"""Graph serialization for T1C-Viz.

Converts t1c.ir Graph objects to JSON-serializable dictionaries
with all data embedded for visualization.
"""

from dataclasses import fields
from typing import Any, Dict, List, Optional, Union

import numpy as np

from .encode import encode_value, format_shape
from .constants import (
    NODE_COLORS, NODE_SHAPES, NODE_DISPLAY_PARAMS, DEFAULT_NODE_COLOR, DEFAULT_NODE_SHAPE,
    GROUP_COLORS, GROUP_SHAPES, GROUP_ICONS, GROUP_DISPLAY_PARAMS, DEFAULT_GROUP_COLOR, DEFAULT_GROUP_SHAPE
)
from .patterns import detect_all_patterns, build_group_hierarchy, PatternMatch, detect_repconv_patterns


def serialize_node(name: str, node: Any) -> Dict[str, Any]:
    """Serialize a single T1C-IR node.

    Args:
        name: Node identifier in the graph
        node: T1C-IR node instance (Affine, LIF, etc.)

    Returns:
        Dictionary with node data for visualization
    """
    node_type = type(node).__name__

    # Get input/output shapes
    input_shape = None
    output_shape = None

    if hasattr(node, "input_type") and node.input_type is not None:
        if isinstance(node.input_type, dict) and "input" in node.input_type:
            input_shape = node.input_type["input"]
            if isinstance(input_shape, np.ndarray):
                input_shape = input_shape.tolist()

    if hasattr(node, "output_type") and node.output_type is not None:
        if isinstance(node.output_type, dict) and "output" in node.output_type:
            output_shape = node.output_type["output"]
            if isinstance(output_shape, np.ndarray):
                output_shape = output_shape.tolist()

    # Extract all parameters (weight, bias, tau, etc.)
    params = {}
    config = {}
    param_count = 0

    # Get fields from dataclass
    if hasattr(node, "__dataclass_fields__"):
        for field in fields(node):
            field_name = field.name
            if field_name in ("input_type", "output_type"):
                continue

            value = getattr(node, field_name, None)
            if value is None:
                continue

            if isinstance(value, np.ndarray):
                # This is a parameter (weight, bias, tau, etc.)
                params[field_name] = encode_value(value)
                param_count += value.size
            elif isinstance(value, dict) and not value:
                # Skip empty dicts (like empty metadata)
                continue
            else:
                # This is configuration (stride, padding, spike_mode, etc.)
                config[field_name] = encode_value(value)

    return {
        "id": name,
        "type": node_type,
        "input_shape": input_shape,
        "output_shape": output_shape,
        "params": params,
        "config": config,
        "param_count": param_count,
        "color": NODE_COLORS.get(node_type, DEFAULT_NODE_COLOR),
        "shape": NODE_SHAPES.get(node_type, DEFAULT_NODE_SHAPE),
        "display_params": NODE_DISPLAY_PARAMS.get(node_type, []),
    }


def compute_summary(graph: Any) -> Dict[str, Any]:
    """Compute summary statistics for a graph.

    Single-pass implementation for efficiency.

    Args:
        graph: T1C-IR Graph object

    Returns:
        Dictionary with summary information
    """
    total_params = 0
    node_counts: Dict[str, int] = {}
    inputs: List[Dict[str, Any]] = []
    outputs: List[Dict[str, Any]] = []

    # Single pass through all nodes
    for name, node in graph.nodes.items():
        node_type = type(node).__name__
        node_counts[node_type] = node_counts.get(node_type, 0) + 1

        # Count parameters (using __dataclass_fields__ directly is faster than fields())
        if hasattr(node, "__dataclass_fields__"):
            for field_name in node.__dataclass_fields__:
                value = getattr(node, field_name, None)
                if isinstance(value, np.ndarray):
                    total_params += value.size

        # Collect Input/Output info in same pass
        if node_type == "Input":
            shape = None
            if hasattr(node, "input_type") and node.input_type:
                shape = node.input_type.get("input")
                if isinstance(shape, np.ndarray):
                    shape = shape.tolist()
            inputs.append({"id": name, "shape": shape})
        elif node_type == "Output":
            shape = None
            if hasattr(node, "output_type") and node.output_type:
                shape = node.output_type.get("output")
                if isinstance(shape, np.ndarray):
                    shape = shape.tolist()
            outputs.append({"id": name, "shape": shape})

    return {
        "node_count": len(graph.nodes),
        "edge_count": len(graph.edges),
        "total_params": total_params,
        "node_counts": node_counts,
        "inputs": inputs,
        "outputs": outputs,
    }


def serialize_pattern(pattern: PatternMatch) -> Dict[str, Any]:
    """Serialize a pattern match for visualization.

    Args:
        pattern: PatternMatch object

    Returns:
        Dictionary with pattern data for visualization
    """
    pattern_type = pattern.pattern_type

    # Build display info for collapsed view
    if pattern_type == "RepConv":
        branches = pattern.metadata.get('branches', [])
        branch_types = [b['type'] for b in branches]
        label = f"RepConv ({len(branches)} branches)"
        subtitle = ", ".join(branch_types)
    elif pattern_type == "SPP":
        num_scales = pattern.metadata.get('num_scales', 0)
        pool_kernels = pattern.metadata.get('pool_kernels', [])
        kernel_strs = [f"{k[0]}×{k[1]}" if k else "?" for k in pool_kernels]
        label = f"SPP ({num_scales} scales)"
        subtitle = "parallel: " + ", ".join(kernel_strs)
    elif pattern_type == "SPPF":
        chain_depth = pattern.metadata.get('chain_depth', 0)
        kernel = pattern.metadata.get('kernel_size')
        kernel_str = f"{kernel[0]}×{kernel[1]}" if kernel else "?"
        label = f"SPPF (depth={chain_depth})"
        subtitle = f"sequential: {kernel_str}"
    elif pattern_type == "SkipConnection":
        processing_depth = pattern.metadata.get('processing_depth', 0)
        path_types = pattern.metadata.get('path_types', [])
        label = f"Skip ({processing_depth} layers)"
        subtitle = "bypass: " + " → ".join(path_types) if path_types else "residual"
    else:
        label = pattern_type
        subtitle = f"{len(pattern.nodes)} nodes"

    return {
        "id": pattern.group_id,
        "type": pattern_type,
        "label": label,
        "subtitle": subtitle,
        "nodes": pattern.nodes,
        "entry_nodes": pattern.entry_nodes,
        "exit_nodes": pattern.exit_nodes,
        "metadata": pattern.metadata,
        "color": GROUP_COLORS.get(pattern_type, DEFAULT_GROUP_COLOR),
        "shape": GROUP_SHAPES.get(pattern_type, DEFAULT_GROUP_SHAPE),
        "icon": GROUP_ICONS.get(pattern_type, "◫"),
        "display_params": GROUP_DISPLAY_PARAMS.get(pattern_type, []),
    }


def graph_to_dict(graph: Any, detect_patterns: bool = True) -> Dict[str, Any]:
    """Convert a T1C-IR graph to a visualization-ready dictionary.

    Serializes all nodes, edges, and embedded data for HTML rendering.
    Optionally detects architectural patterns (like RepConv) for grouped visualization.

    Args:
        graph: T1C-IR Graph object (or path to .t1c file)
        detect_patterns: Whether to detect and include pattern groups (default: True)

    Returns:
        Dictionary with:
            - version: T1C-IR version string
            - nodes: List of serialized nodes
            - edges: List of {source, target} dicts
            - metadata: Graph metadata
            - summary: Statistics and overview
            - groups: List of detected pattern groups (for collapse/expand)
            - node_to_group: Mapping of node IDs to their group IDs

    Example:
        from t1c import ir, viz
        graph = ir.read('model.t1c')
        data = viz.graph_to_dict(graph)
        print(f"Total params: {data['summary']['total_params']}")
        print(f"Detected groups: {len(data['groups'])}")
    """
    # Handle path input
    if isinstance(graph, (str, bytes)):
        from t1c import ir
        graph = ir.read(graph)

    # Import t1c.ir for version
    try:
        from t1c import ir
        version = ir.__version__
    except (ImportError, AttributeError):
        version = "unknown"

    # Detect patterns if enabled
    groups = []
    node_to_group = {}

    if detect_patterns:
        patterns = detect_all_patterns(graph)
        hierarchy = build_group_hierarchy(graph, patterns)

        groups = [serialize_pattern(p) for p in patterns]
        node_to_group = hierarchy['node_to_group']

    # Serialize nodes with group association
    nodes = []
    for name, node in graph.nodes.items():
        serialized = serialize_node(name, node)
        if name in node_to_group:
            serialized['group'] = node_to_group[name]
        nodes.append(serialized)

    # Serialize edges
    edges = [{"source": src, "target": dst} for src, dst in graph.edges]

    # Get metadata
    metadata = {}
    if hasattr(graph, "metadata") and graph.metadata:
        metadata = encode_value(graph.metadata)

    return {
        "version": version,
        "nodes": nodes,
        "edges": edges,
        "metadata": metadata,
        "summary": compute_summary(graph),
        "groups": groups,
        "node_to_group": node_to_group,
    }
