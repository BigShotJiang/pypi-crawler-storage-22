from __future__ import annotations
from abc import ABCMeta, abstractmethod
from typing import Callable, Iterable, Mapping, Any, Optional
from table_stream.base.hash_map import T
import threading


class ThreadConsumer(metaclass=ABCMeta):

    def __init__(self):
        self.__running = False
        self.__exception: Exception | None = None

    def __repr__(self):
        return f'<{self.__class__.__name__}()>'

    @abstractmethod
    def event_init_thread(self) -> None:
        pass

    @abstractmethod
    def event_finish_thread(self, t: ControlledThread[T]) -> T | None:
        pass

    def get_exception(self) -> Exception | None:
        return self.__exception

    def set_exception(self, e: Exception) -> None:
        self.__exception = e

    def running(self) -> bool:
        return self.__running

    def set_status_running(self, status: bool) -> None:
        self.__running = status


class ControlledThread[T](threading.Thread):

    def __init__(
                self, *,
                group=None,
                target: Callable,
                name=None,
                args: Iterable[Any]=None,
                kwargs: Mapping[str, Any] | None = None,
                daemon: bool | None=None,
            ):
        if args is None:
            args = ()
        super().__init__(group, target, name, args, kwargs, daemon=daemon)
        self._target: Callable[[Optional[Any]], Any] = target
        self._args: tuple[Any, ...] = tuple(args)
        self._kwargs: dict[str, Any] = dict(kwargs or {})

        self._exception_value: Exception = None
        self._pause_event: threading.Event = threading.Event()
        self._stop_event: threading.Event = threading.Event()
        # Começa rodando
        self._pause_event.set()

        self._result: T = None
        self._consumer: ThreadConsumer = None

    def set_consumer(self, consumer: ThreadConsumer) -> None:
        self._consumer = consumer

    def get_consumer(self) -> ThreadConsumer | None:
        return self._consumer

    def remove_consumer(self) -> None:
        self._consumer = None

    def finish_event(self) -> None:
        """
            Adicionar um ou vários CALLABLE a serem chamados após a conclusão da
        Thread - set[Callable[[ControlledThread], None]]().

        """
        if self.get_consumer() is None:
            return
        # Informar o consumer sobre a finalização da thread.
        self.get_consumer().set_status_running(False)
        self.get_consumer().event_finish_thread(self)

    def get_result(self) -> T:
        return self._result

    def get_exception_value(self) -> Exception | None:
        return self._exception_value

    def run(self) -> None:
        """
        Executa o callable alvo respeitando pause / stop.
        O callable pode checar should_stop() se quiser encerrar limpo.
        """
        self._pause_event.wait()
        # Executa o target
        if self.get_consumer() is not None:
            self.get_consumer().set_status_running(True)
            self.get_consumer().event_init_thread()
        try:
            if self._target is not None:
                self._result = self._target(*self._args, **self._kwargs)
        except Exception as e:
            self._exception_value = e
            if self.get_consumer() is not None:
                self.get_consumer().set_exception(e)
        finally:
            del self._target, self._args, self._kwargs
            self.finish_event()

    def pause(self) -> None:
        print(f'{__class__.__name__} Thread pausada [{self.name}]')
        self._pause_event.clear()

    def resume(self) -> None:
        self._pause_event.set()

    def stop(self) -> None:
        print(f'{__class__.__name__} Thread cancelada [{self.name}]')
        self._stop_event.set()
        self._pause_event.set()

    def wait_thread(self, timeout: Optional[float] = None) -> None:
        self.join(timeout)

    def should_stop(self) -> bool:
        """
        Pode ser chamado de dentro do target para parada cooperativa.
        """
        return self._stop_event.is_set()
