"""
Tableau Server API Client.
Handles all communication with the Tableau Server REST API and Metadata API (GraphQL).
"""

import logging
import os
import re
import requests
import base64
from typing import Any, Dict, List, Optional, Tuple
from contextlib import contextmanager
from urllib.parse import unquote
from datetime import datetime

import tableauserverclient as TSC

from .config import TableauConfig, AuthMethod, get_config

logger = logging.getLogger("tableau-mcp.client")


class TableauClientError(Exception):
    """Custom exception for Tableau API errors."""
    def __init__(self, message: str, error_code: Optional[str] = None):
        super().__init__(message)
        self.error_code = error_code


class TableauClient:
    """
    Client for Tableau Server REST API.
    Uses tableauserverclient library for API interactions.
    """
    
    def __init__(self, config: Optional[TableauConfig] = None):
        """Initialize the client with configuration."""
        self.config = config or get_config()
        self._server: Optional[TSC.Server] = None
        self._auth: Optional[TSC.TableauAuth] = None
    
    def _create_auth(self) -> TSC.TableauAuth:
        """Create the appropriate auth object based on config."""
        if self.config.auth_method == AuthMethod.PERSONAL_ACCESS_TOKEN:
            return TSC.PersonalAccessTokenAuth(
                self.config.token_name,
                self.config.token_secret,
                self.config.site_id
            )
        else:
            return TSC.TableauAuth(
                self.config.username,
                self.config.password,
                self.config.site_id
            )
    
    def _create_server(self) -> TSC.Server:
        """Create and configure the server object."""
        server = TSC.Server(self.config.server_url, use_server_version=True)
        
        # Configure SSL verification
        if not self.config.verify_ssl:
            server.add_http_options({'verify': False})
        
        # Set API version if specified
        if self.config.api_version:
            server.version = self.config.api_version
        
        return server
    
    @contextmanager
    def connection(self):
        """
        Context manager for authenticated Tableau Server connection.
        
        Usage:
            with client.connection() as server:
                workbooks = server.workbooks.get()
        """
        server = self._create_server()
        auth = self._create_auth()
        
        try:
            server.auth.sign_in(auth)
            logger.debug("Successfully authenticated to Tableau Server")
            yield server
        except TSC.ServerResponseError as e:
            raise TableauClientError(f"Tableau API error: {e.summary}", e.code)
        except Exception as e:
            raise TableauClientError(f"Connection error: {str(e)}")
        finally:
            try:
                server.auth.sign_out()
            except:
                pass
    
    def test_connection(self) -> Dict[str, Any]:
        """Test the connection and return server/user info."""
        try:
            with self.connection() as server:
                user = server.users.get_by_id(server.user_id)
                return {
                    "success": True,
                    "server_url": self.config.server_url,
                    "api_version": server.version,
                    "site_id": server.site_id or "Default",
                    "user_id": server.user_id,
                    "user_name": user.name,
                    "user_role": user.site_role
                }
        except TableauClientError as e:
            return {
                "success": False,
                "error": str(e),
                "error_code": e.error_code
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    # ===== Workbook Methods =====
    
    def list_workbooks(self, project_id: Optional[str] = None, limit: int = 1000) -> Tuple[List[TSC.WorkbookItem], int]:
        """List all workbooks, optionally filtered by project."""
        with self.connection() as server:
            req_options = TSC.RequestOptions(pagesize=100)
            # Note: TSC ProjectId filter can be unreliable across versions.
            # We filter client-side if project_id is provided.
            
            all_workbooks = []
            for workbook in TSC.Pager(server.workbooks, req_options):
                if project_id and workbook.project_id != project_id:
                    continue
                all_workbooks.append(workbook)
                if len(all_workbooks) >= limit:
                    break
            
            return all_workbooks, len(all_workbooks)
    
    def get_workbook(self, workbook_id: str) -> TSC.WorkbookItem:
        """Get detailed information about a workbook."""
        with self.connection() as server:
            workbook = server.workbooks.get_by_id(workbook_id)
            server.workbooks.populate_views(workbook)
            return workbook
    
    def search_workbooks(self, query: str, limit: int = 20) -> List[TSC.WorkbookItem]:
        """Search workbooks by name (client-side filter for compatibility)."""
        with self.connection() as server:
            results = []
            query_lower = query.lower()
            for workbook in TSC.Pager(server.workbooks):
                if query_lower in (workbook.name or "").lower():
                    results.append(workbook)
                    if len(results) >= limit:
                        break
            return results
    
    # ===== View Methods =====
    
    def list_views(self, workbook_id: Optional[str] = None) -> List[TSC.ViewItem]:
        """List views, optionally filtered by workbook."""
        with self.connection() as server:
            if workbook_id:
                workbook = server.workbooks.get_by_id(workbook_id)
                server.workbooks.populate_views(workbook)
                return list(workbook.views)
            else:
                all_views = []
                for view in TSC.Pager(server.views):
                    all_views.append(view)
                    if len(all_views) >= 1000:
                        break
                return all_views
    
    def get_view(self, view_id: str) -> TSC.ViewItem:
        """Get detailed information about a view."""
        with self.connection() as server:
            view = server.views.get_by_id(view_id)
            return view
    
    def get_view_image(self, view_id: str) -> bytes:
        """Get PNG image of a view."""
        with self.connection() as server:
            view = server.views.get_by_id(view_id)
            server.views.populate_image(view)
            return view.image
    
    def get_view_data(self, view_id: str, max_rows: int = 100) -> Tuple[List[str], List[List[Any]]]:
        """Get underlying data from a view (CSV format)."""
        with self.connection() as server:
            view = server.views.get_by_id(view_id)
            server.views.populate_csv(view)
            
            import csv
            import io
            
            csv_content = b''.join(view.csv).decode('utf-8')
            reader = csv.reader(io.StringIO(csv_content))
            rows = list(reader)
            
            if not rows:
                return [], []
            
            headers = rows[0]
            data = rows[1:max_rows+1]
            
            return headers, data
    
    def parse_tableau_url(self, url: str) -> Tuple[Optional[str], Optional[str]]:
        """Parse a Tableau URL to extract workbook and view names."""
        url = unquote(url)
        
        patterns = [
            r'#/(?:site/[^/]+/)?views/([^/]+)/([^/?#]+)',
            r'/views/([^/]+)/([^/?#]+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                workbook_url = match.group(1)
                view_name = match.group(2)
                return workbook_url, view_name
        
        return None, None
    
    def find_view_by_content_url(self, workbook_url: str, view_name: str) -> Optional[TSC.ViewItem]:
        """Find a view by its workbook content URL and view name."""
        with self.connection() as server:
            for workbook in TSC.Pager(server.workbooks):
                if workbook.content_url and workbook.content_url.lower() == workbook_url.lower():
                    server.workbooks.populate_views(workbook)
                    for view in workbook.views:
                        view_content_url = view.content_url or ""
                        if view_name.lower() in view_content_url.lower():
                            return view
                        if view.name and view_name.lower().replace(" ", "") == view.name.lower().replace(" ", ""):
                            return view
            
            return None
    
    def save_view_image(
        self, 
        view_id: str, 
        output_dir: str, 
        filename: Optional[str] = None
    ) -> Tuple[bool, str, int]:
        """Download a view's image and save it to disk."""
        with self.connection() as server:
            try:
                view = server.views.get_by_id(view_id)
                server.views.populate_image(view)
                
                if not view.image:
                    return False, "No image data returned from server", 0
                
                os.makedirs(output_dir, exist_ok=True)
                
                if not filename:
                    filename = re.sub(r'[^\w\-]', '_', view.name or view_id)
                
                filepath = os.path.join(output_dir, f"{filename}.png")
                
                with open(filepath, 'wb') as f:
                    f.write(view.image)
                
                return True, filepath, len(view.image)
                
            except Exception as e:
                return False, str(e), 0
    
    # ===== Data Source Methods =====
    
    def list_datasources(self, project_id: Optional[str] = None, limit: int = 1000) -> List[TSC.DatasourceItem]:
        """List all data sources."""
        with self.connection() as server:
            req_options = TSC.RequestOptions(pagesize=100)
            # Note: TSC doesn't support ProjectId filter for datasources.
            # We filter client-side if project_id is provided.
            
            all_datasources = []
            for ds in TSC.Pager(server.datasources, req_options):
                if project_id and ds.project_id != project_id:
                    continue
                all_datasources.append(ds)
                if len(all_datasources) >= limit:
                    break
            
            return all_datasources
    
    def get_datasource(self, datasource_id: str) -> TSC.DatasourceItem:
        """Get detailed information about a data source."""
        with self.connection() as server:
            return server.datasources.get_by_id(datasource_id)
    
    def refresh_datasource(self, datasource_id: str) -> str:
        """Trigger a refresh of a data source extract."""
        with self.connection() as server:
            datasource = server.datasources.get_by_id(datasource_id)
            job = server.datasources.refresh(datasource)
            return job.id
    
    def get_datasource_custom_sql(self, datasource_name: str) -> Dict[str, Any]:
        """
        Get Custom SQL query from a published datasource.
        Downloads the .tdsx file and extracts Custom SQL queries.
        
        Args:
            datasource_name: Name of the datasource
            
        Returns:
            Dict with 'found', 'name', 'id', 'sql_queries' list, and 'error' if any
        """
        import zipfile
        import xml.etree.ElementTree as ET
        import tempfile
        
        with self.connection() as server:
            # Find datasource by name
            req_options = TSC.RequestOptions()
            req_options.filter.add(TSC.Filter(
                TSC.RequestOptions.Field.Name,
                TSC.RequestOptions.Operator.Equals,
                datasource_name
            ))
            
            datasources, _ = server.datasources.get(req_options)
            
            if not datasources:
                return {
                    "found": False,
                    "error": f"Datasource '{datasource_name}' not found"
                }
            
            ds = datasources[0]
            
            # Download datasource content
            download_url = f"{self.config.server_url}/api/{server.version}/sites/{server.site_id}/datasources/{ds.id}/content"
            headers = {"X-Tableau-Auth": server.auth_token}
            
            response = requests.get(
                download_url, 
                headers=headers, 
                verify=self.config.verify_ssl,
                stream=True
            )
            
            if response.status_code != 200:
                return {
                    "found": True,
                    "name": ds.name,
                    "id": ds.id,
                    "error": f"Failed to download datasource: HTTP {response.status_code}"
                }
            
            # Save to temp file
            with tempfile.NamedTemporaryFile(delete=False, suffix='.tdsx') as tmp_file:
                for chunk in response.iter_content(chunk_size=8192):
                    tmp_file.write(chunk)
                tmp_path = tmp_file.name
            
            try:
                sql_queries = []
                
                # Extract from .tdsx (zip file)
                with zipfile.ZipFile(tmp_path, 'r') as z:
                    # Find .tds file
                    tds_files = [name for name in z.namelist() if name.endswith('.tds')]
                    
                    if not tds_files:
                        return {
                            "found": True,
                            "name": ds.name,
                            "id": ds.id,
                            "error": "No .tds file found in datasource archive"
                        }
                    
                    for tds_file in tds_files:
                        with z.open(tds_file) as f:
                            tds_content = f.read().decode('utf-8')
                        
                        # Parse XML to find Custom SQL
                        try:
                            root = ET.fromstring(tds_content)
                            
                            # Find relation elements with type="text" (Custom SQL)
                            relations = root.findall('.//relation[@type="text"]')
                            
                            for relation in relations:
                                sql = relation.text or ''
                                name = relation.get('name', 'Custom SQL Query')
                                
                                if sql.strip():
                                    sql_queries.append({
                                        "name": name,
                                        "sql": sql.strip()
                                    })
                        
                        except ET.ParseError:
                            # Fallback to regex if XML parsing fails
                            import re
                            sql_pattern = r'<relation[^>]*type=["\']text["\'][^>]*>(.*?)</relation>'
                            matches = re.findall(sql_pattern, tds_content, re.DOTALL | re.IGNORECASE)
                            
                            for match in matches:
                                sql_clean = match.strip()
                                if sql_clean:
                                    sql_queries.append({
                                        "name": "Custom SQL Query",
                                        "sql": sql_clean
                                    })
                
                return {
                    "found": True,
                    "name": ds.name,
                    "id": ds.id,
                    "project_name": ds.project_name,
                    "sql_queries": sql_queries
                }
            
            finally:
                # Clean up temp file
                try:
                    os.unlink(tmp_path)
                except:
                    pass
    
    # ===== Project Methods =====
    
    def list_projects(self, parent_id: Optional[str] = None) -> List[TSC.ProjectItem]:
        """List all projects."""
        with self.connection() as server:
            all_projects = []
            for project in TSC.Pager(server.projects):
                if parent_id is None or project.parent_id == parent_id:
                    all_projects.append(project)
            return all_projects
    
    def get_project(self, project_id: str) -> TSC.ProjectItem:
        """Get project details."""
        with self.connection() as server:
            return server.projects.get_by_id(project_id)
    
    # ===== User Methods =====
    
    def list_users(self, limit: int = 100) -> List[TSC.UserItem]:
        """List users on the server."""
        with self.connection() as server:
            all_users = []
            for user in TSC.Pager(server.users):
                all_users.append(user)
                if len(all_users) >= limit:
                    break
            return all_users
    
    def get_user(self, user_id: str) -> TSC.UserItem:
        """Get user details."""
        with self.connection() as server:
            return server.users.get_by_id(user_id)
    
    # ===== Site Methods =====
    
    def list_sites(self) -> List[TSC.SiteItem]:
        """List all sites (requires server admin)."""
        with self.connection() as server:
            sites, _ = server.sites.get()
            return list(sites)
    
    # ===== Publishing Methods =====
    
    def publish_workbook(
        self, 
        file_path: str, 
        project_id: str,
        name: Optional[str] = None,
        show_tabs: bool = True,
        hidden_views: Optional[List[str]] = None,
        overwrite: bool = False
    ) -> Dict[str, Any]:
        """
        Publish a workbook (.twb or .twbx) to Tableau Server.
        
        Args:
            file_path: Path to the workbook file
            project_id: ID of the project to publish to
            name: Name for the workbook (defaults to filename)
            show_tabs: Whether to show sheet tabs
            hidden_views: List of view names to hide
            overwrite: Whether to overwrite existing workbook
            
        Returns:
            Dict with published workbook info
        """
        if not os.path.exists(file_path):
            return {"success": False, "error": f"File not found: {file_path}"}
        
        if not file_path.endswith(('.twb', '.twbx')):
            return {"success": False, "error": "File must be a .twb or .twbx file"}
        
        with self.connection() as server:
            try:
                # Create workbook item
                workbook_name = name or os.path.splitext(os.path.basename(file_path))[0]
                new_workbook = TSC.WorkbookItem(project_id, name=workbook_name, show_tabs=show_tabs)
                
                if hidden_views:
                    new_workbook.hidden_views = hidden_views
                
                # Publish
                publish_mode = TSC.Server.PublishMode.Overwrite if overwrite else TSC.Server.PublishMode.CreateNew
                
                published_workbook = server.workbooks.publish(
                    new_workbook, 
                    file_path, 
                    publish_mode
                )
                
                return {
                    "success": True,
                    "workbook_id": published_workbook.id,
                    "workbook_name": published_workbook.name,
                    "project_id": published_workbook.project_id,
                    "content_url": published_workbook.content_url,
                    "webpage_url": f"{self.config.server_url}/#/workbooks/{published_workbook.id}"
                }
                
            except TSC.ServerResponseError as e:
                return {"success": False, "error": f"Tableau API error: {e.summary}", "code": e.code}
            except Exception as e:
                return {"success": False, "error": str(e)}
    
    def publish_datasource(
        self, 
        file_path: str, 
        project_id: str,
        name: Optional[str] = None,
        overwrite: bool = False
    ) -> Dict[str, Any]:
        """
        Publish a datasource (.tds or .tdsx) to Tableau Server.
        
        Args:
            file_path: Path to the datasource file
            project_id: ID of the project to publish to
            name: Name for the datasource (defaults to filename)
            overwrite: Whether to overwrite existing datasource
            
        Returns:
            Dict with published datasource info
        """
        if not os.path.exists(file_path):
            return {"success": False, "error": f"File not found: {file_path}"}
        
        if not file_path.endswith(('.tds', '.tdsx', '.hyper')):
            return {"success": False, "error": "File must be a .tds, .tdsx, or .hyper file"}
        
        with self.connection() as server:
            try:
                # Create datasource item
                ds_name = name or os.path.splitext(os.path.basename(file_path))[0]
                new_datasource = TSC.DatasourceItem(project_id, name=ds_name)
                
                # Publish
                publish_mode = TSC.Server.PublishMode.Overwrite if overwrite else TSC.Server.PublishMode.CreateNew
                
                published_datasource = server.datasources.publish(
                    new_datasource, 
                    file_path, 
                    publish_mode
                )
                
                return {
                    "success": True,
                    "datasource_id": published_datasource.id,
                    "datasource_name": published_datasource.name,
                    "project_id": published_datasource.project_id,
                    "content_url": published_datasource.content_url,
                    "webpage_url": f"{self.config.server_url}/#/datasources/{published_datasource.id}"
                }
                
            except TSC.ServerResponseError as e:
                return {"success": False, "error": f"Tableau API error: {e.summary}", "code": e.code}
            except Exception as e:
                return {"success": False, "error": str(e)}
    
    # ===== Metadata API (GraphQL) Methods =====
    
    def _get_metadata_api_url(self) -> str:
        """Get the Metadata API GraphQL endpoint URL."""
        base_url = self.config.server_url.rstrip('/')
        return f"{base_url}/api/metadata/graphql"
    
    def _execute_metadata_query(self, query: str, variables: Optional[Dict] = None) -> Dict[str, Any]:
        """Execute a GraphQL query against the Tableau Metadata API."""
        with self.connection() as server:
            auth_token = server.auth_token
            
            headers = {
                "Content-Type": "application/json",
                "X-Tableau-Auth": auth_token
            }
            
            payload = {"query": query}
            if variables:
                payload["variables"] = variables
            
            response = requests.post(
                self._get_metadata_api_url(),
                json=payload,
                headers=headers,
                verify=self.config.verify_ssl
            )
            
            if response.status_code != 200:
                raise TableauClientError(
                    f"Metadata API error: {response.status_code} - {response.text}"
                )
            
            result = response.json()
            
            if "errors" in result:
                # Distinguish real errors from permission warnings
                real_errors = []
                for e in result["errors"]:
                    severity = (e.get("extensions") or {}).get("severity", "ERROR")
                    if severity == "WARNING":
                        logger.debug(f"Metadata API warning: {e.get('message', '')}")
                    else:
                        real_errors.append(e)
                
                # Only raise if there are real errors AND no data
                if real_errors and not result.get("data"):
                    error_msg = "; ".join([e.get("message", str(e)) for e in real_errors])
                    raise TableauClientError(f"GraphQL error: {error_msg}")
            
            return result.get("data", {})
    
    def get_datasource_extract_info(self, datasource_name: str) -> Dict[str, Any]:
        """Get extract refresh information for a datasource."""
        query = """
        query GetDatasourceExtractInfo($name: String) {
            publishedDatasources(filter: { name: $name }) {
                id
                name
                hasExtracts
                extractLastRefreshTime
                extractLastUpdateTime
                extractLastIncrementalUpdateTime
                projectName
                owner { name }
                upstreamDatabases { name connectionType }
                downstreamWorkbooks { name projectName }
            }
        }
        """
        
        result = self._execute_metadata_query(query, {"name": datasource_name})
        datasources = result.get("publishedDatasources", [])
        
        if not datasources:
            return {"found": False, "name": datasource_name}
        
        ds = datasources[0]
        return {
            "found": True,
            "id": ds.get("id"),
            "name": ds.get("name"),
            "has_extracts": ds.get("hasExtracts", False),
            "extract_last_refresh_time": ds.get("extractLastRefreshTime"),
            "extract_last_update_time": ds.get("extractLastUpdateTime"),
            "extract_last_incremental_update_time": ds.get("extractLastIncrementalUpdateTime"),
            "project_name": ds.get("projectName"),
            "owner": ds.get("owner", {}).get("name") if ds.get("owner") else None,
            "upstream_databases": ds.get("upstreamDatabases", []),
            "downstream_workbooks": ds.get("downstreamWorkbooks", [])
        }
    
    def get_workbook_datasources_extract_info(self, workbook_name: str) -> Dict[str, Any]:
        """Get extract refresh information for all datasources used by a workbook."""
        query = """
        query GetWorkbookDatasourcesInfo($name: String) {
            workbooks(filter: { name: $name }) {
                id
                name
                projectName
                owner { name }
                updatedAt
                upstreamDatasources {
                    id name hasExtracts
                    extractLastRefreshTime extractLastUpdateTime
                    extractLastIncrementalUpdateTime projectName
                }
            }
        }
        """
        
        result = self._execute_metadata_query(query, {"name": workbook_name})
        workbooks = result.get("workbooks", [])
        
        if not workbooks:
            return {"found": False, "name": workbook_name}
        
        wb = workbooks[0]
        datasources = []
        for ds in wb.get("upstreamDatasources", []):
            datasources.append({
                "id": ds.get("id"),
                "name": ds.get("name"),
                "has_extracts": ds.get("hasExtracts", False),
                "extract_last_refresh_time": ds.get("extractLastRefreshTime"),
                "extract_last_update_time": ds.get("extractLastUpdateTime"),
                "extract_last_incremental_update_time": ds.get("extractLastIncrementalUpdateTime"),
                "project_name": ds.get("projectName")
            })
        
        return {
            "found": True,
            "id": wb.get("id"),
            "name": wb.get("name"),
            "project_name": wb.get("projectName"),
            "owner": wb.get("owner", {}).get("name") if wb.get("owner") else None,
            "updated_at": wb.get("updatedAt"),
            "datasources": datasources
        }
    
    def search_datasources_by_extract_time(self, hours_since_refresh: int = 24) -> List[Dict[str, Any]]:
        """Find datasources that haven't been refreshed within the specified hours."""
        query = """
        query GetAllDatasourcesExtractInfo {
            publishedDatasources {
                id name hasExtracts extractLastRefreshTime
                extractLastUpdateTime projectName
                owner { name }
            }
        }
        """
        
        result = self._execute_metadata_query(query)
        datasources = result.get("publishedDatasources", [])
        
        stale_datasources = []
        now = datetime.utcnow()
        
        for ds in datasources:
            if not ds.get("hasExtracts"):
                continue
                
            last_refresh = ds.get("extractLastRefreshTime")
            if not last_refresh:
                stale_datasources.append({
                    "id": ds.get("id"),
                    "name": ds.get("name"),
                    "project_name": ds.get("projectName"),
                    "owner": ds.get("owner", {}).get("name") if ds.get("owner") else None,
                    "extract_last_refresh_time": None,
                    "hours_since_refresh": None,
                    "status": "never_refreshed"
                })
                continue
            
            try:
                refresh_time = datetime.fromisoformat(last_refresh.replace('Z', '+00:00'))
                refresh_time = refresh_time.replace(tzinfo=None)
                hours_diff = (now - refresh_time).total_seconds() / 3600
                
                if hours_diff > hours_since_refresh:
                    stale_datasources.append({
                        "id": ds.get("id"),
                        "name": ds.get("name"),
                        "project_name": ds.get("projectName"),
                        "owner": ds.get("owner", {}).get("name") if ds.get("owner") else None,
                        "extract_last_refresh_time": last_refresh,
                        "hours_since_refresh": round(hours_diff, 1),
                        "status": "stale"
                    })
            except (ValueError, TypeError):
                pass
        
        return stale_datasources

    def get_datasource_upstream_tables(self, datasource_name: str) -> Dict[str, Any]:
        """Get the actual upstream tables used by a datasource."""
        query = """
        query GetDatasourceUpstreamTables($name: String) {
            publishedDatasources(filter: { name: $name }) {
                id name hasExtracts projectName
                owner { name }
                upstreamTables {
                    id name fullName schema
                    database { name connectionType }
                }
                upstreamDatabases { name connectionType }
                fields { id name description isHidden fullyQualifiedName }
            }
        }
        """
        
        result = self._execute_metadata_query(query, {"name": datasource_name})
        datasources = result.get("publishedDatasources", [])
        
        if not datasources:
            return {"found": False, "name": datasource_name}
        
        ds = datasources[0]
        
        upstream_tables = []
        for table in ds.get("upstreamTables", []):
            db = table.get("database", {})
            upstream_tables.append({
                "id": table.get("id"),
                "name": table.get("name"),
                "full_name": table.get("fullName"),
                "schema": table.get("schema"),
                "database_name": db.get("name") if db else None,
                "connection_type": db.get("connectionType") if db else None
            })
        
        fields = []
        for field in ds.get("fields", []):
            if not field.get("isHidden", False):
                fields.append({
                    "name": field.get("name"),
                    "description": field.get("description"),
                    "fully_qualified_name": field.get("fullyQualifiedName")
                })
        fields = fields[:50]
        
        return {
            "found": True,
            "id": ds.get("id"),
            "name": ds.get("name"),
            "has_extracts": ds.get("hasExtracts", False),
            "project_name": ds.get("projectName"),
            "owner": ds.get("owner", {}).get("name") if ds.get("owner") else None,
            "upstream_tables": upstream_tables,
            "upstream_databases": ds.get("upstreamDatabases", []),
            "fields": fields,
            "field_count": len(ds.get("fields", []))
        }
    
    def get_workbook_upstream_tables(self, workbook_name: str) -> Dict[str, Any]:
        """Get all upstream tables used by a workbook/dashboard."""
        query = """
        query GetWorkbookUpstreamTables($name: String) {
            workbooks(filter: { name: $name }) {
                id name projectName
                owner { name }
                updatedAt
                upstreamDatasources {
                    id name hasExtracts projectName
                    upstreamTables {
                        id name fullName schema
                        database { name connectionType }
                    }
                }
                upstreamTables {
                    id name fullName schema
                    database { name connectionType }
                }
            }
        }
        """
        
        result = self._execute_metadata_query(query, {"name": workbook_name})
        workbooks = result.get("workbooks", [])
        
        if not workbooks:
            return {"found": False, "name": workbook_name}
        
        wb = workbooks[0]
        
        all_tables = {}
        
        for table in wb.get("upstreamTables", []):
            db = table.get("database", {})
            full_name = table.get("fullName") or f"{table.get('schema', '')}.{table.get('name', '')}"
            all_tables[full_name] = {
                "name": table.get("name"),
                "full_name": full_name,
                "schema": table.get("schema"),
                "database_name": db.get("name") if db else None,
                "connection_type": db.get("connectionType") if db else None,
                "source": "direct"
            }
        
        datasources = []
        for ds in wb.get("upstreamDatasources", []):
            ds_tables = []
            for table in ds.get("upstreamTables", []):
                db = table.get("database", {})
                full_name = table.get("fullName") or f"{table.get('schema', '')}.{table.get('name', '')}"
                table_info = {
                    "name": table.get("name"),
                    "full_name": full_name,
                    "schema": table.get("schema"),
                    "database_name": db.get("name") if db else None,
                    "connection_type": db.get("connectionType") if db else None,
                    "source": f"datasource:{ds.get('name')}"
                }
                ds_tables.append(table_info)
                all_tables[full_name] = table_info
            
            datasources.append({
                "id": ds.get("id"),
                "name": ds.get("name"),
                "has_extracts": ds.get("hasExtracts", False),
                "project_name": ds.get("projectName"),
                "tables": ds_tables
            })
        
        return {
            "found": True,
            "id": wb.get("id"),
            "name": wb.get("name"),
            "project_name": wb.get("projectName"),
            "owner": wb.get("owner", {}).get("name") if wb.get("owner") else None,
            "updated_at": wb.get("updatedAt"),
            "datasources": datasources,
            "all_upstream_tables": list(all_tables.values()),
            "table_count": len(all_tables)
        }

    def get_datasource_custom_sql_via_metadata(self, datasource_name: str) -> Dict[str, Any]:
        """
        Get Custom SQL queries from a published datasource using the Metadata API.
        This is the ZERO-DOWNLOAD approach - no file downloads needed.
        
        Uses intelligent matching to find CustomSQLTables that belong to the datasource.
        
        Args:
            datasource_name: Name of the published datasource
            
        Returns:
            Dict with 'found', 'name', 'id', 'custom_sql_queries' list
        """
        # Step 1: Get datasource info including databases and fields
        query_ds = """
        query GetDatasource($name: String!) {
            publishedDatasources(filter: { name: $name }) {
                id
                name
                projectName
                owner { name }
                hasExtracts
                upstreamDatabases {
                    id
                    name
                    connectionType
                }
                fields {
                    id
                    name
                }
            }
        }
        """
        
        with self.connection() as server:
            auth_token = server.auth_token
            headers = {
                "Content-Type": "application/json",
                "X-Tableau-Auth": auth_token
            }
            
            # Get datasource
            response1 = requests.post(
                self._get_metadata_api_url(),
                json={"query": query_ds, "variables": {"name": datasource_name}},
                headers=headers,
                verify=self.config.verify_ssl
            )
            
            if response1.status_code != 200:
                return {"found": False, "error": f"HTTP error: {response1.status_code}"}
            
            result1 = response1.json()
            datasources = result1.get("data", {}).get("publishedDatasources", [])
            
            if not datasources:
                return {"found": False, "error": f"Datasource '{datasource_name}' not found"}
            
            ds = datasources[0]
            ds_id = ds.get("id")
            ds_name = ds.get("name")
            
            # Get database IDs and names for matching
            upstream_dbs = ds.get("upstreamDatabases", [])
            db_ids = {db.get('id') for db in upstream_dbs if db.get('id')}
            db_names = {db.get('name') for db in upstream_dbs if db.get('name')}
            
            # Get datasource field names for matching
            ds_fields = [
                (f.get('name') or '').lower() 
                for f in ds.get('fields', []) 
                if f and f.get('name')
            ]
            ds_fields_set = set(ds_fields)
            
            # Step 2: Query all CustomSQLTables
            query_cst = """
            query GetAllCustomSQLTables {
                customSQLTables {
                    id
                    name
                    query
                    database {
                        id
                        name
                        connectionType
                    }
                    columns {
                        id
                        name
                        remoteType
                    }
                    tables {
                        name
                        fullName
                        schema
                    }
                }
            }
            """
            
            response2 = requests.post(
                self._get_metadata_api_url(),
                json={"query": query_cst},
                headers=headers,
                verify=self.config.verify_ssl
            )
            
            if response2.status_code != 200:
                return {
                    "found": True,
                    "name": ds_name,
                    "id": ds_id,
                    "error": f"CustomSQLTables query failed: {response2.status_code}"
                }
            
            result2 = response2.json()
            all_custom_sql = result2.get("data", {}).get("customSQLTables", [])
            
            # Step 3: Match CustomSQLTables using scoring algorithm
            # Extract keywords from datasource name
            ds_name_lower = datasource_name.lower()
            ds_keywords = set(ds_name_lower.replace('-', ' ').replace('_', ' ').split())
            ds_keywords -= {'query', 'ds', 'data', 'source', 'datasource', 'the', 'and', 'or', 'for'}
            
            scored_matches = []
            
            for cst in all_custom_sql:
                cst_db = cst.get('database')
                if not cst_db:
                    continue
                
                cst_db_id = cst_db.get('id')
                cst_db_name = cst_db.get('name')
                
                # Must match database
                if cst_db_id not in db_ids and cst_db_name not in db_names:
                    continue
                
                # Get CustomSQLTable columns
                cst_columns = [
                    (col.get('name') or '').lower() 
                    for col in cst.get('columns', []) 
                    if col and col.get('name')
                ]
                cst_column_set = set(cst_columns)
                
                # Get SQL content for keyword matching
                sql_query = (cst.get('query') or '').lower()
                
                # Calculate matching fields
                matching_fields = ds_fields_set & cst_column_set if ds_fields_set else set()
                
                # Check keyword matches in SQL or columns
                keyword_matches = 0
                for kw in ds_keywords:
                    if len(kw) >= 3:
                        if kw in sql_query or any(kw in col for col in cst_columns):
                            keyword_matches += 1
                
                # Calculate score
                score = 0
                
                if matching_fields:
                    score += len(matching_fields) * 10
                    
                    # Bonus for high coverage
                    if ds_fields_set:
                        coverage = len(matching_fields) / len(ds_fields_set)
                        if coverage >= 0.8:
                            score += 50
                        elif coverage >= 0.5:
                            score += 25
                
                # Keyword matching bonus
                if keyword_matches >= 2:
                    score += keyword_matches * 15
                elif keyword_matches == 1:
                    score += 5
                
                # Accept if score is high enough
                if score >= 5:
                    scored_matches.append({
                        'cst': cst,
                        'score': score,
                        'matching_fields': list(matching_fields)[:10],
                        'field_match_count': len(matching_fields),
                        'field_match_pct': round(len(matching_fields) / len(ds_fields_set) * 100, 1) if ds_fields_set else 0
                    })
            
            # Sort by score (highest first)
            scored_matches.sort(key=lambda x: x['score'], reverse=True)
            
            # Take top 3 matches
            top_matches = scored_matches[:3]
            
            custom_sql_queries = []
            for match in top_matches:
                cst = match['cst']
                db = cst.get('database', {})
                
                # Extract source tables from SQL
                sql_text = cst.get('query', '')
                source_tables = []
                table_patterns = [
                    r'from\s+([a-zA-Z_][a-zA-Z0-9_]*\.[a-zA-Z_][a-zA-Z0-9_]*)',
                    r'join\s+([a-zA-Z_][a-zA-Z0-9_]*\.[a-zA-Z_][a-zA-Z0-9_]*)',
                ]
                for pattern in table_patterns:
                    matches = re.findall(pattern, sql_text, re.IGNORECASE)
                    source_tables.extend(matches)
                
                custom_sql_queries.append({
                    'name': cst.get('name', 'Custom SQL Query'),
                    'query': sql_text,
                    'database': db.get('name'),
                    'connection_type': db.get('connectionType'),
                    'columns': [
                        {'name': c.get('name'), 'type': c.get('remoteType')}
                        for c in cst.get('columns', [])
                    ],
                    'source_tables': list(set(source_tables)),
                    'score': match['score'],
                    'matching_fields': match['matching_fields'],
                    'field_match_pct': match['field_match_pct']
                })
            
            return {
                "found": True,
                "name": ds_name,
                "id": ds_id,
                "project_name": ds.get("projectName"),
                "owner": ds.get("owner", {}).get("name") if ds.get("owner") else None,
                "has_extracts": ds.get("hasExtracts", False),
                "upstream_databases": [
                    {"name": db.get("name"), "type": db.get("connectionType")}
                    for db in upstream_dbs
                ],
                "datasource_fields_count": len(ds_fields_set),
                "custom_sql_queries": custom_sql_queries,
                "total_candidates_searched": len(all_custom_sql)
            }

    def _find_workbook_by_name(self, workbook_name: str) -> Optional[Dict]:
        """
        Find a workbook by name via Metadata API with fuzzy fallback.
        Tries exact match first, then falls back to REST API content_url match.
        """
        wb_fields = """
            id
            name
            projectName
            owner { name }
            embeddedDatasources {
                name
                upstreamTables {
                    id
                    name
                    schema
                    database { name connectionType }
                }
            }
            upstreamDatasources {
                id
                name
                hasExtracts
                projectName
            }
        """
        
        # Try 1: exact name match
        wb_query = f"""
        query GetWorkbookInfo($name: String!) {{
            workbooks(filter: {{name: $name}}) {{
                {wb_fields}
            }}
        }}
        """
        wb_data = self._execute_metadata_query(wb_query, {"name": workbook_name})
        workbooks = wb_data.get("workbooks", [])
        if workbooks:
            return workbooks[0]
        
        # Try 2: match via REST API content_url (handles CamelCase slugs)
        try:
            with self.connection() as server:
                real_name = None
                for workbook in TSC.Pager(server.workbooks):
                    if workbook.content_url and workbook.content_url.lower() == workbook_name.lower():
                        real_name = workbook.name
                        break
                    if workbook.name and workbook.name.replace(" ", "").lower() == workbook_name.replace(" ", "").lower():
                        real_name = workbook.name
                        break
            
            if real_name:
                wb_data = self._execute_metadata_query(wb_query, {"name": real_name})
                workbooks = wb_data.get("workbooks", [])
                if workbooks:
                    return workbooks[0]
        except Exception as e:
            logger.warning(f"Fallback workbook search failed: {e}")
        
        return None

    def get_custom_sql_for_workbook(self, workbook_name: str) -> Dict[str, Any]:
        """
        Get custom SQL for a workbook using the Metadata API only (no download).
        Also returns published datasource info if no custom SQL is found.
        
        Args:
            workbook_name: Workbook name (exact or content_url slug)
            
        Returns:
            Dict with workbook info, custom SQL queries, and/or published datasources
        """
        # Step 1: Find workbook (with fuzzy matching)
        wb = self._find_workbook_by_name(workbook_name)
        
        if not wb:
            return {"found": False, "name": workbook_name}
        
        wb_meta_id = wb["id"]
        
        # Step 2: Query ALL customSQLTables and filter by this workbook
        sql_query = """
        {
            customSQLTables {
                id
                name
                query
                database { name connectionType }
                columns { name }
                downstreamWorkbooks { id name }
                downstreamDatasources { name }
                downstreamSheets { name }
            }
        }
        """
        sql_data = self._execute_metadata_query(sql_query)
        all_sql_tables = sql_data.get("customSQLTables", [])
        
        # Filter to this workbook
        relevant_sql = []
        for t in all_sql_tables:
            wbs = t.get("downstreamWorkbooks") or []
            for dwb in wbs:
                if dwb.get("id") == wb_meta_id or dwb.get("name") == wb.get("name"):
                    # Extract source tables from SQL
                    query_text = t.get("query", "")
                    source_tables = []
                    table_patterns = [
                        r'from\s+([a-zA-Z_][a-zA-Z0-9_]*\.[a-zA-Z_][a-zA-Z0-9_]*)',
                        r'join\s+([a-zA-Z_][a-zA-Z0-9_]*\.[a-zA-Z_][a-zA-Z0-9_]*)',
                    ]
                    for pattern in table_patterns:
                        matches = re.findall(pattern, query_text, re.IGNORECASE)
                        source_tables.extend(matches)
                    
                    relevant_sql.append({
                        "name": t.get("name"),
                        "query": query_text,
                        "database": t.get("database", {}).get("name"),
                        "connection_type": t.get("database", {}).get("connectionType"),
                        "columns": [c.get("name") for c in (t.get("columns") or [])],
                        "sheets": [s.get("name") for s in (t.get("downstreamSheets") or [])],
                        "datasources": [d.get("name") for d in (t.get("downstreamDatasources") or [])],
                        "source_tables": list(set(source_tables))
                    })
                    break
        
        # Published datasources
        pub_datasources = []
        for ds in wb.get("upstreamDatasources", []):
            pub_datasources.append({
                "id": ds.get("id"),
                "name": ds.get("name"),
                "has_extracts": ds.get("hasExtracts", False),
                "project_name": ds.get("projectName")
            })
        
        # Embedded datasource upstream tables
        embedded_tables = []
        for eds in wb.get("embeddedDatasources", []):
            for tbl in eds.get("upstreamTables", []):
                db = tbl.get("database", {})
                embedded_tables.append({
                    "datasource": eds.get("name"),
                    "table": tbl.get("name"),
                    "schema": tbl.get("schema"),
                    "database": db.get("name"),
                    "connection_type": db.get("connectionType")
                })
        
        return {
            "found": True,
            "workbook_name": wb.get("name"),
            "project": wb.get("projectName"),
            "owner": (wb.get("owner") or {}).get("name"),
            "custom_sql": relevant_sql,
            "published_datasources": pub_datasources,
            "embedded_tables": embedded_tables,
            "has_custom_sql": len(relevant_sql) > 0
        }

    def get_custom_sql_from_url(self, url: str) -> Dict[str, Any]:
        """
        Get custom SQL for a dashboard given its Tableau URL.
        Works by resolving URL -> workbook name -> custom SQL via Metadata API.
        No TWB download needed.
        
        Args:
            url: Tableau URL (any format: #/views/, /authoring/, etc.)
            
        Returns:
            Dict with workbook info and custom SQL
        """
        workbook_slug = None
        view_slug = None
        
        patterns = [
            r'/#/views/([^/]+)/([^#?]+)',
            r'/views/([^/]+)/([^#?]+)',
            r'/authoring/([^/]+)/([^#?]+)',
        ]
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                workbook_slug = match.group(1)
                view_slug = match.group(2)
                break
        
        if not workbook_slug:
            return {"found": False, "error": f"Could not parse URL: {url}"}
        
        # Find workbook by content_url slug
        with self.connection() as server:
            target_workbook = None
            for workbook in TSC.Pager(server.workbooks):
                if workbook.content_url and workbook.content_url.lower() == workbook_slug.lower():
                    target_workbook = workbook
                    break
            
            if not target_workbook:
                return {"found": False, "error": f"Workbook not found for slug: {workbook_slug}"}
            
            workbook_name = target_workbook.name
        
        # Now use the name-based method
        result = self.get_custom_sql_for_workbook(workbook_name)
        if result.get("found"):
            result["url"] = url
            result["view_slug"] = view_slug
        return result

    def get_dashboard_custom_sql_from_url(self, url: str) -> Dict[str, Any]:
        """Get all custom SQL queries for a dashboard from its URL (legacy method)."""
        
        patterns = [
            r'/authoring/([^/]+)/([^#?]+)',
            r'/#/views/([^/]+)/([^#?]+)',
            r'/views/([^/]+)/([^#?]+)',
        ]
        
        workbook_slug = None
        view_slug = None
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                workbook_slug = match.group(1)
                view_slug = match.group(2)
                break
        
        if not workbook_slug or not view_slug:
            return {"found": False, "error": f"Could not parse URL: {url}"}
        
        with self.connection() as server:
            target_view = None
            target_workbook = None
            
            for view in TSC.Pager(server.views):
                if view.content_url and workbook_slug in view.content_url:
                    if view_slug.lower().replace("-", "") in view.content_url.lower().replace("-", ""):
                        target_view = view
                        target_workbook = server.workbooks.get_by_id(view.workbook_id)
                        break
            
            if not target_view or not target_workbook:
                return {
                    "found": False, 
                    "error": f"View not found for URL slug: {workbook_slug}/{view_slug}"
                }
            
            workbook_name = target_workbook.name
            view_name = target_view.name
            auth_token = server.auth_token
            
            dashboard_query = """
            query GetDashboards {
                dashboards {
                    id name luid
                    sheets { name }
                    workbook { name luid }
                    upstreamDatasources { name }
                }
            }
            """
            
            headers = {
                "Content-Type": "application/json",
                "X-Tableau-Auth": auth_token
            }
            
            response = requests.post(
                self._get_metadata_api_url(),
                json={"query": dashboard_query},
                headers=headers,
                verify=self.config.verify_ssl
            )
            
            if response.status_code != 200:
                return {"found": False, "error": f"Metadata API error: {response.status_code}"}
            
            dashboard_result = response.json().get("data", {})
            
            target_dashboard = None
            dashboard_sheets = []
            dashboard_datasources = []
            
            for dash in dashboard_result.get("dashboards", []):
                wb = dash.get("workbook") or {}
                if wb.get("name") == workbook_name:
                    dash_name = dash.get("name", "")
                    if (view_name.lower().replace(" ", "") in dash_name.lower().replace(" ", "") or
                        dash_name.lower().replace(" ", "") in view_name.lower().replace(" ", "")):
                        target_dashboard = dash
                        dashboard_sheets = [s.get("name") for s in (dash.get("sheets") or [])]
                        dashboard_datasources = [ds.get("name") for ds in (dash.get("upstreamDatasources") or [])]
                        break
            
            custom_sql_query = """
            query GetCustomSQLTables {
                customSQLTables {
                    id name query
                    columns { name }
                    downstreamSheets { name }
                    downstreamDashboards { name }
                    downstreamWorkbooks { name }
                }
            }
            """
            
            response = requests.post(
                self._get_metadata_api_url(),
                json={"query": custom_sql_query},
                headers=headers,
                verify=self.config.verify_ssl
            )
            
            if response.status_code != 200:
                return {"found": False, "error": f"CustomSQL query error: {response.status_code}"}
            
            custom_sql_result = response.json().get("data", {})
            
            relevant_sql = []
            for table in custom_sql_result.get("customSQLTables", []):
                downstream_wbs = [wb.get("name", "") for wb in (table.get("downstreamWorkbooks") or [])]
                downstream_sheets = [s.get("name", "") for s in (table.get("downstreamSheets") or [])]
                downstream_dashes = [d.get("name", "") for d in (table.get("downstreamDashboards") or [])]
                
                if workbook_name in downstream_wbs:
                    all_names = downstream_sheets + downstream_dashes
                    
                    is_relevant = False
                    if target_dashboard:
                        dash_name = target_dashboard.get("name", "")
                        if dash_name in downstream_dashes:
                            is_relevant = True
                        for sheet in dashboard_sheets:
                            if sheet in downstream_sheets:
                                is_relevant = True
                                break
                    
                    if not is_relevant:
                        for name in all_names:
                            if (view_name.lower().replace(" ", "") in name.lower().replace(" ", "") or
                                name.lower().replace(" ", "") in view_name.lower().replace(" ", "")):
                                is_relevant = True
                                break
                    
                    if is_relevant:
                        query_text = table.get("query", "")
                        source_tables = []
                        table_patterns = [
                            r'from\s+([a-zA-Z_][a-zA-Z0-9_]*\.[a-zA-Z_][a-zA-Z0-9_]*)',
                            r'join\s+([a-zA-Z_][a-zA-Z0-9_]*\.[a-zA-Z_][a-zA-Z0-9_]*)',
                        ]
                        for pattern in table_patterns:
                            matches = re.findall(pattern, query_text, re.IGNORECASE)
                            source_tables.extend(matches)
                        
                        relevant_sql.append({
                            "sheets": downstream_sheets,
                            "dashboards": downstream_dashes,
                            "columns": [c.get("name") for c in (table.get("columns") or [])],
                            "query": query_text,
                            "source_tables": list(set(source_tables))
                        })
            
            return {
                "found": True,
                "url": url,
                "workbook_name": workbook_name,
                "workbook_content_url": target_workbook.content_url,
                "view_name": view_name,
                "project": target_workbook.project_name,
                "dashboard_name": target_dashboard.get("name") if target_dashboard else view_name,
                "sheets": dashboard_sheets,
                "datasources": dashboard_datasources,
                "custom_sql": relevant_sql,
                "sql_count": len(relevant_sql)
            }


# Global client instance
_client: Optional[TableauClient] = None


def get_client() -> TableauClient:
    """Get or create the global client instance."""
    global _client
    if _client is None:
        _client = TableauClient()
    return _client
