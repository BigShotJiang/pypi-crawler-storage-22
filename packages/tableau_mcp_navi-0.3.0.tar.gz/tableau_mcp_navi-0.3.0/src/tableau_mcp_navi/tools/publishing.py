"""
Publishing MCP tools for Tableau Server.
Allows publishing workbooks and datasources to Tableau Server.
"""

import logging
from typing import Optional, List
from mcp.server.fastmcp import FastMCP

from ..client import get_client, TableauClientError
from ..analytics import track_tool_call

logger = logging.getLogger("tableau-mcp.tools.publishing")


def register_publishing_tools(mcp: FastMCP) -> None:
    """Register all publishing related tools with the MCP server."""
    
    @mcp.tool()
    @track_tool_call("publish_workbook")
    def publish_workbook(
        file_path: str,
        project_id: str,
        name: Optional[str] = None,
        show_tabs: bool = True,
        overwrite: bool = False
    ) -> str:
        """
        Publish a workbook (.twb or .twbx) to Tableau Server.
        
        Args:
            file_path: Local path to the workbook file (.twb or .twbx)
            project_id: ID of the project to publish to (use list_projects to find)
            name: Name for the workbook (defaults to filename)
            show_tabs: Whether to show sheet tabs in the workbook
            overwrite: Whether to overwrite if workbook already exists
        
        Returns:
            Success message with workbook URL or error message
        """
        try:
            client = get_client()
            result = client.publish_workbook(
                file_path=file_path,
                project_id=project_id,
                name=name,
                show_tabs=show_tabs,
                overwrite=overwrite
            )
            
            if result.get("success"):
                return f"""## ✅ Workbook Published Successfully

**Name:** {result['workbook_name']}
**ID:** `{result['workbook_id']}`
**Project ID:** `{result['project_id']}`
**Content URL:** `{result['content_url']}`

### 🔗 View Workbook
{result['webpage_url']}
"""
            else:
                error = result.get("error", "Unknown error")
                code = result.get("code", "")
                return f"""## ❌ Failed to Publish Workbook

**Error:** {error}
{f"**Code:** {code}" if code else ""}

### Troubleshooting:
- Verify the file exists: `{file_path}`
- Check project_id is correct (use `list_projects`)
- If workbook exists, set `overwrite=True`
- Ensure you have publish permissions
"""
        except TableauClientError as e:
            return f"❌ Tableau API Error: {str(e)}"
        except Exception as e:
            logger.exception("Unexpected error in publish_workbook")
            return f"❌ Unexpected error: {str(e)}"
    
    @mcp.tool()
    @track_tool_call("publish_datasource")
    def publish_datasource(
        file_path: str,
        project_id: str,
        name: Optional[str] = None,
        overwrite: bool = False
    ) -> str:
        """
        Publish a datasource (.tds, .tdsx, or .hyper) to Tableau Server.
        
        Args:
            file_path: Local path to the datasource file
            project_id: ID of the project to publish to (use list_projects to find)
            name: Name for the datasource (defaults to filename)
            overwrite: Whether to overwrite if datasource already exists
        
        Returns:
            Success message with datasource URL or error message
        """
        try:
            client = get_client()
            result = client.publish_datasource(
                file_path=file_path,
                project_id=project_id,
                name=name,
                overwrite=overwrite
            )
            
            if result.get("success"):
                return f"""## ✅ Datasource Published Successfully

**Name:** {result['datasource_name']}
**ID:** `{result['datasource_id']}`
**Project ID:** `{result['project_id']}`
**Content URL:** `{result['content_url']}`

### 🔗 View Datasource
{result['webpage_url']}
"""
            else:
                error = result.get("error", "Unknown error")
                code = result.get("code", "")
                return f"""## ❌ Failed to Publish Datasource

**Error:** {error}
{f"**Code:** {code}" if code else ""}

### Troubleshooting:
- Verify the file exists: `{file_path}`
- Check project_id is correct (use `list_projects`)
- If datasource exists, set `overwrite=True`
- Ensure you have publish permissions
"""
        except TableauClientError as e:
            return f"❌ Tableau API Error: {str(e)}"
        except Exception as e:
            logger.exception("Unexpected error in publish_datasource")
            return f"❌ Unexpected error: {str(e)}"
    
    @mcp.tool()
    @track_tool_call("list_projects_for_publishing")
    def list_projects_for_publishing() -> str:
        """
        List all projects available for publishing workbooks and datasources.
        Returns project IDs needed for publish_workbook and publish_datasource.
        
        Returns:
            Table of projects with IDs, names, and descriptions
        """
        try:
            client = get_client()
            projects = client.list_projects()
            
            if not projects:
                return "⚠️ No projects found. You may need admin permissions to view projects."
            
            result = ["## 📁 Projects Available for Publishing\n"]
            result.append("| Project Name | Project ID | Description |")
            result.append("| --- | --- | --- |")
            
            for project in sorted(projects, key=lambda p: p.name or ""):
                name = project.name or "Unnamed"
                project_id = project.id
                desc = (project.description or "")[:50]
                if len(project.description or "") > 50:
                    desc += "..."
                result.append(f"| {name} | `{project_id}` | {desc} |")
            
            result.append(f"\n**Total:** {len(projects)} projects")
            result.append("\n### Usage Example")
            result.append("```")
            result.append(f'publish_workbook(file_path="/path/to/workbook.twbx", project_id="{projects[0].id}")')
            result.append("```")
            
            return "\n".join(result)
            
        except TableauClientError as e:
            return f"❌ Tableau API Error: {str(e)}"
        except Exception as e:
            logger.exception("Unexpected error in list_projects_for_publishing")
            return f"❌ Unexpected error: {str(e)}"
