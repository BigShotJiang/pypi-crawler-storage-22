import ast
import io
import json
import os
import re

import pandas as pd
import yaml

from tableconv.adapters.df.base import Adapter, register_adapter
from tableconv.adapters.df.file_adapter_mixin import FileAdapterMixin
from tableconv.exceptions import IncapableDestinationError
from tableconv.uri import parse_uri

DEFAULT_SEPARATOR = {"csa": ",", "list": "\n", "tsa": "\t", "mdlist": "\n", "unicodelist": "\n"}
DEFAULT_PREFIX = {"csa": "", "list": "", "tsa": "", "mdlist": "*", "unicodelist": "•"}


@register_adapter(["list", "csa", "tsa", "jsonarray", "pythonlist", "pylist", "mdlist", "unicodelist", "yamlsequence"])
class TextArrayAdapter(FileAdapterMixin, Adapter):

    @staticmethod
    def get_example_url(scheme):
        return f"{scheme}:-"

    @staticmethod
    def load_text_data(scheme, data, params):
        # Parameter parsing
        if scheme in ("csa", "tsa", "list", "mdlist", "unicodelist"):
            prefix = params.get("prefix", params.get("bullet", DEFAULT_PREFIX[scheme]))
            separator = params.get("separator", params.get("sep", DEFAULT_SEPARATOR[scheme]))
            strip_whitespace = params.get("strip_whitespace", True)
            if separator == "\\t":
                separator = "\t"
            if separator == "\\n":
                separator = "\n"
        # Data processing
        data = data.strip()
        if scheme == "jsonarray":
            array = [(item,) for item in json.loads(data)]
        elif scheme in ("pythonlist", "pylist"):
            array = [(item,) for item in ast.literal_eval(data)]
        elif scheme == "yamlsequence":
            data_stream = io.StringIO(data)
            array = [(item,) for item in yaml.safe_load(data_stream)]
        elif scheme in ("csa", "tsa", "list", "mdlist", "unicodelist"):
            if separator[-1] == "\n" and data[-1] == "\n":
                data = data[:-1]
            array = ((item,) for item in data.split(separator))
            if strip_whitespace:
                array = ((item[0].strip(),) for item in array)
            if prefix:
                array = ((item[0].removeprefix(prefix).lstrip(),) for item in array)
        else:
            raise AssertionError()
        return pd.DataFrame.from_records(list(array), columns=["value"])

    @staticmethod
    def dump_text_data(df, scheme, params):
        # Parameter parsing
        if scheme in ("csa", "list", "tsa", "mdlist", "unicodelist"):
            prefix = params.get("prefix", params.get("bullet", DEFAULT_PREFIX[scheme]))
            separator = params.get("separator", params.get("sep", DEFAULT_SEPARATOR[scheme]))
        # Data processing
        if len(df.columns) > 1:
            raise IncapableDestinationError(
                f"Table has multiple columns; unable to condense into an array for {scheme}"
            )
        array = list(df[df.columns[0]].values)
        serialized_array = [str(item) for item in array]
        if scheme == "jsonarray":
            return json.dumps(array)
        elif scheme in ("pythonlist", "pylist"):
            return repr(array)
        elif scheme == "yamlsequence":
            return yaml.safe_dump(serialized_array)
        elif scheme in ("csa", "list", "tsa", "mdlist", "unicodelist"):
            separator_label = f'"{repr(separator)}"'
            if any(separator in item for item in serialized_array):
                raise IncapableDestinationError(
                    f"Cannot write as {scheme}, one or more values contain a {separator_label}"
                )
            if prefix:
                serialized_array = [prefix + " " + item for item in serialized_array]
            return separator.join(serialized_array)
        else:
            raise AssertionError()


@register_adapter(["file_per_row", "row_per_file"])
class FilePerRowOutputAdapter(Adapter):
    """
    Very experimental adapter. Definitely not proper. I'm struggling to figure out a good product design / story for
    solving this specific usecase. What other tool/script can we pipe tableconv output/input through to handle this
    usecase? How can we inject a custom mini python script to handle this usecase? etc. What is
    the composable solution?
    """

    @staticmethod
    def get_example_url(scheme):
        return f"{scheme}:///tmp/example (each file is considered a (filename,value) record)"

    @classmethod
    def load(cls, uri: str, query: str | None) -> pd.DataFrame:
        parsed_uri = parse_uri(uri)
        path = parsed_uri.path
        if not os.path.exists(path):
            raise ValueError(f"Unable to load {path}, path does not exist")
        filenames = os.listdir(path)
        if not filenames:
            raise ValueError(f"Unable to load {path}, no files in {path}")
        data = []
        for filename in os.listdir(path):
            with open(os.path.join(path, filename)) as f:
                value = f.read()
            data.append({"filename": filename, "value": value})
        df = pd.DataFrame.from_records(data)
        return cls._query_in_memory(df, query)

    @classmethod
    def dump(cls, df, uri: str):
        parsed_uri = parse_uri(uri)
        if set(df.columns) != set(["filename", "value"]):
            raise IncapableDestinationError('Table must have only two columns: "filename" and "value".')

        path = parsed_uri.path
        if parsed_uri.authority:
            if path:
                path = os.path.join(parsed_uri.authority, path)
            else:
                path = parsed_uri.authority

        if_exists = parsed_uri.query.get("if_exists", "fail")
        if if_exists not in ("fail", "replace", "append"):
            raise ValueError(f'if_exists must be "fail", "replace", or "append", got "{if_exists}"')

        if os.path.exists(path):
            if not os.path.isdir(path):
                raise IncapableDestinationError(
                    f'Destination must be a folder. "{os.path.abspath(path)}" is a pre-existing file.'
                )
            if if_exists == "fail" and os.listdir(path):
                raise IncapableDestinationError(
                    f'Destination folder must be empty (when if_exists=fail). "{os.path.abspath(path)}" is not empty.'
                )
            if if_exists == "replace":
                for existing_file in os.listdir(path):
                    os.remove(os.path.join(path, existing_file))

        os.makedirs(path, exist_ok=True)
        data = df.to_dict(orient="records")
        for record in data:
            filename = str(record["filename"])
            match = re.search(r"[\0/]|^\.\.?$", filename)
            if match:
                raise IncapableDestinationError(
                    "At least one filename contains forbidden characters, please slugify them using SQL. Example errant"
                    f' filename: "{filename}". (Violating part: "{match.group(0)}")'
                )
            if filename == "":
                raise IncapableDestinationError(
                    "One or more of the specified filenames is empty, please provide non-empty filenames."
                )

        mode = "a" if if_exists == "append" else "w"
        for record in data:
            filename = str(record["filename"])
            with open(os.path.join(path, filename), mode) as f:
                f.write(record["value"])
