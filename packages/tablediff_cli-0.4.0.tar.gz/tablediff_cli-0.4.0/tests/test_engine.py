"""
Unit tests for tablediff/engine.py functions.

Tests include:
- get_schema: Verify schema retrieval from DuckDB
- query_table: Verify querying with columns and where clause
- table_diff: Verify DiffResult with added/removed/updated rows
- calculate_differences: Verify diff calculation logic
- schema_diff: Verify schema comparison functionality
"""

from reladiff import connect_to_table, diff_tables

from tablediff.engine import (
    calculate_differences,
    get_schema,
    query_table,
    schema_diff,
    table_diff,
)
from tablediff.models import DiffResult, SchemaDiffResult


class TestGetSchema:
    """Tests for get_schema function."""

    def test_get_schema_returns_columns(self, temp_duckdb):
        """Test that get_schema returns the correct column names for a table."""
        schema = get_schema(f"duckdb://{temp_duckdb}", "table_a")

        # Schema should be a dict-like structure with column names
        assert "id" in schema
        assert "name" in schema
        assert "email" in schema
        assert "age" in schema

    def test_get_schema_different_tables(self, temp_duckdb):
        """Test that get_schema works for both tables."""
        schema_a = get_schema(f"duckdb://{temp_duckdb}", "table_a")
        schema_b = get_schema(f"duckdb://{temp_duckdb}", "table_b")

        # Both tables should have the same schema
        assert set(schema_a.keys()) == set(schema_b.keys())

    def test_get_schema_with_qualified_name(self, temp_duckdb):
        """Test that get_schema handles qualified table names (schema.table)."""
        # For DuckDB, the default schema is 'main'
        schema = get_schema(f"duckdb://{temp_duckdb}", "main.table_a")

        assert "id" in schema
        assert "name" in schema


class TestQueryTable:
    """Tests for query_table function."""

    def test_query_table_all_columns(self, temp_duckdb):
        """Test querying all columns from a table."""
        columns = ["id", "name", "email", "age"]
        rows = query_table(f"duckdb://{temp_duckdb}", "table_a", columns)

        assert len(rows) == 4
        # Check first row
        assert rows[0][0] == 1  # id
        assert rows[0][1] == "Alice"  # name

    def test_query_table_specific_columns(self, temp_duckdb):
        """Test querying specific columns from a table."""
        columns = ["id", "name"]
        rows = query_table(f"duckdb://{temp_duckdb}", "table_a", columns)

        assert len(rows) == 4
        # Each row should have only 2 columns
        assert len(rows[0]) == 2

    def test_query_table_with_where_clause(self, temp_duckdb):
        """Test querying with a WHERE clause."""
        columns = ["id", "name", "age"]
        rows = query_table(f"duckdb://{temp_duckdb}", "table_a", columns, where="age > 28")

        # Should return 2 rows: Alice (30) and Charlie (35)
        assert len(rows) == 2


class TestCalculateDifferences:
    """Tests for calculate_differences function."""

    def test_calculate_differences_basic(self, temp_duckdb):
        """Test calculate_differences with real output from diff_tables."""
        db_path = f"duckdb://{temp_duckdb}"

        # Create real table segments and diff them
        table_a = connect_to_table(db_path, "table_a", "id")
        table_b = connect_to_table(db_path, "table_b", "id")

        # Get common columns
        schema_a = get_schema(db_path, "table_a")
        schema_b = get_schema(db_path, "table_b")
        cols_a = list(schema_a)
        cols_b = list(schema_b)
        common_cols_set = set(cols_a).intersection(cols_b)
        common_cols = [col for col in cols_b if col in common_cols_set]

        # Perform the actual diff
        diffing = diff_tables(table_a, table_b, key_columns=("id",), extra_columns=tuple(common_cols))

        # Calculate differences
        diff_by_key, diff_by_sign = calculate_differences(diffing)

        # Check diff_by_key structure
        # Note: Keys are returned as strings from reladiff
        assert ("5",) in diff_by_key  # Added
        assert ("3",) in diff_by_key  # Removed
        assert ("2",) in diff_by_key  # Updated
        assert ("4",) in diff_by_key  # Updated

        # Check diff_by_sign
        assert ("5",) in diff_by_sign["+"]  # Added
        assert ("3",) in diff_by_sign["-"]  # Removed
        assert ("2",) in diff_by_sign["!"]  # Updated
        assert ("4",) in diff_by_sign["!"]  # Updated


class TestTableDiff:
    """Tests for table_diff function."""

    def test_table_diff_basic(self, temp_duckdb):
        """Test table_diff with two tables having added/removed/updated rows."""
        db_path = f"duckdb://{temp_duckdb}"

        result = table_diff(db_path, db_path, "table_a", "table_b", "id")

        # Check result type
        assert isinstance(result, DiffResult)

        # Check table metadata
        assert result.table_a.name == "table_a"
        assert result.table_b.name == "table_b"
        assert result.primary_key == "id"

        # Check column lists
        assert "id" in result.common_columns
        assert "name" in result.common_columns
        assert "email" in result.common_columns

        # Check row counts
        assert result.table_a.rows == 4  # table_a has 4 rows
        assert result.table_b.rows == 4  # table_b has 4 rows

        # Check diff statistics
        # Row 3 is only in A (removed)
        assert result.rows_only_in_a == 1

        # Row 5 is only in B (added)
        assert result.rows_only_in_b == 1

        # Row 1 is unchanged
        assert result.rows_in_both_same == 1

        # Rows 2 and 4 are updated (different email/age)
        assert result.rows_in_both_diff == 2

    def test_table_diff_common_columns(self, temp_duckdb):
        """Test that table_diff correctly identifies common columns."""
        db_path = f"duckdb://{temp_duckdb}"

        result = table_diff(db_path, db_path, "table_a", "table_b", "id")

        # All columns should be common since both tables have same schema
        assert set(result.common_columns) == {"id", "name", "email", "age"}

    def test_table_diff_diff_by_keys(self, temp_duckdb):
        """Test that diff_by_keys contains the correct mappings."""
        db_path = f"duckdb://{temp_duckdb}"

        result = table_diff(db_path, db_path, "table_a", "table_b", "id")

        # Check diff_by_keys structure
        # Note: Keys are returned as strings from reladiff
        assert ("3",) in result.diff_by_keys  # Removed row
        assert ("5",) in result.diff_by_keys  # Added row
        assert ("2",) in result.diff_by_keys  # Updated row
        assert ("4",) in result.diff_by_keys  # Updated row

    def test_table_diff_diff_by_sign(self, temp_duckdb):
        """Test that diff_by_sign contains the correct groupings."""
        db_path = f"duckdb://{temp_duckdb}"

        result = table_diff(db_path, db_path, "table_a", "table_b", "id")

        # Check diff_by_sign structure
        assert "-" in result.diff_by_sign
        assert "+" in result.diff_by_sign
        assert "!" in result.diff_by_sign

        # Row 3 should be in removed (-)
        # Note: Keys are returned as strings from reladiff
        assert ("3",) in result.diff_by_sign["-"]

        # Row 5 should be in added (+)
        assert ("5",) in result.diff_by_sign["+"]

        # Rows 2 and 4 should be in updated (!)
        assert ("2",) in result.diff_by_sign["!"]
        assert ("4",) in result.diff_by_sign["!"]


class TestSchemaDiff:
    """Tests for schema_diff function."""

    def test_schema_diff_same_schema(self, temp_duckdb):
        """Test schema_diff with two tables having the same schema."""
        db_path = f"duckdb://{temp_duckdb}"

        result = schema_diff(db_path, db_path, "table_a", "table_b")

        # Check result type
        assert isinstance(result, SchemaDiffResult)

        # Check table names
        assert result.table_a == "table_a"
        assert result.table_b == "table_b"

        # Check that all columns are present in both tables
        assert "id" in result.columns
        assert "name" in result.columns
        assert "email" in result.columns
        assert "age" in result.columns

        # All columns should have the same types in both tables
        for _col_name, col_info in result.columns.items():
            assert col_info["table_a"] is not None
            assert col_info["table_b"] is not None
            assert col_info["table_a"] == col_info["table_b"]

    def test_schema_diff_different_columns(self, temp_duckdb):
        """Test schema_diff with tables having different columns."""
        db_path = f"duckdb://{temp_duckdb}"

        # table_c has columns: id, name, email, status
        # table_d has columns: id, name, email, role
        result = schema_diff(db_path, db_path, "table_c", "table_d")

        # Check result type
        assert isinstance(result, SchemaDiffResult)

        # Check that all columns from both tables are present
        assert "id" in result.columns
        assert "name" in result.columns
        assert "email" in result.columns
        assert "status" in result.columns
        assert "role" in result.columns

        # Common columns should have types in both tables
        assert result.columns["id"]["table_a"] is not None
        assert result.columns["id"]["table_b"] is not None
        assert result.columns["name"]["table_a"] is not None
        assert result.columns["name"]["table_b"] is not None
        assert result.columns["email"]["table_a"] is not None
        assert result.columns["email"]["table_b"] is not None

        # status should only be in table_a
        assert result.columns["status"]["table_a"] is not None
        assert result.columns["status"]["table_b"] is None

        # role should only be in table_b
        assert result.columns["role"]["table_a"] is None
        assert result.columns["role"]["table_b"] is not None

    def test_schema_diff_columns_dict_structure(self, temp_duckdb):
        """Test that schema_diff returns correct dictionary structure."""
        db_path = f"duckdb://{temp_duckdb}"

        result = schema_diff(db_path, db_path, "table_c", "table_d")

        # Verify the structure of the columns dictionary
        for _col_name, col_info in result.columns.items():
            assert isinstance(col_info, dict)
            assert "table_a" in col_info
            assert "table_b" in col_info
            # Each value should be either a string (type) or None
            assert isinstance(col_info["table_a"], (str, type(None)))
            assert isinstance(col_info["table_b"], (str, type(None)))
