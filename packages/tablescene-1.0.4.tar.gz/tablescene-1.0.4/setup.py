from setuptools import setup

setup(  name= 'tablescene', 
        version='1.0.4', 
        description='tablescene', 
        packages=['tablescene'],
		author='ops',
		license="Python Script",
        install_requires = ["blessings ~= 1.7"],
        extras_require={
            "dev": [
                "pytest>=3.2",
            ],
        },
    )

