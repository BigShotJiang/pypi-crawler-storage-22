#
# Copyright 2026 Tabs Data Inc.
#

from typing import Literal

MSSQLLoaderSpec = Literal["polars_sqlalchemy", "pandas"]
