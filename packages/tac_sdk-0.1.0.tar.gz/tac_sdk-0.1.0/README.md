# TAC SDK (Python)

Python SDK for TON <-> TAC cross-chain operations.

## ETH <-> TON Bridge Helpers

See the dedicated helper docs: [helpers/README.md](helpers/README.md)

## Installation

```bash
pip install tac-sdk
```

## Quick start

```python
import asyncio
from sdk.tac_sdk import TacSdk
from structs.struct import Network, SDKParams


async def main() -> None:
    sdk = await TacSdk.create(SDKParams(network=Network.TESTNET))
    token = await sdk.getFT("EQBLi0v_y-KiLlT1VzQJmmMbaoZnLcMAHrIEmzur13dwOmM1")
    print(token.address)


asyncio.run(main())
```
