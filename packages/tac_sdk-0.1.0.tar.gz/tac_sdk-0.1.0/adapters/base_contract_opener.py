from __future__ import annotations

import asyncio
import base64
import math
from typing import Any, Callable, Literal

from pytoniq_core.boc.address import Address as TonAddress
from pytoniq_core.boc.address import ExternalAddress
from pytoniq_core.tlb.transaction import Transaction

from errors.instances import tx_finalization_error
from interfaces.contract_opener import ContractOpener
from interfaces.i_logger import ILogger
from sdk.consts import (
    DEFAULT_FIND_TX_ARCHIVAL,
    DEFAULT_FIND_TX_LIMIT,
    DEFAULT_FIND_TX_MAX_DEPTH,
    DEFAULT_MAX_SCANNED_TRANSACTIONS,
    DEFAULT_WAIT_FOR_ROOT_TRANSACTION,
    DEFAULT_WAIT_FOR_ROOT_TRANSACTION_RETRY_DELAY_MS,
    DEFAULT_WAIT_FOR_ROOT_TRANSACTION_TIMEOUT_MS,
    IGNORE_MSG_VALUE_1_NANO,
    IGNORE_OPCODE,
)
from sdk.utils import get_normalized_ext_message_hash, normalize_hash_to_base64
from structs.internal_struct import TransactionDepth
from structs.struct import (
    AddressInformation,
    GetTransactionsOptions,
    TrackTransactionTreeParams,
    TrackTransactionTreeResult,
    TransactionValidationError,
)


class BaseContractOpener(ContractOpener):
    def __init__(self, logger: ILogger | None = None) -> None:
        self.logger = logger

    def setLogger(self, logger: ILogger) -> None:  # noqa: N802
        if self.logger is None:
            self.logger = logger

    def open(self, src):
        raise NotImplementedError("base_contract_opener.open requires implementation")

    async def getContractState(self, address):
        raise NotImplementedError("base_contract_opener.getContractState requires implementation")

    async def getTransactions(self, address, opts: GetTransactionsOptions) -> list[Transaction]:
        raise NotImplementedError("base_contract_opener.getTransactions requires implementation")

    async def getAddressInformation(self, address) -> AddressInformation:
        raise NotImplementedError("base_contract_opener.getAddressInformation requires implementation")

    async def getConfig(self) -> str:
        raise NotImplementedError("base_contract_opener.getConfig requires implementation")

    async def raw_send_message(self, boc: bytes) -> Any:
        _ = boc
        raise RuntimeError("raw_send_message is not supported by this opener")

    async def closeConnections(self) -> None:
        return None

    async def scanTransactionHistory(
        self,
        address: Any,
        opts: GetTransactionsOptions | None,
        predicate: Callable[[Transaction], bool],
    ) -> Transaction | None:
        hash_raw = opts.get("hash") if opts else None
        to_lt_raw = opts.get("to_lt") if opts else None
        timeout_raw = opts.get("timeoutMs") if opts else None
        retry_delay_raw = opts.get("retryDelayMs") if opts else None
        limit = int(opts.get("limit", DEFAULT_FIND_TX_LIMIT) if opts else DEFAULT_FIND_TX_LIMIT)
        inclusive = bool(opts.get("inclusive", True) if opts else True)
        to_lt = int(str(to_lt_raw)) if to_lt_raw is not None else None
        current_lt = str(opts.get("lt")) if opts and opts.get("lt") is not None else None
        current_hash = normalize_hash_to_base64(hash_raw) if hash_raw else None
        seen_cursors: set[str] = set()
        scanned_transactions = 0
        max_scanned_transactions = int(
            opts.get("maxScannedTransactions", DEFAULT_MAX_SCANNED_TRANSACTIONS)
            if opts
            else DEFAULT_MAX_SCANNED_TRANSACTIONS
        )

        while True:
            request_opts: GetTransactionsOptions = {
                "limit": limit,
                "archival": bool(opts.get("archival", DEFAULT_FIND_TX_ARCHIVAL) if opts else DEFAULT_FIND_TX_ARCHIVAL),
                "inclusive": inclusive,
            }
            if current_lt:
                request_opts["lt"] = str(current_lt)
            if current_hash:
                request_opts["hash"] = str(current_hash)
            if to_lt_raw is not None:
                request_opts["to_lt"] = str(to_lt_raw)
            if timeout_raw is not None:
                request_opts["timeoutMs"] = int(timeout_raw)
            if retry_delay_raw is not None:
                request_opts["retryDelayMs"] = int(retry_delay_raw)

            batch = await self.getTransactions(address, request_opts)
            if not batch:
                break

            start_index = 0
            first_tx = batch[0]
            first_tx_hash = self._tx_hash_b64(first_tx)
            first_tx_lt = self._tx_lt(first_tx)
            first_tx_matches_cursor = (
                current_lt is not None
                and current_hash is not None
                and first_tx_lt == str(current_lt)
                and first_tx_hash == str(current_hash)
            )

            if first_tx_matches_cursor:
                start_index = 1
                if len(batch) == 1:
                    first_prev_lt = self._tx_prev_lt(first_tx)
                    if first_prev_lt == 0:
                        break
                    next_lt = str(first_prev_lt)
                    next_hash = self._tx_prev_hash_b64(first_tx)
                    if current_lt is not None and int(next_lt) >= int(str(current_lt)):
                        break
                    cursor_key = f"{next_lt}:{next_hash}"
                    if cursor_key in seen_cursors:
                        break
                    seen_cursors.add(cursor_key)
                    current_lt = next_lt
                    current_hash = next_hash
                    continue

            for index in range(start_index, len(batch)):
                tx = batch[index]
                scanned_transactions += 1
                if scanned_transactions > max_scanned_transactions:
                    if self.logger:
                        self.logger.debug(
                            f"Scan limit reached ({max_scanned_transactions} transactions), stopping history scan"
                        )
                    return None
                if predicate(tx):
                    return tx

            oldest_tx = batch[-1]
            oldest_prev_lt = self._tx_prev_lt(oldest_tx)
            if oldest_prev_lt == 0:
                break
            if to_lt is not None:
                oldest_lt_int = int(self._tx_lt(oldest_tx))
                if inclusive:
                    if oldest_lt_int <= to_lt:
                        break
                elif oldest_lt_int < to_lt:
                    break

            next_lt = self._tx_lt(oldest_tx)
            next_hash = self._tx_hash_b64(oldest_tx)
            if current_lt is not None and int(next_lt) >= int(str(current_lt)):
                break
            cursor_key = f"{next_lt}:{next_hash}"
            if cursor_key in seen_cursors:
                break
            seen_cursors.add(cursor_key)
            current_lt = next_lt
            current_hash = next_hash

        return None

    async def getTransactionByHash(
        self, address: Any, hash_value: str, opts: GetTransactionsOptions | None = None
    ) -> Transaction | None:
        target = normalize_hash_to_base64(hash_value)

        def _matches(tx: Transaction) -> bool:
            if self._tx_hash_b64(tx) == target:
                return True

            in_msg = tx.in_msg
            if in_msg is not None:
                if in_msg.is_external:
                    try:
                        if get_normalized_ext_message_hash(in_msg) == target:
                            return True
                        if base64.b64encode(in_msg.serialize().hash).decode("utf-8") == target:
                            return True
                    except Exception:
                        pass
                elif in_msg.is_internal:
                    msg_hash = base64.b64encode(in_msg.serialize().hash).decode("utf-8")
                    if msg_hash == target:
                        return True

            for out_msg in tx.out_msgs:
                if base64.b64encode(out_msg.serialize().hash).decode("utf-8") == target:
                    return True
            return False

        return await self.scanTransactionHistory(address, opts, _matches)

    async def getTransactionByTxHash(
        self, address: Any, tx_hash: str, opts: GetTransactionsOptions | None = None
    ) -> Transaction | None:
        target = normalize_hash_to_base64(tx_hash)
        return await self.scanTransactionHistory(address, opts, lambda tx: self._tx_hash_b64(tx) == target)

    async def getTransactionByInMsgHash(
        self, address: Any, msg_hash: str, opts: GetTransactionsOptions | None = None
    ) -> Transaction | None:
        target = normalize_hash_to_base64(msg_hash)

        def _matches(tx: Transaction) -> bool:
            in_msg = tx.in_msg
            if in_msg is None:
                return False
            if in_msg.is_external:
                try:
                    if get_normalized_ext_message_hash(in_msg) == target:
                        return True
                    if base64.b64encode(in_msg.serialize().hash).decode("utf-8") == target:
                        return True
                    return False
                except Exception:
                    return False
            if in_msg.is_internal:
                msg_hash_b64 = base64.b64encode(in_msg.serialize().hash).decode("utf-8")
                return msg_hash_b64 == target
            return False

        return await self.scanTransactionHistory(address, opts, _matches)

    async def getTransactionByOutMsgHash(
        self, address: Any, msg_hash: str, opts: GetTransactionsOptions | None = None
    ) -> Transaction | None:
        target = normalize_hash_to_base64(msg_hash)

        def _matches(tx: Transaction) -> bool:
            for out_msg in tx.out_msgs:
                msg_hash_b64 = base64.b64encode(out_msg.serialize().hash).decode("utf-8")
                if msg_hash_b64 == target:
                    return True
            return False

        return await self.scanTransactionHistory(address, opts, _matches)

    async def getAdjacentTransactions(
        self, address: Any, hash_value: str, opts: GetTransactionsOptions | None = None
    ) -> list[Transaction]:
        root = await self.getTransactionByHash(address, hash_value, opts)
        if not root:
            return []
        adjacent: list[Transaction] = []

        for msg in root.out_msgs:
            dst = msg.info.dest
            if not dst or isinstance(dst, ExternalAddress):
                continue
            msg_hash = base64.b64encode(msg.serialize().hash).decode("utf-8")
            tx = await self.getTransactionByInMsgHash(dst, msg_hash, opts)
            if tx:
                adjacent.append(tx)

        if root.in_msg and root.in_msg.is_internal:
            msg_hash = base64.b64encode(root.in_msg.serialize().hash).decode("utf-8")
            tx = await self.getTransactionByOutMsgHash(root.in_msg.info.src, msg_hash, opts)
            if tx:
                adjacent.append(tx)

        return adjacent

    def validateTransactionWithResult(
        self, tx: Transaction, ignore_opcode_list: list[int]
    ) -> TransactionValidationError | None:
        if getattr(tx.description, "type_", "") != "ordinary":
            return None

        descr = tx.description
        aborted = getattr(descr, "aborted", False)
        compute_ph = getattr(descr, "compute_ph", None)
        action_ph = getattr(descr, "action", None)

        tx_hash = self._tx_hash_b64(tx)
        exit_code: int | Literal["N/A"] = "N/A"
        if compute_ph and compute_ph.type_ != "skipped":
            exit_code = int(compute_ph.exit_code)
        result_code: int | Literal["N/A"] = "N/A"
        if action_ph:
            result_code = int(action_ph.result_code)

        if aborted:
            return self._build_validation_error(tx_hash, exit_code, result_code, "aborted")

        if not compute_ph:
            return self._build_validation_error(tx_hash, exit_code, result_code, "compute_phase_missing")

        if compute_ph.type_ != "skipped" and (not compute_ph.success or compute_ph.exit_code != 0):
            return self._build_validation_error(tx_hash, exit_code, result_code, "compute_phase_failed")

        if action_ph and (not action_ph.success or action_ph.result_code != 0):
            return self._build_validation_error(tx_hash, exit_code, result_code, "action_phase_failed")

        if not tx.in_msg:
            return None

        if tx.in_msg.is_internal and getattr(tx.in_msg.info, "value_coins", 0) == IGNORE_MSG_VALUE_1_NANO:
            return None

        body_slice = tx.in_msg.body.begin_parse()
        if body_slice.remaining_bits >= 32:
            opcode = body_slice.load_uint(32)
            if opcode in ignore_opcode_list:
                return None

        return None

    async def findTransactionByHashType(
        self,
        address: Any,
        hash_value: str,
        hash_type: Literal["unknown", "in", "out"] | None,
        opts: GetTransactionsOptions,
    ) -> Transaction | None:
        search_opts: GetTransactionsOptions = {"archival": True, **opts}
        if hash_type == "in":
            return await self.getTransactionByInMsgHash(address, hash_value, search_opts)
        if hash_type == "out":
            return await self.getTransactionByOutMsgHash(address, hash_value, search_opts)
        return await self.getTransactionByHash(address, hash_value, search_opts)

    async def findRootTransactionWithRetry(
        self,
        address: Any,
        hash_value: str,
        hash_type: Literal["unknown", "in", "out"] | None,
        limit: int,
        max_scanned_transactions: int,
        wait_for_root_transaction: bool,
    ) -> Transaction | None:
        if not wait_for_root_transaction:
            return await self.findTransactionByHashType(
                address,
                hash_value,
                hash_type,
                {"limit": limit, "archival": True, "maxScannedTransactions": max_scanned_transactions},
            )

        attempts = max(
            1,
            math.ceil(DEFAULT_WAIT_FOR_ROOT_TRANSACTION_TIMEOUT_MS / DEFAULT_WAIT_FOR_ROOT_TRANSACTION_RETRY_DELAY_MS),
        )
        broad_search_opts: GetTransactionsOptions = {
            "limit": limit,
            "archival": True,
            "maxScannedTransactions": max_scanned_transactions,
        }
        baseline_info = await self.getAddressInformation(address)
        seen_lt = baseline_info.get("lastTransaction", {}).get("lt") or None

        first_tx = await self.findTransactionByHashType(address, hash_value, hash_type, broad_search_opts)
        if first_tx:
            if self.logger:
                self.logger.debug(f"Root transaction found on attempt 1/{attempts}")
            return first_tx
        if self.logger:
            self.logger.debug(
                "Root transaction not found yet "
                f"(attempt 1/{attempts}), retrying in {DEFAULT_WAIT_FOR_ROOT_TRANSACTION_RETRY_DELAY_MS}ms"
            )
        await asyncio.sleep(DEFAULT_WAIT_FOR_ROOT_TRANSACTION_RETRY_DELAY_MS / 1000)

        for attempt in range(2, attempts + 1):
            info = await self.getAddressInformation(address)
            current_lt = info.get("lastTransaction", {}).get("lt") or None

            if not current_lt or current_lt == seen_lt:
                if self.logger:
                    self.logger.debug(
                        "Root transaction not found yet "
                        f"(attempt {attempt}/{attempts}), lastTx unchanged, "
                        f"retrying in {DEFAULT_WAIT_FOR_ROOT_TRANSACTION_RETRY_DELAY_MS}ms"
                    )
                await asyncio.sleep(DEFAULT_WAIT_FOR_ROOT_TRANSACTION_RETRY_DELAY_MS / 1000)
                continue

            seen_lt = current_lt
            tx = await self.findTransactionByHashType(address, hash_value, hash_type, broad_search_opts)
            if tx:
                if self.logger:
                    self.logger.debug(f"Root transaction found on attempt {attempt}/{attempts}")
                return tx
            if self.logger:
                self.logger.debug(
                    "Root transaction not found yet "
                    f"(attempt {attempt}/{attempts}), retrying in {DEFAULT_WAIT_FOR_ROOT_TRANSACTION_RETRY_DELAY_MS}ms"
                )
            await asyncio.sleep(DEFAULT_WAIT_FOR_ROOT_TRANSACTION_RETRY_DELAY_MS / 1000)

        if self.logger:
            self.logger.debug(f"Root transaction not found after {attempts} attempts")
        return None

    async def trackTransactionTree(
        self, address: str, hash_value: str, params: TrackTransactionTreeParams | None = None
    ) -> None:
        result = await self.trackTransactionTreeWithResult(address, hash_value, params)
        checked_count = result.get("checkedCount")
        if self.logger and isinstance(checked_count, int):
            self.logger.debug(f"Transaction tree checked: {checked_count} unique transaction(s)")
        err = result.get("error")
        if not result.get("success") and err:
            context = ""
            if err["reason"] == "not_found":
                context = f" address={err.get('address', 'unknown')} hashType={err.get('hashType', 'unknown')}"
            raise tx_finalization_error(
                f"{err['txHash']}: reason={err['reason']} (exitCode={err['exitCode']}, resultCode={err['resultCode']}){context}"
            )

    async def trackTransactionTreeWithResult(
        self, address: str, hash_value: str, params: TrackTransactionTreeParams | None = None
    ) -> TrackTransactionTreeResult:
        opts = params or {}
        max_depth = opts.get("maxDepth", DEFAULT_FIND_TX_MAX_DEPTH)
        max_scanned_transactions = opts.get("maxScannedTransactions", DEFAULT_MAX_SCANNED_TRANSACTIONS)
        ignore_opcode_list = opts.get("ignoreOpcodeList", IGNORE_OPCODE)
        limit = opts.get("limit", DEFAULT_FIND_TX_LIMIT)
        direction = opts.get("direction", "both")
        wait_for_root_transaction = bool(opts.get("waitForRootTransaction", DEFAULT_WAIT_FOR_ROOT_TRANSACTION))
        normalized_root_hash = normalize_hash_to_base64(hash_value)

        visited_search_keys: set[str] = set()
        processed_tx_hashes: set[str] = set()
        checked_count = 0
        search_opts: GetTransactionsOptions = {
            "limit": int(limit),
            "archival": True,
            "maxScannedTransactions": int(max_scanned_transactions),
        }
        parsed_address = TonAddress(address) if isinstance(address, str) else address
        queue: list[TransactionDepth] = [
            {"address": parsed_address, "hash": normalized_root_hash, "depth": 0, "hashType": "unknown"}
        ]

        while queue:
            current = queue.pop(0)
            current_hash = current.get("hash", "")
            current_hash_type = self._normalize_hash_type(current.get("hashType"))
            current_address = current.get("address")
            visited_key = f"{self._address_to_key(current_address)}:{current_hash}:{current_hash_type}"
            if visited_key in visited_search_keys:
                continue
            visited_search_keys.add(visited_key)

            current_depth = int(current.get("depth", 0))
            if current_depth == 0:
                tx = await self.findRootTransactionWithRetry(
                    current_address,
                    current_hash,
                    current_hash_type,
                    limit,
                    int(max_scanned_transactions),
                    wait_for_root_transaction,
                )
            else:
                tx = await self.findTransactionByHashType(current_address, current_hash, current_hash_type, search_opts)

            if not tx:
                if self.logger:
                    self.logger.debug(
                        f"Transaction not found for hash: {current_hash} "
                        f"(address={self._address_to_key(current_address)}, hashType={current_hash_type or 'unknown'})"
                    )
                hash_type_for_error: Literal["unknown", "in", "out"] = (
                    current_hash_type if current_hash_type is not None else "unknown"
                )
                not_found_error = self._build_validation_error(
                    tx_hash=current_hash,
                    exit_code="N/A",
                    result_code="N/A",
                    reason="not_found",
                    address=self._address_to_key(current_address),
                    hash_type=hash_type_for_error,
                )
                not_found_result: TrackTransactionTreeResult = {
                    "success": False,
                    "checkedCount": checked_count,
                    "error": not_found_error,
                }
                return not_found_result

            tx_hash = self._tx_hash_b64(tx)
            if tx_hash in processed_tx_hashes:
                continue
            processed_tx_hashes.add(tx_hash)
            checked_count += 1

            validation_error = self.validateTransactionWithResult(tx, ignore_opcode_list)
            if validation_error:
                failed_result: TrackTransactionTreeResult = {
                    "success": False,
                    "checkedCount": checked_count,
                    "error": validation_error,
                }
                return failed_result

            if current_depth < max_depth:
                if (direction in ("forward", "both")) and tx.out_msgs:
                    for msg in tx.out_msgs:
                        dst = msg.info.dest
                        if not dst or isinstance(dst, ExternalAddress):
                            continue
                        queue.append(
                            {
                                "hash": base64.b64encode(msg.serialize().hash).decode("utf-8"),
                                "address": dst,
                                "depth": current_depth + 1,
                                "hashType": "in",
                            }
                        )

                if (direction in ("backward", "both")) and tx.in_msg and tx.in_msg.is_internal:
                    queue.append(
                        {
                            "hash": base64.b64encode(tx.in_msg.serialize().hash).decode("utf-8"),
                            "address": tx.in_msg.info.src,
                            "depth": current_depth + 1,
                            "hashType": "out",
                        }
                    )
        success_result: TrackTransactionTreeResult = {"success": True, "checkedCount": checked_count}
        return success_result

    @staticmethod
    def _build_validation_error(
        tx_hash: str,
        exit_code: int | Literal["N/A"],
        result_code: int | Literal["N/A"],
        reason: Literal[
            "aborted",
            "compute_phase_missing",
            "compute_phase_failed",
            "action_phase_failed",
            "not_found",
        ],
        *,
        address: str | None = None,
        hash_type: Literal["unknown", "in", "out"] | None = None,
    ) -> TransactionValidationError:
        error: TransactionValidationError = {
            "txHash": tx_hash,
            "exitCode": exit_code,
            "resultCode": result_code,
            "reason": reason,
        }
        if address is not None:
            error["address"] = address
        if hash_type is not None:
            error["hashType"] = hash_type
        return error

    @staticmethod
    def _normalize_hash_type(value: object) -> Literal["unknown", "in", "out"] | None:
        if value == "unknown":
            return "unknown"
        if value == "in":
            return "in"
        if value == "out":
            return "out"
        return None

    @staticmethod
    def _tx_hash_b64(tx: Transaction) -> str:
        hash_fn = getattr(tx, "hash", None)
        tx_hash: Any
        if callable(hash_fn):
            tx_hash = hash_fn()
        else:
            tx_hash = getattr(getattr(tx, "cell", None), "hash", b"")
        if isinstance(tx_hash, int):
            tx_hash = tx_hash.to_bytes(32, "big")
        if isinstance(tx_hash, str):
            return tx_hash
        if isinstance(tx_hash, (bytes, bytearray, memoryview)):
            return base64.b64encode(bytes(tx_hash)).decode("utf-8")
        return ""

    @staticmethod
    def _tx_lt(tx: Transaction) -> str:
        return str(getattr(tx, "lt", getattr(tx, "prev_trans_lt", 0)))

    @staticmethod
    def _tx_prev_lt(tx: Transaction) -> int:
        return int(getattr(tx, "prevTransactionLt", getattr(tx, "prev_trans_lt", 0)))

    @staticmethod
    def _tx_prev_hash_b64(tx: Transaction) -> str:
        prev_hash = getattr(tx, "prevTransactionHash", getattr(tx, "prev_trans_hash", b""))
        if isinstance(prev_hash, int):
            prev_hash = prev_hash.to_bytes(32, "big")
        return base64.b64encode(bytes(prev_hash)).decode("utf-8")

    @staticmethod
    def _address_to_key(address: Any) -> str:
        if address is None:
            return "unknown"
        if hasattr(address, "to_str"):
            try:
                return address.to_str(
                    is_user_friendly=True,
                    is_url_safe=True,
                    is_bounceable=True,
                    is_test_only=False,
                )
            except Exception:
                return str(address)
        return str(address)

base_contract_opener = BaseContractOpener
