from __future__ import annotations

import base64
from typing import Any

from pytoniq.contract.contract import Contract
from pytoniq.liteclient.balancer import LiteBalancer
from pytoniq.liteclient.client import LiteClient
from pytoniq_core.boc.address import Address
from pytoniq_core.boc.cell import Cell
from pytoniq_core.tlb.custom.wallet import WalletMessage
from pytoniq_core.tlb.transaction import Transaction

from adapters.base_contract_opener import base_contract_opener
from interfaces.i_logger import ILogger
from sdk.consts import DEFAULT_FIND_TX_LIMIT, DEFAULT_LITESERVER_TRUST_LEVEL
from structs.struct import AddressInformation, ContractState, GetTransactionsOptions, Network
from wrappers.highload_wallet_v3 import highload_wallet_v3


def _int_to_ip(value: int) -> str:
    part1 = value & 255
    part2 = (value >> 8) & 255
    part3 = (value >> 16) & 255
    part4 = (value >> 24) & 255
    return f"{part4}.{part3}.{part2}.{part1}"


class LiteClientOpener(base_contract_opener):
    def __init__(self, client: LiteBalancer, logger: ILogger | None = None):
        super().__init__(logger)
        self.client = client

    @staticmethod
    async def create(options: dict, logger: ILogger | None = None) -> lite_client_opener:
        if "liteservers" in options:
            liteservers = options["liteservers"]
            clients = []
            for server in liteservers:
                host = _int_to_ip(int(server["ip"]))
                port = int(server["port"])
                pub_key = server["id"]["key"]
                clients.append(
                    LiteClient(
                        host=host,
                        port=port,
                        server_pub_key=pub_key,
                        trust_level=DEFAULT_LITESERVER_TRUST_LEVEL,
                    )
                )
            balancer = LiteBalancer(clients)
            await _start_lite_balancer(balancer)
            return lite_client_opener(balancer, logger)

        selected_network = options.get("network")
        if selected_network == Network.TESTNET or selected_network == Network.DEV:
            client = LiteBalancer.from_testnet_config(trust_level=DEFAULT_LITESERVER_TRUST_LEVEL)
        else:
            client = LiteBalancer.from_mainnet_config(trust_level=DEFAULT_LITESERVER_TRUST_LEVEL)
        await _start_lite_balancer(client)
        return lite_client_opener(client, logger)

    def open(self, src: Any) -> Any:
        if _is_wallet_contract(src):
            return _WalletContractProxy(self, src)
        bind_opener = getattr(src, "bind_opener", None)
        if callable(bind_opener):
            return bind_opener(self)
        return src

    async def raw_send_message(self, boc: bytes) -> Any:
        return await self.client.raw_send_message(boc)

    async def closeConnections(self) -> None:
        if hasattr(self.client, "close_all"):
            await self.client.close_all()
            return
        if hasattr(self.client, "close"):
            await self.client.close()

    async def getContractState(self, address: Any) -> ContractState:
        addr = Address(address) if isinstance(address, str) else address
        account, shard = await self.client.raw_get_account_state(addr)
        if account is None:
            return {"balance": 0, "state": "uninitialized", "code": None}

        account_state = account.storage.state
        if account_state.type_ == "account_uninit":
            state_type = "uninitialized"
        elif account_state.type_ == "account_frozen":
            state_type = "frozen"
        else:
            state_type = "active"

        code = None
        if state_type == "active" and getattr(account_state, "state_init", None):
            code_cell = account_state.state_init.code
            if code_cell:
                code = code_cell.to_boc()
        return {"balance": account.storage.balance.grams, "state": state_type, "code": code}

    async def getTransactions(self, address: Any, opts: GetTransactionsOptions) -> list[Transaction]:
        addr = Address(address) if isinstance(address, str) else address
        limit = opts.get("limit") or DEFAULT_FIND_TX_LIMIT
        if opts.get("lt") and opts.get("hash"):
            lt_value = opts.get("lt")
            hash_value = opts.get("hash")
            if lt_value is None or hash_value is None:
                return []
            lt = int(lt_value)
            tx_hash = base64.b64decode(str(hash_value))
        else:
            _, shard = await self.client.raw_get_account_state(addr)
            if shard is None:
                return []
            lt = shard.last_trans_lt
            tx_hash = shard.last_trans_hash

        txs = await self.client.get_transactions(addr, limit, from_lt=lt, from_hash=tx_hash)

        if opts.get("to_lt"):
            to_lt_value = opts.get("to_lt")
            if to_lt_value is None:
                return txs
            to_lt = int(to_lt_value)
            inclusive = bool(opts.get("inclusive"))
            filtered = []
            for tx in txs:
                if inclusive:
                    if tx.lt >= to_lt:
                        filtered.append(tx)
                else:
                    if tx.lt > to_lt:
                        filtered.append(tx)
            txs = filtered

        return txs

    async def getAddressInformation(self, address: Any) -> AddressInformation:
        addr = Address(address) if isinstance(address, str) else address
        _, shard = await self.client.raw_get_account_state(addr)
        if shard is None:
            return {"lastTransaction": {"lt": "", "hash": ""}}
        return {
            "lastTransaction": {
                "lt": str(shard.last_trans_lt),
                "hash": base64.b64encode(shard.last_trans_hash).decode("utf-8"),
            }
        }

    async def getConfig(self) -> str:
        config = await self.client.get_config_all()
        from pytoniq_core.boc import HashMap

        dict_ = HashMap(32)
        for key, value in config.items():
            dict_.set_int_key(int(key), value)
        dict_cell = dict_.serialize() or Cell.empty()
        return base64.b64encode(dict_cell.to_boc()).decode("utf-8")


class _WalletContractProxy:
    def __init__(self, opener: lite_client_opener, wallet: Any):
        self._opener = opener
        self._wallet = wallet

    async def getSeqno(self) -> int:
        try:
            stack = await self._opener.client.run_get_method(self._wallet.address, "seqno", [])
            return int(stack[0]) if stack else 0
        except Exception:
            return 0

    async def send(self, msg: Cell, state_init: Any | None = None) -> str | None:
        init = state_init
        external = Contract.create_external_msg(dest=self._wallet.address, state_init=init, body=msg)
        boc = external.serialize().to_boc()
        await self._opener.raw_send_message(boc)
        return base64.b64encode(boc).decode("utf-8")

    async def sendTransfer(self, **kwargs: Any) -> str:
        if not isinstance(self._wallet, highload_wallet_v3):
            raise ValueError("sendTransfer is supported only for highload_wallet_v3")

        messages = kwargs.get("messages") or []
        send_mode = kwargs.get("sendMode", 3)
        created_at = kwargs.get("createdAt")
        secret_key = kwargs.get("secretKey")
        if secret_key is None:
            raise ValueError("secretKey is required")

        wallet_messages = [WalletMessage(send_mode, msg) for msg in messages]

        # Use on-chain data when available
        subwallet_id = self._wallet.subwallet_id
        timeout = self._wallet.timeout
        state_init = None
        try:
            state = await self._opener.getContractState(self._wallet.address)
            if state.get("state") == "active":
                try:
                    subwallet_id = int((await self._opener.client.run_get_method(self._wallet.address, "get_subwallet_id", []))[0])
                except Exception:
                    pass
                try:
                    timeout = int((await self._opener.client.run_get_method(self._wallet.address, "get_timeout", []))[0])
                except Exception:
                    pass
            else:
                state_init = self._wallet.init
        except Exception:
            state_init = self._wallet.init

        query_id = self._wallet.getQueryIdFromCreatedAt(created_at or highload_wallet_v3.generate_created_at())
        body = self._wallet.create_transfer_body(
            secret_key=secret_key,
            messages=wallet_messages,
            created_at=created_at,
            query_id=query_id,
            timeout=timeout,
            subwallet_id=subwallet_id,
        )
        external = Contract.create_external_msg(dest=self._wallet.address, state_init=state_init, body=body)
        boc = external.serialize().to_boc()
        await self._opener.raw_send_message(boc)
        return base64.b64encode(boc).decode("utf-8")


async def _start_lite_balancer(balancer: LiteBalancer) -> None:
    if hasattr(balancer, "start_up"):
        await balancer.start_up()
        return
    await balancer.connect()


def _is_wallet_contract(src: Any) -> bool:
    if not hasattr(src, "address"):
        return False
    return (
        hasattr(src, "createTransfer")
        or hasattr(src, "create_transfer")
        or hasattr(src, "create_transfer_body")
        or hasattr(src, "public_key")
        or hasattr(src, "init")
    )

lite_client_opener = LiteClientOpener
_wallet_contract_proxy = _WalletContractProxy
