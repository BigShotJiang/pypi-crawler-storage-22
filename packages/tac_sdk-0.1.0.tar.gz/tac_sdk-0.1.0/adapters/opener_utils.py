from __future__ import annotations

from sdk.utils import sleep
from structs.struct import Network

async def get_http_endpoint(network: Network) -> str:
    if network == Network.MAINNET:
        return "https://toncenter.com/api/v2/jsonRPC"
    return "https://testnet.toncenter.com/api/v2/jsonRPC"


async def get_http_v4_endpoint(network: Network) -> str:
    if network == Network.MAINNET:
        return "https://mainnet-v4.tonhubapi.com"
    return "https://testnet-v4.tonhubapi.com"
