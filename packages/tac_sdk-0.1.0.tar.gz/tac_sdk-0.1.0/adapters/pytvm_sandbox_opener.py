from __future__ import annotations

import re
from typing import Any

from adapters.base_contract_opener import base_contract_opener
from interfaces.i_logger import ILogger
from sdk.sandbox import pytvm_chain
from structs.struct import AddressInformation, ContractState, GetTransactionsOptions


class PytvmSandboxOpener(base_contract_opener):
    def __init__(self, chain: pytvm_chain | None = None, logger: ILogger | None = None):
        super().__init__(logger)
        self.chain = chain or pytvm_chain()
        self.client = self.chain

    def open(self, src: Any) -> Any:
        if hasattr(src, "address"):
            return _PytvmSandboxContract(self.chain, src)
        return src

    async def getContractState(self, address: Any) -> ContractState:
        return self.chain.get_contract_state(str(address))

    async def getTransactions(self, address: Any, opts: GetTransactionsOptions):
        _ = (address, opts)
        return []

    async def getAddressInformation(self, address: Any) -> AddressInformation:
        _ = address
        return {"lastTransaction": {"lt": "", "hash": ""}}

    async def getConfig(self) -> str:
        return ""


class _PytvmSandboxContract:
    def __init__(self, chain: pytvm_chain, src: Any):
        self._chain = chain
        self._src = src
        self.address = str(getattr(src, "address", ""))

    def __getattr__(self, item: str) -> Any:
        original = getattr(self._src, item, None)
        if callable(original):
            return original

        if item.startswith("get"):
            async def _run_get(*args: Any) -> Any:
                stack = list(args) if args else []
                method = _to_snake_case(item)
                return self._chain.run_get_method(self.address, method, stack)

            return _run_get

        raise AttributeError(item)


def _to_snake_case(value: str) -> str:
    stripped = value[3:] if value.startswith("get") and len(value) > 3 else value
    return re.sub(r"(?<!^)(?=[A-Z])", "_", stripped).lower()

pytvm_sandbox_opener = PytvmSandboxOpener
_pytvm_sandbox_contract = _PytvmSandboxContract
