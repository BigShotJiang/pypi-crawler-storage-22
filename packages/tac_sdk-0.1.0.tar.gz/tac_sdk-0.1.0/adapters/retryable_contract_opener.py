from __future__ import annotations

import asyncio
import inspect
import re
from dataclasses import dataclass
from typing import Any, Callable
from urllib.parse import urlparse

import requests

from adapters.lite_client_opener import lite_client_opener
from adapters.ton_client4_opener import orbs_opener4
from adapters.ton_client_opener import orbs_opener, ton_client_opener
from errors.errors import transaction_error
from errors.instances import all_contract_opener_failed_error
from interfaces.contract_opener import ContractOpener
from interfaces.i_logger import ILogger
from sdk.consts import DEFAULT_RETRY_DELAY_MS, DEFAULT_RETRY_MAX_COUNT
from structs.struct import (
    AddressInformation,
    ContractState,
    GetTransactionsOptions,
    Network,
    TrackTransactionTreeParams,
    TrackTransactionTreeResult,
)


@dataclass
class OpenerConfig:
    opener: ContractOpener
    retries: int = DEFAULT_RETRY_MAX_COUNT
    retryDelay: int = DEFAULT_RETRY_DELAY_MS


class RetryableContractOpener(ContractOpener):
    def __init__(self, openerConfigs: list[OpenerConfig], logger: ILogger | None = None):
        if not openerConfigs:
            raise ValueError("No ContractOpener instances available")
        self.openerConfigs = openerConfigs
        self.logger = logger
        if logger is not None:
            self._apply_logger_to_openers(logger)
        self.client = self._resolve_client()

    def setLogger(self, logger: ILogger) -> None:  # noqa: N802
        if self.logger is None:
            self.logger = logger
        self._apply_logger_to_openers(logger)

    async def getTransactions(self, address, opts: GetTransactionsOptions):
        result = await self.executeWithFallback(lambda cfg: cfg.opener.getTransactions(address, opts))
        if result["success"] and result.get("data") is not None:
            return result["data"]
        raise result.get("lastError") or all_contract_opener_failed_error("Failed to get transactions")

    async def getTransactionByHash(self, address, hash_value, opts: GetTransactionsOptions | None = None):
        result = await self.executeWithFallback(lambda cfg: cfg.opener.getTransactionByHash(address, hash_value, opts))
        if result["success"]:
            return result.get("data")
        raise result.get("lastError") or all_contract_opener_failed_error("Failed to get transaction by hash")

    async def getAdjacentTransactions(self, address, hash_value, opts: GetTransactionsOptions | None = None):
        result = await self.executeWithFallback(lambda cfg: cfg.opener.getAdjacentTransactions(address, hash_value, opts))
        if result["success"]:
            return result.get("data") or []
        raise result.get("lastError") or all_contract_opener_failed_error("Failed to get adjacent transactions")

    def open(self, src):
        first = self.openerConfigs[0]
        contract = first.opener.open(src)
        return _RetryableContractProxy(self, contract, src)

    async def getContractState(self, address) -> ContractState:
        result = await self.executeWithFallback(lambda cfg: cfg.opener.getContractState(address))
        if result["success"] and result.get("data") is not None:
            return result["data"]
        raise result.get("lastError") or all_contract_opener_failed_error("Failed to get contract state")

    async def getAddressInformation(self, address) -> AddressInformation:
        result = await self.executeWithFallback(lambda cfg: cfg.opener.getAddressInformation(address))
        if result["success"] and result.get("data") is not None:
            return result["data"]
        raise result.get("lastError") or all_contract_opener_failed_error("Failed to get address information")

    async def getConfig(self) -> str:
        result = await self.executeWithFallback(lambda cfg: cfg.opener.getConfig())
        if result["success"] and result.get("data") is not None:
            return result["data"]
        raise result.get("lastError") or all_contract_opener_failed_error("Failed to get blockchain config")

    async def raw_send_message(self, boc: bytes) -> Any:
        result = await self.executeWithFallback(lambda cfg: cfg.opener.raw_send_message(boc))
        if result["success"]:
            return result.get("data")
        raise result.get("lastError") or all_contract_opener_failed_error("Failed to send raw message")

    async def closeConnections(self) -> None:
        closed: set[int] = set()
        for config in self.openerConfigs:
            opener = config.opener
            opener_id = id(opener)
            if opener_id in closed:
                continue
            closed.add(opener_id)
            close_fn = getattr(opener, "closeConnections", None)
            if not callable(close_fn):
                continue
            result = close_fn()
            if inspect.isawaitable(result):
                await result

    async def getTransactionByTxHash(self, address, tx_hash, opts: GetTransactionsOptions | None = None):
        result = await self.executeWithFallback(lambda cfg: cfg.opener.getTransactionByTxHash(address, tx_hash, opts))
        if result["success"]:
            return result.get("data")
        raise result.get("lastError") or all_contract_opener_failed_error("Failed to get transaction by transaction hash")

    async def getTransactionByInMsgHash(self, address, msg_hash, opts: GetTransactionsOptions | None = None):
        result = await self.executeWithFallback(lambda cfg: cfg.opener.getTransactionByInMsgHash(address, msg_hash, opts))
        if result["success"]:
            return result.get("data")
        raise result.get("lastError") or all_contract_opener_failed_error("Failed to get transaction by message hash")

    async def getTransactionByOutMsgHash(self, address, msg_hash, opts: GetTransactionsOptions | None = None):
        result = await self.executeWithFallback(lambda cfg: cfg.opener.getTransactionByOutMsgHash(address, msg_hash, opts))
        if result["success"]:
            return result.get("data")
        raise result.get("lastError") or all_contract_opener_failed_error("Failed to get transaction by outgoing message hash")

    async def trackTransactionTree(self, address: str, hash_value: str, params: TrackTransactionTreeParams | None = None) -> None:
        result = await self.executeWithFallback(
            lambda cfg: cfg.opener.trackTransactionTree(address, hash_value, params),
            use_retries=True,
            should_retry_on_error=_is_track_tree_retryable_error,
            should_fallback_on_error=_is_track_tree_retryable_error,
        )
        if not result["success"]:
            raise result.get("lastError") or all_contract_opener_failed_error("Failed to track transaction tree")

    async def trackTransactionTreeWithResult(
        self, address: str, hash_value: str, params: TrackTransactionTreeParams | None = None
    ) -> TrackTransactionTreeResult:
        result = await self.executeWithFallback(
            lambda cfg: cfg.opener.trackTransactionTreeWithResult(address, hash_value, params),
            use_retries=True,
            should_retry_on_error=_is_track_tree_retryable_error,
            should_fallback_on_error=_is_track_tree_retryable_error,
        )
        if not result["success"]:
            raise result.get("lastError") or all_contract_opener_failed_error("Failed to track transaction tree with result")
        return result["data"]

    async def executeWithFallback(
        self,
        operation: Callable[[OpenerConfig], Any],
        use_retries: bool = True,
        should_retry_on_error: Callable[[Exception], bool] | None = None,
        should_fallback_on_error: Callable[[Exception], bool] | None = None,
    ) -> dict:
        last_error: Exception | None = None
        for config in self.openerConfigs:
            result = (
                await self.tryWithRetries(
                    lambda config=config: operation(config),
                    config,
                    should_retry_on_error=should_retry_on_error,
                )
                if use_retries
                else await self.tryWithoutRetries(lambda config=config: operation(config), config=config)
            )
            if result["success"]:
                return {"success": True, "data": result.get("data")}
            last_error = result.get("lastError")
            if isinstance(last_error, transaction_error) or (
                isinstance(last_error, Exception) and _is_contract_execution_error(last_error)
            ):
                if (
                    last_error is not None
                    and should_fallback_on_error is not None
                    and should_fallback_on_error(last_error)
                ):
                    continue
                return {"success": False, "lastError": last_error}
            if (
                last_error is not None
                and should_fallback_on_error is not None
                and not should_fallback_on_error(last_error)
            ):
                return {"success": False, "lastError": last_error}
        return {"success": False, "lastError": last_error}

    async def tryWithoutRetries(self, operation: Callable[[], Any], config: OpenerConfig | None = None) -> dict:
        try:
            data = operation()
            if inspect.isawaitable(data):
                data = await data
            return {"success": True, "data": data}
        except Exception as exc:
            if self.logger:
                status_code = _extract_status_code(exc)
                label = _opener_label(config.opener) if config else "opener"
                self.logger.debug(
                    f"[{label}] Contract opener single-attempt failed"
                    f"{f' (HTTP {status_code})' if status_code else ''}: {exc}"
                )
            return {"success": False, "lastError": exc}

    async def tryWithRetries(
        self,
        operation: Callable[[], Any],
        config: OpenerConfig,
        should_retry_on_error: Callable[[Exception], bool] | None = None,
    ) -> dict:
        last_error: Exception | None = None
        for attempt in range(config.retries + 1):
            try:
                data = operation()
                if inspect.isawaitable(data):
                    data = await data
                return {"success": True, "data": data}
            except Exception as exc:
                last_error = exc
                status_code = _extract_status_code(exc)
                label = _opener_label(config.opener)
                if self.logger:
                    self.logger.debug(
                        f"[{label}] Contract opener attempt {attempt + 1}/{config.retries + 1} failed"
                        f"{f' (HTTP {status_code})' if status_code else ''}: {exc}"
                    )
                if isinstance(exc, transaction_error) or _is_contract_execution_error(exc):
                    if should_retry_on_error is not None and should_retry_on_error(exc) and attempt < config.retries:
                        await asyncio.sleep(config.retryDelay / 1000)
                        continue
                    return {"success": False, "lastError": last_error}
                if should_retry_on_error is not None and not should_retry_on_error(exc):
                    return {"success": False, "lastError": last_error}
                if attempt < config.retries:
                    retry_delay_ms = config.retryDelay
                    if status_code == 429:
                        retry_delay_ms = max(retry_delay_ms, min(30_000, config.retryDelay * (attempt + 1)))
                    await asyncio.sleep(retry_delay_ms / 1000)
        return {"success": False, "lastError": last_error}

    def _resolve_client(self) -> Any:
        for config in self.openerConfigs:
            client = getattr(config.opener, "client", None)
            if client is not None:
                return client
        return None

    def _apply_logger_to_openers(self, logger: ILogger) -> None:
        for config in self.openerConfigs:
            config.opener.setLogger(logger)


class _RetryableContractProxy:
    def __init__(self, opener: RetryableContractOpener, contract: Any, src: Any):
        self._opener = opener
        self._contract = contract
        self._src = src

    def __getattr__(self, item: str) -> Any:
        value = getattr(self._contract, item)
        if not callable(value):
            return value

        async def _wrapped(*args, **kwargs):
            async def _call(config: OpenerConfig):
                contract = config.opener.open(self._src)
                method = getattr(contract, item)
                result = method(*args, **kwargs)
                if inspect.isawaitable(result):
                    return await result
                return result

            result = await self._opener.executeWithFallback(_call)
            if result["success"]:
                return result.get("data")
            raise result.get("lastError") or all_contract_opener_failed_error("failed to call method in contract")

        return _wrapped


async def create_default_retryable_opener(
    ton_rpc_endpoint: str,
    network_type: Network,
    max_retries: int = DEFAULT_RETRY_MAX_COUNT,
    retry_delay: int = DEFAULT_RETRY_DELAY_MS,
    logger: ILogger | None = None,
    include_lite_client: bool = False,
) -> RetryableContractOpener:
    openers: list[OpenerConfig] = []

    if include_lite_client:
        try:
            opener = await lite_client_opener.create({"network": network_type}, logger=logger)
            openers.append(OpenerConfig(opener=opener, retries=max_retries, retryDelay=retry_delay))
        except Exception:
            pass

    try:
        rpc_endpoint = _normalize_toncenter_rpc_endpoint(ton_rpc_endpoint)
        opener = ton_client_opener.create(rpc_endpoint, logger=logger)
        openers.append(OpenerConfig(opener=opener, retries=max_retries, retryDelay=retry_delay))
    except Exception:
        pass

    if network_type != Network.DEV:
        try:
            opener = await orbs_opener(network_type, logger=logger)
            openers.append(OpenerConfig(opener=opener, retries=max_retries, retryDelay=retry_delay))
        except Exception:
            pass

        try:
            opener = await orbs_opener4(network_type, logger=logger)
            openers.append(OpenerConfig(opener=opener, retries=max_retries, retryDelay=retry_delay))
        except Exception:
            pass

    if not openers:
        raise RuntimeError("Failed to create any ContractOpener instances")

    return RetryableContractOpener(openers, logger)


def _normalize_toncenter_rpc_endpoint(endpoint: str) -> str:
    raw = (endpoint or "").strip().rstrip("/")
    if not raw:
        raise ValueError("ton_rpc_endpoint is required")

    parsed = urlparse(raw)
    path = parsed.path or ""
    if path.endswith("/api/v2/jsonRPC") or path.endswith("/jsonRPC"):
        return raw

    if not path or path == "/":
        return f"{raw}/api/v2/jsonRPC"

    return raw


def _extract_status_code(exc: Exception) -> int | None:
    response = getattr(exc, "response", None)
    code = getattr(response, "status_code", None)
    if isinstance(code, int):
        return code

    message = str(exc)
    match = re.search(r"\b(?:HTTP\s+)?(\d{3})\b", message)
    if match:
        return int(match.group(1))
    return None


def _opener_label(opener: Any) -> str:
    endpoint = getattr(opener, "endpoint", None)
    class_name = opener.__class__.__name__
    if isinstance(endpoint, str) and endpoint:
        return f"{class_name}:{endpoint}"
    return class_name


def _is_transport_error(exc: Exception) -> bool:
    if isinstance(exc, transaction_error):
        return False
    if isinstance(exc, (requests.RequestException, TimeoutError, asyncio.TimeoutError)):
        return True
    status_code = _extract_status_code(exc)
    if status_code is None:
        return True
    return status_code == 429 or status_code >= 500


def _is_contract_execution_error(exc: Exception) -> bool:
    if isinstance(exc, transaction_error):
        return False

    if isinstance(getattr(exc, "exitCode", None), int):
        return True
    if isinstance(getattr(exc, "vmExitCode", None), int):
        return True
    if isinstance(getattr(exc, "exit_code", None), int):
        return True

    message = str(exc)
    return bool(
        re.search(r"unable to execute get method", message, re.IGNORECASE)
        or re.search(r"exit[_\s-]*code\s*:\s*\d+", message, re.IGNORECASE)
        or re.search(r"vm exit code\s*:\s*\d+", message, re.IGNORECASE)
    )


def _is_transaction_not_found_error(exc: Exception) -> bool:
    if not isinstance(exc, transaction_error):
        return False
    return "reason=not_found" in str(exc).lower()


def _is_track_tree_retryable_error(exc: Exception) -> bool:
    return _is_transport_error(exc) or _is_transaction_not_found_error(exc)

opener_config = OpenerConfig
retryable_contract_opener = RetryableContractOpener
_retryable_contract_proxy = _RetryableContractProxy
