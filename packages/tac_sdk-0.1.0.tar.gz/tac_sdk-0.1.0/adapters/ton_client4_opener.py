from __future__ import annotations

import base64
import json
from typing import Any

import requests
from pytoniq.contract.contract import Contract
from pytoniq_core.boc.address import Address
from pytoniq_core.boc.cell import Cell
from pytoniq_core.tlb.custom.wallet import WalletMessage
from pytoniq_core.tlb.transaction import Transaction
from pytoniq_core.tlb.vm_stack import VmStack

from adapters.base_contract_opener import base_contract_opener
from adapters.opener_utils import get_http_v4_endpoint
from interfaces.i_logger import ILogger
from sdk.consts import DEFAULT_HTTP_CLIENT_TIMEOUT_MS
from sdk.utils import normalize_hash_to_base64
from structs.struct import AddressInformation, ContractState, GetTransactionsOptions, Network
from wrappers.highload_wallet_v3 import highload_wallet_v3


def _format_address(address: Any) -> str:
    addr = Address(address) if isinstance(address, str) else address
    if hasattr(addr, "to_str"):
        try:
            return addr.to_str(is_user_friendly=True, is_url_safe=True, is_bounceable=True, is_test_only=False)
        except Exception:
            return str(addr)
    return str(addr)


def _to_urlsafe_base64(value: str) -> str:
    return value.replace("+", "-").replace("/", "_").rstrip("=")


def _parse_vm_stack_number(result_raw: str | None) -> int | None:
    if not result_raw:
        return None
    try:
        cell = Cell.one_from_boc(base64.b64decode(result_raw))
        stack = VmStack.deserialize(cell.begin_parse())
        if not stack:
            return None
        value = stack[0]
        if isinstance(value, int):
            return value
        if isinstance(value, str):
            return int(value)
        return None
    except Exception:
        return None


class TonClient4Opener(base_contract_opener):
    def __init__(
        self,
        endpoint: str,
        timeout: int = DEFAULT_HTTP_CLIENT_TIMEOUT_MS,
        logger: ILogger | None = None,
    ) -> None:
        super().__init__(logger)
        self.endpoint = endpoint.rstrip("/")
        self.timeout = timeout

    @staticmethod
    def create(
        endpoint: str,
        timeout: int = DEFAULT_HTTP_CLIENT_TIMEOUT_MS,
        logger: ILogger | None = None,
    ) -> ton_client4_opener:
        return ton_client4_opener(endpoint=endpoint, timeout=timeout, logger=logger)

    def open(self, src: Any) -> Any:
        if _is_wallet_contract(src):
            return _TonClient4WalletProxy(self, src)
        bind_opener = getattr(src, "bind_opener", None)
        if callable(bind_opener):
            return bind_opener(self)
        return src

    async def getContractState(self, address: Any) -> ContractState:
        latest = self._get_last_block()
        seqno = latest["last"]["seqno"]
        state = self._get_account(seqno, address)
        account_state = state["account"]["state"]
        if account_state["type"] == "uninit":
            state_type = "uninitialized"
        elif account_state["type"] == "frozen":
            state_type = "frozen"
        else:
            state_type = "active"

        code = None
        if state_type == "active":
            code_value = account_state.get("code")
            if code_value:
                code = base64.b64decode(code_value)
        balance = int(state["account"]["balance"]["coins"])
        return {"balance": balance, "state": state_type, "code": code}

    async def getTransactions(self, address: Any, opts: GetTransactionsOptions) -> list[Transaction]:
        addr = _format_address(address)
        lt_opt = opts.get("lt")
        hash_opt = opts.get("hash")

        if bool(lt_opt) != bool(hash_opt):
            raise ValueError("Both lt and hash must be provided together")
        if not lt_opt and not hash_opt:
            info = await self.getAddressInformation(addr)
            last = info.get("lastTransaction") or {}
            lt_opt = last.get("lt")
            hash_opt = last.get("hash")
            if not lt_opt or not hash_opt:
                return []

        lt = int(str(lt_opt))
        hash_value = _to_urlsafe_base64(normalize_hash_to_base64(str(hash_opt)))

        url = f"{self.endpoint}/account/{addr}/tx/{lt}/{hash_value}"
        data = self._request_json("GET", url)
        boc = data.get("boc")
        if not boc:
            return []

        cells = Cell.from_boc(base64.b64decode(boc))
        transactions = [Transaction.deserialize(cell.begin_parse()) for cell in cells]

        if opts.get("limit"):
            limit_value = opts.get("limit")
            if limit_value is not None:
                transactions = transactions[: int(limit_value)]

        if opts.get("to_lt"):
            to_lt_value = opts.get("to_lt")
            if to_lt_value is None:
                return transactions
            to_lt = int(str(to_lt_value))
            inclusive = bool(opts.get("inclusive"))
            filtered: list[Transaction] = []
            for tx in transactions:
                if inclusive:
                    if tx.lt >= to_lt:
                        filtered.append(tx)
                else:
                    if tx.lt > to_lt:
                        filtered.append(tx)
            transactions = filtered

        return transactions

    async def getAddressInformation(self, address: Any) -> AddressInformation:
        latest = self._get_last_block()
        seqno = latest["last"]["seqno"]
        state = self._get_account(seqno, address)
        last = state["account"].get("last") or {}
        return {
            "lastTransaction": {
                "lt": last.get("lt", "") or "",
                "hash": last.get("hash", "") or "",
            }
        }

    async def getConfig(self) -> str:
        latest = self._get_last_block()
        seqno = latest["last"]["seqno"]
        url = f"{self.endpoint}/block/{seqno}/config"
        body = self._request_json("GET", url)
        config = body.get("config", {})
        cell = config.get("cell")
        if not cell:
            raise RuntimeError(f"Failed to fetch config: {json.dumps(body)}")
        return cell

    async def raw_send_message(self, boc: bytes) -> Any:
        return self._send_boc(boc)

    def _get_last_block(self) -> dict:
        url = f"{self.endpoint}/block/latest"
        return self._request_json("GET", url)

    def _get_account(self, seqno: int, address: Any) -> dict:
        addr = _format_address(address)
        url = f"{self.endpoint}/block/{seqno}/{addr}"
        return self._request_json("GET", url)

    def _send_boc(self, boc: bytes) -> Any:
        url = f"{self.endpoint}/send"
        return self._request_json("POST", url, payload={"boc": base64.b64encode(boc).decode("utf-8")})

    def _run_method_raw(self, address: Any, method: str) -> dict:
        latest = self._get_last_block()
        seqno = latest["last"]["seqno"]
        addr = _format_address(address)
        url = f"{self.endpoint}/block/{seqno}/{addr}/run/{method}"
        return self._request_json("GET", url)

    def _request_json(self, method: str, url: str, payload: dict[str, Any] | None = None) -> dict:
        try:
            response = requests.request(
                method=method,
                url=url,
                json=payload,
                timeout=self.timeout / 1000,
            )
            if response.status_code >= 400:
                body_preview = response.text[:500]
                raise RuntimeError(f"HTTP {response.status_code} from '{url}': {body_preview}")
            data = response.json()
            if isinstance(data, dict):
                return data
            raise RuntimeError(f"Unexpected response payload type: {type(data).__name__}")
        except Exception as exc:
            if self.logger:
                self.logger.debug(f"[TonClient4Opener] {method} '{url}' failed: {exc}")
            raise


class _TonClient4WalletProxy:
    def __init__(self, opener: ton_client4_opener, wallet: Any):
        self._opener = opener
        self._wallet = wallet

    async def getSeqno(self) -> int:
        state = await self._opener.getContractState(self._wallet.address)
        if state.get("state") != "active":
            return 0
        result = self._opener._run_method_raw(self._wallet.address, "seqno")
        seqno = _parse_vm_stack_number(result.get("resultRaw"))
        if seqno is None:
            raise RuntimeError("Failed to parse seqno from TonClient4 run response")
        return seqno

    async def send(self, msg: Cell, state_init: Any | None = None) -> str | None:
        init = state_init
        external = Contract.create_external_msg(dest=self._wallet.address, state_init=init, body=msg)
        boc = external.serialize().to_boc()
        self._opener._send_boc(boc)
        return base64.b64encode(boc).decode("utf-8")

    async def sendTransfer(self, **kwargs: Any) -> str:
        if not isinstance(self._wallet, highload_wallet_v3):
            raise ValueError("sendTransfer is supported only for highload_wallet_v3")

        messages = kwargs.get("messages") or []
        send_mode = kwargs.get("sendMode", 3)
        created_at = kwargs.get("createdAt")
        secret_key = kwargs.get("secretKey")
        if secret_key is None:
            raise ValueError("secretKey is required")

        wallet_messages = [WalletMessage(send_mode, msg) for msg in messages]

        subwallet_id = self._wallet.subwallet_id
        timeout = self._wallet.timeout
        state_init = None
        try:
            state = await self._opener.getContractState(self._wallet.address)
            if state.get("state") == "active":
                try:
                    result = self._opener._run_method_raw(self._wallet.address, "get_subwallet_id")
                    subwallet_id = _parse_vm_stack_number(result.get("resultRaw")) or subwallet_id
                except Exception:
                    pass
                try:
                    result = self._opener._run_method_raw(self._wallet.address, "get_timeout")
                    timeout = _parse_vm_stack_number(result.get("resultRaw")) or timeout
                except Exception:
                    pass
            else:
                state_init = self._wallet.init
        except Exception:
            state_init = self._wallet.init

        query_id = self._wallet.getQueryIdFromCreatedAt(created_at or highload_wallet_v3.generate_created_at())
        body = self._wallet.create_transfer_body(
            secret_key=secret_key,
            messages=wallet_messages,
            created_at=created_at,
            query_id=query_id,
            timeout=timeout,
            subwallet_id=subwallet_id,
        )
        external = Contract.create_external_msg(dest=self._wallet.address, state_init=state_init, body=body)
        boc = external.serialize().to_boc()
        self._opener._send_boc(boc)
        return base64.b64encode(boc).decode("utf-8")


def _is_wallet_contract(src: Any) -> bool:
    if not hasattr(src, "address"):
        return False
    return (
        hasattr(src, "createTransfer")
        or hasattr(src, "create_transfer")
        or hasattr(src, "create_transfer_body")
        or hasattr(src, "public_key")
        or hasattr(src, "init")
    )


def ton_hub_api4_opener(
    network: Network,
    timeout: int = DEFAULT_HTTP_CLIENT_TIMEOUT_MS,
    logger: ILogger | None = None,
) -> ton_client4_opener:
    endpoint = "https://mainnet-v4.tonhubapi.com" if network == Network.MAINNET else "https://testnet-v4.tonhubapi.com"
    return ton_client4_opener.create(endpoint, timeout=timeout, logger=logger)


async def orbs_opener4(
    network: Network,
    timeout: int = DEFAULT_HTTP_CLIENT_TIMEOUT_MS,
    logger: ILogger | None = None,
) -> ton_client4_opener:
    endpoint = await get_http_v4_endpoint(network)
    return ton_client4_opener.create(endpoint, timeout=timeout, logger=logger)

ton_client4_opener = TonClient4Opener
_ton_client4_wallet_proxy = _TonClient4WalletProxy
