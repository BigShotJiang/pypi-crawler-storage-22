from __future__ import annotations

import base64
import json
import re
from typing import Any
from urllib.parse import urlparse, urlunparse

import requests
from pytoniq.contract.contract import Contract
from pytoniq_core.boc.address import Address
from pytoniq_core.boc.builder import Builder
from pytoniq_core.boc.cell import Cell
from pytoniq_core.boc.slice import Slice
from pytoniq_core.tlb.custom.wallet import WalletMessage
from pytoniq_core.tlb.transaction import Transaction

from adapters.base_contract_opener import base_contract_opener
from adapters.opener_utils import get_http_endpoint
from interfaces.i_logger import ILogger
from sdk.consts import DEFAULT_FIND_TX_LIMIT, DEFAULT_HTTP_CLIENT_TIMEOUT_MS
from structs.struct import AddressInformation, ContractState, GetTransactionsOptions, Network
from wrappers.highload_wallet_v3 import highload_wallet_v3


def _normalize_hash_to_hex(hash_value: str) -> str:
    if not hash_value:
        return hash_value
    value = hash_value.strip()
    if value.startswith("0x"):
        value = value[2:]
    if re.fullmatch(r"[0-9a-fA-F]+", value) and len(value) % 2 == 0:
        return value.lower()
    if re.fullmatch(r"[A-Za-z0-9+/]+={0,2}", value) or re.fullmatch(r"[A-Za-z0-9_-]+={0,2}", value):
        try:
            normalized = value.replace("-", "+").replace("_", "/")
            padded = normalized + ("=" * ((4 - len(normalized) % 4) % 4))
            raw = base64.b64decode(padded, validate=True)
            if raw:
                return raw.hex()
        except Exception:
            pass
    return value


def _format_address(address: Any) -> str:
    addr = Address(address) if isinstance(address, str) else address
    if hasattr(addr, "to_str"):
        try:
            return addr.to_str(is_user_friendly=True, is_url_safe=True, is_bounceable=True, is_test_only=False)
        except Exception:
            return str(addr)
    return str(addr)


def _extract_stack_num(stack: list) -> int | None:
    if not stack:
        return None
    item = stack[0]
    if isinstance(item, list) and item:
        if item[0] == "num":
            value = item[1]
            if isinstance(value, str):
                if value.startswith("0x"):
                    return int(value, 16)
                return int(value)
            return int(value)
    return None


def _format_stack_num(value: int) -> str:
    return hex(value) if value >= 0 else f"-0x{abs(value):x}"


def _serialize_stack_item(value: Any) -> Any:
    if isinstance(value, list) and len(value) >= 2 and isinstance(value[0], str):
        return value
    if isinstance(value, tuple) and len(value) >= 2 and isinstance(value[0], str):
        return [value[0], value[1]]
    if isinstance(value, bool):
        return ["num", _format_stack_num(1 if value else 0)]
    if isinstance(value, int):
        return ["num", _format_stack_num(value)]
    if isinstance(value, Slice):
        boc = value.to_cell().to_boc()
        return ["tvm.Slice", base64.b64encode(boc).decode("utf-8")]
    if isinstance(value, Cell):
        return ["tvm.Cell", base64.b64encode(value.to_boc()).decode("utf-8")]
    if isinstance(value, Address):
        cell = Builder().store_address(value).end_cell()
        return ["tvm.Slice", base64.b64encode(cell.to_boc()).decode("utf-8")]
    return value


def _serialize_stack(stack: list[Any]) -> list[Any]:
    return [_serialize_stack_item(item) for item in stack]


class TonClientOpener(base_contract_opener):
    def __init__(
        self,
        endpoint: str,
        timeout: int = DEFAULT_HTTP_CLIENT_TIMEOUT_MS,
        api_key: str | None = None,
        logger: ILogger | None = None,
    ) -> None:
        super().__init__(logger)
        self.endpoint = endpoint.rstrip("/")
        self.timeout = timeout
        self.api_key = api_key
        self._resolved_rpc_endpoint: str | None = None

    @staticmethod
    def create(
        endpoint: str,
        timeout: int = DEFAULT_HTTP_CLIENT_TIMEOUT_MS,
        api_key: str | None = None,
        logger: ILogger | None = None,
    ) -> ton_client_opener:
        return ton_client_opener(endpoint=endpoint, timeout=timeout, api_key=api_key, logger=logger)

    def open(self, src: Any) -> Any:
        if _is_wallet_contract(src):
            return _TonClientWalletProxy(self, src)
        bind_opener = getattr(src, "bind_opener", None)
        if callable(bind_opener):
            return bind_opener(self)
        return src

    async def getContractState(self, address: Any) -> ContractState:
        info = self._get_address_information_raw(address)
        balance = int(info.get("balance") or 0)
        state = info.get("state") or "uninitialized"
        code = info.get("code") or ""
        code_bytes = base64.b64decode(code) if code else None
        return {"balance": balance, "state": state, "code": code_bytes}

    async def getTransactions(self, address: Any, opts: GetTransactionsOptions) -> list[Transaction]:
        params: dict[str, Any] = {
            "address": _format_address(address),
            "limit": opts.get("limit", DEFAULT_FIND_TX_LIMIT),
        }
        if opts.get("lt"):
            params["lt"] = str(opts.get("lt"))
        if opts.get("hash"):
            params["hash"] = _normalize_hash_to_hex(str(opts.get("hash")))
        if opts.get("to_lt"):
            params["to_lt"] = str(opts.get("to_lt"))
        if "archival" in opts:
            params["archival"] = opts.get("archival")

        result = self._json_rpc("getTransactions", params, timeout_ms=opts.get("timeoutMs"))
        transactions: list[Transaction] = []
        for tx in result:
            data = tx.get("data")
            if not data:
                continue
            cell = Cell.one_from_boc(base64.b64decode(data))
            transactions.append(Transaction.deserialize(cell.begin_parse()))
        return transactions

    async def getAddressInformation(self, address: Any) -> AddressInformation:
        info = self._get_address_information_raw(address)
        last = info.get("last_transaction_id") or {}
        return {
            "lastTransaction": {
                "lt": last.get("lt", "") or "",
                "hash": last.get("hash", "") or "",
            }
        }

    async def getConfig(self) -> str:
        info = self._json_rpc("getMasterchainInfo", {}, timeout_ms=self.timeout)
        seqno = info.get("last", {}).get("seqno")
        if seqno is None:
            raise RuntimeError("Failed to get masterchain seqno for config fetch")

        rpc_endpoint = self._resolved_rpc_endpoint or self.endpoint
        url = _build_config_all_url(rpc_endpoint)
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["X-API-Key"] = self.api_key
        response = requests.get(url, params={"seqno": seqno}, headers=headers, timeout=60)
        response.raise_for_status()
        body = response.json()
        config_bytes = body.get("result", {}).get("config", {}).get("bytes") if body.get("ok") else None
        if not config_bytes:
            raise RuntimeError(f"Failed to fetch config: {json.dumps(body)}")
        return config_bytes

    async def raw_send_message(self, boc: bytes) -> Any:
        return self._send_boc(boc)

    def _get_address_information_raw(self, address: Any) -> dict:
        return self._json_rpc("getAddressInformation", {"address": _format_address(address)}, timeout_ms=self.timeout)

    def _json_rpc(self, method: str, params: dict, timeout_ms: int | None = None) -> Any:
        payload = {"id": "1", "jsonrpc": "2.0", "method": method, "params": params}
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["X-API-Key"] = self.api_key
        read_timeout_sec = max((timeout_ms or self.timeout) / 1000, 1.0)
        timeout = (read_timeout_sec, read_timeout_sec)
        last_error: Exception | None = None

        for endpoint in self._get_rpc_endpoints():
            try:
                response = requests.post(endpoint, json=payload, headers=headers, timeout=timeout)
                if response.status_code in (404, 405):
                    if self.logger:
                        self.logger.debug(
                            f"[TonClientOpener] endpoint '{endpoint}' rejected method '{method}' "
                            f"with HTTP {response.status_code}, trying next endpoint"
                        )
                    continue
                data: Any | None = None
                try:
                    data = response.json()
                except Exception:
                    data = None

                if isinstance(data, dict) and "ok" in data:
                    if not data.get("ok"):
                        error_code_raw = data.get("code", response.status_code)
                        try:
                            error_code = int(error_code_raw)
                        except Exception:
                            error_code = response.status_code
                        err = RuntimeError(f"Toncenter error ({response.status_code}): {json.dumps(data)}")
                        if error_code == 429 or error_code >= 500:
                            if self.logger:
                                self.logger.debug(
                                    f"[TonClientOpener] transient error on endpoint '{endpoint}' "
                                    f"for '{method}' (code={error_code}), trying next endpoint"
                                )
                            last_error = err
                            continue
                        raise err
                    self._resolved_rpc_endpoint = endpoint
                    return data.get("result")

                if response.status_code >= 400:
                    err = RuntimeError(
                        f"HTTP {response.status_code} from '{endpoint}' for '{method}': {response.text[:300]}"
                    )
                    if response.status_code == 429 or response.status_code >= 500:
                        if self.logger:
                            self.logger.debug(
                                f"[TonClientOpener] transient HTTP {response.status_code} on endpoint "
                                f"'{endpoint}' for '{method}', trying next endpoint"
                            )
                        last_error = err
                        continue
                    raise err
            except Exception as exc:
                if self.logger:
                    self.logger.debug(
                        f"[TonClientOpener] request failed for endpoint '{endpoint}', "
                        f"method '{method}': {exc}"
                    )
                last_error = exc
                continue

        raise RuntimeError(f"Failed to call JSON-RPC method '{method}' on endpoint '{self.endpoint}'") from last_error

    def _get_rpc_endpoints(self) -> list[str]:
        base = self.endpoint.rstrip("/")
        candidates: list[str] = []
        if self._resolved_rpc_endpoint:
            candidates.append(self._resolved_rpc_endpoint)
        if base:
            candidates.append(base)
            stripped = _strip_rpc_suffix(base)
            root = (stripped or base).rstrip("/")
            if root and root != base:
                candidates.append(root)
            candidates.append(root + "/api/v2/jsonRPC")
            candidates.append(root + "/jsonRPC")

        unique: list[str] = []
        seen: set[str] = set()
        for item in candidates:
            if item in seen:
                continue
            seen.add(item)
            unique.append(item)
        return unique

    def _send_boc(self, boc: bytes) -> Any:
        boc_b64 = base64.b64encode(boc).decode("utf-8")
        return self._json_rpc("sendBoc", {"boc": boc_b64}, timeout_ms=self.timeout)

    def _run_get_method(self, address: Any, method: str, stack: list[Any] | None = None) -> dict:
        serialized_stack = _serialize_stack(stack or [])
        return self._json_rpc(
            "runGetMethod",
            {"address": _format_address(address), "method": method, "stack": serialized_stack},
            timeout_ms=self.timeout,
        )


class _TonClientWalletProxy:
    def __init__(self, opener: ton_client_opener, wallet: Any):
        self._opener = opener
        self._wallet = wallet

    async def getSeqno(self) -> int:
        state = await self._opener.getContractState(self._wallet.address)
        if state.get("state") != "active":
            return 0
        result = self._opener._run_get_method(self._wallet.address, "seqno")
        stack = result.get("stack") or []
        seqno = _extract_stack_num(stack)
        if seqno is None:
            raise RuntimeError("Failed to parse seqno from runGetMethod response")
        return seqno

    async def send(self, msg: Cell, state_init: Any | None = None) -> str | None:
        init = state_init
        external = Contract.create_external_msg(dest=self._wallet.address, state_init=init, body=msg)
        boc = external.serialize().to_boc()
        self._opener._send_boc(boc)
        return base64.b64encode(boc).decode("utf-8")

    async def sendTransfer(self, **kwargs: Any) -> str:
        if not isinstance(self._wallet, highload_wallet_v3):
            raise ValueError("sendTransfer is supported only for highload_wallet_v3")

        messages = kwargs.get("messages") or []
        send_mode = kwargs.get("sendMode", 3)
        created_at = kwargs.get("createdAt")
        secret_key = kwargs.get("secretKey")
        if secret_key is None:
            raise ValueError("secretKey is required")

        wallet_messages = [WalletMessage(send_mode, msg) for msg in messages]

        subwallet_id = self._wallet.subwallet_id
        timeout = self._wallet.timeout
        state_init = None
        try:
            state = await self._opener.getContractState(self._wallet.address)
            if state.get("state") == "active":
                try:
                    stack = self._opener._run_get_method(self._wallet.address, "get_subwallet_id").get("stack") or []
                    subwallet_id = _extract_stack_num(stack) or subwallet_id
                except Exception:
                    pass
                try:
                    stack = self._opener._run_get_method(self._wallet.address, "get_timeout").get("stack") or []
                    timeout = _extract_stack_num(stack) or timeout
                except Exception:
                    pass
            else:
                state_init = self._wallet.init
        except Exception:
            state_init = self._wallet.init

        query_id = self._wallet.getQueryIdFromCreatedAt(created_at or highload_wallet_v3.generate_created_at())
        body = self._wallet.create_transfer_body(
            secret_key=secret_key,
            messages=wallet_messages,
            created_at=created_at,
            query_id=query_id,
            timeout=timeout,
            subwallet_id=subwallet_id,
        )
        external = Contract.create_external_msg(dest=self._wallet.address, state_init=state_init, body=body)
        boc = external.serialize().to_boc()
        self._opener._send_boc(boc)
        return base64.b64encode(boc).decode("utf-8")


async def orbs_opener(network: Network, logger: ILogger | None = None) -> ton_client_opener:
    endpoint = await get_http_endpoint(network)
    return ton_client_opener.create(endpoint, logger=logger)


def _build_config_all_url(endpoint: str) -> str:
    parsed = urlparse(endpoint.strip())
    path = parsed.path.rstrip("/")
    if path.endswith("/jsonRPC"):
        path = path[: -len("/jsonRPC")]
    if not path:
        path = ""
    config_path = f"{path}/getConfigAll"
    return urlunparse((parsed.scheme, parsed.netloc, config_path, "", "", ""))


def _strip_rpc_suffix(endpoint: str) -> str:
    normalized = endpoint.rstrip("/")
    if normalized.endswith("/api/v2/jsonRPC"):
        return normalized[: -len("/api/v2/jsonRPC")]
    if normalized.endswith("/jsonRPC"):
        return normalized[: -len("/jsonRPC")]
    return normalized


def _is_wallet_contract(src: Any) -> bool:
    if not hasattr(src, "address"):
        return False
    return (
        hasattr(src, "createTransfer")
        or hasattr(src, "create_transfer")
        or hasattr(src, "create_transfer_body")
        or hasattr(src, "public_key")
        or hasattr(src, "init")
    )

ton_client_opener = TonClientOpener
_ton_client_wallet_proxy = _TonClientWalletProxy
