"""Packaged TAC artifacts bundle and network metadata."""
