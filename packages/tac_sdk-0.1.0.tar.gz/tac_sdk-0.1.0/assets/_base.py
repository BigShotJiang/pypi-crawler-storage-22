from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Any, cast

from structs.struct import AssetType, Origin


def _calculate_raw_amount(amount: float, decimals: int) -> int:
    integer_part, dot, fractional_part = f"{amount}".partition(".")
    padded_fraction = (fractional_part or "").ljust(decimals, "0")[:decimals]
    return int(f"{integer_part}{padded_fraction}" or "0")


@dataclass
class BaseAsset:
    address: str
    type: AssetType
    origin: Origin
    rawAmount: int = 0
    decimals: int = 0

    @property
    def clone(self) -> BaseAsset:
        cloned = copy.copy(self)
        addresses = getattr(cloned, "addresses", None)
        if isinstance(addresses, dict):
            cast(Any, cloned).addresses = dict(addresses)
        return cloned

    def withAmount(self, amount: float) -> BaseAsset:
        cloned = self.clone
        cloned.rawAmount = _calculate_raw_amount(amount, self.decimals)
        return cloned

    def withRawAmount(self, rawAmount: int) -> BaseAsset:
        cloned = self.clone
        cloned.rawAmount = int(rawAmount)
        return cloned

    def addAmount(self, amount: float) -> BaseAsset:
        cloned = self.clone
        cloned.rawAmount = self.rawAmount + _calculate_raw_amount(amount, self.decimals)
        return cloned

    def addRawAmount(self, rawAmount: int) -> BaseAsset:
        cloned = self.clone
        cloned.rawAmount = self.rawAmount + int(rawAmount)
        return cloned

    async def getEVMAddress(self) -> str:
        return self.address

    async def getTVMAddress(self) -> str:
        return self.address

    def generatePayload(self, params: object) -> object:
        raise NotImplementedError("generatePayload requires ton SDK")

    async def checkCanBeTransferredBy(self, userAddress: str) -> None:
        raise NotImplementedError("checkCanBeTransferredBy requires ton SDK")

    async def getBalanceOf(self, userAddress: str) -> int:
        raise NotImplementedError("getBalanceOf requires ton SDK")
