from __future__ import annotations

from collections.abc import Mapping

from interfaces.asset import Asset


class AssetCache:
    _cache: dict[str, Asset] = {}

    @staticmethod
    def get(token: Mapping[str, object]) -> Asset | None:
        key = AssetCache._generate_key(token)
        return AssetCache._cache.get(key)

    @staticmethod
    def set(token: Mapping[str, object], asset: Asset) -> None:
        key = AssetCache._generate_key(token)
        AssetCache._cache[key] = asset

    @staticmethod
    def clear() -> None:
        AssetCache._cache.clear()

    @staticmethod
    def _generate_key(token: Mapping[str, object]) -> str:
        normalized_address = str(token.get("address") or "").lower()
        parts = [normalized_address]
        if token.get("index") is not None:
            parts.append(str(token["index"]))
        return "|".join(parts)
