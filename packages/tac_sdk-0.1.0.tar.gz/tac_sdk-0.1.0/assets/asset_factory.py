from __future__ import annotations

from errors import index_required_error, unknown_token_type_error
from interfaces.asset import Asset
from interfaces.i_configuration import IConfiguration
from structs.struct import (
    AssetFromFTArg,
    AssetFromNFTCollectionArg,
    AssetFromNFTItemArg,
    AssetType,
    NFTAddressType,
)

from .asset_cache import AssetCache
from .ft import Ft
from .nft import Nft
from .ton import Ton


class AssetFactory:
    @staticmethod
    async def from_(
        configuration: IConfiguration,
        token: AssetFromFTArg | AssetFromNFTCollectionArg | AssetFromNFTItemArg,
    ) -> Ton | Asset:
        address = token.get("address", "")
        if address in ("", configuration.nativeTONAddress):
            if token.get("tokenType") != AssetType.FT:
                raise unknown_token_type_error(address, "detected ton, but token type is not ft")
            return Ton.create(configuration)

        cached = AssetCache.get(token)
        if cached:
            return cached.clone.withRawAmount(0)

        if token.get("tokenType") == AssetType.FT:
            token_asset = await AssetFactory.create_ft_asset(configuration, address)
        else:
            address_type = token.get("addressType")
            if address_type is None:
                address_type = NFTAddressType.ITEM
            token_asset = await AssetFactory.create_nft_asset(
                configuration,
                address,
                address_type,
                token.get("index"),
            )

        AssetCache.set(token, token_asset)
        return token_asset

    @staticmethod
    async def create_ft_asset(configuration: IConfiguration, address: str) -> Asset:
        native_ton_asset = Ton.create(configuration)
        ton_evm_address = ""
        try:
            ton_evm_address = await native_ton_asset.getEVMAddress()
        except Exception:
            ton_evm_address = ""

        if address in (configuration.nativeTONAddress, "", ton_evm_address):
            return native_ton_asset
        return await Ft.from_address(configuration, address)

    @staticmethod
    async def create_nft_asset(
        configuration: IConfiguration, address: str, address_type: NFTAddressType, index: int | None = None
    ) -> Asset:
        if address_type == NFTAddressType.ITEM:
            return await Nft.fromItem(configuration, address)

        if address_type == NFTAddressType.COLLECTION:
            if index is None:
                raise index_required_error(address)
            return await Nft.fromCollection(configuration, {"collection": address, "index": index})

        raise unknown_token_type_error(address, "nft address type is unknown: should be either ITEM or COLLECTION")
