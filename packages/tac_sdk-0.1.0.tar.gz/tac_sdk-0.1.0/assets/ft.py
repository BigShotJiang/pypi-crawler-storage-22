from __future__ import annotations

from dataclasses import dataclass
from typing import Any, cast

from pytoniq_core.boc.address import Address
from pytoniq_core.boc.builder import Builder
from pytoniq_core.boc.cell import Cell
from web3 import Web3

from errors import contract_error, empty_contract_error
from errors.instances import (
    insufficient_balance_error,
    missing_decimals,
    missing_jetton_data_error,
    unknown_token_type_error,
)
from interfaces.i_configuration import IConfiguration
from sdk.consts import JETTON_TRANSFER_FORWARD_TON_AMOUNT, TAC_DECIMALS, TON_DECIMALS
from sdk.utils import (
    calculate_amount,
    calculate_contract_address,
    calculate_raw_amount,
    generate_fee_data,
    generate_random_number_by_timestamp,
)
from sdk.validator import Validator
from structs.struct import (
    AssetType,
    EVMAddress,
    FeeParams,
    FtOriginAndData,
    Origin,
    TVMAddress,
    UserWalletBalanceExists,
    UserWalletBalanceExtended,
    UserWalletBalanceMissing,
)
from ton_get_methods.client import TonGetMethodClient
from wrappers.content_utils import read_jetton_metadata
from wrappers.jetton_minter import JettonMinter
from wrappers.jetton_wallet import JettonWallet

from ._base import BaseAsset


@dataclass
class Ft(BaseAsset):
    _configuration: IConfiguration | None = None
    _evmAddress: str | None = None

    def __init__(self, address: TVMAddress, origin: Origin, configuration: IConfiguration | None, decimals: int):
        super().__init__(address=address, type=AssetType.FT, origin=origin, rawAmount=0, decimals=decimals)
        self._configuration = configuration

    @property
    def clone(self) -> Ft:
        cloned = Ft(self.address, self.origin, self._configuration, int(self.decimals))
        cloned.rawAmount = int(self.rawAmount)
        cloned._evmAddress = self._evmAddress
        return cloned

    def withAmount(self, amount: float) -> Ft:
        if self.rawAmount > 0:
            cloned = self.clone
            cloned.rawAmount = calculate_raw_amount(amount, int(self.decimals))
            return cloned
        self.rawAmount = calculate_raw_amount(amount, int(self.decimals))
        return self

    def withRawAmount(self, rawAmount: int) -> Ft:
        if self.rawAmount > 0:
            cloned = self.clone
            cloned.rawAmount = int(rawAmount)
            return cloned
        self.rawAmount = int(rawAmount)
        return self

    def addAmount(self, amount: float) -> Ft:
        self.rawAmount = int(self.rawAmount) + calculate_raw_amount(amount, int(self.decimals))
        return self

    def addRawAmount(self, rawAmount: int) -> Ft:
        self.rawAmount = int(self.rawAmount) + int(rawAmount)
        return self

    @staticmethod
    def _get_contract_opener(configuration: IConfiguration) -> Any:
        opener = configuration.TONParams.get("contractOpener")
        if opener is None:
            raise RuntimeError("contractOpener is required")
        return opener

    @staticmethod
    def _open_jetton_minter(configuration: IConfiguration, address: TVMAddress) -> Any:
        opener = Ft._get_contract_opener(configuration)
        return opener.open(JettonMinter.createFromAddress(Address(address)))

    @staticmethod
    def _open_jetton_wallet(configuration: IConfiguration, address: TVMAddress) -> Any:
        opener = Ft._get_contract_opener(configuration)
        return opener.open(JettonWallet.createFromAddress(Address(address)))

    async def getJettonData(self) -> Any:
        if not self._configuration:
            raise RuntimeError("configuration is required")
        return await Ft._open_jetton_minter(self._configuration, self.address).getJettonData()

    @staticmethod
    async def getOrigin(configuration: IConfiguration, address: TVMAddress) -> Origin:
        result = await Ft.getOriginAndData(configuration, address)
        return result.get("origin", Origin.TON)

    @staticmethod
    async def getOriginAndData(configuration: IConfiguration, address: TVMAddress) -> FtOriginAndData:
        ton_params = configuration.TONParams
        contract_opener = ton_params.get("contractOpener")
        if contract_opener is None:
            return {"origin": Origin.TON}
        jetton_minter = Ft._open_jetton_minter(configuration, address)

        state = await contract_opener.getContractState(Address(address))
        if not state.get("code"):
            raise empty_contract_error

        code_cell = Cell.one_from_boc(state["code"])  # returns first cell
        if isinstance(code_cell, list):
            code_cell = code_cell[0]

        jetton_minter_code = ton_params.get("jettonMinterCode")
        if not jetton_minter_code:
            jetton_data = await jetton_minter.getJettonData()
            return {"origin": Origin.TON, "jettonMinter": jetton_minter, "jettonData": jetton_data}

        expected_code = jetton_minter_code
        if isinstance(expected_code, bytes):
            expected_code = Cell.one_from_boc(expected_code)
            expected_code = expected_code[0] if isinstance(expected_code, list) else expected_code

        if expected_code.hash != code_cell.hash:
            jetton_data = await jetton_minter.getJettonData()
            return {"origin": Origin.TON, "jettonMinter": jetton_minter, "jettonData": jetton_data}

        evm_address = await jetton_minter.getEVMTokenAddress()

        cross_chain_layer = ton_params.get("crossChainLayerAddress")
        jetton_wallet_code = ton_params.get("jettonWalletCode")
        if isinstance(jetton_wallet_code, bytes):
            jetton_wallet_code = Cell.one_from_boc(jetton_wallet_code)
            jetton_wallet_code = jetton_wallet_code[0] if isinstance(jetton_wallet_code, list) else jetton_wallet_code

        if not cross_chain_layer or not jetton_wallet_code or not evm_address:
            jetton_data = await jetton_minter.getJettonData()
            return {"origin": Origin.TON, "jettonMinter": jetton_minter, "jettonData": jetton_data}

        data = (
            Builder()
            .store_coins(0)
            .store_address(Address(cross_chain_layer))
            .store_address(None)
            .store_ref(Builder().end_cell())
            .store_ref(jetton_wallet_code)
            .store_snake_string(evm_address)
            .end_cell()
        )
        expected_address = calculate_contract_address(expected_code, data)
        if expected_address.to_str(is_user_friendly=True, is_bounceable=True) != Address(address).to_str(is_user_friendly=True, is_bounceable=True):
            jetton_data = await jetton_minter.getJettonData()
            return {"origin": Origin.TON, "jettonMinter": jetton_minter, "jettonData": jetton_data}

        return {"origin": Origin.TAC, "jettonMinter": jetton_minter, "evmAddress": evm_address}

    @staticmethod
    async def _resolve_tvm_address(configuration: IConfiguration, address: EVMAddress) -> str:
        # Resolve EVM token into TON jetton master, mirroring TS logic.
        Validator.validate_evm_address(str(address))

        token_utils = configuration.TACParams.get("tokenUtils") if configuration.TACParams else None
        if token_utils is None or not hasattr(token_utils, "exists"):
            raise unknown_token_type_error(address, "TAC token utils are not configured")

        from_tvm = await TonGetMethodClient.await_maybe(token_utils.exists(address))
        if from_tvm:
            provider = configuration.TACParams.get("provider") if configuration.TACParams else None
            if provider is None:
                raise unknown_token_type_error(address, "TAC provider is not configured")

            artifacts = configuration.artifacts
            ccl_erc20_abi: Any = None
            if isinstance(artifacts, dict):
                ccl_erc20_abi = (
                    artifacts.get("tac", {})
                    .get("compilationArtifacts", {})
                    .get("ICrossChainLayerERC20", {})
                    .get("abi")
                )
            else:
                tac = getattr(artifacts, "tac", None)
                compilation = getattr(tac, "compilationArtifacts", None)
                token_entry = getattr(compilation, "ICrossChainLayerERC20", None)
                ccl_erc20_abi = getattr(token_entry, "abi", None)

            if not isinstance(ccl_erc20_abi, list):
                raise unknown_token_type_error(address, "ICrossChainLayerERC20 ABI is not configured")

            token_contract = cast(Any, provider.eth).contract(
                address=Web3.to_checksum_address(str(address)),
                abi=ccl_erc20_abi,
            )
            info = token_contract.functions.getInfo().call()
            if isinstance(info, dict):
                tvm_address = info.get("tvmAddress")
            elif isinstance(info, (list, tuple)) and len(info) >= 4:
                tvm_address = info[3]
            else:
                tvm_address = getattr(info, "tvmAddress", None)
            if not tvm_address:
                raise unknown_token_type_error(address, "Missing tvmAddress in ERC20 info")
            return str(tvm_address)

        ton_params = configuration.TONParams or {}
        cross_chain_layer = ton_params.get("crossChainLayerAddress")
        jetton_wallet_code = ton_params.get("jettonWalletCode")
        jetton_minter_code = ton_params.get("jettonMinterCode")
        if not cross_chain_layer or not jetton_wallet_code or not jetton_minter_code:
            raise unknown_token_type_error(address, "Unable to resolve TVM address from EVM token")

        if isinstance(jetton_wallet_code, bytes):
            jetton_wallet_code = Cell.one_from_boc(jetton_wallet_code)
            jetton_wallet_code = jetton_wallet_code[0] if isinstance(jetton_wallet_code, list) else jetton_wallet_code
        if isinstance(jetton_minter_code, bytes):
            jetton_minter_code = Cell.one_from_boc(jetton_minter_code)
            jetton_minter_code = jetton_minter_code[0] if isinstance(jetton_minter_code, list) else jetton_minter_code

        data = (
            Builder()
            .store_coins(0)
            .store_address(Address(cross_chain_layer))
            .store_address(None)
            .store_ref(Builder().end_cell())
            .store_ref(jetton_wallet_code)
            .store_snake_string(str(address))
            .end_cell()
        )
        jetton_master = calculate_contract_address(jetton_minter_code, data)
        return jetton_master.to_str(is_user_friendly=True, is_bounceable=True)

    @staticmethod
    async def _resolve_evm_address(configuration: IConfiguration, address: TVMAddress) -> str:
        token_utils = configuration.TACParams.get("tokenUtils") if configuration.TACParams else None
        if token_utils and hasattr(token_utils, "computeAddress"):
            return str(await TonGetMethodClient.await_maybe(token_utils.computeAddress(address)))
        return address

    @staticmethod
    async def getTACDecimals(configuration: IConfiguration, evmAddress: EVMAddress) -> int:  # noqa: N802
        native_tac_address = await TonGetMethodClient.await_maybe(configuration.nativeTACAddress())
        if str(native_tac_address).lower() == str(evmAddress).lower():
            return TAC_DECIMALS

        provider = configuration.TACParams.get("provider") if configuration.TACParams else None
        if provider is None:
            raise unknown_token_type_error(str(evmAddress), "TAC provider is not configured")

        artifacts = configuration.artifacts
        erc20_abi: Any = None
        if isinstance(artifacts, dict):
            erc20_abi = (
                artifacts.get("tac", {})
                .get("compilationArtifacts", {})
                .get("IERC20WithDecimals", {})
                .get("abi")
            )
        else:
            tac = getattr(artifacts, "tac", None)
            compilation = getattr(tac, "compilationArtifacts", None)
            token_entry = getattr(compilation, "IERC20WithDecimals", None)
            erc20_abi = getattr(token_entry, "abi", None)

        if not isinstance(erc20_abi, list):
            raise unknown_token_type_error(str(evmAddress), "IERC20WithDecimals ABI is not configured")

        erc20_token = cast(Any, provider.eth).contract(
            address=Web3.to_checksum_address(str(evmAddress)),
            abi=erc20_abi,
        )
        decimals = erc20_token.functions.decimals().call()
        if decimals is None:
            raise missing_decimals
        return int(decimals)

    @staticmethod
    async def from_address(configuration: IConfiguration, address: TVMAddress | EVMAddress) -> Ft:
        is_evm = str(address).startswith("0x")
        tvm_address = await Ft._resolve_tvm_address(configuration, address) if is_evm else str(address)

        origin_and_data: FtOriginAndData
        try:
            origin_and_data = await Ft.getOriginAndData(configuration, tvm_address)
        except contract_error:
            jetton_minter = Ft._open_jetton_minter(configuration, tvm_address)
            origin_and_data = {
                "origin": Origin.TAC,
                "jettonMinter": jetton_minter,
                "evmAddress": str(address) if is_evm else None,
                "jettonData": None,
            }
        resolved_origin_raw = origin_and_data.get("origin", Origin.TON)
        if isinstance(resolved_origin_raw, Origin):
            resolved_origin = resolved_origin_raw
        elif resolved_origin_raw == Origin.TAC.value:
            resolved_origin = Origin.TAC
        else:
            resolved_origin = Origin.TON
        jetton_data = origin_and_data.get("jettonData")
        jetton_minter = origin_and_data.get("jettonMinter")
        evm_address = origin_and_data.get("evmAddress")

        final_evm_address: str | None = None
        if resolved_origin == Origin.TON:
            if not jetton_data:
                raise missing_jetton_data_error
            if not isinstance(jetton_data, dict):
                raise missing_jetton_data_error
            try:
                metadata = read_jetton_metadata(jetton_data.get("content"))
                metadata_dict = metadata if isinstance(metadata, dict) else {}
                metadata_payload = metadata_dict.get("metadata")
                decimals_raw = metadata_payload.get("decimals") if isinstance(metadata_payload, dict) else None
                if decimals_raw is None:
                    decimals = TON_DECIMALS
                else:
                    decimals = int(decimals_raw)
            except Exception:
                decimals = TON_DECIMALS
        else:
            if is_evm:
                final_evm_address = str(address)
            else:
                if evm_address:
                    final_evm_address = str(evm_address)
                else:
                    minter = jetton_minter or Ft._open_jetton_minter(configuration, tvm_address)
                    final_evm_address = str(await minter.getEVMTokenAddress())
            decimals = await Ft.getTACDecimals(configuration, final_evm_address)

        token = Ft(tvm_address, resolved_origin, configuration, decimals)
        if final_evm_address or evm_address or is_evm:
            token._evmAddress = str(final_evm_address or evm_address or address)
        return token

    async def getEVMAddress(self) -> str:
        if self._evmAddress:
            return self._evmAddress
        if self.origin == Origin.TON:
            token_utils = self._configuration.TACParams.get("tokenUtils") if self._configuration and self._configuration.TACParams else None
            if token_utils and hasattr(token_utils, "computeAddress"):
                self._evmAddress = await token_utils.computeAddress(self.address)
                return str(self._evmAddress)
        if self.origin == Origin.TAC:
            if self._configuration is None:
                raise RuntimeError("configuration is required for TAC assets")
            self._evmAddress = await self._get_evm_token_address(self._configuration, self.address)
            return self._evmAddress
        raise unknown_token_type_error(self.address, "Token origin is neither ton nor TAC")

    async def getTVMAddress(self) -> str:
        return self.address

    async def getUserWalletAddress(self, userAddress: str) -> str:
        if self._configuration is None:
            raise RuntimeError("configuration is required")
        jetton_minter = Ft._open_jetton_minter(self._configuration, self.address)
        wallet_address = await jetton_minter.getWalletAddress(Address(userAddress))
        return wallet_address.to_str(is_user_friendly=True, is_url_safe=True, is_bounceable=True, is_test_only=False)

    async def getWallet(self, userAddress: str) -> Any:  # noqa: N802
        if self._configuration is None:
            raise RuntimeError("configuration is required")
        wallet_address = await self.getUserWalletAddress(userAddress)
        return Ft._open_jetton_wallet(self._configuration, wallet_address)

    async def _get_user_wallet_and_balance(self, userAddress: str) -> tuple[str, int]:
        wallet_addr = await self.getUserWalletAddress(userAddress)
        if not wallet_addr:
            return "", 0
        if self._configuration is None:
            raise RuntimeError("configuration is required")
        try:
            jetton_wallet = Ft._open_jetton_wallet(self._configuration, wallet_addr)
            return wallet_addr, int(await jetton_wallet.getJettonBalance())
        except Exception:
            return wallet_addr, 0

    async def getUserBalance(self, userAddress: str) -> int:
        _, balance = await self._get_user_wallet_and_balance(userAddress)
        return balance

    async def getUserBalanceExtended(self, userAddress: str) -> UserWalletBalanceExtended:
        if self._configuration is None:
            raise RuntimeError("configuration is required")

        opener = self._configuration.TONParams.get("contractOpener")
        if opener is None:
            raise RuntimeError("contractOpener is required")

        state = await opener.getContractState(Address(self.address))
        if state.get("state") != "active":
            missing: UserWalletBalanceMissing = {"exists": False}
            return missing

        raw_amount = await self.getUserBalance(userAddress)
        decimals = int(self.decimals)
        existing: UserWalletBalanceExists = {
            "exists": True,
            "rawAmount": int(raw_amount),
            "decimals": decimals,
            "amount": calculate_amount(int(raw_amount), decimals),
        }
        return existing

    async def checkCanBeTransferredBy(self, userAddress: str) -> None:
        wallet_addr, balance = await self._get_user_wallet_and_balance(userAddress)
        if balance < self.rawAmount:
            raise insufficient_balance_error(
                self.address,
                owner_address=userAddress,
                wallet_address=wallet_addr or None,
                current_balance=balance,
                required_balance=self.rawAmount,
            )

    async def getBalanceOf(self, userAddress: str) -> int:
        return await self.getUserBalance(userAddress)

    def generatePayload(self, params: object):
        p = cast(dict[str, Any], params)
        excess_receiver = p.get("excessReceiver")
        evm_data = p.get("evmData")
        cross_chain_ton_amount = int(p.get("crossChainTonAmount") or 0)
        forward_fee_ton_amount = int(p.get("forwardFeeTonAmount") or 0)
        fee_params: FeeParams | None = p.get("feeParams")

        fee_data = generate_fee_data(fee_params)
        if self.origin == Origin.TAC:
            ccl = self._configuration.TONParams.get("crossChainLayerAddress") if self._configuration else None
            if not ccl:
                raise RuntimeError("crossChainLayerAddress is not configured")
            return self._get_burn_payload(self.rawAmount, ccl, cast(Cell | None, evm_data), cross_chain_ton_amount, fee_data)
        proxy = self._configuration.TONParams.get("jettonProxyAddress") if self._configuration else None
        if not proxy:
            raise RuntimeError("jettonProxyAddress is not configured")
        return self._get_transfer_payload(
            self.rawAmount,
            proxy,
            str(excess_receiver or ""),
            cast(Cell | None, evm_data),
            cross_chain_ton_amount,
            forward_fee_ton_amount,
            fee_data,
        )

    def _get_transfer_payload(
        self,
        raw_amount: int,
        notification_receiver: str,
        response_address: str,
        evm_data: Cell | None,
        cross_chain_ton_amount: int,
        forward_fee_amount: int,
        fee_data: Cell | None,
    ) -> Cell:
        query_id = generate_random_number_by_timestamp()["randomNumber"]
        forward_payload = (
            Builder()
            .store_coins(cross_chain_ton_amount)
            .store_maybe_ref(fee_data)
            .store_maybe_ref(evm_data)
            .end_cell()
        )

        return (
            Builder()
            .store_uint(0x0F8A7EA5, 32)
            .store_uint(query_id, 64)
            .store_coins(raw_amount)
            .store_address(Address(notification_receiver))
            .store_address(Address(response_address))
            .store_maybe_ref(None)
            .store_coins(JETTON_TRANSFER_FORWARD_TON_AMOUNT + forward_fee_amount + cross_chain_ton_amount)
            .store_bit(1)
            .store_ref(forward_payload)
            .end_cell()
        )

    def _get_burn_payload(
        self,
        raw_amount: int,
        notification_receiver: str,
        evm_data: Cell | None,
        cross_chain_ton_amount: int,
        fee_data: Cell | None,
    ) -> Cell:
        query_id = generate_random_number_by_timestamp()["randomNumber"]
        custom_payload = None
        if cross_chain_ton_amount or evm_data is not None:
            custom_payload = (
                Builder()
                .store_coins(cross_chain_ton_amount)
                .store_maybe_ref(fee_data)
                .store_maybe_ref(evm_data)
                .end_cell()
            )
        return (
            Builder()
            .store_uint(0x595F07BC, 32)
            .store_uint(query_id, 64)
            .store_coins(raw_amount)
            .store_address(Address(notification_receiver))
            .store_maybe_ref(custom_payload)
            .end_cell()
        )

    @staticmethod
    async def _get_evm_token_address(configuration: IConfiguration, address: TVMAddress) -> str:
        try:
            jetton_minter = Ft._open_jetton_minter(configuration, address)
            return await jetton_minter.getEVMTokenAddress()
        except Exception as exc:
            raise unknown_token_type_error(address, "Missing get_evm_token_address") from exc
