from __future__ import annotations

from typing import Any, cast

from pytoniq_core.boc.address import Address
from pytoniq_core.boc.builder import Builder
from pytoniq_core.boc.cell import Cell
from web3 import Web3

from errors import contract_error
from errors.instances import empty_contract_error, insufficient_balance_error, unknown_token_type_error
from interfaces.i_configuration import IConfiguration
from sdk.consts import NFT_TRANSFER_FORWARD_TON_AMOUNT
from sdk.utils import generate_fee_data, generate_random_number_by_timestamp
from sdk.validator import Validator
from structs.internal_struct import AssetOpType
from structs.struct import AssetType, EVMAddress, FeeParams, Origin, TVMAddress
from ton_get_methods.client import TonGetMethodClient
from wrappers.nft_collection import NftCollection
from wrappers.nft_item import NftItem

from ._base import BaseAsset


class Nft(BaseAsset):
    addresses: dict
    _configuration: IConfiguration | None = None

    def __init__(self, addresses: dict, origin: Origin, configuration: IConfiguration | None):
        super().__init__(address=addresses.get("item", ""), type=AssetType.NFT, origin=origin, rawAmount=1, decimals=0)
        self.addresses = addresses
        self._configuration = configuration

    @property
    def clone(self) -> Nft:
        return Nft(dict(self.addresses), self.origin, self._configuration)

    # NFTs are non-fungible; keep the API shape but preserve invariant rawAmount=1.
    def withAmount(self, amount: float) -> Nft:
        _ = amount
        return self

    def withRawAmount(self, rawAmount: int) -> Nft:
        _ = rawAmount
        return self

    def addAmount(self, amount: float) -> Nft:
        _ = amount
        return self

    def addRawAmount(self, rawAmount: int) -> Nft:
        _ = rawAmount
        return self

    @staticmethod
    def _get_contract_opener(configuration: IConfiguration) -> Any:
        opener = configuration.TONParams.get("contractOpener")
        if opener is None:
            raise RuntimeError("contractOpener is required")
        return opener

    @staticmethod
    async def fromItem(configuration: IConfiguration, item: TVMAddress) -> Nft:
        Validator.validate_tvm_address(str(item))
        item_data = await Nft._get_item_data(configuration, item)
        collection = item_data.get("collectionAddress", "")
        index = int(item_data.get("index", 0))
        origin = await Nft.getOrigin(configuration, item)
        return Nft({"item": item, "collection": collection, "index": index}, origin, configuration)

    @staticmethod
    async def fromCollection(configuration: IConfiguration, item: dict) -> Nft:
        collection_input = str(item.get("collection", ""))
        index = int(item.get("index", 0))
        is_evm = collection_input.startswith("0x")
        collection = await Nft._resolve_tvm_address(configuration, collection_input) if is_evm else collection_input
        try:
            resolved_origin = await Nft.getOrigin(configuration, collection)
        except contract_error:
            resolved_origin = Origin.TAC
        if resolved_origin == Origin.TAC:
            ton_params = configuration.TONParams or {}
            nft_item_code = ton_params.get("nftItemCode")
            cross_chain_layer_address = ton_params.get("crossChainLayerAddress")
            if not nft_item_code or not cross_chain_layer_address:
                raise unknown_token_type_error(collection, "Unable to resolve TAC NFT item address from collection")
            nft_item = NftItem.createFromConfig(
                {
                    "collectionAddress": collection,
                    "cclAddress": cross_chain_layer_address,
                    "index": index,
                },
                nft_item_code,
            )
            item_address = nft_item.address.to_str(
                is_user_friendly=True,
                is_url_safe=True,
                is_bounceable=True,
                is_test_only=False,
            )
        else:
            item_address = await Nft.getItemAddress(configuration, collection, index)
        addresses: dict[str, Any] = {"item": item_address, "collection": collection, "index": index}
        if is_evm:
            addresses["evmAddress"] = collection_input
        return Nft(addresses, resolved_origin, configuration)

    @staticmethod
    async def _get_item_data(configuration: IConfiguration, itemAddress: TVMAddress) -> Any:
        opener = Nft._get_contract_opener(configuration)
        nft_item = opener.open(NftItem.createFromAddress(Address(itemAddress)))
        item_data = await nft_item.getNFTData()
        init = int(item_data.get("init", 0))
        index = int(item_data.get("index", 0))
        collection_address = item_data.get("collectionAddress")
        owner_address = item_data.get("ownerAddress")
        content = item_data.get("content")
        return {
            "init": init,
            "index": index,
            "collectionAddress": collection_address.to_str(is_user_friendly=True, is_url_safe=True, is_bounceable=True, is_test_only=False) if collection_address else "",
            "ownerAddress": owner_address,
            "content": content,
        }

    async def getItemData(self) -> Any:
        if not self._configuration:
            raise RuntimeError("configuration is required")
        return await Nft._get_item_data(self._configuration, self.addresses.get("item", ""))

    @staticmethod
    async def _get_collection_data(configuration: IConfiguration, collectionAddress: TVMAddress) -> Any:
        opener = Nft._get_contract_opener(configuration)
        nft_collection = opener.open(NftCollection.createFromAddress(Address(collectionAddress)))
        collection_data = await nft_collection.getCollectionData()
        next_index = int(collection_data.get("nextIndex", 0))
        collection_content = collection_data.get("content")
        owner_address = collection_data.get("adminAddress")
        return {
            "nextItemIndex": next_index,
            "collectionContent": collection_content,
            "ownerAddress": owner_address,
        }

    async def getCollectionData(self) -> Any:
        if not self._configuration:
            raise RuntimeError("configuration is required")
        return await Nft._get_collection_data(self._configuration, self.addresses.get("collection", ""))

    @staticmethod
    async def getOrigin(configuration: IConfiguration, itemOrCollection: TVMAddress) -> Origin:
        ton_params = configuration.TONParams
        contract_opener = ton_params.get("contractOpener")
        if contract_opener is None:
            return Origin.TON

        state = await contract_opener.getContractState(Address(itemOrCollection))
        if not state.get("code"):
            raise empty_contract_error

        code_cell = Cell.one_from_boc(state["code"])
        if isinstance(code_cell, list):
            code_cell = code_cell[0]

        nft_item_code = ton_params.get("nftItemCode")
        nft_collection_code = ton_params.get("nftCollectionCode")
        for known in (nft_item_code, nft_collection_code):
            if known is None:
                continue
            known_cell = known
            if isinstance(known_cell, bytes):
                known_cell = Cell.one_from_boc(known_cell)
                known_cell = known_cell[0] if isinstance(known_cell, list) else known_cell
            if known_cell.hash == code_cell.hash:
                return Origin.TAC

        return Origin.TON

    @staticmethod
    async def getItemAddress(configuration: IConfiguration, collectionAddress: TVMAddress, index: int) -> str:
        Validator.validate_tvm_address(str(collectionAddress))
        opener = Nft._get_contract_opener(configuration)
        nft_collection = opener.open(NftCollection.createFromAddress(Address(collectionAddress)))
        address = await nft_collection.getNFTAddressByIndex(int(index))
        return address.to_str(is_user_friendly=True, is_url_safe=True, is_bounceable=True, is_test_only=False)

    @staticmethod
    def _extract_tac_abi(configuration: IConfiguration, *names: str) -> list[dict[str, Any]]:
        artifacts = configuration.artifacts
        if isinstance(artifacts, dict):
            compilation = artifacts.get("tac", {}).get("compilationArtifacts", {})
            for name in names:
                abi = compilation.get(name, {}).get("abi")
                if isinstance(abi, list):
                    return abi
        else:
            tac = getattr(artifacts, "tac", None)
            compilation = getattr(tac, "compilationArtifacts", None)
            for name in names:
                item = getattr(compilation, name, None)
                abi = getattr(item, "abi", None)
                if isinstance(abi, list):
                    return abi
        raise unknown_token_type_error("TAC", f"Unable to resolve ABI for {', '.join(names)}")

    @staticmethod
    async def _resolve_tvm_address(configuration: IConfiguration, collectionAddress: EVMAddress, tokenId: int | None = None) -> str:
        Validator.validate_evm_address(str(collectionAddress))
        token_utils = configuration.TACParams.get("tokenUtils") if configuration.TACParams else None
        if token_utils is None or not hasattr(token_utils, "exists"):
            raise unknown_token_type_error(collectionAddress, "TAC token utils are not configured")

        exists = await TonGetMethodClient.await_maybe(token_utils.exists(collectionAddress))
        if exists:
            provider = configuration.TACParams.get("provider") if configuration.TACParams else None
            if provider is None:
                raise unknown_token_type_error(collectionAddress, "TAC provider is not configured")

            erc721_abi = Nft._extract_tac_abi(configuration, "ICrossChainLayerERC721")
            ccl_erc721 = cast(Any, provider.eth).contract(
                address=Web3.to_checksum_address(str(collectionAddress)),
                abi=erc721_abi,
            )
            info = ccl_erc721.functions.getInfo().call()
            if isinstance(info, dict):
                tvm_collection_address = info.get("tvmAddress")
            elif isinstance(info, (list, tuple)) and len(info) >= 4:
                tvm_collection_address = info[3]
            else:
                tvm_collection_address = getattr(info, "tvmAddress", None)
            if not tvm_collection_address:
                raise unknown_token_type_error(collectionAddress, "Missing tvmAddress in ERC721 info")

            collection = Address(str(tvm_collection_address)).to_str(
                is_user_friendly=True,
                is_url_safe=True,
                is_bounceable=True,
                is_test_only=False,
            )
            if tokenId is None:
                return collection
            return await Nft.getItemAddress(configuration, collection, tokenId)

        ton_params = configuration.TONParams or {}
        cross_chain_layer_address = ton_params.get("crossChainLayerAddress")
        nft_item_code = ton_params.get("nftItemCode")
        nft_collection_code = ton_params.get("nftCollectionCode")
        if not cross_chain_layer_address or not nft_item_code or not nft_collection_code:
            raise unknown_token_type_error(collectionAddress, "TON NFT config is not fully configured")

        nft_collection = NftCollection.createFromConfig(
            {
                "adminAddress": cross_chain_layer_address,
                "newAdminAddress": None,
                "collectionContent": Builder().end_cell(),
                "commonContent": Builder().end_cell(),
                "nftItemCode": nft_item_code,
                "originalAddress": collectionAddress,
            },
            nft_collection_code,
        )
        collection = nft_collection.address.to_str(
            is_user_friendly=True,
            is_url_safe=True,
            is_bounceable=True,
            is_test_only=False,
        )
        if tokenId is None:
            return collection

        nft_item = NftItem.createFromConfig(
            {
                "collectionAddress": collection,
                "cclAddress": cross_chain_layer_address,
                "index": tokenId,
            },
            nft_item_code,
        )
        return nft_item.address.to_str(
            is_user_friendly=True,
            is_url_safe=True,
            is_bounceable=True,
            is_test_only=False,
        )

    async def getEVMAddress(self) -> str:
        evm = self.addresses.get("evmAddress")
        if evm:
            return evm
        if self._configuration is None:
            raise RuntimeError("configuration is required")

        ton_params = self._configuration.TONParams or {}
        contract_opener = ton_params.get("contractOpener")
        nft_collection_code = ton_params.get("nftCollectionCode")
        collection_address = str(self.addresses.get("collection", ""))
        if contract_opener is None:
            raise RuntimeError("contractOpener is required")

        tvm_collection_address = Address(collection_address).to_str(
            is_user_friendly=True,
            is_url_safe=True,
            is_bounceable=True,
            is_test_only=False,
        )
        state = await contract_opener.getContractState(Address(tvm_collection_address))
        code_boc = state.get("code")
        if code_boc and nft_collection_code is not None:
            onchain_code = Cell.one_from_boc(code_boc)
            onchain_code = onchain_code[0] if isinstance(onchain_code, list) else onchain_code
            expected_code = nft_collection_code
            if isinstance(expected_code, bytes):
                expected_code = Cell.one_from_boc(expected_code)
                expected_code = expected_code[0] if isinstance(expected_code, list) else expected_code
            if expected_code.hash == onchain_code.hash:
                nft_collection = contract_opener.open(NftCollection.createFromAddress(Address(tvm_collection_address)))
                original_address = await nft_collection.getOriginalAddress()
                self.addresses["evmAddress"] = str(original_address)
                return self.addresses["evmAddress"]

        token_utils = self._configuration.TACParams.get("tokenUtils") if self._configuration.TACParams else None
        if token_utils is None or not hasattr(token_utils, "computeAddressERC721"):
            raise unknown_token_type_error(tvm_collection_address, "tokenUtils.computeAddressERC721 is not configured")
        self.addresses["evmAddress"] = str(await token_utils.computeAddressERC721(tvm_collection_address))
        return self.addresses["evmAddress"]

    async def getTVMAddress(self) -> str:
        return self.address

    def generatePayload(self, params: object) -> Cell:
        p = cast(dict[str, Any], params)
        excess_receiver = p.get("excessReceiver")
        evm_data = p.get("evmData")
        cross_chain_ton_amount = int(p.get("crossChainTonAmount") or 0)
        forward_fee_ton_amount = int(p.get("forwardFeeTonAmount") or 0)
        fee_params: FeeParams | None = p.get("feeParams")

        op_type = AssetOpType.NFT_BURN if self.origin == Origin.TAC else AssetOpType.NFT_TRANSFER
        fee_data = generate_fee_data(fee_params)

        if op_type == AssetOpType.NFT_BURN:
            ccl = self._configuration.TONParams.get("crossChainLayerAddress") if self._configuration else None
            if not ccl:
                raise RuntimeError("crossChainLayerAddress is not configured")
            return self._get_burn_payload(
                ccl,
                cast(Cell | None, evm_data),
                cross_chain_ton_amount,
                fee_data,
            )
        proxy = self._configuration.TONParams.get("nftProxyAddress") if self._configuration else None
        if not proxy:
            raise RuntimeError("nftProxyAddress is not configured")
        return self._get_transfer_payload(
            proxy,
            str(excess_receiver or ""),
            forward_fee_ton_amount,
            cast(Cell | None, evm_data),
            cross_chain_ton_amount,
            fee_data,
        )

    async def isOwnedBy(self, userAddress: str) -> bool:
        if self._configuration is None:
            raise RuntimeError("configuration is required")
        nft_data = await Nft._get_item_data(self._configuration, self.address)
        owner = nft_data.get("ownerAddress")
        if owner is None:
            return False
        try:
            owner_address = owner if isinstance(owner, Address) else Address(str(owner))
            return owner_address == Address(str(userAddress))
        except Exception:
            return False

    async def checkCanBeTransferredBy(self, userAddress: str) -> None:
        if not await self.isOwnedBy(userAddress):
            raise insufficient_balance_error(
                self.address,
                owner_address=userAddress,
                current_balance=0,
                required_balance=1,
            )

    async def getBalanceOf(self, userAddress: str) -> int:
        return 1 if await self.isOwnedBy(userAddress) else 0

    def _get_burn_payload(
        self,
        cross_chain_layer_address: str,
        evm_data: Cell | None,
        cross_chain_ton_amount: int,
        fee_data: Cell | None,
    ) -> Cell:
        query_id = generate_random_number_by_timestamp()["randomNumber"]
        custom_payload = (
            Builder()
            .store_coins(cross_chain_ton_amount)
            .store_maybe_ref(fee_data)
            .store_maybe_ref(evm_data)
            .end_cell()
        )
        return (
            Builder()
            .store_uint(0x03B390CE, 32)
            .store_uint(query_id, 64)
            .store_address(Address(cross_chain_layer_address))
            .store_maybe_ref(custom_payload)
            .end_cell()
        )

    def _get_transfer_payload(
        self,
        to: str,
        response_address: str,
        forward_fee_amount: int,
        evm_data: Cell | None,
        cross_chain_ton_amount: int,
        fee_data: Cell | None,
    ) -> Cell:
        query_id = generate_random_number_by_timestamp()["randomNumber"]
        forward_payload = (
            Builder()
            .store_coins(cross_chain_ton_amount)
            .store_maybe_ref(fee_data)
            .store_maybe_ref(evm_data)
            .end_cell()
        )

        return (
            Builder()
            .store_uint(0x5FCC3D14, 32)
            .store_uint(query_id, 64)
            .store_address(Address(to))
            .store_address(Address(response_address))
            .store_maybe_ref(None)
            .store_coins(NFT_TRANSFER_FORWARD_TON_AMOUNT + forward_fee_amount + cross_chain_ton_amount)
            .store_bit(1)
            .store_ref(forward_payload)
            .end_cell()
        )
