from __future__ import annotations

from dataclasses import dataclass
from typing import Any, cast

from pytoniq_core.boc.address import Address
from pytoniq_core.boc.builder import Builder

from errors.instances import insufficient_balance_error
from interfaces.i_configuration import IConfiguration
from interfaces.sender_abstraction import SenderAbstraction
from sdk.consts import TON_DECIMALS, TON_SYMBOL
from sdk.utils import calculate_raw_amount, generate_fee_data, generate_random_number_by_timestamp
from structs.internal_struct import ShardTransaction
from structs.struct import AssetType, FeeParams, Origin

from ._base import BaseAsset


@dataclass
class Ton(BaseAsset):
    address: str = ""
    type: AssetType = AssetType.FT
    origin: Origin = Origin.TON
    rawAmount: int = 0
    decimals: int = TON_DECIMALS
    _config: IConfiguration | None = None
    _evmAddress: str = ""

    @staticmethod
    def create(config: IConfiguration) -> Ton:
        return Ton(_config=config)

    @property
    def clone(self) -> Ton:
        cloned = Ton(_config=self._config)
        cloned.rawAmount = int(self.rawAmount)
        cloned._evmAddress = self._evmAddress
        return cloned

    def withAmount(self, amount: float) -> Ton:
        if self.rawAmount > 0:
            cloned = self.clone
            cloned.rawAmount = calculate_raw_amount(amount, TON_DECIMALS)
            return cloned
        self.rawAmount = calculate_raw_amount(amount, TON_DECIMALS)
        return self

    def withRawAmount(self, rawAmount: int) -> Ton:
        if self.rawAmount > 0:
            cloned = self.clone
            cloned.rawAmount = int(rawAmount)
            return cloned
        self.rawAmount = int(rawAmount)
        return self

    def addAmount(self, amount: float) -> Ton:
        self.rawAmount = int(self.rawAmount) + calculate_raw_amount(amount, TON_DECIMALS)
        return self

    def addRawAmount(self, rawAmount: int) -> Ton:
        self.rawAmount = int(self.rawAmount) + int(rawAmount)
        return self

    async def getEVMAddress(self) -> str:
        if not self._config:
            raise RuntimeError("configuration is required")
        if not self._evmAddress:
            token_utils = self._config.TACParams.get("tokenUtils") if self._config.TACParams else None
            if not token_utils or not hasattr(token_utils, "computeAddress"):
                raise RuntimeError("getEVMAddress requires TAC token utils")
            self._evmAddress = await token_utils.computeAddress(self._config.nativeTONAddress)
        return self._evmAddress

    async def getTVMAddress(self) -> str:
        return ""

    def generatePayload(self, params: object):
        if not self._config:
            raise RuntimeError("configuration is required")
        p = cast(dict[str, Any], params)
        excess_receiver = p.get("excessReceiver")
        evm_data = p.get("evmData")
        fee_params: FeeParams | None = p.get("feeParams")

        artifacts = getattr(self._config, "artifacts", None)
        if not artifacts:
            raise RuntimeError("Artifacts are required to build ton payload")

        def _get(obj, key):
            if isinstance(obj, dict):
                return obj.get(key)
            return getattr(obj, key, None)

        ton_artifacts = _get(artifacts, "ton")
        wrappers = _get(ton_artifacts, "wrappers") if ton_artifacts else None
        opcodes = _get(wrappers, "CrossChainLayerOpCodes") if wrappers else None
        msg_types = _get(wrappers, "MsgType") if wrappers else None
        if not opcodes or not msg_types:
            raise RuntimeError("CrossChainLayer opcodes are not configured")

        query_id = generate_random_number_by_timestamp()["randomNumber"]
        fee_data = generate_fee_data(fee_params)
        opcode_anyone = _get(opcodes, "anyone_tvmMsgToEVM") if opcodes else None
        msg_type = _get(msg_types, "tonTransfer") if msg_types else None
        if opcode_anyone is None or msg_type is None:
            raise RuntimeError("CrossChainLayer opcodes are not configured")
        normalized_excess_receiver = self._normalize_tvm_address(excess_receiver or "")

        return (
            Builder()
            .store_uint(int(opcode_anyone), 32)
            .store_uint(query_id, 64)
            .store_uint(int(msg_type), 32)
            .store_coins(self.rawAmount)
            .store_maybe_ref(fee_data)
            .store_address(Address(normalized_excess_receiver))
            .store_maybe_ref(cast(Any, evm_data))
            .end_cell()
        )

    async def getUserBalance(self, userAddress: str) -> int:
        if not self._config:
            raise RuntimeError("configuration is required")
        opener = self._config.TONParams.get("contractOpener")
        if opener is None:
            raise RuntimeError("contractOpener is required")
        normalized_user_address = self._normalize_tvm_address(userAddress)
        return (await opener.getContractState(Address(normalized_user_address)))["balance"]

    @staticmethod
    async def checkBalance(sender: SenderAbstraction, config: IConfiguration, transactions: list[ShardTransaction]) -> None:
        total_value = 0
        for transaction in transactions:
            total_value += sum(message["value"] for message in transaction["messages"])
        opener = config.TONParams.get("contractOpener")
        if opener is None:
            raise RuntimeError("contractOpener is required")
        balance = await sender.getBalance(opener)
        if balance < total_value:
            raise insufficient_balance_error(
                TON_SYMBOL,
                owner_address=sender.getSenderAddress(),
                current_balance=balance,
                required_balance=total_value,
            )

    async def checkCanBeTransferredBy(self, userAddress: str) -> None:
        balance = await self.getUserBalance(userAddress)
        if balance < self.rawAmount:
            raise insufficient_balance_error(
                TON_SYMBOL,
                owner_address=userAddress,
                current_balance=balance,
                required_balance=self.rawAmount,
            )

    async def getBalanceOf(self, userAddress: str) -> int:
        return await self.getUserBalance(userAddress)

    @staticmethod
    def _normalize_tvm_address(user_address: Address | str) -> str:
        if hasattr(user_address, "to_str"):
            return cast(Any, user_address).to_str(
                is_user_friendly=True,
                is_url_safe=True,
                is_bounceable=True,
                is_test_only=False,
            )
        value = str(user_address).strip()
        if value.startswith("Address<") and value.endswith(">"):
            return value[len("Address<") : -1]
        return value
