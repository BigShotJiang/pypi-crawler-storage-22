from __future__ import annotations


class ErrorWithStatusCodeError(Exception):
    def __init__(self, message: str, error_code: int):
        super().__init__(message)
        self.error_code = error_code


class ContractError(ErrorWithStatusCodeError):
    def __init__(self, message: str, error_code: int):
        super().__init__(message, error_code)
        self.name = "contract_error"


class FetchError(ErrorWithStatusCodeError):
    def __init__(self, message: str, error_code: int, inner: object | None = None):
        super().__init__(message, error_code)
        self.name = "fetch_error"
        self.inner = inner


class AddressError(ErrorWithStatusCodeError):
    def __init__(self, message: str, error_code: int):
        super().__init__(message, error_code)
        self.name = "address_error"


class WalletError(ErrorWithStatusCodeError):
    def __init__(self, message: str, error_code: int):
        super().__init__(message, error_code)
        self.name = "wallet_error"


class KeyError(ErrorWithStatusCodeError):
    def __init__(self, message: str, error_code: int):
        super().__init__(message, error_code)
        self.name = "key_error"


class FormatError(ErrorWithStatusCodeError):
    def __init__(self, message: str, error_code: int):
        super().__init__(message, error_code)
        self.name = "format_error"


class BitError(ErrorWithStatusCodeError):
    def __init__(self, message: str, error_code: int):
        super().__init__(message, error_code)
        self.name = "bit_error"


class MetadataError(ErrorWithStatusCodeError):
    def __init__(self, message: str, error_code: int):
        super().__init__(message, error_code)
        self.name = "metadata_error"


class SettingError(ErrorWithStatusCodeError):
    def __init__(self, message: str, error_code: int):
        super().__init__(message, error_code)
        self.name = "setting_error"


class EvmCallError(ErrorWithStatusCodeError):
    def __init__(self, message: str, error_code: int):
        super().__init__(message, error_code)
        self.name = "evm_call_error"


class PrepareMessageGroupError(ErrorWithStatusCodeError):
    def __init__(self, message: str, error_code: int):
        super().__init__(message, error_code)
        self.name = "prepare_message_group_error"


class NoValidGroupFoundError(ErrorWithStatusCodeError):
    def __init__(self, message: str, error_code: int):
        super().__init__(message, error_code)
        self.name = "no_valid_group_found_error"


class InsufficientBalanceError(ErrorWithStatusCodeError):
    def __init__(self, message: str, error_code: int):
        super().__init__(message, error_code)
        self.name = "insufficient_balance_error"


class TokenError(ErrorWithStatusCodeError):
    def __init__(self, message: str, error_code: int):
        super().__init__(message, error_code)
        self.name = "token_error"


class TransactionError(ErrorWithStatusCodeError):
    def __init__(self, message: str, error_code: int):
        super().__init__(message, error_code)
        self.name = "transaction_error"

error_with_status_code = ErrorWithStatusCodeError
error_with_status_code_error = ErrorWithStatusCodeError
contract_error = ContractError
fetch_error = FetchError
address_error = AddressError
wallet_error = WalletError
key_error = KeyError
format_error = FormatError
bit_error = BitError
metadata_error = MetadataError
setting_error = SettingError
evm_call_error = EvmCallError
prepare_message_group_error = PrepareMessageGroupError
no_valid_group_found_error = NoValidGroupFoundError
insufficient_balance_error = InsufficientBalanceError
token_error = TokenError
transaction_error = TransactionError
