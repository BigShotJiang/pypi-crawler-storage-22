from __future__ import annotations

from structs.struct import Origin

from .errors import (
    address_error,
    bit_error,
    evm_call_error,
    fetch_error,
    format_error,
    metadata_error,
    setting_error,
    transaction_error,
    wallet_error,
)
from .errors import (
    contract_error as contract_error_cls,
)
from .errors import (
    insufficient_balance_error as insufficient_balance_error_cls,
)
from .errors import (
    key_error as key_error_cls,
)
from .errors import (
    no_valid_group_found_error as no_valid_group_found_error_cls,
)
from .errors import (
    prepare_message_group_error as prepare_message_group_error_cls,
)
from .errors import (
    token_error as token_error_cls,
)

empty_contract_error = contract_error_cls("unexpected empty contract code of given jetton.", 100)


def operation_fetch_error(msg: str, inner: object | None = None) -> fetch_error:
    return fetch_error(f"failed to fetch OperationId: {msg}", 101, inner)


def status_fetch_error(msg: str, inner: object | None = None) -> fetch_error:
    return fetch_error(f"failed to fetch status transaction: {msg}", 102, inner)


def tvm_address_error(addr: str) -> address_error:
    return address_error(f"invalid tvm address {addr}", 103)


def evm_address_error(addr: str) -> address_error:
    return address_error(f"invalid evm address {addr}", 104)


def unknown_wallet_error(version: str) -> wallet_error:
    return wallet_error(f"Unknown wallet version {version}", 105)


def unsupported_key_error(key: str) -> key_error_cls:
    return key_error_cls(f"Unsupported onchain key: {key}", 106)


unsupported_format_error = format_error("Only snake format is supported", 107)

not_multiply_of_8_error = bit_error("Number remaining of bits is not multiply of 8", 108)

prefix_error = metadata_error("Unexpected wrappers metadata content prefix", 109)


def empty_setting_error(setting: str) -> setting_error:
    return setting_error(
        f"unexpected empty {setting}. Make sure the settings contract is valid.",
        110,
    )


def invalid_method_name_error(method_name: str) -> evm_call_error:
    return evm_call_error(
        "Invalid Solidity method name: "
        f'"{method_name}". Method must be either a valid identifier or have parameters (bytes,bytes).',
        111,
    )


def profiling_fetch_error(msg: str, inner: object | None = None) -> fetch_error:
    return fetch_error(f"failed to fetch stage profiling: {msg}", 112, inner)


def empty_array_error(msg: str) -> fetch_error:
    return fetch_error(f"empty array: {msg}", 113)


invalid_asset_type = format_error("Invalid asset type", 114)


def prepare_message_group_error(is_boc_size_valid: bool, is_depth_valid: bool) -> prepare_message_group_error_cls:
    return prepare_message_group_error_cls(
        "Failed to prepare message group: BOC size valid: "
        f"{is_boc_size_valid}, depth valid: {is_depth_valid}",
        115,
    )


no_valid_group_found_error = no_valid_group_found_error_cls("Failed to prepare valid message group", 116)


def all_endpoints_failed_error(inner: object) -> fetch_error:
    msg = "All endpoints failed, last err: "
    if isinstance(inner, Exception):
        msg += str(inner)
    return fetch_error(msg, 117, inner)


def all_contract_opener_failed_error(inner: object) -> fetch_error:
    return fetch_error("All contract opener failed", 118, inner)


def insufficient_balance_error(
    token: str,
    *,
    current_balance: int | None = None,
    required_balance: int | None = None,
    owner_address: str | None = None,
    wallet_address: str | None = None,
) -> insufficient_balance_error_cls:
    details: list[str] = []
    if owner_address:
        details.append(f"owner={owner_address}")
    if wallet_address:
        details.append(f"wallet={wallet_address}")
    if current_balance is not None:
        details.append(f"current={current_balance}")
    if required_balance is not None:
        details.append(f"required={required_balance}")

    message = f"Insufficient balance of {token}"
    if details:
        message = f"{message} ({', '.join(details)})"
    return insufficient_balance_error_cls(message, 119)


def unknown_token_type_error(token: str, reason: str | None = None) -> token_error_cls:
    return token_error_cls(f"Unknown token type of {token}: {reason}", 120)


def index_required_error(token: str) -> token_error_cls:
    return token_error_cls(f"Index is required for collection {token}", 121)


def convert_currency_fetch_error(msg: str, inner: object | None = None) -> fetch_error:
    return fetch_error(f"failed to fetch convert currency: {msg}", 122, inner)


def simulation_fetch_error(msg: str, inner: object | None = None) -> fetch_error:
    return fetch_error(f"failed to fetch simulate tac msg: {msg}", 123, inner)


def get_ton_fee_info_fetch_error(msg: str, inner: object | None = None) -> fetch_error:
    return fetch_error(f"failed to fetch TVM executor fee: {msg}", 124, inner)


missing_fee_params_error = format_error(
    "When withoutSimulation is true, protocolFee and evmExecutorFee must be provided in options",
    125,
)

missing_tvm_executor_fee_error = format_error(
    "When withoutSimulation is true and isRoundTrip is true, tvmExecutorFee must be provided in options",
    126,
)

missing_gas_limit_error = format_error(
    "When withoutSimulation is true, gasLimit must be provided in evmProxyMsg",
    127,
)

missing_decimals = metadata_error("Missing decimals in jetton metadata", 128)

missing_jetton_data_error = metadata_error("Jetton data should be available for ton origin", 129)


def zero_raw_amount_error(asset_address: str) -> token_error_cls:
    return token_error_cls(f"ft asset with zero rawAmount/amount is not allowed: {asset_address}", 130)


def send_cross_chain_transaction_failed_error(msg: str) -> wallet_error:
    return wallet_error(f"failed to send cross chain transaction: {msg}", 131)


convert_currency_negative_or_zero_value_error = format_error(
    "Value cannot be negative or zero for currency conversion",
    132,
)


def unknown_asset_origin_error(origin: Origin) -> token_error_cls:
    return token_error_cls(f"Unknown asset origin: {origin}", 133)


def gas_price_fetch_error(msg: str, inner: object | None = None) -> fetch_error:
    return fetch_error(f"Failed to fetch gas price: {msg}", 134, inner)


def tx_finalization_error(msg: str) -> transaction_error:
    return transaction_error(f"Transaction failed: {msg}", 135)
