# ETH <-> TON Helpers

Set of helpers for bridging between TON and ETH through TAC.

## Included Helpers
- `TonEthHelper` - only `TON -> ETH`.
- `EthTonHelper` - only `ETH -> TON`.
- `LayerZeroBridgeHelper` - unified wrapper for both directions.

## Supported Assets
- `ASSET_ID_CBBTC`
- `ASSET_ID_WETH`

Default routes and addresses are defined in `helpers/bridge_structs.py`.

## Networks
- Mainnet only.
- Helpers create SDK internally with `Network.MAINNET`.

## Public API
```python
helper = await LayerZeroBridgeHelper.create()

res = await helper.sendToETH(
    sender=ton_sender,
    to_account="0xYourEthAccount",
    asset_id=ASSET_ID_WETH,   # or ASSET_ID_CBBTC
    amount=10_000_000_000_000,
)

res = await helper.sendToTON(
    signer=eth_private_key_or_signer,
    to_account="EQ...",   # TVM address
    asset_id=ASSET_ID_WETH,      # or ASSET_ID_CBBTC
    amount=10_000_000_000_000,
)
```

## Prerequisites
- For `TON -> ETH`, you need a valid TON sender (`SenderAbstraction`) and enough token/fee balance.
- For `ETH -> TON`, you need an EVM signer with private key access and enough ETH for gas.
- For `ETH -> TON`, token allowance to the ETH OApp adapter must be set.
- Some routes may require extra TAC-side setup (for example WTAC approve and/or authorized payer on composer), same as in JS specs.
- Before sending, helpers validate WTAC `balance` and `allowance` (for payer -> composer) on TAC and fail early if they are insufficient.

## Return Types
- `sendToETH` returns `TonToEthTransferResult`.
- `sendToTON` returns `EthToTonTransferResult`.

## API Notes
- `TonEthHelper`, `EthTonHelper`, `LayerZeroBridgeHelper` use `create()` for initialization.
- SDK and runtime defaults are internal; users pass only required transaction arguments.

Usage example: `helpers/example_usage.py`.
