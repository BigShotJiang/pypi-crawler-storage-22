from typing import TYPE_CHECKING, Any

from helpers.bridge_structs import (
    ASSET_ID_CBBTC,
    ASSET_ID_WETH,
    COMPOSER,
    DEFAULT_BRIDGE_ROUTES,
    ETH_EID,
    ETH_RPC_URL_MAINNET,
    TAC_EID,
    TAC_RPC_URL_MAINNET,
    WETH_COMPOSER,
    WETH_TON,
    WTAC_TAC,
    BridgeRoute,
    EthToTonTransferResult,
    TonEthFeeQuote,
    TonToEthTransferResult,
    WETH_oftAdapterEth,
    cdBTC_oftAdapterEth,
    cdBTC_ton,
    eth_w3,
    tac_w3,
)

if TYPE_CHECKING:
    from helpers.eth_ton_helper import EthTonHelper
    from helpers.layer_zero_bridge_helper import LayerZeroBridgeHelper
    from helpers.ton_eth_helper import TonEthHelper

__all__ = [
    "ASSET_ID_CBBTC",
    "ASSET_ID_WETH",
    "DEFAULT_BRIDGE_ROUTES",
    "cdBTC_ton",
    "cdBTC_oftAdapterEth",
    "COMPOSER",
    "ETH_EID",
    "TAC_EID",
    "ETH_RPC_URL_MAINNET",
    "TAC_RPC_URL_MAINNET",
    "WETH_TON",
    "WETH_oftAdapterEth",
    "WETH_COMPOSER",
    "WTAC_TAC",
    "eth_w3",
    "tac_w3",
    "BridgeRoute",
    "TonEthFeeQuote",
    "TonToEthTransferResult",
    "EthToTonTransferResult",
    "TonEthHelper",
    "EthTonHelper",
    "LayerZeroBridgeHelper",
]


def __getattr__(name: str) -> Any:
    if name == "TonEthHelper":
        from helpers.ton_eth_helper import TonEthHelper

        return TonEthHelper
    if name == "EthTonHelper":
        from helpers.eth_ton_helper import EthTonHelper

        return EthTonHelper
    if name == "LayerZeroBridgeHelper":
        from helpers.layer_zero_bridge_helper import LayerZeroBridgeHelper

        return LayerZeroBridgeHelper
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
