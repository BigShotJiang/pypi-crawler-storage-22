from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

_ABI_DIR = Path(__file__).resolve().parent / "abi"


@lru_cache(maxsize=None)
def load_helper_abi(file_name: str) -> list[dict[str, Any]]:
    path = _ABI_DIR / file_name
    if not path.exists():
        raise FileNotFoundError(f"ABI file not found: {path}")

    with path.open("r", encoding="utf-8") as f:
        raw = json.load(f)

    if isinstance(raw, list):
        return raw

    if isinstance(raw, dict):
        abi = raw.get("abi")
        if isinstance(abi, list):
            return abi

    raise ValueError(f"Invalid ABI format in file: {path}")

