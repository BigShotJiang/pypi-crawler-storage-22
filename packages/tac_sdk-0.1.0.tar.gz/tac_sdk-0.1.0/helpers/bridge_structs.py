from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from structs.struct import EVMAddress, TransactionLinkerWithOperationId, TVMAddress

ASSET_ID_CBBTC = "cbbtc"
ASSET_ID_WETH = "weth"
IOFT_ABI_FILE = "IOFT.json"
COMPOSER_ETH_ABI_FILE = "composerEth.json"
WTAC_ABI_FILE = "WTAC.json"

cdBTC_ton: str = "EQDhyPzbIjJT_WnY3gGprjSYUK9fiGMjWMezxO8MZiUdfb_B"
cdBTC_oftAdapterEth: str = "0x59Ea2825d8Ad7D60cC6Aa77FFbDD0E89c0fBF539"
COMPOSER: str = "0xC1313fD7ca98a85E8a0A3398739801f6653d456b"
ETH_EID: str = "30101"
TAC_EID: str = "30377"
ETH_RPC_URL_MAINNET: str = "https://ethereum-rpc.publicnode.com"
TAC_RPC_URL_MAINNET: str = "https://rpc-team-mainnet.tac.build"
TON_TO_ETH_DEFAULT_NATIVE_FEE_MARKUP_PERCENT: int = 10
ETH_TO_TON_DEFAULT_NATIVE_FEE_MARKUP_PERCENT: int = 5
ETH_TO_TON_DEFAULT_TVM_EXECUTOR_FEE_MARKUP_PERCENT: int = 10
ETH_TO_TON_DEFAULT_COMPOSE_INDEX: int = 0
ETH_TO_TON_DEFAULT_COMPOSE_GAS_LIMIT: int = 5_000_000
ETH_TO_TON_DEFAULT_COMPOSE_NATIVE_DROP: int = 0
TON_TO_ETH_SEND_TO_ARGS_ABI_TYPE: str = (
    "(address,(uint32,bytes32,uint256,uint256,bytes,bytes,bytes),(uint256,uint256),address,address)"
)
ETH_TO_TON_COMPOSE_MSG_ABI_TYPE: str = "(string,uint64,uint256,uint256,string[],address)"

# Optional aliases for defaults used across helpers.
WETH_TON: str = "EQBTkLAhEteZCRgRe_xMs5ZE0bMrduYxKbyzGCpXXW8dRWOT"
WETH_oftAdapterEth: str = "0xf211D3B40A74632162F45F4d42A461b663694a9D"
WETH_COMPOSER: str = "0xaCC58721e86A0d0b1E44ee4E5AD14e70452489c7"
WTAC_TAC: str = "0xB63B9f0eb4A6E6f191529D71d4D88cc8900Df2C9"

class _LazyWeb3Provider:
    def __init__(self, rpc_url: str) -> None:
        self._rpc_url = rpc_url
        self._instance: Any | None = None

    def _get(self) -> Any:
        if self._instance is None:
            from web3 import Web3

            self._instance = Web3(Web3.HTTPProvider(self._rpc_url))
        return self._instance

    def __getattr__(self, item: str) -> Any:
        return getattr(self._get(), item)


eth_w3 = _LazyWeb3Provider(ETH_RPC_URL_MAINNET)
tac_w3 = _LazyWeb3Provider(TAC_RPC_URL_MAINNET)


@dataclass(frozen=True)
class BridgeRoute:
    token_tvm_address: str
    composer_address: str
    eth_oapp_address: str = ""


DEFAULT_BRIDGE_ROUTES: dict[str, BridgeRoute] = {
    ASSET_ID_CBBTC: BridgeRoute(
        token_tvm_address=cdBTC_ton,
        composer_address=COMPOSER,
        eth_oapp_address=cdBTC_oftAdapterEth,
    ),
    ASSET_ID_WETH: BridgeRoute(
        token_tvm_address=WETH_TON,
        composer_address=WETH_COMPOSER,
        eth_oapp_address=WETH_oftAdapterEth,
    ),
}


@dataclass(frozen=True)
class TonEthFeeQuote:
    native_fee: int
    native_fee_with_markup: int
    lz_token_fee: int


@dataclass(frozen=True)
class TonToEthTransferResult:
    asset_id: str
    to_account: EVMAddress
    token_tvm_address: str
    token_oapp_address: str
    composer_address: str
    amount: int
    min_amount_ld: int
    encoded_parameters: str
    fee_quote: TonEthFeeQuote
    transaction_linker: TransactionLinkerWithOperationId


@dataclass(frozen=True)
class EthToTonTransferResult:
    asset_id: str
    to_account: TVMAddress
    token_tvm_address: str
    token_evm_address: str
    amount: int
    value: int
    transaction_hash: str
