from __future__ import annotations

import random
import time
from typing import Any, Mapping, cast

from eth_abi.abi import encode
from eth_account import Account
from web3 import Web3

from helpers.abi_loader import load_helper_abi
from helpers.bridge_structs import (
    DEFAULT_BRIDGE_ROUTES,
    ETH_TO_TON_COMPOSE_MSG_ABI_TYPE,
    ETH_TO_TON_DEFAULT_COMPOSE_GAS_LIMIT,
    ETH_TO_TON_DEFAULT_COMPOSE_INDEX,
    ETH_TO_TON_DEFAULT_COMPOSE_NATIVE_DROP,
    ETH_TO_TON_DEFAULT_NATIVE_FEE_MARKUP_PERCENT,
    ETH_TO_TON_DEFAULT_TVM_EXECUTOR_FEE_MARKUP_PERCENT,
    IOFT_ABI_FILE,
    TAC_EID,
    BridgeRoute,
    EthToTonTransferResult,
    eth_w3,
    tac_w3,
)
from helpers.lz_options import build_executor_compose_options
from helpers.oft_utils import parse_quote_oft_response, validate_oft_amount_bounds
from helpers.wtac_utils import ensure_wtac_for_tac_action
from interfaces.i_tac_sdk import ITacSDK
from structs.struct import AssetType, EVMAddress, Network, SDKParams, TVMAddress

_IOFT_ABI = load_helper_abi(IOFT_ABI_FILE)


class EthTonHelper:
    def __init__(self) -> None:
        self._tac_sdk: ITacSDK | None = None
        self._routes = self._prepare_routes(DEFAULT_BRIDGE_ROUTES)
        self._ton_eid = int(TAC_EID)
        self._native_fee_markup_percent = int(ETH_TO_TON_DEFAULT_NATIVE_FEE_MARKUP_PERCENT)
        self._tvm_executor_fee_markup_percent = int(ETH_TO_TON_DEFAULT_TVM_EXECUTOR_FEE_MARKUP_PERCENT)

    @classmethod
    async def create(cls) -> EthTonHelper:
        from sdk.tac_sdk import TacSdk

        helper = cls()
        helper._tac_sdk = await TacSdk.create(SDKParams(network=Network.MAINNET))
        return helper

    @classmethod
    async def _create_with_sdk(cls, tac_sdk: ITacSDK) -> EthTonHelper:
        helper = cls()
        helper._tac_sdk = tac_sdk
        return helper

    async def sendToTON(
        self,
        signer: object,
        to_account: TVMAddress,
        asset_id: str,
        amount: int,
    ) -> EthToTonTransferResult:
        tac_sdk = self._require_sdk()
        raw_amount = self._normalize_raw_amount(amount)
        min_amount_ld = 0
        extra_options_hex = self._build_default_extra_options()
        route = self._resolve_route(asset_id)

        signer_address, private_key = self._resolve_signer(signer)
        web3 = self._resolve_eth_provider(signer)

        ft = await tac_sdk.getFT(route.token_tvm_address)
        token_evm_address = self._to_checksum_address(route.eth_oapp_address, "eth_oapp_address")
        composer_address = self._to_checksum_address(route.composer_address, "composer_address")

        trusted_executors = list(tac_sdk.getTrustedTONExecutors)
        tvm_executor_fee = await self._get_default_tvm_executor_fee(ft, raw_amount, trusted_executors)
        tvm_protocol_fee = await self._get_default_tvm_protocol_fee()
        shards_key = self._generate_shards_key()
        required_wtac = int(tvm_protocol_fee) + int(tvm_executor_fee)
        ensure_wtac_for_tac_action(
            tac_sdk=tac_sdk,
            fallback_provider=tac_w3,
            required_wtac=required_wtac,
            payer=signer_address,
            composer_address=composer_address,
        )

        compose_msg = self._construct_compose_msg(
            recipient=str(to_account),
            shards_key=shards_key,
            tvm_protocol_fee=tvm_protocol_fee,
            tvm_executor_fee=tvm_executor_fee,
            tvm_valid_executors=trusted_executors,
            payer=signer_address,
        )
        send_param = self._construct_send_param_eth(
            composer_address=composer_address,
            amount_ld=raw_amount,
            min_amount_ld=int(min_amount_ld),
            compose_msg=compose_msg,
            extra_options_hex=extra_options_hex,
        )

        ioft_contract = cast(Any, web3.eth).contract(address=token_evm_address, abi=_IOFT_ABI)
        token_balance = self._get_user_token_balance(web3, ioft_contract, signer_address)
        if token_balance < raw_amount:
            raise RuntimeError(
                "Insufficient token balance for bridge transfer: "
                f"asset_id={self._normalize_asset_id(asset_id)} sender={signer_address} "
                f"balance={token_balance} requested={raw_amount}"
            )
        min_amount_allowed, max_amount_allowed, amount_sent_ld, amount_received_ld = self._get_oft_limits_and_amounts(
            ioft_contract,
            send_param,
        )
        validate_oft_amount_bounds(
            asset_id=self._normalize_asset_id(asset_id),
            amount=raw_amount,
            min_amount=min_amount_allowed,
            max_amount=max_amount_allowed,
            sent_amount=amount_sent_ld,
            received_amount=amount_received_ld,
        )

        native_fee, lz_token_fee = self._get_gas_estimations_eth_ton(ioft_contract, send_param)
        native_fee_with_markup = self._apply_native_fee_markup(native_fee)
        tx_value = int(native_fee_with_markup)

        tx_hash = self._send_contract_transaction(
            web3=web3,
            fn_call=ioft_contract.functions.send(
                send_param,
                (int(native_fee_with_markup), int(lz_token_fee)),
                signer_address,
            ),
            signer_address=signer_address,
            private_key=private_key,
            value=tx_value,
        )

        return EthToTonTransferResult(
            asset_id=self._normalize_asset_id(asset_id),
            to_account=str(to_account),
            token_tvm_address=route.token_tvm_address,
            token_evm_address=token_evm_address,
            amount=raw_amount,
            value=tx_value,
            transaction_hash=tx_hash,
        )

    def _require_sdk(self) -> ITacSDK:
        if self._tac_sdk is None:
            raise RuntimeError("EthTonHelper is not initialized. Use `await EthTonHelper.create()` first.")
        return self._tac_sdk

    async def _get_default_tvm_executor_fee(self, ft: Any, amount: int, trusted_executors: list[str]) -> int:
        tac_sdk = self._require_sdk()
        token_tvm_address = await ft.getTVMAddress()
        fee_info = await tac_sdk.operationTracker.getTVMExecutorFee(
            {
                "tonAssets": [
                    {
                        "amount": str(int(amount)),
                        "tokenAddress": str(token_tvm_address),
                        "assetType": AssetType.FT,
                    }
                ],
                "feeSymbol": "TAC",
                "tvmValidExecutors": trusted_executors,
            }
        )
        base_fee = int(fee_info["inTAC"])
        return base_fee * (100 + self._tvm_executor_fee_markup_percent) // 100

    async def _get_default_tvm_protocol_fee(self) -> int:
        tac_sdk = self._require_sdk()
        cross_chain_layer = tac_sdk.config.TACParams.get("crossChainLayer")
        if cross_chain_layer is None:
            raise RuntimeError("TAC crossChainLayer is not configured")
        return int(await cross_chain_layer.getProtocolFee())

    @staticmethod
    def _build_default_extra_options() -> str:
        return build_executor_compose_options(
            index=ETH_TO_TON_DEFAULT_COMPOSE_INDEX,
            gas_limit=ETH_TO_TON_DEFAULT_COMPOSE_GAS_LIMIT,
            native_drop=ETH_TO_TON_DEFAULT_COMPOSE_NATIVE_DROP,
        )

    def _construct_send_param_eth(
        self,
        composer_address: str,
        amount_ld: int,
        min_amount_ld: int,
        compose_msg: bytes,
        extra_options_hex: str,
    ) -> tuple[int, bytes, int, int, bytes, bytes, bytes]:
        return (
            self._ton_eid,
            self._evm_address_to_bytes32(composer_address),
            int(amount_ld),
            int(min_amount_ld),
            self._hex_to_bytes(extra_options_hex, "extra_options_hex"),
            compose_msg,
            b"",
        )

    def _get_gas_estimations_eth_ton(
        self,
        ioft_contract: Any,
        send_param: tuple[int, bytes, int, int, bytes, bytes, bytes],
    ) -> tuple[int, int]:
        return self._parse_quote_send_response(ioft_contract.functions.quoteSend(send_param, False).call())

    def _get_oft_limits_and_amounts(
        self,
        ioft_contract: Any,
        send_param: tuple[int, bytes, int, int, bytes, bytes, bytes],
    ) -> tuple[int, int, int, int]:
        return parse_quote_oft_response(ioft_contract.functions.quoteOFT(send_param).call())

    def _construct_compose_msg(
        self,
        recipient: str,
        shards_key: int,
        tvm_protocol_fee: int,
        tvm_executor_fee: int,
        tvm_valid_executors: list[str],
        payer: EVMAddress,
    ) -> bytes:
        return encode(
            [ETH_TO_TON_COMPOSE_MSG_ABI_TYPE],
            [
                (
                    str(recipient),
                    int(shards_key),
                    int(tvm_protocol_fee),
                    int(tvm_executor_fee),
                    [str(x) for x in tvm_valid_executors],
                    self._to_checksum_address(payer, "payer"),
                )
            ],
        )

    def _resolve_eth_provider(self, signer: object) -> Web3:
        provider = getattr(signer, "provider", None) or getattr(signer, "w3", None)
        if provider is None:
            eth_provider_from_config = self._require_sdk().config.TACParams.get("ethProvider")
            if eth_provider_from_config is not None and hasattr(eth_provider_from_config, "eth"):
                provider = eth_provider_from_config
        if provider is None:
            provider = eth_w3
        if not hasattr(provider, "eth"):
            raise ValueError("ETH provider is invalid")
        return cast(Web3, provider)

    def _resolve_signer(self, signer: object) -> tuple[EVMAddress, str]:
        if isinstance(signer, str):
            account = Account.from_key(signer)
            return self._to_checksum_address(account.address, "signer_address"), self._normalize_private_key(signer)

        address = getattr(signer, "address", None)
        private_key = (
            getattr(signer, "key", None)
            or getattr(signer, "privateKey", None)
            or getattr(signer, "_private_key", None)
        )
        if not address:
            raise ValueError("Signer must expose address")
        if private_key is None:
            raise ValueError("Signer must expose key/privateKey for local signing")
        return self._to_checksum_address(str(address), "signer_address"), self._normalize_private_key(private_key)

    def _send_contract_transaction(
        self,
        web3: Web3,
        fn_call: Any,
        signer_address: EVMAddress,
        private_key: str,
        value: int,
    ) -> str:
        eth = cast(Any, web3.eth)
        nonce = int(eth.get_transaction_count(signer_address, "pending"))
        tx_params: dict[str, Any] = {
            "from": signer_address,
            "nonce": nonce,
            "value": int(value),
            "chainId": int(eth.chain_id),
        }
        try:
            tx_params["gasPrice"] = int(eth.gas_price)
        except Exception:
            pass
        try:
            estimate = int(fn_call.estimate_gas({"from": signer_address, "value": int(value)}))
            tx_params["gas"] = max(int(estimate * 1.2), estimate + 50_000)
        except Exception:
            tx_params["gas"] = 2_500_000

        tx = fn_call.build_transaction(tx_params)
        signed = eth.account.sign_transaction(tx, private_key=private_key)
        tx_hash = eth.send_raw_transaction(signed.raw_transaction)
        receipt = eth.wait_for_transaction_receipt(tx_hash, timeout=300)
        if int(getattr(receipt, "status", 0)) != 1:
            raise RuntimeError(f"EVM transaction failed: {tx_hash.hex()}")
        return str(tx_hash.hex())

    def _get_user_token_balance(self, web3: Web3, ioft_contract: Any, user_address: EVMAddress) -> int:
        try:
            return int(ioft_contract.functions.balanceOf(user_address).call())
        except Exception:
            pass

        token_address = self._to_checksum_address(ioft_contract.functions.token().call(), "token_address")
        erc20_balance_abi = [
            {
                "constant": True,
                "inputs": [{"name": "owner", "type": "address"}],
                "name": "balanceOf",
                "outputs": [{"name": "", "type": "uint256"}],
                "stateMutability": "view",
                "type": "function",
            }
        ]
        token_contract = cast(Any, web3.eth).contract(address=token_address, abi=erc20_balance_abi)
        return int(token_contract.functions.balanceOf(user_address).call())

    def _resolve_route(self, asset_id: str) -> BridgeRoute:
        normalized = self._normalize_asset_id(asset_id)
        route = self._routes.get(normalized)
        if route is not None:
            return route
        supported = ", ".join(sorted(self._routes.keys()))
        raise ValueError(f"Unsupported asset_id: {asset_id}. Supported asset_id values: {supported}")

    @staticmethod
    def _normalize_asset_id(asset_id: str) -> str:
        return str(asset_id).strip().lower()

    @staticmethod
    def _prepare_routes(routes: Mapping[str, BridgeRoute]) -> dict[str, BridgeRoute]:
        prepared: dict[str, BridgeRoute] = {}
        for key, route in routes.items():
            normalized_key = EthTonHelper._normalize_asset_id(key)
            if not normalized_key:
                raise ValueError("asset_id route key cannot be empty")
            if not route.token_tvm_address:
                raise ValueError(f"Missing token_tvm_address for asset_id={key}")
            if not route.eth_oapp_address:
                raise ValueError(f"Missing eth_oapp_address for asset_id={key}")
            if not route.composer_address:
                raise ValueError(f"Missing composer_address for asset_id={key}")
            prepared[normalized_key] = BridgeRoute(
                token_tvm_address=route.token_tvm_address,
                composer_address=EthTonHelper._to_checksum_address(route.composer_address, f"composer_address[{key}]"),
                eth_oapp_address=EthTonHelper._to_checksum_address(route.eth_oapp_address, f"eth_oapp_address[{key}]"),
            )
        if not prepared:
            raise ValueError("At least one asset route must be configured")
        return prepared

    def _apply_native_fee_markup(self, native_fee: int) -> int:
        return int(native_fee) * (100 + self._native_fee_markup_percent) // 100

    @staticmethod
    def _parse_quote_send_response(response: Any) -> tuple[int, int]:
        if isinstance(response, dict):
            native_fee = response.get("nativeFee")
            lz_token_fee = response.get("lzTokenFee")
            if native_fee is not None and lz_token_fee is not None:
                return int(native_fee), int(lz_token_fee)

        if hasattr(response, "nativeFee") and hasattr(response, "lzTokenFee"):
            return int(response.nativeFee), int(response.lzTokenFee)

        if isinstance(response, (list, tuple)):
            if len(response) == 2 and not isinstance(response[0], (dict, list, tuple)):
                return int(response[0]), int(response[1])
            if len(response) == 1:
                return EthTonHelper._parse_quote_send_response(response[0])

        raise RuntimeError(f"Unsupported quoteSend response format: {response}")

    @staticmethod
    def _normalize_raw_amount(amount: object) -> int:
        if isinstance(amount, bool) or not isinstance(amount, int):
            raise ValueError("amount must be a raw integer (int)")
        if amount <= 0:
            raise ValueError("amount must be greater than 0")
        return amount

    @staticmethod
    def _generate_shards_key() -> int:
        timestamp = int(time.time())
        return timestamp + random.randint(0, 1000)

    @staticmethod
    def _to_checksum_address(address: str, param_name: str) -> EVMAddress:
        if not Web3.is_address(address):
            raise ValueError(f"Invalid {param_name}: {address}")
        return cast(EVMAddress, Web3.to_checksum_address(address))

    @staticmethod
    def _evm_address_to_bytes32(address: str) -> bytes:
        if not Web3.is_address(address):
            raise ValueError(f"Invalid EVM address: {address}")
        return bytes.fromhex(address.lower().replace("0x", "")).rjust(32, b"\x00")

    @staticmethod
    def _normalize_private_key(private_key: Any) -> str:
        if isinstance(private_key, bytes):
            return "0x" + private_key.hex()
        if hasattr(private_key, "hex") and callable(private_key.hex):
            hex_value = str(private_key.hex())
            return hex_value if str(hex_value).startswith("0x") else f"0x{hex_value}"
        key = str(private_key)
        return key if key.startswith("0x") else f"0x{key}"

    @staticmethod
    def _hex_to_bytes(value: str, param_name: str) -> bytes:
        if not isinstance(value, str):
            raise ValueError(f"{param_name} must be a hex string")
        normalized = value[2:] if value.startswith("0x") else value
        if len(normalized) % 2 != 0:
            raise ValueError(f"{param_name} must contain an even number of hex chars")
        try:
            return bytes.fromhex(normalized)
        except ValueError as exc:
            raise ValueError(f"Invalid {param_name}: {value}") from exc
