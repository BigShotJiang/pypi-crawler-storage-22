from __future__ import annotations

from typing import TYPE_CHECKING, Any

from helpers.bridge_structs import (
    EthToTonTransferResult,
    TonToEthTransferResult,
)
from interfaces.sender_abstraction import SenderAbstraction
from sdk.logger import ConsoleLogger
from structs.struct import EVMAddress, Network, SDKParams, TVMAddress

if TYPE_CHECKING:
    from helpers.eth_ton_helper import EthTonHelper
    from helpers.ton_eth_helper import TonEthHelper


class LayerZeroBridgeHelper:
    def __init__(self) -> None:
        self._tac_sdk: Any | None = None
        self._ton_eth: TonEthHelper | None = None
        self._eth_ton: EthTonHelper | None = None

    @classmethod
    async def create(cls) -> LayerZeroBridgeHelper:
        from helpers.eth_ton_helper import EthTonHelper
        from helpers.ton_eth_helper import TonEthHelper
        from sdk.tac_sdk import TacSdk

        helper = cls()
        helper._tac_sdk = await TacSdk.create(
            SDKParams(network=Network.MAINNET),
            ConsoleLogger(),
        )
        helper._ton_eth = await TonEthHelper._create_with_sdk(helper._tac_sdk)
        helper._eth_ton = await EthTonHelper._create_with_sdk(helper._tac_sdk)
        return helper

    async def sendToETH(
        self,
        sender: SenderAbstraction,
        to_account: EVMAddress,
        asset_id: str,
        amount: int,
    ) -> TonToEthTransferResult:
        await self._ensure_helpers()
        if self._ton_eth is None:
            raise RuntimeError("TonEthHelper is not initialized")
        return await self._ton_eth.sendToETH(
            sender=sender,
            to_account=to_account,
            asset_id=asset_id,
            amount=amount,
        )

    async def sendToTON(
        self,
        signer: object,
        to_account: TVMAddress,
        asset_id: str,
        amount: int,
    ) -> EthToTonTransferResult:
        await self._ensure_helpers()
        if self._eth_ton is None:
            raise RuntimeError("EthTonHelper is not initialized")
        return await self._eth_ton.sendToTON(
            signer=signer,
            to_account=to_account,
            asset_id=asset_id,
            amount=amount,
        )

    async def _ensure_helpers(self) -> None:
        if self._ton_eth is None or self._eth_ton is None:
            raise RuntimeError("LayerZeroBridgeHelper is not initialized. Use `await LayerZeroBridgeHelper.create()` first.")
