from __future__ import annotations

_TYPE_3 = 3
_EXECUTOR_WORKER_ID = 1
_OPTION_TYPE_LZ_COMPOSE = 3

_UINT16_MAX = (1 << 16) - 1
_UINT128_MAX = (1 << 128) - 1


def build_executor_compose_options(index: int, gas_limit: int, native_drop: int = 0) -> str:
    _validate_uint("index", index, _UINT16_MAX)
    _validate_uint("gas_limit", gas_limit, _UINT128_MAX)
    _validate_uint("native_drop", native_drop, _UINT128_MAX)

    params = _encode_uint(index, 2) + _encode_uint(gas_limit, 16)
    if native_drop > 0:
        params += _encode_uint(native_drop, 16)

    option_size = len(params) + 1
    payload = (
        _encode_uint(_TYPE_3, 2)
        + _encode_uint(_EXECUTOR_WORKER_ID, 1)
        + _encode_uint(option_size, 2)
        + _encode_uint(_OPTION_TYPE_LZ_COMPOSE, 1)
        + params
    )
    return "0x" + payload.hex()


def _validate_uint(name: str, value: int, max_value: int) -> None:
    if value < 0:
        raise ValueError(f"{name} must be >= 0")
    if value > max_value:
        raise ValueError(f"{name} must be <= {max_value}")


def _encode_uint(value: int, byte_size: int) -> bytes:
    return int(value).to_bytes(byte_size, "big", signed=False)
