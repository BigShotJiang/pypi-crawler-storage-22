from __future__ import annotations

from typing import Any


def parse_quote_oft_response(response: Any) -> tuple[int, int, int, int]:
    parsed = _extract_quote_oft_parts(response)
    if parsed is not None:
        return parsed

    raise RuntimeError(f"Unsupported quoteOFT response format: {response}")


def validate_oft_amount_bounds(asset_id: str, amount: int, min_amount: int, max_amount: int, sent_amount: int, received_amount: int) -> None:
    _ = (min_amount, received_amount)
    if sent_amount == 0:
        raise RuntimeError(f"Amount is too small for OFT bridge conversion: asset_id={asset_id} amount={amount}")
    if amount > max_amount:
        raise RuntimeError(f"Amount exceeds OFT bridge limit: asset_id={asset_id} amount={amount} max={max_amount}")


def _extract_quote_oft_parts(response: Any) -> tuple[int, int, int, int] | None:
    if isinstance(response, dict):
        return _extract_from_parts(response.get("oftLimit"), response.get("oftReceipt"))

    if isinstance(response, (list, tuple)) and len(response) >= 3:
        parsed = _extract_from_parts(response[0], response[2])
        if parsed is not None:
            return parsed
        if isinstance(response[2], (list, tuple)) and len(response[2]) >= 2:
            return 0, 2**256 - 1, int(response[2][0]), int(response[2][1])

    if hasattr(response, "oftReceipt"):
        return _extract_from_parts(getattr(response, "oftLimit", None), response.oftReceipt)

    return None


def _extract_from_parts(oft_limit: Any, oft_receipt: Any) -> tuple[int, int, int, int] | None:
    if isinstance(oft_limit, dict) and isinstance(oft_receipt, dict):
        min_allowed = oft_limit.get("minAmountLD")
        max_allowed = oft_limit.get("maxAmountLD")
        sent = oft_receipt.get("amountSentLD")
        received = oft_receipt.get("amountReceivedLD")
        if None not in (min_allowed, max_allowed, sent, received):
            return int(min_allowed), int(max_allowed), int(sent), int(received)

    if isinstance(oft_limit, (list, tuple)) and len(oft_limit) >= 2 and isinstance(oft_receipt, (list, tuple)) and len(
        oft_receipt
    ) >= 2:
        return int(oft_limit[0]), int(oft_limit[1]), int(oft_receipt[0]), int(oft_receipt[1])

    if (
        oft_limit is not None
        and hasattr(oft_limit, "minAmountLD")
        and hasattr(oft_limit, "maxAmountLD")
        and hasattr(oft_receipt, "amountSentLD")
        and hasattr(oft_receipt, "amountReceivedLD")
    ):
        return (
            int(oft_limit.minAmountLD),
            int(oft_limit.maxAmountLD),
            int(oft_receipt.amountSentLD),
            int(oft_receipt.amountReceivedLD),
        )

    return None
