from __future__ import annotations

from typing import Any, Mapping, cast

from eth_abi.abi import encode
from web3 import Web3

from helpers.abi_loader import load_helper_abi
from helpers.bridge_structs import (
    ASSET_ID_CBBTC,
    ASSET_ID_WETH,
    COMPOSER_ETH_ABI_FILE,
    DEFAULT_BRIDGE_ROUTES,
    ETH_EID,
    IOFT_ABI_FILE,
    TON_TO_ETH_DEFAULT_NATIVE_FEE_MARKUP_PERCENT,
    TON_TO_ETH_SEND_TO_ARGS_ABI_TYPE,
    BridgeRoute,
    TonEthFeeQuote,
    TonToEthTransferResult,
    tac_w3,
)
from helpers.oft_utils import parse_quote_oft_response, validate_oft_amount_bounds
from helpers.wtac_utils import ensure_wtac_for_tac_action, resolve_tac_provider
from interfaces.i_tac_sdk import ITacSDK
from interfaces.sender_abstraction import SenderAbstraction
from structs.struct import EVMAddress, EvmProxyMsg, Network, SDKParams

_IOFT_ABI = load_helper_abi(IOFT_ABI_FILE)
_COMPOSER_ETH_ABI = load_helper_abi(COMPOSER_ETH_ABI_FILE)


class TonEthHelper:
    def __init__(self) -> None:
        self._tac_sdk: ITacSDK | None = None
        self._routes = self._prepare_routes(DEFAULT_BRIDGE_ROUTES)
        self._eth_eid = int(ETH_EID)
        self._native_fee_markup_percent = int(TON_TO_ETH_DEFAULT_NATIVE_FEE_MARKUP_PERCENT)

    @classmethod
    async def create(cls) -> TonEthHelper:
        from sdk.tac_sdk import TacSdk

        helper = cls()
        helper._tac_sdk = await TacSdk.create(SDKParams(network=Network.MAINNET))
        return helper

    @classmethod
    async def _create_with_sdk(cls, tac_sdk: ITacSDK) -> TonEthHelper:
        helper = cls()
        helper._tac_sdk = tac_sdk
        return helper

    async def sendToETH(
        self,
        sender: SenderAbstraction,
        to_account: EVMAddress,
        asset_id: str,
        amount: int,
    ) -> TonToEthTransferResult:
        tac_sdk = self._require_sdk()
        raw_amount = self._normalize_raw_amount(amount)
        min_amount_ld = 0
        route = self._resolve_route(asset_id)

        to_account_checksum = self._to_checksum_address(str(to_account), "to_account")
        ft = await tac_sdk.getFT(route.token_tvm_address)
        sender_address = sender.getSenderAddress()
        user_balance = int(await ft.getBalanceOf(sender_address))
        if user_balance < raw_amount:
            raise RuntimeError(
                "Insufficient token balance for bridge transfer: "
                f"asset_id={self._normalize_asset_id(asset_id)} sender={sender_address} "
                f"balance={user_balance} requested={raw_amount}"
            )
        oapp_address = await self._resolve_tac_oapp_address(ft, route, asset_id)

        send_param = self._construct_send_param(to_account_checksum, raw_amount, min_amount_ld)
        min_amount_allowed, max_amount_allowed, amount_sent_ld, amount_received_ld = self._get_oft_limits_and_amounts(
            oapp_address, send_param
        )
        validate_oft_amount_bounds(
            asset_id=self._normalize_asset_id(asset_id),
            amount=raw_amount,
            min_amount=min_amount_allowed,
            max_amount=max_amount_allowed,
            sent_amount=amount_sent_ld,
            received_amount=amount_received_ld,
        )

        native_fee, lz_token_fee = self._get_gas_estimations(oapp_address, send_param)
        native_fee_with_markup = self._apply_native_fee_markup(native_fee)
        ensure_wtac_for_tac_action(
            tac_sdk=tac_sdk,
            fallback_provider=tac_w3,
            required_wtac=int(native_fee_with_markup),
            payer=to_account_checksum,
            composer_address=route.composer_address,
        )

        encoded_parameters = self._encode_send_to_args(
            oapp_address=oapp_address,
            send_param=send_param,
            native_fee=native_fee_with_markup,
            lz_token_fee=lz_token_fee,
            refund_address=to_account_checksum,
            payer=to_account_checksum,
        )

        evm_proxy_msg: EvmProxyMsg = {
            "evmTargetAddress": route.composer_address,
            "methodName": "sendTo(bytes,bytes)",
            "encodedParameters": encoded_parameters,
        }
        tx_result = await tac_sdk.sendCrossChainTransaction(
            evm_proxy_msg,
            sender,
            [ft.withRawAmount(raw_amount)],
            None,
        )

        return TonToEthTransferResult(
            asset_id=self._normalize_asset_id(asset_id),
            to_account=to_account_checksum,
            token_tvm_address=route.token_tvm_address,
            token_oapp_address=oapp_address,
            composer_address=route.composer_address,
            amount=raw_amount,
            min_amount_ld=int(min_amount_ld),
            encoded_parameters=encoded_parameters,
            fee_quote=TonEthFeeQuote(
                native_fee=int(native_fee),
                native_fee_with_markup=int(native_fee_with_markup),
                lz_token_fee=int(lz_token_fee),
            ),
            transaction_linker=tx_result,
        )

    async def _resolve_tac_oapp_address(self, ft: Any, route: BridgeRoute, asset_id: str) -> str:
        provider = resolve_tac_provider(self._require_sdk(), tac_w3)

        candidate = self._to_checksum_address(await ft.getEVMAddress(), "token_oapp_address")
        if self._is_contract_deployed(provider, candidate):
            return candidate

        composer_contract = cast(Any, provider.eth).contract(
            address=self._to_checksum_address(route.composer_address, "composer_address"),
            abi=_COMPOSER_ETH_ABI,
        )

        asset = self._normalize_asset_id(asset_id)
        if asset == ASSET_ID_CBBTC:
            fallback = self._to_checksum_address(composer_contract.functions.cbBtcOApp().call(), "cbBtcOApp")
        elif asset == ASSET_ID_WETH:
            fallback = self._to_checksum_address(composer_contract.functions.wethOApp().call(), "wethOApp")
        else:
            raise ValueError(f"Unsupported asset_id: {asset_id}")

        if self._is_contract_deployed(provider, fallback):
            return fallback

        raise RuntimeError(
            "Unable to resolve TAC OApp address for quoteSend: "
            f"candidate={candidate}, fallback={fallback}, asset_id={asset_id}"
        )

    def _require_sdk(self) -> ITacSDK:
        if self._tac_sdk is None:
            raise RuntimeError("TonEthHelper is not initialized. Use `await TonEthHelper.create()` first.")
        return self._tac_sdk

    def _resolve_route(self, asset_id: str) -> BridgeRoute:
        normalized = self._normalize_asset_id(asset_id)
        route = self._routes.get(normalized)
        if route is not None:
            return route
        supported = ", ".join(sorted(self._routes.keys()))
        raise ValueError(f"Unsupported asset_id: {asset_id}. Supported asset_id values: {supported}")

    @staticmethod
    def _normalize_asset_id(asset_id: str) -> str:
        return str(asset_id).strip().lower()

    @staticmethod
    def _prepare_routes(routes: Mapping[str, BridgeRoute]) -> dict[str, BridgeRoute]:
        prepared: dict[str, BridgeRoute] = {}
        for key, route in routes.items():
            normalized_key = TonEthHelper._normalize_asset_id(key)
            if not normalized_key:
                raise ValueError("asset_id route key cannot be empty")
            if not route.token_tvm_address:
                raise ValueError(f"Missing token_tvm_address for asset_id={key}")
            prepared[normalized_key] = BridgeRoute(
                token_tvm_address=route.token_tvm_address,
                composer_address=TonEthHelper._to_checksum_address(route.composer_address, f"composer_address[{key}]"),
                eth_oapp_address=route.eth_oapp_address,
            )
        if not prepared:
            raise ValueError("At least one asset route must be configured")
        return prepared

    def _construct_send_param(
        self,
        recipient_evm_address: str,
        amount_ld: int,
        min_amount_ld: int,
    ) -> tuple[int, bytes, int, int, bytes, bytes, bytes]:
        recipient_bytes32 = self._evm_address_to_bytes32(recipient_evm_address)
        return (
            self._eth_eid,
            recipient_bytes32,
            int(amount_ld),
            int(min_amount_ld),
            b"",
            b"",
            b"",
        )

    def _get_gas_estimations(
        self,
        oapp_address: str,
        send_param: tuple[int, bytes, int, int, bytes, bytes, bytes],
    ) -> tuple[int, int]:
        provider = resolve_tac_provider(self._require_sdk(), tac_w3)

        ioft_contract = cast(Any, provider.eth).contract(
            address=self._to_checksum_address(oapp_address, "oapp_address"),
            abi=_IOFT_ABI,
        )
        fee_response = ioft_contract.functions.quoteSend(send_param, False).call()
        return self._parse_quote_send_response(fee_response)

    def _get_oft_limits_and_amounts(
        self,
        oapp_address: str,
        send_param: tuple[int, bytes, int, int, bytes, bytes, bytes],
    ) -> tuple[int, int, int, int]:
        provider = resolve_tac_provider(self._require_sdk(), tac_w3)
        ioft_contract = cast(Any, provider.eth).contract(
            address=self._to_checksum_address(oapp_address, "oapp_address"),
            abi=_IOFT_ABI,
        )
        quote_oft_response = ioft_contract.functions.quoteOFT(send_param).call()
        return parse_quote_oft_response(quote_oft_response)

    def _encode_send_to_args(
        self,
        oapp_address: str,
        send_param: tuple[int, bytes, int, int, bytes, bytes, bytes],
        native_fee: int,
        lz_token_fee: int,
        refund_address: str,
        payer: str,
    ) -> str:
        send_to_args = (
            self._to_checksum_address(oapp_address, "oapp_address"),
            send_param,
            (int(native_fee), int(lz_token_fee)),
            self._to_checksum_address(refund_address, "refund_address"),
            self._to_checksum_address(payer, "payer"),
        )
        return "0x" + encode([TON_TO_ETH_SEND_TO_ARGS_ABI_TYPE], [send_to_args]).hex()

    def _apply_native_fee_markup(self, native_fee: int) -> int:
        return int(native_fee) * (100 + self._native_fee_markup_percent) // 100

    @staticmethod
    def _normalize_raw_amount(amount: object) -> int:
        if isinstance(amount, bool) or not isinstance(amount, int):
            raise ValueError("amount must be a raw integer (int)")
        if amount <= 0:
            raise ValueError("amount must be greater than 0")
        return amount

    @staticmethod
    def _to_checksum_address(address: str, param_name: str) -> str:
        if not Web3.is_address(address):
            raise ValueError(f"Invalid {param_name}: {address}")
        return Web3.to_checksum_address(address)

    @staticmethod
    def _evm_address_to_bytes32(address: str) -> bytes:
        if not Web3.is_address(address):
            raise ValueError(f"Invalid EVM address: {address}")
        raw = bytes.fromhex(address.lower().replace("0x", ""))
        return raw.rjust(32, b"\x00")

    @staticmethod
    def _parse_quote_send_response(response: Any) -> tuple[int, int]:
        if isinstance(response, dict):
            native_fee = response.get("nativeFee")
            lz_token_fee = response.get("lzTokenFee")
            if native_fee is not None and lz_token_fee is not None:
                return int(native_fee), int(lz_token_fee)

        if hasattr(response, "nativeFee") and hasattr(response, "lzTokenFee"):
            return int(response.nativeFee), int(response.lzTokenFee)

        if isinstance(response, (list, tuple)):
            if len(response) == 2 and not isinstance(response[0], (dict, list, tuple)):
                return int(response[0]), int(response[1])
            if len(response) == 1:
                return TonEthHelper._parse_quote_send_response(response[0])

        raise RuntimeError(f"Unsupported quoteSend response format: {response}")

    @staticmethod
    def _is_contract_deployed(provider: Any, address: str) -> bool:
        eth = getattr(provider, "eth", None)
        if eth is None or not hasattr(eth, "get_code"):
            return True
        try:
            code = eth.get_code(address)
        except Exception:
            return False
        return bool(code and code != b"" and code != b"\x00")
