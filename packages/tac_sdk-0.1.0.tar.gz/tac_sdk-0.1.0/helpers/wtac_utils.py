from __future__ import annotations

from typing import Any, cast

from web3 import Web3

from helpers.abi_loader import load_helper_abi
from helpers.bridge_structs import COMPOSER_ETH_ABI_FILE, WTAC_ABI_FILE

_COMPOSER_ETH_ABI = load_helper_abi(COMPOSER_ETH_ABI_FILE)
_WTAC_ABI = load_helper_abi(WTAC_ABI_FILE)


def resolve_tac_provider(tac_sdk: Any, fallback_provider: Any) -> Any:
    provider = tac_sdk.config.TACParams.get("provider")
    return provider if provider is not None else fallback_provider


def ensure_wtac_for_tac_action(
    tac_sdk: Any,
    fallback_provider: Any,
    required_wtac: int,
    payer: str,
    composer_address: str,
) -> None:
    if int(required_wtac) <= 0:
        return

    provider = resolve_tac_provider(tac_sdk, fallback_provider)
    composer_checksum = _to_checksum_address(composer_address, "composer_address")
    payer_checksum = _to_checksum_address(str(payer), "payer")

    composer_contract = cast(Any, provider.eth).contract(address=composer_checksum, abi=_COMPOSER_ETH_ABI)
    wtac_address = _to_checksum_address(str(composer_contract.functions.wTac().call()), "wtac_address")
    wtac_contract = cast(Any, provider.eth).contract(address=wtac_address, abi=_WTAC_ABI)

    balance = int(wtac_contract.functions.balanceOf(payer_checksum).call())
    if balance < int(required_wtac):
        raise RuntimeError(
            f"Insufficient WTAC balance for payer {payer_checksum}: required={int(required_wtac)}, balance={balance}"
        )

    allowance = int(wtac_contract.functions.allowance(payer_checksum, composer_checksum).call())
    if allowance < int(required_wtac):
        raise RuntimeError(
            "Insufficient WTAC allowance for payer "
            f"{payer_checksum} to composer {composer_checksum}: "
            f"required={int(required_wtac)}, allowance={allowance}"
        )


def _to_checksum_address(address: str, param_name: str) -> str:
    if not Web3.is_address(address):
        raise ValueError(f"Invalid {param_name}: {address}")
    return Web3.to_checksum_address(address)
