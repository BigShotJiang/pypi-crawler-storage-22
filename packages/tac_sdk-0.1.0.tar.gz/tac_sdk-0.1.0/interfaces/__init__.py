import importlib
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from interfaces.asset import Asset
    from interfaces.contract_opener import ContractOpener
    from interfaces.i_configuration import IConfiguration
    from interfaces.i_http_client import HttpResponse, IHttpClient
    from interfaces.i_lite_sequencer_client import ILiteSequencerClient
    from interfaces.i_lite_sequencer_client_factory import ILiteSequencerClientFactory
    from interfaces.i_logger import ILogger
    from interfaces.i_operation_tracker import IOperationTracker
    from interfaces.i_simulator import ISimulator
    from interfaces.i_tac_explorer_client import ITacExplorerClient
    from interfaces.i_tac_sdk import ITacSDK
    from interfaces.i_tx_finalizer import ITxFinalizer
    from interfaces.itac_transaction_manager import ITACTransactionManager
    from interfaces.iton_transaction_manager import ITONTransactionManager
    from interfaces.sender_abstraction import SenderAbstraction
    from interfaces.wallet_instanse import WalletInstanse

__all__ = [
    "ILogger",
    "HttpResponse",
    "IHttpClient",
    "Asset",
    "ContractOpener",
    "IConfiguration",
    "ILiteSequencerClient",
    "ILiteSequencerClientFactory",
    "IOperationTracker",
    "ISimulator",
    "SenderAbstraction",
    "ITacExplorerClient",
    "ITACTransactionManager",
    "ITONTransactionManager",
    "ITxFinalizer",
    "ITacSDK",
    "WalletInstanse",
]

_EXPORTS = {
    "ILogger": ("interfaces.i_logger", "ILogger"),
    "HttpResponse": ("interfaces.i_http_client", "HttpResponse"),
    "IHttpClient": ("interfaces.i_http_client", "IHttpClient"),
    "Asset": ("interfaces.asset", "Asset"),
    "ContractOpener": ("interfaces.contract_opener", "ContractOpener"),
    "IConfiguration": ("interfaces.i_configuration", "IConfiguration"),
    "ILiteSequencerClient": ("interfaces.i_lite_sequencer_client", "ILiteSequencerClient"),
    "ILiteSequencerClientFactory": (
        "interfaces.i_lite_sequencer_client_factory",
        "ILiteSequencerClientFactory",
    ),
    "IOperationTracker": ("interfaces.i_operation_tracker", "IOperationTracker"),
    "ISimulator": ("interfaces.i_simulator", "ISimulator"),
    "SenderAbstraction": ("interfaces.sender_abstraction", "SenderAbstraction"),
    "ITacExplorerClient": ("interfaces.i_tac_explorer_client", "ITacExplorerClient"),
    "ITACTransactionManager": ("interfaces.itac_transaction_manager", "ITACTransactionManager"),
    "ITONTransactionManager": ("interfaces.iton_transaction_manager", "ITONTransactionManager"),
    "ITxFinalizer": ("interfaces.i_tx_finalizer", "ITxFinalizer"),
    "ITacSDK": ("interfaces.i_tac_sdk", "ITacSDK"),
    "WalletInstanse": ("interfaces.wallet_instanse", "WalletInstanse"),
}


def __getattr__(name: str) -> Any:
    target = _EXPORTS.get(name)
    if not target:
        raise AttributeError(name)
    module_name, attr = target
    module = importlib.import_module(module_name)
    return getattr(module, attr)


def __dir__() -> list[str]:
    return sorted(list(globals().keys()) + list(_EXPORTS.keys()))
