from __future__ import annotations

from typing import Any, Protocol

from structs.struct import AssetType, Origin


class Asset(Protocol):
    address: str
    type: AssetType
    rawAmount: int
    origin: Origin

    @property
    def clone(self) -> Asset:
        ...

    def withAmount(self, amount: float) -> Asset:
        ...

    def withRawAmount(self, rawAmount: int) -> Asset:
        ...

    def addAmount(self, amount: float) -> Asset:
        ...

    def addRawAmount(self, rawAmount: int) -> Asset:
        ...

    async def getEVMAddress(self) -> str:
        ...

    async def getTVMAddress(self) -> str:
        ...

    def generatePayload(self, params: Any) -> Any:
        ...

    async def checkCanBeTransferredBy(self, userAddress: str) -> None:
        ...

    async def getBalanceOf(self, userAddress: str) -> int:
        ...
