from __future__ import annotations

from typing import Any, Protocol

from interfaces.i_logger import ILogger
from structs.struct import (
    AddressInformation,
    ContractState,
    GetTransactionsOptions,
    TrackTransactionTreeParams,
    TrackTransactionTreeResult,
)


class ContractOpener(Protocol):
    def setLogger(self, logger: ILogger) -> None:  # noqa: N802
        ...

    def open(self, src: Any) -> Any:
        ...

    async def getContractState(self, address: Any) -> ContractState:
        ...

    async def getTransactions(self, address: Any, opts: GetTransactionsOptions) -> list[Any]:
        ...

    async def getTransactionByHash(
        self, address: Any, hash_value: str, opts: GetTransactionsOptions | None = None
    ) -> Any | None:
        ...

    async def getTransactionByTxHash(
        self, address: Any, tx_hash: str, opts: GetTransactionsOptions | None = None
    ) -> Any | None:
        ...

    async def getTransactionByInMsgHash(
        self, address: Any, msg_hash: str, opts: GetTransactionsOptions | None = None
    ) -> Any | None:
        ...

    async def getTransactionByOutMsgHash(
        self, address: Any, msg_hash: str, opts: GetTransactionsOptions | None = None
    ) -> Any | None:
        ...

    async def getAdjacentTransactions(
        self, address: Any, hash_value: str, opts: GetTransactionsOptions | None = None
    ) -> list[Any]:
        ...

    async def getAddressInformation(self, address: Any) -> AddressInformation:
        ...

    async def getConfig(self) -> str:
        ...

    async def trackTransactionTree(
        self, address: str, hash_value: str, params: TrackTransactionTreeParams | None = None
    ) -> None:
        ...

    async def trackTransactionTreeWithResult(
        self, address: str, hash_value: str, params: TrackTransactionTreeParams | None = None
    ) -> TrackTransactionTreeResult:
        ...

    async def raw_send_message(self, boc: bytes) -> Any:
        ...

    async def closeConnections(self) -> None:
        ...
