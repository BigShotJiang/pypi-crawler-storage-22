from __future__ import annotations

from typing import Any, Protocol

from structs.internal_struct import InternalTACParams, InternalTONParams
from structs.struct import Network


class IConfiguration(Protocol):
    network: Network
    artifacts: Any
    TONParams: InternalTONParams
    TACParams: InternalTACParams
    liteSequencerEndpoints: list[str]

    @property
    def nativeTONAddress(self) -> str:
        ...

    async def nativeTACAddress(self) -> str:
        ...

    @property
    def getTrustedTACExecutors(self) -> list[str]:
        ...

    @property
    def getTrustedTONExecutors(self) -> list[str]:
        ...

    def closeConnections(self) -> Any:
        ...

    async def isContractDeployedOnTVM(self, address: str) -> bool:
        ...
