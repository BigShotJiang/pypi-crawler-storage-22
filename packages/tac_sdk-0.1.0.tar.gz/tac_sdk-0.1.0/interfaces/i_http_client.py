from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Generic, Protocol, TypeVar

T = TypeVar("T")


@dataclass
class HttpResponse(Generic[T]):
    status_code: int
    data: T
    raw: Any | None = None


class IHttpClient(Protocol):
    def get(self, url: str, config: dict | None = None) -> HttpResponse[Any]:
        ...

    def post(self, url: str, data: object, config: dict | None = None) -> HttpResponse[Any]:
        ...
