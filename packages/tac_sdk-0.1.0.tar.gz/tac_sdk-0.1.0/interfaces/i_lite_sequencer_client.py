from __future__ import annotations

from typing import Protocol

from structs.struct import (
    ConvertCurrencyParams,
    ConvertedCurrencyResult,
    ExecutionStagesByOperationId,
    GetTVMExecutorFeeParams,
    OperationIdsByShardsKey,
    OperationType,
    StatusInfosByOperationId,
    SuggestedTVMExecutorFee,
    TACSimulationParams,
    TACSimulationResult,
    TransactionLinker,
)


class ILiteSequencerClient(Protocol):
    async def getOperationType(self, operationId: str) -> OperationType:
        ...

    async def getOperationId(self, transactionLinker: TransactionLinker) -> str:
        ...

    async def getOperationIdByTransactionHash(self, transactionHash: str) -> str:
        ...

    async def getOperationIdsByShardsKeys(
        self, shardsKeys: list[str], caller: str, chunkSize: int | None = None
    ) -> OperationIdsByShardsKey:
        ...

    async def getStageProfilings(
        self, operationIds: list[str], chunkSize: int | None = None
    ) -> ExecutionStagesByOperationId:
        ...

    async def getOperationStatuses(
        self, operationIds: list[str], chunkSize: int | None = None
    ) -> StatusInfosByOperationId:
        ...

    async def convertCurrency(self, params: ConvertCurrencyParams) -> ConvertedCurrencyResult:
        ...

    async def getTVMExecutorFee(self, params: GetTVMExecutorFeeParams) -> SuggestedTVMExecutorFee:
        ...

    async def simulateTACMessage(self, params: TACSimulationParams) -> TACSimulationResult:
        ...
