from __future__ import annotations

from typing import Protocol

from interfaces.i_lite_sequencer_client import ILiteSequencerClient


class ILiteSequencerClientFactory(Protocol):
    def createClients(self, endpoints: list[str]) -> list[ILiteSequencerClient]:
        ...
