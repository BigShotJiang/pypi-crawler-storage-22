from __future__ import annotations

from typing import Protocol


class ILogger(Protocol):
    def debug(self, *arg: object) -> None:
        ...

    def info(self, *arg: object) -> None:
        ...

    def warn(self, *arg: object) -> None:
        ...

    def error(self, *arg: object) -> None:
        ...
