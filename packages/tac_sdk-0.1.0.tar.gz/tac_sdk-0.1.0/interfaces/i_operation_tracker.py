from __future__ import annotations

from typing import Protocol

from structs.struct import (
    ConvertCurrencyParams,
    ConvertedCurrencyResult,
    ExecutionStages,
    ExecutionStagesByOperationId,
    GetTVMExecutorFeeParams,
    OperationIdsByShardsKey,
    OperationType,
    SimplifiedStatuses,
    StatusInfo,
    StatusInfosByOperationId,
    SuggestedTVMExecutorFee,
    TACSimulationParams,
    TACSimulationResult,
    TransactionLinker,
    WaitOptions,
)


class IOperationTracker(Protocol):
    async def getOperationType(self, operationId: str, waitOptions: WaitOptions | None = None) -> OperationType:
        ...

    async def getOperationId(self, transactionLinker: TransactionLinker, waitOptions: WaitOptions | None = None) -> str:
        ...

    async def getOperationIdByTransactionHash(
        self, transactionHash: str, waitOptions: WaitOptions | None = None
    ) -> str:
        ...

    async def getOperationIdsByShardsKeys(
        self,
        shardsKeys: list[str],
        caller: str,
        waitOptions: WaitOptions | None = None,
        chunkSize: int | None = None,
    ) -> OperationIdsByShardsKey:
        ...

    async def getStageProfiling(
        self, operationId: str, waitOptions: WaitOptions | None = None
    ) -> ExecutionStages:
        ...

    async def getStageProfilings(
        self,
        operationIds: list[str],
        waitOptions: WaitOptions | None = None,
        chunkSize: int | None = None,
    ) -> ExecutionStagesByOperationId:
        ...

    async def getOperationStatuses(
        self,
        operationIds: list[str],
        waitOptions: WaitOptions | None = None,
        chunkSize: int | None = None,
    ) -> StatusInfosByOperationId:
        ...

    async def getOperationStatus(self, operationId: str, waitOptions: WaitOptions | None = None) -> StatusInfo:
        ...

    async def getSimplifiedOperationStatus(self, transactionLinker: TransactionLinker) -> SimplifiedStatuses:
        ...

    async def convertCurrency(
        self, params: ConvertCurrencyParams, waitOptions: WaitOptions | None = None
    ) -> ConvertedCurrencyResult:
        ...

    async def simulateTACMessage(
        self, params: TACSimulationParams, waitOptions: WaitOptions | None = None
    ) -> TACSimulationResult:
        ...

    async def getTVMExecutorFee(
        self, params: GetTVMExecutorFeeParams, waitOptions: WaitOptions | None = None
    ) -> SuggestedTVMExecutorFee:
        ...
