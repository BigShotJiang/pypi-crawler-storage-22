from __future__ import annotations

from typing import Protocol

from interfaces.asset import Asset
from interfaces.sender_abstraction import SenderAbstraction
from structs.struct import CrosschainTx, ExecutionFeeEstimationResult, GeneratePayloadParams


class ISimulator(Protocol):
    async def getSimulationsInfo(
        self, sender: SenderAbstraction, txs: list[CrosschainTx]
    ) -> list[ExecutionFeeEstimationResult]:
        ...

    async def getSimulationInfo(self, sender: SenderAbstraction, tx: CrosschainTx) -> ExecutionFeeEstimationResult:
        ...

    async def estimateTONFee(self, asset: Asset, params: GeneratePayloadParams) -> int:
        ...
