from __future__ import annotations

from typing import Protocol

from structs.internal_struct import TacGasPriceResponse


class ITacExplorerClient(Protocol):
    async def getTACGasPrice(self) -> TacGasPriceResponse:
        ...
