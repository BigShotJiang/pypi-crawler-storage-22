from __future__ import annotations

from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from assets import Ft, Nft
    from interfaces.asset import Asset
    from interfaces.contract_opener import ContractOpener
    from interfaces.i_configuration import IConfiguration
    from interfaces.i_operation_tracker import IOperationTracker
    from interfaces.i_tac_explorer_client import ITacExplorerClient
    from interfaces.sender_abstraction import SenderAbstraction
    from structs.struct import (
        AssetFromFTArg,
        AssetFromNFTCollectionArg,
        AssetFromNFTItemArg,
        AssetLike,
        BatchCrossChainTxWithAssetLike,
        CrossChainPayloadResult,
        CrossChainTransactionOptions,
        CrossChainTransactionsOptions,
        CrosschainTx,
        EVMAddress,
        EvmProxyMsg,
        ExecutionFeeEstimationResult,
        NFTAddressType,
        SuggestedTVMExecutorFee,
        TACGasPrice,
        TACSimulationParams,
        TACSimulationResult,
        TransactionLinkerWithOperationId,
        TVMAddress,
        UserWalletBalanceExtended,
        WaitOptions,
    )


class ITacSDK(Protocol):
    config: IConfiguration
    contractOpener: ContractOpener
    operationTracker: IOperationTracker
    explorerClient: ITacExplorerClient

    @property
    def nativeTONAddress(self) -> str:
        ...

    async def nativeTACAddress(self) -> str:
        ...

    async def getSmartAccountAddressForTvmWallet(self, tvmWallet: str, applicationAddress: str) -> str:
        ...

    @property
    def getTrustedTACExecutors(self) -> list[str]:
        ...

    @property
    def getTrustedTONExecutors(self) -> list[str]:
        ...

    async def closeConnections(self) -> Any:
        ...

    async def getAsset(
        self,
        args: AssetFromFTArg | AssetFromNFTCollectionArg | AssetFromNFTItemArg,
    ) -> Asset:
        ...

    async def getFT(self, address: TVMAddress | EVMAddress) -> Ft:
        ...

    async def getNFT(self, args: AssetFromNFTCollectionArg | AssetFromNFTItemArg) -> Nft:
        ...

    async def simulateTACMessage(self, req: TACSimulationParams) -> TACSimulationResult:
        ...

    async def simulateTransactions(
        self, sender: SenderAbstraction, txs: list[CrosschainTx]
    ) -> list[ExecutionFeeEstimationResult]:
        ...

    async def getSimulationInfo(
        self,
        evmProxyMsg: EvmProxyMsg,
        sender: SenderAbstraction,
        assets: list[AssetLike] | None = None,
        options: CrossChainTransactionOptions | None = None,
    ) -> ExecutionFeeEstimationResult:
        ...

    async def getTVMExecutorFeeInfo(
        self, assets: list[AssetLike], feeSymbol: str, tvmValidExecutors: list[str] | None = None
    ) -> SuggestedTVMExecutorFee:
        ...

    async def sendCrossChainTransaction(
        self,
        evmProxyMsg: EvmProxyMsg,
        sender: SenderAbstraction,
        assets: list[AssetLike] | None = None,
        options: CrossChainTransactionOptions | None = None,
        waitOptions: WaitOptions | None = None,
    ) -> TransactionLinkerWithOperationId:
        ...

    async def sendCrossChainTransactions(
        self,
        sender: SenderAbstraction,
        txs: list[BatchCrossChainTxWithAssetLike],
        options: CrossChainTransactionsOptions | None = None,
    ) -> list[TransactionLinkerWithOperationId]:
        ...

    async def bridgeTokensToTON(
        self,
        signer: object,
        value: int,
        tonTarget: str,
        assets: list[AssetLike] | None = None,
        tvmExecutorFee: int | None = None,
        tvmValidExecutors: list[str] | None = None,
    ) -> str:
        ...

    async def getUserJettonWalletAddress(self, userAddress: str, tokenAddress: str) -> str:
        ...

    async def getUserJettonBalance(self, userAddress: str, tokenAddress: str) -> int:
        ...

    async def getUserJettonBalanceExtended(
        self, userAddress: str, tokenAddress: str
    ) -> UserWalletBalanceExtended:
        ...

    async def getJettonData(self, itemAddress: TVMAddress) -> object:
        ...

    async def getNFTItemData(self, itemAddress: TVMAddress) -> object:
        ...

    async def getEVMTokenAddress(self, tvmTokenAddress: str) -> str:
        ...

    async def getTVMTokenAddress(self, evmTokenAddress: str) -> str:
        ...

    async def getTVMNFTAddress(self, evmNFTAddress: str, tokenId: int | None = None) -> str:
        ...

    async def getEVMNFTAddress(self, tvmNFTAddress: str, addressType: NFTAddressType) -> str:
        ...

    async def isContractDeployedOnTVM(self, address: str) -> bool:
        ...

    def getOperationTracker(self) -> IOperationTracker:
        ...

    def getTacExplorerClient(self) -> ITacExplorerClient:
        ...

    def getTonContractOpener(self) -> ContractOpener:
        ...

    async def prepareCrossChainTransactionPayload(
        self,
        evmProxyMsg: EvmProxyMsg,
        senderAddress: str,
        assets: list[AssetLike] | None = None,
        options: CrossChainTransactionOptions | None = None,
    ) -> list[CrossChainPayloadResult]:
        ...

    async def getTACGasPrice(self) -> TACGasPrice:
        ...
