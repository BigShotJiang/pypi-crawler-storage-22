from __future__ import annotations

from typing import Protocol

from structs.struct import TrackTransactionTreeParams


class ITxFinalizer(Protocol):
    async def trackTransactionTree(
        self, address: str, hash_value: str, params: TrackTransactionTreeParams | None = None
    ) -> None:
        ...
