from __future__ import annotations

from typing import Protocol

from interfaces.asset import Asset


class ITACTransactionManager(Protocol):
    async def bridgeTokensToTON(
        self,
        signer: object,
        value: int,
        tonTarget: str,
        assets: list[Asset] | None = None,
        tvmExecutorFee: int | None = None,
        tvmValidExecutors: list[str] | None = None,
    ) -> str:
        ...
