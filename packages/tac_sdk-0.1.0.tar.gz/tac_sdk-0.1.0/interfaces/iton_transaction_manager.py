from __future__ import annotations

from typing import Protocol

from interfaces.asset import Asset
from interfaces.sender_abstraction import SenderAbstraction
from structs.struct import (
    BatchCrossChainTx,
    CrossChainPayloadResult,
    CrossChainTransactionOptions,
    CrossChainTransactionsOptions,
    CrosschainTx,
    EvmProxyMsg,
    FeeParams,
    TransactionLinkerWithOperationId,
)


class ITONTransactionManager(Protocol):
    async def sendCrossChainTransaction(
        self,
        evmProxyMsg: EvmProxyMsg,
        sender: SenderAbstraction,
        tx: CrosschainTx,
    ) -> TransactionLinkerWithOperationId:
        ...

    async def sendCrossChainTransactions(
        self,
        sender: SenderAbstraction,
        txs: list[BatchCrossChainTx],
        options: CrossChainTransactionsOptions | None = None,
    ) -> list[TransactionLinkerWithOperationId]:
        ...

    async def buildFeeParams(
        self,
        options: CrossChainTransactionOptions,
        evmProxyMsg: EvmProxyMsg,
        sender: SenderAbstraction,
        tx: CrosschainTx,
    ) -> FeeParams:
        ...

    async def prepareCrossChainTransactionPayload(
        self,
        evmProxyMsg: EvmProxyMsg,
        senderAddress: str,
        assets: list[Asset],
        options: CrossChainTransactionOptions | None = None,
    ) -> list[CrossChainPayloadResult]:
        ...
