from __future__ import annotations

from typing import Protocol

from interfaces.asset import Asset
from interfaces.contract_opener import ContractOpener
from structs.internal_struct import SendResult, ShardTransaction
from structs.struct import Network


class SenderAbstraction(Protocol):
    async def sendShardTransaction(
        self,
        shardTransaction: ShardTransaction,
        chain: Network | None = None,
        contractOpener: ContractOpener | None = None,
    ) -> SendResult:
        ...

    async def sendShardTransactions(
        self,
        shardTransactions: list[ShardTransaction],
        chain: Network | None = None,
        contractOpener: ContractOpener | None = None,
    ) -> list[SendResult]:
        ...

    def getSenderAddress(self) -> str:
        ...

    async def getBalance(self, contractOpener: ContractOpener) -> int:
        ...

    async def getBalanceOf(self, asset: Asset) -> int:
        ...
