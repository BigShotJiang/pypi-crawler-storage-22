from __future__ import annotations

from typing import Protocol

from pytoniq_core.boc.address import Address
from pytoniq_core.tlb.account import StateInit


class WalletInstanse(Protocol):
    address: Address
    init: StateInit | None

    async def getSeqno(self, provider: object) -> int:
        ...

    async def send(self, provider: object, msg: object) -> str | None:
        ...

    def createTransfer(self, args: dict) -> object:
        ...
