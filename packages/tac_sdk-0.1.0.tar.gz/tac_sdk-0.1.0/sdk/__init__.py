import importlib
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from sdk.configuration import Configuration
    from sdk.lite_sequencer_client import LiteSequencerClient
    from sdk.logger import console_logger, noop_logger
    from sdk.operation_tracker import OperationTracker
    from sdk.requests_http_client import RequestsHttpClient
    from sdk.simulator import Simulator
    from sdk.start_tracking import print_execution_stages_table, start_tracking, start_tracking_multiple
    from sdk.tac_explorer_client import TacExplorerClient
    from sdk.tac_sdk import TacSdk
    from sdk.tac_transaction_manager import TacTransactionManager
    from sdk.ton_eth_helper import (
        ASSET_ID_CBBTC,
        ASSET_ID_WETH,
        DEFAULT_BRIDGE_ROUTES,
        BridgeRoute,
        LayerZeroBridgeHelper,
        EthTonHelper,
        TonEthHelper,
        EthToTonTransferResult,
        TonEthFeeQuote,
        TonToEthTransferResult,
    )
    from sdk.ton_transaction_manager import TonTransactionManager
    from sdk.tx_finalizer import TonTxFinalizer

__all__ = [
    "RequestsHttpClient",
    "Configuration",
    "LiteSequencerClient",
    "console_logger",
    "noop_logger",
    "OperationTracker",
    "Simulator",
    "start_tracking",
    "start_tracking_multiple",
    "print_execution_stages_table",
    "TacExplorerClient",
    "TacSdk",
    "TacTransactionManager",
    "ASSET_ID_CBBTC",
    "ASSET_ID_WETH",
    "DEFAULT_BRIDGE_ROUTES",
    "BridgeRoute",
    "TonEthFeeQuote",
    "TonToEthTransferResult",
    "EthToTonTransferResult",
    "EthTonHelper",
    "LayerZeroBridgeHelper",
    "TonEthHelper",
    "TonTransactionManager",
    "TonTxFinalizer",
]

_EXPORTS = {
    "RequestsHttpClient": ("sdk.requests_http_client", "RequestsHttpClient"),
    "Configuration": ("sdk.configuration", "Configuration"),
    "LiteSequencerClient": ("sdk.lite_sequencer_client", "LiteSequencerClient"),
    "console_logger": ("sdk.logger", "console_logger"),
    "noop_logger": ("sdk.logger", "noop_logger"),
    "OperationTracker": ("sdk.operation_tracker", "OperationTracker"),
    "Simulator": ("sdk.simulator", "Simulator"),
    "start_tracking": ("sdk.start_tracking", "start_tracking"),
    "start_tracking_multiple": ("sdk.start_tracking", "start_tracking_multiple"),
    "print_execution_stages_table": ("sdk.start_tracking", "print_execution_stages_table"),
    "TacExplorerClient": ("sdk.tac_explorer_client", "TacExplorerClient"),
    "TacSdk": ("sdk.tac_sdk", "TacSdk"),
    "TacTransactionManager": ("sdk.tac_transaction_manager", "TacTransactionManager"),
    "ASSET_ID_CBBTC": ("sdk.ton_eth_helper", "ASSET_ID_CBBTC"),
    "ASSET_ID_WETH": ("sdk.ton_eth_helper", "ASSET_ID_WETH"),
    "DEFAULT_BRIDGE_ROUTES": ("sdk.ton_eth_helper", "DEFAULT_BRIDGE_ROUTES"),
    "BridgeRoute": ("sdk.ton_eth_helper", "BridgeRoute"),
    "TonEthFeeQuote": ("sdk.ton_eth_helper", "TonEthFeeQuote"),
    "TonToEthTransferResult": ("sdk.ton_eth_helper", "TonToEthTransferResult"),
    "EthToTonTransferResult": ("sdk.ton_eth_helper", "EthToTonTransferResult"),
    "EthTonHelper": ("sdk.ton_eth_helper", "EthTonHelper"),
    "LayerZeroBridgeHelper": ("sdk.ton_eth_helper", "LayerZeroBridgeHelper"),
    "TonEthHelper": ("sdk.ton_eth_helper", "TonEthHelper"),
    "TonTransactionManager": ("sdk.ton_transaction_manager", "TonTransactionManager"),
    "TonTxFinalizer": ("sdk.tx_finalizer", "TonTxFinalizer"),
}


def __getattr__(name: str) -> Any:
    target = _EXPORTS.get(name)
    if not target:
        raise AttributeError(name)
    module_name, attr = target
    module = importlib.import_module(module_name)
    return getattr(module, attr)


def __dir__() -> list[str]:
    return sorted(list(globals().keys()) + list(_EXPORTS.keys()))
