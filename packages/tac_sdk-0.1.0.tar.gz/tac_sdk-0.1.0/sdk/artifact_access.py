from __future__ import annotations

from typing import Any


def nested_get(source: Any, *keys: str) -> Any:
    current = source
    for key in keys:
        if current is None:
            return None
        if isinstance(current, dict):
            current = current.get(key)
        else:
            current = getattr(current, key, None)
    return current


def artifact_get(artifacts: Any, *paths: tuple[str, ...], default: Any = None) -> Any:
    for path in paths:
        value = nested_get(artifacts, *path)
        if value is not None:
            return value
    return default

