from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from structs.struct import Network


@dataclass
class ArtifactsView:
    data: dict

    def __getitem__(self, item: str) -> Any:
        value = self.data[item]
        return ArtifactsView(value) if isinstance(value, dict) else value

    def __getattr__(self, item: str) -> Any:
        if item in self.data:
            value = self.data[item]
            return ArtifactsView(value) if isinstance(value, dict) else value
        raise AttributeError(item)

    def __contains__(self, item: object) -> bool:
        return item in self.data

    def __iter__(self):
        return iter(self.data)

    def keys(self):
        return self.data.keys()

    def items(self):
        for key, value in self.data.items():
            yield key, ArtifactsView(value) if isinstance(value, dict) else value

    def values(self):
        for value in self.data.values():
            yield ArtifactsView(value) if isinstance(value, dict) else value

    def to_dict(self) -> dict:
        return self.data

    def get(self, key: str, default: Any = None) -> Any:
        value = self.data.get(key, default)
        return ArtifactsView(value) if isinstance(value, dict) else value


def load_artifacts_bundle(path_or_dict: str | Path | dict) -> dict:
    if isinstance(path_or_dict, dict):
        return path_or_dict
    path = Path(path_or_dict)
    if not path.exists():
        raise FileNotFoundError(f"Artifacts bundle not found: {path}")
    return json.loads(path.read_text())


def resolve_artifacts(source: Any, network: Network | str) -> Any:
    if source is None:
        default_bundle = Path(__file__).resolve().parent.parent / "artifacts" / "artifacts.bundle.json"
        if default_bundle.exists():
            source = default_bundle
        else:
            return None

    if isinstance(source, ArtifactsView):
        return source

    if isinstance(source, dict) and {"tac", "ton"} <= set(source.keys()):
        return ArtifactsView(source)

    if isinstance(source, dict) and {"mainnet", "testnet", "dev"} & set(source.keys()):
        bundle = source
        key = _network_key(network)
        if key not in bundle:
            raise KeyError(f"Artifacts bundle does not contain network '{key}'")
        return ArtifactsView(bundle[key])

    if isinstance(source, dict):
        raise ValueError(
            "Artifacts source dict must be either a network bundle (mainnet/testnet/dev) "
            "or a resolved network object with tac/ton sections"
        )

    if isinstance(source, (str, Path)):
        bundle = load_artifacts_bundle(source)
        key = _network_key(network)
        if key not in bundle:
            raise KeyError(f"Artifacts bundle does not contain network '{key}'")
        return ArtifactsView(bundle[key])

    return source


def _network_key(network_name: Network | str) -> str:
    if isinstance(network_name, Network):
        return network_name.value
    return str(network_name)
