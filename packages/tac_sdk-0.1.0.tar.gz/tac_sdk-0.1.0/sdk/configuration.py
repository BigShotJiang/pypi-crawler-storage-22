from __future__ import annotations

import base64
import json
from typing import Any, cast

from pytoniq_core.boc.address import Address
from pytoniq_core.boc.cell import Cell
from pytoniq_core.boc.hashmap.hashmap import HashMap
from pytoniq_core.tlb.config import ConfigParam18, ConfigParam21, ConfigParam25
from web3 import Web3
from web3.contract import Contract as Web3Contract

from interfaces.i_configuration import IConfiguration
from interfaces.i_logger import ILogger
from sdk.artifact_access import artifact_get as _artifact_get
from sdk.artifact_access import nested_get as _nested_get
from sdk.artifacts_loader import resolve_artifacts
from sdk.consts import DEFAULT_RETRY_DELAY_MS, DEFAULT_RETRY_MAX_COUNT
from sdk.fees import DEFAULT_CONTRACT_FEE_USAGE_PARAMS
from sdk.logger import noop_logger
from sdk.utils import get_address_string, get_string, sha256_to_big_int
from structs.internal_struct import InternalTACParams, InternalTONParams, TONFeesParams
from structs.struct import Network, TACParams, TONParams
from wrappers.settings import Settings


def _param_get(params: Any, key: str, default: Any = None) -> Any:
    if isinstance(params, dict):
        return params.get(key, default)
    return getattr(params, key, default)


def _to_checksum(address: str) -> str:
    return Web3.to_checksum_address(address)


class _Web3TokenUtilsAdapter:
    def __init__(
        self,
        web3: Web3,
        contract: Web3Contract,
        erc20_abi: list[dict[str, Any]] | None = None,
        erc721_abi: list[dict[str, Any]] | None = None,
    ) -> None:
        self._web3 = web3
        self._contract = contract
        self._erc20_abi = erc20_abi
        self._erc721_abi = erc721_abi

    async def computeAddress(self, tvm_address: str) -> str:
        return self._contract.functions.computeAddress(str(tvm_address)).call()

    async def computeAddressERC721(self, tvm_address: str) -> str:
        return self._contract.functions.computeAddressERC721(str(tvm_address)).call()

    async def exists(self, value: str) -> bool:
        if isinstance(value, str) and value.startswith("0x") and len(value) == 42:
            try:
                return bool(self._contract.get_function_by_signature("exists(address)")(_to_checksum(value)).call())
            except Exception:
                pass
        return bool(self._contract.get_function_by_signature("exists(string)")(str(value)).call())

    async def getInfo(self, evm_address: str) -> dict[str, Any]:
        checksum = _to_checksum(evm_address)
        if self._erc20_abi:
            try:
                erc20 = cast(Any, self._web3.eth).contract(address=checksum, abi=self._erc20_abi)
                info = erc20.functions.getInfo().call()
                if isinstance(info, (list, tuple)) and len(info) >= 4:
                    return {"tvmAddress": info[3]}
            except Exception:
                pass
        if self._erc721_abi:
            try:
                erc721 = cast(Any, self._web3.eth).contract(address=checksum, abi=self._erc721_abi)
                info = erc721.functions.getInfo().call()
                if isinstance(info, (list, tuple)) and len(info) >= 4:
                    return {"tvmAddress": info[3]}
            except Exception:
                pass
        return {"tvmAddress": None}


class _Web3SmartAccountFactoryAdapter:
    def __init__(self, contract: Web3Contract) -> None:
        self._contract = contract

    async def getSmartAccountForApplication(self, tvm_wallet: str, application: str) -> str:
        return self._contract.functions.getSmartAccountForApplication(
            str(tvm_wallet),
            _to_checksum(application),
        ).call()


class _Web3CrossChainLayerAdapter:
    def __init__(self, contract: Web3Contract) -> None:
        self.contract = contract

    async def getAddress(self) -> str:
        return self.contract.address

    async def getProtocolFee(self) -> int:
        return int(self.contract.functions.getProtocolFee().call())

    async def nativeTokenAddress(self) -> str:
        return self.contract.functions.NATIVE_TOKEN_ADDRESS().call()


class Configuration(IConfiguration):
    def __init__(
        self,
        network: Network,
        artifacts: Any,
        ton_params: InternalTONParams,
        tac_params: InternalTACParams,
        lite_sequencer_endpoints: list[str],
        logger: ILogger,
    ) -> None:
        self.network = network
        self.artifacts = artifacts
        self.TONParams = ton_params
        self.TACParams = tac_params
        self.liteSequencerEndpoints = lite_sequencer_endpoints
        self.logger = logger

    @staticmethod
    async def create(
        network: Network,
        artifacts: Any,
        ton_params_input: TONParams | None = None,
        tac_params_input: TACParams | None = None,
        custom_lite_sequencer_endpoints: list[str] | None = None,
        pass_logger_to_openers: bool | None = None,
        delay: int | None = None,
        logger: ILogger | None = None,
    ) -> Configuration:
        log = logger or noop_logger()
        artifacts = resolve_artifacts(artifacts, network)

        resolved_ton_params = ton_params_input or TONParams()
        resolved_tac_params = tac_params_input or TACParams()

        retry_delay = delay if delay is not None else DEFAULT_RETRY_DELAY_MS
        should_pass_logger_to_openers = pass_logger_to_openers if pass_logger_to_openers is not None else True
        internal_ton = await Configuration._prepare_ton_params(
            network,
            artifacts,
            resolved_ton_params,
            retry_delay,
            log,
            should_pass_logger_to_openers,
        )
        internal_tac = Configuration._prepare_tac_params(network, artifacts, resolved_tac_params, log)

        if network == Network.DEV:
            if not custom_lite_sequencer_endpoints:
                raise ValueError("For dev network, custom lite sequencer endpoints must be provided")
            endpoints = custom_lite_sequencer_endpoints
        else:
            if custom_lite_sequencer_endpoints:
                endpoints = custom_lite_sequencer_endpoints
            else:
                endpoints = _artifact_get(
                    artifacts,
                    ("PUBLIC_LITE_SEQUENCER_ENDPOINTS",),
                    ("tac", "endpoints", "PUBLIC_LITE_SEQUENCER_ENDPOINTS"),
                )
                if endpoints is None:
                    raise RuntimeError("Artifacts do not include PUBLIC_LITE_SEQUENCER_ENDPOINTS")

        return Configuration(network, artifacts, internal_ton, internal_tac, endpoints, log)

    @staticmethod
    async def _prepare_ton_params(
        network: Network,
        artifacts: Any,
        ton_params: TONParams,
        delay: int,
        logger: ILogger,
        pass_logger_to_openers: bool = True,
    ) -> InternalTONParams:
        if network == Network.DEV:
            contract_opener = _param_get(ton_params, "contractOpener")
            if contract_opener is None:
                raise ValueError("For dev network, a custom contract opener must be provided in TONParams")
            settings_address = _param_get(ton_params, "settingsAddress")
            if not settings_address:
                raise ValueError("For dev network, a custom settings address must be provided in TONParams")
        else:
            endpoint = _artifact_get(
                artifacts,
                ("TON_RPC_ENDPOINT_BY_TAC",),
                ("ton", "endpoints", "TON_RPC_ENDPOINT_BY_TAC"),
            )
            contract_opener = _param_get(ton_params, "contractOpener")
            if contract_opener is None:
                if not endpoint:
                    raise RuntimeError("TON_RPC_ENDPOINT_BY_TAC is not configured in artifacts")
                from adapters import create_default_retryable_opener

                contract_opener = await create_default_retryable_opener(
                    endpoint,
                    network,
                    DEFAULT_RETRY_MAX_COUNT,
                    delay,
                    logger if pass_logger_to_openers else None,
                )

            settings_address = _param_get(ton_params, "settingsAddress") or _artifact_get(
                artifacts,
                ("TON_SETTINGS_ADDRESS",),
                ("ton", "addresses", "TON_SETTINGS_ADDRESS"),
                default="",
            )

        if not settings_address:
            raise RuntimeError("TON settings address is not configured")

        if pass_logger_to_openers:
            contract_opener.setLogger(logger)

        settings = contract_opener.open(Settings.createFromAddress(Address(settings_address)))
        all_settings_cell = await settings.getAll()
        settings_dict = Configuration._parse_settings_cell(all_settings_cell)
        if not settings_dict:
            raise RuntimeError("Failed to load TON settings via get_all")

        internal_ton: InternalTONParams = {
            "contractOpener": contract_opener,
            "crossChainLayerAddress": get_address_string(settings_dict.get(sha256_to_big_int("CrossChainLayerAddress"))),
            "jettonProxyAddress": get_address_string(settings_dict.get(sha256_to_big_int("JettonProxyAddress"))),
            "nftProxyAddress": get_address_string(settings_dict.get(sha256_to_big_int("NFTProxyAddress"))),
            "jettonWalletCode": settings_dict.get(sha256_to_big_int("JettonWalletCode")),
            "jettonMinterCode": settings_dict.get(sha256_to_big_int("JettonMinterCode")),
            "nftItemCode": settings_dict.get(sha256_to_big_int("NFTItemCode")),
            "nftCollectionCode": settings_dict.get(sha256_to_big_int("NFTCollectionCode")),
        }

        contract_fee_cell = settings_dict.get(sha256_to_big_int("ContractFeeUsageParams"))
        if contract_fee_cell:
            try:
                json_str = get_string(contract_fee_cell)
                internal_ton["contractFeeUsageParams"] = json.loads(json_str)
            except Exception:
                logger.debug("Failed to load ContractFeeUsageParams from Settings, used default")
                internal_ton["contractFeeUsageParams"] = DEFAULT_CONTRACT_FEE_USAGE_PARAMS
        else:
            logger.debug("Failed to load ContractFeeUsageParams from Settings, used default")
            internal_ton["contractFeeUsageParams"] = DEFAULT_CONTRACT_FEE_USAGE_PARAMS

        internal_ton["feesParams"] = await Configuration._retrieve_ton_fees_params(contract_opener)
        return internal_ton

    @staticmethod
    def _prepare_tac_params(
        network: Network,
        artifacts: Any,
        tac_params: TACParams,
        logger: ILogger,
    ) -> InternalTACParams:
        provider_input = _param_get(tac_params, "provider")
        rpc_endpoint = _artifact_get(
            artifacts,
            ("TAC_RPC_ENDPOINT",),
            ("tac", "endpoints", "TAC_RPC_ENDPOINT"),
        )
        if provider_input is None and network == Network.DEV:
            raise ValueError("For dev network, TAC provider must be provided")
        web3 = Configuration._resolve_web3(provider_input, rpc_endpoint)

        settings_address = _param_get(tac_params, "settingsAddress") or _artifact_get(
            artifacts,
            ("TAC_SETTINGS_ADDRESS",),
            ("tac", "addresses", "TAC_SETTINGS_ADDRESS"),
        )
        if not settings_address:
            raise ValueError("TAC settings address is not configured")

        sa_factory_address = _param_get(tac_params, "saFactoryAddress") or _artifact_get(
            artifacts,
            ("TAC_SMART_ACCOUNT_FACTORY_ADDRESS",),
            ("tac", "addresses", "TAC_SMART_ACCOUNT_FACTORY_ADDRESS"),
        )

        compilation_artifacts = _artifact_get(
            artifacts,
            ("tac", "compilationArtifacts"),
            ("compilationArtifacts",),
            default={},
        )

        settings_abi = Configuration._extract_abi(compilation_artifacts, "ISettings", "Settings")
        if not settings_abi:
            raise ValueError("ISettings ABI is not available in artifacts")

        cross_chain_layer_abi = Configuration._extract_abi(
            compilation_artifacts,
            "CrossChainLayer",
            "ICrossChainLayer",
        )
        token_utils_abi = Configuration._extract_abi(compilation_artifacts, "ITokenUtils", "TokenUtils")
        sa_factory_abi = Configuration._extract_abi(compilation_artifacts, "ISAFactory")
        erc20_abi = Configuration._extract_abi(compilation_artifacts, "IERC20WithDecimals", "CrossChainLayerERC20")
        erc721_abi = Configuration._extract_abi(compilation_artifacts, "IERC721", "CrossChainLayerERC721")

        settings_contract = cast(Any, web3.eth).contract(address=_to_checksum(settings_address), abi=settings_abi)

        trusted_tac_executors: list[str] = []
        trusted_ton_executors: list[str] = []
        cross_chain_layer_address = ""
        token_utils_address = ""

        try:
            cross_chain_layer_address = settings_contract.functions.getAddressSetting(
                Web3.keccak(text="CrossChainLayerAddress")
            ).call()
            token_utils_address = settings_contract.functions.getAddressSetting(
                Web3.keccak(text="TokenUtilsAddress")
            ).call()
            trusted_tac_executors = settings_contract.functions.getTrustedEVMExecutors().call()
            trusted_ton_executors = settings_contract.functions.getTrustedTVMExecutors().call()
        except Exception as exc:
            logger.debug(f"Failed to load TAC settings from chain: {exc}")

        if not trusted_tac_executors:
            trusted_tac_executors = []
        if not trusted_ton_executors:
            trusted_ton_executors = []

        if not cross_chain_layer_address:
            raise ValueError("CrossChainLayerAddress is not configured in TAC settings")
        if not token_utils_address:
            raise ValueError("TokenUtilsAddress is not configured in TAC settings")

        if not cross_chain_layer_abi:
            raise ValueError("ICrossChainLayer ABI is not available in artifacts")
        if not token_utils_abi:
            raise ValueError("ITokenUtils ABI is not available in artifacts")

        cross_chain_layer_contract = cast(Any, web3.eth).contract(
            address=_to_checksum(cross_chain_layer_address),
            abi=cross_chain_layer_abi,
        )
        token_utils_contract = cast(Any, web3.eth).contract(
            address=_to_checksum(token_utils_address),
            abi=token_utils_abi,
        )

        smart_account_factory = None
        if sa_factory_address and sa_factory_abi:
            smart_account_factory_contract = cast(Any, web3.eth).contract(
                address=_to_checksum(sa_factory_address),
                abi=sa_factory_abi,
            )
            smart_account_factory = _Web3SmartAccountFactoryAdapter(smart_account_factory_contract)

        internal_tac: InternalTACParams = {
            "provider": web3,
            "settings": settings_contract,
            "crossChainLayer": _Web3CrossChainLayerAdapter(cross_chain_layer_contract),
            "tokenUtils": _Web3TokenUtilsAdapter(
                web3,
                token_utils_contract,
                erc20_abi=erc20_abi,
                erc721_abi=erc721_abi,
            ),
            "trustedTACExecutors": trusted_tac_executors,
            "trustedTONExecutors": trusted_ton_executors,
        }
        if smart_account_factory:
            internal_tac["smartAccountFactory"] = smart_account_factory

        if isinstance(tac_params, dict):
            provider_value = tac_params.get("provider")
            if provider_value is not None:
                internal_tac["provider"] = provider_value

            cross_chain_layer_value = tac_params.get("crossChainLayer")
            if cross_chain_layer_value is not None:
                internal_tac["crossChainLayer"] = cross_chain_layer_value

            settings_value = tac_params.get("settings")
            if settings_value is not None:
                internal_tac["settings"] = settings_value

            token_utils_value = tac_params.get("tokenUtils")
            if token_utils_value is not None:
                internal_tac["tokenUtils"] = token_utils_value

            smart_account_factory_value = tac_params.get("smartAccountFactory")
            if smart_account_factory_value is not None:
                internal_tac["smartAccountFactory"] = smart_account_factory_value

            trusted_tac_executors_value = tac_params.get("trustedTACExecutors")
            if trusted_tac_executors_value is not None:
                internal_tac["trustedTACExecutors"] = trusted_tac_executors_value

            trusted_ton_executors_value = tac_params.get("trustedTONExecutors")
            if trusted_ton_executors_value is not None:
                internal_tac["trustedTONExecutors"] = trusted_ton_executors_value

            abi_coder_value = tac_params.get("abiCoder")
            if abi_coder_value is not None:
                internal_tac["abiCoder"] = abi_coder_value

        return internal_tac

    @staticmethod
    def _resolve_web3(provider_input: Any, rpc_endpoint: str | None) -> Web3:
        if isinstance(provider_input, Web3):
            return provider_input
        if hasattr(provider_input, "eth") and hasattr(provider_input, "provider"):
            return provider_input
        if provider_input is None and rpc_endpoint:
            return Web3(Web3.HTTPProvider(rpc_endpoint))
        if isinstance(provider_input, str) and provider_input:
            return Web3(Web3.HTTPProvider(provider_input))
        raise ValueError("TAC provider is not configured")

    @staticmethod
    def _extract_abi(artifacts: Any, *names: str) -> list[dict[str, Any]] | None:
        for name in names:
            entry = _nested_get(artifacts, name)
            if isinstance(entry, dict) and isinstance(entry.get("abi"), list):
                return entry["abi"]
            abi = _nested_get(artifacts, name, "abi")
            if isinstance(abi, list):
                return abi
        return None

    @staticmethod
    def _parse_settings_cell(cell: Cell) -> dict[int, Cell]:
       return HashMap.parse(cell.begin_parse(), 256, value_deserializer=lambda s: s.load_ref()) or {}

    @staticmethod
    async def _retrieve_ton_fees_params(contract_opener: Any) -> TONFeesParams:
        try:
            config_b64 = await contract_opener.getConfig()
            cell = Cell.one_from_boc(base64.b64decode(config_b64))
            if isinstance(cell, list):
                cell = cell[0]
            params = HashMap.parse(cell.begin_parse(), 32, value_deserializer=lambda s: s.load_ref()) or {}

            storage_prices = ConfigParam18.deserialize(params[18].begin_parse())
            gas_prices = ConfigParam21.deserialize(params[21].begin_parse())
            msg_prices = ConfigParam25.deserialize(params[25].begin_parse())

            storage_entry = None
            if storage_prices:
                key = sorted(storage_prices.keys())[0]
                storage_entry = storage_prices[key]

            if gas_prices is None:
                raise ValueError("Invalid gas prices config")
            if msg_prices is None:
                raise ValueError("Invalid message prices config")
            other_prices = gas_prices.other
            gas_price = gas_prices.gas_price if gas_prices.type_ != "gas_flat_pfx" else (other_prices.gas_price if other_prices else None)
            if gas_price is None:
                raise ValueError("Invalid gas price")

            return {
                "gasPrice": int(gas_price),
                "lumpPrice": int(msg_prices.lump_price),
                "msgBitPrice": int(msg_prices.bit_price),
                "msgCellPrice": int(msg_prices.cell_price),
                "ihrPriceFactor": int(msg_prices.ihr_price_factor),
                "firstFrac": int(msg_prices.first_frac),
                "accountBitPrice": int(storage_entry.bit_price_ps if storage_entry else 1),
                "accountCellPrice": int(storage_entry.cell_price_ps if storage_entry else 500),
            }
        except Exception:
            return {
                "accountBitPrice": 1,
                "accountCellPrice": 500,
                "lumpPrice": 400000,
                "gasPrice": 26214400,
                "firstFrac": 21845,
                "ihrPriceFactor": 98304,
                "msgBitPrice": 26214400,
                "msgCellPrice": 2621440000,
            }

    @property
    def nativeTONAddress(self) -> str:
        native_address = _artifact_get(
            self.artifacts,
            ("ton_NATIVE_ADDRESS",),
            ("ton", "addresses", "ton_NATIVE_ADDRESS"),
            default=None,
        )
        return native_address or "NONE"

    async def nativeTACAddress(self) -> str:
        native = _artifact_get(
            self.artifacts,
            ("TAC_NATIVE_ADDRESS",),
            ("tac", "addresses", "TAC_NATIVE_ADDRESS"),
        )
        if native:
            return native

        cross_chain_layer = self.TACParams.get("crossChainLayer")
        if cross_chain_layer and hasattr(cross_chain_layer, "nativeTokenAddress"):
            return await cross_chain_layer.nativeTokenAddress()

        raise RuntimeError("Unable to resolve TAC native token address")

    @property
    def getTrustedTACExecutors(self) -> list[str]:
        return self.TACParams.get("trustedTACExecutors", [])

    @property
    def getTrustedTONExecutors(self) -> list[str]:
        return self.TACParams.get("trustedTONExecutors", [])

    async def isContractDeployedOnTVM(self, address: str) -> bool:
        opener = self.TONParams.get("contractOpener")
        if not opener:
            raise RuntimeError("Contract opener is not configured")
        state = await opener.getContractState(address)
        return state.get("state") == "active"

    def closeConnections(self) -> Any:
        opener = self.TONParams.get("contractOpener")
        if opener is None:
            return None
        close_fn = getattr(opener, "closeConnections", None)
        if callable(close_fn):
            return close_fn()
        return None

_web3_token_utils_adapter = _Web3TokenUtilsAdapter
_web3_smart_account_factory_adapter = _Web3SmartAccountFactoryAdapter
_web3_cross_chain_layer_adapter = _Web3CrossChainLayerAdapter
