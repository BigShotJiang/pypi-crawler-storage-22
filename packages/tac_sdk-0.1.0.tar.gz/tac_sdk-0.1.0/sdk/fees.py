from __future__ import annotations

from sdk.consts import ONE_YEAR_SECONDS
from structs.internal_struct import ContractFeeUsageParams, TransactionFeeCalculationStep

FIXED_POINT_SHIFT = 2 ** 16

DEFAULT_CONTRACT_FEE_USAGE_PARAMS: ContractFeeUsageParams = {
    "crossChainLayer": {
        "accountBits": 43514,
        "accountCells": 100,
        "gas": {"tvmMsgToEvm": 14619},
    },
    "jettonWallet": {
        "accountBits": 949,
        "accountCells": 3,
        "estimatedAccountBits": 11000,
        "estimatedAccountCells": 25,
        "initStateBits": 847,
        "initStateCells": 3,
        "gas": {
            "internalTransfer": 10669,
            "receive": 11427,
            "burn": 8653,
            "estimatedSendTransfer": 11000,
            "estimatedReceiveTransfer": 12000,
        },
    },
    "jettonProxy": {
        "accountBits": 7760,
        "accountCells": 16,
        "gas": {
            "ownershipAssigned": 8515,
            "transferNotification": 8515,
            "errorNotification": 5556,
        },
    },
    "jettonMinter": {
        "accountBits": 10208,
        "accountCells": 28,
        "gas": {
            "burnNotification": 10357,
            "mintAfterError": 9654,
        },
    },
    "nftItem": {
        "accountBits": 1422,
        "accountCells": 5,
        "gas": {
            "send": 11722,
            "burn": 11552,
            "errorNotification": 4638,
        },
    },
    "nftProxy": {
        "accountBits": 7512,
        "accountCells": 15,
        "gas": {
            "ownershipAssigned": 7688,
            "errorNotification": 4737,
        },
    },
}


def create_cross_chain_layer_tvm_msg_to_evm_step(
    params: ContractFeeUsageParams, msgBits: int, msgCells: int
) -> TransactionFeeCalculationStep:
    return {
        "accountBits": 0,
        "accountCells": 0,
        "gasUsed": params["crossChainLayer"]["gas"]["tvmMsgToEvm"],
        "msgBits": msgBits,
        "msgCells": msgCells,
        "timeDelta": ONE_YEAR_SECONDS,
    }


def create_jetton_wallet_internal_transfer_step(
    params: ContractFeeUsageParams, msgBits: int, msgCells: int
) -> TransactionFeeCalculationStep:
    return {
        "accountBits": params["jettonWallet"]["accountBits"],
        "accountCells": params["jettonWallet"]["accountCells"],
        "gasUsed": params["jettonWallet"]["gas"]["internalTransfer"],
        "msgBits": msgBits,
        "msgCells": msgCells,
        "timeDelta": ONE_YEAR_SECONDS,
    }


def create_jetton_wallet_receive_step(
    params: ContractFeeUsageParams, msgBits: int, msgCells: int
) -> TransactionFeeCalculationStep:
    return {
        "accountBits": params["jettonWallet"]["accountBits"],
        "accountCells": params["jettonWallet"]["accountCells"],
        "gasUsed": params["jettonWallet"]["gas"]["receive"],
        "msgBits": msgBits,
        "msgCells": msgCells,
        "timeDelta": ONE_YEAR_SECONDS,
    }


def create_jetton_wallet_burn_step(
    params: ContractFeeUsageParams, msgBits: int, msgCells: int
) -> TransactionFeeCalculationStep:
    return {
        "accountBits": params["jettonWallet"]["accountBits"],
        "accountCells": params["jettonWallet"]["accountCells"],
        "gasUsed": params["jettonWallet"]["gas"]["burn"],
        "msgBits": msgBits,
        "msgCells": msgCells,
        "timeDelta": ONE_YEAR_SECONDS,
    }


def create_jetton_proxy_ownership_assigned_step(
    params: ContractFeeUsageParams, msgBits: int, msgCells: int
) -> TransactionFeeCalculationStep:
    return {
        "accountBits": 0,
        "accountCells": 0,
        "gasUsed": params["jettonProxy"]["gas"]["ownershipAssigned"],
        "msgBits": msgBits,
        "msgCells": msgCells,
        "timeDelta": ONE_YEAR_SECONDS,
    }


def create_jetton_minter_burn_notification_step(
    params: ContractFeeUsageParams, msgBits: int, msgCells: int
) -> TransactionFeeCalculationStep:
    return {
        "accountBits": params["jettonMinter"]["accountBits"],
        "accountCells": params["jettonMinter"]["accountCells"],
        "gasUsed": params["jettonMinter"]["gas"]["burnNotification"],
        "msgBits": msgBits,
        "msgCells": msgCells,
        "timeDelta": ONE_YEAR_SECONDS,
    }


def create_nft_item_send_step(
    params: ContractFeeUsageParams, msgBits: int, msgCells: int
) -> TransactionFeeCalculationStep:
    return {
        "accountBits": params["nftItem"]["accountBits"],
        "accountCells": params["nftItem"]["accountCells"],
        "gasUsed": params["nftItem"]["gas"]["send"],
        "msgBits": msgBits,
        "msgCells": msgCells,
        "timeDelta": ONE_YEAR_SECONDS,
    }


def create_nft_item_burn_step(
    params: ContractFeeUsageParams, msgBits: int, msgCells: int
) -> TransactionFeeCalculationStep:
    return {
        "accountBits": params["nftItem"]["accountBits"],
        "accountCells": params["nftItem"]["accountCells"],
        "gasUsed": params["nftItem"]["gas"]["burn"],
        "msgBits": msgBits,
        "msgCells": msgCells,
        "timeDelta": ONE_YEAR_SECONDS,
    }


def create_nft_proxy_ownership_assigned_step(
    params: ContractFeeUsageParams, msgBits: int, msgCells: int
) -> TransactionFeeCalculationStep:
    return {
        "accountBits": 0,
        "accountCells": 0,
        "gasUsed": params["nftProxy"]["gas"]["ownershipAssigned"],
        "msgBits": msgBits,
        "msgCells": msgCells,
        "timeDelta": ONE_YEAR_SECONDS,
    }


def create_error_notification_gas_step(
    params: ContractFeeUsageParams, msgBits: int, msgCells: int
) -> TransactionFeeCalculationStep:
    return {
        "accountBits": 0,
        "accountCells": 0,
        "gasUsed": params["jettonProxy"]["gas"]["errorNotification"],
        "msgBits": msgBits,
        "msgCells": msgCells,
        "timeDelta": 0,
    }


def create_estimated_send_transfer_gas_step(
    params: ContractFeeUsageParams, msgBits: int, msgCells: int
) -> TransactionFeeCalculationStep:
    return {
        "accountBits": 0,
        "accountCells": 0,
        "gasUsed": params["jettonWallet"]["gas"]["estimatedSendTransfer"],
        "msgBits": msgBits,
        "msgCells": msgCells,
        "timeDelta": 0,
    }


def create_estimated_receive_transfer_gas_step(
    params: ContractFeeUsageParams, msgBits: int, msgCells: int
) -> TransactionFeeCalculationStep:
    return {
        "accountBits": 0,
        "accountCells": 0,
        "gasUsed": params["jettonWallet"]["gas"]["estimatedReceiveTransfer"],
        "msgBits": msgBits,
        "msgCells": msgCells,
        "timeDelta": 0,
    }


def create_mint_after_error_gas_step(
    params: ContractFeeUsageParams, msgBits: int, msgCells: int
) -> TransactionFeeCalculationStep:
    return {
        "accountBits": params["jettonMinter"]["accountBits"],
        "accountCells": params["jettonMinter"]["accountCells"],
        "gasUsed": params["jettonMinter"]["gas"]["mintAfterError"],
        "msgBits": msgBits,
        "msgCells": msgCells,
        "timeDelta": ONE_YEAR_SECONDS,
    }


def create_nft_proxy_error_notification_step(
    params: ContractFeeUsageParams, msgBits: int, msgCells: int
) -> TransactionFeeCalculationStep:
    return {
        "accountBits": 0,
        "accountCells": 0,
        "gasUsed": params["nftProxy"]["gas"]["errorNotification"],
        "msgBits": msgBits,
        "msgCells": msgCells,
        "timeDelta": 0,
    }


def create_nft_item_error_notification_step(
    params: ContractFeeUsageParams,
) -> TransactionFeeCalculationStep:
    return {
        "accountBits": 0,
        "accountCells": 0,
        "gasUsed": params["nftItem"]["gas"]["errorNotification"],
        "msgBits": 0,
        "msgCells": 0,
        "timeDelta": 0,
    }
