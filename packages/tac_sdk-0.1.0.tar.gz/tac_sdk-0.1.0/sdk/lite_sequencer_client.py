from __future__ import annotations

import re
from collections.abc import Callable
from typing import Any
from urllib.parse import urljoin

from errors import empty_array_error, operation_fetch_error, profiling_fetch_error, status_fetch_error
from errors.instances import convert_currency_fetch_error, get_ton_fee_info_fetch_error, simulation_fetch_error
from interfaces.i_http_client import IHttpClient
from interfaces.i_lite_sequencer_client import ILiteSequencerClient
from sdk.requests_http_client import RequestsHttpClient
from sdk.utils import to_camel_case_transformer
from structs.internal_struct import (
    OperationIdWithLogIndexResponse,
    OperationTypeResponse,
    StringResponse,
)
from structs.struct import (
    ConvertCurrencyParams,
    ConvertedCurrencyResult,
    ExecutionStagesByOperationId,
    GetTVMExecutorFeeParams,
    OperationIdsByShardsKey,
    OperationType,
    StatusInfosByOperationId,
    SuggestedTVMExecutorFee,
    TACSimulationParams,
    TACSimulationResult,
    TransactionLinker,
)


class LiteSequencerClient(ILiteSequencerClient):
    def __init__(self, endpoint: str, max_chunk_size: int = 100, http_client: IHttpClient | None = None):
        self.endpoint = endpoint
        self.max_chunk_size = max_chunk_size
        self.http_client = http_client or RequestsHttpClient()

    def _build_url(self, path: str) -> str:
        base = self.endpoint if self.endpoint.endswith("/") else f"{self.endpoint}/"
        return urljoin(base, path)

    async def getOperationIdByTransactionHash(self, transactionHash: str) -> str:
        is_eth_hash = bool(re.fullmatch(r"0x[a-fA-F0-9]{64}", transactionHash or ""))
        path = "tac/operation-id" if is_eth_hash else "ton/operation-id"
        try:
            if is_eth_hash:
                response = self.http_client.get(
                    self._build_url(path),
                    {"params": {"transactionHash": transactionHash}},
                )
                data: OperationIdWithLogIndexResponse = response.data
                return (data.get("response") or {}).get("operationId", "")
            response = self.http_client.get(
                self._build_url(path),
                {"params": {"transactionHash": transactionHash}},
            )
            text_data: StringResponse = response.data
            return text_data.get("response", "")
        except Exception as error:
            if _get_http_status_code(error) == 404:
                return ""
            raise operation_fetch_error(f"endpoint {self.endpoint} failed to complete request", error) from error

    async def getOperationType(self, operationId: str) -> OperationType:
        try:
            response = self.http_client.get(
                self._build_url("operation-type"),
                {"params": {"operationId": operationId}},
            )
            data: OperationTypeResponse = response.data
            return data.get("response", "")
        except Exception as error:
            raise operation_fetch_error(f"endpoint {self.endpoint} failed to complete request", error) from error

    async def getOperationId(self, transactionLinker: TransactionLinker) -> str:
        payload = {
            "shardsKey": transactionLinker["shardsKey"],
            "caller": transactionLinker["caller"],
            "shardCount": transactionLinker["shardCount"],
            "timestamp": transactionLinker["timestamp"],
        }
        try:
            response = self.http_client.post(
                self._build_url("ton/operation-id"),
                payload,
            )
            data: StringResponse = response.data
            return data.get("response", "")
        except Exception as error:
            if _get_http_status_code(error) == 404:
                return ""
            raise operation_fetch_error(f"endpoint {self.endpoint} failed to complete request", error) from error

    async def getOperationIdsByShardsKeys(
        self, shardsKeys: list[str], caller: str, chunkSize: int | None = None
    ) -> OperationIdsByShardsKey:
        if not shardsKeys:
            raise empty_array_error("shardsKeys")
        try:
            response_data = await self._process_chunked_request(
                shardsKeys,
                lambda chunk: self.http_client.post(
                    self._build_url("operation-ids-by-shards-keys"),
                    {"shardsKeys": chunk, "caller": caller},
                ).data,
                chunkSize or self.max_chunk_size,
            )
            if not isinstance(response_data, dict):
                raise RuntimeError("Unexpected operation ids response format")
            return response_data.get("response", {})
        except Exception as error:
            raise operation_fetch_error(f"endpoint {self.endpoint} failed to complete request", error) from error

    async def getStageProfilings(
        self, operationIds: list[str], chunkSize: int | None = None
    ) -> ExecutionStagesByOperationId:
        if not operationIds:
            raise empty_array_error("operationIds")
        try:
            response_data = await self._process_chunked_request(
                operationIds,
                lambda chunk: self.http_client.post(
                    self._build_url("stage-profiling"),
                    {"operationIds": chunk},
                    {"transformResponse": [to_camel_case_transformer]},
                ).data,
                chunkSize or self.max_chunk_size,
            )
            if not isinstance(response_data, dict):
                raise RuntimeError("Unexpected stage profilings response format")
            return response_data.get("response", {})
        except Exception as error:
            raise profiling_fetch_error(f"endpoint {self.endpoint} failed to complete request", error) from error

    async def getOperationStatuses(
        self, operationIds: list[str], chunkSize: int | None = None
    ) -> StatusInfosByOperationId:
        if not operationIds:
            raise empty_array_error("operationIds")
        try:
            response_data = await self._process_chunked_request(
                operationIds,
                lambda chunk: self.http_client.post(
                    self._build_url("status"),
                    {"operationIds": chunk},
                    {"transformResponse": [to_camel_case_transformer]},
                ).data,
                chunkSize or self.max_chunk_size,
            )
            if not isinstance(response_data, dict):
                raise RuntimeError("Unexpected operation statuses response format")
            return response_data.get("response", {})
        except Exception as error:
            raise status_fetch_error(f"endpoint {self.endpoint} failed to complete request", error) from error

    async def convertCurrency(self, params: ConvertCurrencyParams) -> ConvertedCurrencyResult:
        try:
            payload = {"currency": params["currency"], "value": str(params["value"])}
            response = self.http_client.post(
                self._build_url("convert_currency"),
                payload,
                {"transformResponse": [to_camel_case_transformer]},
            )
            raw = response.data.get("response", {})
            return {
                "decimals": raw.get("decimals", 0),
                "spotValue": int(raw.get("spotValue", 0)),
                "emaValue": int(raw.get("emaValue", 0)),
                "currency": raw.get("currency"),
                "tacPrice": {
                    "spot": int(raw.get("tacPrice", {}).get("spot", 0)),
                    "ema": int(raw.get("tacPrice", {}).get("ema", 0)),
                    "decimals": raw.get("tacPrice", {}).get("decimals", 0),
                },
                "tonPrice": {
                    "spot": int(raw.get("tonPrice", {}).get("spot", 0)),
                    "ema": int(raw.get("tonPrice", {}).get("ema", 0)),
                    "decimals": raw.get("tonPrice", {}).get("decimals", 0),
                },
            }
        except Exception as error:
            raise convert_currency_fetch_error(f"endpoint {self.endpoint} failed to complete request", error) from error

    async def getTVMExecutorFee(self, params: GetTVMExecutorFeeParams) -> SuggestedTVMExecutorFee:
        try:
            response = self.http_client.post(
                self._build_url("/ton/calculator/ton-executor-fee"),
                params,
                {"transformResponse": [to_camel_case_transformer]},
            )
            data = response.data
            return data.get("response", {})
        except Exception as error:
            raise get_ton_fee_info_fetch_error(f"endpoint {self.endpoint} failed to complete request", error) from error

    async def simulateTACMessage(self, params: TACSimulationParams) -> TACSimulationResult:
        try:
            response = self.http_client.post(
                self._build_url("tac/simulator/simulate-message"),
                params,
                {"transformResponse": [to_camel_case_transformer]},
            )
            return response.data.get("response", {})
        except Exception as error:
            raise simulation_fetch_error(f"endpoint {self.endpoint} failed to complete request", error) from error

    async def _process_chunked_request(
        self,
        items: list[str],
        fn: Callable[[list[str]], Any],
        chunk_size: int,
    ) -> dict[str, Any] | list[Any] | Any:
        chunks = [items[i : i + chunk_size] for i in range(0, len(items), chunk_size)]
        results: list[Any] = []
        for chunk in chunks:
            results.append(fn(chunk))

        if not results:
            return {}

        first = results[0]
        if isinstance(first, list):
            flattened: list[Any] = []
            for result in results:
                if isinstance(result, list):
                    flattened.extend(result)
            return flattened
        if isinstance(first, dict):
            merged_response: dict[str, Any] = {}
            has_nested_response = True
            for result in results:
                if not isinstance(result, dict):
                    continue
                response_data = result.get("response")
                if not isinstance(response_data, dict):
                    has_nested_response = False
                    break
                merged_response.update(response_data)
            if has_nested_response:
                return {"response": merged_response}

            merged: dict[str, Any] = {}
            for result in results:
                if isinstance(result, dict):
                    merged.update(result)
            return merged
        return first


def _get_http_status_code(error: Exception) -> int | None:
    code = getattr(error, "code", None)
    if isinstance(code, int):
        return code
    response = getattr(error, "response", None)
    status_code = getattr(response, "status_code", None)
    if isinstance(status_code, int):
        return status_code
    return None
