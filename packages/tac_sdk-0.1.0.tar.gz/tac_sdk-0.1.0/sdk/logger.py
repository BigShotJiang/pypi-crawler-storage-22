from __future__ import annotations

from interfaces.i_logger import ILogger


class ConsoleLogger(ILogger):
    def debug(self, *arg: object) -> None:
        print("[DEBUG]", *arg)

    def info(self, *arg: object) -> None:
        print("[INFO]", *arg)

    def warn(self, *arg: object) -> None:
        print("[WARN]", *arg)

    def error(self, *arg: object) -> None:
        print("[ERROR]", *arg)


class NoopLogger(ILogger):
    def debug(self, *_arg: object) -> None:
        return None

    def info(self, *_arg: object) -> None:
        return None

    def warn(self, *_arg: object) -> None:
        return None

    def error(self, *_arg: object) -> None:
        return None

console_logger = ConsoleLogger
noop_logger = NoopLogger
