from __future__ import annotations

from errors import all_endpoints_failed_error
from errors.instances import convert_currency_negative_or_zero_value_error
from interfaces.i_lite_sequencer_client import ILiteSequencerClient
from interfaces.i_lite_sequencer_client_factory import ILiteSequencerClientFactory
from interfaces.i_logger import ILogger
from interfaces.i_operation_tracker import IOperationTracker
from sdk.lite_sequencer_client import LiteSequencerClient
from sdk.logger import noop_logger
from sdk.utils import format_object_for_logging, wait_until_success
from sdk.validator import Validator
from structs.struct import (
    ConvertCurrencyParams,
    ConvertedCurrencyResult,
    ExecutionStages,
    ExecutionStagesByOperationId,
    GetTVMExecutorFeeParams,
    Network,
    OperationIdsByShardsKey,
    OperationType,
    SimplifiedStatuses,
    StatusInfo,
    StatusInfosByOperationId,
    SuggestedTVMExecutorFee,
    TACSimulationParams,
    TACSimulationResult,
    TransactionLinker,
    WaitOptions,
)

DEFAULT_LITE_SEQUENCER_ENDPOINTS: dict[Network, list[str]] = {
    Network.MAINNET: ["https://data.tac.build"],
    Network.TESTNET: ["https://data.spb.tac.build"],
}


class DefaultLiteSequencerClientFactory(ILiteSequencerClientFactory):
    def createClients(self, endpoints: list[str]) -> list[ILiteSequencerClient]:
        return [LiteSequencerClient(endpoint) for endpoint in endpoints]


class OperationTracker(IOperationTracker):
    def __init__(
        self,
        network: Network,
        customLiteSequencerEndpoints: list[str] | None = None,
        logger: ILogger | None = None,
        clientFactory: ILiteSequencerClientFactory | None = None,
    ) -> None:
        self.logger = logger or noop_logger()
        factory = clientFactory or DefaultLiteSequencerClientFactory()
        if network == Network.DEV:
            if not customLiteSequencerEndpoints:
                raise ValueError("For DEV network, custom lite sequencer endpoints must be provided")
            endpoints = customLiteSequencerEndpoints
        else:
            if customLiteSequencerEndpoints:
                endpoints = customLiteSequencerEndpoints
            else:
                endpoints = DEFAULT_LITE_SEQUENCER_ENDPOINTS[network]
        self.clients = factory.createClients(endpoints)

    async def getOperationIdByTransactionHash(
        self, transactionHash: str, waitOptions: WaitOptions | None = None
    ) -> str:
        self.logger.debug(f"Getting operation ID for transactionHash: {format_object_for_logging(transactionHash)}")

        async def request_fn() -> str:
            last_error = None
            for client in self.clients:
                try:
                    op_id = await client.getOperationIdByTransactionHash(transactionHash)
                    self.logger.debug(f"Operation ID {op_id if op_id else 'does not exist'}")
                    return op_id
                except Exception as error:
                    self.logger.warn(
                        "Failed to get OperationId by transactionHash using one of the endpoints: "
                        f"{error!r}"
                    )
                    last_error = error
            self.logger.error(
                "All endpoints failed to get operation id by transactionHash. "
                f"Last error: {last_error!r}"
            )
            raise all_endpoints_failed_error(last_error)

        return (
            await wait_until_success(
                waitOptions,
                request_fn,
                "OperationTracker: Getting operation ID by transaction hash",
            )
            if waitOptions
            else await request_fn()
        )

    async def getOperationType(self, operationId: str, waitOptions: WaitOptions | None = None) -> OperationType:
        self.logger.debug(f"Getting operation type for {format_object_for_logging(operationId)}")

        async def request_fn() -> OperationType:
            last_error = None
            for client in self.clients:
                try:
                    result = await client.getOperationType(operationId)
                    self.logger.debug("Operation retrieved successfully")
                    return result
                except Exception as error:
                    self.logger.warn(f"Failed to get operationType using one of the endpoints: {error!r}")
                    last_error = error
            self.logger.error(f"All endpoints failed to get operation type. Last error: {last_error!r}")
            raise all_endpoints_failed_error(last_error)

        return (
            await wait_until_success(waitOptions, request_fn, "OperationTracker: Getting operation type")
            if waitOptions
            else await request_fn()
        )

    async def getOperationId(self, transactionLinker: TransactionLinker, waitOptions: WaitOptions | None = None) -> str:
        self.logger.debug(f"Getting operation ID for transaction linker: {format_object_for_logging(transactionLinker)}")

        async def request_fn() -> str:
            last_error = None
            for client in self.clients:
                try:
                    result = await client.getOperationId(transactionLinker)
                    self.logger.debug(f"Operation ID {result if result else 'does not exist'}")
                    return result
                except Exception as error:
                    self.logger.warn(f"Failed to get OperationId using one of the endpoints: {error!r}")
                    last_error = error
            self.logger.error(f"All endpoints failed to get operation id. Last error: {last_error!r}")
            raise all_endpoints_failed_error(last_error)

        return (
            await wait_until_success(
                waitOptions,
                request_fn,
                "OperationTracker: Getting operation ID by transaction linker",
            )
            if waitOptions
            else await request_fn()
        )

    async def getOperationIdsByShardsKeys(
        self,
        shardsKeys: list[str],
        caller: str,
        waitOptions: WaitOptions | None = None,
        chunkSize: int | None = None,
    ) -> OperationIdsByShardsKey:
        self.logger.debug(f"Getting operation IDs for shards keys: {format_object_for_logging(shardsKeys)}")
        self.logger.debug(f"Caller: {caller}, Chunk size: {chunkSize or 100}")

        async def request_fn() -> OperationIdsByShardsKey:
            last_error = None
            for client in self.clients:
                try:
                    result = await client.getOperationIdsByShardsKeys(shardsKeys, caller, chunkSize or 100)
                    self.logger.debug("Operation IDs by shards keys retrieved successfully")
                    return result
                except Exception as error:
                    self.logger.warn(f"Failed to get operation_ids using one of the endpoints: {error!r}")
                    last_error = error
            self.logger.error(f"All endpoints failed to get operation ids by shards keys. Last error: {last_error!r}")
            raise all_endpoints_failed_error(last_error)

        return (
            await wait_until_success(
                waitOptions,
                request_fn,
                "OperationTracker: Getting operation IDs by shards keys",
            )
            if waitOptions
            else await request_fn()
        )

    async def getStageProfiling(self, operationId: str, waitOptions: WaitOptions | None = None) -> ExecutionStages:
        self.logger.debug(f"Getting stage profiling for operation {operationId}")

        async def request_fn() -> ExecutionStages:
            last_error = None
            for client in self.clients:
                try:
                    result = await client.getStageProfilings([operationId])
                    if not result.get(operationId):
                        raise ValueError(f"No stageProfiling data for operationId={operationId}")
                    self.logger.debug("Stage profiling retrieved successfully")
                    return result[operationId]
                except Exception as error:
                    self.logger.warn(f"Failed to get stage profiling using one of the endpoints: {error!r}")
                    last_error = error
            self.logger.error(f"All endpoints failed to get stage profiling. Last error: {last_error!r}")
            raise all_endpoints_failed_error(last_error)

        return (
            await wait_until_success(waitOptions, request_fn, "OperationTracker: Getting stage profiling")
            if waitOptions
            else await request_fn()
        )

    async def getStageProfilings(
        self,
        operationIds: list[str],
        waitOptions: WaitOptions | None = None,
        chunkSize: int | None = None,
    ) -> ExecutionStagesByOperationId:
        self.logger.debug(f"Getting stage profilings for operations: {', '.join(operationIds)}")
        self.logger.debug(f"Chunk size: {chunkSize or 100}")

        async def request_fn() -> ExecutionStagesByOperationId:
            last_error = None
            for client in self.clients:
                try:
                    result = await client.getStageProfilings(operationIds, chunkSize or 100)
                    self.logger.debug("Stage profilings retrieved successfully")
                    return result
                except Exception as error:
                    self.logger.warn(f"Failed to get stage profilings using one of the endpoints: {error!r}")
                    last_error = error
            self.logger.error(f"All endpoints failed to get stage profilings. Last error: {last_error!r}")
            raise all_endpoints_failed_error(last_error)

        return (
            await wait_until_success(waitOptions, request_fn, "OperationTracker: Getting stage profilings")
            if waitOptions
            else await request_fn()
        )

    async def getOperationStatuses(
        self,
        operationIds: list[str],
        waitOptions: WaitOptions | None = None,
        chunkSize: int | None = None,
    ) -> StatusInfosByOperationId:
        self.logger.debug(f"Getting operation statuses for operations: {format_object_for_logging(operationIds)}")
        self.logger.debug(f"Chunk size: {chunkSize or 100}")

        async def request_fn() -> StatusInfosByOperationId:
            last_error = None
            for client in self.clients:
                try:
                    result = await client.getOperationStatuses(operationIds, chunkSize or 100)
                    self.logger.debug("Statuses retrieved successfully")
                    return result
                except Exception as error:
                    self.logger.warn(f"Failed to get statuses using one of the endpoints: {error!r}")
                    last_error = error
            self.logger.error(f"All endpoints failed to get statuses. Last error: {last_error!r}")
            raise all_endpoints_failed_error(last_error)

        return (
            await wait_until_success(waitOptions, request_fn, "OperationTracker: Getting operation statuses")
            if waitOptions
            else await request_fn()
        )

    async def getOperationStatus(self, operationId: str, waitOptions: WaitOptions | None = None) -> StatusInfo:
        self.logger.debug(f"Getting operation status for {format_object_for_logging(operationId)}")

        async def request_fn() -> StatusInfo:
            last_error = None
            for client in self.clients:
                try:
                    result = await client.getOperationStatuses([operationId])
                    status = result.get(operationId)
                    if status is None:
                        self.logger.warn(f"No operation status for operationId={operationId}")
                        raise ValueError(f"No operation status for operationId={operationId}")
                    return status
                except Exception as error:
                    self.logger.warn(f"Failed to get operation status using one of the endpoints: {error!r}")
                    last_error = error
            self.logger.error(f"All endpoints failed to get operation status. Last error: {last_error!r}")
            raise all_endpoints_failed_error(last_error)

        if waitOptions:
            status = await wait_until_success(waitOptions, request_fn, "OperationTracker: Getting operation status")
            self.logger.debug(
                "operation status resolved "
                f"stage={status.get('stage', 'unknown')} "
                f"success={str(status.get('success')).lower() if isinstance(status.get('success'), bool) else 'unknown'}"
            )
            return status

        status = await request_fn()
        self.logger.debug(
            "operation status resolved "
            f"stage={status.get('stage', 'unknown')} "
            f"success={str(status.get('success')).lower() if isinstance(status.get('success'), bool) else 'unknown'}"
        )
        return status

    async def getSimplifiedOperationStatus(self, transactionLinker: TransactionLinker) -> SimplifiedStatuses:
        self.logger.debug(
            "Getting simplified operation status for transaction linker: "
            f"{format_object_for_logging(transactionLinker)}"
        )
        op_id = await self.getOperationId(transactionLinker)
        if not op_id:
            self.logger.warn("Operation ID not found")
            return SimplifiedStatuses.OPERATION_ID_NOT_FOUND
        op_type = await self.getOperationType(op_id)
        if op_type in (OperationType.PENDING, OperationType.UNKNOWN):
            return SimplifiedStatuses.PENDING
        if op_type == OperationType.ROLLBACK:
            return SimplifiedStatuses.FAILED
        return SimplifiedStatuses.SUCCESSFUL

    async def convertCurrency(
        self, params: ConvertCurrencyParams, waitOptions: WaitOptions | None = None
    ) -> ConvertedCurrencyResult:
        if params["value"] <= 0:
            raise convert_currency_negative_or_zero_value_error
        self.logger.debug(f"Converting currency: {format_object_for_logging(params)}")

        async def request_fn() -> ConvertedCurrencyResult:
            last_error = None
            for client in self.clients:
                try:
                    result = await client.convertCurrency(params)
                    self.logger.debug("Conversion result retrieved successfully")
                    return result
                except Exception as error:
                    self.logger.warn(f"Failed to convert currency using one of the endpoints: {error!r}")
                    last_error = error
            self.logger.error(f"All endpoints failed to convert currency. Last error: {last_error!r}")
            raise all_endpoints_failed_error(last_error)

        return (
            await wait_until_success(waitOptions, request_fn, "OperationTracker: Converting currency")
            if waitOptions
            else await request_fn()
        )

    async def simulateTACMessage(
        self, params: TACSimulationParams, waitOptions: WaitOptions | None = None
    ) -> TACSimulationResult:
        Validator.validate_tac_simulation_params(params)
        self.logger.debug(f"Simulating TAC message: {format_object_for_logging(params)}")

        async def request_fn() -> TACSimulationResult:
            last_error = None
            for client in self.clients:
                try:
                    result = await client.simulateTACMessage(params)
                    self.logger.debug("Simulation result retrieved successfully")
                    return result
                except Exception as error:
                    self.logger.warn(f"Failed to simulate TAC message using one of the endpoints: {error!r}")
                    last_error = error
            self.logger.error(f"All endpoints failed to simulate TAC message. Last error: {last_error!r}")
            raise all_endpoints_failed_error(last_error)

        return (
            await wait_until_success(waitOptions, request_fn, "OperationTracker: Simulating TAC message")
            if waitOptions
            else await request_fn()
        )

    async def getTVMExecutorFee(
        self, params: GetTVMExecutorFeeParams, waitOptions: WaitOptions | None = None
    ) -> SuggestedTVMExecutorFee:
        self.logger.debug(f"get TVM executor fee: {format_object_for_logging(params)}")

        async def request_fn() -> SuggestedTVMExecutorFee:
            last_error = None
            for client in self.clients:
                try:
                    result = await client.getTVMExecutorFee(params)
                    self.logger.debug("Suggested TVM executor fee retrieved successfully")
                    return result
                except Exception as error:
                    self.logger.warn(f"Failed to get TVM executor fee using one of the endpoints: {error!r}")
                    last_error = error
            self.logger.error(f"All endpoints failed to get TVM executor fee. Last error: {last_error!r}")
            raise all_endpoints_failed_error(last_error)

        return (
            await wait_until_success(waitOptions, request_fn, "OperationTracker: Getting TVM executor fee")
            if waitOptions
            else await request_fn()
        )
