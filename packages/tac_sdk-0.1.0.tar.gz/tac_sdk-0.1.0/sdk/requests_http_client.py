from __future__ import annotations

import json
from enum import Enum
from typing import Any
from urllib.parse import urlencode, urlparse, urlunparse

import requests

from interfaces.i_http_client import HttpResponse, IHttpClient


class EnumEncoder(json.JSONEncoder):
    def default(self, o: Any) -> Any:
        if isinstance(o, Enum):
            return o.value
        return super().default(o)


class RequestsHttpClient(IHttpClient):
    def __init__(self, config: dict | None = None):
        self.config = config or {}

    def get(self, url: str, config: dict | None = None) -> HttpResponse[Any]:
        return self._request("GET", url, None, config)

    def post(self, url: str, data: object, config: dict | None = None) -> HttpResponse[Any]:
        return self._request("POST", url, data, config)

    def _request(self, method: str, url: str, data: object | None, config: dict | None) -> HttpResponse[Any]:
        cfg = config or {}
        params = cfg.get("params")
        headers = cfg.get("headers", {})
        transform = cfg.get("transformResponse") or []
        timeout = cfg.get("timeout", self.config.get("timeout", 30))

        final_url = self._apply_params(url, params)
        # Serialize data with custom encoder that handles Enum values
        json_data = json.dumps(data, cls=EnumEncoder) if data is not None else None
        response = requests.request(
            method=method,
            url=final_url,
            data=json_data,
            headers={**headers, "Content-Type": "application/json"} if json_data else headers,
            timeout=timeout,
        )
        response.raise_for_status()

        text = response.text
        parsed: Any = text
        for fn in transform:
            parsed = fn(parsed)
        if not transform:
            try:
                parsed = json.loads(text)
            except Exception:
                parsed = text

        return HttpResponse(status_code=response.status_code, data=parsed, raw=text)

    @staticmethod
    def _apply_params(url: str, params: dict | None) -> str:
        if not params:
            return url
        parsed = urlparse(url)
        query = parsed.query
        new_query = urlencode(params, doseq=True)
        if query:
            new_query = f"{query}&{new_query}"
        return urlunparse(parsed._replace(query=new_query))
