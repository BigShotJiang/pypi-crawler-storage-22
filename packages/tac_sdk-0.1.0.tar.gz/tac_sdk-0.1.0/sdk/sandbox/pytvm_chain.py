from __future__ import annotations

import base64
import re
from dataclasses import dataclass
from typing import Any

from pytoniq_core import Cell, begin_cell
from pytoniq_core.boc.address import Address
from pytoniq_core.tlb.account import (
    Account,
    AccountState,
    AccountStorage,
    ShardAccount,
    StateInit,
    StorageExtraInfo,
    StorageInfo,
    StorageUsed,
)
from pytoniq_core.tlb.block import CurrencyCollection
from pytoniq_core.tlb.transaction import ExternalMsgInfo, MessageAny

from structs.struct import ContractState


@dataclass
class PytvmAccount:
    address: Address
    code: Cell
    data: Cell
    balance: int = 0
    last_trans_lt: int = 0
    last_trans_hash: bytes = b"\x00" * 32


class PytvmChain:
    def __init__(self, verbosity_level: int = 0):
        self.verbosity_level = verbosity_level
        self._accounts: dict[str, pytvm_account] = {}

    def register_account(
        self,
        address: str | Address,
        code: Cell | bytes | str,
        data: Cell | bytes | str | None = None,
        balance: int = 0,
    ) -> None:
        addr = Address(address) if isinstance(address, str) else address
        key = self._normalize_address(addr)
        code_cell = self._cell_from_input(code)
        data_cell = self._cell_from_input(data) if data is not None else begin_cell().end_cell()
        self._accounts[key] = pytvm_account(
            address=addr,
            code=code_cell,
            data=data_cell,
            balance=int(balance),
        )

    def has_account(self, address: str | Address) -> bool:
        addr = Address(address) if isinstance(address, str) else address
        return self._normalize_address(addr) in self._accounts

    def get_contract_state(self, address: str | Address) -> ContractState:
        addr = Address(address) if isinstance(address, str) else address
        account = self._accounts.get(self._normalize_address(addr))
        if account is None:
            return {"balance": 0, "state": "uninitialized", "code": None}
        return {
            "balance": int(account.balance),
            "state": "active",
            "code": account.code.to_boc(),
        }

    def run_get_method(self, address: str | Address, method: str | int, stack: list[Any] | None = None) -> dict[str, Any]:
        account = self._get_account(address)
        from pytvm.tvm_emulator import TvmEmulator

        emulator = TvmEmulator(account.code, account.data, verbosity_level=self.verbosity_level)
        return emulator.run_get_method(method=method, stack=stack or [])

    def emulate_external_message(
        self,
        address: str | Address,
        body: Cell | bytes | str | None = None,
        unixtime: int | None = None,
        max_routed_messages: int = 32,
    ) -> dict[str, Any]:
        account = self._get_account(address)
        message_body = self._cell_from_input(body) if body is not None else begin_cell().end_cell()
        message = MessageAny(ExternalMsgInfo(account.address, account.address, 0), None, message_body)
        return self._emulate_message_with_routing(account.address, message.serialize(), unixtime, max_routed_messages)

    def emulate_message(
        self,
        address: str | Address,
        message: MessageAny | Cell | bytes | str,
        unixtime: int | None = None,
        max_routed_messages: int = 32,
    ) -> dict[str, Any]:
        message_cell = message.serialize() if isinstance(message, MessageAny) else self._cell_from_input(message)
        addr = Address(address) if isinstance(address, str) else address
        return self._emulate_message_with_routing(addr, message_cell, unixtime, max_routed_messages)

    def _emulate_message_with_routing(
        self,
        initial_address: Address,
        initial_message: Cell,
        unixtime: int | None,
        max_routed_messages: int,
    ) -> dict[str, Any]:
        queue: list[tuple[Address, Cell]] = [(initial_address, initial_message)]
        routed = 0
        root_result: dict[str, Any] | None = None

        while queue:
            target, msg_cell = queue.pop(0)
            account = self._get_account(target)
            result = self._emulate_one(account, msg_cell, unixtime)
            if root_result is None:
                root_result = result

            routed += 1
            if routed > max_routed_messages:
                break

            if not result.get("success"):
                continue

            tx = result.get("transaction")
            if tx is None:
                continue
            for out_msg in getattr(tx, "out_msgs", []):
                if not getattr(out_msg, "is_internal", False):
                    continue
                dest = out_msg.info.dest
                if dest is None:
                    continue
                key = self._normalize_address(dest)
                if key not in self._accounts:
                    continue
                queue.append((dest, out_msg.serialize()))

        return root_result or {"success": False, "error": "message queue did not execute"}

    def _emulate_one(self, account: pytvm_account, message_cell: Cell, unixtime: int | None) -> dict[str, Any]:
        from pytvm.transaction_emulator import TransactionEmulator

        emulator = TransactionEmulator(verbosity_level=self.verbosity_level)
        if unixtime is not None:
            emulator.set_unixtime(int(unixtime))
        shard_account_cell = self._build_shard_account_cell(account)
        result = emulator.emulate_transaction(shard_account_cell, message_cell)

        if result.get("success"):
            shard_account = result.get("shard_account")
            if shard_account is not None:
                self._update_account_from_shard(account, shard_account)

        return result

    def _build_shard_account_cell(self, account: pytvm_account) -> Cell:
        storage = AccountStorage(
            last_trans_lt=account.last_trans_lt,
            balance=CurrencyCollection(account.balance),
            state=AccountState(
                "account_active",
                state_init=StateInit(
                    code=account.code,
                    data=account.data,
                ),
            ),
        )
        storage_info = StorageInfo(
            used=StorageUsed(cells=0, bits=0),
            storage_extra=StorageExtraInfo("storage_extra_none"),
            last_paid=0,
            due_payment=None,
        )
        tlb_account = Account(addr=account.address, storage_stat=storage_info, storage=storage)
        shard = ShardAccount(
            account=tlb_account,
            last_trans_hash=account.last_trans_hash,
            last_trans_lt=account.last_trans_lt,
        )
        return shard.serialize()

    def _update_account_from_shard(self, target: pytvm_account, shard_account: Any) -> None:
        account = getattr(shard_account, "account", None)
        if account is None:
            return
        storage = getattr(account, "storage", None)
        if storage is None:
            return

        target.balance = int(getattr(getattr(storage, "balance", None), "grams", target.balance))
        target.last_trans_lt = int(getattr(shard_account, "last_trans_lt", target.last_trans_lt))
        last_hash = getattr(shard_account, "last_trans_hash", None)
        if isinstance(last_hash, (bytes, bytearray)) and len(last_hash) == 32:
            target.last_trans_hash = bytes(last_hash)

        state = getattr(storage, "state", None)
        if state is None:
            return
        if getattr(state, "type_", "") != "account_active":
            return
        state_init = getattr(state, "state_init", None)
        if state_init is None:
            return

        code = getattr(state_init, "code", None)
        data = getattr(state_init, "data", None)
        if isinstance(code, Cell):
            target.code = code
        if isinstance(data, Cell):
            target.data = data

    def _get_account(self, address: str | Address) -> pytvm_account:
        addr = Address(address) if isinstance(address, str) else address
        key = self._normalize_address(addr)
        if key not in self._accounts:
            raise KeyError(f"Account is not registered in pytvm chain: {key}")
        return self._accounts[key]

    @staticmethod
    def _normalize_address(address: Address) -> str:
        return address.to_str(is_user_friendly=True, is_url_safe=True, is_bounceable=True, is_test_only=False)

    @staticmethod
    def _cell_from_input(cell: Cell | bytes | str) -> Cell:
        if isinstance(cell, Cell):
            return cell
        if isinstance(cell, bytes):
            parsed = Cell.one_from_boc(cell)
            return parsed[0] if isinstance(parsed, list) else parsed
        raw = cell.strip()
        if re.fullmatch(r"[0-9a-fA-F]+", raw):
            parsed = Cell.one_from_boc(bytes.fromhex(raw))
            return parsed[0] if isinstance(parsed, list) else parsed
        decoded = base64.b64decode(raw)
        parsed = Cell.one_from_boc(decoded)
        return parsed[0] if isinstance(parsed, list) else parsed

pytvm_account = PytvmAccount
pytvm_chain = PytvmChain
