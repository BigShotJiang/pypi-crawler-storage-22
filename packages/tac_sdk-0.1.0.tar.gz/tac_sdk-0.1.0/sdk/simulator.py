from __future__ import annotations

from typing import Any, cast

from assets import Ton
from errors import unknown_token_type_error
from errors.instances import unknown_asset_origin_error
from interfaces.i_configuration import IConfiguration
from interfaces.i_logger import ILogger
from interfaces.i_operation_tracker import IOperationTracker
from interfaces.i_simulator import ISimulator
from interfaces.sender_abstraction import SenderAbstraction
from sdk.fees import (
    FIXED_POINT_SHIFT,
    create_cross_chain_layer_tvm_msg_to_evm_step,
    create_error_notification_gas_step,
    create_estimated_receive_transfer_gas_step,
    create_estimated_send_transfer_gas_step,
    create_jetton_minter_burn_notification_step,
    create_jetton_proxy_ownership_assigned_step,
    create_jetton_wallet_burn_step,
    create_jetton_wallet_internal_transfer_step,
    create_jetton_wallet_receive_step,
    create_mint_after_error_gas_step,
    create_nft_item_burn_step,
    create_nft_item_error_notification_step,
    create_nft_item_send_step,
    create_nft_proxy_error_notification_step,
    create_nft_proxy_ownership_assigned_step,
)
from sdk.logger import noop_logger
from sdk.utils import (
    aggregate_tokens,
    format_solidity_method_name,
    generate_transaction_linker,
    map_assets_to_ton_assets,
    recurisively_collect_cell_stats,
)
from sdk.validator import Validator
from structs.internal_struct import TONFeeCalculationParams, TransactionFeeCalculationStep
from structs.struct import (
    AssetType,
    CrosschainTx,
    ExecutionFeeEstimationResult,
    FeeParams,
    GeneratePayloadParams,
    Origin,
    TACSimulationParams,
)


class Simulator(ISimulator):
    def __init__(self, config: IConfiguration, operationTracker: IOperationTracker, logger: ILogger | None = None):
        self.config = config
        self.operationTracker = operationTracker
        self.logger = logger or noop_logger()

    async def getSimulationsInfo(self, sender: SenderAbstraction, txs: list[CrosschainTx]) -> list[ExecutionFeeEstimationResult]:
        results: list[ExecutionFeeEstimationResult] = []
        for tx in txs:
            results.append(await self.getSimulationInfo(sender, tx))
        return results

    async def getSimulationInfo(self, sender: SenderAbstraction, tx: CrosschainTx) -> ExecutionFeeEstimationResult:
        self.logger.debug("Getting simulation info")
        evm_proxy_msg = tx.get("evmProxyMsg")
        assets = tx.get("assets") or []
        options = tx.get("options") or {}
        evm_valid_executors = options.get("evmValidExecutors") or self.config.TACParams.get("trustedTACExecutors", [])
        tvm_valid_executors = options.get("tvmValidExecutors") or self.config.TACParams.get("trustedTONExecutors", [])
        calculate_rollback_fee = options.get("calculateRollbackFee", True)
        allow_simulation_error = options.get("allowSimulationError", False)

        if evm_proxy_msg:
            Validator.validate_evm_address(evm_proxy_msg["evmTargetAddress"])
        Validator.validate_evm_addresses(evm_valid_executors)
        Validator.validate_tvm_addresses(tvm_valid_executors)

        aggregated_data = aggregate_tokens(assets)
        shard_count = len(aggregated_data["jettons"]) or 1
        transaction_linker = generate_transaction_linker(sender.getSenderAddress(), shard_count)

        tac_simulation_params: TACSimulationParams = {
            "tacCallParams": {
                "arguments": (evm_proxy_msg.get("encodedParameters") or "0x") if evm_proxy_msg else "0x",
                "methodName": format_solidity_method_name(evm_proxy_msg.get("methodName") if evm_proxy_msg else None),
                "target": (evm_proxy_msg.get("evmTargetAddress") or "") if evm_proxy_msg else "",
            },
            "evmValidExecutors": evm_valid_executors,
            "tvmValidExecutors": tvm_valid_executors,
            "extraData": "0x",
            "shardsKey": transaction_linker["shardsKey"],
            "tonAssets": map_assets_to_ton_assets(assets),
            "tonCaller": transaction_linker["caller"],
            "calculateRollbackFee": calculate_rollback_fee,
        }

        simulation = await self.operationTracker.simulateTACMessage(tac_simulation_params)
        self.logger.debug(f"TAC simulation {'success' if simulation.get('simulationStatus') else 'failed'}")

        is_round_trip = options.get("isRoundTrip")
        if is_round_trip is None:
            is_round_trip = bool(assets) or bool(simulation.get("outMessages"))
        protocol_fee = await self._resolve_protocol_fee(bool(is_round_trip))
        self.logger.debug(f"Resolved TON protocol fee: {protocol_fee} (isRoundTrip={bool(is_round_trip)})")

        fee_params: FeeParams = {
            "isRoundTrip": bool(is_round_trip),
            "gasLimit": int(simulation.get("estimatedGas", 0)) if simulation.get("simulationStatus") else 0,
            "protocolFee": protocol_fee,
            "evmExecutorFee": int(simulation.get("suggestedTacExecutionFee", 0)),
            "tvmExecutorFee": int(simulation.get("suggestedTonExecutionFee", 0)) * (1 if is_round_trip else 0),
        }

        if not simulation.get("simulationStatus") and not allow_simulation_error:
            raise RuntimeError(str(simulation))

        if allow_simulation_error and not simulation.get("simulationStatus"):
            self.logger.info("Simulation failed but allowSimulationError is true, returning partial fee params")

        return {"feeParams": fee_params, "simulation": simulation}

    @staticmethod
    def _ceil_div(value: int, divisor: int) -> int:
        return (value + divisor - 1) // divisor

    def _calculate_ton_fees(self, params: TONFeeCalculationParams) -> int:
        storage_fee = self._ceil_div(
            (params["accountBits"] * params["accountBitPrice"] + params["accountCells"] * params["accountCellPrice"])
            * params["timeDelta"],
            FIXED_POINT_SHIFT,
        )
        # JS computes this with float division and applies Math.ceil to total at the end.
        # Since all other components are integer, this is equivalent to ceil on computeFee.
        compute_fee = self._ceil_div(params["gasUsed"] * params["gasPrice"], FIXED_POINT_SHIFT)
        msg_fwd_fees = params["lumpPrice"] + self._ceil_div(
            params["msgBitPrice"] * params["msgBits"] + params["msgCellPrice"] * params["msgCells"],
            FIXED_POINT_SHIFT,
        )
        ihr_fwd_fees = self._ceil_div(msg_fwd_fees * params["ihrPriceFactor"], FIXED_POINT_SHIFT)
        total_fwd_fees = msg_fwd_fees + ihr_fwd_fees
        action_fee = (msg_fwd_fees * params["firstFrac"]) // FIXED_POINT_SHIFT
        total_fees = storage_fee + compute_fee + action_fee + total_fwd_fees
        return int(total_fees)

    def _calculate_transaction_pipeline(self, steps: list[TransactionFeeCalculationStep]) -> int:
        params = self.config.TONParams.get("feesParams", {})
        total = 0
        for step in steps:
            full: TONFeeCalculationParams = cast(TONFeeCalculationParams, {**step, **params})
            total += self._calculate_ton_fees(full)
        return total

    @staticmethod
    def _extract_stack_int(entry: Any) -> int | None:
        if isinstance(entry, list) and len(entry) >= 2 and entry[0] == "num":
            value = entry[1]
            if isinstance(value, str):
                return int(value, 16) if value.startswith("0x") else int(value)
            if isinstance(value, int):
                return value
            return None
        if isinstance(entry, dict):
            if entry.get("type") in {"int", "num"}:
                value = entry.get("value")
                if isinstance(value, str):
                    return int(value, 16) if value.startswith("0x") else int(value)
                if isinstance(value, int):
                    return value
        return None

    def _extract_protocol_fees(self, stack: list[Any]) -> tuple[int, int] | None:
        numbers: list[int] = []
        for entry in stack:
            parsed = self._extract_stack_int(entry)
            if parsed is not None:
                numbers.append(parsed)
        if len(numbers) < 8:
            return None
        return numbers[6], numbers[7]

    def _read_protocol_fees_from_opener(self, opener: Any, cross_chain_layer_address: str) -> tuple[int, int] | None:
        if hasattr(opener, "_run_get_method"):
            result = opener._run_get_method(cross_chain_layer_address, "get_full_data")
            stack = result.get("stack") or []
            return self._extract_protocol_fees(stack)
        if hasattr(opener, "_run_method_raw"):
            result = opener._run_method_raw(cross_chain_layer_address, "get_full_data")
            stack = result.get("result") or []
            return self._extract_protocol_fees(stack)
        return None

    async def _resolve_protocol_fee(self, is_round_trip: bool) -> int:
        cross_chain_layer_address = self.config.TONParams.get("crossChainLayerAddress")
        if not cross_chain_layer_address:
            raise RuntimeError("crossChainLayerAddress is not configured")
        opener = self.config.TONParams.get("contractOpener")
        if opener is None:
            raise RuntimeError("contractOpener is not configured")

        candidates = []
        opener_configs = getattr(opener, "openerConfigs", None)
        if isinstance(opener_configs, list) and opener_configs:
            candidates = [cfg.opener for cfg in opener_configs if hasattr(cfg, "opener")]
        else:
            candidates = [opener]

        errors: list[str] = []
        for candidate in candidates:
            try:
                protocol_fees = self._read_protocol_fees_from_opener(candidate, cross_chain_layer_address)
                if protocol_fees is None:
                    continue
                tac_protocol_fee, ton_protocol_fee = protocol_fees
                return int(tac_protocol_fee + (ton_protocol_fee if is_round_trip else 0))
            except Exception as exc:
                errors.append(f"{type(candidate).__name__}: {exc}")

        error_text = "; ".join(errors) if errors else "No compatible opener to run get_full_data"
        raise RuntimeError(f"Failed to resolve TON protocol fee: {error_text}")

    async def estimateTONFee(self, asset: Any, params: GeneratePayloadParams) -> int:
        payload = asset.generatePayload(params)
        stats = recurisively_collect_cell_stats(payload)
        msg_bits = stats["bits"]
        msg_cells = stats["cells"]

        contract_fee_usage_params: Any = self.config.TONParams.get("contractFeeUsageParams") or {}
        if not contract_fee_usage_params:
            from sdk.fees import DEFAULT_CONTRACT_FEE_USAGE_PARAMS

            contract_fee_usage_params = DEFAULT_CONTRACT_FEE_USAGE_PARAMS

        if asset.type == AssetType.FT:
            if isinstance(asset, Ton):
                return self._calculate_transaction_pipeline([
                    create_cross_chain_layer_tvm_msg_to_evm_step(contract_fee_usage_params, msg_bits, msg_cells),
                ])
            if asset.origin == Origin.TON:
                return self._calculate_transaction_pipeline([
                    create_jetton_wallet_internal_transfer_step(contract_fee_usage_params, msg_bits, msg_cells),
                    create_jetton_wallet_receive_step(contract_fee_usage_params, msg_bits, msg_cells),
                    create_jetton_proxy_ownership_assigned_step(contract_fee_usage_params, msg_bits, msg_cells),
                    create_cross_chain_layer_tvm_msg_to_evm_step(contract_fee_usage_params, msg_bits, msg_cells),
                    create_error_notification_gas_step(contract_fee_usage_params, msg_bits, msg_cells),
                    create_estimated_send_transfer_gas_step(contract_fee_usage_params, msg_bits, msg_cells),
                    create_estimated_receive_transfer_gas_step(contract_fee_usage_params, msg_bits, msg_cells),
                ])
            if asset.origin == Origin.TAC:
                return self._calculate_transaction_pipeline([
                    create_jetton_wallet_burn_step(contract_fee_usage_params, msg_bits, msg_cells),
                    create_jetton_minter_burn_notification_step(contract_fee_usage_params, msg_bits, msg_cells),
                    create_cross_chain_layer_tvm_msg_to_evm_step(contract_fee_usage_params, msg_bits, msg_cells),
                    create_mint_after_error_gas_step(contract_fee_usage_params, msg_bits, msg_cells),
                    create_jetton_wallet_receive_step(contract_fee_usage_params, msg_bits, msg_cells),
                ])
            raise unknown_asset_origin_error(asset.origin)

        if asset.type == AssetType.NFT:
            if asset.origin == Origin.TON:
                return self._calculate_transaction_pipeline([
                    create_nft_item_send_step(contract_fee_usage_params, msg_bits, msg_cells),
                    create_nft_proxy_ownership_assigned_step(contract_fee_usage_params, msg_bits, msg_cells),
                    create_cross_chain_layer_tvm_msg_to_evm_step(contract_fee_usage_params, msg_bits, msg_cells),
                    create_nft_proxy_error_notification_step(contract_fee_usage_params, msg_bits, msg_cells),
                    create_nft_item_send_step(contract_fee_usage_params, msg_bits, msg_cells),
                ])
            if asset.origin == Origin.TAC:
                return self._calculate_transaction_pipeline([
                    create_nft_item_burn_step(contract_fee_usage_params, msg_bits, msg_cells),
                    create_cross_chain_layer_tvm_msg_to_evm_step(contract_fee_usage_params, msg_bits, msg_cells),
                    create_nft_item_error_notification_step(contract_fee_usage_params),
                ])
            raise unknown_asset_origin_error(asset.origin)

        raise unknown_token_type_error(asset.type)
