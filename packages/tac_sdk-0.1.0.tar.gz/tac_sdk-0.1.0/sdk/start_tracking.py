from __future__ import annotations

from datetime import datetime

from interfaces.contract_opener import ContractOpener
from interfaces.i_logger import ILogger
from interfaces.i_tx_finalizer import ITxFinalizer
from sdk.consts import DEFAULT_FIND_TX_MAX_DEPTH, MAX_ITERATION_COUNT
from sdk.logger import noop_logger
from sdk.operation_tracker import OperationTracker
from sdk.utils import sleep
from structs.struct import ExecutionStages, Network, OperationType, TransactionLinker


async def start_tracking(
    transaction_linker: TransactionLinker,
    network: Network,
    options: dict | None = None,
):
    opts = options or {}
    custom_endpoints = opts.get("customLiteSequencerEndpoints")
    delay = opts.get("delay", 10)
    max_iteration_count = opts.get("maxIterationCount", MAX_ITERATION_COUNT)
    return_value = opts.get("returnValue", False)
    table_view = opts.get("tableView", True)
    logger: ILogger = opts.get("logger") or noop_logger()
    tx_finalizer: ITxFinalizer | None = opts.get("txFinalizer")
    contract_opener: ContractOpener | None = opts.get("contractOpener")
    ccl_address = opts.get("cclAddress")

    tracker = OperationTracker(network, custom_endpoints, logger)

    logger.debug(
        "Start tracking operation\n"
        f"caller: {transaction_linker['caller']}\n"
        f"shardsKey: {transaction_linker['shardsKey']}\n"
        f"shardCount: {transaction_linker['shardCount']}\n"
        f"timestamp: {transaction_linker['timestamp']}"
    )

    operation_id = ""
    current_operation_type = OperationType.UNKNOWN
    iteration = 0
    ok = True
    error_message = ""

    while True:
        iteration += 1
        if iteration >= max_iteration_count:
            ok = False
            error_message = "maximum number of iterations has been exceeded"
            break

        if not operation_id:
            logger.debug("request operationId")
            try:
                operation_id = await tracker.getOperationId(transaction_linker)
            except Exception:
                pass
        else:
            try:
                current_operation_type = await tracker.getOperationType(operation_id)
                if current_operation_type not in (OperationType.PENDING, OperationType.UNKNOWN):
                    break
            except Exception as err:
                logger.debug(f"failed to get operation type: {err}")

            logger.debug(f"operationId: {operation_id}\noperationType: {current_operation_type}\ntime: {datetime.utcnow().isoformat()}")
        await sleep(delay * 1000)

    logger.debug("Tracking finished")
    if not ok:
        if return_value:
            raise RuntimeError(error_message)
        logger.debug(error_message)

    profiling_data = await tracker.getStageProfiling(operation_id)

    executed = profiling_data.get("executedInTON")
    stage_data = executed.get("stageData") if executed else None
    transactions = stage_data.get("transactions") if stage_data else None
    if executed and executed.get("exists") and transactions:
        logger.debug("EXECUTED_IN_ton stage found, verifying transaction success in ton...")
        finalizer = tx_finalizer or contract_opener
        if finalizer and ccl_address:
            for tx in transactions:
                if tx is None:
                    continue
                try:
                    logger.debug(f"Verifying transaction: {tx['hash']}")
                    await finalizer.trackTransactionTree(ccl_address, tx["hash"], {"maxDepth": DEFAULT_FIND_TX_MAX_DEPTH})
                    logger.debug(f"Transaction {tx['hash']} verified successfully in ton")
                except Exception as error:
                    logger.debug(f"Transaction {tx['hash']} failed verification in ton: {error}")
                    if return_value:
                        raise
        else:
            logger.debug("Finalizer, ContractOpener or CCL address is not provided, skipping ton transaction verification")

    if return_value:
        return profiling_data

    logger.debug(profiling_data.get("operationType"))
    logger.debug(profiling_data.get("metaInfo"))
    if table_view:
        print_execution_stages_table(profiling_data, logger)
    else:
        logger.debug(format_execution_stages(profiling_data))


async def start_tracking_multiple(
    transaction_linkers: list[TransactionLinker],
    network: Network,
    options: dict | None = None,
):
    opts = options or {}
    custom_endpoints = opts.get("customLiteSequencerEndpoints")
    delay = opts.get("delay", 10)
    max_iteration_count = opts.get("maxIterationCount", MAX_ITERATION_COUNT)
    return_value = opts.get("returnValue", False)
    table_view = opts.get("tableView", True)
    tx_finalizer = opts.get("txFinalizer")
    contract_opener = opts.get("contractOpener")
    ccl_address = opts.get("cclAddress")
    logger: ILogger = opts.get("logger") or noop_logger()

    logger.debug(f"Start tracking {len(transaction_linkers)} operations")

    results = []
    for linker in transaction_linkers:
        results.append(
            await start_tracking(
                linker,
                network,
                {
                    "customLiteSequencerEndpoints": custom_endpoints,
                    "delay": delay,
                    "maxIterationCount": max_iteration_count,
                    "returnValue": True,
                    "tableView": False,
                    "txFinalizer": tx_finalizer,
                    "contractOpener": contract_opener,
                    "cclAddress": ccl_address,
                    "logger": logger,
                },
            )
        )

    if return_value:
        return results

    for idx, result in enumerate(results):
        logger.debug(f"Results for operation {idx + 1}:")
        if table_view:
            print_execution_stages_table(result, logger)
        else:
            logger.debug(format_execution_stages(result))


def format_execution_stages(stages: ExecutionStages):
    keys = [
        "collectedInTAC",
        "includedInTACConsensus",
        "executedInTAC",
        "collectedInTON",
        "includedInTONConsensus",
        "executedInTON",
    ]
    rows = []
    for stage in keys:
        data = stages.get(stage, {})
        stage_data = data.get("stageData") if data else None
        rows.append(
            {
                "stage": stage,
                "exists": "Yes" if data.get("exists") else "No",
                "success": "Yes" if data.get("exists") and stage_data and stage_data.get("success") else "-",
                "timestamp": datetime.fromtimestamp(stage_data.get("timestamp", 0)).isoformat() if data.get("exists") and stage_data else "-",
                "transactions": " \n".join([t["hash"] for t in stage_data.get("transactions", [])]) if data.get("exists") and stage_data and stage_data.get("transactions") else "-",
                "noteContent": stage_data.get("note", {}).get("content") if data.get("exists") and stage_data and stage_data.get("note") else "-",
                "errorName": stage_data.get("note", {}).get("errorName") if data.get("exists") and stage_data and stage_data.get("note") else "-",
                "internalMsg": stage_data.get("note", {}).get("internalMsg") if data.get("exists") and stage_data and stage_data.get("note") else "-",
                "bytesError": stage_data.get("note", {}).get("internalBytesError") if data.get("exists") and stage_data and stage_data.get("note") else "-",
            }
        )
    return rows


def _fit_to_width(text: str, width: int) -> str:
    first_line = text.split("\n")[0]
    if len(first_line) > width - 2:
        return first_line[: width - 5] + "..."
    return first_line.ljust(width, " ")


def create_simple_table(headers: list[str], rows: list[list[str]], col_widths: list[int]) -> str:
    lines = []
    separator = "+" + "+".join(["-" * w for w in col_widths]) + "+"
    header_row = "|" + "|".join([_fit_to_width(h, col_widths[i]) for i, h in enumerate(headers)]) + "|"
    lines.append(separator)
    lines.append(header_row)
    lines.append(separator)
    for row in rows:
        lines.append("|" + "|".join([_fit_to_width(cell, col_widths[i]) for i, cell in enumerate(row)]) + "|")
    lines.append(separator)
    return "\n" + "\n".join(lines)


def print_execution_stages_table(stages: ExecutionStages, logger: ILogger) -> None:
    headers = [
        "Stage",
        "Exists",
        "Success",
        "Timestamp",
        "Transactions",
        "NoteContent",
        "ErrorName",
        "InternalMsg",
        "BytesError",
    ]
    col_widths = [30, 8, 9, 13, 70, 13, 13, 13, 13]
    table_data = format_execution_stages(stages)
    rows = [
        [
            row["stage"],
            row["exists"],
            row["success"],
            row["timestamp"],
            row["transactions"],
            row["noteContent"],
            row["errorName"],
            row["internalMsg"],
            row["bytesError"],
        ]
        for row in table_data
    ]
    table = create_simple_table(headers, rows, col_widths)
    logger.debug(table)
