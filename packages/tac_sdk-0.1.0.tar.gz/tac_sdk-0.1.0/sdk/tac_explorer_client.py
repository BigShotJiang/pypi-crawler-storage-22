from __future__ import annotations

from errors.instances import gas_price_fetch_error
from interfaces.i_http_client import IHttpClient
from interfaces.i_tac_explorer_client import ITacExplorerClient
from sdk.requests_http_client import RequestsHttpClient
from sdk.utils import to_camel_case_transformer
from structs.internal_struct import TacGasPriceResponse


class TacExplorerClient(ITacExplorerClient):
    def __init__(self, explorer_api_endpoint: str, http_client: IHttpClient | None = None):
        self.explorer_api_endpoint = explorer_api_endpoint
        self.http_client = http_client or RequestsHttpClient()

    async def getTACGasPrice(self) -> TacGasPriceResponse:
        try:
            response = self.http_client.get(
                f"{self.explorer_api_endpoint.rstrip('/')}/stats",
                {"transformResponse": [to_camel_case_transformer]},
            )
            return response.data
        except Exception as error:
            raise gas_price_fetch_error(
                f"endpoint {self.explorer_api_endpoint} failed to complete request",
                error,
            ) from error
