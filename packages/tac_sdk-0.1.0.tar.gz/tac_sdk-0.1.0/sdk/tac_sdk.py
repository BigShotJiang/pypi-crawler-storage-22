from __future__ import annotations

import inspect
from typing import Any, cast

from assets import AssetFactory, Ft, Nft
from interfaces.asset import Asset
from interfaces.contract_opener import ContractOpener
from interfaces.i_configuration import IConfiguration
from interfaces.i_logger import ILogger
from interfaces.i_operation_tracker import IOperationTracker
from interfaces.i_simulator import ISimulator
from interfaces.i_tac_explorer_client import ITacExplorerClient
from interfaces.i_tac_sdk import ITacSDK
from interfaces.itac_transaction_manager import ITACTransactionManager
from interfaces.iton_transaction_manager import ITONTransactionManager
from interfaces.sender_abstraction import SenderAbstraction
from sdk.artifacts_loader import resolve_artifacts
from sdk.configuration import Configuration
from sdk.consts import DEFAULT_DELAY
from sdk.logger import noop_logger
from sdk.operation_tracker import OperationTracker
from sdk.simulator import Simulator
from sdk.tac_explorer_client import TacExplorerClient
from sdk.tac_transaction_manager import TacTransactionManager
from sdk.ton_transaction_manager import TonTransactionManager
from sdk.utils import get_bounced_address, map_assets_to_ton_assets, normalize_assets
from structs.struct import (
    AssetFromFTArg,
    AssetFromNFTCollectionArg,
    AssetFromNFTItemArg,
    AssetLike,
    BatchCrossChainTx,
    BatchCrossChainTxWithAssetLike,
    CrossChainPayloadResult,
    CrossChainTransactionOptions,
    CrossChainTransactionsOptions,
    CrosschainTx,
    EVMAddress,
    EvmProxyMsg,
    ExecutionFeeEstimationResult,
    GetTVMExecutorFeeParams,
    NFTAddressType,
    SDKParams,
    SuggestedTVMExecutorFee,
    TACGasPrice,
    TACSimulationParams,
    TACSimulationResult,
    TransactionLinkerWithOperationId,
    TVMAddress,
    UserWalletBalanceExtended,
    WaitOptions,
)


class TacSdk(ITacSDK):
    def __init__(
        self,
        config: IConfiguration,
        simulator: ISimulator,
        ton_transaction_manager: ITONTransactionManager,
        tac_transaction_manager: ITACTransactionManager,
        operation_tracker: IOperationTracker,
        explorer_client: ITacExplorerClient,
    ) -> None:
        self.config = config
        opener = config.TONParams.get("contractOpener")
        if opener is None:
            raise RuntimeError("TON contract opener is not configured")
        self.contractOpener = opener
        self.simulator = simulator
        self.tonTransactionManager = ton_transaction_manager
        self.tacTransactionManager = tac_transaction_manager
        self.operationTracker = operation_tracker
        self.explorerClient = explorer_client

    @staticmethod
    async def create(sdk_params: SDKParams, logger: ILogger | None = None) -> TacSdk:
        log = logger or noop_logger()
        network = sdk_params.network
        delay = sdk_params.delay if sdk_params.delay is not None else DEFAULT_DELAY
        artifacts_source = getattr(sdk_params, "artifacts", None)
        artifacts = resolve_artifacts(artifacts_source, network)
        if artifacts is None:
            raise RuntimeError("Artifacts are required to create TacSdk in this port")

        config = await Configuration.create(
            network,
            artifacts,
            sdk_params.TONParams,
            sdk_params.TACParams,
            sdk_params.customLiteSequencerEndpoints,
            sdk_params.passLoggerToOpeners,
            delay,
            log,
        )
        tracker = OperationTracker(network, config.liteSequencerEndpoints, log)
        tac_endpoints = getattr(getattr(artifacts, "tac", None), "endpoints", None)
        if isinstance(tac_endpoints, dict):
            nested_explorer_endpoint = tac_endpoints.get("TAC_EXPLORER_API_ENDPOINT")
        else:
            nested_explorer_endpoint = getattr(tac_endpoints, "TAC_EXPLORER_API_ENDPOINT", None)
        explorer_endpoint = getattr(artifacts, "TAC_EXPLORER_API_ENDPOINT", None) or nested_explorer_endpoint
        explorer_client = TacExplorerClient(explorer_endpoint or "")
        simulator_instance = Simulator(config, tracker, log)
        ton_manager = TonTransactionManager(config, simulator_instance, tracker, log)
        tac_manager = TacTransactionManager(config, tracker, log)
        return TacSdk(
            config,
            simulator_instance,
            ton_manager,
            tac_manager,
            tracker,
            explorer_client,
        )

    @property
    def nativeTONAddress(self) -> str:
        return self.config.nativeTONAddress

    async def getSmartAccountAddressForTvmWallet(self, tvmWallet: str, applicationAddress: str) -> str:
        bounced = get_bounced_address(tvmWallet)
        smart_account_factory = self.config.TACParams.get("smartAccountFactory")
        if not smart_account_factory:
            raise RuntimeError("smartAccountFactory not configured")
        return await smart_account_factory.getSmartAccountForApplication(bounced, applicationAddress)

    async def nativeTACAddress(self) -> str:
        return await self.config.nativeTACAddress()

    @property
    def getTrustedTACExecutors(self) -> list[str]:
        return self.config.getTrustedTACExecutors

    @property
    def getTrustedTONExecutors(self) -> list[str]:
        return self.config.getTrustedTONExecutors

    async def getSimulationInfo(
        self,
        evmProxyMsg: EvmProxyMsg,
        sender: SenderAbstraction,
        assets: list[AssetLike] | None = None,
        options: CrossChainTransactionOptions | None = None,
    ) -> ExecutionFeeEstimationResult:
        normalized_assets = await normalize_assets(self.config, assets)
        tx: CrosschainTx = {"evmProxyMsg": evmProxyMsg, "assets": normalized_assets, "options": options}
        return await self.simulator.getSimulationInfo(sender, tx)

    async def getTVMExecutorFeeInfo(
        self, assets: list[AssetLike], feeSymbol: str, tvmValidExecutors: list[str] | None = None
    ) -> SuggestedTVMExecutorFee:
        normalized = await normalize_assets(self.config, assets)
        params: GetTVMExecutorFeeParams = {
            "tonAssets": map_assets_to_ton_assets(normalized),
            "feeSymbol": feeSymbol,
            "tvmValidExecutors": tvmValidExecutors or [],
        }
        return await self.operationTracker.getTVMExecutorFee(params)

    async def sendCrossChainTransaction(
        self,
        evmProxyMsg: EvmProxyMsg,
        sender: SenderAbstraction,
        assets: list[AssetLike] | None = None,
        options: CrossChainTransactionOptions | None = None,
        waitOptions: WaitOptions | None = None,
    ) -> TransactionLinkerWithOperationId:
        merged_options = cast(CrossChainTransactionOptions, cast(object, dict(options or {})))
        if waitOptions is not None:
            merged_options["waitOptions"] = waitOptions
        normalized_assets = await normalize_assets(self.config, assets)
        tx: CrosschainTx = {"evmProxyMsg": evmProxyMsg, "assets": normalized_assets, "options": merged_options}
        return await self.tonTransactionManager.sendCrossChainTransaction(evmProxyMsg, sender, tx)

    async def sendCrossChainTransactions(
        self,
        sender: SenderAbstraction,
        txs: list[BatchCrossChainTxWithAssetLike],
        options: CrossChainTransactionsOptions | None = None,
    ) -> list[TransactionLinkerWithOperationId]:
        normalized_txs: list[BatchCrossChainTx] = []
        for tx in txs:
            normalized_txs.append(
                {
                    "evmProxyMsg": tx["evmProxyMsg"],
                    "options": tx.get("options"),
                    "assets": await normalize_assets(self.config, tx.get("assets")),
                }
            )
        return await self.tonTransactionManager.sendCrossChainTransactions(sender, normalized_txs, options)

    async def bridgeTokensToTON(
        self,
        signer: object,
        value: int,
        tonTarget: str,
        assets: list[AssetLike] | None = None,
        tvmExecutorFee: int | None = None,
        tvmValidExecutors: list[str] | None = None,
    ) -> str:
        normalized = await normalize_assets(self.config, assets)
        return await self.tacTransactionManager.bridgeTokensToTON(
            signer,
            value,
            tonTarget,
            normalized,
            tvmExecutorFee,
            tvmValidExecutors,
        )

    async def isContractDeployedOnTVM(self, address: str) -> bool:
        return await self.config.isContractDeployedOnTVM(address)

    async def getAsset(self, args: AssetFromFTArg | AssetFromNFTCollectionArg | AssetFromNFTItemArg) -> Asset:
        return await AssetFactory.from_(self.config, args)

    async def getFT(self, address: TVMAddress | EVMAddress) -> Ft:
        return await Ft.from_address(self.config, address)

    async def getNFT(self, args: AssetFromNFTCollectionArg | AssetFromNFTItemArg) -> Nft:
        if args.get("addressType") == NFTAddressType.ITEM:
            return await Nft.fromItem(self.config, args["address"])
        return await Nft.fromCollection(self.config, {"collection": args["address"], "index": args.get("index", 0)})

    async def getUserJettonWalletAddress(self, userAddress: str, tokenAddress: str) -> str:
        token = await self.getFT(tokenAddress)
        return await token.getUserWalletAddress(userAddress)

    async def getUserJettonBalance(self, userAddress: str, tokenAddress: str) -> int:
        token = await self.getFT(tokenAddress)
        return await token.getUserBalance(userAddress)

    async def getUserJettonBalanceExtended(self, userAddress: str, tokenAddress: str) -> UserWalletBalanceExtended:
        token = await self.getFT(tokenAddress)
        return await token.getUserBalanceExtended(userAddress)

    async def getJettonData(self, itemAddress: TVMAddress) -> Any:
        token = await self.getFT(itemAddress)
        return await token.getJettonData()

    async def getNFTItemData(self, itemAddress: TVMAddress) -> Any:
        item = await Nft.fromItem(self.config, itemAddress)
        return await item.getItemData()

    async def getEVMTokenAddress(self, tvmTokenAddress: str) -> str:
        token = await self.getFT(tvmTokenAddress)
        return await token.getEVMAddress()

    async def getTVMTokenAddress(self, evmTokenAddress: str) -> str:
        token = await self.getFT(evmTokenAddress)
        return await token.getTVMAddress()

    async def getTVMNFTAddress(self, evmNFTAddress: str, tokenId: int | None = None) -> str:
        index = 0 if tokenId is None else int(tokenId)
        resolved_nft = await Nft.fromCollection(self.config, {"collection": evmNFTAddress, "index": index})
        if tokenId is None:
            return str(resolved_nft.addresses.get("collection", ""))
        return str(resolved_nft.addresses.get("item", ""))

    async def getEVMNFTAddress(self, tvmNFTAddress: str, addressType: NFTAddressType) -> str:
        if addressType == NFTAddressType.ITEM:
            item = await Nft.fromItem(self.config, tvmNFTAddress)
            return await item.getEVMAddress()
        collection = await Nft.fromCollection(self.config, {"collection": tvmNFTAddress, "index": 0})
        return await collection.getEVMAddress()

    def getOperationTracker(self) -> IOperationTracker:
        return self.operationTracker

    def getTacExplorerClient(self) -> ITacExplorerClient:
        return self.explorerClient

    def getTonContractOpener(self) -> ContractOpener:
        if self.contractOpener is None:
            raise RuntimeError("TON contract opener is not configured")
        return self.contractOpener

    async def prepareCrossChainTransactionPayload(
        self,
        evmProxyMsg: EvmProxyMsg,
        senderAddress: str,
        assets: list[AssetLike] | None = None,
        options: CrossChainTransactionOptions | None = None,
    ) -> list[CrossChainPayloadResult]:
        normalized_assets = await normalize_assets(self.config, assets)
        return await self.tonTransactionManager.prepareCrossChainTransactionPayload(
            evmProxyMsg,
            senderAddress,
            normalized_assets,
            options,
        )

    async def getTACGasPrice(self) -> TACGasPrice:
        response = await self.explorerClient.getTACGasPrice()
        prices = response.get("gasPrices", {})
        return {
            "average": float(prices.get("average", 0.0)),
            "fast": float(prices.get("fast", 0.0)),
            "slow": float(prices.get("slow", 0.0)),
        }

    async def simulateTACMessage(self, req: TACSimulationParams) -> TACSimulationResult:
        return await self.operationTracker.simulateTACMessage(req)

    async def simulateTransactions(
        self, sender: SenderAbstraction, txs: list[CrosschainTx]
    ) -> list[ExecutionFeeEstimationResult]:
        return await self.simulator.getSimulationsInfo(sender, txs)

    async def closeConnections(self) -> Any:
        opener = self.config.TONParams.get("contractOpener")
        if opener is None:
            return None
        close_fn = getattr(opener, "closeConnections", None)
        if not callable(close_fn):
            return None
        result = close_fn()
        if inspect.isawaitable(result):
            return await result
        return result
