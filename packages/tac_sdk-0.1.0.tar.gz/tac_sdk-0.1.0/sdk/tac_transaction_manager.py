from __future__ import annotations

import random
from typing import Any, cast

from eth_account import Account
from web3 import Web3

from assets import AssetFactory
from interfaces.asset import Asset
from interfaces.i_configuration import IConfiguration
from interfaces.i_logger import ILogger
from interfaces.i_operation_tracker import IOperationTracker
from interfaces.itac_transaction_manager import ITACTransactionManager
from sdk.artifact_access import artifact_get as _artifact_get
from sdk.artifact_access import nested_get as _nested_get
from sdk.consts import TAC_SYMBOL
from sdk.logger import noop_logger
from sdk.utils import format_object_for_logging, map_assets_to_ton_assets
from sdk.validator import Validator
from structs.struct import AssetFromFTArg, AssetType


class TacTransactionManager(ITACTransactionManager):
    def __init__(self, config: IConfiguration, operationTracker: IOperationTracker, logger: ILogger | None = None):
        self.config = config
        self.operationTracker = operationTracker
        self.logger = logger or noop_logger()

    async def bridgeTokensToTON(
        self,
        signer: object,
        value: int,
        tonTarget: str,
        assets: list[Asset] | None = None,
        tvmExecutorFee: int | None = None,
        tvmValidExecutors: list[str] | None = None,
    ) -> str:
        Validator.validate_tvm_address(tonTarget)
        assets = assets or []

        web3 = self._get_web3()
        signer_address, private_key = self._resolve_signer(signer)
        cross_chain_layer_contract = self._get_cross_chain_layer_contract()
        cross_chain_layer_address = self._get_cross_chain_layer_address(cross_chain_layer_contract)

        tvm_executor_fee = tvmExecutorFee
        if tvm_executor_fee is None:
            fee_assets = list(assets)
            if value > 0:
                ft_arg: AssetFromFTArg = {
                    "address": await self.config.nativeTACAddress(),
                    "tokenType": AssetType.FT,
                }
                native_tac_asset = await AssetFactory.from_(
                    self.config,
                    ft_arg,
                )
                fee_assets.append(native_tac_asset.withRawAmount(int(value)))

            ton_assets = map_assets_to_ton_assets(fee_assets)
            suggested_fee = await self.operationTracker.getTVMExecutorFee(
                {
                    "tonAssets": ton_assets,
                    "feeSymbol": TAC_SYMBOL,
                    "tvmValidExecutors": tvmValidExecutors or [],
                }
            )
            tvm_executor_fee = int(suggested_fee["inTAC"])
            self.logger.debug(f"Suggested TAC executor fee: {format_object_for_logging(suggested_fee)}")

        for asset_item in assets:
            await self._approve_asset(asset_item, signer_address, private_key, cross_chain_layer_address)

        protocol_fee = int(cross_chain_layer_contract.functions.getProtocolFee().call())
        shards_key = random.SystemRandom().randrange(1, 10**18)

        to_bridge: list[dict[str, Any]] = []
        to_bridge_nft: list[dict[str, Any]] = []
        for asset_item in assets:
            evm_address = Web3.to_checksum_address(await asset_item.getEVMAddress())
            if asset_item.type == AssetType.FT:
                to_bridge.append({"evmAddress": evm_address, "amount": int(asset_item.rawAmount)})
            elif asset_item.type == AssetType.NFT:
                token_id = self._extract_nft_token_id(asset_item)
                to_bridge_nft.append({"evmAddress": evm_address, "tokenId": token_id, "amount": 1})

        out_message = {
            "shardsKey": int(shards_key),
            "tvmTarget": tonTarget,
            "tvmPayload": "",
            "tvmProtocolFee": int(protocol_fee),
            "tvmExecutorFee": int(tvm_executor_fee or 0),
            "tvmValidExecutors": list(self.config.getTrustedTONExecutors),
            "toBridge": to_bridge,
            "toBridgeNFT": to_bridge_nft,
        }
        encoded_message = self._encode_out_message(out_message)
        total_value = int(value) + int(protocol_fee) + int(tvm_executor_fee or 0)
        self.logger.debug(f"Sending TAC->ton message with total value: {total_value}")

        tx_hash = self._send_contract_transaction(
            web3,
            cross_chain_layer_contract.functions.sendMessage(1, encoded_message),
            signer_address,
            private_key,
            value=total_value,
        )
        self.logger.debug(f"TAC bridge transaction hash: {tx_hash}")
        return tx_hash

    async def _approve_asset(
        self,
        asset: Asset,
        signer_address: str,
        private_key: str,
        spender_address: str,
    ) -> None:
        if asset.type not in (AssetType.FT, AssetType.NFT):
            return

        web3 = self._get_web3()
        evm_address = Web3.to_checksum_address(await asset.getEVMAddress())
        spender = Web3.to_checksum_address(spender_address)

        if asset.type == AssetType.FT:
            abi = self._get_tac_abi("IERC20WithDecimals", "CrossChainLayerERC20", "IERC20")
            token_contract = web3.eth.contract(address=evm_address, abi=abi)
            tx_hash = self._send_contract_transaction(
                web3,
                token_contract.functions.approve(spender, int(asset.rawAmount)),
                signer_address,
                private_key,
                value=0,
            )
            self.logger.debug(f"Approved ft {evm_address} for {spender}: {tx_hash}")
            return

        abi = self._get_tac_abi("IERC721", "CrossChainLayerERC721")
        token_id = self._extract_nft_token_id(asset)
        nft_contract = web3.eth.contract(address=evm_address, abi=abi)
        tx_hash = self._send_contract_transaction(
            web3,
            nft_contract.functions.approve(spender, token_id),
            signer_address,
            private_key,
            value=0,
        )
        self.logger.debug(f"Approved nft {evm_address}#{token_id} for {spender}: {tx_hash}")

    def _get_web3(self) -> Web3:
        provider = self.config.TACParams.get("provider")
        if provider is None or not hasattr(provider, "eth"):
            raise ValueError("TAC provider is not configured")
        return provider

    def _get_cross_chain_layer_contract(self) -> Any:
        adapter = self.config.TACParams.get("crossChainLayer")
        contract = getattr(adapter, "contract", None)
        if contract is None:
            raise ValueError("CrossChainLayer contract is not configured")
        return contract

    def _get_cross_chain_layer_address(self, contract: Any) -> str:
        address = getattr(contract, "address", None)
        if not address:
            raise ValueError("CrossChainLayer contract address is not available")
        return str(address)

    def _resolve_signer(self, signer: object) -> tuple[str, str]:
        if isinstance(signer, str):
            account = Account.from_key(signer)
            return Web3.to_checksum_address(account.address), self._normalize_private_key(signer)

        address = getattr(signer, "address", None)
        private_key = (
            getattr(signer, "key", None)
            or getattr(signer, "privateKey", None)
            or getattr(signer, "_private_key", None)
        )
        if not address:
            raise ValueError("Signer must expose address")
        if private_key is None:
            raise ValueError("Signer must expose key/privateKey for local signing")
        return Web3.to_checksum_address(address), self._normalize_private_key(private_key)

    def _normalize_private_key(self, private_key: Any) -> str:
        if isinstance(private_key, bytes):
            return "0x" + private_key.hex()
        if hasattr(private_key, "hex") and callable(private_key.hex):
            hex_value = str(private_key.hex())
            return hex_value if str(hex_value).startswith("0x") else f"0x{hex_value}"
        key = str(private_key)
        return key if key.startswith("0x") else f"0x{key}"

    def _get_tac_abi(self, *name_candidates: str) -> list[dict[str, Any]]:
        compilation_artifacts = _artifact_get(
            self.config.artifacts,
            ("tac", "compilationArtifacts"),
            ("compilationArtifacts",),
            default={},
        )
        for name in name_candidates:
            abi = _nested_get(compilation_artifacts, name, "abi")
            if isinstance(abi, list):
                return abi
        if any(name in name_candidates for name in ("IERC20WithDecimals", "CrossChainLayerERC20", "IERC20")):
            return [
                {
                    "type": "function",
                    "name": "approve",
                    "stateMutability": "nonpayable",
                    "inputs": [
                        {"name": "spender", "type": "address"},
                        {"name": "value", "type": "uint256"},
                    ],
                    "outputs": [{"name": "", "type": "bool"}],
                }
            ]
        if any(name in name_candidates for name in ("IERC721", "CrossChainLayerERC721")):
            return [
                {
                    "type": "function",
                    "name": "approve",
                    "stateMutability": "nonpayable",
                    "inputs": [
                        {"name": "to", "type": "address"},
                        {"name": "tokenId", "type": "uint256"},
                    ],
                    "outputs": [],
                }
            ]
        raise ValueError(f"TAC ABI not found for: {', '.join(name_candidates)}")

    def _encode_out_message(self, out_message: dict[str, Any]) -> bytes:
        web3 = self._get_web3()
        structs_abi = self._get_tac_abi("IStructsInterface", "IstructsInterface")
        structs_contract = web3.eth.contract(abi=structs_abi)

        encoded_call = None
        contract_any = cast(Any, structs_contract)
        if hasattr(contract_any, "encode_abi"):
            encoded_call = contract_any.encode_abi("__OutMessageV1", args=[out_message])
        elif hasattr(contract_any, "encodeABI"):
            encoded_call = contract_any.encodeABI(fn_name="__OutMessageV1", args=[out_message])
        else:
            encoded_call = structs_contract.get_function_by_name("__OutMessageV1")(out_message)._encode_transaction_data()

        if not isinstance(encoded_call, str) or not encoded_call.startswith("0x") or len(encoded_call) < 10:
            raise ValueError("Failed to ABI-encode OutMessageV1")

        # Remove 4-byte selector, keep encoded struct bytes only.
        return bytes.fromhex(encoded_call[10:])

    def _send_contract_transaction(
        self,
        web3: Web3,
        fn_call: Any,
        signer_address: str,
        private_key: str,
        value: int = 0,
    ) -> str:
        eth = cast(Any, web3.eth)
        nonce = eth.get_transaction_count(signer_address, "pending")
        tx_params: dict[str, Any] = {
            "from": signer_address,
            "nonce": nonce,
            "value": int(value),
            "chainId": eth.chain_id,
        }
        try:
            tx_params["gasPrice"] = int(eth.gas_price)
        except Exception:
            pass
        try:
            estimate = int(fn_call.estimate_gas({"from": signer_address, "value": int(value)}))
            tx_params["gas"] = max(int(estimate * 1.2), estimate + 50_000)
        except Exception:
            tx_params["gas"] = 2_500_000

        tx = fn_call.build_transaction(tx_params)
        try:
            balance = int(eth.get_balance(signer_address, "latest"))
            gas_price = int(tx.get("gasPrice") or tx.get("maxFeePerGas") or 0)
            gas_limit = int(tx.get("gas") or 0)
            required_balance = int(tx.get("value") or 0) + gas_limit * gas_price
            if required_balance > 0 and balance < required_balance:
                raise RuntimeError(
                    "Insufficient EVM balance "
                    f"(address={signer_address}, current={balance}, required={required_balance})"
                )
        except RuntimeError:
            raise
        except Exception:
            pass

        signed = eth.account.sign_transaction(tx, private_key=private_key)
        tx_hash = eth.send_raw_transaction(signed.raw_transaction)
        receipt = eth.wait_for_transaction_receipt(tx_hash, timeout=300)
        if int(getattr(receipt, "status", 0)) != 1:
            raise RuntimeError(f"EVM transaction failed: {tx_hash.hex()}")
        return tx_hash.hex()

    def _extract_nft_token_id(self, asset: Asset) -> int:
        addresses = getattr(asset, "addresses", None)
        if isinstance(addresses, dict) and "index" in addresses:
            return int(addresses["index"])
        token_id = getattr(asset, "tokenId", None)
        if token_id is not None:
            return int(token_id)
        raise ValueError("nft asset does not expose token id")
