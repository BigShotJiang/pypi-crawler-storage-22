from __future__ import annotations

import asyncio
import base64
import time
from dataclasses import asdict
from typing import Any, cast

from pytoniq_core.boc.cell import Cell
from pytoniq_core.tlb.transaction import MessageAny

from assets import Ft, Nft, Ton
from errors.instances import (
    missing_fee_params_error,
    missing_gas_limit_error,
    missing_tvm_executor_fee_error,
    send_cross_chain_transaction_failed_error,
)
from interfaces.asset import Asset
from interfaces.i_configuration import IConfiguration
from interfaces.i_logger import ILogger
from interfaces.i_operation_tracker import IOperationTracker
from interfaces.i_simulator import ISimulator
from interfaces.iton_transaction_manager import ITONTransactionManager
from interfaces.sender_abstraction import SenderAbstraction
from sdk.consts import (
    DEFAULT_FIND_TX_MAX_DEPTH,
    FIFTEEN_MINUTES,
    JETTON_TRANSFER_FORWARD_TON_AMOUNT,
    NFT_TRANSFER_FORWARD_TON_AMOUNT,
)
from sdk.logger import noop_logger
from sdk.utils import (
    aggregate_tokens,
    build_evm_data_cell,
    format_object_for_logging,
    generate_transaction_linker,
    get_normalized_ext_message_hash,
)
from sdk.validator import Validator
from sender import get_mock_sender
from structs.internal_struct import ShardMessage, ShardMessageExtra
from structs.struct import (
    BatchCrossChainTx,
    CrossChainPayloadResult,
    CrossChainTransactionOptions,
    CrossChainTransactionsOptions,
    CrosschainTx,
    EvmProxyMsg,
    FeeParams,
    OperationIdsByShardsKey,
    TransactionLinker,
    TransactionLinkerWithOperationId,
    ValidExecutors,
    WaitOptions,
)


class TonTransactionManager(ITONTransactionManager):
    def __init__(self, config: IConfiguration, simulator: ISimulator, operationTracker: IOperationTracker, logger: ILogger | None = None):
        self.config = config
        self.simulator = simulator
        self.operationTracker = operationTracker
        self.logger = logger or noop_logger()

    async def sendCrossChainTransaction(
        self,
        evmProxyMsg: EvmProxyMsg,
        sender: SenderAbstraction,
        tx: CrosschainTx,
    ) -> TransactionLinkerWithOperationId:
        prepared = await self._prepareCrossChainTransaction(
            evmProxyMsg,
            sender,
            tx.get("assets") or [],
            tx.get("options") or {},
        )

        await Ton.checkBalance(sender, self.config, [prepared["transaction"]])
        self.logger.debug(f"Sending transaction: {format_object_for_logging(prepared['transactionLinker'])}")

        send_result = await sender.sendShardTransaction(
            prepared["transaction"],
            self.config.network,
            self.config.TONParams.get("contractOpener"),
        )

        self.logger.debug(f"Send result: success={send_result.success}, error={send_result.error}")

        if not send_result.success or send_result.error:
            raise send_cross_chain_transaction_failed_error(str(send_result.error) if send_result.error else "Transaction failed")

        should_wait = (tx.get("options") or {}).get("waitOperationId", True)
        if not should_wait:
            prepared["transactionLinker"]["sendTransactionResult"] = send_result
            return prepared["transactionLinker"]

        wait_options_obj = (tx.get("options") or {}).get("waitOptions") or WaitOptions[str, Any](ensureTxExecuted=True)
        if not isinstance(wait_options_obj, WaitOptions):
            # Convert dict to WaitOptions object
            wait_options_obj = WaitOptions[str, Any](**wait_options_obj)
        ensure_tx_executed = (
            bool(wait_options_obj.ensureTxExecuted)
            if wait_options_obj.ensureTxExecuted is not None
            else True
        )
        wait_options_obj.ensureTxExecuted = ensure_tx_executed

        if ensure_tx_executed and send_result.boc:
            msg_cell = Cell.one_from_boc(base64.b64decode(send_result.boc))
            if isinstance(msg_cell, list):
                msg_cell = msg_cell[0]
            message = MessageAny.deserialize(msg_cell.begin_parse())
            hash_b64 = get_normalized_ext_message_hash(message)
            self.logger.info(f"Tracking transaction tree for hash: {hash_b64}")
            opener = self.config.TONParams.get("contractOpener")
            if opener is None:
                raise RuntimeError("contractOpener is required")
            await opener.trackTransactionTree(sender.getSenderAddress(), hash_b64, {"maxDepth": DEFAULT_FIND_TX_MAX_DEPTH})
            self.logger.info("Transaction tree successful")
        elif ensure_tx_executed:
            self.logger.debug(
                "Skipping transaction tree tracking because sender result has no BoC"
            )
        else:
            self.logger.debug(
                "Skipping transaction tree tracking because ensureTxExecuted is false"
            )

        # Set default successCheck and logger if not provided
        if not wait_options_obj.successCheck:
            wait_options_obj.successCheck = lambda op_id, _: bool(op_id)
        if not wait_options_obj.logger:
            wait_options_obj.logger = self.logger

        operation_id = None
        try:
            operation_id = await self.operationTracker.getOperationId(prepared["transactionLinker"], wait_options_obj)
        except Exception as exc:
            self.logger.error(f"Error while waiting for operation ID: {exc}")

        prepared["transactionLinker"]["sendTransactionResult"] = send_result
        if operation_id:
            prepared["transactionLinker"]["operationId"] = operation_id
        return prepared["transactionLinker"]

    async def sendCrossChainTransactions(
        self,
        sender: SenderAbstraction,
        txs: list[BatchCrossChainTx],
        options: CrossChainTransactionsOptions | None = None,
    ) -> list[TransactionLinkerWithOperationId]:
        caller = sender.getSenderAddress()
        self.logger.debug(f"Preparing {len(txs)} cross-chain transactions for {caller}")

        prepared = await self._prepareBatchTransactions(txs, sender)

        await Ton.checkBalance(sender, self.config, prepared["transactions"])
        self.logger.debug(f"Sending transactions: {format_object_for_logging(prepared['transactionLinkers'])}")

        results = await sender.sendShardTransactions(
            prepared["transactions"],
            self.config.network,
            self.config.TONParams.get("contractOpener"),
        )

        for result in results:
            if not result.success or result.error:
                raise send_cross_chain_transaction_failed_error(str(result.error) if result.error else "Transaction failed")

        should_wait = options.get("waitOperationIds", True) if options else True
        wait_options_value = (options or {}).get("waitOptions")
        return (
            await self._waitForOperationIds(prepared["transactionLinkers"], caller, wait_options_value)
            if should_wait
            else prepared["transactionLinkers"]
        )

    async def buildFeeParams(
        self,
        options: CrossChainTransactionOptions,
        evmProxyMsg: EvmProxyMsg,
        sender: SenderAbstraction,
        tx: CrosschainTx,
    ) -> FeeParams:
        without_sim = options.get("withoutSimulation")
        protocol_fee = options.get("protocolFee")
        evm_fee = options.get("evmExecutorFee")
        tvm_fee = options.get("tvmExecutorFee")
        is_round_trip = options.get("isRoundTrip")

        if without_sim:
            if protocol_fee is None or evm_fee is None:
                raise missing_fee_params_error
            if is_round_trip and tvm_fee is None:
                raise missing_tvm_executor_fee_error
            if not evmProxyMsg.get("gasLimit"):
                raise missing_gas_limit_error
            return {
                "protocolFee": int(protocol_fee),
                "evmExecutorFee": int(evm_fee),
                "tvmExecutorFee": int(tvm_fee or 0),
                "gasLimit": int(evmProxyMsg.get("gasLimit") or 0),
                "isRoundTrip": bool(is_round_trip or False),
            }

        simulation_result = await self.simulator.getSimulationInfo(sender, tx)
        fee_params_sim = simulation_result["feeParams"]
        gas_limit_sim = int(fee_params_sim.get("gasLimit", 0))
        protocol_fee_sim = int(fee_params_sim.get("protocolFee", 0))
        evm_executor_fee_sim = int(fee_params_sim.get("evmExecutorFee", 0))
        tvm_executor_fee_sim = int(fee_params_sim.get("tvmExecutorFee", 0))
        round_trip_sim = bool(fee_params_sim.get("isRoundTrip", False))
        if not evmProxyMsg.get("gasLimit"):
            evmProxyMsg["gasLimit"] = gas_limit_sim

        resolved_tvm_executor_fee = (
            int(tvm_fee)
            if round_trip_sim and tvm_fee is not None
            else tvm_executor_fee_sim
        )

        return {
            "protocolFee": int(protocol_fee) if protocol_fee is not None else protocol_fee_sim,
            "evmExecutorFee": int(evm_fee) if evm_fee is not None else evm_executor_fee_sim,
            "tvmExecutorFee": resolved_tvm_executor_fee,
            "gasLimit": int(evmProxyMsg.get("gasLimit") or gas_limit_sim),
            "isRoundTrip": bool(is_round_trip if is_round_trip is not None else round_trip_sim),
            "evmEstimatedGas": cast(Any, simulation_result.get("simulation")).get("estimatedGas") if simulation_result.get("simulation") else None,
        }

    async def prepareCrossChainTransactionPayload(
        self,
        evmProxyMsg: EvmProxyMsg,
        senderAddress: str,
        assets: list[Asset],
        options: CrossChainTransactionOptions | None = None,
    ) -> list[CrossChainPayloadResult]:
        mock_sender = get_mock_sender(senderAddress)
        prepared = await self._prepareCrossChainTransaction(evmProxyMsg, mock_sender, assets, options, True)

        return [
            {
                "body": msg["payload"],
                "destinationAddress": msg["address"],
                "tonAmount": msg["value"],
                "tonNetworkFee": msg["extra"]["tonNetworkFee"],
                "tacEstimatedGas": msg["extra"].get("tacEstimatedGas"),
                "transactionLinker": prepared["transactionLinker"],
            }
            for msg in prepared["transaction"]["messages"]
        ]

    async def _prepareCrossChainTransaction(
        self,
        evmProxyMsg: EvmProxyMsg,
        sender: SenderAbstraction,
        assets: list[Asset] | None = None,
        options: CrossChainTransactionOptions | None = None,
        skip_assets_balance_validation: bool = False,
    ) -> dict:
        self.logger.debug("Preparing cross-chain transaction")
        caller = sender.getSenderAddress()
        opts = options or {}
        evm_valid = opts.get("evmValidExecutors") or []
        tvm_valid = opts.get("tvmValidExecutors") or []

        allow_sim_error = opts.get("allowSimulationError", False)
        is_round_trip = opts.get("isRoundTrip")
        calculate_rollback_fee = opts.get("calculateRollbackFee", True)
        validate_assets_balance = opts.get("validateAssetsBalance", True)
        evm_data_builder = opts.get("evmDataBuilder") or build_evm_data_cell

        Validator.validate_evm_address(evmProxyMsg["evmTargetAddress"])
        aggregated = aggregate_tokens(assets or [])

        Validator.validate_evm_addresses(evm_valid)
        Validator.validate_tvm_addresses(tvm_valid)

        should_validate = validate_assets_balance and not skip_assets_balance_validation
        if should_validate:
            checks = []
            checks += [jetton.checkCanBeTransferredBy(caller) for jetton in aggregated["jettons"]]
            checks += [nft.checkCanBeTransferredBy(caller) for nft in aggregated["nfts"]]
            if aggregated.get("ton"):
                checks.append(aggregated["ton"].checkCanBeTransferredBy(caller))
            await asyncio.gather(*[c for c in checks if c])

        tokens_len = len(aggregated["jettons"]) + len(aggregated["nfts"])
        transaction_linker = generate_transaction_linker(caller, tokens_len or 1)
        self.logger.debug(f"Generated transaction linker: {format_object_for_logging(transaction_linker)}")

        tac_executors = evm_valid or self.config.getTrustedTACExecutors
        ton_executors = tvm_valid or self.config.getTrustedTONExecutors

        tx_options: CrossChainTransactionOptions = {
            "allowSimulationError": allow_sim_error,
            "evmValidExecutors": tac_executors,
            "tvmValidExecutors": ton_executors,
            "calculateRollbackFee": calculate_rollback_fee,
        }
        if is_round_trip is not None:
            tx_options["isRoundTrip"] = is_round_trip
        tx: CrosschainTx = {
            "evmProxyMsg": evmProxyMsg,
            "assets": assets or [],
            "options": tx_options,
        }

        fee_params = await self.buildFeeParams(opts, evmProxyMsg, sender, tx)
        self.logger.debug(f"Resulting fee params: {format_object_for_logging(fee_params)}")

        valid_executors: ValidExecutors = {"tac": tac_executors, "ton": ton_executors}
        evm_data = evm_data_builder(transaction_linker, evmProxyMsg, valid_executors)
        messages = await self._generateCrossChainMessages(caller, evm_data, aggregated, fee_params)

        return {
            "transaction": {"validUntil": int(time.time() * 1000) + FIFTEEN_MINUTES, "messages": messages, "network": self.config.network},
            "transactionLinker": transaction_linker,
        }

    async def _generateCrossChainMessages(
        self,
        caller: str,
        evm_data: Cell,
        aggregated: dict,
        fee_params: FeeParams,
    ) -> list[ShardMessage]:
        self.logger.debug("Generating cross-chain messages")
        jettons: list[Ft] = aggregated["jettons"]
        nfts: list[Nft] = aggregated["nfts"]
        native_ton_asset: Ton = aggregated.get("ton") or Ton.create(self.config)

        total_assets = list(jettons) + list(nfts)
        cross_chain_ton_amount = native_ton_asset.rawAmount
        fee_ton_amount = int(fee_params.get("protocolFee", 0)) + int(fee_params.get("evmExecutorFee", 0)) + int(fee_params.get("tvmExecutorFee", 0))

        if not total_assets:
            ton_network_fee = await self.simulator.estimateTONFee(
                native_ton_asset,
                {"excessReceiver": caller, "evmData": evm_data, "feeParams": fee_params},
            )
            cross_chain_layer_address = self.config.TONParams.get("crossChainLayerAddress")
            if not cross_chain_layer_address:
                raise RuntimeError("crossChainLayerAddress is not configured")
            extra: ShardMessageExtra = {"tonNetworkFee": ton_network_fee}
            evm_estimated_gas = fee_params.get("evmEstimatedGas")
            if evm_estimated_gas is not None:
                extra["tacEstimatedGas"] = int(evm_estimated_gas)
            return [
                {
                    "address": cross_chain_layer_address,
                    "value": cross_chain_ton_amount + fee_ton_amount + ton_network_fee,
                    "payload": native_ton_asset.generatePayload({"excessReceiver": caller, "evmData": evm_data, "feeParams": fee_params}),
                    "extra": extra,
                }
            ]

        messages: list[ShardMessage] = []
        current_fee_params = fee_params

        for asset_item in total_assets:
            params = {
                "excessReceiver": caller,
                "evmData": evm_data,
                "crossChainTonAmount": cross_chain_ton_amount,
                "forwardFeeTonAmount": fee_ton_amount,
                "feeParams": current_fee_params,
            }
            payload = asset_item.generatePayload(params)
            address = await asset_item.getUserWalletAddress(caller) if isinstance(asset_item, Ft) else asset_item.address
            forward_amount = (
                JETTON_TRANSFER_FORWARD_TON_AMOUNT
                if isinstance(asset_item, Ft)
                else NFT_TRANSFER_FORWARD_TON_AMOUNT
            )
            ton_network_fee = await self.simulator.estimateTONFee(asset_item, cast(Any, params))
            extra: ShardMessageExtra = {"tonNetworkFee": ton_network_fee}
            if current_fee_params:
                evm_estimated_gas = current_fee_params.get("evmEstimatedGas")
                if evm_estimated_gas is not None:
                    extra["tacEstimatedGas"] = int(evm_estimated_gas)

            messages.append(
                {
                    "address": address,
                    "value": cross_chain_ton_amount + fee_ton_amount + ton_network_fee + forward_amount,
                    "payload": payload,
                    "extra": extra,
                }
            )

            cross_chain_ton_amount = 0
            fee_ton_amount = 0
            current_fee_params = None

        self.logger.debug("Cross-chain messages generated successfully")
        return messages

    async def _prepareBatchTransactions(self, txs: list[BatchCrossChainTx], sender: SenderAbstraction) -> dict:
        caller = sender.getSenderAddress()

        txs_requiring_validation = [
            tx for tx in txs if (tx.get("options") or {}).get("validateAssetsBalance", True)
        ]
        if txs_requiring_validation:
            assets_to_validate = []
            for tx in txs_requiring_validation:
                assets_to_validate.extend(tx.get("assets") or [])
            aggregated = aggregate_tokens(assets_to_validate)
            checks = []
            checks += [jetton.checkCanBeTransferredBy(caller) for jetton in aggregated["jettons"]]
            checks += [nft.checkCanBeTransferredBy(caller) for nft in aggregated["nfts"]]
            if aggregated.get("ton"):
                checks.append(aggregated["ton"].checkCanBeTransferredBy(caller))
            await asyncio.gather(*[c for c in checks if c])

        results = await asyncio.gather(
            *[
                self._prepareCrossChainTransaction(tx["evmProxyMsg"], sender, tx.get("assets") or [], tx.get("options") or {}, True)
                for tx in txs
            ]
        )

        return {
            "transactions": [r["transaction"] for r in results],
            "transactionLinkers": [r["transactionLinker"] for r in results],
        }

    async def _waitForOperationIds(
        self,
        transaction_linkers: list[TransactionLinker],
        caller: str,
        wait_options_input: WaitOptions[OperationIdsByShardsKey, Any] | dict[str, Any] | None,
    ) -> list[TransactionLinkerWithOperationId]:
        self.logger.debug("Waiting for operation IDs")
        try:
            if isinstance(wait_options_input, WaitOptions):
                wait_options_dict = asdict(wait_options_input)
            else:
                wait_options_dict = dict(wait_options_input or {})
            if "successCheck" not in wait_options_dict:
                wait_options_dict["successCheck"] = (
                    lambda operation_ids, _: len(operation_ids) == len(transaction_linkers)
                    and all(len(v.get("operationIds", [])) > 0 for v in operation_ids.values())
                )
            wait_options_dict["logger"] = wait_options_dict.get("logger") or self.logger

            operation_ids: OperationIdsByShardsKey = await self.operationTracker.getOperationIdsByShardsKeys(
                [linker["shardsKey"] for linker in transaction_linkers],
                caller,
                cast(Any, wait_options_dict),
            )
            self.logger.debug(f"Operation IDs: {format_object_for_logging(operation_ids)}")
            resolved: list[TransactionLinkerWithOperationId] = []
            for linker in transaction_linkers:
                linker_with_operation_id: TransactionLinkerWithOperationId = {
                    "caller": linker["caller"],
                    "shardCount": linker["shardCount"],
                    "shardsKey": linker["shardsKey"],
                    "timestamp": linker["timestamp"],
                    "sendTransactionResult": linker["sendTransactionResult"],
                    "operationId": operation_ids[linker["shardsKey"]]["operationIds"][0],
                }
                resolved.append(linker_with_operation_id)
            return resolved
        except Exception as exc:
            self.logger.error(f"Error while waiting for operation IDs: {exc}")
            return [
                {
                    "caller": linker["caller"],
                    "shardCount": linker["shardCount"],
                    "shardsKey": linker["shardsKey"],
                    "timestamp": linker["timestamp"],
                    "sendTransactionResult": linker["sendTransactionResult"],
                }
                for linker in transaction_linkers
            ]
