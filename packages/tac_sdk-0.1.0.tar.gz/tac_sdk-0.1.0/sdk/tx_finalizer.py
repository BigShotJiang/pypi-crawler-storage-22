from __future__ import annotations

from errors import tx_finalization_error
from interfaces.i_http_client import IHttpClient
from interfaces.i_logger import ILogger
from interfaces.i_tx_finalizer import ITxFinalizer
from sdk.consts import (
    DEFAULT_FIND_TX_MAX_DEPTH,
    DEFAULT_RETRY_DELAY_MS,
    DEFAULT_RETRY_MAX_COUNT,
    IGNORE_MSG_VALUE_1_NANO,
    IGNORE_OPCODE,
)
from sdk.logger import noop_logger
from sdk.requests_http_client import RequestsHttpClient
from sdk.utils import sleep, to_camel_case_transformer
from structs.internal_struct import (
    AdjacentTransactionsResponse,
    ToncenterTransaction,
    TransactionDepth,
    TxFinalizerConfig,
)
from structs.struct import TrackTransactionTreeParams


class TonTxFinalizer(ITxFinalizer):
    def __init__(
        self,
        api_config: TxFinalizerConfig,
        logger: ILogger | None = None,
        http_client: IHttpClient | None = None,
    ) -> None:
        self.api_config = api_config
        self.logger = logger or noop_logger()
        self.http_client = http_client or RequestsHttpClient()

    async def fetch_adjacent_transactions(
        self, hash_value: str, retries: int = DEFAULT_RETRY_MAX_COUNT, delay: int = DEFAULT_RETRY_DELAY_MS
    ) -> list[ToncenterTransaction]:
        for i in range(retries, -1, -1):
            try:
                url = self.api_config["urlBuilder"](hash_value)
                headers: dict[str, str] = {}
                authorization = self.api_config.get("authorization")
                if authorization is not None:
                    headers[authorization["header"]] = authorization["value"]
                response = self.http_client.get(
                    url,
                    {
                        "headers": headers,
                        "transformResponse": [to_camel_case_transformer],
                    },
                )
                data: AdjacentTransactionsResponse = response.data
                return data.get("transactions", [])
            except Exception as error:
                message = str(error)
                if "429" in message:
                    if i > 0:
                        await sleep(delay)
                    continue
                if "404" not in message:
                    self.logger.warn(f"Failed to fetch adjacent transactions for {hash_value}: {message}")
                if i > 0:
                    await sleep(delay)
        return []

    async def trackTransactionTree(
        self, address: str, hash_value: str, params: TrackTransactionTreeParams | None = None
    ) -> None:
        params = params or {"maxDepth": DEFAULT_FIND_TX_MAX_DEPTH, "ignoreOpcodeList": IGNORE_OPCODE}
        max_depth = params.get("maxDepth", DEFAULT_FIND_TX_MAX_DEPTH)
        ignore_opcode_list = params.get("ignoreOpcodeList", IGNORE_OPCODE)

        visited_hashes = set()
        queue: list[TransactionDepth] = [{"address": None, "hash": hash_value, "depth": 0, "hashType": "unknown"}]

        while queue:
            current = queue.pop(0)
            current_hash = current["hash"]
            current_depth = current["depth"]
            if current_hash in visited_hashes:
                continue
            visited_hashes.add(current_hash)

            self.logger.debug(f"Checking hash (depth {current_depth}): {current_hash}")

            transactions = await self.fetch_adjacent_transactions(current_hash)
            if not transactions:
                continue

            for tx in transactions:
                if str(tx["inMsg"].get("value")) == str(IGNORE_MSG_VALUE_1_NANO):
                    continue
                opcode = tx["inMsg"].get("opcode")
                if opcode is not None and int(opcode) in ignore_opcode_list:
                    self.logger.debug(f"Skipping hash (depth {current_depth}): {tx['hash']}")
                    continue

                description = tx.get("description", {})
                aborted = description.get("aborted")
                compute = description.get("computePh")
                action = description.get("action")
                failure_case = None
                if aborted:
                    failure_case = "Transaction was aborted"
                elif not compute:
                    failure_case = "computePh not present"
                elif not compute.get("success"):
                    failure_case = "computePh not successful"
                elif compute.get("exitCode") != 0:
                    failure_case = "computePh.exitCode was not zero"
                elif action and not action.get("success"):
                    failure_case = "action not successful"
                elif action and action.get("resultCode") != 0:
                    failure_case = "action.resultCode was not zero"

                if failure_case:
                    exit_code = compute.get("exitCode") if compute else "N/A"
                    result_code = action.get("resultCode") if action else "N/A"
                    raise tx_finalization_error(
                        f"{tx['hash']}: {failure_case} (exitCode={exit_code}, resultCode={result_code})"
                    )

                if current_depth + 1 < max_depth and tx.get("outMsgs"):
                    queue.append(
                        {"address": None, "hash": tx["hash"], "depth": current_depth + 1, "hashType": "unknown"}
                    )
