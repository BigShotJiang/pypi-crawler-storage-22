from __future__ import annotations

import asyncio
import base64
import json
import random
import re
import time
from hashlib import sha256
from typing import Any, cast

from Cryptodome.Hash import keccak
from pytoniq import Address, Builder, Cell, ExternalMsgInfo, MessageAny, StateInit

from errors import invalid_method_name_error, token_error, zero_raw_amount_error
from interfaces.asset import Asset
from interfaces.i_configuration import IConfiguration
from sdk.consts import SOLIDITY_METHOD_NAME_REGEX, SOLIDITY_SIGNATURE_REGEX, TON_BURN_ADDRESS
from structs.internal_struct import RandomNumberByTimestamp
from structs.struct import (
    AssetFromFTArg,
    AssetFromNFTCollectionArg,
    AssetFromNFTItemArg,
    AssetLike,
    AssetType,
    EvmProxyMsg,
    FeeParams,
    NFTAddressType,
    TONAsset,
    TransactionLinker,
    ValidExecutors,
    WaitOptions,
)


async def sleep(ms: int) -> None:
    await asyncio.sleep(ms / 1000)


def generate_random_number(interval: int) -> int:
    return round(random.random() * interval)


def generate_random_number_by_timestamp() -> RandomNumberByTimestamp:
    timestamp = int(time.time())
    return {"timestamp": timestamp, "randomNumber": timestamp + generate_random_number(1000)}


def calculate_contract_address(code: Any, data: Any) -> Any:
    state_init = StateInit(code=code, data=data)
    init_cell = state_init.serialize()
    return Address((0, init_cell.hash))


def build_evm_data_cell(
    TransactionLinker: TransactionLinker,
    EvmProxyMsg: EvmProxyMsg,
    ValidExecutors: ValidExecutors,
) -> Cell:
    evm_arguments = None
    encoded = EvmProxyMsg.get("encodedParameters")
    if encoded:
        evm_arguments = base64.b64encode(bytes.fromhex(encoded.replace("0x", ""))).decode("utf-8")
    if not EvmProxyMsg.get("methodName") and evm_arguments:
        raise invalid_method_name_error(EvmProxyMsg.get("methodName") or "")

    payload = {
        "evmCall": {
            "target": EvmProxyMsg["evmTargetAddress"],
            "methodName": format_solidity_method_name(EvmProxyMsg.get("methodName")),
            "arguments": evm_arguments,
            "gasLimit": int(EvmProxyMsg.get("gasLimit") or 0),
        },
        "shardsKey": TransactionLinker["shardsKey"],
        "shardCount": TransactionLinker["shardCount"],
        "evmValidExecutors": ValidExecutors["tac"],
        "tvmValidExecutors": ValidExecutors["ton"],
    }
    json_payload = json.dumps(payload)
    return Builder().store_snake_string(json_payload).end_cell()


def format_solidity_method_name(method_name: str | None) -> str:
    if not method_name:
        return ""
    if not re.match(SOLIDITY_SIGNATURE_REGEX, method_name):
        raise invalid_method_name_error(method_name)
    if re.match(SOLIDITY_METHOD_NAME_REGEX, method_name):
        return f"{method_name}(bytes,bytes)"
    return method_name


def generate_transaction_linker(caller: str, shard_count: int) -> TransactionLinker:
    random_data = generate_random_number_by_timestamp()
    return {
        "caller": caller,
        "shardCount": shard_count,
        "shardsKey": str(random_data["randomNumber"]),
        "timestamp": random_data["timestamp"],
        "sendTransactionResult": None,
    }


def calculate_evm_token_address(
    abi_coder: Any,
    token_utils_address: str,
    cross_chain_layer_token_bytecode: str,
    cross_chain_layer_address: str,
    tvm_address: str,
) -> str:
    def _keccak(data: bytes) -> bytes:
        return keccak.new(digest_bits=256, data=data).digest()

    def _clean_hex(value: str) -> str:
        return value[2:] if value.startswith("0x") else value

    salt = _keccak(tvm_address.encode("utf-8"))
    bytecode = bytes.fromhex(_clean_hex(cross_chain_layer_token_bytecode))

    # ABI-encode address (left padded to 32 bytes)
    addr_hex = _clean_hex(cross_chain_layer_address).rjust(64, "0")
    init_code = bytecode + bytes.fromhex(addr_hex)
    init_code_hash = _keccak(init_code)

    deployer = bytes.fromhex(_clean_hex(token_utils_address).rjust(40, "0"))
    create2_hash = _keccak(b"\xff" + deployer + salt + init_code_hash)
    return "0x" + create2_hash[-20:].hex()


def _snake_to_camel(value: str) -> str:
    return re.sub(r"_([a-z])", lambda m: m.group(1).upper(), value)


def convert_keys_to_camel_case(data: Any) -> Any:
    if isinstance(data, list):
        return [convert_keys_to_camel_case(item) for item in data]
    if isinstance(data, dict):
        return {
            _snake_to_camel(key): convert_keys_to_camel_case(value)
            for key, value in data.items()
        }
    return data


def convert_keys_to_lowercase(data: Any) -> Any:
    """Convert all dict keys to lowercase recursively."""
    if isinstance(data, list):
        return [convert_keys_to_lowercase(item) for item in data]
    if isinstance(data, dict):
        return {
            key.lower(): convert_keys_to_lowercase(value)
            for key, value in data.items()
        }
    return data


def calculate_raw_amount(amount: float, decimals: int) -> int:
    integer_part, dot, fractional_part = f"{amount}".partition(".")
    padded_fraction = (fractional_part or "").ljust(decimals, "0")[:decimals]
    return int(f"{integer_part}{padded_fraction}" or "0")


def calculate_amount(raw_amount: int, decimals: int) -> float:
    raw_str = str(raw_amount)
    if len(raw_str) <= decimals:
        return float(f"0.{raw_str.zfill(decimals)}")
    integer_part = raw_str[:-decimals]
    fractional_part = raw_str[-decimals:].rstrip("0")
    return float(f"{integer_part}.{fractional_part}" if fractional_part else integer_part)


def to_camel_case_transformer(data: str) -> Any:
    try:
        parsed = json.loads(data)
        return convert_keys_to_camel_case(parsed)
    except Exception:
        return data


def generate_fee_data(fee_params: FeeParams | None) -> Any:
    if not fee_params:
        return None
    return (
        Builder()
        .store_bit(bool(fee_params.get("isRoundTrip")))
        .store_coins(int(fee_params.get("protocolFee", 0)))
        .store_coins(int(fee_params.get("evmExecutorFee", 0)))
        .store_coins(int(fee_params.get("tvmExecutorFee", 0)) if fee_params.get("isRoundTrip") else 0)
        .end_cell()
    )


async def wait_until_success(
    options: WaitOptions[Any, Any] | None,
    operation,
    operation_description: str | None = None,
    *args,
) -> Any:
    opts = options or WaitOptions()
    timeout = opts.timeout if opts.timeout is not None else 300000
    max_attempts = opts.maxAttempts if opts.maxAttempts is not None else 30
    delay = opts.delay if opts.delay is not None else 10000
    success_check = opts.successCheck
    context = opts.context
    context_prefix = f"[{operation_description}] " if operation_description else ""

    if opts.logger:
        opts.logger.debug(
            f"{context_prefix}Starting wait for success with timeout={timeout}ms, "
            f"maxAttempts={max_attempts}, delay={delay}ms"
        )

    start_time = asyncio.get_event_loop().time() * 1000
    attempt = 1
    while True:
        current_time = asyncio.get_event_loop().time() * 1000
        elapsed = current_time - start_time
        try:
            result = await operation(*args)
            if result is None:
                raise RuntimeError("Empty result")
            if success_check and not success_check(result, context):
                raise RuntimeError(f"Result is not successful: {format_object_for_logging(result)}")
            if opts.logger:
                opts.logger.debug(f"{context_prefix}Attempt {attempt} successful")
            if opts.onSuccess:
                try:
                    maybe = opts.onSuccess(result, context)
                    if asyncio.iscoroutine(maybe):
                        await maybe
                except Exception as callback_error:  # pragma: no cover - best effort
                    if opts.logger:
                        opts.logger.warn(
                            f"{context_prefix}onSuccess callback error: {callback_error}"
                        )
            return result
        except Exception as error:
            if elapsed >= timeout:
                if opts.logger:
                    opts.logger.debug(f"{context_prefix}Timeout after {elapsed}ms")
                raise error
            if attempt >= max_attempts:
                if opts.logger:
                    opts.logger.debug(
                        f"{context_prefix}Max attempts ({max_attempts}) reached"
                    )
                raise error
            if opts.logger:
                pending_message = _status_retry_message_from_error(error, attempt, max_attempts, delay)
                if pending_message:
                    opts.logger.debug(f"{context_prefix}{pending_message}")
                else:
                    opts.logger.debug(
                        f"{context_prefix}attempt={attempt}/{max_attempts} failed; "
                        f"retry_in={delay}ms; error={error}"
                    )
            await sleep(delay)
            attempt += 1


def format_object_for_logging(obj: Any) -> str:
    def _default(value: Any) -> Any:
        if isinstance(value, int):
            return value
        return str(value)

    return json.dumps(obj, default=_default)


def _status_retry_message_from_error(error: Exception, attempt: int, max_attempts: int, delay: int) -> str | None:
    prefix = "Result is not successful: "
    message = str(error)
    if not message.startswith(prefix):
        return None

    payload_str = message[len(prefix) :].strip()
    try:
        payload = json.loads(payload_str)
    except Exception:
        return None

    if not isinstance(payload, dict):
        return None
    if "stage" not in payload and "success" not in payload and "transactions" not in payload:
        return None

    stage = str(payload.get("stage") or "unknown")
    success_raw = payload.get("success")
    success = str(success_raw).lower() if isinstance(success_raw, bool) else "unknown"

    tx_hash = "-"
    txs = payload.get("transactions")
    if isinstance(txs, list) and txs:
        first = txs[0]
        if isinstance(first, dict):
            tx_hash_raw = first.get("hash")
            tx_hash = tx_hash_raw if isinstance(tx_hash_raw, str) and tx_hash_raw else "-"

    return (
        f"pending attempt={attempt}/{max_attempts} stage={stage} "
        f"success={success} tx={tx_hash} retry_in={delay}ms"
    )


def get_bounced_address(tvm_address: str) -> str:
    return tvm_address


def aggregate_tokens(assets: list[Asset] | None = None) -> dict[str, Any]:
    jettons_map: dict[str, Any] = {}
    nfts_map: dict[str, Any] = {}
    native_ton_asset = None

    for asset_item in assets or []:
        if asset_item.rawAmount == 0 and asset_item.type == AssetType.FT:
            raise zero_raw_amount_error(asset_item.address or "NATIVE ton")

        if asset_item.type == AssetType.FT:
            if not asset_item.address:
                native_ton_asset = (
                    native_ton_asset.addRawAmount(asset_item.rawAmount) if native_ton_asset else asset_item.clone
                )
            else:
                existing = jettons_map.get(asset_item.address)
                jettons_map[asset_item.address] = (
                    existing.addRawAmount(asset_item.rawAmount) if existing else asset_item.clone
                )
        elif asset_item.type == AssetType.NFT:
            nfts_map[asset_item.address] = asset_item.clone

    return {
        "jettons": list(jettons_map.values()),
        "nfts": list(nfts_map.values()),
        "ton": native_ton_asset,
    }


def sha256_to_big_int(contract_name: str) -> int:
    digest = sha256(contract_name.encode("utf-8")).hexdigest()
    return int(digest, 16)


def map_assets_to_ton_assets(assets: list[Asset]) -> list[TONAsset]:
    aggregated = aggregate_tokens(assets)
    result = list(aggregated["jettons"]) + list(aggregated["nfts"])
    if aggregated.get("ton"):
        result.append(aggregated["ton"])

    return [
        {
            "amount": str(asset_item.rawAmount),
            "tokenAddress": asset_item.address or "",
            "assetType": asset_item.type,
        }
        for asset_item in result
    ]


def _get_asset_factory():
    # Lazy import to avoid circular import between assets and sdk utils.
    from assets import AssetFactory

    return AssetFactory


def _parse_asset_type(value: Any) -> AssetType | None:
    if isinstance(value, AssetType):
        return value
    if isinstance(value, str):
        normalized = value.strip().upper()
        enum_member = AssetType.__members__.get(normalized)
        if enum_member is not None:
            return enum_member
        for enum_item in AssetType:
            if str(enum_item.value).upper() == normalized:
                return enum_item
    return None


def _is_ft_with_invalid_amount(asset: Asset, raw_amount: Any, amount: float | None) -> bool:
    if asset.type != AssetType.FT:
        return False
    if raw_amount is not None:
        return int(raw_amount) <= 0
    if amount is not None:
        return amount <= 0
    return True


async def normalize_asset(config: IConfiguration, input_asset: AssetLike) -> Asset:
    asset_factory_class = _get_asset_factory()

    if hasattr(input_asset, "generatePayload"):
        return input_asset  # type: ignore[return-value]

    if isinstance(input_asset, dict):
        input_map = input_asset
    else:
        input_map = {}

    address = str(input_map.get("address", getattr(input_asset, "address", "")))
    token_type = _parse_asset_type(input_map.get("tokenType"))
    item_index = int(input_map["itemIndex"]) if "itemIndex" in input_map else None
    raw_amount = input_map.get("rawAmount")
    amount_raw = input_map.get("amount")
    amount = float(amount_raw) if amount_raw is not None else None

    is_native_ton = address in ("", config.nativeTONAddress, TON_BURN_ADDRESS)

    if item_index is not None:
        args: AssetFromNFTCollectionArg = {
            "address": address,
            "tokenType": AssetType.NFT,
            "addressType": NFTAddressType.COLLECTION,
            "index": item_index,
        }
        return cast(Asset, await asset_factory_class.from_(config, args))

    if token_type == AssetType.NFT:
        item_args: AssetFromNFTItemArg = {
            "address": address,
            "tokenType": AssetType.NFT,
            "addressType": NFTAddressType.ITEM,
        }
        return cast(Asset, await asset_factory_class.from_(config, item_args))

    if token_type == AssetType.FT or is_native_ton or raw_amount is not None or amount is not None:
        ft_args: AssetFromFTArg = {"address": address, "tokenType": AssetType.FT}
        normalized_asset = cast(Asset, await asset_factory_class.from_(config, ft_args))
        if _is_ft_with_invalid_amount(normalized_asset, raw_amount, amount):
            raise zero_raw_amount_error(normalized_asset.address or "NATIVE TON")
        if raw_amount is not None:
            return normalized_asset.withRawAmount(int(raw_amount))
        if amount is not None:
            return normalized_asset.withAmount(float(amount))
        return normalized_asset

    try:
        ft_args: AssetFromFTArg = {"address": address, "tokenType": AssetType.FT}
        normalized_asset = cast(Asset, await asset_factory_class.from_(config, ft_args))
        if normalized_asset.type == AssetType.FT:
            raise zero_raw_amount_error(normalized_asset.address or "NATIVE TON")
        return normalized_asset
    except Exception as exc:
        if isinstance(exc, token_error) and exc.error_code == zero_raw_amount_error("x").error_code:
            raise

    item_args: AssetFromNFTItemArg = {
        "address": address,
        "tokenType": AssetType.NFT,
        "addressType": NFTAddressType.ITEM,
    }
    return cast(Asset, await asset_factory_class.from_(config, item_args))


async def normalize_assets(config: IConfiguration, assets: list[AssetLike] | None = None) -> list[Asset]:
    if not assets:
        return []
    normalized: list[Asset] = []
    for asset_item in assets:
        normalized.append(await normalize_asset(config, asset_item))
    return normalized


def get_address_string(cell: Any | None = None) -> str:
    if cell is None:
        return ""
    try:
        addr = cell.begin_parse().load_address()
        if addr is None:
            return ""
        return addr.to_str(is_user_friendly=True, is_url_safe=True, is_bounceable=True, is_test_only=False)
    except Exception:
        if getattr(cell, "refs", None):
            for ref in cell.refs:
                parsed = get_address_string(ref)
                if parsed:
                    return parsed
        return ""


def get_number(length: int, cell: Any | None = None) -> int:
    if cell is None:
        return 0
    try:
        return int(cell.begin_parse().load_uint(length))
    except Exception:
        if getattr(cell, "refs", None):
            for ref in cell.refs:
                value = get_number(length, ref)
                if value:
                    return value
        return 0


def get_string(cell: Any | None = None) -> str:
    if cell is None:
        return ""
    try:
        return cell.begin_parse().load_string()
    except Exception:
        try:
            return cell.begin_parse().load_snake_string()
        except Exception:
            if getattr(cell, "refs", None):
                for ref in cell.refs:
                    value = get_string(ref)
                    if value:
                        return value
            return ""


def muldivr(a: int, b: int, c: int) -> int:
    if c == 0:
        raise ValueError("Division by zero in muldivr")
    return (a * b + c // 2) // c


def normalize_hash_to_base64(hash_value: str) -> str:
    if re.match(r"^[A-Za-z0-9+/]+={0,2}$", hash_value):
        try:
            base64.b64decode(hash_value, validate=True)
            return hash_value
        except Exception:
            pass
    if re.match(r"^[0-9a-fA-F]+$", hash_value):
        return base64.b64encode(bytes.fromhex(hash_value)).decode("utf-8")
    return hash_value


def get_normalized_ext_message_hash(message: Any) -> str:
    if not isinstance(message, MessageAny) or not message.is_external:
        raise ValueError('Message must be "external-in"')
    normalized_info = ExternalMsgInfo(
        src=cast(Any, None),
        dest=message.info.dest,
        import_fee=0,
    )
    normalized_message = MessageAny(info=normalized_info, init=None, body=message.body)
    return base64.b64encode(normalized_message.serialize().hash).decode("utf-8")


async def retry(fn, options: dict[str, int]) -> Any:
    last_error: Exception | None = None
    for _ in range(options.get("retries", 0)):
        try:
            return await fn()
        except Exception as exc:
            last_error = exc
            await asyncio.sleep(options.get("delay", 0) / 1000)
    if last_error:
        raise last_error


def recurisively_collect_cell_stats(cell: Any) -> dict[str, int]:
    bits = len(cell.bits)
    cells = 1
    for ref in cell.refs:
        stats = recurisively_collect_cell_stats(ref)
        bits += stats["bits"]
        cells += stats["cells"]
    return {"bits": bits, "cells": cells}
