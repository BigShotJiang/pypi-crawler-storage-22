from __future__ import annotations

import re

from errors import evm_address_error, tvm_address_error
from structs.struct import EvmProxyMsg, TACSimulationParams

_EVM_REGEX = re.compile(r"^0x[a-fA-F0-9]{40}$")


class Validator:
    @staticmethod
    def validate_tac_simulation_params(req: TACSimulationParams) -> None:
        Validator.validate_evm_address(req["tacCallParams"]["target"])
        for addr in req.get("evmValidExecutors", []) or []:
            Validator.validate_evm_address(addr)
        for addr in req.get("tvmValidExecutors", []) or []:
            Validator.validate_tvm_address(addr)
        for asset in req.get("tonAssets", []) or []:
            if asset.get("tokenAddress"):
                Validator.validate_tvm_address(asset["tokenAddress"])
        Validator.validate_tvm_address(req["tonCaller"])

    @staticmethod
    def validate_evm_proxy_msg(evm_proxy_msg: EvmProxyMsg) -> None:
        Validator.validate_evm_address(evm_proxy_msg["evmTargetAddress"])

    @staticmethod
    def validate_tvm_addresses(addresses: list[str] | None = None) -> None:
        for addr in addresses or []:
            Validator.validate_tvm_address(addr)

    @staticmethod
    def validate_evm_addresses(addresses: list[str] | None = None) -> None:
        for addr in addresses or []:
            Validator.validate_evm_address(addr)

    @staticmethod
    def validate_tvm_address(address: str) -> None:
        if not isinstance(address, str) or not address.strip():
            raise tvm_address_error(address)

    @staticmethod
    def validate_evm_address(address: str) -> None:
        if not _EVM_REGEX.match(address or ""):
            raise evm_address_error(address)
