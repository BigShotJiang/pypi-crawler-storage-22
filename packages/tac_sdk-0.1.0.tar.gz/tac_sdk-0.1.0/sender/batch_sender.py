from __future__ import annotations

import time
from typing import Any

from pytoniq.contract.contract import Contract
from pytoniq_core.boc.address import Address

from errors.instances import no_valid_group_found_error, prepare_message_group_error
from interfaces.asset import Asset
from interfaces.contract_opener import ContractOpener
from interfaces.sender_abstraction import SenderAbstraction
from sdk.consts import MAX_EXT_MSG_SIZE, MAX_HIGHLOAD_GROUP_MSG_NUM, MAX_MSG_DEPTH
from structs.internal_struct import SendResult, ShardTransaction
from structs.struct import Network
from wrappers.highload_wallet_v3 import highload_wallet_v3


class BatchSender(SenderAbstraction):
    def __init__(self, wallet: Any, secret_key: bytes):
        self.wallet = wallet
        self.secret_key = secret_key
        self.lastCreatedAt = 0

    async def getBalanceOf(self, asset: Asset) -> int:
        return await asset.getBalanceOf(self.getSenderAddress())

    async def getBalance(self, contractOpener: ContractOpener) -> int:
        state = await contractOpener.getContractState(self.wallet.address)
        return state["balance"]

    async def sendShardTransactions(
        self,
        shardTransactions: list[ShardTransaction],
        chain: Network | None = None,
        contractOpener: ContractOpener | None = None,
    ) -> list[SendResult]:
        if contractOpener is None:
            raise ValueError("contractOpener is required")

        all_messages = []
        min_valid_until = 2**63 - 1

        for transaction in shardTransactions:
            for message in transaction["messages"]:
                all_messages.append(
                    Contract.create_internal_msg(
                        dest=Address(message["address"]),
                        value=int(message["value"]),
                        bounce=True,
                        body=message["payload"],
                    )
                )
            min_valid_until = min(min_valid_until, transaction["validUntil"])

        groups = await self._prepare_groups(all_messages)

        results: list[SendResult] = []
        current_index = 0

        for group in groups:
            try:
                result = await self._send_group(group, contractOpener)
                boc = result if isinstance(result, str) else (result.get("result") if isinstance(result, dict) else "")
                results.append(
                    SendResult(success=True, boc=boc or "", result=result, lastMessageIndex=current_index + len(group) - 1)
                )
            except Exception as error:
                results.append(SendResult(success=False, boc="", error=error, lastMessageIndex=current_index - 1))
                break
            current_index += len(group)

        return results

    async def sendShardTransaction(
        self,
        shardTransaction: ShardTransaction,
        chain: Network | None = None,
        contractOpener: ContractOpener | None = None,
    ) -> SendResult:
        if contractOpener is None:
            raise ValueError("contractOpener is required")

        messages = []
        for message in shardTransaction["messages"]:
            messages.append(
                Contract.create_internal_msg(
                    dest=Address(message["address"]),
                    value=int(message["value"]),
                    bounce=True,
                    body=message["payload"],
                )
            )

        result = await self._send_group(messages, contractOpener)
        boc = result if isinstance(result, str) else (result.get("result") if isinstance(result, dict) else "")
        return SendResult(success=True, boc=boc or "", result=result, lastMessageIndex=len(messages) - 1)

    def getSenderAddress(self) -> str:
        address = self.wallet.address
        if hasattr(address, "to_str"):
            return address.to_str(is_user_friendly=True, is_url_safe=True, is_bounceable=True, is_test_only=False)
        return str(address)

    async def _prepare_groups(self, messages: list[Any]) -> list[list[Any]]:
        total = len(messages)
        left = 0
        groups: list[list[Any]] = []

        while left < total:
            group_size = min(total - left, MAX_HIGHLOAD_GROUP_MSG_NUM)
            valid_group_found = False

            while group_size > 0:
                group = messages[left : left + group_size]
                created_at = int(time.time()) - 40
                query_id = self.wallet.getQueryIdFromCreatedAt(created_at)
                external_msg = self.wallet.getExternalMessage(group, 3, 0, query_id)
                is_boc_size_valid = len(external_msg.body.to_boc()) <= MAX_EXT_MSG_SIZE
                is_depth_valid = external_msg.body.get_depth() <= MAX_MSG_DEPTH

                if is_boc_size_valid and is_depth_valid:
                    groups.append(group)
                    left += group_size
                    valid_group_found = True
                    break

                if group_size <= 1:
                    raise prepare_message_group_error(is_boc_size_valid, is_depth_valid)

                group_size = group_size // 2

            if not valid_group_found:
                raise no_valid_group_found_error

        return groups

    async def _send_group(self, messages: list[Any], contractOpener: ContractOpener) -> str | dict:
        wallet_contract = contractOpener.open(self.wallet)

        created_at = highload_wallet_v3.generate_created_at()
        if created_at <= self.lastCreatedAt:
            created_at = self.lastCreatedAt + 1
        self.lastCreatedAt = created_at

        return await wallet_contract.sendTransfer(
            secretKey=self.secret_key,
            messages=messages,
            sendMode=3,
            createdAt=created_at,
        )
