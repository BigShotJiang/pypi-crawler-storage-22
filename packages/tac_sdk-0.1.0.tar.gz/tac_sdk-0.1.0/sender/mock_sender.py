from __future__ import annotations

from typing import Any

from interfaces.sender_abstraction import SenderAbstraction
from structs.internal_struct import SendResult


def get_mock_sender(sender_address: str) -> SenderAbstraction:
    class _MockSender:
        def getSenderAddress(self) -> str:
            return sender_address

        async def sendShardTransaction(self, *args: Any, **kwargs: Any) -> SendResult:
            return SendResult(success=True, boc="")

        async def sendShardTransactions(self, *args: Any, **kwargs: Any) -> list[SendResult]:
            return []

        async def getBalance(self, *args: Any, **kwargs: Any) -> int:
            return 0

        async def getBalanceOf(self, *args: Any, **kwargs: Any) -> int:
            return 0

    return _MockSender()
