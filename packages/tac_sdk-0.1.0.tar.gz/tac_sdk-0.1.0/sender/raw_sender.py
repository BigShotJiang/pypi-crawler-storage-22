from __future__ import annotations

import base64
from typing import Any, Optional, cast

from pytoniq.contract.contract import Contract
from pytoniq.contract.wallets.wallet import WALLET_V3_R1_CODE, WALLET_V3_R2_CODE, WALLET_V4_R2_CODE
from pytoniq.contract.wallets.wallet_v5 import WALLET_V5_R1_CODE
from pytoniq_core.boc.address import Address
from pytoniq_core.boc.cell import Cell
from pytoniq_core.tlb.account import StateInit

from interfaces.asset import Asset
from interfaces.contract_opener import ContractOpener
from interfaces.sender_abstraction import SenderAbstraction
from interfaces.wallet_instanse import WalletInstanse
from structs.internal_struct import SendResult, ShardTransaction
from structs.struct import Network


def _matches_deployed_wallet_code(code_boc: bytes, version: str) -> bool:
    try:
        deployed_hash = Cell.one_from_boc(code_boc).hash
    except Exception:
        return True

    expected_by_version = {
        "V3R1": WALLET_V3_R1_CODE.hash,
        "V3R2": WALLET_V3_R2_CODE.hash,
        "V4": WALLET_V4_R2_CODE.hash,
        "V5R1": WALLET_V5_R1_CODE.hash,
    }
    expected_hash = expected_by_version.get(version)
    if expected_hash is None:
        return True
    return deployed_hash == expected_hash


class RawSender(SenderAbstraction):
    def __init__(self, wallet: WalletInstanse, secret_key: bytes, max_batch_size: int = 4):
        self.wallet = wallet
        self.secret_key = secret_key
        self.max_batch_size = max_batch_size

    async def getBalanceOf(self, asset: Asset) -> int:
        return await asset.getBalanceOf(self.getSenderAddress())

    async def getBalance(self, contractOpener: ContractOpener) -> int:
        state = await contractOpener.getContractState(self.wallet.address)
        return state["balance"]

    async def sendShardTransactions(
        self,
        shardTransactions: list[ShardTransaction],
        chain: Network | None = None,
        contractOpener: ContractOpener | None = None,
    ) -> list[SendResult]:
        if contractOpener is None:
            raise ValueError("contractOpener is required")

        all_messages = []
        for transaction in shardTransactions:
            for message in transaction["messages"]:
                all_messages.append(
                    Contract.create_internal_msg(
                        dest=Address(message["address"]),
                        value=int(message["value"]),
                        bounce=True,
                        body=message["payload"],
                    )
                )

        batches = self._prepare_batches(all_messages)

        results: list[SendResult] = []
        current_index = 0

        for batch in batches:
            try:
                result = await self._send_batch(batch, contractOpener)
                boc = result if isinstance(result, str) else (result.get("result") if isinstance(result, dict) else "")
                results.append(
                    SendResult(success=True, boc=boc or "", result=result, lastMessageIndex=current_index + len(batch) - 1)
                )
            except Exception as error:
                results.append(
                    SendResult(success=False, boc="", error=error, lastMessageIndex=current_index - 1)
                )
                break
            current_index += len(batch)

        return results

    async def sendShardTransaction(
        self,
        shardTransaction: ShardTransaction,
        chain: Network | None = None,
        contractOpener: ContractOpener | None = None,
    ) -> SendResult:
        if contractOpener is None:
            raise ValueError("contractOpener is required")

        messages = []
        for message in shardTransaction["messages"]:
            messages.append(
                Contract.create_internal_msg(
                    dest=Address(message["address"]),
                    value=int(message["value"]),
                    bounce=True,
                    body=message["payload"],
                )
            )

        result = await self._send_batch(messages, contractOpener)
        boc = result if isinstance(result, str) else (result.get("result") if isinstance(result, dict) else "")
        return SendResult(success=True, boc=boc or "", result=result, lastMessageIndex=len(messages) - 1)

    def getSenderAddress(self) -> str:
        address = self.wallet.address
        if hasattr(address, "to_str"):
            return address.to_str(is_user_friendly=True, is_url_safe=True, is_bounceable=True, is_test_only=False)
        return str(address)

    def _prepare_batches(self, messages: list[Any]) -> list[list[Any]]:
        batches = []
        for i in range(0, len(messages), self.max_batch_size):
            batches.append(messages[i : i + self.max_batch_size])
        return batches

    async def _send_batch(self, messages: list[Any], contractOpener: ContractOpener) -> str | dict | None:
        wallet_contract = contractOpener.open(self.wallet)
        seqno = await wallet_contract.getSeqno()

        msg_body = self.wallet.createTransfer(
            {
                "seqno": seqno,
                "secretKey": self.secret_key,
                "messages": messages,
                "sendMode": 3,
            }
        )

        needed_init = None
        local_state_init = getattr(self.wallet, "init", None) or getattr(self.wallet, "state_init", None)
        if local_state_init is not None:
            state = await contractOpener.getContractState(self.wallet.address)
            if state.get("state") == "active":
                wallet_version = getattr(self.wallet, "version", "")
                deployed_code = state.get("code")
                if isinstance(deployed_code, (bytes, bytearray)) and not _matches_deployed_wallet_code(
                    bytes(deployed_code), str(wallet_version)
                ):
                    raise RuntimeError(
                        f"Wallet version mismatch: configured {wallet_version}, "
                        "but deployed wallet code has different version"
                    )
            else:
                needed_init = local_state_init

        external = Contract.create_external_msg(
            dest=cast(Address, self.wallet.address),
            state_init=cast(Optional[StateInit], needed_init),
            body=cast(Cell, msg_body),
        )
        boc = external.serialize().to_boc()
        boc_b64 = base64.b64encode(boc).decode("utf-8")

        if hasattr(contractOpener, "raw_send_message"):
            await contractOpener.raw_send_message(boc)
            return boc_b64

        result = await wallet_contract.send(msg_body, needed_init)
        return result or boc_b64
