from __future__ import annotations

from typing import Any, Callable, cast

from pytoniq.contract.wallets import wallet as wallet_lib
from pytoniq.contract.wallets.wallet import (
    WALLET_V3_R1_CODE,
    WALLET_V3_R2_CODE,
    WALLET_V4_R2_CODE,
    WalletV3,
    WalletV4,
)
from pytoniq.contract.wallets.wallet_v5 import WALLET_V5_R1_CODE, WalletV5R1, WalletV5WalletID
from pytoniq_core.boc.address import Address
from pytoniq_core.tlb.account import StateInit
from pytoniq_core.tlb.custom.wallet import WalletMessage

from errors import unknown_wallet_error
from sender.batch_sender import BatchSender
from sender.raw_sender import RawSender
from sender.ton_connect_sender import TonConnectSender
from structs.struct import Network
from wrappers.highload_wallet_v3 import DEFAULT_SUBWALLET_ID, DEFAULT_TIMEOUT, highload_wallet_v3


class _LocalWallet:
    def __init__(self, wallet: Any, version: str):
        self._wallet = wallet
        self.version = version
        self.address = cast(Address, getattr(wallet, "address"))
        self.state_init = cast(StateInit | None, getattr(wallet, "state_init", None))
        self.init = self.state_init

    def createTransfer(self, args: dict):
        seqno = int(args.get("seqno", 0))
        secret_key = args.get("secretKey")
        if not isinstance(secret_key, (bytes, bytearray)):
            raise ValueError("secretKey must be bytes")
        secret_key = bytes(secret_key)
        messages = args.get("messages") or []
        send_mode = int(args.get("sendMode", 3))
        wallet_messages = [WalletMessage(send_mode, msg) for msg in messages]
        wallet_id = int(getattr(self._wallet, "wallet_id"))
        raw_create_transfer = getattr(self._wallet, "raw_create_transfer_msg", None)
        if not callable(raw_create_transfer):
            raise unknown_wallet_error(self.version)
        return raw_create_transfer(
            private_key=secret_key,
            seqno=seqno,
            wallet_id=wallet_id,
            messages=wallet_messages,
        )

    async def getSeqno(self, provider: object) -> int:
        _ = provider
        return 0

    async def send(self, provider: object, msg: object) -> str | None:
        _ = (provider, msg)
        return None


class SenderFactory:
    @staticmethod
    async def get_sender(params: dict) -> Any:
        if "tonConnect" in params:
            return TonConnectSender(params["tonConnect"])

        version = params.get("version")
        if not version:
            raise unknown_wallet_error("unknown")

        # Normalize version to uppercase
        version = str(version).upper()

        if version not in ("V3R1", "V3R2", "V4", "V5R1", "HIGHLOAD_V3"):
            raise unknown_wallet_error(version)

        mnemonic = params.get("mnemonic", "").split()
        mnemonic_to_private_key_name = "mnemonic_to_private_key"
        mnemonic_to_private_key = cast(
            Callable[[list[str]], tuple[bytes, bytes]],
            getattr(wallet_lib, mnemonic_to_private_key_name),
        )
        public_key, secret_key = mnemonic_to_private_key(mnemonic)
        if not isinstance(secret_key, (bytes, bytearray)):
            raise ValueError("mnemonic_to_private_key returned invalid secret key")
        secret_key = bytes(secret_key)

        workchain = 0
        wallet_id = None
        if version == "V3R1":
            wallet_id = 698983191 + workchain
            data = wallet_lib.WalletV3.create_data_cell(public_key, wallet_id=wallet_id, wc=workchain)
            init = StateInit(code=WALLET_V3_R1_CODE, data=data)
            address = Address((workchain, init.serialize().hash))
            local = WalletV3(provider=None, address=address, state_init=init, private_key=secret_key)
        elif version == "V3R2":
            wallet_id = 698983191 + workchain
            data = wallet_lib.WalletV3.create_data_cell(public_key, wallet_id=wallet_id, wc=workchain)
            init = StateInit(code=WALLET_V3_R2_CODE, data=data)
            address = Address((workchain, init.serialize().hash))
            local = WalletV3(provider=None, address=address, state_init=init, private_key=secret_key)
        elif version == "V4":
            wallet_id = 698983191 + workchain
            data = wallet_lib.WalletV4.create_data_cell(public_key, wallet_id=wallet_id, wc=workchain)
            init = StateInit(code=WALLET_V4_R2_CODE, data=data)
            address = Address((workchain, init.serialize().hash))
            local = WalletV4(provider=None, address=address, state_init=init, private_key=secret_key)
        elif version == "V5R1":
            selected_network = params.get("network", Network.MAINNET)
            network_global_id = -239 if selected_network == Network.MAINNET else -3
            subwallet_number = (params.get("options") or {}).get("v5r1", {}).get("subwalletNumber", 0)
            wallet_id = WalletV5WalletID(network_global_id, workchain=workchain, subwallet_number=subwallet_number).pack()
            data = WalletV5R1.create_data_cell(public_key, wc=workchain, wallet_id=wallet_id)
            init = StateInit(code=WALLET_V5_R1_CODE, data=data)
            address = Address((workchain, init.serialize().hash))
            local = WalletV5R1(provider=None, address=address, state_init=init, private_key=secret_key)
        else:  # HIGHLOAD_V3
            subwallet_id = (params.get("options") or {}).get("highloadV3", {}).get("subwalletId", DEFAULT_SUBWALLET_ID)
            timeout = (params.get("options") or {}).get("highloadV3", {}).get("timeout", DEFAULT_TIMEOUT)
            wallet = highload_wallet_v3.create(public_key, workchain, subwallet_id=subwallet_id, timeout=timeout)
            return BatchSender(wallet, secret_key)

        wallet = _LocalWallet(local, version)
        max_batch = 254 if version == "V5R1" else 4
        return RawSender(wallet, secret_key, max_batch)
