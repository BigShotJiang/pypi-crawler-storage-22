from __future__ import annotations

import base64
from typing import Any

from pytoniq_core.boc.address import Address

from interfaces.asset import Asset
from interfaces.contract_opener import ContractOpener
from interfaces.sender_abstraction import SenderAbstraction
from sdk.utils import sleep
from structs.internal_struct import SendResult, ShardTransaction
from structs.struct import Network


class TonConnectSender(SenderAbstraction):
    def __init__(self, ton_connect_ui: Any):
        self.ton_connect_ui = ton_connect_ui

    async def getBalanceOf(self, asset: Asset) -> int:
        return await asset.getBalanceOf(self.getSenderAddress())

    async def getBalance(self, contractOpener: ContractOpener) -> int:
        account = getattr(self.ton_connect_ui, "account", None)
        if not account or not getattr(account, "address", None):
            return 0
        return (await contractOpener.getContractState(Address(account.address))).get("balance", 0)

    async def sendShardTransactions(
        self,
        shardTransactions: list[ShardTransaction],
        chain: Network | None = None,
        contractOpener: ContractOpener | None = None,
    ) -> list[SendResult]:
        all_messages = []
        min_valid_until = 2**63 - 1
        for transaction in shardTransactions:
            for message in transaction["messages"]:
                payload_b64 = base64.b64encode(message["payload"].to_boc()).decode("utf-8")
                all_messages.append(
                    {
                        "address": message["address"],
                        "amount": str(message["value"]),
                        "payload": payload_b64,
                    }
                )
            min_valid_until = min(min_valid_until, transaction["validUntil"])

        return await self._send_chunked_messages(all_messages, min_valid_until, chain or Network.MAINNET)

    async def sendShardTransaction(
        self,
        shardTransaction: ShardTransaction,
        chain: Network | None = None,
        contractOpener: ContractOpener | None = None,
    ) -> SendResult:
        messages = []
        for message in shardTransaction["messages"]:
            payload_b64 = base64.b64encode(message["payload"].to_boc()).decode("utf-8")
            messages.append(
                {
                    "address": message["address"],
                    "amount": str(message["value"]),
                    "payload": payload_b64,
                }
            )

        responses = await self._send_chunked_messages(messages, shardTransaction["validUntil"], chain or Network.MAINNET)
        return responses[0]

    def getSenderAddress(self) -> str:
        account = getattr(self.ton_connect_ui, "account", None)
        return getattr(account, "address", "") if account else ""

    async def _send_chunked_messages(self, messages: list[dict], valid_until: int, chain: Network) -> list[SendResult]:
        responses: list[SendResult] = []
        current_index = 0

        chunk_size = 4
        wallet = getattr(self.ton_connect_ui, "wallet", None)
        if wallet and getattr(wallet, "device", None):
            for feature in getattr(wallet.device, "features", []):
                if isinstance(feature, dict) and "maxMessages" in feature:
                    chunk_size = feature.get("maxMessages", chunk_size)

        for i in range(0, len(messages), chunk_size):
            chunk = messages[i : i + chunk_size]
            transaction = {"validUntil": valid_until, "messages": chunk, "network": chain.value if hasattr(chain, "value") else str(chain)}

            try:
                send_fn = getattr(self.ton_connect_ui, "sendTransaction", None) or getattr(self.ton_connect_ui, "send_transaction", None)
                if not send_fn:
                    raise RuntimeError("TonConnect sender object does not implement sendTransaction")
                response = await send_fn(transaction)
                boc = ""
                if isinstance(response, dict):
                    boc = response.get("boc", "")
                else:
                    boc = getattr(response, "boc", "")
                responses.append(
                    SendResult(
                        success=True,
                        result=response,
                        boc=boc,
                        lastMessageIndex=current_index + len(chunk) - 1,
                    )
                )
                current_index += len(chunk)
            except Exception as error:
                responses.append(SendResult(success=False, boc="", error=error, lastMessageIndex=current_index - 1))
                break

            if i + chunk_size < len(messages):
                await sleep(1000)

        return responses
