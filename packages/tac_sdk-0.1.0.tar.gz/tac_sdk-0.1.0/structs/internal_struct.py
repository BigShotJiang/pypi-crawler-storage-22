from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable, Literal, NotRequired, TypedDict

from structs.struct import (
    CurrencyType,
    ExecutionStagesByOperationId,
    Network,
    OperationIdsByShardsKey,
    OperationType,
    StatusInfosByOperationId,
    SuggestedTVMExecutorFee,
    TACSimulationResult,
)


class ShardMessage(TypedDict):
    address: str
    value: int
    payload: Any
    extra: ShardMessageExtra


class ShardMessageExtra(TypedDict, total=False):
    tonNetworkFee: int
    tacEstimatedGas: int


class ShardTransaction(TypedDict):
    validUntil: int
    messages: list[ShardMessage]
    network: Network


class AssetOpType(str, Enum):
    JETTON_BURN = "JETTON_BURN"
    JETTON_TRANSFER = "JETTON_TRANSFER"
    NFT_BURN = "NFT_BURN"
    NFT_TRANSFER = "NFT_TRANSFER"


class RandomNumberByTimestamp(TypedDict):
    timestamp: int
    randomNumber: int


class InternalTONParams(TypedDict, total=False):
    contractOpener: Any
    jettonProxyAddress: str
    nftProxyAddress: str
    crossChainLayerAddress: str
    jettonMinterCode: Any
    jettonWalletCode: Any
    nftItemCode: Any
    nftCollectionCode: Any
    feesParams: TONFeesParams
    contractFeeUsageParams: ContractFeeUsageParams


class InternalTACParams(TypedDict, total=False):
    provider: Any
    crossChainLayer: Any
    settings: Any
    tokenUtils: Any
    smartAccountFactory: Any
    trustedTACExecutors: list[str]
    trustedTONExecutors: list[str]
    abiCoder: Any


class ResponseBase(TypedDict):
    response: Any


class StringResponse(ResponseBase):
    response: str


class OperationTypeResponse(ResponseBase):
    response: OperationType


class StatusesResponse(ResponseBase):
    response: StatusInfosByOperationId


class OperationIdsByShardsKeyResponse(ResponseBase):
    response: OperationIdsByShardsKey


class StageProfilingResponse(ResponseBase):
    response: ExecutionStagesByOperationId


class TACSimulationResponse(ResponseBase):
    response: TACSimulationResult


class SuggestedTVMExecutorFeeResponse(ResponseBase):
    response: SuggestedTVMExecutorFee


class ConvertCurrencyResponse(ResponseBase):
    response: ConvertedCurrencyRawResult


class OperationIdWithLogIndex(TypedDict):
    operationId: str
    logIndex: int


class OperationIdWithLogIndexResponse(ResponseBase):
    response: OperationIdWithLogIndex


@dataclass
class SendResult:
    success: bool
    boc: str
    result: Any | None = None
    error: Exception | None = None
    lastMessageIndex: int | None = None


class ToncenterTransactionAction(TypedDict):
    resultCode: int
    success: bool


class ToncenterTransactionComputePh(TypedDict):
    exitCode: int
    success: bool


class ToncenterTransactionDescription(TypedDict):
    aborted: bool
    destroyed: bool
    action: NotRequired[ToncenterTransactionAction]
    computePh: NotRequired[ToncenterTransactionComputePh]


class ToncenterInMsg(TypedDict):
    hash: str
    opcode: str
    value: str


class ToncenterOutMsg(TypedDict):
    hash: str


class ToncenterTransaction(TypedDict):
    description: ToncenterTransactionDescription
    hash: str
    inMsg: ToncenterInMsg
    outMsgs: list[ToncenterOutMsg]


class TransactionDepth(TypedDict):
    address: Any
    hash: str
    depth: int
    hashType: Literal["unknown", "in", "out"]


class AdjacentTransactionsResponse(TypedDict):
    transactions: list[ToncenterTransaction]


class TxFinalizerAuthorization(TypedDict):
    header: str
    value: str


class TxFinalizerConfig(TypedDict):
    urlBuilder: Callable[[str], str]
    authorization: NotRequired[TxFinalizerAuthorization]


class UsdPriceInfoRaw(TypedDict):
    spot: str
    ema: str
    decimals: int


class ConvertedCurrencyRawResult(TypedDict):
    spotValue: str
    emaValue: str
    decimals: int
    currency: CurrencyType
    tacPrice: UsdPriceInfoRaw
    tonPrice: UsdPriceInfoRaw


class TONFeesParams(TypedDict):
    accountBitPrice: int
    accountCellPrice: int
    lumpPrice: int
    gasPrice: int
    firstFrac: int
    ihrPriceFactor: int
    msgBitPrice: int
    msgCellPrice: int


class CrossChainLayerGasUsage(TypedDict):
    tvmMsgToEvm: int


class CrossChainLayerFeeUsage(TypedDict):
    accountBits: int
    accountCells: int
    gas: CrossChainLayerGasUsage


class JettonWalletGasUsage(TypedDict):
    internalTransfer: int
    receive: int
    burn: int
    estimatedSendTransfer: int
    estimatedReceiveTransfer: int


class JettonWalletFeeUsage(TypedDict):
    accountBits: int
    accountCells: int
    estimatedAccountBits: int
    estimatedAccountCells: int
    initStateBits: int
    initStateCells: int
    gas: JettonWalletGasUsage


class JettonProxyGasUsage(TypedDict):
    ownershipAssigned: int
    transferNotification: int
    errorNotification: int


class JettonProxyFeeUsage(TypedDict):
    accountBits: int
    accountCells: int
    gas: JettonProxyGasUsage


class JettonMinterGasUsage(TypedDict):
    burnNotification: int
    mintAfterError: int


class JettonMinterFeeUsage(TypedDict):
    accountBits: int
    accountCells: int
    gas: JettonMinterGasUsage


class NftItemGasUsage(TypedDict):
    send: int
    burn: int
    errorNotification: int


class NftItemFeeUsage(TypedDict):
    accountBits: int
    accountCells: int
    gas: NftItemGasUsage


class NftProxyGasUsage(TypedDict):
    ownershipAssigned: int
    errorNotification: int


class NftProxyFeeUsage(TypedDict):
    accountBits: int
    accountCells: int
    gas: NftProxyGasUsage


class ContractFeeUsageParams(TypedDict):
    crossChainLayer: CrossChainLayerFeeUsage
    jettonWallet: JettonWalletFeeUsage
    jettonProxy: JettonProxyFeeUsage
    jettonMinter: JettonMinterFeeUsage
    nftItem: NftItemFeeUsage
    nftProxy: NftProxyFeeUsage


class TransactionFeeCalculationStep(TypedDict):
    accountBits: int
    accountCells: int
    gasUsed: int
    msgBits: int
    msgCells: int
    timeDelta: int


class TONFeeCalculationParams(TransactionFeeCalculationStep, TONFeesParams):
    ...


class TacGasPrices(TypedDict):
    average: float
    fast: float
    slow: float


class TacGasPriceResponse(TypedDict):
    gasPrices: TacGasPrices
