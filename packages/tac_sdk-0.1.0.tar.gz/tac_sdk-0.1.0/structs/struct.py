from __future__ import annotations

from collections.abc import Awaitable
from dataclasses import dataclass
from enum import Enum
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Generic,
    Literal,
    NotRequired,
    Protocol,
    TypedDict,
    TypeVar,
    Union,
)

if TYPE_CHECKING:
    from assets.ft import Ft
    from assets.nft import Nft
    from interfaces.asset import Asset
    from interfaces.contract_opener import ContractOpener
    from interfaces.i_logger import ILogger
else:
    Asset = Any
    ContractOpener = Any
    ILogger = Any
    Ft = Any
    Nft = Any


class ContractState(TypedDict):
    balance: int
    state: Literal["active", "uninitialized", "frozen"]
    code: bytes | None


class SimplifiedStatuses(str, Enum):
    PENDING = "PENDING"
    FAILED = "FAILED"
    SUCCESSFUL = "SUCCESSFUL"
    OPERATION_ID_NOT_FOUND = "OPERATION_ID_NOT_FOUND"


class Network(str, Enum):
    TESTNET = "testnet"
    MAINNET = "mainnet"
    DEV = "dev"


class BlockchainType(str, Enum):
    TAC = "TAC"
    TON = "TON"


class CurrencyType(str, Enum):
    TAC = "TAC"
    TON = "TON"


class OperationType(str, Enum):
    PENDING = "PENDING"
    TON_TAC_TON = "TON-TAC-TON"
    ROLLBACK = "ROLLBACK"
    TON_TAC = "TON-TAC"
    TAC_TON = "TAC-TON"
    UNKNOWN = "UNKNOWN"


@dataclass
class TACParams:
    provider: Any | None = None
    settingsAddress: str | None = None
    saFactoryAddress: str | None = None


@dataclass
class TONParams:
    contractOpener: ContractOpener | None = None
    settingsAddress: str | None = None


@dataclass
class SDKParams:
    network: Network
    delay: int | None = None
    TACParams: TACParams | None = None
    TONParams: TONParams | None = None
    customLiteSequencerEndpoints: list[str] | None = None
    passLoggerToOpeners: bool | None = None
    artifacts: Any | None = None


class AssetType(str, Enum):
    NFT = "NFT"
    FT = "FT"


class NFTAddressType(str, Enum):
    ITEM = "ITEM"
    COLLECTION = "COLLECTION"


class UserWalletBalanceExists(TypedDict):
    exists: Literal[True]
    amount: float
    rawAmount: int
    decimals: int


class UserWalletBalanceMissing(TypedDict):
    exists: Literal[False]


UserWalletBalanceExtended = Union[UserWalletBalanceExists, UserWalletBalanceMissing]


class EvmProxyMsg(TypedDict):
    evmTargetAddress: str
    methodName: NotRequired[str]
    encodedParameters: NotRequired[str]
    gasLimit: NotRequired[int | None]


class TransactionLinker(TypedDict):
    caller: str
    shardCount: int
    shardsKey: str
    timestamp: int
    sendTransactionResult: Any | None


class TransactionLinkerWithOperationId(TransactionLinker, total=False):
    operationId: str


class TONAsset(TypedDict):
    amount: str
    tokenAddress: str
    assetType: AssetType


class TACCallParams(TypedDict):
    arguments: str
    methodName: str
    target: str


class TACSimulationParams(TypedDict):
    tacCallParams: TACCallParams
    evmValidExecutors: NotRequired[list[str]]
    tvmValidExecutors: NotRequired[list[str]]
    extraData: NotRequired[str]
    shardsKey: str
    tonAssets: list[TONAsset]
    tonCaller: str
    calculateRollbackFee: NotRequired[bool]


class StageName(str, Enum):
    COLLECTED_IN_TAC = "collectedInTAC"
    INCLUDED_IN_TAC_CONSENSUS = "includedInTACConsensus"
    EXECUTED_IN_TAC = "executedInTAC"
    COLLECTED_IN_TON = "collectedInTON"
    INCLUDED_IN_TON_CONSENSUS = "includedInTONConsensus"
    EXECUTED_IN_TON = "executedInTON"


class TransactionData(TypedDict):
    hash: str
    blockchainType: BlockchainType


class NoteInfo(TypedDict):
    content: str
    errorName: str
    internalMsg: str
    internalBytesError: str


class StageData(TypedDict, total=False):
    success: bool
    timestamp: int
    transactions: list[TransactionData] | None
    note: NoteInfo | None


class StatusInfo(StageData, total=False):
    stage: StageName


class ProfilingStageData(TypedDict, total=False):
    exists: bool
    stageData: StageData | None


class InitialCallerInfo(TypedDict):
    address: str
    blockchainType: BlockchainType


class ValidExecutors(TypedDict):
    tac: list[str]
    ton: list[str]


class TokenSymbol(str, Enum):
    TAC_SYMBOL = "TAC"
    TON_SYMBOL = "TON"


class GeneralFeeInfo(TypedDict):
    protocolFee: str
    executorFee: str
    tokenFeeSymbol: TokenSymbol


class AdditionalFeeInfo(TypedDict):
    attachedProtocolFee: str
    tokenFeeSymbol: TokenSymbol


class FeeInfo(TypedDict):
    additionalFeeInfo: AdditionalFeeInfo
    tac: GeneralFeeInfo
    ton: GeneralFeeInfo


class AssetMovement(TypedDict):
    assetType: AssetType
    tvmAddress: str
    evmAddress: str
    amount: str
    tokenId: str | None


class TransactionHash(TypedDict):
    hash: str
    blockchainType: BlockchainType


class AssetMovementInfo(TypedDict):
    caller: InitialCallerInfo
    target: InitialCallerInfo
    transactionHash: TransactionHash
    assetMovements: list[AssetMovement]


class MetaInfo(TypedDict):
    initialCaller: InitialCallerInfo
    validExecutors: ValidExecutors
    feeInfo: FeeInfo
    sentAssets: AssetMovementInfo | None
    receivedAssets: AssetMovementInfo | None


class ExecutionStages(TypedDict, total=False):
    operationType: OperationType
    metaInfo: MetaInfo
    collectedInTAC: ProfilingStageData
    includedInTACConsensus: ProfilingStageData
    executedInTAC: ProfilingStageData
    collectedInTON: ProfilingStageData
    includedInTONConsensus: ProfilingStageData
    executedInTON: ProfilingStageData


ExecutionStagesByOperationId = dict[str, ExecutionStages]
StatusInfosByOperationId = dict[str, StatusInfo]


class OperationIds(TypedDict):
    operationIds: list[str]


OperationIdsByShardsKey = dict[str, OperationIds]


class TACSimulationResult(TypedDict, total=False):
    estimatedGas: int
    feeParams: dict[str, Any]
    message: str
    outMessages: list[dict[str, Any | None]]
    simulationError: str
    simulationStatus: bool
    suggestedTonExecutionFee: str
    suggestedTacExecutionFee: str
    debugInfo: dict[str, Any]


class SuggestedTVMExecutorFee(TypedDict):
    inTAC: str
    inTON: str


class FeeParams(TypedDict, total=False):
    isRoundTrip: bool
    gasLimit: int
    protocolFee: int
    evmExecutorFee: int
    tvmExecutorFee: int
    evmEstimatedGas: int | None


TCell = TypeVar("TCell")


class EvmDataBuilder(Protocol):
    def __call__(
        self,
        transactionLinker: TransactionLinker,
        evmProxyMsg: EvmProxyMsg,
        validExecutors: ValidExecutors,
    ) -> Any:
        ...


class CrossChainTransactionOptions(TypedDict, total=False):
    allowSimulationError: bool
    isRoundTrip: bool
    protocolFee: int
    evmValidExecutors: list[str]
    evmExecutorFee: int
    tvmValidExecutors: list[str]
    tvmExecutorFee: int
    calculateRollbackFee: bool
    withoutSimulation: bool
    validateAssetsBalance: bool
    waitOperationId: bool
    waitOptions: WaitOptions[str, Any]
    evmDataBuilder: EvmDataBuilder


class BatchCrossChainTransactionOptions(TypedDict, total=False):
    allowSimulationError: bool
    isRoundTrip: bool
    protocolFee: int
    evmValidExecutors: list[str]
    evmExecutorFee: int
    tvmValidExecutors: list[str]
    tvmExecutorFee: int
    calculateRollbackFee: bool
    withoutSimulation: bool
    validateAssetsBalance: bool
    waitOperationId: bool
    waitOptions: WaitOptions[str, Any]
    evmDataBuilder: EvmDataBuilder


class CrossChainTransactionsOptions(TypedDict, total=False):
    waitOperationIds: bool
    waitOptions: WaitOptions[OperationIdsByShardsKey, Any]


class ExecutionFeeEstimationResult(TypedDict):
    feeParams: FeeParams
    simulation: TACSimulationResult | None


class CrosschainTx(TypedDict):
    evmProxyMsg: EvmProxyMsg
    assets: list[Asset]
    options: CrossChainTransactionOptions | None


class BatchCrossChainTx(TypedDict):
    evmProxyMsg: EvmProxyMsg
    assets: list[Asset]
    options: BatchCrossChainTransactionOptions | None


AssetLike = Asset | Ft | Nft | dict[str, Any]


class BatchCrossChainTxWithAssetLike(TypedDict):
    evmProxyMsg: EvmProxyMsg
    assets: list[AssetLike]
    options: BatchCrossChainTransactionOptions | None


T = TypeVar("T")
TContext = TypeVar("TContext")


@dataclass
class WaitOptions(Generic[T, TContext]):
    timeout: int | None = None
    maxAttempts: int | None = None
    delay: int | None = None
    logger: ILogger | None = None
    context: TContext | None = None
    successCheck: Callable[[T, TContext | None], bool] | None = None
    onSuccess: Callable[[T, TContext | None], Awaitable[None] | None] | None = None
    ensureTxExecuted: bool | None = None


defaultWaitOptions = WaitOptions(timeout=300000, maxAttempts=30, delay=10000)


class Origin(str, Enum):
    TON = "TON"
    TAC = "TAC"


TVMAddress = str
EVMAddress = str


class AssetFromFTArg(TypedDict):
    address: TVMAddress | EVMAddress
    tokenType: AssetType


class AssetFromNFTCollectionArg(TypedDict):
    address: TVMAddress | EVMAddress
    tokenType: AssetType
    addressType: NFTAddressType
    index: int


class AssetFromNFTItemArg(TypedDict):
    address: TVMAddress
    tokenType: AssetType
    addressType: NFTAddressType


class ConvertCurrencyParams(TypedDict):
    value: int
    currency: CurrencyType


class UsdPriceInfo(TypedDict):
    spot: int
    ema: int
    decimals: int


class ConvertedCurrencyResult(TypedDict):
    spotValue: int
    emaValue: int
    decimals: int
    currency: CurrencyType
    tacPrice: UsdPriceInfo
    tonPrice: UsdPriceInfo


class GetTVMExecutorFeeParams(TypedDict):
    feeSymbol: str
    tonAssets: list[TONAsset]
    tvmValidExecutors: list[str]


class FtOriginAndData(TypedDict, total=False):
    origin: Origin
    jettonMinter: Any
    evmAddress: str | None
    jettonData: Any | None


class CrossChainPayloadResult(TypedDict, total=False):
    body: Any
    destinationAddress: str
    tonAmount: int
    tonNetworkFee: int
    tacEstimatedGas: int | None
    transactionLinker: TransactionLinker


class GeneratePayloadParams(TypedDict, total=False):
    excessReceiver: str
    evmData: Any
    crossChainTonAmount: int
    forwardFeeTonAmount: int
    feeParams: FeeParams


class TACGasPrice(TypedDict):
    average: float
    fast: float
    slow: float


class TrackTransactionTreeParams(TypedDict, total=False):
    limit: int
    maxDepth: int
    maxScannedTransactions: int
    ignoreOpcodeList: list[int]
    direction: Literal["forward", "backward", "both"]
    waitForRootTransaction: bool


class TransactionValidationError(TypedDict):
    txHash: str
    exitCode: int | Literal["N/A"]
    resultCode: int | Literal["N/A"]
    reason: Literal[
        "aborted",
        "compute_phase_missing",
        "compute_phase_failed",
        "action_phase_failed",
        "not_found",
    ]
    address: NotRequired[str]
    hashType: NotRequired[Literal["unknown", "in", "out"]]


class TrackTransactionTreeResult(TypedDict, total=False):
    success: bool
    checkedCount: int
    error: TransactionValidationError | None


class GetTransactionsOptions(TypedDict, total=False):
    limit: int
    lt: str
    hash: str
    to_lt: str
    inclusive: bool
    archival: bool
    timeoutMs: int
    retryDelayMs: int
    maxScannedTransactions: int


class AddressInformation(TypedDict):
    lastTransaction: dict[str, str]
