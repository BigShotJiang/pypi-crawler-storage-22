from __future__ import annotations

import pytest

from assets.asset_cache import AssetCache
from tests.test_helpers import dummy_asset


@pytest.fixture(autouse=True)
def _clear_asset_cache():
    AssetCache.clear()
    yield
    AssetCache.clear()


def test_asset_cache_stores_and_retrieves_by_address():
    token = {"address": "EQTestAddress"}
    asset = dummy_asset(token["address"])

    assert AssetCache.get(token) is None
    AssetCache.set(token, asset)
    assert AssetCache.get(token) is asset


def test_asset_cache_is_case_insensitive_for_address():
    upper = {"address": "AaBbCcDd"}
    lower = {"address": "aabbccdd"}
    asset = dummy_asset(upper["address"])

    AssetCache.set(upper, asset)
    assert AssetCache.get(lower) is asset
    assert AssetCache.get(upper) is asset


def test_asset_cache_distinguishes_by_index():
    base = "EQAddressForCollection"
    token_no_index = {"address": base}
    token_index_0 = {"address": base, "index": 0}
    token_index_1 = {"address": base, "index": 1}
    asset_0 = dummy_asset("item0")
    asset_1 = dummy_asset("item1")

    AssetCache.set(token_index_0, asset_0)
    AssetCache.set(token_index_1, asset_1)

    assert AssetCache.get(token_no_index) is None
    assert AssetCache.get(token_index_0) is asset_0
    assert AssetCache.get(token_index_1) is asset_1


def test_asset_cache_clear_empties_cache():
    token = {"address": "EQAnotherAddress"}
    asset = dummy_asset(token["address"])
    AssetCache.set(token, asset)

    assert AssetCache.get(token) is asset
    AssetCache.clear()
    assert AssetCache.get(token) is None
