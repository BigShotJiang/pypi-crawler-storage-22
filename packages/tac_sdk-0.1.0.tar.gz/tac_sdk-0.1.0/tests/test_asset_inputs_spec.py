from __future__ import annotations

from types import SimpleNamespace
from typing import cast

import pytest

import sdk.utils as utilsModule
from interfaces.i_configuration import IConfiguration
from sdk.utils import normalize_asset, normalize_assets
from structs.struct import AssetLike, AssetType, NFTAddressType, Origin
from tests.test_helpers import dummy_asset


@pytest.fixture
def config_stub():
    return cast(
        IConfiguration,
        SimpleNamespace(
            Network=None,
            artifacts={},
            TONParams={},
            TACParams={},
            liteSequencerEndpoints=[],
            nativeTONAddress="",
        ),
    )


@pytest.fixture
def patch_asset_factory(monkeypatch):
    async def fake_from(config, token):
        _ = config
        token_type = token.get("tokenType")
        address = token.get("address", "")

        if token_type == AssetType.FT:
            if address.startswith("EQNft"):
                raise RuntimeError("Not an ft")
            return dummy_asset(address, asset_type=AssetType.FT, origin=Origin.TON, decimals=9)

        if token_type == AssetType.NFT:
            if token.get("addressType") == NFTAddressType.COLLECTION:
                index = token.get("index")
                return dummy_asset(
                    f"{address}:{index}",
                    asset_type=AssetType.NFT,
                    origin=Origin.TON,
                    decimals=0,
                )
            return dummy_asset(address, asset_type=AssetType.NFT, origin=Origin.TON, decimals=0)

        raise RuntimeError("Unknown token type")

    monkeypatch.setattr(
        utilsModule,
        "_get_asset_factory",
        lambda: SimpleNamespace(from_=fake_from),
    )


@pytest.mark.asyncio
async def test_normalize_asset_supports_all_shapes(config_stub, patch_asset_factory):
    ft_amount = await normalize_asset(config_stub, {"address": "EQft", "amount": 1})
    assert ft_amount.type == AssetType.FT
    assert ft_amount.rawAmount > 0

    ft_raw = await normalize_asset(config_stub, {"address": "EQft", "rawAmount": 1000})
    assert ft_raw.type == AssetType.FT
    assert ft_raw.rawAmount == 1000

    nft_item = await normalize_asset(config_stub, {"address": "EQNftITEM"})
    assert nft_item.type == AssetType.NFT

    nft_collection = await normalize_asset(config_stub, {"address": "EQNftCOLLECTION", "itemIndex": 7})
    assert nft_collection.type == AssetType.NFT
    assert nft_collection.address.endswith(":7")


@pytest.mark.asyncio
async def test_normalize_asset_throws_on_zero_amount_for_ft(config_stub, patch_asset_factory):
    with pytest.raises(Exception, match="zero rawAmount/amount"):
        await normalize_asset(config_stub, {"address": "EQft"})

    with pytest.raises(Exception, match="zero rawAmount/amount"):
        await normalize_asset(config_stub, {"address": "EQft", "amount": 0})

    with pytest.raises(Exception, match="zero rawAmount/amount"):
        await normalize_asset(config_stub, {"address": "EQft", "rawAmount": 0})


@pytest.mark.asyncio
async def test_normalize_asset_returns_same_asset_instance(config_stub, patch_asset_factory):
    existing = dummy_asset("EQExisting", asset_type=AssetType.FT, origin=Origin.TON, raw_amount=123, decimals=9)
    normalized = await normalize_asset(config_stub, existing)
    assert normalized is existing


@pytest.mark.asyncio
async def test_normalize_assets_supports_mixed_inputs_and_empty(config_stub, patch_asset_factory):
    existing = dummy_asset("EQExisting", asset_type=AssetType.FT, origin=Origin.TON, raw_amount=42, decimals=9)
    inputs: list[AssetLike] = [
        existing,
        {"address": "EQft", "amount": 1},
        {"address": "EQft", "rawAmount": 1000},
        {"address": "EQNftITEM"},
        {"address": "EQNftCOLLECTION", "itemIndex": 0},
    ]

    normalized = await normalize_assets(config_stub, inputs)
    assert len(normalized) == len(inputs)
    assert normalized[0] is existing
    assert normalized[1].type == AssetType.FT
    assert normalized[2].rawAmount == 1000
    assert normalized[3].type == AssetType.NFT
    assert normalized[4].type == AssetType.NFT

    assert await normalize_assets(config_stub, []) == []
    assert await normalize_assets(config_stub, None) == []
