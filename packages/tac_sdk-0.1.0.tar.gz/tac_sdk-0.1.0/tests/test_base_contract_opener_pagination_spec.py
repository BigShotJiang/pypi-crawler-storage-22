from __future__ import annotations

import base64
from types import SimpleNamespace
from typing import Any, cast

from pytoniq_core.boc.address import Address
from pytoniq_core.tlb.transaction import Transaction

from adapters.base_contract_opener import base_contract_opener
from structs.struct import AddressInformation, GetTransactionsOptions


class PaginationTestOpener(base_contract_opener):
    def __init__(self, pages: list[list[Transaction]]) -> None:
        super().__init__()
        self.calls: list[GetTransactionsOptions] = []
        self.pages = pages

    def open(self, src: Any) -> Any:
        return src

    async def getContractState(self, address: Any) -> dict[str, Any]:  # noqa: N802
        _ = address
        raise NotImplementedError

    async def getTransactions(self, address: Any, opts: GetTransactionsOptions) -> list[Transaction]:  # noqa: N802
        _ = address
        self.calls.append(opts)
        return self.pages.pop(0) if self.pages else []

    async def getAddressInformation(self, address: Any) -> AddressInformation:  # noqa: N802
        _ = address
        raise NotImplementedError

    async def getConfig(self) -> str:  # noqa: N802
        return ""


def make_tx(hash_byte: int, lt: int, prev_lt: int, prev_hash_hex: str) -> Transaction:
    hash_bytes = bytes([hash_byte]) * 32
    return cast(
        Transaction,
        SimpleNamespace(
            hash=(lambda value=hash_bytes: value),
            lt=lt,
            prev_trans_lt=prev_lt,
            prev_trans_hash=bytes.fromhex(prev_hash_hex),
            in_msg=None,
            out_msgs=[],
            cell=SimpleNamespace(hash=hash_bytes),
        ),
    )


def tx_hash_b64(tx: Transaction) -> str:
    cell_hash = cast(Any, tx).cell.hash
    return base64.b64encode(cell_hash).decode("utf-8")


ADDRESS = Address("EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c")


async def test_scan_passes_32byte_cursor_hash_to_next_page() -> None:
    first_tx = make_tx(1, 100, 123, "bb" * 32)
    second_tx = make_tx(2, 99, 0, "cc" * 32)
    opener = PaginationTestOpener([[first_tx], [second_tx]])
    target_hash = tx_hash_b64(second_tx)

    result = await opener.getTransactionByTxHash(ADDRESS, target_hash, {"limit": 1})

    assert result is second_tx
    assert len(opener.calls) == 2
    second_call_hash = opener.calls[1].get("hash")
    assert second_call_hash is not None
    assert len(base64.b64decode(second_call_hash)) == 32
    assert base64.b64decode(second_call_hash).hex() == "01" * 32


async def test_scan_stops_after_100_transactions() -> None:
    txs: list[Transaction] = []
    for idx in range(101):
        txs.append(make_tx(idx + 1, 1000 - idx, 0, "aa" * 32))

    opener = PaginationTestOpener([txs])
    target_hash = tx_hash_b64(txs[100])

    result = await opener.getTransactionByTxHash(ADDRESS, target_hash, {"limit": 101})

    assert result is None
    assert len(opener.calls) == 1


async def test_scan_supports_custom_max_scanned_transactions() -> None:
    txs: list[Transaction] = []
    for idx in range(101):
        txs.append(make_tx(idx + 1, 2000 - idx, 0, "aa" * 32))

    opener = PaginationTestOpener([txs])
    target_hash = tx_hash_b64(txs[100])

    result = await opener.getTransactionByTxHash(
        ADDRESS,
        target_hash,
        {"limit": 101, "maxScannedTransactions": 101},
    )

    assert result is txs[100]
