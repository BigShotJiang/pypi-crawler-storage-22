from __future__ import annotations

import importlib
from types import SimpleNamespace
from typing import Any, cast

import pytest
from pytoniq_core.boc.address import Address
from pytoniq_core.tlb.transaction import Transaction

from adapters.base_contract_opener import base_contract_opener
from structs.struct import AddressInformation, GetTransactionsOptions

base_contract_opener_module = importlib.import_module("adapters.base_contract_opener")


class RootRetryTestOpener(base_contract_opener):
    def __init__(self) -> None:
        super().__init__()
        self.search_calls = 0
        self.info_calls = 0
        self._address_infos: list[AddressInformation] = []
        self._search_results: list[Transaction | None] = []

    def set_address_infos(self, infos: list[AddressInformation]) -> None:
        self._address_infos = infos

    def set_search_results(self, results: list[Transaction | None]) -> None:
        self._search_results = results

    def open(self, src: Any) -> Any:
        return src

    async def getContractState(self, address: Any) -> dict[str, Any]:  # noqa: N802
        _ = address
        raise NotImplementedError

    async def getTransactions(self, address: Any, opts: GetTransactionsOptions) -> list[Transaction]:  # noqa: N802
        _ = (address, opts)
        return []

    async def getAddressInformation(self, address: Any) -> AddressInformation:  # noqa: N802
        _ = address
        self.info_calls += 1
        if self._address_infos:
            return self._address_infos.pop(0)
        return {"lastTransaction": {"lt": "", "hash": ""}}

    async def getConfig(self) -> str:  # noqa: N802
        return ""

    async def findTransactionByHashType(  # noqa: N802
        self,
        address: Any,
        hash_value: str,
        hash_type: str | None,
        opts: GetTransactionsOptions,
    ) -> Transaction | None:
        _ = (address, hash_value, hash_type, opts)
        self.search_calls += 1
        if self._search_results:
            return self._search_results.pop(0)
        return None


ADDRESS = Address("EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c")


def _dummy_tx() -> Transaction:
    return cast(
        Transaction,
        SimpleNamespace(
            hash=lambda: b"\x11" * 32,
            lt=1,
            prev_trans_lt=0,
            prev_trans_hash=b"\x00" * 32,
            in_msg=None,
            out_msgs=[],
            cell=SimpleNamespace(hash=b"\x11" * 32),
            description=SimpleNamespace(type_="ordinary", aborted=False, compute_ph=None, action=None),
        ),
    )


@pytest.mark.asyncio
async def test_root_retry_captures_baseline_and_searches_immediately(monkeypatch: pytest.MonkeyPatch) -> None:
    async def _no_sleep(_: float) -> None:
        return None

    monkeypatch.setattr(base_contract_opener_module.asyncio, "sleep", _no_sleep)

    opener = RootRetryTestOpener()
    tx = _dummy_tx()
    opener.set_search_results([tx])

    result = await opener.findRootTransactionWithRetry(ADDRESS, "hash", "unknown", 10, 100, True)

    assert result is tx
    assert opener.search_calls == 1
    assert opener.info_calls == 1


@pytest.mark.asyncio
async def test_root_retry_does_not_search_when_lt_unchanged(monkeypatch: pytest.MonkeyPatch) -> None:
    async def _no_sleep(_: float) -> None:
        return None

    monkeypatch.setattr(base_contract_opener_module.asyncio, "sleep", _no_sleep)

    opener = RootRetryTestOpener()
    opener.set_search_results([None])
    opener.set_address_infos([
        {"lastTransaction": {"lt": "100", "hash": ""}},
        *({"lastTransaction": {"lt": "100", "hash": ""}} for _ in range(59)),
    ])

    result = await opener.findRootTransactionWithRetry(ADDRESS, "hash", "unknown", 10, 100, True)

    assert result is None
    assert opener.search_calls == 1
    assert opener.info_calls == 60


@pytest.mark.asyncio
async def test_root_retry_searches_once_after_lt_change(monkeypatch: pytest.MonkeyPatch) -> None:
    async def _no_sleep(_: float) -> None:
        return None

    monkeypatch.setattr(base_contract_opener_module.asyncio, "sleep", _no_sleep)

    opener = RootRetryTestOpener()
    tx = _dummy_tx()
    opener.set_search_results([None, tx])
    opener.set_address_infos([
        {"lastTransaction": {"lt": "100", "hash": ""}},
        {"lastTransaction": {"lt": "100", "hash": ""}},
        {"lastTransaction": {"lt": "100", "hash": ""}},
        {"lastTransaction": {"lt": "101", "hash": ""}},
    ])

    result = await opener.findRootTransactionWithRetry(ADDRESS, "hash", "unknown", 10, 100, True)

    assert result is tx
    assert opener.search_calls == 2
