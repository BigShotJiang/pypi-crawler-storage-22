from __future__ import annotations

from typing import Any

import pytest
from pytoniq_core.boc.address import Address
from pytoniq_core.boc.builder import Builder
from pytoniq_core.boc.cell import Cell
from pytoniq_core.boc.hashmap.hashmap import HashMap

from adapters.base_contract_opener import base_contract_opener
from adapters.retryable_contract_opener import opener_config, retryable_contract_opener
from sdk.configuration import Configuration
from sdk.utils import sha256_to_big_int
from structs.struct import AddressInformation, GetTransactionsOptions, Network, TONParams

SAMPLE_SETTINGS_ADDRESS = "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c"
SAMPLE_CCL_ADDRESS = "EQCQTgXQ99LqwpeYUxDml9DeYTqoqnZEqiTnRyc63Um9RYn5"
SAMPLE_JETTON_PROXY_ADDRESS = "EQDoF2OkxsI3gc5jAuxlqozN9H_SgEOUCopMa1yU4djLaXuL"
SAMPLE_NFT_PROXY_ADDRESS = "EQBLi0v_y-KiLlT1VzQJmmMbaoZnLcMAHrIEmzur13dwOmM1"


class _LoggerStub:
    def debug(self, *args: object) -> None:
        _ = args

    def info(self, *args: object) -> None:
        _ = args

    def warn(self, *args: object) -> None:
        _ = args

    def error(self, *args: object) -> None:
        _ = args


class _SettingsOpener(base_contract_opener):
    def __init__(self, settings_cell: Cell, fail: bool) -> None:
        super().__init__()
        self.settings_cell = settings_cell
        self.fail = fail
        self.calls = 0
        self.opened_contracts: list[str] = []

    def open(self, src: Any) -> Any:
        self.opened_contracts.append(src.__class__.__name__)
        bind_opener = getattr(src, "bind_opener", None)
        if callable(bind_opener):
            return bind_opener(self)
        return src

    async def getContractState(self, address: Any) -> dict[str, Any]:  # noqa: N802
        _ = address
        return {"balance": 0, "state": "active", "code": None}

    async def getTransactions(self, address: Any, opts: GetTransactionsOptions) -> list[Any]:  # noqa: N802
        _ = (address, opts)
        return []

    async def getAddressInformation(self, address: Any) -> AddressInformation:  # noqa: N802
        _ = address
        return {"lastTransaction": {"lt": "", "hash": ""}}

    async def getConfig(self) -> str:  # noqa: N802
        return ""

    def _run_get_method(self, address: Any, method: str, stack: list[Any] | None = None) -> dict[str, Any]:
        _ = (address, stack)
        self.calls += 1
        if method != "get_all":
            raise RuntimeError(f"Unsupported get-method: {method}")
        if self.fail:
            raise TimeoutError("upstream timeout")
        return {"stack": [self.settings_cell]}


def _address_cell(value: str) -> Cell:
    return Builder().store_address(Address(value)).end_cell()


def _settings_cell() -> Cell:
    # TS parity: Dictionary<bigint, Cell> with Dictionary.Values.Cell() stores values as refs.
    data = HashMap(256, value_serializer=lambda src, dest: dest.store_ref(src))
    data.set_int_key(sha256_to_big_int("CrossChainLayerAddress"), _address_cell(SAMPLE_CCL_ADDRESS))
    data.set_int_key(sha256_to_big_int("JettonProxyAddress"), _address_cell(SAMPLE_JETTON_PROXY_ADDRESS))
    data.set_int_key(sha256_to_big_int("NFTProxyAddress"), _address_cell(SAMPLE_NFT_PROXY_ADDRESS))
    data.set_int_key(sha256_to_big_int("JettonMinterCode"), Builder().store_uint(1, 8).end_cell())
    data.set_int_key(sha256_to_big_int("JettonWalletCode"), Builder().store_uint(2, 8).end_cell())
    data.set_int_key(sha256_to_big_int("NFTItemCode"), Builder().store_uint(3, 8).end_cell())
    data.set_int_key(sha256_to_big_int("NFTCollectionCode"), Builder().store_uint(4, 8).end_cell())
    serialized = data.serialize()
    if serialized is None:
        raise RuntimeError("Failed to serialize settings cell for test")
    return serialized


@pytest.mark.asyncio
async def test_prepare_ton_params_uses_get_all_via_wrapper_and_fallback() -> None:
    logger = _LoggerStub()
    settings_cell = _settings_cell()
    failing = _SettingsOpener(settings_cell=settings_cell, fail=True)
    working = _SettingsOpener(settings_cell=settings_cell, fail=False)
    opener = retryable_contract_opener(
        [
            opener_config(opener=failing, retries=0, retryDelay=1),
            opener_config(opener=working, retries=0, retryDelay=1),
        ],
        logger,
    )

    internal = await Configuration._prepare_ton_params(
        Network.TESTNET,
        artifacts={},
        ton_params=TONParams(contractOpener=opener, settingsAddress=SAMPLE_SETTINGS_ADDRESS),
        delay=1,
        logger=logger,
    )

    assert failing.calls >= 1
    assert working.calls >= 1
    assert "Settings" in failing.opened_contracts
    assert "Settings" in working.opened_contracts
    assert internal.get("crossChainLayerAddress") == SAMPLE_CCL_ADDRESS
    assert internal.get("jettonProxyAddress") == SAMPLE_JETTON_PROXY_ADDRESS
    assert internal.get("nftProxyAddress") == SAMPLE_NFT_PROXY_ADDRESS


@pytest.mark.asyncio
async def test_prepare_ton_params_passes_logger_to_opener_by_default() -> None:
    logger = _LoggerStub()
    opener = _SettingsOpener(settings_cell=_settings_cell(), fail=False)

    _ = await Configuration._prepare_ton_params(
        Network.TESTNET,
        artifacts={},
        ton_params=TONParams(contractOpener=opener, settingsAddress=SAMPLE_SETTINGS_ADDRESS),
        delay=1,
        logger=logger,
    )

    assert opener.logger is logger


@pytest.mark.asyncio
async def test_prepare_ton_params_can_skip_passing_logger_to_opener() -> None:
    logger = _LoggerStub()
    opener = _SettingsOpener(settings_cell=_settings_cell(), fail=False)

    _ = await Configuration._prepare_ton_params(
        Network.TESTNET,
        artifacts={},
        ton_params=TONParams(contractOpener=opener, settingsAddress=SAMPLE_SETTINGS_ADDRESS),
        delay=1,
        logger=logger,
        pass_logger_to_openers=False,
    )

    assert opener.logger is None
