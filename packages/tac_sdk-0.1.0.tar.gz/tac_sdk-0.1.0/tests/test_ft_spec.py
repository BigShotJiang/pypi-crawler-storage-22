from __future__ import annotations

from types import SimpleNamespace
from typing import Any, cast

import pytest
from pytoniq_core.boc.address import Address
from pytoniq_core.boc.builder import Builder

from assets.ft import Ft
from interfaces.i_configuration import IConfiguration
from sdk.consts import JETTON_TRANSFER_FORWARD_TON_AMOUNT
from structs.struct import AddressInformation, GetTransactionsOptions, Origin

SAMPLE_TVM_ADDRESS = "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c"
SAMPLE_USER_ADDRESS = "EQCQTgXQ99LqwpeYUxDml9DeYTqoqnZEqiTnRyc63Um9RYn5"
SAMPLE_WALLET_ADDRESS = "EQDoF2OkxsI3gc5jAuxlqozN9H_SgEOUCopMa1yU4djLaXuL"
SAMPLE_EVM_ADDRESS = "0xCf61405b7525F09f4E7501fc831fE7cbCc823d4c"


def _normalize_tvm(value: Any) -> str:
    if isinstance(value, Address):
        address = value
    else:
        raw = str(value)
        if raw.startswith("Address<") and raw.endswith(">"):
            raw = raw[len("Address<") : -1]
        address = Address(raw)
    return address.to_str(is_user_friendly=True, is_url_safe=True, is_bounceable=True, is_test_only=False)


class _FtContractOpenerStub:
    def __init__(self, minter_code_boc: bytes, runtime_code_boc: bytes, wallet_balance: int = 0) -> None:
        self._minter_code_boc = minter_code_boc
        self._runtime_code_boc = runtime_code_boc
        self._wallet_balance = wallet_balance

    def open(self, src: Any) -> Any:
        bind_opener = getattr(src, "bind_opener", None)
        if callable(bind_opener):
            return bind_opener(self)
        return src

    async def getContractState(self, address: Any) -> dict[str, Any]:  # noqa: N802
        if _normalize_tvm(str(address)) == _normalize_tvm(SAMPLE_TVM_ADDRESS):
            return {"balance": 0, "state": "active", "code": self._runtime_code_boc}
        return {"balance": 0, "state": "active", "code": self._minter_code_boc}

    async def getTransactions(self, address: Any, opts: GetTransactionsOptions) -> list[Any]:  # noqa: N802
        _ = (address, opts)
        return []

    async def getAddressInformation(self, address: Any) -> AddressInformation:  # noqa: N802
        _ = address
        return {"lastTransaction": {"lt": "", "hash": ""}}

    async def getConfig(self) -> str:  # noqa: N802
        return ""

    def _run_get_method(self, address: Any, method: str, stack: list[Any] | None = None) -> dict[str, Any]:
        address_key = _normalize_tvm(str(address))
        _ = stack
        if address_key == _normalize_tvm(SAMPLE_TVM_ADDRESS) and method == "get_jetton_data":
            return {
                "stack": [
                    1000,
                    1,
                    Address(SAMPLE_USER_ADDRESS),
                    Builder().end_cell(),
                    Builder().store_uint(1, 8).end_cell(),
                ]
            }
        if address_key == _normalize_tvm(SAMPLE_TVM_ADDRESS) and method in (
            "get_evm_token_address",
            "get_evm_token_addr",
        ):
            return {"stack": [SAMPLE_EVM_ADDRESS]}
        if address_key == _normalize_tvm(SAMPLE_TVM_ADDRESS) and method == "get_wallet_address":
            return {"stack": [Address(SAMPLE_WALLET_ADDRESS)]}
        if address_key == _normalize_tvm(SAMPLE_WALLET_ADDRESS) and method == "get_wallet_data":
            return {
                "stack": [
                    self._wallet_balance,
                    Address(SAMPLE_USER_ADDRESS),
                    Address(SAMPLE_TVM_ADDRESS),
                    Builder().end_cell(),
                ]
            }
        raise RuntimeError(f"unsupported call {method} on {address_key}")


@pytest.mark.asyncio
async def test_get_origin_and_data_returns_ton_shape() -> None:
    runtime_code = Builder().store_uint(1, 8).end_cell()
    expected_jetton_minter_code = Builder().store_uint(2, 8).end_cell()
    opener = _FtContractOpenerStub(expected_jetton_minter_code.to_boc(), runtime_code.to_boc())

    config = cast(
        IConfiguration,
        SimpleNamespace(
            network=None,
            artifacts={},
            TONParams={
                "contractOpener": opener,
                "jettonMinterCode": expected_jetton_minter_code,
            },
            TACParams={},
            liteSequencerEndpoints=[],
            nativeTONAddress="NONE",
        ),
    )

    result = await Ft.getOriginAndData(config, SAMPLE_TVM_ADDRESS)

    assert result.get("origin") == Origin.TON
    assert result.get("jettonData") is not None
    assert result.get("evmAddress") is None


@pytest.mark.asyncio
async def test_get_origin_and_data_returns_tac_shape_and_wallet_balance_uses_wallet_wrapper(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runtime_code = Builder().store_uint(7, 8).end_cell()
    wallet_code = Builder().store_uint(9, 8).end_cell()
    opener = _FtContractOpenerStub(runtime_code.to_boc(), runtime_code.to_boc(), wallet_balance=1234)
    monkeypatch.setattr("assets.ft.calculate_contract_address", lambda _code, _data: Address(SAMPLE_TVM_ADDRESS))

    config = cast(
        IConfiguration,
        SimpleNamespace(
            network=None,
            artifacts={},
            TONParams={
                "contractOpener": opener,
                "jettonMinterCode": runtime_code,
                "crossChainLayerAddress": SAMPLE_USER_ADDRESS,
                "jettonWalletCode": wallet_code,
            },
            TACParams={},
            liteSequencerEndpoints=[],
            nativeTONAddress="NONE",
        ),
    )

    result = await Ft.getOriginAndData(config, SAMPLE_TVM_ADDRESS)
    assert result.get("origin") == Origin.TAC
    assert result.get("evmAddress") == SAMPLE_EVM_ADDRESS

    token = Ft(SAMPLE_TVM_ADDRESS, Origin.TON, config, decimals=9)
    assert await token.getUserWalletAddress(SAMPLE_USER_ADDRESS) == _normalize_tvm(SAMPLE_WALLET_ADDRESS)
    assert await token.getBalanceOf(SAMPLE_USER_ADDRESS) == 1234


def test_ft_generate_payload_transfer_and_burn_match_js_layout() -> None:
    config = cast(
        IConfiguration,
        SimpleNamespace(
            network=None,
            artifacts={},
            TONParams={
                "crossChainLayerAddress": SAMPLE_USER_ADDRESS,
                "jettonProxyAddress": SAMPLE_WALLET_ADDRESS,
            },
            TACParams={},
            liteSequencerEndpoints=[],
            nativeTONAddress="NONE",
        ),
    )

    evm_data = Builder().store_uint(1, 8).end_cell()

    transfer_asset = cast(Ft, Ft(SAMPLE_TVM_ADDRESS, Origin.TON, config, decimals=9).withRawAmount(123))
    transfer_payload = transfer_asset.generatePayload(
        {
            "excessReceiver": SAMPLE_USER_ADDRESS,
            "evmData": evm_data,
            "crossChainTonAmount": 7,
            "forwardFeeTonAmount": 11,
        }
    )
    transfer_slice = transfer_payload.begin_parse()
    assert transfer_slice.load_uint(32) == 0x0F8A7EA5
    _ = transfer_slice.load_uint(64)  # query id
    assert transfer_slice.load_coins() == 123
    assert _normalize_tvm(transfer_slice.load_address()) == _normalize_tvm(SAMPLE_WALLET_ADDRESS)
    assert _normalize_tvm(transfer_slice.load_address()) == _normalize_tvm(SAMPLE_USER_ADDRESS)
    assert transfer_slice.load_bit() == 0  # custom payload
    assert transfer_slice.load_coins() == JETTON_TRANSFER_FORWARD_TON_AMOUNT + 11 + 7
    assert transfer_slice.load_bit() == 1
    transfer_forward_slice = transfer_slice.load_ref().begin_parse()
    assert transfer_forward_slice.load_coins() == 7
    assert transfer_forward_slice.load_bit() == 0  # feeData
    assert transfer_forward_slice.load_bit() == 1  # evmData

    burn_asset = cast(Ft, Ft(SAMPLE_TVM_ADDRESS, Origin.TAC, config, decimals=9).withRawAmount(321))
    burn_payload = burn_asset.generatePayload(
        {
            "evmData": evm_data,
            "crossChainTonAmount": 9,
        }
    )
    burn_slice = burn_payload.begin_parse()
    assert burn_slice.load_uint(32) == 0x595F07BC
    _ = burn_slice.load_uint(64)  # query id
    assert burn_slice.load_coins() == 321
    assert _normalize_tvm(burn_slice.load_address()) == _normalize_tvm(SAMPLE_USER_ADDRESS)
    assert burn_slice.load_bit() == 1  # custom payload exists
    burn_custom_slice = burn_slice.load_ref().begin_parse()
    assert burn_custom_slice.load_coins() == 9
    assert burn_custom_slice.load_bit() == 0  # feeData
    assert burn_custom_slice.load_bit() == 1  # evmData

    burn_payload_without_crosschain = burn_asset.generatePayload(
        {
            "evmData": None,
            "crossChainTonAmount": 0,
        }
    )
    burn_without_crosschain_slice = burn_payload_without_crosschain.begin_parse()
    _ = burn_without_crosschain_slice.load_uint(32)
    _ = burn_without_crosschain_slice.load_uint(64)
    _ = burn_without_crosschain_slice.load_coins()
    _ = burn_without_crosschain_slice.load_address()
    assert burn_without_crosschain_slice.load_bit() == 0
