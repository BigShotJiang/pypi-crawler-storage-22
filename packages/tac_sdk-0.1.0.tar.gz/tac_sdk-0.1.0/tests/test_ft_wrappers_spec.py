from __future__ import annotations

from types import SimpleNamespace
from typing import Any, cast

import pytest
from pytoniq_core.boc.address import Address
from pytoniq_core.boc.builder import Builder

from assets.ft import Ft
from interfaces.i_configuration import IConfiguration
from structs.struct import Origin
from wrappers.jetton_minter import JettonMinter
from wrappers.jetton_wallet import JettonWallet

MINTER_ADDRESS = "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c"
WALLET_ADDRESS = "EQDoF2OkxsI3gc5jAuxlqozN9H_SgEOUCopMa1yU4djLaXuL"
OWNER_ADDRESS = "EQCQTgXQ99LqwpeYUxDml9DeYTqoqnZEqiTnRyc63Um9RYn5"
MASTER_ADDRESS = "EQBLi0v_y-KiLlT1VzQJmmMbaoZnLcMAHrIEmzur13dwOmM1"


def _normalize_tvm(value: Any) -> str:
    if isinstance(value, Address):
        address = value
    else:
        text = str(value)
        if text.startswith("Address<") and text.endswith(">"):
            text = text[len("Address<") : -1]
        address = Address(text)
    return address.to_str(is_user_friendly=True, is_url_safe=True, is_bounceable=True, is_test_only=False)


class _FtOpenerStub:
    def __init__(self, balance: int) -> None:
        self.balance = balance

    def open(self, src: Any) -> Any:
        bind_opener = getattr(src, "bind_opener", None)
        if callable(bind_opener):
            return bind_opener(self)
        return src

    def _run_get_method(self, address: Any, method: str, stack: list[Any] | None = None) -> dict[str, Any]:
        address_key = _normalize_tvm(address)
        _ = stack
        if address_key == _normalize_tvm(MINTER_ADDRESS) and method == "get_jetton_data":
            return {
                "stack": [
                    777,
                    1,
                    Address(OWNER_ADDRESS),
                    Builder().end_cell(),
                    Builder().store_uint(11, 8).end_cell(),
                ]
            }
        if address_key == _normalize_tvm(MINTER_ADDRESS) and method == "get_wallet_address":
            return {"stack": [Address(WALLET_ADDRESS)]}
        if address_key == _normalize_tvm(MINTER_ADDRESS) and method in (
            "get_evm_token_address",
            "get_evm_token_addr",
        ):
            return {"stack": ["0xCf61405b7525F09f4E7501fc831fE7cbCc823d4c"]}
        if address_key == _normalize_tvm(WALLET_ADDRESS) and method == "get_wallet_data":
            return {
                "stack": [
                    self.balance,
                    Address(OWNER_ADDRESS),
                    Address(MASTER_ADDRESS),
                    Builder().store_uint(12, 8).end_cell(),
                ]
            }
        raise RuntimeError(f"unsupported call {method} for {address_key}")

    async def getContractState(self, address: Any) -> dict[str, Any]:  # noqa: N802
        _ = address
        return {"balance": 0, "state": "active", "code": None}


def _config(opener: Any) -> IConfiguration:
    return cast(
        IConfiguration,
        SimpleNamespace(
            network=None,
            artifacts={},
            TONParams={"contractOpener": opener},
            TACParams={},
            liteSequencerEndpoints=[],
            nativeTONAddress="NONE",
        ),
    )


@pytest.mark.asyncio
async def test_jetton_wrappers_parse_get_methods() -> None:
    opener = _FtOpenerStub(balance=321)
    minter = opener.open(JettonMinter.createFromAddress(Address(MINTER_ADDRESS)))
    wallet = opener.open(JettonWallet.createFromAddress(Address(WALLET_ADDRESS)))

    jetton_data = await minter.getJettonData()
    wallet_address = await minter.getWalletAddress(Address(OWNER_ADDRESS))
    wallet_balance = await wallet.getJettonBalance()
    wallet_data = await wallet.getWalletData()

    assert jetton_data["totalSupply"] == 777
    assert _normalize_tvm(wallet_address) == _normalize_tvm(WALLET_ADDRESS)
    assert wallet_balance == 321
    assert wallet_data["ownerAddress"] == _normalize_tvm(OWNER_ADDRESS)
    assert wallet_data["jettonMasterAddress"] == _normalize_tvm(MASTER_ADDRESS)


@pytest.mark.asyncio
async def test_ft_balance_checks_use_jetton_wallet() -> None:
    opener = _FtOpenerStub(balance=10)
    token = Ft(MINTER_ADDRESS, origin=Origin.TON, configuration=_config(opener), decimals=9)

    assert await token.getBalanceOf(OWNER_ADDRESS) == 10
    assert await token.getUserWalletAddress(OWNER_ADDRESS) == _normalize_tvm(WALLET_ADDRESS)
