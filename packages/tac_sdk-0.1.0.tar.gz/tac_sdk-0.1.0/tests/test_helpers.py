from __future__ import annotations

from assets._base import BaseAsset
import pytest
from interfaces.asset import Asset
from interfaces.contract_opener import ContractOpener
from sdk.utils import wait_until_success
from structs.internal_struct import SendResult, ShardTransaction
from structs.struct import AssetType, Network, Origin, WaitOptions


class DummyAsset(BaseAsset):
    def __init__(
        self,
        address: str,
        *,
        asset_type: AssetType = AssetType.FT,
        origin: Origin = Origin.TON,
        raw_amount: int = 0,
        decimals: int = 9,
    ) -> None:
        super().__init__(
            address=address,
            type=asset_type,
            origin=origin,
            rawAmount=raw_amount,
            decimals=decimals,
        )

    @staticmethod
    def _calculate_raw(amount: float, decimals: int) -> int:
        integer_part, _, fractional_part = f"{amount}".partition(".")
        padded_fraction = (fractional_part or "").ljust(decimals, "0")[:decimals]
        return int(f"{integer_part}{padded_fraction}" or "0")

    @property
    def clone(self) -> dummy_asset:
        return dummy_asset(
            self.address,
            asset_type=self.type,
            origin=self.origin,
            raw_amount=self.rawAmount,
            decimals=self.decimals,
        )

    def withAmount(self, amount: float) -> dummy_asset:
        return dummy_asset(
            self.address,
            asset_type=self.type,
            origin=self.origin,
            raw_amount=self._calculate_raw(amount, self.decimals),
            decimals=self.decimals,
        )

    def withRawAmount(self, rawAmount: int) -> dummy_asset:
        return dummy_asset(
            self.address,
            asset_type=self.type,
            origin=self.origin,
            raw_amount=int(rawAmount),
            decimals=self.decimals,
        )

    def addAmount(self, amount: float) -> dummy_asset:
        return dummy_asset(
            self.address,
            asset_type=self.type,
            origin=self.origin,
            raw_amount=self.rawAmount + self._calculate_raw(amount, self.decimals),
            decimals=self.decimals,
        )

    def addRawAmount(self, rawAmount: int) -> dummy_asset:
        return dummy_asset(
            self.address,
            asset_type=self.type,
            origin=self.origin,
            raw_amount=self.rawAmount + int(rawAmount),
            decimals=self.decimals,
        )

    async def getEVMAddress(self) -> str:  # noqa: N802
        return self.address

    async def getTVMAddress(self) -> str:  # noqa: N802
        return self.address

    def generatePayload(self, params: object) -> object:  # noqa: N802
        return {"params": params}

    async def checkCanBeTransferredBy(self, userAddress: str) -> None:  # noqa: N802
        _ = userAddress
        return None

    async def getBalanceOf(self, userAddress: str) -> int:  # noqa: N802
        _ = userAddress
        return self.rawAmount


class SenderStub:
    def __init__(self, address: str):
        self._address = address

    def getSenderAddress(self) -> str:  # noqa: N802
        return self._address

    async def sendShardTransaction(  # noqa: N802
        self,
        shardTransaction: ShardTransaction,
        chain: Network | None = None,
        contractOpener: ContractOpener | None = None,
    ) -> SendResult:
        _ = (shardTransaction, chain, contractOpener)
        return SendResult(success=True, boc="", result={})

    async def sendShardTransactions(  # noqa: N802
        self,
        shardTransactions: list[ShardTransaction],
        chain: Network | None = None,
        contractOpener: ContractOpener | None = None,
    ) -> list[SendResult]:
        _ = (shardTransactions, chain, contractOpener)
        return [SendResult(success=True, boc="", result={})]

    async def getBalance(  # noqa: N802
        self,
        contractOpener: ContractOpener,
    ) -> int:
        _ = contractOpener
        return 0

    async def getBalanceOf(self, asset: Asset) -> int:  # noqa: N802
        _ = asset
        return 0

dummy_asset = DummyAsset
sender_stub = SenderStub


class _MemoryLogger:
    def __init__(self) -> None:
        self.debug_logs: list[str] = []
        self.warn_logs: list[str] = []
        self.error_logs: list[str] = []

    def debug(self, message: str) -> None:
        self.debug_logs.append(message)

    def warn(self, message: str) -> None:
        self.warn_logs.append(message)

    def error(self, message: str) -> None:
        self.error_logs.append(message)

    def info(self, message: str) -> None:
        _ = message


@pytest.mark.asyncio
async def test_wait_until_success_logs_pending_one_liner_for_status_payload() -> None:
    logger = _MemoryLogger()
    status = {
        "stage": "includedInTONConsensus",
        "success": True,
        "timestamp": 1770894966,
        "transactions": [{"hash": "0x69d97176890b6968837c20ff9fff36d8791e5108cb0a8bb366da13db6bd556ab"}],
    }

    async def _op() -> dict:
        return status

    with pytest.raises(RuntimeError):
        await wait_until_success(
            WaitOptions[dict, None](
                timeout=100,
                maxAttempts=2,
                delay=1,
                logger=logger,
                successCheck=lambda result, _: result.get("stage") == "executedInTON",
            ),
            _op,
            "OperationTracker: Getting operation status",
        )

    pending_logs = [line for line in logger.debug_logs if " pending attempt=" in line]
    assert len(pending_logs) == 1
    assert "stage=includedInTONConsensus" in pending_logs[0]
    assert "success=true" in pending_logs[0]
    assert "tx=0x69d97176890b6968837c20ff9fff36d8791e5108cb0a8bb366da13db6bd556ab" in pending_logs[0]
    assert "retry_in=1ms" in pending_logs[0]
    assert '"transactions"' not in pending_logs[0]


@pytest.mark.asyncio
async def test_wait_until_success_keeps_generic_one_liner_for_non_status_payload() -> None:
    logger = _MemoryLogger()

    async def _op() -> dict:
        return {"foo": "bar"}

    with pytest.raises(RuntimeError):
        await wait_until_success(
            WaitOptions[dict, None](
                timeout=100,
                maxAttempts=2,
                delay=1,
                logger=logger,
                successCheck=lambda _result, _: False,
            ),
            _op,
            "Any operation",
        )

    generic_logs = [line for line in logger.debug_logs if "attempt=1/2 failed; retry_in=1ms; error=" in line]
    assert len(generic_logs) == 1
    assert "pending attempt=" not in generic_logs[0]
