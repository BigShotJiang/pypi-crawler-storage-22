from __future__ import annotations

from types import SimpleNamespace
from typing import Any, cast

import pytest
from pytoniq_core.boc.address import Address
from pytoniq_core.boc.builder import Builder

from assets.nft import Nft
from interfaces.i_configuration import IConfiguration
from sdk.consts import NFT_TRANSFER_FORWARD_TON_AMOUNT
from structs.struct import Origin
from wrappers.nft_collection import NftCollection
from wrappers.nft_item import NftItem

ITEM_ADDRESS = "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c"
COLLECTION_ADDRESS = "EQDoF2OkxsI3gc5jAuxlqozN9H_SgEOUCopMa1yU4djLaXuL"
OWNER_ADDRESS = "EQCQTgXQ99LqwpeYUxDml9DeYTqoqnZEqiTnRyc63Um9RYn5"
ORIGINAL_EVM_ADDRESS = "0xCf61405b7525F09f4E7501fc831fE7cbCc823d4c"


def _normalize_tvm(value: Any) -> str:
    if isinstance(value, Address):
        address = value
    else:
        text = str(value)
        if text.startswith("Address<") and text.endswith(">"):
            text = text[len("Address<") : -1]
        address = Address(text)
    return address.to_str(is_user_friendly=True, is_url_safe=True, is_bounceable=True, is_test_only=False)


class _TokenUtilsStub:
    async def computeAddressERC721(self, address: str) -> str:  # noqa: N802
        return f"computed:{address}"

    async def exists(self, address: str) -> bool:
        _ = address
        return False


class _NftOpenerStub:
    def __init__(self) -> None:
        self.item_code = Builder().store_uint(1, 8).end_cell()
        self.collection_code = Builder().store_uint(2, 8).end_cell()

    def open(self, src: Any) -> Any:
        bind_opener = getattr(src, "bind_opener", None)
        if callable(bind_opener):
            return bind_opener(self)
        return src

    def _run_get_method(self, address: Any, method: str, stack: list[Any] | None = None) -> dict[str, Any]:
        address_key = _normalize_tvm(address)
        _ = stack
        if address_key == _normalize_tvm(ITEM_ADDRESS) and method == "get_nft_data":
            return {
                "stack": [
                    1,
                    7,
                    Address(COLLECTION_ADDRESS),
                    Address(OWNER_ADDRESS),
                    Builder().store_uint(99, 8).end_cell(),
                ]
            }
        if address_key == _normalize_tvm(COLLECTION_ADDRESS) and method == "get_collection_data":
            return {
                "stack": [
                    8,
                    Builder().store_uint(77, 8).end_cell(),
                    Address(OWNER_ADDRESS),
                ]
            }
        if address_key == _normalize_tvm(COLLECTION_ADDRESS) and method == "get_nft_address_by_index":
            return {"stack": [Address(ITEM_ADDRESS)]}
        if address_key == _normalize_tvm(COLLECTION_ADDRESS) and method == "get_original_address":
            return {"stack": [ORIGINAL_EVM_ADDRESS]}
        raise RuntimeError(f"unsupported call {method} for {address_key}")

    async def getContractState(self, address: Any) -> dict[str, Any]:  # noqa: N802
        address_key = _normalize_tvm(address)
        if address_key == _normalize_tvm(ITEM_ADDRESS):
            return {"balance": 0, "state": "active", "code": self.item_code.to_boc()}
        if address_key == _normalize_tvm(COLLECTION_ADDRESS):
            return {"balance": 0, "state": "active", "code": self.collection_code.to_boc()}
        return {"balance": 0, "state": "active", "code": None}


def _config(opener: _NftOpenerStub) -> IConfiguration:
    return cast(
        IConfiguration,
        SimpleNamespace(
            network=None,
            artifacts={},
            TONParams={
                "contractOpener": opener,
                "nftItemCode": opener.item_code,
                "nftCollectionCode": opener.collection_code,
                "crossChainLayerAddress": OWNER_ADDRESS,
            },
            TACParams={"tokenUtils": _TokenUtilsStub()},
            liteSequencerEndpoints=[],
            nativeTONAddress="NONE",
        ),
    )


@pytest.mark.asyncio
async def test_nft_wrappers_parse_get_methods() -> None:
    opener = _NftOpenerStub()
    nft_item = opener.open(NftItem.createFromAddress(Address(ITEM_ADDRESS)))
    nft_collection = opener.open(NftCollection.createFromAddress(Address(COLLECTION_ADDRESS)))

    item_data = await nft_item.getNFTData()
    collection_data = await nft_collection.getCollectionData()
    item_address = await nft_collection.getNFTAddressByIndex(7)
    original_address = await nft_collection.getOriginalAddress()

    assert int(item_data["index"]) == 7
    assert _normalize_tvm(item_data["collectionAddress"]) == _normalize_tvm(COLLECTION_ADDRESS)
    assert int(collection_data["nextIndex"]) == 8
    assert _normalize_tvm(item_address) == _normalize_tvm(ITEM_ADDRESS)
    assert original_address == ORIGINAL_EVM_ADDRESS


@pytest.mark.asyncio
async def test_nft_asset_uses_wrappers_and_original_address_resolution() -> None:
    opener = _NftOpenerStub()
    configuration = _config(opener)

    nft = await Nft.fromItem(configuration, ITEM_ADDRESS)
    assert nft.addresses["collection"] == _normalize_tvm(COLLECTION_ADDRESS)
    assert int(nft.addresses["index"]) == 7
    assert await nft.getItemData()
    assert await nft.getCollectionData()
    assert await Nft.getItemAddress(configuration, COLLECTION_ADDRESS, 7) == _normalize_tvm(ITEM_ADDRESS)

    evm_address = await nft.getEVMAddress()
    assert evm_address == ORIGINAL_EVM_ADDRESS


def test_nft_generate_payload_transfer_and_burn_match_js_layout() -> None:
    opener = _NftOpenerStub()
    configuration = _config(opener)
    configuration.TONParams["nftProxyAddress"] = COLLECTION_ADDRESS

    evm_data = Builder().store_uint(2, 8).end_cell()

    nft_transfer = Nft({"item": ITEM_ADDRESS}, Origin.TON, configuration)
    transfer_payload = nft_transfer.generatePayload(
        {
            "excessReceiver": OWNER_ADDRESS,
            "evmData": evm_data,
            "crossChainTonAmount": 13,
            "forwardFeeTonAmount": 17,
        }
    )
    transfer_slice = transfer_payload.begin_parse()
    assert transfer_slice.load_uint(32) == 0x5FCC3D14
    _ = transfer_slice.load_uint(64)  # query id
    assert _normalize_tvm(transfer_slice.load_address()) == _normalize_tvm(COLLECTION_ADDRESS)
    assert _normalize_tvm(transfer_slice.load_address()) == _normalize_tvm(OWNER_ADDRESS)
    assert transfer_slice.load_bit() == 0  # custom payload
    assert transfer_slice.load_coins() == NFT_TRANSFER_FORWARD_TON_AMOUNT + 17 + 13
    assert transfer_slice.load_bit() == 1
    transfer_forward_slice = transfer_slice.load_ref().begin_parse()
    assert transfer_forward_slice.load_coins() == 13
    assert transfer_forward_slice.load_bit() == 0  # feeData
    assert transfer_forward_slice.load_bit() == 1  # evmData

    nft_burn = Nft({"item": ITEM_ADDRESS}, Origin.TAC, configuration)
    burn_payload = nft_burn.generatePayload(
        {
            "evmData": evm_data,
            "crossChainTonAmount": 21,
        }
    )
    burn_slice = burn_payload.begin_parse()
    assert burn_slice.load_uint(32) == 0x03B390CE
    _ = burn_slice.load_uint(64)  # query id
    assert _normalize_tvm(burn_slice.load_address()) == _normalize_tvm(OWNER_ADDRESS)
    assert burn_slice.load_bit() == 1
    burn_custom_slice = burn_slice.load_ref().begin_parse()
    assert burn_custom_slice.load_coins() == 21
    assert burn_custom_slice.load_bit() == 0  # feeData
    assert burn_custom_slice.load_bit() == 1  # evmData
