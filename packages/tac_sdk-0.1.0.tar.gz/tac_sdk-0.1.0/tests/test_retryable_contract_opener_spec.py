from __future__ import annotations

import importlib
import inspect
import time
from collections.abc import Awaitable
from typing import Any, Callable

import pytest

from adapters.base_contract_opener import base_contract_opener
from adapters.retryable_contract_opener import (
    create_default_retryable_opener,
    opener_config,
    retryable_contract_opener,
)
from structs.struct import AddressInformation, GetTransactionsOptions, Network

retryable_module = importlib.import_module("adapters.retryable_contract_opener")


class _LoggerStub:
    def debug(self, *args: object) -> None:
        _ = args

    def info(self, *args: object) -> None:
        _ = args

    def warn(self, *args: object) -> None:
        _ = args

    def error(self, *args: object) -> None:
        _ = args


class _WalletContractStub:
    async def getJettonBalance(self) -> int:  # noqa: N802
        return 1000

    async def getWalletData(self) -> dict[str, int]:  # noqa: N802
        return {"balance": 1000}


class _UnstableContractProxy:
    def __init__(self, opener: _UnstableContractOpener, contract: Any) -> None:
        self._opener = opener
        self._contract = contract

    def __getattr__(self, item: str) -> Any:
        value = getattr(self._contract, item)
        if not callable(value):
            return value

        async def _wrapped(*args: Any, **kwargs: Any) -> Any:
            return await self._opener._execute(item, lambda: value(*args, **kwargs))

        return _wrapped


class _UnstableContractOpener(base_contract_opener):
    def __init__(self, name: str, fails_before_success: int = 0) -> None:
        super().__init__()
        self.name = name
        self.fails_before_success = fails_before_success
        self.call_counts: dict[str, int] = {}
        self.client = object()

    async def _execute(self, method: str, operation: Callable[[], Any | Awaitable[Any]]) -> Any:
        key = f"{self.name}-{method}"
        current_count = self.call_counts.get(key, 0) + 1
        self.call_counts[key] = current_count

        if current_count <= self.fails_before_success:
            raise RuntimeError(
                f"{self.name}: Simulated network failure for {method} (attempt {current_count})"
            )

        self.call_counts[key] = 0
        result = operation()
        if inspect.isawaitable(result):
            return await result
        return result

    def open(self, src: Any) -> Any:
        return _UnstableContractProxy(self, src)

    async def getContractState(self, address: Any) -> dict[str, Any]:  # noqa: N802
        _ = address
        return await self._execute(
            "getContractState",
            lambda: {"balance": 0, "state": "active", "code": b"1"},
        )

    async def getTransactions(self, address: Any, opts: GetTransactionsOptions) -> list[Any]:  # noqa: N802
        _ = (address, opts)
        return await self._execute("getTransactions", lambda: [])

    async def getAddressInformation(self, address: Any) -> AddressInformation:  # noqa: N802
        _ = address
        return await self._execute(
            "getAddressInformation",
            lambda: {"lastTransaction": {"lt": "", "hash": ""}},
        )

    async def getConfig(self) -> str:  # noqa: N802
        return await self._execute("getConfig", lambda: "")


@pytest.mark.asyncio
async def test_multiple_sequential_calls_use_fallback_and_retry_delay() -> None:
    unstable_opener_1 = _UnstableContractOpener("RPC1", 10)
    unstable_opener_2 = _UnstableContractOpener("RPC2", 3)
    stable_opener = _UnstableContractOpener("RPC3", 0)

    retryable_opener = retryable_contract_opener(
        [
            opener_config(opener=unstable_opener_1, retries=2, retryDelay=40),
            opener_config(opener=unstable_opener_2, retries=2, retryDelay=40),
            opener_config(opener=stable_opener, retries=1, retryDelay=5),
        ]
    )

    contract = retryable_opener.open(_WalletContractStub())
    start = time.monotonic()
    balance = await contract.getJettonBalance()
    elapsed_ms = (time.monotonic() - start) * 1000

    assert balance == 1000
    assert elapsed_ms >= 160
    assert unstable_opener_1.call_counts["RPC1-getJettonBalance"] == 3
    assert unstable_opener_2.call_counts["RPC2-getJettonBalance"] == 3
    assert stable_opener.call_counts["RPC3-getJettonBalance"] == 0


@pytest.mark.asyncio
async def test_each_contract_method_restarts_from_first_opener() -> None:
    unstable_opener_1 = _UnstableContractOpener("RPC1", 10)
    unstable_opener_2 = _UnstableContractOpener("RPC2", 10)
    unstable_opener_3 = _UnstableContractOpener("RPC3", 10)
    stable_opener = _UnstableContractOpener("RPC4", 0)

    retryable_opener = retryable_contract_opener(
        [
            opener_config(opener=unstable_opener_1, retries=2, retryDelay=1),
            opener_config(opener=unstable_opener_2, retries=2, retryDelay=1),
            opener_config(opener=unstable_opener_3, retries=2, retryDelay=1),
            opener_config(opener=stable_opener, retries=1, retryDelay=1),
        ]
    )
    contract = retryable_opener.open(_WalletContractStub())

    await contract.getJettonBalance()
    assert unstable_opener_1.call_counts["RPC1-getJettonBalance"] == 3
    assert unstable_opener_2.call_counts["RPC2-getJettonBalance"] == 3
    assert unstable_opener_3.call_counts["RPC3-getJettonBalance"] == 3
    assert stable_opener.call_counts["RPC4-getJettonBalance"] == 0

    await contract.getWalletData()
    assert unstable_opener_1.call_counts["RPC1-getWalletData"] == 3
    assert unstable_opener_2.call_counts["RPC2-getWalletData"] == 3
    assert unstable_opener_3.call_counts["RPC3-getWalletData"] == 3
    assert stable_opener.call_counts["RPC4-getWalletData"] == 0


@pytest.mark.asyncio
async def test_raises_when_all_openers_fail() -> None:
    failing_opener_1 = _UnstableContractOpener("RPC1", 10)
    failing_opener_2 = _UnstableContractOpener("RPC2", 10)
    failing_opener_3 = _UnstableContractOpener("RPC3", 10)

    retryable_opener = retryable_contract_opener(
        [
            opener_config(opener=failing_opener_1, retries=3, retryDelay=1),
            opener_config(opener=failing_opener_2, retries=3, retryDelay=1),
            opener_config(opener=failing_opener_3, retries=3, retryDelay=1),
        ]
    )

    contract = retryable_opener.open(_WalletContractStub())

    with pytest.raises(RuntimeError):
        await contract.getJettonBalance()

    assert failing_opener_1.call_counts["RPC1-getJettonBalance"] == 4
    assert failing_opener_2.call_counts["RPC2-getJettonBalance"] == 4
    assert failing_opener_3.call_counts["RPC3-getJettonBalance"] == 4

_wallet_contract_stub = _WalletContractStub
_unstable_contract_proxy = _UnstableContractProxy
_unstable_contract_opener = _UnstableContractOpener


class _TrackTreeFlakyOpener(base_contract_opener):
    def __init__(self, fail_count: int) -> None:
        super().__init__()
        self.fail_count = fail_count
        self.calls = 0

    def open(self, src: Any) -> Any:
        return src

    async def getContractState(self, address: Any) -> dict[str, Any]:  # noqa: N802
        _ = address
        return {"balance": 0, "state": "active", "code": None}

    async def getTransactions(self, address: Any, opts: GetTransactionsOptions) -> list[Any]:  # noqa: N802
        _ = (address, opts)
        return []

    async def getAddressInformation(self, address: Any) -> AddressInformation:  # noqa: N802
        _ = address
        return {"lastTransaction": {"lt": "", "hash": ""}}

    async def getConfig(self) -> str:  # noqa: N802
        return ""

    async def trackTransactionTree(self, address: str, hash_value: str, params: Any | None = None) -> None:  # noqa: N802
        _ = (address, hash_value, params)
        self.calls += 1
        if self.calls <= self.fail_count:
            raise RuntimeError("Toncenter error (429): Ratelimit exceed")


@pytest.mark.asyncio
async def test_track_tree_retries_transport_errors() -> None:
    opener = _TrackTreeFlakyOpener(fail_count=2)
    retryable = retryable_contract_opener([opener_config(opener=opener, retries=3, retryDelay=1)])

    await retryable.trackTransactionTree(
        "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",
    )

    assert opener.calls == 3


def test_set_logger_propagates_to_child_openers() -> None:
    opener1 = _UnstableContractOpener("RPC1")
    opener2 = _UnstableContractOpener("RPC2")
    retryable = retryable_contract_opener(
        [
            opener_config(opener=opener1, retries=1, retryDelay=1),
            opener_config(opener=opener2, retries=1, retryDelay=1),
        ]
    )

    logger = _LoggerStub()
    retryable.setLogger(logger)

    assert retryable.logger is logger
    assert opener1.logger is logger
    assert opener2.logger is logger


class _EndpointOpener(base_contract_opener):
    def __init__(self, endpoint: str) -> None:
        super().__init__()
        self.endpoint = endpoint

    def open(self, src: Any) -> Any:
        return src

    async def getContractState(self, address: Any) -> dict[str, Any]:  # noqa: N802
        _ = address
        return {"balance": 0, "state": "active", "code": None}

    async def getTransactions(self, address: Any, opts: GetTransactionsOptions) -> list[Any]:  # noqa: N802
        _ = (address, opts)
        return []

    async def getAddressInformation(self, address: Any) -> AddressInformation:  # noqa: N802
        _ = address
        return {"lastTransaction": {"lt": "", "hash": ""}}

    async def getConfig(self) -> str:  # noqa: N802
        return ""


@pytest.mark.asyncio
async def test_execute_with_fallback_respects_opener_list_order() -> None:
    call_order: list[str] = []

    class _OrderedOpener(base_contract_opener):
        def __init__(self, name: str, should_fail: bool) -> None:
            super().__init__()
            self.name = name
            self.should_fail = should_fail

        def open(self, src: Any) -> Any:
            return src

        async def getContractState(self, address: Any) -> dict[str, Any]:  # noqa: N802
            _ = address
            call_order.append(self.name)
            if self.should_fail:
                raise RuntimeError(f"{self.name} failed")
            return {"balance": 1, "state": "active", "code": None}

        async def getTransactions(self, address: Any, opts: GetTransactionsOptions) -> list[Any]:  # noqa: N802
            _ = (address, opts)
            return []

        async def getAddressInformation(self, address: Any) -> AddressInformation:  # noqa: N802
            _ = address
            return {"lastTransaction": {"lt": "", "hash": ""}}

        async def getConfig(self) -> str:  # noqa: N802
            return ""

    opener_1 = _OrderedOpener("first", should_fail=True)
    opener_2 = _OrderedOpener("second", should_fail=False)
    opener_3 = _OrderedOpener("third", should_fail=False)

    retryable = retryable_contract_opener(
        [
            opener_config(opener=opener_1, retries=0, retryDelay=1),
            opener_config(opener=opener_2, retries=0, retryDelay=1),
            opener_config(opener=opener_3, retries=0, retryDelay=1),
        ]
    )

    state = await retryable.getContractState("EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c")
    assert state["state"] == "active"
    assert call_order == ["first", "second"]


@pytest.mark.asyncio
async def test_create_default_retryable_opener_non_dev_uses_primary_orbs_v4_order(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    primary = _EndpointOpener("https://primary.example/api/v2/jsonRPC")
    orbs = _EndpointOpener("https://orbs.example/api/v2/jsonRPC")
    v4 = _EndpointOpener("https://testnet-v4.tonhubapi.com")

    monkeypatch.setattr(retryable_module.ton_client_opener, "create", lambda endpoint, logger=None: primary)

    async def _fake_orbs(network: Network, logger: Any = None) -> _EndpointOpener:
        _ = (network, logger)
        return orbs

    async def _fake_orbs4(network: Network, timeout: int = 30000, logger: Any = None) -> _EndpointOpener:
        _ = (network, timeout, logger)
        return v4

    monkeypatch.setattr(retryable_module, "orbs_opener", _fake_orbs)
    monkeypatch.setattr(retryable_module, "orbs_opener4", _fake_orbs4)

    opener = await create_default_retryable_opener("https://primary.example", Network.TESTNET)
    endpoints = [getattr(cfg.opener, "endpoint", "") for cfg in opener.openerConfigs]

    assert endpoints == [
        "https://primary.example/api/v2/jsonRPC",
        "https://orbs.example/api/v2/jsonRPC",
        "https://testnet-v4.tonhubapi.com",
    ]


class _ContractExecutionFailingOpener(base_contract_opener):
    def __init__(self, name: str) -> None:
        super().__init__()
        self.name = name
        self.calls = 0

    def open(self, src: Any) -> Any:
        return src

    async def getContractState(self, address: Any) -> dict[str, Any]:  # noqa: N802
        _ = address
        self.calls += 1
        raise RuntimeError("Unable to execute get method, vm exit code: 57")

    async def getTransactions(self, address: Any, opts: GetTransactionsOptions) -> list[Any]:  # noqa: N802
        _ = (address, opts)
        return []

    async def getAddressInformation(self, address: Any) -> AddressInformation:  # noqa: N802
        _ = address
        return {"lastTransaction": {"lt": "", "hash": ""}}

    async def getConfig(self) -> str:  # noqa: N802
        return ""


@pytest.mark.asyncio
async def test_contract_execution_error_stops_retries_and_fallback() -> None:
    failing_1 = _ContractExecutionFailingOpener("RPC1")
    failing_2 = _ContractExecutionFailingOpener("RPC2")
    retryable = retryable_contract_opener(
        [
            opener_config(opener=failing_1, retries=3, retryDelay=1),
            opener_config(opener=failing_2, retries=3, retryDelay=1),
        ]
    )

    with pytest.raises(RuntimeError, match="exit code"):
        await retryable.getContractState("EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c")

    assert failing_1.calls == 1
    assert failing_2.calls == 0
