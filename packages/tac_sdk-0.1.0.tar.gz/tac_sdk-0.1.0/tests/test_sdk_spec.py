from __future__ import annotations

from types import SimpleNamespace
from typing import Any, cast

import pytest

import sdk.tac_sdk as tac_sdkModule
from adapters import pytvm_sandbox_opener
from interfaces.asset import Asset
from interfaces.contract_opener import ContractOpener
from interfaces.i_configuration import IConfiguration
from interfaces.i_lite_sequencer_client import ILiteSequencerClient
from interfaces.i_lite_sequencer_client_factory import ILiteSequencerClientFactory
from interfaces.i_operation_tracker import IOperationTracker
from interfaces.i_simulator import ISimulator
from interfaces.i_tac_explorer_client import ITacExplorerClient
from interfaces.itac_transaction_manager import ITACTransactionManager
from interfaces.iton_transaction_manager import ITONTransactionManager
from sdk.operation_tracker import OperationTracker
from sdk.tac_sdk import TacSdk
from structs.internal_struct import TacGasPriceResponse
from structs.struct import (
    BatchCrossChainTx,
    ConvertCurrencyParams,
    ConvertedCurrencyResult,
    CrossChainPayloadResult,
    CrossChainTransactionOptions,
    CrossChainTransactionsOptions,
    CrosschainTx,
    CurrencyType,
    EvmProxyMsg,
    ExecutionFeeEstimationResult,
    ExecutionStages,
    ExecutionStagesByOperationId,
    FeeParams,
    GeneratePayloadParams,
    GetTVMExecutorFeeParams,
    Network,
    OperationIdsByShardsKey,
    OperationType,
    SDKParams,
    SimplifiedStatuses,
    StatusInfo,
    StatusInfosByOperationId,
    SuggestedTVMExecutorFee,
    TACSimulationParams,
    TACSimulationResult,
    TransactionLinker,
    TransactionLinkerWithOperationId,
    WaitOptions,
)
from tests.pytvm_test_utils import build_chain_from_fixture
from tests.test_helpers import dummy_asset, sender_stub


class _TonTransactionManagerStub(ITONTransactionManager):
    def __init__(self) -> None:
        self.calls: list[tuple[EvmProxyMsg, Any, CrosschainTx]] = []

    async def sendCrossChainTransaction(  # noqa: N802
        self,
        evmProxyMsg: EvmProxyMsg,
        sender: Any,
        tx: CrosschainTx,
    ) -> TransactionLinkerWithOperationId:
        self.calls.append((evmProxyMsg, sender, tx))
        return {
            "caller": sender.getSenderAddress(),
            "shardCount": 1,
            "shardsKey": "1",
            "timestamp": 0,
            "operationId": "operation-1",
            "sendTransactionResult": None,
        }

    async def sendCrossChainTransactions(  # noqa: N802
        self,
        sender: Any,
        txs: list[BatchCrossChainTx],
        options: CrossChainTransactionsOptions | None = None,
    ) -> list[TransactionLinkerWithOperationId]:
        _ = (sender, txs, options)
        return []

    async def buildFeeParams(  # noqa: N802
        self,
        options: CrossChainTransactionOptions,
        evmProxyMsg: EvmProxyMsg,
        sender: Any,
        tx: CrosschainTx,
    ) -> FeeParams:
        _ = (options, evmProxyMsg, sender, tx)
        return {"gasLimit": 0, "protocolFee": 0, "evmExecutorFee": 0, "tvmExecutorFee": 0, "isRoundTrip": False}

    async def prepareCrossChainTransactionPayload(  # noqa: N802
        self,
        evmProxyMsg: EvmProxyMsg,
        senderAddress: str,
        assets: list[Asset],
        options: CrossChainTransactionOptions | None = None,
    ) -> list[CrossChainPayloadResult]:
        _ = (evmProxyMsg, senderAddress, assets, options)
        return []


class _TacTransactionManagerStub(ITACTransactionManager):
    def __init__(self) -> None:
        self.calls: list[tuple[object, int, str, list[Asset] | None, int | None, list[str] | None]] = []

    async def bridgeTokensToTON(  # noqa: N802
        self,
        signer: object,
        value: int,
        tonTarget: str,
        assets: list[Asset] | None = None,
        tvmExecutorFee: int | None = None,
        tvmValidExecutors: list[str] | None = None,
    ) -> str:
        self.calls.append((signer, value, tonTarget, assets, tvmExecutorFee, tvmValidExecutors))
        return "0xdeadbeef"


class _ConfigStub(IConfiguration):
    def __init__(self, opener: ContractOpener) -> None:
        self.network = Network.TESTNET
        self.artifacts = {}
        self.TONParams = {"contractOpener": opener}
        self.TACParams = {}
        self.liteSequencerEndpoints = []

    @property
    def nativeTONAddress(self) -> str:
        return "NONE"

    async def nativeTACAddress(self) -> str:
        return "0x0000000000000000000000000000000000000000"

    @property
    def getTrustedTACExecutors(self) -> list[str]:
        return []

    @property
    def getTrustedTONExecutors(self) -> list[str]:
        return []

    async def closeConnections(self) -> None:  # noqa: N802
        return None

    async def isContractDeployedOnTVM(self, address: str) -> bool:
        _ = address
        return True


class _SimulatorStub(ISimulator):
    async def getSimulationsInfo(  # noqa: N802
        self,
        sender: Any,
        txs: list[CrosschainTx],
    ) -> list[ExecutionFeeEstimationResult]:
        _ = (sender, txs)
        return []

    async def getSimulationInfo(  # noqa: N802
        self,
        sender: Any,
        tx: CrosschainTx,
    ) -> ExecutionFeeEstimationResult:
        _ = (sender, tx)
        return {
            "feeParams": {"gasLimit": 0, "protocolFee": 0, "evmExecutorFee": 0, "tvmExecutorFee": 0, "isRoundTrip": False},
            "simulation": None,
        }

    async def estimateTONFee(  # noqa: N802
        self,
        asset: Asset,
        params: GeneratePayloadParams,
    ) -> int:
        _ = (asset, params)
        return 0


class _OperationTrackerStub(IOperationTracker):
    async def getOperationType(  # noqa: N802
        self,
        operationId: str,
        waitOptions: WaitOptions | None = None,
    ) -> OperationType:
        _ = (operationId, waitOptions)
        return OperationType.PENDING

    async def getOperationId(  # noqa: N802
        self,
        transactionLinker: TransactionLinker,
        waitOptions: WaitOptions | None = None,
    ) -> str:
        _ = (transactionLinker, waitOptions)
        return ""

    async def getOperationIdByTransactionHash(  # noqa: N802
        self,
        transactionHash: str,
        waitOptions: WaitOptions | None = None,
    ) -> str:
        _ = (transactionHash, waitOptions)
        return ""

    async def getOperationIdsByShardsKeys(  # noqa: N802
        self,
        shardsKeys: list[str],
        caller: str,
        waitOptions: WaitOptions | None = None,
        chunkSize: int | None = None,
    ) -> OperationIdsByShardsKey:
        _ = (shardsKeys, caller, waitOptions, chunkSize)
        return {}

    async def getStageProfiling(  # noqa: N802
        self,
        operationId: str,
        waitOptions: WaitOptions | None = None,
    ) -> ExecutionStages:
        _ = (operationId, waitOptions)
        return {}

    async def getStageProfilings(  # noqa: N802
        self,
        operationIds: list[str],
        waitOptions: WaitOptions | None = None,
        chunkSize: int | None = None,
    ) -> ExecutionStagesByOperationId:
        _ = (operationIds, waitOptions, chunkSize)
        return {}

    async def getOperationStatuses(  # noqa: N802
        self,
        operationIds: list[str],
        waitOptions: WaitOptions | None = None,
        chunkSize: int | None = None,
    ) -> StatusInfosByOperationId:
        _ = (operationIds, waitOptions, chunkSize)
        return {}

    async def getOperationStatus(  # noqa: N802
        self,
        operationId: str,
        waitOptions: WaitOptions | None = None,
    ) -> StatusInfo:
        _ = (operationId, waitOptions)
        return {}

    async def getSimplifiedOperationStatus(  # noqa: N802
        self,
        transactionLinker: TransactionLinker,
    ) -> SimplifiedStatuses:
        _ = transactionLinker
        return SimplifiedStatuses.PENDING

    async def convertCurrency(  # noqa: N802
        self,
        params: ConvertCurrencyParams,
        waitOptions: WaitOptions | None = None,
    ) -> ConvertedCurrencyResult:
        _ = (params, waitOptions)
        return {
            "spotValue": 0,
            "emaValue": 0,
            "decimals": 0,
            "currency": CurrencyType.TON,
            "tacPrice": {"spot": 0, "ema": 0, "decimals": 0},
            "tonPrice": {"spot": 0, "ema": 0, "decimals": 0},
        }

    async def simulateTACMessage(  # noqa: N802
        self,
        params: TACSimulationParams,
        waitOptions: WaitOptions | None = None,
    ) -> TACSimulationResult:
        _ = (params, waitOptions)
        return {}

    async def getTVMExecutorFee(  # noqa: N802
        self,
        params: GetTVMExecutorFeeParams,
        waitOptions: WaitOptions | None = None,
    ) -> SuggestedTVMExecutorFee:
        _ = (params, waitOptions)
        return {"inTAC": "0", "inTON": "0"}


class _TacExplorerClientStub(ITacExplorerClient):
    async def getTACGasPrice(self) -> TacGasPriceResponse:  # noqa: N802
        return {"gasPrices": {"average": 0.0, "fast": 0.0, "slow": 0.0}}


class _MemoryLogger:
    def __init__(self) -> None:
        self.debug_logs: list[str] = []
        self.warn_logs: list[str] = []
        self.error_logs: list[str] = []

    def debug(self, message: str) -> None:
        self.debug_logs.append(message)

    def warn(self, message: str) -> None:
        self.warn_logs.append(message)

    def error(self, message: str) -> None:
        self.error_logs.append(message)

    def info(self, message: str) -> None:
        _ = message


class _SequencerStatusClient(ILiteSequencerClient):
    def __init__(self) -> None:
        self.calls = 0

    async def getOperationType(self, operationId: str) -> OperationType:  # noqa: N802
        _ = operationId
        return OperationType.PENDING

    async def getOperationId(self, transactionLinker: TransactionLinker) -> str:  # noqa: N802
        _ = transactionLinker
        return ""

    async def getOperationIdByTransactionHash(self, transactionHash: str) -> str:  # noqa: N802
        _ = transactionHash
        return ""

    async def getOperationIdsByShardsKeys(  # noqa: N802
        self,
        shardsKeys: list[str],
        caller: str,
        chunkSize: int | None = None,
    ) -> OperationIdsByShardsKey:
        _ = (shardsKeys, caller, chunkSize)
        return {}

    async def getStageProfilings(  # noqa: N802
        self,
        operationIds: list[str],
        chunkSize: int | None = None,
    ) -> ExecutionStagesByOperationId:
        _ = (operationIds, chunkSize)
        return {}

    async def getOperationStatuses(  # noqa: N802
        self,
        operationIds: list[str],
        chunkSize: int | None = None,
    ) -> StatusInfosByOperationId:
        _ = (operationIds, chunkSize)
        self.calls += 1
        if self.calls == 1:
            return {
                "op-1": {
                    "stage": "includedInTONConsensus",
                    "success": True,
                    "transactions": [
                        {
                            "hash": "0x69d97176890b6968837c20ff9fff36d8791e5108cb0a8bb366da13db6bd556ab",
                            "blockchainType": "TON",
                        }
                    ],
                }
            }
        return {
            "op-1": {
                "stage": "executedInTON",
                "success": True,
                "transactions": [
                    {
                        "hash": "0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
                        "blockchainType": "TON",
                    }
                ],
            }
        }

    async def convertCurrency(self, params: ConvertCurrencyParams) -> ConvertedCurrencyResult:  # noqa: N802
        _ = params
        return {
            "spotValue": 0,
            "emaValue": 0,
            "decimals": 0,
            "currency": CurrencyType.TON,
            "tacPrice": {"spot": 0, "ema": 0, "decimals": 0},
            "tonPrice": {"spot": 0, "ema": 0, "decimals": 0},
        }

    async def getTVMExecutorFee(self, params: GetTVMExecutorFeeParams) -> SuggestedTVMExecutorFee:  # noqa: N802
        _ = params
        return {"inTAC": "0", "inTON": "0"}

    async def simulateTACMessage(self, params: TACSimulationParams) -> TACSimulationResult:  # noqa: N802
        _ = params
        return {}


class _SequencerClientFactory(ILiteSequencerClientFactory):
    def __init__(self, client: ILiteSequencerClient) -> None:
        self._client = client

    def createClients(self, endpoints: list[str]) -> list[ILiteSequencerClient]:  # noqa: N802
        _ = endpoints
        return [self._client]


@pytest.mark.asyncio
async def test_pytvm_opener_reads_contract_state(require_pytvm: None, sandbox_fixtures: dict[str, dict]) -> None:
    fixture = sandbox_fixtures["testnet"]
    chain, address = build_chain_from_fixture(fixture)
    opener = pytvm_sandbox_opener(chain)

    state = await opener.getContractState(address)

    assert state["state"] == "active"
    assert state["balance"] > 0
    assert isinstance(state["code"], (bytes, bytearray))


@pytest.mark.asyncio
async def test_tacsdk_delegates_send_cross_chain_transaction_to_manager(
    require_pytvm: None,
    sandbox_fixtures: dict[str, dict],
) -> None:
    fixture = sandbox_fixtures["testnet"]
    chain, _address = build_chain_from_fixture(fixture)
    opener = pytvm_sandbox_opener(chain)

    config = _ConfigStub(opener)
    ton_tx_manager = _TonTransactionManagerStub()
    tac_tx_manager = _TacTransactionManagerStub()

    sdk = TacSdk(
        config=config,
        simulator=_SimulatorStub(),
        ton_transaction_manager=ton_tx_manager,
        tac_transaction_manager=tac_tx_manager,
        operation_tracker=_OperationTrackerStub(),
        explorer_client=_TacExplorerClientStub(),
    )

    sender = sender_stub("EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c")
    asset = dummy_asset("EQToken", raw_amount=1)
    result = await sdk.sendCrossChainTransaction(
        {
            "evmTargetAddress": "0x0000000000000000000000000000000000000001",
            "methodName": "",
            "encodedParameters": "0x",
            "gasLimit": None,
        },
        sender,
        [asset],
        {"waitOperationId": False},
    )

    assert result.get("operationId") == "operation-1"
    assert len(ton_tx_manager.calls) == 1
    _msg, captured_sender, tx = ton_tx_manager.calls[0]
    assert captured_sender is sender
    assert tx["assets"][0] is asset


@pytest.mark.asyncio
async def test_tacsdk_create_wires_components(monkeypatch: pytest.MonkeyPatch) -> None:
    captured_create_args: dict[str, Any] = {}

    async def fake_configuration_create(*_args: Any, **_kwargs: Any) -> Any:
        captured_create_args["args"] = _args
        captured_create_args["kwargs"] = _kwargs
        return SimpleNamespace(
            TONParams={"contractOpener": object()},
            TACParams={},
            nativeTONAddress="NONE",
            getTrustedTACExecutors=[],
            getTrustedTONExecutors=[],
            liteSequencerEndpoints=["https://ls.example"],
        )

    class _OperationTrackerStub:
        def __init__(self, network: Network, endpoints: list[str], logger: Any) -> None:
            self.network = network
            self.endpoints = endpoints
            self.logger = logger

    class _ExplorerStub:
        def __init__(self, endpoint: str) -> None:
            self.endpoint = endpoint

    class _SimulatorStub:
        def __init__(self, config: Any, tracker: Any, logger: Any) -> None:
            self.config = config
            self.tracker = tracker
            self.logger = logger

    class _TonManagerStub:
        def __init__(self, config: Any, simulator: Any, tracker: Any, logger: Any) -> None:
            self.config = config
            self.simulator = simulator
            self.tracker = tracker
            self.logger = logger

    class _TacManagerStub:
        def __init__(self, config: Any, tracker: Any, logger: Any) -> None:
            self.config = config
            self.tracker = tracker
            self.logger = logger

    def fake_resolve_artifacts(_source: Any, _network: Network) -> Any:
        return SimpleNamespace(
            tac=SimpleNamespace(
                endpoints={"TAC_EXPLORER_API_ENDPOINT": "https://explorer.example"},
            )
        )

    monkeypatch.setattr(tac_sdkModule.Configuration, "create", fake_configuration_create)
    monkeypatch.setattr(tac_sdkModule, "OperationTracker", _OperationTrackerStub)
    monkeypatch.setattr(tac_sdkModule, "TacExplorerClient", _ExplorerStub)
    monkeypatch.setattr(tac_sdkModule, "Simulator", _SimulatorStub)
    monkeypatch.setattr(tac_sdkModule, "TonTransactionManager", _TonManagerStub)
    monkeypatch.setattr(tac_sdkModule, "TacTransactionManager", _TacManagerStub)
    monkeypatch.setattr(tac_sdkModule, "resolve_artifacts", fake_resolve_artifacts)

    sdk = await TacSdk.create(
        SDKParams(
            network=Network.TESTNET,
            artifacts={"testnet": {}},
            passLoggerToOpeners=False,
        )
    )

    assert isinstance(sdk, TacSdk)
    assert isinstance(sdk.operationTracker, _OperationTrackerStub)
    assert isinstance(sdk.explorerClient, _ExplorerStub)
    assert isinstance(sdk.simulator, _SimulatorStub)
    assert isinstance(sdk.tonTransactionManager, _TonManagerStub)
    assert isinstance(sdk.tacTransactionManager, _TacManagerStub)
    assert captured_create_args["args"][5] is False


@pytest.mark.asyncio
async def test_operation_tracker_get_operation_status_logs_pending_and_final_resolution() -> None:
    logger = _MemoryLogger()
    client = _SequencerStatusClient()
    tracker = OperationTracker(
        network=Network.TESTNET,
        customLiteSequencerEndpoints=["https://data.spb.tac.build"],
        logger=logger,
        clientFactory=_SequencerClientFactory(client),
    )

    status = await tracker.getOperationStatus(
        "op-1",
        WaitOptions[StatusInfo, None](
            timeout=1000,
            maxAttempts=5,
            delay=1,
            logger=logger,
            successCheck=lambda result, _: result.get("stage") == "executedInTON",
        ),
    )

    assert status.get("stage") == "executedInTON"
    assert not any("Operation status retrieved successfully" in line for line in logger.debug_logs)
    assert any(
        "pending attempt=1/5 stage=includedInTONConsensus success=true "
        "tx=0x69d97176890b6968837c20ff9fff36d8791e5108cb0a8bb366da13db6bd556ab retry_in=1ms" in line
        for line in logger.debug_logs
    )
    assert any(
        "operation status resolved stage=executedInTON success=true" in line
        for line in logger.debug_logs
    )

_ton_transaction_manager_stub = _TonTransactionManagerStub
_tac_transaction_manager_stub = _TacTransactionManagerStub
_config_stub = _ConfigStub
_simulator_stub = _SimulatorStub
_operation_tracker_stub = _OperationTrackerStub
_tac_explorer_client_stub = _TacExplorerClientStub


def test_tacsdk_uses_strict_js_method_names_only() -> None:
    assert hasattr(TacSdk, "nativeTONAddress")
    assert hasattr(TacSdk, "bridgeTokensToTON")
    assert hasattr(TacSdk, "closeConnections")

    assert not hasattr(TacSdk, "nativetTONAddress")
    assert not hasattr(TacSdk, "bridgeTokensToTon")
    assert not hasattr(TacSdk, "close")


@pytest.mark.asyncio
async def test_tacsdk_close_connections_delegates_to_opener_close() -> None:
    class _ClosableOpener:
        def __init__(self) -> None:
            self.closed = False

        async def closeConnections(self) -> None:
            self.closed = True

    opener = _ClosableOpener()
    sdk = TacSdk(
        config=_ConfigStub(cast(ContractOpener, opener)),
        simulator=_SimulatorStub(),
        ton_transaction_manager=_TonTransactionManagerStub(),
        tac_transaction_manager=_TacTransactionManagerStub(),
        operation_tracker=_OperationTrackerStub(),
        explorer_client=_TacExplorerClientStub(),
    )

    await sdk.closeConnections()

    assert opener.closed is True
