from __future__ import annotations

from typing import Any

import pytest
from pytoniq.contract.contract import Contract
from pytoniq.contract.wallets import wallet as wallet_lib
from pytoniq.contract.wallets.wallet import WALLET_V4_R2_CODE, WalletV4
from pytoniq.contract.wallets.wallet_v5 import WALLET_V5_R1_CODE, WalletV5R1, WalletV5WalletID
from pytoniq_core.boc.address import Address
from pytoniq_core.tlb.account import StateInit
from pytoniq_core import begin_cell
from pytoniq_core.tlb.custom.wallet import WalletMessage

from sender.batch_sender import BatchSender
from sender.raw_sender import RawSender
from sender.sender_factory import SenderFactory, _LocalWallet
from structs.struct import Network

MNEMONIC = (
    "sibling cover host ask camera coin harbor pepper weekend knife sponsor boost "
    "top write torch axis horn control puppy speak suit crystal harsh equal"
)
RECIPIENT = "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c"


class _WalletContractProxy:
    def __init__(self, fail_on_send_call: int | None = None) -> None:
        self._seqno = 0
        self._fail_on_send_call = fail_on_send_call
        self.send_calls = 0

    async def getSeqno(self) -> int:  # noqa: N802
        seqno = self._seqno
        self._seqno += 1
        return seqno

    async def send(self, _msg: Any, _state_init: Any) -> dict[str, str]:
        self.send_calls += 1
        if self._fail_on_send_call and self.send_calls == self._fail_on_send_call:
            raise RuntimeError("Simulated send failure")
        return {"result": f"boc-{self.send_calls}"}


class _ContractOpenerStub:
    def __init__(self, fail_on_send_call: int | None = None) -> None:
        self.wallet_proxy = _WalletContractProxy(fail_on_send_call)

    def open(self, _src: Any) -> _WalletContractProxy:
        return self.wallet_proxy

    async def getContractState(self, _address: Any) -> dict[str, Any]:  # noqa: N802
        return {"balance": 10**9, "state": "active", "code": b"code"}


def _build_shard_tx(index: int) -> dict[str, Any]:
    return {
        "network": Network.TESTNET,
        "validUntil": 0,
        "messages": [
            {
                "address": RECIPIENT,
                "value": 1,
                "payload": begin_cell().store_uint(index, 32).end_cell(),
                "extra": {},
            }
        ],
    }


@pytest.mark.asyncio
async def test_sender_factory_returns_expected_sender_types() -> None:
    raw_sender_v4 = await SenderFactory.get_sender(
        {"network": Network.TESTNET, "version": "V4", "mnemonic": MNEMONIC}
    )
    raw_sender_v5 = await SenderFactory.get_sender(
        {"network": Network.TESTNET, "version": "V5R1", "mnemonic": MNEMONIC}
    )
    highload_sender = await SenderFactory.get_sender(
        {"network": Network.TESTNET, "version": "HIGHLOAD_V3", "mnemonic": MNEMONIC}
    )

    assert isinstance(raw_sender_v4, RawSender)
    assert isinstance(raw_sender_v5, RawSender)
    assert isinstance(highload_sender, BatchSender)
    assert raw_sender_v5.max_batch_size == 254
    assert raw_sender_v4.getSenderAddress()
    assert highload_sender.getSenderAddress()


@pytest.mark.asyncio
async def test_raw_sender_sends_single_shard_transaction() -> None:
    raw_sender = await SenderFactory.get_sender(
        {"network": Network.TESTNET, "version": "V4", "mnemonic": MNEMONIC}
    )
    opener = _ContractOpenerStub()

    result = await raw_sender.sendShardTransaction(
        _build_shard_tx(1),
        Network.TESTNET,
        opener,
    )

    assert result.success is True
    assert result.lastMessageIndex == 0
    assert result.boc == "boc-1"
    assert opener.wallet_proxy.send_calls == 1


@pytest.mark.asyncio
async def test_raw_sender_batches_transactions_and_stops_on_first_error() -> None:
    raw_sender = await SenderFactory.get_sender(
        {"network": Network.TESTNET, "version": "V4", "mnemonic": MNEMONIC}
    )
    opener = _ContractOpenerStub(fail_on_send_call=2)
    txs = [_build_shard_tx(i) for i in range(5)]

    results = await raw_sender.sendShardTransactions(
        txs,
        Network.TESTNET,
        opener,
    )

    assert len(results) == 2
    assert results[0].success is True
    assert results[0].lastMessageIndex == 3
    assert results[1].success is False
    assert results[1].lastMessageIndex == 3
    assert opener.wallet_proxy.send_calls == 2


@pytest.mark.asyncio
async def test_raw_sender_raises_on_wallet_version_mismatch() -> None:
    raw_sender = await SenderFactory.get_sender(
        {"network": Network.TESTNET, "version": "V4", "mnemonic": MNEMONIC}
    )

    class _MismatchOpener(_ContractOpenerStub):
        async def getContractState(self, _address: Any) -> dict[str, Any]:  # noqa: N802
            return {"balance": 10**9, "state": "active", "code": WALLET_V5_R1_CODE.to_boc()}

    opener = _MismatchOpener()

    with pytest.raises(RuntimeError, match="Wallet version mismatch"):
        await raw_sender.sendShardTransaction(
            _build_shard_tx(1),
            Network.TESTNET,
            opener,
        )

_wallet_contract_proxy = _WalletContractProxy
_contract_opener_stub = _ContractOpenerStub


def test_v5_transfer_message_matches_pytoniq_reference() -> None:
    _, secret_key = wallet_lib.mnemonic_to_private_key(MNEMONIC.split())
    wallet_id = WalletV5WalletID(-3, workchain=0, subwallet_number=0).pack()
    public_key = wallet_lib.private_key_to_public_key(secret_key)
    state_data = WalletV5R1.create_data_cell(public_key, wc=0, wallet_id=wallet_id)
    state_init = StateInit(code=WALLET_V5_R1_CODE, data=state_data)
    wallet_address = Address((0, state_init.serialize().hash))
    wallet_impl = WalletV5R1(provider=None, address=wallet_address, state_init=state_init, private_key=secret_key)
    wallet_adapter = _LocalWallet(wallet_impl, "V5R1")
    message = Contract.create_internal_msg(
        dest=Address(RECIPIENT),
        value=1,
        bounce=True,
        body=begin_cell().store_uint(1, 32).end_cell(),
    )
    wallet_messages = [WalletMessage(3, message)]

    generated = wallet_adapter.createTransfer(
        {
            "seqno": 0,
            "secretKey": secret_key,
            "messages": [message],
            "sendMode": 3,
        }
    )
    reference = WalletV5R1.raw_create_transfer_msg(WalletV5R1, secret_key, 0, wallet_id, wallet_messages)

    assert generated.to_boc() == reference.to_boc()
    assert generated.hash == reference.hash


def test_v4_transfer_message_matches_pytoniq_reference() -> None:
    _, secret_key = wallet_lib.mnemonic_to_private_key(MNEMONIC.split())
    wallet_id = 698983191
    public_key = wallet_lib.private_key_to_public_key(secret_key)
    state_data = WalletV4.create_data_cell(public_key, wallet_id=wallet_id, wc=0)
    state_init = StateInit(code=WALLET_V4_R2_CODE, data=state_data)
    wallet_address = Address((0, state_init.serialize().hash))
    wallet_impl = WalletV4(provider=None, address=wallet_address, state_init=state_init, private_key=secret_key)
    wallet_adapter = _LocalWallet(wallet_impl, "V4")
    message = Contract.create_internal_msg(
        dest=Address(RECIPIENT),
        value=1,
        bounce=True,
        body=begin_cell().store_uint(1, 32).end_cell(),
    )
    wallet_messages = [WalletMessage(3, message)]

    generated = wallet_adapter.createTransfer(
        {
            "seqno": 0,
            "secretKey": secret_key,
            "messages": [message],
            "sendMode": 3,
        }
    )
    reference = WalletV4.raw_create_transfer_msg(secret_key, 0, wallet_id, wallet_messages)

    assert generated.to_boc() == reference.to_boc()
    assert generated.hash == reference.hash
