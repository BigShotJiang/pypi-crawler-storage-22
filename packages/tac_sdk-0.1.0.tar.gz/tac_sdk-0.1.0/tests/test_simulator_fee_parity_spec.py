from __future__ import annotations

from typing import Any, cast

import pytest

from sdk.logger import noop_logger
from sdk.simulator import Simulator
from structs.struct import CrosschainTx


class _SenderStub:
    def getSenderAddress(self) -> str:  # noqa: N802
        return "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c"


class _OperationTrackerStub:
    async def simulateTACMessage(self, params: dict[str, Any]) -> dict[str, Any]:  # noqa: N802
        _ = params
        return {
            "simulationStatus": True,
            "estimatedGas": 12345,
            "suggestedTacExecutionFee": "21197",
            "suggestedTonExecutionFee": "42000",
            "outMessages": None,
        }


class _RunGetMethodOpener:
    def __init__(self, stack: list[Any]) -> None:
        self._stack = stack

    def _run_get_method(self, address: str, method: str) -> dict[str, Any]:
        _ = (address, method)
        return {"stack": self._stack}


class _ConfigStub:
    def __init__(self, stack: list[Any]) -> None:
        self.TACParams = {
            "trustedTACExecutors": [],
            "trustedTONExecutors": [],
        }
        self.TONParams = {
            "contractOpener": _RunGetMethodOpener(stack),
            "crossChainLayerAddress": "EQAVGclLM4b0fb4pYRbS-OUUJiXlaTk8C0D1IueAzx6XgGo0",
            "contractFeeUsageParams": {},
            "feesParams": {
                "accountBitPrice": 0,
                "accountCellPrice": 0,
                "lumpPrice": 0,
                "gasPrice": 65536,
                "firstFrac": 65536,
                "ihrPriceFactor": 0,
                "msgBitPrice": 0,
                "msgCellPrice": 0,
            },
        }


def _build_get_full_data_stack(tac_protocol_fee: int, ton_protocol_fee: int) -> list[Any]:
    return [
        ["cell", {}],
        ["cell", {}],
        ["cell", {}],
        ["num", "0x3"],
        ["cell", {}],
        ["num", "0x1"],
        ["num", "0x2"],
        ["num", "0x3"],
        ["num", "0x4"],
        ["num", "0x5"],
        ["num", hex(tac_protocol_fee)],
        ["num", hex(ton_protocol_fee)],
        ["num", "0x1"],
        ["cell", {}],
    ]


def _build_tx(is_round_trip: bool | None = None) -> CrosschainTx:
    options: dict[str, Any] = {}
    if is_round_trip is not None:
        options["isRoundTrip"] = is_round_trip
    return cast(
        CrosschainTx,
        {
        "evmProxyMsg": {
            "evmTargetAddress": "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266",
            "methodName": "",
            "encodedParameters": "0x",
            "gasLimit": None,
        },
        "assets": [],
        "options": options,
        },
    )


@pytest.mark.asyncio
async def test_protocol_fee_uses_tac_plus_ton_for_round_trip() -> None:
    tac_fee = 10_000_000
    ton_fee = 1_000_000
    cfg = _ConfigStub(_build_get_full_data_stack(tac_fee, ton_fee))
    sim = Simulator(cast(Any, cfg), cast(Any, _OperationTrackerStub()), noop_logger())
    result = await sim.getSimulationInfo(cast(Any, _SenderStub()), _build_tx(True))
    assert result.get("feeParams", {}).get("protocolFee") == tac_fee + ton_fee


@pytest.mark.asyncio
async def test_protocol_fee_uses_only_tac_for_one_way() -> None:
    tac_fee = 10_000_000
    ton_fee = 1_000_000
    cfg = _ConfigStub(_build_get_full_data_stack(tac_fee, ton_fee))
    sim = Simulator(cast(Any, cfg), cast(Any, _OperationTrackerStub()), noop_logger())
    result = await sim.getSimulationInfo(cast(Any, _SenderStub()), _build_tx(False))
    assert result.get("feeParams", {}).get("protocolFee") == tac_fee
