from __future__ import annotations

from typing import Any

import pytest

from adapters.ton_client4_opener import _ton_client4_wallet_proxy
from adapters.ton_client_opener import _ton_client_wallet_proxy, ton_client_opener
from structs.struct import GetTransactionsOptions


class _CapturingTonClientOpener(ton_client_opener):
    def __init__(self) -> None:
        super().__init__("https://example.com")
        self.last_method: str | None = None
        self.last_params: dict[str, Any] | None = None

    def _json_rpc(self, method: str, params: dict, timeout_ms: int | None = None) -> Any:
        _ = timeout_ms
        self.last_method = method
        self.last_params = dict(params)
        return []


@pytest.mark.asyncio
async def test_get_transactions_does_not_send_inclusive_to_toncenter() -> None:
    opener = _CapturingTonClientOpener()
    opts: GetTransactionsOptions = {
        "limit": 10,
        "hash": "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",
        "inclusive": True,
        "archival": True,
    }

    await opener.getTransactions("EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c", opts)

    assert opener.last_method == "getTransactions"
    assert opener.last_params is not None
    assert "inclusive" not in opener.last_params
    assert opener.last_params.get("archival") is True


def test_get_rpc_endpoints_include_base_and_rpc_variants() -> None:
    opener = ton_client_opener("https://rp-testnet.turin.tac.build/api/v2/jsonRPC")
    endpoints = opener._get_rpc_endpoints()
    assert endpoints[0] == "https://rp-testnet.turin.tac.build/api/v2/jsonRPC"
    assert "https://rp-testnet.turin.tac.build" in endpoints
    assert "https://rp-testnet.turin.tac.build/api/v2/jsonRPC" in endpoints
    assert "https://rp-testnet.turin.tac.build/jsonRPC" in endpoints
    assert len(endpoints) == len(set(endpoints))


def test_json_rpc_uses_full_timeout_for_connect_and_read(monkeypatch: pytest.MonkeyPatch) -> None:
    captured_timeout: tuple[float, float] | None = None

    class _ResponseStub:
        status_code = 200
        text = ""

        @staticmethod
        def json() -> dict[str, Any]:
            return {"ok": True, "result": []}

    def _fake_post(*args: Any, **kwargs: Any) -> _ResponseStub:
        nonlocal captured_timeout
        _ = args
        timeout_value = kwargs.get("timeout")
        if isinstance(timeout_value, tuple):
            captured_timeout = timeout_value
        return _ResponseStub()

    monkeypatch.setattr("requests.post", _fake_post)

    opener = ton_client_opener("https://rp-testnet.turin.tac.build/api/v2/jsonRPC")
    opener._json_rpc("getTransactions", {"address": "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c", "limit": 1})

    assert captured_timeout == (30.0, 30.0)


def test_json_rpc_429_fails_over_to_next_endpoint(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[str] = []

    class _Response429:
        status_code = 429
        text = ""

        @staticmethod
        def json() -> dict[str, Any]:
            return {"ok": False, "result": "Ratelimit exceed", "code": 429}

    class _Response200:
        status_code = 200
        text = ""

        @staticmethod
        def json() -> dict[str, Any]:
            return {"ok": True, "result": ["ok"]}

    def _fake_post(url: str, *args: Any, **kwargs: Any) -> Any:
        _ = (args, kwargs)
        calls.append(url)
        if url.endswith("/api/v2/jsonRPC"):
            return _Response429()
        return _Response200()

    monkeypatch.setattr("requests.post", _fake_post)

    opener = ton_client_opener("https://rp-testnet.turin.tac.build/api/v2/jsonRPC")
    result = opener._json_rpc("getTransactions", {"address": "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c", "limit": 1})

    assert result == ["ok"]
    assert len(calls) >= 2


@pytest.mark.asyncio
async def test_ton_client_wallet_proxy_get_seqno_does_not_suppress_transport_errors() -> None:
    class _WalletStub:
        address = "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c"

    class _OpenerStub:
        async def getContractState(self, _address: str) -> dict[str, Any]:  # noqa: N802
            raise RuntimeError("temporary transport failure")

        def _run_get_method(self, _address: str, _method: str) -> dict[str, Any]:
            return {"stack": [["num", "0x1"]]}

    proxy = _ton_client_wallet_proxy(_OpenerStub(), _WalletStub())
    with pytest.raises(RuntimeError, match="transport failure"):
        await proxy.getSeqno()


@pytest.mark.asyncio
async def test_ton_client4_wallet_proxy_get_seqno_does_not_suppress_transport_errors() -> None:
    class _WalletStub:
        address = "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c"

    class _OpenerStub:
        async def getContractState(self, _address: str) -> dict[str, Any]:  # noqa: N802
            raise RuntimeError("temporary transport failure")

        def _run_method_raw(self, _address: str, _method: str) -> dict[str, Any]:
            return {"resultRaw": None}

    proxy = _ton_client4_wallet_proxy(_OpenerStub(), _WalletStub())
    with pytest.raises(RuntimeError, match="transport failure"):
        await proxy.getSeqno()
