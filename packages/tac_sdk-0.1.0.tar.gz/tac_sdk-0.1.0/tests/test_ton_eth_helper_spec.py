from __future__ import annotations

from types import SimpleNamespace
from typing import Any, cast

import pytest
from eth_abi.abi import decode
from eth_account import Account
from web3 import Web3

from helpers import EthTonHelper, LayerZeroBridgeHelper, TonEthHelper
from helpers.lz_options import build_executor_compose_options
from tests.test_helpers import dummy_asset, sender_stub

_SEND_TO_ARGS_ABI_TYPE = (
    "(address,(uint32,bytes32,uint256,uint256,bytes,bytes,bytes),(uint256,uint256),address,address)"
)

_COMPOSER = "0xC1313fD7ca98a85E8a0A3398739801f6653d456b"
_RECIPIENT_ETH = "0x2222222222222222222222222222222222222222"
_RECIPIENT_TON = "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c"
_CBBTC_TVM = "EQDhyPzbIjJT_WnY3gGprjSYUK9fiGMjWMezxO8MZiUdfb_B"
_CBBTC_OAPP = "0x59Ea2825d8Ad7D60cC6Aa77FFbDD0E89c0fBF539"
_WTAC = "0xB63B9f0eb4A6E6f191529D71d4D88cc8900Df2C9"
_TEST_SIGNER_KEY = "0x" + "11" * 32
_EXPECTED_COMPOSE_OPTIONS = "0x0003010013030000000000000000000000000000004c4b40"


class _QuoteSendCallStub:
    def __init__(self, response: Any) -> None:
        self._response = response

    def call(self) -> Any:
        return self._response


class _SendFnCallStub:
    def __init__(self, contract: _ContractStub, args: tuple[Any, Any, Any]) -> None:
        self._contract = contract
        self._args = args

    def estimate_gas(self, _params: dict[str, Any]) -> int:
        return 100_000

    def build_transaction(self, tx_params: dict[str, Any]) -> dict[str, Any]:
        self._contract.send_build_tx_calls.append(tx_params)
        return {**tx_params, "to": self._contract.address, "data": "0xdead"}


class _ContractFunctionsStub:
    def __init__(self, contract: _ContractStub) -> None:
        self._contract = contract

    def quoteSend(self, send_param: tuple, pay_in_lz_token: bool) -> _QuoteSendCallStub:  # noqa: N802
        self._contract.quote_send_calls.append((send_param, pay_in_lz_token))
        return _QuoteSendCallStub(self._contract.quote_response)

    def quoteOFT(self, send_param: tuple) -> _QuoteSendCallStub:  # noqa: N802
        self._contract.quote_oft_calls.append(send_param)
        response = self._contract.quote_oft_response
        if callable(response):
            response = response(send_param)
        return _QuoteSendCallStub(response)

    def send(self, send_param: tuple, messaging_fee: tuple[int, int], refund_address: str) -> _SendFnCallStub:  # noqa: N802
        self._contract.send_calls.append((send_param, messaging_fee, refund_address))
        return _SendFnCallStub(self._contract, (send_param, messaging_fee, refund_address))

    def wTac(self) -> _QuoteSendCallStub:  # noqa: N802
        return _QuoteSendCallStub(self._contract.wtac_address)

    def balanceOf(self, owner: str) -> _QuoteSendCallStub:  # noqa: N802
        self._contract.balance_of_calls.append(owner)
        return _QuoteSendCallStub(self._contract.wtac_balance)

    def allowance(self, owner: str, spender: str) -> _QuoteSendCallStub:  # noqa: N802
        self._contract.allowance_calls.append((owner, spender))
        return _QuoteSendCallStub(self._contract.wtac_allowance)


class _ContractStub:
    def __init__(
        self,
        address: str,
        quote_response: Any,
        wtac_address: str,
        wtac_balance: int,
        wtac_allowance: int,
    ) -> None:
        self.address = address
        self.quote_response = quote_response
        self.quote_oft_response = ((0, 2**256 - 1), [], (1, 1))
        self.wtac_address = wtac_address
        self.wtac_balance = int(wtac_balance)
        self.wtac_allowance = int(wtac_allowance)
        self.quote_send_calls: list[tuple[tuple, bool]] = []
        self.quote_oft_calls: list[tuple] = []
        self.send_calls: list[tuple[tuple, tuple[int, int], str]] = []
        self.send_build_tx_calls: list[dict[str, Any]] = []
        self.balance_of_calls: list[str] = []
        self.allowance_calls: list[tuple[str, str]] = []
        self.functions = _ContractFunctionsStub(self)


class _TxHashStub:
    def __init__(self, value: str) -> None:
        self._value = value

    def hex(self) -> str:
        return self._value


class _SignedTxStub:
    def __init__(self) -> None:
        self.raw_transaction = b"\x01"


class _AccountSignerStub:
    def sign_transaction(self, tx: dict[str, Any], private_key: str) -> _SignedTxStub:
        assert tx["from"]
        assert private_key.startswith("0x")
        return _SignedTxStub()


class _EthStub:
    def __init__(
        self,
        quote_response: Any,
        wtac_balance: int,
        wtac_allowance: int,
        quote_oft_response: Any = ((0, 2**256 - 1), [], (1, 1)),
        ioft_token_balance: int = 10**30,
    ) -> None:
        self._quote_response = quote_response
        self._wtac_balance = int(wtac_balance)
        self._wtac_allowance = int(wtac_allowance)
        self._quote_oft_response = quote_oft_response
        self._ioft_token_balance = int(ioft_token_balance)
        self.contract_calls: list[tuple[str, list[dict[str, Any]]]] = []
        self.last_contract: _ContractStub | None = None
        self.last_ioft_contract: _ContractStub | None = None
        self.ioft_contracts: list[_ContractStub] = []
        self.account = _AccountSignerStub()
        self.chain_id = 1
        self.gas_price = 1
        self.sent_raw_transactions: list[bytes] = []
        self.wait_receipt_calls: list[tuple[str, int]] = []

    def contract(self, address: str, abi: list[dict[str, Any]]) -> _ContractStub:
        normalized_address = Web3.to_checksum_address(address)
        self.contract_calls.append((normalized_address, abi))
        contract = _ContractStub(
            normalized_address,
            self._quote_response,
            Web3.to_checksum_address(_WTAC),
            self._wtac_balance,
            self._wtac_allowance,
        )
        contract.quote_oft_response = self._quote_oft_response
        self.last_contract = contract
        if normalized_address.lower() == Web3.to_checksum_address(_CBBTC_OAPP).lower():
            contract.wtac_balance = self._ioft_token_balance
            self.last_ioft_contract = contract
            self.ioft_contracts.append(contract)
        return contract

    def get_transaction_count(self, _address: str, _block: str) -> int:
        return 1

    def send_raw_transaction(self, raw_transaction: bytes) -> _TxHashStub:
        self.sent_raw_transactions.append(raw_transaction)
        return _TxHashStub("0xdeadbeef")

    def wait_for_transaction_receipt(self, tx_hash: _TxHashStub, timeout: int) -> Any:
        self.wait_receipt_calls.append((tx_hash.hex(), timeout))
        return SimpleNamespace(status=1)


class _ProviderStub:
    def __init__(
        self,
        quote_response: Any,
        wtac_balance: int = 10**30,
        wtac_allowance: int = 10**30,
        quote_oft_response: Any = ((0, 2**256 - 1), [], (1, 1)),
        ioft_token_balance: int = 10**30,
    ) -> None:
        self.eth = _EthStub(
            quote_response,
            wtac_balance=wtac_balance,
            wtac_allowance=wtac_allowance,
            quote_oft_response=quote_oft_response,
            ioft_token_balance=ioft_token_balance,
        )


class _CrossChainLayerStub:
    async def getProtocolFee(self) -> int:  # noqa: N802
        return 7


class _OperationTrackerStub:
    async def getTVMExecutorFee(self, _params: dict[str, Any]) -> dict[str, str]:  # noqa: N802
        return {"inTAC": "100"}


class _FtStub(dummy_asset):
    def __init__(self, tvm_address: str, oapp_address: str, user_balance: int = 10**30) -> None:
        super().__init__(tvm_address)
        self._oapp_address = oapp_address
        self._user_balance = int(user_balance)

    async def getEVMAddress(self) -> str:  # noqa: N802
        return self._oapp_address

    async def getTVMAddress(self) -> str:  # noqa: N802
        return self.address

    async def getBalanceOf(self, userAddress: str) -> int:  # noqa: N802
        _ = userAddress
        return self._user_balance


class _TacSdkStub:
    def __init__(self, provider: _ProviderStub, ft: _FtStub) -> None:
        self.config = cast(
            Any,
            SimpleNamespace(
                TACParams={
                    "provider": provider,
                    "ethProvider": provider,
                    "crossChainLayer": _CrossChainLayerStub(),
                }
            ),
        )
        self.operationTracker = _OperationTrackerStub()
        self._ft = ft
        self.get_ft_calls: list[str] = []
        self.send_calls: list[tuple[dict[str, Any], Any, list[dummy_asset], dict[str, Any] | None]] = []
        self._trusted_ton_executors = ["executor-1"]

    @property
    def getTrustedTONExecutors(self) -> list[str]:  # noqa: N802
        return list(self._trusted_ton_executors)

    async def getFT(self, address: str) -> _FtStub:  # noqa: N802
        self.get_ft_calls.append(address)
        return self._ft

    async def sendCrossChainTransaction(  # noqa: N802
        self,
        evm_proxy_msg: dict[str, Any],
        sender: Any,
        assets: list[dummy_asset] | None = None,
        options: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        self.send_calls.append((evm_proxy_msg, sender, assets or [], options))
        return {
            "caller": sender.getSenderAddress(),
            "shardCount": 1,
            "shardsKey": "1",
            "timestamp": 0,
            "operationId": "operation-1",
            "sendTransactionResult": None,
        }


def _patch_tac_sdk_create(monkeypatch: pytest.MonkeyPatch, sdk_stub: _TacSdkStub) -> None:
    from sdk.tac_sdk import TacSdk

    async def _fake_create(_sdk_params: Any, _logger: Any = None) -> _TacSdkStub:
        return sdk_stub

    monkeypatch.setattr(TacSdk, "create", staticmethod(_fake_create))


@pytest.mark.asyncio
async def test_ton_eth_helper_send_to_eth(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _ProviderStub((1000, 7))
    ft = _FtStub(_CBBTC_TVM, _CBBTC_OAPP)
    sdk_stub = _TacSdkStub(provider, ft)
    _patch_tac_sdk_create(monkeypatch, sdk_stub)
    helper = await TonEthHelper.create()

    result = await helper.sendToETH(
        sender=sender_stub(_RECIPIENT_ETH),
        to_account=_RECIPIENT_ETH,
        asset_id="cbBTC",
        amount=1,
    )

    assert sdk_stub.get_ft_calls == [_CBBTC_TVM]
    assert len(sdk_stub.send_calls) == 1
    assert any(len(contract.quote_oft_calls) == 1 for contract in provider.eth.ioft_contracts)

    evm_proxy_msg, _sender, sent_assets, send_options = sdk_stub.send_calls[0]
    assert evm_proxy_msg["evmTargetAddress"] == Web3.to_checksum_address(_COMPOSER)
    assert evm_proxy_msg["methodName"] == "sendTo(bytes,bytes)"
    assert send_options is None
    assert len(sent_assets) == 1
    assert sent_assets[0].rawAmount == 1

    encoded_parameters = cast(str, evm_proxy_msg["encodedParameters"])
    decoded = decode([_SEND_TO_ARGS_ABI_TYPE], bytes.fromhex(encoded_parameters[2:]))[0]
    expected_to = bytes.fromhex(("00" * 12) + _RECIPIENT_ETH[2:].lower())
    assert decoded[0].lower() == Web3.to_checksum_address(_CBBTC_OAPP).lower()
    assert decoded[1][0] == 30101
    assert decoded[1][1] == expected_to
    assert decoded[1][2] == 1
    assert decoded[1][3] == 0
    assert decoded[1][4] == b""
    assert decoded[1][5] == b""
    assert decoded[1][6] == b""
    assert decoded[2][0] == 1100
    assert decoded[2][1] == 7
    assert decoded[3].lower() == Web3.to_checksum_address(_RECIPIENT_ETH).lower()
    assert decoded[4].lower() == Web3.to_checksum_address(_RECIPIENT_ETH).lower()

    assert result.asset_id == "cbbtc"
    assert result.to_account.lower() == Web3.to_checksum_address(_RECIPIENT_ETH).lower()
    assert result.composer_address == Web3.to_checksum_address(_COMPOSER)
    assert result.fee_quote.native_fee == 1000
    assert result.fee_quote.native_fee_with_markup == 1100
    assert result.fee_quote.lz_token_fee == 7
    assert result.transaction_linker.get("operationId") == "operation-1"


@pytest.mark.asyncio
async def test_ton_eth_helper_rejects_non_integer_amount(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _ProviderStub((1000, 7))
    ft = _FtStub(_CBBTC_TVM, _CBBTC_OAPP)
    sdk_stub = _TacSdkStub(provider, ft)
    _patch_tac_sdk_create(monkeypatch, sdk_stub)
    helper = await TonEthHelper.create()

    with pytest.raises(ValueError, match="raw integer"):
        await helper.sendToETH(
            sender=sender_stub(_RECIPIENT_ETH),
            to_account=_RECIPIENT_ETH,
            asset_id="cbBTC",
            amount=0.00001,  # type: ignore[arg-type]
        )


@pytest.mark.asyncio
async def test_ton_eth_helper_rejects_too_small_amount_after_quote_oft(monkeypatch: pytest.MonkeyPatch) -> None:
    def _quote_oft_threshold(send_param: tuple) -> tuple[tuple[int, int], list, tuple[int, int]]:
        amount = int(send_param[2])
        if amount >= 10:
            return ((0, 0), [], (amount, amount))
        return ((0, 0), [], (0, 0))

    provider = _ProviderStub((1000, 7), quote_oft_response=_quote_oft_threshold)
    ft = _FtStub(_CBBTC_TVM, _CBBTC_OAPP)
    sdk_stub = _TacSdkStub(provider, ft)
    _patch_tac_sdk_create(monkeypatch, sdk_stub)
    helper = await TonEthHelper.create()

    with pytest.raises(RuntimeError, match="Amount is too small for OFT bridge conversion"):
        await helper.sendToETH(
            sender=sender_stub(_RECIPIENT_ETH),
            to_account=_RECIPIENT_ETH,
            asset_id="cbBTC",
            amount=2,
        )


@pytest.mark.asyncio
async def test_ton_eth_helper_rejects_amount_above_oft_max(monkeypatch: pytest.MonkeyPatch) -> None:
    def _quote_oft_max_100(send_param: tuple) -> tuple[tuple[int, int], list, tuple[int, int]]:
        amount = int(send_param[2])
        return ((0, 100), [], (amount, amount))

    provider = _ProviderStub((1000, 7), quote_oft_response=_quote_oft_max_100)
    ft = _FtStub(_CBBTC_TVM, _CBBTC_OAPP)
    sdk_stub = _TacSdkStub(provider, ft)
    _patch_tac_sdk_create(monkeypatch, sdk_stub)
    helper = await TonEthHelper.create()

    with pytest.raises(RuntimeError, match="Amount exceeds OFT bridge limit"):
        await helper.sendToETH(
            sender=sender_stub(_RECIPIENT_ETH),
            to_account=_RECIPIENT_ETH,
            asset_id="cbBTC",
            amount=101,
        )


@pytest.mark.asyncio
async def test_ton_eth_helper_rejects_unknown_asset_id(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _ProviderStub((1000, 7))
    ft = _FtStub(_CBBTC_TVM, _CBBTC_OAPP)
    sdk_stub = _TacSdkStub(provider, ft)
    _patch_tac_sdk_create(monkeypatch, sdk_stub)
    helper = await TonEthHelper.create()

    with pytest.raises(ValueError, match="Unsupported asset_id"):
        await helper.sendToETH(
            sender=sender_stub(_RECIPIENT_ETH),
            to_account=_RECIPIENT_ETH,
            asset_id="unknown-token",
            amount=1,
        )


@pytest.mark.asyncio
async def test_ton_eth_helper_raises_if_wtac_is_not_enough(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _ProviderStub((1000, 7), wtac_balance=100, wtac_allowance=100)
    ft = _FtStub(_CBBTC_TVM, _CBBTC_OAPP)
    sdk_stub = _TacSdkStub(provider, ft)
    _patch_tac_sdk_create(monkeypatch, sdk_stub)
    helper = await TonEthHelper.create()

    with pytest.raises(RuntimeError, match="Insufficient WTAC"):
        await helper.sendToETH(
            sender=sender_stub(_RECIPIENT_ETH),
            to_account=_RECIPIENT_ETH,
            asset_id="cbbtc",
            amount=1,
        )


@pytest.mark.asyncio
async def test_ton_eth_helper_rejects_if_token_balance_is_not_enough(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _ProviderStub((1000, 7))
    ft = _FtStub(_CBBTC_TVM, _CBBTC_OAPP, user_balance=1)
    sdk_stub = _TacSdkStub(provider, ft)
    _patch_tac_sdk_create(monkeypatch, sdk_stub)
    helper = await TonEthHelper.create()

    with pytest.raises(RuntimeError, match="Insufficient token balance"):
        await helper.sendToETH(
            sender=sender_stub(_RECIPIENT_ETH),
            to_account=_RECIPIENT_ETH,
            asset_id="cbbtc",
            amount=2,
        )


@pytest.mark.asyncio
async def test_eth_ton_helper_send_to_ton(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _ProviderStub((1000, 7))
    ft = _FtStub(_CBBTC_TVM, _CBBTC_OAPP)
    sdk_stub = _TacSdkStub(provider, ft)
    _patch_tac_sdk_create(monkeypatch, sdk_stub)
    helper = await EthTonHelper.create()

    result = await helper.sendToTON(
        signer=_TEST_SIGNER_KEY,
        to_account=_RECIPIENT_TON,
        asset_id="cbbtc",
        amount=10,
    )

    account_address = Web3.to_checksum_address(Account.from_key(_TEST_SIGNER_KEY).address)
    assert len(provider.eth.contract_calls) >= 3
    called_addresses = [addr for addr, _abi in provider.eth.contract_calls]
    assert Web3.to_checksum_address(_CBBTC_OAPP) in called_addresses
    assert provider.eth.last_ioft_contract is not None
    assert len(provider.eth.last_ioft_contract.quote_send_calls) == 1
    assert len(provider.eth.last_ioft_contract.send_calls) == 1
    assert provider.eth.last_ioft_contract.send_calls[0][2] == account_address
    send_param = provider.eth.last_ioft_contract.send_calls[0][0]
    assert send_param[4] == bytes.fromhex(_EXPECTED_COMPOSE_OPTIONS[2:])
    assert provider.eth.sent_raw_transactions == [b"\x01"]
    assert provider.eth.wait_receipt_calls == [("0xdeadbeef", 300)]

    assert result.asset_id == "cbbtc"
    assert result.amount == 10
    assert result.value == 1050
    assert result.to_account == _RECIPIENT_TON
    assert result.token_tvm_address == _CBBTC_TVM
    assert result.token_evm_address == Web3.to_checksum_address(_CBBTC_OAPP)
    assert result.transaction_hash == "0xdeadbeef"


@pytest.mark.asyncio
async def test_eth_ton_helper_rejects_if_token_balance_is_not_enough(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _ProviderStub((1000, 7), wtac_balance=10**30, wtac_allowance=10**30, ioft_token_balance=1)
    ft = _FtStub(_CBBTC_TVM, _CBBTC_OAPP)
    sdk_stub = _TacSdkStub(provider, ft)
    _patch_tac_sdk_create(monkeypatch, sdk_stub)
    helper = await EthTonHelper.create()

    with pytest.raises(RuntimeError, match="Insufficient token balance"):
        await helper.sendToTON(
            signer=_TEST_SIGNER_KEY,
            to_account=_RECIPIENT_TON,
            asset_id="cbbtc",
            amount=2,
        )


@pytest.mark.asyncio
async def test_eth_ton_helper_rejects_too_small_amount_after_quote_oft(monkeypatch: pytest.MonkeyPatch) -> None:
    def _quote_oft_threshold(send_param: tuple) -> tuple[tuple[int, int], list, tuple[int, int]]:
        amount = int(send_param[2])
        if amount >= 10:
            return ((0, 2**256 - 1), [], (amount, amount))
        return ((0, 2**256 - 1), [], (0, 0))

    provider = _ProviderStub((1000, 7), quote_oft_response=_quote_oft_threshold)
    ft = _FtStub(_CBBTC_TVM, _CBBTC_OAPP)
    sdk_stub = _TacSdkStub(provider, ft)
    _patch_tac_sdk_create(monkeypatch, sdk_stub)
    helper = await EthTonHelper.create()

    with pytest.raises(RuntimeError, match="Amount is too small for OFT bridge conversion"):
        await helper.sendToTON(
            signer=_TEST_SIGNER_KEY,
            to_account=_RECIPIENT_TON,
            asset_id="cbbtc",
            amount=2,
        )


@pytest.mark.asyncio
async def test_eth_ton_helper_rejects_amount_above_oft_max(monkeypatch: pytest.MonkeyPatch) -> None:
    def _quote_oft_max_100(send_param: tuple) -> tuple[tuple[int, int], list, tuple[int, int]]:
        amount = int(send_param[2])
        return ((0, 100), [], (amount, amount))

    provider = _ProviderStub((1000, 7), quote_oft_response=_quote_oft_max_100)
    ft = _FtStub(_CBBTC_TVM, _CBBTC_OAPP)
    sdk_stub = _TacSdkStub(provider, ft)
    _patch_tac_sdk_create(monkeypatch, sdk_stub)
    helper = await EthTonHelper.create()

    with pytest.raises(RuntimeError, match="Amount exceeds OFT bridge limit"):
        await helper.sendToTON(
            signer=_TEST_SIGNER_KEY,
            to_account=_RECIPIENT_TON,
            asset_id="cbbtc",
            amount=101,
        )


def test_build_executor_compose_options_matches_js_value() -> None:
    assert build_executor_compose_options(0, 5_000_000, 0) == _EXPECTED_COMPOSE_OPTIONS


def test_build_executor_compose_options_rejects_negative_values() -> None:
    with pytest.raises(ValueError, match="index must be >= 0"):
        build_executor_compose_options(-1, 5_000_000, 0)
    with pytest.raises(ValueError, match="gas_limit must be >= 0"):
        build_executor_compose_options(0, -1, 0)
    with pytest.raises(ValueError, match="native_drop must be >= 0"):
        build_executor_compose_options(0, 5_000_000, -1)


def test_build_executor_compose_options_rejects_out_of_range_values() -> None:
    with pytest.raises(ValueError, match="index must be <="):
        build_executor_compose_options(1 << 16, 5_000_000, 0)
    with pytest.raises(ValueError, match="gas_limit must be <="):
        build_executor_compose_options(0, 1 << 128, 0)
    with pytest.raises(ValueError, match="native_drop must be <="):
        build_executor_compose_options(0, 5_000_000, 1 << 128)


@pytest.mark.asyncio
async def test_layer_zero_bridge_helper_delegates_both_directions(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _ProviderStub((3000, 11))
    ft = _FtStub(_CBBTC_TVM, _CBBTC_OAPP)
    sdk_stub = _TacSdkStub(provider, ft)
    _patch_tac_sdk_create(monkeypatch, sdk_stub)
    helper = await LayerZeroBridgeHelper.create()

    to_eth = await helper.sendToETH(
        sender=sender_stub(_RECIPIENT_ETH),
        to_account=_RECIPIENT_ETH,
        asset_id="cbbtc",
        amount=2,
    )
    to_ton = await helper.sendToTON(
        signer=_TEST_SIGNER_KEY,
        to_account=_RECIPIENT_TON,
        asset_id="cbbtc",
        amount=5,
    )

    assert to_eth.fee_quote.native_fee == 3000
    assert to_eth.fee_quote.lz_token_fee == 11
    assert to_ton.amount == 5
    assert len(sdk_stub.send_calls) == 1
    assert provider.eth.last_ioft_contract is not None
    assert len(provider.eth.last_ioft_contract.send_calls) == 1


@pytest.mark.asyncio
async def test_eth_ton_helper_raises_if_wtac_is_not_enough(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _ProviderStub((1000, 7), wtac_balance=1, wtac_allowance=1)
    ft = _FtStub(_CBBTC_TVM, _CBBTC_OAPP)
    sdk_stub = _TacSdkStub(provider, ft)
    _patch_tac_sdk_create(monkeypatch, sdk_stub)
    helper = await EthTonHelper.create()

    with pytest.raises(RuntimeError, match="Insufficient WTAC"):
        await helper.sendToTON(
            signer=_TEST_SIGNER_KEY,
            to_account=_RECIPIENT_TON,
            asset_id="cbbtc",
            amount=10,
        )


@pytest.mark.asyncio
async def test_removed_ton_eth_optional_kwargs_raise_type_error(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _ProviderStub((1000, 7))
    ft = _FtStub(_CBBTC_TVM, _CBBTC_OAPP)
    sdk_stub = _TacSdkStub(provider, ft)
    _patch_tac_sdk_create(monkeypatch, sdk_stub)
    helper = await TonEthHelper.create()

    with pytest.raises(TypeError):
        await helper.sendToETH(
            sender=sender_stub(_RECIPIENT_ETH),
            to_account=_RECIPIENT_ETH,
            asset_id="cbbtc",
            amount=1,
            min_amount_ld=0,  # type: ignore[call-arg]
        )


@pytest.mark.asyncio
async def test_removed_eth_ton_optional_kwargs_raise_type_error(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _ProviderStub((1000, 7))
    ft = _FtStub(_CBBTC_TVM, _CBBTC_OAPP)
    sdk_stub = _TacSdkStub(provider, ft)
    _patch_tac_sdk_create(monkeypatch, sdk_stub)
    helper = await EthTonHelper.create()

    with pytest.raises(TypeError):
        await helper.sendToTON(
            signer=_TEST_SIGNER_KEY,
            to_account=_RECIPIENT_TON,
            asset_id="cbbtc",
            amount=10,
            value=1,  # type: ignore[call-arg]
        )


@pytest.mark.asyncio
async def test_removed_bridge_optional_kwargs_raise_type_error(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _ProviderStub((1000, 7))
    ft = _FtStub(_CBBTC_TVM, _CBBTC_OAPP)
    sdk_stub = _TacSdkStub(provider, ft)
    _patch_tac_sdk_create(monkeypatch, sdk_stub)
    helper = await LayerZeroBridgeHelper.create()

    with pytest.raises(TypeError):
        await helper.sendToETH(
            sender=sender_stub(_RECIPIENT_ETH),
            to_account=_RECIPIENT_ETH,
            asset_id="cbbtc",
            amount=1,
            min_amount_ld=0,  # type: ignore[call-arg]
        )

    with pytest.raises(TypeError):
        await helper.sendToTON(
            signer=_TEST_SIGNER_KEY,
            to_account=_RECIPIENT_TON,
            asset_id="cbbtc",
            amount=10,
            value=1,  # type: ignore[call-arg]
        )
