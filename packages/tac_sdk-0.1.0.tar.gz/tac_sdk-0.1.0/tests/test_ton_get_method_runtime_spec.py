from __future__ import annotations

import base64
from typing import Any

import pytest
from pytoniq_core.boc.address import Address
from pytoniq_core.tlb.vm_stack import VmStack

from ton_get_methods.runtime import run_get_method


class _TonClient4LikeStub:
    def __init__(self, result_raw: str) -> None:
        self.result_raw = result_raw

    def _run_method_raw(self, address: Any, method: str) -> dict[str, Any]:
        _ = (address, method)
        return {"resultRaw": self.result_raw}


@pytest.mark.asyncio
async def test_run_get_method_parses_result_raw_vm_stack() -> None:
    stack_cell = VmStack.serialize([123])
    result_raw = base64.b64encode(stack_cell.to_boc()).decode("utf-8")
    opener = _TonClient4LikeStub(result_raw=result_raw)

    stack = await run_get_method(
        opener,
        Address("EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c"),
        "seqno",
        [],
    )

    assert stack[0] == 123
