from __future__ import annotations

from types import SimpleNamespace
from typing import Any, cast

import pytest

import sdk.ton_transaction_manager as ton_tm_module
from sdk.ton_transaction_manager import TonTransactionManager
from structs.internal_struct import SendResult
from structs.struct import CrosschainTx, EvmProxyMsg, Network, WaitOptions


class _LoggerStub:
    def debug(self, *args: object) -> None:
        _ = args

    def info(self, *args: object) -> None:
        _ = args

    def error(self, *args: object) -> None:
        _ = args


class _OpenerStub:
    def __init__(self) -> None:
        self.calls: list[tuple[str, str, dict[str, Any]]] = []

    async def trackTransactionTree(self, address: str, hash_value: str, params: dict[str, Any]) -> None:  # noqa: N802
        self.calls.append((address, hash_value, params))


class _SenderStub:
    def __init__(self, boc: str) -> None:
        self._boc = boc

    async def sendShardTransaction(self, *args: Any, **kwargs: Any) -> SendResult:  # noqa: N802
        _ = (args, kwargs)
        return SendResult(success=True, boc=self._boc, result={"ok": True})

    async def sendShardTransactions(self, *args: Any, **kwargs: Any) -> list[SendResult]:  # noqa: N802
        _ = (args, kwargs)
        return [SendResult(success=True, boc=self._boc, result={"ok": True}, lastMessageIndex=0)]

    def getSenderAddress(self) -> str:  # noqa: N802
        return "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c"

    async def getBalance(self, *args: Any, **kwargs: Any) -> int:  # noqa: N802
        _ = (args, kwargs)
        return 0

    async def getBalanceOf(self, *args: Any, **kwargs: Any) -> int:  # noqa: N802
        _ = (args, kwargs)
        return 0


class _TrackerStub:
    async def getOperationId(self, *args: Any, **kwargs: Any) -> str:  # noqa: N802
        _ = (args, kwargs)
        return "operation-id"


@pytest.mark.asyncio
async def test_send_cross_chain_transaction_tracks_tree_by_default_even_with_custom_wait_options(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    opener = _OpenerStub()
    config = SimpleNamespace(
        network=Network.TESTNET,
        TONParams={"contractOpener": opener},
    )
    manager = TonTransactionManager(
        cast(Any, config),
        simulator=cast(Any, SimpleNamespace()),
        operationTracker=cast(Any, _TrackerStub()),
        logger=cast(Any, _LoggerStub()),
    )

    async def _fake_prepare(*args: Any, **kwargs: Any) -> dict[str, Any]:
        _ = (args, kwargs)
        return {
            "transaction": {"messages": [], "network": Network.TESTNET, "validUntil": 0},
            "transactionLinker": {
                "caller": "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c",
                "shardCount": 1,
                "shardsKey": "1",
                "timestamp": 1,
                "sendTransactionResult": None,
            },
        }

    async def _fake_check_balance(*args: Any, **kwargs: Any) -> None:
        _ = (args, kwargs)
        return None

    class _FakeCellResult:
        @staticmethod
        def begin_parse() -> object:
            return object()

    class _FakeCellType:
        @staticmethod
        def one_from_boc(_boc: bytes) -> _FakeCellResult:
            return _FakeCellResult()

    class _FakeMessageAny:
        @staticmethod
        def deserialize(_slice: object) -> object:
            return object()

    monkeypatch.setattr(manager, "_prepareCrossChainTransaction", _fake_prepare)
    monkeypatch.setattr(ton_tm_module.Ton, "checkBalance", _fake_check_balance)
    monkeypatch.setattr(ton_tm_module, "Cell", _FakeCellType)
    monkeypatch.setattr(ton_tm_module, "MessageAny", _FakeMessageAny)
    monkeypatch.setattr(ton_tm_module, "get_normalized_ext_message_hash", lambda _msg: "tx-hash")

    tx: CrosschainTx = {
        "evmProxyMsg": {"evmTargetAddress": "0x1111111111111111111111111111111111111111"},
        "assets": [],
        "options": {
            "waitOperationId": True,
            "waitOptions": WaitOptions[str, Any](timeout=1000, maxAttempts=1, delay=100),
        },
    }
    evm_proxy_msg: EvmProxyMsg = {"evmTargetAddress": "0x1111111111111111111111111111111111111111"}
    sender = _SenderStub("ZmFrZQ==")

    await manager.sendCrossChainTransaction(evm_proxy_msg, cast(Any, sender), tx)

    assert len(opener.calls) == 1
    assert opener.calls[0][1] == "tx-hash"


@pytest.mark.asyncio
async def test_send_cross_chain_transaction_skips_tree_when_ensure_tx_executed_false(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    opener = _OpenerStub()
    config = SimpleNamespace(
        network=Network.TESTNET,
        TONParams={"contractOpener": opener},
    )
    manager = TonTransactionManager(
        cast(Any, config),
        simulator=cast(Any, SimpleNamespace()),
        operationTracker=cast(Any, _TrackerStub()),
        logger=cast(Any, _LoggerStub()),
    )

    async def _fake_prepare(*args: Any, **kwargs: Any) -> dict[str, Any]:
        _ = (args, kwargs)
        return {
            "transaction": {"messages": [], "network": Network.TESTNET, "validUntil": 0},
            "transactionLinker": {
                "caller": "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c",
                "shardCount": 1,
                "shardsKey": "1",
                "timestamp": 1,
                "sendTransactionResult": None,
            },
        }

    async def _fake_check_balance(*args: Any, **kwargs: Any) -> None:
        _ = (args, kwargs)
        return None

    monkeypatch.setattr(manager, "_prepareCrossChainTransaction", _fake_prepare)
    monkeypatch.setattr(ton_tm_module.Ton, "checkBalance", _fake_check_balance)

    tx: CrosschainTx = {
        "evmProxyMsg": {"evmTargetAddress": "0x1111111111111111111111111111111111111111"},
        "assets": [],
        "options": {
            "waitOperationId": True,
            "waitOptions": WaitOptions[str, Any](ensureTxExecuted=False),
        },
    }
    evm_proxy_msg: EvmProxyMsg = {"evmTargetAddress": "0x1111111111111111111111111111111111111111"}
    sender = _SenderStub("ZmFrZQ==")

    await manager.sendCrossChainTransaction(evm_proxy_msg, cast(Any, sender), tx)

    assert opener.calls == []
