from __future__ import annotations

import importlib
from types import SimpleNamespace
from typing import Any, cast

import pytest
from pytoniq_core.tlb.transaction import Transaction

from adapters.base_contract_opener import base_contract_opener
from structs.struct import AddressInformation, GetTransactionsOptions

base_contract_opener_module = importlib.import_module("adapters.base_contract_opener")


class _DelayedTxOpener(base_contract_opener):
    def __init__(self, appear_on_attempt: int) -> None:
        super().__init__()
        self.appear_on_attempt = appear_on_attempt
        self.search_calls = 0
        self.info_calls = 0

    def open(self, src: Any) -> Any:
        return src

    async def getContractState(self, address: Any) -> dict[str, Any]:  # noqa: N802
        _ = address
        return {"balance": 0, "state": "active", "code": None}

    async def getTransactions(self, address: Any, opts: GetTransactionsOptions) -> list[Transaction]:  # noqa: N802
        _ = (address, opts)
        return []

    async def getAddressInformation(self, address: Any) -> AddressInformation:  # noqa: N802
        _ = address
        self.info_calls += 1
        # JS-like behavior: root search is retried only after lt changes.
        return {"lastTransaction": {"lt": str(self.info_calls), "hash": ""}}

    async def getConfig(self) -> str:  # noqa: N802
        return ""

    async def findTransactionByHashType(  # noqa: N802
        self,
        address: Any,
        hash_value: str,
        hash_type: str | None,
        opts: GetTransactionsOptions,
    ) -> Transaction | None:
        _ = (address, hash_value, hash_type, opts)
        self.search_calls += 1
        if self.search_calls < self.appear_on_attempt:
            return None
        return cast(
            Transaction,
            SimpleNamespace(
                description=SimpleNamespace(aborted=False, compute_ph=None, action=None),
                out_msgs=[],
                in_msg=None,
                cell=None,
            ),
        )


@pytest.mark.asyncio
async def test_track_tree_waits_for_initial_hash_by_default(monkeypatch: pytest.MonkeyPatch) -> None:
    async def _no_sleep(_: float) -> None:
        return None

    monkeypatch.setattr(base_contract_opener_module.asyncio, "sleep", _no_sleep)
    opener = _DelayedTxOpener(appear_on_attempt=3)
    result = await opener.trackTransactionTreeWithResult(
        "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",
        {},
    )
    assert result.get("success") is True
    assert opener.search_calls == 3


@pytest.mark.asyncio
async def test_track_tree_can_skip_wait_for_initial_hash(monkeypatch: pytest.MonkeyPatch) -> None:
    async def _no_sleep(_: float) -> None:
        return None

    monkeypatch.setattr(base_contract_opener_module.asyncio, "sleep", _no_sleep)
    opener = _DelayedTxOpener(appear_on_attempt=3)
    result = await opener.trackTransactionTreeWithResult(
        "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",
        {"waitForRootTransaction": False},
    )
    assert result.get("success") is False
    error = result.get("error")
    assert error is not None
    assert error.get("reason") == "not_found"
    assert opener.search_calls == 1

_delayed_tx_opener = _DelayedTxOpener


class _FailedTxOpener(base_contract_opener):
    def __init__(self) -> None:
        super().__init__()
        self.calls = 0

    def open(self, src: Any) -> Any:
        return src

    async def getContractState(self, address: Any) -> dict[str, Any]:  # noqa: N802
        _ = address
        return {"balance": 0, "state": "active", "code": None}

    async def getTransactions(self, address: Any, opts: GetTransactionsOptions) -> list[Transaction]:  # noqa: N802
        _ = (address, opts)
        return []

    async def getAddressInformation(self, address: Any) -> AddressInformation:  # noqa: N802
        _ = address
        return {"lastTransaction": {"lt": "", "hash": ""}}

    async def getConfig(self) -> str:  # noqa: N802
        return ""

    async def findTransactionByHashType(  # noqa: N802
        self,
        address: Any,
        hash_value: str,
        hash_type: str | None,
        opts: GetTransactionsOptions,
    ) -> Transaction | None:
        _ = (address, hash_value, hash_type, opts)
        self.calls += 1
        return cast(
            Transaction,
            SimpleNamespace(
                description=SimpleNamespace(
                    type_="ordinary",
                    aborted=False,
                    compute_ph=SimpleNamespace(type_="vm", success=False, exit_code=204),
                    action=None,
                ),
                out_msgs=[],
                in_msg=None,
                cell=SimpleNamespace(hash=b"\x01" * 32),
            ),
        )


@pytest.mark.asyncio
async def test_track_tree_stops_on_exit_code_204(monkeypatch: pytest.MonkeyPatch) -> None:
    async def _no_sleep(_: float) -> None:
        return None

    monkeypatch.setattr(base_contract_opener_module.asyncio, "sleep", _no_sleep)
    opener = _FailedTxOpener()
    result = await opener.trackTransactionTreeWithResult(
        "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",
        {},
    )
    assert result.get("success") is False
    error = result.get("error")
    assert error is not None
    assert error.get("reason") == "compute_phase_failed"
    assert error.get("exitCode") == 204
    assert opener.calls == 1
