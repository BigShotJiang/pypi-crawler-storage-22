from __future__ import annotations

import inspect
from typing import Any

from pytoniq_core.boc.address import Address

from interfaces.i_configuration import IConfiguration
from structs.struct import TVMAddress
from ton_get_methods.runtime import run_get_method


class TonGetMethodClient:
    @classmethod
    async def run_get_method(
        cls,
        configuration: IConfiguration,
        address: TVMAddress | Address,
        method: str,
        stack: list[Any] | None = None,
    ) -> list[Any]:
        opener = configuration.TONParams.get("contractOpener")
        if opener is None:
            raise RuntimeError("contractOpener is required")
        return await run_get_method(opener, address, method, stack or [])

    @staticmethod
    async def await_maybe(value: Any) -> Any:
        if inspect.isawaitable(value):
            return await value
        return value
