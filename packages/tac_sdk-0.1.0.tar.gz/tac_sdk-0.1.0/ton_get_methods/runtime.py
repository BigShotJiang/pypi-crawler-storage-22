from __future__ import annotations

import base64
import inspect
from typing import Any, cast

from pytoniq_core.boc.address import Address, ExternalAddress
from pytoniq_core.boc.cell import Cell
from pytoniq_core.boc.slice import Slice
from pytoniq_core.tlb.vm_stack import VmStack


def _decode_boc_cell(value: str) -> Cell | None:
    normalized = value.replace("-", "+").replace("_", "/")
    padded = normalized + "=" * ((4 - len(normalized) % 4) % 4)
    try:
        cell = Cell.one_from_boc(base64.b64decode(padded))
    except Exception:
        return None
    if isinstance(cell, list):
        return cell[0] if cell else None
    return cell


def _stack_value_to_cell(value: Any) -> Cell | None:
    if isinstance(value, Cell):
        return value
    if isinstance(value, Slice):
        return value.to_cell()
    raw_boc: str | None = None
    if isinstance(value, dict):
        raw_boc = cast(str | None, value.get("bytes") or value.get("data"))
    elif isinstance(value, str):
        raw_boc = value
    if not raw_boc:
        return None
    return _decode_boc_cell(raw_boc)


def _normalize_stack_item(item: Any) -> Any:
    if isinstance(item, list) and len(item) >= 2 and isinstance(item[0], str):
        item_type = item[0]
        value = item[1]
        if item_type == "num":
            if isinstance(value, str):
                return int(value, 16) if value.startswith(("0x", "-0x", "+0x")) else int(value)
            return int(value)
        if item_type in ("cell", "tvm.Cell"):
            cell = _stack_value_to_cell(value)
            return cell if cell is not None else item
        if item_type in ("slice", "tvm.Slice"):
            cell = _stack_value_to_cell(value)
            return cell.begin_parse() if cell is not None else item
    return item


def _normalize_stack(stack: list[Any]) -> list[Any]:
    return [_normalize_stack_item(item) for item in stack]


def _parse_result_raw_stack(result_raw: str) -> list[Any]:
    stack_cell = _decode_boc_cell(result_raw)
    if stack_cell is None:
        return []
    stack = VmStack.deserialize(stack_cell.begin_parse())
    if stack is None:
        return []
    return list(stack) if not isinstance(stack, list) else stack


async def _run_get_method_with_opener(
    opener: Any,
    address: Address,
    method: str,
    stack: list[Any],
) -> list[Any]:
    client = getattr(opener, "client", None)
    if client is not None and hasattr(client, "run_get_method"):
        result = client.run_get_method(address, method, stack)
        if inspect.isawaitable(result):
            result = await result
        if isinstance(result, list):
            return result
        return _normalize_stack(cast(list[Any], result or []))

    run_get_method = getattr(opener, "_run_get_method", None)
    if callable(run_get_method):
        try:
            result = run_get_method(address, method, stack)
        except TypeError:
            result = run_get_method(address, method)
        if inspect.isawaitable(result):
            result = await result
        if isinstance(result, dict):
            return _normalize_stack(cast(list[Any], result.get("stack") or []))
        if isinstance(result, list):
            return _normalize_stack(result)
        return []

    run_method_raw = getattr(opener, "_run_method_raw", None)
    if callable(run_method_raw):
        if stack:
            raise RuntimeError(f"{opener.__class__.__name__} does not support stack arguments for '{method}'")
        result = run_method_raw(address, method)
        if inspect.isawaitable(result):
            result = await result
        if isinstance(result, dict):
            stack_value = result.get("stack")
            if isinstance(stack_value, list):
                return _normalize_stack(stack_value)
            result_raw = result.get("resultRaw")
            if isinstance(result_raw, str) and result_raw:
                return _parse_result_raw_stack(result_raw)
        return []

    raise RuntimeError("contractOpener does not support run_get_method")


async def run_get_method(
    opener: Any,
    address: Address | str,
    method: str,
    stack: list[Any] | None = None,
) -> list[Any]:
    address_obj = Address(address) if isinstance(address, str) else address
    stack_args = stack or []

    execute_with_fallback = getattr(opener, "executeWithFallback", None)
    if callable(execute_with_fallback):

        async def _call(config: Any) -> list[Any]:
            return await _run_get_method_with_opener(config.opener, address_obj, method, stack_args)

        result = await cast(Any, execute_with_fallback)(_call)
        if result.get("success"):
            return cast(list[Any], result.get("data") or [])
        raise result.get("lastError") or RuntimeError("contractOpener does not support run_get_method")

    return await _run_get_method_with_opener(opener, address_obj, method, stack_args)


def stack_item_as_cell(item: Any) -> Cell | None:
    return _stack_value_to_cell(item)


def stack_item_as_slice(item: Any) -> Slice | None:
    if isinstance(item, Slice):
        return item
    cell = _stack_value_to_cell(item)
    return cell.begin_parse() if cell is not None else None


def stack_item_as_int(item: Any) -> int | None:
    if isinstance(item, bool):
        return 1 if item else 0
    if isinstance(item, int):
        return item
    if isinstance(item, str):
        try:
            return int(item, 16) if item.startswith(("0x", "-0x", "+0x")) else int(item)
        except Exception:
            return None
    if isinstance(item, list) and len(item) >= 2 and item[0] == "num":
        return stack_item_as_int(item[1])
    return None


def stack_item_as_address(item: Any) -> Address | None:
    if isinstance(item, Address):
        return item
    if isinstance(item, str):
        try:
            return Address(item)
        except Exception:
            return None
    slice_item = stack_item_as_slice(item)
    if slice_item is None:
        return None
    try:
        loaded = slice_item.load_address()
        if isinstance(loaded, ExternalAddress):
            return None
        return loaded
    except Exception:
        return None


def stack_item_as_string(item: Any) -> str | None:
    if isinstance(item, str):
        return item
    slice_item = stack_item_as_slice(item)
    if slice_item is None:
        return None
    try:
        return slice_item.load_string()
    except Exception:
        try:
            return slice_item.load_snake_string()
        except Exception:
            return None
