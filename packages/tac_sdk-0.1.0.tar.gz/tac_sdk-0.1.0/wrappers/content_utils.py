from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256

import requests
from pytoniq_core.boc.builder import Builder
from pytoniq_core.boc.cell import Cell
from pytoniq_core.boc.hashmap.hashmap import HashMap
from pytoniq_core.boc.slice import Slice

from errors import not_multiply_of_8_error, prefix_error, unsupported_format_error, unsupported_key_error

ONCHAIN_CONTENT_PREFIX = 0x00
OFFCHAIN_CONTENT_PREFIX = 0x01
SNAKE_PREFIX = 0x00


@dataclass
class JettonMetadata:
    uri: str | None = None
    name: str = ""
    description: str = ""
    image: str | None = None
    image_data: str | None = None
    symbol: str = ""
    decimals: str | None = None


JettonMetaDataKeys = str


_JETTON_ONCHAIN_METADATA_SPEC: dict[str, str | None] = {
    "uri": "ascii",
    "name": "utf8",
    "description": "utf8",
    "image": "ascii",
    "image_data": "ascii",
    "symbol": "utf8",
    "decimals": "utf8",
}


def _sha256_bytes(value: str) -> bytes:
    return sha256(value.encode("utf-8")).digest()


def _store_snake_content(content: bytes, is_first: bool) -> Cell:
    cell = Builder()
    if is_first:
        cell.store_uint(SNAKE_PREFIX, 8)
    # leave room for refs
    max_bytes = cell.available_bytes
    cell.store_bytes(content[:max_bytes])
    remaining = content[max_bytes:]
    if remaining:
        cell.store_ref(_store_snake_content(remaining, False))
    return cell.end_cell()


def build_jetton_offchain_metadata(content_uri: str) -> Cell:
    return Builder().store_uint(OFFCHAIN_CONTENT_PREFIX, 8).store_snake_string(content_uri).end_cell()


def build_jetton_onchain_metadata(_data: jetton_metadata) -> Cell:
    dict_ = HashMap(256)

    for key, encoding in _JETTON_ONCHAIN_METADATA_SPEC.items():
        value = getattr(_data, key, None)
        if encoding is None:
            raise unsupported_key_error(key)
        if value is None or value == "":
            continue
        raw = str(value).encode(encoding)
        dict_.set_int_key(int.from_bytes(_sha256_bytes(key), "big"), _store_snake_content(raw, True))

    dict_cell = dict_.serialize()
    return (
        Builder()
        .store_uint(ONCHAIN_CONTENT_PREFIX, 8)
        .store_dict(dict_cell)
        .end_cell()
    )


def read_jetton_metadata(_content_cell: object) -> dict[str, object]:
    if not isinstance(_content_cell, Cell) or len(_content_cell.bits) == 0:
        return {
            "persistenceType": "none",
            "metadata": {},
            "isJettonDeployerFaultyOnChainData": False,
            "contentUri": None,
        }

    content_slice = _content_cell.begin_parse()
    prefix = content_slice.load_uint(8)

    if prefix == ONCHAIN_CONTENT_PREFIX:
        metadata, faulty = _parse_onchain_metadata(content_slice)
        return {
            "persistenceType": "onchain",
            "metadata": metadata,
            "isJettonDeployerFaultyOnChainData": faulty,
            "contentUri": None,
        }
    if prefix == OFFCHAIN_CONTENT_PREFIX:
        metadata, is_ipfs, content_uri = _parse_offchain_metadata(content_slice)
        return {
            "persistenceType": "offchain_ipfs" if is_ipfs else "offchain_private_domain",
            "metadata": metadata or {},
            "isJettonDeployerFaultyOnChainData": False,
            "contentUri": content_uri,
        }
    raise prefix_error


def _read_snake_content(slice_: Slice, is_first: bool) -> bytes:
    if is_first and slice_.load_uint(8) != SNAKE_PREFIX:
        raise unsupported_format_error

    if slice_.remaining_bits % 8 != 0:
        raise not_multiply_of_8_error

    remaining = b""
    if slice_.remaining_bits:
        remaining = slice_.load_bytes(slice_.remaining_bits // 8)

    if slice_.remaining_refs:
        next_cell = slice_.load_ref()
        remaining += _read_snake_content(next_cell.begin_parse(), False)

    return remaining


def _parse_onchain_metadata(content_slice: Slice) -> tuple[dict[str, str], bool]:
    from pytoniq_core.boc.hashmap.hashmap import HashMap

    # Dictionary stored directly without maybe-flag
    dict_data = HashMap.parse(content_slice, 256, value_deserializer=lambda s: s.to_cell()) or {}

    res: dict[str, str] = {}
    for key, encoding in _JETTON_ONCHAIN_METADATA_SPEC.items():
        if encoding is None:
            continue
        dict_key = int.from_bytes(_sha256_bytes(key), "big")
        cell = dict_data.get(dict_key)
        if cell is None:
            continue
        value_bytes = _read_snake_content(cell.begin_parse(), True)
        res[key] = value_bytes.decode(encoding)

    return res, False


def _parse_offchain_metadata(content_slice: Slice) -> tuple[dict | None, bool | None, str]:
    if content_slice.remaining_bits % 8 != 0:
        raise not_multiply_of_8_error

    uri = content_slice.load_bytes(content_slice.remaining_bits // 8).decode("utf-8")
    uri = uri.replace("ipfs://", "https://ipfs.io/ipfs/")

    metadata = None
    is_ipfs = None
    try:
        response = requests.get(uri, timeout=10)
        response.raise_for_status()
        metadata = response.json()
        is_ipfs = bool("ipfs" in uri)
    except Exception:
        pass
    return metadata, is_ipfs, uri

jetton_metadata = JettonMetadata
