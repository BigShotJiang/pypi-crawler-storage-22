from __future__ import annotations

BIT_NUMBER_SIZE = 10
MAX_BIT_NUMBER = 1022
MAX_SHIft = 8191


class HighloadQueryId:
    def __init__(self) -> None:
        self.shift = 0
        self.bitnumber = 0

    @staticmethod
    def from_shift_and_bit_number(shift: int, bitnumber: int) -> highload_query_id:
        q = highload_query_id()
        q.shift = shift
        if q.shift < 0 or q.shift > MAX_SHIft:
            raise ValueError("invalid shift")
        q.bitnumber = bitnumber
        if q.bitnumber < 0 or q.bitnumber > MAX_BIT_NUMBER:
            raise ValueError("invalid bitnumber")
        return q

    def get_next(self) -> highload_query_id:
        new_bitnumber = self.bitnumber + 1
        new_shift = self.shift

        if new_shift == MAX_SHIft and new_bitnumber > MAX_BIT_NUMBER - 1:
            raise ValueError("Overload")

        if new_bitnumber > MAX_BIT_NUMBER:
            new_bitnumber = 0
            new_shift += 1
            if new_shift > MAX_SHIft:
                raise ValueError("Overload")

        return highload_query_id.from_shift_and_bit_number(new_shift, new_bitnumber)

    def has_next(self) -> bool:
        is_end = self.bitnumber >= MAX_BIT_NUMBER - 1 and self.shift == MAX_SHIft
        return not is_end

    def get_shift(self) -> int:
        return self.shift

    def get_bit_number(self) -> int:
        return self.bitnumber

    def get_query_id(self) -> int:
        return (self.shift << BIT_NUMBER_SIZE) + self.bitnumber

    @staticmethod
    def from_query_id(query_id: int) -> highload_query_id:
        shift = query_id >> BIT_NUMBER_SIZE
        bitnumber = query_id & 1023
        return highload_query_id.from_shift_and_bit_number(shift, bitnumber)

    @staticmethod
    def from_seqno(seqno: int) -> highload_query_id:
        shift = seqno // 1023
        bitnumber = seqno % 1023
        return highload_query_id.from_shift_and_bit_number(shift, bitnumber)

    def to_seqno(self) -> int:
        return self.bitnumber + self.shift * 1023

highload_query_id = HighloadQueryId
