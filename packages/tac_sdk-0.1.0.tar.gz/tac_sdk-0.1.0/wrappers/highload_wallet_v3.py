from __future__ import annotations

import time
from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any, cast

from pytoniq.contract.wallets.highload_v3 import HIGHLOAD_V3_WALLET_CODE
from pytoniq.contract.wallets.highload_v3 import HighloadWalletV3 as pytoniq_highload_wallet_v3
from pytoniq.contract.wallets.wallet import Wallet
from pytoniq_core.boc.address import Address
from pytoniq_core.boc.builder import Builder
from pytoniq_core.boc.cell import Cell
from pytoniq_core.crypto.signature import sign_message
from pytoniq_core.tlb.account import StateInit
from pytoniq_core.tlb.custom.wallet import WalletMessage

from wrappers.highload_query_id import highload_query_id

DEFAULT_SUBWALLET_ID = 0x10AD
DEFAULT_TIMEOUT = 60 * 60
_HIGHLOAD_SEQNO_MOD = 1023 * 8192


@dataclass
class HighloadWalletV3:
    address: Address
    init: StateInit | None
    public_key: bytes
    subwallet_id: int = DEFAULT_SUBWALLET_ID
    timeout: int = DEFAULT_TIMEOUT

    @staticmethod
    def create(public_key: bytes, workchain: int = 0, subwallet_id: int | None = None, timeout: int | None = None) -> highload_wallet_v3:
        wallet_id = subwallet_id if subwallet_id is not None else DEFAULT_SUBWALLET_ID
        ttl = timeout if timeout is not None else DEFAULT_TIMEOUT
        data = pytoniq_highload_wallet_v3.create_data_cell(public_key, wallet_id=wallet_id, wc=workchain, timeout=ttl)
        init = StateInit(code=HIGHLOAD_V3_WALLET_CODE, data=data)
        address = Address((workchain, init.serialize().hash))
        return highload_wallet_v3(address=address, init=init, public_key=public_key, subwallet_id=wallet_id, timeout=ttl)

    @staticmethod
    def generate_created_at() -> int:
        return int(time.time()) - 40

    def getQueryIdFromCreatedAt(self, created_at: int) -> int:
        # Keep query id in valid HighloadV3 domain and avoid reserved bit 1023.
        seqno = created_at % _HIGHLOAD_SEQNO_MOD
        return highload_query_id.from_seqno(seqno).get_query_id()

    def _pack_actions(self, messages: list[WalletMessage], query_id: int) -> WalletMessage:
        # Ported from pytoniq highload_wallet_v3.pack_actions
        message_per_pack = 253
        if len(messages) > message_per_pack:
            rest = self._pack_actions(messages[message_per_pack:], query_id)
            messages = messages[:message_per_pack] + [rest]

        amt = 0
        list_cell = Cell.empty()
        for msg in messages:
            msg_info = cast(Any, msg.message.info)
            amt += int(msg_info.value.grams)
            msg_cell = (
                Builder()
                .store_uint(0x0EC3C86D, 32)
                .store_uint(msg.send_mode, 8)
                .store_ref(msg.message.serialize())
                .end_cell()
            )
            list_cell = Builder().store_ref(list_cell).store_cell(msg_cell).end_cell()

        # attach some coins for internal message processing gas fees
        fees = 7 * 10**6 * len(messages) + 10**7
        amt += fees

        return Wallet.create_wallet_internal_message(
            destination=self.address,
            send_mode=3,
            value=amt,
            body=Builder()
            .store_uint(0xAE42E5A4, 32)
            .store_uint(query_id, 64)
            .store_ref(list_cell)
            .end_cell(),
        )

    def getExternalMessage(self, messages: list[Any], send_mode: Any, value: int, query_id: int) -> Any:
        wallet_messages = [WalletMessage(send_mode, msg) for msg in messages]
        internal = self._pack_actions(wallet_messages, query_id)
        return internal.message

    def create_transfer_body(
        self,
        secret_key: bytes,
        messages: Iterable[WalletMessage],
        created_at: int | None = None,
        query_id: int | None = None,
        timeout: int | None = None,
        subwallet_id: int | None = None,
    ) -> Cell:
        created_at = created_at if created_at is not None else int(time.time()) - 30
        if query_id is None:
            query_id = self.getQueryIdFromCreatedAt(created_at)
        ttl = timeout if timeout is not None else self.timeout
        wallet_id = subwallet_id if subwallet_id is not None else self.subwallet_id

        msgs = list(messages)
        if not msgs:
            raise ValueError("messages should not be empty")
        if len(msgs) > 254 * 254:
            raise ValueError("for highload v3 wallet maximum messages amount is 254*254")

        if len(msgs) == 1 and msgs[0].message.init is None:
            msg = msgs[0]
        else:
            msg = self._pack_actions(msgs, query_id)

        signing_message = (
            Builder()
            .store_uint(wallet_id, 32)
            .store_ref(msg.message.serialize())
            .store_uint(msg.send_mode, 8)
            .store_uint(query_id, 23)
            .store_uint(created_at, 64)
            .store_uint(ttl, 22)
            .end_cell()
        )

        signature = sign_message(signing_message.hash, secret_key)
        return Builder().store_bytes(signature).store_ref(signing_message).end_cell()

highload_wallet_v3 = HighloadWalletV3
