from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from pytoniq_core.boc.address import Address
from pytoniq_core.boc.builder import Builder

from ton_get_methods.runtime import (
    run_get_method,
    stack_item_as_address,
    stack_item_as_cell,
    stack_item_as_int,
    stack_item_as_string,
)


@dataclass(frozen=True)
class JettonMinter:
    address: Address

    @staticmethod
    def createFromAddress(address: Address | str) -> JettonMinter:
        return JettonMinter(Address(address) if isinstance(address, str) else address)

    def bind_opener(self, opener: Any) -> OpenedJettonMinter:
        return OpenedJettonMinter(self.address, opener)


class OpenedJettonMinter:
    def __init__(self, address: Address, opener: Any) -> None:
        self.address = address
        self._opener = opener

    async def getJettonData(self) -> dict[str, Any]:  # noqa: N802
        stack = await run_get_method(self._opener, self.address, "get_jetton_data", [])
        if len(stack) < 5:
            raise RuntimeError("Jetton minter returned invalid get_jetton_data stack")

        total_supply = stack_item_as_int(stack[0])
        mintable_value = stack_item_as_int(stack[1])
        admin_address = stack_item_as_address(stack[2])
        content = stack_item_as_cell(stack[3])
        wallet_code = stack_item_as_cell(stack[4])

        if total_supply is None or admin_address is None or content is None or wallet_code is None:
            raise RuntimeError("Jetton minter returned invalid get_jetton_data values")

        return {
            "totalSupply": total_supply,
            "mintable": bool(mintable_value),
            "adminAddress": admin_address,
            "content": content,
            "walletCode": wallet_code,
        }

    async def getWalletAddress(self, owner: Address | str) -> Address:  # noqa: N802
        owner_address = Address(owner) if isinstance(owner, str) else owner
        owner_slice = Builder().store_address(owner_address).end_cell().begin_parse()
        stack = await run_get_method(self._opener, self.address, "get_wallet_address", [owner_slice])
        if not stack:
            raise RuntimeError("Jetton minter returned empty wallet address stack")
        wallet_address = stack_item_as_address(stack[0])
        if wallet_address is None:
            raise RuntimeError("Jetton minter returned invalid wallet address")
        return wallet_address

    async def getEVMTokenAddress(self) -> str:  # noqa: N802
        for method in ("get_evm_token_address", "get_evm_token_addr"):
            try:
                stack = await run_get_method(self._opener, self.address, method, [])
            except Exception:
                continue
            if not stack:
                continue
            evm_address = stack_item_as_string(stack[0])
            if evm_address:
                return evm_address
        raise RuntimeError("Jetton minter returned empty EVM token address")

    async def getDisplayMultiplier(self) -> dict[str, int]:  # noqa: N802
        stack = await run_get_method(self._opener, self.address, "get_display_multiplier", [])
        if len(stack) < 2:
            raise RuntimeError("Jetton minter returned invalid display multiplier stack")
        numerator = stack_item_as_int(stack[0])
        denominator = stack_item_as_int(stack[1])
        if numerator is None or denominator is None:
            raise RuntimeError("Jetton minter returned invalid display multiplier values")
        return {"numerator": numerator, "denominator": denominator}
