from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from pytoniq_core.boc.address import Address
from pytoniq_core.boc.cell import Cell

from ton_get_methods.runtime import run_get_method, stack_item_as_address, stack_item_as_cell, stack_item_as_int


def _to_bounceable(address: Address) -> str:
    return address.to_str(is_user_friendly=True, is_url_safe=True, is_bounceable=True, is_test_only=False)


@dataclass(frozen=True)
class JettonWallet:
    address: Address

    @staticmethod
    def createFromAddress(address: Address | str) -> JettonWallet:
        return JettonWallet(Address(address) if isinstance(address, str) else address)

    def bind_opener(self, opener: Any) -> OpenedJettonWallet:
        return OpenedJettonWallet(self.address, opener)


class OpenedJettonWallet:
    def __init__(self, address: Address, opener: Any) -> None:
        self.address = address
        self._opener = opener

    async def getWalletData(self) -> dict[str, Any]:  # noqa: N802
        stack = await run_get_method(self._opener, self.address, "get_wallet_data", [])
        if len(stack) < 4:
            raise RuntimeError("Jetton wallet returned invalid get_wallet_data stack")

        balance = stack_item_as_int(stack[0])
        owner_address = stack_item_as_address(stack[1])
        jetton_master_address = stack_item_as_address(stack[2])
        jetton_wallet_code = stack_item_as_cell(stack[3])

        if (
            balance is None
            or owner_address is None
            or jetton_master_address is None
            or not isinstance(jetton_wallet_code, Cell)
        ):
            raise RuntimeError("Jetton wallet returned invalid get_wallet_data values")

        return {
            "balance": balance,
            "ownerAddress": _to_bounceable(owner_address),
            "jettonMasterAddress": _to_bounceable(jetton_master_address),
            "jettonWalletCode": jetton_wallet_code,
        }

    async def getJettonBalance(self) -> int:  # noqa: N802
        wallet_data = await self.getWalletData()
        return int(wallet_data["balance"])
