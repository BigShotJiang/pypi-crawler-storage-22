from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from pytoniq_core.boc.address import Address
from pytoniq_core.boc.builder import Builder
from pytoniq_core.boc.cell import Cell

from sdk.utils import calculate_contract_address
from ton_get_methods.runtime import (
    run_get_method,
    stack_item_as_address,
    stack_item_as_cell,
    stack_item_as_int,
    stack_item_as_string,
)


@dataclass(frozen=True)
class NftCollection:
    address: Address

    @staticmethod
    def createFromAddress(address: Address | str) -> NftCollection:
        return NftCollection(Address(address) if isinstance(address, str) else address)

    @staticmethod
    def createFromConfig(config: dict[str, Any], code: Cell, workchain: int = 0) -> NftCollection:
        del workchain
        admin_address = Address(str(config["adminAddress"]))
        new_admin_address_raw = config.get("newAdminAddress")
        new_admin_address = Address(str(new_admin_address_raw)) if new_admin_address_raw else None
        collection_content = config["collectionContent"]
        common_content = config["commonContent"]
        nft_item_code = config["nftItemCode"]
        original_address = str(config["originalAddress"])

        data = (
            Builder()
            .store_address(admin_address)
            .store_address(new_admin_address)
            .store_ref(Builder().store_ref(collection_content).store_ref(common_content).end_cell())
            .store_ref(nft_item_code)
            .store_snake_string(original_address)
            .end_cell()
        )
        contract_address = calculate_contract_address(code, data)
        if hasattr(contract_address, "to_str"):
            tvm_address = contract_address.to_str(
                is_user_friendly=True,
                is_url_safe=True,
                is_bounceable=True,
                is_test_only=False,
            )
        else:
            tvm_address = str(contract_address)
        return NftCollection(Address(tvm_address))

    def bind_opener(self, opener: Any) -> OpenedNftCollection:
        return OpenedNftCollection(self.address, opener)


class OpenedNftCollection:
    def __init__(self, address: Address, opener: Any) -> None:
        self.address = address
        self._opener = opener

    async def getCollectionData(self) -> dict[str, Any]:  # noqa: N802
        stack = await run_get_method(self._opener, self.address, "get_collection_data", [])
        if len(stack) < 3:
            raise RuntimeError("NFT collection returned invalid get_collection_data stack")

        next_index = stack_item_as_int(stack[0])
        content = stack_item_as_cell(stack[1])
        admin_address = stack_item_as_address(stack[2])
        if next_index is None or content is None or admin_address is None:
            raise RuntimeError("NFT collection returned invalid get_collection_data values")

        return {
            "nextIndex": next_index,
            "content": content,
            "adminAddress": admin_address,
        }

    async def getNFTAddressByIndex(self, index: int) -> Address:  # noqa: N802
        stack = await run_get_method(self._opener, self.address, "get_nft_address_by_index", [int(index)])
        if not stack:
            raise RuntimeError("NFT collection returned empty get_nft_address_by_index stack")
        nft_address = stack_item_as_address(stack[0])
        if nft_address is None:
            raise RuntimeError("NFT collection returned invalid NFT address by index")
        return nft_address

    async def getOriginalAddress(self) -> str:  # noqa: N802
        stack = await run_get_method(self._opener, self.address, "get_original_address", [])
        if not stack:
            raise RuntimeError("NFT collection returned empty get_original_address stack")
        original_address = stack_item_as_string(stack[0])
        if not original_address:
            raise RuntimeError("NFT collection returned invalid original address")
        return original_address
