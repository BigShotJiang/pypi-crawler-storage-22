from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from pytoniq_core.boc.address import Address
from pytoniq_core.boc.builder import Builder
from pytoniq_core.boc.cell import Cell

from sdk.utils import calculate_contract_address
from ton_get_methods.runtime import run_get_method, stack_item_as_address, stack_item_as_cell, stack_item_as_int


@dataclass(frozen=True)
class NftItem:
    address: Address

    @staticmethod
    def createFromAddress(address: Address | str) -> NftItem:
        return NftItem(Address(address) if isinstance(address, str) else address)

    @staticmethod
    def createFromConfig(config: dict[str, Any], code: Cell, workchain: int = 0) -> NftItem:
        del workchain
        collection_address = Address(str(config["collectionAddress"]))
        ccl_address = Address(str(config["cclAddress"]))
        owner_address_raw = config.get("ownerAddress")
        owner_address = Address(str(owner_address_raw)) if owner_address_raw else None
        content = config.get("content")

        data = (
            Builder()
            .store_bit(bool(config.get("init", False)))
            .store_uint(int(config["index"]), 256)
            .store_ref(
                Builder()
                .store_address(collection_address)
                .store_address(ccl_address)
                .store_address(owner_address)
                .end_cell()
            )
            .store_maybe_ref(content)
            .end_cell()
        )
        contract_address = calculate_contract_address(code, data)
        if hasattr(contract_address, "to_str"):
            tvm_address = contract_address.to_str(
                is_user_friendly=True,
                is_url_safe=True,
                is_bounceable=True,
                is_test_only=False,
            )
        else:
            tvm_address = str(contract_address)
        return NftItem(Address(tvm_address))

    def bind_opener(self, opener: Any) -> OpenedNftItem:
        return OpenedNftItem(self.address, opener)


class OpenedNftItem:
    def __init__(self, address: Address, opener: Any) -> None:
        self.address = address
        self._opener = opener

    async def getNFTData(self) -> dict[str, Any]:  # noqa: N802
        stack = await run_get_method(self._opener, self.address, "get_nft_data", [])
        if len(stack) < 5:
            raise RuntimeError("NFT item returned invalid get_nft_data stack")

        init = bool(stack_item_as_int(stack[0]))
        index = stack_item_as_int(stack[1])
        collection_address = stack_item_as_address(stack[2])
        owner_address = stack_item_as_address(stack[3])
        content = stack_item_as_cell(stack[4])

        if index is None or collection_address is None:
            raise RuntimeError("NFT item returned invalid get_nft_data values")

        return {
            "init": init,
            "index": index,
            "collectionAddress": collection_address,
            "ownerAddress": owner_address,
            "content": content,
        }
