from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from pytoniq_core.boc.address import Address
from pytoniq_core.boc.cell import Cell

from ton_get_methods.runtime import run_get_method, stack_item_as_cell


@dataclass(frozen=True)
class Settings:
    address: Address

    @staticmethod
    def createFromAddress(address: Address | str) -> Settings:
        return Settings(Address(address) if isinstance(address, str) else address)

    def bind_opener(self, opener: Any) -> OpenedSettings:
        return OpenedSettings(self.address, opener)


class OpenedSettings:
    def __init__(self, address: Address, opener: Any) -> None:
        self.address = address
        self._opener = opener

    async def getAll(self) -> Cell:  # noqa: N802
        stack = await run_get_method(self._opener, self.address, "get_all", [])
        if not stack:
            return Cell.empty()
        result = stack_item_as_cell(stack[0])
        return result if result is not None else Cell.empty()
