from __future__ import annotations

from rich.console import Console

console = Console(highlight=False)
console_err = Console(highlight=False, stderr=True)
