from __future__ import annotations

from domain_one import x

x
