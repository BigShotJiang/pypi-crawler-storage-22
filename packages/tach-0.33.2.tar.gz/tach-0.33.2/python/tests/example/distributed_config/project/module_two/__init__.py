def module_two():
    print("module_two")
