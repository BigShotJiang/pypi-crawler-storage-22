from __future__ import annotations


def d3function(): ...
