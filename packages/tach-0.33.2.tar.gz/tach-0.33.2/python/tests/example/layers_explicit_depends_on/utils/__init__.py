tool = lambda: None
