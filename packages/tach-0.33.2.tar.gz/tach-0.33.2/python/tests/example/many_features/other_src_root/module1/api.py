from module1.submodule1.api import Api  # tach-ignore

from module1.submodule1.api import OtherApi

from module1.submodule2 import something

from module1.submodule3 import something_else
