from package2 import something
