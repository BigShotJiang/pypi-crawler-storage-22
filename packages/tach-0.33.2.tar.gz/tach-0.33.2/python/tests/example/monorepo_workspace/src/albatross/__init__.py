from package1 import something
from package2 import something_else
