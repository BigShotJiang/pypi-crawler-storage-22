def hello_world() -> str:
    import git
    return "Hello world from package A!"
