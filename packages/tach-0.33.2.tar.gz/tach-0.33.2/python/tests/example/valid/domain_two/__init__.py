from __future__ import annotations

from domain_four import ok
from domain_three import x

from .. import domain_three

y = domain_three

__all__ = ["x", "ok"]
