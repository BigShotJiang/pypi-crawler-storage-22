from module3 import something
