mod all;
pub mod django;

pub use all::PluginsConfig;
