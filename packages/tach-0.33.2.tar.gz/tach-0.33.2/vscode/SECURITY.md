
### Reporting Security Issues

**Please do not report security vulnerabilities through public GitHub issues.** Instead, please send a  DM to caelean or nashsando on [Discord](https://discord.gg/a58vW8dnmw). You can also email us at caelean@gauge.sh or evan@gauge.sh. If the issue is significant, we will consider paying a bounty.