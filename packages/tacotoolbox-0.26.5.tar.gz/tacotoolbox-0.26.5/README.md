# tacotoolbox

[![codecov](https://codecov.io/gh/tacofoundation/taco-toolbox/graph/badge.svg?token=OZ8GB6H10B)](https://codecov.io/gh/tacofoundation/taco-toolbox)
[![PyPI](https://img.shields.io/pypi/v/tacotoolbox.svg)](https://pypi.python.org/pypi/tacotoolbox)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
[![BlueSky](https://img.shields.io/badge/bluesky-tacofoundation-1185fe?labelColor=000000&logo=bluesky)](https://bsky.app/profile/tacofoundation.bsky.social)
[![Checked with mypy](https://www.mypy-lang.org/static/mypy_badge.svg)](https://mypy-lang.org/)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![Linting: Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/charliermarsh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)




A prototype implementation of the TACO Toolbox API specification.

Status: Work in progress.