"""
Generated ANTLR parsers for Lua DSL.

These files are generated from LuaLexer.g4 and LuaParser.g4 grammars using ANTLR4.
Do not edit manually - regenerate using:
    make generate-parsers
"""
