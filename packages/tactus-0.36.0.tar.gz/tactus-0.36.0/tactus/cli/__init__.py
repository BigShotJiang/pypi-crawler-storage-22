"""
Tactus CLI module.
"""

from tactus.cli.app import main

__all__ = ["main"]
