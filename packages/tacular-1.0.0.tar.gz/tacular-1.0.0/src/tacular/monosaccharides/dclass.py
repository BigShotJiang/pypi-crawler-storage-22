from ..obo_entity import OboEntity


class MonosaccharideInfo(OboEntity):
    """Class to store information about a monosaccharide"""
