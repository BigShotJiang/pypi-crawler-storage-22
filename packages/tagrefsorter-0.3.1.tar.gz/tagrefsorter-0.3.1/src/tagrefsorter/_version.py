from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("tagrefsorter")
except PackageNotFoundError:  # editable / source tree
    __version__ = "0.0.0"

__all__ = ["__version__"]
