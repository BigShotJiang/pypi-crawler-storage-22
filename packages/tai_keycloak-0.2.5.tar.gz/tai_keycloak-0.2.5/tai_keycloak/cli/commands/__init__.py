"""Commands package for tai-keycloak CLI"""
from .cmd_api import api
from .cmd_run import run
from .cmd_init import init