"""
Comando tai-kc init
Inicializa los recursos de Keycloak en el proyecto actual
"""
from .main import init

__all__ = ['init']
