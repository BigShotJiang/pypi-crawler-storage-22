"""
tai-storage: Librería para gestión unificada de archivos en múltiples orígenes.

Proporciona una interfaz única para manejar archivos almacenados en:
- Sistema de archivos local
- Azure Blob Storage
- Servidores SFTP/FTP
- SharePoint
- Y más...

Uso básico:
    >>> from tai_storage import StorageFactory
    >>> 
    >>> # Crear origen local
    >>> origin = StorageFactory.create_local(root_path='/data')
    >>> folder = origin.get_folder('reports')
    >>> file = folder.get_file('report.csv')
    >>> data = file.read()
"""

__version__ = "0.1.0"
__author__ = "MateoSaezMata"

from tai_storage.base import Origin, Folder, File
from tai_storage.exceptions import (
    TaiStorageError,
    SecretNotFoundError,
    OriginConnectionError,
    AuthenticationError,
    OriginNotConnectedError,
    FolderNotFoundError,
    FolderAlreadyExistsError,
    FileNotFoundError,
    FileAlreadyExistsError,
    InvalidPathError,
    PermissionError,
    OperationNotSupportedError,
    ValidationError,
    UploadError,
    WriteError,
)
from tai_storage.secrets import SecretManager
from tai_storage.logger import configure_logger

# Implementaciones disponibles
from tai_storage.implementations.local import LocalOrigin, LocalFolder, LocalFile
from tai_storage.implementations.sharepoint import SharePointOrigin, SharePointFolder, SharePointFile
from tai_storage.implementations.azure import AzureBlobOrigin, AzureBlobFolder, AzureBlobFile

# Factory pattern
from tai_storage.factory import StorageFactory

# Cache system
from tai_storage.cache import CachedOrigin, CachedFolder, CachedFile

__all__ = [
    # Version
    '__version__',
    '__author__',
    
    # Base classes
    'Origin',
    'Folder',
    'File',
    
    # Exceptions
    'TaiStorageError',
    'SecretNotFoundError',
    'OriginConnectionError',
    'AuthenticationError',
    'OriginNotConnectedError',
    'FolderNotFoundError',
    'FolderAlreadyExistsError',
    'FileNotFoundError',
    'FileAlreadyExistsError',
    'InvalidPathError',
    'PermissionError',
    'OperationNotSupportedError',
    'ValidationError',
    'UploadError',
    'WriteError',
    
    # Utilities
    'SecretManager',
    'configure_logger',
    
    # Local implementation
    'LocalOrigin',
    'LocalFolder',
    'LocalFile',
    
    # SharePoint implementation
    'SharePointOrigin',
    'SharePointFolder',
    'SharePointFile',
    
    # Azure Blob Storage implementation
    'AzureBlobOrigin',
    'AzureBlobFolder',
    'AzureBlobFile',
    
    # Factory pattern
    'StorageFactory',
    
    # Cache system
    'CachedOrigin',
    'CachedFolder',
    'CachedFile',
]
