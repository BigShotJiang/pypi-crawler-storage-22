"""
Excepciones personalizadas para tai-storage.
"""


class TaiStorageError(Exception):
    """Excepción base para todos los errores de tai-storage."""
    pass


class SecretNotFoundError(TaiStorageError):
    """Se lanza cuando un secreto requerido no se encuentra."""
    pass


class OriginConnectionError(TaiStorageError):
    """Se lanza cuando falla la conexión a un origen."""
    pass


class AuthenticationError(TaiStorageError):
    """Se lanza cuando falla la autenticación con el origen."""
    pass


class OriginNotConnectedError(TaiStorageError):
    """Se lanza cuando se intenta operar sin estar conectado."""
    pass


class FolderNotFoundError(TaiStorageError):
    """Se lanza cuando una carpeta no existe."""
    pass


class FolderAlreadyExistsError(TaiStorageError):
    """Se lanza cuando se intenta crear una carpeta que ya existe."""
    pass


class FileNotFoundError(TaiStorageError):
    """Se lanza cuando un archivo no existe."""
    pass


class FileAlreadyExistsError(TaiStorageError):
    """Se lanza cuando se intenta crear un archivo que ya existe."""
    pass


class InvalidPathError(TaiStorageError):
    """Se lanza cuando una ruta es inválida."""
    pass


class PermissionError(TaiStorageError):
    """Se lanza cuando no hay permisos suficientes."""
    pass


class OperationNotSupportedError(TaiStorageError):
    """Se lanza cuando una operación no está soportada por el origen."""
    pass


class ValidationError(TaiStorageError):
    """Se lanza cuando la validación de datos falla."""
    pass


class UploadError(TaiStorageError):
    """Se lanza cuando falla la subida de un archivo."""
    pass


class WriteError(TaiStorageError):
    """Se lanza cuando falla la escritura de un archivo."""
    pass
