"""Implementaciones de orígenes de almacenamiento."""
