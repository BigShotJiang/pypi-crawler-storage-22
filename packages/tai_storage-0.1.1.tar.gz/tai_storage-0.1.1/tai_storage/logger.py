"""
Configuración del logger de tai-storage usando tai-alphi.

Este módulo configura automáticamente el logger 'tai-storage' al ser importado.
Para obtener el logger en otros módulos, usar:
    from tai_alphi import Alphi
    logger = Alphi.get_logger_by_name('tai-storage')
"""
from tai_alphi import Alphi


# Nombre del logger para tai-storage
LOGGER_NAME = 'tai-storage'


# Configuración por defecto del logger
DEFAULT_CONFIG = {
    'consola': {
        'enabled': True,
        'log_level': 'INFO',
        'display_info': ['asctime', 'levelname'],
        'time_format': '%H:%M:%S'
    }
}


def configure_logger(log_level: str = 'INFO', 
                    display_info: list = None,
                    time_format: str = '%H:%M:%S'):
    """
    Configura el logger de tai-storage.
    
    Args:
        log_level: Nivel de log (DEBUG, INFO, WARN, ERROR, CRIT)
        display_info: Lista de campos a mostrar en logs
        time_format: Formato de timestamp
        
    Example:
        >>> from tai_storage.logger import configure_logger
        >>> configure_logger(log_level='DEBUG', 
        ...                  display_info=['asctime', 'levelname', 'funcName'])
    """
    config = {
        'consola': {
            'enabled': True,
            'log_level': log_level,
            'display_info': display_info or ['asctime', 'levelname'],
            'time_format': time_format
        }
    }
    Alphi.configure_logger(LOGGER_NAME, config)


# Configurar logger por defecto al importar el módulo
Alphi.configure_logger(LOGGER_NAME, DEFAULT_CONFIG)
