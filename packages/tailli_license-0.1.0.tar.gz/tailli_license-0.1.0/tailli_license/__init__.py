"""
Táillí License Client - Python SDK for offline license management.

A friendly, well-documented client for managing seats and API keys with
the Táillí License Manager.

Basic usage:
    from tailli_license import LicenseClient

    client = LicenseClient("http://localhost:8787", product_id="my-product")

    # Use a seat with automatic cleanup
    with client.seat() as seat:
        print(f"Seat allocated: {seat.seat_id}")
        # Do your licensed work here
    # Seat automatically released

Async usage:
    async with client.seat_async() as seat:
        # Do async licensed work
        pass

For more examples, see the README.md file.
"""

from .client import LicenseClient, Seat, LicenseError, SeatLimitError, LicenseExpiredError

__version__ = "0.1.0"
__all__ = ["LicenseClient", "Seat", "LicenseError", "SeatLimitError", "LicenseExpiredError"]
