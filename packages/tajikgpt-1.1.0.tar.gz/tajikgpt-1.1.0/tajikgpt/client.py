"""TajikGPT API Client"""

import time
import requests
from tajikgpt.models import ChatCompletion, ImageResult, VideoResult


class _ChatCompletions:
    """Chat completions endpoint"""

    def __init__(self, client):
        self._client = client

    def create(self, model="tj-1.0", messages=None, temperature=0.7, max_tokens=None):
        """Create a chat completion.

        Args:
            model: Model ID (tj-0.5, tj-1.0-mini, tj-1.0, tj-1.0-pro, tj-1.0-ultra, tj-coder)
            messages: List of message dicts with 'role' and 'content'
            temperature: Creativity (0-2, default 0.7)
            max_tokens: Maximum tokens in response

        Returns:
            ChatCompletion object
        """
        if messages is None:
            raise ValueError("messages is required")

        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
        }
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        data = self._client._post("/chat/completions", payload)
        return ChatCompletion(data)


class _Chat:
    """Chat namespace"""

    def __init__(self, client):
        self.completions = _ChatCompletions(client)


class _Images:
    """Images endpoint"""

    def __init__(self, client):
        self._client = client

    def generate(self, prompt, image_model="tj-image-1.0", seed=None):
        """Generate an image from text.

        Args:
            prompt: Image description
            image_model: Model (tj-image-1.0 or tj-image-0.5)
            seed: Seed for reproducibility

        Returns:
            ImageResult object
        """
        payload = {"prompt": prompt, "image_model": image_model}
        if seed is not None:
            payload["seed"] = seed

        data = self._client._post("/images/generate", payload)
        return ImageResult(data)


class _Video:
    """Video endpoint"""

    def __init__(self, client):
        self._client = client

    def generate(self, prompt):
        """Generate a video from text description.

        Args:
            prompt: Video description (English recommended)

        Returns:
            VideoResult object

        Note:
            Available only for Plus and Pro users.
            Limits: Pro — 10/week, Plus — 2/2 weeks.
        """
        payload = {"prompt": prompt}
        data = self._client._post("/video/generate", payload)
        return VideoResult(data)


class TajikGPT:
    """TajikGPT API client.

    Usage:
        from tajikgpt import TajikGPT

        client = TajikGPT(api_key="sk-tj-your-key")

        response = client.chat.completions.create(
            model="tj-1.0",
            messages=[{"role": "user", "content": "Привет!"}]
        )
        print(response.choices[0].message.content)
    """

    def __init__(self, api_key, base_url="https://tajikgpt.com/api/v1"):
        if not api_key:
            raise ValueError("api_key is required")

        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self._session = requests.Session()
        self._session.headers.update({
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        })

        self.chat = _Chat(self)
        self.images = _Images(self)
        self.video = _Video(self)

    def _post(self, endpoint, payload):
        url = f"{self.base_url}{endpoint}"
        resp = self._session.post(url, json=payload, timeout=120)

        if resp.status_code == 401:
            raise AuthenticationError("Invalid API key")
        elif resp.status_code == 402:
            raise InsufficientBalanceError("Insufficient balance. Top up at https://tajikgpt.com/pricing")
        elif resp.status_code == 429:
            raise RateLimitError("Rate limit exceeded. Please wait and try again.")
        elif resp.status_code >= 500:
            raise APIError(f"Server error ({resp.status_code})")
        elif resp.status_code != 200:
            raise APIError(f"Request failed ({resp.status_code}): {resp.text}")

        return resp.json()

    def list_models(self):
        """Get available models."""
        url = f"{self.base_url}/models"
        resp = self._session.get(url, timeout=30)
        if resp.status_code != 200:
            raise APIError(f"Failed to list models ({resp.status_code})")
        return resp.json()


# Exceptions
class TajikGPTError(Exception):
    """Base exception"""
    pass

class AuthenticationError(TajikGPTError):
    """Invalid API key"""
    pass

class InsufficientBalanceError(TajikGPTError):
    """Not enough balance"""
    pass

class RateLimitError(TajikGPTError):
    """Rate limit exceeded"""
    pass

class APIError(TajikGPTError):
    """General API error"""
    pass
