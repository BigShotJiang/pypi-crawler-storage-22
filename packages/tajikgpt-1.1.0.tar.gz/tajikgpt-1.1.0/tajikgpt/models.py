"""Data models for TajikGPT SDK"""


class Message:
    def __init__(self, role: str, content: str):
        self.role = role
        self.content = content

    def to_dict(self):
        return {"role": self.role, "content": self.content}

    def __repr__(self):
        return f"Message(role='{self.role}', content='{self.content[:50]}...')"


class Choice:
    def __init__(self, data: dict):
        self.index = data.get("index", 0)
        self.message = Message(
            role=data.get("message", {}).get("role", "assistant"),
            content=data.get("message", {}).get("content", ""),
        )
        self.finish_reason = data.get("finish_reason", "stop")


class Usage:
    def __init__(self, data: dict):
        self.prompt_tokens = data.get("prompt_tokens", 0)
        self.completion_tokens = data.get("completion_tokens", 0)
        self.total_tokens = data.get("total_tokens", 0)


class ChatCompletion:
    def __init__(self, data: dict):
        self.id = data.get("id", "")
        self.object = data.get("object", "chat.completion")
        self.created = data.get("created", 0)
        self.model = data.get("model", "")
        self.choices = [Choice(c) for c in data.get("choices", [])]
        self.usage = Usage(data.get("usage", {}))


class ImageResult:
    def __init__(self, data: dict):
        self.id = data.get("id", "")
        self.object = data.get("object", "image")
        self.created = data.get("created", 0)
        self.model = data.get("model", "")
        self.data = data.get("data", [])

    @property
    def url(self):
        if self.data:
            return self.data[0].get("url", "")
        return ""


class VideoResult:
    def __init__(self, data: dict):
        self.id = data.get("id", "")
        self.object = data.get("object", "video")
        self.created = data.get("created", 0)
        self.model = data.get("model", "")
        self.data = data.get("data", [])

    @property
    def url(self):
        if self.data:
            return self.data[0].get("url", "")
        return ""
