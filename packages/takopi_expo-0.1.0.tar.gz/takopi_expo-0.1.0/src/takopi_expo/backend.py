from __future__ import annotations

import json
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from takopi.api import (
    CommandBackend,
    CommandContext,
    CommandResult,
    ConfigError,
    HOME_CONFIG_PATH,
    get_logger,
    read_config,
)
from takopi.utils.git import git_stdout, resolve_main_worktree_root

logger = get_logger(__name__)

DEFAULT_PLATFORM = "all"
DEFAULT_PROFILE = "development"
DEFAULT_POLL_INTERVAL_S = 20

PLATFORM_CHOICES = {"ios", "android", "all"}
PROFILE_ALIASES = {
    "dev": "development",
    "development": "development",
    "preview": "preview",
    "prod": "production",
    "production": "production",
}
SCRIPT_KEYS = (
    "build_dev",
    "build_preview",
    "build_prod",
    "build_ios",
    "build_android",
)
PROJECT_CONTEXT_HELP = "expo requires a project context; specify /<project> @branch"


@dataclass(frozen=True, slots=True)
class ExpoScripts:
    build_dev: str | None = None
    build_preview: str | None = None
    build_prod: str | None = None
    build_ios: str | None = None
    build_android: str | None = None

    @classmethod
    def from_config(
        cls, config: object, *, config_path: Path, prefix: str
    ) -> "ExpoScripts":
        if config is None:
            return cls()
        if isinstance(config, ExpoScripts):
            return config
        if not isinstance(config, dict):
            raise ConfigError(
                f"Invalid `{prefix}` in {config_path}; expected a table."
            )
        unknown = set(config) - set(SCRIPT_KEYS)
        if unknown:
            unknown_keys = ", ".join(sorted(unknown))
            raise ConfigError(
                f"Invalid `{prefix}` in {config_path}; unknown keys: {unknown_keys}."
            )
        values = {
            key: _optional_str_config(
                config, key, config_path=config_path, prefix=prefix
            )
            for key in SCRIPT_KEYS
        }
        return cls(**values)

    def resolve_build_script(self, *, platform: str, profile: str) -> str | None:
        profile = _normalize_profile(profile)
        if profile == "development" and self.build_dev:
            return self.build_dev
        if profile == "preview" and self.build_preview:
            return self.build_preview
        if profile == "production" and self.build_prod:
            return self.build_prod
        if platform == "ios" and self.build_ios:
            return self.build_ios
        if platform == "android" and self.build_android:
            return self.build_android
        return None


@dataclass(frozen=True, slots=True)
class ExpoConfig:
    eas_bin: str
    expo_bin: str
    package_manager: str
    default_platform: str
    default_profile: str
    prefer_package_scripts: bool
    non_interactive: bool
    wait: bool
    poll_interval_s: int
    expo_token_env: str
    project_slug_env: str
    owner_env: str
    scripts: ExpoScripts

    @classmethod
    def from_config(cls, config: object, *, config_path: Path) -> "ExpoConfig":
        if isinstance(config, ExpoConfig):
            return config
        if not isinstance(config, dict):
            raise ConfigError(
                f"Invalid `expo` config in {config_path}; expected a table."
            )

        eas_bin = _optional_str(config, "eas_bin", config_path=config_path) or "eas"
        expo_bin = _optional_str(config, "expo_bin", config_path=config_path) or "expo"
        package_manager = (
            _optional_str(config, "package_manager", config_path=config_path) or "bun"
        )
        package_manager = package_manager.strip().lower()
        if package_manager not in {"bun", "npm", "pnpm", "yarn"}:
            raise ConfigError(
                f"Invalid `expo.package_manager` in {config_path}; "
                "expected bun, npm, pnpm, or yarn."
            )

        default_platform = (
            _optional_str(config, "default_platform", config_path=config_path)
            or DEFAULT_PLATFORM
        )
        default_platform = _normalize_platform(default_platform)
        default_profile = (
            _optional_str(config, "default_profile", config_path=config_path)
            or DEFAULT_PROFILE
        )
        default_profile = _normalize_profile(default_profile)
        prefer_package_scripts = _optional_bool(
            config, "prefer_package_scripts", True, config_path=config_path
        )
        non_interactive = _optional_bool(
            config, "non_interactive", True, config_path=config_path
        )
        wait = _optional_bool(config, "wait", True, config_path=config_path)
        poll_interval_s = _optional_int(
            config, "poll_interval_s", config_path=config_path
        )
        if poll_interval_s is None:
            poll_interval_s = DEFAULT_POLL_INTERVAL_S
        if poll_interval_s < 5:
            raise ConfigError(
                f"Invalid `expo.poll_interval_s` in {config_path}; "
                "expected >= 5."
            )

        expo_token_env = (
            _optional_str(config, "expo_token_env", config_path=config_path)
            or "EXPO_TOKEN"
        )
        project_slug_env = (
            _optional_str(config, "project_slug_env", config_path=config_path)
            or "APP_SLUG"
        )
        owner_env = (
            _optional_str(config, "owner_env", config_path=config_path)
            or "EXPO_PUBLIC_OWNER"
        )

        scripts = ExpoScripts.from_config(
            config.get("scripts"), config_path=config_path, prefix="expo.scripts"
        )

        return cls(
            eas_bin=eas_bin,
            expo_bin=expo_bin,
            package_manager=package_manager,
            default_platform=default_platform,
            default_profile=default_profile,
            prefer_package_scripts=prefer_package_scripts,
            non_interactive=non_interactive,
            wait=wait,
            poll_interval_s=poll_interval_s,
            expo_token_env=expo_token_env,
            project_slug_env=project_slug_env,
            owner_env=owner_env,
            scripts=scripts,
        )


@dataclass(frozen=True, slots=True)
class BuildRequest:
    platform: str
    profile: str
    wait: bool


class ExpoCommand:
    id = "expo"
    description = "Build Expo/EAS apps"

    async def handle(self, ctx: CommandContext) -> CommandResult | None:
        try:
            return await self._handle(ctx)
        except ConfigError as exc:
            return CommandResult(text=f"expo error: {exc}")

    async def _handle(self, ctx: CommandContext) -> CommandResult:
        if not ctx.args:
            return CommandResult(text=_help_text())

        ambient_context = getattr(ctx.executor, "default_context", None)
        resolved = ctx.runtime.resolve_message(
            text=ctx.text,
            reply_text=ctx.reply_text,
            ambient_context=ambient_context,
            chat_id=_coerce_chat_id(ctx.message.channel_id),
        )
        context = resolved.context
        context_line = ctx.runtime.format_context_line(context)
        cwd = ctx.runtime.resolve_run_cwd(context)

        project = _require_project(context)
        config = _load_config(ctx, context, project)

        command = ctx.args[0].lower()
        if command in {"help", "-h", "--help"}:
            return CommandResult(text=_help_text())
        if command in {"status"}:
            worktree_path, _repo_root = _require_worktree(cwd, action="expo status")
            return CommandResult(
                text=_format_status(
                    project=project,
                    worktree_path=worktree_path,
                    config=config,
                    context_line=context_line,
                )
            )

        if command in {
            "build",
            "build:dev",
            "build:preview",
            "build:prod",
            "build:production",
            "build:ios",
            "build:android",
        }:
            _ensure_expo_token(config)
            worktree_path, _repo_root = _require_worktree(cwd, action="expo build")
            request = _resolve_build_request(
                command,
                ctx.args[1:],
                default_platform=config.default_platform,
                default_profile=config.default_profile,
                default_wait=config.wait,
            )
            _validate_platform(request.platform)
            _validate_profile(request.profile)

            script = None
            if config.prefer_package_scripts:
                script = config.scripts.resolve_build_script(
                    platform=request.platform, profile=request.profile
                )
            if script:
                _run_script(
                    script=script,
                    package_manager=config.package_manager,
                    cwd=worktree_path,
                )
                if request.wait:
                    builds = _fetch_latest_builds(
                        config=config,
                        cwd=worktree_path,
                        platform=request.platform,
                        profile=request.profile,
                    )
                    return CommandResult(
                        text=_format_build_links(builds, profile=request.profile)
                    )
                return CommandResult(
                    text=(
                        "expo build started. Run `/expo install` to fetch the latest link."
                    )
                )

            build_output = _run_eas_build(
                config=config,
                cwd=worktree_path,
                platform=request.platform,
                profile=request.profile,
                wait=request.wait,
            )
            if request.wait:
                builds = _extract_builds_from_output(build_output)
                if not builds:
                    builds = _fetch_latest_builds(
                        config=config,
                        cwd=worktree_path,
                        platform=request.platform,
                        profile=request.profile,
                    )
                return CommandResult(
                    text=_format_build_links(builds, profile=request.profile)
                )
            return CommandResult(
                text=(
                    "expo build queued. Run `/expo install` to fetch the latest link."
                )
            )

        if command in {"install"}:
            _ensure_expo_token(config)
            worktree_path, _repo_root = _require_worktree(cwd, action="expo install")
            request = _resolve_install_request(
                ctx.args[1:],
                default_platform=config.default_platform,
                default_profile=config.default_profile,
            )
            builds = _fetch_latest_builds(
                config=config,
                cwd=worktree_path,
                platform=request.platform,
                profile=request.profile,
            )
            return CommandResult(
                text=_format_build_links(builds, profile=request.profile)
            )

        if command in {"update"}:
            _ensure_expo_token(config)
            worktree_path, _repo_root = _require_worktree(cwd, action="expo update")
            channel, message = _parse_update_args(ctx.args[1:])
            output = _run_eas_update(
                config=config,
                cwd=worktree_path,
                channel=channel,
                message=message,
            )
            return CommandResult(text=output)

        raise ConfigError(f"Unknown subcommand {command!r}.")


BACKEND: CommandBackend = ExpoCommand()


def _coerce_chat_id(value: Any) -> int | None:
    if isinstance(value, int):
        return value
    return None


def _require_project(context: object | None) -> str:
    if context is None:
        raise ConfigError(PROJECT_CONTEXT_HELP)
    project = getattr(context, "project", None)
    if not isinstance(project, str) or not project:
        raise ConfigError(PROJECT_CONTEXT_HELP)
    return project


def _load_config(
    ctx: CommandContext, context: object | None, project: str
) -> ExpoConfig:
    config_path = ctx.config_path or HOME_CONFIG_PATH
    takopi_config = _load_takopi_config(config_path)
    _require_project_entry(takopi_config, project, config_path)

    base = dict(ctx.plugin_config or {})
    project_override = _project_override(base, project, config_path=config_path)
    merged = _merge_config(base, project_override)
    return ExpoConfig.from_config(merged, config_path=config_path)


def _load_takopi_config(config_path: Path) -> dict[str, Any]:
    data = read_config(config_path)
    if not isinstance(data, dict):
        raise ConfigError(f"Invalid takopi config at {config_path}.")
    return data


def _require_project_entry(
    config: dict[str, Any], project: str, config_path: Path
) -> None:
    projects = config.get("projects")
    if not isinstance(projects, dict):
        raise ConfigError(
            f"expo requires `[projects.{project}]` in {config_path}."
        )
    if project in projects:
        return
    if project.lower() in projects:
        return
    raise ConfigError(
        f"expo requires `[projects.{project}]` in {config_path}."
    )


def _project_override(
    config: dict[str, Any], project: str, *, config_path: Path
) -> dict[str, Any]:
    overrides = config.get("projects")
    if overrides is None:
        raise ConfigError(
            f"expo requires `[plugins.expo.projects.{project}]` in {config_path}."
        )
    if not isinstance(overrides, dict):
        raise ConfigError(
            f"Invalid `plugins.expo.projects` in {config_path}; expected a table."
        )
    raw = overrides.get(project)
    if raw is None:
        raw = overrides.get(project.lower())
    if raw is None:
        raise ConfigError(
            f"expo requires `[plugins.expo.projects.{project}]` in {config_path}."
        )
    if not isinstance(raw, dict):
        raise ConfigError(
            f"Invalid `plugins.expo.projects.{project}` in {config_path}; "
            "expected a table."
        )
    return dict(raw)


def _merge_config(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    merged.pop("projects", None)
    override = dict(override)
    scripts = merged.get("scripts")
    override_scripts = override.get("scripts")
    if isinstance(scripts, dict) or isinstance(override_scripts, dict):
        merged_scripts = dict(scripts or {})
        merged_scripts.update(override_scripts or {})
        merged["scripts"] = merged_scripts
    merged.update({k: v for k, v in override.items() if k != "scripts"})
    return merged


def _ensure_expo_token(config: ExpoConfig) -> None:
    if not config.non_interactive:
        return
    token = os.environ.get(config.expo_token_env)
    if not token:
        raise ConfigError(
            f"Missing {config.expo_token_env}; set it for non-interactive EAS runs."
        )


def _require_worktree(
    cwd: Path | None, *, action: str = "expo"
) -> tuple[Path, Path]:
    if cwd is None:
        raise ConfigError(f"{action} requires a worktree; specify a project/branch.")
    top = git_stdout(
        ["rev-parse", "--path-format=absolute", "--show-toplevel"], cwd=cwd
    )
    if not top:
        raise ConfigError(f"{action} requires a git worktree.")
    worktree_path = Path(top).resolve(strict=False)
    repo_root = resolve_main_worktree_root(worktree_path)
    if repo_root is None:
        raise ConfigError(f"{action} requires a git worktree.")
    repo_root = repo_root.resolve(strict=False)
    if worktree_path == repo_root:
        raise ConfigError(f"{action} requires a worktree (not the main repo).")
    return worktree_path, repo_root


def _normalize_platform(value: str) -> str:
    return value.strip().lower()


def _normalize_profile(value: str) -> str:
    cleaned = value.strip().lower()
    return PROFILE_ALIASES.get(cleaned, cleaned)


def _is_platform(value: str) -> bool:
    return _normalize_platform(value) in PLATFORM_CHOICES


def _validate_platform(platform: str) -> None:
    if platform not in PLATFORM_CHOICES:
        raise ConfigError(
            f"Invalid platform {platform!r}; expected ios, android, or all."
        )


def _validate_profile(profile: str) -> None:
    if not profile:
        raise ConfigError("Profile cannot be empty.")


def _parse_build_args(
    args: tuple[str, ...],
    *,
    default_platform: str,
    default_profile: str,
    default_wait: bool,
) -> BuildRequest:
    wait = default_wait
    positional: list[str] = []
    for token in args:
        if token == "--wait":
            wait = True
            continue
        if token == "--no-wait":
            wait = False
            continue
        positional.append(token)

    platform = default_platform
    profile = default_profile

    if positional:
        first = positional.pop(0)
        if _is_platform(first):
            platform = _normalize_platform(first)
        else:
            profile = _normalize_profile(first)

    if positional:
        profile = _normalize_profile(positional.pop(0))

    if positional:
        raise ConfigError("Too many arguments for expo build.")

    return BuildRequest(platform=platform, profile=profile, wait=wait)


def _resolve_build_request(
    command: str,
    args: tuple[str, ...],
    *,
    default_platform: str,
    default_profile: str,
    default_wait: bool,
) -> BuildRequest:
    if command == "build:dev":
        return BuildRequest(
            platform=default_platform,
            profile="development",
            wait=default_wait,
        )
    if command == "build:preview":
        return BuildRequest(
            platform=default_platform,
            profile="preview",
            wait=default_wait,
        )
    if command in {"build:prod", "build:production"}:
        return BuildRequest(
            platform=default_platform,
            profile="production",
            wait=default_wait,
        )
    if command == "build:ios":
        return BuildRequest(
            platform="ios",
            profile=default_profile,
            wait=default_wait,
        )
    if command == "build:android":
        return BuildRequest(
            platform="android",
            profile=default_profile,
            wait=default_wait,
        )
    return _parse_build_args(
        args,
        default_platform=default_platform,
        default_profile=default_profile,
        default_wait=default_wait,
    )


def _resolve_install_request(
    args: tuple[str, ...],
    *,
    default_platform: str,
    default_profile: str,
) -> BuildRequest:
    request = _parse_build_args(
        args,
        default_platform=default_platform,
        default_profile=default_profile,
        default_wait=True,
    )
    return BuildRequest(
        platform=request.platform, profile=request.profile, wait=True
    )


def _parse_update_args(args: tuple[str, ...]) -> tuple[str, str]:
    if len(args) < 2:
        raise ConfigError("usage: /expo update <channel> <message...>")
    channel = args[0].strip()
    if not channel:
        raise ConfigError("Channel cannot be empty.")
    message = " ".join(args[1:]).strip()
    if not message:
        raise ConfigError("Update message cannot be empty.")
    return channel, message


def _run_script(*, script: str, package_manager: str, cwd: Path) -> None:
    if package_manager == "bun":
        cmd = ["bun", script]
    elif package_manager == "npm":
        cmd = ["npm", "run", script]
    elif package_manager == "pnpm":
        cmd = ["pnpm", script]
    elif package_manager == "yarn":
        cmd = ["yarn", script]
    else:
        raise ConfigError(f"Unsupported package manager {package_manager!r}.")
    _run_cmd(cmd, cwd=cwd)


def _run_eas_build(
    *,
    config: ExpoConfig,
    cwd: Path,
    platform: str,
    profile: str,
    wait: bool,
) -> str:
    cmd = [
        config.eas_bin,
        "build",
        "--platform",
        platform,
        "--profile",
        profile,
        "--json",
    ]
    if wait:
        cmd.append("--wait")
    if config.non_interactive:
        cmd.append("--non-interactive")
    result = _run_cmd(cmd, cwd=cwd)
    return result


def _run_eas_update(
    *,
    config: ExpoConfig,
    cwd: Path,
    channel: str,
    message: str,
) -> str:
    cmd = [
        config.eas_bin,
        "update",
        "--channel",
        channel,
        "--message",
        message,
        "--json",
    ]
    if config.non_interactive:
        cmd.append("--non-interactive")
    output = _run_cmd(cmd, cwd=cwd)
    summary = _format_update_output(output)
    return summary


def _run_cmd(cmd: list[str], *, cwd: Path) -> str:
    logger.info("expo.cmd", cmd=" ".join(cmd), cwd=str(cwd))
    result = subprocess.run(
        cmd,
        cwd=cwd,
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        stderr = (result.stderr or "").strip()
        stdout = (result.stdout or "").strip()
        details = stderr or stdout or "(no output)"
        raise ConfigError(f"Command failed: {details}")
    return (result.stdout or "").strip()


def _extract_builds_from_output(output: str) -> list[dict[str, Any]]:
    if not output:
        return []
    try:
        data = json.loads(output)
    except json.JSONDecodeError:
        return []
    if isinstance(data, dict):
        builds = data.get("builds")
        if isinstance(builds, list):
            return [item for item in builds if isinstance(item, dict)]
        if isinstance(data.get("build"), dict):
            return [data["build"]]
    if isinstance(data, list):
        return [item for item in data if isinstance(item, dict)]
    return []


def _fetch_latest_builds(
    *,
    config: ExpoConfig,
    cwd: Path,
    platform: str,
    profile: str,
) -> list[dict[str, Any]]:
    platforms = [platform]
    if platform == "all":
        platforms = ["ios", "android"]
    builds: list[dict[str, Any]] = []
    for target in platforms:
        cmd = [
            config.eas_bin,
            "build:list",
            "--limit",
            "1",
            "--platform",
            target,
            "--json",
        ]
        if profile:
            cmd.extend(["--profile", profile])
        if config.non_interactive:
            cmd.append("--non-interactive")
        output = _run_cmd(cmd, cwd=cwd)
        try:
            data = json.loads(output)
        except json.JSONDecodeError:
            continue
        if isinstance(data, list) and data:
            if isinstance(data[0], dict):
                builds.append(data[0])
    return builds


def _format_build_links(builds: list[dict[str, Any]], *, profile: str) -> str:
    if not builds:
        return "No builds found."
    lines = [f"expo builds ({profile}):"]
    for build in builds:
        platform = build.get("platform", "unknown")
        status = build.get("status") or "unknown"
        urls = _extract_urls(build)
        if urls:
            lines.append(f"- {platform} [{status}]: {urls[0]}")
        else:
            build_id = build.get("id") or build.get("buildId") or "unknown"
            lines.append(f"- {platform} [{status}]: build {build_id}")
    return "\n".join(lines)


def _extract_urls(payload: Any) -> list[str]:
    found: list[str] = []

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            for key, item in value.items():
                if key in {
                    "buildUrl",
                    "applicationArchiveUrl",
                    "installUrl",
                    "url",
                } and isinstance(item, str):
                    if item.startswith("http"):
                        found.append(item)
                walk(item)
            return
        if isinstance(value, list):
            for item in value:
                walk(item)
            return
        if isinstance(value, str) and value.startswith("http"):
            found.append(value)

    walk(payload)
    deduped = []
    seen = set()
    for item in found:
        if item in seen:
            continue
        seen.add(item)
        deduped.append(item)
    return deduped


def _format_update_output(output: str) -> str:
    if not output:
        return "expo update completed."
    try:
        data = json.loads(output)
    except json.JSONDecodeError:
        return output
    if isinstance(data, dict):
        group = data.get("group") or data.get("groupId") or data.get("id")
        if group:
            return f"expo update published ({group})."
    return "expo update published."


def _format_status(
    *,
    project: str,
    worktree_path: Path,
    config: ExpoConfig,
    context_line: str | None,
) -> str:
    token_set = bool(os.environ.get(config.expo_token_env))
    lines = [
        "expo status:",
        f"- project: {project}",
        f"- worktree: {worktree_path}",
        f"- context: {context_line or '(none)'}",
        f"- default platform: {config.default_platform}",
        f"- default profile: {config.default_profile}",
        f"- package manager: {config.package_manager}",
        f"- EXPO token set: {'yes' if token_set else 'no'}",
    ]
    return "\n".join(lines)


def _help_text() -> str:
    return (
        "expo commands:\n"
        "/expo build [platform] [profile] [--wait|--no-wait]\n"
        "/expo build:dev\n"
        "/expo build:preview\n"
        "/expo build:prod\n"
        "/expo build:ios\n"
        "/expo build:android\n"
        "/expo install [platform] [profile]\n"
        "/expo update <channel> <message...>\n"
        "/expo status\n"
        "/expo help"
    )


def _optional_str(
    config: dict[str, Any], key: str, *, config_path: Path
) -> str | None:
    if key not in config:
        return None
    value = config.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        raise ConfigError(
            f"Invalid `expo.{key}` in {config_path}; expected a string."
        )
    cleaned = value.strip()
    return cleaned or None


def _optional_str_config(
    config: dict[str, Any], key: str, *, config_path: Path, prefix: str
) -> str | None:
    if key not in config:
        return None
    value = config.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        raise ConfigError(
            f"Invalid `{prefix}.{key}` in {config_path}; expected a string."
        )
    cleaned = value.strip()
    return cleaned or None


def _optional_bool(
    config: dict[str, Any],
    key: str,
    default: bool,
    *,
    config_path: Path,
) -> bool:
    if key not in config:
        return default
    value = config.get(key)
    if isinstance(value, bool):
        return value
    raise ConfigError(
        f"Invalid `expo.{key}` in {config_path}; expected true/false."
    )


def _optional_int(
    config: dict[str, Any], key: str, *, config_path: Path
) -> int | None:
    if key not in config:
        return None
    value = config.get(key)
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        raise ConfigError(
            f"Invalid `expo.{key}` in {config_path}; expected an integer."
        )
    return value
