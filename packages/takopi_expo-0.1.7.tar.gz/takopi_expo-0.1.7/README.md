# takopi-expo

Build Expo / EAS React Native apps from Takopi commands and return install links.

This plugin is intentionally strict about Takopi configuration: it will refuse
commands unless the target repo is registered under `[projects.<name>]` and has
an explicit `[plugins.expo.projects.<name>]` entry.

## quickstart

Install takopi + plugin (same environment as your transport):

```sh
uv tool install -U takopi --with takopi-expo
```

Add config to `~/.takopi/takopi.toml`:

```toml
[plugins]
enabled = ["takopi-expo"]

[plugins.expo]
# global defaults
default_platform = "all"          # ios | android | all
default_profile = "development"   # development | preview | production
non_interactive = true
wait = true

[projects.zkp2p-mobile]
path = "/home/ubuntu/zkp2p/zkp2p-mobile"
worktrees_dir = ".worktrees"

[plugins.expo.projects.zkp2p-mobile]
# per-project overrides (required)
# optional: map to package.json scripts
build_dev = "build:dev"
build_ios = "build:ios"
build_android = "build:android"
```

Set `EXPO_TOKEN` in the environment (or `plugins.expo.expo_token` in
`takopi.toml`) for non-interactive EAS builds.

## server setup (remote EAS builds)

takopi-expo uses `eas build` on Expo's servers, so it works on Linux without
Xcode. You still need Expo credentials configured in your Expo account.

1. Install EAS CLI on the server (or set `eas_bin` in config).

```sh
npm install -g eas-cli
```

2. Create an Expo access token and export it where Takopi runs (or set
   `plugins.expo.expo_token` in `takopi.toml`).

```sh
export EXPO_TOKEN=your_token_here
```

3. Ensure credentials exist in Expo:
   - iOS: Apple Developer credentials configured via EAS.
   - Android: keystore configured via EAS.

4. Confirm `eas.json` includes a dev build profile:

```json
{
  "build": {
    "development": {
      "developmentClient": true,
      "distribution": "internal"
    }
  }
}
```

For day-to-day development, install the dev client once (`/expo build:dev`),
then run Metro on your server and point the device to the server host/port.

## commands

- `/expo build [platform] [profile] [--wait|--no-wait]`
- `/expo build:dev` (alias)
- `/expo build:preview` (alias)
- `/expo build:prod` (alias)
- `/expo build:ios` (alias)
- `/expo build:android` (alias)
- `/expo install [platform] [profile]` (fetch latest build link)
- `/expo update <channel> <message...>`
- `/expo status`
- `/expo help`

## behavior

- Requires a Takopi project context (e.g. `/zkp2p-mobile @branch`).
- Refuses to run if the project is not configured in `takopi.toml`.
- Uses EAS CLI by default. Optional script aliases can be configured per project.
- When `wait = true`, build commands fetch the latest build link and print install URLs.

## notes for zkp2p-mobile

The repository already defines EAS build scripts:

- `bun build:dev`
- `bun build:android`
- `bun build:ios`

Use `/expo build:dev` for device-installable development builds, then
`/expo update development "message"` for OTA updates without running Metro.
