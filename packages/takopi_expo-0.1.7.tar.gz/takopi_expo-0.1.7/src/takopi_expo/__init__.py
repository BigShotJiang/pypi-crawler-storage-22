"""Takopi command backend for Expo / EAS builds."""

from .backend import BACKEND

__all__ = ["BACKEND"]
