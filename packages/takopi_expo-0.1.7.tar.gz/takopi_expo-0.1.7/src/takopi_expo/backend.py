from __future__ import annotations

from dataclasses import dataclass
from functools import partial
from pathlib import Path
from typing import Any, Awaitable, Callable

import anyio
from takopi.api import (
    CommandBackend,
    CommandContext,
    CommandResult,
    ConfigError,
    HOME_CONFIG_PATH,
)
from takopi.utils.git import git_stdout, resolve_main_worktree_root

from . import config as expo_config
from . import eas as expo_eas
from . import render as expo_render

HELP_COMMANDS = {"help", "-h", "--help"}
BUILD_COMMANDS = {
    "build",
    "build:dev",
    "build:preview",
    "build:prod",
    "build:production",
    "build:ios",
    "build:android",
}


@dataclass(frozen=True, slots=True)
class CommandState:
    command: str
    ctx: CommandContext
    project: str
    config: expo_config.ExpoConfig
    context_line: str | None
    cwd: Path | None


Handler = Callable[[CommandState], Awaitable[CommandResult]]


class ExpoCommand:
    id = "expo"
    description = "Build Expo/EAS apps"

    async def handle(self, ctx: CommandContext) -> CommandResult | None:
        try:
            return await self._handle(ctx)
        except ConfigError as exc:
            return CommandResult(text=f"expo error: {exc}")

    async def _handle(self, ctx: CommandContext) -> CommandResult:
        if not ctx.args:
            return CommandResult(text=expo_render.help_text())

        ambient_context = getattr(ctx.executor, "default_context", None)
        resolved = ctx.runtime.resolve_message(
            text=ctx.text,
            reply_text=ctx.reply_text,
            ambient_context=ambient_context,
            chat_id=_coerce_chat_id(ctx.message.channel_id),
        )
        context = resolved.context
        context_line = ctx.runtime.format_context_line(context)
        cwd = ctx.runtime.resolve_run_cwd(context)

        project = expo_config.require_project(context)
        config_path = ctx.config_path or HOME_CONFIG_PATH
        config = expo_config.load_expo_config(
            ctx.plugin_config or {},
            config_path,
            project=project,
        )

        command = ctx.args[0].lower()
        if command in HELP_COMMANDS:
            return CommandResult(text=expo_render.help_text())

        handler = COMMAND_HANDLERS.get(command)
        if handler is None:
            raise ConfigError(f"Unknown subcommand {command!r}.")
        state = CommandState(
            command=command,
            ctx=ctx,
            project=project,
            config=config,
            context_line=context_line,
            cwd=cwd,
        )
        return await handler(state)


BACKEND: CommandBackend = ExpoCommand()


def _coerce_chat_id(value: Any) -> int | None:
    if isinstance(value, int):
        return value
    return None


async def _run_in_thread(func: Callable[..., Any], **kwargs: Any) -> Any:
    return await anyio.to_thread.run_sync(partial(func, **kwargs))


def _require_worktree(
    cwd: Path | None, *, action: str = "expo"
) -> tuple[Path, Path]:
    if cwd is None:
        raise ConfigError(f"{action} requires a worktree; specify a project/branch.")
    top = git_stdout(
        ["rev-parse", "--path-format=absolute", "--show-toplevel"], cwd=cwd
    )
    if not top:
        raise ConfigError(f"{action} requires a git worktree.")
    worktree_path = Path(top).resolve(strict=False)
    repo_root = resolve_main_worktree_root(worktree_path)
    if repo_root is None:
        raise ConfigError(f"{action} requires a git worktree.")
    repo_root = repo_root.resolve(strict=False)
    if worktree_path == repo_root:
        raise ConfigError(f"{action} requires a worktree (not the main repo).")
    return worktree_path, repo_root


def _build_started_message(
    *, local_builds: bool, platform: str, profile: str
) -> str:
    build_mode = "local" if local_builds else "remote"
    return (
        f"expo build started ({build_mode}, {platform}/{profile}). "
        "waiting for EAS…"
    )


def _format_build_links(
    state: CommandState, builds: list[dict[str, Any]], *, profile: str
) -> CommandResult:
    return CommandResult(
        text=expo_render.format_build_links(
            builds,
            profile=profile,
            local=state.config.local_builds,
        )
    )


async def _fetch_latest_builds(
    state: CommandState,
    *,
    worktree_path: Path,
    platform: str,
    profile: str,
) -> list[dict[str, Any]]:
    return await _run_in_thread(
        expo_eas.fetch_latest_builds,
        config=state.config,
        cwd=worktree_path,
        platform=platform,
        profile=profile,
    )


async def _handle_status(state: CommandState) -> CommandResult:
    worktree_path, _repo_root = _require_worktree(
        state.cwd, action="expo status"
    )
    token_set = bool(expo_config.resolve_expo_token(state.config))
    return CommandResult(
        text=expo_render.format_status(
            project=state.project,
            worktree_path=worktree_path,
            config=state.config,
            context_line=state.context_line,
            token_set=token_set,
        )
    )


async def _handle_build(state: CommandState) -> CommandResult:
    expo_config.ensure_expo_token(state.config)
    worktree_path, _repo_root = _require_worktree(state.cwd, action="expo build")
    request = expo_config.resolve_build_request(
        state.command,
        state.ctx.args[1:],
        default_platform=state.config.default_platform,
        default_profile=state.config.default_profile,
        default_wait=state.config.wait,
    )
    expo_config.validate_platform(request.platform)
    expo_config.validate_profile(request.profile)
    await state.ctx.executor.send(
        _build_started_message(
            local_builds=state.config.local_builds,
            platform=request.platform,
            profile=request.profile,
        )
    )

    script = None
    if state.config.prefer_package_scripts:
        script = state.config.scripts.resolve_build_script(
            platform=request.platform, profile=request.profile
        )
    if script:
        extra_args = ["--local"] if state.config.local_builds else None
        await _run_in_thread(
            expo_eas.run_script,
            script=script,
            package_manager=state.config.package_manager,
            cwd=worktree_path,
            env=expo_config.expo_env(state.config),
            extra_args=extra_args,
        )
        if request.wait and not state.config.local_builds:
            builds = await _fetch_latest_builds(
                state,
                worktree_path=worktree_path,
                platform=request.platform,
                profile=request.profile,
            )
            return _format_build_links(state, builds, profile=request.profile)
        if request.wait and state.config.local_builds:
            return _format_build_links(state, [], profile=request.profile)
        return CommandResult(
            text=(
                "expo build started. Run `/expo install` to fetch the latest link."
            )
        )

    build_output = await _run_in_thread(
        expo_eas.run_eas_build,
        config=state.config,
        cwd=worktree_path,
        platform=request.platform,
        profile=request.profile,
        wait=request.wait,
    )
    if request.wait:
        builds = expo_eas.extract_builds_from_output(build_output)
        if not builds and not state.config.local_builds:
            builds = await _fetch_latest_builds(
                state,
                worktree_path=worktree_path,
                platform=request.platform,
                profile=request.profile,
            )
        return _format_build_links(state, builds, profile=request.profile)
    return CommandResult(
        text="expo build queued. Run `/expo install` to fetch the latest link."
    )


async def _handle_install(state: CommandState) -> CommandResult:
    expo_config.ensure_expo_token(state.config)
    if state.config.local_builds:
        return CommandResult(
            text="local builds are enabled; `/expo install` only works for remote builds."
        )
    worktree_path, _repo_root = _require_worktree(state.cwd, action="expo install")
    request = expo_config.resolve_install_request(
        state.ctx.args[1:],
        default_platform=state.config.default_platform,
        default_profile=state.config.default_profile,
    )
    builds = await _fetch_latest_builds(
        state,
        worktree_path=worktree_path,
        platform=request.platform,
        profile=request.profile,
    )
    return _format_build_links(state, builds, profile=request.profile)


async def _handle_update(state: CommandState) -> CommandResult:
    expo_config.ensure_expo_token(state.config)
    worktree_path, _repo_root = _require_worktree(state.cwd, action="expo update")
    channel, message = expo_config.parse_update_args(state.ctx.args[1:])
    output = await _run_in_thread(
        expo_eas.run_eas_update,
        config=state.config,
        cwd=worktree_path,
        channel=channel,
        message=message,
    )
    return CommandResult(text=expo_render.format_update_output(output))


COMMAND_HANDLERS: dict[str, Handler] = {
    "status": _handle_status,
    "install": _handle_install,
    "update": _handle_update,
}
for command in BUILD_COMMANDS:
    COMMAND_HANDLERS[command] = _handle_build
