from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from takopi.api import ConfigError, read_config

DEFAULT_PLATFORM = "all"
DEFAULT_PROFILE = "development"

PLATFORM_CHOICES = {"ios", "android", "all"}
PROFILE_ALIASES = {
    "dev": "development",
    "development": "development",
    "preview": "preview",
    "prod": "production",
    "production": "production",
}
SCRIPT_KEYS = (
    "build_dev",
    "build_preview",
    "build_prod",
    "build_ios",
    "build_android",
)
PROJECT_CONTEXT_HELP = "expo requires a project context; specify /<project> @branch"


@dataclass(frozen=True, slots=True)
class ExpoScripts:
    build_dev: str | None = None
    build_preview: str | None = None
    build_prod: str | None = None
    build_ios: str | None = None
    build_android: str | None = None

    @classmethod
    def from_config(
        cls, config: object, *, config_path: Path, prefix: str
    ) -> "ExpoScripts":
        if config is None:
            return cls()
        if isinstance(config, ExpoScripts):
            return config
        if not isinstance(config, dict):
            raise ConfigError(
                f"Invalid `{prefix}` in {config_path}; expected a table."
            )
        unknown = set(config) - set(SCRIPT_KEYS)
        if unknown:
            unknown_keys = ", ".join(sorted(unknown))
            raise ConfigError(
                f"Invalid `{prefix}` in {config_path}; unknown keys: {unknown_keys}."
            )
        values = {
            key: _optional_str_config(
                config, key, config_path=config_path, prefix=prefix
            )
            for key in SCRIPT_KEYS
        }
        return cls(**values)

    def resolve_build_script(self, *, platform: str, profile: str) -> str | None:
        profile = normalize_profile(profile)
        if profile == "development" and self.build_dev:
            return self.build_dev
        if profile == "preview" and self.build_preview:
            return self.build_preview
        if profile == "production" and self.build_prod:
            return self.build_prod
        if platform == "ios" and self.build_ios:
            return self.build_ios
        if platform == "android" and self.build_android:
            return self.build_android
        return None


@dataclass(frozen=True, slots=True)
class ExpoConfig:
    eas_bin: str
    package_manager: str
    default_platform: str
    default_profile: str
    prefer_package_scripts: bool
    local_builds: bool
    non_interactive: bool
    wait: bool
    expo_token: str | None
    expo_token_env: str
    scripts: ExpoScripts

    @classmethod
    def from_config(cls, config: object, *, config_path: Path) -> "ExpoConfig":
        if isinstance(config, ExpoConfig):
            return config
        if not isinstance(config, dict):
            raise ConfigError(
                f"Invalid `expo` config in {config_path}; expected a table."
            )

        eas_bin = _optional_str(config, "eas_bin", config_path=config_path) or "eas"
        package_manager = (
            _optional_str(config, "package_manager", config_path=config_path) or "bun"
        )
        package_manager = package_manager.strip().lower()
        if package_manager not in {"bun", "npm", "pnpm", "yarn"}:
            raise ConfigError(
                f"Invalid `expo.package_manager` in {config_path}; "
                "expected bun, npm, pnpm, or yarn."
            )

        default_platform = (
            _optional_str(config, "default_platform", config_path=config_path)
            or DEFAULT_PLATFORM
        )
        default_platform = normalize_platform(default_platform)
        default_profile = (
            _optional_str(config, "default_profile", config_path=config_path)
            or DEFAULT_PROFILE
        )
        default_profile = normalize_profile(default_profile)
        prefer_package_scripts = _optional_bool(
            config, "prefer_package_scripts", True, config_path=config_path
        )
        local_builds = _optional_bool(
            config, "local_builds", False, config_path=config_path
        )
        non_interactive = _optional_bool(
            config, "non_interactive", True, config_path=config_path
        )
        wait = _optional_bool(config, "wait", True, config_path=config_path)

        expo_token_env = (
            _optional_str(config, "expo_token_env", config_path=config_path)
            or "EXPO_TOKEN"
        )
        expo_token = _optional_str(config, "expo_token", config_path=config_path)

        scripts = ExpoScripts.from_config(
            _extract_scripts(config), config_path=config_path, prefix="expo.scripts"
        )

        return cls(
            eas_bin=eas_bin,
            package_manager=package_manager,
            default_platform=default_platform,
            default_profile=default_profile,
            prefer_package_scripts=prefer_package_scripts,
            local_builds=local_builds,
            non_interactive=non_interactive,
            wait=wait,
            expo_token=expo_token,
            expo_token_env=expo_token_env,
            scripts=scripts,
        )


@dataclass(frozen=True, slots=True)
class BuildRequest:
    platform: str
    profile: str
    wait: bool


def require_project(context: object | None) -> str:
    if context is None:
        raise ConfigError(PROJECT_CONTEXT_HELP)
    project = getattr(context, "project", None)
    if not isinstance(project, str) or not project:
        raise ConfigError(PROJECT_CONTEXT_HELP)
    return project


def load_takopi_config(config_path: Path) -> dict[str, Any]:
    data = read_config(config_path)
    if not isinstance(data, dict):
        raise ConfigError(f"Invalid takopi config at {config_path}.")
    return data


def load_expo_config(
    plugin_config: dict[str, Any], config_path: Path, *, project: str
) -> ExpoConfig:
    takopi_config = load_takopi_config(config_path)
    require_project_entry(takopi_config, project, config_path)

    base = dict(plugin_config)
    project_override = project_override_for(base, project, config_path=config_path)
    merged = merge_config(base, project_override)
    return ExpoConfig.from_config(merged, config_path=config_path)


def require_project_entry(
    config: dict[str, Any], project: str, config_path: Path
) -> None:
    projects = config.get("projects")
    if not isinstance(projects, dict):
        raise ConfigError(
            f"expo requires `[projects.{project}]` in {config_path}."
        )
    if project in projects:
        return
    if project.lower() in projects:
        return
    raise ConfigError(
        f"expo requires `[projects.{project}]` in {config_path}."
    )


def project_override_for(
    config: dict[str, Any], project: str, *, config_path: Path
) -> dict[str, Any]:
    overrides = config.get("projects")
    if overrides is None:
        raise ConfigError(
            f"expo requires `[plugins.expo.projects.{project}]` in {config_path}."
        )
    if not isinstance(overrides, dict):
        raise ConfigError(
            f"Invalid `plugins.expo.projects` in {config_path}; expected a table."
        )
    raw = overrides.get(project)
    if raw is None:
        raw = overrides.get(project.lower())
    if raw is None:
        raise ConfigError(
            f"expo requires `[plugins.expo.projects.{project}]` in {config_path}."
        )
    if not isinstance(raw, dict):
        raise ConfigError(
            f"Invalid `plugins.expo.projects.{project}` in {config_path}; "
            "expected a table."
        )
    return dict(raw)


def merge_config(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    merged.pop("projects", None)
    override = dict(override)
    merged.update(override)
    return merged


def ensure_expo_token(config: ExpoConfig) -> None:
    if not config.non_interactive:
        return
    if not resolve_expo_token(config):
        raise ConfigError(
            "Missing Expo token; set plugins.expo.expo_token or "
            f"{config.expo_token_env} for non-interactive EAS runs."
        )


def resolve_expo_token(config: ExpoConfig) -> str | None:
    if config.expo_token:
        return config.expo_token
    return os.environ.get(config.expo_token_env)


def expo_env(config: ExpoConfig) -> dict[str, str] | None:
    token = resolve_expo_token(config)
    if not token:
        return None
    env = dict(os.environ)
    env[config.expo_token_env] = token
    return env


def normalize_platform(value: str) -> str:
    return value.strip().lower()


def normalize_profile(value: str) -> str:
    cleaned = value.strip().lower()
    return PROFILE_ALIASES.get(cleaned, cleaned)


def is_platform(value: str) -> bool:
    return normalize_platform(value) in PLATFORM_CHOICES


def validate_platform(platform: str) -> None:
    if platform not in PLATFORM_CHOICES:
        raise ConfigError(
            f"Invalid platform {platform!r}; expected ios, android, or all."
        )


def validate_profile(profile: str) -> None:
    if not profile:
        raise ConfigError("Profile cannot be empty.")


def parse_build_args(
    args: tuple[str, ...],
    *,
    default_platform: str,
    default_profile: str,
    default_wait: bool,
) -> BuildRequest:
    wait = default_wait
    positional: list[str] = []
    for token in args:
        if token == "--wait":
            wait = True
            continue
        if token == "--no-wait":
            wait = False
            continue
        positional.append(token)

    platform = default_platform
    profile = default_profile

    if positional:
        first = positional.pop(0)
        if is_platform(first):
            platform = normalize_platform(first)
        else:
            profile = normalize_profile(first)

    if positional:
        profile = normalize_profile(positional.pop(0))

    if positional:
        raise ConfigError("Too many arguments for expo build.")

    return BuildRequest(platform=platform, profile=profile, wait=wait)


def resolve_build_request(
    command: str,
    args: tuple[str, ...],
    *,
    default_platform: str,
    default_profile: str,
    default_wait: bool,
) -> BuildRequest:
    if command == "build:dev":
        return BuildRequest(
            platform=default_platform,
            profile="development",
            wait=default_wait,
        )
    if command == "build:preview":
        return BuildRequest(
            platform=default_platform,
            profile="preview",
            wait=default_wait,
        )
    if command in {"build:prod", "build:production"}:
        return BuildRequest(
            platform=default_platform,
            profile="production",
            wait=default_wait,
        )
    if command == "build:ios":
        return BuildRequest(
            platform="ios",
            profile=default_profile,
            wait=default_wait,
        )
    if command == "build:android":
        return BuildRequest(
            platform="android",
            profile=default_profile,
            wait=default_wait,
        )
    return parse_build_args(
        args,
        default_platform=default_platform,
        default_profile=default_profile,
        default_wait=default_wait,
    )


def resolve_install_request(
    args: tuple[str, ...],
    *,
    default_platform: str,
    default_profile: str,
) -> BuildRequest:
    request = parse_build_args(
        args,
        default_platform=default_platform,
        default_profile=default_profile,
        default_wait=True,
    )
    return BuildRequest(
        platform=request.platform, profile=request.profile, wait=True
    )


def parse_update_args(args: tuple[str, ...]) -> tuple[str, str]:
    if len(args) < 2:
        raise ConfigError("usage: /expo update <channel> <message...>")
    channel = args[0].strip()
    if not channel:
        raise ConfigError("Channel cannot be empty.")
    message = " ".join(args[1:]).strip()
    if not message:
        raise ConfigError("Update message cannot be empty.")
    return channel, message


def _extract_scripts(config: dict[str, Any]) -> dict[str, Any] | None:
    if "scripts" in config:
        raise ConfigError(
            "`expo.scripts` is no longer supported; "
            "move build_* keys to the project root."
        )
    merged: dict[str, Any] = {}
    for key in SCRIPT_KEYS:
        if key in config:
            merged[key] = config.get(key)
    return merged or None


def _optional_str(
    config: dict[str, Any], key: str, *, config_path: Path
) -> str | None:
    if key not in config:
        return None
    value = config.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        raise ConfigError(
            f"Invalid `expo.{key}` in {config_path}; expected a string."
        )
    cleaned = value.strip()
    return cleaned or None


def _optional_str_config(
    config: dict[str, Any], key: str, *, config_path: Path, prefix: str
) -> str | None:
    if key not in config:
        return None
    value = config.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        raise ConfigError(
            f"Invalid `{prefix}.{key}` in {config_path}; expected a string."
        )
    cleaned = value.strip()
    return cleaned or None


def _optional_bool(
    config: dict[str, Any],
    key: str,
    default: bool,
    *,
    config_path: Path,
) -> bool:
    if key not in config:
        return default
    value = config.get(key)
    if isinstance(value, bool):
        return value
    raise ConfigError(
        f"Invalid `expo.{key}` in {config_path}; expected true/false."
    )
