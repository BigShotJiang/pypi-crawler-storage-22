from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

from takopi.api import ConfigError, get_logger

from . import config as expo_config

logger = get_logger(__name__)


def run_script(
    *,
    script: str,
    package_manager: str,
    cwd: Path,
    env: dict[str, str] | None,
    extra_args: list[str] | None = None,
) -> None:
    extra_args = extra_args or []
    if package_manager == "bun":
        cmd = ["bun", "run", script]
    elif package_manager == "npm":
        cmd = ["npm", "run", script]
    elif package_manager == "pnpm":
        cmd = ["pnpm", script]
    elif package_manager == "yarn":
        cmd = ["yarn", script]
    else:
        raise ConfigError(f"Unsupported package manager {package_manager!r}.")
    if extra_args:
        cmd.extend(["--", *extra_args])
    _run_cmd(cmd, cwd=cwd, env=env)


def run_eas_build(
    *,
    config: expo_config.ExpoConfig,
    cwd: Path,
    platform: str,
    profile: str,
    wait: bool,
) -> str:
    cmd = [
        config.eas_bin,
        "build",
        "--platform",
        platform,
        "--profile",
        profile,
        "--json",
    ]
    if wait:
        cmd.append("--wait")
    if config.local_builds:
        cmd.append("--local")
    if config.non_interactive:
        cmd.append("--non-interactive")
    return _run_cmd(cmd, cwd=cwd, env=expo_config.expo_env(config))


def run_eas_update(
    *,
    config: expo_config.ExpoConfig,
    cwd: Path,
    channel: str,
    message: str,
) -> str:
    cmd = [
        config.eas_bin,
        "update",
        "--channel",
        channel,
        "--message",
        message,
        "--json",
    ]
    if config.non_interactive:
        cmd.append("--non-interactive")
    return _run_cmd(cmd, cwd=cwd, env=expo_config.expo_env(config))


def _run_cmd(cmd: list[str], *, cwd: Path, env: dict[str, str] | None) -> str:
    logger.info("expo.cmd", cmd=" ".join(cmd), cwd=str(cwd))
    run_env: dict[str, str] | None
    if env is None:
        run_env = None
    else:
        run_env = dict(env)
        cwd_str = str(cwd)
        run_env["PWD"] = cwd_str
        run_env["INIT_CWD"] = cwd_str
    result = subprocess.run(
        cmd,
        cwd=cwd,
        text=True,
        capture_output=True,
        check=False,
        env=run_env,
    )
    if result.returncode != 0:
        stderr = (result.stderr or "").strip()
        stdout = (result.stdout or "").strip()
        details = stderr or stdout or "(no output)"
        raise ConfigError(f"Command failed: {details}")
    return (result.stdout or "").strip()


def extract_builds_from_output(output: str) -> list[dict[str, Any]]:
    if not output:
        return []
    try:
        data = json.loads(output)
    except json.JSONDecodeError:
        return []
    if isinstance(data, dict):
        builds = data.get("builds")
        if isinstance(builds, list):
            return [item for item in builds if isinstance(item, dict)]
        if isinstance(data.get("build"), dict):
            return [data["build"]]
    if isinstance(data, list):
        return [item for item in data if isinstance(item, dict)]
    return []


def fetch_latest_builds(
    *,
    config: expo_config.ExpoConfig,
    cwd: Path,
    platform: str,
    profile: str,
) -> list[dict[str, Any]]:
    platforms = [platform]
    if platform == "all":
        platforms = ["ios", "android"]
    builds: list[dict[str, Any]] = []
    for target in platforms:
        cmd = [
            config.eas_bin,
            "build:list",
            "--limit",
            "1",
            "--platform",
            target,
            "--json",
        ]
        if profile:
            cmd.extend(["--profile", profile])
        if config.non_interactive:
            cmd.append("--non-interactive")
        output = _run_cmd(cmd, cwd=cwd, env=expo_config.expo_env(config))
        try:
            data = json.loads(output)
        except json.JSONDecodeError:
            continue
        if isinstance(data, list) and data:
            if isinstance(data[0], dict):
                builds.append(data[0])
    return builds
