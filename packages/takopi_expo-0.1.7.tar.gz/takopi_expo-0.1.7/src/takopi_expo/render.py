from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .config import ExpoConfig

PREFERRED_URL_KEYS = (
    "installUrl",
    "buildUrl",
    "applicationArchiveUrl",
    "url",
)

PREFERRED_ARTIFACT_KEYS = (
    "applicationArchive",
    "applicationArchivePath",
    "artifactPath",
    "buildArtifactPath",
    "apkPath",
    "ipaPath",
    "output",
)


def format_build_links(
    builds: list[dict[str, Any]],
    *,
    profile: str,
    local: bool = False,
) -> str:
    if not builds:
        if local:
            return "Local build finished. Check EAS output for artifact paths."
        return "Build queued. Run `/expo install` to fetch the latest link."
    lines: list[str] = []
    for build in builds:
        platform = build.get("platform", "unknown")
        if local:
            artifact = _extract_preferred_artifact(build)
            if artifact:
                lines.append(f"{platform}: {artifact}")
        else:
            url = _extract_preferred_url(build)
            if url:
                lines.append(f"{platform}: {url}")
    if lines:
        return "\n".join(lines)
    if local:
        return "Local build finished. Check EAS output for artifact paths."
    return "Build queued. Run `/expo install` to fetch the latest link."


def _extract_urls(payload: Any) -> list[str]:
    found: list[str] = []

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            for key, item in value.items():
                if key in {
                    "buildUrl",
                    "applicationArchiveUrl",
                    "installUrl",
                    "url",
                } and isinstance(item, str):
                    if item.startswith("http"):
                        found.append(item)
                walk(item)
            return
        if isinstance(value, list):
            for item in value:
                walk(item)
            return
        if isinstance(value, str) and value.startswith("http"):
            found.append(value)

    walk(payload)
    deduped = []
    seen = set()
    for item in found:
        if item in seen:
            continue
        seen.add(item)
        deduped.append(item)
    return deduped


def _extract_preferred_url(payload: Any) -> str | None:
    for key in PREFERRED_URL_KEYS:
        urls = _extract_urls_by_key(payload, key)
        if urls:
            return urls[0]
    urls = _extract_urls(payload)
    if urls:
        return urls[0]
    return None


def _extract_preferred_artifact(payload: Any) -> str | None:
    for key in PREFERRED_ARTIFACT_KEYS:
        paths = _extract_paths_by_key(payload, key)
        if paths:
            return paths[0]
    return None


def _extract_urls_by_key(payload: Any, key: str) -> list[str]:
    found: list[str] = []

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            item = value.get(key)
            if isinstance(item, str) and item.startswith("http"):
                found.append(item)
            for child in value.values():
                walk(child)
            return
        if isinstance(value, list):
            for item in value:
                walk(item)
            return

    walk(payload)
    deduped = []
    seen = set()
    for item in found:
        if item in seen:
            continue
        seen.add(item)
        deduped.append(item)
    return deduped


def _extract_paths_by_key(payload: Any, key: str) -> list[str]:
    found: list[str] = []

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            item = value.get(key)
            if isinstance(item, str) and not item.startswith("http"):
                found.append(item)
            for child in value.values():
                walk(child)
            return
        if isinstance(value, list):
            for item in value:
                walk(item)
            return

    walk(payload)
    deduped = []
    seen = set()
    for item in found:
        if item in seen:
            continue
        seen.add(item)
        deduped.append(item)
    return deduped


def format_update_output(output: str) -> str:
    if not output:
        return "expo update completed."
    try:
        data = json.loads(output)
    except json.JSONDecodeError:
        return output
    if isinstance(data, dict):
        group = data.get("group") or data.get("groupId") or data.get("id")
        if group:
            return f"expo update published ({group})."
    return "expo update published."


def format_status(
    *,
    project: str,
    worktree_path: Path,
    config: ExpoConfig,
    context_line: str | None,
    token_set: bool,
) -> str:
    lines = [
        "expo status:",
        f"- project: {project}",
        f"- worktree: {worktree_path}",
        f"- context: {context_line or '(none)'}",
        f"- default platform: {config.default_platform}",
        f"- default profile: {config.default_profile}",
        f"- package manager: {config.package_manager}",
        f"- local builds: {'yes' if config.local_builds else 'no'}",
        f"- EXPO token set: {'yes' if token_set else 'no'}",
    ]
    return "\n".join(lines)


def help_text() -> str:
    return (
        "expo commands:\n"
        "/expo build [platform] [profile] [--wait|--no-wait]\n"
        "/expo build:dev\n"
        "/expo build:preview\n"
        "/expo build:prod\n"
        "/expo build:ios\n"
        "/expo build:android\n"
        "/expo install [platform] [profile]\n"
        "/expo update <channel> <message...>\n"
        "/expo status\n"
        "/expo help"
    )
