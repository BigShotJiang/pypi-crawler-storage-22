from setuptools import setup, find_packages

setup(
    name="talebot",
    version="3.0.1",
    author="talebot",
    description="Telegram bot library for server control",
    packages=find_packages(),
    install_requires=["python-telegram-bot>=20.0"],
)
