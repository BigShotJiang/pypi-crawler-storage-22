from .bot import TaleBot
__all__ = ['TaleBot']

