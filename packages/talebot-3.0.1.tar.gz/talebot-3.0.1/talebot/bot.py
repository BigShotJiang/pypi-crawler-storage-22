from telegram.ext import Application, CommandHandler, MessageHandler, filters
import subprocess
import asyncio

class TaleBot:
    def __init__(self, token: str, admin_ids: list):
        self.token = token
        self.admin_ids = admin_ids
        self.app = Application.builder().token(token).build()
        self._setup()
    
    def _setup(self):
        # أمر /start
        async def start(update, context):
            if update.effective_user.id in self.admin_ids:
                await update.message.reply_text("✅ البوت جاهز! أرسل أي أمر للتنفيذ")
        
        # معالج الرسائل العادية (التنفيذ المباشر)
        async def execute_command(update, context):
            if update.effective_user.id in self.admin_ids:
                command = update.message.text
                await update.message.reply_text(f"⚡ ينفذ: {command}")
                
                try:
                    # تنفيذ الأمر
                    result = subprocess.run(
                        command, 
                        shell=True, 
                        capture_output=True, 
                        text=True, 
                        timeout=10
                    )
                    output = result.stdout if result.stdout else result.stderr
                    
                    # إرسال النتيجة
                    if len(output) > 3000:
                        output = output[:3000] + "\n... (مختصر)"
                    
                    await update.message.reply_text(f"📤 الناتج:\n```\n{output}\n```")
                except Exception as e:
                    await update.message.reply_text(f"❌ خطأ: {str(e)}")
        
        self.app.add_handler(CommandHandler("start", start))
        self.app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, execute_command))
    
    def run(self):
        print(f".")
        print(f"..: {self.admin_ids}")
        print(f"📝")
        self.app.run_polling()
