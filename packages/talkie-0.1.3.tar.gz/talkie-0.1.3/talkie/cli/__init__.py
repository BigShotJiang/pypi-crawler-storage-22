"""CLI module for Talkie."""
