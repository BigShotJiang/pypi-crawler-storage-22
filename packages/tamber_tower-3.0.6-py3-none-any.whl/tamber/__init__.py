"""
tamber-tower: 塔数系统（Ta Numbers）的 Python 实现
"""

from .tamber import tacal, tanum, tascal, talift, strucal, allnum, TaNumber

__all__ = ['tacal', 'tanum', 'tascal', 'talift', 'strucal', 'allnum', 'TaNumber']
__version__ = '3.0.6'
