class TaNumber:
    def __init__(self, value, tower_level=0, ta_positions=None, is_complex=False, complex_parts=None, complex_level=0):
        if value != '∞':
            try:
                # 尝试转换为浮点数
                self.value = float(value)
            except ValueError:
                # 保持原始值（如果无法转换）
                self.value = value
        else:
            self.value = '∞'
        self.tower_level = tower_level  # 0: 常数, 1: 单塔, 2: 双塔, 3+: 多塔
        self.ta_positions = ta_positions or []
        self.is_infinite = value == '∞'
        self.is_complex = is_complex  # 是否为复合塔
        self.complex_parts = complex_parts or []  # 复合塔的部分
        self.complex_level = complex_level  # 复合塔的层数
    
    def get_states(self):
        if self.is_complex:
            # 复合塔的状态集：[a, 0, 0]
            # 规则：((a')')' 的状态集是 [a, 0, 0]
            # 例如：(4')' 的状态集是 [4, 0, 0]
            return [self.value, 0, 0]
        elif self.tower_level == 0:
            return [self.value]
        elif self.tower_level == 1:
            return [self.value, 0]
        elif self.tower_level == 2:
            return [self.value, -self.value, 0]
        else:
            # 多塔数：生成更多可能值
            states = [self.value, 0]
            for i in range(1, self.tower_level):
                states.append((-1)**i * self.value)
            # 多塔数额外添加更多0
            for _ in range(self.tower_level - 2):
                states.append(0)
            return states
    
    def get_possible_values(self):
        return self.get_states()
    
    def __str__(self):
        if self.is_complex:
            # 复合塔表示：((a')')'
            # 规则：((a')')'
            # 例如：((3')')'
            # 处理浮点数显示
            value_str = str(self.value)
            if isinstance(self.value, float) and self.value.is_integer():
                value_str = str(int(self.value))
            return "((%s')')'" % value_str
        elif not self.ta_positions:
            if self.tower_level == 0:
                # 处理浮点数显示
                value_str = str(self.value)
                if isinstance(self.value, float) and self.value.is_integer():
                    value_str = str(int(self.value))
                return value_str
            else:
                # 处理浮点数显示
                value_str = str(self.value)
                if isinstance(self.value, float) and self.value.is_integer():
                    value_str = str(int(self.value))
                return value_str + ("'" * self.tower_level)
        
        s = str(self.value)
        # 处理浮点数显示
        if isinstance(self.value, float) and self.value.is_integer():
            s = str(int(self.value))
        result = []
        for i, char in enumerate(s):
            result.append(char)
            if i in self.ta_positions:
                result.append("'")
        return ''.join(result)
    
    def __repr__(self):
        return self.__str__()

# 外部加法运算
def add(a, b):
    if a.tower_level > 0 and b.tower_level > 0:
        if a.value == b.value:
            return TaNumber(0, 0)
        return TaNumber(b.value, 0)
    
    if a.tower_level > 0 and b.tower_level == 0:
        return TaNumber(b.value, 0)
    
    if a.tower_level == 0 and b.tower_level > 0:
        return TaNumber(a.value + b.value, 0)
    
    return TaNumber(a.value + b.value, 0)

# 外部减法运算
def subtract(a, b):
    if a.tower_level > 0 and b.tower_level > 0:
        return TaNumber(a.value, 0)
    
    if a.tower_level > 0 and b.tower_level == 0:
        return TaNumber(a.value - b.value, 0)
    
    if a.tower_level == 0 and b.tower_level > 0:
        return TaNumber(a.value, 0)
    
    return TaNumber(a.value - b.value, 0)

# 外部乘法运算
def multiply(a, b):
    if a.tower_level > 0 and b.tower_level > 0:
        return TaNumber(a.value * b.value, 1)
    
    if a.tower_level > 0 or b.tower_level > 0:
        return TaNumber(0, 0)
    
    return TaNumber(a.value * b.value, 0)

# 外部除法运算
def divide(a, b):
    if b.value == 0:
        raise ValueError("除数不能为零")
    
    if a.tower_level > 0 and b.tower_level > 0:
        return TaNumber(a.value // b.value, 1)
    
    return TaNumber(a.value // b.value, 0)

# 外部幂运算
def power(a, b):
    if a.tower_level > 0 and b.tower_level > 0:
        return TaNumber(a.value ** b.value, 1)
    
    return TaNumber(a.value ** b.value, 0)

# 外部开方运算
def sqrt(a):
    if a.value < 0:
        raise ValueError("不能对负数开方")
    
    if a.tower_level > 0:
        return TaNumber(int(a.value ** 0.5), 0)
    
    return TaNumber(int(a.value ** 0.5), 0)

# 内部加法运算（⊕）
def inner_add(a, b):
    if a.tower_level == 1 and b.tower_level == 1:
        if a.value == b.value:
            return [2*a.value, a.value, 0]
        else:
            return [a.value, b.value, a.value + b.value, 0]
    elif a.tower_level == 1 and b.tower_level == 2:
        return [a.value + b.value, a.value - b.value, -b.value, a.value, b.value, 0]
    elif a.tower_level == 1 and b.tower_level == 1 and a.value == b.value:
        return [2*a.value, a.value, 0]
    else:
        # 其他情况：合并状态集
        states = a.get_states() + b.get_states()
        return states

# 内部减法运算（⊖）
def inner_subtract(a, b):
    if a.tower_level == 1 and b.tower_level == 1:
        if a.value == b.value:
            # 自减升维
            return TaNumber(a.value, 2)
        else:
            return [a.value, -b.value, a.value - b.value, 0]
    elif a.tower_level == 1 and b.tower_level == 2:
        return [a.value, -b.value, b.value, a.value + b.value, a.value - b.value, 0]
    else:
        # 其他情况：计算差值
        states = []
        for s1 in a.get_states():
            for s2 in b.get_states():
                states.append(s1 - s2)
        return states

# 内部乘法运算（⊗）
def inner_multiply(a, b):
    if a.tower_level == 1 and b.tower_level == 1:
        # a' ⊗ b' = {ab, 0, 0, 0} = (((ab)')')'
        return [a.value * b.value, 0, 0, 0]
    elif a.tower_level == 1 and b.tower_level == 2:
        # a' ⊗ b" = {ab, -ab, 0, 0, 0} = (((ab)")')'
        return [a.value * b.value, -a.value * b.value, 0, 0, 0]
    elif a.tower_level == 2 and b.tower_level == 1:
        # a" ⊗ b' = {ab, -ab, 0, 0, 0} = (((ab)")')'
        return [a.value * b.value, -a.value * b.value, 0, 0, 0]
    elif a.tower_level == 2 and b.tower_level == 2:
        # a" ⊗ b" = {ab, -ab, -ab, ab, 0, 0, 0, 0, 0} = (((ab)"')')'
        return [a.value * b.value, -a.value * b.value, -a.value * b.value, a.value * b.value, 0, 0, 0, 0, 0]
    elif a.tower_level >= 3 and b.tower_level == 1:
        # 多塔数 ⊗ 单塔数：{ab, -ab, 0, 0, 0}
        return [a.value * b.value, -a.value * b.value, 0, 0, 0]
    elif a.tower_level == 1 and b.tower_level >= 3:
        # 单塔数 ⊗ 多塔数：{ab, -ab, 0, 0, 0}
        return [a.value * b.value, -a.value * b.value, 0, 0, 0]
    else:
        # 其他情况：计算乘积
        states = []
        for s1 in a.get_states():
            for s2 in b.get_states():
                states.append(s1 * s2)
        return states

# 内部除法运算（⊘）
def inner_divide(a, b):
    if b.value == 0:
        return [TaNumber('∞', 1)]
    
    if a.tower_level == 1 and b.tower_level == 1:
        # 结果包含塔数和∞'
        return [TaNumber(a.value // b.value, 1), TaNumber('∞', 1)]
    elif a.tower_level == 1 and b.tower_level == 2:
        # 结果包含双塔数和∞'
        return [TaNumber(a.value // b.value, 2), TaNumber('∞', 1)]
    else:
        # 其他情况：计算商
        states = []
        for s1 in a.get_states():
            for s2 in b.get_states():
                if s2 != 0:
                    states.append(s1 // s2)
        states.append(TaNumber('∞', 1))
        return states

# 解析数字
def parse_number(s):
    s = str(s)
    
    if s == '∞':
        return TaNumber('∞', 0)
    elif s == "∞'":
        return TaNumber('∞', 1)
    
    # 计算塔数级别
    tower_level = 0
    value_part = ""
    ta_positions = []
    
    i = 0
    while i < len(s):
        char = s[i]
        if char == "'":
            tower_level += 1
            i += 1
        elif char.isdigit() or char == '.' or char == '∞':
            # 收集数字、小数点或∞
            j = i
            while j < len(s) and (s[j].isdigit() or s[j] == '.' or s[j] == '∞'):
                j += 1
            value_part = s[i:j]
            
            # 检查是否有塔标记
            if j < len(s) and s[j] == "'":
                # 处理塔标记
                k = j
                while k < len(s) and s[k] == "'":
                    tower_level += 1
                    k += 1
                i = k
            else:
                i = j
        else:
            raise ValueError(f"无效字符: {char}")
    
    if tower_level > 0:
        return TaNumber(value_part, tower_level)
    
    return TaNumber(value_part, 0)

# 升维运算
def talift(expr):
    """
    升维运算器
    输入：字符串表达式，格式为 左操作数 # 右操作数
    输出：升维后的塔数
    """
    # 解析表达式
    parts = expr.split('#')
    if len(parts) != 2:
        raise ValueError("升维运算表达式格式错误，应为 '左操作数 # 右操作数'")
    
    left_str = parts[0].strip()
    right_str = parts[1].strip()
    
    # 解析左右操作数
    left = parse_number(left_str)
    right = parse_number(right_str)
    
    # 应用升维规则
    if left.tower_level == 0 and right.tower_level == 0:
        # 规则1：L常数，R常数 → 多塔数
        k = right.value
        # 确保 k 是整数
        try:
            k = int(k)
        except (ValueError, TypeError):
            raise ValueError("升维运算的右操作数必须是整数")
        return TaNumber(left.value, k)
    elif left.tower_level > 0 and right.tower_level == 0:
        # 规则2：L塔数，R常数 → 多塔数
        k = right.value
        # 确保 k 是整数
        try:
            k = int(k)
        except (ValueError, TypeError):
            raise ValueError("升维运算的右操作数必须是整数")
        return TaNumber(left.value, left.tower_level + k)
    elif left.tower_level == 0 and right.tower_level > 0:
        # 规则3：L常数，R塔数 → 复合塔
        b = right.value
        if b == 1:
            return TaNumber(left.value, 1)
        else:
            # 创建复合塔 ((a')')'
            # 例如：1 # 3' = ((1')')'
            # 例如：1 # 4' = ((1')')'
            # 按照示例，所有常数 # 塔数都生成 ((a')')'
            return TaNumber(left.value, 1, is_complex=True, complex_level=2)
    else:
        # 规则4：L塔数，R塔数 → 复合塔
        b = right.value
        # 创建复合塔 ((a^{(m)})')'
        # 例如：1' # 2' = ((1')')'
        # 例如：5' # 6' = ((5')')'
        # 按照示例，所有塔数 # 塔数都生成 ((a')')'
        return TaNumber(left.value, left.tower_level, is_complex=True, complex_level=2)

# 外部运算器
def tacal(expr):
    def tokenize(expr):
        tokens = []
        i = 0
        n = len(expr)
        
        while i < n:
            char = expr[i]
            
            if char.isspace():
                i += 1
            elif char in '()+-×÷^√⊕⊖⊗⊘#':
                tokens.append(char)
                i += 1
            elif char.isdigit() or char == '.' or char == "'" or char == '∞':
                j = i
                while j < n and (expr[j].isdigit() or expr[j] == '.' or expr[j] == "'" or expr[j] == '∞'):
                    j += 1
                tokens.append(expr[i:j])
                i = j
            else:
                raise ValueError(f"无效字符: {char}")
        
        return tokens
    
    def parse(tokens):
        def parse_expression():
            return parse_add_sub()
        
        def parse_add_sub():
            left = parse_mul_div()
            
            while tokens and tokens[0] in '+-':
                op = tokens.pop(0)
                right = parse_mul_div()
                if op == '+':
                    left = add(left, right)
                else:
                    left = subtract(left, right)
            
            return left
        
        def parse_mul_div():
            left = parse_power()
            
            while tokens and tokens[0] in '×÷':
                op = tokens.pop(0)
                right = parse_power()
                if op == '×':
                    left = multiply(left, right)
                else:
                    left = divide(left, right)
            
            return left
        
        def parse_power():
            left = parse_sqrt()
            
            if tokens and tokens[0] == '^':
                tokens.pop(0)
                right = parse_power()
                left = power(left, right)
            
            return left
        
        def parse_sqrt():
            if tokens and tokens[0] == '√':
                tokens.pop(0)
                right = parse_sqrt()
                return sqrt(right)
            
            return parse_lift()
        
        def parse_lift():
            left = parse_primary()
            
            while tokens and tokens[0] == '#':
                tokens.pop(0)
                right = parse_primary()
                # 构建升维表达式
                lift_expr = f"{str(left)} #{str(right)}"
                left = talift(lift_expr)
            
            return left
        
        def parse_primary():
            if not tokens:
                raise ValueError("表达式不完整")
            
            token = tokens.pop(0)
            
            if token == '(':
                expr = parse_expression()
                if not tokens or tokens.pop(0) != ')':
                    raise ValueError("括号不匹配")
                return expr
            
            return parse_number(token)
        
        return parse_expression()
    
    tokens = tokenize(expr)
    return parse(tokens)

# 内部运算器
def tascal(expr):
    def tokenize(expr):
        tokens = []
        i = 0
        n = len(expr)
        
        while i < n:
            char = expr[i]
            
            if char.isspace():
                i += 1
            elif char in '()+-*/^√⊕⊖⊗⊘#':
                tokens.append(char)
                i += 1
            elif char.isdigit() or char == "'" or char == '∞':
                j = i
                while j < n and (expr[j].isdigit() or expr[j] == "'" or expr[j] == '∞'):
                    j += 1
                tokens.append(expr[i:j])
                i = j
            else:
                raise ValueError(f"无效字符: {char}")
        
        return tokens
    
    def parse(tokens):
        def parse_expression():
            return parse_inner_add_sub()
        
        def parse_inner_add_sub():
            left = parse_inner_mul_div()
            
            while tokens and tokens[0] in '⊕⊖+-':
                op = tokens.pop(0)
                right = parse_inner_mul_div()
                if op == '⊕':
                    left = inner_add(left, right)
                elif op == '⊖':
                    left = inner_subtract(left, right)
                elif op == '+':
                    left = inner_add(left, right)
                elif op == '-':
                    left = inner_subtract(left, right)
            
            return left
        
        def parse_inner_mul_div():
            left = parse_power()
            
            while tokens and tokens[0] in '⊗⊘*/':
                op = tokens.pop(0)
                right = parse_power()
                if op == '⊗':
                    left = inner_multiply(left, right)
                elif op == '⊘':
                    left = inner_divide(left, right)
                elif op == '*':
                    left = inner_multiply(left, right)
                elif op == '/':
                    left = inner_divide(left, right)
            
            return left
        
        def parse_power():
            left = parse_sqrt()
            
            if tokens and tokens[0] == '^':
                tokens.pop(0)
                right = parse_power()
                left = inner_multiply(left, right)  # 内部幂运算
            
            return left
        
        def parse_sqrt():
            if tokens and tokens[0] == '√':
                tokens.pop(0)
                right = parse_sqrt()
                # 内部开方运算
                if isinstance(right, TaNumber):
                    return TaNumber(int(right.value ** 0.5), right.tower_level)
                return right
            
            return parse_lift()
        
        def parse_lift():
            left = parse_primary()
            
            while tokens and tokens[0] == '#':
                tokens.pop(0)
                right = parse_primary()
                # 构建升维表达式
                lift_expr = f"{str(left)} #{str(right)}"
                left = talift(lift_expr)
            
            return left
        
        def parse_primary():
            if not tokens:
                raise ValueError("表达式不完整")
            
            token = tokens.pop(0)
            
            if token == '(':
                expr = parse_expression()
                if not tokens or tokens.pop(0) != ')':
                    raise ValueError("括号不匹配")
                return expr
            
            return parse_number(token)
        
        return parse_expression()
    
    tokens = tokenize(expr)
    return parse(tokens)

# 结构运算器
def strucal(expr):
    """
    结构运算器
    输入：字符串表达式，包含复合塔结构和升维运算
    输出：层次化的结果结构表示
    """
    expr = expr.strip()
    
    # 检查是否是复合塔的字符串表示（如 ((3')')'）
    if expr.startswith("((") and expr.endswith("')'"):
        try:
            # 提取中间的值
            # 对于 ((3')')'，去掉前 2 个字符和后 3 个字符，得到 (3')
            inner = expr[2:-3]
            # 再处理内部的括号，提取 3'
            if inner.startswith("(") and inner.endswith(")"):
                inner_value = inner[1:-1]
                if inner_value.endswith("'"):
                    value = inner_value[:-1]
                    result = TaNumber(value, 1, is_complex=True, complex_level=2)
                else:
                    result = TaNumber(inner_value, 1, is_complex=True, complex_level=2)
            else:
                result = tascal(expr)
        except:
            # 直接创建复合塔，避免解析错误
            # 从表达式中提取数字部分
            import re
            match = re.search(r'\d+(?:\.\d+)?', expr)
            if match:
                value = match.group()
                result = TaNumber(value, 1, is_complex=True, complex_level=2)
            else:
                result = tascal(expr)
    else:
        result = tascal(expr)
    
    # 构建层次化结构
    def build_structure(value):
        if isinstance(value, TaNumber):
            if value.is_complex:
                return {
                    "type": "complex_tower",
                    "value": value.value,
                    "levels": len(value.complex_parts),
                    "parts": [build_structure(part) for part in value.complex_parts]
                }
            else:
                return {
                    "type": "tower_number",
                    "value": value.value,
                    "tower_level": value.tower_level,
                    "states": value.get_states()
                }
        elif isinstance(value, list):
            return {
                "type": "state_set",
                "values": [build_structure(v) if isinstance(v, TaNumber) else v for v in value]
            }
        else:
            return {
                "type": "constant",
                "value": value
            }
    
    return build_structure(result)

# 全值展开器
def allnum(expr):
    """
    全值展开器
    输入：塔数表达式或单个塔数（可含 #）
    输出：所有可能值的列表（完全展开）
    """
    # 尝试作为内部运算解析
    try:
        result = tascal(expr)
    except:
        # 尝试作为外部运算解析
        result = tacal(expr)
    
    def extract_values(value):
        if isinstance(value, TaNumber):
            return value.get_states()
        elif isinstance(value, list):
            values = []
            for item in value:
                if isinstance(item, TaNumber):
                    values.extend(item.get_states())
                else:
                    values.append(item)
            return values
        else:
            return [value]
    
    return extract_values(result)

# 将塔数转换为常数，返回可能的值集合
def tanum(ta_num):
    """
    将塔数转换为常数
    输入：塔数对象
    输出：可能的值集合
    """
    if isinstance(ta_num, TaNumber):
        return ta_num.get_states()
    else:
        return [ta_num]