# TamilPP (Tamil Programming Language)

TamilPP is a programming language that allows you to write Python code using Tamil keywords.

## Installation
```bash
pip install tamilpp