# tandoor-client v2.5.0

Auto-generated Python client for the [Tandoor Recipes](https://tandoor.dev) API.

## Installation

```bash
pip install tandoor-client
```

## Usage

```python
from tandoor_client import Client

client = Client(base_url="https://your-tandoor-instance.com")
```

See the [main repository](https://github.com/FeatureCreep-dev/tandoor-api) for more details.
