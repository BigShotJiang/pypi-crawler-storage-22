# tandoor-client v2.5.1

Auto-generated Python client for the [Tandoor Recipes](https://tandoor.dev) API.

## Installation

```bash
pip install tandoor-client
```

## Usage

Most endpoints require authentication. Use `AuthenticatedClient` with an API token
from your Tandoor instance (Settings > API Browser > Tokens).

```python
from tandoor_client import AuthenticatedClient

client = AuthenticatedClient(
    base_url="https://your-tandoor-instance.com",
    token="your-api-token",
)
```

### Example: List Recipes

```python
from tandoor_client.api.recipe import recipe_list

response = recipe_list.sync(client=client)
```

See the [pipeline repository](https://github.com/featurecreep-cron/tandoor-api) for full documentation.
