from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_automation_list_type_item import ApiAutomationListTypeItem
from ...models.paginated_automation_list import PaginatedAutomationList
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    type_: list[ApiAutomationListTypeItem] | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["page"] = page

    params["page_size"] = page_size

    json_type_: list[str] | Unset = UNSET
    if not isinstance(type_, Unset):
        json_type_ = []
        for type_item_data in type_:
            type_item = type_item_data.value
            json_type_.append(type_item)

    params["type"] = json_type_

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/automation/",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PaginatedAutomationList | None:
    if response.status_code == 200:
        response_200 = PaginatedAutomationList.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PaginatedAutomationList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    type_: list[ApiAutomationListTypeItem] | Unset = UNSET,
) -> Response[PaginatedAutomationList]:
    """logs request counts to redis cache total/per user/

    Args:
        page (int | Unset):
        page_size (int | Unset):
        type_ (list[ApiAutomationListTypeItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedAutomationList]
    """

    kwargs = _get_kwargs(
        page=page,
        page_size=page_size,
        type_=type_,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    type_: list[ApiAutomationListTypeItem] | Unset = UNSET,
) -> PaginatedAutomationList | None:
    """logs request counts to redis cache total/per user/

    Args:
        page (int | Unset):
        page_size (int | Unset):
        type_ (list[ApiAutomationListTypeItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedAutomationList
    """

    return sync_detailed(
        client=client,
        page=page,
        page_size=page_size,
        type_=type_,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    type_: list[ApiAutomationListTypeItem] | Unset = UNSET,
) -> Response[PaginatedAutomationList]:
    """logs request counts to redis cache total/per user/

    Args:
        page (int | Unset):
        page_size (int | Unset):
        type_ (list[ApiAutomationListTypeItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedAutomationList]
    """

    kwargs = _get_kwargs(
        page=page,
        page_size=page_size,
        type_=type_,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    type_: list[ApiAutomationListTypeItem] | Unset = UNSET,
) -> PaginatedAutomationList | None:
    """logs request counts to redis cache total/per user/

    Args:
        page (int | Unset):
        page_size (int | Unset):
        type_ (list[ApiAutomationListTypeItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedAutomationList
    """

    return (
        await asyncio_detailed(
            client=client,
            page=page,
            page_size=page_size,
            type_=type_,
        )
    ).parsed
