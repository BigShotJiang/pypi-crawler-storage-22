from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.paginated_generic_model_reference_list import PaginatedGenericModelReferenceList
from ...types import UNSET, Response, Unset


def _get_kwargs(
    id: int,
    *,
    cache: bool | Unset = True,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["cache"] = cache

    params["page"] = page

    params["page_size"] = page_size

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/connector-config/{id}/cascading/".format(
            id=quote(str(id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PaginatedGenericModelReferenceList | None:
    if response.status_code == 200:
        response_200 = PaginatedGenericModelReferenceList.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PaginatedGenericModelReferenceList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: int,
    *,
    client: AuthenticatedClient,
    cache: bool | Unset = True,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
) -> Response[PaginatedGenericModelReferenceList]:
    """get a paginated list of objects that will be cascaded (deleted) when deleting the selected object

    Args:
        id (int):
        cache (bool | Unset):  Default: True.
        page (int | Unset):
        page_size (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedGenericModelReferenceList]
    """

    kwargs = _get_kwargs(
        id=id,
        cache=cache,
        page=page,
        page_size=page_size,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: int,
    *,
    client: AuthenticatedClient,
    cache: bool | Unset = True,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
) -> PaginatedGenericModelReferenceList | None:
    """get a paginated list of objects that will be cascaded (deleted) when deleting the selected object

    Args:
        id (int):
        cache (bool | Unset):  Default: True.
        page (int | Unset):
        page_size (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedGenericModelReferenceList
    """

    return sync_detailed(
        id=id,
        client=client,
        cache=cache,
        page=page,
        page_size=page_size,
    ).parsed


async def asyncio_detailed(
    id: int,
    *,
    client: AuthenticatedClient,
    cache: bool | Unset = True,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
) -> Response[PaginatedGenericModelReferenceList]:
    """get a paginated list of objects that will be cascaded (deleted) when deleting the selected object

    Args:
        id (int):
        cache (bool | Unset):  Default: True.
        page (int | Unset):
        page_size (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedGenericModelReferenceList]
    """

    kwargs = _get_kwargs(
        id=id,
        cache=cache,
        page=page,
        page_size=page_size,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: int,
    *,
    client: AuthenticatedClient,
    cache: bool | Unset = True,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
) -> PaginatedGenericModelReferenceList | None:
    """get a paginated list of objects that will be cascaded (deleted) when deleting the selected object

    Args:
        id (int):
        cache (bool | Unset):  Default: True.
        page (int | Unset):
        page_size (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedGenericModelReferenceList
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
            cache=cache,
            page=page,
            page_size=page_size,
        )
    ).parsed
