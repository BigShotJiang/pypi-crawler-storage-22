from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.fdc_query import FdcQuery
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    data_type: list[str] | Unset = UNSET,
    query: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_data_type: list[str] | Unset = UNSET
    if not isinstance(data_type, Unset):
        json_data_type = data_type

    params["dataType"] = json_data_type

    params["query"] = query

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/fdc-search/",
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> FdcQuery | None:
    if response.status_code == 200:
        response_200 = FdcQuery.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[FdcQuery]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    data_type: list[str] | Unset = UNSET,
    query: str | Unset = UNSET,
) -> Response[FdcQuery]:
    """
    Args:
        data_type (list[str] | Unset):
        query (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FdcQuery]
    """

    kwargs = _get_kwargs(
        data_type=data_type,
        query=query,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    data_type: list[str] | Unset = UNSET,
    query: str | Unset = UNSET,
) -> FdcQuery | None:
    """
    Args:
        data_type (list[str] | Unset):
        query (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FdcQuery
    """

    return sync_detailed(
        client=client,
        data_type=data_type,
        query=query,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    data_type: list[str] | Unset = UNSET,
    query: str | Unset = UNSET,
) -> Response[FdcQuery]:
    """
    Args:
        data_type (list[str] | Unset):
        query (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FdcQuery]
    """

    kwargs = _get_kwargs(
        data_type=data_type,
        query=query,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    data_type: list[str] | Unset = UNSET,
    query: str | Unset = UNSET,
) -> FdcQuery | None:
    """
    Args:
        data_type (list[str] | Unset):
        query (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FdcQuery
    """

    return (
        await asyncio_detailed(
            client=client,
            data_type=data_type,
            query=query,
        )
    ).parsed
