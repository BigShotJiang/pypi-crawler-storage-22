from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.paginated_food_list import PaginatedFoodList
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    limit: str | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    random: str | Unset = UNSET,
    root: int | Unset = UNSET,
    root_tree: int | Unset = UNSET,
    tree: int | Unset = UNSET,
    updated_at: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["page"] = page

    params["page_size"] = page_size

    params["query"] = query

    params["random"] = random

    params["root"] = root

    params["root_tree"] = root_tree

    params["tree"] = tree

    params["updated_at"] = updated_at

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/food/",
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> PaginatedFoodList | None:
    if response.status_code == 200:
        response_200 = PaginatedFoodList.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[PaginatedFoodList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    limit: str | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    random: str | Unset = UNSET,
    root: int | Unset = UNSET,
    root_tree: int | Unset = UNSET,
    tree: int | Unset = UNSET,
    updated_at: str | Unset = UNSET,
) -> Response[PaginatedFoodList]:
    """logs request counts to redis cache total/per user/

    Args:
        limit (str | Unset):
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):
        random (str | Unset):
        root (int | Unset):
        root_tree (int | Unset):
        tree (int | Unset):
        updated_at (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedFoodList]
    """

    kwargs = _get_kwargs(
        limit=limit,
        page=page,
        page_size=page_size,
        query=query,
        random=random,
        root=root,
        root_tree=root_tree,
        tree=tree,
        updated_at=updated_at,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    limit: str | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    random: str | Unset = UNSET,
    root: int | Unset = UNSET,
    root_tree: int | Unset = UNSET,
    tree: int | Unset = UNSET,
    updated_at: str | Unset = UNSET,
) -> PaginatedFoodList | None:
    """logs request counts to redis cache total/per user/

    Args:
        limit (str | Unset):
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):
        random (str | Unset):
        root (int | Unset):
        root_tree (int | Unset):
        tree (int | Unset):
        updated_at (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedFoodList
    """

    return sync_detailed(
        client=client,
        limit=limit,
        page=page,
        page_size=page_size,
        query=query,
        random=random,
        root=root,
        root_tree=root_tree,
        tree=tree,
        updated_at=updated_at,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    limit: str | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    random: str | Unset = UNSET,
    root: int | Unset = UNSET,
    root_tree: int | Unset = UNSET,
    tree: int | Unset = UNSET,
    updated_at: str | Unset = UNSET,
) -> Response[PaginatedFoodList]:
    """logs request counts to redis cache total/per user/

    Args:
        limit (str | Unset):
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):
        random (str | Unset):
        root (int | Unset):
        root_tree (int | Unset):
        tree (int | Unset):
        updated_at (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedFoodList]
    """

    kwargs = _get_kwargs(
        limit=limit,
        page=page,
        page_size=page_size,
        query=query,
        random=random,
        root=root,
        root_tree=root_tree,
        tree=tree,
        updated_at=updated_at,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    limit: str | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    random: str | Unset = UNSET,
    root: int | Unset = UNSET,
    root_tree: int | Unset = UNSET,
    tree: int | Unset = UNSET,
    updated_at: str | Unset = UNSET,
) -> PaginatedFoodList | None:
    """logs request counts to redis cache total/per user/

    Args:
        limit (str | Unset):
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):
        random (str | Unset):
        root (int | Unset):
        root_tree (int | Unset):
        tree (int | Unset):
        updated_at (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedFoodList
    """

    return (
        await asyncio_detailed(
            client=client,
            limit=limit,
            page=page,
            page_size=page_size,
            query=query,
            random=random,
            root=root,
            root_tree=root_tree,
            tree=tree,
            updated_at=updated_at,
        )
    ).parsed
