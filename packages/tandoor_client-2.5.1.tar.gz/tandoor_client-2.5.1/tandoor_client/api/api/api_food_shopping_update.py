from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.food_shopping_update import FoodShoppingUpdate
from ...types import UNSET, Response


def _get_kwargs(
    id: int,
    *,
    body: FoodShoppingUpdate | FoodShoppingUpdate | FoodShoppingUpdate | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/api/food/{id}/shopping/".format(
            id=quote(str(id), safe=""),
        ),
    }

    if isinstance(body, FoodShoppingUpdate):
        _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, FoodShoppingUpdate):
        _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, FoodShoppingUpdate):
        _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> FoodShoppingUpdate | None:
    if response.status_code == 200:
        response_200 = FoodShoppingUpdate.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[FoodShoppingUpdate]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: int,
    *,
    client: AuthenticatedClient,
    body: FoodShoppingUpdate | FoodShoppingUpdate | FoodShoppingUpdate | Unset = UNSET,
) -> Response[FoodShoppingUpdate]:
    """logs request counts to redis cache total/per user/

    Args:
        id (int):
        body (FoodShoppingUpdate):
        body (FoodShoppingUpdate):
        body (FoodShoppingUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FoodShoppingUpdate]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: int,
    *,
    client: AuthenticatedClient,
    body: FoodShoppingUpdate | FoodShoppingUpdate | FoodShoppingUpdate | Unset = UNSET,
) -> FoodShoppingUpdate | None:
    """logs request counts to redis cache total/per user/

    Args:
        id (int):
        body (FoodShoppingUpdate):
        body (FoodShoppingUpdate):
        body (FoodShoppingUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FoodShoppingUpdate
    """

    return sync_detailed(
        id=id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    id: int,
    *,
    client: AuthenticatedClient,
    body: FoodShoppingUpdate | FoodShoppingUpdate | FoodShoppingUpdate | Unset = UNSET,
) -> Response[FoodShoppingUpdate]:
    """logs request counts to redis cache total/per user/

    Args:
        id (int):
        body (FoodShoppingUpdate):
        body (FoodShoppingUpdate):
        body (FoodShoppingUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FoodShoppingUpdate]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: int,
    *,
    client: AuthenticatedClient,
    body: FoodShoppingUpdate | FoodShoppingUpdate | FoodShoppingUpdate | Unset = UNSET,
) -> FoodShoppingUpdate | None:
    """logs request counts to redis cache total/per user/

    Args:
        id (int):
        body (FoodShoppingUpdate):
        body (FoodShoppingUpdate):
        body (FoodShoppingUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FoodShoppingUpdate
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
            body=body,
        )
    ).parsed
