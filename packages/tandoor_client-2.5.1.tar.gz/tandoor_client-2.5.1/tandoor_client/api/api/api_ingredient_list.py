from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.paginated_ingredient_list import PaginatedIngredientList
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    food: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    unit: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["food"] = food

    params["page"] = page

    params["page_size"] = page_size

    params["unit"] = unit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/ingredient/",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PaginatedIngredientList | None:
    if response.status_code == 200:
        response_200 = PaginatedIngredientList.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PaginatedIngredientList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    food: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    unit: int | Unset = UNSET,
) -> Response[PaginatedIngredientList]:
    """logs request counts to redis cache total/per user/

    Args:
        food (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        unit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedIngredientList]
    """

    kwargs = _get_kwargs(
        food=food,
        page=page,
        page_size=page_size,
        unit=unit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    food: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    unit: int | Unset = UNSET,
) -> PaginatedIngredientList | None:
    """logs request counts to redis cache total/per user/

    Args:
        food (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        unit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedIngredientList
    """

    return sync_detailed(
        client=client,
        food=food,
        page=page,
        page_size=page_size,
        unit=unit,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    food: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    unit: int | Unset = UNSET,
) -> Response[PaginatedIngredientList]:
    """logs request counts to redis cache total/per user/

    Args:
        food (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        unit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedIngredientList]
    """

    kwargs = _get_kwargs(
        food=food,
        page=page,
        page_size=page_size,
        unit=unit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    food: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    unit: int | Unset = UNSET,
) -> PaginatedIngredientList | None:
    """logs request counts to redis cache total/per user/

    Args:
        food (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        unit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedIngredientList
    """

    return (
        await asyncio_detailed(
            client=client,
            food=food,
            page=page,
            page_size=page_size,
            unit=unit,
        )
    ).parsed
