from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.ingredient_parser_request import IngredientParserRequest
from ...models.ingredient_parser_response import IngredientParserResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: IngredientParserRequest | IngredientParserRequest | IngredientParserRequest | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/ingredient-parser/post/",
    }

    if isinstance(body, IngredientParserRequest):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, IngredientParserRequest):
        if not isinstance(body, Unset):
            _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, IngredientParserRequest):
        if not isinstance(body, Unset):
            _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> IngredientParserResponse | None:
    if response.status_code == 200:
        response_200 = IngredientParserResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[IngredientParserResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: IngredientParserRequest | IngredientParserRequest | IngredientParserRequest | Unset = UNSET,
) -> Response[IngredientParserResponse]:
    """
    Args:
        body (IngredientParserRequest | Unset):
        body (IngredientParserRequest | Unset):
        body (IngredientParserRequest | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[IngredientParserResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: IngredientParserRequest | IngredientParserRequest | IngredientParserRequest | Unset = UNSET,
) -> IngredientParserResponse | None:
    """
    Args:
        body (IngredientParserRequest | Unset):
        body (IngredientParserRequest | Unset):
        body (IngredientParserRequest | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        IngredientParserResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: IngredientParserRequest | IngredientParserRequest | IngredientParserRequest | Unset = UNSET,
) -> Response[IngredientParserResponse]:
    """
    Args:
        body (IngredientParserRequest | Unset):
        body (IngredientParserRequest | Unset):
        body (IngredientParserRequest | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[IngredientParserResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: IngredientParserRequest | IngredientParserRequest | IngredientParserRequest | Unset = UNSET,
) -> IngredientParserResponse | None:
    """
    Args:
        body (IngredientParserRequest | Unset):
        body (IngredientParserRequest | Unset):
        body (IngredientParserRequest | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        IngredientParserResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
