from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.paginated_meal_plan_list import PaginatedMealPlanList
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    from_date: str | Unset = UNSET,
    meal_type: list[str] | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    to_date: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["from_date"] = from_date

    json_meal_type: list[str] | Unset = UNSET
    if not isinstance(meal_type, Unset):
        json_meal_type = meal_type

    params["meal_type"] = json_meal_type

    params["page"] = page

    params["page_size"] = page_size

    params["to_date"] = to_date

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/meal-plan/",
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> PaginatedMealPlanList | None:
    if response.status_code == 200:
        response_200 = PaginatedMealPlanList.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PaginatedMealPlanList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    from_date: str | Unset = UNSET,
    meal_type: list[str] | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    to_date: str | Unset = UNSET,
) -> Response[PaginatedMealPlanList]:
    """logs request counts to redis cache total/per user/

    Args:
        from_date (str | Unset):
        meal_type (list[str] | Unset):
        page (int | Unset):
        page_size (int | Unset):
        to_date (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedMealPlanList]
    """

    kwargs = _get_kwargs(
        from_date=from_date,
        meal_type=meal_type,
        page=page,
        page_size=page_size,
        to_date=to_date,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    from_date: str | Unset = UNSET,
    meal_type: list[str] | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    to_date: str | Unset = UNSET,
) -> PaginatedMealPlanList | None:
    """logs request counts to redis cache total/per user/

    Args:
        from_date (str | Unset):
        meal_type (list[str] | Unset):
        page (int | Unset):
        page_size (int | Unset):
        to_date (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedMealPlanList
    """

    return sync_detailed(
        client=client,
        from_date=from_date,
        meal_type=meal_type,
        page=page,
        page_size=page_size,
        to_date=to_date,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    from_date: str | Unset = UNSET,
    meal_type: list[str] | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    to_date: str | Unset = UNSET,
) -> Response[PaginatedMealPlanList]:
    """logs request counts to redis cache total/per user/

    Args:
        from_date (str | Unset):
        meal_type (list[str] | Unset):
        page (int | Unset):
        page_size (int | Unset):
        to_date (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedMealPlanList]
    """

    kwargs = _get_kwargs(
        from_date=from_date,
        meal_type=meal_type,
        page=page,
        page_size=page_size,
        to_date=to_date,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    from_date: str | Unset = UNSET,
    meal_type: list[str] | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    to_date: str | Unset = UNSET,
) -> PaginatedMealPlanList | None:
    """logs request counts to redis cache total/per user/

    Args:
        from_date (str | Unset):
        meal_type (list[str] | Unset):
        page (int | Unset):
        page_size (int | Unset):
        to_date (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedMealPlanList
    """

    return (
        await asyncio_detailed(
            client=client,
            from_date=from_date,
            meal_type=meal_type,
            page=page,
            page_size=page_size,
            to_date=to_date,
        )
    ).parsed
