from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.recipe import Recipe
from ...types import UNSET, Response, Unset


def _get_kwargs(
    id: int,
    *,
    body: Recipe | Recipe | Recipe | Unset = UNSET,
    provider: int | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["provider"] = provider

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/recipe/{id}/aiproperties/".format(
            id=quote(str(id), safe=""),
        ),
        "params": params,
    }

    if isinstance(body, Recipe):
        _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, Recipe):
        _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, Recipe):
        _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Recipe | None:
    if response.status_code == 200:
        response_200 = Recipe.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Recipe]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: int,
    *,
    client: AuthenticatedClient,
    body: Recipe | Recipe | Recipe | Unset = UNSET,
    provider: int | Unset = UNSET,
) -> Response[Recipe]:
    """logs request counts to redis cache total/per user/

    Args:
        id (int):
        provider (int | Unset):
        body (Recipe): Adds nested create feature
        body (Recipe): Adds nested create feature
        body (Recipe): Adds nested create feature

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Recipe]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
        provider=provider,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: int,
    *,
    client: AuthenticatedClient,
    body: Recipe | Recipe | Recipe | Unset = UNSET,
    provider: int | Unset = UNSET,
) -> Recipe | None:
    """logs request counts to redis cache total/per user/

    Args:
        id (int):
        provider (int | Unset):
        body (Recipe): Adds nested create feature
        body (Recipe): Adds nested create feature
        body (Recipe): Adds nested create feature

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Recipe
    """

    return sync_detailed(
        id=id,
        client=client,
        body=body,
        provider=provider,
    ).parsed


async def asyncio_detailed(
    id: int,
    *,
    client: AuthenticatedClient,
    body: Recipe | Recipe | Recipe | Unset = UNSET,
    provider: int | Unset = UNSET,
) -> Response[Recipe]:
    """logs request counts to redis cache total/per user/

    Args:
        id (int):
        provider (int | Unset):
        body (Recipe): Adds nested create feature
        body (Recipe): Adds nested create feature
        body (Recipe): Adds nested create feature

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Recipe]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
        provider=provider,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: int,
    *,
    client: AuthenticatedClient,
    body: Recipe | Recipe | Recipe | Unset = UNSET,
    provider: int | Unset = UNSET,
) -> Recipe | None:
    """logs request counts to redis cache total/per user/

    Args:
        id (int):
        provider (int | Unset):
        body (Recipe): Adds nested create feature
        body (Recipe): Adds nested create feature
        body (Recipe): Adds nested create feature

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Recipe
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
            body=body,
            provider=provider,
        )
    ).parsed
