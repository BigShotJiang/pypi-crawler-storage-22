from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.paginated_recipe_book_entry_list import PaginatedRecipeBookEntryList
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    book: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    recipe: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["book"] = book

    params["page"] = page

    params["page_size"] = page_size

    params["recipe"] = recipe

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/recipe-book-entry/",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PaginatedRecipeBookEntryList | None:
    if response.status_code == 200:
        response_200 = PaginatedRecipeBookEntryList.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PaginatedRecipeBookEntryList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    book: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    recipe: int | Unset = UNSET,
) -> Response[PaginatedRecipeBookEntryList]:
    """logs request counts to redis cache total/per user/

    Args:
        book (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        recipe (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedRecipeBookEntryList]
    """

    kwargs = _get_kwargs(
        book=book,
        page=page,
        page_size=page_size,
        recipe=recipe,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    book: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    recipe: int | Unset = UNSET,
) -> PaginatedRecipeBookEntryList | None:
    """logs request counts to redis cache total/per user/

    Args:
        book (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        recipe (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedRecipeBookEntryList
    """

    return sync_detailed(
        client=client,
        book=book,
        page=page,
        page_size=page_size,
        recipe=recipe,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    book: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    recipe: int | Unset = UNSET,
) -> Response[PaginatedRecipeBookEntryList]:
    """logs request counts to redis cache total/per user/

    Args:
        book (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        recipe (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedRecipeBookEntryList]
    """

    kwargs = _get_kwargs(
        book=book,
        page=page,
        page_size=page_size,
        recipe=recipe,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    book: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    recipe: int | Unset = UNSET,
) -> PaginatedRecipeBookEntryList | None:
    """logs request counts to redis cache total/per user/

    Args:
        book (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        recipe (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedRecipeBookEntryList
    """

    return (
        await asyncio_detailed(
            client=client,
            book=book,
            page=page,
            page_size=page_size,
            recipe=recipe,
        )
    ).parsed
