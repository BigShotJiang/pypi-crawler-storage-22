from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_recipe_book_list_order_direction import ApiRecipeBookListOrderDirection
from ...models.api_recipe_book_list_order_field import ApiRecipeBookListOrderField
from ...models.paginated_recipe_book_list import PaginatedRecipeBookList
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    limit: str | Unset = UNSET,
    order_direction: ApiRecipeBookListOrderDirection | Unset = UNSET,
    order_field: ApiRecipeBookListOrderField | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    random: str | Unset = UNSET,
    updated_at: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    json_order_direction: str | Unset = UNSET
    if not isinstance(order_direction, Unset):
        json_order_direction = order_direction.value

    params["order_direction"] = json_order_direction

    json_order_field: str | Unset = UNSET
    if not isinstance(order_field, Unset):
        json_order_field = order_field.value

    params["order_field"] = json_order_field

    params["page"] = page

    params["page_size"] = page_size

    params["query"] = query

    params["random"] = random

    params["updated_at"] = updated_at

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/recipe-book/",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PaginatedRecipeBookList | None:
    if response.status_code == 200:
        response_200 = PaginatedRecipeBookList.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PaginatedRecipeBookList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    limit: str | Unset = UNSET,
    order_direction: ApiRecipeBookListOrderDirection | Unset = UNSET,
    order_field: ApiRecipeBookListOrderField | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    random: str | Unset = UNSET,
    updated_at: str | Unset = UNSET,
) -> Response[PaginatedRecipeBookList]:
    """logs request counts to redis cache total/per user/

    Args:
        limit (str | Unset):
        order_direction (ApiRecipeBookListOrderDirection | Unset):
        order_field (ApiRecipeBookListOrderField | Unset):
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):
        random (str | Unset):
        updated_at (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedRecipeBookList]
    """

    kwargs = _get_kwargs(
        limit=limit,
        order_direction=order_direction,
        order_field=order_field,
        page=page,
        page_size=page_size,
        query=query,
        random=random,
        updated_at=updated_at,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    limit: str | Unset = UNSET,
    order_direction: ApiRecipeBookListOrderDirection | Unset = UNSET,
    order_field: ApiRecipeBookListOrderField | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    random: str | Unset = UNSET,
    updated_at: str | Unset = UNSET,
) -> PaginatedRecipeBookList | None:
    """logs request counts to redis cache total/per user/

    Args:
        limit (str | Unset):
        order_direction (ApiRecipeBookListOrderDirection | Unset):
        order_field (ApiRecipeBookListOrderField | Unset):
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):
        random (str | Unset):
        updated_at (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedRecipeBookList
    """

    return sync_detailed(
        client=client,
        limit=limit,
        order_direction=order_direction,
        order_field=order_field,
        page=page,
        page_size=page_size,
        query=query,
        random=random,
        updated_at=updated_at,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    limit: str | Unset = UNSET,
    order_direction: ApiRecipeBookListOrderDirection | Unset = UNSET,
    order_field: ApiRecipeBookListOrderField | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    random: str | Unset = UNSET,
    updated_at: str | Unset = UNSET,
) -> Response[PaginatedRecipeBookList]:
    """logs request counts to redis cache total/per user/

    Args:
        limit (str | Unset):
        order_direction (ApiRecipeBookListOrderDirection | Unset):
        order_field (ApiRecipeBookListOrderField | Unset):
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):
        random (str | Unset):
        updated_at (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedRecipeBookList]
    """

    kwargs = _get_kwargs(
        limit=limit,
        order_direction=order_direction,
        order_field=order_field,
        page=page,
        page_size=page_size,
        query=query,
        random=random,
        updated_at=updated_at,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    limit: str | Unset = UNSET,
    order_direction: ApiRecipeBookListOrderDirection | Unset = UNSET,
    order_field: ApiRecipeBookListOrderField | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    random: str | Unset = UNSET,
    updated_at: str | Unset = UNSET,
) -> PaginatedRecipeBookList | None:
    """logs request counts to redis cache total/per user/

    Args:
        limit (str | Unset):
        order_direction (ApiRecipeBookListOrderDirection | Unset):
        order_field (ApiRecipeBookListOrderField | Unset):
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):
        random (str | Unset):
        updated_at (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedRecipeBookList
    """

    return (
        await asyncio_detailed(
            client=client,
            limit=limit,
            order_direction=order_direction,
            order_field=order_field,
            page=page,
            page_size=page_size,
            query=query,
            random=random,
            updated_at=updated_at,
        )
    ).parsed
