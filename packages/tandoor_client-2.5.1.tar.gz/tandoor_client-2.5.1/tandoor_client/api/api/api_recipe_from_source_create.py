from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.recipe_from_source import RecipeFromSource
from ...models.recipe_from_source_response import RecipeFromSourceResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: RecipeFromSource | RecipeFromSource | RecipeFromSource | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/recipe-from-source/",
    }

    if isinstance(body, RecipeFromSource):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, RecipeFromSource):
        if not isinstance(body, Unset):
            _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, RecipeFromSource):
        if not isinstance(body, Unset):
            _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> RecipeFromSourceResponse | None:
    if response.status_code == 200:
        response_200 = RecipeFromSourceResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[RecipeFromSourceResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: RecipeFromSource | RecipeFromSource | RecipeFromSource | Unset = UNSET,
) -> Response[RecipeFromSourceResponse]:
    """function to retrieve a recipe from a given url or source string
    :param request: standard request with additional post parameters
            - url: url to use for importing recipe
            - data: if no url is given recipe is imported from provided source data
            - (optional) bookmarklet: id of bookmarklet import to use, overrides URL and data attributes
    :return: JsonResponse containing the parsed json and images

    Args:
        body (RecipeFromSource | Unset):
        body (RecipeFromSource | Unset):
        body (RecipeFromSource | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RecipeFromSourceResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: RecipeFromSource | RecipeFromSource | RecipeFromSource | Unset = UNSET,
) -> RecipeFromSourceResponse | None:
    """function to retrieve a recipe from a given url or source string
    :param request: standard request with additional post parameters
            - url: url to use for importing recipe
            - data: if no url is given recipe is imported from provided source data
            - (optional) bookmarklet: id of bookmarklet import to use, overrides URL and data attributes
    :return: JsonResponse containing the parsed json and images

    Args:
        body (RecipeFromSource | Unset):
        body (RecipeFromSource | Unset):
        body (RecipeFromSource | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RecipeFromSourceResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: RecipeFromSource | RecipeFromSource | RecipeFromSource | Unset = UNSET,
) -> Response[RecipeFromSourceResponse]:
    """function to retrieve a recipe from a given url or source string
    :param request: standard request with additional post parameters
            - url: url to use for importing recipe
            - data: if no url is given recipe is imported from provided source data
            - (optional) bookmarklet: id of bookmarklet import to use, overrides URL and data attributes
    :return: JsonResponse containing the parsed json and images

    Args:
        body (RecipeFromSource | Unset):
        body (RecipeFromSource | Unset):
        body (RecipeFromSource | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RecipeFromSourceResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: RecipeFromSource | RecipeFromSource | RecipeFromSource | Unset = UNSET,
) -> RecipeFromSourceResponse | None:
    """function to retrieve a recipe from a given url or source string
    :param request: standard request with additional post parameters
            - url: url to use for importing recipe
            - data: if no url is given recipe is imported from provided source data
            - (optional) bookmarklet: id of bookmarklet import to use, overrides URL and data attributes
    :return: JsonResponse containing the parsed json and images

    Args:
        body (RecipeFromSource | Unset):
        body (RecipeFromSource | Unset):
        body (RecipeFromSource | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RecipeFromSourceResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
