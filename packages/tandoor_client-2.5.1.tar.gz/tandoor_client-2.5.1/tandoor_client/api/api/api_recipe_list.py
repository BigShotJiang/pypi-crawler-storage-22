import datetime
from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.paginated_recipe_overview_list import PaginatedRecipeOverviewList
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    books: list[int] | Unset = UNSET,
    books_and: list[int] | Unset = UNSET,
    books_and_not: list[int] | Unset = UNSET,
    books_or: list[int] | Unset = UNSET,
    books_or_not: list[int] | Unset = UNSET,
    cookedon_gte: datetime.date | Unset = UNSET,
    cookedon_lte: datetime.date | Unset = UNSET,
    createdby: int | Unset = UNSET,
    createdon: datetime.date | Unset = UNSET,
    createdon_gte: datetime.date | Unset = UNSET,
    createdon_lte: datetime.date | Unset = UNSET,
    filter_: int | Unset = UNSET,
    foods: list[int] | Unset = UNSET,
    foods_and: list[int] | Unset = UNSET,
    foods_and_not: list[int] | Unset = UNSET,
    foods_or: list[int] | Unset = UNSET,
    foods_or_not: list[int] | Unset = UNSET,
    include_children: bool | Unset = UNSET,
    internal: bool | Unset = UNSET,
    keywords: list[int] | Unset = UNSET,
    keywords_and: list[int] | Unset = UNSET,
    keywords_and_not: list[int] | Unset = UNSET,
    keywords_or: list[int] | Unset = UNSET,
    keywords_or_not: list[int] | Unset = UNSET,
    makenow: bool | Unset = UNSET,
    new: bool | Unset = UNSET,
    num_recent: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    random: bool | Unset = UNSET,
    rating: int | Unset = UNSET,
    rating_gte: int | Unset = UNSET,
    rating_lte: int | Unset = UNSET,
    sort_order: str | Unset = UNSET,
    timescooked: int | Unset = UNSET,
    timescooked_gte: int | Unset = UNSET,
    timescooked_lte: int | Unset = UNSET,
    units: int | Unset = UNSET,
    updatedon: datetime.date | Unset = UNSET,
    updatedon_gte: datetime.date | Unset = UNSET,
    updatedon_lte: datetime.date | Unset = UNSET,
    viewedon_gte: datetime.date | Unset = UNSET,
    viewedon_lte: datetime.date | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_books: list[int] | Unset = UNSET
    if not isinstance(books, Unset):
        json_books = books

    params["books"] = json_books

    json_books_and: list[int] | Unset = UNSET
    if not isinstance(books_and, Unset):
        json_books_and = books_and

    params["books_and"] = json_books_and

    json_books_and_not: list[int] | Unset = UNSET
    if not isinstance(books_and_not, Unset):
        json_books_and_not = books_and_not

    params["books_and_not"] = json_books_and_not

    json_books_or: list[int] | Unset = UNSET
    if not isinstance(books_or, Unset):
        json_books_or = books_or

    params["books_or"] = json_books_or

    json_books_or_not: list[int] | Unset = UNSET
    if not isinstance(books_or_not, Unset):
        json_books_or_not = books_or_not

    params["books_or_not"] = json_books_or_not

    json_cookedon_gte: str | Unset = UNSET
    if not isinstance(cookedon_gte, Unset):
        json_cookedon_gte = cookedon_gte.isoformat()
    params["cookedon_gte"] = json_cookedon_gte

    json_cookedon_lte: str | Unset = UNSET
    if not isinstance(cookedon_lte, Unset):
        json_cookedon_lte = cookedon_lte.isoformat()
    params["cookedon_lte"] = json_cookedon_lte

    params["createdby"] = createdby

    json_createdon: str | Unset = UNSET
    if not isinstance(createdon, Unset):
        json_createdon = createdon.isoformat()
    params["createdon"] = json_createdon

    json_createdon_gte: str | Unset = UNSET
    if not isinstance(createdon_gte, Unset):
        json_createdon_gte = createdon_gte.isoformat()
    params["createdon_gte"] = json_createdon_gte

    json_createdon_lte: str | Unset = UNSET
    if not isinstance(createdon_lte, Unset):
        json_createdon_lte = createdon_lte.isoformat()
    params["createdon_lte"] = json_createdon_lte

    params["filter"] = filter_

    json_foods: list[int] | Unset = UNSET
    if not isinstance(foods, Unset):
        json_foods = foods

    params["foods"] = json_foods

    json_foods_and: list[int] | Unset = UNSET
    if not isinstance(foods_and, Unset):
        json_foods_and = foods_and

    params["foods_and"] = json_foods_and

    json_foods_and_not: list[int] | Unset = UNSET
    if not isinstance(foods_and_not, Unset):
        json_foods_and_not = foods_and_not

    params["foods_and_not"] = json_foods_and_not

    json_foods_or: list[int] | Unset = UNSET
    if not isinstance(foods_or, Unset):
        json_foods_or = foods_or

    params["foods_or"] = json_foods_or

    json_foods_or_not: list[int] | Unset = UNSET
    if not isinstance(foods_or_not, Unset):
        json_foods_or_not = foods_or_not

    params["foods_or_not"] = json_foods_or_not

    params["include_children"] = include_children

    params["internal"] = internal

    json_keywords: list[int] | Unset = UNSET
    if not isinstance(keywords, Unset):
        json_keywords = keywords

    params["keywords"] = json_keywords

    json_keywords_and: list[int] | Unset = UNSET
    if not isinstance(keywords_and, Unset):
        json_keywords_and = keywords_and

    params["keywords_and"] = json_keywords_and

    json_keywords_and_not: list[int] | Unset = UNSET
    if not isinstance(keywords_and_not, Unset):
        json_keywords_and_not = keywords_and_not

    params["keywords_and_not"] = json_keywords_and_not

    json_keywords_or: list[int] | Unset = UNSET
    if not isinstance(keywords_or, Unset):
        json_keywords_or = keywords_or

    params["keywords_or"] = json_keywords_or

    json_keywords_or_not: list[int] | Unset = UNSET
    if not isinstance(keywords_or_not, Unset):
        json_keywords_or_not = keywords_or_not

    params["keywords_or_not"] = json_keywords_or_not

    params["makenow"] = makenow

    params["new"] = new

    params["num_recent"] = num_recent

    params["page"] = page

    params["page_size"] = page_size

    params["query"] = query

    params["random"] = random

    params["rating"] = rating

    params["rating_gte"] = rating_gte

    params["rating_lte"] = rating_lte

    params["sort_order"] = sort_order

    params["timescooked"] = timescooked

    params["timescooked_gte"] = timescooked_gte

    params["timescooked_lte"] = timescooked_lte

    params["units"] = units

    json_updatedon: str | Unset = UNSET
    if not isinstance(updatedon, Unset):
        json_updatedon = updatedon.isoformat()
    params["updatedon"] = json_updatedon

    json_updatedon_gte: str | Unset = UNSET
    if not isinstance(updatedon_gte, Unset):
        json_updatedon_gte = updatedon_gte.isoformat()
    params["updatedon_gte"] = json_updatedon_gte

    json_updatedon_lte: str | Unset = UNSET
    if not isinstance(updatedon_lte, Unset):
        json_updatedon_lte = updatedon_lte.isoformat()
    params["updatedon_lte"] = json_updatedon_lte

    json_viewedon_gte: str | Unset = UNSET
    if not isinstance(viewedon_gte, Unset):
        json_viewedon_gte = viewedon_gte.isoformat()
    params["viewedon_gte"] = json_viewedon_gte

    json_viewedon_lte: str | Unset = UNSET
    if not isinstance(viewedon_lte, Unset):
        json_viewedon_lte = viewedon_lte.isoformat()
    params["viewedon_lte"] = json_viewedon_lte

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/recipe/",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PaginatedRecipeOverviewList | None:
    if response.status_code == 200:
        response_200 = PaginatedRecipeOverviewList.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PaginatedRecipeOverviewList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    books: list[int] | Unset = UNSET,
    books_and: list[int] | Unset = UNSET,
    books_and_not: list[int] | Unset = UNSET,
    books_or: list[int] | Unset = UNSET,
    books_or_not: list[int] | Unset = UNSET,
    cookedon_gte: datetime.date | Unset = UNSET,
    cookedon_lte: datetime.date | Unset = UNSET,
    createdby: int | Unset = UNSET,
    createdon: datetime.date | Unset = UNSET,
    createdon_gte: datetime.date | Unset = UNSET,
    createdon_lte: datetime.date | Unset = UNSET,
    filter_: int | Unset = UNSET,
    foods: list[int] | Unset = UNSET,
    foods_and: list[int] | Unset = UNSET,
    foods_and_not: list[int] | Unset = UNSET,
    foods_or: list[int] | Unset = UNSET,
    foods_or_not: list[int] | Unset = UNSET,
    include_children: bool | Unset = UNSET,
    internal: bool | Unset = UNSET,
    keywords: list[int] | Unset = UNSET,
    keywords_and: list[int] | Unset = UNSET,
    keywords_and_not: list[int] | Unset = UNSET,
    keywords_or: list[int] | Unset = UNSET,
    keywords_or_not: list[int] | Unset = UNSET,
    makenow: bool | Unset = UNSET,
    new: bool | Unset = UNSET,
    num_recent: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    random: bool | Unset = UNSET,
    rating: int | Unset = UNSET,
    rating_gte: int | Unset = UNSET,
    rating_lte: int | Unset = UNSET,
    sort_order: str | Unset = UNSET,
    timescooked: int | Unset = UNSET,
    timescooked_gte: int | Unset = UNSET,
    timescooked_lte: int | Unset = UNSET,
    units: int | Unset = UNSET,
    updatedon: datetime.date | Unset = UNSET,
    updatedon_gte: datetime.date | Unset = UNSET,
    updatedon_lte: datetime.date | Unset = UNSET,
    viewedon_gte: datetime.date | Unset = UNSET,
    viewedon_lte: datetime.date | Unset = UNSET,
) -> Response[PaginatedRecipeOverviewList]:
    """logs request counts to redis cache total/per user/

    Args:
        books (list[int] | Unset):
        books_and (list[int] | Unset):
        books_and_not (list[int] | Unset):
        books_or (list[int] | Unset):
        books_or_not (list[int] | Unset):
        cookedon_gte (datetime.date | Unset):
        cookedon_lte (datetime.date | Unset):
        createdby (int | Unset):
        createdon (datetime.date | Unset):
        createdon_gte (datetime.date | Unset):
        createdon_lte (datetime.date | Unset):
        filter_ (int | Unset):
        foods (list[int] | Unset):
        foods_and (list[int] | Unset):
        foods_and_not (list[int] | Unset):
        foods_or (list[int] | Unset):
        foods_or_not (list[int] | Unset):
        include_children (bool | Unset):
        internal (bool | Unset):
        keywords (list[int] | Unset):
        keywords_and (list[int] | Unset):
        keywords_and_not (list[int] | Unset):
        keywords_or (list[int] | Unset):
        keywords_or_not (list[int] | Unset):
        makenow (bool | Unset):
        new (bool | Unset):
        num_recent (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):
        random (bool | Unset):
        rating (int | Unset):
        rating_gte (int | Unset):
        rating_lte (int | Unset):
        sort_order (str | Unset):
        timescooked (int | Unset):
        timescooked_gte (int | Unset):
        timescooked_lte (int | Unset):
        units (int | Unset):
        updatedon (datetime.date | Unset):
        updatedon_gte (datetime.date | Unset):
        updatedon_lte (datetime.date | Unset):
        viewedon_gte (datetime.date | Unset):
        viewedon_lte (datetime.date | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedRecipeOverviewList]
    """

    kwargs = _get_kwargs(
        books=books,
        books_and=books_and,
        books_and_not=books_and_not,
        books_or=books_or,
        books_or_not=books_or_not,
        cookedon_gte=cookedon_gte,
        cookedon_lte=cookedon_lte,
        createdby=createdby,
        createdon=createdon,
        createdon_gte=createdon_gte,
        createdon_lte=createdon_lte,
        filter_=filter_,
        foods=foods,
        foods_and=foods_and,
        foods_and_not=foods_and_not,
        foods_or=foods_or,
        foods_or_not=foods_or_not,
        include_children=include_children,
        internal=internal,
        keywords=keywords,
        keywords_and=keywords_and,
        keywords_and_not=keywords_and_not,
        keywords_or=keywords_or,
        keywords_or_not=keywords_or_not,
        makenow=makenow,
        new=new,
        num_recent=num_recent,
        page=page,
        page_size=page_size,
        query=query,
        random=random,
        rating=rating,
        rating_gte=rating_gte,
        rating_lte=rating_lte,
        sort_order=sort_order,
        timescooked=timescooked,
        timescooked_gte=timescooked_gte,
        timescooked_lte=timescooked_lte,
        units=units,
        updatedon=updatedon,
        updatedon_gte=updatedon_gte,
        updatedon_lte=updatedon_lte,
        viewedon_gte=viewedon_gte,
        viewedon_lte=viewedon_lte,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    books: list[int] | Unset = UNSET,
    books_and: list[int] | Unset = UNSET,
    books_and_not: list[int] | Unset = UNSET,
    books_or: list[int] | Unset = UNSET,
    books_or_not: list[int] | Unset = UNSET,
    cookedon_gte: datetime.date | Unset = UNSET,
    cookedon_lte: datetime.date | Unset = UNSET,
    createdby: int | Unset = UNSET,
    createdon: datetime.date | Unset = UNSET,
    createdon_gte: datetime.date | Unset = UNSET,
    createdon_lte: datetime.date | Unset = UNSET,
    filter_: int | Unset = UNSET,
    foods: list[int] | Unset = UNSET,
    foods_and: list[int] | Unset = UNSET,
    foods_and_not: list[int] | Unset = UNSET,
    foods_or: list[int] | Unset = UNSET,
    foods_or_not: list[int] | Unset = UNSET,
    include_children: bool | Unset = UNSET,
    internal: bool | Unset = UNSET,
    keywords: list[int] | Unset = UNSET,
    keywords_and: list[int] | Unset = UNSET,
    keywords_and_not: list[int] | Unset = UNSET,
    keywords_or: list[int] | Unset = UNSET,
    keywords_or_not: list[int] | Unset = UNSET,
    makenow: bool | Unset = UNSET,
    new: bool | Unset = UNSET,
    num_recent: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    random: bool | Unset = UNSET,
    rating: int | Unset = UNSET,
    rating_gte: int | Unset = UNSET,
    rating_lte: int | Unset = UNSET,
    sort_order: str | Unset = UNSET,
    timescooked: int | Unset = UNSET,
    timescooked_gte: int | Unset = UNSET,
    timescooked_lte: int | Unset = UNSET,
    units: int | Unset = UNSET,
    updatedon: datetime.date | Unset = UNSET,
    updatedon_gte: datetime.date | Unset = UNSET,
    updatedon_lte: datetime.date | Unset = UNSET,
    viewedon_gte: datetime.date | Unset = UNSET,
    viewedon_lte: datetime.date | Unset = UNSET,
) -> PaginatedRecipeOverviewList | None:
    """logs request counts to redis cache total/per user/

    Args:
        books (list[int] | Unset):
        books_and (list[int] | Unset):
        books_and_not (list[int] | Unset):
        books_or (list[int] | Unset):
        books_or_not (list[int] | Unset):
        cookedon_gte (datetime.date | Unset):
        cookedon_lte (datetime.date | Unset):
        createdby (int | Unset):
        createdon (datetime.date | Unset):
        createdon_gte (datetime.date | Unset):
        createdon_lte (datetime.date | Unset):
        filter_ (int | Unset):
        foods (list[int] | Unset):
        foods_and (list[int] | Unset):
        foods_and_not (list[int] | Unset):
        foods_or (list[int] | Unset):
        foods_or_not (list[int] | Unset):
        include_children (bool | Unset):
        internal (bool | Unset):
        keywords (list[int] | Unset):
        keywords_and (list[int] | Unset):
        keywords_and_not (list[int] | Unset):
        keywords_or (list[int] | Unset):
        keywords_or_not (list[int] | Unset):
        makenow (bool | Unset):
        new (bool | Unset):
        num_recent (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):
        random (bool | Unset):
        rating (int | Unset):
        rating_gte (int | Unset):
        rating_lte (int | Unset):
        sort_order (str | Unset):
        timescooked (int | Unset):
        timescooked_gte (int | Unset):
        timescooked_lte (int | Unset):
        units (int | Unset):
        updatedon (datetime.date | Unset):
        updatedon_gte (datetime.date | Unset):
        updatedon_lte (datetime.date | Unset):
        viewedon_gte (datetime.date | Unset):
        viewedon_lte (datetime.date | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedRecipeOverviewList
    """

    return sync_detailed(
        client=client,
        books=books,
        books_and=books_and,
        books_and_not=books_and_not,
        books_or=books_or,
        books_or_not=books_or_not,
        cookedon_gte=cookedon_gte,
        cookedon_lte=cookedon_lte,
        createdby=createdby,
        createdon=createdon,
        createdon_gte=createdon_gte,
        createdon_lte=createdon_lte,
        filter_=filter_,
        foods=foods,
        foods_and=foods_and,
        foods_and_not=foods_and_not,
        foods_or=foods_or,
        foods_or_not=foods_or_not,
        include_children=include_children,
        internal=internal,
        keywords=keywords,
        keywords_and=keywords_and,
        keywords_and_not=keywords_and_not,
        keywords_or=keywords_or,
        keywords_or_not=keywords_or_not,
        makenow=makenow,
        new=new,
        num_recent=num_recent,
        page=page,
        page_size=page_size,
        query=query,
        random=random,
        rating=rating,
        rating_gte=rating_gte,
        rating_lte=rating_lte,
        sort_order=sort_order,
        timescooked=timescooked,
        timescooked_gte=timescooked_gte,
        timescooked_lte=timescooked_lte,
        units=units,
        updatedon=updatedon,
        updatedon_gte=updatedon_gte,
        updatedon_lte=updatedon_lte,
        viewedon_gte=viewedon_gte,
        viewedon_lte=viewedon_lte,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    books: list[int] | Unset = UNSET,
    books_and: list[int] | Unset = UNSET,
    books_and_not: list[int] | Unset = UNSET,
    books_or: list[int] | Unset = UNSET,
    books_or_not: list[int] | Unset = UNSET,
    cookedon_gte: datetime.date | Unset = UNSET,
    cookedon_lte: datetime.date | Unset = UNSET,
    createdby: int | Unset = UNSET,
    createdon: datetime.date | Unset = UNSET,
    createdon_gte: datetime.date | Unset = UNSET,
    createdon_lte: datetime.date | Unset = UNSET,
    filter_: int | Unset = UNSET,
    foods: list[int] | Unset = UNSET,
    foods_and: list[int] | Unset = UNSET,
    foods_and_not: list[int] | Unset = UNSET,
    foods_or: list[int] | Unset = UNSET,
    foods_or_not: list[int] | Unset = UNSET,
    include_children: bool | Unset = UNSET,
    internal: bool | Unset = UNSET,
    keywords: list[int] | Unset = UNSET,
    keywords_and: list[int] | Unset = UNSET,
    keywords_and_not: list[int] | Unset = UNSET,
    keywords_or: list[int] | Unset = UNSET,
    keywords_or_not: list[int] | Unset = UNSET,
    makenow: bool | Unset = UNSET,
    new: bool | Unset = UNSET,
    num_recent: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    random: bool | Unset = UNSET,
    rating: int | Unset = UNSET,
    rating_gte: int | Unset = UNSET,
    rating_lte: int | Unset = UNSET,
    sort_order: str | Unset = UNSET,
    timescooked: int | Unset = UNSET,
    timescooked_gte: int | Unset = UNSET,
    timescooked_lte: int | Unset = UNSET,
    units: int | Unset = UNSET,
    updatedon: datetime.date | Unset = UNSET,
    updatedon_gte: datetime.date | Unset = UNSET,
    updatedon_lte: datetime.date | Unset = UNSET,
    viewedon_gte: datetime.date | Unset = UNSET,
    viewedon_lte: datetime.date | Unset = UNSET,
) -> Response[PaginatedRecipeOverviewList]:
    """logs request counts to redis cache total/per user/

    Args:
        books (list[int] | Unset):
        books_and (list[int] | Unset):
        books_and_not (list[int] | Unset):
        books_or (list[int] | Unset):
        books_or_not (list[int] | Unset):
        cookedon_gte (datetime.date | Unset):
        cookedon_lte (datetime.date | Unset):
        createdby (int | Unset):
        createdon (datetime.date | Unset):
        createdon_gte (datetime.date | Unset):
        createdon_lte (datetime.date | Unset):
        filter_ (int | Unset):
        foods (list[int] | Unset):
        foods_and (list[int] | Unset):
        foods_and_not (list[int] | Unset):
        foods_or (list[int] | Unset):
        foods_or_not (list[int] | Unset):
        include_children (bool | Unset):
        internal (bool | Unset):
        keywords (list[int] | Unset):
        keywords_and (list[int] | Unset):
        keywords_and_not (list[int] | Unset):
        keywords_or (list[int] | Unset):
        keywords_or_not (list[int] | Unset):
        makenow (bool | Unset):
        new (bool | Unset):
        num_recent (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):
        random (bool | Unset):
        rating (int | Unset):
        rating_gte (int | Unset):
        rating_lte (int | Unset):
        sort_order (str | Unset):
        timescooked (int | Unset):
        timescooked_gte (int | Unset):
        timescooked_lte (int | Unset):
        units (int | Unset):
        updatedon (datetime.date | Unset):
        updatedon_gte (datetime.date | Unset):
        updatedon_lte (datetime.date | Unset):
        viewedon_gte (datetime.date | Unset):
        viewedon_lte (datetime.date | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedRecipeOverviewList]
    """

    kwargs = _get_kwargs(
        books=books,
        books_and=books_and,
        books_and_not=books_and_not,
        books_or=books_or,
        books_or_not=books_or_not,
        cookedon_gte=cookedon_gte,
        cookedon_lte=cookedon_lte,
        createdby=createdby,
        createdon=createdon,
        createdon_gte=createdon_gte,
        createdon_lte=createdon_lte,
        filter_=filter_,
        foods=foods,
        foods_and=foods_and,
        foods_and_not=foods_and_not,
        foods_or=foods_or,
        foods_or_not=foods_or_not,
        include_children=include_children,
        internal=internal,
        keywords=keywords,
        keywords_and=keywords_and,
        keywords_and_not=keywords_and_not,
        keywords_or=keywords_or,
        keywords_or_not=keywords_or_not,
        makenow=makenow,
        new=new,
        num_recent=num_recent,
        page=page,
        page_size=page_size,
        query=query,
        random=random,
        rating=rating,
        rating_gte=rating_gte,
        rating_lte=rating_lte,
        sort_order=sort_order,
        timescooked=timescooked,
        timescooked_gte=timescooked_gte,
        timescooked_lte=timescooked_lte,
        units=units,
        updatedon=updatedon,
        updatedon_gte=updatedon_gte,
        updatedon_lte=updatedon_lte,
        viewedon_gte=viewedon_gte,
        viewedon_lte=viewedon_lte,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    books: list[int] | Unset = UNSET,
    books_and: list[int] | Unset = UNSET,
    books_and_not: list[int] | Unset = UNSET,
    books_or: list[int] | Unset = UNSET,
    books_or_not: list[int] | Unset = UNSET,
    cookedon_gte: datetime.date | Unset = UNSET,
    cookedon_lte: datetime.date | Unset = UNSET,
    createdby: int | Unset = UNSET,
    createdon: datetime.date | Unset = UNSET,
    createdon_gte: datetime.date | Unset = UNSET,
    createdon_lte: datetime.date | Unset = UNSET,
    filter_: int | Unset = UNSET,
    foods: list[int] | Unset = UNSET,
    foods_and: list[int] | Unset = UNSET,
    foods_and_not: list[int] | Unset = UNSET,
    foods_or: list[int] | Unset = UNSET,
    foods_or_not: list[int] | Unset = UNSET,
    include_children: bool | Unset = UNSET,
    internal: bool | Unset = UNSET,
    keywords: list[int] | Unset = UNSET,
    keywords_and: list[int] | Unset = UNSET,
    keywords_and_not: list[int] | Unset = UNSET,
    keywords_or: list[int] | Unset = UNSET,
    keywords_or_not: list[int] | Unset = UNSET,
    makenow: bool | Unset = UNSET,
    new: bool | Unset = UNSET,
    num_recent: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    random: bool | Unset = UNSET,
    rating: int | Unset = UNSET,
    rating_gte: int | Unset = UNSET,
    rating_lte: int | Unset = UNSET,
    sort_order: str | Unset = UNSET,
    timescooked: int | Unset = UNSET,
    timescooked_gte: int | Unset = UNSET,
    timescooked_lte: int | Unset = UNSET,
    units: int | Unset = UNSET,
    updatedon: datetime.date | Unset = UNSET,
    updatedon_gte: datetime.date | Unset = UNSET,
    updatedon_lte: datetime.date | Unset = UNSET,
    viewedon_gte: datetime.date | Unset = UNSET,
    viewedon_lte: datetime.date | Unset = UNSET,
) -> PaginatedRecipeOverviewList | None:
    """logs request counts to redis cache total/per user/

    Args:
        books (list[int] | Unset):
        books_and (list[int] | Unset):
        books_and_not (list[int] | Unset):
        books_or (list[int] | Unset):
        books_or_not (list[int] | Unset):
        cookedon_gte (datetime.date | Unset):
        cookedon_lte (datetime.date | Unset):
        createdby (int | Unset):
        createdon (datetime.date | Unset):
        createdon_gte (datetime.date | Unset):
        createdon_lte (datetime.date | Unset):
        filter_ (int | Unset):
        foods (list[int] | Unset):
        foods_and (list[int] | Unset):
        foods_and_not (list[int] | Unset):
        foods_or (list[int] | Unset):
        foods_or_not (list[int] | Unset):
        include_children (bool | Unset):
        internal (bool | Unset):
        keywords (list[int] | Unset):
        keywords_and (list[int] | Unset):
        keywords_and_not (list[int] | Unset):
        keywords_or (list[int] | Unset):
        keywords_or_not (list[int] | Unset):
        makenow (bool | Unset):
        new (bool | Unset):
        num_recent (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):
        random (bool | Unset):
        rating (int | Unset):
        rating_gte (int | Unset):
        rating_lte (int | Unset):
        sort_order (str | Unset):
        timescooked (int | Unset):
        timescooked_gte (int | Unset):
        timescooked_lte (int | Unset):
        units (int | Unset):
        updatedon (datetime.date | Unset):
        updatedon_gte (datetime.date | Unset):
        updatedon_lte (datetime.date | Unset):
        viewedon_gte (datetime.date | Unset):
        viewedon_lte (datetime.date | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedRecipeOverviewList
    """

    return (
        await asyncio_detailed(
            client=client,
            books=books,
            books_and=books_and,
            books_and_not=books_and_not,
            books_or=books_or,
            books_or_not=books_or_not,
            cookedon_gte=cookedon_gte,
            cookedon_lte=cookedon_lte,
            createdby=createdby,
            createdon=createdon,
            createdon_gte=createdon_gte,
            createdon_lte=createdon_lte,
            filter_=filter_,
            foods=foods,
            foods_and=foods_and,
            foods_and_not=foods_and_not,
            foods_or=foods_or,
            foods_or_not=foods_or_not,
            include_children=include_children,
            internal=internal,
            keywords=keywords,
            keywords_and=keywords_and,
            keywords_and_not=keywords_and_not,
            keywords_or=keywords_or,
            keywords_or_not=keywords_or_not,
            makenow=makenow,
            new=new,
            num_recent=num_recent,
            page=page,
            page_size=page_size,
            query=query,
            random=random,
            rating=rating,
            rating_gte=rating_gte,
            rating_lte=rating_lte,
            sort_order=sort_order,
            timescooked=timescooked,
            timescooked_gte=timescooked_gte,
            timescooked_lte=timescooked_lte,
            units=units,
            updatedon=updatedon,
            updatedon_gte=updatedon_gte,
            updatedon_lte=updatedon_lte,
            viewedon_gte=viewedon_gte,
            viewedon_lte=viewedon_lte,
        )
    ).parsed
