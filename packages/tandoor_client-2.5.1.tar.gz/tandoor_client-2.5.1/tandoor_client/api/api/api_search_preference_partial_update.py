from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.patched_search_preference import PatchedSearchPreference
from ...models.search_preference import SearchPreference
from ...types import UNSET, Response, Unset


def _get_kwargs(
    user: int,
    *,
    body: PatchedSearchPreference | PatchedSearchPreference | PatchedSearchPreference | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/api/search-preference/{user}/".format(
            user=quote(str(user), safe=""),
        ),
    }

    if isinstance(body, PatchedSearchPreference):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, PatchedSearchPreference):
        if not isinstance(body, Unset):
            _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, PatchedSearchPreference):
        if not isinstance(body, Unset):
            _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> SearchPreference | None:
    if response.status_code == 200:
        response_200 = SearchPreference.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[SearchPreference]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    user: int,
    *,
    client: AuthenticatedClient,
    body: PatchedSearchPreference | PatchedSearchPreference | PatchedSearchPreference | Unset = UNSET,
) -> Response[SearchPreference]:
    """logs request counts to redis cache total/per user/

    Args:
        user (int):
        body (PatchedSearchPreference | Unset): Adds nested create feature
        body (PatchedSearchPreference | Unset): Adds nested create feature
        body (PatchedSearchPreference | Unset): Adds nested create feature

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SearchPreference]
    """

    kwargs = _get_kwargs(
        user=user,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    user: int,
    *,
    client: AuthenticatedClient,
    body: PatchedSearchPreference | PatchedSearchPreference | PatchedSearchPreference | Unset = UNSET,
) -> SearchPreference | None:
    """logs request counts to redis cache total/per user/

    Args:
        user (int):
        body (PatchedSearchPreference | Unset): Adds nested create feature
        body (PatchedSearchPreference | Unset): Adds nested create feature
        body (PatchedSearchPreference | Unset): Adds nested create feature

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SearchPreference
    """

    return sync_detailed(
        user=user,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    user: int,
    *,
    client: AuthenticatedClient,
    body: PatchedSearchPreference | PatchedSearchPreference | PatchedSearchPreference | Unset = UNSET,
) -> Response[SearchPreference]:
    """logs request counts to redis cache total/per user/

    Args:
        user (int):
        body (PatchedSearchPreference | Unset): Adds nested create feature
        body (PatchedSearchPreference | Unset): Adds nested create feature
        body (PatchedSearchPreference | Unset): Adds nested create feature

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SearchPreference]
    """

    kwargs = _get_kwargs(
        user=user,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    user: int,
    *,
    client: AuthenticatedClient,
    body: PatchedSearchPreference | PatchedSearchPreference | PatchedSearchPreference | Unset = UNSET,
) -> SearchPreference | None:
    """logs request counts to redis cache total/per user/

    Args:
        user (int):
        body (PatchedSearchPreference | Unset): Adds nested create feature
        body (PatchedSearchPreference | Unset): Adds nested create feature
        body (PatchedSearchPreference | Unset): Adds nested create feature

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SearchPreference
    """

    return (
        await asyncio_detailed(
            user=user,
            client=client,
            body=body,
        )
    ).parsed
