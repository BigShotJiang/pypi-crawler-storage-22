import datetime
from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.paginated_shopping_list_entry_list import PaginatedShoppingListEntryList
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    mealplan: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    updated_after: datetime.datetime | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["mealplan"] = mealplan

    params["page"] = page

    params["page_size"] = page_size

    json_updated_after: str | Unset = UNSET
    if not isinstance(updated_after, Unset):
        json_updated_after = updated_after.isoformat()
    params["updated_after"] = json_updated_after

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/shopping-list-entry/",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PaginatedShoppingListEntryList | None:
    if response.status_code == 200:
        response_200 = PaginatedShoppingListEntryList.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PaginatedShoppingListEntryList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    mealplan: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    updated_after: datetime.datetime | Unset = UNSET,
) -> Response[PaginatedShoppingListEntryList]:
    """individual entries of a shopping list
    automatically filtered to only contain unchecked items that are not older than the shopping recent
    days setting to not bloat endpoint

    Args:
        mealplan (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        updated_after (datetime.datetime | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedShoppingListEntryList]
    """

    kwargs = _get_kwargs(
        mealplan=mealplan,
        page=page,
        page_size=page_size,
        updated_after=updated_after,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    mealplan: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    updated_after: datetime.datetime | Unset = UNSET,
) -> PaginatedShoppingListEntryList | None:
    """individual entries of a shopping list
    automatically filtered to only contain unchecked items that are not older than the shopping recent
    days setting to not bloat endpoint

    Args:
        mealplan (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        updated_after (datetime.datetime | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedShoppingListEntryList
    """

    return sync_detailed(
        client=client,
        mealplan=mealplan,
        page=page,
        page_size=page_size,
        updated_after=updated_after,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    mealplan: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    updated_after: datetime.datetime | Unset = UNSET,
) -> Response[PaginatedShoppingListEntryList]:
    """individual entries of a shopping list
    automatically filtered to only contain unchecked items that are not older than the shopping recent
    days setting to not bloat endpoint

    Args:
        mealplan (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        updated_after (datetime.datetime | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedShoppingListEntryList]
    """

    kwargs = _get_kwargs(
        mealplan=mealplan,
        page=page,
        page_size=page_size,
        updated_after=updated_after,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    mealplan: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    updated_after: datetime.datetime | Unset = UNSET,
) -> PaginatedShoppingListEntryList | None:
    """individual entries of a shopping list
    automatically filtered to only contain unchecked items that are not older than the shopping recent
    days setting to not bloat endpoint

    Args:
        mealplan (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        updated_after (datetime.datetime | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedShoppingListEntryList
    """

    return (
        await asyncio_detailed(
            client=client,
            mealplan=mealplan,
            page=page,
            page_size=page_size,
            updated_after=updated_after,
        )
    ).parsed
