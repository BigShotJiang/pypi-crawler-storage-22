from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.patched_shopping_list_entry import PatchedShoppingListEntry
from ...models.shopping_list_entry import ShoppingListEntry
from ...types import UNSET, Response, Unset


def _get_kwargs(
    id: int,
    *,
    body: PatchedShoppingListEntry | PatchedShoppingListEntry | PatchedShoppingListEntry | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/api/shopping-list-entry/{id}/".format(
            id=quote(str(id), safe=""),
        ),
    }

    if isinstance(body, PatchedShoppingListEntry):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, PatchedShoppingListEntry):
        if not isinstance(body, Unset):
            _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, PatchedShoppingListEntry):
        if not isinstance(body, Unset):
            _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ShoppingListEntry | None:
    if response.status_code == 200:
        response_200 = ShoppingListEntry.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ShoppingListEntry]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: int,
    *,
    client: AuthenticatedClient,
    body: PatchedShoppingListEntry | PatchedShoppingListEntry | PatchedShoppingListEntry | Unset = UNSET,
) -> Response[ShoppingListEntry]:
    """individual entries of a shopping list
    automatically filtered to only contain unchecked items that are not older than the shopping recent
    days setting to not bloat endpoint

    Args:
        id (int):
        body (PatchedShoppingListEntry | Unset): Adds nested create feature
        body (PatchedShoppingListEntry | Unset): Adds nested create feature
        body (PatchedShoppingListEntry | Unset): Adds nested create feature

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ShoppingListEntry]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: int,
    *,
    client: AuthenticatedClient,
    body: PatchedShoppingListEntry | PatchedShoppingListEntry | PatchedShoppingListEntry | Unset = UNSET,
) -> ShoppingListEntry | None:
    """individual entries of a shopping list
    automatically filtered to only contain unchecked items that are not older than the shopping recent
    days setting to not bloat endpoint

    Args:
        id (int):
        body (PatchedShoppingListEntry | Unset): Adds nested create feature
        body (PatchedShoppingListEntry | Unset): Adds nested create feature
        body (PatchedShoppingListEntry | Unset): Adds nested create feature

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ShoppingListEntry
    """

    return sync_detailed(
        id=id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    id: int,
    *,
    client: AuthenticatedClient,
    body: PatchedShoppingListEntry | PatchedShoppingListEntry | PatchedShoppingListEntry | Unset = UNSET,
) -> Response[ShoppingListEntry]:
    """individual entries of a shopping list
    automatically filtered to only contain unchecked items that are not older than the shopping recent
    days setting to not bloat endpoint

    Args:
        id (int):
        body (PatchedShoppingListEntry | Unset): Adds nested create feature
        body (PatchedShoppingListEntry | Unset): Adds nested create feature
        body (PatchedShoppingListEntry | Unset): Adds nested create feature

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ShoppingListEntry]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: int,
    *,
    client: AuthenticatedClient,
    body: PatchedShoppingListEntry | PatchedShoppingListEntry | PatchedShoppingListEntry | Unset = UNSET,
) -> ShoppingListEntry | None:
    """individual entries of a shopping list
    automatically filtered to only contain unchecked items that are not older than the shopping recent
    days setting to not bloat endpoint

    Args:
        id (int):
        body (PatchedShoppingListEntry | Unset): Adds nested create feature
        body (PatchedShoppingListEntry | Unset): Adds nested create feature
        body (PatchedShoppingListEntry | Unset): Adds nested create feature

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ShoppingListEntry
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
            body=body,
        )
    ).parsed
