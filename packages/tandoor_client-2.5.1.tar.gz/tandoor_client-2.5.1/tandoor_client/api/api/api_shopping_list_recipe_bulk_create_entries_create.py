from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.shopping_list_entry_bulk_create import ShoppingListEntryBulkCreate
from ...types import UNSET, Response


def _get_kwargs(
    id: int,
    *,
    body: ShoppingListEntryBulkCreate | ShoppingListEntryBulkCreate | ShoppingListEntryBulkCreate | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/shopping-list-recipe/{id}/bulk_create_entries/".format(
            id=quote(str(id), safe=""),
        ),
    }

    if isinstance(body, ShoppingListEntryBulkCreate):
        _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, ShoppingListEntryBulkCreate):
        _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, ShoppingListEntryBulkCreate):
        _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ShoppingListEntryBulkCreate | None:
    if response.status_code == 200:
        response_200 = ShoppingListEntryBulkCreate.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ShoppingListEntryBulkCreate]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: int,
    *,
    client: AuthenticatedClient,
    body: ShoppingListEntryBulkCreate | ShoppingListEntryBulkCreate | ShoppingListEntryBulkCreate | Unset = UNSET,
) -> Response[ShoppingListEntryBulkCreate]:
    """logs request counts to redis cache total/per user/

    Args:
        id (int):
        body (ShoppingListEntryBulkCreate):
        body (ShoppingListEntryBulkCreate):
        body (ShoppingListEntryBulkCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ShoppingListEntryBulkCreate]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: int,
    *,
    client: AuthenticatedClient,
    body: ShoppingListEntryBulkCreate | ShoppingListEntryBulkCreate | ShoppingListEntryBulkCreate | Unset = UNSET,
) -> ShoppingListEntryBulkCreate | None:
    """logs request counts to redis cache total/per user/

    Args:
        id (int):
        body (ShoppingListEntryBulkCreate):
        body (ShoppingListEntryBulkCreate):
        body (ShoppingListEntryBulkCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ShoppingListEntryBulkCreate
    """

    return sync_detailed(
        id=id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    id: int,
    *,
    client: AuthenticatedClient,
    body: ShoppingListEntryBulkCreate | ShoppingListEntryBulkCreate | ShoppingListEntryBulkCreate | Unset = UNSET,
) -> Response[ShoppingListEntryBulkCreate]:
    """logs request counts to redis cache total/per user/

    Args:
        id (int):
        body (ShoppingListEntryBulkCreate):
        body (ShoppingListEntryBulkCreate):
        body (ShoppingListEntryBulkCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ShoppingListEntryBulkCreate]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: int,
    *,
    client: AuthenticatedClient,
    body: ShoppingListEntryBulkCreate | ShoppingListEntryBulkCreate | ShoppingListEntryBulkCreate | Unset = UNSET,
) -> ShoppingListEntryBulkCreate | None:
    """logs request counts to redis cache total/per user/

    Args:
        id (int):
        body (ShoppingListEntryBulkCreate):
        body (ShoppingListEntryBulkCreate):
        body (ShoppingListEntryBulkCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ShoppingListEntryBulkCreate
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
            body=body,
        )
    ).parsed
