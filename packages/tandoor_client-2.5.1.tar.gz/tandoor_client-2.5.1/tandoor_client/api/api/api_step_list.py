from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.paginated_step_list import PaginatedStepList
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    recipe: list[int] | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["page"] = page

    params["page_size"] = page_size

    params["query"] = query

    json_recipe: list[int] | Unset = UNSET
    if not isinstance(recipe, Unset):
        json_recipe = recipe

    params["recipe"] = json_recipe

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/step/",
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> PaginatedStepList | None:
    if response.status_code == 200:
        response_200 = PaginatedStepList.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[PaginatedStepList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    recipe: list[int] | Unset = UNSET,
) -> Response[PaginatedStepList]:
    """logs request counts to redis cache total/per user/

    Args:
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):
        recipe (list[int] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedStepList]
    """

    kwargs = _get_kwargs(
        page=page,
        page_size=page_size,
        query=query,
        recipe=recipe,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    recipe: list[int] | Unset = UNSET,
) -> PaginatedStepList | None:
    """logs request counts to redis cache total/per user/

    Args:
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):
        recipe (list[int] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedStepList
    """

    return sync_detailed(
        client=client,
        page=page,
        page_size=page_size,
        query=query,
        recipe=recipe,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    recipe: list[int] | Unset = UNSET,
) -> Response[PaginatedStepList]:
    """logs request counts to redis cache total/per user/

    Args:
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):
        recipe (list[int] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedStepList]
    """

    kwargs = _get_kwargs(
        page=page,
        page_size=page_size,
        query=query,
        recipe=recipe,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
    recipe: list[int] | Unset = UNSET,
) -> PaginatedStepList | None:
    """logs request counts to redis cache total/per user/

    Args:
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):
        recipe (list[int] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedStepList
    """

    return (
        await asyncio_detailed(
            client=client,
            page=page,
            page_size=page_size,
            query=query,
            recipe=recipe,
        )
    ).parsed
