from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.paginated_unit_conversion_list import PaginatedUnitConversionList
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    food_id: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["food_id"] = food_id

    params["page"] = page

    params["page_size"] = page_size

    params["query"] = query

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/unit-conversion/",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PaginatedUnitConversionList | None:
    if response.status_code == 200:
        response_200 = PaginatedUnitConversionList.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PaginatedUnitConversionList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    food_id: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
) -> Response[PaginatedUnitConversionList]:
    """logs request counts to redis cache total/per user/

    Args:
        food_id (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedUnitConversionList]
    """

    kwargs = _get_kwargs(
        food_id=food_id,
        page=page,
        page_size=page_size,
        query=query,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    food_id: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
) -> PaginatedUnitConversionList | None:
    """logs request counts to redis cache total/per user/

    Args:
        food_id (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedUnitConversionList
    """

    return sync_detailed(
        client=client,
        food_id=food_id,
        page=page,
        page_size=page_size,
        query=query,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    food_id: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
) -> Response[PaginatedUnitConversionList]:
    """logs request counts to redis cache total/per user/

    Args:
        food_id (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PaginatedUnitConversionList]
    """

    kwargs = _get_kwargs(
        food_id=food_id,
        page=page,
        page_size=page_size,
        query=query,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    food_id: int | Unset = UNSET,
    page: int | Unset = UNSET,
    page_size: int | Unset = UNSET,
    query: str | Unset = UNSET,
) -> PaginatedUnitConversionList | None:
    """logs request counts to redis cache total/per user/

    Args:
        food_id (int | Unset):
        page (int | Unset):
        page_size (int | Unset):
        query (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PaginatedUnitConversionList
    """

    return (
        await asyncio_detailed(
            client=client,
            food_id=food_id,
            page=page,
            page_size=page_size,
            query=query,
        )
    ).parsed
