from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.user import User
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    filter_list: list[str] | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_filter_list: list[str] | Unset = UNSET
    if not isinstance(filter_list, Unset):
        json_filter_list = filter_list

    params["filter_list"] = json_filter_list

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/user/",
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> list[User] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = User.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[list[User]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    filter_list: list[str] | Unset = UNSET,
) -> Response[list[User]]:
    """logs request counts to redis cache total/per user/

    Args:
        filter_list (list[str] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[User]]
    """

    kwargs = _get_kwargs(
        filter_list=filter_list,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    filter_list: list[str] | Unset = UNSET,
) -> list[User] | None:
    """logs request counts to redis cache total/per user/

    Args:
        filter_list (list[str] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[User]
    """

    return sync_detailed(
        client=client,
        filter_list=filter_list,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    filter_list: list[str] | Unset = UNSET,
) -> Response[list[User]]:
    """logs request counts to redis cache total/per user/

    Args:
        filter_list (list[str] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[User]]
    """

    kwargs = _get_kwargs(
        filter_list=filter_list,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    filter_list: list[str] | Unset = UNSET,
) -> list[User] | None:
    """logs request counts to redis cache total/per user/

    Args:
        filter_list (list[str] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[User]
    """

    return (
        await asyncio_detailed(
            client=client,
            filter_list=filter_list,
        )
    ).parsed
