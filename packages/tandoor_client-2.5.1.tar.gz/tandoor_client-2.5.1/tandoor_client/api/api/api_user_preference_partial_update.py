from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.patched_user_preference import PatchedUserPreference
from ...models.user_preference import UserPreference
from ...types import UNSET, Response, Unset


def _get_kwargs(
    user: int,
    *,
    body: PatchedUserPreference | PatchedUserPreference | PatchedUserPreference | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/api/user-preference/{user}/".format(
            user=quote(str(user), safe=""),
        ),
    }

    if isinstance(body, PatchedUserPreference):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, PatchedUserPreference):
        if not isinstance(body, Unset):
            _kwargs["data"] = body.to_dict()

        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if isinstance(body, PatchedUserPreference):
        if not isinstance(body, Unset):
            _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> UserPreference | None:
    if response.status_code == 200:
        response_200 = UserPreference.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[UserPreference]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    user: int,
    *,
    client: AuthenticatedClient,
    body: PatchedUserPreference | PatchedUserPreference | PatchedUserPreference | Unset = UNSET,
) -> Response[UserPreference]:
    """logs request counts to redis cache total/per user/

    Args:
        user (int):
        body (PatchedUserPreference | Unset): Adds nested create feature
        body (PatchedUserPreference | Unset): Adds nested create feature
        body (PatchedUserPreference | Unset): Adds nested create feature

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UserPreference]
    """

    kwargs = _get_kwargs(
        user=user,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    user: int,
    *,
    client: AuthenticatedClient,
    body: PatchedUserPreference | PatchedUserPreference | PatchedUserPreference | Unset = UNSET,
) -> UserPreference | None:
    """logs request counts to redis cache total/per user/

    Args:
        user (int):
        body (PatchedUserPreference | Unset): Adds nested create feature
        body (PatchedUserPreference | Unset): Adds nested create feature
        body (PatchedUserPreference | Unset): Adds nested create feature

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UserPreference
    """

    return sync_detailed(
        user=user,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    user: int,
    *,
    client: AuthenticatedClient,
    body: PatchedUserPreference | PatchedUserPreference | PatchedUserPreference | Unset = UNSET,
) -> Response[UserPreference]:
    """logs request counts to redis cache total/per user/

    Args:
        user (int):
        body (PatchedUserPreference | Unset): Adds nested create feature
        body (PatchedUserPreference | Unset): Adds nested create feature
        body (PatchedUserPreference | Unset): Adds nested create feature

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UserPreference]
    """

    kwargs = _get_kwargs(
        user=user,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    user: int,
    *,
    client: AuthenticatedClient,
    body: PatchedUserPreference | PatchedUserPreference | PatchedUserPreference | Unset = UNSET,
) -> UserPreference | None:
    """logs request counts to redis cache total/per user/

    Args:
        user (int):
        body (PatchedUserPreference | Unset): Adds nested create feature
        body (PatchedUserPreference | Unset): Adds nested create feature
        body (PatchedUserPreference | Unset): Adds nested create feature

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UserPreference
    """

    return (
        await asyncio_detailed(
            user=user,
            client=client,
            body=body,
        )
    ).parsed
