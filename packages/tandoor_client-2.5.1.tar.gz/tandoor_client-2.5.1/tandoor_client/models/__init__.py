"""Contains all the data models used in inputs/outputs"""

from .access_token import AccessToken
from .ai_import import AiImport
from .ai_log import AiLog
from .ai_provider import AiProvider
from .api_automation_list_type_item import ApiAutomationListTypeItem
from .api_custom_filter_list_type_item import ApiCustomFilterListTypeItem
from .api_property_type_list_category_item import ApiPropertyTypeListCategoryItem
from .api_recipe_book_list_order_direction import ApiRecipeBookListOrderDirection
from .api_recipe_book_list_order_field import ApiRecipeBookListOrderField
from .auth_token import AuthToken
from .auto_meal_plan import AutoMealPlan
from .automation import Automation
from .automation_type_enum import AutomationTypeEnum
from .bookmarklet_import import BookmarkletImport
from .bookmarklet_import_list import BookmarkletImportList
from .connector_config import ConnectorConfig
from .connector_config_type_enum import ConnectorConfigTypeEnum
from .cook_log import CookLog
from .custom_filter import CustomFilter
from .default_page_enum import DefaultPageEnum
from .delete_enum import DeleteEnum
from .export_log import ExportLog
from .export_request import ExportRequest
from .fdc_query import FdcQuery
from .fdc_query_foods import FdcQueryFoods
from .food import Food
from .food_batch_update import FoodBatchUpdate
from .food_inherit_field import FoodInheritField
from .food_shopping import FoodShopping
from .food_shopping_update import FoodShoppingUpdate
from .food_simple import FoodSimple
from .generic_model_reference import GenericModelReference
from .group import Group
from .import_log import ImportLog
from .import_open_data import ImportOpenData
from .import_open_data_meta_data import ImportOpenDataMetaData
from .import_open_data_response import ImportOpenDataResponse
from .import_open_data_response_detail import ImportOpenDataResponseDetail
from .import_open_data_version_meta_data import ImportOpenDataVersionMetaData
from .ingredient import Ingredient
from .ingredient_parser_request import IngredientParserRequest
from .ingredient_parser_response import IngredientParserResponse
from .ingredient_simple import IngredientSimple
from .invite_link import InviteLink
from .keyword import Keyword
from .keyword_label import KeywordLabel
from .localization import Localization
from .meal_plan import MealPlan
from .meal_type import MealType
from .method_enum import MethodEnum
from .nutrition_information import NutritionInformation
from .paginated_ai_log_list import PaginatedAiLogList
from .paginated_ai_provider_list import PaginatedAiProviderList
from .paginated_automation_list import PaginatedAutomationList
from .paginated_bookmarklet_import_list_list import PaginatedBookmarkletImportListList
from .paginated_connector_config_list import PaginatedConnectorConfigList
from .paginated_cook_log_list import PaginatedCookLogList
from .paginated_custom_filter_list import PaginatedCustomFilterList
from .paginated_export_log_list import PaginatedExportLogList
from .paginated_food_list import PaginatedFoodList
from .paginated_generic_model_reference_list import PaginatedGenericModelReferenceList
from .paginated_import_log_list import PaginatedImportLogList
from .paginated_ingredient_list import PaginatedIngredientList
from .paginated_invite_link_list import PaginatedInviteLinkList
from .paginated_keyword_list import PaginatedKeywordList
from .paginated_meal_plan_list import PaginatedMealPlanList
from .paginated_meal_type_list import PaginatedMealTypeList
from .paginated_property_list import PaginatedPropertyList
from .paginated_property_type_list import PaginatedPropertyTypeList
from .paginated_recipe_book_entry_list import PaginatedRecipeBookEntryList
from .paginated_recipe_book_list import PaginatedRecipeBookList
from .paginated_recipe_import_list import PaginatedRecipeImportList
from .paginated_recipe_overview_list import PaginatedRecipeOverviewList
from .paginated_shopping_list_entry_list import PaginatedShoppingListEntryList
from .paginated_shopping_list_list import PaginatedShoppingListList
from .paginated_shopping_list_recipe_list import PaginatedShoppingListRecipeList
from .paginated_space_list import PaginatedSpaceList
from .paginated_step_list import PaginatedStepList
from .paginated_storage_list import PaginatedStorageList
from .paginated_supermarket_category_list import PaginatedSupermarketCategoryList
from .paginated_supermarket_category_relation_list import PaginatedSupermarketCategoryRelationList
from .paginated_supermarket_list import PaginatedSupermarketList
from .paginated_sync_list import PaginatedSyncList
from .paginated_sync_log_list import PaginatedSyncLogList
from .paginated_unit_conversion_list import PaginatedUnitConversionList
from .paginated_unit_list import PaginatedUnitList
from .paginated_user_file_list import PaginatedUserFileList
from .paginated_user_space_list import PaginatedUserSpaceList
from .paginated_view_log_list import PaginatedViewLogList
from .patched_access_token import PatchedAccessToken
from .patched_ai_provider import PatchedAiProvider
from .patched_automation import PatchedAutomation
from .patched_bookmarklet_import import PatchedBookmarkletImport
from .patched_connector_config import PatchedConnectorConfig
from .patched_cook_log import PatchedCookLog
from .patched_custom_filter import PatchedCustomFilter
from .patched_export_log import PatchedExportLog
from .patched_food import PatchedFood
from .patched_import_log import PatchedImportLog
from .patched_ingredient import PatchedIngredient
from .patched_invite_link import PatchedInviteLink
from .patched_keyword import PatchedKeyword
from .patched_meal_plan import PatchedMealPlan
from .patched_meal_type import PatchedMealType
from .patched_property import PatchedProperty
from .patched_property_type import PatchedPropertyType
from .patched_recipe import PatchedRecipe
from .patched_recipe_book import PatchedRecipeBook
from .patched_recipe_book_entry import PatchedRecipeBookEntry
from .patched_recipe_import import PatchedRecipeImport
from .patched_search_preference import PatchedSearchPreference
from .patched_shopping_list import PatchedShoppingList
from .patched_shopping_list_entry import PatchedShoppingListEntry
from .patched_shopping_list_recipe import PatchedShoppingListRecipe
from .patched_space import PatchedSpace
from .patched_step import PatchedStep
from .patched_storage import PatchedStorage
from .patched_supermarket import PatchedSupermarket
from .patched_supermarket_category import PatchedSupermarketCategory
from .patched_supermarket_category_relation import PatchedSupermarketCategoryRelation
from .patched_sync import PatchedSync
from .patched_unit import PatchedUnit
from .patched_unit_conversion import PatchedUnitConversion
from .patched_user import PatchedUser
from .patched_user_file import PatchedUserFile
from .patched_user_preference import PatchedUserPreference
from .patched_user_space import PatchedUserSpace
from .patched_view_log import PatchedViewLog
from .property_ import Property
from .property_type import PropertyType
from .recipe import Recipe
from .recipe_batch_update import RecipeBatchUpdate
from .recipe_book import RecipeBook
from .recipe_book_entry import RecipeBookEntry
from .recipe_flat import RecipeFlat
from .recipe_from_source import RecipeFromSource
from .recipe_from_source_response import RecipeFromSourceResponse
from .recipe_image import RecipeImage
from .recipe_import import RecipeImport
from .recipe_overview import RecipeOverview
from .recipe_shopping_update import RecipeShoppingUpdate
from .recipe_simple import RecipeSimple
from .search_enum import SearchEnum
from .search_fields import SearchFields
from .search_preference import SearchPreference
from .server_settings import ServerSettings
from .share_link import ShareLink
from .shopping_list import ShoppingList
from .shopping_list_entry import ShoppingListEntry
from .shopping_list_entry_bulk import ShoppingListEntryBulk
from .shopping_list_entry_bulk_create import ShoppingListEntryBulkCreate
from .shopping_list_entry_simple_create import ShoppingListEntrySimpleCreate
from .shopping_list_recipe import ShoppingListRecipe
from .source_import_duplicate import SourceImportDuplicate
from .source_import_food import SourceImportFood
from .source_import_ingredient import SourceImportIngredient
from .source_import_keyword import SourceImportKeyword
from .source_import_property import SourceImportProperty
from .source_import_property_type import SourceImportPropertyType
from .source_import_recipe import SourceImportRecipe
from .source_import_step import SourceImportStep
from .source_import_unit import SourceImportUnit
from .space import Space
from .space_nav_text_color_enum import SpaceNavTextColorEnum
from .space_theme_enum import SpaceThemeEnum
from .step import Step
from .storage import Storage
from .supermarket import Supermarket
from .supermarket_category import SupermarketCategory
from .supermarket_category_relation import SupermarketCategoryRelation
from .sync import Sync
from .sync_log import SyncLog
from .theme_enum import ThemeEnum
from .unit import Unit
from .unit_conversion import UnitConversion
from .user import User
from .user_file import UserFile
from .user_file_view import UserFileView
from .user_preference import UserPreference
from .user_preference_nav_text_color_enum import UserPreferenceNavTextColorEnum
from .user_space import UserSpace
from .view_log import ViewLog

__all__ = (
    "AccessToken",
    "AiImport",
    "AiLog",
    "AiProvider",
    "ApiAutomationListTypeItem",
    "ApiCustomFilterListTypeItem",
    "ApiPropertyTypeListCategoryItem",
    "ApiRecipeBookListOrderDirection",
    "ApiRecipeBookListOrderField",
    "AuthToken",
    "Automation",
    "AutomationTypeEnum",
    "AutoMealPlan",
    "BookmarkletImport",
    "BookmarkletImportList",
    "ConnectorConfig",
    "ConnectorConfigTypeEnum",
    "CookLog",
    "CustomFilter",
    "DefaultPageEnum",
    "DeleteEnum",
    "ExportLog",
    "ExportRequest",
    "FdcQuery",
    "FdcQueryFoods",
    "Food",
    "FoodBatchUpdate",
    "FoodInheritField",
    "FoodShopping",
    "FoodShoppingUpdate",
    "FoodSimple",
    "GenericModelReference",
    "Group",
    "ImportLog",
    "ImportOpenData",
    "ImportOpenDataMetaData",
    "ImportOpenDataResponse",
    "ImportOpenDataResponseDetail",
    "ImportOpenDataVersionMetaData",
    "Ingredient",
    "IngredientParserRequest",
    "IngredientParserResponse",
    "IngredientSimple",
    "InviteLink",
    "Keyword",
    "KeywordLabel",
    "Localization",
    "MealPlan",
    "MealType",
    "MethodEnum",
    "NutritionInformation",
    "PaginatedAiLogList",
    "PaginatedAiProviderList",
    "PaginatedAutomationList",
    "PaginatedBookmarkletImportListList",
    "PaginatedConnectorConfigList",
    "PaginatedCookLogList",
    "PaginatedCustomFilterList",
    "PaginatedExportLogList",
    "PaginatedFoodList",
    "PaginatedGenericModelReferenceList",
    "PaginatedImportLogList",
    "PaginatedIngredientList",
    "PaginatedInviteLinkList",
    "PaginatedKeywordList",
    "PaginatedMealPlanList",
    "PaginatedMealTypeList",
    "PaginatedPropertyList",
    "PaginatedPropertyTypeList",
    "PaginatedRecipeBookEntryList",
    "PaginatedRecipeBookList",
    "PaginatedRecipeImportList",
    "PaginatedRecipeOverviewList",
    "PaginatedShoppingListEntryList",
    "PaginatedShoppingListList",
    "PaginatedShoppingListRecipeList",
    "PaginatedSpaceList",
    "PaginatedStepList",
    "PaginatedStorageList",
    "PaginatedSupermarketCategoryList",
    "PaginatedSupermarketCategoryRelationList",
    "PaginatedSupermarketList",
    "PaginatedSyncList",
    "PaginatedSyncLogList",
    "PaginatedUnitConversionList",
    "PaginatedUnitList",
    "PaginatedUserFileList",
    "PaginatedUserSpaceList",
    "PaginatedViewLogList",
    "PatchedAccessToken",
    "PatchedAiProvider",
    "PatchedAutomation",
    "PatchedBookmarkletImport",
    "PatchedConnectorConfig",
    "PatchedCookLog",
    "PatchedCustomFilter",
    "PatchedExportLog",
    "PatchedFood",
    "PatchedImportLog",
    "PatchedIngredient",
    "PatchedInviteLink",
    "PatchedKeyword",
    "PatchedMealPlan",
    "PatchedMealType",
    "PatchedProperty",
    "PatchedPropertyType",
    "PatchedRecipe",
    "PatchedRecipeBook",
    "PatchedRecipeBookEntry",
    "PatchedRecipeImport",
    "PatchedSearchPreference",
    "PatchedShoppingList",
    "PatchedShoppingListEntry",
    "PatchedShoppingListRecipe",
    "PatchedSpace",
    "PatchedStep",
    "PatchedStorage",
    "PatchedSupermarket",
    "PatchedSupermarketCategory",
    "PatchedSupermarketCategoryRelation",
    "PatchedSync",
    "PatchedUnit",
    "PatchedUnitConversion",
    "PatchedUser",
    "PatchedUserFile",
    "PatchedUserPreference",
    "PatchedUserSpace",
    "PatchedViewLog",
    "Property",
    "PropertyType",
    "Recipe",
    "RecipeBatchUpdate",
    "RecipeBook",
    "RecipeBookEntry",
    "RecipeFlat",
    "RecipeFromSource",
    "RecipeFromSourceResponse",
    "RecipeImage",
    "RecipeImport",
    "RecipeOverview",
    "RecipeShoppingUpdate",
    "RecipeSimple",
    "SearchEnum",
    "SearchFields",
    "SearchPreference",
    "ServerSettings",
    "ShareLink",
    "ShoppingList",
    "ShoppingListEntry",
    "ShoppingListEntryBulk",
    "ShoppingListEntryBulkCreate",
    "ShoppingListEntrySimpleCreate",
    "ShoppingListRecipe",
    "SourceImportDuplicate",
    "SourceImportFood",
    "SourceImportIngredient",
    "SourceImportKeyword",
    "SourceImportProperty",
    "SourceImportPropertyType",
    "SourceImportRecipe",
    "SourceImportStep",
    "SourceImportUnit",
    "Space",
    "SpaceNavTextColorEnum",
    "SpaceThemeEnum",
    "Step",
    "Storage",
    "Supermarket",
    "SupermarketCategory",
    "SupermarketCategoryRelation",
    "Sync",
    "SyncLog",
    "ThemeEnum",
    "Unit",
    "UnitConversion",
    "User",
    "UserFile",
    "UserFileView",
    "UserPreference",
    "UserPreferenceNavTextColorEnum",
    "UserSpace",
    "ViewLog",
)
