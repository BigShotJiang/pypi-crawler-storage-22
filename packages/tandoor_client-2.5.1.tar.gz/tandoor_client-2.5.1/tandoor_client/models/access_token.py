from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="AccessToken")


@_attrs_define
class AccessToken:
    """
    Attributes:
        token (str):
        expires (datetime.datetime):
        created (datetime.datetime):
        updated (datetime.datetime):
        id (int | Unset):
        scope (str | Unset):
    """

    token: str
    expires: datetime.datetime
    created: datetime.datetime
    updated: datetime.datetime
    id: int | Unset = UNSET
    scope: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        token = self.token

        expires = self.expires.isoformat()

        created = self.created.isoformat()

        updated = self.updated.isoformat()

        id = self.id

        scope = self.scope

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "token": token,
                "expires": expires,
                "created": created,
                "updated": updated,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if scope is not UNSET:
            field_dict["scope"] = scope

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("token", (None, str(self.token).encode(), "text/plain")))

        files.append(("expires", (None, self.expires.isoformat().encode(), "text/plain")))

        files.append(("created", (None, self.created.isoformat().encode(), "text/plain")))

        files.append(("updated", (None, self.updated.isoformat().encode(), "text/plain")))

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.scope, Unset):
            files.append(("scope", (None, str(self.scope).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        token = d.pop("token")

        expires = isoparse(d.pop("expires"))

        created = isoparse(d.pop("created"))

        updated = isoparse(d.pop("updated"))

        id = d.pop("id", UNSET)

        scope = d.pop("scope", UNSET)

        access_token = cls(
            token=token,
            expires=expires,
            created=created,
            updated=updated,
            id=id,
            scope=scope,
        )

        access_token.additional_properties = d
        return access_token

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
