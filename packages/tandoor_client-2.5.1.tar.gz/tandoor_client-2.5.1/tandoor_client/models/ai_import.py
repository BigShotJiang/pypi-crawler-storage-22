from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types

T = TypeVar("T", bound="AiImport")


@_attrs_define
class AiImport:
    """
    Attributes:
        ai_provider_id (int):
        file (None | str):
        text (None | str):
        recipe_id (None | str):
    """

    ai_provider_id: int
    file: None | str
    text: None | str
    recipe_id: None | str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        ai_provider_id = self.ai_provider_id

        file: None | str
        file = self.file

        text: None | str
        text = self.text

        recipe_id: None | str
        recipe_id = self.recipe_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "ai_provider_id": ai_provider_id,
                "file": file,
                "text": text,
                "recipe_id": recipe_id,
            }
        )

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("ai_provider_id", (None, str(self.ai_provider_id).encode(), "text/plain")))

        if isinstance(self.file, str):
            files.append(("file", (None, str(self.file).encode(), "text/plain")))
        else:
            files.append(("file", (None, str(self.file).encode(), "text/plain")))

        if isinstance(self.text, str):
            files.append(("text", (None, str(self.text).encode(), "text/plain")))
        else:
            files.append(("text", (None, str(self.text).encode(), "text/plain")))

        if isinstance(self.recipe_id, str):
            files.append(("recipe_id", (None, str(self.recipe_id).encode(), "text/plain")))
        else:
            files.append(("recipe_id", (None, str(self.recipe_id).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        ai_provider_id = d.pop("ai_provider_id")

        def _parse_file(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        file = _parse_file(d.pop("file"))

        def _parse_text(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        text = _parse_text(d.pop("text"))

        def _parse_recipe_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        recipe_id = _parse_recipe_id(d.pop("recipe_id"))

        ai_import = cls(
            ai_provider_id=ai_provider_id,
            file=file,
            text=text,
            recipe_id=recipe_id,
        )

        ai_import.additional_properties = d
        return ai_import

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
