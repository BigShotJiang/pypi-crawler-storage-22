from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="AiProvider")


@_attrs_define
class AiProvider:
    """
    Attributes:
        name (str):
        model_name (str):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        id (int | Unset):
        description (str | Unset):
        api_key (str | Unset):
        url (None | str | Unset):
        log_credit_cost (bool | Unset):
        space (int | None | Unset):
    """

    name: str
    model_name: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    id: int | Unset = UNSET
    description: str | Unset = UNSET
    api_key: str | Unset = UNSET
    url: None | str | Unset = UNSET
    log_credit_cost: bool | Unset = UNSET
    space: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        model_name = self.model_name

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        id = self.id

        description = self.description

        api_key = self.api_key

        url: None | str | Unset
        if isinstance(self.url, Unset):
            url = UNSET
        else:
            url = self.url

        log_credit_cost = self.log_credit_cost

        space: int | None | Unset
        if isinstance(self.space, Unset):
            space = UNSET
        else:
            space = self.space

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "model_name": model_name,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if description is not UNSET:
            field_dict["description"] = description
        if api_key is not UNSET:
            field_dict["api_key"] = api_key
        if url is not UNSET:
            field_dict["url"] = url
        if log_credit_cost is not UNSET:
            field_dict["log_credit_cost"] = log_credit_cost
        if space is not UNSET:
            field_dict["space"] = space

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("name", (None, str(self.name).encode(), "text/plain")))

        files.append(("model_name", (None, str(self.model_name).encode(), "text/plain")))

        files.append(("created_at", (None, self.created_at.isoformat().encode(), "text/plain")))

        files.append(("updated_at", (None, self.updated_at.isoformat().encode(), "text/plain")))

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.description, Unset):
            files.append(("description", (None, str(self.description).encode(), "text/plain")))

        if not isinstance(self.api_key, Unset):
            files.append(("api_key", (None, str(self.api_key).encode(), "text/plain")))

        if not isinstance(self.url, Unset):
            if isinstance(self.url, str):
                files.append(("url", (None, str(self.url).encode(), "text/plain")))
            else:
                files.append(("url", (None, str(self.url).encode(), "text/plain")))

        if not isinstance(self.log_credit_cost, Unset):
            files.append(("log_credit_cost", (None, str(self.log_credit_cost).encode(), "text/plain")))

        if not isinstance(self.space, Unset):
            if isinstance(self.space, int):
                files.append(("space", (None, str(self.space).encode(), "text/plain")))
            else:
                files.append(("space", (None, str(self.space).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        model_name = d.pop("model_name")

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        id = d.pop("id", UNSET)

        description = d.pop("description", UNSET)

        api_key = d.pop("api_key", UNSET)

        def _parse_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        url = _parse_url(d.pop("url", UNSET))

        log_credit_cost = d.pop("log_credit_cost", UNSET)

        def _parse_space(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        space = _parse_space(d.pop("space", UNSET))

        ai_provider = cls(
            name=name,
            model_name=model_name,
            created_at=created_at,
            updated_at=updated_at,
            id=id,
            description=description,
            api_key=api_key,
            url=url,
            log_credit_cost=log_credit_cost,
            space=space,
        )

        ai_provider.additional_properties = d
        return ai_provider

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
