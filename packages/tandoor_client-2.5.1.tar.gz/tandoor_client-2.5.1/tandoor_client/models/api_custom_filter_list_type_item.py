from enum import Enum


class ApiCustomFilterListTypeItem(str, Enum):
    FOOD = "FOOD"
    KEYWORD = "KEYWORD"
    RECIPE = "RECIPE"

    def __str__(self) -> str:
        return str(self.value)
