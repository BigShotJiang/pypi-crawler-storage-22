from enum import Enum


class ApiPropertyTypeListCategoryItem(str, Enum):
    ALLERGEN = "ALLERGEN"
    GOAL = "GOAL"
    NUTRITION = "NUTRITION"
    OTHER = "OTHER"
    PRICE = "PRICE"

    def __str__(self) -> str:
        return str(self.value)
