from enum import Enum


class ApiRecipeBookListOrderField(str, Enum):
    ID = "id"
    NAME = "name"
    ORDER = "order"

    def __str__(self) -> str:
        return str(self.value)
