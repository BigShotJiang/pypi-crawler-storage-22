from __future__ import annotations

import datetime
import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.user import User


T = TypeVar("T", bound="AutoMealPlan")


@_attrs_define
class AutoMealPlan:
    """
    Attributes:
        start_date (datetime.datetime):
        end_date (datetime.datetime):
        meal_type_id (int):
        keyword_ids (list[Any]):
        servings (float):
        addshopping (bool):
        shared (list[User] | None | Unset):
    """

    start_date: datetime.datetime
    end_date: datetime.datetime
    meal_type_id: int
    keyword_ids: list[Any]
    servings: float
    addshopping: bool
    shared: list[User] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        start_date = self.start_date.isoformat()

        end_date = self.end_date.isoformat()

        meal_type_id = self.meal_type_id

        keyword_ids = self.keyword_ids

        servings = self.servings

        addshopping = self.addshopping

        shared: list[dict[str, Any]] | None | Unset
        if isinstance(self.shared, Unset):
            shared = UNSET
        elif isinstance(self.shared, list):
            shared = []
            for shared_type_0_item_data in self.shared:
                shared_type_0_item = shared_type_0_item_data.to_dict()
                shared.append(shared_type_0_item)

        else:
            shared = self.shared

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "start_date": start_date,
                "end_date": end_date,
                "meal_type_id": meal_type_id,
                "keyword_ids": keyword_ids,
                "servings": servings,
                "addshopping": addshopping,
            }
        )
        if shared is not UNSET:
            field_dict["shared"] = shared

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("start_date", (None, self.start_date.isoformat().encode(), "text/plain")))

        files.append(("end_date", (None, self.end_date.isoformat().encode(), "text/plain")))

        files.append(("meal_type_id", (None, str(self.meal_type_id).encode(), "text/plain")))

        for keyword_ids_item_element in self.keyword_ids:
            files.append(("keyword_ids", (None, str(keyword_ids_item_element).encode(), "text/plain")))

        files.append(("servings", (None, str(self.servings).encode(), "text/plain")))

        files.append(("addshopping", (None, str(self.addshopping).encode(), "text/plain")))

        if not isinstance(self.shared, Unset):
            if isinstance(self.shared, list):
                for shared_type_0_item_element in self.shared:
                    files.append(
                        (
                            "shared",
                            (None, json.dumps(shared_type_0_item_element.to_dict()).encode(), "application/json"),
                        )
                    )
            else:
                files.append(("shared", (None, str(self.shared).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user import User

        d = dict(src_dict)
        start_date = isoparse(d.pop("start_date"))

        end_date = isoparse(d.pop("end_date"))

        meal_type_id = d.pop("meal_type_id")

        keyword_ids = cast(list[Any], d.pop("keyword_ids"))

        servings = d.pop("servings")

        addshopping = d.pop("addshopping")

        def _parse_shared(data: object) -> list[User] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                shared_type_0 = []
                _shared_type_0 = data
                for shared_type_0_item_data in _shared_type_0:
                    shared_type_0_item = User.from_dict(shared_type_0_item_data)

                    shared_type_0.append(shared_type_0_item)

                return shared_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[User] | None | Unset, data)

        shared = _parse_shared(d.pop("shared", UNSET))

        auto_meal_plan = cls(
            start_date=start_date,
            end_date=end_date,
            meal_type_id=meal_type_id,
            keyword_ids=keyword_ids,
            servings=servings,
            addshopping=addshopping,
            shared=shared,
        )

        auto_meal_plan.additional_properties = d
        return auto_meal_plan

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
