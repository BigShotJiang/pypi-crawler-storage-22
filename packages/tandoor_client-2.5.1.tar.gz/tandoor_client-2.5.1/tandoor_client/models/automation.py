from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..models.automation_type_enum import AutomationTypeEnum
from ..types import UNSET, Unset

T = TypeVar("T", bound="Automation")


@_attrs_define
class Automation:
    """
    Attributes:
        type_ (AutomationTypeEnum): * `FOOD_ALIAS` - Food Alias
            * `UNIT_ALIAS` - Unit Alias
            * `KEYWORD_ALIAS` - Keyword Alias
            * `DESCRIPTION_REPLACE` - Description Replace
            * `INSTRUCTION_REPLACE` - Instruction Replace
            * `NEVER_UNIT` - Never Unit
            * `TRANSPOSE_WORDS` - Transpose Words
            * `FOOD_REPLACE` - Food Replace
            * `UNIT_REPLACE` - Unit Replace
            * `NAME_REPLACE` - Name Replace
        created_by (int):
        id (int | Unset):
        name (str | Unset):
        description (None | str | Unset):
        param_1 (None | str | Unset):
        param_2 (None | str | Unset):
        param_3 (None | str | Unset):
        order (int | Unset):
        disabled (bool | Unset):
    """

    type_: AutomationTypeEnum
    created_by: int
    id: int | Unset = UNSET
    name: str | Unset = UNSET
    description: None | str | Unset = UNSET
    param_1: None | str | Unset = UNSET
    param_2: None | str | Unset = UNSET
    param_3: None | str | Unset = UNSET
    order: int | Unset = UNSET
    disabled: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_.value

        created_by = self.created_by

        id = self.id

        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        param_1: None | str | Unset
        if isinstance(self.param_1, Unset):
            param_1 = UNSET
        else:
            param_1 = self.param_1

        param_2: None | str | Unset
        if isinstance(self.param_2, Unset):
            param_2 = UNSET
        else:
            param_2 = self.param_2

        param_3: None | str | Unset
        if isinstance(self.param_3, Unset):
            param_3 = UNSET
        else:
            param_3 = self.param_3

        order = self.order

        disabled = self.disabled

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "type": type_,
                "created_by": created_by,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if param_1 is not UNSET:
            field_dict["param_1"] = param_1
        if param_2 is not UNSET:
            field_dict["param_2"] = param_2
        if param_3 is not UNSET:
            field_dict["param_3"] = param_3
        if order is not UNSET:
            field_dict["order"] = order
        if disabled is not UNSET:
            field_dict["disabled"] = disabled

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("type", (None, str(self.type_.value).encode(), "text/plain")))

        files.append(("created_by", (None, str(self.created_by).encode(), "text/plain")))

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.name, Unset):
            files.append(("name", (None, str(self.name).encode(), "text/plain")))

        if not isinstance(self.description, Unset):
            if isinstance(self.description, str):
                files.append(("description", (None, str(self.description).encode(), "text/plain")))
            else:
                files.append(("description", (None, str(self.description).encode(), "text/plain")))

        if not isinstance(self.param_1, Unset):
            if isinstance(self.param_1, str):
                files.append(("param_1", (None, str(self.param_1).encode(), "text/plain")))
            else:
                files.append(("param_1", (None, str(self.param_1).encode(), "text/plain")))

        if not isinstance(self.param_2, Unset):
            if isinstance(self.param_2, str):
                files.append(("param_2", (None, str(self.param_2).encode(), "text/plain")))
            else:
                files.append(("param_2", (None, str(self.param_2).encode(), "text/plain")))

        if not isinstance(self.param_3, Unset):
            if isinstance(self.param_3, str):
                files.append(("param_3", (None, str(self.param_3).encode(), "text/plain")))
            else:
                files.append(("param_3", (None, str(self.param_3).encode(), "text/plain")))

        if not isinstance(self.order, Unset):
            files.append(("order", (None, str(self.order).encode(), "text/plain")))

        if not isinstance(self.disabled, Unset):
            files.append(("disabled", (None, str(self.disabled).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        type_ = AutomationTypeEnum(d.pop("type"))

        created_by = d.pop("created_by")

        id = d.pop("id", UNSET)

        name = d.pop("name", UNSET)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_param_1(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        param_1 = _parse_param_1(d.pop("param_1", UNSET))

        def _parse_param_2(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        param_2 = _parse_param_2(d.pop("param_2", UNSET))

        def _parse_param_3(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        param_3 = _parse_param_3(d.pop("param_3", UNSET))

        order = d.pop("order", UNSET)

        disabled = d.pop("disabled", UNSET)

        automation = cls(
            type_=type_,
            created_by=created_by,
            id=id,
            name=name,
            description=description,
            param_1=param_1,
            param_2=param_2,
            param_3=param_3,
            order=order,
            disabled=disabled,
        )

        automation.additional_properties = d
        return automation

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
