from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..models.connector_config_type_enum import ConnectorConfigTypeEnum
from ..types import UNSET, Unset

T = TypeVar("T", bound="ConnectorConfig")


@_attrs_define
class ConnectorConfig:
    """
    Attributes:
        name (str):
        created_by (int):
        id (int | Unset):
        type_ (ConnectorConfigTypeEnum | Unset): * `HomeAssistant` - HomeAssistant
        url (None | str | Unset):
        token (None | str | Unset):
        todo_entity (None | str | Unset):
        enabled (bool | Unset): Is Connector Enabled
        on_shopping_list_entry_created_enabled (bool | Unset):
        on_shopping_list_entry_updated_enabled (bool | Unset):
        on_shopping_list_entry_deleted_enabled (bool | Unset):
        supports_description_field (bool | Unset): Does the todo entity support the description field
    """

    name: str
    created_by: int
    id: int | Unset = UNSET
    type_: ConnectorConfigTypeEnum | Unset = UNSET
    url: None | str | Unset = UNSET
    token: None | str | Unset = UNSET
    todo_entity: None | str | Unset = UNSET
    enabled: bool | Unset = UNSET
    on_shopping_list_entry_created_enabled: bool | Unset = UNSET
    on_shopping_list_entry_updated_enabled: bool | Unset = UNSET
    on_shopping_list_entry_deleted_enabled: bool | Unset = UNSET
    supports_description_field: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        created_by = self.created_by

        id = self.id

        type_: str | Unset = UNSET
        if not isinstance(self.type_, Unset):
            type_ = self.type_.value

        url: None | str | Unset
        if isinstance(self.url, Unset):
            url = UNSET
        else:
            url = self.url

        token: None | str | Unset
        if isinstance(self.token, Unset):
            token = UNSET
        else:
            token = self.token

        todo_entity: None | str | Unset
        if isinstance(self.todo_entity, Unset):
            todo_entity = UNSET
        else:
            todo_entity = self.todo_entity

        enabled = self.enabled

        on_shopping_list_entry_created_enabled = self.on_shopping_list_entry_created_enabled

        on_shopping_list_entry_updated_enabled = self.on_shopping_list_entry_updated_enabled

        on_shopping_list_entry_deleted_enabled = self.on_shopping_list_entry_deleted_enabled

        supports_description_field = self.supports_description_field

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "created_by": created_by,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if type_ is not UNSET:
            field_dict["type"] = type_
        if url is not UNSET:
            field_dict["url"] = url
        if token is not UNSET:
            field_dict["token"] = token
        if todo_entity is not UNSET:
            field_dict["todo_entity"] = todo_entity
        if enabled is not UNSET:
            field_dict["enabled"] = enabled
        if on_shopping_list_entry_created_enabled is not UNSET:
            field_dict["on_shopping_list_entry_created_enabled"] = on_shopping_list_entry_created_enabled
        if on_shopping_list_entry_updated_enabled is not UNSET:
            field_dict["on_shopping_list_entry_updated_enabled"] = on_shopping_list_entry_updated_enabled
        if on_shopping_list_entry_deleted_enabled is not UNSET:
            field_dict["on_shopping_list_entry_deleted_enabled"] = on_shopping_list_entry_deleted_enabled
        if supports_description_field is not UNSET:
            field_dict["supports_description_field"] = supports_description_field

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("name", (None, str(self.name).encode(), "text/plain")))

        files.append(("created_by", (None, str(self.created_by).encode(), "text/plain")))

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.type_, Unset):
            files.append(("type", (None, str(self.type_.value).encode(), "text/plain")))

        if not isinstance(self.url, Unset):
            if isinstance(self.url, str):
                files.append(("url", (None, str(self.url).encode(), "text/plain")))
            else:
                files.append(("url", (None, str(self.url).encode(), "text/plain")))

        if not isinstance(self.token, Unset):
            if isinstance(self.token, str):
                files.append(("token", (None, str(self.token).encode(), "text/plain")))
            else:
                files.append(("token", (None, str(self.token).encode(), "text/plain")))

        if not isinstance(self.todo_entity, Unset):
            if isinstance(self.todo_entity, str):
                files.append(("todo_entity", (None, str(self.todo_entity).encode(), "text/plain")))
            else:
                files.append(("todo_entity", (None, str(self.todo_entity).encode(), "text/plain")))

        if not isinstance(self.enabled, Unset):
            files.append(("enabled", (None, str(self.enabled).encode(), "text/plain")))

        if not isinstance(self.on_shopping_list_entry_created_enabled, Unset):
            files.append(
                (
                    "on_shopping_list_entry_created_enabled",
                    (None, str(self.on_shopping_list_entry_created_enabled).encode(), "text/plain"),
                )
            )

        if not isinstance(self.on_shopping_list_entry_updated_enabled, Unset):
            files.append(
                (
                    "on_shopping_list_entry_updated_enabled",
                    (None, str(self.on_shopping_list_entry_updated_enabled).encode(), "text/plain"),
                )
            )

        if not isinstance(self.on_shopping_list_entry_deleted_enabled, Unset):
            files.append(
                (
                    "on_shopping_list_entry_deleted_enabled",
                    (None, str(self.on_shopping_list_entry_deleted_enabled).encode(), "text/plain"),
                )
            )

        if not isinstance(self.supports_description_field, Unset):
            files.append(
                ("supports_description_field", (None, str(self.supports_description_field).encode(), "text/plain"))
            )

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        created_by = d.pop("created_by")

        id = d.pop("id", UNSET)

        _type_ = d.pop("type", UNSET)
        type_: ConnectorConfigTypeEnum | Unset
        if isinstance(_type_, Unset):
            type_ = UNSET
        else:
            type_ = ConnectorConfigTypeEnum(_type_)

        def _parse_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        url = _parse_url(d.pop("url", UNSET))

        def _parse_token(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        token = _parse_token(d.pop("token", UNSET))

        def _parse_todo_entity(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        todo_entity = _parse_todo_entity(d.pop("todo_entity", UNSET))

        enabled = d.pop("enabled", UNSET)

        on_shopping_list_entry_created_enabled = d.pop("on_shopping_list_entry_created_enabled", UNSET)

        on_shopping_list_entry_updated_enabled = d.pop("on_shopping_list_entry_updated_enabled", UNSET)

        on_shopping_list_entry_deleted_enabled = d.pop("on_shopping_list_entry_deleted_enabled", UNSET)

        supports_description_field = d.pop("supports_description_field", UNSET)

        connector_config = cls(
            name=name,
            created_by=created_by,
            id=id,
            type_=type_,
            url=url,
            token=token,
            todo_entity=todo_entity,
            enabled=enabled,
            on_shopping_list_entry_created_enabled=on_shopping_list_entry_created_enabled,
            on_shopping_list_entry_updated_enabled=on_shopping_list_entry_updated_enabled,
            on_shopping_list_entry_deleted_enabled=on_shopping_list_entry_deleted_enabled,
            supports_description_field=supports_description_field,
        )

        connector_config.additional_properties = d
        return connector_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
