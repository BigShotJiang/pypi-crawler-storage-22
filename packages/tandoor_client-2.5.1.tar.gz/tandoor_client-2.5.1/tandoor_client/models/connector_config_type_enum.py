from enum import Enum


class ConnectorConfigTypeEnum(str, Enum):
    HOMEASSISTANT = "HomeAssistant"

    def __str__(self) -> str:
        return str(self.value)
