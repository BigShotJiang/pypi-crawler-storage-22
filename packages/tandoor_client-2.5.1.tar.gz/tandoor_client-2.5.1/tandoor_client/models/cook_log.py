from __future__ import annotations

import datetime
import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.user import User


T = TypeVar("T", bound="CookLog")


@_attrs_define
class CookLog:
    """
    Attributes:
        recipe (int):
        created_by (User): Adds nested create feature
        updated_at (datetime.datetime):
        id (int | Unset):
        servings (int | None | Unset):
        rating (int | None | Unset):
        comment (None | str | Unset):
        created_at (datetime.datetime | Unset):
    """

    recipe: int
    created_by: User
    updated_at: datetime.datetime
    id: int | Unset = UNSET
    servings: int | None | Unset = UNSET
    rating: int | None | Unset = UNSET
    comment: None | str | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        recipe = self.recipe

        created_by = self.created_by.to_dict()

        updated_at = self.updated_at.isoformat()

        id = self.id

        servings: int | None | Unset
        if isinstance(self.servings, Unset):
            servings = UNSET
        else:
            servings = self.servings

        rating: int | None | Unset
        if isinstance(self.rating, Unset):
            rating = UNSET
        else:
            rating = self.rating

        comment: None | str | Unset
        if isinstance(self.comment, Unset):
            comment = UNSET
        else:
            comment = self.comment

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "recipe": recipe,
                "created_by": created_by,
                "updated_at": updated_at,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if servings is not UNSET:
            field_dict["servings"] = servings
        if rating is not UNSET:
            field_dict["rating"] = rating
        if comment is not UNSET:
            field_dict["comment"] = comment
        if created_at is not UNSET:
            field_dict["created_at"] = created_at

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("recipe", (None, str(self.recipe).encode(), "text/plain")))

        files.append(("created_by", (None, json.dumps(self.created_by.to_dict()).encode(), "application/json")))

        files.append(("updated_at", (None, self.updated_at.isoformat().encode(), "text/plain")))

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.servings, Unset):
            if isinstance(self.servings, int):
                files.append(("servings", (None, str(self.servings).encode(), "text/plain")))
            else:
                files.append(("servings", (None, str(self.servings).encode(), "text/plain")))

        if not isinstance(self.rating, Unset):
            if isinstance(self.rating, int):
                files.append(("rating", (None, str(self.rating).encode(), "text/plain")))
            else:
                files.append(("rating", (None, str(self.rating).encode(), "text/plain")))

        if not isinstance(self.comment, Unset):
            if isinstance(self.comment, str):
                files.append(("comment", (None, str(self.comment).encode(), "text/plain")))
            else:
                files.append(("comment", (None, str(self.comment).encode(), "text/plain")))

        if not isinstance(self.created_at, Unset):
            files.append(("created_at", (None, self.created_at.isoformat().encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user import User

        d = dict(src_dict)
        recipe = d.pop("recipe")

        created_by = User.from_dict(d.pop("created_by"))

        updated_at = isoparse(d.pop("updated_at"))

        id = d.pop("id", UNSET)

        def _parse_servings(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        servings = _parse_servings(d.pop("servings", UNSET))

        def _parse_rating(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        rating = _parse_rating(d.pop("rating", UNSET))

        def _parse_comment(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        comment = _parse_comment(d.pop("comment", UNSET))

        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        cook_log = cls(
            recipe=recipe,
            created_by=created_by,
            updated_at=updated_at,
            id=id,
            servings=servings,
            rating=rating,
            comment=comment,
            created_at=created_at,
        )

        cook_log.additional_properties = d
        return cook_log

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
