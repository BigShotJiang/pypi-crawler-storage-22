from __future__ import annotations

import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.user import User


T = TypeVar("T", bound="CustomFilter")


@_attrs_define
class CustomFilter:
    """Adds nested create feature

    Attributes:
        name (str):
        search (str):
        created_by (int):
        id (int | Unset):
        shared (list[User] | Unset):
    """

    name: str
    search: str
    created_by: int
    id: int | Unset = UNSET
    shared: list[User] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        search = self.search

        created_by = self.created_by

        id = self.id

        shared: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.shared, Unset):
            shared = []
            for shared_item_data in self.shared:
                shared_item = shared_item_data.to_dict()
                shared.append(shared_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "search": search,
                "created_by": created_by,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if shared is not UNSET:
            field_dict["shared"] = shared

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("name", (None, str(self.name).encode(), "text/plain")))

        files.append(("search", (None, str(self.search).encode(), "text/plain")))

        files.append(("created_by", (None, str(self.created_by).encode(), "text/plain")))

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.shared, Unset):
            for shared_item_element in self.shared:
                files.append(("shared", (None, json.dumps(shared_item_element.to_dict()).encode(), "application/json")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user import User

        d = dict(src_dict)
        name = d.pop("name")

        search = d.pop("search")

        created_by = d.pop("created_by")

        id = d.pop("id", UNSET)

        _shared = d.pop("shared", UNSET)
        shared: list[User] | Unset = UNSET
        if _shared is not UNSET:
            shared = []
            for shared_item_data in _shared:
                shared_item = User.from_dict(shared_item_data)

                shared.append(shared_item)

        custom_filter = cls(
            name=name,
            search=search,
            created_by=created_by,
            id=id,
            shared=shared,
        )

        custom_filter.additional_properties = d
        return custom_filter

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
