from enum import Enum


class DefaultPageEnum(str, Enum):
    BOOKS = "BOOKS"
    PLAN = "PLAN"
    SEARCH = "SEARCH"
    SHOPPING = "SHOPPING"

    def __str__(self) -> str:
        return str(self.value)
