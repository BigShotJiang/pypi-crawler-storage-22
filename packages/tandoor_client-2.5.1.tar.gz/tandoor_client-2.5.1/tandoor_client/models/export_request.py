from __future__ import annotations

import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.custom_filter import CustomFilter
    from ..models.recipe_simple import RecipeSimple


T = TypeVar("T", bound="ExportRequest")


@_attrs_define
class ExportRequest:
    """
    Attributes:
        type_ (str):
        all_ (bool | Unset):  Default: False.
        recipes (list[RecipeSimple] | Unset):
        custom_filter (CustomFilter | None | Unset):
    """

    type_: str
    all_: bool | Unset = False
    recipes: list[RecipeSimple] | Unset = UNSET
    custom_filter: CustomFilter | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.custom_filter import CustomFilter

        type_ = self.type_

        all_ = self.all_

        recipes: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.recipes, Unset):
            recipes = []
            for recipes_item_data in self.recipes:
                recipes_item = recipes_item_data.to_dict()
                recipes.append(recipes_item)

        custom_filter: dict[str, Any] | None | Unset
        if isinstance(self.custom_filter, Unset):
            custom_filter = UNSET
        elif isinstance(self.custom_filter, CustomFilter):
            custom_filter = self.custom_filter.to_dict()
        else:
            custom_filter = self.custom_filter

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "type": type_,
            }
        )
        if all_ is not UNSET:
            field_dict["all"] = all_
        if recipes is not UNSET:
            field_dict["recipes"] = recipes
        if custom_filter is not UNSET:
            field_dict["custom_filter"] = custom_filter

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("type", (None, str(self.type_).encode(), "text/plain")))

        if not isinstance(self.all_, Unset):
            files.append(("all", (None, str(self.all_).encode(), "text/plain")))

        if not isinstance(self.recipes, Unset):
            for recipes_item_element in self.recipes:
                files.append(
                    ("recipes", (None, json.dumps(recipes_item_element.to_dict()).encode(), "application/json"))
                )

        if not isinstance(self.custom_filter, Unset):
            if self.custom_filter is None:
                files.append(("custom_filter", (None, str(self.custom_filter).encode(), "text/plain")))
            else:
                files.append(
                    ("custom_filter", (None, json.dumps(self.custom_filter.to_dict()).encode(), "application/json"))
                )

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.custom_filter import CustomFilter
        from ..models.recipe_simple import RecipeSimple

        d = dict(src_dict)
        type_ = d.pop("type")

        all_ = d.pop("all", UNSET)

        _recipes = d.pop("recipes", UNSET)
        recipes: list[RecipeSimple] | Unset = UNSET
        if _recipes is not UNSET:
            recipes = []
            for recipes_item_data in _recipes:
                recipes_item = RecipeSimple.from_dict(recipes_item_data)

                recipes.append(recipes_item)

        def _parse_custom_filter(data: object) -> CustomFilter | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                custom_filter_type_1 = CustomFilter.from_dict(data)

                return custom_filter_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CustomFilter | None | Unset, data)

        custom_filter = _parse_custom_filter(d.pop("custom_filter", UNSET))

        export_request = cls(
            type_=type_,
            all_=all_,
            recipes=recipes,
            custom_filter=custom_filter,
        )

        export_request.additional_properties = d
        return export_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
