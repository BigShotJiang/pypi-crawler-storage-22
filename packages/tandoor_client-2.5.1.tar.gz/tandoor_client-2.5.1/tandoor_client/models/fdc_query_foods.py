from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="FdcQueryFoods")


@_attrs_define
class FdcQueryFoods:
    """
    Attributes:
        fdc_id (int):
        description (str):
        data_type (str):
    """

    fdc_id: int
    description: str
    data_type: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        fdc_id = self.fdc_id

        description = self.description

        data_type = self.data_type

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "fdcId": fdc_id,
                "description": description,
                "dataType": data_type,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        fdc_id = d.pop("fdcId")

        description = d.pop("description")

        data_type = d.pop("dataType")

        fdc_query_foods = cls(
            fdc_id=fdc_id,
            description=description,
            data_type=data_type,
        )

        fdc_query_foods.additional_properties = d
        return fdc_query_foods

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
