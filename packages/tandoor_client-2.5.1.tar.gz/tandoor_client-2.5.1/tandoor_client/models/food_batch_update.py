from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="FoodBatchUpdate")


@_attrs_define
class FoodBatchUpdate:
    """
    Attributes:
        foods (list[int]):
        substitute_add (list[int]):
        substitute_remove (list[int]):
        substitute_set (list[int]):
        inherit_fields_add (list[int]):
        inherit_fields_remove (list[int]):
        inherit_fields_set (list[int]):
        child_inherit_fields_add (list[int]):
        child_inherit_fields_remove (list[int]):
        child_inherit_fields_set (list[int]):
        category (int | None | Unset):
        substitute_remove_all (bool | Unset):  Default: False.
        inherit_fields_remove_all (bool | Unset):  Default: False.
        child_inherit_fields_remove_all (bool | Unset):  Default: False.
        shopping_lists_add (list[int] | Unset):
        shopping_lists_remove (list[int] | Unset):
        shopping_lists_set (list[int] | Unset):
        shopping_lists_remove_all (bool | Unset):  Default: False.
        substitute_children (bool | None | Unset):
        substitute_siblings (bool | None | Unset):
        ignore_shopping (bool | None | Unset):
        on_hand (bool | None | Unset):
        parent_remove (bool | None | Unset):
        parent_set (int | None | Unset):
    """

    foods: list[int]
    substitute_add: list[int]
    substitute_remove: list[int]
    substitute_set: list[int]
    inherit_fields_add: list[int]
    inherit_fields_remove: list[int]
    inherit_fields_set: list[int]
    child_inherit_fields_add: list[int]
    child_inherit_fields_remove: list[int]
    child_inherit_fields_set: list[int]
    category: int | None | Unset = UNSET
    substitute_remove_all: bool | Unset = False
    inherit_fields_remove_all: bool | Unset = False
    child_inherit_fields_remove_all: bool | Unset = False
    shopping_lists_add: list[int] | Unset = UNSET
    shopping_lists_remove: list[int] | Unset = UNSET
    shopping_lists_set: list[int] | Unset = UNSET
    shopping_lists_remove_all: bool | Unset = False
    substitute_children: bool | None | Unset = UNSET
    substitute_siblings: bool | None | Unset = UNSET
    ignore_shopping: bool | None | Unset = UNSET
    on_hand: bool | None | Unset = UNSET
    parent_remove: bool | None | Unset = UNSET
    parent_set: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        foods = self.foods

        substitute_add = self.substitute_add

        substitute_remove = self.substitute_remove

        substitute_set = self.substitute_set

        inherit_fields_add = self.inherit_fields_add

        inherit_fields_remove = self.inherit_fields_remove

        inherit_fields_set = self.inherit_fields_set

        child_inherit_fields_add = self.child_inherit_fields_add

        child_inherit_fields_remove = self.child_inherit_fields_remove

        child_inherit_fields_set = self.child_inherit_fields_set

        category: int | None | Unset
        if isinstance(self.category, Unset):
            category = UNSET
        else:
            category = self.category

        substitute_remove_all = self.substitute_remove_all

        inherit_fields_remove_all = self.inherit_fields_remove_all

        child_inherit_fields_remove_all = self.child_inherit_fields_remove_all

        shopping_lists_add: list[int] | Unset = UNSET
        if not isinstance(self.shopping_lists_add, Unset):
            shopping_lists_add = self.shopping_lists_add

        shopping_lists_remove: list[int] | Unset = UNSET
        if not isinstance(self.shopping_lists_remove, Unset):
            shopping_lists_remove = self.shopping_lists_remove

        shopping_lists_set: list[int] | Unset = UNSET
        if not isinstance(self.shopping_lists_set, Unset):
            shopping_lists_set = self.shopping_lists_set

        shopping_lists_remove_all = self.shopping_lists_remove_all

        substitute_children: bool | None | Unset
        if isinstance(self.substitute_children, Unset):
            substitute_children = UNSET
        else:
            substitute_children = self.substitute_children

        substitute_siblings: bool | None | Unset
        if isinstance(self.substitute_siblings, Unset):
            substitute_siblings = UNSET
        else:
            substitute_siblings = self.substitute_siblings

        ignore_shopping: bool | None | Unset
        if isinstance(self.ignore_shopping, Unset):
            ignore_shopping = UNSET
        else:
            ignore_shopping = self.ignore_shopping

        on_hand: bool | None | Unset
        if isinstance(self.on_hand, Unset):
            on_hand = UNSET
        else:
            on_hand = self.on_hand

        parent_remove: bool | None | Unset
        if isinstance(self.parent_remove, Unset):
            parent_remove = UNSET
        else:
            parent_remove = self.parent_remove

        parent_set: int | None | Unset
        if isinstance(self.parent_set, Unset):
            parent_set = UNSET
        else:
            parent_set = self.parent_set

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "foods": foods,
                "substitute_add": substitute_add,
                "substitute_remove": substitute_remove,
                "substitute_set": substitute_set,
                "inherit_fields_add": inherit_fields_add,
                "inherit_fields_remove": inherit_fields_remove,
                "inherit_fields_set": inherit_fields_set,
                "child_inherit_fields_add": child_inherit_fields_add,
                "child_inherit_fields_remove": child_inherit_fields_remove,
                "child_inherit_fields_set": child_inherit_fields_set,
            }
        )
        if category is not UNSET:
            field_dict["category"] = category
        if substitute_remove_all is not UNSET:
            field_dict["substitute_remove_all"] = substitute_remove_all
        if inherit_fields_remove_all is not UNSET:
            field_dict["inherit_fields_remove_all"] = inherit_fields_remove_all
        if child_inherit_fields_remove_all is not UNSET:
            field_dict["child_inherit_fields_remove_all"] = child_inherit_fields_remove_all
        if shopping_lists_add is not UNSET:
            field_dict["shopping_lists_add"] = shopping_lists_add
        if shopping_lists_remove is not UNSET:
            field_dict["shopping_lists_remove"] = shopping_lists_remove
        if shopping_lists_set is not UNSET:
            field_dict["shopping_lists_set"] = shopping_lists_set
        if shopping_lists_remove_all is not UNSET:
            field_dict["shopping_lists_remove_all"] = shopping_lists_remove_all
        if substitute_children is not UNSET:
            field_dict["substitute_children"] = substitute_children
        if substitute_siblings is not UNSET:
            field_dict["substitute_siblings"] = substitute_siblings
        if ignore_shopping is not UNSET:
            field_dict["ignore_shopping"] = ignore_shopping
        if on_hand is not UNSET:
            field_dict["on_hand"] = on_hand
        if parent_remove is not UNSET:
            field_dict["parent_remove"] = parent_remove
        if parent_set is not UNSET:
            field_dict["parent_set"] = parent_set

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        for foods_item_element in self.foods:
            files.append(("foods", (None, str(foods_item_element).encode(), "text/plain")))

        for substitute_add_item_element in self.substitute_add:
            files.append(("substitute_add", (None, str(substitute_add_item_element).encode(), "text/plain")))

        for substitute_remove_item_element in self.substitute_remove:
            files.append(("substitute_remove", (None, str(substitute_remove_item_element).encode(), "text/plain")))

        for substitute_set_item_element in self.substitute_set:
            files.append(("substitute_set", (None, str(substitute_set_item_element).encode(), "text/plain")))

        for inherit_fields_add_item_element in self.inherit_fields_add:
            files.append(("inherit_fields_add", (None, str(inherit_fields_add_item_element).encode(), "text/plain")))

        for inherit_fields_remove_item_element in self.inherit_fields_remove:
            files.append(
                ("inherit_fields_remove", (None, str(inherit_fields_remove_item_element).encode(), "text/plain"))
            )

        for inherit_fields_set_item_element in self.inherit_fields_set:
            files.append(("inherit_fields_set", (None, str(inherit_fields_set_item_element).encode(), "text/plain")))

        for child_inherit_fields_add_item_element in self.child_inherit_fields_add:
            files.append(
                ("child_inherit_fields_add", (None, str(child_inherit_fields_add_item_element).encode(), "text/plain"))
            )

        for child_inherit_fields_remove_item_element in self.child_inherit_fields_remove:
            files.append(
                (
                    "child_inherit_fields_remove",
                    (None, str(child_inherit_fields_remove_item_element).encode(), "text/plain"),
                )
            )

        for child_inherit_fields_set_item_element in self.child_inherit_fields_set:
            files.append(
                ("child_inherit_fields_set", (None, str(child_inherit_fields_set_item_element).encode(), "text/plain"))
            )

        if not isinstance(self.category, Unset):
            if isinstance(self.category, int):
                files.append(("category", (None, str(self.category).encode(), "text/plain")))
            else:
                files.append(("category", (None, str(self.category).encode(), "text/plain")))

        if not isinstance(self.substitute_remove_all, Unset):
            files.append(("substitute_remove_all", (None, str(self.substitute_remove_all).encode(), "text/plain")))

        if not isinstance(self.inherit_fields_remove_all, Unset):
            files.append(
                ("inherit_fields_remove_all", (None, str(self.inherit_fields_remove_all).encode(), "text/plain"))
            )

        if not isinstance(self.child_inherit_fields_remove_all, Unset):
            files.append(
                (
                    "child_inherit_fields_remove_all",
                    (None, str(self.child_inherit_fields_remove_all).encode(), "text/plain"),
                )
            )

        if not isinstance(self.shopping_lists_add, Unset):
            for shopping_lists_add_item_element in self.shopping_lists_add:
                files.append(
                    ("shopping_lists_add", (None, str(shopping_lists_add_item_element).encode(), "text/plain"))
                )

        if not isinstance(self.shopping_lists_remove, Unset):
            for shopping_lists_remove_item_element in self.shopping_lists_remove:
                files.append(
                    ("shopping_lists_remove", (None, str(shopping_lists_remove_item_element).encode(), "text/plain"))
                )

        if not isinstance(self.shopping_lists_set, Unset):
            for shopping_lists_set_item_element in self.shopping_lists_set:
                files.append(
                    ("shopping_lists_set", (None, str(shopping_lists_set_item_element).encode(), "text/plain"))
                )

        if not isinstance(self.shopping_lists_remove_all, Unset):
            files.append(
                ("shopping_lists_remove_all", (None, str(self.shopping_lists_remove_all).encode(), "text/plain"))
            )

        if not isinstance(self.substitute_children, Unset):
            if isinstance(self.substitute_children, bool):
                files.append(("substitute_children", (None, str(self.substitute_children).encode(), "text/plain")))
            else:
                files.append(("substitute_children", (None, str(self.substitute_children).encode(), "text/plain")))

        if not isinstance(self.substitute_siblings, Unset):
            if isinstance(self.substitute_siblings, bool):
                files.append(("substitute_siblings", (None, str(self.substitute_siblings).encode(), "text/plain")))
            else:
                files.append(("substitute_siblings", (None, str(self.substitute_siblings).encode(), "text/plain")))

        if not isinstance(self.ignore_shopping, Unset):
            if isinstance(self.ignore_shopping, bool):
                files.append(("ignore_shopping", (None, str(self.ignore_shopping).encode(), "text/plain")))
            else:
                files.append(("ignore_shopping", (None, str(self.ignore_shopping).encode(), "text/plain")))

        if not isinstance(self.on_hand, Unset):
            if isinstance(self.on_hand, bool):
                files.append(("on_hand", (None, str(self.on_hand).encode(), "text/plain")))
            else:
                files.append(("on_hand", (None, str(self.on_hand).encode(), "text/plain")))

        if not isinstance(self.parent_remove, Unset):
            if isinstance(self.parent_remove, bool):
                files.append(("parent_remove", (None, str(self.parent_remove).encode(), "text/plain")))
            else:
                files.append(("parent_remove", (None, str(self.parent_remove).encode(), "text/plain")))

        if not isinstance(self.parent_set, Unset):
            if isinstance(self.parent_set, int):
                files.append(("parent_set", (None, str(self.parent_set).encode(), "text/plain")))
            else:
                files.append(("parent_set", (None, str(self.parent_set).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        foods = cast(list[int], d.pop("foods"))

        substitute_add = cast(list[int], d.pop("substitute_add"))

        substitute_remove = cast(list[int], d.pop("substitute_remove"))

        substitute_set = cast(list[int], d.pop("substitute_set"))

        inherit_fields_add = cast(list[int], d.pop("inherit_fields_add"))

        inherit_fields_remove = cast(list[int], d.pop("inherit_fields_remove"))

        inherit_fields_set = cast(list[int], d.pop("inherit_fields_set"))

        child_inherit_fields_add = cast(list[int], d.pop("child_inherit_fields_add"))

        child_inherit_fields_remove = cast(list[int], d.pop("child_inherit_fields_remove"))

        child_inherit_fields_set = cast(list[int], d.pop("child_inherit_fields_set"))

        def _parse_category(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        category = _parse_category(d.pop("category", UNSET))

        substitute_remove_all = d.pop("substitute_remove_all", UNSET)

        inherit_fields_remove_all = d.pop("inherit_fields_remove_all", UNSET)

        child_inherit_fields_remove_all = d.pop("child_inherit_fields_remove_all", UNSET)

        shopping_lists_add = cast(list[int], d.pop("shopping_lists_add", UNSET))

        shopping_lists_remove = cast(list[int], d.pop("shopping_lists_remove", UNSET))

        shopping_lists_set = cast(list[int], d.pop("shopping_lists_set", UNSET))

        shopping_lists_remove_all = d.pop("shopping_lists_remove_all", UNSET)

        def _parse_substitute_children(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        substitute_children = _parse_substitute_children(d.pop("substitute_children", UNSET))

        def _parse_substitute_siblings(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        substitute_siblings = _parse_substitute_siblings(d.pop("substitute_siblings", UNSET))

        def _parse_ignore_shopping(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        ignore_shopping = _parse_ignore_shopping(d.pop("ignore_shopping", UNSET))

        def _parse_on_hand(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        on_hand = _parse_on_hand(d.pop("on_hand", UNSET))

        def _parse_parent_remove(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        parent_remove = _parse_parent_remove(d.pop("parent_remove", UNSET))

        def _parse_parent_set(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        parent_set = _parse_parent_set(d.pop("parent_set", UNSET))

        food_batch_update = cls(
            foods=foods,
            substitute_add=substitute_add,
            substitute_remove=substitute_remove,
            substitute_set=substitute_set,
            inherit_fields_add=inherit_fields_add,
            inherit_fields_remove=inherit_fields_remove,
            inherit_fields_set=inherit_fields_set,
            child_inherit_fields_add=child_inherit_fields_add,
            child_inherit_fields_remove=child_inherit_fields_remove,
            child_inherit_fields_set=child_inherit_fields_set,
            category=category,
            substitute_remove_all=substitute_remove_all,
            inherit_fields_remove_all=inherit_fields_remove_all,
            child_inherit_fields_remove_all=child_inherit_fields_remove_all,
            shopping_lists_add=shopping_lists_add,
            shopping_lists_remove=shopping_lists_remove,
            shopping_lists_set=shopping_lists_set,
            shopping_lists_remove_all=shopping_lists_remove_all,
            substitute_children=substitute_children,
            substitute_siblings=substitute_siblings,
            ignore_shopping=ignore_shopping,
            on_hand=on_hand,
            parent_remove=parent_remove,
            parent_set=parent_set,
        )

        food_batch_update.additional_properties = d
        return food_batch_update

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
