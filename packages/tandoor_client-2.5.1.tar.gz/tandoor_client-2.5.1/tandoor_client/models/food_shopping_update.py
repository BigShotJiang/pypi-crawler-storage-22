from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..models.delete_enum import DeleteEnum
from ..types import UNSET, Unset

T = TypeVar("T", bound="FoodShoppingUpdate")


@_attrs_define
class FoodShoppingUpdate:
    """
    Attributes:
        delete (DeleteEnum | None): When set to true will delete all food from active shopping lists.

            * `true` - true
        id (int | Unset):
        amount (int | None | Unset): Amount of food to add to the shopping list
        unit (int | None | Unset): ID of unit to use for the shopping list
    """

    delete: DeleteEnum | None
    id: int | Unset = UNSET
    amount: int | None | Unset = UNSET
    unit: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        delete: None | str
        if isinstance(self.delete, DeleteEnum):
            delete = self.delete.value
        else:
            delete = self.delete

        id = self.id

        amount: int | None | Unset
        if isinstance(self.amount, Unset):
            amount = UNSET
        else:
            amount = self.amount

        unit: int | None | Unset
        if isinstance(self.unit, Unset):
            unit = UNSET
        else:
            unit = self.unit

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "delete": delete,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if amount is not UNSET:
            field_dict["amount"] = amount
        if unit is not UNSET:
            field_dict["unit"] = unit

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if self.delete is None:
            files.append(("delete", (None, str(self.delete).encode(), "text/plain")))
        else:
            files.append(("delete", (None, str(self.delete.value).encode(), "text/plain")))

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.amount, Unset):
            if isinstance(self.amount, int):
                files.append(("amount", (None, str(self.amount).encode(), "text/plain")))
            else:
                files.append(("amount", (None, str(self.amount).encode(), "text/plain")))

        if not isinstance(self.unit, Unset):
            if isinstance(self.unit, int):
                files.append(("unit", (None, str(self.unit).encode(), "text/plain")))
            else:
                files.append(("unit", (None, str(self.unit).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_delete(data: object) -> DeleteEnum | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                delete_type_1 = DeleteEnum(data)

                return delete_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DeleteEnum | None, data)

        delete = _parse_delete(d.pop("delete"))

        id = d.pop("id", UNSET)

        def _parse_amount(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        amount = _parse_amount(d.pop("amount", UNSET))

        def _parse_unit(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        unit = _parse_unit(d.pop("unit", UNSET))

        food_shopping_update = cls(
            delete=delete,
            id=id,
            amount=amount,
            unit=unit,
        )

        food_shopping_update.additional_properties = d
        return food_shopping_update

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
