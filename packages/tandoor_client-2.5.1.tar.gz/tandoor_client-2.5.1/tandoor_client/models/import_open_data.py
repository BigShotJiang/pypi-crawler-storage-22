from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="ImportOpenData")


@_attrs_define
class ImportOpenData:
    """
    Attributes:
        selected_version (str):
        selected_datatypes (list[str]):
        update_existing (bool | Unset):  Default: True.
        use_metric (bool | Unset):  Default: True.
    """

    selected_version: str
    selected_datatypes: list[str]
    update_existing: bool | Unset = True
    use_metric: bool | Unset = True
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        selected_version = self.selected_version

        selected_datatypes = self.selected_datatypes

        update_existing = self.update_existing

        use_metric = self.use_metric

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "selected_version": selected_version,
                "selected_datatypes": selected_datatypes,
            }
        )
        if update_existing is not UNSET:
            field_dict["update_existing"] = update_existing
        if use_metric is not UNSET:
            field_dict["use_metric"] = use_metric

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("selected_version", (None, str(self.selected_version).encode(), "text/plain")))

        for selected_datatypes_item_element in self.selected_datatypes:
            files.append(("selected_datatypes", (None, str(selected_datatypes_item_element).encode(), "text/plain")))

        if not isinstance(self.update_existing, Unset):
            files.append(("update_existing", (None, str(self.update_existing).encode(), "text/plain")))

        if not isinstance(self.use_metric, Unset):
            files.append(("use_metric", (None, str(self.use_metric).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        selected_version = d.pop("selected_version")

        selected_datatypes = cast(list[str], d.pop("selected_datatypes"))

        update_existing = d.pop("update_existing", UNSET)

        use_metric = d.pop("use_metric", UNSET)

        import_open_data = cls(
            selected_version=selected_version,
            selected_datatypes=selected_datatypes,
            update_existing=update_existing,
            use_metric=use_metric,
        )

        import_open_data.additional_properties = d
        return import_open_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
