from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.import_open_data_version_meta_data import ImportOpenDataVersionMetaData


T = TypeVar("T", bound="ImportOpenDataMetaData")


@_attrs_define
class ImportOpenDataMetaData:
    """
    Attributes:
        versions (list[str]):
        datatypes (list[str]):
        base (ImportOpenDataVersionMetaData):
        cs (ImportOpenDataVersionMetaData):
        da (ImportOpenDataVersionMetaData):
        de (ImportOpenDataVersionMetaData):
        el (ImportOpenDataVersionMetaData):
        en (ImportOpenDataVersionMetaData):
        es (ImportOpenDataVersionMetaData):
        fr (ImportOpenDataVersionMetaData):
        hu (ImportOpenDataVersionMetaData):
        it (ImportOpenDataVersionMetaData):
        nb_no (ImportOpenDataVersionMetaData):
        nl (ImportOpenDataVersionMetaData):
        pl (ImportOpenDataVersionMetaData):
        pt (ImportOpenDataVersionMetaData):
        pt_br (ImportOpenDataVersionMetaData):
        sk (ImportOpenDataVersionMetaData):
        sl (ImportOpenDataVersionMetaData):
        zh_hans (ImportOpenDataVersionMetaData):
    """

    versions: list[str]
    datatypes: list[str]
    base: ImportOpenDataVersionMetaData
    cs: ImportOpenDataVersionMetaData
    da: ImportOpenDataVersionMetaData
    de: ImportOpenDataVersionMetaData
    el: ImportOpenDataVersionMetaData
    en: ImportOpenDataVersionMetaData
    es: ImportOpenDataVersionMetaData
    fr: ImportOpenDataVersionMetaData
    hu: ImportOpenDataVersionMetaData
    it: ImportOpenDataVersionMetaData
    nb_no: ImportOpenDataVersionMetaData
    nl: ImportOpenDataVersionMetaData
    pl: ImportOpenDataVersionMetaData
    pt: ImportOpenDataVersionMetaData
    pt_br: ImportOpenDataVersionMetaData
    sk: ImportOpenDataVersionMetaData
    sl: ImportOpenDataVersionMetaData
    zh_hans: ImportOpenDataVersionMetaData
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        versions = self.versions

        datatypes = self.datatypes

        base = self.base.to_dict()

        cs = self.cs.to_dict()

        da = self.da.to_dict()

        de = self.de.to_dict()

        el = self.el.to_dict()

        en = self.en.to_dict()

        es = self.es.to_dict()

        fr = self.fr.to_dict()

        hu = self.hu.to_dict()

        it = self.it.to_dict()

        nb_no = self.nb_no.to_dict()

        nl = self.nl.to_dict()

        pl = self.pl.to_dict()

        pt = self.pt.to_dict()

        pt_br = self.pt_br.to_dict()

        sk = self.sk.to_dict()

        sl = self.sl.to_dict()

        zh_hans = self.zh_hans.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "versions": versions,
                "datatypes": datatypes,
                "base": base,
                "cs": cs,
                "da": da,
                "de": de,
                "el": el,
                "en": en,
                "es": es,
                "fr": fr,
                "hu": hu,
                "it": it,
                "nb_NO": nb_no,
                "nl": nl,
                "pl": pl,
                "pt": pt,
                "pt_BR": pt_br,
                "sk": sk,
                "sl": sl,
                "zh_Hans": zh_hans,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.import_open_data_version_meta_data import ImportOpenDataVersionMetaData

        d = dict(src_dict)
        versions = cast(list[str], d.pop("versions"))

        datatypes = cast(list[str], d.pop("datatypes"))

        base = ImportOpenDataVersionMetaData.from_dict(d.pop("base"))

        cs = ImportOpenDataVersionMetaData.from_dict(d.pop("cs"))

        da = ImportOpenDataVersionMetaData.from_dict(d.pop("da"))

        de = ImportOpenDataVersionMetaData.from_dict(d.pop("de"))

        el = ImportOpenDataVersionMetaData.from_dict(d.pop("el"))

        en = ImportOpenDataVersionMetaData.from_dict(d.pop("en"))

        es = ImportOpenDataVersionMetaData.from_dict(d.pop("es"))

        fr = ImportOpenDataVersionMetaData.from_dict(d.pop("fr"))

        hu = ImportOpenDataVersionMetaData.from_dict(d.pop("hu"))

        it = ImportOpenDataVersionMetaData.from_dict(d.pop("it"))

        nb_no = ImportOpenDataVersionMetaData.from_dict(d.pop("nb_NO"))

        nl = ImportOpenDataVersionMetaData.from_dict(d.pop("nl"))

        pl = ImportOpenDataVersionMetaData.from_dict(d.pop("pl"))

        pt = ImportOpenDataVersionMetaData.from_dict(d.pop("pt"))

        pt_br = ImportOpenDataVersionMetaData.from_dict(d.pop("pt_BR"))

        sk = ImportOpenDataVersionMetaData.from_dict(d.pop("sk"))

        sl = ImportOpenDataVersionMetaData.from_dict(d.pop("sl"))

        zh_hans = ImportOpenDataVersionMetaData.from_dict(d.pop("zh_Hans"))

        import_open_data_meta_data = cls(
            versions=versions,
            datatypes=datatypes,
            base=base,
            cs=cs,
            da=da,
            de=de,
            el=el,
            en=en,
            es=es,
            fr=fr,
            hu=hu,
            it=it,
            nb_no=nb_no,
            nl=nl,
            pl=pl,
            pt=pt,
            pt_br=pt_br,
            sk=sk,
            sl=sl,
            zh_hans=zh_hans,
        )

        import_open_data_meta_data.additional_properties = d
        return import_open_data_meta_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
