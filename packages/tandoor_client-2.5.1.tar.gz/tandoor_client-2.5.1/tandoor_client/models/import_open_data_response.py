from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.import_open_data_response_detail import ImportOpenDataResponseDetail


T = TypeVar("T", bound="ImportOpenDataResponse")


@_attrs_define
class ImportOpenDataResponse:
    """
    Attributes:
        food (ImportOpenDataResponseDetail | Unset):
        unit (ImportOpenDataResponseDetail | Unset):
        category (ImportOpenDataResponseDetail | Unset):
        property_ (ImportOpenDataResponseDetail | Unset):
        store (ImportOpenDataResponseDetail | Unset):
        conversion (ImportOpenDataResponseDetail | Unset):
    """

    food: ImportOpenDataResponseDetail | Unset = UNSET
    unit: ImportOpenDataResponseDetail | Unset = UNSET
    category: ImportOpenDataResponseDetail | Unset = UNSET
    property_: ImportOpenDataResponseDetail | Unset = UNSET
    store: ImportOpenDataResponseDetail | Unset = UNSET
    conversion: ImportOpenDataResponseDetail | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        food: dict[str, Any] | Unset = UNSET
        if not isinstance(self.food, Unset):
            food = self.food.to_dict()

        unit: dict[str, Any] | Unset = UNSET
        if not isinstance(self.unit, Unset):
            unit = self.unit.to_dict()

        category: dict[str, Any] | Unset = UNSET
        if not isinstance(self.category, Unset):
            category = self.category.to_dict()

        property_: dict[str, Any] | Unset = UNSET
        if not isinstance(self.property_, Unset):
            property_ = self.property_.to_dict()

        store: dict[str, Any] | Unset = UNSET
        if not isinstance(self.store, Unset):
            store = self.store.to_dict()

        conversion: dict[str, Any] | Unset = UNSET
        if not isinstance(self.conversion, Unset):
            conversion = self.conversion.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if food is not UNSET:
            field_dict["food"] = food
        if unit is not UNSET:
            field_dict["unit"] = unit
        if category is not UNSET:
            field_dict["category"] = category
        if property_ is not UNSET:
            field_dict["property"] = property_
        if store is not UNSET:
            field_dict["store"] = store
        if conversion is not UNSET:
            field_dict["conversion"] = conversion

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.import_open_data_response_detail import ImportOpenDataResponseDetail

        d = dict(src_dict)
        _food = d.pop("food", UNSET)
        food: ImportOpenDataResponseDetail | Unset
        if isinstance(_food, Unset):
            food = UNSET
        else:
            food = ImportOpenDataResponseDetail.from_dict(_food)

        _unit = d.pop("unit", UNSET)
        unit: ImportOpenDataResponseDetail | Unset
        if isinstance(_unit, Unset):
            unit = UNSET
        else:
            unit = ImportOpenDataResponseDetail.from_dict(_unit)

        _category = d.pop("category", UNSET)
        category: ImportOpenDataResponseDetail | Unset
        if isinstance(_category, Unset):
            category = UNSET
        else:
            category = ImportOpenDataResponseDetail.from_dict(_category)

        _property_ = d.pop("property", UNSET)
        property_: ImportOpenDataResponseDetail | Unset
        if isinstance(_property_, Unset):
            property_ = UNSET
        else:
            property_ = ImportOpenDataResponseDetail.from_dict(_property_)

        _store = d.pop("store", UNSET)
        store: ImportOpenDataResponseDetail | Unset
        if isinstance(_store, Unset):
            store = UNSET
        else:
            store = ImportOpenDataResponseDetail.from_dict(_store)

        _conversion = d.pop("conversion", UNSET)
        conversion: ImportOpenDataResponseDetail | Unset
        if isinstance(_conversion, Unset):
            conversion = UNSET
        else:
            conversion = ImportOpenDataResponseDetail.from_dict(_conversion)

        import_open_data_response = cls(
            food=food,
            unit=unit,
            category=category,
            property_=property_,
            store=store,
            conversion=conversion,
        )

        import_open_data_response.additional_properties = d
        return import_open_data_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
