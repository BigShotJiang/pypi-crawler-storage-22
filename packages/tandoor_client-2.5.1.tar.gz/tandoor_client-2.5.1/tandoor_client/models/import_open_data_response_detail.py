from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ImportOpenDataResponseDetail")


@_attrs_define
class ImportOpenDataResponseDetail:
    """
    Attributes:
        total_created (int | Unset):  Default: 0.
        total_updated (int | Unset):  Default: 0.
        total_untouched (int | Unset):  Default: 0.
        total_errored (int | Unset):  Default: 0.
    """

    total_created: int | Unset = 0
    total_updated: int | Unset = 0
    total_untouched: int | Unset = 0
    total_errored: int | Unset = 0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        total_created = self.total_created

        total_updated = self.total_updated

        total_untouched = self.total_untouched

        total_errored = self.total_errored

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if total_created is not UNSET:
            field_dict["total_created"] = total_created
        if total_updated is not UNSET:
            field_dict["total_updated"] = total_updated
        if total_untouched is not UNSET:
            field_dict["total_untouched"] = total_untouched
        if total_errored is not UNSET:
            field_dict["total_errored"] = total_errored

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        total_created = d.pop("total_created", UNSET)

        total_updated = d.pop("total_updated", UNSET)

        total_untouched = d.pop("total_untouched", UNSET)

        total_errored = d.pop("total_errored", UNSET)

        import_open_data_response_detail = cls(
            total_created=total_created,
            total_updated=total_updated,
            total_untouched=total_untouched,
            total_errored=total_errored,
        )

        import_open_data_response_detail.additional_properties = d
        return import_open_data_response_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
