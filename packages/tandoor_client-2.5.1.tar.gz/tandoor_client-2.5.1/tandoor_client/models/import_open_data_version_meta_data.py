from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="ImportOpenDataVersionMetaData")


@_attrs_define
class ImportOpenDataVersionMetaData:
    """
    Attributes:
        food (int):
        unit (int):
        category (int):
        property_ (int):
        store (int):
        conversion (int):
    """

    food: int
    unit: int
    category: int
    property_: int
    store: int
    conversion: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        food = self.food

        unit = self.unit

        category = self.category

        property_ = self.property_

        store = self.store

        conversion = self.conversion

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "food": food,
                "unit": unit,
                "category": category,
                "property": property_,
                "store": store,
                "conversion": conversion,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        food = d.pop("food")

        unit = d.pop("unit")

        category = d.pop("category")

        property_ = d.pop("property")

        store = d.pop("store")

        conversion = d.pop("conversion")

        import_open_data_version_meta_data = cls(
            food=food,
            unit=unit,
            category=category,
            property_=property_,
            store=store,
            conversion=conversion,
        )

        import_open_data_version_meta_data.additional_properties = d
        return import_open_data_version_meta_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
