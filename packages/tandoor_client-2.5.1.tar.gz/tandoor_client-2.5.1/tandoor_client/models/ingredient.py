from __future__ import annotations

import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.food import Food
    from ..models.unit import Unit


T = TypeVar("T", bound="Ingredient")


@_attrs_define
class Ingredient:
    """Adds nested create feature

    Attributes:
        food (Food | None):
        unit (None | Unit):
        amount (float):
        conversions (list[Any]):
        used_in_recipes (list[Any]):
        checked (bool): Just laziness to have a checked field on the frontend API client Default: False.
        id (int | Unset):
        note (None | str | Unset):
        order (int | Unset):
        is_header (bool | Unset):
        no_amount (bool | Unset):
        original_text (None | str | Unset):
        always_use_plural_unit (bool | Unset):
        always_use_plural_food (bool | Unset):
    """

    food: Food | None
    unit: None | Unit
    amount: float
    conversions: list[Any]
    used_in_recipes: list[Any]
    checked: bool = False
    id: int | Unset = UNSET
    note: None | str | Unset = UNSET
    order: int | Unset = UNSET
    is_header: bool | Unset = UNSET
    no_amount: bool | Unset = UNSET
    original_text: None | str | Unset = UNSET
    always_use_plural_unit: bool | Unset = UNSET
    always_use_plural_food: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.food import Food
        from ..models.unit import Unit

        food: dict[str, Any] | None
        if isinstance(self.food, Food):
            food = self.food.to_dict()
        else:
            food = self.food

        unit: dict[str, Any] | None
        if isinstance(self.unit, Unit):
            unit = self.unit.to_dict()
        else:
            unit = self.unit

        amount = self.amount

        conversions = self.conversions

        used_in_recipes = self.used_in_recipes

        checked = self.checked

        id = self.id

        note: None | str | Unset
        if isinstance(self.note, Unset):
            note = UNSET
        else:
            note = self.note

        order = self.order

        is_header = self.is_header

        no_amount = self.no_amount

        original_text: None | str | Unset
        if isinstance(self.original_text, Unset):
            original_text = UNSET
        else:
            original_text = self.original_text

        always_use_plural_unit = self.always_use_plural_unit

        always_use_plural_food = self.always_use_plural_food

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "food": food,
                "unit": unit,
                "amount": amount,
                "conversions": conversions,
                "used_in_recipes": used_in_recipes,
                "checked": checked,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if note is not UNSET:
            field_dict["note"] = note
        if order is not UNSET:
            field_dict["order"] = order
        if is_header is not UNSET:
            field_dict["is_header"] = is_header
        if no_amount is not UNSET:
            field_dict["no_amount"] = no_amount
        if original_text is not UNSET:
            field_dict["original_text"] = original_text
        if always_use_plural_unit is not UNSET:
            field_dict["always_use_plural_unit"] = always_use_plural_unit
        if always_use_plural_food is not UNSET:
            field_dict["always_use_plural_food"] = always_use_plural_food

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if self.food is None:
            files.append(("food", (None, str(self.food).encode(), "text/plain")))
        else:
            files.append(("food", (None, json.dumps(self.food.to_dict()).encode(), "application/json")))

        if self.unit is None:
            files.append(("unit", (None, str(self.unit).encode(), "text/plain")))
        else:
            files.append(("unit", (None, json.dumps(self.unit.to_dict()).encode(), "application/json")))

        files.append(("amount", (None, str(self.amount).encode(), "text/plain")))

        for conversions_item_element in self.conversions:
            files.append(("conversions", (None, str(conversions_item_element).encode(), "text/plain")))

        for used_in_recipes_item_element in self.used_in_recipes:
            files.append(("used_in_recipes", (None, str(used_in_recipes_item_element).encode(), "text/plain")))

        files.append(("checked", (None, str(self.checked).encode(), "text/plain")))

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.note, Unset):
            if isinstance(self.note, str):
                files.append(("note", (None, str(self.note).encode(), "text/plain")))
            else:
                files.append(("note", (None, str(self.note).encode(), "text/plain")))

        if not isinstance(self.order, Unset):
            files.append(("order", (None, str(self.order).encode(), "text/plain")))

        if not isinstance(self.is_header, Unset):
            files.append(("is_header", (None, str(self.is_header).encode(), "text/plain")))

        if not isinstance(self.no_amount, Unset):
            files.append(("no_amount", (None, str(self.no_amount).encode(), "text/plain")))

        if not isinstance(self.original_text, Unset):
            if isinstance(self.original_text, str):
                files.append(("original_text", (None, str(self.original_text).encode(), "text/plain")))
            else:
                files.append(("original_text", (None, str(self.original_text).encode(), "text/plain")))

        if not isinstance(self.always_use_plural_unit, Unset):
            files.append(("always_use_plural_unit", (None, str(self.always_use_plural_unit).encode(), "text/plain")))

        if not isinstance(self.always_use_plural_food, Unset):
            files.append(("always_use_plural_food", (None, str(self.always_use_plural_food).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.food import Food
        from ..models.unit import Unit

        d = dict(src_dict)

        def _parse_food(data: object) -> Food | None:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                food_type_1 = Food.from_dict(data)

                return food_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(Food | None, data)

        food = _parse_food(d.pop("food"))

        def _parse_unit(data: object) -> None | Unit:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                unit_type_1 = Unit.from_dict(data)

                return unit_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unit, data)

        unit = _parse_unit(d.pop("unit"))

        amount = d.pop("amount")

        conversions = cast(list[Any], d.pop("conversions"))

        used_in_recipes = cast(list[Any], d.pop("used_in_recipes"))

        checked = d.pop("checked")

        id = d.pop("id", UNSET)

        def _parse_note(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        note = _parse_note(d.pop("note", UNSET))

        order = d.pop("order", UNSET)

        is_header = d.pop("is_header", UNSET)

        no_amount = d.pop("no_amount", UNSET)

        def _parse_original_text(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        original_text = _parse_original_text(d.pop("original_text", UNSET))

        always_use_plural_unit = d.pop("always_use_plural_unit", UNSET)

        always_use_plural_food = d.pop("always_use_plural_food", UNSET)

        ingredient = cls(
            food=food,
            unit=unit,
            amount=amount,
            conversions=conversions,
            used_in_recipes=used_in_recipes,
            checked=checked,
            id=id,
            note=note,
            order=order,
            is_header=is_header,
            no_amount=no_amount,
            original_text=original_text,
            always_use_plural_unit=always_use_plural_unit,
            always_use_plural_food=always_use_plural_food,
        )

        ingredient.additional_properties = d
        return ingredient

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
