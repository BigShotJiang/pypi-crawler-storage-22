from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="IngredientParserRequest")


@_attrs_define
class IngredientParserRequest:
    """
    Attributes:
        ingredient (str | Unset):
        ingredients (list[str] | Unset):
    """

    ingredient: str | Unset = UNSET
    ingredients: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        ingredient = self.ingredient

        ingredients: list[str] | Unset = UNSET
        if not isinstance(self.ingredients, Unset):
            ingredients = self.ingredients

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if ingredient is not UNSET:
            field_dict["ingredient"] = ingredient
        if ingredients is not UNSET:
            field_dict["ingredients"] = ingredients

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.ingredient, Unset):
            files.append(("ingredient", (None, str(self.ingredient).encode(), "text/plain")))

        if not isinstance(self.ingredients, Unset):
            for ingredients_item_element in self.ingredients:
                files.append(("ingredients", (None, str(ingredients_item_element).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        ingredient = d.pop("ingredient", UNSET)

        ingredients = cast(list[str], d.pop("ingredients", UNSET))

        ingredient_parser_request = cls(
            ingredient=ingredient,
            ingredients=ingredients,
        )

        ingredient_parser_request.additional_properties = d
        return ingredient_parser_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
