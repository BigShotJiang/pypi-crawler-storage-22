from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.ingredient_simple import IngredientSimple


T = TypeVar("T", bound="IngredientParserResponse")


@_attrs_define
class IngredientParserResponse:
    """
    Attributes:
        ingredient (IngredientSimple | None):
        ingredients (list[IngredientSimple]):
    """

    ingredient: IngredientSimple | None
    ingredients: list[IngredientSimple]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.ingredient_simple import IngredientSimple

        ingredient: dict[str, Any] | None
        if isinstance(self.ingredient, IngredientSimple):
            ingredient = self.ingredient.to_dict()
        else:
            ingredient = self.ingredient

        ingredients = []
        for ingredients_item_data in self.ingredients:
            ingredients_item = ingredients_item_data.to_dict()
            ingredients.append(ingredients_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "ingredient": ingredient,
                "ingredients": ingredients,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.ingredient_simple import IngredientSimple

        d = dict(src_dict)

        def _parse_ingredient(data: object) -> IngredientSimple | None:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                ingredient_type_1 = IngredientSimple.from_dict(data)

                return ingredient_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(IngredientSimple | None, data)

        ingredient = _parse_ingredient(d.pop("ingredient"))

        ingredients = []
        _ingredients = d.pop("ingredients")
        for ingredients_item_data in _ingredients:
            ingredients_item = IngredientSimple.from_dict(ingredients_item_data)

            ingredients.append(ingredients_item)

        ingredient_parser_response = cls(
            ingredient=ingredient,
            ingredients=ingredients,
        )

        ingredient_parser_response.additional_properties = d
        return ingredient_parser_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
