from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.food_simple import FoodSimple
    from ..models.unit import Unit


T = TypeVar("T", bound="IngredientSimple")


@_attrs_define
class IngredientSimple:
    """Adds nested create feature

    Attributes:
        food (FoodSimple | None):
        unit (None | Unit):
        amount (float):
        checked (bool): Just laziness to have a checked field on the frontend API client Default: False.
        id (int | Unset):
        note (None | str | Unset):
        order (int | Unset):
        is_header (bool | Unset):
        no_amount (bool | Unset):
        original_text (None | str | Unset):
        always_use_plural_unit (bool | Unset):
        always_use_plural_food (bool | Unset):
    """

    food: FoodSimple | None
    unit: None | Unit
    amount: float
    checked: bool = False
    id: int | Unset = UNSET
    note: None | str | Unset = UNSET
    order: int | Unset = UNSET
    is_header: bool | Unset = UNSET
    no_amount: bool | Unset = UNSET
    original_text: None | str | Unset = UNSET
    always_use_plural_unit: bool | Unset = UNSET
    always_use_plural_food: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.food_simple import FoodSimple
        from ..models.unit import Unit

        food: dict[str, Any] | None
        if isinstance(self.food, FoodSimple):
            food = self.food.to_dict()
        else:
            food = self.food

        unit: dict[str, Any] | None
        if isinstance(self.unit, Unit):
            unit = self.unit.to_dict()
        else:
            unit = self.unit

        amount = self.amount

        checked = self.checked

        id = self.id

        note: None | str | Unset
        if isinstance(self.note, Unset):
            note = UNSET
        else:
            note = self.note

        order = self.order

        is_header = self.is_header

        no_amount = self.no_amount

        original_text: None | str | Unset
        if isinstance(self.original_text, Unset):
            original_text = UNSET
        else:
            original_text = self.original_text

        always_use_plural_unit = self.always_use_plural_unit

        always_use_plural_food = self.always_use_plural_food

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "food": food,
                "unit": unit,
                "amount": amount,
                "checked": checked,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if note is not UNSET:
            field_dict["note"] = note
        if order is not UNSET:
            field_dict["order"] = order
        if is_header is not UNSET:
            field_dict["is_header"] = is_header
        if no_amount is not UNSET:
            field_dict["no_amount"] = no_amount
        if original_text is not UNSET:
            field_dict["original_text"] = original_text
        if always_use_plural_unit is not UNSET:
            field_dict["always_use_plural_unit"] = always_use_plural_unit
        if always_use_plural_food is not UNSET:
            field_dict["always_use_plural_food"] = always_use_plural_food

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.food_simple import FoodSimple
        from ..models.unit import Unit

        d = dict(src_dict)

        def _parse_food(data: object) -> FoodSimple | None:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                food_type_1 = FoodSimple.from_dict(data)

                return food_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(FoodSimple | None, data)

        food = _parse_food(d.pop("food"))

        def _parse_unit(data: object) -> None | Unit:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                unit_type_1 = Unit.from_dict(data)

                return unit_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unit, data)

        unit = _parse_unit(d.pop("unit"))

        amount = d.pop("amount")

        checked = d.pop("checked")

        id = d.pop("id", UNSET)

        def _parse_note(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        note = _parse_note(d.pop("note", UNSET))

        order = d.pop("order", UNSET)

        is_header = d.pop("is_header", UNSET)

        no_amount = d.pop("no_amount", UNSET)

        def _parse_original_text(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        original_text = _parse_original_text(d.pop("original_text", UNSET))

        always_use_plural_unit = d.pop("always_use_plural_unit", UNSET)

        always_use_plural_food = d.pop("always_use_plural_food", UNSET)

        ingredient_simple = cls(
            food=food,
            unit=unit,
            amount=amount,
            checked=checked,
            id=id,
            note=note,
            order=order,
            is_header=is_header,
            no_amount=no_amount,
            original_text=original_text,
            always_use_plural_unit=always_use_plural_unit,
            always_use_plural_food=always_use_plural_food,
        )

        ingredient_simple.additional_properties = d
        return ingredient_simple

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
