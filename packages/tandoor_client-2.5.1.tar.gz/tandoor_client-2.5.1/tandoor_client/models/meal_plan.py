from __future__ import annotations

import datetime
import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.meal_type import MealType
    from ..models.recipe_overview import RecipeOverview
    from ..models.user import User


T = TypeVar("T", bound="MealPlan")


@_attrs_define
class MealPlan:
    """Adds nested create feature

    Attributes:
        servings (float):
        note_markdown (str):
        from_date (datetime.datetime):
        meal_type (MealType): Adds nested create feature
        created_by (int):
        recipe_name (str):
        meal_type_name (str):
        shopping (bool):
        id (int | Unset):
        title (str | Unset):
        recipe (None | RecipeOverview | Unset):
        note (str | Unset):
        to_date (datetime.datetime | Unset):
        shared (list[User] | None | Unset):
        addshopping (bool | Unset):
    """

    servings: float
    note_markdown: str
    from_date: datetime.datetime
    meal_type: MealType
    created_by: int
    recipe_name: str
    meal_type_name: str
    shopping: bool
    id: int | Unset = UNSET
    title: str | Unset = UNSET
    recipe: None | RecipeOverview | Unset = UNSET
    note: str | Unset = UNSET
    to_date: datetime.datetime | Unset = UNSET
    shared: list[User] | None | Unset = UNSET
    addshopping: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.recipe_overview import RecipeOverview

        servings = self.servings

        note_markdown = self.note_markdown

        from_date = self.from_date.isoformat()

        meal_type = self.meal_type.to_dict()

        created_by = self.created_by

        recipe_name = self.recipe_name

        meal_type_name = self.meal_type_name

        shopping = self.shopping

        id = self.id

        title = self.title

        recipe: dict[str, Any] | None | Unset
        if isinstance(self.recipe, Unset):
            recipe = UNSET
        elif isinstance(self.recipe, RecipeOverview):
            recipe = self.recipe.to_dict()
        else:
            recipe = self.recipe

        note = self.note

        to_date: str | Unset = UNSET
        if not isinstance(self.to_date, Unset):
            to_date = self.to_date.isoformat()

        shared: list[dict[str, Any]] | None | Unset
        if isinstance(self.shared, Unset):
            shared = UNSET
        elif isinstance(self.shared, list):
            shared = []
            for shared_type_0_item_data in self.shared:
                shared_type_0_item = shared_type_0_item_data.to_dict()
                shared.append(shared_type_0_item)

        else:
            shared = self.shared

        addshopping = self.addshopping

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "servings": servings,
                "note_markdown": note_markdown,
                "from_date": from_date,
                "meal_type": meal_type,
                "created_by": created_by,
                "recipe_name": recipe_name,
                "meal_type_name": meal_type_name,
                "shopping": shopping,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if title is not UNSET:
            field_dict["title"] = title
        if recipe is not UNSET:
            field_dict["recipe"] = recipe
        if note is not UNSET:
            field_dict["note"] = note
        if to_date is not UNSET:
            field_dict["to_date"] = to_date
        if shared is not UNSET:
            field_dict["shared"] = shared
        if addshopping is not UNSET:
            field_dict["addshopping"] = addshopping

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("servings", (None, str(self.servings).encode(), "text/plain")))

        files.append(("note_markdown", (None, str(self.note_markdown).encode(), "text/plain")))

        files.append(("from_date", (None, self.from_date.isoformat().encode(), "text/plain")))

        files.append(("meal_type", (None, json.dumps(self.meal_type.to_dict()).encode(), "application/json")))

        files.append(("created_by", (None, str(self.created_by).encode(), "text/plain")))

        files.append(("recipe_name", (None, str(self.recipe_name).encode(), "text/plain")))

        files.append(("meal_type_name", (None, str(self.meal_type_name).encode(), "text/plain")))

        files.append(("shopping", (None, str(self.shopping).encode(), "text/plain")))

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.title, Unset):
            files.append(("title", (None, str(self.title).encode(), "text/plain")))

        if not isinstance(self.recipe, Unset):
            if self.recipe is None:
                files.append(("recipe", (None, str(self.recipe).encode(), "text/plain")))
            else:
                files.append(("recipe", (None, json.dumps(self.recipe.to_dict()).encode(), "application/json")))

        if not isinstance(self.note, Unset):
            files.append(("note", (None, str(self.note).encode(), "text/plain")))

        if not isinstance(self.to_date, Unset):
            files.append(("to_date", (None, self.to_date.isoformat().encode(), "text/plain")))

        if not isinstance(self.shared, Unset):
            if isinstance(self.shared, list):
                for shared_type_0_item_element in self.shared:
                    files.append(
                        (
                            "shared",
                            (None, json.dumps(shared_type_0_item_element.to_dict()).encode(), "application/json"),
                        )
                    )
            else:
                files.append(("shared", (None, str(self.shared).encode(), "text/plain")))

        if not isinstance(self.addshopping, Unset):
            files.append(("addshopping", (None, str(self.addshopping).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.meal_type import MealType
        from ..models.recipe_overview import RecipeOverview
        from ..models.user import User

        d = dict(src_dict)
        servings = d.pop("servings")

        note_markdown = d.pop("note_markdown")

        from_date = isoparse(d.pop("from_date"))

        meal_type = MealType.from_dict(d.pop("meal_type"))

        created_by = d.pop("created_by")

        recipe_name = d.pop("recipe_name")

        meal_type_name = d.pop("meal_type_name")

        shopping = d.pop("shopping")

        id = d.pop("id", UNSET)

        title = d.pop("title", UNSET)

        def _parse_recipe(data: object) -> None | RecipeOverview | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                recipe_type_1 = RecipeOverview.from_dict(data)

                return recipe_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RecipeOverview | Unset, data)

        recipe = _parse_recipe(d.pop("recipe", UNSET))

        note = d.pop("note", UNSET)

        _to_date = d.pop("to_date", UNSET)
        to_date: datetime.datetime | Unset
        if isinstance(_to_date, Unset):
            to_date = UNSET
        else:
            to_date = isoparse(_to_date)

        def _parse_shared(data: object) -> list[User] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                shared_type_0 = []
                _shared_type_0 = data
                for shared_type_0_item_data in _shared_type_0:
                    shared_type_0_item = User.from_dict(shared_type_0_item_data)

                    shared_type_0.append(shared_type_0_item)

                return shared_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[User] | None | Unset, data)

        shared = _parse_shared(d.pop("shared", UNSET))

        addshopping = d.pop("addshopping", UNSET)

        meal_plan = cls(
            servings=servings,
            note_markdown=note_markdown,
            from_date=from_date,
            meal_type=meal_type,
            created_by=created_by,
            recipe_name=recipe_name,
            meal_type_name=meal_type_name,
            shopping=shopping,
            id=id,
            title=title,
            recipe=recipe,
            note=note,
            to_date=to_date,
            shared=shared,
            addshopping=addshopping,
        )

        meal_plan.additional_properties = d
        return meal_plan

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
