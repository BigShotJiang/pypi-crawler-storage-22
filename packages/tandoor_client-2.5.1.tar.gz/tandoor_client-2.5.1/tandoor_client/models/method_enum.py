from enum import Enum


class MethodEnum(str, Enum):
    DB = "DB"
    LOCAL = "LOCAL"
    NEXTCLOUD = "NEXTCLOUD"

    def __str__(self) -> str:
        return str(self.value)
