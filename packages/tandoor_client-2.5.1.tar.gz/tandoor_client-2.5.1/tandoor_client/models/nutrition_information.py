from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="NutritionInformation")


@_attrs_define
class NutritionInformation:
    """
    Attributes:
        carbohydrates (float):
        fats (float):
        proteins (float):
        calories (float):
        id (int | Unset):
        source (None | str | Unset):
    """

    carbohydrates: float
    fats: float
    proteins: float
    calories: float
    id: int | Unset = UNSET
    source: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        carbohydrates = self.carbohydrates

        fats = self.fats

        proteins = self.proteins

        calories = self.calories

        id = self.id

        source: None | str | Unset
        if isinstance(self.source, Unset):
            source = UNSET
        else:
            source = self.source

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "carbohydrates": carbohydrates,
                "fats": fats,
                "proteins": proteins,
                "calories": calories,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if source is not UNSET:
            field_dict["source"] = source

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        carbohydrates = d.pop("carbohydrates")

        fats = d.pop("fats")

        proteins = d.pop("proteins")

        calories = d.pop("calories")

        id = d.pop("id", UNSET)

        def _parse_source(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        source = _parse_source(d.pop("source", UNSET))

        nutrition_information = cls(
            carbohydrates=carbohydrates,
            fats=fats,
            proteins=proteins,
            calories=calories,
            id=id,
            source=source,
        )

        nutrition_information.additional_properties = d
        return nutrition_information

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
