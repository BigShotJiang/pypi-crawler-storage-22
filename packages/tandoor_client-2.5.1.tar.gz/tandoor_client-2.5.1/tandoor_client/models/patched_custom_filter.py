from __future__ import annotations

import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.user import User


T = TypeVar("T", bound="PatchedCustomFilter")


@_attrs_define
class PatchedCustomFilter:
    """Adds nested create feature

    Attributes:
        id (int | Unset):
        name (str | Unset):
        search (str | Unset):
        shared (list[User] | Unset):
        created_by (int | Unset):
    """

    id: int | Unset = UNSET
    name: str | Unset = UNSET
    search: str | Unset = UNSET
    shared: list[User] | Unset = UNSET
    created_by: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        search = self.search

        shared: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.shared, Unset):
            shared = []
            for shared_item_data in self.shared:
                shared_item = shared_item_data.to_dict()
                shared.append(shared_item)

        created_by = self.created_by

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if name is not UNSET:
            field_dict["name"] = name
        if search is not UNSET:
            field_dict["search"] = search
        if shared is not UNSET:
            field_dict["shared"] = shared
        if created_by is not UNSET:
            field_dict["created_by"] = created_by

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.name, Unset):
            files.append(("name", (None, str(self.name).encode(), "text/plain")))

        if not isinstance(self.search, Unset):
            files.append(("search", (None, str(self.search).encode(), "text/plain")))

        if not isinstance(self.shared, Unset):
            for shared_item_element in self.shared:
                files.append(("shared", (None, json.dumps(shared_item_element.to_dict()).encode(), "application/json")))

        if not isinstance(self.created_by, Unset):
            files.append(("created_by", (None, str(self.created_by).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user import User

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        name = d.pop("name", UNSET)

        search = d.pop("search", UNSET)

        _shared = d.pop("shared", UNSET)
        shared: list[User] | Unset = UNSET
        if _shared is not UNSET:
            shared = []
            for shared_item_data in _shared:
                shared_item = User.from_dict(shared_item_data)

                shared.append(shared_item)

        created_by = d.pop("created_by", UNSET)

        patched_custom_filter = cls(
            id=id,
            name=name,
            search=search,
            shared=shared,
            created_by=created_by,
        )

        patched_custom_filter.additional_properties = d
        return patched_custom_filter

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
