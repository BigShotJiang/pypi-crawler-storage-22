from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="PatchedExportLog")


@_attrs_define
class PatchedExportLog:
    """
    Attributes:
        id (int | Unset):
        type_ (str | Unset):
        msg (str | Unset):
        running (bool | Unset):
        total_recipes (int | Unset):
        exported_recipes (int | Unset):
        cache_duration (int | Unset):
        possibly_not_expired (bool | Unset):
        created_by (int | Unset):
        created_at (datetime.datetime | Unset):
    """

    id: int | Unset = UNSET
    type_: str | Unset = UNSET
    msg: str | Unset = UNSET
    running: bool | Unset = UNSET
    total_recipes: int | Unset = UNSET
    exported_recipes: int | Unset = UNSET
    cache_duration: int | Unset = UNSET
    possibly_not_expired: bool | Unset = UNSET
    created_by: int | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        type_ = self.type_

        msg = self.msg

        running = self.running

        total_recipes = self.total_recipes

        exported_recipes = self.exported_recipes

        cache_duration = self.cache_duration

        possibly_not_expired = self.possibly_not_expired

        created_by = self.created_by

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if type_ is not UNSET:
            field_dict["type"] = type_
        if msg is not UNSET:
            field_dict["msg"] = msg
        if running is not UNSET:
            field_dict["running"] = running
        if total_recipes is not UNSET:
            field_dict["total_recipes"] = total_recipes
        if exported_recipes is not UNSET:
            field_dict["exported_recipes"] = exported_recipes
        if cache_duration is not UNSET:
            field_dict["cache_duration"] = cache_duration
        if possibly_not_expired is not UNSET:
            field_dict["possibly_not_expired"] = possibly_not_expired
        if created_by is not UNSET:
            field_dict["created_by"] = created_by
        if created_at is not UNSET:
            field_dict["created_at"] = created_at

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.type_, Unset):
            files.append(("type", (None, str(self.type_).encode(), "text/plain")))

        if not isinstance(self.msg, Unset):
            files.append(("msg", (None, str(self.msg).encode(), "text/plain")))

        if not isinstance(self.running, Unset):
            files.append(("running", (None, str(self.running).encode(), "text/plain")))

        if not isinstance(self.total_recipes, Unset):
            files.append(("total_recipes", (None, str(self.total_recipes).encode(), "text/plain")))

        if not isinstance(self.exported_recipes, Unset):
            files.append(("exported_recipes", (None, str(self.exported_recipes).encode(), "text/plain")))

        if not isinstance(self.cache_duration, Unset):
            files.append(("cache_duration", (None, str(self.cache_duration).encode(), "text/plain")))

        if not isinstance(self.possibly_not_expired, Unset):
            files.append(("possibly_not_expired", (None, str(self.possibly_not_expired).encode(), "text/plain")))

        if not isinstance(self.created_by, Unset):
            files.append(("created_by", (None, str(self.created_by).encode(), "text/plain")))

        if not isinstance(self.created_at, Unset):
            files.append(("created_at", (None, self.created_at.isoformat().encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id", UNSET)

        type_ = d.pop("type", UNSET)

        msg = d.pop("msg", UNSET)

        running = d.pop("running", UNSET)

        total_recipes = d.pop("total_recipes", UNSET)

        exported_recipes = d.pop("exported_recipes", UNSET)

        cache_duration = d.pop("cache_duration", UNSET)

        possibly_not_expired = d.pop("possibly_not_expired", UNSET)

        created_by = d.pop("created_by", UNSET)

        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        patched_export_log = cls(
            id=id,
            type_=type_,
            msg=msg,
            running=running,
            total_recipes=total_recipes,
            exported_recipes=exported_recipes,
            cache_duration=cache_duration,
            possibly_not_expired=possibly_not_expired,
            created_by=created_by,
            created_at=created_at,
        )

        patched_export_log.additional_properties = d
        return patched_export_log

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
