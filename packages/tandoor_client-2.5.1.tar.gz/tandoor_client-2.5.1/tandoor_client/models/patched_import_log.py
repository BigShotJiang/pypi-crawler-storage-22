from __future__ import annotations

import datetime
import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.keyword import Keyword


T = TypeVar("T", bound="PatchedImportLog")


@_attrs_define
class PatchedImportLog:
    """
    Attributes:
        id (int | Unset):
        type_ (str | Unset):
        msg (str | Unset):
        running (bool | Unset):
        keyword (Keyword | Unset): Moves `UniqueValidator`'s from the validation stage to the save stage.
            It solves the problem with nested validation for unique fields on update.

            If you want more details, you can read related issues and articles:
            https://github.com/beda-software/drf-writable-nested/issues/1
            http://www.django-rest-framework.org/api-guide/validators/#updating-nested-serializers

            Example of usage:
            ```
                class Child(models.Model):
                field = models.CharField(unique=True)


            class Parent(models.Model):
                child = models.ForeignKey('Child')


            class ChildSerializer(UniqueFieldsMixin, serializers.ModelSerializer):
                class Meta:
                    model = Child


            class ParentSerializer(NestedUpdateMixin, serializers.ModelSerializer):
                child = ChildSerializer()

                class Meta:
                    model = Parent
            ```

            Note: `UniqueFieldsMixin` must be applied only on the serializer
            which has unique fields.

            Note: When you are using both mixins
            (`UniqueFieldsMixin` and `NestedCreateMixin` or `NestedUpdateMixin`)
            you should put `UniqueFieldsMixin` ahead.
        total_recipes (int | Unset):
        imported_recipes (int | Unset):
        created_by (int | Unset):
        created_at (datetime.datetime | Unset):
    """

    id: int | Unset = UNSET
    type_: str | Unset = UNSET
    msg: str | Unset = UNSET
    running: bool | Unset = UNSET
    keyword: Keyword | Unset = UNSET
    total_recipes: int | Unset = UNSET
    imported_recipes: int | Unset = UNSET
    created_by: int | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        type_ = self.type_

        msg = self.msg

        running = self.running

        keyword: dict[str, Any] | Unset = UNSET
        if not isinstance(self.keyword, Unset):
            keyword = self.keyword.to_dict()

        total_recipes = self.total_recipes

        imported_recipes = self.imported_recipes

        created_by = self.created_by

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if type_ is not UNSET:
            field_dict["type"] = type_
        if msg is not UNSET:
            field_dict["msg"] = msg
        if running is not UNSET:
            field_dict["running"] = running
        if keyword is not UNSET:
            field_dict["keyword"] = keyword
        if total_recipes is not UNSET:
            field_dict["total_recipes"] = total_recipes
        if imported_recipes is not UNSET:
            field_dict["imported_recipes"] = imported_recipes
        if created_by is not UNSET:
            field_dict["created_by"] = created_by
        if created_at is not UNSET:
            field_dict["created_at"] = created_at

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.type_, Unset):
            files.append(("type", (None, str(self.type_).encode(), "text/plain")))

        if not isinstance(self.msg, Unset):
            files.append(("msg", (None, str(self.msg).encode(), "text/plain")))

        if not isinstance(self.running, Unset):
            files.append(("running", (None, str(self.running).encode(), "text/plain")))

        if not isinstance(self.keyword, Unset):
            files.append(("keyword", (None, json.dumps(self.keyword.to_dict()).encode(), "application/json")))

        if not isinstance(self.total_recipes, Unset):
            files.append(("total_recipes", (None, str(self.total_recipes).encode(), "text/plain")))

        if not isinstance(self.imported_recipes, Unset):
            files.append(("imported_recipes", (None, str(self.imported_recipes).encode(), "text/plain")))

        if not isinstance(self.created_by, Unset):
            files.append(("created_by", (None, str(self.created_by).encode(), "text/plain")))

        if not isinstance(self.created_at, Unset):
            files.append(("created_at", (None, self.created_at.isoformat().encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.keyword import Keyword

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        type_ = d.pop("type", UNSET)

        msg = d.pop("msg", UNSET)

        running = d.pop("running", UNSET)

        _keyword = d.pop("keyword", UNSET)
        keyword: Keyword | Unset
        if isinstance(_keyword, Unset):
            keyword = UNSET
        else:
            keyword = Keyword.from_dict(_keyword)

        total_recipes = d.pop("total_recipes", UNSET)

        imported_recipes = d.pop("imported_recipes", UNSET)

        created_by = d.pop("created_by", UNSET)

        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        patched_import_log = cls(
            id=id,
            type_=type_,
            msg=msg,
            running=running,
            keyword=keyword,
            total_recipes=total_recipes,
            imported_recipes=imported_recipes,
            created_by=created_by,
            created_at=created_at,
        )

        patched_import_log.additional_properties = d
        return patched_import_log

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
