from __future__ import annotations

import datetime
import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.group import Group


T = TypeVar("T", bound="PatchedInviteLink")


@_attrs_define
class PatchedInviteLink:
    """Adds nested create feature

    Attributes:
        id (int | Unset):
        uuid (UUID | Unset):
        email (str | Unset):
        group (Group | Unset): Moves `UniqueValidator`'s from the validation stage to the save stage.
            It solves the problem with nested validation for unique fields on update.

            If you want more details, you can read related issues and articles:
            https://github.com/beda-software/drf-writable-nested/issues/1
            http://www.django-rest-framework.org/api-guide/validators/#updating-nested-serializers

            Example of usage:
            ```
                class Child(models.Model):
                field = models.CharField(unique=True)


            class Parent(models.Model):
                child = models.ForeignKey('Child')


            class ChildSerializer(UniqueFieldsMixin, serializers.ModelSerializer):
                class Meta:
                    model = Child


            class ParentSerializer(NestedUpdateMixin, serializers.ModelSerializer):
                child = ChildSerializer()

                class Meta:
                    model = Parent
            ```

            Note: `UniqueFieldsMixin` must be applied only on the serializer
            which has unique fields.

            Note: When you are using both mixins
            (`UniqueFieldsMixin` and `NestedCreateMixin` or `NestedUpdateMixin`)
            you should put `UniqueFieldsMixin` ahead.
        valid_until (datetime.date | Unset):
        used_by (int | None | Unset):
        reusable (bool | Unset):
        internal_note (None | str | Unset):
        created_by (int | Unset):
        created_at (datetime.datetime | Unset):
        email_sent (bool | Unset): Return whether the invite email was successfully sent.
    """

    id: int | Unset = UNSET
    uuid: UUID | Unset = UNSET
    email: str | Unset = UNSET
    group: Group | Unset = UNSET
    valid_until: datetime.date | Unset = UNSET
    used_by: int | None | Unset = UNSET
    reusable: bool | Unset = UNSET
    internal_note: None | str | Unset = UNSET
    created_by: int | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    email_sent: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        uuid: str | Unset = UNSET
        if not isinstance(self.uuid, Unset):
            uuid = str(self.uuid)

        email = self.email

        group: dict[str, Any] | Unset = UNSET
        if not isinstance(self.group, Unset):
            group = self.group.to_dict()

        valid_until: str | Unset = UNSET
        if not isinstance(self.valid_until, Unset):
            valid_until = self.valid_until.isoformat()

        used_by: int | None | Unset
        if isinstance(self.used_by, Unset):
            used_by = UNSET
        else:
            used_by = self.used_by

        reusable = self.reusable

        internal_note: None | str | Unset
        if isinstance(self.internal_note, Unset):
            internal_note = UNSET
        else:
            internal_note = self.internal_note

        created_by = self.created_by

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        email_sent = self.email_sent

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if uuid is not UNSET:
            field_dict["uuid"] = uuid
        if email is not UNSET:
            field_dict["email"] = email
        if group is not UNSET:
            field_dict["group"] = group
        if valid_until is not UNSET:
            field_dict["valid_until"] = valid_until
        if used_by is not UNSET:
            field_dict["used_by"] = used_by
        if reusable is not UNSET:
            field_dict["reusable"] = reusable
        if internal_note is not UNSET:
            field_dict["internal_note"] = internal_note
        if created_by is not UNSET:
            field_dict["created_by"] = created_by
        if created_at is not UNSET:
            field_dict["created_at"] = created_at
        if email_sent is not UNSET:
            field_dict["email_sent"] = email_sent

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.uuid, Unset):
            files.append(("uuid", (None, str(self.uuid), "text/plain")))

        if not isinstance(self.email, Unset):
            files.append(("email", (None, str(self.email).encode(), "text/plain")))

        if not isinstance(self.group, Unset):
            files.append(("group", (None, json.dumps(self.group.to_dict()).encode(), "application/json")))

        if not isinstance(self.valid_until, Unset):
            files.append(("valid_until", (None, self.valid_until.isoformat().encode(), "text/plain")))

        if not isinstance(self.used_by, Unset):
            if isinstance(self.used_by, int):
                files.append(("used_by", (None, str(self.used_by).encode(), "text/plain")))
            else:
                files.append(("used_by", (None, str(self.used_by).encode(), "text/plain")))

        if not isinstance(self.reusable, Unset):
            files.append(("reusable", (None, str(self.reusable).encode(), "text/plain")))

        if not isinstance(self.internal_note, Unset):
            if isinstance(self.internal_note, str):
                files.append(("internal_note", (None, str(self.internal_note).encode(), "text/plain")))
            else:
                files.append(("internal_note", (None, str(self.internal_note).encode(), "text/plain")))

        if not isinstance(self.created_by, Unset):
            files.append(("created_by", (None, str(self.created_by).encode(), "text/plain")))

        if not isinstance(self.created_at, Unset):
            files.append(("created_at", (None, self.created_at.isoformat().encode(), "text/plain")))

        if not isinstance(self.email_sent, Unset):
            files.append(("email_sent", (None, str(self.email_sent).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.group import Group

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        _uuid = d.pop("uuid", UNSET)
        uuid: UUID | Unset
        if isinstance(_uuid, Unset):
            uuid = UNSET
        else:
            uuid = UUID(_uuid)

        email = d.pop("email", UNSET)

        _group = d.pop("group", UNSET)
        group: Group | Unset
        if isinstance(_group, Unset):
            group = UNSET
        else:
            group = Group.from_dict(_group)

        _valid_until = d.pop("valid_until", UNSET)
        valid_until: datetime.date | Unset
        if isinstance(_valid_until, Unset):
            valid_until = UNSET
        else:
            valid_until = isoparse(_valid_until).date()

        def _parse_used_by(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        used_by = _parse_used_by(d.pop("used_by", UNSET))

        reusable = d.pop("reusable", UNSET)

        def _parse_internal_note(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        internal_note = _parse_internal_note(d.pop("internal_note", UNSET))

        created_by = d.pop("created_by", UNSET)

        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        email_sent = d.pop("email_sent", UNSET)

        patched_invite_link = cls(
            id=id,
            uuid=uuid,
            email=email,
            group=group,
            valid_until=valid_until,
            used_by=used_by,
            reusable=reusable,
            internal_note=internal_note,
            created_by=created_by,
            created_at=created_at,
            email_sent=email_sent,
        )

        patched_invite_link.additional_properties = d
        return patched_invite_link

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
