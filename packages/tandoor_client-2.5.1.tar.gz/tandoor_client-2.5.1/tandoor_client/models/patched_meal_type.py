from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="PatchedMealType")


@_attrs_define
class PatchedMealType:
    """Adds nested create feature

    Attributes:
        id (int | Unset):
        name (str | Unset):
        order (int | Unset):
        time (None | str | Unset):
        color (None | str | Unset):
        default (bool | Unset):
        created_by (int | Unset):
    """

    id: int | Unset = UNSET
    name: str | Unset = UNSET
    order: int | Unset = UNSET
    time: None | str | Unset = UNSET
    color: None | str | Unset = UNSET
    default: bool | Unset = UNSET
    created_by: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        order = self.order

        time: None | str | Unset
        if isinstance(self.time, Unset):
            time = UNSET
        else:
            time = self.time

        color: None | str | Unset
        if isinstance(self.color, Unset):
            color = UNSET
        else:
            color = self.color

        default = self.default

        created_by = self.created_by

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if name is not UNSET:
            field_dict["name"] = name
        if order is not UNSET:
            field_dict["order"] = order
        if time is not UNSET:
            field_dict["time"] = time
        if color is not UNSET:
            field_dict["color"] = color
        if default is not UNSET:
            field_dict["default"] = default
        if created_by is not UNSET:
            field_dict["created_by"] = created_by

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.name, Unset):
            files.append(("name", (None, str(self.name).encode(), "text/plain")))

        if not isinstance(self.order, Unset):
            files.append(("order", (None, str(self.order).encode(), "text/plain")))

        if not isinstance(self.time, Unset):
            if isinstance(self.time, str):
                files.append(("time", (None, str(self.time).encode(), "text/plain")))
            else:
                files.append(("time", (None, str(self.time).encode(), "text/plain")))

        if not isinstance(self.color, Unset):
            if isinstance(self.color, str):
                files.append(("color", (None, str(self.color).encode(), "text/plain")))
            else:
                files.append(("color", (None, str(self.color).encode(), "text/plain")))

        if not isinstance(self.default, Unset):
            files.append(("default", (None, str(self.default).encode(), "text/plain")))

        if not isinstance(self.created_by, Unset):
            files.append(("created_by", (None, str(self.created_by).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id", UNSET)

        name = d.pop("name", UNSET)

        order = d.pop("order", UNSET)

        def _parse_time(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        time = _parse_time(d.pop("time", UNSET))

        def _parse_color(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        color = _parse_color(d.pop("color", UNSET))

        default = d.pop("default", UNSET)

        created_by = d.pop("created_by", UNSET)

        patched_meal_type = cls(
            id=id,
            name=name,
            order=order,
            time=time,
            color=color,
            default=default,
            created_by=created_by,
        )

        patched_meal_type.additional_properties = d
        return patched_meal_type

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
