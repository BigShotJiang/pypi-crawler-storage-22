from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="PatchedPropertyType")


@_attrs_define
class PatchedPropertyType:
    """Adds nested create feature

    Attributes:
        id (int | Unset):
        name (str | Unset):
        unit (None | str | Unset):
        description (None | str | Unset):
        order (int | Unset):  Default: 0.
        open_data_slug (None | str | Unset):
        fdc_id (int | None | Unset):
    """

    id: int | Unset = UNSET
    name: str | Unset = UNSET
    unit: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    order: int | Unset = 0
    open_data_slug: None | str | Unset = UNSET
    fdc_id: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        unit: None | str | Unset
        if isinstance(self.unit, Unset):
            unit = UNSET
        else:
            unit = self.unit

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        order = self.order

        open_data_slug: None | str | Unset
        if isinstance(self.open_data_slug, Unset):
            open_data_slug = UNSET
        else:
            open_data_slug = self.open_data_slug

        fdc_id: int | None | Unset
        if isinstance(self.fdc_id, Unset):
            fdc_id = UNSET
        else:
            fdc_id = self.fdc_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if name is not UNSET:
            field_dict["name"] = name
        if unit is not UNSET:
            field_dict["unit"] = unit
        if description is not UNSET:
            field_dict["description"] = description
        if order is not UNSET:
            field_dict["order"] = order
        if open_data_slug is not UNSET:
            field_dict["open_data_slug"] = open_data_slug
        if fdc_id is not UNSET:
            field_dict["fdc_id"] = fdc_id

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.name, Unset):
            files.append(("name", (None, str(self.name).encode(), "text/plain")))

        if not isinstance(self.unit, Unset):
            if isinstance(self.unit, str):
                files.append(("unit", (None, str(self.unit).encode(), "text/plain")))
            else:
                files.append(("unit", (None, str(self.unit).encode(), "text/plain")))

        if not isinstance(self.description, Unset):
            if isinstance(self.description, str):
                files.append(("description", (None, str(self.description).encode(), "text/plain")))
            else:
                files.append(("description", (None, str(self.description).encode(), "text/plain")))

        if not isinstance(self.order, Unset):
            files.append(("order", (None, str(self.order).encode(), "text/plain")))

        if not isinstance(self.open_data_slug, Unset):
            if isinstance(self.open_data_slug, str):
                files.append(("open_data_slug", (None, str(self.open_data_slug).encode(), "text/plain")))
            else:
                files.append(("open_data_slug", (None, str(self.open_data_slug).encode(), "text/plain")))

        if not isinstance(self.fdc_id, Unset):
            if isinstance(self.fdc_id, int):
                files.append(("fdc_id", (None, str(self.fdc_id).encode(), "text/plain")))
            else:
                files.append(("fdc_id", (None, str(self.fdc_id).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id", UNSET)

        name = d.pop("name", UNSET)

        def _parse_unit(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        unit = _parse_unit(d.pop("unit", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        order = d.pop("order", UNSET)

        def _parse_open_data_slug(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        open_data_slug = _parse_open_data_slug(d.pop("open_data_slug", UNSET))

        def _parse_fdc_id(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        fdc_id = _parse_fdc_id(d.pop("fdc_id", UNSET))

        patched_property_type = cls(
            id=id,
            name=name,
            unit=unit,
            description=description,
            order=order,
            open_data_slug=open_data_slug,
            fdc_id=fdc_id,
        )

        patched_property_type.additional_properties = d
        return patched_property_type

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
