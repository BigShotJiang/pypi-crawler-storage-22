from __future__ import annotations

import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.custom_filter import CustomFilter
    from ..models.user import User


T = TypeVar("T", bound="PatchedRecipeBook")


@_attrs_define
class PatchedRecipeBook:
    """Adds nested create feature

    Attributes:
        id (int | Unset):
        name (str | Unset):
        description (str | Unset):
        shared (list[User] | Unset):
        created_by (User | Unset): Adds nested create feature
        filter_ (CustomFilter | None | Unset):
        order (int | Unset):
    """

    id: int | Unset = UNSET
    name: str | Unset = UNSET
    description: str | Unset = UNSET
    shared: list[User] | Unset = UNSET
    created_by: User | Unset = UNSET
    filter_: CustomFilter | None | Unset = UNSET
    order: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.custom_filter import CustomFilter

        id = self.id

        name = self.name

        description = self.description

        shared: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.shared, Unset):
            shared = []
            for shared_item_data in self.shared:
                shared_item = shared_item_data.to_dict()
                shared.append(shared_item)

        created_by: dict[str, Any] | Unset = UNSET
        if not isinstance(self.created_by, Unset):
            created_by = self.created_by.to_dict()

        filter_: dict[str, Any] | None | Unset
        if isinstance(self.filter_, Unset):
            filter_ = UNSET
        elif isinstance(self.filter_, CustomFilter):
            filter_ = self.filter_.to_dict()
        else:
            filter_ = self.filter_

        order = self.order

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if shared is not UNSET:
            field_dict["shared"] = shared
        if created_by is not UNSET:
            field_dict["created_by"] = created_by
        if filter_ is not UNSET:
            field_dict["filter"] = filter_
        if order is not UNSET:
            field_dict["order"] = order

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.name, Unset):
            files.append(("name", (None, str(self.name).encode(), "text/plain")))

        if not isinstance(self.description, Unset):
            files.append(("description", (None, str(self.description).encode(), "text/plain")))

        if not isinstance(self.shared, Unset):
            for shared_item_element in self.shared:
                files.append(("shared", (None, json.dumps(shared_item_element.to_dict()).encode(), "application/json")))

        if not isinstance(self.created_by, Unset):
            files.append(("created_by", (None, json.dumps(self.created_by.to_dict()).encode(), "application/json")))

        if not isinstance(self.filter_, Unset):
            if self.filter_ is None:
                files.append(("filter", (None, str(self.filter_).encode(), "text/plain")))
            else:
                files.append(("filter", (None, json.dumps(self.filter_.to_dict()).encode(), "application/json")))

        if not isinstance(self.order, Unset):
            files.append(("order", (None, str(self.order).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.custom_filter import CustomFilter
        from ..models.user import User

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        name = d.pop("name", UNSET)

        description = d.pop("description", UNSET)

        _shared = d.pop("shared", UNSET)
        shared: list[User] | Unset = UNSET
        if _shared is not UNSET:
            shared = []
            for shared_item_data in _shared:
                shared_item = User.from_dict(shared_item_data)

                shared.append(shared_item)

        _created_by = d.pop("created_by", UNSET)
        created_by: User | Unset
        if isinstance(_created_by, Unset):
            created_by = UNSET
        else:
            created_by = User.from_dict(_created_by)

        def _parse_filter_(data: object) -> CustomFilter | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                filter_type_1 = CustomFilter.from_dict(data)

                return filter_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CustomFilter | None | Unset, data)

        filter_ = _parse_filter_(d.pop("filter", UNSET))

        order = d.pop("order", UNSET)

        patched_recipe_book = cls(
            id=id,
            name=name,
            description=description,
            shared=shared,
            created_by=created_by,
            filter_=filter_,
            order=order,
        )

        patched_recipe_book.additional_properties = d
        return patched_recipe_book

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
