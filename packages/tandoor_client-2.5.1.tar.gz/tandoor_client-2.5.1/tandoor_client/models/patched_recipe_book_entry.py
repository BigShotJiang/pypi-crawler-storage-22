from __future__ import annotations

import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.recipe_book import RecipeBook
    from ..models.recipe_overview import RecipeOverview


T = TypeVar("T", bound="PatchedRecipeBookEntry")


@_attrs_define
class PatchedRecipeBookEntry:
    """
    Attributes:
        id (int | Unset):
        book (int | Unset):
        book_content (RecipeBook | Unset): Adds nested create feature
        recipe (int | Unset):
        recipe_content (RecipeOverview | Unset): Adds nested create feature
    """

    id: int | Unset = UNSET
    book: int | Unset = UNSET
    book_content: RecipeBook | Unset = UNSET
    recipe: int | Unset = UNSET
    recipe_content: RecipeOverview | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        book = self.book

        book_content: dict[str, Any] | Unset = UNSET
        if not isinstance(self.book_content, Unset):
            book_content = self.book_content.to_dict()

        recipe = self.recipe

        recipe_content: dict[str, Any] | Unset = UNSET
        if not isinstance(self.recipe_content, Unset):
            recipe_content = self.recipe_content.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if book is not UNSET:
            field_dict["book"] = book
        if book_content is not UNSET:
            field_dict["book_content"] = book_content
        if recipe is not UNSET:
            field_dict["recipe"] = recipe
        if recipe_content is not UNSET:
            field_dict["recipe_content"] = recipe_content

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.book, Unset):
            files.append(("book", (None, str(self.book).encode(), "text/plain")))

        if not isinstance(self.book_content, Unset):
            files.append(("book_content", (None, json.dumps(self.book_content.to_dict()).encode(), "application/json")))

        if not isinstance(self.recipe, Unset):
            files.append(("recipe", (None, str(self.recipe).encode(), "text/plain")))

        if not isinstance(self.recipe_content, Unset):
            files.append(
                ("recipe_content", (None, json.dumps(self.recipe_content.to_dict()).encode(), "application/json"))
            )

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.recipe_book import RecipeBook
        from ..models.recipe_overview import RecipeOverview

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        book = d.pop("book", UNSET)

        _book_content = d.pop("book_content", UNSET)
        book_content: RecipeBook | Unset
        if isinstance(_book_content, Unset):
            book_content = UNSET
        else:
            book_content = RecipeBook.from_dict(_book_content)

        recipe = d.pop("recipe", UNSET)

        _recipe_content = d.pop("recipe_content", UNSET)
        recipe_content: RecipeOverview | Unset
        if isinstance(_recipe_content, Unset):
            recipe_content = UNSET
        else:
            recipe_content = RecipeOverview.from_dict(_recipe_content)

        patched_recipe_book_entry = cls(
            id=id,
            book=book,
            book_content=book_content,
            recipe=recipe,
            recipe_content=recipe_content,
        )

        patched_recipe_book_entry.additional_properties = d
        return patched_recipe_book_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
