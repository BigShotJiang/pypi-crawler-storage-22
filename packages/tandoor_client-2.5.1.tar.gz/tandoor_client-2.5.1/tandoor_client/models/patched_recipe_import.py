from __future__ import annotations

import datetime
import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.storage import Storage


T = TypeVar("T", bound="PatchedRecipeImport")


@_attrs_define
class PatchedRecipeImport:
    """Adds nested create feature

    Attributes:
        id (int | Unset):
        storage (Storage | Unset): Adds nested create feature
        name (str | Unset):
        file_uid (str | Unset):
        file_path (str | Unset):
        created_at (datetime.datetime | Unset):
    """

    id: int | Unset = UNSET
    storage: Storage | Unset = UNSET
    name: str | Unset = UNSET
    file_uid: str | Unset = UNSET
    file_path: str | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        storage: dict[str, Any] | Unset = UNSET
        if not isinstance(self.storage, Unset):
            storage = self.storage.to_dict()

        name = self.name

        file_uid = self.file_uid

        file_path = self.file_path

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if storage is not UNSET:
            field_dict["storage"] = storage
        if name is not UNSET:
            field_dict["name"] = name
        if file_uid is not UNSET:
            field_dict["file_uid"] = file_uid
        if file_path is not UNSET:
            field_dict["file_path"] = file_path
        if created_at is not UNSET:
            field_dict["created_at"] = created_at

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.storage, Unset):
            files.append(("storage", (None, json.dumps(self.storage.to_dict()).encode(), "application/json")))

        if not isinstance(self.name, Unset):
            files.append(("name", (None, str(self.name).encode(), "text/plain")))

        if not isinstance(self.file_uid, Unset):
            files.append(("file_uid", (None, str(self.file_uid).encode(), "text/plain")))

        if not isinstance(self.file_path, Unset):
            files.append(("file_path", (None, str(self.file_path).encode(), "text/plain")))

        if not isinstance(self.created_at, Unset):
            files.append(("created_at", (None, self.created_at.isoformat().encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.storage import Storage

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        _storage = d.pop("storage", UNSET)
        storage: Storage | Unset
        if isinstance(_storage, Unset):
            storage = UNSET
        else:
            storage = Storage.from_dict(_storage)

        name = d.pop("name", UNSET)

        file_uid = d.pop("file_uid", UNSET)

        file_path = d.pop("file_path", UNSET)

        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        patched_recipe_import = cls(
            id=id,
            storage=storage,
            name=name,
            file_uid=file_uid,
            file_path=file_path,
            created_at=created_at,
        )

        patched_recipe_import.additional_properties = d
        return patched_recipe_import

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
