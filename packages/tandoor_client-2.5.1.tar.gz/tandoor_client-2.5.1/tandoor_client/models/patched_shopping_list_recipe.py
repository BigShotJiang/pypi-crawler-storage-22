from __future__ import annotations

import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.meal_plan import MealPlan
    from ..models.recipe_overview import RecipeOverview
    from ..models.user import User


T = TypeVar("T", bound="PatchedShoppingListRecipe")


@_attrs_define
class PatchedShoppingListRecipe:
    """
    Attributes:
        id (int | Unset):
        name (str | Unset):
        recipe (int | None | Unset):
        recipe_data (RecipeOverview | Unset): Adds nested create feature
        meal_plan_data (MealPlan | Unset): Adds nested create feature
        mealplan (int | None | Unset):
        servings (float | Unset):
        created_by (User | Unset): Adds nested create feature
    """

    id: int | Unset = UNSET
    name: str | Unset = UNSET
    recipe: int | None | Unset = UNSET
    recipe_data: RecipeOverview | Unset = UNSET
    meal_plan_data: MealPlan | Unset = UNSET
    mealplan: int | None | Unset = UNSET
    servings: float | Unset = UNSET
    created_by: User | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        recipe: int | None | Unset
        if isinstance(self.recipe, Unset):
            recipe = UNSET
        else:
            recipe = self.recipe

        recipe_data: dict[str, Any] | Unset = UNSET
        if not isinstance(self.recipe_data, Unset):
            recipe_data = self.recipe_data.to_dict()

        meal_plan_data: dict[str, Any] | Unset = UNSET
        if not isinstance(self.meal_plan_data, Unset):
            meal_plan_data = self.meal_plan_data.to_dict()

        mealplan: int | None | Unset
        if isinstance(self.mealplan, Unset):
            mealplan = UNSET
        else:
            mealplan = self.mealplan

        servings = self.servings

        created_by: dict[str, Any] | Unset = UNSET
        if not isinstance(self.created_by, Unset):
            created_by = self.created_by.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if name is not UNSET:
            field_dict["name"] = name
        if recipe is not UNSET:
            field_dict["recipe"] = recipe
        if recipe_data is not UNSET:
            field_dict["recipe_data"] = recipe_data
        if meal_plan_data is not UNSET:
            field_dict["meal_plan_data"] = meal_plan_data
        if mealplan is not UNSET:
            field_dict["mealplan"] = mealplan
        if servings is not UNSET:
            field_dict["servings"] = servings
        if created_by is not UNSET:
            field_dict["created_by"] = created_by

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.name, Unset):
            files.append(("name", (None, str(self.name).encode(), "text/plain")))

        if not isinstance(self.recipe, Unset):
            if isinstance(self.recipe, int):
                files.append(("recipe", (None, str(self.recipe).encode(), "text/plain")))
            else:
                files.append(("recipe", (None, str(self.recipe).encode(), "text/plain")))

        if not isinstance(self.recipe_data, Unset):
            files.append(("recipe_data", (None, json.dumps(self.recipe_data.to_dict()).encode(), "application/json")))

        if not isinstance(self.meal_plan_data, Unset):
            files.append(
                ("meal_plan_data", (None, json.dumps(self.meal_plan_data.to_dict()).encode(), "application/json"))
            )

        if not isinstance(self.mealplan, Unset):
            if isinstance(self.mealplan, int):
                files.append(("mealplan", (None, str(self.mealplan).encode(), "text/plain")))
            else:
                files.append(("mealplan", (None, str(self.mealplan).encode(), "text/plain")))

        if not isinstance(self.servings, Unset):
            files.append(("servings", (None, str(self.servings).encode(), "text/plain")))

        if not isinstance(self.created_by, Unset):
            files.append(("created_by", (None, json.dumps(self.created_by.to_dict()).encode(), "application/json")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.meal_plan import MealPlan
        from ..models.recipe_overview import RecipeOverview
        from ..models.user import User

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        name = d.pop("name", UNSET)

        def _parse_recipe(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        recipe = _parse_recipe(d.pop("recipe", UNSET))

        _recipe_data = d.pop("recipe_data", UNSET)
        recipe_data: RecipeOverview | Unset
        if isinstance(_recipe_data, Unset):
            recipe_data = UNSET
        else:
            recipe_data = RecipeOverview.from_dict(_recipe_data)

        _meal_plan_data = d.pop("meal_plan_data", UNSET)
        meal_plan_data: MealPlan | Unset
        if isinstance(_meal_plan_data, Unset):
            meal_plan_data = UNSET
        else:
            meal_plan_data = MealPlan.from_dict(_meal_plan_data)

        def _parse_mealplan(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        mealplan = _parse_mealplan(d.pop("mealplan", UNSET))

        servings = d.pop("servings", UNSET)

        _created_by = d.pop("created_by", UNSET)
        created_by: User | Unset
        if isinstance(_created_by, Unset):
            created_by = UNSET
        else:
            created_by = User.from_dict(_created_by)

        patched_shopping_list_recipe = cls(
            id=id,
            name=name,
            recipe=recipe,
            recipe_data=recipe_data,
            meal_plan_data=meal_plan_data,
            mealplan=mealplan,
            servings=servings,
            created_by=created_by,
        )

        patched_shopping_list_recipe.additional_properties = d
        return patched_shopping_list_recipe

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
