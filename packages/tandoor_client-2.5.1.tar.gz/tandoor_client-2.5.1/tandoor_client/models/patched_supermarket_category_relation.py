from __future__ import annotations

import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.supermarket_category import SupermarketCategory


T = TypeVar("T", bound="PatchedSupermarketCategoryRelation")


@_attrs_define
class PatchedSupermarketCategoryRelation:
    """Adds nested create feature

    Attributes:
        id (int | Unset):
        category (SupermarketCategory | Unset): Moves `UniqueValidator`'s from the validation stage to the save stage.
            It solves the problem with nested validation for unique fields on update.

            If you want more details, you can read related issues and articles:
            https://github.com/beda-software/drf-writable-nested/issues/1
            http://www.django-rest-framework.org/api-guide/validators/#updating-nested-serializers

            Example of usage:
            ```
                class Child(models.Model):
                field = models.CharField(unique=True)


            class Parent(models.Model):
                child = models.ForeignKey('Child')


            class ChildSerializer(UniqueFieldsMixin, serializers.ModelSerializer):
                class Meta:
                    model = Child


            class ParentSerializer(NestedUpdateMixin, serializers.ModelSerializer):
                child = ChildSerializer()

                class Meta:
                    model = Parent
            ```

            Note: `UniqueFieldsMixin` must be applied only on the serializer
            which has unique fields.

            Note: When you are using both mixins
            (`UniqueFieldsMixin` and `NestedCreateMixin` or `NestedUpdateMixin`)
            you should put `UniqueFieldsMixin` ahead.
        supermarket (int | Unset):
        order (int | Unset):
    """

    id: int | Unset = UNSET
    category: SupermarketCategory | Unset = UNSET
    supermarket: int | Unset = UNSET
    order: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        category: dict[str, Any] | Unset = UNSET
        if not isinstance(self.category, Unset):
            category = self.category.to_dict()

        supermarket = self.supermarket

        order = self.order

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if category is not UNSET:
            field_dict["category"] = category
        if supermarket is not UNSET:
            field_dict["supermarket"] = supermarket
        if order is not UNSET:
            field_dict["order"] = order

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.category, Unset):
            files.append(("category", (None, json.dumps(self.category.to_dict()).encode(), "application/json")))

        if not isinstance(self.supermarket, Unset):
            files.append(("supermarket", (None, str(self.supermarket).encode(), "text/plain")))

        if not isinstance(self.order, Unset):
            files.append(("order", (None, str(self.order).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.supermarket_category import SupermarketCategory

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        _category = d.pop("category", UNSET)
        category: SupermarketCategory | Unset
        if isinstance(_category, Unset):
            category = UNSET
        else:
            category = SupermarketCategory.from_dict(_category)

        supermarket = d.pop("supermarket", UNSET)

        order = d.pop("order", UNSET)

        patched_supermarket_category_relation = cls(
            id=id,
            category=category,
            supermarket=supermarket,
            order=order,
        )

        patched_supermarket_category_relation.additional_properties = d
        return patched_supermarket_category_relation

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
