from __future__ import annotations

import datetime
import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.storage import Storage


T = TypeVar("T", bound="PatchedSync")


@_attrs_define
class PatchedSync:
    """Adds nested create feature

    Attributes:
        id (int | Unset):
        storage (Storage | Unset): Adds nested create feature
        path (str | Unset):
        active (bool | Unset):
        last_checked (datetime.datetime | None | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
    """

    id: int | Unset = UNSET
    storage: Storage | Unset = UNSET
    path: str | Unset = UNSET
    active: bool | Unset = UNSET
    last_checked: datetime.datetime | None | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        storage: dict[str, Any] | Unset = UNSET
        if not isinstance(self.storage, Unset):
            storage = self.storage.to_dict()

        path = self.path

        active = self.active

        last_checked: None | str | Unset
        if isinstance(self.last_checked, Unset):
            last_checked = UNSET
        elif isinstance(self.last_checked, datetime.datetime):
            last_checked = self.last_checked.isoformat()
        else:
            last_checked = self.last_checked

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if storage is not UNSET:
            field_dict["storage"] = storage
        if path is not UNSET:
            field_dict["path"] = path
        if active is not UNSET:
            field_dict["active"] = active
        if last_checked is not UNSET:
            field_dict["last_checked"] = last_checked
        if created_at is not UNSET:
            field_dict["created_at"] = created_at
        if updated_at is not UNSET:
            field_dict["updated_at"] = updated_at

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.storage, Unset):
            files.append(("storage", (None, json.dumps(self.storage.to_dict()).encode(), "application/json")))

        if not isinstance(self.path, Unset):
            files.append(("path", (None, str(self.path).encode(), "text/plain")))

        if not isinstance(self.active, Unset):
            files.append(("active", (None, str(self.active).encode(), "text/plain")))

        if not isinstance(self.last_checked, Unset):
            if isinstance(self.last_checked, datetime.datetime):
                files.append(("last_checked", (None, self.last_checked.isoformat().encode(), "text/plain")))
            else:
                files.append(("last_checked", (None, str(self.last_checked).encode(), "text/plain")))

        if not isinstance(self.created_at, Unset):
            files.append(("created_at", (None, self.created_at.isoformat().encode(), "text/plain")))

        if not isinstance(self.updated_at, Unset):
            files.append(("updated_at", (None, self.updated_at.isoformat().encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.storage import Storage

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        _storage = d.pop("storage", UNSET)
        storage: Storage | Unset
        if isinstance(_storage, Unset):
            storage = UNSET
        else:
            storage = Storage.from_dict(_storage)

        path = d.pop("path", UNSET)

        active = d.pop("active", UNSET)

        def _parse_last_checked(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_checked_type_0 = isoparse(data)

                return last_checked_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_checked = _parse_last_checked(d.pop("last_checked", UNSET))

        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updated_at", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        patched_sync = cls(
            id=id,
            storage=storage,
            path=path,
            active=active,
            last_checked=last_checked,
            created_at=created_at,
            updated_at=updated_at,
        )

        patched_sync.additional_properties = d
        return patched_sync

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
