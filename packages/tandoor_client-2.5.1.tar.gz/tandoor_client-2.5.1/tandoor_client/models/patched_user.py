from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="PatchedUser")


@_attrs_define
class PatchedUser:
    """Adds nested create feature

    Attributes:
        id (int | Unset):
        username (str | Unset): Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only.
        first_name (str | Unset):
        last_name (str | Unset):
        display_name (str | Unset):
        is_staff (bool | Unset): Designates whether the user can log into this admin site.
        is_superuser (bool | Unset): Designates that this user has all permissions without explicitly assigning them.
        is_active (bool | Unset): Designates whether this user should be treated as active. Unselect this instead of
            deleting accounts.
    """

    id: int | Unset = UNSET
    username: str | Unset = UNSET
    first_name: str | Unset = UNSET
    last_name: str | Unset = UNSET
    display_name: str | Unset = UNSET
    is_staff: bool | Unset = UNSET
    is_superuser: bool | Unset = UNSET
    is_active: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        username = self.username

        first_name = self.first_name

        last_name = self.last_name

        display_name = self.display_name

        is_staff = self.is_staff

        is_superuser = self.is_superuser

        is_active = self.is_active

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if username is not UNSET:
            field_dict["username"] = username
        if first_name is not UNSET:
            field_dict["first_name"] = first_name
        if last_name is not UNSET:
            field_dict["last_name"] = last_name
        if display_name is not UNSET:
            field_dict["display_name"] = display_name
        if is_staff is not UNSET:
            field_dict["is_staff"] = is_staff
        if is_superuser is not UNSET:
            field_dict["is_superuser"] = is_superuser
        if is_active is not UNSET:
            field_dict["is_active"] = is_active

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.username, Unset):
            files.append(("username", (None, str(self.username).encode(), "text/plain")))

        if not isinstance(self.first_name, Unset):
            files.append(("first_name", (None, str(self.first_name).encode(), "text/plain")))

        if not isinstance(self.last_name, Unset):
            files.append(("last_name", (None, str(self.last_name).encode(), "text/plain")))

        if not isinstance(self.display_name, Unset):
            files.append(("display_name", (None, str(self.display_name).encode(), "text/plain")))

        if not isinstance(self.is_staff, Unset):
            files.append(("is_staff", (None, str(self.is_staff).encode(), "text/plain")))

        if not isinstance(self.is_superuser, Unset):
            files.append(("is_superuser", (None, str(self.is_superuser).encode(), "text/plain")))

        if not isinstance(self.is_active, Unset):
            files.append(("is_active", (None, str(self.is_active).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id", UNSET)

        username = d.pop("username", UNSET)

        first_name = d.pop("first_name", UNSET)

        last_name = d.pop("last_name", UNSET)

        display_name = d.pop("display_name", UNSET)

        is_staff = d.pop("is_staff", UNSET)

        is_superuser = d.pop("is_superuser", UNSET)

        is_active = d.pop("is_active", UNSET)

        patched_user = cls(
            id=id,
            username=username,
            first_name=first_name,
            last_name=last_name,
            display_name=display_name,
            is_staff=is_staff,
            is_superuser=is_superuser,
            is_active=is_active,
        )

        patched_user.additional_properties = d
        return patched_user

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
