from __future__ import annotations

import datetime
import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.user import User


T = TypeVar("T", bound="PatchedUserFile")


@_attrs_define
class PatchedUserFile:
    """
    Attributes:
        id (int | Unset):
        name (str | Unset):
        file (str | Unset):
        file_download (str | Unset):
        preview (str | Unset):
        file_size_kb (int | Unset):
        created_by (User | Unset): Adds nested create feature
        created_at (datetime.datetime | Unset):
    """

    id: int | Unset = UNSET
    name: str | Unset = UNSET
    file: str | Unset = UNSET
    file_download: str | Unset = UNSET
    preview: str | Unset = UNSET
    file_size_kb: int | Unset = UNSET
    created_by: User | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        file = self.file

        file_download = self.file_download

        preview = self.preview

        file_size_kb = self.file_size_kb

        created_by: dict[str, Any] | Unset = UNSET
        if not isinstance(self.created_by, Unset):
            created_by = self.created_by.to_dict()

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if name is not UNSET:
            field_dict["name"] = name
        if file is not UNSET:
            field_dict["file"] = file
        if file_download is not UNSET:
            field_dict["file_download"] = file_download
        if preview is not UNSET:
            field_dict["preview"] = preview
        if file_size_kb is not UNSET:
            field_dict["file_size_kb"] = file_size_kb
        if created_by is not UNSET:
            field_dict["created_by"] = created_by
        if created_at is not UNSET:
            field_dict["created_at"] = created_at

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.name, Unset):
            files.append(("name", (None, str(self.name).encode(), "text/plain")))

        if not isinstance(self.file, Unset):
            files.append(("file", (None, str(self.file).encode(), "text/plain")))

        if not isinstance(self.file_download, Unset):
            files.append(("file_download", (None, str(self.file_download).encode(), "text/plain")))

        if not isinstance(self.preview, Unset):
            files.append(("preview", (None, str(self.preview).encode(), "text/plain")))

        if not isinstance(self.file_size_kb, Unset):
            files.append(("file_size_kb", (None, str(self.file_size_kb).encode(), "text/plain")))

        if not isinstance(self.created_by, Unset):
            files.append(("created_by", (None, json.dumps(self.created_by.to_dict()).encode(), "application/json")))

        if not isinstance(self.created_at, Unset):
            files.append(("created_at", (None, self.created_at.isoformat().encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user import User

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        name = d.pop("name", UNSET)

        file = d.pop("file", UNSET)

        file_download = d.pop("file_download", UNSET)

        preview = d.pop("preview", UNSET)

        file_size_kb = d.pop("file_size_kb", UNSET)

        _created_by = d.pop("created_by", UNSET)
        created_by: User | Unset
        if isinstance(_created_by, Unset):
            created_by = UNSET
        else:
            created_by = User.from_dict(_created_by)

        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        patched_user_file = cls(
            id=id,
            name=name,
            file=file,
            file_download=file_download,
            preview=preview,
            file_size_kb=file_size_kb,
            created_by=created_by,
            created_at=created_at,
        )

        patched_user_file.additional_properties = d
        return patched_user_file

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
