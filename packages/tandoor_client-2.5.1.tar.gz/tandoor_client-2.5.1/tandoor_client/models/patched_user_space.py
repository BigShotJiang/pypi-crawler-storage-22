from __future__ import annotations

import datetime
import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.group import Group
    from ..models.user import User


T = TypeVar("T", bound="PatchedUserSpace")


@_attrs_define
class PatchedUserSpace:
    """Adds nested create feature

    Attributes:
        id (int | Unset):
        user (User | Unset): Adds nested create feature
        space (int | Unset):
        groups (list[Group] | Unset):
        active (bool | Unset):
        internal_note (None | str | Unset):
        invite_link (int | None | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
    """

    id: int | Unset = UNSET
    user: User | Unset = UNSET
    space: int | Unset = UNSET
    groups: list[Group] | Unset = UNSET
    active: bool | Unset = UNSET
    internal_note: None | str | Unset = UNSET
    invite_link: int | None | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        user: dict[str, Any] | Unset = UNSET
        if not isinstance(self.user, Unset):
            user = self.user.to_dict()

        space = self.space

        groups: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.groups, Unset):
            groups = []
            for groups_item_data in self.groups:
                groups_item = groups_item_data.to_dict()
                groups.append(groups_item)

        active = self.active

        internal_note: None | str | Unset
        if isinstance(self.internal_note, Unset):
            internal_note = UNSET
        else:
            internal_note = self.internal_note

        invite_link: int | None | Unset
        if isinstance(self.invite_link, Unset):
            invite_link = UNSET
        else:
            invite_link = self.invite_link

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if user is not UNSET:
            field_dict["user"] = user
        if space is not UNSET:
            field_dict["space"] = space
        if groups is not UNSET:
            field_dict["groups"] = groups
        if active is not UNSET:
            field_dict["active"] = active
        if internal_note is not UNSET:
            field_dict["internal_note"] = internal_note
        if invite_link is not UNSET:
            field_dict["invite_link"] = invite_link
        if created_at is not UNSET:
            field_dict["created_at"] = created_at
        if updated_at is not UNSET:
            field_dict["updated_at"] = updated_at

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.user, Unset):
            files.append(("user", (None, json.dumps(self.user.to_dict()).encode(), "application/json")))

        if not isinstance(self.space, Unset):
            files.append(("space", (None, str(self.space).encode(), "text/plain")))

        if not isinstance(self.groups, Unset):
            for groups_item_element in self.groups:
                files.append(("groups", (None, json.dumps(groups_item_element.to_dict()).encode(), "application/json")))

        if not isinstance(self.active, Unset):
            files.append(("active", (None, str(self.active).encode(), "text/plain")))

        if not isinstance(self.internal_note, Unset):
            if isinstance(self.internal_note, str):
                files.append(("internal_note", (None, str(self.internal_note).encode(), "text/plain")))
            else:
                files.append(("internal_note", (None, str(self.internal_note).encode(), "text/plain")))

        if not isinstance(self.invite_link, Unset):
            if isinstance(self.invite_link, int):
                files.append(("invite_link", (None, str(self.invite_link).encode(), "text/plain")))
            else:
                files.append(("invite_link", (None, str(self.invite_link).encode(), "text/plain")))

        if not isinstance(self.created_at, Unset):
            files.append(("created_at", (None, self.created_at.isoformat().encode(), "text/plain")))

        if not isinstance(self.updated_at, Unset):
            files.append(("updated_at", (None, self.updated_at.isoformat().encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.group import Group
        from ..models.user import User

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        _user = d.pop("user", UNSET)
        user: User | Unset
        if isinstance(_user, Unset):
            user = UNSET
        else:
            user = User.from_dict(_user)

        space = d.pop("space", UNSET)

        _groups = d.pop("groups", UNSET)
        groups: list[Group] | Unset = UNSET
        if _groups is not UNSET:
            groups = []
            for groups_item_data in _groups:
                groups_item = Group.from_dict(groups_item_data)

                groups.append(groups_item)

        active = d.pop("active", UNSET)

        def _parse_internal_note(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        internal_note = _parse_internal_note(d.pop("internal_note", UNSET))

        def _parse_invite_link(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        invite_link = _parse_invite_link(d.pop("invite_link", UNSET))

        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updated_at", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        patched_user_space = cls(
            id=id,
            user=user,
            space=space,
            groups=groups,
            active=active,
            internal_note=internal_note,
            invite_link=invite_link,
            created_at=created_at,
            updated_at=updated_at,
        )

        patched_user_space.additional_properties = d
        return patched_user_space

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
