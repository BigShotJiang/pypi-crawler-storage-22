from __future__ import annotations

import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.property_type import PropertyType


T = TypeVar("T", bound="Property")


@_attrs_define
class Property:
    """Moves `UniqueValidator`'s from the validation stage to the save stage.
    It solves the problem with nested validation for unique fields on update.

    If you want more details, you can read related issues and articles:
    https://github.com/beda-software/drf-writable-nested/issues/1
    http://www.django-rest-framework.org/api-guide/validators/#updating-nested-serializers

    Example of usage:
    ```
        class Child(models.Model):
        field = models.CharField(unique=True)


    class Parent(models.Model):
        child = models.ForeignKey('Child')


    class ChildSerializer(UniqueFieldsMixin, serializers.ModelSerializer):
        class Meta:
            model = Child


    class ParentSerializer(NestedUpdateMixin, serializers.ModelSerializer):
        child = ChildSerializer()

        class Meta:
            model = Parent
    ```

    Note: `UniqueFieldsMixin` must be applied only on the serializer
    which has unique fields.

    Note: When you are using both mixins
    (`UniqueFieldsMixin` and `NestedCreateMixin` or `NestedUpdateMixin`)
    you should put `UniqueFieldsMixin` ahead.

        Attributes:
            property_amount (float | None):
            property_type (PropertyType): Adds nested create feature
            id (int | Unset):
    """

    property_amount: float | None
    property_type: PropertyType
    id: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        property_amount: float | None
        property_amount = self.property_amount

        property_type = self.property_type.to_dict()

        id = self.id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "property_amount": property_amount,
                "property_type": property_type,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if isinstance(self.property_amount, float):
            files.append(("property_amount", (None, str(self.property_amount).encode(), "text/plain")))
        else:
            files.append(("property_amount", (None, str(self.property_amount).encode(), "text/plain")))

        files.append(("property_type", (None, json.dumps(self.property_type.to_dict()).encode(), "application/json")))

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.property_type import PropertyType

        d = dict(src_dict)

        def _parse_property_amount(data: object) -> float | None:
            if data is None:
                return data
            return cast(float | None, data)

        property_amount = _parse_property_amount(d.pop("property_amount"))

        property_type = PropertyType.from_dict(d.pop("property_type"))

        id = d.pop("id", UNSET)

        property_ = cls(
            property_amount=property_amount,
            property_type=property_type,
            id=id,
        )

        property_.additional_properties = d
        return property_

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
