from __future__ import annotations

import datetime
import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.keyword import Keyword
    from ..models.nutrition_information import NutritionInformation
    from ..models.property_ import Property
    from ..models.step import Step
    from ..models.user import User


T = TypeVar("T", bound="Recipe")


@_attrs_define
class Recipe:
    """Adds nested create feature

    Attributes:
        name (str):
        image (None | str):
        steps (list[Step]):
        created_by (User): Adds nested create feature
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        food_properties (Any):
        rating (float | None):
        last_cooked (datetime.datetime | None):
        id (int | Unset):
        description (None | str | Unset):
        keywords (list[Keyword] | Unset):
        working_time (int | Unset):
        waiting_time (int | Unset):
        source_url (None | str | Unset):
        internal (bool | Unset):
        show_ingredient_overview (bool | Unset):
        nutrition (None | NutritionInformation | Unset):
        properties (list[Property] | Unset):
        servings (int | Unset):
        file_path (str | Unset):
        servings_text (str | Unset):
        diameter (int | Unset):
        diameter_text (str | Unset):
        private (bool | Unset):
        shared (list[User] | Unset):
    """

    name: str
    image: None | str
    steps: list[Step]
    created_by: User
    created_at: datetime.datetime
    updated_at: datetime.datetime
    food_properties: Any
    rating: float | None
    last_cooked: datetime.datetime | None
    id: int | Unset = UNSET
    description: None | str | Unset = UNSET
    keywords: list[Keyword] | Unset = UNSET
    working_time: int | Unset = UNSET
    waiting_time: int | Unset = UNSET
    source_url: None | str | Unset = UNSET
    internal: bool | Unset = UNSET
    show_ingredient_overview: bool | Unset = UNSET
    nutrition: None | NutritionInformation | Unset = UNSET
    properties: list[Property] | Unset = UNSET
    servings: int | Unset = UNSET
    file_path: str | Unset = UNSET
    servings_text: str | Unset = UNSET
    diameter: int | Unset = UNSET
    diameter_text: str | Unset = UNSET
    private: bool | Unset = UNSET
    shared: list[User] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.nutrition_information import NutritionInformation

        name = self.name

        image: None | str
        image = self.image

        steps = []
        for steps_item_data in self.steps:
            steps_item = steps_item_data.to_dict()
            steps.append(steps_item)

        created_by = self.created_by.to_dict()

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        food_properties = self.food_properties

        rating: float | None
        rating = self.rating

        last_cooked: None | str
        if isinstance(self.last_cooked, datetime.datetime):
            last_cooked = self.last_cooked.isoformat()
        else:
            last_cooked = self.last_cooked

        id = self.id

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        keywords: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.keywords, Unset):
            keywords = []
            for keywords_item_data in self.keywords:
                keywords_item = keywords_item_data.to_dict()
                keywords.append(keywords_item)

        working_time = self.working_time

        waiting_time = self.waiting_time

        source_url: None | str | Unset
        if isinstance(self.source_url, Unset):
            source_url = UNSET
        else:
            source_url = self.source_url

        internal = self.internal

        show_ingredient_overview = self.show_ingredient_overview

        nutrition: dict[str, Any] | None | Unset
        if isinstance(self.nutrition, Unset):
            nutrition = UNSET
        elif isinstance(self.nutrition, NutritionInformation):
            nutrition = self.nutrition.to_dict()
        else:
            nutrition = self.nutrition

        properties: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.properties, Unset):
            properties = []
            for properties_item_data in self.properties:
                properties_item = properties_item_data.to_dict()
                properties.append(properties_item)

        servings = self.servings

        file_path = self.file_path

        servings_text = self.servings_text

        diameter = self.diameter

        diameter_text = self.diameter_text

        private = self.private

        shared: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.shared, Unset):
            shared = []
            for shared_item_data in self.shared:
                shared_item = shared_item_data.to_dict()
                shared.append(shared_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "image": image,
                "steps": steps,
                "created_by": created_by,
                "created_at": created_at,
                "updated_at": updated_at,
                "food_properties": food_properties,
                "rating": rating,
                "last_cooked": last_cooked,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if description is not UNSET:
            field_dict["description"] = description
        if keywords is not UNSET:
            field_dict["keywords"] = keywords
        if working_time is not UNSET:
            field_dict["working_time"] = working_time
        if waiting_time is not UNSET:
            field_dict["waiting_time"] = waiting_time
        if source_url is not UNSET:
            field_dict["source_url"] = source_url
        if internal is not UNSET:
            field_dict["internal"] = internal
        if show_ingredient_overview is not UNSET:
            field_dict["show_ingredient_overview"] = show_ingredient_overview
        if nutrition is not UNSET:
            field_dict["nutrition"] = nutrition
        if properties is not UNSET:
            field_dict["properties"] = properties
        if servings is not UNSET:
            field_dict["servings"] = servings
        if file_path is not UNSET:
            field_dict["file_path"] = file_path
        if servings_text is not UNSET:
            field_dict["servings_text"] = servings_text
        if diameter is not UNSET:
            field_dict["diameter"] = diameter
        if diameter_text is not UNSET:
            field_dict["diameter_text"] = diameter_text
        if private is not UNSET:
            field_dict["private"] = private
        if shared is not UNSET:
            field_dict["shared"] = shared

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("name", (None, str(self.name).encode(), "text/plain")))

        if isinstance(self.image, str):
            files.append(("image", (None, str(self.image).encode(), "text/plain")))
        else:
            files.append(("image", (None, str(self.image).encode(), "text/plain")))

        for steps_item_element in self.steps:
            files.append(("steps", (None, json.dumps(steps_item_element.to_dict()).encode(), "application/json")))

        files.append(("created_by", (None, json.dumps(self.created_by.to_dict()).encode(), "application/json")))

        files.append(("created_at", (None, self.created_at.isoformat().encode(), "text/plain")))

        files.append(("updated_at", (None, self.updated_at.isoformat().encode(), "text/plain")))

        files.append(("food_properties", (None, str(self.food_properties).encode(), "text/plain")))

        if isinstance(self.rating, float):
            files.append(("rating", (None, str(self.rating).encode(), "text/plain")))
        else:
            files.append(("rating", (None, str(self.rating).encode(), "text/plain")))

        if isinstance(self.last_cooked, datetime.datetime):
            files.append(("last_cooked", (None, self.last_cooked.isoformat().encode(), "text/plain")))
        else:
            files.append(("last_cooked", (None, str(self.last_cooked).encode(), "text/plain")))

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.description, Unset):
            if isinstance(self.description, str):
                files.append(("description", (None, str(self.description).encode(), "text/plain")))
            else:
                files.append(("description", (None, str(self.description).encode(), "text/plain")))

        if not isinstance(self.keywords, Unset):
            for keywords_item_element in self.keywords:
                files.append(
                    ("keywords", (None, json.dumps(keywords_item_element.to_dict()).encode(), "application/json"))
                )

        if not isinstance(self.working_time, Unset):
            files.append(("working_time", (None, str(self.working_time).encode(), "text/plain")))

        if not isinstance(self.waiting_time, Unset):
            files.append(("waiting_time", (None, str(self.waiting_time).encode(), "text/plain")))

        if not isinstance(self.source_url, Unset):
            if isinstance(self.source_url, str):
                files.append(("source_url", (None, str(self.source_url).encode(), "text/plain")))
            else:
                files.append(("source_url", (None, str(self.source_url).encode(), "text/plain")))

        if not isinstance(self.internal, Unset):
            files.append(("internal", (None, str(self.internal).encode(), "text/plain")))

        if not isinstance(self.show_ingredient_overview, Unset):
            files.append(
                ("show_ingredient_overview", (None, str(self.show_ingredient_overview).encode(), "text/plain"))
            )

        if not isinstance(self.nutrition, Unset):
            if self.nutrition is None:
                files.append(("nutrition", (None, str(self.nutrition).encode(), "text/plain")))
            else:
                files.append(("nutrition", (None, json.dumps(self.nutrition.to_dict()).encode(), "application/json")))

        if not isinstance(self.properties, Unset):
            for properties_item_element in self.properties:
                files.append(
                    ("properties", (None, json.dumps(properties_item_element.to_dict()).encode(), "application/json"))
                )

        if not isinstance(self.servings, Unset):
            files.append(("servings", (None, str(self.servings).encode(), "text/plain")))

        if not isinstance(self.file_path, Unset):
            files.append(("file_path", (None, str(self.file_path).encode(), "text/plain")))

        if not isinstance(self.servings_text, Unset):
            files.append(("servings_text", (None, str(self.servings_text).encode(), "text/plain")))

        if not isinstance(self.diameter, Unset):
            files.append(("diameter", (None, str(self.diameter).encode(), "text/plain")))

        if not isinstance(self.diameter_text, Unset):
            files.append(("diameter_text", (None, str(self.diameter_text).encode(), "text/plain")))

        if not isinstance(self.private, Unset):
            files.append(("private", (None, str(self.private).encode(), "text/plain")))

        if not isinstance(self.shared, Unset):
            for shared_item_element in self.shared:
                files.append(("shared", (None, json.dumps(shared_item_element.to_dict()).encode(), "application/json")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.keyword import Keyword
        from ..models.nutrition_information import NutritionInformation
        from ..models.property_ import Property
        from ..models.step import Step
        from ..models.user import User

        d = dict(src_dict)
        name = d.pop("name")

        def _parse_image(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        image = _parse_image(d.pop("image"))

        steps = []
        _steps = d.pop("steps")
        for steps_item_data in _steps:
            steps_item = Step.from_dict(steps_item_data)

            steps.append(steps_item)

        created_by = User.from_dict(d.pop("created_by"))

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        food_properties = d.pop("food_properties")

        def _parse_rating(data: object) -> float | None:
            if data is None:
                return data
            return cast(float | None, data)

        rating = _parse_rating(d.pop("rating"))

        def _parse_last_cooked(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_cooked_type_0 = isoparse(data)

                return last_cooked_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        last_cooked = _parse_last_cooked(d.pop("last_cooked"))

        id = d.pop("id", UNSET)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        _keywords = d.pop("keywords", UNSET)
        keywords: list[Keyword] | Unset = UNSET
        if _keywords is not UNSET:
            keywords = []
            for keywords_item_data in _keywords:
                keywords_item = Keyword.from_dict(keywords_item_data)

                keywords.append(keywords_item)

        working_time = d.pop("working_time", UNSET)

        waiting_time = d.pop("waiting_time", UNSET)

        def _parse_source_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        source_url = _parse_source_url(d.pop("source_url", UNSET))

        internal = d.pop("internal", UNSET)

        show_ingredient_overview = d.pop("show_ingredient_overview", UNSET)

        def _parse_nutrition(data: object) -> None | NutritionInformation | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                nutrition_type_1 = NutritionInformation.from_dict(data)

                return nutrition_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | NutritionInformation | Unset, data)

        nutrition = _parse_nutrition(d.pop("nutrition", UNSET))

        _properties = d.pop("properties", UNSET)
        properties: list[Property] | Unset = UNSET
        if _properties is not UNSET:
            properties = []
            for properties_item_data in _properties:
                properties_item = Property.from_dict(properties_item_data)

                properties.append(properties_item)

        servings = d.pop("servings", UNSET)

        file_path = d.pop("file_path", UNSET)

        servings_text = d.pop("servings_text", UNSET)

        diameter = d.pop("diameter", UNSET)

        diameter_text = d.pop("diameter_text", UNSET)

        private = d.pop("private", UNSET)

        _shared = d.pop("shared", UNSET)
        shared: list[User] | Unset = UNSET
        if _shared is not UNSET:
            shared = []
            for shared_item_data in _shared:
                shared_item = User.from_dict(shared_item_data)

                shared.append(shared_item)

        recipe = cls(
            name=name,
            image=image,
            steps=steps,
            created_by=created_by,
            created_at=created_at,
            updated_at=updated_at,
            food_properties=food_properties,
            rating=rating,
            last_cooked=last_cooked,
            id=id,
            description=description,
            keywords=keywords,
            working_time=working_time,
            waiting_time=waiting_time,
            source_url=source_url,
            internal=internal,
            show_ingredient_overview=show_ingredient_overview,
            nutrition=nutrition,
            properties=properties,
            servings=servings,
            file_path=file_path,
            servings_text=servings_text,
            diameter=diameter,
            diameter_text=diameter_text,
            private=private,
            shared=shared,
        )

        recipe.additional_properties = d
        return recipe

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
