from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="RecipeBatchUpdate")


@_attrs_define
class RecipeBatchUpdate:
    """
    Attributes:
        recipes (list[int]):
        keywords_add (list[int]):
        keywords_remove (list[int]):
        keywords_set (list[int]):
        shared_add (list[int]):
        shared_remove (list[int]):
        shared_set (list[int]):
        keywords_remove_all (bool | Unset):  Default: False.
        working_time (int | None | Unset):
        waiting_time (int | None | Unset):
        servings (int | None | Unset):
        servings_text (None | str | Unset):
        private (bool | None | Unset):
        shared_remove_all (bool | Unset):  Default: False.
        show_ingredient_overview (bool | None | Unset):
        clear_description (bool | None | Unset):
    """

    recipes: list[int]
    keywords_add: list[int]
    keywords_remove: list[int]
    keywords_set: list[int]
    shared_add: list[int]
    shared_remove: list[int]
    shared_set: list[int]
    keywords_remove_all: bool | Unset = False
    working_time: int | None | Unset = UNSET
    waiting_time: int | None | Unset = UNSET
    servings: int | None | Unset = UNSET
    servings_text: None | str | Unset = UNSET
    private: bool | None | Unset = UNSET
    shared_remove_all: bool | Unset = False
    show_ingredient_overview: bool | None | Unset = UNSET
    clear_description: bool | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        recipes = self.recipes

        keywords_add = self.keywords_add

        keywords_remove = self.keywords_remove

        keywords_set = self.keywords_set

        shared_add = self.shared_add

        shared_remove = self.shared_remove

        shared_set = self.shared_set

        keywords_remove_all = self.keywords_remove_all

        working_time: int | None | Unset
        if isinstance(self.working_time, Unset):
            working_time = UNSET
        else:
            working_time = self.working_time

        waiting_time: int | None | Unset
        if isinstance(self.waiting_time, Unset):
            waiting_time = UNSET
        else:
            waiting_time = self.waiting_time

        servings: int | None | Unset
        if isinstance(self.servings, Unset):
            servings = UNSET
        else:
            servings = self.servings

        servings_text: None | str | Unset
        if isinstance(self.servings_text, Unset):
            servings_text = UNSET
        else:
            servings_text = self.servings_text

        private: bool | None | Unset
        if isinstance(self.private, Unset):
            private = UNSET
        else:
            private = self.private

        shared_remove_all = self.shared_remove_all

        show_ingredient_overview: bool | None | Unset
        if isinstance(self.show_ingredient_overview, Unset):
            show_ingredient_overview = UNSET
        else:
            show_ingredient_overview = self.show_ingredient_overview

        clear_description: bool | None | Unset
        if isinstance(self.clear_description, Unset):
            clear_description = UNSET
        else:
            clear_description = self.clear_description

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "recipes": recipes,
                "keywords_add": keywords_add,
                "keywords_remove": keywords_remove,
                "keywords_set": keywords_set,
                "shared_add": shared_add,
                "shared_remove": shared_remove,
                "shared_set": shared_set,
            }
        )
        if keywords_remove_all is not UNSET:
            field_dict["keywords_remove_all"] = keywords_remove_all
        if working_time is not UNSET:
            field_dict["working_time"] = working_time
        if waiting_time is not UNSET:
            field_dict["waiting_time"] = waiting_time
        if servings is not UNSET:
            field_dict["servings"] = servings
        if servings_text is not UNSET:
            field_dict["servings_text"] = servings_text
        if private is not UNSET:
            field_dict["private"] = private
        if shared_remove_all is not UNSET:
            field_dict["shared_remove_all"] = shared_remove_all
        if show_ingredient_overview is not UNSET:
            field_dict["show_ingredient_overview"] = show_ingredient_overview
        if clear_description is not UNSET:
            field_dict["clear_description"] = clear_description

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        for recipes_item_element in self.recipes:
            files.append(("recipes", (None, str(recipes_item_element).encode(), "text/plain")))

        for keywords_add_item_element in self.keywords_add:
            files.append(("keywords_add", (None, str(keywords_add_item_element).encode(), "text/plain")))

        for keywords_remove_item_element in self.keywords_remove:
            files.append(("keywords_remove", (None, str(keywords_remove_item_element).encode(), "text/plain")))

        for keywords_set_item_element in self.keywords_set:
            files.append(("keywords_set", (None, str(keywords_set_item_element).encode(), "text/plain")))

        for shared_add_item_element in self.shared_add:
            files.append(("shared_add", (None, str(shared_add_item_element).encode(), "text/plain")))

        for shared_remove_item_element in self.shared_remove:
            files.append(("shared_remove", (None, str(shared_remove_item_element).encode(), "text/plain")))

        for shared_set_item_element in self.shared_set:
            files.append(("shared_set", (None, str(shared_set_item_element).encode(), "text/plain")))

        if not isinstance(self.keywords_remove_all, Unset):
            files.append(("keywords_remove_all", (None, str(self.keywords_remove_all).encode(), "text/plain")))

        if not isinstance(self.working_time, Unset):
            if isinstance(self.working_time, int):
                files.append(("working_time", (None, str(self.working_time).encode(), "text/plain")))
            else:
                files.append(("working_time", (None, str(self.working_time).encode(), "text/plain")))

        if not isinstance(self.waiting_time, Unset):
            if isinstance(self.waiting_time, int):
                files.append(("waiting_time", (None, str(self.waiting_time).encode(), "text/plain")))
            else:
                files.append(("waiting_time", (None, str(self.waiting_time).encode(), "text/plain")))

        if not isinstance(self.servings, Unset):
            if isinstance(self.servings, int):
                files.append(("servings", (None, str(self.servings).encode(), "text/plain")))
            else:
                files.append(("servings", (None, str(self.servings).encode(), "text/plain")))

        if not isinstance(self.servings_text, Unset):
            if isinstance(self.servings_text, str):
                files.append(("servings_text", (None, str(self.servings_text).encode(), "text/plain")))
            else:
                files.append(("servings_text", (None, str(self.servings_text).encode(), "text/plain")))

        if not isinstance(self.private, Unset):
            if isinstance(self.private, bool):
                files.append(("private", (None, str(self.private).encode(), "text/plain")))
            else:
                files.append(("private", (None, str(self.private).encode(), "text/plain")))

        if not isinstance(self.shared_remove_all, Unset):
            files.append(("shared_remove_all", (None, str(self.shared_remove_all).encode(), "text/plain")))

        if not isinstance(self.show_ingredient_overview, Unset):
            if isinstance(self.show_ingredient_overview, bool):
                files.append(
                    ("show_ingredient_overview", (None, str(self.show_ingredient_overview).encode(), "text/plain"))
                )
            else:
                files.append(
                    ("show_ingredient_overview", (None, str(self.show_ingredient_overview).encode(), "text/plain"))
                )

        if not isinstance(self.clear_description, Unset):
            if isinstance(self.clear_description, bool):
                files.append(("clear_description", (None, str(self.clear_description).encode(), "text/plain")))
            else:
                files.append(("clear_description", (None, str(self.clear_description).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        recipes = cast(list[int], d.pop("recipes"))

        keywords_add = cast(list[int], d.pop("keywords_add"))

        keywords_remove = cast(list[int], d.pop("keywords_remove"))

        keywords_set = cast(list[int], d.pop("keywords_set"))

        shared_add = cast(list[int], d.pop("shared_add"))

        shared_remove = cast(list[int], d.pop("shared_remove"))

        shared_set = cast(list[int], d.pop("shared_set"))

        keywords_remove_all = d.pop("keywords_remove_all", UNSET)

        def _parse_working_time(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        working_time = _parse_working_time(d.pop("working_time", UNSET))

        def _parse_waiting_time(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        waiting_time = _parse_waiting_time(d.pop("waiting_time", UNSET))

        def _parse_servings(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        servings = _parse_servings(d.pop("servings", UNSET))

        def _parse_servings_text(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        servings_text = _parse_servings_text(d.pop("servings_text", UNSET))

        def _parse_private(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        private = _parse_private(d.pop("private", UNSET))

        shared_remove_all = d.pop("shared_remove_all", UNSET)

        def _parse_show_ingredient_overview(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_ingredient_overview = _parse_show_ingredient_overview(d.pop("show_ingredient_overview", UNSET))

        def _parse_clear_description(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        clear_description = _parse_clear_description(d.pop("clear_description", UNSET))

        recipe_batch_update = cls(
            recipes=recipes,
            keywords_add=keywords_add,
            keywords_remove=keywords_remove,
            keywords_set=keywords_set,
            shared_add=shared_add,
            shared_remove=shared_remove,
            shared_set=shared_set,
            keywords_remove_all=keywords_remove_all,
            working_time=working_time,
            waiting_time=waiting_time,
            servings=servings,
            servings_text=servings_text,
            private=private,
            shared_remove_all=shared_remove_all,
            show_ingredient_overview=show_ingredient_overview,
            clear_description=clear_description,
        )

        recipe_batch_update.additional_properties = d
        return recipe_batch_update

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
