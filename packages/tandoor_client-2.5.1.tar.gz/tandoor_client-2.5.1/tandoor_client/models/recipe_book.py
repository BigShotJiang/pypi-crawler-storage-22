from __future__ import annotations

import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.custom_filter import CustomFilter
    from ..models.user import User


T = TypeVar("T", bound="RecipeBook")


@_attrs_define
class RecipeBook:
    """Adds nested create feature

    Attributes:
        name (str):
        shared (list[User]):
        created_by (User): Adds nested create feature
        id (int | Unset):
        description (str | Unset):
        filter_ (CustomFilter | None | Unset):
        order (int | Unset):
    """

    name: str
    shared: list[User]
    created_by: User
    id: int | Unset = UNSET
    description: str | Unset = UNSET
    filter_: CustomFilter | None | Unset = UNSET
    order: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.custom_filter import CustomFilter

        name = self.name

        shared = []
        for shared_item_data in self.shared:
            shared_item = shared_item_data.to_dict()
            shared.append(shared_item)

        created_by = self.created_by.to_dict()

        id = self.id

        description = self.description

        filter_: dict[str, Any] | None | Unset
        if isinstance(self.filter_, Unset):
            filter_ = UNSET
        elif isinstance(self.filter_, CustomFilter):
            filter_ = self.filter_.to_dict()
        else:
            filter_ = self.filter_

        order = self.order

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "shared": shared,
                "created_by": created_by,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if description is not UNSET:
            field_dict["description"] = description
        if filter_ is not UNSET:
            field_dict["filter"] = filter_
        if order is not UNSET:
            field_dict["order"] = order

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("name", (None, str(self.name).encode(), "text/plain")))

        for shared_item_element in self.shared:
            files.append(("shared", (None, json.dumps(shared_item_element.to_dict()).encode(), "application/json")))

        files.append(("created_by", (None, json.dumps(self.created_by.to_dict()).encode(), "application/json")))

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.description, Unset):
            files.append(("description", (None, str(self.description).encode(), "text/plain")))

        if not isinstance(self.filter_, Unset):
            if self.filter_ is None:
                files.append(("filter", (None, str(self.filter_).encode(), "text/plain")))
            else:
                files.append(("filter", (None, json.dumps(self.filter_.to_dict()).encode(), "application/json")))

        if not isinstance(self.order, Unset):
            files.append(("order", (None, str(self.order).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.custom_filter import CustomFilter
        from ..models.user import User

        d = dict(src_dict)
        name = d.pop("name")

        shared = []
        _shared = d.pop("shared")
        for shared_item_data in _shared:
            shared_item = User.from_dict(shared_item_data)

            shared.append(shared_item)

        created_by = User.from_dict(d.pop("created_by"))

        id = d.pop("id", UNSET)

        description = d.pop("description", UNSET)

        def _parse_filter_(data: object) -> CustomFilter | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                filter_type_1 = CustomFilter.from_dict(data)

                return filter_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CustomFilter | None | Unset, data)

        filter_ = _parse_filter_(d.pop("filter", UNSET))

        order = d.pop("order", UNSET)

        recipe_book = cls(
            name=name,
            shared=shared,
            created_by=created_by,
            id=id,
            description=description,
            filter_=filter_,
            order=order,
        )

        recipe_book.additional_properties = d
        return recipe_book

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
