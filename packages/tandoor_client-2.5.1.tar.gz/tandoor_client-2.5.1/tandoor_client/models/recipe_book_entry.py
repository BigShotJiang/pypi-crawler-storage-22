from __future__ import annotations

import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.recipe_book import RecipeBook
    from ..models.recipe_overview import RecipeOverview


T = TypeVar("T", bound="RecipeBookEntry")


@_attrs_define
class RecipeBookEntry:
    """
    Attributes:
        book (int):
        book_content (RecipeBook): Adds nested create feature
        recipe (int):
        recipe_content (RecipeOverview): Adds nested create feature
        id (int | Unset):
    """

    book: int
    book_content: RecipeBook
    recipe: int
    recipe_content: RecipeOverview
    id: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        book = self.book

        book_content = self.book_content.to_dict()

        recipe = self.recipe

        recipe_content = self.recipe_content.to_dict()

        id = self.id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "book": book,
                "book_content": book_content,
                "recipe": recipe,
                "recipe_content": recipe_content,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("book", (None, str(self.book).encode(), "text/plain")))

        files.append(("book_content", (None, json.dumps(self.book_content.to_dict()).encode(), "application/json")))

        files.append(("recipe", (None, str(self.recipe).encode(), "text/plain")))

        files.append(("recipe_content", (None, json.dumps(self.recipe_content.to_dict()).encode(), "application/json")))

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.recipe_book import RecipeBook
        from ..models.recipe_overview import RecipeOverview

        d = dict(src_dict)
        book = d.pop("book")

        book_content = RecipeBook.from_dict(d.pop("book_content"))

        recipe = d.pop("recipe")

        recipe_content = RecipeOverview.from_dict(d.pop("recipe_content"))

        id = d.pop("id", UNSET)

        recipe_book_entry = cls(
            book=book,
            book_content=book_content,
            recipe=recipe,
            recipe_content=recipe_content,
            id=id,
        )

        recipe_book_entry.additional_properties = d
        return recipe_book_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
