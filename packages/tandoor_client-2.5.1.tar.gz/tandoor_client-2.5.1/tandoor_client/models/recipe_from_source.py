from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="RecipeFromSource")


@_attrs_define
class RecipeFromSource:
    """
    Attributes:
        url (None | str | Unset):
        data (None | str | Unset):
        bookmarklet (int | None | Unset):
    """

    url: None | str | Unset = UNSET
    data: None | str | Unset = UNSET
    bookmarklet: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        url: None | str | Unset
        if isinstance(self.url, Unset):
            url = UNSET
        else:
            url = self.url

        data: None | str | Unset
        if isinstance(self.data, Unset):
            data = UNSET
        else:
            data = self.data

        bookmarklet: int | None | Unset
        if isinstance(self.bookmarklet, Unset):
            bookmarklet = UNSET
        else:
            bookmarklet = self.bookmarklet

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if url is not UNSET:
            field_dict["url"] = url
        if data is not UNSET:
            field_dict["data"] = data
        if bookmarklet is not UNSET:
            field_dict["bookmarklet"] = bookmarklet

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.url, Unset):
            if isinstance(self.url, str):
                files.append(("url", (None, str(self.url).encode(), "text/plain")))
            else:
                files.append(("url", (None, str(self.url).encode(), "text/plain")))

        if not isinstance(self.data, Unset):
            if isinstance(self.data, str):
                files.append(("data", (None, str(self.data).encode(), "text/plain")))
            else:
                files.append(("data", (None, str(self.data).encode(), "text/plain")))

        if not isinstance(self.bookmarklet, Unset):
            if isinstance(self.bookmarklet, int):
                files.append(("bookmarklet", (None, str(self.bookmarklet).encode(), "text/plain")))
            else:
                files.append(("bookmarklet", (None, str(self.bookmarklet).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        url = _parse_url(d.pop("url", UNSET))

        def _parse_data(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        data = _parse_data(d.pop("data", UNSET))

        def _parse_bookmarklet(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        bookmarklet = _parse_bookmarklet(d.pop("bookmarklet", UNSET))

        recipe_from_source = cls(
            url=url,
            data=data,
            bookmarklet=bookmarklet,
        )

        recipe_from_source.additional_properties = d
        return recipe_from_source

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
