from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.source_import_duplicate import SourceImportDuplicate
    from ..models.source_import_recipe import SourceImportRecipe


T = TypeVar("T", bound="RecipeFromSourceResponse")


@_attrs_define
class RecipeFromSourceResponse:
    """
    Attributes:
        recipe (SourceImportRecipe | Unset):
        recipe_id (int | Unset):
        images (list[str] | Unset):
        error (bool | Unset):  Default: False.
        msg (str | Unset):  Default: ''.
        duplicates (list[SourceImportDuplicate] | Unset):
    """

    recipe: SourceImportRecipe | Unset = UNSET
    recipe_id: int | Unset = UNSET
    images: list[str] | Unset = UNSET
    error: bool | Unset = False
    msg: str | Unset = ""
    duplicates: list[SourceImportDuplicate] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        recipe: dict[str, Any] | Unset = UNSET
        if not isinstance(self.recipe, Unset):
            recipe = self.recipe.to_dict()

        recipe_id = self.recipe_id

        images: list[str] | Unset = UNSET
        if not isinstance(self.images, Unset):
            images = self.images

        error = self.error

        msg = self.msg

        duplicates: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.duplicates, Unset):
            duplicates = []
            for duplicates_item_data in self.duplicates:
                duplicates_item = duplicates_item_data.to_dict()
                duplicates.append(duplicates_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if recipe is not UNSET:
            field_dict["recipe"] = recipe
        if recipe_id is not UNSET:
            field_dict["recipe_id"] = recipe_id
        if images is not UNSET:
            field_dict["images"] = images
        if error is not UNSET:
            field_dict["error"] = error
        if msg is not UNSET:
            field_dict["msg"] = msg
        if duplicates is not UNSET:
            field_dict["duplicates"] = duplicates

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.source_import_duplicate import SourceImportDuplicate
        from ..models.source_import_recipe import SourceImportRecipe

        d = dict(src_dict)
        _recipe = d.pop("recipe", UNSET)
        recipe: SourceImportRecipe | Unset
        if isinstance(_recipe, Unset):
            recipe = UNSET
        else:
            recipe = SourceImportRecipe.from_dict(_recipe)

        recipe_id = d.pop("recipe_id", UNSET)

        images = cast(list[str], d.pop("images", UNSET))

        error = d.pop("error", UNSET)

        msg = d.pop("msg", UNSET)

        _duplicates = d.pop("duplicates", UNSET)
        duplicates: list[SourceImportDuplicate] | Unset = UNSET
        if _duplicates is not UNSET:
            duplicates = []
            for duplicates_item_data in _duplicates:
                duplicates_item = SourceImportDuplicate.from_dict(duplicates_item_data)

                duplicates.append(duplicates_item)

        recipe_from_source_response = cls(
            recipe=recipe,
            recipe_id=recipe_id,
            images=images,
            error=error,
            msg=msg,
            duplicates=duplicates,
        )

        recipe_from_source_response.additional_properties = d
        return recipe_from_source_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
