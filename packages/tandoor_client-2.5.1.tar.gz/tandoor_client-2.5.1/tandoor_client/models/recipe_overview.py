from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.keyword_label import KeywordLabel
    from ..models.user import User


T = TypeVar("T", bound="RecipeOverview")


@_attrs_define
class RecipeOverview:
    """Adds nested create feature

    Attributes:
        name (str):
        image (None | str):
        keywords (list[KeywordLabel]):
        working_time (int):
        waiting_time (int):
        created_by (User): Adds nested create feature
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        internal (bool):
        servings (int):
        servings_text (str):
        rating (float | None):
        last_cooked (datetime.datetime | None):
        new (bool):
        recent (str):
        id (int | Unset):
        description (None | str | Unset):
        private (bool | Unset):
    """

    name: str
    image: None | str
    keywords: list[KeywordLabel]
    working_time: int
    waiting_time: int
    created_by: User
    created_at: datetime.datetime
    updated_at: datetime.datetime
    internal: bool
    servings: int
    servings_text: str
    rating: float | None
    last_cooked: datetime.datetime | None
    new: bool
    recent: str
    id: int | Unset = UNSET
    description: None | str | Unset = UNSET
    private: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        image: None | str
        image = self.image

        keywords = []
        for keywords_item_data in self.keywords:
            keywords_item = keywords_item_data.to_dict()
            keywords.append(keywords_item)

        working_time = self.working_time

        waiting_time = self.waiting_time

        created_by = self.created_by.to_dict()

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        internal = self.internal

        servings = self.servings

        servings_text = self.servings_text

        rating: float | None
        rating = self.rating

        last_cooked: None | str
        if isinstance(self.last_cooked, datetime.datetime):
            last_cooked = self.last_cooked.isoformat()
        else:
            last_cooked = self.last_cooked

        new = self.new

        recent = self.recent

        id = self.id

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        private = self.private

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "image": image,
                "keywords": keywords,
                "working_time": working_time,
                "waiting_time": waiting_time,
                "created_by": created_by,
                "created_at": created_at,
                "updated_at": updated_at,
                "internal": internal,
                "servings": servings,
                "servings_text": servings_text,
                "rating": rating,
                "last_cooked": last_cooked,
                "new": new,
                "recent": recent,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if description is not UNSET:
            field_dict["description"] = description
        if private is not UNSET:
            field_dict["private"] = private

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.keyword_label import KeywordLabel
        from ..models.user import User

        d = dict(src_dict)
        name = d.pop("name")

        def _parse_image(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        image = _parse_image(d.pop("image"))

        keywords = []
        _keywords = d.pop("keywords")
        for keywords_item_data in _keywords:
            keywords_item = KeywordLabel.from_dict(keywords_item_data)

            keywords.append(keywords_item)

        working_time = d.pop("working_time")

        waiting_time = d.pop("waiting_time")

        created_by = User.from_dict(d.pop("created_by"))

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        internal = d.pop("internal")

        servings = d.pop("servings")

        servings_text = d.pop("servings_text")

        def _parse_rating(data: object) -> float | None:
            if data is None:
                return data
            return cast(float | None, data)

        rating = _parse_rating(d.pop("rating"))

        def _parse_last_cooked(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_cooked_type_0 = isoparse(data)

                return last_cooked_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        last_cooked = _parse_last_cooked(d.pop("last_cooked"))

        new = d.pop("new")

        recent = d.pop("recent")

        id = d.pop("id", UNSET)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        private = d.pop("private", UNSET)

        recipe_overview = cls(
            name=name,
            image=image,
            keywords=keywords,
            working_time=working_time,
            waiting_time=waiting_time,
            created_by=created_by,
            created_at=created_at,
            updated_at=updated_at,
            internal=internal,
            servings=servings,
            servings_text=servings_text,
            rating=rating,
            last_cooked=last_cooked,
            new=new,
            recent=recent,
            id=id,
            description=description,
            private=private,
        )

        recipe_overview.additional_properties = d
        return recipe_overview

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
