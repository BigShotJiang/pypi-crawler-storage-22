from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="RecipeShoppingUpdate")


@_attrs_define
class RecipeShoppingUpdate:
    """
    Attributes:
        ingredients (list[int | None]):
        id (int | Unset):
        list_recipe (int | None | Unset): Existing shopping list to update
        servings (int | None | Unset): Providing a list_recipe ID and servings of 0 will delete that shopping list.
            Default: 1.
    """

    ingredients: list[int | None]
    id: int | Unset = UNSET
    list_recipe: int | None | Unset = UNSET
    servings: int | None | Unset = 1
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        ingredients = []
        for ingredients_item_data in self.ingredients:
            ingredients_item: int | None
            ingredients_item = ingredients_item_data
            ingredients.append(ingredients_item)

        id = self.id

        list_recipe: int | None | Unset
        if isinstance(self.list_recipe, Unset):
            list_recipe = UNSET
        else:
            list_recipe = self.list_recipe

        servings: int | None | Unset
        if isinstance(self.servings, Unset):
            servings = UNSET
        else:
            servings = self.servings

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "ingredients": ingredients,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if list_recipe is not UNSET:
            field_dict["list_recipe"] = list_recipe
        if servings is not UNSET:
            field_dict["servings"] = servings

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        for ingredients_item_element in self.ingredients:
            if isinstance(ingredients_item_element, int):
                files.append(("ingredients", (None, str(ingredients_item_element).encode(), "text/plain")))
            else:
                files.append(("ingredients", (None, str(ingredients_item_element).encode(), "text/plain")))

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.list_recipe, Unset):
            if isinstance(self.list_recipe, int):
                files.append(("list_recipe", (None, str(self.list_recipe).encode(), "text/plain")))
            else:
                files.append(("list_recipe", (None, str(self.list_recipe).encode(), "text/plain")))

        if not isinstance(self.servings, Unset):
            if isinstance(self.servings, int):
                files.append(("servings", (None, str(self.servings).encode(), "text/plain")))
            else:
                files.append(("servings", (None, str(self.servings).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        ingredients = []
        _ingredients = d.pop("ingredients")
        for ingredients_item_data in _ingredients:

            def _parse_ingredients_item(data: object) -> int | None:
                if data is None:
                    return data
                return cast(int | None, data)

            ingredients_item = _parse_ingredients_item(ingredients_item_data)

            ingredients.append(ingredients_item)

        id = d.pop("id", UNSET)

        def _parse_list_recipe(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        list_recipe = _parse_list_recipe(d.pop("list_recipe", UNSET))

        def _parse_servings(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        servings = _parse_servings(d.pop("servings", UNSET))

        recipe_shopping_update = cls(
            ingredients=ingredients,
            id=id,
            list_recipe=list_recipe,
            servings=servings,
        )

        recipe_shopping_update.additional_properties = d
        return recipe_shopping_update

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
