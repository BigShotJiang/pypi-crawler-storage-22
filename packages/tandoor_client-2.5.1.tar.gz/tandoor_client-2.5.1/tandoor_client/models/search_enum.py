from enum import Enum


class SearchEnum(str, Enum):
    PHRASE = "phrase"
    PLAIN = "plain"
    RAW = "raw"
    WEBSEARCH = "websearch"

    def __str__(self) -> str:
        return str(self.value)
