from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.search_enum import SearchEnum
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.search_fields import SearchFields
    from ..models.user import User


T = TypeVar("T", bound="SearchPreference")


@_attrs_define
class SearchPreference:
    """Adds nested create feature

    Attributes:
        user (User): Adds nested create feature
        search (SearchEnum | Unset): * `plain` - Simple
            * `phrase` - Phrase
            * `websearch` - Web
            * `raw` - Raw
        lookup (bool | Unset):
        unaccent (list[SearchFields] | None | Unset):
        icontains (list[SearchFields] | None | Unset):
        istartswith (list[SearchFields] | None | Unset):
        trigram (list[SearchFields] | None | Unset):
        fulltext (list[SearchFields] | None | Unset):
        trigram_threshold (float | Unset):
    """

    user: User
    search: SearchEnum | Unset = UNSET
    lookup: bool | Unset = UNSET
    unaccent: list[SearchFields] | None | Unset = UNSET
    icontains: list[SearchFields] | None | Unset = UNSET
    istartswith: list[SearchFields] | None | Unset = UNSET
    trigram: list[SearchFields] | None | Unset = UNSET
    fulltext: list[SearchFields] | None | Unset = UNSET
    trigram_threshold: float | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        user = self.user.to_dict()

        search: str | Unset = UNSET
        if not isinstance(self.search, Unset):
            search = self.search.value

        lookup = self.lookup

        unaccent: list[dict[str, Any]] | None | Unset
        if isinstance(self.unaccent, Unset):
            unaccent = UNSET
        elif isinstance(self.unaccent, list):
            unaccent = []
            for unaccent_type_0_item_data in self.unaccent:
                unaccent_type_0_item = unaccent_type_0_item_data.to_dict()
                unaccent.append(unaccent_type_0_item)

        else:
            unaccent = self.unaccent

        icontains: list[dict[str, Any]] | None | Unset
        if isinstance(self.icontains, Unset):
            icontains = UNSET
        elif isinstance(self.icontains, list):
            icontains = []
            for icontains_type_0_item_data in self.icontains:
                icontains_type_0_item = icontains_type_0_item_data.to_dict()
                icontains.append(icontains_type_0_item)

        else:
            icontains = self.icontains

        istartswith: list[dict[str, Any]] | None | Unset
        if isinstance(self.istartswith, Unset):
            istartswith = UNSET
        elif isinstance(self.istartswith, list):
            istartswith = []
            for istartswith_type_0_item_data in self.istartswith:
                istartswith_type_0_item = istartswith_type_0_item_data.to_dict()
                istartswith.append(istartswith_type_0_item)

        else:
            istartswith = self.istartswith

        trigram: list[dict[str, Any]] | None | Unset
        if isinstance(self.trigram, Unset):
            trigram = UNSET
        elif isinstance(self.trigram, list):
            trigram = []
            for trigram_type_0_item_data in self.trigram:
                trigram_type_0_item = trigram_type_0_item_data.to_dict()
                trigram.append(trigram_type_0_item)

        else:
            trigram = self.trigram

        fulltext: list[dict[str, Any]] | None | Unset
        if isinstance(self.fulltext, Unset):
            fulltext = UNSET
        elif isinstance(self.fulltext, list):
            fulltext = []
            for fulltext_type_0_item_data in self.fulltext:
                fulltext_type_0_item = fulltext_type_0_item_data.to_dict()
                fulltext.append(fulltext_type_0_item)

        else:
            fulltext = self.fulltext

        trigram_threshold = self.trigram_threshold

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "user": user,
            }
        )
        if search is not UNSET:
            field_dict["search"] = search
        if lookup is not UNSET:
            field_dict["lookup"] = lookup
        if unaccent is not UNSET:
            field_dict["unaccent"] = unaccent
        if icontains is not UNSET:
            field_dict["icontains"] = icontains
        if istartswith is not UNSET:
            field_dict["istartswith"] = istartswith
        if trigram is not UNSET:
            field_dict["trigram"] = trigram
        if fulltext is not UNSET:
            field_dict["fulltext"] = fulltext
        if trigram_threshold is not UNSET:
            field_dict["trigram_threshold"] = trigram_threshold

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.search_fields import SearchFields
        from ..models.user import User

        d = dict(src_dict)
        user = User.from_dict(d.pop("user"))

        _search = d.pop("search", UNSET)
        search: SearchEnum | Unset
        if isinstance(_search, Unset):
            search = UNSET
        else:
            search = SearchEnum(_search)

        lookup = d.pop("lookup", UNSET)

        def _parse_unaccent(data: object) -> list[SearchFields] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                unaccent_type_0 = []
                _unaccent_type_0 = data
                for unaccent_type_0_item_data in _unaccent_type_0:
                    unaccent_type_0_item = SearchFields.from_dict(unaccent_type_0_item_data)

                    unaccent_type_0.append(unaccent_type_0_item)

                return unaccent_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[SearchFields] | None | Unset, data)

        unaccent = _parse_unaccent(d.pop("unaccent", UNSET))

        def _parse_icontains(data: object) -> list[SearchFields] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                icontains_type_0 = []
                _icontains_type_0 = data
                for icontains_type_0_item_data in _icontains_type_0:
                    icontains_type_0_item = SearchFields.from_dict(icontains_type_0_item_data)

                    icontains_type_0.append(icontains_type_0_item)

                return icontains_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[SearchFields] | None | Unset, data)

        icontains = _parse_icontains(d.pop("icontains", UNSET))

        def _parse_istartswith(data: object) -> list[SearchFields] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                istartswith_type_0 = []
                _istartswith_type_0 = data
                for istartswith_type_0_item_data in _istartswith_type_0:
                    istartswith_type_0_item = SearchFields.from_dict(istartswith_type_0_item_data)

                    istartswith_type_0.append(istartswith_type_0_item)

                return istartswith_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[SearchFields] | None | Unset, data)

        istartswith = _parse_istartswith(d.pop("istartswith", UNSET))

        def _parse_trigram(data: object) -> list[SearchFields] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                trigram_type_0 = []
                _trigram_type_0 = data
                for trigram_type_0_item_data in _trigram_type_0:
                    trigram_type_0_item = SearchFields.from_dict(trigram_type_0_item_data)

                    trigram_type_0.append(trigram_type_0_item)

                return trigram_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[SearchFields] | None | Unset, data)

        trigram = _parse_trigram(d.pop("trigram", UNSET))

        def _parse_fulltext(data: object) -> list[SearchFields] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                fulltext_type_0 = []
                _fulltext_type_0 = data
                for fulltext_type_0_item_data in _fulltext_type_0:
                    fulltext_type_0_item = SearchFields.from_dict(fulltext_type_0_item_data)

                    fulltext_type_0.append(fulltext_type_0_item)

                return fulltext_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[SearchFields] | None | Unset, data)

        fulltext = _parse_fulltext(d.pop("fulltext", UNSET))

        trigram_threshold = d.pop("trigram_threshold", UNSET)

        search_preference = cls(
            user=user,
            search=search,
            lookup=lookup,
            unaccent=unaccent,
            icontains=icontains,
            istartswith=istartswith,
            trigram=trigram,
            fulltext=fulltext,
            trigram_threshold=trigram_threshold,
        )

        search_preference.additional_properties = d
        return search_preference

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
