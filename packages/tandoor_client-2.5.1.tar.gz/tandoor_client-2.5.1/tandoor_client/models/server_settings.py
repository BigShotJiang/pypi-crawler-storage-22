from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ServerSettings")


@_attrs_define
class ServerSettings:
    """
    Attributes:
        shopping_min_autosync_interval (str):
        enable_pdf_export (bool):
        disable_external_connectors (bool):
        terms_url (str):
        privacy_url (str):
        imprint_url (str):
        hosted (bool):
        debug (bool):
        version (str):
        unauthenticated_theme_from_space (int):
        force_theme_from_space (int):
        logo_color_32 (str | Unset):
        logo_color_128 (str | Unset):
        logo_color_144 (str | Unset):
        logo_color_180 (str | Unset):
        logo_color_192 (str | Unset):
        logo_color_512 (str | Unset):
        logo_color_svg (str | Unset):
        custom_space_theme (str | Unset):
        nav_logo (str | Unset):
        nav_bg_color (str | Unset):
    """

    shopping_min_autosync_interval: str
    enable_pdf_export: bool
    disable_external_connectors: bool
    terms_url: str
    privacy_url: str
    imprint_url: str
    hosted: bool
    debug: bool
    version: str
    unauthenticated_theme_from_space: int
    force_theme_from_space: int
    logo_color_32: str | Unset = UNSET
    logo_color_128: str | Unset = UNSET
    logo_color_144: str | Unset = UNSET
    logo_color_180: str | Unset = UNSET
    logo_color_192: str | Unset = UNSET
    logo_color_512: str | Unset = UNSET
    logo_color_svg: str | Unset = UNSET
    custom_space_theme: str | Unset = UNSET
    nav_logo: str | Unset = UNSET
    nav_bg_color: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        shopping_min_autosync_interval = self.shopping_min_autosync_interval

        enable_pdf_export = self.enable_pdf_export

        disable_external_connectors = self.disable_external_connectors

        terms_url = self.terms_url

        privacy_url = self.privacy_url

        imprint_url = self.imprint_url

        hosted = self.hosted

        debug = self.debug

        version = self.version

        unauthenticated_theme_from_space = self.unauthenticated_theme_from_space

        force_theme_from_space = self.force_theme_from_space

        logo_color_32 = self.logo_color_32

        logo_color_128 = self.logo_color_128

        logo_color_144 = self.logo_color_144

        logo_color_180 = self.logo_color_180

        logo_color_192 = self.logo_color_192

        logo_color_512 = self.logo_color_512

        logo_color_svg = self.logo_color_svg

        custom_space_theme = self.custom_space_theme

        nav_logo = self.nav_logo

        nav_bg_color = self.nav_bg_color

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "shopping_min_autosync_interval": shopping_min_autosync_interval,
                "enable_pdf_export": enable_pdf_export,
                "disable_external_connectors": disable_external_connectors,
                "terms_url": terms_url,
                "privacy_url": privacy_url,
                "imprint_url": imprint_url,
                "hosted": hosted,
                "debug": debug,
                "version": version,
                "unauthenticated_theme_from_space": unauthenticated_theme_from_space,
                "force_theme_from_space": force_theme_from_space,
            }
        )
        if logo_color_32 is not UNSET:
            field_dict["logo_color_32"] = logo_color_32
        if logo_color_128 is not UNSET:
            field_dict["logo_color_128"] = logo_color_128
        if logo_color_144 is not UNSET:
            field_dict["logo_color_144"] = logo_color_144
        if logo_color_180 is not UNSET:
            field_dict["logo_color_180"] = logo_color_180
        if logo_color_192 is not UNSET:
            field_dict["logo_color_192"] = logo_color_192
        if logo_color_512 is not UNSET:
            field_dict["logo_color_512"] = logo_color_512
        if logo_color_svg is not UNSET:
            field_dict["logo_color_svg"] = logo_color_svg
        if custom_space_theme is not UNSET:
            field_dict["custom_space_theme"] = custom_space_theme
        if nav_logo is not UNSET:
            field_dict["nav_logo"] = nav_logo
        if nav_bg_color is not UNSET:
            field_dict["nav_bg_color"] = nav_bg_color

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        shopping_min_autosync_interval = d.pop("shopping_min_autosync_interval")

        enable_pdf_export = d.pop("enable_pdf_export")

        disable_external_connectors = d.pop("disable_external_connectors")

        terms_url = d.pop("terms_url")

        privacy_url = d.pop("privacy_url")

        imprint_url = d.pop("imprint_url")

        hosted = d.pop("hosted")

        debug = d.pop("debug")

        version = d.pop("version")

        unauthenticated_theme_from_space = d.pop("unauthenticated_theme_from_space")

        force_theme_from_space = d.pop("force_theme_from_space")

        logo_color_32 = d.pop("logo_color_32", UNSET)

        logo_color_128 = d.pop("logo_color_128", UNSET)

        logo_color_144 = d.pop("logo_color_144", UNSET)

        logo_color_180 = d.pop("logo_color_180", UNSET)

        logo_color_192 = d.pop("logo_color_192", UNSET)

        logo_color_512 = d.pop("logo_color_512", UNSET)

        logo_color_svg = d.pop("logo_color_svg", UNSET)

        custom_space_theme = d.pop("custom_space_theme", UNSET)

        nav_logo = d.pop("nav_logo", UNSET)

        nav_bg_color = d.pop("nav_bg_color", UNSET)

        server_settings = cls(
            shopping_min_autosync_interval=shopping_min_autosync_interval,
            enable_pdf_export=enable_pdf_export,
            disable_external_connectors=disable_external_connectors,
            terms_url=terms_url,
            privacy_url=privacy_url,
            imprint_url=imprint_url,
            hosted=hosted,
            debug=debug,
            version=version,
            unauthenticated_theme_from_space=unauthenticated_theme_from_space,
            force_theme_from_space=force_theme_from_space,
            logo_color_32=logo_color_32,
            logo_color_128=logo_color_128,
            logo_color_144=logo_color_144,
            logo_color_180=logo_color_180,
            logo_color_192=logo_color_192,
            logo_color_512=logo_color_512,
            logo_color_svg=logo_color_svg,
            custom_space_theme=custom_space_theme,
            nav_logo=nav_logo,
            nav_bg_color=nav_bg_color,
        )

        server_settings.additional_properties = d
        return server_settings

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
