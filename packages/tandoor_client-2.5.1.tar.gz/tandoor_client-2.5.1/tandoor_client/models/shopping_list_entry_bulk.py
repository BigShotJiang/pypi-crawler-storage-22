from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from .. import types
from ..types import UNSET, Unset

T = TypeVar("T", bound="ShoppingListEntryBulk")


@_attrs_define
class ShoppingListEntryBulk:
    """
    Attributes:
        ids (list[Any]):
        timestamp (datetime.datetime):
        checked (bool | None | Unset):
        shopping_lists_add (list[int] | Unset):
        shopping_lists_remove (list[int] | Unset):
        shopping_lists_set (list[int] | Unset):
        shopping_lists_remove_all (bool | Unset):  Default: False.
    """

    ids: list[Any]
    timestamp: datetime.datetime
    checked: bool | None | Unset = UNSET
    shopping_lists_add: list[int] | Unset = UNSET
    shopping_lists_remove: list[int] | Unset = UNSET
    shopping_lists_set: list[int] | Unset = UNSET
    shopping_lists_remove_all: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        ids = self.ids

        timestamp = self.timestamp.isoformat()

        checked: bool | None | Unset
        if isinstance(self.checked, Unset):
            checked = UNSET
        else:
            checked = self.checked

        shopping_lists_add: list[int] | Unset = UNSET
        if not isinstance(self.shopping_lists_add, Unset):
            shopping_lists_add = self.shopping_lists_add

        shopping_lists_remove: list[int] | Unset = UNSET
        if not isinstance(self.shopping_lists_remove, Unset):
            shopping_lists_remove = self.shopping_lists_remove

        shopping_lists_set: list[int] | Unset = UNSET
        if not isinstance(self.shopping_lists_set, Unset):
            shopping_lists_set = self.shopping_lists_set

        shopping_lists_remove_all = self.shopping_lists_remove_all

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "ids": ids,
                "timestamp": timestamp,
            }
        )
        if checked is not UNSET:
            field_dict["checked"] = checked
        if shopping_lists_add is not UNSET:
            field_dict["shopping_lists_add"] = shopping_lists_add
        if shopping_lists_remove is not UNSET:
            field_dict["shopping_lists_remove"] = shopping_lists_remove
        if shopping_lists_set is not UNSET:
            field_dict["shopping_lists_set"] = shopping_lists_set
        if shopping_lists_remove_all is not UNSET:
            field_dict["shopping_lists_remove_all"] = shopping_lists_remove_all

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        for ids_item_element in self.ids:
            files.append(("ids", (None, str(ids_item_element).encode(), "text/plain")))

        files.append(("timestamp", (None, self.timestamp.isoformat().encode(), "text/plain")))

        if not isinstance(self.checked, Unset):
            if isinstance(self.checked, bool):
                files.append(("checked", (None, str(self.checked).encode(), "text/plain")))
            else:
                files.append(("checked", (None, str(self.checked).encode(), "text/plain")))

        if not isinstance(self.shopping_lists_add, Unset):
            for shopping_lists_add_item_element in self.shopping_lists_add:
                files.append(
                    ("shopping_lists_add", (None, str(shopping_lists_add_item_element).encode(), "text/plain"))
                )

        if not isinstance(self.shopping_lists_remove, Unset):
            for shopping_lists_remove_item_element in self.shopping_lists_remove:
                files.append(
                    ("shopping_lists_remove", (None, str(shopping_lists_remove_item_element).encode(), "text/plain"))
                )

        if not isinstance(self.shopping_lists_set, Unset):
            for shopping_lists_set_item_element in self.shopping_lists_set:
                files.append(
                    ("shopping_lists_set", (None, str(shopping_lists_set_item_element).encode(), "text/plain"))
                )

        if not isinstance(self.shopping_lists_remove_all, Unset):
            files.append(
                ("shopping_lists_remove_all", (None, str(self.shopping_lists_remove_all).encode(), "text/plain"))
            )

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        ids = cast(list[Any], d.pop("ids"))

        timestamp = isoparse(d.pop("timestamp"))

        def _parse_checked(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        checked = _parse_checked(d.pop("checked", UNSET))

        shopping_lists_add = cast(list[int], d.pop("shopping_lists_add", UNSET))

        shopping_lists_remove = cast(list[int], d.pop("shopping_lists_remove", UNSET))

        shopping_lists_set = cast(list[int], d.pop("shopping_lists_set", UNSET))

        shopping_lists_remove_all = d.pop("shopping_lists_remove_all", UNSET)

        shopping_list_entry_bulk = cls(
            ids=ids,
            timestamp=timestamp,
            checked=checked,
            shopping_lists_add=shopping_lists_add,
            shopping_lists_remove=shopping_lists_remove,
            shopping_lists_set=shopping_lists_set,
            shopping_lists_remove_all=shopping_lists_remove_all,
        )

        shopping_list_entry_bulk.additional_properties = d
        return shopping_list_entry_bulk

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
