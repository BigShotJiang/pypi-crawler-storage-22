from __future__ import annotations

import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.shopping_list_entry_simple_create import ShoppingListEntrySimpleCreate


T = TypeVar("T", bound="ShoppingListEntryBulkCreate")


@_attrs_define
class ShoppingListEntryBulkCreate:
    """
    Attributes:
        entries (list[ShoppingListEntrySimpleCreate]):
        shopping_lists_ids (list[int] | Unset):
    """

    entries: list[ShoppingListEntrySimpleCreate]
    shopping_lists_ids: list[int] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        entries = []
        for entries_item_data in self.entries:
            entries_item = entries_item_data.to_dict()
            entries.append(entries_item)

        shopping_lists_ids: list[int] | Unset = UNSET
        if not isinstance(self.shopping_lists_ids, Unset):
            shopping_lists_ids = self.shopping_lists_ids

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "entries": entries,
            }
        )
        if shopping_lists_ids is not UNSET:
            field_dict["shopping_lists_ids"] = shopping_lists_ids

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        for entries_item_element in self.entries:
            files.append(("entries", (None, json.dumps(entries_item_element.to_dict()).encode(), "application/json")))

        if not isinstance(self.shopping_lists_ids, Unset):
            for shopping_lists_ids_item_element in self.shopping_lists_ids:
                files.append(
                    ("shopping_lists_ids", (None, str(shopping_lists_ids_item_element).encode(), "text/plain"))
                )

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.shopping_list_entry_simple_create import ShoppingListEntrySimpleCreate

        d = dict(src_dict)
        entries = []
        _entries = d.pop("entries")
        for entries_item_data in _entries:
            entries_item = ShoppingListEntrySimpleCreate.from_dict(entries_item_data)

            entries.append(entries_item)

        shopping_lists_ids = cast(list[int], d.pop("shopping_lists_ids", UNSET))

        shopping_list_entry_bulk_create = cls(
            entries=entries,
            shopping_lists_ids=shopping_lists_ids,
        )

        shopping_list_entry_bulk_create.additional_properties = d
        return shopping_list_entry_bulk_create

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
