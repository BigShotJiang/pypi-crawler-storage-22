from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="ShoppingListEntrySimpleCreate")


@_attrs_define
class ShoppingListEntrySimpleCreate:
    """
    Attributes:
        amount (float):
        unit_id (int | None):
        food_id (int | None):
        ingredient_id (int | None):
    """

    amount: float
    unit_id: int | None
    food_id: int | None
    ingredient_id: int | None
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        amount = self.amount

        unit_id: int | None
        unit_id = self.unit_id

        food_id: int | None
        food_id = self.food_id

        ingredient_id: int | None
        ingredient_id = self.ingredient_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "amount": amount,
                "unit_id": unit_id,
                "food_id": food_id,
                "ingredient_id": ingredient_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        amount = d.pop("amount")

        def _parse_unit_id(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        unit_id = _parse_unit_id(d.pop("unit_id"))

        def _parse_food_id(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        food_id = _parse_food_id(d.pop("food_id"))

        def _parse_ingredient_id(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        ingredient_id = _parse_ingredient_id(d.pop("ingredient_id"))

        shopping_list_entry_simple_create = cls(
            amount=amount,
            unit_id=unit_id,
            food_id=food_id,
            ingredient_id=ingredient_id,
        )

        shopping_list_entry_simple_create.additional_properties = d
        return shopping_list_entry_simple_create

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
