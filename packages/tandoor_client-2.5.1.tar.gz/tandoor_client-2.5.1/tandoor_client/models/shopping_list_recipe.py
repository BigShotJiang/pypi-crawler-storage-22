from __future__ import annotations

import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.meal_plan import MealPlan
    from ..models.recipe_overview import RecipeOverview
    from ..models.user import User


T = TypeVar("T", bound="ShoppingListRecipe")


@_attrs_define
class ShoppingListRecipe:
    """
    Attributes:
        recipe_data (RecipeOverview): Adds nested create feature
        meal_plan_data (MealPlan): Adds nested create feature
        servings (float):
        created_by (User): Adds nested create feature
        id (int | Unset):
        name (str | Unset):
        recipe (int | None | Unset):
        mealplan (int | None | Unset):
    """

    recipe_data: RecipeOverview
    meal_plan_data: MealPlan
    servings: float
    created_by: User
    id: int | Unset = UNSET
    name: str | Unset = UNSET
    recipe: int | None | Unset = UNSET
    mealplan: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        recipe_data = self.recipe_data.to_dict()

        meal_plan_data = self.meal_plan_data.to_dict()

        servings = self.servings

        created_by = self.created_by.to_dict()

        id = self.id

        name = self.name

        recipe: int | None | Unset
        if isinstance(self.recipe, Unset):
            recipe = UNSET
        else:
            recipe = self.recipe

        mealplan: int | None | Unset
        if isinstance(self.mealplan, Unset):
            mealplan = UNSET
        else:
            mealplan = self.mealplan

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "recipe_data": recipe_data,
                "meal_plan_data": meal_plan_data,
                "servings": servings,
                "created_by": created_by,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if name is not UNSET:
            field_dict["name"] = name
        if recipe is not UNSET:
            field_dict["recipe"] = recipe
        if mealplan is not UNSET:
            field_dict["mealplan"] = mealplan

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("recipe_data", (None, json.dumps(self.recipe_data.to_dict()).encode(), "application/json")))

        files.append(("meal_plan_data", (None, json.dumps(self.meal_plan_data.to_dict()).encode(), "application/json")))

        files.append(("servings", (None, str(self.servings).encode(), "text/plain")))

        files.append(("created_by", (None, json.dumps(self.created_by.to_dict()).encode(), "application/json")))

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.name, Unset):
            files.append(("name", (None, str(self.name).encode(), "text/plain")))

        if not isinstance(self.recipe, Unset):
            if isinstance(self.recipe, int):
                files.append(("recipe", (None, str(self.recipe).encode(), "text/plain")))
            else:
                files.append(("recipe", (None, str(self.recipe).encode(), "text/plain")))

        if not isinstance(self.mealplan, Unset):
            if isinstance(self.mealplan, int):
                files.append(("mealplan", (None, str(self.mealplan).encode(), "text/plain")))
            else:
                files.append(("mealplan", (None, str(self.mealplan).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.meal_plan import MealPlan
        from ..models.recipe_overview import RecipeOverview
        from ..models.user import User

        d = dict(src_dict)
        recipe_data = RecipeOverview.from_dict(d.pop("recipe_data"))

        meal_plan_data = MealPlan.from_dict(d.pop("meal_plan_data"))

        servings = d.pop("servings")

        created_by = User.from_dict(d.pop("created_by"))

        id = d.pop("id", UNSET)

        name = d.pop("name", UNSET)

        def _parse_recipe(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        recipe = _parse_recipe(d.pop("recipe", UNSET))

        def _parse_mealplan(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        mealplan = _parse_mealplan(d.pop("mealplan", UNSET))

        shopping_list_recipe = cls(
            recipe_data=recipe_data,
            meal_plan_data=meal_plan_data,
            servings=servings,
            created_by=created_by,
            id=id,
            name=name,
            recipe=recipe,
            mealplan=mealplan,
        )

        shopping_list_recipe.additional_properties = d
        return shopping_list_recipe

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
