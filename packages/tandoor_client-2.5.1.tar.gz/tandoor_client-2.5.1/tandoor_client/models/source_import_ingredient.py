from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.source_import_food import SourceImportFood
    from ..models.source_import_unit import SourceImportUnit


T = TypeVar("T", bound="SourceImportIngredient")


@_attrs_define
class SourceImportIngredient:
    """
    Attributes:
        amount (float):
        food (SourceImportFood):
        unit (SourceImportUnit):
        original_text (str):
        note (str | Unset):
    """

    amount: float
    food: SourceImportFood
    unit: SourceImportUnit
    original_text: str
    note: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        amount = self.amount

        food = self.food.to_dict()

        unit = self.unit.to_dict()

        original_text = self.original_text

        note = self.note

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "amount": amount,
                "food": food,
                "unit": unit,
                "original_text": original_text,
            }
        )
        if note is not UNSET:
            field_dict["note"] = note

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.source_import_food import SourceImportFood
        from ..models.source_import_unit import SourceImportUnit

        d = dict(src_dict)
        amount = d.pop("amount")

        food = SourceImportFood.from_dict(d.pop("food"))

        unit = SourceImportUnit.from_dict(d.pop("unit"))

        original_text = d.pop("original_text")

        note = d.pop("note", UNSET)

        source_import_ingredient = cls(
            amount=amount,
            food=food,
            unit=unit,
            original_text=original_text,
            note=note,
        )

        source_import_ingredient.additional_properties = d
        return source_import_ingredient

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
