from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="SourceImportKeyword")


@_attrs_define
class SourceImportKeyword:
    """
    Attributes:
        label (str):
        name (str):
        id (int | None | Unset):
        import_keyword (bool | Unset):  Default: True.
    """

    label: str
    name: str
    id: int | None | Unset = UNSET
    import_keyword: bool | Unset = True
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        label = self.label

        name = self.name

        id: int | None | Unset
        if isinstance(self.id, Unset):
            id = UNSET
        else:
            id = self.id

        import_keyword = self.import_keyword

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "label": label,
                "name": name,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if import_keyword is not UNSET:
            field_dict["import_keyword"] = import_keyword

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        label = d.pop("label")

        name = d.pop("name")

        def _parse_id(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        id = _parse_id(d.pop("id", UNSET))

        import_keyword = d.pop("import_keyword", UNSET)

        source_import_keyword = cls(
            label=label,
            name=name,
            id=id,
            import_keyword=import_keyword,
        )

        source_import_keyword.additional_properties = d
        return source_import_keyword

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
