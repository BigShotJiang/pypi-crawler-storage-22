from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.source_import_property_type import SourceImportPropertyType


T = TypeVar("T", bound="SourceImportProperty")


@_attrs_define
class SourceImportProperty:
    """
    Attributes:
        property_type (SourceImportPropertyType):
        property_amount (float):
    """

    property_type: SourceImportPropertyType
    property_amount: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        property_type = self.property_type.to_dict()

        property_amount = self.property_amount

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "property_type": property_type,
                "property_amount": property_amount,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.source_import_property_type import SourceImportPropertyType

        d = dict(src_dict)
        property_type = SourceImportPropertyType.from_dict(d.pop("property_type"))

        property_amount = d.pop("property_amount")

        source_import_property = cls(
            property_type=property_type,
            property_amount=property_amount,
        )

        source_import_property.additional_properties = d
        return source_import_property

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
