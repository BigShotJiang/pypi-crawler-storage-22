from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.source_import_keyword import SourceImportKeyword
    from ..models.source_import_property import SourceImportProperty
    from ..models.source_import_step import SourceImportStep


T = TypeVar("T", bound="SourceImportRecipe")


@_attrs_define
class SourceImportRecipe:
    """
    Attributes:
        steps (list[SourceImportStep]):
        source_url (str):
        name (str):
        internal (bool | Unset):  Default: True.
        description (str | Unset):
        servings (int | Unset):  Default: 1.
        servings_text (str | Unset):  Default: ''.
        working_time (int | Unset):  Default: 0.
        waiting_time (int | Unset):  Default: 0.
        image_url (str | Unset):
        keywords (list[SourceImportKeyword] | Unset):
        properties (list[SourceImportProperty] | Unset):
    """

    steps: list[SourceImportStep]
    source_url: str
    name: str
    internal: bool | Unset = True
    description: str | Unset = UNSET
    servings: int | Unset = 1
    servings_text: str | Unset = ""
    working_time: int | Unset = 0
    waiting_time: int | Unset = 0
    image_url: str | Unset = UNSET
    keywords: list[SourceImportKeyword] | Unset = UNSET
    properties: list[SourceImportProperty] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        steps = []
        for steps_item_data in self.steps:
            steps_item = steps_item_data.to_dict()
            steps.append(steps_item)

        source_url = self.source_url

        name = self.name

        internal = self.internal

        description = self.description

        servings = self.servings

        servings_text = self.servings_text

        working_time = self.working_time

        waiting_time = self.waiting_time

        image_url = self.image_url

        keywords: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.keywords, Unset):
            keywords = []
            for keywords_item_data in self.keywords:
                keywords_item = keywords_item_data.to_dict()
                keywords.append(keywords_item)

        properties: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.properties, Unset):
            properties = []
            for properties_item_data in self.properties:
                properties_item = properties_item_data.to_dict()
                properties.append(properties_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "steps": steps,
                "source_url": source_url,
                "name": name,
            }
        )
        if internal is not UNSET:
            field_dict["internal"] = internal
        if description is not UNSET:
            field_dict["description"] = description
        if servings is not UNSET:
            field_dict["servings"] = servings
        if servings_text is not UNSET:
            field_dict["servings_text"] = servings_text
        if working_time is not UNSET:
            field_dict["working_time"] = working_time
        if waiting_time is not UNSET:
            field_dict["waiting_time"] = waiting_time
        if image_url is not UNSET:
            field_dict["image_url"] = image_url
        if keywords is not UNSET:
            field_dict["keywords"] = keywords
        if properties is not UNSET:
            field_dict["properties"] = properties

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.source_import_keyword import SourceImportKeyword
        from ..models.source_import_property import SourceImportProperty
        from ..models.source_import_step import SourceImportStep

        d = dict(src_dict)
        steps = []
        _steps = d.pop("steps")
        for steps_item_data in _steps:
            steps_item = SourceImportStep.from_dict(steps_item_data)

            steps.append(steps_item)

        source_url = d.pop("source_url")

        name = d.pop("name")

        internal = d.pop("internal", UNSET)

        description = d.pop("description", UNSET)

        servings = d.pop("servings", UNSET)

        servings_text = d.pop("servings_text", UNSET)

        working_time = d.pop("working_time", UNSET)

        waiting_time = d.pop("waiting_time", UNSET)

        image_url = d.pop("image_url", UNSET)

        _keywords = d.pop("keywords", UNSET)
        keywords: list[SourceImportKeyword] | Unset = UNSET
        if _keywords is not UNSET:
            keywords = []
            for keywords_item_data in _keywords:
                keywords_item = SourceImportKeyword.from_dict(keywords_item_data)

                keywords.append(keywords_item)

        _properties = d.pop("properties", UNSET)
        properties: list[SourceImportProperty] | Unset = UNSET
        if _properties is not UNSET:
            properties = []
            for properties_item_data in _properties:
                properties_item = SourceImportProperty.from_dict(properties_item_data)

                properties.append(properties_item)

        source_import_recipe = cls(
            steps=steps,
            source_url=source_url,
            name=name,
            internal=internal,
            description=description,
            servings=servings,
            servings_text=servings_text,
            working_time=working_time,
            waiting_time=waiting_time,
            image_url=image_url,
            keywords=keywords,
            properties=properties,
        )

        source_import_recipe.additional_properties = d
        return source_import_recipe

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
