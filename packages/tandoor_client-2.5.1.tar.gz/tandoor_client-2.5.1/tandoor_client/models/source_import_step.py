from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.source_import_ingredient import SourceImportIngredient


T = TypeVar("T", bound="SourceImportStep")


@_attrs_define
class SourceImportStep:
    """
    Attributes:
        instruction (str):
        ingredients (list[SourceImportIngredient]):
        show_ingredients_table (bool | Unset):  Default: True.
    """

    instruction: str
    ingredients: list[SourceImportIngredient]
    show_ingredients_table: bool | Unset = True
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        instruction = self.instruction

        ingredients = []
        for ingredients_item_data in self.ingredients:
            ingredients_item = ingredients_item_data.to_dict()
            ingredients.append(ingredients_item)

        show_ingredients_table = self.show_ingredients_table

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "instruction": instruction,
                "ingredients": ingredients,
            }
        )
        if show_ingredients_table is not UNSET:
            field_dict["show_ingredients_table"] = show_ingredients_table

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.source_import_ingredient import SourceImportIngredient

        d = dict(src_dict)
        instruction = d.pop("instruction")

        ingredients = []
        _ingredients = d.pop("ingredients")
        for ingredients_item_data in _ingredients:
            ingredients_item = SourceImportIngredient.from_dict(ingredients_item_data)

            ingredients.append(ingredients_item)

        show_ingredients_table = d.pop("show_ingredients_table", UNSET)

        source_import_step = cls(
            instruction=instruction,
            ingredients=ingredients,
            show_ingredients_table=show_ingredients_table,
        )

        source_import_step.additional_properties = d
        return source_import_step

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
