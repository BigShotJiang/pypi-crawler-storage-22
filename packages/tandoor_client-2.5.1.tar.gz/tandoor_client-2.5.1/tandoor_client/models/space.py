from __future__ import annotations

import datetime
import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from .. import types
from ..models.space_nav_text_color_enum import SpaceNavTextColorEnum
from ..models.space_theme_enum import SpaceThemeEnum
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.ai_provider import AiProvider
    from ..models.food_inherit_field import FoodInheritField
    from ..models.user import User
    from ..models.user_file_view import UserFileView


T = TypeVar("T", bound="Space")


@_attrs_define
class Space:
    """Adds nested create feature

    Attributes:
        created_by (User): Adds nested create feature
        created_at (datetime.datetime):
        max_recipes (int):
        max_file_storage_mb (int): Maximum file storage for space in MB. 0 for unlimited, -1 to disable file upload.
        max_users (int):
        allow_sharing (bool):
        demo (bool):
        user_count (int):
        recipe_count (int):
        file_size_mb (float):
        ai_monthly_credits_used (int):
        id (int | Unset):
        name (str | Unset):
        message (str | Unset):
        food_inherit (list[FoodInheritField] | Unset):
        image (None | Unset | UserFileView):
        nav_logo (None | Unset | UserFileView):
        space_theme (SpaceThemeEnum | Unset): * `BLANK` - -------
            * `TANDOOR` - Tandoor
            * `BOOTSTRAP` - Bootstrap
            * `DARKLY` - Darkly
            * `FLATLY` - Flatly
            * `SUPERHERO` - Superhero
            * `TANDOOR_DARK` - Tandoor Dark (INCOMPLETE)
        custom_space_theme (None | Unset | UserFileView):
        nav_bg_color (str | Unset):
        nav_text_color (SpaceNavTextColorEnum | Unset): * `BLANK` - -------
            * `LIGHT` - Light
            * `DARK` - Dark
        logo_color_32 (None | Unset | UserFileView):
        logo_color_128 (None | Unset | UserFileView):
        logo_color_144 (None | Unset | UserFileView):
        logo_color_180 (None | Unset | UserFileView):
        logo_color_192 (None | Unset | UserFileView):
        logo_color_512 (None | Unset | UserFileView):
        logo_color_svg (None | Unset | UserFileView):
        ai_credits_monthly (int | Unset):
        ai_credits_balance (float | Unset):
        ai_enabled (bool | Unset):
        ai_default_provider (AiProvider | None | Unset):
        space_setup_completed (bool | Unset):
    """

    created_by: User
    created_at: datetime.datetime
    max_recipes: int
    max_file_storage_mb: int
    max_users: int
    allow_sharing: bool
    demo: bool
    user_count: int
    recipe_count: int
    file_size_mb: float
    ai_monthly_credits_used: int
    id: int | Unset = UNSET
    name: str | Unset = UNSET
    message: str | Unset = UNSET
    food_inherit: list[FoodInheritField] | Unset = UNSET
    image: None | Unset | UserFileView = UNSET
    nav_logo: None | Unset | UserFileView = UNSET
    space_theme: SpaceThemeEnum | Unset = UNSET
    custom_space_theme: None | Unset | UserFileView = UNSET
    nav_bg_color: str | Unset = UNSET
    nav_text_color: SpaceNavTextColorEnum | Unset = UNSET
    logo_color_32: None | Unset | UserFileView = UNSET
    logo_color_128: None | Unset | UserFileView = UNSET
    logo_color_144: None | Unset | UserFileView = UNSET
    logo_color_180: None | Unset | UserFileView = UNSET
    logo_color_192: None | Unset | UserFileView = UNSET
    logo_color_512: None | Unset | UserFileView = UNSET
    logo_color_svg: None | Unset | UserFileView = UNSET
    ai_credits_monthly: int | Unset = UNSET
    ai_credits_balance: float | Unset = UNSET
    ai_enabled: bool | Unset = UNSET
    ai_default_provider: AiProvider | None | Unset = UNSET
    space_setup_completed: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.ai_provider import AiProvider
        from ..models.user_file_view import UserFileView

        created_by = self.created_by.to_dict()

        created_at = self.created_at.isoformat()

        max_recipes = self.max_recipes

        max_file_storage_mb = self.max_file_storage_mb

        max_users = self.max_users

        allow_sharing = self.allow_sharing

        demo = self.demo

        user_count = self.user_count

        recipe_count = self.recipe_count

        file_size_mb = self.file_size_mb

        ai_monthly_credits_used = self.ai_monthly_credits_used

        id = self.id

        name = self.name

        message = self.message

        food_inherit: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.food_inherit, Unset):
            food_inherit = []
            for food_inherit_item_data in self.food_inherit:
                food_inherit_item = food_inherit_item_data.to_dict()
                food_inherit.append(food_inherit_item)

        image: dict[str, Any] | None | Unset
        if isinstance(self.image, Unset):
            image = UNSET
        elif isinstance(self.image, UserFileView):
            image = self.image.to_dict()
        else:
            image = self.image

        nav_logo: dict[str, Any] | None | Unset
        if isinstance(self.nav_logo, Unset):
            nav_logo = UNSET
        elif isinstance(self.nav_logo, UserFileView):
            nav_logo = self.nav_logo.to_dict()
        else:
            nav_logo = self.nav_logo

        space_theme: str | Unset = UNSET
        if not isinstance(self.space_theme, Unset):
            space_theme = self.space_theme.value

        custom_space_theme: dict[str, Any] | None | Unset
        if isinstance(self.custom_space_theme, Unset):
            custom_space_theme = UNSET
        elif isinstance(self.custom_space_theme, UserFileView):
            custom_space_theme = self.custom_space_theme.to_dict()
        else:
            custom_space_theme = self.custom_space_theme

        nav_bg_color = self.nav_bg_color

        nav_text_color: str | Unset = UNSET
        if not isinstance(self.nav_text_color, Unset):
            nav_text_color = self.nav_text_color.value

        logo_color_32: dict[str, Any] | None | Unset
        if isinstance(self.logo_color_32, Unset):
            logo_color_32 = UNSET
        elif isinstance(self.logo_color_32, UserFileView):
            logo_color_32 = self.logo_color_32.to_dict()
        else:
            logo_color_32 = self.logo_color_32

        logo_color_128: dict[str, Any] | None | Unset
        if isinstance(self.logo_color_128, Unset):
            logo_color_128 = UNSET
        elif isinstance(self.logo_color_128, UserFileView):
            logo_color_128 = self.logo_color_128.to_dict()
        else:
            logo_color_128 = self.logo_color_128

        logo_color_144: dict[str, Any] | None | Unset
        if isinstance(self.logo_color_144, Unset):
            logo_color_144 = UNSET
        elif isinstance(self.logo_color_144, UserFileView):
            logo_color_144 = self.logo_color_144.to_dict()
        else:
            logo_color_144 = self.logo_color_144

        logo_color_180: dict[str, Any] | None | Unset
        if isinstance(self.logo_color_180, Unset):
            logo_color_180 = UNSET
        elif isinstance(self.logo_color_180, UserFileView):
            logo_color_180 = self.logo_color_180.to_dict()
        else:
            logo_color_180 = self.logo_color_180

        logo_color_192: dict[str, Any] | None | Unset
        if isinstance(self.logo_color_192, Unset):
            logo_color_192 = UNSET
        elif isinstance(self.logo_color_192, UserFileView):
            logo_color_192 = self.logo_color_192.to_dict()
        else:
            logo_color_192 = self.logo_color_192

        logo_color_512: dict[str, Any] | None | Unset
        if isinstance(self.logo_color_512, Unset):
            logo_color_512 = UNSET
        elif isinstance(self.logo_color_512, UserFileView):
            logo_color_512 = self.logo_color_512.to_dict()
        else:
            logo_color_512 = self.logo_color_512

        logo_color_svg: dict[str, Any] | None | Unset
        if isinstance(self.logo_color_svg, Unset):
            logo_color_svg = UNSET
        elif isinstance(self.logo_color_svg, UserFileView):
            logo_color_svg = self.logo_color_svg.to_dict()
        else:
            logo_color_svg = self.logo_color_svg

        ai_credits_monthly = self.ai_credits_monthly

        ai_credits_balance = self.ai_credits_balance

        ai_enabled = self.ai_enabled

        ai_default_provider: dict[str, Any] | None | Unset
        if isinstance(self.ai_default_provider, Unset):
            ai_default_provider = UNSET
        elif isinstance(self.ai_default_provider, AiProvider):
            ai_default_provider = self.ai_default_provider.to_dict()
        else:
            ai_default_provider = self.ai_default_provider

        space_setup_completed = self.space_setup_completed

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "created_by": created_by,
                "created_at": created_at,
                "max_recipes": max_recipes,
                "max_file_storage_mb": max_file_storage_mb,
                "max_users": max_users,
                "allow_sharing": allow_sharing,
                "demo": demo,
                "user_count": user_count,
                "recipe_count": recipe_count,
                "file_size_mb": file_size_mb,
                "ai_monthly_credits_used": ai_monthly_credits_used,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if name is not UNSET:
            field_dict["name"] = name
        if message is not UNSET:
            field_dict["message"] = message
        if food_inherit is not UNSET:
            field_dict["food_inherit"] = food_inherit
        if image is not UNSET:
            field_dict["image"] = image
        if nav_logo is not UNSET:
            field_dict["nav_logo"] = nav_logo
        if space_theme is not UNSET:
            field_dict["space_theme"] = space_theme
        if custom_space_theme is not UNSET:
            field_dict["custom_space_theme"] = custom_space_theme
        if nav_bg_color is not UNSET:
            field_dict["nav_bg_color"] = nav_bg_color
        if nav_text_color is not UNSET:
            field_dict["nav_text_color"] = nav_text_color
        if logo_color_32 is not UNSET:
            field_dict["logo_color_32"] = logo_color_32
        if logo_color_128 is not UNSET:
            field_dict["logo_color_128"] = logo_color_128
        if logo_color_144 is not UNSET:
            field_dict["logo_color_144"] = logo_color_144
        if logo_color_180 is not UNSET:
            field_dict["logo_color_180"] = logo_color_180
        if logo_color_192 is not UNSET:
            field_dict["logo_color_192"] = logo_color_192
        if logo_color_512 is not UNSET:
            field_dict["logo_color_512"] = logo_color_512
        if logo_color_svg is not UNSET:
            field_dict["logo_color_svg"] = logo_color_svg
        if ai_credits_monthly is not UNSET:
            field_dict["ai_credits_monthly"] = ai_credits_monthly
        if ai_credits_balance is not UNSET:
            field_dict["ai_credits_balance"] = ai_credits_balance
        if ai_enabled is not UNSET:
            field_dict["ai_enabled"] = ai_enabled
        if ai_default_provider is not UNSET:
            field_dict["ai_default_provider"] = ai_default_provider
        if space_setup_completed is not UNSET:
            field_dict["space_setup_completed"] = space_setup_completed

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("created_by", (None, json.dumps(self.created_by.to_dict()).encode(), "application/json")))

        files.append(("created_at", (None, self.created_at.isoformat().encode(), "text/plain")))

        files.append(("max_recipes", (None, str(self.max_recipes).encode(), "text/plain")))

        files.append(("max_file_storage_mb", (None, str(self.max_file_storage_mb).encode(), "text/plain")))

        files.append(("max_users", (None, str(self.max_users).encode(), "text/plain")))

        files.append(("allow_sharing", (None, str(self.allow_sharing).encode(), "text/plain")))

        files.append(("demo", (None, str(self.demo).encode(), "text/plain")))

        files.append(("user_count", (None, str(self.user_count).encode(), "text/plain")))

        files.append(("recipe_count", (None, str(self.recipe_count).encode(), "text/plain")))

        files.append(("file_size_mb", (None, str(self.file_size_mb).encode(), "text/plain")))

        files.append(("ai_monthly_credits_used", (None, str(self.ai_monthly_credits_used).encode(), "text/plain")))

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.name, Unset):
            files.append(("name", (None, str(self.name).encode(), "text/plain")))

        if not isinstance(self.message, Unset):
            files.append(("message", (None, str(self.message).encode(), "text/plain")))

        if not isinstance(self.food_inherit, Unset):
            for food_inherit_item_element in self.food_inherit:
                files.append(
                    (
                        "food_inherit",
                        (None, json.dumps(food_inherit_item_element.to_dict()).encode(), "application/json"),
                    )
                )

        if not isinstance(self.image, Unset):
            if self.image is None:
                files.append(("image", (None, str(self.image).encode(), "text/plain")))
            else:
                files.append(("image", (None, json.dumps(self.image.to_dict()).encode(), "application/json")))

        if not isinstance(self.nav_logo, Unset):
            if self.nav_logo is None:
                files.append(("nav_logo", (None, str(self.nav_logo).encode(), "text/plain")))
            else:
                files.append(("nav_logo", (None, json.dumps(self.nav_logo.to_dict()).encode(), "application/json")))

        if not isinstance(self.space_theme, Unset):
            files.append(("space_theme", (None, str(self.space_theme.value).encode(), "text/plain")))

        if not isinstance(self.custom_space_theme, Unset):
            if self.custom_space_theme is None:
                files.append(("custom_space_theme", (None, str(self.custom_space_theme).encode(), "text/plain")))
            else:
                files.append(
                    (
                        "custom_space_theme",
                        (None, json.dumps(self.custom_space_theme.to_dict()).encode(), "application/json"),
                    )
                )

        if not isinstance(self.nav_bg_color, Unset):
            files.append(("nav_bg_color", (None, str(self.nav_bg_color).encode(), "text/plain")))

        if not isinstance(self.nav_text_color, Unset):
            files.append(("nav_text_color", (None, str(self.nav_text_color.value).encode(), "text/plain")))

        if not isinstance(self.logo_color_32, Unset):
            if self.logo_color_32 is None:
                files.append(("logo_color_32", (None, str(self.logo_color_32).encode(), "text/plain")))
            else:
                files.append(
                    ("logo_color_32", (None, json.dumps(self.logo_color_32.to_dict()).encode(), "application/json"))
                )

        if not isinstance(self.logo_color_128, Unset):
            if self.logo_color_128 is None:
                files.append(("logo_color_128", (None, str(self.logo_color_128).encode(), "text/plain")))
            else:
                files.append(
                    ("logo_color_128", (None, json.dumps(self.logo_color_128.to_dict()).encode(), "application/json"))
                )

        if not isinstance(self.logo_color_144, Unset):
            if self.logo_color_144 is None:
                files.append(("logo_color_144", (None, str(self.logo_color_144).encode(), "text/plain")))
            else:
                files.append(
                    ("logo_color_144", (None, json.dumps(self.logo_color_144.to_dict()).encode(), "application/json"))
                )

        if not isinstance(self.logo_color_180, Unset):
            if self.logo_color_180 is None:
                files.append(("logo_color_180", (None, str(self.logo_color_180).encode(), "text/plain")))
            else:
                files.append(
                    ("logo_color_180", (None, json.dumps(self.logo_color_180.to_dict()).encode(), "application/json"))
                )

        if not isinstance(self.logo_color_192, Unset):
            if self.logo_color_192 is None:
                files.append(("logo_color_192", (None, str(self.logo_color_192).encode(), "text/plain")))
            else:
                files.append(
                    ("logo_color_192", (None, json.dumps(self.logo_color_192.to_dict()).encode(), "application/json"))
                )

        if not isinstance(self.logo_color_512, Unset):
            if self.logo_color_512 is None:
                files.append(("logo_color_512", (None, str(self.logo_color_512).encode(), "text/plain")))
            else:
                files.append(
                    ("logo_color_512", (None, json.dumps(self.logo_color_512.to_dict()).encode(), "application/json"))
                )

        if not isinstance(self.logo_color_svg, Unset):
            if self.logo_color_svg is None:
                files.append(("logo_color_svg", (None, str(self.logo_color_svg).encode(), "text/plain")))
            else:
                files.append(
                    ("logo_color_svg", (None, json.dumps(self.logo_color_svg.to_dict()).encode(), "application/json"))
                )

        if not isinstance(self.ai_credits_monthly, Unset):
            files.append(("ai_credits_monthly", (None, str(self.ai_credits_monthly).encode(), "text/plain")))

        if not isinstance(self.ai_credits_balance, Unset):
            files.append(("ai_credits_balance", (None, str(self.ai_credits_balance).encode(), "text/plain")))

        if not isinstance(self.ai_enabled, Unset):
            files.append(("ai_enabled", (None, str(self.ai_enabled).encode(), "text/plain")))

        if not isinstance(self.ai_default_provider, Unset):
            if self.ai_default_provider is None:
                files.append(("ai_default_provider", (None, str(self.ai_default_provider).encode(), "text/plain")))
            else:
                files.append(
                    (
                        "ai_default_provider",
                        (None, json.dumps(self.ai_default_provider.to_dict()).encode(), "application/json"),
                    )
                )

        if not isinstance(self.space_setup_completed, Unset):
            files.append(("space_setup_completed", (None, str(self.space_setup_completed).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.ai_provider import AiProvider
        from ..models.food_inherit_field import FoodInheritField
        from ..models.user import User
        from ..models.user_file_view import UserFileView

        d = dict(src_dict)
        created_by = User.from_dict(d.pop("created_by"))

        created_at = isoparse(d.pop("created_at"))

        max_recipes = d.pop("max_recipes")

        max_file_storage_mb = d.pop("max_file_storage_mb")

        max_users = d.pop("max_users")

        allow_sharing = d.pop("allow_sharing")

        demo = d.pop("demo")

        user_count = d.pop("user_count")

        recipe_count = d.pop("recipe_count")

        file_size_mb = d.pop("file_size_mb")

        ai_monthly_credits_used = d.pop("ai_monthly_credits_used")

        id = d.pop("id", UNSET)

        name = d.pop("name", UNSET)

        message = d.pop("message", UNSET)

        _food_inherit = d.pop("food_inherit", UNSET)
        food_inherit: list[FoodInheritField] | Unset = UNSET
        if _food_inherit is not UNSET:
            food_inherit = []
            for food_inherit_item_data in _food_inherit:
                food_inherit_item = FoodInheritField.from_dict(food_inherit_item_data)

                food_inherit.append(food_inherit_item)

        def _parse_image(data: object) -> None | Unset | UserFileView:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                image_type_1 = UserFileView.from_dict(data)

                return image_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UserFileView, data)

        image = _parse_image(d.pop("image", UNSET))

        def _parse_nav_logo(data: object) -> None | Unset | UserFileView:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                nav_logo_type_1 = UserFileView.from_dict(data)

                return nav_logo_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UserFileView, data)

        nav_logo = _parse_nav_logo(d.pop("nav_logo", UNSET))

        _space_theme = d.pop("space_theme", UNSET)
        space_theme: SpaceThemeEnum | Unset
        if isinstance(_space_theme, Unset):
            space_theme = UNSET
        else:
            space_theme = SpaceThemeEnum(_space_theme)

        def _parse_custom_space_theme(data: object) -> None | Unset | UserFileView:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                custom_space_theme_type_1 = UserFileView.from_dict(data)

                return custom_space_theme_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UserFileView, data)

        custom_space_theme = _parse_custom_space_theme(d.pop("custom_space_theme", UNSET))

        nav_bg_color = d.pop("nav_bg_color", UNSET)

        _nav_text_color = d.pop("nav_text_color", UNSET)
        nav_text_color: SpaceNavTextColorEnum | Unset
        if isinstance(_nav_text_color, Unset):
            nav_text_color = UNSET
        else:
            nav_text_color = SpaceNavTextColorEnum(_nav_text_color)

        def _parse_logo_color_32(data: object) -> None | Unset | UserFileView:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                logo_color_32_type_1 = UserFileView.from_dict(data)

                return logo_color_32_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UserFileView, data)

        logo_color_32 = _parse_logo_color_32(d.pop("logo_color_32", UNSET))

        def _parse_logo_color_128(data: object) -> None | Unset | UserFileView:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                logo_color_128_type_1 = UserFileView.from_dict(data)

                return logo_color_128_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UserFileView, data)

        logo_color_128 = _parse_logo_color_128(d.pop("logo_color_128", UNSET))

        def _parse_logo_color_144(data: object) -> None | Unset | UserFileView:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                logo_color_144_type_1 = UserFileView.from_dict(data)

                return logo_color_144_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UserFileView, data)

        logo_color_144 = _parse_logo_color_144(d.pop("logo_color_144", UNSET))

        def _parse_logo_color_180(data: object) -> None | Unset | UserFileView:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                logo_color_180_type_1 = UserFileView.from_dict(data)

                return logo_color_180_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UserFileView, data)

        logo_color_180 = _parse_logo_color_180(d.pop("logo_color_180", UNSET))

        def _parse_logo_color_192(data: object) -> None | Unset | UserFileView:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                logo_color_192_type_1 = UserFileView.from_dict(data)

                return logo_color_192_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UserFileView, data)

        logo_color_192 = _parse_logo_color_192(d.pop("logo_color_192", UNSET))

        def _parse_logo_color_512(data: object) -> None | Unset | UserFileView:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                logo_color_512_type_1 = UserFileView.from_dict(data)

                return logo_color_512_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UserFileView, data)

        logo_color_512 = _parse_logo_color_512(d.pop("logo_color_512", UNSET))

        def _parse_logo_color_svg(data: object) -> None | Unset | UserFileView:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                logo_color_svg_type_1 = UserFileView.from_dict(data)

                return logo_color_svg_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UserFileView, data)

        logo_color_svg = _parse_logo_color_svg(d.pop("logo_color_svg", UNSET))

        ai_credits_monthly = d.pop("ai_credits_monthly", UNSET)

        ai_credits_balance = d.pop("ai_credits_balance", UNSET)

        ai_enabled = d.pop("ai_enabled", UNSET)

        def _parse_ai_default_provider(data: object) -> AiProvider | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                ai_default_provider_type_1 = AiProvider.from_dict(data)

                return ai_default_provider_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AiProvider | None | Unset, data)

        ai_default_provider = _parse_ai_default_provider(d.pop("ai_default_provider", UNSET))

        space_setup_completed = d.pop("space_setup_completed", UNSET)

        space = cls(
            created_by=created_by,
            created_at=created_at,
            max_recipes=max_recipes,
            max_file_storage_mb=max_file_storage_mb,
            max_users=max_users,
            allow_sharing=allow_sharing,
            demo=demo,
            user_count=user_count,
            recipe_count=recipe_count,
            file_size_mb=file_size_mb,
            ai_monthly_credits_used=ai_monthly_credits_used,
            id=id,
            name=name,
            message=message,
            food_inherit=food_inherit,
            image=image,
            nav_logo=nav_logo,
            space_theme=space_theme,
            custom_space_theme=custom_space_theme,
            nav_bg_color=nav_bg_color,
            nav_text_color=nav_text_color,
            logo_color_32=logo_color_32,
            logo_color_128=logo_color_128,
            logo_color_144=logo_color_144,
            logo_color_180=logo_color_180,
            logo_color_192=logo_color_192,
            logo_color_512=logo_color_512,
            logo_color_svg=logo_color_svg,
            ai_credits_monthly=ai_credits_monthly,
            ai_credits_balance=ai_credits_balance,
            ai_enabled=ai_enabled,
            ai_default_provider=ai_default_provider,
            space_setup_completed=space_setup_completed,
        )

        space.additional_properties = d
        return space

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
