from enum import Enum


class SpaceNavTextColorEnum(str, Enum):
    BLANK = "BLANK"
    DARK = "DARK"
    LIGHT = "LIGHT"

    def __str__(self) -> str:
        return str(self.value)
