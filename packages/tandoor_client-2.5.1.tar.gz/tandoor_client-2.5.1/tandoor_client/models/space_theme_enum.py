from enum import Enum


class SpaceThemeEnum(str, Enum):
    BLANK = "BLANK"
    BOOTSTRAP = "BOOTSTRAP"
    DARKLY = "DARKLY"
    FLATLY = "FLATLY"
    SUPERHERO = "SUPERHERO"
    TANDOOR = "TANDOOR"
    TANDOOR_DARK = "TANDOOR_DARK"

    def __str__(self) -> str:
        return str(self.value)
