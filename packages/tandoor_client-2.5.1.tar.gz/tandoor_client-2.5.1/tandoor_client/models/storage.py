from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..models.method_enum import MethodEnum
from ..types import UNSET, Unset

T = TypeVar("T", bound="Storage")


@_attrs_define
class Storage:
    """Adds nested create feature

    Attributes:
        name (str):
        created_by (int):
        id (int | Unset):
        method (MethodEnum | Unset): * `DB` - Dropbox
            * `NEXTCLOUD` - Nextcloud
            * `LOCAL` - Local
        username (None | str | Unset):
        password (None | str | Unset):
        token (None | str | Unset):
        url (None | str | Unset):
        path (str | Unset):
    """

    name: str
    created_by: int
    id: int | Unset = UNSET
    method: MethodEnum | Unset = UNSET
    username: None | str | Unset = UNSET
    password: None | str | Unset = UNSET
    token: None | str | Unset = UNSET
    url: None | str | Unset = UNSET
    path: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        created_by = self.created_by

        id = self.id

        method: str | Unset = UNSET
        if not isinstance(self.method, Unset):
            method = self.method.value

        username: None | str | Unset
        if isinstance(self.username, Unset):
            username = UNSET
        else:
            username = self.username

        password: None | str | Unset
        if isinstance(self.password, Unset):
            password = UNSET
        else:
            password = self.password

        token: None | str | Unset
        if isinstance(self.token, Unset):
            token = UNSET
        else:
            token = self.token

        url: None | str | Unset
        if isinstance(self.url, Unset):
            url = UNSET
        else:
            url = self.url

        path = self.path

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "created_by": created_by,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if method is not UNSET:
            field_dict["method"] = method
        if username is not UNSET:
            field_dict["username"] = username
        if password is not UNSET:
            field_dict["password"] = password
        if token is not UNSET:
            field_dict["token"] = token
        if url is not UNSET:
            field_dict["url"] = url
        if path is not UNSET:
            field_dict["path"] = path

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("name", (None, str(self.name).encode(), "text/plain")))

        files.append(("created_by", (None, str(self.created_by).encode(), "text/plain")))

        if not isinstance(self.id, Unset):
            files.append(("id", (None, str(self.id).encode(), "text/plain")))

        if not isinstance(self.method, Unset):
            files.append(("method", (None, str(self.method.value).encode(), "text/plain")))

        if not isinstance(self.username, Unset):
            if isinstance(self.username, str):
                files.append(("username", (None, str(self.username).encode(), "text/plain")))
            else:
                files.append(("username", (None, str(self.username).encode(), "text/plain")))

        if not isinstance(self.password, Unset):
            if isinstance(self.password, str):
                files.append(("password", (None, str(self.password).encode(), "text/plain")))
            else:
                files.append(("password", (None, str(self.password).encode(), "text/plain")))

        if not isinstance(self.token, Unset):
            if isinstance(self.token, str):
                files.append(("token", (None, str(self.token).encode(), "text/plain")))
            else:
                files.append(("token", (None, str(self.token).encode(), "text/plain")))

        if not isinstance(self.url, Unset):
            if isinstance(self.url, str):
                files.append(("url", (None, str(self.url).encode(), "text/plain")))
            else:
                files.append(("url", (None, str(self.url).encode(), "text/plain")))

        if not isinstance(self.path, Unset):
            files.append(("path", (None, str(self.path).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        created_by = d.pop("created_by")

        id = d.pop("id", UNSET)

        _method = d.pop("method", UNSET)
        method: MethodEnum | Unset
        if isinstance(_method, Unset):
            method = UNSET
        else:
            method = MethodEnum(_method)

        def _parse_username(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        username = _parse_username(d.pop("username", UNSET))

        def _parse_password(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        password = _parse_password(d.pop("password", UNSET))

        def _parse_token(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        token = _parse_token(d.pop("token", UNSET))

        def _parse_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        url = _parse_url(d.pop("url", UNSET))

        path = d.pop("path", UNSET)

        storage = cls(
            name=name,
            created_by=created_by,
            id=id,
            method=method,
            username=username,
            password=password,
            token=token,
            url=url,
            path=path,
        )

        storage.additional_properties = d
        return storage

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
