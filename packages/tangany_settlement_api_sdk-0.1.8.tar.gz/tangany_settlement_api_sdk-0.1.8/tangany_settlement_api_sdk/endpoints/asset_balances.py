import requests

from attr import define
from .response_handler import return_or_raise
from ..auth import Authenticator

@define
class AssetBalances:
    _authenticator: Authenticator
    _base_url: str

    def __init__(self, authenticator: Authenticator):
        self._authenticator = authenticator  
        self._base_url = f"{authenticator.credentials.base_url}/ledgers"

    def get(self, ledger_id: str, valuta_date: str = None, include_cold_balance: bool = False, include_staked_balance: bool = False, include_deposited_balance: bool = False) -> str:
        url = f"{self._base_url}/{ledger_id}/balances/assets?includeColdBalance={str(include_cold_balance).lower()}&includeStakedBalance={str(include_staked_balance).lower()}&includeDepositedBalance={str(include_deposited_balance).lower()}"

        if valuta_date is not None:
            url = f"{url}&date={valuta_date}"
            
        response = requests.get(url=url, headers=self._authenticator.get_base_header())        

        responseJson = return_or_raise(response)
        return responseJson    