import requests

from attr import define
from .response_handler import return_or_raise
from ..auth import Authenticator

@define
class Staking:
    _authenticator: Authenticator
    _base_url: str

    def __init__(self, authenticator: Authenticator):
        self._authenticator = authenticator
        self._base_url = f"{authenticator.credentials.base_url}/staking"

    def list_intents(self, next_page_token: str = None, limit: str = "100", sort: str = None) -> str:
        url = f"{self._base_url }/intents"
        params = {}
        params['limit'] = limit

        if sort is not None:
            params['sort'] = sort

        if next_page_token is not None:
            params['pageToken'] = next_page_token
        
        response = requests.get(url=url, headers=self._authenticator.get_base_header(), params=params)
        return return_or_raise(response)
    