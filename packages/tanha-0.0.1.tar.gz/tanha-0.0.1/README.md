# tanha

Platform SDK for building autonomous agent systems.

> This package is under active development by [Synth Laboratories](https://usesynth.ai).

## Installation

```bash
pip install tanha
```

## Status

This package is in early planning. Watch this space.
