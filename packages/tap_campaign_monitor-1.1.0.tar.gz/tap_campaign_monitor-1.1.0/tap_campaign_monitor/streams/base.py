import inspect
import singer
import singer.utils
import singer.metrics
import dateutil.parser
import os
import pytz

from singer import metadata as meta
from singer.transform import Transformer, VALID_DATETIME_FORMATS, \
    NO_INTEGER_DATETIME_PARSING, UNIX_SECONDS_INTEGER_DATETIME_PARSING, \
    unix_seconds_to_datetime, unix_milliseconds_to_datetime
from singer.utils import strftime

from tap_campaign_monitor.state import incorporate, save_state, \
    get_last_record_value_for_table

LOGGER = singer.get_logger()


def strptime_with_timezone(dtimestr, timezone):
    d_object = dateutil.parser.parse(dtimestr)

    if d_object.tzinfo is None:
        d_object = timezone.localize(d_object)

    d_object = d_object.astimezone(pytz.UTC)

    return d_object


def string_to_datetime(value, timezone):
    try:
        return strftime(strptime_with_timezone(value, timezone))
    except Exception as ex:
        LOGGER.exception(ex)
        LOGGER.warning("%s, (%s)", ex, value)
        return None


def is_stream_selected(stream):
    stream_metadata = meta.to_map(stream.metadata)

    selected = meta.get(stream_metadata, (), 'selected')
    inclusion = meta.get(stream_metadata, (), 'inclusion')
    if inclusion == 'unsupported':
        return False
    if selected is not None:
        return selected

    return inclusion == 'automatic'


class CampaignMonitorTransformer(Transformer):
    def __init__(self, timezone, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.timezone = timezone

    def _transform_datetime(self, value):
        if value is None or value == "":
            return None  # Short circuit in the case of null or empty string

        if self.integer_datetime_fmt not in VALID_DATETIME_FORMATS:
            raise Exception("Invalid integer datetime parsing option")

        if self.integer_datetime_fmt == NO_INTEGER_DATETIME_PARSING:
            return string_to_datetime(value, self.timezone)
        else:
            try:
                if self.integer_datetime_fmt == UNIX_SECONDS_INTEGER_DATETIME_PARSING:  # noqa
                    return unix_seconds_to_datetime(value)
                else:
                    return unix_milliseconds_to_datetime(value)
            except:
                return string_to_datetime(value, self.timezone)


class BaseStream:
    KEY_PROPERTIES = ['id']
    API_METHOD = 'GET'
    TABLE = None
    REQUIRES = []
    REPLICATION_METHOD = 'FULL_TABLE'
    REPLICATION_KEYS = []
    PARENT = ''

    def __init__(self, config, state, catalog, client):
        self.config = config
        self.state = state
        self.catalog = catalog
        self.client = client
        self.substreams = []

    def get_class_path(self):
        return os.path.dirname(inspect.getfile(self.__class__))

    def load_schema_by_name(self, name):
        return singer.utils.load_json(
            os.path.normpath(
                os.path.join(
                    self.get_class_path(),
                    '../schemas/{}.json'.format(name))))

    def get_schema(self):
        return self.load_schema_by_name(self.TABLE)

    def get_stream_data(self, result):
        """
        Given a result set from Campaign Monitor, return the data
        to be persisted for this stream.
        """
        raise RuntimeError("get_stream_data not implemented!")

    @classmethod
    def requirements_met(cls, catalog):
        selected_streams = [
            s.stream for s in catalog.streams if is_stream_selected(s)
        ]

        return set(cls.REQUIRES).issubset(selected_streams)

    @classmethod
    def matches_catalog(cls, stream_catalog):
        return stream_catalog.stream == cls.TABLE

    def generate_catalog(self):
        schema = self.get_schema()
        mdata = meta.new()

        mdata = meta.write(
            mdata,
            (),
            'inclusion',
            'available'
        )

        mdata = meta.get_standard_metadata(
            schema=schema,
            key_properties=getattr(self, "KEY_PROPERTIES") or [],
            valid_replication_keys=(getattr(self, "REPLICATION_KEYS") or []),
            replication_method=getattr(self, "REPLICATION_METHOD"),
        )
        mdata = meta.to_map(mdata)

        parent_tap_stream_id = getattr(self, 'PARENT', None)
        if parent_tap_stream_id:
            mdata = meta.write(mdata, (), 'parent-tap-stream-id', parent_tap_stream_id)

        for field_name, field_schema in schema.get('properties').items():
            inclusion = 'available'

            if field_name in self.KEY_PROPERTIES:
                inclusion = 'automatic'

            mdata = meta.write(
                mdata,
                ('properties', field_name),
                'inclusion',
                inclusion
            )

        return [{
            'tap_stream_id': self.TABLE,
            'stream': self.TABLE,
            'key_properties': self.KEY_PROPERTIES,
            'schema': self.get_schema(),
            'metadata': meta.to_list(mdata)
        }]

    def write_schema(self):
        singer.write_schema(
            self.catalog.stream,
            self.catalog.schema.to_dict(),
            key_properties=self.catalog.key_properties)

    def transform_record(self, record):
        with CampaignMonitorTransformer(self.client.timezone) as tx:
            metadata = {}

            if self.catalog.metadata is not None:
                metadata = meta.to_map(self.catalog.metadata)

            return tx.transform(
                record,
                self.catalog.schema.to_dict(),
                metadata)

    def sync(self, substreams=None):
        LOGGER.info('Syncing stream {} with {}'
                    .format(self.catalog.tap_stream_id,
                            self.__class__.__name__))

        self.write_schema()

        return self.sync_data(substreams=substreams)

    def sync_data(self, substreams=None):
        if substreams is None:
            substreams = []

        table = self.TABLE
        url = (
            'https://api.createsend.com/api/v3.2{api_path}'.format(
                api_path=self.api_path))

        result = self.client.make_request(url, self.API_METHOD)

        data = self.get_stream_data(result)

        with singer.metrics.record_counter(endpoint=table) as counter:
            for index, obj in enumerate(data):
                LOGGER.info("On {} of {}".format(index, len(data)))

                singer.write_records(
                    table,
                    [obj])

                counter.increment()

                for substream in substreams:
                    substream.sync_data(parent=obj)


class ChildStream(BaseStream):

    def get_parent_id(self, parent):
        raise NotImplementedError('get_parent_id is not implemented!')

    def get_api_path_for_child(self, parent):
        raise NotImplementedError(
            'get_api_path_for_child is not implemented!')

    def sync_data(self, parent=None):
        if parent is None:
            raise RuntimeError('Cannot sync a subobject of null!')

        table = self.TABLE
        url = (
            'https://api.createsend.com/api/v3.2{api_path}'.format(
                api_path=self.get_api_path_for_child(parent)))

        result = self.client.make_request(url, self.API_METHOD)

        data = self.get_stream_data(result)

        with singer.metrics.record_counter(endpoint=table) as counter:
            for obj in data:
                singer.write_records(
                    table,
                    [self.incorporate_parent_id(obj, parent)])

                counter.increment()


class PaginatedChildStream(ChildStream):

    def sync_data(self, parent=None):
        if parent is None:
            raise RuntimeError('Cannot sync a subobject of null!')

        table = self.TABLE

        has_data = True
        page = 1
        page_size = 1000
        total_pages = -1

        while has_data:
            url = (
                'https://api.createsend.com/api/v3.2{api_path}'.format(
                    api_path=self.get_api_path_for_child(parent)))

            params = {
                'page': page,
                'pagesize': page_size,
            }

            result = self.client.make_request(
                url, self.API_METHOD, params=params)

            total_pages = result.get('NumberOfPages')

            LOGGER.info("Syncing page {} of {}".format(page, total_pages))

            data = self.get_stream_data(result)

            with singer.metrics.record_counter(endpoint=table) as counter:
                for obj in data:
                    singer.write_records(
                        table,
                        [self.incorporate_parent_id(obj, parent)])

                    counter.increment()

            if page >= total_pages:
                has_data = False

            else:
                page = page + 1


class DatePaginatedChildStream(ChildStream):

    def sync_data(self, parent=None):
        if parent is None:
            raise RuntimeError('Cannot sync a subobject of null!')

        table = self.TABLE

        has_data = True
        page = 1
        page_size = 1000
        total_pages = -1

        state_key = "{}.{}".format(self.get_parent_id(parent), table)

        start_date = get_last_record_value_for_table(self.state, state_key)

        while has_data:
            url = (
                'https://api.createsend.com/api/v3.2{api_path}'.format(
                    api_path=self.get_api_path_for_child(parent)))

            params = {
                'page': page,
                'pagesize': page_size,
                'orderfield': 'date',
                'orderdirection': 'asc',
            }

            if start_date is not None:
                params['date'] = start_date

            result = self.client.make_request(
                url, self.API_METHOD, params=params)

            total_pages = result.get('NumberOfPages')

            LOGGER.info("Syncing page {} of {}".format(page, total_pages))

            data = self.get_stream_data(result)

            with singer.metrics.record_counter(endpoint=table) as counter:
                for obj in data:
                    to_write = self.incorporate_parent_id(obj, parent)

                    singer.write_records(
                        table,
                        [to_write])

                    self.state = incorporate(self.state,
                                             state_key,
                                             'Date',
                                             to_write.get('Date'))

                    counter.increment()

            save_state(self.state)

            if page >= total_pages:
                has_data = False

            else:
                page = page + 1
