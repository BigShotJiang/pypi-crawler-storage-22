"""
CLI module entry point for python -m tapps_agents.cli
"""
from .main import main

if __name__ == "__main__":
    main()

