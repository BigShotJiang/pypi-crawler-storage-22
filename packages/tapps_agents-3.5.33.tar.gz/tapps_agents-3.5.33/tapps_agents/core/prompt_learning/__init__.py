"""Prompt learning system for Cursor Skills integration."""

