"""
Pluggable validators for project-specific validation.
"""

