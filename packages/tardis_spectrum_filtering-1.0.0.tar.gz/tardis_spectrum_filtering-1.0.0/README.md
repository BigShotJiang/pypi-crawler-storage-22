# spectra-filtering


[![image](https://img.shields.io/pypi/v/spectra-filtering.svg)](https://pypi.python.org/pypi/spectra-filtering)
[![image](https://img.shields.io/conda/vn/conda-forge/spectra-filtering.svg)](https://anaconda.org/conda-forge/spectra-filtering)


**Package used to apply telescope filters to spectra from Stars or Supernovae**


-   Free software: MIT License
