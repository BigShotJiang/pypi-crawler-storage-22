# Welcome to TARDIS_Spectrum_Filtering


[![image](https://img.shields.io/pypi/v/TARDIS_Spectrum_Filtering.svg)](https://pypi.python.org/pypi/TARDIS_Spectrum_Filtering)


**Package used to apply telescope filters to spectra from Stars or Supernovae**


-   Free software: MIT License
-   Documentation: <https://ClydeME.github.io/TARDIS_Spectrum_Filtering>
    

## Features

-   TODO
