# Targon gRPC protocol definitions.
