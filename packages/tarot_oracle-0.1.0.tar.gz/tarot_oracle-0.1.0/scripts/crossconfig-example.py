from crossconfig import get_config

# load the config
config = get_config("tarot-oracle")
config.load()

# get a path for a subdirectory
subdir_path = config.path("subdir")

# set a setting
config.set("my_setting", "my_value")

# save and reload the config
config.save()
[config.unset(key) for key in config.list()]
assert len(config.list()) == 0
config.load()

# get a setting
assert config.get("my_setting") == "my_value"

# unset a setting
config.unset("my_setting")

# save the config
config.save()
