"""Integration tests for Task Crusade MCP."""
