Create a named checkpoint in .agent-files.

Run: taskman describe "$ARGUMENTS"

Report the revision ID.
