Fetch file content at all revisions in range.

Arguments: <file> <start_rev> [end_rev]

Run: taskman history-batch $ARGUMENTS

Display the output.
