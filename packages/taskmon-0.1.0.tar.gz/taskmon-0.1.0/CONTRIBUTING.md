# Contributing to taskmon

Thank you for your interest in contributing to taskmon! 🎉

## Getting Started

### Prerequisites

- Python 3.8 or higher
- Git
- pip

### Setup Development Environment

1. Fork the repository
2. Clone your fork:
   ```bash
   git clone https://github.com/yourusername/taskmon.git
   cd taskmon
   ```

3. Install in development mode:
   ```bash
   pip install -e ".[dev]"
   ```

4. Run tests to verify:
   ```bash
   pytest tests/ -v
   ```

## Development Workflow

### Making Changes

1. Create a new branch:
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. Make your changes

3. Add tests for new functionality

4. Run tests:
   ```bash
   pytest tests/ -v
   ```

5. Format code:
   ```bash
   black taskmon/
   flake8 taskmon/
   ```

6. Commit your changes:
   ```bash
   git commit -m "Add feature: description"
   ```

7. Push to your fork:
   ```bash
   git push origin feature/your-feature-name
   ```

8. Create a Pull Request

## Code Style

- Follow PEP 8
- Use Black for formatting (line length: 100)
- Add type hints where possible
- Write docstrings for all public functions

## Testing

- Write tests for all new features
- Maintain or improve code coverage
- Test on Python 3.8, 3.9, 3.10, 3.11, 3.12

## Documentation

- Update README.md if adding features
- Add examples for new functionality
- Update CHANGELOG.md

## Commit Messages

Use clear, descriptive commit messages:

- `feat: add new feature`
- `fix: resolve bug in monitoring`
- `docs: update README`
- `test: add tests for monitor`
- `refactor: improve performance`

## Pull Request Process

1. Update documentation
2. Add tests
3. Update CHANGELOG.md
4. Ensure all tests pass
5. Request review

## Questions?

Open an issue or reach out to maintainers.

## License

By contributing, you agree that your contributions will be licensed under the MIT License.
