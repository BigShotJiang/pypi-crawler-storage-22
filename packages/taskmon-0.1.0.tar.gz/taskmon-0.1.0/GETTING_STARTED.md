# 🚀 Getting Started with taskmon

## 1️⃣ Installation (1 minute)

```bash
cd taskmon
pip install -e .
```

That's it! ✅

---

## 2️⃣ Quick Test (30 seconds)

```bash
python examples/simple_example.py
```

You'll see:
```
┌─ 🚀 quick_example() started
│  📊 Baseline: CPU 2.3% | MEM 156.2MB | THR 4
  ├─ 🚀 Step 1: Load Data started
    └─ ✅ Step 1: Load Data completed in 0.30s
       📊 CPU: 3.1% [███░░░░░░░] | MEM: 🟢 +0.8MB
  
  └─ ✅ quick_example() completed in 1.02s
     📊 CPU: 5.2% | MEM: 🟢 +1.2MB
```

---

## 3️⃣ Add to Your Code (2 minutes)

### Before:
```python
def process_data():
    data = load_from_db()
    processed = transform(data)
    save_results(processed)
```

### After:
```python
from taskmon import monitor, track

@monitor()
def process_data():
    with track("Load Data"):
        data = load_from_db()
    
    with track("Transform"):
        processed = transform(data)
    
    with track("Save"):
        save_results(processed)
```

**That's it!** Run your code and see the monitoring output.

---

## 4️⃣ Real-World Example - Space Mission Data Pipeline

### Your Original Code:

```python
def collect_telemetry_data():
    print("Starting telemetry data collection")
    
    active_missions = config.get('ACTIVE_MISSIONS', 'apollo,voyager,hubble')
    mission_ids = active_missions.split(',')
    
    satellites = get_satellite_config_cached()
    total_signals = get_total_signal_count(mission_ids)
    
    chunk_size = 50000
    for offset in range(0, total_signals, chunk_size):
        process_signal_chunk(offset, chunk_size, mission_ids, satellites)
```

### Add Monitoring (Just add decorators!):

```python
from taskmon import monitor, track

@monitor()  # ← Add this
def collect_telemetry_data():
    print("Starting telemetry data collection")
    
    with track("Configuration"):  # ← Track sections
        active_missions = config.get('ACTIVE_MISSIONS', 'apollo,voyager,hubble')
        mission_ids = active_missions.split(',')
    
    with track("Load Satellites"):
        satellites = get_satellite_config_cached()
    
    with track("Count Signals"):
        total_signals = get_total_signal_count(mission_ids)
    
    chunk_size = 50000
    for offset in range(0, total_signals, chunk_size):
        chunk_num = offset // chunk_size + 1
        
        with track(f"Chunk {chunk_num}"):
            process_signal_chunk(offset, chunk_size, mission_ids, satellites)
```

### What You Get:

```
┌─ 🚀 collect_telemetry_data() started
  ├─ 🚀 Configuration started
    └─ ✅ Configuration completed in 0.10s
       📊 CPU: 2.1% | MEM: 🟢 +0.1MB

  ├─ 🚀 Load Satellites started
    └─ ✅ Load Satellites completed in 0.15s
       📊 CPU: 3.2% | MEM: 🟢 +1.2MB

  ├─ 🚀 Count Signals started
    └─ ✅ Count Signals completed in 0.23s
       📊 CPU: 5.1% | MEM: 🟢 +0.1MB

  ├─ 🚀 Chunk 1 started
    └─ ✅ Chunk 1 completed in 12.34s
       📊 CPU: 45.2% | MEM: 🟢 +2.3MB

  ├─ 🚀 Chunk 2 started
    └─ ✅ Chunk 2 completed in 11.89s
       📊 CPU: 43.1% | MEM: 🔴 +125.6MB  <-- MEMORY LEAK HERE!

  └─ ✅ collect_telemetry_data() completed in 45.67s
```

**You immediately see where the memory leak is!** 🔴

---

## 5️⃣ Find the Leak - Deep Dive

Add monitoring to the leaking function:

```python
@monitor()
def process_signal_chunk(offset, limit, mission_ids, satellites):
    
    with track("Database Queries"):
        signal_df = telemetry_to_dataframe(Database.raw(signal_query))
        orbit_df = telemetry_to_dataframe(Database.raw(orbit_query))
    
    with track("DataFrame Merge"):
        df = signal_df.merge(orbit_df, on='signal_id')
        # Oops! Not cleaning up signal_df and orbit_df
    
    with track("Processing"):
        for row in df.itertuples():
            enqueue_task(row)
```

**Output:**
```
  ├─ 🚀 DataFrame Merge started
    └─ ✅ DataFrame Merge completed in 0.23s
       📊 CPU: 25.6% | MEM: 🔴 +245.2MB  <-- LEAK IS HERE!
```

**Fix:**
```python
with track("DataFrame Merge"):
    df = signal_df.merge(orbit_df, on='signal_id')
    
    # Fix: Clean up!
    del signal_df, orbit_df
    gc.collect()
```

**New Output:**
```
  ├─ 🚀 DataFrame Merge started
    └─ ✅ DataFrame Merge completed in 0.23s
       📊 CPU: 25.6% | MEM: 🟢 +2.1MB  <-- FIXED! ✅
```

---

## 6️⃣ View Statistics

```python
from taskmon import print_summary

# After your code runs
print_summary()
```

**Output:**
```
================================================================================
📊 FUNCTION MONITORING SUMMARY
================================================================================

Function                                    Calls   Total Time   Avg Time   Failures
--------------------------------------------------------------------------------
mission.process_signal_chunk                  25      312.45s     12.498s      0 (0.0%)
mission.telemetry_to_dataframe               150       45.67s      0.304s      2 (1.3%)
mission.get_satellite_config_cached            1        0.15s      0.150s      0 (0.0%)

================================================================================
```

---

## 7️⃣ Run Examples

### Simple Example
```bash
python examples/simple_example.py
```

### All Examples
```bash
python examples/comprehensive_examples.py
```

### Space Mission Demo
```bash
python examples/space_mission_example.py
```

This shows:
- Normal version (no leak) ✅
- Leaky version (with leak) 🔴
- Side-by-side comparison

### Benchmark (Performance Test)
```bash
python examples/benchmark.py
```

Shows overhead is < 1%

---

## 8️⃣ Using Makefile

```bash
# Install
make install

# Run tests
make test

# Run example
make example

# Run demo
make demo

# See all commands
make help
```

---

## 9️⃣ Common Patterns

### Pattern 1: Monitor Everything
```python
from taskmon import monitor

@monitor()
def my_function():
    pass
```

### Pattern 2: Monitor Sections Only
```python
from taskmon import track

def my_function():
    with track("critical_section"):
        # Only monitor this part
        pass
```

### Pattern 3: Both (Recommended)
```python
from taskmon import monitor, track

@monitor()
def my_function():
    with track("section_1"):
        pass
    
    with track("section_2"):
        pass
```

---

## 🔟 Memory Leak Detection Guide

### 🟢 Green (< 10MB) - Normal
```
MEM: 🟢 +2.3MB  ← Good! No leak
```

### 🟡 Yellow (10-100MB) - Monitor
```
MEM: 🟡 +45.6MB  ← Watch this function
```

### 🔴 Red (> 100MB) - LEAK!
```
MEM: 🔴 +245.3MB  ← FIX THIS! Memory leak!
```

**What to do:**
1. Find the 🔴 red section
2. Add `gc.collect()` after large operations
3. Use `del` to remove unused DataFrames
4. Check for global variable accumulation

---

## 📚 Next Steps

1. ✅ Read [README.md](README.md) for full documentation
2. ✅ Check [INSTALLATION.md](INSTALLATION.md) for Turkish guide
3. ✅ Browse [examples/](examples/) for more use cases
4. ✅ Run [tests/](tests/) to verify installation

---

## ❓ FAQ

**Q: Does it slow down my code?**
A: No, overhead is < 1%. Run `make benchmark` to see.

**Q: Can I use in production?**
A: Yes! It's thread-safe and lightweight.

**Q: How do I disable monitoring?**
A: Just remove the `@monitor()` decorator.

**Q: Can I monitor async functions?**
A: Currently only sync functions. Async support planned.

**Q: Does it work with Celery?**
A: Yes! Just add `@monitor()` to your tasks.

---

## 🎉 You're Ready!

Start monitoring your code:

```python
from taskmon import monitor, track

@monitor()
def your_function():
    with track("your_section"):
        # your code
        pass
```

**That's all you need!** 🚀

---

## 💡 Pro Tips

1. **Start small**: Add to one function first
2. **Track sections**: Use `track()` to isolate problems
3. **Check statistics**: Use `print_summary()` after runs
4. **Look for 🔴**: Red indicators = leaks to fix
5. **Benchmark first**: Run without monitoring, then with

---

## 🆘 Need Help?

- 📖 Full docs: [README.md](README.md)
- 🇹🇷 Turkish guide: [INSTALLATION.md](INSTALLATION.md)
- 💻 Examples: [examples/](examples/)
- 🐛 Issues: GitHub Issues
- 💬 Questions: GitHub Discussions

---

**Happy monitoring! 🎊**
