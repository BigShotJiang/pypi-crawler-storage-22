# 📦 taskmon - Kurulum ve Kullanım Kılavuzu

## 🎯 Neden taskmon?

**SORUN**: Veri işleme kodunuzda memory leak var ama hangi fonksiyonda olduğunu bilmiyorsunuz.

**ÇÖZÜM**: `taskmon` ile her fonksiyonu ve kod bloğunu izleyebilir, hangi fonksiyonun memory leak yaptığını 🔴 kırmızı gösterge ile anında görebilirsiniz!

## ⚡ Hızlı Kurulum

### 1. Package'ı Kurun

```bash
cd taskmon
pip install -e .
```

### 2. Kodunuza Ekleyin

**ÖNCESİ:**
```python
def process_signal_chunk(offset, limit, satellites):
    # Fetch data
    signal_df = telemetry_to_dataframe(Database.raw(signal_query))
    orbit_df = telemetry_to_dataframe(Database.raw(orbit_query))
    
    # Merge
    df = signal_df.merge(orbit_df, on='signal_id')
    
    # Process
    for row in df.itertuples():
        enqueue_task(row)
    
    return len(df)
```

**SONRASI:**
```python
from taskmon import monitor, track

@monitor()  # ← Sadece bu satırı ekleyin!
def process_signal_chunk(offset, limit, satellites):
    
    with track("Database Queries"):  # ← Bölümleri izleyin
        signal_df = telemetry_to_dataframe(Database.raw(signal_query))
        orbit_df = telemetry_to_dataframe(Database.raw(orbit_query))
    
    with track("DataFrame Merge"):
        df = signal_df.merge(orbit_df, on='signal_id')
    
    with track("Task Enqueueing"):
        for row in df.itertuples():
            enqueue_task(row)
    
    return len(df)
```

**ÇIKTI:**
```
┌─ 🚀 process_signal_chunk() started [call_1_1738574400123]
│  📊 Baseline: CPU 2.3% | MEM 456.2MB | THR 4
  ├─ 🚀 Database Queries started
    └─ ✅ Database Queries completed in 0.45s
       📊 CPU: 15.2% [█████░░░░░] | MEM: 🟢 +12.3MB
  
  ├─ 🚀 DataFrame Merge started
    └─ ✅ DataFrame Merge completed in 0.23s
       📊 CPU: 25.6% [████████░░] | MEM: 🔴 +245.2MB  <-- LEAK BU SATIRDA!
  
  ├─ 🚀 Task Enqueueing started
    └─ ✅ Task Enqueueing completed in 3.12s
       📊 CPU: 45.3% [█████████░] | MEM: 🟢 +1.1MB
  
  └─ ✅ process_signal_chunk() completed in 3.89s
     📊 CPU: 28.7% [███████░░░] | MEM: 🔴 +258.6MB (peak: 714.8MB)
     ⚡ Processed: 50,000 items (12,853.2 items/s)
```

## 🎯 Gerçek Kullanım Örnekleri

### Örnek 1: Mevcut Veri İşleme Kodunuza Entegrasyon

```python
from taskmon import monitor, track
import pandas as pd
import gc

@monitor()
def collect_telemetry_data():
    print("Starting telemetry data collection")
    
    with track("Configuration"):
        active_missions = config.get('ACTIVE_MISSIONS', 'apollo,voyager,hubble')
        mission_ids = active_missions.split(',')
    
    with track("Load Satellites"):
        satellites = get_satellite_config_cached()
    
    with track("Count Signals"):
        total_signals = get_total_signal_count(mission_ids)
        print(f"Total Signals: {total_signals:,}")
    
    chunk_size = 50000
    for offset in range(0, total_signals, chunk_size):
        chunk_num = offset // chunk_size + 1
        
        with track(f"Chunk {chunk_num}"):
            enqueued = process_signal_chunk(
                offset, chunk_size, 
                mission_ids, satellites
            )
            print(f"Chunk {chunk_num}: {enqueued:,} tasks")
```

### Örnek 2: Memory Leak Bulma

**Senaryo**: DataFrame merge'de memory leak var ama bilmiyorsunuz.

```python
from taskmon import monitor, track

@monitor()
def merge_dataframes():
    with track("Load DataFrames"):
        df1 = pd.read_csv("large_file1.csv")
        df2 = pd.read_csv("large_file2.csv")
    
    with track("Merge Operation"):
        # Bug: ara DataFrame'leri temizlemiyoruz
        merged = df1.merge(df2, on='id')
        # df1, df2 hala bellekte!
    
    with track("Process Merged"):
        result = merged.groupby('category').sum()
    
    return result
```

**ÇIKTI:**
```
  ├─ 🚀 Load DataFrames started
    └─ ✅ Load DataFrames completed in 2.34s
       📊 CPU: 25.2% | MEM: 🟡 +245.3MB
  
  ├─ 🚀 Merge Operation started
    └─ ✅ Merge Operation completed in 1.23s
       📊 CPU: 45.6% | MEM: 🔴 +456.7MB  <-- İŞTE LEAK!
  
  ├─ 🚀 Process Merged started
    └─ ✅ Process Merged completed in 0.89s
       📊 CPU: 35.1% | MEM: 🟢 +12.3MB
```

**DÜZELTİLMİŞ KOD:**
```python
@monitor()
def merge_dataframes():
    with track("Load DataFrames"):
        df1 = pd.read_csv("large_file1.csv")
        df2 = pd.read_csv("large_file2.csv")
    
    with track("Merge Operation"):
        merged = df1.merge(df2, on='id')
        
        # FIX: Temizlik yap!
        del df1, df2
        gc.collect()
    
    with track("Process Merged"):
        result = merged.groupby('category').sum()
    
    return result
```

**YENİ ÇIKTI:**
```
  ├─ 🚀 Merge Operation started
    └─ ✅ Merge Operation completed in 1.23s
       📊 CPU: 45.6% | MEM: 🟢 +12.4MB  <-- Artık leak yok!
```

### Örnek 3: Celery Task'leri İzleme

```python
from celery import shared_task
from taskmon import monitor, track

@shared_task
@monitor()  # ← Bu kadar basit!
def process_telemetry_task(signal_id, satellite_id, frequency):
    with track("Fetch Data"):
        data = fetch_telemetry(signal_id)
    
    with track("Parse Signal"):
        parsed = parse_signal(data)
    
    with track("Save to DB"):
        save_to_database(parsed)
    
    return parsed
```

### Örnek 4: Statistik Toplama

```python
from taskmon import monitor, print_summary, get_stats

@monitor()
def process_data(data):
    # ... your code
    pass

# Birçok kez çağır
for i in range(100):
    process_data(data[i])

# Özet göster
print_summary()
```

**ÇIKTI:**
```
================================================================================
📊 FUNCTION MONITORING SUMMARY
================================================================================

Function                                    Calls   Total Time   Avg Time   Failures
--------------------------------------------------------------------------------
__main__.process_data                         100      125.23s      1.252s      0 (0.0%)
__main__.fetch_url                            100       45.67s      0.457s      3 (3.0%)
__main__.parse_html                           100       34.12s      0.341s      0 (0.0%)
__main__.save_to_database                     100       23.45s      0.235s      1 (1.0%)

================================================================================
```

## 🔍 Memory Leak Detection

### Nasıl Çalışır?

taskmon her fonksiyonun:
- **Başlangıç memory**'sini kaydeder
- **Bitiş memory**'sini ölçer
- **Delta**yı hesaplar

**Threshold'lar:**
- 🟢 **< 10MB**: Normal (temiz kod)
- 🟡 **10-100MB**: Dikkat (izlenmeli)
- 🔴 **> 100MB**: LEAK! (düzeltilmeli)

### Örnek Leak Tespiti

```python
from taskmon import monitor, track

leaked_data = []

@monitor()
def function_with_leak():
    global leaked_data
    
    with track("Data Loading"):
        data = load_large_dataset()
    
    with track("Processing"):
        # Bug: global'e ekliyoruz, temizlemiyoruz
        leaked_data.append(data)
        result = process(data)
    
    return result

# Her çağrıda memory artar
for i in range(10):
    function_with_leak()
```

**ÇIKTI:**
```
Call 1:  MEM: 🟢 +125.3MB  (İlk yükleme)
Call 2:  MEM: 🔴 +125.1MB  (Leak başladı!)
Call 3:  MEM: 🔴 +125.2MB  (Devam ediyor)
Call 4:  MEM: 🔴 +125.0MB  (Her çağrıda artış)
...
Call 10: MEM: 🔴 +125.3MB  (Toplam ~1.25GB leak!)
```

## 📊 Dashboard Entegrasyonu (İleri Seviye)

### Grafana/Prometheus için

```python
from taskmon import monitor, get_stats
import json

@monitor()
def monitored_task():
    # your code
    pass

# Metrikleri export et
stats = get_stats()
print(json.dumps(stats, indent=2))
```

### Elasticsearch için

```python
from taskmon import monitor
from datetime import datetime
import json

class ElasticsearchExporter:
    def __init__(self, es_client):
        self.es = es_client
    
    def export_stats(self, stats):
        for func_name, metrics in stats.items():
            doc = {
                "timestamp": datetime.now().isoformat(),
                "function": func_name,
                "metrics": metrics
            }
            self.es.index(index="taskmon-metrics", document=doc)
```

## 🎮 Demo Çalıştırma

### Tüm Örnekleri Çalıştır

```bash
python examples/comprehensive_examples.py
```

### İnteraktif Mode

```bash
python examples/comprehensive_examples.py --interactive
```

### Space Mission Demo

```bash
python examples/space_mission_example.py
```

Bu demo:
1. Normal version çalıştırır (leak yok)
2. Leaky version çalıştırır (memory leak var)
3. İkisini karşılaştırır
4. Leak'i highlight eder

## 🧪 Test Etme

```bash
cd taskmon
pytest tests/ -v
```

## 📝 Best Practices

### 1. Her Critical Function'a Ekleyin

```python
@monitor()
def critical_function():
    pass
```

### 2. Uzun Task'leri Bölümlere Ayırın

```python
@monitor()
def long_task():
    with track("step1"):
        # ...
    with track("step2"):
        # ...
    with track("step3"):
        # ...
```

### 3. Memory-Intensive Operasyonları İzleyin

```python
@monitor()
def data_processing():
    with track("Load Large Dataset"):
        df = pd.read_csv("huge_file.csv")
    
    with track("Transform"):
        result = df.groupby(...).agg(...)
        
        # Cleanup
        del df
        gc.collect()
    
    return result
```

### 4. Production'da Kullanın

taskmon çok hafif (< 1% overhead), production'da çalışabilir:

```python
import os
from taskmon import monitor

# Sadece debug modunda monitor et
if os.environ.get('DEBUG') == '1':
    @monitor()
    def my_function():
        pass
else:
    def my_function():
        pass
```

Veya her zaman izleyin ama sadece sorun olduğunda logları inceleyin.

## 🚨 Sorun Giderme

### Renkler görünmüyor?

```bash
export TERM=xterm-256color
```

### Çok fazla output?

Context manager ile sadece istediğiniz yerleri izleyin:

```python
# Tüm fonksiyonu değil
def my_function():
    with track("critical_section"):
        # Sadece burayı izle
        pass
```

### Performance overhead?

- Background thread her 1 saniyede bir sample alır
- Overhead < 1%
- İsterseniz disable edebilirsiniz:

```python
# Geliştirme
@monitor()
def dev_function():
    pass

# Production (decorator'ı kaldır)
def prod_function():
    pass
```

## 🎯 Özet

✅ **Kolay Entegrasyon**: Sadece `@monitor()` ekleyin
✅ **Function-Level Tracking**: Task ID'ye gerek yok
✅ **Memory Leak Detection**: Otomatik tespit
✅ **Visual Output**: Renkli, anlaşılır
✅ **Low Overhead**: < 1% CPU impact
✅ **Production Ready**: Thread-safe, stable

## 📞 Destek

- 🐛 Issue: GitHub Issues
- 💬 Soru: Discussions
- 📧 Email: kadirsmdb@gmail.com

---

**Hemen başlayın! 🚀**

```bash
cd taskmon
pip install -e .
python examples/space_mission_example.py
```
