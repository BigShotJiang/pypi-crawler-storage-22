# 📁 taskmon Project Structure

```
taskmon/
│
├── 📄 README.md                      # Full English documentation
├── 📄 GETTING_STARTED.md             # Quick start guide (step-by-step)
├── 📄 INSTALLATION.md                # Turkish installation guide
├── 📄 QUICKSTART.md                  # 1-minute quick start
├── 📄 CHANGELOG.md                   # Version history
├── 📄 CONTRIBUTING.md                # Contribution guidelines
├── 📄 LICENSE                        # MIT License
│
├── ⚙️  Configuration Files
│   ├── setup.py                      # Package setup (legacy)
│   ├── pyproject.toml                # Modern Python packaging
│   ├── MANIFEST.in                   # Package manifest
│   ├── requirements.txt              # Runtime dependencies
│   ├── requirements-dev.txt          # Development dependencies
│   ├── .gitignore                    # Git ignore rules
│   └── Makefile                      # Common tasks automation
│
├── 📦 taskmon/                       # Main package
│   ├── __init__.py                   # Package initialization & public API
│   └── monitor.py                    # Core monitoring functionality
│       ├── FunctionMetrics           # Data class for metrics
│       ├── FunctionMonitor           # Main monitoring engine
│       ├── @monitor()                # Decorator for functions
│       ├── track()                   # Context manager for sections
│       ├── get_stats()               # Get statistics
│       ├── print_summary()           # Print summary report
│       └── clear_stats()             # Clear statistics
│
├── 📚 examples/                      # Usage examples
│   ├── __init__.py
│   ├── simple_example.py             # 30-second quick test
│   ├── comprehensive_examples.py     # All features demonstration
│   ├── space_mission_example.py      # Real-world use case
│   └── benchmark.py                  # Performance benchmarks
│
├── 🧪 tests/                         # Test suite
│   ├── __init__.py
│   └── test_monitor.py               # Core functionality tests
│
└── 📖 docs/                          # Documentation (empty for now)
```

---

## 🎯 Key Files Explained

### Documentation

| File | Purpose | Audience |
|------|---------|----------|
| `README.md` | Complete documentation | All users |
| `GETTING_STARTED.md` | Step-by-step tutorial | New users |
| `INSTALLATION.md` | Turkish guide with examples | Turkish users |
| `QUICKSTART.md` | 1-minute start | Impatient users 😄 |
| `CHANGELOG.md` | Version history | Maintainers & users |
| `CONTRIBUTING.md` | How to contribute | Contributors |

### Core Package

| File | Purpose | Lines | Key Classes/Functions |
|------|---------|-------|----------------------|
| `taskmon/__init__.py` | Public API | ~40 | Exports main functions |
| `taskmon/monitor.py` | Monitoring engine | ~600 | `FunctionMonitor`, `@monitor()`, `track()` |

### Examples

| File | Purpose | Demonstrates |
|------|---------|--------------|
| `simple_example.py` | Quick test | Basic usage |
| `comprehensive_examples.py` | All features | Everything |
| `space_mission_example.py` | Real-world | Data pipeline use case |
| `benchmark.py` | Performance | Overhead measurement |

### Configuration

| File | Purpose |
|------|---------|
| `setup.py` | Legacy packaging (for pip install) |
| `pyproject.toml` | Modern packaging (PEP 517/518) |
| `requirements.txt` | Runtime dependencies (psutil) |
| `requirements-dev.txt` | Dev tools (pytest, black, etc.) |
| `Makefile` | Task automation |

---

## 🚀 Usage Flow

```
1. User reads GETTING_STARTED.md
   ↓
2. Installs: pip install -e .
   ↓
3. Runs: python examples/simple_example.py
   ↓
4. Adds to their code:
   from taskmon import monitor, track
   
   @monitor()
   def my_function():
       with track("section"):
           pass
   ↓
5. Finds memory leaks with 🔴 indicators
   ↓
6. Fixes issues
   ↓
7. Production ready! ✅
```

---

## 🔧 Development Flow

```
1. Clone repo
   ↓
2. make install-dev
   ↓
3. Make changes
   ↓
4. make test
   ↓
5. make format
   ↓
6. make lint
   ↓
7. git commit
   ↓
8. Create PR
```

---

## 📦 Package Structure Details

### taskmon/monitor.py Components

```python
# Data Classes
├── FunctionMetrics              # Stores metrics for one function call
│   ├── function_name
│   ├── duration_seconds
│   ├── cpu_*
│   ├── memory_*
│   └── status

# Main Engine
├── FunctionMonitor              # Core monitoring class
│   ├── _active_calls           # Currently running functions
│   ├── _completed_calls        # Historical data
│   ├── _function_stats         # Aggregated statistics
│   ├── start_function()        # Begin monitoring
│   ├── end_function()          # End monitoring
│   └── _monitoring_loop()      # Background thread

# Public API
├── @monitor()                   # Function decorator
├── track()                      # Context manager
├── get_stats()                  # Get statistics
├── print_summary()              # Print report
└── clear_stats()                # Clear data
```

### Example: How @monitor() Works

```python
@monitor()
def my_function():
    pass

# Internally translates to:
def my_function():
    call_id = _monitor.start_function(...)
    try:
        result = original_function()
        return result
    finally:
        _monitor.end_function(call_id, ...)
```

---

## 🧪 Testing Structure

```
tests/
└── test_monitor.py
    ├── test_basic_monitor()           # Basic decorator
    ├── test_monitor_with_items()      # Item counting
    ├── test_track_context_manager()   # Context manager
    ├── test_nested_functions()        # Nested calls
    ├── test_error_handling()          # Error tracking
    ├── test_memory_tracking()         # Memory measurement
    ├── test_active_calls()            # Active call tracking
    ├── test_multiple_calls()          # Statistics
    └── test_clear_stats()             # Clear functionality
```

Run with:
```bash
make test
# or
pytest tests/ -v
```

---

## 📊 File Statistics

| Category | Files | Lines of Code |
|----------|-------|---------------|
| Core Package | 2 | ~650 |
| Examples | 5 | ~800 |
| Tests | 1 | ~150 |
| Documentation | 7 | ~2000 |
| **Total** | **15** | **~3600** |

---

## 🎨 Design Principles

### 1. Simple API
```python
# Just two things to remember:
from taskmon import monitor, track

@monitor()           # For functions
def func():
    with track():    # For sections
        pass
```

### 2. Zero Configuration
- No config files
- No setup needed
- Works out of the box

### 3. Visual Feedback
```
└─ ✅ completed in 2.34s
   📊 CPU: 45.6% | MEM: 🔴 +456.7MB
```

### 4. Low Overhead
- Background thread samples every 1s
- < 1% CPU overhead
- Negligible memory impact

### 5. Thread-Safe
- Uses threading.Lock
- Safe for multi-threaded apps
- Works with Celery

---

## 🚢 Release Checklist

When releasing a new version:

- [ ] Update `CHANGELOG.md`
- [ ] Update version in `setup.py`
- [ ] Update version in `pyproject.toml`
- [ ] Update version in `taskmon/__init__.py`
- [ ] Run tests: `make test`
- [ ] Run lint: `make lint`
- [ ] Run format: `make format`
- [ ] Build package: `make build`
- [ ] Test package locally
- [ ] Create git tag: `git tag v0.1.0`
- [ ] Push to GitHub: `git push --tags`
- [ ] Publish to PyPI: `make publish`
- [ ] Update documentation if needed

---

## 📈 Future Roadmap

### v0.2.0 (Planned)
- [ ] Redis backend for distributed monitoring
- [ ] Async function support
- [ ] Custom thresholds configuration
- [ ] JSON export for metrics

### v0.3.0 (Planned)
- [ ] Web dashboard
- [ ] Prometheus metrics export
- [ ] Elasticsearch integration
- [ ] Email/Slack alerts

### v1.0.0 (Planned)
- [ ] Stable API
- [ ] Full async support
- [ ] Plugin system
- [ ] Complete documentation site

---

## 🤝 Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for:
- Development setup
- Code style guidelines
- Testing requirements
- Pull request process

---

## 📞 Support

- 🐛 **Issues**: GitHub Issues
- 💬 **Discussions**: GitHub Discussions
- 📧 **Email**: kadirsmdb@gmail.com
- 📖 **Docs**: README.md

---

## 📝 License

MIT License - see [LICENSE](LICENSE) file

---

**Project Status**: ✅ Production Ready

**Current Version**: 0.1.0

**Last Updated**: 2026-02-03
