# 🚀 taskmon Quick Start

## Installation

```bash
cd taskmon
pip install -e .
```

## 1-Minute Usage

```python
from taskmon import monitor, track

@monitor()
def my_function():
    with track("section1"):
        # your code
        pass
    
    with track("section2"):
        # more code
        pass

my_function()
```

## Run Examples

```bash
# Run all examples
python examples/comprehensive_examples.py

# Interactive mode
python examples/comprehensive_examples.py --interactive

# Space mission demo
python examples/space_mission_example.py
```

## Use in Your Code

### Option 1: Decorator (Best for functions)

```python
from taskmon import monitor

@monitor()
def process_data(items):
    results = []
    for item in items:
        results.append(transform(item))
    return results
```

### Option 2: Context Manager (Best for code sections)

```python
from taskmon import monitor, track

@monitor()
def data_pipeline():
    with track("load_data"):
        data = load_from_db()
    
    with track("process"):
        processed = process_data(data)
    
    with track("save"):
        save_to_db(processed)
```

### Option 3: Mixed (Recommended)

```python
from taskmon import monitor, track

@monitor()
def plan_mission_data_collection():
    with track("Configuration"):
        config = load_config()
    
    with track("Fetch Signals"):
        signals = get_signals()
    
    for i, chunk in enumerate(chunks(signals, 50000)):
        with track(f"Process Chunk {i}"):
            process_chunk(chunk)
```

## See Results

Output shows:
- ✅/❌ Success/failure status
- ⏱️ Duration for each section
- 📊 CPU and memory usage
- 🔴/🟡/🟢 Memory leak indicators
- 📈 Throughput (items/sec)

```
┌─ 🚀 plan_mission_data_collection() started
  ├─ 🚀 Configuration started
    └─ ✅ Configuration completed in 0.10s
       📊 CPU: 2.1% | MEM: 🟢 +1.2MB
  
  ├─ 🚀 Process Chunk 1 started
    └─ ✅ Process Chunk 1 completed in 12.34s
       📊 CPU: 45.2% | MEM: 🟢 +2.3MB
  
  ├─ 🚀 Process Chunk 2 started
    └─ ✅ Process Chunk 2 completed in 11.89s
       📊 CPU: 43.1% | MEM: 🔴 +125.6MB  <-- LEAK!
```

## Get Statistics

```python
from taskmon import print_summary, get_stats

# After running your code
print_summary()

# Or get specific function stats
stats = get_stats("my_module.my_function")
print(f"Calls: {stats['total_calls']}")
print(f"Avg CPU: {stats['avg_cpu']:.1f}%")
```

## Find Memory Leaks

Look for 🔴 red indicators:
- 🟢 < 10MB = Normal
- 🟡 10-100MB = Monitor
- 🔴 > 100MB = Leak!

## Tips

1. **Add to existing code**: Just add `@monitor()` decorator
2. **Track sections**: Use `with track("name")` for code blocks
3. **No configuration**: Works out of the box
4. **Low overhead**: < 1% CPU impact
5. **Thread-safe**: Works in multi-threaded apps

## Need Help?

See full documentation in `README.md`

---

**That's it! You're monitoring!** 🎉
