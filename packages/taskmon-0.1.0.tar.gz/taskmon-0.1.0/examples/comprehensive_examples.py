#!/usr/bin/env python3
"""
taskmon Examples - Comprehensive demonstration of all features
"""

import time
import random
from taskmon import monitor, track, print_summary, get_stats


# ============================================================================
# Example 1: Basic Function Monitoring
# ============================================================================

@monitor()
def basic_function():
    """Simple function with monitoring"""
    time.sleep(0.5)
    return "done"


# ============================================================================
# Example 2: Function with Items Processing
# ============================================================================

@monitor()
def process_items(items):
    """Process a list of items - automatically tracks count"""
    result = []
    for item in items:
        time.sleep(0.01)  # Simulate work
        result.append(item * 2)
    return result


# ============================================================================
# Example 3: Nested Functions
# ============================================================================

@monitor()
def parent_function():
    """Parent function that calls other monitored functions"""
    child_function_1()
    child_function_2()
    return "parent done"


@monitor()
def child_function_1():
    """First child function"""
    time.sleep(0.2)
    return "child 1 done"


@monitor()
def child_function_2():
    """Second child function"""
    time.sleep(0.3)
    return "child 2 done"


# ============================================================================
# Example 4: Section Tracking
# ============================================================================

@monitor()
def data_pipeline():
    """Complex pipeline with multiple tracked sections"""
    
    # Section 1: Load data
    with track("load_data"):
        time.sleep(0.5)
        data = list(range(1000))
    
    # Section 2: Process data
    with track("process_data"):
        time.sleep(0.3)
        processed = [x * 2 for x in data]
    
    # Section 3: Validate
    with track("validate"):
        time.sleep(0.2)
        valid = all(x > 0 for x in processed)
    
    # Section 4: Save
    with track("save_results"):
        time.sleep(0.4)
        # Simulate saving
    
    return processed


# ============================================================================
# Example 5: Memory Intensive Operation
# ============================================================================

@monitor()
def memory_intensive():
    """Function that uses significant memory"""
    # Allocate large list
    large_data = [random.random() for _ in range(1000000)]
    
    # Process it
    time.sleep(0.5)
    result = sum(large_data) / len(large_data)
    
    return result


# ============================================================================
# Example 6: Simulated Memory Leak
# ============================================================================

leaked_data = []

@monitor()
def memory_leak_simulation():
    """Function that leaks memory (intentionally for demo)"""
    global leaked_data
    
    # "Leak" memory by keeping reference
    leaked_data.append([random.random() for _ in range(500000)])
    
    time.sleep(0.2)
    return len(leaked_data)


# ============================================================================
# Example 7: CPU Intensive Operation
# ============================================================================

@monitor()
def cpu_intensive():
    """Function that uses significant CPU"""
    result = 0
    for i in range(5000000):
        result += i ** 2
    return result


# ============================================================================
# Example 8: Batch Processing
# ============================================================================

@monitor()
def batch_processor(total_items=1000, batch_size=100):
    """Process items in batches"""
    
    items = list(range(total_items))
    results = []
    
    num_batches = (total_items + batch_size - 1) // batch_size
    
    for batch_num in range(num_batches):
        start_idx = batch_num * batch_size
        end_idx = min(start_idx + batch_size, total_items)
        batch = items[start_idx:end_idx]
        
        with track(f"batch_{batch_num + 1}"):
            # Process batch
            batch_result = [x * 2 for x in batch]
            time.sleep(0.1)
            results.extend(batch_result)
    
    return results


# ============================================================================
# Example 9: Error Handling
# ============================================================================

@monitor()
def function_with_error():
    """Function that raises an error"""
    time.sleep(0.2)
    raise ValueError("Intentional error for demo")


@monitor()
def safe_error_handler():
    """Function that handles errors"""
    try:
        function_with_error()
    except ValueError:
        print("   ℹ️  Error was caught and handled")
    
    return "recovered"


# ============================================================================
# Example 10: Real-World Space Mission Data Processing Simulation
# ============================================================================

@monitor()
def fetch_telemetry_from_db():
    """Simulate fetching telemetry data from mission database"""
    time.sleep(0.3)
    return [f"signal_{i}" for i in range(100)]


@monitor()
def process_signal(signal):
    """Simulate processing a single telemetry signal"""
    time.sleep(0.01)
    return {"signal": signal, "frequency": random.uniform(100, 1000)}


@monitor()
def plan_mission_data_simulation():
    """Simulated space mission data pipeline"""
    
    with track("Load Configuration"):
        time.sleep(0.1)
        config = {"batch_size": 20, "satellites": 4}
    
    with track("Fetch Telemetry"):
        signals = fetch_telemetry_from_db()
    
    results = []
    batch_size = config["batch_size"]
    
    for i in range(0, len(signals), batch_size):
        batch = signals[i:i + batch_size]
        
        with track(f"Process Batch {i//batch_size + 1}"):
            for signal in batch:
                result = process_signal(signal)
                results.append(result)
    
    with track("Save Results"):
        time.sleep(0.2)
    
    return results


# ============================================================================
# Example Runner
# ============================================================================

def run_example(num, name, func, *args, **kwargs):
    """Run a single example"""
    print("\n" + "="*80)
    print(f"Example {num}: {name}")
    print("="*80 + "\n")
    
    try:
        result = func(*args, **kwargs)
        print(f"\n✅ Example {num} completed successfully")
        return True
    except Exception as e:
        print(f"\n❌ Example {num} failed: {e}")
        return False


def main():
    """Run all examples"""
    print("\n" + "█"*80)
    print("📊 TASKMON - Comprehensive Examples")
    print("█"*80)
    
    examples = [
        (1, "Basic Function Monitoring", basic_function),
        (2, "Process Items (Auto-count)", process_items, [1, 2, 3, 4, 5]),
        (3, "Nested Functions", parent_function),
        (4, "Section Tracking", data_pipeline),
        (5, "Memory Intensive", memory_intensive),
        (6, "CPU Intensive", cpu_intensive),
        (7, "Batch Processing", batch_processor, 500, 50),
        (8, "Error Handling", safe_error_handler),
        (9, "Memory Leak Simulation (3 calls)", 
         lambda: [memory_leak_simulation() for _ in range(3)]),
        (10, "Real-World Space Mission Data", plan_mission_data_simulation),
    ]
    
    success_count = 0
    
    for example_data in examples:
        num, name, func, *args = example_data
        if run_example(num, name, func, *args):
            success_count += 1
        
        # Pause between examples
        time.sleep(1)
    
    # Print final summary
    print("\n" + "█"*80)
    print("📈 FINAL SUMMARY")
    print("█"*80 + "\n")
    
    print_summary()
    
    print("\n" + "█"*80)
    print(f"✅ {success_count}/{len(examples)} examples completed successfully")
    print("█"*80 + "\n")
    
    # Show memory leak detection
    print("\n" + "="*80)
    print("🔍 MEMORY LEAK DETECTION REPORT")
    print("="*80 + "\n")
    
    stats = get_stats()
    for func_name, metrics in stats.items():
        avg_memory = metrics.get('total_memory_delta', 0) / max(metrics.get('total_calls', 1), 1)
        if avg_memory > 50:  # More than 50MB average
            print(f"⚠️  Potential memory leak detected in: {func_name}")
            print(f"   Average memory delta: {avg_memory:.1f}MB per call")
            print(f"   Total calls: {metrics['total_calls']}")
            print()


def interactive_menu():
    """Interactive example selector"""
    examples = {
        "1": ("Basic Function", basic_function, []),
        "2": ("Process Items", process_items, [[1, 2, 3, 4, 5]]),
        "3": ("Nested Functions", parent_function, []),
        "4": ("Section Tracking", data_pipeline, []),
        "5": ("Memory Intensive", memory_intensive, []),
        "6": ("CPU Intensive", cpu_intensive, []),
        "7": ("Batch Processing", batch_processor, [500, 50]),
        "8": ("Error Handling", safe_error_handler, []),
        "9": ("Memory Leak", memory_leak_simulation, []),
        "10": ("Space Mission Data", plan_mission_data_simulation, []),
    }
    
    while True:
        print("\n" + "="*80)
        print("🎮 TASKMON EXAMPLES - Interactive Menu")
        print("="*80 + "\n")
        
        for key, (name, _, _) in examples.items():
            print(f"{key}. {name}")
        
        print("\nA. Run ALL examples")
        print("S. Show statistics summary")
        print("C. Clear statistics")
        print("0. Exit")
        
        print("\n" + "="*80)
        choice = input("\nSelect example (0-10, A, S, C): ").strip().upper()
        
        if choice == "0":
            print("\n👋 Goodbye!")
            break
        elif choice == "A":
            main()
        elif choice == "S":
            print_summary()
        elif choice == "C":
            from taskmon import clear_stats
            clear_stats()
            print("\n✅ Statistics cleared")
        elif choice in examples:
            name, func, args = examples[choice]
            run_example(int(choice), name, func, *args)
        else:
            print("\n❌ Invalid choice")
        
        input("\nPress Enter to continue...")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "--interactive":
        interactive_menu()
    else:
        main()
