#!/usr/bin/env python3
"""
Simple Example - Test taskmon in 30 seconds
"""

import time
from taskmon import monitor, track, print_summary


@monitor()
def quick_example():
    """Simple function with sections"""
    
    with track("Step 1: Load Data"):
        time.sleep(0.3)
        data = list(range(1000))
    
    with track("Step 2: Process"):
        time.sleep(0.5)
        result = [x * 2 for x in data]
    
    with track("Step 3: Save"):
        time.sleep(0.2)
    
    return result


@monitor()
def memory_example():
    """Example showing memory allocation"""
    
    with track("Allocate Small"):
        small = [i for i in range(10000)]
    
    with track("Allocate Large"):
        large = [i for i in range(1000000)]
    
    return len(small) + len(large)


if __name__ == "__main__":
    print("\n" + "="*60)
    print("🚀 TASKMON - Simple Example")
    print("="*60 + "\n")
    
    print("Running quick_example()...\n")
    result1 = quick_example()
    print(f"\nResult: {len(result1)} items\n")
    
    input("Press Enter to run memory_example()...\n")
    
    result2 = memory_example()
    print(f"\nResult: {result2} items\n")
    
    input("Press Enter to see summary...\n")
    
    print_summary()
