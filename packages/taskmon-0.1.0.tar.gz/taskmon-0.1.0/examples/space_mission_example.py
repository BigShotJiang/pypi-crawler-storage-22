"""
Real-World Example: Space Mission Data Pipeline with taskmon
Shows how to integrate taskmon into your existing data processing code
"""

import time
import random
from taskmon import monitor, track


# ============================================================================
# Simulated Helper Functions (Space Mission Theme)
# ============================================================================

def simulate_telemetry_query(rows=1000):
    """Simulate fetching telemetry data from mission database"""
    time.sleep(0.1)
    return [{"id": i, "signal_id": f"signal_{i}"} for i in range(rows)]


def simulate_cache_lookup():
    """Simulate cache lookup for satellite configurations"""
    time.sleep(0.01)
    return None  # Cache miss


def simulate_mission_db_query():
    """Simulate fetching mission configurations from database"""
    time.sleep(0.05)
    return [{"id": i, "name": f"satellite_{i}"} for i in range(10)]


# ============================================================================
# Monitored Space Mission Data Processing Functions
# ============================================================================

@monitor()
def get_satellite_config_cached():
    """
    Get cached satellite configuration data
    Now with monitoring to detect if caching is working!
    """
    with track("Cache Lookup"):
        cached = simulate_cache_lookup()
    
    if cached:
        return cached
    
    # Cache miss - load from DB
    with track("Database Query"):
        satellites = simulate_mission_db_query()
    
    with track("Cache Write"):
        time.sleep(0.01)  # Simulate cache write
    
    return satellites


@monitor()
def get_total_signal_count(mission_ids):
    """Get total signal count for chunking"""
    with track("Count Query"):
        # Simulate query
        time.sleep(0.1)
        return random.randint(100000, 500000)


@monitor()
def telemetry_to_dataframe(query_result):
    """
    Convert telemetry result to DataFrame
    Monitor to catch memory issues!
    """
    with track("Column Extraction"):
        columns = ["id", "signal_id", "satellite_id"]
    
    with track("Row Processing"):
        rows = query_result
        time.sleep(0.05)
    
    with track("DataFrame Creation"):
        # Simulate pandas DataFrame creation
        time.sleep(0.1)
        df = {"columns": columns, "rows": rows, "size": len(rows)}
    
    return df


@monitor()
def process_signal_chunk(
    offset: int,
    limit: int,
    mission_ids: list,
    satellites: dict,
    current_ts,
    period_end
):
    """
    Process a chunk of telemetry signals
    Each section is tracked to find bottlenecks!
    """
    
    # Fetch data
    with track("Database Queries"):
        with track("Fetch Signals"):
            signal_data = simulate_telemetry_query(limit)
        
        with track("Fetch Orbits"):
            orbit_data = simulate_telemetry_query(limit // 2)
        
        with track("Fetch Processing Rules"):
            rules_data = simulate_telemetry_query(6)
    
    # Convert to DataFrames
    with track("DataFrame Conversion"):
        with track("Signal DataFrame"):
            signal_df = telemetry_to_dataframe(signal_data)
        
        with track("Orbit DataFrame"):
            orbit_df = telemetry_to_dataframe(orbit_data)
        
        with track("Rules DataFrame"):
            rules_df = telemetry_to_dataframe(rules_data)
    
    # Merge operations
    with track("DataFrame Merges"):
        with track("Merge Signals + Orbits"):
            time.sleep(0.2)
            merged_df = {"size": signal_df["size"]}
        
        with track("Merge + Rules"):
            time.sleep(0.15)
        
        with track("Memory Cleanup"):
            time.sleep(0.05)
            # gc.collect() would go here
    
    # Filter logic
    with track("Filtering"):
        with track("Calculate Next Processing Time"):
            time.sleep(0.1)
        
        with track("Apply Filters"):
            time.sleep(0.1)
            filtered_count = limit // 3
    
    # Parse metadata
    with track("Metadata Parsing"):
        time.sleep(0.05)
    
    # Enqueue tasks
    enqueued = 0
    failed = 0
    
    with track("Task Enqueueing"):
        for i in range(filtered_count):
            try:
                # Simulate task enqueueing
                time.sleep(0.001)
                enqueued += 1
            except Exception:
                failed += 1
        
        if failed > 0:
            print(f"   ⚠️  {failed} tasks failed to enqueue")
    
    with track("Memory Cleanup"):
        time.sleep(0.05)
    
    return enqueued


@monitor()
def plan_mission_data_collection():
    """
    Main space mission data collection planning task
    Now with full monitoring to identify issues!
    """
    
    # Configuration
    with track("Configuration"):
        active_missions = "apollo,voyager,hubble"
        mission_ids = active_missions.split(',')
        chunk_size = 50000
        time.sleep(0.1)
    
    # Get cached satellite configs
    with track("Load Satellite Configs"):
        satellites = get_satellite_config_cached()
    
    # Get current period
    with track("Get Current Period"):
        time.sleep(0.05)
        current_ts = time.time()
        period_end = current_ts + 3600
    
    # Get total count
    with track("Count Signals"):
        total_signals = get_total_signal_count(mission_ids)
        print(f"   📊 Total signals to process: {total_signals:,}")
    
    # Process in chunks
    total_enqueued = 0
    chunk_num = 0
    num_chunks = min((total_signals + chunk_size - 1) // chunk_size, 5)  # Limit to 5 for demo
    
    for offset in range(0, num_chunks * chunk_size, chunk_size):
        chunk_num += 1
        
        with track(f"Chunk {chunk_num}/{num_chunks}"):
            enqueued = process_signal_chunk(
                offset,
                chunk_size,
                mission_ids,
                satellites,
                current_ts,
                period_end
            )
            
            total_enqueued += enqueued
            print(f"   ✅ Chunk {chunk_num} complete: {enqueued:,} tasks enqueued")
    
    print(f"\n   🎉 SUCCESS: {total_enqueued:,} total tasks enqueued")
    
    return total_enqueued


# ============================================================================
# Simulated Memory Leak Version (for demonstration)
# ============================================================================

leaked_dataframes = []

@monitor()
def process_signal_chunk_with_leak(
    offset: int,
    limit: int,
    mission_ids: list,
    satellites: dict,
    current_ts,
    period_end
):
    """
    Version with memory leak - taskmon will highlight this!
    """
    global leaked_dataframes
    
    with track("Database Queries"):
        signal_data = simulate_telemetry_query(limit)
        orbit_data = simulate_telemetry_query(limit // 2)
    
    with track("DataFrame Conversion"):
        signal_df = telemetry_to_dataframe(signal_data)
        orbit_df = telemetry_to_dataframe(orbit_data)
        
        # Oops! Leak - not cleaning up DataFrames
        leaked_dataframes.append(signal_df)
        leaked_dataframes.append(orbit_df)
    
    with track("Processing"):
        time.sleep(0.3)
        enqueued = limit // 3
    
    # Notice: No memory cleanup!
    
    return enqueued


@monitor()
def plan_mission_data_collection_with_leak():
    """Space mission data collection with memory leak"""
    
    with track("Configuration"):
        chunk_size = 50000
        time.sleep(0.1)
    
    with track("Count Signals"):
        total_signals = 250000
    
    num_chunks = 5
    total_enqueued = 0
    
    for offset in range(0, num_chunks * chunk_size, chunk_size):
        chunk_num = offset // chunk_size + 1
        
        with track(f"Chunk {chunk_num} (LEAKING)"):
            enqueued = process_signal_chunk_with_leak(
                offset,
                chunk_size,
                [],
                {},
                time.time(),
                time.time() + 3600
            )
            total_enqueued += enqueued
    
    print(f"\n   ⚠️  Total DataFrames leaked: {len(leaked_dataframes)}")
    
    return total_enqueued


# ============================================================================
# Demo Runner
# ============================================================================

def main():
    """Run demo"""
    print("\n" + "="*80)
    print("🚀 SPACE MISSION DATA PIPELINE WITH TASKMON - Demo")
    print("="*80 + "\n")
    
    print("This demo shows how taskmon helps you:")
    print("  1. Find bottlenecks in your pipeline")
    print("  2. Detect memory leaks")
    print("  3. Understand where time is spent")
    print("  4. Monitor resource usage per section")
    print("\n" + "="*80 + "\n")
    
    input("Press Enter to run NORMAL version (without leak)...")
    
    print("\n" + "█"*80)
    print("▶️  Running NORMAL Space Mission Data Collection")
    print("█"*80 + "\n")
    
    plan_mission_data_collection()
    
    input("\n\nPress Enter to run LEAKY version (with memory leak)...")
    
    print("\n" + "█"*80)
    print("▶️  Running LEAKY Data Collection (Watch for 🔴 red indicators!)")
    print("█"*80 + "\n")
    
    plan_mission_data_collection_with_leak()
    
    # Print summary
    print("\n" + "="*80)
    print("📊 COMPARISON SUMMARY")
    print("="*80 + "\n")
    
    from taskmon import print_summary, get_stats
    print_summary()
    
    # Highlight issues
    print("\n" + "="*80)
    print("🔍 ISSUES DETECTED")
    print("="*80 + "\n")
    
    stats = get_stats()
    for func_name, metrics in stats.items():
        avg_memory = metrics.get('total_memory_delta', 0) / max(metrics.get('total_calls', 1), 1)
        
        if 'leak' in func_name.lower() and avg_memory > 20:
            print(f"❌ MEMORY LEAK: {func_name}")
            print(f"   Average memory delta: {avg_memory:.1f}MB per call")
            print(f"   Total calls: {metrics['total_calls']}")
            print(f"   Total leaked: {metrics['total_memory_delta']:.1f}MB")
            print()
    
    print("\n" + "="*80)
    print("💡 KEY INSIGHTS")
    print("="*80 + "\n")
    
    print("✅ With taskmon, you can:")
    print("  • See exactly which function leaks memory (🔴 red indicators)")
    print("  • Identify the slowest sections in your pipeline")
    print("  • Track performance across multiple calls")
    print("  • Monitor nested function calls")
    print("  • Get aggregated statistics")
    print("\n" + "="*80 + "\n")


if __name__ == "__main__":
    main()
