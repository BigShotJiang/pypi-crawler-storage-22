"""
Tests for taskmon package
"""

import pytest
import time
from taskmon import monitor, track, get_stats, clear_stats, get_active_calls


def test_basic_monitor():
    """Test basic function monitoring"""
    clear_stats()
    
    @monitor()
    def simple_function():
        time.sleep(0.1)
        return "done"
    
    result = simple_function()
    
    assert result == "done"
    stats = get_stats()
    # Check that the function was tracked (module name may vary)
    assert any("simple_function" in key for key in stats.keys())
    # Get the actual key
    func_key = [k for k in stats.keys() if "simple_function" in k][0]
    assert stats[func_key]["total_calls"] == 1


def test_monitor_with_items():
    """Test monitoring with item counting"""
    clear_stats()
    
    @monitor()
    def process_items():
        time.sleep(0.1)
        return [1, 2, 3, 4, 5]
    
    result = process_items()
    
    assert len(result) == 5
    # Stats should track this
    

def test_track_context_manager():
    """Test track context manager"""
    clear_stats()
    
    @monitor()
    def function_with_sections():
        with track("section1"):
            time.sleep(0.1)
        
        with track("section2"):
            time.sleep(0.1)
        
        return "done"
    
    result = function_with_sections()
    assert result == "done"


def test_nested_functions():
    """Test nested function monitoring"""
    clear_stats()
    
    @monitor()
    def child():
        time.sleep(0.05)
        return "child"
    
    @monitor()
    def parent():
        result = child()
        time.sleep(0.05)
        return f"parent-{result}"
    
    result = parent()
    assert result == "parent-child"
    
    stats = get_stats()
    # Check that both functions were tracked
    assert any("parent" in key for key in stats.keys())
    assert any("child" in key for key in stats.keys())


def test_error_handling():
    """Test monitoring functions that raise errors"""
    clear_stats()
    
    @monitor()
    def failing_function():
        time.sleep(0.05)
        raise ValueError("Test error")
    
    with pytest.raises(ValueError):
        failing_function()
    
    stats = get_stats()
    # Check that the function was tracked
    assert any("failing_function" in key for key in stats.keys())
    func_key = [k for k in stats.keys() if "failing_function" in k][0]
    assert stats[func_key]["failed_calls"] == 1


def test_memory_tracking():
    """Test memory delta tracking"""
    clear_stats()
    
    @monitor()
    def allocate_memory():
        data = [i for i in range(100000)]
        time.sleep(0.1)
        return len(data)
    
    result = allocate_memory()
    assert result == 100000


def test_active_calls():
    """Test getting active calls"""
    
    @monitor()
    def slow_function():
        # Check that we're in active calls during execution
        active = get_active_calls()
        assert len(active) > 0
        time.sleep(0.1)
    
    slow_function()


def test_multiple_calls():
    """Test statistics across multiple calls"""
    clear_stats()
    
    @monitor()
    def repeated_function(x):
        time.sleep(0.05)
        return x * 2
    
    for i in range(5):
        repeated_function(i)
    
    stats = get_stats()
    # Find the function in stats
    func_key = [k for k in stats.keys() if "repeated_function" in k][0]
    assert stats[func_key]["total_calls"] == 5


def test_clear_stats():
    """Test clearing statistics"""
    
    @monitor()
    def test_func():
        return "test"
    
    test_func()
    clear_stats()
    
    stats = get_stats()
    assert len(stats) == 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
