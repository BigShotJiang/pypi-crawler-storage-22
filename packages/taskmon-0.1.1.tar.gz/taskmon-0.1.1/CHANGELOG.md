# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.1] - 2026-02-05

### Added
- Logger integration for `monitor()` and `track()` with optional color control
- `set_logger()` helper and `print_summary(logger=...)` support
- Documentation updates with logger usage examples

## [0.1.0] - 2026-02-03

### Added
- Initial release of taskmon
- Function-level monitoring with `@monitor()` decorator
- Section tracking with `track()` context manager
- Real-time CPU and memory monitoring
- Visual terminal output with color-coded indicators
- Memory leak detection (🟢 🟡 🔴 indicators)
- Nested function call tracking with visual hierarchy
- Aggregated statistics with `print_summary()`
- Thread-safe implementation
- Comprehensive examples
- Full test suite
- Documentation in English and Turkish

### Features
- Automatic items counting for list/dict returns
- Peak CPU and memory tracking
- Duration measurement for all sections
- Error handling and failure tracking
- Low overhead (< 1% CPU impact)
- Background monitoring thread
- Call stack tracking for nested functions

### Examples Included
- Simple example for quick start
- Comprehensive examples covering all features
- Space mission data pipeline real-world example
- Memory leak demonstration

## [Unreleased]

### Planned
- Redis backend for distributed monitoring
- Dashboard web interface
- Prometheus metrics export
- Elasticsearch integration
- Configuration file support
- Custom threshold configuration
- Email/Slack alerts
- Historical data visualization
