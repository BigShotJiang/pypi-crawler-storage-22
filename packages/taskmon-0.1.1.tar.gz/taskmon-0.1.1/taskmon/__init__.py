"""
taskmon - Function-level Performance Monitoring

Simple, powerful monitoring for Python functions with visual terminal output.

Usage:
    from taskmon import monitor, track
    
    @monitor()
    def my_function():
        with track("database_query"):
            # query code
            pass
        
        with track("processing"):
            # processing code
            pass
    
    my_function()
"""

__version__ = "0.1.1"
__author__ = "kadirtutenn"

from .monitor import (
    monitor,
    track,
    get_stats,
    print_summary,
    clear_stats,
    get_active_calls,
    set_logger,
    FunctionMetrics,
)

__all__ = [
    "monitor",
    "track",
    "get_stats",
    "print_summary",
    "clear_stats",
    "get_active_calls",
    "set_logger",
    "FunctionMetrics",
]
