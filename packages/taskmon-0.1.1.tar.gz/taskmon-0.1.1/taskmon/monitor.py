"""
taskmon.monitor - Core monitoring functionality
"""

import functools
import time
import psutil
import os
import threading
import datetime
import json
import logging
import sys
from typing import Optional, Callable, Dict, Any, List
from dataclasses import dataclass, asdict
from collections import defaultdict, deque


@dataclass
class FunctionMetrics:
    """Metrics for a single function execution"""
    function_name: str
    module_name: str
    call_id: str  # Unique ID for this specific call
    
    # Timestamps
    started_at: float
    ended_at: Optional[float] = None
    duration_seconds: Optional[float] = None
    
    # Resource usage
    cpu_start: float = 0.0
    cpu_end: float = 0.0
    cpu_avg: float = 0.0
    cpu_peak: float = 0.0
    
    memory_start_mb: float = 0.0
    memory_end_mb: float = 0.0
    memory_peak_mb: float = 0.0
    memory_delta_mb: float = 0.0
    
    # Thread info
    thread_count_start: int = 0
    thread_count_end: int = 0
    
    # Custom metrics
    items_processed: int = 0
    
    # Status
    status: str = "running"  # running, completed, failed
    error: Optional[str] = None
    
    # Parent tracking
    parent_call_id: Optional[str] = None
    children_call_ids: List[str] = None
    logger: Optional[Any] = None
    use_color: Optional[bool] = None
    
    def __post_init__(self):
        if self.children_call_ids is None:
            self.children_call_ids = []
    
    def to_dict(self):
        return asdict(self)


class PrintLogger:
    """Default logger that prints to stdout/stderr."""
    def __init__(self, stream=None, err_stream=None):
        self.stream = stream or sys.stdout
        self.err_stream = err_stream or sys.stderr

    def info(self, message: str):
        print(message, file=self.stream)

    def warning(self, message: str):
        print(message, file=self.stream)

    def error(self, message: str):
        print(message, file=self.err_stream)

    def debug(self, message: str):
        print(message, file=self.stream)


class FunctionMonitor:
    """
    Function-level monitoring with real-time tracking
    
    Usage:
        from taskmon import monitor
        
        @monitor()
        def my_function(x, y):
            return x + y
        
        # Or with context manager
        with monitor.track("section_name"):
            # code here
    """
    
    def __init__(self):
        self.process = psutil.Process(os.getpid())
        self._active_calls: Dict[str, FunctionMetrics] = {}
        self._completed_calls: deque = deque(maxlen=1000)
        self._call_counter = 0
        self._lock = threading.Lock()
        
        # Real-time monitoring
        self._monitoring_thread: Optional[threading.Thread] = None
        self._monitoring_active = False
        self._sample_interval = 1.0
        
        # Aggregated stats per function
        self._function_stats: Dict[str, Dict[str, Any]] = defaultdict(lambda: {
            "total_calls": 0,
            "total_duration": 0.0,
            "total_memory_delta": 0.0,
            "failed_calls": 0,
            "avg_cpu": 0.0,
            "peak_memory": 0.0,
        })
        
        # Call stack for nested functions
        self._call_stack: threading.local = threading.local()

        # Logging
        self._logger = PrintLogger()
        self._use_color = True

    def set_logger(self, logger: Optional[Any], use_color: Optional[bool] = None):
        """Set default logger for all output"""
        if logger is None:
            self._logger = PrintLogger()
        else:
            self._logger = logger
        if use_color is not None:
            self._use_color = use_color

    def _emit(self, message: str, level: str = "info", logger: Optional[Any] = None):
        target = logger or self._logger

        if callable(target):
            try:
                target(message)
                return
            except TypeError:
                pass

        if hasattr(target, level):
            getattr(target, level)(message)
            return

        if hasattr(target, "log"):
            log_level = logging.INFO if level == "info" else logging.ERROR
            target.log(log_level, message)
            return

        # Fallback to print
        if level == "error":
            print(message, file=sys.stderr)
        else:
            print(message)
    
    def _get_call_id(self) -> str:
        """Generate unique call ID"""
        with self._lock:
            self._call_counter += 1
            return f"call_{self._call_counter}_{int(time.time()*1000)}"
    
    def _get_current_call_id(self) -> Optional[str]:
        """Get current call ID from stack"""
        if not hasattr(self._call_stack, 'stack'):
            self._call_stack.stack = []
        return self._call_stack.stack[-1] if self._call_stack.stack else None
    
    def _push_call(self, call_id: str):
        """Push call to stack"""
        if not hasattr(self._call_stack, 'stack'):
            self._call_stack.stack = []
        self._call_stack.stack.append(call_id)
    
    def _pop_call(self):
        """Pop call from stack"""
        if hasattr(self._call_stack, 'stack') and self._call_stack.stack:
            return self._call_stack.stack.pop()
        return None
    
    def _start_monitoring_thread(self):
        """Start background monitoring thread"""
        if self._monitoring_active:
            return
        
        self._monitoring_active = True
        self._monitoring_thread = threading.Thread(
            target=self._monitoring_loop,
            daemon=True
        )
        self._monitoring_thread.start()
    
    def _monitoring_loop(self):
        """Background loop to track active calls"""
        while self._monitoring_active:
            try:
                with self._lock:
                    for call_id, metrics in list(self._active_calls.items()):
                        # Update current resource usage
                        try:
                            cpu = self.process.cpu_percent(interval=0.1)
                            memory = self.process.memory_info().rss / 1024 / 1024
                            
                            metrics.cpu_peak = max(metrics.cpu_peak, cpu)
                            metrics.memory_peak_mb = max(metrics.memory_peak_mb, memory)
                        except (psutil.NoSuchProcess, psutil.AccessDenied):
                            # Process no longer exists or access denied
                            continue
                
                time.sleep(self._sample_interval)
            except Exception as e:
                # Log error but continue monitoring
                self._emit(f"[taskmon] Monitoring error: {e}", level="error")
                time.sleep(self._sample_interval)
    
    def start_function(
        self,
        function_name: str,
        module_name: str,
        parent_call_id: Optional[str] = None,
        logger: Optional[Any] = None,
        use_color: Optional[bool] = None
    ) -> str:
        """Start monitoring a function"""
        call_id = self._get_call_id()
        
        # Start monitoring thread if not already started
        if not self._monitoring_active:
            self._start_monitoring_thread()
        
        # Capture initial state
        cpu_start = self.process.cpu_percent(interval=0)
        memory_start = self.process.memory_info().rss / 1024 / 1024
        thread_count = self.process.num_threads()
        
        metrics = FunctionMetrics(
            function_name=function_name,
            module_name=module_name,
            call_id=call_id,
            started_at=time.time(),
            cpu_start=cpu_start,
            memory_start_mb=memory_start,
            thread_count_start=thread_count,
            parent_call_id=parent_call_id,
            logger=logger,
            use_color=use_color
        )
        
        with self._lock:
            self._active_calls[call_id] = metrics
            
            # Link to parent
            if parent_call_id and parent_call_id in self._active_calls:
                self._active_calls[parent_call_id].children_call_ids.append(call_id)
        
        self._push_call(call_id)
        self._log_function_start(metrics)
        
        return call_id
    
    def end_function(
        self,
        call_id: str,
        status: str = "completed",
        error: Optional[str] = None,
        items_processed: int = 0
    ):
        """End monitoring a function"""
        self._pop_call()
        
        with self._lock:
            if call_id not in self._active_calls:
                return
            
            metrics = self._active_calls[call_id]
            
            # Capture final state
            metrics.ended_at = time.time()
            metrics.duration_seconds = metrics.ended_at - metrics.started_at
            metrics.cpu_end = self.process.cpu_percent(interval=0.1)
            metrics.memory_end_mb = self.process.memory_info().rss / 1024 / 1024
            metrics.memory_delta_mb = metrics.memory_end_mb - metrics.memory_start_mb
            metrics.thread_count_end = self.process.num_threads()
            metrics.status = status
            metrics.error = error
            metrics.items_processed = items_processed
            
            # Calculate average CPU
            if metrics.cpu_peak > 0:
                metrics.cpu_avg = (metrics.cpu_start + metrics.cpu_end + metrics.cpu_peak) / 3
            else:
                metrics.cpu_avg = (metrics.cpu_start + metrics.cpu_end) / 2
            
            # Update aggregated stats
            self._update_function_stats(metrics)
            
            # Move to completed
            self._completed_calls.append(metrics)
            del self._active_calls[call_id]
            
            self._log_function_end(metrics)
    
    def _update_function_stats(self, metrics: FunctionMetrics):
        """Update aggregated statistics"""
        func_key = f"{metrics.module_name}.{metrics.function_name}"
        stats = self._function_stats[func_key]
        
        stats["total_calls"] += 1
        stats["total_duration"] += metrics.duration_seconds or 0
        stats["total_memory_delta"] += metrics.memory_delta_mb
        
        if metrics.status == "failed":
            stats["failed_calls"] += 1
        
        # Update averages
        n = stats["total_calls"]
        stats["avg_cpu"] = ((n - 1) * stats["avg_cpu"] + metrics.cpu_avg) / n
        stats["peak_memory"] = max(stats["peak_memory"], metrics.memory_peak_mb)
    
    def _log_function_start(self, metrics: FunctionMetrics):
        """Log function start"""
        indent = "  " * len(getattr(self._call_stack, 'stack', []))

        self._emit(
            f"{indent}{'┌' if not indent else '├'}─ 🚀 {metrics.function_name}() started"
            f" [{metrics.call_id}]",
            logger=metrics.logger
        )
        self._emit(
            f"{indent}│  📊 Baseline: "
            f"CPU {metrics.cpu_start:.1f}% | "
            f"MEM {metrics.memory_start_mb:.1f}MB | "
            f"THR {metrics.thread_count_start}",
            logger=metrics.logger
        )
    
    def _log_function_end(self, metrics: FunctionMetrics):
        """Log function end with visual indicators"""
        indent = "  " * (len(getattr(self._call_stack, 'stack', [])) + 1)
        use_color = self._use_color if metrics.use_color is None else metrics.use_color
        
        # Status indicator
        if metrics.status == "completed":
            status_icon = "✅"
            status_color = "\033[92m"  # Green
        elif metrics.status == "failed":
            status_icon = "❌"
            status_color = "\033[91m"  # Red
        else:
            status_icon = "⚠️"
            status_color = "\033[93m"  # Yellow
        
        # Memory status
        if abs(metrics.memory_delta_mb) < 10:
            mem_status = "🟢"
        elif abs(metrics.memory_delta_mb) < 100:
            mem_status = "🟡"
        else:
            mem_status = "🔴"
        
        # CPU bar
        cpu_bar = self._create_bar(metrics.cpu_avg, 100, width=10)
        
        reset = "\033[0m"
        if not use_color:
            status_color = ""
            reset = ""

        self._emit(
            f"{indent}└─ {status_icon} {status_color}{metrics.function_name}(){reset} "
            f"completed in {metrics.duration_seconds:.2f}s",
            logger=metrics.logger
        )
        self._emit(
            f"{indent}   📊 CPU: {metrics.cpu_avg:.1f}% {cpu_bar} | "
            f"MEM: {mem_status} {metrics.memory_delta_mb:+.1f}MB "
            f"(peak: {metrics.memory_peak_mb:.1f}MB)",
            logger=metrics.logger
        )
        
        if metrics.items_processed > 0:
            throughput = metrics.items_processed / metrics.duration_seconds
            self._emit(
                f"{indent}   ⚡ Processed: {metrics.items_processed:,} items "
                f"({throughput:.1f} items/s)",
                logger=metrics.logger
            )
        
        if metrics.error:
            self._emit(f"{indent}   ❌ Error: {metrics.error}", level="error", logger=metrics.logger)

        self._emit("", logger=metrics.logger)  # Blank line
    
    def _create_bar(self, value: float, max_value: float, width: int = 10) -> str:
        """Create visual bar"""
        filled = int((value / max_value) * width)
        return f"[{'█' * filled}{'░' * (width - filled)}]"
    
    def get_active_calls(self) -> List[FunctionMetrics]:
        """Get currently active function calls"""
        with self._lock:
            return list(self._active_calls.values())
    
    def get_completed_calls(self, limit: int = 100) -> List[FunctionMetrics]:
        """Get recently completed calls"""
        return list(self._completed_calls)[-limit:]
    
    def get_function_stats(self, function_name: Optional[str] = None) -> Dict:
        """Get aggregated function statistics"""
        if function_name:
            return self._function_stats.get(function_name, {})
        return dict(self._function_stats)
    
    def print_summary(self, logger: Optional[Any] = None):
        """Print summary of all monitored functions"""
        self._emit("\n" + "="*80, logger=logger)
        self._emit("📊 FUNCTION MONITORING SUMMARY", logger=logger)
        self._emit("="*80 + "\n", logger=logger)
        
        if not self._function_stats:
            self._emit("No functions monitored yet.\n", logger=logger)
            return
        
        # Sort by total duration
        sorted_funcs = sorted(
            self._function_stats.items(),
            key=lambda x: x[1]["total_duration"],
            reverse=True
        )
        
        self._emit(f"{'Function':<40} {'Calls':>8} {'Total Time':>12} {'Avg Time':>10} {'Failures':>10}", logger=logger)
        self._emit("-"*80, logger=logger)
        
        for func_name, stats in sorted_funcs:
            avg_time = stats["total_duration"] / stats["total_calls"]
            failure_rate = stats["failed_calls"] / stats["total_calls"] * 100
            
            self._emit(
                f"{func_name:<40} "
                f"{stats['total_calls']:>8} "
                f"{stats['total_duration']:>11.2f}s "
                f"{avg_time:>9.3f}s "
                f"{stats['failed_calls']:>6} ({failure_rate:.1f}%)",
                logger=logger
            )
        
        self._emit("\n" + "="*80 + "\n", logger=logger)
    
    def clear_stats(self):
        """Clear all statistics"""
        with self._lock:
            self._function_stats.clear()
            self._completed_calls.clear()


# Global monitor instance
_monitor = FunctionMonitor()


def monitor(
    items_attr: Optional[str] = None,
    print_summary: bool = False,
    logger: Optional[Any] = None,
    use_color: Optional[bool] = None
):
    """
    Decorator to monitor function performance
    
    Args:
        items_attr: Name of attribute/variable to track as items_processed
        print_summary: Print summary after function completes
        logger: Logger instance/callable (e.g. logging.Logger or Celery logger)
        use_color: Enable/disable ANSI colors for this decorated function
    
    Usage:
        @monitor()
        def my_function():
            pass
        
        @monitor(items_attr='result')  # Track len(result)
        def process_items():
            return [1, 2, 3]

        @monitor(logger=my_logger, use_color=False)
        def task():
            pass
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Get parent call ID
            parent_call_id = _monitor._get_current_call_id()
            
            # Start monitoring
            call_id = _monitor.start_function(
                function_name=func.__name__,
                module_name=func.__module__,
                parent_call_id=parent_call_id,
                logger=logger,
                use_color=use_color
            )
            
            items_processed = 0
            status = "completed"
            error = None
            
            try:
                result = func(*args, **kwargs)
                
                # Track items if specified
                if items_attr and hasattr(result, items_attr):
                    items_value = getattr(result, items_attr)
                    if hasattr(items_value, '__len__'):
                        items_processed = len(items_value)
                elif items_attr is None and hasattr(result, '__len__'):
                    try:
                        items_processed = len(result)
                    except (TypeError, AttributeError):
                        pass
                
                return result
                
            except Exception as e:
                status = "failed"
                error = str(e)
                raise
                
            finally:
                _monitor.end_function(
                    call_id=call_id,
                    status=status,
                    error=error,
                    items_processed=items_processed
                )
                
                if print_summary:
                    _monitor.print_summary(logger=logger)
        
        return wrapper
    return decorator


class track:
    """
    Context manager for monitoring code sections
    
    Usage:
        with track("section_name"):
            # code here
            pass

        with track("section_name", logger=my_logger, use_color=False):
            pass
    """
    
    def __init__(self, section_name: str, items: int = 0, logger: Optional[Any] = None, use_color: Optional[bool] = None):
        self.section_name = section_name
        self.items = items
        self.call_id = None
        self.logger = logger
        self.use_color = use_color
    
    def __enter__(self):
        parent_call_id = _monitor._get_current_call_id()
        self.call_id = _monitor.start_function(
            function_name=self.section_name,
            module_name="<section>",
            parent_call_id=parent_call_id,
            logger=self.logger,
            use_color=self.use_color
        )
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        status = "failed" if exc_type else "completed"
        error = str(exc_val) if exc_val else None
        
        _monitor.end_function(
            call_id=self.call_id,
            status=status,
            error=error,
            items_processed=self.items
        )
        
        return False  # Don't suppress exceptions


# Convenience functions
def get_stats(function_name: Optional[str] = None) -> Dict:
    """Get function statistics"""
    return _monitor.get_function_stats(function_name)


def print_summary(logger: Optional[Any] = None):
    """Print monitoring summary"""
    _monitor.print_summary(logger=logger)


def set_logger(logger: Optional[Any], use_color: Optional[bool] = None):
    """Set default logger for taskmon output"""
    _monitor.set_logger(logger, use_color=use_color)


def clear_stats():
    """Clear all statistics"""
    _monitor.clear_stats()


def get_active_calls() -> List[FunctionMetrics]:
    """Get currently active function calls"""
    return _monitor.get_active_calls()
