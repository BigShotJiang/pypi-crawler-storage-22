"""Pytest configuration for taskwarrior-mcp tests."""

import pytest

# pytest-asyncio configuration is handled in pyproject.toml
