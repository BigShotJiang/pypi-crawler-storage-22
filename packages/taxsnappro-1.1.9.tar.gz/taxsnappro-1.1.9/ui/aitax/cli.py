"""
TaxSnapPro CLI - Launch the tax preparation app
"""
import subprocess
import sys
import os
import shutil
from pathlib import Path


__version__ = "1.1.9"

RXCONFIG_CONTENT = '''"""Reflex config for TaxSnapPro."""
import reflex as rx

config = rx.Config(
    app_name="aitax",
    plugins=[]
)
'''


def setup_app_dir() -> Path:
    """Create app directory with necessary files."""
    # Use ~/.taxsnappro as the app directory
    app_dir = Path.home() / ".taxsnappro"
    app_dir.mkdir(exist_ok=True)
    
    # Create rxconfig.py
    rxconfig = app_dir / "rxconfig.py"
    if not rxconfig.exists():
        rxconfig.write_text(RXCONFIG_CONTENT)
    
    # Create aitax package symlink/copy
    aitax_dir = app_dir / "aitax"
    if not aitax_dir.exists():
        # Get the installed package location
        import aitax
        src_dir = Path(aitax.__file__).parent
        # Copy the package files
        shutil.copytree(src_dir, aitax_dir)
    
    return app_dir


def upgrade():
    """Upgrade TaxSnapPro with SSL certificate handling."""
    import ssl
    import urllib.request
    import json
    import platform
    
    print("🔄 Checking for updates...")
    
    # Step 1: Check current version vs latest (avoid timing issues)
    try:
        # Create SSL context that works on macOS
        if platform.system() == "Darwin":  # macOS
            # Try multiple SSL approaches for macOS
            ssl_contexts = [
                ssl.create_default_context(),
                ssl.create_default_context(cafile=None),
                ssl._create_unverified_context()  # Last resort
            ]
        else:
            ssl_contexts = [ssl.create_default_context()]
        
        latest_version = None
        for ssl_context in ssl_contexts:
            try:
                req = urllib.request.Request("https://pypi.org/pypi/taxsnappro/json")
                with urllib.request.urlopen(req, context=ssl_context) as response:
                    data = json.loads(response.read())
                    latest_version = data["info"]["version"]
                    break
            except Exception as e:
                continue  # Try next SSL context
        
        if not latest_version:
            print("⚠️  Could not check latest version, proceeding with upgrade...")
            latest_version = "unknown"
        
    except Exception as e:
        print(f"⚠️  Version check failed: {e}")
        latest_version = "unknown"
    
    # Get current version
    current_version = __version__
    
    if latest_version != "unknown" and current_version == latest_version:
        print(f"✅ Already on latest version (v{current_version})")
        return 0
    elif latest_version != "unknown":
        print(f"📦 Update available: v{current_version} → v{latest_version}")
    
    # Step 2: Upgrade with SSL handling
    pip_args = [sys.executable, "-m", "pip", "install", "--upgrade", "--no-cache-dir"]
    
    # macOS SSL certificate workarounds
    if platform.system() == "Darwin":
        pip_args.extend([
            "--trusted-host", "pypi.org",
            "--trusted-host", "pypi.python.org", 
            "--trusted-host", "files.pythonhosted.org"
        ])
    
    pip_args.append("taxsnappro")
    
    print("🚀 Installing update...")
    result = subprocess.run(pip_args, text=True, capture_output=True)
    
    if result.returncode != 0:
        print(f"❌ Upgrade failed: {result.stderr}")
        # Fallback: try with --user flag
        print("🔄 Trying user-level install...")
        fallback_args = pip_args[:-1] + ["--user", "taxsnappro"]
        result = subprocess.run(fallback_args, text=True)
        
        if result.returncode != 0:
            print("❌ Fallback also failed")
            return 1
    
    # Step 3: Clear cache and confirm
    app_dir = Path.home() / ".taxsnappro"
    aitax_dir = app_dir / "aitax"
    if aitax_dir.exists():
        shutil.rmtree(aitax_dir)
    
    if latest_version != "unknown":
        print(f"✅ Successfully upgraded: v{current_version} → v{latest_version}")
    else:
        print("✅ Upgrade completed successfully!")
    
    print("   Run 'taxsnappro' to start with the latest version")
    return 0


def main():
    """Main entry point for taxsnappro command."""
    args = sys.argv[1:]
    
    if args and args[0] in ("--version", "-v"):
        print(f"TaxSnapPro v{__version__}")
        return 0
    
    if args and args[0] in ("--help", "-h"):
        print(f"""TaxSnapPro v{__version__} - AI-powered tax preparation

Usage:
  taxsnappro [run]     Launch the web UI (default)
  taxsnappro upgrade   Check for and install updates
  taxsnappro --version Show version
  taxsnappro --help    Show this help
  taxsnappro --reset   Reset app directory (clear cache)

After running, open http://localhost:3000 in your browser.
Go to Settings to configure your Gemini API key first.
""")
        return 0
    
    if args and args[0] == "upgrade":
        return upgrade()
    
    if args and args[0] == "--reset":
        app_dir = Path.home() / ".taxsnappro"
        if app_dir.exists():
            shutil.rmtree(app_dir)
            print(f"✓ Removed {app_dir}")
        return 0
    
    # Setup app directory
    print(f"🔨 TaxSnapPro v{__version__}")
    print("   Setting up app directory...")
    
    try:
        app_dir = setup_app_dir()
    except Exception as e:
        print(f"Error setting up app: {e}")
        return 1
    
    print(f"   Directory: {app_dir}")
    print(f"   Open http://localhost:3000 after startup")
    print()
    
    os.chdir(app_dir)
    
    # Run reflex
    try:
        result = subprocess.run(
            [sys.executable, "-m", "reflex", "run"],
            cwd=app_dir,
        )
        return result.returncode
    except KeyboardInterrupt:
        print("\n👋 TaxSnapPro stopped")
        return 0
    except FileNotFoundError:
        print("Error: Reflex not installed. Run: pip install reflex")
        return 1


if __name__ == "__main__":
    sys.exit(main())
