"""TaxSnapPro - AI-powered tax preparation"""

__version__ = "1.1.7"

# Export app for Reflex
from .aitax import app

__all__ = ["app", "__version__"]
