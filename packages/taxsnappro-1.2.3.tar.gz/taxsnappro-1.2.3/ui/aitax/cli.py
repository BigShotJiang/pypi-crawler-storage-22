"""
TaxSnapPro CLI - Launch the tax preparation app
"""
import subprocess
import sys
import os
import shutil
from pathlib import Path


__version__ = "1.2.3"

RXCONFIG_CONTENT = '''"""Reflex config for TaxSnapPro."""
import reflex as rx

config = rx.Config(
    app_name="aitax",
    plugins=[]
)
'''


def setup_app_dir() -> Path:
    """Create app directory with necessary files."""
    # Use ~/.taxsnappro as the app directory
    app_dir = Path.home() / ".taxsnappro"
    app_dir.mkdir(exist_ok=True)
    
    # Create rxconfig.py
    rxconfig = app_dir / "rxconfig.py"
    if not rxconfig.exists():
        rxconfig.write_text(RXCONFIG_CONTENT)
    
    # Create aitax package symlink/copy
    aitax_dir = app_dir / "aitax"
    if not aitax_dir.exists():
        # Get the installed package location
        import aitax
        src_dir = Path(aitax.__file__).parent
        # Copy the package files
        shutil.copytree(src_dir, aitax_dir)
    
    return app_dir


def upgrade():
    """Upgrade TaxSnapPro - simplified, always run pip upgrade."""
    import platform
    
    print("🔄 Upgrading TaxSnapPro...")
    
    # Always run pip upgrade and let pip handle version checking
    # This is more reliable than trying to parse versions ourselves
    
    pip_args = [sys.executable, "-m", "pip", "install", "--upgrade", "--no-cache-dir"]
    
    # macOS SSL certificate workarounds
    if platform.system() == "Darwin":
        pip_args.extend([
            "--trusted-host", "pypi.org",
            "--trusted-host", "pypi.python.org", 
            "--trusted-host", "files.pythonhosted.org"
        ])
    
    pip_args.append("taxsnappro")
    
    print("🚀 Installing latest version...")
    result = subprocess.run(pip_args, text=True, capture_output=True)
    
    if result.returncode != 0:
        print(f"❌ Upgrade failed: {result.stderr}")
        # Fallback: try with --user flag
        print("🔄 Trying user-level install...")
        fallback_args = pip_args[:-1] + ["--user", "taxsnappro"]
        result = subprocess.run(fallback_args, text=True, capture_output=True)
        
        if result.returncode != 0:
            print(f"❌ Fallback also failed: {result.stderr}")
            return 1
    
    # Check what version was installed
    try:
        version_check = subprocess.run(
            [sys.executable, "-m", "pip", "show", "taxsnappro"],
            text=True, capture_output=True
        )
        if version_check.returncode == 0:
            for line in version_check.stdout.split('\n'):
                if line.startswith('Version:'):
                    new_version = line.split(':', 1)[1].strip()
                    print(f"✅ TaxSnapPro updated to v{new_version}")
                    break
        else:
            print("✅ TaxSnapPro upgrade completed!")
    except Exception:
        print("✅ TaxSnapPro upgrade completed!")
    
    # Clear app cache so new version loads
    app_dir = Path.home() / ".taxsnappro"
    aitax_dir = app_dir / "aitax"
    if aitax_dir.exists():
        shutil.rmtree(aitax_dir)
    
    print("   Run 'taxsnappro' to start with the latest version")
    return 0


def main():
    """Main entry point for taxsnappro command."""
    args = sys.argv[1:]
    
    if args and args[0] in ("--version", "-v"):
        print(f"TaxSnapPro v{__version__}")
        return 0
    
    if args and args[0] in ("--help", "-h"):
        print(f"""TaxSnapPro v{__version__} - AI-powered tax preparation

Usage:
  taxsnappro [run]     Launch the web UI (default)
  taxsnappro upgrade   Check for and install updates
  taxsnappro --version Show version
  taxsnappro --help    Show this help
  taxsnappro --reset   Reset app directory (clear cache)

After running, open http://localhost:3000 in your browser.
Go to Settings to configure your Gemini API key first.
""")
        return 0
    
    if args and args[0] == "upgrade":
        return upgrade()
    
    if args and args[0] == "--reset":
        app_dir = Path.home() / ".taxsnappro"
        if app_dir.exists():
            shutil.rmtree(app_dir)
            print(f"✓ Removed {app_dir}")
        return 0
    
    # Setup app directory
    print(f"🔨 TaxSnapPro v{__version__}")
    print("   Setting up app directory...")
    
    try:
        app_dir = setup_app_dir()
    except Exception as e:
        print(f"Error setting up app: {e}")
        return 1
    
    print(f"   Directory: {app_dir}")
    print(f"   Open http://localhost:3000 after startup")
    print()
    
    os.chdir(app_dir)
    
    # Run reflex
    try:
        result = subprocess.run(
            [sys.executable, "-m", "reflex", "run"],
            cwd=app_dir,
        )
        return result.returncode
    except KeyboardInterrupt:
        print("\n👋 TaxSnapPro stopped")
        return 0
    except FileNotFoundError:
        print("Error: Reflex not installed. Run: pip install reflex")
        return 1


if __name__ == "__main__":
    sys.exit(main())
