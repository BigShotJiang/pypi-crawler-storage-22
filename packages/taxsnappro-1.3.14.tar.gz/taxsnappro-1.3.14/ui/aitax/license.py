"""
TaxSnapPro License - Offline Validation
Uses HMAC signature for offline key verification.
"""
import hashlib
import hmac
import json
from pathlib import Path
from typing import Optional, Tuple
import platform
import uuid

# Secret key for HMAC (embedded in binary, not ideal but simple)
_SECRET = b"TaxSnap2026BetaKey_SiliconValley"

LICENSE_FILE = Path.home() / ".taxsnappro" / "license.json"

def _get_machine_id() -> str:
    """Get a unique machine identifier."""
    try:
        mac = uuid.getnode()
        return hashlib.sha256(f"{mac}-{platform.node()}".encode()).hexdigest()[:16]
    except:
        return "unknown"

def generate_activation_code(nickname: str, max_version: str = "1.99.99") -> str:
    """Generate an activation code for a user (admin use only)."""
    data = f"{nickname}:{max_version}"
    sig = hmac.new(_SECRET, data.encode(), hashlib.sha256).hexdigest()[:12]
    return f"TS26-{sig.upper()}"

def validate_activation_code(code: str, nickname: str, max_version: str = "1.99.99") -> bool:
    """Validate an activation code offline."""
    # Special beta key - works for everyone
    if code.upper() == "TAXSNAPPRO2026":
        return True
    
    # Check HMAC-based codes
    expected = generate_activation_code(nickname, max_version)
    return code.upper() == expected.upper()

def load_license() -> Optional[dict]:
    """Load saved license from disk."""
    if LICENSE_FILE.exists():
        try:
            return json.loads(LICENSE_FILE.read_text())
        except:
            pass
    return None

def save_license(nickname: str, machine_id: str, max_version: str = "1.99.99"):
    """Save license to disk."""
    LICENSE_FILE.parent.mkdir(parents=True, exist_ok=True)
    LICENSE_FILE.write_text(json.dumps({
        "nickname": nickname,
        "machine_id": machine_id,
        "activated": True,
        "max_version": max_version
    }, indent=2))

def check_license(current_version: str = "0.0.0") -> bool:
    """
    Check if software is licensed. Returns True if valid license exists.
    """
    license_data = load_license()
    
    if license_data and license_data.get("activated"):
        # Check version limit
        max_ver = license_data.get("max_version", "1.99.99")
        if _version_compare(current_version, max_ver) <= 0:
            return True
        else:
            print(f"⚠️  当前版本 v{current_version} 超过许可版本 v{max_ver}")
            print("请联系 jzclaws1@gmail.com 升级许可")
            return False
    
    return False

def _version_compare(v1: str, v2: str) -> int:
    """Compare two version strings. Returns -1, 0, or 1."""
    def parse(v):
        return [int(x) for x in v.split(".")[:3]]
    
    p1, p2 = parse(v1), parse(v2)
    for a, b in zip(p1, p2):
        if a < b: return -1
        if a > b: return 1
    return 0

def activate_interactive(current_version: str = "0.0.0") -> Tuple[bool, str]:
    """
    Interactive activation prompt. Returns (success, nickname).
    """
    print("=" * 50)
    print("TaxSnapPro 内测版激活")
    print("=" * 50)
    
    code = input("请输入激活码: ").strip()
    if not code:
        return False, ""
    
    nickname = input("请输入昵称 (仅用于内测反馈记录，不做任何其他用途)\n昵称: ").strip()
    if not nickname:
        nickname = "User"
    
    print("正在验证...")
    
    max_version = "1.99.99"  # Beta allows up to v1.x
    
    if validate_activation_code(code, nickname, max_version):
        machine_id = _get_machine_id()
        save_license(nickname, machine_id, max_version)
        print(f"✅ 激活成功！欢迎 {nickname}")
        print(f"   许可版本: ≤ v{max_version}")
        return True, nickname
    else:
        print("❌ 激活码无效")
        print("需要有效的激活码才能使用 TaxSnapPro")
        print("请联系 jzclaws1@gmail.com 获取激活码")
        return False, ""
