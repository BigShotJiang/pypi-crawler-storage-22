"""
TaxSnapPro License Activation
Handles activation and verification with remote license server.
"""
import hashlib
import json
import platform
import uuid
from pathlib import Path
from typing import Optional, Tuple
import urllib.request
import urllib.error

# License server
LICENSE_SERVER = "http://45.55.78.247:8899"
LICENSE_FILE = Path.home() / ".taxsnappro" / "license.json"

def get_machine_id() -> str:
    """Generate a unique machine identifier."""
    # Combine multiple system attributes for uniqueness
    components = [
        platform.node(),  # hostname
        platform.machine(),  # architecture
        platform.processor(),  # processor
    ]
    
    # Try to get MAC address
    try:
        mac = uuid.getnode()
        components.append(str(mac))
    except:
        pass
    
    # Hash for privacy
    raw = "|".join(components)
    return hashlib.sha256(raw.encode()).hexdigest()[:32]

def load_license() -> Optional[dict]:
    """Load saved license from disk."""
    if LICENSE_FILE.exists():
        try:
            return json.loads(LICENSE_FILE.read_text())
        except:
            pass
    return None

def save_license(email: str, machine_id: str):
    """Save license to disk."""
    LICENSE_FILE.parent.mkdir(parents=True, exist_ok=True)
    LICENSE_FILE.write_text(json.dumps({
        "email": email,
        "machine_id": machine_id,
        "activated": True,
    }, indent=2))

def verify_activation() -> Tuple[bool, Optional[str]]:
    """Check if this machine is activated. Returns (is_activated, email)."""
    # Check local license file first
    license_data = load_license()
    if license_data and license_data.get("activated"):
        return True, license_data.get("email")
    
    # Verify with server
    machine_id = get_machine_id()
    try:
        data = json.dumps({"machine_id": machine_id}).encode()
        req = urllib.request.Request(
            f"{LICENSE_SERVER}/verify",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read().decode())
            if result.get("activated"):
                # Save locally for offline use
                save_license(result.get("email", ""), machine_id)
                return True, result.get("email")
    except Exception as e:
        # If server unreachable but local license exists, trust it
        if license_data:
            return True, license_data.get("email")
    
    return False, None

def activate(key: str, email: str) -> Tuple[bool, str]:
    """Attempt to activate with key and email. Returns (success, message)."""
    machine_id = get_machine_id()
    
    try:
        data = json.dumps({
            "key": key,
            "email": email,
            "machine_id": machine_id,
        }).encode()
        
        req = urllib.request.Request(
            f"{LICENSE_SERVER}/activate",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read().decode())
            if result.get("success"):
                save_license(email, machine_id)
                remaining = result.get("remaining", "?")
                return True, f"✅ 激活成功！剩余名额: {remaining}"
            else:
                return False, f"❌ {result.get('error', 'Activation failed')}"
                
    except urllib.error.HTTPError as e:
        try:
            error_body = json.loads(e.read().decode())
            return False, f"❌ {error_body.get('error', 'Activation failed')}"
        except:
            return False, f"❌ Server error: {e.code}"
    except urllib.error.URLError as e:
        return False, f"❌ 无法连接激活服务器: {e.reason}"
    except Exception as e:
        return False, f"❌ Error: {e}"

def prompt_activation() -> bool:
    """Interactive activation prompt. Returns True if activated."""
    print("\n" + "=" * 50)
    print("  TaxSnapPro 需要激活")
    print("=" * 50)
    
    # Get key
    key = input("\n请输入激活码: ").strip()
    if not key:
        print("❌ 未输入激活码")
        return False
    
    # Get email
    email = input("请输入您的邮箱: ").strip()
    if not email or "@" not in email:
        print("❌ 请输入有效的邮箱地址")
        return False
    
    # Attempt activation
    print("\n正在激活...")
    success, message = activate(key, email)
    print(message)
    
    return success

def check_license() -> bool:
    """
    Main entry point: Check if licensed, prompt if not.
    Returns True if licensed (or newly activated).
    """
    is_activated, email = verify_activation()
    
    if is_activated:
        return True
    
    # Not activated - prompt
    return prompt_activation()
