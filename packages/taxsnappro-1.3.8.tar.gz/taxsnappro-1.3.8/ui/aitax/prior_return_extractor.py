"""
TaxSnapPro - Prior Return Extractor

Extracts carryover data from prior year tax returns (1040, Schedule D, Form 8582, etc.)
Uses Google Gemini API for multi-page PDF extraction.
"""
import os
import base64
import json
import asyncio
import httpx
from pathlib import Path
from typing import Optional, Dict, Any

# Rate limiting (same as document_extractor)
MAX_RETRIES = 5
RETRY_DELAY_SECONDS = 10
REQUEST_DELAY_SECONDS = 5


PRIOR_RETURN_EXTRACTION_PROMPT = """You are a tax return analyzer. Extract carryover data from this prior year tax return.

IMPORTANT: This is a PRIOR YEAR return. We need data that carries forward to the NEXT year.

Look for and extract the following from Form 1040 and related schedules:

FROM FORM 1040:
- tax_year: The year this return is for (e.g., 2023)
- adjusted_gross_income: Line 11 - AGI (needed for e-file verification)
- filing_status: single, married_filing_jointly, etc.

FROM SCHEDULE D (Capital Gains and Losses):
Look at Part III - Summary, specifically:
- Line 16: If there's a LOSS, this is your capital loss for the year
- Line 21: Capital loss carryover to NEXT YEAR (if line 16 is a loss and exceeds $3,000)

Extract:
- capital_loss_carryover_short: Short-term capital loss carryover (if shown separately)
- capital_loss_carryover_long: Long-term capital loss carryover (if shown separately)
- total_capital_loss_carryover: Combined carryover if not separated

Note: The $3,000 limit ($1,500 MFS) is already deducted. Carryover = excess beyond that.

FROM SCHEDULE A (Itemized Deductions):
- charitable_contributions: Total charitable contributions claimed
- charitable_carryover: Excess contributions (over 60% AGI limit) carried forward

FROM FORM 8582 (Passive Activity Loss Limitations):
- passive_loss_carryover: Total suspended passive losses
- passive_loss_by_property: List of properties with suspended losses

FROM FORM 8801 (Credit for Prior Year Minimum Tax):
- amt_credit_carryforward: AMT credit available to carry forward

FROM NOL CARRYFORWARD (if applicable):
- nol_carryforward: Net Operating Loss carried forward

Respond ONLY with valid JSON:
{
  "success": true,
  "tax_year": 2023,
  "adjusted_gross_income": 75000.00,
  "filing_status": "single",
  "carryovers": {
    "capital_loss_short": 0.0,
    "capital_loss_long": 5000.0,
    "charitable": 0.0,
    "passive_loss": 0.0,
    "passive_loss_by_property": [],
    "amt_credit": 0.0,
    "nol": 0.0
  },
  "confidence": 0.85,
  "notes": "Any important notes about what was found or missing"
}

If this is NOT a tax return or carryover data cannot be extracted:
{
  "success": false,
  "error": "Description of the issue",
  "confidence": 0.0
}

Important:
- All monetary values as numbers (no $ or commas)
- Set confidence lower if pages are blurry or key schedules are missing
- If specific carryover types aren't found, use 0.0
- Note which schedules were found/missing in the notes field
"""


async def extract_prior_return(
    file_path: str,
    api_key: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Extract carryover data from a prior year tax return PDF.
    
    Args:
        file_path: Path to the prior year return PDF
        api_key: Gemini API key (uses env var if not provided)
        
    Returns:
        Dict with carryover data or error information
    """
    api_key = api_key or os.environ.get("GOOGLE_API_KEY") or os.environ.get("GEMINI_API_KEY")
    if not api_key:
        return {
            "success": False,
            "error": "No API key configured. Add your Gemini API key in Settings.",
            "confidence": 0.0
        }
    
    path = Path(file_path)
    if not path.exists():
        return {
            "success": False,
            "error": f"File not found: {file_path}",
            "confidence": 0.0
        }
    
    # Read and encode the PDF
    file_bytes = path.read_bytes()
    base64_data = base64.standard_b64encode(file_bytes).decode("utf-8")
    
    # Determine MIME type
    suffix = path.suffix.lower()
    mime_type = {
        ".pdf": "application/pdf",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
    }.get(suffix, "application/pdf")
    
    # Build Gemini API request
    # Using gemini-2.0-flash for better PDF handling
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={api_key}"
    
    request_body = {
        "contents": [
            {
                "parts": [
                    {
                        "inline_data": {
                            "mime_type": mime_type,
                            "data": base64_data
                        }
                    },
                    {
                        "text": PRIOR_RETURN_EXTRACTION_PROMPT
                    }
                ]
            }
        ],
        "generationConfig": {
            "temperature": 0.1,  # Low temperature for accuracy
            "maxOutputTokens": 2048,
        }
    }
    
    # Retry logic with exponential backoff
    for attempt in range(MAX_RETRIES):
        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                response = await client.post(url, json=request_body)
                
                if response.status_code == 429:
                    # Rate limited - wait and retry
                    wait_time = RETRY_DELAY_SECONDS * (2 ** attempt)
                    await asyncio.sleep(wait_time)
                    continue
                    
                if response.status_code != 200:
                    return {
                        "success": False,
                        "error": f"API error: {response.status_code} - {response.text[:200]}",
                        "confidence": 0.0
                    }
                
                result = response.json()
                
                # Extract text from response
                try:
                    text_response = result["candidates"][0]["content"]["parts"][0]["text"]
                except (KeyError, IndexError):
                    return {
                        "success": False,
                        "error": "Unexpected API response format",
                        "confidence": 0.0
                    }
                
                # Parse JSON from response
                # Handle markdown code blocks
                text_response = text_response.strip()
                if text_response.startswith("```"):
                    lines = text_response.split("\n")
                    # Remove first and last lines (```json and ```)
                    text_response = "\n".join(lines[1:-1])
                
                try:
                    parsed = json.loads(text_response)
                    return parsed
                except json.JSONDecodeError as e:
                    return {
                        "success": False,
                        "error": f"Failed to parse response: {str(e)}",
                        "raw_response": text_response[:500],
                        "confidence": 0.0
                    }
                    
        except httpx.TimeoutException:
            if attempt < MAX_RETRIES - 1:
                await asyncio.sleep(RETRY_DELAY_SECONDS)
                continue
            return {
                "success": False,
                "error": "Request timed out. The PDF may be too large.",
                "confidence": 0.0
            }
        except Exception as e:
            return {
                "success": False,
                "error": f"Unexpected error: {str(e)}",
                "confidence": 0.0
            }
    
    return {
        "success": False,
        "error": "Max retries exceeded. Please try again later.",
        "confidence": 0.0
    }


def apply_carryover_to_state(extraction_result: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert extraction result to state-compatible format.
    
    Returns dict that can be used to update TaxAppState fields.
    """
    if not extraction_result.get("success"):
        return {"error": extraction_result.get("error", "Extraction failed")}
    
    carryovers = extraction_result.get("carryovers", {})
    
    return {
        "prior_return_imported": True,
        "prior_return_year": extraction_result.get("tax_year", 0),
        "prior_year_agi": extraction_result.get("adjusted_gross_income", 0.0),
        "capital_loss_carryover_short": carryovers.get("capital_loss_short", 0.0),
        "capital_loss_carryover_long": carryovers.get("capital_loss_long", 0.0),
        "nol_carryforward": carryovers.get("nol", 0.0),
        "charitable_carryover": carryovers.get("charitable", 0.0),
        "amt_credit_carryforward": carryovers.get("amt_credit", 0.0),
        # Passive losses need special handling (list of dicts)
        "passive_loss_total": carryovers.get("passive_loss", 0.0),
        "passive_loss_by_property": carryovers.get("passive_loss_by_property", []),
        "confidence": extraction_result.get("confidence", 0.0),
        "notes": extraction_result.get("notes", ""),
    }
