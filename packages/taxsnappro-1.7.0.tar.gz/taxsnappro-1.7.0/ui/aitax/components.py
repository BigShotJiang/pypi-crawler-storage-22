"""
TaxSnapPro - Reusable UI Components (Fintech Light Theme)
"""
import reflex as rx
from typing import Callable


# ============== Theme Colors (Fintech Light) ==============
COLORS = {
    # Backgrounds
    "bg_page": "#f8fafc",           # Very light gray page background
    "bg_card": "white",              # Pure white cards
    "bg_hover": "#f1f5f9",           # Hover state
    "bg_input": "#f8fafc",           # Input background
    "bg_subtle": "#f1f5f9",          # Subtle background (same as hover)
    
    # Text (Improved contrast ratios for WCAG AA compliance)
    "text_primary": "#171717",       # Tailwind gray-900 (better contrast)
    "text_secondary": "#404040",     # Tailwind gray-700 (better readability) 
    "text_muted": "#525252",         # Tailwind gray-600 (5.74:1 contrast ratio vs old 3.15:1)
    
    # Borders
    "border": "#e2e8f0",             # Light border
    "border_focus": "#6366f1",       # Focus border (indigo)
    
    # Accents
    "accent_primary": "#6366f1",     # Indigo primary
    "accent_purple": "#8b5cf6",      # Purple gradient end
    "accent_light": "#eef2ff",       # Light indigo background
    
    # Status colors
    "success": "#10b981",
    "success_light": "#d1fae5",
    "warning": "#f59e0b",
    "warning_light": "#fef3c7",
    "error": "#ef4444",
    "error_light": "#fee2e2",
}


# ============== Base Components ==============
def fintech_card(*children, **props) -> rx.Component:
    """Fintech-style card with subtle shadow."""
    border = props.pop("border", f"1px solid {COLORS['border']}")
    padding = props.pop("padding", "24px")
    background = props.pop("background", COLORS["bg_card"])
    return rx.box(
        *children,
        background=background,
        border=border,
        border_radius="16px",
        padding=padding,
        box_shadow="0 1px 3px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.06)",
        **props,
    )


# Keep mercury_card as alias for compatibility
def mercury_card(*children, **props) -> rx.Component:
    """Alias for fintech_card."""
    return fintech_card(*children, **props)


def gradient_button(text: str, icon: str = None, **props) -> rx.Component:
    """Primary gradient button (indigo to purple)."""
    children = []
    if icon:
        children.append(rx.icon(icon, size=16))
    children.append(rx.text(text))
    
    return rx.box(
        rx.hstack(*children, spacing="2", justify="center"),
        background=f"linear-gradient(135deg, {COLORS['accent_primary']} 0%, {COLORS['accent_purple']} 100%)",
        color="white",
        padding="12px 24px",
        border_radius="8px",
        cursor="pointer",
        font_weight="500",
        font_size="15px",
        _hover={
            "opacity": "0.9",
            "transform": "translateY(-1px)",
            "box_shadow": "0 4px 12px rgba(99, 102, 241, 0.4)",
        },
        transition="all 0.2s ease",
        **props,
    )


def outline_button(text: str, **props) -> rx.Component:
    """Secondary outline button."""
    return rx.box(
        rx.text(text),
        background="white",
        color=COLORS["text_primary"],
        border=f"1px solid {COLORS['border']}",
        padding="12px 24px",
        border_radius="8px",
        cursor="pointer",
        font_weight="500",
        font_size="15px",
        _hover={
            "background": COLORS["bg_hover"],
            "border_color": COLORS["text_muted"],
        },
        transition="all 0.2s ease",
        **props,
    )


def stat_card(label: str, value: str, icon: str, color: str) -> rx.Component:
    """Statistics card with icon."""
    return fintech_card(
        rx.vstack(
            rx.hstack(
                rx.box(
                    rx.icon(icon, size=20, color=color),
                    background=f"rgba(99, 102, 241, 0.1)",
                    padding="10px",
                    border_radius="10px",
                ),
                rx.spacer(),
                spacing="2",
                width="100%",
            ),
            rx.text(value, color=COLORS["text_primary"], font_size="28px", font_weight="600"),
            rx.text(label, color=COLORS["text_muted"], font_size="14px"),
            align_items="start",
            spacing="2",
        ),
        min_width="180px",
        flex="1",
    )


def section_header(title: str, subtitle: str = None, action: rx.Component = None) -> rx.Component:
    """Section header with optional action button."""
    return rx.hstack(
        rx.vstack(
            rx.text(title, color=COLORS["text_primary"], font_size="18px", font_weight="600"),
            rx.cond(
                subtitle is not None,
                rx.text(subtitle, color=COLORS["text_muted"], font_size="14px"),
                rx.fragment(),
            ),
            align_items="start",
            spacing="1",
        ),
        rx.spacer(),
        rx.cond(action is not None, action, rx.fragment()),
        width="100%",
    )


def empty_state(icon: str, message: str, action_text: str = None, 
                action_href: str = None) -> rx.Component:
    """Empty state placeholder."""
    children = [
        rx.box(
            rx.icon(icon, size=48, color=COLORS["text_muted"]),
            background=COLORS["accent_light"],
            padding="24px",
            border_radius="50%",
        ),
        rx.text(message, color=COLORS["text_muted"], font_size="16px"),
    ]
    if action_text and action_href:
        children.append(
            rx.link(action_text, href=action_href, color=COLORS["accent_primary"], 
                    font_weight="500")
        )
    
    return rx.vstack(
        *children,
        align_items="center",
        padding="40px",
        spacing="4",
    )


def badge(text: str, color_scheme: str = "blue") -> rx.Component:
    """Status badge."""
    colors = {
        "blue": (COLORS["accent_primary"], COLORS["accent_light"]),
        "green": (COLORS["success"], COLORS["success_light"]),
        "yellow": ("#b45309", COLORS["warning_light"]),
        "red": (COLORS["error"], COLORS["error_light"]),
    }
    text_color, bg_color = colors.get(color_scheme, colors["blue"])
    
    return rx.box(
        rx.text(text, font_size="12px", font_weight="600"),
        background=bg_color,
        color=text_color,
        padding="4px 12px",
        border_radius="12px",
    )


def data_row(label: str, value: rx.Component) -> rx.Component:
    """Data display row."""
    return rx.hstack(
        rx.text(label, color=COLORS["text_muted"], font_size="14px"),
        rx.spacer(),
        value,
        width="100%",
        padding="8px 0",
    )


def input_field(label: str, placeholder: str = "", value: str = "",
                on_change: Callable = None, type: str = "text") -> rx.Component:
    """Styled input field."""
    return rx.vstack(
        rx.text(label, color=COLORS["text_secondary"], font_size="14px", font_weight="500"),
        rx.input(
            placeholder=placeholder,
            value=value,
            on_change=on_change,
            type=type,
            background=COLORS["bg_input"],
            border=f"1px solid {COLORS['border']}",
            color=COLORS["text_primary"],
            padding="12px 16px",
            border_radius="8px",
            width="100%",
            _focus={
                "border_color": COLORS["accent_primary"],
                "box_shadow": f"0 0 0 3px {COLORS['accent_light']}",
            },
        ),
        align_items="start",
        spacing="2",
        width="100%",
    )


def select_field(label: str, options: list, value: str = "",
                 on_change: Callable = None) -> rx.Component:
    """Styled select field."""
    return rx.vstack(
        rx.text(label, color=COLORS["text_secondary"], font_size="14px", font_weight="500"),
        rx.select(
            options,
            value=value,
            on_change=on_change,
            background=COLORS["bg_input"],
            border=f"1px solid {COLORS['border']}",
            color=COLORS["text_primary"],
            padding="12px 16px",
            border_radius="8px",
            width="100%",
        ),
        align_items="start",
        spacing="2",
        width="100%",
    )


# ============== Document Components ==============
def document_card(doc: dict, toggle_func: Callable = None) -> rx.Component:
    """Document list item card with include/exclude toggle."""
    return rx.hstack(
        # Toggle checkbox (only for parsed documents)
        rx.cond(
            doc["status"] == "parsed",
            rx.box(
                rx.cond(
                    doc["included"],
                    rx.icon("square-check", size=20, color=COLORS["success"]),
                    rx.icon("square", size=20, color=COLORS["text_muted"]),
                ),
                cursor="pointer",
                on_click=lambda: toggle_func(doc["name"]) if toggle_func else None
            ),
            rx.box(width="20px"),  # Spacer for non-parsed docs
        ),
        rx.box(
            rx.icon("file-text", size=20, 
                   color=rx.cond(
                       doc["status"] == "parsed",
                       rx.cond(doc["included"], COLORS["accent_primary"], COLORS["text_muted"]), 
                       COLORS["accent_primary"]
                   )),
            background=rx.cond(
                doc["status"] == "parsed",
                rx.cond(doc["included"], COLORS["accent_light"], COLORS["bg_hover"]),
                COLORS["accent_light"]
            ),
            padding="10px",
            border_radius="8px",
        ),
        rx.vstack(
            rx.text(doc["name"], 
                   color=rx.cond(
                       doc["status"] == "parsed",
                       rx.cond(doc["included"], COLORS["text_primary"], COLORS["text_muted"]),
                       COLORS["text_primary"]
                   ),
                   font_size="14px", font_weight="500",
                   text_decoration=rx.cond(
                       doc["status"] == "parsed",
                       rx.cond(doc["included"], "none", "line-through"),
                       "none"
                   )),
            rx.text(
                rx.cond(
                    doc["status"] == "parsed",
                    rx.cond(doc["included"], f"✓ Included - {doc['type']}", f"✗ Excluded - {doc['type']}"),
                    doc["type"]
                ),
                color=rx.cond(
                    doc["status"] == "parsed", 
                    rx.cond(doc["included"], COLORS["success"], COLORS["text_muted"]),
                    COLORS["text_muted"]
                ), 
                font_size="12px"),
            align_items="start",
            spacing="0",
        ),
        rx.spacer(),
        rx.cond(
            doc["status"] == "parsed",
            rx.cond(doc["included"], badge("Included", "green"), badge("Excluded", "gray")),
            badge("Pending", "yellow"),
        ),
        width="100%",
        padding="16px",
        background=COLORS["bg_card"],
        border_radius="12px",
        border=f"1px solid {COLORS['border']}",
        _hover={"background": COLORS["bg_hover"]},
        transition="all 0.15s ease",
    )


def w2_card(w2: dict, index: int, on_remove: Callable) -> rx.Component:
    """W-2 summary card."""
    return rx.hstack(
        rx.vstack(
            rx.text(w2["employer_name"], color=COLORS["text_primary"], font_weight="500"),
            rx.hstack(
                rx.text("Wages:", color=COLORS["text_muted"], font_size="13px"),
                rx.text(f"${w2['wages']:,.2f}", color=COLORS["success"], font_size="13px", font_weight="500"),
                rx.text("| Withheld:", color=COLORS["text_muted"], font_size="13px"),
                rx.text(f"${w2['federal_withheld']:,.2f}", color=COLORS["accent_primary"], font_size="13px", font_weight="500"),
                spacing="2",
            ),
            align_items="start",
            spacing="1",
        ),
        rx.spacer(),
        rx.icon(
            "trash-2", 
            size=16, 
            color=COLORS["error"],
            cursor="pointer",
            on_click=lambda: on_remove(index),
            _hover={"opacity": "0.7"},
        ),
        width="100%",
        padding="16px",
        background=COLORS["bg_card"],
        border_radius="12px",
        border=f"1px solid {COLORS['border']}",
    )


def income_1099_card(form: dict, index: int, on_remove: Callable) -> rx.Component:
    """1099 summary card."""
    return rx.hstack(
        rx.vstack(
            rx.hstack(
                badge(form["form_type"], "blue"),
                rx.text(form["payer_name"], color=COLORS["text_primary"], font_weight="500"),
                spacing="2",
            ),
            rx.text(f"${form['amount']:,.2f}", color=COLORS["success"], font_size="14px", font_weight="500"),
            align_items="start",
            spacing="1",
        ),
        rx.spacer(),
        rx.icon(
            "trash-2", 
            size=16, 
            color=COLORS["error"],
            cursor="pointer",
            on_click=lambda: on_remove(index),
            _hover={"opacity": "0.7"},
        ),
        width="100%",
        padding="16px",
        background=COLORS["bg_card"],
        border_radius="12px",
        border=f"1px solid {COLORS['border']}",
    )


# ============== Navigation ==============
def cache_clear_option(title: str, description: str, clear_type: str, is_dangerous: bool = False) -> rx.Component:
    """Cache clear option with clear button."""
    from .state import TaxAppState
    
    color_scheme = COLORS["error"] if is_dangerous else COLORS["text_primary"]
    bg_scheme = COLORS["error_light"] if is_dangerous else COLORS["bg_hover"]
    
    return rx.hstack(
        rx.vstack(
            rx.text(title, color=color_scheme, font_size="15px", font_weight="600"),
            rx.text(description, color=COLORS["text_muted"], font_size="13px"),
            align_items="start",
            spacing="1",
        ),
        rx.spacer(),
        rx.box(
            rx.text("Clear", font_size="14px"),
            background=bg_scheme,
            color=color_scheme,
            border=f"1px solid {color_scheme}" if not is_dangerous else "none",
            padding="8px 16px",
            border_radius="6px",
            cursor="pointer",
            font_weight="500",
            on_click=lambda: TaxAppState.show_cache_clear_modal(clear_type),
            _hover={"opacity": "0.8"},
        ),
        width="100%",
        align_items="center",
        padding="16px 0",
        border_bottom=f"1px solid {COLORS['border']}",
    )


def cache_clear_modal() -> rx.Component:
    """Cache clear confirmation modal."""
    from .state import TaxAppState
    
    return rx.cond(
        TaxAppState.show_cache_modal,
        rx.box(
            # Backdrop
            rx.box(
                position="fixed",
                top="0",
                left="0",
                right="0",
                bottom="0",
                background="rgba(0,0,0,0.5)",
                z_index="200",
                on_click=TaxAppState.close_cache_modal,
            ),
            # Modal content
            rx.box(
                rx.vstack(
                    # Header
                    rx.hstack(
                        rx.hstack(
                            rx.icon("triangle_alert", size=24, color=COLORS["warning"]),
                            rx.text(TaxAppState.cache_modal_title, color=COLORS["text_primary"], 
                                   font_size="20px", font_weight="600"),
                            spacing="3",
                        ),
                        rx.spacer(),
                        rx.icon("x", size=20, color=COLORS["text_muted"], cursor="pointer",
                               on_click=TaxAppState.close_cache_modal, 
                               _hover={"color": COLORS["text_primary"]}),
                        width="100%",
                    ),
                    rx.divider(border_color=COLORS["border"]),
                    
                    # Body
                    rx.text(
                        TaxAppState.cache_modal_message,
                        color=COLORS["text_secondary"],
                        font_size="14px",
                        line_height="1.6",
                        white_space="pre-line",  # Preserve line breaks
                    ),
                    
                    # Footer buttons
                    rx.hstack(
                        rx.button(
                            "Cancel",
                            background="white",
                            color=COLORS["text_primary"],
                            border=f"1px solid {COLORS['border']}",
                            padding="10px 20px",
                            border_radius="8px",
                            cursor="pointer",
                            on_click=TaxAppState.close_cache_modal,
                            _hover={"background": COLORS["bg_hover"]},
                        ),
                        rx.button(
                            "Clear Data",
                            background=COLORS["error"],
                            color="white",
                            padding="10px 20px",
                            border_radius="8px",
                            cursor="pointer",
                            on_click=TaxAppState.confirm_cache_clear,
                            _hover={"opacity": "0.9"},
                        ),
                        spacing="3",
                        justify="end",
                        width="100%",
                    ),
                    
                    spacing="4",
                    width="100%",
                ),
                position="fixed",
                top="50%",
                left="50%",
                transform="translate(-50%, -50%)",
                background="white",
                border_radius="16px",
                padding="24px",
                box_shadow="0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04)",
                max_width="500px",
                width="90%",
                z_index="300",
                border=f"1px solid {COLORS['border']}",
            ),
        ),
    )


def cache_status_card() -> rx.Component:
    """Show current cache status."""
    from .state import TaxAppState
    
    return fintech_card(
        rx.vstack(
            rx.hstack(
                rx.box(
                    rx.icon("hard-drive", size=20, color=COLORS["accent_primary"]),
                    background=COLORS["accent_light"],
                    padding="10px",
                    border_radius="8px",
                ),
                rx.text("Cached Data Status", color=COLORS["text_primary"], 
                        font_size="18px", font_weight="600"),
                spacing="3",
            ),
            rx.divider(border_color=COLORS["border"]),
            
            rx.text(
                "TaxSnapPro stores data locally on YOUR device for performance and convenience.",
                color=COLORS["text_muted"],
                font_size="14px",
                line_height="1.5",
            ),
            
            # Cache stats
            rx.vstack(
                data_row(
                    "📄 Processed Documents", 
                    rx.hstack(
                        rx.text(TaxAppState.cache_stats_documents_processed, 
                               color=rx.cond(TaxAppState.cache_stats_documents_processed > 0, 
                                           COLORS["success"], COLORS["text_muted"]),
                               font_weight="600"),
                        rx.text("files", 
                               color=rx.cond(TaxAppState.cache_stats_documents_processed > 0, 
                                           COLORS["success"], COLORS["text_muted"])),
                        spacing="1",
                    )
                ),
                data_row(
                    "👤 Personal Information", 
                    rx.cond(TaxAppState.cache_stats_personal_info_complete,
                           rx.text("Saved", color=COLORS["success"]),
                           rx.text("Empty", color=COLORS["text_muted"]))
                ),
                data_row(
                    "💰 W-2 Forms", 
                    rx.hstack(
                        rx.text(TaxAppState.cache_stats_w2_count, 
                               color=rx.cond(TaxAppState.cache_stats_w2_count > 0, 
                                           COLORS["success"], COLORS["text_muted"]),
                               font_weight="600"),
                        rx.text("forms", 
                               color=rx.cond(TaxAppState.cache_stats_w2_count > 0, 
                                           COLORS["success"], COLORS["text_muted"])),
                        spacing="1",
                    )
                ),
                data_row(
                    "📊 1099 Forms", 
                    rx.hstack(
                        rx.text(TaxAppState.cache_stats_form_1099_count, 
                               color=rx.cond(TaxAppState.cache_stats_form_1099_count > 0, 
                                           COLORS["success"], COLORS["text_muted"]),
                               font_weight="600"),
                        rx.text("forms", 
                               color=rx.cond(TaxAppState.cache_stats_form_1099_count > 0, 
                                           COLORS["success"], COLORS["text_muted"])),
                        spacing="1",
                    )
                ),
                data_row(
                    "📈 Total Data Entries", 
                    rx.hstack(
                        rx.text(TaxAppState.cache_stats_total_entries, 
                               color=COLORS["text_primary"], font_weight="600"),
                        rx.text("items", color=COLORS["text_primary"]),
                        spacing="1",
                    )
                ),
                spacing="2",
            ),
            spacing="4",
        )
    )


def privacy_explanation_card() -> rx.Component:
    """Explain data privacy and caching."""
    return fintech_card(
        rx.vstack(
            rx.hstack(
                rx.box(
                    rx.icon("shield-check", size=20, color=COLORS["success"]),
                    background=COLORS["success_light"],
                    padding="10px",
                    border_radius="8px",
                ),
                rx.text("🔒 Your Data Privacy", color=COLORS["text_primary"], 
                        font_size="18px", font_weight="600"),
                spacing="3",
            ),
            rx.divider(border_color=COLORS["border"]),
            
            rx.vstack(
                rx.hstack(
                    rx.icon("check_check", size=16, color=COLORS["success"]),
                    rx.text("All data stored locally on YOUR device only", 
                           color=COLORS["text_primary"], font_size="14px"),
                    spacing="2",
                ),
                rx.hstack(
                    rx.icon("check_check", size=16, color=COLORS["success"]),
                    rx.text("AI processing uses YOUR Gemini API key directly", 
                           color=COLORS["text_primary"], font_size="14px"),
                    spacing="2",
                ),
                rx.hstack(
                    rx.icon("check_check", size=16, color=COLORS["success"]),
                    rx.text("No data uploaded to our servers", 
                           color=COLORS["text_primary"], font_size="14px"),
                    spacing="2",
                ),
                rx.hstack(
                    rx.icon("x", size=16, color=COLORS["error"]),
                    rx.text("We cannot access your information remotely", 
                           color=COLORS["text_primary"], font_size="14px"),
                    spacing="2",
                ),
                align_items="start",
                spacing="3",
            ),
            
            rx.box(
                rx.text(
                    "💡 Why we cache data: To avoid re-processing documents (saves time + API costs) "
                    "and to pre-fill forms for your convenience. You have full control below.",
                    color=COLORS["text_muted"],
                    font_size="13px",
                    line_height="1.5",
                    font_style="italic",
                ),
                background=COLORS["bg_subtle"],
                padding="12px 16px",
                border_radius="8px",
                margin_top="8px",
            ),
            spacing="4",
        ),
        border=f"1px solid {COLORS['success']}",
    )


def nav_bar() -> rx.Component:
    """Top navigation bar."""
    return rx.box(
        rx.hstack(
            rx.hstack(
                rx.text("🔨", font_size="24px"),
                rx.text("TaxSnapPro", color=COLORS["text_primary"], font_size="20px", font_weight="700"),
                spacing="2",
            ),
            rx.spacer(),
            rx.hstack(
                rx.link("Dashboard", href="/", color=COLORS["text_secondary"], font_weight="500",
                        _hover={"color": COLORS["accent_primary"]}),
                rx.link("Upload", href="/upload", color=COLORS["text_secondary"], font_weight="500",
                        _hover={"color": COLORS["accent_primary"]}),
                rx.link("Review", href="/review", color=COLORS["text_secondary"], font_weight="500",
                        _hover={"color": COLORS["accent_primary"]}),
                rx.link("Settings", href="/settings", color=COLORS["text_secondary"], font_weight="500",
                        _hover={"color": COLORS["accent_primary"]}),
                spacing="6",
            ),
            width="100%",
            max_width="1200px",
            margin="0 auto",
            padding="20px 40px",
        ),
        background="rgba(255, 255, 255, 0.95)",
        border_bottom=f"1px solid {COLORS['border']}",
        backdrop_filter="blur(10px)",
        position="fixed",
        top="0",
        left="0",
        right="0",
        z_index="100",
    )


def disclaimer_banner() -> rx.Component:
    """Legal disclaimer banner."""
    return rx.box(
        rx.hstack(
            rx.icon("alert-triangle", size=16, color="#92400e"),
            rx.text(
                "⚠️ This tool is for educational purposes only and does not constitute tax, legal, or financial advice. "
                "Always consult a qualified tax professional before filing. Use at your own risk.",
                font_size="12px",
                color="#92400e",
            ),
            spacing="2",
            align="center",
            justify="center",
        ),
        padding="8px 16px",
        background="#fef3c7",
        border_bottom="1px solid #f59e0b",
        text_align="center",
    )


def page_container(*children) -> rx.Component:
    """Page container with nav and proper padding."""
    return rx.box(
        disclaimer_banner(),
        nav_bar(),
        rx.box(
            *children,
            min_height="100vh",
            background=COLORS["bg_page"],
        ),
    )


# ============== Modal / Dialog ==============
def api_key_modal(is_open: bool, on_close: Callable, api_key_value: str, 
                  on_api_key_change: Callable, on_save: Callable) -> rx.Component:
    """API key configuration modal."""
    return rx.cond(
        is_open,
        rx.box(
            # Backdrop
            rx.box(
                position="fixed",
                top="0",
                left="0",
                right="0",
                bottom="0",
                background="rgba(0,0,0,0.5)",
                z_index="200",
                on_click=on_close,
            ),
            # Modal content
            rx.box(
                rx.vstack(
                    # Header
                    rx.hstack(
                        rx.hstack(
                            rx.icon("key", size=24, color=COLORS["accent_primary"]),
                            rx.text("Configure API Key", color=COLORS["text_primary"], 
                                   font_size="20px", font_weight="600"),
                            spacing="3",
                        ),
                        rx.spacer(),
                        rx.icon("x", size=20, color=COLORS["text_muted"], cursor="pointer",
                               on_click=on_close, _hover={"color": COLORS["text_primary"]}),
                        width="100%",
                    ),
                    
                    # Body
                    rx.box(
                        rx.vstack(
                            rx.box(
                                rx.hstack(
                                    rx.icon("circle-alert", size=16, color=COLORS["warning"]),
                                    rx.text("API key required for document parsing", 
                                           color="#b45309", font_size="14px", font_weight="500"),
                                    spacing="2",
                                ),
                                background=COLORS["warning_light"],
                                padding="12px 16px",
                                border_radius="8px",
                                width="100%",
                            ),
                            rx.text(
                                "TaxSnapPro uses Google Gemini (FREE) to extract data from your tax documents. "
                                "Get your API key in 30 seconds:",
                                color=COLORS["text_secondary"],
                                font_size="14px",
                                line_height="1.6",
                            ),
                            rx.vstack(
                                rx.hstack(
                                    rx.box(
                                        rx.text("1", font_size="12px", font_weight="600", color="white"),
                                        background=COLORS["accent_primary"],
                                        padding="4px 10px",
                                        border_radius="50%",
                                    ),
                                    rx.text("Go to ", color=COLORS["text_secondary"], font_size="14px"),
                                    rx.link(
                                        "aistudio.google.com/apikey",
                                        href="https://aistudio.google.com/apikey",
                                        color=COLORS["accent_primary"],
                                        font_weight="500",
                                        is_external=True,
                                    ),
                                    spacing="2",
                                ),
                                rx.hstack(
                                    rx.box(
                                        rx.text("2", font_size="12px", font_weight="600", color="white"),
                                        background=COLORS["accent_primary"],
                                        padding="4px 10px",
                                        border_radius="50%",
                                    ),
                                    rx.text("Sign in with Google and click 'Create API Key'", 
                                           color=COLORS["text_secondary"], font_size="14px"),
                                    spacing="2",
                                ),
                                rx.hstack(
                                    rx.box(
                                        rx.text("3", font_size="12px", font_weight="600", color="white"),
                                        background=COLORS["accent_primary"],
                                        padding="4px 10px",
                                        border_radius="50%",
                                    ),
                                    rx.text("Copy and paste your key below", 
                                           color=COLORS["text_secondary"], font_size="14px"),
                                    spacing="2",
                                ),
                                spacing="3",
                                align_items="start",
                                padding="8px 0",
                            ),
                            rx.vstack(
                                rx.text("Gemini API Key", color=COLORS["text_secondary"], 
                                       font_size="14px", font_weight="500"),
                                rx.input(
                                    placeholder="AIza...",
                                    type="password",
                                    value=api_key_value,
                                    on_change=on_api_key_change,
                                    background=COLORS["bg_input"],
                                    border=f"1px solid {COLORS['border']}",
                                    color=COLORS["text_primary"],
                                    padding="12px 16px",
                                    border_radius="8px",
                                    width="100%",
                                    _focus={
                                        "border_color": COLORS["accent_primary"],
                                        "box_shadow": f"0 0 0 3px {COLORS['accent_light']}",
                                    },
                                ),
                                spacing="2",
                                width="100%",
                            ),
                            rx.hstack(
                                rx.icon("circle-check", size=14, color=COLORS["success"]),
                                rx.text("FREE: 1,500 requests/day — more than enough!", 
                                       color=COLORS["success"], font_size="13px", font_weight="500"),
                                spacing="2",
                            ),
                            spacing="4",
                            width="100%",
                        ),
                        padding="16px 0",
                        width="100%",
                    ),
                    
                    # Footer
                    rx.hstack(
                        rx.spacer(),
                        outline_button("Cancel", on_click=on_close),
                        gradient_button("Save & Continue", on_click=on_save),
                        spacing="3",
                        width="100%",
                        padding_top="8px",
                    ),
                    
                    spacing="4",
                    width="100%",
                ),
                background="white",
                border_radius="16px",
                padding="24px",
                box_shadow="0 25px 50px -12px rgba(0, 0, 0, 0.25)",
                position="fixed",
                top="50%",
                left="50%",
                transform="translate(-50%, -50%)",
                z_index="201",
                width="90%",
                max_width="480px",
            ),
        ),
    )


def processing_overlay(
    is_processing: bool,
    current_file: str,
    file_index: int,
    total_files: int,
) -> rx.Component:
    """Full-screen processing overlay with progress."""
    return rx.cond(
        is_processing,
        rx.box(
            # Backdrop
            rx.box(
                position="fixed",
                top="0",
                left="0",
                right="0",
                bottom="0",
                background="rgba(0, 0, 0, 0.5)",
                z_index="300",
            ),
            # Modal
            rx.box(
                rx.vstack(
                    rx.box(
                        rx.spinner(size="3", color=COLORS["accent_primary"]),
                        padding="16px",
                        background=COLORS["accent_light"],
                        border_radius="50%",
                    ),
                    rx.text("Processing Documents", 
                            color=COLORS["text_primary"],
                            font_size="20px", 
                            font_weight="600"),
                    rx.text(f"File {file_index} of {total_files}",
                            color=COLORS["text_secondary"],
                            font_size="14px"),
                    rx.text(current_file,
                            color=COLORS["accent_primary"],
                            font_size="14px",
                            font_weight="500",
                            max_width="280px",
                            overflow="hidden",
                            text_overflow="ellipsis",
                            white_space="nowrap"),
                    rx.box(
                        rx.progress(
                            value=file_index,
                            max=total_files,
                            width="100%",
                            color_scheme="indigo",
                        ),
                        width="100%",
                        padding="8px 0",
                    ),
                    rx.text("Please wait while AI extracts data...",
                            color=COLORS["text_muted"],
                            font_size="13px"),
                    spacing="3",
                    align_items="center",
                    width="100%",
                ),
                background="white",
                border_radius="16px",
                padding="32px",
                box_shadow="0 25px 50px -12px rgba(0, 0, 0, 0.25)",
                position="fixed",
                top="50%",
                left="50%",
                transform="translate(-50%, -50%)",
                z_index="301",
                width="90%",
                max_width="360px",
                text_align="center",
            ),
        ),
    )


def deductions_breakdown_modal() -> rx.Component:
    """Modal showing deductions breakdown."""
    from .state import TaxAppState
    
    return rx.cond(
        TaxAppState.show_deductions_modal,
        rx.box(
            # Backdrop
            rx.box(
                position="fixed",
                top="0",
                left="0",
                right="0",
                bottom="0",
                background="rgba(0,0,0,0.5)",
                z_index="200",
                on_click=TaxAppState.close_deductions_modal,
            ),
            # Modal content
            rx.box(
                rx.vstack(
                    # Header
                    rx.hstack(
                        rx.hstack(
                            rx.icon("receipt", size=24, color=COLORS["warning"]),
                            rx.text("Deductions Breakdown", color=COLORS["text_primary"], 
                                   font_size="20px", font_weight="600"),
                            spacing="3",
                        ),
                        rx.spacer(),
                        rx.icon("x", size=20, color=COLORS["text_muted"], cursor="pointer",
                               on_click=TaxAppState.close_deductions_modal, 
                               _hover={"color": COLORS["text_primary"]}),
                        width="100%",
                    ),
                    
                    rx.divider(border_color=COLORS["border"]),
                    
                    # Deduction Type Comparison
                    rx.vstack(
                        rx.text("Deduction Comparison", font_weight="600", color=COLORS["text_primary"]),
                        rx.hstack(
                            rx.vstack(
                                rx.text("Standard", color=COLORS["text_muted"], font_size="13px"),
                                rx.text(TaxAppState.formatted_standard_deduction, 
                                       color=rx.cond(TaxAppState.deduction_type_label == "Standard", 
                                                    COLORS["success"], COLORS["text_primary"]),
                                       font_weight="600", font_size="18px"),
                                rx.cond(
                                    TaxAppState.deduction_type_label == "Standard",
                                    rx.badge("Used", color_scheme="green"),
                                    rx.fragment(),
                                ),
                                align_items="center",
                                padding="16px",
                                background=rx.cond(TaxAppState.deduction_type_label == "Standard",
                                                  COLORS["success_light"], COLORS["bg_hover"]),
                                border_radius="8px",
                                flex="1",
                            ),
                            rx.vstack(
                                rx.text("Itemized", color=COLORS["text_muted"], font_size="13px"),
                                rx.text(TaxAppState.formatted_itemized_deductions,
                                       color=rx.cond(TaxAppState.deduction_type_label == "Itemized", 
                                                    COLORS["success"], COLORS["text_primary"]),
                                       font_weight="600", font_size="18px"),
                                rx.cond(
                                    TaxAppState.deduction_type_label == "Itemized",
                                    rx.badge("Used", color_scheme="green"),
                                    rx.fragment(),
                                ),
                                align_items="center",
                                padding="16px",
                                background=rx.cond(TaxAppState.deduction_type_label == "Itemized",
                                                  COLORS["success_light"], COLORS["bg_hover"]),
                                border_radius="8px",
                                flex="1",
                            ),
                            spacing="4",
                            width="100%",
                        ),
                        spacing="3",
                        width="100%",
                    ),
                    
                    rx.divider(border_color=COLORS["border"]),
                    
                    # Itemized Breakdown (if applicable)
                    rx.vstack(
                        rx.text("Itemized Deduction Details", font_weight="600", color=COLORS["text_primary"]),
                        data_row("Mortgage Interest (1098)", 
                                rx.text(TaxAppState.formatted_mortgage_interest, color=COLORS["text_primary"])),
                        data_row("SALT (capped at $10k)", 
                                rx.text(TaxAppState.formatted_salt_deduction, color=COLORS["text_primary"])),
                        spacing="2",
                        width="100%",
                    ),
                    
                    rx.divider(border_color=COLORS["border"]),
                    
                    # Above-the-line Deductions
                    rx.vstack(
                        rx.text("Above-the-Line Deductions", font_weight="600", color=COLORS["text_primary"]),
                        rx.text("(reduce AGI before standard/itemized)", color=COLORS["text_muted"], font_size="12px"),
                        data_row("HSA Contributions", 
                                rx.text(TaxAppState.formatted_hsa_deduction, color=COLORS["text_primary"])),
                        data_row("Self-Employment Deduction", 
                                rx.text(TaxAppState.formatted_se_deduction, color=COLORS["text_primary"])),
                        spacing="2",
                        width="100%",
                    ),
                    
                    # Close button
                    rx.hstack(
                        rx.spacer(),
                        rx.button(
                            "Close",
                            on_click=TaxAppState.close_deductions_modal,
                            variant="soft",
                        ),
                        width="100%",
                    ),
                    
                    spacing="4",
                    padding="24px",
                    width="100%",
                ),
                position="fixed",
                top="50%",
                left="50%",
                transform="translate(-50%, -50%)",
                background="white",
                border_radius="16px",
                box_shadow="0 20px 25px -5px rgba(0, 0, 0, 0.1)",
                z_index="201",
                width="90%",
                max_width="480px",
            ),
        ),
    )


def tax_estimate_breakdown_modal() -> rx.Component:
    """Modal showing tax estimate breakdown."""
    from .state import TaxAppState
    
    return rx.cond(
        TaxAppState.show_tax_estimate_modal,
        rx.box(
            # Backdrop
            rx.box(
                position="fixed",
                top="0",
                left="0",
                right="0",
                bottom="0",
                background="rgba(0,0,0,0.5)",
                z_index="200",
                on_click=TaxAppState.close_tax_estimate_modal,
            ),
            # Modal content
            rx.box(
                rx.vstack(
                    # Header
                    rx.hstack(
                        rx.hstack(
                            rx.icon("calculator", size=24, color=COLORS["error"]),
                            rx.text("Tax Calculation Breakdown", color=COLORS["text_primary"], 
                                   font_size="20px", font_weight="600"),
                            spacing="3",
                        ),
                        rx.spacer(),
                        rx.icon("x", size=20, color=COLORS["text_muted"], cursor="pointer",
                               on_click=TaxAppState.close_tax_estimate_modal, 
                               _hover={"color": COLORS["text_primary"]}),
                        width="100%",
                    ),
                    
                    rx.divider(border_color=COLORS["border"]),
                    
                    # Taxes Section
                    rx.vstack(
                        rx.text("Federal Income Taxes", font_weight="600", color=COLORS["text_primary"]),
                        data_row("Regular Income Tax", 
                                rx.text(TaxAppState.formatted_ordinary_tax, color=COLORS["error"])),
                        data_row("Capital Gains Tax", 
                                rx.text(TaxAppState.formatted_capital_gains_tax, color=COLORS["error"])),
                        data_row("Self-Employment Tax", 
                                rx.text(TaxAppState.formatted_se_tax, color=COLORS["error"])),
                        data_row("Additional Medicare Tax", 
                                rx.text(TaxAppState.formatted_additional_medicare, color=COLORS["error"])),
                        data_row("NIIT (Investment Tax)", 
                                rx.text(TaxAppState.formatted_niit, color=COLORS["error"])),
                        spacing="2",
                        width="100%",
                    ),
                    
                    rx.divider(border_color=COLORS["border"]),
                    
                    # Credits Section
                    rx.vstack(
                        rx.text("Tax Credits (Reduce Tax)", font_weight="600", color=COLORS["text_primary"]),
                        data_row("Child Tax Credit", 
                                rx.text(f"-{TaxAppState.formatted_child_tax_credit}", color=COLORS["success"])),
                        data_row("Other Dependent Credit + Child Care", 
                                rx.text(f"-{TaxAppState.formatted_other_credits}", color=COLORS["success"])),
                        rx.divider(border_color=COLORS["border"]),
                        data_row("Total Credits", 
                                rx.text(f"-{TaxAppState.formatted_total_credits}", color=COLORS["success"], font_weight="600")),
                        spacing="2",
                        width="100%",
                    ),
                    
                    rx.divider(border_color=COLORS["border"]),
                    
                    # Final Total
                    rx.hstack(
                        rx.text("Total Tax After Credits", font_weight="600", color=COLORS["text_primary"]),
                        rx.spacer(),
                        rx.text(f"${TaxAppState.total_tax:,.0f}", 
                               color=COLORS["error"], font_weight="700", font_size="20px"),
                        width="100%",
                        padding="12px",
                        background=COLORS["error_light"],
                        border_radius="8px",
                    ),
                    
                    # Close button
                    rx.hstack(
                        rx.spacer(),
                        rx.button(
                            "Close",
                            on_click=TaxAppState.close_tax_estimate_modal,
                            variant="soft",
                        ),
                        width="100%",
                    ),
                    
                    spacing="4",
                    padding="24px",
                    width="100%",
                ),
                position="fixed",
                top="50%",
                left="50%",
                transform="translate(-50%, -50%)",
                background="white",
                border_radius="16px",
                box_shadow="0 20px 25px -5px rgba(0, 0, 0, 0.1)",
                z_index="201",
                width="90%",
                max_width="480px",
            ),
        ),
    )


def clickable_stat_card(label: str, value: str, icon: str, color: str, on_click) -> rx.Component:
    """Clickable statistics card with icon - opens breakdown modal."""
    return fintech_card(
        rx.vstack(
            rx.hstack(
                rx.box(
                    rx.icon(icon, size=20, color=color),
                    background=f"rgba(99, 102, 241, 0.1)",
                    padding="10px",
                    border_radius="10px",
                ),
                rx.spacer(),
                rx.icon("chevron-right", size=16, color=COLORS["text_muted"]),
                spacing="2",
                width="100%",
            ),
            rx.text(value, color=COLORS["text_primary"], font_size="28px", font_weight="600"),
            rx.text(label, color=COLORS["text_muted"], font_size="14px"),
            align_items="start",
            spacing="2",
        ),
        min_width="180px",
        flex="1",
        cursor="pointer",
        on_click=on_click,
        _hover={
            "border_color": COLORS["accent_primary"],
            "box_shadow": f"0 4px 12px rgba(99, 102, 241, 0.15)",
        },
        transition="all 0.2s ease",
    )


def expandable_section(title: str, value: str, is_expanded: bool, on_toggle, children: list, value_color: str = COLORS["text_primary"]) -> rx.Component:
    """Expandable section for tax calculation details."""
    return rx.box(
        rx.vstack(
            # Header row (always visible)
            rx.hstack(
                rx.icon(
                    rx.cond(is_expanded, "chevron-down", "chevron-right"),
                    size=16,
                    color=COLORS["text_muted"],
                ),
                rx.text(title, color=COLORS["text_muted"], font_size="14px"),
                rx.spacer(),
                rx.text(value, color=value_color, font_weight="500"),
                width="100%",
                cursor="pointer",
                on_click=on_toggle,
                padding="8px 0",
                _hover={"background": COLORS["bg_hover"]},
            ),
            # Expandable content
            rx.cond(
                is_expanded,
                rx.box(
                    rx.vstack(
                        *children,
                        spacing="2",
                        width="100%",
                        padding_left="24px",
                        padding_top="8px",
                        padding_bottom="8px",
                    ),
                    background=COLORS["bg_subtle"],
                    border_radius="8px",
                    margin_top="4px",
                ),
            ),
            spacing="0",
            width="100%",
        ),
    )


def sub_data_row(label: str, value: str, color: str = COLORS["text_secondary"]) -> rx.Component:
    """Sub-row for expandable section details."""
    return rx.hstack(
        rx.text(label, color=COLORS["text_muted"], font_size="13px"),
        rx.spacer(),
        rx.text(value, color=color, font_size="13px"),
        width="100%",
    )


def privacy_confirmation_modal(is_open: bool, on_close: Callable, on_confirm: Callable) -> rx.Component:
    """Privacy confirmation modal for AI processing."""
    return rx.cond(
        is_open,
        rx.box(
            # Backdrop
            rx.box(
                position="fixed",
                top="0",
                left="0",
                right="0",
                bottom="0",
                background="rgba(0,0,0,0.5)",
                z_index="200",
                on_click=on_close,
            ),
            # Modal content
            rx.box(
                rx.vstack(
                    # Header
                    rx.hstack(
                        rx.hstack(
                            rx.icon("shield-check", size=24, color=COLORS["accent_primary"]),
                            rx.text("数据隐私确认", color=COLORS["text_primary"], 
                                   font_size="20px", font_weight="600"),
                            spacing="3",
                        ),
                        rx.spacer(),
                        rx.icon("x", size=20, color=COLORS["text_muted"], cursor="pointer",
                               on_click=on_close, _hover={"color": COLORS["text_primary"]}),
                        width="100%",
                    ),
                    
                    # Privacy notice
                    rx.box(
                        rx.hstack(
                            rx.icon("lock", size=16, color=COLORS["success"]),
                            rx.text("您的数据完全安全", 
                                   color="#059669", font_size="14px", font_weight="500"),
                            spacing="2",
                        ),
                        background=COLORS["success_light"],
                        padding="12px 16px",
                        border_radius="8px",
                        width="100%",
                    ),
                    
                    # Privacy explanation
                    rx.vstack(
                        rx.text(
                            "🔒 本地处理：所有数据都保存在您的本地设备上",
                            color=COLORS["text_secondary"],
                            font_size="14px",
                            line_height="1.6",
                        ),
                        rx.text(
                            "🛡️ 隐私保护：我们无法访问您的任何文件或信息",
                            color=COLORS["text_secondary"],
                            font_size="14px",
                            line_height="1.6",
                        ),
                        rx.text(
                            "🤖 AI处理：仅用您自己的API密钥调用AI模型解析文档",
                            color=COLORS["text_secondary"],
                            font_size="14px",
                            line_height="1.6",
                        ),
                        spacing="2",
                        align_items="flex_start",
                        width="100%",
                    ),
                    
                    # Confirmation text
                    rx.box(
                        rx.text(
                            "点击「同意并处理」即表示您允许使用您自己的大模型API来分析您上传的税务文档。",
                            color=COLORS["text_muted"],
                            font_size="13px",
                            line_height="1.5",
                            text_align="center",
                        ),
                        background=COLORS["bg_subtle"],
                        padding="16px",
                        border_radius="8px",
                        width="100%",
                    ),
                    
                    # Buttons
                    rx.hstack(
                        rx.button(
                            "取消",
                            on_click=on_close,
                            size="3",
                            variant="outline",
                            cursor="pointer",
                        ),
                        rx.button(
                            rx.icon("check", size=16),
                            "同意并处理",
                            on_click=on_confirm,
                            size="3",
                            cursor="pointer",
                            background=COLORS["accent_primary"],
                            color="white",
                            _hover={"background": COLORS["accent_purple"]},
                        ),
                        spacing="3",
                        width="100%",
                    ),
                    
                    spacing="6",
                    width="100%",
                ),
                background="white",
                border_radius="16px",
                padding="24px",
                box_shadow="0 25px 50px -12px rgba(0, 0, 0, 0.25)",
                position="fixed",
                top="50%",
                left="50%",
                transform="translate(-50%, -50%)",
                z_index="201",
                width="90%",
                max_width="480px",
            ),
        ),
    )


def prior_return_import_modal() -> rx.Component:
    """Modal for importing prior year tax return."""
    from .state import TaxAppState
    
    return rx.cond(
        TaxAppState.show_prior_return_modal,
        rx.box(
            # Backdrop
            rx.box(
                position="fixed",
                top="0",
                left="0",
                right="0",
                bottom="0",
                background="rgba(0,0,0,0.5)",
                z_index="200",
                on_click=TaxAppState.close_prior_return_modal,
            ),
            # Modal content
            rx.box(
                rx.vstack(
                    # Header
                    rx.hstack(
                        rx.hstack(
                            rx.icon("file-clock", size=24, color=COLORS["accent_primary"]),
                            rx.text("Import Prior Year Return", color=COLORS["text_primary"], 
                                   font_size="20px", font_weight="600"),
                            spacing="3",
                        ),
                        rx.spacer(),
                        rx.icon("x", size=20, color=COLORS["text_muted"], cursor="pointer",
                               on_click=TaxAppState.close_prior_return_modal, 
                               _hover={"color": COLORS["text_primary"]}),
                        width="100%",
                    ),
                    
                    rx.divider(border_color=COLORS["border"]),
                    
                    # Description
                    rx.text(
                        "Upload your prior year tax return (PDF) to automatically import carryover data like capital losses, NOL, and charitable contribution carryovers.",
                        color=COLORS["text_muted"],
                        font_size="14px",
                        line_height="1.6",
                    ),
                    
                    # Upload area (when no result yet)
                    rx.cond(
                        ~TaxAppState.prior_return_extraction_success,
                        rx.vstack(
                            rx.upload(
                                rx.vstack(
                                    rx.icon("upload", size=32, color=COLORS["accent_primary"]),
                                    rx.text("Drop PDF here or click to browse", 
                                           color=COLORS["text_primary"], font_weight="500"),
                                    rx.text("Form 1040 with Schedule D, 8582, etc.", 
                                           color=COLORS["text_muted"], font_size="13px"),
                                    align_items="center",
                                    spacing="2",
                                    padding="32px",
                                ),
                                id="prior_return_upload",
                                border=f"2px dashed {COLORS['border']}",
                                border_radius="12px",
                                background="white",
                                _hover={
                                    "border_color": COLORS["accent_primary"],
                                    "background": COLORS["accent_light"],
                                },
                                cursor="pointer",
                                width="100%",
                                on_drop=TaxAppState.handle_prior_return_upload(
                                    rx.upload_files(upload_id="prior_return_upload")
                                ),
                            ),
                            
                            # Processing indicator
                            rx.cond(
                                TaxAppState.prior_return_processing,
                                rx.hstack(
                                    rx.spinner(size="3", color=COLORS["accent_primary"]),
                                    rx.text("Analyzing your return...", 
                                           color=COLORS["text_muted"], font_size="14px"),
                                    spacing="3",
                                    padding="16px",
                                ),
                            ),
                            
                            # Error message
                            rx.cond(
                                TaxAppState.prior_return_error != "",
                                rx.box(
                                    rx.hstack(
                                        rx.icon("circle-x", size=16, color=COLORS["error"]),
                                        rx.text(TaxAppState.prior_return_error, 
                                               color=COLORS["error"], font_size="14px"),
                                        spacing="2",
                                    ),
                                    background=COLORS["error_light"],
                                    padding="12px 16px",
                                    border_radius="8px",
                                    width="100%",
                                ),
                            ),
                            
                            width="100%",
                            spacing="3",
                        ),
                    ),
                    
                    # Results view (when extraction successful)
                    rx.cond(
                        TaxAppState.prior_return_extraction_success,
                        rx.vstack(
                            # Success header
                            rx.box(
                                rx.hstack(
                                    rx.icon("circle-check", size=20, color=COLORS["success"]),
                                    rx.text("Extraction Complete", 
                                           color=COLORS["success"], font_weight="600"),
                                    rx.text(f"({TaxAppState.prior_return_confidence_percent} confidence)", 
                                           color=COLORS["text_muted"], font_size="13px"),
                                    spacing="2",
                                ),
                                background=COLORS["success_light"],
                                padding="12px 16px",
                                border_radius="8px",
                                width="100%",
                            ),
                            
                            # Extracted data summary
                            rx.vstack(
                                rx.text("Found Carryover Data:", color=COLORS["text_primary"], 
                                       font_weight="600", font_size="15px"),
                                rx.text("Review the extracted data before applying.",
                                       color=COLORS["text_muted"], font_size="13px"),
                                align_items="start",
                                spacing="2",
                                width="100%",
                            ),
                            
                            spacing="4",
                            width="100%",
                        ),
                    ),
                    
                    # Footer buttons
                    rx.hstack(
                        rx.button(
                            "Cancel",
                            background="white",
                            color=COLORS["text_primary"],
                            border=f"1px solid {COLORS['border']}",
                            padding="10px 20px",
                            border_radius="8px",
                            cursor="pointer",
                            on_click=TaxAppState.close_prior_return_modal,
                            _hover={"background": COLORS["bg_hover"]},
                        ),
                        rx.cond(
                            TaxAppState.prior_return_extraction_success,
                            rx.button(
                                rx.icon("check", size=16),
                                "Apply to Return",
                                background=f"linear-gradient(135deg, {COLORS['accent_primary']} 0%, {COLORS['accent_purple']} 100%)",
                                color="white",
                                padding="10px 20px",
                                border_radius="8px",
                                cursor="pointer",
                                on_click=TaxAppState.apply_prior_return_data,
                                _hover={"opacity": "0.9"},
                            ),
                        ),
                        spacing="3",
                        width="100%",
                        justify="end",
                        margin_top="8px",
                    ),
                    
                    spacing="4",
                    width="100%",
                ),
                background="white",
                border_radius="16px",
                padding="24px",
                box_shadow="0 25px 50px -12px rgba(0, 0, 0, 0.25)",
                position="fixed",
                top="50%",
                left="50%",
                transform="translate(-50%, -50%)",
                z_index="201",
                width="90%",
                max_width="520px",
            ),
        ),
    )


def prior_return_section() -> rx.Component:
    """Prior return import section for Settings page."""
    from .state import TaxAppState
    
    return fintech_card(
        rx.vstack(
            rx.hstack(
                rx.box(
                    rx.icon("file-clock", size=20, color=COLORS["accent_primary"]),
                    background=COLORS["accent_light"],
                    padding="10px",
                    border_radius="8px",
                ),
                rx.text("Prior Year Return", color=COLORS["text_primary"], 
                        font_size="18px", font_weight="600"),
                spacing="3",
            ),
            rx.divider(border_color=COLORS["border"]),
            rx.text(
                "Import carryover data from your prior year return. This includes capital losses, charitable contribution carryovers, and more.",
                color=COLORS["text_muted"],
                font_size="14px",
            ),
            
            # Status indicator
            rx.cond(
                TaxAppState.prior_return_imported,
                # Imported state
                rx.vstack(
                    rx.box(
                        rx.hstack(
                            rx.icon("circle-check", size=16, color=COLORS["success"]),
                            rx.text(f"Imported from {TaxAppState.prior_return_year} return", 
                                   color=COLORS["success"], font_weight="500"),
                            spacing="2",
                        ),
                        background=COLORS["success_light"],
                        padding="12px 16px",
                        border_radius="8px",
                        width="100%",
                    ),
                    
                    # Carryover summary
                    rx.cond(
                        TaxAppState.has_carryover_data,
                        rx.vstack(
                            rx.text("Carryover Summary:", color=COLORS["text_primary"], 
                                   font_weight="600", font_size="14px"),
                            rx.cond(
                                TaxAppState.total_capital_loss_carryover > 0,
                                rx.hstack(
                                    rx.text("Capital Loss:", color=COLORS["text_muted"], font_size="13px"),
                                    rx.text(f"${TaxAppState.total_capital_loss_carryover:,.0f}", 
                                           color=COLORS["text_primary"], font_size="13px"),
                                    spacing="2",
                                ),
                            ),
                            rx.cond(
                                TaxAppState.nol_carryforward > 0,
                                rx.hstack(
                                    rx.text("NOL Carryforward:", color=COLORS["text_muted"], font_size="13px"),
                                    rx.text(f"${TaxAppState.nol_carryforward:,.0f}", 
                                           color=COLORS["text_primary"], font_size="13px"),
                                    spacing="2",
                                ),
                            ),
                            rx.cond(
                                TaxAppState.charitable_carryover > 0,
                                rx.hstack(
                                    rx.text("Charitable Carryover:", color=COLORS["text_muted"], font_size="13px"),
                                    rx.text(f"${TaxAppState.charitable_carryover:,.0f}", 
                                           color=COLORS["text_primary"], font_size="13px"),
                                    spacing="2",
                                ),
                            ),
                            align_items="start",
                            spacing="1",
                            padding="12px",
                            background=COLORS["bg_hover"],
                            border_radius="8px",
                            width="100%",
                        ),
                    ),
                    
                    # Action buttons
                    rx.hstack(
                        rx.box(
                            rx.text("Re-import", font_size="14px"),
                            background="white",
                            color=COLORS["text_primary"],
                            border=f"1px solid {COLORS['border']}",
                            padding="8px 16px",
                            border_radius="6px",
                            cursor="pointer",
                            on_click=TaxAppState.open_prior_return_modal,
                            _hover={"background": COLORS["bg_hover"]},
                        ),
                        rx.box(
                            rx.text("Clear", font_size="14px"),
                            background=COLORS["error_light"],
                            color=COLORS["error"],
                            padding="8px 16px",
                            border_radius="6px",
                            cursor="pointer",
                            on_click=TaxAppState.clear_prior_return_data,
                            _hover={"opacity": "0.8"},
                        ),
                        spacing="2",
                    ),
                    
                    width="100%",
                    spacing="3",
                    align_items="start",
                ),
                
                # Not imported state
                rx.hstack(
                    rx.vstack(
                        rx.text("No prior return imported", color=COLORS["text_muted"], font_size="14px"),
                        rx.text("Import to apply capital loss and other carryovers", 
                               color=COLORS["text_muted"], font_size="12px"),
                        align_items="start",
                        spacing="0",
                    ),
                    rx.spacer(),
                    rx.box(
                        rx.hstack(
                            rx.icon("upload", size=14),
                            rx.text("Import", font_size="14px"),
                            spacing="2",
                        ),
                        background=f"linear-gradient(135deg, {COLORS['accent_primary']} 0%, {COLORS['accent_purple']} 100%)",
                        color="white",
                        padding="10px 20px",
                        border_radius="8px",
                        cursor="pointer",
                        on_click=TaxAppState.open_prior_return_modal,
                        _hover={"opacity": "0.9"},
                    ),
                    width="100%",
                    align_items="center",
                ),
            ),
            
            width="100%",
            spacing="4",
        ),
        width="100%",
        margin_top="24px",
    )
