"""
TaxSnapPro - Centralized Configuration Constants

This module contains all configuration constants used throughout the application.
Centralizes tax constants, API settings, and other configuration to avoid duplication.
"""

# ===== 2024 Tax Constants =====
# Based on IRS 2024 tax year (returns filed in 2025)

TAX_CONSTANTS_2024 = {
    # Standard deduction by filing status
    "standard_deduction": {
        "single": 14600,
        "married_filing_jointly": 29200,
        "married_filing_separately": 14600,
        "head_of_household": 21900,
        "qualifying_widow": 29200,
    },
    
    # Federal income tax brackets (marginal rates)
    # Format: (upper_limit, rate) - last bracket has float('inf') as upper limit
    "brackets": {
        "single": [
            (11600, 0.10),
            (47150, 0.12),
            (100525, 0.22),
            (191950, 0.24),
            (243725, 0.32),
            (609350, 0.35),
            (float("inf"), 0.37),
        ],
        "married_filing_jointly": [
            (23200, 0.10),
            (94300, 0.12),
            (201050, 0.22),
            (383900, 0.24),
            (487450, 0.32),
            (731200, 0.35),
            (float("inf"), 0.37),
        ],
        "married_filing_separately": [
            (11600, 0.10),
            (47150, 0.12),
            (100525, 0.22),
            (191950, 0.24),
            (243725, 0.32),
            (365600, 0.35),
            (float("inf"), 0.37),
        ],
        "head_of_household": [
            (16550, 0.10),
            (63100, 0.12),
            (100500, 0.22),
            (191950, 0.24),
            (243700, 0.32),
            (609350, 0.35),
            (float("inf"), 0.37),
        ],
        "qualifying_widow": [
            (23200, 0.10),
            (94300, 0.12),
            (201050, 0.22),
            (383900, 0.24),
            (487450, 0.32),
            (731200, 0.35),
            (float("inf"), 0.37),
        ],
    },
    
    # Long-term capital gains tax brackets (0%, 15%, 20%)
    "capital_gains_brackets": {
        "single": [
            (47025, 0.0),
            (518900, 0.15),
            (float("inf"), 0.20),
        ],
        "married_filing_jointly": [
            (94050, 0.0),
            (583750, 0.15),
            (float("inf"), 0.20),
        ],
        "married_filing_separately": [
            (47025, 0.0),
            (291850, 0.15),
            (float("inf"), 0.20),
        ],
        "head_of_household": [
            (63000, 0.0),
            (551350, 0.15),
            (float("inf"), 0.20),
        ],
        "qualifying_widow": [
            (94050, 0.0),
            (583750, 0.15),
            (float("inf"), 0.20),
        ],
    },
    
    # Social Security wage base for FICA tax
    "social_security_wage_base": 168600,
    
    # Additional Medicare Tax (0.9%) threshold
    "medicare_additional_threshold": {
        "married_filing_jointly": 250000,
        "qualifying_widow": 250000,
        "single": 200000,
        "head_of_household": 200000,
        "married_filing_separately": 125000,
    },
    
    # Net Investment Income Tax (NIIT) 3.8% threshold
    "niit_threshold": {
        "married_filing_jointly": 250000,
        "qualifying_widow": 250000,
        "single": 200000,
        "head_of_household": 200000,
        "married_filing_separately": 125000,
    },
    
    # ===== Alternative Minimum Tax (AMT) Constants =====
    # Form 6251 - flat structure (not nested)
    
    # AMT exemption amounts
    "amt_exemption": {
        "married_filing_jointly": 133300,
        "qualifying_widow": 133300,
        "single": 85700,
        "head_of_household": 85700,
        "married_filing_separately": 66650,
    },
    
    # AMT exemption phase-out start thresholds
    # Exemption reduces by 25% of AMTI above this threshold
    "amt_phaseout_start": {
        "married_filing_jointly": 1218700,
        "qualifying_widow": 1218700,
        "single": 609350,
        "head_of_household": 609350,
        "married_filing_separately": 609350,
    },
    
    # AMT rate thresholds (26% up to limit, 28% above)
    "amt_26_percent_limit": {
        "married_filing_jointly": 220700,
        "qualifying_widow": 220700,
        "single": 110350,
        "head_of_household": 110350,
        "married_filing_separately": 110350,
    },
}

# ===== Tax Credits and Limits =====

# Child Tax Credit per qualifying child (under 17)
CHILD_TAX_CREDIT = 2000

# Credit for Other Dependents (not qualifying for CTC)
DEPENDENT_CREDIT = 500

# Capital loss deduction limit (Schedule D)
CAPITAL_LOSS_LIMIT = 3000

# State and Local Tax (SALT) deduction cap
SALT_CAP = 10000

# ===== Passive Activity Loss Allowance =====
# For rental real estate activities (special $25k allowance)

# Base passive loss allowance
PASSIVE_LOSS_ALLOWANCE = {
    "base": 25000,
    "married_filing_separately": 12500,
}

# Passive loss allowance phase-out thresholds
PASSIVE_LOSS_PHASEOUT = {
    "start": 100000,
    "end": 150000,
    "start_mfs": 50000,  # Married Filing Separately
    "end_mfs": 75000,    # Married Filing Separately
    "reduction_rate": 0.50,  # $0.50 reduction per $1 over start threshold
}

# ===== API Settings =====
# Configuration for document extraction and AI services

# Delay between API requests to avoid rate limiting (seconds)
REQUEST_DELAY_SECONDS = 5.0

# Maximum number of retry attempts for failed API calls
MAX_RETRIES = 5

# Initial retry delay (will use exponential backoff: delay * 2^attempt)
RETRY_DELAY_SECONDS = 10
