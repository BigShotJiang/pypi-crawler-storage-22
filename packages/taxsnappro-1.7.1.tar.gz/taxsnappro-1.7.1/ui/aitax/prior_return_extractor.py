"""
TaxSnapPro - Prior Return Extractor

Extracts carryover data from prior year tax returns (1040, Schedule D, Form 8582, etc.)
Supports: Gemini (free), OpenAI (GPT-4o), Claude (Sonnet)
"""
import os
import base64
import json
import asyncio
import httpx
from pathlib import Path
from typing import Optional, Dict, Any, Literal

from .config import REQUEST_DELAY_SECONDS, MAX_RETRIES, RETRY_DELAY_SECONDS

ModelProvider = Literal["gemini", "openai", "claude"]


PRIOR_RETURN_EXTRACTION_PROMPT = """You are a tax return analyzer. Extract carryover data from this prior year tax return.

IMPORTANT: This is a PRIOR YEAR return. We need data that carries forward to the NEXT year.

Look for and extract the following from Form 1040 and related schedules:

FROM FORM 1040:
- tax_year: The year this return is for (e.g., 2023)
- adjusted_gross_income: Line 11 - AGI (needed for e-file verification)
- filing_status: single, married_filing_jointly, etc.

FROM SCHEDULE D (Capital Gains and Losses):
Look at Part III - Summary, specifically:
- Line 16: If there's a LOSS, this is your capital loss for the year
- Line 21: Capital loss carryover to NEXT YEAR (if line 16 is a loss and exceeds $3,000)

Extract:
- capital_loss_carryover_short: Short-term capital loss carryover (if shown separately)
- capital_loss_carryover_long: Long-term capital loss carryover (if shown separately)
- total_capital_loss_carryover: Combined carryover if not separated

Note: The $3,000 limit ($1,500 MFS) is already deducted. Carryover = excess beyond that.

FROM SCHEDULE A (Itemized Deductions):
- charitable_contributions: Total charitable contributions claimed
- charitable_carryover: Excess contributions (over 60% AGI limit) carried forward

FROM FORM 8582 (Passive Activity Loss Limitations):
- passive_loss_carryover: Total suspended passive losses
- passive_loss_by_property: List of properties with suspended losses

FROM FORM 8801 (Credit for Prior Year Minimum Tax):
- amt_credit_carryforward: AMT credit available to carry forward

FROM NOL CARRYFORWARD (if applicable):
- nol_carryforward: Net Operating Loss carried forward

Respond ONLY with valid JSON:
{
  "success": true,
  "tax_year": 2023,
  "adjusted_gross_income": 75000.00,
  "filing_status": "single",
  "carryovers": {
    "capital_loss_short": 0.0,
    "capital_loss_long": 5000.0,
    "charitable": 0.0,
    "passive_loss": 0.0,
    "passive_loss_by_property": [],
    "amt_credit": 0.0,
    "nol": 0.0
  },
  "confidence": 0.85,
  "notes": "Any important notes about what was found or missing"
}

If this is NOT a tax return or carryover data cannot be extracted:
{
  "success": false,
  "error": "Description of the issue",
  "confidence": 0.0
}

Important:
- All monetary values as numbers (no $ or commas)
- Set confidence lower if pages are blurry or key schedules are missing
- If specific carryover types aren't found, use 0.0
- Note which schedules were found/missing in the notes field
"""


async def extract_prior_return(
    file_path: str,
    api_key: Optional[str] = None,
    provider: ModelProvider = "gemini",
) -> Dict[str, Any]:
    """
    Extract carryover data from a prior year tax return PDF.
    
    Args:
        file_path: Path to the prior year return PDF
        api_key: API key for the selected provider
        provider: "gemini" (free), "openai", or "claude"
        
    Returns:
        Dict with carryover data or error information
    """
    # Get API key from env if not provided
    if not api_key:
        if provider == "gemini":
            api_key = os.environ.get("GOOGLE_API_KEY") or os.environ.get("GEMINI_API_KEY")
        elif provider == "openai":
            api_key = os.environ.get("OPENAI_API_KEY")
        elif provider == "claude":
            api_key = os.environ.get("ANTHROPIC_API_KEY")
    
    if not api_key:
        provider_help = {
            "gemini": "Get a free key from aistudio.google.com/apikey",
            "openai": "Get a key from platform.openai.com/api-keys",
            "claude": "Get a key from console.anthropic.com/settings/keys",
        }
        return {
            "success": False,
            "error": f"No API key configured. {provider_help.get(provider, '')}",
            "confidence": 0.0
        }
    
    path = Path(file_path)
    if not path.exists():
        return {
            "success": False,
            "error": f"File not found: {file_path}",
            "confidence": 0.0
        }
    
    # Read and encode the PDF
    file_bytes = path.read_bytes()
    base64_data = base64.standard_b64encode(file_bytes).decode("utf-8")
    
    # Determine MIME type
    suffix = path.suffix.lower()
    mime_type = {
        ".pdf": "application/pdf",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
    }.get(suffix, "application/pdf")
    
    # Retry logic with exponential backoff
    for attempt in range(MAX_RETRIES):
        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                # Call appropriate API based on provider
                if provider == "gemini":
                    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={api_key}"
                    response = await client.post(url, json={
                        "contents": [{"parts": [
                            {"inline_data": {"mime_type": mime_type, "data": base64_data}},
                            {"text": PRIOR_RETURN_EXTRACTION_PROMPT}
                        ]}],
                        "generationConfig": {"temperature": 0.1, "maxOutputTokens": 2048}
                    })
                    if response.status_code == 429:
                        wait_time = RETRY_DELAY_SECONDS * (2 ** attempt)
                        await asyncio.sleep(wait_time)
                        continue
                    if response.status_code != 200:
                        return {"success": False, "error": f"Gemini API error: {response.status_code} - {response.text[:200]}", "confidence": 0.0}
                    result = response.json()
                    try:
                        text_response = result["candidates"][0]["content"]["parts"][0]["text"]
                    except (KeyError, IndexError):
                        return {"success": False, "error": "Unexpected Gemini response format", "confidence": 0.0}
                
                elif provider == "openai":
                    response = await client.post(
                        "https://api.openai.com/v1/chat/completions",
                        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                        json={
                            "model": "gpt-4o",
                            "messages": [{"role": "user", "content": [
                                {"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{base64_data}"}},
                                {"type": "text", "text": PRIOR_RETURN_EXTRACTION_PROMPT}
                            ]}],
                            "max_tokens": 2048,
                            "temperature": 0.1
                        },
                    )
                    if response.status_code == 429:
                        wait_time = RETRY_DELAY_SECONDS * (2 ** attempt)
                        await asyncio.sleep(wait_time)
                        continue
                    if response.status_code != 200:
                        return {"success": False, "error": f"OpenAI API error: {response.status_code} - {response.text[:200]}", "confidence": 0.0}
                    result = response.json()
                    text_response = result.get("choices", [{}])[0].get("message", {}).get("content", "{}")
                
                elif provider == "claude":
                    response = await client.post(
                        "https://api.anthropic.com/v1/messages",
                        headers={"x-api-key": api_key, "anthropic-version": "2023-06-01", "Content-Type": "application/json"},
                        json={
                            "model": "claude-sonnet-4-20250514",
                            "max_tokens": 2048,
                            "messages": [{"role": "user", "content": [
                                {"type": "image", "source": {"type": "base64", "media_type": mime_type, "data": base64_data}},
                                {"type": "text", "text": PRIOR_RETURN_EXTRACTION_PROMPT}
                            ]}]
                        },
                    )
                    if response.status_code == 429:
                        wait_time = RETRY_DELAY_SECONDS * (2 ** attempt)
                        await asyncio.sleep(wait_time)
                        continue
                    if response.status_code != 200:
                        return {"success": False, "error": f"Claude API error: {response.status_code} - {response.text[:200]}", "confidence": 0.0}
                    result = response.json()
                    content_blocks = result.get("content", [])
                    text_response = content_blocks[0].get("text", "{}") if content_blocks else "{}"
                
                else:
                    return {"success": False, "error": f"Unknown provider: {provider}", "confidence": 0.0}
                
                # Parse JSON from response
                # Handle markdown code blocks
                text_response = text_response.strip()
                if text_response.startswith("```"):
                    lines = text_response.split("\n")
                    # Remove first and last lines (```json and ```)
                    text_response = "\n".join(lines[1:-1])
                
                try:
                    parsed = json.loads(text_response)
                    return parsed
                except json.JSONDecodeError as e:
                    return {
                        "success": False,
                        "error": f"Failed to parse response: {str(e)}",
                        "raw_response": text_response[:500],
                        "confidence": 0.0
                    }
                    
        except httpx.TimeoutException:
            if attempt < MAX_RETRIES - 1:
                await asyncio.sleep(RETRY_DELAY_SECONDS)
                continue
            return {
                "success": False,
                "error": "Request timed out. The PDF may be too large.",
                "confidence": 0.0
            }
        except Exception as e:
            return {
                "success": False,
                "error": f"Unexpected error: {str(e)}",
                "confidence": 0.0
            }
    
    return {
        "success": False,
        "error": "Max retries exceeded. Please try again later.",
        "confidence": 0.0
    }


def apply_carryover_to_state(extraction_result: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert extraction result to state-compatible format.
    
    Returns dict that can be used to update TaxAppState fields.
    """
    if not extraction_result.get("success"):
        return {"error": extraction_result.get("error", "Extraction failed")}
    
    carryovers = extraction_result.get("carryovers", {})
    
    return {
        "prior_return_imported": True,
        "prior_return_year": extraction_result.get("tax_year", 0),
        "prior_year_agi": extraction_result.get("adjusted_gross_income", 0.0),
        "capital_loss_carryover_short": carryovers.get("capital_loss_short", 0.0),
        "capital_loss_carryover_long": carryovers.get("capital_loss_long", 0.0),
        "nol_carryforward": carryovers.get("nol", 0.0),
        "charitable_carryover": carryovers.get("charitable", 0.0),
        "amt_credit_carryforward": carryovers.get("amt_credit", 0.0),
        # Passive losses need special handling (list of dicts)
        "passive_loss_total": carryovers.get("passive_loss", 0.0),
        "passive_loss_by_property": carryovers.get("passive_loss_by_property", []),
        "confidence": extraction_result.get("confidence", 0.0),
        "notes": extraction_result.get("notes", ""),
    }
