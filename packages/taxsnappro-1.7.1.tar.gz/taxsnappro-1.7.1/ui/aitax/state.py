"""
TaxSnapPro - Application State
"""
import reflex as rx
import os
from pathlib import Path
from typing import List, Dict
from enum import Enum

from .document_extractor import (
    extract_with_retry, 
    convert_to_w2, 
    convert_to_1099, 
    convert_to_business_income,
    convert_1099_misc_to_other_income,
)
from .prior_return_extractor import extract_prior_return, apply_carryover_to_state
from .persistence import save_state, load_state, clear_saved_data
from .irs_form_filler import fill_form_1040, get_tax_data_for_1040
from .config import (
    TAX_CONSTANTS_2024, 
    REQUEST_DELAY_SECONDS,
    CHILD_TAX_CREDIT,
    DEPENDENT_CREDIT,
    CAPITAL_LOSS_LIMIT,
    SALT_CAP,
)
from .tax_calculator import calculate_passive_loss_allowance
import asyncio
import base64


class FilingStatus(str, Enum):
    """Filing status enum."""
    SINGLE = "single"
    MARRIED_FILING_JOINTLY = "married_filing_jointly"
    MARRIED_FILING_SEPARATELY = "married_filing_separately"
    HEAD_OF_HOUSEHOLD = "head_of_household"
    QUALIFYING_WIDOW = "qualifying_widow"


class TaxAppState(rx.State):
    """Main application state."""
    
    # ===== UI State =====
    processing: bool = False
    processing_file_index: int = 0
    processing_total_files: int = 0
    processing_current_file: str = ""
    error_message: str = ""
    success_message: str = ""
    show_api_modal: bool = False  # API key configuration modal
    show_privacy_modal: bool = False  # Privacy confirmation modal
    temp_api_key: str = ""  # Temporary input for modal
    
    # Multi-model support
    model_provider: str = "gemini"  # "gemini", "openai", "claude"
    gemini_api_key: str = ""
    claude_api_key: str = ""
    
    # ===== User Settings =====
    tax_year: int = 2024
    filing_status: str = "single"
    openai_api_key: str = ""  # Actually Gemini API key
    anthropic_api_key: str = ""  # Alias
    settings_api_key_input: str = ""  # Temp input for settings page
    settings_dirty: bool = False  # Track unsaved changes
    
    # Personal info editing state
    personal_info_dirty: bool = False
    temp_first_name: str = ""
    temp_last_name: str = ""
    temp_ssn: str = ""
    temp_spouse_first_name: str = ""
    temp_spouse_last_name: str = ""
    temp_spouse_ssn: str = ""
    temp_address_street: str = ""
    temp_address_apt: str = ""
    temp_address_city: str = ""
    temp_address_state: str = ""
    temp_address_zip: str = ""
    
    # Cache management state
    show_cache_modal: bool = False
    cache_clear_type: str = ""  # "llm", "personal", "calculations", "all"
    cache_modal_title: str = ""
    cache_modal_message: str = ""
    
    # Breakdown modals (Dashboard)
    show_deductions_modal: bool = False
    show_tax_estimate_modal: bool = False
    
    # Expandable sections (Review page)
    expanded_agi: bool = False
    expanded_deductions: bool = False
    expanded_tax: bool = False
    expanded_withholding: bool = False
    
    # Prior Return Import state
    show_prior_return_modal: bool = False
    prior_return_processing: bool = False
    prior_return_error: str = ""
    prior_return_result: Dict = {}  # Extraction result for review
    prior_return_file_path: str = ""  # Temp file path for uploaded prior return
    
    # ===== Form Inputs for Manual Entry =====
    # Rental property form
    rental_form_address: str = ""
    rental_form_income: str = ""
    rental_form_mortgage: str = ""
    rental_form_tax: str = ""
    rental_form_insurance: str = ""
    rental_form_repairs: str = ""
    rental_form_depreciation: str = ""
    rental_form_other: str = ""
    # Auto-depreciation fields
    rental_form_cost_basis: str = ""  # Purchase price + improvements (building only, not land)
    rental_form_placed_month: str = ""  # Month placed in service (1-12)
    rental_form_placed_year: str = ""  # Year placed in service
    rental_form_auto_depreciation: bool = True  # Use auto-calc vs manual
    
    # Business form
    business_form_name: str = ""
    business_form_income: str = ""
    business_form_expenses: str = ""
    
    # Other income/deduction forms
    other_income_form_desc: str = ""
    other_income_form_amount: str = ""
    other_deduction_form_desc: str = ""
    other_deduction_form_amount: str = ""
    
    # Dependent form
    dependent_form_name: str = ""
    dependent_form_relationship: str = ""
    
    # ISO (Incentive Stock Option) form - Form 3921
    iso_form_company: str = ""
    iso_form_exercise_date: str = ""  # YYYY-MM-DD
    iso_form_shares: str = ""
    iso_form_exercise_price: str = ""  # Per share
    iso_form_fmv: str = ""  # FMV per share at exercise
    
    # RSU (Restricted Stock Unit) vest form
    rsu_form_company: str = ""
    rsu_form_vest_date: str = ""  # YYYY-MM-DD
    rsu_form_shares: str = ""
    rsu_form_fmv: str = ""  # FMV per share at vest
    
    # ESPP (Employee Stock Purchase Plan) form - Form 3922
    espp_form_company: str = ""
    espp_form_grant_date: str = ""  # YYYY-MM-DD
    espp_form_purchase_date: str = ""  # YYYY-MM-DD
    espp_form_shares: str = ""
    espp_form_exercise_price: str = ""  # What you paid per share
    espp_form_fmv_grant: str = ""  # FMV per share at grant
    espp_form_fmv_purchase: str = ""  # FMV per share at purchase
    dependent_form_age: str = ""
    child_care_form_amount: str = ""
    
    # Form visibility
    show_rental_form: bool = False
    show_business_form: bool = False
    show_other_income_form: bool = False
    show_other_deduction_form: bool = False
    show_dependent_form: bool = False
    show_iso_form: bool = False
    show_rsu_form: bool = False
    show_espp_form: bool = False
    
    # ===== Document State =====
    uploaded_files: List[str] = []
    parsed_documents: List[Dict] = []  # {name, type, status: pending|processing|parsed|error}
    selected_files: List[str] = []  # Files selected for processing
    
    # ===== Personal Info =====
    first_name: str = ""
    last_name: str = ""
    ssn: str = ""  # Social Security Number
    
    # Spouse info (if married filing jointly)
    spouse_first_name: str = ""
    spouse_last_name: str = ""
    spouse_ssn: str = ""
    
    # Address
    address_street: str = ""
    address_apt: str = ""
    address_city: str = ""
    address_state: str = ""
    address_zip: str = ""
    
    # ===== Tax Data =====
    w2_list: List[Dict] = []
    form_1099_list: List[Dict] = []
    form_1098_list: List[Dict] = []  # Mortgage interest (deduction)
    form_5498_list: List[Dict] = []  # HSA contributions (deduction)
    
    # ===== Prior Return / Carryover Data =====
    prior_return_imported: bool = False
    prior_return_year: int = 0
    prior_year_agi: float = 0.0  # Needed for e-file PIN verification
    
    # Capital Loss Carryover (Schedule D)
    capital_loss_carryover_short: float = 0.0  # Short-term losses carried forward
    capital_loss_carryover_long: float = 0.0   # Long-term losses carried forward
    
    # NOL Carryforward
    nol_carryforward: float = 0.0
    
    # Passive Activity Loss Carryover (Form 8582)
    passive_loss_carryover: List[Dict] = []  # {property_address, suspended_loss}
    
    # Charitable Contribution Carryover (excess over 60% AGI limit)
    charitable_carryover: float = 0.0
    
    # AMT Credit Carryforward (Form 8801)
    amt_credit_carryforward: float = 0.0
    
    # ===== Real Estate Professional Status =====
    # If True, rental losses are not subject to passive activity limits
    is_real_estate_professional: bool = False
    
    # ===== Manual Entry Data =====
    # Schedule E - Rental Property (multiple properties)
    # Each property should have 'active_participation': True/False for $25k allowance
    rental_properties: List[Dict] = []  # {address, rent_income, expenses: {...}, active_participation: bool}
    
    # Schedule C - Business Income (simplified)
    business_income: List[Dict] = []  # {name, gross_income, expenses, net_profit}
    
    # Other manual entries
    other_income: List[Dict] = []  # {description, amount, tax_type}
    other_deductions: List[Dict] = []  # {description, amount, deduction_type}
    
    # ===== ISO (Incentive Stock Options) - Form 3921 =====
    # Each ISO exercise: {company, exercise_date, shares, exercise_price, fmv_at_exercise, sold: bool, sale_price, sale_date}
    iso_exercises: List[Dict] = []
    
    # ===== RSU (Restricted Stock Units) Vests =====
    # Each RSU vest: {company, vest_date, shares, fmv_per_share, total_fmv, shares_remaining, used_for_basis: []}
    rsu_vests: List[Dict] = []
    
    # ===== ESPP (Employee Stock Purchase Plan) - Form 3922 =====
    # Each ESPP purchase: {company, grant_date, purchase_date, shares, exercise_price, fmv_grant, fmv_purchase, sold: bool, sale_date, sale_price}
    espp_purchases: List[Dict] = []
    
    # ===== 529 Plan Distributions - Form 1099-Q =====
    # Only need to track if there are non-qualified distributions (taxable)
    # {plan_name, gross_distribution, earnings, basis, is_qualified}
    distributions_529: List[Dict] = []
    
    # ===== 1099-R Retirement Distributions =====
    # {payer_name, gross_distribution, taxable_amount, federal_withheld, distribution_code, is_early}
    form_1099r_list: List[Dict] = []
    
    # Dependents
    dependents: List[Dict] = []  # {name, relationship, age, ssn_last4, is_child}
    
    # Child and Dependent Care
    child_care_expenses: float = 0.0  # Expenses for dependent care while working
    
    # ===== Calculated Values =====
    total_wages: float = 0.0
    total_medicare_wages: float = 0.0  # From W-2 Box 5 (for Additional Medicare Tax)
    employer_hsa_contributions: float = 0.0  # From W-2 Box 12 Code W
    total_interest: float = 0.0
    total_dividends: float = 0.0  # Total ordinary dividends (Box 1a)
    qualified_dividends: float = 0.0  # Qualified dividends (Box 1b) - taxed at cap gains rates
    total_capital_gains: float = 0.0  # Total capital gains (short + long)
    short_term_capital_gains: float = 0.0  # Short-term gains (taxed as ordinary income)
    long_term_capital_gains: float = 0.0  # Long-term gains (preferential rates)
    total_rental_income: float = 0.0  # Schedule E net income (after passive limits)
    rental_income_before_passive_limit: float = 0.0  # Gross rental P&L before limits
    suspended_passive_loss: float = 0.0  # Passive losses disallowed this year (carryforward)
    total_business_income: float = 0.0  # Schedule C net profit
    total_other_income: float = 0.0
    hsa_deduction: float = 0.0  # From 5498-SA
    self_employment_tax: float = 0.0  # SE tax on business income
    mortgage_interest_deduction: float = 0.0  # From 1098
    adjusted_gross_income: float = 0.0
    
    # ===== AMT (Alternative Minimum Tax) Calculated Values =====
    iso_amt_preference: float = 0.0  # ISO spread (FMV - exercise price) for AMT
    amt_income: float = 0.0  # Alternative Minimum Taxable Income (AMTI)
    amt_exemption: float = 0.0  # AMT exemption amount (after phase-out)
    tentative_minimum_tax: float = 0.0  # AMT before comparison to regular tax
    amt_owed: float = 0.0  # Additional tax if AMT > regular tax
    itemized_deductions: float = 0.0
    standard_deduction: float = 0.0
    total_deductions: float = 0.0  # Higher of standard or itemized
    capital_gains_tax: float = 0.0  # Separate tax on capital gains
    additional_medicare_tax: float = 0.0  # 0.9% on wages > $250k (MFJ)
    niit: float = 0.0  # Net Investment Income Tax 3.8%
    qbi_deduction: float = 0.0  # Qualified Business Income Deduction (20%)
    
    # Tax Credits
    child_tax_credit: float = 0.0  # $2,000 per child under 17
    other_dependent_credit: float = 0.0  # $500 per other dependent
    child_care_credit: float = 0.0  # Credit for child/dependent care
    total_credits: float = 0.0
    total_income: float = 0.0  # Total income before AGI adjustments  
    taxable_income: float = 0.0
    total_tax: float = 0.0
    total_withholding: float = 0.0
    other_withholding: float = 0.0  # From 1099-NEC/MISC Box 4 (goes to Line 25c)
    refund_or_owed: float = 0.0
    is_refund: bool = True
    
    # Carryover to next year (calculated, for display/export)
    capital_loss_carryover_next_year: float = 0.0
    
    # ===== Return State =====
    return_status: str = "not_started"
    return_generated: bool = False
    show_return_summary: bool = False
    generated_pdf_base64: str = ""
    
    # ===== Methods =====
    
    def set_filing_status(self, status: str):
        """Update filing status."""
        self.filing_status = status
        self._recalculate()
        self._auto_save()  # Persist the updated calculations
    
    def set_tax_year(self, year: str):
        """Update tax year."""
        self.tax_year = int(year)
        self._recalculate()
        self._auto_save()
    
    def set_real_estate_professional(self, is_rep: bool):
        """Update real estate professional status."""
        self.is_real_estate_professional = is_rep
        self._recalculate()
        self._auto_save()
    
    def set_api_key(self, key: str):
        """Set API key for currently selected provider."""
        if self.model_provider == "gemini":
            self.gemini_api_key = key
            self.openai_api_key = key  # Keep for backwards compat
        elif self.model_provider == "openai":
            self.openai_api_key = key
        elif self.model_provider == "claude":
            self.claude_api_key = key
    
    def set_model_provider(self, provider: str):
        """Set the model provider for document extraction."""
        self.model_provider = provider
    
    @rx.var
    def active_api_key(self) -> str:
        """Get the API key for the currently selected provider."""
        if self.model_provider == "gemini":
            return self.gemini_api_key or self.openai_api_key
        elif self.model_provider == "openai":
            return self.openai_api_key
        elif self.model_provider == "claude":
            return self.claude_api_key
        return ""
    
    @rx.var
    def has_api_key(self) -> bool:
        """Check if the current provider has an API key configured."""
        return bool(self.active_api_key)
    
    def set_settings_api_key(self, key: str):
        """Set API key input on settings page (not saved yet)."""
        self.settings_api_key_input = key
        self.settings_dirty = True
    
    def load_settings(self):
        """Load current values into settings inputs."""
        self.settings_api_key_input = self.openai_api_key
        self.settings_dirty = False
    
    def save_settings(self):
        """Save settings from input fields."""
        self.openai_api_key = self.settings_api_key_input
        self.settings_dirty = False
        self.success_message = "Settings saved!"
    
    # ===== Personal Info Management =====
    def load_personal_info(self):
        """Load current personal info into temp editing fields."""
        self.temp_first_name = self.first_name
        self.temp_last_name = self.last_name
        self.temp_ssn = self.ssn
        self.temp_spouse_first_name = self.spouse_first_name
        self.temp_spouse_last_name = self.spouse_last_name
        self.temp_spouse_ssn = self.spouse_ssn
        self.temp_address_street = self.address_street
        self.temp_address_apt = self.address_apt
        self.temp_address_city = self.address_city
        self.temp_address_state = self.address_state
        self.temp_address_zip = self.address_zip
        self.personal_info_dirty = False
    
    def save_personal_info(self):
        """Save personal info from temp fields to permanent state."""
        self.first_name = self.temp_first_name
        self.last_name = self.temp_last_name
        self.ssn = self.temp_ssn
        self.spouse_first_name = self.temp_spouse_first_name
        self.spouse_last_name = self.temp_spouse_last_name
        self.spouse_ssn = self.temp_spouse_ssn
        self.address_street = self.temp_address_street
        self.address_apt = self.temp_address_apt
        self.address_city = self.temp_address_city
        self.address_state = self.temp_address_state
        self.address_zip = self.temp_address_zip
        self.personal_info_dirty = False
        self._recalculate()  # Recalculate with any changes
        self._auto_save()  # Persist to storage
        self.success_message = "Personal information saved!"
    
    def cancel_personal_info_changes(self):
        """Cancel personal info changes and revert to saved state."""
        self.load_personal_info()  # Reload from permanent state
        self.personal_info_dirty = False
    
    # Temp setters that mark state as dirty
    def set_temp_first_name(self, val): 
        self.temp_first_name = val
        self.personal_info_dirty = True
    def set_temp_last_name(self, val): 
        self.temp_last_name = val
        self.personal_info_dirty = True
    def set_temp_ssn(self, val): 
        self.temp_ssn = val
        self.personal_info_dirty = True
    def set_temp_spouse_first_name(self, val): 
        self.temp_spouse_first_name = val
        self.personal_info_dirty = True
    def set_temp_spouse_last_name(self, val): 
        self.temp_spouse_last_name = val
        self.personal_info_dirty = True
    def set_temp_spouse_ssn(self, val): 
        self.temp_spouse_ssn = val
        self.personal_info_dirty = True
    def set_temp_address_street(self, val): 
        self.temp_address_street = val
        self.personal_info_dirty = True
    def set_temp_address_apt(self, val): 
        self.temp_address_apt = val
        self.personal_info_dirty = True
    def set_temp_address_city(self, val): 
        self.temp_address_city = val
        self.personal_info_dirty = True
    def set_temp_address_state(self, val): 
        self.temp_address_state = val
        self.personal_info_dirty = True
    def set_temp_address_zip(self, val): 
        self.temp_address_zip = val
        self.personal_info_dirty = True
    
    # ===== Cache Management =====
    def get_cache_stats(self) -> Dict:
        """Calculate cache statistics."""
        processed_docs = len([d for d in self.parsed_documents if d["status"] == "parsed"])
        personal_fields = self.count_personal_info_fields()
        
        return {
            "documents_processed": processed_docs,
            "personal_info_complete": personal_fields > 0,
            "w2_count": len(self.w2_list),
            "form_1099_count": len(self.form_1099_list),
            "rental_properties": len(self.rental_properties),
            "business_income": len(self.business_income),
            "total_entries": processed_docs + len(self.w2_list) + len(self.form_1099_list)
        }
    
    def count_personal_info_fields(self) -> int:
        """Count filled personal info fields."""
        fields = [
            self.first_name, self.last_name, self.ssn,
            self.address_street, self.address_city, self.address_state, self.address_zip
        ]
        return len([f for f in fields if f.strip()])
    
    def show_cache_clear_modal(self, clear_type: str):
        """Show cache clear confirmation modal."""
        self.cache_clear_type = clear_type
        
        if clear_type == "llm":
            self.cache_modal_title = "Clear Document Processing Cache?"
            self.cache_modal_message = """This will delete AI-processed data from your documents.

What happens next:
• Your uploaded files remain safe
• You'll need to re-process documents with AI
• This will use your API credits again
• Your personal information stays saved"""
            
        elif clear_type == "personal":
            self.cache_modal_title = "Clear Personal Information?"
            self.cache_modal_message = """This will delete all personal information from forms.

What happens next:
• All name/address/SSN fields reset to empty
• Document processing results stay saved
• You'll need to re-enter personal details
• Tax calculations will update automatically"""
            
        elif clear_type == "calculations":
            self.cache_modal_title = "Clear Tax Calculations?"
            self.cache_modal_message = """This will recalculate all tax numbers from scratch.

What happens next:
• All tax calculations refreshed
• Document data and personal info stay saved
• Any calculation errors will be corrected
• May take a moment to recalculate"""
            
        elif clear_type == "all":
            self.cache_modal_title = "⚠️ Clear ALL Data?"
            self.cache_modal_message = """This will delete EVERYTHING and start completely fresh.

What will be deleted:
• All uploaded documents
• All AI processing results  
• All personal information
• All manual entries and calculations

This cannot be undone!"""
        
        self.show_cache_modal = True
    
    def close_cache_modal(self):
        """Close cache clear modal."""
        self.show_cache_modal = False
        self.cache_clear_type = ""
    
    def confirm_cache_clear(self):
        """Execute the cache clear after confirmation."""
        if self.cache_clear_type == "llm":
            self.clear_llm_cache()
        elif self.cache_clear_type == "personal":
            self.clear_personal_info_cache()
        elif self.cache_clear_type == "calculations":
            self.clear_tax_calculations()
        elif self.cache_clear_type == "all":
            self.clear_all_cache()
        
        self.close_cache_modal()
    
    def clear_llm_cache(self):
        """Clear LLM extraction results - documents need re-processing."""
        for doc in self.parsed_documents:
            if doc["status"] == "parsed":
                doc["status"] = "pending"
                doc.pop("extracted_data", None)
                doc["included"] = True  # Reset to included
        
        # Clear data that came from LLM processing
        self.w2_list = [w for w in self.w2_list if not w.get("source_file")]
        self.form_1099_list = [f for f in self.form_1099_list if not f.get("source_file")]
        self.form_1098_list = [f for f in self.form_1098_list if not f.get("source_file")]
        self.form_5498_list = [f for f in self.form_5498_list if not f.get("source_file")]
        
        self._recalculate()
        self._auto_save()
        self.success_message = "✅ Document processing cache cleared. Re-process documents to restore data."
    
    # ===== Breakdown Modal Methods =====
    def open_deductions_modal(self):
        """Open deductions breakdown modal."""
        self.show_deductions_modal = True
    
    def close_deductions_modal(self):
        """Close deductions breakdown modal."""
        self.show_deductions_modal = False
    
    def open_tax_estimate_modal(self):
        """Open tax estimate breakdown modal."""
        self.show_tax_estimate_modal = True
    
    def close_tax_estimate_modal(self):
        """Close tax estimate breakdown modal."""
        self.show_tax_estimate_modal = False
    
    # ===== Expandable Section Toggle Methods =====
    def toggle_agi_section(self):
        """Toggle AGI breakdown section."""
        self.expanded_agi = not self.expanded_agi
    
    def toggle_deductions_section(self):
        """Toggle deductions breakdown section."""
        self.expanded_deductions = not self.expanded_deductions
    
    def toggle_tax_section(self):
        """Toggle tax breakdown section."""
        self.expanded_tax = not self.expanded_tax
    
    def toggle_withholding_section(self):
        """Toggle withholding breakdown section."""
        self.expanded_withholding = not self.expanded_withholding
    
    def clear_personal_info_cache(self):
        """Clear personal info - forms will be empty."""
        # Clear permanent personal info
        self.first_name = ""
        self.last_name = ""
        self.ssn = ""
        self.spouse_first_name = ""
        self.spouse_last_name = ""
        self.spouse_ssn = ""
        self.address_street = ""
        self.address_apt = ""
        self.address_city = ""
        self.address_state = ""
        self.address_zip = ""
        
        # Clear temp editing fields
        self.temp_first_name = ""
        self.temp_last_name = ""
        self.temp_ssn = ""
        self.temp_spouse_first_name = ""
        self.temp_spouse_last_name = ""
        self.temp_spouse_ssn = ""
        self.temp_address_street = ""
        self.temp_address_apt = ""
        self.temp_address_city = ""
        self.temp_address_state = ""
        self.temp_address_zip = ""
        
        self.personal_info_dirty = False
        self._recalculate()
        self._auto_save()
        self.success_message = "✅ Personal information cleared. Forms reset to empty."
    
    def clear_tax_calculations(self):
        """Force recalculation of all tax numbers."""
        # Reset all calculated fields to 0
        self.total_wages = 0.0
        self.total_medicare_wages = 0.0
        self.employer_hsa_contributions = 0.0
        self.total_interest = 0.0
        self.total_dividends = 0.0
        self.qualified_dividends = 0.0
        self.total_capital_gains = 0.0
        self.short_term_capital_gains = 0.0
        self.long_term_capital_gains = 0.0
        self.total_rental_income = 0.0
        self.rental_income_before_passive_limit = 0.0
        self.suspended_passive_loss = 0.0
        self.total_business_income = 0.0
        self.total_other_income = 0.0
        self.adjusted_gross_income = 0.0
        self.total_deductions = 0.0
        self.total_income = 0.0
        self.taxable_income = 0.0
        self.total_tax = 0.0
        self.total_withholding = 0.0
        self.refund_or_owed = 0.0
        
        # Recalculate from source data
        self._recalculate()
        self._auto_save()
        self.success_message = "✅ Tax calculations refreshed from source data."
    
    def clear_all_cache(self):
        """Nuclear option - complete fresh start."""
        # Clear everything
        self.uploaded_files = []
        self.parsed_documents = []
        self.selected_files = []
        
        # Clear all extracted data
        self.w2_list = []
        self.form_1099_list = []
        self.form_1098_list = []
        self.form_5498_list = []
        
        # Clear manual entries
        self.rental_properties = []
        self.business_income = []
        self.other_income = []
        self.other_deductions = []
        self.dependents = []
        
        # Clear personal info (call the method)
        self.clear_personal_info_cache()
        
        # Clear calculated values
        self.clear_tax_calculations()
        
        # Reset state
        self.return_status = "not_started"
        self.return_generated = False
        self.success_message = "✅ All data cleared. Starting completely fresh."
    
    def set_temp_api_key(self, key: str):
        """Set temporary API key in modal."""
        self.temp_api_key = key
    
    def open_api_modal(self):
        """Open API key modal."""
        self.temp_api_key = self.openai_api_key
        self.show_api_modal = True
    
    def close_api_modal(self):
        """Close API key modal."""
        self.show_api_modal = False
        self.temp_api_key = ""
    
    def save_api_key_from_modal(self):
        """Save API key from modal and close."""
        self.openai_api_key = self.temp_api_key
        self.show_api_modal = False
        self.success_message = "API key saved!"
    
    def open_privacy_modal(self):
        """Open privacy confirmation modal."""
        self.show_privacy_modal = True
    
    def close_privacy_modal(self):
        """Close privacy confirmation modal."""
        self.show_privacy_modal = False
    
    def confirm_privacy_and_process(self):
        """User confirmed privacy agreement, proceed with AI processing."""
        self.show_privacy_modal = False
        # Proceed with actual processing
        return self.process_selected_files_confirmed()
    
    # ===== Prior Return Import =====
    def open_prior_return_modal(self):
        """Open the prior return import modal."""
        self.show_prior_return_modal = True
        self.prior_return_error = ""
        self.prior_return_result = {}
    
    def close_prior_return_modal(self):
        """Close the prior return import modal."""
        self.show_prior_return_modal = False
        self.prior_return_error = ""
        self.prior_return_result = {}
        self.prior_return_processing = False
    
    async def handle_prior_return_upload(self, files: List[rx.UploadFile]):
        """Handle prior return PDF upload."""
        self.prior_return_error = ""
        self.prior_return_result = {}
        
        if not files:
            self.prior_return_error = "No file selected"
            return
        
        if not self.openai_api_key:
            self.prior_return_error = "Please configure your API key in Settings first"
            return
        
        # Take only the first file
        file = files[0]
        if not file.filename.lower().endswith('.pdf'):
            self.prior_return_error = "Please upload a PDF file"
            return
        
        # Save to temp location
        upload_dir = Path("uploaded_files")
        upload_dir.mkdir(exist_ok=True)
        file_path = upload_dir / f"prior_return_{file.filename}"
        
        try:
            file_data = await file.read()
            file_path.write_bytes(file_data)
            self.prior_return_file_path = str(file_path)
        except Exception as e:
            self.prior_return_error = f"Upload failed: {str(e)}"
            return
        
        # Start processing
        self.prior_return_processing = True
        yield  # Update UI
        
        try:
            # Extract carryover data
            result = await extract_prior_return(
                str(file_path),
                api_key=self.active_api_key,
                provider=self.model_provider
            )
            
            if result.get("success"):
                self.prior_return_result = result
                self.prior_return_error = ""
            else:
                self.prior_return_error = result.get("error", "Failed to extract data")
                self.prior_return_result = {}
        except Exception as e:
            self.prior_return_error = f"Extraction failed: {str(e)}"
        finally:
            self.prior_return_processing = False
    
    def apply_prior_return_data(self):
        """Apply extracted prior return data to state."""
        if not self.prior_return_result.get("success"):
            self.prior_return_error = "No valid extraction to apply"
            return
        
        # Convert extraction result to state fields
        state_data = apply_carryover_to_state(self.prior_return_result)
        
        if "error" in state_data:
            self.prior_return_error = state_data["error"]
            return
        
        # Apply to state
        self.prior_return_imported = True
        self.prior_return_year = state_data.get("prior_return_year", 0)
        self.prior_year_agi = state_data.get("prior_year_agi", 0.0)
        self.capital_loss_carryover_short = state_data.get("capital_loss_carryover_short", 0.0)
        self.capital_loss_carryover_long = state_data.get("capital_loss_carryover_long", 0.0)
        self.nol_carryforward = state_data.get("nol_carryforward", 0.0)
        self.charitable_carryover = state_data.get("charitable_carryover", 0.0)
        self.amt_credit_carryforward = state_data.get("amt_credit_carryforward", 0.0)
        
        # Handle passive loss carryover (list)
        passive_list = state_data.get("passive_loss_by_property", [])
        if passive_list:
            self.passive_loss_carryover = passive_list
        elif state_data.get("passive_loss_total", 0) > 0:
            # If only total is provided, create a generic entry
            self.passive_loss_carryover = [{
                "property_address": "Prior Year Passive Loss",
                "suspended_loss": state_data.get("passive_loss_total", 0)
            }]
        
        # Recalculate with new carryover data
        self._recalculate()
        self._auto_save()
        
        # Close modal and show success
        self.show_prior_return_modal = False
        self.success_message = f"✅ Imported carryover data from {self.prior_return_year} return"
    
    def clear_prior_return_data(self):
        """Clear all imported prior return data."""
        self.prior_return_imported = False
        self.prior_return_year = 0
        self.prior_year_agi = 0.0
        self.capital_loss_carryover_short = 0.0
        self.capital_loss_carryover_long = 0.0
        self.nol_carryforward = 0.0
        self.charitable_carryover = 0.0
        self.amt_credit_carryforward = 0.0
        self.passive_loss_carryover = []
        
        self._recalculate()
        self._auto_save()
        self.success_message = "Prior return data cleared"
    
    @rx.var
    def total_capital_loss_carryover(self) -> float:
        """Total capital loss carryover (short + long)."""
        return self.capital_loss_carryover_short + self.capital_loss_carryover_long
    
    @rx.var
    def has_carryover_data(self) -> bool:
        """Check if any carryover data exists."""
        return (
            self.capital_loss_carryover_short > 0 or
            self.capital_loss_carryover_long > 0 or
            self.nol_carryforward > 0 or
            self.charitable_carryover > 0 or
            self.amt_credit_carryforward > 0 or
            len(self.passive_loss_carryover) > 0
        )
    
    @rx.var
    def prior_return_confidence_percent(self) -> str:
        """Get extraction confidence as percentage."""
        conf = self.prior_return_result.get("confidence", 0)
        return f"{conf * 100:.0f}%"
    
    @rx.var
    def prior_return_extraction_success(self) -> bool:
        """Check if prior return extraction was successful."""
        return self.prior_return_result.get("success", False) == True
    
    # ===== Personal Info Setters =====
    def set_first_name(self, name: str):
        """Set first name."""
        self.first_name = name
    
    def set_last_name(self, name: str):
        """Set last name."""
        self.last_name = name
    
    def set_ssn(self, ssn: str):
        """Set SSN."""
        self.ssn = ssn
    
    def set_spouse_first_name(self, name: str):
        """Set spouse first name."""
        self.spouse_first_name = name
    
    def set_spouse_last_name(self, name: str):
        """Set spouse last name."""
        self.spouse_last_name = name
    
    def set_spouse_ssn(self, ssn: str):
        """Set spouse SSN."""
        self.spouse_ssn = ssn
    
    def set_address_street(self, address: str):
        """Set street address."""
        self.address_street = address
    
    @rx.var
    def is_personal_info_complete(self) -> bool:
        """Check if basic personal information is complete."""
        required_fields = [
            self.first_name,
            self.last_name,
            self.ssn,
            self.address_street,
            self.address_city,
            self.address_state
        ]
        return all(field.strip() for field in required_fields)
    
    @rx.var
    def is_personal_info_incomplete(self) -> bool:
        """Check if personal information is incomplete."""
        return not self.is_personal_info_complete
    
    @rx.var
    def missing_personal_info_count(self) -> int:
        """Get count of missing personal info fields."""
        required_fields = [
            self.first_name,
            self.last_name,
            self.ssn,
            self.address_street,
            self.address_city,
            self.address_state
        ]
        return sum(1 for field in required_fields if not field.strip())
    
    def set_address_apt(self, apt: str):
        """Set apartment/unit number."""
        self.address_apt = apt
    
    def set_address_city(self, city: str):
        """Set city."""
        self.address_city = city
    
    def set_address_state(self, state: str):
        """Set state."""
        self.address_state = state
    
    def set_address_zip(self, zip_code: str):
        """Set ZIP code."""
        self.address_zip = zip_code
        self._auto_save()  # Persist API key
    
    def check_api_key_for_upload(self):
        """Check if API key is set, open modal if not."""
        if not self.openai_api_key:
            self.open_api_modal()
            return False
        return True
    
    @rx.var
    def has_api_key(self) -> bool:
        """Check if API key is configured."""
        return bool(self.openai_api_key)
    
    @rx.var
    def processing_progress(self) -> str:
        """Get processing progress message."""
        if not self.processing:
            return ""
        if self.processing_total_files == 0:
            return "Preparing..."
        return f"Processing {self.processing_file_index}/{self.processing_total_files}: {self.processing_current_file}"
    
    async def handle_file_upload(self, files: List[rx.UploadFile]):
        """Handle uploaded tax documents - just save, no AI processing."""
        self.error_message = ""
        self.success_message = ""
        
        # Ensure upload directory exists
        upload_dir = Path("uploaded_files")
        upload_dir.mkdir(exist_ok=True)
        
        new_files = 0
        try:
            for file in files:
                file_data = await file.read()
                filename = file.filename
                
                # Skip if already uploaded
                if filename in self.uploaded_files:
                    continue
                
                # Save file to disk
                file_path = upload_dir / filename
                file_path.write_bytes(file_data)
                
                self.uploaded_files.append(filename)
                
                # Initial doc type guess from filename
                doc_type = self._detect_document_type(filename)
                self.parsed_documents.append({
                    "name": filename,
                    "type": doc_type,
                    "status": "pending",  # Not processed yet
                    "included": True,  # Include in tax calculation by default
                })
                new_files += 1
            
            if new_files > 0:
                self.success_message = f"Uploaded {new_files} file(s). Go to Review to process with AI."
                self.return_status = "in_progress"
                self._auto_save()  # Persist uploaded files list
        except Exception as e:
            self.error_message = f"Upload failed: {str(e)}"
    
    def toggle_file_selection(self, filename: str):
        """Toggle file selection for AI processing."""
        # Don't allow selecting already-processed files
        for doc in self.parsed_documents:
            if doc["name"] == filename and doc["status"] == "parsed":
                return
        
        if filename in self.selected_files:
            self.selected_files.remove(filename)
        else:
            self.selected_files.append(filename)
    
    def select_all_pending(self):
        """Select all pending files for processing."""
        self.selected_files = [
            doc["name"] for doc in self.parsed_documents 
            if doc["status"] in ("pending", "error")
        ]
    
    def clear_selection(self):
        """Clear file selection."""
        self.selected_files = []
    
    def toggle_document_inclusion(self, filename: str):
        """Toggle whether a parsed document is included in tax calculation."""
        for doc in self.parsed_documents:
            if doc["name"] == filename and doc["status"] == "parsed":
                doc["included"] = not doc.get("included", True)
                self._recalculate()  # Recalculate totals based on new inclusion
                self._auto_save()
                return
    
    def get_included_files(self) -> set:
        """Get set of filenames that are included in calculation."""
        return {
            doc["name"] for doc in self.parsed_documents 
            if doc.get("status") == "parsed" and doc.get("included", True)
        }
    
    def process_selected_files(self):
        """Show privacy confirmation modal before AI processing."""
        if not self.selected_files:
            self.error_message = "No files selected for processing"
            return
        
        if not self.openai_api_key:
            self.error_message = "Please configure your API key in Settings first"
            return
        
        # Show privacy confirmation modal
        self.open_privacy_modal()
    
    async def process_selected_files_confirmed(self):
        """Process selected files with AI (after privacy confirmation)."""
        self.processing = True
        self.processing_total_files = len(self.selected_files)
        self.processing_file_index = 0
        self.error_message = ""
        self.success_message = ""
        yield  # Trigger UI update to show processing overlay
        
        upload_dir = Path("uploaded_files")
        parsed_count = 0
        error_files = []
        
        try:
            for idx, filename in enumerate(self.selected_files):
                self.processing_file_index = idx + 1
                self.processing_current_file = filename
                
                # Update status to processing
                for doc in self.parsed_documents:
                    if doc["name"] == filename:
                        doc["status"] = "processing"
                yield  # Update UI to show current file
                
                file_path = upload_dir / filename
                
                # Call AI to extract data with retry (supports Gemini/OpenAI/Claude)
                result = await extract_with_retry(
                    str(file_path),
                    api_key=self.active_api_key,
                    provider=self.model_provider,
                )
                
                # Add delay between files to avoid rate limiting
                await asyncio.sleep(REQUEST_DELAY_SECONDS)
                
                if result.get("error"):
                    error_files.append(f"{filename}: {result['error']}")
                    for doc in self.parsed_documents:
                        if doc["name"] == filename:
                            doc["status"] = "error"
                    yield  # Update UI to show error status
                    continue
                
                # Update document type from AI
                ai_doc_type = result.get("document_type", "OTHER")
                for doc in self.parsed_documents:
                    if doc["name"] == filename:
                        doc["type"] = ai_doc_type
                        doc["status"] = "parsed"
                
                # Extract and add to appropriate list
                extracted = result.get("extracted_data", {})
                
                # Remove any existing entries from this file (prevent duplicates on re-process)
                self.w2_list = [w for w in self.w2_list if w.get("source_file") != filename]
                self.form_1099_list = [f for f in self.form_1099_list if f.get("source_file") != filename]
                self.form_1098_list = [f for f in self.form_1098_list if f.get("source_file") != filename]
                self.form_5498_list = [f for f in self.form_5498_list if f.get("source_file") != filename]
                self.business_income = [b for b in self.business_income if b.get("source_file") != filename]
                self.other_income = [o for o in self.other_income if o.get("source_file") != filename]
                self.rental_properties = [r for r in self.rental_properties if r.get("source_file") != filename]
                
                if ai_doc_type == "W-2":
                    w2_data = convert_to_w2(extracted)
                    w2_data["source_file"] = filename  # Track source
                    self.w2_list.append(w2_data)
                    parsed_count += 1
                    
                elif ai_doc_type in ("1099-INT", "1099-DIV", "1099-B"):
                    form_data = convert_to_1099(extracted, ai_doc_type)
                    form_data["source_file"] = filename  # Track source
                    self.form_1099_list.append(form_data)
                    parsed_count += 1
                    
                elif ai_doc_type == "1098":
                    # Mortgage interest is a DEDUCTION, not income
                    self.form_1098_list.append({
                        "lender_name": extracted.get("lender_name", "Mortgage Lender"),
                        "mortgage_interest": float(extracted.get("mortgage_interest", 0)),
                        "points_paid": float(extracted.get("points_paid", 0)),
                        "property_taxes": float(extracted.get("property_taxes", 0)),
                        "source_file": filename,
                    })
                    parsed_count += 1
                    
                elif ai_doc_type == "5498-SA":
                    # HSA contribution is a DEDUCTION (above-the-line)
                    self.form_5498_list.append({
                        "trustee_name": extracted.get("trustee_name", "HSA Administrator"),
                        "contribution": float(extracted.get("contribution", 0)),
                        "source_file": filename,
                    })
                    parsed_count += 1
                
                elif ai_doc_type == "1099-NEC":
                    # Nonemployee compensation → Schedule C (self-employment)
                    business_data = convert_to_business_income(extracted, "1099-NEC")
                    business_data["source_file"] = filename
                    self.business_income.append(business_data)
                    
                    # Track any withholding
                    withheld = float(extracted.get("federal_withheld", 0))
                    if withheld > 0:
                        # Add to a special 1099 withholding tracker (goes to Line 25c)
                        if not hasattr(self, 'other_withholding'):
                            self.other_withholding = 0.0
                        self.other_withholding += withheld
                    parsed_count += 1
                
                elif ai_doc_type == "1099-MISC":
                    # Check if it has nonemployee comp (Box 7, pre-2020)
                    nec_amount = float(extracted.get("nonemployee_compensation", 0))
                    if nec_amount > 0:
                        # Treat like 1099-NEC
                        business_data = convert_to_business_income(extracted, "1099-MISC")
                        business_data["source_file"] = filename
                        self.business_income.append(business_data)
                    
                    # Handle other 1099-MISC income (rents, royalties, other)
                    other_entries = convert_1099_misc_to_other_income(extracted)
                    for entry in other_entries:
                        entry["source_file"] = filename
                        if entry.get("category") == "rental":
                            # Add as simple rental (user can expand)
                            self.rental_properties.append({
                                "address": entry["description"],
                                "rent_income": entry["amount"],
                                "mortgage_interest": 0,
                                "property_tax": 0,
                                "insurance": 0,
                                "repairs": 0,
                                "management": 0,
                                "utilities": 0,
                                "depreciation": 0,
                                "other_expenses": 0,
                                "total_expenses": 0,
                                "net_income": entry["amount"],
                                "source_file": filename,
                            })
                        else:
                            # Other income
                            self.other_income.append({
                                "description": entry["description"],
                                "amount": entry["amount"],
                                "source_file": filename,
                            })
                    
                    if nec_amount > 0 or other_entries:
                        parsed_count += 1
                
                elif ai_doc_type == "RSU-SUPPLEMENT":
                    # RSU Stock Plan Supplemental Information
                    # Remove existing RSU vests from this file
                    self.rsu_vests = [v for v in self.rsu_vests if v.get("source_file") != filename]
                    
                    company = extracted.get("company", "Unknown Company")
                    vests = extracted.get("vests", [])
                    
                    for vest in vests:
                        try:
                            self.rsu_vests.append({
                                "company": company,
                                "vest_date": vest.get("vest_date", ""),
                                "shares": float(vest.get("shares", 0)),
                                "fmv_per_share": float(vest.get("fmv_per_share", 0)),
                                "total_fmv": float(vest.get("total_fmv", 0)) or (float(vest.get("shares", 0)) * float(vest.get("fmv_per_share", 0))),
                                "shares_remaining": float(vest.get("net_shares", 0)) or float(vest.get("shares", 0)),
                                "source_file": filename,
                            })
                        except (ValueError, TypeError):
                            continue
                    
                    if vests:
                        parsed_count += 1
                
                elif ai_doc_type == "FORM-3921":
                    # ISO Exercise - goes to iso_exercises
                    # Remove existing ISO from this file
                    self.iso_exercises = [i for i in self.iso_exercises if i.get("source_file") != filename]
                    
                    try:
                        shares = float(extracted.get("shares", 0))
                        exercise_price = float(extracted.get("exercise_price", 0))
                        fmv = float(extracted.get("fmv_exercise_date", 0))
                        
                        if shares > 0:
                            self.iso_exercises.append({
                                "company": extracted.get("company", "Unknown"),
                                "exercise_date": extracted.get("exercise_date", ""),
                                "shares": shares,
                                "exercise_price": exercise_price,
                                "fmv_at_exercise": fmv,
                                "spread": (fmv - exercise_price) * shares,
                                "sold": False,
                                "source_file": filename,
                            })
                            parsed_count += 1
                    except (ValueError, TypeError):
                        pass
                
                elif ai_doc_type == "FORM-3922":
                    # ESPP Purchase - goes to espp_purchases
                    # Remove existing ESPP from this file
                    self.espp_purchases = [e for e in self.espp_purchases if e.get("source_file") != filename]
                    
                    try:
                        shares = float(extracted.get("shares", 0))
                        exercise_price = float(extracted.get("exercise_price", 0))
                        fmv_grant = float(extracted.get("fmv_grant_date", 0))
                        fmv_purchase = float(extracted.get("fmv_purchase_date", 0))
                        
                        if shares > 0:
                            discount_per_share = fmv_purchase - exercise_price
                            self.espp_purchases.append({
                                "company": extracted.get("company", "Unknown"),
                                "grant_date": extracted.get("grant_date", ""),
                                "purchase_date": extracted.get("purchase_date", ""),
                                "shares": shares,
                                "exercise_price": exercise_price,
                                "fmv_grant": fmv_grant,
                                "fmv_purchase": fmv_purchase,
                                "discount_per_share": discount_per_share,
                                "total_discount": discount_per_share * shares,
                                "cost_basis": exercise_price * shares,
                                "sold": False,
                                "source_file": filename,
                            })
                            parsed_count += 1
                    except (ValueError, TypeError):
                        pass
                
                elif ai_doc_type == "1099-Q":
                    # 529 Plan Distribution
                    # Remove existing 529 from this file
                    self.distributions_529 = [d for d in self.distributions_529 if d.get("source_file") != filename]
                    
                    try:
                        gross = float(extracted.get("gross_distribution", 0))
                        earnings = float(extracted.get("earnings", 0))
                        basis = float(extracted.get("basis", 0))
                        
                        if gross > 0:
                            # Default to qualified (user can change)
                            self.distributions_529.append({
                                "plan_name": extracted.get("payer_name", "529 Plan"),
                                "gross_distribution": gross,
                                "earnings": earnings,
                                "basis": basis,
                                "is_qualified": True,  # Assume qualified, user marks if not
                                "source_file": filename,
                            })
                            parsed_count += 1
                    except (ValueError, TypeError):
                        pass
                
                elif ai_doc_type == "1099-R":
                    # Retirement Distribution (IRA, 401k, Pension)
                    # Remove existing 1099-R from this file
                    self.form_1099r_list = [r for r in self.form_1099r_list if r.get("source_file") != filename]
                    
                    try:
                        gross = float(extracted.get("gross_distribution", 0))
                        taxable = float(extracted.get("taxable_amount", 0) or gross)  # Default to gross if not specified
                        withheld = float(extracted.get("federal_withheld", 0))
                        code = str(extracted.get("distribution_code", "7"))  # Default to normal
                        
                        # Early distribution codes: 1 = early with penalty, 2 = early exception, J = early Roth
                        early_penalty_codes = ["1", "J"]
                        is_early = code in early_penalty_codes
                        
                        # Rollover codes (not taxable): G, H
                        rollover_codes = ["G", "H"]
                        is_rollover = code in rollover_codes
                        
                        if gross > 0:
                            self.form_1099r_list.append({
                                "payer_name": extracted.get("payer_name", "Retirement Plan"),
                                "gross_distribution": gross,
                                "taxable_amount": 0 if is_rollover else taxable,
                                "federal_withheld": withheld,
                                "distribution_code": code,
                                "is_early": is_early,
                                "is_rollover": is_rollover,
                                "source_file": filename,
                            })
                            parsed_count += 1
                    except (ValueError, TypeError):
                        pass
            
            # Recalculate totals
            self._recalculate()
            
            # Save parsed data to disk
            self._auto_save()
            
            self.return_status = "in_progress"
            
            if parsed_count > 0:
                self.success_message = f"Successfully parsed {parsed_count} document(s)"
            if error_files:
                self.error_message = "Errors: " + "; ".join(error_files)
            
            # Clear selection after processing
            self.selected_files = []
            
        except Exception as e:
            self.error_message = f"Upload failed: {str(e)}"
        finally:
            self.processing = False
    
    def _detect_document_type(self, filename: str) -> str:
        """Detect document type from filename."""
        lower = filename.lower()
        if "w2" in lower or "w-2" in lower:
            return "W-2"
        elif "1099-nec" in lower or "1099nec" in lower:
            return "1099-NEC"
        elif "1099-misc" in lower or "1099misc" in lower:
            return "1099-MISC"
        elif "1099-int" in lower or "1099int" in lower:
            return "1099-INT"
        elif "1099-div" in lower or "1099div" in lower:
            return "1099-DIV"
        elif "1099-b" in lower or "1099b" in lower:
            return "1099-B"
        elif "1099" in lower:
            return "1099"
        elif "1098" in lower:
            return "1098"
        elif "5498" in lower:
            return "5498-SA"
        return "Unknown"
    
    def add_w2(self, employer: str, wages: float, withheld: float):
        """Add a W-2 entry."""
        self.w2_list.append({
            "employer_name": employer,
            "wages": wages,
            "federal_withheld": withheld,
        })
        self._recalculate()
    
    def add_1099(self, payer: str, amount: float, form_type: str = "1099-INT"):
        """Add a 1099 entry."""
        self.form_1099_list.append({
            "payer_name": payer,
            "amount": amount,
            "form_type": form_type,
        })
        self._recalculate()
    
    def remove_w2(self, index: int):
        """Remove a W-2 entry."""
        if 0 <= index < len(self.w2_list):
            self.w2_list.pop(index)
            self._recalculate()
    
    def remove_1099(self, index: int):
        """Remove a 1099 entry."""
        if 0 <= index < len(self.form_1099_list):
            self.form_1099_list.pop(index)
            self._recalculate()
    
    # ===== Schedule E - Rental Property Methods =====
    def add_rental_property(self, address: str, rent_income: float, 
                           mortgage_interest: float = 0, property_tax: float = 0,
                           insurance: float = 0, repairs: float = 0, 
                           management: float = 0, utilities: float = 0,
                           depreciation: float = 0, other_expenses: float = 0,
                           monthly_rent: float = 0, quarterly_tax: float = 0,
                           cost_basis: float = 0, placed_month: int = 0, 
                           placed_year: int = 0, auto_depreciation: bool = False):
        """Add a rental property (Schedule E). All values should be annual."""
        total_expenses = (mortgage_interest + property_tax + insurance + 
                         repairs + management + utilities + depreciation + other_expenses)
        self.rental_properties.append({
            "address": address,
            "monthly_rent": monthly_rent,    # For display
            "quarterly_tax": quarterly_tax,  # For display
            "rent_income": rent_income,      # Annual (monthly × 12)
            "mortgage_interest": mortgage_interest,
            "property_tax": property_tax,    # Annual (quarterly × 4)
            "insurance": insurance,
            "repairs": repairs,
            "management": management,
            "utilities": utilities,
            "depreciation": depreciation,
            "other_expenses": other_expenses,
            "total_expenses": total_expenses,
            "net_income": rent_income - total_expenses,
            # Depreciation tracking
            "cost_basis": cost_basis,
            "placed_month": placed_month,
            "placed_year": placed_year,
            "auto_depreciation": auto_depreciation,
        })
        self._recalculate()
    
    def remove_rental_property(self, index: int):
        """Remove a rental property by index."""
        if 0 <= index < len(self.rental_properties):
            self.rental_properties.pop(index)
            self._recalculate()
            self._auto_save()
    
    def remove_rental_property_by_address(self, address: str):
        """Remove a rental property by address."""
        self.rental_properties = [p for p in self.rental_properties if p.get("address") != address]
        self._recalculate()
        self._auto_save()
    
    # ===== Schedule C - Business Income Methods =====
    def add_business(self, name: str, gross_income: float, expenses: float):
        """Add a business (Schedule C simplified)."""
        net_profit = gross_income - expenses
        self.business_income.append({
            "name": name,
            "gross_income": gross_income,
            "expenses": expenses,
            "net_profit": net_profit,
        })
        self._recalculate()
    
    def remove_business(self, index: int):
        """Remove a business."""
        if 0 <= index < len(self.business_income):
            self.business_income.pop(index)
            self._recalculate()
    
    # ===== Other Manual Entry Methods =====
    def add_other_income(self, description: str, amount: float):
        """Add other income."""
        self.other_income.append({
            "description": description,
            "amount": amount,
        })
        self._recalculate()
    
    def remove_other_income(self, index: int):
        """Remove other income."""
        if 0 <= index < len(self.other_income):
            self.other_income.pop(index)
            self._recalculate()
    
    def add_other_deduction(self, description: str, amount: float):
        """Add other deduction (above-the-line)."""
        self.other_deductions.append({
            "description": description,
            "amount": amount,
        })
        self._recalculate()
    
    def remove_other_deduction(self, index: int):
        """Remove other deduction."""
        if 0 <= index < len(self.other_deductions):
            self.other_deductions.pop(index)
            self._recalculate()
    
    # ===== Dependent Methods =====
    def add_dependent(self, name: str, relationship: str, age: int, is_child: bool = True):
        """Add a dependent (child or other)."""
        self.dependents.append({
            "name": name,
            "relationship": relationship,
            "age": age,
            "is_child": is_child and age < 17,  # Child Tax Credit requires under 17
        })
        self._recalculate()
    
    def remove_dependent(self, index: int):
        """Remove a dependent."""
        if 0 <= index < len(self.dependents):
            self.dependents.pop(index)
            self._recalculate()
    
    def set_child_care_expenses(self, amount: float):
        """Set child/dependent care expenses."""
        self.child_care_expenses = amount
        self._recalculate()
        self._auto_save()  # Persist the updated calculations
    
    # ===== ISO (Incentive Stock Options) Methods =====
    def add_iso_exercise(self):
        """Add an ISO exercise from form data (Form 3921)."""
        try:
            shares = int(self.iso_form_shares or 0)
            exercise_price = float(self.iso_form_exercise_price or 0)
            fmv = float(self.iso_form_fmv or 0)
            
            if shares <= 0 or not self.iso_form_company:
                return
            
            self.iso_exercises.append({
                "company": self.iso_form_company,
                "exercise_date": self.iso_form_exercise_date,
                "shares": shares,
                "exercise_price": exercise_price,
                "fmv_at_exercise": fmv,
                "sold": False,
                "spread": (fmv - exercise_price) * shares,  # AMT preference amount
            })
            
            # Clear form
            self.iso_form_company = ""
            self.iso_form_exercise_date = ""
            self.iso_form_shares = ""
            self.iso_form_exercise_price = ""
            self.iso_form_fmv = ""
            self.show_iso_form = False
            
            self._recalculate()
            self._auto_save()
        except ValueError:
            pass
    
    def remove_iso_exercise(self, index: int):
        """Remove an ISO exercise."""
        if 0 <= index < len(self.iso_exercises):
            self.iso_exercises.pop(index)
            self._recalculate()
            self._auto_save()
    
    def mark_iso_sold(self, index: int):
        """Mark an ISO as sold (removes from AMT calculation)."""
        if 0 <= index < len(self.iso_exercises):
            self.iso_exercises[index]["sold"] = True
            self._recalculate()
            self._auto_save()
    
    # ===== RSU (Restricted Stock Units) Methods =====
    def add_rsu_vest(self):
        """Add an RSU vest from form data."""
        try:
            shares = float(self.rsu_form_shares or 0)
            fmv = float(self.rsu_form_fmv or 0)
            
            if shares <= 0 or not self.rsu_form_company:
                return
            
            self.rsu_vests.append({
                "company": self.rsu_form_company,
                "vest_date": self.rsu_form_vest_date,
                "shares": shares,
                "fmv_per_share": fmv,
                "total_fmv": shares * fmv,  # This was taxed as W-2 income
                "shares_remaining": shares,  # Decremented when used for cost basis
            })
            
            # Clear form
            self.rsu_form_company = ""
            self.rsu_form_vest_date = ""
            self.rsu_form_shares = ""
            self.rsu_form_fmv = ""
            self.show_rsu_form = False
            
            self._recalculate()
            self._auto_save()
        except ValueError:
            pass
    
    def add_rsu_vest_from_data(self, company: str, vest_date: str, shares: float, fmv_per_share: float):
        """Add an RSU vest programmatically (from document extraction)."""
        self.rsu_vests.append({
            "company": company,
            "vest_date": vest_date,
            "shares": shares,
            "fmv_per_share": fmv_per_share,
            "total_fmv": shares * fmv_per_share,
            "shares_remaining": shares,
        })
        self._auto_save()
    
    def remove_rsu_vest(self, index: int):
        """Remove an RSU vest."""
        if 0 <= index < len(self.rsu_vests):
            self.rsu_vests.pop(index)
            self._recalculate()
            self._auto_save()
    
    def get_rsu_cost_basis(self, company: str, shares_sold: float, sale_date: str) -> tuple:
        """
        Get cost basis for RSU sale using FIFO method.
        Returns (cost_basis, shares_matched, vests_used).
        
        The cost basis for RSU shares = FMV at vest (already taxed as W-2 income).
        """
        cost_basis = 0.0
        shares_to_match = shares_sold
        vests_used = []
        
        # Sort vests by date (FIFO - First In, First Out)
        sorted_vests = sorted(
            [(i, v) for i, v in enumerate(self.rsu_vests) if v.get("company", "").upper() == company.upper()],
            key=lambda x: x[1].get("vest_date", "")
        )
        
        for idx, vest in sorted_vests:
            if shares_to_match <= 0:
                break
            
            remaining = vest.get("shares_remaining", vest.get("shares", 0))
            if remaining <= 0:
                continue
            
            # Use shares from this vest
            shares_from_vest = min(remaining, shares_to_match)
            basis_from_vest = shares_from_vest * vest.get("fmv_per_share", 0)
            
            cost_basis += basis_from_vest
            shares_to_match -= shares_from_vest
            vests_used.append({
                "vest_idx": idx,
                "shares_used": shares_from_vest,
                "basis": basis_from_vest,
                "vest_date": vest.get("vest_date"),
            })
        
        return cost_basis, shares_sold - shares_to_match, vests_used
    
    # ===== ESPP (Employee Stock Purchase Plan) Methods =====
    def add_espp_purchase(self):
        """Add an ESPP purchase from form data (Form 3922)."""
        try:
            shares = float(self.espp_form_shares or 0)
            exercise_price = float(self.espp_form_exercise_price or 0)
            fmv_grant = float(self.espp_form_fmv_grant or 0)
            fmv_purchase = float(self.espp_form_fmv_purchase or 0)
            
            if shares <= 0 or not self.espp_form_company:
                return
            
            # Calculate the discount (bargain element)
            discount_per_share = fmv_purchase - exercise_price
            
            self.espp_purchases.append({
                "company": self.espp_form_company,
                "grant_date": self.espp_form_grant_date,
                "purchase_date": self.espp_form_purchase_date,
                "shares": shares,
                "exercise_price": exercise_price,
                "fmv_grant": fmv_grant,
                "fmv_purchase": fmv_purchase,
                "discount_per_share": discount_per_share,
                "total_discount": discount_per_share * shares,
                "cost_basis": exercise_price * shares,  # What you actually paid
                "sold": False,
            })
            
            # Clear form
            self.espp_form_company = ""
            self.espp_form_grant_date = ""
            self.espp_form_purchase_date = ""
            self.espp_form_shares = ""
            self.espp_form_exercise_price = ""
            self.espp_form_fmv_grant = ""
            self.espp_form_fmv_purchase = ""
            self.show_espp_form = False
            
            self._recalculate()
            self._auto_save()
        except ValueError:
            pass
    
    def remove_espp_purchase(self, index: int):
        """Remove an ESPP purchase."""
        if 0 <= index < len(self.espp_purchases):
            self.espp_purchases.pop(index)
            self._recalculate()
            self._auto_save()
    
    def calculate_espp_sale_tax(self, purchase_idx: int, sale_date: str, sale_price: float) -> dict:
        """
        Calculate tax treatment for ESPP sale.
        
        Returns dict with:
        - is_qualifying: bool (met both holding periods)
        - ordinary_income: amount taxed as ordinary income
        - capital_gain: amount taxed as capital gain
        - holding_period: "short-term" or "long-term" for the capital gain portion
        """
        from datetime import datetime, timedelta
        
        if purchase_idx < 0 or purchase_idx >= len(self.espp_purchases):
            return {"error": "Invalid purchase index"}
        
        purchase = self.espp_purchases[purchase_idx]
        shares = purchase.get("shares", 0)
        exercise_price = purchase.get("exercise_price", 0)
        fmv_grant = purchase.get("fmv_grant", 0)
        fmv_purchase = purchase.get("fmv_purchase", 0)
        
        try:
            grant_date = datetime.strptime(purchase.get("grant_date", ""), "%Y-%m-%d")
            purchase_date = datetime.strptime(purchase.get("purchase_date", ""), "%Y-%m-%d")
            sale_dt = datetime.strptime(sale_date, "%Y-%m-%d")
        except ValueError:
            return {"error": "Invalid date format"}
        
        # Check qualifying disposition requirements
        # Must hold: 2+ years from grant AND 1+ year from purchase
        two_years_from_grant = grant_date + timedelta(days=730)
        one_year_from_purchase = purchase_date + timedelta(days=365)
        
        is_qualifying = sale_dt >= two_years_from_grant and sale_dt >= one_year_from_purchase
        
        # Calculate proceeds
        proceeds = sale_price * shares
        cost_basis = exercise_price * shares
        total_gain = proceeds - cost_basis
        
        if is_qualifying:
            # Qualifying Disposition
            # Ordinary income = LESSER OF:
            #   - Actual gain (sale_price - exercise_price) per share, OR
            #   - Discount at grant date (fmv_grant - exercise_price, max 15%)
            actual_gain_per_share = sale_price - exercise_price
            grant_discount_per_share = fmv_grant - exercise_price
            
            ordinary_income_per_share = min(actual_gain_per_share, grant_discount_per_share)
            ordinary_income_per_share = max(0, ordinary_income_per_share)  # Can't be negative
            
            ordinary_income = ordinary_income_per_share * shares
            capital_gain = total_gain - ordinary_income
            holding_period = "long-term"  # Always long-term for qualifying
        else:
            # Disqualifying Disposition
            # Ordinary income = FMV at purchase - exercise price (the bargain element)
            ordinary_income = (fmv_purchase - exercise_price) * shares
            ordinary_income = max(0, ordinary_income)
            
            # Remaining is capital gain (could be negative = loss)
            # Adjusted basis = exercise_price + ordinary_income recognized
            adjusted_basis = cost_basis + ordinary_income
            capital_gain = proceeds - adjusted_basis
            
            # Holding period for cap gain portion
            days_held = (sale_dt - purchase_date).days
            holding_period = "long-term" if days_held > 365 else "short-term"
        
        return {
            "is_qualifying": is_qualifying,
            "ordinary_income": ordinary_income,
            "capital_gain": capital_gain,
            "holding_period": holding_period,
            "proceeds": proceeds,
            "cost_basis": cost_basis,
        }
    
    # ===== Form Toggle Methods =====
    def toggle_rental_form(self):
        self.show_rental_form = not self.show_rental_form
    
    def toggle_business_form(self):
        self.show_business_form = not self.show_business_form
    
    def toggle_other_income_form(self):
        self.show_other_income_form = not self.show_other_income_form
    
    def toggle_other_deduction_form(self):
        self.show_other_deduction_form = not self.show_other_deduction_form
    
    def toggle_dependent_form(self):
        self.show_dependent_form = not self.show_dependent_form
    
    def toggle_iso_form(self):
        self.show_iso_form = not self.show_iso_form
    
    def toggle_rsu_form(self):
        self.show_rsu_form = not self.show_rsu_form
    
    def toggle_espp_form(self):
        self.show_espp_form = not self.show_espp_form
    
    # ===== Form Input Setters =====
    def set_rental_address(self, val): self.rental_form_address = val
    def set_rental_income(self, val): self.rental_form_income = val
    def set_rental_mortgage(self, val): self.rental_form_mortgage = val
    def set_rental_tax(self, val): self.rental_form_tax = val
    def set_rental_insurance(self, val): self.rental_form_insurance = val
    def set_rental_repairs(self, val): self.rental_form_repairs = val
    def set_rental_depreciation(self, val): self.rental_form_depreciation = val
    def set_rental_other(self, val): self.rental_form_other = val
    def set_rental_cost_basis(self, val): self.rental_form_cost_basis = val
    def set_rental_placed_month(self, val): self.rental_form_placed_month = val
    def set_rental_placed_year(self, val): self.rental_form_placed_year = val
    def toggle_rental_auto_depreciation(self): self.rental_form_auto_depreciation = not self.rental_form_auto_depreciation
    
    def set_business_name(self, val): self.business_form_name = val
    def set_business_income(self, val): self.business_form_income = val
    def set_business_expenses(self, val): self.business_form_expenses = val
    
    def set_other_income_desc(self, val): self.other_income_form_desc = val
    def set_other_income_amount(self, val): self.other_income_form_amount = val
    def set_other_deduction_desc(self, val): self.other_deduction_form_desc = val
    def set_other_deduction_amount(self, val): self.other_deduction_form_amount = val
    
    def set_dependent_name(self, val): self.dependent_form_name = val
    def set_dependent_relationship(self, val): self.dependent_form_relationship = val
    def set_dependent_age(self, val): self.dependent_form_age = val
    def set_child_care_amount(self, val): self.child_care_form_amount = val
    
    # ISO form setters
    def set_iso_company(self, val): self.iso_form_company = val
    def set_iso_exercise_date(self, val): self.iso_form_exercise_date = val
    def set_iso_shares(self, val): self.iso_form_shares = val
    def set_iso_exercise_price(self, val): self.iso_form_exercise_price = val
    def set_iso_fmv(self, val): self.iso_form_fmv = val
    
    # RSU form setters
    def set_rsu_company(self, val): self.rsu_form_company = val
    def set_rsu_vest_date(self, val): self.rsu_form_vest_date = val
    def set_rsu_shares(self, val): self.rsu_form_shares = val
    def set_rsu_fmv(self, val): self.rsu_form_fmv = val
    
    # ESPP form setters
    def set_espp_company(self, val): self.espp_form_company = val
    def set_espp_grant_date(self, val): self.espp_form_grant_date = val
    def set_espp_purchase_date(self, val): self.espp_form_purchase_date = val
    def set_espp_shares(self, val): self.espp_form_shares = val
    def set_espp_exercise_price(self, val): self.espp_form_exercise_price = val
    def set_espp_fmv_grant(self, val): self.espp_form_fmv_grant = val
    def set_espp_fmv_purchase(self, val): self.espp_form_fmv_purchase = val
    
    # ===== Form Submit Methods =====
    def _calculate_rental_depreciation(self, cost_basis: float, placed_month: int, placed_year: int, tax_year: int) -> float:
        """Calculate residential rental depreciation using 27.5 year straight-line.
        
        IRS rules:
        - Residential rental = 27.5 years straight-line
        - Mid-month convention: property placed in service in middle of month
        - First year: (12.5 - placed_month + 0.5) / 12 * annual_depreciation
        - Full years: cost_basis / 27.5
        - After 27.5 years: $0
        """
        if cost_basis <= 0 or placed_year > tax_year:
            return 0.0
        
        annual_depreciation = cost_basis / 27.5
        years_owned = tax_year - placed_year
        
        if years_owned == 0:
            # First year - mid-month convention
            # Months of service = (12 - placed_month + 0.5)
            months_in_service = 12 - placed_month + 0.5
            return (months_in_service / 12) * annual_depreciation
        elif years_owned < 27:
            # Full year depreciation
            return annual_depreciation
        elif years_owned == 27:
            # Final partial year (remaining 0.5 years)
            months_in_service = placed_month - 0.5
            return (months_in_service / 12) * annual_depreciation
        else:
            # Fully depreciated
            return 0.0
    
    def submit_rental_form(self):
        """Submit rental property form."""
        try:
            # Monthly rent × 12 = Annual rent income
            monthly_rent = float(self.rental_form_income or 0)
            annual_rent = monthly_rent * 12
            
            # Quarterly property tax × 4 = Annual
            quarterly_tax = float(self.rental_form_tax or 0)
            annual_tax = quarterly_tax * 4
            
            # Calculate depreciation (auto or manual)
            if self.rental_form_auto_depreciation:
                cost_basis = float(self.rental_form_cost_basis or 0)
                placed_month = int(self.rental_form_placed_month or 1)
                placed_year = int(self.rental_form_placed_year or self.tax_year)
                depreciation = self._calculate_rental_depreciation(
                    cost_basis, placed_month, placed_year, self.tax_year
                )
            else:
                cost_basis = 0
                placed_month = 0
                placed_year = 0
                depreciation = float(self.rental_form_depreciation or 0)
            
            self.add_rental_property(
                address=self.rental_form_address or "Property",
                rent_income=annual_rent,
                mortgage_interest=float(self.rental_form_mortgage or 0),
                property_tax=annual_tax,
                insurance=float(self.rental_form_insurance or 0),
                repairs=float(self.rental_form_repairs or 0),
                depreciation=depreciation,
                other_expenses=float(self.rental_form_other or 0),
                monthly_rent=monthly_rent,  # Store for display
                quarterly_tax=quarterly_tax,  # Store for display
                cost_basis=cost_basis,  # Store for recalculation
                placed_month=placed_month,
                placed_year=placed_year,
                auto_depreciation=self.rental_form_auto_depreciation,
            )
            # Clear form
            self.rental_form_address = ""
            self.rental_form_income = ""
            self.rental_form_mortgage = ""
            self.rental_form_tax = ""
            self.rental_form_insurance = ""
            self.rental_form_repairs = ""
            self.rental_form_depreciation = ""
            self.rental_form_other = ""
            self.rental_form_cost_basis = ""
            self.rental_form_placed_month = ""
            self.rental_form_placed_year = ""
            self.rental_form_auto_depreciation = True
            self.show_rental_form = False
            self.success_message = "Rental property added!"
        except ValueError:
            self.error_message = "Invalid numbers in form"
    
    def submit_business_form(self):
        """Submit business income form."""
        try:
            self.add_business(
                name=self.business_form_name or "Business",
                gross_income=float(self.business_form_income or 0),
                expenses=float(self.business_form_expenses or 0),
            )
            self.business_form_name = ""
            self.business_form_income = ""
            self.business_form_expenses = ""
            self.show_business_form = False
            self.success_message = "Business added!"
        except ValueError:
            self.error_message = "Invalid numbers in form"
    
    def submit_other_income_form(self):
        """Submit other income form."""
        try:
            self.add_other_income(
                description=self.other_income_form_desc or "Other Income",
                amount=float(self.other_income_form_amount or 0),
            )
            self.other_income_form_desc = ""
            self.other_income_form_amount = ""
            self.show_other_income_form = False
            self.success_message = "Other income added!"
        except ValueError:
            self.error_message = "Invalid amount"
    
    def submit_other_deduction_form(self):
        """Submit other deduction form."""
        try:
            self.add_other_deduction(
                description=self.other_deduction_form_desc or "Other Deduction",
                amount=float(self.other_deduction_form_amount or 0),
            )
            self.other_deduction_form_desc = ""
            self.other_deduction_form_amount = ""
            self.show_other_deduction_form = False
            self.success_message = "Deduction added!"
        except ValueError:
            self.error_message = "Invalid amount"
    
    def submit_dependent_form(self):
        """Submit dependent form."""
        try:
            age = int(self.dependent_form_age or 0)
            self.add_dependent(
                name=self.dependent_form_name or "Dependent",
                relationship=self.dependent_form_relationship or "Child",
                age=age,
                is_child=(age < 17),
            )
            self.dependent_form_name = ""
            self.dependent_form_relationship = ""
            self.dependent_form_age = ""
            self.show_dependent_form = False
            self.success_message = "Dependent added!"
        except ValueError:
            self.error_message = "Invalid age"
    
    def submit_child_care_expenses(self):
        """Submit child care expenses."""
        try:
            self.child_care_expenses = float(self.child_care_form_amount or 0)
            self.child_care_form_amount = ""
            self._recalculate()
            self.success_message = "Child care expenses updated!"
        except ValueError:
            self.error_message = "Invalid amount"
    
    def remove_file(self, filename: str):
        """Remove an uploaded file and its extracted data."""
        if filename in self.uploaded_files:
            self.uploaded_files.remove(filename)
        if filename in self.selected_files:
            self.selected_files.remove(filename)
        # Remove from parsed_documents
        self.parsed_documents = [
            doc for doc in self.parsed_documents 
            if doc["name"] != filename
        ]
        # Remove extracted W-2 data from this file
        self.w2_list = [
            w for w in self.w2_list 
            if w.get("source_file") != filename
        ]
        # Remove extracted 1099 data from this file
        self.form_1099_list = [
            f for f in self.form_1099_list 
            if f.get("source_file") != filename
        ]
        # Remove extracted 1098 data from this file
        self.form_1098_list = [
            f for f in self.form_1098_list 
            if f.get("source_file") != filename
        ]
        # Remove extracted 5498-SA data from this file
        self.form_5498_list = [
            f for f in self.form_5498_list 
            if f.get("source_file") != filename
        ]
        # Recalculate totals
        self._recalculate()
        
        if not self.uploaded_files:
            self.return_status = "not_started"
    
    def _recalculate(self):
        """Recalculate all tax values following IRS Form 1040 logic."""
        # Get set of included document filenames
        included_files = self.get_included_files()
        
        # Helper to check if item should be included
        def is_included(item):
            source = item.get("source_file")
            # Include if: no source file (manual entry) OR source is in included set
            return source is None or source in included_files
        
        # ===== INCOME (Lines 1-9) =====
        
        # Line 1: Wages (from W-2)
        self.total_wages = sum(w.get("wages", 0) for w in self.w2_list if is_included(w))
        
        # Employer HSA contributions (W-2 Box 12 Code W) - already excluded from wages
        self.employer_hsa_contributions = sum(
            w.get("hsa_employer_contribution", 0) for w in self.w2_list if is_included(w)
        )
        
        # Medicare wages (W-2 Box 5) - used for Additional Medicare Tax
        # Box 5 is often HIGHER than Box 1 because pretax deductions (401k, health, HSA) 
        # are excluded from Box 1 but included in Box 5
        # If Box 5 not provided, fall back to Box 1
        self.total_medicare_wages = sum(
            w.get("medicare_wages", 0) or w.get("wages", 0) 
            for w in self.w2_list if is_included(w)
        )
        
        # Withholding from all sources
        self.total_withholding = sum(w.get("federal_withheld", 0) for w in self.w2_list if is_included(w))
        self.total_withholding += sum(f.get("federal_withheld", 0) for f in self.form_1099_list if is_included(f))
        self.total_withholding += sum(r.get("federal_withheld", 0) for r in self.form_1099r_list if is_included(r))  # 1099-R
        self.total_withholding += self.other_withholding  # From 1099-NEC/MISC
        
        # Line 2b: Taxable interest (1099-INT)
        self.total_interest = sum(
            f.get("amount", 0) for f in self.form_1099_list 
            if f.get("form_type") == "1099-INT" and is_included(f)
        )
        
        # Line 3b: Ordinary dividends (1099-DIV)
        # Total dividends = Box 1a (ordinary dividends)
        self.total_dividends = sum(
            f.get("amount", 0) for f in self.form_1099_list 
            if f.get("form_type") == "1099-DIV" and is_included(f)
        )
        # Qualified dividends = Box 1b (subset of ordinary, taxed at cap gains rates)
        self.qualified_dividends = sum(
            f.get("qualified_dividends", 0) for f in self.form_1099_list 
            if f.get("form_type") == "1099-DIV" and is_included(f)
        )
        # Ensure qualified doesn't exceed total (data integrity)
        self.qualified_dividends = min(self.qualified_dividends, self.total_dividends)
        
        # Line 7: Capital gains (1099-B) - separate short-term and long-term
        # Short-term gains (held ≤1 year) = taxed as ordinary income
        self.short_term_capital_gains = sum(
            f.get("amount", 0) for f in self.form_1099_list 
            if f.get("form_type") == "1099-B" and f.get("is_short_term", False) and is_included(f)
        )
        # Long-term gains (held >1 year) = preferential rates
        self.long_term_capital_gains = sum(
            f.get("amount", 0) for f in self.form_1099_list 
            if f.get("form_type") == "1099-B" and not f.get("is_short_term", False) and is_included(f)
        )
        # Total for display and other calculations
        self.total_capital_gains = self.short_term_capital_gains + self.long_term_capital_gains
        
        # Other income from 1099 (1099-MISC, 1099-NEC, etc.)
        other_1099_income = sum(
            f.get("amount", 0) for f in self.form_1099_list 
            if f.get("form_type") not in ("1099-INT", "1099-DIV", "1099-B") and is_included(f)
        )
        
        # Schedule E - Rental Property Income (Line 17)
        # Calculate raw rental income/loss before passive activity limits
        self.rental_income_before_passive_limit = sum(
            p.get("net_income", 0) for p in self.rental_properties if is_included(p)
        )
        
        # Passive Activity Loss Limits (Form 8582)
        # Rental activity is passive by default unless Real Estate Professional
        # See IRC Section 469 and Publication 925
        #
        # Rules:
        # 1. If rental has NET PROFIT: fully taxable (no limit)
        # 2. If rental has NET LOSS:
        #    - Real Estate Professional: no limit (all losses deductible)
        #    - Active Participation: up to $25,000 deductible, phases out $100k-$150k MAGI
        #    - Neither: no losses deductible (suspended until property sale)
        
        if self.rental_income_before_passive_limit >= 0:
            # Profit - no passive activity limits apply
            self.total_rental_income = self.rental_income_before_passive_limit
            self.suspended_passive_loss = 0.0
        else:
            # Loss - apply passive activity rules
            rental_loss = abs(self.rental_income_before_passive_limit)
            
            if self.is_real_estate_professional:
                # Real estate professional can deduct all rental losses
                self.total_rental_income = self.rental_income_before_passive_limit
                self.suspended_passive_loss = 0.0
            else:
                # Check for active participation (any property with active_participation=True)
                has_active_participation = any(
                    p.get("active_participation", True)  # Default True for simplicity
                    for p in self.rental_properties if is_included(p)
                )
                
                if has_active_participation:
                    # $25,000 special allowance with phase-out (IRS Publication 527)
                    # Calculate preliminary AGI for phase-out (without rental loss)
                    preliminary_income = (
                        self.total_wages + self.total_interest + 
                        self.total_dividends + self.total_capital_gains + 
                        self.total_business_income + self.total_other_income
                    )
                    
                    # Use centralized passive loss allowance calculation
                    allowed_loss, suspended_loss = calculate_passive_loss_allowance(
                        preliminary_income, self.filing_status, rental_loss
                    )
                    self.total_rental_income = -allowed_loss  # Negative = loss
                    self.suspended_passive_loss = suspended_loss
                else:
                    # No active participation - all losses suspended
                    self.total_rental_income = 0.0
                    self.suspended_passive_loss = rental_loss
        
        # Schedule C - Business Income (Line 3 of Schedule 1)
        self.total_business_income = sum(
            b.get("net_profit", 0) for b in self.business_income if is_included(b)
        )
        
        # Other manual income entries (manual = no source_file, always included)
        manual_other_income = sum(
            i.get("amount", 0) for i in self.other_income if is_included(i)
        )
        
        # Non-qualified 529 distribution earnings (taxable as ordinary income)
        nonqualified_529_income = sum(
            d.get("earnings", 0) for d in self.distributions_529
            if not d.get("is_qualified", True)
        )
        
        # 1099-R retirement distributions (taxable amount)
        retirement_income = sum(
            r.get("taxable_amount", 0) for r in self.form_1099r_list
            if is_included(r)
        )
        
        self.total_other_income = other_1099_income + manual_other_income + nonqualified_529_income + retirement_income
        
        # ===== SELF-EMPLOYMENT TAX (Schedule SE) =====
        # SE tax = 15.3% on 92.35% of net self-employment income
        # (12.4% Social Security + 2.9% Medicare)
        # Social Security portion only applies to first $168,600 (2024)
        se_income = self.total_business_income
        if se_income > 0:
            se_taxable = se_income * 0.9235  # 92.35%
            ss_wage_base = TAX_CONSTANTS_2024["social_security_wage_base"]
            ss_portion = min(se_taxable, ss_wage_base) * 0.124
            medicare_portion = se_taxable * 0.029
            self.self_employment_tax = ss_portion + medicare_portion
            se_deduction = self.self_employment_tax / 2  # Half is deductible
        else:
            self.self_employment_tax = 0.0
            se_deduction = 0.0
        
        # ===== ADJUSTMENTS TO INCOME (Lines 10-22) =====
        
        # HSA deduction (from 5498-SA, minus employer contributions)
        # Employer HSA contributions (W-2 Box 12 Code W) are already excluded from wages
        # Only personal contributions are deductible
        total_hsa_contributions = sum(
            f.get("contribution", 0) for f in self.form_5498_list if is_included(f)
        )
        self.hsa_deduction = max(0, total_hsa_contributions - self.employer_hsa_contributions)
        
        # Other manual deductions (above-the-line)
        manual_deductions = sum(
            d.get("amount", 0) for d in self.other_deductions if is_included(d)
        )
        
        # Total adjustments to income
        adjustments = self.hsa_deduction + se_deduction + manual_deductions
        
        # Line 9: Total Income
        # Capital losses are limited to $3,000 per year for offsetting ordinary income (IRC 1211)
        # Excess losses carry forward to future years
        capital_gains_for_income = max(-CAPITAL_LOSS_LIMIT, self.total_capital_gains)
        if self.total_capital_gains < -CAPITAL_LOSS_LIMIT:
            # Track carryover (simplified - just track the excess)
            self.capital_loss_carryover_short = abs(self.total_capital_gains) - CAPITAL_LOSS_LIMIT
        
        total_income = (
            self.total_wages + self.total_interest + 
            self.total_dividends + capital_gains_for_income + 
            self.total_rental_income + self.total_business_income +
            self.total_other_income
        )
        
        # Store total income (before adjustments) for consistent display
        self.total_income = total_income
        
        # Line 11: AGI = Total Income - Adjustments
        self.adjusted_gross_income = max(0, total_income - adjustments)
        
        # ===== DEDUCTIONS (Lines 12-14) =====
        
        # Mortgage interest deduction (from 1098 forms)
        self.mortgage_interest_deduction = sum(
            f.get("mortgage_interest", 0) + f.get("points_paid", 0)
            for f in self.form_1098_list if is_included(f)
        )
        
        # Property taxes (SALT - capped at $10,000)
        property_taxes = sum(f.get("property_taxes", 0) for f in self.form_1098_list if is_included(f))
        salt_deduction = min(property_taxes, SALT_CAP)  # SALT cap
        
        # Itemized deductions (Schedule A)
        self.itemized_deductions = self.mortgage_interest_deduction + salt_deduction
        
        # Standard deduction based on filing status
        self.standard_deduction = TAX_CONSTANTS_2024["standard_deduction"].get(
            self.filing_status, 14600
        )
        
        # Use higher of standard or itemized deduction
        self.total_deductions = max(self.standard_deduction, self.itemized_deductions)
        
        # ===== QBI DEDUCTION (Section 199A) =====
        # Qualified Business Income = Schedule C net + Schedule E rental net
        # 20% deduction subject to income limits
        qualified_business_income = self.total_business_income + self.total_rental_income
        
        if qualified_business_income > 0:
            # 2024 Income thresholds for QBI phase-out
            qbi_thresholds = {
                "single": (191950, 241950),
                "married_filing_jointly": (383900, 483900),
                "married_filing_separately": (191950, 241950),
                "head_of_household": (191950, 241950),
                "qualifying_widow": (383900, 483900),
            }
            threshold_start, threshold_end = qbi_thresholds.get(
                self.filing_status, (191950, 241950)
            )
            
            # Pre-QBI taxable income for phase-out calculation
            pre_qbi_taxable = self.adjusted_gross_income - self.total_deductions
            
            # Calculate QBI deduction (20% of QBI, subject to limits)
            tentative_qbi = qualified_business_income * 0.20
            
            # Apply income phase-out
            if pre_qbi_taxable <= threshold_start:
                # Full deduction
                self.qbi_deduction = tentative_qbi
            elif pre_qbi_taxable >= threshold_end:
                # No deduction (phased out completely)
                self.qbi_deduction = 0.0
            else:
                # Partial phase-out
                phase_out_range = threshold_end - threshold_start
                excess_income = pre_qbi_taxable - threshold_start
                phase_out_pct = excess_income / phase_out_range
                self.qbi_deduction = tentative_qbi * (1 - phase_out_pct)
            
            # QBI deduction cannot exceed 20% of (taxable income - net capital gains)
            taxable_limit = max(0, (pre_qbi_taxable - self.total_capital_gains) * 0.20)
            self.qbi_deduction = min(self.qbi_deduction, taxable_limit)
        else:
            self.qbi_deduction = 0.0
        
        # ===== TAXABLE INCOME (Line 15) =====
        # QBI reduces taxable income
        self.taxable_income = max(0, self.adjusted_gross_income - self.total_deductions - self.qbi_deduction)
        
        # ===== TAX CALCULATION (Line 16) =====
        # 
        # Income types and their tax treatment:
        # - Ordinary income: wages, interest, ordinary-only dividends, short-term gains, SE income
        # - Preferential income: qualified dividends, long-term gains (0%/15%/20%)
        #
        # The IRS "stacking" method: ordinary income fills brackets first,
        # then preferential income is taxed at the rate for that income level.
        
        brackets = TAX_CONSTANTS_2024["brackets"].get(
            self.filing_status, 
            TAX_CONSTANTS_2024["brackets"]["single"]
        )
        cg_brackets = TAX_CONSTANTS_2024["capital_gains_brackets"].get(
            self.filing_status,
            TAX_CONSTANTS_2024["capital_gains_brackets"]["single"]
        )
        
        # Apply capital loss carryover from prior years
        prior_loss_carryover = (self.capital_loss_carryover_short or 0) + (self.capital_loss_carryover_long or 0)
        
        # Net capital position (apply losses to gains first)
        net_short_term = self.short_term_capital_gains - (self.capital_loss_carryover_short or 0)
        net_long_term = self.long_term_capital_gains - (self.capital_loss_carryover_long or 0)
        
        # If one category has excess losses, apply to the other
        if net_short_term < 0 and net_long_term > 0:
            net_long_term = net_long_term + net_short_term  # Reduce long-term by short-term losses
            net_short_term = 0
        elif net_long_term < 0 and net_short_term > 0:
            net_short_term = net_short_term + net_long_term  # Reduce short-term by long-term losses
            net_long_term = 0
        
        # Total net capital gain/loss
        net_capital = net_short_term + net_long_term
        
        # Capital loss deduction limit ($3,000/year against ordinary income)
        if net_capital < 0:
            capital_loss_deduction = min(abs(net_capital), 3000)
            self.capital_loss_carryover_next_year = abs(net_capital) - capital_loss_deduction
        else:
            capital_loss_deduction = 0
            self.capital_loss_carryover_next_year = 0
        
        # Calculate ordinary-only dividends (total - qualified)
        ordinary_only_dividends = max(0, self.total_dividends - self.qualified_dividends)
        
        # Ordinary income (taxed at regular brackets)
        # Includes: wages, interest, ordinary-only dividends, short-term gains, other income
        # Note: Net short-term gains are included; net short-term losses reduce ordinary income
        ordinary_income = (
            self.taxable_income 
            - self.qualified_dividends 
            - max(0, net_long_term)  # Exclude long-term gains (preferential)
        )
        # Add back short-term gains if they were already in taxable income
        # Subtract capital loss deduction
        ordinary_income = max(0, ordinary_income - capital_loss_deduction)
        
        # Tax on ordinary income (regular brackets)
        ordinary_tax = self._calculate_tax(ordinary_income, brackets)
        
        # Preferential income (qualified dividends + net long-term capital gains)
        preferential_income = self.qualified_dividends + max(0, net_long_term)
        
        # Tax on preferential income at capital gains rates
        # The rate depends on where this income "stacks" on top of ordinary income
        if preferential_income > 0:
            self.capital_gains_tax = self._calculate_preferential_tax(
                ordinary_income, preferential_income, cg_brackets
            )
        else:
            self.capital_gains_tax = 0.0
        
        # Additional Medicare Tax (0.9% on Medicare wages over threshold)
        # Per IRS Form 8959: Uses Medicare wages (W-2 Box 5), NOT regular wages (Box 1)
        # Box 5 includes pretax deductions like 401k, health insurance, HSA that are
        # excluded from Box 1, so Box 5 is often higher than Box 1
        # Thresholds: MFJ $250k, Single $200k, MFS $125k
        medicare_thresholds = {
            "married_filing_jointly": 250000,
            "qualifying_widow": 250000,
            "single": 200000,
            "head_of_household": 200000,
            "married_filing_separately": 125000,
        }
        medicare_threshold = medicare_thresholds.get(self.filing_status, 200000)
        # Use Medicare wages (Box 5) if available, otherwise fall back to regular wages
        medicare_wages_for_tax = self.total_medicare_wages if self.total_medicare_wages > 0 else self.total_wages
        medicare_base = max(0, medicare_wages_for_tax - medicare_threshold)
        self.additional_medicare_tax = medicare_base * 0.009
        
        # Net Investment Income Tax (NIIT) - 3.8% on investment income when AGI > threshold
        # Thresholds: MFJ $250k, Single $200k, MFS $125k
        niit_thresholds = {
            "married_filing_jointly": 250000,
            "qualifying_widow": 250000,
            "single": 200000,
            "head_of_household": 200000,
            "married_filing_separately": 125000,
        }
        niit_threshold = niit_thresholds.get(self.filing_status, 200000)
        # NIIT investment income (Form 8960):
        # Line 1: Interest
        # Line 2: Dividends  
        # Line 5a-5d: Net capital gain/loss from Schedule D
        #   - Form 8960 Line 5a references Schedule D Line 15 or 16
        #   - Capital losses are capped at $3,000 (same as regular tax)
        # Line 4c: Rental - excluded if actively managed (trade/business exception)
        # 
        # Per IRS Form 8960 instructions and verified against CPA practice:
        capital_for_niit = max(-CAPITAL_LOSS_LIMIT, self.total_capital_gains)  # Same $3k loss cap as Schedule D
        investment_income = (
            self.total_interest + 
            self.total_dividends + 
            capital_for_niit
            # Rental excluded - typically trade/business for active landlords
        )
        # NII cannot be negative
        investment_income = max(0, investment_income)
        niit_base = min(investment_income, max(0, self.adjusted_gross_income - niit_threshold))
        self.niit = niit_base * 0.038
        
        # ===== ALTERNATIVE MINIMUM TAX (AMT) - Form 6251 =====
        # AMT is a parallel tax system. Pay the HIGHER of regular tax or AMT.
        # Key AMT preference items that get added back:
        # 1. State/local tax deduction (SALT) - already capped at $10k
        # 2. ISO spread (FMV - exercise price) at exercise
        # 3. Certain itemized deductions
        
        # Calculate ISO AMT preference (spread at exercise for unexercised ISOs)
        self.iso_amt_preference = sum(
            (iso.get("fmv_at_exercise", 0) - iso.get("exercise_price", 0)) * iso.get("shares", 0)
            for iso in self.iso_exercises
            if not iso.get("sold", False)  # Only count ISOs not yet sold
        )
        
        # Step 1: Calculate Alternative Minimum Taxable Income (AMTI)
        # Start with taxable income, then add back AMT preference items
        
        # SALT already deducted (in itemized) - add back for AMT
        # Note: We already have SALT capped at $10k, but for AMT it's fully disallowed
        salt_addback = min(
            sum(f.get("property_taxes", 0) for f in self.form_1098_list),
            10000  # The amount actually deducted (SALT cap)
        ) if self.itemized_deductions > self.standard_deduction else 0
        
        # AMTI = Taxable Income + AMT Preference Items
        self.amt_income = (
            self.taxable_income +
            self.iso_amt_preference +  # ISO spread
            salt_addback  # State/local taxes
            # Note: Could add more items like private activity bond interest, etc.
        )
        
        # Step 2: Calculate AMT Exemption (phases out at high income)
        base_exemption = TAX_CONSTANTS_2024["amt_exemption"].get(self.filing_status, 85700)
        phaseout_threshold = TAX_CONSTANTS_2024["amt_phaseout_start"].get(self.filing_status, 609350)
        
        # Exemption phases out at 25 cents per dollar over threshold
        if self.amt_income > phaseout_threshold:
            exemption_reduction = (self.amt_income - phaseout_threshold) * 0.25
            self.amt_exemption = max(0, base_exemption - exemption_reduction)
        else:
            self.amt_exemption = base_exemption
        
        # Step 3: Calculate Tentative Minimum Tax
        amt_taxable = max(0, self.amt_income - self.amt_exemption)
        
        # AMT rates: 26% up to threshold, 28% above
        amt_rate_threshold = TAX_CONSTANTS_2024["amt_26_percent_limit"].get(self.filing_status, 110350)
        
        if amt_taxable <= amt_rate_threshold:
            self.tentative_minimum_tax = amt_taxable * 0.26
        else:
            self.tentative_minimum_tax = (amt_rate_threshold * 0.26) + ((amt_taxable - amt_rate_threshold) * 0.28)
        
        # Step 4: Compare to regular tax (before credits)
        regular_tax_before_credits = ordinary_tax + self.capital_gains_tax
        
        # AMT owed is the excess of TMT over regular tax
        self.amt_owed = max(0, self.tentative_minimum_tax - regular_tax_before_credits)
        
        # Gross tax before credits (includes AMT if applicable)
        gross_tax = (ordinary_tax + self.capital_gains_tax + self.amt_owed +
                    self.additional_medicare_tax + self.niit + 
                    self.self_employment_tax)
        
        # ===== TAX CREDITS =====
        
        # Child Tax Credit ($2,000 per qualifying child under 17)
        # Phase out: MFJ $400k, others $200k
        ctc_phaseout = 400000 if self.filing_status == "married_filing_jointly" else 200000
        qualifying_children = sum(1 for d in self.dependents if d.get("is_child", False))
        base_ctc = qualifying_children * CHILD_TAX_CREDIT
        
        # Phase out: reduce by $50 for each $1,000 over threshold
        if self.adjusted_gross_income > ctc_phaseout:
            reduction = ((self.adjusted_gross_income - ctc_phaseout) // 1000) * 50
            self.child_tax_credit = max(0, base_ctc - reduction)
        else:
            self.child_tax_credit = base_ctc
        
        # Credit for Other Dependents ($500 per dependent not qualifying for CTC)
        other_dependents = sum(1 for d in self.dependents if not d.get("is_child", False))
        self.other_dependent_credit = other_dependents * DEPENDENT_CREDIT
        
        # Child and Dependent Care Credit (20-35% of expenses, max $3,000/1 or $6,000/2+)
        # Note: Expenses used for Dependent Care FSA (W-2 Box 10) CANNOT also be used for this credit
        total_dcfsa = sum(w.get("dependent_care_benefits", 0) for w in self.w2_list)
        expenses_for_credit = max(0, self.child_care_expenses - total_dcfsa)  # Reduce by FSA amount
        
        if expenses_for_credit > 0 and qualifying_children > 0:
            max_expenses = 3000 if qualifying_children == 1 else 6000
            eligible_expenses = min(expenses_for_credit, max_expenses)
            # Credit rate: 35% if AGI <= $15,000, phases down to 20% at $43,000+
            if self.adjusted_gross_income <= 15000:
                rate = 0.35
            elif self.adjusted_gross_income >= 43000:
                rate = 0.20
            else:
                rate = 0.35 - ((self.adjusted_gross_income - 15000) // 2000) * 0.01
                rate = max(0.20, rate)
            self.child_care_credit = eligible_expenses * rate
        else:
            self.child_care_credit = 0.0
        
        # Total credits (nonrefundable - can't exceed tax)
        self.total_credits = self.child_tax_credit + self.other_dependent_credit + self.child_care_credit
        
        # ===== 529 NON-QUALIFIED DISTRIBUTION PENALTY =====
        # Non-qualified 529 distributions: earnings taxed as ordinary income + 10% penalty
        nonqualified_529_earnings = sum(
            d.get("earnings", 0) for d in self.distributions_529
            if not d.get("is_qualified", True)
        )
        penalty_529 = nonqualified_529_earnings * 0.10
        
        # ===== EARLY WITHDRAWAL PENALTY (1099-R) =====
        # 10% penalty on early distributions (code 1 or J, before age 59.5)
        early_withdrawal_penalty = sum(
            r.get("taxable_amount", 0) * 0.10 for r in self.form_1099r_list
            if r.get("is_early", False)
        )
        
        # ===== AMT CREDIT (Form 8801) =====
        # Prior year AMT from timing differences (like ISO) can offset regular tax
        # Credit is limited to excess of regular tax over TMT in current year
        # For simplicity, we apply carryforward directly (user enters from Form 8801)
        amt_credit_used = min(
            self.amt_credit_carryforward,
            max(0, gross_tax - self.total_credits)  # Can't exceed tax liability
        )
        
        # Total tax after credits, AMT credit, plus penalties
        self.total_tax = max(0, gross_tax - self.total_credits - amt_credit_used) + penalty_529 + early_withdrawal_penalty
        
        # ===== REFUND OR AMOUNT OWED =====
        self.refund_or_owed = self.total_withholding - self.total_tax
        self.is_refund = self.refund_or_owed >= 0
        
        if self.total_wages > 0 or total_income > 0:
            self.return_status = "in_progress"
        
        # Auto-save after recalculation
        self._auto_save()
    
    def _auto_save(self):
        """Auto-save state to disk."""
        try:
            save_state(self)
        except Exception as e:
            print(f"[TaxSnapPro] Auto-save failed: {e}")
    
    def _calculate_tax(self, income: float, brackets: list) -> float:
        """Calculate tax from brackets."""
        tax = 0.0
        remaining = income
        prev = 0.0
        
        for limit, rate in brackets:
            if remaining <= 0:
                break
            bracket_income = min(remaining, limit - prev)
            tax += bracket_income * rate
            remaining -= bracket_income
            prev = limit
        
        return round(tax, 2)
    
    def _calculate_preferential_tax(self, ordinary_income: float, preferential_income: float, cg_brackets: list) -> float:
        """
        Calculate tax on preferential income (qualified dividends + long-term capital gains).
        
        Uses the "stacking" method: preferential income is taxed at the rate
        corresponding to where it falls when stacked on top of ordinary income.
        
        Example: If ordinary income is $40,000 and preferential is $20,000,
        the preferential income starts at $40,000 and is taxed at the rate
        for that income level.
        """
        tax = 0.0
        remaining = preferential_income
        current_position = ordinary_income  # Start where ordinary income ends
        prev = 0.0
        
        for limit, rate in cg_brackets:
            if remaining <= 0:
                break
            
            # How much of this bracket is available?
            # If current_position is already past this bracket, skip it
            if current_position >= limit:
                prev = limit
                continue
            
            # Start of this bracket for preferential income
            bracket_start = max(current_position, prev)
            
            # How much room in this bracket?
            room_in_bracket = limit - bracket_start
            
            # How much preferential income fits in this bracket?
            income_in_bracket = min(remaining, room_in_bracket)
            
            tax += income_in_bracket * rate
            remaining -= income_in_bracket
            current_position += income_in_bracket
            prev = limit
        
        return round(tax, 2)
    
    def generate_return(self):
        """Generate official IRS Form 1040 PDF."""
        self._recalculate()
        self.return_status = "complete"
        self.return_generated = True
        
        # Ensure IRS form template exists
        irs_forms_dir = Path.home() / ".taxsnappro" / "irs_forms"
        irs_forms_dir.mkdir(parents=True, exist_ok=True)
        template_path = irs_forms_dir / "f1040.pdf"
        
        if not template_path.exists():
            # Download from IRS
            import httpx
            print("[TaxSnapPro] Downloading IRS Form 1040 template...")
            try:
                resp = httpx.get("https://www.irs.gov/pub/irs-pdf/f1040.pdf", timeout=30)
                resp.raise_for_status()
                template_path.write_bytes(resp.content)
                print("[TaxSnapPro] Form 1040 template downloaded")
            except Exception as e:
                self.error_message = f"Failed to download Form 1040: {e}"
                return
        
        # Generate filled Form 1040
        tax_data = get_tax_data_for_1040(self)
        try:
            pdf_bytes = fill_form_1040(tax_data, template_path=str(template_path))
        except Exception as e:
            self.error_message = f"Failed to fill Form 1040: {e}"
            return
        
        # Store as base64 for download
        self.generated_pdf_base64 = base64.b64encode(pdf_bytes).decode('utf-8')
        self.show_return_summary = True
        
        # Build summary
        refund_or_owed = self.total_withholding - self.total_tax
        if refund_or_owed >= 0:
            result_text = f"Estimated Refund: ${refund_or_owed:,.2f}"
        else:
            result_text = f"Estimated Amount Owed: ${abs(refund_or_owed):,.2f}"
        
        self.success_message = f"✅ IRS Form 1040 generated! {result_text}"
    
    def close_return_summary(self):
        """Close the return summary modal."""
        self.show_return_summary = False
    
    def download_pdf(self):
        """Trigger PDF download."""
        if self.generated_pdf_base64:
            return rx.download(
                data=f"data:application/pdf;base64,{self.generated_pdf_base64}",
                filename=f"Form_1040_{self.tax_year}.pdf"
            )
    
    def clear_all(self):
        """Clear all data."""
        self.uploaded_files = []
        self.parsed_documents = []
        self.selected_files = []
        self.w2_list = []
        self.form_1098_list = []
        self.form_5498_list = []
        self.rental_properties = []
        self.business_income = []
        self.other_income = []
        self.other_deductions = []
        self.dependents = []
        self.child_care_expenses = 0.0
        self.form_1099_list = []
        self.total_wages = 0.0
        self.total_medicare_wages = 0.0
        self.employer_hsa_contributions = 0.0
        self.total_interest = 0.0
        self.total_dividends = 0.0
        self.qualified_dividends = 0.0
        self.total_capital_gains = 0.0
        self.short_term_capital_gains = 0.0
        self.long_term_capital_gains = 0.0
        self.total_rental_income = 0.0
        self.rental_income_before_passive_limit = 0.0
        self.suspended_passive_loss = 0.0
        self.is_real_estate_professional = False
        self.total_business_income = 0.0
        self.total_other_income = 0.0
        self.hsa_deduction = 0.0
        self.self_employment_tax = 0.0
        self.mortgage_interest_deduction = 0.0
        self.adjusted_gross_income = 0.0
        self.itemized_deductions = 0.0
        self.standard_deduction = 0.0
        self.total_deductions = 0.0
        self.taxable_income = 0.0
        self.capital_gains_tax = 0.0
        self.additional_medicare_tax = 0.0
        self.niit = 0.0
        self.total_income = 0.0
        self.total_tax = 0.0
        self.total_withholding = 0.0
        self.other_withholding = 0.0
        self.refund_or_owed = 0.0
        self.is_refund = True
        self.return_status = "not_started"
        self.return_generated = False
        self.show_return_summary = False
        self.generated_pdf_base64 = ""
        self.error_message = ""
        self.success_message = ""
        # Also clear persisted data
        clear_saved_data()
    
    def load_saved_data(self):
        """Load previously saved data from disk."""
        if load_state(self):
            self.success_message = "Previous session restored!"
        else:
            self.success_message = ""
    
    # ===== Computed Properties =====
    @rx.var
    def formatted_refund(self) -> str:
        """Format refund amount."""
        amount = abs(self.refund_or_owed)
        if self.is_refund:
            return f"+${amount:,.2f}"
        return f"-${amount:,.2f}"
    
    @rx.var
    def has_documents(self) -> bool:
        """Check if documents uploaded."""
        return len(self.parsed_documents) > 0
    
    @rx.var
    def has_income_data(self) -> bool:
        """Check if income data entered."""
        return len(self.w2_list) > 0 or len(self.form_1099_list) > 0
    
    @rx.var
    def can_generate_return(self) -> bool:
        """Check if can generate return."""
        return self.has_income_data
    
    # ===== Consistent Display Properties =====
    @rx.var
    def display_total_income(self) -> str:
        """Total income before adjustments - consistent across all pages."""
        return f"${self.total_income:,.0f}" if self.total_income > 0 else "$0"
    
    @rx.var  
    def display_estimated_tax(self) -> str:
        """Estimated tax - consistent across all pages."""
        return f"${self.total_tax:,.0f}" if self.total_tax > 0 else "$0"
    
    @rx.var
    def display_deductions(self) -> str:
        """Total deductions - consistent across all pages."""  
        return f"${self.total_deductions:,.0f}" if self.total_deductions > 0 else "$0"
    
    # ===== Breakdown Display Properties =====
    @rx.var
    def deduction_type_label(self) -> str:
        """Label for the type of deduction being used."""
        if self.itemized_deductions > self.standard_deduction:
            return "Itemized"
        return "Standard"
    
    @rx.var
    def formatted_standard_deduction(self) -> str:
        """Formatted standard deduction."""
        return f"${(self.standard_deduction or 0):,.0f}"
    
    @rx.var
    def formatted_itemized_deductions(self) -> str:
        """Formatted itemized deductions."""
        return f"${(self.itemized_deductions or 0):,.0f}"
    
    @rx.var
    def formatted_mortgage_interest(self) -> str:
        """Formatted mortgage interest deduction."""
        return f"${(self.mortgage_interest_deduction or 0):,.0f}"
    
    @rx.var
    def formatted_salt_deduction(self) -> str:
        """Formatted SALT deduction (capped at $10k)."""
        property_taxes = sum(float(f.get("property_taxes", 0) or 0) for f in self.form_1098_list)
        salt = min(property_taxes, SALT_CAP)
        return f"${salt:,.0f}"
    
    @rx.var
    def formatted_hsa_deduction(self) -> str:
        """Formatted HSA deduction."""
        return f"${(self.hsa_deduction or 0):,.0f}"
    
    @rx.var
    def formatted_se_deduction(self) -> str:
        """Formatted self-employment deduction (half of SE tax)."""
        se_tax = self.self_employment_tax or 0.0
        se_ded = se_tax / 2 if se_tax > 0 else 0
        return f"${se_ded:,.0f}"
    
    @rx.var
    def formatted_qbi_deduction(self) -> str:
        """Formatted QBI deduction (Section 199A)."""
        return f"${self.qbi_deduction:,.0f}" if self.qbi_deduction > 0 else "$0"
    
    @rx.var
    def formatted_ordinary_tax(self) -> str:
        """Formatted ordinary income tax (regular brackets)."""
        taxable = self.taxable_income or 0.0
        cap_gains = self.total_capital_gains or 0.0
        ordinary_income = max(0, taxable - cap_gains)
        brackets = TAX_CONSTANTS_2024["brackets"].get(self.filing_status or "single", TAX_CONSTANTS_2024["brackets"]["single"])
        tax = self._calculate_tax(ordinary_income, brackets)
        return f"${tax:,.0f}"
    
    @rx.var
    def formatted_capital_gains_tax(self) -> str:
        """Formatted capital gains tax."""
        return f"${(self.capital_gains_tax or 0):,.0f}"
    
    @rx.var
    def formatted_se_tax(self) -> str:
        """Formatted self-employment tax."""
        return f"${(self.self_employment_tax or 0):,.0f}"
    
    @rx.var
    def formatted_additional_medicare(self) -> str:
        """Formatted additional Medicare tax."""
        return f"${(self.additional_medicare_tax or 0):,.0f}"
    
    @rx.var
    def formatted_niit(self) -> str:
        """Formatted NIIT (Net Investment Income Tax)."""
        return f"${(self.niit or 0):,.0f}"
    
    @rx.var
    def formatted_suspended_passive_loss(self) -> str:
        """Formatted suspended passive loss (carryforward to future years)."""
        return f"${(self.suspended_passive_loss or 0):,.0f}"
    
    @rx.var
    def formatted_rental_before_limit(self) -> str:
        """Formatted rental income before passive loss limits."""
        return f"${(self.rental_income_before_passive_limit or 0):,.0f}"
    
    @rx.var
    def formatted_child_tax_credit(self) -> str:
        """Formatted child tax credit."""
        return f"${(self.child_tax_credit or 0):,.0f}"
    
    @rx.var
    def formatted_other_credits(self) -> str:
        """Formatted other credits."""
        other = (self.other_dependent_credit or 0) + (self.child_care_credit or 0)
        return f"${other:,.0f}"
    
    @rx.var
    def formatted_total_credits(self) -> str:
        """Formatted total credits."""
        return f"${(self.total_credits or 0):,.0f}"
    
    @rx.var
    def formatted_w2_withholding(self) -> str:
        """Formatted W-2 withholding."""
        w2_withholding = sum(float(w.get("federal_withheld", 0) or 0) for w in self.w2_list)
        return f"${w2_withholding:,.0f}"
    
    @rx.var
    def formatted_1099_withholding(self) -> str:
        """Formatted 1099 withholding."""
        withholding = sum(float(f.get("federal_withheld", 0) or 0) for f in self.form_1099_list)
        return f"${withholding:,.0f}"
    
    @rx.var
    def formatted_other_withholding(self) -> str:
        """Formatted other withholding."""
        return f"${(self.other_withholding or 0):,.0f}"
    
    @rx.var
    def cache_stats_documents_processed(self) -> int:
        """Number of processed documents."""
        return len([d for d in self.parsed_documents if d["status"] == "parsed"])
    
    @rx.var
    def cache_stats_personal_info_complete(self) -> bool:
        """Whether personal info is complete."""
        return self.count_personal_info_fields() > 0
    
    @rx.var
    def cache_stats_w2_count(self) -> int:
        """Number of W-2 forms."""
        return len(self.w2_list)
    
    @rx.var
    def cache_stats_form_1099_count(self) -> int:
        """Number of 1099 forms."""
        return len(self.form_1099_list)
    
    @rx.var
    def cache_stats_total_entries(self) -> int:
        """Total data entries."""
        return len([d for d in self.parsed_documents if d["status"] == "parsed"]) + len(self.w2_list) + len(self.form_1099_list)
    
    # ===== AMT Computed Properties =====
    @rx.var
    def has_amt(self) -> bool:
        """Whether AMT applies (AMT > regular tax)."""
        return (self.amt_owed or 0) > 0
    
    @rx.var
    def formatted_amt_owed(self) -> str:
        """Formatted AMT owed."""
        return f"${self.amt_owed:,.0f}" if self.amt_owed else "$0"
    
    @rx.var
    def formatted_iso_preference(self) -> str:
        """Formatted ISO AMT preference amount."""
        return f"${self.iso_amt_preference:,.0f}" if self.iso_amt_preference else "$0"
    
    @rx.var
    def formatted_amt_income(self) -> str:
        """Formatted Alternative Minimum Taxable Income."""
        return f"${self.amt_income:,.0f}" if self.amt_income else "$0"
    
    @rx.var
    def total_iso_spread(self) -> float:
        """Total ISO spread for display."""
        return sum(
            (iso.get("fmv_at_exercise", 0) - iso.get("exercise_price", 0)) * iso.get("shares", 0)
            for iso in self.iso_exercises
            if not iso.get("sold", False)
        )
    
    @rx.var
    def has_iso_exercises(self) -> bool:
        """Whether there are any ISO exercises."""
        return len(self.iso_exercises) > 0
    
    # ===== RSU Computed Properties =====
    @rx.var
    def has_rsu_vests(self) -> bool:
        """Whether there are any RSU vests tracked."""
        return len(self.rsu_vests) > 0
    
    @rx.var
    def total_rsu_basis_available(self) -> float:
        """Total cost basis available from RSU vests."""
        return sum(
            v.get("shares_remaining", v.get("shares", 0)) * v.get("fmv_per_share", 0)
            for v in self.rsu_vests
        )
    
    @rx.var
    def formatted_rsu_basis(self) -> str:
        """Formatted total RSU basis available."""
        total = sum(
            v.get("shares_remaining", v.get("shares", 0)) * v.get("fmv_per_share", 0)
            for v in self.rsu_vests
        )
        return f"${total:,.0f}"
    
    # ===== ESPP Computed Properties =====
    @rx.var
    def has_espp_purchases(self) -> bool:
        """Whether there are any ESPP purchases tracked."""
        return len(self.espp_purchases) > 0
    
    @rx.var
    def total_espp_discount(self) -> float:
        """Total ESPP discount (bargain element) across all purchases."""
        return sum(p.get("total_discount", 0) for p in self.espp_purchases)
    
    @rx.var
    def formatted_espp_discount(self) -> str:
        """Formatted total ESPP discount."""
        total = sum(p.get("total_discount", 0) for p in self.espp_purchases)
        return f"${total:,.0f}"
    
    # ===== Dependent Care Benefits Computed Properties =====
    @rx.var
    def total_dependent_care_benefits(self) -> float:
        """Total dependent care benefits from all W-2s (Box 10)."""
        return sum(w.get("dependent_care_benefits", 0) for w in self.w2_list)
    
    # ===== 529 Plan Computed Properties =====
    @rx.var
    def has_529_distributions(self) -> bool:
        """Whether there are any 529 distributions."""
        return len(self.distributions_529) > 0
    
    @rx.var
    def taxable_529_earnings(self) -> float:
        """Taxable earnings from non-qualified 529 distributions."""
        return sum(
            d.get("earnings", 0) for d in self.distributions_529
            if not d.get("is_qualified", True)
        )
    
    @rx.var
    def penalty_529(self) -> float:
        """10% penalty on non-qualified 529 earnings."""
        return self.taxable_529_earnings * 0.10
    
    # ===== 1099-R Computed Properties =====
    @rx.var
    def has_1099r(self) -> bool:
        """Whether there are any 1099-R distributions."""
        return len(self.form_1099r_list) > 0
    
    @rx.var
    def total_retirement_income(self) -> float:
        """Total taxable retirement income."""
        return sum(r.get("taxable_amount", 0) for r in self.form_1099r_list)
    
    @rx.var
    def early_withdrawal_penalty(self) -> float:
        """10% early withdrawal penalty."""
        return sum(
            r.get("taxable_amount", 0) * 0.10 for r in self.form_1099r_list
            if r.get("is_early", False)
        )
