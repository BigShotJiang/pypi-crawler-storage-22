"""
TaxSnapPro Core Tax Calculator - Standalone tax calculation module.

This module contains pure tax calculation logic without Reflex dependencies.
Used for testing and validation.
"""

from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field

from .config import (
    TAX_CONSTANTS_2024, 
    PASSIVE_LOSS_ALLOWANCE, 
    PASSIVE_LOSS_PHASEOUT,
    CAPITAL_LOSS_LIMIT,
    SALT_CAP,
)


def calculate_passive_loss_allowance(
    preliminary_income: float,
    filing_status: str,
    total_passive_loss: float
) -> tuple[float, float]:
    """
    Calculate allowed passive rental loss under the $25k special allowance.
    
    IRS allows up to $25,000 of rental real estate losses to offset other income
    for active participants, subject to phase-out based on modified AGI.
    
    Args:
        preliminary_income: Modified AGI (or approximation) for phase-out calculation
        filing_status: Tax filing status
        total_passive_loss: Total passive loss amount (positive number)
    
    Returns:
        tuple: (allowed_loss, suspended_loss)
            - allowed_loss: Amount allowed to deduct this year
            - suspended_loss: Amount suspended to future years
    
    Reference: IRS Publication 527, Active Participation
    """
    # Determine base allowance and phase-out thresholds
    is_mfs = filing_status == "married_filing_separately"
    
    base_allowance = (PASSIVE_LOSS_ALLOWANCE["married_filing_separately"] 
                     if is_mfs else PASSIVE_LOSS_ALLOWANCE["base"])
    
    phaseout_start = (PASSIVE_LOSS_PHASEOUT["start_mfs"] 
                     if is_mfs else PASSIVE_LOSS_PHASEOUT["start"])
    
    phaseout_end = (PASSIVE_LOSS_PHASEOUT["end_mfs"] 
                   if is_mfs else PASSIVE_LOSS_PHASEOUT["end"])
    
    # Calculate allowance after phase-out
    if preliminary_income <= phaseout_start:
        allowance = base_allowance
    elif preliminary_income >= phaseout_end:
        allowance = 0
    else:
        # Reduction: $0.50 per $1 over start threshold
        reduction = (preliminary_income - phaseout_start) * PASSIVE_LOSS_PHASEOUT["reduction_rate"]
        allowance = max(0, base_allowance - reduction)
    
    # Allowed loss is lesser of actual loss or allowance
    allowed_loss = min(total_passive_loss, allowance)
    suspended_loss = total_passive_loss - allowed_loss
    
    return allowed_loss, suspended_loss


@dataclass
class TaxCalculationResult:
    """Result of tax calculation."""
    # Income
    total_wages: float = 0
    total_medicare_wages: float = 0
    total_interest: float = 0
    total_dividends: float = 0
    qualified_dividends: float = 0
    short_term_capital_gains: float = 0
    long_term_capital_gains: float = 0
    total_capital_gains: float = 0
    total_rental_income: float = 0
    total_business_income: float = 0
    total_other_income: float = 0
    total_income: float = 0
    
    # Adjustments
    hsa_deduction: float = 0
    se_deduction: float = 0
    total_adjustments: float = 0
    
    # AGI and deductions
    adjusted_gross_income: float = 0
    standard_deduction: float = 0
    itemized_deductions: float = 0
    total_deductions: float = 0
    qbi_deduction: float = 0
    taxable_income: float = 0
    
    # Taxes
    ordinary_tax: float = 0
    capital_gains_tax: float = 0
    additional_medicare_tax: float = 0
    net_investment_income_tax: float = 0
    self_employment_tax: float = 0
    total_tax: float = 0
    
    # Withholding
    total_withholding: float = 0
    refund_or_owe: float = 0
    
    # Other
    effective_rate: float = 0
    suspended_passive_loss: float = 0
    capital_loss_carryover_next: float = 0
    iso_bargain_element: float = 0
    amt_income: float = 0
    amt_tax: float = 0
    amt_depreciation_adjustment: float = 0
    amt_passive_adjustment: float = 0


def calculate_tax(income: float, brackets: List[tuple]) -> float:
    """Calculate tax using progressive brackets."""
    tax = 0
    prev_bracket = 0
    
    for bracket, rate in brackets:
        if income <= bracket:
            tax += (income - prev_bracket) * rate
            break
        tax += (bracket - prev_bracket) * rate
        prev_bracket = bracket
    
    return round(tax, 2)


def calculate_preferential_tax(ordinary_income: float, preferential_income: float, 
                               cg_brackets: List[tuple]) -> float:
    """Calculate tax on preferential income (qualified dividends + long-term capital gains)."""
    if preferential_income <= 0:
        return 0
    
    # Preferential income "stacks" on top of ordinary income
    # Find the rate that applies at each income level
    tax = 0
    running_total = ordinary_income
    remaining_preferential = preferential_income
    
    prev_bracket = 0
    for bracket, rate in cg_brackets:
        if running_total >= bracket:
            prev_bracket = bracket
            continue
        
        # How much preferential income fits in this bracket?
        room_in_bracket = bracket - max(running_total, prev_bracket)
        taxable_at_this_rate = min(remaining_preferential, room_in_bracket)
        
        tax += taxable_at_this_rate * rate
        remaining_preferential -= taxable_at_this_rate
        running_total += taxable_at_this_rate
        
        if remaining_preferential <= 0:
            break
        
        prev_bracket = bracket
    
    return round(tax, 2)


def calculate_taxes(inputs: Dict[str, Any]) -> TaxCalculationResult:
    """
    Calculate all taxes based on input data.
    
    inputs should contain:
    - filing_status: str
    - w2_list: list of W-2 data
    - form_1099_list: list of 1099 data
    - form_1098_list: list of 1098 data
    - form_5498_list: list of 5498-SA data
    - rental_properties: list of rental property data
    - business_income: list of Schedule C data
    - other_income: list of other income
    - other_deductions: list of other deductions
    """
    result = TaxCalculationResult()
    
    filing_status = inputs.get("filing_status", "married_filing_jointly")
    
    # ===== INCOME =====
    
    # W-2 Wages
    w2_list = inputs.get("w2_list", [])
    result.total_wages = sum(w.get("wages", 0) for w in w2_list)
    result.total_medicare_wages = sum(
        w.get("medicare_wages", 0) or w.get("wages", 0) for w in w2_list
    )
    result.total_withholding = sum(w.get("federal_withheld", 0) for w in w2_list)
    
    employer_hsa = sum(w.get("hsa_employer_contribution", 0) for w in w2_list)
    
    # 1099 forms
    form_1099_list = inputs.get("form_1099_list", [])
    
    # Interest (1099-INT)
    result.total_interest = sum(
        f.get("amount", 0) for f in form_1099_list if f.get("form_type") == "1099-INT"
    )
    
    # Dividends (1099-DIV)
    result.total_dividends = sum(
        f.get("amount", 0) for f in form_1099_list if f.get("form_type") == "1099-DIV"
    )
    result.qualified_dividends = sum(
        f.get("qualified_dividends", 0) for f in form_1099_list if f.get("form_type") == "1099-DIV"
    )
    result.qualified_dividends = min(result.qualified_dividends, result.total_dividends)
    
    # Capital gains (1099-B)
    result.short_term_capital_gains = sum(
        f.get("amount", 0) for f in form_1099_list 
        if f.get("form_type") == "1099-B" and f.get("is_short_term", False)
    )
    result.long_term_capital_gains = sum(
        f.get("amount", 0) for f in form_1099_list 
        if f.get("form_type") == "1099-B" and not f.get("is_short_term", False)
    )
    result.total_capital_gains = result.short_term_capital_gains + result.long_term_capital_gains
    
    # Withholding from 1099s
    result.total_withholding += sum(f.get("federal_withheld", 0) for f in form_1099_list)
    
    # Rental income
    rental_properties = inputs.get("rental_properties", [])
    rental_raw = sum(p.get("net_income", 0) for p in rental_properties)
    
    # Check if real estate professional (can deduct all losses)
    is_re_professional = inputs.get("is_real_estate_professional", False)
    
    # Apply passive loss limits
    if rental_raw >= 0:
        result.total_rental_income = rental_raw
    elif is_re_professional:
        # Real estate professional can deduct all rental losses
        result.total_rental_income = rental_raw
        result.suspended_passive_loss = 0
    else:
        # Use centralized passive loss allowance calculation
        preliminary_income = result.total_wages + result.total_interest + result.total_dividends
        allowed_loss, suspended_loss = calculate_passive_loss_allowance(
            preliminary_income, filing_status, abs(rental_raw)
        )
        result.total_rental_income = -allowed_loss
        result.suspended_passive_loss = suspended_loss
    
    # Business income
    business_income = inputs.get("business_income", [])
    result.total_business_income = sum(b.get("net_profit", 0) for b in business_income)
    
    # Other income
    other_income = inputs.get("other_income", [])
    result.total_other_income = sum(i.get("amount", 0) for i in other_income)
    
    # ===== SELF-EMPLOYMENT TAX =====
    if result.total_business_income > 0:
        se_taxable = result.total_business_income * 0.9235
        ss_wage_base = TAX_CONSTANTS_2024["social_security_wage_base"]
        ss_portion = min(se_taxable, ss_wage_base) * 0.124
        medicare_portion = se_taxable * 0.029
        result.self_employment_tax = round(ss_portion + medicare_portion, 2)
        result.se_deduction = round(result.self_employment_tax / 2, 2)
    
    # ===== CAPITAL LOSS CARRYOVER =====
    # Apply prior year capital loss carryover
    prior_loss_short = inputs.get("capital_loss_carryover_short", 0)
    prior_loss_long = inputs.get("capital_loss_carryover_long", 0)
    
    # Net current year gains against carryover
    net_short = result.short_term_capital_gains - prior_loss_short
    net_long = result.long_term_capital_gains - prior_loss_long
    
    # If one category has excess loss, apply to other
    if net_short < 0 and net_long > 0:
        net_long = net_long + net_short
        net_short = 0
    elif net_long < 0 and net_short > 0:
        net_short = net_short + net_long
        net_long = 0
    
    net_capital = net_short + net_long
    
    # ===== TOTAL INCOME =====
    # Capital loss limited to $3k per year
    capital_for_income = max(-CAPITAL_LOSS_LIMIT, net_capital)
    
    # Track carryover to next year
    if net_capital < -CAPITAL_LOSS_LIMIT:
        result.capital_loss_carryover_next = abs(net_capital) - CAPITAL_LOSS_LIMIT
    
    # Update the gains for tax calculation
    result.short_term_capital_gains = max(0, net_short)
    result.long_term_capital_gains = max(0, net_long)
    result.total_capital_gains = result.short_term_capital_gains + result.long_term_capital_gains
    
    result.total_income = (
        result.total_wages + result.total_interest + result.total_dividends +
        capital_for_income + result.total_rental_income + 
        result.total_business_income + result.total_other_income
    )
    
    # ===== ADJUSTMENTS =====
    
    # HSA deduction
    form_5498_list = inputs.get("form_5498_list", [])
    total_hsa = sum(f.get("contribution", 0) for f in form_5498_list)
    result.hsa_deduction = max(0, total_hsa - employer_hsa)
    
    # Other deductions (above-the-line)
    other_deductions = inputs.get("other_deductions", [])
    manual_deductions = sum(d.get("amount", 0) for d in other_deductions)
    
    result.total_adjustments = result.hsa_deduction + result.se_deduction + manual_deductions
    
    # ===== AGI =====
    result.adjusted_gross_income = max(0, result.total_income - result.total_adjustments)
    
    # ===== DEDUCTIONS =====
    
    # Mortgage interest and property tax from 1098
    form_1098_list = inputs.get("form_1098_list", [])
    mortgage_interest = sum(
        f.get("mortgage_interest", 0) + f.get("points_paid", 0) for f in form_1098_list
    )
    property_taxes = sum(f.get("property_taxes", 0) for f in form_1098_list)
    
    # SALT cap
    salt = min(property_taxes, SALT_CAP)
    
    result.itemized_deductions = mortgage_interest + salt
    result.standard_deduction = TAX_CONSTANTS_2024["standard_deduction"].get(filing_status, 14600)
    result.total_deductions = max(result.standard_deduction, result.itemized_deductions)
    
    # ===== QBI DEDUCTION =====
    qbi = result.total_business_income + result.total_rental_income
    if qbi > 0:
        qbi_thresholds = {
            "single": (191950, 241950),
            "married_filing_jointly": (383900, 483900),
            "married_filing_separately": (191950, 241950),
            "head_of_household": (191950, 241950),
            "qualifying_widow": (383900, 483900),
        }
        threshold_start, threshold_end = qbi_thresholds.get(filing_status, (191950, 241950))
        pre_qbi_taxable = result.adjusted_gross_income - result.total_deductions
        tentative_qbi = qbi * 0.20
        
        if pre_qbi_taxable <= threshold_start:
            result.qbi_deduction = tentative_qbi
        elif pre_qbi_taxable >= threshold_end:
            result.qbi_deduction = 0
        else:
            phase_out_pct = (pre_qbi_taxable - threshold_start) / (threshold_end - threshold_start)
            result.qbi_deduction = tentative_qbi * (1 - phase_out_pct)
    
    # ===== TAXABLE INCOME =====
    result.taxable_income = max(0, 
        result.adjusted_gross_income - result.total_deductions - result.qbi_deduction
    )
    
    # ===== TAX CALCULATION =====
    
    brackets = TAX_CONSTANTS_2024["brackets"].get(filing_status, TAX_CONSTANTS_2024["brackets"]["single"])
    cg_brackets = TAX_CONSTANTS_2024["capital_gains_brackets"].get(
        filing_status, TAX_CONSTANTS_2024["capital_gains_brackets"]["single"]
    )
    
    # Preferential income
    preferential_income = result.qualified_dividends + max(0, result.long_term_capital_gains)
    ordinary_income = max(0, result.taxable_income - preferential_income)
    
    # Ordinary tax
    result.ordinary_tax = calculate_tax(ordinary_income, brackets)
    
    # Capital gains tax
    result.capital_gains_tax = calculate_preferential_tax(ordinary_income, preferential_income, cg_brackets)
    
    # Additional Medicare Tax (0.9% over threshold)
    medicare_threshold = TAX_CONSTANTS_2024["medicare_additional_threshold"].get(filing_status, 200000)
    medicare_wages = result.total_medicare_wages if result.total_medicare_wages > 0 else result.total_wages
    if medicare_wages > medicare_threshold:
        result.additional_medicare_tax = round((medicare_wages - medicare_threshold) * 0.009, 2)
    
    # NIIT (3.8% on investment income)
    niit_threshold = TAX_CONSTANTS_2024["niit_threshold"].get(filing_status, 200000)
    net_investment = result.total_interest + result.total_dividends + max(0, result.total_capital_gains)
    excess_agi = max(0, result.adjusted_gross_income - niit_threshold)
    niit_base = min(net_investment, excess_agi)
    result.net_investment_income_tax = round(niit_base * 0.038, 2)
    
    # ===== AMT CALCULATION (Form 6251) =====
    # Step 1: Calculate AMTI (Alternative Minimum Taxable Income)
    # Start with taxable income, then add back AMT preference items
    
    # AMT Adjustments (Form 6251 Part I)
    amt_adjustments = 0
    
    # Line 2a: State and local taxes (add back SALT deduction)
    # If itemized, SALT was deducted - add it back for AMT
    if result.itemized_deductions > result.standard_deduction:
        # We capped SALT at $10k, so add back up to $10k
        form_1098_list = inputs.get("form_1098_list", [])
        property_taxes = sum(f.get("property_taxes", 0) for f in form_1098_list)
        salt_deducted = min(property_taxes, SALT_CAP)
        amt_adjustments += salt_deducted
    
    # Line 2i: Exercise of Incentive Stock Options (ISO)
    # Bargain element = (FMV at exercise - exercise price) × shares
    iso_exercises = inputs.get("iso_exercises", [])
    iso_bargain_element = sum(ex.get("bargain_element", 0) for ex in iso_exercises)
    amt_adjustments += iso_bargain_element
    result.iso_bargain_element = iso_bargain_element
    
    # Line 2l: Depreciation Adjustment (Post-1986 property)
    # Regular tax uses MACRS (27.5 years for residential rental)
    # AMT uses ADS (40 years for residential rental)
    # Adjustment = Regular depreciation - AMT depreciation
    depreciation_adjustment = 0
    rental_properties = inputs.get("rental_properties", [])
    for prop in rental_properties:
        # Get depreciation info if provided
        regular_depreciation = prop.get("depreciation", 0)
        building_cost = prop.get("building_cost", 0)  # Cost basis excluding land
        
        if regular_depreciation > 0 and building_cost > 0:
            # Regular: 27.5 years straight-line
            # AMT: 40 years straight-line
            amt_depreciation = building_cost / 40
            depreciation_adjustment += (regular_depreciation - amt_depreciation)
        elif regular_depreciation > 0:
            # Estimate: AMT depreciation is roughly 27.5/40 = 68.75% of regular
            amt_depreciation = regular_depreciation * (27.5 / 40)
            depreciation_adjustment += (regular_depreciation - amt_depreciation)
    
    amt_adjustments += max(0, depreciation_adjustment)  # Only positive adjustments
    result.amt_depreciation_adjustment = depreciation_adjustment
    
    # Line 2m: Passive Activity Adjustment
    # Must recalculate passive loss limits using AMTI (before passive adjustment)
    # instead of regular AGI
    passive_adjustment = 0
    
    # Only applies if we have rental losses and used the $25k allowance
    if result.total_rental_income < 0 and not inputs.get("is_real_estate_professional", False):
        # Regular tax allowed some loss based on AGI
        regular_loss_allowed = abs(result.total_rental_income)
        
        # For AMT, recalculate using preliminary AMTI
        # AMTI before passive adjustment = taxable income + other AMT adjustments
        preliminary_amti = result.taxable_income + amt_adjustments
        
        # Total rental loss before limits
        total_rental_loss = sum(
            abs(p.get("net_income", 0)) for p in rental_properties 
            if p.get("net_income", 0) < 0
        )
        
        # Use centralized passive loss allowance calculation (with AMTI instead of AGI)
        amt_loss_allowed, _ = calculate_passive_loss_allowance(
            preliminary_amti, filing_status, total_rental_loss
        )
        
        # Passive adjustment = Regular loss allowed - AMT loss allowed
        # This adds back the disallowed portion for AMT
        if regular_loss_allowed > amt_loss_allowed:
            passive_adjustment = regular_loss_allowed - amt_loss_allowed
    
    amt_adjustments += passive_adjustment
    result.amt_passive_adjustment = passive_adjustment
    
    # AMTI = Taxable Income + AMT Adjustments
    amti = result.taxable_income + amt_adjustments
    result.amt_income = amti
    
    # Step 2: Calculate AMT Exemption (with phase-out)
    base_exemption = TAX_CONSTANTS_2024["amt_exemption"].get(filing_status, 85700)
    phaseout_start = TAX_CONSTANTS_2024["amt_phaseout_start"].get(filing_status, 609350)
    
    # Exemption reduced by 25 cents per dollar of AMTI over threshold
    if amti > phaseout_start:
        reduction = (amti - phaseout_start) * 0.25
        amt_exemption = max(0, base_exemption - reduction)
    else:
        amt_exemption = base_exemption
    
    # Step 3: AMT Base = AMTI - Exemption
    amt_base = max(0, amti - amt_exemption)
    
    # Step 4: Calculate Tentative Minimum Tax
    # 26% on first portion, 28% on rest
    amt_26_limit = TAX_CONSTANTS_2024["amt_26_percent_limit"].get(filing_status, 110350)
    
    if amt_base <= amt_26_limit:
        tentative_amt = amt_base * 0.26
    else:
        tentative_amt = (amt_26_limit * 0.26) + ((amt_base - amt_26_limit) * 0.28)
    
    # For capital gains, use lower of AMT rate or capital gains rate
    # (simplified: if we have preferential income, recalculate with cap gains rates)
    if preferential_income > 0:
        # AMT ordinary income portion
        amt_ordinary = max(0, amt_base - preferential_income)
        if amt_ordinary <= amt_26_limit:
            amt_on_ordinary = amt_ordinary * 0.26
        else:
            amt_on_ordinary = (amt_26_limit * 0.26) + ((amt_ordinary - amt_26_limit) * 0.28)
        
        # Capital gains portion at preferential rates (same as regular tax)
        amt_on_cap_gains = calculate_preferential_tax(amt_ordinary, preferential_income, cg_brackets)
        
        tentative_amt = amt_on_ordinary + amt_on_cap_gains
    
    # Step 5: AMT = max(0, Tentative AMT - Regular Tax)
    # Regular tax = ordinary tax + capital gains tax (before other taxes)
    regular_tax = result.ordinary_tax + result.capital_gains_tax
    
    if tentative_amt > regular_tax:
        result.amt_tax = round(tentative_amt - regular_tax, 2)
    else:
        result.amt_tax = 0
    
    # ===== TOTAL TAX =====
    # Regular tax + AMT + Additional Medicare + NIIT + SE Tax
    result.total_tax = round(
        result.ordinary_tax + result.capital_gains_tax + result.amt_tax +
        result.additional_medicare_tax + result.net_investment_income_tax +
        result.self_employment_tax, 2
    )
    
    # ===== REFUND/OWE =====
    result.refund_or_owe = round(result.total_withholding - result.total_tax, 2)
    
    # ===== EFFECTIVE RATE =====
    if result.total_income > 0:
        result.effective_rate = round(result.total_tax / result.total_income * 100, 2)
    
    return result
