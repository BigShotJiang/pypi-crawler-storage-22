"""
Natural Language Tax Input Parser

Converts free-form text into structured tax entries.
Supports multiple languages (English, Chinese) and various input styles.

Examples:
- "W2 wages $275,000, federal withheld $50,000"
- "我去年房贷利息 $106,450，贷款余额 160 万"
- "1099-INT from Chase Bank: $1,234 interest"
"""

import json
import re
from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict, Any
from decimal import Decimal

# Try to import LLM libraries
try:
    import openai
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False

try:
    import anthropic
    HAS_ANTHROPIC = True
except ImportError:
    HAS_ANTHROPIC = False


@dataclass
class ParsedTaxEntry:
    """A single parsed tax entry from natural language."""
    form_type: str  # W2, 1099-INT, 1099-DIV, 1098, etc.
    fields: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.0  # 0.0 to 1.0
    schedule: str = ""  # A, B, C, D, E, SE, or empty
    notes: str = ""  # Any clarifications or warnings
    raw_text: str = ""  # Original text that was parsed
    
    @property
    def summary(self) -> str:
        """Generate a human-readable summary of the entry."""
        parts = []
        for k, v in self.fields.items():
            if isinstance(v, (int, float)) and v > 0:
                parts.append(f"{k}: ${v:,.0f}")
            elif v and isinstance(v, str):
                parts.append(f"{k}: {v}")
        return " | ".join(parts[:3])  # Show first 3 fields
    
    def to_dict(self) -> Dict:
        d = asdict(self)
        d["summary"] = self.summary
        return d


@dataclass 
class ParseResult:
    """Result of parsing natural language tax input."""
    entries: List[ParsedTaxEntry] = field(default_factory=list)
    unparsed_text: str = ""  # Parts that couldn't be parsed
    suggestions: List[str] = field(default_factory=list)  # Follow-up questions
    error: Optional[str] = None


# Schema for LLM to follow
TAX_ENTRY_SCHEMA = """
{
  "entries": [
    {
      "form_type": "W2 | 1099-INT | 1099-DIV | 1099-B | 1098 | 1099-NEC | 1099-MISC | 1099-R | 5498-SA | RENTAL | BUSINESS | OTHER",
      "fields": {
        // For W2:
        "employer_name": "string",
        "wages": number,
        "federal_withheld": number,
        "state_withheld": number,
        "social_security_wages": number,
        "medicare_wages": number,
        
        // For 1099-INT:
        "payer_name": "string",
        "interest": number,
        
        // For 1099-DIV:
        "payer_name": "string",
        "ordinary_dividends": number,
        "qualified_dividends": number,
        
        // For 1098:
        "lender_name": "string",
        "mortgage_interest": number,
        "loan_balance": number,
        "origination_date": "YYYY or 'pre-2018' or 'post-2017'",
        "property_type": "primary | rental",
        "property_address": "string (optional)",
        
        // For 1099-B:
        "broker_name": "string",
        "proceeds": number,
        "cost_basis": number,
        "gain_loss": number,
        "holding_period": "short-term | long-term",
        
        // For RENTAL:
        "property_address": "string",
        "rent_income": number,
        "mortgage_interest": number,
        "property_tax": number,
        "insurance": number,
        "repairs": number,
        "depreciation": number,
        
        // For BUSINESS (Schedule C):
        "business_name": "string",
        "gross_income": number,
        "expenses": number
      },
      "confidence": 0.0-1.0,
      "schedule": "A | B | C | D | E | SE | empty",
      "notes": "any warnings or clarifications"
    }
  ],
  "unparsed_text": "parts that couldn't be understood",
  "suggestions": ["follow-up questions to clarify ambiguous input"]
}
"""

SYSTEM_PROMPT = f"""You are a tax document parser. Convert natural language input into structured tax data.

IMPORTANT RULES:
1. Extract ALL tax-relevant information from the input
2. Use appropriate form types (W2, 1099-INT, 1098, etc.)
3. For mortgage interest:
   - If property is PRIMARY RESIDENCE → schedule: "A"
   - If property is RENTAL → schedule: "E"
   - Capture loan_balance if mentioned (important for $750K limit)
   - Note if loan is pre-2018 (grandfathered $1M limit) or post-2017 ($750K limit)
4. Convert Chinese numerals: 万 = 10,000, 十万 = 100,000
5. Handle both English and Chinese input
6. Set confidence based on how clear the input is (0.0-1.0)
7. If something is ambiguous, add it to "suggestions" for follow-up

OUTPUT FORMAT (JSON only, no markdown):
{TAX_ENTRY_SCHEMA}

EXAMPLES:

Input: "W2 工资 275000，联邦税扣了 50000"
Output: {{"entries": [{{"form_type": "W2", "fields": {{"wages": 275000, "federal_withheld": 50000}}, "confidence": 0.95, "schedule": "", "notes": ""}}], "unparsed_text": "", "suggestions": ["What is the employer name?", "Any state tax withheld?"]}}

Input: "房贷利息 $106,450，贷款余额 160 万，2023 年 refinance"
Output: {{"entries": [{{"form_type": "1098", "fields": {{"mortgage_interest": 106450, "loan_balance": 1600000, "origination_date": "2023", "property_type": "primary"}}, "confidence": 0.9, "schedule": "A", "notes": "Post-2017 loan: $750K acquisition debt limit applies"}}], "unparsed_text": "", "suggestions": ["What is the lender name?"]}}

Input: "出租房 21 Hall St 收租 $54000，房贷利息 $11,252"
Output: {{"entries": [{{"form_type": "RENTAL", "fields": {{"property_address": "21 Hall St", "rent_income": 54000, "mortgage_interest": 11252}}, "confidence": 0.95, "schedule": "E", "notes": ""}}], "unparsed_text": "", "suggestions": ["Any other rental expenses (property tax, insurance, repairs)?"]}}
"""


def parse_with_openai(text: str, api_key: str, model: str = "gpt-4o-mini") -> ParseResult:
    """Parse tax input using OpenAI."""
    if not HAS_OPENAI:
        return ParseResult(error="OpenAI library not installed. Run: pip install openai")
    
    client = openai.OpenAI(api_key=api_key)
    
    try:
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": text}
            ],
            response_format={"type": "json_object"},
            temperature=0.1,
        )
        
        result_json = json.loads(response.choices[0].message.content)
        return _parse_response(result_json, text)
        
    except Exception as e:
        return ParseResult(error=f"OpenAI API error: {str(e)}")


def parse_with_anthropic(text: str, api_key: str, model: str = "claude-3-5-haiku-20241022") -> ParseResult:
    """Parse tax input using Anthropic Claude."""
    if not HAS_ANTHROPIC:
        return ParseResult(error="Anthropic library not installed. Run: pip install anthropic")
    
    client = anthropic.Anthropic(api_key=api_key)
    
    try:
        response = client.messages.create(
            model=model,
            max_tokens=2000,
            system=SYSTEM_PROMPT,
            messages=[
                {"role": "user", "content": text}
            ]
        )
        
        # Extract JSON from response
        content = response.content[0].text
        # Handle potential markdown code blocks
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0]
        elif "```" in content:
            content = content.split("```")[1].split("```")[0]
        
        result_json = json.loads(content.strip())
        return _parse_response(result_json, text)
        
    except Exception as e:
        return ParseResult(error=f"Anthropic API error: {str(e)}")


def _parse_response(result_json: Dict, original_text: str) -> ParseResult:
    """Convert JSON response to ParseResult."""
    entries = []
    
    for entry_data in result_json.get("entries", []):
        entry = ParsedTaxEntry(
            form_type=entry_data.get("form_type", "OTHER"),
            fields=entry_data.get("fields", {}),
            confidence=float(entry_data.get("confidence", 0.5)),
            schedule=entry_data.get("schedule", ""),
            notes=entry_data.get("notes", ""),
            raw_text=original_text
        )
        entries.append(entry)
    
    return ParseResult(
        entries=entries,
        unparsed_text=result_json.get("unparsed_text", ""),
        suggestions=result_json.get("suggestions", [])
    )


def parse_tax_input(
    text: str,
    api_key: str,
    provider: str = "anthropic",  # "openai" or "anthropic"
    model: Optional[str] = None
) -> ParseResult:
    """
    Parse natural language tax input into structured data.
    
    Args:
        text: Natural language description of tax information
        api_key: API key for the LLM provider
        provider: "openai" or "anthropic"
        model: Optional model override
    
    Returns:
        ParseResult with structured tax entries
    """
    if not text.strip():
        return ParseResult(error="Empty input")
    
    if provider == "openai":
        return parse_with_openai(text, api_key, model or "gpt-4o-mini")
    elif provider == "anthropic":
        return parse_with_anthropic(text, api_key, model or "claude-3-5-haiku-20241022")
    else:
        return ParseResult(error=f"Unknown provider: {provider}")


# Quick regex-based parsing for simple cases (no LLM needed)
def quick_parse(text: str) -> Optional[ParseResult]:
    """
    Try to parse simple, well-formatted input without LLM.
    Returns None if input is too complex for quick parsing.
    """
    entries = []
    
    # Pattern: W2 wages $XXX
    w2_pattern = r'[Ww]-?2.*?(?:wages?|工资|salary).*?\$?([\d,]+)'
    w2_match = re.search(w2_pattern, text)
    if w2_match:
        wages = float(w2_match.group(1).replace(',', ''))
        
        # Look for federal withheld
        fed_pattern = r'(?:federal|联邦|fed).*?(?:withheld|withholding|扣|tax).*?\$?([\d,]+)'
        fed_match = re.search(fed_pattern, text, re.IGNORECASE)
        fed_withheld = float(fed_match.group(1).replace(',', '')) if fed_match else 0
        
        entries.append(ParsedTaxEntry(
            form_type="W2",
            fields={"wages": wages, "federal_withheld": fed_withheld},
            confidence=0.8,
            notes="Quick parse (no LLM)"
        ))
    
    # Pattern: 1099-INT interest $XXX
    int_pattern = r'1099-?INT.*?\$?([\d,]+)'
    int_match = re.search(int_pattern, text, re.IGNORECASE)
    if int_match:
        interest = float(int_match.group(1).replace(',', ''))
        entries.append(ParsedTaxEntry(
            form_type="1099-INT",
            fields={"interest": interest},
            confidence=0.7,
            schedule="B",
            notes="Quick parse (no LLM)"
        ))
    
    # Pattern: mortgage interest / 房贷利息 $XXX
    mortgage_pattern = r'(?:mortgage|房贷|1098).*?(?:interest|利息).*?\$?([\d,]+)'
    mortgage_match = re.search(mortgage_pattern, text, re.IGNORECASE)
    if mortgage_match:
        interest = float(mortgage_match.group(1).replace(',', ''))
        
        # Look for loan balance (支持 "160万" / "160 万" / "$1,600,000")
        loan_balance = 0
        # Try Chinese format first: 余额 160 万 or 贷款余额160万
        cn_balance = re.search(r'(?:余额|贷款|balance)\D*([\d.]+)\s*万', text)
        if cn_balance:
            loan_balance = float(cn_balance.group(1)) * 10000
        else:
            # Try dollar format: $1,600,000 or 1600000
            dollar_balance = re.search(r'(?:balance|余额|principal)\D*\$?([\d,]+)', text, re.IGNORECASE)
            if dollar_balance:
                loan_balance = float(dollar_balance.group(1).replace(',', ''))
        
        # Check if rental
        is_rental = bool(re.search(r'(?:rental|出租|rent)', text, re.IGNORECASE))
        
        entries.append(ParsedTaxEntry(
            form_type="1098" if not is_rental else "RENTAL",
            fields={
                "mortgage_interest": interest,
                "loan_balance": loan_balance,
                "property_type": "rental" if is_rental else "primary"
            },
            confidence=0.7,
            schedule="E" if is_rental else "A",
            notes="Quick parse (no LLM)"
        ))
    
    if entries:
        return ParseResult(entries=entries)
    
    return None  # Input too complex, needs LLM


# Test function
if __name__ == "__main__":
    # Test quick parse
    test_inputs = [
        "W2 wages $275,000, federal withheld $50,000",
        "房贷利息 $106,450，贷款余额 160 万",
        "1099-INT from Chase: $1,234",
        "出租房利息 $11,252",
    ]
    
    print("=== Quick Parse Tests ===\n")
    for text in test_inputs:
        result = quick_parse(text)
        print(f"Input: {text}")
        if result:
            for entry in result.entries:
                print(f"  → {entry.form_type}: {entry.fields}")
                print(f"     Schedule: {entry.schedule}, Confidence: {entry.confidence}")
        else:
            print("  → Needs LLM parsing")
        print()
