# tcd2

Unofficial fork of **Twitch Chat Downloader** (the `tcd` package) by Petter Kraabøl.
This distribution keeps the CLI name `tcd` but publishes under a new name (`tcd2`) on PyPI.

## Install

```bash
pip install tcd2
```

## Usage

```bash
tcd
```

```bash
# Download chat from VODs by video id
tcd --video 789654123,987456321 --format irc --output ~/Downloads
```

```bash
# Download chat from the first 10 VODs from multiple streamers
tcd --channel sodapoppin,nymn,lirik --first=10
```

## Credits

Original project: https://github.com/PetterKraabol/Twitch-Chat-Downloader
