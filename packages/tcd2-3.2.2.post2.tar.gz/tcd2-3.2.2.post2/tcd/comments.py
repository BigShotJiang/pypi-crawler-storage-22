from typing import Iterable

from twitch.helix import Video
from twitch.v5 import Comment

from .graphql_comments import GraphQLComments


def get_comments(video: Video) -> Iterable[Comment]:
    """
    Return an iterator of comments for a video using Twitch GraphQL.
    """
    return GraphQLComments(video.id)
