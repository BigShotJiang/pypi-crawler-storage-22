from typing import Iterable

from twitch.helix import Video
from twitch.v5 import Comment

from tcd.comments import get_comments
from tcd.settings import Settings


class Format:

    def __init__(self, video: Video, format_name: str):
        self.video: Video = video
        self.format_name: str = format_name
        self.format_dictionary: dict = Settings().config['formats'][format_name]

    def comments(self) -> Iterable[Comment]:
        """
        Return an iterator for video comments using GraphQL.
        """
        return get_comments(self.video)
