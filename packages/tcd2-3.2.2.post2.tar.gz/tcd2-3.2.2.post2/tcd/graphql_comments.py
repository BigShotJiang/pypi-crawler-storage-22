"""
GraphQL-based comments module for Twitch VODs.
This replaces the deprecated V5 API with Twitch's GraphQL API.
"""
from typing import Union, Generator, Dict, Any, List
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
import twitch.v5 as v5


class GraphQLComments:
    """
    Fetches VOD comments using Twitch's GraphQL API.
    """

    GRAPHQL_ENDPOINT = 'https://gql.twitch.tv/gql'
    # Public client ID used by Twitch web
    CLIENT_ID = 'kimne78kx3ncx6brgo4mv6wki5h1ko'
    # SHA256 hash for the VideoCommentsByOffsetOrCursor persisted query
    QUERY_HASH = 'b70a3591ff0f4e0313d126c6a1502d79a1c02baebb288227c582044aa76adf6a'

    def __init__(self, video_id: Union[str, int], num_threads: int = 4):
        self._video_id: str = str(video_id)
        self._num_threads: int = num_threads
        self._session = requests.Session()
        self._session_lock = threading.Lock()

    def _graphql_request(self, variables: Dict[str, Any]) -> Dict[str, Any]:
        query = [{
            "operationName": "VideoCommentsByOffsetOrCursor",
            "variables": variables,
            "extensions": {
                "persistedQuery": {
                    "version": 1,
                    "sha256Hash": self.QUERY_HASH
                }
            }
        }]

        headers = {
            'Client-Id': self.CLIENT_ID,
            'Content-Type': 'application/json'
        }

        with self._session_lock:
            response = self._session.post(self.GRAPHQL_ENDPOINT, json=query, headers=headers)
        response.raise_for_status()
        return response.json()

    def _fetch_chunk(self, start_offset: float) -> List[Dict[str, Any]]:
        comments: List[Dict[str, Any]] = []
        variables = {
            "videoID": self._video_id,
            "contentOffsetSeconds": start_offset
        }

        try:
            response_data = self._graphql_request(variables)
            if not response_data:
                return comments

            data = response_data[0].get('data', {})
            video_data = data.get('video')
            if not video_data:
                return comments

            comments_data = video_data.get('comments')
            if not comments_data:
                return comments

            edges = comments_data.get('edges', [])
            for edge in edges:
                comments.append(self._convert_graphql_comment_to_v5_format(edge))
        except Exception as exc:
            import sys
            print(f"Error fetching chunk at offset {start_offset}: {exc}", file=sys.stderr)

        return comments

    def _convert_graphql_comment_to_v5_format(self, comment_node: Dict[str, Any]) -> Dict[str, Any]:
        comment = comment_node.get('node', {})
        commenter = comment.get('commenter', {})
        message = comment.get('message', {})

        fragments = []
        emoticons = []
        full_message_text = []

        for fragment in message.get('fragments', []):
            fragment_text = fragment.get('text', '')
            full_message_text.append(fragment_text)
            fragment_data = {'text': fragment_text}

            emote = fragment.get('emote')
            if emote:
                emoticon_data = {
                    '_id': emote.get('emoteID'),
                    'begin': len(''.join([f['text'] for f in fragments])),
                    'end': None,
                    'emoticon_id': emote.get('emoteID'),
                    'emoticon_set_id': None
                }
                emoticon_data['end'] = emoticon_data['begin'] + len(fragment_data['text'])
                emoticons.append(emoticon_data)
                fragment_data['emoticon'] = emoticon_data

            fragments.append(fragment_data)

        message_body = ''.join(full_message_text)

        user_badges = []
        for badge in message.get('userBadges', []):
            user_badges.append({
                '_id': badge.get('setID'),
                'version': badge.get('version')
            })

        v5_comment = {
            '_id': comment.get('id'),
            'created_at': comment.get('createdAt'),
            'updated_at': comment.get('updatedAt', comment.get('createdAt')),
            'channel_id': None,
            'content_type': 'video',
            'content_id': self._video_id,
            'content_offset_seconds': float(comment.get('contentOffsetSeconds', 0)),
            'commenter': {
                'display_name': commenter.get('displayName'),
                '_id': commenter.get('id'),
                'name': commenter.get('login'),
                'type': None,
                'bio': None,
                'created_at': None,
                'updated_at': None,
                'logo': None
            } if commenter else None,
            'source': 'chat',
            'state': 'published',
            'message': {
                'body': message_body,
                'emoticons': emoticons,
                'fragments': fragments,
                'is_action': False,
                'user_badges': user_badges,
                'user_color': message.get('userColor')
            },
            'more_replies': False
        }

        return v5_comment

    def __iter__(self) -> Generator['v5.Comment', None, None]:
        initial_chunk = self._fetch_chunk(0.0)
        if not initial_chunk:
            return

        chunk_interval = 3600
        all_comments: List[Dict[str, Any]] = []
        current_offset = 0.0
        max_offset = 0.0

        while True:
            chunk_offsets = []
            for i in range(self._num_threads):
                offset = current_offset + (i * chunk_interval)
                chunk_offsets.append(offset)

            chunks_data = []
            with ThreadPoolExecutor(max_workers=self._num_threads) as executor:
                future_to_offset = {
                    executor.submit(self._fetch_chunk, offset): offset
                    for offset in chunk_offsets
                }

                for future in as_completed(future_to_offset):
                    offset = future_to_offset[future]
                    try:
                        chunk_comments = future.result()
                        if chunk_comments:
                            chunks_data.append((offset, chunk_comments))
                    except Exception as exc:
                        import sys
                        print(f"Error downloading chunk at {offset}: {exc}", file=sys.stderr)

            chunks_data.sort(key=lambda x: x[0])

            got_new_data = False
            for _, chunk_comments in chunks_data:
                for comment_data in chunk_comments:
                    comment_offset = float(comment_data.get('content_offset_seconds', 0))
                    if comment_offset <= max_offset:
                        continue

                    all_comments.append(comment_data)
                    max_offset = max(max_offset, comment_offset)
                    got_new_data = True

            if not got_new_data:
                break

            current_offset = max_offset

        all_comments.sort(key=lambda x: x.get('content_offset_seconds', 0))

        from twitch.api import API
        minimal_api = API(base_url='https://api.twitch.tv/v5/',
                         client_id=self.CLIENT_ID)

        for comment_data in all_comments:
            yield v5.Comment(api=minimal_api, data=comment_data)
