# Terminus Cancrorum Est

**Purpose:** Monitor Claude Code processes, token usage, and costs. Query process health, kill stale/zombie processes, check token spend, and manage the web dashboard.

**Use when user asks to:**
- "Check my Claude processes"
- "How are my Claude processes?"
- "Any stale or zombie processes?"
- "What's my token spend / cost?"
- "How much have I spent on Claude?"
- "Kill stale Claude processes"
- "Kill process [PID]"
- "Open the monitor dashboard"
- "Start the Claude monitor"
- "Show Claude session history"
- "Which projects are using the most tokens?"

---

## CLI Commands

All commands use the `tce` entry point (installed via `pip install -e .` or `pip install tce`).

### Check Process Health

```bash
tce status
```

Returns: process count, health breakdown, per-process details (PID, project, memory, CPU, uptime, health status).

### Token Usage & Costs

```bash
tce usage
```

Returns: per-model token breakdown (input, output, cache read, cache creation), computed cost per model, total cost.

### Recent Sessions

```bash
tce sessions
```

Returns: recent sessions with project, duration, tokens, lines changed, summary.

Optional: `--limit N` (default 15)

### Kill a Process

```bash
tce kill <PID>
```

Sends SIGTERM. Add `--force` for SIGKILL.

### Kill All Stale Processes

```bash
tce kill-stale
```

Finds and kills all stale processes (SIGTERM). Reports what was killed.

### Pin / Unpin a Process

```bash
tce pin <PID>
tce unpin <PID>
```

Pinned processes are exempt from stale detection.

### Start Dashboard

```bash
tce dashboard
```

Starts the web dashboard on localhost:5111 and opens it in the browser.

### Stop Dashboard

```bash
tce dashboard-stop
```

Stops the running dashboard server.

### Run Full App

```bash
tce run
```

Runs menu bar + dashboard (macOS with rumps) or dashboard-only mode (other platforms).

---

## Response Formatting

When reporting process status to the user, format as a clear summary:

**Process Health:**
- Use health indicators: healthy, stale (idle >4h), zombie (dead process), pinned (user-exempt)
- Include PID, project name, memory (MB), uptime, health
- Highlight any stale or zombie processes prominently

**Token Usage:**
- Show per-model costs sorted by highest first
- Include total cost prominently
- Format large token counts as K/M/B

**Sessions:**
- Show project, duration, token count, lines changed, summary
- Most recent first

---

## Architecture Note

This is an installable Python package (`tce`). Install with `pip install -e .` from the project root. The `tce` CLI entry point is defined in `tce/cli.py`.
