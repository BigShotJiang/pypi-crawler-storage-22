"""macOS notification alerts for process health changes."""

import logging
import subprocess
import time

from tce.config import settings
from tce.models import ClaudeProcess, HealthStatus

logger = logging.getLogger(__name__)


class AlertService:
    """Sends macOS notifications with cooldown to prevent spam."""

    def __init__(self) -> None:
        self._last_alert: dict[int, float] = {}  # pid -> timestamp

    def _should_alert(self, pid: int) -> bool:
        """Check if enough time has passed since last alert for this PID."""
        last = self._last_alert.get(pid, 0)
        return (time.time() - last) > settings.alert_cooldown

    def _send_notification(self, title: str, message: str) -> None:
        """Send a macOS notification via osascript."""
        script = f'display notification "{message}" with title "{title}"'
        try:
            subprocess.run(
                ["osascript", "-e", script],
                capture_output=True,
                timeout=5,
            )
        except (subprocess.TimeoutExpired, OSError) as e:
            logger.warning("Failed to send notification: %s", e)

    def check_and_alert(self, processes: list[ClaudeProcess]) -> None:
        """Check processes and send alerts for stale/zombie ones."""
        for proc in processes:
            if proc.health == HealthStatus.STALE and self._should_alert(proc.pid):
                self._send_notification(
                    "Terminus Cancrorum Est — Stale Process",
                    f"PID {proc.pid} ({proc.project_name}) idle for {proc.uptime_hours:.1f}h",
                )
                self._last_alert[proc.pid] = time.time()
                logger.info("Alert: stale process PID %d (%s)", proc.pid, proc.project_name)

            elif proc.health == HealthStatus.ZOMBIE and self._should_alert(proc.pid):
                self._send_notification(
                    "Terminus Cancrorum Est — Zombie Process",
                    f"PID {proc.pid} ({proc.project_name}) is a zombie",
                )
                self._last_alert[proc.pid] = time.time()
                logger.info("Alert: zombie process PID %d (%s)", proc.pid, proc.project_name)

        # Clean up alerts for PIDs that no longer exist
        active_pids = {p.pid for p in processes}
        stale_keys = set(self._last_alert.keys()) - active_pids
        for pid in stale_keys:
            del self._last_alert[pid]
