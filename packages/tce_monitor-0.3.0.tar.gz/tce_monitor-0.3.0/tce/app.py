"""Terminus Cancrorum Est — entry point.

Runs rumps menu bar on the main thread (required by PyObjC)
and FastAPI/uvicorn as a daemon thread. Falls back to
dashboard-only mode when rumps is not available.
"""

import logging
import sys
import threading

import uvicorn

from tce.config import settings
from tce.dashboard import create_app
from tce.process_scanner import ProcessScanner
from tce.token_tracker import TokenTracker

try:
    from tce.menubar import TerminusApp
    HAS_RUMPS = True
except ImportError:
    HAS_RUMPS = False

try:
    from ai_tools import setup_logging

    setup_logging("terminus-cancrorum-est")
except ImportError:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

logger = logging.getLogger(__name__)


def run_dashboard(scanner: ProcessScanner, tracker: TokenTracker) -> None:
    """Run FastAPI dashboard in a daemon thread."""
    app = create_app(scanner, tracker)
    config = uvicorn.Config(
        app,
        host=settings.host,
        port=settings.port,
        log_level="warning",
    )
    server = uvicorn.Server(config)
    server.run()


def main() -> None:
    """Launch Terminus Cancrorum Est.

    If rumps is available (macOS with pyobjc), runs the menu bar on the main
    thread with the dashboard as a daemon thread.  Otherwise falls back to
    dashboard-only mode (uvicorn on the main thread).
    """
    logger.info("Starting Terminus Cancrorum Est on port %d", settings.port)

    scanner = ProcessScanner()
    tracker = TokenTracker()

    if HAS_RUMPS:
        # Start web dashboard as daemon thread
        dashboard_thread = threading.Thread(
            target=run_dashboard,
            args=(scanner, tracker),
            daemon=True,
            name="dashboard",
        )
        dashboard_thread.start()
        logger.info("Dashboard running at http://%s:%d", settings.host, settings.port)

        # Run menu bar on main thread (required by PyObjC/rumps)
        app = TerminusApp(scanner)
        app.run()
    else:
        logger.info(
            "rumps not available — running dashboard-only mode at http://%s:%d",
            settings.host,
            settings.port,
        )
        run_dashboard(scanner, tracker)


if __name__ == "__main__":
    main()
