"""Cost calculation for Claude API token usage."""

import logging

from tce.config import settings
from tce.models import MODEL_DISPLAY_NAMES, ModelTokenUsage

logger = logging.getLogger(__name__)


class CostCalculator:
    """Computes USD costs from token counts using model pricing tables."""

    def __init__(self) -> None:
        self._pricing = settings.pricing

    def compute_cost(
        self,
        model_id: str,
        input_tokens: int = 0,
        output_tokens: int = 0,
        cache_read_tokens: int = 0,
        cache_creation_tokens: int = 0,
    ) -> float:
        """Compute USD cost for given token counts.

        Pricing is per million tokens. Returns 0.0 for unknown models.
        """
        prices = self._pricing.get(model_id)
        if not prices:
            logger.warning("No pricing for model %s", model_id)
            return 0.0

        cost = (
            (input_tokens * prices["input"] / 1_000_000)
            + (output_tokens * prices["output"] / 1_000_000)
            + (cache_read_tokens * prices["cache_read"] / 1_000_000)
            + (cache_creation_tokens * prices["cache_creation"] / 1_000_000)
        )
        return round(cost, 4)

    def build_model_usage(self, model_usage_raw: dict) -> list[ModelTokenUsage]:
        """Build ModelTokenUsage list from stats-cache.json modelUsage data."""
        results: list[ModelTokenUsage] = []
        for model_id, data in model_usage_raw.items():
            input_tokens = data.get("inputTokens", 0)
            output_tokens = data.get("outputTokens", 0)
            cache_read = data.get("cacheReadInputTokens", 0)
            cache_creation = data.get("cacheCreationInputTokens", 0)

            cost = self.compute_cost(
                model_id,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cache_read_tokens=cache_read,
                cache_creation_tokens=cache_creation,
            )

            results.append(
                ModelTokenUsage(
                    model_id=model_id,
                    model_name=MODEL_DISPLAY_NAMES.get(model_id, model_id),
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    cache_read_tokens=cache_read,
                    cache_creation_tokens=cache_creation,
                    cost_usd=cost,
                )
            )
        return sorted(results, key=lambda m: m.cost_usd, reverse=True)
