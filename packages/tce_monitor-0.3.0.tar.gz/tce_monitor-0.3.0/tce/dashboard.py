"""FastAPI web dashboard for Terminus Cancrorum Est."""

import logging
from pathlib import Path

from fastapi import FastAPI
from fastapi.requests import Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from tce.models import HealthStatus
from tce.process_scanner import ProcessScanner
from tce.token_tracker import TokenTracker

logger = logging.getLogger(__name__)

TEMPLATES_DIR = Path(__file__).parent / "templates"
STATIC_DIR = Path(__file__).parent / "static"


def create_app(scanner: ProcessScanner, tracker: TokenTracker) -> FastAPI:
    """Create the FastAPI dashboard application."""
    app = FastAPI(title="Terminus Cancrorum Est", docs_url=None, redoc_url=None)
    templates = Jinja2Templates(directory=str(TEMPLATES_DIR))
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    @app.get("/", response_class=HTMLResponse)
    async def dashboard(request: Request):
        summary = scanner.scan()
        usage = tracker.get_dashboard()
        return templates.TemplateResponse(
            "dashboard.html",
            {
                "request": request,
                "summary": summary,
                "usage": usage,
            },
        )

    @app.get("/api/processes")
    async def api_processes():
        summary = scanner.scan()
        return summary.model_dump()

    @app.get("/api/usage")
    async def api_usage():
        usage = tracker.get_dashboard()
        return usage.model_dump()

    @app.get("/api/sessions")
    async def api_sessions(limit: int = 20):
        sessions = tracker.get_recent_sessions(limit=limit)
        return [s.model_dump() for s in sessions]

    @app.post("/api/kill/{pid}")
    async def api_kill(pid: int, force: bool = False):
        success, message = scanner.kill_process(pid, force=force)
        status_code = 200 if success else 400
        return JSONResponse(
            content={"success": success, "message": message},
            status_code=status_code,
        )

    @app.post("/api/pin/{pid}")
    async def api_pin(pid: int):
        scanner.pin(pid)
        return {"success": True, "message": f"PID {pid} pinned"}

    @app.post("/api/unpin/{pid}")
    async def api_unpin(pid: int):
        scanner.unpin(pid)
        return {"success": True, "message": f"PID {pid} unpinned"}

    return app
