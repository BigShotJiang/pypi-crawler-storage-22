"""rumps menu bar application for Terminus Cancrorum Est."""

import logging
import os
import signal
import subprocess
import sys

import rumps

from tce.alert_service import AlertService
from tce.config import settings
from tce.models import HealthStatus, ProcessSummary
from tce.process_scanner import ProcessScanner

logger = logging.getLogger(__name__)

HEALTH_ICONS = {
    HealthStatus.HEALTHY: "✅",
    HealthStatus.STALE: "🟡",
    HealthStatus.ZOMBIE: "💀",
    HealthStatus.PINNED: "📌",
}

CRAB = "🦀"


class TerminusApp(rumps.App):
    """Menu bar app showing Claude Code process status."""

    def __init__(self, scanner: ProcessScanner) -> None:
        super().__init__("Terminus Cancrorum Est", title=CRAB)
        self._scanner = scanner
        self._alert_service = AlertService()
        self._last_summary: ProcessSummary | None = None
        self._webview_proc: subprocess.Popen | None = None

    @rumps.timer(settings.process_poll_interval)
    def poll_processes(self, _sender: rumps.Timer) -> None:
        """Periodic scan of Claude processes."""
        try:
            summary = self._scanner.scan()
            self._last_summary = summary
            self._update_title(summary)
            self._update_menu(summary)
            self._alert_service.check_and_alert(summary.processes)
        except Exception as e:
            logger.error("Error during process poll: %s", e)

    def _update_title(self, summary: ProcessSummary) -> None:
        """Update menu bar title: crab + zombie count in red when present."""
        if summary.zombie > 0:
            self.title = f"{CRAB} 💀{summary.zombie}"
        elif summary.stale > 0:
            self.title = f"{CRAB} 🟡{summary.stale}"
        else:
            self.title = CRAB

    def _update_menu(self, summary: ProcessSummary) -> None:
        """Rebuild the dropdown menu with current processes."""
        self.menu.clear()

        # Open dashboard (top item for easy access)
        self.menu.add(rumps.MenuItem(
            "🌐 Open Dashboard",
            callback=self._open_dashboard,
        ))
        self.menu.add(rumps.separator)

        # Summary line
        mem_str = f"{summary.total_memory_mb:.0f}" if summary.total_memory_mb else "0"
        self.menu.add(rumps.MenuItem(
            f"{summary.total} processes | {mem_str} MB total",
            callback=None,
        ))
        self.menu.add(rumps.separator)

        # Process list
        if not summary.processes:
            self.menu.add(rumps.MenuItem("No Claude processes", callback=None))
        else:
            for proc in summary.processes:
                icon = HEALTH_ICONS.get(proc.health, "❓")
                label = (
                    f"{icon} {proc.pid} — {proc.project_name} "
                    f"({proc.memory_total_mb:.0f}MB, {proc.uptime_hours:.1f}h)"
                )
                proc_menu = rumps.MenuItem(label)

                kill_item = rumps.MenuItem(
                    f"🔪 Kill PID {proc.pid}",
                    callback=self._make_kill_callback(proc.pid),
                )
                proc_menu.add(kill_item)

                force_kill_item = rumps.MenuItem(
                    f"💀 Force Kill PID {proc.pid}",
                    callback=self._make_kill_callback(proc.pid, force=True),
                )
                proc_menu.add(force_kill_item)

                if proc.is_pinned:
                    pin_item = rumps.MenuItem(
                        f"📌 Unpin PID {proc.pid}",
                        callback=self._make_unpin_callback(proc.pid),
                    )
                else:
                    pin_item = rumps.MenuItem(
                        f"📌 Pin PID {proc.pid}",
                        callback=self._make_pin_callback(proc.pid),
                    )
                proc_menu.add(pin_item)

                self.menu.add(proc_menu)

        self.menu.add(rumps.separator)
        self.menu.add(rumps.MenuItem("🚪 Quit", callback=self._quit))

    def _open_dashboard(self, _sender: rumps.MenuItem) -> None:
        """Open the dashboard in a native webview window."""
        # Check if webview is already running
        if self._webview_proc and self._webview_proc.poll() is None:
            # Process still alive — bring to front by re-launching
            # (macOS doesn't let us raise another process's window easily)
            logger.info("Webview already running (PID %d)", self._webview_proc.pid)
            return

        # Launch webview as a subprocess (needs its own main thread on macOS)
        self._webview_proc = subprocess.Popen(
            [sys.executable, "-m", "tce.webview_window"],
            cwd=os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        )
        logger.info("Webview launched (PID %d)", self._webview_proc.pid)

    def _make_kill_callback(self, pid: int, force: bool = False):
        def callback(_sender):
            action = "force kill" if force else "kill"
            response = rumps.alert(
                title=f"Confirm {action}",
                message=f"Are you sure you want to {action} PID {pid}?",
                ok="Yes",
                cancel="No",
            )
            if response == 1:
                success, msg = self._scanner.kill_process(pid, force=force)
                if success:
                    rumps.notification("Terminus Cancrorum Est", "Process Killed", msg)
                else:
                    rumps.notification("Terminus Cancrorum Est", "Kill Failed", msg)
        return callback

    def _make_pin_callback(self, pid: int):
        def callback(_sender):
            self._scanner.pin(pid)
            rumps.notification("Terminus Cancrorum Est", "Pinned", f"PID {pid} pinned")
        return callback

    def _make_unpin_callback(self, pid: int):
        def callback(_sender):
            self._scanner.unpin(pid)
            rumps.notification("Terminus Cancrorum Est", "Unpinned", f"PID {pid} unpinned")
        return callback

    def _quit(self, _sender: rumps.MenuItem) -> None:
        """Clean up webview subprocess before quitting."""
        if self._webview_proc and self._webview_proc.poll() is None:
            try:
                os.kill(self._webview_proc.pid, signal.SIGTERM)
            except OSError:
                pass
        rumps.quit_application(_sender)
