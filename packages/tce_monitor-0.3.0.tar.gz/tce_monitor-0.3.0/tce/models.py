"""Pydantic models for Terminus Cancrorum Est."""

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field


class HealthStatus(str, Enum):
    """Process health classification."""

    HEALTHY = "healthy"
    STALE = "stale"
    ZOMBIE = "zombie"
    PINNED = "pinned"


class ClaudeProcess(BaseModel):
    """A detected Claude Code process."""

    pid: int
    exe: str = ""
    cmdline: list[str] = Field(default_factory=list)
    cwd: str = ""
    project_name: str = ""
    terminal: str = ""
    status: str = ""  # psutil status string
    health: HealthStatus = HealthStatus.HEALTHY
    cpu_percent: float = 0.0
    memory_rss_mb: float = 0.0
    memory_total_mb: float = 0.0  # including children
    child_count: int = 0
    create_time: datetime | None = None
    uptime_hours: float = 0.0
    is_pinned: bool = False


class ProcessSummary(BaseModel):
    """Summary of all Claude processes."""

    total: int = 0
    healthy: int = 0
    stale: int = 0
    zombie: int = 0
    pinned: int = 0
    total_memory_mb: float = 0.0
    processes: list[ClaudeProcess] = Field(default_factory=list)


class ModelTokenUsage(BaseModel):
    """Token usage for a single model."""

    model_id: str
    model_name: str = ""  # friendly name
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_creation_tokens: int = 0
    cost_usd: float = 0.0


class DailyTokens(BaseModel):
    """Token usage for a single day."""

    date: str
    tokens_by_model: dict[str, int] = Field(default_factory=dict)
    total_tokens: int = 0


class SessionInfo(BaseModel):
    """Summary of a Claude session from session-meta."""

    session_id: str
    project_path: str = ""
    project_name: str = ""
    start_time: datetime | None = None
    duration_minutes: float = 0.0
    input_tokens: int = 0
    output_tokens: int = 0
    summary: str = ""
    tool_counts: dict[str, int] = Field(default_factory=dict)
    lines_added: int = 0
    lines_removed: int = 0


class UsageDashboard(BaseModel):
    """Complete usage data for the dashboard."""

    model_usage: list[ModelTokenUsage] = Field(default_factory=list)
    daily_tokens: list[DailyTokens] = Field(default_factory=list)
    total_cost_usd: float = 0.0
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    total_cache_read_tokens: int = 0
    total_sessions: int = 0
    recent_sessions: list[SessionInfo] = Field(default_factory=list)


# Friendly model names
MODEL_DISPLAY_NAMES: dict[str, str] = {
    "claude-opus-4-5-20251101": "Opus 4.5",
    "claude-opus-4-6": "Opus 4.6",
    "claude-sonnet-4-5-20250929": "Sonnet 4.5",
    "claude-haiku-4-5-20251001": "Haiku 4.5",
}
