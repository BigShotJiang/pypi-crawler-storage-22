"""Claude Code process detection, health classification, and management."""

import json
import logging
import os
import signal
import time
from datetime import datetime, timezone
from pathlib import Path

import psutil

from tce.config import settings
from tce.models import ClaudeProcess, HealthStatus, ProcessSummary

logger = logging.getLogger(__name__)


class ProcessScanner:
    """Detects and classifies Claude Code processes."""

    def __init__(self) -> None:
        self._pinned_pids: set[int] = set()
        self._load_pinned()

    def _load_pinned(self) -> None:
        """Load pinned PIDs from persistent storage."""
        try:
            if settings.pinned_path.exists():
                data = json.loads(settings.pinned_path.read_text())
                self._pinned_pids = set(data.get("pinned_pids", []))
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Failed to load pinned PIDs: %s", e)
            self._pinned_pids = set()

    def _save_pinned(self) -> None:
        """Persist pinned PIDs to JSON."""
        settings.pinned_path.parent.mkdir(parents=True, exist_ok=True)
        settings.pinned_path.write_text(json.dumps({"pinned_pids": list(self._pinned_pids)}))

    def pin(self, pid: int) -> None:
        """Pin a process to exempt it from stale detection."""
        self._pinned_pids.add(pid)
        self._save_pinned()

    def unpin(self, pid: int) -> None:
        """Remove pin from a process."""
        self._pinned_pids.discard(pid)
        self._save_pinned()

    def is_pinned(self, pid: int) -> bool:
        return pid in self._pinned_pids

    def _is_claude_process(self, proc: psutil.Process) -> bool:
        """Detect if a process is a Claude Code instance."""
        try:
            exe = proc.exe()
            if settings.claude_exe_marker in exe:
                return True
        except (psutil.AccessDenied, psutil.NoSuchProcess, OSError):
            pass

        try:
            cmdline = proc.cmdline()
            if cmdline and cmdline[0] == "claude":
                return True
        except (psutil.AccessDenied, psutil.NoSuchProcess, OSError):
            pass

        return False

    def _get_project_name(self, cwd: str) -> str:
        """Extract project name from working directory."""
        if not cwd:
            return "unknown"
        path = Path(cwd)
        # If under ~/AI/, use the project folder name
        ai_dir = Path.home() / "AI"
        try:
            rel = path.relative_to(ai_dir)
            return str(rel).split("/")[0]
        except ValueError:
            return path.name

    def _has_terminal(self, proc: psutil.Process) -> bool:
        """Check if process is attached to a terminal."""
        try:
            terminal = proc.terminal()
            return terminal is not None
        except (psutil.AccessDenied, psutil.NoSuchProcess, OSError):
            return False

    def _classify_health(self, proc: psutil.Process, info: ClaudeProcess) -> HealthStatus:
        """Classify process health status."""
        if info.is_pinned:
            return HealthStatus.PINNED

        status = info.status.lower()
        if status in ("zombie", "stopped"):
            return HealthStatus.ZOMBIE

        # Check for stale: sleeping with low CPU for extended time
        if info.cpu_percent < settings.stale_cpu_threshold:
            threshold_hours = (
                settings.stale_interactive_hours
                if self._has_terminal(proc)
                else settings.stale_background_hours
            )
            if info.uptime_hours > threshold_hours:
                return HealthStatus.STALE

        return HealthStatus.HEALTHY

    def _build_process_info(self, proc: psutil.Process) -> ClaudeProcess | None:
        """Build a ClaudeProcess from a psutil.Process."""
        try:
            with proc.oneshot():
                pid = proc.pid
                exe = ""
                try:
                    exe = proc.exe()
                except (psutil.AccessDenied, psutil.NoSuchProcess):
                    pass

                cmdline: list[str] = []
                try:
                    cmdline = proc.cmdline()
                except (psutil.AccessDenied, psutil.NoSuchProcess):
                    pass

                cwd = ""
                try:
                    cwd = proc.cwd()
                except (psutil.AccessDenied, psutil.NoSuchProcess):
                    pass

                terminal = ""
                try:
                    terminal = proc.terminal() or ""
                except (psutil.AccessDenied, psutil.NoSuchProcess, OSError):
                    pass

                status = ""
                try:
                    status = proc.status()
                except (psutil.AccessDenied, psutil.NoSuchProcess):
                    pass

                cpu = 0.0
                try:
                    cpu = proc.cpu_percent(interval=0)
                except (psutil.AccessDenied, psutil.NoSuchProcess):
                    pass

                rss_bytes = 0
                try:
                    mem = proc.memory_info()
                    rss_bytes = mem.rss
                except (psutil.AccessDenied, psutil.NoSuchProcess):
                    pass

                create_time: datetime | None = None
                uptime_hours = 0.0
                try:
                    ct = proc.create_time()
                    create_time = datetime.fromtimestamp(ct, tz=timezone.utc)
                    uptime_hours = (time.time() - ct) / 3600.0
                except (psutil.AccessDenied, psutil.NoSuchProcess):
                    pass

                # Aggregate child memory
                child_count = 0
                child_rss = 0
                try:
                    children = proc.children(recursive=True)
                    child_count = len(children)
                    for child in children:
                        try:
                            child_rss += child.memory_info().rss
                        except (psutil.AccessDenied, psutil.NoSuchProcess):
                            pass
                except (psutil.AccessDenied, psutil.NoSuchProcess):
                    pass

                rss_mb = rss_bytes / (1024 * 1024)
                total_mb = (rss_bytes + child_rss) / (1024 * 1024)

                info = ClaudeProcess(
                    pid=pid,
                    exe=exe,
                    cmdline=cmdline,
                    cwd=cwd,
                    project_name=self._get_project_name(cwd),
                    terminal=terminal,
                    status=status,
                    cpu_percent=round(cpu, 1),
                    memory_rss_mb=round(rss_mb, 1),
                    memory_total_mb=round(total_mb, 1),
                    child_count=child_count,
                    create_time=create_time,
                    uptime_hours=round(uptime_hours, 2),
                    is_pinned=self.is_pinned(pid),
                )
                info.health = self._classify_health(proc, info)
                return info

        except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
            logger.debug("Failed to build process info for PID %s: %s", proc.pid, e)
            return None

    def scan(self) -> ProcessSummary:
        """Scan all running processes and return Claude Code instances."""
        processes: list[ClaudeProcess] = []

        for proc in psutil.process_iter():
            try:
                if self._is_claude_process(proc):
                    info = self._build_process_info(proc)
                    if info:
                        processes.append(info)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        # Clean up pinned PIDs that no longer exist
        active_pids = {p.pid for p in processes}
        stale_pins = self._pinned_pids - active_pids
        if stale_pins:
            self._pinned_pids -= stale_pins
            self._save_pinned()

        summary = ProcessSummary(
            total=len(processes),
            healthy=sum(1 for p in processes if p.health == HealthStatus.HEALTHY),
            stale=sum(1 for p in processes if p.health == HealthStatus.STALE),
            zombie=sum(1 for p in processes if p.health == HealthStatus.ZOMBIE),
            pinned=sum(1 for p in processes if p.health == HealthStatus.PINNED),
            total_memory_mb=round(sum(p.memory_total_mb for p in processes), 1),
            processes=sorted(processes, key=lambda p: p.pid),
        )
        return summary

    def kill_process(self, pid: int, force: bool = False) -> tuple[bool, str]:
        """Kill a Claude process. Returns (success, message)."""
        try:
            proc = psutil.Process(pid)
            if not self._is_claude_process(proc):
                return False, f"PID {pid} is not a Claude process"

            if force:
                os.kill(pid, signal.SIGKILL)
                return True, f"Sent SIGKILL to PID {pid}"

            os.kill(pid, signal.SIGTERM)
            try:
                proc.wait(timeout=5)
                return True, f"Process {pid} terminated gracefully"
            except psutil.TimeoutExpired:
                return True, f"Sent SIGTERM to PID {pid} (still running after 5s, may need force kill)"

        except psutil.NoSuchProcess:
            return False, f"PID {pid} no longer exists"
        except psutil.AccessDenied:
            return False, f"Access denied for PID {pid}"
        except OSError as e:
            return False, f"Error killing PID {pid}: {e}"
