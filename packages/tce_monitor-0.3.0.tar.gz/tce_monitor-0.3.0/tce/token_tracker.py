"""Token usage tracking from Claude stats-cache.json and session-meta files."""

import json
import logging
from datetime import datetime, timezone
from pathlib import Path

from tce.config import settings
from tce.cost_calculator import CostCalculator
from tce.models import (
    MODEL_DISPLAY_NAMES,
    DailyTokens,
    SessionInfo,
    UsageDashboard,
)

logger = logging.getLogger(__name__)


class TokenTracker:
    """Parses Claude usage data with mtime-based caching."""

    def __init__(self) -> None:
        self._cost_calculator = CostCalculator()
        self._stats_cache_mtime: float = 0.0
        self._cached_dashboard: UsageDashboard | None = None
        self._session_meta_mtime: float = 0.0
        self._cached_sessions: list[SessionInfo] | None = None

    def _read_stats_cache(self) -> dict | None:
        """Read stats-cache.json if modified since last read."""
        path = settings.stats_cache_path
        if not path.exists():
            logger.warning("stats-cache.json not found at %s", path)
            return None
        try:
            mtime = path.stat().st_mtime
            if mtime <= self._stats_cache_mtime and self._cached_dashboard:
                return None  # Not modified
            self._stats_cache_mtime = mtime
            return json.loads(path.read_text())
        except (json.JSONDecodeError, OSError) as e:
            logger.error("Failed to read stats-cache.json: %s", e)
            return None

    def _parse_daily_tokens(self, daily_model_tokens: list[dict]) -> list[DailyTokens]:
        """Parse dailyModelTokens array into DailyTokens models."""
        results: list[DailyTokens] = []
        for entry in daily_model_tokens:
            date = entry.get("date", "")
            tokens_by_model = entry.get("tokensByModel", {})
            total = sum(tokens_by_model.values())
            results.append(
                DailyTokens(
                    date=date,
                    tokens_by_model=tokens_by_model,
                    total_tokens=total,
                )
            )
        return results

    def _read_session_meta(self, limit: int = 50) -> list[SessionInfo]:
        """Read recent session-meta files, sorted by start_time descending."""
        meta_dir = settings.session_meta_dir
        if not meta_dir.exists():
            logger.warning("session-meta dir not found at %s", meta_dir)
            return []

        try:
            # Check directory mtime for quick caching
            dir_mtime = meta_dir.stat().st_mtime
            if dir_mtime <= self._session_meta_mtime and self._cached_sessions is not None:
                return self._cached_sessions
            self._session_meta_mtime = dir_mtime
        except OSError:
            pass

        sessions: list[SessionInfo] = []
        # Sort by file modification time, newest first
        meta_files = sorted(meta_dir.glob("*.json"), key=lambda f: f.stat().st_mtime, reverse=True)

        for meta_file in meta_files[:limit]:
            try:
                data = json.loads(meta_file.read_text())
                project_path = data.get("project_path", "")
                project_name = Path(project_path).name if project_path else "unknown"

                start_time = None
                if data.get("start_time"):
                    try:
                        start_time = datetime.fromisoformat(
                            data["start_time"].replace("Z", "+00:00")
                        )
                    except (ValueError, TypeError):
                        pass

                sessions.append(
                    SessionInfo(
                        session_id=data.get("session_id", meta_file.stem),
                        project_path=project_path,
                        project_name=project_name,
                        start_time=start_time,
                        duration_minutes=data.get("duration_minutes", 0),
                        input_tokens=data.get("input_tokens", 0),
                        output_tokens=data.get("output_tokens", 0),
                        summary=data.get("summary", ""),
                        tool_counts=data.get("tool_counts", {}),
                        lines_added=data.get("lines_added", 0),
                        lines_removed=data.get("lines_removed", 0),
                    )
                )
            except (json.JSONDecodeError, OSError) as e:
                logger.debug("Failed to read session meta %s: %s", meta_file, e)
                continue

        self._cached_sessions = sessions
        return sessions

    def get_dashboard(self) -> UsageDashboard:
        """Build the complete usage dashboard data."""
        data = self._read_stats_cache()

        if data is not None:
            # Fresh data — rebuild dashboard
            model_usage_raw = data.get("modelUsage", {})
            model_usage = self._cost_calculator.build_model_usage(model_usage_raw)
            daily_tokens = self._parse_daily_tokens(data.get("dailyModelTokens", []))

            total_cost = sum(m.cost_usd for m in model_usage)
            total_input = sum(m.input_tokens for m in model_usage)
            total_output = sum(m.output_tokens for m in model_usage)
            total_cache_read = sum(m.cache_read_tokens for m in model_usage)

            sessions = self._read_session_meta()

            self._cached_dashboard = UsageDashboard(
                model_usage=model_usage,
                daily_tokens=daily_tokens,
                total_cost_usd=round(total_cost, 2),
                total_input_tokens=total_input,
                total_output_tokens=total_output,
                total_cache_read_tokens=total_cache_read,
                total_sessions=data.get("totalSessions", 0),
                recent_sessions=sessions,
            )

        if self._cached_dashboard:
            return self._cached_dashboard

        # Fallback: return empty dashboard
        return UsageDashboard()

    def get_recent_sessions(self, limit: int = 20) -> list[SessionInfo]:
        """Get recent sessions only."""
        return self._read_session_meta(limit=limit)
