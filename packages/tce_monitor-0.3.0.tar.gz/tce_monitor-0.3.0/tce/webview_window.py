"""Standalone pywebview window for the dashboard.

Launched as a subprocess from the menu bar app so it gets its own
main thread (required by macOS). Connects to the FastAPI server
already running on localhost. Falls back to webbrowser.open() when
pywebview is not installed.
"""

import sys
import webbrowser

from tce.config import settings

try:
    import webview
    HAS_WEBVIEW = True
except ImportError:
    HAS_WEBVIEW = False


def main():
    url = f"http://{settings.host}:{settings.port}"

    if HAS_WEBVIEW:
        window = webview.create_window(
            "Terminus Cancrorum Est",
            url,
            width=1280,
            height=860,
            min_size=(800, 500),
            background_color="#0f0f14",
            text_select=True,
        )
        webview.start()
    else:
        webbrowser.open(url)


if __name__ == "__main__":
    main()
