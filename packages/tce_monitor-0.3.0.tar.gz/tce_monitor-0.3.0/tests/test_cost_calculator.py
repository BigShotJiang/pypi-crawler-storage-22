"""Tests for cost_calculator.py — pricing accuracy."""

import pytest

from tce.cost_calculator import CostCalculator


@pytest.fixture
def calc():
    return CostCalculator()


class TestComputeCost:
    """Test cost computation for each model."""

    def test_opus_46_input_only(self, calc):
        # 1M input tokens @ $15/M = $15.00
        cost = calc.compute_cost("claude-opus-4-6", input_tokens=1_000_000)
        assert cost == 15.0

    def test_opus_46_output_only(self, calc):
        # 1M output tokens @ $75/M = $75.00
        cost = calc.compute_cost("claude-opus-4-6", output_tokens=1_000_000)
        assert cost == 75.0

    def test_opus_46_cache_read(self, calc):
        # 1M cache read @ $1.50/M = $1.50
        cost = calc.compute_cost("claude-opus-4-6", cache_read_tokens=1_000_000)
        assert cost == 1.5

    def test_opus_46_cache_creation(self, calc):
        # 1M cache creation @ $18.75/M = $18.75
        cost = calc.compute_cost("claude-opus-4-6", cache_creation_tokens=1_000_000)
        assert cost == 18.75

    def test_haiku_pricing(self, calc):
        # 1M input @ $0.80 + 1M output @ $4.00 = $4.80
        cost = calc.compute_cost(
            "claude-haiku-4-5-20251001",
            input_tokens=1_000_000,
            output_tokens=1_000_000,
        )
        assert cost == 4.8

    def test_sonnet_pricing(self, calc):
        # 1M input @ $3 + 1M output @ $15 = $18.00
        cost = calc.compute_cost(
            "claude-sonnet-4-5-20250929",
            input_tokens=1_000_000,
            output_tokens=1_000_000,
        )
        assert cost == 18.0

    def test_combined_cost(self, calc):
        cost = calc.compute_cost(
            "claude-opus-4-6",
            input_tokens=500_000,
            output_tokens=100_000,
            cache_read_tokens=2_000_000,
            cache_creation_tokens=300_000,
        )
        expected = (
            500_000 * 15.0 / 1_000_000     # 7.50
            + 100_000 * 75.0 / 1_000_000   # 7.50
            + 2_000_000 * 1.50 / 1_000_000 # 3.00
            + 300_000 * 18.75 / 1_000_000  # 5.625
        )
        assert cost == round(expected, 4)

    def test_unknown_model_returns_zero(self, calc):
        cost = calc.compute_cost("unknown-model", input_tokens=1_000_000)
        assert cost == 0.0

    def test_zero_tokens_returns_zero(self, calc):
        cost = calc.compute_cost("claude-opus-4-6")
        assert cost == 0.0


class TestBuildModelUsage:
    """Test building ModelTokenUsage from raw stats data."""

    def test_builds_model_list(self, calc):
        raw = {
            "claude-opus-4-6": {
                "inputTokens": 100000,
                "outputTokens": 50000,
                "cacheReadInputTokens": 0,
                "cacheCreationInputTokens": 0,
            },
        }
        result = calc.build_model_usage(raw)
        assert len(result) == 1
        assert result[0].model_name == "Opus 4.6"
        assert result[0].input_tokens == 100000
        assert result[0].cost_usd > 0

    def test_sorted_by_cost_descending(self, calc):
        raw = {
            "claude-haiku-4-5-20251001": {
                "inputTokens": 1000,
                "outputTokens": 1000,
                "cacheReadInputTokens": 0,
                "cacheCreationInputTokens": 0,
            },
            "claude-opus-4-6": {
                "inputTokens": 1000000,
                "outputTokens": 500000,
                "cacheReadInputTokens": 0,
                "cacheCreationInputTokens": 0,
            },
        }
        result = calc.build_model_usage(raw)
        assert result[0].model_name == "Opus 4.6"
        assert result[0].cost_usd > result[1].cost_usd
