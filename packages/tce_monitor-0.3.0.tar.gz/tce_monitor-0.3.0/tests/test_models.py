"""Tests for Pydantic model serialization and validation."""

from datetime import datetime, timezone

from tce.models import (
    ClaudeProcess,
    DailyTokens,
    HealthStatus,
    ModelTokenUsage,
    ProcessSummary,
    SessionInfo,
    UsageDashboard,
)


class TestClaudeProcess:
    def test_default_values(self):
        p = ClaudeProcess(pid=1234)
        assert p.pid == 1234
        assert p.health == HealthStatus.HEALTHY
        assert p.memory_rss_mb == 0.0
        assert p.cmdline == []
        assert p.project_name == ""

    def test_serialization(self):
        p = ClaudeProcess(
            pid=1234,
            project_name="tweek",
            health=HealthStatus.STALE,
            memory_rss_mb=150.5,
            uptime_hours=5.2,
        )
        d = p.model_dump()
        assert d["pid"] == 1234
        assert d["health"] == "stale"
        assert d["project_name"] == "tweek"

    def test_json_roundtrip(self):
        p = ClaudeProcess(
            pid=1234,
            create_time=datetime(2026, 2, 10, 12, 0, 0, tzinfo=timezone.utc),
        )
        json_str = p.model_dump_json()
        p2 = ClaudeProcess.model_validate_json(json_str)
        assert p2.pid == 1234
        assert p2.create_time is not None


class TestProcessSummary:
    def test_default_counts(self):
        s = ProcessSummary()
        assert s.total == 0
        assert s.healthy == 0
        assert s.processes == []

    def test_with_processes(self):
        procs = [
            ClaudeProcess(pid=1, health=HealthStatus.HEALTHY, memory_total_mb=100),
            ClaudeProcess(pid=2, health=HealthStatus.STALE, memory_total_mb=200),
        ]
        s = ProcessSummary(
            total=2,
            healthy=1,
            stale=1,
            total_memory_mb=300,
            processes=procs,
        )
        assert s.total == 2
        assert len(s.processes) == 2


class TestModelTokenUsage:
    def test_cost_field(self):
        m = ModelTokenUsage(
            model_id="claude-opus-4-6",
            model_name="Opus 4.6",
            input_tokens=1_000_000,
            output_tokens=500_000,
            cost_usd=52.50,
        )
        d = m.model_dump()
        assert d["cost_usd"] == 52.5
        assert d["model_name"] == "Opus 4.6"


class TestDailyTokens:
    def test_total_tokens(self):
        d = DailyTokens(
            date="2026-02-10",
            tokens_by_model={"claude-opus-4-6": 100000, "claude-haiku-4-5-20251001": 50000},
            total_tokens=150000,
        )
        assert d.total_tokens == 150000


class TestSessionInfo:
    def test_from_raw(self):
        s = SessionInfo(
            session_id="abc-123",
            project_path="/Users/test/AI/tweek",
            project_name="tweek",
            duration_minutes=45,
            input_tokens=1000,
            output_tokens=2000,
            summary="Auth module",
            lines_added=200,
            lines_removed=50,
        )
        assert s.project_name == "tweek"
        assert s.duration_minutes == 45


class TestUsageDashboard:
    def test_empty_dashboard(self):
        d = UsageDashboard()
        assert d.total_cost_usd == 0.0
        assert d.model_usage == []
        assert d.recent_sessions == []
