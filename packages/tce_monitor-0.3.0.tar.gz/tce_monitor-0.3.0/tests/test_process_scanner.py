"""Tests for process_scanner.py — uses mock psutil processes."""

import json
import signal
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

from tce.models import HealthStatus
from tce.process_scanner import ProcessScanner


@pytest.fixture
def scanner(tmp_path):
    """Create a ProcessScanner with a temp pinned.json path."""
    with patch("tce.process_scanner.settings") as mock_settings:
        mock_settings.pinned_path = tmp_path / "pinned.json"
        mock_settings.claude_exe_marker = ".local/share/claude/versions/"
        mock_settings.stale_cpu_threshold = 1.0
        mock_settings.stale_interactive_hours = 4.0
        mock_settings.stale_background_hours = 8.0
        s = ProcessScanner()
    # Re-patch settings for subsequent calls
    with patch.object(s, "_pinned_pids", set()):
        pass
    return s


def _make_mock_proc(
    pid=1234,
    exe="/Users/test/.local/share/claude/versions/2.1.41",
    cmdline=None,
    cwd="/Users/test/AI/myproject",
    status="sleeping",
    cpu_percent=0.5,
    rss=100 * 1024 * 1024,
    create_time=None,
    terminal="/dev/ttys001",
    children=None,
):
    """Build a mock psutil.Process."""
    proc = MagicMock()
    proc.pid = pid
    proc.exe.return_value = exe
    proc.cmdline.return_value = cmdline or ["claude"]
    proc.cwd.return_value = cwd
    proc.status.return_value = status
    proc.cpu_percent.return_value = cpu_percent
    proc.terminal.return_value = terminal

    mem = MagicMock()
    mem.rss = rss
    proc.memory_info.return_value = mem

    if create_time is None:
        import time
        create_time = time.time() - 3600  # 1 hour ago
    proc.create_time.return_value = create_time

    if children is None:
        children = []
    proc.children.return_value = children

    # Support oneshot context manager
    proc.oneshot.return_value.__enter__ = MagicMock(return_value=None)
    proc.oneshot.return_value.__exit__ = MagicMock(return_value=False)

    return proc


class TestClaudeDetection:
    """Test Claude process detection logic."""

    def test_detects_by_exe_path(self, scanner):
        proc = _make_mock_proc(exe="/Users/test/.local/share/claude/versions/2.1.41")
        assert scanner._is_claude_process(proc) is True

    def test_detects_by_cmdline_fallback(self, scanner):
        proc = _make_mock_proc(exe="/usr/bin/node", cmdline=["claude"])
        assert scanner._is_claude_process(proc) is True

    def test_rejects_non_claude(self, scanner):
        proc = _make_mock_proc(exe="/usr/bin/python3", cmdline=["python3", "app.py"])
        assert scanner._is_claude_process(proc) is False

    def test_handles_access_denied_exe(self, scanner):
        import psutil
        proc = _make_mock_proc()
        proc.exe.side_effect = psutil.AccessDenied(pid=1234)
        proc.cmdline.return_value = ["claude"]
        assert scanner._is_claude_process(proc) is True

    def test_handles_access_denied_both(self, scanner):
        import psutil
        proc = _make_mock_proc()
        proc.exe.side_effect = psutil.AccessDenied(pid=1234)
        proc.cmdline.side_effect = psutil.AccessDenied(pid=1234)
        assert scanner._is_claude_process(proc) is False


class TestHealthClassification:
    """Test health status classification."""

    def test_healthy_process(self, scanner):
        proc = _make_mock_proc(status="sleeping", cpu_percent=5.0)
        info = scanner._build_process_info(proc)
        assert info is not None
        assert info.health == HealthStatus.HEALTHY

    def test_zombie_process(self, scanner):
        proc = _make_mock_proc(status="zombie")
        info = scanner._build_process_info(proc)
        assert info is not None
        assert info.health == HealthStatus.ZOMBIE

    def test_stopped_process(self, scanner):
        proc = _make_mock_proc(status="stopped")
        info = scanner._build_process_info(proc)
        assert info is not None
        assert info.health == HealthStatus.ZOMBIE

    def test_stale_interactive(self, scanner):
        import time
        proc = _make_mock_proc(
            status="sleeping",
            cpu_percent=0.1,
            create_time=time.time() - (5 * 3600),  # 5 hours ago
            terminal="/dev/ttys001",
        )
        info = scanner._build_process_info(proc)
        assert info is not None
        assert info.health == HealthStatus.STALE

    def test_not_stale_if_high_cpu(self, scanner):
        import time
        proc = _make_mock_proc(
            status="sleeping",
            cpu_percent=15.0,
            create_time=time.time() - (5 * 3600),
            terminal="/dev/ttys001",
        )
        info = scanner._build_process_info(proc)
        assert info is not None
        assert info.health == HealthStatus.HEALTHY


class TestProjectName:
    """Test project name extraction."""

    def test_ai_project(self, scanner):
        from pathlib import Path
        ai_dir = str(Path.home() / "AI")
        assert scanner._get_project_name(f"{ai_dir}/tweek-public") == "tweek-public"

    def test_nested_ai_project(self, scanner):
        from pathlib import Path
        ai_dir = str(Path.home() / "AI")
        assert scanner._get_project_name(f"{ai_dir}/tweek-public/src") == "tweek-public"

    def test_non_ai_path(self, scanner):
        assert scanner._get_project_name("/tmp/foo") == "foo"

    def test_empty_path(self, scanner):
        assert scanner._get_project_name("") == "unknown"


class TestPinning:
    """Test pin/unpin persistence."""

    def test_pin_and_check(self, tmp_path):
        with patch("tce.process_scanner.settings") as mock_settings:
            mock_settings.pinned_path = tmp_path / "pinned.json"
            mock_settings.claude_exe_marker = ".local/share/claude/versions/"
            mock_settings.stale_cpu_threshold = 1.0
            mock_settings.stale_interactive_hours = 4.0
            mock_settings.stale_background_hours = 8.0
            s = ProcessScanner()
            s.pin(1234)
            assert s.is_pinned(1234)

            # Verify persisted
            data = json.loads((tmp_path / "pinned.json").read_text())
            assert 1234 in data["pinned_pids"]

    def test_unpin(self, tmp_path):
        with patch("tce.process_scanner.settings") as mock_settings:
            mock_settings.pinned_path = tmp_path / "pinned.json"
            mock_settings.claude_exe_marker = ".local/share/claude/versions/"
            mock_settings.stale_cpu_threshold = 1.0
            mock_settings.stale_interactive_hours = 4.0
            mock_settings.stale_background_hours = 8.0
            s = ProcessScanner()
            s.pin(1234)
            s.unpin(1234)
            assert not s.is_pinned(1234)


class TestScan:
    """Test full scan with mocked process_iter."""

    @patch("tce.process_scanner.psutil.process_iter")
    def test_scan_finds_claude_processes(self, mock_iter, scanner):
        claude_proc = _make_mock_proc(pid=100)
        non_claude = _make_mock_proc(pid=200, exe="/usr/bin/python3", cmdline=["python3"])
        mock_iter.return_value = [claude_proc, non_claude]

        summary = scanner.scan()
        assert summary.total == 1
        assert summary.processes[0].pid == 100

    @patch("tce.process_scanner.psutil.process_iter")
    def test_scan_empty(self, mock_iter, scanner):
        mock_iter.return_value = []
        summary = scanner.scan()
        assert summary.total == 0


class TestKill:
    """Test kill_process behavior."""

    @patch("tce.process_scanner.psutil.Process")
    @patch("tce.process_scanner.os.kill")
    def test_kill_sigterm(self, mock_kill, mock_proc_cls, scanner):
        proc = _make_mock_proc(pid=100)
        mock_proc_cls.return_value = proc
        scanner._is_claude_process = MagicMock(return_value=True)
        proc.wait.return_value = None

        success, msg = scanner.kill_process(100)
        assert success
        mock_kill.assert_called_with(100, signal.SIGTERM)

    @patch("tce.process_scanner.psutil.Process")
    @patch("tce.process_scanner.os.kill")
    def test_kill_sigkill_force(self, mock_kill, mock_proc_cls, scanner):
        proc = _make_mock_proc(pid=100)
        mock_proc_cls.return_value = proc
        scanner._is_claude_process = MagicMock(return_value=True)

        success, msg = scanner.kill_process(100, force=True)
        assert success
        mock_kill.assert_called_with(100, signal.SIGKILL)

    @patch("tce.process_scanner.psutil.Process")
    def test_kill_non_claude_rejected(self, mock_proc_cls, scanner):
        proc = _make_mock_proc(pid=200, exe="/usr/bin/python3", cmdline=["python3"])
        mock_proc_cls.return_value = proc

        success, msg = scanner.kill_process(200)
        assert not success
        assert "not a Claude process" in msg
