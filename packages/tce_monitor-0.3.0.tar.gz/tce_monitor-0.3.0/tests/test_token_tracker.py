"""Tests for token_tracker.py — uses tmp_path fixtures with sample data."""

import json
from datetime import datetime

import pytest

from tce.token_tracker import TokenTracker


@pytest.fixture
def sample_stats_cache(tmp_path):
    """Create a sample stats-cache.json."""
    data = {
        "version": 2,
        "lastComputedDate": "2026-02-12",
        "dailyActivity": [
            {"date": "2026-02-10", "messageCount": 100, "sessionCount": 2, "toolCallCount": 50},
            {"date": "2026-02-11", "messageCount": 200, "sessionCount": 3, "toolCallCount": 75},
        ],
        "dailyModelTokens": [
            {"date": "2026-02-10", "tokensByModel": {"claude-opus-4-6": 500000}},
            {"date": "2026-02-11", "tokensByModel": {"claude-opus-4-6": 300000, "claude-haiku-4-5-20251001": 100000}},
        ],
        "modelUsage": {
            "claude-opus-4-6": {
                "inputTokens": 100000,
                "outputTokens": 50000,
                "cacheReadInputTokens": 2000000,
                "cacheCreationInputTokens": 500000,
                "webSearchRequests": 0,
                "costUSD": 0,
            },
            "claude-haiku-4-5-20251001": {
                "inputTokens": 5000,
                "outputTokens": 3000,
                "cacheReadInputTokens": 100000,
                "cacheCreationInputTokens": 20000,
                "webSearchRequests": 0,
                "costUSD": 0,
            },
        },
        "totalSessions": 42,
        "totalMessages": 5000,
    }
    path = tmp_path / "stats-cache.json"
    path.write_text(json.dumps(data))
    return path


@pytest.fixture
def sample_session_meta(tmp_path):
    """Create sample session-meta files."""
    meta_dir = tmp_path / "session-meta"
    meta_dir.mkdir()

    sessions = [
        {
            "session_id": "abc-123",
            "project_path": "/Users/test/AI/tweek",
            "start_time": "2026-02-11T14:30:00.000Z",
            "duration_minutes": 45,
            "input_tokens": 1000,
            "output_tokens": 2000,
            "summary": "Implemented auth module",
            "tool_counts": {"Bash": 10, "Edit": 5},
            "lines_added": 200,
            "lines_removed": 50,
        },
        {
            "session_id": "def-456",
            "project_path": "/Users/test/AI/rpgmaster",
            "start_time": "2026-02-10T10:00:00.000Z",
            "duration_minutes": 120,
            "input_tokens": 5000,
            "output_tokens": 8000,
            "summary": "Session prep for game night",
            "tool_counts": {"Read": 20, "Write": 8},
            "lines_added": 500,
            "lines_removed": 100,
        },
    ]

    for session in sessions:
        path = meta_dir / f"{session['session_id']}.json"
        path.write_text(json.dumps(session))

    return meta_dir


@pytest.fixture
def tracker(tmp_path, sample_stats_cache, sample_session_meta, monkeypatch):
    """Create a TokenTracker with patched paths."""
    from tce import config
    monkeypatch.setattr(config.settings, "stats_cache_path", sample_stats_cache)
    monkeypatch.setattr(config.settings, "session_meta_dir", sample_session_meta)
    return TokenTracker()


class TestDashboard:
    """Test dashboard data assembly."""

    def test_loads_model_usage(self, tracker):
        dashboard = tracker.get_dashboard()
        assert len(dashboard.model_usage) == 2

        # Opus should be the most expensive
        opus = next(m for m in dashboard.model_usage if m.model_id == "claude-opus-4-6")
        assert opus.input_tokens == 100000
        assert opus.output_tokens == 50000
        assert opus.cost_usd > 0

    def test_total_cost(self, tracker):
        dashboard = tracker.get_dashboard()
        assert dashboard.total_cost_usd > 0

    def test_daily_tokens(self, tracker):
        dashboard = tracker.get_dashboard()
        assert len(dashboard.daily_tokens) == 2
        assert dashboard.daily_tokens[0].date == "2026-02-10"
        assert dashboard.daily_tokens[0].total_tokens == 500000

    def test_total_sessions(self, tracker):
        dashboard = tracker.get_dashboard()
        assert dashboard.total_sessions == 42


class TestSessions:
    """Test session-meta parsing."""

    def test_loads_sessions(self, tracker):
        sessions = tracker.get_recent_sessions(limit=10)
        assert len(sessions) == 2

    def test_session_fields(self, tracker):
        sessions = tracker.get_recent_sessions()
        # Find by session_id
        session = next(s for s in sessions if s.session_id == "abc-123")
        assert session.project_name == "tweek"
        assert session.duration_minutes == 45
        assert session.input_tokens == 1000
        assert session.lines_added == 200
        assert session.summary == "Implemented auth module"

    def test_session_start_time_parsed(self, tracker):
        sessions = tracker.get_recent_sessions()
        session = next(s for s in sessions if s.session_id == "abc-123")
        assert session.start_time is not None
        assert session.start_time.year == 2026


class TestCaching:
    """Test mtime-based caching."""

    def test_returns_cached_on_second_call(self, tracker):
        dash1 = tracker.get_dashboard()
        dash2 = tracker.get_dashboard()
        # Should return the same object (cache hit)
        assert dash1 is dash2

    def test_refreshes_on_file_change(self, tracker, sample_stats_cache):
        dash1 = tracker.get_dashboard()
        # Touch the file to update mtime
        import time
        time.sleep(0.1)
        data = json.loads(sample_stats_cache.read_text())
        data["totalSessions"] = 99
        sample_stats_cache.write_text(json.dumps(data))

        dash2 = tracker.get_dashboard()
        assert dash2.total_sessions == 99
        assert dash1 is not dash2
