#!/usr/bin/env python3
"""Demo script to show resource alert functionality.

This script simulates Claude processes with varying resource consumption
to demonstrate the resource alert feature.
"""

from tce.models import ClaudeProcess, HealthStatus, ResourceAlertType
from tce.process_scanner import ProcessScanner


def demo_resource_alerts():
    """Demonstrate resource alert detection."""
    scanner = ProcessScanner()

    # Simulate system with 16GB RAM and 8 cores
    total_memory_mb = 16 * 1024  # 16GB
    cpu_count = 8

    print("=" * 70)
    print("RESOURCE ALERT DEMO")
    print("=" * 70)
    print(f"System: {total_memory_mb / 1024:.0f}GB RAM, {cpu_count} CPU cores")
    print(f"Thresholds: CPU > 75%, Memory > 75%")
    print()

    # Create test processes
    processes = [
        {
            "name": "Normal Process",
            "memory_mb": 500,
            "cpu_percent": 50,  # 50% on one core = 6.25% of 8-core system
        },
        {
            "name": "Memory Hog",
            "memory_mb": 13 * 1024,  # 13GB = 81% of 16GB
            "cpu_percent": 25,
        },
        {
            "name": "CPU Hog",
            "memory_mb": 1024,
            "cpu_percent": 640,  # 640% = 80% of 8-core system
        },
        {
            "name": "Both Resources High",
            "memory_mb": 13 * 1024,
            "cpu_percent": 640,
        },
    ]

    for idx, proc_data in enumerate(processes, start=1):
        # Create a mock ClaudeProcess
        info = ClaudeProcess(
            pid=1000 + idx,
            project_name=proc_data["name"],
            memory_total_mb=proc_data["memory_mb"],
            cpu_percent=proc_data["cpu_percent"],
            health=HealthStatus.HEALTHY,
        )

        # Check for resource alert
        alert = scanner._check_resource_alert(info, total_memory_mb, cpu_count)
        info.resource_alert = alert

        print(f"Process: {info.project_name}")
        print(f"  PID: {info.pid}")
        print(f"  Memory: {info.memory_total_mb:.0f} MB ({info.memory_percent_of_system:.1f}% of system)")
        print(f"  CPU: {info.cpu_percent:.0f}% ({info.cpu_percent_of_system:.1f}% of system)")

        if alert:
            alert_type = {
                ResourceAlertType.HIGH_MEMORY: "⚠️  HIGH MEMORY",
                ResourceAlertType.HIGH_CPU: "⚠️  HIGH CPU",
                ResourceAlertType.BOTH: "⚠️  HIGH CPU + MEMORY",
            }[alert]
            print(f"  Alert: {alert_type}")
        else:
            print(f"  Alert: ✅ OK")
        print()

    print("=" * 70)


if __name__ == "__main__":
    demo_resource_alerts()
