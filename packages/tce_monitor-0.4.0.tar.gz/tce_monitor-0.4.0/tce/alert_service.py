"""macOS notification alerts for process health changes."""

import logging
import shutil
import subprocess
import time
from pathlib import Path

from tce.config import settings
from tce.models import ClaudeProcess, HealthStatus, ResourceAlertType

logger = logging.getLogger(__name__)

ICON_PATH = str(Path(__file__).parent / "static" / "logo.jpg")


class AlertService:
    """Sends macOS notifications via terminal-notifier with cooldown to prevent spam."""

    def __init__(self) -> None:
        self._last_alert: dict[int, float] = {}  # pid -> timestamp (for stale/zombie)
        self._last_resource_alert: dict[int, float] = {}  # pid -> timestamp (for resource alerts)
        self._notifier = shutil.which("terminal-notifier")
        if not self._notifier:
            logger.warning("terminal-notifier not found — install with: brew install terminal-notifier")

    def _should_alert(self, pid: int) -> bool:
        """Check if enough time has passed since last alert for this PID."""
        last = self._last_alert.get(pid, 0)
        return (time.time() - last) > settings.alert_cooldown

    def _should_alert_resource(self, pid: int) -> bool:
        """Check if enough time has passed since last resource alert for this PID."""
        last = self._last_resource_alert.get(pid, 0)
        return (time.time() - last) > settings.resource_alert_cooldown

    def _send_notification(self, title: str, subtitle: str, message: str) -> None:
        """Send a macOS notification via terminal-notifier."""
        if not self._notifier:
            logger.warning("Notification suppressed (no terminal-notifier): %s", message)
            return
        try:
            subprocess.run(
                [
                    self._notifier,
                    "-title", title,
                    "-subtitle", subtitle,
                    "-message", message,
                    "-sound", "default",
                    "-appIcon", ICON_PATH,
                    "-group", "tce",
                ],
                capture_output=True,
                timeout=5,
            )
        except (subprocess.TimeoutExpired, OSError) as e:
            logger.warning("Failed to send notification: %s", e)

    def check_and_alert(self, processes: list[ClaudeProcess]) -> None:
        """Check processes and send alerts for stale/zombie/resource-intensive ones."""
        for proc in processes:
            if proc.health == HealthStatus.STALE and self._should_alert(proc.pid):
                self._send_notification(
                    "\U0001f980 Terminus Cancrorum Est",
                    "\U0001f7e1 Stale Process Detected",
                    f"PID {proc.pid} \u2022 {proc.project_name}\n"
                    f"Idle for {proc.uptime_hours:.1f}h \u2022 {proc.memory_total_mb:.0f} MB\n"
                    f"Run: tce kill {proc.pid}",
                )
                self._last_alert[proc.pid] = time.time()
                logger.info("Alert: stale process PID %d (%s)", proc.pid, proc.project_name)

            elif proc.health == HealthStatus.ZOMBIE and self._should_alert(proc.pid):
                self._send_notification(
                    "\U0001f980 Terminus Cancrorum Est",
                    "\U0001f480 Zombie Process Detected",
                    f"PID {proc.pid} \u2022 {proc.project_name}\n"
                    f"Process is unresponsive\n"
                    f"Run: tce kill {proc.pid} --force",
                )
                self._last_alert[proc.pid] = time.time()
                logger.info("Alert: zombie process PID %d (%s)", proc.pid, proc.project_name)

            # Check for resource alerts (separate from health status)
            if proc.resource_alert and self._should_alert_resource(proc.pid):
                alert_type = proc.resource_alert
                if alert_type == ResourceAlertType.HIGH_MEMORY:
                    subtitle = "\u26a0\ufe0f High Memory Usage"
                    message = (
                        f"PID {proc.pid} \u2022 {proc.project_name}\n"
                        f"Memory: {proc.memory_percent_of_system:.1f}% of system "
                        f"({proc.memory_total_mb:.0f} MB)\n"
                        f"Consider: tce kill {proc.pid}"
                    )
                elif alert_type == ResourceAlertType.HIGH_CPU:
                    subtitle = "\u26a0\ufe0f High CPU Usage"
                    message = (
                        f"PID {proc.pid} \u2022 {proc.project_name}\n"
                        f"CPU: {proc.cpu_percent_of_system:.1f}% of system\n"
                        f"Consider: tce kill {proc.pid}"
                    )
                else:  # BOTH
                    subtitle = "\u26a0\ufe0f High Resource Usage"
                    message = (
                        f"PID {proc.pid} \u2022 {proc.project_name}\n"
                        f"CPU: {proc.cpu_percent_of_system:.1f}% \u2022 "
                        f"Memory: {proc.memory_percent_of_system:.1f}%\n"
                        f"Consider: tce kill {proc.pid}"
                    )

                self._send_notification("\U0001f980 Terminus Cancrorum Est", subtitle, message)
                self._last_resource_alert[proc.pid] = time.time()
                logger.info(
                    "Alert: %s for PID %d (%s) - CPU: %.1f%%, Memory: %.1f%%",
                    alert_type.value,
                    proc.pid,
                    proc.project_name,
                    proc.cpu_percent_of_system,
                    proc.memory_percent_of_system,
                )

        # Clean up alerts for PIDs that no longer exist
        active_pids = {p.pid for p in processes}
        stale_keys = set(self._last_alert.keys()) - active_pids
        for pid in stale_keys:
            del self._last_alert[pid]
        stale_resource_keys = set(self._last_resource_alert.keys()) - active_pids
        for pid in stale_resource_keys:
            del self._last_resource_alert[pid]
