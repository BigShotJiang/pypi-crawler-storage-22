"""Terminus Cancrorum Est — canonical CLI entry point.

Installed as `tce` via pyproject.toml [project.scripts].
"""

import argparse
import os
import signal
import subprocess
import sys
import time
import webbrowser

from tce.config import settings
from tce.models import HealthStatus
from tce.process_scanner import ProcessScanner
from tce.token_tracker import TokenTracker


def cmd_status(args):
    """Show Claude process health status."""
    scanner = ProcessScanner()
    summary = scanner.scan()

    print(f"{'='*60}")
    print(f" TERMINUS CANCRORUM EST — Process Status")
    print(f"{'='*60}")
    print(f" Total: {summary.total}  |  Healthy: {summary.healthy}  |  Stale: {summary.stale}  |  Zombie: {summary.zombie}  |  Pinned: {summary.pinned}")
    print(f" Resource Alerts: {summary.resource_alerts}  |  Total Memory: {summary.total_memory_mb:.0f} MB")
    print(f"{'='*60}")

    if not summary.processes:
        print(" No Claude processes running.")
        return

    for p in summary.processes:
        health_icon = {"healthy": "+", "stale": "!", "zombie": "X", "pinned": "*"}.get(p.health.value, "?")
        print(f" [{health_icon}] PID {p.pid:>6}  {p.project_name:<25} {p.memory_total_mb:>6.0f} MB  {p.cpu_percent:>5.1f}%  {p.uptime_hours:>6.1f}h  {p.health.value}")
        if p.terminal:
            print(f"              terminal: {p.terminal}")
        if p.resource_alert:
            alert_msg = f"              \u26a0\ufe0f  RESOURCE ALERT: "
            if p.resource_alert.value == "high_memory":
                alert_msg += f"Memory {p.memory_percent_of_system:.1f}% of system"
            elif p.resource_alert.value == "high_cpu":
                alert_msg += f"CPU {p.cpu_percent_of_system:.1f}% of system"
            else:  # both
                alert_msg += f"CPU {p.cpu_percent_of_system:.1f}%, Memory {p.memory_percent_of_system:.1f}%"
            print(alert_msg)

    if summary.stale > 0:
        print(f"\n WARNING: {summary.stale} stale process(es) detected. Use 'tce kill-stale' to clean up.")
    if summary.zombie > 0:
        print(f"\n CRITICAL: {summary.zombie} zombie process(es) detected. Use 'tce kill <PID> --force' to remove.")
    if summary.resource_alerts > 0:
        print(f"\n WARNING: {summary.resource_alerts} process(es) consuming excessive resources (>75% CPU or memory).")


def cmd_usage(args):
    """Show token usage and costs."""
    tracker = TokenTracker()
    dashboard = tracker.get_dashboard()

    print(f"{'='*60}")
    print(f" TERMINUS CANCRORUM EST — Token Usage & Costs")
    print(f"{'='*60}")
    print(f" Total Cost: ${dashboard.total_cost_usd:,.2f}")
    print(f" Total Sessions: {dashboard.total_sessions}")
    print(f"{'='*60}")

    if not dashboard.model_usage:
        print(" No usage data found.")
        return

    print(f" {'Model':<20} {'Input':>10} {'Output':>10} {'Cache Rd':>10} {'Cache Cr':>10} {'Cost':>12}")
    print(f" {'-'*20} {'-'*10} {'-'*10} {'-'*10} {'-'*10} {'-'*12}")

    for m in dashboard.model_usage:
        print(f" {m.model_name:<20} {_fmt_tokens(m.input_tokens):>10} {_fmt_tokens(m.output_tokens):>10} {_fmt_tokens(m.cache_read_tokens):>10} {_fmt_tokens(m.cache_creation_tokens):>10} ${m.cost_usd:>10,.2f}")

    print(f" {'-'*20} {'-'*10} {'-'*10} {'-'*10} {'-'*10} {'-'*12}")
    print(f" {'TOTAL':<20} {_fmt_tokens(dashboard.total_input_tokens):>10} {_fmt_tokens(dashboard.total_output_tokens):>10} {_fmt_tokens(dashboard.total_cache_read_tokens):>10} {'':>10} ${dashboard.total_cost_usd:>10,.2f}")


def cmd_sessions(args):
    """Show recent sessions."""
    tracker = TokenTracker()
    sessions = tracker.get_recent_sessions(limit=args.limit)

    print(f"{'='*60}")
    print(f" TERMINUS CANCRORUM EST — Recent Sessions (last {args.limit})")
    print(f"{'='*60}")

    if not sessions:
        print(" No sessions found.")
        return

    for s in sessions:
        start = s.start_time.strftime("%b %d %H:%M") if s.start_time else "unknown"
        print(f" {s.project_name:<22} {start}  {s.duration_minutes:>4.0f}m  +{s.lines_added}/-{s.lines_removed}")
        if s.summary:
            print(f"   {s.summary[:75]}")


def cmd_kill(args):
    """Kill a specific process."""
    scanner = ProcessScanner()
    success, msg = scanner.kill_process(args.pid, force=args.force)
    print(msg)
    sys.exit(0 if success else 1)


def cmd_kill_stale(args):
    """Kill all stale processes."""
    scanner = ProcessScanner()
    summary = scanner.scan()
    stale = [p for p in summary.processes if p.health == HealthStatus.STALE]

    if not stale:
        print("No stale processes found.")
        return

    print(f"Found {len(stale)} stale process(es):")
    killed = 0
    for p in stale:
        print(f"  Killing PID {p.pid} ({p.project_name}, idle {p.uptime_hours:.1f}h)...", end=" ")
        success, msg = scanner.kill_process(p.pid)
        print("OK" if success else f"FAILED: {msg}")
        if success:
            killed += 1

    print(f"\nKilled {killed}/{len(stale)} stale processes.")


def cmd_pin(args):
    """Pin a process."""
    scanner = ProcessScanner()
    scanner.pin(args.pid)
    print(f"PID {args.pid} pinned (exempt from stale detection).")


def cmd_unpin(args):
    """Unpin a process."""
    scanner = ProcessScanner()
    scanner.unpin(args.pid)
    print(f"PID {args.pid} unpinned.")


def cmd_dashboard(args):
    """Start the web dashboard."""
    import urllib.request

    # Check if already running
    try:
        urllib.request.urlopen(f"http://{settings.host}:{settings.port}/", timeout=2)
        print(f"Dashboard already running at http://{settings.host}:{settings.port}")
        webbrowser.open(f"http://{settings.host}:{settings.port}")
        return
    except Exception:
        pass

    print(f"Starting dashboard on http://{settings.host}:{settings.port} ...")
    proc = subprocess.Popen(
        [sys.executable, "-c", "\n".join([
            "import uvicorn",
            "from tce.process_scanner import ProcessScanner",
            "from tce.token_tracker import TokenTracker",
            "from tce.dashboard import create_app",
            "scanner = ProcessScanner()",
            "tracker = TokenTracker()",
            "app = create_app(scanner, tracker)",
            f"uvicorn.run(app, host='{settings.host}', port={settings.port}, log_level='warning')",
        ])],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )

    # Write PID for later stop
    pid_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs")
    os.makedirs(pid_dir, exist_ok=True)
    pid_file = os.path.join(pid_dir, "dashboard.pid")
    with open(pid_file, "w") as f:
        f.write(str(proc.pid))

    time.sleep(2)
    webbrowser.open(f"http://{settings.host}:{settings.port}")
    print(f"Dashboard started (PID {proc.pid}). Open http://{settings.host}:{settings.port}")


def cmd_dashboard_stop(args):
    """Stop the web dashboard."""
    pid_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs")
    pid_file = os.path.join(pid_dir, "dashboard.pid")

    if not os.path.exists(pid_file):
        # Try lsof fallback
        try:
            result = subprocess.run(
                ["lsof", f"-ti:{settings.port}"],
                capture_output=True, text=True,
            )
            pids = result.stdout.strip().split()
            if pids:
                for pid in pids:
                    os.kill(int(pid), signal.SIGTERM)
                print(f"Stopped dashboard (port {settings.port}).")
                return
        except Exception:
            pass
        print("No dashboard PID file found and no process on port.")
        return

    with open(pid_file) as f:
        pid = int(f.read().strip())

    try:
        os.kill(pid, signal.SIGTERM)
        os.remove(pid_file)
        print(f"Dashboard stopped (PID {pid}).")
    except ProcessLookupError:
        os.remove(pid_file)
        print(f"Dashboard was not running (PID {pid} gone).")


def cmd_run(args):
    """Run full app (menu bar + dashboard on macOS, dashboard-only otherwise)."""
    from tce.app import main as app_main
    app_main()


LAUNCHD_LABEL = "com.terminus-cancrorum-est"
LAUNCHD_PLIST_TEMPLATE = """\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>%LABEL%</string>

    <key>ProgramArguments</key>
    <array>
        <string>%TCE_PATH%</string>
        <string>run</string>
    </array>

    <key>RunAtLoad</key>
    <true/>

    <key>KeepAlive</key>
    <true/>

    <key>StandardOutPath</key>
    <string>%LOG_DIR%/stdout.log</string>

    <key>StandardErrorPath</key>
    <string>%LOG_DIR%/stderr.log</string>

    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>%PATH_ENV%</string>
        <key>HOME</key>
        <string>%HOME%</string>
    </dict>
</dict>
</plist>
"""


def cmd_install(args):
    """Install tce as a macOS launchd service (auto-start at login)."""
    import platform
    import shutil
    from pathlib import Path

    if platform.system() != "Darwin":
        print("Error: 'tce install' is only supported on macOS.")
        sys.exit(1)

    tce_path = shutil.which("tce")
    if not tce_path:
        print("Error: 'tce' not found on PATH. Is tce-monitor installed?")
        sys.exit(1)

    if not shutil.which("terminal-notifier"):
        print("Note: installing terminal-notifier for desktop notifications...")
        subprocess.run(["brew", "install", "terminal-notifier"], capture_output=True)
        if not shutil.which("terminal-notifier"):
            print("  Warning: terminal-notifier not found. Install with: brew install terminal-notifier")

    home = str(Path.home())
    log_dir = str(Path.home() / ".terminus-cancrorum-est" / "logs")
    os.makedirs(log_dir, exist_ok=True)

    plist_content = LAUNCHD_PLIST_TEMPLATE.replace("%LABEL%", LAUNCHD_LABEL)
    plist_content = plist_content.replace("%TCE_PATH%", tce_path)
    plist_content = plist_content.replace("%LOG_DIR%", log_dir)
    plist_content = plist_content.replace("%PATH_ENV%", os.environ.get("PATH", "/usr/local/bin:/usr/bin:/bin"))
    plist_content = plist_content.replace("%HOME%", home)

    plist_dest = Path.home() / "Library" / "LaunchAgents" / f"{LAUNCHD_LABEL}.plist"
    plist_dest.parent.mkdir(parents=True, exist_ok=True)

    # Unload if already installed
    if plist_dest.exists():
        subprocess.run(["launchctl", "unload", str(plist_dest)], capture_output=True)

    # Ensure Info.plist exists for rumps notifications
    python_bin = Path(sys.executable).parent
    info_plist = python_bin / "Info.plist"
    if not info_plist.exists():
        subprocess.run(
            ["/usr/libexec/PlistBuddy", "-c",
             f'Add :CFBundleIdentifier string "{LAUNCHD_LABEL}"',
             str(info_plist)],
            capture_output=True,
        )

    plist_dest.write_text(plist_content)
    result = subprocess.run(["launchctl", "load", str(plist_dest)], capture_output=True, text=True)

    if result.returncode != 0:
        print(f"Error loading service: {result.stderr.strip()}")
        sys.exit(1)

    print(f"Installed and started tce as a macOS login service.")
    print(f"  Plist: {plist_dest}")
    print(f"  Logs:  {log_dir}/")
    print(f"  Using: {tce_path}")
    print(f"\nThe crab will appear in your menu bar and persist across logins.")
    print(f"Run 'tce uninstall' to remove.")


def cmd_uninstall(args):
    """Remove tce launchd service."""
    import platform
    from pathlib import Path

    if platform.system() != "Darwin":
        print("Error: 'tce uninstall' is only supported on macOS.")
        sys.exit(1)

    plist_dest = Path.home() / "Library" / "LaunchAgents" / f"{LAUNCHD_LABEL}.plist"

    if not plist_dest.exists():
        print("tce is not installed as a launchd service.")
        return

    subprocess.run(["launchctl", "unload", str(plist_dest)], capture_output=True)
    plist_dest.unlink()

    print(f"Uninstalled tce launchd service.")
    print(f"  Removed: {plist_dest}")


def _fmt_tokens(n: int) -> str:
    """Format token count for display."""
    if n >= 1_000_000_000:
        return f"{n / 1_000_000_000:.1f}B"
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.1f}K"
    return str(n)


def main():
    parser = argparse.ArgumentParser(
        prog="tce",
        description="Terminus Cancrorum Est — Claude Code process monitor",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("status", help="Show Claude process health")
    sub.add_parser("usage", help="Show token usage and costs")

    p_sessions = sub.add_parser("sessions", help="Show recent sessions")
    p_sessions.add_argument("--limit", type=int, default=15, help="Number of sessions to show")

    p_kill = sub.add_parser("kill", help="Kill a Claude process")
    p_kill.add_argument("pid", type=int, help="Process ID to kill")
    p_kill.add_argument("--force", action="store_true", help="Send SIGKILL instead of SIGTERM")

    sub.add_parser("kill-stale", help="Kill all stale processes")

    p_pin = sub.add_parser("pin", help="Pin a process (exempt from stale)")
    p_pin.add_argument("pid", type=int, help="Process ID to pin")

    p_unpin = sub.add_parser("unpin", help="Unpin a process")
    p_unpin.add_argument("pid", type=int, help="Process ID to unpin")

    sub.add_parser("dashboard", help="Start the web dashboard")
    sub.add_parser("dashboard-stop", help="Stop the web dashboard")
    sub.add_parser("run", help="Run full app (menu bar + dashboard)")
    sub.add_parser("install", help="Install as macOS login service (launchd)")
    sub.add_parser("uninstall", help="Remove macOS login service")

    args = parser.parse_args()

    commands = {
        "status": cmd_status,
        "usage": cmd_usage,
        "sessions": cmd_sessions,
        "kill": cmd_kill,
        "kill-stale": cmd_kill_stale,
        "pin": cmd_pin,
        "unpin": cmd_unpin,
        "dashboard": cmd_dashboard,
        "dashboard-stop": cmd_dashboard_stop,
        "run": cmd_run,
        "install": cmd_install,
        "uninstall": cmd_uninstall,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
