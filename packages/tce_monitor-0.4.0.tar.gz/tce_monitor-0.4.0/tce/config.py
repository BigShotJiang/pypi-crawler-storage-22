"""Configuration for Terminus Cancrorum Est using pydantic-settings."""

from pathlib import Path

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment and .env file."""

    model_config = {"env_prefix": "CLAUDE_MONITOR_", "env_file": ".env", "extra": "ignore"}

    # Server
    port: int = 5111
    host: str = "127.0.0.1"

    # Polling intervals (seconds)
    process_poll_interval: int = 10
    token_poll_interval: int = 300  # 5 minutes

    # Health thresholds
    stale_interactive_hours: float = 4.0
    stale_background_hours: float = 8.0
    stale_cpu_threshold: float = 1.0  # percent

    # Resource consumption thresholds
    resource_cpu_percent_threshold: float = 75.0  # % of total system CPU
    resource_memory_percent_threshold: float = 75.0  # % of total system memory

    # Alert cooldown (seconds)
    alert_cooldown: int = 1800  # 30 minutes
    resource_alert_cooldown: int = 1800  # 30 minutes (separate from stale alerts)

    # Paths
    claude_home: Path = Path.home() / ".claude"
    stats_cache_path: Path = Path.home() / ".claude" / "stats-cache.json"
    session_meta_dir: Path = Path.home() / ".claude" / "usage-data" / "session-meta"
    pinned_path: Path = Path.home() / ".terminus-cancrorum-est" / "pinned.json"

    # Claude process detection
    claude_exe_marker: str = ".local/share/claude/versions/"

    # Model pricing (per million tokens)
    pricing: dict[str, dict[str, float]] = {
        "claude-opus-4-5-20251101": {
            "input": 15.0,
            "output": 75.0,
            "cache_read": 1.50,
            "cache_creation": 18.75,  # 1.25x input
        },
        "claude-opus-4-6": {
            "input": 15.0,
            "output": 75.0,
            "cache_read": 1.50,
            "cache_creation": 18.75,
        },
        "claude-sonnet-4-5-20250929": {
            "input": 3.0,
            "output": 15.0,
            "cache_read": 0.30,
            "cache_creation": 3.75,
        },
        "claude-haiku-4-5-20251001": {
            "input": 0.80,
            "output": 4.0,
            "cache_read": 0.08,
            "cache_creation": 1.0,
        },
    }


settings = Settings()
