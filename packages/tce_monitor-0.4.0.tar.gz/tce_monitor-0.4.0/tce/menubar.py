"""rumps menu bar application for Terminus Cancrorum Est."""

import logging
import os
import signal
import subprocess
import sys

import rumps

from tce.alert_service import AlertService
from tce.config import settings
from tce.models import HealthStatus, ProcessSummary, ResourceAlertType
from tce.process_scanner import ProcessScanner

logger = logging.getLogger(__name__)

HEALTH_ICONS = {
    HealthStatus.HEALTHY: "✅",
    HealthStatus.STALE: "🟡",
    HealthStatus.ZOMBIE: "💀",
    HealthStatus.PINNED: "📌",
}

CRAB = "🦀"


class TerminusApp(rumps.App):
    """Menu bar app showing Claude Code process status."""

    def __init__(self, scanner: ProcessScanner) -> None:
        super().__init__("Terminus Cancrorum Est", title=CRAB)
        self._scanner = scanner
        self._alert_service = AlertService()
        self._last_summary: ProcessSummary | None = None
        self._webview_proc: subprocess.Popen | None = None

    @rumps.timer(settings.process_poll_interval)
    def poll_processes(self, _sender: rumps.Timer) -> None:
        """Periodic scan of Claude processes."""
        try:
            summary = self._scanner.scan()
            self._last_summary = summary
            self._update_title(summary)
            self._update_menu(summary)
            self._alert_service.check_and_alert(summary.processes)
        except Exception as e:
            logger.error("Error during process poll: %s", e)

    def _update_title(self, summary: ProcessSummary) -> None:
        """Update menu bar title: crab + status indicators."""
        if summary.zombie > 0:
            self.title = f"{CRAB} 💀{summary.zombie}"
        elif summary.resource_alerts > 0:
            self.title = f"{CRAB} ⚠️{summary.resource_alerts}"
        elif summary.stale > 0:
            self.title = f"{CRAB} 🟡{summary.stale}"
        else:
            self.title = CRAB

    def _update_menu(self, summary: ProcessSummary) -> None:
        """Rebuild the dropdown menu with current processes."""
        self.menu.clear()

        # Open dashboard (top item for easy access)
        self.menu.add(rumps.MenuItem(
            "🌐 Open Dashboard",
            callback=self._open_dashboard,
        ))
        self.menu.add(rumps.separator)

        # Summary line
        mem_str = f"{summary.total_memory_mb:.0f}" if summary.total_memory_mb else "0"
        summary_parts = [f"{summary.total} processes", f"{mem_str} MB total"]
        if summary.resource_alerts > 0:
            summary_parts.append(f"⚠️ {summary.resource_alerts} resource alerts")
        self.menu.add(rumps.MenuItem(" | ".join(summary_parts), callback=None))
        self.menu.add(rumps.separator)

        # Process list
        if not summary.processes:
            self.menu.add(rumps.MenuItem("No Claude processes", callback=None))
        else:
            for proc in summary.processes:
                icon = HEALTH_ICONS.get(proc.health, "❓")

                # Check if CPU or memory exceed thresholds
                cpu_exceeds = proc.cpu_percent_of_system >= settings.resource_cpu_percent_threshold
                mem_exceeds = proc.memory_percent_of_system >= settings.resource_memory_percent_threshold

                # Add red circle indicator to values that exceed threshold
                cpu_str = f"CPU: {proc.cpu_percent:.1f}%"
                if cpu_exceeds:
                    cpu_str = f"🔴 {cpu_str}"

                mem_str = f"Mem: {proc.memory_total_mb:.0f}MB"
                if mem_exceeds:
                    mem_str = f"🔴 {mem_str}"

                # Build label with CPU, memory, and uptime
                label = (
                    f"{icon} {proc.pid} — {proc.project_name} "
                    f"({cpu_str}, {mem_str}, {proc.uptime_hours:.1f}h)"
                )

                # Add resource alert indicator if present
                if proc.resource_alert:
                    label = f"⚠️ {label}"

                proc_menu = rumps.MenuItem(label)

                # Add resource usage details if there's an alert
                if proc.resource_alert:
                    # Add red circles to system percentages that exceed threshold
                    sys_cpu_str = f"CPU {proc.cpu_percent_of_system:.1f}%"
                    if cpu_exceeds:
                        sys_cpu_str = f"🔴 {sys_cpu_str}"

                    sys_mem_str = f"Memory {proc.memory_percent_of_system:.1f}%"
                    if mem_exceeds:
                        sys_mem_str = f"🔴 {sys_mem_str}"

                    resource_info = rumps.MenuItem(
                        f"   System Usage: {sys_cpu_str}, {sys_mem_str}",
                        callback=None,
                    )
                    proc_menu.add(resource_info)

                kill_item = rumps.MenuItem(
                    f"🔪 Kill PID {proc.pid}",
                    callback=self._make_kill_callback(proc.pid),
                )
                proc_menu.add(kill_item)

                force_kill_item = rumps.MenuItem(
                    f"💀 Force Kill PID {proc.pid}",
                    callback=self._make_kill_callback(proc.pid, force=True),
                )
                proc_menu.add(force_kill_item)

                if proc.is_pinned:
                    pin_item = rumps.MenuItem(
                        f"📌 Unpin PID {proc.pid}",
                        callback=self._make_unpin_callback(proc.pid),
                    )
                else:
                    pin_item = rumps.MenuItem(
                        f"📌 Pin PID {proc.pid}",
                        callback=self._make_pin_callback(proc.pid),
                    )
                proc_menu.add(pin_item)

                self.menu.add(proc_menu)

        self.menu.add(rumps.separator)
        self.menu.add(rumps.MenuItem("🚪 Quit", callback=self._quit))

    def _open_dashboard(self, _sender: rumps.MenuItem) -> None:
        """Open the dashboard in a native webview window."""
        # Check if webview is already running
        if self._webview_proc and self._webview_proc.poll() is None:
            # Process still alive — bring to front by re-launching
            # (macOS doesn't let us raise another process's window easily)
            logger.info("Webview already running (PID %d)", self._webview_proc.pid)
            return

        # Launch webview as a subprocess (needs its own main thread on macOS)
        self._webview_proc = subprocess.Popen(
            [sys.executable, "-m", "tce.webview_window"],
            cwd=os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        )
        logger.info("Webview launched (PID %d)", self._webview_proc.pid)

    def _make_kill_callback(self, pid: int, force: bool = False):
        def callback(_sender):
            action = "force kill" if force else "kill"
            response = rumps.alert(
                title=f"Confirm {action}",
                message=f"Are you sure you want to {action} PID {pid}?",
                ok="Yes",
                cancel="No",
            )
            if response == 1:
                success, msg = self._scanner.kill_process(pid, force=force)
                if success:
                    rumps.notification("Terminus Cancrorum Est", "Process Killed", msg)
                else:
                    rumps.notification("Terminus Cancrorum Est", "Kill Failed", msg)
        return callback

    def _make_pin_callback(self, pid: int):
        def callback(_sender):
            self._scanner.pin(pid)
            rumps.notification("Terminus Cancrorum Est", "Pinned", f"PID {pid} pinned")
        return callback

    def _make_unpin_callback(self, pid: int):
        def callback(_sender):
            self._scanner.unpin(pid)
            rumps.notification("Terminus Cancrorum Est", "Unpinned", f"PID {pid} unpinned")
        return callback

    def _quit(self, _sender: rumps.MenuItem) -> None:
        """Clean up webview subprocess before quitting."""
        if self._webview_proc and self._webview_proc.poll() is None:
            try:
                os.kill(self._webview_proc.pid, signal.SIGTERM)
            except OSError:
                pass
        rumps.quit_application(_sender)
