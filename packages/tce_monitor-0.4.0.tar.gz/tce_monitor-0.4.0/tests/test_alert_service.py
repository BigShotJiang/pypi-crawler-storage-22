"""Tests for alert_service.py — resource alert notifications."""

import time
from unittest.mock import MagicMock, patch

import pytest

from tce.alert_service import AlertService
from tce.models import ClaudeProcess, HealthStatus, ResourceAlertType


@pytest.fixture
def alert_service():
    """Create an AlertService with mocked terminal-notifier."""
    with patch("tce.alert_service.shutil.which") as mock_which:
        mock_which.return_value = "/usr/local/bin/terminal-notifier"
        return AlertService()


def _make_process(
    pid: int = 1234,
    project_name: str = "test-project",
    health: HealthStatus = HealthStatus.HEALTHY,
    resource_alert: ResourceAlertType | None = None,
    cpu_percent_of_system: float = 0.0,
    memory_percent_of_system: float = 0.0,
    memory_total_mb: float = 100.0,
    uptime_hours: float = 1.0,
) -> ClaudeProcess:
    """Build a ClaudeProcess for testing."""
    return ClaudeProcess(
        pid=pid,
        project_name=project_name,
        health=health,
        resource_alert=resource_alert,
        cpu_percent_of_system=cpu_percent_of_system,
        memory_percent_of_system=memory_percent_of_system,
        memory_total_mb=memory_total_mb,
        uptime_hours=uptime_hours,
    )


class TestResourceAlertNotifications:
    """Test resource alert notification behavior."""

    @patch("tce.alert_service.subprocess.run")
    @patch("tce.alert_service.settings")
    def test_high_memory_alert_sent(self, mock_settings, mock_run, alert_service):
        mock_settings.resource_alert_cooldown = 1800

        proc = _make_process(
            pid=100,
            resource_alert=ResourceAlertType.HIGH_MEMORY,
            memory_percent_of_system=85.0,
            memory_total_mb=7000.0,
        )

        alert_service.check_and_alert([proc])

        # Verify notification was sent
        assert mock_run.called
        call_args = mock_run.call_args[0][0]
        assert "High Memory Usage" in " ".join(call_args)
        assert "85.0%" in " ".join(call_args)

    @patch("tce.alert_service.subprocess.run")
    @patch("tce.alert_service.settings")
    def test_high_cpu_alert_sent(self, mock_settings, mock_run, alert_service):
        mock_settings.resource_alert_cooldown = 1800

        proc = _make_process(
            pid=100,
            resource_alert=ResourceAlertType.HIGH_CPU,
            cpu_percent_of_system=90.0,
        )

        alert_service.check_and_alert([proc])

        # Verify notification was sent
        assert mock_run.called
        call_args = mock_run.call_args[0][0]
        assert "High CPU Usage" in " ".join(call_args)
        assert "90.0%" in " ".join(call_args)

    @patch("tce.alert_service.subprocess.run")
    @patch("tce.alert_service.settings")
    def test_both_resources_alert_sent(self, mock_settings, mock_run, alert_service):
        mock_settings.resource_alert_cooldown = 1800

        proc = _make_process(
            pid=100,
            resource_alert=ResourceAlertType.BOTH,
            cpu_percent_of_system=80.0,
            memory_percent_of_system=85.0,
        )

        alert_service.check_and_alert([proc])

        # Verify notification was sent
        assert mock_run.called
        call_args = mock_run.call_args[0][0]
        assert "High Resource Usage" in " ".join(call_args)
        assert "80.0%" in " ".join(call_args)
        assert "85.0%" in " ".join(call_args)

    @patch("tce.alert_service.subprocess.run")
    @patch("tce.alert_service.settings")
    def test_no_alert_when_no_resource_issue(self, mock_settings, mock_run, alert_service):
        mock_settings.resource_alert_cooldown = 1800

        proc = _make_process(pid=100, resource_alert=None)

        alert_service.check_and_alert([proc])

        # Only stale/zombie alerts should have been checked, no resource alert
        # Since health is HEALTHY, no notification should be sent at all
        assert not mock_run.called

    @patch("tce.alert_service.subprocess.run")
    @patch("tce.alert_service.settings")
    def test_resource_alert_cooldown_respected(self, mock_settings, mock_run, alert_service):
        mock_settings.resource_alert_cooldown = 1800

        proc = _make_process(
            pid=100,
            resource_alert=ResourceAlertType.HIGH_MEMORY,
            memory_percent_of_system=85.0,
        )

        # First alert should go through
        alert_service.check_and_alert([proc])
        assert mock_run.call_count == 1

        # Immediate second alert should be suppressed
        mock_run.reset_mock()
        alert_service.check_and_alert([proc])
        assert not mock_run.called

    @patch("tce.alert_service.subprocess.run")
    @patch("tce.alert_service.settings")
    def test_stale_and_resource_alerts_independent(self, mock_settings, mock_run, alert_service):
        """Test that stale alerts and resource alerts use separate cooldowns."""
        mock_settings.alert_cooldown = 1800
        mock_settings.resource_alert_cooldown = 1800

        # Process that is both stale AND has high resource usage
        proc = _make_process(
            pid=100,
            health=HealthStatus.STALE,
            resource_alert=ResourceAlertType.HIGH_MEMORY,
            memory_percent_of_system=85.0,
            uptime_hours=5.0,
        )

        alert_service.check_and_alert([proc])

        # Should send two separate notifications
        assert mock_run.call_count == 2

    @patch("tce.alert_service.subprocess.run")
    def test_cleanup_stale_resource_alerts(self, mock_run, alert_service):
        """Test that resource alert tracking is cleaned up for dead processes."""
        proc1 = _make_process(
            pid=100,
            resource_alert=ResourceAlertType.HIGH_MEMORY,
            memory_percent_of_system=85.0,
        )
        proc2 = _make_process(
            pid=101,
            resource_alert=ResourceAlertType.HIGH_CPU,
            cpu_percent_of_system=90.0,
        )

        # Alert for both
        alert_service.check_and_alert([proc1, proc2])
        assert 100 in alert_service._last_resource_alert
        assert 101 in alert_service._last_resource_alert

        # Only proc1 still exists
        alert_service.check_and_alert([proc1])
        assert 100 in alert_service._last_resource_alert
        assert 101 not in alert_service._last_resource_alert
