import sys
import os
from importlib.metadata import version


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import TDS_Fabric
from pyspark.sql import functions as F
from pyspark.sql.types import *

def getKeyvaultUrl(keyvaultName):
    return f"https://{keyvaultName}.vault.azure.net/"

def getSecret(secretName, keyvaultName=None):
    if keyvaultName is not None:
        return TDS_Fabric._notebookutils.credentials.getSecret(getKeyvaultUrl(keyvaultName), secretName)
    else:
        return TDS_Fabric._notebookutils.credentials.getSecret(TDS_Fabric.keyvaultUrl, secretName)

def getVersion():
    print(version("TDS_Fabric"))


