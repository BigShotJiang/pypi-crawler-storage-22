# How to build here for

python -m pip install --upgrade pip
python -m pip install --upgrade hatchling
python -m pip install --upgrade twine
python -m pip install --upgrade build
python -m build
python -m twine upload --repository testpypi dist/*
python -m twine upload --repository pypi dist/*     

python -m pip freeze > requirements.txt

python -m pip install -r requirements.txt


# For install in notebook
pip install 




import TDS_Fabric as TDS
TDS.init.modules(notebookutils=notebookutils, spark=spark,AFAS_Verkooprelatie="12952")
TDS.verstuurServicemelding(INPUT)
