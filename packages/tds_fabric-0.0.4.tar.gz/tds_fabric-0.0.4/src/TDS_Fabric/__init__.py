from pyspark.sql import functions as F
from pyspark.sql.types import *
from .monitoring import verstuurServicemelding

_notebookutils = None
_spark = None
_AFAS_Verkooprelatie = None

schemaName = None
workspaceName = None
lakehouseName = None
keyvaultName = None
keyvaultUrl = None

typeMapping = {
    "BINARY": BinaryType(),
    "BOOLEAN": BooleanType(),
    "BYTE": ByteType(),
    "DATE": DateType(),
    "DOUBLE": DoubleType(),
    "FLOAT": FloatType(),
    "INTEGER": IntegerType(),
    "LONG": LongType(),
    "STRING": StringType(),
    "TIMESTAMP": TimestampType()
}

