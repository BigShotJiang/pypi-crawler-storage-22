import sys
import os
import requests

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import TDS_Fabric as TDS


def getBaseUrl():
    ToschAFASMember = "83164"   # AFAS online member id is required for the api url.
    base_url = f'https://{ToschAFASMember}.rest.afas.online/ProfitRestServices/'
    return base_url

def autenticeerServicemelding(key_vault,client_id_name, client_secret_name):
    key_vault = "kv-afasservicemelding"
    ToschAFASMember = "83164"   # AFAS online member id is required for the api url.

    # Configuratie
    base_url = getBaseUrl()    

    CLIENT_ID =  TDS.utils.getSecret(client_id_name, key_vault)
    CLIENT_SECRET = TDS.utils.getSecret(client_secret_name, key_vault)
    TOKEN_URL = f"https://{ToschAFASMember}.rest.afas.online/ProfitRestServices/oauth/token"

    data = {
        "grant_type": "client_credentials",
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "scope": "afas"  # required by AFAS
    }

    response = requests.post(TOKEN_URL, data=data)
    access_token = response.json()["access_token"]
    try:
        access_token = access_token
        header = {'Authorization': f'Bearer {access_token}'}
        return header
    except Exception as e:
        print(f"Fout bij het verkrijgen van het access token: {e}")
        raise



def verstuurServicemelding(key_vault="kv-afasservicemelding",client_id_name = "afas-servicemelding-clientid", client_secret_name="afas-servicemelding-clientsecret"):
    headers = autenticeerServicemelding(key_vault=key_vault, client_id_name=client_id_name, client_secret_name=client_secret_name   )
    verkooprelatie_id = TDS._AFAS_Verkooprelatie
    instuurder = "83164.zz"
    
    subject = "Alert: " + "Titel"
    context = "Toelichting"
    pipeline = "87e52f09-a490-4bdc-bea2-4472142eca56"
    pipelineRunID = "f145ef9f-3e1a-41d1-839e-952775b84358"
    notebooks = "notebooks"
    workspace = "9f0b12aa-d2a7-46eb-a307-2c214b5b9804"
    monitoring_url = f"https://app.powerbi.com/workloads/data-pipeline/artifactAuthor/workspaces/{workspace}/pipelines/{pipeline}/{pipelineRunID}?experience=power-bi"
    
    if checkServicemeldingExist(pipeline):
        print("Servicemelding bestaat al")
        return
    

    payload = {
        "KnSubject": {
            "Element": {
                "Fields": {
                    "StId": 21,
                    "Ds":  subject,
                    "SbTx": context,
                    "UsId": instuurder,
                    #"EmId": verantwoordelijke,
                    "ViPr": "L",
                    "FvF1": 256
                },
                "Objects": [
                    {
                        "KnSubjectLink": {
                            "Element": {
                                "Fields": {
                                    "ToSR": True,
                                    "SfTp": 4,
                                    "SfId": verkooprelatie_id
                                }
                            }
                        }
                    },
                    {
                        "KnS01": {
                            "Element": {
                                "Fields": {
                                    "U82630274481AD0D5BEBEE5998D00F4A2": "08",
                                    "UB8F9A9A16617425CBC02FD0023AD021A": monitoring_url,
                                    "U7C069BA078A54B3284F9332FE701896A": pipeline,
                                    "U4EEE081D389B4714A5F5A2A3015604E8": workspace,
                                    "UB1F2ED1A9EE646BFA44245BBB703891D": notebooks
                                }
                            }
                        }
                    }
                ]
            }
        }
    }
    base_url =getBaseUrl()   
    url = f"{base_url}/connectors/KnSubject"
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code == 201:
        responseJson = response.json()
        dossierItem_id = responseJson["results"]["KnSubject"]["SbId"]
        return dossierItem_id
    else:
        raise Exception(f"Status: {response.status_code}, Response: {response.text}")
    
    return response     

def checkServicemeldingExist(pipeline):
    return False



def logRun():
    pass