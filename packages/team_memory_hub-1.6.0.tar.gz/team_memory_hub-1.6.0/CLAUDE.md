# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

---

## 项目概述

**Team Memory Hub (TMH)** 是一个面向开发团队的 AI 上下文记忆管理与分发系统。V1.6 版本已实现完整的后端 API、MCP Server、Dashboard 和测试套件。

### 核心功能
- 团队知识库的集体记忆分发
- 基于 SQLite 索引 + 文件存储的双引擎架构
- 分层上传（Hook > Script > MCP）+ 预注入读取的 token 优化
- 混合搜索引擎（BM25 + 向量 Score Fusion）
- 建议式记忆整合与自动去重
- MCP Server 全 CRUD（5 个工具，tool_set 配置）

---

## 项目结构

```
src/team_memory_hub/
  config.py               # TOML + 环境变量配置
  server/
    app.py                # FastAPI 应用（路由注册、中间件、生命周期）
    dependencies.py       # DI 工厂（get_db, get_current_user, require_role）
    event_bus.py          # asyncio 发布/订阅事件总线
    mcp_server.py         # MCP JSON-RPC Server（V1.6 全 CRUD）
    routes/               # API 路由（auth, keys, memories, search, curation, ...）
  core/
    memory_store.py       # 记忆 CRUD + 文件一致性
    memory_file_store.py  # 文件系统存储
    search_engine.py      # 混合搜索引擎
    context_engine.py     # 三层 Context 组装
    context_cache.py      # 缓存
    preference_engine.py  # 用户偏好引擎
    memory_consolidator.py # 合并建议
    rbac.py               # 权限矩阵
    audit.py              # 审计日志
    write_queue.py        # 异步写队列
  storage/
    database.py           # aiosqlite 封装 + 迁移
    migrations/           # v1.py, v1_5.py schema
    models.py             # Pydantic 数据模型
  providers/
    embedding/            # Gemini, OpenAI, ONNX, OpenAI-compatible
    llm/                  # Claude, Gemini, Rules engine
  chat_adapters/          # Claude Code, Cursor, OpenCode, Chatbox, Codex
  dashboard/
    templates/            # Jinja2 + HTMX（base, index, memories, search, ...）
    static/               # CSS
tests/                    # pytest 测试套件
main.py                   # uvicorn 入口
```

---

## 架构关键概念

### 1. 双引擎存储架构
- **SQLite**：存储元数据、摘要、向量索引、用户偏好和 FTS5 全文索引
- **文件系统**：存储规范原文（`specs/`）、记忆内容（`memories/`）、聊天记录（`chats/`）

### 2. 三层上传策略（零 token 优先）
1. **Tier 1 - Hook 自动回调**：零 token 消耗（Claude Code、OpenCode）
2. **Tier 2 - Python 脚本**：~100 tokens/次（Cursor、Codex）
3. **Tier 3 - MCP**：~200 tokens/次，兜底方案

### 3. 分层 Context 注入
- **Layer 0**：团队规范（pinned/verified），自动注入
- **Layer 1**：项目上下文，按 project_id 过滤
- **Layer 2**：按需搜索，通过 MCP/API 动态获取

### 4. MCP Server（V1.6）
- 5 个工具：`search_memory`, `get_memory_detail`, `store_memory`, `update_memory`, `delete_memory`
- `tool_set` 配置：`read_only` / `read_write` / `full_crud`
- RBAC 权限矩阵：每个工具有最低角色要求

---

## 技术栈

### 后端
- **Python 3.11+** / **FastAPI** / **uvicorn**
- **SQLite**（aiosqlite + sqlite-vec + FTS5）
- **Pydantic v2** 数据验证

### AI 服务（可选依赖）
- **Embedding**：Gemini / OpenAI / ONNX 本地 / OpenAI-compatible（Ollama/vLLM）
- **LLM**：Claude（anthropic）/ Gemini（google-generativeai）/ Rules engine（无 LLM 降级）

### 前端（Dashboard）
- **Jinja2** 模板 + **HTMX** 动态交互
- **Pico CSS** 极简样式 + **Chart.js** 趋势图

### 认证与权限
- **认证**：API Key + JWT 双模式
- **权限**：RBAC（admin / maintainer / member / viewer）

---

## 开发指南

### 启动服务
```bash
python main.py                     # 默认 0.0.0.0:8000
python main.py --port 9000         # 自定义端口
python main.py --reload            # 开发模式
```

### 运行测试
```bash
pytest                             # 运行所有测试
pytest tests/test_memories.py      # 单文件
pytest -x --tb=short               # 快速失败模式
```

### 命名规范
- Python 模块：snake_case
- API 端点：RESTful（`/api/memories`, `/api/curation/memories/{id}/verify`）
- 环境变量：大写下划线（`TMH_SERVER_HOST`, `TMH_MCP_TOOL_SET`）
- 数据模型中使用中文枚举名：`Memory范围`, `质量状态`, `Memory类别`

### 关键代码模式
- `from __future__ import annotations` — 所有模块头部
- FastAPI `Depends()` 注入 — `get_db()`, `get_current_user()`, `require_role()`
- `_try_include_router()` — 条件路由加载（静默跳过缺失模块）
- `MemoryStore` — 文件 + 索引一致性保证（写文件 → 写索引 → 失败补偿删文件）

---

## 关键设计决策

- **SQLite**：轻量级、FTS5 + sqlite-vec、适合团队规模、单文件备份
- **三层上传**：Hook 零 token > Script 低 token > MCP 兜底
- **混合搜索**：BM25 精确匹配 + 向量语义相似 + Score Fusion
- **MCP tool_set**：按部署场景控制工具暴露（read_only 给只读客户端，full_crud 给管理工具）

---

## 文档

- `docs/Team Memory Hub (TMH) — 系统架构设计 V1.6.md`：完整架构设计文档
