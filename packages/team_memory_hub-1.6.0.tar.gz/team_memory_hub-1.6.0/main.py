"""Team Memory Hub — 入口点。

启动方式:
    python main.py                    # 默认 0.0.0.0:8000
    python main.py --port 9000        # 自定义端口
    python main.py --reload           # 开发模式（热重载）
    uvicorn team_memory_hub.server.app:app  # 直接 uvicorn
"""

from __future__ import annotations

import argparse
import logging
import sys


def main() -> None:
    parser = argparse.ArgumentParser(description="Team Memory Hub Server")
    parser.add_argument("--host", default=None, help="绑定地址 (默认: 配置文件或 0.0.0.0)")
    parser.add_argument("--port", type=int, default=None, help="监听端口 (默认: 配置文件或 8000)")
    parser.add_argument("--reload", action="store_true", help="开发模式热重载")
    parser.add_argument("--config", default=None, help="配置文件路径 (默认: tmh.toml)")
    parser.add_argument("--log-level", default=None, help="日志级别 (DEBUG/INFO/WARNING/ERROR)")
    args = parser.parse_args()

    # 加载配置
    from team_memory_hub.config import load_config, set_config

    config = load_config(config_path=args.config)
    set_config(config)

    # 应用命令行覆盖
    host = args.host or config.server.host
    port = args.port or config.server.port
    log_level = (args.log_level or config.logging.level).lower()

    logging.basicConfig(
        level=getattr(logging, log_level.upper(), logging.INFO),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    try:
        import uvicorn
    except ImportError:
        print("错误: 缺少 uvicorn 依赖。请执行: pip install uvicorn", file=sys.stderr)
        sys.exit(1)

    uvicorn.run(
        "team_memory_hub.server.app:app",
        host=host,
        port=port,
        reload=args.reload,
        log_level=log_level,
    )


if __name__ == "__main__":
    main()
