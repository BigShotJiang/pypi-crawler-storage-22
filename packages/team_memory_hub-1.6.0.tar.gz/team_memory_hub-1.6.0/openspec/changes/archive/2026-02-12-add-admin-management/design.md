## Context

TMH V1.6 已具备完整的后端 API、MCP Server 和基础 Dashboard（记忆浏览、搜索调试、合并审核）。但核心实体（Teams、Projects、Users、API Keys）的管理仍需通过 API 调用完成，缺少可视化管理界面。现有 RBAC 为四级角色粒度，对管理后台的操作控制不够精细。

当前 Dashboard 技术栈：Jinja2 + HTMX 1.9 + Pico CSS + Chart.js，SSR 渲染，无前端构建步骤。

## Goals / Non-Goals

**Goals:**
- 在现有 Dashboard 中扩展管理后台，实现 Teams / Projects / Users / API Keys / 记忆审核 / 系统配置的完整 CRUD 界面
- 在现有 RBAC 四级角色上叠加 `entity:action` 细粒度权限，支持角色默认权限 + 自定义覆盖
- 所有管理操作通过统一的 `/api/admin/*` API 端点暴露，Dashboard 通过 HTMX 调用
- 管理页面根据当前用户权限动态显示/隐藏操作按钮

**Non-Goals:**
- 不引入前端框架（React/Vue），继续使用 Jinja2 + HTMX
- 不实现多租户隔离（当前为单实例部署）
- 不实现操作审批流（如删除需二次确认即可，无需审批链）
- 不实现自定义角色定义（保持四级固定角色）

## Decisions

### D1: 管理页面路由结构

**决定**：在 `/dashboard/admin/` 下统一组织管理页面，与现有 Dashboard 页面并列。

```
/dashboard/admin/teams         → 团队管理
/dashboard/admin/projects      → 项目管理
/dashboard/admin/users         → 用户管理
/dashboard/admin/api-keys      → API Key 管理
/dashboard/admin/curation      → 记忆审核
/dashboard/admin/system        → 系统配置
```

**理由**：独立 `/admin/` 前缀便于权限中间件统一拦截，同时复用现有 `base.html` 布局。

**替代方案**：混合在现有 `/dashboard/` 路径下 → 权限控制更分散，且导航结构不清晰。

### D2: 细粒度权限实现方式

**决定**：扩展现有 `PERMISSIONS` 字典 + 新增 `permission_overrides` 表。

权限检查流程：
1. 查询 `permission_overrides` 表是否有该用户的自定义权限
2. 若有覆盖则使用覆盖值（allow/deny）
3. 若无覆盖则回退到 `PERMISSIONS` 字典中角色默认权限

新增权限点（`entity:action` 格式）：
```python
# 团队管理
"team:create": ADMIN,
"team:update": ADMIN,
"team:delete": ADMIN,
"team:list": MAINTAINER,

# 项目管理
"project:create": MAINTAINER,
"project:update": MAINTAINER,
"project:delete": ADMIN,
"project:list": MEMBER,

# 用户管理
"user:create": ADMIN,
"user:update": ADMIN,
"user:delete": ADMIN,
"user:list": ADMIN,
"user:toggle_active": ADMIN,

# API Key 管理（已有 key:create）
"key:list_all": ADMIN,
"key:revoke_any": ADMIN,

# 记忆审核
"curation:batch_verify": MAINTAINER,
"curation:batch_archive": MAINTAINER,
"curation:quality_override": ADMIN,

# 系统配置
"system:view_config": ADMIN,
"system:update_config": ADMIN,
```

**理由**：最小侵入性 — `check_permission()` 只需增加一次覆盖查询，现有调用方零修改。

**替代方案**：完整 ABAC（Attribute-Based Access Control）→ 过度设计，当前规模不需要。

### D3: 管理 API 设计

**决定**：新增 `server/routes/admin.py` 统一模块，API 路径 `/api/admin/*`。

```
# 团队
GET    /api/admin/teams                    → 列表（支持分页搜索）
POST   /api/admin/teams                    → 创建
GET    /api/admin/teams/{id}               → 详情
PUT    /api/admin/teams/{id}               → 更新
DELETE /api/admin/teams/{id}               → 删除

# 项目（同结构）
GET    /api/admin/projects
POST   /api/admin/projects
GET    /api/admin/projects/{id}
PUT    /api/admin/projects/{id}
DELETE /api/admin/projects/{id}

# 用户
GET    /api/admin/users
POST   /api/admin/users
GET    /api/admin/users/{id}
PUT    /api/admin/users/{id}
DELETE /api/admin/users/{id}
PATCH  /api/admin/users/{id}/toggle-active → 启用/禁用
PATCH  /api/admin/users/{id}/role          → 修改角色

# API Keys
GET    /api/admin/api-keys                 → 列表所有用户的 Key
DELETE /api/admin/api-keys/{id}            → 吊销任意 Key

# 记忆审核
GET    /api/admin/curation/memories        → 待审核记忆列表
POST   /api/admin/curation/batch           → 批量操作（verify/archive/pin）

# 系统配置
GET    /api/admin/system/config            → 获取运行时配置
PATCH  /api/admin/system/config            → 更新配置项
GET    /api/admin/system/stats             → 系统统计信息
```

**理由**：统一 `/api/admin/` 前缀，便于中间件统一鉴权；与现有 `/api/teams` 等端点分离，管理操作有独立的权限要求。

**替代方案**：直接在现有路由上增加管理功能 → 权限逻辑混杂，不利于审计。

### D4: Dashboard 模板组织

**决定**：管理页面模板放在 `dashboard/templates/admin/` 子目录，共享 `base.html` 但使用独立的导航块。

```
templates/
  admin/
    _layout.html              → 管理页面布局（继承 base.html，添加侧边栏）
    teams.html                → 团队管理
    projects.html             → 项目管理
    users.html                → 用户管理
    api_keys.html             → API Key 管理
    curation.html             → 记忆审核
    system.html               → 系统配置
    partials/
      entity_table.html       → 通用实体表格（HTMX 复用）
      entity_form.html        → 通用实体表单（创建/编辑）
      confirm_dialog.html     → 删除确认对话框
```

**理由**：`_layout.html` 继承 `base.html` 并添加管理侧边栏，保持样式统一；通用 partials 减少模板重复。

### D5: HTMX 交互模式

**决定**：采用 HTMX 标准模式实现 CRUD 交互。

- **列表加载**：`hx-get` + `hx-target="#content"` 无刷新分页
- **创建/编辑**：模态框表单，`hx-post`/`hx-put` 提交后 `hx-swap="outerHTML"` 刷新表格行
- **删除确认**：`hx-confirm` 属性或自定义确认对话框，`hx-delete` 后移除行
- **权限控制**：Jinja2 条件渲染 `{% if can('team:create') %}` 控制按钮显示

**理由**：与现有 Dashboard 的 HTMX 用法一致，零学习成本。

## Risks / Trade-offs

- **[权限覆盖查询性能]** → 每次权限检查多一次 DB 查询。缓解：使用内存 LRU 缓存（per-request），权限变更时失效。
- **[HTMX 表单验证局限]** → 服务端验证为主，前端无即时反馈。缓解：返回 HTML 片段包含错误信息，HTMX 自动替换。
- **[系统配置修改风险]** → 运行时修改配置可能导致不稳定。缓解：仅暴露安全的配置项（非核心参数），敏感配置保持 TOML/环境变量管理。
- **[Breaking change: check_permission]** → 签名扩展需要所有调用方兼容。缓解：新增可选参数 `user_id`，不传则保持原有逻辑。

## Open Questions

- 系统配置管理是否需要配置变更历史记录？（建议：V1 不实现，后续根据需求扩展）
- 删除团队时是否级联删除所有关联数据？（建议：软删除 + 阻止删除有活跃项目/用户的团队）
