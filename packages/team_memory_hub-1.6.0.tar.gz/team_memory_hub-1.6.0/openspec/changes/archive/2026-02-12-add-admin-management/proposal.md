## Why

TMH 目前的 Dashboard 仅提供只读的记忆浏览、搜索和合并建议审查功能，缺乏对系统核心实体（Teams、Projects、Users、API Keys）的可视化管理能力。管理员和维护者需要通过直接 API 调用或数据库操作来管理这些实体，效率低且容易出错。此外，现有 RBAC 仅提供四级角色粒度，无法精细控制"谁能创建团队"、"谁能删除项目"等操作级权限。

## What Changes

- 新增管理后台页面模块，在现有 Dashboard 中扩展 Teams、Projects、Users、API Keys、记忆审核、系统配置六个管理页面
- 新增细粒度权限系统，在现有 RBAC 四级角色基础上引入操作级权限（如 `team:create`、`project:delete`、`user:manage_roles`）
- 新增管理 API 端点，为每个实体提供完整的 CRUD REST API（部分已存在，需补全 PUT/PATCH 操作）
- 新增系统配置管理界面，支持在线查看和修改 TMH 运行时配置
- **BREAKING**：现有 RBAC `check_permission()` 函数签名将扩展以支持细粒度权限检查

## Capabilities

### New Capabilities
- `admin-entity-management`：Teams / Projects / Users / API Keys 四个实体的可视化 CRUD 管理页面，包含列表、创建、编辑、删除操作，支持按权限控制操作可见性
- `admin-system-config`：系统配置的在线查看与修改界面，包含运行参数、功能开关、记忆审核策略等配置项
- `fine-grained-permissions`：基于操作级的细粒度权限系统，在现有角色层级上叠加 `entity:action` 格式的权限点，支持角色默认权限 + 自定义权限覆盖

### Modified Capabilities
- `auth-and-rbac`：扩展权限检查机制，从纯角色级别检查升级为角色 + 操作级双层权限检查；新增权限点注册和查询接口
- `dashboard`：扩展导航结构和布局，新增管理后台侧边栏区域；调整基础模板以支持管理页面的独立布局需求

## Impact

- **代码影响**：`core/rbac.py`（权限矩阵扩展）、`server/dependencies.py`（权限注入增强）、`server/routes/`（新增管理路由）、`dashboard/templates/`（新增 6+ 模板文件）
- **API 影响**：新增 `/api/admin/*` 管理端点群，补全 Teams/Projects/Users 的 PUT/PATCH 操作
- **数据库影响**：可能新增 `permission_overrides` 表存储自定义权限覆盖；现有表结构不变
- **依赖影响**：无新增外部依赖，继续使用 Jinja2 + HTMX + Pico CSS 技术栈
- **兼容性影响**：`check_permission()` 签名变更为向后兼容的可选参数扩展，现有调用方无需修改
