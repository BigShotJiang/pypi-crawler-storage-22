## ADDED Requirements

### Requirement: Team management CRUD interface
系统 SHALL 在管理后台提供团队（Teams）的完整 CRUD 界面，路径 `/dashboard/admin/teams`。页面包含：团队列表（名称、成员数、项目数、创建时间）、创建表单（名称、初始设置）、编辑表单（名称、设置）、删除操作（需确认）。所有操作通过 `/api/admin/teams` API 端点实现。

#### Scenario: List all teams
- **WHEN** admin 用户访问 `/dashboard/admin/teams`
- **THEN** 显示所有团队的分页列表，包含名称、成员数量、项目数量、创建时间

#### Scenario: Create a new team
- **WHEN** admin 用户在创建表单中填写团队名称并提交
- **THEN** 系统创建团队并刷新列表，显示新创建的团队

#### Scenario: Edit team settings
- **WHEN** admin 用户点击团队的编辑按钮，修改名称或设置后提交
- **THEN** 系统更新团队信息，表格行原地刷新显示更新后的数据

#### Scenario: Delete team with safety check
- **WHEN** admin 用户点击删除按钮并确认
- **THEN** 若团队下有活跃用户或项目，系统返回错误提示禁止删除；若无关联数据则执行删除

#### Scenario: Insufficient permission to create team
- **WHEN** maintainer 角色用户尝试创建团队
- **THEN** 创建按钮不显示，直接调用 API 返回 403 Forbidden

### Requirement: Project management CRUD interface
系统 SHALL 在管理后台提供项目（Projects）的完整 CRUD 界面，路径 `/dashboard/admin/projects`。页面包含：项目列表（名称、所属团队、描述、技术栈、状态）、创建表单（名称、描述、所属团队选择、项目类型）、编辑表单、归档/删除操作。

#### Scenario: List projects with team filter
- **WHEN** 用户访问 `/dashboard/admin/projects` 并选择团队过滤器
- **THEN** 仅显示该团队下的项目列表

#### Scenario: Create project under team
- **WHEN** maintainer 用户填写项目名称、选择所属团队、输入描述后提交
- **THEN** 系统在指定团队下创建项目

#### Scenario: Edit project details
- **WHEN** 用户修改项目描述或类型后提交
- **THEN** 系统更新项目信息并刷新显示

#### Scenario: Delete project
- **WHEN** admin 用户删除项目并确认
- **THEN** 系统执行软删除（设置 is_active=False），项目从列表中消失

#### Scenario: Duplicate project name in same team
- **WHEN** 用户创建项目时使用同一团队内已存在的项目名称
- **THEN** 系统返回错误提示"项目名称在该团队内已存在"

### Requirement: User management CRUD interface
系统 SHALL 在管理后台提供用户（Users）的完整管理界面，路径 `/dashboard/admin/users`。页面包含：用户列表（名称、邮箱、角色、所属团队、状态、最后活跃时间）、创建表单（名称、邮箱、密码、角色、团队选择）、编辑表单（名称、邮箱、角色、团队）、启用/禁用操作、角色变更操作。

#### Scenario: List users with role filter
- **WHEN** admin 用户访问 `/dashboard/admin/users` 并选择角色过滤器
- **THEN** 仅显示指定角色的用户列表

#### Scenario: Create new user
- **WHEN** admin 用户填写姓名、邮箱、密码、选择角色和团队后提交
- **THEN** 系统创建用户，密码 SHALL 使用 bcrypt 哈希存储

#### Scenario: Change user role
- **WHEN** admin 用户通过角色下拉菜单修改目标用户的角色
- **THEN** 系统更新用户角色，该用户后续请求的权限立即生效

#### Scenario: Toggle user active status
- **WHEN** admin 用户点击禁用/启用按钮
- **THEN** 系统切换用户的 is_active 状态；被禁用用户的后续 API 请求 SHALL 返回 401

#### Scenario: Cannot delete self
- **WHEN** admin 用户尝试删除自己的账户
- **THEN** 系统返回错误提示"不能删除当前登录的用户"

### Requirement: API Key management interface
系统 SHALL 在管理后台提供 API Key 管理界面，路径 `/dashboard/admin/api-keys`。页面包含：所有用户的 Key 列表（Key ID、所属用户、名称、scope、创建时间、最后使用时间、状态）、吊销操作。

#### Scenario: List all API keys
- **WHEN** admin 用户访问 `/dashboard/admin/api-keys`
- **THEN** 显示系统中所有用户的 API Key 列表（Key 值 SHALL 仅显示前 8 位 + 掩码）

#### Scenario: Filter API keys by user
- **WHEN** admin 用户选择用户过滤器
- **THEN** 仅显示该用户的 API Key 列表

#### Scenario: Revoke API key
- **WHEN** admin 用户点击吊销按钮并确认
- **THEN** 系统将 Key 设为 is_active=False，该 Key 立即失效

### Requirement: Memory curation management interface
系统 SHALL 在管理后台提供记忆审核管理界面，路径 `/dashboard/admin/curation`。页面包含：待审核记忆列表（按质量状态过滤）、批量操作（验证、置顶、归档、标记过时）、记忆详情查看。

#### Scenario: List memories pending review
- **WHEN** maintainer 用户访问 `/dashboard/admin/curation`
- **THEN** 默认显示 quality=community 的记忆列表，支持切换到其他质量状态

#### Scenario: Batch verify memories
- **WHEN** maintainer 用户勾选多条记忆并点击"批量验证"
- **THEN** 系统将选中记忆的 quality 更新为 verified，记录 verified_by 和 verified_at

#### Scenario: Batch archive stale memories
- **WHEN** maintainer 用户勾选多条过时记忆并点击"批量归档"
- **THEN** 系统将选中记忆的 quality 更新为 archived

#### Scenario: View memory detail in curation
- **WHEN** 用户点击记忆行展开详情
- **THEN** 显示记忆原文内容、元数据（标签、分类、来源聊天）和版本历史

### Requirement: Admin API endpoints
系统 SHALL 提供统一的管理 API 端点，前缀 `/api/admin/`。所有端点 SHALL 要求至少 maintainer 角色，具体操作按细粒度权限控制。

#### Scenario: Teams CRUD API
- **WHEN** 调用 `GET /api/admin/teams`（带分页参数 page、per_page）
- **THEN** 返回团队列表，包含每个团队的成员数和项目数聚合统计

#### Scenario: Users management API
- **WHEN** 调用 `PATCH /api/admin/users/{id}/role` 并指定新角色
- **THEN** 系统更新用户角色并返回更新后的用户信息

#### Scenario: Batch curation API
- **WHEN** 调用 `POST /api/admin/curation/batch` 并指定 action=verify 和 memory_ids 列表
- **THEN** 系统批量更新指定记忆的质量状态

#### Scenario: Unauthorized admin API access
- **WHEN** viewer 角色用户调用任何 `/api/admin/*` 端点
- **THEN** 系统返回 403 Forbidden

### Requirement: HTMX-driven CRUD interactions
管理页面的所有 CRUD 操作 SHALL 通过 HTMX 实现无刷新交互。创建/编辑使用模态框表单，删除使用确认对话框，列表支持无刷新分页和过滤。

#### Scenario: Create entity via modal form
- **WHEN** 用户点击"新建"按钮
- **THEN** 弹出模态框表单，提交后模态框关闭，列表自动刷新显示新记录

#### Scenario: Inline edit entity
- **WHEN** 用户点击编辑按钮
- **THEN** 弹出预填数据的模态框表单，提交后对应表格行原地更新

#### Scenario: Delete with confirmation
- **WHEN** 用户点击删除按钮
- **THEN** 显示确认对话框，确认后对应行从列表中移除（HTMX swap delete）

#### Scenario: Paginated list loading
- **WHEN** 用户点击下一页或更改每页数量
- **THEN** 仅更新列表区域，不刷新整个页面
