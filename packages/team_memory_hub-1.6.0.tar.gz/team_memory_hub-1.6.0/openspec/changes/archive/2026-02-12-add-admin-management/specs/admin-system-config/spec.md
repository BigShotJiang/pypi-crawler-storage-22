## ADDED Requirements

### Requirement: System configuration view
系统 SHALL 在管理后台提供系统配置查看界面，路径 `/dashboard/admin/system`。页面 SHALL 显示当前运行时配置参数，按分组组织（服务器、搜索、嵌入、MCP、安全等）。

#### Scenario: View system configuration
- **WHEN** admin 用户访问 `/dashboard/admin/system`
- **THEN** 显示当前系统配置参数，按分类分组（server、search、embedding、mcp、security）

#### Scenario: Non-admin cannot view system config
- **WHEN** maintainer 角色用户访问 `/dashboard/admin/system`
- **THEN** 系统返回 403 Forbidden 或重定向到无权限提示页

### Requirement: Runtime configuration editing
系统 SHALL 支持在线修改部分运行时配置参数。可修改参数 SHALL 限定为安全参数（如搜索结果数量、缓存 TTL、分页默认值等），核心参数（如数据库路径、密钥、端口）SHALL 保持只读。

#### Scenario: Edit safe configuration parameter
- **WHEN** admin 用户修改 search.default_limit 的值并保存
- **THEN** 系统更新运行时配置，后续请求使用新值

#### Scenario: Cannot edit read-only parameter
- **WHEN** admin 用户尝试修改 server.host 等核心参数
- **THEN** 该参数 SHALL 显示为只读状态，不提供编辑功能

#### Scenario: Invalid configuration value
- **WHEN** admin 用户输入非法值（如负数的 limit）
- **THEN** 系统返回验证错误提示，不应用变更

### Requirement: System statistics dashboard
系统 SHALL 在系统配置页面提供系统运行统计信息，包含：数据库大小、记忆总数、用户总数、团队总数、项目总数、API 调用统计、搜索引擎状态。

#### Scenario: View system statistics
- **WHEN** admin 用户查看系统统计区域
- **THEN** 显示各项统计数据的当前值

#### Scenario: Statistics auto-refresh
- **WHEN** 页面保持打开超过 30 秒
- **THEN** 统计数据 SHALL 通过 HTMX 轮询自动刷新

### Requirement: System config API
系统 SHALL 提供系统配置 API 端点 `/api/admin/system/config` 和 `/api/admin/system/stats`，仅 admin 角色可访问。

#### Scenario: Get configuration
- **WHEN** 调用 `GET /api/admin/system/config`
- **THEN** 返回所有配置参数，每个参数标记 editable=true/false

#### Scenario: Update configuration
- **WHEN** 调用 `PATCH /api/admin/system/config` 并提交配置变更
- **THEN** 系统验证参数合法性后更新运行时配置，返回更新后的配置

#### Scenario: Get system stats
- **WHEN** 调用 `GET /api/admin/system/stats`
- **THEN** 返回系统统计信息（数据库大小、各实体计数、搜索引擎状态）
