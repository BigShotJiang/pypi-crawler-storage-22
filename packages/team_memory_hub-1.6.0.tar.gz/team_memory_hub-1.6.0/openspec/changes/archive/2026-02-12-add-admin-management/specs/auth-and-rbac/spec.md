## MODIFIED Requirements

### Requirement: RBAC four-tier roles
系统 SHALL 实现四级角色权限控制：admin > maintainer > member > viewer。

权限矩阵：
- admin：全部操作
- maintainer：读写记忆、合并提案、处理合并建议、标记 verified、设置团队偏好、管理所属团队项目
- member：读写记忆、创建提案、管理私有数据
- viewer：只读团队记忆

`check_permission()` 函数 SHALL 支持新增可选参数 `user_id: str | None = None`。当传入 `user_id` 时，系统 SHALL 先查询 `permission_overrides` 表检查是否有该用户的权限覆盖，有覆盖则使用覆盖值（allow 返回 True，deny 返回 False），无覆盖则回退到基于角色级别的默认检查逻辑。不传 `user_id` 时行为与修改前完全一致。

新增权限点（追加到现有 PERMISSIONS 字典）：
- `team:create` → ADMIN
- `team:update` → ADMIN
- `team:delete` → ADMIN
- `team:list` → MAINTAINER
- `project:create` → MAINTAINER
- `project:update` → MAINTAINER
- `project:delete` → ADMIN
- `project:list` → MEMBER
- `user:create` → ADMIN
- `user:update` → ADMIN
- `user:delete` → ADMIN
- `user:list` → ADMIN
- `user:toggle_active` → ADMIN
- `key:list_all` → ADMIN
- `key:revoke_any` → ADMIN
- `curation:batch_verify` → MAINTAINER
- `curation:batch_archive` → MAINTAINER
- `curation:quality_override` → ADMIN
- `system:view_config` → ADMIN
- `system:update_config` → ADMIN

#### Scenario: Member creates proposal
- **WHEN** member 角色用户调用 `POST /api/specs/proposals`
- **THEN** 系统创建提案成功

#### Scenario: Member cannot merge proposal
- **WHEN** member 角色用户尝试调用 `POST /api/specs/proposals/:id/merge`
- **THEN** 系统返回 403 Forbidden

#### Scenario: Viewer cannot write memory
- **WHEN** viewer 角色用户尝试调用 `POST /api/memories`
- **THEN** 系统返回 403 Forbidden

#### Scenario: Permission check with user override
- **WHEN** 调用 `check_permission(role=MEMBER, permission="project:create", user_id="usr_xxx")`，且该用户有 allow 覆盖
- **THEN** 返回 True（覆盖优先于角色默认的 MAINTAINER 要求）

#### Scenario: Permission check without user_id is backward compatible
- **WHEN** 调用 `check_permission(role=MEMBER, permission="memory:read_team")`（不传 user_id）
- **THEN** 行为与修改前完全一致，仅基于角色级别判断
