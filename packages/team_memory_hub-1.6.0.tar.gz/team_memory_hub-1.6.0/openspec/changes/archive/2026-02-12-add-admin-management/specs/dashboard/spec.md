## MODIFIED Requirements

### Requirement: Dashboard web interface
系统 SHALL 提供 Web Dashboard（`GET /dashboard/*`），使用 Jinja2 SSR + HTMX 实现，供管理员管理团队记忆、规范、合并建议。

Dashboard SHALL 新增管理后台区域（`/dashboard/admin/*`），包含以下管理页面：
- `/dashboard/admin/teams` — 团队管理
- `/dashboard/admin/projects` — 项目管理
- `/dashboard/admin/users` — 用户管理
- `/dashboard/admin/api-keys` — API Key 管理
- `/dashboard/admin/curation` — 记忆审核
- `/dashboard/admin/system` — 系统配置

管理页面 SHALL 使用独立的布局模板（`admin/_layout.html`），继承 `base.html` 并添加管理侧边栏导航。侧边栏 SHALL 根据用户权限动态显示可访问的管理页面链接。

#### Scenario: Access dashboard
- **WHEN** 用户访问 `/dashboard/`
- **THEN** 显示团队概览页面，包含记忆统计、待处理建议数、最近活动

#### Scenario: Access admin section
- **WHEN** admin 用户点击导航栏中的"管理后台"链接
- **THEN** 进入管理区域，显示管理侧边栏和默认管理页面（团队管理）

#### Scenario: Admin navigation sidebar
- **WHEN** admin 用户进入管理区域
- **THEN** 侧边栏显示所有 6 个管理页面链接，当前页面高亮

#### Scenario: Maintainer limited admin navigation
- **WHEN** maintainer 用户进入管理区域
- **THEN** 侧边栏仅显示有权限访问的页面（如项目管理、记忆审核），不显示系统配置

#### Scenario: Member/Viewer cannot access admin
- **WHEN** member 或 viewer 用户尝试访问 `/dashboard/admin/*`
- **THEN** 系统重定向到 Dashboard 首页或显示权限不足提示

#### Scenario: Admin link in main navigation
- **WHEN** 有管理权限的用户查看 Dashboard 主导航
- **THEN** 导航栏 SHALL 显示"管理后台"入口链接；无权限用户不显示此链接
