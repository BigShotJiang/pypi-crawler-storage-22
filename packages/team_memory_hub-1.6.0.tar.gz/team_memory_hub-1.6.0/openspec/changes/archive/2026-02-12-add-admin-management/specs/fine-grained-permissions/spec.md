## ADDED Requirements

### Requirement: Operation-level permission definitions
系统 SHALL 在现有 RBAC 四级角色基础上支持 `entity:action` 格式的操作级权限点。每个权限点有默认的最低角色要求。权限点 SHALL 涵盖以下实体操作：

- `team:create`、`team:update`、`team:delete`、`team:list`
- `project:create`、`project:update`、`project:delete`、`project:list`
- `user:create`、`user:update`、`user:delete`、`user:list`、`user:toggle_active`
- `key:list_all`、`key:revoke_any`
- `curation:batch_verify`、`curation:batch_archive`、`curation:quality_override`
- `system:view_config`、`system:update_config`

#### Scenario: Permission point registered with default role
- **WHEN** 系统启动并加载权限配置
- **THEN** 每个 `entity:action` 权限点 SHALL 关联一个默认最低角色（如 `team:create` → admin）

#### Scenario: Check permission by role default
- **WHEN** 用户角色为 maintainer，请求需要 `project:create`（默认 maintainer）权限的操作
- **THEN** 权限检查通过

#### Scenario: Insufficient role for permission
- **WHEN** 用户角色为 member，请求需要 `team:create`（默认 admin）权限的操作
- **THEN** 权限检查失败，返回 403 Forbidden

### Requirement: Permission override mechanism
系统 SHALL 支持为特定用户覆盖默认权限。覆盖存储在 `permission_overrides` 表中，支持 allow 和 deny 两种类型。覆盖优先级高于角色默认权限。

#### Scenario: Grant permission override
- **WHEN** admin 为某 member 用户添加 `project:create` 的 allow 覆盖
- **THEN** 该 member 用户可以创建项目，尽管 member 角色默认无此权限

#### Scenario: Deny permission override
- **WHEN** admin 为某 maintainer 用户添加 `curation:batch_verify` 的 deny 覆盖
- **THEN** 该 maintainer 用户无法执行批量验证，尽管 maintainer 角色默认有此权限

#### Scenario: Override precedence over role
- **WHEN** 权限检查发现用户有覆盖记录
- **THEN** 系统 SHALL 使用覆盖值（allow/deny），忽略角色默认权限

### Requirement: Permission check function extension
`check_permission()` 函数 SHALL 扩展以支持细粒度权限检查。新增可选参数 `user_id`，传入时查询覆盖表；不传时保持原有纯角色检查逻辑，确保向后兼容。

#### Scenario: Backward compatible call without user_id
- **WHEN** 调用 `check_permission(role, "memory:read_team")` 不传 user_id
- **THEN** 行为与修改前完全一致，仅基于角色检查

#### Scenario: Call with user_id checks overrides
- **WHEN** 调用 `check_permission(role, "team:create", user_id="usr_xxx")`
- **THEN** 先查询该用户的覆盖，有覆盖用覆盖值，无覆盖用角色默认

### Requirement: Permission overrides database table
系统 SHALL 新增 `permission_overrides` 表存储权限覆盖记录。

表结构：
- `id` TEXT PRIMARY KEY
- `user_id` TEXT NOT NULL（外键 → users.id）
- `permission` TEXT NOT NULL（权限点名称）
- `type` TEXT NOT NULL（allow / deny）
- `granted_by` TEXT NOT NULL（授权者 user_id）
- `reason` TEXT（授权原因）
- `expires_at` DATETIME（可选过期时间）
- `created_at` DATETIME

约束：UNIQUE(user_id, permission)

#### Scenario: Create permission override record
- **WHEN** admin 通过 API 或界面为用户添加权限覆盖
- **THEN** 系统在 `permission_overrides` 表中插入记录，包含授权者和原因

#### Scenario: Expired override ignored
- **WHEN** 权限覆盖记录的 expires_at 已过期
- **THEN** 系统 SHALL 忽略该覆盖，回退到角色默认权限

### Requirement: Permission-aware UI rendering
管理后台页面 SHALL 根据当前用户的有效权限动态渲染操作按钮。无权限的操作按钮 SHALL 不显示（而非显示为禁用状态）。

#### Scenario: Admin sees all management buttons
- **WHEN** admin 用户访问管理页面
- **THEN** 显示所有 CRUD 操作按钮（创建、编辑、删除）

#### Scenario: Maintainer sees limited buttons
- **WHEN** maintainer 用户访问项目管理页面（无自定义覆盖）
- **THEN** 显示创建和编辑按钮，不显示删除按钮（`project:delete` 默认需要 admin）

#### Scenario: Member with override sees extra buttons
- **WHEN** 有 `project:create` allow 覆盖的 member 用户访问项目管理页面
- **THEN** 显示创建按钮（来自覆盖），不显示编辑和删除按钮
