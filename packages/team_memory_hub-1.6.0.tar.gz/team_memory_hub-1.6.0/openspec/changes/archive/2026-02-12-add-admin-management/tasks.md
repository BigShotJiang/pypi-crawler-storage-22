## 1. 数据库与权限基础

- [x] 1.1 新增 `permission_overrides` 表的数据库迁移（v1_6.py），包含 id、user_id、permission、type、granted_by、reason、expires_at、created_at 字段，UNIQUE(user_id, permission) 约束
- [x] 1.2 在 `storage/models.py` 中新增 `PermissionOverride`、`PermissionOverrideCreate` Pydantic 模型
- [x] 1.3 扩展 `core/rbac.py` 的 `PERMISSIONS` 字典，添加所有新权限点（team:*、project:*、user:*、key:*、curation:*、system:*）
- [x] 1.4 扩展 `check_permission()` 函数，新增可选参数 `user_id`，实现覆盖查询逻辑（覆盖优先 → 角色默认回退）
- [x] 1.5 编写权限系统单元测试：覆盖优先级、过期覆盖忽略、向后兼容性

## 2. 管理 API 端点

- [x] 2.1 创建 `server/routes/admin.py` 路由模块，注册到 `/api/admin` 前缀
- [x] 2.2 实现 Teams CRUD API：`GET/POST /api/admin/teams`、`GET/PUT/DELETE /api/admin/teams/{id}`，包含成员数和项目数聚合查询
- [x] 2.3 实现 Projects CRUD API：`GET/POST /api/admin/projects`、`GET/PUT/DELETE /api/admin/projects/{id}`，支持团队过滤，软删除逻辑
- [x] 2.4 实现 Users 管理 API：`GET/POST /api/admin/users`、`GET/PUT/DELETE /api/admin/users/{id}`、`PATCH .../toggle-active`、`PATCH .../role`，包含自删除保护
- [x] 2.5 实现 API Keys 管理 API：`GET /api/admin/api-keys`（列表所有用户 Key）、`DELETE /api/admin/api-keys/{id}`（吊销）
- [x] 2.6 实现记忆审核批量 API：`GET /api/admin/curation/memories`、`POST /api/admin/curation/batch`（批量 verify/archive/pin）
- [x] 2.7 实现系统配置 API：`GET /api/admin/system/config`、`PATCH /api/admin/system/config`、`GET /api/admin/system/stats`
- [x] 2.8 在 `app.py` 中注册 admin 路由（使用 `_try_include_router` 条件加载模式）
- [x] 2.9 编写管理 API 端点集成测试：CRUD 操作、权限拦截、边界条件

## 3. Dashboard 管理布局

- [x] 3.1 创建 `templates/admin/_layout.html` 管理布局模板，继承 `base.html`，添加管理侧边栏导航
- [x] 3.2 修改 `templates/base.html`，在主导航栏添加"管理后台"入口链接（权限条件渲染）
- [x] 3.3 创建 `templates/admin/partials/entity_table.html` 通用实体表格模板（HTMX 分页复用）
- [x] 3.4 创建 `templates/admin/partials/entity_form.html` 通用模态框表单模板（创建/编辑复用）
- [x] 3.5 创建 `templates/admin/partials/confirm_dialog.html` 删除确认对话框模板
- [x] 3.6 添加管理后台 CSS 样式到 `dashboard/static/` 目录

## 4. 管理页面实现

- [x] 4.1 创建 `server/routes/admin_dashboard.py` 管理 Dashboard 路由模块
- [x] 4.2 实现 Teams 管理页面 `templates/admin/teams.html`：列表、创建/编辑模态框、删除确认、HTMX 交互
- [x] 4.3 实现 Projects 管理页面 `templates/admin/projects.html`：列表（团队过滤）、创建/编辑模态框、软删除
- [x] 4.4 实现 Users 管理页面 `templates/admin/users.html`：列表（角色过滤）、创建/编辑模态框、启用/禁用开关、角色变更
- [x] 4.5 实现 API Keys 管理页面 `templates/admin/api_keys.html`：列表（用户过滤）、Key 掩码显示、吊销操作
- [x] 4.6 实现记忆审核页面 `templates/admin/curation.html`：待审核列表（质量状态过滤）、批量操作工具栏、记忆详情展开
- [x] 4.7 实现系统配置页面 `templates/admin/system.html`：分组配置显示、可编辑参数表单、系统统计信息、自动刷新

## 5. 权限集成与安全

- [x] 5.1 在 `dependencies.py` 中新增 `require_permission(permission: str)` 依赖工厂，结合 user_id 进行细粒度权限检查
- [x] 5.2 为所有管理 API 端点添加 `require_permission()` 依赖注入
- [x] 5.3 在 Jinja2 模板上下文中注入 `can(permission)` 辅助函数，用于条件渲染操作按钮
- [x] 5.4 实现管理区域路由级权限中间件，拦截无权限用户访问 `/dashboard/admin/*`

## 6. 测试与验证

- [x] 6.1 编写管理页面端到端测试：页面加载、CRUD 操作流、权限拦截
- [x] 6.2 编写细粒度权限完整测试：所有权限点、覆盖机制、过期处理、向后兼容
- [x] 6.3 验证现有测试通过（`check_permission` 向后兼容性）
- [x] 6.4 手动验证管理后台 UI 交互流畅性和响应式布局
