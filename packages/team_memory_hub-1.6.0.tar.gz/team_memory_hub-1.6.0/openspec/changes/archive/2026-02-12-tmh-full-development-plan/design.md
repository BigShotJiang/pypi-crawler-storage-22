## Context

TMH 当前状态为纯架构设计文档（V1.5），无可运行代码。需要将设计文档转化为完整实现。

约束条件：
- 后端语言锁定 Python，框架锁定 FastAPI
- 存储必须使用 SQLite（无外部数据库依赖），附带 sqlite-vec 向量扩展和 FTS5 全文索引
- Embedding 统一 384 维，通过 Provider 抽象层适配多种后端
- MCP Server 仅保留 2 个读取工具，写入全走 Hook/Script/HTTP API
- 面向 10-100 人团队规模，单机部署为主

## Goals / Non-Goals

**Goals:**
- 实现 V1.5 架构文档中定义的全部功能模块
- 支持 Claude Code / Cursor / OpenCode / Chatbox / Codex 五种 AI 工具的集成
- 提供 Docker 一键部署能力
- 核心模块测试覆盖率 > 80%
- API 响应时间 P95 < 200ms（搜索 < 500ms）

**Non-Goals:**
- OAuth 2.1 认证（V2 规划）
- 分布式/多节点部署
- Web Dashboard 的复杂前端框架（使用 Jinja2 SSR + HTMX 即可）
- 移动端适配
- 国际化/多语言 UI

## Decisions

### D1: 项目骨架与包管理

**选择**: 使用 `pyproject.toml` + `uv` 作为包管理工具，`src/team_memory_hub/` 布局

**理由**: uv 是最快的 Python 包管理器，src 布局防止隐式导入问题。pyproject.toml 是 PEP 标准。

**替代方案**:
- Poetry：成熟但速度慢，锁文件合并冲突多 → 弃用
- pip + requirements.txt：功能不足，无锁文件 → 弃用

### D2: 数据库迁移策略

**选择**: 使用手动版本化 SQL 脚本（`storage/migrations/v1.py`, `v1_5.py`），启动时自动检测并执行

**理由**: SQLite 不支持并发 schema 变更，且项目规模不需要 Alembic 的复杂性。版本号存在 `_meta` 表中。

**替代方案**:
- Alembic：过重，SQLite 的 ALTER TABLE 限制使其收益有限 → 弃用
- 无迁移（每次重建）：无法保留数据 → 弃用

### D3: 异步架构

**选择**: 全异步（async/await），FastAPI + uvicorn + httpx.AsyncClient + aiosqlite

**理由**: Embedding API 和 LLM API 调用是主要 I/O 瓶颈，异步可显著提升并发处理能力。SQLite 写入通过 asyncio.Queue 序列化。

**替代方案**:
- 同步 + 线程池：模型简单但难以处理 SSE → 弃用

### D4: 分阶段开发顺序

**选择**: 4 个开发阶段，按依赖拓扑排序

```
Phase 1 (基座层):  storage-engine → auth-and-rbac → memory-management
Phase 2 (核心引擎): embedding-providers → hybrid-search → context-engine → spec-management
Phase 3 (集成层):  upload-pipeline → chat-capture → mcp-server → user-preferences → client-integration → tmh-cli
Phase 4 (高级功能): memory-consolidation → curation-tasks → sse-events → dashboard
```

**理由**: 每个阶段结束时系统可独立验证。Phase 1 提供存储和 API 骨架，Phase 2 实现核心搜索和 Context 能力，Phase 3 打通工具集成，Phase 4 添加高级功能。

### D5: Dashboard 技术选型

**选择**: Jinja2 模板 + HTMX + 轻量 CSS（Pico CSS / simple.css）

**理由**: 避免引入 Node.js 工具链和前端构建流程。HTMX 提供动态交互（搜索过滤、表单提交、SSE 推送）而无需编写 JS。Dashboard 是管理工具，不需要 SPA 体验。

**替代方案**:
- React/Vue SPA：需要独立构建、部署、跨域配置 → 对管理工具过重
- Streamlit：快速原型但定制性差，不适合多页面管理端 → 弃用

### D6: 测试策略

**选择**: pytest + pytest-asyncio，分层测试

- **单元测试**: core/ 模块的纯逻辑（score fusion、聚类算法、规则归一化）
- **集成测试**: 使用内存 SQLite 数据库 + 临时文件目录，测试完整 CRUD 和搜索流程
- **API 测试**: httpx.AsyncClient + FastAPI TestClient
- **Provider 测试**: mock 外部 API（Embedding/LLM），避免真实调用

### D7: 配置管理

**选择**: TOML 配置文件 (`tmh.toml`) + 环境变量覆盖

```
tmh.toml（默认值）→ 环境变量覆盖 → CLI 参数覆盖
```

**理由**: TOML 可读性好，Python 3.11+ 内置 tomllib。环境变量用于 Docker 部署和密钥注入。

### D8: Embedding 维度统一策略

**选择**: 所有 Provider 输出统一截断/填充到 384 维，存储固定宽度向量

**理由**: sqlite-vec 要求固定维度。384 维在质量和存储之间取得平衡。切换 Provider 后通过 `migrate_embeddings` 增量重建向量。

### D9: 写入队列设计

**选择**: asyncio.Queue + 攒批提交（100ms 或 50 条触发），单写入者模式

**理由**: SQLite 不支持并发写入。队列序列化所有写入操作，攒批减少事务开销。busy_timeout=10s 防止写入超时。

### D10: 项目目录布局

```
team-memory-hub/
├── pyproject.toml
├── tmh.toml.example
├── Dockerfile / docker-compose.yml
├── src/team_memory_hub/
│   ├── server/         # FastAPI 应用 + 路由
│   ├── core/           # 业务逻辑引擎
│   ├── providers/      # Embedding + LLM Provider
│   ├── chat_adapters/  # 聊天格式适配
│   ├── client_adapters/# AI 工具集成适配
│   ├── storage/        # 数据库 + 文件存储
│   └── dashboard/      # Jinja2 模板 + 静态资源
├── cli/                # tmh CLI 入口
├── scaffold/           # 项目脚手架模板
└── tests/              # 测试套件
```

## Risks / Trade-offs

### R1: SQLite 并发写入限制
**风险**: 高频写入场景下，SQLite 的全局写锁可能成为瓶颈
**缓解**: 写入队列攒批处理 + WAL 模式 + busy_timeout。10-100 人团队规模下，写入 QPS 极低（<10/s），不会触及瓶颈

### R2: sqlite-vec 生态成熟度
**风险**: sqlite-vec 是相对较新的扩展，可能存在边缘情况 bug
**缓解**: 固定版本锁定，集成测试覆盖 KNN 搜索路径。必要时可退化为暴力 cosine 计算

### R3: LLM API 可用性
**风险**: 记忆提取、合并建议生成依赖外部 LLM API
**缓解**: 规则引擎作为降级方案（关键词+正则提取），合并建议可以排队等待 API 恢复

### R4: Embedding Provider 切换成本
**风险**: 切换 Provider 需要重建所有向量索引
**缓解**: `migrate_embeddings` 增量迁移任务，支持后台运行，迁移期间旧向量仍可用

### R5: FTS5 中文分词
**风险**: SQLite FTS5 默认的 unicode61 分词器对中文支持有限
**缓解**: 先用 unicode61 逐字符分词（可用但不完美），后续可引入 jieba 分词器作为 FTS5 tokenizer 插件

### R6: Dashboard 用户体验
**风险**: HTMX + Jinja2 方案的交互体验不如 SPA
**缓解**: Dashboard 是面向管理员的低频工具，核心操作（审核合并、标记质量）交互简单。确保关键流程流畅即可

## Migration Plan

不适用（全新项目，无需迁移）。

首次部署步骤：
1. `docker-compose up -d` 启动服务
2. 自动执行数据库迁移脚本，创建所有表和索引
3. 通过 CLI 或 API 创建管理员账户和团队
4. 各项目执行 `tmh init` 接入

## Open Questions

1. **中文 BM25 分词**：是否在 V1.5 首版就引入 jieba 分词器，还是先用 unicode61 然后 V2 优化？
2. **Dashboard 认证**：Dashboard 是否复用 JWT 认证，还是使用独立的 session-based 认证？
3. **数据备份策略**：SQLite 文件 + 文件目录的备份方案——直接 cp 还是使用 SQLite 的 online backup API？
4. **CI/CD 流程**：是否在首版就建立 GitHub Actions 自动化测试和发布流程？
