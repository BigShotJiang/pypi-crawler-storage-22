## Why

Team Memory Hub (TMH) 目前仅有架构设计文档（V1.5），没有任何可运行的代码实现。团队需要一个完整的开发计划，将 V1.5 架构设计从文档落地为可部署的系统。该系统解决的核心问题是：团队 AI 上下文记忆的统一管理与分发——让团队规范、编码标准、经验教训自动同步到每个成员的 AI 工具中，同时以极低的 token 成本实现无感体验。

## What Changes

- 从零构建 FastAPI 后端服务，包括完整的 HTTP API 路由、认证鉴权、RBAC 权限体系
- 实现 SQLite + 文件系统双引擎存储架构，包括 sqlite-vec 向量索引和 FTS5 全文索引
- 实现三层 Context 引擎（Layer 0 规范预注入 / Layer 1 活跃上下文 / Layer 2 按需搜索）
- 实现 BM25 + 向量 Score Fusion 混合搜索引擎
- 实现三层上传策略（Hook 自动回调 / Python 脚本 / MCP 兜底）
- 实现 MCP Server（仅 2 个读取工具：search_memory、get_memory_detail）
- 实现规范管理系统（specs/ + proposals/ 双目录、提案生命周期）
- 实现项目接入流程（ProjectDetector 画像检测 + SpecMatcher 规范匹配 + SpecDeduplicator 语义去重 + ContextSyncer 版本保鲜）
- 实现多工具聊天捕获与智能记忆提取（Claude Code / Cursor / OpenCode / Chatbox / Codex 适配器）
- 实现用户偏好系统（三级优先级 + 自动学习）
- 实现建议式记忆整合模块（语义聚类 + LLM 合并建议 + 人工确认）
- 实现知识策展系统（质量生命周期 + 自动维护任务）
- 实现 SSE 实时事件推送
- 实现 tmh CLI 命令行工具
- 实现 Embedding Provider 抽象层（Gemini / OpenAI / ONNX / OpenAI-Compatible）
- 构建 Web Dashboard 管理端
- 构建完整测试套件
- 编写部署配置（Docker / docker-compose）

## Capabilities

### New Capabilities

- `auth-and-rbac`: 认证鉴权体系——JWT 令牌认证、多 API Key 管理（scope 隔离）、RBAC 四级角色权限控制
- `storage-engine`: 双引擎存储层——SQLite 索引/元数据/向量/FTS5 + 文件系统存储规范原文/记忆/聊天记录，含写入队列和一致性保证
- `memory-management`: 记忆 CRUD 与生命周期——记忆创建/读取/更新/删除、版本追踪、质量标记（community→verified→stale→archived→pinned）
- `hybrid-search`: BM25 + 向量混合搜索引擎——双路检索 Score Fusion、三层评分（融合→上下文加权→截断排序）、FTS5 全文索引
- `context-engine`: 三层 Context 引擎——Layer 0 规范预注入、Layer 1 活跃上下文、Layer 2 按需搜索、缓存策略
- `spec-management`: 规范管理与提案系统——specs/ 真相源、proposals/ 提案生命周期（draft→pending_review→approved→merged）、Delta 格式
- `project-onboarding`: 项目接入与同步——ProjectDetector 画像检测、SpecMatcher 规范匹配、SpecDeduplicator 语义去重、ContextSyncer 版本保鲜
- `upload-pipeline`: 三层上传策略——Tier 1 Hook 自动回调、Tier 2 Python 脚本、Tier 3 MCP 兜底
- `chat-capture`: 多工具聊天捕获——ChatAdapter 适配层（5 种工具）、LLM 智能提取记忆、统一 JSONL 格式
- `user-preferences`: 用户偏好系统——三级优先级（项目→用户→团队）、偏好自动学习、LLM 建议确认
- `memory-consolidation`: 建议式记忆整合——语义聚类候选检测、LLM 合并建议生成、maintainer 确认执行、私有记忆可自动
- `mcp-server`: MCP Server——仅 2 个读取工具（search_memory + get_memory_detail），可选开启写入
- `sse-events`: SSE 实时事件推送——context_updated、memory_created、merge_suggestion 等事件流
- `tmh-cli`: CLI 命令行工具——init/sync/store/search/ingest/specs/consolidation 全套命令
- `client-integration`: 客户端集成——AGENTS.md 生成器、工具专用指令文件、Slash Commands、Hook 脚本脚手架
- `embedding-providers`: Embedding 抽象层——Gemini/OpenAI/ONNX/OpenAI-Compatible 四种 Provider，统一 384 维
- `dashboard`: Web Dashboard——记忆浏览、搜索调试、规范管理、合并建议审核、统计概览
- `curation-tasks`: 自动维护任务——去重检测、过期标记、自动归档、文件巡检、索引同步、合并候选扫描

### Modified Capabilities

无（全新项目，没有已有 specs）

## Impact

- **代码**：从零构建完整 Python 项目 `src/team_memory_hub/`，包含 server/core/providers/adapters/storage/dashboard/cli 七大模块
- **API**：全新 HTTP API（约 40+ 端点）、MCP Server（2 工具）、SSE 事件流
- **依赖**：FastAPI、uvicorn、httpx、sqlite-vec、python-jose（JWT）、Jinja2（Dashboard）、onnxruntime（可选）、mcp-sdk
- **基础设施**：Docker 容器化部署、SQLite 数据库文件、文件存储目录结构
- **集成**：需要 Embedding API（Gemini/OpenAI/Ollama）和 LLM API（Claude/Gemini）的访问凭证
- **工具生态**：生成 AGENTS.md / CLAUDE.md / .cursorrules 等 AI 工具指令文件
