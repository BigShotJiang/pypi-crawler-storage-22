## ADDED Requirements

### Requirement: JWT token authentication
系统 SHALL 支持基于 JWT 的用户认证。access_token 有效期 15 分钟，refresh_token 有效期 30 天，采用滑动窗口策略（每次使用 refresh token 签发新 token，旧 token grace period 30 秒）。

#### Scenario: User login
- **WHEN** 用户提交有效的 email 和密码到 `POST /api/auth/token`
- **THEN** 系统返回 access_token 和 refresh_token

#### Scenario: Token refresh
- **WHEN** 用户使用有效的 refresh_token 请求 `POST /api/auth/token/refresh`
- **THEN** 系统签发新的 access_token 和 refresh_token，旧 refresh_token 在 30 秒 grace period 内仍可用

#### Scenario: Expired access token
- **WHEN** 用户使用过期的 access_token 访问受保护 API
- **THEN** 系统返回 401 Unauthorized

### Requirement: Multi API key management
系统 SHALL 支持每个用户创建多个 API Key，每个 Key 有独立的 scope（full_access / mcp_only / read_only / sync_only / ingest_only）。

#### Scenario: Create API key with scope
- **WHEN** 用户调用 `POST /api/keys` 并指定 name 和 scope
- **THEN** 系统创建新的 API Key 并返回密钥值（仅返回一次）

#### Scenario: API key scope enforcement
- **WHEN** 使用 scope=read_only 的 API Key 尝试写入记忆
- **THEN** 系统返回 403 Forbidden

#### Scenario: Delete API key
- **WHEN** 用户调用 `DELETE /api/keys/:id`
- **THEN** 该 Key 立即失效，后续使用该 Key 的请求返回 401

### Requirement: RBAC four-tier roles
系统 SHALL 实现四级角色权限控制：admin > maintainer > member > viewer。

权限矩阵：
- admin：全部操作
- maintainer：读写记忆、合并提案、处理合并建议、标记 verified、设置团队偏好
- member：读写记忆、创建提案、管理私有数据
- viewer：只读团队记忆

#### Scenario: Member creates proposal
- **WHEN** member 角色用户调用 `POST /api/specs/proposals`
- **THEN** 系统创建提案成功

#### Scenario: Member cannot merge proposal
- **WHEN** member 角色用户尝试调用 `POST /api/specs/proposals/:id/merge`
- **THEN** 系统返回 403 Forbidden

#### Scenario: Viewer cannot write memory
- **WHEN** viewer 角色用户尝试调用 `POST /api/memories`
- **THEN** 系统返回 403 Forbidden

### Requirement: Private data isolation
系统 SHALL 确保私有记忆和偏好仅对所有者可见，任何角色（包括 admin）都无法访问其他用户的私有数据。

#### Scenario: User accesses own private memory
- **WHEN** 用户查询 scope=private 的记忆
- **THEN** 系统仅返回该用户自己的私有记忆

#### Scenario: Admin cannot see others private data
- **WHEN** admin 用户查询其他用户的 scope=private 记忆
- **THEN** 系统返回空结果
