## ADDED Requirements

### Requirement: Chat adapter abstraction
系统 SHALL 提供 ChatAdapter 抽象层，将不同 AI 工具的聊天格式转换为统一的 TMH Chat JSONL 格式。SHALL 支持 5 种适配器：Claude Code、Cursor、OpenCode、Chatbox、Codex。

#### Scenario: Claude Code chat ingestion
- **WHEN** 调用 `POST /api/chats/ingest` 提交 tool_name="claude-code" 和原始会话数据
- **THEN** ClaudeCodeAdapter 将数据转换为 TMH JSONL 格式

#### Scenario: Unknown tool rejected
- **WHEN** 调用 `POST /api/chats/ingest` 提交不支持的 tool_name
- **THEN** 系统返回 400 错误，提示不支持的工具类型

### Requirement: Intelligent memory extraction
系统 SHALL 使用 LLM 从聊天记录中智能提取有价值的记忆，分类为决策/经验/规范/bug。一次聊天可提取 0-N 条记忆。

#### Scenario: Extract decision from chat
- **WHEN** 聊天内容包含技术决策（如"我们决定使用 JWT 代替 Session Cookie"）
- **THEN** 系统提取为 category=decision 的记忆

#### Scenario: No valuable content
- **WHEN** 聊天内容仅包含简单的代码修改无决策性内容
- **THEN** 系统不提取任何记忆（0 条），仅存储聊天索引

### Requirement: Extraction fallback to rules engine
系统 SHALL 在 LLM 不可用时降级为规则引擎（关键词 + 正则）进行记忆提取。

#### Scenario: LLM unavailable fallback
- **WHEN** LLM API 调用失败
- **THEN** 系统使用规则引擎（关键词匹配如"决定"、"选择"、"因为"）提取记忆

### Requirement: Chat session indexing
系统 SHALL 在 SQLite chat_sessions 表中索引所有聊天会话元数据（user_id、tool、project_id、turn_count、memories_extracted），聊天原文存储在 `data/chats/{user}/{date}_{tool}_{session}.jsonl`。

#### Scenario: Chat session recorded
- **WHEN** 聊天成功接收
- **THEN** 系统在 chat_sessions 表创建记录，原文写入 JSONL 文件
