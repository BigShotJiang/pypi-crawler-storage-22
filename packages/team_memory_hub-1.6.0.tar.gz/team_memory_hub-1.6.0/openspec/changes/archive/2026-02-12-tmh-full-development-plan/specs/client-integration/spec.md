## ADDED Requirements

### Requirement: AGENTS.md generation
系统 SHALL 生成通用 AGENTS.md 文件作为所有 AI 工具的指令入口。文件包含 header（specs_version、fingerprint、generated_at、project、profile、overrides 路径）、团队规范（Layer 0）、当前上下文（Layer 1）、开发者偏好、记忆管理指令。

#### Scenario: Generate AGENTS.md
- **WHEN** 执行 `tmh sync` 或 `tmh init`
- **THEN** 系统生成 AGENTS.md 文件，包含 `<!-- TMH Auto-Generated | DO NOT EDIT MANUALLY -->` 标记

#### Scenario: AGENTS.md includes version header
- **WHEN** 生成 AGENTS.md
- **THEN** 文件包含 specs_version、specs_fingerprint、generated_at 的 HTML 注释头

### Requirement: Tool-specific instruction files
系统 SHALL 为不同 AI 工具生成专用指令文件：CLAUDE.md（Claude Code）、.cursorrules（Cursor）、.opencode/instructions（OpenCode）。通用部分来自 AGENTS.md，工具专用部分包含特定的 Hook/Script/Command 配置。

#### Scenario: Generate Claude Code config
- **WHEN** 初始化时指定 tools 包含 claude-code
- **THEN** 生成 CLAUDE.md（包含 AGENTS.md 内容 + Claude Code Hook 配置）

#### Scenario: Generate Cursor config
- **WHEN** 初始化时指定 tools 包含 cursor
- **THEN** 生成 .cursorrules（包含 AGENTS.md 内容 + upload.py 调用指令）

### Requirement: Slash commands
系统 SHALL 为支持的 AI 工具生成 Slash Commands 配置：`/tmh:store`（存储记忆）、`/tmh:search $QUERY`（搜索记忆）、`/tmh:propose $TITLE`（创建提案）、`/tmh:sync`（强制刷新）。

#### Scenario: Slash command store
- **WHEN** 用户在 AI 工具中输入 `/tmh:store`
- **THEN** AI agent 通过 bash 调用 `.tmh/upload.py store` 存储记忆

#### Scenario: Slash command search
- **WHEN** 用户在 AI 工具中输入 `/tmh:search JWT`
- **THEN** AI agent 通过 MCP `search_memory` 工具搜索团队记忆

### Requirement: Hook script scaffold
系统 SHALL 在 `.tmh/` 目录中生成 Hook 脚本脚手架，包含 upload.py（Tier 2 上传脚本）和 hooks/post_session.py（Tier 1 Hook 脚本）。

#### Scenario: Scaffold generated on init
- **WHEN** 执行 `tmh init`
- **THEN** 系统在项目根目录创建 `.tmh/` 目录，包含 upload.py、overrides.json、sync_state.json、hooks/
