## ADDED Requirements

### Requirement: Three-layer context architecture
系统 SHALL 实现三层 Context 注入架构：Layer 0（核心规范，~1.5K tokens，来自 specs/*.md，文件预注入）、Layer 1（活跃上下文，~2K tokens，SQLite 摘要 + 偏好）、Layer 2（按需检索，0-2K/次，MCP 混合搜索）。

#### Scenario: Build context for user
- **WHEN** 调用 `GET /api/context/:user_id` 并指定 project_id
- **THEN** 系统返回合并后的 Layer 0 + Layer 1 内容，格式为 AGENTS.md 兼容的 Markdown

#### Scenario: Layer 0 content from specs
- **WHEN** 构建 Layer 0 上下文
- **THEN** 系统从 `data/specs/*.md` 加载适用于当前项目类型的团队规范，应用 overrides

#### Scenario: Layer 1 includes recent decisions
- **WHEN** 构建 Layer 1 上下文
- **THEN** 系统从 SQLite 中获取近期高质量记忆摘要（verified 优先、7 天内优先），总计不超过 ~2K tokens

### Requirement: Context caching
系统 SHALL 实现 Context 缓存：Layer 0 缓存 1 小时，Layer 1 缓存 10 分钟。写入/merge/合并操作 SHALL 触发缓存失效。

#### Scenario: Cache hit for Layer 0
- **WHEN** 1 小时内重复请求同一团队的 Layer 0 上下文
- **THEN** 系统直接返回缓存结果，不重新读取文件

#### Scenario: Cache invalidation on spec merge
- **WHEN** 规范提案合并（merge）
- **THEN** 相关团队的 Layer 0 缓存立即失效

#### Scenario: Cache invalidation on memory write
- **WHEN** 新记忆创建或合并执行
- **THEN** 相关团队的 Layer 1 缓存立即失效

### Requirement: Context refresh API
系统 SHALL 提供 `POST /api/context/refresh` 端点，强制刷新指定用户或团队的所有 Context 缓存。

#### Scenario: Force refresh
- **WHEN** 调用 `POST /api/context/refresh` 指定 team_id
- **THEN** 该团队的 Layer 0 和 Layer 1 缓存全部失效，下次请求重新构建
