## ADDED Requirements

### Requirement: Duplicate detection task
系统 SHALL 每日执行 detect_duplicates 任务，检测语义相似度 > 0.92 的重复记忆，标记为潜在重复。

#### Scenario: Detect duplicate memories
- **WHEN** 每日维护任务执行
- **THEN** 系统扫描所有非 archived 记忆，标记相似度 > 0.92 的重复对

### Requirement: Staleness detection task
系统 SHALL 每日执行 detect_staleness 任务，将 180 天未被检索（access_count 无增长）的记忆标记为 stale。

#### Scenario: Mark stale memory
- **WHEN** 记忆 180 天内 last_accessed_at 未更新
- **THEN** quality 更新为 stale

### Requirement: Auto archive task
系统 SHALL 每日执行 auto_archive 任务，将 stale 状态超过 30 天的记忆自动标记为 archived。

#### Scenario: Auto archive stale memory
- **WHEN** 记忆处于 stale 状态超过 30 天
- **THEN** quality 更新为 archived

### Requirement: Quality score refresh task
系统 SHALL 每日执行 refresh_quality_scores 任务，基于访问频率、时间衰减、验证状态等因素重新计算每条记忆的 quality_score。

#### Scenario: Refresh quality scores
- **WHEN** 每日维护任务执行
- **THEN** 所有非 archived 记忆的 quality_score 重新计算

### Requirement: File integrity check task
系统 SHALL 每日执行 verify_file_integrity 任务，通过 SHA256 校验文件完整性，检测文件损坏或篡改。

#### Scenario: Detect corrupted file
- **WHEN** 文件 SHA256 与 SQLite 中记录的 file_hash 不一致
- **THEN** 系统记录告警日志

### Requirement: Orphan file cleanup task
系统 SHALL 每日执行 clean_orphan_files 任务，清理文件系统中存在但 SQLite 索引中不存在的孤儿文件。

#### Scenario: Clean orphan file
- **WHEN** 文件系统中存在 mem_xxx.md 但 memories 表无对应记录
- **THEN** 系统删除孤儿文件

### Requirement: Specs index sync task
系统 SHALL 每日执行 sync_specs_index 任务，确保 specs/ 文件与 SQLite 中的 layer=0 记忆索引一致。

#### Scenario: Sync new spec file
- **WHEN** specs/ 目录新增了文件但 SQLite 中无对应索引
- **THEN** 系统自动创建对应的 layer=0 记忆索引记录

### Requirement: Merge candidate scan task
系统 SHALL 每日执行 scan_merge_candidates 任务（凌晨 4 点），扫描近 30 天记忆的合并候选，生成合并建议。每次最多生成 20 条建议。

#### Scenario: Daily merge scan
- **WHEN** 凌晨 4 点定时任务执行
- **THEN** 扫描近 30 天记忆，生成不超过 20 条合并建议

### Requirement: Old suggestion cleanup task
系统 SHALL 每日执行 clean_old_suggestions 任务，清理超过 30 天未处理的合并建议。

#### Scenario: Clean expired suggestion
- **WHEN** 合并建议 pending 状态超过 30 天
- **THEN** 自动标记为 dismissed

### Requirement: Audit log retention task
系统 SHALL 每日执行 clean_old_audit_logs 任务，根据配置的保留策略清理过期审计日志。

#### Scenario: Clean old audit logs
- **WHEN** 审计日志超过保留期限
- **THEN** 系统删除过期日志记录

### Requirement: Embedding migration task
系统 SHALL 提供按需执行的 migrate_embeddings 任务，在切换 Embedding Provider 后增量重建所有向量索引。

#### Scenario: Incremental embedding migration
- **WHEN** 管理员触发 embedding 迁移任务
- **THEN** 系统后台逐批重新生成向量，通过 SSE 推送 migration_progress 事件
