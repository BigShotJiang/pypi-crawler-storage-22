## ADDED Requirements

### Requirement: Dashboard web interface
系统 SHALL 提供 Web Dashboard（`GET /dashboard/*`），使用 Jinja2 SSR + HTMX 实现，供管理员管理团队记忆、规范、合并建议。

#### Scenario: Access dashboard
- **WHEN** 用户访问 `/dashboard/`
- **THEN** 显示团队概览页面，包含记忆统计、待处理建议数、最近活动

### Requirement: Memory browsing and management
Dashboard SHALL 提供记忆浏览页面，支持按 scope/category/quality/project 过滤，按时间/评分排序，查看摘要和原文详情。

#### Scenario: Filter memories by category
- **WHEN** 在 Dashboard 中选择 category=decision 过滤器
- **THEN** 仅显示 decision 类别的记忆列表

#### Scenario: View memory detail
- **WHEN** 点击记忆卡片
- **THEN** 展开显示完整原文内容和元数据

### Requirement: Consolidation review interface
Dashboard SHALL 提供合并建议审核页面，包含：整合概览（待处理数/本月已合并/瘦身率）、建议列表（相似度/类别/记忆数）、详情视图（原始记忆 vs 合并预览对比）、操作按钮（接受/编辑后接受/拒绝/忽略）。

#### Scenario: Review merge suggestion
- **WHEN** maintainer 在 Dashboard 中打开合并建议详情
- **THEN** 左侧显示原始 N 条记忆内容，右侧显示 LLM 生成的合并预览

#### Scenario: Edit and accept merge
- **WHEN** maintainer 修改合并预览内容后点击"编辑后接受"
- **THEN** 使用修改后的内容执行合并

### Requirement: Spec and proposal management
Dashboard SHALL 提供规范管理页面，显示规范列表和提案列表，支持查看提案 delta、审核批准/拒绝。

#### Scenario: View pending proposals
- **WHEN** 在 Dashboard 中打开提案管理页面
- **THEN** 显示所有 pending_review 状态的提案列表

### Requirement: Search debugging
Dashboard SHALL 提供搜索调试界面，输入查询后显示各路评分明细（vec_score、bm25_score、fusion_score、final_score），帮助管理员调优搜索参数。

#### Scenario: Debug search scores
- **WHEN** 在 Dashboard 搜索调试页面输入查询
- **THEN** 每条结果展示完整的 score_breakdown
