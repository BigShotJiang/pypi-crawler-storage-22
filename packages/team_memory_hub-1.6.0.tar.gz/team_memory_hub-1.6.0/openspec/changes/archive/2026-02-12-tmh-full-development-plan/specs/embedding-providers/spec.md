## ADDED Requirements

### Requirement: Embedding provider abstraction
系统 SHALL 实现 EmbeddingProvider 抽象层，统一输出 384 维向量。所有 Provider SHALL 实现 `embed(texts)` 和 `embed_single(text)` 接口。

#### Scenario: Provider returns 384-dim vectors
- **WHEN** 调用任意 Provider 的 embed 方法
- **THEN** 返回的每个向量维度固定为 384

### Requirement: Gemini embedding provider
系统 SHALL 实现 GeminiProvider，将 Gemini Embedding API 返回的 768 维向量截断为 384 维。

#### Scenario: Gemini embedding
- **WHEN** 使用 Gemini Provider 对文本生成 embedding
- **THEN** 返回 384 维向量（768 维截断前 384 维）

### Requirement: OpenAI embedding provider
系统 SHALL 实现 OpenAIProvider，将 OpenAI Embedding API 返回的 1536 维向量截断为 384 维。

#### Scenario: OpenAI embedding
- **WHEN** 使用 OpenAI Provider 对文本生成 embedding
- **THEN** 返回 384 维向量（1536 维截断前 384 维）

### Requirement: ONNX local embedding provider
系统 SHALL 实现 ONNXLocalProvider，使用本地 ONNX 模型生成原生 384 维向量，无需截断。

#### Scenario: ONNX local embedding
- **WHEN** 使用 ONNX Provider 对文本生成 embedding
- **THEN** 返回原生 384 维向量

### Requirement: OpenAI-compatible embedding provider
系统 SHALL 实现 OpenAICompatibleProvider，通过配置 base_url 适配 Ollama、vLLM、TEI、LocalAI 等兼容 OpenAI API 的推理服务。维度不足 384 时零填充，超过时截断。

#### Scenario: Ollama embedding via compatible provider
- **WHEN** 配置 base_url="http://localhost:11434"，model="nomic-embed-text"
- **THEN** Provider 调用 Ollama 的 /v1/embeddings 端点并归一化到 384 维

#### Scenario: vLLM embedding via compatible provider
- **WHEN** 配置 base_url="http://gpu-server:8000"，model="BAAI/bge-base-en-v1.5"
- **THEN** Provider 调用 vLLM 的 /v1/embeddings 端点并归一化到 384 维

### Requirement: Embedding input is summary
系统 SHALL 对记忆的摘要（summary）生成 embedding，而不是原文内容。

#### Scenario: Summary used for embedding
- **WHEN** 创建新记忆
- **THEN** 系统对 summary 字段生成 embedding 并存储到 memory_embeddings 表

### Requirement: Embedding migration
系统 SHALL 提供 `migrate_embeddings` 任务，在切换 Provider 后增量重建所有向量索引。迁移期间旧向量仍可用于搜索。

#### Scenario: Provider switch migration
- **WHEN** 管理员切换 Embedding Provider 并触发迁移
- **THEN** 系统后台增量重建所有向量，迁移完成前旧向量继续服务搜索
