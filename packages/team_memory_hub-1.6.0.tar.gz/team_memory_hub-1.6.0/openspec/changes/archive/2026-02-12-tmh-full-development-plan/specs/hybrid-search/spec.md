## ADDED Requirements

### Requirement: BM25 plus vector score fusion search
系统 SHALL 实现混合搜索引擎，同时使用 BM25 关键词搜索和向量语义搜索，通过 Score Fusion 公式融合结果。默认权重：语义 α=0.7，BM25 β=0.3。

#### Scenario: Hybrid search returns fused results
- **WHEN** 用户调用 `POST /api/memories/search` 提交 query="JWT refresh token"
- **THEN** 系统并行执行 BM25 搜索和向量搜索，取 limit×3 候选集，min-max 归一化后按 α×vec + β×bm25 融合排序

#### Scenario: Exact term matching via BM25
- **WHEN** 用户搜索精确术语如 "WAL mode"
- **THEN** BM25 引擎通过 FTS5 精确匹配该术语，即使向量搜索可能将其与无关内容混淆

#### Scenario: Semantic matching via vector
- **WHEN** 用户搜索语义描述如 "认证方案"
- **THEN** 向量引擎匹配语义相似的 "JWT 实现"、"OAuth 配置" 等记忆

### Requirement: FTS5 full-text index
系统 SHALL 为记忆摘要和标签创建 FTS5 虚拟表 `memories_fts`，使用 `unicode61 remove_diacritics 2` 分词器。FTS5 索引通过触发器自动与 memories 表同步（INSERT/UPDATE/DELETE）。

#### Scenario: FTS5 auto sync on insert
- **WHEN** 新记忆插入 memories 表
- **THEN** 触发器自动将摘要和标签插入 memories_fts 虚拟表

#### Scenario: FTS5 auto sync on update
- **WHEN** 记忆摘要更新
- **THEN** 触发器自动删除旧 FTS5 记录并插入新记录

### Requirement: Three-layer scoring
系统 SHALL 实现三层评分：第一层双引擎融合 raw = α×semantic + β×bm25；第二层上下文加权 raw × project_boost(+20%) × time_decay × quality_boost(+15%)；第三层截断排序 top-K。

#### Scenario: Project context boost
- **WHEN** 搜索结果中有记忆属于当前项目
- **THEN** 该记忆得分乘以 1.20（+20%）

#### Scenario: Time decay penalty
- **WHEN** 记忆创建超过 90 天
- **THEN** 该记忆得分乘以 0.85（-15%）

#### Scenario: Recent memory boost
- **WHEN** 记忆创建在 7 天内
- **THEN** 该记忆得分乘以 1.10（+10%）

#### Scenario: Verified quality boost
- **WHEN** 记忆 quality 为 verified
- **THEN** 该记忆得分乘以 1.15（+15%）

### Requirement: Search result with score breakdown
系统 SHALL 在搜索结果中包含各路评分明细，包括 score（最终得分）、raw_fusion_score、vec_score、bm25_score。

#### Scenario: Score breakdown in response
- **WHEN** 用户搜索记忆
- **THEN** 每条结果包含 score、score_breakdown（fusion、vec、bm25、project_boost、time_boost、quality_boost）

### Requirement: Search engine configuration
系统 SHALL 支持通过配置切换搜索引擎模式：hybrid（默认）、vector_only、bm25_only。权重和候选集倍数均可配置。

#### Scenario: Switch to vector only mode
- **WHEN** 配置 `search.engine = "vector_only"`
- **THEN** 搜索仅使用向量语义引擎，忽略 BM25

#### Scenario: Adjust fusion weights
- **WHEN** 配置 `search.semantic_weight = 0.5` 和 `search.keyword_weight = 0.5`
- **THEN** 搜索使用等权重融合
