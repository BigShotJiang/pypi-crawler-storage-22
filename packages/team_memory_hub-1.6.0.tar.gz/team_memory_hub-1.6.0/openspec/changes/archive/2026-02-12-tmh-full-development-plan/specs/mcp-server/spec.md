## ADDED Requirements

### Requirement: Read-only MCP tools
系统 SHALL 实现 MCP Server 并仅默认暴露 2 个读取工具：`search_memory`（语义搜索返回摘要列表）和 `get_memory_detail`（获取记忆原文）。工具定义总计约 400 tokens。

#### Scenario: Search memory via MCP
- **WHEN** AI agent 调用 MCP `search_memory` 工具，提供 query、scope、category、limit 参数
- **THEN** 系统使用混合搜索引擎返回匹配的记忆摘要列表（不含原文）

#### Scenario: Get memory detail via MCP
- **WHEN** AI agent 调用 MCP `get_memory_detail` 工具，提供 memory_id
- **THEN** 系统从文件系统加载并返回记忆完整原文

### Requirement: Optional write tools
系统 SHALL 支持通过配置 `mcp.enable_write_tools = true` 开启 MCP 写入工具（`store_memory`），仅面向 Chatbox 等纯 MCP 工具。

#### Scenario: Write tool enabled
- **WHEN** 配置开启 MCP 写入工具
- **THEN** MCP Server 额外暴露 `store_memory` 工具

#### Scenario: Write tool disabled by default
- **WHEN** 使用默认配置
- **THEN** MCP Server 仅暴露 search_memory 和 get_memory_detail

### Requirement: MCP authentication
系统 SHALL 通过 API Key 对 MCP 请求进行认证，使用 scope=mcp_only 的 Key。

#### Scenario: Valid MCP key
- **WHEN** MCP 请求携带有效的 mcp_only scope API Key
- **THEN** 请求正常处理

#### Scenario: Invalid MCP key
- **WHEN** MCP 请求未携带有效 Key
- **THEN** 返回认证错误
