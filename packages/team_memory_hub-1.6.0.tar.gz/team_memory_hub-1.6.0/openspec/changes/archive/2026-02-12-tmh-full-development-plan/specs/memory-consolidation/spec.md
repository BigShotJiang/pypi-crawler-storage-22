## ADDED Requirements

### Requirement: Semantic clustering for merge candidates
系统 SHALL 使用贪心语义聚类算法检测可合并的记忆组。相似度阈值 CLUSTER_THRESHOLD=0.85（低于去重阈值 0.92），扫描近 30 天的非 archived 记忆，每组至少 2 条且至少 1 条来自同一 category。

#### Scenario: Detect merge group
- **WHEN** 每日凌晨自动扫描执行
- **THEN** 系统输出候选合并组列表，每组包含记忆 ID、平均相似度、类别

#### Scenario: Single memory not clustered
- **WHEN** 某记忆与其他所有记忆的相似度都低于 0.85
- **THEN** 该记忆不出现在任何合并组中

### Requirement: LLM merge suggestion generation
系统 SHALL 使用 LLM 为每个候选合并组生成合并建议，包括：合并后的内容（保留所有独特信息、更精炼的结构）、合并后的标签（去重合并）、合并后的分类（多数票）。

#### Scenario: Generate merge suggestion
- **WHEN** 检测到 3 条 JWT 相关记忆可合并
- **THEN** LLM 生成合并后的单条内容，保留所有关键信息，末尾列出合并来源 ID

### Requirement: Suggestion review workflow
系统 SHALL 实现建议式合并审核流程：建议存入 merge_suggestions 表（status=pending），通过 Dashboard/CLI/SSE 通知 maintainer，maintainer 可接受/拒绝/编辑后接受/忽略。

#### Scenario: Accept merge suggestion
- **WHEN** maintainer 调用 `POST /api/consolidation/suggestions/:id/accept`
- **THEN** 系统创建新合并记忆，原始记忆标记为 archived 并设置 merged_into 字段，更新索引和向量，推送 memory_merged 事件

#### Scenario: Reject merge suggestion
- **WHEN** maintainer 调用 `POST /api/consolidation/suggestions/:id/reject`
- **THEN** 建议状态变为 rejected，原始记忆不受影响

#### Scenario: Dismiss merge suggestion
- **WHEN** maintainer 调用 `POST /api/consolidation/suggestions/:id/dismiss`
- **THEN** 建议状态变为 dismissed，不再重复提示

### Requirement: Private memory auto consolidation
系统 SHALL 支持 scope=private 的记忆自动合并（用户可在偏好中开启 `auto_consolidate_private=true`）。私有记忆高度重复（>0.92）时直接合并，中度相似时仍生成建议。

#### Scenario: Auto merge private duplicate
- **WHEN** 用户开启 auto_consolidate_private 且检测到两条私有记忆相似度 > 0.92
- **THEN** 系统自动执行合并，无需人工确认

#### Scenario: Private suggestion for moderate similarity
- **WHEN** 用户私有记忆相似度 0.85-0.92
- **THEN** 系统生成建议但不自动合并，在个人 Dashboard 中展示

### Requirement: Consolidation statistics
系统 SHALL 提供整合统计 API（`GET /api/consolidation/stats`），包括待处理建议数、本月已合并数、记忆瘦身百分比。

#### Scenario: View consolidation stats
- **WHEN** member 调用 `GET /api/consolidation/stats`
- **THEN** 返回整合统计数据
