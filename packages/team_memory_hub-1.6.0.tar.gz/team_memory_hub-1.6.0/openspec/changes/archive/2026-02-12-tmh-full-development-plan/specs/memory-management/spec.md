## ADDED Requirements

### Requirement: Memory CRUD operations
系统 SHALL 提供完整的记忆 CRUD API：创建（`POST /api/memories`）、读取摘要（`GET /api/memories/:id`）、读取原文（`GET /api/memories/:id/detail`）、更新（`PUT /api/memories/:id`）、删除（`DELETE /api/memories/:id`）、列表（`GET /api/memories`）。

#### Scenario: Create team memory
- **WHEN** member 用户调用 `POST /api/memories` 提交 content、scope=team、category=decision、tags
- **THEN** 系统生成唯一 ID（mem_前缀 + 8 位随机字符），将摘要写入 SQLite，原文写入文件系统，生成 embedding 向量，返回记忆 ID

#### Scenario: Get memory summary vs detail
- **WHEN** 用户调用 `GET /api/memories/:id`
- **THEN** 返回 SQLite 中的摘要和元数据（不含原文）
- **WHEN** 用户调用 `GET /api/memories/:id/detail`
- **THEN** 从文件系统加载并返回完整原文内容

#### Scenario: Delete memory
- **WHEN** 记忆所有者或 admin 调用 `DELETE /api/memories/:id`
- **THEN** 系统删除 SQLite 索引记录和文件系统中的原文文件

### Requirement: Memory scope classification
系统 SHALL 支持三种记忆 scope：private（仅本人）、project（项目范围）、team（团队范围）。

#### Scenario: Private memory visibility
- **WHEN** 用户创建 scope=private 的记忆
- **THEN** 该记忆仅在该用户的搜索和 context 中可见

#### Scenario: Team memory visibility
- **WHEN** 用户创建 scope=team 的记忆
- **THEN** 该记忆对团队所有成员可见（根据 RBAC 权限）

### Requirement: Memory category classification
系统 SHALL 支持记忆分类：decision（决策）、experience（经验）、standard（规范）、bug（bug 修复）、general（通用）。

#### Scenario: Filter by category
- **WHEN** 用户搜索记忆并指定 category=decision
- **THEN** 系统仅返回该分类下的记忆结果

### Requirement: Memory quality lifecycle
系统 SHALL 实现记忆质量生命周期：community → verified → stale → archived，以及 pinned 置顶状态。

#### Scenario: Verify memory
- **WHEN** maintainer 调用 `POST /api/memories/:id/verify`
- **THEN** 记忆 quality 更新为 verified，记录 verified_by 和 verified_at

#### Scenario: Auto stale detection
- **WHEN** 记忆 180 天未被检索
- **THEN** 自动维护任务将其标记为 stale

#### Scenario: Auto archive
- **WHEN** 记忆处于 stale 状态超过 30 天
- **THEN** 自动维护任务将其标记为 archived

### Requirement: Memory version tracking
系统 SHALL 对每次记忆内容更新记录版本历史，存储在 memory_versions 表中。

#### Scenario: Version created on update
- **WHEN** 用户更新记忆内容
- **THEN** 系统在 memory_versions 表创建新版本记录，包含变更前摘要和 diff

#### Scenario: List versions
- **WHEN** 用户调用 `GET /api/memories/:id/versions`
- **THEN** 返回该记忆的所有版本历史，按版本号降序排列

### Requirement: Memory file format
每条记忆的原文文件 SHALL 使用 Markdown 格式，包含 YAML front-matter 元数据（id、scope、category、tags、layer、quality、author、project、created_at 等字段）。

#### Scenario: Memory file structure
- **WHEN** 读取一条记忆的原文文件
- **THEN** 文件以 `---` 包围的 YAML front-matter 开头，后跟 Markdown 格式的正文内容
