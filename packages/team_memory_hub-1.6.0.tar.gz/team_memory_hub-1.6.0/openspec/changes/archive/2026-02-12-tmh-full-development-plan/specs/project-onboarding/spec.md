## ADDED Requirements

### Requirement: Project profile detection
系统 SHALL 通过 ProjectDetector 自动检测项目画像，包括：语言（Python/TypeScript/Go 等）、框架（FastAPI/React 等）、包管理器、Docker/CI 标志、已有规范文件（.eslintrc/ruff.toml/.editorconfig）、已有 AI 配置（CLAUDE.md/.cursorrules）。

#### Scenario: Detect Python FastAPI project
- **WHEN** 执行 `tmh init` 且项目根目录包含 `pyproject.toml` 和 fastapi 依赖
- **THEN** ProjectDetector 输出 ProjectProfile，languages=["python"]，frameworks=["fastapi"]，project_type="python-web"

#### Scenario: Detect existing rules
- **WHEN** 项目中存在 `.eslintrc.json` 和 `ruff.toml`
- **THEN** ProjectDetector 扫描并提取已有规范文件的关键规则

### Requirement: Spec matching
系统 SHALL 通过 SpecMatcher 将团队 `specs/` 中的规范与项目画像匹配。每条规范有适用条件（语言/框架/项目类型/通用），匹配结果按置信度降序排列。

#### Scenario: Match language-specific spec
- **WHEN** 项目画像 languages 包含 "python"
- **THEN** SpecMatcher 匹配 `coding-standards-python.md` 规范，置信度高

#### Scenario: Match universal spec
- **WHEN** 项目画像为任意类型
- **THEN** SpecMatcher 始终匹配 `workflow/git-workflow.md` 等通用规范

### Requirement: Semantic deduplication
系统 SHALL 通过 SpecDeduplicator 进行语义去重，使用 RuleNormalizer 将不同格式（editorconfig/ruff/eslint/TMH spec）的规则提取为标准化 NormalizedRule，逐条比较判断：等价（跳过）、冲突（交互解决）、TMH 独有（注入）、项目独有（保留）。

#### Scenario: Equivalent rules detected
- **WHEN** TMH 规范 indent=4 与项目 ruff.toml indent=4 一致
- **THEN** SpecDeduplicator 标记为等价，跳过注入

#### Scenario: Conflicting rules detected
- **WHEN** TMH 规范 indent=4 与项目 editorconfig indent=2 冲突
- **THEN** SpecDeduplicator 标记为冲突，提交 CLI 交互解决

#### Scenario: TMH unique rules injected
- **WHEN** TMH 规范包含项目中不存在的规则
- **THEN** SpecDeduplicator 标记为 TMH 独有，直接注入

### Requirement: Conflict resolution persistence
系统 SHALL 将冲突解决决策持久化到 `.tmh/overrides.json`，支持四种策略：merge（交互式逐条选择）、tmh_priority、project_priority、skip。后续 `tmh sync` 自动应用已有决策。

#### Scenario: Override applied on sync
- **WHEN** 执行 `tmh sync` 且 `.tmh/overrides.json` 中有已记录的决策
- **THEN** 系统自动应用已有决策，仅提示新冲突

### Requirement: Version freshness sync
系统 SHALL 通过 ContextSyncer 实现版本保鲜，对比客户端 AGENTS.md 中的 specs_version 与服务器最新版本。支持三种模式：实时（SSE 监听）、定时（Git hook/CI）、手动（tmh sync）。

#### Scenario: Incremental sync
- **WHEN** 执行 `tmh sync` 且本地 specs_version < 服务器版本
- **THEN** 系统拉取增量变更，执行去重，无冲突则无感更新 AGENTS.md

#### Scenario: No change needed
- **WHEN** 执行 `tmh sync` 且本地 specs_version 与服务器一致
- **THEN** 系统输出"无变化"，跳过
