## ADDED Requirements

### Requirement: Specs directory as source of truth
系统 SHALL 将 `data/specs/*.md` 作为 Layer 0 团队规范的真相源。规范文件支持分类目录结构（如 `architecture/auth.md`、`workflow/git-workflow.md`）。

#### Scenario: List specs
- **WHEN** 调用 `GET /api/specs`
- **THEN** 返回所有规范文件的路径列表和摘要

#### Scenario: Get spec content
- **WHEN** 调用 `GET /api/specs/:path`
- **THEN** 从文件系统加载并返回规范完整内容

### Requirement: Proposal lifecycle
系统 SHALL 实现规范提案生命周期：draft → pending_review → approved → merged，以及 withdrawn 撤回状态。

#### Scenario: Create proposal
- **WHEN** member+ 用户调用 `POST /api/specs/proposals` 提交 title、description、spec_delta
- **THEN** 系统创建 draft 状态的提案，存储 delta 文件

#### Scenario: Submit for review
- **WHEN** 提案作者将 draft 提案提交审核
- **THEN** 提案状态变为 pending_review

#### Scenario: Approve and merge proposal
- **WHEN** maintainer+ 调用 `POST /api/specs/proposals/:id/merge`
- **THEN** 系统将 delta 内容合并到目标 specs/ 文件，提案状态变为 merged，更新 specs_version 和 specs_fingerprint

#### Scenario: Withdraw proposal
- **WHEN** 提案作者调用 `POST /api/specs/proposals/:id/withdraw`
- **THEN** 提案状态变为 withdrawn

### Requirement: Delta spec format
系统 SHALL 支持 Delta 格式的规范变更描述，包含 ADDED、MODIFIED、REMOVED 三种变更类型。

#### Scenario: Delta with additions
- **WHEN** 提案包含 `## ADDED` 章节
- **THEN** 合并时将新内容追加到目标 spec 文件

#### Scenario: Delta with modifications
- **WHEN** 提案包含 `## MODIFIED` 章节
- **THEN** 合并时替换目标 spec 文件中对应的决策/规则

#### Scenario: Delta with removals
- **WHEN** 提案包含 `## REMOVED` 章节
- **THEN** 合并时从目标 spec 文件中删除对应内容

### Requirement: Specs version tracking
系统 SHALL 维护团队级别的 specs_version（递增整数）和 specs_fingerprint（SHA256），每次 merge 操作后更新。

#### Scenario: Version increment on merge
- **WHEN** 提案成功合并
- **THEN** 团队的 specs_version 递增 1，specs_fingerprint 重新计算为所有 spec 文件的组合哈希

#### Scenario: Get current version
- **WHEN** 调用 `GET /api/specs/version`
- **THEN** 返回当前 specs_version 和 specs_fingerprint
