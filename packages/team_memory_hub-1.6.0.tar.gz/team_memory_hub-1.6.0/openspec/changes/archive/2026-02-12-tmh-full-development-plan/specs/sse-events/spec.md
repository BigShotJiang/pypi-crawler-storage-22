## ADDED Requirements

### Requirement: SSE event stream endpoint
系统 SHALL 提供 `GET /api/events/stream` SSE 端点，支持实时事件推送。客户端通过 EventSource 连接后持续接收事件。

#### Scenario: Client connects to SSE
- **WHEN** 客户端连接 `GET /api/events/stream` 并提供有效认证
- **THEN** 服务端保持连接，实时推送事件

#### Scenario: Reconnection support
- **WHEN** SSE 连接断开后客户端重新连接
- **THEN** 服务端发送断开期间的未接收事件（基于 Last-Event-Id）

### Requirement: Event types
系统 SHALL 支持以下事件类型：context_updated（L0/L1 变更或 proposal merge）、memory_created（新记忆含聊天提取）、quality_changed（标记变更）、preference_suggestion（发现偏好）、proposal_status（提案状态变更）、migration_progress（向量迁移）、merge_suggestion（新合并建议）、memory_merged（合并已执行）。

#### Scenario: Context updated event
- **WHEN** 规范提案合并
- **THEN** SSE 推送 context_updated 事件，包含 team_id 和新 specs_version

#### Scenario: Merge suggestion event
- **WHEN** 自动扫描发现新的合并候选
- **THEN** SSE 推送 merge_suggestion 事件，包含建议 ID 和摘要

#### Scenario: Memory merged event
- **WHEN** maintainer 接受合并建议并执行
- **THEN** SSE 推送 memory_merged 事件，包含新记忆 ID 和合并来源 ID 列表

### Requirement: Event filtering
系统 SHALL 支持按 team_id 和 event_type 过滤 SSE 事件，避免推送无关事件。

#### Scenario: Filter by team
- **WHEN** 客户端连接 SSE 并指定 team_id
- **THEN** 仅接收该团队的事件
