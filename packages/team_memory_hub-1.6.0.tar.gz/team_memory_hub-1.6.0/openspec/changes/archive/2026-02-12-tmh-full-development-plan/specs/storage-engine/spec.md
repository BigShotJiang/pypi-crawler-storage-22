## ADDED Requirements

### Requirement: SQLite dual-engine storage
系统 SHALL 采用 SQLite + 文件系统双引擎存储架构。SQLite 存储结构化数据（元数据、摘要、向量索引、用户偏好、FTS5 全文索引、RBAC、审计日志），文件系统存储大文本（规范原文 `specs/*.md`、记忆原文 `memories/*.md`、聊天记录 `chats/*.jsonl`）。

#### Scenario: Memory storage split
- **WHEN** 创建一条新记忆
- **THEN** 摘要和元数据写入 SQLite memories 表，原文内容写入 `data/memories/{scope}/{year}/{month}/mem_{id}.md` 文件

#### Scenario: Spec storage
- **WHEN** 规范文件更新
- **THEN** 原文存储在 `data/specs/*.md` 文件中，摘要索引同步到 SQLite memories 表（layer=0）

### Requirement: Write queue with batching
系统 SHALL 使用 asyncio.Queue 实现写入队列，攒批提交（100ms 超时或 50 条触发批量事务）。SQLite busy_timeout 设为 10 秒。

#### Scenario: Batch write trigger by count
- **WHEN** 写入队列积累到 50 条记录
- **THEN** 系统在单个事务中批量提交所有记录

#### Scenario: Batch write trigger by timeout
- **WHEN** 写入队列有待处理记录且 100ms 内未达到 50 条
- **THEN** 系统在 100ms 超时后批量提交当前所有待处理记录

### Requirement: Data consistency guarantee
系统 SHALL 保证文件与索引的一致性：写入流程为先写文件 → 再写索引 → 失败则补偿删除文件。

#### Scenario: Index write failure compensation
- **WHEN** 文件写入成功但 SQLite 索引写入失败
- **THEN** 系统删除已写入的文件，返回写入失败错误

#### Scenario: File integrity check
- **WHEN** 定期维护任务执行
- **THEN** 系统通过 SHA256 校验文件完整性，清理孤儿文件，同步 specs/ 与索引一致性

### Requirement: Database migration
系统 SHALL 支持版本化数据库迁移。迁移版本号存储在 `_meta` 表中，服务启动时自动检测并执行未应用的迁移脚本。

#### Scenario: Auto migration on startup
- **WHEN** 服务启动且数据库版本低于代码版本
- **THEN** 系统自动执行所有未应用的迁移脚本，更新版本号

#### Scenario: First run initialization
- **WHEN** 服务首次启动且数据库文件不存在
- **THEN** 系统创建数据库文件并执行全部迁移脚本，生成完整 schema

### Requirement: WAL mode enabled
系统 SHALL 在 SQLite 连接时启用 WAL（Write-Ahead Logging）模式，允许并发读取不阻塞写入。

#### Scenario: Concurrent read during write
- **WHEN** 写入队列正在执行批量写入事务
- **THEN** 其他读取请求不被阻塞，可正常返回结果
