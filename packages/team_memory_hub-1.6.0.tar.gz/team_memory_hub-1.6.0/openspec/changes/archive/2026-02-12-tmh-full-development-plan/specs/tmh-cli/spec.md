## ADDED Requirements

### Requirement: Init command
系统 SHALL 提供 `tmh init` 命令，执行完整的项目接入流程：自动检测项目画像 → 匹配团队规范 → CLI 交互确认 → 语义去重 → 冲突解决 → 生成 AGENTS.md + .tmh/ + Hooks + Commands。

#### Scenario: Interactive init
- **WHEN** 执行 `tmh init`
- **THEN** 系统自动检测项目画像，交互式确认规范匹配，生成所有配置文件

#### Scenario: Non-interactive init
- **WHEN** 执行 `tmh init --non-interactive --project-priority`
- **THEN** 系统自动检测、匹配、以项目优先策略解决冲突，无交互

#### Scenario: Specify tools
- **WHEN** 执行 `tmh init --tools claude-code,cursor`
- **THEN** 系统仅生成指定工具的 Hook/Script/指令文件

### Requirement: Sync command
系统 SHALL 提供 `tmh sync` 命令，同步 context 和 AGENTS.md。支持 `--watch`（SSE 实时模式）、`--resolve`（解决新冲突）、`--force`（强制全量刷新）。

#### Scenario: Sync detects update
- **WHEN** 执行 `tmh sync` 且本地版本落后于服务器
- **THEN** 拉取增量变更，更新 AGENTS.md

#### Scenario: Watch mode
- **WHEN** 执行 `tmh sync --watch`
- **THEN** 通过 SSE 实时监听变更，自动同步

### Requirement: Memory commands
系统 SHALL 提供记忆相关 CLI 命令：`tmh store`（存储记忆）、`tmh search`（搜索记忆，默认混合搜索）、`tmh detail`（查看原文）。

#### Scenario: Store memory via CLI
- **WHEN** 执行 `tmh store "JWT 采用滑动窗口" --scope team --category decision`
- **THEN** 调用 API 存储记忆并输出记忆 ID

#### Scenario: Search with engine option
- **WHEN** 执行 `tmh search "JWT token" --engine vector_only`
- **THEN** 使用指定引擎搜索并显示结果

### Requirement: Chat ingest commands
系统 SHALL 提供 `tmh ingest` 命令，支持 `--file`（从文件导入）、`--stdin`（管道输入）、`--scan-cursor`（扫描 Cursor 聊天记录）。

#### Scenario: Ingest from file
- **WHEN** 执行 `tmh ingest --file chat.json --tool cursor`
- **THEN** 上传聊天记录并输出提取的记忆数量

#### Scenario: Ingest from stdin
- **WHEN** 执行 `codex ... | tmh ingest --stdin --tool codex`
- **THEN** 从标准输入读取并处理聊天记录

### Requirement: Spec management commands
系统 SHALL 提供规范管理 CLI 命令：`tmh specs list`、`tmh specs show`、`tmh specs propose`、`tmh specs proposals`、`tmh specs merge`、`tmh specs withdraw`。

#### Scenario: List specs
- **WHEN** 执行 `tmh specs list`
- **THEN** 显示所有团队规范的路径和摘要

#### Scenario: Create proposal via CLI
- **WHEN** 执行 `tmh specs propose "迁移JWT v2" --delta delta.md`
- **THEN** 创建提案并输出提案 ID

### Requirement: Consolidation commands
系统 SHALL 提供记忆整合 CLI 命令：`tmh consolidation list`、`tmh consolidation show`、`tmh consolidation accept`、`tmh consolidation reject`、`tmh consolidation scan`、`tmh consolidation stats`。

#### Scenario: List pending suggestions via CLI
- **WHEN** 执行 `tmh consolidation list`
- **THEN** 显示所有 pending 状态的合并建议

#### Scenario: Manual scan trigger
- **WHEN** 执行 `tmh consolidation scan`
- **THEN** 触发手动合并候选扫描
