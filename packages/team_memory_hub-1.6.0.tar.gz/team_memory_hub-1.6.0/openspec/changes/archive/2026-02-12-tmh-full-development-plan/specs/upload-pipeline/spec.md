## ADDED Requirements

### Requirement: Tier 1 hook auto callback
系统 SHALL 支持 Tier 1 Hook 自动回调上传，完全在 AI 上下文之外执行，零 token 消耗。支持 Claude Code Stop Hook 和 OpenCode onSessionEnd Hook。

#### Scenario: Claude Code post session hook
- **WHEN** Claude Code 会话结束触发 Stop Hook
- **THEN** Hook 脚本收集对话历史，POST 到 `/api/chats/ingest`，AI 上下文完全不可见，零 token 消耗

#### Scenario: Hook failure is silent
- **WHEN** Hook 脚本执行中 TMH Server 不可达
- **THEN** Hook 静默失败，不影响用户体验

### Requirement: Tier 2 Python script upload
系统 SHALL 提供 `.tmh/upload.py` Python 脚本，供 AI agent 通过 bash 调用。支持三个子命令：store（存储记忆）、chat（上传聊天）、propose（创建提案）。每次调用约 100 tokens。

#### Scenario: Store memory via script
- **WHEN** AI agent 执行 `python .tmh/upload.py store "JWT 采用滑动窗口" --scope team --category decision --tags jwt,auth`
- **THEN** 脚本调用 `POST /api/memories` 存储记忆

#### Scenario: Upload chat via script
- **WHEN** AI agent 执行 `python .tmh/upload.py chat --file session.json --tool cursor`
- **THEN** 脚本调用 `POST /api/chats/ingest` 上传聊天记录

### Requirement: Tier 3 MCP fallback
对于 Chatbox 等纯 MCP 工具，系统 SHALL 可选开启 MCP 写入工具（`store_memory`），通过配置 `mcp.enable_write_tools = true` 激活。默认关闭。

#### Scenario: MCP write enabled for Chatbox
- **WHEN** 配置 `mcp.enable_write_tools = true`
- **THEN** MCP Server 额外暴露 `store_memory` 工具

#### Scenario: MCP write disabled by default
- **WHEN** 使用默认配置
- **THEN** MCP Server 仅暴露 2 个读取工具

### Requirement: Tool-specific upload strategy
系统 SHALL 为每种 AI 工具推荐最优上传策略：Claude Code → Hook、OpenCode → Hook、Cursor → Script + .cursorrules、Codex → Script（管道重定向）、Chatbox → MCP。

#### Scenario: Init generates tool-specific config
- **WHEN** 执行 `tmh init --tools claude-code,cursor`
- **THEN** 系统生成 Claude Code Hook 配置和 Cursor 的 .cursorrules 上传指令
