## ADDED Requirements

### Requirement: Three-level preference priority
系统 SHALL 实现三级偏好优先级：项目级 > 用户全局 > 团队默认。读取偏好时按优先级逐级查找，首次命中即返回。

#### Scenario: Project preference overrides user
- **WHEN** 用户在项目 A 中设置 indent_style=tab，全局设置 indent_style=space
- **THEN** 在项目 A 的 context 中使用 tab，在其他项目中使用 space

#### Scenario: Team default fallback
- **WHEN** 用户未设置个人偏好，团队默认 test_framework=pytest
- **THEN** context 中使用 pytest 作为测试框架偏好

### Requirement: Preference CRUD API
系统 SHALL 提供偏好管理 API：`GET/PUT /api/preferences`（个人偏好）、`GET /api/preferences/resolved`（解析后偏好，合并三级）、`GET/PUT /api/team/preferences`（团队默认偏好，maintainer+）。

#### Scenario: Set personal preference
- **WHEN** 用户调用 `PUT /api/preferences` 提交 category="editor", key="indent_style", value="space"
- **THEN** 系统存储该偏好到 user_preferences 表

#### Scenario: Get resolved preferences
- **WHEN** 用户调用 `GET /api/preferences/resolved?project_id=xxx`
- **THEN** 返回合并三级后的最终偏好列表

### Requirement: Preference auto learning
系统 SHALL 使用 LLM 从聊天记录中识别用户偏好模式（如编码风格、工具偏好、响应风格），生成偏好建议存入 preference_suggestions 表，不自动写入，需用户确认。

#### Scenario: Preference suggestion from chat
- **WHEN** LLM 从聊天中识别用户反复使用 pytest 而非 unittest
- **THEN** 系统创建 preference_suggestion（key="test_framework", value="pytest"），推送通知

#### Scenario: Accept preference suggestion
- **WHEN** 用户调用 `POST /api/preferences/accept` 接受建议
- **THEN** 建议写入 user_preferences 表，建议状态变为 accepted

### Requirement: Preference injection in context
系统 SHALL 将解析后的用户偏好注入到 AGENTS.md 的"开发者偏好"区域。

#### Scenario: Preferences in AGENTS.md
- **WHEN** 生成 AGENTS.md 文件
- **THEN** 文件包含"开发者偏好"区域，列出 indent_style、test_framework、response_style 等偏好项
