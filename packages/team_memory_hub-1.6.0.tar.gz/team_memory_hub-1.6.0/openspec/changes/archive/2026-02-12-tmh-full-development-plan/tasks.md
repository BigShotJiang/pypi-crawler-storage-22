## 1. 项目骨架与基础设施

- [x] 1.1 初始化项目结构：创建 `pyproject.toml`（uv 包管理）、`src/team_memory_hub/` 目录布局、`__init__.py` 文件
- [x] 1.2 配置开发依赖：fastapi、uvicorn、httpx、aiosqlite、python-jose、jinja2、pydantic、pytest、pytest-asyncio
- [x] 1.3 创建 `tmh.toml.example` 配置模板（包含 server/search/embedding/consolidation/mcp 各区域默认值）
- [x] 1.4 实现配置加载模块 `src/team_memory_hub/config.py`：TOML 文件 → 环境变量覆盖 → CLI 参数覆盖
- [x] 1.5 创建 `Dockerfile` 和 `docker-compose.yml`，支持一键部署
- [x] 1.6 创建 `.env.example` 文件（TMH_SERVER、TMH_INGEST_KEY、EMBEDDING_PROVIDER 等环境变量模板）

## 2. 存储引擎（storage-engine）

- [x] 2.1 实现 `storage/database.py`：异步 SQLite 连接管理（aiosqlite）、WAL 模式启用、busy_timeout=10s
- [x] 2.2 实现 `storage/migrations/v1.py`：创建完整 schema（teams、users、api_keys、projects、project_members、memories、memory_embeddings、memory_versions、spec_proposals、spec_applicability、user_preferences、team_default_preferences、preference_suggestions、chat_sessions、audit_logs 及所有索引）
- [x] 2.3 实现 `storage/migrations/v1_5.py`：创建 V1.5 新增 schema（memories_fts FTS5 虚拟表 + 同步触发器、merge_suggestions 表、memories.merged_into 字段、相关索引）
- [x] 2.4 实现数据库版本检测与自动迁移逻辑（`_meta` 表存储版本号，启动时检测并执行）
- [x] 2.5 实现 `storage/models.py`：所有 Pydantic 数据模型（MemoryCreate、MemoryResponse、SearchResult、MergeSuggestion 等）
- [x] 2.6 实现 `core/write_queue.py`：asyncio.Queue 写入队列，100ms/50 条攒批事务提交
- [x] 2.7 实现 `core/memory_file_store.py`：文件系统存储（记忆 .md 文件读写、YAML front-matter 解析、目录结构 `data/memories/{scope}/{year}/{month}/`）
- [x] 2.8 实现数据一致性保证逻辑：先写文件 → 再写索引 → 失败补偿删除文件
- [x] 2.9 编写存储引擎单元测试和集成测试（内存 SQLite + 临时目录）

## 3. 认证与权限（auth-and-rbac）

- [x] 3.1 实现 `server/routes/auth.py`：JWT 认证端点（`POST /api/auth/token`、`POST /api/auth/token/refresh`、`GET /api/auth/me`），access_token 15min、refresh_token 30 天滑动窗口
- [x] 3.2 实现 `server/dependencies.py`：FastAPI 依赖注入（get_current_user、require_role、api_key_auth）
- [x] 3.3 实现 `server/routes/keys.py`：API Key CRUD（`POST/GET/DELETE /api/keys`），支持 scope（full_access/mcp_only/read_only/sync_only/ingest_only）
- [x] 3.4 实现 `core/rbac.py`：RBAC 四级角色权限检查（admin > maintainer > member > viewer），权限矩阵按架构文档第 12 节实现
- [x] 3.5 实现私有数据隔离逻辑：scope=private 的数据仅所有者可访问
- [x] 3.6 编写认证与权限测试

## 4. 记忆管理（memory-management）

- [x] 4.1 实现 `core/memory_store.py`：记忆 CRUD 核心逻辑（创建含 ID 生成 mem_ 前缀、摘要写入 SQLite、原文写入文件、embedding 生成）
- [x] 4.2 实现 `server/routes/memories.py`：记忆 API 端点（`POST/GET/PUT/DELETE /api/memories`、`GET /api/memories/:id/detail`、`GET /api/memories/:id/versions`）
- [x] 4.3 实现记忆质量生命周期标记 API：`POST /api/memories/:id/{verify,stale,pin,archive}`
- [x] 4.4 实现记忆版本追踪逻辑：更新时在 memory_versions 表创建版本记录
- [x] 4.5 实现 scope 和 category 过滤查询
- [x] 4.6 编写记忆管理 API 测试

## 5. Embedding Provider 层（embedding-providers）

- [x] 5.1 实现 `providers/embedding/base.py`：EmbeddingProvider 抽象基类（TARGET_DIMENSIONS=384、embed、embed_single、_normalize_dimensions）
- [x] 5.2 实现 `providers/embedding/gemini.py`：GeminiProvider（768→384 截断）
- [x] 5.3 实现 `providers/embedding/openai_provider.py`：OpenAIProvider（1536→384 截断）
- [x] 5.4 实现 `providers/embedding/onnx.py`：ONNXLocalProvider（原生 384 维）
- [x] 5.5 实现 `providers/embedding/openai_compatible.py`：OpenAICompatibleProvider（通用 base_url 适配 Ollama/vLLM/TEI/LocalAI）
- [x] 5.6 实现 Provider 工厂函数：根据 tmh.toml 配置自动选择 Provider
- [x] 5.7 编写 Provider 测试（mock 外部 API）

## 6. 混合搜索引擎（hybrid-search）

- [x] 6.1 实现 `core/search_engine.py` — HybridSearchEngine 类：双路并行检索（向量 KNN + FTS5 BM25）
- [x] 6.2 实现向量搜索路径：`_vector_search()` — sqlite-vec KNN 余弦距离搜索
- [x] 6.3 实现 BM25 搜索路径：`_bm25_search()` — FTS5 MATCH 查询
- [x] 6.4 实现 Score Fusion 评分：min-max 归一化 → α×semantic + β×bm25 融合
- [x] 6.5 实现三层评分后处理：project_boost(+20%)、time_decay(7 天+10%/90 天-15%)、verified_boost(+15%)
- [x] 6.6 实现搜索 API 端点 `GET /api/search`，返回 SearchResult 含 score
- [x] 6.7 实现搜索引擎配置切换：hybrid / vector_only / bm25_only 模式
- [x] 6.8 编写混合搜索测试（含各种查询场景：精确术语、语义、缩写、中文）

## 7. Context 引擎（context-engine）

- [x] 7.1 实现 `core/context_engine.py`：三层 Context 构建逻辑（Layer 0 pinned/verified 团队标准、Layer 1 项目上下文、Layer 2 按需搜索）
- [x] 7.2 实现 `core/context_cache.py`：缓存管理（Layer 0 缓存 1h、Layer 1 缓存 10min、invalidate/invalidate_prefix 支持）
- [x] 7.3 实现 `server/routes/context.py`：Context API（`GET /api/context`、`POST /api/context/invalidate`）
- [x] 7.4 编写 Context 引擎测试

## 8. 规范管理（spec-management）

- [x] 8.1 实现 `core/spec_manager.py`：规范文件读取（从 `data/specs/` 加载）、版本指纹计算（SHA256 组合哈希）、Delta 格式解析与合并
- [x] 8.2 实现 `server/routes/specs.py`：规范 API（`GET /api/specs/files`、`GET /api/specs/files/:path`、`PUT /api/specs/files/:path`）
- [x] 8.3 实现提案生命周期 API：`POST /api/specs/proposals`（创建）、`GET /api/specs/proposals`（列表）、`PATCH /api/specs/proposals/:id/status`（状态更新）、`POST /api/specs/proposals/:id/merge`（合并）
- [x] 8.4 实现提案合并逻辑：解析 Delta（ADDED/MODIFIED/REMOVED）→ 修改目标 spec 文件 → 更新 specs_version 和 fingerprint
- [x] 8.5 编写规范管理测试

## 9. 项目接入与同步（project-onboarding）

- [x] 9.1 实现 `core/project_detector.py`：ProjectDetector（文件特征扫描 → 依赖分析 → 已有规范扫描 → 输出 ProjectProfile）
- [x] 9.2 实现 `core/rule_normalizer.py`：RuleNormalizer（editorconfig/ruff/eslint/TMH spec → NormalizedRule 标准化）
- [x] 9.3 实现 `core/spec_deduplicator.py`：SpecDeduplicator（逐条语义比较 → 等价/冲突/独有分类）
- [x] 9.4 实现冲突解决逻辑（merge/tmh_priority/project_priority/skip 策略）和 `.tmh/overrides.json` 持久化
- [x] 9.5 实现 `core/context_syncer.py`：ContextSyncer（版本对比 → 增量拉取 → 去重 → 更新 AGENTS.md），支持 SSE/Git hook/手动三种触发模式
- [x] 9.6 实现 SpecMatcher：规范适用条件匹配（languages/frameworks/project_types 过滤 + 置信度计算）
- [x] 9.7 编写项目接入测试

## 10. 上传管道（upload-pipeline）

- [x] 10.1 创建 `scaffold/hooks/post_session.py`：Claude Code Stop Hook 脚本（收集会话 → POST /api/chats/ingest → 静默失败）
- [x] 10.2 创建 `scaffold/.tmh/upload.py`：Tier 2 Python 上传脚本（store/chat/propose 三个子命令）
- [x] 10.3 创建 OpenCode onSessionEnd Hook 脚本模板
- [x] 10.4 实现 `tmh init` 时根据指定工具生成对应的 Hook/Script 配置

## 11. 聊天捕获与提取（chat-capture）

- [x] 11.1 实现 `chat_adapters/base.py`：ChatAdapter 抽象基类（convert 方法）
- [x] 11.2 实现 5 种聊天适配器：`claude_code.py`、`cursor.py`、`opencode.py`、`chatbox.py`、`codex.py`
- [x] 11.3 实现 `core/chat_ingest.py`：聊天接收逻辑（选择适配器 → 转换格式 → 存储 JSONL → 触发提取）
- [x] 11.4 实现 `core/memory_extractor.py`：LLM 智能记忆提取（分类为决策/经验/规范/bug）
- [x] 11.5 实现规则引擎降级提取（关键词 + 正则，LLM 不可用时使用）
- [x] 11.6 实现 `server/routes/chats.py`：聊天 API（`POST /api/chats/ingest`、`GET /api/chats`、`GET /api/chats/:id`）
- [x] 11.7 编写聊天捕获和提取测试

## 12. 用户偏好（user-preferences）

- [x] 12.1 实现 `core/preference_engine.py`：三级优先级解析（项目 > 用户全局 > 团队默认）
- [x] 12.2 实现 `server/routes/preferences.py`：偏好 API（`GET/PUT /api/preferences`、`GET /api/preferences/resolved`、`GET /api/preferences/suggestions`、`POST /api/preferences/accept`）
- [x] 12.3 实现团队默认偏好 API：`GET/PUT /api/team/preferences`（maintainer+ 权限）
- [x] 12.4 实现偏好自动学习逻辑（LLM 从聊天中识别偏好模式 → preference_suggestions）
- [x] 12.5 编写偏好系统测试

## 13. MCP Server（mcp-server）

- [x] 13.1 实现 `server/mcp_server.py`：MCP Server（search_memory + get_memory_detail 两个读取工具）
- [x] 13.2 实现可选写入工具开关：`mcp.enable_write_tools = true` 时暴露 store_memory
- [x] 13.3 实现 MCP 认证：API Key scope=mcp_only 校验
- [x] 13.4 编写 MCP Server 测试

## 14. 客户端集成（client-integration）

- [x] 14.1 实现 `core/agents_generator.py`：AGENTS.md 生成器（Header 注释 + Layer 0 规范 + Layer 1 上下文 + 偏好 + 记忆管理指令）
- [x] 14.2 实现 `client_adapters/base.py` 和各工具适配器（claude_code/cursor/opencode/chatbox/codex）：生成工具专用指令文件
- [x] 14.3 创建 `scaffold/slash_commands/`：Claude Code、Cursor、OpenCode 的 Slash Command 配置模板（/tmh:store、/tmh:search、/tmh:propose、/tmh:sync）
- [x] 14.4 创建 `scaffold/agents_md_template.md`：AGENTS.md 模板文件
- [x] 14.5 创建 `scaffold/git_hooks/post-merge`：Git post-merge hook 用于自动触发 tmh sync

## 15. SSE 实时事件（sse-events）

- [x] 15.1 实现 `server/event_bus.py`：内存事件总线（publish/subscribe 模式）
- [x] 15.2 实现 `server/routes/events.py`：SSE 端点（`GET /api/events/stream`），支持 team_id 和 event_type 过滤
- [x] 15.3 在各模块中集成事件发布：memory_created、quality_changed、context_updated、proposal_status、merge_suggestion、memory_merged
- [x] 15.4 编写 SSE 端点测试

## 16. 记忆整合（memory-consolidation）

- [x] 16.1 实现 `core/memory_consolidator.py`：MemoryConsolidator 类（detect_merge_candidates 贪心聚类 + generate_merge_suggestion LLM 合并 + execute_merge 执行合并）
- [x] 16.2 实现私有记忆自动整合逻辑：auto_consolidate_private 配置控制
- [x] 16.3 实现 `server/routes/consolidation.py`：合并建议 API（GET suggestions 列表/详情、POST accept/reject/dismiss、POST scan 手动触发、GET stats 统计）
- [x] 16.4 编写记忆整合测试

## 17. 自动维护任务（curation-tasks）

- [x] 17.1 实现 `core/curation.py`：策展任务管理器（定时调度、任务注册）
- [x] 17.2 实现每日任务：detect_duplicates（相似度>0.92 重复检测）
- [x] 17.3 实现每日任务：detect_staleness（180 天未检索 → stale）+ auto_archive（stale 30 天 → archived）
- [x] 17.4 实现每日任务：refresh_quality_scores（重新计算质量分）
- [x] 17.5 实现每日任务：verify_file_integrity（SHA256 校验）+ clean_orphan_files（孤儿清理）+ sync_specs_index（规范索引同步）
- [x] 17.6 实现每日任务：scan_merge_candidates（V1.5 合并候选扫描）+ clean_old_suggestions（过期建议清理）+ clean_old_audit_logs（审计日志清理）
- [x] 17.7 实现 `providers/embedding/migrator.py`：按需 embedding 迁移任务
- [x] 17.8 编写维护任务测试

## 18. tmh CLI（tmh-cli）

- [x] 18.1 实现 `cli/main.py`：CLI 入口（使用 argparse 或 click），注册所有子命令
- [x] 18.2 实现 `tmh init` 命令：项目画像检测 → 规范匹配 → 交互确认 → 去重 → 冲突解决 → 生成配置文件（支持 --tools、--non-interactive、--project-priority、--git-hooks）
- [x] 18.3 实现 `tmh sync` 命令：Context 同步 + AGENTS.md 更新（支持 --watch、--resolve、--force）
- [x] 18.4 实现 `tmh store` / `tmh search` / `tmh detail` 命令：记忆操作
- [x] 18.5 实现 `tmh ingest` 命令：聊天导入（--file、--stdin、--scan-cursor、--tool）
- [x] 18.6 实现 `tmh prefs` 命令：偏好管理（list/set/suggestions）
- [x] 18.7 实现 `tmh specs` 命令：规范管理（list/show/propose/proposals/merge/withdraw）
- [x] 18.8 实现 `tmh consolidation` 命令：记忆整合（list/show/accept/reject/scan/stats）
- [x] 18.9 编写 CLI 测试

## 19. Web Dashboard（dashboard）

- [x] 19.1 创建 `dashboard/templates/` 基础布局模板（base.html、nav、header、footer），使用 Pico CSS / simple.css
- [x] 19.2 实现概览页面：团队统计（记忆总数、活跃用户、待处理建议）
- [x] 19.3 实现记忆浏览页面：列表展示 + scope/category/quality/project 过滤 + 详情展开（HTMX 动态加载）
- [x] 19.4 实现合并建议审核页面：概览统计 + 建议列表 + 详情视图（左右对比原文 vs 合并预览）+ 操作按钮
- [x] 19.5 实现规范与提案管理页面：规范列表 + 提案列表 + delta 查看
- [x] 19.6 实现搜索调试页面：查询输入 + 结果展示（含 score_breakdown 各路评分明细）
- [x] 19.7 实现 Dashboard 认证（复用 JWT 或 session-based）
- [x] 19.8 集成 SSE 实时更新（HTMX SSE 扩展）

## 20. FastAPI 应用组装与系统集成

- [x] 20.1 实现 `server/app.py`：FastAPI 应用入口，注册所有路由、中间件（CORS、认证、审计日志）、依赖注入、启动/关闭钩子
- [x] 20.2 实现 `server/routes/team.py` + `server/routes/projects.py`：团队和项目 CRUD API
- [x] 20.3 实现 `core/audit.py` + `server/routes/audit.py`：审计日志记录与查询
- [x] 20.4 实现 `server/routes/system.py`：健康检查 `GET /api/health` + 系统设置 `GET/PUT /api/settings`
- [x] 20.5 实现 LLM Provider 层：`providers/llm/base.py`、`claude.py`、`gemini.py`、`rules.py`（规则引擎降级）
- [x] 20.6 端到端集成测试：从 tmh init → 存储记忆 → 搜索 → 合并建议 → 整合完整流程

## 21. 文档与部署

- [x] 21.1 编写项目根 README.md（双语：中文 + 英文），包含项目介绍、快速开始、架构概述
- [x] 21.2 完善 docker-compose.yml：包含 TMH Server + 可选 Ollama embedding 服务
- [x] 21.3 编写 API 文档（利用 FastAPI 自动生成的 OpenAPI/Swagger）
- [x] 21.4 创建 `data/` 目录初始化脚本（specs/、memories/、chats/ 目录结构）
