## Context

TMH 项目 V1.6 架构设计文档已定义完整的系统架构（25 章），现有代码实现了约 75-80% 的核心引擎层（`src/team_memory_hub/core/*`），但服务器基础设施、MCP Server、完整 API 路由层、Provider 实现、Dashboard UI、测试覆盖等关键部分缺失或为空壳。项目无法启动和部署。

**已有资产**：
- 18 个 OpenSpec specs 已归档并同步
- `core/` 下 18+ 个完整实现的引擎模块
- `config.py` 完整配置系统
- `storage/database.py` + `models.py` 数据层
- `cli/main.py` 完整 CLI 工具（520 行）
- `server/app.py` FastAPI 框架骨架（166 行）
- `Dockerfile` + `docker-compose.yml`

**约束**：
- Python 3.11+，FastAPI，SQLite（WAL + FTS5 + sqlite-vec）
- MCP 使用官方 Python SDK
- Dashboard 使用 Jinja2 + HTMX（零构建）
- 统一 384 维 embedding
- 所有图表使用 Mermaid

## Goals / Non-Goals

**Goals:**
- 使 TMH 可以通过 `uvicorn` 或 `docker compose up` 正常启动
- 实现 V1.6 全部 HTTP API 端点（40+ 路由）
- 实现 V1.6 MCP Server（全 CRUD 5 工具 + tool_set 配置）
- 实现所有 Embedding/LLM Provider（含规则引擎降级）
- 实现 5 个 Chat Adapter 的完整解析逻辑
- 提供可用的 Dashboard 管理界面
- 建立完整的数据库初始化迁移（V1.6 schema）
- 建立基本的测试覆盖（核心路径）

**Non-Goals:**
- OAuth 2.1 认证（V2 范围）
- 前端 SPA 重构（当前用 Jinja2 + HTMX）
- PostgreSQL/Redis 支持
- 多团队 SaaS 模式
- 100% 测试覆盖（先覆盖核心路径）

## Decisions

### D1: 依赖注入方案 — FastAPI Depends + 模块级单例

**选择**：使用 FastAPI 原生 `Depends` + `app.state` 生命周期管理
**替代方案**：dependency-injector 库、手动全局变量
**理由**：FastAPI Depends 是框架原生方式，已有 `server/app.py` 的 lifespan 模式。无需引入额外依赖。`dependencies.py` 作为工厂函数集中管理所有核心服务实例。

### D2: 事件总线 — 进程内 asyncio 发布/订阅

**选择**：基于 `asyncio.Queue` 的简单发布/订阅模式
**替代方案**：Redis Pub/Sub、外部消息队列
**理由**：TMH 是单进程部署（SQLite 限制），进程内事件总线足够。SSE 端点订阅事件总线，Dashboard 和 CLI 通过 SSE 接收推送。与写入队列复用 asyncio 模式。

### D3: 数据库迁移 — 内置 Python 迁移脚本

**选择**：`storage/migrations/` 下编号 Python 脚本，启动时自动执行
**替代方案**：Alembic、手动 SQL 文件
**理由**：已有 `database.py` 中的迁移系统框架。SQLite 不支持 ALTER TABLE ADD CONSTRAINT 等 DDL，纯 SQL 迁移受限。Python 脚本可以处理数据变换。V001 为完整 schema 初始化。

### D4: MCP Server — 独立 FastMCP 进程 + 共享核心引擎

**选择**：使用 `mcp` Python SDK（FastMCP），与 HTTP Server 共享 core 层
**替代方案**：内嵌 MCP 到 FastAPI、完全独立服务
**理由**：MCP 协议走 stdio 或 SSE，与 HTTP 是不同的传输层。共享 core 层避免代码重复。通过 `tool_set` 配置动态注册工具。

### D5: Embedding Provider — 工厂模式 + 统一接口

**选择**：`EmbeddingProvider` ABC + 工厂函数根据 config 返回具体实现
**替代方案**：策略模式、插件系统
**理由**：V1.6 文档已定义清晰的 Provider 类层次。4 种 provider 接口一致（embed/embed_single），差异仅在 API 调用和维度裁剪。工厂模式简单够用。

### D6: Dashboard — Jinja2 模板 + HTMX 动态交互

**选择**：服务端渲染 + HTMX 片段替换
**替代方案**：React SPA、Vue SPA
**理由**：V1.6 架构文档明确指定 Jinja2 + HTMX + Chart.js。零构建步骤，CDN 加载前端库。管理界面交互不复杂，SSR 足够。

### D7: 测试策略 — pytest + httpx + 内存 SQLite

**选择**：pytest 异步测试，httpx.AsyncClient 测试 API，内存 SQLite（`:memory:`）隔离
**替代方案**：unittest、外部测试数据库
**理由**：`pyproject.toml` 已配置 pytest。内存 SQLite 保证测试隔离和速度。httpx.AsyncClient 是 FastAPI 推荐的测试方式。

## Risks / Trade-offs

| 风险 | 影响 | 缓解 |
|------|------|------|
| sqlite-vec 扩展在某些平台不可用 | 向量搜索无法使用 | 提供 fallback：纯 BM25 搜索模式 |
| ONNX Runtime 在 ARM/Windows 上可能有兼容性问题 | 本地 embedding 不可用 | ONNX 是可选 provider，配置其他 provider 即可 |
| FTS5 tokenizer 对中文支持有限 | 中文搜索质量下降 | unicode61 tokenizer 按 Unicode 分词可用；后续可引入 jieba 分词 |
| MCP SDK 版本更新可能破坏兼容 | MCP 工具不可用 | 锁定 MCP SDK 版本，测试覆盖 |
| Dashboard 无 CSRF 保护 | 安全风险 | 当前内网部署场景可接受；生产环境需加 CSRF token |
| 单进程 SQLite 写入瓶颈 | 高并发下写入延迟 | 写入队列攒批已缓解；<100 人团队场景足够 |
