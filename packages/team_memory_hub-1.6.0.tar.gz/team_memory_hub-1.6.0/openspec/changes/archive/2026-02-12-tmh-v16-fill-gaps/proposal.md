## Why

TMH 项目已有 ~75-80% 的核心引擎代码（core/*），但**缺少让系统真正运行起来的关键基础设施**：服务器入口点仍是 PyCharm 模板、MCP Server 完全缺失（V1.6 核心变更）、API 路由不完整、数据库迁移未建立、Dashboard 为空壳、测试覆盖为零。当前状态下项目无法启动、无法测试、无法部署。需要补全这些缺口，使 TMH 从"设计文档+核心引擎"进入"可运行的完整系统"。

## What Changes

### 新增实现
- **服务器基础设施**：真正的 FastAPI 入口点（替换 PyCharm 模板）、依赖注入容器（`dependencies.py`）、事件总线（`event_bus.py`）
- **数据库迁移系统**：V1.6 完整 schema（20+ 表、索引、FTS5 虚拟表、触发器）的初始化迁移
- **MCP Server 实现**：V1.6 全 CRUD 5 工具 + `tool_set` 配置控制（`read_only` / `read_write` / `full_crud`）
- **API 路由补全**：`events.py`（SSE）、`system.py`（健康检查+设置）、`curation.py`、`team.py`、`projects.py`、`consolidation.py`、`specs.py`、`context.py` 等缺失路由
- **Embedding/LLM Provider 实现**：4 种 embedding provider（Gemini/OpenAI/ONNX/OpenAI-Compatible）+ 3 种 LLM provider（Claude/Gemini/规则引擎）
- **Chat Adapter 解析逻辑**：5 个适配器（Claude Code/Cursor/OpenCode/Chatbox/Codex）的完整解析实现
- **Dashboard UI**：基于 Jinja2 + HTMX 的管理界面（记忆列表、合并建议、规范管理、统计面板）
- **测试套件**：核心引擎、API 路由、MCP Server 的单元测试和集成测试

### 修改
- **MCP Server spec 更新**：从"仅 2 读取工具"升级为"最多 5 工具全 CRUD + 权限矩阵"（V1.6 核心变更）

## Capabilities

### New Capabilities
- `server-infrastructure`: 服务器入口点、依赖注入、事件总线、数据库迁移初始化
- `api-routes`: 完整的 HTTP API 路由层实现（对应 V1.6 文档第 19 章 40+ 端点）
- `embedding-llm-providers`: Embedding 和 LLM Provider 的完整实现（4+3 种 provider）
- `chat-adapter-impl`: 5 个聊天适配器的完整解析逻辑实现
- `dashboard-ui`: Jinja2 + HTMX 管理界面（记忆、合并建议、规范、统计）
- `test-suite`: 核心引擎、API、MCP 的测试覆盖

### Modified Capabilities
- `mcp-server`: V1.6 变更 — 从仅 2 读取工具升级为全 CRUD 5 工具，新增 `tool_set` 配置和 RBAC 权限矩阵

## Impact

- **代码**：新增 ~30 个文件，修改 ~5 个已有文件（`main.py`、`server/app.py`、MCP 相关）
- **API**：补全 40+ HTTP 端点（认证、记忆 CRUD、搜索、聊天、偏好、规范、整合、策展、团队、项目、审计、SSE、系统）
- **依赖**：新增 `mcp`（Python SDK）、`jinja2`、`onnxruntime`、`google-generativeai`、`anthropic` 等
- **数据库**：创建完整的 V1.6 schema 迁移（20+ 表 + FTS5 + sqlite-vec + 触发器 + 索引）
- **部署**：`main.py` 入口变更，Docker 配置可能需微调
