## ADDED Requirements

### Requirement: Authentication routes
系统 SHALL 实现认证路由 `routes/auth.py`：`POST /api/auth/token`（JWT 签发）、`GET /api/auth/me`（当前用户信息）。

#### Scenario: Login and get token
- **WHEN** POST /api/auth/token，提供有效的 email 和 password
- **THEN** 返回 JWT access token，包含 user_id、team_id、role

#### Scenario: Get current user
- **WHEN** GET /api/auth/me，携带有效 JWT
- **THEN** 返回当前用户信息（id、name、email、role、team_id）

### Requirement: API key management routes
系统 SHALL 实现 Key 管理路由 `routes/keys.py`：`POST /api/keys`（创建）、`GET /api/keys`（列表）、`DELETE /api/keys/:id`（吊销）。

#### Scenario: Create API key
- **WHEN** POST /api/keys，指定 name 和 scope（full_access/mcp_only/read_only/sync_only/ingest_only）
- **THEN** 返回新创建的 API Key（仅首次返回明文 key）

#### Scenario: List user keys
- **WHEN** GET /api/keys
- **THEN** 返回当前用户的所有 API Key 列表（不含明文 key）

### Requirement: Memory CRUD routes
系统 SHALL 实现记忆 CRUD 路由 `routes/memories.py`：POST（创建）、GET /:id（摘要）、GET /:id/detail（原文）、PUT /:id（更新）、DELETE /:id（软删除）、GET（列表）、GET /:id/versions（版本历史）。

#### Scenario: Create memory
- **WHEN** POST /api/memories，提供 content、scope、category、tags
- **THEN** 生成摘要+embedding，写入文件和索引，返回 memory_id

#### Scenario: Update memory
- **WHEN** PUT /api/memories/:id，提供更新内容
- **THEN** 创建新版本记录，更新文件和索引

#### Scenario: Soft delete memory
- **WHEN** DELETE /api/memories/:id（需 admin 角色）
- **THEN** 记忆 quality 变为 archived，不从文件系统删除

### Requirement: Search route
系统 SHALL 实现搜索路由：`POST /api/memories/search`，使用混合搜索引擎（BM25 + 向量 Score Fusion）。

#### Scenario: Hybrid search
- **WHEN** POST /api/memories/search，提供 query、scope、category、limit
- **THEN** 返回按融合分数排序的结果列表，每条包含 id、summary、score、score_breakdown

### Requirement: Chat ingest routes
系统 SHALL 实现聊天摄入路由 `routes/chats.py`：`POST /api/chats/ingest`（上传+提取）、`GET /api/chats`（列表）、`GET /api/chats/:id`（详情）。

#### Scenario: Ingest chat session
- **WHEN** POST /api/chats/ingest，提供 tool_name 和 raw_data
- **THEN** 适配器解析原始数据为统一 JSONL，LLM 提取记忆，返回 {memories_created: N}

### Requirement: Preference routes
系统 SHALL 实现偏好路由 `routes/preferences.py`：GET/PUT 用户偏好、GET resolved 偏好、GET suggestions、POST accept。

#### Scenario: Get resolved preferences
- **WHEN** GET /api/preferences/resolved
- **THEN** 返回三级优先级解析后的最终生效偏好（项目级 > 用户全局 > 团队默认）

#### Scenario: Accept preference suggestion
- **WHEN** POST /api/preferences/accept，提供 suggestion_id
- **THEN** 将建议写入 user_preferences，标记建议为 accepted

### Requirement: Spec and proposal routes
系统 SHALL 实现规范路由 `routes/specs.py`：GET specs 列表/内容/版本指纹、POST proposals 创建、GET proposals 列表/详情、POST merge/withdraw。

#### Scenario: Create spec proposal
- **WHEN** POST /api/specs/proposals，提供 title、description、delta
- **THEN** 创建 draft 状态的规范提案

#### Scenario: Merge proposal
- **WHEN** POST /api/specs/proposals/:id/merge（需 maintainer+ 角色）
- **THEN** 将 delta 应用到 specs/，更新 specs_version 和 specs_fingerprint

### Requirement: Consolidation routes
系统 SHALL 实现整合路由 `routes/consolidation.py`：GET suggestions 列表/详情、POST accept/reject/dismiss、POST scan、GET stats。

#### Scenario: Accept merge suggestion
- **WHEN** POST /api/consolidation/suggestions/:id/accept（需 maintainer+ 角色）
- **THEN** 创建合并记忆，原始记忆归档，更新索引，发布 memory_merged 事件

### Requirement: Context routes
系统 SHALL 实现 Context 路由 `routes/context.py`：`GET /api/context/:user_id`（预加载三层 context）、`POST /api/context/refresh`（强制刷新缓存）。

#### Scenario: Get preloaded context
- **WHEN** GET /api/context/:user_id
- **THEN** 返回 Layer 0（团队规范） + Layer 1（活跃上下文+偏好）组装后的内容

### Requirement: Curation routes
系统 SHALL 实现策展路由 `routes/curation.py`：`POST /api/memories/:id/{verify,stale,pin,archive}`。

#### Scenario: Verify memory
- **WHEN** POST /api/memories/:id/verify（需 maintainer+ 角色）
- **THEN** 记忆 quality 变为 verified，记录 verified_by 和 verified_at

### Requirement: Team and project routes
系统 SHALL 实现团队路由 `routes/team.py`（CRUD members、GET/PUT team preferences）和项目路由 `routes/projects.py`（CRUD projects）。

#### Scenario: Add team member
- **WHEN** POST /api/team/members（需 admin 角色）
- **THEN** 创建新用户并分配角色

### Requirement: SSE events route
系统 SHALL 实现 SSE 路由 `routes/events.py`：`GET /api/events/stream`，推送实时事件（context_updated、memory_created、quality_changed、merge_suggestion 等 8 种事件类型）。

#### Scenario: SSE connection and heartbeat
- **WHEN** 客户端连接 GET /api/events/stream
- **THEN** 保持 SSE 连接，每 30 秒发送 heartbeat，接收到事件时实时推送

### Requirement: System routes
系统 SHALL 实现系统路由 `routes/system.py`：`GET /api/health`（增强版健康检查）、`GET/PUT /api/settings`。

#### Scenario: Health check
- **WHEN** GET /api/health
- **THEN** 返回各组件状态（database、cache、write_queue、embedding_provider、llm_provider、file_storage）和版本号

### Requirement: Audit routes
系统 SHALL 实现审计路由 `routes/audit.py`：`GET /api/audit/logs`（需 maintainer+ 角色），支持按 user_id、action、时间范围过滤。

#### Scenario: Query audit logs
- **WHEN** GET /api/audit/logs?action=memory_created&limit=50
- **THEN** 返回最近 50 条 memory_created 操作的审计日志
