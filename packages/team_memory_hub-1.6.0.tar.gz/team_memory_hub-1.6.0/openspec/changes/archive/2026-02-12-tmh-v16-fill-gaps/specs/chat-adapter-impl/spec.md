## ADDED Requirements

### Requirement: Claude Code chat adapter
系统 SHALL 实现 `ClaudeCodeChatAdapter`，解析 Claude Code 的 JSON 会话数据为统一 `ChatSession` 格式。MUST 提取 session_id、user messages、assistant messages、tool_calls。

#### Scenario: Parse Claude Code session
- **WHEN** Claude Code Stop Hook 传入 JSON 格式的会话数据
- **THEN** 解析为 ChatSession 对象，包含元数据（session_id、tool="claude-code"、started_at）和按时间排序的 turns 列表

#### Scenario: Extract tool calls
- **WHEN** 会话中 assistant 使用了 create_file、edit_file 等工具
- **THEN** 在对应 turn 的 tool_calls 字段中记录工具名称和参数

### Requirement: Cursor chat adapter
系统 SHALL 实现 `CursorChatAdapter`，处理 Cursor 的会话数据。由于 Cursor 无官方导出 API，支持三种策略：A) 通过 .cursorrules 指示 AI 调用 MCP/Script 输出的结构化数据；B) 手动导出的 JSON；C) tmh ingest --scan-cursor 扫描结果。

#### Scenario: Parse Cursor structured output
- **WHEN** Cursor 通过 .cursorrules 指示输出的结构化 JSON 数据传入
- **THEN** 解析为 ChatSession，提取用户问题和 AI 回答

#### Scenario: Handle incomplete data
- **WHEN** Cursor 数据缺少 timestamp 等字段
- **THEN** 使用当前时间填充缺失字段，不报错

### Requirement: OpenCode chat adapter
系统 SHALL 实现 `OpenCodeChatAdapter`，解析 OpenCode onSessionEnd 事件传入的 JSON 会话数据。

#### Scenario: Parse OpenCode session
- **WHEN** OpenCode onSessionEnd hook 传入 JSON 数据
- **THEN** 解析为 ChatSession，保留完整的对话轮次和工具调用信息

### Requirement: Chatbox chat adapter
系统 SHALL 实现 `ChatboxChatAdapter`，解析 Chatbox 通过 MCP Resource 或手动导出的 JSON 会话数据。

#### Scenario: Parse Chatbox export
- **WHEN** Chatbox 导出的 JSON 数据传入（包含 messages 数组）
- **THEN** 解析为 ChatSession，区分 user/assistant 角色

### Requirement: Codex chat adapter
系统 SHALL 实现 `CodexChatAdapter`，解析 Codex CLI 管道重定向的文本流数据。

#### Scenario: Parse Codex text stream
- **WHEN** Codex CLI 输出通过管道重定向传入（`codex ... | tmh ingest --stdin`）
- **THEN** 解析文本流为 ChatSession，识别 user prompt 和 assistant response 边界

#### Scenario: Handle raw text format
- **WHEN** 传入纯文本格式（非 JSON）
- **THEN** 使用文本分割策略识别对话轮次

### Requirement: Adapter registry
系统 SHALL 维护聊天适配器注册表，根据 tool_name 自动选择对应适配器。支持的 tool_name：claude-code、cursor、opencode、chatbox、codex。

#### Scenario: Auto-select adapter
- **WHEN** POST /api/chats/ingest 传入 tool_name="claude-code"
- **THEN** 自动选择 ClaudeCodeChatAdapter 解析数据

#### Scenario: Unknown tool name
- **WHEN** tool_name 不在注册表中
- **THEN** 返回 400 错误，提示不支持的工具
