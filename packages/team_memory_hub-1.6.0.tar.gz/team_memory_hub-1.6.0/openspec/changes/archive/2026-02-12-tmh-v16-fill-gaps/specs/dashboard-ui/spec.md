## ADDED Requirements

### Requirement: Dashboard template system
系统 SHALL 使用 Jinja2 模板引擎 + HTMX 实现 Dashboard UI。所有页面继承 `base.html` 基础模板（导航栏、侧边栏、全局样式）。前端库通过 CDN 加载（HTMX、Chart.js），无需构建步骤。

#### Scenario: Page rendering
- **WHEN** 访问 `/dashboard/` 的任意页面
- **THEN** 返回完整的 HTML 页面，包含导航栏、侧边栏和内容区

#### Scenario: HTMX partial update
- **WHEN** 用户在页面内操作（如过滤、分页）
- **THEN** 通过 HTMX 仅刷新内容区域，不全页刷新

### Requirement: Overview page
Dashboard SHALL 提供首页概览（`/dashboard/`），展示：团队记忆总数、各 scope 分布、待处理合并建议数、最近 7 天活动统计图（Chart.js）、最新记忆列表。

#### Scenario: View overview stats
- **WHEN** 访问 /dashboard/
- **THEN** 显示记忆统计卡片（总数、team/private/project 分布）和活动趋势图

### Requirement: Memory management page
Dashboard SHALL 提供记忆管理页面（`/dashboard/memories`），支持：列表视图（摘要、scope、category、quality、时间）、过滤器（scope/category/quality/project）、排序（时间/评分）、详情查看（点击展开原文）、质量操作（verify/stale/pin/archive 按钮）。

#### Scenario: Filter and browse memories
- **WHEN** 在记忆页面选择 scope=team, category=decision
- **THEN** HTMX 更新列表，仅显示匹配的记忆

#### Scenario: Quality action from list
- **WHEN** maintainer 点击记忆旁的 "verify" 按钮
- **THEN** HTMX 发送 POST 请求，记忆标记为 verified，按钮状态更新

### Requirement: Consolidation review page
Dashboard SHALL 提供合并建议审核页面（`/dashboard/consolidation`），包含：建议列表（相似度、类别、记忆数）、详情对比视图（左侧原始 N 条、右侧合并预览）、操作按钮（接受/编辑后接受/拒绝/忽略）、统计面板（本月合并数、瘦身率）。

#### Scenario: Side-by-side comparison
- **WHEN** 打开合并建议详情
- **THEN** 左右对比显示原始记忆和合并预览

#### Scenario: Edit then accept
- **WHEN** 修改右侧合并预览内容后点击"接受"
- **THEN** 使用修改后内容执行合并，页面更新状态

### Requirement: Spec management page
Dashboard SHALL 提供规范管理页面（`/dashboard/specs`），显示：规范列表（名称、版本、最后更新）、提案列表（状态、作者、delta 预览）、提案审核操作。

#### Scenario: Review proposal
- **WHEN** maintainer 查看 pending_review 状态的提案
- **THEN** 显示提案标题、描述、delta 内容、approve/reject 按钮

### Requirement: Search debug page
Dashboard SHALL 提供搜索调试页面（`/dashboard/search`），输入查询后显示结果和评分明细（vec_score、bm25_score、fusion_score、final_score、各 boost 系数）。

#### Scenario: Debug search scoring
- **WHEN** 输入查询 "JWT refresh token" 并搜索
- **THEN** 每条结果展示完整 score_breakdown，帮助调优搜索参数

### Requirement: Dashboard authentication
Dashboard SHALL 要求登录才能访问。MUST 支持 JWT cookie 认证。不同角色看到不同功能（admin 看到全部，member 看不到合并建议管理）。

#### Scenario: Unauthenticated access
- **WHEN** 未登录用户访问 /dashboard/
- **THEN** 重定向到登录页面

#### Scenario: Role-based visibility
- **WHEN** member 角色用户登录 Dashboard
- **THEN** 看不到合并建议管理和审计日志菜单
