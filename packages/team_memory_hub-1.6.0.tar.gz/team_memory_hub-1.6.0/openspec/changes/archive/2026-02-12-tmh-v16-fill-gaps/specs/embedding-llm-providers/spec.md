## ADDED Requirements

### Requirement: Embedding provider base interface
系统 SHALL 定义 `EmbeddingProvider` 抽象基类，统一 384 维输出，提供 `embed(texts) -> list[list[float]]` 和 `embed_single(text) -> list[float]` 方法。所有 provider MUST 将原生维度截断或填充到 384 维。

#### Scenario: Dimension normalization
- **WHEN** provider 原生输出 768 维向量
- **THEN** 截断为前 384 维返回

#### Scenario: Low dimension padding
- **WHEN** provider 原生输出 128 维向量
- **THEN** 用 0.0 填充到 384 维返回

### Requirement: Gemini embedding provider
系统 SHALL 实现 `GeminiProvider`，使用 `google-generativeai` SDK 调用 Gemini embedding-001 模型，原生 768 维截断到 384 维。

#### Scenario: Gemini embed texts
- **WHEN** 调用 GeminiProvider.embed(["JWT 认证方案"])
- **THEN** 返回 384 维 float 向量列表

#### Scenario: Gemini API error
- **WHEN** Gemini API 返回错误（如 quota 超限）
- **THEN** 抛出 EmbeddingError 异常，包含错误详情

### Requirement: OpenAI embedding provider
系统 SHALL 实现 `OpenAIProvider`，使用 `openai` SDK 调用 text-embedding-3-small 模型，原生 1536 维截断到 384 维。

#### Scenario: OpenAI embed with dimension truncation
- **WHEN** 调用 OpenAIProvider.embed(["数据库设计"])
- **THEN** 请求 OpenAI API 并将 1536 维结果截断为 384 维返回

### Requirement: ONNX local embedding provider
系统 SHALL 实现 `ONNXLocalProvider`，使用 `onnxruntime` 加载 all-MiniLM-L6-v2 模型（~25MB 自动下载），原生 384 维，零 API 成本。

#### Scenario: Local ONNX embed
- **WHEN** 调用 ONNXLocalProvider.embed(["本地测试"])
- **THEN** 使用本地 ONNX 模型推理，返回 384 维向量，无网络请求

#### Scenario: Model auto download
- **WHEN** 首次使用 ONNX provider 且模型文件不存在
- **THEN** 自动下载模型文件到缓存目录

### Requirement: OpenAI-compatible embedding provider
系统 SHALL 实现 `OpenAICompatibleProvider`，通过 `/v1/embeddings` 端点兼容 Ollama、vLLM、TEI、LocalAI 等自托管服务。

#### Scenario: Ollama embedding
- **WHEN** 配置 base_url=http://localhost:11434，model=nomic-embed-text
- **THEN** 调用 Ollama 的 OpenAI-compatible API 获取 embedding 并归一化到 384 维

### Requirement: Embedding provider factory
系统 SHALL 提供工厂函数 `create_embedding_provider(config) -> EmbeddingProvider`，根据 `config.embedding.provider` 返回对应实现。

#### Scenario: Factory creates Gemini provider
- **WHEN** config.embedding.provider = "gemini"
- **THEN** 返回已配置的 GeminiProvider 实例

#### Scenario: Invalid provider
- **WHEN** config.embedding.provider = "unknown"
- **THEN** 抛出 ConfigError 异常

### Requirement: LLM provider base interface
系统 SHALL 定义 `LLMProvider` 抽象基类，提供 `generate(prompt) -> str` 方法，用于摘要生成、质量评分、标签提取、记忆提取、偏好识别、合并建议生成。

#### Scenario: Generate summary
- **WHEN** 调用 llm.generate(prompt="请为以下内容生成摘要...")
- **THEN** 返回 LLM 生成的文本

### Requirement: Claude LLM provider
系统 SHALL 实现 `ClaudeLLMProvider`，使用 `anthropic` SDK 调用 Claude API。

#### Scenario: Claude generate
- **WHEN** 调用 ClaudeLLMProvider.generate(prompt)
- **THEN** 调用 Claude API 返回生成结果

### Requirement: Gemini LLM provider
系统 SHALL 实现 `GeminiLLMProvider`，使用 `google-generativeai` SDK 调用 Gemini API。

#### Scenario: Gemini generate
- **WHEN** 调用 GeminiLLMProvider.generate(prompt)
- **THEN** 调用 Gemini API 返回生成结果

### Requirement: Rule engine fallback
系统 SHALL 实现 `RuleEngineLLMProvider` 作为无 API Key 时的降级方案，使用关键词提取+正则匹配+时间衰减评分替代 LLM 智能功能。

#### Scenario: Fallback when no LLM configured
- **WHEN** config.llm.provider = "none" 或未配置 API Key
- **THEN** 系统使用规则引擎降级：关键词提取替代摘要生成、基于时间衰减的评分替代智能评分

### Requirement: Embedding migration support
系统 SHALL 支持切换 Embedding Provider 后的增量向量迁移。维护 `embedding_provider` 和 `embedding_model` 字段，提供批量重新 embed 的 `migrate_embeddings` 任务。

#### Scenario: Provider switch migration
- **WHEN** 管理员将 embedding provider 从 gemini 切换为 openai
- **THEN** 后台任务批量取出未迁移的记忆，使用新 provider 重新 embed，更新 memory_embeddings 表
