## MODIFIED Requirements

### Requirement: Read-only MCP tools
系统 SHALL 实现 MCP Server 并根据 `mcp.tool_set` 配置控制暴露的工具集。默认 `tool_set = "read_only"` 暴露 2 个读取工具：`search_memory`（混合搜索返回摘要列表）和 `get_memory_detail`（获取记忆原文）。工具定义约 400 tokens。

#### Scenario: Search memory via MCP
- **WHEN** AI agent 调用 MCP `search_memory` 工具，提供 query、scope、category、limit 参数
- **THEN** 系统使用混合搜索引擎返回匹配的记忆摘要列表（不含原文）

#### Scenario: Get memory detail via MCP
- **WHEN** AI agent 调用 MCP `get_memory_detail` 工具，提供 memory_id
- **THEN** 系统从文件系统加载并返回记忆完整原文

### Requirement: Optional write tools
系统 SHALL 支持通过 `mcp.tool_set` 配置扩展 MCP 工具集。`tool_set = "read_write"` 新增 `store_memory`（约 600 tokens），`tool_set = "full_crud"` 新增 `store_memory` + `update_memory` + `delete_memory`（约 1000 tokens）。全部工具受 RBAC 权限控制。

#### Scenario: read_write tool set
- **WHEN** 配置 mcp.tool_set = "read_write"
- **THEN** MCP Server 暴露 search_memory + get_memory_detail + store_memory 共 3 个工具

#### Scenario: full_crud tool set
- **WHEN** 配置 mcp.tool_set = "full_crud"
- **THEN** MCP Server 暴露全部 5 个工具：search_memory、get_memory_detail、store_memory、update_memory、delete_memory

#### Scenario: read_only tool set (default)
- **WHEN** 使用默认配置或 mcp.tool_set = "read_only"
- **THEN** MCP Server 仅暴露 search_memory 和 get_memory_detail

#### Scenario: store_memory with RBAC
- **WHEN** member 角色通过 MCP 调用 store_memory
- **THEN** 正常创建记忆

#### Scenario: delete_memory requires admin
- **WHEN** member 角色通过 MCP 调用 delete_memory
- **THEN** 返回权限错误，仅 admin 角色可删除

#### Scenario: update_memory ownership check
- **WHEN** member 角色通过 MCP 调用 update_memory 更新他人的记忆
- **THEN** 返回权限错误（member 仅可更新自己的记忆，maintainer+ 可更新任意）

### Requirement: MCP authentication
系统 SHALL 通过 API Key 对 MCP 请求进行认证。API Key scope MUST 与 tool_set 匹配：`mcp_only` scope 可使用当前 tool_set 暴露的所有工具，`read_only` scope 仅可使用读取工具，`full_access` scope 可使用全部工具。

#### Scenario: Valid MCP key
- **WHEN** MCP 请求携带有效的 mcp_only scope API Key
- **THEN** 请求正常处理，可使用 tool_set 配置范围内的工具

#### Scenario: read_only key with full_crud server
- **WHEN** tool_set="full_crud" 但 API Key scope="read_only"
- **THEN** 仅允许使用 search_memory 和 get_memory_detail

#### Scenario: Invalid MCP key
- **WHEN** MCP 请求未携带有效 Key
- **THEN** 返回认证错误

### Requirement: MCP permission matrix
系统 SHALL 按以下权限矩阵控制 MCP 工具操作：search_memory（viewer+）、get_memory_detail（viewer+）、store_memory（member+）、update_memory（member 仅自己 / maintainer+ 任意）、delete_memory（admin）。

#### Scenario: Viewer searches memory
- **WHEN** viewer 角色调用 search_memory
- **THEN** 正常返回搜索结果

#### Scenario: Viewer attempts store
- **WHEN** viewer 角色调用 store_memory
- **THEN** 返回 403 权限不足
