## ADDED Requirements

### Requirement: Application entry point
系统 SHALL 提供 `main.py` 入口文件，通过 `uvicorn` 启动 FastAPI 应用。入口文件 MUST 导入并启动 `server.app` 中定义的 FastAPI 实例，支持 `--host`、`--port`、`--reload` 参数。

#### Scenario: Start server via uvicorn
- **WHEN** 执行 `python -m team_memory_hub` 或 `uvicorn team_memory_hub.server.app:app`
- **THEN** FastAPI 服务正常启动，监听配置端口，所有路由可访问

#### Scenario: Start with custom port
- **WHEN** 执行 `uvicorn team_memory_hub.server.app:app --port 9000`
- **THEN** 服务在 9000 端口启动

### Requirement: Dependency injection container
系统 SHALL 提供 `server/dependencies.py` 依赖注入模块，使用 FastAPI `Depends` 机制为路由提供核心服务实例。MUST 管理以下服务的生命周期：Database、MemoryStore、SearchEngine、ContextEngine、SpecManager、PreferenceEngine、MemoryConsolidator、ChatIngest、WriteQueue、Curation、RBAC、EmbeddingProvider、LLMProvider。

#### Scenario: Route accesses memory store
- **WHEN** API 路由函数声明 `memory_store: MemoryStore = Depends(get_memory_store)`
- **THEN** 收到已初始化的 MemoryStore 单例实例

#### Scenario: Service initialization on startup
- **WHEN** FastAPI 应用启动（lifespan context manager）
- **THEN** 所有核心服务按依赖顺序初始化：Database → EmbeddingProvider → WriteQueue → MemoryStore → SearchEngine → 其他服务

#### Scenario: Graceful shutdown
- **WHEN** 应用接收到 shutdown 信号
- **THEN** WriteQueue 完成剩余写入、Database 连接关闭、资源正确释放

### Requirement: Event bus
系统 SHALL 提供 `server/event_bus.py` 进程内事件总线，使用 asyncio 发布/订阅模式。支持事件类型：`context_updated`、`memory_created`、`quality_changed`、`preference_suggestion`、`proposal_status`、`migration_progress`、`merge_suggestion`、`memory_merged`。

#### Scenario: Publish and subscribe
- **WHEN** 核心服务发布事件 `memory_created`，且有 SSE 端点订阅该事件
- **THEN** SSE 端点接收到事件数据并推送给客户端

#### Scenario: Multiple subscribers
- **WHEN** 多个 SSE 客户端订阅事件
- **THEN** 所有订阅者均收到事件通知

#### Scenario: No subscriber
- **WHEN** 发布事件但无订阅者
- **THEN** 事件被丢弃，不报错

### Requirement: Database migration V1.6
系统 SHALL 提供 `storage/migrations/v001_initial.py` 完整的 V1.6 schema 初始化迁移，包含：20+ 张表（teams, users, api_keys, projects, project_members, memories, memory_versions, spec_proposals, spec_applicability, merge_suggestions, user_preferences, team_default_preferences, preference_suggestions, chat_sessions, audit_logs）、FTS5 虚拟表（memories_fts）、sqlite-vec 虚拟表（memory_embeddings）、FTS5 同步触发器（INSERT/DELETE/UPDATE）、15+ 索引。

#### Scenario: Fresh database initialization
- **WHEN** 服务首次启动且无数据库文件
- **THEN** 创建数据库文件，执行 v001 迁移，所有表、索引、触发器、虚拟表正确创建

#### Scenario: Idempotent migration
- **WHEN** v001 迁移已执行过，服务再次启动
- **THEN** 跳过已执行的迁移，不报错
