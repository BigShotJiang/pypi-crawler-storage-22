## ADDED Requirements

### Requirement: Test infrastructure
系统 SHALL 建立 pytest 测试基础设施：`conftest.py` 提供共享 fixtures（内存 SQLite 数据库、测试用 EmbeddingProvider、mock LLMProvider、已初始化的核心服务实例、httpx.AsyncClient）。

#### Scenario: Test isolation
- **WHEN** 运行任意测试
- **THEN** 使用独立的内存 SQLite 数据库（`:memory:`），测试间无状态泄漏

#### Scenario: Async test support
- **WHEN** 测试函数标记为 `@pytest.mark.asyncio`
- **THEN** pytest-asyncio 正确执行异步测试

### Requirement: Memory store tests
系统 SHALL 提供 `tests/test_memory_store.py`，覆盖记忆 CRUD：创建记忆（含文件写入+索引）、读取摘要和原文、更新记忆（版本记录）、软删除（quality→archived）、列表查询（scope/category 过滤）。

#### Scenario: Test create and read
- **WHEN** 通过 MemoryStore 创建一条记忆
- **THEN** 可以通过 ID 读取其摘要和原文，文件存在于正确路径

#### Scenario: Test version history
- **WHEN** 更新记忆内容两次
- **THEN** versions 列表包含 3 条记录（创建+2 次更新）

### Requirement: Search engine tests
系统 SHALL 提供 `tests/test_search_engine.py`，覆盖：向量搜索、BM25 搜索、混合搜索 Score Fusion、分数归一化、后处理加权（项目 boost、时间衰减、verified boost）。

#### Scenario: Test hybrid search ranking
- **WHEN** 搜索 "JWT token"，数据库中有精确匹配和语义相似的记忆
- **THEN** 融合分数排序正确，精确匹配排在前面

#### Scenario: Test score normalization
- **WHEN** 调用 _normalize_scores({a: 0.5, b: 0.8, c: 0.2})
- **THEN** 返回归一化结果 {a: 0.5, b: 1.0, c: 0.0}

### Requirement: API route tests
系统 SHALL 提供 `tests/test_api_*.py`，使用 httpx.AsyncClient 测试核心 API 端点：认证（登录/获取用户）、记忆 CRUD、搜索、聊天摄入、偏好、规范提案。

#### Scenario: Test memory API flow
- **WHEN** POST /api/memories → GET /api/memories/:id → PUT /api/memories/:id → DELETE /api/memories/:id
- **THEN** 每步返回正确状态码和数据，CRUD 流程完整

#### Scenario: Test RBAC enforcement
- **WHEN** viewer 角色尝试 POST /api/memories
- **THEN** 返回 403 Forbidden

### Requirement: MCP server tests
系统 SHALL 提供 `tests/test_mcp_server.py`，测试 MCP 工具注册、search_memory、get_memory_detail、store_memory、update_memory、delete_memory，以及 tool_set 配置控制。

#### Scenario: Test tool_set configuration
- **WHEN** tool_set="read_only"
- **THEN** 仅注册 search_memory 和 get_memory_detail 两个工具

#### Scenario: Test full_crud tools
- **WHEN** tool_set="full_crud"
- **THEN** 注册全部 5 个工具，CRUD 操作均正常

### Requirement: Core engine tests
系统 SHALL 提供核心引擎测试：context_engine（三层组装）、preference_engine（三级优先级）、memory_consolidator（聚类+合并）、curation（质量生命周期）。

#### Scenario: Test context assembly
- **WHEN** 调用 build_context(user_id, team_id, project_id)
- **THEN** 返回包含 Layer 0（specs）+ Layer 1（活跃记忆+偏好）的组装内容

#### Scenario: Test preference resolution
- **WHEN** 用户有项目级偏好 indent_size=2，团队默认 indent_size=4
- **THEN** resolve_preferences 返回 indent_size=2（项目级优先）
