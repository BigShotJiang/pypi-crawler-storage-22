## 1. 服务器基础设施

- [x] 1.1 实现 `storage/migrations/v001_initial.py` — 完整 V1.6 schema（20+ 表、FTS5 虚拟表、sqlite-vec 虚拟表、触发器、索引）  *(已有 v1.py + v1_5.py 覆盖全部 schema)*
- [x] 1.2 实现 `server/event_bus.py` — 基于 asyncio 的进程内发布/订阅事件总线，支持 8 种事件类型  *(已实现，85 行)*
- [x] 1.3 实现 `server/dependencies.py` — FastAPI 依赖注入工厂函数，管理所有核心服务实例的创建和生命周期  *(已实现，183 行)*
- [x] 1.4 重写 `main.py` 入口 — 替换 PyCharm 模板为 uvicorn 启动入口，支持命令行参数  *(已实现)*
- [x] 1.5 更新 `server/app.py` — 添加 V1.6 版本号、补全 curation 路由注册、增强健康检查  *(已实现)*

## 2. Embedding & LLM Providers

- [x] 2.1 实现 `providers/embedding/base.py` — EmbeddingProvider ABC + 工厂函数 create_embedding_provider  *(已实现，50 行)*
- [x] 2.2 实现 `providers/embedding/gemini.py` — Gemini embedding-001 provider（768→384 截断）  *(已实现，75 行)*
- [x] 2.3 实现 `providers/embedding/openai.py` — OpenAI text-embedding-3-small provider（1536→384 截断）  *(已实现，73 行)*
- [x] 2.4 实现 `providers/embedding/onnx.py` — ONNX 本地 all-MiniLM-L6-v2 provider（原生 384 维，自动下载模型）  *(已实现，99 行)*
- [x] 2.5 实现 `providers/embedding/openai_compatible.py` — 通用 OpenAI-compatible provider（Ollama/vLLM/TEI）  *(已实现，86 行)*
- [x] 2.6 实现 `providers/embedding/migrator.py` — Embedding provider 切换后的增量向量迁移任务  *(已实现，93 行)*
- [x] 2.7 实现 `providers/llm/base.py` — LLMProvider ABC + 工厂函数 create_llm_provider  *(已实现，21 行)*
- [x] 2.8 实现 `providers/llm/claude.py` — Claude LLM provider（anthropic SDK）  *(已实现，58 行)*
- [x] 2.9 实现 `providers/llm/gemini.py` — Gemini LLM provider（google-generativeai SDK）  *(已实现，54 行)*
- [x] 2.10 实现 `providers/llm/rules.py` — 规则引擎降级 provider（关键词提取 + 时间衰减评分）  *(已实现，50 行)*

## 3. API 路由层

- [x] 3.1 实现 `routes/auth.py` — JWT 认证（POST /api/auth/token, GET /api/auth/me）  *(已实现，202 行)*
- [x] 3.2 实现 `routes/keys.py` — API Key 管理（POST/GET/DELETE /api/keys）  *(已实现，103 行)*
- [x] 3.3 实现 `routes/memories.py` — 记忆 CRUD（POST/GET/PUT/DELETE /api/memories，含 detail 和 versions）  *(已实现，316 行)*
- [x] 3.4 实现 `routes/search.py` 或合并到 memories — 搜索端点（POST /api/memories/search）  *(已实现，99 行)*
- [x] 3.5 实现 `routes/chats.py` — 聊天摄入（POST /api/chats/ingest, GET /api/chats）  *(已实现，216 行)*
- [x] 3.6 实现 `routes/preferences.py` — 用户偏好（GET/PUT + resolved + suggestions + accept）  *(已实现，211 行)*
- [x] 3.7 实现 `routes/specs.py` — 规范管理（specs CRUD + proposals 生命周期）  *(已实现，193 行)*
- [x] 3.8 实现 `routes/consolidation.py` — 合并建议（suggestions CRUD + scan + stats）  *(已实现，112 行)*
- [x] 3.9 实现 `routes/context.py` — Context 预加载（GET /api/context/:user_id, POST refresh）  *(已实现，113 行)*
- [x] 3.10 实现 `routes/curation.py` — 策展操作（POST /api/memories/:id/{verify,stale,pin,archive}）  *(已实现，79 行)*
- [x] 3.11 实现 `routes/team.py` — 团队管理（CRUD members + team preferences）  *(已实现，97 行)*
- [x] 3.12 实现 `routes/projects.py` — 项目管理（CRUD projects）  *(已实现，129 行)*
- [x] 3.13 实现 `routes/events.py` — SSE 实时推送（GET /api/events/stream + heartbeat）  *(已实现，64 行)*
- [x] 3.14 实现 `routes/system.py` — 系统管理（GET /api/health 增强版 + GET/PUT /api/settings）  *(已实现，65 行)*
- [x] 3.15 实现 `routes/audit.py` — 审计日志（GET /api/audit/logs，支持过滤）  *(已实现，34 行)*

## 4. MCP Server（V1.6 全 CRUD）

- [x] 4.1 实现 `server/mcp_server.py` — FastMCP Server 框架，tool_set 配置（read_only/read_write/full_crud）动态工具注册  *(已实现)*
- [x] 4.2 实现 search_memory 工具 — 调用混合搜索引擎，返回摘要列表  *(已实现)*
- [x] 4.3 实现 get_memory_detail 工具 — 从文件系统加载记忆原文  *(已实现)*
- [x] 4.4 实现 store_memory 工具 — 创建记忆，需 member+ 角色  *(已实现)*
- [x] 4.5 实现 update_memory 工具 — 更新记忆，member 仅自己 / maintainer+ 任意  *(已实现)*
- [x] 4.6 实现 delete_memory 工具 — 软删除记忆（→archived），需 admin 角色  *(已实现)*
- [x] 4.7 实现 MCP 认证 — API Key scope 与 tool_set 权限交叉检查  *(已实现，通过 api_key_auth + RBAC 双层检查)*

## 5. Chat Adapter 完善

- [x] 5.1 完善 `chat_adapters/claude_code.py` — 解析 Claude Code JSON 会话数据（session_id、turns、tool_calls）  *(已实现，82 行)*
- [x] 5.2 完善 `chat_adapters/cursor.py` — 支持 .cursorrules 结构化输出和手动导出 JSON 两种格式  *(已实现，82 行)*
- [x] 5.3 完善 `chat_adapters/opencode.py` — 解析 OpenCode onSessionEnd JSON 数据  *(已实现，65 行)*
- [x] 5.4 完善 `chat_adapters/chatbox.py` — 解析 Chatbox MCP Resource / 导出 JSON  *(已实现，65 行)*
- [x] 5.5 完善 `chat_adapters/codex.py` — 解析 Codex CLI 管道文本流，识别对话边界  *(已实现，115 行)*
- [x] 5.6 实现适配器注册表 — 根据 tool_name 自动选择适配器，未知 tool 返回 400  *(已在 chat_adapters/__init__.py 实现)*

## 6. Dashboard UI

- [x] 6.1 完善 `dashboard/templates/base.html` — 基础模板（导航栏、侧边栏、CDN 引入 HTMX + Chart.js）  *(已完善，版本号 + Chart.js CDN)*
- [x] 6.2 实现 `dashboard/templates/index.html` — 首页概览（统计卡片、活动趋势图、最新记忆）  *(已完善，添加 Chart.js 趋势图)*
- [x] 6.3 完善 `dashboard/templates/memories.html` — 记忆管理（列表+过滤+排序+详情展开+质量操作按钮）  *(已完善，添加 verify/pin/stale/archive 按钮)*
- [x] 6.4 完善 `dashboard/templates/consolidation.html` — 合并建议审核（列表+对比视图+操作按钮+统计）  *(已完善，添加 accept/reject 按钮)*
- [x] 6.5 实现 `dashboard/templates/specs.html` — 规范管理（规范列表+提案列表+审核操作）  *(已实现)*
- [x] 6.6 实现 `dashboard/templates/search.html` — 搜索调试（查询输入+结果+score_breakdown 明细）  *(已实现)*
- [x] 6.7 实现 `dashboard/templates/login.html` — 登录页面  *(已实现)*
- [x] 6.8 实现 `dashboard/routes.py` — Dashboard 路由（认证中间件+页面渲染+HTMX 片段端点）  *(已完善，添加 login/logout + 趋势数据)*
- [x] 6.9 实现 `dashboard/static/` — 基础 CSS 样式  *(已实现 style.css)*

## 7. 测试套件

- [x] 7.1 创建 `tests/conftest.py` — 共享 fixtures（内存 SQLite、mock providers、httpx.AsyncClient、测试数据工厂）  *(已实现，147 行)*
- [x] 7.2 创建 `tests/test_memory_store.py` — 记忆 CRUD + 文件一致性 + 版本历史  *(test_memories.py，369 行)*
- [x] 7.3 创建 `tests/test_search_engine.py` — 向量搜索 + BM25 + 混合搜索 + 分数归一化 + 后处理加权  *(test_hybrid_search.py，330 行)*
- [x] 7.4 创建 `tests/test_api_auth.py` — 认证 API（登录、JWT 验证、无效凭证）  *(test_auth.py，238 行)*
- [x] 7.5 创建 `tests/test_api_memories.py` — 记忆 API 全流程（CRUD + 搜索 + RBAC）  *(test_memories.py 已覆盖)*
- [x] 7.6 创建 `tests/test_mcp_server.py` — MCP 工具注册 + tool_set 配置 + CRUD 操作 + 权限检查  *(test_mcp.py，已更新为 V1.6 全 CRUD)*
- [x] 7.7 创建 `tests/test_context_engine.py` — 三层 context 组装 + 缓存失效  *(test_context.py，284 行)*
- [x] 7.8 创建 `tests/test_preference_engine.py` — 三级优先级解析 + 偏好格式化  *(test_preferences.py，186 行)*

## 8. 集成与收尾

- [x] 8.1 更新 `pyproject.toml` — 添加缺失的依赖 + 版本号 1.6.0 + optional-dependencies 分组  *(已完成)*
- [x] 8.2 更新 `.env.example` — 补全 MCP tool_set 环境变量  *(已完成)*
- [x] 8.3 更新 `CLAUDE.md` — 同步项目结构、技术栈、MCP V1.6 变更  *(已完成)*
- [x] 8.4 端到端冒烟测试 — 256 个测试全部通过，84 个路由注册成功，核心功能验证完毕  *(已完成)*
