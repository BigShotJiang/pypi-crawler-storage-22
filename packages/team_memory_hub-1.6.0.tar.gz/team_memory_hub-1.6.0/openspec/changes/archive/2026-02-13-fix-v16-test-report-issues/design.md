## Context

V1.6 全功能测试报告（443 项测试中 441 通过）发现 3 个遗留问题需要修复：

1. **P0 — 缺少 Streamable HTTP `/mcp` 端点**：当前 MCP Server 仅注册了 `/api/v1/mcp/rpc`（JSON-RPC POST）、`/api/v1/mcp/sse`（SSE transport）、`/api/v1/mcp/messages`（SSE 消息接收）和 `/api/v1/mcp/tools`（REST 工具列表）。V1.6 架构文档要求支持 Streamable HTTP（`POST /mcp`），这是 Chatbox 等仅支持 HTTP transport 的客户端唯一的接入方式。
2. **P1 — CLI 路径前缀错误**：`cli/main.py` 中所有 API 调用使用 `/api/*` 路径，而服务器实际注册在 `/api/v1/*`，导致真实部署中全量 404。
3. **P2 — 健康检查版本号不一致**：`/api/v1/health` 返回 `1.6.0`，`/api/v1/system/health` 返回 `0.1.0`。

## Goals / Non-Goals

**Goals:**
- 实现 Streamable HTTP `POST /mcp` 端点，使 HTTP-only 客户端可正常使用 MCP 协议
- 修正 CLI 所有 API 路径为 `/api/v1/*` 前缀
- 统一所有健康检查端点的版本号为 `1.6.0`

**Non-Goals:**
- 不重构现有 MCP RPC/SSE 端点
- 不修改 CLI 功能逻辑，仅修正路径
- 不引入版本号配置化管理（未来可考虑从 pyproject.toml 读取）

## Decisions

### D1：Streamable HTTP 端点注册位置

**决策**：在 `mcp_server.py` 的 router 上新增 `POST /streamable` 路由，并在 `app.py` 中额外注册一个顶层 `POST /mcp` 路由转发到同一 handler。

**理由**：
- 架构文档要求 `POST /mcp` 作为顶层端点（非 `/api/v1/mcp/` 前缀下）
- Streamable HTTP 是独立于 SSE 和纯 RPC 的第三种 transport，处理逻辑与现有 `_process_rpc` 可复用
- 在 `app.py` 顶层注册 `/mcp` 保持了与架构文档一致的简洁路径

**替代方案（否决）**：
- 在 `/api/v1/mcp/` 前缀下注册 `/streamable`：路径为 `/api/v1/mcp/streamable`，与架构文档要求的 `/mcp` 不一致
- 重写整个 MCP 路由层：改动过大，风险不对称

### D2：Streamable HTTP 响应格式

**决策**：`POST /mcp` 接收 JSON-RPC 请求，返回 `Content-Type: application/json` 的 JSON-RPC 响应。对于支持流式的请求（如 `tools/call`），使用 `Content-Type: text/event-stream` 的 SSE 流式响应。

**理由**：
- MCP Streamable HTTP 规范要求单端点同时支持普通 JSON 响应和流式 SSE 响应
- 通过 `Accept` header 或请求方法判断是否需要流式响应
- 复用已有的 `_process_rpc` 函数处理核心逻辑

### D3：CLI 路径修正策略

**决策**：将 CLI 中硬编码的 API 路径统一添加 `/v1` 段，即 `/api/memories` → `/api/v1/memories`。同时提取路径前缀为常量 `API_PREFIX = "/api/v1"` 以避免未来重复问题。

**理由**：
- 改动最小、最直接
- 常量化可防止未来版本升级时再次出现不一致

**替代方案（否决）**：
- 使用配置化 API 版本：过度设计，当前仅有 v1

### D4：版本号统一策略

**决策**：直接将 `system.py:18` 的 `"0.1.0"` 改为 `"1.6.0"`。

**理由**：最简单直接的修复。未来可考虑从 `app.py` 中的版本常量读取。

## Risks / Trade-offs

- **[风险] Streamable HTTP 协议细节不完整** → 仅实现基本的 JSON-RPC over HTTP + 简单 SSE 流式，后续根据实际客户端需求增量完善
- **[风险] CLI 路径修改可能遗漏** → 通过 grep 全量扫描 `/api/` 确保无遗漏，specs 中列出所有需修改行
- **[风险] 版本号硬编码分散** → 当前 scope 内不解决，记录为技术债
