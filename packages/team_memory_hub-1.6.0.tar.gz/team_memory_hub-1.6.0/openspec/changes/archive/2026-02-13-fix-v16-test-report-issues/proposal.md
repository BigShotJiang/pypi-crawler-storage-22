## Why

V1.6 全功能测试报告（2026-02-13）发现 3 个未修复问题：P0 级 Streamable HTTP `/mcp` 端点缺失导致 Chatbox 等 HTTP-only 客户端无法接入；P1 级 CLI 路径系统性缺少 `/v1` 前缀导致真实部署 404；P2 级双健康检查端点版本号不一致影响运维可观测性。这些问题直接影响生产可用性，需在发布前修复。

## What Changes

- 新增 Streamable HTTP `/mcp` 端点，支持 `POST /mcp` 单端点 JSON-RPC + 流式响应（P0）
- 修复 CLI 所有 API 路径从 `/api/*` 改为 `/api/v1/*`，涵盖 memories、chats、preferences、consolidation 共 13+ 处（P1）
- 统一 `/api/v1/system/health` 版本号为 `1.6.0`，与 `/api/v1/health` 保持一致（P2）

## Capabilities

### New Capabilities

（无新增能力，均为已有能力的缺陷修复）

### Modified Capabilities

- `mcp-server`：新增 Streamable HTTP transport（`POST /mcp`），补齐 V1.6 架构文档要求的传输层
- `tmh-cli`：修正所有 API 端点路径前缀为 `/api/v1/*`
- `admin-system-config`：统一 `/api/v1/system/health` 返回的版本号为 `1.6.0`

## Impact

- **代码变更**：
  - `src/team_memory_hub/server/mcp_server.py`：新增 Streamable HTTP handler
  - `src/team_memory_hub/server/app.py`：注册 `/mcp` 路由
  - `cli/main.py`：修正 13+ 处 API 路径
  - `src/team_memory_hub/server/routes/system.py`：修正版本号
- **API 变更**：新增 `POST /mcp` 端点（非 breaking，纯增量）
- **测试影响**：需新增 `/mcp` 端点测试，CLI 路径测试应更新
