## MODIFIED Requirements

### Requirement: System configuration view
系统 SHALL 在管理后台提供系统配置查看界面，路径 `/dashboard/admin/system`。页面 SHALL 显示当前运行时配置参数，按分组组织（服务器、搜索、嵌入、MCP、安全等）。

#### Scenario: View system configuration
- **WHEN** admin 用户访问 `/dashboard/admin/system`
- **THEN** 显示当前系统配置参数，按分类分组（server、search、embedding、mcp、security）

#### Scenario: Non-admin cannot view system config
- **WHEN** maintainer 角色用户访问 `/dashboard/admin/system`
- **THEN** 系统返回 403 Forbidden 或重定向到无权限提示页

### Requirement: System health version consistency
`/api/v1/system/health` 端点 SHALL 返回与 `/api/v1/health` 一致的版本号 `1.6.0`。

#### Scenario: System health returns correct version
- **WHEN** 调用 `GET /api/v1/system/health`
- **THEN** 返回 JSON 包含 `"version": "1.6.0"`

#### Scenario: Both health endpoints return same version
- **WHEN** 分别调用 `GET /api/v1/health` 和 `GET /api/v1/system/health`
- **THEN** 两个响应中的 `version` 字段值相同，均为 `1.6.0`
