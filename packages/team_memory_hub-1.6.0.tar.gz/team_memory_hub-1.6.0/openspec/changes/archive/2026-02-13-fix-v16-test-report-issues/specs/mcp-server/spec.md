## ADDED Requirements

### Requirement: Streamable HTTP transport
系统 SHALL 提供 Streamable HTTP 端点 `POST /mcp`，接收 JSON-RPC 请求并返回响应。该端点 SHALL 支持所有已实现的 MCP 方法（`initialize`、`ping`、`tools/list`、`tools/call`）。认证方式与现有 MCP 端点一致（API Key，scope=mcp_only）。

#### Scenario: Initialize via Streamable HTTP
- **WHEN** 客户端发送 `POST /mcp`，Body 为 `{"jsonrpc":"2.0","id":1,"method":"initialize"}`，携带有效 mcp_only API Key
- **THEN** 系统返回 200，Content-Type 为 `application/json`，Body 包含 `protocolVersion`、`capabilities`、`serverInfo`

#### Scenario: Tool call via Streamable HTTP
- **WHEN** 客户端发送 `POST /mcp`，Body 为 `tools/call` 请求，调用 `search_memory` 工具
- **THEN** 系统返回 200，Body 包含搜索结果

#### Scenario: Unauthenticated Streamable HTTP request
- **WHEN** 客户端发送 `POST /mcp` 未携带 API Key
- **THEN** 系统返回 401 认证错误

#### Scenario: Invalid JSON-RPC method via Streamable HTTP
- **WHEN** 客户端发送 `POST /mcp` 携带未知方法名
- **THEN** 系统返回 JSON-RPC error（code: -32601, Method not found）
