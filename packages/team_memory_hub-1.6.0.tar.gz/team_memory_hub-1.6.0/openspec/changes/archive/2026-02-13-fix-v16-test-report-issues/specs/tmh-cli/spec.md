## MODIFIED Requirements

### Requirement: Memory commands
系统 SHALL 提供记忆相关 CLI 命令：`tmh store`（存储记忆）、`tmh search`（搜索记忆，默认混合搜索）、`tmh detail`（查看原文）。所有 API 调用 SHALL 使用 `/api/v1/` 版本化前缀。

#### Scenario: Store memory via CLI
- **WHEN** 执行 `tmh store "JWT 采用滑动窗口" --scope team --category decision`
- **THEN** 调用 `POST /api/v1/memories` 存储记忆并输出记忆 ID

#### Scenario: Search with engine option
- **WHEN** 执行 `tmh search "JWT token" --engine vector_only`
- **THEN** 调用 `GET /api/v1/memories` 使用指定引擎搜索并显示结果

#### Scenario: Get memory detail
- **WHEN** 执行 `tmh detail <memory_id>`
- **THEN** 调用 `GET /api/v1/memories/{memory_id}/detail` 并显示完整记忆内容

### Requirement: Chat ingest commands
系统 SHALL 提供 `tmh ingest` 命令，支持 `--file`（从文件导入）、`--stdin`（管道输入）、`--scan-cursor`（扫描 Cursor 聊天记录）。所有 API 调用 SHALL 使用 `/api/v1/` 版本化前缀。

#### Scenario: Ingest from file
- **WHEN** 执行 `tmh ingest --file chat.json --tool cursor`
- **THEN** 调用 `POST /api/v1/chats/ingest` 上传聊天记录并输出提取的记忆数量

#### Scenario: Ingest from stdin
- **WHEN** 执行 `codex ... | tmh ingest --stdin --tool codex`
- **THEN** 调用 `POST /api/v1/chats/ingest` 从标准输入读取并处理聊天记录

### Requirement: Consolidation commands
系统 SHALL 提供记忆整合 CLI 命令：`tmh consolidation list`、`tmh consolidation show`、`tmh consolidation accept`、`tmh consolidation reject`、`tmh consolidation scan`、`tmh consolidation stats`。所有 API 调用 SHALL 使用 `/api/v1/` 版本化前缀。

#### Scenario: List pending suggestions via CLI
- **WHEN** 执行 `tmh consolidation list`
- **THEN** 调用 `GET /api/v1/consolidation/suggestions` 显示所有 pending 状态的合并建议

#### Scenario: Manual scan trigger
- **WHEN** 执行 `tmh consolidation scan`
- **THEN** 调用 `POST /api/v1/consolidation/scan` 触发手动合并候选扫描

#### Scenario: Accept or reject suggestion
- **WHEN** 执行 `tmh consolidation accept --id <suggestion_id>`
- **THEN** 调用 `POST /api/v1/consolidation/suggestions/{id}/accept`

### Requirement: Preference commands use versioned API
系统 SHALL 使所有偏好相关 CLI 命令使用 `/api/v1/` 版本化前缀。涵盖 `tmh prefs list`、`set`、`get`、`team-list`、`team-set`、`suggestions` 子命令。

#### Scenario: List user preferences
- **WHEN** 执行 `tmh prefs list`
- **THEN** 调用 `GET /api/v1/preferences/user`

#### Scenario: Set user preference
- **WHEN** 执行 `tmh prefs set --key theme --value dark`
- **THEN** 调用 `POST /api/v1/preferences/user`

#### Scenario: Get effective preferences
- **WHEN** 执行 `tmh prefs get`
- **THEN** 调用 `GET /api/v1/preferences/effective`

#### Scenario: Team preference operations
- **WHEN** 执行 `tmh prefs team-list` 或 `tmh prefs team-set`
- **THEN** 分别调用 `GET /api/v1/preferences/team` 和 `POST /api/v1/preferences/team`

#### Scenario: Preference suggestions
- **WHEN** 执行 `tmh prefs suggestions`
- **THEN** 调用 `GET /api/v1/preferences/suggestions`
