## 1. P0 — Streamable HTTP `/mcp` 端点

- [x] 1.1 在 `src/team_memory_hub/server/mcp_server.py` 新增 Streamable HTTP handler 函数，复用 `_process_rpc` 处理 JSON-RPC 请求，返回 `application/json` 响应
- [x] 1.2 在 `src/team_memory_hub/server/app.py` 注册顶层 `POST /mcp` 路由，绑定到 Streamable HTTP handler
- [x] 1.3 新增 Streamable HTTP 端点测试：initialize、tools/call、未认证 401、未知方法 -32601

## 2. P1 — CLI API 路径修正

- [x] 2.1 在 `cli/main.py` 顶部定义常量 `API_PREFIX = "/api/v1"`
- [x] 2.2 修正 `cmd_store`：`/api/memories` → `f"{API_PREFIX}/memories"`
- [x] 2.3 修正 `cmd_search`：`/api/memories` → `f"{API_PREFIX}/memories"`
- [x] 2.4 修正 `cmd_detail`：`/api/memories/{id}/detail` → `f"{API_PREFIX}/memories/{id}/detail"`
- [x] 2.5 修正 `cmd_ingest`：`/api/chats/ingest` → `f"{API_PREFIX}/chats/ingest"`
- [x] 2.6 修正 `cmd_prefs` 所有 6 处路径：`/api/preferences/*` → `f"{API_PREFIX}/preferences/*"`
- [x] 2.7 修正 `cmd_consolidation` 所有 3 处路径：`/api/consolidation/*` → `f"{API_PREFIX}/consolidation/*"`
- [x] 2.8 全量 grep 确认 `cli/main.py` 中无残留的 `/api/` 硬编码路径（不含 `/api/v1`）

## 3. P2 — 健康检查版本号统一

- [x] 3.1 修改 `src/team_memory_hub/server/routes/system.py:18`，将 `"0.1.0"` 改为 `"1.6.0"`

## 4. 回归验证

- [x] 4.1 运行 `pytest tests/test_mcp.py` 确认 MCP 测试通过（含新 Streamable HTTP 测试）— 20 passed
- [x] 4.2 运行 `pytest tests/test_cli.py` 确认 CLI 测试通过 — 11 passed
- [x] 4.3 运行 `pytest -q` 全量回归确认无新增失败 — 332 passed
