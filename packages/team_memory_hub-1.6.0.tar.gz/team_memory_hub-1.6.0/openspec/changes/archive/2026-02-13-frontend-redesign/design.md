## Context

TMH Dashboard 当前采用 Pico CSS v2 + HTMX 1.9.12 + Chart.js v4 + Jinja2 模板引擎架构。共 15 个模板文件（5 个用户端 + 6 个管理后台 + 4 个 partial），2 个 CSS 文件（`style.css` <2KB、`admin.css` <1KB），JavaScript 全部以内联 `<script>` 形式嵌入模板。

现状问题：
- 无统一设计令牌，颜色/间距在各模板中硬编码
- 原生 `<dialog>` 在 iOS Safari 兼容性不足，无动画
- 加载反馈仅 `aria-busy` 文本，无视觉动画
- 管理后台 6 个导航项平铺，移动端换行
- 内联 JS 无法复用，批量操作和确认对话框在多个模板中重复

## Goals / Non-Goals

**Goals:**
- 建立 CSS 变量驱动的设计令牌系统，所有视觉属性从变量派生
- 实现浅色/深色主题无缝切换
- 将散落的内联 JS 提取为可复用的独立模块（`toast.js`、`modal.js`、`table.js`）
- 重构导航结构：顶栏 + 管理后台分组侧边栏 + 移动端抽屉式
- 统一所有页面的组件风格（徽章、卡片、表格、分页）
- 保持 WCAG 2.1 AA 级别色彩对比度

**Non-Goals:**
- 不迁移到 SPA 框架（React/Vue）
- 不引入前端构建工具（Webpack/Vite）
- 不修改后端 API 接口或业务逻辑
- 不实现 PWA / Service Worker
- 不实现国际化（i18n）
- 不引入 CSS 预处理器（Sass/Less），纯 CSS 变量方案

## Decisions

### D1: 保留 Pico CSS 作为基础，通过 CSS 变量层覆盖

**选择**: 在 Pico CSS 之上叠加自定义 CSS 变量层
**替代方案**:
- Tailwind CSS：功能强大但需要构建工具，违背无构建约束
- 完全自写 CSS：工作量大，Pico 已提供良好的基础重置和排版
- Bootstrap：过重，与 HTMX 哲学不匹配

**理由**: Pico CSS 提供语义化 HTML 默认样式，通过覆盖其 CSS 变量（`--pico-primary`、`--pico-border-radius` 等）可快速实现主题定制，同时保持零构建依赖。

### D2: CSS 文件模块化拆分

**选择**: 将样式拆分为以下结构：
```
static/
  css/
    tokens.css        # 设计令牌（变量定义）
    base.css           # 全局基础样式 + Pico 覆盖
    components.css     # 组件样式（modal、toast、table、pagination、badge）
    layout.css         # 布局与导航
    pages.css          # 页面特定样式
    admin.css          # 管理后台专用
```
**替代方案**: 单一 CSS 文件 → 文件过大难以维护
**理由**: 模块化便于按需维护，每个文件职责清晰。通过 `base.html` 中的 `<link>` 标签顺序加载（tokens → base → components → layout → pages），利用浏览器并行下载。

### D3: JS 提取为独立模块文件

**选择**: 提取为独立 JS 文件，通过原生 ES module 或 IIFE 组织：
```
static/
  js/
    theme.js           # 主题切换（localStorage 持久化）
    toast.js           # Toast 通知系统
    modal.js           # 模态框组件
    table.js           # 表格增强（全选、排序）
    shortcuts.js       # 键盘快捷键
```
**替代方案**: 继续内联 → 无法复用，代码重复
**理由**: 每个 JS 文件控制在 2-5KB，通过 `<script src>` 按需加载，不需要打包工具。

### D4: 自定义模态框替代原生 `<dialog>`

**选择**: 用 `<div class="modal-overlay">` + `<div class="modal">` 替代 `<dialog>`
**替代方案**: 保留 `<dialog>` + polyfill → 动画控制受限
**理由**: 自定义实现可完全控制进入/退出动画（CSS transition）、backdrop 模糊效果、嵌套模态框支持，且跨浏览器一致性好。通过 `modal.js` 统一管理焦点陷阱和 ESC 关闭。

### D5: Toast 通知系统

**选择**: 自建轻量 Toast 组件（纯 CSS + 50 行 JS）
**替代方案**:
- 第三方库（Toastify/Notyf）：增加外部依赖
- 继续用 `alert()`：阻塞主线程，用户体验差
**理由**: Toast 逻辑简单（创建 → 动画入场 → 自动消失），不需要引入外部依赖。支持 4 种类型（success/error/warning/info），位置固定右上角，自动堆叠。

### D6: 主题切换机制

**选择**: 通过 `<html data-theme="light|dark">` 属性 + CSS 变量实现
**替代方案**: `prefers-color-scheme` 媒体查询 → 无法手动切换
**理由**: data-theme 属性允许用户手动切换并通过 localStorage 持久化偏好，同时可以从 `prefers-color-scheme` 读取系统默认值作为初始值。Pico CSS 原生支持 `data-theme` 属性。

### D7: 管理后台导航分组

**选择**: 侧边栏分为两个 `<details>` 折叠组：
- **实体管理**: 团队、用户、项目、API Key
- **系统运维**: 记忆审核、系统配置
**替代方案**: 使用图标 Tab → 辨识度低
**理由**: `<details>` 元素原生支持折叠/展开，无需 JS。分组后每组最多 4 项，认知负担显著降低。

## Risks / Trade-offs

**[R1] CSS 文件数量增加导致 HTTP 请求增多** → 6 个 CSS 文件在 HTTP/2 下并行加载，总大小预计 <15KB（压缩后 <5KB），性能影响可忽略。若后期需优化，可手动合并为单文件。

**[R2] 深色模式下所有组件需双重验证** → 每个组件开发后需在两种主题下检查对比度。使用 CSS 变量确保一次定义两套色值，减少遗漏风险。

**[R3] 移除原生 `<dialog>` 后模态框可访问性退化** → 自定义模态框需手动实现焦点陷阱（Tab 循环）、`aria-modal="true"`、ESC 关闭、打开时 body 滚动锁定。在 `modal.js` 中统一处理。

**[R4] 内联 JS 提取可能破坏 HTMX 事件绑定** → 部分 `htmx:afterRequest` 监听器需要在 HTMX 加载后绑定。通过 `DOMContentLoaded` 事件确保加载顺序正确。

**[R5] Pico CSS 版本升级可能覆盖自定义变量** → 锁定 Pico CSS v2 CDN 版本号，自定义变量层的优先级高于 Pico 默认值（通过选择器权重保证）。
