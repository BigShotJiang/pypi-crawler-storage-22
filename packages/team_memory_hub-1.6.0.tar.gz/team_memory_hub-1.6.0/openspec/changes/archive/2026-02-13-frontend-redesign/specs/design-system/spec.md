## ADDED Requirements

### Requirement: Design tokens SHALL be defined as CSS custom properties
系统 SHALL 在 `tokens.css` 中定义全部设计令牌，包括颜色（primary、secondary、success、warning、error、neutral）、间距（xs/sm/md/lg/xl/2xl）、圆角（sm/md/lg/full）、阴影（sm/md/lg）、字体大小（xs/sm/base/lg/xl/2xl）和行高。所有组件和页面样式 SHALL 仅通过引用这些变量来获取视觉属性，禁止硬编码颜色值或间距数值。

#### Scenario: 令牌文件包含完整的颜色变量
- **WHEN** 加载 `tokens.css` 文件
- **THEN** 文件中 SHALL 定义 `--tmh-color-primary`、`--tmh-color-secondary`、`--tmh-color-success`、`--tmh-color-warning`、`--tmh-color-error`、`--tmh-color-neutral` 及其各级变体（50/100/200/.../900）

#### Scenario: 令牌文件包含间距变量
- **WHEN** 加载 `tokens.css` 文件
- **THEN** 文件中 SHALL 定义 `--tmh-space-xs`(4px)、`--tmh-space-sm`(8px)、`--tmh-space-md`(16px)、`--tmh-space-lg`(24px)、`--tmh-space-xl`(32px)、`--tmh-space-2xl`(48px)

#### Scenario: 组件样式仅通过变量引用
- **WHEN** 审查任意组件的 CSS 规则
- **THEN** 所有颜色值和间距值 SHALL 引用 `--tmh-*` 变量，不得使用硬编码的十六进制色值或像素数值

### Requirement: Light and dark themes SHALL be switchable via data-theme attribute
系统 SHALL 支持通过 `<html data-theme="light">` 和 `<html data-theme="dark">` 切换浅色和深色主题。两套主题 SHALL 在 `tokens.css` 中通过 `[data-theme="light"]` 和 `[data-theme="dark"]` 选择器分别定义语义颜色变量（如 `--tmh-bg-primary`、`--tmh-text-primary`、`--tmh-border-default`）。

#### Scenario: 切换到深色主题
- **WHEN** 用户点击主题切换按钮
- **THEN** `<html>` 元素的 `data-theme` 属性 SHALL 切换为 `"dark"`
- **THEN** 页面所有元素 SHALL 立即应用深色主题的颜色变量
- **THEN** 用户偏好 SHALL 持久化到 `localStorage`

#### Scenario: 首次访问读取系统偏好
- **WHEN** 用户首次访问 Dashboard 且 `localStorage` 中无主题偏好
- **THEN** 系统 SHALL 读取 `prefers-color-scheme` 媒体查询结果作为默认主题

#### Scenario: 再次访问恢复已保存主题
- **WHEN** 用户再次访问 Dashboard 且 `localStorage` 中存在 `tmh-theme` 值
- **THEN** 系统 SHALL 在页面渲染前应用已保存的主题，避免闪烁（FOUC）

### Requirement: Color contrast SHALL meet WCAG 2.1 AA standard
所有前景文本与背景色的组合 SHALL 满足 WCAG 2.1 AA 级别对比度要求：正常文本 ≥ 4.5:1，大文本 ≥ 3:1。

#### Scenario: 徽章文本对比度验证
- **WHEN** 渲染任意质量状态徽章（community/verified/pinned/stale/archived）
- **THEN** 徽章文本与背景色的对比度 SHALL ≥ 4.5:1（正常文本）

#### Scenario: 深色模式对比度验证
- **WHEN** 切换到深色主题
- **THEN** 所有 `--tmh-text-*` 变量与对应 `--tmh-bg-*` 变量的对比度 SHALL ≥ 4.5:1

### Requirement: Pico CSS variables SHALL be overridden through custom token layer
系统 SHALL 通过覆盖 Pico CSS 的内置变量（如 `--pico-primary`、`--pico-border-radius`、`--pico-spacing`）来实现主题定制，而非直接修改 Pico 源码或使用 `!important`。

#### Scenario: Pico 变量覆盖优先级
- **WHEN** `tokens.css` 在 Pico CSS 之后加载
- **THEN** `tokens.css` 中定义的 `--pico-primary` 等变量值 SHALL 覆盖 Pico 默认值
- **THEN** 覆盖 SHALL 通过 `:root` 选择器实现，不使用 `!important`
