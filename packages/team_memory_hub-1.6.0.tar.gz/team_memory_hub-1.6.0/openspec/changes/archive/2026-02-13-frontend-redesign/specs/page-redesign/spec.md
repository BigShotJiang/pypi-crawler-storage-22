## ADDED Requirements

### Requirement: Overview dashboard SHALL display enhanced KPI cards with sparklines
概览页面的 KPI 卡片 SHALL 重新设计为包含：数值、变化趋势箭头（较昨日 ↑/↓/→）、7 天迷你趋势图（sparkline）。卡片 SHALL 使用 `stat-grid` 自适应网格布局。

#### Scenario: KPI 卡片内容
- **WHEN** 用户访问概览页面
- **THEN** SHALL 显示 4 个 KPI 卡片：记忆总数、活跃用户数、团队数、项目数
- **THEN** 每个卡片 SHALL 包含：标题、当前数值、较昨日变化百分比（带方向箭头）、7 天 sparkline 图
- **THEN** 增长 SHALL 显示绿色 ↑，下降 SHALL 显示红色 ↓，持平 SHALL 显示灰色 →

#### Scenario: Sparkline 渲染
- **WHEN** 加载 KPI 卡片数据
- **THEN** sparkline SHALL 使用 Chart.js 以 `type: 'line'` 渲染，高度 40px，无坐标轴、无图例、无网格线
- **THEN** 填充色 SHALL 使用半透明 primary 色

### Requirement: Quality distribution SHALL use doughnut chart alongside trend chart
概览页面 SHALL 将质量分布从表格改为环形图（doughnut chart），与 14 天趋势折线图并排展示在双列布局中。

#### Scenario: 图表区域布局
- **WHEN** 用户访问概览页面
- **THEN** KPI 卡片下方 SHALL 显示双列布局：左侧环形图（质量分布）、右侧折线图（14 天趋势）
- **WHEN** 视口宽度 ≤768px
- **THEN** 双列 SHALL 改为单列堆叠

#### Scenario: 环形图交互
- **WHEN** 用户悬停在环形图的某个扇区上
- **THEN** SHALL 显示 tooltip，包含质量状态名称和具体数量/百分比

### Requirement: Overview SHALL include quick action shortcuts
概览页面 SHALL 在图表区域下方提供"快速操作"区域，包含常用操作的快捷入口按钮。

#### Scenario: 快速操作按钮渲染
- **WHEN** 用户访问概览页面
- **THEN** SHALL 显示以下快捷按钮：新建记忆、搜索记忆、查看待审核、查看合并建议
- **THEN** 每个按钮 SHALL 包含图标和文字标签
- **WHEN** 用户无对应权限时
- **THEN** 该快捷按钮 SHALL 不显示

### Requirement: Memory browser SHALL have improved filter and action experience
记忆浏览器 SHALL 使用顶部工具栏样式的过滤器（水平排列的下拉菜单），表格使用升级后的数据表格组件（含水平滚动、全选、骨架屏加载）。

#### Scenario: 过滤工具栏
- **WHEN** 用户访问记忆浏览器页面
- **THEN** 页面顶部 SHALL 显示水平排列的过滤器：范围下拉菜单、类别下拉菜单、质量状态下拉菜单
- **THEN** 过滤器变更 SHALL 通过 HTMX 动态更新表格内容，不刷新整页

#### Scenario: 记忆操作按钮
- **WHEN** 用户在记忆表格中操作某条记忆
- **THEN** 操作结果 SHALL 通过 Toast 通知反馈（替代 alert）
- **THEN** 删除操作 SHALL 通过模态框确认（替代 hx-confirm）

### Requirement: Search debug page SHALL link results to memory details
搜索调试页面的搜索结果 SHALL 包含到记忆详情/编辑页面的跳转链接，并可视化显示搜索评分。

#### Scenario: 搜索结果链接
- **WHEN** 搜索返回结果列表
- **THEN** 每条结果的标题 SHALL 是可点击的链接，跳转到对应记忆的浏览页面
- **THEN** 每条结果 SHALL 显示评分条（progress bar 样式），直观展示相关性分数

#### Scenario: 评分可视化
- **WHEN** 搜索结果包含 BM25 和向量搜索的混合评分
- **THEN** 每条结果 SHALL 显示一个颜色进度条表示综合评分（0-1 范围映射到 0%-100% 宽度）
- **THEN** 进度条颜色 SHALL 根据分数区间变化（高分绿色、中分橙色、低分灰色）

### Requirement: Consolidation page SHALL use card-based layout
合并建议页面 SHALL 从当前的列表式改为卡片式布局，每条建议一个卡片，包含相似度/置信度可视化和操作按钮。

#### Scenario: 建议卡片渲染
- **WHEN** 用户访问合并建议页面
- **THEN** 每条建议 SHALL 渲染为卡片，包含：建议标题、涉及的记忆摘要、相似度百分比、置信度指示器、接受/拒绝按钮
- **THEN** 卡片 SHALL 使用 grid 布局自适应排列

#### Scenario: 操作反馈
- **WHEN** 用户点击"接受"或"拒绝"按钮
- **THEN** 操作结果 SHALL 通过 Toast 通知反馈
- **THEN** 被处理的卡片 SHALL 以 fade-out 动画消失

### Requirement: Admin pages SHALL use consistent entity management pattern
管理后台的实体管理页面（团队、用户、项目、API Key）SHALL 使用统一的布局模式：顶部工具栏（过滤器 + 新建按钮）+ 数据表格 + 模态框表单。

#### Scenario: 统一工具栏
- **WHEN** 用户访问任意实体管理页面
- **THEN** 页面顶部 SHALL 显示统一样式的工具栏：左侧过滤下拉菜单、右侧新建按钮
- **THEN** 工具栏 SHALL 使用 `display: flex; justify-content: space-between` 布局

#### Scenario: 实体表单模态框
- **WHEN** 用户点击"新建"按钮或编辑操作
- **THEN** SHALL 在新模态框组件中打开表单（替代原生 dialog）
- **THEN** 表单提交成功后 SHALL 自动关闭模态框并刷新表格

### Requirement: Login page SHALL have centered card design with branding
登录页面 SHALL 使用垂直水平居中的卡片设计，包含品牌标识、标题、登录表单和主题切换按钮。

#### Scenario: 登录页面布局
- **WHEN** 用户访问登录页面
- **THEN** 页面 SHALL 显示居中的登录卡片，最大宽度 400px
- **THEN** 卡片顶部 SHALL 显示 TMH 品牌标识和"Team Memory Hub"标题
- **THEN** 卡片底部 SHALL 有主题切换按钮（允许在登录前切换主题）
- **THEN** 页面背景 SHALL 使用渐变色或微妙的图案

#### Scenario: 登录错误反馈
- **WHEN** 用户提交无效的登录信息
- **THEN** 错误信息 SHALL 在表单上方以红色提示条显示
- **THEN** 输入框 SHALL 添加红色边框和 shake 动画
