## 1. 设计令牌与主题基础

- [x] 1.1 创建 `static/css/tokens.css`，定义完整的设计令牌变量（颜色、间距、圆角、阴影、排版），包含 `[data-theme="light"]` 和 `[data-theme="dark"]` 两套语义色值
- [x] 1.2 创建 `static/css/base.css`，覆盖 Pico CSS 变量（`--pico-primary` 等），设置全局基础样式
- [x] 1.3 创建 `static/js/theme.js`，实现主题切换逻辑（`data-theme` 属性切换、`localStorage` 持久化、首次访问读取 `prefers-color-scheme`、页面加载前应用避免 FOUC）
- [x] 1.4 更新 `base.html` 的 `<head>`，按顺序引入 Pico CSS → tokens.css → base.css，添加主题初始化内联脚本

## 2. 布局与导航重构

- [x] 2.1 创建 `static/css/layout.css`，定义全局布局网格（响应式断点：1200px/768px）、管理后台侧边栏 + 主内容双列布局
- [x] 2.2 重构 `base.html` 顶部导航栏：添加面包屑区域、全局搜索输入框、主题切换按钮、用户头像下拉菜单
- [x] 2.3 重构 `base.html` 用户端 Tab 导航栏：水平 Tab 样式，当前页面底部高亮，管理后台入口条件渲染
- [x] 2.4 重构 `admin/_layout.html` 侧边栏：使用 `<details>` 元素将 6 项分为"实体管理"和"系统运维"两组，添加折叠动画
- [x] 2.5 实现移动端抽屉导航：创建 drawer HTML 结构、CSS 动画（slide-in 200ms）、hamburger 按钮切换逻辑
- [x] 2.6 实现面包屑 Jinja2 宏：根据当前路由自动生成面包屑层级

## 3. UI 组件库

- [x] 3.1 创建 `static/css/components.css`，定义模态框、Toast、分页器、数据表格、徽章、骨架屏的样式
- [x] 3.2 创建 `static/js/modal.js`，实现模态框组件（open/close 方法、焦点陷阱、ESC 关闭、body 滚动锁定、进入/退出动画、HTMX afterRequest 集成）
- [x] 3.3 创建 `static/js/toast.js`，实现 Toast 通知系统（4 种类型、slide-in 动画、自动消失 3s、error 类型不自动消失、堆叠管理、手动关闭）
- [x] 3.4 重构分页 partial：创建 `partials/pagination.html` Jinja2 宏，支持页码列表（省略号逻辑）、跳页输入框、每页条数选择器
- [x] 3.5 重构表格组件：更新 `partials/memory_table.html`，添加水平滚动容器（含渐变阴影提示）、表头全选复选框、已选计数显示
- [x] 3.6 创建 `static/js/table.js`，实现表格增强（全选/反选、Ctrl+A 快捷键、选中计数更新）
- [x] 3.7 创建骨架屏 partial：`partials/skeleton_table.html` 和 `partials/skeleton_card.html`，实现 shimmer 动画
- [x] 3.8 统一徽章组件样式：更新所有模板中的 badge class，使用设计令牌语义颜色变量，统一 pill 形状和尺寸

## 4. 页面重构 — 登录与概览

- [x] 4.1 重构 `login.html`：居中卡片设计（max-width 400px）、品牌标识、渐变背景、主题切换按钮、错误信息提示条 + shake 动画
- [x] 4.2 重构 `index.html` KPI 卡片区域：重新设计卡片布局，添加趋势箭头（↑/↓/→）和颜色编码，集成 sparkline 迷你图
- [x] 4.3 重构 `index.html` 图表区域：将质量分布改为 doughnut chart（含 hover tooltip），与趋势折线图并排双列布局（移动端堆叠）
- [x] 4.4 添加"快速操作"区域：新建记忆、搜索记忆、查看待审核、查看合并建议的快捷按钮，条件渲染权限控制

## 5. 页面重构 — 记忆与搜索

- [x] 5.1 重构 `memories.html`：将过滤器改为水平工具栏样式，集成新表格组件和骨架屏加载
- [x] 5.2 更新记忆操作反馈：将所有 `alert()` 和 `hx-confirm` 替换为 Toast 通知和模态框确认
- [x] 5.3 重构 `search.html`：搜索结果标题添加跳转链接、评分进度条可视化（颜色编码：高分绿/中分橙/低分灰）
- [x] 5.4 重构 `consolidation.html`：改为卡片式布局（含相似度/置信度可视化），操作按钮使用 Toast 反馈，处理后卡片 fade-out 动画

## 6. 页面重构 — 管理后台

- [x] 6.1 统一管理后台工具栏：更新 `admin/teams.html`、`admin/users.html`、`admin/projects.html`、`admin/api_keys.html`，使用一致的 flex 工具栏（过滤器左 + 新建按钮右）
- [x] 6.2 替换管理后台模态框：将所有 `<dialog>` 用法替换为新模态框组件，更新 `admin/partials/entity_form.html` 和 `admin/partials/confirm_dialog.html`
- [x] 6.3 重构 `admin/curation.html`：集成新表格组件的全选功能，批量操作反馈改用 Toast，添加骨架屏加载
- [x] 6.4 重构 `admin/system.html`：统计卡片使用设计令牌样式，配置表格使用新表格组件

## 7. 样式收尾与清理

- [x] 7.1 创建 `static/css/pages.css`，将页面特定样式从各模板内联 `<style>` 中提取到此文件
- [x] 7.2 删除旧文件 `static/style.css` 和 `static/admin.css`（功能已迁移到新模块化 CSS）
- [x] 7.3 检查所有模板中的硬编码颜色值和间距，替换为设计令牌变量引用
- [x] 7.4 深色模式全面验证：在 dark 主题下逐页检查所有组件的对比度和视觉效果
- [x] 7.5 移动端全面验证：在 ≤768px 视口下逐页检查布局、导航、表格滚动、模态框表现
