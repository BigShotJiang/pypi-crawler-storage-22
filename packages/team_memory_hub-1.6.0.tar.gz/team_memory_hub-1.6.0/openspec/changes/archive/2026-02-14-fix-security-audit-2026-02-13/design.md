## Context

2026-02-13 代码审查发现 7 个安全缺陷（5 高危 + 2 中危），主要集中在认证授权边界和配置逻辑。当前代码的认证层（`dependencies.py`）、记忆路由（`memories.py`）、管理路由（`admin.py`）和审计中间件（`app.py`）存在多处安全漏洞。

关键约束：
- 修改必须向后兼容现有 JWT 认证流程
- 注册接口的 `role` 字段变更是唯一的 BREAKING change
- 所有修复必须有对应的回归测试

## Goals / Non-Goals

**Goals:**
- 修复全部 7 个已确认安全缺陷
- 为每个修复增加回归测试覆盖
- 保持现有 API 契约（除注册接口外）

**Non-Goals:**
- 不重构整个认证架构（如切换到 OAuth2）
- 不增加新的 API 端点
- 不修改数据库 schema

## Decisions

### D1: 注册接口角色限制策略
**选择**: 在 `register` 路由中忽略用户提交的 `role`，强制设为 `member`。
**备选方案**: 从 `UserCreate` 模型中移除 `role` 字段 — 被拒绝，因为 `UserCreate` 也被管理后台创建用户接口复用。
**理由**: 最小改动，仅在公开注册路由层面强制覆盖，不影响管理端用户创建。

### D2: 私有记忆隔离修复方式
**选择**: 将 `memories.py:98` 的 `include_private=True` 改为 `include_private=False`。
**理由**: `MemoryStore.list_memories` 已实现正确的私有隔离逻辑（`include_private=False` 时增加 `scope != 'private' OR owner_id = ?`），路由层只需传正确参数。

### D3: API Key scope 强制策略
**选择**: 方案 B — 在 `get_current_user` 中注入 scope 信息到 `request.state`，并提供 `require_scope` 依赖工厂供路由使用；同时在 `get_current_user` 中对 `read_only` 和 `mcp_only` scope 的 key，阻止写操作路由。
**备选方案**: 方案 A（API Key 仅限 `api_key_auth` 路由）— 被拒绝，改动面过大，影响 MCP Server 等集成。
**理由**: 渐进式增强，在统一依赖中处理 scope 检查，不要求每个路由单独处理。

### D4: 质量接口资源级校验方式
**选择**: 在每个质量接口（`/verify`, `/stale`, `/pin`, `/archive`）中先调用 `store.get(memory_id)` 获取记忆，然后检查 `memory.team_id == current_user.team_id`。对 `/stale` 和 `/archive` 额外要求 `MAINTAINER` 角色或资源所有者。
**理由**: 复用现有的 `can_access_memory` / `can_modify_memory` 检查，保持一致。

### D5: 管理端审核 team 过滤方式
**选择**: 在 `list_curation_memories` 和 `batch_curation` 中强制加入 `team_id = current_user.team_id` 条件。批量操作前先验证所有 `memory_ids` 归属当前用户团队。
**理由**: 多租户数据隔离的基本要求，无需超级管理员豁免（当前无此角色设计）。

### D6: 布尔值转换修复
**选择**: 用显式映射替换 `bool(value)`：`{"true","1","yes"}` → `True`，`{"false","0","no"}` → `False`，其余值报错。
**理由**: 标准做法，避免 Python `bool()` 的字符串陷阱。

### D7: 审计日志 user_id 注入方式
**选择**: 在 `get_current_user` 依赖中成功认证后，写入 `request.state.user_id = user.id`。审计中间件已能正确读取此值。
**理由**: 最小改动，利用 FastAPI 的 request state 机制。

## Risks / Trade-offs

- [注册 BREAKING] 现有使用 `role` 字段的客户端注册调用会静默忽略角色 → **可接受**，安全优先
- [API Key scope] `get_current_user` 增加 scope 检查会使所有 API Key 立即受限 → **需要**在迁移时检查现有 Key 的 scope 分布
- [审核 team 过滤] 如果存在需要跨团队审核的超级管理员场景，此修复会阻断 → **当前设计无此需求**，后续可通过 permission_override 扩展
