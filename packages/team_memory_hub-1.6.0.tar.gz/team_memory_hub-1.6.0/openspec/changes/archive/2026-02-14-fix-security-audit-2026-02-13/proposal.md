## Why

2026-02-13 代码逻辑审查发现 7 个安全缺陷（5 个高危、2 个中危），涉及鉴权授权边界越权、数据泄露、权限绕过、配置错误和审计日志缺失。这些问题直接威胁多租户数据隔离和系统安全性，必须立即修复。

## What Changes

- **BREAKING** 公开注册接口强制 `role=member`，移除用户可控的角色字段
- 修复记忆列表接口私有数据隔离（`include_private=True` → `include_private=False`）
- 为质量生命周期接口（`/verify`、`/stale`、`/pin`、`/archive`）增加资源级 team + owner 权限校验
- 在 `get_current_user` 统一层面强制 API Key scope 检查，或将 API Key 认证限制为专用依赖
- 管理端审核接口增加 `team_id` 过滤，防止跨租户数据读写
- 修复系统配置布尔值转换逻辑（`bool("false")` 错误）
- 在认证依赖中写入 `request.state.user_id`，修复审计日志主体缺失

## Capabilities

### New Capabilities

（无新增能力）

### Modified Capabilities

- `auth-and-rbac`: 注册接口角色限制；`get_current_user` 增加 API Key scope 强制检查；认证依赖写入 `request.state.user_id`
- `memory-management`: 记忆列表私有隔离修复；质量生命周期接口增加资源级权限校验
- `admin-entity-management`: 审核列表和批量操作增加 `team_id` 过滤
- `admin-system-config`: 布尔值转换逻辑修复

## Impact

- **受影响文件**：
  - `src/team_memory_hub/server/routes/auth.py` — 注册接口
  - `src/team_memory_hub/server/routes/memories.py` — 列表 + 质量生命周期
  - `src/team_memory_hub/server/dependencies.py` — API Key scope 强制 + user_id 注入
  - `src/team_memory_hub/server/routes/admin.py` — 审核 team 过滤 + 布尔转换
  - `src/team_memory_hub/server/app.py` — 审计中间件（依赖 user_id 注入）
- **API 变更**：注册接口不再接受 `role` 参数（**BREAKING**）
- **测试**：需补充 7 个安全场景的回归测试
