## MODIFIED Requirements

### Requirement: Memory curation management interface
系统 SHALL 在管理后台提供记忆审核管理界面，路径 `/dashboard/admin/curation`。页面包含：待审核记忆列表（按质量状态过滤）、批量操作（验证、置顶、归档、标记过时）、记忆详情查看。

审核列表接口（`GET /api/admin/curation/memories`）SHALL 强制按 `team_id = current_user.team_id` 过滤，确保仅返回当前用户所属团队的记忆。

批量审核接口（`POST /api/admin/curation/batch`）SHALL 在执行更新前验证所有 `memory_ids` 的 `team_id` 与当前用户的 `team_id` 匹配。任何不匹配的 memory_id SHALL 被拒绝，整个批量操作不执行。

#### Scenario: List memories pending review
- **WHEN** maintainer 用户访问 `/dashboard/admin/curation`
- **THEN** 默认显示 quality=community 的记忆列表，仅包含当前用户团队的记忆

#### Scenario: Cross-team memories not visible in curation
- **WHEN** maintainer 用户调用 `GET /api/admin/curation/memories`
- **THEN** 结果仅包含 `team_id` 等于当前用户 `team_id` 的记忆

#### Scenario: Batch verify memories
- **WHEN** maintainer 用户勾选多条记忆并点击"批量验证"
- **THEN** 系统将选中记忆的 quality 更新为 verified，记录 verified_by 和 verified_at

#### Scenario: Batch curation rejects cross-team memory_ids
- **WHEN** 用户调用 `POST /api/admin/curation/batch`，memory_ids 中包含其他团队的记忆 ID
- **THEN** 系统返回 403 Forbidden，整个批量操作不执行

#### Scenario: Batch archive stale memories
- **WHEN** maintainer 用户勾选多条过时记忆并点击"批量归档"
- **THEN** 系统将选中记忆的 quality 更新为 archived

#### Scenario: View memory detail in curation
- **WHEN** 用户点击记忆行展开详情
- **THEN** 显示记忆原文内容、元数据（标签、分类、来源聊天）和版本历史
