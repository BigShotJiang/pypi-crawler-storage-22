## MODIFIED Requirements

### Requirement: Runtime configuration editing
系统 SHALL 支持在线修改部分运行时配置参数。可修改参数 SHALL 限定为安全参数（如搜索结果数量、缓存 TTL、分页默认值等），核心参数（如数据库路径、密钥、端口）SHALL 保持只读。

布尔类型参数的转换 SHALL 使用严格解析：仅接受 `{"true", "1", "yes"}` 转为 `True`，`{"false", "0", "no"}` 转为 `False`（均忽略大小写）。其他字符串值 SHALL 返回验证错误。

#### Scenario: Edit safe configuration parameter
- **WHEN** admin 用户修改 search.default_limit 的值并保存
- **THEN** 系统更新运行时配置，后续请求使用新值

#### Scenario: Cannot edit read-only parameter
- **WHEN** admin 用户尝试修改 server.host 等核心参数
- **THEN** 该参数 SHALL 显示为只读状态，不提供编辑功能

#### Scenario: Invalid configuration value
- **WHEN** admin 用户输入非法值（如负数的 limit）
- **THEN** 系统返回验证错误提示，不应用变更

#### Scenario: Boolean string "false" correctly parsed
- **WHEN** admin 用户将布尔配置项设为字符串 `"false"`
- **THEN** 系统将其转换为 `False`（而非 `True`）

#### Scenario: Invalid boolean string rejected
- **WHEN** admin 用户将布尔配置项设为字符串 `"maybe"`
- **THEN** 系统返回验证错误"无效的布尔值"
