## 1. 注册接口角色限制（高危 #1）

- [x] 1.1 修改 `src/team_memory_hub/server/routes/auth.py` 的 `register` 函数：在写入数据库前强制 `role = UserRole.MEMBER`，忽略 `data.role`
- [x] 1.2 添加测试：验证注册接口提交 `role=admin` 后，实际创建的用户角色为 `member`

## 2. 记忆列表私有数据隔离（高危 #2）

- [x] 2.1 修改 `src/team_memory_hub/server/routes/memories.py` 的 `list_memories` 路由：将 `include_private=True` 改为 `include_private=False`
- [x] 2.2 添加测试：验证用户 A 调用列表接口时不可见用户 B 的私有记忆

## 3. 质量生命周期接口资源级权限（高危 #3）

- [x] 3.1 修改 `memories.py` 的 `/verify` 接口：先 `store.get(memory_id)` 并检查 `team_id` 匹配
- [x] 3.2 修改 `memories.py` 的 `/stale` 接口：增加 team_id 检查，要求 MAINTAINER 或 owner
- [x] 3.3 修改 `memories.py` 的 `/pin` 接口：增加 team_id 检查
- [x] 3.4 修改 `memories.py` 的 `/archive` 接口：增加 team_id 检查，要求 MAINTAINER 或 owner
- [x] 3.5 添加测试：跨团队用户无法修改记忆质量状态；普通 member 非 owner 无法调用 `/stale` 和 `/archive`

## 4. API Key scope 强制（高危 #4）

- [x] 4.1 修改 `src/team_memory_hub/server/dependencies.py` 的 `get_current_user`：认证成功后写入 `request.state.user_id` 和 `request.state.api_key_scope`
- [x] 4.2 在 `get_current_user` 中增加 scope 检查：`read_only` key 拒绝写操作方法（POST/PUT/DELETE/PATCH）
- [x] 4.3 添加测试：`read_only` scope 的 API Key 调用写接口返回 403；`full_access` Key 正常通过

## 5. 管理端审核跨租户过滤（高危 #5）

- [x] 5.1 修改 `src/team_memory_hub/server/routes/admin.py` 的 `list_curation_memories`：增加 `m.team_id = ?` 条件
- [x] 5.2 修改 `admin.py` 的 `batch_curation`：在更新前查询所有 memory_ids 的 team_id，校验全部属于当前用户团队
- [x] 5.3 添加测试：审核列表仅返回本团队记忆；批量操作包含其他团队 ID 时返回 403

## 6. 布尔值转换修复（中危 #6）

- [x] 6.1 修改 `admin.py` 的 `update_system_config`：用严格布尔解析替换 `bool(value)`
- [x] 6.2 添加测试：字符串 `"false"` 正确转换为 `False`；无效布尔字符串 `"maybe"` 返回错误

## 7. 审计日志 user_id 注入（中危 #7）

- [x] 7.1 依赖任务 4.1 中的 `request.state.user_id` 注入（已在任务 4.1 中完成）
- [x] 7.2 添加测试：验证已认证用户的写操作审计日志中 user_id 不为 "anonymous"
