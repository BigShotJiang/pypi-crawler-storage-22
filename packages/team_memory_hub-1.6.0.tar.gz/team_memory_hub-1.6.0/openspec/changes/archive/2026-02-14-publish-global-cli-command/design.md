## Context

TMH CLI 目前位于 `cli/main.py`，是项目顶层的一个独立脚本，不在 `src/team_memory_hub/` 包内。因此：
- 通过 `pip install .` 安装时，CLI 代码不会被打包进 wheel
- 用户无法通过 `tmh` 命令全局调用 CLI
- `pyproject.toml` 缺少 `[project.scripts]` 入口点定义

现有 `src/team_memory_hub/__main__.py` 仅用于 `python -m team_memory_hub` 启动服务器，与 CLI 无关。

## Goals / Non-Goals

**Goals:**
- `pip install .` 后 `tmh` 命令全局可用
- CLI 代码随包一起分发（在 wheel 内）
- 保持现有 CLI 所有子命令功能不变
- `python -m team_memory_hub` 继续启动服务器
- Docker 构建无需额外修改

**Non-Goals:**
- 不重写 CLI 框架（如迁移到 click/typer）
- 不新增 CLI 子命令
- 不修改 CLI 的业务逻辑
- 不提供独立的 CLI-only 安装包

## Decisions

### D1: CLI 模块位置 — `src/team_memory_hub/cli.py`

将 `cli/main.py` 迁移到 `src/team_memory_hub/cli.py`。

**理由**: hatchling 构建配置 `packages = ["src/team_memory_hub"]`，只有该包内的模块才会被打入 wheel。将 CLI 放入包内是最简单的方案。

**替代方案**:
- 创建 `src/team_memory_hub/cli/` 子包 → 过度设计，当前只需一个文件
- 修改 hatchling `include` 配置纳入 `cli/` → 打破项目结构惯例

### D2: 入口点注册 — `[project.scripts]`

在 `pyproject.toml` 中添加：
```toml
[project.scripts]
tmh = "team_memory_hub.cli:main"
```

**理由**: 标准 PEP 621 方式，pip 安装时自动生成 `tmh` 可执行脚本。hatchling 原生支持。

### D3: `__main__.py` 保持服务器入口

`python -m team_memory_hub` 继续启动服务器（当前行为），不混入 CLI 逻辑。

**理由**: 服务器和 CLI 是不同的使用场景。`tmh` 命令处理 CLI，`python -m team_memory_hub` 处理服务器启动，职责清晰。

### D4: 旧 `cli/` 目录处理

迁移后删除 `cli/main.py`，保留 `cli/` 目录仅当其中有其他文件。如果目录为空则整个删除。

**理由**: 保留已废弃的文件会造成混乱。代码已纳入包内，不需要重定向。

### D5: `__main__.py` import 修复

当前 `__main__.py` 使用 `from main import main`（相对于项目根目录），需改为 `from team_memory_hub.server.app import create_app` 或保持 uvicorn 调用方式。

**理由**: 当前 import 依赖 `main.py` 在 Python path 上，以包方式安装后会失败。

## Risks / Trade-offs

- **[风险] 现有用户直接调用 `python cli/main.py`** → 迁移说明在 CHANGELOG 中注明；推荐使用 `tmh` 命令
- **[风险] `cli/main.py` 内部 import `team_memory_hub.*`** → 已确认现有代码使用绝对 import，迁移后路径兼容
- **[风险] Docker 构建路径变化** → Dockerfile 使用 `pip install .`，入口点自动注册，无需修改
- **[风险] 测试 import 路径变化** → `tests/test_cli.py` 需更新 import 从 `cli.main` 改为 `team_memory_hub.cli`
