## Why

TMH CLI (`cli/main.py`) 目前只能通过 `python cli/main.py` 或在项目目录内运行，无法作为全局命令使用。用户必须手动管理 Python 路径和工作目录。通过 `pip install` 注册 `tmh` 全局入口点，用户可以在任意终端直接执行 `tmh init`、`tmh search` 等命令，大幅降低使用门槛。

## What Changes

- 在 `pyproject.toml` 中添加 `[project.scripts]` 入口点，注册 `tmh = "team_memory_hub.cli:main"`
- 将 `cli/main.py` 迁移到 `src/team_memory_hub/cli.py`（纳入包内，随 wheel 一起分发）
- 修复 `src/team_memory_hub/__main__.py`，支持 `python -m team_memory_hub` 同时启动服务和使用 CLI
- 确保 `pip install .` 或 `pip install team-memory-hub` 后，`tmh` 命令全局可用
- 保持现有 CLI 功能不变（init, sync, store, search, detail, ingest, prefs, specs, consolidation）

## Capabilities

### New Capabilities
- `global-cli-entrypoint`: 将 TMH CLI 注册为 pip 可安装的全局命令入口点，支持 `tmh` 命令在任意目录下运行

### Modified Capabilities
- `tmh-cli`: CLI 模块路径从 `cli/main.py` 迁移到 `src/team_memory_hub/cli.py`，入口函数签名保持不变

## Impact

- **pyproject.toml**: 新增 `[project.scripts]` 段
- **源码结构**: `cli/main.py` → `src/team_memory_hub/cli.py`
- **__main__.py**: 更新 import 路径
- **现有测试**: `tests/test_cli.py` 需更新 import 路径
- **Docker**: Dockerfile 中安装方式需确认兼容
- **向后兼容**: `cli/` 目录可保留重定向脚本或在迁移完成后删除
