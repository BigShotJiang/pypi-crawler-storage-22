## ADDED Requirements

### Requirement: pip install registers tmh command
系统 SHALL 在通过 `pip install .` 或 `pip install team-memory-hub` 安装后，自动注册 `tmh` 全局命令入口点。

#### Scenario: Install and run tmh
- **WHEN** 用户执行 `pip install .` 然后在任意目录执行 `tmh --help`
- **THEN** 系统显示 TMH CLI 帮助信息，列出所有可用子命令

#### Scenario: tmh command invokes CLI main
- **WHEN** 用户执行 `tmh <subcommand>`
- **THEN** 系统调用 `team_memory_hub.cli:main` 入口函数处理命令

### Requirement: CLI module packaged in wheel
系统 SHALL 将 CLI 代码放置在 `src/team_memory_hub/cli.py` 模块内，确保随 wheel 包一起分发。

#### Scenario: CLI in installed package
- **WHEN** 通过 `pip install .` 安装后执行 `python -c "from team_memory_hub.cli import main"`
- **THEN** 导入成功，无 ImportError

### Requirement: pyproject.toml scripts entry
系统 SHALL 在 `pyproject.toml` 的 `[project.scripts]` 段定义 `tmh = "team_memory_hub.cli:main"`。

#### Scenario: Entry point defined
- **WHEN** 检查 `pyproject.toml` 内容
- **THEN** 存在 `[project.scripts]` 段，包含 `tmh = "team_memory_hub.cli:main"`

### Requirement: python -m continues to start server
`python -m team_memory_hub` SHALL 继续启动 TMH 服务器，与 CLI 入口点互不干扰。

#### Scenario: Module execution starts server
- **WHEN** 用户执行 `python -m team_memory_hub`
- **THEN** 系统启动 uvicorn 服务器，监听配置的端口
