## MODIFIED Requirements

### Requirement: Init command
系统 SHALL 提供 `tmh init` 命令，执行完整的项目接入流程：自动检测项目画像 → 匹配团队规范 → CLI 交互确认 → 语义去重 → 冲突解决 → 生成 AGENTS.md + .tmh/ + Hooks + Commands。CLI 入口模块位于 `team_memory_hub.cli`。

#### Scenario: Interactive init
- **WHEN** 执行 `tmh init`
- **THEN** 系统自动检测项目画像，交互式确认规范匹配，生成所有配置文件

#### Scenario: Non-interactive init
- **WHEN** 执行 `tmh init --non-interactive --project-priority`
- **THEN** 系统自动检测、匹配、以项目优先策略解决冲突，无交互

#### Scenario: Specify tools
- **WHEN** 执行 `tmh init --tools claude-code,cursor`
- **THEN** 系统仅生成指定工具的 Hook/Script/指令文件

### Requirement: Memory commands
系统 SHALL 提供记忆相关 CLI 命令：`tmh store`（存储记忆）、`tmh search`（搜索记忆，默认混合搜索）、`tmh detail`（查看原文）。所有 API 调用 SHALL 使用 `/api/v1/` 版本化前缀。CLI 模块路径为 `team_memory_hub.cli`。

#### Scenario: Store memory via CLI
- **WHEN** 执行 `tmh store "JWT 采用滑动窗口" --scope team --category decision`
- **THEN** 调用 `POST /api/v1/memories` 存储记忆并输出记忆 ID

#### Scenario: Search with engine option
- **WHEN** 执行 `tmh search "JWT token" --engine vector_only`
- **THEN** 调用 `GET /api/v1/memories` 使用指定引擎搜索并显示结果

#### Scenario: Get memory detail
- **WHEN** 执行 `tmh detail <memory_id>`
- **THEN** 调用 `GET /api/v1/memories/{memory_id}/detail` 并显示完整记忆内容
