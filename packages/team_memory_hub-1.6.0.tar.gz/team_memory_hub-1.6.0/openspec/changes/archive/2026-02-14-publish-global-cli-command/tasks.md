## 1. CLI 模块迁移

- [x] 1.1 将 `cli/main.py` 复制到 `src/team_memory_hub/cli.py`，保持所有功能代码不变
- [x] 1.2 删除 `cli/main.py` 和 `cli/__init__.py`，删除 `cli/` 空目录

## 2. 入口点注册

- [x] 2.1 在 `pyproject.toml` 中添加 `[project.scripts]` 段：`tmh = "team_memory_hub.cli:main"`

## 3. __main__.py 修复

- [x] 3.1 修复 `src/team_memory_hub/__main__.py`，将 `from main import main` 改为从正确的服务器入口模块导入

## 4. 测试更新

- [x] 4.1 更新 `tests/test_cli.py` 中所有 `from cli.main import ...` 为 `from team_memory_hub.cli import ...`

## 5. 验证

- [x] 5.1 执行 `pip install -e .` 确认 `tmh --help` 全局命令可用
- [x] 5.2 运行 `pytest tests/test_cli.py` 确认测试通过
- [x] 5.3 验证 `python -m team_memory_hub` 仍能启动服务器（import 不报错）
