## Context

TMH V1.6 已有基础 Dockerfile 和 docker-compose.yml，但存在以下问题：
- Dockerfile 安装 `.[dev]` 依赖（包含 pytest/ruff），镜像体积过大且暴露测试工具
- 无多阶段构建，无法利用层缓存优化构建速度
- 容器以 root 用户运行，存在安全隐患
- docker-compose.yml 缺少 profiles 区分开发/生产环境
- 无 `.dockerignore`，构建上下文包含 tests、.git 等无关文件
- `__init__.py` 版本号（0.1.0）与 `pyproject.toml`（1.6.0）不同步
- 尚未发布到 PyPI 或 DockerHub，缺乏自动化发布流程

## Goals / Non-Goals

**Goals:**
- 生产级 Docker 镜像：多阶段构建、非 root 用户、最小化体积
- docker-compose 多 profile 编排：dev（含 ollama + 热重载）、prod（资源限制 + 日志配置）
- DockerHub 自动发布：tag 触发 → 构建 → 推送多架构镜像
- PyPI 打包就绪：元数据完善、版本同步、构建验证
- PyPI 发布流程：GitHub Actions 自动发布或手动 twine 上传
- 统一版本管理：单一版本源（pyproject.toml）

**Non-Goals:**
- Kubernetes / Helm Chart 部署（后续迭代）
- 私有镜像仓库支持（仅 DockerHub）
- PyPI 私有仓库发布
- CI/CD 完整测试流水线（仅发布阶段）
- ARM 单独优化（依赖 Docker Buildx 多架构默认行为）

## Decisions

### D1: 多阶段 Dockerfile 构建

**选择**：两阶段构建（builder + runtime）

- **builder 阶段**：安装依赖到虚拟环境，编译需要的 C 扩展
- **runtime 阶段**：仅复制虚拟环境和源码，基于 `python:3.11-slim`

**替代方案**：
- 单阶段 + .dockerignore → 镜像仍包含编译工具链，体积大
- distroless 基础镜像 → 缺少 shell 调试能力，不适合当前阶段

**理由**：在镜像体积和可调试性之间取得平衡。

### D2: 容器用户隔离

**选择**：创建 `tmh` 非 root 用户（UID 1000）

```dockerfile
RUN groupadd -r tmh && useradd -r -g tmh -u 1000 tmh
```

**理由**：最小权限原则，防止容器逃逸时获取宿主机 root 权限。

### D3: docker-compose profiles 策略

**选择**：使用 Docker Compose profiles 区分环境

| Profile | 包含服务 | 特点 |
|---------|---------|------|
| （默认） | tmh | 最小启动，适合已有外部 embedding 服务 |
| `dev` | tmh（热重载）+ ollama | 开发环境，挂载源码 |
| `prod` | tmh + ollama | 资源限制、日志驱动、restart: always |

**替代方案**：
- 多个 compose 文件（docker-compose.dev.yml / docker-compose.prod.yml）→ 维护成本高
- 单个文件无 profiles → 开发/生产配置混杂

**理由**：profiles 是 Compose V2 标准特性，单文件维护更简洁。

### D4: DockerHub 发布策略

**选择**：GitHub Actions 自动构建 + tag 触发发布

- 触发条件：推送 `v*` tag（如 `v1.6.0`）
- 构建多架构镜像：`linux/amd64`, `linux/arm64`
- 标签策略：`latest`, `v1.6.0`, `v1.6`, `v1`
- 使用 `docker/build-push-action` + `docker/metadata-action`

**替代方案**：
- DockerHub 自动构建（Automated Builds）→ DockerHub 已弃用免费自动构建
- 手动构建推送 → 容易忘记、不可复现

### D5: PyPI 打包方案

**选择**：保持 `hatchling` 构建后端，补全元数据

需要补全的 pyproject.toml 字段：
- `license`、`authors`、`readme`、`keywords`
- `classifiers`（Development Status、Framework、License 等）
- `urls`（Homepage、Repository、Documentation、Bug Tracker）

**版本同步方案**：`__init__.py` 运行时从 `importlib.metadata` 读取版本

```python
from importlib.metadata import version
__version__ = version("team-memory-hub")
```

### D6: PyPI 发布流程

**选择**：GitHub Actions 自动发布 + 手动 twine 备选

- 自动发布：tag `v*` 触发 → `python -m build` → `twine upload`
- 手动备选：`python -m build && twine upload dist/*`
- 使用 PyPI trusted publisher（OIDC）免密发布

**替代方案**：
- 仅手动发布 → 容易遗漏、无法保证一致性
- flit / poetry → 更换构建后端代价过大

### D7: 健康检查优化

**选择**：在 Dockerfile 中使用轻量级 curl 替代 Python httpx 调用

```dockerfile
HEALTHCHECK --interval=30s --timeout=5s --retries=3 \
  CMD curl -f http://localhost:8000/api/health || exit 1
```

**替代方案**：保持 `python -c "import httpx; ..."` → 启动慢、内存开销大

## Risks / Trade-offs

- **[多架构构建时间]** → 首次构建 ARM64 较慢，通过 GitHub Actions 缓存 + BuildKit 层缓存缓解
- **[PyPI 包名冲突]** → 需验证 `team-memory-hub` 在 PyPI 上未被占用；若被占用则使用 `tmh-server`
- **[版本号跳跃]** → `__version__` 从 0.1.0 跳到 1.6.0，可能让已有用户困惑 → 在 CHANGELOG 中明确说明
- **[sqlite-vec 编译]** → ARM64 可能需要额外编译步骤 → 在 builder 阶段预装编译工具
- **[.env 文件安全]** → docker-compose 引用 .env 可能泄露密钥 → 使用 Docker secrets 或环境变量注入，提供 `.env.example` 但 `.env` 加入 `.gitignore`
