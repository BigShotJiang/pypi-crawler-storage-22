## Why

TMH V1.6 功能已完备，但缺乏生产级部署和分发能力。当前 Dockerfile 存在安全隐患（安装 dev 依赖、无多阶段构建、无非 root 用户），docker-compose.yml 仅有基础编排缺少生产配置（profiles、网络隔离、资源限制）。同时项目尚未发布到 PyPI，用户无法通过 `pip install team-memory-hub` 快速安装，版本号在 `__init__.py`（0.1.0）与 `pyproject.toml`（1.6.0）间不同步。需要完善容器化部署方案并建立 PyPI 发布流程，使 TMH 可被团队快速采用。

## What Changes

### Docker / DockerHub 发布
- 重写 Dockerfile：多阶段构建、非 root 用户、生产依赖分离、健康检查内置
- 增强 docker-compose.yml：添加 profiles（dev/prod）、网络隔离、资源限制、日志配置
- 添加 `.dockerignore` 优化构建上下文
- 创建 DockerHub 自动发布方案（GitHub Actions CI/CD）
- 镜像标签策略：`latest`、语义化版本（`v1.6.0`）、`sha-<commit>`

### PyPI 打包与发布
- 同步版本号：`__init__.py` 与 `pyproject.toml` 对齐
- 完善 pyproject.toml 元数据（classifiers、license、urls、readme）
- 验证 `hatchling` 构建产物（sdist + wheel）
- 创建 PyPI 发布流程（GitHub Actions 或手动 `twine upload`）
- 添加安装验证脚本

### 版本管理
- 统一版本号源为 `pyproject.toml`，`__init__.py` 动态读取
- **BREAKING**：`__version__` 从硬编码 `"0.1.0"` 跳到 `"1.6.0"`

## Capabilities

### New Capabilities
- `docker-deployment`: 生产级 Docker 镜像构建、docker-compose 多 profile 编排、DockerHub CI/CD 发布
- `pypi-packaging`: PyPI 打包配置完善、构建验证、发布流程、版本同步机制

### Modified Capabilities
（无现有 spec 的需求变更）

## Impact

- **文件变更**：Dockerfile（重写）、docker-compose.yml（增强）、pyproject.toml（元数据补全）、`__init__.py`（版本同步）
- **新增文件**：`.dockerignore`、GitHub Actions workflow（可选）
- **依赖**：无新运行时依赖；构建/发布需要 `twine`、`build`（仅 CI 环境）
- **用户影响**：现有 `docker compose up` 命令兼容，新增 `--profile prod` 选项
- **发布渠道**：DockerHub（`xiaoc/team-memory-hub`）、PyPI（`team-memory-hub`）
