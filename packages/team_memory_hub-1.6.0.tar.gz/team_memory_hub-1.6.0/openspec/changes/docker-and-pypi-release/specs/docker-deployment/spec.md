## ADDED Requirements

### Requirement: 多阶段 Docker 镜像构建
Dockerfile SHALL 使用多阶段构建，将依赖安装（builder）与运行时（runtime）分离。Runtime 阶段 SHALL 基于 `python:3.11-slim`，MUST NOT 包含编译工具链或 dev 依赖。最终镜像 SHALL 以非 root 用户 `tmh`（UID 1000）运行。

#### Scenario: 构建生产镜像
- **WHEN** 执行 `docker build -t tmh .`
- **THEN** 生成的镜像 MUST NOT 包含 pytest、ruff 等 dev 依赖，镜像内进程以 `tmh` 用户运行

#### Scenario: 镜像层缓存
- **WHEN** 仅修改 src/ 代码（未修改 pyproject.toml）后重新构建
- **THEN** 依赖安装层 SHALL 命中缓存，构建仅重新复制源码

### Requirement: Docker 健康检查
Dockerfile SHALL 内置 HEALTHCHECK 指令，定期检测 `/api/health` 端点。

#### Scenario: 健康检查通过
- **WHEN** TMH 服务正常运行
- **THEN** `docker inspect` 显示容器状态为 `healthy`

#### Scenario: 健康检查失败
- **WHEN** TMH 服务无响应
- **THEN** 连续 3 次检查失败后容器状态变为 `unhealthy`

### Requirement: .dockerignore 文件
项目根目录 SHALL 包含 `.dockerignore` 文件，排除 `.git`、`tests/`、`__pycache__`、`.env`、`data/`、`openspec/` 等与运行无关的文件。

#### Scenario: 构建上下文最小化
- **WHEN** 执行 `docker build`
- **THEN** 构建上下文 MUST NOT 包含 .git 目录、tests 目录、data 目录

### Requirement: docker-compose 多 profile 编排
docker-compose.yml SHALL 支持以下运行模式：
- 默认（无 profile）：仅启动 tmh 服务
- `dev` profile：tmh（源码挂载 + 热重载）+ ollama
- `prod` profile：tmh + ollama，带资源限制和日志配置

#### Scenario: 默认启动
- **WHEN** 执行 `docker compose up`
- **THEN** 仅启动 tmh 服务，不启动 ollama

#### Scenario: 开发模式启动
- **WHEN** 执行 `docker compose --profile dev up`
- **THEN** tmh 服务挂载本地 src/ 目录并启用热重载，同时启动 ollama 服务

#### Scenario: 生产模式启动
- **WHEN** 执行 `docker compose --profile prod up -d`
- **THEN** tmh 和 ollama 均启动，tmh 设置内存限制和 CPU 限制，日志驱动配置为 json-file 并限制大小

### Requirement: 数据持久化
docker-compose SHALL 使用 named volumes 持久化 TMH 数据目录和 ollama 模型数据。

#### Scenario: 容器重建后数据保留
- **WHEN** 执行 `docker compose down && docker compose up`
- **THEN** TMH 数据库和记忆文件 SHALL 保留，ollama 已下载的模型 SHALL 保留

### Requirement: DockerHub 自动发布
项目 SHALL 提供 GitHub Actions workflow，在推送 `v*` tag 时自动构建并推送 Docker 镜像到 DockerHub。

#### Scenario: tag 触发发布
- **WHEN** 推送 tag `v1.6.0` 到 GitHub
- **THEN** GitHub Actions 构建多架构镜像（amd64 + arm64）并推送标签 `latest`、`v1.6.0`、`v1.6`、`v1`

#### Scenario: 非 tag 推送不触发
- **WHEN** 推送普通 commit 到 main 分支
- **THEN** Docker 发布 workflow MUST NOT 被触发
