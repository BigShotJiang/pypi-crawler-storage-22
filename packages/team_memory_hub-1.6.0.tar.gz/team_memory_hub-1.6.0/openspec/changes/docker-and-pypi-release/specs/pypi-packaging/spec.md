## ADDED Requirements

### Requirement: PyPI 包元数据完整
pyproject.toml SHALL 包含完整的 PyPI 发布所需元数据：license、authors、readme、keywords、classifiers、project-urls。

#### Scenario: 元数据验证通过
- **WHEN** 执行 `python -m build` 构建 sdist 和 wheel
- **THEN** `twine check dist/*` SHALL 返回 PASSED，无警告

#### Scenario: PyPI 页面信息完整
- **WHEN** 包发布到 PyPI
- **THEN** PyPI 页面 SHALL 显示项目描述（README）、主页链接、仓库链接、许可证信息

### Requirement: 版本号单一来源
项目版本号 SHALL 以 `pyproject.toml` 中的 `version` 字段为唯一真实来源。`__init__.py` 中的 `__version__` SHALL 通过 `importlib.metadata` 动态读取，MUST NOT 硬编码版本号。

#### Scenario: 版本号一致性
- **WHEN** 导入 `team_memory_hub` 包
- **THEN** `team_memory_hub.__version__` SHALL 等于 `pyproject.toml` 中的 `version` 值

#### Scenario: 版本号更新
- **WHEN** 仅修改 `pyproject.toml` 中的 version 字段
- **THEN** `team_memory_hub.__version__` SHALL 自动反映新版本，无需修改其他文件

### Requirement: 构建产物正确
`python -m build` SHALL 生成可安装的 sdist（.tar.gz）和 wheel（.whl）包，安装后 `tmh` CLI 命令可用。

#### Scenario: wheel 安装验证
- **WHEN** 在干净虚拟环境中 `pip install dist/team_memory_hub-*.whl`
- **THEN** `tmh --help` 命令可用，`python -c "from team_memory_hub import __version__; print(__version__)"` 输出正确版本

#### Scenario: sdist 安装验证
- **WHEN** 在干净虚拟环境中 `pip install dist/team-memory-hub-*.tar.gz`
- **THEN** 安装成功且 `tmh` 命令可用

### Requirement: PyPI 发布流程
项目 SHALL 提供 GitHub Actions workflow，在推送 `v*` tag 时自动构建并发布到 PyPI。同时 SHALL 支持手动 twine 上传作为备选。

#### Scenario: 自动发布到 PyPI
- **WHEN** 推送 tag `v1.6.0` 到 GitHub
- **THEN** GitHub Actions 构建 sdist + wheel 并通过 trusted publisher 发布到 PyPI

#### Scenario: 手动发布
- **WHEN** 开发者本地执行 `python -m build && twine upload dist/*`
- **THEN** 包成功上传到 PyPI

### Requirement: 安装方式文档化
README SHALL 列出所有安装方式及其适用场景。

#### Scenario: pip 安装
- **WHEN** 用户执行 `pip install team-memory-hub`
- **THEN** 安装核心依赖，`tmh` CLI 可用

#### Scenario: 带可选依赖安装
- **WHEN** 用户执行 `pip install team-memory-hub[all]`
- **THEN** 安装所有 embedding 和 llm 可选依赖

#### Scenario: Docker 安装
- **WHEN** 用户执行 `docker run -p 8000:8000 xiaoc/team-memory-hub`
- **THEN** TMH 服务启动并监听 8000 端口
