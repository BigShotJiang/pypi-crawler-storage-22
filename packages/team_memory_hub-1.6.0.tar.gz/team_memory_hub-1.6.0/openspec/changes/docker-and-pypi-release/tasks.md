## 1. 版本号同步

- [x] 1.1 修改 `src/team_memory_hub/__init__.py`，使用 `importlib.metadata.version()` 动态读取版本号，移除硬编码 `"0.1.0"`
- [x] 1.2 验证 `python -c "from team_memory_hub import __version__; print(__version__)"` 输出 `1.6.0`

## 2. Docker 镜像优化

- [x] 2.1 创建 `.dockerignore` 文件，排除 `.git/`、`tests/`、`__pycache__/`、`*.pyc`、`.env`、`data/`、`openspec/`、`docs/`、`.ruff_cache/`
- [x] 2.2 重写 Dockerfile 为多阶段构建：builder 阶段安装依赖，runtime 阶段仅复制虚拟环境和源码
- [x] 2.3 在 runtime 阶段创建非 root 用户 `tmh`（UID 1000），设置数据目录权限
- [x] 2.4 在 Dockerfile 中添加 HEALTHCHECK 指令（curl -f http://localhost:8000/api/health）
- [x] 2.5 执行 `docker build -t tmh:test .` 验证构建成功，检查镜像不含 dev 依赖
- [x] 2.6 执行 `docker run` 验证容器以 tmh 用户运行，健康检查正常

## 3. docker-compose 增强

- [x] 3.1 重写 docker-compose.yml：默认仅启动 tmh 服务（无 ollama 依赖）
- [x] 3.2 添加 `dev` profile：tmh 服务挂载 src/ 目录 + 热重载，ollama 服务
- [x] 3.3 添加 `prod` profile：tmh + ollama，配置资源限制（memory、cpus）、日志驱动（json-file + max-size）、restart: always
- [x] 3.4 配置网络隔离：创建 `tmh-net` 网络，服务间通过服务名通信
- [x] 3.5 验证 `docker compose up`（默认）、`docker compose --profile dev up`、`docker compose --profile prod up` 三种模式均正常

## 4. PyPI 打包配置

- [x] 4.1 补全 pyproject.toml 元数据：license、authors、readme、keywords、classifiers、project-urls
- [ ] 4.2 执行 `python -m build` 生成 sdist 和 wheel
- [ ] 4.3 执行 `twine check dist/*` 验证包元数据无警告
- [ ] 4.4 在干净虚拟环境中安装 wheel，验证 `tmh --help` 和 `__version__` 正确

## 5. CI/CD 发布流程

- [ ] 5.1 创建 `.github/workflows/docker-publish.yml`：tag 触发 → 多架构构建 → 推送 DockerHub（标签：latest、vX.Y.Z、vX.Y、vX）
- [ ] 5.2 创建 `.github/workflows/pypi-publish.yml`：tag 触发 → build → twine upload（trusted publisher OIDC）
- [ ] 5.3 在两个 workflow 中添加版本号一致性检查（tag 版本 == pyproject.toml 版本）

## 6. 文档更新

- [ ] 6.1 更新 README 安装章节：添加 `pip install team-memory-hub`、`docker run`、`docker compose` 三种安装方式
- [ ] 6.2 创建 `.env.example` 更新（确认已包含 Docker 相关环境变量）
- [ ] 6.3 创建 `tmh.toml.example` 更新（确认 Docker 默认配置可用）
