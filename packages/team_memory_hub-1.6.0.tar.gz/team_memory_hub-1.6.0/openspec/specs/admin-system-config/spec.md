## ADDED Requirements

### Requirement: System configuration view
系统 SHALL 在管理后台提供系统配置查看界面，路径 `/dashboard/admin/system`。页面 SHALL 显示当前运行时配置参数，按分组组织（服务器、搜索、嵌入、MCP、安全等）。

#### Scenario: View system configuration
- **WHEN** admin 用户访问 `/dashboard/admin/system`
- **THEN** 显示当前系统配置参数，按分类分组（server、search、embedding、mcp、security）

#### Scenario: Non-admin cannot view system config
- **WHEN** maintainer 角色用户访问 `/dashboard/admin/system`
- **THEN** 系统返回 403 Forbidden 或重定向到无权限提示页

### Requirement: Runtime configuration editing
系统 SHALL 支持在线修改部分运行时配置参数。可修改参数 SHALL 限定为安全参数（如搜索结果数量、缓存 TTL、分页默认值等），核心参数（如数据库路径、密钥、端口）SHALL 保持只读。

布尔类型参数的转换 SHALL 使用严格解析：仅接受 `{"true", "1", "yes"}` 转为 `True`，`{"false", "0", "no"}` 转为 `False`（均忽略大小写）。其他字符串值 SHALL 返回验证错误。

#### Scenario: Edit safe configuration parameter
- **WHEN** admin 用户修改 search.default_limit 的值并保存
- **THEN** 系统更新运行时配置，后续请求使用新值

#### Scenario: Cannot edit read-only parameter
- **WHEN** admin 用户尝试修改 server.host 等核心参数
- **THEN** 该参数 SHALL 显示为只读状态，不提供编辑功能

#### Scenario: Invalid configuration value
- **WHEN** admin 用户输入非法值（如负数的 limit）
- **THEN** 系统返回验证错误提示，不应用变更

#### Scenario: Boolean string "false" correctly parsed
- **WHEN** admin 用户将布尔配置项设为字符串 `"false"`
- **THEN** 系统将其转换为 `False`（而非 `True`）

#### Scenario: Invalid boolean string rejected
- **WHEN** admin 用户将布尔配置项设为字符串 `"maybe"`
- **THEN** 系统返回验证错误"无效的布尔值"

### Requirement: System statistics dashboard
系统 SHALL 在系统配置页面提供系统运行统计信息，包含：数据库大小、记忆总数、用户总数、团队总数、项目总数、API 调用统计、搜索引擎状态。

#### Scenario: View system statistics
- **WHEN** admin 用户查看系统统计区域
- **THEN** 显示各项统计数据的当前值

#### Scenario: Statistics auto-refresh
- **WHEN** 页面保持打开超过 30 秒
- **THEN** 统计数据 SHALL 通过 HTMX 轮询自动刷新

### Requirement: System config API
系统 SHALL 提供系统配置 API 端点 `/api/admin/system/config` 和 `/api/admin/system/stats`，仅 admin 角色可访问。

#### Scenario: Get configuration
- **WHEN** 调用 `GET /api/admin/system/config`
- **THEN** 返回所有配置参数，每个参数标记 editable=true/false

#### Scenario: Update configuration
- **WHEN** 调用 `PATCH /api/admin/system/config` 并提交配置变更
- **THEN** 系统验证参数合法性后更新运行时配置，返回更新后的配置

#### Scenario: Get system stats
- **WHEN** 调用 `GET /api/admin/system/stats`
- **THEN** 返回系统统计信息（数据库大小、各实体计数、搜索引擎状态）

### Requirement: System health version consistency
`/api/v1/system/health` 端点 SHALL 返回与 `/api/v1/health` 一致的版本号 `1.6.0`。

#### Scenario: System health returns correct version
- **WHEN** 调用 `GET /api/v1/system/health`
- **THEN** 返回 JSON 包含 `"version": "1.6.0"`

#### Scenario: Both health endpoints return same version
- **WHEN** 分别调用 `GET /api/v1/health` 和 `GET /api/v1/system/health`
- **THEN** 两个响应中的 `version` 字段值相同，均为 `1.6.0`
