### Requirement: Top navigation bar SHALL include breadcrumb, user menu, and global search
顶部导航栏 SHALL 包含以下元素（从左到右）：品牌标识（TMH Dashboard）、面包屑导航、全局搜索输入框、主题切换按钮、用户头像下拉菜单。导航栏 SHALL 固定在页面顶部，高度 56px。

#### Scenario: 导航栏元素渲染
- **WHEN** 用户访问任意 Dashboard 页面
- **THEN** 顶部导航栏 SHALL 显示品牌标识、面包屑、搜索框、主题按钮、用户菜单
- **THEN** 导航栏 SHALL 使用 `position: sticky; top: 0` 固定在顶部

#### Scenario: 面包屑显示当前路径
- **WHEN** 用户在管理后台 > 团队管理页面
- **THEN** 面包屑 SHALL 显示"概览 / 管理后台 / 团队管理"
- **THEN** 每一级 SHALL 可点击跳转到对应页面

#### Scenario: 用户头像下拉菜单
- **WHEN** 用户点击顶栏右侧的用户头像/名称
- **THEN** SHALL 展开下拉菜单，包含"个人信息"和"退出登录"选项

### Requirement: Main navigation SHALL use horizontal tabs for user pages
用户端页面导航 SHALL 使用顶部导航栏下方的水平 Tab 栏，包含：概览、记忆、合并、规范、搜索。当前活跃页面的 Tab SHALL 有明显的视觉区分（底部高亮边框）。

#### Scenario: Tab 栏渲染与活跃状态
- **WHEN** 用户在"记忆"页面
- **THEN** "记忆" Tab SHALL 显示底部高亮边框（使用 `--tmh-color-primary`）
- **THEN** 其他 Tab SHALL 显示默认非活跃状态

#### Scenario: 管理后台入口在 Tab 栏
- **WHEN** 当前用户的 `is_admin` 为 `True`
- **THEN** Tab 栏右侧 SHALL 显示"管理后台"入口（带图标区分）
- **WHEN** `is_admin` 为 `False`
- **THEN** "管理后台"入口 SHALL 不显示

### Requirement: Admin sidebar SHALL group navigation items into collapsible sections
管理后台 SHALL 使用左侧侧边栏导航，宽度 220px，将导航项分为两个可折叠组：
- **实体管理**：团队、用户、项目、API Key
- **系统运维**：记忆审核、系统配置

#### Scenario: 侧边栏分组折叠
- **WHEN** 用户点击"实体管理"分组标题
- **THEN** 该分组 SHALL 折叠/展开其子导航项
- **THEN** 折叠状态 SHALL 使用 CSS transition 平滑动画

#### Scenario: 当前页面高亮
- **WHEN** 用户在"用户管理"页面
- **THEN** "用户管理"导航项 SHALL 显示活跃状态（背景色高亮 + 左侧边框）
- **THEN** 其所在的"实体管理"分组 SHALL 保持展开状态

### Requirement: Mobile navigation SHALL use drawer pattern
在视口宽度 ≤ 768px 时，系统 SHALL 将导航切换为抽屉式（drawer）模式：
- 顶部导航栏左侧 SHALL 显示 hamburger 图标按钮
- 点击后 SHALL 从左侧滑出导航抽屉，覆盖内容区域
- 抽屉 SHALL 包含所有用户端 Tab 项和管理后台入口

#### Scenario: 移动端导航抽屉打开
- **WHEN** 视口宽度 ≤ 768px 且用户点击 hamburger 图标
- **THEN** 导航抽屉 SHALL 从左侧滑入（CSS transform 动画，duration 200ms）
- **THEN** 抽屉外区域 SHALL 显示半透明遮罩

#### Scenario: 移动端导航抽屉关闭
- **WHEN** 用户点击遮罩区域或抽屉内的导航链接
- **THEN** 导航抽屉 SHALL 滑出关闭

#### Scenario: 管理后台侧边栏在移动端折叠
- **WHEN** 视口宽度 ≤ 768px 且用户在管理后台页面
- **THEN** 侧边栏 SHALL 隐藏，管理后台导航项合并到全局抽屉中

### Requirement: Responsive grid layout SHALL adapt to viewport width
页面主内容区域 SHALL 使用 CSS Grid 响应式布局：
- 桌面（>1200px）：最大宽度 1200px，居中
- 平板（768px-1200px）：左右 padding 24px
- 手机（<768px）：左右 padding 16px

#### Scenario: 管理后台布局
- **WHEN** 视口宽度 >768px 且用户在管理后台
- **THEN** 页面 SHALL 使用 `grid-template-columns: 220px 1fr` 布局（侧边栏 + 主内容）

#### Scenario: 手机端全宽布局
- **WHEN** 视口宽度 ≤768px
- **THEN** 页面 SHALL 使用单列全宽布局，padding 16px
