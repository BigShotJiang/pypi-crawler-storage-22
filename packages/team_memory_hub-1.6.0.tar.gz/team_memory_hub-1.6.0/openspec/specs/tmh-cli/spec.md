## ADDED Requirements

### Requirement: Init command
系统 SHALL 提供 `tmh init` 命令，执行完整的项目接入流程：自动检测项目画像 → 匹配团队规范 → CLI 交互确认 → 语义去重 → 冲突解决 → 生成 AGENTS.md + .tmh/ + Hooks + Commands。CLI 入口模块位于 `team_memory_hub.cli`。

#### Scenario: Interactive init
- **WHEN** 执行 `tmh init`
- **THEN** 系统自动检测项目画像，交互式确认规范匹配，生成所有配置文件

#### Scenario: Non-interactive init
- **WHEN** 执行 `tmh init --non-interactive --project-priority`
- **THEN** 系统自动检测、匹配、以项目优先策略解决冲突，无交互

#### Scenario: Specify tools
- **WHEN** 执行 `tmh init --tools claude-code,cursor`
- **THEN** 系统仅生成指定工具的 Hook/Script/指令文件

### Requirement: Sync command
系统 SHALL 提供 `tmh sync` 命令，同步 context 和 AGENTS.md。支持 `--watch`（SSE 实时模式）、`--resolve`（解决新冲突）、`--force`（强制全量刷新）。

#### Scenario: Sync detects update
- **WHEN** 执行 `tmh sync` 且本地版本落后于服务器
- **THEN** 拉取增量变更，更新 AGENTS.md

#### Scenario: Watch mode
- **WHEN** 执行 `tmh sync --watch`
- **THEN** 通过 SSE 实时监听变更，自动同步

### Requirement: Memory commands
系统 SHALL 提供记忆相关 CLI 命令：`tmh store`（存储记忆）、`tmh search`（搜索记忆，默认混合搜索）、`tmh detail`（查看原文）。所有 API 调用 SHALL 使用 `/api/v1/` 版本化前缀。CLI 模块路径为 `team_memory_hub.cli`。

#### Scenario: Store memory via CLI
- **WHEN** 执行 `tmh store "JWT 采用滑动窗口" --scope team --category decision`
- **THEN** 调用 `POST /api/v1/memories` 存储记忆并输出记忆 ID

#### Scenario: Search with engine option
- **WHEN** 执行 `tmh search "JWT token" --engine vector_only`
- **THEN** 调用 `GET /api/v1/memories` 使用指定引擎搜索并显示结果

#### Scenario: Get memory detail
- **WHEN** 执行 `tmh detail <memory_id>`
- **THEN** 调用 `GET /api/v1/memories/{memory_id}/detail` 并显示完整记忆内容

### Requirement: Chat ingest commands
系统 SHALL 提供 `tmh ingest` 命令，支持 `--file`（从文件导入）、`--stdin`（管道输入）、`--scan-cursor`（扫描 Cursor 聊天记录）。所有 API 调用 SHALL 使用 `/api/v1/` 版本化前缀。

#### Scenario: Ingest from file
- **WHEN** 执行 `tmh ingest --file chat.json --tool cursor`
- **THEN** 调用 `POST /api/v1/chats/ingest` 上传聊天记录并输出提取的记忆数量

#### Scenario: Ingest from stdin
- **WHEN** 执行 `codex ... | tmh ingest --stdin --tool codex`
- **THEN** 调用 `POST /api/v1/chats/ingest` 从标准输入读取并处理聊天记录

### Requirement: Spec management commands
系统 SHALL 提供规范管理 CLI 命令：`tmh specs list`、`tmh specs show`、`tmh specs propose`、`tmh specs proposals`、`tmh specs merge`、`tmh specs withdraw`。

#### Scenario: List specs
- **WHEN** 执行 `tmh specs list`
- **THEN** 显示所有团队规范的路径和摘要

#### Scenario: Create proposal via CLI
- **WHEN** 执行 `tmh specs propose "迁移JWT v2" --delta delta.md`
- **THEN** 创建提案并输出提案 ID

### Requirement: Consolidation commands
系统 SHALL 提供记忆整合 CLI 命令：`tmh consolidation list`、`tmh consolidation show`、`tmh consolidation accept`、`tmh consolidation reject`、`tmh consolidation scan`、`tmh consolidation stats`。所有 API 调用 SHALL 使用 `/api/v1/` 版本化前缀。

#### Scenario: List pending suggestions via CLI
- **WHEN** 执行 `tmh consolidation list`
- **THEN** 调用 `GET /api/v1/consolidation/suggestions` 显示所有 pending 状态的合并建议

#### Scenario: Manual scan trigger
- **WHEN** 执行 `tmh consolidation scan`
- **THEN** 调用 `POST /api/v1/consolidation/scan` 触发手动合并候选扫描

#### Scenario: Accept or reject suggestion
- **WHEN** 执行 `tmh consolidation accept --id <suggestion_id>`
- **THEN** 调用 `POST /api/v1/consolidation/suggestions/{id}/accept`

### Requirement: Preference commands use versioned API
系统 SHALL 使所有偏好相关 CLI 命令使用 `/api/v1/` 版本化前缀。涵盖 `tmh prefs list`、`set`、`get`、`team-list`、`team-set`、`suggestions` 子命令。

#### Scenario: List user preferences
- **WHEN** 执行 `tmh prefs list`
- **THEN** 调用 `GET /api/v1/preferences/user`

#### Scenario: Set user preference
- **WHEN** 执行 `tmh prefs set --key theme --value dark`
- **THEN** 调用 `POST /api/v1/preferences/user`

#### Scenario: Get effective preferences
- **WHEN** 执行 `tmh prefs get`
- **THEN** 调用 `GET /api/v1/preferences/effective`

#### Scenario: Team preference operations
- **WHEN** 执行 `tmh prefs team-list` 或 `tmh prefs team-set`
- **THEN** 分别调用 `GET /api/v1/preferences/team` 和 `POST /api/v1/preferences/team`

#### Scenario: Preference suggestions
- **WHEN** 执行 `tmh prefs suggestions`
- **THEN** 调用 `GET /api/v1/preferences/suggestions`
