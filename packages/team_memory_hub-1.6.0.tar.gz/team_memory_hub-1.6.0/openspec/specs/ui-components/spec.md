### Requirement: Modal component SHALL replace native dialog element
模态框组件 SHALL 使用 `<div class="modal-overlay">` + `<div class="modal">` 结构替代原生 `<dialog>` 元素。支持进入/退出 CSS 动画、backdrop 模糊效果、ESC 键关闭和焦点陷阱。

#### Scenario: 模态框打开动画
- **WHEN** 调用 `TMH.modal.open(contentUrl)` 方法
- **THEN** overlay SHALL 以 fade-in 动画出现（opacity 0→1，duration 150ms）
- **THEN** modal 主体 SHALL 以 scale + fade 动画出现（transform scale(0.95)→scale(1)，duration 200ms）
- **THEN** overlay SHALL 应用 `backdrop-filter: blur(4px)` 效果

#### Scenario: 模态框焦点陷阱
- **WHEN** 模态框打开后用户按 Tab 键
- **THEN** 焦点 SHALL 在模态框内部的可聚焦元素间循环，不会跳出模态框
- **WHEN** 用户按 ESC 键
- **THEN** 模态框 SHALL 关闭并恢复焦点到触发元素

#### Scenario: 模态框关闭
- **WHEN** 用户点击 overlay 遮罩区域或模态框关闭按钮
- **THEN** 模态框 SHALL 以反向动画退出（duration 150ms）
- **THEN** body 滚动 SHALL 恢复

#### Scenario: HTMX 集成
- **WHEN** 通过 HTMX 请求加载模态框内容
- **THEN** 成功的 HTMX 请求（`htmx:afterRequest` 且 successful）SHALL 自动关闭模态框并刷新父容器

### Requirement: Toast notification system SHALL replace alert dialogs
系统 SHALL 提供 Toast 通知组件替代所有 `alert()` 调用。Toast 支持 4 种类型：success（绿色）、error（红色）、warning（橙色）、info（蓝色）。

#### Scenario: Toast 显示与自动消失
- **WHEN** 调用 `TMH.toast.show({type: 'success', message: '操作成功'})` 方法
- **THEN** Toast SHALL 在页面右上角以 slide-in 动画出现
- **THEN** Toast SHALL 在 3 秒后自动以 fade-out 动画消失
- **THEN** error 类型的 Toast SHALL 不自动消失，需手动关闭

#### Scenario: Toast 堆叠
- **WHEN** 多个 Toast 同时存在
- **THEN** Toast SHALL 自上而下堆叠显示，间距 8px
- **THEN** 新 Toast SHALL 出现在堆叠顶部

#### Scenario: Toast 手动关闭
- **WHEN** 用户点击 Toast 上的关闭按钮
- **THEN** 该 Toast SHALL 以 fade-out 动画消失
- **THEN** 剩余 Toast SHALL 平滑上移填补空间

### Requirement: Pagination component SHALL support page numbers and page size selection
分页组件 SHALL 显示页码列表（最多 7 个页码按钮 + 省略号）、上一页/下一页按钮、跳页输入框、每页条数选择器（10/20/50/100）。

#### Scenario: 页码列表显示
- **WHEN** 总页数 >7 且当前页为第 5 页
- **THEN** 页码 SHALL 显示为 `[1] ... [4] [5] [6] ... [10]`（首页 + 省略 + 当前页前后 + 省略 + 末页）
- **WHEN** 总页数 ≤7
- **THEN** SHALL 显示所有页码，不使用省略号

#### Scenario: 跳页功能
- **WHEN** 用户在跳页输入框中输入页码并按 Enter
- **THEN** 系统 SHALL 通过 HTMX 请求跳转到指定页面
- **WHEN** 输入的页码超出范围
- **THEN** 系统 SHALL 自动修正为最近的有效页码

#### Scenario: 每页条数切换
- **WHEN** 用户从下拉菜单选择不同的每页条数
- **THEN** 系统 SHALL 重新请求第 1 页数据，使用新的 page_size 参数
- **THEN** 当前选中的条数 SHALL 持久化到 `localStorage`

### Requirement: Data table component SHALL support horizontal scroll, select-all, and sort indicators
数据表格组件 SHALL 在容器宽度不足时支持水平滚动，表头 SHALL 支持全选/反选复选框，可排序列 SHALL 显示排序方向指示器。

#### Scenario: 水平滚动
- **WHEN** 表格宽度超过容器宽度
- **THEN** 表格容器 SHALL 显示水平滚动条
- **THEN** 容器左右两侧 SHALL 在可滚动方向显示渐变阴影提示

#### Scenario: 全选与反选
- **WHEN** 用户点击表头的全选复选框
- **THEN** 当前页所有行的复选框 SHALL 被选中
- **WHEN** 再次点击
- **THEN** 所有复选框 SHALL 取消选中
- **THEN** 页面底部 SHALL 显示已选择数量（如"已选择 5 条记忆"）

#### Scenario: 键盘快捷键
- **WHEN** 表格处于焦点状态且用户按 `Ctrl+A`
- **THEN** SHALL 全选当前页所有行（而非触发浏览器默认全选）

### Requirement: Loading skeleton SHALL replace text-only loading indicators
加载状态 SHALL 使用骨架屏（skeleton）动画替代纯文本"加载中..."。骨架屏 SHALL 模拟即将加载内容的形状和布局。

#### Scenario: 表格加载骨架屏
- **WHEN** 通过 HTMX 请求加载表格数据时
- **THEN** 表格区域 SHALL 显示 5 行骨架屏占位符（灰色矩形 + shimmer 动画）
- **THEN** 数据返回后骨架屏 SHALL 被实际内容替换

#### Scenario: 卡片加载骨架屏
- **WHEN** 概览页面加载 KPI 数据时
- **THEN** KPI 卡片区域 SHALL 显示与卡片尺寸匹配的骨架屏
- **THEN** 骨架屏 SHALL 使用 `background: linear-gradient` + CSS animation 实现 shimmer 效果

### Requirement: Badge component SHALL use unified visual style
徽章组件 SHALL 统一使用 pill 形状（`border-radius: var(--tmh-radius-full)`）、一致的内边距和字体大小。颜色 SHALL 通过设计令牌中的语义颜色变量获取。

#### Scenario: 质量状态徽章渲染
- **WHEN** 渲染质量状态徽章
- **THEN** community SHALL 使用 `--tmh-color-info` 系列变量
- **THEN** verified SHALL 使用 `--tmh-color-success` 系列变量
- **THEN** pinned SHALL 使用 `--tmh-color-warning` 系列变量
- **THEN** stale SHALL 使用 `--tmh-color-error` 系列变量
- **THEN** archived SHALL 使用 `--tmh-color-neutral` 系列变量

#### Scenario: 角色徽章渲染
- **WHEN** 渲染用户角色徽章
- **THEN** admin SHALL 使用紫色系变量（`--tmh-color-purple-*`）
- **THEN** 所有徽章 SHALL 使用相同的 padding（4px 12px）和 font-size（0.75rem）
