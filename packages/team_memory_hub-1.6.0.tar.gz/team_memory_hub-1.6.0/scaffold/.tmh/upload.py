#!/usr/bin/env python3
"""TMH upload script: Tier 2 upload with store/chat/propose subcommands.

Usage:
  python upload.py store --content "..." --category decision --tags "tag1,tag2"
  python upload.py chat --file chat_export.json --tool claude-code
  python upload.py propose --title "..." --spec coding_standards --delta delta.md

Environment variables:
  TMH_SERVER      - TMH server URL (default: http://localhost:8000)
  TMH_INGEST_KEY  - API key for authentication
"""

import argparse
import json
import os
import sys


def get_client():
    """Get configured httpx client."""
    import httpx

    server = os.environ.get("TMH_SERVER", "http://localhost:8000")
    key = os.environ.get("TMH_INGEST_KEY", "")

    headers = {"Content-Type": "application/json"}
    if key:
        headers["Authorization"] = f"Bearer {key}"

    return httpx.Client(base_url=server, headers=headers, timeout=30)


def cmd_store(args):
    """Store a memory."""
    client = get_client()

    tags = [t.strip() for t in args.tags.split(",")] if args.tags else []

    payload = {
        "content": args.content,
        "summary": args.summary,
        "category": args.category,
        "tags": tags,
        "scope": args.scope,
    }

    resp = client.post("/api/memories", json=payload)
    if resp.status_code == 201:
        data = resp.json()
        print(f"Memory stored: {data.get('id')}")
    else:
        print(f"Error: {resp.status_code} - {resp.text}", file=sys.stderr)
        sys.exit(1)


def cmd_chat(args):
    """Upload a chat session."""
    client = get_client()

    # Read chat data from file or stdin
    if args.file == "-":
        raw_data = json.loads(sys.stdin.read())
    else:
        with open(args.file, "r", encoding="utf-8") as f:
            raw_data = json.load(f)

    payload = {
        "tool_name": args.tool,
        "raw_data": raw_data,
        "project_id": args.project,
    }

    resp = client.post("/api/chats/ingest", json=payload)
    if resp.status_code == 200:
        data = resp.json()
        print(f"Chat ingested: {data.get('session_id')} ({data.get('turn_count')} turns)")
    else:
        print(f"Error: {resp.status_code} - {resp.text}", file=sys.stderr)
        sys.exit(1)


def cmd_propose(args):
    """Create a spec proposal."""
    client = get_client()

    # Read delta from file
    delta_content = ""
    if args.delta:
        with open(args.delta, "r", encoding="utf-8") as f:
            delta_content = f.read()

    payload = {
        "title": args.title,
        "description": args.description or "",
        "target_spec": args.spec,
        "delta_content": delta_content,
    }

    resp = client.post("/api/specs/proposals", json=payload)
    if resp.status_code in (200, 201):
        data = resp.json()
        print(f"Proposal created: {data.get('id')}")
    else:
        print(f"Error: {resp.status_code} - {resp.text}", file=sys.stderr)
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="TMH Upload Script")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # store subcommand
    store_p = subparsers.add_parser("store", help="Store a memory")
    store_p.add_argument("--content", required=True, help="Memory content")
    store_p.add_argument("--summary", default=None, help="Brief summary")
    store_p.add_argument("--category", default="general",
                         choices=["general", "decision", "experience", "bug_fix",
                                  "architecture", "coding_standard", "workflow"])
    store_p.add_argument("--tags", default="", help="Comma-separated tags")
    store_p.add_argument("--scope", default="private",
                         choices=["private", "project", "team"])
    store_p.set_defaults(func=cmd_store)

    # chat subcommand
    chat_p = subparsers.add_parser("chat", help="Upload a chat session")
    chat_p.add_argument("--file", required=True, help="Chat export file (or '-' for stdin)")
    chat_p.add_argument("--tool", required=True,
                        choices=["claude-code", "cursor", "opencode", "chatbox", "codex"])
    chat_p.add_argument("--project", default=None, help="Project ID")
    chat_p.set_defaults(func=cmd_chat)

    # propose subcommand
    propose_p = subparsers.add_parser("propose", help="Create a spec proposal")
    propose_p.add_argument("--title", required=True, help="Proposal title")
    propose_p.add_argument("--description", default=None, help="Proposal description")
    propose_p.add_argument("--spec", required=True, help="Target spec name")
    propose_p.add_argument("--delta", default=None, help="Delta file path")
    propose_p.set_defaults(func=cmd_propose)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
