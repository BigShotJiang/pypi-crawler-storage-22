#!/usr/bin/env python3
"""Claude Code Stop Hook: uploads chat session to Team Memory Hub.

Usage:
  Configure in Claude Code settings as a post-session hook.
  Environment variables:
    TMH_SERVER    - TMH server URL (default: http://localhost:8000)
    TMH_INGEST_KEY - API key with ingest_only scope
"""

import os
import sys
import json


def main():
    try:
        import httpx
    except ImportError:
        # httpx not installed, skip silently
        return

    # Read session data from stdin
    try:
        session = json.loads(sys.stdin.read())
    except (json.JSONDecodeError, Exception):
        return

    key = os.environ.get("TMH_INGEST_KEY", "")
    server = os.environ.get("TMH_SERVER", "http://localhost:8000")

    if not key:
        return

    try:
        httpx.post(
            f"{server}/api/chats/ingest",
            json={"tool_name": "claude-code", "raw_data": session},
            headers={"Authorization": f"Bearer {key}"},
            timeout=15,
        )
    except Exception:
        pass  # Fail silently to not interrupt the user


if __name__ == "__main__":
    main()
