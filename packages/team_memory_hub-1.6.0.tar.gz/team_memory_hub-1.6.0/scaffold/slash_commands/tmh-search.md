# /tmh-search

Search team memories via TMH MCP server.

## Usage

```
/tmh-search <query>
```

## Description

Searches the Team Memory Hub for relevant memories matching your query.
Returns summaries of matching memories with their IDs for detailed lookup.

## MCP Tool

Uses the `search_memory` MCP tool to perform the search.
