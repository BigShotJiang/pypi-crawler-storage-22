# /tmh-store

Store a new memory to Team Memory Hub.

## Usage

```
/tmh-store <content>
```

## Description

Stores a new memory to the Team Memory Hub. The memory will be stored
with private scope by default. Use tags and categories for organization.

## MCP Tool

Uses the `store_memory` MCP tool (requires write tools enabled).
