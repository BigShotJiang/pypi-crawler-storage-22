"""Team Memory Hub - AI 上下文记忆管理与分发系统。"""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("team-memory-hub")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"
