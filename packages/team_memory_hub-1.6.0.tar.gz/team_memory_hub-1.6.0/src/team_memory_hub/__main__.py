"""允许 python -m team_memory_hub 启动服务。"""

from __future__ import annotations

import argparse
import logging
import sys


def main() -> None:
    parser = argparse.ArgumentParser(description="Team Memory Hub Server")
    parser.add_argument("--host", default=None, help="绑定地址 (默认: 配置文件或 0.0.0.0)")
    parser.add_argument("--port", type=int, default=None, help="监听端口 (默认: 配置文件或 8000)")
    parser.add_argument("--reload", action="store_true", help="开发模式热重载")
    parser.add_argument("--config", default=None, help="配置文件路径 (默认: tmh.toml)")
    parser.add_argument("--log-level", default=None, help="日志级别 (DEBUG/INFO/WARNING/ERROR)")
    args = parser.parse_args()

    from team_memory_hub.config import load_config, set_config

    config = load_config(config_path=args.config)
    set_config(config)

    host = args.host or config.server.host
    port = args.port or config.server.port
    log_level = (args.log_level or config.logging.level).lower()

    logging.basicConfig(
        level=getattr(logging, log_level.upper(), logging.INFO),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    try:
        import uvicorn
    except ImportError:
        print("错误: 缺少 uvicorn 依赖。请执行: pip install uvicorn", file=sys.stderr)
        sys.exit(1)

    uvicorn.run(
        "team_memory_hub.server.app:app",
        host=host,
        port=port,
        reload=args.reload,
        log_level=log_level,
    )


if __name__ == "__main__":
    main()
