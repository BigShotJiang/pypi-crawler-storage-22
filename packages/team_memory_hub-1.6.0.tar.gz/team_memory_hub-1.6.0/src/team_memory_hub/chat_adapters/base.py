"""聊天适配器抽象基类。

Each adapter converts raw chat data from a specific AI tool into
a standard list of ChatMessage objects.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class ChatMessage:
    """聊天会话中的单个消息。"""

    role: str  # "user" or "assistant"
    content: str
    timestamp: datetime | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class ChatAdapter(ABC):
    """聊天适配器的抽象基类。

    Each adapter knows how to parse the raw data format of a specific
    AI coding tool and convert it to a list of ChatMessage objects.
    """

    tool_name: str = ""

    @abstractmethod
    def convert(self, raw_data: dict) -> list[ChatMessage]:
        """将原始聊天数据转换为 ChatMessage 对象列表。

        Args:
            raw_data: 工具特定的原始聊天会话数据。

        Returns:
            归一化 ChatMessage 对象的列表。
        """
        ...

    def get_session_metadata(self, raw_data: dict) -> dict[str, Any]:
        """从原始数据中提取会话级元数据。

        在子类中覆盖以获取工具特定的元数据。
        """
        return {
            "tool": self.tool_name,
        }
