"""Chatbox adapter.

解析 Chatbox AI 桌面应用聊天导出数据。
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from team_memory_hub.chat_adapters.base import ChatAdapter, ChatMessage


class ChatboxAdapter(ChatAdapter):
    """Chatbox AI 聊天会话数据的适配器。"""

    tool_name = "chatbox"

    def convert(self, raw_data: dict) -> list[ChatMessage]:
        """将 Chatbox 会话数据转换为 ChatMessage 列表。

        预期格式：
        {
            "messages": [
                {"role": "user", "content": "...", "createdAt": 1234567890},
                {"role": "assistant", "content": "...", "createdAt": 1234567890},
            ],
            ...
        }
        """
        messages: list[ChatMessage] = []

        for msg in raw_data.get("messages", []):
            content = msg.get("content", "")
            if not content:
                continue

            ts = None
            created_at = msg.get("createdAt", msg.get("created_at"))
            if created_at:
                try:
                    if isinstance(created_at, (int, float)):
                        ts = datetime.fromtimestamp(
                            created_at / 1000 if created_at > 1e12 else created_at
                        )
                    elif isinstance(created_at, str):
                        ts = datetime.fromisoformat(created_at)
                except (ValueError, OSError):
                    pass

            messages.append(ChatMessage(
                role=msg.get("role", "user"),
                content=content if isinstance(content, str) else str(content),
                timestamp=ts,
                metadata={},
            ))

        return messages

    def get_session_metadata(self, raw_data: dict) -> dict[str, Any]:
        return {
            "tool": self.tool_name,
            "model": raw_data.get("model", ""),
            "title": raw_data.get("title", ""),
        }
