"""Claude Code 聊天适配器。

解析 Claude Code 会话数据（来自停止钩子或手动导出）。
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from team_memory_hub.chat_adapters.base import ChatAdapter, ChatMessage


class ClaudeCodeAdapter(ChatAdapter):
    """Claude Code 聊天会话数据的适配器。"""

    tool_name = "claude-code"

    def convert(self, raw_data: dict) -> list[ChatMessage]:
        """将 Claude Code 会话数据转换为 ChatMessage 列表。

        预期格式：
        {
            "messages": [
                {"role": "user", "content": "...", "timestamp": "..."},
                {"role": "assistant", "content": "...", "timestamp": "..."},
            ],
            "session_id": "...",
            "model": "...",
            ...
        }
        """
        messages: list[ChatMessage] = []

        for msg in raw_data.get("messages", []):
            content = self._extract_content(msg.get("content", ""))
            if not content:
                continue

            ts = None
            if msg.get("timestamp"):
                try:
                    ts = datetime.fromisoformat(msg["timestamp"])
                except (ValueError, TypeError):
                    pass

            messages.append(ChatMessage(
                role=msg.get("role", "user"),
                content=content,
                timestamp=ts,
                metadata={
                    "model": raw_data.get("model", ""),
                    "session_id": raw_data.get("session_id", ""),
                },
            ))

        return messages

    def get_session_metadata(self, raw_data: dict) -> dict[str, Any]:
        return {
            "tool": self.tool_name,
            "model": raw_data.get("model", ""),
            "session_id": raw_data.get("session_id", ""),
            "project": raw_data.get("project", ""),
            "cwd": raw_data.get("cwd", ""),
        }

    @staticmethod
    def _extract_content(content: Any) -> str:
        """Extract text content from various formats."""
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            # Content blocks format: [{"type": "text", "text": "..."}, ...]
            parts = []
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    parts.append(block.get("text", ""))
                elif isinstance(block, str):
                    parts.append(block)
            return "\n".join(parts)
        return str(content) if content else ""
