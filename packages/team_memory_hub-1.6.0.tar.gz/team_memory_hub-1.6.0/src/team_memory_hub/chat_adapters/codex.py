"""Codex (OpenAI) chat adapter.

解析 OpenAI Codex / ChatGPT 会话数据。
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from team_memory_hub.chat_adapters.base import ChatAdapter, ChatMessage


class CodexAdapter(ChatAdapter):
    """OpenAI Codex / ChatGPT 聊天会话数据的适配器。"""

    tool_name = "codex"

    def convert(self, raw_data: dict) -> list[ChatMessage]:
        """将 Codex/ChatGPT 会话数据转换为 ChatMessage 列表。

        Expected format (OpenAI API style):
        {
            "messages": [
                {"role": "user", "content": "..."},
                {"role": "assistant", "content": "..."},
            ],
            "model": "...",
        }
        或对话导出：
        {
            "mapping": {
                "node_id": {
                    "message": {"author": {"role": "..."}, "content": {"parts": ["..."]}},
                    ...
                }
            }
        }
        """
        messages: list[ChatMessage] = []

        # 首先尝试标准格式
        if "messages" in raw_data:
            for msg in raw_data["messages"]:
                content = self._extract_content(msg.get("content", ""))
                if not content:
                    continue
                messages.append(ChatMessage(
                    role=msg.get("role", "user"),
                    content=content,
                    timestamp=self._parse_timestamp(msg.get("timestamp")),
                    metadata={"model": raw_data.get("model", "")},
                ))
            return messages

        # 尝试带有映射的 ChatGPT 导出格式
        if "mapping" in raw_data:
            mapping = raw_data["mapping"]
            for node_id, node in mapping.items():
                msg_data = node.get("message")
                if not msg_data:
                    continue

                author = msg_data.get("author", {})
                role = author.get("role", "user")
                if role == "system":
                    continue

                content_data = msg_data.get("content", {})
                parts = content_data.get("parts", [])
                content = "\n".join(str(p) for p in parts if p)
                if not content:
                    continue

                ts = self._parse_timestamp(msg_data.get("create_time"))

                messages.append(ChatMessage(
                    role="assistant" if role == "assistant" else "user",
                    content=content,
                    timestamp=ts,
                    metadata={"model": msg_data.get("metadata", {}).get("model_slug", "")},
                ))

        return messages

    def get_session_metadata(self, raw_data: dict) -> dict[str, Any]:
        return {
            "tool": self.tool_name,
            "model": raw_data.get("model", ""),
            "title": raw_data.get("title", ""),
        }

    @staticmethod
    def _extract_content(content: Any) -> str:
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            return "\n".join(str(p) for p in content if p)
        return str(content) if content else ""

    @staticmethod
    def _parse_timestamp(ts: Any) -> datetime | None:
        if ts is None:
            return None
        if isinstance(ts, (int, float)):
            try:
                return datetime.fromtimestamp(ts)
            except (ValueError, OSError):
                return None
        if isinstance(ts, str):
            try:
                return datetime.fromisoformat(ts)
            except ValueError:
                return None
        return None
