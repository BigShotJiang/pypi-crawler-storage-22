"""Cursor 聊天适配器。

解析 Cursor AI 聊天导出数据。
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from team_memory_hub.chat_adapters.base import ChatAdapter, ChatMessage


class CursorAdapter(ChatAdapter):
    """Cursor AI 聊天会话数据的适配器。"""

    tool_name = "cursor"

    def convert(self, raw_data: dict) -> list[ChatMessage]:
        """将 Cursor 聊天数据转换为 ChatMessage 列表。

        预期格式：
        {
            "conversation": [
                {"type": "human", "text": "...", "timestamp": ...},
                {"type": "ai", "text": "...", "timestamp": ...},
            ],
            ...
        }
        """
        messages: list[ChatMessage] = []

        for msg in raw_data.get("conversation", raw_data.get("messages", [])):
            role = self._normalize_role(msg.get("type", msg.get("role", "user")))
            content = msg.get("text", msg.get("content", ""))
            if not content:
                continue

            ts = self._parse_timestamp(msg.get("timestamp"))

            messages.append(ChatMessage(
                role=role,
                content=content if isinstance(content, str) else str(content),
                timestamp=ts,
                metadata={
                    "model": raw_data.get("model", ""),
                },
            ))

        return messages

    def get_session_metadata(self, raw_data: dict) -> dict[str, Any]:
        return {
            "tool": self.tool_name,
            "model": raw_data.get("model", ""),
            "workspace": raw_data.get("workspace", ""),
        }

    @staticmethod
    def _normalize_role(role: str) -> str:
        role_lower = role.lower()
        if role_lower in ("human", "user"):
            return "user"
        if role_lower in ("ai", "assistant", "bot"):
            return "assistant"
        return role_lower

    @staticmethod
    def _parse_timestamp(ts: Any) -> datetime | None:
        if ts is None:
            return None
        if isinstance(ts, (int, float)):
            try:
                return datetime.fromtimestamp(ts / 1000 if ts > 1e12 else ts)
            except (ValueError, OSError):
                return None
        if isinstance(ts, str):
            try:
                return datetime.fromisoformat(ts)
            except ValueError:
                return None
        return None
