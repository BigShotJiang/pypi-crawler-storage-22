"""OpenCode 聊天适配器。

解析 OpenCode 聊天会话数据。
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from team_memory_hub.chat_adapters.base import ChatAdapter, ChatMessage


class OpenCodeAdapter(ChatAdapter):
    """OpenCode 聊天会话数据的适配器。"""

    tool_name = "opencode"

    def convert(self, raw_data: dict) -> list[ChatMessage]:
        """将 OpenCode 会话数据转换为 ChatMessage 列表。

        预期格式：
        {
            "messages": [
                {"role": "user", "content": "...", "created_at": "..."},
                {"role": "assistant", "content": "...", "created_at": "..."},
            ],
            "session": {...},
        }
        """
        messages: list[ChatMessage] = []

        for msg in raw_data.get("messages", []):
            content = msg.get("content", "")
            if not content:
                continue

            ts = None
            for ts_field in ("created_at", "timestamp", "time"):
                if msg.get(ts_field):
                    try:
                        ts = datetime.fromisoformat(msg[ts_field])
                        break
                    except (ValueError, TypeError):
                        pass

            messages.append(ChatMessage(
                role=msg.get("role", "user"),
                content=content if isinstance(content, str) else str(content),
                timestamp=ts,
                metadata={
                    "model": msg.get("model", raw_data.get("model", "")),
                },
            ))

        return messages

    def get_session_metadata(self, raw_data: dict) -> dict[str, Any]:
        session = raw_data.get("session", {})
        return {
            "tool": self.tool_name,
            "model": raw_data.get("model", ""),
            "session_id": session.get("id", ""),
            "project": session.get("project", ""),
        }
