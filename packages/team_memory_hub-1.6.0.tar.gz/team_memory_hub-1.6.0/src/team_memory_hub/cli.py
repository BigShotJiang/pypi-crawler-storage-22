"""TMH CLI: Command-line interface for Team Memory Hub.

Usage:
  tmh init [--tool <tool>] [--server <url>]
  tmh sync [--quiet]
  tmh store --content <text> [--category <cat>] [--tags <tags>] [--scope <scope>]
  tmh search <query> [--category <cat>] [--limit <n>]
  tmh detail <memory_id>
  tmh ingest --file <path> --tool <tool>
  tmh prefs [get|set|list|team-set|team-list|suggestions]
  tmh specs [detect|normalize|compare|match]
  tmh consolidation [scan|list|accept|reject]
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from pathlib import Path


API_PREFIX = "/api/v1"


def get_server_url() -> str:
    return os.environ.get("TMH_SERVER", "http://localhost:8000")


def get_api_key() -> str:
    return os.environ.get("TMH_INGEST_KEY", os.environ.get("TMH_API_KEY", ""))


def get_headers() -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    key = get_api_key()
    if key:
        headers["Authorization"] = f"Bearer {key}"
    return headers


def _get_client():
    import httpx
    return httpx.Client(
        base_url=get_server_url(),
        headers=get_headers(),
        timeout=30,
    )


# ========== tmh init ==========

def cmd_init(args):
    """Initialize TMH integration in a project directory."""
    project_root = args.directory or os.getcwd()

    # Detect project
    from team_memory_hub.core.project_detector import ProjectDetector
    detector = ProjectDetector(project_root)
    profile = detector.detect()

    print(f"Detected project: {profile.name}")
    print(f"  Languages: {', '.join(profile.languages) or 'none detected'}")
    print(f"  Frameworks: {', '.join(profile.frameworks) or 'none detected'}")
    print(f"  Package managers: {', '.join(profile.package_managers) or 'none detected'}")

    # Create .tmh directory
    tmh_dir = Path(project_root) / ".tmh"
    tmh_dir.mkdir(parents=True, exist_ok=True)

    # Save project profile
    profile_path = tmh_dir / "project_profile.json"
    profile_path.write_text(
        json.dumps(profile.to_dict(), indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    # Configure tool if specified
    if args.tool:
        from team_memory_hub.client_adapters.base import get_client_adapter
        adapter = get_client_adapter(args.tool)
        config = adapter.generate_config(
            project_root=project_root,
            server_url=args.server or get_server_url(),
            api_key=get_api_key(),
        )
        written = adapter.apply(config, project_root)
        for f in written:
            print(f"  Created: {f}")
        for instruction in config.instructions:
            print(f"  Note: {instruction}")

    # Save TMH config
    tmh_config = {
        "server": args.server or get_server_url(),
        "project_name": profile.name,
        "tools": [args.tool] if args.tool else [],
    }
    config_path = tmh_dir / "config.json"
    config_path.write_text(
        json.dumps(tmh_config, indent=2) + "\n",
        encoding="utf-8",
    )

    print(f"\nTMH initialized in {project_root}")
    print(f"  Config: {config_path}")


# ========== tmh sync ==========

def cmd_sync(args):
    """Sync team context from TMH server."""

    async def _sync():
        from team_memory_hub.core.context_syncer import ContextSyncer
        syncer = ContextSyncer(
            project_root=args.directory or os.getcwd(),
            server_url=args.server or get_server_url(),
            api_key=get_api_key(),
        )
        result = await syncer.sync()

        if not args.quiet:
            if result.specs_updated:
                print(f"Specs updated to version {result.new_version}")
            if result.memories_synced:
                print(f"Synced {result.memories_synced} memories")
            if result.agents_md_updated:
                print("AGENTS.md updated")
            if result.errors:
                for err in result.errors:
                    print(f"Error: {err}", file=sys.stderr)

    asyncio.run(_sync())


# ========== tmh store ==========

def cmd_store(args):
    """Store a new memory."""
    client = _get_client()

    tags = [t.strip() for t in args.tags.split(",")] if args.tags else []

    # Read content from file or argument
    content = args.content
    if content == "-":
        content = sys.stdin.read()

    payload = {
        "content": content,
        "summary": args.summary,
        "category": args.category,
        "tags": tags,
        "scope": args.scope,
    }

    resp = client.post(f"{API_PREFIX}/memories", json=payload)
    if resp.status_code == 201:
        data = resp.json()
        print(f"Memory stored: {data.get('id')}")
        print(f"  Summary: {data.get('summary', '')[:100]}")
    else:
        print(f"Error: {resp.status_code} - {resp.text}", file=sys.stderr)
        sys.exit(1)


# ========== tmh search ==========

def cmd_search(args):
    """Search memories."""
    client = _get_client()

    params = {"page_size": args.limit}
    # Use keyword filter through category or general listing
    if args.category:
        params["category"] = args.category

    resp = client.get(f"{API_PREFIX}/memories", params=params)
    if resp.status_code == 200:
        data = resp.json()
        items = data.get("items", [])

        # Client-side filter by query
        query_lower = args.query.lower()
        filtered = [
            item for item in items
            if query_lower in item.get("summary", "").lower()
            or query_lower in json.dumps(item.get("tags", [])).lower()
        ]

        if not filtered:
            print("No matching memories found.")
            return

        for item in filtered:
            mid = item.get("id", "")
            summary = item.get("summary", "")
            category = item.get("category", "")
            quality = item.get("quality", "")
            print(f"  [{mid}] ({category}/{quality}) {summary}")

        print(f"\n{len(filtered)} result(s)")
    else:
        print(f"Error: {resp.status_code} - {resp.text}", file=sys.stderr)
        sys.exit(1)


# ========== tmh detail ==========

def cmd_detail(args):
    """Get memory detail."""
    client = _get_client()

    resp = client.get(f"{API_PREFIX}/memories/{args.memory_id}/detail")
    if resp.status_code == 200:
        data = resp.json()
        print(f"ID:       {data.get('id')}")
        print(f"Summary:  {data.get('summary')}")
        print(f"类别: {data.get('category')}")
        print(f"范围:    {data.get('scope')}")
        print(f"质量:  {data.get('quality')}")
        print(f"Tags:     {', '.join(data.get('tags', []))}")
        print(f"Created:  {data.get('created_at')}")
        print(f"Updated:  {data.get('updated_at')}")
        print(f"\n--- Content ---\n")
        print(data.get("content", ""))
    else:
        print(f"Error: {resp.status_code} - {resp.text}", file=sys.stderr)
        sys.exit(1)


# ========== tmh ingest ==========

def cmd_ingest(args):
    """Ingest a chat session file."""
    client = _get_client()

    if args.file == "-":
        raw_data = json.loads(sys.stdin.read())
    else:
        with open(args.file, "r", encoding="utf-8") as f:
            raw_data = json.load(f)

    payload = {
        "tool_name": args.tool,
        "raw_data": raw_data,
        "project_id": args.project,
    }

    resp = client.post(f"{API_PREFIX}/chats/ingest", json=payload)
    if resp.status_code == 200:
        data = resp.json()
        print(f"Session ingested: {data.get('session_id')}")
        print(f"  Turns: {data.get('turn_count')}")
        print(f"  状态: {data.get('status')}")
    else:
        print(f"Error: {resp.status_code} - {resp.text}", file=sys.stderr)
        sys.exit(1)


# ========== tmh prefs ==========

def cmd_prefs(args):
    """Manage preferences."""
    client = _get_client()

    if args.action == "list":
        params = {}
        if args.category:
            params["category"] = args.category
        resp = client.get(f"{API_PREFIX}/preferences/user", params=params)
        if resp.status_code == 200:
            items = resp.json().get("items", [])
            for p in items:
                print(f"  [{p.get('category')}] {p.get('key')} = {p.get('value')}")
        else:
            print(f"Error: {resp.status_code}", file=sys.stderr)

    elif args.action == "set":
        if not args.key or not args.value:
            print("Error: --key and --value required", file=sys.stderr)
            sys.exit(1)
        resp = client.post(f"{API_PREFIX}/preferences/user", json={
            "category": args.category or "general",
            "key": args.key,
            "value": args.value,
            "scope": args.scope or "global",
        })
        if resp.status_code == 201:
            print(f"Preference set: {args.key} = {args.value}")
        else:
            print(f"Error: {resp.status_code}", file=sys.stderr)

    elif args.action == "get":
        resp = client.get(f"{API_PREFIX}/preferences/effective", params={
            "category": args.category,
        })
        if resp.status_code == 200:
            prefs = resp.json().get("preferences", {})
            for key, info in prefs.items():
                if isinstance(info, dict):
                    print(f"  {key} = {info.get('value')} (source: {info.get('source')})")
                else:
                    print(f"  {key} = {info}")
        else:
            print(f"Error: {resp.status_code}", file=sys.stderr)

    elif args.action == "team-list":
        resp = client.get(f"{API_PREFIX}/preferences/team")
        if resp.status_code == 200:
            items = resp.json().get("items", [])
            for p in items:
                print(f"  [{p.get('category')}] {p.get('key')} = {p.get('value')}")
        else:
            print(f"Error: {resp.status_code}", file=sys.stderr)

    elif args.action == "team-set":
        if not args.key or not args.value:
            print("Error: --key and --value required", file=sys.stderr)
            sys.exit(1)
        resp = client.post(f"{API_PREFIX}/preferences/team", json={
            "category": args.category or "general",
            "key": args.key,
            "value": args.value,
        })
        if resp.status_code == 201:
            print(f"Team default set: {args.key} = {args.value}")
        else:
            print(f"Error: {resp.status_code}", file=sys.stderr)

    elif args.action == "suggestions":
        resp = client.get(f"{API_PREFIX}/preferences/suggestions")
        if resp.status_code == 200:
            items = resp.json().get("items", [])
            if not items:
                print("No pending suggestions.")
            for s in items:
                print(f"  [{s.get('id')}] {s.get('category')}/{s.get('key')} = {s.get('value')}")
                if s.get("evidence"):
                    print(f"    Evidence: {s.get('evidence')[:100]}")
        else:
            print(f"Error: {resp.status_code}", file=sys.stderr)


# ========== tmh specs ==========

def cmd_specs(args):
    """Manage specs and rules."""
    project_root = args.directory or os.getcwd()

    if args.action == "detect":
        from team_memory_hub.core.project_detector import ProjectDetector
        detector = ProjectDetector(project_root)
        profile = detector.detect()
        print(json.dumps(profile.to_dict(), indent=2, ensure_ascii=False))

    elif args.action == "normalize":
        from team_memory_hub.core.rule_normalizer import RuleNormalizer
        normalizer = RuleNormalizer(project_root)
        rules = normalizer.normalize_all()
        for rule in rules:
            print(f"  [{rule.source}] {rule.key} = {rule.value} ({rule.file_pattern})")

    elif args.action == "compare":
        from team_memory_hub.core.rule_normalizer import RuleNormalizer
        from team_memory_hub.core.spec_deduplicator import SpecDeduplicator

        normalizer = RuleNormalizer(project_root)
        project_rules = normalizer.normalize_all()

        # TMH rules would be loaded from server; for now show project rules
        dedup = SpecDeduplicator()
        result = dedup.compare([], project_rules)

        print(f"Summary: {result.summary()}")
        if result.project_only:
            print("\nProject-only rules:")
            for comp in result.project_only:
                rule = comp.project_rule
                if rule:
                    print(f"  [{rule.source}] {rule.key} = {rule.value}")

    elif args.action == "match":
        from team_memory_hub.core.project_detector import ProjectDetector
        from team_memory_hub.core.spec_matcher import SpecMatcher

        detector = ProjectDetector(project_root)
        profile = detector.detect()

        print(f"Project: {profile.name}")
        print(f"Languages: {', '.join(profile.languages)}")
        print(f"Frameworks: {', '.join(profile.frameworks)}")


# ========== tmh consolidation ==========

def cmd_consolidation(args):
    """Manage memory consolidation."""
    client = _get_client()

    if args.action == "scan":
        resp = client.post(f"{API_PREFIX}/consolidation/scan")
        if resp.status_code == 200:
            data = resp.json()
            print(f"Scan complete: {data.get('suggestions_created', 0)} suggestions")
        else:
            print(f"Error: {resp.status_code}", file=sys.stderr)

    elif args.action == "list":
        resp = client.get(f"{API_PREFIX}/consolidation/suggestions")
        if resp.status_code == 200:
            items = resp.json().get("items", [])
            for s in items:
                print(f"  [{s.get('id')}] {s.get('status')} - similarity: {s.get('avg_similarity', 0):.2f}")
                ids = s.get("original_ids", [])
                print(f"    Merges: {', '.join(ids)}")
        else:
            print(f"Error: {resp.status_code}", file=sys.stderr)

    elif args.action in ("accept", "reject"):
        if not args.suggestion_id:
            print("Error: --id required", file=sys.stderr)
            sys.exit(1)
        resp = client.post(f"{API_PREFIX}/consolidation/suggestions/{args.suggestion_id}/{args.action}")
        if resp.status_code == 200:
            print(f"Suggestion {args.action}ed: {args.suggestion_id}")
        else:
            print(f"Error: {resp.status_code}", file=sys.stderr)


# ========== Main ==========

def main():
    parser = argparse.ArgumentParser(
        prog="tmh",
        description="Team Memory Hub CLI",
    )
    parser.add_argument("--server", help="TMH server URL")
    subparsers = parser.add_subparsers(dest="command")

    # init
    init_p = subparsers.add_parser("init", help="Initialize TMH in a project")
    init_p.add_argument("--tool", choices=["claude-code", "cursor", "opencode", "codex"],
                        help="Configure for a specific tool")
    init_p.add_argument("--server", dest="server", help="TMH server URL")
    init_p.add_argument("--directory", "-d", default=None, help="Project directory")
    init_p.set_defaults(func=cmd_init)

    # sync
    sync_p = subparsers.add_parser("sync", help="Sync team context")
    sync_p.add_argument("--quiet", "-q", action="store_true")
    sync_p.add_argument("--server", dest="server", help="TMH server URL")
    sync_p.add_argument("--directory", "-d", default=None, help="Project directory")
    sync_p.set_defaults(func=cmd_sync)

    # store
    store_p = subparsers.add_parser("store", help="Store a memory")
    store_p.add_argument("--content", required=True, help="Content (or '-' for stdin)")
    store_p.add_argument("--summary", default=None)
    store_p.add_argument("--category", default="general",
                         choices=["general", "decision", "experience", "bug_fix",
                                  "architecture", "coding_standard", "workflow"])
    store_p.add_argument("--tags", default="")
    store_p.add_argument("--scope", default="private", choices=["private", "project", "team"])
    store_p.set_defaults(func=cmd_store)

    # search
    search_p = subparsers.add_parser("search", help="Search memories")
    search_p.add_argument("query", help="搜索查询")
    search_p.add_argument("--category", default=None)
    search_p.add_argument("--limit", type=int, default=20)
    search_p.set_defaults(func=cmd_search)

    # detail
    detail_p = subparsers.add_parser("detail", help="Get memory detail")
    detail_p.add_argument("memory_id", help="Memory ID")
    detail_p.set_defaults(func=cmd_detail)

    # ingest
    ingest_p = subparsers.add_parser("ingest", help="Ingest a chat session")
    ingest_p.add_argument("--file", required=True, help="Chat file (or '-' for stdin)")
    ingest_p.add_argument("--tool", required=True,
                          choices=["claude-code", "cursor", "opencode", "chatbox", "codex"])
    ingest_p.add_argument("--project", default=None, help="Project ID")
    ingest_p.set_defaults(func=cmd_ingest)

    # prefs
    prefs_p = subparsers.add_parser("prefs", help="Manage preferences")
    prefs_p.add_argument("action",
                         choices=["get", "set", "list", "team-set", "team-list", "suggestions"])
    prefs_p.add_argument("--category", default=None)
    prefs_p.add_argument("--key", default=None)
    prefs_p.add_argument("--value", default=None)
    prefs_p.add_argument("--scope", default="global")
    prefs_p.set_defaults(func=cmd_prefs)

    # specs
    specs_p = subparsers.add_parser("specs", help="Manage specs and rules")
    specs_p.add_argument("action", choices=["detect", "normalize", "compare", "match"])
    specs_p.add_argument("--directory", "-d", default=None, help="Project directory")
    specs_p.set_defaults(func=cmd_specs)

    # consolidation
    consol_p = subparsers.add_parser("consolidation", help="Memory consolidation")
    consol_p.add_argument("action", choices=["scan", "list", "accept", "reject"])
    consol_p.add_argument("--id", dest="suggestion_id", default=None)
    consol_p.set_defaults(func=cmd_consolidation)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
