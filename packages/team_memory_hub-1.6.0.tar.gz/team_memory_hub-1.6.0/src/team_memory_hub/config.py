"""配置加载：TOML 文件带环境变量覆盖。"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import tomllib
except ImportError:
    import tomli as tomllib  # type: ignore[no-redef]


@dataclass
class ServerConfig:
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = False
    data_dir: str = "./data"
    cors_origins: list[str] = field(default_factory=lambda: ["http://localhost:3000"])


@dataclass
class AuthConfig:
    jwt_secret: str = "CHANGE-ME-IN-PRODUCTION"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 15
    refresh_token_expire_days: int = 30


@dataclass
class DatabaseConfig:
    path: str = "./data/team_memory.db"
    wal_mode: bool = True
    busy_timeout_ms: int = 10000


@dataclass
class StorageConfig:
    memories_dir: str = "./data/memories"
    specs_dir: str = "./data/specs"
    chats_dir: str = "./data/chats"


@dataclass
class WriteQueueConfig:
    batch_timeout_ms: int = 100
    batch_max_size: int = 50


@dataclass
class SearchConfig:
    engine: str = "hybrid"
    semantic_weight: float = 0.7
    keyword_weight: float = 0.3
    candidate_multiplier: int = 3
    score_normalization: str = "min_max"


@dataclass
class EmbeddingConfig:
    provider: str = "openai_compatible"
    dimensions: int = 384
    base_url: str = "http://localhost:11434"
    model: str = "nomic-embed-text"
    api_key: str = ""


@dataclass
class ConsolidationConfig:
    enabled: bool = True
    scan_schedule: str = "0 4 * * *"
    scan_days: int = 30
    cluster_threshold: float = 0.85
    max_suggestions_per_scan: int = 20
    auto_private: bool = False
    suggestion_retention_days: int = 30


@dataclass
class MCPConfig:
    tool_set: str = "read_only"  # read_only | read_write | full_crud
    max_results: int = 50


@dataclass
class LoggingConfig:
    level: str = "INFO"
    format: str = "json"


@dataclass
class TMHConfig:
    server: ServerConfig = field(default_factory=ServerConfig)
    auth: AuthConfig = field(default_factory=AuthConfig)
    database: DatabaseConfig = field(default_factory=DatabaseConfig)
    storage: StorageConfig = field(default_factory=StorageConfig)
    write_queue: WriteQueueConfig = field(default_factory=WriteQueueConfig)
    search: SearchConfig = field(default_factory=SearchConfig)
    embedding: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    consolidation: ConsolidationConfig = field(default_factory=ConsolidationConfig)
    mcp: MCPConfig = field(default_factory=MCPConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)


# 环境变量映射：ENV_VAR -> (section, key)
_ENV_MAP: dict[str, tuple[str, str]] = {
    "TMH_SERVER_HOST": ("server", "host"),
    "TMH_SERVER_PORT": ("server", "port"),
    "TMH_SERVER_DEBUG": ("server", "debug"),
    "TMH_DATA_DIR": ("server", "data_dir"),
    "TMH_JWT_SECRET": ("auth", "jwt_secret"),
    "TMH_JWT_ALGORITHM": ("auth", "jwt_algorithm"),
    "TMH_ACCESS_TOKEN_EXPIRE_MINUTES": ("auth", "access_token_expire_minutes"),
    "TMH_REFRESH_TOKEN_EXPIRE_DAYS": ("auth", "refresh_token_expire_days"),
    "TMH_DATABASE_PATH": ("database", "path"),
    "TMH_EMBEDDING_PROVIDER": ("embedding", "provider"),
    "TMH_EMBEDDING_BASE_URL": ("embedding", "base_url"),
    "TMH_EMBEDDING_MODEL": ("embedding", "model"),
    "TMH_EMBEDDING_API_KEY": ("embedding", "api_key"),
    "TMH_MCP_TOOL_SET": ("mcp", "tool_set"),
    "TMH_LOG_LEVEL": ("logging", "level"),
}


def _coerce_value(value: str, target_type: type) -> Any:
    """将字符串环境变量强制转换为目标字段类型。"""
    if target_type is bool:
        return value.lower() in ("true", "1", "yes")
    if target_type is int:
        return int(value)
    if target_type is float:
        return float(value)
    return value


def _apply_dict_to_dataclass(dc: Any, data: dict[str, Any]) -> None:
    """将字典值应用到数据类实例。"""
    for key, value in data.items():
        if hasattr(dc, key):
            current = getattr(dc, key)
            if isinstance(value, dict) and hasattr(current, "__dataclass_fields__"):
                _apply_dict_to_dataclass(current, value)
            else:
                setattr(dc, key, value)


def load_config(
    config_path: str | Path | None = None,
    env_prefix: str = "TMH_",
) -> TMHConfig:
    """从 TOML 文件加载配置，然后应用环境变量覆盖。

    优先级：环境变量 > TOML 文件 > 默认值
    """
    config = TMHConfig()

    # 1. 如果可用，加载 TOML 文件
    if config_path is None:
        for candidate in ["tmh.toml", "tmh.toml.example"]:
            if Path(candidate).exists():
                config_path = candidate
                break

    if config_path and Path(config_path).exists():
        with open(config_path, "rb") as f:
            toml_data = tomllib.load(f)

        # 将 embedding.openai_compatible 展平到 embedding
        if "embedding" in toml_data:
            compat = toml_data["embedding"].pop("openai_compatible", {})
            toml_data["embedding"].update(compat)

        _apply_dict_to_dataclass(config, toml_data)

    # 2. 应用环境变量覆盖
    for env_var, (section, key) in _ENV_MAP.items():
        value = os.environ.get(env_var)
        if value is not None:
            section_obj = getattr(config, section)
            field_info = section_obj.__dataclass_fields__[key]
            coerced = _coerce_value(value, field_info.type)
            setattr(section_obj, key, coerced)

    return config


# 全局配置单例
_config: TMHConfig | None = None


def get_config() -> TMHConfig:
    """获取或创建全局配置。"""
    global _config
    if _config is None:
        _config = load_config()
    return _config


def set_config(config: TMHConfig) -> None:
    """设置全局配置（用于测试）。"""
    global _config
    _config = config
