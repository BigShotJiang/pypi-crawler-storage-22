"""审计日志：记录用户操作以用于合规和调试。"""

from __future__ import annotations

import logging
import secrets
import string
from datetime import datetime
from typing import Any

from team_memory_hub.storage.database import Database

logger = logging.getLogger(__name__)

_ID_CHARS = string.ascii_lowercase + string.digits


def _gen_id() -> str:
    return f"aud_{''.join(secrets.choice(_ID_CHARS) for _ in range(10))}"


class AuditLogger:
    """将结构化审计日志条目写入数据库。"""

    def __init__(self, db: Database) -> None:
        self.db = db

    async def log(
        self,
        user_id: str,
        action: str,
        target_type: str | None = None,
        target_id: str | None = None,
        details: str | None = None,
        ip_address: str | None = None,
    ) -> str:
        audit_id = _gen_id()
        await self.db.execute(
            """INSERT INTO audit_logs (id, user_id, action, target_type, target_id, details, ip_address)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (audit_id, user_id, action, target_type, target_id, details, ip_address),
        )
        await self.db.commit()
        return audit_id

    async def query(
        self,
        user_id: str | None = None,
        action: str | None = None,
        target_type: str | None = None,
        page: int = 1,
        page_size: int = 50,
    ) -> tuple[list[dict[str, Any]], int]:
        conditions = []
        params: list[Any] = []

        if user_id:
            conditions.append("user_id = ?")
            params.append(user_id)
        if action:
            conditions.append("action = ?")
            params.append(action)
        if target_type:
            conditions.append("target_type = ?")
            params.append(target_type)

        where = " AND ".join(conditions) if conditions else "1=1"

        count_row = await self.db.fetch_one(
            f"SELECT COUNT(*) as cnt FROM audit_logs WHERE {where}", tuple(params)
        )
        total = count_row["cnt"] if count_row else 0

        offset = (page - 1) * page_size
        rows = await self.db.fetch_all(
            f"""SELECT * FROM audit_logs WHERE {where}
                ORDER BY created_at DESC LIMIT ? OFFSET ?""",
            tuple(params + [page_size, offset]),
        )
        return rows, total

    async def clean_old(self, retention_days: int = 90) -> int:
        """删除超过 retention_days 的审计日志条目。"""
        cutoff = datetime.utcnow().isoformat()
        result = await self.db.execute(
            "DELETE FROM audit_logs WHERE created_at < datetime(?, ?)",
            (cutoff, f"-{retention_days} days"),
        )
        await self.db.commit()
        return result.rowcount
