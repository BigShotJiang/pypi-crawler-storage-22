"""聊天摄入：接收、存储和处理聊天会话。

处理管道：原始数据 -> 适配器 -> 存储 -> 提取。
"""

from __future__ import annotations

import json
import logging
import secrets
import string
from datetime import datetime
from pathlib import Path
from typing import Any

from team_memory_hub.chat_adapters.base import ChatAdapter, ChatMessage
from team_memory_hub.chat_adapters.claude_code import ClaudeCodeAdapter
from team_memory_hub.chat_adapters.cursor import CursorAdapter
from team_memory_hub.chat_adapters.opencode import OpenCodeAdapter
from team_memory_hub.chat_adapters.chatbox import ChatboxAdapter
from team_memory_hub.chat_adapters.codex import CodexAdapter
from team_memory_hub.storage.database import Database

logger = logging.getLogger(__name__)

_ID_CHARS = string.ascii_lowercase + string.digits

# Registry of adapters by tool name
_ADAPTERS: dict[str, type[ChatAdapter]] = {
    "claude-code": ClaudeCodeAdapter,
    "cursor": CursorAdapter,
    "opencode": OpenCodeAdapter,
    "chatbox": ChatboxAdapter,
    "codex": CodexAdapter,
}


def get_adapter(tool_name: str) -> ChatAdapter:
    """获取工具名称的适应适配器。"""
    adapter_cls = _ADAPTERS.get(tool_name)
    if adapter_cls is None:
        raise ValueError(f"Unknown tool: {tool_name}. Supported: {list(_ADAPTERS.keys())}")
    return adapter_cls()


def register_adapter(tool_name: str, adapter_cls: type[ChatAdapter]) -> None:
    """为工具名称注册新的适配器。"""
    _ADAPTERS[tool_name] = adapter_cls


class ChatIngestor:
    """摄入原始聊天数据，通过适配器转换，存储并触发提取。"""

    def __init__(self, db: Database, chats_dir: str):
        self.db = db
        self.chats_dir = Path(chats_dir)
        self.chats_dir.mkdir(parents=True, exist_ok=True)

    async def ingest(
        self,
        tool_name: str,
        raw_data: dict,
        user_id: str,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        """摄入聊天会话：转换、存储并返回会话信息。

        Returns:
            Dict with session_id, turn_count, file_path.
        """
        # Step 1: Get adapter and convert
        adapter = get_adapter(tool_name)
        messages = adapter.convert(raw_data)
        session_meta = adapter.get_session_metadata(raw_data)

        if not messages:
            return {"session_id": None, "turn_count": 0, "status": "empty"}

        # Step 2: Generate session ID and save raw data
        session_id = f"chat_{''.join(secrets.choice(_ID_CHARS) for _ in range(8))}"
        file_path = self._save_chat_file(session_id, tool_name, messages, raw_data)

        # Step 3: Compute timestamps
        started_at = None
        ended_at = None
        for msg in messages:
            if msg.timestamp:
                if started_at is None or msg.timestamp < started_at:
                    started_at = msg.timestamp
                if ended_at is None or msg.timestamp > ended_at:
                    ended_at = msg.timestamp

        now = datetime.utcnow()

        # Step 4: Store session record in database
        await self.db.execute(
            """INSERT INTO chat_sessions
               (id, user_id, tool, tool_version, project_id, file_path,
                turn_count, started_at, ended_at, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                session_id,
                user_id,
                tool_name,
                session_meta.get("model", ""),
                project_id,
                file_path,
                len(messages),
                started_at.isoformat() if started_at else now.isoformat(),
                ended_at.isoformat() if ended_at else now.isoformat(),
                now.isoformat(),
            ),
        )
        await self.db.commit()

        return {
            "session_id": session_id,
            "turn_count": len(messages),
            "file_path": file_path,
            "status": "ingested",
        }

    def _save_chat_file(
        self,
        session_id: str,
        tool_name: str,
        messages: list[ChatMessage],
        raw_data: dict,
    ) -> str:
        """Save chat data to a JSON file."""
        now = datetime.utcnow()
        dir_path = self.chats_dir / tool_name / str(now.year) / f"{now.month:02d}"
        dir_path.mkdir(parents=True, exist_ok=True)

        file_path = dir_path / f"{session_id}.json"
        chat_data = {
            "session_id": session_id,
            "tool": tool_name,
            "ingested_at": now.isoformat(),
            "messages": [
                {
                    "role": msg.role,
                    "content": msg.content,
                    "timestamp": msg.timestamp.isoformat() if msg.timestamp else None,
                    "metadata": msg.metadata,
                }
                for msg in messages
            ],
            "raw_metadata": {
                k: v for k, v in raw_data.items()
                if k != "messages" and k != "conversation" and k != "mapping"
            },
        }

        file_path.write_text(
            json.dumps(chat_data, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

        # Return relative path
        return str(file_path.relative_to(self.chats_dir))

    async def get_session(self, session_id: str) -> dict[str, Any] | None:
        """Get a chat session record from database."""
        return await self.db.fetch_one(
            "SELECT * FROM chat_sessions WHERE id = ?",
            (session_id,),
        )

    async def list_sessions(
        self,
        user_id: str,
        tool: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> tuple[list[dict[str, Any]], int]:
        """List chat sessions for a user with optional tool filter."""
        conditions = ["user_id = ?"]
        params: list[Any] = [user_id]

        if tool:
            conditions.append("tool = ?")
            params.append(tool)

        where = " AND ".join(conditions)

        count_row = await self.db.fetch_one(
            f"SELECT COUNT(*) as cnt FROM chat_sessions WHERE {where}",
            tuple(params),
        )
        total = count_row["cnt"] if count_row else 0

        offset = (page - 1) * page_size
        rows = await self.db.fetch_all(
            f"""SELECT * FROM chat_sessions WHERE {where}
                ORDER BY created_at DESC LIMIT ? OFFSET ?""",
            tuple(params + [page_size, offset]),
        )

        return rows, total

    def read_chat_file(self, file_path: str) -> dict[str, Any] | None:
        """Read a stored chat file."""
        full_path = self.chats_dir / file_path
        if not full_path.exists():
            return None
        try:
            return json.loads(full_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return None
