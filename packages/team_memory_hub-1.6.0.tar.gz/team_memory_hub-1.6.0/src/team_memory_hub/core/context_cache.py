"""In-memory context cache with TTL support.

Layer 0: cached 1 hour
Layer 1: cached 10 minutes
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any


@dataclass
class _CacheEntry:
    """A cached value with expiration."""
    data: Any
    expires_at: float


class ContextCache:
    """Simple in-memory TTL cache for context layers.

    Thread-safe enough for asyncio (single-threaded event loop).
    """

    def __init__(self, max_entries: int = 1000):
        self._store: dict[str, _CacheEntry] = {}
        self._max_entries = max_entries

    def get(self, key: str) -> Any | None:
        """Get a cached value, returning None if expired or missing."""
        entry = self._store.get(key)
        if entry is None:
            return None
        if time.monotonic() > entry.expires_at:
            del self._store[key]
            return None
        return entry.data

    def set(self, key: str, value: Any, ttl_seconds: int = 600) -> None:
        """Set a cache entry with TTL in seconds."""
        # Evict expired entries if we're at capacity
        if len(self._store) >= self._max_entries:
            self._evict_expired()

        # If still at capacity, evict oldest
        if len(self._store) >= self._max_entries:
            oldest_key = min(self._store, key=lambda k: self._store[k].expires_at)
            del self._store[oldest_key]

        self._store[key] = _CacheEntry(
            data=value,
            expires_at=time.monotonic() + ttl_seconds,
        )

    def invalidate(self, key: str) -> bool:
        """Remove a specific cache entry. Returns True if it existed."""
        return self._store.pop(key, None) is not None

    def invalidate_prefix(self, prefix: str) -> int:
        """Remove all cache entries whose key starts with prefix."""
        keys_to_remove = [k for k in self._store if k.startswith(prefix)]
        for k in keys_to_remove:
            del self._store[k]
        return len(keys_to_remove)

    def clear(self) -> None:
        """Clear all cache entries."""
        self._store.clear()

    def _evict_expired(self) -> None:
        """Remove all expired entries."""
        now = time.monotonic()
        expired = [k for k, v in self._store.items() if now > v.expires_at]
        for k in expired:
            del self._store[k]

    @property
    def size(self) -> int:
        """Current number of entries (including potentially expired)."""
        return len(self._store)
