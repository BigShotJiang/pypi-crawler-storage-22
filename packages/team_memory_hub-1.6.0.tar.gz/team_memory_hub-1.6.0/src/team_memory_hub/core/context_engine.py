"""上下文引擎：为 AI 代理消耗构建三层上下文。

第 0 层（固定）：团队范围标准、编码约定、固定决策
第 1 层（项目）：特定于项目的上下文、活跃决策、最近的模式
第 2 层（会话）：混合搜索中的查询时相关记忆
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from team_memory_hub.core.context_cache import ContextCache
from team_memory_hub.core.search_engine import HybridSearchEngine, SearchResult
from team_memory_hub.storage.database import Database

logger = logging.getLogger(__name__)


@dataclass
class ContextLayer:
    """上下文的单个层。"""
    name: str
    layer: int
    items: list[dict[str, Any]] = field(default_factory=list)
    token_estimate: int = 0


@dataclass
class ContextResponse:
    """包含所有层的完整上下文响应。"""
    layers: list[ContextLayer] = field(default_factory=list)
    total_token_estimate: int = 0
    cache_hit: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "layers": [
                {
                    "name": layer.name,
                    "layer": layer.layer,
                    "items": layer.items,
                    "token_estimate": layer.token_estimate,
                }
                for layer in self.layers
            ],
            "total_token_estimate": self.total_token_estimate,
            "cache_hit": self.cache_hit,
        }


class ContextEngine:
    """为 AI 代理构建三层上下文。

    从以下内容构建上下文窗口：
    - 第 0 层：固定/已验证的团队范围记忆 + 规范（缓存 1h）
    - 第 1 层：特定于项目的上下文（缓存 10 分钟）
    - 第 2 层：来自搜索的会话相关记忆（未缓存）
    """

    def __init__(
        self,
        db: Database,
        search_engine: HybridSearchEngine,
        cache: ContextCache | None = None,
    ):
        self.db = db
        self.search = search_engine
        self.cache = cache or ContextCache()

    async def build_context(
        self,
        team_id: str,
        user_id: str | None = None,
        project_id: str | None = None,
        query: str | None = None,
        max_tokens: int = 4000,
        include_layers: list[int] | None = None,
    ) -> ContextResponse:
        """构建用于 AI 消耗的多层上下文。

        Args:
            team_id: The team to build context for.
            user_id: Current user for private data isolation.
            project_id: Optional project context.
            query: Optional search query for Layer 2.
            max_tokens: Approximate token budget.
            include_layers: Which layers to include (default: all).

        Returns:
            具有分层上下文的 ContextResponse。
        """
        layers_to_include = include_layers or [0, 1, 2]
        response = ContextResponse()
        remaining_tokens = max_tokens

        # Layer 0: Pinned/Verified team context (cached 1h)
        if 0 in layers_to_include:
            layer0 = await self._build_layer0(team_id, remaining_tokens)
            response.layers.append(layer0)
            remaining_tokens -= layer0.token_estimate

        # Layer 1: Project context (cached 10min)
        if 1 in layers_to_include and project_id:
            layer1 = await self._build_layer1(
                team_id, project_id, user_id, remaining_tokens
            )
            response.layers.append(layer1)
            remaining_tokens -= layer1.token_estimate

        # Layer 2: Session/query context (not cached)
        if 2 in layers_to_include and query:
            layer2 = await self._build_layer2(
                query, team_id, user_id, project_id, remaining_tokens
            )
            response.layers.append(layer2)

        # Calculate total
        response.total_token_estimate = sum(
            l.token_estimate for l in response.layers
        )

        return response

    async def _build_layer0(self, team_id: str, budget: int) -> ContextLayer:
        """Layer 0: Pinned and verified team-wide memories."""
        cache_key = f"layer0:{team_id}"
        cached = self.cache.get(cache_key)
        if cached is not None:
            layer = ContextLayer(name="team_standards", layer=0, items=cached)
            layer.token_estimate = _estimate_tokens(cached)
            return layer

        rows = await self.db.fetch_all(
            """SELECT id, summary, category, tags, quality
               FROM memories
               WHERE team_id = ? AND quality IN ('pinned', 'verified')
               AND scope != 'private'
               ORDER BY
                   CASE quality WHEN 'pinned' THEN 0 ELSE 1 END,
                   updated_at DESC
               LIMIT 50""",
            (team_id,),
        )

        items = [_row_to_context_item(row) for row in rows]

        # Trim to budget
        items = _trim_to_budget(items, budget)

        self.cache.set(cache_key, items, ttl_seconds=3600)  # 1 hour

        layer = ContextLayer(name="team_standards", layer=0, items=items)
        layer.token_estimate = _estimate_tokens(items)
        return layer

    async def _build_layer1(
        self, team_id: str, project_id: str, user_id: str | None, budget: int
    ) -> ContextLayer:
        """Layer 1: Project-specific context."""
        cache_key = f"layer1:{team_id}:{project_id}"
        cached = self.cache.get(cache_key)
        if cached is not None:
            layer = ContextLayer(name="project_context", layer=1, items=cached)
            layer.token_estimate = _estimate_tokens(cached)
            return layer

        # Get project-scoped memories (recent and relevant)
        rows = await self.db.fetch_all(
            """SELECT id, summary, category, tags, quality
               FROM memories
               WHERE team_id = ? AND project_id = ?
               AND scope != 'private'
               AND quality != 'archived'
               ORDER BY
                   CASE quality WHEN 'pinned' THEN 0 WHEN 'verified' THEN 1 ELSE 2 END,
                   updated_at DESC
               LIMIT 30""",
            (team_id, project_id),
        )

        items = [_row_to_context_item(row) for row in rows]
        items = _trim_to_budget(items, budget)

        self.cache.set(cache_key, items, ttl_seconds=600)  # 10 minutes

        layer = ContextLayer(name="project_context", layer=1, items=items)
        layer.token_estimate = _estimate_tokens(items)
        return layer

    async def _build_layer2(
        self,
        query: str,
        team_id: str,
        user_id: str | None,
        project_id: str | None,
        budget: int,
    ) -> ContextLayer:
        """Layer 2: Session/query-relevant memories from search."""
        search_results = await self.search.search(
            query=query,
            team_id=team_id,
            user_id=user_id,
            project_id=project_id,
            limit=15,
        )

        items = [_search_result_to_item(r) for r in search_results]
        items = _trim_to_budget(items, budget)

        layer = ContextLayer(name="session_relevant", layer=2, items=items)
        layer.token_estimate = _estimate_tokens(items)
        return layer


def _row_to_context_item(row: dict[str, Any]) -> dict[str, Any]:
    """Convert a DB row to a context item dict."""
    import json as _json

    tags = row.get("tags", "[]")
    if isinstance(tags, str):
        try:
            tags = _json.loads(tags)
        except _json.JSONDecodeError:
            tags = []

    return {
        "id": row["id"],
        "summary": row["summary"],
        "category": row.get("category", "general"),
        "tags": tags,
        "quality": row.get("quality", "community"),
    }


def _search_result_to_item(result: SearchResult) -> dict[str, Any]:
    """Convert a SearchResult to a context item dict."""
    return {
        "id": result.id,
        "summary": result.summary,
        "category": result.category,
        "tags": result.tags,
        "score": round(result.score, 4),
    }


def _estimate_tokens(items: list[dict[str, Any]]) -> int:
    """Rough token estimate: ~4 chars per token."""
    total_chars = sum(
        len(str(item.get("summary", ""))) + len(str(item.get("tags", "")))
        for item in items
    )
    return total_chars // 4


def _trim_to_budget(
    items: list[dict[str, Any]], budget_tokens: int
) -> list[dict[str, Any]]:
    """Trim items list to fit within token budget."""
    result: list[dict[str, Any]] = []
    used = 0
    for item in items:
        item_tokens = _estimate_tokens([item])
        if used + item_tokens > budget_tokens:
            break
        result.append(item)
        used += item_tokens
    return result
