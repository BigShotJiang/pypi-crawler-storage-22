"""Context syncer: version comparison, incremental pull, AGENTS.md updates.

Syncs team specs and context from the TMH server to local project.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

import httpx

logger = logging.getLogger(__name__)


@dataclass
class SyncState:
    """Persisted sync state for a project."""

    specs_version: int = 0
    specs_fingerprint: str = ""
    last_synced_at: str = ""
    synced_memories_count: int = 0
    server_url: str = "http://localhost:8000"

    @classmethod
    def load(cls, project_root: str | Path) -> SyncState:
        state_path = Path(project_root) / ".tmh" / "sync_state.json"
        if not state_path.exists():
            return cls()
        try:
            data = json.loads(state_path.read_text(encoding="utf-8"))
            return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
        except (json.JSONDecodeError, OSError):
            return cls()

    def save(self, project_root: str | Path) -> None:
        tmh_dir = Path(project_root) / ".tmh"
        tmh_dir.mkdir(parents=True, exist_ok=True)
        state_path = tmh_dir / "sync_state.json"
        state_path.write_text(
            json.dumps({
                "specs_version": self.specs_version,
                "specs_fingerprint": self.specs_fingerprint,
                "last_synced_at": self.last_synced_at,
                "synced_memories_count": self.synced_memories_count,
                "server_url": self.server_url,
            }, indent=2) + "\n",
            encoding="utf-8",
        )


@dataclass
class SyncResult:
    """Result of a sync operation."""

    specs_updated: bool = False
    memories_synced: int = 0
    agents_md_updated: bool = False
    errors: list[str] = field(default_factory=list)
    new_version: int = 0


class ContextSyncer:
    """Syncs team context from TMH server to a local project directory.

    Flow:
    1. Compare local sync_state.json version with server version
    2. If newer, pull specs incrementally
    3. Update AGENTS.md with fresh context
    """

    def __init__(
        self,
        project_root: str | Path,
        server_url: str = "http://localhost:8000",
        api_key: str = "",
    ):
        self.project_root = Path(project_root).resolve()
        self.server_url = server_url.rstrip("/")
        self.api_key = api_key

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    async def sync(self) -> SyncResult:
        """Run a full sync: check version, pull specs, update AGENTS.md."""
        result = SyncResult()
        state = SyncState.load(self.project_root)
        state.server_url = self.server_url

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                # Step 1: Check server version
                server_info = await self._get_server_info(client)
                if server_info is None:
                    result.errors.append("Failed to reach server")
                    return result

                server_version = server_info.get("specs_version", 0)
                server_fingerprint = server_info.get("specs_fingerprint", "")

                # Step 2: Pull if newer version
                if server_version > state.specs_version or server_fingerprint != state.specs_fingerprint:
                    specs_data = await self._pull_specs(client)
                    if specs_data is not None:
                        self._write_specs(specs_data)
                        result.specs_updated = True
                        result.new_version = server_version

                # Step 3: Pull recent memories for context
                memories = await self._pull_memories(client)
                if memories:
                    result.memories_synced = len(memories)

                # Step 4: Update AGENTS.md
                agents_content = self._generate_agents_md(
                    server_info=server_info,
                    memories=memories,
                )
                self._write_agents_md(agents_content)
                result.agents_md_updated = True

                # Update sync state
                state.specs_version = server_version
                state.specs_fingerprint = server_fingerprint
                state.last_synced_at = datetime.utcnow().isoformat()
                state.synced_memories_count = result.memories_synced
                state.save(self.project_root)

        except httpx.HTTPError as e:
            result.errors.append(f"HTTP error: {e}")
        except Exception as e:
            result.errors.append(f"Sync error: {e}")

        return result

    async def check_update_available(self) -> bool:
        """Check if there is a newer version on the server."""
        state = SyncState.load(self.project_root)
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                info = await self._get_server_info(client)
                if info is None:
                    return False
                return info.get("specs_version", 0) > state.specs_version
        except Exception:
            return False

    async def _get_server_info(self, client: httpx.AsyncClient) -> dict[str, Any] | None:
        """Get server info including specs version."""
        try:
            resp = await client.get(
                f"{self.server_url}/api/v1/health",
                headers=self._headers(),
            )
            if resp.status_code == 200:
                return resp.json()
        except Exception as e:
            logger.warning("Failed to get server info: %s", e)
        return None

    async def _pull_specs(self, client: httpx.AsyncClient) -> list[dict] | None:
        """Pull specs from the server."""
        try:
            resp = await client.get(
                f"{self.server_url}/api/v1/memories",
                params={"scope": "team", "category": "coding_standard", "page_size": 100},
                headers=self._headers(),
            )
            if resp.status_code == 200:
                data = resp.json()
                return data.get("items", [])
        except Exception as e:
            logger.warning("Failed to pull specs: %s", e)
        return None

    async def _pull_memories(self, client: httpx.AsyncClient) -> list[dict]:
        """Pull recent team memories for AGENTS.md context."""
        try:
            resp = await client.get(
                f"{self.server_url}/api/v1/memories",
                params={"scope": "team", "page_size": 50},
                headers=self._headers(),
            )
            if resp.status_code == 200:
                data = resp.json()
                return data.get("items", [])
        except Exception as e:
            logger.warning("Failed to pull memories: %s", e)
        return []

    def _write_specs(self, specs: list[dict]) -> None:
        """Write specs data to .tmh/specs.json."""
        tmh_dir = self.project_root / ".tmh"
        tmh_dir.mkdir(parents=True, exist_ok=True)
        specs_path = tmh_dir / "specs.json"
        specs_path.write_text(
            json.dumps(specs, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    def _write_agents_md(self, content: str) -> None:
        """Write AGENTS.md to project root."""
        agents_path = self.project_root / "AGENTS.md"
        agents_path.write_text(content, encoding="utf-8")

    def _generate_agents_md(
        self,
        server_info: dict[str, Any] | None = None,
        memories: list[dict] | None = None,
    ) -> str:
        """Generate AGENTS.md content from synced data."""
        lines = [
            "# AGENTS.md",
            "",
            f"<!-- Auto-generated by TMH at {datetime.utcnow().isoformat()} -->",
            "<!-- Do not edit manually; run `tmh sync` to refresh -->",
            "",
        ]

        # Team coding standards
        if memories:
            standards = [m for m in memories if m.get("category") == "coding_standard"]
            if standards:
                lines.append("## Coding Standards")
                lines.append("")
                for std in standards:
                    summary = std.get("summary", "")
                    tags = std.get("tags", [])
                    tag_str = ", ".join(tags) if tags else ""
                    lines.append(f"- {summary}")
                    if tag_str:
                        lines.append(f"  Tags: {tag_str}")
                lines.append("")

        # Team decisions
        if memories:
            decisions = [m for m in memories if m.get("category") == "decision"]
            if decisions:
                lines.append("## Architecture Decisions")
                lines.append("")
                for dec in decisions:
                    summary = dec.get("summary", "")
                    lines.append(f"- {summary}")
                lines.append("")

        # Experiences and lessons
        if memories:
            experiences = [m for m in memories if m.get("category") in ("experience", "bug_fix")]
            if experiences:
                lines.append("## Lessons Learned")
                lines.append("")
                for exp in experiences:
                    summary = exp.get("summary", "")
                    lines.append(f"- {summary}")
                lines.append("")

        # General team memories
        if memories:
            general = [
                m for m in memories
                if m.get("category") not in ("coding_standard", "decision", "experience", "bug_fix")
            ]
            if general:
                lines.append("## Team Knowledge")
                lines.append("")
                for mem in general[:20]:  # Limit to avoid huge file
                    summary = mem.get("summary", "")
                    lines.append(f"- {summary}")
                lines.append("")

        return "\n".join(lines) + "\n"
