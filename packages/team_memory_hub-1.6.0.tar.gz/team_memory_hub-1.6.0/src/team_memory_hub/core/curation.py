"""Curation task manager: automated maintenance tasks for memory quality."""

from __future__ import annotations

import hashlib
import logging
from datetime import datetime, timedelta
from typing import Any

from team_memory_hub.storage.database import Database

logger = logging.getLogger(__name__)

DUPLICATE_THRESHOLD = 0.92
STALE_DAYS = 180
AUTO_ARCHIVE_STALE_DAYS = 30


class CurationManager:
    """Runs periodic maintenance tasks on the memory store."""

    def __init__(self, db: Database, file_base_dir: str | None = None):
        self.db = db
        self.file_base_dir = file_base_dir

    # ========== Duplicate Detection ==========

    async def detect_duplicates(
        self, team_id: str, threshold: float = DUPLICATE_THRESHOLD
    ) -> list[dict[str, Any]]:
        """Find memory pairs with summary similarity > threshold."""
        rows = await self.db.fetch_all(
            """SELECT id, summary FROM memories
               WHERE team_id = ? AND quality != 'archived'
               ORDER BY created_at DESC LIMIT 500""",
            (team_id,),
        )

        duplicates: list[dict[str, Any]] = []
        for i in range(len(rows)):
            for j in range(i + 1, len(rows)):
                sim = self._jaccard_similarity(rows[i]["summary"], rows[j]["summary"])
                if sim >= threshold:
                    duplicates.append({
                        "id_a": rows[i]["id"],
                        "id_b": rows[j]["id"],
                        "similarity": round(sim, 4),
                    })
        return duplicates

    # ========== Staleness Detection ==========

    async def detect_staleness(
        self, team_id: str, stale_days: int = STALE_DAYS
    ) -> int:
        """Mark memories as stale if not accessed in stale_days."""
        cutoff = (datetime.utcnow() - timedelta(days=stale_days)).isoformat()
        result = await self.db.execute(
            """UPDATE memories SET quality = 'stale', updated_at = ?
               WHERE team_id = ? AND quality NOT IN ('archived', 'stale', 'pinned')
                 AND (last_accessed_at IS NULL OR last_accessed_at < ?)
                 AND created_at < ?""",
            (datetime.utcnow().isoformat(), team_id, cutoff, cutoff),
        )
        await self.db.commit()
        return result.rowcount

    async def auto_archive(
        self, team_id: str, stale_archive_days: int = AUTO_ARCHIVE_STALE_DAYS
    ) -> int:
        """Archive stale memories that have been stale for stale_archive_days."""
        cutoff = (datetime.utcnow() - timedelta(days=stale_archive_days)).isoformat()
        result = await self.db.execute(
            """UPDATE memories SET quality = 'archived', updated_at = ?
               WHERE team_id = ? AND quality = 'stale'
                 AND updated_at < ?""",
            (datetime.utcnow().isoformat(), team_id, cutoff),
        )
        await self.db.commit()
        return result.rowcount

    # ========== 质量 Score Refresh ==========

    async def refresh_quality_scores(self, team_id: str) -> int:
        """Recalculate quality scores based on access patterns and age."""
        rows = await self.db.fetch_all(
            """SELECT id, access_count, quality, created_at, last_accessed_at
               FROM memories WHERE team_id = ? AND quality != 'archived'""",
            (team_id,),
        )

        updated = 0
        now = datetime.utcnow()

        for row in rows:
            score = self._calculate_quality_score(row, now)
            await self.db.execute(
                "UPDATE memories SET quality_score = ? WHERE id = ?",
                (score, row["id"]),
            )
            updated += 1

        await self.db.commit()
        return updated

    # ========== File Integrity ==========

    async def verify_file_integrity(self, team_id: str) -> dict[str, Any]:
        """Verify SHA256 hashes of memory files match the index."""
        if not self.file_base_dir:
            return {"checked": 0, "mismatched": 0, "missing": 0}

        from pathlib import Path

        base = Path(self.file_base_dir)
        rows = await self.db.fetch_all(
            "SELECT id, file_path, file_hash FROM memories WHERE team_id = ?",
            (team_id,),
        )

        checked = 0
        mismatched = 0
        missing = 0

        for row in rows:
            full_path = base / row["file_path"]
            if not full_path.exists():
                missing += 1
                continue

            checked += 1
            actual_hash = hashlib.sha256(full_path.read_bytes()).hexdigest()
            if row["file_hash"] and actual_hash != row["file_hash"]:
                mismatched += 1

        return {"checked": checked, "mismatched": mismatched, "missing": missing}

    async def clean_orphan_files(self, team_id: str) -> int:
        """Remove files that have no corresponding database entry."""
        if not self.file_base_dir:
            return 0

        from pathlib import Path

        base = Path(self.file_base_dir)
        if not base.exists():
            return 0

        # Get all indexed file paths
        rows = await self.db.fetch_all(
            "SELECT file_path FROM memories WHERE team_id = ?", (team_id,)
        )
        indexed_paths = {row["file_path"] for row in rows}

        removed = 0
        for md_file in base.rglob("*.md"):
            try:
                rel = str(md_file.relative_to(base))
            except ValueError:
                continue
            # Normalize path separators
            rel = rel.replace("\\", "/")
            if rel not in indexed_paths:
                md_file.unlink()
                removed += 1

        return removed

    async def sync_specs_index(self, team_id: str) -> int:
        """Ensure specs table is consistent. Returns number of fixes applied."""
        # Verify spec proposals reference valid teams
        result = await self.db.execute(
            """UPDATE spec_proposals SET status = 'withdrawn'
               WHERE team_id = ? AND status = 'pending_review'
                 AND author_id NOT IN (SELECT id FROM users WHERE is_active = 1)""",
            (team_id,),
        )
        await self.db.commit()
        return result.rowcount

    # ========== Merge Candidate Scanning ==========

    async def scan_merge_candidates(self, team_id: str) -> int:
        """Wrapper: run merge candidate detection via MemoryConsolidator."""
        from team_memory_hub.core.memory_consolidator import MemoryConsolidator

        consolidator = MemoryConsolidator(self.db)
        candidates = await consolidator.detect_merge_candidates(team_id)

        created = 0
        for candidate in candidates:
            await consolidator.generate_merge_suggestion(
                team_id=team_id,
                memory_ids=candidate["ids"],
                similarity=candidate["similarity"],
            )
            created += 1

        return created

    async def clean_old_suggestions(self, retention_days: int = 30) -> int:
        from team_memory_hub.core.memory_consolidator import MemoryConsolidator

        consolidator = MemoryConsolidator(self.db)
        return await consolidator.clean_old_suggestions(retention_days)

    async def clean_old_audit_logs(self, retention_days: int = 90) -> int:
        from team_memory_hub.core.audit import AuditLogger

        audit = AuditLogger(self.db)
        return await audit.clean_old(retention_days)

    # ========== Run All Tasks ==========

    async def run_all(self, team_id: str) -> dict[str, Any]:
        """Run all curation tasks and return a summary report."""
        results: dict[str, Any] = {}

        results["duplicates"] = await self.detect_duplicates(team_id)
        results["stale_marked"] = await self.detect_staleness(team_id)
        results["auto_archived"] = await self.auto_archive(team_id)
        results["quality_refreshed"] = await self.refresh_quality_scores(team_id)
        results["file_integrity"] = await self.verify_file_integrity(team_id)
        results["orphans_cleaned"] = await self.clean_orphan_files(team_id)
        results["specs_synced"] = await self.sync_specs_index(team_id)
        results["merge_candidates"] = await self.scan_merge_candidates(team_id)
        results["old_suggestions_cleaned"] = await self.clean_old_suggestions()
        results["old_audit_cleaned"] = await self.clean_old_audit_logs()

        return results

    # ========== Helpers ==========

    @staticmethod
    def _jaccard_similarity(a: str, b: str) -> float:
        if not a or not b:
            return 0.0
        words_a = set(a.lower().split())
        words_b = set(b.lower().split())
        if not words_a or not words_b:
            return 0.0
        intersection = words_a & words_b
        union = words_a | words_b
        return len(intersection) / len(union)

    @staticmethod
    def _calculate_quality_score(row: dict[str, Any], now: datetime) -> float:
        """Calculate a quality score between 0 and 1."""
        score = 0.5

        # Access frequency boost
        access_count = row.get("access_count", 0)
        if access_count > 10:
            score += 0.2
        elif access_count > 3:
            score += 0.1

        # 质量 status boost
        quality = row.get("quality", "community")
        if quality == "verified":
            score += 0.15
        elif quality == "pinned":
            score += 0.2
        elif quality == "stale":
            score -= 0.2

        # Recency boost
        created_str = row.get("created_at")
        if created_str:
            try:
                created = datetime.fromisoformat(str(created_str))
                age_days = (now - created).days
                if age_days < 7:
                    score += 0.1
                elif age_days > 365:
                    score -= 0.1
            except (ValueError, TypeError):
                pass

        return max(0.0, min(1.0, score))
