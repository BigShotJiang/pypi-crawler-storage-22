"""记忆整合：检测合并候选项并执行合并。"""

from __future__ import annotations

import json
import logging
import secrets
import string
from datetime import datetime, timedelta
from typing import Any

from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import MergeSuggestion, MergeSuggestion状态

logger = logging.getLogger(__name__)

_ID_CHARS = string.ascii_lowercase + string.digits
CLUSTER_THRESHOLD = 0.85


def _gen_id(prefix: str = "msug") -> str:
    return f"{prefix}_{''.join(secrets.choice(_ID_CHARS) for _ in range(8))}"


class MemoryConsolidator:
    """检测合并候选项并管理合并建议。"""

    def __init__(self, db: Database, llm_provider: Any = None):
        self.db = db
        self.llm = llm_provider

    async def detect_merge_candidates(
        self,
        team_id: str,
        threshold: float = CLUSTER_THRESHOLD,
        scan_days: int = 30,
        max_suggestions: int = 20,
    ) -> list[dict[str, Any]]:
        """检测作为潜在合并候选项的记忆对。

        贪心聚类：在过去 scan_days 天内的未归档记忆中查找余弦相似度 > 阈值的对。
        """
        cutoff = (datetime.utcnow() - timedelta(days=scan_days)).isoformat()

        # 获取候选记忆
        rows = await self.db.fetch_all(
            """SELECT id, summary, tags, category, scope
               FROM memories
               WHERE team_id = ? AND quality != 'archived'
                 AND created_at >= ?
               ORDER BY created_at DESC""",
            (team_id, cutoff),
        )

        if len(rows) < 2:
            return []

        # 基于摘要重叠的简单文本相似度
        candidates: list[dict[str, Any]] = []
        seen: set[str] = set()

        for i in range(len(rows)):
            if rows[i]["id"] in seen:
                continue
            for j in range(i + 1, len(rows)):
                if rows[j]["id"] in seen:
                    continue

                sim = self._text_similarity(rows[i]["summary"], rows[j]["summary"])
                if sim >= threshold:
                    candidates.append({
                        "ids": [rows[i]["id"], rows[j]["id"]],
                        "summaries": [rows[i]["summary"], rows[j]["summary"]],
                        "similarity": sim,
                        "scope": rows[i]["scope"],
                    })
                    seen.add(rows[i]["id"])
                    seen.add(rows[j]["id"])

                    if len(candidates) >= max_suggestions:
                        return candidates

        return candidates

    async def generate_merge_suggestion(
        self,
        team_id: str,
        memory_ids: list[str],
        similarity: float,
    ) -> MergeSuggestion:
        """Generate a merge suggestion for a group of memories."""
        memories = []
        all_tags: list[str] = []
        categories: list[str] = []
        scope = "private"

        for mid in memory_ids:
            row = await self.db.fetch_one("SELECT * FROM memories WHERE id = ?", (mid,))
            if row:
                memories.append(row)
                tags = json.loads(row.get("tags", "[]")) if isinstance(row.get("tags"), str) else []
                all_tags.extend(tags)
                categories.append(row.get("category", "general"))
                if row.get("scope") in ("team", "project"):
                    scope = row["scope"]

        # Generate merged content (using LLM if available, otherwise simple concatenation)
        merged_content = await self._generate_merged_content(memories)
        merged_tags = list(set(all_tags))

        # Pick most common category
        merged_category = max(set(categories), key=categories.count) if categories else "general"

        suggestion_id = _gen_id()
        confidence = min(similarity, 0.99)

        await self.db.execute(
            """INSERT INTO merge_suggestions
               (id, team_id, original_ids, merged_content, merged_tags,
                merged_category, scope, avg_similarity, confidence, status)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                suggestion_id, team_id, json.dumps(memory_ids), merged_content,
                json.dumps(merged_tags), merged_category, scope,
                similarity, confidence, MergeSuggestion状态.PENDING.value,
            ),
        )
        await self.db.commit()

        return MergeSuggestion(
            id=suggestion_id,
            team_id=team_id,
            original_ids=memory_ids,
            merged_content=merged_content,
            merged_tags=merged_tags,
            merged_category=merged_category,
            scope=scope,
            avg_similarity=similarity,
            confidence=confidence,
        )

    async def execute_merge(
        self,
        suggestion_id: str,
        reviewed_by: str,
    ) -> str | None:
        """Execute an accepted merge: create new memory, archive originals."""
        row = await self.db.fetch_one(
            "SELECT * FROM merge_suggestions WHERE id = ?", (suggestion_id,)
        )
        if not row:
            return None

        original_ids = json.loads(row["original_ids"])
        merged_content = row["merged_content"]
        merged_tags = row.get("merged_tags", "[]")
        merged_category = row.get("merged_category", "general")
        scope = row["scope"]
        team_id = row["team_id"]

        # 创建新的 merged memory ID
        new_id = f"mem_{''.join(secrets.choice(_ID_CHARS) for _ in range(8))}"
        now = datetime.utcnow().isoformat()

        summary = merged_content[:200] if len(merged_content) > 200 else merged_content

        await self.db.execute(
            """INSERT INTO memories
               (id, summary, file_path, owner_id, scope, team_id,
                category, tags, layer, quality, quality_score, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                new_id, summary, f"merged/{new_id}.md", reviewed_by,
                scope, team_id, merged_category, merged_tags,
                2, "community", 0.5, now, now,
            ),
        )

        # Archive originals and set merged_into
        for mid in original_ids:
            await self.db.execute(
                "UPDATE memories SET quality = 'archived', merged_into = ?, updated_at = ? WHERE id = ?",
                (new_id, now, mid),
            )

        # Update suggestion status
        await self.db.execute(
            """UPDATE merge_suggestions SET status = 'accepted',
               reviewed_by = ?, reviewed_at = ? WHERE id = ?""",
            (reviewed_by, now, suggestion_id),
        )

        await self.db.commit()
        return new_id

    async def reject_suggestion(self, suggestion_id: str, reviewed_by: str) -> bool:
        now = datetime.utcnow().isoformat()
        result = await self.db.execute(
            """UPDATE merge_suggestions SET status = 'rejected',
               reviewed_by = ?, reviewed_at = ? WHERE id = ?""",
            (reviewed_by, now, suggestion_id),
        )
        await self.db.commit()
        return result.rowcount > 0

    async def dismiss_suggestion(self, suggestion_id: str, reviewed_by: str) -> bool:
        now = datetime.utcnow().isoformat()
        result = await self.db.execute(
            """UPDATE merge_suggestions SET status = 'dismissed',
               reviewed_by = ?, reviewed_at = ? WHERE id = ?""",
            (reviewed_by, now, suggestion_id),
        )
        await self.db.commit()
        return result.rowcount > 0

    async def get_suggestions(
        self, team_id: str, status: str | None = None, page: int = 1, page_size: int = 20
    ) -> tuple[list[MergeSuggestion], int]:
        conditions = ["team_id = ?"]
        params: list[Any] = [team_id]

        if status:
            conditions.append("status = ?")
            params.append(status)

        where = " AND ".join(conditions)

        count_row = await self.db.fetch_one(
            f"SELECT COUNT(*) as cnt FROM merge_suggestions WHERE {where}", tuple(params)
        )
        total = count_row["cnt"] if count_row else 0

        offset = (page - 1) * page_size
        rows = await self.db.fetch_all(
            f"""SELECT * FROM merge_suggestions WHERE {where}
                ORDER BY created_at DESC LIMIT ? OFFSET ?""",
            tuple(params + [page_size, offset]),
        )

        suggestions = [self._row_to_suggestion(r) for r in rows]
        return suggestions, total

    async def get_stats(self, team_id: str) -> dict[str, Any]:
        rows = await self.db.fetch_all(
            "SELECT status, COUNT(*) as cnt FROM merge_suggestions WHERE team_id = ? GROUP BY status",
            (team_id,),
        )
        stats = {r["status"]: r["cnt"] for r in rows}
        stats["total"] = sum(stats.values())
        return stats

    async def clean_old_suggestions(self, retention_days: int = 30) -> int:
        cutoff = (datetime.utcnow() - timedelta(days=retention_days)).isoformat()
        result = await self.db.execute(
            "DELETE FROM merge_suggestions WHERE status IN ('rejected', 'dismissed') AND created_at < ?",
            (cutoff,),
        )
        await self.db.commit()
        return result.rowcount

    async def _generate_merged_content(self, memories: list[dict[str, Any]]) -> str:
        """Generate merged content. Uses LLM if available, otherwise concatenates."""
        if self.llm:
            try:
                summaries = [m.get("summary", "") for m in memories]
                prompt = (
                    "Merge the following memory summaries into one concise summary:\n\n"
                    + "\n---\n".join(summaries)
                )
                return await self.llm.generate(prompt)
            except Exception:
                logger.warning("LLM merge generation failed, falling back to concatenation")

        # Fallback: concatenate summaries
        parts = []
        for m in memories:
            parts.append(m.get("summary", ""))
        return " | ".join(parts)

    @staticmethod
    def _text_similarity(a: str, b: str) -> float:
        """Simple Jaccard similarity on word tokens."""
        if not a or not b:
            return 0.0
        words_a = set(a.lower().split())
        words_b = set(b.lower().split())
        if not words_a or not words_b:
            return 0.0
        intersection = words_a & words_b
        union = words_a | words_b
        return len(intersection) / len(union)

    @staticmethod
    def _row_to_suggestion(row: dict[str, Any]) -> MergeSuggestion:
        original_ids = row.get("original_ids", "[]")
        if isinstance(original_ids, str):
            original_ids = json.loads(original_ids)

        merged_tags = row.get("merged_tags", "[]")
        if isinstance(merged_tags, str):
            merged_tags = json.loads(merged_tags)

        return MergeSuggestion(
            id=row["id"],
            team_id=row["team_id"],
            original_ids=original_ids,
            merged_content=row["merged_content"],
            merged_tags=merged_tags,
            merged_category=row.get("merged_category"),
            scope=row["scope"],
            avg_similarity=row["avg_similarity"],
            confidence=row["confidence"],
            status=row.get("status", "pending"),
            reviewed_by=row.get("reviewed_by"),
            reviewed_at=row.get("reviewed_at"),
            created_at=row.get("created_at"),
        )
