"""记忆提取器：从聊天会话中提取知识。

Two-tier extraction:
1. LLM-based: intelligent extraction via configurable LLM provider
2. Rule-based: keyword + regex fallback when LLM is unavailable
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

from team_memory_hub.chat_adapters.base import ChatMessage

logger = logging.getLogger(__name__)


@dataclass
class ExtractedMemory:
    """从聊天会话中提取的记忆。"""

    content: str
    summary: str
    category: str = "general"
    tags: list[str] = field(default_factory=list)
    confidence: float = 0.5
    source_turn: int = 0  # which turn in the chat this came from
    extraction_method: str = "rule"  # "llm" or "rule"


# ========== 基于规则的提取模式 ==========

# 指示来自助手的值得记住的陈述的模式
_MEMORY_PATTERNS: list[tuple[str, str, re.Pattern]] = [
    # 决策和结论
    ("decision", "decision", re.compile(
        r"(?:we\s+(?:should|decided|chose|went\s+with|agreed))|"
        r"(?:the\s+decision\s+(?:is|was))|"
        r"(?:let'?s\s+(?:go\s+with|use|adopt))",
        re.IGNORECASE,
    )),
    # 错误修复和解决方案
    ("bug_fix", "bug-fix", re.compile(
        r"(?:the\s+(?:bug|issue|problem|error)\s+(?:was|is))|"
        r"(?:(?:fixed|resolved|solved)\s+(?:by|with|using))|"
        r"(?:root\s+cause\s+(?:is|was))",
        re.IGNORECASE,
    )),
    # 架构和设计
    ("architecture", "architecture", re.compile(
        r"(?:architecture|design\s+pattern|system\s+design)|"
        r"(?:(?:database|api|service)\s+(?:schema|structure|design))|"
        r"(?:(?:chose|using|adopted)\s+(?:microservices|monolith|serverless))",
        re.IGNORECASE,
    )),
    # 编码标准
    ("coding_standard", "standard", re.compile(
        r"(?:coding\s+(?:standard|convention|style))|"
        r"(?:(?:naming|file|folder)\s+convention)|"
        r"(?:best\s+practice)|"
        r"(?:we\s+(?:always|never)\s+(?:use|do))",
        re.IGNORECASE,
    )),
    # 工作流模式
    ("workflow", "workflow", re.compile(
        r"(?:workflow|process|pipeline)|"
        r"(?:(?:deploy|release|ci)\s+(?:process|pipeline|workflow))|"
        r"(?:(?:review|testing|branching)\s+strategy)",
        re.IGNORECASE,
    )),
    # 经验 / 吸取的教训
    ("experience", "lesson", re.compile(
        r"(?:lesson\s+learned)|"
        r"(?:(?:important|key)\s+(?:takeaway|insight|finding))|"
        r"(?:in\s+(?:my|our)\s+experience)|"
        r"(?:(?:tip|trick|gotcha|caveat|pitfall))",
        re.IGNORECASE,
    )),
]

# 表明内容值得记住的关键字
_VALUE_KEYWORDS = [
    "important", "remember", "note", "convention", "standard", "pattern",
    "always", "never", "avoid", "prefer", "requirement", "constraint",
    "principle", "rule", "guideline", "policy",
]

# 考虑提取的最小内容长度
_MIN_CONTENT_LENGTH = 50
_MIN_SENTENCE_LENGTH = 20


class MemoryExtractor:
    """使用规则或 LLM 从聊天消息中提取记忆。"""

    def __init__(self, llm_provider: Any = None):
        """初始化提取器。

        Args:
            llm_provider: Optional LLM provider for intelligent extraction.
                          If None, falls back to rule-based extraction.
        """
        self.llm_provider = llm_provider

    async def extract(
        self,
        messages: list[ChatMessage],
        context: dict[str, Any] | None = None,
    ) -> list[ExtractedMemory]:
        """从聊天消息列表中提取记忆。

        如果可用，使用 LLM，否则退回到基于规则的提取。
        """
        if self.llm_provider:
            try:
                return await self._extract_with_llm(messages, context)
            except Exception as e:
                logger.warning("LLM 提取失败，退回到规则： %s", e)

        return self._extract_with_rules(messages)

    async def _extract_with_llm(
        self,
        messages: list[ChatMessage],
        context: dict[str, Any] | None = None,
    ) -> list[ExtractedMemory]:
        """使用 LLM 提取记忆（提供程序集成的占位符）。"""
        # 从消息构建提示
        chat_text = self._format_chat_for_llm(messages)

        prompt = (
            "分析以下用户和 AI 助手之间的聊天对话。 "
            "Extract any valuable knowledge, decisions, patterns, or lessons that would be "
            "useful for a team to remember.\n\n"
            "对于每个提取的记忆，提供：\n"
            "1. 简洁的摘要（一句话）\n"
            "2. 完整内容（1-3 段）\n"
            "3. A category: general, decision, experience, bug_fix, architecture, "
            "coding_standard, or workflow\n"
            "4. 相关标签（关键字列表）\n"
            "5. 置信度分数（0.0 到 1.0）\n\n"
            "将结果返回为 JSON 数组。\n\n"
            f"聊天：\n{chat_text}"
        )

        # Call LLM provider
        response = await self.llm_provider.generate(prompt)

        # Parse LLM response
        return self._parse_llm_response(response)

    def _extract_with_rules(self, messages: list[ChatMessage]) -> list[ExtractedMemory]:
        """使用关键字和正则表达式规则提取记忆（后备方案）。"""
        extracted: list[ExtractedMemory] = []

        for i, msg in enumerate(messages):
            # 仅从助手响应中提取
            if msg.role != "assistant":
                continue

            content = msg.content.strip()
            if len(content) < _MIN_CONTENT_LENGTH:
                continue

            # 检查每个模式
            for category, tag, pattern in _MEMORY_PATTERNS:
                matches = pattern.findall(content)
                if matches:
                    # Extract the relevant paragraph
                    relevant = self._extract_relevant_paragraph(content, pattern)
                    if relevant and len(relevant) >= _MIN_SENTENCE_LENGTH:
                        summary = self._generate_summary(relevant)
                        confidence = self._calculate_confidence(relevant)

                        extracted.append(ExtractedMemory(
                            content=relevant,
                            summary=summary,
                            category=category,
                            tags=[tag],
                            confidence=confidence,
                            source_turn=i,
                            extraction_method="rule",
                        ))

            # Check for value keywords (general extraction)
            keyword_score = self._score_keywords(content)
            if keyword_score >= 2 and not any(e.source_turn == i for e in extracted):
                # High keyword score and not already extracted
                summary = self._generate_summary(content)
                extracted.append(ExtractedMemory(
                    content=content[:2000],  # Limit content length
                    summary=summary,
                    category="general",
                    tags=self._extract_tags_from_content(content),
                    confidence=min(0.3 + keyword_score * 0.1, 0.8),
                    source_turn=i,
                    extraction_method="rule",
                ))

        # Deduplicate similar extractions
        return self._deduplicate(extracted)

    @staticmethod
    def _extract_relevant_paragraph(content: str, pattern: re.Pattern) -> str:
        """Extract the paragraph containing the pattern match."""
        paragraphs = content.split("\n\n")
        for para in paragraphs:
            if pattern.search(para):
                return para.strip()
        # If no paragraph match, return the first match's sentence context
        sentences = re.split(r'[.!?]\s+', content)
        for sentence in sentences:
            if pattern.search(sentence):
                return sentence.strip()
        return content[:500]

    @staticmethod
    def _generate_summary(content: str) -> str:
        """Generate a short summary from content (first meaningful sentence)."""
        # Take first sentence or first 200 chars
        sentences = re.split(r'[.!?]\s+', content)
        first = sentences[0].strip() if sentences else content[:200]
        if len(first) > 200:
            first = first[:197] + "..."
        return first

    @staticmethod
    def _calculate_confidence(content: str) -> float:
        """Calculate confidence score for a rule-based extraction."""
        score = 0.3
        lower = content.lower()

        # Definitive language increases confidence
        definitive = ["always", "never", "must", "should", "decided", "chosen", "standard"]
        for word in definitive:
            if word in lower:
                score += 0.05

        # Code examples increase confidence
        if "```" in content:
            score += 0.1

        # Length adds confidence (longer = more detailed)
        if len(content) > 200:
            score += 0.05
        if len(content) > 500:
            score += 0.05

        return min(score, 0.9)

    @staticmethod
    def _score_keywords(content: str) -> int:
        """Count how many value keywords appear in content."""
        lower = content.lower()
        return sum(1 for kw in _VALUE_KEYWORDS if kw in lower)

    @staticmethod
    def _extract_tags_from_content(content: str) -> list[str]:
        """Extract likely tags from content."""
        tags: list[str] = []
        lower = content.lower()

        tag_keywords = {
            "python": "python", "javascript": "javascript", "typescript": "typescript",
            "react": "react", "vue": "vue", "docker": "docker",
            "api": "api", "database": "database", "testing": "testing",
            "security": "security", "performance": "performance",
            "git": "git", "ci/cd": "cicd", "deploy": "deployment",
        }

        for keyword, tag in tag_keywords.items():
            if keyword in lower and tag not in tags:
                tags.append(tag)

        return tags[:5]

    @staticmethod
    def _deduplicate(extracted: list[ExtractedMemory]) -> list[ExtractedMemory]:
        """Remove duplicate extractions based on content similarity."""
        if len(extracted) <= 1:
            return extracted

        unique: list[ExtractedMemory] = []
        seen_summaries: set[str] = set()

        for mem in sorted(extracted, key=lambda m: m.confidence, reverse=True):
            # Simple dedup: check if summary is too similar
            summary_lower = mem.summary.lower()[:100]
            if summary_lower not in seen_summaries:
                seen_summaries.add(summary_lower)
                unique.append(mem)

        return unique

    @staticmethod
    def _format_chat_for_llm(messages: list[ChatMessage]) -> str:
        """Format chat messages for LLM prompt."""
        lines = []
        for msg in messages:
            role = "User" if msg.role == "user" else "Assistant"
            # Truncate very long messages
            content = msg.content[:3000] if len(msg.content) > 3000 else msg.content
            lines.append(f"[{role}]: {content}")
        return "\n\n".join(lines)

    @staticmethod
    def _parse_llm_response(response: str) -> list[ExtractedMemory]:
        """Parse LLM JSON response into ExtractedMemory list."""
        import json

        try:
            # Try to extract JSON from the response
            # Handle markdown code blocks
            if "```json" in response:
                start = response.index("```json") + 7
                end = response.index("```", start)
                response = response[start:end]
            elif "```" in response:
                start = response.index("```") + 3
                end = response.index("```", start)
                response = response[start:end]

            data = json.loads(response.strip())
            if not isinstance(data, list):
                data = [data]

            results = []
            for item in data:
                results.append(ExtractedMemory(
                    content=item.get("content", ""),
                    summary=item.get("summary", "")[:200],
                    category=item.get("category", "general"),
                    tags=item.get("tags", []),
                    confidence=float(item.get("confidence", 0.7)),
                    extraction_method="llm",
                ))
            return results
        except (json.JSONDecodeError, ValueError, IndexError) as e:
            logger.warning("Failed to parse LLM response: %s", e)
            return []
