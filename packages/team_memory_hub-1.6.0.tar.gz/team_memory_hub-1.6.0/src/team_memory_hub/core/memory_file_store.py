"""文件系统存储记忆内容：带 YAML front-matter 的 .md 文件。"""

from __future__ import annotations

import hashlib
import logging
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)


class MemoryFileStore:
    """管理磁盘上的记忆内容文件。

    每个记忆存储为带 YAML front-matter 的 Markdown 文件：
        ---
        id: mem_a1b2c3d4
        scope: team
        category: decision
        ...
        ---
        # Title
        Content here...
    """

    def __init__(self, base_dir: str):
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def _build_path(
        self, scope: str, owner_name: str | None, project_name: str | None,
        memory_id: str, created_at: datetime | None = None,
    ) -> Path:
        """根据范围和日期构建文件路径。

        结构：
          - team/{year}/{month}/mem_xxx.md
          - projects/{name}/{year}/{month}/mem_xxx.md
          - private/{user}/{year}/{month}/mem_xxx.md
        """
        now = created_at or datetime.utcnow()
        year = str(now.year)
        month = f"{now.month:02d}"

        if scope == "team":
            return self.base_dir / "team" / year / month / f"{memory_id}.md"
        elif scope == "project" and project_name:
            return self.base_dir / "projects" / project_name / year / month / f"{memory_id}.md"
        else:
            user = owner_name or "unknown"
            return self.base_dir / "private" / user / year / month / f"{memory_id}.md"

    def write_memory(
        self,
        memory_id: str,
        content: str,
        metadata: dict[str, Any],
        scope: str = "private",
        owner_name: str | None = None,
        project_name: str | None = None,
        created_at: datetime | None = None,
    ) -> tuple[str, str, int]:
        """将记忆文件写入磁盘。

        返回：
            元组 (相对文件路径, 文件哈希, 文件大小字节数)
        """
        file_path = self._build_path(scope, owner_name, project_name, memory_id, created_at)
        file_path.parent.mkdir(parents=True, exist_ok=True)

        # 构建 YAML front-matter
        front_matter = {
            "id": memory_id,
            "scope": scope,
            **{k: v for k, v in metadata.items() if v is not None},
        }

        # 组合文件内容
        yaml_str = yaml.dump(front_matter, default_flow_style=False, allow_unicode=True)
        full_content = f"---\n{yaml_str}---\n\n{content}\n"

        # 作为字节写入文件，避免平台特定的换行符转换
        content_bytes = full_content.encode("utf-8")
        file_path.write_bytes(content_bytes)

        # 计算哈希和大小
        file_hash = hashlib.sha256(content_bytes).hexdigest()
        file_size = len(content_bytes)

        # 返回相对路径
        rel_path = str(file_path.relative_to(self.base_dir))
        return rel_path, file_hash, file_size

    def read_memory(self, file_path: str) -> tuple[dict[str, Any], str]:
        """读取记忆文件并解析其 front-matter 和内容。

        返回：
            元组 (元数据字典, 内容字符串)
        """
        full_path = self.base_dir / file_path
        if not full_path.exists():
            raise FileNotFoundError(f"Memory file not found: {file_path}")

        text = full_path.read_text(encoding="utf-8")
        return self._parse_frontmatter(text)

    def delete_memory(self, file_path: str) -> bool:
        """从磁盘删除记忆文件。

        返回：如果删除了文件则为 True，如果不存在则为 False。
        """
        full_path = self.base_dir / file_path
        if full_path.exists():
            full_path.unlink()
            # 清理空的父目录
            self._cleanup_empty_dirs(full_path.parent)
            return True
        return False

    def file_exists(self, file_path: str) -> bool:
        """检查记忆文件是否存在。"""
        return (self.base_dir / file_path).exists()

    def compute_hash(self, file_path: str) -> str | None:
        """计算记忆文件的 SHA256 哈希。"""
        full_path = self.base_dir / file_path
        if not full_path.exists():
            return None
        content = full_path.read_bytes()
        return hashlib.sha256(content).hexdigest()

    @staticmethod
    def _parse_frontmatter(text: str) -> tuple[dict[str, Any], str]:
        """从 Markdown 文本解析 YAML front-matter。"""
        if not text.startswith("---"):
            return {}, text

        parts = text.split("---", 2)
        if len(parts) < 3:
            return {}, text

        yaml_str = parts[1]
        content = parts[2].strip()

        try:
            metadata = yaml.safe_load(yaml_str) or {}
        except yaml.YAMLError:
            metadata = {}

        return metadata, content

    def _cleanup_empty_dirs(self, directory: Path) -> None:
        """删除直到 base_dir 的空父目录。"""
        while directory != self.base_dir:
            try:
                if directory.exists() and not any(directory.iterdir()):
                    directory.rmdir()
                    directory = directory.parent
                else:
                    break
            except OSError:
                break
