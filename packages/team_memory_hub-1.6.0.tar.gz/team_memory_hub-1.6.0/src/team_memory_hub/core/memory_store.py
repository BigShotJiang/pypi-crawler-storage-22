"""记忆存储：CRUD 操作与数据一致性保证。

一致性保证：写入文件 -> 写入索引 -> 失败时，通过删除文件进行补偿。
"""

from __future__ import annotations

import json
import logging
import secrets
import string
from datetime import datetime
from typing import Any

from team_memory_hub.core.memory_file_store import MemoryFileStore
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import (
    Memory,
    MemoryCreate,
    MemoryDetail,
    MemoryUpdate,
    MemoryVersion,
    质量状态,
)

logger = logging.getLogger(__name__)

# ID 生成：mem_ 前缀 + 8 个随机字母数字
_ID_CHARS = string.ascii_lowercase + string.digits
_ID_LENGTH = 8


def generate_memory_id() -> str:
    """生成唯一的记忆 ID：mem_ + 8 个随机字符。"""
    suffix = "".join(secrets.choice(_ID_CHARS) for _ in range(_ID_LENGTH))
    return f"mem_{suffix}"


class MemoryStore:
    """核心记忆 CRUD，实现文件 + 索引一致性。"""

    def __init__(self, db: Database, file_store: MemoryFileStore):
        self.db = db
        self.file_store = file_store

    async def create(
        self,
        data: MemoryCreate,
        owner_id: str,
        team_id: str,
        owner_name: str | None = None,
        project_name: str | None = None,
    ) -> Memory:
        """创建新记忆，保证文件 + 索引一致性。

        流程：生成 ID -> 写入文件 -> 写入索引 -> 失败时删除文件
        """
        memory_id = generate_memory_id()
        now = datetime.utcnow()
        summary = data.summary or data.content[:200]

        # Front-matter 元数据
        metadata = {
            "category": data.category,
            "tags": data.tags,
            "layer": data.layer,
            "quality": 质量状态.COMMUNITY.value,
            "author": owner_name,
            "project": project_name,
            "created_at": now.isoformat(),
        }

        # 步骤 1：写入文件
        try:
            file_path, file_hash, file_size = self.file_store.write_memory(
                memory_id=memory_id,
                content=data.content,
                metadata=metadata,
                scope=data.scope,
                owner_name=owner_name,
                project_name=project_name,
                created_at=now,
            )
        except Exception as e:
            logger.error(f"Failed to write memory file for {memory_id}: {e}")
            raise

        # 步骤 2：写入索引（失败时进行补偿）
        try:
            tags_json = json.dumps(data.tags)
            await self.db.execute(
                """INSERT INTO memories
                   (id, summary, file_path, file_hash, file_size_bytes,
                    owner_id, scope, team_id, project_id, category, tags,
                    layer, quality, quality_score, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    memory_id, summary, file_path, file_hash, file_size,
                    owner_id, data.scope, team_id, data.project_id,
                    data.category, tags_json, data.layer,
                    质量状态.COMMUNITY.value, 0.5,
                    now.isoformat(), now.isoformat(),
                ),
            )
            await self.db.commit()

            # 创建初始版本记录
            await self._create_version(
                memory_id=memory_id,
                version=1,
                summary=summary,
                file_path=file_path,
                changed_by=owner_id,
                change_type="created",
            )

        except Exception as e:
            # 补偿：删除刚写入的文件
            logger.error(f"Failed to write index for {memory_id}, compensating: {e}")
            self.file_store.delete_memory(file_path)
            raise

        return Memory(
            id=memory_id,
            summary=summary,
            file_path=file_path,
            file_hash=file_hash,
            file_size_bytes=file_size,
            owner_id=owner_id,
            scope=data.scope,
            team_id=team_id,
            project_id=data.project_id,
            category=data.category,
            tags=data.tags,
            layer=data.layer,
            quality=质量状态.COMMUNITY,
            quality_score=0.5,
            created_at=now,
            updated_at=now,
        )

    async def get(self, memory_id: str) -> Memory | None:
        """通过 ID 获取记忆元数据。"""
        row = await self.db.fetch_one(
            "SELECT * FROM memories WHERE id = ?", (memory_id,)
        )
        if row is None:
            return None
        return self._row_to_memory(row)

    async def get_detail(self, memory_id: str) -> MemoryDetail | None:
        """获取记忆及其文件中的完整内容。"""
        memory = await self.get(memory_id)
        if memory is None:
            return None

        # 更新访问计数
        await self.db.execute(
            """UPDATE memories SET access_count = access_count + 1,
               last_accessed_at = ? WHERE id = ?""",
            (datetime.utcnow().isoformat(), memory_id),
        )
        await self.db.commit()

        # 从文件读取内容
        try:
            _, content = self.file_store.read_memory(memory.file_path)
        except FileNotFoundError:
            content = "[Content file not found]"

        return MemoryDetail(**memory.model_dump(), content=content)

    async def update(
        self,
        memory_id: str,
        data: MemoryUpdate,
        changed_by: str,
        owner_name: str | None = None,
        project_name: str | None = None,
    ) -> Memory | None:
        """更新记忆，保证文件 + 索引一致性。"""
        existing = await self.get(memory_id)
        if existing is None:
            return None

        now = datetime.utcnow()

        # 获取当前版本号
        version = await self._get_next_version(memory_id)

        # 构建更新字段
        updates: dict[str, Any] = {"updated_at": now.isoformat()}
        if data.summary is not None:
            updates["summary"] = data.summary
        if data.scope is not None:
            updates["scope"] = data.scope
        if data.category is not None:
            updates["category"] = data.category
        if data.tags is not None:
            updates["tags"] = json.dumps(data.tags)
        if data.project_id is not None:
            updates["project_id"] = data.project_id

        # 如果内容被更新，重新写入文件
        new_file_path = existing.file_path
        if data.content is not None:
            new_summary = data.summary or data.content[:200]
            updates["summary"] = new_summary

            metadata = {
                "category": data.category or existing.category,
                "tags": data.tags if data.tags is not None else existing.tags,
                "layer": existing.layer,
                "quality": existing.quality,
                "author": owner_name,
                "project": project_name,
                "created_at": existing.created_at.isoformat() if existing.created_at else None,
                "updated_at": now.isoformat(),
            }

            scope = data.scope or existing.scope
            file_path, file_hash, file_size = self.file_store.write_memory(
                memory_id=memory_id,
                content=data.content,
                metadata=metadata,
                scope=scope,
                owner_name=owner_name,
                project_name=project_name,
                created_at=existing.created_at,
            )
            updates["file_path"] = file_path
            updates["file_hash"] = file_hash
            updates["file_size_bytes"] = file_size
            new_file_path = file_path

        # 更新索引
        set_clause = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [memory_id]
        await self.db.execute(
            f"UPDATE memories SET {set_clause} WHERE id = ?",
            tuple(values),
        )
        await self.db.commit()

        # 创建版本记录
        await self._create_version(
            memory_id=memory_id,
            version=version,
            summary=updates.get("summary", existing.summary),
            file_path=new_file_path,
            changed_by=changed_by,
            change_type="updated",
        )

        return await self.get(memory_id)

    async def delete(self, memory_id: str) -> bool:
        """删除记忆（文件 + 索引）。"""
        memory = await self.get(memory_id)
        if memory is None:
            return False

        # 先删除索引（避免孤立的索引条目）
        await self.db.execute("DELETE FROM memory_versions WHERE memory_id = ?", (memory_id,))
        await self.db.execute("DELETE FROM memories WHERE id = ?", (memory_id,))
        await self.db.commit()

        # 删除文件
        self.file_store.delete_memory(memory.file_path)

        return True

    async def list_memories(
        self,
        team_id: str,
        user_id: str | None = None,
        scope: str | None = None,
        category: str | None = None,
        project_id: str | None = None,
        quality: str | None = None,
        page: int = 1,
        page_size: int = 20,
        include_private: bool = False,
    ) -> tuple[list[Memory], int]:
        """列出记忆，支持筛选和分页。

        私有数据隔离：私有记忆仅在 user_id 与所有者匹配时显示。
        """
        conditions = ["m.team_id = ?"]
        params: list[Any] = [team_id]

        # 私有数据隔离
        if not include_private:
            if user_id:
                conditions.append(
                    "(m.scope != 'private' OR m.owner_id = ?)"
                )
                params.append(user_id)
            else:
                conditions.append("m.scope != 'private'")

        if scope:
            conditions.append("m.scope = ?")
            params.append(scope)

        if category:
            conditions.append("m.category = ?")
            params.append(category)

        if project_id:
            conditions.append("m.project_id = ?")
            params.append(project_id)

        if quality:
            conditions.append("m.quality = ?")
            params.append(quality)

        # 默认排除已归档
        if quality != "archived":
            conditions.append("m.quality != 'archived'")

        where = " AND ".join(conditions)

        # 计数总数
        count_row = await self.db.fetch_one(
            f"SELECT COUNT(*) as cnt FROM memories m WHERE {where}",
            tuple(params),
        )
        total = count_row["cnt"] if count_row else 0

        # 获取分页数据
        offset = (page - 1) * page_size
        rows = await self.db.fetch_all(
            f"""SELECT * FROM memories m WHERE {where}
                ORDER BY m.updated_at DESC LIMIT ? OFFSET ?""",
            tuple(params + [page_size, offset]),
        )

        memories = [self._row_to_memory(row) for row in rows]
        return memories, total

    async def update_quality(
        self,
        memory_id: str,
        quality: str,
        changed_by: str,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        """更新记忆质量状态（生命周期转换）。"""
        now = datetime.utcnow()
        updates = {
            "quality": quality,
            "updated_at": now.isoformat(),
        }

        if quality == "verified":
            updates["verified_by"] = changed_by
            updates["verified_at"] = now.isoformat()

        if metadata and "merged_into" in metadata:
            updates["merged_into"] = metadata["merged_into"]

        set_clause = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [memory_id]

        result = await self.db.execute(
            f"UPDATE memories SET {set_clause} WHERE id = ?",
            tuple(values),
        )
        await self.db.commit()
        return result.rowcount > 0

    async def get_versions(self, memory_id: str) -> list[MemoryVersion]:
        """获取记忆的版本历史。"""
        rows = await self.db.fetch_all(
            """SELECT * FROM memory_versions WHERE memory_id = ?
               ORDER BY version DESC""",
            (memory_id,),
        )
        return [
            MemoryVersion(
                id=row["id"],
                memory_id=row["memory_id"],
                version=row["version"],
                summary=row["summary"],
                file_path=row.get("file_path"),
                changed_by=row["changed_by"],
                change_type=row["change_type"],
                diff_json=row.get("diff_json"),
                created_at=row.get("created_at"),
            )
            for row in rows
        ]

    async def _create_version(
        self,
        memory_id: str,
        version: int,
        summary: str,
        file_path: str | None,
        changed_by: str,
        change_type: str,
        diff_json: str | None = None,
    ) -> None:
        """创建版本记录。"""
        version_id = f"ver_{''.join(secrets.choice(_ID_CHARS) for _ in range(8))}"
        await self.db.execute(
            """INSERT INTO memory_versions
               (id, memory_id, version, summary, file_path, changed_by, change_type, diff_json)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (version_id, memory_id, version, summary, file_path, changed_by, change_type, diff_json),
        )
        await self.db.commit()

    async def _get_next_version(self, memory_id: str) -> int:
        """获取记忆的下一个版本号。"""
        row = await self.db.fetch_one(
            "SELECT MAX(version) as max_ver FROM memory_versions WHERE memory_id = ?",
            (memory_id,),
        )
        current = row["max_ver"] if row and row["max_ver"] else 0
        return current + 1

    @staticmethod
    def _row_to_memory(row: dict[str, Any]) -> Memory:
        """将数据库行转换为 Memory 模型。"""
        tags = row.get("tags", "[]")
        if isinstance(tags, str):
            try:
                tags = json.loads(tags)
            except json.JSONDecodeError:
                tags = []

        return Memory(
            id=row["id"],
            summary=row["summary"],
            file_path=row["file_path"],
            file_hash=row.get("file_hash"),
            file_size_bytes=row.get("file_size_bytes"),
            owner_id=row["owner_id"],
            scope=row.get("scope", "private"),
            team_id=row["team_id"],
            project_id=row.get("project_id"),
            category=row.get("category", "general"),
            tags=tags,
            layer=row.get("layer", 2),
            quality=row.get("quality", "community"),
            quality_score=row.get("quality_score", 0.5),
            verified_by=row.get("verified_by"),
            verified_at=row.get("verified_at"),
            access_count=row.get("access_count", 0),
            last_accessed_at=row.get("last_accessed_at"),
            merged_into=row.get("merged_into"),
            created_at=row.get("created_at"),
            updated_at=row.get("updated_at"),
        )
