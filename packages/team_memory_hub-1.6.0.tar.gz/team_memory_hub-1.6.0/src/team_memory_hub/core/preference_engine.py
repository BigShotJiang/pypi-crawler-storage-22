"""Preference engine: three-level priority resolution.

Priority hierarchy:
1. User explicit preferences (highest)
2. User auto-learned preferences
3. Team default preferences (lowest)
"""

from __future__ import annotations

import json
import logging
import secrets
import string
from datetime import datetime
from typing import Any

from team_memory_hub.storage.database import Database

logger = logging.getLogger(__name__)

_ID_CHARS = string.ascii_lowercase + string.digits


def _gen_id(prefix: str = "pref") -> str:
    return f"{prefix}_{''.join(secrets.choice(_ID_CHARS) for _ in range(8))}"


class PreferenceEngine:
    """Resolves user preferences with three-level priority.

    Level 1: User explicit preferences (manual set)
    Level 2: User auto-learned suggestions (accepted)
    Level 3: Team default preferences
    """

    def __init__(self, db: Database):
        self.db = db

    async def get_effective_preferences(
        self,
        user_id: str,
        team_id: str,
        category: str | None = None,
        scope: str = "global",
    ) -> dict[str, Any]:
        """Get merged effective preferences for a user.

        Merges team defaults with user preferences (user wins on conflict).
        """
        # Layer 3: Team defaults
        team_prefs = await self._get_team_defaults(team_id, category)

        # Layer 1+2: User preferences (both explicit and accepted suggestions)
        user_prefs = await self._get_user_preferences(user_id, category, scope)

        # Merge: user overrides team
        effective: dict[str, Any] = {}

        for key, value in team_prefs.items():
            effective[key] = {
                "value": value["value"],
                "source": "team_default",
                "set_by": value.get("set_by", ""),
                "category": value.get("category", category or "general"),
            }

        for key, value in user_prefs.items():
            effective[key] = {
                "value": value["value"],
                "source": "user",
                "category": value.get("category", category or "general"),
                "metadata": value.get("metadata", {}),
            }

        return effective

    async def get_preference(
        self,
        user_id: str,
        team_id: str,
        category: str,
        key: str,
        scope: str = "global",
    ) -> Any | None:
        """Get a single effective preference value."""
        prefs = await self.get_effective_preferences(user_id, team_id, category, scope)
        compound_key = f"{category}:{key}"
        if compound_key in prefs:
            return prefs[compound_key]["value"]
        return None

    # ========== User Preferences ==========

    async def set_user_preference(
        self,
        user_id: str,
        category: str,
        key: str,
        value: str,
        scope: str = "global",
        metadata: dict | None = None,
    ) -> str:
        """Set a user preference (explicit)."""
        pref_id = _gen_id("pref")
        now = datetime.utcnow().isoformat()
        meta_json = json.dumps(metadata or {})

        # Upsert
        await self.db.execute(
            """INSERT INTO user_preferences (id, user_id, category, key, value, metadata, scope, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(user_id, category, key, scope)
               DO UPDATE SET value = excluded.value, metadata = excluded.metadata,
                            is_active = 1, updated_at = excluded.updated_at""",
            (pref_id, user_id, category, key, value, meta_json, scope, now),
        )
        await self.db.commit()
        return pref_id

    async def delete_user_preference(
        self,
        user_id: str,
        category: str,
        key: str,
        scope: str = "global",
    ) -> bool:
        """删除 (deactivate) a user preference."""
        result = await self.db.execute(
            """UPDATE user_preferences SET is_active = 0, updated_at = ?
               WHERE user_id = ? AND category = ? AND key = ? AND scope = ?""",
            (datetime.utcnow().isoformat(), user_id, category, key, scope),
        )
        await self.db.commit()
        return result.rowcount > 0

    async def list_user_preferences(
        self,
        user_id: str,
        category: str | None = None,
        scope: str | None = None,
    ) -> list[dict[str, Any]]:
        """列出所有 active user preferences."""
        conditions = ["user_id = ?", "is_active = 1"]
        params: list[Any] = [user_id]

        if category:
            conditions.append("category = ?")
            params.append(category)
        if scope:
            conditions.append("scope = ?")
            params.append(scope)

        where = " AND ".join(conditions)
        return await self.db.fetch_all(
            f"SELECT * FROM user_preferences WHERE {where} ORDER BY category, key",
            tuple(params),
        )

    # ========== Team Default Preferences ==========

    async def set_team_default(
        self,
        team_id: str,
        category: str,
        key: str,
        value: str,
        set_by: str,
        metadata: dict | None = None,
    ) -> str:
        """Set a team default preference."""
        pref_id = _gen_id("tpref")
        now = datetime.utcnow().isoformat()
        meta_json = json.dumps(metadata or {})

        await self.db.execute(
            """INSERT INTO team_default_preferences
               (id, team_id, category, key, value, metadata, set_by, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(team_id, category, key)
               DO UPDATE SET value = excluded.value, metadata = excluded.metadata,
                            set_by = excluded.set_by, updated_at = excluded.updated_at""",
            (pref_id, team_id, category, key, value, meta_json, set_by, now),
        )
        await self.db.commit()
        return pref_id

    async def delete_team_default(
        self,
        team_id: str,
        category: str,
        key: str,
    ) -> bool:
        """删除 a team default preference."""
        result = await self.db.execute(
            "DELETE FROM team_default_preferences WHERE team_id = ? AND category = ? AND key = ?",
            (team_id, category, key),
        )
        await self.db.commit()
        return result.rowcount > 0

    async def list_team_defaults(
        self,
        team_id: str,
        category: str | None = None,
    ) -> list[dict[str, Any]]:
        """列出所有 team default preferences."""
        if category:
            return await self.db.fetch_all(
                "SELECT * FROM team_default_preferences WHERE team_id = ? AND category = ? ORDER BY key",
                (team_id, category),
            )
        return await self.db.fetch_all(
            "SELECT * FROM team_default_preferences WHERE team_id = ? ORDER BY category, key",
            (team_id,),
        )

    # ========== Preference Suggestions (auto-learn) ==========

    async def create_suggestion(
        self,
        user_id: str,
        category: str,
        key: str,
        value: str,
        evidence: str = "",
        source_chat: str = "",
    ) -> str:
        """Create a preference suggestion from auto-learning."""
        sug_id = _gen_id("psug")
        now = datetime.utcnow().isoformat()

        await self.db.execute(
            """INSERT INTO preference_suggestions
               (id, user_id, category, key, value, evidence, source_chat, status, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?)""",
            (sug_id, user_id, category, key, value, evidence, source_chat, now),
        )
        await self.db.commit()
        return sug_id

    async def accept_suggestion(self, suggestion_id: str, user_id: str) -> bool:
        """Accept a suggestion: apply it as a user preference."""
        row = await self.db.fetch_one(
            "SELECT * FROM preference_suggestions WHERE id = ? AND user_id = ?",
            (suggestion_id, user_id),
        )
        if not row:
            return False

        # Apply as user preference
        await self.set_user_preference(
            user_id=user_id,
            category=row["category"],
            key=row["key"],
            value=row["value"],
            metadata={"source": "suggestion", "suggestion_id": suggestion_id},
        )

        # Mark suggestion as accepted
        await self.db.execute(
            "UPDATE preference_suggestions SET status = 'accepted' WHERE id = ?",
            (suggestion_id,),
        )
        await self.db.commit()
        return True

    async def reject_suggestion(self, suggestion_id: str, user_id: str) -> bool:
        """Reject a preference suggestion."""
        result = await self.db.execute(
            "UPDATE preference_suggestions SET status = 'rejected' WHERE id = ? AND user_id = ?",
            (suggestion_id, user_id),
        )
        await self.db.commit()
        return result.rowcount > 0

    async def list_suggestions(
        self,
        user_id: str,
        status: str = "pending",
    ) -> list[dict[str, Any]]:
        """List preference suggestions for a user."""
        return await self.db.fetch_all(
            "SELECT * FROM preference_suggestions WHERE user_id = ? AND status = ? ORDER BY created_at DESC",
            (user_id, status),
        )

    # ========== Internal helpers ==========

    async def _get_user_preferences(
        self,
        user_id: str,
        category: str | None = None,
        scope: str = "global",
    ) -> dict[str, dict[str, Any]]:
        """Get user preferences as a dict keyed by category:key."""
        conditions = ["user_id = ?", "is_active = 1"]
        params: list[Any] = [user_id]

        if category:
            conditions.append("category = ?")
            params.append(category)

        # Include global scope and the requested scope
        if scope != "global":
            conditions.append("(scope = 'global' OR scope = ?)")
            params.append(scope)

        where = " AND ".join(conditions)
        rows = await self.db.fetch_all(
            f"SELECT * FROM user_preferences WHERE {where}",
            tuple(params),
        )

        result: dict[str, dict[str, Any]] = {}
        for row in rows:
            compound_key = f"{row['category']}:{row['key']}"
            meta = row.get("metadata", "{}")
            if isinstance(meta, str):
                try:
                    meta = json.loads(meta)
                except json.JSONDecodeError:
                    meta = {}
            result[compound_key] = {
                "value": row["value"],
                "category": row["category"],
                "scope": row.get("scope", "global"),
                "metadata": meta,
            }
        return result

    async def _get_team_defaults(
        self,
        team_id: str,
        category: str | None = None,
    ) -> dict[str, dict[str, Any]]:
        """Get team defaults as a dict keyed by category:key."""
        if category:
            rows = await self.db.fetch_all(
                "SELECT * FROM team_default_preferences WHERE team_id = ? AND category = ?",
                (team_id, category),
            )
        else:
            rows = await self.db.fetch_all(
                "SELECT * FROM team_default_preferences WHERE team_id = ?",
                (team_id,),
            )

        result: dict[str, dict[str, Any]] = {}
        for row in rows:
            compound_key = f"{row['category']}:{row['key']}"
            result[compound_key] = {
                "value": row["value"],
                "category": row["category"],
                "set_by": row.get("set_by", ""),
            }
        return result
