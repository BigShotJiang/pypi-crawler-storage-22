"""Project detection: scan project directories to build a ProjectProfile.

Detects languages, frameworks, package managers, Docker, CI/CD configurations.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class ProjectProfile:
    """Detected project profile from directory scanning."""

    root_path: str
    name: str
    languages: list[str] = field(default_factory=list)
    frameworks: list[str] = field(default_factory=list)
    package_managers: list[str] = field(default_factory=list)
    has_docker: bool = False
    docker_files: list[str] = field(default_factory=list)
    ci_providers: list[str] = field(default_factory=list)
    ci_files: list[str] = field(default_factory=list)
    linters: list[str] = field(default_factory=list)
    formatters: list[str] = field(default_factory=list)
    config_files: list[str] = field(default_factory=list)
    test_frameworks: list[str] = field(default_factory=list)
    monorepo: bool = False

    def to_dict(self) -> dict:
        from dataclasses import asdict
        return asdict(self)


# File patterns -> language detection
_LANGUAGE_INDICATORS: dict[str, list[str]] = {
    "python": ["*.py", "pyproject.toml", "setup.py", "setup.cfg", "Pipfile", "requirements.txt"],
    "javascript": ["*.js", "*.mjs", "*.cjs", "package.json"],
    "typescript": ["*.ts", "*.tsx", "tsconfig.json"],
    "go": ["*.go", "go.mod", "go.sum"],
    "rust": ["*.rs", "Cargo.toml"],
    "java": ["*.java", "pom.xml", "build.gradle"],
    "kotlin": ["*.kt", "*.kts"],
    "ruby": ["*.rb", "Gemfile"],
    "php": ["*.php", "composer.json"],
    "csharp": ["*.cs", "*.csproj", "*.sln"],
    "swift": ["*.swift", "Package.swift"],
    "dart": ["*.dart", "pubspec.yaml"],
    "elixir": ["*.ex", "*.exs", "mix.exs"],
}

# Framework detection: (file_or_pattern, content_match_optional) -> framework name
_FRAMEWORK_FILES: dict[str, str] = {
    "next.config.js": "next.js",
    "next.config.mjs": "next.js",
    "next.config.ts": "next.js",
    "nuxt.config.ts": "nuxt",
    "nuxt.config.js": "nuxt",
    "angular.json": "angular",
    "svelte.config.js": "svelte",
    "astro.config.mjs": "astro",
    "remix.config.js": "remix",
    "vite.config.ts": "vite",
    "vite.config.js": "vite",
    "webpack.config.js": "webpack",
    "tailwind.config.js": "tailwind",
    "tailwind.config.ts": "tailwind",
    "manage.py": "django",
    "settings.py": "django",
    "app.py": "flask",
    "Cargo.toml": "rust",
    "go.mod": "go",
    "mix.exs": "phoenix",
    "Gemfile": "rails",
}

# Package manager detection
_PACKAGE_MANAGER_FILES: dict[str, str] = {
    "package-lock.json": "npm",
    "yarn.lock": "yarn",
    "pnpm-lock.yaml": "pnpm",
    "bun.lockb": "bun",
    "Pipfile.lock": "pipenv",
    "poetry.lock": "poetry",
    "uv.lock": "uv",
    "pdm.lock": "pdm",
    "Cargo.lock": "cargo",
    "go.sum": "go",
    "Gemfile.lock": "bundler",
    "composer.lock": "composer",
    "pubspec.lock": "pub",
}

# Docker detection
_DOCKER_FILES = ["Dockerfile", "docker-compose.yml", "docker-compose.yaml", ".dockerignore"]

# CI/CD detection
_CI_PATTERNS: dict[str, list[str]] = {
    "github-actions": [".github/workflows"],
    "gitlab-ci": [".gitlab-ci.yml"],
    "circleci": [".circleci/config.yml"],
    "jenkins": ["Jenkinsfile"],
    "travis": [".travis.yml"],
    "azure-pipelines": ["azure-pipelines.yml"],
    "bitbucket-pipelines": ["bitbucket-pipelines.yml"],
}

# Linter/formatter detection
_LINTER_FILES: dict[str, str] = {
    ".eslintrc.js": "eslint",
    ".eslintrc.json": "eslint",
    ".eslintrc.yml": "eslint",
    ".eslintrc.yaml": "eslint",
    "eslint.config.js": "eslint",
    "eslint.config.mjs": "eslint",
    ".prettierrc": "prettier",
    ".prettierrc.json": "prettier",
    ".prettierrc.js": "prettier",
    "ruff.toml": "ruff",
    ".flake8": "flake8",
    ".pylintrc": "pylint",
    "mypy.ini": "mypy",
    ".editorconfig": "editorconfig",
    "biome.json": "biome",
    ".stylelintrc": "stylelint",
    "rustfmt.toml": "rustfmt",
    ".golangci.yml": "golangci-lint",
    ".golangci.yaml": "golangci-lint",
}

# Test framework detection
_TEST_FRAMEWORK_FILES: dict[str, str] = {
    "jest.config.js": "jest",
    "jest.config.ts": "jest",
    "vitest.config.ts": "vitest",
    "vitest.config.js": "vitest",
    "pytest.ini": "pytest",
    "conftest.py": "pytest",
    ".mocharc.yml": "mocha",
    "karma.conf.js": "karma",
    "cypress.config.js": "cypress",
    "cypress.config.ts": "cypress",
    "playwright.config.ts": "playwright",
    "playwright.config.js": "playwright",
}


class ProjectDetector:
    """Scans a project directory to detect languages, frameworks, and tools."""

    def __init__(self, root_path: str | Path):
        self.root = Path(root_path).resolve()

    def detect(self) -> ProjectProfile:
        """Run full project detection and return a ProjectProfile."""
        profile = ProjectProfile(
            root_path=str(self.root),
            name=self.root.name,
        )

        self._detect_languages(profile)
        self._detect_frameworks(profile)
        self._detect_package_managers(profile)
        self._detect_docker(profile)
        self._detect_ci(profile)
        self._detect_linters(profile)
        self._detect_test_frameworks(profile)
        self._detect_monorepo(profile)
        self._detect_framework_from_deps(profile)

        # Collect all detected config files
        profile.config_files = self._collect_config_files()

        return profile

    def _file_exists(self, name: str) -> bool:
        return (self.root / name).exists()

    def _dir_exists(self, name: str) -> bool:
        return (self.root / name).is_dir()

    def _has_files_with_ext(self, ext: str, max_depth: int = 2) -> bool:
        """Check if any files with the given extension exist (limited depth)."""
        for item in self._walk_limited(max_depth):
            if item.suffix == ext and item.is_file():
                return True
        return False

    def _walk_limited(self, max_depth: int = 2):
        """Walk directory tree with depth limit to avoid deep traversal."""
        skip_dirs = {
            "node_modules", ".git", "__pycache__", ".venv", "venv",
            "dist", "build", ".next", ".nuxt", "target", "vendor",
        }

        def _walk(path: Path, depth: int):
            if depth > max_depth:
                return
            try:
                for item in path.iterdir():
                    if item.is_dir() and item.name in skip_dirs:
                        continue
                    yield item
                    if item.is_dir() and depth < max_depth:
                        yield from _walk(item, depth + 1)
            except PermissionError:
                pass

        yield from _walk(self.root, 0)

    def _detect_languages(self, profile: ProjectProfile) -> None:
        for lang, indicators in _LANGUAGE_INDICATORS.items():
            for indicator in indicators:
                if indicator.startswith("*."):
                    ext = indicator[1:]  # e.g. ".py"
                    if self._has_files_with_ext(ext):
                        if lang not in profile.languages:
                            profile.languages.append(lang)
                        break
                else:
                    if self._file_exists(indicator):
                        if lang not in profile.languages:
                            profile.languages.append(lang)
                        break

    def _detect_frameworks(self, profile: ProjectProfile) -> None:
        for filename, framework in _FRAMEWORK_FILES.items():
            if self._file_exists(filename):
                if framework not in profile.frameworks:
                    profile.frameworks.append(framework)

    def _detect_framework_from_deps(self, profile: ProjectProfile) -> None:
        """Detect frameworks from package.json dependencies."""
        pkg_path = self.root / "package.json"
        if pkg_path.exists():
            try:
                data = json.loads(pkg_path.read_text(encoding="utf-8"))
                all_deps = {}
                all_deps.update(data.get("dependencies", {}))
                all_deps.update(data.get("devDependencies", {}))

                dep_framework_map = {
                    "react": "react",
                    "vue": "vue",
                    "svelte": "svelte",
                    "@angular/core": "angular",
                    "express": "express",
                    "fastify": "fastify",
                    "koa": "koa",
                    "hono": "hono",
                    "electron": "electron",
                }

                for dep, fw in dep_framework_map.items():
                    if dep in all_deps and fw not in profile.frameworks:
                        profile.frameworks.append(fw)
            except (json.JSONDecodeError, OSError):
                pass

        # pyproject.toml dependencies
        pyproject = self.root / "pyproject.toml"
        if pyproject.exists():
            try:
                content = pyproject.read_text(encoding="utf-8")
                py_fw_keywords = {
                    "fastapi": "fastapi",
                    "django": "django",
                    "flask": "flask",
                    "starlette": "starlette",
                    "tornado": "tornado",
                    "aiohttp": "aiohttp",
                }
                for keyword, fw in py_fw_keywords.items():
                    if keyword in content.lower() and fw not in profile.frameworks:
                        profile.frameworks.append(fw)
            except OSError:
                pass

    def _detect_package_managers(self, profile: ProjectProfile) -> None:
        for filename, pm in _PACKAGE_MANAGER_FILES.items():
            if self._file_exists(filename):
                if pm not in profile.package_managers:
                    profile.package_managers.append(pm)

        # Detect from pyproject.toml build system
        pyproject = self.root / "pyproject.toml"
        if pyproject.exists():
            try:
                content = pyproject.read_text(encoding="utf-8")
                if "hatchling" in content:
                    if "hatch" not in profile.package_managers:
                        profile.package_managers.append("hatch")
                if "setuptools" in content:
                    if "setuptools" not in profile.package_managers:
                        profile.package_managers.append("setuptools")
            except OSError:
                pass

    def _detect_docker(self, profile: ProjectProfile) -> None:
        for df in _DOCKER_FILES:
            if self._file_exists(df):
                profile.has_docker = True
                profile.docker_files.append(df)

    def _detect_ci(self, profile: ProjectProfile) -> None:
        for provider, patterns in _CI_PATTERNS.items():
            for pattern in patterns:
                if self._file_exists(pattern) or self._dir_exists(pattern):
                    if provider not in profile.ci_providers:
                        profile.ci_providers.append(provider)
                    profile.ci_files.append(pattern)

    def _detect_linters(self, profile: ProjectProfile) -> None:
        for filename, linter in _LINTER_FILES.items():
            if self._file_exists(filename):
                if linter not in profile.linters:
                    profile.linters.append(linter)
                # Classify as formatter if applicable
                if linter in ("prettier", "rustfmt", "biome"):
                    if linter not in profile.formatters:
                        profile.formatters.append(linter)

        # Check pyproject.toml for tool configs
        pyproject = self.root / "pyproject.toml"
        if pyproject.exists():
            try:
                content = pyproject.read_text(encoding="utf-8")
                if "[tool.ruff]" in content and "ruff" not in profile.linters:
                    profile.linters.append("ruff")
                if "[tool.mypy]" in content and "mypy" not in profile.linters:
                    profile.linters.append("mypy")
                if "[tool.black]" in content:
                    if "black" not in profile.formatters:
                        profile.formatters.append("black")
                if "[tool.isort]" in content:
                    if "isort" not in profile.linters:
                        profile.linters.append("isort")
                if "[tool.pytest" in content and "pytest" not in profile.test_frameworks:
                    profile.test_frameworks.append("pytest")
            except OSError:
                pass

    def _detect_test_frameworks(self, profile: ProjectProfile) -> None:
        for filename, tf in _TEST_FRAMEWORK_FILES.items():
            if self._file_exists(filename):
                if tf not in profile.test_frameworks:
                    profile.test_frameworks.append(tf)

    def _detect_monorepo(self, profile: ProjectProfile) -> None:
        """Detect if the project is a monorepo."""
        monorepo_indicators = [
            "lerna.json",
            "nx.json",
            "turbo.json",
            "pnpm-workspace.yaml",
        ]
        for indicator in monorepo_indicators:
            if self._file_exists(indicator):
                profile.monorepo = True
                return

        # Check package.json for workspaces
        pkg_path = self.root / "package.json"
        if pkg_path.exists():
            try:
                data = json.loads(pkg_path.read_text(encoding="utf-8"))
                if "workspaces" in data:
                    profile.monorepo = True
            except (json.JSONDecodeError, OSError):
                pass

    def _collect_config_files(self) -> list[str]:
        """Collect names of all configuration files found."""
        config_names = set()
        common_configs = [
            ".editorconfig", ".gitignore", ".gitattributes",
            "pyproject.toml", "setup.py", "setup.cfg",
            "package.json", "tsconfig.json",
            "Makefile", "justfile",
            ".env.example", ".env.template",
        ]
        for name in common_configs:
            if self._file_exists(name):
                config_names.add(name)
        return sorted(config_names)
