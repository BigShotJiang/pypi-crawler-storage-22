"""RBAC：基于角色的访问控制，四级层级结构。

层级：admin > maintainer > member > viewer
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import IntEnum
from typing import TYPE_CHECKING, Any

from team_memory_hub.storage.models import UserRole

if TYPE_CHECKING:
    from team_memory_hub.storage.database import Database


class RoleLevel(IntEnum):
    """数值角色级别，用于比较。"""
    VIEWER = 0
    MEMBER = 1
    MAINTAINER = 2
    ADMIN = 3


# 将角色字符串映射到数值级别
ROLE_LEVELS: dict[str, RoleLevel] = {
    UserRole.VIEWER: RoleLevel.VIEWER,
    UserRole.MEMBER: RoleLevel.MEMBER,
    UserRole.MAINTAINER: RoleLevel.MAINTAINER,
    UserRole.ADMIN: RoleLevel.ADMIN,
}


def get_role_level(role: str) -> RoleLevel:
    """获取角色字符串的数值级别。"""
    return ROLE_LEVELS.get(role, RoleLevel.VIEWER)


def has_minimum_role(user_role: str, required_role: str) -> bool:
    """检查用户角色是否满足最低要求的角色。"""
    return get_role_level(user_role) >= get_role_level(required_role)


# 权限定义：操作 -> 最低要求的角色
PERMISSIONS: dict[str, str] = {
    # 记忆操作
    "memory:read_team": UserRole.VIEWER,
    "memory:write_team": UserRole.MEMBER,
    "memory:write_layer0": UserRole.MAINTAINER,
    "memory:delete_any": UserRole.ADMIN,

    # 质量操作
    "memory:verify": UserRole.MAINTAINER,
    "memory:pin": UserRole.MAINTAINER,

    # 规范操作
    "spec:create_proposal": UserRole.MEMBER,
    "spec:merge_proposal": UserRole.MAINTAINER,

    # 合并建议 (V1.5)
    "consolidation:review": UserRole.MAINTAINER,
    "consolidation:scan": UserRole.ADMIN,

    # 用户管理
    "user:manage": UserRole.ADMIN,
    "user:manage_roles": UserRole.ADMIN,

    # 团队偏好
    "team:set_preferences": UserRole.MAINTAINER,

    # API Key 管理（用户管理自己的密钥）
    "key:create": UserRole.MEMBER,

    # ========== V1.6 管理后台权限 ==========

    # 团队管理
    "team:create": UserRole.ADMIN,
    "team:update": UserRole.ADMIN,
    "team:delete": UserRole.ADMIN,
    "team:list": UserRole.MAINTAINER,

    # 项目管理
    "project:create": UserRole.MAINTAINER,
    "project:update": UserRole.MAINTAINER,
    "project:delete": UserRole.ADMIN,
    "project:list": UserRole.MEMBER,

    # 用户管理（细粒度）
    "user:create": UserRole.ADMIN,
    "user:update": UserRole.ADMIN,
    "user:delete": UserRole.ADMIN,
    "user:list": UserRole.ADMIN,
    "user:toggle_active": UserRole.ADMIN,

    # API Key 管理（全局）
    "key:list_all": UserRole.ADMIN,
    "key:revoke_any": UserRole.ADMIN,

    # 记忆审核
    "curation:batch_verify": UserRole.MAINTAINER,
    "curation:batch_archive": UserRole.MAINTAINER,
    "curation:quality_override": UserRole.ADMIN,

    # 系统配置
    "system:view_config": UserRole.ADMIN,
    "system:update_config": UserRole.ADMIN,
}


def check_permission(user_role: str, action: str) -> bool:
    """检查给定角色的用户是否有权执行该操作（同步，仅角色检查）。"""
    required = PERMISSIONS.get(action)
    if required is None:
        return False
    return has_minimum_role(user_role, required)


async def check_permission_with_overrides(
    user_role: str,
    action: str,
    user_id: str,
    db: Database,
) -> bool:
    """检查权限，支持用户级覆盖。

    优先级：覆盖（未过期）> 角色默认权限。
    """
    row = await db.fetch_one(
        "SELECT type, expires_at FROM permission_overrides WHERE user_id = ? AND permission = ?",
        (user_id, action),
    )
    if row is not None:
        # 检查是否过期
        if row.get("expires_at"):
            expires = datetime.fromisoformat(row["expires_at"])
            if expires.tzinfo is None:
                expires = expires.replace(tzinfo=timezone.utc)
            if expires < datetime.now(timezone.utc):
                # 过期，回退到角色默认
                return check_permission(user_role, action)
        return row["type"] == "allow"

    return check_permission(user_role, action)


def can_access_memory(
    user_id: str,
    user_role: str,
    user_team_id: str,
    memory_owner_id: str,
    memory_scope: str,
    memory_team_id: str,
) -> bool:
    """检查用户是否可以读取特定记忆。

    规则：
    - 私有记忆：仅所有者
    - 项目/团队记忆：同一团队 + viewer 或更高权限
    - 管理员可以读取其团队中的一切
    """
    # 不同团队：无访问权限
    if user_team_id != memory_team_id:
        return False

    # 私有范围：仅所有者
    if memory_scope == "private":
        return user_id == memory_owner_id

    # 团队/项目范围：同一团队中 viewer 或更高权限
    return has_minimum_role(user_role, UserRole.VIEWER)


def can_modify_memory(
    user_id: str,
    user_role: str,
    user_team_id: str,
    memory_owner_id: str,
    memory_scope: str,
    memory_team_id: str,
) -> bool:
    """检查用户是否可以修改特定记忆。

    规则：
    - 私有记忆：仅所有者
    - 团队/项目记忆：所有者或 maintainer+
    - 管理员可以修改其团队中的任何内容
    """
    if user_team_id != memory_team_id:
        return False

    if memory_scope == "private":
        return user_id == memory_owner_id

    # 所有者始终可以修改自己的
    if user_id == memory_owner_id:
        return True

    # Maintainer+ 可以修改团队/项目记忆
    return has_minimum_role(user_role, UserRole.MAINTAINER)


def can_delete_memory(
    user_id: str,
    user_role: str,
    user_team_id: str,
    memory_owner_id: str,
    memory_scope: str,
    memory_team_id: str,
) -> bool:
    """检查用户是否可以删除特定记忆。

    规则：
    - 私有记忆：仅所有者
    - 团队/项目记忆：仅管理员（或所有者的自己的）
    """
    if user_team_id != memory_team_id:
        return False

    if memory_scope == "private":
        return user_id == memory_owner_id

    # 所有者可以删除自己的
    if user_id == memory_owner_id:
        return True

    # 仅管理员可以删除他人的记忆
    return has_minimum_role(user_role, UserRole.ADMIN)
