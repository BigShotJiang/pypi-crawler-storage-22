"""Rule normalization: convert editorconfig/ruff/eslint configs to a standard format.

Reads project linter and editor configuration files and produces NormalizedRule objects.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class NormalizedRule:
    """A single normalized rule extracted from a project config file."""

    source: str  # e.g. "editorconfig", "ruff", "eslint", "prettier"
    category: str  # e.g. "formatting", "linting", "style"
    key: str  # e.g. "indent_style", "max_line_length"
    value: Any  # e.g. "spaces", 100
    file_pattern: str = "*"  # file glob the rule applies to
    severity: str = "info"  # "error", "warning", "info"
    raw_key: str = ""  # original key before normalization
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "source": self.source,
            "category": self.category,
            "key": self.key,
            "value": self.value,
            "file_pattern": self.file_pattern,
            "severity": self.severity,
            "raw_key": self.raw_key,
            "metadata": self.metadata,
        }


class RuleNormalizer:
    """Reads project configuration files and normalizes rules to a standard format."""

    def __init__(self, root_path: str | Path):
        self.root = Path(root_path).resolve()

    def normalize_all(self) -> list[NormalizedRule]:
        """Read all known config files and return normalized rules."""
        rules: list[NormalizedRule] = []

        rules.extend(self._parse_editorconfig())
        rules.extend(self._parse_ruff())
        rules.extend(self._parse_eslint())
        rules.extend(self._parse_prettier())
        rules.extend(self._parse_pyproject_tools())

        return rules

    def _parse_editorconfig(self) -> list[NormalizedRule]:
        """Parse .editorconfig into normalized rules."""
        ec_path = self.root / ".editorconfig"
        if not ec_path.exists():
            return []

        rules: list[NormalizedRule] = []
        current_pattern = "*"

        try:
            content = ec_path.read_text(encoding="utf-8")
            for line in content.splitlines():
                line = line.strip()
                if not line or line.startswith("#") or line.startswith(";"):
                    continue

                if line.startswith("[") and line.endswith("]"):
                    current_pattern = line[1:-1]
                    continue

                if "=" in line:
                    key, _, value = line.partition("=")
                    key = key.strip().lower()
                    value = value.strip()

                    norm_key = self._normalize_editorconfig_key(key)
                    if norm_key:
                        rules.append(NormalizedRule(
                            source="editorconfig",
                            category="formatting",
                            key=norm_key,
                            value=self._coerce_value(value),
                            file_pattern=current_pattern,
                            raw_key=key,
                        ))
        except OSError as e:
            logger.warning("Failed to parse .editorconfig: %s", e)

        return rules

    @staticmethod
    def _normalize_editorconfig_key(key: str) -> str | None:
        """Map editorconfig keys to normalized key names."""
        mapping = {
            "indent_style": "indent_style",
            "indent_size": "indent_size",
            "tab_width": "tab_width",
            "end_of_line": "line_ending",
            "charset": "charset",
            "trim_trailing_whitespace": "trim_trailing_whitespace",
            "insert_final_newline": "insert_final_newline",
            "max_line_length": "max_line_length",
        }
        return mapping.get(key)

    def _parse_ruff(self) -> list[NormalizedRule]:
        """Parse ruff configuration from ruff.toml or pyproject.toml."""
        rules: list[NormalizedRule] = []

        # Try ruff.toml first
        ruff_path = self.root / "ruff.toml"
        if ruff_path.exists():
            try:
                import tomllib
            except ImportError:
                import tomli as tomllib  # type: ignore[no-redef]

            try:
                with open(ruff_path, "rb") as f:
                    data = tomllib.load(f)
                rules.extend(self._extract_ruff_rules(data))
            except Exception as e:
                logger.warning("Failed to parse ruff.toml: %s", e)
            return rules

        # Fall back to pyproject.toml [tool.ruff]
        pyproject = self.root / "pyproject.toml"
        if pyproject.exists():
            try:
                import tomllib
            except ImportError:
                import tomli as tomllib  # type: ignore[no-redef]

            try:
                with open(pyproject, "rb") as f:
                    data = tomllib.load(f)
                ruff_config = data.get("tool", {}).get("ruff", {})
                if ruff_config:
                    rules.extend(self._extract_ruff_rules(ruff_config))
            except Exception as e:
                logger.warning("Failed to parse pyproject.toml for ruff: %s", e)

        return rules

    def _extract_ruff_rules(self, data: dict) -> list[NormalizedRule]:
        """Extract normalized rules from ruff config dict."""
        rules: list[NormalizedRule] = []

        if "line-length" in data:
            rules.append(NormalizedRule(
                source="ruff",
                category="formatting",
                key="max_line_length",
                value=data["line-length"],
                file_pattern="*.py",
                raw_key="line-length",
            ))

        if "target-version" in data:
            rules.append(NormalizedRule(
                source="ruff",
                category="compatibility",
                key="python_version",
                value=data["target-version"],
                file_pattern="*.py",
                raw_key="target-version",
            ))

        # lint.select / lint.ignore
        lint = data.get("lint", {})
        if "select" in lint:
            rules.append(NormalizedRule(
                source="ruff",
                category="linting",
                key="enabled_rules",
                value=lint["select"],
                file_pattern="*.py",
                raw_key="lint.select",
            ))

        if "ignore" in lint:
            rules.append(NormalizedRule(
                source="ruff",
                category="linting",
                key="ignored_rules",
                value=lint["ignore"],
                file_pattern="*.py",
                raw_key="lint.ignore",
            ))

        # format section
        fmt = data.get("format", {})
        if "quote-style" in fmt:
            rules.append(NormalizedRule(
                source="ruff",
                category="formatting",
                key="quote_style",
                value=fmt["quote-style"],
                file_pattern="*.py",
                raw_key="format.quote-style",
            ))

        if "indent-style" in fmt:
            rules.append(NormalizedRule(
                source="ruff",
                category="formatting",
                key="indent_style",
                value=fmt["indent-style"],
                file_pattern="*.py",
                raw_key="format.indent-style",
            ))

        return rules

    def _parse_eslint(self) -> list[NormalizedRule]:
        """Parse ESLint configuration."""
        rules: list[NormalizedRule] = []

        # Try JSON configs
        for name in [".eslintrc.json", ".eslintrc"]:
            path = self.root / name
            if path.exists():
                try:
                    data = json.loads(path.read_text(encoding="utf-8"))
                    rules.extend(self._extract_eslint_rules(data))
                    return rules
                except (json.JSONDecodeError, OSError) as e:
                    logger.warning("Failed to parse %s: %s", name, e)

        # Try flat config (eslint.config.js / eslint.config.mjs) - can't parse JS directly,
        # but we note its existence
        for name in ["eslint.config.js", "eslint.config.mjs"]:
            if (self.root / name).exists():
                rules.append(NormalizedRule(
                    source="eslint",
                    category="linting",
                    key="config_type",
                    value="flat_config",
                    file_pattern="*.{js,ts,jsx,tsx}",
                    raw_key=name,
                    metadata={"note": "Flat config detected, rules not parsed from JS"},
                ))
                return rules

        return rules

    def _extract_eslint_rules(self, data: dict) -> list[NormalizedRule]:
        """Extract normalized rules from eslint JSON config."""
        rules: list[NormalizedRule] = []
        pattern = "*.{js,ts,jsx,tsx}"

        eslint_rules = data.get("rules", {})
        for rule_key, rule_value in eslint_rules.items():
            severity = "info"
            value = rule_value

            if isinstance(rule_value, list) and len(rule_value) > 0:
                sev = rule_value[0]
                value = rule_value[1] if len(rule_value) > 1 else True
                if sev == 2 or sev == "error":
                    severity = "error"
                elif sev == 1 or sev == "warn":
                    severity = "warning"
            elif rule_value == 2 or rule_value == "error":
                severity = "error"
                value = True
            elif rule_value == 1 or rule_value == "warn":
                severity = "warning"
                value = True

            norm_key = self._normalize_eslint_key(rule_key)
            rules.append(NormalizedRule(
                source="eslint",
                category="linting",
                key=norm_key,
                value=value,
                file_pattern=pattern,
                severity=severity,
                raw_key=rule_key,
            ))

        # Extended configs
        if "extends" in data:
            extends = data["extends"]
            if isinstance(extends, str):
                extends = [extends]
            rules.append(NormalizedRule(
                source="eslint",
                category="linting",
                key="extends",
                value=extends,
                file_pattern=pattern,
                raw_key="extends",
            ))

        return rules

    @staticmethod
    def _normalize_eslint_key(key: str) -> str:
        """Normalize an eslint rule key."""
        replacements = {
            "indent": "indent_size",
            "semi": "semicolons",
            "quotes": "quote_style",
            "max-len": "max_line_length",
            "no-unused-vars": "no_unused_vars",
            "no-console": "no_console",
        }
        return replacements.get(key, key.replace("-", "_"))

    def _parse_prettier(self) -> list[NormalizedRule]:
        """Parse Prettier configuration."""
        for name in [".prettierrc", ".prettierrc.json"]:
            path = self.root / name
            if path.exists():
                try:
                    data = json.loads(path.read_text(encoding="utf-8"))
                    return self._extract_prettier_rules(data)
                except (json.JSONDecodeError, OSError) as e:
                    logger.warning("Failed to parse %s: %s", name, e)
        return []

    def _extract_prettier_rules(self, data: dict) -> list[NormalizedRule]:
        """Extract normalized rules from prettier config."""
        rules: list[NormalizedRule] = []
        pattern = "*.{js,ts,jsx,tsx,json,css,md}"

        key_map = {
            "tabWidth": ("indent_size", "formatting"),
            "useTabs": ("indent_style", "formatting"),
            "semi": ("semicolons", "formatting"),
            "singleQuote": ("quote_style", "formatting"),
            "printWidth": ("max_line_length", "formatting"),
            "trailingComma": ("trailing_comma", "formatting"),
            "bracketSpacing": ("bracket_spacing", "formatting"),
            "endOfLine": ("line_ending", "formatting"),
        }

        for raw_key, (norm_key, category) in key_map.items():
            if raw_key in data:
                value = data[raw_key]
                # Normalize useTabs to indent_style
                if raw_key == "useTabs":
                    value = "tab" if value else "space"
                if raw_key == "singleQuote":
                    value = "single" if value else "double"

                rules.append(NormalizedRule(
                    source="prettier",
                    category=category,
                    key=norm_key,
                    value=value,
                    file_pattern=pattern,
                    raw_key=raw_key,
                ))

        return rules

    def _parse_pyproject_tools(self) -> list[NormalizedRule]:
        """Parse additional tools from pyproject.toml (black, isort, mypy)."""
        pyproject = self.root / "pyproject.toml"
        if not pyproject.exists():
            return []

        try:
            import tomllib
        except ImportError:
            import tomli as tomllib  # type: ignore[no-redef]

        rules: list[NormalizedRule] = []
        try:
            with open(pyproject, "rb") as f:
                data = tomllib.load(f)
        except Exception:
            return rules

        tools = data.get("tool", {})

        # black
        black = tools.get("black", {})
        if "line-length" in black:
            rules.append(NormalizedRule(
                source="black",
                category="formatting",
                key="max_line_length",
                value=black["line-length"],
                file_pattern="*.py",
                raw_key="line-length",
            ))

        # isort
        isort = tools.get("isort", {})
        if "profile" in isort:
            rules.append(NormalizedRule(
                source="isort",
                category="formatting",
                key="import_sort_profile",
                value=isort["profile"],
                file_pattern="*.py",
                raw_key="profile",
            ))

        # mypy
        mypy = tools.get("mypy", {})
        if "strict" in mypy:
            rules.append(NormalizedRule(
                source="mypy",
                category="type_checking",
                key="strict_mode",
                value=mypy["strict"],
                file_pattern="*.py",
                raw_key="strict",
            ))

        return rules

    @staticmethod
    def _coerce_value(value: str) -> Any:
        """Coerce string values to appropriate Python types."""
        lower = value.lower()
        if lower in ("true", "yes"):
            return True
        if lower in ("false", "no"):
            return False
        try:
            return int(value)
        except ValueError:
            pass
        return value
