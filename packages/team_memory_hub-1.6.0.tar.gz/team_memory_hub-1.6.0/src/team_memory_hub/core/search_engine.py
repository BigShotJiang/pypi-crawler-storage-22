"""混合搜索引擎：向量（sqlite-vec）+ BM25（FTS5）分数融合。"""

from __future__ import annotations

import json
import logging
import struct
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from typing import Any

from team_memory_hub.providers.embedding.base import EmbeddingProvider
from team_memory_hub.storage.database import Database

logger = logging.getLogger(__name__)


@dataclass
class SearchResult:
    """单个搜索结果及其融合分数。"""
    id: str
    summary: str
    score: float
    scope: str = "private"
    category: str = "general"
    project_id: str | None = None
    quality: str = "community"
    tags: list[str] = field(default_factory=list)
    created_at: str | None = None
    updated_at: str | None = None
    owner_id: str = ""
    team_id: str = ""
    layer: int = 2
    file_path: str = ""


class HybridSearchEngine:
    """两阶段混合搜索：向量 + BM25，带有上下文后处理。

    第 1 阶段：并行双引擎搜索（向量 KNN + FTS5 BM25）
    第 2 阶段：分数融合（最小值-最大值归一化 -> 加权组合）
    第 3 阶段：上下文感知后处理（项目提升、时间衰减、已验证提升）
    """

    def __init__(
        self,
        db: Database,
        embedding_provider: EmbeddingProvider,
        semantic_weight: float = 0.7,
        keyword_weight: float = 0.3,
    ):
        self.db = db
        self.embedding = embedding_provider
        self.semantic_weight = semantic_weight
        self.keyword_weight = keyword_weight
        self._vec_available: bool | None = None

    async def search(
        self,
        query: str,
        team_id: str,
        user_id: str | None = None,
        scope: str | None = None,
        category: str | None = None,
        project_id: str | None = None,
        limit: int = 10,
        mode: str = "hybrid",
    ) -> list[SearchResult]:
        """执行混合搜索并返回排序结果。

        参数：
            query: 搜索查询文本。
            team_id: 搜索的团队范围。
            user_id: 当前用户 ID（用于私有数据隔离）。
            scope: 按记忆范围筛选。
            category: 按记忆类别筛选。
            project_id: 按项目 ID 筛选。
            limit: 返回的最大结果数。
            mode: 搜索模式 - "hybrid"、"vector_only" 或 "bm25_only"。

        Returns:
            Sorted list of SearchResult, highest score first.
        """
        candidate_limit = limit * 3

        vec_results: dict[str, float] = {}
        bm25_results: dict[str, float] = {}

        # Stage 1: Dual-engine search
        if mode in ("hybrid", "vector_only"):
            vec_results = await self._vector_search(
                query, team_id, user_id, scope, category, project_id, candidate_limit
            )

        if mode in ("hybrid", "bm25_only"):
            bm25_results = await self._bm25_search(
                query, team_id, user_id, scope, category, project_id, candidate_limit
            )

        # Stage 2: 分数融合
        all_ids = set(vec_results.keys()) | set(bm25_results.keys())
        if not all_ids:
            return []

        vec_normalized = self._normalize_scores(vec_results)
        bm25_normalized = self._normalize_scores(bm25_results)

        fused: dict[str, float] = {}
        for mid in all_ids:
            vec_score = vec_normalized.get(mid, 0.0)
            bm25_score = bm25_normalized.get(mid, 0.0)
            fused[mid] = (
                self.semantic_weight * vec_score + self.keyword_weight * bm25_score
            )

        # Fetch metadata for all candidates
        results = await self._fetch_metadata(list(fused.keys()))

        # Apply fused scores
        for r in results:
            r.score = fused.get(r.id, 0.0)

        # Stage 3: Post-processing boosts
        results = self._apply_boosts(results, project_id)

        # Sort and truncate
        results.sort(key=lambda r: r.score, reverse=True)
        return results[:limit]

    async def _vector_search(
        self,
        query: str,
        team_id: str,
        user_id: str | None,
        scope: str | None,
        category: str | None,
        project_id: str | None,
        limit: int,
    ) -> dict[str, float]:
        """KNN vector search using sqlite-vec extension."""
        if not await self._is_vec_available():
            logger.debug("sqlite-vec not available, skipping vector search")
            return {}

        try:
            query_embedding = await self.embedding.embed_single(query)
            query_blob = _float_list_to_blob(query_embedding)

            # Build WHERE clause for scope filtering
            conditions, params = self._build_conditions(
                team_id, user_id, scope, category, project_id
            )
            where_clause = " AND ".join(conditions) if conditions else "1=1"

            sql = f"""
                SELECT m.id, v.distance
                FROM vec_memories v
                JOIN memories m ON m.id = v.memory_id
                WHERE {where_clause}
                AND v.embedding MATCH ?
                ORDER BY v.distance
                LIMIT ?
            """
            params.extend([query_blob, limit])

            rows = await self.db.fetch_all(sql, tuple(params))

            # Convert distance to similarity (cosine distance -> similarity)
            results: dict[str, float] = {}
            for row in rows:
                distance = row["distance"]
                similarity = max(0.0, 1.0 - distance)
                results[row["id"]] = similarity

            return results

        except Exception as e:
            logger.warning(f"Vector search failed, degrading gracefully: {e}")
            return {}

    async def _bm25_search(
        self,
        query: str,
        team_id: str,
        user_id: str | None,
        scope: str | None,
        category: str | None,
        project_id: str | None,
        limit: int,
    ) -> dict[str, float]:
        """BM25 full-text search using FTS5."""
        try:
            # Escape FTS5 special characters
            safe_query = _escape_fts5_query(query)
            if not safe_query.strip():
                return {}

            conditions, params = self._build_conditions(
                team_id, user_id, scope, category, project_id
            )
            where_clause = " AND ".join(conditions) if conditions else "1=1"

            sql = f"""
                SELECT m.id, fts.rank
                FROM memories_fts fts
                JOIN memories m ON m.rowid = fts.rowid
                WHERE memories_fts MATCH ?
                AND {where_clause}
                ORDER BY fts.rank
                LIMIT ?
            """
            params_list = [safe_query] + params + [limit]

            rows = await self.db.fetch_all(sql, tuple(params_list))

            results: dict[str, float] = {}
            for row in rows:
                # FTS5 rank is negative (lower = better match), convert to positive score
                results[row["id"]] = -row["rank"]

            return results

        except Exception as e:
            logger.warning(f"BM25 search failed: {e}")
            return {}

    async def _fetch_metadata(self, memory_ids: list[str]) -> list[SearchResult]:
        """Fetch memory metadata for result assembly."""
        if not memory_ids:
            return []

        placeholders = ",".join("?" for _ in memory_ids)
        rows = await self.db.fetch_all(
            f"SELECT * FROM memories WHERE id IN ({placeholders})",
            tuple(memory_ids),
        )

        results: list[SearchResult] = []
        for row in rows:
            tags = row.get("tags", "[]")
            if isinstance(tags, str):
                try:
                    tags = json.loads(tags)
                except json.JSONDecodeError:
                    tags = []

            results.append(SearchResult(
                id=row["id"],
                summary=row["summary"],
                score=0.0,
                scope=row.get("scope", "private"),
                category=row.get("category", "general"),
                project_id=row.get("project_id"),
                quality=row.get("quality", "community"),
                tags=tags,
                created_at=row.get("created_at"),
                updated_at=row.get("updated_at"),
                owner_id=row.get("owner_id", ""),
                team_id=row.get("team_id", ""),
                layer=row.get("layer", 2),
                file_path=row.get("file_path", ""),
            ))

        return results

    def _apply_boosts(
        self, results: list[SearchResult], current_project_id: str | None = None
    ) -> list[SearchResult]:
        """Apply three-layer post-processing boosts.

        1. project_boost: +20% if result matches current project
        2. time_decay: +10% if <7 days old, -15% if >90 days old
        3. verified_boost: +15% if quality == verified or pinned
        """
        now = datetime.utcnow()

        for r in results:
            boost = 1.0

            # Project boost: +20%
            if current_project_id and r.project_id == current_project_id:
                boost *= 1.20

            # Time decay
            if r.created_at:
                try:
                    created = datetime.fromisoformat(str(r.created_at))
                    age = now - created
                    if age < timedelta(days=7):
                        boost *= 1.10  # Recent: +10%
                    elif age > timedelta(days=90):
                        boost *= 0.85  # Old: -15%
                except (ValueError, TypeError):
                    pass

            # Verified / Pinned boost: +15%
            if r.quality in ("verified", "pinned"):
                boost *= 1.15

            r.score *= boost

        return results

    def _build_conditions(
        self,
        team_id: str,
        user_id: str | None,
        scope: str | None,
        category: str | None,
        project_id: str | None,
    ) -> tuple[list[str], list[Any]]:
        """Build SQL WHERE conditions for scope filtering."""
        conditions: list[str] = ["m.team_id = ?"]
        params: list[Any] = [team_id]

        # Private data isolation
        if user_id:
            conditions.append("(m.scope != 'private' OR m.owner_id = ?)")
            params.append(user_id)
        else:
            conditions.append("m.scope != 'private'")

        if scope:
            conditions.append("m.scope = ?")
            params.append(scope)

        if category:
            conditions.append("m.category = ?")
            params.append(category)

        if project_id:
            conditions.append("m.project_id = ?")
            params.append(project_id)

        # Exclude archived
        conditions.append("m.quality != 'archived'")

        return conditions, params

    @staticmethod
    def _normalize_scores(scores: dict[str, float]) -> dict[str, float]:
        """Min-max normalize scores to [0, 1]."""
        if not scores:
            return {}

        values = list(scores.values())
        min_val = min(values)
        max_val = max(values)
        range_val = max_val - min_val

        if range_val == 0:
            return {k: 1.0 for k in scores}

        return {k: (v - min_val) / range_val for k, v in scores.items()}

    async def _is_vec_available(self) -> bool:
        """Check if sqlite-vec extension is loaded."""
        if self._vec_available is not None:
            return self._vec_available

        try:
            await self.db.fetch_one(
                "SELECT * FROM sqlite_master WHERE type='table' AND name='vec_memories'"
            )
            row = await self.db.fetch_one(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='vec_memories'"
            )
            self._vec_available = row is not None
        except Exception:
            self._vec_available = False

        return self._vec_available


def _float_list_to_blob(values: list[float]) -> bytes:
    """Convert a list of floats to a binary blob for sqlite-vec."""
    return struct.pack(f"{len(values)}f", *values)


def _escape_fts5_query(query: str) -> str:
    """Escape special FTS5 characters and build a safe query.

    Wraps each word in double quotes to avoid FTS5 syntax errors.
    """
    # Remove FTS5 operators and special chars
    special = set('"*(){}[]^~:')
    cleaned = "".join(c if c not in special else " " for c in query)
    words = cleaned.split()

    if not words:
        return ""

    # Quote each word individually and combine with implicit AND
    return " ".join(f'"{w}"' for w in words if w.strip())
