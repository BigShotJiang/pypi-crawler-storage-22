"""Spec deduplication: compare TMH rules and project rules.

Classifies rules as equivalent, conflicting, or unique to one side.
Manages conflict resolution and .tmh/overrides.json persistence.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from team_memory_hub.core.rule_normalizer import NormalizedRule

logger = logging.getLogger(__name__)


@dataclass
class RuleComparison:
    """Result of comparing a TMH rule with a project rule."""

    key: str
    file_pattern: str
    status: str  # "equivalent", "conflict", "tmh_only", "project_only"
    tmh_rule: NormalizedRule | None = None
    project_rule: NormalizedRule | None = None
    resolution: str | None = None  # "use_tmh", "use_project", "custom", None
    resolved_value: Any = None


@dataclass
class DeduplicationResult:
    """Full result of spec deduplication between TMH and project rules."""

    equivalent: list[RuleComparison] = field(default_factory=list)
    conflicts: list[RuleComparison] = field(default_factory=list)
    tmh_only: list[RuleComparison] = field(default_factory=list)
    project_only: list[RuleComparison] = field(default_factory=list)

    @property
    def has_conflicts(self) -> bool:
        return len(self.conflicts) > 0

    @property
    def total_rules(self) -> int:
        return len(self.equivalent) + len(self.conflicts) + len(self.tmh_only) + len(self.project_only)

    def summary(self) -> dict[str, int]:
        return {
            "equivalent": len(self.equivalent),
            "conflicts": len(self.conflicts),
            "tmh_only": len(self.tmh_only),
            "project_only": len(self.project_only),
        }


class SpecDeduplicator:
    """Compare TMH specs and project rules to find overlaps and conflicts."""

    def compare(
        self,
        tmh_rules: list[NormalizedRule],
        project_rules: list[NormalizedRule],
    ) -> DeduplicationResult:
        """Compare two sets of rules and classify each pair."""
        result = DeduplicationResult()

        # Build lookup: (key, file_pattern) -> rule
        tmh_map: dict[tuple[str, str], NormalizedRule] = {}
        for rule in tmh_rules:
            map_key = (rule.key, rule.file_pattern)
            tmh_map[map_key] = rule

        project_map: dict[tuple[str, str], NormalizedRule] = {}
        for rule in project_rules:
            map_key = (rule.key, rule.file_pattern)
            project_map[map_key] = rule

        # Find matches and conflicts
        seen_keys: set[tuple[str, str]] = set()

        for map_key, tmh_rule in tmh_map.items():
            seen_keys.add(map_key)
            project_rule = project_map.get(map_key)

            if project_rule is None:
                result.tmh_only.append(RuleComparison(
                    key=map_key[0],
                    file_pattern=map_key[1],
                    status="tmh_only",
                    tmh_rule=tmh_rule,
                ))
            elif self._values_equivalent(tmh_rule.value, project_rule.value):
                result.equivalent.append(RuleComparison(
                    key=map_key[0],
                    file_pattern=map_key[1],
                    status="equivalent",
                    tmh_rule=tmh_rule,
                    project_rule=project_rule,
                ))
            else:
                result.conflicts.append(RuleComparison(
                    key=map_key[0],
                    file_pattern=map_key[1],
                    status="conflict",
                    tmh_rule=tmh_rule,
                    project_rule=project_rule,
                ))

        # Project-only rules
        for map_key, project_rule in project_map.items():
            if map_key not in seen_keys:
                result.project_only.append(RuleComparison(
                    key=map_key[0],
                    file_pattern=map_key[1],
                    status="project_only",
                    project_rule=project_rule,
                ))

        return result

    @staticmethod
    def _values_equivalent(v1: Any, v2: Any) -> bool:
        """Check if two rule values are semantically equivalent."""
        if v1 == v2:
            return True

        # Normalize types for comparison
        s1, s2 = str(v1).lower().strip(), str(v2).lower().strip()
        if s1 == s2:
            return True

        # Numeric equivalence
        try:
            return float(v1) == float(v2)
        except (ValueError, TypeError):
            pass

        # Boolean equivalence
        truthy = {"true", "yes", "1", "on"}
        falsy = {"false", "no", "0", "off"}
        if s1 in truthy and s2 in truthy:
            return True
        if s1 in falsy and s2 in falsy:
            return True

        # List equivalence (order-insensitive)
        if isinstance(v1, list) and isinstance(v2, list):
            return set(str(x) for x in v1) == set(str(x) for x in v2)

        return False

    def resolve_conflicts(
        self,
        result: DeduplicationResult,
        strategy: str = "project_wins",
    ) -> DeduplicationResult:
        """Apply a conflict resolution strategy to all conflicts.

        Strategies:
        - "project_wins": project rules take precedence
        - "tmh_wins": TMH rules take precedence
        - "manual": leave conflicts unresolved for manual review
        """
        for conflict in result.conflicts:
            if strategy == "project_wins":
                conflict.resolution = "use_project"
                conflict.resolved_value = (
                    conflict.project_rule.value if conflict.project_rule else None
                )
            elif strategy == "tmh_wins":
                conflict.resolution = "use_tmh"
                conflict.resolved_value = (
                    conflict.tmh_rule.value if conflict.tmh_rule else None
                )
            # "manual" -> no resolution applied

        return result


def load_overrides(project_root: str | Path) -> dict[str, Any]:
    """Load overrides from .tmh/overrides.json."""
    overrides_path = Path(project_root) / ".tmh" / "overrides.json"
    if not overrides_path.exists():
        return {}
    try:
        return json.loads(overrides_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        logger.warning("Failed to load overrides: %s", e)
        return {}


def save_overrides(project_root: str | Path, overrides: dict[str, Any]) -> None:
    """Save overrides to .tmh/overrides.json."""
    tmh_dir = Path(project_root) / ".tmh"
    tmh_dir.mkdir(parents=True, exist_ok=True)
    overrides_path = tmh_dir / "overrides.json"
    overrides_path.write_text(
        json.dumps(overrides, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def apply_conflict_overrides(
    result: DeduplicationResult,
    overrides: dict[str, Any],
) -> DeduplicationResult:
    """Apply saved overrides to conflict resolutions."""
    override_rules = overrides.get("rules", {})

    for conflict in result.conflicts:
        override_key = f"{conflict.key}:{conflict.file_pattern}"
        if override_key in override_rules:
            override = override_rules[override_key]
            conflict.resolution = override.get("resolution", "use_project")
            conflict.resolved_value = override.get("value")

    return result


def save_conflict_resolutions(
    project_root: str | Path,
    result: DeduplicationResult,
) -> None:
    """Save conflict resolutions to .tmh/overrides.json."""
    overrides = load_overrides(project_root)

    rules = overrides.setdefault("rules", {})
    for conflict in result.conflicts:
        if conflict.resolution:
            override_key = f"{conflict.key}:{conflict.file_pattern}"
            rules[override_key] = {
                "resolution": conflict.resolution,
                "value": conflict.resolved_value,
                "tmh_source": conflict.tmh_rule.source if conflict.tmh_rule else None,
                "project_source": conflict.project_rule.source if conflict.project_rule else None,
            }

    save_overrides(project_root, overrides)
