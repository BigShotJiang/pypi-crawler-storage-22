"""Spec manager: specification file management with versioning and delta merging.

Handles reading spec files, computing version fingerprints (SHA256),
parsing deltas (ADDED/MODIFIED/REMOVED), and merging changes.
"""

from __future__ import annotations

import hashlib
import json
import logging
import secrets
import string
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml

from team_memory_hub.storage.database import Database

logger = logging.getLogger(__name__)

_ID_CHARS = string.ascii_lowercase + string.digits


def _generate_id(prefix: str) -> str:
    suffix = "".join(secrets.choice(_ID_CHARS) for _ in range(8))
    return f"{prefix}_{suffix}"


class SpecManager:
    """Manage specification files with versioning and delta-based proposals.

    Spec files are YAML/Markdown files stored in the specs directory.
    Each spec has a SHA256 fingerprint for change detection.
    Proposals contain deltas that can be merged into target specs.
    """

    def __init__(self, specs_dir: str, db: Database):
        self.specs_dir = Path(specs_dir)
        self.specs_dir.mkdir(parents=True, exist_ok=True)
        self.db = db

    # ==================== Spec File Operations ====================

    def list_specs(self, team_id: str) -> list[dict[str, Any]]:
        """列出所有 spec files for a team."""
        team_dir = self.specs_dir / team_id
        if not team_dir.exists():
            return []

        specs: list[dict[str, Any]] = []
        for path in sorted(team_dir.rglob("*.yaml")):
            rel_path = str(path.relative_to(self.specs_dir))
            content = path.read_text(encoding="utf-8")
            fingerprint = self._compute_fingerprint(content)

            specs.append({
                "path": rel_path,
                "fingerprint": fingerprint,
                "size_bytes": path.stat().st_size,
                "modified_at": datetime.fromtimestamp(path.stat().st_mtime).isoformat(),
            })

        # Also list .md files
        for path in sorted(team_dir.rglob("*.md")):
            rel_path = str(path.relative_to(self.specs_dir))
            content = path.read_text(encoding="utf-8")
            fingerprint = self._compute_fingerprint(content)

            specs.append({
                "path": rel_path,
                "fingerprint": fingerprint,
                "size_bytes": path.stat().st_size,
                "modified_at": datetime.fromtimestamp(path.stat().st_mtime).isoformat(),
            })

        return specs

    def read_spec(self, spec_path: str) -> dict[str, Any]:
        """Read a spec file and return its content with metadata."""
        full_path = self.specs_dir / spec_path
        if not full_path.exists():
            raise FileNotFoundError(f"规范文件未找到: {spec_path}")

        content = full_path.read_text(encoding="utf-8")
        fingerprint = self._compute_fingerprint(content)

        # Parse if YAML
        parsed = None
        if spec_path.endswith(".yaml") or spec_path.endswith(".yml"):
            try:
                parsed = yaml.safe_load(content)
            except yaml.YAMLError:
                pass

        return {
            "path": spec_path,
            "content": content,
            "parsed": parsed,
            "fingerprint": fingerprint,
            "size_bytes": len(content.encode("utf-8")),
        }

    def write_spec(
        self, spec_path: str, content: str, team_id: str
    ) -> dict[str, Any]:
        """Write or update a spec file."""
        full_path = self.specs_dir / spec_path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(content, encoding="utf-8")

        fingerprint = self._compute_fingerprint(content)
        return {
            "path": spec_path,
            "fingerprint": fingerprint,
            "size_bytes": len(content.encode("utf-8")),
        }

    # ==================== Proposal Operations ====================

    async def create_proposal(
        self,
        title: str,
        description: str | None,
        target_spec: str,
        delta: dict[str, Any],
        author_id: str,
        team_id: str,
    ) -> dict[str, Any]:
        """Create a new spec change proposal with delta."""
        proposal_id = _generate_id("prop")
        now = datetime.utcnow().isoformat()

        # Write delta to file
        delta_filename = f"{proposal_id}_delta.json"
        delta_path = self.specs_dir / team_id / ".proposals" / delta_filename
        delta_path.parent.mkdir(parents=True, exist_ok=True)
        delta_path.write_text(json.dumps(delta, indent=2), encoding="utf-8")

        rel_delta_path = str(delta_path.relative_to(self.specs_dir))

        await self.db.execute(
            """INSERT INTO spec_proposals
               (id, title, description, target_spec, delta_path, status,
                author_id, team_id, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, 'draft', ?, ?, ?, ?)""",
            (proposal_id, title, description, target_spec, rel_delta_path,
             author_id, team_id, now, now),
        )
        await self.db.commit()

        return {
            "id": proposal_id,
            "title": title,
            "description": description,
            "target_spec": target_spec,
            "delta_path": rel_delta_path,
            "status": "draft",
            "author_id": author_id,
            "team_id": team_id,
            "created_at": now,
        }

    async def get_proposal(self, proposal_id: str) -> dict[str, Any] | None:
        """Get a proposal by ID."""
        row = await self.db.fetch_one(
            "SELECT * FROM spec_proposals WHERE id = ?", (proposal_id,)
        )
        if row is None:
            return None
        return dict(row)

    async def list_proposals(
        self, team_id: str, status: str | None = None
    ) -> list[dict[str, Any]]:
        """List proposals for a team."""
        if status:
            rows = await self.db.fetch_all(
                "SELECT * FROM spec_proposals WHERE team_id = ? AND status = ? ORDER BY created_at DESC",
                (team_id, status),
            )
        else:
            rows = await self.db.fetch_all(
                "SELECT * FROM spec_proposals WHERE team_id = ? ORDER BY created_at DESC",
                (team_id,),
            )
        return [dict(r) for r in rows]

    async def update_proposal_status(
        self,
        proposal_id: str,
        new_status: str,
        reviewer_id: str | None = None,
    ) -> dict[str, Any] | None:
        """Update proposal status (lifecycle transition)."""
        now = datetime.utcnow().isoformat()

        updates = {"status": new_status, "updated_at": now}
        if reviewer_id:
            updates["reviewer_id"] = reviewer_id
        if new_status == "merged":
            updates["merged_at"] = now

        set_clause = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [proposal_id]

        await self.db.execute(
            f"UPDATE spec_proposals SET {set_clause} WHERE id = ?",
            tuple(values),
        )
        await self.db.commit()

        return await self.get_proposal(proposal_id)

    async def merge_proposal(
        self, proposal_id: str, reviewer_id: str, team_id: str
    ) -> dict[str, Any]:
        """Merge a proposal: apply delta to target spec file.

        Delta format:
        {
            "changes": [
                {"action": "ADDED", "path": "section.key", "value": "..."},
                {"action": "MODIFIED", "path": "section.key", "old_value": "...", "value": "..."},
                {"action": "REMOVED", "path": "section.key"}
            ]
        }
        """
        proposal = await self.get_proposal(proposal_id)
        if proposal is None:
            raise ValueError(f"Proposal not found: {proposal_id}")

        if proposal["status"] not in ("draft", "pending_review", "approved"):
            raise ValueError(f"Cannot merge proposal in status: {proposal['status']}")

        # Read delta
        delta_full_path = self.specs_dir / proposal["delta_path"]
        delta = json.loads(delta_full_path.read_text(encoding="utf-8"))

        # Read or create target spec
        target_path = proposal["target_spec"]
        target_full_path = self.specs_dir / target_path

        if target_full_path.exists():
            content = target_full_path.read_text(encoding="utf-8")
            if target_path.endswith((".yaml", ".yml")):
                spec_data = yaml.safe_load(content) or {}
            else:
                spec_data = {"content": content}
        else:
            spec_data = {}

        # Apply delta changes
        for change in delta.get("changes", []):
            action = change.get("action", "").upper()
            path = change.get("path", "")

            if action == "ADDED":
                _set_nested(spec_data, path, change.get("value"))
            elif action == "MODIFIED":
                _set_nested(spec_data, path, change.get("value"))
            elif action == "REMOVED":
                _delete_nested(spec_data, path)

        # Write updated spec
        target_full_path.parent.mkdir(parents=True, exist_ok=True)
        if target_path.endswith((".yaml", ".yml")):
            new_content = yaml.dump(spec_data, default_flow_style=False, allow_unicode=True)
        else:
            new_content = spec_data.get("content", str(spec_data))

        target_full_path.write_text(new_content, encoding="utf-8")

        # Update proposal status
        await self.update_proposal_status(proposal_id, "merged", reviewer_id)

        # Update team specs version
        fingerprint = self._compute_fingerprint(new_content)
        await self.db.execute(
            """UPDATE teams SET specs_version = specs_version + 1,
               specs_fingerprint = ? WHERE id = ?""",
            (fingerprint, team_id),
        )
        await self.db.commit()

        return {
            "proposal_id": proposal_id,
            "target_spec": target_path,
            "fingerprint": fingerprint,
            "changes_applied": len(delta.get("changes", [])),
        }

    @staticmethod
    def _compute_fingerprint(content: str) -> str:
        """Compute SHA256 fingerprint of content."""
        return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _set_nested(data: dict, path: str, value: Any) -> None:
    """Set a value at a dotted path in a nested dict."""
    keys = path.split(".")
    current = data
    for key in keys[:-1]:
        if key not in current or not isinstance(current[key], dict):
            current[key] = {}
        current = current[key]
    current[keys[-1]] = value


def _delete_nested(data: dict, path: str) -> None:
    """删除 a value at a dotted path in a nested dict."""
    keys = path.split(".")
    current = data
    for key in keys[:-1]:
        if key not in current or not isinstance(current[key], dict):
            return
        current = current[key]
    current.pop(keys[-1], None)
