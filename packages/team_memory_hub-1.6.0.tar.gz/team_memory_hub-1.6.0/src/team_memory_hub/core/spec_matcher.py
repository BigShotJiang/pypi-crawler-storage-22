"""SpecMatcher: match specs to projects based on applicability conditions.

Conditions include language, framework, file pattern, and custom tags.
"""

from __future__ import annotations

import fnmatch
import logging
from dataclasses import dataclass
from typing import Any

from team_memory_hub.core.project_detector import ProjectProfile

logger = logging.getLogger(__name__)


@dataclass
class SpecCondition:
    """A single applicability condition for a spec."""

    condition_type: str  # "language", "framework", "file_pattern", "tag", "always"
    condition_value: str  # e.g. "python", "react", "*.py", "backend"


@dataclass
class SpecApplicability:
    """Spec with its applicability conditions."""

    spec_path: str
    team_id: str
    conditions: list[SpecCondition]

    def matches(self, profile: ProjectProfile, file_path: str | None = None) -> bool:
        """Check if this spec applies to the given project and file."""
        if not self.conditions:
            return True  # No conditions means always applies

        for condition in self.conditions:
            if _match_condition(condition, profile, file_path):
                return True
        return False


class SpecMatcher:
    """Match specs against project profiles and file paths."""

    def __init__(self, specs: list[SpecApplicability] | None = None):
        self._specs = specs or []

    def add_spec(self, spec: SpecApplicability) -> None:
        self._specs.append(spec)

    def find_applicable(
        self,
        profile: ProjectProfile,
        file_path: str | None = None,
    ) -> list[SpecApplicability]:
        """Find all specs that apply to the given project and file."""
        return [
            spec for spec in self._specs
            if spec.matches(profile, file_path)
        ]

    def find_by_language(self, language: str) -> list[SpecApplicability]:
        """Find all specs that match a specific language."""
        return [
            spec for spec in self._specs
            if any(
                c.condition_type == "language" and c.condition_value.lower() == language.lower()
                for c in spec.conditions
            )
        ]

    def find_by_framework(self, framework: str) -> list[SpecApplicability]:
        """Find all specs that match a specific framework."""
        return [
            spec for spec in self._specs
            if any(
                c.condition_type == "framework" and c.condition_value.lower() == framework.lower()
                for c in spec.conditions
            )
        ]

    async def load_from_db(self, db: Any, team_id: str) -> None:
        """Load spec applicability rules from database."""
        rows = await db.fetch_all(
            "SELECT * FROM spec_applicability WHERE team_id = ?",
            (team_id,),
        )

        spec_map: dict[str, SpecApplicability] = {}
        for row in rows:
            spec_path = row["spec_path"]
            if spec_path not in spec_map:
                spec_map[spec_path] = SpecApplicability(
                    spec_path=spec_path,
                    team_id=team_id,
                    conditions=[],
                )
            spec_map[spec_path].conditions.append(SpecCondition(
                condition_type=row["condition_type"],
                condition_value=row["condition_value"],
            ))

        self._specs = list(spec_map.values())


def _match_condition(
    condition: SpecCondition,
    profile: ProjectProfile,
    file_path: str | None = None,
) -> bool:
    """Check if a single condition matches."""
    ctype = condition.condition_type.lower()
    cvalue = condition.condition_value.lower()

    if ctype == "always":
        return True

    if ctype == "language":
        return cvalue in [lang.lower() for lang in profile.languages]

    if ctype == "framework":
        return cvalue in [fw.lower() for fw in profile.frameworks]

    if ctype == "package_manager":
        return cvalue in [pm.lower() for pm in profile.package_managers]

    if ctype == "file_pattern" and file_path:
        return fnmatch.fnmatch(file_path.lower(), cvalue)

    if ctype == "has_docker":
        return profile.has_docker

    if ctype == "ci_provider":
        return cvalue in [ci.lower() for ci in profile.ci_providers]

    if ctype == "tag":
        # Tags match against project name or detected config
        return cvalue in profile.name.lower()

    return False
