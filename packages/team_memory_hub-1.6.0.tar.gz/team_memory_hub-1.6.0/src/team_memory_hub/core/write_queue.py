"""异步写队列，带批处理：100ms 超时 / 50 个项目最大批"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Any, Callable, Coroutine

logger = logging.getLogger(__name__)


@dataclass
class WriteOperation:
    """要批处理的单个写操作。"""
    sql: str
    params: tuple | None = None
    callback: asyncio.Future | None = None


class WriteQueue:
    """基于 Asyncio 的写队列，带批积累。

    收集写操作并分批提交，
    当达到 batch_max_size 或经过 batch_timeout_ms 后执行。
    """

    def __init__(
        self,
        execute_batch: Callable[[list[WriteOperation]], Coroutine[Any, Any, None]],
        batch_timeout_ms: int = 100,
        batch_max_size: int = 50,
    ):
        self._execute_batch = execute_batch
        self._batch_timeout_ms = batch_timeout_ms
        self._batch_max_size = batch_max_size
        self._queue: asyncio.Queue[WriteOperation] = asyncio.Queue()
        self._task: asyncio.Task | None = None
        self._running = False

    async def start(self) -> None:
        """启动后台批处理器。"""
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._process_loop())

    async def stop(self) -> None:
        """停止后台批处理器并刷新剩余项。"""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        # 刷新剩余项
        await self._flush_remaining()

    async def enqueue(self, sql: str, params: tuple | None = None) -> None:
        """将写操作添加到队列。

        返回一个 future，当包含此操作的批被提交时解析。
        """
        loop = asyncio.get_event_loop()
        future = loop.create_future()
        op = WriteOperation(sql=sql, params=params, callback=future)
        await self._queue.put(op)
        await future

    async def enqueue_nowait(self, sql: str, params: tuple | None = None) -> None:
        """添加写操作而不等待提交。"""
        op = WriteOperation(sql=sql, params=params)
        await self._queue.put(op)

    async def _process_loop(self) -> None:
        """主处理循环：收集批然后执行。"""
        while self._running:
            batch: list[WriteOperation] = []
            try:
                # 等待第一个项
                first = await asyncio.wait_for(
                    self._queue.get(), timeout=1.0
                )
                batch.append(first)

                # 在超时内收集更多项
                deadline = asyncio.get_event_loop().time() + (
                    self._batch_timeout_ms / 1000.0
                )
                while len(batch) < self._batch_max_size:
                    remaining = deadline - asyncio.get_event_loop().time()
                    if remaining <= 0:
                        break
                    try:
                        item = await asyncio.wait_for(
                            self._queue.get(), timeout=remaining
                        )
                        batch.append(item)
                    except asyncio.TimeoutError:
                        break

                # 执行批
                await self._execute_and_resolve(batch)

            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                if batch:
                    await self._execute_and_resolve(batch)
                raise
            except Exception:
                logger.exception("Error in write queue processing loop")
                # 用错误解析 futures
                for op in batch:
                    if op.callback and not op.callback.done():
                        op.callback.set_exception(
                            RuntimeError("Batch execution failed")
                        )

    async def _execute_and_resolve(self, batch: list[WriteOperation]) -> None:
        """执行批并解析所有 futures。"""
        try:
            await self._execute_batch(batch)
            for op in batch:
                if op.callback and not op.callback.done():
                    op.callback.set_result(None)
        except Exception as e:
            logger.exception("Batch execution failed")
            for op in batch:
                if op.callback and not op.callback.done():
                    op.callback.set_exception(e)

    async def _flush_remaining(self) -> None:
        """刷新队列中的任何剩余项。"""
        batch: list[WriteOperation] = []
        while not self._queue.empty():
            try:
                item = self._queue.get_nowait()
                batch.append(item)
            except asyncio.QueueEmpty:
                break
        if batch:
            await self._execute_and_resolve(batch)
