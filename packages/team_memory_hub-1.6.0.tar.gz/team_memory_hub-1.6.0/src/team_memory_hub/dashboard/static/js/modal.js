/* TMH Modal Component */
(function() {
  var activeModal = null;
  var previousFocus = null;

  function open(contentHtml, url) {
    if (activeModal) close();
    previousFocus = document.activeElement;

    // Create overlay
    var overlay = document.createElement('div');
    overlay.className = 'tmh-modal-overlay';
    overlay.innerHTML =
      '<div class="tmh-modal">' +
        '<button class="tmh-modal-close" aria-label="关闭">&times;</button>' +
        '<div class="tmh-modal-content"></div>' +
      '</div>';

    document.body.appendChild(overlay);
    document.body.style.overflow = 'hidden';
    activeModal = overlay;

    // Close handlers
    overlay.querySelector('.tmh-modal-close').addEventListener('click', close);
    overlay.addEventListener('click', function(e) {
      if (e.target === overlay) close();
    });
    document.addEventListener('keydown', onEsc);

    // Load content
    var contentEl = overlay.querySelector('.tmh-modal-content');
    if (url) {
      htmx.ajax('GET', url, {target: contentEl, swap: 'innerHTML'});
    } else if (contentHtml) {
      contentEl.innerHTML = contentHtml;
    }

    // Animate in
    requestAnimationFrame(function() {
      overlay.classList.add('visible');
    });

    // Focus trap
    setupFocusTrap(overlay);
  }

  function confirm(title, message, onConfirm) {
    var html =
      '<div class="tmh-modal-header"><h3>' + escapeHtml(title) + '</h3></div>' +
      '<div class="tmh-modal-body"><p>' + escapeHtml(message) + '</p></div>' +
      '<div class="tmh-modal-footer">' +
        '<button class="secondary tmh-confirm-cancel">取消</button>' +
        '<button class="contrast tmh-confirm-ok">确认</button>' +
      '</div>';

    open(html);

    if (activeModal) {
      activeModal.querySelector('.tmh-confirm-cancel').addEventListener('click', close);
      activeModal.querySelector('.tmh-confirm-ok').addEventListener('click', function() {
        close();
        if (onConfirm) onConfirm();
      });
    }
  }

  function close() {
    if (!activeModal) return;
    var overlay = activeModal;
    overlay.classList.remove('visible');
    document.removeEventListener('keydown', onEsc);
    setTimeout(function() {
      if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
    }, 200);
    document.body.style.overflow = '';
    activeModal = null;
    if (previousFocus) {
      previousFocus.focus();
      previousFocus = null;
    }
  }

  function onEsc(e) {
    if (e.key === 'Escape') close();
  }

  function setupFocusTrap(overlay) {
    overlay.addEventListener('keydown', function(e) {
      if (e.key !== 'Tab') return;
      var focusable = overlay.querySelectorAll('a,button,input,select,textarea,[tabindex]:not([tabindex="-1"])');
      if (focusable.length === 0) return;
      var first = focusable[0];
      var last = focusable[focusable.length - 1];
      if (e.shiftKey) {
        if (document.activeElement === first) { e.preventDefault(); last.focus(); }
      } else {
        if (document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    });
  }

  function escapeHtml(str) {
    var div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  window.TMH = window.TMH || {};
  window.TMH.modal = { open: open, close: close, confirm: confirm };
})();
