/* TMH Table Enhancement */
(function() {
  function init() {
    initScrollShadows();
    initSelectAll();
    initKeyboardShortcuts();
  }

  // Horizontal scroll shadow indicators
  function initScrollShadows() {
    document.querySelectorAll('.tmh-table-wrapper').forEach(function(wrapper) {
      function updateShadows() {
        var sl = wrapper.scrollLeft;
        var sw = wrapper.scrollWidth;
        var cw = wrapper.clientWidth;
        wrapper.classList.toggle('scroll-left', sl > 0);
        wrapper.classList.toggle('scroll-right', sl + cw < sw - 1);
      }
      wrapper.addEventListener('scroll', updateShadows);
      updateShadows();
      // Re-check on resize
      window.addEventListener('resize', updateShadows);
    });
  }

  // Select-all checkbox
  function initSelectAll() {
    document.querySelectorAll('#select-all').forEach(function(selectAll) {
      selectAll.addEventListener('change', function() {
        var checked = selectAll.checked;
        document.querySelectorAll('.row-check').forEach(function(cb) {
          cb.checked = checked;
        });
        updateSelectCount();
      });
    });

    // Individual checkbox change
    document.addEventListener('change', function(e) {
      if (e.target.classList.contains('row-check')) {
        updateSelectCount();
        // Update select-all state
        var all = document.querySelectorAll('.row-check');
        var checked = document.querySelectorAll('.row-check:checked');
        var selectAll = document.getElementById('select-all');
        if (selectAll) {
          selectAll.checked = all.length > 0 && all.length === checked.length;
          selectAll.indeterminate = checked.length > 0 && checked.length < all.length;
        }
      }
    });
  }

  function updateSelectCount() {
    var count = document.querySelectorAll('.row-check:checked').length;
    var indicator = document.querySelector('.tmh-select-count');
    if (indicator) {
      if (count > 0) {
        indicator.textContent = '\u5DF2\u9009\u62E9 ' + count + ' \u6761\u8BB0\u5FC6';
        indicator.classList.add('visible');
      } else {
        indicator.classList.remove('visible');
      }
    }
  }

  // Keyboard shortcuts
  function initKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
      // Ctrl+A to select all rows (only when table is in view)
      if ((e.ctrlKey || e.metaKey) && e.key === 'a') {
        var selectAll = document.getElementById('select-all');
        if (selectAll && isElementInViewport(selectAll)) {
          e.preventDefault();
          selectAll.checked = !selectAll.checked;
          selectAll.dispatchEvent(new Event('change'));
        }
      }
    });
  }

  function isElementInViewport(el) {
    var rect = el.getBoundingClientRect();
    return rect.top >= 0 && rect.left >= 0 &&
      rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
      rect.right <= (window.innerWidth || document.documentElement.clientWidth);
  }

  // Expose
  window.TMH = window.TMH || {};
  window.TMH.table = { init: init, updateSelectCount: updateSelectCount };

  // Auto-init on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Re-init after HTMX swaps
  document.addEventListener('htmx:afterSwap', init);
})();
