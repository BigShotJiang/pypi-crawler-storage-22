/* TMH Theme Switcher */
(function() {
  var STORAGE_KEY = 'tmh-theme';

  function getPreferredTheme() {
    var stored = localStorage.getItem(STORAGE_KEY);
    if (stored) return stored;
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }

  function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem(STORAGE_KEY, theme);
    // Update toggle button icon
    var btn = document.getElementById('theme-toggle');
    if (btn) {
      btn.textContent = theme === 'dark' ? '\u2600' : '\u263E';
      btn.title = theme === 'dark' ? '\u5207\u6362\u5230\u6D45\u8272\u6A21\u5F0F' : '\u5207\u6362\u5230\u6DF1\u8272\u6A21\u5F0F';
    }
  }

  function toggleTheme() {
    var current = document.documentElement.getAttribute('data-theme') || 'light';
    setTheme(current === 'dark' ? 'light' : 'dark');
  }

  // Apply theme immediately (before DOMContentLoaded to avoid FOUC)
  setTheme(getPreferredTheme());

  // Bind toggle button after DOM ready
  document.addEventListener('DOMContentLoaded', function() {
    var btn = document.getElementById('theme-toggle');
    if (btn) {
      btn.addEventListener('click', toggleTheme);
      // Set initial icon
      var theme = document.documentElement.getAttribute('data-theme') || 'light';
      btn.textContent = theme === 'dark' ? '\u2600' : '\u263E';
    }
  });

  // Listen for system preference changes
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function(e) {
    if (!localStorage.getItem(STORAGE_KEY)) {
      setTheme(e.matches ? 'dark' : 'light');
    }
  });

  // Expose for programmatic use
  window.TMH = window.TMH || {};
  window.TMH.theme = { toggle: toggleTheme, set: setTheme };
})();
