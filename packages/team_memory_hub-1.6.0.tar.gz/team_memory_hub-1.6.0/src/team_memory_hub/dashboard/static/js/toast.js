/* TMH Toast Notification System */
(function() {
  var container = null;
  var ICONS = {
    success: '\u2713',
    error: '\u2717',
    warning: '\u26A0',
    info: '\u2139'
  };

  function ensureContainer() {
    if (!container || !container.parentNode) {
      container = document.createElement('div');
      container.className = 'tmh-toast-container';
      document.body.appendChild(container);
    }
    return container;
  }

  function show(opts) {
    var type = opts.type || 'info';
    var message = opts.message || '';
    var duration = opts.duration;

    // Default: 3s for all except error (no auto-dismiss)
    if (duration === undefined) {
      duration = type === 'error' ? 0 : 3000;
    }

    var c = ensureContainer();

    var toast = document.createElement('div');
    toast.className = 'tmh-toast tmh-toast-' + type;
    toast.innerHTML =
      '<span class="tmh-toast-icon">' + (ICONS[type] || '') + '</span>' +
      '<span class="tmh-toast-message">' + escapeHtml(message) + '</span>' +
      '<button class="tmh-toast-close" aria-label="关闭">&times;</button>';

    c.prepend(toast);

    // Close button
    toast.querySelector('.tmh-toast-close').addEventListener('click', function() {
      removeToast(toast);
    });

    // Animate in
    requestAnimationFrame(function() {
      toast.classList.add('visible');
    });

    // Auto-dismiss
    if (duration > 0) {
      setTimeout(function() {
        removeToast(toast);
      }, duration);
    }

    return toast;
  }

  function removeToast(toast) {
    toast.classList.add('removing');
    toast.classList.remove('visible');
    setTimeout(function() {
      if (toast.parentNode) toast.parentNode.removeChild(toast);
    }, 250);
  }

  function escapeHtml(str) {
    var div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  window.TMH = window.TMH || {};
  window.TMH.toast = { show: show };
})();
