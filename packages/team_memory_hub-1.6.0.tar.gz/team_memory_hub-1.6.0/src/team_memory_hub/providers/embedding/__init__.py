"""嵌入提供程序工厂和重新导出。"""

from __future__ import annotations

from team_memory_hub.config import EmbeddingConfig
from team_memory_hub.providers.embedding.base import EmbeddingProvider, TARGET_DIMENSIONS


def create_embedding_provider(config: EmbeddingConfig) -> EmbeddingProvider:
    """Factory: create an embedding provider from configuration.

    Supported provider values:
        - "gemini"             -> GeminiProvider
        - "openai"             -> OpenAIProvider
        - "onnx"               -> ONNXLocalProvider
        - "openai_compatible"  -> OpenAICompatibleProvider (default)
    """
    provider_name = config.provider.lower()

    if provider_name == "gemini":
        from team_memory_hub.providers.embedding.gemini import GeminiProvider
        return GeminiProvider(api_key=config.api_key, model=config.model)

    if provider_name == "openai":
        from team_memory_hub.providers.embedding.openai_provider import OpenAIProvider
        return OpenAIProvider(api_key=config.api_key, model=config.model)

    if provider_name == "onnx":
        from team_memory_hub.providers.embedding.onnx import ONNXLocalProvider
        return ONNXLocalProvider(model_path=config.model)

    # Default: openai_compatible (works with Ollama, vLLM, TEI)
    from team_memory_hub.providers.embedding.openai_compatible import OpenAICompatibleProvider
    return OpenAICompatibleProvider(
        base_url=config.base_url,
        model=config.model,
        api_key=config.api_key,
    )


__all__ = [
    "EmbeddingProvider",
    "TARGET_DIMENSIONS",
    "create_embedding_provider",
]
