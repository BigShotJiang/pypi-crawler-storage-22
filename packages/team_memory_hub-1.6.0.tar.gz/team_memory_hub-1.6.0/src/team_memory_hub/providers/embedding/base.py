"""嵌入提供程序的抽象基类。"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)

TARGET_DIMENSIONS = 384


class EmbeddingProvider(ABC):
    """所有嵌入提供程序的基类。

    所有提供程序必须生成 TARGET_DIMENSIONS (384) 维的向量。
    具有较大原生维度的提供程序会截断并重新归一化。
    """

    TARGET_DIMENSIONS = TARGET_DIMENSIONS

    @abstractmethod
    async def embed(self, texts: list[str]) -> list[list[float]]:
        """将一批文本嵌入到向量中。

        返回值：
            浮点向量列表，每个向量长度为 TARGET_DIMENSIONS。
        """

    async def embed_single(self, text: str) -> list[float]:
        """嵌入单个文本字符串。"""
        results = await self.embed([text])
        return results[0]

    @staticmethod
    def _normalize_dimensions(
        vector: list[float], target_dim: int = TARGET_DIMENSIONS
    ) -> list[float]:
        """将向量截断到目标维度并进行 L2 归一化。

        Matryoshka 风格：取前 `target_dim` 个分量，然后归一化。
        """
        truncated = vector[:target_dim]

        # L2 归一化
        norm = sum(x * x for x in truncated) ** 0.5
        if norm > 0:
            truncated = [x / norm for x in truncated]

        return truncated
