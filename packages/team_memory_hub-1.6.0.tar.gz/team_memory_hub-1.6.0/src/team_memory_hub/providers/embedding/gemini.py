"""Google Gemini 嵌入提供程序（768 -> 384 截断）。"""

from __future__ import annotations

import logging
from typing import Any

import httpx

from team_memory_hub.providers.embedding.base import EmbeddingProvider

logger = logging.getLogger(__name__)

GEMINI_EMBED_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:batchEmbedContents"
DEFAULT_MODEL = "text-embedding-004"
NATIVE_DIMENSIONS = 768
BATCH_SIZE = 100


class GeminiProvider(EmbeddingProvider):
    """Google Gemini 嵌入提供程序。

    原生输出：768 维，截断为 384。
    """

    def __init__(self, api_key: str, model: str = DEFAULT_MODEL):
        self.api_key = api_key
        self.model = model
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=60.0)
        return self._client

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """使用 Gemini API 和批处理嵌入文本。"""
        all_vectors: list[list[float]] = []

        for i in range(0, len(texts), BATCH_SIZE):
            batch = texts[i : i + BATCH_SIZE]
            vectors = await self._embed_batch(batch)
            all_vectors.extend(vectors)

        return all_vectors

    async def _embed_batch(self, texts: list[str]) -> list[list[float]]:
        """通过 Gemini API 嵌入单个批次。"""
        client = await self._get_client()
        url = GEMINI_EMBED_URL.format(model=self.model)

        requests_body = [
            {"model": f"models/{self.model}", "content": {"parts": [{"text": t}]}}
            for t in texts
        ]

        response = await client.post(
            url,
            params={"key": self.api_key},
            json={"requests": requests_body},
        )
        response.raise_for_status()
        data = response.json()

        vectors: list[list[float]] = []
        for embedding in data["embeddings"]:
            raw = embedding["values"]
            normalized = self._normalize_dimensions(raw)
            vectors.append(normalized)

        return vectors

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()
