"""嵌入迁移：切换提供程序或模型时重新嵌入记忆。"""

from __future__ import annotations

import logging
from typing import Any

from team_memory_hub.providers.embedding.base import EmbeddingProvider
from team_memory_hub.storage.database import Database

logger = logging.getLogger(__name__)

BATCH_SIZE = 50


class EmbeddingMigrator:
    """在提供程序或模型更改时处理嵌入的迁移。"""

    def __init__(
        self,
        db: Database,
        old_provider: EmbeddingProvider | None,
        new_provider: EmbeddingProvider,
    ):
        self.db = db
        self.old_provider = old_provider
        self.new_provider = new_provider

    async def migrate(
        self,
        team_id: str | None = None,
        batch_size: int = BATCH_SIZE,
    ) -> dict[str, Any]:
        """使用新提供程序重新嵌入所有记忆。

        返回迁移统计信息。
        """
        conditions = ["1=1"]
        params: list[Any] = []

        if team_id:
            conditions.append("team_id = ?")
            params.append(team_id)

        where = " AND ".join(conditions)

        count_row = await self.db.fetch_one(
            f"SELECT COUNT(*) as cnt FROM memories WHERE {where}", tuple(params)
        )
        total = count_row["cnt"] if count_row else 0

        processed = 0
        errors = 0
        offset = 0

        while offset < total:
            rows = await self.db.fetch_all(
                f"""SELECT id, summary FROM memories WHERE {where}
                    ORDER BY id LIMIT ? OFFSET ?""",
                tuple(params + [batch_size, offset]),
            )

            if not rows:
                break

            texts = [r["summary"] for r in rows]
            ids = [r["id"] for r in rows]

            try:
                vectors = await self.new_provider.embed(texts)

                for mid, vector in zip(ids, vectors):
                    # Update embedding metadata
                    await self.db.execute(
                        """UPDATE memories SET embedding_provider = ?, embedding_model = ?
                           WHERE id = ?""",
                        ("migrated", "new_model", mid),
                    )
                    processed += 1

            except Exception as e:
                logger.error("Embedding migration batch failed at offset %d: %s", offset, e)
                errors += len(rows)

            offset += batch_size

        await self.db.commit()

        return {
            "total": total,
            "processed": processed,
            "errors": errors,
        }
