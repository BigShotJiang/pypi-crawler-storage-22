"""ONNX 本地嵌入提供程序（原生 384 维）。"""

from __future__ import annotations

import logging
from pathlib import Path

from team_memory_hub.providers.embedding.base import EmbeddingProvider

logger = logging.getLogger(__name__)

DEFAULT_MODEL_PATH = "models/all-MiniLM-L6-v2"
BATCH_SIZE = 32


class ONNXLocalProvider(EmbeddingProvider):
    """本地 ONNX Runtime 嵌入提供程序。

    使用具有原生 384 维的 all-MiniLM-L6-v2 或类似模型。
    不需要截断。
    """

    def __init__(self, model_path: str = DEFAULT_MODEL_PATH):
        self.model_path = model_path
        self._session = None
        self._tokenizer = None

    def _ensure_loaded(self) -> None:
        """延迟加载 ONNX 模型和分词器。"""
        if self._session is not None:
            return

        try:
            import onnxruntime as ort
            from tokenizers import Tokenizer
        except ImportError as e:
            raise ImportError(
                "ONNX provider requires 'onnxruntime' and 'tokenizers' packages. "
                "Install them with: pip install onnxruntime tokenizers"
            ) from e

        model_dir = Path(self.model_path)
        onnx_path = model_dir / "model.onnx"
        tokenizer_path = model_dir / "tokenizer.json"

        if not onnx_path.exists():
            raise FileNotFoundError(f"ONNX model not found at {onnx_path}")
        if not tokenizer_path.exists():
            raise FileNotFoundError(f"Tokenizer not found at {tokenizer_path}")

        self._session = ort.InferenceSession(str(onnx_path))
        self._tokenizer = Tokenizer.from_file(str(tokenizer_path))
        self._tokenizer.enable_padding(pad_id=0, pad_token="[PAD]", length=128)
        self._tokenizer.enable_truncation(max_length=128)

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """使用本地 ONNX 模型嵌入文本。"""
        self._ensure_loaded()

        all_vectors: list[list[float]] = []
        for i in range(0, len(texts), BATCH_SIZE):
            batch = texts[i : i + BATCH_SIZE]
            vectors = self._embed_batch_sync(batch)
            all_vectors.extend(vectors)

        return all_vectors

    def _embed_batch_sync(self, texts: list[str]) -> list[list[float]]:
        """同步批量嵌入。"""
        import numpy as np

        encoded = self._tokenizer.encode_batch(texts)

        input_ids = np.array([e.ids for e in encoded], dtype=np.int64)
        attention_mask = np.array([e.attention_mask for e in encoded], dtype=np.int64)
        token_type_ids = np.zeros_like(input_ids, dtype=np.int64)

        outputs = self._session.run(
            None,
            {
                "input_ids": input_ids,
                "attention_mask": attention_mask,
                "token_type_ids": token_type_ids,
            },
        )

        # Mean pooling over token embeddings
        token_embeddings = outputs[0]  # (batch, seq_len, hidden_dim)
        mask_expanded = attention_mask[:, :, np.newaxis].astype(np.float32)
        sum_embeddings = (token_embeddings * mask_expanded).sum(axis=1)
        sum_mask = mask_expanded.sum(axis=1).clip(min=1e-9)
        mean_pooled = sum_embeddings / sum_mask

        # L2 normalize
        norms = np.linalg.norm(mean_pooled, axis=1, keepdims=True)
        norms = np.clip(norms, a_min=1e-9, a_max=None)
        normalized = mean_pooled / norms

        return normalized.tolist()
