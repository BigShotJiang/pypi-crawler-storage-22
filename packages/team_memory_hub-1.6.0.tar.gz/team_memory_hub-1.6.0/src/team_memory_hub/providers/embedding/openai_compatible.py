"""用于 Ollama、vLLM、TEI 等的 OpenAI 兼容的嵌入提供程序。"""

from __future__ import annotations

import logging

import httpx

from team_memory_hub.providers.embedding.base import EmbeddingProvider

logger = logging.getLogger(__name__)

BATCH_SIZE = 64


class OpenAICompatibleProvider(EmbeddingProvider):
    """通用 OpenAI 兼容的嵌入提供程序。

    适用于任何公开 /v1/embeddings 的服务器（Ollama、vLLM、TEI、LiteLLM）。
    如果原生输出较大，则截断为 TARGET_DIMENSIONS。
    """

    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        model: str = "nomic-embed-text",
        api_key: str = "",
    ):
        # Normalize base_url: strip trailing /v1 if present
        self.base_url = base_url.rstrip("/")
        if not self.base_url.endswith("/v1"):
            self.base_url += "/v1"
        self.model = model
        self.api_key = api_key
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=120.0)
        return self._client

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """使用 OpenAI 兼容的 API 嵌入文本。"""
        all_vectors: list[list[float]] = []

        for i in range(0, len(texts), BATCH_SIZE):
            batch = texts[i : i + BATCH_SIZE]
            vectors = await self._embed_batch(batch)
            all_vectors.extend(vectors)

        return all_vectors

    async def _embed_batch(self, texts: list[str]) -> list[list[float]]:
        """通过 OpenAI 兼容的 API 嵌入单个批次。"""
        client = await self._get_client()

        headers: dict[str, str] = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        url = f"{self.base_url}/embeddings"
        response = await client.post(
            url,
            headers=headers,
            json={
                "input": texts,
                "model": self.model,
            },
        )
        response.raise_for_status()
        data = response.json()

        embeddings = sorted(data["data"], key=lambda x: x["index"])

        vectors: list[list[float]] = []
        for item in embeddings:
            raw = item["embedding"]
            if len(raw) > self.TARGET_DIMENSIONS:
                raw = self._normalize_dimensions(raw)
            vectors.append(raw)

        return vectors

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()
