"""OpenAI 嵌入提供程序（1536 -> 384 截断）。"""

from __future__ import annotations

import logging

import httpx

from team_memory_hub.providers.embedding.base import EmbeddingProvider

logger = logging.getLogger(__name__)

OPENAI_EMBED_URL = "https://api.openai.com/v1/embeddings"
DEFAULT_MODEL = "text-embedding-3-small"
BATCH_SIZE = 2048


class OpenAIProvider(EmbeddingProvider):
    """OpenAI 嵌入提供程序。

    原生输出：1536 维（text-embedding-3-small），截断为 384。
    """

    def __init__(self, api_key: str, model: str = DEFAULT_MODEL):
        self.api_key = api_key
        self.model = model
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=60.0)
        return self._client

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """使用 OpenAI API 和批处理嵌入文本。"""
        all_vectors: list[list[float]] = []

        for i in range(0, len(texts), BATCH_SIZE):
            batch = texts[i : i + BATCH_SIZE]
            vectors = await self._embed_batch(batch)
            all_vectors.extend(vectors)

        return all_vectors

    async def _embed_batch(self, texts: list[str]) -> list[list[float]]:
        """通过 OpenAI API 嵌入单个批次。"""
        client = await self._get_client()

        response = await client.post(
            OPENAI_EMBED_URL,
            headers={"Authorization": f"Bearer {self.api_key}"},
            json={
                "input": texts,
                "model": self.model,
            },
        )
        response.raise_for_status()
        data = response.json()

        # 按 index 排序以保持顺序
        embeddings = sorted(data["data"], key=lambda x: x["index"])

        vectors: list[list[float]] = []
        for item in embeddings:
            raw = item["embedding"]
            normalized = self._normalize_dimensions(raw)
            vectors.append(normalized)

        return vectors

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()
