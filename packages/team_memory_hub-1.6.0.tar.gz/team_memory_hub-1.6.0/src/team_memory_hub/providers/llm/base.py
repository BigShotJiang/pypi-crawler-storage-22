"""LLM 提供程序的抽象基类。"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class LLMProvider(ABC):
    """用于摘要和合并生成的所有 LLM 提供程序的基类。"""

    @abstractmethod
    async def generate(self, prompt: str, **kwargs: Any) -> str:
        """从提示生成文本。

        Returns:
            生成的文本字符串。
        """

    async def close(self) -> None:
        """清理资源。"""
