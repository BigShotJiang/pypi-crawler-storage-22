"""Claude（Anthropic）LLM 提供程序。"""

from __future__ import annotations

import logging
from typing import Any

import httpx

from team_memory_hub.providers.llm.base import LLMProvider

logger = logging.getLogger(__name__)

ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"
DEFAULT_MODEL = "claude-sonnet-4-5-20250929"


class ClaudeProvider(LLMProvider):
    """用于文本生成的 Anthropic Claude 提供程序。"""

    def __init__(self, api_key: str, model: str = DEFAULT_MODEL):
        self.api_key = api_key
        self.model = model
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=60.0)
        return self._client

    async def generate(self, prompt: str, **kwargs: Any) -> str:
        client = await self._get_client()
        max_tokens = kwargs.get("max_tokens", 1024)

        response = await client.post(
            ANTHROPIC_API_URL,
            headers={
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": self.model,
                "max_tokens": max_tokens,
                "messages": [{"role": "user", "content": prompt}],
            },
        )
        response.raise_for_status()
        data = response.json()

        # 从响应中提取文本
        content_blocks = data.get("content", [])
        text_parts = [b["text"] for b in content_blocks if b.get("type") == "text"]
        return " ".join(text_parts)

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()
