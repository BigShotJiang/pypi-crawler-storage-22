"""Google Gemini LLM 提供程序。"""

from __future__ import annotations

import logging
from typing import Any

import httpx

from team_memory_hub.providers.llm.base import LLMProvider

logger = logging.getLogger(__name__)

GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models"
DEFAULT_MODEL = "gemini-2.0-flash"


class GeminiProvider(LLMProvider):
    """用于文本生成的 Google Gemini 提供程序。"""

    def __init__(self, api_key: str, model: str = DEFAULT_MODEL):
        self.api_key = api_key
        self.model = model
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=60.0)
        return self._client

    async def generate(self, prompt: str, **kwargs: Any) -> str:
        client = await self._get_client()

        url = f"{GEMINI_API_URL}/{self.model}:generateContent?key={self.api_key}"

        response = await client.post(
            url,
            json={
                "contents": [{"parts": [{"text": prompt}]}],
            },
        )
        response.raise_for_status()
        data = response.json()

        # 从响应中提取文本
        candidates = data.get("candidates", [])
        if candidates:
            parts = candidates[0].get("content", {}).get("parts", [])
            return " ".join(p.get("text", "") for p in parts)
        return ""

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()
