"""基于规则的 LLM 后备方案：无 API 调用，纯启发式文本处理。"""

from __future__ import annotations

import logging
from typing import Any

from team_memory_hub.providers.llm.base import LLMProvider

logger = logging.getLogger(__name__)


class RulesProvider(LLMProvider):
    """当未配置 LLM API 时的规则引擎后备方案。

    在没有外部 API 调用的情况下提供基本文本处理。
    """

    async def generate(self, prompt: str, **kwargs: Any) -> str:
        """使用简单启发式规则生成文本。"""
        prompt_lower = prompt.lower()

        # Merge request: concatenate inputs
        if "merge" in prompt_lower and "---" in prompt:
            parts = prompt.split("---")
            summaries = [p.strip() for p in parts[1:] if p.strip()]
            if summaries:
                # Deduplicate sentences
                seen: set[str] = set()
                unique_sentences: list[str] = []
                for summary in summaries:
                    for sentence in summary.split(". "):
                        normalized = sentence.strip().lower()
                        if normalized and normalized not in seen:
                            seen.add(normalized)
                            unique_sentences.append(sentence.strip())
                return ". ".join(unique_sentences)

        # Summarize request: take first 200 chars
        if "summar" in prompt_lower:
            # Find the content after the last colon or newline
            lines = prompt.strip().split("\n")
            content_lines = [l for l in lines if l.strip() and not l.strip().startswith(("Summar", "Please", "Generate"))]
            content = " ".join(content_lines)
            return content[:200] if len(content) > 200 else content

        # Default: echo back cleaned input
        lines = prompt.strip().split("\n")
        content = " ".join(l.strip() for l in lines if l.strip())
        return content[:500] if len(content) > 500 else content
