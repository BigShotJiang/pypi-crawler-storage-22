"""FastAPI 应用设置，包含所有路由、中间件和生命周期钩子。"""

from __future__ import annotations

import importlib
import logging
from pathlib import Path

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from team_memory_hub.config import get_config
from team_memory_hub.storage.database import Database

logger = logging.getLogger(__name__)


def create_app() -> FastAPI:
    """创建并配置 FastAPI 应用。"""
    config = get_config()

    app = FastAPI(
        title="Team Memory Hub",
        version="1.6.0",
        description="AI context memory management and distribution system",
    )

    # ========== CORS 中间件 ==========
    app.add_middleware(
        CORSMiddleware,
        allow_origins=config.server.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ========== 审计日志中间件 ==========
    @app.middleware("http")
    async def audit_middleware(request: Request, call_next):
        response: Response = await call_next(request)

        # 记录写操作到审计日志
        if request.method in ("POST", "PUT", "DELETE", "PATCH"):
            if hasattr(request.app.state, "db"):
                try:
                    from team_memory_hub.core.audit import AuditLogger
                    audit = AuditLogger(request.app.state.db)
                    user_id = "anonymous"
                    if hasattr(request.state, "user_id"):
                        user_id = request.state.user_id
                    await audit.log(
                        user_id=user_id,
                        action=f"{request.method} {request.url.path}",
                        ip_address=request.client.host if request.client else None,
                    )
                except Exception:
                    pass  # 不因审计日志失败而中断请求

        return response

    # 在应用状态上存储配置
    app.state.config = config

    # ========== 生命周期事件 ==========
    @app.on_event("startup")
    async def startup() -> None:
        # 初始化数据库
        db = Database(config.database.path)
        await db.initialize()
        app.state.db = db

        # 初始化事件总线
        from team_memory_hub.server.event_bus import get_event_bus
        app.state.event_bus = get_event_bus()

        # 初始化写队列
        try:
            from team_memory_hub.core.write_queue import WriteQueue

            async def execute_batch(batch):
                for op in batch:
                    await db.execute(op.sql, op.params)
                await db.commit()

            write_queue = WriteQueue(
                execute_batch=execute_batch,
                batch_timeout_ms=config.write_queue.batch_timeout_ms,
                batch_max_size=config.write_queue.batch_max_size,
            )
            await write_queue.start()
            app.state.write_queue = write_queue
        except Exception:
            logger.warning("Write queue initialization skipped")

        logger.info("TMH application started")

    @app.on_event("shutdown")
    async def shutdown() -> None:
        # 停止写队列
        if hasattr(app.state, "write_queue"):
            try:
                await app.state.write_queue.stop()
            except Exception:
                pass

        # 关闭数据库
        if hasattr(app.state, "db"):
            await app.state.db.close()

        logger.info("TMH application stopped")

    # ========== 静态文件 ==========
    _static_dir = Path(__file__).resolve().parent.parent / "dashboard" / "static"
    if _static_dir.is_dir():
        app.mount("/dashboard/static", StaticFiles(directory=str(_static_dir)), name="dashboard-static")

    # ========== 注册路由 ==========

    # Phase 1 核心路由（始终存在）
    from team_memory_hub.server.routes.auth import router as auth_router
    from team_memory_hub.server.routes.keys import router as keys_router
    from team_memory_hub.server.routes.memories import router as memories_router

    app.include_router(auth_router, prefix="/api/v1/auth", tags=["auth"])
    app.include_router(keys_router, prefix="/api/v1/keys", tags=["keys"])
    app.include_router(memories_router, prefix="/api/v1/memories", tags=["memories"])

    # Phase 2-4 路由的条件导入
    _try_include_router(app, "team_memory_hub.server.routes.team", "/api/v1/teams", ["teams"])
    _try_include_router(app, "team_memory_hub.server.routes.projects", "/api/v1/projects", ["projects"])
    _try_include_router(app, "team_memory_hub.server.routes.consolidation", "/api/v1/consolidation", ["consolidation"])
    _try_include_router(app, "team_memory_hub.server.routes.events", "/api/v1/events", ["events"])
    _try_include_router(app, "team_memory_hub.server.routes.audit", "/api/v1/audit", ["audit"])
    _try_include_router(app, "team_memory_hub.server.routes.system", "/api/v1/system", ["system"])
    _try_include_router(app, "team_memory_hub.server.routes.curation", "/api/v1/curation", ["curation"])
    _try_include_router(app, "team_memory_hub.server.routes.admin", "/api/v1/admin", ["admin"])
    _try_include_router(app, "team_memory_hub.server.routes.admin_dashboard", "/dashboard/admin", ["admin-dashboard"])
    _try_include_router(app, "team_memory_hub.server.routes.dashboard", "/dashboard", ["dashboard"])

    # Phase 2 路由
    _try_include_router(app, "team_memory_hub.server.routes.search", "/api/v1/search", ["search"])
    _try_include_router(app, "team_memory_hub.server.routes.context", "/api/v1/context", ["context"])
    _try_include_router(app, "team_memory_hub.server.routes.specs", "/api/v1/specs", ["specs"])

    # Phase 3 路由
    _try_include_router(app, "team_memory_hub.server.routes.ingest", "/api/v1/ingest", ["ingest"])
    _try_include_router(app, "team_memory_hub.server.routes.chats", "/api/v1/chats", ["chats"])
    _try_include_router(app, "team_memory_hub.server.routes.preferences", "/api/v1/preferences", ["preferences"])
    _try_include_router(app, "team_memory_hub.server.routes.mcp", "/api/v1/mcp", ["mcp"])

    # ========== Streamable HTTP /mcp 顶层端点 ==========
    try:
        from team_memory_hub.server.mcp_server import streamable_http as _streamable_handler
        app.post("/mcp", tags=["mcp"])(_streamable_handler)
    except Exception:
        pass

    # ========== 健康检查 ==========
    @app.get("/api/v1/health")
    async def health_check(request: Request):
        components = {}
        if hasattr(request.app.state, "db"):
            try:
                await request.app.state.db.execute("SELECT 1")
                components["database"] = {"status": "ok"}
            except Exception:
                components["database"] = {"status": "error"}
        if hasattr(request.app.state, "write_queue"):
            wq = request.app.state.write_queue
            components["write_queue"] = {
                "status": "ok",
                "pending": getattr(wq, "_queue", None) and wq._queue.qsize() or 0,
            }
        return {"status": "healthy", "version": "1.6.0", "components": components}

    return app


def _try_include_router(
    app: FastAPI, module_path: str, prefix: str, tags: list[str]
) -> None:
    """尝试导入并包含路由模块。如果未找到，则静默跳过。"""
    try:
        mod = importlib.import_module(module_path)
        if hasattr(mod, "router"):
            app.include_router(mod.router, prefix=prefix, tags=tags)
    except (ImportError, ModuleNotFoundError):
        logger.debug("Router module %s not available, skipping", module_path)
    except Exception:
        logger.warning("Failed to load router %s", module_path, exc_info=True)


# 模块级应用实例，用于便利（由测试、uvicorn 等使用）
app = create_app()
