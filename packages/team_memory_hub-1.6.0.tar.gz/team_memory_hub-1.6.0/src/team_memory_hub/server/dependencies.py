"""FastAPI 依赖：认证、授权和共享资源。"""

from __future__ import annotations

from datetime import datetime
from typing import Annotated

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from team_memory_hub.config import get_config
from team_memory_hub.core.rbac import check_permission_with_overrides, has_minimum_role
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import User, UserRole

security = HTTPBearer(auto_error=False)


async def get_db(request: Request) -> Database:
    """从应用状态获取数据库实例。"""
    return request.app.state.db


async def get_current_user(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Depends(security),
    db: Database = Depends(get_db),
) -> User:
    """从 JWT 令牌或 API 密钥提取和验证当前用户。

    支持：
    - Bearer JWT 令牌
    - API 密钥 (Bearer <api_key>)
    """
    if credentials is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = credentials.credentials

    # 首先尝试 API 密钥认证
    user = await _try_api_key_auth(db, token)
    if user:
        # 注入 user_id 供审计中间件使用
        request.state.user_id = user.id
        # API Key scope 强制检查
        key_scope = getattr(user, "_api_key_scope", "full_access")
        request.state.api_key_scope = key_scope
        if key_scope == "read_only" and request.method in ("POST", "PUT", "DELETE", "PATCH"):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"API key scope '{key_scope}' insufficient for write operations",
            )
        if key_scope == "mcp_only" and not request.url.path.startswith("/api/v1/mcp"):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"API key scope '{key_scope}' restricted to MCP endpoints only",
            )
        return user

    # 尝试 JWT 认证
    user = await _try_jwt_auth(db, token)
    if user:
        # 注入 user_id 供审计中间件使用
        request.state.user_id = user.id
        return user

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid authentication credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )


async def _try_api_key_auth(db: Database, key: str) -> User | None:
    """通过 API 密钥进行认证。"""
    row = await db.fetch_one(
        """SELECT ak.*, u.name, u.email, u.role, u.team_id, u.is_active as user_active
           FROM api_keys ak
           JOIN users u ON u.id = ak.user_id
           WHERE ak.key = ? AND ak.is_active = 1""",
        (key,),
    )
    if not row:
        return None

    # 检查密钥是否过期
    if row.get("expires_at"):
        expires = datetime.fromisoformat(row["expires_at"])
        if expires < datetime.utcnow():
            return None

    # 检查用户是否活跃
    if not row.get("user_active"):
        return None

    # 更新 last_used_at
    await db.execute(
        "UPDATE api_keys SET last_used_at = ? WHERE id = ?",
        (datetime.utcnow().isoformat(), row["id"]),
    )
    await db.commit()

    # 在用户对象上存储 API 密钥范围以进行权限检查
    user = User(
        id=row["user_id"],
        name=row["name"],
        email=row["email"],
        role=row["role"],
        team_id=row["team_id"],
    )
    # 附加密钥范围信息
    user._api_key_scope = row.get("scope", "full_access")  # type: ignore[attr-defined]
    return user


async def _try_jwt_auth(db: Database, token: str) -> User | None:
    """通过 JWT 令牌进行认证。"""
    from jose import JWTError, jwt as jose_jwt

    config = get_config()
    try:
        payload = jose_jwt.decode(
            token, config.auth.jwt_secret, algorithms=[config.auth.jwt_algorithm]
        )
    except JWTError:
        return None

    if payload.get("type") not in ("access", None):
        return None

    user_id = payload.get("sub")
    if not user_id:
        return None

    row = await db.fetch_one(
        "SELECT * FROM users WHERE id = ? AND is_active = 1",
        (user_id,),
    )
    if not row:
        return None

    return User(
        id=row["id"],
        name=row["name"],
        email=row["email"],
        role=row["role"],
        team_id=row["team_id"],
    )


def require_role(minimum_role: str):
    """依赖工厂：要求最低角色级别。"""

    async def _check(current_user: User = Depends(get_current_user)) -> User:
        if not has_minimum_role(current_user.role, minimum_role):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Requires {minimum_role} role or higher",
            )
        return current_user

    return _check


def require_permission(permission: str):
    """依赖工厂：要求细粒度权限，支持用户级覆盖。"""

    async def _check(
        current_user: User = Depends(get_current_user),
        db: Database = Depends(get_db),
    ) -> User:
        allowed = await check_permission_with_overrides(
            current_user.role, permission, current_user.id, db
        )
        if not allowed:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"权限不足：需要 {permission}",
            )
        return current_user

    return _check


def api_key_auth(required_scope: str | None = None):
    """依赖工厂：要求 API 密钥认证，支持可选的范围检查。"""

    async def _check(
        credentials: HTTPAuthorizationCredentials | None = Depends(security),
        db: Database = Depends(get_db),
    ) -> User:
        if credentials is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="API key required",
            )

        user = await _try_api_key_auth(db, credentials.credentials)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid API key",
            )

        # 如果需要，检查范围
        if required_scope:
            key_scope = getattr(user, "_api_key_scope", "full_access")
            if key_scope != "full_access" and key_scope != required_scope:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"API key scope '{key_scope}' insufficient, requires '{required_scope}'",
                )

        return user

    return _check
