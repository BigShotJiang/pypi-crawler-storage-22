"""内存事件总线：使用每个订阅者的 asyncio.Queue 实现 publish/subscribe 模式。"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)


class EventBus:
    """用于 SSE 实时事件的异步事件总线。

    每个订阅者都有自己的 asyncio.Queue。支持通配符 '*' 订阅。
    """

    def __init__(self) -> None:
        self._subscribers: dict[str, list[asyncio.Queue]] = {}
        self._lock = asyncio.Lock()

    async def publish(self, event_type: str, data: dict[str, Any]) -> None:
        """将事件发布给所有匹配的订阅者。"""
        event = {
            "type": event_type,
            "data": data,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        targets: set[asyncio.Queue] = set()

        # 精确匹配订阅者
        for q in self._subscribers.get(event_type, []):
            targets.add(q)

        # 通配符订阅者
        for q in self._subscribers.get("*", []):
            targets.add(q)

        for queue in targets:
            try:
                queue.put_nowait(event)
            except asyncio.QueueFull:
                logger.warning("Subscriber queue full, dropping event %s", event_type)

    def subscribe(
        self,
        event_types: list[str] | None = None,
        max_size: int = 256,
    ) -> asyncio.Queue:
        """为给定的事件类型创建新的订阅者队列。

        参数：
            event_types：要监听的事件类型列表。None 或空 -> ["*"]。
            max_size：事件被丢弃前的最大队列深度。

        返回：
            将接收匹配事件的 asyncio.Queue。
        """
        queue: asyncio.Queue = asyncio.Queue(maxsize=max_size)
        types = event_types if event_types else ["*"]
        for t in types:
            self._subscribers.setdefault(t, []).append(queue)
        return queue

    def unsubscribe(self, queue: asyncio.Queue) -> None:
        """从所有事件类型中移除订阅者队列。"""
        for event_type, queues in list(self._subscribers.items()):
            if queue in queues:
                queues.remove(queue)
            if not queues:
                del self._subscribers[event_type]


# 全局单例
_event_bus: EventBus | None = None


def get_event_bus() -> EventBus:
    """获取或创建全局事件总线。"""
    global _event_bus
    if _event_bus is None:
        _event_bus = EventBus()
    return _event_bus
