"""MCP Server: JSON-RPC based Model Context Protocol server (V1.6).

提供 5 个工具，通过 tool_set 配置动态注册：
  - read_only:  search_memory, get_memory_detail
  - read_write: + store_memory
  - full_crud:  + update_memory, delete_memory

传输层：
  - HTTP POST /rpc          — 原始 JSON-RPC 端点
  - POST /streamable        — Streamable HTTP transport（单端点 JSON-RPC）
  - GET /sse                — SSE transport（Chatbox 等客户端使用）
  - POST /messages          — SSE transport 消息端点

权限矩阵（RBAC）：
  search_memory     → viewer+
  get_memory_detail → viewer+
  store_memory      → member+
  update_memory     → member（仅自己）/ maintainer+（任意）
  delete_memory     → admin
"""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from team_memory_hub.core.memory_file_store import MemoryFileStore
from team_memory_hub.core.memory_store import MemoryStore
from team_memory_hub.server.dependencies import api_key_auth, get_db
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import MemoryCreate, MemoryUpdate, User

logger = logging.getLogger(__name__)

router = APIRouter()

# ========== SSE Session 管理 ==========

# session_id -> asyncio.Queue（用于 SSE 消息推送）
_sse_sessions: dict[str, asyncio.Queue] = {}
# session_id -> User（缓存认证用户）
_sse_session_users: dict[str, User] = {}

# ========== 常量 ==========

ROLE_HIERARCHY = {"admin": 4, "maintainer": 3, "member": 2, "viewer": 1}

# 每个工具需要的最低角色
TOOL_MIN_ROLE: dict[str, str] = {
    "search_memory": "viewer",
    "get_memory_detail": "viewer",
    "store_memory": "member",
    "update_memory": "member",
    "delete_memory": "admin",
}

# tool_set 到允许的工具列表
TOOL_SETS: dict[str, list[str]] = {
    "read_only": ["search_memory", "get_memory_detail"],
    "read_write": ["search_memory", "get_memory_detail", "store_memory"],
    "full_crud": ["search_memory", "get_memory_detail", "store_memory", "update_memory", "delete_memory"],
}


# ========== JSON-RPC Models ==========

class JsonRpcRequest(BaseModel):
    jsonrpc: str = "2.0"
    method: str
    params: dict[str, Any] | None = None
    id: int | str | None = None


class JsonRpcResponse(BaseModel):
    jsonrpc: str = "2.0"
    result: Any = None
    error: dict[str, Any] | None = None
    id: int | str | None = None


# ========== MCP Tool Definitions ==========

_ALL_TOOLS: list[dict[str, Any]] = [
    {
        "name": "search_memory",
        "description": "Search team memories by keyword. Returns a list of matching memories.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query keywords"},
                "category": {
                    "type": "string",
                    "description": "Filter by category",
                    "enum": ["general", "decision", "experience", "bug_fix", "architecture", "coding_standard", "workflow"],
                },
                "scope": {
                    "type": "string",
                    "description": "Filter by scope",
                    "enum": ["private", "project", "team"],
                },
                "limit": {"type": "integer", "description": "Max results (default 10)", "default": 10},
            },
            "required": ["query"],
        },
    },
    {
        "name": "get_memory_detail",
        "description": "Get full content of a specific memory by ID.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "memory_id": {"type": "string", "description": "The memory ID (e.g. mem_abc12345)"},
            },
            "required": ["memory_id"],
        },
    },
    {
        "name": "store_memory",
        "description": "Store a new memory. Requires member+ role.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "Memory content"},
                "summary": {"type": "string", "description": "Brief summary"},
                "category": {
                    "type": "string",
                    "enum": ["general", "decision", "experience", "bug_fix", "architecture", "coding_standard", "workflow"],
                    "default": "general",
                },
                "tags": {"type": "array", "items": {"type": "string"}, "description": "Tags"},
                "scope": {"type": "string", "enum": ["private", "project", "team"], "default": "private"},
            },
            "required": ["content"],
        },
    },
    {
        "name": "update_memory",
        "description": "Update an existing memory. Member can update own memories, maintainer+ can update any.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "memory_id": {"type": "string", "description": "The memory ID to update"},
                "content": {"type": "string", "description": "New content (optional)"},
                "summary": {"type": "string", "description": "New summary (optional)"},
                "category": {
                    "type": "string",
                    "enum": ["general", "decision", "experience", "bug_fix", "architecture", "coding_standard", "workflow"],
                },
                "tags": {"type": "array", "items": {"type": "string"}, "description": "New tags (optional)"},
                "scope": {"type": "string", "enum": ["private", "project", "team"]},
            },
            "required": ["memory_id"],
        },
    },
    {
        "name": "delete_memory",
        "description": "Soft-delete a memory (sets quality to archived). Requires admin role.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "memory_id": {"type": "string", "description": "The memory ID to delete"},
            },
            "required": ["memory_id"],
        },
    },
]


# ========== 辅助函数 ==========

def _get_tool_set(request: Request) -> str:
    """获取当前配置的 tool_set。"""
    config = getattr(request.app.state, "config", None)
    if config and hasattr(config, "mcp"):
        return config.mcp.tool_set
    return "read_only"


def _get_allowed_tools(tool_set: str) -> list[str]:
    """根据 tool_set 配置获取允许的工具名称列表。"""
    return TOOL_SETS.get(tool_set, TOOL_SETS["read_only"])


def _has_role(user: User, min_role: str) -> bool:
    """检查用户是否满足最低角色要求。"""
    user_level = ROLE_HIERARCHY.get(user.role, 0)
    required_level = ROLE_HIERARCHY.get(min_role, 999)
    return user_level >= required_level


def _get_store(request: Request, db: Database) -> MemoryStore:
    """构建 MemoryStore 实例。"""
    config = request.app.state.config
    file_store = MemoryFileStore(config.storage.memories_dir)
    return MemoryStore(db, file_store)


# ========== MCP JSON-RPC Endpoint ==========

@router.post("/rpc")
async def mcp_rpc(
    rpc_request: JsonRpcRequest,
    request: Request,
    current_user: User = Depends(api_key_auth("mcp_only")),
    db: Database = Depends(get_db),
):
    """Handle MCP JSON-RPC requests."""
    method = rpc_request.method
    params = rpc_request.params or {}

    try:
        if method == "tools/list":
            tool_set = _get_tool_set(request)
            allowed = _get_allowed_tools(tool_set)
            tools = [t for t in _ALL_TOOLS if t["name"] in allowed]
            return JsonRpcResponse(result={"tools": tools}, id=rpc_request.id)

        elif method == "tools/call":
            tool_name = params.get("name", "")
            arguments = params.get("arguments", {})
            result = await _handle_tool_call(
                tool_name, arguments, request, current_user, db,
            )
            return JsonRpcResponse(
                result={"content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False)}]},
                id=rpc_request.id,
            )

        elif method == "initialize":
            return JsonRpcResponse(
                result={
                    "protocolVersion": "2024-11-05",
                    "capabilities": {"tools": {"listChanged": False}},
                    "serverInfo": {"name": "team-memory-hub", "version": "1.6.0"},
                },
                id=rpc_request.id,
            )

        elif method == "ping":
            return JsonRpcResponse(result={}, id=rpc_request.id)

        else:
            return JsonRpcResponse(
                error={"code": -32601, "message": f"Method not found: {method}"},
                id=rpc_request.id,
            )

    except Exception as e:
        logger.exception("MCP RPC error")
        return JsonRpcResponse(
            error={"code": -32000, "message": str(e)},
            id=rpc_request.id,
        )


# ========== Tool Dispatcher ==========

async def _handle_tool_call(
    tool_name: str,
    arguments: dict,
    request: Request,
    user: User,
    db: Database,
) -> Any:
    """Dispatch a tool call with tool_set and RBAC checks."""
    # 1. tool_set 权限检查
    tool_set = _get_tool_set(request)
    allowed = _get_allowed_tools(tool_set)
    if tool_name not in allowed:
        return {"error": f"Tool '{tool_name}' is not enabled in tool_set '{tool_set}'"}

    # 2. RBAC 角色检查
    min_role = TOOL_MIN_ROLE.get(tool_name)
    if min_role and not _has_role(user, min_role):
        return {"error": f"Insufficient permissions. '{tool_name}' requires {min_role}+ role."}

    # 3. 分发到具体处理函数
    handlers = {
        "search_memory": _tool_search_memory,
        "get_memory_detail": _tool_get_memory_detail,
        "store_memory": _tool_store_memory,
        "update_memory": _tool_update_memory,
        "delete_memory": _tool_delete_memory,
    }

    handler = handlers.get(tool_name)
    if not handler:
        return {"error": f"Unknown tool: {tool_name}"}

    return await handler(arguments, request, user, db)


# ========== Tool Handlers ==========

async def _tool_search_memory(args: dict, request: Request, user: User, db: Database) -> dict:
    """Search memories by keyword."""
    query = args.get("query", "")
    category = args.get("category")
    scope = args.get("scope")
    limit = min(args.get("limit", 10), 50)

    conditions = ["m.team_id = ?", "(m.scope != 'private' OR m.owner_id = ?)"]
    params: list[Any] = [user.team_id, user.id]

    if query:
        conditions.append("(m.summary LIKE ? OR m.tags LIKE ?)")
        params.extend([f"%{query}%", f"%{query}%"])
    if category:
        conditions.append("m.category = ?")
        params.append(category)
    if scope:
        conditions.append("m.scope = ?")
        params.append(scope)

    conditions.append("m.quality != 'archived'")
    where = " AND ".join(conditions)

    rows = await db.fetch_all(
        f"SELECT * FROM memories m WHERE {where} ORDER BY m.updated_at DESC LIMIT ?",
        tuple(params + [limit]),
    )

    return {
        "results": [
            {
                "id": row["id"],
                "summary": row["summary"],
                "category": row.get("category", "general"),
                "tags": json.loads(row.get("tags", "[]")) if isinstance(row.get("tags"), str) else row.get("tags", []),
                "scope": row.get("scope", "private"),
                "quality": row.get("quality", "community"),
                "updated_at": row.get("updated_at", ""),
            }
            for row in rows
        ],
        "count": len(rows),
    }


async def _tool_get_memory_detail(args: dict, request: Request, user: User, db: Database) -> dict:
    """Get full memory detail."""
    store = _get_store(request, db)
    memory_id = args.get("memory_id", "")

    detail = await store.get_detail(memory_id)
    if detail is None:
        return {"error": "Memory not found"}

    # 访问控制：私有记忆仅所有者可见
    if detail.scope == "private" and detail.owner_id != user.id:
        return {"error": "Access denied"}
    if detail.team_id != user.team_id:
        return {"error": "Access denied"}

    return {
        "id": detail.id,
        "summary": detail.summary,
        "content": detail.content,
        "category": detail.category,
        "tags": detail.tags,
        "scope": detail.scope,
        "quality": detail.quality,
        "created_at": detail.created_at.isoformat() if detail.created_at else None,
        "updated_at": detail.updated_at.isoformat() if detail.updated_at else None,
    }


async def _tool_store_memory(args: dict, request: Request, user: User, db: Database) -> dict:
    """Store a new memory."""
    store = _get_store(request, db)
    data = MemoryCreate(
        content=args.get("content", ""),
        summary=args.get("summary"),
        category=args.get("category", "general"),
        tags=args.get("tags", []),
        scope=args.get("scope", "private"),
    )

    memory = await store.create(
        data=data,
        owner_id=user.id,
        team_id=user.team_id,
        owner_name=user.name,
    )

    return {"id": memory.id, "summary": memory.summary, "status": "created"}


async def _tool_update_memory(args: dict, request: Request, user: User, db: Database) -> dict:
    """Update an existing memory. Member can update own, maintainer+ can update any."""
    store = _get_store(request, db)
    memory_id = args.get("memory_id", "")

    # 检查记忆是否存在
    existing = await store.get(memory_id)
    if existing is None:
        return {"error": "Memory not found"}

    # 权限：member 仅自己，maintainer+ 任意
    if existing.owner_id != user.id and not _has_role(user, "maintainer"):
        return {"error": "Access denied. Members can only update their own memories."}

    # 团队隔离
    if existing.team_id != user.team_id:
        return {"error": "Access denied"}

    data = MemoryUpdate(
        content=args.get("content"),
        summary=args.get("summary"),
        category=args.get("category"),
        tags=args.get("tags"),
        scope=args.get("scope"),
    )

    updated = await store.update(
        memory_id=memory_id,
        data=data,
        changed_by=user.id,
        owner_name=user.name,
    )

    if updated is None:
        return {"error": "Update failed"}

    return {"id": updated.id, "summary": updated.summary, "status": "updated"}


async def _tool_delete_memory(args: dict, request: Request, user: User, db: Database) -> dict:
    """Soft-delete a memory (set quality to archived). Admin only."""
    store = _get_store(request, db)
    memory_id = args.get("memory_id", "")

    existing = await store.get(memory_id)
    if existing is None:
        return {"error": "Memory not found"}

    # 团队隔离
    if existing.team_id != user.team_id:
        return {"error": "Access denied"}

    # 软删除：quality → archived
    success = await store.update_quality(
        memory_id=memory_id,
        quality="archived",
        changed_by=user.id,
    )

    if not success:
        return {"error": "Delete failed"}

    return {"id": memory_id, "status": "archived"}


# ========== SSE Transport ==========

async def _process_rpc(
    rpc_data: dict,
    request: Request,
    user: User,
    db: Database,
) -> dict:
    """处理 JSON-RPC 请求并返回响应字典（SSE 和 HTTP 共用）。"""
    method = rpc_data.get("method", "")
    params = rpc_data.get("params") or {}
    req_id = rpc_data.get("id")

    try:
        if method == "tools/list":
            tool_set = _get_tool_set(request)
            allowed = _get_allowed_tools(tool_set)
            tools = [t for t in _ALL_TOOLS if t["name"] in allowed]
            return {"jsonrpc": "2.0", "result": {"tools": tools}, "id": req_id}

        elif method == "tools/call":
            tool_name = params.get("name", "")
            arguments = params.get("arguments", {})
            result = await _handle_tool_call(tool_name, arguments, request, user, db)
            return {
                "jsonrpc": "2.0",
                "result": {"content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False)}]},
                "id": req_id,
            }

        elif method == "initialize":
            return {
                "jsonrpc": "2.0",
                "result": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {"tools": {"listChanged": False}},
                    "serverInfo": {"name": "team-memory-hub", "version": "1.6.0"},
                },
                "id": req_id,
            }

        elif method == "ping":
            return {"jsonrpc": "2.0", "result": {}, "id": req_id}

        elif method == "notifications/initialized":
            # 客户端通知，无需响应
            return None  # type: ignore[return-value]

        else:
            return {
                "jsonrpc": "2.0",
                "error": {"code": -32601, "message": f"Method not found: {method}"},
                "id": req_id,
            }

    except Exception as e:
        logger.exception("MCP RPC error")
        return {
            "jsonrpc": "2.0",
            "error": {"code": -32000, "message": str(e)},
            "id": req_id,
        }


@router.get("/sse")
async def sse_endpoint(
    request: Request,
    current_user: User = Depends(api_key_auth("mcp_only")),
):
    """SSE transport: 建立 SSE 连接，发送消息端点 URL。

    客户端连接后收到 endpoint 事件，然后通过 POST /messages 发送 JSON-RPC。
    """
    session_id = str(uuid.uuid4())
    queue: asyncio.Queue = asyncio.Queue()
    _sse_sessions[session_id] = queue
    _sse_session_users[session_id] = current_user

    logger.info("SSE session created: %s (user: %s)", session_id, current_user.id)

    async def event_generator():
        try:
            # 发送消息端点 URL
            endpoint_url = f"/api/v1/mcp/messages?sessionId={session_id}"
            yield f"event: endpoint\ndata: {endpoint_url}\n\n"

            # 持续监听队列中的消息
            while True:
                if await request.is_disconnected():
                    break
                try:
                    message = await asyncio.wait_for(queue.get(), timeout=30.0)
                    yield f"event: message\ndata: {json.dumps(message, ensure_ascii=False)}\n\n"
                except asyncio.TimeoutError:
                    # 发送心跳保持连接
                    yield ": heartbeat\n\n"
        except asyncio.CancelledError:
            pass
        finally:
            _sse_sessions.pop(session_id, None)
            _sse_session_users.pop(session_id, None)
            logger.info("SSE session closed: %s", session_id)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.post("/messages")
async def sse_messages(
    request: Request,
    sessionId: str = Query(..., description="SSE session ID"),
    db: Database = Depends(get_db),
):
    """SSE transport: 接收客户端 JSON-RPC 消息并通过 SSE 流返回响应。"""
    queue = _sse_sessions.get(sessionId)
    if queue is None:
        raise HTTPException(status_code=404, detail="Session not found or expired")

    user = _sse_session_users.get(sessionId)
    if user is None:
        raise HTTPException(status_code=401, detail="Session not authenticated")

    body = await request.json()
    logger.debug("SSE message received (session %s): %s", sessionId, body.get("method", ""))

    response = await _process_rpc(body, request, user, db)

    # notifications 不需要响应
    if response is not None:
        await queue.put(response)

    return {"ok": True}


# ========== Streamable HTTP Transport ==========

@router.post("/streamable")
async def streamable_http(
    request: Request,
    current_user: User = Depends(api_key_auth("mcp_only")),
    db: Database = Depends(get_db),
):
    """Streamable HTTP transport: 单端点接收 JSON-RPC 请求并返回 JSON 响应。

    兼容仅支持 HTTP POST 的 MCP 客户端（如 Chatbox）。
    """
    body = await request.json()
    response = await _process_rpc(body, request, current_user, db)
    if response is None:
        return {"jsonrpc": "2.0", "result": {}, "id": body.get("id")}
    return response


# ========== REST convenience endpoints ==========

@router.get("/tools")
async def list_tools(request: Request):
    """List available MCP tools (REST endpoint)."""
    tool_set = _get_tool_set(request)
    allowed = _get_allowed_tools(tool_set)
    tools = [t for t in _ALL_TOOLS if t["name"] in allowed]
    return {"tools": tools, "tool_set": tool_set}
