"""管理后台 API 路由：Teams / Projects / Users / API Keys / Curation / System。"""

from __future__ import annotations

import json
import os
import secrets
import string
import uuid
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel

from team_memory_hub.core.rbac import check_permission_with_overrides
from team_memory_hub.server.dependencies import get_current_user, get_db
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import (
    PermissionOverrideType,
    User,
    UserRole,
    质量状态,
)

router = APIRouter()


# ========== 请求/响应模型 ==========

class TeamCreateRequest(BaseModel):
    name: str
    settings: dict[str, Any] | None = None


class TeamUpdateRequest(BaseModel):
    name: str | None = None
    settings: dict[str, Any] | None = None


class ProjectCreateRequest(BaseModel):
    name: str
    team_id: str
    description: str | None = None
    project_type: str | None = None


class ProjectUpdateRequest(BaseModel):
    name: str | None = None
    description: str | None = None
    project_type: str | None = None


class UserCreateRequest(BaseModel):
    name: str
    email: str
    password: str
    role: UserRole = UserRole.MEMBER
    team_id: str


class UserUpdateRequest(BaseModel):
    name: str | None = None
    email: str | None = None
    team_id: str | None = None


class RoleUpdateRequest(BaseModel):
    role: UserRole


class BatchCurationRequest(BaseModel):
    memory_ids: list[str]
    action: str  # verify / archive / pin / stale


class ConfigUpdateRequest(BaseModel):
    updates: dict[str, Any]


class PermissionOverrideRequest(BaseModel):
    user_id: str
    permission: str
    type: PermissionOverrideType
    reason: str | None = None
    expires_at: datetime | None = None


# ========== 权限检查辅助 ==========

async def _require_perm(perm: str, user: User, db: Database) -> None:
    """检查权限，不满足则抛出 403。"""
    allowed = await check_permission_with_overrides(user.role, perm, user.id, db)
    if not allowed:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"权限不足：需要 {perm}",
        )


def _gen_id(prefix: str) -> str:
    """生成带前缀的 ID。"""
    return f"{prefix}_{''.join(secrets.choice(string.ascii_lowercase + string.digits) for _ in range(8))}"


# ========== Teams CRUD ==========

@router.get("/teams")
async def list_teams(
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    search: str | None = Query(None),
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("team:list", current_user, db)

    conditions: list[str] = []
    params: list[Any] = []
    if search:
        conditions.append("t.name LIKE ?")
        params.append(f"%{search}%")
    where = " AND ".join(conditions) if conditions else "1=1"
    offset = (page - 1) * per_page

    count_row = await db.fetch_one(
        f"SELECT COUNT(*) as cnt FROM teams t WHERE {where}", tuple(params)
    )
    total = count_row["cnt"] if count_row else 0

    rows = await db.fetch_all(
        f"""SELECT t.*,
                   (SELECT COUNT(*) FROM users u WHERE u.team_id = t.id AND u.is_active = 1) as member_count,
                   (SELECT COUNT(*) FROM projects p WHERE p.team_id = t.id AND p.is_active = 1) as project_count
            FROM teams t WHERE {where}
            ORDER BY t.created_at DESC LIMIT ? OFFSET ?""",
        tuple(params + [per_page, offset]),
    )
    return {"items": rows, "total": total, "page": page, "per_page": per_page}


@router.post("/teams", status_code=status.HTTP_201_CREATED)
async def create_team(
    data: TeamCreateRequest,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("team:create", current_user, db)

    team_id = _gen_id("team")
    settings_json = json.dumps(data.settings or {})
    try:
        await db.execute(
            "INSERT INTO teams (id, name, settings) VALUES (?, ?, ?)",
            (team_id, data.name, settings_json),
        )
        await db.commit()
    except Exception:
        raise HTTPException(status_code=400, detail="团队名称已存在")

    return {"id": team_id, "name": data.name}


@router.get("/teams/{team_id}")
async def get_team(
    team_id: str,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("team:list", current_user, db)

    row = await db.fetch_one(
        """SELECT t.*,
                  (SELECT COUNT(*) FROM users u WHERE u.team_id = t.id AND u.is_active = 1) as member_count,
                  (SELECT COUNT(*) FROM projects p WHERE p.team_id = t.id AND p.is_active = 1) as project_count
           FROM teams t WHERE t.id = ?""",
        (team_id,),
    )
    if not row:
        raise HTTPException(status_code=404, detail="团队不存在")
    return row


@router.put("/teams/{team_id}")
async def update_team(
    team_id: str,
    data: TeamUpdateRequest,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("team:update", current_user, db)

    existing = await db.fetch_one("SELECT id FROM teams WHERE id = ?", (team_id,))
    if not existing:
        raise HTTPException(status_code=404, detail="团队不存在")

    updates: list[str] = []
    params: list[Any] = []
    if data.name is not None:
        updates.append("name = ?")
        params.append(data.name)
    if data.settings is not None:
        updates.append("settings = ?")
        params.append(json.dumps(data.settings))

    if updates:
        params.append(team_id)
        await db.execute(
            f"UPDATE teams SET {', '.join(updates)} WHERE id = ?", tuple(params)
        )
        await db.commit()

    return {"id": team_id, "updated": True}


@router.delete("/teams/{team_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_team(
    team_id: str,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("team:delete", current_user, db)

    # 安全检查：有活跃用户或项目不允许删除
    user_count = await db.fetch_one(
        "SELECT COUNT(*) as cnt FROM users WHERE team_id = ? AND is_active = 1",
        (team_id,),
    )
    if user_count and user_count["cnt"] > 0:
        raise HTTPException(status_code=400, detail="团队下有活跃用户，无法删除")

    proj_count = await db.fetch_one(
        "SELECT COUNT(*) as cnt FROM projects WHERE team_id = ? AND is_active = 1",
        (team_id,),
    )
    if proj_count and proj_count["cnt"] > 0:
        raise HTTPException(status_code=400, detail="团队下有活跃项目，无法删除")

    await db.execute("DELETE FROM teams WHERE id = ?", (team_id,))
    await db.commit()


# ========== Projects CRUD ==========

@router.get("/projects")
async def list_projects(
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    team_id: str | None = Query(None),
    search: str | None = Query(None),
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("project:list", current_user, db)

    conditions: list[str] = ["p.is_active = 1"]
    params: list[Any] = []
    if team_id:
        conditions.append("p.team_id = ?")
        params.append(team_id)
    if search:
        conditions.append("p.name LIKE ?")
        params.append(f"%{search}%")
    where = " AND ".join(conditions)
    offset = (page - 1) * per_page

    count_row = await db.fetch_one(
        f"SELECT COUNT(*) as cnt FROM projects p WHERE {where}", tuple(params)
    )
    total = count_row["cnt"] if count_row else 0

    rows = await db.fetch_all(
        f"""SELECT p.*, t.name as team_name
            FROM projects p LEFT JOIN teams t ON t.id = p.team_id
            WHERE {where}
            ORDER BY p.created_at DESC LIMIT ? OFFSET ?""",
        tuple(params + [per_page, offset]),
    )
    return {"items": rows, "total": total, "page": page, "per_page": per_page}


@router.post("/projects", status_code=status.HTTP_201_CREATED)
async def create_project(
    data: ProjectCreateRequest,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("project:create", current_user, db)

    # 验证团队存在
    team = await db.fetch_one("SELECT id FROM teams WHERE id = ?", (data.team_id,))
    if not team:
        raise HTTPException(status_code=400, detail="指定的团队不存在")

    project_id = _gen_id("proj")
    try:
        await db.execute(
            "INSERT INTO projects (id, name, team_id, description, project_type) VALUES (?, ?, ?, ?, ?)",
            (project_id, data.name, data.team_id, data.description, data.project_type),
        )
        await db.commit()
    except Exception:
        raise HTTPException(status_code=400, detail="项目名称在该团队内已存在")

    return {"id": project_id, "name": data.name}


@router.get("/projects/{project_id}")
async def get_project(
    project_id: str,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("project:list", current_user, db)

    row = await db.fetch_one(
        """SELECT p.*, t.name as team_name
           FROM projects p LEFT JOIN teams t ON t.id = p.team_id
           WHERE p.id = ?""",
        (project_id,),
    )
    if not row:
        raise HTTPException(status_code=404, detail="项目不存在")
    return row


@router.put("/projects/{project_id}")
async def update_project(
    project_id: str,
    data: ProjectUpdateRequest,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("project:update", current_user, db)

    existing = await db.fetch_one("SELECT id FROM projects WHERE id = ?", (project_id,))
    if not existing:
        raise HTTPException(status_code=404, detail="项目不存在")

    updates: list[str] = []
    params: list[Any] = []
    if data.name is not None:
        updates.append("name = ?")
        params.append(data.name)
    if data.description is not None:
        updates.append("description = ?")
        params.append(data.description)
    if data.project_type is not None:
        updates.append("project_type = ?")
        params.append(data.project_type)

    if updates:
        params.append(project_id)
        await db.execute(
            f"UPDATE projects SET {', '.join(updates)} WHERE id = ?", tuple(params)
        )
        await db.commit()

    return {"id": project_id, "updated": True}


@router.delete("/projects/{project_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_project(
    project_id: str,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("project:delete", current_user, db)

    existing = await db.fetch_one("SELECT id FROM projects WHERE id = ?", (project_id,))
    if not existing:
        raise HTTPException(status_code=404, detail="项目不存在")

    # 软删除
    await db.execute("UPDATE projects SET is_active = 0 WHERE id = ?", (project_id,))
    await db.commit()


# ========== Users CRUD ==========

@router.get("/users")
async def list_users(
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    role: str | None = Query(None),
    team_id: str | None = Query(None),
    search: str | None = Query(None),
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("user:list", current_user, db)

    conditions: list[str] = []
    params: list[Any] = []
    if role:
        conditions.append("u.role = ?")
        params.append(role)
    if team_id:
        conditions.append("u.team_id = ?")
        params.append(team_id)
    if search:
        conditions.append("(u.name LIKE ? OR u.email LIKE ?)")
        params.extend([f"%{search}%", f"%{search}%"])
    where = " AND ".join(conditions) if conditions else "1=1"
    offset = (page - 1) * per_page

    count_row = await db.fetch_one(
        f"SELECT COUNT(*) as cnt FROM users u WHERE {where}", tuple(params)
    )
    total = count_row["cnt"] if count_row else 0

    rows = await db.fetch_all(
        f"""SELECT u.id, u.name, u.email, u.role, u.team_id, u.is_active, u.created_at,
                   t.name as team_name
            FROM users u LEFT JOIN teams t ON t.id = u.team_id
            WHERE {where}
            ORDER BY u.created_at DESC LIMIT ? OFFSET ?""",
        tuple(params + [per_page, offset]),
    )
    return {"items": rows, "total": total, "page": page, "per_page": per_page}


@router.post("/users", status_code=status.HTTP_201_CREATED)
async def create_user(
    data: UserCreateRequest,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("user:create", current_user, db)

    # 验证团队存在
    team = await db.fetch_one("SELECT id FROM teams WHERE id = ?", (data.team_id,))
    if not team:
        raise HTTPException(status_code=400, detail="指定的团队不存在")

    # 检查邮箱唯一
    existing = await db.fetch_one("SELECT id FROM users WHERE email = ?", (data.email,))
    if existing:
        raise HTTPException(status_code=400, detail="邮箱已被使用")

    user_id = _gen_id("usr")
    # 密码哈希
    from team_memory_hub.server.routes.auth import hash_password
    password_hash = hash_password(data.password)

    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id, password_hash) VALUES (?, ?, ?, ?, ?, ?)",
        (user_id, data.name, data.email, data.role, data.team_id, password_hash),
    )
    await db.commit()

    return {"id": user_id, "name": data.name, "email": data.email, "role": data.role}


@router.get("/users/{user_id}")
async def get_user(
    user_id: str,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("user:list", current_user, db)

    row = await db.fetch_one(
        """SELECT u.id, u.name, u.email, u.role, u.team_id, u.is_active, u.created_at,
                  t.name as team_name
           FROM users u LEFT JOIN teams t ON t.id = u.team_id
           WHERE u.id = ?""",
        (user_id,),
    )
    if not row:
        raise HTTPException(status_code=404, detail="用户不存在")
    return row


@router.put("/users/{user_id}")
async def update_user(
    user_id: str,
    data: UserUpdateRequest,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("user:update", current_user, db)

    existing = await db.fetch_one("SELECT id FROM users WHERE id = ?", (user_id,))
    if not existing:
        raise HTTPException(status_code=404, detail="用户不存在")

    updates: list[str] = []
    params: list[Any] = []
    if data.name is not None:
        updates.append("name = ?")
        params.append(data.name)
    if data.email is not None:
        updates.append("email = ?")
        params.append(data.email)
    if data.team_id is not None:
        updates.append("team_id = ?")
        params.append(data.team_id)

    if updates:
        params.append(user_id)
        await db.execute(
            f"UPDATE users SET {', '.join(updates)} WHERE id = ?", tuple(params)
        )
        await db.commit()

    return {"id": user_id, "updated": True}


@router.delete("/users/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_user(
    user_id: str,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("user:delete", current_user, db)

    if user_id == current_user.id:
        raise HTTPException(status_code=400, detail="不能删除当前登录的用户")

    existing = await db.fetch_one("SELECT id FROM users WHERE id = ?", (user_id,))
    if not existing:
        raise HTTPException(status_code=404, detail="用户不存在")

    await db.execute("UPDATE users SET is_active = 0 WHERE id = ?", (user_id,))
    await db.commit()


@router.patch("/users/{user_id}/toggle-active")
async def toggle_user_active(
    user_id: str,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("user:toggle_active", current_user, db)

    if user_id == current_user.id:
        raise HTTPException(status_code=400, detail="不能禁用当前登录的用户")

    row = await db.fetch_one("SELECT id, is_active FROM users WHERE id = ?", (user_id,))
    if not row:
        raise HTTPException(status_code=404, detail="用户不存在")

    new_active = not bool(row["is_active"])
    await db.execute("UPDATE users SET is_active = ? WHERE id = ?", (new_active, user_id))
    await db.commit()

    return {"id": user_id, "is_active": new_active}


@router.patch("/users/{user_id}/role")
async def update_user_role(
    user_id: str,
    data: RoleUpdateRequest,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("user:manage_roles", current_user, db)

    existing = await db.fetch_one("SELECT id FROM users WHERE id = ?", (user_id,))
    if not existing:
        raise HTTPException(status_code=404, detail="用户不存在")

    await db.execute("UPDATE users SET role = ? WHERE id = ?", (data.role, user_id))
    await db.commit()

    return {"id": user_id, "role": data.role}


# ========== API Keys 管理 ==========

@router.get("/api-keys")
async def list_all_api_keys(
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    user_id: str | None = Query(None),
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("key:list_all", current_user, db)

    conditions: list[str] = []
    params: list[Any] = []
    if user_id:
        conditions.append("ak.user_id = ?")
        params.append(user_id)
    where = " AND ".join(conditions) if conditions else "1=1"
    offset = (page - 1) * per_page

    count_row = await db.fetch_one(
        f"SELECT COUNT(*) as cnt FROM api_keys ak WHERE {where}", tuple(params)
    )
    total = count_row["cnt"] if count_row else 0

    rows = await db.fetch_all(
        f"""SELECT ak.id, SUBSTR(ak.key, 1, 12) || '********' as key_masked,
                   ak.user_id, ak.name, ak.scope, ak.is_active,
                   ak.last_used_at, ak.expires_at, ak.created_at,
                   u.name as user_name
            FROM api_keys ak LEFT JOIN users u ON u.id = ak.user_id
            WHERE {where}
            ORDER BY ak.created_at DESC LIMIT ? OFFSET ?""",
        tuple(params + [per_page, offset]),
    )
    return {"items": rows, "total": total, "page": page, "per_page": per_page}


@router.delete("/api-keys/{key_id}", status_code=status.HTTP_204_NO_CONTENT)
async def revoke_any_api_key(
    key_id: str,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("key:revoke_any", current_user, db)

    existing = await db.fetch_one("SELECT id FROM api_keys WHERE id = ?", (key_id,))
    if not existing:
        raise HTTPException(status_code=404, detail="API Key 不存在")

    await db.execute("UPDATE api_keys SET is_active = 0 WHERE id = ?", (key_id,))
    await db.commit()


# ========== 记忆审核 ==========

@router.get("/curation/memories")
async def list_curation_memories(
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    quality: str | None = Query(None),
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("curation:batch_verify", current_user, db)

    conditions: list[str] = ["m.team_id = ?"]
    params: list[Any] = [current_user.team_id]
    if quality:
        conditions.append("m.quality = ?")
        params.append(quality)
    else:
        conditions.append("m.quality = 'community'")
    where = " AND ".join(conditions)
    offset = (page - 1) * per_page

    count_row = await db.fetch_one(
        f"SELECT COUNT(*) as cnt FROM memories m WHERE {where}", tuple(params)
    )
    total = count_row["cnt"] if count_row else 0

    rows = await db.fetch_all(
        f"""SELECT m.id, m.summary, m.scope, m.category, m.tags, m.quality,
                   m.quality_score, m.owner_id, m.team_id, m.project_id,
                   m.created_at, m.updated_at,
                   u.name as owner_name
            FROM memories m LEFT JOIN users u ON u.id = m.owner_id
            WHERE {where}
            ORDER BY m.created_at DESC LIMIT ? OFFSET ?""",
        tuple(params + [per_page, offset]),
    )
    return {"items": rows, "total": total, "page": page, "per_page": per_page}


@router.post("/curation/batch")
async def batch_curation(
    data: BatchCurationRequest,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    action_perm_map = {
        "verify": "curation:batch_verify",
        "archive": "curation:batch_archive",
        "pin": "curation:batch_verify",
        "stale": "curation:batch_archive",
    }
    perm = action_perm_map.get(data.action)
    if not perm:
        raise HTTPException(status_code=400, detail=f"无效的操作: {data.action}")

    await _require_perm(perm, current_user, db)

    action_quality_map = {
        "verify": 质量状态.VERIFIED,
        "archive": 质量状态.ARCHIVED,
        "pin": 质量状态.PINNED,
        "stale": 质量状态.STALE,
    }
    new_quality = action_quality_map[data.action]
    now = datetime.now(timezone.utc).isoformat()

    # 校验所有 memory_ids 属于当前用户团队
    if data.memory_ids:
        placeholders = ",".join("?" for _ in data.memory_ids)
        rows = await db.fetch_all(
            f"SELECT id, team_id FROM memories WHERE id IN ({placeholders})",
            tuple(data.memory_ids),
        )
        found_ids = {r["id"] for r in rows}
        for r in rows:
            if r["team_id"] != current_user.team_id:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"记忆 {r['id']} 不属于当前团队，批量操作已拒绝",
                )
        missing = set(data.memory_ids) - found_ids
        if missing:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"记忆未找到: {', '.join(missing)}",
            )

    updated = 0
    for mid in data.memory_ids:
        if data.action == "verify":
            await db.execute(
                "UPDATE memories SET quality = ?, verified_by = ?, verified_at = ?, updated_at = ? WHERE id = ?",
                (new_quality, current_user.id, now, now, mid),
            )
        else:
            await db.execute(
                "UPDATE memories SET quality = ?, updated_at = ? WHERE id = ?",
                (new_quality, now, mid),
            )
        updated += 1

    await db.commit()
    return {"updated": updated, "action": data.action, "quality": new_quality}


# ========== 系统配置 ==========

# 可编辑的安全配置参数
_EDITABLE_CONFIG_KEYS = {
    "search.semantic_weight", "search.keyword_weight",
    "search.candidate_multiplier", "search.score_normalization",
    "consolidation.enabled", "consolidation.scan_days",
    "consolidation.cluster_threshold", "consolidation.max_suggestions_per_scan",
    "mcp.tool_set", "mcp.max_results",
    "logging.level",
}


@router.get("/system/config")
async def get_system_config(
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("system:view_config", current_user, db)

    from team_memory_hub.config import get_config
    config = get_config()

    def _section_to_dict(section_name: str, section_obj) -> list[dict]:
        items = []
        for field_name in section_obj.__dataclass_fields__:
            full_key = f"{section_name}.{field_name}"
            value = getattr(section_obj, field_name)
            # 隐藏敏感值
            if "secret" in field_name.lower() or "password" in field_name.lower() or "api_key" in field_name.lower():
                display_value = "********"
            else:
                display_value = value
            items.append({
                "key": full_key,
                "value": display_value,
                "editable": full_key in _EDITABLE_CONFIG_KEYS,
                "type": type(value).__name__,
            })
        return items

    sections = {}
    for section_name in ["server", "auth", "database", "storage", "search",
                         "embedding", "consolidation", "mcp", "logging"]:
        section_obj = getattr(config, section_name, None)
        if section_obj:
            sections[section_name] = _section_to_dict(section_name, section_obj)

    return {"sections": sections}


@router.patch("/system/config")
async def update_system_config(
    data: ConfigUpdateRequest,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("system:update_config", current_user, db)

    from team_memory_hub.config import get_config
    config = get_config()

    updated = {}
    errors = {}
    for key, value in data.updates.items():
        if key not in _EDITABLE_CONFIG_KEYS:
            errors[key] = "该配置项为只读"
            continue

        section_name, field_name = key.split(".", 1)
        section_obj = getattr(config, section_name, None)
        if not section_obj or not hasattr(section_obj, field_name):
            errors[key] = "配置项不存在"
            continue

        current_value = getattr(section_obj, field_name)
        try:
            if isinstance(current_value, bool):
                str_val = str(value).lower().strip()
                if str_val in ("true", "1", "yes"):
                    coerced = True
                elif str_val in ("false", "0", "no"):
                    coerced = False
                else:
                    errors[key] = f"无效的布尔值: {value}"
                    continue
            elif isinstance(current_value, int):
                coerced = int(value)
            elif isinstance(current_value, float):
                coerced = float(value)
            else:
                coerced = str(value)
            setattr(section_obj, field_name, coerced)
            updated[key] = coerced
        except (ValueError, TypeError) as e:
            errors[key] = f"无效的值: {e}"

    return {"updated": updated, "errors": errors}


@router.get("/system/stats")
async def get_system_stats(
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("system:view_config", current_user, db)

    mem_count = await db.fetch_one("SELECT COUNT(*) as cnt FROM memories")
    user_count = await db.fetch_one("SELECT COUNT(*) as cnt FROM users")
    team_count = await db.fetch_one("SELECT COUNT(*) as cnt FROM teams")
    proj_count = await db.fetch_one("SELECT COUNT(*) as cnt FROM projects WHERE is_active = 1")
    key_count = await db.fetch_one("SELECT COUNT(*) as cnt FROM api_keys WHERE is_active = 1")

    quality_rows = await db.fetch_all(
        "SELECT quality, COUNT(*) as count FROM memories GROUP BY quality"
    )

    # 数据库文件大小
    from team_memory_hub.config import get_config
    config = get_config()
    db_size = 0
    if os.path.exists(config.database.path):
        db_size = os.path.getsize(config.database.path)

    return {
        "memories": mem_count["cnt"] if mem_count else 0,
        "users": user_count["cnt"] if user_count else 0,
        "teams": team_count["cnt"] if team_count else 0,
        "projects": proj_count["cnt"] if proj_count else 0,
        "api_keys": key_count["cnt"] if key_count else 0,
        "quality_distribution": {r["quality"]: r["count"] for r in quality_rows},
        "database_size_bytes": db_size,
    }


# ========== 权限覆盖管理 ==========

@router.get("/permissions/overrides")
async def list_permission_overrides(
    user_id: str | None = Query(None),
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("user:manage", current_user, db)

    conditions: list[str] = []
    params: list[Any] = []
    if user_id:
        conditions.append("po.user_id = ?")
        params.append(user_id)
    where = " AND ".join(conditions) if conditions else "1=1"

    rows = await db.fetch_all(
        f"""SELECT po.*, u.name as user_name, g.name as granted_by_name
            FROM permission_overrides po
            LEFT JOIN users u ON u.id = po.user_id
            LEFT JOIN users g ON g.id = po.granted_by
            WHERE {where}
            ORDER BY po.created_at DESC""",
        tuple(params),
    )
    return {"items": rows}


@router.post("/permissions/overrides", status_code=status.HTTP_201_CREATED)
async def create_permission_override(
    data: PermissionOverrideRequest,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("user:manage", current_user, db)

    override_id = str(uuid.uuid4())
    expires_at = data.expires_at.isoformat() if data.expires_at else None

    try:
        await db.execute(
            """INSERT INTO permission_overrides (id, user_id, permission, type, granted_by, reason, expires_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (override_id, data.user_id, data.permission, data.type, current_user.id, data.reason, expires_at),
        )
        await db.commit()
    except Exception:
        # UNIQUE 冲突：更新已有覆盖
        await db.execute(
            """UPDATE permission_overrides
               SET type = ?, granted_by = ?, reason = ?, expires_at = ?, created_at = CURRENT_TIMESTAMP
               WHERE user_id = ? AND permission = ?""",
            (data.type, current_user.id, data.reason, expires_at, data.user_id, data.permission),
        )
        await db.commit()

    return {"id": override_id, "user_id": data.user_id, "permission": data.permission, "type": data.type}


@router.delete("/permissions/overrides/{override_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_permission_override(
    override_id: str,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    await _require_perm("user:manage", current_user, db)

    existing = await db.fetch_one("SELECT id FROM permission_overrides WHERE id = ?", (override_id,))
    if not existing:
        raise HTTPException(status_code=404, detail="权限覆盖不存在")

    await db.execute("DELETE FROM permission_overrides WHERE id = ?", (override_id,))
    await db.commit()
