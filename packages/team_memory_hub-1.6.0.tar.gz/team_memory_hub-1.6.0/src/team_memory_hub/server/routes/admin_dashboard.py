"""管理后台 Dashboard 路由：Jinja2 + HTMX 管理页面。"""

from __future__ import annotations

import json
import secrets
import string
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Cookie, Depends, Form, Query, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates

from team_memory_hub.core.rbac import (
    PERMISSIONS,
    check_permission,
    check_permission_with_overrides,
    has_minimum_role,
)
from team_memory_hub.server.dependencies import get_db
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import UserRole

router = APIRouter()

_DASHBOARD_DIR = Path(__file__).resolve().parent.parent.parent / "dashboard"
_TEMPLATE_DIR = _DASHBOARD_DIR / "templates"
templates = Jinja2Templates(directory=str(_TEMPLATE_DIR))


def _gen_id(prefix: str) -> str:
    """生成带前缀的 ID。"""
    return f"{prefix}_{''.join(secrets.choice(string.ascii_lowercase + string.digits) for _ in range(8))}"


async def _get_dashboard_user(request: Request, db: Database) -> dict | None:
    """从 session cookie 获取当前用户信息。"""
    token = request.cookies.get("tmh_session")
    if not token:
        return None

    try:
        from jose import jwt as jose_jwt
        from team_memory_hub.config import get_config
        config = get_config()
        payload = jose_jwt.decode(token, config.auth.jwt_secret, algorithms=[config.auth.jwt_algorithm])
        user_id = payload.get("sub")
        if not user_id:
            return None
        row = await db.fetch_one("SELECT * FROM users WHERE id = ? AND is_active = 1", (user_id,))
        if row:
            return dict(row)
    except Exception:
        pass

    return None


def _can_factory(user_role: str):
    """创建模板用的 can() 权限检查函数。"""
    def can(permission: str) -> bool:
        return check_permission(user_role, permission)
    return can


def _admin_context(request: Request, user: dict, active_page: str, **extra) -> dict:
    """构建管理页面模板上下文。"""
    ctx = {
        "request": request,
        "user": user,
        "active_page": active_page,
        "can": _can_factory(user.get("role", "viewer")),
        "is_admin": has_minimum_role(user.get("role", "viewer"), UserRole.MAINTAINER),
    }
    ctx.update(extra)
    return ctx


# ========== 权限中间件 ==========

async def _require_admin_access(request: Request, db: Database) -> dict | RedirectResponse:
    """管理页面统一权限检查：至少 maintainer。返回用户 dict 或 RedirectResponse。"""
    user = await _get_dashboard_user(request, db)
    if not user:
        return RedirectResponse(url="/dashboard/login", status_code=303)
    if not has_minimum_role(user.get("role", "viewer"), UserRole.MAINTAINER):
        return RedirectResponse(url="/dashboard/", status_code=303)
    return user


# ========== Teams 管理页面 ==========

@router.get("/teams", response_class=HTMLResponse)
async def teams_page(
    request: Request,
    action: str | None = Query(None),
    id: str | None = Query(None),
    db: Database = Depends(get_db),
):
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result
    user = result

    # 表单操作
    if action == "create_form":
        return templates.TemplateResponse("admin/partials/entity_form.html", {
            "request": request,
            "form_title": "新建团队",
            "form_action": "/dashboard/admin/teams/form",
            "edit_mode": False,
            "fields": [
                {"label": "团队名称", "name": "name", "type": "text", "required": True, "placeholder": "输入团队名称"},
            ],
        })
    elif action == "edit_form" and id:
        team = await db.fetch_one("SELECT * FROM teams WHERE id = ?", (id,))
        if not team:
            return HTMLResponse("团队不存在", status_code=404)
        return templates.TemplateResponse("admin/partials/entity_form.html", {
            "request": request,
            "form_title": f"编辑团队: {team['name']}",
            "form_action": f"/dashboard/admin/teams/{id}/form",
            "edit_mode": True,
            "fields": [
                {"label": "团队名称", "name": "name", "type": "text", "required": True, "value": team["name"]},
            ],
        })

    rows = await db.fetch_all(
        """SELECT t.*,
                  (SELECT COUNT(*) FROM users u WHERE u.team_id = t.id AND u.is_active = 1) as member_count,
                  (SELECT COUNT(*) FROM projects p WHERE p.team_id = t.id AND p.is_active = 1) as project_count
           FROM teams t ORDER BY t.created_at DESC"""
    )
    return templates.TemplateResponse("admin/teams.html", _admin_context(
        request, user, "teams", teams=rows,
    ))


@router.post("/teams/form", response_class=HTMLResponse)
async def teams_create(
    request: Request,
    name: str = Form(...),
    db: Database = Depends(get_db),
):
    """创建团队（Dashboard 表单）。"""
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result

    team_id = _gen_id("team")
    try:
        await db.execute("INSERT INTO teams (id, name) VALUES (?, ?)", (team_id, name))
        await db.commit()
    except Exception:
        return HTMLResponse("团队名称已存在", status_code=400)

    return HTMLResponse(status_code=200, headers={"HX-Redirect": "/dashboard/admin/teams"})


@router.put("/teams/{team_id}/form", response_class=HTMLResponse)
async def teams_update(
    request: Request,
    team_id: str,
    name: str = Form(...),
    db: Database = Depends(get_db),
):
    """更新团队（Dashboard 表单）。"""
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result

    existing = await db.fetch_one("SELECT id FROM teams WHERE id = ?", (team_id,))
    if not existing:
        return HTMLResponse("团队不存在", status_code=404)

    await db.execute("UPDATE teams SET name = ? WHERE id = ?", (name, team_id))
    await db.commit()

    return HTMLResponse(status_code=200, headers={"HX-Redirect": "/dashboard/admin/teams"})


@router.delete("/teams/{team_id}/action", response_class=HTMLResponse)
async def teams_delete(
    request: Request,
    team_id: str,
    db: Database = Depends(get_db),
):
    """删除团队（Dashboard 操作）。"""
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result

    # 安全检查
    user_count = await db.fetch_one(
        "SELECT COUNT(*) as cnt FROM users WHERE team_id = ? AND is_active = 1", (team_id,)
    )
    if user_count and user_count["cnt"] > 0:
        return HTMLResponse("团队下有活跃用户，无法删除", status_code=400)

    proj_count = await db.fetch_one(
        "SELECT COUNT(*) as cnt FROM projects WHERE team_id = ? AND is_active = 1", (team_id,)
    )
    if proj_count and proj_count["cnt"] > 0:
        return HTMLResponse("团队下有活跃项目，无法删除", status_code=400)

    await db.execute("DELETE FROM teams WHERE id = ?", (team_id,))
    await db.commit()

    return HTMLResponse(status_code=200, headers={"HX-Redirect": "/dashboard/admin/teams"})


# ========== Projects 管理页面 ==========

@router.get("/projects", response_class=HTMLResponse)
async def projects_page(
    request: Request,
    action: str | None = Query(None),
    id: str | None = Query(None),
    team_id: str | None = Query(None),
    db: Database = Depends(get_db),
):
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result
    user = result

    teams = await db.fetch_all("SELECT id, name FROM teams ORDER BY name")
    team_options = [{"value": t["id"], "label": t["name"]} for t in teams]

    # 表单操作
    if action == "create_form":
        return templates.TemplateResponse("admin/partials/entity_form.html", {
            "request": request,
            "form_title": "新建项目",
            "form_action": "/dashboard/admin/projects/form",
            "edit_mode": False,
            "fields": [
                {"label": "项目名称", "name": "name", "type": "text", "required": True, "placeholder": "输入项目名称"},
                {"label": "所属团队", "name": "team_id", "type": "select", "required": True,
                 "options": [{"value": "", "label": "-- 选择团队 --"}] + team_options, "value": ""},
                {"label": "描述", "name": "description", "type": "textarea", "required": False},
                {"label": "类型", "name": "project_type", "type": "text", "required": False, "placeholder": "如: web, mobile, library"},
            ],
        })
    elif action == "edit_form" and id:
        proj = await db.fetch_one("SELECT * FROM projects WHERE id = ?", (id,))
        if not proj:
            return HTMLResponse("项目不存在", status_code=404)
        return templates.TemplateResponse("admin/partials/entity_form.html", {
            "request": request,
            "form_title": f"编辑项目: {proj['name']}",
            "form_action": f"/dashboard/admin/projects/{id}/form",
            "edit_mode": True,
            "fields": [
                {"label": "项目名称", "name": "name", "type": "text", "required": True, "value": proj["name"]},
                {"label": "所属团队", "name": "team_id", "type": "select", "required": True,
                 "options": team_options, "value": proj["team_id"]},
                {"label": "描述", "name": "description", "type": "textarea", "required": False, "value": proj.get("description", "")},
                {"label": "类型", "name": "project_type", "type": "text", "required": False, "value": proj.get("project_type", "")},
            ],
        })

    conditions = ["p.is_active = 1"]
    params: list[Any] = []
    if team_id:
        conditions.append("p.team_id = ?")
        params.append(team_id)
    where = " AND ".join(conditions)

    rows = await db.fetch_all(
        f"""SELECT p.*, t.name as team_name
            FROM projects p LEFT JOIN teams t ON t.id = p.team_id
            WHERE {where} ORDER BY p.created_at DESC""",
        tuple(params),
    )
    return templates.TemplateResponse("admin/projects.html", _admin_context(
        request, user, "projects", projects=rows, teams=teams, filter_team_id=team_id,
    ))


@router.post("/projects/form", response_class=HTMLResponse)
async def projects_create(
    request: Request,
    name: str = Form(...),
    team_id: str = Form(...),
    description: str = Form(""),
    project_type: str = Form(""),
    db: Database = Depends(get_db),
):
    """创建项目（Dashboard 表单）。"""
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result

    team = await db.fetch_one("SELECT id FROM teams WHERE id = ?", (team_id,))
    if not team:
        return HTMLResponse("指定的团队不存在", status_code=400)

    project_id = _gen_id("proj")
    try:
        await db.execute(
            "INSERT INTO projects (id, name, team_id, description, project_type) VALUES (?, ?, ?, ?, ?)",
            (project_id, name, team_id, description or None, project_type or None),
        )
        await db.commit()
    except Exception:
        return HTMLResponse("创建项目失败", status_code=400)

    return HTMLResponse(status_code=200, headers={"HX-Redirect": "/dashboard/admin/projects"})


@router.put("/projects/{project_id}/form", response_class=HTMLResponse)
async def projects_update(
    request: Request,
    project_id: str,
    name: str = Form(...),
    team_id: str = Form(...),
    description: str = Form(""),
    project_type: str = Form(""),
    db: Database = Depends(get_db),
):
    """更新项目（Dashboard 表单）。"""
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result

    existing = await db.fetch_one("SELECT id FROM projects WHERE id = ?", (project_id,))
    if not existing:
        return HTMLResponse("项目不存在", status_code=404)

    await db.execute(
        "UPDATE projects SET name = ?, team_id = ?, description = ?, project_type = ? WHERE id = ?",
        (name, team_id, description or None, project_type or None, project_id),
    )
    await db.commit()

    return HTMLResponse(status_code=200, headers={"HX-Redirect": "/dashboard/admin/projects"})


@router.delete("/projects/{project_id}/action", response_class=HTMLResponse)
async def projects_delete(
    request: Request,
    project_id: str,
    db: Database = Depends(get_db),
):
    """归档项目（Dashboard 操作）。"""
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result

    existing = await db.fetch_one("SELECT id FROM projects WHERE id = ?", (project_id,))
    if not existing:
        return HTMLResponse("项目不存在", status_code=404)

    await db.execute("UPDATE projects SET is_active = 0 WHERE id = ?", (project_id,))
    await db.commit()

    return HTMLResponse(status_code=200, headers={"HX-Redirect": "/dashboard/admin/projects"})


# ========== Users 管理页面 ==========

@router.get("/users", response_class=HTMLResponse)
async def users_page(
    request: Request,
    action: str | None = Query(None),
    id: str | None = Query(None),
    role: str | None = Query(None),
    db: Database = Depends(get_db),
):
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result
    user = result

    teams = await db.fetch_all("SELECT id, name FROM teams ORDER BY name")
    team_options = [{"value": t["id"], "label": t["name"]} for t in teams]
    role_options = [
        {"value": "admin", "label": "管理员"},
        {"value": "maintainer", "label": "维护者"},
        {"value": "member", "label": "成员"},
        {"value": "viewer", "label": "观察者"},
    ]

    # 表单操作
    if action == "create_form":
        return templates.TemplateResponse("admin/partials/entity_form.html", {
            "request": request,
            "form_title": "新建用户",
            "form_action": "/dashboard/admin/users/form",
            "edit_mode": False,
            "fields": [
                {"label": "用户名", "name": "name", "type": "text", "required": True, "placeholder": "输入用户名"},
                {"label": "邮箱", "name": "email", "type": "email", "required": True, "placeholder": "输入邮箱"},
                {"label": "密码", "name": "password", "type": "password", "required": True, "placeholder": "设置密码"},
                {"label": "角色", "name": "role", "type": "select", "required": True,
                 "options": role_options, "value": "member"},
                {"label": "所属团队", "name": "team_id", "type": "select", "required": True,
                 "options": [{"value": "", "label": "-- 选择团队 --"}] + team_options, "value": ""},
            ],
        })
    elif action == "edit_form" and id:
        target_user = await db.fetch_one("SELECT * FROM users WHERE id = ?", (id,))
        if not target_user:
            return HTMLResponse("用户不存在", status_code=404)
        return templates.TemplateResponse("admin/partials/entity_form.html", {
            "request": request,
            "form_title": f"编辑用户: {target_user['name']}",
            "form_action": f"/dashboard/admin/users/{id}/form",
            "edit_mode": True,
            "fields": [
                {"label": "用户名", "name": "name", "type": "text", "required": True, "value": target_user["name"]},
                {"label": "邮箱", "name": "email", "type": "email", "required": True, "value": target_user["email"]},
                {"label": "所属团队", "name": "team_id", "type": "select", "required": True,
                 "options": team_options, "value": target_user["team_id"]},
            ],
        })

    conditions: list[str] = []
    params: list[Any] = []
    if role:
        conditions.append("u.role = ?")
        params.append(role)
    where = " AND ".join(conditions) if conditions else "1=1"

    rows = await db.fetch_all(
        f"""SELECT u.id, u.name, u.email, u.role, u.team_id, u.is_active, u.created_at,
                   t.name as team_name
            FROM users u LEFT JOIN teams t ON t.id = u.team_id
            WHERE {where} ORDER BY u.created_at DESC""",
        tuple(params),
    )
    return templates.TemplateResponse("admin/users.html", _admin_context(
        request, user, "users", users=rows, teams=teams, filter_role=role,
    ))


@router.post("/users/form", response_class=HTMLResponse)
async def users_create(
    request: Request,
    name: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    role: str = Form("member"),
    team_id: str = Form(...),
    db: Database = Depends(get_db),
):
    """创建用户（Dashboard 表单）。"""
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result

    # 验证团队
    team = await db.fetch_one("SELECT id FROM teams WHERE id = ?", (team_id,))
    if not team:
        return HTMLResponse("指定的团队不存在", status_code=400)

    # 检查邮箱唯一
    existing = await db.fetch_one("SELECT id FROM users WHERE email = ?", (email,))
    if existing:
        return HTMLResponse("邮箱已被使用", status_code=400)

    user_id = _gen_id("usr")
    from team_memory_hub.server.routes.auth import hash_password
    password_hash = hash_password(password)

    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id, password_hash) VALUES (?, ?, ?, ?, ?, ?)",
        (user_id, name, email, role, team_id, password_hash),
    )
    await db.commit()

    return HTMLResponse(status_code=200, headers={"HX-Redirect": "/dashboard/admin/users"})


@router.post("/users/{user_id}/toggle-active", response_class=HTMLResponse)
async def users_toggle_active(
    request: Request,
    user_id: str,
    db: Database = Depends(get_db),
):
    """切换用户启用/禁用（Dashboard 操作）。"""
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result

    row = await db.fetch_one("SELECT id, is_active FROM users WHERE id = ?", (user_id,))
    if not row:
        return HTMLResponse("用户不存在", status_code=404)

    new_active = not bool(row["is_active"])
    await db.execute("UPDATE users SET is_active = ? WHERE id = ?", (new_active, user_id))
    await db.commit()

    return HTMLResponse(status_code=200, headers={"HX-Redirect": "/dashboard/admin/users"})


@router.post("/users/{user_id}/change-role", response_class=HTMLResponse)
async def users_change_role(
    request: Request,
    user_id: str,
    role: str = Form(...),
    db: Database = Depends(get_db),
):
    """修改用户角色（Dashboard 操作）。"""
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result

    valid_roles = {"admin", "maintainer", "member", "viewer"}
    if role not in valid_roles:
        return HTMLResponse("无效的角色", status_code=400)

    existing = await db.fetch_one("SELECT id FROM users WHERE id = ?", (user_id,))
    if not existing:
        return HTMLResponse("用户不存在", status_code=404)

    await db.execute("UPDATE users SET role = ? WHERE id = ?", (role, user_id))
    await db.commit()

    return HTMLResponse(status_code=200, headers={"HX-Redirect": "/dashboard/admin/users"})


@router.put("/users/{user_id}/form", response_class=HTMLResponse)
async def users_update(
    request: Request,
    user_id: str,
    name: str = Form(...),
    email: str = Form(...),
    team_id: str = Form(...),
    db: Database = Depends(get_db),
):
    """更新用户（Dashboard 表单）。"""
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result

    existing = await db.fetch_one("SELECT id FROM users WHERE id = ?", (user_id,))
    if not existing:
        return HTMLResponse("用户不存在", status_code=404)

    await db.execute(
        "UPDATE users SET name = ?, email = ?, team_id = ? WHERE id = ?",
        (name, email, team_id, user_id),
    )
    await db.commit()

    return HTMLResponse(status_code=200, headers={"HX-Redirect": "/dashboard/admin/users"})


# ========== API Keys 管理页面 ==========

@router.get("/api-keys", response_class=HTMLResponse)
async def api_keys_page(
    request: Request,
    user_filter: str | None = Query(None, alias="user_id"),
    db: Database = Depends(get_db),
):
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result
    user = result

    conditions: list[str] = []
    params: list[Any] = []
    if user_filter:
        conditions.append("ak.user_id = ?")
        params.append(user_filter)
    where = " AND ".join(conditions) if conditions else "1=1"

    rows = await db.fetch_all(
        f"""SELECT ak.id, SUBSTR(ak.key, 1, 12) || '********' as key_masked,
                   ak.user_id, ak.name, ak.scope, ak.is_active,
                   ak.last_used_at, ak.expires_at, ak.created_at,
                   u.name as user_name
            FROM api_keys ak LEFT JOIN users u ON u.id = ak.user_id
            WHERE {where} ORDER BY ak.created_at DESC""",
        tuple(params),
    )
    users = await db.fetch_all("SELECT id, name FROM users WHERE is_active = 1 ORDER BY name")
    return templates.TemplateResponse("admin/api_keys.html", _admin_context(
        request, user, "api_keys", api_keys=rows, users=users, filter_user_id=user_filter,
    ))


@router.delete("/api-keys/{key_id}/revoke", response_class=HTMLResponse)
async def api_keys_revoke(
    request: Request,
    key_id: str,
    db: Database = Depends(get_db),
):
    """吊销 API Key（Dashboard 操作）。"""
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result

    existing = await db.fetch_one("SELECT id FROM api_keys WHERE id = ?", (key_id,))
    if not existing:
        return HTMLResponse("API Key 不存在", status_code=404)

    await db.execute("UPDATE api_keys SET is_active = 0 WHERE id = ?", (key_id,))
    await db.commit()

    return HTMLResponse(status_code=200, headers={"HX-Redirect": "/dashboard/admin/api-keys"})


# ========== 记忆审核页面 ==========

@router.post("/curation/batch")
async def curation_batch_action(
    request: Request,
    db: Database = Depends(get_db),
):
    """批量审核操作（Dashboard）。"""
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result

    body = await request.json()
    memory_ids = body.get("memory_ids", [])
    action = body.get("action", "")

    action_quality_map = {
        "verify": "verified",
        "archive": "archived",
        "pin": "pinned",
        "stale": "stale",
    }
    new_quality = action_quality_map.get(action)
    if not new_quality:
        return HTMLResponse("无效的操作", status_code=400)

    from datetime import datetime, timezone
    user = result
    now = datetime.now(timezone.utc).isoformat()

    for mid in memory_ids:
        if action == "verify":
            await db.execute(
                "UPDATE memories SET quality = ?, verified_by = ?, verified_at = ?, updated_at = ? WHERE id = ?",
                (new_quality, user.get("id"), now, now, mid),
            )
        else:
            await db.execute(
                "UPDATE memories SET quality = ?, updated_at = ? WHERE id = ?",
                (new_quality, now, mid),
            )
    await db.commit()

    return {"updated": len(memory_ids), "action": action}


@router.get("/curation", response_class=HTMLResponse)
async def curation_page(
    request: Request,
    quality: str | None = Query(None),
    db: Database = Depends(get_db),
):
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result
    user = result

    conditions: list[str] = []
    params: list[Any] = []
    if quality:
        conditions.append("m.quality = ?")
        params.append(quality)
    else:
        conditions.append("m.quality = 'community'")
    where = " AND ".join(conditions)

    rows = await db.fetch_all(
        f"""SELECT m.id, m.summary, m.scope, m.category, m.tags, m.quality,
                   m.quality_score, m.owner_id, m.team_id, m.created_at,
                   u.name as owner_name
            FROM memories m LEFT JOIN users u ON u.id = m.owner_id
            WHERE {where} ORDER BY m.created_at DESC LIMIT 100""",
        tuple(params),
    )
    # 解析 tags JSON
    memories = []
    for r in rows:
        m = dict(r)
        if isinstance(m.get("tags"), str):
            try:
                m["tags"] = json.loads(m["tags"])
            except json.JSONDecodeError:
                m["tags"] = []
        memories.append(m)

    stats = await db.fetch_all(
        "SELECT quality, COUNT(*) as cnt FROM memories GROUP BY quality"
    )
    quality_stats = {s["quality"]: s["cnt"] for s in stats}

    return templates.TemplateResponse("admin/curation.html", _admin_context(
        request, user, "curation", memories=memories,
        quality_stats=quality_stats, filter_quality=quality or "community",
    ))


# ========== 系统配置页面 ==========

# 可编辑的安全配置参数
_EDITABLE_CONFIG_KEYS = {
    "search.semantic_weight", "search.keyword_weight",
    "search.candidate_multiplier", "search.score_normalization",
    "consolidation.enabled", "consolidation.scan_days",
    "consolidation.cluster_threshold", "consolidation.max_suggestions_per_scan",
    "mcp.tool_set", "mcp.max_results",
    "logging.level",
}


@router.post("/system/update-config")
async def system_update_config(
    request: Request,
    db: Database = Depends(get_db),
):
    """更新系统配置（Dashboard）。"""
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result

    body = await request.json()
    updates_input = body.get("updates", {})

    from team_memory_hub.config import get_config
    config = get_config()

    updated = {}
    errors = {}
    for key, value in updates_input.items():
        if key not in _EDITABLE_CONFIG_KEYS:
            errors[key] = "该配置项为只读"
            continue

        section_name, field_name = key.split(".", 1)
        section_obj = getattr(config, section_name, None)
        if not section_obj or not hasattr(section_obj, field_name):
            errors[key] = "配置项不存在"
            continue

        field_info = section_obj.__dataclass_fields__[field_name]
        try:
            if field_info.type is bool:
                coerced = bool(value)
            elif field_info.type is int:
                coerced = int(value)
            elif field_info.type is float:
                coerced = float(value)
            else:
                coerced = str(value)
            setattr(section_obj, field_name, coerced)
            updated[key] = coerced
        except (ValueError, TypeError) as e:
            errors[key] = f"无效的值: {e}"

    return {"updated": updated, "errors": errors}


@router.get("/system", response_class=HTMLResponse)
async def system_page(request: Request, db: Database = Depends(get_db)):
    result = await _require_admin_access(request, db)
    if isinstance(result, RedirectResponse):
        return result
    user = result
    if not check_permission(user.get("role", "viewer"), "system:view_config"):
        return RedirectResponse(url="/dashboard/admin/teams", status_code=303)

    from team_memory_hub.config import get_config
    import os
    config = get_config()

    # 系统统计
    mem_count = await db.fetch_one("SELECT COUNT(*) as cnt FROM memories")
    user_count = await db.fetch_one("SELECT COUNT(*) as cnt FROM users")
    team_count = await db.fetch_one("SELECT COUNT(*) as cnt FROM teams")
    proj_count = await db.fetch_one("SELECT COUNT(*) as cnt FROM projects WHERE is_active = 1")

    db_size = 0
    if os.path.exists(config.database.path):
        db_size = os.path.getsize(config.database.path)

    stats = {
        "memories": mem_count["cnt"] if mem_count else 0,
        "users": user_count["cnt"] if user_count else 0,
        "teams": team_count["cnt"] if team_count else 0,
        "projects": proj_count["cnt"] if proj_count else 0,
        "db_size_mb": round(db_size / 1024 / 1024, 2),
    }

    # 配置参数
    editable_keys = {
        "search.semantic_weight", "search.keyword_weight",
        "search.candidate_multiplier", "search.score_normalization",
        "consolidation.enabled", "consolidation.scan_days",
        "consolidation.cluster_threshold", "consolidation.max_suggestions_per_scan",
        "mcp.tool_set", "mcp.max_results",
        "logging.level",
    }

    sections = {}
    for section_name in ["server", "auth", "database", "storage", "search",
                         "embedding", "consolidation", "mcp", "logging"]:
        section_obj = getattr(config, section_name, None)
        if not section_obj:
            continue
        items = []
        for field_name in section_obj.__dataclass_fields__:
            full_key = f"{section_name}.{field_name}"
            value = getattr(section_obj, field_name)
            if "secret" in field_name.lower() or "password" in field_name.lower() or "api_key" in field_name.lower():
                display = "********"
            else:
                display = value
            items.append({
                "key": full_key,
                "field": field_name,
                "value": display,
                "editable": full_key in editable_keys,
            })
        sections[section_name] = items

    return templates.TemplateResponse("admin/system.html", _admin_context(
        request, user, "system", stats=stats, config_sections=sections,
    ))
