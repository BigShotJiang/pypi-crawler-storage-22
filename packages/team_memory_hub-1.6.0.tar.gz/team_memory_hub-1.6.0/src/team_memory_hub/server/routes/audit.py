"""审计日志 API 路由。"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query

from team_memory_hub.core.audit import AuditLogger
from team_memory_hub.server.dependencies import get_db, require_role
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import User, UserRole

router = APIRouter()


@router.get("")
async def list_audit_logs(
    user_id: str | None = Query(None),
    action: str | None = Query(None),
    target_type: str | None = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    current_user: User = Depends(require_role(UserRole.ADMIN)),
    db: Database = Depends(get_db),
):
    """列出审计日志条目（仅限管理员）。"""
    audit = AuditLogger(db)
    rows, total = await audit.query(
        user_id=user_id,
        action=action,
        target_type=target_type,
        page=page,
        page_size=page_size,
    )
    return {"items": rows, "total": total, "page": page, "page_size": page_size}
