"""认证路由：JWT 令牌管理。"""

from __future__ import annotations

import secrets
import string
from datetime import datetime, timedelta
from typing import Any

import bcrypt as _bcrypt
from fastapi import APIRouter, Depends, HTTPException, status
from jose import JWTError, jwt

from team_memory_hub.config import get_config
from team_memory_hub.server.dependencies import get_current_user, get_db
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import (
    RefreshRequest,
    TokenRequest,
    TokenResponse,
    User,
    UserCreate,
    UserRole,
)

router = APIRouter()


def hash_password(password: str) -> str:
    """使用 bcrypt 对密码进行哈希处理。"""
    return _bcrypt.hashpw(password.encode("utf-8"), _bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    """验证密码是否与哈希匹配。"""
    try:
        return _bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False


def create_access_token(data: dict[str, Any], expires_delta: timedelta | None = None) -> str:
    """创建 JWT 访问令牌。"""
    config = get_config()
    to_encode = data.copy()
    expire = datetime.utcnow() + (
        expires_delta or timedelta(minutes=config.auth.access_token_expire_minutes)
    )
    to_encode.update({"exp": expire, "type": "access"})
    return jwt.encode(to_encode, config.auth.jwt_secret, algorithm=config.auth.jwt_algorithm)


def create_refresh_token(data: dict[str, Any], expires_delta: timedelta | None = None) -> str:
    """创建 JWT 刷新令牌，支持 30 天滑动窗口。"""
    config = get_config()
    to_encode = data.copy()
    expire = datetime.utcnow() + (
        expires_delta or timedelta(days=config.auth.refresh_token_expire_days)
    )
    to_encode.update({"exp": expire, "type": "refresh"})
    return jwt.encode(to_encode, config.auth.jwt_secret, algorithm=config.auth.jwt_algorithm)


def decode_token(token: str) -> dict[str, Any]:
    """解码并验证 JWT 令牌。"""
    config = get_config()
    try:
        payload = jwt.decode(
            token, config.auth.jwt_secret, algorithms=[config.auth.jwt_algorithm]
        )
        return payload
    except JWTError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        ) from e


@router.post("/token", response_model=TokenResponse)
async def login(request: TokenRequest, db: Database = Depends(get_db)):
    """验证用户身份并返回访问令牌和刷新令牌。"""
    row = await db.fetch_one(
        "SELECT * FROM users WHERE email = ? AND is_active = 1",
        (request.email,),
    )
    if not row or not row.get("password_hash"):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="凭证无效",
        )

    if not verify_password(request.password, row["password_hash"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="凭证无效",
        )

    config = get_config()
    token_data = {
        "sub": row["id"],
        "email": row["email"],
        "role": row["role"],
        "team_id": row["team_id"],
    }

    access_token = create_access_token(token_data)
    refresh_token = create_refresh_token(token_data)

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=config.auth.access_token_expire_minutes * 60,
    )


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(request: RefreshRequest, db: Database = Depends(get_db)):
    """使用有效的刷新令牌刷新访问令牌（滑动窗口）。"""
    payload = decode_token(request.refresh_token)

    if payload.get("type") != "refresh":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="令牌类型无效",
        )

    # 验证用户仍然存在且处于活跃状态
    user_id = payload.get("sub")
    row = await db.fetch_one(
        "SELECT * FROM users WHERE id = ? AND is_active = 1",
        (user_id,),
    )
    if not row:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="用户未找到或不活跃",
        )

    config = get_config()
    token_data = {
        "sub": row["id"],
        "email": row["email"],
        "role": row["role"],
        "team_id": row["team_id"],
    }

    # 发送新令牌（滑动窗口：刷新令牌被更新）
    access_token = create_access_token(token_data)
    new_refresh_token = create_refresh_token(token_data)

    return TokenResponse(
        access_token=access_token,
        refresh_token=new_refresh_token,
        expires_in=config.auth.access_token_expire_minutes * 60,
    )


@router.get("/me", response_model=User)
async def get_me(current_user: User = Depends(get_current_user)):
    """获取当前已验证用户的个人资料。"""
    return current_user


@router.post("/register", response_model=User, status_code=status.HTTP_201_CREATED)
async def register(data: UserCreate, db: Database = Depends(get_db)):
    """注册新用户。"""
    # 检查邮箱是否已存在
    existing = await db.fetch_one(
        "SELECT id FROM users WHERE email = ?", (data.email,)
    )
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="邮箱已注册",
        )

    # 验证团队是否存在
    team = await db.fetch_one(
        "SELECT id FROM teams WHERE id = ?", (data.team_id,)
    )
    if not team:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="团队未找到",
        )

    # 公开注册强制 role=member，防止权限提升
    forced_role = UserRole.MEMBER

    user_id = f"usr_{''.join(secrets.choice(string.ascii_lowercase + string.digits) for _ in range(8))}"
    password_hash = hash_password(data.password)

    await db.execute(
        """INSERT INTO users (id, name, email, role, team_id, password_hash)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (user_id, data.name, data.email, forced_role, data.team_id, password_hash),
    )
    await db.commit()

    return User(
        id=user_id,
        name=data.name,
        email=data.email,
        role=forced_role,
        team_id=data.team_id,
    )
