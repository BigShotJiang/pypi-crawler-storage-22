"""聊天 API 路由：摄入、列出会话、获取会话详情。"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel

from team_memory_hub.core.chat_ingest import ChatIngestor
from team_memory_hub.core.memory_extractor import MemoryExtractor
from team_memory_hub.server.dependencies import api_key_auth, get_current_user, get_db
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import User

router = APIRouter()


class IngestRequest(BaseModel):
    tool_name: str
    raw_data: dict
    project_id: str | None = None


class IngestResponse(BaseModel):
    session_id: str | None
    turn_count: int
    status: str
    file_path: str | None = None


class SessionListResponse(BaseModel):
    items: list[dict]
    total: int
    page: int = 1
    page_size: int = 20


def _get_ingestor(request: Request, db: Database) -> ChatIngestor:
    config = request.app.state.config
    return ChatIngestor(db, config.storage.chats_dir)


@router.post("/ingest", response_model=IngestResponse)
async def ingest_chat(
    data: IngestRequest,
    request: Request,
    current_user: User = Depends(api_key_auth("ingest_only")),
    db: Database = Depends(get_db),
):
    """从 AI 工具摄入聊天会话。

    Accepts raw chat data, converts via the appropriate adapter,
    and stores the session.
    """
    ingestor = _get_ingestor(request, db)

    try:
        result = await ingestor.ingest(
            tool_name=data.tool_name,
            raw_data=data.raw_data,
            user_id=current_user.id,
            project_id=data.project_id,
        )
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

    return IngestResponse(
        session_id=result.get("session_id"),
        turn_count=result.get("turn_count", 0),
        status=result.get("status", "error"),
        file_path=result.get("file_path"),
    )


@router.get("", response_model=SessionListResponse)
async def list_sessions(
    request: Request,
    tool: str | None = Query(None, description="按...筛选 tool name"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """List chat sessions for the current user."""
    ingestor = _get_ingestor(request, db)

    sessions, total = await ingestor.list_sessions(
        user_id=current_user.id,
        tool=tool,
        page=page,
        page_size=page_size,
    )

    return SessionListResponse(
        items=sessions,
        total=total,
        page=page,
        page_size=page_size,
    )


@router.get("/{session_id}")
async def get_session(
    session_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """Get a chat session by ID."""
    ingestor = _get_ingestor(request, db)
    session = await ingestor.get_session(session_id)

    if session is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Session not found")

    # Check ownership
    if session["user_id"] != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="访问被拒绝")

    return session


@router.get("/{session_id}/messages")
async def get_session_messages(
    session_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """Get the full messages of a chat session."""
    ingestor = _get_ingestor(request, db)
    session = await ingestor.get_session(session_id)

    if session is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Session not found")

    if session["user_id"] != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="访问被拒绝")

    # Read the chat file
    chat_data = ingestor.read_chat_file(session["file_path"])
    if chat_data is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Chat file not found")

    return chat_data


@router.post("/{session_id}/extract")
async def extract_memories(
    session_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """Extract memories from a chat session."""
    ingestor = _get_ingestor(request, db)
    session = await ingestor.get_session(session_id)

    if session is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Session not found")

    if session["user_id"] != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="访问被拒绝")

    # Read chat data
    chat_data = ingestor.read_chat_file(session["file_path"])
    if chat_data is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Chat file not found")

    # Convert messages back to ChatMessage objects
    from team_memory_hub.chat_adapters.base import ChatMessage
    from datetime import datetime

    messages = []
    for msg in chat_data.get("messages", []):
        ts = None
        if msg.get("timestamp"):
            try:
                ts = datetime.fromisoformat(msg["timestamp"])
            except (ValueError, TypeError):
                pass
        messages.append(ChatMessage(
            role=msg.get("role", "user"),
            content=msg.get("content", ""),
            timestamp=ts,
            metadata=msg.get("metadata", {}),
        ))

    # Extract
    extractor = MemoryExtractor()
    extracted = await extractor.extract(messages)

    # Update session record
    await db.execute(
        "UPDATE chat_sessions SET memories_extracted = ? WHERE id = ?",
        (len(extracted), session_id),
    )
    await db.commit()

    return {
        "session_id": session_id,
        "extracted_count": len(extracted),
        "memories": [
            {
                "content": m.content[:500],
                "summary": m.summary,
                "category": m.category,
                "tags": m.tags,
                "confidence": m.confidence,
                "extraction_method": m.extraction_method,
            }
            for m in extracted
        ],
    }
