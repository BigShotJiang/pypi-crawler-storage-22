"""整合 API：合并建议管理。"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status

from team_memory_hub.core.memory_consolidator import MemoryConsolidator
from team_memory_hub.server.dependencies import get_current_user, get_db, require_role
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import MergeSuggestion, User, UserRole

router = APIRouter()


def _get_consolidator(db: Database) -> MemoryConsolidator:
    return MemoryConsolidator(db)


@router.get("/suggestions", response_model=list[MergeSuggestion])
async def list_suggestions(
    request: Request,
    status_filter: str | None = Query(None, alias="status", description="按状态筛选"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    current_user: User = Depends(require_role(UserRole.MAINTAINER)),
    db: Database = Depends(get_db),
):
    """列出当前用户团队的合并建议。"""
    consolidator = _get_consolidator(db)
    suggestions, _ = await consolidator.get_suggestions(
        team_id=current_user.team_id,
        status=status_filter,
        page=page,
        page_size=page_size,
    )
    return suggestions


@router.post("/scan")
async def trigger_scan(
    request: Request,
    current_user: User = Depends(require_role(UserRole.ADMIN)),
    db: Database = Depends(get_db),
):
    """触发合并候选扫描（仅限管理员）。"""
    consolidator = _get_consolidator(db)
    candidates = await consolidator.detect_merge_candidates(
        team_id=current_user.team_id,
    )

    created = []
    for candidate in candidates:
        suggestion = await consolidator.generate_merge_suggestion(
            team_id=current_user.team_id,
            memory_ids=candidate["ids"],
            similarity=candidate["similarity"],
        )
        created.append(suggestion)

    return {"scanned": len(candidates), "suggestions_created": len(created)}


@router.post("/suggestions/{suggestion_id}/accept")
async def accept_suggestion(
    suggestion_id: str,
    current_user: User = Depends(require_role(UserRole.MAINTAINER)),
    db: Database = Depends(get_db),
):
    """接受并执行合并建议。"""
    consolidator = _get_consolidator(db)
    new_id = await consolidator.execute_merge(suggestion_id, current_user.id)
    if new_id is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="建议未找到")
    return {"merged_memory_id": new_id}


@router.post("/suggestions/{suggestion_id}/reject")
async def reject_suggestion(
    suggestion_id: str,
    current_user: User = Depends(require_role(UserRole.MAINTAINER)),
    db: Database = Depends(get_db),
):
    """Reject a merge suggestion."""
    consolidator = _get_consolidator(db)
    success = await consolidator.reject_suggestion(suggestion_id, current_user.id)
    if not success:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="建议未找到")
    return {"status": "rejected"}


@router.post("/suggestions/{suggestion_id}/dismiss")
async def dismiss_suggestion(
    suggestion_id: str,
    current_user: User = Depends(require_role(UserRole.MAINTAINER)),
    db: Database = Depends(get_db),
):
    """Dismiss a merge suggestion."""
    consolidator = _get_consolidator(db)
    success = await consolidator.dismiss_suggestion(suggestion_id, current_user.id)
    if not success:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="建议未找到")
    return {"status": "dismissed"}


@router.get("/stats")
async def get_consolidation_stats(
    current_user: User = Depends(require_role(UserRole.MAINTAINER)),
    db: Database = Depends(get_db),
):
    """Get merge suggestion statistics."""
    consolidator = _get_consolidator(db)
    return await consolidator.get_stats(current_user.team_id)
