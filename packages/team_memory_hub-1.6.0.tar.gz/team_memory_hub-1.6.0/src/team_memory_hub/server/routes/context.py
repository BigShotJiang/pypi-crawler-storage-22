"""上下文 API 路由：为 AI 代理构建多层上下文。"""

from __future__ import annotations

from pydantic import BaseModel, Field
from fastapi import APIRouter, Depends, Query, Request
from typing import Any

from team_memory_hub.config import get_config
from team_memory_hub.core.context_cache import ContextCache
from team_memory_hub.core.context_engine import ContextEngine
from team_memory_hub.core.search_engine import HybridSearchEngine
from team_memory_hub.providers.embedding import create_embedding_provider
from team_memory_hub.server.dependencies import get_current_user, get_db
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import User

router = APIRouter()

# 模块级缓存实例（在请求间共享）
_context_cache = ContextCache()


class ContextLayerResponse(BaseModel):
    """响应中的单个上下文层。"""
    name: str
    layer: int
    items: list[dict[str, Any]] = Field(default_factory=list)
    token_estimate: int = 0


class ContextResponseModel(BaseModel):
    """完整的上下文响应。"""
    layers: list[ContextLayerResponse] = Field(default_factory=list)
    total_token_estimate: int = 0
    cache_hit: bool = False


def _get_context_engine(request: Request, db: Database) -> ContextEngine:
    """创建上下文引擎实例。"""
    config = get_config()
    embedding = create_embedding_provider(config.embedding)
    search_engine = HybridSearchEngine(
        db=db,
        embedding_provider=embedding,
        semantic_weight=config.search.semantic_weight,
        keyword_weight=config.search.keyword_weight,
    )
    return ContextEngine(db=db, search_engine=search_engine, cache=_context_cache)


@router.get("", response_model=ContextResponseModel)
async def get_context(
    request: Request,
    query: str | None = Query(None, description="第 2 层的搜索查询"),
    project_id: str | None = Query(None, description="第 1 层的项目 ID"),
    max_tokens: int = Query(4000, ge=100, le=32000, description="令牌预算"),
    layers: str | None = Query(None, description="逗号分隔的层号（如 '0,1,2'）"),
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """为 AI 代理消耗构建多层上下文。

    第 0 层：固定/已验证的团队范围标准（缓存 1h）
    第 1 层：特定于项目的上下文（缓存 10 分钟）
    第 2 层：来自搜索的与查询相关的记忆
    """
    engine = _get_context_engine(request, db)

    # 解析层过滤器
    include_layers: list[int] | None = None
    if layers:
        include_layers = [int(x.strip()) for x in layers.split(",") if x.strip().isdigit()]

    ctx = await engine.build_context(
        team_id=current_user.team_id,
        user_id=current_user.id,
        project_id=project_id,
        query=query,
        max_tokens=max_tokens,
        include_layers=include_layers,
    )

    return ContextResponseModel(
        layers=[
            ContextLayerResponse(
                name=layer.name,
                layer=layer.layer,
                items=layer.items,
                token_estimate=layer.token_estimate,
            )
            for layer in ctx.layers
        ],
        total_token_estimate=ctx.total_token_estimate,
        cache_hit=ctx.cache_hit,
    )


@router.post("/invalidate")
async def invalidate_cache(
    request: Request,
    prefix: str | None = Query(None, description="Cache key prefix to invalidate"),
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """Invalidate context cache entries."""
    if prefix:
        count = _context_cache.invalidate_prefix(prefix)
    else:
        count = _context_cache.size
        _context_cache.clear()

    return {"invalidated": count}
