"""策展路由：记忆质量标记操作。"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status

from team_memory_hub.server.dependencies import get_current_user, get_db, require_role
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import User

logger = logging.getLogger(__name__)
router = APIRouter()


async def _update_quality(
    db: Database, memory_id: str, quality: str, user: User, extra: dict | None = None,
) -> dict:
    """更新记忆质量状态的共用逻辑。"""
    row = await db.fetch_one("SELECT id, quality FROM memories WHERE id = ?", (memory_id,))
    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Memory not found")

    updates = {"quality": quality, "updated_at": datetime.now(timezone.utc).isoformat()}
    if extra:
        updates.update(extra)

    set_clause = ", ".join(f"{k} = ?" for k in updates)
    values = list(updates.values()) + [memory_id]
    await db.execute(f"UPDATE memories SET {set_clause} WHERE id = ?", tuple(values))
    await db.commit()

    return {"id": memory_id, "quality": quality, "updated_by": user.id}


@router.post("/memories/{memory_id}/verify")
async def verify_memory(
    memory_id: str,
    user: User = Depends(require_role("maintainer")),
    db: Database = Depends(get_db),
):
    """标记记忆为 verified（需 maintainer+ 角色）。"""
    return await _update_quality(db, memory_id, "verified", user, {
        "verified_by": user.id,
        "verified_at": datetime.now(timezone.utc).isoformat(),
    })


@router.post("/memories/{memory_id}/stale")
async def mark_stale(
    memory_id: str,
    user: User = Depends(require_role("maintainer")),
    db: Database = Depends(get_db),
):
    """标记记忆为 stale（需 maintainer+ 角色）。"""
    return await _update_quality(db, memory_id, "stale", user)


@router.post("/memories/{memory_id}/pin")
async def pin_memory(
    memory_id: str,
    user: User = Depends(require_role("maintainer")),
    db: Database = Depends(get_db),
):
    """置顶记忆（需 maintainer+ 角色）。"""
    return await _update_quality(db, memory_id, "pinned", user)


@router.post("/memories/{memory_id}/archive")
async def archive_memory(
    memory_id: str,
    user: User = Depends(require_role("maintainer")),
    db: Database = Depends(get_db),
):
    """归档记忆（需 maintainer+ 角色）。"""
    return await _update_quality(db, memory_id, "archived", user)
