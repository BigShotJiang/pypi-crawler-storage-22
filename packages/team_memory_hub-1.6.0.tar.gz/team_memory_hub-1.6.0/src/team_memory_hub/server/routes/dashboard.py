"""仪表板路由：带有 HTMX 支持的 Jinja2 HTML 页面。"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Cookie, Depends, Form, Query, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from team_memory_hub.core.rbac import has_minimum_role
from team_memory_hub.server.dependencies import get_db
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import UserRole

router = APIRouter()

# Template & static directories
_DASHBOARD_DIR = Path(__file__).resolve().parent.parent.parent / "dashboard"
_TEMPLATE_DIR = _DASHBOARD_DIR / "templates"
_STATIC_DIR = _DASHBOARD_DIR / "static"
templates = Jinja2Templates(directory=str(_TEMPLATE_DIR))


async def _get_session_user(request: Request, db: Database) -> dict | None:
    """从 session cookie 解析当前登录用户。"""
    token = request.cookies.get("tmh_session")
    if not token:
        return None
    try:
        from jose import jwt as jose_jwt
        from team_memory_hub.config import get_config
        config = get_config()
        payload = jose_jwt.decode(token, config.auth.jwt_secret, algorithms=[config.auth.jwt_algorithm])
        user_id = payload.get("sub")
        if not user_id:
            return None
        row = await db.fetch_one("SELECT * FROM users WHERE id = ? AND is_active = 1", (user_id,))
        if row:
            return dict(row)
    except Exception:
        pass
    return None


def _base_context(request: Request, user: dict | None = None, **extra) -> dict:
    """构建所有 Dashboard 页面的基础模板上下文。"""
    ctx = {"request": request}
    if user:
        ctx["user"] = user
        ctx["is_admin"] = has_minimum_role(user.get("role", "viewer"), UserRole.MAINTAINER)
    else:
        ctx["is_admin"] = False
    ctx.update(extra)
    return ctx


# ========== Login ==========

@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    """Login page."""
    return templates.TemplateResponse("login.html", {"request": request, "error": None})


@router.post("/login")
async def login_submit(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    db: Database = Depends(get_db),
):
    """Handle login form submission."""
    from team_memory_hub.config import get_config

    config = get_config()

    # 支持用户名或邮箱登录，逐个验证密码
    from team_memory_hub.server.routes.auth import verify_password

    candidates = await db.fetch_all(
        "SELECT * FROM users WHERE (name = ? COLLATE NOCASE OR email = ? COLLATE NOCASE) AND is_active = 1",
        (username, username),
    )
    row = None
    for candidate in candidates:
        if candidate.get("password_hash") and verify_password(password, candidate["password_hash"]):
            row = candidate
            break

    if row is None:
        return templates.TemplateResponse("login.html", {
            "request": request, "error": "用户名或密码错误",
        })

    # Generate JWT for dashboard session
    try:
        from jose import jwt as jose_jwt

        payload = {
            "sub": row["id"],
            "name": row["name"],
            "role": row.get("role", "viewer"),
            "exp": datetime.now(timezone.utc) + timedelta(hours=8),
        }
        token = jose_jwt.encode(payload, config.auth.jwt_secret, algorithm=config.auth.jwt_algorithm)
    except ImportError:
        # Fallback: simple cookie without JWT
        token = row["id"]

    response = RedirectResponse(url="/dashboard/", status_code=303)
    response.set_cookie("tmh_session", token, httponly=True, max_age=8 * 3600)
    return response


@router.get("/logout")
async def logout():
    """Clear session and redirect to login."""
    response = RedirectResponse(url="/dashboard/login", status_code=303)
    response.delete_cookie("tmh_session")
    return response


# ========== Pages ==========

@router.get("/", response_class=HTMLResponse)
async def dashboard_index(request: Request, db: Database = Depends(get_db)):
    """Overview dashboard page."""
    user = await _get_session_user(request, db)
    stats = await _get_overview_stats(db)
    return templates.TemplateResponse("index.html", _base_context(request, user, stats=stats))


@router.get("/memories", response_class=HTMLResponse)
async def memories_page(request: Request, db: Database = Depends(get_db)):
    """Memory browser page."""
    user = await _get_session_user(request, db)
    rows = await db.fetch_all(
        "SELECT * FROM memories WHERE quality != 'archived' ORDER BY updated_at DESC LIMIT 50"
    )
    memories = [_parse_memory_row(r) for r in rows]
    return templates.TemplateResponse("memories.html", _base_context(
        request, user, memories=memories, filters={}, total=len(memories), page=1, page_size=50,
    ))


@router.get("/memories/list", response_class=HTMLResponse)
async def memories_list_partial(
    request: Request,
    scope: str | None = Query(None),
    category: str | None = Query(None),
    quality: str | None = Query(None),
    page: int = Query(1, ge=1),
    db: Database = Depends(get_db),
):
    """HTMX partial: filtered memory table."""
    page_size = 50
    conditions: list[str] = []
    params: list[Any] = []

    if scope:
        conditions.append("scope = ?")
        params.append(scope)
    if category:
        conditions.append("category = ?")
        params.append(category)
    if quality:
        conditions.append("quality = ?")
        params.append(quality)
    else:
        conditions.append("quality != 'archived'")

    where = " AND ".join(conditions) if conditions else "1=1"
    offset = (page - 1) * page_size

    count_row = await db.fetch_one(
        f"SELECT COUNT(*) as cnt FROM memories WHERE {where}", tuple(params)
    )
    total = count_row["cnt"] if count_row else 0

    rows = await db.fetch_all(
        f"SELECT * FROM memories WHERE {where} ORDER BY updated_at DESC LIMIT ? OFFSET ?",
        tuple(params + [page_size, offset]),
    )
    memories = [_parse_memory_row(r) for r in rows]

    return templates.TemplateResponse("partials/memory_table.html", {
        "request": request,
        "memories": memories,
        "total": total,
        "page": page,
        "page_size": page_size,
    })


@router.get("/consolidation", response_class=HTMLResponse)
async def consolidation_page(request: Request, db: Database = Depends(get_db)):
    """Merge suggestions review page."""
    stats_rows = await db.fetch_all(
        "SELECT status, COUNT(*) as cnt FROM merge_suggestions GROUP BY status"
    )
    stats = {r["status"]: r["cnt"] for r in stats_rows}
    stats["total"] = sum(stats.values())

    rows = await db.fetch_all(
        "SELECT * FROM merge_suggestions WHERE status = 'pending' ORDER BY created_at DESC LIMIT 50"
    )

    suggestions = []
    for r in rows:
        s = dict(r)
        if isinstance(s.get("original_ids"), str):
            try:
                s["original_ids"] = json.loads(s["original_ids"])
            except json.JSONDecodeError:
                s["original_ids"] = []
        suggestions.append(s)

    user = await _get_session_user(request, db)
    return templates.TemplateResponse("consolidation.html", _base_context(
        request, user, stats=stats, suggestions=suggestions,
    ))


@router.get("/specs", response_class=HTMLResponse)
async def specs_page(request: Request, db: Database = Depends(get_db)):
    """Specs and proposals page."""
    rows = await db.fetch_all(
        "SELECT * FROM spec_proposals WHERE status NOT IN ('withdrawn') ORDER BY created_at DESC LIMIT 50"
    )
    user = await _get_session_user(request, db)
    return templates.TemplateResponse("specs.html", _base_context(
        request, user, proposals=rows,
    ))


@router.get("/search", response_class=HTMLResponse)
async def search_page(request: Request, db: Database = Depends(get_db)):
    """Search debug page."""
    user = await _get_session_user(request, db)
    return templates.TemplateResponse("search.html", _base_context(request, user))


@router.post("/search/run", response_class=HTMLResponse)
async def search_run(
    request: Request,
    query: str = Form(...),
    scope: str | None = Form(None),
    db: Database = Depends(get_db),
):
    """Execute search and return results (HTMX)."""
    conditions = ["summary LIKE ?"]
    params: list[Any] = [f"%{query}%"]

    if scope:
        conditions.append("scope = ?")
        params.append(scope)

    where = " AND ".join(conditions)
    rows = await db.fetch_all(
        f"SELECT * FROM memories WHERE {where} ORDER BY updated_at DESC LIMIT 20",
        tuple(params),
    )
    results = [_parse_memory_row(r) for r in rows]

    return templates.TemplateResponse("partials/search_results.html", {
        "request": request,
        "results": results,
    })


# ========== Helpers ==========

async def _get_overview_stats(db: Database) -> dict[str, Any]:
    """Gather overview statistics."""
    mem_count = await db.fetch_one("SELECT COUNT(*) as cnt FROM memories")
    user_count = await db.fetch_one("SELECT COUNT(*) as cnt FROM users")
    team_count = await db.fetch_one("SELECT COUNT(*) as cnt FROM teams")
    proj_count = await db.fetch_one("SELECT COUNT(*) as cnt FROM projects")

    quality_rows = await db.fetch_all(
        "SELECT quality, COUNT(*) as count FROM memories GROUP BY quality"
    )

    recent = await db.fetch_all(
        "SELECT summary, updated_at FROM memories ORDER BY updated_at DESC LIMIT 10"
    )

    # Activity trend: memories created per day over last 14 days
    trend_labels: list[str] = []
    trend_data: list[int] = []
    try:
        today = datetime.now(timezone.utc).date()
        for i in range(13, -1, -1):
            day = today - timedelta(days=i)
            day_str = day.isoformat()
            next_day_str = (day + timedelta(days=1)).isoformat()
            row = await db.fetch_one(
                "SELECT COUNT(*) as cnt FROM memories WHERE created_at >= ? AND created_at < ?",
                (day_str, next_day_str),
            )
            trend_labels.append(day.strftime("%m-%d"))
            trend_data.append(row["cnt"] if row else 0)
    except Exception:
        trend_labels = []
        trend_data = []

    return {
        "total_memories": mem_count["cnt"] if mem_count else 0,
        "total_users": user_count["cnt"] if user_count else 0,
        "total_teams": team_count["cnt"] if team_count else 0,
        "total_projects": proj_count["cnt"] if proj_count else 0,
        "quality_dist": quality_rows,
        "recent_memories": recent,
        "trend_labels": trend_labels,
        "trend_data": trend_data,
    }


def _parse_memory_row(row: dict) -> dict:
    """Parse a raw memory row for template usage."""
    result = dict(row)
    tags = result.get("tags", "[]")
    if isinstance(tags, str):
        try:
            result["tags"] = json.loads(tags)
        except json.JSONDecodeError:
            result["tags"] = []
    return result
