"""SSE 端点：实时事件流。"""

from __future__ import annotations

import asyncio
import json

from fastapi import APIRouter, Query, Request
from starlette.responses import StreamingResponse

from team_memory_hub.server.event_bus import get_event_bus

router = APIRouter()


@router.get("/stream")
async def event_stream(
    request: Request,
    team_id: str | None = Query(None, description="按团队 ID 筛选"),
    event_type: str | None = Query(None, description="按事件类型筛选（逗号分隔）"),
):
    """Server-Sent Events 流。

    客户端可以按 team_id 和/或 event_type 选择筛选。
    """
    bus = get_event_bus()

    types: list[str] | None = None
    if event_type:
        types = [t.strip() for t in event_type.split(",") if t.strip()]

    queue = bus.subscribe(event_types=types)

    async def generate():
        try:
            while True:
                # 检查客户端是否断开连接
                if await request.is_disconnected():
                    break

                try:
                    event = await asyncio.wait_for(queue.get(), timeout=30.0)
                except asyncio.TimeoutError:
                    # 发送保活注释
                    yield ": keepalive\n\n"
                    continue

                # 如果指定了 team_id，应用筛选
                if team_id and event["data"].get("team_id") != team_id:
                    continue

                yield f"event: {event['type']}\ndata: {json.dumps(event['data'])}\n\n"
        finally:
            bus.unsubscribe(queue)

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
