"""API 密钥 CRUD 路由。"""

from __future__ import annotations

import secrets
import string
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status

from team_memory_hub.server.dependencies import get_current_user, get_db
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import ApiKeyCreate, ApiKeyInfo, ApiKeyResponse, User

router = APIRouter()

_KEY_CHARS = string.ascii_letters + string.digits
_KEY_LENGTH = 48


def generate_api_key() -> str:
    """生成安全的 API 密钥。"""
    return "tmh_" + "".join(secrets.choice(_KEY_CHARS) for _ in range(_KEY_LENGTH))


@router.post("", response_model=ApiKeyResponse, status_code=status.HTTP_201_CREATED)
async def create_key(
    data: ApiKeyCreate,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """为当前用户创建新的 API 密钥。"""
    key_id = f"key_{''.join(secrets.choice(string.ascii_lowercase + string.digits) for _ in range(8))}"
    key_value = generate_api_key()

    expires_at = data.expires_at.isoformat() if data.expires_at else None

    await db.execute(
        """INSERT INTO api_keys (id, key, user_id, name, scope, expires_at)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (key_id, key_value, current_user.id, data.name, data.scope, expires_at),
    )
    await db.commit()

    return ApiKeyResponse(
        id=key_id,
        key=key_value,
        name=data.name,
        scope=data.scope,
        expires_at=data.expires_at,
    )


@router.get("", response_model=list[ApiKeyInfo])
async def list_keys(
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """列出当前用户的所有 API 密钥。"""
    rows = await db.fetch_all(
        """SELECT id, name, scope, expires_at, is_active, last_used_at, created_at
           FROM api_keys WHERE user_id = ? ORDER BY created_at DESC""",
        (current_user.id,),
    )
    return [
        ApiKeyInfo(
            id=row["id"],
            name=row["name"],
            scope=row["scope"],
            expires_at=row.get("expires_at"),
            is_active=bool(row.get("is_active", True)),
            last_used_at=row.get("last_used_at"),
            created_at=row.get("created_at"),
        )
        for row in rows
    ]


@router.delete("/{key_id}", status_code=status.HTTP_204_NO_CONTENT)
async def revoke_key(
    key_id: str,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """撤销（停用）API 密钥。"""
    row = await db.fetch_one(
        "SELECT id, user_id FROM api_keys WHERE id = ?", (key_id,)
    )
    if not row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="API 密钥未找到",
        )
    if row["user_id"] != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="无法撤销其他用户的密钥",
        )

    await db.execute(
        "UPDATE api_keys SET is_active = 0 WHERE id = ?", (key_id,)
    )
    await db.commit()
