"""MCP 路由代理：重新导出 MCP 服务器路由。"""

from team_memory_hub.server.mcp_server import router

__all__ = ["router"]
