"""记忆 API 路由：CRUD、质量生命周期、版本、过滤。"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status

from team_memory_hub.core.memory_file_store import MemoryFileStore
from team_memory_hub.core.memory_store import MemoryStore
from team_memory_hub.core.rbac import can_access_memory, can_delete_memory, can_modify_memory, check_permission
from team_memory_hub.server.dependencies import get_current_user, get_db, require_role
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import (
    Memory,
    MemoryCreate,
    MemoryDetail,
    MemoryListResponse,
    MemoryUpdate,
    MemoryVersion,
    质量Update,
    User,
    UserRole,
)

router = APIRouter()


def _get_memory_store(request: Request, db: Database) -> MemoryStore:
    """获取或创建 MemoryStore 实例。"""
    config = request.app.state.config
    file_store = MemoryFileStore(config.storage.memories_dir)
    return MemoryStore(db, file_store)


@router.post("", response_model=Memory, status_code=status.HTTP_201_CREATED)
async def create_memory(
    data: MemoryCreate,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """创建新的记忆。"""
    # 检查写入权限
    if data.scope in ("team", "project"):
        if not check_permission(current_user.role, "memory:write_team"):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="权限不足，无法写入团队/项目记忆",
            )

    store = _get_memory_store(request, db)

    # 获取所有者名称用于文件路径
    owner_name = current_user.name

    # 如果提供了 project_id，获取项目名称
    project_name = None
    if data.project_id:
        project = await db.fetch_one(
            "SELECT name FROM projects WHERE id = ?", (data.project_id,)
        )
        if project:
            project_name = project["name"]

    memory = await store.create(
        data=data,
        owner_id=current_user.id,
        team_id=current_user.team_id,
        owner_name=owner_name,
        project_name=project_name,
    )
    return memory


@router.get("", response_model=MemoryListResponse)
async def list_memories(
    request: Request,
    scope: str | None = Query(None, description="按范围筛选：private/project/team"),
    category: str | None = Query(None, description="按类别筛选"),
    project_id: str | None = Query(None, description="按项目 ID 筛选"),
    quality: str | None = Query(None, description="按质量状态筛选"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """列出具有范围/类别/项目筛选的记忆。"""
    store = _get_memory_store(request, db)

    memories, total = await store.list_memories(
        team_id=current_user.team_id,
        user_id=current_user.id,
        scope=scope,
        category=category,
        project_id=project_id,
        quality=quality,
        page=page,
        page_size=page_size,
        include_private=False,  # 启用私有数据隔离
    )

    return MemoryListResponse(
        items=memories,
        total=total,
        page=page,
        page_size=page_size,
    )


@router.get("/{memory_id}", response_model=Memory)
async def get_memory(
    memory_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """按 ID 获取记忆元数据。"""
    store = _get_memory_store(request, db)
    memory = await store.get(memory_id)

    if memory is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="记忆未找到")

    # 访问控制
    if not can_access_memory(
        user_id=current_user.id,
        user_role=current_user.role,
        user_team_id=current_user.team_id,
        memory_owner_id=memory.owner_id,
        memory_scope=memory.scope,
        memory_team_id=memory.team_id,
    ):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="访问被拒绝")

    return memory


@router.get("/{memory_id}/detail", response_model=MemoryDetail)
async def get_memory_detail(
    memory_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """Get memory with full content from file."""
    store = _get_memory_store(request, db)

    # 首先检查访问权限
    memory = await store.get(memory_id)
    if memory is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="记忆未找到")

    if not can_access_memory(
        user_id=current_user.id,
        user_role=current_user.role,
        user_team_id=current_user.team_id,
        memory_owner_id=memory.owner_id,
        memory_scope=memory.scope,
        memory_team_id=memory.team_id,
    ):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="访问被拒绝")

    detail = await store.get_detail(memory_id)
    return detail


@router.put("/{memory_id}", response_model=Memory)
async def update_memory(
    memory_id: str,
    data: MemoryUpdate,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """Update a memory."""
    store = _get_memory_store(request, db)

    memory = await store.get(memory_id)
    if memory is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="记忆未找到")

    if not can_modify_memory(
        user_id=current_user.id,
        user_role=current_user.role,
        user_team_id=current_user.team_id,
        memory_owner_id=memory.owner_id,
        memory_scope=memory.scope,
        memory_team_id=memory.team_id,
    ):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="修改被拒绝")

    updated = await store.update(
        memory_id=memory_id,
        data=data,
        changed_by=current_user.id,
        owner_name=current_user.name,
    )
    return updated


@router.delete("/{memory_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_memory(
    memory_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """删除 a memory."""
    store = _get_memory_store(request, db)

    memory = await store.get(memory_id)
    if memory is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="记忆未找到")

    if not can_delete_memory(
        user_id=current_user.id,
        user_role=current_user.role,
        user_team_id=current_user.team_id,
        memory_owner_id=memory.owner_id,
        memory_scope=memory.scope,
        memory_team_id=memory.team_id,
    ):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="删除被拒绝")

    await store.delete(memory_id)


# ========== 质量 Lifecycle ==========

@router.post("/{memory_id}/verify", response_model=Memory)
async def verify_memory(
    memory_id: str,
    request: Request,
    current_user: User = Depends(require_role(UserRole.MAINTAINER)),
    db: Database = Depends(get_db),
):
    """Mark memory as verified (需要维护者权限+)."""
    store = _get_memory_store(request, db)
    memory = await store.get(memory_id)
    if memory is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="记忆未找到")
    if memory.team_id != current_user.team_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="无权操作其他团队的记忆")
    await store.update_quality(memory_id, "verified", current_user.id)
    return await store.get(memory_id)


@router.post("/{memory_id}/stale", response_model=Memory)
async def mark_stale(
    memory_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """Mark memory as stale (需要维护者权限或记忆所有者)."""
    store = _get_memory_store(request, db)
    memory = await store.get(memory_id)
    if memory is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="记忆未找到")
    if memory.team_id != current_user.team_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="无权操作其他团队的记忆")
    from team_memory_hub.core.rbac import has_minimum_role
    if memory.owner_id != current_user.id and not has_minimum_role(current_user.role, UserRole.MAINTAINER):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="需要维护者权限或记忆所有者")
    await store.update_quality(memory_id, "stale", current_user.id)
    return await store.get(memory_id)


@router.post("/{memory_id}/pin", response_model=Memory)
async def pin_memory(
    memory_id: str,
    request: Request,
    current_user: User = Depends(require_role(UserRole.MAINTAINER)),
    db: Database = Depends(get_db),
):
    """Pin a memory (需要维护者权限+)."""
    store = _get_memory_store(request, db)
    memory = await store.get(memory_id)
    if memory is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="记忆未找到")
    if memory.team_id != current_user.team_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="无权操作其他团队的记忆")
    await store.update_quality(memory_id, "pinned", current_user.id)
    return await store.get(memory_id)


@router.post("/{memory_id}/archive", response_model=Memory)
async def archive_memory(
    memory_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """Archive a memory (需要维护者权限或记忆所有者)."""
    store = _get_memory_store(request, db)
    memory = await store.get(memory_id)
    if memory is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="记忆未找到")
    if memory.team_id != current_user.team_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="无权操作其他团队的记忆")
    from team_memory_hub.core.rbac import has_minimum_role
    if memory.owner_id != current_user.id and not has_minimum_role(current_user.role, UserRole.MAINTAINER):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="需要维护者权限或记忆所有者")
    await store.update_quality(memory_id, "archived", current_user.id)
    return await store.get(memory_id)


# ========== Version History ==========

@router.get("/{memory_id}/versions", response_model=list[MemoryVersion])
async def get_versions(
    memory_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """获取版本历史 for a memory."""
    store = _get_memory_store(request, db)

    # Check access
    memory = await store.get(memory_id)
    if memory is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="记忆未找到")

    if not can_access_memory(
        user_id=current_user.id,
        user_role=current_user.role,
        user_team_id=current_user.team_id,
        memory_owner_id=memory.owner_id,
        memory_scope=memory.scope,
        memory_team_id=memory.team_id,
    ):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="访问被拒绝")

    return await store.get_versions(memory_id)
