"""偏好 API 路由：用户偏好、团队默认值、建议。"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel

from team_memory_hub.core.preference_engine import PreferenceEngine
from team_memory_hub.server.dependencies import get_current_user, get_db, require_role
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import User, UserRole

router = APIRouter()


class PreferenceSet(BaseModel):
    category: str
    key: str
    value: str
    scope: str = "global"
    metadata: dict | None = None


class TeamDefaultSet(BaseModel):
    category: str
    key: str
    value: str
    metadata: dict | None = None


def _get_engine(db: Database) -> PreferenceEngine:
    return PreferenceEngine(db)


# ========== 有效偏好 ==========

@router.get("/effective")
async def get_effective_preferences(
    category: str | None = Query(None),
    scope: str = Query("global"),
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """获取当前用户的有效偏好（合并）。"""
    engine = _get_engine(db)
    prefs = await engine.get_effective_preferences(
        user_id=current_user.id,
        team_id=current_user.team_id,
        category=category,
        scope=scope,
    )
    return {"preferences": prefs}


# ========== User Preferences ==========

@router.get("/user")
async def list_user_preferences(
    category: str | None = Query(None),
    scope: str | None = Query(None),
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """List the current user's preferences."""
    engine = _get_engine(db)
    prefs = await engine.list_user_preferences(
        user_id=current_user.id,
        category=category,
        scope=scope,
    )
    return {"items": prefs}


@router.post("/user", status_code=status.HTTP_201_CREATED)
async def set_user_preference(
    data: PreferenceSet,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """Set a user preference."""
    engine = _get_engine(db)
    pref_id = await engine.set_user_preference(
        user_id=current_user.id,
        category=data.category,
        key=data.key,
        value=data.value,
        scope=data.scope,
        metadata=data.metadata,
    )
    return {"id": pref_id, "status": "set"}


@router.delete("/user/{category}/{key}")
async def delete_user_preference(
    category: str,
    key: str,
    scope: str = Query("global"),
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """删除 a user preference."""
    engine = _get_engine(db)
    deleted = await engine.delete_user_preference(
        user_id=current_user.id,
        category=category,
        key=key,
        scope=scope,
    )
    if not deleted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Preference not found")
    return {"status": "deleted"}


# ========== Team Default Preferences ==========

@router.get("/team")
async def list_team_defaults(
    category: str | None = Query(None),
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """List team default preferences."""
    engine = _get_engine(db)
    prefs = await engine.list_team_defaults(
        team_id=current_user.team_id,
        category=category,
    )
    return {"items": prefs}


@router.post("/team", status_code=status.HTTP_201_CREATED)
async def set_team_default(
    data: TeamDefaultSet,
    current_user: User = Depends(require_role(UserRole.MAINTAINER)),
    db: Database = Depends(get_db),
):
    """Set a team default preference (需要维护者权限+)."""
    engine = _get_engine(db)
    pref_id = await engine.set_team_default(
        team_id=current_user.team_id,
        category=data.category,
        key=data.key,
        value=data.value,
        set_by=current_user.id,
        metadata=data.metadata,
    )
    return {"id": pref_id, "status": "set"}


@router.delete("/team/{category}/{key}")
async def delete_team_default(
    category: str,
    key: str,
    current_user: User = Depends(require_role(UserRole.MAINTAINER)),
    db: Database = Depends(get_db),
):
    """删除 a team default preference (需要维护者权限+)."""
    engine = _get_engine(db)
    deleted = await engine.delete_team_default(
        team_id=current_user.team_id,
        category=category,
        key=key,
    )
    if not deleted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Default not found")
    return {"status": "deleted"}


# ========== Preference Suggestions ==========

@router.get("/suggestions")
async def list_suggestions(
    suggestion_status: str = Query("pending", alias="status"),
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """List preference suggestions for the current user."""
    engine = _get_engine(db)
    suggestions = await engine.list_suggestions(
        user_id=current_user.id,
        status=suggestion_status,
    )
    return {"items": suggestions}


@router.post("/suggestions/{suggestion_id}/accept")
async def accept_suggestion(
    suggestion_id: str,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """Accept a preference suggestion."""
    engine = _get_engine(db)
    accepted = await engine.accept_suggestion(suggestion_id, current_user.id)
    if not accepted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="建议未找到")
    return {"status": "accepted"}


@router.post("/suggestions/{suggestion_id}/reject")
async def reject_suggestion(
    suggestion_id: str,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """Reject a preference suggestion."""
    engine = _get_engine(db)
    rejected = await engine.reject_suggestion(suggestion_id, current_user.id)
    if not rejected:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="建议未找到")
    return {"status": "rejected"}
