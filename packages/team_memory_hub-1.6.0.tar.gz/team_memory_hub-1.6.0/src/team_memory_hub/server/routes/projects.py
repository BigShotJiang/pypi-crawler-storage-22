"""项目管理 API 路由。"""

from __future__ import annotations

import json
import secrets
import string

from fastapi import APIRouter, Depends, HTTPException, Query, status

from team_memory_hub.server.dependencies import get_current_user, get_db, require_role
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import Project, ProjectCreate, User, UserRole

router = APIRouter()

_ID_CHARS = string.ascii_lowercase + string.digits


@router.post("", response_model=Project, status_code=status.HTTP_201_CREATED)
async def create_project(
    data: ProjectCreate,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """在用户的团队中创建新项目。"""
    project_id = f"proj_{''.join(secrets.choice(_ID_CHARS) for _ in range(8))}"

    existing = await db.fetch_one(
        "SELECT id FROM projects WHERE name = ? AND team_id = ?",
        (data.name, current_user.team_id),
    )
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="项目名称已在团队中存在",
        )

    await db.execute(
        """INSERT INTO projects (id, name, team_id, description, project_type)
           VALUES (?, ?, ?, ?, ?)""",
        (project_id, data.name, current_user.team_id, data.description, data.project_type),
    )
    await db.commit()

    return Project(
        id=project_id,
        name=data.name,
        team_id=current_user.team_id,
        description=data.description,
        project_type=data.project_type,
    )


@router.get("", response_model=list[Project])
async def list_projects(
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """列出用户团队中的项目。"""
    rows = await db.fetch_all(
        "SELECT * FROM projects WHERE team_id = ? AND is_active = 1 ORDER BY name",
        (current_user.team_id,),
    )
    return [_row_to_project(r) for r in rows]


@router.get("/{project_id}", response_model=Project)
async def get_project(
    project_id: str,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """按 ID 获取项目。"""
    row = await db.fetch_one(
        "SELECT * FROM projects WHERE id = ? AND team_id = ?",
        (project_id, current_user.team_id),
    )
    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="项目未找到")
    return _row_to_project(row)


@router.delete("/{project_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_project(
    project_id: str,
    current_user: User = Depends(require_role(UserRole.MAINTAINER)),
    db: Database = Depends(get_db),
):
    """软删除项目。"""
    row = await db.fetch_one(
        "SELECT id FROM projects WHERE id = ? AND team_id = ?",
        (project_id, current_user.team_id),
    )
    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="项目未找到")

    await db.execute(
        "UPDATE projects SET is_active = 0 WHERE id = ?", (project_id,)
    )
    await db.commit()


def _row_to_project(row: dict) -> Project:
    languages = row.get("detected_languages", "[]")
    if isinstance(languages, str):
        try:
            languages = json.loads(languages)
        except json.JSONDecodeError:
            languages = []

    frameworks = row.get("detected_frameworks", "[]")
    if isinstance(frameworks, str):
        try:
            frameworks = json.loads(frameworks)
        except json.JSONDecodeError:
            frameworks = []

    return Project(
        id=row["id"],
        name=row["name"],
        team_id=row["team_id"],
        description=row.get("description"),
        is_active=row.get("is_active", True),
        project_type=row.get("project_type"),
        detected_languages=languages,
        detected_frameworks=frameworks,
        created_at=row.get("created_at"),
    )
