"""搜索 API 路由：混合搜索端点。"""

from __future__ import annotations

from pydantic import BaseModel, Field
from fastapi import APIRouter, Depends, Query, Request

from team_memory_hub.config import get_config
from team_memory_hub.core.search_engine import HybridSearchEngine, SearchResult
from team_memory_hub.providers.embedding import create_embedding_provider
from team_memory_hub.server.dependencies import get_current_user, get_db
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import User

router = APIRouter()


class SearchResultItem(BaseModel):
    """搜索结果响应项。"""
    id: str
    summary: str
    score: float
    scope: str = "private"
    category: str = "general"
    project_id: str | None = None
    quality: str = "community"
    tags: list[str] = Field(default_factory=list)
    created_at: str | None = None
    updated_at: str | None = None


class SearchResponse(BaseModel):
    """包含结果和元数据的搜索响应。"""
    query: str
    mode: str
    results: list[SearchResultItem]
    total: int


def _get_search_engine(request: Request, db: Database) -> HybridSearchEngine:
    """获取或创建搜索引擎实例。"""
    config = get_config()
    embedding = create_embedding_provider(config.embedding)
    return HybridSearchEngine(
        db=db,
        embedding_provider=embedding,
        semantic_weight=config.search.semantic_weight,
        keyword_weight=config.search.keyword_weight,
    )


@router.get("", response_model=SearchResponse)
async def search_memories(
    request: Request,
    q: str = Query(..., description="搜索查询"),
    mode: str = Query("hybrid", description="搜索模式：hybrid, vector_only, bm25_only"),
    scope: str | None = Query(None, description="按范围筛选"),
    category: str | None = Query(None, description="按类别筛选"),
    project_id: str | None = Query(None, description="按项目 ID 筛选"),
    limit: int = Query(10, ge=1, le=100, description="最大结果数"),
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """使用混合搜索（向量 + BM25）搜索记忆。"""
    engine = _get_search_engine(request, db)

    results = await engine.search(
        query=q,
        team_id=current_user.team_id,
        user_id=current_user.id,
        scope=scope,
        category=category,
        project_id=project_id,
        limit=limit,
        mode=mode,
    )

    items = [
        SearchResultItem(
            id=r.id,
            summary=r.summary,
            score=round(r.score, 4),
            scope=r.scope,
            category=r.category,
            project_id=r.project_id,
            quality=r.quality,
            tags=r.tags,
            created_at=r.created_at,
            updated_at=r.updated_at,
        )
        for r in results
    ]

    return SearchResponse(
        query=q,
        mode=mode,
        results=items,
        total=len(items),
    )
