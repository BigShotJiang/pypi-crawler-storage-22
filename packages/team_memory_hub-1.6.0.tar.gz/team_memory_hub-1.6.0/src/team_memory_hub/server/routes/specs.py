"""规范管理 API 路由：规范文件、提案和增量合并。"""

from __future__ import annotations

from pydantic import BaseModel, Field
from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from typing import Any

from team_memory_hub.config import get_config
from team_memory_hub.core.spec_manager import SpecManager
from team_memory_hub.server.dependencies import get_current_user, get_db, require_role
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import User, UserRole

router = APIRouter()


def _get_spec_manager(request: Request, db: Database) -> SpecManager:
    """获取或创建 SpecManager 实例。"""
    config = get_config()
    return SpecManager(specs_dir=config.storage.specs_dir, db=db)


# ==================== 规范文件端点 ====================


@router.get("/files")
async def list_spec_files(
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """列出当前团队的所有规范文件。"""
    manager = _get_spec_manager(request, db)
    specs = manager.list_specs(current_user.team_id)
    return {"specs": specs, "total": len(specs)}


@router.get("/files/{spec_path:path}")
async def get_spec_file(
    spec_path: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """读取规范文件内容。"""
    manager = _get_spec_manager(request, db)
    try:
        return manager.read_spec(spec_path)
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"规范文件未找到：{spec_path}",
        )


class SpecWriteRequest(BaseModel):
    content: str


@router.put("/files/{spec_path:path}")
async def write_spec_file(
    spec_path: str,
    data: SpecWriteRequest,
    request: Request,
    current_user: User = Depends(require_role(UserRole.MAINTAINER)),
    db: Database = Depends(get_db),
):
    """写入或更新规范文件（需要维护者及以上权限）。"""
    manager = _get_spec_manager(request, db)
    result = manager.write_spec(spec_path, data.content, current_user.team_id)
    return result


# ==================== 提案端点 ====================


class ProposalCreateRequest(BaseModel):
    title: str
    description: str | None = None
    target_spec: str
    delta: dict[str, Any]


@router.post("/proposals", status_code=status.HTTP_201_CREATED)
async def create_proposal(
    data: ProposalCreateRequest,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """创建新的规范变更提案。"""
    manager = _get_spec_manager(request, db)
    proposal = await manager.create_proposal(
        title=data.title,
        description=data.description,
        target_spec=data.target_spec,
        delta=data.delta,
        author_id=current_user.id,
        team_id=current_user.team_id,
    )
    return proposal


@router.get("/proposals")
async def list_proposals(
    request: Request,
    proposal_status: str | None = Query(None, alias="status", description="按...筛选 status"),
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """List proposals for the current team."""
    manager = _get_spec_manager(request, db)
    proposals = await manager.list_proposals(
        team_id=current_user.team_id, status=proposal_status
    )
    return {"proposals": proposals, "total": len(proposals)}


@router.get("/proposals/{proposal_id}")
async def get_proposal(
    proposal_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """Get a specific proposal."""
    manager = _get_spec_manager(request, db)
    proposal = await manager.get_proposal(proposal_id)
    if proposal is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Proposal not found",
        )
    return proposal


class 状态UpdateRequest(BaseModel):
    status: str


@router.patch("/proposals/{proposal_id}/status")
async def update_proposal_status(
    proposal_id: str,
    data: 状态UpdateRequest,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Database = Depends(get_db),
):
    """Update proposal status (submit for review, approve, withdraw)."""
    manager = _get_spec_manager(request, db)
    proposal = await manager.get_proposal(proposal_id)
    if proposal is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Proposal not found",
        )

    result = await manager.update_proposal_status(
        proposal_id=proposal_id,
        new_status=data.status,
        reviewer_id=current_user.id if data.status in ("approved", "withdrawn") else None,
    )
    return result


@router.post("/proposals/{proposal_id}/merge")
async def merge_proposal(
    proposal_id: str,
    request: Request,
    current_user: User = Depends(require_role(UserRole.MAINTAINER)),
    db: Database = Depends(get_db),
):
    """Merge a proposal into its target spec (需要维护者权限+)."""
    manager = _get_spec_manager(request, db)

    try:
        result = await manager.merge_proposal(
            proposal_id=proposal_id,
            reviewer_id=current_user.id,
            team_id=current_user.team_id,
        )
        return result
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except FileNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )
