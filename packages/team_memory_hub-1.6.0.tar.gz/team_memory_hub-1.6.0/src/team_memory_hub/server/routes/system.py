"""系统路由：健康检查、设置、策管触发器。"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request

from team_memory_hub.core.curation import CurationManager
from team_memory_hub.server.dependencies import get_current_user, get_db, require_role
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import User, UserRole

router = APIRouter()


@router.get("/health")
async def health_check():
    """基本健康检查。"""
    return {"status": "ok", "version": "1.6.0"}


@router.get("/settings")
async def get_settings(
    request: Request,
    current_user: User = Depends(require_role(UserRole.ADMIN)),
):
    """获取当前服务器设置（仅限管理员）。"""
    config = request.app.state.config
    return {
        "server": {
            "host": config.server.host,
            "port": config.server.port,
            "debug": config.server.debug,
        },
        "database": {
            "path": config.database.path,
        },
        "search": {
            "engine": config.search.engine,
            "semantic_weight": config.search.semantic_weight,
            "keyword_weight": config.search.keyword_weight,
        },
        "consolidation": {
            "enabled": config.consolidation.enabled,
            "cluster_threshold": config.consolidation.cluster_threshold,
            "scan_days": config.consolidation.scan_days,
        },
        "embedding": {
            "provider": config.embedding.provider,
            "model": config.embedding.model,
            "dimensions": config.embedding.dimensions,
        },
    }


@router.post("/curation/run")
async def trigger_curation(
    request: Request,
    current_user: User = Depends(require_role(UserRole.ADMIN)),
    db: Database = Depends(get_db),
):
    """Manually trigger all curation tasks (仅限管理员)."""
    config = request.app.state.config
    manager = CurationManager(db, file_base_dir=config.storage.memories_dir)
    results = await manager.run_all(current_user.team_id)
    return {"status": "completed", "results": results}
