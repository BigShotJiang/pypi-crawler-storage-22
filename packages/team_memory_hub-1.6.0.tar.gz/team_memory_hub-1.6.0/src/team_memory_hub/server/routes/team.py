"""团队管理 API 路由。"""

from __future__ import annotations

import secrets
import string

from fastapi import APIRouter, Depends, HTTPException, Query, status

from team_memory_hub.server.dependencies import get_current_user, get_db, require_role
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import Team, TeamCreate, User, UserRole

router = APIRouter()

_ID_CHARS = string.ascii_lowercase + string.digits


@router.post("", response_model=Team, status_code=status.HTTP_201_CREATED)
async def create_team(
    data: TeamCreate,
    db: Database = Depends(get_db),
):
    """创建新团队（用于引导的公共端点）。"""
    team_id = f"team_{''.join(secrets.choice(_ID_CHARS) for _ in range(8))}"

    existing = await db.fetch_one("SELECT id FROM teams WHERE name = ?", (data.name,))
    if existing:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="团队名称已存在")

    await db.execute(
        "INSERT INTO teams (id, name) VALUES (?, ?)",
        (team_id, data.name),
    )
    await db.commit()

    return Team(id=team_id, name=data.name)


@router.get("", response_model=list[Team])
async def list_teams(
    db: Database = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """列出所有团队（对于非管理员用户过滤为其团队）。"""
    if current_user.role == UserRole.ADMIN:
        rows = await db.fetch_all("SELECT * FROM teams ORDER BY name")
    else:
        rows = await db.fetch_all(
            "SELECT * FROM teams WHERE id = ?", (current_user.team_id,)
        )

    return [
        Team(
            id=r["id"],
            name=r["name"],
            specs_version=r.get("specs_version", 0),
            specs_fingerprint=r.get("specs_fingerprint"),
            created_at=r.get("created_at"),
        )
        for r in rows
    ]


@router.get("/{team_id}", response_model=Team)
async def get_team(
    team_id: str,
    db: Database = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """按 ID 获取团队。"""
    row = await db.fetch_one("SELECT * FROM teams WHERE id = ?", (team_id,))
    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="团队未找到")

    return Team(
        id=row["id"],
        name=row["name"],
        specs_version=row.get("specs_version", 0),
        specs_fingerprint=row.get("specs_fingerprint"),
        created_at=row.get("created_at"),
    )


@router.delete("/{team_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_team(
    team_id: str,
    current_user: User = Depends(require_role(UserRole.ADMIN)),
    db: Database = Depends(get_db),
):
    """删除团队（仅限管理员）。"""
    row = await db.fetch_one("SELECT id FROM teams WHERE id = ?", (team_id,))
    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="团队未找到")

    await db.execute("DELETE FROM teams WHERE id = ?", (team_id,))
    await db.commit()
