"""异步 SQLite 连接管理，支持 WAL 模式和繁忙超时。"""

from __future__ import annotations

import asyncio
from contextlib import suppress
import logging
from pathlib import Path
from typing import Any

import aiosqlite

from team_memory_hub.storage.migrations import v1, v1_5, v1_6

logger = logging.getLogger(__name__)

# 架构版本常量
SCHEMA_VERSION_V1 = 1
SCHEMA_VERSION_V1_5 = 2
SCHEMA_VERSION_V1_6 = 3
CURRENT_SCHEMA_VERSION = SCHEMA_VERSION_V1_6


class Database:
    """异步 SQLite 数据库管理器，支持 WAL 模式和自动迁移。"""

    def __init__(self, db_path: str = ":memory:"):
        self.db_path = db_path
        self._connection: aiosqlite.Connection | None = None

    async def _await_with_heartbeat(self, awaitable):
        """Await an aiosqlite operation while keeping the event loop active.

        In some environments, background-thread callbacks from aiosqlite can stall
        without periodic loop wakeups. A tiny heartbeat task prevents deadlocks.
        """
        async def _heartbeat() -> None:
            while True:
                await asyncio.sleep(0.01)

        hb_task = asyncio.create_task(_heartbeat())
        try:
            return await awaitable
        finally:
            hb_task.cancel()
            with suppress(asyncio.CancelledError):
                await hb_task

    async def initialize(self) -> None:
        """初始化数据库连接并运行迁移。"""
        if self.db_path != ":memory:":
            Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)

        self._connection = await self._await_with_heartbeat(
            aiosqlite.connect(self.db_path)
        )
        self._connection.row_factory = aiosqlite.Row

        # 启用 WAL 模式并设置繁忙超时
        await self._await_with_heartbeat(
            self._connection.execute("PRAGMA journal_mode=WAL")
        )
        await self._await_with_heartbeat(
            self._connection.execute("PRAGMA busy_timeout=10000")
        )
        await self._await_with_heartbeat(
            self._connection.execute("PRAGMA foreign_keys=ON")
        )

        # 运行迁移
        await self._await_with_heartbeat(self._run_migrations())

    async def _run_migrations(self) -> None:
        """检测架构版本并运行必要的迁移。"""
        current_version = await self._get_schema_version()

        if current_version < SCHEMA_VERSION_V1:
            logger.info("Running V1 migration...")
            await v1.migrate(self._connection)
            await self._set_schema_version(SCHEMA_VERSION_V1)
            logger.info("V1 migration completed.")

        if current_version < SCHEMA_VERSION_V1_5:
            logger.info("Running V1.5 migration...")
            await v1_5.migrate(self._connection)
            await self._set_schema_version(SCHEMA_VERSION_V1_5)
            logger.info("V1.5 migration completed.")

        if current_version < SCHEMA_VERSION_V1_6:
            logger.info("Running V1.6 migration...")
            await v1_6.migrate(self._connection)
            await self._set_schema_version(SCHEMA_VERSION_V1_6)
            logger.info("V1.6 migration completed.")

    async def _get_schema_version(self) -> int:
        """从 _meta 表获取当前架构版本。"""
        try:
            cursor = await self._await_with_heartbeat(
                self._connection.execute(
                    "SELECT value FROM _meta WHERE key = 'schema_version'"
                )
            )
            row = await self._await_with_heartbeat(cursor.fetchone())
            return int(row["value"]) if row else 0
        except aiosqlite.OperationalError:
            # _meta 表尚不存在
            return 0

    async def _set_schema_version(self, version: int) -> None:
        """在 _meta 表中设置架构版本。"""
        await self._await_with_heartbeat(
            self._connection.execute(
                """INSERT INTO _meta (key, value) VALUES ('schema_version', ?)
                   ON CONFLICT(key) DO UPDATE SET value = excluded.value""",
                (str(version),),
            )
        )
        await self._await_with_heartbeat(self._connection.commit())

    @property
    def connection(self) -> aiosqlite.Connection:
        """获取活动的数据库连接。"""
        if self._connection is None:
            raise RuntimeError("Database not initialized. Call initialize() first.")
        return self._connection

    async def execute(self, sql: str, params: tuple | dict | None = None) -> aiosqlite.Cursor:
        """执行 SQL 语句。"""
        if params is None:
            return await self._await_with_heartbeat(self.connection.execute(sql))
        return await self._await_with_heartbeat(self.connection.execute(sql, params))

    async def execute_many(self, sql: str, params_list: list[tuple]) -> None:
        """使用多个参数集合执行 SQL 语句。"""
        await self._await_with_heartbeat(self.connection.executemany(sql, params_list))

    async def fetch_one(self, sql: str, params: tuple | dict | None = None) -> dict[str, Any] | None:
        """执行查询并将第一行作为字典返回。"""
        cursor = await self.execute(sql, params)
        row = await self._await_with_heartbeat(cursor.fetchone())
        if row is None:
            return None
        return dict(row)

    async def fetch_all(self, sql: str, params: tuple | dict | None = None) -> list[dict[str, Any]]:
        """执行查询并将所有行作为字典列表返回。"""
        cursor = await self.execute(sql, params)
        rows = await self._await_with_heartbeat(cursor.fetchall())
        return [dict(row) for row in rows]

    async def commit(self) -> None:
        """提交当前事务。"""
        await self._await_with_heartbeat(self.connection.commit())

    async def close(self) -> None:
        """关闭数据库连接。"""
        if self._connection:
            await self._await_with_heartbeat(self._connection.close())
            self._connection = None
