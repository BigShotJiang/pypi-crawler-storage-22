"""V1 模式迁移：完整的初始架构。"""

from __future__ import annotations

import aiosqlite


async def migrate(conn: aiosqlite.Connection) -> None:
    """创建完整的 V1 架构。"""

    # 用于版本跟踪的元表
    await conn.execute("""
        CREATE TABLE IF NOT EXISTS _meta (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
    """)

    # ========== 用户和权限 ==========

    await conn.execute("""
        CREATE TABLE IF NOT EXISTS teams (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL UNIQUE,
            settings TEXT DEFAULT '{}',
            specs_version INTEGER DEFAULT 0,
            specs_fingerprint TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)

    await conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            role TEXT NOT NULL DEFAULT 'member',
            team_id TEXT NOT NULL,
            password_hash TEXT,
            is_active BOOLEAN DEFAULT TRUE,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (team_id) REFERENCES teams(id)
        )
    """)

    await conn.execute("""
        CREATE TABLE IF NOT EXISTS api_keys (
            id TEXT PRIMARY KEY,
            key TEXT NOT NULL UNIQUE,
            user_id TEXT NOT NULL,
            name TEXT NOT NULL,
            scope TEXT NOT NULL DEFAULT 'full_access',
            expires_at DATETIME,
            is_active BOOLEAN DEFAULT TRUE,
            last_used_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    await conn.execute("""
        CREATE TABLE IF NOT EXISTS projects (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            team_id TEXT NOT NULL,
            description TEXT,
            is_active BOOLEAN DEFAULT TRUE,
            project_type TEXT,
            detected_languages TEXT DEFAULT '[]',
            detected_frameworks TEXT DEFAULT '[]',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (team_id) REFERENCES teams(id),
            UNIQUE(name, team_id)
        )
    """)

    await conn.execute("""
        CREATE TABLE IF NOT EXISTS project_members (
            project_id TEXT,
            user_id TEXT,
            joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (project_id, user_id),
            FOREIGN KEY (project_id) REFERENCES projects(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    # ========== Memory Index ==========

    await conn.execute("""
        CREATE TABLE IF NOT EXISTS memories (
            id TEXT PRIMARY KEY,
            summary TEXT NOT NULL,
            file_path TEXT NOT NULL,
            file_hash TEXT,
            file_size_bytes INTEGER,
            owner_id TEXT NOT NULL,
            scope TEXT NOT NULL DEFAULT 'private',
            team_id TEXT NOT NULL,
            project_id TEXT,
            category TEXT DEFAULT 'general',
            tags TEXT DEFAULT '[]',
            layer INTEGER DEFAULT 2,
            quality TEXT DEFAULT 'community',
            quality_score REAL DEFAULT 0.5,
            verified_by TEXT,
            verified_at DATETIME,
            embedding_provider TEXT,
            embedding_model TEXT,
            access_count INTEGER DEFAULT 0,
            last_accessed_at DATETIME,
            source_chat_path TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (owner_id) REFERENCES users(id),
            FOREIGN KEY (team_id) REFERENCES teams(id),
            FOREIGN KEY (project_id) REFERENCES projects(id)
        )
    """)

    await conn.execute("""
        CREATE TABLE IF NOT EXISTS memory_versions (
            id TEXT PRIMARY KEY,
            memory_id TEXT NOT NULL,
            version INTEGER NOT NULL,
            summary TEXT NOT NULL,
            file_path TEXT,
            changed_by TEXT NOT NULL,
            change_type TEXT NOT NULL,
            diff_json TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE
        )
    """)

    # ========== Spec Proposals ==========

    await conn.execute("""
        CREATE TABLE IF NOT EXISTS spec_proposals (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            description TEXT,
            target_spec TEXT NOT NULL,
            delta_path TEXT NOT NULL,
            status TEXT DEFAULT 'draft',
            author_id TEXT NOT NULL,
            reviewer_id TEXT,
            team_id TEXT NOT NULL,
            merged_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (author_id) REFERENCES users(id),
            FOREIGN KEY (team_id) REFERENCES teams(id)
        )
    """)

    await conn.execute("""
        CREATE TABLE IF NOT EXISTS spec_applicability (
            id TEXT PRIMARY KEY,
            spec_path TEXT NOT NULL,
            team_id TEXT NOT NULL,
            condition_type TEXT NOT NULL,
            condition_value TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (team_id) REFERENCES teams(id),
            UNIQUE(spec_path, team_id, condition_type, condition_value)
        )
    """)

    # ========== User Preferences ==========

    await conn.execute("""
        CREATE TABLE IF NOT EXISTS user_preferences (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            category TEXT NOT NULL,
            key TEXT NOT NULL,
            value TEXT NOT NULL,
            metadata TEXT DEFAULT '{}',
            scope TEXT DEFAULT 'global',
            is_active BOOLEAN DEFAULT TRUE,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            UNIQUE(user_id, category, key, scope)
        )
    """)

    await conn.execute("""
        CREATE TABLE IF NOT EXISTS team_default_preferences (
            id TEXT PRIMARY KEY,
            team_id TEXT NOT NULL,
            category TEXT NOT NULL,
            key TEXT NOT NULL,
            value TEXT NOT NULL,
            metadata TEXT DEFAULT '{}',
            set_by TEXT NOT NULL,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (team_id) REFERENCES teams(id),
            UNIQUE(team_id, category, key)
        )
    """)

    await conn.execute("""
        CREATE TABLE IF NOT EXISTS preference_suggestions (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            category TEXT NOT NULL,
            key TEXT NOT NULL,
            value TEXT NOT NULL,
            evidence TEXT,
            source_chat TEXT,
            status TEXT DEFAULT 'pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    # ========== Chat Sessions ==========

    await conn.execute("""
        CREATE TABLE IF NOT EXISTS chat_sessions (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            tool TEXT NOT NULL,
            tool_version TEXT,
            project_id TEXT,
            file_path TEXT NOT NULL,
            turn_count INTEGER DEFAULT 0,
            started_at DATETIME,
            ended_at DATETIME,
            memories_extracted INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    # ========== Audit Logs ==========

    await conn.execute("""
        CREATE TABLE IF NOT EXISTS audit_logs (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            action TEXT NOT NULL,
            target_type TEXT,
            target_id TEXT,
            details TEXT,
            ip_address TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    # ========== Indexes ==========

    await conn.execute("CREATE INDEX IF NOT EXISTS idx_mem_scope ON memories(scope, team_id)")
    await conn.execute("CREATE INDEX IF NOT EXISTS idx_mem_owner ON memories(owner_id, scope)")
    await conn.execute("CREATE INDEX IF NOT EXISTS idx_mem_layer ON memories(layer, team_id)")
    await conn.execute("CREATE INDEX IF NOT EXISTS idx_mem_quality ON memories(quality, team_id)")
    await conn.execute("CREATE INDEX IF NOT EXISTS idx_mem_project ON memories(project_id, scope)")
    await conn.execute("CREATE INDEX IF NOT EXISTS idx_mem_hash ON memories(file_hash)")
    await conn.execute("CREATE INDEX IF NOT EXISTS idx_mem_updated ON memories(updated_at DESC)")
    await conn.execute("CREATE INDEX IF NOT EXISTS idx_mem_source ON memories(source_chat_path)")
    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_ver_mid ON memory_versions(memory_id, version DESC)"
    )
    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_key_user ON api_keys(user_id, is_active)"
    )
    await conn.execute("CREATE INDEX IF NOT EXISTS idx_key_key ON api_keys(key)")
    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_pref_user ON user_preferences(user_id, is_active)"
    )
    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_pref_scope ON user_preferences(user_id, scope, is_active)"
    )
    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_tpref ON team_default_preferences(team_id)"
    )
    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_psug ON preference_suggestions(user_id, status)"
    )
    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_chat_user ON chat_sessions(user_id, created_at DESC)"
    )
    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_chat_tool ON chat_sessions(tool, user_id)"
    )
    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_prop_team ON spec_proposals(team_id, status)"
    )
    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_prop_author ON spec_proposals(author_id)"
    )
    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_spec_app ON spec_applicability(team_id, condition_type)"
    )
    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_logs(user_id, created_at DESC)"
    )
    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at)"
    )

    await conn.commit()
