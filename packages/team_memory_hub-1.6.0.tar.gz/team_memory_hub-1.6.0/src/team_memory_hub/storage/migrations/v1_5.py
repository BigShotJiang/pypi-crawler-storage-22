"""V1.5 模式迁移：FTS5、合并建议、merged_into 字段。"""

from __future__ import annotations

import aiosqlite


async def migrate(conn: aiosqlite.Connection) -> None:
    """应用 V1.5 架构更改。"""

    # Add merged_into column to memories table
    try:
        await conn.execute("ALTER TABLE memories ADD COLUMN merged_into TEXT")
    except aiosqlite.OperationalError:
        pass  # Column already exists

    # Create merged_into index
    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_mem_merged ON memories(merged_into)"
    )

    # ========== 合并建议 ==========

    await conn.execute("""
        CREATE TABLE IF NOT EXISTS merge_suggestions (
            id TEXT PRIMARY KEY,
            team_id TEXT NOT NULL,
            original_ids TEXT NOT NULL,
            merged_content TEXT NOT NULL,
            merged_tags TEXT DEFAULT '[]',
            merged_category TEXT,
            scope TEXT NOT NULL,
            avg_similarity REAL NOT NULL,
            confidence REAL NOT NULL,
            status TEXT DEFAULT 'pending',
            reviewed_by TEXT,
            reviewed_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (team_id) REFERENCES teams(id)
        )
    """)

    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_msug_team ON merge_suggestions(team_id, status)"
    )
    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_msug_created ON merge_suggestions(created_at DESC)"
    )

    # ========== FTS5 全文搜索 ==========

    # Check if FTS5 table already exists
    cursor = await conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='memories_fts'"
    )
    if not await cursor.fetchone():
        await conn.execute("""
            CREATE VIRTUAL TABLE memories_fts USING fts5(
                summary,
                tags,
                content='memories',
                content_rowid='rowid',
                tokenize='unicode61 remove_diacritics 2'
            )
        """)

        # Sync triggers: auto-update FTS5 when memories table changes
        await conn.execute("""
            CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
                INSERT INTO memories_fts(rowid, summary, tags)
                VALUES (new.rowid, new.summary, REPLACE(REPLACE(new.tags, '[', ''), ']', ''));
            END
        """)

        await conn.execute("""
            CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories BEGIN
                INSERT INTO memories_fts(memories_fts, rowid, summary, tags)
                VALUES ('delete', old.rowid, old.summary, REPLACE(REPLACE(old.tags, '[', ''), ']', ''));
            END
        """)

        await conn.execute("""
            CREATE TRIGGER IF NOT EXISTS memories_au AFTER UPDATE ON memories BEGIN
                INSERT INTO memories_fts(memories_fts, rowid, summary, tags)
                VALUES ('delete', old.rowid, old.summary, REPLACE(REPLACE(old.tags, '[', ''), ']', ''));
                INSERT INTO memories_fts(rowid, summary, tags)
                VALUES (new.rowid, new.summary, REPLACE(REPLACE(new.tags, '[', ''), ']', ''));
            END
        """)

        # Populate FTS5 from existing data
        await conn.execute("""
            INSERT INTO memories_fts(rowid, summary, tags)
            SELECT rowid, summary, REPLACE(REPLACE(tags, '[', ''), ']', '')
            FROM memories
        """)

    await conn.commit()
