"""V1.6 模式迁移：权限覆盖表。"""

from __future__ import annotations

import aiosqlite


async def migrate(conn: aiosqlite.Connection) -> None:
    """应用 V1.6 架构更改：新增 permission_overrides 表。"""

    await conn.execute("""
        CREATE TABLE IF NOT EXISTS permission_overrides (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            permission TEXT NOT NULL,
            type TEXT NOT NULL CHECK(type IN ('allow', 'deny')),
            granted_by TEXT NOT NULL,
            reason TEXT,
            expires_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (granted_by) REFERENCES users(id),
            UNIQUE(user_id, permission)
        )
    """)

    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_perm_override_user ON permission_overrides(user_id)"
    )
    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_perm_override_expires ON permission_overrides(expires_at)"
    )

    await conn.commit()
