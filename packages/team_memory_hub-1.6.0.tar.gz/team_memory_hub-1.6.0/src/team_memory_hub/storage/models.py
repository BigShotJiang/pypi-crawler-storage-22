"""所有实体的 Pydantic 数据模型。"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


# ========== 枚举 ==========

class UserRole(str, Enum):
    ADMIN = "admin"
    MAINTAINER = "maintainer"
    MEMBER = "member"
    VIEWER = "viewer"


class Memory范围(str, Enum):
    PRIVATE = "private"
    PROJECT = "project"
    TEAM = "team"


class Memory类别(str, Enum):
    GENERAL = "general"
    DECISION = "decision"
    EXPERIENCE = "experience"
    BUG_FIX = "bug_fix"
    ARCHITECTURE = "architecture"
    CODING_STANDARD = "coding_standard"
    WORKFLOW = "workflow"


class 质量状态(str, Enum):
    COMMUNITY = "community"
    VERIFIED = "verified"
    PINNED = "pinned"
    STALE = "stale"
    ARCHIVED = "archived"


class ApiKey范围(str, Enum):
    FULL_ACCESS = "full_access"
    MCP_ONLY = "mcp_only"
    READ_ONLY = "read_only"
    SYNC_ONLY = "sync_only"
    INGEST_ONLY = "ingest_only"


class PermissionOverrideType(str, Enum):
    ALLOW = "allow"
    DENY = "deny"


class Proposal状态(str, Enum):
    DRAFT = "draft"
    PENDING_REVIEW = "pending_review"
    APPROVED = "approved"
    MERGED = "merged"
    WITHDRAWN = "withdrawn"


class MergeSuggestion状态(str, Enum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    DISMISSED = "dismissed"


# ========== 团队 ==========

class TeamBase(BaseModel):
    name: str


class TeamCreate(TeamBase):
    pass


class Team(TeamBase):
    id: str
    settings: dict[str, Any] = Field(default_factory=dict)
    specs_version: int = 0
    specs_fingerprint: str | None = None
    created_at: datetime | None = None


# ========== 用户 ==========

class UserBase(BaseModel):
    name: str
    email: str


class UserCreate(UserBase):
    password: str
    role: UserRole = UserRole.MEMBER
    team_id: str


class UserUpdate(BaseModel):
    name: str | None = None
    email: str | None = None
    role: UserRole | None = None
    is_active: bool | None = None


class User(UserBase):
    id: str
    role: UserRole = UserRole.MEMBER
    team_id: str
    is_active: bool = True
    created_at: datetime | None = None


class UserInDB(User):
    password_hash: str | None = None


# ========== 认证 ==========

class TokenRequest(BaseModel):
    email: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int


class RefreshRequest(BaseModel):
    refresh_token: str


# ========== API 密钥 ==========

class ApiKeyCreate(BaseModel):
    name: str
    scope: ApiKey范围 = ApiKey范围.FULL_ACCESS
    expires_at: datetime | None = None


class ApiKeyResponse(BaseModel):
    id: str
    key: str  # 仅在创建时返回
    name: str
    scope: ApiKey范围
    expires_at: datetime | None = None
    is_active: bool = True
    last_used_at: datetime | None = None
    created_at: datetime | None = None


class ApiKeyInfo(BaseModel):
    id: str
    name: str
    scope: ApiKey范围
    expires_at: datetime | None = None
    is_active: bool = True
    last_used_at: datetime | None = None
    created_at: datetime | None = None


# ========== 记忆 ==========

class MemoryCreate(BaseModel):
    content: str
    summary: str | None = None
    scope: Memory范围 = Memory范围.PRIVATE
    category: Memory类别 = Memory类别.GENERAL
    tags: list[str] = Field(default_factory=list)
    project_id: str | None = None
    layer: int = 2


class MemoryUpdate(BaseModel):
    content: str | None = None
    summary: str | None = None
    scope: Memory范围 | None = None
    category: Memory类别 | None = None
    tags: list[str] | None = None
    project_id: str | None = None


class Memory(BaseModel):
    id: str
    summary: str
    file_path: str
    file_hash: str | None = None
    file_size_bytes: int | None = None
    owner_id: str
    scope: Memory范围 = Memory范围.PRIVATE
    team_id: str
    project_id: str | None = None
    category: Memory类别 = Memory类别.GENERAL
    tags: list[str] = Field(default_factory=list)
    layer: int = 2
    quality: 质量状态 = 质量状态.COMMUNITY
    quality_score: float = 0.5
    verified_by: str | None = None
    verified_at: datetime | None = None
    access_count: int = 0
    last_accessed_at: datetime | None = None
    merged_into: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class MemoryDetail(Memory):
    content: str


class MemoryListResponse(BaseModel):
    items: list[Memory]
    total: int
    page: int = 1
    page_size: int = 20


# ========== 质量 ==========

class 质量Update(BaseModel):
    quality: 质量状态


# ========== 记忆版本 ==========

class MemoryVersion(BaseModel):
    id: str
    memory_id: str
    version: int
    summary: str
    file_path: str | None = None
    changed_by: str
    change_type: str
    diff_json: str | None = None
    created_at: datetime | None = None


# ========== 项目 ==========

class ProjectCreate(BaseModel):
    name: str
    description: str | None = None
    project_type: str | None = None


class Project(BaseModel):
    id: str
    name: str
    team_id: str
    description: str | None = None
    is_active: bool = True
    project_type: str | None = None
    detected_languages: list[str] = Field(default_factory=list)
    detected_frameworks: list[str] = Field(default_factory=list)
    created_at: datetime | None = None


# ========== 合并建议 (V1.5) ==========

class MergeSuggestion(BaseModel):
    id: str
    team_id: str
    original_ids: list[str]
    merged_content: str
    merged_tags: list[str] = Field(default_factory=list)
    merged_category: str | None = None
    scope: Memory范围
    avg_similarity: float
    confidence: float
    status: MergeSuggestion状态 = MergeSuggestion状态.PENDING
    reviewed_by: str | None = None
    reviewed_at: datetime | None = None
    created_at: datetime | None = None


# ========== 权限覆盖 (V1.6) ==========

class PermissionOverrideCreate(BaseModel):
    user_id: str
    permission: str
    type: PermissionOverrideType
    reason: str | None = None
    expires_at: datetime | None = None


class PermissionOverride(BaseModel):
    id: str
    user_id: str
    permission: str
    type: PermissionOverrideType
    granted_by: str
    reason: str | None = None
    expires_at: datetime | None = None
    created_at: datetime | None = None
