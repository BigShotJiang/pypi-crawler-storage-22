"""Shared test fixtures: test database, test client, test users."""

from __future__ import annotations

import os
import tempfile
from typing import AsyncGenerator

import pytest
import pytest_asyncio
from fastapi.testclient import TestClient
from httpx import ASGITransport, AsyncClient

from team_memory_hub.config import TMHConfig, AuthConfig, DatabaseConfig, ServerConfig, StorageConfig, set_config
from team_memory_hub.server.routes.auth import create_access_token, hash_password
from team_memory_hub.storage.database import Database


@pytest.fixture(scope="session")
def tmp_data_dir():
    """Create a temporary directory for test data files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest_asyncio.fixture
async def db() -> AsyncGenerator[Database, None]:
    """Create an in-memory test database."""
    database = Database(":memory:")
    await database.initialize()
    yield database
    await database.close()


@pytest_asyncio.fixture
async def seeded_db(db: Database, test_config) -> Database:
    """Database pre-seeded with test team and users."""
    # Create team
    await db.execute(
        "INSERT INTO teams (id, name) VALUES (?, ?)",
        ("team_test", "Test Team"),
    )

    # Create admin user
    await db.execute(
        """INSERT INTO users (id, name, email, role, team_id, password_hash)
           VALUES (?, ?, ?, ?, ?, ?)""",
        ("usr_admin", "Admin", "admin@test.com", "admin", "team_test",
         hash_password("password123")),
    )

    # Create maintainer user
    await db.execute(
        """INSERT INTO users (id, name, email, role, team_id, password_hash)
           VALUES (?, ?, ?, ?, ?, ?)""",
        ("usr_maint", "Maintainer", "maintainer@test.com", "maintainer", "team_test",
         hash_password("password123")),
    )

    # Create member user
    await db.execute(
        """INSERT INTO users (id, name, email, role, team_id, password_hash)
           VALUES (?, ?, ?, ?, ?, ?)""",
        ("usr_member", "Member", "member@test.com", "member", "team_test",
         hash_password("password123")),
    )

    # Create viewer user
    await db.execute(
        """INSERT INTO users (id, name, email, role, team_id, password_hash)
           VALUES (?, ?, ?, ?, ?, ?)""",
        ("usr_viewer", "Viewer", "viewer@test.com", "viewer", "team_test",
         hash_password("password123")),
    )

    # Create a second team and user for isolation tests
    await db.execute(
        "INSERT INTO teams (id, name) VALUES (?, ?)",
        ("team_other", "Other Team"),
    )
    await db.execute(
        """INSERT INTO users (id, name, email, role, team_id, password_hash)
           VALUES (?, ?, ?, ?, ?, ?)""",
        ("usr_other", "Other", "other@test.com", "member", "team_other",
         hash_password("password123")),
    )

    await db.commit()
    return db


@pytest.fixture
def test_config(tmp_data_dir: str) -> TMHConfig:
    """Create a test configuration."""
    config = TMHConfig(
        server=ServerConfig(data_dir=tmp_data_dir),
        auth=AuthConfig(jwt_secret="test-secret-key-for-testing"),
        database=DatabaseConfig(path=":memory:"),
        storage=StorageConfig(
            memories_dir=os.path.join(tmp_data_dir, "memories"),
            specs_dir=os.path.join(tmp_data_dir, "specs"),
            chats_dir=os.path.join(tmp_data_dir, "chats"),
        ),
    )
    set_config(config)
    return config


def make_token(user_id: str, email: str, role: str, team_id: str) -> str:
    """Create a test JWT token."""
    return create_access_token({
        "sub": user_id,
        "email": email,
        "role": role,
        "team_id": team_id,
    })


@pytest.fixture
def admin_token(test_config: TMHConfig) -> str:
    return make_token("usr_admin", "admin@test.com", "admin", "team_test")


@pytest.fixture
def maintainer_token(test_config: TMHConfig) -> str:
    return make_token("usr_maint", "maintainer@test.com", "maintainer", "team_test")


@pytest.fixture
def member_token(test_config: TMHConfig) -> str:
    return make_token("usr_member", "member@test.com", "member", "team_test")


@pytest.fixture
def viewer_token(test_config: TMHConfig) -> str:
    return make_token("usr_viewer", "viewer@test.com", "viewer", "team_test")


@pytest.fixture
def other_team_token(test_config: TMHConfig) -> str:
    return make_token("usr_other", "other@test.com", "member", "team_other")


def auth_header(token: str) -> dict[str, str]:
    """Create authorization header dict."""
    return {"Authorization": f"Bearer {token}"}
