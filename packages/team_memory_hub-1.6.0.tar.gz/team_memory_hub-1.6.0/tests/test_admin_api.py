"""管理 API 端点集成测试。"""

from __future__ import annotations

import pytest
from httpx import ASGITransport, AsyncClient

from team_memory_hub.server.app import create_app
from team_memory_hub.storage.database import Database


@pytest.fixture
async def app_and_db():
    """创建测试应用并初始化内存数据库。"""
    app = create_app()
    db = Database(":memory:")
    await db.initialize()
    app.state.db = db

    # 插入测试数据
    await db.execute(
        "INSERT INTO teams (id, name) VALUES (?, ?)",
        ("team_test", "Test Team"),
    )
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id, password_hash) VALUES (?, ?, ?, ?, ?, ?)",
        ("usr_admin", "Admin", "admin@test.com", "admin", "team_test", "fakehash"),
    )
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id, password_hash) VALUES (?, ?, ?, ?, ?, ?)",
        ("usr_member", "Member", "member@test.com", "member", "team_test", "fakehash"),
    )
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id, password_hash) VALUES (?, ?, ?, ?, ?, ?)",
        ("usr_viewer", "Viewer", "viewer@test.com", "viewer", "team_test", "fakehash"),
    )
    await db.commit()

    yield app, db
    await db.close()


@pytest.fixture
async def admin_client(app_and_db):
    """以 admin 身份认证的测试客户端。"""
    app, db = app_and_db
    # 创建 API Key
    import secrets
    key = "tmh_" + secrets.token_hex(24)
    await db.execute(
        "INSERT INTO api_keys (id, key, user_id, name, scope) VALUES (?, ?, ?, ?, ?)",
        ("key_admin", key, "usr_admin", "Admin Key", "full_access"),
    )
    await db.commit()

    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
        headers={"Authorization": f"Bearer {key}"},
    ) as client:
        yield client


@pytest.fixture
async def member_client(app_and_db):
    """以 member 身份认证的测试客户端。"""
    app, db = app_and_db
    import secrets
    key = "tmh_" + secrets.token_hex(24)
    await db.execute(
        "INSERT INTO api_keys (id, key, user_id, name, scope) VALUES (?, ?, ?, ?, ?)",
        ("key_member", key, "usr_member", "Member Key", "full_access"),
    )
    await db.commit()

    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
        headers={"Authorization": f"Bearer {key}"},
    ) as client:
        yield client


# ========== Teams CRUD ==========

class TestTeamsAdmin:
    @pytest.mark.asyncio
    async def test_list_teams(self, admin_client):
        resp = await admin_client.get("/api/v1/admin/teams")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] >= 1
        assert len(data["items"]) >= 1

    @pytest.mark.asyncio
    async def test_create_team(self, admin_client):
        resp = await admin_client.post("/api/v1/admin/teams", json={"name": "New Team"})
        assert resp.status_code == 201
        assert resp.json()["name"] == "New Team"

    @pytest.mark.asyncio
    async def test_create_duplicate_team(self, admin_client):
        resp = await admin_client.post("/api/v1/admin/teams", json={"name": "Test Team"})
        assert resp.status_code == 400

    @pytest.mark.asyncio
    async def test_update_team(self, admin_client):
        resp = await admin_client.put("/api/v1/admin/teams/team_test", json={"name": "Updated Team"})
        assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_delete_team_blocked_by_users(self, admin_client):
        resp = await admin_client.delete("/api/v1/admin/teams/team_test")
        assert resp.status_code == 400  # 有活跃用户

    @pytest.mark.asyncio
    async def test_member_cannot_create_team(self, member_client):
        resp = await member_client.post("/api/v1/admin/teams", json={"name": "Forbidden"})
        assert resp.status_code == 403


# ========== Projects CRUD ==========

class TestProjectsAdmin:
    @pytest.mark.asyncio
    async def test_create_and_list_projects(self, admin_client):
        resp = await admin_client.post("/api/v1/admin/projects", json={
            "name": "Test Project", "team_id": "team_test",
        })
        assert resp.status_code == 201

        resp = await admin_client.get("/api/v1/admin/projects")
        assert resp.status_code == 200
        assert resp.json()["total"] >= 1

    @pytest.mark.asyncio
    async def test_delete_project_soft(self, admin_client):
        # 先创建
        resp = await admin_client.post("/api/v1/admin/projects", json={
            "name": "To Delete", "team_id": "team_test",
        })
        pid = resp.json()["id"]

        resp = await admin_client.delete(f"/api/v1/admin/projects/{pid}")
        assert resp.status_code == 204


# ========== Users CRUD ==========

class TestUsersAdmin:
    @pytest.mark.asyncio
    async def test_list_users(self, admin_client):
        resp = await admin_client.get("/api/v1/admin/users")
        assert resp.status_code == 200
        assert resp.json()["total"] >= 3

    @pytest.mark.asyncio
    async def test_create_user(self, admin_client):
        resp = await admin_client.post("/api/v1/admin/users", json={
            "name": "New User", "email": "new@test.com",
            "password": "secret123", "team_id": "team_test",
        })
        assert resp.status_code == 201

    @pytest.mark.asyncio
    async def test_cannot_delete_self(self, admin_client):
        resp = await admin_client.delete("/api/v1/admin/users/usr_admin")
        assert resp.status_code == 400

    @pytest.mark.asyncio
    async def test_toggle_active(self, admin_client):
        resp = await admin_client.patch("/api/v1/admin/users/usr_viewer/toggle-active")
        assert resp.status_code == 200
        assert resp.json()["is_active"] is False

    @pytest.mark.asyncio
    async def test_update_role(self, admin_client):
        resp = await admin_client.patch("/api/v1/admin/users/usr_member/role", json={"role": "maintainer"})
        assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_member_cannot_list_users(self, member_client):
        resp = await member_client.get("/api/v1/admin/users")
        assert resp.status_code == 403


# ========== System ==========

class TestSystemAdmin:
    @pytest.mark.asyncio
    async def test_get_config(self, admin_client):
        resp = await admin_client.get("/api/v1/admin/system/config")
        assert resp.status_code == 200
        assert "sections" in resp.json()

    @pytest.mark.asyncio
    async def test_get_stats(self, admin_client):
        resp = await admin_client.get("/api/v1/admin/system/stats")
        assert resp.status_code == 200
        data = resp.json()
        assert "memories" in data
        assert "users" in data

    @pytest.mark.asyncio
    async def test_update_config_readonly_rejected(self, admin_client):
        resp = await admin_client.patch("/api/v1/admin/system/config", json={
            "updates": {"server.host": "evil.com"},
        })
        assert resp.status_code == 200
        assert "server.host" in resp.json()["errors"]

    @pytest.mark.asyncio
    async def test_update_config_editable(self, admin_client):
        resp = await admin_client.patch("/api/v1/admin/system/config", json={
            "updates": {"logging.level": "DEBUG"},
        })
        assert resp.status_code == 200
        assert "logging.level" in resp.json()["updated"]
