"""管理 Dashboard 页面端到端测试。"""

from __future__ import annotations

import secrets
from datetime import datetime, timedelta, timezone

import pytest
from httpx import ASGITransport, AsyncClient

from team_memory_hub.server.app import create_app
from team_memory_hub.storage.database import Database


@pytest.fixture
async def app_and_db():
    """创建测试应用并初始化内存数据库。"""
    app = create_app()
    db = Database(":memory:")
    await db.initialize()
    app.state.db = db

    await db.execute("INSERT INTO teams (id, name) VALUES (?, ?)", ("team_test", "Test Team"))
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id, password_hash) VALUES (?, ?, ?, ?, ?, ?)",
        ("usr_admin", "Admin", "admin@test.com", "admin", "team_test", "fakehash"),
    )
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id, password_hash) VALUES (?, ?, ?, ?, ?, ?)",
        ("usr_viewer", "Viewer", "viewer@test.com", "viewer", "team_test", "fakehash"),
    )
    await db.execute(
        "INSERT INTO projects (id, name, team_id) VALUES (?, ?, ?)",
        ("proj_test", "Test Project", "team_test"),
    )
    await db.commit()
    yield app, db
    await db.close()


@pytest.fixture
async def admin_client(app_and_db):
    app, db = app_and_db
    key = "tmh_" + secrets.token_hex(24)
    await db.execute(
        "INSERT INTO api_keys (id, key, user_id, name, scope) VALUES (?, ?, ?, ?, ?)",
        ("key_admin", key, "usr_admin", "Admin Key", "full_access"),
    )
    await db.commit()
    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
        headers={"Authorization": f"Bearer {key}"},
    ) as client:
        yield client


@pytest.fixture
async def viewer_client(app_and_db):
    app, db = app_and_db
    key = "tmh_" + secrets.token_hex(24)
    await db.execute(
        "INSERT INTO api_keys (id, key, user_id, name, scope) VALUES (?, ?, ?, ?, ?)",
        ("key_viewer", key, "usr_viewer", "Viewer Key", "full_access"),
    )
    await db.commit()
    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
        headers={"Authorization": f"Bearer {key}"},
    ) as client:
        yield client


# ========== CRUD 操作流 ==========

class TestAdminCRUDFlow:
    @pytest.mark.asyncio
    async def test_full_team_lifecycle(self, admin_client):
        # 创建
        resp = await admin_client.post("/api/v1/admin/teams", json={"name": "Lifecycle Team"})
        assert resp.status_code == 201
        team_id = resp.json()["id"]

        # 读取
        resp = await admin_client.get(f"/api/v1/admin/teams/{team_id}")
        assert resp.status_code == 200
        assert resp.json()["name"] == "Lifecycle Team"

        # 更新
        resp = await admin_client.put(f"/api/v1/admin/teams/{team_id}", json={"name": "Updated Team"})
        assert resp.status_code == 200

        # 删除（无活跃成员/项目）
        resp = await admin_client.delete(f"/api/v1/admin/teams/{team_id}")
        assert resp.status_code == 204

    @pytest.mark.asyncio
    async def test_full_project_lifecycle(self, admin_client):
        resp = await admin_client.post("/api/v1/admin/projects", json={
            "name": "Lifecycle Project", "team_id": "team_test",
        })
        assert resp.status_code == 201
        pid = resp.json()["id"]

        resp = await admin_client.put(f"/api/v1/admin/projects/{pid}", json={"description": "Updated"})
        assert resp.status_code == 200

        resp = await admin_client.delete(f"/api/v1/admin/projects/{pid}")
        assert resp.status_code == 204

    @pytest.mark.asyncio
    async def test_full_user_lifecycle(self, admin_client):
        resp = await admin_client.post("/api/v1/admin/users", json={
            "name": "New User", "email": "lifecycle@test.com",
            "password": "pass123", "team_id": "team_test",
        })
        assert resp.status_code == 201
        uid = resp.json()["id"]

        # 修改角色
        resp = await admin_client.patch(f"/api/v1/admin/users/{uid}/role", json={"role": "maintainer"})
        assert resp.status_code == 200

        # 禁用
        resp = await admin_client.patch(f"/api/v1/admin/users/{uid}/toggle-active")
        assert resp.status_code == 200
        assert resp.json()["is_active"] is False

        # 启用
        resp = await admin_client.patch(f"/api/v1/admin/users/{uid}/toggle-active")
        assert resp.json()["is_active"] is True


# ========== 权限拦截 ==========

class TestPermissionBlocking:
    @pytest.mark.asyncio
    async def test_viewer_blocked_from_teams(self, viewer_client):
        resp = await viewer_client.get("/api/v1/admin/teams")
        assert resp.status_code == 403

    @pytest.mark.asyncio
    async def test_viewer_blocked_from_users(self, viewer_client):
        resp = await viewer_client.get("/api/v1/admin/users")
        assert resp.status_code == 403

    @pytest.mark.asyncio
    async def test_viewer_blocked_from_system(self, viewer_client):
        resp = await viewer_client.get("/api/v1/admin/system/config")
        assert resp.status_code == 403

    @pytest.mark.asyncio
    async def test_viewer_blocked_from_api_keys(self, viewer_client):
        resp = await viewer_client.get("/api/v1/admin/api-keys")
        assert resp.status_code == 403


# ========== 边界条件 ==========

class TestEdgeCases:
    @pytest.mark.asyncio
    async def test_get_nonexistent_team(self, admin_client):
        resp = await admin_client.get("/api/v1/admin/teams/nonexistent")
        assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_create_project_invalid_team(self, admin_client):
        resp = await admin_client.post("/api/v1/admin/projects", json={
            "name": "Bad Project", "team_id": "nonexistent",
        })
        assert resp.status_code == 400

    @pytest.mark.asyncio
    async def test_create_user_duplicate_email(self, admin_client):
        resp = await admin_client.post("/api/v1/admin/users", json={
            "name": "Dup", "email": "admin@test.com",
            "password": "pass", "team_id": "team_test",
        })
        assert resp.status_code == 400
