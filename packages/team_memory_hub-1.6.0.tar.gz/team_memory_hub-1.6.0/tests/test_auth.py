"""测试身份验证和授权。"""

from __future__ import annotations

import pytest

from team_memory_hub.core.rbac import (
    can_access_memory,
    can_delete_memory,
    can_modify_memory,
    check_permission,
    has_minimum_role,
)
from team_memory_hub.server.routes.auth import (
    create_access_token,
    create_refresh_token,
    decode_token,
    hash_password,
    verify_password,
)
from team_memory_hub.storage.database import Database


# ========== Password Hashing Tests ==========


class TestPasswordHashing:
    def test_hash_and_verify(self, test_config):
        hashed = hash_password("mysecret")
        assert verify_password("mysecret", hashed)
        assert not verify_password("wrongpassword", hashed)

    def test_different_hashes(self, test_config):
        """每个哈希应是唯一的（由于盐）。"""
        h1 = hash_password("same")
        h2 = hash_password("same")
        assert h1 != h2  # Different salts
        assert verify_password("same", h1)
        assert verify_password("same", h2)


# ========== JWT Token Tests ==========


class TestJWTTokens:
    def test_access_token_roundtrip(self, test_config):
        """Access token should encode and decode correctly."""
        data = {"sub": "usr_1", "email": "test@t.com", "role": "member", "team_id": "t1"}
        token = create_access_token(data)
        payload = decode_token(token)

        assert payload["sub"] == "usr_1"
        assert payload["email"] == "test@t.com"
        assert payload["type"] == "access"

    def test_refresh_token_type(self, test_config):
        """Refresh token should have type='refresh'."""
        data = {"sub": "usr_1"}
        token = create_refresh_token(data)
        payload = decode_token(token)
        assert payload["type"] == "refresh"

    def test_invalid_token_raises(self, test_config):
        """令牌无效 should raise HTTPException."""
        from fastapi import HTTPException
        with pytest.raises(HTTPException) as exc_info:
            decode_token("invalid.token.here")
        assert exc_info.value.status_code == 401


# ========== RBAC Tests ==========


class TestRBAC:
    """Test role-based access control."""

    def test_role_hierarchy(self):
        """Admin > Maintainer > Member > Viewer."""
        assert has_minimum_role("admin", "admin")
        assert has_minimum_role("admin", "viewer")
        assert has_minimum_role("maintainer", "maintainer")
        assert has_minimum_role("maintainer", "member")
        assert has_minimum_role("member", "member")
        assert has_minimum_role("member", "viewer")
        assert has_minimum_role("viewer", "viewer")

        assert not has_minimum_role("viewer", "member")
        assert not has_minimum_role("member", "maintainer")
        assert not has_minimum_role("maintainer", "admin")

    def test_permissions(self):
        """Check permission matrix."""
        # Admin can do everything
        assert check_permission("admin", "memory:write_team")
        assert check_permission("admin", "memory:delete_any")
        assert check_permission("admin", "user:manage")

        # Maintainer can verify and manage specs
        assert check_permission("maintainer", "memory:verify")
        assert check_permission("maintainer", "spec:merge_proposal")
        assert not check_permission("maintainer", "user:manage")

        # Member can write but not verify
        assert check_permission("member", "memory:write_team")
        assert check_permission("member", "spec:create_proposal")
        assert not check_permission("member", "memory:verify")

        # Viewer can only read
        assert not check_permission("viewer", "memory:write_team")
        assert not check_permission("viewer", "spec:create_proposal")


# ========== Memory Access Control Tests ==========


class TestMemoryAccessControl:
    """Test private data isolation and access control."""

    def test_private_memory_owner_access(self):
        """Owner can access their private memory."""
        assert can_access_memory(
            user_id="usr_1", user_role="member", user_team_id="t1",
            memory_owner_id="usr_1", memory_scope="private", memory_team_id="t1",
        )

    def test_private_memory_other_user_denied(self):
        """Other users cannot access private memory."""
        assert not can_access_memory(
            user_id="usr_2", user_role="admin", user_team_id="t1",
            memory_owner_id="usr_1", memory_scope="private", memory_team_id="t1",
        )

    def test_team_memory_same_team(self):
        """Same team members can access team memory."""
        assert can_access_memory(
            user_id="usr_2", user_role="viewer", user_team_id="t1",
            memory_owner_id="usr_1", memory_scope="team", memory_team_id="t1",
        )

    def test_team_memory_different_team(self):
        """Different team members cannot access team memory."""
        assert not can_access_memory(
            user_id="usr_2", user_role="admin", user_team_id="t2",
            memory_owner_id="usr_1", memory_scope="team", memory_team_id="t1",
        )

    def test_modify_own_memory(self):
        """Owner can modify their own team memory."""
        assert can_modify_memory(
            user_id="usr_1", user_role="member", user_team_id="t1",
            memory_owner_id="usr_1", memory_scope="team", memory_team_id="t1",
        )

    def test_modify_others_memory_maintainer(self):
        """Maintainer can modify other's team memory."""
        assert can_modify_memory(
            user_id="usr_2", user_role="maintainer", user_team_id="t1",
            memory_owner_id="usr_1", memory_scope="team", memory_team_id="t1",
        )

    def test_modify_others_memory_member_denied(self):
        """Member cannot modify other's team memory."""
        assert not can_modify_memory(
            user_id="usr_2", user_role="member", user_team_id="t1",
            memory_owner_id="usr_1", memory_scope="team", memory_team_id="t1",
        )

    def test_delete_others_memory_admin(self):
        """Admin can delete other's memory."""
        assert can_delete_memory(
            user_id="usr_2", user_role="admin", user_team_id="t1",
            memory_owner_id="usr_1", memory_scope="team", memory_team_id="t1",
        )

    def test_delete_others_memory_member_denied(self):
        """Member cannot delete other's team memory."""
        assert not can_delete_memory(
            user_id="usr_2", user_role="member", user_team_id="t1",
            memory_owner_id="usr_1", memory_scope="team", memory_team_id="t1",
        )

    def test_private_modify_owner_only(self):
        """Only owner can modify private memory."""
        assert can_modify_memory(
            user_id="usr_1", user_role="member", user_team_id="t1",
            memory_owner_id="usr_1", memory_scope="private", memory_team_id="t1",
        )
        assert not can_modify_memory(
            user_id="usr_2", user_role="admin", user_team_id="t1",
            memory_owner_id="usr_1", memory_scope="private", memory_team_id="t1",
        )


# ========== Auth with Database Tests ==========


class TestAuthWithDB:
    """Test authentication flows with database."""

    @pytest.mark.asyncio
    async def test_login_success(self, seeded_db: Database, test_config):
        """Login with valid credentials should return tokens."""
        row = await seeded_db.fetch_one(
            "SELECT * FROM users WHERE email = ?", ("admin@test.com",)
        )
        assert row is not None
        assert verify_password("password123", row["password_hash"])

    @pytest.mark.asyncio
    async def test_login_wrong_password(self, seeded_db: Database, test_config):
        """Login with wrong password should fail."""
        row = await seeded_db.fetch_one(
            "SELECT * FROM users WHERE email = ?", ("admin@test.com",)
        )
        assert not verify_password("wrongpassword", row["password_hash"])

    @pytest.mark.asyncio
    async def test_api_key_creation(self, seeded_db: Database, test_config):
        """API key should be stored and retrievable."""
        from team_memory_hub.server.routes.keys import generate_api_key

        key_value = generate_api_key()
        assert key_value.startswith("tmh_")
        assert len(key_value) > 20

        await seeded_db.execute(
            """INSERT INTO api_keys (id, key, user_id, name, scope)
               VALUES (?, ?, ?, ?, ?)""",
            ("key_1", key_value, "usr_admin", "Test Key", "full_access"),
        )
        await seeded_db.commit()

        row = await seeded_db.fetch_one(
            "SELECT * FROM api_keys WHERE key = ?", (key_value,)
        )
        assert row is not None
        assert row["scope"] == "full_access"
