"""测试聊天捕获：适配器、摄入、提取。"""

from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime

import pytest
import pytest_asyncio

from team_memory_hub.chat_adapters.base import ChatAdapter, ChatMessage
from team_memory_hub.chat_adapters.claude_code import ClaudeCodeAdapter
from team_memory_hub.chat_adapters.cursor import CursorAdapter
from team_memory_hub.chat_adapters.opencode import OpenCodeAdapter
from team_memory_hub.chat_adapters.chatbox import ChatboxAdapter
from team_memory_hub.chat_adapters.codex import CodexAdapter
from team_memory_hub.core.chat_ingest import ChatIngestor, get_adapter
from team_memory_hub.core.memory_extractor import ExtractedMemory, MemoryExtractor
from team_memory_hub.storage.database import Database


# ========== Adapter Tests ==========

class TestClaudeCodeAdapter:
    def test_convert_basic(self):
        adapter = ClaudeCodeAdapter()
        raw = {
            "messages": [
                {"role": "user", "content": "Hello", "timestamp": "2025-01-01T00:00:00"},
                {"role": "assistant", "content": "Hi there!", "timestamp": "2025-01-01T00:00:01"},
            ],
            "session_id": "sess_123",
            "model": "claude-3",
        }
        messages = adapter.convert(raw)
        assert len(messages) == 2
        assert messages[0].role == "user"
        assert messages[0].content == "Hello"
        assert messages[1].role == "assistant"

    def test_convert_content_blocks(self):
        adapter = ClaudeCodeAdapter()
        raw = {
            "messages": [
                {"role": "assistant", "content": [
                    {"type": "text", "text": "First part"},
                    {"type": "text", "text": "Second part"},
                ]},
            ],
        }
        messages = adapter.convert(raw)
        assert len(messages) == 1
        assert "First part" in messages[0].content
        assert "Second part" in messages[0].content

    def test_empty_messages(self):
        adapter = ClaudeCodeAdapter()
        messages = adapter.convert({"messages": []})
        assert messages == []

    def test_session_metadata(self):
        adapter = ClaudeCodeAdapter()
        meta = adapter.get_session_metadata({
            "model": "claude-3", "session_id": "s1", "project": "my-proj",
        })
        assert meta["tool"] == "claude-code"
        assert meta["model"] == "claude-3"


class TestCursorAdapter:
    def test_convert_conversation_format(self):
        adapter = CursorAdapter()
        raw = {
            "conversation": [
                {"type": "human", "text": "Fix the bug"},
                {"type": "ai", "text": "I'll fix it"},
            ],
        }
        messages = adapter.convert(raw)
        assert len(messages) == 2
        assert messages[0].role == "user"
        assert messages[1].role == "assistant"

    def test_convert_messages_format(self):
        adapter = CursorAdapter()
        raw = {
            "messages": [
                {"role": "user", "content": "Hello"},
                {"role": "assistant", "content": "Hi"},
            ],
        }
        messages = adapter.convert(raw)
        assert len(messages) == 2

    def test_timestamp_millis(self):
        adapter = CursorAdapter()
        raw = {
            "conversation": [
                {"type": "human", "text": "test", "timestamp": 1704067200000},
            ],
        }
        messages = adapter.convert(raw)
        assert messages[0].timestamp is not None


class TestOpenCodeAdapter:
    def test_convert(self):
        adapter = OpenCodeAdapter()
        raw = {
            "messages": [
                {"role": "user", "content": "Build a feature", "created_at": "2025-01-01T00:00:00"},
                {"role": "assistant", "content": "Done!"},
            ],
            "model": "gpt-4",
        }
        messages = adapter.convert(raw)
        assert len(messages) == 2
        assert messages[0].timestamp is not None
        assert messages[1].timestamp is None


class TestChatboxAdapter:
    def test_convert(self):
        adapter = ChatboxAdapter()
        raw = {
            "messages": [
                {"role": "user", "content": "What is Python?", "createdAt": 1704067200},
                {"role": "assistant", "content": "Python is a language."},
            ],
        }
        messages = adapter.convert(raw)
        assert len(messages) == 2
        assert messages[0].timestamp is not None


class TestCodexAdapter:
    def test_convert_standard(self):
        adapter = CodexAdapter()
        raw = {
            "messages": [
                {"role": "user", "content": "Hello"},
                {"role": "assistant", "content": "Hi"},
            ],
            "model": "gpt-4",
        }
        messages = adapter.convert(raw)
        assert len(messages) == 2

    def test_convert_chatgpt_export(self):
        adapter = CodexAdapter()
        raw = {
            "mapping": {
                "node1": {
                    "message": {
                        "author": {"role": "user"},
                        "content": {"parts": ["Hello world"]},
                        "create_time": 1704067200,
                    },
                },
                "node2": {
                    "message": {
                        "author": {"role": "assistant"},
                        "content": {"parts": ["Hi there!"]},
                        "create_time": 1704067201,
                        "metadata": {"model_slug": "gpt-4"},
                    },
                },
            },
        }
        messages = adapter.convert(raw)
        assert len(messages) == 2
        assert messages[0].role == "user"
        assert messages[1].role == "assistant"

    def test_skip_system_messages(self):
        adapter = CodexAdapter()
        raw = {
            "mapping": {
                "node1": {
                    "message": {
                        "author": {"role": "system"},
                        "content": {"parts": ["You are an AI"]},
                    },
                },
            },
        }
        messages = adapter.convert(raw)
        assert len(messages) == 0


# ========== Adapter Registry Tests ==========

class TestAdapterRegistry:
    def test_get_known_adapters(self):
        for tool in ["claude-code", "cursor", "opencode", "chatbox", "codex"]:
            adapter = get_adapter(tool)
            assert adapter.tool_name == tool

    def test_unknown_adapter(self):
        with pytest.raises(ValueError, match="Unknown tool"):
            get_adapter("unknown-tool")


# ========== ChatIngestor Tests ==========

class TestChatIngestor:
    @pytest_asyncio.fixture
    async def ingestor(self):
        db = Database(":memory:")
        await db.initialize()
        with tempfile.TemporaryDirectory() as tmpdir:
            ingestor = ChatIngestor(db, tmpdir)
            yield ingestor
            await db.close()

    @pytest.mark.asyncio
    async def test_ingest_session(self, ingestor):
        # Create a test user
        await ingestor.db.execute(
            "INSERT INTO teams (id, name) VALUES ('t1', 'Test')"
        )
        await ingestor.db.execute(
            "INSERT INTO users (id, name, email, team_id) VALUES ('u1', 'User', 'u@t.com', 't1')"
        )
        await ingestor.db.commit()

        raw = {
            "messages": [
                {"role": "user", "content": "Hello"},
                {"role": "assistant", "content": "Hi"},
            ],
        }

        result = await ingestor.ingest("claude-code", raw, "u1")

        assert result["status"] == "ingested"
        assert result["turn_count"] == 2
        assert result["session_id"] is not None

    @pytest.mark.asyncio
    async def test_ingest_empty(self, ingestor):
        result = await ingestor.ingest("claude-code", {"messages": []}, "u1")
        assert result["status"] == "empty"

    @pytest.mark.asyncio
    async def test_list_sessions(self, ingestor):
        await ingestor.db.execute(
            "INSERT INTO teams (id, name) VALUES ('t1', 'Test')"
        )
        await ingestor.db.execute(
            "INSERT INTO users (id, name, email, team_id) VALUES ('u1', 'User', 'u@t.com', 't1')"
        )
        await ingestor.db.commit()

        # Ingest two sessions
        await ingestor.ingest("claude-code", {
            "messages": [{"role": "user", "content": "A"}]
        }, "u1")
        await ingestor.ingest("cursor", {
            "conversation": [{"type": "human", "text": "B"}]
        }, "u1")

        sessions, total = await ingestor.list_sessions("u1")
        assert total == 2

        # 按...筛选 tool
        sessions, total = await ingestor.list_sessions("u1", tool="claude-code")
        assert total == 1


# ========== MemoryExtractor Tests ==========

class TestMemoryExtractor:
    def test_extract_decision(self):
        messages = [
            ChatMessage(role="user", content="What database should we use?"),
            ChatMessage(
                role="assistant",
                content="We decided to use PostgreSQL for the main database because it offers "
                "better JSON support and ACID compliance. The decision was made after "
                "comparing it with MongoDB and MySQL. PostgreSQL also provides better "
                "extension support through plugins.",
            ),
        ]

        extractor = MemoryExtractor()
        # Use sync wrapper
        import asyncio
        extracted = asyncio.get_event_loop().run_until_complete(
            extractor.extract(messages)
        )

        assert len(extracted) >= 1
        assert any(e.category == "decision" for e in extracted)

    def test_extract_bug_fix(self):
        messages = [
            ChatMessage(role="user", content="The app keeps crashing"),
            ChatMessage(
                role="assistant",
                content="The bug was caused by a null pointer exception in the auth module. "
                "The root cause was that the user session object wasn't being initialized "
                "properly when the JWT token expired. Fixed by adding a null check before "
                "accessing the session properties.",
            ),
        ]

        extractor = MemoryExtractor()
        import asyncio
        extracted = asyncio.get_event_loop().run_until_complete(
            extractor.extract(messages)
        )

        assert len(extracted) >= 1
        assert any(e.category == "bug_fix" for e in extracted)

    def test_extract_nothing_from_short(self):
        messages = [
            ChatMessage(role="assistant", content="OK"),
        ]

        extractor = MemoryExtractor()
        import asyncio
        extracted = asyncio.get_event_loop().run_until_complete(
            extractor.extract(messages)
        )

        assert len(extracted) == 0

    def test_skip_user_messages(self):
        messages = [
            ChatMessage(
                role="user",
                content="We always use snake_case for Python naming convention. "
                "This is our standard coding practice that everyone should follow.",
            ),
        ]

        extractor = MemoryExtractor()
        import asyncio
        extracted = asyncio.get_event_loop().run_until_complete(
            extractor.extract(messages)
        )

        # Should not extract from user messages
        assert len(extracted) == 0

    def test_confidence_scoring(self):
        messages = [
            ChatMessage(
                role="assistant",
                content="The team decided to always use TypeScript strict mode for all new "
                "projects. This is a standard requirement and must be followed. "
                "```json\n{\"strict\": true}\n```\n"
                "This guideline should never be bypassed.",
            ),
        ]

        extractor = MemoryExtractor()
        import asyncio
        extracted = asyncio.get_event_loop().run_until_complete(
            extractor.extract(messages)
        )

        if extracted:
            # Higher confidence for definitive language + code example
            assert extracted[0].confidence >= 0.3

    def test_tag_extraction(self):
        messages = [
            ChatMessage(
                role="assistant",
                content="For Python API development with Docker, always ensure your "
                "database migrations are tested before deployment. This is important "
                "for maintaining data integrity in the CI/CD pipeline.",
            ),
        ]

        extractor = MemoryExtractor()
        import asyncio
        extracted = asyncio.get_event_loop().run_until_complete(
            extractor.extract(messages)
        )

        if extracted:
            tags_flat = []
            for e in extracted:
                tags_flat.extend(e.tags)
            # Should detect some tech keywords
            assert len(tags_flat) >= 0  # May or may not detect tags
