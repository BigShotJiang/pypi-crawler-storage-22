"""Tests for TMH CLI commands."""

from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


class TestCLIInit:
    def test_init_detects_project(self, tmp_path: Path):
        """tmh init detects project profile."""
        # Create a Python project structure
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "test-project"\n\n[tool.ruff]\nline-length = 100\n'
        )
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "main.py").write_text("print('hello')")

        from team_memory_hub.cli import cmd_init

        args = MagicMock()
        args.directory = str(tmp_path)
        args.tool = None
        args.server = "http://localhost:8000"

        cmd_init(args)

        # Check .tmh directory created
        assert (tmp_path / ".tmh").is_dir()
        assert (tmp_path / ".tmh" / "project_profile.json").exists()
        assert (tmp_path / ".tmh" / "config.json").exists()

        # Verify profile content
        profile = json.loads((tmp_path / ".tmh" / "project_profile.json").read_text())
        assert "python" in profile["languages"]

    def test_init_with_tool(self, tmp_path: Path):
        """tmh init with tool creates hooks."""
        (tmp_path / "pyproject.toml").write_text('[project]\nname = "test"\n')

        from team_memory_hub.cli import cmd_init

        args = MagicMock()
        args.directory = str(tmp_path)
        args.tool = "claude-code"
        args.server = "http://localhost:8000"

        cmd_init(args)

        # Check tool-specific files
        assert (tmp_path / ".tmh" / "hooks" / "post_session.py").exists()


class TestCLISpecs:
    def test_specs_detect(self, tmp_path: Path, capsys):
        """tmh specs detect outputs profile JSON."""
        (tmp_path / "package.json").write_text(json.dumps({
            "name": "js-project",
            "dependencies": {"react": "^18.0.0"},
        }))

        from team_memory_hub.cli import cmd_specs

        args = MagicMock()
        args.action = "detect"
        args.directory = str(tmp_path)

        cmd_specs(args)

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert "javascript" in data["languages"]
        assert "react" in data["frameworks"]

    def test_specs_normalize(self, tmp_path: Path, capsys):
        """tmh specs normalize outputs rules."""
        (tmp_path / ".editorconfig").write_text(
            "root = true\n\n[*]\nindent_style = space\nindent_size = 4\n"
        )

        from team_memory_hub.cli import cmd_specs

        args = MagicMock()
        args.action = "normalize"
        args.directory = str(tmp_path)

        cmd_specs(args)

        captured = capsys.readouterr()
        assert "indent_style" in captured.out
        assert "indent_size" in captured.out

    def test_specs_compare(self, tmp_path: Path, capsys):
        """tmh specs compare shows summary."""
        (tmp_path / ".editorconfig").write_text(
            "root = true\n\n[*]\nindent_size = 4\n"
        )

        from team_memory_hub.cli import cmd_specs

        args = MagicMock()
        args.action = "compare"
        args.directory = str(tmp_path)

        cmd_specs(args)

        captured = capsys.readouterr()
        assert "Summary" in captured.out


class TestCLIParser:
    def test_parser_no_command(self):
        """No command shows help and exits."""
        from team_memory_hub.cli import main

        with pytest.raises(SystemExit) as exc_info:
            with patch("sys.argv", ["tmh"]):
                main()
        assert exc_info.value.code == 1

    def test_parser_store_requires_content(self):
        """Store command requires --content."""
        from team_memory_hub.cli import main

        with pytest.raises(SystemExit):
            with patch("sys.argv", ["tmh", "store"]):
                main()

    def test_parser_search_requires_query(self):
        """Search command requires query argument."""
        from team_memory_hub.cli import main

        with pytest.raises(SystemExit):
            with patch("sys.argv", ["tmh", "search"]):
                main()


class TestCLIAgentsGenerator:
    def test_generate_agents_md(self):
        """Test AGENTS.md generation."""
        from team_memory_hub.core.agents_generator import AgentsGenerator

        generator = AgentsGenerator(
            memories=[
                {"summary": "Use type hints", "category": "coding_standard", "tags": ["python"]},
                {"summary": "Use PostgreSQL", "category": "decision"},
                {"summary": "Check nulls in auth", "category": "bug_fix"},
            ],
        )

        content = generator.generate_agents_md()

        assert "# AGENTS.md" in content
        assert "Coding Standards" in content
        assert "Use type hints" in content
        assert "Architecture Decisions" in content
        assert "Lessons Learned" in content

    def test_generate_claude_md(self):
        """Test CLAUDE.md generation."""
        from team_memory_hub.core.agents_generator import AgentsGenerator
        from team_memory_hub.core.project_detector import ProjectProfile

        profile = ProjectProfile(
            root_path="/test",
            name="my-project",
            languages=["python", "typescript"],
            frameworks=["fastapi", "react"],
        )

        generator = AgentsGenerator(
            memories=[
                {"summary": "Standard rule", "category": "coding_standard"},
            ],
            profile=profile,
        )

        content = generator.generate_claude_md()

        assert "CLAUDE.md" in content
        assert "python" in content
        assert "Standard rule" in content

    def test_write_to_project(self, tmp_path: Path):
        """Test writing generated files to project."""
        from team_memory_hub.core.agents_generator import AgentsGenerator

        generator = AgentsGenerator(memories=[
            {"summary": "Test rule", "category": "coding_standard"},
        ])

        written = generator.write_to_project(
            tmp_path,
            formats=["agents_md", "claude_md", "cursorrules"],
        )

        assert len(written) == 3
        assert (tmp_path / "AGENTS.md").exists()
        assert (tmp_path / "CLAUDE.md").exists()
        assert (tmp_path / ".cursorrules").exists()
