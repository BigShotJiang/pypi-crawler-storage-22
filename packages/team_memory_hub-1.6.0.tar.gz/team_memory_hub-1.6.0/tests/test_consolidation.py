"""测试记忆整合：合并候选项、建议、执行。"""

from __future__ import annotations

import json

import pytest
import pytest_asyncio

from team_memory_hub.core.memory_consolidator import MemoryConsolidator
from team_memory_hub.storage.database import Database


@pytest_asyncio.fixture
async def consolidation_db() -> Database:
    """为整合创建包含测试记忆的数据库。"""
    db = Database(":memory:")
    await db.initialize()

    # Create team
    await db.execute("INSERT INTO teams (id, name) VALUES (?, ?)", ("team_1", "Test Team"))

    # Create user
    await db.execute(
        """INSERT INTO users (id, name, email, role, team_id, password_hash)
           VALUES (?, ?, ?, ?, ?, ?)""",
        ("usr_1", "Tester", "test@test.com", "admin", "team_1", "hash"),
    )

    # Create similar memories (should be merge candidates)
    for i, summary in enumerate([
        "How to configure Docker containers for microservices deployment",
        "How to configure Docker containers for microservices deployment guide",
        "Python best practices for error handling",
        "Unique memory about database migrations",
    ]):
        await db.execute(
            """INSERT INTO memories
               (id, summary, file_path, owner_id, scope, team_id, category, tags, quality)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (f"mem_{i}", summary, f"test/{i}.md", "usr_1", "team", "team_1",
             "general", "[]", "community"),
        )

    await db.commit()
    yield db
    await db.close()


class TestMemoryConsolidator:

    @pytest.mark.asyncio
    async def test_detect_merge_candidates(self, consolidation_db: Database):
        """应检测高度相似的记忆作为合并候选项。"""
        consolidator = MemoryConsolidator(consolidation_db)
        candidates = await consolidator.detect_merge_candidates(
            team_id="team_1",
            threshold=0.7,  # Lower threshold for test data
        )

        # The first two memories are very similar
        assert len(candidates) >= 1
        found_ids = set()
        for c in candidates:
            found_ids.update(c["ids"])
        assert "mem_0" in found_ids or "mem_1" in found_ids

    @pytest.mark.asyncio
    async def test_detect_no_candidates_high_threshold(self, consolidation_db: Database):
        """高阈值应对不相似的记忆产生零候选项。"""
        consolidator = MemoryConsolidator(consolidation_db)
        candidates = await consolidator.detect_merge_candidates(
            team_id="team_1",
            threshold=0.99,
        )
        assert len(candidates) == 0

    @pytest.mark.asyncio
    async def test_generate_merge_suggestion(self, consolidation_db: Database):
        """应在数据库中创建合并建议。"""
        consolidator = MemoryConsolidator(consolidation_db)
        suggestion = await consolidator.generate_merge_suggestion(
            team_id="team_1",
            memory_ids=["mem_0", "mem_1"],
            similarity=0.9,
        )

        assert suggestion.id.startswith("msug_")
        assert suggestion.team_id == "team_1"
        assert len(suggestion.original_ids) == 2
        assert suggestion.status == "pending"
        assert suggestion.avg_similarity == 0.9

    @pytest.mark.asyncio
    async def test_execute_merge(self, consolidation_db: Database):
        """应创建新记忆、存档原始记忆并更新建议状态。"""
        consolidator = MemoryConsolidator(consolidation_db)

        # Create suggestion first
        suggestion = await consolidator.generate_merge_suggestion(
            team_id="team_1",
            memory_ids=["mem_0", "mem_1"],
            similarity=0.9,
        )

        # 执行合并
        new_id = await consolidator.execute_merge(suggestion.id, "usr_1")
        assert new_id is not None
        assert new_id.startswith("mem_")

        # Verify originals are archived
        row0 = await consolidation_db.fetch_one("SELECT * FROM memories WHERE id = 'mem_0'")
        assert row0["quality"] == "archived"
        assert row0["merged_into"] == new_id

        row1 = await consolidation_db.fetch_one("SELECT * FROM memories WHERE id = 'mem_1'")
        assert row1["quality"] == "archived"

        # Verify suggestion status updated
        sug_row = await consolidation_db.fetch_one(
            "SELECT * FROM merge_suggestions WHERE id = ?", (suggestion.id,)
        )
        assert sug_row["status"] == "accepted"

    @pytest.mark.asyncio
    async def test_reject_suggestion(self, consolidation_db: Database):
        consolidator = MemoryConsolidator(consolidation_db)
        suggestion = await consolidator.generate_merge_suggestion(
            team_id="team_1", memory_ids=["mem_0", "mem_1"], similarity=0.9,
        )

        success = await consolidator.reject_suggestion(suggestion.id, "usr_1")
        assert success

        sug_row = await consolidation_db.fetch_one(
            "SELECT * FROM merge_suggestions WHERE id = ?", (suggestion.id,)
        )
        assert sug_row["status"] == "rejected"

    @pytest.mark.asyncio
    async def test_dismiss_suggestion(self, consolidation_db: Database):
        consolidator = MemoryConsolidator(consolidation_db)
        suggestion = await consolidator.generate_merge_suggestion(
            team_id="team_1", memory_ids=["mem_0", "mem_1"], similarity=0.9,
        )

        success = await consolidator.dismiss_suggestion(suggestion.id, "usr_1")
        assert success

    @pytest.mark.asyncio
    async def test_get_suggestions(self, consolidation_db: Database):
        consolidator = MemoryConsolidator(consolidation_db)

        # Create two suggestions
        await consolidator.generate_merge_suggestion(
            team_id="team_1", memory_ids=["mem_0", "mem_1"], similarity=0.9,
        )
        await consolidator.generate_merge_suggestion(
            team_id="team_1", memory_ids=["mem_2", "mem_3"], similarity=0.8,
        )

        suggestions, total = await consolidator.get_suggestions("team_1")
        assert total == 2
        assert len(suggestions) == 2

        # 按...筛选 status
        pending, pending_total = await consolidator.get_suggestions("team_1", status="pending")
        assert pending_total == 2

    @pytest.mark.asyncio
    async def test_get_stats(self, consolidation_db: Database):
        consolidator = MemoryConsolidator(consolidation_db)

        await consolidator.generate_merge_suggestion(
            team_id="team_1", memory_ids=["mem_0", "mem_1"], similarity=0.9,
        )

        stats = await consolidator.get_stats("team_1")
        assert stats["total"] >= 1
        assert stats.get("pending", 0) >= 1

    @pytest.mark.asyncio
    async def test_text_similarity(self):
        """测试 Jaccard 相似度计算。"""
        sim = MemoryConsolidator._text_similarity(
            "docker containers deployment guide",
            "docker containers deployment tutorial",
        )
        assert sim > 0.5

        sim_empty = MemoryConsolidator._text_similarity("", "test")
        assert sim_empty == 0.0
