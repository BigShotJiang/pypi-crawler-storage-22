"""测试上下文引擎和上下文缓存。"""

from __future__ import annotations

import time
from datetime import datetime, timedelta
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio

from team_memory_hub.core.context_cache import ContextCache
from team_memory_hub.core.context_engine import ContextEngine, ContextResponse
from team_memory_hub.core.search_engine import HybridSearchEngine, SearchResult
from team_memory_hub.providers.embedding.base import EmbeddingProvider
from team_memory_hub.storage.database import Database


# ==================== Cache Tests ====================


class TestContextCache:
    def test_set_and_get(self):
        cache = ContextCache()
        cache.set("key1", {"data": "value"}, ttl_seconds=60)
        result = cache.get("key1")
        assert result == {"data": "value"}

    def test_expired_entry(self):
        cache = ContextCache()
        cache.set("key1", "value", ttl_seconds=0)
        # 条目应立即过期（或很快）
        time.sleep(0.01)
        result = cache.get("key1")
        assert result is None

    def test_missing_key(self):
        cache = ContextCache()
        result = cache.get("nonexistent")
        assert result is None

    def test_invalidate(self):
        cache = ContextCache()
        cache.set("key1", "value", ttl_seconds=60)
        removed = cache.invalidate("key1")
        assert removed is True
        assert cache.get("key1") is None

    def test_invalidate_nonexistent(self):
        cache = ContextCache()
        removed = cache.invalidate("nonexistent")
        assert removed is False

    def test_invalidate_prefix(self):
        cache = ContextCache()
        cache.set("layer0:team1", "data1", ttl_seconds=60)
        cache.set("layer0:team2", "data2", ttl_seconds=60)
        cache.set("layer1:team1", "data3", ttl_seconds=60)

        count = cache.invalidate_prefix("layer0:")
        assert count == 2
        assert cache.get("layer0:team1") is None
        assert cache.get("layer0:team2") is None
        assert cache.get("layer1:team1") is not None

    def test_clear(self):
        cache = ContextCache()
        cache.set("a", 1, ttl_seconds=60)
        cache.set("b", 2, ttl_seconds=60)
        cache.clear()
        assert cache.size == 0

    def test_max_entries_eviction(self):
        cache = ContextCache(max_entries=3)
        cache.set("a", 1, ttl_seconds=60)
        cache.set("b", 2, ttl_seconds=60)
        cache.set("c", 3, ttl_seconds=60)
        cache.set("d", 4, ttl_seconds=60)  # Should evict one
        assert cache.size <= 3


# ==================== Context Engine 夹具 ====================


class MockEmbeddingProvider(EmbeddingProvider):
    async def embed(self, texts: list[str]) -> list[list[float]]:
        return [[0.1] * 384 for _ in texts]


@pytest_asyncio.fixture
async def db() -> Database:
    database = Database(":memory:")
    await database.initialize()
    yield database
    await database.close()


@pytest_asyncio.fixture
async def seeded_db(db: Database) -> Database:
    """DB with test data for context engine tests."""
    await db.execute(
        "INSERT INTO teams (id, name) VALUES (?, ?)",
        ("team_test", "Test Team"),
    )
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id) VALUES (?, ?, ?, ?, ?)",
        ("usr_1", "User1", "u1@test.com", "member", "team_test"),
    )
    await db.execute(
        "INSERT INTO projects (id, name, team_id) VALUES (?, ?, ?)",
        ("proj_1", "TestProject", "team_test"),
    )

    now = datetime.utcnow()

    # Layer 0: pinned/verified team memories
    await db.execute(
        """INSERT INTO memories
           (id, summary, file_path, owner_id, scope, team_id,
            category, tags, quality, created_at, updated_at)
           VALUES (?, ?, 'test.md', ?, ?, ?, ?, ?, ?, ?, ?)""",
        ("mem_pinned", "Team coding standards", "usr_1", "team", "team_test",
         "coding_standard", '["standards"]', "pinned",
         now.isoformat(), now.isoformat()),
    )
    await db.execute(
        """INSERT INTO memories
           (id, summary, file_path, owner_id, scope, team_id,
            category, tags, quality, created_at, updated_at)
           VALUES (?, ?, 'test.md', ?, ?, ?, ?, ?, ?, ?, ?)""",
        ("mem_verified", "API design principles", "usr_1", "team", "team_test",
         "architecture", '["api"]', "verified",
         now.isoformat(), now.isoformat()),
    )

    # Layer 1: project-specific memories
    await db.execute(
        """INSERT INTO memories
           (id, summary, file_path, owner_id, scope, team_id, project_id,
            category, tags, quality, created_at, updated_at)
           VALUES (?, ?, 'test.md', ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        ("mem_proj", "Project setup guide", "usr_1", "project", "team_test", "proj_1",
         "workflow", '["setup"]', "community",
         now.isoformat(), now.isoformat()),
    )

    # Layer 2: regular memories for search
    await db.execute(
        """INSERT INTO memories
           (id, summary, file_path, owner_id, scope, team_id,
            category, tags, quality, created_at, updated_at)
           VALUES (?, ?, 'test.md', ?, ?, ?, ?, ?, ?, ?, ?)""",
        ("mem_regular", "Python debugging techniques", "usr_1", "team", "team_test",
         "experience", '["python","debug"]', "community",
         now.isoformat(), now.isoformat()),
    )

    await db.commit()
    return db


@pytest.fixture
def context_engine(seeded_db: Database) -> ContextEngine:
    provider = MockEmbeddingProvider()
    search_engine = HybridSearchEngine(
        db=seeded_db,
        embedding_provider=provider,
    )
    search_engine._vec_available = False
    cache = ContextCache()
    return ContextEngine(db=seeded_db, search_engine=search_engine, cache=cache)


# ==================== Context Engine Tests ====================


class TestContextEngine:
    @pytest.mark.asyncio
    async def test_build_layer0(self, context_engine: ContextEngine):
        """Layer 0 should contain pinned and verified memories."""
        ctx = await context_engine.build_context(
            team_id="team_test",
            include_layers=[0],
        )
        assert len(ctx.layers) == 1
        assert ctx.layers[0].layer == 0
        assert ctx.layers[0].name == "team_standards"
        # Should have pinned and verified items
        ids = [item["id"] for item in ctx.layers[0].items]
        assert "mem_pinned" in ids
        assert "mem_verified" in ids

    @pytest.mark.asyncio
    async def test_build_layer1(self, context_engine: ContextEngine):
        """Layer 1 should contain project-specific memories."""
        ctx = await context_engine.build_context(
            team_id="team_test",
            project_id="proj_1",
            include_layers=[1],
        )
        assert len(ctx.layers) == 1
        assert ctx.layers[0].layer == 1
        assert ctx.layers[0].name == "project_context"
        ids = [item["id"] for item in ctx.layers[0].items]
        assert "mem_proj" in ids

    @pytest.mark.asyncio
    async def test_layer1_requires_project(self, context_engine: ContextEngine):
        """Layer 1 should be empty without project_id."""
        ctx = await context_engine.build_context(
            team_id="team_test",
            include_layers=[1],
        )
        # No project_id -> no layer 1
        assert len(ctx.layers) == 0

    @pytest.mark.asyncio
    async def test_build_layer2_with_query(self, context_engine: ContextEngine):
        """Layer 2 should contain search results."""
        ctx = await context_engine.build_context(
            team_id="team_test",
            user_id="usr_1",
            query="Python debugging",
            include_layers=[2],
        )
        assert len(ctx.layers) == 1
        assert ctx.layers[0].layer == 2
        assert ctx.layers[0].name == "session_relevant"

    @pytest.mark.asyncio
    async def test_layer2_requires_query(self, context_engine: ContextEngine):
        """Layer 2 should be empty without a query."""
        ctx = await context_engine.build_context(
            team_id="team_test",
            include_layers=[2],
        )
        assert len(ctx.layers) == 0

    @pytest.mark.asyncio
    async def test_all_layers(self, context_engine: ContextEngine):
        """Full context with all layers."""
        ctx = await context_engine.build_context(
            team_id="team_test",
            user_id="usr_1",
            project_id="proj_1",
            query="coding standards",
        )
        assert len(ctx.layers) == 3
        layer_numbers = [l.layer for l in ctx.layers]
        assert 0 in layer_numbers
        assert 1 in layer_numbers
        assert 2 in layer_numbers

    @pytest.mark.asyncio
    async def test_token_estimate(self, context_engine: ContextEngine):
        """Total token estimate should be positive."""
        ctx = await context_engine.build_context(
            team_id="team_test",
            include_layers=[0],
        )
        assert ctx.total_token_estimate >= 0

    @pytest.mark.asyncio
    async def test_layer0_caching(self, context_engine: ContextEngine):
        """Layer 0 should be cached after first call."""
        await context_engine.build_context(
            team_id="team_test",
            include_layers=[0],
        )
        # Second call should use cache
        cached = context_engine.cache.get("layer0:team_test")
        assert cached is not None

    @pytest.mark.asyncio
    async def test_context_response_to_dict(self, context_engine: ContextEngine):
        ctx = await context_engine.build_context(
            team_id="team_test",
            include_layers=[0],
        )
        d = ctx.to_dict()
        assert "layers" in d
        assert "total_token_estimate" in d
        assert "cache_hit" in d
