"""测试策管任务：重复项、陈旧性、质量评分、文件完整性。"""

from __future__ import annotations

import os
import tempfile
from datetime import datetime, timedelta

import pytest
import pytest_asyncio

from team_memory_hub.core.curation import CurationManager
from team_memory_hub.storage.database import Database


@pytest_asyncio.fixture
async def curation_db() -> Database:
    """为策管测试创建包含测试数据的数据库。"""
    db = Database(":memory:")
    await db.initialize()

    await db.execute("INSERT INTO teams (id, name) VALUES (?, ?)", ("team_1", "Test Team"))
    await db.execute(
        """INSERT INTO users (id, name, email, role, team_id, password_hash)
           VALUES (?, ?, ?, ?, ?, ?)""",
        ("usr_1", "Tester", "test@test.com", "admin", "team_1", "hash"),
    )

    now = datetime.utcnow()

    # Memory 0 and 1: near-duplicates
    await db.execute(
        """INSERT INTO memories
           (id, summary, file_path, owner_id, scope, team_id, category, tags,
            quality, quality_score, access_count, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        ("mem_0", "setting up docker containers", "test/0.md", "usr_1", "team", "team_1",
         "general", "[]", "community", 0.5, 5, now.isoformat(), now.isoformat()),
    )
    await db.execute(
        """INSERT INTO memories
           (id, summary, file_path, owner_id, scope, team_id, category, tags,
            quality, quality_score, access_count, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        ("mem_1", "setting up docker containers guide", "test/1.md", "usr_1", "team", "team_1",
         "general", "[]", "community", 0.5, 2, now.isoformat(), now.isoformat()),
    )

    # Memory 2: old, never accessed (should become stale)
    old_date = (now - timedelta(days=200)).isoformat()
    await db.execute(
        """INSERT INTO memories
           (id, summary, file_path, owner_id, scope, team_id, category, tags,
            quality, quality_score, access_count, created_at, updated_at, last_accessed_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        ("mem_2", "ancient forgotten memory", "test/2.md", "usr_1", "team", "team_1",
         "general", "[]", "community", 0.5, 0, old_date, old_date, None),
    )

    # Memory 3: recently accessed, high quality
    await db.execute(
        """INSERT INTO memories
           (id, summary, file_path, owner_id, scope, team_id, category, tags,
            quality, quality_score, access_count, created_at, updated_at, last_accessed_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        ("mem_3", "active high quality memory", "test/3.md", "usr_1", "team", "team_1",
         "architecture", "[]", "verified", 0.8, 15, now.isoformat(), now.isoformat(),
         now.isoformat()),
    )

    # Memory 4: already stale, should be auto-archived
    stale_date = (now - timedelta(days=40)).isoformat()
    await db.execute(
        """INSERT INTO memories
           (id, summary, file_path, owner_id, scope, team_id, category, tags,
            quality, quality_score, access_count, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        ("mem_4", "stale memory waiting for archive", "test/4.md", "usr_1", "team", "team_1",
         "general", "[]", "stale", 0.3, 0, stale_date, stale_date),
    )

    await db.commit()
    yield db
    await db.close()


class TestCurationManager:

    @pytest.mark.asyncio
    async def test_detect_duplicates(self, curation_db: Database):
        """应找到近似重复的记忆。"""
        manager = CurationManager(curation_db)
        dupes = await manager.detect_duplicates("team_1", threshold=0.7)

        assert len(dupes) >= 1
        pair = dupes[0]
        assert pair["similarity"] >= 0.7
        assert set([pair["id_a"], pair["id_b"]]) == {"mem_0", "mem_1"}

    @pytest.mark.asyncio
    async def test_detect_staleness(self, curation_db: Database):
        """应将旧的未访问记忆标记为陈旧。"""
        manager = CurationManager(curation_db)
        count = await manager.detect_staleness("team_1", stale_days=180)

        assert count >= 1

        row = await curation_db.fetch_one("SELECT quality FROM memories WHERE id = 'mem_2'")
        assert row["quality"] == "stale"

    @pytest.mark.asyncio
    async def test_auto_archive(self, curation_db: Database):
        """应存档已陈旧 30+ 天的记忆。"""
        manager = CurationManager(curation_db)
        count = await manager.auto_archive("team_1", stale_archive_days=30)

        assert count >= 1

        row = await curation_db.fetch_one("SELECT quality FROM memories WHERE id = 'mem_4'")
        assert row["quality"] == "archived"

    @pytest.mark.asyncio
    async def test_refresh_quality_scores(self, curation_db: Database):
        """应重新计算所有未存档记忆的质量评分。"""
        manager = CurationManager(curation_db)
        count = await manager.refresh_quality_scores("team_1")

        assert count >= 4  # At least 4 non-archived memories

        # Verified + high access should have higher score
        row = await curation_db.fetch_one("SELECT quality_score FROM memories WHERE id = 'mem_3'")
        assert row["quality_score"] > 0.5

    @pytest.mark.asyncio
    async def test_verify_file_integrity_no_base_dir(self, curation_db: Database):
        """不使用 file_base_dir，应返回零。"""
        manager = CurationManager(curation_db)
        result = await manager.verify_file_integrity("team_1")
        assert result["checked"] == 0

    @pytest.mark.asyncio
    async def test_verify_file_integrity_with_files(self, curation_db: Database):
        """应检查文件并检测丢失的文件。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a file for mem_0 but not for others
            test_dir = os.path.join(tmpdir, "test")
            os.makedirs(test_dir, exist_ok=True)
            with open(os.path.join(test_dir, "0.md"), "w") as f:
                f.write("test content")

            manager = CurationManager(curation_db, file_base_dir=tmpdir)
            result = await manager.verify_file_integrity("team_1")

            assert result["checked"] >= 1
            assert result["missing"] >= 1  # Others are missing

    @pytest.mark.asyncio
    async def test_sync_specs_index(self, curation_db: Database):
        """应修复孤立的规范提案。"""
        manager = CurationManager(curation_db)
        count = await manager.sync_specs_index("team_1")
        assert count >= 0  # No orphans in test data

    @pytest.mark.asyncio
    async def test_calculate_quality_score(self):
        """测试质量评分计算。"""
        now = datetime.utcnow()

        # High access, verified
        row = {
            "access_count": 15,
            "quality": "verified",
            "created_at": now.isoformat(),
            "last_accessed_at": now.isoformat(),
        }
        score = CurationManager._calculate_quality_score(row, now)
        assert score > 0.7

        # Zero access, stale
        row2 = {
            "access_count": 0,
            "quality": "stale",
            "created_at": (now - timedelta(days=400)).isoformat(),
            "last_accessed_at": None,
        }
        score2 = CurationManager._calculate_quality_score(row2, now)
        assert score2 < 0.5

    @pytest.mark.asyncio
    async def test_run_all(self, curation_db: Database):
        """run_all should execute without errors."""
        manager = CurationManager(curation_db)
        results = await manager.run_all("team_1")

        assert "duplicates" in results
        assert "stale_marked" in results
        assert "auto_archived" in results
        assert "quality_refreshed" in results
