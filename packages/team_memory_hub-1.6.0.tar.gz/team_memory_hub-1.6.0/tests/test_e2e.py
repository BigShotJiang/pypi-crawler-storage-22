"""End-to-end integration tests: full API flow through FastAPI app."""

from __future__ import annotations

import os
import tempfile

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from team_memory_hub.config import (
    TMHConfig, AuthConfig, DatabaseConfig, ServerConfig, StorageConfig, set_config,
)
from team_memory_hub.server.app import create_app


@pytest.fixture
def e2e_config():
    """Create e2e test configuration with temp directories."""
    with tempfile.TemporaryDirectory() as tmpdir:
        config = TMHConfig(
            server=ServerConfig(data_dir=tmpdir),
            auth=AuthConfig(jwt_secret="e2e-test-secret"),
            database=DatabaseConfig(path=":memory:"),
            storage=StorageConfig(
                memories_dir=os.path.join(tmpdir, "memories"),
                specs_dir=os.path.join(tmpdir, "specs"),
                chats_dir=os.path.join(tmpdir, "chats"),
            ),
        )
        set_config(config)
        yield config


@pytest_asyncio.fixture
async def client(e2e_config):
    """Create async test client with full app lifecycle."""
    app = create_app()

    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as ac:
        # Trigger startup
        async with app.router.lifespan_context(app):
            yield ac


class TestHealthCheck:
    @pytest.mark.asyncio
    async def test_health(self, client: AsyncClient):
        resp = await client.get("/api/v1/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] in ("ok", "healthy")


class TestFullFlow:
    @pytest.mark.asyncio
    async def test_register_login_create_memory(self, client: AsyncClient):
        """Full flow: create team -> register -> login -> create memory -> list."""
        # 1. Create team
        resp = await client.post("/api/v1/teams", json={"name": "E2E Team"})
        if resp.status_code == 201:
            team_id = resp.json()["id"]
        else:
            # Team route may not be available; use direct approach
            pytest.skip("Team route not available")
            return

        # 2. Register user
        resp = await client.post("/api/v1/auth/register", json={
            "name": "E2E User",
            "email": "e2e@test.com",
            "password": "testpass123",
            "role": "admin",
            "team_id": team_id,
        })
        assert resp.status_code == 201
        user = resp.json()
        assert user["team_id"] == team_id

        # 3. Login
        resp = await client.post("/api/v1/auth/token", json={
            "email": "e2e@test.com",
            "password": "testpass123",
        })
        assert resp.status_code == 200
        tokens = resp.json()
        access_token = tokens["access_token"]
        headers = {"Authorization": f"Bearer {access_token}"}

        # 4. Get current user
        resp = await client.get("/api/v1/auth/me", headers=headers)
        assert resp.status_code == 200
        assert resp.json()["email"] == "e2e@test.com"

        # 5. Create memory
        resp = await client.post("/api/v1/memories", headers=headers, json={
            "content": "E2E test memory content about Python best practices",
            "summary": "Python best practices",
            "scope": "team",
            "category": "coding_standard",
            "tags": ["python", "e2e"],
        })
        assert resp.status_code == 201
        memory = resp.json()
        memory_id = memory["id"]
        assert memory["summary"] == "Python best practices"

        # 6. List memories
        resp = await client.get("/api/v1/memories", headers=headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] >= 1

        # 7. Get memory detail
        resp = await client.get(f"/api/v1/memories/{memory_id}/detail", headers=headers)
        assert resp.status_code == 200
        detail = resp.json()
        assert "Python best practices" in detail["content"]

        # 8. Update memory
        resp = await client.put(f"/api/v1/memories/{memory_id}", headers=headers, json={
            "summary": "Updated Python best practices",
        })
        assert resp.status_code == 200

        # 9. 验证记忆（公开注册用户被强制为 member，不能执行 maintainer+ 操作）
        resp = await client.post(f"/api/v1/memories/{memory_id}/verify", headers=headers)
        assert resp.status_code == 403

        # 10. Get versions
        resp = await client.get(f"/api/v1/memories/{memory_id}/versions", headers=headers)
        assert resp.status_code == 200
        versions = resp.json()
        assert len(versions) >= 1

    @pytest.mark.asyncio
    async def test_project_crud(self, client: AsyncClient):
        """Test project creation and listing."""
        # Create team
        resp = await client.post("/api/v1/teams", json={"name": "Project Test Team"})
        if resp.status_code != 201:
            pytest.skip("Team route not available")
            return
        team_id = resp.json()["id"]

        # Register and login
        await client.post("/api/v1/auth/register", json={
            "name": "Proj User", "email": "proj@test.com",
            "password": "pass123", "role": "admin", "team_id": team_id,
        })
        resp = await client.post("/api/v1/auth/token", json={
            "email": "proj@test.com", "password": "pass123",
        })
        headers = {"Authorization": f"Bearer {resp.json()['access_token']}"}

        # Create project
        resp = await client.post("/api/v1/projects", headers=headers, json={
            "name": "Test Project",
            "description": "A test project",
        })
        assert resp.status_code == 201
        project = resp.json()
        assert project["name"] == "Test Project"

        # List projects
        resp = await client.get("/api/v1/projects", headers=headers)
        assert resp.status_code == 200
        assert len(resp.json()) >= 1


class TestSystemEndpoints:
    @pytest.mark.asyncio
    async def test_system_health(self, client: AsyncClient):
        """System health endpoint should work without auth."""
        resp = await client.get("/api/v1/system/health")
        if resp.status_code == 200:
            assert resp.json()["status"] == "ok"
        # May not be available if system router didn't load
