"""测试嵌入提供程序（模拟外部 API）。"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from team_memory_hub.providers.embedding.base import EmbeddingProvider, TARGET_DIMENSIONS


# ==================== Base Provider Tests ====================


class TestBaseProvider:
    """测试 EmbeddingProvider 基类实用程序。"""

    def test_target_dimensions(self):
        assert TARGET_DIMENSIONS == 384
        assert EmbeddingProvider.TARGET_DIMENSIONS == 384

    def test_normalize_dimensions_truncation(self):
        """将 768 维向量截断为 384。"""
        vector = [0.1] * 768
        result = EmbeddingProvider._normalize_dimensions(vector, 384)
        assert len(result) == 384

    def test_normalize_dimensions_l2_normalized(self):
        """Result should be L2 归一化d."""
        vector = [1.0, 0.0, 0.0] + [0.0] * 381
        result = EmbeddingProvider._normalize_dimensions(vector, 384)
        assert len(result) == 384
        # L2 norm should be ~1.0
        norm = sum(x * x for x in result) ** 0.5
        assert abs(norm - 1.0) < 1e-6

    def test_normalize_zero_vector(self):
        """零向量应保持零（无零除）。"""
        vector = [0.0] * 768
        result = EmbeddingProvider._normalize_dimensions(vector, 384)
        assert len(result) == 384
        assert all(x == 0.0 for x in result)

    def test_normalize_short_vector(self):
        """比目标短的向量不应填充。"""
        vector = [1.0, 2.0, 3.0]
        result = EmbeddingProvider._normalize_dimensions(vector, 384)
        # Should only have 3 elements (no padding)
        assert len(result) == 3


# ==================== Gemini Provider Tests ====================


class TestGeminiProvider:
    """测试具有模拟 HTTP 的 GeminiProvider。"""

    @pytest.mark.asyncio
    async def test_embed_single(self):
        from team_memory_hub.providers.embedding.gemini import GeminiProvider

        provider = GeminiProvider(api_key="test-key")

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "embeddings": [{"values": [0.1] * 768}]
        }

        with patch.object(provider, "_get_client") as mock_client:
            client = AsyncMock()
            client.post = AsyncMock(return_value=mock_response)
            mock_client.return_value = client

            result = await provider.embed_single("test text")
            assert len(result) == 384

    @pytest.mark.asyncio
    async def test_embed_batch(self):
        from team_memory_hub.providers.embedding.gemini import GeminiProvider

        provider = GeminiProvider(api_key="test-key")

        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "embeddings": [
                {"values": [0.1] * 768},
                {"values": [0.2] * 768},
            ]
        }

        with patch.object(provider, "_get_client") as mock_client:
            client = AsyncMock()
            client.post = AsyncMock(return_value=mock_response)
            mock_client.return_value = client

            results = await provider.embed(["text1", "text2"])
            assert len(results) == 2
            assert all(len(v) == 384 for v in results)


# ==================== OpenAI Provider Tests ====================


class TestOpenAIProvider:
    """测试具有模拟 HTTP 的 OpenAIProvider。"""

    @pytest.mark.asyncio
    async def test_embed_single(self):
        from team_memory_hub.providers.embedding.openai_provider import OpenAIProvider

        provider = OpenAIProvider(api_key="test-key")

        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "data": [{"index": 0, "embedding": [0.1] * 1536}]
        }

        with patch.object(provider, "_get_client") as mock_client:
            client = AsyncMock()
            client.post = AsyncMock(return_value=mock_response)
            mock_client.return_value = client

            result = await provider.embed_single("test text")
            assert len(result) == 384

    @pytest.mark.asyncio
    async def test_embed_preserves_order(self):
        from team_memory_hub.providers.embedding.openai_provider import OpenAIProvider

        provider = OpenAIProvider(api_key="test-key")

        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        # Return out of order
        mock_response.json.return_value = {
            "data": [
                {"index": 1, "embedding": [0.2] * 1536},
                {"index": 0, "embedding": [0.1] * 1536},
            ]
        }

        with patch.object(provider, "_get_client") as mock_client:
            client = AsyncMock()
            client.post = AsyncMock(return_value=mock_response)
            mock_client.return_value = client

            results = await provider.embed(["first", "second"])
            assert len(results) == 2


# ==================== OpenAI-Compatible Provider Tests ====================


class TestOpenAICompatibleProvider:
    """测试具有模拟 HTTP 的 OpenAICompatibleProvider。"""

    @pytest.mark.asyncio
    async def test_embed_with_ollama(self):
        from team_memory_hub.providers.embedding.openai_compatible import OpenAICompatibleProvider

        provider = OpenAICompatibleProvider(
            base_url="http://localhost:11434",
            model="nomic-embed-text",
        )

        # Ollama produces 768-dim vectors
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "data": [{"index": 0, "embedding": [0.1] * 768}]
        }

        with patch.object(provider, "_get_client") as mock_client:
            client = AsyncMock()
            client.post = AsyncMock(return_value=mock_response)
            mock_client.return_value = client

            result = await provider.embed_single("test text")
            assert len(result) == 384

    @pytest.mark.asyncio
    async def test_native_384_no_truncation(self):
        from team_memory_hub.providers.embedding.openai_compatible import OpenAICompatibleProvider

        provider = OpenAICompatibleProvider(
            base_url="http://localhost:11434",
            model="all-minilm",
        )

        # Native 384-dim vector
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "data": [{"index": 0, "embedding": [0.1] * 384}]
        }

        with patch.object(provider, "_get_client") as mock_client:
            client = AsyncMock()
            client.post = AsyncMock(return_value=mock_response)
            mock_client.return_value = client

            result = await provider.embed_single("test text")
            assert len(result) == 384

    def test_base_url_normalization(self):
        from team_memory_hub.providers.embedding.openai_compatible import OpenAICompatibleProvider

        # Without /v1
        p1 = OpenAICompatibleProvider(base_url="http://localhost:11434")
        assert p1.base_url == "http://localhost:11434/v1"

        # With /v1
        p2 = OpenAICompatibleProvider(base_url="http://localhost:11434/v1")
        assert p2.base_url == "http://localhost:11434/v1"

        # With trailing slash
        p3 = OpenAICompatibleProvider(base_url="http://localhost:11434/")
        assert p3.base_url == "http://localhost:11434/v1"


# ==================== Factory Tests ====================


class TestProviderFactory:
    """测试 create_embedding_provider 工厂。"""

    def test_create_openai_compatible(self):
        from team_memory_hub.config import EmbeddingConfig
        from team_memory_hub.providers.embedding import create_embedding_provider
        from team_memory_hub.providers.embedding.openai_compatible import OpenAICompatibleProvider

        config = EmbeddingConfig(provider="openai_compatible")
        provider = create_embedding_provider(config)
        assert isinstance(provider, OpenAICompatibleProvider)

    def test_create_openai(self):
        from team_memory_hub.config import EmbeddingConfig
        from team_memory_hub.providers.embedding import create_embedding_provider
        from team_memory_hub.providers.embedding.openai_provider import OpenAIProvider

        config = EmbeddingConfig(provider="openai", api_key="test")
        provider = create_embedding_provider(config)
        assert isinstance(provider, OpenAIProvider)

    def test_create_gemini(self):
        from team_memory_hub.config import EmbeddingConfig
        from team_memory_hub.providers.embedding import create_embedding_provider
        from team_memory_hub.providers.embedding.gemini import GeminiProvider

        config = EmbeddingConfig(provider="gemini", api_key="test")
        provider = create_embedding_provider(config)
        assert isinstance(provider, GeminiProvider)

    def test_create_default(self):
        from team_memory_hub.config import EmbeddingConfig
        from team_memory_hub.providers.embedding import create_embedding_provider
        from team_memory_hub.providers.embedding.openai_compatible import OpenAICompatibleProvider

        config = EmbeddingConfig(provider="unknown_provider")
        provider = create_embedding_provider(config)
        assert isinstance(provider, OpenAICompatibleProvider)
