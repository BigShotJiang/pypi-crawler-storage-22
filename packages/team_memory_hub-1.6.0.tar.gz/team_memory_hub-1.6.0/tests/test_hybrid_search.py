"""测试混合搜索引擎。"""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, patch

import pytest
import pytest_asyncio

from team_memory_hub.core.search_engine import (
    HybridSearchEngine,
    SearchResult,
    _escape_fts5_query,
    _float_list_to_blob,
)
from team_memory_hub.providers.embedding.base import EmbeddingProvider
from team_memory_hub.storage.database import Database


# ==================== 夹具 ====================


class MockEmbeddingProvider(EmbeddingProvider):
    """用于测试的模拟嵌入提供程序。"""

    async def embed(self, texts: list[str]) -> list[list[float]]:
        return [[0.1] * 384 for _ in texts]


@pytest_asyncio.fixture
async def db() -> Database:
    database = Database(":memory:")
    await database.initialize()
    yield database
    await database.close()


@pytest_asyncio.fixture
async def seeded_db(db: Database) -> Database:
    """包含测试团队、用户和记忆的数据库。"""
    await db.execute(
        "INSERT INTO teams (id, name) VALUES (?, ?)",
        ("team_test", "Test Team"),
    )
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id) VALUES (?, ?, ?, ?, ?)",
        ("usr_1", "User1", "u1@test.com", "member", "team_test"),
    )

    # Insert test memories
    now = datetime.utcnow()
    memories = [
        ("mem_1", "Python async patterns", "team_test", "usr_1", "team",
         "experience", '["python","async"]', "community",
         (now - timedelta(days=2)).isoformat()),
        ("mem_2", "Database migration best practices", "team_test", "usr_1", "team",
         "decision", '["database","migration"]', "verified",
         (now - timedelta(days=5)).isoformat()),
        ("mem_3", "Old architecture notes", "team_test", "usr_1", "team",
         "architecture", '["architecture"]', "community",
         (now - timedelta(days=100)).isoformat()),
        ("mem_4", "Private debugging notes", "team_test", "usr_1", "private",
         "bug_fix", '["debug"]', "community",
         now.isoformat()),
        ("mem_5", "React component patterns", "team_test", "usr_1", "project",
         "coding_standard", '["react","frontend"]', "pinned",
         (now - timedelta(days=30)).isoformat()),
    ]

    for m in memories:
        await db.execute(
            """INSERT INTO memories
               (id, summary, file_path, owner_id, scope, team_id,
                category, tags, quality, created_at, updated_at)
               VALUES (?, ?, 'test.md', ?, ?, ?, ?, ?, ?, ?, ?)""",
            (m[0], m[1], m[3], m[4], m[2], m[5], m[6], m[7], m[8], m[8]),
        )

    await db.commit()
    return db


@pytest.fixture
def mock_provider() -> MockEmbeddingProvider:
    return MockEmbeddingProvider()


@pytest.fixture
def engine(seeded_db: Database, mock_provider: MockEmbeddingProvider) -> HybridSearchEngine:
    eng = HybridSearchEngine(
        db=seeded_db,
        embedding_provider=mock_provider,
        semantic_weight=0.7,
        keyword_weight=0.3,
    )
    # Force vec as unavailable (no sqlite-vec in tests)
    eng._vec_available = False
    return eng


# ==================== Score Normalization Tests ====================


class TestScoreNormalization:
    def test_normalize_empty(self):
        result = HybridSearchEngine._normalize_scores({})
        assert result == {}

    def test_normalize_single(self):
        result = HybridSearchEngine._normalize_scores({"a": 5.0})
        assert result == {"a": 1.0}

    def test_normalize_range(self):
        result = HybridSearchEngine._normalize_scores({
            "a": 1.0, "b": 3.0, "c": 5.0
        })
        assert result["a"] == pytest.approx(0.0)
        assert result["b"] == pytest.approx(0.5)
        assert result["c"] == pytest.approx(1.0)

    def test_normalize_equal_values(self):
        result = HybridSearchEngine._normalize_scores({
            "a": 3.0, "b": 3.0
        })
        assert result["a"] == 1.0
        assert result["b"] == 1.0


# ==================== BM25 Search Tests ====================


class TestBM25Search:
    @pytest.mark.asyncio
    async def test_bm25_search_finds_matches(self, engine: HybridSearchEngine):
        """BM25 should find memories matching the query."""
        results = await engine._bm25_search(
            query="Python async",
            team_id="team_test",
            user_id="usr_1",
            scope=None,
            category=None,
            project_id=None,
            limit=10,
        )
        assert len(results) > 0
        assert "mem_1" in results

    @pytest.mark.asyncio
    async def test_bm25_search_private_isolation(self, engine: HybridSearchEngine):
        """Private memories should only be visible to owner."""
        # User who owns the private memory
        results = await engine._bm25_search(
            query="debugging",
            team_id="team_test",
            user_id="usr_1",
            scope=None,
            category=None,
            project_id=None,
            limit=10,
        )
        # mem_4 is private but owned by usr_1
        # Whether it shows depends on if "debugging" matches "Private debugging notes"
        # It should match since summary contains "debugging"

        # Different user should not see private memories
        results_other = await engine._bm25_search(
            query="debugging",
            team_id="team_test",
            user_id="usr_other",
            scope=None,
            category=None,
            project_id=None,
            limit=10,
        )
        assert "mem_4" not in results_other

    @pytest.mark.asyncio
    async def test_bm25_empty_query(self, engine: HybridSearchEngine):
        results = await engine._bm25_search(
            query="",
            team_id="team_test",
            user_id="usr_1",
            scope=None,
            category=None,
            project_id=None,
            limit=10,
        )
        assert results == {}


# ==================== Boost Tests ====================


class TestBoosts:
    def test_project_boost(self, engine: HybridSearchEngine):
        """Project-matching results should get +20% boost."""
        results = [
            SearchResult(id="mem_a", summary="test", score=1.0, project_id="proj_1"),
            SearchResult(id="mem_b", summary="test", score=1.0, project_id="proj_2"),
        ]
        boosted = engine._apply_boosts(results, current_project_id="proj_1")
        assert boosted[0].score > boosted[1].score

    def test_time_decay_recent(self, engine: HybridSearchEngine):
        """Recent memories (<7 days) should get +10% boost."""
        now = datetime.utcnow()
        results = [
            SearchResult(
                id="mem_recent", summary="test", score=1.0,
                created_at=(now - timedelta(days=1)).isoformat(),
            ),
            SearchResult(
                id="mem_old", summary="test", score=1.0,
                created_at=(now - timedelta(days=120)).isoformat(),
            ),
        ]
        boosted = engine._apply_boosts(results)
        assert boosted[0].score > boosted[1].score  # Recent > old

    def test_verified_boost(self, engine: HybridSearchEngine):
        """Verified/pinned memories should get +15% boost."""
        results = [
            SearchResult(id="mem_v", summary="test", score=1.0, quality="verified"),
            SearchResult(id="mem_c", summary="test", score=1.0, quality="community"),
        ]
        boosted = engine._apply_boosts(results)
        assert boosted[0].score > boosted[1].score

    def test_combined_boosts(self, engine: HybridSearchEngine):
        """Multiple boosts should stack multiplicatively."""
        now = datetime.utcnow()
        results = [
            SearchResult(
                id="mem_super", summary="test", score=1.0,
                quality="pinned",
                project_id="proj_1",
                created_at=(now - timedelta(days=1)).isoformat(),
            ),
        ]
        boosted = engine._apply_boosts(results, current_project_id="proj_1")
        # 1.0 * 1.20 * 1.10 * 1.15 = 1.518
        assert boosted[0].score == pytest.approx(1.518, rel=0.01)


# ==================== Full Search Tests ====================


class TestFullSearch:
    @pytest.mark.asyncio
    async def test_bm25_only_mode(self, engine: HybridSearchEngine):
        """bm25_only mode should work without vector search."""
        results = await engine.search(
            query="Python",
            team_id="team_test",
            user_id="usr_1",
            limit=10,
            mode="bm25_only",
        )
        assert isinstance(results, list)
        # Should find at least mem_1 (Python async patterns)
        ids = [r.id for r in results]
        assert "mem_1" in ids

    @pytest.mark.asyncio
    async def test_hybrid_mode_without_vec(self, engine: HybridSearchEngine):
        """Hybrid mode should gracefully degrade when vec is unavailable."""
        results = await engine.search(
            query="database",
            team_id="team_test",
            user_id="usr_1",
            limit=10,
            mode="hybrid",
        )
        # Should still return BM25 results
        assert isinstance(results, list)

    @pytest.mark.asyncio
    async def test_category_filter(self, engine: HybridSearchEngine):
        results = await engine.search(
            query="patterns",
            team_id="team_test",
            user_id="usr_1",
            category="experience",
            limit=10,
            mode="bm25_only",
        )
        for r in results:
            assert r.category == "experience"

    @pytest.mark.asyncio
    async def test_results_sorted_by_score(self, engine: HybridSearchEngine):
        results = await engine.search(
            query="patterns",
            team_id="team_test",
            user_id="usr_1",
            limit=10,
            mode="bm25_only",
        )
        if len(results) > 1:
            for i in range(len(results) - 1):
                assert results[i].score >= results[i + 1].score


# ==================== Utility Tests ====================


class TestUtilities:
    def test_escape_fts5_query_basic(self):
        result = _escape_fts5_query("hello world")
        assert '"hello"' in result
        assert '"world"' in result

    def test_escape_fts5_query_special_chars(self):
        result = _escape_fts5_query('test "quoted" (parens)')
        # Special chars should be removed
        assert "(" not in result
        assert ")" not in result

    def test_escape_fts5_empty(self):
        result = _escape_fts5_query("")
        assert result == ""

    def test_float_list_to_blob(self):
        values = [1.0, 2.0, 3.0]
        blob = _float_list_to_blob(values)
        assert isinstance(blob, bytes)
        assert len(blob) == 12  # 3 floats * 4 bytes
