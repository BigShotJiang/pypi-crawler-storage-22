"""Tests for MCP Server V1.6: JSON-RPC tools, tool_set, RBAC."""

from __future__ import annotations

import json
import os
import tempfile

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from team_memory_hub.config import (
    TMHConfig, AuthConfig, DatabaseConfig, MCPConfig,
    ServerConfig, StorageConfig, set_config,
)
from team_memory_hub.server.routes.auth import hash_password
from team_memory_hub.storage.database import Database


@pytest.fixture
def test_config():
    with tempfile.TemporaryDirectory() as tmpdir:
        config = TMHConfig(
            server=ServerConfig(data_dir=tmpdir),
            auth=AuthConfig(jwt_secret="test-secret-key"),
            database=DatabaseConfig(path=":memory:"),
            storage=StorageConfig(
                memories_dir=os.path.join(tmpdir, "memories"),
                specs_dir=os.path.join(tmpdir, "specs"),
                chats_dir=os.path.join(tmpdir, "chats"),
            ),
            mcp=MCPConfig(tool_set="full_crud"),
        )
        set_config(config)
        yield config


async def _seed_db(db: Database) -> None:
    """Seed database with test team, users, and API keys."""
    await db.execute("INSERT INTO teams (id, name) VALUES ('t1', 'Test')")
    # Admin user
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id, password_hash) "
        "VALUES ('u_admin', 'Admin', 'admin@t.com', 'admin', 't1', ?)",
        (hash_password("password"),),
    )
    # Member user
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id, password_hash) "
        "VALUES ('u_member', 'Member', 'member@t.com', 'member', 't1', ?)",
        (hash_password("password"),),
    )
    # Viewer user
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id, password_hash) "
        "VALUES ('u_viewer', 'Viewer', 'viewer@t.com', 'viewer', 't1', ?)",
        (hash_password("password"),),
    )
    # API keys
    await db.execute(
        "INSERT INTO api_keys (id, key, user_id, name, scope) "
        "VALUES ('ak_admin', 'key-admin', 'u_admin', 'Admin MCP', 'mcp_only')",
    )
    await db.execute(
        "INSERT INTO api_keys (id, key, user_id, name, scope) "
        "VALUES ('ak_member', 'key-member', 'u_member', 'Member MCP', 'mcp_only')",
    )
    await db.execute(
        "INSERT INTO api_keys (id, key, user_id, name, scope) "
        "VALUES ('ak_viewer', 'key-viewer', 'u_viewer', 'Viewer MCP', 'mcp_only')",
    )
    await db.commit()


@pytest_asyncio.fixture
async def app_client(test_config):
    """Create a test app with full_crud MCP."""
    from team_memory_hub.server.app import create_app

    app = create_app()
    db = Database(":memory:")
    await db.initialize()
    app.state.db = db
    await _seed_db(db)

    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as client:
        yield client

    await db.close()


ADMIN_HEADERS = {"Authorization": "Bearer key-admin"}
MEMBER_HEADERS = {"Authorization": "Bearer key-member"}
VIEWER_HEADERS = {"Authorization": "Bearer key-viewer"}


def _rpc(method: str, params: dict | None = None, rpc_id: int = 1) -> dict:
    req = {"jsonrpc": "2.0", "method": method, "id": rpc_id}
    if params is not None:
        req["params"] = params
    return req


def _tool_call(name: str, arguments: dict, rpc_id: int = 1) -> dict:
    return _rpc("tools/call", {"name": name, "arguments": arguments}, rpc_id)


def _parse_tool_result(resp_json: dict) -> dict:
    return json.loads(resp_json["result"]["content"][0]["text"])


# ========== Initialize & Ping ==========


class TestMCPProtocol:
    @pytest.mark.asyncio
    async def test_initialize(self, app_client: AsyncClient):
        resp = await app_client.post(
            "/api/v1/mcp/rpc", json=_rpc("initialize"), headers=ADMIN_HEADERS,
        )
        assert resp.status_code == 200
        info = resp.json()["result"]["serverInfo"]
        assert info["name"] == "team-memory-hub"
        assert info["version"] == "1.6.0"

    @pytest.mark.asyncio
    async def test_ping(self, app_client: AsyncClient):
        resp = await app_client.post(
            "/api/v1/mcp/rpc", json=_rpc("ping"), headers=ADMIN_HEADERS,
        )
        assert resp.json()["result"] == {}

    @pytest.mark.asyncio
    async def test_no_auth(self, app_client: AsyncClient):
        resp = await app_client.post("/api/v1/mcp/rpc", json=_rpc("ping"))
        assert resp.status_code == 401


# ========== Tool Set Configuration ==========


class TestToolSet:
    @pytest.mark.asyncio
    async def test_full_crud_lists_all_tools(self, app_client: AsyncClient):
        """full_crud tool_set should list all 5 tools."""
        resp = await app_client.post(
            "/api/v1/mcp/rpc", json=_rpc("tools/list"), headers=ADMIN_HEADERS,
        )
        tools = resp.json()["result"]["tools"]
        names = [t["name"] for t in tools]
        assert "search_memory" in names
        assert "get_memory_detail" in names
        assert "store_memory" in names
        assert "update_memory" in names
        assert "delete_memory" in names

    @pytest.mark.asyncio
    async def test_rest_tools_endpoint(self, app_client: AsyncClient):
        resp = await app_client.get("/api/v1/mcp/tools")
        data = resp.json()
        assert "tools" in data
        assert "tool_set" in data


# ========== CRUD Full Flow ==========


class TestCRUDFlow:
    @pytest.mark.asyncio
    async def test_store_search_update_delete(self, app_client: AsyncClient):
        """Full lifecycle: store -> search -> get -> update -> delete."""
        # 1. Store
        resp = await app_client.post("/api/v1/mcp/rpc", json=_tool_call(
            "store_memory", {
                "content": "Always use type hints in Python",
                "summary": "Python type hints convention",
                "category": "coding_standard",
                "tags": ["python", "typing"],
                "scope": "team",
            },
        ), headers=ADMIN_HEADERS)
        assert resp.status_code == 200
        result = _parse_tool_result(resp.json())
        assert result["status"] == "created"
        mem_id = result["id"]

        # 2. Search
        resp = await app_client.post("/api/v1/mcp/rpc", json=_tool_call(
            "search_memory", {"query": "type hints"},
        ), headers=ADMIN_HEADERS)
        result = _parse_tool_result(resp.json())
        assert result["count"] >= 1

        # 3. Get detail
        resp = await app_client.post("/api/v1/mcp/rpc", json=_tool_call(
            "get_memory_detail", {"memory_id": mem_id},
        ), headers=ADMIN_HEADERS)
        result = _parse_tool_result(resp.json())
        assert result["id"] == mem_id
        assert "type hints" in result["content"]

        # 4. Update
        resp = await app_client.post("/api/v1/mcp/rpc", json=_tool_call(
            "update_memory", {
                "memory_id": mem_id,
                "summary": "Updated: Python type hints",
                "tags": ["python", "typing", "best-practice"],
            },
        ), headers=ADMIN_HEADERS)
        result = _parse_tool_result(resp.json())
        assert result["status"] == "updated"

        # 5. Delete (soft)
        resp = await app_client.post("/api/v1/mcp/rpc", json=_tool_call(
            "delete_memory", {"memory_id": mem_id},
        ), headers=ADMIN_HEADERS)
        result = _parse_tool_result(resp.json())
        assert result["status"] == "archived"


# ========== RBAC Permission Tests ==========


class TestRBAC:
    @pytest.mark.asyncio
    async def test_viewer_can_search(self, app_client: AsyncClient):
        """Viewer should be able to search."""
        resp = await app_client.post("/api/v1/mcp/rpc", json=_tool_call(
            "search_memory", {"query": "test"},
        ), headers=VIEWER_HEADERS)
        result = _parse_tool_result(resp.json())
        assert "error" not in result

    @pytest.mark.asyncio
    async def test_viewer_cannot_store(self, app_client: AsyncClient):
        """Viewer should not be able to store."""
        resp = await app_client.post("/api/v1/mcp/rpc", json=_tool_call(
            "store_memory", {"content": "test"},
        ), headers=VIEWER_HEADERS)
        result = _parse_tool_result(resp.json())
        assert "error" in result
        assert "permissions" in result["error"].lower() or "role" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_member_can_store(self, app_client: AsyncClient):
        """Member should be able to store."""
        resp = await app_client.post("/api/v1/mcp/rpc", json=_tool_call(
            "store_memory", {"content": "member memory", "scope": "team"},
        ), headers=MEMBER_HEADERS)
        result = _parse_tool_result(resp.json())
        assert result["status"] == "created"

    @pytest.mark.asyncio
    async def test_member_cannot_delete(self, app_client: AsyncClient):
        """Member should not be able to delete (admin only)."""
        # First store a memory
        resp = await app_client.post("/api/v1/mcp/rpc", json=_tool_call(
            "store_memory", {"content": "to delete", "scope": "team"},
        ), headers=MEMBER_HEADERS)
        mem_id = _parse_tool_result(resp.json())["id"]

        # Try to delete
        resp = await app_client.post("/api/v1/mcp/rpc", json=_tool_call(
            "delete_memory", {"memory_id": mem_id},
        ), headers=MEMBER_HEADERS)
        result = _parse_tool_result(resp.json())
        assert "error" in result

    @pytest.mark.asyncio
    async def test_member_can_update_own(self, app_client: AsyncClient):
        """Member can update their own memory."""
        # Store
        resp = await app_client.post("/api/v1/mcp/rpc", json=_tool_call(
            "store_memory", {"content": "my memory", "scope": "team"},
        ), headers=MEMBER_HEADERS)
        mem_id = _parse_tool_result(resp.json())["id"]

        # Update own
        resp = await app_client.post("/api/v1/mcp/rpc", json=_tool_call(
            "update_memory", {"memory_id": mem_id, "summary": "updated"},
        ), headers=MEMBER_HEADERS)
        result = _parse_tool_result(resp.json())
        assert result["status"] == "updated"


# ========== Error Handling ==========


class TestErrors:
    @pytest.mark.asyncio
    async def test_unknown_method(self, app_client: AsyncClient):
        resp = await app_client.post(
            "/api/v1/mcp/rpc", json=_rpc("unknown/method"), headers=ADMIN_HEADERS,
        )
        assert resp.json()["error"]["code"] == -32601

    @pytest.mark.asyncio
    async def test_unknown_tool(self, app_client: AsyncClient):
        resp = await app_client.post("/api/v1/mcp/rpc", json=_tool_call(
            "nonexistent_tool", {},
        ), headers=ADMIN_HEADERS)
        result = _parse_tool_result(resp.json())
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_nonexistent_memory(self, app_client: AsyncClient):
        resp = await app_client.post("/api/v1/mcp/rpc", json=_tool_call(
            "get_memory_detail", {"memory_id": "mem_notfound"},
        ), headers=ADMIN_HEADERS)
        result = _parse_tool_result(resp.json())
        assert "error" in result

    @pytest.mark.asyncio
    async def test_update_nonexistent(self, app_client: AsyncClient):
        resp = await app_client.post("/api/v1/mcp/rpc", json=_tool_call(
            "update_memory", {"memory_id": "mem_notfound", "summary": "x"},
        ), headers=ADMIN_HEADERS)
        result = _parse_tool_result(resp.json())
        assert "error" in result

    @pytest.mark.asyncio
    async def test_delete_nonexistent(self, app_client: AsyncClient):
        resp = await app_client.post("/api/v1/mcp/rpc", json=_tool_call(
            "delete_memory", {"memory_id": "mem_notfound"},
        ), headers=ADMIN_HEADERS)
        result = _parse_tool_result(resp.json())
        assert "error" in result


# ========== Streamable HTTP Transport ==========


class TestStreamableHTTP:
    @pytest.mark.asyncio
    async def test_initialize_via_streamable(self, app_client: AsyncClient):
        """POST /mcp should handle initialize."""
        resp = await app_client.post(
            "/mcp", json=_rpc("initialize"), headers=ADMIN_HEADERS,
        )
        assert resp.status_code == 200
        info = resp.json()["result"]["serverInfo"]
        assert info["name"] == "team-memory-hub"
        assert info["version"] == "1.6.0"

    @pytest.mark.asyncio
    async def test_tool_call_via_streamable(self, app_client: AsyncClient):
        """POST /mcp should handle tools/call."""
        resp = await app_client.post(
            "/mcp", json=_tool_call("search_memory", {"query": "test"}),
            headers=ADMIN_HEADERS,
        )
        assert resp.status_code == 200
        result = _parse_tool_result(resp.json())
        assert "count" in result

    @pytest.mark.asyncio
    async def test_no_auth_streamable(self, app_client: AsyncClient):
        """POST /mcp without auth should return 401."""
        resp = await app_client.post("/mcp", json=_rpc("initialize"))
        assert resp.status_code == 401

    @pytest.mark.asyncio
    async def test_unknown_method_streamable(self, app_client: AsyncClient):
        """POST /mcp with unknown method should return -32601."""
        resp = await app_client.post(
            "/mcp", json=_rpc("unknown/method"), headers=ADMIN_HEADERS,
        )
        assert resp.json()["error"]["code"] == -32601
