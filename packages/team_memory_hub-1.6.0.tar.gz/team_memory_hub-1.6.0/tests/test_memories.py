"""测试记忆管理：CRUD、质量生命周期、版本、筛选。"""

from __future__ import annotations

import os

import pytest

from team_memory_hub.core.memory_file_store import MemoryFileStore
from team_memory_hub.core.memory_store import MemoryStore, generate_memory_id
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import (
    MemoryCreate,
    MemoryUpdate,
    Memory范围,
    Memory类别,
    质量状态,
)


# ========== ID 生成测试 ==========


class TestMemoryIdGeneration:
    def test_id_format(self):
        """ID 应具有 mem_ 前缀 + 8 个字符。"""
        mid = generate_memory_id()
        assert mid.startswith("mem_")
        assert len(mid) == 12  # "mem_" + 8 chars

    def test_ids_unique(self):
        """生成的 ID 应是唯一的。"""
        ids = {generate_memory_id() for _ in range(100)}
        assert len(ids) == 100


# ========== 记忆存储测试 ==========


class TestMemoryStore:
    """测试记忆 CRUD 操作。"""

    @pytest.fixture
    def memory_store(self, seeded_db: Database, tmp_data_dir: str) -> MemoryStore:
        file_store = MemoryFileStore(os.path.join(tmp_data_dir, "test_memories"))
        return MemoryStore(seeded_db, file_store)

    @pytest.mark.asyncio
    async def test_create_memory(self, memory_store: MemoryStore):
        """创建记忆并验证其存在。"""
        data = MemoryCreate(
            content="# JWT Decision\n\nWe chose sliding window.",
            summary="JWT sliding window decision",
            scope=Memory范围.TEAM,
            category=Memory类别.DECISION,
            tags=["jwt", "auth"],
        )

        memory = await memory_store.create(
            data=data,
            owner_id="usr_member",
            team_id="team_test",
            owner_name="Member",
        )

        assert memory.id.startswith("mem_")
        assert memory.summary == "JWT sliding window decision"
        assert memory.scope == Memory范围.TEAM
        assert memory.category == Memory类别.DECISION
        assert memory.tags == ["jwt", "auth"]
        assert memory.quality == 质量状态.COMMUNITY

    @pytest.mark.asyncio
    async def test_auto_summary(self, memory_store: MemoryStore):
        """When no summary is provided, it should use first 200 chars of content."""
        data = MemoryCreate(
            content="Auto-generated summary test content.",
            scope=Memory范围.PRIVATE,
        )

        memory = await memory_store.create(
            data=data,
            owner_id="usr_member",
            team_id="team_test",
        )

        assert memory.summary == "Auto-generated summary test content."

    @pytest.mark.asyncio
    async def test_get_memory(self, memory_store: MemoryStore):
        """Get memory by ID."""
        data = MemoryCreate(content="Get test", summary="Get test")
        created = await memory_store.create(
            data=data, owner_id="usr_member", team_id="team_test"
        )

        fetched = await memory_store.get(created.id)
        assert fetched is not None
        assert fetched.id == created.id
        assert fetched.summary == "Get test"

    @pytest.mark.asyncio
    async def test_get_nonexistent(self, memory_store: MemoryStore):
        """Get nonexistent memory should return None."""
        result = await memory_store.get("mem_nonexist")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_detail(self, memory_store: MemoryStore):
        """Get detail should include file content."""
        data = MemoryCreate(
            content="# Detailed Content\n\nFull body here.",
            summary="Detail test",
        )
        created = await memory_store.create(
            data=data, owner_id="usr_member", team_id="team_test"
        )

        detail = await memory_store.get_detail(created.id)
        assert detail is not None
        assert "Detailed Content" in detail.content
        assert "Full body here." in detail.content

    @pytest.mark.asyncio
    async def test_update_memory(self, memory_store: MemoryStore):
        """Update memory content and metadata."""
        data = MemoryCreate(content="Original content", summary="Original")
        created = await memory_store.create(
            data=data, owner_id="usr_member", team_id="team_test"
        )

        update_data = MemoryUpdate(
            content="Updated content",
            summary="Updated summary",
            category=Memory类别.DECISION,
        )
        updated = await memory_store.update(
            memory_id=created.id,
            data=update_data,
            changed_by="usr_member",
        )

        assert updated is not None
        assert updated.summary == "Updated summary"
        assert updated.category == Memory类别.DECISION

    @pytest.mark.asyncio
    async def test_delete_memory(self, memory_store: MemoryStore):
        """删除 should remove both file and index."""
        data = MemoryCreate(content="To delete", summary="删除 test")
        created = await memory_store.create(
            data=data, owner_id="usr_member", team_id="team_test"
        )

        result = await memory_store.delete(created.id)
        assert result is True

        fetched = await memory_store.get(created.id)
        assert fetched is None

    @pytest.mark.asyncio
    async def test_delete_nonexistent(self, memory_store: MemoryStore):
        """删除 nonexistent should return False."""
        result = await memory_store.delete("mem_nonexist")
        assert result is False


# ========== 质量 Lifecycle Tests ==========


class Test质量Lifecycle:
    """Test quality status transitions."""

    @pytest.fixture
    def memory_store(self, seeded_db: Database, tmp_data_dir: str) -> MemoryStore:
        file_store = MemoryFileStore(os.path.join(tmp_data_dir, "test_quality"))
        return MemoryStore(seeded_db, file_store)

    @pytest.mark.asyncio
    async def test_verify_memory(self, memory_store: MemoryStore):
        """Verify should set quality and verified_by."""
        data = MemoryCreate(content="To verify", summary="Verify test")
        created = await memory_store.create(
            data=data, owner_id="usr_member", team_id="team_test"
        )

        success = await memory_store.update_quality(
            created.id, "verified", "usr_maint"
        )
        assert success

        memory = await memory_store.get(created.id)
        assert memory.quality == "verified"
        assert memory.verified_by == "usr_maint"

    @pytest.mark.asyncio
    async def test_lifecycle_transitions(self, memory_store: MemoryStore):
        """Test community -> stale -> archived lifecycle."""
        data = MemoryCreate(content="Lifecycle", summary="Lifecycle")
        created = await memory_store.create(
            data=data, owner_id="usr_member", team_id="team_test"
        )
        assert (await memory_store.get(created.id)).quality == "community"

        await memory_store.update_quality(created.id, "stale", "system")
        assert (await memory_store.get(created.id)).quality == "stale"

        await memory_store.update_quality(created.id, "archived", "system")
        assert (await memory_store.get(created.id)).quality == "archived"


# ========== Version Tracking Tests ==========


class TestVersionTracking:
    """Test memory version history."""

    @pytest.fixture
    def memory_store(self, seeded_db: Database, tmp_data_dir: str) -> MemoryStore:
        file_store = MemoryFileStore(os.path.join(tmp_data_dir, "test_versions"))
        return MemoryStore(seeded_db, file_store)

    @pytest.mark.asyncio
    async def test_initial_version(self, memory_store: MemoryStore):
        """Creating a memory should create version 1."""
        data = MemoryCreate(content="Version test", summary="V1")
        created = await memory_store.create(
            data=data, owner_id="usr_member", team_id="team_test"
        )

        versions = await memory_store.get_versions(created.id)
        assert len(versions) == 1
        assert versions[0].version == 1
        assert versions[0].change_type == "created"

    @pytest.mark.asyncio
    async def test_update_creates_version(self, memory_store: MemoryStore):
        """Updating a memory should create a new version."""
        data = MemoryCreate(content="Original", summary="V1")
        created = await memory_store.create(
            data=data, owner_id="usr_member", team_id="team_test"
        )

        await memory_store.update(
            memory_id=created.id,
            data=MemoryUpdate(content="Updated", summary="V2"),
            changed_by="usr_member",
        )

        versions = await memory_store.get_versions(created.id)
        assert len(versions) == 2
        assert versions[0].version == 2  # Newest first
        assert versions[0].change_type == "updated"


# ========== 范围 & 类别 Filtering Tests ==========


class TestFiltering:
    """Test scope and category filtering."""

    @pytest.fixture
    def memory_store(self, seeded_db: Database, tmp_data_dir: str) -> MemoryStore:
        file_store = MemoryFileStore(os.path.join(tmp_data_dir, "test_filter"))
        return MemoryStore(seeded_db, file_store)

    @pytest.mark.asyncio
    async def test_scope_filter(self, memory_store: MemoryStore):
        """Should filter by scope."""
        # Create team memory
        await memory_store.create(
            data=MemoryCreate(content="Team", summary="Team", scope=Memory范围.TEAM),
            owner_id="usr_member", team_id="team_test",
        )
        # Create private memory
        await memory_store.create(
            data=MemoryCreate(content="Private", summary="Private", scope=Memory范围.PRIVATE),
            owner_id="usr_member", team_id="team_test",
        )

        # Filter team only
        memories, total = await memory_store.list_memories(
            team_id="team_test", user_id="usr_member", scope="team"
        )
        assert all(m.scope == "team" for m in memories)
        assert total >= 1

    @pytest.mark.asyncio
    async def test_category_filter(self, memory_store: MemoryStore):
        """Should filter by category."""
        await memory_store.create(
            data=MemoryCreate(
                content="Decision", summary="Dec",
                scope=Memory范围.TEAM, category=Memory类别.DECISION,
            ),
            owner_id="usr_member", team_id="team_test",
        )
        await memory_store.create(
            data=MemoryCreate(
                content="Bug", summary="Bug",
                scope=Memory范围.TEAM, category=Memory类别.BUG_FIX,
            ),
            owner_id="usr_member", team_id="team_test",
        )

        memories, _ = await memory_store.list_memories(
            team_id="team_test", user_id="usr_member", category="decision"
        )
        assert all(m.category == "decision" for m in memories)

    @pytest.mark.asyncio
    async def test_private_isolation(self, memory_store: MemoryStore):
        """Private memories should only be visible to owner."""
        # Member creates private memory
        await memory_store.create(
            data=MemoryCreate(content="Secret", summary="Secret", scope=Memory范围.PRIVATE),
            owner_id="usr_member", team_id="team_test",
        )

        # Member sees it
        member_memories, _ = await memory_store.list_memories(
            team_id="team_test", user_id="usr_member"
        )
        private_count = sum(1 for m in member_memories if m.scope == "private")
        assert private_count >= 1

        # Admin from same team does NOT see private memories (unless they own it)
        admin_memories, _ = await memory_store.list_memories(
            team_id="team_test", user_id="usr_admin"
        )
        admin_private = [m for m in admin_memories if m.scope == "private" and m.owner_id == "usr_member"]
        assert len(admin_private) == 0

    @pytest.mark.asyncio
    async def test_archived_excluded_by_default(self, memory_store: MemoryStore):
        """Archived memories should not appear in default listing."""
        data = MemoryCreate(content="Archive", summary="Archive", scope=Memory范围.TEAM)
        created = await memory_store.create(
            data=data, owner_id="usr_member", team_id="team_test"
        )
        await memory_store.update_quality(created.id, "archived", "system")

        memories, _ = await memory_store.list_memories(
            team_id="team_test", user_id="usr_member"
        )
        archived_ids = [m.id for m in memories if m.id == created.id]
        assert len(archived_ids) == 0

    @pytest.mark.asyncio
    async def test_pagination(self, memory_store: MemoryStore):
        """Pagination should work correctly."""
        for i in range(5):
            await memory_store.create(
                data=MemoryCreate(content=f"Page {i}", summary=f"P{i}", scope=Memory范围.TEAM),
                owner_id="usr_member", team_id="team_test",
            )

        page1, total = await memory_store.list_memories(
            team_id="team_test", user_id="usr_member", page=1, page_size=2
        )
        assert len(page1) == 2
        assert total >= 5

        page2, _ = await memory_store.list_memories(
            team_id="team_test", user_id="usr_member", page=2, page_size=2
        )
        assert len(page2) == 2
        assert page1[0].id != page2[0].id
