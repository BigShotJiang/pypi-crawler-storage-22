"""Tests for preference engine: user prefs, team defaults, suggestions."""

from __future__ import annotations

import pytest
import pytest_asyncio

from team_memory_hub.core.preference_engine import PreferenceEngine
from team_memory_hub.storage.database import Database


@pytest_asyncio.fixture
async def db():
    database = Database(":memory:")
    await database.initialize()

    # Seed test data
    await database.execute(
        "INSERT INTO teams (id, name) VALUES ('t1', 'Test Team')"
    )
    await database.execute(
        "INSERT INTO users (id, name, email, team_id, role) VALUES ('u1', 'User1', 'u1@t.com', 't1', 'member')"
    )
    await database.execute(
        "INSERT INTO users (id, name, email, team_id, role) VALUES ('u2', 'User2', 'u2@t.com', 't1', 'maintainer')"
    )
    await database.commit()

    yield database
    await database.close()


@pytest_asyncio.fixture
async def engine(db):
    return PreferenceEngine(db)


class TestUserPreferences:
    @pytest.mark.asyncio
    async def test_set_and_get(self, engine: PreferenceEngine):
        """Set and retrieve a user preference."""
        await engine.set_user_preference("u1", "editor", "indent_size", "4")
        prefs = await engine.list_user_preferences("u1")
        assert len(prefs) == 1
        assert prefs[0]["key"] == "indent_size"
        assert prefs[0]["value"] == "4"

    @pytest.mark.asyncio
    async def test_upsert(self, engine: PreferenceEngine):
        """Upsert overwrites existing preference."""
        await engine.set_user_preference("u1", "editor", "indent_size", "4")
        await engine.set_user_preference("u1", "editor", "indent_size", "2")
        prefs = await engine.list_user_preferences("u1")
        assert len(prefs) == 1
        assert prefs[0]["value"] == "2"

    @pytest.mark.asyncio
    async def test_delete(self, engine: PreferenceEngine):
        """删除 a user preference."""
        await engine.set_user_preference("u1", "editor", "indent_size", "4")
        deleted = await engine.delete_user_preference("u1", "editor", "indent_size")
        assert deleted

        prefs = await engine.list_user_preferences("u1")
        assert len(prefs) == 0

    @pytest.mark.asyncio
    async def test_filter_by_category(self, engine: PreferenceEngine):
        """Filter preferences by category."""
        await engine.set_user_preference("u1", "editor", "indent_size", "4")
        await engine.set_user_preference("u1", "git", "auto_commit", "false")

        editor_prefs = await engine.list_user_preferences("u1", category="editor")
        assert len(editor_prefs) == 1
        assert editor_prefs[0]["category"] == "editor"


class TestTeamDefaults:
    @pytest.mark.asyncio
    async def test_set_and_list(self, engine: PreferenceEngine):
        """Set and list team defaults."""
        await engine.set_team_default("t1", "editor", "indent_size", "4", "u2")
        defaults = await engine.list_team_defaults("t1")
        assert len(defaults) == 1
        assert defaults[0]["value"] == "4"

    @pytest.mark.asyncio
    async def test_upsert_default(self, engine: PreferenceEngine):
        """Upsert overwrites existing default."""
        await engine.set_team_default("t1", "editor", "indent_size", "4", "u2")
        await engine.set_team_default("t1", "editor", "indent_size", "2", "u2")
        defaults = await engine.list_team_defaults("t1")
        assert len(defaults) == 1
        assert defaults[0]["value"] == "2"

    @pytest.mark.asyncio
    async def test_delete_default(self, engine: PreferenceEngine):
        """删除 a team default."""
        await engine.set_team_default("t1", "editor", "indent_size", "4", "u2")
        deleted = await engine.delete_team_default("t1", "editor", "indent_size")
        assert deleted

        defaults = await engine.list_team_defaults("t1")
        assert len(defaults) == 0


class TestEffectivePreferences:
    @pytest.mark.asyncio
    async def test_team_default_only(self, engine: PreferenceEngine):
        """Team default shown when no user preference."""
        await engine.set_team_default("t1", "editor", "indent_size", "4", "u2")

        effective = await engine.get_effective_preferences("u1", "t1", "editor")
        assert "editor:indent_size" in effective
        assert effective["editor:indent_size"]["source"] == "team_default"
        assert effective["editor:indent_size"]["value"] == "4"

    @pytest.mark.asyncio
    async def test_user_overrides_team(self, engine: PreferenceEngine):
        """User preference overrides team default."""
        await engine.set_team_default("t1", "editor", "indent_size", "4", "u2")
        await engine.set_user_preference("u1", "editor", "indent_size", "2")

        effective = await engine.get_effective_preferences("u1", "t1", "editor")
        assert effective["editor:indent_size"]["source"] == "user"
        assert effective["editor:indent_size"]["value"] == "2"

    @pytest.mark.asyncio
    async def test_get_single_preference(self, engine: PreferenceEngine):
        """Get a single effective preference value."""
        await engine.set_team_default("t1", "editor", "indent_size", "4", "u2")

        value = await engine.get_preference("u1", "t1", "editor", "indent_size")
        assert value == "4"


class TestPreferenceSuggestions:
    @pytest.mark.asyncio
    async def test_create_suggestion(self, engine: PreferenceEngine):
        """Create a preference suggestion."""
        sug_id = await engine.create_suggestion(
            user_id="u1",
            category="editor",
            key="theme",
            value="dark",
            evidence="User consistently used dark mode in 5 sessions",
        )
        assert sug_id.startswith("psug_")

        suggestions = await engine.list_suggestions("u1")
        assert len(suggestions) == 1
        assert suggestions[0]["value"] == "dark"

    @pytest.mark.asyncio
    async def test_accept_suggestion(self, engine: PreferenceEngine):
        """Accept a suggestion and apply it as preference."""
        sug_id = await engine.create_suggestion("u1", "editor", "theme", "dark")
        accepted = await engine.accept_suggestion(sug_id, "u1")
        assert accepted

        # Check preference was created
        prefs = await engine.list_user_preferences("u1")
        assert len(prefs) == 1
        assert prefs[0]["value"] == "dark"

        # Check suggestion status
        suggestions = await engine.list_suggestions("u1", status="accepted")
        assert len(suggestions) == 1

    @pytest.mark.asyncio
    async def test_reject_suggestion(self, engine: PreferenceEngine):
        """Reject a preference suggestion."""
        sug_id = await engine.create_suggestion("u1", "editor", "theme", "dark")
        rejected = await engine.reject_suggestion(sug_id, "u1")
        assert rejected

        pending = await engine.list_suggestions("u1", status="pending")
        assert len(pending) == 0

    @pytest.mark.asyncio
    async def test_accept_wrong_user(self, engine: PreferenceEngine):
        """Cannot accept another user's suggestion."""
        sug_id = await engine.create_suggestion("u1", "editor", "theme", "dark")
        accepted = await engine.accept_suggestion(sug_id, "u2")
        assert not accepted
