"""Tests for project onboarding: detector, normalizer, deduplicator, matcher."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

import pytest

from team_memory_hub.core.project_detector import ProjectDetector, ProjectProfile
from team_memory_hub.core.rule_normalizer import NormalizedRule, RuleNormalizer
from team_memory_hub.core.spec_deduplicator import (
    DeduplicationResult,
    SpecDeduplicator,
    load_overrides,
    save_conflict_resolutions,
    save_overrides,
)
from team_memory_hub.core.spec_matcher import SpecApplicability, SpecCondition, SpecMatcher


# ========== ProjectDetector Tests ==========

class TestProjectDetector:
    def test_detect_python_project(self, tmp_path: Path):
        """Detect a Python project with pyproject.toml."""
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "my-project"\n\n[tool.ruff]\nline-length = 100\n'
        )
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "main.py").write_text("print('hello')")

        detector = ProjectDetector(tmp_path)
        profile = detector.detect()

        assert "python" in profile.languages
        assert "ruff" in profile.linters
        assert profile.name == tmp_path.name

    def test_detect_javascript_project(self, tmp_path: Path):
        """Detect a JavaScript/Node.js project."""
        (tmp_path / "package.json").write_text(json.dumps({
            "name": "my-js-project",
            "dependencies": {"react": "^18.0.0"},
        }))
        (tmp_path / "package-lock.json").write_text("{}")
        (tmp_path / "index.js").write_text("console.log('hello')")

        detector = ProjectDetector(tmp_path)
        profile = detector.detect()

        assert "javascript" in profile.languages
        assert "npm" in profile.package_managers
        assert "react" in profile.frameworks

    def test_detect_docker(self, tmp_path: Path):
        """Detect Docker files."""
        (tmp_path / "Dockerfile").write_text("FROM python:3.11")
        (tmp_path / "docker-compose.yml").write_text("version: '3'")

        detector = ProjectDetector(tmp_path)
        profile = detector.detect()

        assert profile.has_docker
        assert "Dockerfile" in profile.docker_files

    def test_detect_ci(self, tmp_path: Path):
        """Detect CI configuration."""
        gh_dir = tmp_path / ".github" / "workflows"
        gh_dir.mkdir(parents=True)
        (gh_dir / "ci.yml").write_text("name: CI")

        detector = ProjectDetector(tmp_path)
        profile = detector.detect()

        assert "github-actions" in profile.ci_providers

    def test_detect_monorepo(self, tmp_path: Path):
        """Detect monorepo indicators."""
        (tmp_path / "package.json").write_text(json.dumps({
            "name": "my-monorepo",
            "workspaces": ["packages/*"],
        }))

        detector = ProjectDetector(tmp_path)
        profile = detector.detect()

        assert profile.monorepo

    def test_detect_test_frameworks(self, tmp_path: Path):
        """Detect test framework files."""
        (tmp_path / "conftest.py").write_text("import pytest")
        (tmp_path / "pyproject.toml").write_text('[tool.pytest.ini_options]\ntestpaths = ["tests"]\n')

        detector = ProjectDetector(tmp_path)
        profile = detector.detect()

        assert "pytest" in profile.test_frameworks

    def test_to_dict(self, tmp_path: Path):
        """Test ProjectProfile serialization."""
        detector = ProjectDetector(tmp_path)
        profile = detector.detect()
        d = profile.to_dict()

        assert isinstance(d, dict)
        assert "root_path" in d
        assert "languages" in d

    def test_empty_directory(self, tmp_path: Path):
        """Handle empty directory gracefully."""
        detector = ProjectDetector(tmp_path)
        profile = detector.detect()

        assert profile.languages == []
        assert profile.frameworks == []
        assert not profile.has_docker


# ========== RuleNormalizer Tests ==========

class TestRuleNormalizer:
    def test_parse_editorconfig(self, tmp_path: Path):
        """Parse .editorconfig file."""
        (tmp_path / ".editorconfig").write_text(
            "root = true\n\n[*]\nindent_style = space\nindent_size = 4\nmax_line_length = 100\n"
        )

        normalizer = RuleNormalizer(tmp_path)
        rules = normalizer.normalize_all()

        indent_rules = [r for r in rules if r.key == "indent_style"]
        assert len(indent_rules) >= 1
        assert indent_rules[0].value == "space"
        assert indent_rules[0].source == "editorconfig"

    def test_parse_prettier(self, tmp_path: Path):
        """Parse .prettierrc file."""
        (tmp_path / ".prettierrc").write_text(json.dumps({
            "tabWidth": 2,
            "useTabs": False,
            "singleQuote": True,
            "printWidth": 80,
        }))

        normalizer = RuleNormalizer(tmp_path)
        rules = normalizer.normalize_all()

        tab_rules = [r for r in rules if r.key == "indent_size"]
        assert len(tab_rules) >= 1
        assert tab_rules[0].value == 2

        quote_rules = [r for r in rules if r.key == "quote_style"]
        assert len(quote_rules) >= 1
        assert quote_rules[0].value == "single"

    def test_parse_eslint_json(self, tmp_path: Path):
        """Parse .eslintrc.json file."""
        (tmp_path / ".eslintrc.json").write_text(json.dumps({
            "rules": {
                "semi": [2, "always"],
                "quotes": [1, "single"],
                "no-console": 0,
            },
            "extends": ["eslint:recommended"],
        }))

        normalizer = RuleNormalizer(tmp_path)
        rules = normalizer.normalize_all()

        eslint_rules = [r for r in rules if r.source == "eslint"]
        assert len(eslint_rules) > 0

        semi_rules = [r for r in eslint_rules if r.key == "semicolons"]
        assert len(semi_rules) == 1
        assert semi_rules[0].severity == "error"

    def test_no_configs(self, tmp_path: Path):
        """Handle missing config files gracefully."""
        normalizer = RuleNormalizer(tmp_path)
        rules = normalizer.normalize_all()
        assert rules == []


# ========== SpecDeduplicator Tests ==========

class TestSpecDeduplicator:
    def test_equivalent_rules(self):
        """Detect equivalent rules between TMH and project."""
        tmh_rules = [
            NormalizedRule(source="tmh", category="formatting", key="indent_size", value=4),
        ]
        project_rules = [
            NormalizedRule(source="editorconfig", category="formatting", key="indent_size", value=4),
        ]

        dedup = SpecDeduplicator()
        result = dedup.compare(tmh_rules, project_rules)

        assert len(result.equivalent) == 1
        assert len(result.conflicts) == 0

    def test_conflicting_rules(self):
        """Detect conflicting rules."""
        tmh_rules = [
            NormalizedRule(source="tmh", category="formatting", key="indent_size", value=4),
        ]
        project_rules = [
            NormalizedRule(source="editorconfig", category="formatting", key="indent_size", value=2),
        ]

        dedup = SpecDeduplicator()
        result = dedup.compare(tmh_rules, project_rules)

        assert len(result.conflicts) == 1
        assert result.has_conflicts

    def test_unique_rules(self):
        """Detect rules unique to each side."""
        tmh_rules = [
            NormalizedRule(source="tmh", category="formatting", key="max_line_length", value=100),
        ]
        project_rules = [
            NormalizedRule(source="eslint", category="linting", key="no_console", value=True),
        ]

        dedup = SpecDeduplicator()
        result = dedup.compare(tmh_rules, project_rules)

        assert len(result.tmh_only) == 1
        assert len(result.project_only) == 1

    def test_resolve_project_wins(self):
        """Test conflict resolution: project wins."""
        tmh_rules = [
            NormalizedRule(source="tmh", category="formatting", key="indent_size", value=4),
        ]
        project_rules = [
            NormalizedRule(source="prettier", category="formatting", key="indent_size", value=2),
        ]

        dedup = SpecDeduplicator()
        result = dedup.compare(tmh_rules, project_rules)
        result = dedup.resolve_conflicts(result, strategy="project_wins")

        assert result.conflicts[0].resolution == "use_project"
        assert result.conflicts[0].resolved_value == 2

    def test_boolean_equivalence(self):
        """Test boolean value equivalence."""
        tmh_rules = [
            NormalizedRule(source="tmh", category="formatting", key="trim_ws", value=True),
        ]
        project_rules = [
            NormalizedRule(source="editorconfig", category="formatting", key="trim_ws", value="true"),
        ]

        dedup = SpecDeduplicator()
        result = dedup.compare(tmh_rules, project_rules)

        assert len(result.equivalent) == 1

    def test_overrides_persistence(self, tmp_path: Path):
        """Test saving and loading overrides."""
        overrides = {"rules": {"indent_size:*": {"resolution": "use_project", "value": 2}}}
        save_overrides(tmp_path, overrides)

        loaded = load_overrides(tmp_path)
        assert loaded["rules"]["indent_size:*"]["resolution"] == "use_project"

    def test_summary(self):
        """Test result summary."""
        dedup = SpecDeduplicator()
        result = dedup.compare([], [])
        summary = result.summary()
        assert summary == {
            "equivalent": 0, "conflicts": 0, "tmh_only": 0, "project_only": 0,
        }


# ========== SpecMatcher Tests ==========

class TestSpecMatcher:
    def _make_profile(self, **kwargs) -> ProjectProfile:
        defaults = {
            "root_path": "/test",
            "name": "test-project",
            "languages": [],
            "frameworks": [],
            "package_managers": [],
        }
        defaults.update(kwargs)
        return ProjectProfile(**defaults)

    def test_match_by_language(self):
        """Match spec by language condition."""
        spec = SpecApplicability(
            spec_path="python_standards.md",
            team_id="team1",
            conditions=[SpecCondition("language", "python")],
        )

        matcher = SpecMatcher([spec])
        profile = self._make_profile(languages=["python", "javascript"])
        applicable = matcher.find_applicable(profile)

        assert len(applicable) == 1
        assert applicable[0].spec_path == "python_standards.md"

    def test_match_by_framework(self):
        """Match spec by framework condition."""
        spec = SpecApplicability(
            spec_path="react_guidelines.md",
            team_id="team1",
            conditions=[SpecCondition("framework", "react")],
        )

        matcher = SpecMatcher([spec])
        profile = self._make_profile(frameworks=["react", "next.js"])
        applicable = matcher.find_applicable(profile)

        assert len(applicable) == 1

    def test_no_match(self):
        """No match when conditions don't apply."""
        spec = SpecApplicability(
            spec_path="go_standards.md",
            team_id="team1",
            conditions=[SpecCondition("language", "go")],
        )

        matcher = SpecMatcher([spec])
        profile = self._make_profile(languages=["python"])
        applicable = matcher.find_applicable(profile)

        assert len(applicable) == 0

    def test_always_condition(self):
        """Always condition matches everything."""
        spec = SpecApplicability(
            spec_path="general.md",
            team_id="team1",
            conditions=[SpecCondition("always", "true")],
        )

        matcher = SpecMatcher([spec])
        profile = self._make_profile()
        applicable = matcher.find_applicable(profile)

        assert len(applicable) == 1

    def test_file_pattern_match(self):
        """Match spec by file pattern."""
        spec = SpecApplicability(
            spec_path="test_standards.md",
            team_id="team1",
            conditions=[SpecCondition("file_pattern", "*.test.ts")],
        )

        matcher = SpecMatcher([spec])
        profile = self._make_profile(languages=["typescript"])

        # With matching file
        applicable = matcher.find_applicable(profile, file_path="utils.test.ts")
        assert len(applicable) == 1

        # Without matching file
        applicable = matcher.find_applicable(profile, file_path="utils.ts")
        assert len(applicable) == 0

    def test_find_by_language(self):
        """Find specs by language."""
        specs = [
            SpecApplicability("py.md", "t1", [SpecCondition("language", "python")]),
            SpecApplicability("js.md", "t1", [SpecCondition("language", "javascript")]),
        ]

        matcher = SpecMatcher(specs)
        py_specs = matcher.find_by_language("python")

        assert len(py_specs) == 1
        assert py_specs[0].spec_path == "py.md"
