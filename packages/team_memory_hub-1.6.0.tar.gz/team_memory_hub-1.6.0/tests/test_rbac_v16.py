"""V1.6 权限系统测试：覆盖优先级、过期忽略、向后兼容。"""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

import pytest

from team_memory_hub.core.rbac import (
    PERMISSIONS,
    check_permission,
    check_permission_with_overrides,
)
from team_memory_hub.storage.database import Database
from team_memory_hub.storage.models import UserRole


@pytest.fixture
async def db():
    """创建内存数据库并初始化。"""
    database = Database(":memory:")
    await database.initialize()
    # 插入测试团队和用户
    await database.execute(
        "INSERT INTO teams (id, name) VALUES (?, ?)",
        ("team_test", "Test Team"),
    )
    await database.execute(
        "INSERT INTO users (id, name, email, role, team_id) VALUES (?, ?, ?, ?, ?)",
        ("usr_admin", "Admin", "admin@test.com", "admin", "team_test"),
    )
    await database.execute(
        "INSERT INTO users (id, name, email, role, team_id) VALUES (?, ?, ?, ?, ?)",
        ("usr_member", "Member", "member@test.com", "member", "team_test"),
    )
    await database.execute(
        "INSERT INTO users (id, name, email, role, team_id) VALUES (?, ?, ?, ?, ?)",
        ("usr_maintainer", "Maintainer", "maintainer@test.com", "maintainer", "team_test"),
    )
    await database.commit()
    yield database
    await database.close()


# ========== 向后兼容性 ==========

class TestCheckPermissionBackwardCompat:
    """原始 check_permission 保持不变。"""

    def test_admin_has_all(self):
        assert check_permission(UserRole.ADMIN, "memory:read_team") is True
        assert check_permission(UserRole.ADMIN, "team:create") is True

    def test_member_limited(self):
        assert check_permission(UserRole.MEMBER, "memory:write_team") is True
        assert check_permission(UserRole.MEMBER, "team:create") is False

    def test_viewer_read_only(self):
        assert check_permission(UserRole.VIEWER, "memory:read_team") is True
        assert check_permission(UserRole.VIEWER, "memory:write_team") is False

    def test_unknown_action(self):
        assert check_permission(UserRole.ADMIN, "nonexistent:action") is False


# ========== V1.6 新权限点 ==========

class TestNewPermissionPoints:
    """所有新增权限点已注册。"""

    @pytest.mark.parametrize("perm", [
        "team:create", "team:update", "team:delete", "team:list",
        "project:create", "project:update", "project:delete", "project:list",
        "user:create", "user:update", "user:delete", "user:list", "user:toggle_active",
        "key:list_all", "key:revoke_any",
        "curation:batch_verify", "curation:batch_archive", "curation:quality_override",
        "system:view_config", "system:update_config",
    ])
    def test_permission_registered(self, perm: str):
        assert perm in PERMISSIONS


# ========== 覆盖机制 ==========

class TestPermissionOverrides:
    """check_permission_with_overrides 的覆盖优先级测试。"""

    @pytest.mark.asyncio
    async def test_no_override_falls_back_to_role(self, db: Database):
        # member 无 team:create 权限
        result = await check_permission_with_overrides(
            UserRole.MEMBER, "team:create", "usr_member", db
        )
        assert result is False

    @pytest.mark.asyncio
    async def test_allow_override_grants_permission(self, db: Database):
        # 给 member 添加 allow 覆盖
        await db.execute(
            "INSERT INTO permission_overrides (id, user_id, permission, type, granted_by) VALUES (?, ?, ?, ?, ?)",
            (str(uuid.uuid4()), "usr_member", "team:create", "allow", "usr_admin"),
        )
        await db.commit()

        result = await check_permission_with_overrides(
            UserRole.MEMBER, "team:create", "usr_member", db
        )
        assert result is True

    @pytest.mark.asyncio
    async def test_deny_override_blocks_permission(self, db: Database):
        # 给 maintainer 添加 deny 覆盖（maintainer 默认有 curation:batch_verify）
        await db.execute(
            "INSERT INTO permission_overrides (id, user_id, permission, type, granted_by) VALUES (?, ?, ?, ?, ?)",
            (str(uuid.uuid4()), "usr_maintainer", "curation:batch_verify", "deny", "usr_admin"),
        )
        await db.commit()

        result = await check_permission_with_overrides(
            UserRole.MAINTAINER, "curation:batch_verify", "usr_maintainer", db
        )
        assert result is False

    @pytest.mark.asyncio
    async def test_expired_override_ignored(self, db: Database):
        # 添加已过期的 allow 覆盖
        expired = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        await db.execute(
            "INSERT INTO permission_overrides (id, user_id, permission, type, granted_by, expires_at) VALUES (?, ?, ?, ?, ?, ?)",
            (str(uuid.uuid4()), "usr_member", "team:delete", "allow", "usr_admin", expired),
        )
        await db.commit()

        # member 默认无 team:delete，过期覆盖应被忽略
        result = await check_permission_with_overrides(
            UserRole.MEMBER, "team:delete", "usr_member", db
        )
        assert result is False

    @pytest.mark.asyncio
    async def test_future_override_applied(self, db: Database):
        # 添加未过期的 allow 覆盖
        future = (datetime.now(timezone.utc) + timedelta(days=7)).isoformat()
        await db.execute(
            "INSERT INTO permission_overrides (id, user_id, permission, type, granted_by, expires_at) VALUES (?, ?, ?, ?, ?, ?)",
            (str(uuid.uuid4()), "usr_member", "project:delete", "allow", "usr_admin", future),
        )
        await db.commit()

        result = await check_permission_with_overrides(
            UserRole.MEMBER, "project:delete", "usr_member", db
        )
        assert result is True
