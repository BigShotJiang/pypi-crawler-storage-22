"""安全审计修复回归测试 — 2026-02-13 审查报告中 7 个缺陷的验证。"""

from __future__ import annotations

import secrets

import pytest
from httpx import ASGITransport, AsyncClient

from team_memory_hub.server.app import create_app
from team_memory_hub.storage.database import Database


# ========== Fixtures ==========


@pytest.fixture
async def app_and_db(test_config):
    """创建测试应用并初始化内存数据库。"""
    app = create_app()
    db = Database(":memory:")
    await db.initialize()
    app.state.db = db

    # 团队 A
    await db.execute("INSERT INTO teams (id, name) VALUES (?, ?)", ("team_a", "Team A"))
    # 团队 B
    await db.execute("INSERT INTO teams (id, name) VALUES (?, ?)", ("team_b", "Team B"))

    from team_memory_hub.server.routes.auth import hash_password

    # 团队 A 的用户
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id, password_hash) VALUES (?, ?, ?, ?, ?, ?)",
        ("usr_admin_a", "Admin A", "admin_a@test.com", "admin", "team_a", hash_password("pass")),
    )
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id, password_hash) VALUES (?, ?, ?, ?, ?, ?)",
        ("usr_maint_a", "Maint A", "maint_a@test.com", "maintainer", "team_a", hash_password("pass")),
    )
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id, password_hash) VALUES (?, ?, ?, ?, ?, ?)",
        ("usr_member_a", "Member A", "member_a@test.com", "member", "team_a", hash_password("pass")),
    )

    # 团队 B 的用户
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id, password_hash) VALUES (?, ?, ?, ?, ?, ?)",
        ("usr_maint_b", "Maint B", "maint_b@test.com", "maintainer", "team_b", hash_password("pass")),
    )

    await db.commit()
    yield app, db
    await db.close()


def _make_key():
    return "tmh_" + secrets.token_hex(24)


async def _create_api_key(db, key_id, user_id, scope="full_access"):
    key = _make_key()
    await db.execute(
        "INSERT INTO api_keys (id, key, user_id, name, scope) VALUES (?, ?, ?, ?, ?)",
        (key_id, key, user_id, f"Key {key_id}", scope),
    )
    await db.commit()
    return key


async def _make_client(app, key):
    transport = ASGITransport(app=app)
    return AsyncClient(transport=transport, base_url="http://test", headers={"Authorization": f"Bearer {key}"})


async def _insert_memory(db, memory_id, team_id, owner_id, scope="team", quality="community"):
    """直接插入记忆到数据库。"""
    await db.execute(
        """INSERT INTO memories (id, summary, file_path, owner_id, scope, team_id, category, tags, quality, quality_score, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))""",
        (memory_id, f"Test {memory_id}", f"/fake/{memory_id}.md", owner_id, scope, team_id, "general", "[]", quality, 0.5),
    )
    await db.commit()


# ========== 1. 注册接口角色限制 ==========


class TestRegisterRoleForced:
    """高危 #1: 注册接口不应允许自设管理员。"""

    @pytest.mark.asyncio
    async def test_register_ignores_admin_role(self, app_and_db):
        app, db = app_and_db
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            resp = await client.post("/api/v1/auth/register", json={
                "name": "Evil",
                "email": "evil@test.com",
                "password": "password123",
                "role": "admin",
                "team_id": "team_a",
            })
            assert resp.status_code == 201
            data = resp.json()
            assert data["role"] == "member"

        # 验证数据库中角色也是 member
        row = await db.fetch_one("SELECT role FROM users WHERE email = ?", ("evil@test.com",))
        assert row["role"] == "member"


# ========== 2. 私有记忆隔离 ==========


class TestPrivateMemoryIsolation:
    """高危 #2: 列表接口不应泄露他人私有记忆。"""

    @pytest.mark.asyncio
    async def test_list_hides_others_private(self, app_and_db):
        app, db = app_and_db

        # member_a 的私有记忆
        await _insert_memory(db, "mem_private1", "team_a", "usr_member_a", scope="private")
        # maint_a 的团队记忆
        await _insert_memory(db, "mem_team1", "team_a", "usr_maint_a", scope="team")

        key = await _create_api_key(db, "key_maint_a", "usr_maint_a")
        async with await _make_client(app, key) as client:
            resp = await client.get("/api/v1/memories")
            assert resp.status_code == 200
            items = resp.json()["items"]
            # maint_a 不应看到 member_a 的私有记忆
            private_from_others = [m for m in items if m["id"] == "mem_private1"]
            assert len(private_from_others) == 0
            # 但应看到团队记忆
            team_mems = [m for m in items if m["id"] == "mem_team1"]
            assert len(team_mems) == 1


# ========== 3. 质量接口资源级权限 ==========


class TestQualityLifecyclePermissions:
    """高危 #3: 质量接口应检查 team_id 和角色。"""

    @pytest.mark.asyncio
    async def test_verify_cross_team_rejected(self, app_and_db):
        app, db = app_and_db
        await _insert_memory(db, "mem_a1", "team_a", "usr_member_a")

        # 团队 B 的维护者尝试验证团队 A 的记忆
        key = await _create_api_key(db, "key_maint_b_v", "usr_maint_b")
        async with await _make_client(app, key) as client:
            resp = await client.post("/api/v1/memories/mem_a1/verify")
            assert resp.status_code == 403

    @pytest.mark.asyncio
    async def test_stale_member_non_owner_rejected(self, app_and_db):
        app, db = app_and_db
        # maint_a 创建的记忆
        await _insert_memory(db, "mem_maint1", "team_a", "usr_maint_a")

        # member_a (非 owner, 非 maintainer) 尝试标记 stale
        key = await _create_api_key(db, "key_member_a_s", "usr_member_a")
        async with await _make_client(app, key) as client:
            resp = await client.post("/api/v1/memories/mem_maint1/stale")
            assert resp.status_code == 403

    @pytest.mark.asyncio
    async def test_stale_owner_allowed(self, app_and_db):
        app, db = app_and_db
        await _insert_memory(db, "mem_own1", "team_a", "usr_member_a")

        key = await _create_api_key(db, "key_member_a_o", "usr_member_a")
        async with await _make_client(app, key) as client:
            resp = await client.post("/api/v1/memories/mem_own1/stale")
            assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_archive_member_non_owner_rejected(self, app_and_db):
        app, db = app_and_db
        await _insert_memory(db, "mem_arch1", "team_a", "usr_maint_a")

        key = await _create_api_key(db, "key_member_a_a", "usr_member_a")
        async with await _make_client(app, key) as client:
            resp = await client.post("/api/v1/memories/mem_arch1/archive")
            assert resp.status_code == 403

    @pytest.mark.asyncio
    async def test_pin_cross_team_rejected(self, app_and_db):
        app, db = app_and_db
        await _insert_memory(db, "mem_pin1", "team_a", "usr_member_a")

        key = await _create_api_key(db, "key_maint_b_p", "usr_maint_b")
        async with await _make_client(app, key) as client:
            resp = await client.post("/api/v1/memories/mem_pin1/pin")
            assert resp.status_code == 403


# ========== 4. API Key scope 强制 ==========


class TestApiKeyScopeEnforcement:
    """高危 #4: API Key scope 应被强制执行。"""

    @pytest.mark.asyncio
    async def test_read_only_key_write_rejected(self, app_and_db):
        app, db = app_and_db
        key = await _create_api_key(db, "key_ro", "usr_admin_a", scope="read_only")
        async with await _make_client(app, key) as client:
            resp = await client.post("/api/v1/memories", json={
                "content": "Test", "summary": "Test",
            })
            assert resp.status_code == 403
            assert "scope" in resp.json()["detail"].lower()

    @pytest.mark.asyncio
    async def test_read_only_key_read_allowed(self, app_and_db):
        app, db = app_and_db
        key = await _create_api_key(db, "key_ro2", "usr_admin_a", scope="read_only")
        async with await _make_client(app, key) as client:
            resp = await client.get("/api/v1/memories")
            assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_full_access_key_write_allowed(self, app_and_db):
        app, db = app_and_db
        key = await _create_api_key(db, "key_full", "usr_admin_a", scope="full_access")
        async with await _make_client(app, key) as client:
            resp = await client.get("/api/v1/memories")
            assert resp.status_code == 200


# ========== 5. 管理端审核跨租户过滤 ==========


class TestCurationTeamFilter:
    """高危 #5: 审核接口应按团队过滤。"""

    @pytest.mark.asyncio
    async def test_curation_list_only_own_team(self, app_and_db):
        app, db = app_and_db
        await _insert_memory(db, "mem_cur_a", "team_a", "usr_member_a", quality="community")
        await _insert_memory(db, "mem_cur_b", "team_b", "usr_maint_b", quality="community")

        key = await _create_api_key(db, "key_admin_cur", "usr_admin_a")
        async with await _make_client(app, key) as client:
            resp = await client.get("/api/v1/admin/curation/memories")
            assert resp.status_code == 200
            items = resp.json()["items"]
            # 只应看到团队 A 的记忆
            team_ids = {m["team_id"] for m in items}
            assert "team_b" not in team_ids

    @pytest.mark.asyncio
    async def test_batch_curation_cross_team_rejected(self, app_and_db):
        app, db = app_and_db
        await _insert_memory(db, "mem_batch_b", "team_b", "usr_maint_b", quality="community")

        key = await _create_api_key(db, "key_admin_batch", "usr_admin_a")
        async with await _make_client(app, key) as client:
            resp = await client.post("/api/v1/admin/curation/batch", json={
                "memory_ids": ["mem_batch_b"],
                "action": "verify",
            })
            assert resp.status_code == 403


# ========== 6. 布尔值转换修复 ==========


class TestBoolConversion:
    """中危 #6: 布尔转换应正确处理。"""

    @pytest.mark.asyncio
    async def test_false_string_converts_correctly(self, app_and_db):
        app, db = app_and_db
        key = await _create_api_key(db, "key_admin_bool", "usr_admin_a")
        async with await _make_client(app, key) as client:
            resp = await client.patch("/api/v1/admin/system/config", json={
                "updates": {"consolidation.enabled": "false"},
            })
            assert resp.status_code == 200
            data = resp.json()
            if "consolidation.enabled" in data.get("updated", {}):
                assert data["updated"]["consolidation.enabled"] is False

    @pytest.mark.asyncio
    async def test_invalid_bool_rejected(self, app_and_db):
        app, db = app_and_db
        key = await _create_api_key(db, "key_admin_bool2", "usr_admin_a")
        async with await _make_client(app, key) as client:
            resp = await client.patch("/api/v1/admin/system/config", json={
                "updates": {"consolidation.enabled": "maybe"},
            })
            assert resp.status_code == 200
            data = resp.json()
            assert "consolidation.enabled" in data.get("errors", {})


# ========== 7. 审计日志 user_id 注入 ==========


class TestAuditUserIdInjection:
    """中危 #7: 审计日志应记录实际 user_id。"""

    @pytest.mark.asyncio
    async def test_request_state_user_id_set(self, app_and_db):
        """验证认证成功后 request.state.user_id 被正确设置。"""
        app, db = app_and_db
        key = await _create_api_key(db, "key_audit", "usr_admin_a")

        captured_user_id = None

        @app.middleware("http")
        async def capture_user_id(request, call_next):
            nonlocal captured_user_id
            response = await call_next(request)
            if hasattr(request.state, "user_id"):
                captured_user_id = request.state.user_id
            return response

        async with await _make_client(app, key) as client:
            resp = await client.get("/api/v1/memories")
            assert resp.status_code == 200

        assert captured_user_id == "usr_admin_a"
