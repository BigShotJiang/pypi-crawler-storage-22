"""Tests for spec manager: file operations, proposals, and delta merging."""

from __future__ import annotations

import json
import os
import tempfile

import pytest
import pytest_asyncio
import yaml

from team_memory_hub.core.spec_manager import SpecManager, _set_nested, _delete_nested
from team_memory_hub.storage.database import Database


@pytest_asyncio.fixture
async def db() -> Database:
    database = Database(":memory:")
    await database.initialize()
    yield database
    await database.close()


@pytest_asyncio.fixture
async def seeded_db(db: Database) -> Database:
    """DB with test team."""
    await db.execute(
        "INSERT INTO teams (id, name) VALUES (?, ?)",
        ("team_test", "Test Team"),
    )
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id) VALUES (?, ?, ?, ?, ?)",
        ("usr_1", "User1", "u1@test.com", "maintainer", "team_test"),
    )
    await db.commit()
    return db


@pytest.fixture
def specs_dir():
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
def manager(specs_dir: str, seeded_db: Database) -> SpecManager:
    return SpecManager(specs_dir=specs_dir, db=seeded_db)


# ==================== Nested Dict Utility Tests ====================


class TestNestedDictUtils:
    def test_set_nested_simple(self):
        data = {}
        _set_nested(data, "key", "value")
        assert data == {"key": "value"}

    def test_set_nested_deep(self):
        data = {}
        _set_nested(data, "a.b.c", "value")
        assert data == {"a": {"b": {"c": "value"}}}

    def test_set_nested_overwrite(self):
        data = {"a": {"b": "old"}}
        _set_nested(data, "a.b", "new")
        assert data["a"]["b"] == "new"

    def test_delete_nested_simple(self):
        data = {"key": "value"}
        _delete_nested(data, "key")
        assert "key" not in data

    def test_delete_nested_deep(self):
        data = {"a": {"b": {"c": "value"}}}
        _delete_nested(data, "a.b.c")
        assert "c" not in data["a"]["b"]

    def test_delete_nested_nonexistent(self):
        data = {"a": 1}
        _delete_nested(data, "b.c")  # Should not raise


# ==================== Spec File Tests ====================


class TestSpecFiles:
    def test_list_specs_empty(self, manager: SpecManager):
        specs = manager.list_specs("team_test")
        assert specs == []

    def test_write_and_read_yaml_spec(self, manager: SpecManager):
        content = yaml.dump({"coding": {"indent": 4, "max_line": 100}})
        result = manager.write_spec("team_test/coding.yaml", content, "team_test")

        assert result["path"] == "team_test/coding.yaml"
        assert result["fingerprint"]

        # Read back
        spec = manager.read_spec("team_test/coding.yaml")
        assert spec["parsed"]["coding"]["indent"] == 4
        assert spec["fingerprint"] == result["fingerprint"]

    def test_write_and_read_md_spec(self, manager: SpecManager):
        content = "# API Guidelines\n\nUse REST conventions."
        manager.write_spec("team_test/api.md", content, "team_test")

        spec = manager.read_spec("team_test/api.md")
        assert spec["content"] == content
        assert spec["parsed"] is None  # Not YAML

    def test_list_specs_finds_files(self, manager: SpecManager):
        manager.write_spec("team_test/a.yaml", "key: value", "team_test")
        manager.write_spec("team_test/b.md", "# Title", "team_test")

        specs = manager.list_specs("team_test")
        paths = [s["path"] for s in specs]
        assert len(specs) == 2
        # Paths should be relative
        assert any("a.yaml" in p for p in paths)
        assert any("b.md" in p for p in paths)

    def test_read_nonexistent_spec(self, manager: SpecManager):
        with pytest.raises(FileNotFoundError):
            manager.read_spec("nonexistent.yaml")

    def test_fingerprint_consistency(self, manager: SpecManager):
        content = "test content"
        r1 = manager.write_spec("team_test/f1.yaml", content, "team_test")
        r2 = manager.write_spec("team_test/f2.yaml", content, "team_test")
        assert r1["fingerprint"] == r2["fingerprint"]

    def test_fingerprint_changes_on_update(self, manager: SpecManager):
        r1 = manager.write_spec("team_test/f.yaml", "version: 1", "team_test")
        r2 = manager.write_spec("team_test/f.yaml", "version: 2", "team_test")
        assert r1["fingerprint"] != r2["fingerprint"]


# ==================== Proposal Tests ====================


class TestProposals:
    @pytest.mark.asyncio
    async def test_create_proposal(self, manager: SpecManager):
        delta = {
            "changes": [
                {"action": "ADDED", "path": "rules.new_rule", "value": "Always test"},
            ]
        }
        proposal = await manager.create_proposal(
            title="Add new rule",
            description="Adding a testing rule",
            target_spec="team_test/coding.yaml",
            delta=delta,
            author_id="usr_1",
            team_id="team_test",
        )
        assert proposal["id"].startswith("prop_")
        assert proposal["status"] == "draft"
        assert proposal["title"] == "Add new rule"

    @pytest.mark.asyncio
    async def test_get_proposal(self, manager: SpecManager):
        delta = {"changes": []}
        created = await manager.create_proposal(
            title="Test", description=None,
            target_spec="test.yaml", delta=delta,
            author_id="usr_1", team_id="team_test",
        )
        fetched = await manager.get_proposal(created["id"])
        assert fetched is not None
        assert fetched["id"] == created["id"]

    @pytest.mark.asyncio
    async def test_list_proposals(self, manager: SpecManager):
        delta = {"changes": []}
        await manager.create_proposal(
            title="P1", description=None,
            target_spec="t.yaml", delta=delta,
            author_id="usr_1", team_id="team_test",
        )
        await manager.create_proposal(
            title="P2", description=None,
            target_spec="t.yaml", delta=delta,
            author_id="usr_1", team_id="team_test",
        )

        proposals = await manager.list_proposals("team_test")
        assert len(proposals) == 2

    @pytest.mark.asyncio
    async def test_list_proposals_with_status_filter(self, manager: SpecManager):
        delta = {"changes": []}
        p = await manager.create_proposal(
            title="P1", description=None,
            target_spec="t.yaml", delta=delta,
            author_id="usr_1", team_id="team_test",
        )
        await manager.update_proposal_status(p["id"], "pending_review")

        drafts = await manager.list_proposals("team_test", status="draft")
        assert len(drafts) == 0

        pending = await manager.list_proposals("team_test", status="pending_review")
        assert len(pending) == 1

    @pytest.mark.asyncio
    async def test_update_proposal_status(self, manager: SpecManager):
        delta = {"changes": []}
        p = await manager.create_proposal(
            title="Test", description=None,
            target_spec="t.yaml", delta=delta,
            author_id="usr_1", team_id="team_test",
        )
        updated = await manager.update_proposal_status(
            p["id"], "pending_review"
        )
        assert updated["status"] == "pending_review"


# ==================== Delta Merge Tests ====================


class TestDeltaMerge:
    @pytest.mark.asyncio
    async def test_merge_added(self, manager: SpecManager):
        """ADDED action should add new keys."""
        # Create initial spec
        initial = yaml.dump({"existing": "value"})
        manager.write_spec("team_test/merge_test.yaml", initial, "team_test")

        delta = {
            "changes": [
                {"action": "ADDED", "path": "new_key", "value": "new_value"},
            ]
        }
        p = await manager.create_proposal(
            title="Add key", description=None,
            target_spec="team_test/merge_test.yaml", delta=delta,
            author_id="usr_1", team_id="team_test",
        )
        result = await manager.merge_proposal(p["id"], "usr_1", "team_test")
        assert result["changes_applied"] == 1

        # Verify
        spec = manager.read_spec("team_test/merge_test.yaml")
        assert spec["parsed"]["new_key"] == "new_value"
        assert spec["parsed"]["existing"] == "value"

    @pytest.mark.asyncio
    async def test_merge_modified(self, manager: SpecManager):
        """MODIFIED action should update existing keys."""
        initial = yaml.dump({"key": "old_value"})
        manager.write_spec("team_test/mod_test.yaml", initial, "team_test")

        delta = {
            "changes": [
                {"action": "MODIFIED", "path": "key", "old_value": "old_value", "value": "new_value"},
            ]
        }
        p = await manager.create_proposal(
            title="Modify key", description=None,
            target_spec="team_test/mod_test.yaml", delta=delta,
            author_id="usr_1", team_id="team_test",
        )
        await manager.merge_proposal(p["id"], "usr_1", "team_test")

        spec = manager.read_spec("team_test/mod_test.yaml")
        assert spec["parsed"]["key"] == "new_value"

    @pytest.mark.asyncio
    async def test_merge_removed(self, manager: SpecManager):
        """REMOVED action should delete keys."""
        initial = yaml.dump({"keep": "yes", "remove": "this"})
        manager.write_spec("team_test/rm_test.yaml", initial, "team_test")

        delta = {
            "changes": [
                {"action": "REMOVED", "path": "remove"},
            ]
        }
        p = await manager.create_proposal(
            title="Remove key", description=None,
            target_spec="team_test/rm_test.yaml", delta=delta,
            author_id="usr_1", team_id="team_test",
        )
        await manager.merge_proposal(p["id"], "usr_1", "team_test")

        spec = manager.read_spec("team_test/rm_test.yaml")
        assert "remove" not in spec["parsed"]
        assert spec["parsed"]["keep"] == "yes"

    @pytest.mark.asyncio
    async def test_merge_nested_changes(self, manager: SpecManager):
        """Delta merge should handle nested paths."""
        initial = yaml.dump({"coding": {"indent": 2}})
        manager.write_spec("team_test/nested.yaml", initial, "team_test")

        delta = {
            "changes": [
                {"action": "MODIFIED", "path": "coding.indent", "value": 4},
                {"action": "ADDED", "path": "coding.max_line", "value": 100},
            ]
        }
        p = await manager.create_proposal(
            title="Nested", description=None,
            target_spec="team_test/nested.yaml", delta=delta,
            author_id="usr_1", team_id="team_test",
        )
        await manager.merge_proposal(p["id"], "usr_1", "team_test")

        spec = manager.read_spec("team_test/nested.yaml")
        assert spec["parsed"]["coding"]["indent"] == 4
        assert spec["parsed"]["coding"]["max_line"] == 100

    @pytest.mark.asyncio
    async def test_merge_creates_new_spec(self, manager: SpecManager):
        """Merging into a non-existent spec should create it."""
        delta = {
            "changes": [
                {"action": "ADDED", "path": "version", "value": "1.0"},
                {"action": "ADDED", "path": "rules.rule1", "value": "Be nice"},
            ]
        }
        p = await manager.create_proposal(
            title="New spec", description=None,
            target_spec="team_test/new_spec.yaml", delta=delta,
            author_id="usr_1", team_id="team_test",
        )
        await manager.merge_proposal(p["id"], "usr_1", "team_test")

        spec = manager.read_spec("team_test/new_spec.yaml")
        assert spec["parsed"]["version"] == "1.0"
        assert spec["parsed"]["rules"]["rule1"] == "Be nice"

    @pytest.mark.asyncio
    async def test_merge_updates_team_version(self, manager: SpecManager, seeded_db: Database):
        """Merging should increment the team's specs_version."""
        delta = {"changes": [{"action": "ADDED", "path": "k", "value": "v"}]}
        p = await manager.create_proposal(
            title="V bump", description=None,
            target_spec="team_test/v.yaml", delta=delta,
            author_id="usr_1", team_id="team_test",
        )
        await manager.merge_proposal(p["id"], "usr_1", "team_test")

        team = await seeded_db.fetch_one(
            "SELECT specs_version, specs_fingerprint FROM teams WHERE id = ?",
            ("team_test",),
        )
        assert team["specs_version"] == 1
        assert team["specs_fingerprint"] is not None

    @pytest.mark.asyncio
    async def test_cannot_merge_withdrawn(self, manager: SpecManager):
        """Cannot merge a withdrawn proposal."""
        delta = {"changes": []}
        p = await manager.create_proposal(
            title="W", description=None,
            target_spec="t.yaml", delta=delta,
            author_id="usr_1", team_id="team_test",
        )
        await manager.update_proposal_status(p["id"], "withdrawn")

        with pytest.raises(ValueError, match="Cannot merge"):
            await manager.merge_proposal(p["id"], "usr_1", "team_test")
