"""Tests for SSE event bus and streaming endpoint."""

from __future__ import annotations

import asyncio
import json

import pytest
import pytest_asyncio

from team_memory_hub.server.event_bus import EventBus, get_event_bus


# ========== EventBus Unit Tests ==========


class TestEventBus:
    def setup_method(self):
        self.bus = EventBus()

    @pytest.mark.asyncio
    async def test_publish_subscribe_wildcard(self):
        """Wildcard subscribers receive all events."""
        queue = self.bus.subscribe()  # defaults to ["*"]

        await self.bus.publish("memory.created", {"id": "mem_1"})
        event = queue.get_nowait()

        assert event["type"] == "memory.created"
        assert event["data"]["id"] == "mem_1"
        assert "timestamp" in event

    @pytest.mark.asyncio
    async def test_publish_subscribe_specific_type(self):
        """Type-specific subscribers only receive matching events."""
        queue = self.bus.subscribe(event_types=["memory.created"])

        await self.bus.publish("memory.created", {"id": "mem_1"})
        await self.bus.publish("memory.deleted", {"id": "mem_2"})

        assert queue.qsize() == 1
        event = queue.get_nowait()
        assert event["data"]["id"] == "mem_1"

    @pytest.mark.asyncio
    async def test_multiple_subscribers(self):
        """Multiple subscribers each get their own copy."""
        q1 = self.bus.subscribe(event_types=["test"])
        q2 = self.bus.subscribe(event_types=["test"])

        await self.bus.publish("test", {"value": 42})

        assert q1.qsize() == 1
        assert q2.qsize() == 1

    @pytest.mark.asyncio
    async def test_unsubscribe(self):
        """Unsubscribed queues no longer receive events."""
        queue = self.bus.subscribe(event_types=["test"])
        self.bus.unsubscribe(queue)

        await self.bus.publish("test", {"value": 1})

        assert queue.qsize() == 0

    @pytest.mark.asyncio
    async def test_queue_full_drops_event(self):
        """Events are dropped when queue is full instead of blocking."""
        queue = self.bus.subscribe(event_types=["test"], max_size=1)

        await self.bus.publish("test", {"v": 1})
        await self.bus.publish("test", {"v": 2})  # Should be dropped

        assert queue.qsize() == 1

    @pytest.mark.asyncio
    async def test_wildcard_and_specific_no_duplicate(self):
        """A subscriber to both '*' and a specific type doesn't get duplicates."""
        # Subscribe to wildcard
        q_wild = self.bus.subscribe()
        # Subscribe to specific
        q_spec = self.bus.subscribe(event_types=["memory.created"])

        await self.bus.publish("memory.created", {"id": "1"})

        assert q_wild.qsize() == 1
        assert q_spec.qsize() == 1


class TestGetEventBus:
    def test_singleton(self):
        """get_event_bus returns same instance."""
        bus1 = get_event_bus()
        bus2 = get_event_bus()
        assert bus1 is bus2


# ========== SSE Endpoint Tests ==========

@pytest.mark.asyncio
async def test_sse_endpoint_exists():
    """Verify the SSE route module can be imported."""
    from team_memory_hub.server.routes.events import router
    assert router is not None

    # Check that /stream route exists
    routes = [r.path for r in router.routes]
    assert "/stream" in routes
