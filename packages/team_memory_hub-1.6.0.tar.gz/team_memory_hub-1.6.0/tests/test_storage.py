"""Tests for storage engine: database, migrations, file store, write queue."""

from __future__ import annotations

import asyncio
import os
import tempfile

import pytest

from team_memory_hub.core.memory_file_store import MemoryFileStore
from team_memory_hub.core.write_queue import WriteOperation, WriteQueue
from team_memory_hub.storage.database import Database


# ========== Database Tests ==========


class TestDatabase:
    """Test async SQLite connection management."""

    @pytest.mark.asyncio
    async def test_initialize_creates_tables(self, db: Database):
        """V1 migration should create all required tables."""
        tables = await db.fetch_all(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        )
        table_names = {t["name"] for t in tables}

        expected = {
            "_meta", "teams", "users", "api_keys", "projects", "project_members",
            "memories", "memory_versions", "spec_proposals", "spec_applicability",
            "user_preferences", "team_default_preferences", "preference_suggestions",
            "chat_sessions", "audit_logs", "merge_suggestions",
        }
        assert expected.issubset(table_names), f"Missing tables: {expected - table_names}"

    @pytest.mark.asyncio
    async def test_wal_mode_enabled(self, db: Database):
        """WAL mode should be enabled."""
        row = await db.fetch_one("PRAGMA journal_mode")
        assert row is not None
        # In-memory databases may use 'memory' mode, which is fine for tests
        journal_mode = list(row.values())[0]
        assert journal_mode in ("wal", "memory")

    @pytest.mark.asyncio
    async def test_schema_version(self, db: Database):
        """Schema version should be set to current version."""
        row = await db.fetch_one(
            "SELECT value FROM _meta WHERE key = 'schema_version'"
        )
        assert row is not None
        assert int(row["value"]) == 3  # CURRENT_SCHEMA_VERSION (V1.6)

    @pytest.mark.asyncio
    async def test_foreign_keys_enabled(self, db: Database):
        """Foreign keys should be enabled."""
        row = await db.fetch_one("PRAGMA foreign_keys")
        assert row is not None
        assert list(row.values())[0] == 1

    @pytest.mark.asyncio
    async def test_execute_and_fetch(self, db: Database):
        """Test basic CRUD operations."""
        await db.execute(
            "INSERT INTO teams (id, name) VALUES (?, ?)",
            ("t1", "Test Team"),
        )
        await db.commit()

        row = await db.fetch_one("SELECT * FROM teams WHERE id = ?", ("t1",))
        assert row is not None
        assert row["name"] == "Test Team"

    @pytest.mark.asyncio
    async def test_fetch_all(self, db: Database):
        """Test fetching multiple rows."""
        await db.execute("INSERT INTO teams (id, name) VALUES (?, ?)", ("t1", "Team 1"))
        await db.execute("INSERT INTO teams (id, name) VALUES (?, ?)", ("t2", "Team 2"))
        await db.commit()

        rows = await db.fetch_all("SELECT * FROM teams ORDER BY id")
        assert len(rows) == 2
        assert rows[0]["id"] == "t1"
        assert rows[1]["id"] == "t2"

    @pytest.mark.asyncio
    async def test_fetch_one_returns_none(self, db: Database):
        """fetch_one should return None for no results."""
        row = await db.fetch_one("SELECT * FROM teams WHERE id = ?", ("nonexistent",))
        assert row is None


# ========== V1.5 Migration Tests ==========


class TestV15Migration:
    """Test V1.5 schema additions."""

    @pytest.mark.asyncio
    async def test_merged_into_column(self, db: Database):
        """memories table should have merged_into column."""
        # Insert a memory and check merged_into works
        await db.execute(
            "INSERT INTO teams (id, name) VALUES (?, ?)", ("t1", "T1")
        )
        await db.execute(
            """INSERT INTO users (id, name, email, role, team_id)
               VALUES (?, ?, ?, ?, ?)""",
            ("u1", "User", "u@t.com", "member", "t1"),
        )
        await db.execute(
            """INSERT INTO memories (id, summary, file_path, owner_id, team_id, merged_into)
               VALUES (?, ?, ?, ?, ?, ?)""",
            ("mem_1", "test", "path.md", "u1", "t1", "mem_2"),
        )
        await db.commit()

        row = await db.fetch_one("SELECT merged_into FROM memories WHERE id = ?", ("mem_1",))
        assert row is not None
        assert row["merged_into"] == "mem_2"

    @pytest.mark.asyncio
    async def test_merge_suggestions_table(self, db: Database):
        """merge_suggestions table should exist."""
        await db.execute(
            "INSERT INTO teams (id, name) VALUES (?, ?)", ("t1", "T1")
        )
        await db.execute(
            """INSERT INTO merge_suggestions
               (id, team_id, original_ids, merged_content, scope, avg_similarity, confidence)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            ("ms_1", "t1", '["mem_1","mem_2"]', "merged text", "team", 0.9, 0.85),
        )
        await db.commit()

        row = await db.fetch_one("SELECT * FROM merge_suggestions WHERE id = ?", ("ms_1",))
        assert row is not None
        assert row["status"] == "pending"

    @pytest.mark.asyncio
    async def test_fts5_table_exists(self, db: Database):
        """memories_fts virtual table should exist."""
        tables = await db.fetch_all(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='memories_fts'"
        )
        assert len(tables) == 1


# ========== File Store Tests ==========


class TestMemoryFileStore:
    """Test file system memory storage."""

    @pytest.fixture
    def file_store(self, tmp_data_dir: str) -> MemoryFileStore:
        return MemoryFileStore(os.path.join(tmp_data_dir, "memories"))

    def test_write_and_read(self, file_store: MemoryFileStore):
        """Write and read a memory file."""
        rel_path, file_hash, file_size = file_store.write_memory(
            memory_id="mem_testid01",
            content="# Test Memory\n\nThis is test content.",
            metadata={"category": "decision", "tags": ["test"]},
            scope="team",
        )

        assert rel_path.endswith("mem_testid01.md")
        assert file_hash is not None
        assert file_size > 0

        # Read back
        metadata, content = file_store.read_memory(rel_path)
        assert metadata["id"] == "mem_testid01"
        assert metadata["scope"] == "team"
        assert "This is test content." in content

    def test_write_private_scope(self, file_store: MemoryFileStore):
        """Private scope should use user subdirectory."""
        rel_path, _, _ = file_store.write_memory(
            memory_id="mem_priv0001",
            content="Private note",
            metadata={},
            scope="private",
            owner_name="alice",
        )
        assert "private" in rel_path
        assert "alice" in rel_path

    def test_write_project_scope(self, file_store: MemoryFileStore):
        """Project scope should use project subdirectory."""
        rel_path, _, _ = file_store.write_memory(
            memory_id="mem_proj0001",
            content="Project note",
            metadata={},
            scope="project",
            project_name="myproject",
        )
        assert "projects" in rel_path
        assert "myproject" in rel_path

    def test_delete_memory(self, file_store: MemoryFileStore):
        """删除 should remove the file."""
        rel_path, _, _ = file_store.write_memory(
            memory_id="mem_del00001",
            content="To be deleted",
            metadata={},
            scope="team",
        )
        assert file_store.file_exists(rel_path)

        result = file_store.delete_memory(rel_path)
        assert result is True
        assert not file_store.file_exists(rel_path)

    def test_delete_nonexistent(self, file_store: MemoryFileStore):
        """删除 of nonexistent file should return False."""
        assert file_store.delete_memory("nonexistent.md") is False

    def test_compute_hash(self, file_store: MemoryFileStore):
        """Hash computation should be deterministic."""
        rel_path, original_hash, _ = file_store.write_memory(
            memory_id="mem_hash0001",
            content="Hash test",
            metadata={},
            scope="team",
        )
        computed_hash = file_store.compute_hash(rel_path)
        assert computed_hash == original_hash

    def test_frontmatter_parsing(self):
        """Test YAML front-matter parsing."""
        text = """---
id: mem_test
scope: team
tags: [a, b]
---

# Content here
Body text."""
        metadata, content = MemoryFileStore._parse_frontmatter(text)
        assert metadata["id"] == "mem_test"
        assert metadata["tags"] == ["a", "b"]
        assert "Content here" in content
        assert "Body text." in content

    def test_no_frontmatter(self):
        """Text without front-matter should return empty metadata."""
        text = "Just plain text"
        metadata, content = MemoryFileStore._parse_frontmatter(text)
        assert metadata == {}
        assert content == "Just plain text"


# ========== Write Queue Tests ==========


class TestWriteQueue:
    """Test async write queue with batching."""

    @pytest.mark.asyncio
    async def test_batch_execution(self):
        """Queue should batch multiple writes."""
        executed_batches: list[list[WriteOperation]] = []

        async def mock_execute(batch: list[WriteOperation]):
            executed_batches.append(batch)

        queue = WriteQueue(
            execute_batch=mock_execute,
            batch_timeout_ms=50,
            batch_max_size=5,
        )
        await queue.start()

        # Enqueue 3 items quickly
        await asyncio.gather(
            queue.enqueue("INSERT 1"),
            queue.enqueue("INSERT 2"),
            queue.enqueue("INSERT 3"),
        )

        await queue.stop()

        # Should have been batched together
        total_ops = sum(len(b) for b in executed_batches)
        assert total_ops == 3

    @pytest.mark.asyncio
    async def test_max_batch_size(self):
        """Queue should flush when max_batch_size is reached."""
        executed_batches: list[list[WriteOperation]] = []

        async def mock_execute(batch: list[WriteOperation]):
            executed_batches.append(batch)

        queue = WriteQueue(
            execute_batch=mock_execute,
            batch_timeout_ms=5000,  # Long timeout so size limit triggers first
            batch_max_size=3,
        )
        await queue.start()

        # Enqueue items - the first 3 should trigger a batch
        tasks = []
        for i in range(6):
            tasks.append(queue.enqueue(f"INSERT {i}"))

        await asyncio.gather(*tasks)
        await queue.stop()

        total_ops = sum(len(b) for b in executed_batches)
        assert total_ops == 6

    @pytest.mark.asyncio
    async def test_flush_on_stop(self):
        """Remaining items should be flushed on stop."""
        executed: list[WriteOperation] = []

        async def mock_execute(batch: list[WriteOperation]):
            executed.extend(batch)

        queue = WriteQueue(
            execute_batch=mock_execute,
            batch_timeout_ms=5000,
            batch_max_size=100,
        )
        await queue.start()

        await queue.enqueue_nowait("INSERT 1")
        await queue.enqueue_nowait("INSERT 2")

        # Give a moment for processing
        await asyncio.sleep(0.1)
        await queue.stop()

        assert len(executed) >= 2
