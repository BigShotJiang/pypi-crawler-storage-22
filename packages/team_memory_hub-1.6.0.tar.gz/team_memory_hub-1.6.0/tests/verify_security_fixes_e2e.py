"""端到端验证脚本：通过 HTTP API 验证全部 7 个安全修复。

运行: python -m pytest tests/verify_security_fixes_e2e.py -v
"""

from __future__ import annotations

import secrets

import pytest
from httpx import ASGITransport, AsyncClient

from team_memory_hub.server.app import create_app
from team_memory_hub.server.routes.auth import hash_password
from team_memory_hub.storage.database import Database


@pytest.fixture
async def live_app(test_config):
    """完整的应用实例，模拟真实部署环境。"""
    app = create_app()
    db = Database(":memory:")
    await db.initialize()
    app.state.db = db

    # === 种子数据 ===
    # 两个团队
    await db.execute("INSERT INTO teams (id, name) VALUES ('team_alpha', 'Alpha')")
    await db.execute("INSERT INTO teams (id, name) VALUES ('team_beta', 'Beta')")

    # Alpha 团队用户
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id, password_hash) VALUES (?, ?, ?, ?, ?, ?)",
        ("usr_admin_a", "Admin A", "admin_a@t.com", "admin", "team_alpha", hash_password("pass")),
    )
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id, password_hash) VALUES (?, ?, ?, ?, ?, ?)",
        ("usr_maint_a", "Maint A", "maint_a@t.com", "maintainer", "team_alpha", hash_password("pass")),
    )
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id, password_hash) VALUES (?, ?, ?, ?, ?, ?)",
        ("usr_member_a", "Member A", "member_a@t.com", "member", "team_alpha", hash_password("pass")),
    )

    # Beta 团队用户
    await db.execute(
        "INSERT INTO users (id, name, email, role, team_id, password_hash) VALUES (?, ?, ?, ?, ?, ?)",
        ("usr_maint_b", "Maint B", "maint_b@t.com", "maintainer", "team_beta", hash_password("pass")),
    )

    # API Keys — 不同 scope
    def _key():
        return "tmh_" + secrets.token_hex(24)

    keys = {}
    for kid, uid, scope in [
        ("k_admin_a", "usr_admin_a", "full_access"),
        ("k_maint_a", "usr_maint_a", "full_access"),
        ("k_member_a", "usr_member_a", "full_access"),
        ("k_maint_b", "usr_maint_b", "full_access"),
        ("k_readonly", "usr_admin_a", "read_only"),
        ("k_mcp", "usr_admin_a", "mcp_only"),
    ]:
        k = _key()
        keys[kid] = k
        await db.execute(
            "INSERT INTO api_keys (id, key, user_id, name, scope) VALUES (?, ?, ?, ?, ?)",
            (kid, k, uid, kid, scope),
        )

    # 记忆数据
    for mid, team, owner, scope, quality in [
        ("mem_team_a1", "team_alpha", "usr_member_a", "team", "community"),
        ("mem_priv_a1", "team_alpha", "usr_member_a", "private", "community"),
        ("mem_team_a2", "team_alpha", "usr_maint_a", "team", "community"),
        ("mem_team_b1", "team_beta", "usr_maint_b", "team", "community"),
    ]:
        await db.execute(
            """INSERT INTO memories (id, summary, file_path, owner_id, scope, team_id, category, tags, quality, quality_score, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, 'general', '[]', ?, 0.5, datetime('now'), datetime('now'))""",
            (mid, f"Summary of {mid}", f"/fake/{mid}.md", owner, scope, team, quality),
        )

    await db.commit()

    yield app, db, keys
    await db.close()


def _client(app, key):
    return AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
        headers={"Authorization": f"Bearer {key}"},
    )


# ============================================================
# 验证 #1: 注册接口角色限制
# ============================================================

class TestVerify1_RegisterRoleForced:
    """[高危] 注册接口提交 role=admin 后实际角色应为 member。"""

    @pytest.mark.asyncio
    async def test_register_with_admin_role_gets_member(self, live_app):
        app, db, keys = live_app
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as c:
            r = await c.post("/api/v1/auth/register", json={
                "name": "Attacker", "email": "attacker@evil.com",
                "password": "pw", "role": "admin", "team_id": "team_alpha",
            })
        assert r.status_code == 201
        assert r.json()["role"] == "member", "注册角色未被强制为 member"
        # DB 验证
        row = await db.fetch_one("SELECT role FROM users WHERE email='attacker@evil.com'")
        assert row["role"] == "member", "数据库中角色未被强制为 member"
        print("✅ #1 PASS: 注册接口角色已强制为 member")

    @pytest.mark.asyncio
    async def test_register_with_maintainer_role_gets_member(self, live_app):
        app, db, keys = live_app
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as c:
            r = await c.post("/api/v1/auth/register", json={
                "name": "Sneaky", "email": "sneaky@evil.com",
                "password": "pw", "role": "maintainer", "team_id": "team_alpha",
            })
        assert r.status_code == 201
        assert r.json()["role"] == "member"
        print("✅ #1 PASS: maintainer 角色也被强制为 member")


# ============================================================
# 验证 #2: 私有记忆隔离
# ============================================================

class TestVerify2_PrivateMemoryIsolation:
    """[高危] 其他用户调用列表接口不应看到他人私有记忆。"""

    @pytest.mark.asyncio
    async def test_maint_cannot_see_member_private(self, live_app):
        app, db, keys = live_app
        async with _client(app, keys["k_maint_a"]) as c:
            r = await c.get("/api/v1/memories")
        assert r.status_code == 200
        items = r.json()["items"]
        leaked = [m for m in items if m["id"] == "mem_priv_a1"]
        assert len(leaked) == 0, f"泄露了私有记忆: {leaked}"
        print("✅ #2 PASS: 他人私有记忆已隐藏")

    @pytest.mark.asyncio
    async def test_owner_can_see_own_private(self, live_app):
        app, db, keys = live_app
        async with _client(app, keys["k_member_a"]) as c:
            r = await c.get("/api/v1/memories")
        assert r.status_code == 200
        items = r.json()["items"]
        own_priv = [m for m in items if m["id"] == "mem_priv_a1"]
        assert len(own_priv) == 1, "所有者应能看到自己的私有记忆"
        print("✅ #2 PASS: 所有者可见自己的私有记忆")


# ============================================================
# 验证 #3: 质量接口资源级权限
# ============================================================

class TestVerify3_QualityLifecyclePermissions:
    """[高危] 质量接口应检查 team_id 和角色。"""

    @pytest.mark.asyncio
    async def test_verify_cross_team_403(self, live_app):
        app, db, keys = live_app
        async with _client(app, keys["k_maint_b"]) as c:
            r = await c.post("/api/v1/memories/mem_team_a1/verify")
        assert r.status_code == 403, f"跨团队 verify 应返回 403，实际 {r.status_code}"
        print("✅ #3 PASS: 跨团队 verify 被拒绝")

    @pytest.mark.asyncio
    async def test_stale_non_owner_member_403(self, live_app):
        app, db, keys = live_app
        # mem_team_a2 属于 maint_a, member_a 尝试标记 stale
        async with _client(app, keys["k_member_a"]) as c:
            r = await c.post("/api/v1/memories/mem_team_a2/stale")
        assert r.status_code == 403, f"非 owner member 标记 stale 应返回 403，实际 {r.status_code}"
        print("✅ #3 PASS: 非 owner member 标记 stale 被拒绝")

    @pytest.mark.asyncio
    async def test_stale_owner_200(self, live_app):
        app, db, keys = live_app
        async with _client(app, keys["k_member_a"]) as c:
            r = await c.post("/api/v1/memories/mem_team_a1/stale")
        assert r.status_code == 200, f"owner 标记 stale 应返回 200，实际 {r.status_code}"
        print("✅ #3 PASS: owner 标记 stale 成功")

    @pytest.mark.asyncio
    async def test_archive_non_owner_member_403(self, live_app):
        app, db, keys = live_app
        async with _client(app, keys["k_member_a"]) as c:
            r = await c.post("/api/v1/memories/mem_team_a2/archive")
        assert r.status_code == 403
        print("✅ #3 PASS: 非 owner member 归档被拒绝")

    @pytest.mark.asyncio
    async def test_pin_cross_team_403(self, live_app):
        app, db, keys = live_app
        async with _client(app, keys["k_maint_b"]) as c:
            r = await c.post("/api/v1/memories/mem_team_a1/pin")
        assert r.status_code == 403
        print("✅ #3 PASS: 跨团队 pin 被拒绝")

    @pytest.mark.asyncio
    async def test_verify_same_team_maint_200(self, live_app):
        app, db, keys = live_app
        async with _client(app, keys["k_maint_a"]) as c:
            r = await c.post("/api/v1/memories/mem_team_a2/verify")
        assert r.status_code == 200
        assert r.json()["quality"] == "verified"
        print("✅ #3 PASS: 同团队 maintainer verify 成功")


# ============================================================
# 验证 #4: API Key scope 强制
# ============================================================

class TestVerify4_ApiKeyScopeEnforcement:
    """[高危] API Key scope 应被强制执行。"""

    @pytest.mark.asyncio
    async def test_read_only_write_403(self, live_app):
        app, db, keys = live_app
        async with _client(app, keys["k_readonly"]) as c:
            r = await c.post("/api/v1/memories", json={"content": "x", "summary": "x"})
        assert r.status_code == 403, f"read_only 写操作应 403，实际 {r.status_code}"
        assert "scope" in r.json()["detail"].lower()
        print("✅ #4 PASS: read_only key 写操作被拒绝")

    @pytest.mark.asyncio
    async def test_read_only_read_200(self, live_app):
        app, db, keys = live_app
        async with _client(app, keys["k_readonly"]) as c:
            r = await c.get("/api/v1/memories")
        assert r.status_code == 200
        print("✅ #4 PASS: read_only key 读操作正常")

    @pytest.mark.asyncio
    async def test_mcp_only_non_mcp_403(self, live_app):
        app, db, keys = live_app
        async with _client(app, keys["k_mcp"]) as c:
            r = await c.get("/api/v1/memories")
        assert r.status_code == 403, f"mcp_only 非 MCP 路由应 403，实际 {r.status_code}"
        print("✅ #4 PASS: mcp_only key 非 MCP 路由被拒绝")

    @pytest.mark.asyncio
    async def test_full_access_all_ok(self, live_app):
        app, db, keys = live_app
        async with _client(app, keys["k_admin_a"]) as c:
            r = await c.get("/api/v1/memories")
        assert r.status_code == 200
        print("✅ #4 PASS: full_access key 正常通过")


# ============================================================
# 验证 #5: 管理端审核跨租户过滤
# ============================================================

class TestVerify5_CurationTeamFilter:
    """[高危] 审核接口应按团队过滤。"""

    @pytest.mark.asyncio
    async def test_curation_list_filtered_by_team(self, live_app):
        app, db, keys = live_app
        async with _client(app, keys["k_admin_a"]) as c:
            r = await c.get("/api/v1/admin/curation/memories")
        assert r.status_code == 200
        items = r.json()["items"]
        leaked = [m for m in items if m.get("team_id") == "team_beta"]
        assert len(leaked) == 0, f"泄露了其他团队记忆: {leaked}"
        print("✅ #5 PASS: 审核列表已按团队过滤")

    @pytest.mark.asyncio
    async def test_batch_cross_team_403(self, live_app):
        app, db, keys = live_app
        async with _client(app, keys["k_admin_a"]) as c:
            r = await c.post("/api/v1/admin/curation/batch", json={
                "memory_ids": ["mem_team_b1"], "action": "verify",
            })
        assert r.status_code == 403, f"跨团队批量操作应 403，实际 {r.status_code}"
        print("✅ #5 PASS: 跨团队批量审核被拒绝")

    @pytest.mark.asyncio
    async def test_batch_same_team_ok(self, live_app):
        app, db, keys = live_app
        async with _client(app, keys["k_admin_a"]) as c:
            r = await c.post("/api/v1/admin/curation/batch", json={
                "memory_ids": ["mem_team_a2"], "action": "verify",
            })
        assert r.status_code == 200
        assert r.json()["updated"] == 1
        print("✅ #5 PASS: 同团队批量审核成功")


# ============================================================
# 验证 #6: 布尔值转换修复
# ============================================================

class TestVerify6_BoolConversion:
    """[中危] 布尔转换应正确处理 'false' 字符串。"""

    @pytest.mark.asyncio
    async def test_false_string_is_false(self, live_app):
        app, db, keys = live_app
        async with _client(app, keys["k_admin_a"]) as c:
            r = await c.patch("/api/v1/admin/system/config", json={
                "updates": {"consolidation.enabled": "false"},
            })
        assert r.status_code == 200
        data = r.json()
        assert data["updated"]["consolidation.enabled"] is False, \
            f"'false' 应转为 False，实际 {data['updated'].get('consolidation.enabled')}"
        print("✅ #6 PASS: 'false' 正确转为 False")

    @pytest.mark.asyncio
    async def test_true_string_is_true(self, live_app):
        app, db, keys = live_app
        async with _client(app, keys["k_admin_a"]) as c:
            r = await c.patch("/api/v1/admin/system/config", json={
                "updates": {"consolidation.enabled": "true"},
            })
        assert r.status_code == 200
        assert r.json()["updated"]["consolidation.enabled"] is True
        print("✅ #6 PASS: 'true' 正确转为 True")

    @pytest.mark.asyncio
    async def test_invalid_bool_error(self, live_app):
        app, db, keys = live_app
        async with _client(app, keys["k_admin_a"]) as c:
            r = await c.patch("/api/v1/admin/system/config", json={
                "updates": {"consolidation.enabled": "maybe"},
            })
        assert r.status_code == 200
        assert "consolidation.enabled" in r.json()["errors"]
        print("✅ #6 PASS: 无效布尔值被正确拒绝")


# ============================================================
# 验证 #7: 审计日志 user_id 注入
# ============================================================

class TestVerify7_AuditUserIdInjection:
    """[中危] 认证后 request.state.user_id 应为实际用户 ID。"""

    @pytest.mark.asyncio
    async def test_user_id_injected_into_request_state(self, live_app):
        app, db, keys = live_app

        captured = {}

        @app.middleware("http")
        async def capture(request, call_next):
            resp = await call_next(request)
            if hasattr(request.state, "user_id"):
                captured["user_id"] = request.state.user_id
            return resp

        async with _client(app, keys["k_admin_a"]) as c:
            await c.get("/api/v1/memories")

        assert captured.get("user_id") == "usr_admin_a", \
            f"user_id 应为 usr_admin_a，实际 {captured.get('user_id')}"
        print("✅ #7 PASS: request.state.user_id 正确注入")

    @pytest.mark.asyncio
    async def test_api_key_scope_injected(self, live_app):
        app, db, keys = live_app

        captured = {}

        @app.middleware("http")
        async def capture2(request, call_next):
            resp = await call_next(request)
            if hasattr(request.state, "api_key_scope"):
                captured["scope"] = request.state.api_key_scope
            return resp

        async with _client(app, keys["k_readonly"]) as c:
            await c.get("/api/v1/memories")

        assert captured.get("scope") == "read_only", \
            f"scope 应为 read_only，实际 {captured.get('scope')}"
        print("✅ #7 PASS: request.state.api_key_scope 正确注入")
