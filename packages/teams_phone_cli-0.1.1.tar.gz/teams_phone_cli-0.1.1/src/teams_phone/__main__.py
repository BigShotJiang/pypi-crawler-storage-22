"""Entry point for running as python -m teams_phone."""

from teams_phone.cli.main import app

if __name__ == "__main__":
    app()
