"""CLI Layer - Typer commands for Teams Phone management."""

from teams_phone.cli.context import CLIContext, get_context
from teams_phone.cli.main import app

__all__ = ["CLIContext", "app", "get_context"]
