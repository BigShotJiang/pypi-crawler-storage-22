"""Tenant profile models for multi-tenant CLI configuration."""

from enum import Enum
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class AuthMethod(str, Enum):
    """Authentication methods supported for tenant profiles.

    Attributes:
        CERTIFICATE: Certificate-based authentication using X.509 certificate.
        CLIENT_SECRET: Client secret authentication (less secure, for dev/test).
    """

    CERTIFICATE = "certificate"
    CLIENT_SECRET = "client-secret"


class TenantProfile(BaseModel):
    """Configuration for a Microsoft Entra tenant.

    Represents a tenant profile stored in config.toml for multi-tenant
    CLI operations. Supports both certificate and client-secret authentication.

    Attributes:
        name: Profile name used as key in configuration (e.g., "contoso").
        tenant_id: Microsoft Entra tenant ID (UUID).
        client_id: App registration client ID (UUID).
        display_name: Human-readable tenant name for display.
        auth_method: Authentication method (certificate or client-secret).
        cert_path: Path to certificate file (required if auth_method is certificate).
        default_location: Default emergency location name for number assignments.
    """

    model_config = ConfigDict(extra="forbid")

    name: str
    tenant_id: UUID
    client_id: UUID
    display_name: str
    auth_method: AuthMethod
    cert_path: Optional[str] = None
    default_location: Optional[str] = None
