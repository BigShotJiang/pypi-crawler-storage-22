# Refactoring Analysis

Analysis of code duplication, file sizes, and complexity in the Teams Phone CLI codebase.

## Summary

| Category | Finding | Impact |
|----------|---------|--------|
| Large Test Files | 6 files over 1,400 lines | High - AI agents struggle with context |
| Large Source Files | 2 files over 600 lines | Medium - maintainability concerns |
| Test Mock Duplication | ~300+ repeated mock patterns | High - maintenance burden |
| Factory Function Duplication | 5 functions defined multiple times | Medium - inconsistency risk |
| CLI Helper Duplication | `_run_async` duplicated 3x | Low - but violates DRY |
| Complexity (Ruff C901) | No violations | Good |

---

## 1. Large Files (AI Agent Difficulty)

Files over 500 lines become difficult for AI agents to work with effectively due to context window limitations and difficulty tracking state across the file.

### Test Files (Critical)

| File | Lines | Recommendation |
|------|-------|----------------|
| `tests/unit/test_cli_numbers.py` | **3,501** | Split by command (list, show, assign, bulk) |
| `tests/unit/test_number_service.py` | **2,289** | Split by operation type |
| `tests/unit/test_models.py` | **2,089** | Split by model category |
| `tests/unit/test_auth_service.py` | **1,866** | Consider grouping by auth flow |
| `tests/unit/test_cli_policies.py` | **1,552** | Split by command |
| `tests/unit/test_bulk_operations.py` | **1,469** | Split validation vs execution |
| `tests/unit/test_graph_client.py` | **1,265** | Split by HTTP method |

### Source Files (Moderate Concern)

| File | Lines | Recommendation |
|------|-------|----------------|
| `src/teams_phone/cli/numbers.py` | **1,667** | Split into submodules (list, assign, bulk) |
| `src/teams_phone/cli/policies.py` | **892** | Acceptable but monitor |
| `src/teams_phone/infrastructure/graph_client.py` | **638** | Acceptable |
| `src/teams_phone/services/bulk_operations.py` | **561** | Acceptable |

---

## 2. Test Mock Duplication (High Priority)

### Problem: Repeated Mock Boilerplate

The following pattern appears **100+ times** across test files:

```python
with (
    patch("teams_phone.cli.numbers.CacheManager"),
    patch("teams_phone.cli.numbers.AuthService"),
    patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
    patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
):
    mock_gc = AsyncMock()
    mock_gc.__aenter__.return_value = mock_gc
    mock_gc.__aexit__.return_value = None
    mock_gc_class.return_value = mock_gc
    # ... service setup
```

**Metrics:**
- 120 occurrences of `patch.*GraphClient`
- 106 occurrences of `mock_gc.__aenter__` pattern
- 322 occurrences of CacheManager/AuthService patches
- 138 async context manager mocks in `test_cli_numbers.py` alone

### Recommendation: Create Shared Fixtures

Add to `tests/conftest.py`:

```python
@pytest.fixture
def mock_graph_client_context():
    """Fixture that provides a mock GraphClient as async context manager."""
    mock_gc = AsyncMock()
    mock_gc.__aenter__.return_value = mock_gc
    mock_gc.__aexit__.return_value = None
    return mock_gc

@pytest.fixture
def mock_cli_infrastructure(mock_graph_client_context):
    """Fixture that patches all CLI infrastructure components."""
    with (
        patch("teams_phone.cli.numbers.CacheManager"),
        patch("teams_phone.cli.numbers.AuthService"),
        patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
    ):
        mock_gc_class.return_value = mock_graph_client_context
        yield {
            "graph_client": mock_graph_client_context,
            "graph_client_class": mock_gc_class,
        }
```

---

## 3. Factory Function Duplication (Medium Priority)

### Duplicated Definitions

| Function | Defined In | Times |
|----------|------------|-------|
| `_make_user` | `test_cli_numbers.py:660`, `test_cli_policies.py:63`, `test_cli_users.py:29` | 3x |
| `_make_location` | `test_cli_locations.py:19`, `test_cli_numbers.py:681` | 2x |
| `_make_number` | `test_cli_numbers.py:34` | 1x (should be shared) |
| `_make_policy` | `test_cli_policies.py:23` | 1x (should be shared) |
| `_make_tenant` | `test_cli_tenants.py:24` | 1x (should be shared) |
| `_make_operation` | `test_cli_numbers.py:696` | 1x (should be shared) |

### Recommendation: Create `tests/fixtures/factories.py`

```python
"""Shared factory functions for creating test objects."""

from teams_phone.models import (
    NumberAssignment, UserConfiguration, EmergencyLocation,
    Policy, TenantInfo, AsyncOperation
)

def make_number(**kwargs) -> NumberAssignment:
    """Create a NumberAssignment with sensible defaults."""
    defaults = {
        "id": "num-123",
        "telephoneNumber": "+14255551234",
        "numberType": "directRouting",
        # ... other defaults
    }
    defaults.update(kwargs)
    return NumberAssignment.model_validate(defaults)

def make_user(**kwargs) -> UserConfiguration:
    """Create a UserConfiguration with sensible defaults."""
    # ...

# etc.
```

---

## 4. Source Code Duplication (Lower Priority)

### `_run_async` Pattern Duplicated

The same helper function is defined in 3 CLI modules:

- `src/teams_phone/cli/numbers.py:50` - `_run_async()`
- `src/teams_phone/cli/policies.py:162` - `_run_async()`
- `src/teams_phone/cli/users.py:42` - `_run_async()`

Each follows the same pattern:
```python
def _run_async(ctx, coro_factory) -> tuple[Any, OutputFormatter]:
    cli_ctx = get_context(ctx)
    formatter = cli_ctx.get_output_formatter()
    config_manager = cli_ctx.get_config_manager()
    cache_manager = CacheManager()
    auth_service = AuthService(config_manager, cache_manager)

    async def _execute():
        async with GraphClient(auth_service) as graph_client:
            service = XService(graph_client)
            return await coro_factory(service)

    result = asyncio.run(_execute())
    return result, formatter
```

### Recommendation: Extract to `cli/helpers.py`

```python
# src/teams_phone/cli/helpers.py
def run_with_service(
    ctx: typer.Context,
    service_factory: Callable[[GraphClient], T],
    coro_factory: Callable[[T], Coroutine],
) -> tuple[Any, OutputFormatter]:
    """Generic async runner with service dependency injection."""
    # ... implementation
```

### `_X_to_list_dict` / `_X_to_json_dict` Pattern

Each CLI module has paired conversion functions:
- `_number_to_list_dict` / `_number_to_json_dict` (numbers.py)
- `_user_to_list_dict` / `_user_to_json_dict` (users.py)
- `_location_to_list_dict` / `_location_to_json_dict` (locations.py)
- `_policy_to_list_dict` / `_policy_to_json_dict` (policies.py)

**Recommendation:** Consider adding `to_table_dict()` and `to_json_dict()` methods directly to Pydantic models, or create a formatter mixin.

---

## 5. Ruff Complexity Analysis

**Good news:** No McCabe complexity (C901) violations found.

### Current Ruff Configuration (pyproject.toml)

```toml
[tool.ruff.lint]
select = ["E4", "E7", "E9", "F"]  # Minimal rules
```

### Recommendation: Expand Ruff Rules

Consider enabling additional rules to catch more issues:

```toml
[tool.ruff.lint]
select = [
    "E4", "E7", "E9", "F",  # Current rules
    "C901",  # McCabe complexity
    "B",     # Bugbear (common bugs)
    "SIM",   # Simplify
    "UP",    # pyupgrade
    "I",     # isort
]
mccabe.max-complexity = 10
```

---

## Prioritized Refactoring Roadmap

### Phase 1: Test Infrastructure (High Impact)
1. Create `tests/fixtures/factories.py` with shared factory functions
2. Add mock fixtures to `tests/conftest.py` for GraphClient patterns
3. Update existing tests to use shared fixtures (incremental)

**Estimated reduction:** ~30% fewer lines in test files

### Phase 2: Split Large Test Files (Medium Impact)
1. Split `test_cli_numbers.py` into:
   - `test_cli_numbers_list.py`
   - `test_cli_numbers_assign.py`
   - `test_cli_numbers_bulk.py`
2. Split `test_models.py` by model category
3. Split other large test files as needed

**Benefit:** AI agents can work on focused subsets

### Phase 3: CLI Refactoring (Lower Priority)
1. Extract `_run_async` helpers to `cli/helpers.py`
2. Consider splitting `cli/numbers.py` if it continues to grow
3. Add model methods for dict conversion

### Phase 4: Linting Improvements
1. Expand ruff rules incrementally
2. Add complexity thresholds
3. Consider enabling more strict checks

---

## Metrics Summary

| Metric | Current | Target |
|--------|---------|--------|
| Largest test file | 3,501 lines | < 1,000 lines |
| Largest src file | 1,667 lines | < 800 lines |
| Mock pattern repetitions | 100+ | < 20 (via fixtures) |
| Duplicated factory functions | 5 | 0 |
| Ruff rules enabled | 4 | 10+ |

---

*Generated: 2026-02-02*
