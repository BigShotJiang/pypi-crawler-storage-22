# Ruff Ignores Tracking Document

This document tracks all ruff rule violations that are intentionally ignored in the codebase, along with their justifications.

## Ruff Configuration Overview

**Configuration file:** `pyproject.toml`

```toml
[tool.ruff]
line-length = 88
target-version = "py310"

[tool.ruff.lint]
select = ["E4", "E7", "E9", "F", "C901", "B", "I", "SIM", "UP"]
ignore = ["B008"]  # typer.Option in defaults is standard Typer pattern
fixable = ["ALL"]

[tool.ruff.lint.mccabe]
max-complexity = 10

[tool.ruff.lint.isort]
known-first-party = ["teams_phone"]
force-single-line = false
lines-after-imports = 2
```

### Enabled Rules

| Rule Set | Description |
|----------|-------------|
| E4, E7, E9 | Core pycodestyle errors (indentation, statements, runtime) |
| F | Pyflakes (undefined names, unused imports, etc.) |
| C901 | McCabe complexity (max complexity: 10) |
| B | flake8-bugbear (common bugs and design problems) |
| I | isort (import sorting) |
| SIM | flake8-simplify (code simplification patterns) |
| UP | pyupgrade (Python version syntax modernization) |

---

## Global Ignores (pyproject.toml)

| Rule | Name | Rationale |
|------|------|-----------|
| B008 | Function call in default argument | Standard Typer CLI pattern - `typer.Option()` and `typer.Argument()` are designed to be used as default values |

---

## Inline noqa Comments

### C901 - McCabe Complexity (9 instances)

CLI commands and complex validation functions that orchestrate multiple operations. Refactoring these would fragment the logical flow and reduce readability.

| File | Line | Function | Justification |
|------|------|----------|---------------|
| `src/teams_phone/cli/numbers.py` | 354 | `show_number` | CLI command rendering multiple detail sections with optional fields |
| `src/teams_phone/cli/numbers.py` | 574 | `assign_number` | CLI command with dry-run, wait, force modes and JSON output |
| `src/teams_phone/cli/numbers.py` | 823 | `unassign_number` | CLI command with dry-run, wait, force modes and JSON output |
| `src/teams_phone/cli/numbers.py` | 1024 | `update_number` | CLI command with dry-run, force modes, mutual exclusion, and JSON output |
| `src/teams_phone/cli/numbers.py` | 1218 | `bulk_assign` | Bulk operation with validation, dry-run, progress, and error handling |
| `src/teams_phone/cli/policies.py` | 536 | `bulk_assign` | Bulk operation with validation, dry-run, progress, and error handling |
| `src/teams_phone/cli/api_check.py` | 159 | `api_check` | CLI command with validation, table/JSON output, and verbose mode |
| `src/teams_phone/infrastructure/graph_client.py` | 564 | `get_paginated_url` | Pagination loop with debug logging and early termination |
| `src/teams_phone/services/bulk_operations.py` | 483 | `validate_assign_csv` | Multi-step validation with error aggregation |

**Pattern:** These functions are inherently complex because they:
- Handle multiple output formats (table, JSON)
- Support multiple modes (dry-run, force, wait)
- Orchestrate validation, API calls, and user feedback
- Aggregate errors for bulk operations

### BLE001 - Blind Exception (1 instance)

| File | Line | Context | Justification |
|------|------|---------|---------------|
| `src/teams_phone/services/tenant_service.py` | 197 | Connection test | Catches any exception to report connection test failure - appropriate for diagnostic commands |

### E402 - Module-level import not at top (10 instances in tests/conftest.py)

These imports must come after environment variable setup to ensure Rich/Typer see the terminal configuration.

| File | Lines | Imports | Justification |
|------|-------|---------|---------------|
| `tests/conftest.py` | 26-34, 50 | shutil, collections.abc, typing, unittest.mock, pytest, typer, re | Environment variables (`COLUMNS`, `LINES`, `NO_COLOR`) and Rich configuration must be set before these imports to ensure consistent test behavior in CI environments |

**Context:** Rich checks `COLUMNS` env var and `shutil.get_terminal_size()` for terminal width. In CI environments without a TTY, these can return unusable values. The environment setup must happen before any Rich/Typer imports.

### F401 - Unused import (4 instances in test files)

| File | Line | Import | Justification |
|------|------|--------|---------------|
| `tests/unit/test_number_service_modify.py` | 13 | `GraphClient` | Prevents circular import - must import infrastructure before models/services |
| `tests/unit/test_user_service.py` | 12 | `GraphClient` | Prevents circular import - must import infrastructure before models/services |
| `tests/unit/test_number_service_read.py` | 11 | `GraphClient` | Prevents circular import - must import infrastructure before models/services |
| `tests/unit/test_number_service_assign.py` | 13 | `GraphClient` | Prevents circular import - must import infrastructure before models/services |

**Pattern:** These unused imports establish import order to avoid circular dependency issues in the test suite.

---

## Guidelines for Adding New Ignores

### When to Add a noqa Comment

1. **Complexity (C901):** Only when refactoring would genuinely harm readability or fragment a cohesive operation. CLI commands with multiple modes are valid candidates.

2. **Blind Exception (BLE001):** Only for diagnostic/connection-testing code where catching all exceptions is the intended behavior.

3. **Import Order (E402):** Only when imports must follow initialization code (environment setup, module patching).

4. **Unused Import (F401):** Only for import-order dependencies or re-exports. Prefer removing unused imports when possible.

### Format

Always include a brief justification:

```python
def my_function(  # noqa: C901 - Brief explanation of why complexity is necessary
    ...
) -> None:
```

### Process

1. Verify the violation cannot be reasonably fixed
2. Add the noqa comment with justification
3. Update this document with the new entry
4. Include the update in the same commit as the code change

---

## Verification Commands

```bash
# Verify all rules pass (uses pyproject.toml config)
uv run ruff check src/ tests/

# Check specific rule, bypassing pyproject.toml ignores
uv run ruff check src/ tests/ --select C901

# Show statistics
uv run ruff check src/ tests/ --statistics

# Auto-fix fixable violations
uv run ruff check src/ tests/ --fix
```

---

*Last updated: 2026-02-02 (Task 20: Added SIM and UP rules)*
