# 10. Infrastructure and Deployment

### 10.1 Deployment Strategy

- **Strategy:** Package distribution via PyPI + optional standalone binaries
- **CI/CD Platform:** GitHub Actions
- **Primary:** PyPI distribution (MVP)
- **Future:** Standalone binaries via PyInstaller (Phase 5)

### 10.2 CI/CD Pipeline

| Workflow | Trigger | Actions |
|----------|---------|---------|
| `ci.yml` | PR, push to main | Lint, type-check, unit tests, build |
| `release.yml` | Version tag (v*) | Full tests, publish to PyPI, GitHub Release |
| `contract-tests.yml` | Daily 6:00 UTC | Validate Pydantic models against live API |

### 10.3 Environment Promotion Flow

```
Feature Branch → Main Branch → Test PyPI → PyPI (Production)
     │                │              │              │
     ▼                ▼              ▼              ▼
 Unit tests      Integration    Install test    Published
 Lint/format     Contract       Version bump    Available
 Type check      tests                          via pip
```

### 10.4 Rollback Strategy

- **Primary Method:** Version pinning (`pip install teams-phone-cli==1.0.0`)
- **Trigger Conditions:** Critical bug, API contract break, security vulnerability
- **Recovery Time Objective:** < 1 hour to publish hotfix

---
