# 13. Test Strategy

### 13.1 Coverage Goals

| Layer | Target |
|-------|--------|
| Services | >90% |
| Infrastructure | >85% |
| CLI | >75% |
| Models | >95% |
| **Overall** | **>80%** |

### 13.2 Test Types

| Type | Location | Purpose |
|------|----------|---------|
| Unit | `tests/unit/` | Fast tests with mocked dependencies |
| Integration | `tests/integration/` | Real Graph API calls against test tenant |
| Contract | `tests/contract/` | Validate Pydantic models match live API |
| E2E | `tests/e2e/` | Full CLI command execution |

### 13.3 Test Markers

```bash
pytest -m unit                 # Fast unit tests only
pytest -m integration          # Integration tests (needs auth)
pytest -m contract             # API contract tests
pytest --cov=teams_phone       # With coverage report
```

---
