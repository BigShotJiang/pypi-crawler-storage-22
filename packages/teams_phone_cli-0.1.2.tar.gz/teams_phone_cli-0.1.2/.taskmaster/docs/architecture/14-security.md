# 14. Security

### 14.1 Authentication

- **Method:** Service principal (app registration)
- **Certificate auth preferred** over client secrets
- **Secrets via environment only** - never in config files

### 14.2 Secrets Management

| Data | Storage | Logging |
|------|---------|---------|
| Access tokens | Encrypted file cache | `[REDACTED]` |
| Client secrets | Environment variable | Never logged |
| Certificate keys | File system (user manages) | Never logged |

### 14.3 Required API Permissions

| Permission | Type | Purpose |
|------------|------|---------|
| `TeamsUserConfiguration.Read.All` | Application | Read user configs |
| `TeamsTelephoneNumber.Read.All` | Application | Read numbers |
| `TeamsTelephoneNumber.ReadWrite.All` | Application | Assign/unassign |
| `TeamsPolicyUserAssign.ReadWrite.All` | Application | Assign policies |
| `User.Read.All` | Application | User profiles |
| `Directory.Read.All` | Application | Tenant info |

### 14.4 Security Checklist for AI Agents

- [ ] No hardcoded secrets, tokens, or credentials
- [ ] All external input validated before use
- [ ] Sensitive data not logged at DEBUG level
- [ ] Error messages don't expose internal details
- [ ] File paths validated before read/write
- [ ] Subprocess calls use list args, not `shell=True`
- [ ] HTTP requests use HTTPS only
- [ ] Pydantic models validate all API responses

---
