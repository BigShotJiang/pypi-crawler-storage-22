# 3. Tech Stack

This is the **DEFINITIVE** technology selection section. All choices documented here are the single source of truth for the project.

### 3.1 Cloud Infrastructure

- **Provider:** Microsoft Azure (via Microsoft Graph API)
- **Key Services:** Microsoft Graph API (Beta), Microsoft Entra ID (authentication)
- **Deployment Regions:** N/A - CLI runs locally; connects to Microsoft's global Graph API endpoints

### 3.2 Technology Stack Table

| Category | Technology | Version | Purpose | Rationale |
|----------|------------|---------|---------|-----------|
| **Language** | Python | 3.10+ | Primary development language | Cross-platform, rich ecosystem, type hints, async support |
| **CLI Framework** | Typer | ^0.9.0 | Command-line interface | Modern CLI framework, auto-completion, type-based args, Rich integration |
| **HTTP Client** | httpx | ^0.25.0 | Async HTTP requests to Graph API | Native async, timeout handling, connection pooling, modern API |
| **Authentication** | msal | ^1.24.0 | Microsoft Entra ID auth | Official Microsoft library, token caching, certificate support |
| **Data Validation** | Pydantic | ^2.0.0 | Schema validation for API responses | Strict mode for contract validation, fast serialization |
| **Terminal UI** | Rich | ^13.0.0 | Tables, progress bars, colored output | Beautiful terminal output, Typer integration, cross-platform |
| **Config Parsing** | tomli / tomllib | stdlib (3.11+) / ^2.0.0 | TOML configuration files | Human-readable config, stdlib in Python 3.11+ |
| **CSV Handling** | csv (stdlib) | stdlib | Read location/policy CSV cache | No external dependency needed |
| **Testing** | pytest | ^7.4.0 | Unit and integration testing | Industry standard, excellent fixtures, async support |
| **Test Mocking** | pytest-mock | ^3.12.0 | Mock Graph API responses | Clean mocking syntax, pytest integration |
| **Async Testing** | pytest-asyncio | ^0.21.0 | Test async code paths | Required for httpx async testing |
| **HTTP Mocking** | respx | ^0.20.0 | Mock httpx requests | Purpose-built for httpx, clean API |
| **Code Formatting** | Ruff | ^0.1.0 | Linting and formatting | Fast, replaces flake8/black/isort, single tool |
| **Type Checking** | mypy | ^1.7.0 | Static type analysis | Catch type errors before runtime |
| **Package Management** | uv | ^0.1.0 | Fast Python package installer | 10-100x faster than pip, lockfile support |

### 3.3 Development Tools

| Tool | Purpose | Notes |
|------|---------|-------|
| **uv** | Package management, virtual environments | Modern replacement for pip + venv |
| **Ruff** | Linting + formatting (single tool) | Replaces flake8, black, isort |
| **mypy** | Type checking | Strict mode recommended |
| **pre-commit** | Git hooks for quality checks | Run ruff, mypy before commits |

### 3.4 External Dependencies

| System | Requirement | Purpose |
|--------|-------------|---------|
| Microsoft Entra ID | App Registration with service principal | Graph API authentication |
| Microsoft Graph API | Beta endpoints access | Teams Phone management operations |
| PowerShell + MicrosoftTeams module | Optional (for CSV export) | Export locations/policies to CSV |

---
