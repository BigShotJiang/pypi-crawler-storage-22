# 8. Database Schema

This project uses **file-based storage only** - no traditional database.

### 8.1 Storage Architecture

```
~/.teams-phone/
├── config.toml              # Main configuration file
├── tokens/                  # Encrypted token cache
│   ├── contoso.json         # Per-tenant token cache
│   └── fabrikam.json
└── cache/                   # CSV cache from PowerShell export
    ├── locations.csv        # Emergency locations
    ├── policies.csv         # Policy definitions
    └── export-metadata.json # Cache metadata
```

### 8.2 Configuration Schema (TOML)

```toml
# ~/.teams-phone/config.toml

[default]
tenant = "contoso"           # Active tenant profile name
output_format = "table"      # Default output: table | json
color = true                 # Enable colored output
verbose = false              # Verbose logging

[cache]
users_ttl = 300              # User data cache TTL (seconds)
numbers_ttl = 300            # Number data cache TTL (seconds)
csv_stale_days = 30          # Warn if CSV older than this

[tenants.contoso]
tenant_id = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
client_id = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
display_name = "Contoso Ltd"
auth_method = "certificate"  # certificate | client-secret
cert_path = "/path/to/contoso-cert.pem"
default_location = "Seattle-HQ"

[tenants.fabrikam]
tenant_id = "yyyyyyyy-yyyy-yyyy-yyyy-yyyyyyyyyyyy"
client_id = "yyyyyyyy-yyyy-yyyy-yyyy-yyyyyyyyyyyy"
display_name = "Fabrikam Inc"
auth_method = "client-secret"
# Secret provided via TEAMS_PHONE_CLIENT_SECRET env var
default_location = "Portland-Main"
```

### 8.3 CSV Cache Schemas

#### locations.csv

| Column | Type | Description |
|--------|------|-------------|
| `locationId` | UUID | Unique location ID (used in API calls) |
| `civicAddressId` | UUID | Parent civic address ID |
| `description` | string | Location name/description |
| `companyName` | string | Company name |
| `address` | string | Full street address |
| `city` | string | City name |
| `stateOrProvince` | string | State/province code |
| `postalCode` | string | ZIP/postal code |
| `countryOrRegion` | string | Country code |
| `isDefault` | boolean | Default location flag |

#### policies.csv

| Column | Type | Description |
|--------|------|-------------|
| `policyType` | string | Policy type identifier |
| `policyName` | string | Policy name (Identity) |
| `policyId` | string | Policy ID for API calls |
| `description` | string | Policy description |
| `isGlobal` | boolean | Global/default policy flag |

#### export-metadata.json

```json
{
  "exportedAt": "2026-01-27T15:30:00Z",
  "exportedBy": "admin@contoso.com",
  "tenantId": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
  "tenantName": "Contoso Ltd",
  "scriptVersion": "1.0.0",
  "counts": {
    "locations": 15,
    "policies": 23
  }
}
```

---
