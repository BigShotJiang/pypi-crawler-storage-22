# 9. Source Tree

```
teams-phone-cli/
├── .github/
│   └── workflows/
│       ├── ci.yml                    # Lint, type-check, test on PR
│       ├── release.yml               # Build and publish to PyPI
│       └── contract-tests.yml        # Daily API contract validation
│
├── src/
│   └── teams_phone/                  # Main package
│       ├── __init__.py               # Package version, metadata
│       ├── __main__.py               # Entry point: python -m teams_phone
│       ├── cli/                      # CLI Layer (Typer commands)
│       │   ├── __init__.py
│       │   ├── main.py               # Root CLI app, global options
│       │   ├── users.py              # users command group
│       │   ├── numbers.py            # numbers command group
│       │   ├── policies.py           # policies command group
│       │   ├── locations.py          # locations command group
│       │   ├── tenants.py            # tenants command group
│       │   ├── auth.py               # auth command group
│       │   └── api_check.py          # api-check command
│       │
│       ├── services/                 # Service Layer (business logic)
│       │   ├── __init__.py
│       │   ├── user_service.py
│       │   ├── number_service.py
│       │   ├── policy_service.py
│       │   ├── location_service.py
│       │   ├── tenant_service.py
│       │   └── auth_service.py
│       │
│       ├── infrastructure/           # Infrastructure Layer
│       │   ├── __init__.py
│       │   ├── graph_client.py
│       │   ├── cache_manager.py
│       │   ├── config_manager.py
│       │   └── output_formatter.py
│       │
│       ├── models/                   # Pydantic models
│       │   ├── __init__.py
│       │   ├── user.py
│       │   ├── number.py
│       │   ├── policy.py
│       │   ├── location.py
│       │   ├── tenant.py
│       │   ├── auth.py
│       │   └── api_responses.py
│       │
│       ├── exceptions.py             # Custom exception hierarchy
│       ├── constants.py              # API URLs, exit codes, defaults
│       └── utils.py                  # Phone number normalization, helpers
│
├── tests/
│   ├── __init__.py
│   ├── conftest.py                   # Pytest fixtures
│   ├── unit/                         # Unit tests (mocked)
│   ├── integration/                  # Integration tests (real API)
│   ├── contract/                     # API contract tests
│   └── fixtures/                     # Test data files
│
├── scripts/
│   ├── Export-TeamsPhoneData.ps1     # PowerShell CSV export script
│   └── setup-test-tenant.ps1         # Test tenant setup script
│
├── docs/                             # Documentation
│
├── pyproject.toml                    # Project metadata, dependencies
├── uv.lock                           # Dependency lockfile
├── README.md
├── LICENSE
├── CHANGELOG.md
└── .pre-commit-config.yaml
```

---
