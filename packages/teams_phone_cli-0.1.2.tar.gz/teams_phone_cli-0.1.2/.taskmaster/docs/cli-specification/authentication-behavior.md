# Authentication Behavior

Commands that require authentication (all commands except `auth login`, `auth status`, `tenants list`, `tenants add`, and `--help`/`--version`) will automatically trigger authentication if no valid token exists:

1. **Auto-login flow:** If no cached token exists or token is expired and cannot be refreshed, the CLI automatically initiates the tenant's configured auth method (default: certificate).
2. **Non-interactive auth:** Certificate or client-secret authentication proceeds automatically without user interaction.
3. **Auth failure:** If authentication fails (missing certificate, invalid secret, etc.), the command fails with exit code 2 and guidance to check credentials or run `auth login` first.
4. **Explicit control:** Use `auth login` to authenticate before running commands, especially in scripts.

**Example behavior:**
```bash
# First run - certificate configured
$ teams-phone users list
Authenticating with certificate... ✓ Authenticated

# Command proceeds after successful auth
┌─────────────┬─────────────────────────┬──────────────┐
│ Display Name│ UPN                     │ Phone Number │
...

# First run - no credentials configured
$ teams-phone users list
Error: No valid authentication credentials found.

  Configure authentication using one of these methods:
  - Certificate: teams-phone auth login --method certificate --cert-path /path/to/cert.pem
  - Client secret: teams-phone auth login --method client-secret --secret <secret>

  Or set credentials in config file (~/.teams-phone/config.toml)
```

---
