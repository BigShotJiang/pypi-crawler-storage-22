# Bulk Operations Implementation Strategy

### Graph API Batch Endpoint Usage

The CLI uses the Microsoft Graph batch endpoint (`POST /beta/$batch`) for certain bulk operations to improve performance.

**Batch-Enabled Operations:**
- `users list --all` - Fetch multiple user pages in parallel (when result set > 1000 users)
- `numbers list --all` - Fetch multiple number pages in parallel (when result set > 1000 numbers)
- Internal lookups - Resolve multiple user IDs/phone numbers simultaneously

**Sequential Operations:**
- `numbers bulk-assign` - Sequential calls with progress reporting (better UX, easier error handling)
- `policies bulk-assign` - Sequential calls with progress reporting
- Any operation requiring real-time progress updates

**Batch Constraints:**
- Maximum 20 requests per batch
- Cannot mix v1.0 and beta endpoints
- Each request still counts against rate limits
- Responses may arrive out of order (use request ID correlation)

**Why Sequential for Bulk Assign:**
1. **Progress reporting** - Live progress bar requires sequential processing
2. **Error handling** - Easier to identify which specific row failed
3. **Async operations** - Number assign/unassign return 202 and require polling per request
4. **User experience** - Real-time feedback more important than raw speed for bulk operations

**Future Optimization:**
Post-MVP, we may add `--fast` flag to bulk operations that uses batching for speed at the cost of reduced progress visibility.

---
