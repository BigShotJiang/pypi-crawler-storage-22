# Command Group 4: Tenants

Manage multi-tenant configuration.

### `tenants list`

List all configured tenant profiles.

```
teams-phone tenants list [OPTIONS]
```

**Output Fields:**
- Profile Name
- Display Name
- Tenant ID
- Status (Current/Available)
- Last Used

**Example:**
```bash
teams-phone tenants list
```

---

### `tenants current`

Show the currently active tenant.

```
teams-phone tenants current [OPTIONS]
```

**Output:**
- Profile name
- Display name
- Tenant ID
- Connection status

**Example:**
```bash
teams-phone tenants current
```

---

### `tenants switch <name>`

Switch to a different tenant profile.

```
teams-phone tenants switch <name> [OPTIONS]
```

**Arguments:**
| Argument | Description |
|----------|-------------|
| `<name>` | Tenant profile name |

**Example:**
```bash
# Switch to different tenant
teams-phone tenants switch fabrikam

# Switch and verify
teams-phone tenants switch contoso && teams-phone tenants current
```

---

### `tenants add`

Add a new tenant profile (interactive wizard).

```
teams-phone tenants add [OPTIONS]
```

**Options:**
| Option | Description |
|--------|-------------|
| `--name <name>` | Profile name (skip prompt) |
| `--tenant-id <id>` | Tenant ID (skip prompt) |
| `--client-id <id>` | Client/Application ID (skip prompt) |
| `--display-name <name>` | Display name (skip prompt) |
| `--auth-method <method>` | Auth method: `certificate` (recommended), `client-secret` |

**Behavior:**
- **Full interactive:** If no flags provided, prompts for all required values
- **Partial flags:** Prompts only for missing required values (name, tenant-id, client-id)
- **Full non-interactive:** If all required flags provided, skips prompts entirely
- **Validation:** Always validates tenant-id and client-id are valid UUIDs before saving

**Interactive Prompts (when needed):**
1. Profile name (short identifier for CLI)
2. Tenant ID (GUID from Azure AD)
3. Client ID (App Registration ID)
4. Display name (friendly name, defaults to profile name if skipped)
5. Authentication method selection (defaults to certificate)
6. Test connection (optional, prompted in interactive mode)

**Example:**
```bash
# Interactive wizard
teams-phone tenants add

# Non-interactive with all options (certificate)
teams-phone tenants add \
  --name contoso \
  --tenant-id "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" \
  --client-id "yyyyyyyy-yyyy-yyyy-yyyy-yyyyyyyyyyyy" \
  --display-name "Contoso Ltd" \
  --auth-method certificate
```

---

### `tenants remove <name>`

Remove a tenant profile.

```
teams-phone tenants remove <name> [OPTIONS]
```

**Arguments:**
| Argument | Description |
|----------|-------------|
| `<name>` | Tenant profile name to remove |

**Options:**
| Option | Description |
|--------|-------------|
| `--force` | Skip confirmation prompt |

**Example:**
```bash
# Remove with confirmation
teams-phone tenants remove oldtenant

# Remove without confirmation
teams-phone tenants remove oldtenant --force
```

---

### `tenants test [name]`

Test connection to a tenant.

```
teams-phone tenants test [name] [OPTIONS]
```

**Arguments:**
| Argument | Description |
|----------|-------------|
| `[name]` | Tenant profile name (default: current tenant) |

**Tests Performed:**
1. Authentication (token acquisition)
2. Graph API connectivity
3. Required permissions validation
4. Teams Phone Graph endpoint access (beta where required)

**Example:**
```bash
# Test current tenant
teams-phone tenants test

# Test specific tenant
teams-phone tenants test fabrikam
```

---
