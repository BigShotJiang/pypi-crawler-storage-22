# Command Group 5: Auth

Authentication management commands.

### `auth login`

Authenticate with the current tenant.

```
teams-phone auth login [OPTIONS]
```

**Options:**
| Option | Description |
|--------|-------------|
| `--method <method>` | Auth method: `certificate` (recommended), `client-secret` |
| `--force` | Force new authentication even if token exists |
| `--secret` | Client secret (for `client-secret` method; can also use `TEAMS_PHONE_CLIENT_SECRET` env var) |
| `--cert-path <path>` | Path to certificate file (for `certificate` method) |
| `--cert-thumbprint <hex>` | Certificate thumbprint (for `certificate` method with system store) |

**Method-Specific Requirements:**
- `certificate` (recommended): Requires either `--cert-path` (PEM/PFX file) or `--cert-thumbprint` (system certificate store). Most secure option.
- `client-secret`: Requires `--secret` or `TEAMS_PHONE_CLIENT_SECRET` environment variable. Secrets should be rotated regularly.

**Example:**
```bash
# Login with certificate file (recommended)
teams-phone auth login --method certificate --cert-path /path/to/cert.pem

# Login with certificate from Windows certificate store
teams-phone auth login --method certificate --cert-thumbprint "ABC123DEF456..."

# Login with client secret (from environment)
export TEAMS_PHONE_CLIENT_SECRET="your-secret"
teams-phone auth login --method client-secret

# Login with client secret (inline - less secure, avoid in scripts)
teams-phone auth login --method client-secret --secret "your-secret"
```

---

### `auth status`

Show current authentication status.

```
teams-phone auth status [OPTIONS]
```

**Output:**
- Authenticated: Yes/No
- Tenant
- Token expiry
- Authentication method

**Example:**
```bash
teams-phone auth status
```

---

### `auth logout`

Clear cached authentication tokens.

```
teams-phone auth logout [OPTIONS]
```

**Options:**
| Option | Description |
|--------|-------------|
| `--all` | Clear tokens for all tenants |

**Example:**
```bash
# Logout current tenant
teams-phone auth logout

# Logout all tenants
teams-phone auth logout --all
```

---

### `auth refresh`

Refresh cached authentication tokens for the current tenant.

```
teams-phone auth refresh [OPTIONS]
```

**Options:**
| Option | Description |
|--------|-------------|
| `--force` | Force refresh even if token is still valid |

**Example:**
```bash
# Refresh token for current tenant
teams-phone auth refresh

# Force refresh
teams-phone auth refresh --force
```
---
