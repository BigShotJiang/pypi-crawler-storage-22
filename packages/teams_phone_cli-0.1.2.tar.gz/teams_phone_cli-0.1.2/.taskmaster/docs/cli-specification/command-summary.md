# Command Summary

| Command | Description | Data Source |
|---------|-------------|-------------|
| **Users** | | |
| `users list` | List users with voice-related configuration | Graph API |
| `users show <user>` | Show user voice configuration | Graph API |
| `users search <query>` | Search users by name/UPN/phone | Graph API |
| **Numbers** | | |
| `numbers list` | List phone number inventory | Graph API |
| `numbers show <number>` | Show phone number details | Graph API |
| `numbers search <pattern>` | Search phone numbers | Graph API |
| `numbers assign <user> <number> [location]` | Assign number to user (async operation) | Graph API |
| `numbers unassign <number>` | Remove number assignment (async operation) | Graph API |
| `numbers update <number>` | Update number location/network site (sync operation) | Graph API |
| `numbers bulk-assign <csv>` | Bulk assign from CSV with locations | Graph API |
| **Policies** | | |
| `policies list [type]` | List available policies by type | CSV Export |
| `policies show <user>` | Show user's policy assignments | Graph API |
| `policies assign <user> <type> <name>` | Assign policy to user | Graph API |
| `policies bulk-assign <csv>` | Bulk assign policies from CSV | Graph API |
| **Locations** | | |
| `locations list` | List emergency locations | CSV Export |
| `locations show <location>` | Show location details | CSV Export |
| `locations search <query>` | Search locations by name/address | CSV Export |
| **Tenants** | | |
| `tenants list` | List configured tenants | Local Config |
| `tenants current` | Show current tenant | Local Config |
| `tenants switch <name>` | Switch active tenant | Local Config |
| `tenants add` | Add new tenant profile | Local Config |
| `tenants remove <name>` | Remove tenant profile | Local Config |
| `tenants test [name]` | Test tenant connection | Graph API |
| **Auth** | | |
| `auth login` | Authenticate with tenant (certificate or client-secret) | MSAL |
| `auth status` | Show auth status | MSAL |
| `auth logout` | Clear auth tokens | MSAL |
| `auth refresh` | Refresh authentication tokens | MSAL |

---
