# Configuration File

Location: `~/.teams-phone/config.toml`

```toml
[default]
tenant = "contoso"
output_format = "table"  # table, json
color = true

[cache]
users_ttl = 300  # seconds
numbers_ttl = 300
policies_ttl = 600
tenant_ttl = 3600

[tenants.contoso]
tenant_id = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
client_id = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
display_name = "Contoso Ltd"
auth_method = "certificate"  # certificate (recommended), client-secret
cert_path = "/path/to/contoso-cert.pem"  # or use cert_thumbprint on Windows
default_location = "Seattle-HQ"  # Default emergency location for number assignments

[tenants.fabrikam]
tenant_id = "yyyyyyyy-yyyy-yyyy-yyyy-yyyyyyyyyyyy"
client_id = "yyyyyyyy-yyyy-yyyy-yyyy-yyyyyyyyyyyy"
display_name = "Fabrikam Inc"
auth_method = "client-secret"
# secret stored in TEAMS_PHONE_CLIENT_SECRET env var (do not store secrets in config)
default_location = "NYC-Main"
```

---
