# Global Options

All commands support these global options:

| Option | Short | Description |
|--------|-------|-------------|
| `--tenant <name>` | `-t` | Override default tenant for this command |
| `--json` | `-j` | Output in JSON format for automation |
| `--verbose` | `-v` | Show detailed output and debug information |
| `--no-cache` | | Force fresh data fetch, ignore cache |
| `--debug-log <path>` | | Write sanitized JSON diagnostic logs to a file |
| `--help` | `-h` | Show help for command |
| `--version` | | Show application version |

---
