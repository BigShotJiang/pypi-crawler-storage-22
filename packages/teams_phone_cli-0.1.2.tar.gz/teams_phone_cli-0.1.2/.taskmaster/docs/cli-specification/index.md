# CLI Specification: Teams Phone CLI MVP

## Table of Contents

- [CLI Specification: Teams Phone CLI MVP](#table-of-contents)
  - [Overview](#overview)
  - [Architecture: Hybrid Graph API + CSV Export](#architecture-hybrid-graph-api-csv-export)
  - [Global Options](#global-options)
  - [Authentication Behavior](#authentication-behavior)
  - [Command Group 1: Users](#command-group-1-users)
  - [Command Group 2: Numbers](#command-group-2-numbers)
  - [Command Group 3: Policies](#command-group-3-policies)
  - [Command Group 4: Tenants](#command-group-4-tenants)
  - [Command Group 5: Auth](#command-group-5-auth)
  - [Command Group 6: Locations](#command-group-6-locations)
  - [Output Formats](#output-formats)
  - [Logging & Diagnostics](#logging-diagnostics)
  - [Error Handling](#error-handling)
  - [Configuration File](#configuration-file)
  - [Bulk Operations Implementation Strategy](#bulk-operations-implementation-strategy)
  - [Command Summary](#command-summary)
  - [MVP Checklist](#mvp-checklist)
