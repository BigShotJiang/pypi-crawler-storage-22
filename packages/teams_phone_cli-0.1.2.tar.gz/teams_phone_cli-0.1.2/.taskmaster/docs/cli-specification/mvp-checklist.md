# MVP Checklist

### Core Commands (Must Have)

**Users (Graph API)**
- [ ] `users list` with filtering (licensed/unlicensed, assigned/unassigned)
- [ ] Account type filtering and display (user/resource-account/guest)
- [ ] `users show` with full voice config and all policy assignments
- [ ] `users search` with partial matching by name/UPN/phone

**Numbers (Graph API)**
- [ ] `numbers list` with filtering by status/type/city
- [ ] `numbers show` with full details
- [ ] Enhanced number details (activation state, port status, assignment source)
- [ ] `numbers search` with pattern matching (last 4 digits, wildcards)
- [ ] `numbers assign` with emergency location, async polling, dry-run
- [ ] `numbers unassign` with async polling, dry-run
- [ ] `numbers update` with location/network-site updates, dry-run
- [ ] `numbers bulk-assign` with CSV import, location column support, progress bar

**Policies (Graph API + CSV)**
- [ ] `policies list` by type (reads from CSV export)
- [ ] `policies show` for user (Graph API effectivePolicyAssignments)
- [ ] Enhanced policy display with assignment source (direct/group/global)
- [ ] `policies assign` with validation and dry-run
- [ ] `policies bulk-assign` from CSV

**Locations (CSV Export Only)**
- [ ] `locations list` with filtering by city (reads from CSV)
- [ ] `locations show` with full address details (reads from CSV)
- [ ] `locations search` with partial matching (reads from CSV)
- [ ] CSV staleness warning (>30 days old)
- [ ] Degraded mode handling when CSV missing

**Tenants (Local Config)**
- [ ] `tenants list` showing all configured profiles
- [ ] `tenants current` with connection status
- [ ] `tenants switch` with profile validation
- [ ] `tenants add` interactive wizard with UUID validation
- [ ] `tenants remove` with confirmation
- [ ] `tenants test` validating auth + permissions

**Auth (MSAL)**
- [ ] `auth login` with certificate (recommended) and client-secret methods
- [ ] `auth status` showing token expiry
- [ ] `auth logout` clearing cached tokens
- [ ] `auth refresh` forcing token renewal

### Global Features (Must Have)
- [ ] `--json` output for all commands
- [ ] `--verbose` mode with detailed API call logging
- [ ] `--tenant` override for multi-tenant operations
- [ ] `--no-cache` option forcing fresh data fetch
- [ ] `--help` for all commands with examples
- [ ] `--version` flag
- [ ] Rich table output with color-coded status
- [ ] Progress bars for bulk operations and async polling
- [ ] Consistent error messages with exit codes (0-7)
- [ ] Phone number format normalization (E.164 ↔ digits-only)

### Infrastructure (Must Have)
- [ ] PowerShell export script (`Export-TeamsPhoneData.ps1`)
  - [ ] Service principal authentication (certificate/secret)
  - [ ] Export locations to CSV
  - [ ] Export policies to CSV
  - [ ] Generate export-metadata.json
  - [ ] Error handling and logging
- [ ] CSV cache management
  - [ ] Read locations.csv with schema validation
  - [ ] Read policies.csv with schema validation
  - [ ] Staleness detection (>30 days)
  - [ ] Missing file warnings
- [ ] Async operation polling
  - [ ] Poll `/operations/{id}` endpoint
  - [ ] Exponential backoff (2-5 seconds)
  - [ ] Terminal state detection
  - [ ] Timeout handling (default 60s)
  - [ ] `--wait` / `--no-wait` modes
- [ ] Graph API error mapping (HTTP status → exit codes)
- [ ] Bulk operation strategy (batch vs sequential with progress)

### Nice to Have (Post-MVP)
- [ ] Shell completion (bash, zsh, fish, PowerShell)
- [ ] `--output <file>` for all list commands
- [ ] Automatic CSV refresh reminder based on age
