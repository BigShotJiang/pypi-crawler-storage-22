# Output Formats

### Default (Rich Tables)

Human-readable output with:
- Colored status indicators (green=good, yellow=warning, red=error)
- Formatted tables with borders
- Progress bars for long operations
- Summary statistics

### JSON Output (`--json`)

Machine-readable JSON for automation:
- Consistent structure across commands
- Includes metadata (timestamp, tenant, command)
- Array of objects for list commands
- Single object for show commands

**Example JSON output:**
```json
{
  "metadata": {
    "command": "users list",
    "tenant": "contoso",
    "timestamp": "2026-01-24T10:30:00Z",
    "count": 2,
    "correlation_id": "a1b2c3d4"
  },
  "data": [
    {
      "id": "xxx-xxx-xxx",
      "displayName": "John Doe",
      "userPrincipalName": "john.doe@contoso.com",
      "phoneNumber": "+12065551234",
      "licensed": true,
      "voiceEnabled": true
    },
    {
      "id": "yyy-yyy-yyy",
      "displayName": "Jane Smith",
      "userPrincipalName": "jane.smith@contoso.com",
      "phoneNumber": null,
      "licensed": true,
      "voiceEnabled": false
    }
  ]
}
```

---
