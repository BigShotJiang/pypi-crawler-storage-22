# Overview

This document defines the complete CLI functionality for the Teams Phone CLI MVP. The CLI follows a consistent `<noun> <verb> [args] [--flags]` command structure and provides six core command groups.
