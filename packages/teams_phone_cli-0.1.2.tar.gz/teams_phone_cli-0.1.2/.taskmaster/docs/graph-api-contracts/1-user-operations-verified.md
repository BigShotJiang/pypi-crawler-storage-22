# 1. User Operations - VERIFIED

### 1.1 List User Configurations
**CLI Commands:** `users list`
**Status:** VERIFIED

| Property | Value |
|----------|-------|
| **Endpoint** | `GET /admin/teams/userConfigurations` |
| **API Version** | Beta |
| **Permission** | `TeamsUserConfiguration.Read.All` |
| **Pagination** | Yes (`$top`, `$skip`) |

**Documentation:** [List userConfigurations](https://learn.microsoft.com/en-us/graph/api/teamsadministration-teamsadminroot-list-userconfigurations?view=graph-rest-beta)

**Query Parameters:**
- `$top` - Page size
- `$skip` - Skip count
- `$filter` - OData filter
- `$select` - Field selection
- `$expand` - Expand related resources
- `$orderBy` - Sort order

**Response Properties:**
```json
{
  "id": "string (GUID)",
  "userPrincipalName": "string",
  "tenantId": "string",
  "accountType": "user|resourceAccount|guest|sfbOnPremUser|unknown",
  "isEnterpriseVoiceEnabled": "boolean",
  "featureTypes": ["Teams", "CallingPlan", ...],
  "telephoneNumbers": [
    {
      "telephoneNumber": "+13235533696",
      "assignmentCategory": "primary"
    }
  ],
  "effectivePolicyAssignments": [
    {
      "policyType": "TeamsCallingPolicy",
      "policyAssignment": {
        "displayName": "string",
        "assignmentType": "direct|group",
        "policyId": "string",
        "groupId": "string"
      }
    }
  ],
  "createdDateTime": "ISO 8601",
  "modifiedDateTime": "ISO 8601"
}
```

**Contract Status:** [x] Verified [x] Documented [ ] Tested

---

### 1.2 Get User Configuration
**CLI Commands:** `users show <user>`
**Status:** VERIFIED

| Property | Value |
|----------|-------|
| **Endpoint** | `GET /admin/teams/userConfigurations/{teamsUserConfigurationId}` |
| **API Version** | Beta |
| **Permission** | `TeamsUserConfiguration.Read.All` |

**Documentation:** [Get teamsUserConfiguration](https://learn.microsoft.com/en-us/graph/api/teamsadministration-teamsuserconfiguration-get?view=graph-rest-beta)

**Path Parameters:**
- `teamsUserConfigurationId` - User's Entra object ID (GUID)

**Query Parameters:**
- `$select` - Field selection
- `$expand` - Expand related resources

**Response:** Same as 1.1 but single object

**Contract Status:** [x] Verified [x] Documented [ ] Tested

---

### 1.3 Search/Resolve Users
**CLI Commands:** `users search <query>`, user resolution for other commands
**Status:** VERIFIED (V1.0)

| Property | Value |
|----------|-------|
| **Endpoint** | `GET /users` |
| **API Version** | V1.0 |
| **Permission** | `User.Read.All` |

**Query Parameters:**
- `$search` - Search expression (requires `ConsistencyLevel: eventual` header)
- `$filter` - OData filter (startsWith, eq)
- `$top` - Result limit
- `$select` - Field selection

**Notes:**
- To search by phone number, use userConfigurations endpoint with filter
- Can filter by `userPrincipalName`, `displayName`, `id`

**Contract Status:** [x] Verified [x] Documented [ ] Tested

---
