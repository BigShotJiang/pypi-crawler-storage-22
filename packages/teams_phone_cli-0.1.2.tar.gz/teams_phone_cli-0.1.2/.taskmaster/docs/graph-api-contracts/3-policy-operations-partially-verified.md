# 3. Policy Operations - PARTIALLY VERIFIED

### 3.1 List Policies by Type
**CLI Commands:** `policies list [type]`
**Status:** NOT FOUND

No dedicated Graph API endpoint found for listing available policies by type. The policy names are referenced in assignments but there's no "list all calling policies" endpoint documented.

**MVP Solution:** PowerShell CSV export script (see Section 7)
- User runs PowerShell script to export policies to CSV
- CLI reads CSV for validation, display, and tab completion
- Degrades gracefully if CSV missing

**Contract Status:** [ ] Verified [ ] Documented [ ] Tested - **NOT AVAILABLE via Graph API**

---

### 3.2 Get User Policy Assignments
**CLI Commands:** `policies show <user>`
**Status:** VERIFIED (via userConfigurations)

User policy assignments are included in the `userConfigurations` endpoint response under `effectivePolicyAssignments`.

**Voice-Specific Policy Types (PRD Requirements) - VERIFIED:**

| PRD Name | Graph policyType | Batch Assignment | Status |
|----------|------------------|------------------|--------|
| Calling Policy | `TeamsCallingPolicy` | ✓ Supported | **VERIFIED** |
| Voicemail Policy | `TeamsVoicemailPolicy` | ✗ Not supported | Likely returned* |
| Emergency Calling Policy | `TeamsEmergencyCallingPolicy` | ✓ Supported | **VERIFIED** |
| Emergency Call Routing Policy | `TeamsEmergencyCallRoutingPolicy` | ✓ Supported | **VERIFIED** |
| Caller ID Policy | `CallingLineIdentity` | ✓ Supported | **VERIFIED** |
| Dial Plan | `TenantDialPlan` | ✓ Supported | **VERIFIED** |
| Voice Routing Policy | `OnlineVoiceRoutingPolicy` | ✓ Supported | **VERIFIED** |

*TeamsVoicemailPolicy follows the same pattern but is not in the batch assignment list. It can be assigned individually via `Grant-CsTeamsVoicemailPolicy`.

**Other Policy Types Also Returned:**
- `TeamsMeetingPolicy`
- `TeamsMessagingPolicy`
- `TeamsUpdateManagementPolicy`
- `TeamsAppSetupPolicy`
- `TeamsAppPermissionPolicy`
- And others (20+ types supported)

**Example Response:**
```json
"effectivePolicyAssignments": [
  {
    "policyType": "TeamsCallingPolicy",
    "policyAssignment": {
      "displayName": "AllOn",
      "assignmentType": "group",
      "policyId": "f7593e81-772a-4455-88a3-fc9e5ebc1e4a",
      "groupId": "75ae6229-35fe-4b01-ae7f-7c50439d239c"
    }
  }
]
```

**Contract Status:** [x] Verified [x] Documented [ ] Tested

---

### 3.3 Assign Policy to User
**CLI Commands:** `policies assign <user> <type> <name>`
**Status:** VERIFIED

| Property | Value |
|----------|-------|
| **Endpoint** | `POST /admin/teams/policy/userAssignments/assign` |
| **API Version** | Beta |
| **Permission** | `TeamsPolicyUserAssign.ReadWrite.All` |

**Documentation:** [teamsPolicyUserAssignment: assign](https://learn.microsoft.com/en-us/graph/api/teamsadministration-teamspolicyuserassignment-assign?view=graph-rest-beta)

**Request Body:**
```json
{
  "value": [
    {
      "@odata.type": "#microsoft.graph.teamsAdministration.teamsPolicyUserAssignment",
      "userId": "5c802b19-3600-83f1-1767-7b9edc7f38ab",
      "policyType": "TeamsMeetingPolicy",
      "policyId": "VnMAaN3X2X1B9tEHx1CJWfC76PSaKEzA4NoUuqIMRUo"
    }
  ]
}
```

**Response:** `204 No Content` on success

**Supported Policy Types (VERIFIED via batch assignment docs):**

Voice-related types:
- `TeamsCallingPolicy`
- `TeamsEmergencyCallingPolicy`
- `TeamsEmergencyCallRoutingPolicy`
- `CallingLineIdentity`
- `TenantDialPlan`
- `OnlineVoiceRoutingPolicy`

Other types:
- `TeamsMeetingPolicy`, `TeamsMessagingPolicy`, `TeamsAppSetupPolicy`, `TeamsAppPermissionPolicy`, `TeamsCallParkPolicy`, `TeamsChannelsPolicy`, `TeamsEducationAssignmentsAppPolicy`, `TeamsMeetingBroadcastPolicy`, `TeamsTemplatePermissionPolicy`, `TeamsUpdateManagementPolicy`, `TeamsUpgradePolicy`, `TeamsVerticalPackagePolicy`, `TeamsVideoInteropServicePolicy`, `ExternalAccessPolicy`

**Note:** `TeamsVoicemailPolicy` is NOT in the batch assignment list; use `Grant-CsTeamsVoicemailPolicy` via PowerShell.

**Contract Status:** [x] Verified [x] Documented [ ] Tested

---
