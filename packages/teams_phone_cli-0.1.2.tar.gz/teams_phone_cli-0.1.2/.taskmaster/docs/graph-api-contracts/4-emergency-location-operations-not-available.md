# 4. Emergency Location Operations - NOT AVAILABLE

### 4.1-4.3 All Location Operations
**CLI Commands:** `locations list`, `locations show`, `locations search`
**Status:** NOT AVAILABLE VIA GRAPH API

**Finding:** There is **NO Microsoft Graph API endpoint** for managing emergency locations. The `numberAssignment` resource contains `locationId` and `civicAddressId` fields, but there is no corresponding API to:
- List emergency locations
- Get location details
- Search locations
- Create/update/delete locations

**Current Management Methods:**
1. **Teams Admin Center** - Web UI only
2. **PowerShell** cmdlets:
   - `New-CsOnlineLisLocation` - Create location
   - `Set-CsOnlineLisCivicAddress` - Modify address
   - `Get-CsOnlineLisCivicAddress` - List addresses
   - `Remove-CsOnlineLisCivicAddress` - Remove address

**Impact on CLI:**
- Cannot implement `locations list/show/search` commands via Graph API
- Cannot validate location IDs before number assignment in real-time

**MVP Solution:** PowerShell CSV export script (see Section 7)
- User runs PowerShell script to export locations to CSV
- CLI reads CSV for validation and display
- Degrades gracefully if CSV missing

**Contract Status:** [ ] Verified [ ] Documented [ ] Tested - **NOT AVAILABLE via Graph API**

---
