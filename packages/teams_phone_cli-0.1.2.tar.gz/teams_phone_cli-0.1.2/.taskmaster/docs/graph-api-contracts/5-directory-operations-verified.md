# 5. Directory Operations - VERIFIED

### 5.1 Get User by ID/UPN
**Status:** VERIFIED (V1.0)

| Property | Value |
|----------|-------|
| **Endpoint** | `GET /users/{id}` |
| **API Version** | V1.0 |
| **Permission** | `User.Read.All` |

Standard Graph API - well documented.

**Contract Status:** [x] Verified [x] Documented [ ] Tested

---

### 5.2 Get Organization/Tenant Info
**Status:** VERIFIED (V1.0)

| Property | Value |
|----------|-------|
| **Endpoint** | `GET /organization` |
| **API Version** | V1.0 |
| **Permission** | `Directory.Read.All` |

Standard Graph API - well documented.

**Contract Status:** [x] Verified [x] Documented [ ] Tested

---
