# Critical Findings

### What EXISTS and is DOCUMENTED

| API Area | Status | Notes |
|----------|--------|-------|
| User Configurations | Beta - Documented | Full read access to user voice config |
| Number Assignments (READ) | Beta - Documented | List and get phone numbers |
| Number Assign/Unassign | Beta - Documented | Async operations with 202 response |
| Number Update | Beta - Documented | Update location, network site |
| Policy Assignment | Beta - Documented | Assign policies to users |

### What does NOT EXIST or is NOT DOCUMENTED

| API Area | Status | Workaround |
|----------|--------|------------|
| Emergency Locations API | **NOT AVAILABLE** | PowerShell CSV export (see Section 7) |
| Number Reserve/Unreserve | **NOT AVAILABLE** | No equivalent exists - dropped from MVP |
| Policy List by Type | **Not Found** | PowerShell CSV export (see Section 7) |

### ⚠️ Important Schema vs Enforcement Discrepancy

| API Endpoint | Parameter | Schema Says | Reality |
|--------------|-----------|-------------|---------|
| `assignNumber` | `locationId` | Optional | **REQUIRED for Calling Plan** (backend enforcement due to E911 regulations). Optional for Direct Routing. See Section 2.3 for details. |

**Impact**: CLI must detect number type and enforce location requirement based on numberType, not just the API schema.

---
