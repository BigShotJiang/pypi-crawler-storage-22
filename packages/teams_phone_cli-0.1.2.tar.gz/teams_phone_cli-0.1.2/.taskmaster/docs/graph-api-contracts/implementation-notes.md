# Implementation Notes

### Async Operations (assignNumber, unassignNumber) - VERIFIED

Both operations return `202 Accepted` with a `Location` header pointing to an operation status URL:
```
Location: https://graph.microsoft.com/beta/admin/teams/telephoneNumberManagement/operations('{operationId}')
```

**Implementation pattern:**
1. POST to assign/unassign endpoint
2. Extract operation ID from Location header
3. Poll the operations endpoint until status is complete or failed
4. Return result to user

**Operations Endpoint Response (VERIFIED):**
```json
{
  "id": "QXNzaWdubWVudHw2Y2E4Yjc0Ni0...",
  "createdDateTime": "2025-02-03T22:03:26Z",
  "status": "succeeded",  // notStarted | running | succeeded | failed | skipped
  "numbers": [
    {
      "resourceLocation": "https://graph.microsoft.com/beta/.../numberAssignments/{id}",
      "status": "succeeded"
    }
  ]
}
```

**Terminal States:** `succeeded`, `failed`, `skipped`

### Phone Number Format

- **assignNumber/unassignNumber:** Digits only, no `+` prefix (e.g., `12061234567`)
- **updateNumber:** With `+` prefix (e.g., `+12061234567`)
- **numberAssignments list/get:** Returns with `+` prefix

**Implementation:** Normalize phone numbers to handle both formats

---
