# Recommendations

### Recommended Approach: Graph API First

With assign/unassign/update now verified, the recommended approach is:

**Users:** Full functionality via Graph API
- `users list` - userConfigurations endpoint
- `users show` - userConfigurations endpoint
- `users search` - /users endpoint + userConfigurations

**Numbers:** Full functionality via Graph API
- `numbers list` - numberAssignments endpoint
- `numbers show` - numberAssignments with filter
- `numbers search` - numberAssignments with filter
- `numbers assign` - assignNumber endpoint (async)
- `numbers unassign` - unassignNumber endpoint (async)
- ~~`numbers reserve`~~ - Drop (feature doesn't exist)
- ~~`numbers unreserve`~~ - Drop (feature doesn't exist)

**Policies:** Full functionality via Graph + CSV
- `policies show` - via userConfigurations effectivePolicyAssignments
- `policies assign` - userAssignments/assign endpoint
- `policies list` - Read from policies.csv (PowerShell export)

**Locations:** Full functionality via CSV
- `locations list` - Read from locations.csv (PowerShell export)
- `locations show` - Read from locations.csv
- `locations search` - Read from locations.csv
- CLI validates locationId against CSV when assigning numbers

**Tenants:** Full functionality
- All tenant management is local config + Graph validation

**Auth:** Full functionality
- MSAL-based, no Graph dependency for auth itself

---
