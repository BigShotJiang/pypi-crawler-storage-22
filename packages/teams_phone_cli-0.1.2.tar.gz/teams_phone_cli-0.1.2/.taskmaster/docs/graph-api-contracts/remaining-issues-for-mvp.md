# Remaining Issues for MVP

### Resolved via PowerShell CSV Export

1. **Emergency Locations** - Solved via CSV export (see Section 7)
2. **Policy List** - Solved via CSV export (see Section 7)

### Dropped from MVP

1. **Reserve/Unreserve** - Feature does not exist anywhere; dropped

### Implementation Required

1. ~~**Async operations**~~ - VERIFIED: Schema documented in section 2.6; implement polling logic
2. ~~**Batch operations**~~ - VERIFIED: Use `beta/$batch` endpoint; documented in section 6.1
3. ~~**PowerShell output schemas**~~ - VERIFIED: Cmdlet outputs documented in section 7
4. **PowerShell export script** - Provide script for users to generate CSV files

---
