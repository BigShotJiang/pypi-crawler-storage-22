# Required Permissions Summary (Updated)

| Permission | Type | Purpose | Verified |
|------------|------|---------|----------|
| `TeamsUserConfiguration.Read.All` | Application | Read user voice config | Yes |
| `TeamsTelephoneNumber.Read.All` | Application | Read phone inventory | Yes |
| `TeamsTelephoneNumber.ReadWrite.All` | Application | Assign/unassign/update numbers | Yes |
| `TeamsPolicyUserAssign.ReadWrite.All` | Application | Assign policies | Yes |
| `User.Read.All` | Application | User profiles | Yes |
| `Directory.Read.All` | Application | Tenant info | Yes |

**Note:** `TeamsEmergencyLocation.Read.All` permission does not appear to exist - emergency locations are not exposed via Graph API.

---
