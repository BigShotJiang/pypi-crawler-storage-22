# Summary

| Category | Graph API | CSV Export | Dropped |
|----------|-----------|------------|---------|
| Users | 3 read | - | - |
| Numbers | 3 read, 3 write | - | reserve/unreserve |
| Policies | 1 read, 1 write | list by type | - |
| Locations | - | list, show, search | - |
| Directory | 2 read | - | - |
| **Total** | **9 read, 4 write** | **4 ops** | **2 ops** |

---
