# PRD: Test Infrastructure Refactoring

> Refactor test infrastructure to reduce file sizes, eliminate duplication, and improve maintainability for both AI agents and human developers.

---

## 1. Executive Summary

The Teams Phone CLI test suite has grown to include files exceeding 3,500 lines with 100+ duplicated mock patterns, creating significant maintenance burden and exceeding AI agent context limits. This refactoring introduces shared test fixtures, factory functions, and strategic file splitting to reduce the largest test file from 3,501 to under 1,000 lines while eliminating mock duplication through centralized pytest fixtures.

---

## 2. Problem Statement

### Current Situation

The test infrastructure has accumulated technical debt as the codebase grew:

| Issue | Current State | Impact |
|-------|---------------|--------|
| Largest test file | 3,501 lines (`test_cli_numbers.py`) | Exceeds AI context windows |
| Mock duplication | 100+ repeated patterns | High maintenance overhead |
| Factory duplication | 5 functions defined multiple times | Inconsistency risk |
| Test files > 1,400 lines | 6 files | Difficult navigation |

### User Impact

**AI Coding Agents (Claude Code, Copilot, etc.):**
- Cannot effectively process files exceeding ~2,000 lines
- Struggle to maintain context across large test files
- Generate inconsistent mock patterns due to scattered examples
- Fail to identify all relevant test cases when making changes

**Human Developers:**
- Spend excessive time navigating large files
- Introduce inconsistencies when copying mock boilerplate
- Risk missing related tests spread across thousands of lines
- Face difficulty onboarding new team members

### Business Impact

- **Development velocity**: Slower feature development due to test maintenance overhead
- **Quality risk**: Inconsistent mocks may mask bugs or introduce false positives
- **AI assistance degradation**: Reduced effectiveness of AI coding tools on test files
- **Onboarding cost**: New developers struggle to understand test patterns

### Why Solve This Now

The codebase has reached MVP completion, making this an ideal time for consolidation before adding new features. The analysis document (`.taskmaster\docs\REFACTORING_ANALYSIS.md`) provides clear metrics and actionable recommendations.

---

## 3. Goals & Success Metrics

| Goal | Metric | Baseline | Target | Timeframe |
|------|--------|----------|--------|-----------|
| G1: Reduce max test file size | Lines in largest test file | 3,501 | < 1,000 | Phase 2 |
| G2: Reduce max source file size | Lines in largest source file | 1,667 | < 800 | Phase 3 |
| G3: Eliminate mock duplication | Unique mock pattern instances | 100+ | < 20 | Phase 1 |
| G4: Consolidate factory functions | Duplicated factory definitions | 5 | 0 | Phase 1 |
| G5: Expand linting coverage | Ruff rules enabled | 4 | 10+ | Phase 4 |
| G6: Maintain test coverage | pytest coverage % | Current | No reduction | All phases |

### Success Definition

- All tests pass after each phase completion
- No reduction in code coverage metrics
- AI agents can successfully modify individual test files
- New test patterns use shared fixtures exclusively

---

## 4. User Stories

### US-001: AI Agent Test Modification

**As an** AI coding agent,
**I want** test files to be under 1,000 lines each,
**So that** I can effectively understand and modify tests within my context window.

**Acceptance Criteria:**
- [ ] No test file exceeds 1,000 lines
- [ ] Each test file focuses on a single command or feature area
- [ ] File names clearly indicate the scope (e.g., `test_cli_numbers_list.py`)
- [ ] Related tests are grouped logically within files

**Implementation Tasks:**
- Split `test_cli_numbers.py` into command-specific files
- Split `test_models.py` by model category
- Update imports and pytest configuration

---

### US-002: Developer Mock Setup

**As a** developer writing new tests,
**I want** pre-configured mock fixtures available,
**So that** I can write tests without copying boilerplate.

**Acceptance Criteria:**
- [ ] `mock_graph_client` fixture provides async context manager mock
- [ ] `mock_cli_infrastructure` fixture patches all CLI dependencies
- [ ] Fixtures are documented with usage examples
- [ ] IDE autocomplete works for fixture parameters

**Implementation Tasks:**
- Create fixtures in `tests/conftest.py`
- Add docstrings with examples
- Migrate existing tests incrementally

---

### US-003: Developer Factory Functions

**As a** developer creating test data,
**I want** centralized factory functions for domain objects,
**So that** I can create consistent test fixtures with minimal code.

**Acceptance Criteria:**
- [ ] `make_user()` creates `UserConfiguration` with sensible defaults
- [ ] `make_number()` creates `NumberAssignment` with sensible defaults
- [ ] `make_policy()` creates `Policy` with sensible defaults
- [ ] All factories support keyword argument overrides
- [ ] Factory return types match Pydantic models

**Implementation Tasks:**
- Create `tests/fixtures/factories.py`
- Implement factory for each domain model
- Update existing tests to use factories

---

### US-004: Maintainer Code Quality

**As a** code maintainer,
**I want** comprehensive linting rules enabled,
**So that** code quality issues are caught before commit.

**Acceptance Criteria:**
- [ ] Ruff checks for McCabe complexity (C901)
- [ ] Ruff checks for common bugs (B - bugbear)
- [ ] Ruff enforces import sorting (I - isort)
- [ ] Maximum complexity threshold set to 10
- [ ] All existing code passes new rules (or has explicit ignores)

**Implementation Tasks:**
- Update `pyproject.toml` with expanded ruff configuration
- Fix any new violations or add targeted ignores
- Document any ignored rules with rationale

---

## 5. Functional Requirements

### Phase 1: Test Infrastructure

| ID | Requirement | Priority | Testable Criteria |
|----|-------------|----------|-------------------|
| REQ-001 | Create `tests/conftest.py` with `mock_graph_client` fixture that returns AsyncMock configured as context manager | Must Have | Fixture importable and usable in test |
| REQ-002 | Create `tests/conftest.py` with `mock_cli_infrastructure` fixture that patches CacheManager, AuthService, GraphClient | Must Have | Single fixture replaces 4+ patch statements |
| REQ-003 | Create `tests/conftest.py` with `mock_number_service` fixture for NumberService mocking | Must Have | Fixture reduces boilerplate in numbers tests |
| REQ-004 | Create `tests/fixtures/__init__.py` package for shared test utilities | Must Have | Package importable |
| REQ-005 | Create `tests/fixtures/factories.py` with `make_user()` returning `UserConfiguration` | Must Have | `make_user()` returns valid model instance |
| REQ-006 | Create `tests/fixtures/factories.py` with `make_number()` returning `NumberAssignment` | Must Have | `make_number()` returns valid model instance |
| REQ-007 | Create `tests/fixtures/factories.py` with `make_policy()` returning `Policy` | Must Have | `make_policy()` returns valid model instance |
| REQ-008 | Create `tests/fixtures/factories.py` with `make_location()` returning `EmergencyLocation` | Should Have | `make_location()` returns valid model instance |
| REQ-009 | Create `tests/fixtures/factories.py` with `make_operation()` returning `AsyncOperation` | Should Have | `make_operation()` returns valid model instance |
| REQ-010 | All factory functions support `**kwargs` for field overrides | Must Have | `make_user(display_name="Test")` works |

### Phase 2: Test File Splitting

| ID | Requirement | Priority | Testable Criteria |
|----|-------------|----------|-------------------|
| REQ-011 | Split `test_cli_numbers.py` into `test_cli_numbers_list.py` (list command tests) | Must Have | File exists, tests pass, < 1000 lines |
| REQ-012 | Split `test_cli_numbers.py` into `test_cli_numbers_show.py` (show command tests) | Must Have | File exists, tests pass, < 1000 lines |
| REQ-013 | Split `test_cli_numbers.py` into `test_cli_numbers_assign.py` (assign/unassign tests) | Must Have | File exists, tests pass, < 1000 lines |
| REQ-014 | Split `test_cli_numbers.py` into `test_cli_numbers_bulk.py` (bulk operation tests) | Must Have | File exists, tests pass, < 1000 lines |
| REQ-015 | Split `test_models.py` by model category (user, number, policy, location) | Should Have | Each file < 1000 lines |
| REQ-016 | Split `test_number_service.py` by operation type | Should Have | Each file < 1000 lines |
| REQ-017 | Update all split test files to use shared fixtures from Phase 1 | Must Have | No duplicated mock patterns in new files |

### Phase 3: Source Refactoring

| ID | Requirement | Priority | Testable Criteria |
|----|-------------|----------|-------------------|
| REQ-018 | Extract `_run_async` helper to `src/teams_phone/cli/helpers.py` | Should Have | Single definition, imported by 3 CLI modules |
| REQ-019 | Create generic `run_with_service()` function supporting any service type | Should Have | Function accepts service factory parameter |
| REQ-020 | Update `cli/numbers.py`, `cli/policies.py`, `cli/users.py` to import from helpers | Should Have | No duplicate `_run_async` definitions |
| REQ-021 | Split `cli/numbers.py` into submodules if > 800 lines after helper extraction | Could Have | Main file < 800 lines |

### Phase 4: Linting Expansion

| ID | Requirement | Priority | Testable Criteria |
|----|-------------|----------|-------------------|
| REQ-022 | Add C901 (McCabe complexity) to ruff rules with max-complexity=10 | Should Have | `ruff check` enforces complexity |
| REQ-023 | Add B (bugbear) to ruff rules | Should Have | Common bug patterns detected |
| REQ-024 | Add I (isort) to ruff rules | Should Have | Import sorting enforced |
| REQ-025 | Add SIM (simplify) to ruff rules | Could Have | Code simplification suggestions |
| REQ-026 | Add UP (pyupgrade) to ruff rules | Could Have | Python version upgrades suggested |
| REQ-027 | All code passes expanded ruff rules or has documented ignores | Must Have | `ruff check` exits 0 |

---

## 6. Non-Functional Requirements

### Performance

| Requirement | Target | Measurement |
|-------------|--------|-------------|
| Test suite execution time | No increase > 10% | `pytest --durations=0` comparison |
| Individual test file load time | < 2 seconds | pytest collection time |
| Factory function execution | < 1ms per call | Benchmark test |

### Reliability

| Requirement | Target |
|-------------|--------|
| Test determinism | 100% - no flaky tests introduced |
| CI pipeline stability | All existing workflows pass |
| Fixture isolation | No state leakage between tests |

### Maintainability

| Requirement | Target |
|-------------|--------|
| Documentation | All fixtures have docstrings with examples |
| Code organization | Clear file naming conventions |
| Import clarity | No circular imports |

### Compatibility

| Requirement | Target |
|-------------|--------|
| pytest version | Compatible with pytest 7.x+ |
| Python version | Works with Python 3.11+ |
| IDE support | Fixtures discoverable by PyCharm/VSCode |

---

## 7. Technical Considerations

### Architecture Implications

The refactoring maintains the existing layered architecture while improving test organization:

```
tests/
├── conftest.py              # Shared fixtures (NEW)
├── fixtures/
│   ├── __init__.py          # Package marker (NEW)
│   └── factories.py         # Factory functions (NEW)
├── unit/
│   ├── test_cli_numbers_list.py    # Split from test_cli_numbers.py
│   ├── test_cli_numbers_show.py    # Split from test_cli_numbers.py
│   ├── test_cli_numbers_assign.py  # Split from test_cli_numbers.py
│   ├── test_cli_numbers_bulk.py    # Split from test_cli_numbers.py
│   ├── test_models_user.py         # Split from test_models.py
│   ├── test_models_number.py       # Split from test_models.py
│   └── ...
```

### Fixture Design

```python
# tests/conftest.py

import pytest
from unittest.mock import AsyncMock, patch

@pytest.fixture
def mock_graph_client():
    """
    Provides a mock GraphClient configured as async context manager.

    Usage:
        def test_something(mock_graph_client):
            mock_graph_client.get.return_value = {"data": "value"}
            # ... test code
    """
    mock = AsyncMock()
    mock.__aenter__.return_value = mock
    mock.__aexit__.return_value = None
    return mock

@pytest.fixture
def mock_cli_infrastructure(mock_graph_client):
    """
    Patches all CLI infrastructure components.

    Returns dict with:
        - graph_client: The mock GraphClient instance
        - graph_client_class: The patched class
        - cache_manager: The mock CacheManager
        - auth_service: The mock AuthService

    Usage:
        def test_command(mock_cli_infrastructure):
            mock_cli_infrastructure["graph_client"].get.return_value = {...}
    """
    with (
        patch("teams_phone.cli.numbers.CacheManager") as mock_cache,
        patch("teams_phone.cli.numbers.AuthService") as mock_auth,
        patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
    ):
        mock_gc_class.return_value = mock_graph_client
        yield {
            "graph_client": mock_graph_client,
            "graph_client_class": mock_gc_class,
            "cache_manager": mock_cache,
            "auth_service": mock_auth,
        }
```

### Factory Design

```python
# tests/fixtures/factories.py

from teams_phone.models import (
    UserConfiguration,
    NumberAssignment,
    Policy,
    EmergencyLocation,
    AsyncOperation,
)

def make_user(**kwargs) -> UserConfiguration:
    """
    Create a UserConfiguration with sensible defaults.

    Usage:
        user = make_user()  # All defaults
        user = make_user(display_name="Alice", enterprise_voice_enabled=True)
    """
    defaults = {
        "id": "user-123",
        "userPrincipalName": "user@contoso.com",
        "displayName": "Test User",
        "enterpriseVoiceEnabled": False,
        "lineUri": None,
        "onlineVoiceRoutingPolicy": None,
        "teamsCallingPolicy": None,
        "tenantDialPlan": None,
    }
    defaults.update(kwargs)
    return UserConfiguration.model_validate(defaults)

def make_number(**kwargs) -> NumberAssignment:
    """
    Create a NumberAssignment with sensible defaults.
    """
    defaults = {
        "id": "num-123",
        "telephoneNumber": "+14255551234",
        "numberType": "directRouting",
        "assignedTo": None,
        "capabilities": ["voice"],
        "city": "Seattle",
        "countryCode": "US",
    }
    defaults.update(kwargs)
    return NumberAssignment.model_validate(defaults)

# Additional factories for Policy, EmergencyLocation, AsyncOperation...
```

### Migration Strategy

1. **Parallel structure**: New fixtures exist alongside old patterns
2. **Incremental adoption**: Update tests file-by-file
3. **Validation**: Run full test suite after each file migration
4. **Cleanup**: Remove old patterns only after all tests migrated

### Testing Strategy

- Run `pytest tests/` after each change
- Monitor coverage with `pytest --cov=teams_phone`
- Use `pytest --collect-only` to verify test discovery
- Run CI pipeline on each phase completion

---

## 8. Implementation Roadmap

### Phase 1: Test Infrastructure (Foundation)

**Objective:** Create shared fixtures and factories

| Task | Description | Dependencies |
|------|-------------|--------------|
| 1.1 | Create `tests/fixtures/` package with `__init__.py` | None |
| 1.2 | Implement `factories.py` with all factory functions | 1.1 |
| 1.3 | Add mock fixtures to `tests/conftest.py` | None |
| 1.4 | Write tests for factory functions | 1.2 |
| 1.5 | Document fixtures with examples | 1.2, 1.3 |

**Exit Criteria:**
- All factory functions return valid Pydantic models
- Fixtures are importable and documented
- Existing tests still pass (no changes to existing tests yet)

---

### Phase 2: Test File Splitting (Highest Impact)

**Objective:** Split large test files into focused modules

| Task | Description | Dependencies |
|------|-------------|--------------|
| 2.1 | Analyze `test_cli_numbers.py` to identify logical splits | Phase 1 |
| 2.2 | Create `test_cli_numbers_list.py` with list command tests | 2.1 |
| 2.3 | Create `test_cli_numbers_show.py` with show command tests | 2.1 |
| 2.4 | Create `test_cli_numbers_assign.py` with assign tests | 2.1 |
| 2.5 | Create `test_cli_numbers_bulk.py` with bulk operation tests | 2.1 |
| 2.6 | Migrate split files to use shared fixtures | 2.2-2.5 |
| 2.7 | Delete original `test_cli_numbers.py` | 2.6 |
| 2.8 | Split `test_models.py` by model category | Phase 1 |
| 2.9 | Split remaining large test files | 2.8 |

**Exit Criteria:**
- No test file exceeds 1,000 lines
- All tests pass
- Coverage unchanged or improved

---

### Phase 3: Source Refactoring (Lower Priority)

**Objective:** Extract duplicated CLI helpers

| Task | Description | Dependencies |
|------|-------------|--------------|
| 3.1 | Create `src/teams_phone/cli/helpers.py` | None |
| 3.2 | Implement `run_with_service()` generic helper | 3.1 |
| 3.3 | Update `cli/numbers.py` to use helper | 3.2 |
| 3.4 | Update `cli/policies.py` to use helper | 3.2 |
| 3.5 | Update `cli/users.py` to use helper | 3.2 |
| 3.6 | Evaluate if `cli/numbers.py` needs splitting | 3.3-3.5 |

**Exit Criteria:**
- Single `_run_async` / `run_with_service` definition
- All CLI commands function correctly
- Source file sizes reduced

---

### Phase 4: Linting Expansion (Polish)

**Objective:** Expand code quality rules

| Task | Description | Dependencies |
|------|-------------|--------------|
| 4.1 | Add C901 (complexity) rule to ruff | None |
| 4.2 | Add B (bugbear) rule to ruff | None |
| 4.3 | Add I (isort) rule to ruff | None |
| 4.4 | Fix or ignore new violations | 4.1-4.3 |
| 4.5 | Add SIM, UP rules (optional) | 4.4 |
| 4.6 | Document any rule exclusions | 4.4 |

**Exit Criteria:**
- 10+ ruff rules enabled
- All code passes `ruff check`
- Exclusions documented with rationale

---

## 9. Out of Scope

The following are explicitly **NOT** included in this refactoring:

| Item | Reason |
|------|--------|
| Test behavior changes | Refactoring only - same test logic |
| New test cases | Focus on infrastructure, not coverage expansion |
| Integration test changes | Unit test focus only |
| CLI functional changes | No changes to CLI behavior |
| Model changes | Pydantic models unchanged |
| API contract changes | Graph API integration unchanged |
| Documentation updates | Beyond fixture docstrings |
| Performance optimization | Not a performance refactoring |
| Dependency upgrades | Keep current versions |

**Future Considerations:**
- Integration test infrastructure improvements
- Test data generation with Hypothesis
- Parallel test execution optimization

---

## 10. Open Questions & Risks

### Open Questions

| Question | Owner | Status |
|----------|-------|--------|
| Q1: Should factories use builder pattern or simple functions? | Developer | Simple functions recommended |
| Q2: Should mock fixtures be module-scoped for performance? | Developer | Function-scoped for isolation |
| Q3: What naming convention for split test files? | Developer | `test_<module>_<command>.py` |

### Known Risks

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| R1: Test coverage reduction during splits | Medium | High | Run coverage after each split |
| R2: Import path breaks in CI | Low | Medium | Test CI pipeline early in Phase 2 |
| R3: Fixture state leakage | Low | High | Use function-scoped fixtures, add isolation tests |
| R4: IDE fixture discovery issues | Low | Low | Ensure `conftest.py` in correct location |
| R5: Merge conflicts if parallel work | Medium | Medium | Complete refactoring before new features |

### Mitigation Strategies

**R1 Coverage Reduction:**
- Run `pytest --cov` before and after each file split
- Block merge if coverage decreases
- Add coverage threshold to CI

**R2 Import Path Breaks:**
- Run CI pipeline after Phase 1 completion
- Test imports manually before pushing

**R3 Fixture State Leakage:**
- Always use function-scoped fixtures
- Add tests that verify fixture isolation
- Review any module-scoped fixtures carefully

---

## 11. Validation Checkpoints

### Phase 1 Completion Checklist

- [ ] `tests/fixtures/__init__.py` exists
- [ ] `tests/fixtures/factories.py` implements all required factories
- [ ] Each factory has docstring with usage example
- [ ] Factory unit tests pass
- [ ] `conftest.py` fixtures documented
- [ ] All existing tests still pass
- [ ] Coverage unchanged

### Phase 2 Completion Checklist

- [ ] `test_cli_numbers.py` split into 4+ files
- [ ] Each new file < 1,000 lines
- [ ] All new files use shared fixtures
- [ ] No duplicated mock patterns in new files
- [ ] Original file deleted
- [ ] `test_models.py` split by category
- [ ] All tests pass
- [ ] Coverage unchanged

### Phase 3 Completion Checklist

- [ ] `cli/helpers.py` created with `run_with_service()`
- [ ] `cli/numbers.py` uses shared helper
- [ ] `cli/policies.py` uses shared helper
- [ ] `cli/users.py` uses shared helper
- [ ] No duplicate `_run_async` definitions
- [ ] All CLI commands work correctly
- [ ] All tests pass

### Phase 4 Completion Checklist

- [ ] Ruff config has 10+ rules enabled
- [ ] C901 (complexity) enabled with max=10
- [ ] B (bugbear) enabled
- [ ] I (isort) enabled
- [ ] `ruff check` passes
- [ ] Any exclusions documented
- [ ] Pre-commit hooks updated

### Final Validation

- [ ] All 4 phases complete
- [ ] No test file > 1,000 lines
- [ ] No source file > 800 lines
- [ ] Mock pattern count < 20 unique instances
- [ ] 0 duplicated factory functions
- [ ] Full test suite passes
- [ ] CI pipeline green
- [ ] Coverage >= baseline

---

*Generated: 2026-02-02*
