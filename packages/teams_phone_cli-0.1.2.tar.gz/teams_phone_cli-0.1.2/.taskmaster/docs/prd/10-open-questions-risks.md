# 10. Open Questions & Risks

### Open Questions

| ID | Question | Owner | Status | Decision |
|----|----------|-------|--------|----------|
| OQ-001 | Should we support interactive device-code auth for personal use? | Product | Open | Leaning no - automation focus |
| OQ-002 | Package distribution: PyPI, standalone binary, or both? | Engineering | Open | - |
| OQ-003 | Should CSV export be bundled or separate repo? | Engineering | Open | - |
| OQ-004 | What is the minimum supported Python version? | Engineering | Open | Likely 3.10+ |

### Known Risks

| ID | Risk | Probability | Impact | Mitigation |
|----|------|-------------|--------|------------|
| R-001 | Microsoft Graph beta APIs change without notice | Medium | High | Strict Pydantic schema validation (extra='forbid'), `api-check` pre-flight command, daily CI contract tests against test tenant, immediate failure on schema mismatch |
| R-002 | PowerShell Teams module incompatibilities | Medium | Medium | Document supported versions, test matrix |
| R-003 | Rate limiting impacts bulk operations | High | Medium | Implement smart throttling, batch where possible, document limits |
| R-004 | TeamsVoicemailPolicy cannot be assigned via Graph | Confirmed | Low | Document limitation, suggest PowerShell fallback |
| R-005 | Large tenant performance (> 5000 users) | Low | Medium | Implement pagination, streaming output |
| R-006 | Certificate management complexity | Medium | Medium | Provide clear documentation, support multiple cert formats |

### Areas Needing Research

| Topic | Questions | Priority |
|-------|-----------|----------|
| Token encryption | Best practice for cross-platform secure token storage | High |
| Batch API optimization | Can batch endpoint improve bulk operation performance? | Medium |
| Shell completion | Best approach for bash/zsh/fish/PowerShell completions | Low |

---
