# 11. Validation Checkpoints

### Checkpoint 1: Authentication & Tenant Management (Phase 1 Complete)

**Validation Criteria:**
- [ ] Can authenticate with certificate
- [ ] Can authenticate with client secret (env var)
- [ ] Can add/list/switch/remove tenant profiles
- [ ] Token caching works across sessions
- [ ] --tenant flag overrides active tenant
- [ ] `api-check` validates all endpoint schemas and reports results
- [ ] API responses fail fast on unexpected schema changes (strict Pydantic)

### Checkpoint 2: Read Operations (Phase 2 Complete)

**Validation Criteria:**
- [ ] `users list` returns paginated results with all fields
- [ ] `users show` returns complete voice configuration
- [ ] `numbers list` returns inventory with status
- [ ] `numbers search` finds numbers by pattern
- [ ] `locations list` reads from CSV correctly
- [ ] Staleness warning displayed for old CSV
- [ ] --json output is valid JSON for all commands

### Checkpoint 3: Write Operations (Phase 3 Complete)

**Validation Criteria:**
- [ ] `numbers assign` completes async operation successfully
- [ ] E911 enforcement blocks Calling Plan without location
- [ ] `numbers unassign` completes successfully
- [ ] `policies assign` applies policy correctly
- [ ] --dry-run shows preview without changes
- [ ] --force skips confirmation prompts

### Checkpoint 4: Bulk Operations (Phase 4 Complete)

**Validation Criteria:**
- [ ] `numbers bulk-assign` processes 100-row CSV successfully
- [ ] Progress bar updates in real-time
- [ ] --continue-on-error processes all rows
- [ ] Results file generated with success/failure status
- [ ] Error messages include remediation guidance

### Checkpoint 5: Production Ready (Phase 5 Complete)

**Validation Criteria:**
- [ ] Unit test coverage > 80%
- [ ] All core workflows pass integration tests
- [ ] Documentation complete
- [ ] PowerShell export script tested
- [ ] Performance meets targets (< 3s single lookup, < 5s list)

---
