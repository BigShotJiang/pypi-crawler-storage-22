# 6. Non-Functional Requirements

### Performance

| Requirement | Target | Measurement |
|-------------|--------|-------------|
| Single user/number lookup | < 3 seconds | p95 latency |
| List commands (default page) | < 5 seconds | p95 latency |
| Tenant switch | < 5 seconds | p95 latency |
| Bulk operation throughput | > 10 items/minute | Sustained rate accounting for API throttling |
| CLI startup time | < 500ms | Cold start to ready |

### Security

| Requirement | Implementation |
|-------------|----------------|
| No plaintext secrets in config files | Secrets via environment variables or secure storage only |
| Certificate-based auth preferred | Documentation recommends certificates over client secrets |
| Token caching with encryption | Cached tokens encrypted at rest |
| Audit logging capability | All operations logged with sanitized PII (--debug-log) |
| Secrets never in debug logs | Tokens and secrets masked in all log output |

### Reliability

| Requirement | Target |
|-------------|--------|
| Graceful API error handling | 100% of Graph API errors mapped to user-friendly messages |
| Retry with backoff for transient failures | 3 retries with exponential backoff for 429/503 |
| Cache fallback for read operations | Stale data served with warning if API unavailable |
| Bulk operation continuation | --continue-on-error allows processing to complete |
| Schema validation | 100% of Graph API responses validated against Pydantic models (strict mode) |
| Contract drift detection | Automated CI check runs daily against test tenant |

### Scalability

| Dimension | Requirement |
|-----------|-------------|
| User count | Support tenants with up to 5,000 users |
| Number inventory | Support up to 10,000 phone numbers per tenant |
| Bulk operations | Handle CSV files with up to 1,000 rows |
| Concurrent tenants | Support 50+ configured tenant profiles |

### Compatibility

| Dimension | Requirement |
|-----------|-------------|
| Operating Systems | Windows 10+, macOS 12+, Linux (Ubuntu 20.04+, RHEL 8+) |
| Python Version | Python 3.10+ |
| Terminal | Support for standard terminals, CI/CD environments |
| Graph API | Beta endpoints (with awareness of potential changes) |

### Accessibility

| Requirement | Implementation |
|-------------|----------------|
| Screen reader compatible | Text-based output, no ASCII art dependencies |
| Color optional | --no-color flag or NOCOLOR env var support |
| Keyboard only operation | No mouse/GUI dependencies |

---
