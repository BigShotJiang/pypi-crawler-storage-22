# 9. Out of Scope

The following items are explicitly **NOT included** in this MVP:

### Functionality Not Included

| Item | Reason | Future Consideration |
|------|--------|----------------------|
| Number reservation/unreservation | No Graph API or PowerShell equivalent exists | Monitor for future API availability |
| Location creation/modification | Graph API does not support; requires TAC or PowerShell | May add PowerShell wrapper post-MVP |
| Policy creation/modification | Graph API does not support listing/creating policies | May add PowerShell wrapper post-MVP |
| Resource account management | Complex scenario, separate domain | Phase 2 feature |
| Call queue/auto-attendant management | Different API surface, complex workflows | Phase 2 feature |
| Teams meeting policies | Not voice-specific | Out of domain |
| Reporting/analytics | Requires different data sources | Phase 2 feature |
| GUI/TUI interface | CLI-first approach | Community contribution opportunity |

### Technical Scope Exclusions

| Item | Reason |
|------|--------|
| Graph API v1.0 | Teams Admin APIs are beta-only |
| Interactive/device-code auth | Service principal only (automation focus) |
| Windows certificate store | File-based certificates for cross-platform |
| Automatic CSV refresh | User runs PowerShell script manually |
| Real-time webhooks | Polling-based approach for MVP |

---
