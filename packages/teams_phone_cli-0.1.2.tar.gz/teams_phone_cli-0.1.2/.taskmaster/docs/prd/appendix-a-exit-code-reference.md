# Appendix A: Exit Code Reference

| Code | Meaning | Example Scenario |
|------|---------|------------------|
| 0 | Success | Command completed successfully |
| 1 | General error | Unexpected error, network failure |
| 2 | Authentication error | Invalid credentials, expired token |
| 3 | Authorization error | Missing Graph API permissions |
| 4 | Not found | User, number, or policy not found |
| 5 | Validation error | Invalid input, missing required field, E911 violation |
| 6 | Rate limit exceeded | Graph API throttling after retries |
| 7 | Configuration error | Invalid config file, missing tenant |

---
