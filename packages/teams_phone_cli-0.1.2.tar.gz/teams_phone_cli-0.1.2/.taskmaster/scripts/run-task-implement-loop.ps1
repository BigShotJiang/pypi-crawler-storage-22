<#
.SYNOPSIS
    Runs /task-implement command multiple times in sequence.

.DESCRIPTION
    Executes the claude CLI with /task-implement command for a specified number of iterations.
    Useful for batch processing multiple tasks sequentially.

.PARAMETER Count
    Number of times to run the /task-implement command. Must be a positive integer.

.EXAMPLE
    .\run-task-implement-loop.ps1 -Count 5
    Runs /task-implement 5 times in sequence.

.EXAMPLE
    .\run-task-implement-loop.ps1 5
    Runs /task-implement 5 times (positional parameter).
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateRange(1, [int]::MaxValue)]
    [int]$Count
)

Write-Host "Starting task implementation loop for $Count iteration(s)..." -ForegroundColor Cyan
Write-Host ""

for ($i = 1; $i -le $Count; $i++) {
    Write-Host "========================================" -ForegroundColor Yellow
    Write-Host "Iteration $i of $Count" -ForegroundColor Yellow
    Write-Host "========================================" -ForegroundColor Yellow
    Write-Host ""

    # Run the claude command
    & claude --dangerously-skip-permissions -p "/task-implement"

    $exitCode = $LASTEXITCODE

    if ($exitCode -ne 0) {
        Write-Host ""
        Write-Host "Command failed with exit code: $exitCode" -ForegroundColor Red
        Write-Host "Stopping execution at iteration $i of $Count" -ForegroundColor Red
        exit $exitCode
    }

    Write-Host ""
    Write-Host "Completed iteration $i of $Count" -ForegroundColor Green

    # Add separator between iterations (except after the last one)
    if ($i -lt $Count) {
        Write-Host ""
        Write-Host "---" -ForegroundColor DarkGray
        Write-Host ""
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "All $Count iteration(s) completed successfully!" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
