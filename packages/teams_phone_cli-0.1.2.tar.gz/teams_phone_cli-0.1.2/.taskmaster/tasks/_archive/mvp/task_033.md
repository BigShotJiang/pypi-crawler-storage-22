# Task ID: 33

**Title:** Write Unit Tests for Infrastructure Layer

**Status:** done

**Dependencies:** 4, 5, 7, 8, 32

**Priority:** high

**Description:** Create comprehensive unit tests for ConfigManager, CacheManager, GraphClient, and OutputFormatter.

**Details:**

Create tests in `tests/unit/infrastructure/`:

`test_config_manager.py`: load/save config, tenant CRUD, default tenant, missing file handling, validation errors.

`test_cache_manager.py`: token storage/retrieval, CSV reading, staleness detection, missing files, metadata parsing.

`test_graph_client.py` (with respx):
- Successful GET/POST requests
- Retry on 429 with Retry-After header
- Retry on 5xx with exponential backoff
- Token refresh on 401
- Proper error mapping to exceptions
- Pagination handling

`test_output_formatter.py`: table output, JSON mode, color handling, progress bars.

Target: >85% coverage for infrastructure layer.

**Test Strategy:**

Run `pytest tests/unit/infrastructure/ --cov=teams_phone.infrastructure --cov-report=term-missing` and verify >85% coverage.

---

## Completion Notes (2026-01-30)

Tests were written incrementally during feature development rather than as a separate phase. All infrastructure components now have comprehensive unit tests located in `tests/unit/` (flat structure, not `tests/unit/infrastructure/`).

### Coverage Results (Target: >85%)

| Component | Coverage | Status |
|-----------|----------|--------|
| config_manager.py | 98% | ✅ Exceeds |
| cache_manager.py | 94% | ✅ Exceeds |
| graph_client.py | 87% | ✅ Meets |
| output_formatter.py | 100% | ✅ Exceeds |
| debug_logger.py | 100% | ✅ Exceeds |

### Test Files Created

- `tests/unit/test_config_manager.py` - Config load/save, tenant CRUD, validation
- `tests/unit/test_cache_manager.py` - Token storage, CSV reading, staleness detection
- `tests/unit/test_graph_client.py` - HTTP requests, retry logic, error mapping (uses respx)
- `tests/unit/test_output_formatter.py` - Table output, JSON mode, formatting

### Remaining Gaps (Low Priority)

- `graph_client.py` lines 484-498: POST method with debug logging instrumentation
- Debug logging paths are low-value to unit test
