# Task ID: 2

**Title:** Implement factory functions in factories.py

**Status:** pending

**Dependencies:** 1

**Priority:** high

**Description:** Create tests/fixtures/factories.py with factory functions for all domain models: make_user(), make_number(), make_policy(), make_location(), and make_operation().

**Details:**

Create factories that return valid Pydantic model instances with sensible defaults. Each factory should support **kwargs for field overrides.

```python
# tests/fixtures/factories.py
"""Factory functions for creating test domain objects.

All factories return valid Pydantic model instances with sensible defaults.
Use keyword arguments to override any default value.

Example:
    user = make_user()  # All defaults
    user = make_user(display_name="Alice", enterprise_voice_enabled=True)
"""

from datetime import datetime, timezone
from typing import Any

from teams_phone.models import (
    AccountType,
    ActivationState,
    AssignmentStatus,
    AsyncOperation,
    EmergencyLocation,
    NumberAssignment,
    NumberType,
    OperationStatus,
    Policy,
    UserConfiguration,
)

def make_user(**kwargs: Any) -> UserConfiguration:
    """Create a UserConfiguration with sensible defaults.
    
    Args:
        **kwargs: Override any field (use snake_case or camelCase).
        
    Returns:
        A valid UserConfiguration instance.
        
    Example:
        user = make_user(display_name="Alice")
        user = make_user(userPrincipalName="alice@contoso.com")
    """
    defaults = {
        "id": "user-123",
        "userPrincipalName": "user@contoso.com",
        "tenantId": "tenant-123",
        "displayName": "Test User",
        "accountType": AccountType.USER.value,
        "isEnterpriseVoiceEnabled": True,
        "featureTypes": ["Teams"],
        "telephoneNumbers": [],
        "effectivePolicyAssignments": [],
    }
    defaults.update(kwargs)
    return UserConfiguration.model_validate(defaults)

def make_number(**kwargs: Any) -> NumberAssignment:
    """Create a NumberAssignment with sensible defaults.
    
    Args:
        **kwargs: Override any field (use snake_case or camelCase).
        
    Returns:
        A valid NumberAssignment instance.
    """
    defaults = {
        "id": "num-123",
        "telephoneNumber": "+14255551234",
        "numberType": NumberType.DIRECT_ROUTING.value,
        "assignmentStatus": AssignmentStatus.UNASSIGNED.value,
        "activationState": ActivationState.ACTIVATED.value,
        "capabilities": ["userAssignment"],
        "city": "Seattle",
    }
    defaults.update(kwargs)
    return NumberAssignment.model_validate(defaults)

def make_policy(**kwargs: Any) -> Policy:
    """Create a Policy with sensible defaults."""
    defaults = {
        "policyType": "TeamsCallingPolicy",
        "policyName": "AllowCalling",
        "policyId": "policy-123",
        "description": "Test policy",
        "isGlobal": False,
    }
    defaults.update(kwargs)
    return Policy.model_validate(defaults)

def make_location(**kwargs: Any) -> EmergencyLocation:
    """Create an EmergencyLocation with sensible defaults."""
    defaults = {
        "locationId": "loc-123",
        "civicAddressId": "civic-123",
        "description": "Seattle HQ",
        "isDefault": True,
    }
    defaults.update(kwargs)
    return EmergencyLocation.model_validate(defaults)

def make_operation(**kwargs: Any) -> AsyncOperation:
    """Create an AsyncOperation with sensible defaults."""
    defaults = {
        "id": "op-123",
        "createdDateTime": datetime.now(timezone.utc).isoformat(),
        "status": OperationStatus.SUCCEEDED.value,
        "numbers": [],
    }
    defaults.update(kwargs)
    return AsyncOperation.model_validate(defaults)
```

**Test Strategy:**

Create tests/unit/test_factories.py with tests verifying each factory returns valid Pydantic models, accepts overrides, and validates field types. Run `uv run pytest tests/unit/test_factories.py -v`.

---

## Implementation Notes

### Session: 2026-02-02 17:00 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Verified factory implementation in `tests/fixtures/factories.py` already exists (created during Task 1)
- Created comprehensive test file: `tests/unit/test_factories.py`
- 43 tests covering all 5 factory functions organized into 6 test classes:
  - `TestMakeUser` (9 tests)
  - `TestMakeNumber` (10 tests)
  - `TestMakePolicy` (5 tests)
  - `TestMakeLocation` (5 tests)
  - `TestMakeOperation` (10 tests)
  - `TestFactoryIntegration` (4 tests)

#### Key Decisions Made
- Test categories: defaults, overrides, return types, enum handling, validation errors, integration
- Added `type: ignore[arg-type]` comments for kwargs override tests to satisfy mypy
- Added `type: ignore[import-untyped]` for teams_phone.models import (no py.typed marker)

#### Patterns Discovered
- `EffectivePolicyAssignment` has nested structure with `policyAssignment` field containing `PolicyAssignmentDetail`
- Enum values must use camelCase (e.g., `"resourceAccount"` not `"ResourceAccount"`)
- `OperationStatus.NOT_STARTED` instead of `PENDING`
- `ActivationState.ASSIGNMENT_PENDING` not `ACTIVATION_PENDING`

#### Test Coverage Details
- Default value validation for all fields
- Keyword argument overrides (snake_case parameters)
- Raw kwargs overrides (camelCase for model_validate)
- Enum handling (both enum instances and string values)
- ValidationError on invalid inputs
- None values for optional fields
- Nested model creation (TelephoneNumber, EffectivePolicyAssignment, OperationNumber)
- Integration tests for cross-factory consistency

#### Gotchas and Warnings
- When passing raw dicts for `effective_policy_assignments`, use the correct nested structure:
  ```python
  {"policyType": "...", "policyAssignment": {"displayName": "...", "assignmentType": "...", "policyId": "..."}}
  ```
- The `OperationNumber.status` field is a string (not OperationStatus enum) when creating via factory

---
