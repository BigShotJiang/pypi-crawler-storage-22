# Task ID: 3

**Title:** Add shared mock fixtures to conftest.py

**Status:** pending

**Dependencies:** 1

**Priority:** high

**Description:** Enhance tests/conftest.py with mock_graph_client, mock_cli_infrastructure, and mock_number_service fixtures to eliminate repetitive mock setup.

**Details:**

Add fixtures to the existing tests/conftest.py that provide pre-configured mocks. The current mock_graph_client fixture returns a basic MagicMock; replace it with an AsyncMock configured as an async context manager.

```python
# Add to tests/conftest.py after existing imports
from unittest.mock import AsyncMock, patch
from typing import Generator, Any

@pytest.fixture
def mock_graph_client() -> AsyncMock:
    """Provides a mock GraphClient configured as async context manager.
    
    The mock is pre-configured for use with `async with GraphClient(...):`
    
    Usage:
        def test_something(mock_graph_client):
            mock_graph_client.get.return_value = {"data": "value"}
            # ... test code using mock_graph_client
    """
    mock = AsyncMock()
    mock.__aenter__.return_value = mock
    mock.__aexit__.return_value = None
    return mock

@pytest.fixture
def mock_cli_infrastructure(mock_graph_client: AsyncMock) -> Generator[dict[str, Any], None, None]:
    """Patches all CLI infrastructure components.
    
    Returns dict with:
        - graph_client: The mock GraphClient instance
        - graph_client_class: The patched GraphClient class
        - cache_manager: The mock CacheManager class
        - auth_service: The mock AuthService class
        
    Usage:
        def test_command(mock_cli_infrastructure):
            infra = mock_cli_infrastructure
            infra["graph_client"].get.return_value = {...}
    """
    with (
        patch("teams_phone.cli.numbers.CacheManager") as mock_cache,
        patch("teams_phone.cli.numbers.AuthService") as mock_auth,
        patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
    ):
        mock_gc_class.return_value = mock_graph_client
        yield {
            "graph_client": mock_graph_client,
            "graph_client_class": mock_gc_class,
            "cache_manager": mock_cache,
            "auth_service": mock_auth,
        }

@pytest.fixture
def mock_number_service(mock_cli_infrastructure: dict[str, Any]) -> Generator[dict[str, Any], None, None]:
    """Patches NumberService along with CLI infrastructure.
    
    Returns dict with all mock_cli_infrastructure keys plus:
        - number_service: The mock NumberService instance
        - number_service_class: The patched NumberService class
    """
    with patch("teams_phone.cli.numbers.NumberService") as mock_ns_class:
        mock_service = MagicMock()
        mock_ns_class.return_value = mock_service
        yield {
            **mock_cli_infrastructure,
            "number_service": mock_service,
            "number_service_class": mock_ns_class,
        }
```

**Test Strategy:**

Write fixture smoke tests in tests/unit/test_conftest_fixtures.py verifying fixtures are importable and return expected types. Run full test suite to ensure no regressions: `uv run pytest tests/ -m unit`.

---

## Implementation Notes

### Session: 2026-02-02 17:45 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Replaced `mock_graph_client` fixture in `tests/conftest.py` with AsyncMock configured as async context manager
- Added `mock_cli_infrastructure` fixture that patches CacheManager, AuthService, and GraphClient at `teams_phone.cli.numbers` module level
- Added `mock_number_service` fixture that extends `mock_cli_infrastructure` with NumberService mock
- Created `tests/test_shared_fixtures.py` with 14 smoke tests for the new fixtures
- Created `tests/unit/conftest.py` with backward-compatible `mock_graph_client` override for service-level unit tests

#### Key Decisions Made
- **Fixture test location**: Moved fixture smoke tests to `tests/test_shared_fixtures.py` (root level) instead of `tests/unit/test_conftest_fixtures.py` because pytest fixtures use closest conftest.py - tests under `tests/unit/` would pick up the MagicMock override instead of the AsyncMock from root conftest.py
- **Backward compatibility**: Added `tests/unit/conftest.py` with a `mock_graph_client` fixture that returns plain MagicMock. This overrides the root fixture for unit tests, preserving backward compatibility for service-level tests (e.g., `test_user_service.py`) that inject mocks directly into services rather than using them as async context managers.
- **Fixture structure differs from task spec**: The implementation uses independent infrastructure mocks (not injecting `mock_graph_client` into `mock_cli_infrastructure`) because the CLI tests need the patches applied at module level, not the same instance.

#### Patterns Discovered
- **Pytest fixture override**: Local conftest.py fixtures override higher-level conftest.py fixtures of the same name - used this for backward compatibility
- **AsyncMock vs MagicMock for services**: Service-level tests (UserService, NumberService) inject mocks directly and configure methods like `get_paginated` - they don't need async context manager support. CLI-level tests need the context manager protocol.

#### Open Items for Next Agent
- [ ] Consider adding `mock_user_service` fixture following the same pattern as `mock_number_service`
- [ ] Consider adding `mock_cli_infrastructure_users`, `mock_cli_infrastructure_policies` variants for other CLI modules (currently only `numbers` module is supported)
- [ ] Pre-existing mypy errors in `tests/conftest.py` lines 21, 31, 86 (unrelated to this task)

#### Gotchas and Warnings
- **Fixture scoping matters**: Tests in `tests/unit/` get the MagicMock version of `mock_graph_client` from `tests/unit/conftest.py`. Tests at root level or in other directories get the AsyncMock version from `tests/conftest.py`.
- **Patch path specificity**: The `mock_cli_infrastructure` and `mock_number_service` fixtures patch at `teams_phone.cli.numbers.*` - other CLI modules need their own fixtures or the patches need to be parameterized.

---
