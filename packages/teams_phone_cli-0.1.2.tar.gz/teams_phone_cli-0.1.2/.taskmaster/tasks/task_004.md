# Task ID: 4

**Title:** Write unit tests for factory functions

**Status:** pending

**Dependencies:** 2

**Priority:** high

**Description:** Create comprehensive tests for the factory functions to ensure they return valid models and support overrides.

**Details:**

Create tests/unit/test_factories.py:

```python
"""Unit tests for test factory functions."""

import pytest
from datetime import datetime, timezone

from tests.fixtures import (
    make_user,
    make_number,
    make_policy,
    make_location,
    make_operation,
)
from teams_phone.models import (
    AccountType,
    ActivationState,
    AssignmentStatus,
    AsyncOperation,
    EmergencyLocation,
    NumberAssignment,
    NumberType,
    OperationStatus,
    Policy,
    UserConfiguration,
)

class TestMakeUser:
    """Tests for make_user factory."""
    
    @pytest.mark.unit
    def test_returns_user_configuration(self) -> None:
        """make_user returns UserConfiguration instance."""
        user = make_user()
        assert isinstance(user, UserConfiguration)
    
    @pytest.mark.unit
    def test_has_sensible_defaults(self) -> None:
        """make_user provides sensible default values."""
        user = make_user()
        assert user.id == "user-123"
        assert user.display_name == "Test User"
        assert user.account_type == AccountType.USER
    
    @pytest.mark.unit
    def test_accepts_overrides(self) -> None:
        """make_user accepts keyword overrides."""
        user = make_user(displayName="Alice", id="alice-id")
        assert user.display_name == "Alice"
        assert user.id == "alice-id"

class TestMakeNumber:
    """Tests for make_number factory."""
    
    @pytest.mark.unit
    def test_returns_number_assignment(self) -> None:
        """make_number returns NumberAssignment instance."""
        number = make_number()
        assert isinstance(number, NumberAssignment)
    
    @pytest.mark.unit
    def test_accepts_enum_overrides(self) -> None:
        """make_number accepts enum value overrides."""
        number = make_number(
            numberType=NumberType.CALLING_PLAN.value,
            assignmentStatus=AssignmentStatus.USER_ASSIGNED.value
        )
        assert number.number_type == NumberType.CALLING_PLAN
        assert number.assignment_status == AssignmentStatus.USER_ASSIGNED

class TestMakePolicy:
    """Tests for make_policy factory."""
    
    @pytest.mark.unit
    def test_returns_policy(self) -> None:
        """make_policy returns Policy instance."""
        policy = make_policy()
        assert isinstance(policy, Policy)

class TestMakeLocation:
    """Tests for make_location factory."""
    
    @pytest.mark.unit
    def test_returns_emergency_location(self) -> None:
        """make_location returns EmergencyLocation instance."""
        location = make_location()
        assert isinstance(location, EmergencyLocation)

class TestMakeOperation:
    """Tests for make_operation factory."""
    
    @pytest.mark.unit
    def test_returns_async_operation(self) -> None:
        """make_operation returns AsyncOperation instance."""
        operation = make_operation()
        assert isinstance(operation, AsyncOperation)
    
    @pytest.mark.unit
    def test_accepts_status_override(self) -> None:
        """make_operation accepts status override."""
        operation = make_operation(status=OperationStatus.FAILED.value)
        assert operation.status == OperationStatus.FAILED
```

**Test Strategy:**

Run `uv run pytest tests/unit/test_factories.py -v`. All tests should pass. Verify coverage with `uv run pytest tests/unit/test_factories.py --cov=tests/fixtures`.

---

## Implementation Notes

### Session: 2026-02-02 17:35 - Agent: claude-opus-4-5-20251101

**Status:** Verified Complete

#### What Was Done
- Verified test file `tests/unit/test_factories.py` exists with 43 comprehensive tests
- Confirmed all 43 tests pass: `uv run pytest tests/unit/test_factories.py -v` (0.15s)
- Verified no mypy type errors in test and factory files
- Verified no ruff lint errors in test and factory files

#### Test Coverage Summary
| Test Class | Tests | Coverage |
|------------|-------|----------|
| `TestMakeUser` | 9 | Return type, defaults, overrides, enum (enum+string), lists, None, kwargs, validation |
| `TestMakeNumber` | 10 | Return type, defaults, overrides, all 3 enums, capabilities list, None, kwargs, validation |
| `TestMakePolicy` | 5 | Return type, defaults, overrides, None, kwargs |
| `TestMakeLocation` | 5 | Return type, defaults, overrides, None, kwargs |
| `TestMakeOperation` | 10 | Return type, defaults, all status values (running/not_started/failed), datetime, id, numbers list, kwargs, validation |
| `TestFactoryIntegration` | 4 | User with phone numbers, user with policy assignments, number with location, ID consistency |

#### Acceptance Criteria Verification
- [x] Test file `tests/unit/test_factories.py` exists
- [x] Tests verify each factory returns correct Pydantic model type (5 tests, one per factory)
- [x] Tests verify sensible default values (5 tests with comprehensive assertions)
- [x] Tests verify keyword argument overrides work correctly (multiple tests per factory)
- [x] Tests verify enum handling - both enum instances and string values (e.g., `TestMakeUser::test_override_account_type_with_enum` and `test_override_account_type_with_string`)
- [x] Tests verify ValidationError on invalid inputs (3 tests: user, number, operation)
- [x] All tests pass: `uv run pytest tests/unit/test_factories.py -v` ✓

#### Key Implementation Patterns
- Type ignore comments: `type: ignore[arg-type]` for kwargs overrides to satisfy mypy
- Enum string testing: Use kwargs with camelCase keys (e.g., `**{"accountType": "resourceAccount"}`)
- All test methods have `-> None` return type annotation
- All test methods marked with `@pytest.mark.unit`

#### Notes for Future Agents
- Task was already implemented in a previous session (likely Task 2 implementation session)
- The original task description had simpler test examples; actual implementation exceeded requirements
- Factory integration tests demonstrate how factories work together for complex test scenarios

---
