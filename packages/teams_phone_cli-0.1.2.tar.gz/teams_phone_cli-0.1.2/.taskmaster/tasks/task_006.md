# Task ID: 6

**Title:** Split test_cli_numbers.py into list command tests

**Status:** pending

**Dependencies:** 3, 4

**Priority:** high

**Description:** Extract TestNumbersListCommand class from test_cli_numbers.py into a new test_cli_numbers_list.py file, migrating to shared fixtures.

**Details:**

Create tests/unit/test_cli_numbers_list.py containing the TestNumbersListCommand class (~260 lines from original file).

Steps:
1. Copy TestNumbersListCommand class (lines 61-322) to new file
2. Update imports to use shared fixtures:
   - Import make_number from tests.fixtures
   - Remove local _make_number function
3. Update tests to use mock_number_service fixture where applicable
4. Ensure CliRunner import from tests.conftest

```python
# tests/unit/test_cli_numbers_list.py
"""Unit tests for CLI numbers list command."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from tests.conftest import CliRunner
from tests.fixtures import make_number

from teams_phone.cli.main import app
from teams_phone.models import AssignmentStatus, NumberType

if TYPE_CHECKING:
    pass

runner = CliRunner()

class TestNumbersListCommand:
    """Tests for numbers list command."""

    @pytest.mark.unit
    def test_list_shows_in_help(self) -> None:
        """list command appears in numbers help."""
        result = runner.invoke(app, ["numbers", "--help"])
        assert result.exit_code == 0
        assert "list" in result.stdout

    @pytest.mark.unit
    def test_list_empty(self, mock_number_service: dict) -> None:
        """list shows empty message when no numbers found."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])
        
        result = runner.invoke(app, ["numbers", "list"])
        assert result.exit_code == 0
        assert "No numbers found" in result.stdout

    # ... migrate remaining tests, updating to use fixtures
```

Key migration pattern for each test:
- Replace 4-line mock setup block with fixture parameter
- Replace _make_number() calls with make_number() from fixtures
- Simplify mock configuration using fixture dict access

**Test Strategy:**

Run `uv run pytest tests/unit/test_cli_numbers_list.py -v` to verify all migrated tests pass. Compare test count with original to ensure no tests lost. Run `wc -l` to verify file is under 1000 lines.

---

## Implementation Notes

### Session: 2026-02-02 17:20 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Created `tests/unit/test_cli_numbers_list.py` (155 lines) with 12 migrated tests
- Migrated all 12 tests from `TestNumbersListCommand` to use shared fixtures:
  - `mock_number_service` fixture for 10 tests that need mocking
  - `make_number` factory for tests that create number data
  - 2 tests (`test_list_shows_in_help`, `test_list_limit_and_all_mutually_exclusive`) kept without fixtures as they don't require mocks
- Removed `TestNumbersListCommand` class (262 lines) from `tests/unit/test_cli_numbers.py`
- Original file reduced from 3501 to 3239 lines

#### Key Decisions Made
- **Kept `_make_number` in original file**: Although the recon suggested removing it, it's still used by 25+ other tests in the original file. Removing it would break other test classes.
- **Explicit return type annotation on fixture parameter**: Used `dict[str, Any]` instead of just `dict` for type safety
- **No fixture for validation tests**: `test_list_shows_in_help` and `test_list_limit_and_all_mutually_exclusive` don't need mocks since they test CLI help output and validation before any service calls

#### Patterns Discovered
- The `mock_number_service` fixture provides pre-configured `AsyncMock` methods with empty returns by default, so tests only need to override specific methods they're testing
- Tests that verify filter arguments pass `call_args[1]` for keyword arguments

#### Open Items for Next Agent
- [ ] Future tasks (7-9) will continue migrating other command tests, eventually allowing `_make_number` to be removed from original file

#### Gotchas and Warnings
- The `mock_number_service` fixture already sets `list_numbers` to return `[]` by default (conftest.py:204), so setting it explicitly in tests is only needed for documentation clarity
- Pre-existing mypy errors in `tests/conftest.py` (lines 21, 31, 86) are unrelated to this task

---
