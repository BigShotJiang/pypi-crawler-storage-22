# Task ID: 7

**Title:** Split test_cli_numbers.py into show command tests

**Status:** pending

**Dependencies:** 3, 4

**Priority:** high

**Description:** Extract TestNumbersShowCommand and TestNumbersSearchCommand classes into test_cli_numbers_show.py.

**Details:**

Create tests/unit/test_cli_numbers_show.py containing:
- TestNumbersShowCommand class (lines 323-486)
- TestNumbersSearchCommand class (lines 487-632)

Both classes focus on read-only number lookup operations.

```python
# tests/unit/test_cli_numbers_show.py
"""Unit tests for CLI numbers show and search commands."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from tests.conftest import CliRunner
from tests.fixtures import make_number

from teams_phone.cli.main import app
from teams_phone.exceptions import NotFoundError
from teams_phone.models import NumberType

runner = CliRunner()

class TestNumbersShowCommand:
    """Tests for numbers show command."""
    # Migrate tests from original file
    pass

class TestNumbersSearchCommand:
    """Tests for numbers search command."""
    # Migrate tests from original file
    pass
```

Migration steps:
1. Copy both test classes to new file
2. Replace local _make_number with imported make_number
3. Update mock patterns to use shared fixtures where beneficial
4. Add proper type hints and imports

**Test Strategy:**

Run `uv run pytest tests/unit/test_cli_numbers_show.py -v`. Verify test count matches original classes. Check file is under 1000 lines with `wc -l`.

---

## Implementation Notes

### Session: 2026-02-02 18:35 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Created `tests/unit/test_cli_numbers_show.py` containing:
  - `TestNumbersShowCommand` class (7 tests)
  - `TestNumbersSearchCommand` class (7 tests)
- Replaced all `_make_number()` calls with `make_number()` from `tests.fixtures`
- Removed `TestNumbersShowCommand` and `TestNumbersSearchCommand` from `tests/unit/test_cli_numbers.py`
- All 14 tests pass in the new file
- All 66 remaining tests pass in the original file

#### Key Decisions Made
- **Kept inline patches (Option 1 from recon)**: Followed recon recommendation to keep inline `with patch(...)` blocks rather than refactoring to use `mock_number_service` fixture. This minimizes risk and matches the task description exactly. Fixture refactoring can be a follow-up task.
- **Parameter mapping**: The `make_number()` factory uses the same parameter names as `_make_number()` (telephone_number, city, assignment_status, etc.), so replacement was straightforward with no parameter renaming needed.

#### Patterns Discovered
- Factory import pattern established: `from tests.fixtures import make_number` (consistent with `test_cli_numbers_list.py:11`)
- The show/search tests use `get_number` and `search_numbers` methods which are already pre-configured in `mock_number_service` fixture (see `tests/conftest.py:203-208`)

#### Open Items for Next Agent
- [ ] Consider refactoring show/search tests to use `mock_number_service` fixture (follow-up task)
- [ ] The `_make_number()` local function remains in `test_cli_numbers.py` for use by remaining test classes (assign, unassign, update, bulk commands)

#### Gotchas and Warnings
- The mypy errors in `tests/conftest.py` are pre-existing and unrelated to this task (library stubs issues)
- New file line count: 330 lines (meets target of ~350, well under 1000 limit)
- Original file reduced from 3239 to 2929 lines (removed 310 lines)

---
