# Task ID: 8

**Title:** Split test_cli_numbers.py into assign command tests

**Status:** pending

**Dependencies:** 3, 4

**Priority:** high

**Description:** Extract TestNumbersAssignCommand and TestNumbersUnassignCommand classes into test_cli_numbers_assign.py.

**Details:**

Create tests/unit/test_cli_numbers_assign.py containing:
- TestNumbersAssignCommand class (lines 711-1178, ~468 lines)
- TestNumbersUnassignCommand class (lines 1179-1541, ~363 lines)
- TestNumbersUpdateCommand class (lines 1542-1937, ~396 lines)
- TestProgressDisplay class (lines 1938-2172, ~235 lines)

These classes test number assignment lifecycle operations.

```python
# tests/unit/test_cli_numbers_assign.py
"""Unit tests for CLI numbers assign, unassign, and update commands."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from tests.conftest import CliRunner
from tests.fixtures import make_number, make_user, make_location, make_operation

from teams_phone.cli.main import app
from teams_phone.models import OperationStatus, NumberType

if TYPE_CHECKING:
    pass

runner = CliRunner()

class TestNumbersAssignCommand:
    """Tests for numbers assign command."""
    # Migrate from original, using make_user, make_location, make_operation
    pass

class TestNumbersUnassignCommand:
    """Tests for numbers unassign command."""
    pass

class TestNumbersUpdateCommand:
    """Tests for numbers update command."""
    pass

class TestProgressDisplay:
    """Tests for progress display during async operations."""
    pass
```

Key migrations:
- Replace local _make_user, _make_location, _make_operation with imported factories
- Remove duplicated factory function definitions
- Update to use mock_cli_infrastructure fixture for complex mock setups

**Test Strategy:**

Run `uv run pytest tests/unit/test_cli_numbers_assign.py -v`. Compare test counts. This file may approach 1000 lines; if over, consider further splitting by command.
