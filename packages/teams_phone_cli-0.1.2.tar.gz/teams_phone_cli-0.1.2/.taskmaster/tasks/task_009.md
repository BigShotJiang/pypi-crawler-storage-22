# Task ID: 9

**Title:** Split test_cli_numbers.py into bulk operation tests

**Status:** pending

**Dependencies:** 3, 4

**Priority:** high

**Description:** Extract TestNumbersBulkAssignCommand class into test_cli_numbers_bulk.py.

**Details:**

Create tests/unit/test_cli_numbers_bulk.py containing:
- TestNumbersBulkAssignCommand class (lines 2173-3501, ~1329 lines)
- TestNumbersCommandIntegration class (lines 633-658, ~26 lines)

Bulk operations have complex mock setups that benefit most from shared fixtures.

```python
# tests/unit/test_cli_numbers_bulk.py
"""Unit tests for CLI numbers bulk operations."""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from tests.conftest import CliRunner
from tests.fixtures import make_number, make_user, make_location, make_operation

from teams_phone.cli.main import app
from teams_phone.models import NumberType, OperationStatus

if TYPE_CHECKING:
    pass

runner = CliRunner()

class TestNumbersCommandIntegration:
    """Integration tests for numbers command group."""
    pass

class TestNumbersBulkAssignCommand:
    """Tests for numbers bulk-assign command."""
    # Migrate bulk operation tests
    # These have the most repetitive mock setup patterns
    pass
```

This file may still be large (~1300 lines). If needed, further split by:
- test_cli_numbers_bulk_validation.py (validation tests)
- test_cli_numbers_bulk_execution.py (execution tests)
- test_cli_numbers_bulk_output.py (output format tests)

**Test Strategy:**

Run `uv run pytest tests/unit/test_cli_numbers_bulk.py -v`. If file exceeds 1000 lines, create subtask to split further. Verify no tests lost from original file.

---

## Subtask 9.1 Implementation Notes

### Session: 2026-02-02 20:05 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Created `tests/unit/test_cli_numbers_bulk_validation.py` (436 lines)
- Extracted `TestNumbersCommandIntegration` class (3 tests) from `test_cli_numbers.py` lines 22-47
- Created `TestNumbersBulkValidation` class with 10 tests:
  - `test_bulk_assign_shows_in_help` (line 53)
  - `test_bulk_assign_requires_csv_file_argument` (line 60)
  - `test_bulk_assign_file_not_found` (line 72)
  - `test_bulk_assign_dry_run_valid_csv` (line 83)
  - `test_bulk_assign_dry_run_with_errors` (line 144)
  - `test_bulk_assign_json_dry_run` (line 193)
  - `test_bulk_assign_validation_error_without_continue` (line 247)
  - `test_bulk_assign_empty_csv_no_rows` (line 298)
  - `test_bulk_assign_default_location_applied` (line 317)
  - `test_bulk_assign_default_location_from_tenant_profile` (line 984)
- Total: 13 tests, all passing

#### Key Decisions Made
- Renamed class to `TestNumbersBulkValidation` to match the validation/dry-run focus
- Kept inline `with patch(...)` blocks as per existing pattern (no refactoring to fixtures)
- Did NOT remove tests from original file - deferred to subtask 9.3

#### Patterns Discovered
- `test_bulk_assign_default_location_from_tenant_profile` test (line 984) patches `teams_phone.infrastructure.ConfigManager` directly, not via `teams_phone.cli.numbers.ConfigManager`

#### Open Items for Next Agent
- [ ] Subtask 9.2: Extract execution tests (~500 lines)
- [ ] Subtask 9.3: Extract output tests and remove duplicates from original file

#### Gotchas and Warnings
- Pre-existing mypy errors in `tests/conftest.py` (unrelated to this task)
- The tenant profile test imports ConfigManager from a different path than other tests

---

## Subtask 9.2 Implementation Notes

### Session: 2026-02-02 20:35 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Created `tests/unit/test_cli_numbers_bulk_execution.py` (630 lines)
- Created `TestNumbersBulkExecution` class with 8 tests:
  - `test_bulk_assign_confirmation_cancelled` (lines 371-418 from original)
  - `test_bulk_assign_yes_skips_confirmation` (lines 420-494)
  - `test_bulk_assign_continue_on_error_proceeds` (lines 497-592)
  - `test_bulk_assign_execution_success_increments_counter` (lines 595-672)
  - `test_bulk_assign_execution_failure_increments_counter` (lines 675-750)
  - `test_bulk_assign_execution_exception_increments_fail_counter` (lines 753-809)
  - `test_bulk_assign_skips_rows_with_validation_errors` (lines 888-981)
  - `test_bulk_assign_stops_on_first_error_without_continue` (lines 1054-1122)
- Total: 8 tests, all passing

#### Key Decisions Made
- File is 630 lines (above 500 estimate but under 1000 line PRD goal) - acceptable
- Added `NotFoundError` import for exception tests (as recon noted)
- Kept inline `with patch(...)` blocks consistent with validation file pattern
- Added `write_results_csv` mock to all execution tests (except confirmation_cancelled which doesn't reach execution)
- Did NOT remove tests from original file - deferred to subtask 9.3

#### Patterns Discovered
- Execution tests require 8 patches vs 7 for validation (adds `write_results_csv`)
- Service mocks are accessed via `mock_bulk.user_service`, `mock_bulk.number_service`, etc.
- Tests follow confirmation -> execution -> error handling logical flow

#### Open Items for Next Agent
- [ ] Subtask 9.3: Extract output tests (~400 lines) and remove all duplicates from original file

#### Gotchas and Warnings
- Pre-existing mypy errors in `tests/conftest.py` continue (unrelated to this task)
- Line count is higher than recon estimate due to verbose mock setup in each test

---

## Subtask 9.3 Implementation Notes

### Session: 2026-02-02 18:30 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Created `tests/unit/test_cli_numbers_bulk_output.py` (353 lines)
- Created `TestNumbersBulkOutput` class with 4 tests:
  - `test_bulk_assign_json_mode_suppresses_progress` (lines 812-886 from original)
  - `test_bulk_assign_writes_results_file` (lines 1125-1210)
  - `test_bulk_assign_json_output_includes_results` (lines 1213-1293)
  - `test_bulk_assign_generates_timestamp_filename` (lines 1296-1378)
- Deleted `tests/unit/test_cli_numbers.py` (all 1377 lines migrated to 3 new files)
- Total: 4 tests, all passing
- Combined bulk tests: 25 tests total (13 validation + 8 execution + 4 output)

#### Key Decisions Made
- Added `import json` for JSON output parsing (not needed in validation/execution files)
- Used same patch setup pattern (8 patches) consistent with execution tests
- Added datetime mock for timestamp filename test (`teams_phone.cli.numbers.datetime`)
- Deleted original file entirely - all tests confirmed migrated to new split files

#### Final Test File Summary
| File | Lines | Tests | Focus |
|------|-------|-------|-------|
| `test_cli_numbers_bulk_validation.py` | 436 | 13 | Validation, dry-run, error detection |
| `test_cli_numbers_bulk_execution.py` | 630 | 8 | Confirmation, execution flow, error handling |
| `test_cli_numbers_bulk_output.py` | 353 | 4 | JSON output, file writing, timestamps |
| **Total** | **1419** | **25** | Complete bulk test coverage |

#### Patterns Discovered
- Output tests use `json.loads(result.stdout)` for JSON output verification
- `mock_write.call_args[0][1]` gets the output path from `write_results_csv` mock
- datetime mock requires patching `teams_phone.cli.numbers.datetime.now`

#### Verification Completed
- All 25 bulk tests pass: `uv run pytest tests/unit/test_cli_numbers_bulk_*.py -v`
- ruff check passes
- mypy errors are pre-existing in `tests/conftest.py` (unrelated)

#### Open Items for Next Agent
- None - Task 9 (split test_cli_numbers.py) is complete

#### Gotchas and Warnings
- Pre-existing mypy errors in `tests/conftest.py` continue (unrelated to this task)
- Parent task 9 can now be marked done since all 3 subtasks complete
