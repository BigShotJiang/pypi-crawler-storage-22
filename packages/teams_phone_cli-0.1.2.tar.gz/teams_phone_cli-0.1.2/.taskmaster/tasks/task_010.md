# Task ID: 10

**Title:** Delete original test_cli_numbers.py after verification

**Status:** pending

**Dependencies:** 6, 7, 8, 9

**Priority:** high

**Description:** Remove the original test_cli_numbers.py after verifying all tests have been successfully migrated to split files.

**Details:**

Final cleanup step after all number command tests are split:

1. Count total tests in original file:
   ```bash
   grep -c "def test_" tests/unit/test_cli_numbers.py
   ```

2. Count total tests in new files:
   ```bash
   grep -c "def test_" tests/unit/test_cli_numbers_list.py tests/unit/test_cli_numbers_show.py tests/unit/test_cli_numbers_assign.py tests/unit/test_cli_numbers_bulk.py
   ```

3. Verify counts match

4. Run full test suite to ensure no regressions:
   ```bash
   uv run pytest tests/unit/ -m unit -v
   ```

5. Check coverage hasn't decreased:
   ```bash
   uv run pytest tests/unit/ --cov=teams_phone --cov-report=term-missing
   ```

6. Delete original file:
   ```bash
   rm tests/unit/test_cli_numbers.py
   ```

7. Run tests again to confirm all pass without original file

**Test Strategy:**

Run complete test suite `uv run pytest tests/ -m unit` before and after deletion. Coverage must not decrease. All tests must pass.

---

## Implementation Notes

### Session: 2026-02-02 21:35 - Agent: claude-opus-4-5-20251101

**Status:** Implemented (Verification Only)

#### What Was Done

This task was a **verification task** - the original `test_cli_numbers.py` file was already deleted in Task 9.3.

Verified:
1. **Original file deleted** - `tests/unit/test_cli_numbers.py` does not exist (confirmed via glob search)
2. **Test count verified** - 92 tests across 6 split files:
   - `test_cli_numbers_list.py`: 12 tests
   - `test_cli_numbers_show.py`: 14 tests
   - `test_cli_numbers_assign.py`: 41 tests
   - `test_cli_numbers_bulk_validation.py`: 13 tests
   - `test_cli_numbers_bulk_execution.py`: 8 tests
   - `test_cli_numbers_bulk_output.py`: 4 tests
3. **Full test suite passes** - 1182 unit tests passed in 23.70s
4. **Coverage maintained** - 94% coverage for `teams_phone` module
5. **Lint checks pass** - All split test files pass `ruff check`

#### Key Decisions Made
- No code changes needed - this was purely a verification task
- Task 9.3 had already completed the file deletion as part of the bulk output tests extraction

#### Patterns Discovered
- Test file splitting completed across Tasks 6-9 followed consistent patterns
- The bulk tests were further split into 3 files (validation, execution, output) for maintainability

#### Open Items for Next Agent
- None - test migration and cleanup is complete

#### Gotchas and Warnings
- Pre-existing mypy errors in `tests/conftest.py` are unrelated to this task (type signature issues with CliRunner wrapper)
- The task description mentioned 4 split files, but the actual implementation created 6 files (bulk was split into 3)

---
