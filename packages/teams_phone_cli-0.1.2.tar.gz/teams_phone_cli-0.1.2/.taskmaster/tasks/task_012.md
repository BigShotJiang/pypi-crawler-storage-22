# Task ID: 12

**Title:** Split test_number_service.py by operation type

**Status:** pending

**Dependencies:** 4

**Priority:** medium

**Description:** Split the 2289-line test_number_service.py into focused test files by operation category.

**Details:**

Analyze test_number_service.py and split by operation type:

1. test_number_service_list.py - Tests for list_numbers, get_numbers_paginated
2. test_number_service_get.py - Tests for get_number, search operations
3. test_number_service_assign.py - Tests for assign_number, poll_assignment
4. test_number_service_unassign.py - Tests for unassign_number operations
5. test_number_service_update.py - Tests for update_number, update location

Use shared fixtures for GraphClient mocking:

```python
# tests/unit/test_number_service_assign.py
"""Unit tests for NumberService assignment operations."""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, MagicMock

from tests.fixtures import make_number, make_operation, make_user
from teams_phone.services.number_service import NumberService
from teams_phone.models import OperationStatus, NumberType

class TestAssignNumber:
    """Tests for NumberService.assign_number method."""
    
    @pytest.fixture
    def number_service(self, mock_graph_client: AsyncMock) -> NumberService:
        """Create NumberService with mocked GraphClient."""
        return NumberService(mock_graph_client)
    
    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_assign_success(self, number_service: NumberService) -> None:
        # ...
```

This allows reusing mock_graph_client from conftest.py while keeping service-specific fixtures local.

**Test Strategy:**

Run `uv run pytest tests/unit/test_number_service_*.py -v`. Verify test count matches original 2289-line file. Each file under 800 lines.

---

## Subtask 12.1 Implementation Notes

### Session: 2026-02-02 17:15 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Created `tests/unit/test_number_service_read.py` containing read operation tests
- Extracted helper function `make_number_dict()` (not `make_operation_dict` which is used by other test classes)
- Extracted test classes:
  - `TestNumberServiceInit` (1 test)
  - `TestNumberServiceListNumbers` (13 tests)
  - `TestNumberServiceGetNumber` (8 tests)
  - `TestNumberServiceSearchNumbers` (13 tests)
- Total: 33 tests passing

#### Key Decisions Made
- **Test count correction**: Task specified 36 tests (1+13+9+13) but actual count is 33 (1+13+8+13). The original file has 8 tests in `TestNumberServiceGetNumber`, not 9.
- **Helper functions**: Only copied `make_number_dict()` - the `make_operation_dict()` helper is needed by poll/assign tests which go in subsequent split files (12.2, 12.3).
- **File size**: New file is ~800 lines as expected, focused solely on read operations.

#### Patterns Discovered
- Async generator mock pattern: Use `return; yield` idiom for empty async generators (see `test_number_service_read.py:76-78`)
- Param capture pattern: Use `captured_params` dict in mock functions to verify query params (see `test_number_service_read.py:138-145`)
- The `mock_graph_client` fixture from `tests/conftest.py:113-136` is used throughout

#### Open Items for Next Agent
- [ ] Subtask 12.2: Create `test_number_service_assign.py` with assign/poll/extract tests
- [ ] Subtask 12.3: Create `test_number_service_modify.py` with unassign/update tests
- [ ] After all subtasks complete: Remove extracted classes from original `test_number_service.py`

#### Gotchas and Warnings
- The `make_operation_dict()` helper function is NOT needed in this file - it's used by poll_operation, assign, and unassign tests which are in subsequent split files
- mypy shows import-untyped errors for teams_phone modules - this is a pre-existing project issue, not introduced by this task

---

## Subtask 12.2 Implementation Notes

### Session: 2026-02-02 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Created `tests/unit/test_number_service_assign.py` containing assignment operation tests
- Extracted helper function `make_operation_dict()` (needed for poll/assign tests)
- Extracted test classes:
  - `TestNumberServicePollOperation` (9 tests) - poll_operation method tests
  - `TestNumberServiceExtractOperationId` (12 tests) - _extract_operation_id method tests
  - `TestNumberServiceAssignNumber` (13 tests) - assign_number method tests
- Total: 34 tests passing

#### Key Decisions Made
- **Test count correction**: Task specified 35 tests (8+10+17) but actual count is 34 (9+12+13). The original estimate was approximate.
- **Helper functions**: Only copied `make_operation_dict()` - no need for `make_number_dict()` in this file as assign tests don't use it.
- **Import consolidation**: Used unified import at top level (`from unittest.mock import AsyncMock, MagicMock, patch`) instead of per-test imports for cleaner code.
- **File size**: New file is ~650 lines, well under the 800 line target.

#### Patterns Discovered
- Mock response pattern for assign/unassign: Use `SyncMock()` for response object with `headers` dict (see `test_number_service_assign.py:341-346`)
- Time mocking pattern for timeout tests: Use `nonlocal call_count` to track time progression (see `test_number_service_assign.py:147-162`)
- Progress callback testing: Use `SyncMock()` for callback, check `call_args_list` for invocation details

#### Open Items for Next Agent
- [ ] Subtask 12.3: Create `test_number_service_modify.py` with unassign/update tests
- [ ] After all subtasks complete: Remove extracted classes from original `test_number_service.py`

#### Gotchas and Warnings
- The `make_number_dict()` helper function is NOT needed in this file - assign tests only use `make_operation_dict()`
- All tests in original `test_number_service.py` still pass (89 tests) - no accidental breakage
- mypy shows import-untyped errors for teams_phone modules - this is a pre-existing project issue

---

## Subtask 12.3 Implementation Notes

### Session: 2026-02-02 19:20 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Created `tests/unit/test_number_service_modify.py` containing modification operation tests
- Extracted helper function `make_operation_dict()` (needed for unassign tests with polling)
- Extracted test classes:
  - `TestNumberServiceUnassignNumber` (11 tests) - unassign_number method tests
  - `TestNumberServiceUpdateNumber` (11 tests) - update_number method tests
- Total: 22 tests passing
- Deleted original `tests/unit/test_number_service.py` after verification
- Final verification: 89 tests pass across all 3 split files (matching original count)

#### Key Decisions Made
- **Test count**: Task estimated 21 tests (11+10) but actual count is 22 (11+11). Minor difference from estimate.
- **Helper functions**: Only copied `make_operation_dict()` - unassign uses polling like assign, but update_number doesn't poll (synchronous operation).
- **Import consolidation**: Used unified imports at top level, matching pattern from `test_number_service_assign.py`.
- **File size**: New file is ~550 lines, well under the 800 line target.

#### Final Split Summary
| File | Tests | Lines | Operations |
|------|-------|-------|------------|
| `test_number_service_read.py` | 33 | ~800 | init, list, get, search |
| `test_number_service_assign.py` | 34 | ~650 | poll, extract_id, assign |
| `test_number_service_modify.py` | 22 | ~550 | unassign, update |
| **Total** | **89** | **~2000** | All operations |

#### Patterns Discovered
- Update operations don't require polling - they're synchronous (no `wait` parameter)
- Unassign uses same async polling pattern as assign
- Validation tests (mutual exclusivity checks) don't need mock responses - they fail before API call

#### Open Items for Next Agent
- (None - task complete)

#### Gotchas and Warnings
- The original file is now deleted - all tests are in split files
- mypy `import-untyped` errors are pre-existing project issue, not regressions
- The task description suggested 5 files but actual implementation used 3 (read, assign, modify) which covers all operations more cohesively

---
