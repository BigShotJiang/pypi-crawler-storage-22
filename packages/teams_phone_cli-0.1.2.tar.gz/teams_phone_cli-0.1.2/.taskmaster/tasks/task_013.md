# Task ID: 13

**Title:** Migrate remaining test files to use shared fixtures

**Status:** done

**Dependencies:** 2, 3

**Priority:** medium

**Description:** Update test_cli_users.py, test_cli_policies.py, test_cli_locations.py, and other CLI test files to use shared fixtures and factories.

**Details:**

Update existing CLI test files to use shared infrastructure:

1. test_cli_users.py:
   - Replace local _make_user with `from tests.fixtures import make_user`
   - Update mock patterns to use mock_cli_infrastructure where beneficial

2. test_cli_policies.py:
   - Replace _make_policy, _make_assignment, _make_user with imports
   - Simplify repetitive mock setup

3. test_cli_locations.py:
   - Replace _make_location with import

4. test_cli_tenants.py:
   - Keep _make_tenant local (tenant model not in factories)
   - Or add make_tenant to factories.py

For each file:
```python
# Before
def _make_user(...) -> UserConfiguration:
    # 20 lines of factory code

def test_something():
    user = _make_user()

# After
from tests.fixtures import make_user

def test_something():
    user = make_user()
```

This migration should reduce each file by 20-50 lines while improving consistency.

**Test Strategy:**

Run `uv run pytest tests/unit/test_cli_*.py -v` after each file update. No test failures. Run `grep -c "def _make_" tests/unit/test_cli_*.py` to verify local factories eliminated.

---

## Implementation Notes

### Session: 2026-02-02 12:30 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Migrated test_cli_locations.py: Removed local `_make_location` factory (~28 lines), replaced with `from tests.fixtures import make_location`
- Migrated test_cli_users.py: Removed local `_make_user` factory (~39 lines), replaced with `from tests.fixtures import make_user`
- Migrated test_cli_policies.py: Removed local `_make_policy` and `_make_user` factories (~33 lines), kept `_make_assignment` (no shared factory for EffectivePolicyAssignment)

#### Key Decisions Made
1. **Kept `_make_assignment` local in test_cli_policies.py**: There is no shared factory for EffectivePolicyAssignment. This is noted for potential future addition to factories.py.
2. **Updated tests with explicit field values**: When the shared factory has different defaults than the local factory, tests that verify specific values were updated to pass those values explicitly (e.g., `make_location(description="Seattle HQ")` instead of relying on defaults).
3. **Parameter name mappings applied**:
   - `upn` → `user_principal_name`
   - `user_id` → `id`
   - `phone_number` → `telephone_numbers` (list of dicts with "telephoneNumber" and "assignmentCategory")

#### Patterns Discovered
- Shared factory `make_user` requires `is_enterprise_voice_enabled=True` to match old local factory behavior - many tests depend on this
- Telephone numbers must be passed as list of dicts, not a single string: `telephone_numbers=[{"telephoneNumber": "+14255551234", "assignmentCategory": "primary"}]`
- When replacing factory calls with parameters, use Edit tool with `replace_all=true` for batch replacements of identical patterns

#### Open Items for Next Agent
- [ ] Consider adding `make_assignment` to factories.py for EffectivePolicyAssignment (currently only used in test_cli_policies.py)
- [ ] Consider adding `make_tenant` to factories.py for TenantProfile (currently kept local in test_cli_tenants.py)
- [ ] Pre-existing mypy errors in tests/conftest.py are unrelated to this task

#### Gotchas and Warnings
- The shared factories have different default values than the local factories had. Always verify test assertions match the factory output or pass explicit values.
- The `make_user` factory's default `is_enterprise_voice_enabled=False` differs from the old local factory's default of `True` - be explicit when tests need an enterprise voice enabled user.

#### Verification
- All 346 CLI unit tests pass: `uv run pytest tests/unit/test_cli_*.py`
- `grep -c "def _make_" tests/unit/test_cli_*.py` shows only expected local factories remain:
  - test_cli_helpers.py:1 - `_make_mock_context` (not a model factory)
  - test_cli_policies.py:1 - `_make_assignment` (no shared factory yet)
  - test_cli_tenants.py:1 - `_make_tenant` (no shared factory yet)

---
