# Task ID: 14

**Title:** Create cli/helpers.py with shared run_with_service helper

**Status:** pending

**Dependencies:** None

**Priority:** medium

**Description:** Extract the duplicated _run_async pattern from cli/numbers.py, cli/policies.py, and cli/users.py into a shared cli/helpers.py module.

**Details:**

Create src/teams_phone/cli/helpers.py with a generic service runner:

```python
# src/teams_phone/cli/helpers.py
"""Shared helper functions for CLI commands."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any, Callable, TypeVar

import typer

from teams_phone.cli.context import get_context
from teams_phone.infrastructure import CacheManager, GraphClient
from teams_phone.services import AuthService

if TYPE_CHECKING:
    from teams_phone.infrastructure import OutputFormatter

T = TypeVar("T")
ServiceT = TypeVar("ServiceT")

def run_with_service(
    ctx: typer.Context,
    service_factory: Callable[[GraphClient], ServiceT],
    operation: Callable[[ServiceT], Any],
) -> tuple[Any, "OutputFormatter"]:
    """Run an async operation with a service.
    
    Creates the required infrastructure (GraphClient, service) and runs
    the async operation using asyncio.run().
    
    Args:
        ctx: Typer context with CLIContext.
        service_factory: Callable that creates service from GraphClient.
        operation: Async callable that takes service and returns result.
        
    Returns:
        Tuple of (result, OutputFormatter).
        
    Example:
        result, formatter = run_with_service(
            ctx,
            lambda gc: NumberService(gc),
            lambda svc: svc.list_numbers()
        )
    """
    cli_ctx = get_context(ctx)
    formatter = cli_ctx.get_output_formatter()
    config_manager = cli_ctx.get_config_manager()
    cache_manager = CacheManager()
    auth_service = AuthService(config_manager, cache_manager)
    
    async def _execute() -> Any:
        async with GraphClient(auth_service) as graph_client:
            service = service_factory(graph_client)
            return await operation(service)
    
    result = asyncio.run(_execute())
    return result, formatter
```

This generic helper can replace the 3 similar _run_async functions in numbers.py, policies.py, and users.py.

**Test Strategy:**

Create tests/unit/test_cli_helpers.py with unit tests for run_with_service. Run `uv run pytest tests/unit/test_cli_helpers.py -v`. Verify helper handles errors correctly.

---

## Implementation Notes

### Session: 2026-02-02 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Created `src/teams_phone/cli/helpers.py` with the `run_with_service` generic helper function
- Updated `src/teams_phone/cli/__init__.py` to export `run_with_service` from the CLI package
- Created `tests/unit/test_cli_helpers.py` with 8 comprehensive unit tests:
  - `test_returns_result_and_formatter` - verifies basic operation returns tuple
  - `test_creates_graph_client_with_auth_service` - verifies infrastructure instantiation
  - `test_calls_service_factory_with_graph_client` - verifies factory is called correctly
  - `test_calls_operation_with_service` - verifies operation receives the service
  - `test_propagates_teams_phone_error` - verifies TeamsPhoneError propagation
  - `test_closes_graph_client_on_success` - verifies async context manager exit on success
  - `test_closes_graph_client_on_error` - verifies async context manager exit on error
  - `test_works_with_complex_return_types` - verifies handling of complex return values

#### Key Decisions Made
- Used `ServiceT = TypeVar("ServiceT")` for generic service type (matches task spec)
- Removed unused `T = TypeVar("T")` from task spec - not needed
- Used `Callable[[GraphClient], ServiceT]` for service_factory type hint
- Used `Callable[[ServiceT], Any]` for operation type hint (returns coroutine)
- Return type is `tuple[Any, OutputFormatter]` - keeps flexibility for various return types

#### Patterns Discovered
- CLIContext is a dataclass with lazy initialization via `get_output_formatter()` and `get_config_manager()`
- The `output_formatter` and `config_manager` are public fields that can be pre-set for testing
- GraphClient async context manager mocking pattern: `mock_gc.__aenter__.return_value = mock_gc`

#### Open Items for Next Agent
- [ ] Task 15: Migrate numbers.py to use run_with_service
- [ ] Task 16: Migrate users.py to use run_with_service
- [ ] Task 17: Migrate policies.py to use run_with_service (note: policies.py uses two services - PolicyService + UserService - may need special handling)

#### Gotchas and Warnings
- `policies.py:162-192` creates both PolicyService AND UserService - the simple `run_with_service` helper won't directly replace this. May need a multi-service variant or nested calls.
- The task spec included an unused `T = TypeVar("T")` - I removed it since it wasn't used.
- Test context creation requires setting `cli_ctx.config_manager` and `cli_ctx.output_formatter` directly (not private `_config_manager`).

---
