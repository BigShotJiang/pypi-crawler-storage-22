# Task ID: 15

**Title:** Update CLI modules to use shared helpers

**Status:** pending

**Dependencies:** 14

**Priority:** medium

**Description:** Refactor cli/numbers.py, cli/policies.py, and cli/users.py to import and use run_with_service from cli/helpers.py.

**Details:**

Update each CLI module to use the shared helper:

1. cli/numbers.py:
```python
# Before (50 lines of _run_async)
def _run_async(ctx, coro_factory):
    # ... duplicated code

# After
from teams_phone.cli.helpers import run_with_service
from teams_phone.services.number_service import NumberService

# In command:
result, formatter = run_with_service(
    ctx,
    lambda gc: NumberService(gc),
    lambda svc: svc.list_numbers()
)
```

2. cli/policies.py:
```python
from teams_phone.cli.helpers import run_with_service
from teams_phone.services.policy_service import PolicyService
```

3. cli/users.py:
```python
from teams_phone.cli.helpers import run_with_service
from teams_phone.services.user_service import UserService
```

For complex commands needing multiple services (like assign), keep specialized helpers but consider if run_with_multi_service pattern would help.

This should reduce:
- cli/numbers.py by ~30 lines (removing _run_async)
- cli/policies.py by ~30 lines
- cli/users.py by ~30 lines

**Test Strategy:**

Run full CLI test suite `uv run pytest tests/unit/test_cli_*.py -v`. All existing tests must pass. Run `grep -c "def _run_async" src/teams_phone/cli/*.py` to verify duplication eliminated.

---

## Implementation Notes

### Session: 2026-02-02 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Migrated `cli/users.py` to use `run_with_service` from `cli/helpers.py`
  - Removed `_run_async` function (29 lines of boilerplate)
  - Updated imports: removed `asyncio`, `CacheManager`, `GraphClient`, `AuthService`
  - Added import for `run_with_service` from helpers
  - Updated `list_users`, `show_user`, `search_users` commands to use new pattern
- Migrated `cli/numbers.py` to use `run_with_service`
  - Removed basic `_run_async` function (29 lines)
  - Kept specialized multi-service helpers: `_run_assign_async`, `_run_bulk_assign_async`
  - Updated `list_numbers`, `show_number`, `search_numbers`, `unassign_number` (no-wait case), `update_number` commands
- Kept `cli/policies.py` `_run_async` as-is (creates both PolicyService AND UserService - not replaceable with single-service helper)
- Updated test files to patch at `teams_phone.cli.helpers.*` instead of module level for infrastructure:
  - `tests/unit/test_cli_users.py`
  - `tests/unit/test_cli_numbers_show.py`
  - `tests/unit/test_cli_numbers_assign.py`
  - `tests/conftest.py` - `mock_cli_infrastructure` fixture now patches at both helpers and numbers level

#### Key Decisions Made
- **policies.py kept as-is**: The `_run_async` in policies.py creates TWO services (PolicyService + UserService), which the simple `run_with_service` pattern cannot replace. This is correct per the task spec: "For complex commands needing multiple services, keep specialized helpers"
- **Exception handling pattern**: Commands must get formatter BEFORE the try block (using `cli_ctx.get_output_formatter()`) to ensure the `except` block can display errors. The formatter from `run_with_service` is ignored in these cases.
- **Test patching strategy**: Infrastructure classes (CacheManager, AuthService, GraphClient) are now patched at `teams_phone.cli.helpers.*` level for commands using `run_with_service`

#### Patterns Discovered
- `run_with_service` pattern: See `src/teams_phone/cli/helpers.py:21-64`
- Test mock pattern for migrated commands: Patch at `teams_phone.cli.helpers.*` level instead of module level

#### Line Count Reductions
- `users.py`: Net reduction of ~36 lines (59 changes)
- `numbers.py`: Net reduction of ~45 lines (81 changes)
- Total: ~81 lines removed (exceeds target of ~30 lines per module)

#### Verification
- `grep -c "def _run_async" src/teams_phone/cli/*.py`:
  - users.py: 0 (migrated)
  - numbers.py: 0 (migrated, specialized helpers kept)
  - policies.py: 1 (intentionally kept - dual-service)
- 346 CLI tests pass

#### Gotchas and Warnings
- When using `run_with_service`, if the command has an `except TeamsPhoneError` block, the formatter MUST be obtained before the try block. Otherwise, exceptions from `run_with_service` will fail because `formatter` is undefined.
- The `mock_cli_infrastructure` fixture in conftest.py now patches at BOTH helpers level AND numbers level to support both the basic `run_with_service` usage and the specialized multi-service helpers.

---
