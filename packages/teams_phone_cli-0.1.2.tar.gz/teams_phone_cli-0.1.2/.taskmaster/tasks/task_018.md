# Task ID: 18

**Title:** Add isort (I) rules to ruff configuration

**Status:** pending

**Dependencies:** None

**Priority:** medium

**Description:** Enable import sorting rules (I) in ruff to enforce consistent import organization.

**Details:**

Update pyproject.toml:

```toml
[tool.ruff.lint]
select = ["E4", "E7", "E9", "F", "C901", "B", "I"]  # Add I
fixable = ["ALL"]

[tool.ruff.lint.isort]
known-first-party = ["teams_phone"]
force-single-line = false
lines-after-imports = 2
```

Isort rules enforce:
- Standard library imports first
- Third-party imports second
- Local imports third
- Alphabetical sorting within groups
- Consistent blank lines between groups

After enabling:
1. Run `ruff check src/ tests/ --fix` to auto-fix import order
2. Review changes to ensure correct grouping
3. Commit the formatting changes

The `known-first-party` setting ensures `teams_phone` imports are grouped correctly as local imports.

**Test Strategy:**

Run `ruff check src/ tests/ --fix` and review changes. Run `ruff check src/ tests/` to verify all pass. Run test suite to ensure imports work correctly.

---

## Implementation Notes

### Session: 2026-02-02 10:30 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Added "I" to ruff lint select list in `pyproject.toml:45`
- Added `[tool.ruff.lint.isort]` section with configuration:
  - `known-first-party = ["teams_phone"]`
  - `force-single-line = false`
  - `lines-after-imports = 2`
- Ran `ruff check src/ tests/ --select=I` to identify 84 import sorting violations
- Ran `ruff check src/ tests/ --fix` to auto-fix all 84 violations
- Verified `tests/conftest.py` E402 noqa imports preserved (lines 26-33, 49)
- Ran full test suite: 1324 passed, 11 skipped

#### Files Modified
- `pyproject.toml` - Added isort configuration
- 27 source files in `src/teams_phone/` - Import order auto-fixed
- 30 test files in `tests/` - Import order auto-fixed

#### Key Decisions Made
- **Preserved E402 noqa comments**: The `tests/conftest.py` file has intentional out-of-order imports for CI environment setup. These noqa comments (E402) protect against "module level import not at top" violations and are unaffected by isort (I001) which handles sorting.
- **Used `force-single-line = false`**: Allows multi-line imports with parentheses, which matches existing codebase style.
- **Used `lines-after-imports = 2`**: Follows PEP 8 standard for two blank lines after imports at module level.

#### Patterns Discovered
- Isort auto-groups imports into: `__future__` → standard library → third-party → first-party (teams_phone)
- Import sorting within groups is alphabetical by module name
- Multi-line imports are preserved and sorted alphabetically

#### Open Items for Next Agent
- [ ] Pre-commit mypy hook fails on tests directory (missing pytest stubs) - this is pre-existing and unrelated to isort (noted in Task 16)

#### Gotchas and Warnings
- The `tests/conftest.py` file has a special import structure where environment variables must be set BEFORE importing Rich/Typer modules. The E402 noqa comments protect this pattern.
- Isort rules (I001/I002) are distinct from E402 rules - isort handles sorting order, E402 handles import positioning.

---
