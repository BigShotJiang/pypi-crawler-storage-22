# Task ID: 19

**Title:** Fix or document ruff rule violations

**Status:** pending

**Dependencies:** 16, 17, 18

**Priority:** medium

**Description:** Address all violations from newly enabled ruff rules (C901, B, I) by fixing code or adding documented ignores.

**Details:**

After enabling C901, B, and I rules, systematically address violations:

1. Run `ruff check src/ tests/ --statistics` to see violation counts by rule

2. For each violation type, decide approach:
   - Auto-fixable (I rules): `ruff check --fix`
   - Simple fixes (most B rules): Manual fix
   - Complex refactoring (C901): Evaluate if refactoring is beneficial
   - Necessary complexity: Add noqa with comment

3. Document any ignored rules in pyproject.toml:
```toml
[tool.ruff.lint.per-file-ignores]
# Complex CLI command handlers have necessary complexity
"src/teams_phone/cli/numbers.py" = ["C901"]
```

4. Add inline noqa comments with justification:
```python
def complex_but_necessary_function():  # noqa: C901 - orchestrates multi-step workflow
    ...
```

5. Create tracking document `.taskmaster/docs/RUFF_IGNORES.md` listing all ignored rules and rationale.

**Test Strategy:**

Run `ruff check src/ tests/` - must exit 0. Run full test suite. Review any noqa comments in PR for appropriateness.

---

## Implementation Notes

### Subtask 19.1: Auto-fix import sorting (I) violations

#### Session: 2026-02-02 20:40 - Agent: claude-opus-4-5-20251101

**Status:** Verified Complete (No Changes Needed)

#### What Was Done
- Verified import sorting violations: `ruff check src/ tests/ --select I` returned **zero violations**
- Verified full ruff check: `ruff check src/ tests/` returned **All checks passed!**
- Confirmed this work was already completed by Task 18 (see implementation notes in `task_018.md:60-63`)

#### Key Decisions Made
- **No code changes required**: Task 18 already auto-fixed all 84 import sorting violations
- **Marking as done without commit**: Since no changes were made, no commit is needed - just status update

#### Verification Results
```
$ uv run ruff check src/ tests/ --select I
All checks passed!

$ uv run ruff check src/ tests/
All checks passed!
```

#### Open Items for Next Agent
- [ ] 32 test errors exist due to `mock_cli_services_users` fixture trying to patch `teams_phone.cli.users.CacheManager` which no longer exists - this is a **pre-existing test fixture bug** unrelated to import sorting
- [ ] Pre-commit mypy hook fails on tests directory (from Task 16 notes) - unrelated to this subtask

#### Gotchas and Warnings
- The test failures are caused by outdated test fixtures that reference removed module attributes, not by import sorting changes
- Task 18 implementation notes document the 84 violations that were already fixed

---

### Subtask 19.2: Fix bugbear (B) rule violations manually

#### Session: 2026-02-02 21:20 - Agent: claude-opus-4-5-20251101

**Status:** Verified Complete (No Changes Needed)

#### What Was Done
- Verified B rule violations status: All B violations are B008 (typer.Option/typer.Argument in defaults)
- Confirmed B008 is intentionally ignored in pyproject.toml (line 46) with documentation comment
- Ran full ruff check: `ruff check src/ tests/` returned **All checks passed!**
- Ran full unit test suite: **1204 passed** in 24.60s
- Ran mypy: No type errors

#### Key Decisions Made
- **No code changes required**: B008 is the only B rule violation, and it's intentionally ignored
- **B008 ignore is correct**: `typer.Option()` and `typer.Argument()` in function defaults is the standard Typer CLI pattern
- **Well documented**: pyproject.toml includes comment explaining why B008 is ignored

#### Verification Results
```
$ uv run ruff check src/ tests/ --select B
Found 12 errors.  # All are B008

$ uv run ruff check src/ tests/  # Uses pyproject.toml config
All checks passed!

$ uv run pytest tests/ -m unit --tb=short -q
1204 passed, 131 deselected in 24.60s

$ uv run mypy src/
No errors
```

#### B008 Violation Locations (Intentionally Ignored)
All 12 B008 violations are in CLI modules using standard Typer patterns:
- `src/teams_phone/cli/locations.py:257` - typer.Option for search field
- `src/teams_phone/cli/main.py:59` - typer.Option for debug log
- `src/teams_phone/cli/numbers.py:269,275,590,1220,1241` - typer.Option/Argument for list/assign commands
- `src/teams_phone/cli/policies.py:538,554` - typer.Argument/Option for bulk assign
- `src/teams_phone/cli/tenants.py:286` - typer.Option for auth method
- `src/teams_phone/cli/users.py:129,325` - typer.Option for account type/search field

#### Open Items for Next Agent
- [ ] None - B rule violations are fully handled

#### Gotchas and Warnings
- When running `ruff check --select B`, it shows 12 errors because `--select` overrides pyproject.toml ignore
- The full `ruff check src/ tests/` (without explicit --select) uses pyproject.toml config correctly

---

### Subtask 19.3: Address C901 complexity violations and create RUFF_IGNORES.md

#### Session: 2026-02-02 21:45 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Verified all C901 noqa comments already exist with proper justifications (9 instances)
- Verified BLE001 noqa comment exists for tenant_service connection test
- Verified E402 noqa comments in tests/conftest.py for import order dependencies
- Verified F401 noqa comments in test files for circular import prevention
- Created `.taskmaster/docs/RUFF_IGNORES.md` comprehensive tracking document with:
  - Ruff configuration overview
  - Global ignores (B008) with rationale
  - Complete table of all inline noqa comments organized by rule
  - Guidelines for adding new ignores
  - Verification commands

#### Key Decisions Made
- **No code refactoring needed**: All 9 C901 violations are CLI commands and bulk operations where complexity is inherent and justified
- **Documentation focus**: Main deliverable is the tracking document, not code changes
- **Comprehensive coverage**: Documented all noqa comments including E402 and F401 in test files

#### Files Created
- `.taskmaster/docs/RUFF_IGNORES.md` - Main tracking document

#### noqa Comments Documented
| Rule | Count | Context |
|------|-------|---------|
| C901 | 9 | CLI commands and bulk operations |
| BLE001 | 1 | Connection test exception handling |
| E402 | 9 | Test conftest import order |
| F401 | 4 | Test files circular import prevention |

#### Verification Results
```
$ uv run ruff check src/ tests/
All checks passed!

$ uv run ruff check src/ tests/ --select C901
All checks passed!

$ uv run pytest tests/ -m unit -q --tb=short
1204 passed, 131 deselected in 24.59s
```

#### Open Items for Next Agent
- [ ] None - all acceptance criteria met

#### Gotchas and Warnings
- When adding new noqa comments, always update RUFF_IGNORES.md in the same commit
- The F401 imports in test files are not truly "unused" - they establish import order to avoid circular dependencies

---
