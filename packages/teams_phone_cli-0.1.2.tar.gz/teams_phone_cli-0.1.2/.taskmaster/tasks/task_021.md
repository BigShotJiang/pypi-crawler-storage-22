# Task ID: 21

**Title:** Update pre-commit hooks for expanded ruff rules

**Status:** pending

**Dependencies:** 19

**Priority:** low

**Description:** Ensure pre-commit configuration runs ruff with all newly enabled rules.

**Details:**

Verify pre-commit hooks use project ruff configuration:

1. Check .pre-commit-config.yaml:
```yaml
repos:
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: v0.1.0  # Use latest version
    hooks:
      - id: ruff
        args: [--fix, --exit-non-zero-on-fix]
      - id: ruff-format
```

2. Run `pre-commit run --all-files` to test

3. If any files fail, fix violations

4. Update pre-commit hook version if needed:
```bash
pre-commit autoupdate
```

5. Document the expanded rules in CONTRIBUTING.md or README if applicable

**Test Strategy:**

Run `pre-commit run --all-files` - must pass. Make a test commit to verify hooks trigger correctly.

---

## Implementation Notes

### Session: 2026-02-02 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Updated ruff-pre-commit from v0.9.6 to v0.14.14 to match project's ruff version
- Added `--exit-non-zero-on-fix` flag to ruff hook for stricter pre-commit behavior
- Applied formatting fixes to 5 files that had minor formatting differences due to version mismatch
- Verified all pre-commit hooks pass (ruff check and ruff-format)
- Confirmed mypy fails on tests directory (known pre-existing issue - missing pytest stubs)

#### Files Modified
- `.pre-commit-config.yaml` - Updated ruff version and args
- `src/teams_phone/models/config.py` - Formatting fix (extra blank line removed)
- `src/teams_phone/models/number.py` - Formatting fix (line length optimization)
- `src/teams_phone/models/user.py` - Formatting fix (line length optimization)
- `src/teams_phone/services/location_service.py` - Formatting fix (multi-line if statement)
- `tests/unit/test_auth_service.py` - Formatting fix (context manager formatting)

#### Key Decisions Made
- **Version alignment**: Updated pre-commit hook to v0.14.14 to match installed ruff 0.14.14, eliminating formatting drift
- **Exit behavior**: Added `--exit-non-zero-on-fix` so auto-fixes block the commit until re-staged (stricter workflow)
- **README documentation**: Declined adding ruff rule documentation to README since RUFF_IGNORES.md already provides comprehensive coverage in the appropriate location

#### Verification Results
```
ruff (legacy alias)......................................................Passed
ruff format..............................................................Passed
mypy.....................................................................Failed (known issue)
```

- Unit tests: 1190 passed
- Source mypy: Success (no issues found in 40 source files)

#### Open Items for Next Agent
- [ ] Pre-commit mypy hook fails on tests directory - documented in multiple task notes, not addressed here (out of scope)

#### Gotchas and Warnings
- Pre-commit hooks use isolated environments - the hook's ruff version must match the project's version to avoid formatting differences
- The `--exit-non-zero-on-fix` flag changes workflow: users must re-stage after auto-fixes instead of having fixes silently committed

---
