"""Teams Phone CLI - Manage Microsoft Teams Phone configurations."""

__version__ = "0.1.0"
