"""CLI Helper Functions - Shared utilities for CLI commands."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from typing import TYPE_CHECKING, Any, TypeVar

import typer

from teams_phone.cli.context import get_context
from teams_phone.infrastructure import CacheManager, GraphClient
from teams_phone.services import AuthService


if TYPE_CHECKING:
    from teams_phone.infrastructure import OutputFormatter

ServiceT = TypeVar("ServiceT")


def run_with_service(
    ctx: typer.Context,
    service_factory: Callable[[GraphClient], ServiceT],
    operation: Callable[[ServiceT], Any],
) -> tuple[Any, OutputFormatter]:
    """Run an async operation with a service.

    Creates the required infrastructure (GraphClient, service) and runs
    the async operation using asyncio.run(). This is the generic pattern
    for CLI commands that need to interact with services.

    Args:
        ctx: Typer context with CLIContext.
        service_factory: A callable that takes a GraphClient and returns
            a service instance (e.g., UserService, NumberService).
        operation: A callable that takes the service and returns a coroutine
            to execute.

    Returns:
        Tuple of (result, OutputFormatter) where result is the coroutine's
        return value.

    Example:
        def list_users(ctx: typer.Context) -> None:
            result, formatter = run_with_service(
                ctx,
                service_factory=UserService,
                operation=lambda svc: svc.list_users(),
            )
            formatter.print_table(result)
    """
    cli_ctx = get_context(ctx)
    formatter = cli_ctx.get_output_formatter()
    config_manager = cli_ctx.get_config_manager()
    cache_manager = CacheManager()
    auth_service = AuthService(config_manager, cache_manager)

    async def _execute() -> Any:
        async with GraphClient(auth_service) as graph_client:
            service = service_factory(graph_client)
            return await operation(service)

    result = asyncio.run(_execute())
    return result, formatter
