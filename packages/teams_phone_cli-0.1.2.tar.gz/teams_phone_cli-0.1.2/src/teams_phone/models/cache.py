"""Cache-related models for metadata and staleness tracking."""

from datetime import datetime

from pydantic import BaseModel, ConfigDict


class CacheMetadata(BaseModel):
    """Metadata about CSV cache files.

    Tracks when the cache was last updated and how much data it contains.
    Used to determine if the cache is stale and needs refreshing.

    Attributes:
        last_updated: UTC datetime when the oldest cache file was modified.
            None if no cache files exist.
        locations_count: Number of location records in the cache.
        policies_count: Number of policy records in the cache.
    """

    model_config = ConfigDict(extra="forbid")

    last_updated: datetime | None
    locations_count: int
    policies_count: int
