"""Configuration models for CLI settings and defaults."""

from pydantic import BaseModel, ConfigDict, Field

from teams_phone.constants import (
    CSV_STALE_DAYS,
    DEFAULT_CACHE_PATH,
    DEFAULT_CONFIG_PATH,
    DEFAULT_TIMEOUT,
    DEFAULT_TOKEN_PATH,
    MAX_RETRIES,
)
from teams_phone.models.tenant import TenantProfile


class CacheSettings(BaseModel):
    """Cache configuration settings.

    Attributes:
        cache_path: Directory path for cached data files.
        stale_days: Number of days before cache is considered stale.
    """

    model_config = ConfigDict(extra="forbid")

    cache_path: str = DEFAULT_CACHE_PATH
    stale_days: int = CSV_STALE_DAYS


class NetworkSettings(BaseModel):
    """Network and HTTP client settings.

    Attributes:
        timeout: HTTP request timeout in seconds.
        max_retries: Maximum retry attempts for transient failures.
    """

    model_config = ConfigDict(extra="forbid")

    timeout: int = DEFAULT_TIMEOUT
    max_retries: int = MAX_RETRIES


class Config(BaseModel):
    """Main configuration model for Teams Phone CLI.

    Root configuration containing all settings, defaults, and tenant profiles.
    Loaded from config.toml at startup.

    Attributes:
        config_path: Path to the configuration file.
        token_path: Directory path for authentication token storage.
        default_tenant: Name of the default tenant profile to use.
        cache: Cache-related settings.
        network: Network and HTTP client settings.
        tenants: Dictionary of tenant profiles keyed by name.
    """

    model_config = ConfigDict(extra="forbid")

    config_path: str = DEFAULT_CONFIG_PATH
    token_path: str = DEFAULT_TOKEN_PATH
    default_tenant: str | None = None
    cache: CacheSettings = Field(default_factory=CacheSettings)
    network: NetworkSettings = Field(default_factory=NetworkSettings)
    tenants: dict[str, TenantProfile] = Field(default_factory=dict)
