"""Emergency location model for CSV cache data."""

from pydantic import BaseModel, ConfigDict, Field


class EmergencyLocation(BaseModel):
    """Emergency location from CSV cache.

    Represents an emergency calling location exported via PowerShell.
    Used for validation and display since Graph API doesn't expose location endpoints.

    Attributes:
        location_id: Unique identifier for the location (GUID).
        civic_address_id: Associated civic address ID (GUID).
        description: Location description/name.
        company_name: Company name at this location.
        address: Street address.
        city: City name.
        state_or_province: State or province.
        postal_code: Postal/ZIP code.
        country_or_region: Country or region code.
        is_default: Whether this is the default location for the civic address.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    location_id: str = Field(alias="locationId")
    civic_address_id: str = Field(alias="civicAddressId")
    description: str = Field(alias="description")
    company_name: str | None = Field(alias="companyName", default=None)
    address: str | None = Field(alias="address", default=None)
    city: str | None = Field(alias="city", default=None)
    state_or_province: str | None = Field(alias="stateOrProvince", default=None)
    postal_code: str | None = Field(alias="postalCode", default=None)
    country_or_region: str | None = Field(alias="countryOrRegion", default=None)
    is_default: bool = Field(alias="isDefault")
