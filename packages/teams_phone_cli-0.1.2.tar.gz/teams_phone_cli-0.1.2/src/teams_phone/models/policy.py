"""Voice policy model for CSV cache data."""

from pydantic import BaseModel, ConfigDict, Field


class Policy(BaseModel):
    """Voice policy from CSV cache.

    Represents a Teams voice policy exported via PowerShell.
    Used for validation and display since Graph API doesn't expose policy endpoints.

    Attributes:
        policy_type: Type of policy (e.g., "TeamsCallingPolicy", "TenantDialPlan").
        policy_name: Human-readable policy name.
        policy_id: Unique identifier for the policy.
        description: Optional policy description.
        is_global: Whether this is the global (default) policy.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    policy_type: str = Field(alias="policyType")
    policy_name: str = Field(alias="policyName")
    policy_id: str = Field(alias="policyId")
    description: str | None = Field(alias="description", default=None)
    is_global: bool = Field(alias="isGlobal")
