"""Service Layer - Business logic for Teams Phone operations."""

from teams_phone.services.auth_service import CLIENT_SECRET_ENV_VAR, SCOPES, AuthService
from teams_phone.services.location_service import LocationService
from teams_phone.services.policy_service import PolicyService
from teams_phone.services.tenant_service import TenantService


# Note: UserService and NumberService are not exported here to avoid circular import.
# Import directly:
#   from teams_phone.services.user_service import UserService
#   from teams_phone.services.number_service import NumberService

__all__ = [
    "AuthService",
    "CLIENT_SECRET_ENV_VAR",
    "LocationService",
    "PolicyService",
    "SCOPES",
    "TenantService",
]
