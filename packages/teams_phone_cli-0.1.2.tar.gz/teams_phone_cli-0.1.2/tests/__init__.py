"""Test suite for Teams Phone CLI."""
