"""Pytest configuration and fixtures for Teams Phone CLI tests."""

# Set terminal environment BEFORE any imports to ensure Rich/Typer see them.
# Rich checks COLUMNS env var and shutil.get_terminal_size() for terminal width.
# In CI environments without a TTY, these can return unusable values.
# NO_COLOR=1 disables ANSI color codes so string matching in tests works correctly.
# (Rich splits "--json" into "-" + "-json" with color codes between, breaking asserts)
import os


os.environ.setdefault("COLUMNS", "120")
os.environ.setdefault("LINES", "24")
os.environ.setdefault("TERM", "xterm-256color")
os.environ["NO_COLOR"] = (
    "1"  # Must be set, not setdefault, to override any existing value
)

# Configure Typer's Rich console BEFORE any Typer imports
# This is critical for CI environments where Rich cannot detect terminal size
import typer.rich_utils as rich_utils


rich_utils._TERMINAL_WIDTH = 120  # type: ignore[assignment]
rich_utils.MAX_WIDTH = 120

import shutil  # noqa: E402
from collections.abc import Generator  # noqa: E402
from typing import Any  # noqa: E402
from unittest.mock import AsyncMock, MagicMock, patch  # noqa: E402

import pytest  # noqa: E402
from typer import Typer  # noqa: E402
from typer.testing import CliRunner as TyperCliRunner  # noqa: E402
from typer.testing import Result  # type: ignore[attr-defined]  # noqa: E402


# Store original function for potential restoration
_original_get_terminal_size = shutil.get_terminal_size


def _fixed_terminal_size(fallback: tuple[int, int] = (80, 24)) -> os.terminal_size:
    """Return a fixed terminal size for consistent test behavior."""
    return os.terminal_size((120, 24))


# Patch at module level to catch early imports
shutil.get_terminal_size = _fixed_terminal_size


import re  # noqa: E402


def strip_ansi(text: str) -> str:
    """Remove ANSI escape codes from text for reliable assertion matching."""
    ansi_pattern = re.compile(r"\x1b\[[0-9;]*m")
    return ansi_pattern.sub("", text)


class CliRunnerResult:
    """Wrapper for CliRunner Result that provides ANSI-stripped output.

    In CI environments, Rich may insert ANSI codes that split up text
    (e.g., "--json" becomes "-" + colored "-json"), breaking assertions.
    This wrapper provides `plain_stdout` and `plain_stderr` for reliable matching.
    """

    def __init__(self, result: Result) -> None:
        self._result = result

    def __getattr__(self, name: str) -> Any:
        return getattr(self._result, name)

    @property
    def plain_stdout(self) -> str:
        """Return stdout with ANSI codes stripped."""
        return strip_ansi(self._result.stdout)

    @property
    def plain_stderr(self) -> str:
        """Return stderr with ANSI codes stripped."""
        return strip_ansi(self._result.stderr) if self._result.stderr else ""


class CliRunner(TyperCliRunner):
    """Custom CliRunner that ensures consistent output for tests.

    Wraps results in CliRunnerResult for ANSI-stripped output properties.
    """

    def invoke(  # type: ignore[override]
        self,
        app: Typer,
        args: list[str] | str | None = None,
        **kwargs: Any,
    ) -> CliRunnerResult:
        """Invoke the CLI app and wrap the result."""
        kwargs.setdefault("terminal_width", 120)
        result = super().invoke(app, args, **kwargs)
        return CliRunnerResult(result)


def pytest_configure(config: pytest.Config) -> None:
    """Register custom markers for test categorization."""
    config.addinivalue_line("markers", "unit: Fast unit tests with mocks")
    config.addinivalue_line("markers", "integration: Integration tests with real API")
    config.addinivalue_line("markers", "contract: API contract validation tests")


# =============================================================================
# Shared Fixtures
# =============================================================================


@pytest.fixture
def mock_graph_client() -> AsyncMock:
    """Create a mock GraphClient configured as an async context manager.

    This fixture provides an AsyncMock pre-configured with the async context manager
    protocol (__aenter__/__aexit__) that GraphClient uses. It's suitable for CLI-level
    tests where GraphClient is accessed via `async with GraphClient() as gc:`.

    For service-level unit tests that inject GraphClient directly into constructors,
    use the mock_graph_client fixture from tests/unit/conftest.py instead (which
    provides a plain MagicMock).

    Returns:
        AsyncMock: A mock configured with __aenter__ returning itself and
            __aexit__ returning None. All methods are AsyncMock by default.

    Example:
        Basic usage with patching:

            def test_with_graph_client(mock_graph_client):
                mock_graph_client.get.return_value = {"value": []}

                with patch("my_module.GraphClient", return_value=mock_graph_client):
                    result = await my_function()

        Configure paginated responses:

            def test_paginated(mock_graph_client):
                mock_graph_client.get_paginated.return_value = [
                    {"id": "1", "name": "Item 1"},
                    {"id": "2", "name": "Item 2"},
                ]

    Note:
        This fixture is overridden in tests/unit/conftest.py to provide a plain
        MagicMock for direct service injection. Tests in tests/unit/ will
        automatically receive the MagicMock version.
    """
    mock_gc = AsyncMock()
    mock_gc.__aenter__.return_value = mock_gc
    mock_gc.__aexit__.return_value = None
    return mock_gc


@pytest.fixture
def mock_cli_infrastructure() -> Generator[dict[str, Any], None, None]:
    """Patch common CLI infrastructure for CLI module tests.

    This fixture patches CacheManager, AuthService, and GraphClient at multiple
    module levels to support the CLI's dependency injection pattern. It patches at:
    - teams_phone.cli.helpers (for run_with_service helper)
    - teams_phone.cli.numbers (for specialized multi-service helpers)

    Use this fixture as a base for CLI tests that need infrastructure mocks but
    don't need service-level mocking. For tests that also need NumberService,
    use mock_number_service instead.

    Args:
        None (pytest fixture - no explicit arguments).

    Yields:
        dict[str, Any]: A dictionary containing mock instances:
            - "cache_manager" (MagicMock): Mock for CacheManager, used for
              CSV cache operations (policies, locations).
            - "auth_service" (MagicMock): Mock for AuthService, provides
              authentication context.
            - "graph_client" (AsyncMock): Mock for GraphClient, configured
              with async context manager protocol.

    Example:
        Basic CLI test with infrastructure mocking:

            def test_numbers_command(mock_cli_infrastructure):
                mocks = mock_cli_infrastructure
                mocks["graph_client"].get.return_value = {"value": []}

                result = runner.invoke(app, ["numbers", "list"])
                assert result.exit_code == 0

        Configure cache manager for policy lookups:

            def test_with_cached_policies(mock_cli_infrastructure):
                mocks = mock_cli_infrastructure
                mocks["cache_manager"].get_policies.return_value = [
                    Policy(policy_type="TeamsCallingPolicy", ...)
                ]

        Configure auth service:

            def test_auth_context(mock_cli_infrastructure):
                mocks = mock_cli_infrastructure
                mocks["auth_service"].tenant_id = "test-tenant-id"

    Note:
        This fixture only patches infrastructure at teams_phone.cli.helpers and
        teams_phone.cli.numbers. For other CLI modules (users, policies), you may
        need to add additional patches or use a module-specific fixture.
    """
    mock_cm = MagicMock()
    mock_auth = MagicMock()
    mock_gc = AsyncMock()
    mock_gc.__aenter__.return_value = mock_gc
    mock_gc.__aexit__.return_value = None

    with (
        # Patch at helpers level for run_with_service
        patch("teams_phone.cli.helpers.CacheManager", return_value=mock_cm),
        patch("teams_phone.cli.helpers.AuthService", return_value=mock_auth),
        patch("teams_phone.cli.helpers.GraphClient", return_value=mock_gc),
        # Also patch at numbers level for specialized multi-service helpers
        patch("teams_phone.cli.numbers.CacheManager", return_value=mock_cm),
        patch("teams_phone.cli.numbers.AuthService", return_value=mock_auth),
        patch("teams_phone.cli.numbers.GraphClient", return_value=mock_gc),
    ):
        yield {
            "cache_manager": mock_cm,
            "auth_service": mock_auth,
            "graph_client": mock_gc,
        }


@pytest.fixture
def mock_number_service(
    mock_cli_infrastructure: dict[str, Any],
) -> Generator[dict[str, Any], None, None]:
    """Patch NumberService in addition to CLI infrastructure for numbers module.

    This fixture extends mock_cli_infrastructure by adding a NumberService mock
    pre-configured with AsyncMock stubs for all service methods. Use this for
    CLI tests of the numbers module that need to control service-level behavior.

    The fixture patches NumberService at teams_phone.cli.numbers, which is where
    the numbers CLI module imports it from.

    Args:
        mock_cli_infrastructure: The base infrastructure fixture (auto-injected
            by pytest). Provides cache_manager, auth_service, and graph_client.

    Yields:
        dict[str, Any]: A dictionary containing all mock instances:
            - "cache_manager" (MagicMock): From mock_cli_infrastructure.
            - "auth_service" (MagicMock): From mock_cli_infrastructure.
            - "graph_client" (AsyncMock): From mock_cli_infrastructure.
            - "number_service" (MagicMock): Mock NumberService with pre-configured
              AsyncMock methods: list_numbers, get_number, search_numbers,
              assign_number, unassign_number (all return empty/None by default).

    Example:
        Test listing numbers:

            def test_numbers_list(mock_number_service):
                mocks = mock_number_service
                mocks["number_service"].list_numbers.return_value = [
                    make_number(telephone_number="+14255551234"),
                    make_number(telephone_number="+14255555678"),
                ]

                result = runner.invoke(app, ["numbers", "list"])
                assert result.exit_code == 0

        Test number assignment:

            def test_assign_number(mock_number_service):
                mocks = mock_number_service
                mocks["number_service"].assign_number.return_value = make_operation(
                    status=OperationStatus.SUCCEEDED
                )

                result = runner.invoke(app, ["numbers", "assign", ...])

        Test error handling:

            def test_number_not_found(mock_number_service):
                from teams_phone.exceptions import NotFoundError
                mocks = mock_number_service
                mocks["number_service"].get_number.side_effect = NotFoundError(
                    "Number not found"
                )

                result = runner.invoke(app, ["numbers", "get", "+1234"])
                assert result.exit_code != 0

    Note:
        The number_service mock methods return empty results by default:
        - list_numbers returns []
        - get_number returns None
        - search_numbers returns []
        - assign_number returns None
        - unassign_number returns None
        Configure return values or side_effects as needed for your test.
    """
    mock_ns = MagicMock()
    mock_ns.list_numbers = AsyncMock(return_value=[])
    mock_ns.get_number = AsyncMock(return_value=None)
    mock_ns.search_numbers = AsyncMock(return_value=[])
    mock_ns.assign_number = AsyncMock(return_value=None)
    mock_ns.unassign_number = AsyncMock(return_value=None)

    with patch("teams_phone.cli.numbers.NumberService", return_value=mock_ns):
        yield {
            **mock_cli_infrastructure,
            "number_service": mock_ns,
        }
