"""Contract tests for validating Pydantic models against live Graph API."""
