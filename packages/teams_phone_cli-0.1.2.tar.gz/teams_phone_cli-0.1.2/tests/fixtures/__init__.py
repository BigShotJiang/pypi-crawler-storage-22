"""Test fixtures package for shared test utilities.

This package provides factory functions and fixtures for creating test data.
All factories return Pydantic model instances with sensible defaults.

Usage:
    from tests.fixtures import make_user, make_number, make_policy

    # Create with defaults
    user = make_user()
    number = make_number()

    # Override specific fields
    user = make_user(display_name="Alice", is_enterprise_voice_enabled=True)

Factory Functions:
    - make_user: Create UserConfiguration instances
    - make_number: Create NumberAssignment instances
    - make_policy: Create Policy instances
    - make_location: Create EmergencyLocation instances
    - make_operation: Create AsyncOperation instances
"""

from tests.fixtures.factories import (
    make_location,
    make_number,
    make_operation,
    make_policy,
    make_user,
)


__all__ = [
    "make_user",
    "make_number",
    "make_policy",
    "make_location",
    "make_operation",
]
