"""Factory functions for creating test model instances.

This module provides factory functions that create Pydantic model instances
with sensible defaults. All functions support **kwargs for field overrides.

Usage:
    from tests.fixtures import make_user, make_number, make_policy

    # Create with defaults
    user = make_user()

    # Override specific fields
    user = make_user(display_name="Alice", is_enterprise_voice_enabled=True)

Factory Functions:
    - make_user: Create UserConfiguration instances
    - make_number: Create NumberAssignment instances
    - make_policy: Create Policy instances
    - make_location: Create EmergencyLocation instances
    - make_operation: Create AsyncOperation instances
"""

from datetime import datetime, timezone
from typing import Any

from teams_phone.models import (
    AccountType,
    ActivationState,
    AssignmentStatus,
    AsyncOperation,
    EmergencyLocation,
    NumberAssignment,
    NumberType,
    OperationStatus,
    Policy,
    UserConfiguration,
)


def make_user(
    *,
    id: str = "11111111-1111-1111-1111-111111111111",
    user_principal_name: str = "user@contoso.com",
    tenant_id: str = "22222222-2222-2222-2222-222222222222",
    display_name: str | None = "Test User",
    account_type: AccountType = AccountType.USER,
    is_enterprise_voice_enabled: bool = False,
    feature_types: list[str] | None = None,
    telephone_numbers: list[dict[str, Any]] | None = None,
    effective_policy_assignments: list[dict[str, Any]] | None = None,
    **kwargs: Any,
) -> UserConfiguration:
    """Create a UserConfiguration with sensible defaults.

    Creates a valid UserConfiguration Pydantic model instance with pre-populated
    default values. All fields can be overridden via explicit parameters or kwargs.

    Args:
        id: User's Entra object ID (UUID format).
        user_principal_name: User's UPN (email format).
        tenant_id: Microsoft Entra tenant ID.
        display_name: User's display name.
        account_type: Type of user account (USER, RESOURCE_ACCOUNT, etc.).
        is_enterprise_voice_enabled: Whether enterprise voice is enabled.
        feature_types: List of enabled features (e.g., ["VoicemailEnabled"]).
        telephone_numbers: List of telephone number dicts with keys
            "telephoneNumber" and "assignmentCategory".
        effective_policy_assignments: List of policy assignment dicts with nested
            structure: {"policyType": "...", "policyAssignment": {"displayName": "...",
            "assignmentType": "...", "policyId": "..."}}.
        **kwargs: Additional fields passed directly to model_validate. Use camelCase
            API field names (e.g., displayName) to override any field.

    Returns:
        UserConfiguration: A valid model instance ready for testing.

    Example:
        Basic usage with defaults:

            >>> user = make_user()
            >>> user.display_name
            'Test User'

        Override specific fields:

            >>> user = make_user(display_name="Alice", is_enterprise_voice_enabled=True)
            >>> user.display_name
            'Alice'

        Create enterprise voice user with phone number:

            >>> user = make_user(
            ...     is_enterprise_voice_enabled=True,
            ...     telephone_numbers=[
            ...         {"telephoneNumber": "+14255551234", "assignmentCategory": "primary"}
            ...     ]
            ... )

        Override via camelCase kwargs:

            >>> user = make_user(displayName="Bob", userPrincipalName="bob@contoso.com")
            >>> user.display_name
            'Bob'

    Note:
        The factory uses model_validate() so Pydantic field validation is performed.
        Invalid field values will raise pydantic.ValidationError. Both enum instances
        (e.g., AccountType.USER) and string values (e.g., "user") are accepted for
        enum fields.
    """
    data = {
        "id": id,
        "userPrincipalName": user_principal_name,
        "tenantId": tenant_id,
        "displayName": display_name,
        "accountType": account_type.value
        if isinstance(account_type, AccountType)
        else account_type,
        "isEnterpriseVoiceEnabled": is_enterprise_voice_enabled,
        "featureTypes": feature_types if feature_types is not None else [],
        "telephoneNumbers": telephone_numbers if telephone_numbers is not None else [],
        "effectivePolicyAssignments": effective_policy_assignments
        if effective_policy_assignments is not None
        else [],
    }
    data.update(kwargs)
    return UserConfiguration.model_validate(data)


def make_number(
    *,
    id: str = "num-11111111-1111-1111-1111-111111111111",
    telephone_number: str = "+14255551234",
    number_type: NumberType = NumberType.DIRECT_ROUTING,
    activation_state: ActivationState = ActivationState.ACTIVATED,
    capabilities: list[str] | None = None,
    assignment_status: AssignmentStatus = AssignmentStatus.UNASSIGNED,
    city: str | None = "Seattle",
    location_id: str | None = None,
    assignment_target_id: str | None = None,
    **kwargs: Any,
) -> NumberAssignment:
    """Create a NumberAssignment with sensible defaults.

    Creates a valid NumberAssignment Pydantic model instance representing a phone
    number in Teams Phone. Defaults to an unassigned DirectRouting number.

    Args:
        id: Unique identifier for the number assignment.
        telephone_number: Phone number in E.164 format (e.g., "+14255551234").
        number_type: Type of phone number (DIRECT_ROUTING, CALLING_PLAN, etc.).
        activation_state: Current activation state (ACTIVATED, ACTIVATION_PENDING).
        capabilities: List of capabilities (defaults to ["userAssignment"]).
        assignment_status: Current assignment status (UNASSIGNED, USER_ASSIGNED,
            RESOURCE_ACCOUNT_ASSIGNED).
        city: City associated with the number.
        location_id: ID of emergency location (GUID format).
        assignment_target_id: User or resource account object ID when assigned.
        **kwargs: Additional fields passed directly to model_validate. Use camelCase
            API field names (e.g., telephoneNumber) to override any field.

    Returns:
        NumberAssignment: A valid model instance ready for testing.

    Example:
        Basic usage with defaults (unassigned number):

            >>> number = make_number()
            >>> number.telephone_number
            '+14255551234'
            >>> number.assignment_status
            <AssignmentStatus.UNASSIGNED: 'unassigned'>

        Create an assigned number:

            >>> number = make_number(
            ...     telephone_number="+14255559999",
            ...     assignment_status=AssignmentStatus.USER_ASSIGNED,
            ...     assignment_target_id="user-123"
            ... )

        Create a CallingPlan number:

            >>> number = make_number(
            ...     number_type=NumberType.CALLING_PLAN,
            ...     capabilities=["userAssignment", "voiceApplicationAssignment"]
            ... )

        Override via camelCase kwargs:

            >>> number = make_number(telephoneNumber="+15551234567")
            >>> number.telephone_number
            '+15551234567'

    Note:
        The factory uses model_validate() so Pydantic field validation is performed.
        Invalid field values will raise pydantic.ValidationError. Both enum instances
        (e.g., NumberType.DIRECT_ROUTING) and string values (e.g., "directRouting")
        are accepted for enum fields.
    """
    data = {
        "id": id,
        "telephoneNumber": telephone_number,
        "numberType": number_type.value
        if isinstance(number_type, NumberType)
        else number_type,
        "activationState": activation_state.value
        if isinstance(activation_state, ActivationState)
        else activation_state,
        "capabilities": capabilities
        if capabilities is not None
        else ["userAssignment"],
        "assignmentStatus": assignment_status.value
        if isinstance(assignment_status, AssignmentStatus)
        else assignment_status,
        "city": city,
        "locationId": location_id,
        "assignmentTargetId": assignment_target_id,
    }
    data.update(kwargs)
    return NumberAssignment.model_validate(data)


def make_policy(
    *,
    policy_type: str = "TeamsCallingPolicy",
    policy_name: str = "AllowCalling",
    policy_id: str = "policy-11111111-1111-1111-1111-111111111111",
    description: str | None = "Test policy for unit tests",
    is_global: bool = False,
    **kwargs: Any,
) -> Policy:
    """Create a Policy with sensible defaults.

    Creates a valid Policy Pydantic model instance representing a Teams policy.
    Defaults to a non-global TeamsCallingPolicy.

    Args:
        policy_type: Type of policy. Common values include "TeamsCallingPolicy",
            "TenantDialPlan", "TeamsVoiceRoutingPolicy", "CallerIdPolicy".
        policy_name: Human-readable policy name.
        policy_id: Unique identifier for the policy (GUID format).
        description: Optional policy description.
        is_global: Whether this is the global (default) policy. Global policies
            apply to all users who don't have a specific policy assigned.
        **kwargs: Additional fields passed directly to model_validate. Use camelCase
            API field names (e.g., policyType) to override any field.

    Returns:
        Policy: A valid model instance ready for testing.

    Example:
        Basic usage with defaults:

            >>> policy = make_policy()
            >>> policy.policy_type
            'TeamsCallingPolicy'
            >>> policy.is_global
            False

        Create a global dial plan:

            >>> policy = make_policy(
            ...     policy_type="TenantDialPlan",
            ...     policy_name="Global",
            ...     is_global=True
            ... )

        Create a voice routing policy:

            >>> policy = make_policy(
            ...     policy_type="TeamsVoiceRoutingPolicy",
            ...     policy_name="US-Routing",
            ...     description="Routes calls to US PSTN gateway"
            ... )

        Override via camelCase kwargs:

            >>> policy = make_policy(policyName="CustomPolicy")
            >>> policy.policy_name
            'CustomPolicy'

    Note:
        The factory uses model_validate() so Pydantic field validation is performed.
        Invalid field values will raise pydantic.ValidationError.
    """
    data = {
        "policyType": policy_type,
        "policyName": policy_name,
        "policyId": policy_id,
        "description": description,
        "isGlobal": is_global,
    }
    data.update(kwargs)
    return Policy.model_validate(data)


def make_location(
    *,
    location_id: str = "loc-11111111-1111-1111-1111-111111111111",
    civic_address_id: str = "civic-22222222-2222-2222-2222-222222222222",
    description: str = "Main Office",
    company_name: str | None = "Contoso",
    address: str | None = "123 Main St",
    city: str | None = "Seattle",
    state_or_province: str | None = "WA",
    postal_code: str | None = "98101",
    country_or_region: str | None = "US",
    is_default: bool = True,
    **kwargs: Any,
) -> EmergencyLocation:
    """Create an EmergencyLocation with sensible defaults.

    Creates a valid EmergencyLocation Pydantic model instance representing an
    E911 emergency location for Teams Phone. Defaults to a Seattle office address.

    Args:
        location_id: Unique location identifier (GUID format).
        civic_address_id: Associated civic address ID (GUID format). Multiple
            locations can share the same civic address.
        description: Location description/name (e.g., "Main Office", "Building A").
        company_name: Company name at this location.
        address: Street address.
        city: City name.
        state_or_province: State or province code (e.g., "WA", "CA").
        postal_code: Postal/ZIP code.
        country_or_region: Country or region code (e.g., "US", "CA").
        is_default: Whether this is the default location for the tenant.
        **kwargs: Additional fields passed directly to model_validate. Use camelCase
            API field names (e.g., locationId) to override any field.

    Returns:
        EmergencyLocation: A valid model instance ready for testing.

    Example:
        Basic usage with defaults:

            >>> location = make_location()
            >>> location.description
            'Main Office'
            >>> location.city
            'Seattle'

        Create a non-default location:

            >>> location = make_location(
            ...     description="Portland Office",
            ...     city="Portland",
            ...     state_or_province="OR",
            ...     is_default=False
            ... )

        Create a Canadian location:

            >>> location = make_location(
            ...     description="Toronto Office",
            ...     city="Toronto",
            ...     state_or_province="ON",
            ...     postal_code="M5V 1A1",
            ...     country_or_region="CA"
            ... )

        Override via camelCase kwargs:

            >>> location = make_location(companyName="Fabrikam")
            >>> location.company_name
            'Fabrikam'

    Note:
        The factory uses model_validate() so Pydantic field validation is performed.
        Invalid field values will raise pydantic.ValidationError.
    """
    data = {
        "locationId": location_id,
        "civicAddressId": civic_address_id,
        "description": description,
        "companyName": company_name,
        "address": address,
        "city": city,
        "stateOrProvince": state_or_province,
        "postalCode": postal_code,
        "countryOrRegion": country_or_region,
        "isDefault": is_default,
    }
    data.update(kwargs)
    return EmergencyLocation.model_validate(data)


def make_operation(
    *,
    status: OperationStatus = OperationStatus.SUCCEEDED,
    created_date_time: datetime | None = None,
    id: str | None = None,
    numbers: list[dict[str, Any]] | None = None,
    **kwargs: Any,
) -> AsyncOperation:
    """Create an AsyncOperation with sensible defaults.

    Creates a valid AsyncOperation Pydantic model instance representing an
    asynchronous operation result from Teams Phone API (e.g., number assignment).
    Defaults to a succeeded operation.

    Args:
        status: Overall status of the operation (SUCCEEDED, RUNNING, FAILED).
        created_date_time: When the operation was created. Defaults to
            2025-01-01T12:00:00Z if not specified.
        id: Unique identifier for the operation. Only included if explicitly
            provided (some API responses omit this field).
        numbers: Status of individual phone numbers in the operation. Each dict
            should have "resourceLocation" and "status" keys.
        **kwargs: Additional fields passed directly to model_validate. Use camelCase
            API field names (e.g., createdDateTime) to override any field.

    Returns:
        AsyncOperation: A valid model instance ready for testing.

    Example:
        Basic usage with defaults (succeeded operation):

            >>> operation = make_operation()
            >>> operation.status
            <OperationStatus.SUCCEEDED: 'succeeded'>

        Create a running operation:

            >>> operation = make_operation(status=OperationStatus.RUNNING)
            >>> operation.status
            <OperationStatus.RUNNING: 'running'>

        Create an operation with number results:

            >>> operation = make_operation(
            ...     status=OperationStatus.SUCCEEDED,
            ...     numbers=[
            ...         {"resourceLocation": "/numbers/123", "status": "succeeded"},
            ...         {"resourceLocation": "/numbers/456", "status": "succeeded"}
            ...     ]
            ... )

        Create a failed operation:

            >>> operation = make_operation(
            ...     status=OperationStatus.FAILED,
            ...     numbers=[
            ...         {"resourceLocation": "/numbers/123", "status": "failed"}
            ...     ]
            ... )

        Override via camelCase kwargs:

            >>> from datetime import datetime, timezone
            >>> operation = make_operation(
            ...     createdDateTime=datetime(2025, 6, 15, tzinfo=timezone.utc).isoformat()
            ... )

    Note:
        The factory uses model_validate() so Pydantic field validation is performed.
        Invalid field values will raise pydantic.ValidationError. Both enum instances
        (e.g., OperationStatus.RUNNING) and string values (e.g., "running") are
        accepted for the status field.
    """
    if created_date_time is None:
        created_date_time = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)

    data = {
        "createdDateTime": created_date_time.isoformat(),
        "status": status.value if isinstance(status, OperationStatus) else status,
        "numbers": numbers if numbers is not None else [],
    }
    if id is not None:
        data["id"] = id
    data.update(kwargs)
    return AsyncOperation.model_validate(data)


__all__ = [
    "make_user",
    "make_number",
    "make_policy",
    "make_location",
    "make_operation",
]
