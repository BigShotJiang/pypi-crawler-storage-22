"""CLI integration tests for Teams Phone CLI."""
