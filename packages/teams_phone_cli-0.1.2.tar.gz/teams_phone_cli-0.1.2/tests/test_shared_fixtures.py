"""Smoke tests for conftest.py shared fixtures.

These tests verify that the shared fixtures in tests/conftest.py are
importable, properly typed, and return the expected mock structures.
"""

from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest


class TestMockGraphClient:
    """Tests for mock_graph_client fixture."""

    @pytest.mark.unit
    def test_returns_async_mock(self, mock_graph_client: AsyncMock) -> None:
        """mock_graph_client returns an AsyncMock."""
        assert isinstance(mock_graph_client, AsyncMock)

    @pytest.mark.unit
    def test_supports_async_context_manager_enter(
        self, mock_graph_client: AsyncMock
    ) -> None:
        """mock_graph_client has __aenter__ configured."""
        assert hasattr(mock_graph_client, "__aenter__")
        # __aenter__ should return the mock itself
        assert mock_graph_client.__aenter__.return_value is mock_graph_client

    @pytest.mark.unit
    def test_supports_async_context_manager_exit(
        self, mock_graph_client: AsyncMock
    ) -> None:
        """mock_graph_client has __aexit__ configured."""
        assert hasattr(mock_graph_client, "__aexit__")
        # __aexit__ should return None
        assert mock_graph_client.__aexit__.return_value is None

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_usable_as_async_context_manager(
        self, mock_graph_client: AsyncMock
    ) -> None:
        """mock_graph_client can be used with async with statement."""
        async with mock_graph_client as gc:
            assert gc is mock_graph_client


class TestMockCliInfrastructure:
    """Tests for mock_cli_infrastructure fixture."""

    @pytest.mark.unit
    def test_returns_dict(self, mock_cli_infrastructure: dict[str, Any]) -> None:
        """mock_cli_infrastructure returns a dict."""
        assert isinstance(mock_cli_infrastructure, dict)

    @pytest.mark.unit
    def test_contains_cache_manager(
        self, mock_cli_infrastructure: dict[str, Any]
    ) -> None:
        """mock_cli_infrastructure contains cache_manager key."""
        assert "cache_manager" in mock_cli_infrastructure
        assert isinstance(mock_cli_infrastructure["cache_manager"], MagicMock)

    @pytest.mark.unit
    def test_contains_auth_service(
        self, mock_cli_infrastructure: dict[str, Any]
    ) -> None:
        """mock_cli_infrastructure contains auth_service key."""
        assert "auth_service" in mock_cli_infrastructure
        assert isinstance(mock_cli_infrastructure["auth_service"], MagicMock)

    @pytest.mark.unit
    def test_contains_graph_client(
        self, mock_cli_infrastructure: dict[str, Any]
    ) -> None:
        """mock_cli_infrastructure contains graph_client as AsyncMock."""
        assert "graph_client" in mock_cli_infrastructure
        assert isinstance(mock_cli_infrastructure["graph_client"], AsyncMock)

    @pytest.mark.unit
    def test_graph_client_is_async_context_manager(
        self, mock_cli_infrastructure: dict[str, Any]
    ) -> None:
        """graph_client in infrastructure is configured as async context manager."""
        gc = mock_cli_infrastructure["graph_client"]
        assert gc.__aenter__.return_value is gc
        assert gc.__aexit__.return_value is None


class TestMockNumberService:
    """Tests for mock_number_service fixture."""

    @pytest.mark.unit
    def test_returns_dict(self, mock_number_service: dict[str, Any]) -> None:
        """mock_number_service returns a dict."""
        assert isinstance(mock_number_service, dict)

    @pytest.mark.unit
    def test_contains_infrastructure_keys(
        self, mock_number_service: dict[str, Any]
    ) -> None:
        """mock_number_service includes all infrastructure keys."""
        assert "cache_manager" in mock_number_service
        assert "auth_service" in mock_number_service
        assert "graph_client" in mock_number_service

    @pytest.mark.unit
    def test_contains_number_service(self, mock_number_service: dict[str, Any]) -> None:
        """mock_number_service contains number_service key."""
        assert "number_service" in mock_number_service
        assert isinstance(mock_number_service["number_service"], MagicMock)

    @pytest.mark.unit
    def test_number_service_has_async_methods(
        self, mock_number_service: dict[str, Any]
    ) -> None:
        """number_service mock has AsyncMock methods configured."""
        ns = mock_number_service["number_service"]
        assert isinstance(ns.list_numbers, AsyncMock)
        assert isinstance(ns.get_number, AsyncMock)
        assert isinstance(ns.search_numbers, AsyncMock)
        assert isinstance(ns.assign_number, AsyncMock)
        assert isinstance(ns.unassign_number, AsyncMock)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_number_service_methods_are_awaitable(
        self, mock_number_service: dict[str, Any]
    ) -> None:
        """number_service async methods can be awaited."""
        ns = mock_number_service["number_service"]
        result = await ns.list_numbers()
        assert result == []
