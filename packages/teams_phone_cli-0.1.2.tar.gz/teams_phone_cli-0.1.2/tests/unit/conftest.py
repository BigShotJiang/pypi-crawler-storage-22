"""Pytest fixtures specific to unit tests.

This conftest provides fixtures that override shared fixtures for unit test needs.
Service-level unit tests often need direct mock injection rather than async
context manager configured mocks.
"""

from unittest.mock import MagicMock

import pytest


@pytest.fixture
def mock_auth_service() -> MagicMock:
    """Create a mock AuthService that returns a test token.

    Used by GraphClient tests to provide authentication without real credentials.

    Returns:
        A MagicMock configured to return a test access token.
    """
    mock_service = MagicMock()
    mock_service.get_token.return_value = "test-access-token-12345"
    return mock_service


@pytest.fixture
def mock_graph_client() -> MagicMock:
    """Create a basic MagicMock GraphClient for service-level unit tests.

    This fixture overrides the shared mock_graph_client from tests/conftest.py
    to provide a plain MagicMock suitable for direct injection into services.

    Service-level tests (e.g., UserService, NumberService) typically:
    - Inject the mock directly into service constructors
    - Configure specific methods like get_paginated, get, post
    - Don't need async context manager protocol support

    For CLI-level tests that need async context manager support, use the
    mock_cli_infrastructure or mock_number_service fixtures from the root conftest.

    Returns:
        A basic MagicMock that can be configured for any service method.

    Example:
        def test_service_method(mock_graph_client):
            mock_graph_client.get = AsyncMock(return_value={"data": "value"})
            service = SomeService(mock_graph_client)
            result = await service.some_method()
    """
    return MagicMock()
