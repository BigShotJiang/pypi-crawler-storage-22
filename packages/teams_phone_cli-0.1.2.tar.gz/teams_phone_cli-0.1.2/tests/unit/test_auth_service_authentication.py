"""Unit tests for AuthService authentication methods (login, logout, status)."""

from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import MagicMock, patch
from uuid import UUID

import pytest
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

from teams_phone.exceptions import (
    ConfigurationError,
    NotFoundError,
)
from teams_phone.infrastructure import CacheManager, ConfigManager
from teams_phone.models import AuthMethod, AuthStatusType, CachedToken, TenantProfile
from teams_phone.services import SCOPES, AuthService


def generate_test_certificate(tmp_path: Path) -> tuple[Path, str]:
    """Generate a self-signed certificate and private key for testing.

    Returns:
        Tuple of (certificate path, expected thumbprint uppercase hex).
    """
    # Generate a private key
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )

    # Generate a self-signed certificate
    subject = issuer = x509.Name(
        [
            x509.NameAttribute(NameOID.COUNTRY_NAME, "US"),
            x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, "Washington"),
            x509.NameAttribute(NameOID.LOCALITY_NAME, "Seattle"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Test"),
            x509.NameAttribute(NameOID.COMMON_NAME, "test.example.com"),
        ]
    )

    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(private_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.now(timezone.utc))
        .not_valid_after(datetime.now(timezone.utc) + timedelta(days=365))
        .sign(private_key, hashes.SHA256())
    )

    # Calculate expected thumbprint
    thumbprint = cert.fingerprint(hashes.SHA1()).hex().upper()

    # Serialize to PEM
    cert_pem = cert.public_bytes(serialization.Encoding.PEM)
    key_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )

    # Write combined PEM file
    cert_path = tmp_path / "test_cert.pem"
    cert_path.write_bytes(cert_pem + key_pem)

    return cert_path, thumbprint


class TestIsAuthenticated:
    """Tests for is_authenticated method."""

    @pytest.mark.unit
    def test_returns_true_for_valid_token(self, tmp_path: Path) -> None:
        """is_authenticated returns True when cached token is valid."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path="/path/to/cert.pem",
        )
        config_manager.set_tenant("test-tenant", profile)

        # Cache a valid token
        valid_token = CachedToken(
            access_token="valid-token",
            expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
            tenant_id=str(profile.tenant_id),
            scopes=SCOPES,
        )
        cache_manager.save_token("test-tenant", valid_token)

        assert service.is_authenticated("test-tenant") is True

    @pytest.mark.unit
    def test_returns_false_for_expired_token(self, tmp_path: Path) -> None:
        """is_authenticated returns False when cached token is expired."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path="/path/to/cert.pem",
        )
        config_manager.set_tenant("test-tenant", profile)

        # Cache an expired token
        expired_token = CachedToken(
            access_token="expired-token",
            expires_at=datetime.now(timezone.utc) - timedelta(hours=1),
            tenant_id=str(profile.tenant_id),
            scopes=SCOPES,
        )
        cache_manager.save_token("test-tenant", expired_token)

        assert service.is_authenticated("test-tenant") is False

    @pytest.mark.unit
    def test_returns_false_for_no_token(self, tmp_path: Path) -> None:
        """is_authenticated returns False when no cached token exists."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path="/path/to/cert.pem",
        )
        config_manager.set_tenant("test-tenant", profile)

        # No token cached
        assert service.is_authenticated("test-tenant") is False

    @pytest.mark.unit
    def test_returns_false_for_token_within_buffer(self, tmp_path: Path) -> None:
        """is_authenticated returns False when token is within refresh buffer."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path="/path/to/cert.pem",
        )
        config_manager.set_tenant("test-tenant", profile)

        # Token expires in 2 minutes (within 5-minute buffer)
        near_expiry_token = CachedToken(
            access_token="near-expiry-token",
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=2),
            tenant_id=str(profile.tenant_id),
            scopes=SCOPES,
        )
        cache_manager.save_token("test-tenant", near_expiry_token)

        assert service.is_authenticated("test-tenant") is False

    @pytest.mark.unit
    def test_does_not_throw_for_configuration_error(self, tmp_path: Path) -> None:
        """is_authenticated returns False (not throws) for ConfigurationError."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        # No default tenant, passing None should cause ConfigurationError
        # But is_authenticated should swallow it and return False
        assert service.is_authenticated(None) is False

    @pytest.mark.unit
    def test_does_not_throw_for_not_found_error(self, tmp_path: Path) -> None:
        """is_authenticated returns False (not throws) for NotFoundError."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        # Nonexistent tenant should cause NotFoundError
        # But is_authenticated should swallow it and return False
        assert service.is_authenticated("nonexistent-tenant") is False

    @pytest.mark.unit
    def test_uses_default_tenant_when_none(self, tmp_path: Path) -> None:
        """is_authenticated uses default tenant when tenant_name is None."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        profile = TenantProfile(
            name="default-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Default Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path="/path/to/cert.pem",
        )
        config_manager.set_tenant("default-tenant", profile)
        config_manager.set_default_tenant("default-tenant")

        # Cache a valid token
        valid_token = CachedToken(
            access_token="valid-token",
            expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
            tenant_id=str(profile.tenant_id),
            scopes=SCOPES,
        )
        cache_manager.save_token("default-tenant", valid_token)

        assert service.is_authenticated(None) is True


class TestGetStatus:
    """Tests for get_status method."""

    @pytest.mark.unit
    def test_returns_authenticated_with_details(self, tmp_path: Path) -> None:
        """get_status returns AUTHENTICATED with token details when valid."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path="/path/to/cert.pem",
        )
        config_manager.set_tenant("test-tenant", profile)

        expires_at = datetime.now(timezone.utc) + timedelta(hours=1)
        valid_token = CachedToken(
            access_token="valid-token",
            expires_at=expires_at,
            tenant_id=str(profile.tenant_id),
            scopes=SCOPES,
        )
        cache_manager.save_token("test-tenant", valid_token)

        status = service.get_status("test-tenant")

        assert status.status == AuthStatusType.AUTHENTICATED
        assert status.tenant_name == "test-tenant"
        assert status.tenant_id == str(profile.tenant_id)
        assert status.expires_at == expires_at

    @pytest.mark.unit
    def test_returns_unauthenticated_when_no_token(self, tmp_path: Path) -> None:
        """get_status returns UNAUTHENTICATED when no token exists."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path="/path/to/cert.pem",
        )
        config_manager.set_tenant("test-tenant", profile)

        status = service.get_status("test-tenant")

        assert status.status == AuthStatusType.UNAUTHENTICATED
        assert status.tenant_name == "test-tenant"
        assert status.tenant_id is None
        assert status.expires_at is None

    @pytest.mark.unit
    def test_returns_expired_when_token_expired(self, tmp_path: Path) -> None:
        """get_status returns EXPIRED when token is expired."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path="/path/to/cert.pem",
        )
        config_manager.set_tenant("test-tenant", profile)

        expires_at = datetime.now(timezone.utc) - timedelta(hours=1)
        expired_token = CachedToken(
            access_token="expired-token",
            expires_at=expires_at,
            tenant_id=str(profile.tenant_id),
            scopes=SCOPES,
        )
        cache_manager.save_token("test-tenant", expired_token)

        status = service.get_status("test-tenant")

        assert status.status == AuthStatusType.EXPIRED
        assert status.tenant_name == "test-tenant"
        assert status.tenant_id == str(profile.tenant_id)
        assert status.expires_at == expires_at

    @pytest.mark.unit
    def test_raises_configuration_error_when_no_default(self, tmp_path: Path) -> None:
        """get_status raises ConfigurationError when None and no default set."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        with pytest.raises(ConfigurationError) as exc_info:
            service.get_status(None)

        assert "No tenant specified" in str(exc_info.value)

    @pytest.mark.unit
    def test_raises_not_found_for_unknown_tenant(self, tmp_path: Path) -> None:
        """get_status raises NotFoundError for non-existent tenant."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        with pytest.raises(NotFoundError) as exc_info:
            service.get_status("nonexistent-tenant")

        assert "nonexistent-tenant" in str(exc_info.value)

    @pytest.mark.unit
    def test_uses_default_tenant_when_none(self, tmp_path: Path) -> None:
        """get_status uses default tenant when tenant_name is None."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        profile = TenantProfile(
            name="default-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Default Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path="/path/to/cert.pem",
        )
        config_manager.set_tenant("default-tenant", profile)
        config_manager.set_default_tenant("default-tenant")

        status = service.get_status(None)

        assert status.tenant_name == "default-tenant"


class TestLogin:
    """Tests for login method."""

    @pytest.mark.unit
    def test_returns_cached_token_when_authenticated(self, tmp_path: Path) -> None:
        """login returns cached token when already authenticated."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        cert_path, _ = generate_test_certificate(tmp_path)
        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path=str(cert_path),
        )
        config_manager.set_tenant("test-tenant", profile)

        # Pre-populate with valid token
        valid_token = CachedToken(
            access_token="cached-token",
            expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
            tenant_id=str(profile.tenant_id),
            scopes=SCOPES,
        )
        cache_manager.save_token("test-tenant", valid_token)

        # Should not call MSAL
        with patch(
            "teams_phone.services.auth_service.ConfidentialClientApplication"
        ) as mock_app:
            result = service.login("test-tenant")

            mock_app.assert_not_called()
            assert result.access_token == "cached-token"

    @pytest.mark.unit
    def test_acquires_new_token_when_force_true(self, tmp_path: Path) -> None:
        """login acquires new token when force=True even if authenticated."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        cert_path, _ = generate_test_certificate(tmp_path)
        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path=str(cert_path),
        )
        config_manager.set_tenant("test-tenant", profile)

        # Pre-populate with valid token
        valid_token = CachedToken(
            access_token="old-token",
            expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
            tenant_id=str(profile.tenant_id),
            scopes=SCOPES,
        )
        cache_manager.save_token("test-tenant", valid_token)

        with patch(
            "teams_phone.services.auth_service.ConfidentialClientApplication"
        ) as mock_app:
            mock_instance = MagicMock()
            mock_instance.acquire_token_for_client.return_value = {
                "access_token": "new-forced-token",
                "expires_in": 3600,
            }
            mock_app.return_value = mock_instance

            result = service.login("test-tenant", force=True)

            mock_instance.acquire_token_for_client.assert_called_once()
            assert result.access_token == "new-forced-token"

    @pytest.mark.unit
    def test_acquires_token_when_not_authenticated(self, tmp_path: Path) -> None:
        """login acquires new token when no cached token exists."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        cert_path, _ = generate_test_certificate(tmp_path)
        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path=str(cert_path),
        )
        config_manager.set_tenant("test-tenant", profile)

        with patch(
            "teams_phone.services.auth_service.ConfidentialClientApplication"
        ) as mock_app:
            mock_instance = MagicMock()
            mock_instance.acquire_token_for_client.return_value = {
                "access_token": "fresh-token",
                "expires_in": 3600,
            }
            mock_app.return_value = mock_instance

            result = service.login("test-tenant")

            mock_instance.acquire_token_for_client.assert_called_once()
            assert result.access_token == "fresh-token"

    @pytest.mark.unit
    def test_acquires_token_when_cached_expired(self, tmp_path: Path) -> None:
        """login acquires new token when cached token is expired."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        cert_path, _ = generate_test_certificate(tmp_path)
        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path=str(cert_path),
        )
        config_manager.set_tenant("test-tenant", profile)

        # Pre-populate with expired token
        expired_token = CachedToken(
            access_token="expired-token",
            expires_at=datetime.now(timezone.utc) - timedelta(hours=1),
            tenant_id=str(profile.tenant_id),
            scopes=SCOPES,
        )
        cache_manager.save_token("test-tenant", expired_token)

        with patch(
            "teams_phone.services.auth_service.ConfidentialClientApplication"
        ) as mock_app:
            mock_instance = MagicMock()
            mock_instance.acquire_token_for_client.return_value = {
                "access_token": "new-token",
                "expires_in": 3600,
            }
            mock_app.return_value = mock_instance

            result = service.login("test-tenant")

            mock_instance.acquire_token_for_client.assert_called_once()
            assert result.access_token == "new-token"

    @pytest.mark.unit
    def test_raises_configuration_error_when_no_default(self, tmp_path: Path) -> None:
        """login raises ConfigurationError when None and no default set."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        with pytest.raises(ConfigurationError) as exc_info:
            service.login(None)

        assert "No tenant specified" in str(exc_info.value)

    @pytest.mark.unit
    def test_raises_not_found_for_unknown_tenant(self, tmp_path: Path) -> None:
        """login raises NotFoundError for non-existent tenant."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        with pytest.raises(NotFoundError) as exc_info:
            service.login("nonexistent-tenant")

        assert "nonexistent-tenant" in str(exc_info.value)

    @pytest.mark.unit
    def test_uses_default_tenant_when_none(self, tmp_path: Path) -> None:
        """login uses default tenant when tenant_name is None."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        cert_path, _ = generate_test_certificate(tmp_path)
        profile = TenantProfile(
            name="default-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Default Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path=str(cert_path),
        )
        config_manager.set_tenant("default-tenant", profile)
        config_manager.set_default_tenant("default-tenant")

        # Pre-populate with valid token
        valid_token = CachedToken(
            access_token="default-token",
            expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
            tenant_id=str(profile.tenant_id),
            scopes=SCOPES,
        )
        cache_manager.save_token("default-tenant", valid_token)

        result = service.login(None)

        assert result.access_token == "default-token"


class TestLogout:
    """Tests for logout method."""

    @pytest.mark.unit
    def test_clears_single_tenant_token(self, tmp_path: Path) -> None:
        """logout clears token for specific tenant."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path="/path/to/cert.pem",
        )
        config_manager.set_tenant("test-tenant", profile)

        # Cache a token
        valid_token = CachedToken(
            access_token="token-to-clear",
            expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
            tenant_id=str(profile.tenant_id),
            scopes=SCOPES,
        )
        cache_manager.save_token("test-tenant", valid_token)

        # Verify token exists
        assert cache_manager.get_token("test-tenant") is not None

        service.logout("test-tenant")

        # Verify token was cleared
        assert cache_manager.get_token("test-tenant") is None

    @pytest.mark.unit
    def test_clears_all_tenant_tokens(self, tmp_path: Path) -> None:
        """logout clears all tokens when all_tenants=True."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        # Set up multiple tenants
        for name in ["tenant-1", "tenant-2", "tenant-3"]:
            profile = TenantProfile(
                name=name,
                tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
                client_id=UUID("87654321-4321-4321-4321-210987654321"),
                display_name=name,
                auth_method=AuthMethod.CERTIFICATE,
                cert_path="/path/to/cert.pem",
            )
            config_manager.set_tenant(name, profile)

            token = CachedToken(
                access_token=f"token-{name}",
                expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
                tenant_id=str(profile.tenant_id),
                scopes=SCOPES,
            )
            cache_manager.save_token(name, token)

        # Verify all tokens exist
        for name in ["tenant-1", "tenant-2", "tenant-3"]:
            assert cache_manager.get_token(name) is not None

        service.logout(all_tenants=True)

        # Verify all tokens were cleared
        for name in ["tenant-1", "tenant-2", "tenant-3"]:
            assert cache_manager.get_token(name) is None

    @pytest.mark.unit
    def test_logout_ignores_tenant_name_when_all_tenants_true(
        self, tmp_path: Path
    ) -> None:
        """logout ignores tenant_name parameter when all_tenants=True."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        # Set up a tenant
        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path="/path/to/cert.pem",
        )
        config_manager.set_tenant("test-tenant", profile)

        token = CachedToken(
            access_token="token",
            expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
            tenant_id=str(profile.tenant_id),
            scopes=SCOPES,
        )
        cache_manager.save_token("test-tenant", token)

        # Should not raise NotFoundError even though "nonexistent" doesn't exist
        service.logout(tenant_name="nonexistent", all_tenants=True)

        # Verify token was still cleared
        assert cache_manager.get_token("test-tenant") is None

    @pytest.mark.unit
    def test_raises_configuration_error_when_no_default(self, tmp_path: Path) -> None:
        """logout raises ConfigurationError when None and no default set."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        with pytest.raises(ConfigurationError) as exc_info:
            service.logout(None)

        assert "No tenant specified" in str(exc_info.value)

    @pytest.mark.unit
    def test_raises_not_found_for_unknown_tenant(self, tmp_path: Path) -> None:
        """logout raises NotFoundError for non-existent tenant."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        with pytest.raises(NotFoundError) as exc_info:
            service.logout("nonexistent-tenant")

        assert "nonexistent-tenant" in str(exc_info.value)

    @pytest.mark.unit
    def test_uses_default_tenant_when_none(self, tmp_path: Path) -> None:
        """logout uses default tenant when tenant_name is None."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        profile = TenantProfile(
            name="default-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Default Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path="/path/to/cert.pem",
        )
        config_manager.set_tenant("default-tenant", profile)
        config_manager.set_default_tenant("default-tenant")

        # Cache a token for default tenant
        valid_token = CachedToken(
            access_token="default-token",
            expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
            tenant_id=str(profile.tenant_id),
            scopes=SCOPES,
        )
        cache_manager.save_token("default-tenant", valid_token)

        # Verify token exists
        assert cache_manager.get_token("default-tenant") is not None

        service.logout(None)

        # Verify token was cleared
        assert cache_manager.get_token("default-tenant") is None

    @pytest.mark.unit
    def test_logout_is_idempotent(self, tmp_path: Path) -> None:
        """logout succeeds even if no token exists to clear."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path="/path/to/cert.pem",
        )
        config_manager.set_tenant("test-tenant", profile)

        # No token cached - should not raise
        service.logout("test-tenant")
