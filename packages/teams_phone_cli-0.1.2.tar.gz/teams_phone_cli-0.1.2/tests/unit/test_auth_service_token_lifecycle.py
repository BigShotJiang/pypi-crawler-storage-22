"""Unit tests for AuthService token lifecycle (refresh, get, cache)."""

from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import MagicMock, patch
from uuid import UUID

import pytest
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

from teams_phone.constants import TOKEN_EXPIRY_BUFFER_SECONDS
from teams_phone.exceptions import (
    ConfigurationError,
    NotFoundError,
)
from teams_phone.infrastructure import CacheManager, ConfigManager
from teams_phone.models import AuthMethod, CachedToken, TenantProfile
from teams_phone.services import SCOPES, AuthService


def generate_test_certificate(tmp_path: Path) -> tuple[Path, str]:
    """Generate a self-signed certificate and private key for testing.

    Returns:
        Tuple of (certificate path, expected thumbprint uppercase hex).
    """
    # Generate a private key
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )

    # Generate a self-signed certificate
    subject = issuer = x509.Name(
        [
            x509.NameAttribute(NameOID.COUNTRY_NAME, "US"),
            x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, "Washington"),
            x509.NameAttribute(NameOID.LOCALITY_NAME, "Seattle"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Test"),
            x509.NameAttribute(NameOID.COMMON_NAME, "test.example.com"),
        ]
    )

    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(private_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.now(timezone.utc))
        .not_valid_after(datetime.now(timezone.utc) + timedelta(days=365))
        .sign(private_key, hashes.SHA256())
    )

    # Calculate expected thumbprint
    thumbprint = cert.fingerprint(hashes.SHA1()).hex().upper()

    # Serialize to PEM
    cert_pem = cert.public_bytes(serialization.Encoding.PEM)
    key_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )

    # Write combined PEM file
    cert_path = tmp_path / "test_cert.pem"
    cert_path.write_bytes(cert_pem + key_pem)

    return cert_path, thumbprint


class TestNeedsRefresh:
    """Tests for _needs_refresh method."""

    @pytest.mark.unit
    def test_returns_true_for_expired_token(self, tmp_path: Path) -> None:
        """_needs_refresh returns True when token is expired."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        expired_token = CachedToken(
            access_token="expired-token",
            expires_at=datetime.now(timezone.utc) - timedelta(hours=1),
            tenant_id="12345678-1234-1234-1234-123456789012",
            scopes=SCOPES,
        )

        assert service._needs_refresh(expired_token) is True

    @pytest.mark.unit
    def test_returns_true_for_token_within_buffer(self, tmp_path: Path) -> None:
        """_needs_refresh returns True when token expires within buffer period."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        # Token expires in 2 minutes (less than 5-minute buffer)
        near_expiry_token = CachedToken(
            access_token="near-expiry-token",
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=2),
            tenant_id="12345678-1234-1234-1234-123456789012",
            scopes=SCOPES,
        )

        assert service._needs_refresh(near_expiry_token) is True

    @pytest.mark.unit
    def test_returns_false_for_valid_token(self, tmp_path: Path) -> None:
        """_needs_refresh returns False when token is valid and not near expiry."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        valid_token = CachedToken(
            access_token="valid-token",
            expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
            tenant_id="12345678-1234-1234-1234-123456789012",
            scopes=SCOPES,
        )

        assert service._needs_refresh(valid_token) is False

    @pytest.mark.unit
    def test_handles_naive_datetime(self, tmp_path: Path) -> None:
        """_needs_refresh handles naive datetime by assuming UTC."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        # Create token with naive datetime (no timezone) well in the future
        # Use UTC's concept of "now" + 1 hour to ensure it's valid regardless of local timezone
        utc_now = datetime.now(timezone.utc)
        naive_expires = utc_now.replace(tzinfo=None) + timedelta(hours=1)
        valid_token = CachedToken(
            access_token="valid-token",
            expires_at=naive_expires,
            tenant_id="12345678-1234-1234-1234-123456789012",
            scopes=SCOPES,
        )

        # Should not raise and should return False (valid token)
        assert service._needs_refresh(valid_token) is False

    @pytest.mark.unit
    def test_uses_correct_buffer_value(self, tmp_path: Path) -> None:
        """_needs_refresh uses TOKEN_EXPIRY_BUFFER_SECONDS (300 seconds)."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        # Token expires in exactly 5 minutes - should need refresh
        at_buffer_token = CachedToken(
            access_token="at-buffer-token",
            expires_at=datetime.now(timezone.utc)
            + timedelta(seconds=TOKEN_EXPIRY_BUFFER_SECONDS),
            tenant_id="12345678-1234-1234-1234-123456789012",
            scopes=SCOPES,
        )
        assert service._needs_refresh(at_buffer_token) is True

        # Token expires in 6 minutes - should NOT need refresh
        after_buffer_token = CachedToken(
            access_token="after-buffer-token",
            expires_at=datetime.now(timezone.utc)
            + timedelta(seconds=TOKEN_EXPIRY_BUFFER_SECONDS + 60),
            tenant_id="12345678-1234-1234-1234-123456789012",
            scopes=SCOPES,
        )
        assert service._needs_refresh(after_buffer_token) is False


class TestRefreshToken:
    """Tests for refresh_token method."""

    @pytest.mark.unit
    def test_acquires_and_caches_token(self, tmp_path: Path) -> None:
        """refresh_token acquires token via MSAL and saves to cache."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        cert_path, _ = generate_test_certificate(tmp_path)
        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path=str(cert_path),
        )
        config_manager.set_tenant("test-tenant", profile)

        with patch(
            "teams_phone.services.auth_service.ConfidentialClientApplication"
        ) as mock_app:
            mock_instance = MagicMock()
            mock_instance.acquire_token_for_client.return_value = {
                "access_token": "test-access-token",
                "expires_in": 3600,
            }
            mock_app.return_value = mock_instance

            result = service.refresh_token("test-tenant")

            assert result.access_token == "test-access-token"
            assert result.tenant_id == str(profile.tenant_id)
            assert result.scopes == SCOPES

            # Verify token was cached
            cached = cache_manager.get_token("test-tenant")
            assert cached is not None
            assert cached.access_token == "test-access-token"

    @pytest.mark.unit
    def test_raises_authentication_error_on_msal_failure(self, tmp_path: Path) -> None:
        """refresh_token raises AuthenticationError when MSAL returns error."""
        from teams_phone.exceptions import AuthenticationError

        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        cert_path, _ = generate_test_certificate(tmp_path)
        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path=str(cert_path),
        )
        config_manager.set_tenant("test-tenant", profile)

        with patch(
            "teams_phone.services.auth_service.ConfidentialClientApplication"
        ) as mock_app:
            mock_instance = MagicMock()
            mock_instance.acquire_token_for_client.return_value = {
                "error": "invalid_client",
                "error_description": "The client credentials are invalid",
            }
            mock_app.return_value = mock_instance

            with pytest.raises(AuthenticationError) as exc_info:
                service.refresh_token("test-tenant")

            assert "invalid_client" in str(exc_info.value)
            assert exc_info.value.remediation is not None

    @pytest.mark.unit
    def test_uses_default_tenant_when_none(self, tmp_path: Path) -> None:
        """refresh_token uses default tenant when tenant_name is None."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        cert_path, _ = generate_test_certificate(tmp_path)
        profile = TenantProfile(
            name="default-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Default Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path=str(cert_path),
        )
        config_manager.set_tenant("default-tenant", profile)
        config_manager.set_default_tenant("default-tenant")

        with patch(
            "teams_phone.services.auth_service.ConfidentialClientApplication"
        ) as mock_app:
            mock_instance = MagicMock()
            mock_instance.acquire_token_for_client.return_value = {
                "access_token": "default-token",
                "expires_in": 3600,
            }
            mock_app.return_value = mock_instance

            result = service.refresh_token(None)

            assert result.access_token == "default-token"

            # Verify cached under default tenant name
            cached = cache_manager.get_token("default-tenant")
            assert cached is not None

    @pytest.mark.unit
    def test_calculates_expiration_correctly(self, tmp_path: Path) -> None:
        """refresh_token calculates expiration from expires_in."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        cert_path, _ = generate_test_certificate(tmp_path)
        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path=str(cert_path),
        )
        config_manager.set_tenant("test-tenant", profile)

        before_call = datetime.now(timezone.utc)

        with patch(
            "teams_phone.services.auth_service.ConfidentialClientApplication"
        ) as mock_app:
            mock_instance = MagicMock()
            mock_instance.acquire_token_for_client.return_value = {
                "access_token": "test-token",
                "expires_in": 7200,  # 2 hours
            }
            mock_app.return_value = mock_instance

            result = service.refresh_token("test-tenant")

            after_call = datetime.now(timezone.utc)

            # Expiration should be approximately 2 hours from now
            expected_min = before_call + timedelta(seconds=7200)
            expected_max = after_call + timedelta(seconds=7200)

            assert result.expires_at >= expected_min
            assert result.expires_at <= expected_max

    @pytest.mark.unit
    def test_handles_invalid_grant_error(self, tmp_path: Path) -> None:
        """refresh_token provides specific remediation for invalid_grant."""
        from teams_phone.exceptions import AuthenticationError

        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        cert_path, _ = generate_test_certificate(tmp_path)
        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path=str(cert_path),
        )
        config_manager.set_tenant("test-tenant", profile)

        with patch(
            "teams_phone.services.auth_service.ConfidentialClientApplication"
        ) as mock_app:
            mock_instance = MagicMock()
            mock_instance.acquire_token_for_client.return_value = {
                "error": "invalid_grant",
                "error_description": "AADSTS65001: The user or administrator has not consented",
            }
            mock_app.return_value = mock_instance

            with pytest.raises(AuthenticationError) as exc_info:
                service.refresh_token("test-tenant")

            assert "invalid_grant" in str(exc_info.value)
            assert exc_info.value.remediation is not None
            assert "admin consent" in exc_info.value.remediation.lower()


class TestGetToken:
    """Tests for get_token method."""

    @pytest.mark.unit
    def test_returns_cached_token_when_valid(self, tmp_path: Path) -> None:
        """get_token returns cached token when it's still valid."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        cert_path, _ = generate_test_certificate(tmp_path)
        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path=str(cert_path),
        )
        config_manager.set_tenant("test-tenant", profile)

        # Pre-populate cache with valid token
        valid_token = CachedToken(
            access_token="cached-valid-token",
            expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
            tenant_id=str(profile.tenant_id),
            scopes=SCOPES,
        )
        cache_manager.save_token("test-tenant", valid_token)

        # Should not call MSAL
        with patch(
            "teams_phone.services.auth_service.ConfidentialClientApplication"
        ) as mock_app:
            result = service.get_token("test-tenant")

            mock_app.assert_not_called()
            assert result == "cached-valid-token"

    @pytest.mark.unit
    def test_refreshes_expired_token(self, tmp_path: Path) -> None:
        """get_token refreshes token when cached token is expired."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        cert_path, _ = generate_test_certificate(tmp_path)
        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path=str(cert_path),
        )
        config_manager.set_tenant("test-tenant", profile)

        # Pre-populate cache with expired token
        expired_token = CachedToken(
            access_token="expired-token",
            expires_at=datetime.now(timezone.utc) - timedelta(hours=1),
            tenant_id=str(profile.tenant_id),
            scopes=SCOPES,
        )
        cache_manager.save_token("test-tenant", expired_token)

        with patch(
            "teams_phone.services.auth_service.ConfidentialClientApplication"
        ) as mock_app:
            mock_instance = MagicMock()
            mock_instance.acquire_token_for_client.return_value = {
                "access_token": "new-access-token",
                "expires_in": 3600,
            }
            mock_app.return_value = mock_instance

            result = service.get_token("test-tenant")

            assert result == "new-access-token"
            mock_instance.acquire_token_for_client.assert_called_once()

    @pytest.mark.unit
    def test_refreshes_token_within_buffer(self, tmp_path: Path) -> None:
        """get_token refreshes token when within buffer period."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        cert_path, _ = generate_test_certificate(tmp_path)
        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path=str(cert_path),
        )
        config_manager.set_tenant("test-tenant", profile)

        # Pre-populate cache with token expiring in 2 minutes (within 5-min buffer)
        near_expiry_token = CachedToken(
            access_token="near-expiry-token",
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=2),
            tenant_id=str(profile.tenant_id),
            scopes=SCOPES,
        )
        cache_manager.save_token("test-tenant", near_expiry_token)

        with patch(
            "teams_phone.services.auth_service.ConfidentialClientApplication"
        ) as mock_app:
            mock_instance = MagicMock()
            mock_instance.acquire_token_for_client.return_value = {
                "access_token": "proactively-refreshed-token",
                "expires_in": 3600,
            }
            mock_app.return_value = mock_instance

            result = service.get_token("test-tenant")

            assert result == "proactively-refreshed-token"
            mock_instance.acquire_token_for_client.assert_called_once()

    @pytest.mark.unit
    def test_acquires_token_when_no_cache(self, tmp_path: Path) -> None:
        """get_token acquires new token when no cached token exists."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        cert_path, _ = generate_test_certificate(tmp_path)
        profile = TenantProfile(
            name="test-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Test Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path=str(cert_path),
        )
        config_manager.set_tenant("test-tenant", profile)

        with patch(
            "teams_phone.services.auth_service.ConfidentialClientApplication"
        ) as mock_app:
            mock_instance = MagicMock()
            mock_instance.acquire_token_for_client.return_value = {
                "access_token": "fresh-token",
                "expires_in": 3600,
            }
            mock_app.return_value = mock_instance

            result = service.get_token("test-tenant")

            assert result == "fresh-token"
            mock_instance.acquire_token_for_client.assert_called_once()

    @pytest.mark.unit
    def test_uses_default_tenant_when_none(self, tmp_path: Path) -> None:
        """get_token uses default tenant when tenant_name is None."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        cert_path, _ = generate_test_certificate(tmp_path)
        profile = TenantProfile(
            name="default-tenant",
            tenant_id=UUID("12345678-1234-1234-1234-123456789012"),
            client_id=UUID("87654321-4321-4321-4321-210987654321"),
            display_name="Default Tenant",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path=str(cert_path),
        )
        config_manager.set_tenant("default-tenant", profile)
        config_manager.set_default_tenant("default-tenant")

        # Pre-populate cache with valid token for default tenant
        valid_token = CachedToken(
            access_token="default-tenant-token",
            expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
            tenant_id=str(profile.tenant_id),
            scopes=SCOPES,
        )
        cache_manager.save_token("default-tenant", valid_token)

        result = service.get_token(None)

        assert result == "default-tenant-token"

    @pytest.mark.unit
    def test_raises_configuration_error_when_no_default(self, tmp_path: Path) -> None:
        """get_token raises ConfigurationError when None and no default set."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        with pytest.raises(ConfigurationError) as exc_info:
            service.get_token(None)

        assert "No tenant specified" in str(exc_info.value)

    @pytest.mark.unit
    def test_raises_not_found_for_unknown_tenant(self, tmp_path: Path) -> None:
        """get_token raises NotFoundError for non-existent tenant."""
        config_manager = ConfigManager(config_path=str(tmp_path / "config.toml"))
        cache_manager = CacheManager(token_dir=str(tmp_path / "tokens"))
        service = AuthService(config_manager, cache_manager)

        with pytest.raises(NotFoundError) as exc_info:
            service.get_token("nonexistent-tenant")

        assert "nonexistent-tenant" in str(exc_info.value)
