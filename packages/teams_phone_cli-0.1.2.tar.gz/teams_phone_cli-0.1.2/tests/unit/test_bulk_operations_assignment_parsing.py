"""Unit tests for bulk_operations assignment CSV parsing."""

from pathlib import Path

import pytest

from teams_phone.exceptions import ValidationError

# Import infrastructure first to avoid circular import
# (graph_client imports auth_service which imports infrastructure)
from teams_phone.infrastructure import GraphClient  # noqa: F401
from teams_phone.services.bulk_operations import parse_assign_csv


# Sample CSV content for assignment tests
VALID_CSV = """user,phone_number,location
user1@contoso.com,+14255551234,loc-001
user2@contoso.com,+14255555678,loc-002"""

VALID_CSV_NO_LOCATION = """user,phone_number
user1@contoso.com,+14255551234
user2@contoso.com,+14255555678"""

VALID_CSV_WITH_BOM = (
    "\ufeffuser,phone_number,location\nuser1@contoso.com,+14255551234,loc-001"
)

EMPTY_REQUIRED_FIELDS_CSV = """user,phone_number,location
,+14255551234,loc-001
user2@contoso.com,,loc-002
,,loc-003"""

EMPTY_LOCATION_CSV = """user,phone_number,location
user1@contoso.com,+14255551234,
user2@contoso.com,+14255555678,"""

MISSING_USER_COLUMN_CSV = """phone_number,location
+14255551234,loc-001"""

MISSING_PHONE_COLUMN_CSV = """user,location
user1@contoso.com,loc-001"""

MISSING_BOTH_COLUMNS_CSV = """location,other
loc-001,value"""

HEADER_ONLY_CSV = """user,phone_number,location"""

EMPTY_FILE_CSV = ""


class TestParseAssignCsv:
    """Tests for parse_assign_csv function."""

    @pytest.mark.unit
    def test_parses_valid_csv_with_all_columns(self, tmp_path: Path) -> None:
        """parse_assign_csv parses CSV with all columns correctly."""
        csv_file = tmp_path / "bulk.csv"
        csv_file.write_text(VALID_CSV, encoding="utf-8")

        rows = parse_assign_csv(csv_file)

        assert len(rows) == 2
        assert rows[0].row_number == 2
        assert rows[0].user == "user1@contoso.com"
        assert rows[0].phone_number == "+14255551234"
        assert rows[0].location == "loc-001"
        assert rows[0].errors == []
        assert rows[0].warnings == []

        assert rows[1].row_number == 3
        assert rows[1].user == "user2@contoso.com"
        assert rows[1].phone_number == "+14255555678"
        assert rows[1].location == "loc-002"

    @pytest.mark.unit
    def test_parses_csv_without_location_column(self, tmp_path: Path) -> None:
        """parse_assign_csv handles CSV without optional location column."""
        csv_file = tmp_path / "bulk.csv"
        csv_file.write_text(VALID_CSV_NO_LOCATION, encoding="utf-8")

        rows = parse_assign_csv(csv_file)

        assert len(rows) == 2
        assert rows[0].location is None
        assert rows[0].warnings == []  # No warning when column doesn't exist

    @pytest.mark.unit
    def test_handles_utf8_bom(self, tmp_path: Path) -> None:
        """parse_assign_csv handles UTF-8 BOM from PowerShell exports."""
        csv_file = tmp_path / "bulk.csv"
        csv_file.write_text(VALID_CSV_WITH_BOM, encoding="utf-8")

        rows = parse_assign_csv(csv_file)

        assert len(rows) == 1
        assert rows[0].user == "user1@contoso.com"

    @pytest.mark.unit
    def test_collects_errors_for_empty_required_fields(self, tmp_path: Path) -> None:
        """parse_assign_csv collects errors when required fields are empty."""
        csv_file = tmp_path / "bulk.csv"
        csv_file.write_text(EMPTY_REQUIRED_FIELDS_CSV, encoding="utf-8")

        rows = parse_assign_csv(csv_file)

        assert len(rows) == 3
        # Row 2: missing user
        assert "Missing required field: user" in rows[0].errors
        assert "Missing required field: phone_number" not in rows[0].errors

        # Row 3: missing phone_number
        assert "Missing required field: phone_number" in rows[1].errors
        assert "Missing required field: user" not in rows[1].errors

        # Row 4: missing both
        assert "Missing required field: user" in rows[2].errors
        assert "Missing required field: phone_number" in rows[2].errors

    @pytest.mark.unit
    def test_generates_warning_for_empty_location(self, tmp_path: Path) -> None:
        """parse_assign_csv generates warning when location column is empty."""
        csv_file = tmp_path / "bulk.csv"
        csv_file.write_text(EMPTY_LOCATION_CSV, encoding="utf-8")

        rows = parse_assign_csv(csv_file)

        assert len(rows) == 2
        assert "Empty optional field: location" in rows[0].warnings
        assert "Empty optional field: location" in rows[1].warnings
        assert rows[0].location is None
        assert rows[1].location is None

    @pytest.mark.unit
    def test_raises_validation_error_missing_user_column(self, tmp_path: Path) -> None:
        """parse_assign_csv raises ValidationError when user column missing."""
        csv_file = tmp_path / "bulk.csv"
        csv_file.write_text(MISSING_USER_COLUMN_CSV, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_assign_csv(csv_file)

        assert "user" in str(exc_info.value)
        assert exc_info.value.remediation is not None

    @pytest.mark.unit
    def test_raises_validation_error_missing_phone_column(self, tmp_path: Path) -> None:
        """parse_assign_csv raises ValidationError when phone_number column missing."""
        csv_file = tmp_path / "bulk.csv"
        csv_file.write_text(MISSING_PHONE_COLUMN_CSV, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_assign_csv(csv_file)

        assert "phone_number" in str(exc_info.value)
        assert exc_info.value.remediation is not None

    @pytest.mark.unit
    def test_raises_validation_error_missing_both_required_columns(
        self, tmp_path: Path
    ) -> None:
        """parse_assign_csv raises ValidationError when both required columns missing."""
        csv_file = tmp_path / "bulk.csv"
        csv_file.write_text(MISSING_BOTH_COLUMNS_CSV, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_assign_csv(csv_file)

        assert "phone_number" in str(exc_info.value)
        assert "user" in str(exc_info.value)

    @pytest.mark.unit
    def test_returns_empty_list_for_header_only_csv(self, tmp_path: Path) -> None:
        """parse_assign_csv returns empty list when CSV has only header."""
        csv_file = tmp_path / "bulk.csv"
        csv_file.write_text(HEADER_ONLY_CSV, encoding="utf-8")

        rows = parse_assign_csv(csv_file)

        assert rows == []

    @pytest.mark.unit
    def test_raises_validation_error_for_empty_file(self, tmp_path: Path) -> None:
        """parse_assign_csv raises ValidationError for empty file."""
        csv_file = tmp_path / "bulk.csv"
        csv_file.write_text(EMPTY_FILE_CSV, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_assign_csv(csv_file)

        assert "empty" in str(exc_info.value).lower()

    @pytest.mark.unit
    def test_raises_validation_error_for_missing_file(self, tmp_path: Path) -> None:
        """parse_assign_csv raises ValidationError when file doesn't exist."""
        csv_file = tmp_path / "nonexistent.csv"

        with pytest.raises(ValidationError) as exc_info:
            parse_assign_csv(csv_file)

        assert "not found" in str(exc_info.value).lower()
        assert exc_info.value.remediation is not None

    @pytest.mark.unit
    def test_row_numbers_are_1_indexed(self, tmp_path: Path) -> None:
        """parse_assign_csv uses 1-indexed row numbers starting after header."""
        csv_file = tmp_path / "bulk.csv"
        csv_file.write_text(VALID_CSV, encoding="utf-8")

        rows = parse_assign_csv(csv_file)

        # Header is row 1, data starts at row 2
        assert rows[0].row_number == 2
        assert rows[1].row_number == 3

    @pytest.mark.unit
    def test_strips_whitespace_from_values(self, tmp_path: Path) -> None:
        """parse_assign_csv strips leading/trailing whitespace from values."""
        csv_content = """user,phone_number,location
  user1@contoso.com  ,  +14255551234  ,  loc-001  """
        csv_file = tmp_path / "bulk.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        rows = parse_assign_csv(csv_file)

        assert rows[0].user == "user1@contoso.com"
        assert rows[0].phone_number == "+14255551234"
        assert rows[0].location == "loc-001"
