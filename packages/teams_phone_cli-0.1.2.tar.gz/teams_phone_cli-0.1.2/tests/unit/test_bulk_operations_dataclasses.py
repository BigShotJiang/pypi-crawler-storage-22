"""Unit tests for bulk_operations dataclasses."""

import pytest

# Import infrastructure first to avoid circular import
# (graph_client imports auth_service which imports infrastructure)
from teams_phone.infrastructure import GraphClient  # noqa: F401
from teams_phone.services.bulk_operations import (
    BulkAssignResult,
    BulkAssignRow,
    BulkPolicyResult,
    BulkPolicyRow,
    BulkPolicyValidationResult,
    BulkValidationResult,
)


class TestBulkAssignRow:
    """Tests for BulkAssignRow dataclass."""

    @pytest.mark.unit
    def test_dataclass_creates_with_all_fields(self) -> None:
        """BulkAssignRow stores all provided fields."""
        row = BulkAssignRow(
            row_number=2,
            user="user@contoso.com",
            phone_number="+14255551234",
            location="loc-001",
            errors=["error1"],
            warnings=["warning1"],
        )

        assert row.row_number == 2
        assert row.user == "user@contoso.com"
        assert row.phone_number == "+14255551234"
        assert row.location == "loc-001"
        assert row.errors == ["error1"]
        assert row.warnings == ["warning1"]

    @pytest.mark.unit
    def test_dataclass_default_empty_lists(self) -> None:
        """BulkAssignRow defaults errors and warnings to empty lists."""
        row = BulkAssignRow(
            row_number=2,
            user="user@contoso.com",
            phone_number="+14255551234",
            location=None,
        )

        assert row.errors == []
        assert row.warnings == []

    @pytest.mark.unit
    def test_dataclass_mutable_defaults_independent(self) -> None:
        """BulkAssignRow instances have independent error/warning lists."""
        row1 = BulkAssignRow(
            row_number=2,
            user="user1@contoso.com",
            phone_number="+14255551234",
            location=None,
        )
        row2 = BulkAssignRow(
            row_number=3,
            user="user2@contoso.com",
            phone_number="+14255555678",
            location=None,
        )

        row1.errors.append("error for row1")

        assert row1.errors == ["error for row1"]
        assert row2.errors == []


class TestBulkValidationResult:
    """Tests for BulkValidationResult dataclass."""

    @pytest.mark.unit
    def test_dataclass_creates_with_all_fields(self) -> None:
        """BulkValidationResult stores all provided fields."""
        rows = [
            BulkAssignRow(
                row_number=2,
                user="user@contoso.com",
                phone_number="+14255551234",
                location=None,
            )
        ]
        result = BulkValidationResult(
            rows=rows,
            valid_count=1,
            error_count=0,
            warning_count=0,
        )

        assert result.rows == rows
        assert result.valid_count == 1
        assert result.error_count == 0
        assert result.warning_count == 0


class TestBulkAssignResult:
    """Tests for BulkAssignResult dataclass."""

    @pytest.mark.unit
    def test_dataclass_creates_with_all_fields(self) -> None:
        """BulkAssignResult stores all provided fields."""
        result = BulkAssignResult(
            row_number=2,
            user="user@contoso.com",
            phone_number="+14255551234",
            status="success",
            error="Some error",
        )

        assert result.row_number == 2
        assert result.user == "user@contoso.com"
        assert result.phone_number == "+14255551234"
        assert result.status == "success"
        assert result.error == "Some error"

    @pytest.mark.unit
    def test_dataclass_default_error_none(self) -> None:
        """BulkAssignResult defaults error to None."""
        result = BulkAssignResult(
            row_number=2,
            user="user@contoso.com",
            phone_number="+14255551234",
            status="success",
        )

        assert result.error is None

    @pytest.mark.unit
    def test_dataclass_accepts_different_statuses(self) -> None:
        """BulkAssignResult accepts success, failed, and skipped statuses."""
        success = BulkAssignResult(
            row_number=2,
            user="user1@contoso.com",
            phone_number="+14255551234",
            status="success",
        )
        failed = BulkAssignResult(
            row_number=3,
            user="user2@contoso.com",
            phone_number="+14255555678",
            status="failed",
            error="User not found",
        )
        skipped = BulkAssignResult(
            row_number=4,
            user="user3@contoso.com",
            phone_number="+14255559999",
            status="skipped",
            error="Missing required field",
        )

        assert success.status == "success"
        assert failed.status == "failed"
        assert skipped.status == "skipped"


class TestBulkPolicyRow:
    """Tests for BulkPolicyRow dataclass."""

    @pytest.mark.unit
    def test_dataclass_creates_with_all_fields(self) -> None:
        """BulkPolicyRow stores all provided fields."""
        row = BulkPolicyRow(
            row_number=2,
            user="user@contoso.com",
            policy_type="TeamsCallingPolicy",
            policy_name="AllowCalling",
            errors=["error1"],
            warnings=["warning1"],
        )

        assert row.row_number == 2
        assert row.user == "user@contoso.com"
        assert row.policy_type == "TeamsCallingPolicy"
        assert row.policy_name == "AllowCalling"
        assert row.errors == ["error1"]
        assert row.warnings == ["warning1"]

    @pytest.mark.unit
    def test_dataclass_default_empty_lists(self) -> None:
        """BulkPolicyRow defaults errors and warnings to empty lists."""
        row = BulkPolicyRow(
            row_number=2,
            user="user@contoso.com",
            policy_type="TeamsCallingPolicy",
            policy_name="AllowCalling",
        )

        assert row.errors == []
        assert row.warnings == []

    @pytest.mark.unit
    def test_dataclass_mutable_defaults_independent(self) -> None:
        """BulkPolicyRow instances have independent error/warning lists."""
        row1 = BulkPolicyRow(
            row_number=2,
            user="user1@contoso.com",
            policy_type="TeamsCallingPolicy",
            policy_name="Policy1",
        )
        row2 = BulkPolicyRow(
            row_number=3,
            user="user2@contoso.com",
            policy_type="TenantDialPlan",
            policy_name="Policy2",
        )

        row1.errors.append("error for row1")

        assert row1.errors == ["error for row1"]
        assert row2.errors == []


class TestBulkPolicyValidationResult:
    """Tests for BulkPolicyValidationResult dataclass."""

    @pytest.mark.unit
    def test_dataclass_creates_with_all_fields(self) -> None:
        """BulkPolicyValidationResult stores all provided fields."""
        rows = [
            BulkPolicyRow(
                row_number=2,
                user="user@contoso.com",
                policy_type="TeamsCallingPolicy",
                policy_name="AllowCalling",
            )
        ]
        result = BulkPolicyValidationResult(
            rows=rows,
            valid_count=1,
            error_count=0,
            warning_count=0,
        )

        assert result.rows == rows
        assert result.valid_count == 1
        assert result.error_count == 0
        assert result.warning_count == 0


class TestBulkPolicyResult:
    """Tests for BulkPolicyResult dataclass."""

    @pytest.mark.unit
    def test_dataclass_creates_with_all_fields(self) -> None:
        """BulkPolicyResult stores all provided fields."""
        result = BulkPolicyResult(
            row_number=2,
            user="user@contoso.com",
            policy_type="TeamsCallingPolicy",
            policy_name="AllowCalling",
            status="success",
            error="Some error",
        )

        assert result.row_number == 2
        assert result.user == "user@contoso.com"
        assert result.policy_type == "TeamsCallingPolicy"
        assert result.policy_name == "AllowCalling"
        assert result.status == "success"
        assert result.error == "Some error"

    @pytest.mark.unit
    def test_dataclass_default_error_none(self) -> None:
        """BulkPolicyResult defaults error to None."""
        result = BulkPolicyResult(
            row_number=2,
            user="user@contoso.com",
            policy_type="TeamsCallingPolicy",
            policy_name="AllowCalling",
            status="success",
        )

        assert result.error is None

    @pytest.mark.unit
    def test_dataclass_accepts_different_statuses(self) -> None:
        """BulkPolicyResult accepts success, failed, and skipped statuses."""
        success = BulkPolicyResult(
            row_number=2,
            user="user1@contoso.com",
            policy_type="TeamsCallingPolicy",
            policy_name="Policy1",
            status="success",
        )
        failed = BulkPolicyResult(
            row_number=3,
            user="user2@contoso.com",
            policy_type="TenantDialPlan",
            policy_name="Policy2",
            status="failed",
            error="Policy not found",
        )
        skipped = BulkPolicyResult(
            row_number=4,
            user="user3@contoso.com",
            policy_type="TeamsEmergencyCallingPolicy",
            policy_name="Policy3",
            status="skipped",
            error="Missing required field",
        )

        assert success.status == "success"
        assert failed.status == "failed"
        assert skipped.status == "skipped"
