"""Unit tests for bulk_operations CSV output functions."""

from pathlib import Path
from unittest.mock import patch

import pytest

from teams_phone.exceptions import ConfigurationError

# Import infrastructure first to avoid circular import
# (graph_client imports auth_service which imports infrastructure)
from teams_phone.infrastructure import GraphClient  # noqa: F401
from teams_phone.services.bulk_operations import (
    BulkAssignResult,
    BulkPolicyResult,
    write_policy_results_csv,
    write_results_csv,
)


class TestWriteResultsCsv:
    """Tests for write_results_csv function."""

    @pytest.mark.unit
    def test_writes_valid_results_file(self, tmp_path: Path) -> None:
        """write_results_csv creates a valid CSV file with results."""
        output_file = tmp_path / "results.csv"
        results = [
            BulkAssignResult(
                row_number=2,
                user="user1@contoso.com",
                phone_number="+14255551234",
                status="success",
            ),
            BulkAssignResult(
                row_number=3,
                user="user2@contoso.com",
                phone_number="+14255555678",
                status="failed",
                error="User not found",
            ),
        ]

        write_results_csv(results, output_file)

        assert output_file.exists()
        content = output_file.read_text(encoding="utf-8")
        lines = content.strip().split("\n")

        assert len(lines) == 3  # Header + 2 data rows
        assert lines[0] == "row,user,phone_number,status,error"
        assert lines[1] == "2,user1@contoso.com,+14255551234,success,"
        assert lines[2] == "3,user2@contoso.com,+14255555678,failed,User not found"

    @pytest.mark.unit
    def test_writes_utf8_without_bom(self, tmp_path: Path) -> None:
        """write_results_csv writes UTF-8 without BOM."""
        output_file = tmp_path / "results.csv"
        results = [
            BulkAssignResult(
                row_number=2,
                user="user@contoso.com",
                phone_number="+14255551234",
                status="success",
            )
        ]

        write_results_csv(results, output_file)

        # Read raw bytes and check for BOM
        raw_content = output_file.read_bytes()
        assert not raw_content.startswith(b"\xef\xbb\xbf")  # UTF-8 BOM
        assert raw_content.startswith(b"row,")

    @pytest.mark.unit
    def test_creates_parent_directory(self, tmp_path: Path) -> None:
        """write_results_csv creates parent directories if they don't exist."""
        output_file = tmp_path / "nested" / "output" / "results.csv"
        results = [
            BulkAssignResult(
                row_number=2,
                user="user@contoso.com",
                phone_number="+14255551234",
                status="success",
            )
        ]

        write_results_csv(results, output_file)

        assert output_file.exists()
        assert output_file.parent.exists()

    @pytest.mark.unit
    def test_permission_error_on_mkdir_raises_configuration_error(
        self, tmp_path: Path
    ) -> None:
        """write_results_csv raises ConfigurationError on permission failure for mkdir."""
        output_file = tmp_path / "restricted" / "results.csv"
        results = [
            BulkAssignResult(
                row_number=2,
                user="user@contoso.com",
                phone_number="+14255551234",
                status="success",
            )
        ]

        with (
            patch.object(Path, "mkdir", side_effect=PermissionError("Access denied")),
            pytest.raises(ConfigurationError) as exc_info,
        ):
            write_results_csv(results, output_file)

        assert "Cannot create output directory" in str(exc_info.value)
        assert exc_info.value.remediation is not None

    @pytest.mark.unit
    def test_permission_error_on_write_raises_configuration_error(
        self, tmp_path: Path
    ) -> None:
        """write_results_csv raises ConfigurationError on write permission failure."""
        output_file = tmp_path / "results.csv"
        results = [
            BulkAssignResult(
                row_number=2,
                user="user@contoso.com",
                phone_number="+14255551234",
                status="success",
            )
        ]

        with (
            patch.object(Path, "open", side_effect=PermissionError("Access denied")),
            pytest.raises(ConfigurationError) as exc_info,
        ):
            write_results_csv(results, output_file)

        assert "Cannot write to output file" in str(exc_info.value)
        assert exc_info.value.remediation is not None

    @pytest.mark.unit
    def test_handles_empty_results_list(self, tmp_path: Path) -> None:
        """write_results_csv handles empty results list."""
        output_file = tmp_path / "results.csv"
        results: list[BulkAssignResult] = []

        write_results_csv(results, output_file)

        assert output_file.exists()
        content = output_file.read_text(encoding="utf-8")
        lines = content.strip().split("\n")

        assert len(lines) == 1  # Only header
        assert lines[0] == "row,user,phone_number,status,error"

    @pytest.mark.unit
    def test_multiple_errors_formatting(self, tmp_path: Path) -> None:
        """write_results_csv preserves semicolon-delimited error messages."""
        output_file = tmp_path / "results.csv"
        results = [
            BulkAssignResult(
                row_number=2,
                user="user@contoso.com",
                phone_number="+14255551234",
                status="failed",
                error="User not found; Number not in inventory",
            )
        ]

        write_results_csv(results, output_file)

        content = output_file.read_text(encoding="utf-8")
        lines = content.strip().split("\n")

        assert "User not found; Number not in inventory" in lines[1]

    @pytest.mark.unit
    def test_field_ordering_consistent(self, tmp_path: Path) -> None:
        """write_results_csv maintains consistent field ordering."""
        output_file = tmp_path / "results.csv"
        results = [
            BulkAssignResult(
                row_number=2,
                user="user@contoso.com",
                phone_number="+14255551234",
                status="skipped",
                error="Missing required field",
            )
        ]

        write_results_csv(results, output_file)

        content = output_file.read_text(encoding="utf-8")
        lines = content.strip().split("\n")

        # Verify header order
        assert lines[0] == "row,user,phone_number,status,error"
        # Verify data order matches header
        parts = lines[1].split(",")
        assert parts[0] == "2"  # row
        assert parts[1] == "user@contoso.com"  # user
        assert parts[2] == "+14255551234"  # phone_number
        assert parts[3] == "skipped"  # status
        assert parts[4] == "Missing required field"  # error


class TestWritePolicyResultsCsv:
    """Tests for write_policy_results_csv function."""

    @pytest.mark.unit
    def test_writes_valid_results_file(self, tmp_path: Path) -> None:
        """write_policy_results_csv creates a valid CSV file with results."""
        output_file = tmp_path / "results.csv"
        results = [
            BulkPolicyResult(
                row_number=2,
                user="user1@contoso.com",
                policy_type="TeamsCallingPolicy",
                policy_name="AllowCalling",
                status="success",
            ),
            BulkPolicyResult(
                row_number=3,
                user="user2@contoso.com",
                policy_type="TenantDialPlan",
                policy_name="US-DialPlan",
                status="failed",
                error="Policy not found",
            ),
        ]

        write_policy_results_csv(results, output_file)

        assert output_file.exists()
        content = output_file.read_text(encoding="utf-8")
        lines = content.strip().split("\n")

        assert len(lines) == 3  # Header + 2 data rows
        assert lines[0] == "row,user,policy_type,policy_name,status,error"
        assert (
            lines[1] == "2,user1@contoso.com,TeamsCallingPolicy,AllowCalling,success,"
        )
        assert (
            lines[2]
            == "3,user2@contoso.com,TenantDialPlan,US-DialPlan,failed,Policy not found"
        )

    @pytest.mark.unit
    def test_writes_utf8_without_bom(self, tmp_path: Path) -> None:
        """write_policy_results_csv writes UTF-8 without BOM."""
        output_file = tmp_path / "results.csv"
        results = [
            BulkPolicyResult(
                row_number=2,
                user="user@contoso.com",
                policy_type="TeamsCallingPolicy",
                policy_name="AllowCalling",
                status="success",
            )
        ]

        write_policy_results_csv(results, output_file)

        # Read raw bytes and check for BOM
        raw_content = output_file.read_bytes()
        assert not raw_content.startswith(b"\xef\xbb\xbf")  # UTF-8 BOM
        assert raw_content.startswith(b"row,")

    @pytest.mark.unit
    def test_creates_parent_directory(self, tmp_path: Path) -> None:
        """write_policy_results_csv creates parent directories if they don't exist."""
        output_file = tmp_path / "nested" / "output" / "results.csv"
        results = [
            BulkPolicyResult(
                row_number=2,
                user="user@contoso.com",
                policy_type="TeamsCallingPolicy",
                policy_name="AllowCalling",
                status="success",
            )
        ]

        write_policy_results_csv(results, output_file)

        assert output_file.exists()
        assert output_file.parent.exists()

    @pytest.mark.unit
    def test_handles_empty_results_list(self, tmp_path: Path) -> None:
        """write_policy_results_csv handles empty results list."""
        output_file = tmp_path / "results.csv"
        results: list[BulkPolicyResult] = []

        write_policy_results_csv(results, output_file)

        assert output_file.exists()
        content = output_file.read_text(encoding="utf-8")
        lines = content.strip().split("\n")

        assert len(lines) == 1  # Only header
        assert lines[0] == "row,user,policy_type,policy_name,status,error"
