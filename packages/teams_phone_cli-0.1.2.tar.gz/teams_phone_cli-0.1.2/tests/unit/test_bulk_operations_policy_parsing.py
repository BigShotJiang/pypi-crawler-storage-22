"""Unit tests for bulk_operations policy CSV parsing."""

from pathlib import Path

import pytest

from teams_phone.exceptions import ValidationError

# Import infrastructure first to avoid circular import
# (graph_client imports auth_service which imports infrastructure)
from teams_phone.infrastructure import GraphClient  # noqa: F401
from teams_phone.services.bulk_operations import parse_policy_csv


# Sample CSV content for policy tests
VALID_POLICY_CSV = """user,policy_type,policy_name
user1@contoso.com,calling,AllowCalling
user2@contoso.com,dial-plan,US-DialPlan"""

VALID_POLICY_CSV_WITH_BOM = (
    "\ufeffuser,policy_type,policy_name\nuser1@contoso.com,calling,AllowCalling"
)

EMPTY_POLICY_FIELDS_CSV = """user,policy_type,policy_name
,calling,AllowCalling
user2@contoso.com,,US-DialPlan
user3@contoso.com,dial-plan,"""

MISSING_POLICY_USER_COLUMN_CSV = """policy_type,policy_name
calling,AllowCalling"""

MISSING_POLICY_TYPE_COLUMN_CSV = """user,policy_name
user@contoso.com,AllowCalling"""

MISSING_POLICY_NAME_COLUMN_CSV = """user,policy_type
user@contoso.com,calling"""

HEADER_ONLY_POLICY_CSV = """user,policy_type,policy_name"""

EMPTY_POLICY_FILE_CSV = ""


class TestParsePolicyCsv:
    """Tests for parse_policy_csv function."""

    @pytest.mark.unit
    def test_parses_valid_csv_with_all_columns(self, tmp_path: Path) -> None:
        """parse_policy_csv parses CSV with all columns correctly."""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(VALID_POLICY_CSV, encoding="utf-8")

        rows = parse_policy_csv(csv_file)

        assert len(rows) == 2
        assert rows[0].row_number == 2
        assert rows[0].user == "user1@contoso.com"
        assert rows[0].policy_type == "calling"
        assert rows[0].policy_name == "AllowCalling"
        assert rows[0].errors == []
        assert rows[0].warnings == []

        assert rows[1].row_number == 3
        assert rows[1].user == "user2@contoso.com"
        assert rows[1].policy_type == "dial-plan"
        assert rows[1].policy_name == "US-DialPlan"

    @pytest.mark.unit
    def test_handles_utf8_bom(self, tmp_path: Path) -> None:
        """parse_policy_csv handles UTF-8 BOM from PowerShell exports."""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(VALID_POLICY_CSV_WITH_BOM, encoding="utf-8")

        rows = parse_policy_csv(csv_file)

        assert len(rows) == 1
        assert rows[0].user == "user1@contoso.com"

    @pytest.mark.unit
    def test_collects_errors_for_empty_required_fields(self, tmp_path: Path) -> None:
        """parse_policy_csv collects errors when required fields are empty."""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(EMPTY_POLICY_FIELDS_CSV, encoding="utf-8")

        rows = parse_policy_csv(csv_file)

        assert len(rows) == 3
        # Row 2: missing user
        assert "Missing required field: user" in rows[0].errors
        assert len(rows[0].errors) == 1

        # Row 3: missing policy_type
        assert "Missing required field: policy_type" in rows[1].errors
        assert len(rows[1].errors) == 1

        # Row 4: missing policy_name
        assert "Missing required field: policy_name" in rows[2].errors
        assert len(rows[2].errors) == 1

    @pytest.mark.unit
    def test_raises_validation_error_missing_user_column(self, tmp_path: Path) -> None:
        """parse_policy_csv raises ValidationError when user column missing."""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(MISSING_POLICY_USER_COLUMN_CSV, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_policy_csv(csv_file)

        assert "user" in str(exc_info.value)
        assert exc_info.value.remediation is not None

    @pytest.mark.unit
    def test_raises_validation_error_missing_policy_type_column(
        self, tmp_path: Path
    ) -> None:
        """parse_policy_csv raises ValidationError when policy_type column missing."""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(MISSING_POLICY_TYPE_COLUMN_CSV, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_policy_csv(csv_file)

        assert "policy_type" in str(exc_info.value)
        assert exc_info.value.remediation is not None

    @pytest.mark.unit
    def test_raises_validation_error_missing_policy_name_column(
        self, tmp_path: Path
    ) -> None:
        """parse_policy_csv raises ValidationError when policy_name column missing."""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(MISSING_POLICY_NAME_COLUMN_CSV, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_policy_csv(csv_file)

        assert "policy_name" in str(exc_info.value)
        assert exc_info.value.remediation is not None

    @pytest.mark.unit
    def test_returns_empty_list_for_header_only_csv(self, tmp_path: Path) -> None:
        """parse_policy_csv returns empty list when CSV has only header."""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(HEADER_ONLY_POLICY_CSV, encoding="utf-8")

        rows = parse_policy_csv(csv_file)

        assert rows == []

    @pytest.mark.unit
    def test_raises_validation_error_for_empty_file(self, tmp_path: Path) -> None:
        """parse_policy_csv raises ValidationError for empty file."""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(EMPTY_POLICY_FILE_CSV, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_policy_csv(csv_file)

        assert "empty" in str(exc_info.value).lower()

    @pytest.mark.unit
    def test_raises_validation_error_for_missing_file(self, tmp_path: Path) -> None:
        """parse_policy_csv raises ValidationError when file doesn't exist."""
        csv_file = tmp_path / "nonexistent.csv"

        with pytest.raises(ValidationError) as exc_info:
            parse_policy_csv(csv_file)

        assert "not found" in str(exc_info.value).lower()
        assert exc_info.value.remediation is not None

    @pytest.mark.unit
    def test_row_numbers_are_1_indexed(self, tmp_path: Path) -> None:
        """parse_policy_csv uses 1-indexed row numbers starting after header."""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(VALID_POLICY_CSV, encoding="utf-8")

        rows = parse_policy_csv(csv_file)

        # Header is row 1, data starts at row 2
        assert rows[0].row_number == 2
        assert rows[1].row_number == 3

    @pytest.mark.unit
    def test_strips_whitespace_from_values(self, tmp_path: Path) -> None:
        """parse_policy_csv strips leading/trailing whitespace from values."""
        csv_content = """user,policy_type,policy_name
  user1@contoso.com  ,  calling  ,  AllowCalling  """
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        rows = parse_policy_csv(csv_file)

        assert rows[0].user == "user1@contoso.com"
        assert rows[0].policy_type == "calling"
        assert rows[0].policy_name == "AllowCalling"
