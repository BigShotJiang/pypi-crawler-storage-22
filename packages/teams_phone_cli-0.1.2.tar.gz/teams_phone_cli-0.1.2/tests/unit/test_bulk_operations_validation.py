"""Unit tests for bulk_operations validation logic."""

from unittest.mock import AsyncMock, MagicMock

import pytest

from teams_phone.exceptions import NotFoundError, ValidationError

# Import infrastructure first to avoid circular import
# (graph_client imports auth_service which imports infrastructure)
from teams_phone.infrastructure import GraphClient  # noqa: F401
from teams_phone.models import AssignmentStatus, NumberType
from teams_phone.services.bulk_operations import (
    BulkAssignRow,
    BulkOperations,
)


def make_number_assignment(
    phone_number: str = "+14255551234",
    assignment_status: AssignmentStatus = AssignmentStatus.UNASSIGNED,
    number_type: NumberType = NumberType.DIRECT_ROUTING,
) -> MagicMock:
    """Create a mock NumberAssignment for testing."""
    number = MagicMock()
    number.telephone_number = phone_number
    number.assignment_status = assignment_status
    number.number_type = number_type
    return number


@pytest.fixture
def mock_user_service() -> MagicMock:
    """Create a mock UserService for testing."""
    service = MagicMock()
    service.resolve_user = AsyncMock()
    return service


@pytest.fixture
def mock_number_service() -> MagicMock:
    """Create a mock NumberService for testing."""
    service = MagicMock()
    service.get_number = AsyncMock()
    return service


@pytest.fixture
def mock_location_service() -> MagicMock:
    """Create a mock LocationService for testing."""
    service = MagicMock()
    service.validate_location = MagicMock()
    service.is_cache_stale = MagicMock(return_value=False)
    return service


class TestBulkOperations:
    """Tests for BulkOperations class."""

    @pytest.mark.unit
    def test_init_stores_services(
        self,
        mock_user_service: MagicMock,
        mock_number_service: MagicMock,
        mock_location_service: MagicMock,
    ) -> None:
        """BulkOperations stores injected services."""
        ops = BulkOperations(
            mock_user_service, mock_number_service, mock_location_service
        )

        assert ops.user_service is mock_user_service
        assert ops.number_service is mock_number_service
        assert ops.location_service is mock_location_service


class TestValidateAssignCsv:
    """Tests for BulkOperations.validate_assign_csv method."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_valid_row_passes_validation(
        self,
        mock_user_service: MagicMock,
        mock_number_service: MagicMock,
        mock_location_service: MagicMock,
    ) -> None:
        """validate_assign_csv passes valid rows without errors."""
        mock_user_service.resolve_user.return_value = MagicMock()
        mock_number_service.get_number.return_value = make_number_assignment()

        ops = BulkOperations(
            mock_user_service, mock_number_service, mock_location_service
        )
        rows = [
            BulkAssignRow(
                row_number=2,
                user="user@contoso.com",
                phone_number="+14255551234",
                location="loc-001",
            )
        ]

        result = await ops.validate_assign_csv(rows)

        assert result.valid_count == 1
        assert result.error_count == 0
        assert rows[0].errors == []

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_user_not_found_adds_error(
        self,
        mock_user_service: MagicMock,
        mock_number_service: MagicMock,
        mock_location_service: MagicMock,
    ) -> None:
        """validate_assign_csv adds error when user not found."""
        mock_user_service.resolve_user.side_effect = NotFoundError(
            "User 'unknown@contoso.com' not found"
        )
        mock_number_service.get_number.return_value = make_number_assignment()

        ops = BulkOperations(
            mock_user_service, mock_number_service, mock_location_service
        )
        rows = [
            BulkAssignRow(
                row_number=2,
                user="unknown@contoso.com",
                phone_number="+14255551234",
                location=None,
            )
        ]

        result = await ops.validate_assign_csv(rows)

        assert result.error_count == 1
        assert result.valid_count == 0
        assert "User 'unknown@contoso.com' not found" in rows[0].errors

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_ambiguous_user_adds_error(
        self,
        mock_user_service: MagicMock,
        mock_number_service: MagicMock,
        mock_location_service: MagicMock,
    ) -> None:
        """validate_assign_csv adds error for ambiguous user match."""
        mock_user_service.resolve_user.side_effect = ValidationError(
            "Multiple users match 'John'"
        )
        mock_number_service.get_number.return_value = make_number_assignment()

        ops = BulkOperations(
            mock_user_service, mock_number_service, mock_location_service
        )
        rows = [
            BulkAssignRow(
                row_number=2,
                user="John",
                phone_number="+14255551234",
                location=None,
            )
        ]

        result = await ops.validate_assign_csv(rows)

        assert result.error_count == 1
        assert any("Ambiguous user" in err for err in rows[0].errors)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_number_already_assigned_adds_error(
        self,
        mock_user_service: MagicMock,
        mock_number_service: MagicMock,
        mock_location_service: MagicMock,
    ) -> None:
        """validate_assign_csv adds error when number is already assigned."""
        mock_user_service.resolve_user.return_value = MagicMock()
        mock_number_service.get_number.return_value = make_number_assignment(
            assignment_status=AssignmentStatus.USER_ASSIGNED
        )

        ops = BulkOperations(
            mock_user_service, mock_number_service, mock_location_service
        )
        rows = [
            BulkAssignRow(
                row_number=2,
                user="user@contoso.com",
                phone_number="+14255551234",
                location=None,
            )
        ]

        result = await ops.validate_assign_csv(rows)

        assert result.error_count == 1
        assert "already assigned" in rows[0].errors[0]

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_number_not_in_inventory_adds_error(
        self,
        mock_user_service: MagicMock,
        mock_number_service: MagicMock,
        mock_location_service: MagicMock,
    ) -> None:
        """validate_assign_csv adds error when number not in inventory."""
        mock_user_service.resolve_user.return_value = MagicMock()
        mock_number_service.get_number.side_effect = NotFoundError(
            "Phone number '+14255551234' not found"
        )

        ops = BulkOperations(
            mock_user_service, mock_number_service, mock_location_service
        )
        rows = [
            BulkAssignRow(
                row_number=2,
                user="user@contoso.com",
                phone_number="+14255551234",
                location=None,
            )
        ]

        result = await ops.validate_assign_csv(rows)

        assert result.error_count == 1
        assert "not in inventory" in rows[0].errors[0]

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_invalid_location_adds_error(
        self,
        mock_user_service: MagicMock,
        mock_number_service: MagicMock,
        mock_location_service: MagicMock,
    ) -> None:
        """validate_assign_csv adds error for invalid location."""
        mock_user_service.resolve_user.return_value = MagicMock()
        mock_number_service.get_number.return_value = make_number_assignment()
        mock_location_service.validate_location.side_effect = NotFoundError(
            "Location 'invalid-loc' not found"
        )

        ops = BulkOperations(
            mock_user_service, mock_number_service, mock_location_service
        )
        rows = [
            BulkAssignRow(
                row_number=2,
                user="user@contoso.com",
                phone_number="+14255551234",
                location="invalid-loc",
            )
        ]

        result = await ops.validate_assign_csv(rows)

        assert result.error_count == 1
        assert "Location 'invalid-loc' not found" in rows[0].errors

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_stale_cache_adds_warning(
        self,
        mock_user_service: MagicMock,
        mock_number_service: MagicMock,
        mock_location_service: MagicMock,
    ) -> None:
        """validate_assign_csv adds warning when location cache is stale."""
        mock_user_service.resolve_user.return_value = MagicMock()
        mock_number_service.get_number.return_value = make_number_assignment()
        mock_location_service.is_cache_stale.return_value = True

        ops = BulkOperations(
            mock_user_service, mock_number_service, mock_location_service
        )
        rows = [
            BulkAssignRow(
                row_number=2,
                user="user@contoso.com",
                phone_number="+14255551234",
                location="loc-001",
            )
        ]

        result = await ops.validate_assign_csv(rows)

        assert result.warning_count == 1
        assert any("cache is stale" in w for w in rows[0].warnings)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_calling_plan_without_location_adds_warning(
        self,
        mock_user_service: MagicMock,
        mock_number_service: MagicMock,
        mock_location_service: MagicMock,
    ) -> None:
        """validate_assign_csv warns about Calling Plan numbers without location."""
        mock_user_service.resolve_user.return_value = MagicMock()
        mock_number_service.get_number.return_value = make_number_assignment(
            number_type=NumberType.CALLING_PLAN
        )

        ops = BulkOperations(
            mock_user_service, mock_number_service, mock_location_service
        )
        rows = [
            BulkAssignRow(
                row_number=2,
                user="user@contoso.com",
                phone_number="+14255551234",
                location=None,
            )
        ]

        result = await ops.validate_assign_csv(rows)

        assert result.warning_count == 1
        assert any("Calling Plan" in w for w in rows[0].warnings)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_skips_validation_for_rows_with_parsing_errors(
        self,
        mock_user_service: MagicMock,
        mock_number_service: MagicMock,
        mock_location_service: MagicMock,
    ) -> None:
        """validate_assign_csv skips rows that already have parsing errors."""
        ops = BulkOperations(
            mock_user_service, mock_number_service, mock_location_service
        )
        rows = [
            BulkAssignRow(
                row_number=2,
                user="",
                phone_number="+14255551234",
                location=None,
                errors=["Missing required field: user"],
            )
        ]

        result = await ops.validate_assign_csv(rows)

        # Should not call any services for rows with errors
        mock_user_service.resolve_user.assert_not_called()
        mock_number_service.get_number.assert_not_called()
        assert result.error_count == 1
        assert result.valid_count == 0

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_counts_computed_correctly(
        self,
        mock_user_service: MagicMock,
        mock_number_service: MagicMock,
        mock_location_service: MagicMock,
    ) -> None:
        """validate_assign_csv computes valid, error, and warning counts correctly."""
        mock_user_service.resolve_user.return_value = MagicMock()

        # First call succeeds (unassigned), second fails (not found)
        mock_number_service.get_number.side_effect = [
            make_number_assignment(number_type=NumberType.CALLING_PLAN),
            NotFoundError("Not found"),
            make_number_assignment(),
        ]

        ops = BulkOperations(
            mock_user_service, mock_number_service, mock_location_service
        )
        rows = [
            # Valid but has warning (Calling Plan without location)
            BulkAssignRow(
                row_number=2,
                user="user1@contoso.com",
                phone_number="+14255551234",
                location=None,
            ),
            # Error: number not in inventory
            BulkAssignRow(
                row_number=3,
                user="user2@contoso.com",
                phone_number="+14255555678",
                location=None,
            ),
            # Valid with no warnings
            BulkAssignRow(
                row_number=4,
                user="user3@contoso.com",
                phone_number="+14255559999",
                location="loc-001",
            ),
        ]

        result = await ops.validate_assign_csv(rows)

        assert result.valid_count == 2  # Row 1 and 3 (no errors)
        assert result.error_count == 1  # Row 2 (number not found)
        assert result.warning_count == 1  # Row 1 (Calling Plan without location)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_multiple_errors_per_row(
        self,
        mock_user_service: MagicMock,
        mock_number_service: MagicMock,
        mock_location_service: MagicMock,
    ) -> None:
        """validate_assign_csv can collect multiple errors per row."""
        mock_user_service.resolve_user.side_effect = NotFoundError("User not found")
        mock_number_service.get_number.side_effect = NotFoundError("Number not found")
        mock_location_service.validate_location.side_effect = NotFoundError(
            "Location not found"
        )

        ops = BulkOperations(
            mock_user_service, mock_number_service, mock_location_service
        )
        rows = [
            BulkAssignRow(
                row_number=2,
                user="unknown@contoso.com",
                phone_number="+14255551234",
                location="invalid-loc",
            )
        ]

        result = await ops.validate_assign_csv(rows)

        # Should have 3 errors: user, number, and location
        assert len(rows[0].errors) == 3
        assert result.error_count == 1  # Still one row with errors

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_empty_rows_returns_zero_counts(
        self,
        mock_user_service: MagicMock,
        mock_number_service: MagicMock,
        mock_location_service: MagicMock,
    ) -> None:
        """validate_assign_csv handles empty row list."""
        ops = BulkOperations(
            mock_user_service, mock_number_service, mock_location_service
        )
        rows: list[BulkAssignRow] = []

        result = await ops.validate_assign_csv(rows)

        assert result.valid_count == 0
        assert result.error_count == 0
        assert result.warning_count == 0
        assert result.rows == []

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_location_not_validated_when_none(
        self,
        mock_user_service: MagicMock,
        mock_number_service: MagicMock,
        mock_location_service: MagicMock,
    ) -> None:
        """validate_assign_csv does not validate location when not provided."""
        mock_user_service.resolve_user.return_value = MagicMock()
        mock_number_service.get_number.return_value = make_number_assignment()

        ops = BulkOperations(
            mock_user_service, mock_number_service, mock_location_service
        )
        rows = [
            BulkAssignRow(
                row_number=2,
                user="user@contoso.com",
                phone_number="+14255551234",
                location=None,
            )
        ]

        await ops.validate_assign_csv(rows)

        mock_location_service.validate_location.assert_not_called()
