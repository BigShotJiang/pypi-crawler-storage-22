"""Unit tests for CLI helpers module."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import typer

from teams_phone.cli.context import CLIContext
from teams_phone.cli.helpers import run_with_service
from teams_phone.exceptions import TeamsPhoneError


class DummyService:
    """Dummy service for testing."""

    def __init__(self, graph_client: Any) -> None:
        """Initialize with graph client."""
        self.graph_client = graph_client

    async def do_work(self) -> str:
        """Dummy async operation."""
        return "result"


def _make_mock_context() -> typer.Context:
    """Create a mock Typer context with CLIContext."""
    mock_config_manager = MagicMock()
    mock_output_formatter = MagicMock()

    cli_ctx = CLIContext(verbose=False, json_output=False)
    cli_ctx.config_manager = mock_config_manager
    cli_ctx.output_formatter = mock_output_formatter

    mock_typer_ctx = MagicMock(spec=typer.Context)
    mock_typer_ctx.obj = cli_ctx

    return mock_typer_ctx


class TestRunWithService:
    """Tests for run_with_service helper."""

    @pytest.mark.unit
    def test_returns_result_and_formatter(self) -> None:
        """run_with_service returns tuple of (result, formatter)."""
        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            ctx = _make_mock_context()
            result, formatter = run_with_service(
                ctx,
                service_factory=DummyService,
                operation=lambda svc: svc.do_work(),
            )

            assert result == "result"
            assert formatter is ctx.obj.output_formatter

    @pytest.mark.unit
    def test_creates_graph_client_with_auth_service(self) -> None:
        """run_with_service creates GraphClient with AuthService."""
        with (
            patch("teams_phone.cli.helpers.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.helpers.AuthService") as mock_auth_class,
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            ctx = _make_mock_context()
            run_with_service(
                ctx,
                service_factory=DummyService,
                operation=lambda svc: svc.do_work(),
            )

            mock_cm_class.assert_called_once_with()
            mock_auth_class.assert_called_once_with(
                ctx.obj.config_manager, mock_cm_class.return_value
            )
            mock_gc_class.assert_called_once_with(mock_auth_class.return_value)

    @pytest.mark.unit
    def test_calls_service_factory_with_graph_client(self) -> None:
        """run_with_service calls service_factory with GraphClient."""
        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            service_factory = MagicMock(return_value=MagicMock())
            service_factory.return_value.do_work = AsyncMock(return_value="test")

            ctx = _make_mock_context()
            run_with_service(
                ctx,
                service_factory=service_factory,
                operation=lambda svc: svc.do_work(),
            )

            service_factory.assert_called_once_with(mock_gc)

    @pytest.mark.unit
    def test_calls_operation_with_service(self) -> None:
        """run_with_service calls operation with the created service."""
        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_service = MagicMock()
            mock_service.do_work = AsyncMock(return_value="operation_result")
            service_factory = MagicMock(return_value=mock_service)

            ctx = _make_mock_context()
            result, _ = run_with_service(
                ctx,
                service_factory=service_factory,
                operation=lambda svc: svc.do_work(),
            )

            mock_service.do_work.assert_called_once()
            assert result == "operation_result"

    @pytest.mark.unit
    def test_propagates_teams_phone_error(self) -> None:
        """run_with_service propagates TeamsPhoneError from operation."""
        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_service = MagicMock()
            mock_service.fail = AsyncMock(side_effect=TeamsPhoneError("test error"))
            service_factory = MagicMock(return_value=mock_service)

            ctx = _make_mock_context()
            with pytest.raises(TeamsPhoneError, match="test error"):
                run_with_service(
                    ctx,
                    service_factory=service_factory,
                    operation=lambda svc: svc.fail(),
                )

    @pytest.mark.unit
    def test_closes_graph_client_on_success(self) -> None:
        """run_with_service closes GraphClient via async context manager on success."""
        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            ctx = _make_mock_context()
            run_with_service(
                ctx,
                service_factory=DummyService,
                operation=lambda svc: svc.do_work(),
            )

            mock_gc.__aenter__.assert_called_once()
            mock_gc.__aexit__.assert_called_once()

    @pytest.mark.unit
    def test_closes_graph_client_on_error(self) -> None:
        """run_with_service closes GraphClient via async context manager on error."""
        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_service = MagicMock()
            mock_service.fail = AsyncMock(side_effect=ValueError("boom"))
            service_factory = MagicMock(return_value=mock_service)

            ctx = _make_mock_context()
            with pytest.raises(ValueError, match="boom"):
                run_with_service(
                    ctx,
                    service_factory=service_factory,
                    operation=lambda svc: svc.fail(),
                )

            mock_gc.__aenter__.assert_called_once()
            mock_gc.__aexit__.assert_called_once()

    @pytest.mark.unit
    def test_works_with_complex_return_types(self) -> None:
        """run_with_service works with complex return types from operation."""
        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            expected_result = {"users": [{"id": "1"}, {"id": "2"}], "count": 2}
            mock_service = MagicMock()
            mock_service.get_data = AsyncMock(return_value=expected_result)
            service_factory = MagicMock(return_value=mock_service)

            ctx = _make_mock_context()
            result, _ = run_with_service(
                ctx,
                service_factory=service_factory,
                operation=lambda svc: svc.get_data(),
            )

            assert result == expected_result
