"""Unit tests for CLI numbers assign command."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.exceptions import NotFoundError
from teams_phone.models import OperationStatus
from tests.conftest import CliRunner
from tests.fixtures import make_location, make_operation, make_user


runner = CliRunner()


class TestNumbersAssignCommand:
    """Tests for numbers assign command."""

    @pytest.mark.unit
    def test_assign_shows_in_help(self) -> None:
        """assign command appears in numbers help."""
        result = runner.invoke(app, ["numbers", "--help"])
        assert result.exit_code == 0
        assert "assign" in result.stdout

    @pytest.mark.unit
    def test_assign_requires_user_argument(self) -> None:
        """assign requires user argument."""
        result = runner.invoke(app, ["numbers", "assign"])
        assert result.exit_code == 2
        output = result.stdout + (result.stderr or "")
        assert "USER" in output or "Missing argument" in output or result.exit_code == 2

    @pytest.mark.unit
    def test_assign_requires_number_argument(self) -> None:
        """assign requires number argument."""
        result = runner.invoke(app, ["numbers", "assign", "john@contoso.com"])
        assert result.exit_code == 2
        output = result.stdout + (result.stderr or "")
        assert (
            "NUMBER" in output or "Missing argument" in output or result.exit_code == 2
        )

    @pytest.mark.unit
    def test_assign_dry_run_shows_preview(self) -> None:
        """assign --dry-run shows preview without executing."""
        mock_user = make_user(
            id="user-123",
            user_principal_name="john@contoso.com",
            display_name="John Smith",
        )
        mock_location = make_location(location_id="loc-123", description="Seattle HQ")

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService") as mock_ls_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(return_value=mock_user)
            mock_us_class.return_value = mock_user_service

            mock_location_service = MagicMock()
            mock_location_service.validate_location = MagicMock(
                return_value=mock_location
            )
            mock_ls_class.return_value = mock_location_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "assign",
                    "john@contoso.com",
                    "+14255551234",
                    "--location",
                    "Seattle HQ",
                    "--dry-run",
                ],
            )
            assert result.exit_code == 0
            assert "Dry Run Preview" in result.stdout
            assert "John Smith" in result.stdout
            # Phone numbers may have ANSI escape codes
            assert "14255551234" in result.stdout
            assert "Seattle HQ" in result.stdout
            assert "No changes made" in result.stdout

    @pytest.mark.unit
    def test_assign_dry_run_json_output(self) -> None:
        """assign --dry-run --json outputs valid JSON."""
        mock_user = make_user(
            id="user-123",
            user_principal_name="john@contoso.com",
            display_name="John Smith",
        )
        mock_location = make_location(location_id="loc-123", description="Seattle HQ")

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService") as mock_ls_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(return_value=mock_user)
            mock_us_class.return_value = mock_user_service

            mock_location_service = MagicMock()
            mock_location_service.validate_location = MagicMock(
                return_value=mock_location
            )
            mock_ls_class.return_value = mock_location_service

            result = runner.invoke(
                app,
                [
                    "--json",
                    "numbers",
                    "assign",
                    "john@contoso.com",
                    "+14255551234",
                    "--location",
                    "Seattle HQ",
                    "--dry-run",
                ],
            )
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data["dry_run"] is True
            assert data["user_id"] == "user-123"
            assert data["user_principal_name"] == "john@contoso.com"
            assert data["phone_number"] == "+14255551234"
            assert data["number_type"] == "callingPlan"
            assert data["location_id"] == "loc-123"
            assert data["location_description"] == "Seattle HQ"

    @pytest.mark.unit
    def test_assign_calling_plan_without_location_fails(self) -> None:
        """assign Calling Plan number without location shows error."""
        mock_user = make_user(
            id="user-123",
            user_principal_name="john@contoso.com",
            display_name="John Smith",
        )
        mock_tenant = MagicMock()
        mock_tenant.default_location = None  # No default location

        # Create a mock config manager with get_default_tenant and get_tenant
        mock_config_manager = MagicMock()
        mock_config_manager.get_default_tenant = MagicMock(return_value="test-tenant")
        mock_config_manager.get_tenant = MagicMock(return_value=mock_tenant)

        # Create a mock CLIContext that returns our mock config_manager
        mock_cli_ctx = MagicMock()
        mock_cli_ctx.json_output = False
        mock_cli_ctx.get_config_manager = MagicMock(return_value=mock_config_manager)
        mock_cli_ctx.get_output_formatter = MagicMock(return_value=MagicMock())

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService"),
            patch("teams_phone.cli.numbers.get_context", return_value=mock_cli_ctx),
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(return_value=mock_user)
            mock_us_class.return_value = mock_user_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "assign",
                    "john@contoso.com",
                    "+14255551234",
                    "--force",
                ],
            )
            # ValidationError exit code - message goes to mock formatter
            assert result.exit_code == 5

    @pytest.mark.unit
    def test_assign_direct_routing_without_location_succeeds(self) -> None:
        """assign Direct Routing number without location succeeds."""
        mock_user = make_user(
            id="user-123",
            user_principal_name="john@contoso.com",
            display_name="John Smith",
        )
        mock_operation = make_operation(id="op-123", status=OperationStatus.SUCCEEDED)

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
            patch("teams_phone.cli.numbers.LocationService"),
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(return_value=mock_user)
            mock_us_class.return_value = mock_user_service

            mock_number_service = MagicMock()
            mock_number_service.assign_number = AsyncMock(return_value=mock_operation)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "assign",
                    "john@contoso.com",
                    "+14255551234",
                    "--type",
                    "directRouting",
                    "--force",
                ],
            )
            assert result.exit_code == 0
            assert "Assigned" in result.stdout

    @pytest.mark.unit
    def test_assign_success_json_output(self) -> None:
        """assign success outputs valid JSON."""
        mock_user = make_user(
            id="user-123",
            user_principal_name="john@contoso.com",
            display_name="John Smith",
        )
        mock_location = make_location(location_id="loc-123", description="Seattle HQ")
        mock_operation = make_operation(id="op-123", status=OperationStatus.SUCCEEDED)

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
            patch("teams_phone.cli.numbers.LocationService") as mock_ls_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(return_value=mock_user)
            mock_us_class.return_value = mock_user_service

            mock_location_service = MagicMock()
            mock_location_service.validate_location = MagicMock(
                return_value=mock_location
            )
            mock_ls_class.return_value = mock_location_service

            mock_number_service = MagicMock()
            mock_number_service.assign_number = AsyncMock(return_value=mock_operation)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                [
                    "--json",
                    "numbers",
                    "assign",
                    "john@contoso.com",
                    "+14255551234",
                    "--location",
                    "Seattle HQ",
                ],
            )
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data["status"] == "succeeded"
            assert data["user_id"] == "user-123"
            assert data["phone_number"] == "+14255551234"

    @pytest.mark.unit
    def test_assign_with_confirmation_cancelled(self) -> None:
        """assign cancelled by confirmation prompt exits gracefully."""
        mock_user = make_user(
            id="user-123",
            user_principal_name="john@contoso.com",
            display_name="John Smith",
        )
        mock_location = make_location(location_id="loc-123", description="Seattle HQ")

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService") as mock_ls_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(return_value=mock_user)
            mock_us_class.return_value = mock_user_service

            mock_location_service = MagicMock()
            mock_location_service.validate_location = MagicMock(
                return_value=mock_location
            )
            mock_ls_class.return_value = mock_location_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "assign",
                    "john@contoso.com",
                    "+14255551234",
                    "--location",
                    "Seattle HQ",
                ],
                input="n\n",  # Decline confirmation
            )
            assert result.exit_code == 0
            assert "cancelled" in result.stdout

    @pytest.mark.unit
    def test_assign_no_wait_shows_operation_id(self) -> None:
        """assign --no-wait shows operation ID."""
        mock_user = make_user(
            id="user-123",
            user_principal_name="john@contoso.com",
            display_name="John Smith",
        )
        mock_location = make_location(location_id="loc-123", description="Seattle HQ")
        mock_operation = make_operation(id="op-123", status=OperationStatus.NOT_STARTED)

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
            patch("teams_phone.cli.numbers.LocationService") as mock_ls_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(return_value=mock_user)
            mock_us_class.return_value = mock_user_service

            mock_location_service = MagicMock()
            mock_location_service.validate_location = MagicMock(
                return_value=mock_location
            )
            mock_ls_class.return_value = mock_location_service

            mock_number_service = MagicMock()
            mock_number_service.assign_number = AsyncMock(return_value=mock_operation)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "assign",
                    "john@contoso.com",
                    "+14255551234",
                    "--location",
                    "Seattle HQ",
                    "--force",
                    "--no-wait",
                ],
            )
            assert result.exit_code == 0
            # Operation ID may have ANSI escape codes
            assert "op-" in result.stdout
            assert "123" in result.stdout
            assert "initiated" in result.stdout

    @pytest.mark.unit
    def test_assign_user_not_found(self) -> None:
        """assign with unknown user shows error."""
        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService"),
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(
                side_effect=NotFoundError(
                    "User 'unknown@contoso.com' not found",
                    remediation="Verify the user exists.",
                )
            )
            mock_us_class.return_value = mock_user_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "assign",
                    "unknown@contoso.com",
                    "+14255551234",
                    "--type",
                    "directRouting",
                    "--force",
                ],
            )
            assert result.exit_code == 4  # NotFoundError exit code
            assert "not found" in result.stdout

    @pytest.mark.unit
    def test_assign_failed_operation_exits_with_error(self) -> None:
        """assign with failed operation exits with error code."""
        mock_user = make_user(
            id="user-123",
            user_principal_name="john@contoso.com",
            display_name="John Smith",
        )
        mock_location = make_location(location_id="loc-123", description="Seattle HQ")
        mock_operation = make_operation(id="op-123", status=OperationStatus.FAILED)

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
            patch("teams_phone.cli.numbers.LocationService") as mock_ls_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(return_value=mock_user)
            mock_us_class.return_value = mock_user_service

            mock_location_service = MagicMock()
            mock_location_service.validate_location = MagicMock(
                return_value=mock_location
            )
            mock_ls_class.return_value = mock_location_service

            mock_number_service = MagicMock()
            mock_number_service.assign_number = AsyncMock(return_value=mock_operation)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "assign",
                    "john@contoso.com",
                    "+14255551234",
                    "--location",
                    "Seattle HQ",
                    "--force",
                ],
            )
            assert result.exit_code == 1
            assert "failed" in result.stdout
