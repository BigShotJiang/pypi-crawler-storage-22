"""Unit tests for CLI numbers bulk-assign execution flow."""

from __future__ import annotations

from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.exceptions import NotFoundError
from teams_phone.models import NumberType, OperationStatus
from tests.conftest import CliRunner


if TYPE_CHECKING:
    from pathlib import Path

runner = CliRunner()


class TestNumbersBulkExecution:
    """Unit tests for bulk-assign execution flow, confirmation, and error handling."""

    @pytest.mark.unit
    def test_bulk_assign_confirmation_cancelled(self, tmp_path: Path) -> None:
        """bulk-assign exits when user cancels confirmation."""
        csv_content = (
            "user,phone_number,location\njohn@contoso.com,+14255551234,Seattle HQ\n"
        )
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)

        # Create mock validation result - all valid
        mock_validation = MagicMock()
        mock_validation.rows = [MagicMock()]
        mock_validation.rows[0].row_number = 2
        mock_validation.rows[0].user = "john@contoso.com"
        mock_validation.rows[0].phone_number = "+14255551234"
        mock_validation.rows[0].location = "Seattle HQ"
        mock_validation.rows[0].errors = []
        mock_validation.rows[0].warnings = []
        mock_validation.valid_count = 1
        mock_validation.error_count = 0
        mock_validation.warning_count = 0

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService"),
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService"),
            patch("teams_phone.cli.numbers.BulkOperations") as mock_bulk_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_bulk = MagicMock()
            mock_bulk.validate_assign_csv = AsyncMock(return_value=mock_validation)
            mock_bulk_class.return_value = mock_bulk

            # Simulate user typing "n" to cancel
            result = runner.invoke(
                app,
                ["--no-color", "numbers", "bulk-assign", str(csv_file)],
                input="n\n",
            )
            assert result.exit_code == 0
            assert "cancelled" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_yes_skips_confirmation(self, tmp_path: Path) -> None:
        """bulk-assign --yes skips confirmation prompt."""
        csv_content = (
            "user,phone_number,location\njohn@contoso.com,+14255551234,Seattle HQ\n"
        )
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)

        # Create mock validation result - all valid
        mock_validation = MagicMock()
        mock_validation.rows = [MagicMock()]
        mock_validation.rows[0].row_number = 2
        mock_validation.rows[0].user = "john@contoso.com"
        mock_validation.rows[0].phone_number = "+14255551234"
        mock_validation.rows[0].location = "Seattle HQ"
        mock_validation.rows[0].errors = []
        mock_validation.rows[0].warnings = []
        mock_validation.valid_count = 1
        mock_validation.error_count = 0
        mock_validation.warning_count = 0

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService"),
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService"),
            patch("teams_phone.cli.numbers.BulkOperations") as mock_bulk_class,
            patch("teams_phone.cli.numbers.write_results_csv"),
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_bulk = MagicMock()
            mock_bulk.validate_assign_csv = AsyncMock(return_value=mock_validation)
            mock_bulk_class.return_value = mock_bulk

            # Mock user resolution
            mock_user = MagicMock()
            mock_user.id = "user-123"
            mock_bulk.user_service.resolve_user = AsyncMock(return_value=mock_user)

            # Mock number lookup
            mock_number = MagicMock()
            mock_number.number_type = NumberType.DIRECT_ROUTING
            mock_bulk.number_service.get_number = AsyncMock(return_value=mock_number)

            # Mock successful assignment
            mock_operation = MagicMock()
            mock_operation.status = OperationStatus.SUCCEEDED
            mock_bulk.number_service.assign_number = AsyncMock(
                return_value=mock_operation
            )

            # Mock location validation
            mock_location = MagicMock()
            mock_location.location_id = "loc-123"
            mock_bulk.location_service.validate_location = MagicMock(
                return_value=mock_location
            )

            result = runner.invoke(
                app,
                ["--no-color", "numbers", "bulk-assign", str(csv_file), "--yes"],
            )
            # Should complete successfully
            assert result.exit_code == 0
            # Confirmation prompt should not appear
            assert "Proceed with bulk assignment?" not in result.stdout
            # Should show execution summary
            assert "Execution Summary:" in result.stdout
            assert "Successful:" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_continue_on_error_proceeds(self, tmp_path: Path) -> None:
        """bulk-assign --continue-on-error proceeds with valid rows despite errors."""
        csv_content = (
            "user,phone_number,location\n"
            "john@contoso.com,+14255551234,Seattle HQ\n"
            "invalid@contoso.com,+14255555678,Seattle HQ\n"
        )
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)

        # Create mock validation result - one valid, one error
        mock_row1 = MagicMock()
        mock_row1.row_number = 2
        mock_row1.user = "john@contoso.com"
        mock_row1.phone_number = "+14255551234"
        mock_row1.location = "Seattle HQ"
        mock_row1.errors = []
        mock_row1.warnings = []

        mock_row2 = MagicMock()
        mock_row2.row_number = 3
        mock_row2.user = "invalid@contoso.com"
        mock_row2.phone_number = "+14255555678"
        mock_row2.location = "Seattle HQ"
        mock_row2.errors = ["User not found"]
        mock_row2.warnings = []

        mock_validation = MagicMock()
        mock_validation.rows = [mock_row1, mock_row2]
        mock_validation.valid_count = 1
        mock_validation.error_count = 1
        mock_validation.warning_count = 0

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService"),
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService"),
            patch("teams_phone.cli.numbers.BulkOperations") as mock_bulk_class,
            patch("teams_phone.cli.numbers.write_results_csv"),
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_bulk = MagicMock()
            mock_bulk.validate_assign_csv = AsyncMock(return_value=mock_validation)
            mock_bulk_class.return_value = mock_bulk

            # Mock user resolution (only for valid row)
            mock_user = MagicMock()
            mock_user.id = "user-123"
            mock_bulk.user_service.resolve_user = AsyncMock(return_value=mock_user)

            # Mock number lookup
            mock_number = MagicMock()
            mock_number.number_type = NumberType.DIRECT_ROUTING
            mock_bulk.number_service.get_number = AsyncMock(return_value=mock_number)

            # Mock successful assignment
            mock_operation = MagicMock()
            mock_operation.status = OperationStatus.SUCCEEDED
            mock_bulk.number_service.assign_number = AsyncMock(
                return_value=mock_operation
            )

            # Mock location validation
            mock_location = MagicMock()
            mock_location.location_id = "loc-123"
            mock_bulk.location_service.validate_location = MagicMock(
                return_value=mock_location
            )

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "bulk-assign",
                    str(csv_file),
                    "--continue-on-error",
                    "--yes",
                ],
            )
            # Should complete execution with mixed results
            assert result.exit_code == 0
            # Validation summary should show errors exist
            assert "Errors:" in result.stdout
            assert "Valid:" in result.stdout
            # Execution summary should appear
            assert "Execution Summary:" in result.stdout
            assert "Successful:" in result.stdout
            assert "Skipped:" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_execution_success_increments_counter(
        self, tmp_path: Path
    ) -> None:
        """bulk-assign increments success counter on successful assignment."""
        csv_content = (
            "user,phone_number,location\njohn@contoso.com,+14255551234,Seattle HQ\n"
        )
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)

        # Create mock validation result - all valid
        mock_row = MagicMock()
        mock_row.row_number = 2
        mock_row.user = "john@contoso.com"
        mock_row.phone_number = "+14255551234"
        mock_row.location = "Seattle HQ"
        mock_row.errors = []
        mock_row.warnings = []

        mock_validation = MagicMock()
        mock_validation.rows = [mock_row]
        mock_validation.valid_count = 1
        mock_validation.error_count = 0
        mock_validation.warning_count = 0

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService"),
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService"),
            patch("teams_phone.cli.numbers.BulkOperations") as mock_bulk_class,
            patch("teams_phone.cli.numbers.write_results_csv"),
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_bulk = MagicMock()
            mock_bulk.validate_assign_csv = AsyncMock(return_value=mock_validation)
            mock_bulk_class.return_value = mock_bulk

            # Mock user resolution
            mock_user = MagicMock()
            mock_user.id = "user-123"
            mock_bulk.user_service.resolve_user = AsyncMock(return_value=mock_user)

            # Mock number lookup
            mock_number = MagicMock()
            mock_number.number_type = NumberType.DIRECT_ROUTING
            mock_bulk.number_service.get_number = AsyncMock(return_value=mock_number)

            # Mock successful assignment
            mock_operation = MagicMock()
            mock_operation.status = OperationStatus.SUCCEEDED
            mock_bulk.number_service.assign_number = AsyncMock(
                return_value=mock_operation
            )

            # Mock location validation
            mock_location = MagicMock()
            mock_location.location_id = "loc-123"
            mock_bulk.location_service.validate_location = MagicMock(
                return_value=mock_location
            )

            result = runner.invoke(
                app,
                ["--no-color", "numbers", "bulk-assign", str(csv_file), "--yes"],
            )
            assert result.exit_code == 0
            # Check for labels (numbers may have ANSI codes)
            assert "Successful:" in result.stdout
            assert "Failed:" in result.stdout
            # Verify assignment was called
            mock_bulk.number_service.assign_number.assert_called_once()

    @pytest.mark.unit
    def test_bulk_assign_execution_failure_increments_counter(
        self, tmp_path: Path
    ) -> None:
        """bulk-assign increments fail counter on failed assignment."""
        csv_content = (
            "user,phone_number,location\njohn@contoso.com,+14255551234,Seattle HQ\n"
        )
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)

        # Create mock validation result - all valid
        mock_row = MagicMock()
        mock_row.row_number = 2
        mock_row.user = "john@contoso.com"
        mock_row.phone_number = "+14255551234"
        mock_row.location = "Seattle HQ"
        mock_row.errors = []
        mock_row.warnings = []

        mock_validation = MagicMock()
        mock_validation.rows = [mock_row]
        mock_validation.valid_count = 1
        mock_validation.error_count = 0
        mock_validation.warning_count = 0

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService"),
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService"),
            patch("teams_phone.cli.numbers.BulkOperations") as mock_bulk_class,
            patch("teams_phone.cli.numbers.write_results_csv"),
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_bulk = MagicMock()
            mock_bulk.validate_assign_csv = AsyncMock(return_value=mock_validation)
            mock_bulk_class.return_value = mock_bulk

            # Mock user resolution
            mock_user = MagicMock()
            mock_user.id = "user-123"
            mock_bulk.user_service.resolve_user = AsyncMock(return_value=mock_user)

            # Mock number lookup
            mock_number = MagicMock()
            mock_number.number_type = NumberType.DIRECT_ROUTING
            mock_bulk.number_service.get_number = AsyncMock(return_value=mock_number)

            # Mock FAILED assignment
            mock_operation = MagicMock()
            mock_operation.status = OperationStatus.FAILED
            mock_bulk.number_service.assign_number = AsyncMock(
                return_value=mock_operation
            )

            # Mock location validation
            mock_location = MagicMock()
            mock_location.location_id = "loc-123"
            mock_bulk.location_service.validate_location = MagicMock(
                return_value=mock_location
            )

            result = runner.invoke(
                app,
                ["--no-color", "numbers", "bulk-assign", str(csv_file), "--yes"],
            )
            # Exit code 1 when there are failures
            assert result.exit_code == 1
            assert "Successful:" in result.stdout
            assert "Failed:" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_execution_exception_increments_fail_counter(
        self, tmp_path: Path
    ) -> None:
        """bulk-assign increments fail counter when assignment throws exception."""
        csv_content = (
            "user,phone_number,location\njohn@contoso.com,+14255551234,Seattle HQ\n"
        )
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)

        # Create mock validation result - all valid
        mock_row = MagicMock()
        mock_row.row_number = 2
        mock_row.user = "john@contoso.com"
        mock_row.phone_number = "+14255551234"
        mock_row.location = "Seattle HQ"
        mock_row.errors = []
        mock_row.warnings = []

        mock_validation = MagicMock()
        mock_validation.rows = [mock_row]
        mock_validation.valid_count = 1
        mock_validation.error_count = 0
        mock_validation.warning_count = 0

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService"),
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService"),
            patch("teams_phone.cli.numbers.BulkOperations") as mock_bulk_class,
            patch("teams_phone.cli.numbers.write_results_csv"),
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_bulk = MagicMock()
            mock_bulk.validate_assign_csv = AsyncMock(return_value=mock_validation)
            mock_bulk_class.return_value = mock_bulk

            # Mock user resolution that throws exception
            mock_bulk.user_service.resolve_user = AsyncMock(
                side_effect=NotFoundError("User not found")
            )

            result = runner.invoke(
                app,
                ["--no-color", "numbers", "bulk-assign", str(csv_file), "--yes"],
            )
            # Exit code 1 when there are failures
            assert result.exit_code == 1
            assert "Successful:" in result.stdout
            assert "Failed:" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_skips_rows_with_validation_errors(
        self, tmp_path: Path
    ) -> None:
        """bulk-assign skips rows that failed validation and marks them as skipped."""
        csv_content = (
            "user,phone_number,location\n"
            "john@contoso.com,+14255551234,Seattle HQ\n"
            "invalid@contoso.com,+14255555678,Seattle HQ\n"
        )
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)

        # Create mock validation result - one valid, one with error
        mock_row1 = MagicMock()
        mock_row1.row_number = 2
        mock_row1.user = "john@contoso.com"
        mock_row1.phone_number = "+14255551234"
        mock_row1.location = "Seattle HQ"
        mock_row1.errors = []
        mock_row1.warnings = []

        mock_row2 = MagicMock()
        mock_row2.row_number = 3
        mock_row2.user = "invalid@contoso.com"
        mock_row2.phone_number = "+14255555678"
        mock_row2.location = "Seattle HQ"
        mock_row2.errors = ["User not found"]
        mock_row2.warnings = []

        mock_validation = MagicMock()
        mock_validation.rows = [mock_row1, mock_row2]
        mock_validation.valid_count = 1
        mock_validation.error_count = 1
        mock_validation.warning_count = 0

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService"),
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService"),
            patch("teams_phone.cli.numbers.BulkOperations") as mock_bulk_class,
            patch("teams_phone.cli.numbers.write_results_csv"),
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_bulk = MagicMock()
            mock_bulk.validate_assign_csv = AsyncMock(return_value=mock_validation)
            mock_bulk_class.return_value = mock_bulk

            # Mock user resolution (only called for valid row)
            mock_user = MagicMock()
            mock_user.id = "user-123"
            mock_bulk.user_service.resolve_user = AsyncMock(return_value=mock_user)

            # Mock number lookup
            mock_number = MagicMock()
            mock_number.number_type = NumberType.DIRECT_ROUTING
            mock_bulk.number_service.get_number = AsyncMock(return_value=mock_number)

            # Mock successful assignment
            mock_operation = MagicMock()
            mock_operation.status = OperationStatus.SUCCEEDED
            mock_bulk.number_service.assign_number = AsyncMock(
                return_value=mock_operation
            )

            # Mock location validation
            mock_location = MagicMock()
            mock_location.location_id = "loc-123"
            mock_bulk.location_service.validate_location = MagicMock(
                return_value=mock_location
            )

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "bulk-assign",
                    str(csv_file),
                    "--continue-on-error",
                    "--yes",
                ],
            )
            assert result.exit_code == 0
            assert "Successful:" in result.stdout
            assert "Skipped:" in result.stdout
            # assign_number should only be called once (for valid row)
            mock_bulk.number_service.assign_number.assert_called_once()

    @pytest.mark.unit
    def test_bulk_assign_stops_on_first_error_without_continue(
        self, tmp_path: Path
    ) -> None:
        """bulk-assign stops processing on first error when --continue-on-error not set."""
        csv_content = (
            "user,phone_number,location\n"
            "john@contoso.com,+14255551234,Seattle HQ\n"
            "jane@contoso.com,+14255555678,Seattle HQ\n"
        )
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)

        # Create mock validation result - both valid
        mock_row1 = MagicMock()
        mock_row1.row_number = 2
        mock_row1.user = "john@contoso.com"
        mock_row1.phone_number = "+14255551234"
        mock_row1.location = "Seattle HQ"
        mock_row1.errors = []
        mock_row1.warnings = []

        mock_row2 = MagicMock()
        mock_row2.row_number = 3
        mock_row2.user = "jane@contoso.com"
        mock_row2.phone_number = "+14255555678"
        mock_row2.location = "Seattle HQ"
        mock_row2.errors = []
        mock_row2.warnings = []

        mock_validation = MagicMock()
        mock_validation.rows = [mock_row1, mock_row2]
        mock_validation.valid_count = 2
        mock_validation.error_count = 0
        mock_validation.warning_count = 0

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService"),
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService"),
            patch("teams_phone.cli.numbers.BulkOperations") as mock_bulk_class,
            patch("teams_phone.cli.numbers.write_results_csv"),
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_bulk = MagicMock()
            mock_bulk.validate_assign_csv = AsyncMock(return_value=mock_validation)
            mock_bulk_class.return_value = mock_bulk

            # Mock user resolution that fails on first call
            mock_bulk.user_service.resolve_user = AsyncMock(
                side_effect=NotFoundError("User not found")
            )

            result = runner.invoke(
                app,
                ["--no-color", "numbers", "bulk-assign", str(csv_file), "--yes"],
            )
            # Exit code 1 when there are failures
            assert result.exit_code == 1
            # Should only call resolve_user once (stopped after first error)
            assert mock_bulk.user_service.resolve_user.call_count == 1
            # Should show skipped count for second row
            assert "Skipped:" in result.stdout
