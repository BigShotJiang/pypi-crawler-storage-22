"""Unit tests for CLI numbers bulk-assign output formatting."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.models import NumberType, OperationStatus
from tests.conftest import CliRunner


if TYPE_CHECKING:
    from pathlib import Path

runner = CliRunner()


class TestNumbersBulkOutput:
    """Unit tests for bulk-assign output formatting, JSON mode, and file writing."""

    @pytest.mark.unit
    def test_bulk_assign_json_mode_suppresses_progress(self, tmp_path: Path) -> None:
        """bulk-assign --json suppresses progress bar display."""
        csv_content = (
            "user,phone_number,location\njohn@contoso.com,+14255551234,Seattle HQ\n"
        )
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)

        # Create mock validation result - all valid
        mock_row = MagicMock()
        mock_row.row_number = 2
        mock_row.user = "john@contoso.com"
        mock_row.phone_number = "+14255551234"
        mock_row.location = "Seattle HQ"
        mock_row.errors = []
        mock_row.warnings = []

        mock_validation = MagicMock()
        mock_validation.rows = [mock_row]
        mock_validation.valid_count = 1
        mock_validation.error_count = 0
        mock_validation.warning_count = 0

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService"),
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService"),
            patch("teams_phone.cli.numbers.BulkOperations") as mock_bulk_class,
            patch("teams_phone.cli.numbers.write_results_csv"),
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_bulk = MagicMock()
            mock_bulk.validate_assign_csv = AsyncMock(return_value=mock_validation)
            mock_bulk_class.return_value = mock_bulk

            # Mock user resolution
            mock_user = MagicMock()
            mock_user.id = "user-123"
            mock_bulk.user_service.resolve_user = AsyncMock(return_value=mock_user)

            # Mock number lookup
            mock_number = MagicMock()
            mock_number.number_type = NumberType.DIRECT_ROUTING
            mock_bulk.number_service.get_number = AsyncMock(return_value=mock_number)

            # Mock successful assignment
            mock_operation = MagicMock()
            mock_operation.status = OperationStatus.SUCCEEDED
            mock_bulk.number_service.assign_number = AsyncMock(
                return_value=mock_operation
            )

            # Mock location validation
            mock_location = MagicMock()
            mock_location.location_id = "loc-123"
            mock_bulk.location_service.validate_location = MagicMock(
                return_value=mock_location
            )

            result = runner.invoke(
                app,
                ["--json", "numbers", "bulk-assign", str(csv_file), "--yes"],
            )
            assert result.exit_code == 0
            # In JSON mode, validation result is output as JSON
            # No progress bar text should appear
            assert "Processing [" not in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_writes_results_file(self, tmp_path: Path) -> None:
        """bulk-assign writes results to specified output file."""
        csv_content = (
            "user,phone_number,location\njohn@contoso.com,+14255551234,Seattle HQ\n"
        )
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)
        output_file = tmp_path / "results.csv"

        # Create mock validation result
        mock_row = MagicMock()
        mock_row.row_number = 2
        mock_row.user = "john@contoso.com"
        mock_row.phone_number = "+14255551234"
        mock_row.location = "Seattle HQ"
        mock_row.errors = []
        mock_row.warnings = []

        mock_validation = MagicMock()
        mock_validation.rows = [mock_row]
        mock_validation.valid_count = 1
        mock_validation.error_count = 0
        mock_validation.warning_count = 0

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService"),
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService"),
            patch("teams_phone.cli.numbers.BulkOperations") as mock_bulk_class,
            patch("teams_phone.cli.numbers.write_results_csv") as mock_write,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_bulk = MagicMock()
            mock_bulk.validate_assign_csv = AsyncMock(return_value=mock_validation)
            mock_bulk_class.return_value = mock_bulk

            # Mock user resolution
            mock_user = MagicMock()
            mock_user.id = "user-123"
            mock_bulk.user_service.resolve_user = AsyncMock(return_value=mock_user)

            # Mock number lookup
            mock_number = MagicMock()
            mock_number.number_type = NumberType.DIRECT_ROUTING
            mock_bulk.number_service.get_number = AsyncMock(return_value=mock_number)

            # Mock successful assignment
            mock_operation = MagicMock()
            mock_operation.status = OperationStatus.SUCCEEDED
            mock_bulk.number_service.assign_number = AsyncMock(
                return_value=mock_operation
            )

            # Mock location validation
            mock_location = MagicMock()
            mock_location.location_id = "loc-123"
            mock_bulk.location_service.validate_location = MagicMock(
                return_value=mock_location
            )

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "bulk-assign",
                    str(csv_file),
                    "--yes",
                    "--output",
                    str(output_file),
                ],
            )
            assert result.exit_code == 0
            # Verify write_results_csv was called with correct output path
            mock_write.assert_called_once()
            call_args = mock_write.call_args
            assert call_args[0][1] == output_file
            # Should show results file in output
            assert "Results file:" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_json_output_includes_results(self, tmp_path: Path) -> None:
        """bulk-assign --json includes results array in output."""
        csv_content = (
            "user,phone_number,location\njohn@contoso.com,+14255551234,Seattle HQ\n"
        )
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)

        # Create mock validation result
        mock_row = MagicMock()
        mock_row.row_number = 2
        mock_row.user = "john@contoso.com"
        mock_row.phone_number = "+14255551234"
        mock_row.location = "Seattle HQ"
        mock_row.errors = []
        mock_row.warnings = []

        mock_validation = MagicMock()
        mock_validation.rows = [mock_row]
        mock_validation.valid_count = 1
        mock_validation.error_count = 0
        mock_validation.warning_count = 0

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService"),
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService"),
            patch("teams_phone.cli.numbers.BulkOperations") as mock_bulk_class,
            patch("teams_phone.cli.numbers.write_results_csv"),
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_bulk = MagicMock()
            mock_bulk.validate_assign_csv = AsyncMock(return_value=mock_validation)
            mock_bulk_class.return_value = mock_bulk

            # Mock user resolution
            mock_user = MagicMock()
            mock_user.id = "user-123"
            mock_bulk.user_service.resolve_user = AsyncMock(return_value=mock_user)

            # Mock number lookup
            mock_number = MagicMock()
            mock_number.number_type = NumberType.DIRECT_ROUTING
            mock_bulk.number_service.get_number = AsyncMock(return_value=mock_number)

            # Mock successful assignment
            mock_operation = MagicMock()
            mock_operation.status = OperationStatus.SUCCEEDED
            mock_bulk.number_service.assign_number = AsyncMock(
                return_value=mock_operation
            )

            # Mock location validation
            mock_location = MagicMock()
            mock_location.location_id = "loc-123"
            mock_bulk.location_service.validate_location = MagicMock(
                return_value=mock_location
            )

            result = runner.invoke(
                app,
                ["--json", "numbers", "bulk-assign", str(csv_file), "--yes"],
            )
            assert result.exit_code == 0
            # Parse JSON output
            output = json.loads(result.stdout)
            assert output["status"] == "completed"
            assert "summary" in output
            assert output["summary"]["successful"] == 1
            assert output["summary"]["failed"] == 0
            assert "results" in output
            assert len(output["results"]) == 1
            assert output["results"][0]["status"] == "success"
            assert output["results"][0]["user"] == "john@contoso.com"

    @pytest.mark.unit
    def test_bulk_assign_generates_timestamp_filename(self, tmp_path: Path) -> None:
        """bulk-assign generates timestamp-based filename when --output not specified."""
        csv_content = (
            "user,phone_number,location\njohn@contoso.com,+14255551234,Seattle HQ\n"
        )
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)

        # Create mock validation result
        mock_row = MagicMock()
        mock_row.row_number = 2
        mock_row.user = "john@contoso.com"
        mock_row.phone_number = "+14255551234"
        mock_row.location = "Seattle HQ"
        mock_row.errors = []
        mock_row.warnings = []

        mock_validation = MagicMock()
        mock_validation.rows = [mock_row]
        mock_validation.valid_count = 1
        mock_validation.error_count = 0
        mock_validation.warning_count = 0

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService"),
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService"),
            patch("teams_phone.cli.numbers.BulkOperations") as mock_bulk_class,
            patch("teams_phone.cli.numbers.write_results_csv") as mock_write,
            patch("teams_phone.cli.numbers.datetime") as mock_datetime,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            # Mock datetime to control timestamp
            mock_now = MagicMock()
            mock_now.strftime.return_value = "20260129-120000"
            mock_datetime.now.return_value = mock_now

            mock_bulk = MagicMock()
            mock_bulk.validate_assign_csv = AsyncMock(return_value=mock_validation)
            mock_bulk_class.return_value = mock_bulk

            # Mock user resolution
            mock_user = MagicMock()
            mock_user.id = "user-123"
            mock_bulk.user_service.resolve_user = AsyncMock(return_value=mock_user)

            # Mock number lookup
            mock_number = MagicMock()
            mock_number.number_type = NumberType.DIRECT_ROUTING
            mock_bulk.number_service.get_number = AsyncMock(return_value=mock_number)

            # Mock successful assignment
            mock_operation = MagicMock()
            mock_operation.status = OperationStatus.SUCCEEDED
            mock_bulk.number_service.assign_number = AsyncMock(
                return_value=mock_operation
            )

            # Mock location validation
            mock_location = MagicMock()
            mock_location.location_id = "loc-123"
            mock_bulk.location_service.validate_location = MagicMock(
                return_value=mock_location
            )

            result = runner.invoke(
                app,
                ["--no-color", "numbers", "bulk-assign", str(csv_file), "--yes"],
            )
            assert result.exit_code == 0
            # Verify write_results_csv was called with timestamp-based filename
            mock_write.assert_called_once()
            call_args = mock_write.call_args
            output_path = call_args[0][1]
            assert "bulk-assign-results-20260129-120000.csv" in str(output_path)
