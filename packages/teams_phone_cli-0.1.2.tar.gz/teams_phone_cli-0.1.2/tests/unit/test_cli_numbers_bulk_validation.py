"""Unit tests for CLI numbers bulk-assign validation and dry-run."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from teams_phone.cli.main import app
from tests.conftest import CliRunner


if TYPE_CHECKING:
    from pathlib import Path

runner = CliRunner()


class TestNumbersCommandIntegration:
    """Integration tests for numbers command group."""

    @pytest.mark.unit
    def test_numbers_commands_appear_in_help(self) -> None:
        """All numbers commands appear in numbers --help."""
        result = runner.invoke(app, ["numbers", "--help"])
        assert result.exit_code == 0
        assert "list" in result.stdout
        assert "show" in result.stdout
        assert "search" in result.stdout

    @pytest.mark.unit
    def test_numbers_no_args_shows_help(self) -> None:
        """numbers with no args shows help (exit code 2)."""
        result = runner.invoke(app, ["numbers"])
        assert result.exit_code == 2
        assert "Usage:" in result.stdout

    @pytest.mark.unit
    def test_numbers_appears_in_main_help(self) -> None:
        """numbers command group appears in main help."""
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "numbers" in result.stdout


class TestNumbersBulkValidation:
    """Tests for bulk-assign validation and dry-run functionality."""

    @pytest.mark.unit
    def test_bulk_assign_shows_in_help(self) -> None:
        """bulk-assign command appears in numbers help."""
        result = runner.invoke(app, ["numbers", "--help"])
        assert result.exit_code == 0
        assert "bulk-assign" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_requires_csv_file_argument(self) -> None:
        """bulk-assign requires csv_file argument."""
        result = runner.invoke(app, ["numbers", "bulk-assign"])
        assert result.exit_code == 2
        output = result.stdout + (result.stderr or "")
        assert (
            "CSV_FILE" in output
            or "Missing argument" in output
            or result.exit_code == 2
        )

    @pytest.mark.unit
    def test_bulk_assign_file_not_found(self) -> None:
        """bulk-assign shows error for non-existent file."""
        result = runner.invoke(
            app, ["--no-color", "numbers", "bulk-assign", "nonexistent.csv"]
        )
        assert result.exit_code == 2
        # Typer handles this before our code - file doesn't exist
        output = result.stdout + (result.stderr or "")
        assert "not exist" in output or "not found" in output or result.exit_code == 2

    @pytest.mark.unit
    def test_bulk_assign_dry_run_valid_csv(self, tmp_path: Path) -> None:
        """bulk-assign --dry-run validates CSV and shows summary."""
        csv_content = (
            "user,phone_number,location\njohn@contoso.com,+14255551234,Seattle HQ\n"
        )
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)

        # Create mock validation result
        mock_validation = MagicMock()
        mock_validation.rows = [MagicMock()]
        mock_validation.rows[0].row_number = 2
        mock_validation.rows[0].user = "john@contoso.com"
        mock_validation.rows[0].phone_number = "+14255551234"
        mock_validation.rows[0].location = "Seattle HQ"
        mock_validation.rows[0].errors = []
        mock_validation.rows[0].warnings = []
        mock_validation.valid_count = 1
        mock_validation.error_count = 0
        mock_validation.warning_count = 0

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
            patch("teams_phone.cli.numbers.LocationService") as mock_ls_class,
            patch("teams_phone.cli.numbers.BulkOperations") as mock_bulk_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_user_service = MagicMock()
            mock_us_class.return_value = mock_user_service

            mock_number_service = MagicMock()
            mock_ns_class.return_value = mock_number_service

            mock_location_service = MagicMock()
            mock_ls_class.return_value = mock_location_service

            mock_bulk = MagicMock()
            mock_bulk.validate_assign_csv = AsyncMock(return_value=mock_validation)
            mock_bulk_class.return_value = mock_bulk

            result = runner.invoke(
                app,
                ["--no-color", "numbers", "bulk-assign", str(csv_file), "--dry-run"],
            )
            assert result.exit_code == 0
            assert "Validation Summary" in result.stdout
            # Check for content that may have ANSI codes around numbers
            assert "Total rows:" in result.stdout
            assert "Valid:" in result.stdout
            assert "Errors:" in result.stdout
            assert "Dry run complete" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_dry_run_with_errors(self, tmp_path: Path) -> None:
        """bulk-assign --dry-run exits with code 1 when validation errors exist."""
        csv_content = (
            "user,phone_number,location\njohn@contoso.com,+14255551234,Seattle HQ\n"
        )
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)

        # Create mock validation result with errors
        mock_validation = MagicMock()
        mock_validation.rows = [MagicMock()]
        mock_validation.rows[0].row_number = 2
        mock_validation.rows[0].user = "john@contoso.com"
        mock_validation.rows[0].phone_number = "+14255551234"
        mock_validation.rows[0].location = "Seattle HQ"
        mock_validation.rows[0].errors = ["User 'john@contoso.com' not found"]
        mock_validation.rows[0].warnings = []
        mock_validation.valid_count = 0
        mock_validation.error_count = 1
        mock_validation.warning_count = 0

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService"),
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService"),
            patch("teams_phone.cli.numbers.BulkOperations") as mock_bulk_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_bulk = MagicMock()
            mock_bulk.validate_assign_csv = AsyncMock(return_value=mock_validation)
            mock_bulk_class.return_value = mock_bulk

            result = runner.invoke(
                app,
                ["--no-color", "numbers", "bulk-assign", str(csv_file), "--dry-run"],
            )
            assert result.exit_code == 1  # Exit code 1 for validation errors
            assert "Validation Errors" in result.stdout
            assert "john@contoso.com" in result.stdout
            assert "not found" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_json_dry_run(self, tmp_path: Path) -> None:
        """bulk-assign --dry-run --json outputs valid JSON."""
        csv_content = (
            "user,phone_number,location\njohn@contoso.com,+14255551234,Seattle HQ\n"
        )
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)

        # Create mock validation result
        mock_validation = MagicMock()
        mock_validation.rows = [MagicMock()]
        mock_validation.rows[0].row_number = 2
        mock_validation.rows[0].user = "john@contoso.com"
        mock_validation.rows[0].phone_number = "+14255551234"
        mock_validation.rows[0].location = "Seattle HQ"
        mock_validation.rows[0].errors = []
        mock_validation.rows[0].warnings = []
        mock_validation.valid_count = 1
        mock_validation.error_count = 0
        mock_validation.warning_count = 0

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService"),
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService"),
            patch("teams_phone.cli.numbers.BulkOperations") as mock_bulk_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_bulk = MagicMock()
            mock_bulk.validate_assign_csv = AsyncMock(return_value=mock_validation)
            mock_bulk_class.return_value = mock_bulk

            result = runner.invoke(
                app,
                ["--json", "numbers", "bulk-assign", str(csv_file), "--dry-run"],
            )
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data["dry_run"] is True
            assert data["total_rows"] == 1
            assert data["valid_count"] == 1
            assert data["error_count"] == 0
            assert len(data["rows"]) == 1
            assert data["rows"][0]["user"] == "john@contoso.com"
            assert data["rows"][0]["valid"] is True

    @pytest.mark.unit
    def test_bulk_assign_validation_error_without_continue(
        self, tmp_path: Path
    ) -> None:
        """bulk-assign fails with ValidationError when errors exist and no --continue-on-error."""
        csv_content = (
            "user,phone_number,location\njohn@contoso.com,+14255551234,Seattle HQ\n"
        )
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)

        # Create mock validation result with errors
        mock_validation = MagicMock()
        mock_validation.rows = [MagicMock()]
        mock_validation.rows[0].row_number = 2
        mock_validation.rows[0].user = "john@contoso.com"
        mock_validation.rows[0].phone_number = "+14255551234"
        mock_validation.rows[0].location = "Seattle HQ"
        mock_validation.rows[0].errors = ["User not found"]
        mock_validation.rows[0].warnings = []
        mock_validation.valid_count = 0
        mock_validation.error_count = 1
        mock_validation.warning_count = 0

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService"),
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService"),
            patch("teams_phone.cli.numbers.BulkOperations") as mock_bulk_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_bulk = MagicMock()
            mock_bulk.validate_assign_csv = AsyncMock(return_value=mock_validation)
            mock_bulk_class.return_value = mock_bulk

            result = runner.invoke(
                app,
                ["--no-color", "numbers", "bulk-assign", str(csv_file)],
            )
            # Should exit with ValidationError exit code (5)
            assert result.exit_code == 5
            assert "Validation failed" in result.stdout
            assert "continue-on-error" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_empty_csv_no_rows(self, tmp_path: Path) -> None:
        """bulk-assign handles CSV with only header (no data rows)."""
        csv_content = "user,phone_number,location\n"
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient"),
        ):
            result = runner.invoke(
                app,
                ["--no-color", "numbers", "bulk-assign", str(csv_file), "--dry-run"],
            )
            assert result.exit_code == 0
            assert "No data rows found" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_default_location_applied(self, tmp_path: Path) -> None:
        """bulk-assign --default-location applies to rows without location."""
        # CSV without location column
        csv_content = "user,phone_number\njohn@contoso.com,+14255551234\n"
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)

        captured_rows: list[Any] = []

        async def capture_validation(rows: list[Any]) -> MagicMock:
            captured_rows.extend(rows)
            mock_result = MagicMock()
            mock_result.rows = rows
            mock_result.valid_count = 1
            mock_result.error_count = 0
            mock_result.warning_count = 0
            return mock_result

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService"),
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService"),
            patch("teams_phone.cli.numbers.BulkOperations") as mock_bulk_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_bulk = MagicMock()
            mock_bulk.validate_assign_csv = AsyncMock(side_effect=capture_validation)
            mock_bulk_class.return_value = mock_bulk

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "bulk-assign",
                    str(csv_file),
                    "--default-location",
                    "Seattle-HQ",
                    "--dry-run",
                ],
            )
            assert result.exit_code == 0
            # Check that the default location was applied
            assert len(captured_rows) == 1
            assert captured_rows[0].location == "Seattle-HQ"

    @pytest.mark.unit
    def test_bulk_assign_default_location_from_tenant_profile(
        self, tmp_path: Path
    ) -> None:
        """bulk-assign uses tenant profile default_location when --default-location not set."""
        # CSV without location column
        csv_content = "user,phone_number\njohn@contoso.com,+14255551234\n"
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(csv_content)

        captured_rows: list[Any] = []

        async def capture_validation(rows: list[Any]) -> MagicMock:
            captured_rows.extend(rows)
            mock_result = MagicMock()
            mock_result.rows = rows
            mock_result.valid_count = 1
            mock_result.error_count = 0
            mock_result.warning_count = 0
            return mock_result

        with (
            patch("teams_phone.cli.numbers.CacheManager"),
            patch("teams_phone.cli.numbers.AuthService"),
            patch("teams_phone.cli.numbers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService"),
            patch("teams_phone.cli.numbers.NumberService"),
            patch("teams_phone.cli.numbers.LocationService") as mock_loc_class,
            patch("teams_phone.cli.numbers.BulkOperations") as mock_bulk_class,
            patch("teams_phone.infrastructure.ConfigManager") as mock_config_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            # Mock config manager to return tenant with default_location
            mock_config = MagicMock()
            mock_config.get_default_tenant.return_value = "test-tenant"
            mock_tenant = MagicMock()
            mock_tenant.default_location = "Tenant-Default-Location"
            mock_config.get_tenant.return_value = mock_tenant
            mock_config_class.return_value = mock_config

            # Mock location validation (called for default location)
            mock_location = MagicMock()
            mock_location.location_id = "loc-tenant-default"
            mock_loc_class.return_value.validate_location.return_value = mock_location

            mock_bulk = MagicMock()
            mock_bulk.validate_assign_csv = AsyncMock(side_effect=capture_validation)
            mock_bulk_class.return_value = mock_bulk

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "bulk-assign",
                    str(csv_file),
                    "--dry-run",
                ],
            )
            assert result.exit_code == 0
            # Check that the tenant default location was applied
            assert len(captured_rows) == 1
            assert captured_rows[0].location == "Tenant-Default-Location"
            # Should show info message about using tenant default
            assert "Using default location from tenant profile" in result.stdout
