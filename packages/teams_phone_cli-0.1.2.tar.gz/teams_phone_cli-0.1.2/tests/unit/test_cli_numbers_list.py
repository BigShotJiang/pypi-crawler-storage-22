"""Unit tests for CLI numbers list command."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any
from unittest.mock import AsyncMock

import pytest

from teams_phone.cli.main import app
from teams_phone.models import AssignmentStatus, NumberType
from tests.conftest import CliRunner
from tests.fixtures import make_number


if TYPE_CHECKING:
    pass

runner = CliRunner()


class TestNumbersListCommand:
    """Tests for numbers list command."""

    @pytest.mark.unit
    def test_list_shows_in_help(self) -> None:
        """list command appears in numbers help."""
        result = runner.invoke(app, ["numbers", "--help"])
        assert result.exit_code == 0
        assert "list" in result.stdout

    @pytest.mark.unit
    def test_list_empty(self, mock_number_service: dict[str, Any]) -> None:
        """list shows empty message when no numbers found."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])

        result = runner.invoke(app, ["numbers", "list"])
        assert result.exit_code == 0
        assert "No numbers found" in result.stdout

    @pytest.mark.unit
    def test_list_shows_numbers(self, mock_number_service: dict[str, Any]) -> None:
        """list shows numbers in table format."""
        numbers = [
            make_number(telephone_number="+14255551001", city="Seattle"),
            make_number(telephone_number="+14255551002", city="Portland"),
        ]
        mock_number_service["number_service"].list_numbers = AsyncMock(
            return_value=numbers
        )

        result = runner.invoke(app, ["--no-color", "numbers", "list"])
        assert result.exit_code == 0
        assert "+14255551001" in result.stdout
        assert "+14255551002" in result.stdout
        assert "Seattle" in result.stdout
        assert "Portland" in result.stdout

    @pytest.mark.unit
    def test_list_json_output(self, mock_number_service: dict[str, Any]) -> None:
        """list outputs valid JSON with --json flag."""
        numbers = [make_number()]
        mock_number_service["number_service"].list_numbers = AsyncMock(
            return_value=numbers
        )

        result = runner.invoke(app, ["--json", "numbers", "list"])
        assert result.exit_code == 0
        data = json.loads(result.stdout)
        assert len(data) == 1
        assert data[0]["telephone_number"] == "+14255551234"
        assert data[0]["number_type"] == "directRouting"
        assert data[0]["assignment_status"] == "unassigned"

    @pytest.mark.unit
    def test_list_json_empty(self, mock_number_service: dict[str, Any]) -> None:
        """list outputs empty JSON array when no numbers."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])

        result = runner.invoke(app, ["--json", "numbers", "list"])
        assert result.exit_code == 0
        data = json.loads(result.stdout)
        assert data == []

    @pytest.mark.unit
    def test_list_with_status_filter(self, mock_number_service: dict[str, Any]) -> None:
        """list passes status filter to service."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])

        result = runner.invoke(app, ["numbers", "list", "--status", "unassigned"])
        assert result.exit_code == 0
        mock_number_service["number_service"].list_numbers.assert_called_once()
        call_kwargs = mock_number_service["number_service"].list_numbers.call_args[1]
        assert call_kwargs["status"] == AssignmentStatus.UNASSIGNED

    @pytest.mark.unit
    def test_list_with_type_filter(self, mock_number_service: dict[str, Any]) -> None:
        """list passes type filter to service."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])

        result = runner.invoke(app, ["numbers", "list", "--type", "callingPlan"])
        assert result.exit_code == 0
        mock_number_service["number_service"].list_numbers.assert_called_once()
        call_kwargs = mock_number_service["number_service"].list_numbers.call_args[1]
        assert call_kwargs["number_type"] == NumberType.CALLING_PLAN

    @pytest.mark.unit
    def test_list_with_city_filter(self, mock_number_service: dict[str, Any]) -> None:
        """list passes city filter to service."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])

        result = runner.invoke(app, ["numbers", "list", "--city", "Seattle"])
        assert result.exit_code == 0
        mock_number_service["number_service"].list_numbers.assert_called_once()
        call_kwargs = mock_number_service["number_service"].list_numbers.call_args[1]
        assert call_kwargs["city"] == "Seattle"

    @pytest.mark.unit
    def test_list_with_limit(self, mock_number_service: dict[str, Any]) -> None:
        """list passes limit to service."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])

        result = runner.invoke(app, ["numbers", "list", "--limit", "10"])
        assert result.exit_code == 0
        call_kwargs = mock_number_service["number_service"].list_numbers.call_args[1]
        assert call_kwargs["max_items"] == 10

    @pytest.mark.unit
    def test_list_with_all_flag(self, mock_number_service: dict[str, Any]) -> None:
        """list passes None max_items for --all flag."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])

        result = runner.invoke(app, ["numbers", "list", "--all"])
        assert result.exit_code == 0
        call_kwargs = mock_number_service["number_service"].list_numbers.call_args[1]
        assert call_kwargs["max_items"] is None

    @pytest.mark.unit
    def test_list_limit_and_all_mutually_exclusive(self) -> None:
        """list errors when both --limit and --all are specified."""
        result = runner.invoke(app, ["numbers", "list", "--limit", "10", "--all"])
        assert result.exit_code == 5  # ValidationError exit code
        assert "Cannot specify both --limit and --all" in result.stdout

    @pytest.mark.unit
    def test_list_default_limit(self, mock_number_service: dict[str, Any]) -> None:
        """list uses default limit of 100 when no limit specified."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])

        result = runner.invoke(app, ["numbers", "list"])
        assert result.exit_code == 0
        call_kwargs = mock_number_service["number_service"].list_numbers.call_args[1]
        assert call_kwargs["max_items"] == 100
