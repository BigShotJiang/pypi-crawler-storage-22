"""Unit tests for progress display during CLI numbers assign/unassign operations."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.models import AssignmentStatus, NumberType, OperationStatus
from tests.conftest import CliRunner
from tests.fixtures import make_location, make_number, make_operation, make_user


runner = CliRunner()


class TestProgressDisplay:
    """Tests for progress spinner display during assign/unassign operations."""

    @pytest.mark.unit
    def test_assign_wait_calls_on_progress_callback(self) -> None:
        """assign (default wait=True) passes on_progress callback to service."""
        mock_user = make_user(
            id="user-123",
            user_principal_name="john@contoso.com",
            display_name="John Smith",
        )
        mock_location = make_location(location_id="loc-123", description="Seattle HQ")
        mock_operation = make_operation(id="op-123", status=OperationStatus.SUCCEEDED)
        captured_on_progress: list[object] = []

        async def capture_on_progress(
            user_id: str,
            phone_number: str,
            number_type: NumberType,
            *,
            location_id: str | None = None,
            wait: bool = True,
            on_progress: object = None,
            timeout: int = 60,
        ) -> object:
            captured_on_progress.append(on_progress)
            return mock_operation

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
            patch("teams_phone.cli.numbers.LocationService") as mock_ls_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(return_value=mock_user)
            mock_us_class.return_value = mock_user_service

            mock_location_service = MagicMock()
            mock_location_service.validate_location = MagicMock(
                return_value=mock_location
            )
            mock_ls_class.return_value = mock_location_service

            mock_number_service = MagicMock()
            mock_number_service.assign_number = AsyncMock(
                side_effect=capture_on_progress
            )
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "assign",
                    "john@contoso.com",
                    "+14255551234",
                    "--location",
                    "Seattle HQ",
                    "--force",
                ],
            )
            assert result.exit_code == 0
            # Verify on_progress callback was passed (not None)
            assert len(captured_on_progress) == 1
            assert captured_on_progress[0] is not None

    @pytest.mark.unit
    def test_assign_json_mode_no_progress_callback(self) -> None:
        """assign --json does not use progress callback (silent mode)."""
        mock_user = make_user(
            id="user-123",
            user_principal_name="john@contoso.com",
            display_name="John Smith",
        )
        mock_location = make_location(location_id="loc-123", description="Seattle HQ")
        mock_operation = make_operation(id="op-123", status=OperationStatus.SUCCEEDED)
        captured_on_progress: list[object] = []

        async def capture_on_progress(
            user_id: str,
            phone_number: str,
            number_type: NumberType,
            *,
            location_id: str | None = None,
            wait: bool = True,
            on_progress: object = None,
            timeout: int = 60,
        ) -> object:
            captured_on_progress.append(on_progress)
            return mock_operation

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
            patch("teams_phone.cli.numbers.LocationService") as mock_ls_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(return_value=mock_user)
            mock_us_class.return_value = mock_user_service

            mock_location_service = MagicMock()
            mock_location_service.validate_location = MagicMock(
                return_value=mock_location
            )
            mock_ls_class.return_value = mock_location_service

            mock_number_service = MagicMock()
            mock_number_service.assign_number = AsyncMock(
                side_effect=capture_on_progress
            )
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                [
                    "--json",
                    "numbers",
                    "assign",
                    "john@contoso.com",
                    "+14255551234",
                    "--location",
                    "Seattle HQ",
                ],
            )
            assert result.exit_code == 0
            # In JSON mode, on_progress should be None (no spinner)
            assert len(captured_on_progress) == 1
            assert captured_on_progress[0] is None

    @pytest.mark.unit
    def test_unassign_wait_calls_on_progress_callback(self) -> None:
        """unassign (default wait=True) passes on_progress callback to service."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )
        mock_operation = make_operation(id="op-123", status=OperationStatus.SUCCEEDED)
        captured_on_progress: list[object] = []

        async def capture_on_progress(
            phone_number: str,
            number_type: NumberType,
            *,
            wait: bool = True,
            on_progress: object = None,
            timeout: int = 60,
        ) -> object:
            captured_on_progress.append(on_progress)
            return mock_operation

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_number_service.unassign_number = AsyncMock(
                side_effect=capture_on_progress
            )
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                ["--no-color", "numbers", "unassign", "+14255551234", "--force"],
            )
            assert result.exit_code == 0
            # Verify on_progress callback was passed (not None)
            assert len(captured_on_progress) == 1
            assert captured_on_progress[0] is not None

    @pytest.mark.unit
    def test_unassign_json_mode_no_progress_callback(self) -> None:
        """unassign --json does not use progress callback (silent mode)."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )
        mock_operation = make_operation(id="op-123", status=OperationStatus.SUCCEEDED)
        captured_on_progress: list[object] = []

        async def capture_on_progress(
            phone_number: str,
            number_type: NumberType,
            *,
            wait: bool = True,
            on_progress: object = None,
            timeout: int = 60,
        ) -> object:
            captured_on_progress.append(on_progress)
            return mock_operation

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_number_service.unassign_number = AsyncMock(
                side_effect=capture_on_progress
            )
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                ["--json", "numbers", "unassign", "+14255551234"],
            )
            assert result.exit_code == 0
            # In JSON mode, on_progress should be None (no spinner)
            assert len(captured_on_progress) == 1
            assert captured_on_progress[0] is None
