"""Unit tests for CLI numbers show and search commands."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.exceptions import NotFoundError
from teams_phone.models import AssignmentStatus, NumberType
from tests.conftest import CliRunner
from tests.fixtures import make_number


if TYPE_CHECKING:
    pass

runner = CliRunner()


class TestNumbersShowCommand:
    """Tests for numbers show command."""

    @pytest.mark.unit
    def test_show_shows_in_help(self) -> None:
        """show command appears in numbers help."""
        result = runner.invoke(app, ["numbers", "--help"])
        assert result.exit_code == 0
        assert "show" in result.stdout

    @pytest.mark.unit
    def test_show_requires_number_argument(self) -> None:
        """show requires number argument."""
        result = runner.invoke(app, ["numbers", "show"])
        assert result.exit_code == 2
        output = result.stdout + (result.stderr or "")
        assert (
            "NUMBER" in output or "Missing argument" in output or result.exit_code == 2
        )

    @pytest.mark.unit
    def test_show_displays_number(self) -> None:
        """show displays number details."""
        number = make_number(
            telephone_number="+14255551234",
            city="Seattle",
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_service = MagicMock()
            mock_service.get_number = AsyncMock(return_value=number)
            mock_ns_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "numbers", "show", "+14255551234"]
            )
            assert result.exit_code == 0
            # Phone numbers may have ANSI formatting, check for digits
            assert "14255551234" in result.stdout
            assert "Seattle" in result.stdout
            assert "Assigned" in result.stdout
            assert "user-" in result.stdout

    @pytest.mark.unit
    def test_show_json_output(self) -> None:
        """show outputs valid JSON with --json flag."""
        number = make_number()

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_service = MagicMock()
            mock_service.get_number = AsyncMock(return_value=number)
            mock_ns_class.return_value = mock_service

            result = runner.invoke(app, ["--json", "numbers", "show", "+14255551234"])
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data["telephone_number"] == "+14255551234"
            assert data["number_type"] == "directRouting"
            assert data["city"] == "Seattle"

    @pytest.mark.unit
    def test_show_not_found(self) -> None:
        """show exits with error when number not found."""
        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_service = MagicMock()
            mock_service.get_number = AsyncMock(
                side_effect=NotFoundError(
                    "Phone number '+19999999999' not found",
                    remediation="Verify the phone number is in your inventory.",
                )
            )
            mock_ns_class.return_value = mock_service

            result = runner.invoke(app, ["numbers", "show", "+19999999999"])
            assert result.exit_code == 4  # NotFoundError exit code

    @pytest.mark.unit
    def test_show_displays_unassigned_number(self) -> None:
        """show displays unassigned number correctly."""
        number = make_number(
            assignment_status=AssignmentStatus.UNASSIGNED,
            assignment_target_id=None,
        )

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_service = MagicMock()
            mock_service.get_number = AsyncMock(return_value=number)
            mock_ns_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "numbers", "show", "+14255551234"]
            )
            assert result.exit_code == 0
            assert "Unassigned" in result.stdout

    @pytest.mark.unit
    def test_show_displays_calling_plan_type(self) -> None:
        """show displays calling plan number type correctly."""
        number = make_number(number_type=NumberType.CALLING_PLAN)

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_service = MagicMock()
            mock_service.get_number = AsyncMock(return_value=number)
            mock_ns_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "numbers", "show", "+14255551234"]
            )
            assert result.exit_code == 0
            assert "Calling Plan" in result.stdout


class TestNumbersSearchCommand:
    """Tests for numbers search command."""

    @pytest.mark.unit
    def test_search_shows_in_help(self) -> None:
        """search command appears in numbers help."""
        result = runner.invoke(app, ["numbers", "--help"])
        assert result.exit_code == 0
        assert "search" in result.stdout

    @pytest.mark.unit
    def test_search_requires_pattern_argument(self) -> None:
        """search requires pattern argument."""
        result = runner.invoke(app, ["numbers", "search"])
        assert result.exit_code == 2
        output = result.stdout + (result.stderr or "")
        assert (
            "PATTERN" in output or "Missing argument" in output or result.exit_code == 2
        )

    @pytest.mark.unit
    def test_search_shows_results(self) -> None:
        """search shows matching numbers."""
        numbers = [
            make_number(telephone_number="+12065551001"),
            make_number(telephone_number="+12065551002"),
        ]

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_service = MagicMock()
            mock_service.search_numbers = AsyncMock(return_value=numbers)
            mock_ns_class.return_value = mock_service

            result = runner.invoke(app, ["--no-color", "numbers", "search", "206*"])
            assert result.exit_code == 0
            assert "+12065551001" in result.stdout
            assert "+12065551002" in result.stdout
            assert "206*" in result.stdout  # Search pattern in title

    @pytest.mark.unit
    def test_search_no_results(self) -> None:
        """search shows message when no numbers found."""
        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_service = MagicMock()
            mock_service.search_numbers = AsyncMock(return_value=[])
            mock_ns_class.return_value = mock_service

            result = runner.invoke(app, ["--no-color", "numbers", "search", "999*"])
            assert result.exit_code == 0
            assert "No numbers found matching" in result.stdout
            assert "999*" in result.stdout

    @pytest.mark.unit
    def test_search_json_output(self) -> None:
        """search outputs valid JSON with --json flag."""
        numbers = [make_number()]

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_service = MagicMock()
            mock_service.search_numbers = AsyncMock(return_value=numbers)
            mock_ns_class.return_value = mock_service

            result = runner.invoke(app, ["--json", "numbers", "search", "425*"])
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert len(data) == 1
            assert data[0]["telephone_number"] == "+14255551234"

    @pytest.mark.unit
    def test_search_with_limit(self) -> None:
        """search passes limit to service."""
        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_service = MagicMock()
            mock_service.search_numbers = AsyncMock(return_value=[])
            mock_ns_class.return_value = mock_service

            result = runner.invoke(app, ["numbers", "search", "206*", "--limit", "10"])
            assert result.exit_code == 0
            mock_service.search_numbers.assert_called_once()
            call_kwargs = mock_service.search_numbers.call_args[1]
            assert call_kwargs["max_results"] == 10

    @pytest.mark.unit
    def test_search_default_limit(self) -> None:
        """search uses default limit of 25."""
        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_service = MagicMock()
            mock_service.search_numbers = AsyncMock(return_value=[])
            mock_ns_class.return_value = mock_service

            result = runner.invoke(app, ["numbers", "search", "206*"])
            assert result.exit_code == 0
            call_kwargs = mock_service.search_numbers.call_args[1]
            assert call_kwargs["max_results"] == 25
