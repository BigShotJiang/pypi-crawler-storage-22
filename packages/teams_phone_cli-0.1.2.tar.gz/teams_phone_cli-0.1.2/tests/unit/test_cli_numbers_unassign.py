"""Unit tests for CLI numbers unassign command."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.exceptions import NotFoundError
from teams_phone.models import AssignmentStatus, OperationStatus
from tests.conftest import CliRunner
from tests.fixtures import make_number, make_operation


runner = CliRunner()


class TestNumbersUnassignCommand:
    """Tests for numbers unassign command."""

    @pytest.mark.unit
    def test_unassign_shows_in_help(self) -> None:
        """unassign command appears in numbers help."""
        result = runner.invoke(app, ["numbers", "--help"])
        assert result.exit_code == 0
        assert "unassign" in result.stdout

    @pytest.mark.unit
    def test_unassign_requires_number_argument(self) -> None:
        """unassign requires number argument."""
        result = runner.invoke(app, ["numbers", "unassign"])
        assert result.exit_code == 2
        output = result.stdout + (result.stderr or "")
        assert (
            "NUMBER" in output or "Missing argument" in output or result.exit_code == 2
        )

    @pytest.mark.unit
    def test_unassign_with_confirmation_prompt(self) -> None:
        """unassign shows confirmation prompt and can be cancelled."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                ["--no-color", "numbers", "unassign", "+14255551234"],
                input="n\n",  # Decline confirmation
            )
            assert result.exit_code == 0
            assert "cancelled" in result.stdout

    @pytest.mark.unit
    def test_unassign_with_force_skips_confirmation(self) -> None:
        """unassign --force skips confirmation prompt."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )
        mock_operation = make_operation(id="op-123", status=OperationStatus.SUCCEEDED)

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_number_service.unassign_number = AsyncMock(return_value=mock_operation)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                ["--no-color", "numbers", "unassign", "+14255551234", "--force"],
            )
            assert result.exit_code == 0
            assert "Unassigned" in result.stdout
            # Verify no prompt was shown (no "Proceed" in output)
            assert "Proceed" not in result.stdout

    @pytest.mark.unit
    def test_unassign_on_already_unassigned_number_shows_error(self) -> None:
        """unassign on unassigned number shows validation error."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.UNASSIGNED,
            assignment_target_id=None,
        )

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                ["--no-color", "numbers", "unassign", "+14255551234", "--force"],
            )
            # ValidationError exit code
            assert result.exit_code == 5
            assert "not assigned" in result.stdout

    @pytest.mark.unit
    def test_unassign_dry_run_preview_output(self) -> None:
        """unassign --dry-run shows preview without making changes."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                ["--no-color", "numbers", "unassign", "+14255551234", "--dry-run"],
            )
            assert result.exit_code == 0
            assert "Dry Run Preview" in result.stdout
            # Phone numbers and IDs may have ANSI escape codes
            assert "14255551234" in result.stdout
            assert "user-" in result.stdout and "123" in result.stdout
            assert "No changes made" in result.stdout

            # Verify unassign_number was not called
            mock_number_service.unassign_number.assert_not_called()

    @pytest.mark.unit
    def test_unassign_no_wait_returns_immediately(self) -> None:
        """unassign --no-wait returns operation ID without waiting."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )
        mock_operation = make_operation(id="op-123", status=OperationStatus.NOT_STARTED)

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_number_service.unassign_number = AsyncMock(return_value=mock_operation)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "unassign",
                    "+14255551234",
                    "--force",
                    "--no-wait",
                ],
            )
            assert result.exit_code == 0
            # Operation ID may have ANSI escape codes
            assert "op-" in result.stdout
            assert "123" in result.stdout
            assert "initiated" in result.stdout

    @pytest.mark.unit
    def test_unassign_json_output_format(self) -> None:
        """unassign --json outputs valid JSON structure."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )
        mock_operation = make_operation(id="op-123", status=OperationStatus.SUCCEEDED)

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_number_service.unassign_number = AsyncMock(return_value=mock_operation)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                ["--json", "numbers", "unassign", "+14255551234"],
            )
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data["status"] == "succeeded"
            assert data["operation_id"] == "op-123"
            assert data["phone_number"] == "+14255551234"
            assert data["number_type"] == "directRouting"
            assert data["previous_assignee"] == "user-123"

    @pytest.mark.unit
    def test_unassign_success_output(self) -> None:
        """unassign success shows appropriate message."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )
        mock_operation = make_operation(id="op-123", status=OperationStatus.SUCCEEDED)

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_number_service.unassign_number = AsyncMock(return_value=mock_operation)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                ["--no-color", "numbers", "unassign", "+14255551234", "--force"],
            )
            assert result.exit_code == 0
            assert "Unassigned" in result.stdout
            # Phone numbers may have ANSI escape codes
            assert "14255551234" in result.stdout

    @pytest.mark.unit
    def test_unassign_failed_operation_exits_with_error(self) -> None:
        """unassign with failed operation exits with error code."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )
        mock_operation = make_operation(id="op-123", status=OperationStatus.FAILED)

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_number_service.unassign_number = AsyncMock(return_value=mock_operation)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                ["--no-color", "numbers", "unassign", "+14255551234", "--force"],
            )
            assert result.exit_code == 1
            assert "failed" in result.stdout

    @pytest.mark.unit
    def test_unassign_number_not_found_shows_error(self) -> None:
        """unassign with unknown number shows not found error."""
        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(
                side_effect=NotFoundError(
                    "Phone number '+19999999999' not found",
                    remediation="Verify the number exists in your inventory.",
                )
            )
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                ["--no-color", "numbers", "unassign", "+19999999999", "--force"],
            )
            assert result.exit_code == 4  # NotFoundError exit code
            assert "not found" in result.stdout

    @pytest.mark.unit
    def test_unassign_dry_run_json_output(self) -> None:
        """unassign --dry-run --json outputs valid JSON."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                ["--json", "numbers", "unassign", "+14255551234", "--dry-run"],
            )
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data["dry_run"] is True
            assert data["phone_number"] == "+14255551234"
            assert data["number_type"] == "directRouting"
            assert data["current_assignee"] == "user-123"
