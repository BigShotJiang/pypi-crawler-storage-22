"""Unit tests for CLI numbers update command."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.models import AssignmentStatus
from tests.conftest import CliRunner
from tests.fixtures import make_location, make_number


runner = CliRunner()


class TestNumbersUpdateCommand:
    """Tests for numbers update command."""

    @pytest.mark.unit
    def test_update_shows_in_help(self) -> None:
        """update command appears in numbers help."""
        result = runner.invoke(app, ["numbers", "--help"])
        assert result.exit_code == 0
        assert "update" in result.stdout

    @pytest.mark.unit
    def test_update_requires_number_argument(self) -> None:
        """update requires number argument."""
        result = runner.invoke(app, ["numbers", "update"])
        assert result.exit_code == 2
        output = result.stdout + (result.stderr or "")
        assert (
            "NUMBER" in output or "Missing argument" in output or result.exit_code == 2
        )

    @pytest.mark.unit
    def test_update_requires_at_least_one_option(self) -> None:
        """update requires at least one update option."""
        result = runner.invoke(
            app,
            ["numbers", "update", "+14255551234"],
        )
        assert result.exit_code == 5  # ValidationError exit code
        assert "No update parameters specified" in result.stdout

    @pytest.mark.unit
    def test_update_location_and_clear_location_mutually_exclusive(self) -> None:
        """update errors when both --location and --clear-location specified."""
        result = runner.invoke(
            app,
            [
                "numbers",
                "update",
                "+14255551234",
                "--location",
                "Seattle HQ",
                "--clear-location",
            ],
        )
        assert result.exit_code == 5
        assert "Cannot specify both --location and --clear-location" in result.stdout

    @pytest.mark.unit
    def test_update_network_site_and_clear_mutually_exclusive(self) -> None:
        """update errors when both --network-site and --clear-network-site specified."""
        result = runner.invoke(
            app,
            [
                "numbers",
                "update",
                "+14255551234",
                "--network-site",
                "Site-001",
                "--clear-network-site",
            ],
        )
        assert result.exit_code == 5
        assert (
            "Cannot specify both --network-site and --clear-network-site"
            in result.stdout
        )

    @pytest.mark.unit
    def test_update_on_unassigned_number_shows_error(self) -> None:
        """update on unassigned number shows validation error."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.UNASSIGNED,
            assignment_target_id=None,
        )

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "update",
                    "+14255551234",
                    "--clear-location",
                    "--force",
                ],
            )
            # ValidationError exit code
            assert result.exit_code == 5
            assert "not assigned" in result.stdout

    @pytest.mark.unit
    def test_update_dry_run_with_location(self) -> None:
        """update --dry-run shows preview with location."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )
        mock_location = make_location(location_id="loc-123", description="Seattle HQ")

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
            patch("teams_phone.cli.numbers.LocationService") as mock_ls_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_ns_class.return_value = mock_number_service

            mock_location_service = MagicMock()
            mock_location_service.validate_location = MagicMock(
                return_value=mock_location
            )
            mock_ls_class.return_value = mock_location_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "update",
                    "+14255551234",
                    "--location",
                    "Seattle HQ",
                    "--dry-run",
                ],
            )
            assert result.exit_code == 0
            assert "Dry Run Preview" in result.stdout
            assert "14255551234" in result.stdout
            assert "Seattle" in result.stdout
            assert "No changes made" in result.stdout

            # Verify update_number was not called
            mock_number_service.update_number.assert_not_called()

    @pytest.mark.unit
    def test_update_dry_run_with_clear_location(self) -> None:
        """update --dry-run shows preview with clear location."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "update",
                    "+14255551234",
                    "--clear-location",
                    "--dry-run",
                ],
            )
            assert result.exit_code == 0
            assert "Dry Run Preview" in result.stdout
            assert "Will be cleared" in result.stdout

    @pytest.mark.unit
    def test_update_with_confirmation_prompt(self) -> None:
        """update shows confirmation prompt and can be cancelled."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                ["--no-color", "numbers", "update", "+14255551234", "--clear-location"],
                input="n\n",  # Decline confirmation
            )
            assert result.exit_code == 0
            assert "cancelled" in result.stdout

    @pytest.mark.unit
    def test_update_with_force_skips_confirmation(self) -> None:
        """update --force skips confirmation prompt."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_number_service.update_number = AsyncMock(return_value=None)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "update",
                    "+14255551234",
                    "--clear-location",
                    "--force",
                ],
            )
            assert result.exit_code == 0
            assert "Updated" in result.stdout
            # Verify no prompt was shown
            assert "Proceed" not in result.stdout

    @pytest.mark.unit
    def test_update_json_output_format(self) -> None:
        """update --json outputs valid JSON structure."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_number_service.update_number = AsyncMock(return_value=None)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                ["--json", "numbers", "update", "+14255551234", "--clear-location"],
            )
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data["status"] == "success"
            assert data["phone_number"] == "+14255551234"
            assert data["number_type"] == "directRouting"
            assert data["clear_location"] is True

    @pytest.mark.unit
    def test_update_json_dry_run_output(self) -> None:
        """update --json --dry-run outputs preview JSON."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                [
                    "--json",
                    "numbers",
                    "update",
                    "+14255551234",
                    "--network-site",
                    "Site-001",
                    "--dry-run",
                ],
            )
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data["dry_run"] is True
            assert data["phone_number"] == "+14255551234"
            assert data["network_site_id"] == "Site-001"

    @pytest.mark.unit
    def test_update_calls_service_with_correct_parameters(self) -> None:
        """update passes correct parameters to NumberService."""
        mock_number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )
        mock_location = make_location(location_id="loc-123", description="Seattle HQ")

        with (
            patch("teams_phone.cli.helpers.CacheManager"),
            patch("teams_phone.cli.helpers.AuthService"),
            patch("teams_phone.cli.helpers.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
            patch("teams_phone.cli.numbers.LocationService") as mock_ls_class,
        ):
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_number_service = MagicMock()
            mock_number_service.get_number = AsyncMock(return_value=mock_number)
            mock_number_service.update_number = AsyncMock(return_value=None)
            mock_ns_class.return_value = mock_number_service

            mock_location_service = MagicMock()
            mock_location_service.validate_location = MagicMock(
                return_value=mock_location
            )
            mock_ls_class.return_value = mock_location_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "numbers",
                    "update",
                    "+14255551234",
                    "--location",
                    "Seattle HQ",
                    "--force",
                ],
            )
            assert result.exit_code == 0

            # Verify update_number was called with correct arguments
            mock_number_service.update_number.assert_called_once()
            call_kwargs = mock_number_service.update_number.call_args[1]
            assert call_kwargs["phone_number"] == "+14255551234"
            assert call_kwargs["location_id"] == "loc-123"
            assert call_kwargs["clear_location"] is False
