"""Unit tests for CLI policies assign command."""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.exceptions import NotFoundError, ValidationError
from tests.conftest import CliRunner
from tests.fixtures import make_policy, make_user


runner = CliRunner()


class TestPoliciesAssignCommand:
    """Tests for policies assign command."""

    @pytest.mark.unit
    def test_assign_shows_in_help(self) -> None:
        """assign command appears in policies help."""
        result = runner.invoke(app, ["policies", "--help"])
        assert result.exit_code == 0
        assert "assign" in result.stdout

    @pytest.mark.unit
    def test_assign_requires_all_arguments(self) -> None:
        """assign requires user, policy-type, and policy-name arguments."""
        result = runner.invoke(app, ["policies", "assign"])
        assert result.exit_code == 2

        result = runner.invoke(app, ["policies", "assign", "john@contoso.com"])
        assert result.exit_code == 2

        result = runner.invoke(
            app, ["policies", "assign", "john@contoso.com", "calling"]
        )
        assert result.exit_code == 2

    @pytest.mark.unit
    def test_assign_dry_run(self) -> None:
        """assign with --dry-run shows preview without making changes."""
        user = make_user(
            user_principal_name="john.doe@contoso.com",
            display_name="John Doe",
            is_enterprise_voice_enabled=True,
        )
        policy = make_policy()

        with (
            patch("teams_phone.cli.policies._run_async") as mock_run_async,
            patch("teams_phone.cli.policies._get_sync_service") as mock_get_service,
        ):
            mock_run_async.return_value = (
                (user.id, user.display_name, user.user_principal_name),
                MagicMock(),
            )
            mock_service = MagicMock()
            mock_service.validate_policy.return_value = policy
            mock_get_service.return_value = mock_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "policies",
                    "assign",
                    "john@contoso.com",
                    "calling",
                    "AllowCalling",
                    "--dry-run",
                ],
            )
            assert result.exit_code == 0
            assert "Dry Run Preview" in result.stdout
            assert "John Doe" in result.stdout
            assert "AllowCalling" in result.stdout
            assert "No changes made" in result.stdout

    @pytest.mark.unit
    def test_assign_dry_run_json(self) -> None:
        """assign with --dry-run --json outputs valid JSON."""
        user = make_user(
            user_principal_name="john.doe@contoso.com",
            display_name="John Doe",
            is_enterprise_voice_enabled=True,
        )
        policy = make_policy()

        with (
            patch("teams_phone.cli.policies._run_async") as mock_run_async,
            patch("teams_phone.cli.policies._get_sync_service") as mock_get_service,
        ):
            mock_run_async.return_value = (
                (user.id, user.display_name, user.user_principal_name),
                MagicMock(),
            )
            mock_service = MagicMock()
            mock_service.validate_policy.return_value = policy
            mock_get_service.return_value = mock_service

            result = runner.invoke(
                app,
                [
                    "--json",
                    "policies",
                    "assign",
                    "john@contoso.com",
                    "calling",
                    "AllowCalling",
                    "--dry-run",
                ],
            )
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data["dry_run"] is True
            assert data["display_name"] == "John Doe"
            assert data["policy_type"] == "TeamsCallingPolicy"
            assert data["policy_name"] == "AllowCalling"

    @pytest.mark.unit
    def test_assign_success_with_force(self) -> None:
        """assign with --force skips confirmation and succeeds."""
        user = make_user(
            user_principal_name="john.doe@contoso.com",
            display_name="John Doe",
            is_enterprise_voice_enabled=True,
        )
        policy = make_policy()

        call_count = [0]

        def mock_run_async_side_effect(ctx: Any, coro_factory: Any) -> Any:
            call_count[0] += 1
            formatter = MagicMock()
            if call_count[0] == 1:
                # First call: resolve user
                return (
                    (user.id, user.display_name, user.user_principal_name),
                    formatter,
                )
            else:
                # Second call: assign policy
                return (None, formatter)

        with (
            patch(
                "teams_phone.cli.policies._run_async",
                side_effect=mock_run_async_side_effect,
            ),
            patch("teams_phone.cli.policies._get_sync_service") as mock_get_service,
        ):
            mock_service = MagicMock()
            mock_service.validate_policy.return_value = policy
            mock_get_service.return_value = mock_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "policies",
                    "assign",
                    "john@contoso.com",
                    "calling",
                    "AllowCalling",
                    "--force",
                ],
            )
            assert result.exit_code == 0
            assert "Assigned" in result.stdout
            assert "John Doe" in result.stdout

    @pytest.mark.unit
    def test_assign_success_json(self) -> None:
        """assign success outputs valid JSON with --json flag."""
        user = make_user(
            user_principal_name="john.doe@contoso.com",
            display_name="John Doe",
            is_enterprise_voice_enabled=True,
        )
        policy = make_policy()

        call_count = [0]

        def mock_run_async_side_effect(ctx: Any, coro_factory: Any) -> Any:
            call_count[0] += 1
            formatter = MagicMock()
            if call_count[0] == 1:
                return (
                    (user.id, user.display_name, user.user_principal_name),
                    formatter,
                )
            else:
                return (None, formatter)

        with (
            patch(
                "teams_phone.cli.policies._run_async",
                side_effect=mock_run_async_side_effect,
            ),
            patch("teams_phone.cli.policies._get_sync_service") as mock_get_service,
        ):
            mock_service = MagicMock()
            mock_service.validate_policy.return_value = policy
            mock_get_service.return_value = mock_service

            result = runner.invoke(
                app,
                [
                    "--json",
                    "policies",
                    "assign",
                    "john@contoso.com",
                    "calling",
                    "AllowCalling",
                ],
            )
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data["success"] is True
            assert data["display_name"] == "John Doe"
            assert data["policy_type"] == "TeamsCallingPolicy"

    @pytest.mark.unit
    def test_assign_user_not_found(self) -> None:
        """assign exits with error when user not found."""
        with patch("teams_phone.cli.policies._run_async") as mock_run_async:
            mock_run_async.side_effect = NotFoundError(
                "User 'nonexistent@contoso.com' not found",
                remediation="Verify the user identifier is correct.",
            )

            result = runner.invoke(
                app,
                [
                    "policies",
                    "assign",
                    "nonexistent@contoso.com",
                    "calling",
                    "AllowCalling",
                    "--force",
                ],
            )
            assert result.exit_code == 4  # NotFoundError exit code

    @pytest.mark.unit
    def test_assign_policy_not_found(self) -> None:
        """assign exits with error when policy not found."""
        user = make_user(
            user_principal_name="john.doe@contoso.com",
            display_name="John Doe",
            is_enterprise_voice_enabled=True,
        )

        with (
            patch("teams_phone.cli.policies._run_async") as mock_run_async,
            patch("teams_phone.cli.policies._get_sync_service") as mock_get_service,
        ):
            mock_run_async.return_value = (
                (user.id, user.display_name, user.user_principal_name),
                MagicMock(),
            )
            mock_service = MagicMock()
            mock_service.validate_policy.side_effect = NotFoundError(
                "Policy 'Nonexistent' of type 'TeamsCallingPolicy' not found",
                remediation="Use 'teams-phone policies list' to see available policies.",
            )
            mock_get_service.return_value = mock_service

            result = runner.invoke(
                app,
                [
                    "policies",
                    "assign",
                    "john@contoso.com",
                    "calling",
                    "Nonexistent",
                    "--force",
                ],
            )
            assert result.exit_code == 4  # NotFoundError exit code

    @pytest.mark.unit
    def test_assign_voicemail_policy_error(self) -> None:
        """assign raises validation error for voicemail policy."""
        user = make_user(
            user_principal_name="john.doe@contoso.com",
            display_name="John Doe",
            is_enterprise_voice_enabled=True,
        )
        policy = make_policy(policy_type="TeamsVoicemailPolicy")

        call_count = [0]

        def mock_run_async_side_effect(ctx: Any, coro_factory: Any) -> Any:
            call_count[0] += 1
            formatter = MagicMock()
            if call_count[0] == 1:
                return (
                    (user.id, user.display_name, user.user_principal_name),
                    formatter,
                )
            else:
                # This is the assign call - it should raise ValidationError
                raise ValidationError(
                    "Policy type 'TeamsVoicemailPolicy' is not supported for batch assignment",
                    remediation="Use PowerShell cmdlet Grant-CsTeamsVoicemailPolicy instead.",
                )

        with (
            patch(
                "teams_phone.cli.policies._run_async",
                side_effect=mock_run_async_side_effect,
            ),
            patch("teams_phone.cli.policies._get_sync_service") as mock_get_service,
        ):
            mock_service = MagicMock()
            mock_service.validate_policy.return_value = policy
            mock_get_service.return_value = mock_service

            result = runner.invoke(
                app,
                [
                    "policies",
                    "assign",
                    "john@contoso.com",
                    "voicemail",
                    "VoicemailPolicy",
                    "--force",
                ],
            )
            assert result.exit_code == 5  # ValidationError exit code

    @pytest.mark.unit
    def test_assign_policy_type_resolution(self) -> None:
        """assign correctly resolves CLI policy type aliases."""
        user = make_user(
            user_principal_name="john.doe@contoso.com",
            display_name="John Doe",
            is_enterprise_voice_enabled=True,
        )
        policy = make_policy(policy_type="CallingLineIdentity")

        call_count = [0]

        def mock_run_async_side_effect(ctx: Any, coro_factory: Any) -> Any:
            call_count[0] += 1
            formatter = MagicMock()
            if call_count[0] == 1:
                return (
                    (user.id, user.display_name, user.user_principal_name),
                    formatter,
                )
            else:
                return (None, formatter)

        with (
            patch(
                "teams_phone.cli.policies._run_async",
                side_effect=mock_run_async_side_effect,
            ),
            patch("teams_phone.cli.policies._get_sync_service") as mock_get_service,
        ):
            mock_service = MagicMock()
            mock_service.validate_policy.return_value = policy
            mock_get_service.return_value = mock_service

            result = runner.invoke(
                app,
                [
                    "--json",
                    "policies",
                    "assign",
                    "john@contoso.com",
                    "caller-id",
                    "CallerIdPolicy",
                ],
            )
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data["policy_type"] == "CallingLineIdentity"
