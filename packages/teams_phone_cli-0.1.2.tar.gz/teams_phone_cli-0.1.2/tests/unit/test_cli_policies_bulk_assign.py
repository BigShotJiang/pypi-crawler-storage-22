"""Unit tests for CLI policies bulk-assign command."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.exceptions import NotFoundError
from tests.conftest import CliRunner
from tests.fixtures import make_policy, make_user


if TYPE_CHECKING:
    from pathlib import Path


runner = CliRunner()


class TestPoliciesBulkAssignCommand:
    """Tests for policies bulk-assign command."""

    @pytest.mark.unit
    def test_bulk_assign_shows_in_help(self) -> None:
        """bulk-assign command appears in policies help."""
        result = runner.invoke(app, ["policies", "--help"])
        assert result.exit_code == 0
        assert "bulk-assign" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_requires_csv_file_argument(self) -> None:
        """bulk-assign requires csv_file argument."""
        result = runner.invoke(app, ["policies", "bulk-assign"])
        assert result.exit_code == 2
        output = result.stdout + (result.stderr or "")
        assert (
            "CSV_FILE" in output
            or "Missing argument" in output
            or result.exit_code == 2
        )

    @pytest.mark.unit
    def test_bulk_assign_dry_run_valid_csv(self, tmp_path: Any) -> None:
        """bulk-assign --dry-run shows validation summary for valid CSV."""
        csv_content = """user,policy_type,policy_name
john@contoso.com,calling,AllowCalling
jane@contoso.com,dial-plan,US-DialPlan"""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        policy1 = make_policy(
            policy_type="TeamsCallingPolicy", policy_name="AllowCalling"
        )
        policy2 = make_policy(policy_type="TenantDialPlan", policy_name="US-DialPlan")

        with patch("teams_phone.cli.policies._get_sync_service") as mock_get_service:
            mock_service = MagicMock()
            mock_service.get_staleness_warning.return_value = None
            mock_service.validate_policy.side_effect = [policy1, policy2]
            mock_get_service.return_value = mock_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "policies",
                    "bulk-assign",
                    str(csv_file),
                    "--dry-run",
                ],
            )
            assert result.exit_code == 0
            assert "Validation Summary" in result.stdout
            assert "Total rows:" in result.stdout
            assert "Valid:" in result.stdout
            assert "Errors:" in result.stdout
            assert "Dry run complete" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_dry_run_json(self, tmp_path: Any) -> None:
        """bulk-assign --dry-run --json outputs valid JSON."""
        csv_content = """user,policy_type,policy_name
john@contoso.com,calling,AllowCalling"""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        policy = make_policy(
            policy_type="TeamsCallingPolicy", policy_name="AllowCalling"
        )

        with patch("teams_phone.cli.policies._get_sync_service") as mock_get_service:
            mock_service = MagicMock()
            mock_service.get_staleness_warning.return_value = None
            mock_service.validate_policy.return_value = policy
            mock_get_service.return_value = mock_service

            result = runner.invoke(
                app,
                [
                    "--json",
                    "policies",
                    "bulk-assign",
                    str(csv_file),
                    "--dry-run",
                ],
            )
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data["dry_run"] is True
            assert data["valid_count"] == 1
            assert data["error_count"] == 0
            assert len(data["rows"]) == 1
            assert data["rows"][0]["valid"] is True

    @pytest.mark.unit
    def test_bulk_assign_validation_errors(self, tmp_path: Any) -> None:
        """bulk-assign shows validation errors for invalid policies."""
        csv_content = """user,policy_type,policy_name
john@contoso.com,calling,NonexistentPolicy"""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        with patch("teams_phone.cli.policies._get_sync_service") as mock_get_service:
            mock_service = MagicMock()
            mock_service.get_staleness_warning.return_value = None
            mock_service.validate_policy.side_effect = NotFoundError(
                "Policy 'NonexistentPolicy' of type 'TeamsCallingPolicy' not found"
            )
            mock_get_service.return_value = mock_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "policies",
                    "bulk-assign",
                    str(csv_file),
                    "--dry-run",
                ],
            )
            assert result.exit_code == 1  # Error exit code
            assert "Validation Errors" in result.stdout
            assert "NonexistentPolicy" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_voicemail_policy_rejected(self, tmp_path: Any) -> None:
        """bulk-assign rejects TeamsVoicemailPolicy with clear error."""
        csv_content = """user,policy_type,policy_name
john@contoso.com,voicemail,VoicemailPolicy"""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        with patch("teams_phone.cli.policies._get_sync_service") as mock_get_service:
            mock_service = MagicMock()
            mock_service.get_staleness_warning.return_value = None
            mock_get_service.return_value = mock_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "policies",
                    "bulk-assign",
                    str(csv_file),
                    "--dry-run",
                ],
            )
            assert result.exit_code == 1
            assert "TeamsVoicemailPolicy" in result.stdout
            assert "not supported" in result.stdout
            assert "PowerShell" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_invalid_policy_type(self, tmp_path: Any) -> None:
        """bulk-assign rejects invalid policy type."""
        csv_content = """user,policy_type,policy_name
john@contoso.com,invalid-type,SomePolicy"""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        with patch("teams_phone.cli.policies._get_sync_service") as mock_get_service:
            mock_service = MagicMock()
            mock_service.get_staleness_warning.return_value = None
            mock_get_service.return_value = mock_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "policies",
                    "bulk-assign",
                    str(csv_file),
                    "--dry-run",
                ],
            )
            # Exit code 1 due to validation errors in dry-run
            assert result.exit_code == 1
            assert "Invalid policy type" in result.stdout
            assert "invalid-type" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_resolves_policy_type_aliases(self, tmp_path: Any) -> None:
        """bulk-assign correctly resolves CLI policy type aliases."""
        csv_content = """user,policy_type,policy_name
john@contoso.com,caller-id,CallerIdPolicy"""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        policy = make_policy(
            policy_type="CallingLineIdentity", policy_name="CallerIdPolicy"
        )

        with patch("teams_phone.cli.policies._get_sync_service") as mock_get_service:
            mock_service = MagicMock()
            mock_service.get_staleness_warning.return_value = None
            mock_service.validate_policy.return_value = policy
            mock_get_service.return_value = mock_service

            result = runner.invoke(
                app,
                [
                    "--json",
                    "policies",
                    "bulk-assign",
                    str(csv_file),
                    "--dry-run",
                ],
            )
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            # Verify the resolved type is CallingLineIdentity
            assert data["rows"][0]["policy_type"] == "CallingLineIdentity"

    @pytest.mark.unit
    def test_bulk_assign_empty_csv(self, tmp_path: Any) -> None:
        """bulk-assign handles CSV with only header row."""
        csv_content = """user,policy_type,policy_name"""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        result = runner.invoke(
            app,
            [
                "--no-color",
                "policies",
                "bulk-assign",
                str(csv_file),
                "--dry-run",
            ],
        )
        assert result.exit_code == 0
        assert "No data rows found" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_missing_columns(self, tmp_path: Any) -> None:
        """bulk-assign rejects CSV missing required columns."""
        csv_content = """user,policy_type
john@contoso.com,calling"""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        result = runner.invoke(
            app,
            [
                "--no-color",
                "policies",
                "bulk-assign",
                str(csv_file),
                "--dry-run",
            ],
        )
        assert result.exit_code == 5  # ValidationError exit code
        assert "policy_name" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_staleness_warning(self, tmp_path: Any) -> None:
        """bulk-assign shows staleness warning when cache is stale."""
        csv_content = """user,policy_type,policy_name
john@contoso.com,calling,AllowCalling"""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        policy = make_policy(
            policy_type="TeamsCallingPolicy", policy_name="AllowCalling"
        )

        with patch("teams_phone.cli.policies._get_sync_service") as mock_get_service:
            mock_service = MagicMock()
            mock_service.get_staleness_warning.return_value = (
                "Policy cache is 45 days old (threshold: 30 days). "
                "Consider refreshing by running the PowerShell export script."
            )
            mock_service.validate_policy.return_value = policy
            mock_get_service.return_value = mock_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "policies",
                    "bulk-assign",
                    str(csv_file),
                    "--dry-run",
                ],
            )
            assert result.exit_code == 0
            assert "days old" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_continue_on_error_flag(self, tmp_path: Path) -> None:
        """bulk-assign with --continue-on-error processes valid rows."""
        csv_content = """user,policy_type,policy_name
john@contoso.com,calling,AllowCalling
jane@contoso.com,calling,NonexistentPolicy"""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        policy = make_policy(
            policy_type="TeamsCallingPolicy", policy_name="AllowCalling"
        )
        user = make_user(
            user_principal_name="john@contoso.com",
            display_name="John Doe",
            is_enterprise_voice_enabled=True,
        )

        with (
            patch("teams_phone.cli.policies._get_sync_service") as mock_get_service,
            patch("teams_phone.cli.policies.CacheManager"),
            patch("teams_phone.cli.policies.AuthService"),
            patch("teams_phone.cli.policies.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.policies.PolicyService") as mock_ps_class,
            patch("teams_phone.cli.policies.UserService") as mock_us_class,
            patch("teams_phone.cli.policies.write_policy_results_csv"),
        ):
            mock_service = MagicMock()
            mock_service.get_staleness_warning.return_value = None
            mock_service.validate_policy.side_effect = [
                policy,
                NotFoundError("Policy 'NonexistentPolicy' not found"),
            ]
            mock_get_service.return_value = mock_service

            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_ps = MagicMock()
            mock_ps.assign_policy = AsyncMock()
            mock_ps_class.return_value = mock_ps

            mock_us = MagicMock()
            mock_us.resolve_user = AsyncMock(return_value=user)
            mock_us_class.return_value = mock_us

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "policies",
                    "bulk-assign",
                    str(csv_file),
                    "--continue-on-error",
                    "--yes",
                ],
            )
            # Should succeed because valid row was assigned successfully
            assert result.exit_code == 0
            assert "Execution Summary:" in result.stdout
            assert "Successful:" in result.stdout
            # Verify assignment was called once (for the valid row)
            mock_ps.assign_policy.assert_called_once()

    @pytest.mark.unit
    def test_bulk_assign_validation_fails_without_continue_on_error(
        self, tmp_path: Any
    ) -> None:
        """bulk-assign fails validation without --continue-on-error."""
        csv_content = """user,policy_type,policy_name
john@contoso.com,calling,AllowCalling
jane@contoso.com,calling,NonexistentPolicy"""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        policy = make_policy(
            policy_type="TeamsCallingPolicy", policy_name="AllowCalling"
        )

        with patch("teams_phone.cli.policies._get_sync_service") as mock_get_service:
            mock_service = MagicMock()
            mock_service.get_staleness_warning.return_value = None
            mock_service.validate_policy.side_effect = [
                policy,
                NotFoundError("Policy 'NonexistentPolicy' not found"),
            ]
            mock_get_service.return_value = mock_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "policies",
                    "bulk-assign",
                    str(csv_file),
                    "--yes",
                ],
            )
            # Should fail because there are validation errors
            assert result.exit_code == 5  # ValidationError exit code
            assert "Validation failed" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_missing_required_fields_in_rows(self, tmp_path: Any) -> None:
        """bulk-assign shows errors for missing required fields in rows."""
        csv_content = """user,policy_type,policy_name
,calling,AllowCalling
john@contoso.com,,AllowCalling
john@contoso.com,calling,"""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        with patch("teams_phone.cli.policies._get_sync_service") as mock_get_service:
            mock_service = MagicMock()
            mock_service.get_staleness_warning.return_value = None
            mock_get_service.return_value = mock_service

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "policies",
                    "bulk-assign",
                    str(csv_file),
                    "--dry-run",
                ],
            )
            assert result.exit_code == 1
            assert "Errors:" in result.stdout
            assert "Missing required field: user" in result.stdout
            assert "Missing required field: policy_type" in result.stdout
            assert "Missing required field: policy_name" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_execution_success(self, tmp_path: Path) -> None:
        """bulk-assign executes assignments and shows success."""
        csv_content = """user,policy_type,policy_name
john@contoso.com,calling,AllowCalling"""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        policy = make_policy(
            policy_type="TeamsCallingPolicy", policy_name="AllowCalling"
        )
        user = make_user(
            user_principal_name="john.doe@contoso.com",
            display_name="John Doe",
            is_enterprise_voice_enabled=True,
        )

        with (
            patch("teams_phone.cli.policies._get_sync_service") as mock_get_service,
            patch("teams_phone.cli.policies.CacheManager"),
            patch("teams_phone.cli.policies.AuthService"),
            patch("teams_phone.cli.policies.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.policies.PolicyService") as mock_ps_class,
            patch("teams_phone.cli.policies.UserService") as mock_us_class,
            patch("teams_phone.cli.policies.write_policy_results_csv"),
        ):
            # Mock validation service
            mock_service = MagicMock()
            mock_service.get_staleness_warning.return_value = None
            mock_service.validate_policy.return_value = policy
            mock_get_service.return_value = mock_service

            # Mock GraphClient context manager
            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            # Mock PolicyService
            mock_ps = MagicMock()
            mock_ps.assign_policy = AsyncMock()
            mock_ps_class.return_value = mock_ps

            # Mock UserService
            mock_us = MagicMock()
            mock_us.resolve_user = AsyncMock(return_value=user)
            mock_us_class.return_value = mock_us

            result = runner.invoke(
                app,
                ["--no-color", "policies", "bulk-assign", str(csv_file), "--yes"],
            )
            assert result.exit_code == 0
            assert "Execution Summary:" in result.stdout
            assert "Successful:" in result.stdout
            # Verify services were called
            mock_us.resolve_user.assert_called_once_with("john@contoso.com")
            mock_ps.assign_policy.assert_called_once()

    @pytest.mark.unit
    def test_bulk_assign_execution_json_output(self, tmp_path: Path) -> None:
        """bulk-assign --json outputs structured JSON with results."""
        csv_content = """user,policy_type,policy_name
john@contoso.com,calling,AllowCalling"""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        policy = make_policy(
            policy_type="TeamsCallingPolicy", policy_name="AllowCalling"
        )
        user = make_user(
            user_principal_name="john.doe@contoso.com",
            display_name="John Doe",
            is_enterprise_voice_enabled=True,
        )

        with (
            patch("teams_phone.cli.policies._get_sync_service") as mock_get_service,
            patch("teams_phone.cli.policies.CacheManager"),
            patch("teams_phone.cli.policies.AuthService"),
            patch("teams_phone.cli.policies.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.policies.PolicyService") as mock_ps_class,
            patch("teams_phone.cli.policies.UserService") as mock_us_class,
            patch("teams_phone.cli.policies.write_policy_results_csv"),
        ):
            mock_service = MagicMock()
            mock_service.get_staleness_warning.return_value = None
            mock_service.validate_policy.return_value = policy
            mock_get_service.return_value = mock_service

            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_ps = MagicMock()
            mock_ps.assign_policy = AsyncMock()
            mock_ps_class.return_value = mock_ps

            mock_us = MagicMock()
            mock_us.resolve_user = AsyncMock(return_value=user)
            mock_us_class.return_value = mock_us

            result = runner.invoke(
                app,
                ["--json", "policies", "bulk-assign", str(csv_file), "--yes"],
            )
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data["status"] == "completed"
            assert data["summary"]["successful"] == 1
            assert data["summary"]["failed"] == 0
            assert len(data["results"]) == 1
            assert data["results"][0]["status"] == "success"

    @pytest.mark.unit
    def test_bulk_assign_results_csv_written(self, tmp_path: Path) -> None:
        """bulk-assign writes results CSV file."""
        csv_content = """user,policy_type,policy_name
john@contoso.com,calling,AllowCalling"""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")
        output_file = tmp_path / "results.csv"

        policy = make_policy(
            policy_type="TeamsCallingPolicy", policy_name="AllowCalling"
        )
        user = make_user(
            user_principal_name="john.doe@contoso.com",
            display_name="John Doe",
            is_enterprise_voice_enabled=True,
        )

        with (
            patch("teams_phone.cli.policies._get_sync_service") as mock_get_service,
            patch("teams_phone.cli.policies.CacheManager"),
            patch("teams_phone.cli.policies.AuthService"),
            patch("teams_phone.cli.policies.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.policies.PolicyService") as mock_ps_class,
            patch("teams_phone.cli.policies.UserService") as mock_us_class,
        ):
            mock_service = MagicMock()
            mock_service.get_staleness_warning.return_value = None
            mock_service.validate_policy.return_value = policy
            mock_get_service.return_value = mock_service

            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_ps = MagicMock()
            mock_ps.assign_policy = AsyncMock()
            mock_ps_class.return_value = mock_ps

            mock_us = MagicMock()
            mock_us.resolve_user = AsyncMock(return_value=user)
            mock_us_class.return_value = mock_us

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "policies",
                    "bulk-assign",
                    str(csv_file),
                    "--yes",
                    "--output",
                    str(output_file),
                ],
            )
            assert result.exit_code == 0
            assert output_file.exists()
            # Check contents
            contents = output_file.read_text(encoding="utf-8")
            assert "row,user,policy_type,policy_name,status,error" in contents
            assert "john@contoso.com" in contents
            assert "success" in contents

    @pytest.mark.unit
    def test_bulk_assign_continue_on_error_execution(self, tmp_path: Path) -> None:
        """bulk-assign --continue-on-error processes all rows despite failures."""
        csv_content = """user,policy_type,policy_name
john@contoso.com,calling,AllowCalling
jane@contoso.com,calling,AllowCalling"""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        policy = make_policy(
            policy_type="TeamsCallingPolicy", policy_name="AllowCalling"
        )
        user1 = make_user(
            id="user-1",
            user_principal_name="john@contoso.com",
            display_name="John Doe",
            is_enterprise_voice_enabled=True,
        )
        user2 = make_user(
            id="user-2",
            user_principal_name="jane@contoso.com",
            display_name="Jane Smith",
            is_enterprise_voice_enabled=True,
        )

        with (
            patch("teams_phone.cli.policies._get_sync_service") as mock_get_service,
            patch("teams_phone.cli.policies.CacheManager"),
            patch("teams_phone.cli.policies.AuthService"),
            patch("teams_phone.cli.policies.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.policies.PolicyService") as mock_ps_class,
            patch("teams_phone.cli.policies.UserService") as mock_us_class,
            patch("teams_phone.cli.policies.write_policy_results_csv"),
        ):
            mock_service = MagicMock()
            mock_service.get_staleness_warning.return_value = None
            mock_service.validate_policy.return_value = policy
            mock_get_service.return_value = mock_service

            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_ps = MagicMock()
            # First call fails, second succeeds
            mock_ps.assign_policy = AsyncMock(
                side_effect=[NotFoundError("User not found"), None]
            )
            mock_ps_class.return_value = mock_ps

            mock_us = MagicMock()
            mock_us.resolve_user = AsyncMock(side_effect=[user1, user2])
            mock_us_class.return_value = mock_us

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "policies",
                    "bulk-assign",
                    str(csv_file),
                    "--yes",
                    "--continue-on-error",
                ],
            )
            # Should exit 1 due to failures
            assert result.exit_code == 1
            assert "Successful:" in result.stdout
            assert "Failed:" in result.stdout
            # Verify both users were processed
            assert mock_ps.assign_policy.call_count == 2

    @pytest.mark.unit
    def test_bulk_assign_stop_on_first_error(self, tmp_path: Path) -> None:
        """bulk-assign stops on first error without --continue-on-error."""
        csv_content = """user,policy_type,policy_name
john@contoso.com,calling,AllowCalling
jane@contoso.com,calling,AllowCalling"""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        policy = make_policy(
            policy_type="TeamsCallingPolicy", policy_name="AllowCalling"
        )
        user1 = make_user(
            id="user-1",
            user_principal_name="john@contoso.com",
            display_name="John Doe",
            is_enterprise_voice_enabled=True,
        )

        with (
            patch("teams_phone.cli.policies._get_sync_service") as mock_get_service,
            patch("teams_phone.cli.policies.CacheManager"),
            patch("teams_phone.cli.policies.AuthService"),
            patch("teams_phone.cli.policies.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.policies.PolicyService") as mock_ps_class,
            patch("teams_phone.cli.policies.UserService") as mock_us_class,
            patch("teams_phone.cli.policies.write_policy_results_csv"),
        ):
            mock_service = MagicMock()
            mock_service.get_staleness_warning.return_value = None
            mock_service.validate_policy.return_value = policy
            mock_get_service.return_value = mock_service

            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_ps = MagicMock()
            # First call fails
            mock_ps.assign_policy = AsyncMock(
                side_effect=NotFoundError("User not found")
            )
            mock_ps_class.return_value = mock_ps

            mock_us = MagicMock()
            mock_us.resolve_user = AsyncMock(return_value=user1)
            mock_us_class.return_value = mock_us

            result = runner.invoke(
                app,
                ["--no-color", "policies", "bulk-assign", str(csv_file), "--yes"],
            )
            assert result.exit_code == 1
            # Only one assignment attempt (stopped on first error)
            assert mock_ps.assign_policy.call_count == 1
            # Second row should be skipped
            assert "Skipped:" in result.stdout

    @pytest.mark.unit
    def test_bulk_assign_summary_counts_displayed(self, tmp_path: Path) -> None:
        """bulk-assign displays correct summary counts."""
        csv_content = """user,policy_type,policy_name
john@contoso.com,calling,AllowCalling
jane@contoso.com,calling,AllowCalling
bob@contoso.com,calling,AllowCalling"""
        csv_file = tmp_path / "policies.csv"
        csv_file.write_text(csv_content, encoding="utf-8")

        policy = make_policy(
            policy_type="TeamsCallingPolicy", policy_name="AllowCalling"
        )
        user1 = make_user(
            id="user-1",
            user_principal_name="john@contoso.com",
            display_name="John Doe",
            is_enterprise_voice_enabled=True,
        )
        user2 = make_user(
            id="user-2",
            user_principal_name="jane@contoso.com",
            display_name="Jane Smith",
            is_enterprise_voice_enabled=True,
        )
        user3 = make_user(
            id="user-3",
            user_principal_name="bob@contoso.com",
            display_name="Bob Smith",
            is_enterprise_voice_enabled=True,
        )

        with (
            patch("teams_phone.cli.policies._get_sync_service") as mock_get_service,
            patch("teams_phone.cli.policies.CacheManager"),
            patch("teams_phone.cli.policies.AuthService"),
            patch("teams_phone.cli.policies.GraphClient") as mock_gc_class,
            patch("teams_phone.cli.policies.PolicyService") as mock_ps_class,
            patch("teams_phone.cli.policies.UserService") as mock_us_class,
            patch("teams_phone.cli.policies.write_policy_results_csv"),
        ):
            mock_service = MagicMock()
            mock_service.get_staleness_warning.return_value = None
            mock_service.validate_policy.return_value = policy
            mock_get_service.return_value = mock_service

            mock_gc = AsyncMock()
            mock_gc.__aenter__.return_value = mock_gc
            mock_gc.__aexit__.return_value = None
            mock_gc_class.return_value = mock_gc

            mock_ps = MagicMock()
            # First succeeds, second fails, third succeeds
            mock_ps.assign_policy = AsyncMock(
                side_effect=[None, NotFoundError("Policy not found"), None]
            )
            mock_ps_class.return_value = mock_ps

            mock_us = MagicMock()
            mock_us.resolve_user = AsyncMock(side_effect=[user1, user2, user3])
            mock_us_class.return_value = mock_us

            result = runner.invoke(
                app,
                [
                    "--no-color",
                    "policies",
                    "bulk-assign",
                    str(csv_file),
                    "--yes",
                    "--continue-on-error",
                ],
            )
            assert result.exit_code == 1  # Failed count > 0
            assert "Execution Summary:" in result.stdout
            # Check summary values appear
            assert "Successful:" in result.stdout
            assert "Failed:" in result.stdout
            assert "Skipped:" in result.stdout
