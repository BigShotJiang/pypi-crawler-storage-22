"""Unit tests for CLI policies list command."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from teams_phone.cli.main import app
from tests.conftest import CliRunner
from tests.fixtures import make_policy


runner = CliRunner()


class TestPoliciesListCommand:
    """Tests for policies list command."""

    @pytest.mark.unit
    def test_list_shows_in_help(self) -> None:
        """list command appears in policies help."""
        result = runner.invoke(app, ["policies", "--help"])
        assert result.exit_code == 0
        assert "list" in result.stdout

    @pytest.mark.unit
    def test_list_empty(self) -> None:
        """list shows empty message when no policies found."""
        with patch("teams_phone.cli.policies._get_sync_service") as mock_get_service:
            mock_service = MagicMock()
            mock_service.list_policies.return_value = []
            mock_service.get_staleness_warning.return_value = None
            mock_get_service.return_value = mock_service

            result = runner.invoke(app, ["policies", "list"])
            assert result.exit_code == 0
            assert "No policies found" in result.stdout

    @pytest.mark.unit
    def test_list_shows_policies(self) -> None:
        """list shows policies in table format."""
        policies = [
            make_policy(policy_name="AllowCalling", description="Allow calls"),
            make_policy(
                policy_type="TenantDialPlan",
                policy_name="US-DialPlan",
                description="US dial plan",
            ),
        ]

        with patch("teams_phone.cli.policies._get_sync_service") as mock_get_service:
            mock_service = MagicMock()
            mock_service.list_policies.return_value = policies
            mock_service.get_staleness_warning.return_value = None
            mock_get_service.return_value = mock_service

            result = runner.invoke(app, ["--no-color", "policies", "list"])
            assert result.exit_code == 0
            assert "AllowCalling" in result.stdout
            assert "US-DialPlan" in result.stdout

    @pytest.mark.unit
    def test_list_json_output(self) -> None:
        """list outputs valid JSON with --json flag."""
        policies = [make_policy()]

        with patch("teams_phone.cli.policies._get_sync_service") as mock_get_service:
            mock_service = MagicMock()
            mock_service.list_policies.return_value = policies
            mock_service.get_staleness_warning.return_value = None
            mock_get_service.return_value = mock_service

            result = runner.invoke(app, ["--json", "policies", "list"])
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert len(data) == 1
            assert data[0]["policy_name"] == "AllowCalling"
            assert data[0]["policy_type"] == "TeamsCallingPolicy"
            assert data[0]["is_global"] is False

    @pytest.mark.unit
    def test_list_json_empty(self) -> None:
        """list outputs empty JSON array when no policies."""
        with patch("teams_phone.cli.policies._get_sync_service") as mock_get_service:
            mock_service = MagicMock()
            mock_service.list_policies.return_value = []
            mock_service.get_staleness_warning.return_value = None
            mock_get_service.return_value = mock_service

            result = runner.invoke(app, ["--json", "policies", "list"])
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data == []

    @pytest.mark.unit
    def test_list_with_type_filter_cli_alias(self) -> None:
        """list filters by CLI policy type alias."""
        policies = [make_policy(policy_type="TeamsCallingPolicy")]

        with patch("teams_phone.cli.policies._get_sync_service") as mock_get_service:
            mock_service = MagicMock()
            mock_service.list_policies.return_value = policies
            mock_service.get_staleness_warning.return_value = None
            mock_get_service.return_value = mock_service

            result = runner.invoke(app, ["--no-color", "policies", "list", "calling"])
            assert result.exit_code == 0
            # Verify the service was called with the resolved type
            mock_service.list_policies.assert_called_once_with(
                policy_type="TeamsCallingPolicy"
            )

    @pytest.mark.unit
    def test_list_with_type_filter_api_name(self) -> None:
        """list filters by API policy type name."""
        policies = [make_policy(policy_type="TeamsCallingPolicy")]

        with patch("teams_phone.cli.policies._get_sync_service") as mock_get_service:
            mock_service = MagicMock()
            mock_service.list_policies.return_value = policies
            mock_service.get_staleness_warning.return_value = None
            mock_get_service.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "policies", "list", "TeamsCallingPolicy"]
            )
            assert result.exit_code == 0
            mock_service.list_policies.assert_called_once_with(
                policy_type="TeamsCallingPolicy"
            )

    @pytest.mark.unit
    def test_list_shows_staleness_warning(self) -> None:
        """list shows staleness warning when cache is stale."""
        policies = [make_policy()]

        with patch("teams_phone.cli.policies._get_sync_service") as mock_get_service:
            mock_service = MagicMock()
            mock_service.list_policies.return_value = policies
            mock_service.get_staleness_warning.return_value = (
                "Policy cache is 45 days old (threshold: 30 days). "
                "Consider refreshing by running the PowerShell export script."
            )
            mock_get_service.return_value = mock_service

            result = runner.invoke(app, ["--no-color", "policies", "list"])
            assert result.exit_code == 0
            assert "days old" in result.stdout
            assert "threshold" in result.stdout

    @pytest.mark.unit
    def test_list_global_policy_display(self) -> None:
        """list correctly displays global policies."""
        policies = [make_policy(policy_name="Global", is_global=True)]

        with patch("teams_phone.cli.policies._get_sync_service") as mock_get_service:
            mock_service = MagicMock()
            mock_service.list_policies.return_value = policies
            mock_service.get_staleness_warning.return_value = None
            mock_get_service.return_value = mock_service

            result = runner.invoke(app, ["--json", "policies", "list"])
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data[0]["is_global"] is True
