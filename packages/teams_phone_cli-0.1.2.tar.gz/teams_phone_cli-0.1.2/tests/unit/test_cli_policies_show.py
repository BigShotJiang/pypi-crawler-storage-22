"""Unit tests for CLI policies show command."""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.exceptions import NotFoundError
from teams_phone.models import EffectivePolicyAssignment
from tests.conftest import CliRunner
from tests.fixtures import make_user


runner = CliRunner()


def _make_assignment(
    policy_type: str = "TeamsCallingPolicy",
    display_name: str = "AllowCalling",
    assignment_type: str = "direct",
    policy_id: str = "policy-11111111-1111-1111-1111-111111111111",
    group_id: str | None = None,
) -> EffectivePolicyAssignment:
    """Create an EffectivePolicyAssignment for testing.

    Note: This is kept local as there's no shared factory for EffectivePolicyAssignment.
    """
    data: dict[str, Any] = {
        "policyType": policy_type,
        "policyAssignment": {
            "displayName": display_name,
            "assignmentType": assignment_type,
            "policyId": policy_id,
        },
    }
    if group_id is not None:
        data["policyAssignment"]["groupId"] = group_id
    return EffectivePolicyAssignment.model_validate(data)


class TestPoliciesShowCommand:
    """Tests for policies show command."""

    @pytest.mark.unit
    def test_show_shows_in_help(self) -> None:
        """show command appears in policies help."""
        result = runner.invoke(app, ["policies", "--help"])
        assert result.exit_code == 0
        assert "show" in result.stdout

    @pytest.mark.unit
    def test_show_requires_user_argument(self) -> None:
        """show requires user argument."""
        result = runner.invoke(app, ["policies", "show"])
        assert result.exit_code == 2
        output = result.stdout + (result.stderr or "")
        assert "USER" in output or "Missing argument" in output or result.exit_code == 2

    @pytest.mark.unit
    def test_show_displays_policies(self) -> None:
        """show displays user's policy assignments."""
        user = make_user(
            user_principal_name="john.doe@contoso.com",
            display_name="John Doe",
            is_enterprise_voice_enabled=True,
        )
        assignments = [
            _make_assignment(
                policy_type="TeamsCallingPolicy", display_name="AllowCalling"
            ),
            _make_assignment(
                policy_type="TenantDialPlan",
                display_name="US-DialPlan",
                assignment_type="group",
            ),
        ]

        with patch("teams_phone.cli.policies._run_async") as mock_run_async:
            mock_run_async.return_value = (
                (assignments, user.display_name, user.id),
                MagicMock(),
            )

            result = runner.invoke(
                app, ["--no-color", "policies", "show", "john.doe@contoso.com"]
            )
            assert result.exit_code == 0
            assert "John Doe" in result.stdout
            assert "AllowCalling" in result.stdout

    @pytest.mark.unit
    def test_show_json_output(self) -> None:
        """show outputs valid JSON with --json flag."""
        user = make_user(
            user_principal_name="john.doe@contoso.com",
            display_name="John Doe",
            is_enterprise_voice_enabled=True,
        )
        assignments = [
            _make_assignment(
                policy_type="TeamsCallingPolicy", display_name="AllowCalling"
            ),
        ]

        with patch("teams_phone.cli.policies._run_async") as mock_run_async:
            mock_run_async.return_value = (
                (assignments, user.display_name, user.id),
                MagicMock(),
            )

            result = runner.invoke(
                app, ["--json", "policies", "show", "john.doe@contoso.com"]
            )
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data["display_name"] == "John Doe"
            assert len(data["policies"]) == 1
            assert data["policies"][0]["policy_type"] == "TeamsCallingPolicy"
            assert data["policies"][0]["policy_name"] == "AllowCalling"

    @pytest.mark.unit
    def test_show_empty_assignments(self) -> None:
        """show displays message when no assignments found."""
        user = make_user(
            user_principal_name="john.doe@contoso.com",
            display_name="John Doe",
            is_enterprise_voice_enabled=True,
        )

        with patch("teams_phone.cli.policies._run_async") as mock_run_async:
            mock_run_async.return_value = (
                ([], user.display_name, user.id),
                MagicMock(),
            )

            result = runner.invoke(
                app, ["--no-color", "policies", "show", "john.doe@contoso.com"]
            )
            assert result.exit_code == 0
            assert "No policy assignments found" in result.stdout

    @pytest.mark.unit
    def test_show_user_not_found(self) -> None:
        """show exits with error when user not found."""
        with patch("teams_phone.cli.policies._run_async") as mock_run_async:
            mock_run_async.side_effect = NotFoundError(
                "User 'nonexistent@contoso.com' not found",
                remediation="Verify the user identifier is correct.",
            )

            result = runner.invoke(app, ["policies", "show", "nonexistent@contoso.com"])
            assert result.exit_code == 4  # NotFoundError exit code

    @pytest.mark.unit
    def test_show_assignment_types_formatted(self) -> None:
        """show formats assignment types correctly."""
        user = make_user(
            user_principal_name="john.doe@contoso.com",
            display_name="John Doe",
            is_enterprise_voice_enabled=True,
        )
        assignments = [
            _make_assignment(assignment_type="direct"),
            _make_assignment(
                policy_type="TenantDialPlan",
                display_name="DialPlan",
                assignment_type="group",
            ),
            _make_assignment(
                policy_type="TeamsEmergencyCallingPolicy",
                display_name="Default",
                assignment_type="global",
            ),
        ]

        with patch("teams_phone.cli.policies._run_async") as mock_run_async:
            mock_run_async.return_value = (
                (assignments, user.display_name, user.id),
                MagicMock(),
            )

            result = runner.invoke(
                app, ["--no-color", "policies", "show", "john.doe@contoso.com"]
            )
            assert result.exit_code == 0
            assert "Direct" in result.stdout
            assert "Group" in result.stdout
            assert "Global" in result.stdout
