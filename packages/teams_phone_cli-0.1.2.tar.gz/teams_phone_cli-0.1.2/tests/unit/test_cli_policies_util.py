"""Unit tests for CLI policies utility functions and integration tests."""

from __future__ import annotations

import pytest

from teams_phone.cli.main import app
from tests.conftest import CliRunner


runner = CliRunner()


class TestPoliciesCommandIntegration:
    """Integration tests for policies command group."""

    @pytest.mark.unit
    def test_policies_commands_appear_in_help(self) -> None:
        """All policies commands appear in policies --help."""
        result = runner.invoke(app, ["policies", "--help"])
        assert result.exit_code == 0
        assert "list" in result.stdout
        assert "show" in result.stdout
        assert "assign" in result.stdout

    @pytest.mark.unit
    def test_policies_no_args_shows_help(self) -> None:
        """policies with no args shows help (exit code 2)."""
        result = runner.invoke(app, ["policies"])
        assert result.exit_code == 2
        assert "Usage:" in result.stdout

    @pytest.mark.unit
    def test_policies_appears_in_main_help(self) -> None:
        """policies command group appears in main help."""
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "policies" in result.stdout


class TestPolicyTypeMapping:
    """Tests for policy type name mapping."""

    @pytest.mark.unit
    def test_all_cli_aliases_resolve(self) -> None:
        """All CLI aliases resolve to valid API names."""
        from teams_phone.cli.policies import POLICY_TYPE_MAP, _resolve_policy_type

        for cli_alias, api_name in POLICY_TYPE_MAP.items():
            resolved = _resolve_policy_type(cli_alias)
            assert resolved == api_name

    @pytest.mark.unit
    def test_api_names_pass_through(self) -> None:
        """API names pass through unchanged."""
        from teams_phone.cli.policies import _resolve_policy_type

        api_names = [
            "TeamsCallingPolicy",
            "TeamsVoicemailPolicy",
            "CallingLineIdentity",
            "TenantDialPlan",
            "OnlineVoiceRoutingPolicy",
            "TeamsEmergencyCallingPolicy",
            "TeamsEmergencyCallRoutingPolicy",
        ]

        for api_name in api_names:
            resolved = _resolve_policy_type(api_name)
            assert resolved == api_name

    @pytest.mark.unit
    def test_case_insensitive_resolution(self) -> None:
        """Policy type resolution is case-insensitive."""
        from teams_phone.cli.policies import _resolve_policy_type

        assert _resolve_policy_type("CALLING") == "TeamsCallingPolicy"
        assert _resolve_policy_type("Calling") == "TeamsCallingPolicy"
        assert _resolve_policy_type("teamscallingpolicy") == "TeamsCallingPolicy"

    @pytest.mark.unit
    def test_none_returns_none(self) -> None:
        """None input returns None."""
        from teams_phone.cli.policies import _resolve_policy_type

        assert _resolve_policy_type(None) is None
