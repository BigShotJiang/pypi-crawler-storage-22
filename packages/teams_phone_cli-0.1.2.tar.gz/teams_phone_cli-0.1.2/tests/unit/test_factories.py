"""Unit tests for factory functions in tests/fixtures/factories.py.

This module validates that all factory functions:
- Return valid Pydantic model instances
- Have sensible default values
- Support keyword argument overrides
- Handle enum parameters correctly
- Raise ValidationError on invalid inputs
"""

from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from teams_phone.models import (
    AccountType,
    ActivationState,
    AssignmentStatus,
    AsyncOperation,
    EmergencyLocation,
    NumberAssignment,
    NumberType,
    OperationStatus,
    Policy,
    UserConfiguration,
)
from tests.fixtures import (
    make_location,
    make_number,
    make_operation,
    make_policy,
    make_user,
)


class TestMakeUser:
    """Tests for make_user() factory function."""

    @pytest.mark.unit
    def test_returns_user_configuration(self) -> None:
        """make_user() returns a UserConfiguration instance."""
        user = make_user()
        assert isinstance(user, UserConfiguration)

    @pytest.mark.unit
    def test_default_values(self) -> None:
        """make_user() returns valid defaults for all fields."""
        user = make_user()
        assert user.id == "11111111-1111-1111-1111-111111111111"
        assert user.user_principal_name == "user@contoso.com"
        assert user.tenant_id == "22222222-2222-2222-2222-222222222222"
        assert user.display_name == "Test User"
        assert user.account_type == AccountType.USER
        assert user.is_enterprise_voice_enabled is False
        assert user.feature_types == []
        assert user.telephone_numbers == []
        assert user.effective_policy_assignments == []

    @pytest.mark.unit
    def test_override_simple_fields(self) -> None:
        """make_user() accepts keyword argument overrides for simple fields."""
        user = make_user(
            id="custom-id",
            user_principal_name="alice@example.com",
            display_name="Alice Smith",
            is_enterprise_voice_enabled=True,
        )
        assert user.id == "custom-id"
        assert user.user_principal_name == "alice@example.com"
        assert user.display_name == "Alice Smith"
        assert user.is_enterprise_voice_enabled is True

    @pytest.mark.unit
    def test_override_account_type_with_enum(self) -> None:
        """make_user() accepts AccountType enum for account_type."""
        user = make_user(account_type=AccountType.RESOURCE_ACCOUNT)
        assert user.account_type == AccountType.RESOURCE_ACCOUNT

    @pytest.mark.unit
    def test_override_account_type_with_string(self) -> None:
        """make_user() accepts string value for account_type via kwargs."""
        # Pass string via kwargs to bypass enum parameter
        user = make_user(**{"accountType": "resourceAccount"})  # type: ignore[arg-type]
        assert user.account_type == AccountType.RESOURCE_ACCOUNT

    @pytest.mark.unit
    def test_override_list_fields(self) -> None:
        """make_user() accepts list overrides for nested fields."""
        phone_numbers = [
            {"telephoneNumber": "+14255551234", "assignmentCategory": "primary"}
        ]
        user = make_user(telephone_numbers=phone_numbers)
        assert len(user.telephone_numbers) == 1
        assert user.telephone_numbers[0].telephone_number == "+14255551234"

    @pytest.mark.unit
    def test_override_with_none(self) -> None:
        """make_user() allows None for optional fields."""
        user = make_user(display_name=None)
        assert user.display_name is None

    @pytest.mark.unit
    def test_kwargs_override(self) -> None:
        """make_user() allows additional kwargs to override any field."""
        user = make_user(**{"tenantId": "custom-tenant-id"})  # type: ignore[arg-type]
        assert user.tenant_id == "custom-tenant-id"

    @pytest.mark.unit
    def test_invalid_account_type_raises(self) -> None:
        """make_user() with invalid account type raises ValidationError."""
        with pytest.raises(ValidationError):
            make_user(**{"accountType": "InvalidAccountType"})  # type: ignore[arg-type]


class TestMakeNumber:
    """Tests for make_number() factory function."""

    @pytest.mark.unit
    def test_returns_number_assignment(self) -> None:
        """make_number() returns a NumberAssignment instance."""
        number = make_number()
        assert isinstance(number, NumberAssignment)

    @pytest.mark.unit
    def test_default_values(self) -> None:
        """make_number() returns valid defaults for all fields."""
        number = make_number()
        assert number.id == "num-11111111-1111-1111-1111-111111111111"
        assert number.telephone_number == "+14255551234"
        assert number.number_type == NumberType.DIRECT_ROUTING
        assert number.activation_state == ActivationState.ACTIVATED
        assert number.capabilities == ["userAssignment"]
        assert number.assignment_status == AssignmentStatus.UNASSIGNED
        assert number.city == "Seattle"
        assert number.location_id is None
        assert number.assignment_target_id is None

    @pytest.mark.unit
    def test_override_simple_fields(self) -> None:
        """make_number() accepts keyword argument overrides."""
        number = make_number(
            id="custom-num-id",
            telephone_number="+15551234567",
            city="Portland",
        )
        assert number.id == "custom-num-id"
        assert number.telephone_number == "+15551234567"
        assert number.city == "Portland"

    @pytest.mark.unit
    def test_override_number_type_with_enum(self) -> None:
        """make_number() accepts NumberType enum."""
        number = make_number(number_type=NumberType.CALLING_PLAN)
        assert number.number_type == NumberType.CALLING_PLAN

    @pytest.mark.unit
    def test_override_activation_state_with_enum(self) -> None:
        """make_number() accepts ActivationState enum."""
        number = make_number(activation_state=ActivationState.ASSIGNMENT_PENDING)
        assert number.activation_state == ActivationState.ASSIGNMENT_PENDING

    @pytest.mark.unit
    def test_override_assignment_status_with_enum(self) -> None:
        """make_number() accepts AssignmentStatus enum."""
        number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
        )
        assert number.assignment_status == AssignmentStatus.USER_ASSIGNED
        assert number.assignment_target_id == "user-123"

    @pytest.mark.unit
    def test_override_capabilities_list(self) -> None:
        """make_number() accepts custom capabilities list."""
        number = make_number(
            capabilities=["userAssignment", "voiceApplicationAssignment"]
        )
        assert "userAssignment" in number.capabilities
        assert "voiceApplicationAssignment" in number.capabilities

    @pytest.mark.unit
    def test_override_with_none(self) -> None:
        """make_number() allows None for optional fields."""
        number = make_number(city=None, location_id=None)
        assert number.city is None
        assert number.location_id is None

    @pytest.mark.unit
    def test_kwargs_override(self) -> None:
        """make_number() allows additional kwargs to override any field."""
        number = make_number(**{"telephoneNumber": "+19995551234"})  # type: ignore[arg-type]
        assert number.telephone_number == "+19995551234"

    @pytest.mark.unit
    def test_invalid_number_type_raises(self) -> None:
        """make_number() with invalid number type raises ValidationError."""
        with pytest.raises(ValidationError):
            make_number(**{"numberType": "InvalidType"})  # type: ignore[arg-type]


class TestMakePolicy:
    """Tests for make_policy() factory function."""

    @pytest.mark.unit
    def test_returns_policy(self) -> None:
        """make_policy() returns a Policy instance."""
        policy = make_policy()
        assert isinstance(policy, Policy)

    @pytest.mark.unit
    def test_default_values(self) -> None:
        """make_policy() returns valid defaults for all fields."""
        policy = make_policy()
        assert policy.policy_type == "TeamsCallingPolicy"
        assert policy.policy_name == "AllowCalling"
        assert policy.policy_id == "policy-11111111-1111-1111-1111-111111111111"
        assert policy.description == "Test policy for unit tests"
        assert policy.is_global is False

    @pytest.mark.unit
    def test_override_all_fields(self) -> None:
        """make_policy() accepts keyword argument overrides."""
        policy = make_policy(
            policy_type="TenantDialPlan",
            policy_name="US-DialPlan",
            policy_id="custom-policy-id",
            description="Custom dial plan",
            is_global=True,
        )
        assert policy.policy_type == "TenantDialPlan"
        assert policy.policy_name == "US-DialPlan"
        assert policy.policy_id == "custom-policy-id"
        assert policy.description == "Custom dial plan"
        assert policy.is_global is True

    @pytest.mark.unit
    def test_override_with_none(self) -> None:
        """make_policy() allows None for optional fields."""
        policy = make_policy(description=None)
        assert policy.description is None

    @pytest.mark.unit
    def test_kwargs_override(self) -> None:
        """make_policy() allows additional kwargs to override any field."""
        policy = make_policy(**{"policyType": "TeamsVoiceRoutingPolicy"})  # type: ignore[arg-type]
        assert policy.policy_type == "TeamsVoiceRoutingPolicy"


class TestMakeLocation:
    """Tests for make_location() factory function."""

    @pytest.mark.unit
    def test_returns_emergency_location(self) -> None:
        """make_location() returns an EmergencyLocation instance."""
        location = make_location()
        assert isinstance(location, EmergencyLocation)

    @pytest.mark.unit
    def test_default_values(self) -> None:
        """make_location() returns valid defaults for all fields."""
        location = make_location()
        assert location.location_id == "loc-11111111-1111-1111-1111-111111111111"
        assert location.civic_address_id == "civic-22222222-2222-2222-2222-222222222222"
        assert location.description == "Main Office"
        assert location.company_name == "Contoso"
        assert location.address == "123 Main St"
        assert location.city == "Seattle"
        assert location.state_or_province == "WA"
        assert location.postal_code == "98101"
        assert location.country_or_region == "US"
        assert location.is_default is True

    @pytest.mark.unit
    def test_override_all_fields(self) -> None:
        """make_location() accepts keyword argument overrides."""
        location = make_location(
            location_id="custom-loc-id",
            civic_address_id="custom-civic-id",
            description="Portland Office",
            company_name="Fabrikam",
            address="456 Oak Ave",
            city="Portland",
            state_or_province="OR",
            postal_code="97201",
            country_or_region="US",
            is_default=False,
        )
        assert location.location_id == "custom-loc-id"
        assert location.civic_address_id == "custom-civic-id"
        assert location.description == "Portland Office"
        assert location.company_name == "Fabrikam"
        assert location.address == "456 Oak Ave"
        assert location.city == "Portland"
        assert location.state_or_province == "OR"
        assert location.postal_code == "97201"
        assert location.country_or_region == "US"
        assert location.is_default is False

    @pytest.mark.unit
    def test_override_with_none(self) -> None:
        """make_location() allows None for optional fields."""
        location = make_location(
            company_name=None,
            address=None,
            city=None,
        )
        assert location.company_name is None
        assert location.address is None
        assert location.city is None

    @pytest.mark.unit
    def test_kwargs_override(self) -> None:
        """make_location() allows additional kwargs to override any field."""
        location = make_location(**{"locationId": "kwargs-loc-id"})  # type: ignore[arg-type]
        assert location.location_id == "kwargs-loc-id"


class TestMakeOperation:
    """Tests for make_operation() factory function."""

    @pytest.mark.unit
    def test_returns_async_operation(self) -> None:
        """make_operation() returns an AsyncOperation instance."""
        operation = make_operation()
        assert isinstance(operation, AsyncOperation)

    @pytest.mark.unit
    def test_default_values(self) -> None:
        """make_operation() returns valid defaults for all fields."""
        operation = make_operation()
        assert operation.status == OperationStatus.SUCCEEDED
        assert operation.created_date_time == datetime(
            2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc
        )
        assert operation.id is None
        assert operation.numbers == []

    @pytest.mark.unit
    def test_override_status_with_enum(self) -> None:
        """make_operation() accepts OperationStatus enum."""
        operation = make_operation(status=OperationStatus.RUNNING)
        assert operation.status == OperationStatus.RUNNING

    @pytest.mark.unit
    def test_override_status_with_not_started(self) -> None:
        """make_operation() accepts NOT_STARTED status."""
        operation = make_operation(status=OperationStatus.NOT_STARTED)
        assert operation.status == OperationStatus.NOT_STARTED

    @pytest.mark.unit
    def test_override_status_with_failed(self) -> None:
        """make_operation() accepts FAILED status."""
        operation = make_operation(status=OperationStatus.FAILED)
        assert operation.status == OperationStatus.FAILED

    @pytest.mark.unit
    def test_override_created_date_time(self) -> None:
        """make_operation() accepts custom datetime."""
        custom_dt = datetime(2026, 6, 15, 10, 30, 0, tzinfo=timezone.utc)
        operation = make_operation(created_date_time=custom_dt)
        assert operation.created_date_time == custom_dt

    @pytest.mark.unit
    def test_override_id(self) -> None:
        """make_operation() accepts custom id."""
        operation = make_operation(id="custom-operation-id")
        assert operation.id == "custom-operation-id"

    @pytest.mark.unit
    def test_override_numbers(self) -> None:
        """make_operation() accepts custom numbers list."""
        numbers = [
            {"resourceLocation": "/numbers/123", "status": "succeeded"},
            {"resourceLocation": "/numbers/456", "status": "failed"},
        ]
        operation = make_operation(numbers=numbers)
        assert len(operation.numbers) == 2
        assert operation.numbers[0].resource_location == "/numbers/123"
        assert operation.numbers[0].status == "succeeded"

    @pytest.mark.unit
    def test_kwargs_override(self) -> None:
        """make_operation() allows additional kwargs to override any field."""
        operation = make_operation(**{"status": "running"})  # type: ignore[arg-type]
        assert operation.status == OperationStatus.RUNNING

    @pytest.mark.unit
    def test_invalid_status_raises(self) -> None:
        """make_operation() with invalid status raises ValidationError."""
        with pytest.raises(ValidationError):
            make_operation(**{"status": "InvalidStatus"})  # type: ignore[arg-type]


class TestFactoryIntegration:
    """Integration tests verifying factories work together."""

    @pytest.mark.unit
    def test_user_with_telephone_numbers(self) -> None:
        """make_user() can create user with telephone numbers."""
        user = make_user(
            telephone_numbers=[
                {"telephoneNumber": "+14255551234", "assignmentCategory": "primary"},
                {"telephoneNumber": "+14255555678", "assignmentCategory": "alternate"},
            ],
            is_enterprise_voice_enabled=True,
        )
        assert len(user.telephone_numbers) == 2
        assert user.is_enterprise_voice_enabled is True

    @pytest.mark.unit
    def test_user_with_policy_assignments(self) -> None:
        """make_user() can create user with policy assignments."""
        policy = make_policy()
        user = make_user(
            effective_policy_assignments=[
                {
                    "policyType": policy.policy_type,
                    "policyAssignment": {
                        "displayName": policy.policy_name,
                        "assignmentType": "direct",
                        "policyId": policy.policy_id,
                    },
                }
            ]
        )
        assert len(user.effective_policy_assignments) == 1
        assert user.effective_policy_assignments[0].policy_type == policy.policy_type

    @pytest.mark.unit
    def test_assigned_number_with_location(self) -> None:
        """make_number() can reference a location ID."""
        location = make_location()
        number = make_number(
            assignment_status=AssignmentStatus.USER_ASSIGNED,
            assignment_target_id="user-123",
            location_id=location.location_id,
        )
        assert number.location_id == location.location_id
        assert number.assignment_status == AssignmentStatus.USER_ASSIGNED

    @pytest.mark.unit
    def test_multiple_factories_consistent_ids(self) -> None:
        """Factories produce consistent, predictable IDs for testing."""
        user1 = make_user()
        user2 = make_user()
        number1 = make_number()
        number2 = make_number()

        # Same factory call should produce same defaults
        assert user1.id == user2.id
        assert number1.id == number2.id

        # Different factories should have different default IDs
        assert user1.id != number1.id
