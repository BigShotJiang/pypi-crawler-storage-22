"""Unit tests for GraphClient core functionality.

Tests for initialization, URL building, headers, context manager, and request basics.
"""

from unittest.mock import MagicMock

import httpx
import pytest
import respx

from teams_phone.constants import DEFAULT_TIMEOUT, GRAPH_API_BASE
from teams_phone.infrastructure import GraphClient


class TestGraphClientInit:
    """Tests for GraphClient initialization."""

    @pytest.mark.unit
    def test_accepts_auth_service(self, mock_auth_service: MagicMock) -> None:
        """GraphClient accepts AuthService in constructor."""
        client = GraphClient(mock_auth_service)

        assert client.auth_service is mock_auth_service

    @pytest.mark.unit
    def test_uses_default_timeout(self, mock_auth_service: MagicMock) -> None:
        """GraphClient uses DEFAULT_TIMEOUT when timeout not specified."""
        client = GraphClient(mock_auth_service)

        assert client._timeout == DEFAULT_TIMEOUT

    @pytest.mark.unit
    def test_accepts_custom_timeout(self, mock_auth_service: MagicMock) -> None:
        """GraphClient accepts custom timeout value."""
        client = GraphClient(mock_auth_service, timeout=60)

        assert client._timeout == 60

    @pytest.mark.unit
    def test_client_not_initialized_outside_context(
        self, mock_auth_service: MagicMock
    ) -> None:
        """GraphClient._client is None before entering context manager."""
        client = GraphClient(mock_auth_service)

        assert client._client is None


class TestGraphClientBuildUrl:
    """Tests for GraphClient._build_url method."""

    @pytest.mark.unit
    def test_builds_url_without_leading_slash(
        self, mock_auth_service: MagicMock
    ) -> None:
        """_build_url handles endpoint without leading slash."""
        client = GraphClient(mock_auth_service)

        url = client._build_url("users")

        assert url == f"{GRAPH_API_BASE}/users"

    @pytest.mark.unit
    def test_builds_url_with_leading_slash(self, mock_auth_service: MagicMock) -> None:
        """_build_url handles endpoint with leading slash."""
        client = GraphClient(mock_auth_service)

        url = client._build_url("/users")

        assert url == f"{GRAPH_API_BASE}/users"

    @pytest.mark.unit
    def test_builds_url_with_nested_path(self, mock_auth_service: MagicMock) -> None:
        """_build_url handles nested endpoint paths."""
        client = GraphClient(mock_auth_service)

        url = client._build_url("/admin/teams/phone/numbers")

        assert url == f"{GRAPH_API_BASE}/admin/teams/phone/numbers"


class TestGraphClientGetHeaders:
    """Tests for GraphClient._get_headers method."""

    @pytest.mark.unit
    def test_returns_authorization_header(self, mock_auth_service: MagicMock) -> None:
        """_get_headers includes Bearer token from AuthService."""
        client = GraphClient(mock_auth_service)

        headers = client._get_headers()

        assert headers["Authorization"] == "Bearer test-access-token-12345"
        mock_auth_service.get_token.assert_called_once()

    @pytest.mark.unit
    def test_returns_content_type_header(self, mock_auth_service: MagicMock) -> None:
        """_get_headers includes JSON content type."""
        client = GraphClient(mock_auth_service)

        headers = client._get_headers()

        assert headers["Content-Type"] == "application/json"


class TestGraphClientContextManager:
    """Tests for GraphClient async context manager protocol."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_enter_creates_client(self, mock_auth_service: MagicMock) -> None:
        """__aenter__ creates httpx.AsyncClient."""
        client = GraphClient(mock_auth_service)

        async with client as entered:
            assert entered is client
            assert client._client is not None
            assert isinstance(client._client, httpx.AsyncClient)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_exit_closes_client(self, mock_auth_service: MagicMock) -> None:
        """__aexit__ closes httpx.AsyncClient."""
        client = GraphClient(mock_auth_service)

        async with client:
            assert client._client is not None

        assert client._client is None

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_client_uses_configured_timeout(
        self, mock_auth_service: MagicMock
    ) -> None:
        """Context manager creates client with configured timeout."""
        client = GraphClient(mock_auth_service, timeout=45)

        async with client:
            assert client._client is not None
            assert client._client.timeout.connect == 45


class TestGraphClientRequest:
    """Tests for GraphClient._request method."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_raises_without_context_manager(
        self, mock_auth_service: MagicMock
    ) -> None:
        """_request raises RuntimeError when client not in context."""
        client = GraphClient(mock_auth_service)

        with pytest.raises(RuntimeError, match="async context manager"):
            await client._request("GET", f"{GRAPH_API_BASE}/users")

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_makes_request_with_headers(
        self, mock_auth_service: MagicMock
    ) -> None:
        """_request includes authentication headers."""
        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(200, json={"value": []})
            )

            async with GraphClient(mock_auth_service) as client:
                response = await client._request("GET", f"{GRAPH_API_BASE}/users")

            assert route.called
            assert response.status_code == 200
            # Verify headers were sent
            request = route.calls[0].request
            assert request.headers["Authorization"] == "Bearer test-access-token-12345"
            assert request.headers["Content-Type"] == "application/json"
