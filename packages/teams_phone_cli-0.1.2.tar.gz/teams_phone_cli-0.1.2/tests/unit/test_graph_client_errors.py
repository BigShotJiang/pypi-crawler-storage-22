"""Unit tests for GraphClient error handling (_handle_error).

Tests for HTTP status code to exception mapping and error message extraction.
"""

from unittest.mock import MagicMock

import httpx
import pytest
import respx

from teams_phone.constants import GRAPH_API_BASE, MAX_RETRIES
from teams_phone.exceptions import (
    AuthenticationError,
    AuthorizationError,
    NotFoundError,
    TeamsPhoneError,
    ValidationError,
)
from teams_phone.infrastructure import GraphClient


class TestGraphClientHandleError:
    """Tests for GraphClient._handle_error method."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_400_raises_validation_error(
        self, mock_auth_service: MagicMock
    ) -> None:
        """400 status code raises ValidationError."""
        with respx.mock:
            respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(
                    400,
                    json={"error": {"code": "BadRequest", "message": "Invalid filter"}},
                )
            )

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(ValidationError) as exc_info:
                    await client.get("/users")

            assert "Bad request" in str(exc_info.value)
            assert "BadRequest" in str(exc_info.value)
            assert "Invalid filter" in str(exc_info.value)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_401_raises_authentication_error(
        self, mock_auth_service: MagicMock
    ) -> None:
        """401 status code raises AuthenticationError with remediation."""
        # Make refresh_token also fail to prevent retry
        mock_auth_service.refresh_token.side_effect = AuthenticationError(
            "Token refresh failed"
        )

        with respx.mock:
            respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(
                    401,
                    json={
                        "error": {
                            "code": "InvalidAuthenticationToken",
                            "message": "Token expired",
                        }
                    },
                )
            )

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(AuthenticationError) as exc_info:
                    await client.get("/users")

            assert "teams-phone auth login" in str(exc_info.value)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_403_raises_authorization_error(
        self, mock_auth_service: MagicMock
    ) -> None:
        """403 status code raises AuthorizationError with remediation."""
        with respx.mock:
            respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(
                    403,
                    json={
                        "error": {
                            "code": "Authorization_RequestDenied",
                            "message": "Insufficient privileges",
                        }
                    },
                )
            )

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(AuthorizationError) as exc_info:
                    await client.get("/users")

            assert "Access denied" in str(exc_info.value)
            assert "Authorization_RequestDenied" in str(exc_info.value)
            assert "Graph API permissions" in str(exc_info.value)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_404_raises_not_found_error(
        self, mock_auth_service: MagicMock
    ) -> None:
        """404 status code raises NotFoundError."""
        with respx.mock:
            respx.get(f"{GRAPH_API_BASE}/users/123").mock(
                return_value=httpx.Response(
                    404,
                    json={
                        "error": {
                            "code": "Request_ResourceNotFound",
                            "message": "User '123' not found",
                        }
                    },
                )
            )

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(NotFoundError) as exc_info:
                    await client.get("/users/123")

            assert "Resource not found" in str(exc_info.value)
            assert "User '123' not found" in str(exc_info.value)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_409_raises_validation_error(
        self, mock_auth_service: MagicMock
    ) -> None:
        """409 status code raises ValidationError for conflicts."""
        with respx.mock:
            respx.post(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(
                    409,
                    json={
                        "error": {"code": "Conflict", "message": "User already exists"}
                    },
                )
            )

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(ValidationError) as exc_info:
                    await client.post("/users", {"displayName": "Test"})

            assert "Conflict" in str(exc_info.value)
            assert "User already exists" in str(exc_info.value)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_500_raises_teams_phone_error(
        self, mock_auth_service: MagicMock
    ) -> None:
        """500 status code raises TeamsPhoneError after retry exhaustion."""
        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users")
            route.side_effect = [
                httpx.Response(
                    500,
                    json={
                        "error": {
                            "code": "InternalServerError",
                            "message": "Server error",
                        }
                    },
                )
                for _ in range(MAX_RETRIES)
            ]

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(TeamsPhoneError) as exc_info:
                    await client.get("/users")

            # After retry exhaustion, _raise_for_exhausted_retries raises
            assert "HTTP 500" in str(exc_info.value)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_extracts_odata_error_code_and_message(
        self, mock_auth_service: MagicMock
    ) -> None:
        """Error message extraction includes OData code and message."""
        with respx.mock:
            respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(
                    400,
                    json={
                        "error": {
                            "code": "Request_BadRequest",
                            "message": "The query is invalid",
                        }
                    },
                )
            )

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(ValidationError) as exc_info:
                    await client.get("/users")

            error_str = str(exc_info.value)
            assert "Request_BadRequest" in error_str
            assert "The query is invalid" in error_str

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_handles_non_json_error_response(
        self, mock_auth_service: MagicMock
    ) -> None:
        """Non-JSON error response uses response text."""
        with respx.mock:
            respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(
                    400,
                    content=b"Plain text error message",
                    headers={"Content-Type": "text/plain"},
                )
            )

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(ValidationError) as exc_info:
                    await client.get("/users")

            assert "Plain text error message" in str(exc_info.value)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_handles_empty_error_response(
        self, mock_auth_service: MagicMock
    ) -> None:
        """Empty error response uses reason phrase."""
        with respx.mock:
            respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(400, content=b"")
            )

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(ValidationError) as exc_info:
                    await client.get("/users")

            # Should contain "Bad request" from our exception message
            assert "Bad request" in str(exc_info.value)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_handles_malformed_json_error(
        self, mock_auth_service: MagicMock
    ) -> None:
        """Malformed JSON error falls back gracefully."""
        with respx.mock:
            respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(
                    403,
                    content=b"{invalid json",
                    headers={"Content-Type": "application/json"},
                )
            )

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(AuthorizationError) as exc_info:
                    await client.get("/users")

            # Should still raise the correct exception type
            assert "Access denied" in str(exc_info.value)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_handles_error_without_code(
        self, mock_auth_service: MagicMock
    ) -> None:
        """Error response without code still extracts message."""
        with respx.mock:
            respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(
                    404, json={"error": {"message": "Not found"}}
                )
            )

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(NotFoundError) as exc_info:
                    await client.get("/users")

            assert "Not found" in str(exc_info.value)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_unknown_4xx_raises_teams_phone_error(
        self, mock_auth_service: MagicMock
    ) -> None:
        """Unknown 4xx status codes raise TeamsPhoneError."""
        with respx.mock:
            respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(
                    418, json={"error": {"message": "I'm a teapot"}}
                )
            )

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(TeamsPhoneError) as exc_info:
                    await client.get("/users")

            assert "HTTP 418" in str(exc_info.value)
            assert "I'm a teapot" in str(exc_info.value)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_502_raises_after_retry_exhaustion(
        self, mock_auth_service: MagicMock
    ) -> None:
        """502 status raises TeamsPhoneError after retries exhausted."""
        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users")
            route.side_effect = [httpx.Response(502) for _ in range(MAX_RETRIES)]

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(TeamsPhoneError) as exc_info:
                    await client.get("/users")

            assert "HTTP 502" in str(exc_info.value)
            assert route.call_count == MAX_RETRIES
