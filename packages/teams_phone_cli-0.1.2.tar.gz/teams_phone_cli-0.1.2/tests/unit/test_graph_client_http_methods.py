"""Unit tests for GraphClient HTTP methods (GET, POST).

Tests for the get() and post() convenience methods.
"""

import json
from unittest.mock import MagicMock

import httpx
import pytest
import respx

from teams_phone.constants import GRAPH_API_BASE
from teams_phone.exceptions import NotFoundError, ValidationError
from teams_phone.infrastructure import GraphClient


class TestGraphClientGet:
    """Tests for GraphClient.get method."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_get_returns_json(self, mock_auth_service: MagicMock) -> None:
        """get method returns parsed JSON response."""
        expected_data = {"value": [{"id": "user1"}, {"id": "user2"}]}

        with respx.mock:
            respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(200, json=expected_data)
            )

            async with GraphClient(mock_auth_service) as client:
                result = await client.get("/users")

            assert result == expected_data

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_get_with_params(self, mock_auth_service: MagicMock) -> None:
        """get method passes query parameters."""
        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(200, json={"value": []})
            )

            async with GraphClient(mock_auth_service) as client:
                await client.get("/users", params={"$top": "10", "$filter": "active"})

            assert route.called
            request = route.calls[0].request
            # URL encodes $ as %24
            assert "top=10" in str(request.url)
            assert "filter=active" in str(request.url)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_get_raises_not_found_error(
        self, mock_auth_service: MagicMock
    ) -> None:
        """get method raises NotFoundError on 404 response."""
        with respx.mock:
            respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(
                    404,
                    json={
                        "error": {
                            "code": "ResourceNotFound",
                            "message": "User not found",
                        }
                    },
                )
            )

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(NotFoundError) as exc_info:
                    await client.get("/users")

            assert "ResourceNotFound" in str(exc_info.value)
            assert "User not found" in str(exc_info.value)


class TestGraphClientPost:
    """Tests for GraphClient.post method."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_post_returns_json(self, mock_auth_service: MagicMock) -> None:
        """post method returns parsed JSON response."""
        expected_response = {"id": "new-user", "displayName": "Test User"}
        request_body = {"displayName": "Test User"}

        with respx.mock:
            respx.post(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(201, json=expected_response)
            )

            async with GraphClient(mock_auth_service) as client:
                result = await client.post("/users", request_body)

            assert result == expected_response

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_post_sends_json_body(self, mock_auth_service: MagicMock) -> None:
        """post method sends request body as JSON."""
        request_body = {"displayName": "Test User", "mail": "test@example.com"}

        with respx.mock:
            route = respx.post(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(201, json={"id": "user1"})
            )

            async with GraphClient(mock_auth_service) as client:
                await client.post("/users", request_body)

            assert route.called
            request = route.calls[0].request
            # Verify JSON body was sent
            sent_body = json.loads(request.content)
            assert sent_body == request_body

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_post_raises_validation_error(
        self, mock_auth_service: MagicMock
    ) -> None:
        """post method raises ValidationError on 400 response."""
        with respx.mock:
            respx.post(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(
                    400,
                    json={
                        "error": {"code": "BadRequest", "message": "Invalid user data"}
                    },
                )
            )

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(ValidationError) as exc_info:
                    await client.post("/users", {"invalid": "data"})

            assert "BadRequest" in str(exc_info.value)
            assert "Invalid user data" in str(exc_info.value)
