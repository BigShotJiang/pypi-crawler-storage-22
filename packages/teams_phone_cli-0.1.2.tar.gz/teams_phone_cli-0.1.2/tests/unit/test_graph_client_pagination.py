"""Unit tests for GraphClient pagination (get_paginated).

Tests for the get_paginated async generator including multi-page handling,
max_items limits, and edge cases.
"""

from unittest.mock import MagicMock

import httpx
import pytest
import respx

from teams_phone.constants import GRAPH_API_BASE
from teams_phone.exceptions import ContractError, NotFoundError
from teams_phone.infrastructure import GraphClient


class TestGraphClientGetPaginated:
    """Tests for GraphClient.get_paginated method."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_single_page_yields_all_items(
        self, mock_auth_service: MagicMock
    ) -> None:
        """get_paginated yields all items from single page response."""
        response_data = {"value": [{"id": "user1"}, {"id": "user2"}, {"id": "user3"}]}

        with respx.mock:
            respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(200, json=response_data)
            )

            async with GraphClient(mock_auth_service) as client:
                items = [item async for item in client.get_paginated("/users")]

            assert len(items) == 3
            assert items[0] == {"id": "user1"}
            assert items[1] == {"id": "user2"}
            assert items[2] == {"id": "user3"}

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_multi_page_follows_nextlink(
        self, mock_auth_service: MagicMock
    ) -> None:
        """get_paginated follows @odata.nextLink for multiple pages."""
        next_link = f"{GRAPH_API_BASE}/users?$skip=2"
        page1_data = {
            "value": [{"id": "user1"}, {"id": "user2"}],
            "@odata.nextLink": next_link,
        }
        page2_data = {
            "value": [{"id": "user3"}, {"id": "user4"}],
        }

        with respx.mock:
            # Use url__eq for exact matching to avoid prefix matching issues
            respx.get(url__eq=f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(200, json=page1_data)
            )
            respx.get(url__eq=next_link).mock(
                return_value=httpx.Response(200, json=page2_data)
            )

            async with GraphClient(mock_auth_service) as client:
                items = [item async for item in client.get_paginated("/users")]

            assert len(items) == 4
            assert items[0] == {"id": "user1"}
            assert items[3] == {"id": "user4"}

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_max_items_stops_mid_page(self, mock_auth_service: MagicMock) -> None:
        """get_paginated stops yielding when max_items reached mid-page."""
        response_data = {"value": [{"id": "user1"}, {"id": "user2"}, {"id": "user3"}]}

        with respx.mock:
            respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(200, json=response_data)
            )

            async with GraphClient(mock_auth_service) as client:
                items = [
                    item async for item in client.get_paginated("/users", max_items=2)
                ]

            assert len(items) == 2
            assert items[0] == {"id": "user1"}
            assert items[1] == {"id": "user2"}

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_max_items_stops_before_fetching_unnecessary_page(
        self, mock_auth_service: MagicMock
    ) -> None:
        """get_paginated doesn't fetch next page if max_items reached."""
        next_link = f"{GRAPH_API_BASE}/users?$skip=2"
        page1_data = {
            "value": [{"id": "user1"}, {"id": "user2"}],
            "@odata.nextLink": next_link,
        }

        with respx.mock:
            route1 = respx.get(url__eq=f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(200, json=page1_data)
            )
            route2 = respx.get(url__eq=next_link).mock(
                return_value=httpx.Response(200, json={"value": [{"id": "user3"}]})
            )

            async with GraphClient(mock_auth_service) as client:
                items = [
                    item async for item in client.get_paginated("/users", max_items=2)
                ]

            assert len(items) == 2
            assert route1.call_count == 1
            assert route2.call_count == 0  # Second page not fetched

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_empty_value_yields_nothing(
        self, mock_auth_service: MagicMock
    ) -> None:
        """get_paginated handles empty value array gracefully."""
        response_data: dict[str, list[dict[str, str]]] = {"value": []}

        with respx.mock:
            respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(200, json=response_data)
            )

            async with GraphClient(mock_auth_service) as client:
                items = [item async for item in client.get_paginated("/users")]

            assert items == []

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_missing_value_raises_contract_error(
        self, mock_auth_service: MagicMock
    ) -> None:
        """get_paginated raises ContractError if 'value' key is missing."""
        response_data = {"data": [{"id": "user1"}]}  # Wrong key

        with respx.mock:
            respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(200, json=response_data)
            )

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(ContractError) as exc_info:
                    async for _ in client.get_paginated("/users"):
                        pass

            assert "missing 'value' key" in str(exc_info.value)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_max_items_zero_returns_immediately(
        self, mock_auth_service: MagicMock
    ) -> None:
        """get_paginated with max_items=0 returns without making requests."""
        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(200, json={"value": [{"id": "user1"}]})
            )

            async with GraphClient(mock_auth_service) as client:
                items = [
                    item async for item in client.get_paginated("/users", max_items=0)
                ]

            assert items == []
            assert route.call_count == 0

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_retry_logic_applies_to_paginated_request(
        self, mock_auth_service: MagicMock
    ) -> None:
        """get_paginated retries on transient failures."""
        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users")
            route.side_effect = [
                httpx.Response(429, headers={"Retry-After": "0"}),
                httpx.Response(200, json={"value": [{"id": "user1"}]}),
            ]

            async with GraphClient(mock_auth_service) as client:
                items = [item async for item in client.get_paginated("/users")]

            assert len(items) == 1
            assert route.call_count == 2

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_retry_on_second_page(self, mock_auth_service: MagicMock) -> None:
        """get_paginated retries transient failures on subsequent pages."""
        next_link = f"{GRAPH_API_BASE}/users?$skip=1"
        page1_data = {
            "value": [{"id": "user1"}],
            "@odata.nextLink": next_link,
        }

        with respx.mock:
            respx.get(url__eq=f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(200, json=page1_data)
            )
            route2 = respx.get(url__eq=next_link)
            route2.side_effect = [
                httpx.Response(503),
                httpx.Response(200, json={"value": [{"id": "user2"}]}),
            ]

            async with GraphClient(mock_auth_service) as client:
                items = [item async for item in client.get_paginated("/users")]

            assert len(items) == 2
            assert route2.call_count == 2

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_passes_params_to_initial_request(
        self, mock_auth_service: MagicMock
    ) -> None:
        """get_paginated passes query parameters to initial request."""
        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(200, json={"value": []})
            )

            async with GraphClient(mock_auth_service) as client:
                items = [
                    item
                    async for item in client.get_paginated(
                        "/users", params={"$top": "10", "$filter": "active eq true"}
                    )
                ]

            assert items == []
            assert route.called
            request = route.calls[0].request
            assert "top=10" in str(request.url)
            assert "filter=active" in str(request.url)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_raises_not_found_on_404_response(
        self, mock_auth_service: MagicMock
    ) -> None:
        """get_paginated raises NotFoundError on 404 response."""
        with respx.mock:
            respx.get(f"{GRAPH_API_BASE}/users").mock(
                return_value=httpx.Response(
                    404,
                    json={
                        "error": {
                            "code": "ResourceNotFound",
                            "message": "Users not found",
                        }
                    },
                )
            )

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(NotFoundError) as exc_info:
                    async for _ in client.get_paginated("/users"):
                        pass

            assert "ResourceNotFound" in str(exc_info.value)
            assert "Users not found" in str(exc_info.value)
