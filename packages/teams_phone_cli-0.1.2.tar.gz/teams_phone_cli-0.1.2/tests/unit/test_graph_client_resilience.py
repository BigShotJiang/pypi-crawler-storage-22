"""Unit tests for GraphClient resilience (retry, token refresh).

Tests for retry logic, backoff, token refresh on 401, and related helper functions.
"""

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import httpx
import pytest
import respx

from teams_phone.constants import GRAPH_API_BASE, MAX_RETRIES
from teams_phone.exceptions import (
    AuthenticationError,
    RateLimitError,
    TeamsPhoneError,
)
from teams_phone.infrastructure import GraphClient
from teams_phone.infrastructure.graph_client import (
    _get_retry_after,
    _is_retryable_status,
)


class TestRetryHelperFunctions:
    """Tests for retry helper functions."""

    @pytest.mark.unit
    def test_is_retryable_status_429(self) -> None:
        """429 status code is retryable."""
        response = httpx.Response(429)
        assert _is_retryable_status(response) is True

    @pytest.mark.unit
    def test_is_retryable_status_500(self) -> None:
        """500 status code is retryable."""
        response = httpx.Response(500)
        assert _is_retryable_status(response) is True

    @pytest.mark.unit
    def test_is_retryable_status_502(self) -> None:
        """502 status code is retryable."""
        response = httpx.Response(502)
        assert _is_retryable_status(response) is True

    @pytest.mark.unit
    def test_is_retryable_status_503(self) -> None:
        """503 status code is retryable."""
        response = httpx.Response(503)
        assert _is_retryable_status(response) is True

    @pytest.mark.unit
    def test_is_retryable_status_504(self) -> None:
        """504 status code is retryable."""
        response = httpx.Response(504)
        assert _is_retryable_status(response) is True

    @pytest.mark.unit
    def test_is_retryable_status_400_not_retryable(self) -> None:
        """400 status code is not retryable."""
        response = httpx.Response(400)
        assert _is_retryable_status(response) is False

    @pytest.mark.unit
    def test_is_retryable_status_401_not_retryable(self) -> None:
        """401 status code is not retryable (handled separately)."""
        response = httpx.Response(401)
        assert _is_retryable_status(response) is False

    @pytest.mark.unit
    def test_is_retryable_status_403_not_retryable(self) -> None:
        """403 status code is not retryable."""
        response = httpx.Response(403)
        assert _is_retryable_status(response) is False

    @pytest.mark.unit
    def test_is_retryable_status_404_not_retryable(self) -> None:
        """404 status code is not retryable."""
        response = httpx.Response(404)
        assert _is_retryable_status(response) is False

    @pytest.mark.unit
    def test_get_retry_after_integer_seconds(self) -> None:
        """Parses Retry-After header with integer seconds."""
        response = httpx.Response(429, headers={"Retry-After": "5"})
        assert _get_retry_after(response) == 5.0

    @pytest.mark.unit
    def test_get_retry_after_float_seconds(self) -> None:
        """Parses Retry-After header with decimal seconds."""
        response = httpx.Response(429, headers={"Retry-After": "2.5"})
        assert _get_retry_after(response) == 2.5

    @pytest.mark.unit
    def test_get_retry_after_missing_header(self) -> None:
        """Returns None when Retry-After header is missing."""
        response = httpx.Response(429)
        assert _get_retry_after(response) is None

    @pytest.mark.unit
    def test_get_retry_after_http_date_format(self) -> None:
        """Parses Retry-After header with HTTP-date format."""
        # Use a fixed time 10 seconds in the future
        future_time = datetime(2026, 1, 29, 0, 0, 10, tzinfo=timezone.utc)
        date_str = future_time.strftime("%a, %d %b %Y %H:%M:%S GMT")
        response = httpx.Response(429, headers={"Retry-After": date_str})

        with patch("teams_phone.infrastructure.graph_client.datetime") as mock_datetime:
            mock_datetime.now.return_value = datetime(
                2026, 1, 29, 0, 0, 0, tzinfo=timezone.utc
            )
            mock_datetime.side_effect = lambda *args, **kwargs: datetime(
                *args, **kwargs
            )
            result = _get_retry_after(response)

        # Should be approximately 10 seconds
        assert result is not None
        assert 9.0 <= result <= 11.0

    @pytest.mark.unit
    def test_get_retry_after_invalid_format(self) -> None:
        """Returns None for invalid Retry-After format."""
        response = httpx.Response(429, headers={"Retry-After": "invalid"})
        assert _get_retry_after(response) is None


class TestGraphClientRetry:
    """Tests for GraphClient retry behavior."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_retries_on_429(self, mock_auth_service: MagicMock) -> None:
        """Request retries on 429 and succeeds."""
        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users")
            route.side_effect = [
                httpx.Response(429, headers={"Retry-After": "0"}),
                httpx.Response(200, json={"value": []}),
            ]

            async with GraphClient(mock_auth_service) as client:
                response = await client._request("GET", f"{GRAPH_API_BASE}/users")

            assert response.status_code == 200
            assert route.call_count == 2

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_retries_on_500(self, mock_auth_service: MagicMock) -> None:
        """Request retries on 500 and succeeds."""
        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users")
            route.side_effect = [
                httpx.Response(500),
                httpx.Response(200, json={"value": []}),
            ]

            async with GraphClient(mock_auth_service) as client:
                response = await client._request("GET", f"{GRAPH_API_BASE}/users")

            assert response.status_code == 200
            assert route.call_count == 2

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_retries_on_502(self, mock_auth_service: MagicMock) -> None:
        """Request retries on 502 and succeeds."""
        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users")
            route.side_effect = [
                httpx.Response(502),
                httpx.Response(200, json={"value": []}),
            ]

            async with GraphClient(mock_auth_service) as client:
                response = await client._request("GET", f"{GRAPH_API_BASE}/users")

            assert response.status_code == 200
            assert route.call_count == 2

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_retries_on_503(self, mock_auth_service: MagicMock) -> None:
        """Request retries on 503 and succeeds."""
        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users")
            route.side_effect = [
                httpx.Response(503),
                httpx.Response(200, json={"value": []}),
            ]

            async with GraphClient(mock_auth_service) as client:
                response = await client._request("GET", f"{GRAPH_API_BASE}/users")

            assert response.status_code == 200
            assert route.call_count == 2

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_retries_on_504(self, mock_auth_service: MagicMock) -> None:
        """Request retries on 504 and succeeds."""
        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users")
            route.side_effect = [
                httpx.Response(504),
                httpx.Response(200, json={"value": []}),
            ]

            async with GraphClient(mock_auth_service) as client:
                response = await client._request("GET", f"{GRAPH_API_BASE}/users")

            assert response.status_code == 200
            assert route.call_count == 2

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_raises_rate_limit_error_after_max_retries(
        self, mock_auth_service: MagicMock
    ) -> None:
        """Raises RateLimitError after MAX_RETRIES on 429."""
        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users")
            route.side_effect = [
                httpx.Response(429, headers={"Retry-After": "0"})
                for _ in range(MAX_RETRIES)
            ]

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(RateLimitError) as exc_info:
                    await client._request("GET", f"{GRAPH_API_BASE}/users")

            assert "Rate limit exceeded" in str(exc_info.value)
            assert route.call_count == MAX_RETRIES

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_raises_teams_phone_error_after_max_retries_on_5xx(
        self, mock_auth_service: MagicMock
    ) -> None:
        """Raises TeamsPhoneError after MAX_RETRIES on 503."""
        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users")
            route.side_effect = [httpx.Response(503) for _ in range(MAX_RETRIES)]

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(TeamsPhoneError) as exc_info:
                    await client._request("GET", f"{GRAPH_API_BASE}/users")

            assert "HTTP 503" in str(exc_info.value)
            assert route.call_count == MAX_RETRIES

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_no_retry_on_400(self, mock_auth_service: MagicMock) -> None:
        """Does not retry on 400 status code."""
        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users")
            route.mock(return_value=httpx.Response(400, json={"error": "bad request"}))

            async with GraphClient(mock_auth_service) as client:
                response = await client._request("GET", f"{GRAPH_API_BASE}/users")

            assert response.status_code == 400
            assert route.call_count == 1

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_no_retry_on_403(self, mock_auth_service: MagicMock) -> None:
        """Does not retry on 403 status code."""
        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users")
            route.mock(return_value=httpx.Response(403, json={"error": "forbidden"}))

            async with GraphClient(mock_auth_service) as client:
                response = await client._request("GET", f"{GRAPH_API_BASE}/users")

            assert response.status_code == 403
            assert route.call_count == 1

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_no_retry_on_404(self, mock_auth_service: MagicMock) -> None:
        """Does not retry on 404 status code."""
        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users")
            route.mock(return_value=httpx.Response(404, json={"error": "not found"}))

            async with GraphClient(mock_auth_service) as client:
                response = await client._request("GET", f"{GRAPH_API_BASE}/users")

            assert response.status_code == 404
            assert route.call_count == 1


class TestGraphClientTokenRefresh:
    """Tests for 401 token refresh behavior."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_refreshes_token_on_401_and_retries(
        self, mock_auth_service: MagicMock
    ) -> None:
        """Refreshes token on 401 and retries the request."""
        mock_auth_service.refresh_token.return_value = MagicMock(
            access_token="new-token"
        )

        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users")
            route.side_effect = [
                httpx.Response(401, json={"error": "unauthorized"}),
                httpx.Response(200, json={"value": []}),
            ]

            async with GraphClient(mock_auth_service) as client:
                response = await client._request("GET", f"{GRAPH_API_BASE}/users")

            assert response.status_code == 200
            mock_auth_service.refresh_token.assert_called_once()
            assert route.call_count == 2

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_raises_auth_error_after_401_double_failure(
        self, mock_auth_service: MagicMock
    ) -> None:
        """Raises AuthenticationError when 401 persists after token refresh."""
        mock_auth_service.refresh_token.return_value = MagicMock(
            access_token="new-token"
        )

        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users")
            route.side_effect = [
                httpx.Response(401, json={"error": "unauthorized"}),
                httpx.Response(401, json={"error": "still unauthorized"}),
            ]

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(AuthenticationError) as exc_info:
                    await client._request("GET", f"{GRAPH_API_BASE}/users")

            assert "Authentication failed" in str(exc_info.value)
            assert "teams-phone auth login" in str(exc_info.value)
            mock_auth_service.refresh_token.assert_called_once()
            assert route.call_count == 2

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_raises_auth_error_when_refresh_fails(
        self, mock_auth_service: MagicMock
    ) -> None:
        """Raises AuthenticationError when token refresh itself fails."""
        mock_auth_service.refresh_token.side_effect = AuthenticationError(
            "Token refresh failed"
        )

        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users")
            route.mock(return_value=httpx.Response(401, json={"error": "unauthorized"}))

            async with GraphClient(mock_auth_service) as client:
                with pytest.raises(AuthenticationError) as exc_info:
                    await client._request("GET", f"{GRAPH_API_BASE}/users")

            assert "Authentication failed" in str(exc_info.value)
            mock_auth_service.refresh_token.assert_called_once()
            assert route.call_count == 1

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_401_handling_separate_from_retry_logic(
        self, mock_auth_service: MagicMock
    ) -> None:
        """401 is handled separately from transient retry logic."""
        # 401 should not count against the MAX_RETRIES for transient errors
        mock_auth_service.refresh_token.return_value = MagicMock(
            access_token="new-token"
        )

        with respx.mock:
            route = respx.get(f"{GRAPH_API_BASE}/users")
            # 401 -> token refresh -> 503 (retry) -> 200 (success)
            route.side_effect = [
                httpx.Response(401, json={"error": "unauthorized"}),
                httpx.Response(503),
                httpx.Response(200, json={"value": []}),
            ]

            async with GraphClient(mock_auth_service) as client:
                response = await client._request("GET", f"{GRAPH_API_BASE}/users")

            assert response.status_code == 200
            mock_auth_service.refresh_token.assert_called_once()
            assert route.call_count == 3
