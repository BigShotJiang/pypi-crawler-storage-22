"""Unit tests for API response, config, tenant, policy, and location Pydantic models."""

from uuid import UUID, uuid4

import pytest
from pydantic import ValidationError

from teams_phone.models import (
    AuthMethod,
    CacheSettings,
    Config,
    EmergencyLocation,
    GraphErrorDetail,
    GraphErrorResponse,
    GraphListResponse,
    NetworkSettings,
    NumberAssignment,
    NumberType,
    Policy,
    TenantProfile,
    UserConfiguration,
)


class TestTenantProfile:
    """Tests for TenantProfile model."""

    @pytest.mark.unit
    def test_create_minimal_profile(self) -> None:
        """TenantProfile can be created with required fields only."""
        tenant_id = uuid4()
        client_id = uuid4()
        profile = TenantProfile(
            name="contoso",
            tenant_id=tenant_id,
            client_id=client_id,
            display_name="Contoso Corp",
            auth_method=AuthMethod.CERTIFICATE,
        )
        assert profile.name == "contoso"
        assert profile.tenant_id == tenant_id
        assert profile.client_id == client_id
        assert profile.display_name == "Contoso Corp"
        assert profile.auth_method == AuthMethod.CERTIFICATE
        assert profile.cert_path is None
        assert profile.default_location is None

    @pytest.mark.unit
    def test_create_full_profile(self) -> None:
        """TenantProfile can be created with all fields."""
        profile = TenantProfile(
            name="contoso",
            tenant_id=uuid4(),
            client_id=uuid4(),
            display_name="Contoso Corp",
            auth_method=AuthMethod.CERTIFICATE,
            cert_path="/path/to/cert.pem",
            default_location="Main Office",
        )
        assert profile.cert_path == "/path/to/cert.pem"
        assert profile.default_location == "Main Office"

    @pytest.mark.unit
    def test_uuid_from_string(self) -> None:
        """TenantProfile accepts UUID strings for tenant_id and client_id."""
        tenant_uuid = "12345678-1234-5678-1234-567812345678"
        client_uuid = "87654321-4321-8765-4321-876543218765"
        profile = TenantProfile(
            name="test",
            tenant_id=tenant_uuid,  # type: ignore[arg-type]
            client_id=client_uuid,  # type: ignore[arg-type]
            display_name="Test",
            auth_method=AuthMethod.CERTIFICATE,
        )
        assert profile.tenant_id == UUID(tenant_uuid)
        assert profile.client_id == UUID(client_uuid)

    @pytest.mark.unit
    def test_auth_method_from_string(self) -> None:
        """TenantProfile accepts auth_method as string."""
        profile = TenantProfile(
            name="test",
            tenant_id=uuid4(),
            client_id=uuid4(),
            display_name="Test",
            auth_method="certificate",  # type: ignore[arg-type]
        )
        assert profile.auth_method == AuthMethod.CERTIFICATE

    @pytest.mark.unit
    def test_extra_field_rejected(self) -> None:
        """TenantProfile rejects unknown fields (extra='forbid')."""
        with pytest.raises(ValidationError) as exc_info:
            TenantProfile(
                name="test",
                tenant_id=uuid4(),
                client_id=uuid4(),
                display_name="Test",
                auth_method=AuthMethod.CERTIFICATE,
                unknown_field="should fail",  # type: ignore[call-arg]
            )
        assert "extra_forbidden" in str(exc_info.value)

    @pytest.mark.unit
    def test_invalid_uuid_rejected(self) -> None:
        """TenantProfile rejects invalid UUID strings."""
        with pytest.raises(ValidationError) as exc_info:
            TenantProfile(
                name="test",
                tenant_id="not-a-uuid",  # type: ignore[arg-type]
                client_id=uuid4(),
                display_name="Test",
                auth_method=AuthMethod.CERTIFICATE,
            )
        assert "uuid" in str(exc_info.value).lower()

    @pytest.mark.unit
    def test_invalid_auth_method_rejected(self) -> None:
        """TenantProfile rejects invalid auth method."""
        with pytest.raises(ValidationError) as exc_info:
            TenantProfile(
                name="test",
                tenant_id=uuid4(),
                client_id=uuid4(),
                display_name="Test",
                auth_method="invalid-method",  # type: ignore[arg-type]
            )
        assert "auth_method" in str(exc_info.value).lower()

    @pytest.mark.unit
    def test_serialization(self) -> None:
        """TenantProfile serializes to dict correctly."""
        tenant_id = uuid4()
        client_id = uuid4()
        profile = TenantProfile(
            name="contoso",
            tenant_id=tenant_id,
            client_id=client_id,
            display_name="Contoso Corp",
            auth_method=AuthMethod.CERTIFICATE,
        )
        data = profile.model_dump()
        assert data["name"] == "contoso"
        assert data["tenant_id"] == tenant_id
        assert data["client_id"] == client_id
        assert data["auth_method"] == AuthMethod.CERTIFICATE
        assert data["cert_path"] is None

    @pytest.mark.unit
    def test_json_serialization(self) -> None:
        """TenantProfile serializes to JSON correctly."""
        tenant_id = uuid4()
        profile = TenantProfile(
            name="test",
            tenant_id=tenant_id,
            client_id=uuid4(),
            display_name="Test",
            auth_method=AuthMethod.CLIENT_SECRET,
        )
        json_str = profile.model_dump_json()
        assert str(tenant_id) in json_str
        assert "client-secret" in json_str


class TestCacheSettings:
    """Tests for CacheSettings model."""

    @pytest.mark.unit
    def test_default_values(self) -> None:
        """CacheSettings uses default values when not provided."""
        settings = CacheSettings()
        assert settings.cache_path == "~/.teams-phone/cache"
        assert settings.stale_days == 30

    @pytest.mark.unit
    def test_custom_values(self) -> None:
        """CacheSettings accepts custom values."""
        settings = CacheSettings(
            cache_path="/custom/cache",
            stale_days=7,
        )
        assert settings.cache_path == "/custom/cache"
        assert settings.stale_days == 7

    @pytest.mark.unit
    def test_extra_field_rejected(self) -> None:
        """CacheSettings rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            CacheSettings(extra="field")  # type: ignore[call-arg]
        assert "extra_forbidden" in str(exc_info.value)


class TestNetworkSettings:
    """Tests for NetworkSettings model."""

    @pytest.mark.unit
    def test_default_values(self) -> None:
        """NetworkSettings uses default values when not provided."""
        settings = NetworkSettings()
        assert settings.timeout == 30
        assert settings.max_retries == 3

    @pytest.mark.unit
    def test_custom_values(self) -> None:
        """NetworkSettings accepts custom values."""
        settings = NetworkSettings(
            timeout=60,
            max_retries=5,
        )
        assert settings.timeout == 60
        assert settings.max_retries == 5


class TestConfig:
    """Tests for Config model."""

    @pytest.mark.unit
    def test_default_values(self) -> None:
        """Config uses default values when not provided."""
        config = Config()
        assert config.config_path == "~/.teams-phone/config.toml"
        assert config.token_path == "~/.teams-phone/tokens"
        assert config.default_tenant is None
        assert config.cache.cache_path == "~/.teams-phone/cache"
        assert config.network.timeout == 30
        assert config.tenants == {}

    @pytest.mark.unit
    def test_with_tenant(self) -> None:
        """Config can contain tenant profiles."""
        profile = TenantProfile(
            name="contoso",
            tenant_id=uuid4(),
            client_id=uuid4(),
            display_name="Contoso Corp",
            auth_method=AuthMethod.CERTIFICATE,
        )
        config = Config(
            default_tenant="contoso",
            tenants={"contoso": profile},
        )
        assert config.default_tenant == "contoso"
        assert "contoso" in config.tenants
        assert config.tenants["contoso"].display_name == "Contoso Corp"

    @pytest.mark.unit
    def test_with_custom_settings(self) -> None:
        """Config can have custom cache and network settings."""
        config = Config(
            cache=CacheSettings(stale_days=7),
            network=NetworkSettings(timeout=60),
        )
        assert config.cache.stale_days == 7
        assert config.network.timeout == 60

    @pytest.mark.unit
    def test_extra_field_rejected(self) -> None:
        """Config rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            Config(unknown="field")  # type: ignore[call-arg]
        assert "extra_forbidden" in str(exc_info.value)

    @pytest.mark.unit
    def test_serialization(self) -> None:
        """Config serializes to dict correctly."""
        config = Config(default_tenant="test")
        data = config.model_dump()
        assert data["default_tenant"] == "test"
        assert "cache" in data
        assert "network" in data
        assert "tenants" in data

    @pytest.mark.unit
    def test_nested_tenant_serialization(self) -> None:
        """Config with tenants serializes correctly."""
        tenant_id = uuid4()
        profile = TenantProfile(
            name="test",
            tenant_id=tenant_id,
            client_id=uuid4(),
            display_name="Test",
            auth_method=AuthMethod.CERTIFICATE,
        )
        config = Config(tenants={"test": profile})
        data = config.model_dump()
        assert data["tenants"]["test"]["tenant_id"] == tenant_id


class TestPolicy:
    """Tests for Policy model (CSV cache data)."""

    @pytest.mark.unit
    def test_create_from_camel_case(self) -> None:
        """Policy can be created with camelCase aliases (CSV column names)."""
        policy = Policy(
            policyType="TeamsCallingPolicy",
            policyName="Global",
            policyId="Global",
            description="Default calling policy",
            isGlobal=True,
        )
        assert policy.policy_type == "TeamsCallingPolicy"
        assert policy.policy_name == "Global"
        assert policy.policy_id == "Global"
        assert policy.description == "Default calling policy"
        assert policy.is_global is True

    @pytest.mark.unit
    def test_create_from_snake_case(self) -> None:
        """Policy can be created with snake_case field names (populate_by_name)."""
        policy = Policy.model_validate(
            {
                "policy_type": "TenantDialPlan",
                "policy_name": "US-DialPlan",
                "policy_id": "US-DialPlan",
                "description": "US dialing rules",
                "is_global": False,
            }
        )
        assert policy.policy_type == "TenantDialPlan"
        assert policy.policy_name == "US-DialPlan"
        assert policy.is_global is False

    @pytest.mark.unit
    def test_create_with_null_description(self) -> None:
        """Policy can be created with null description."""
        policy = Policy(
            policyType="TeamsVoicemailPolicy",
            policyName="Custom",
            policyId="Custom",
            description=None,
            isGlobal=False,
        )
        assert policy.description is None

    @pytest.mark.unit
    def test_extra_field_rejected(self) -> None:
        """Policy rejects unknown fields (extra='forbid')."""
        with pytest.raises(ValidationError) as exc_info:
            Policy(
                policyType="TeamsCallingPolicy",
                policyName="Global",
                policyId="Global",
                description=None,
                isGlobal=True,
                extra_field="should fail",  # type: ignore[call-arg]
            )
        assert "extra_forbidden" in str(exc_info.value)

    @pytest.mark.unit
    def test_missing_required_field_rejected(self) -> None:
        """Policy requires all fields except description."""
        with pytest.raises(ValidationError):
            Policy(
                policyType="TeamsCallingPolicy",
                policyName="Global",
                # Missing policyId, isGlobal
            )  # type: ignore[call-arg]

    @pytest.mark.unit
    def test_serialization(self) -> None:
        """Policy serializes to dict correctly."""
        policy = Policy(
            policyType="TeamsCallingPolicy",
            policyName="Global",
            policyId="Global",
            description="Test",
            isGlobal=True,
        )
        data = policy.model_dump()
        assert data["policy_type"] == "TeamsCallingPolicy"
        assert data["policy_name"] == "Global"
        assert data["is_global"] is True

    @pytest.mark.unit
    def test_serialization_by_alias(self) -> None:
        """Policy serializes with camelCase aliases."""
        policy = Policy(
            policyType="TeamsCallingPolicy",
            policyName="Global",
            policyId="Global",
            description=None,
            isGlobal=True,
        )
        data = policy.model_dump(by_alias=True)
        assert "policyType" in data
        assert "policyName" in data
        assert "isGlobal" in data


class TestEmergencyLocation:
    """Tests for EmergencyLocation model (CSV cache data)."""

    @pytest.mark.unit
    def test_create_from_camel_case(self) -> None:
        """EmergencyLocation can be created with camelCase aliases."""
        location = EmergencyLocation(
            locationId="loc-uuid-123",
            civicAddressId="civic-uuid-456",
            description="Main Office",
            companyName="Contoso Corp",
            address="123 Main St",
            city="Seattle",
            stateOrProvince="WA",
            postalCode="98101",
            countryOrRegion="US",
            isDefault=True,
        )
        assert location.location_id == "loc-uuid-123"
        assert location.civic_address_id == "civic-uuid-456"
        assert location.description == "Main Office"
        assert location.company_name == "Contoso Corp"
        assert location.address == "123 Main St"
        assert location.city == "Seattle"
        assert location.state_or_province == "WA"
        assert location.postal_code == "98101"
        assert location.country_or_region == "US"
        assert location.is_default is True

    @pytest.mark.unit
    def test_create_from_snake_case(self) -> None:
        """EmergencyLocation can be created with snake_case field names."""
        location = EmergencyLocation.model_validate(
            {
                "location_id": "loc-123",
                "civic_address_id": "civic-456",
                "description": "Branch Office",
                "company_name": "Contoso",
                "address": "456 Oak Ave",
                "city": "Portland",
                "state_or_province": "OR",
                "postal_code": "97201",
                "country_or_region": "US",
                "is_default": False,
            }
        )
        assert location.location_id == "loc-123"
        assert location.city == "Portland"
        assert location.is_default is False

    @pytest.mark.unit
    def test_create_with_null_optional_fields(self) -> None:
        """EmergencyLocation can have null optional fields."""
        location = EmergencyLocation(
            locationId="loc-123",
            civicAddressId="civic-456",
            description="Remote Location",
            companyName=None,
            address=None,
            city=None,
            stateOrProvince=None,
            postalCode=None,
            countryOrRegion=None,
            isDefault=False,
        )
        assert location.company_name is None
        assert location.address is None
        assert location.city is None
        assert location.state_or_province is None
        assert location.postal_code is None
        assert location.country_or_region is None

    @pytest.mark.unit
    def test_extra_field_rejected(self) -> None:
        """EmergencyLocation rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            EmergencyLocation(
                locationId="loc-123",
                civicAddressId="civic-456",
                description="Test",
                companyName=None,
                address=None,
                city=None,
                stateOrProvince=None,
                postalCode=None,
                countryOrRegion=None,
                isDefault=False,
                extra_field="should fail",  # type: ignore[call-arg]
            )
        assert "extra_forbidden" in str(exc_info.value)

    @pytest.mark.unit
    def test_missing_required_field_rejected(self) -> None:
        """EmergencyLocation requires essential fields."""
        with pytest.raises(ValidationError):
            EmergencyLocation(
                locationId="loc-123",
                # Missing civicAddressId, description, isDefault
            )  # type: ignore[call-arg]

    @pytest.mark.unit
    def test_serialization(self) -> None:
        """EmergencyLocation serializes to dict correctly."""
        location = EmergencyLocation(
            locationId="loc-123",
            civicAddressId="civic-456",
            description="Test Location",
            companyName="Test Co",
            address="123 Test St",
            city="TestCity",
            stateOrProvince="TS",
            postalCode="12345",
            countryOrRegion="US",
            isDefault=True,
        )
        data = location.model_dump()
        assert data["location_id"] == "loc-123"
        assert data["civic_address_id"] == "civic-456"
        assert data["is_default"] is True

    @pytest.mark.unit
    def test_serialization_by_alias(self) -> None:
        """EmergencyLocation serializes with camelCase aliases."""
        location = EmergencyLocation(
            locationId="loc-123",
            civicAddressId="civic-456",
            description="Test",
            companyName=None,
            address=None,
            city=None,
            stateOrProvince=None,
            postalCode=None,
            countryOrRegion=None,
            isDefault=False,
        )
        data = location.model_dump(by_alias=True)
        assert "locationId" in data
        assert "civicAddressId" in data
        assert "isDefault" in data
        assert "stateOrProvince" in data


class TestGraphErrorDetail:
    """Tests for GraphErrorDetail model."""

    @pytest.mark.unit
    def test_create_minimal(self) -> None:
        """GraphErrorDetail can be created with required fields only."""
        error = GraphErrorDetail(
            code="BadRequest",
            message="The request is invalid.",
        )
        assert error.code == "BadRequest"
        assert error.message == "The request is invalid."
        assert error.target is None
        assert error.details is None

    @pytest.mark.unit
    def test_create_with_target(self) -> None:
        """GraphErrorDetail can include target field."""
        error = GraphErrorDetail(
            code="InvalidField",
            message="Field value is invalid.",
            target="telephoneNumber",
        )
        assert error.target == "telephoneNumber"

    @pytest.mark.unit
    def test_create_with_nested_details(self) -> None:
        """GraphErrorDetail can have nested error details."""
        error = GraphErrorDetail(
            code="ValidationError",
            message="Multiple validation errors occurred.",
            details=[
                GraphErrorDetail(
                    code="InvalidFormat",
                    message="Phone number format is invalid.",
                    target="telephoneNumber",
                ),
                GraphErrorDetail(
                    code="Required",
                    message="User ID is required.",
                    target="userId",
                ),
            ],
        )
        assert error.details is not None
        assert len(error.details) == 2
        assert error.details[0].code == "InvalidFormat"
        assert error.details[1].target == "userId"

    @pytest.mark.unit
    def test_create_from_dict(self) -> None:
        """GraphErrorDetail can be created from dict with nested details."""
        error = GraphErrorDetail.model_validate(
            {
                "code": "BadRequest",
                "message": "Request failed.",
                "target": None,
                "details": [
                    {
                        "code": "InnerError",
                        "message": "Nested error.",
                    }
                ],
            }
        )
        assert error.code == "BadRequest"
        assert error.details is not None
        assert len(error.details) == 1
        assert error.details[0].code == "InnerError"

    @pytest.mark.unit
    def test_extra_field_rejected(self) -> None:
        """GraphErrorDetail rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            GraphErrorDetail(
                code="BadRequest",
                message="Error",
                extra_field="should fail",  # type: ignore[call-arg]
            )
        assert "extra_forbidden" in str(exc_info.value)

    @pytest.mark.unit
    def test_nested_extra_field_rejected(self) -> None:
        """GraphErrorDetail rejects extra fields in nested details."""
        with pytest.raises(ValidationError) as exc_info:
            GraphErrorDetail.model_validate(
                {
                    "code": "BadRequest",
                    "message": "Error",
                    "details": [
                        {
                            "code": "Inner",
                            "message": "Inner error",
                            "extraField": "should fail",
                        }
                    ],
                }
            )
        assert "extra_forbidden" in str(exc_info.value)


class TestGraphErrorResponse:
    """Tests for GraphErrorResponse model."""

    @pytest.mark.unit
    def test_create_simple(self) -> None:
        """GraphErrorResponse can wrap a simple error."""
        response = GraphErrorResponse(
            error=GraphErrorDetail(
                code="ResourceNotFound",
                message="The specified resource was not found.",
            )
        )
        assert response.error.code == "ResourceNotFound"
        assert response.error.message == "The specified resource was not found."

    @pytest.mark.unit
    def test_create_from_dict(self) -> None:
        """GraphErrorResponse can be created from dict (typical API response)."""
        api_error = {
            "error": {
                "code": "Authorization_RequestDenied",
                "message": "Insufficient privileges to complete the operation.",
                "target": None,
                "details": None,
            }
        }
        response = GraphErrorResponse.model_validate(api_error)
        assert response.error.code == "Authorization_RequestDenied"

    @pytest.mark.unit
    def test_create_with_nested_details(self) -> None:
        """GraphErrorResponse can contain errors with nested details."""
        api_error = {
            "error": {
                "code": "BadRequest",
                "message": "Request validation failed.",
                "details": [
                    {
                        "code": "InvalidFormat",
                        "message": "Phone number must be in E.164 format.",
                        "target": "telephoneNumber",
                    },
                    {
                        "code": "InvalidValue",
                        "message": "Location ID not found.",
                        "target": "locationId",
                    },
                ],
            }
        }
        response = GraphErrorResponse.model_validate(api_error)
        assert response.error.code == "BadRequest"
        assert response.error.details is not None
        assert len(response.error.details) == 2
        assert response.error.details[0].target == "telephoneNumber"

    @pytest.mark.unit
    def test_extra_field_rejected(self) -> None:
        """GraphErrorResponse rejects unknown fields at top level."""
        with pytest.raises(ValidationError) as exc_info:
            GraphErrorResponse(
                error=GraphErrorDetail(code="Error", message="Test"),
                extra_field="should fail",  # type: ignore[call-arg]
            )
        assert "extra_forbidden" in str(exc_info.value)


class TestGraphListResponse:
    """Tests for GraphListResponse generic model."""

    @pytest.mark.unit
    def test_create_with_user_configuration(self) -> None:
        """GraphListResponse can wrap UserConfiguration items."""
        response = GraphListResponse[UserConfiguration].model_validate(
            {
                "@odata.context": "https://graph.microsoft.com/beta/$metadata#teamwork/teamsPhoneConfiguration/users",
                "@odata.count": 2,
                "@odata.nextLink": "https://graph.microsoft.com/beta/teamwork/teamsPhoneConfiguration/users?$skiptoken=abc123",
                "value": [
                    {
                        "id": "user-1",
                        "userPrincipalName": "user1@contoso.com",
                        "tenantId": "tenant-123",
                        "accountType": "user",
                        "isEnterpriseVoiceEnabled": True,
                    },
                    {
                        "id": "user-2",
                        "userPrincipalName": "user2@contoso.com",
                        "tenantId": "tenant-123",
                        "accountType": "user",
                        "isEnterpriseVoiceEnabled": False,
                    },
                ],
            }
        )
        assert (
            response.odata_context
            == "https://graph.microsoft.com/beta/$metadata#teamwork/teamsPhoneConfiguration/users"
        )
        assert response.odata_count == 2
        assert response.odata_next_link is not None
        assert "skiptoken" in response.odata_next_link
        assert len(response.value) == 2
        assert response.value[0].user_principal_name == "user1@contoso.com"
        assert response.value[1].is_enterprise_voice_enabled is False

    @pytest.mark.unit
    def test_create_with_number_assignment(self) -> None:
        """GraphListResponse can wrap NumberAssignment items."""
        response = GraphListResponse[NumberAssignment].model_validate(
            {
                "@odata.context": "https://graph.microsoft.com/beta/$metadata#telephoneNumbers",
                "value": [
                    {
                        "id": "num-1",
                        "telephoneNumber": "+12055551234",
                        "numberType": "callingPlan",
                        "activationState": "activated",
                        "capabilities": ["userAssignment"],
                        "assignmentStatus": "unassigned",
                    }
                ],
            }
        )
        assert len(response.value) == 1
        assert response.value[0].telephone_number == "+12055551234"
        assert response.value[0].number_type == NumberType.CALLING_PLAN

    @pytest.mark.unit
    def test_create_empty_value_list(self) -> None:
        """GraphListResponse handles empty value list."""
        response = GraphListResponse[UserConfiguration].model_validate(
            {
                "@odata.context": "https://graph.microsoft.com/beta/$metadata#...",
                "@odata.count": 0,
                "value": [],
            }
        )
        assert len(response.value) == 0
        assert response.odata_count == 0

    @pytest.mark.unit
    def test_create_minimal(self) -> None:
        """GraphListResponse can be created with just value field."""
        response = GraphListResponse[UserConfiguration].model_validate(
            {
                "value": [
                    {
                        "id": "user-1",
                        "userPrincipalName": "user@contoso.com",
                        "tenantId": "tenant-123",
                        "accountType": "user",
                        "isEnterpriseVoiceEnabled": True,
                    }
                ],
            }
        )
        assert response.odata_context is None
        assert response.odata_count is None
        assert response.odata_next_link is None
        assert len(response.value) == 1

    @pytest.mark.unit
    def test_odata_aliases_work(self) -> None:
        """GraphListResponse correctly maps @odata.* aliases."""
        response = GraphListResponse[UserConfiguration].model_validate(
            {
                "@odata.context": "https://example.com/context",
                "@odata.count": 5,
                "@odata.nextLink": "https://example.com/next",
                "value": [],
            }
        )
        assert response.odata_context == "https://example.com/context"
        assert response.odata_count == 5
        assert response.odata_next_link == "https://example.com/next"

    @pytest.mark.unit
    def test_extra_field_rejected(self) -> None:
        """GraphListResponse rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            GraphListResponse[UserConfiguration].model_validate(
                {
                    "value": [],
                    "extraField": "should fail",
                }
            )
        assert "extra_forbidden" in str(exc_info.value)

    @pytest.mark.unit
    def test_nested_extra_field_rejected(self) -> None:
        """GraphListResponse rejects extra fields in nested items."""
        with pytest.raises(ValidationError) as exc_info:
            GraphListResponse[UserConfiguration].model_validate(
                {
                    "value": [
                        {
                            "id": "user-1",
                            "userPrincipalName": "user@contoso.com",
                            "tenantId": "tenant-123",
                            "accountType": "user",
                            "isEnterpriseVoiceEnabled": True,
                            "extraField": "should fail",
                        }
                    ],
                }
            )
        assert "extra_forbidden" in str(exc_info.value)

    @pytest.mark.unit
    def test_serialization(self) -> None:
        """GraphListResponse serializes to dict correctly."""
        response = GraphListResponse[UserConfiguration].model_validate(
            {
                "@odata.context": "https://example.com",
                "@odata.count": 1,
                "value": [
                    {
                        "id": "user-1",
                        "userPrincipalName": "user@contoso.com",
                        "tenantId": "tenant-123",
                        "accountType": "user",
                        "isEnterpriseVoiceEnabled": True,
                    }
                ],
            }
        )
        data = response.model_dump()
        assert data["odata_context"] == "https://example.com"
        assert data["odata_count"] == 1
        assert len(data["value"]) == 1

    @pytest.mark.unit
    def test_serialization_by_alias(self) -> None:
        """GraphListResponse serializes with @odata.* aliases."""
        response = GraphListResponse[UserConfiguration].model_validate(
            {
                "@odata.context": "https://example.com",
                "@odata.count": 1,
                "@odata.nextLink": "https://example.com/next",
                "value": [],
            }
        )
        data = response.model_dump(by_alias=True)
        assert "@odata.context" in data
        assert "@odata.count" in data
        assert "@odata.nextLink" in data
