"""Unit tests for auth-related Pydantic models."""

from datetime import datetime, timedelta, timezone

import pytest
from pydantic import ValidationError

from teams_phone.models import (
    AuthMethod,
    AuthStatus,
    AuthStatusType,
    CachedToken,
)


class TestAuthMethodEnum:
    """Tests for AuthMethod enum."""

    @pytest.mark.unit
    def test_certificate_value(self) -> None:
        """Certificate auth method has correct value."""
        assert AuthMethod.CERTIFICATE.value == "certificate"

    @pytest.mark.unit
    def test_client_secret_value(self) -> None:
        """Client secret auth method has correct value."""
        assert AuthMethod.CLIENT_SECRET.value == "client-secret"

    @pytest.mark.unit
    def test_is_string_enum(self) -> None:
        """AuthMethod is a string enum."""
        assert isinstance(AuthMethod.CERTIFICATE, str)
        assert isinstance(AuthMethod.CLIENT_SECRET, str)


class TestCachedToken:
    """Tests for CachedToken model."""

    @pytest.mark.unit
    def test_create_token(self) -> None:
        """CachedToken can be created with all fields."""
        expires_at = datetime.now(timezone.utc) + timedelta(hours=1)
        token = CachedToken(
            access_token="eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiI...",
            expires_at=expires_at,
            tenant_id="12345678-1234-5678-1234-567812345678",
            scopes=["https://graph.microsoft.com/.default"],
        )
        assert token.access_token.startswith("eyJ")
        assert token.expires_at == expires_at
        assert token.tenant_id == "12345678-1234-5678-1234-567812345678"
        assert len(token.scopes) == 1

    @pytest.mark.unit
    def test_is_expired_false(self) -> None:
        """is_expired returns False for future expiration."""
        token = CachedToken(
            access_token="token",
            expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
            tenant_id="test",
            scopes=[],
        )
        assert token.is_expired() is False

    @pytest.mark.unit
    def test_is_expired_true(self) -> None:
        """is_expired returns True for past expiration."""
        token = CachedToken(
            access_token="token",
            expires_at=datetime.now(timezone.utc) - timedelta(hours=1),
            tenant_id="test",
            scopes=[],
        )
        assert token.is_expired() is True

    @pytest.mark.unit
    def test_extra_field_rejected(self) -> None:
        """CachedToken rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            CachedToken(
                access_token="token",
                expires_at=datetime.now(timezone.utc),
                tenant_id="test",
                scopes=[],
                refresh_token="should-fail",  # type: ignore[call-arg]
            )
        assert "extra_forbidden" in str(exc_info.value)


class TestAuthStatusType:
    """Tests for AuthStatusType enum."""

    @pytest.mark.unit
    def test_authenticated_value(self) -> None:
        """Authenticated status has correct value."""
        assert AuthStatusType.AUTHENTICATED.value == "authenticated"

    @pytest.mark.unit
    def test_unauthenticated_value(self) -> None:
        """Unauthenticated status has correct value."""
        assert AuthStatusType.UNAUTHENTICATED.value == "unauthenticated"

    @pytest.mark.unit
    def test_expired_value(self) -> None:
        """Expired status has correct value."""
        assert AuthStatusType.EXPIRED.value == "expired"


class TestAuthStatus:
    """Tests for AuthStatus model."""

    @pytest.mark.unit
    def test_create_authenticated_status(self) -> None:
        """AuthStatus can represent authenticated state."""
        expires_at = datetime.now(timezone.utc) + timedelta(hours=1)
        status = AuthStatus(
            status=AuthStatusType.AUTHENTICATED,
            tenant_name="contoso",
            tenant_id="12345678-1234-5678-1234-567812345678",
            expires_at=expires_at,
        )
        assert status.status == AuthStatusType.AUTHENTICATED
        assert status.tenant_name == "contoso"
        assert status.expires_at == expires_at
        assert status.error_message is None

    @pytest.mark.unit
    def test_create_unauthenticated_status(self) -> None:
        """AuthStatus can represent unauthenticated state."""
        status = AuthStatus(status=AuthStatusType.UNAUTHENTICATED)
        assert status.status == AuthStatusType.UNAUTHENTICATED
        assert status.tenant_name is None
        assert status.tenant_id is None

    @pytest.mark.unit
    def test_create_expired_status_with_error(self) -> None:
        """AuthStatus can include error message."""
        status = AuthStatus(
            status=AuthStatusType.EXPIRED,
            tenant_name="contoso",
            error_message="Token expired at 2024-01-15 10:00:00",
        )
        assert status.status == AuthStatusType.EXPIRED
        assert status.error_message is not None

    @pytest.mark.unit
    def test_extra_field_rejected(self) -> None:
        """AuthStatus rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            AuthStatus(
                status=AuthStatusType.AUTHENTICATED,
                unknown="field",  # type: ignore[call-arg]
            )
        assert "extra_forbidden" in str(exc_info.value)
