"""Unit tests for number-related Pydantic models."""

import pytest
from pydantic import ValidationError

from teams_phone.models import (
    ActivationState,
    AssignmentCategory,
    AssignmentStatus,
    AsyncOperation,
    NumberAssignment,
    NumberType,
    OperationNumber,
    OperationStatus,
)


class TestNumberTypeEnum:
    """Tests for NumberType enum."""

    @pytest.mark.unit
    def test_direct_routing_value(self) -> None:
        """Direct routing number type has correct value."""
        assert NumberType.DIRECT_ROUTING.value == "directRouting"

    @pytest.mark.unit
    def test_calling_plan_value(self) -> None:
        """Calling plan number type has correct value."""
        assert NumberType.CALLING_PLAN.value == "callingPlan"

    @pytest.mark.unit
    def test_operator_connect_value(self) -> None:
        """Operator connect number type has correct value."""
        assert NumberType.OPERATOR_CONNECT.value == "operatorConnect"

    @pytest.mark.unit
    def test_is_string_enum(self) -> None:
        """NumberType is a string enum."""
        assert isinstance(NumberType.DIRECT_ROUTING, str)
        assert isinstance(NumberType.CALLING_PLAN, str)
        assert isinstance(NumberType.OPERATOR_CONNECT, str)


class TestActivationStateEnum:
    """Tests for ActivationState enum."""

    @pytest.mark.unit
    def test_activated_value(self) -> None:
        """Activated state has correct value."""
        assert ActivationState.ACTIVATED.value == "activated"

    @pytest.mark.unit
    def test_assignment_pending_value(self) -> None:
        """Assignment pending state has correct value."""
        assert ActivationState.ASSIGNMENT_PENDING.value == "assignmentPending"

    @pytest.mark.unit
    def test_assignment_failed_value(self) -> None:
        """Assignment failed state has correct value."""
        assert ActivationState.ASSIGNMENT_FAILED.value == "assignmentFailed"

    @pytest.mark.unit
    def test_update_pending_value(self) -> None:
        """Update pending state has correct value."""
        assert ActivationState.UPDATE_PENDING.value == "updatePending"

    @pytest.mark.unit
    def test_update_failed_value(self) -> None:
        """Update failed state has correct value."""
        assert ActivationState.UPDATE_FAILED.value == "updateFailed"

    @pytest.mark.unit
    def test_is_string_enum(self) -> None:
        """ActivationState is a string enum."""
        assert isinstance(ActivationState.ACTIVATED, str)
        assert isinstance(ActivationState.ASSIGNMENT_PENDING, str)


class TestAssignmentStatusEnum:
    """Tests for AssignmentStatus enum."""

    @pytest.mark.unit
    def test_unassigned_value(self) -> None:
        """Unassigned status has correct value."""
        assert AssignmentStatus.UNASSIGNED.value == "unassigned"

    @pytest.mark.unit
    def test_user_assigned_value(self) -> None:
        """User assigned status has correct value."""
        assert AssignmentStatus.USER_ASSIGNED.value == "userAssigned"

    @pytest.mark.unit
    def test_conference_assigned_value(self) -> None:
        """Conference assigned status has correct value."""
        assert AssignmentStatus.CONFERENCE_ASSIGNED.value == "conferenceAssigned"

    @pytest.mark.unit
    def test_voice_application_assigned_value(self) -> None:
        """Voice application assigned status has correct value."""
        assert (
            AssignmentStatus.VOICE_APPLICATION_ASSIGNED.value
            == "voiceApplicationAssigned"
        )

    @pytest.mark.unit
    def test_is_string_enum(self) -> None:
        """AssignmentStatus is a string enum."""
        assert isinstance(AssignmentStatus.UNASSIGNED, str)
        assert isinstance(AssignmentStatus.USER_ASSIGNED, str)


class TestAssignmentCategoryEnum:
    """Tests for AssignmentCategory enum."""

    @pytest.mark.unit
    def test_primary_value(self) -> None:
        """Primary category has correct value."""
        assert AssignmentCategory.PRIMARY.value == "primary"

    @pytest.mark.unit
    def test_private_value(self) -> None:
        """Private category has correct value."""
        assert AssignmentCategory.PRIVATE.value == "private"

    @pytest.mark.unit
    def test_alternate_value(self) -> None:
        """Alternate category has correct value."""
        assert AssignmentCategory.ALTERNATE.value == "alternate"

    @pytest.mark.unit
    def test_is_string_enum(self) -> None:
        """AssignmentCategory is a string enum."""
        assert isinstance(AssignmentCategory.PRIMARY, str)
        assert isinstance(AssignmentCategory.PRIVATE, str)
        assert isinstance(AssignmentCategory.ALTERNATE, str)


class TestOperationStatusEnum:
    """Tests for OperationStatus enum."""

    @pytest.mark.unit
    def test_not_started_value(self) -> None:
        """Not started status has correct value."""
        assert OperationStatus.NOT_STARTED.value == "notStarted"

    @pytest.mark.unit
    def test_running_value(self) -> None:
        """Running status has correct value."""
        assert OperationStatus.RUNNING.value == "running"

    @pytest.mark.unit
    def test_succeeded_value(self) -> None:
        """Succeeded status has correct value."""
        assert OperationStatus.SUCCEEDED.value == "succeeded"

    @pytest.mark.unit
    def test_failed_value(self) -> None:
        """Failed status has correct value."""
        assert OperationStatus.FAILED.value == "failed"

    @pytest.mark.unit
    def test_skipped_value(self) -> None:
        """Skipped status has correct value."""
        assert OperationStatus.SKIPPED.value == "skipped"

    @pytest.mark.unit
    def test_unknown_future_value(self) -> None:
        """Unknown future value status has correct value."""
        assert OperationStatus.UNKNOWN_FUTURE_VALUE.value == "unknownFutureValue"

    @pytest.mark.unit
    def test_is_string_enum(self) -> None:
        """OperationStatus is a string enum."""
        assert isinstance(OperationStatus.NOT_STARTED, str)
        assert isinstance(OperationStatus.SUCCEEDED, str)
        assert isinstance(OperationStatus.FAILED, str)


class TestOperationNumber:
    """Tests for OperationNumber model."""

    @pytest.mark.unit
    def test_create_from_camel_case(self) -> None:
        """OperationNumber can be created with camelCase aliases."""
        op_num = OperationNumber(
            resourceLocation="https://graph.microsoft.com/beta/.../numberAssignments/123",
            status=OperationStatus.SUCCEEDED,
        )
        assert (
            op_num.resource_location
            == "https://graph.microsoft.com/beta/.../numberAssignments/123"
        )
        assert op_num.status == OperationStatus.SUCCEEDED

    @pytest.mark.unit
    def test_create_from_snake_case(self) -> None:
        """OperationNumber can be created with snake_case field names (populate_by_name)."""
        op_num = OperationNumber.model_validate(
            {
                "resource_location": "https://graph.microsoft.com/beta/.../numberAssignments/123",
                "status": "succeeded",
            }
        )
        assert (
            op_num.resource_location
            == "https://graph.microsoft.com/beta/.../numberAssignments/123"
        )
        assert op_num.status == OperationStatus.SUCCEEDED

    @pytest.mark.unit
    def test_status_from_string(self) -> None:
        """OperationNumber parses status from string."""
        op_num = OperationNumber(
            resourceLocation="https://example.com",
            status="running",  # type: ignore[arg-type]
        )
        assert op_num.status == OperationStatus.RUNNING

    @pytest.mark.unit
    def test_extra_field_rejected(self) -> None:
        """OperationNumber rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            OperationNumber(
                resourceLocation="https://example.com",
                status=OperationStatus.SUCCEEDED,
                extra_field="should fail",  # type: ignore[call-arg]
            )
        assert "extra_forbidden" in str(exc_info.value)

    @pytest.mark.unit
    def test_invalid_status_rejected(self) -> None:
        """OperationNumber rejects invalid status value."""
        with pytest.raises(ValidationError) as exc_info:
            OperationNumber(
                resourceLocation="https://example.com",
                status="invalid-status",  # type: ignore[arg-type]
            )
        assert "status" in str(exc_info.value).lower()


class TestAsyncOperation:
    """Tests for AsyncOperation model."""

    @pytest.mark.unit
    def test_create_minimal(self) -> None:
        """AsyncOperation can be created with required fields only."""
        op = AsyncOperation(
            id="op-123",
            createdDateTime="2025-02-03T22:03:26Z",  # type: ignore[arg-type]
            status=OperationStatus.RUNNING,
        )
        assert op.id == "op-123"
        assert op.status == OperationStatus.RUNNING
        assert op.odata_type is None
        assert op.numbers == []

    @pytest.mark.unit
    def test_create_full(self) -> None:
        """AsyncOperation can be created with all fields."""
        op = AsyncOperation(
            **{
                "@odata.type": "#microsoft.graph.teamsAdministration.telephoneNumberLongRunningOperation",
            },
            id="QXNzaWdubWVudHw2Y2E4Yjc0Ni0...",
            createdDateTime="2025-02-03T22:03:26Z",  # type: ignore[arg-type]
            status=OperationStatus.SUCCEEDED,
            numbers=[
                OperationNumber(
                    resourceLocation="https://graph.microsoft.com/beta/.../numberAssignments/123",
                    status=OperationStatus.SUCCEEDED,
                )
            ],
        )
        assert (
            op.odata_type
            == "#microsoft.graph.teamsAdministration.telephoneNumberLongRunningOperation"
        )
        assert op.id == "QXNzaWdubWVudHw2Y2E4Yjc0Ni0..."
        assert len(op.numbers) == 1
        assert op.numbers[0].status == OperationStatus.SUCCEEDED

    @pytest.mark.unit
    def test_create_from_graph_api_response(self) -> None:
        """AsyncOperation can be created from Graph API JSON response."""
        api_response = {
            "@odata.type": "#microsoft.graph.teamsAdministration.telephoneNumberLongRunningOperation",
            "id": "QXNzaWdubWVudHw2Y2E4Yjc0Ni0...",
            "createdDateTime": "2025-02-03T22:03:26Z",
            "status": "succeeded",
            "numbers": [
                {
                    "resourceLocation": "https://graph.microsoft.com/beta/.../numberAssignments/{id}",
                    "status": "succeeded",
                }
            ],
        }
        op = AsyncOperation.model_validate(api_response)
        assert op.id == "QXNzaWdubWVudHw2Y2E4Yjc0Ni0..."
        assert op.status == OperationStatus.SUCCEEDED
        assert op.created_date_time.year == 2025
        assert len(op.numbers) == 1

    @pytest.mark.unit
    def test_datetime_parsing(self) -> None:
        """AsyncOperation parses ISO 8601 datetime strings."""
        op = AsyncOperation(
            id="op-123",
            createdDateTime="2025-02-03T22:03:26Z",  # type: ignore[arg-type]
            status=OperationStatus.RUNNING,
        )
        assert op.created_date_time.year == 2025
        assert op.created_date_time.month == 2
        assert op.created_date_time.day == 3
        assert op.created_date_time.hour == 22
        assert op.created_date_time.minute == 3

    @pytest.mark.unit
    def test_extra_field_rejected(self) -> None:
        """AsyncOperation rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            AsyncOperation(
                id="op-123",
                createdDateTime="2025-02-03T22:03:26Z",  # type: ignore[arg-type]
                status=OperationStatus.RUNNING,
                extra_field="should fail",  # type: ignore[call-arg]
            )
        assert "extra_forbidden" in str(exc_info.value)

    @pytest.mark.unit
    def test_nested_extra_field_rejected(self) -> None:
        """AsyncOperation rejects extra fields in nested OperationNumber."""
        with pytest.raises(ValidationError) as exc_info:
            AsyncOperation.model_validate(
                {
                    "id": "op-123",
                    "createdDateTime": "2025-02-03T22:03:26Z",
                    "status": "succeeded",
                    "numbers": [
                        {
                            "resourceLocation": "https://example.com",
                            "status": "succeeded",
                            "extraField": "should fail",
                        }
                    ],
                }
            )
        assert "extra_forbidden" in str(exc_info.value)

    @pytest.mark.unit
    def test_all_operation_statuses(self) -> None:
        """AsyncOperation accepts all valid operation statuses."""
        for status in OperationStatus:
            op = AsyncOperation(
                id="op-123",
                createdDateTime="2025-02-03T22:03:26Z",  # type: ignore[arg-type]
                status=status,
            )
            assert op.status == status


class TestNumberAssignment:
    """Tests for NumberAssignment model."""

    @pytest.mark.unit
    def test_create_minimal(self) -> None:
        """NumberAssignment can be created with required fields only."""
        num = NumberAssignment(
            id="num-123",
            telephoneNumber="+12052582895",
            numberType=NumberType.CALLING_PLAN,
            activationState=ActivationState.ACTIVATED,
            capabilities=["userAssignment"],
            assignmentStatus=AssignmentStatus.UNASSIGNED,
        )
        assert num.id == "num-123"
        assert num.telephone_number == "+12052582895"
        assert num.number_type == NumberType.CALLING_PLAN
        assert num.activation_state == ActivationState.ACTIVATED
        assert num.capabilities == ["userAssignment"]
        assert num.assignment_status == AssignmentStatus.UNASSIGNED
        # Check defaults
        assert num.operator_id is None
        assert num.location_id is None
        assert num.assignment_category is None
        assert num.city is None
        assert num.supported_customer_actions == []

    @pytest.mark.unit
    def test_create_full(self) -> None:
        """NumberAssignment can be created with all fields."""
        num = NumberAssignment(
            id="num-123",
            telephoneNumber="+12052582895",
            operatorId="op-uuid-123",
            numberType=NumberType.OPERATOR_CONNECT,
            activationState=ActivationState.ACTIVATED,
            capabilities=["userAssignment", "conferenceAssignment"],
            locationId="loc-123",
            civicAddressId="civic-123",
            networkSiteId="site-123",
            assignmentTargetId="user-uuid-456",
            assignmentCategory=AssignmentCategory.PRIMARY,
            assignmentStatus=AssignmentStatus.USER_ASSIGNED,
            portInStatus="completed",
            isoCountryCode="US",
            city="Seattle",
            numberSource="online",
            supportedCustomerActions=["locationUpdate"],
            reverseNumberLookupOptions=["carrier"],
        )
        assert num.operator_id == "op-uuid-123"
        assert num.number_type == NumberType.OPERATOR_CONNECT
        assert num.location_id == "loc-123"
        assert num.assignment_target_id == "user-uuid-456"
        assert num.assignment_category == AssignmentCategory.PRIMARY
        assert num.assignment_status == AssignmentStatus.USER_ASSIGNED
        assert num.city == "Seattle"
        assert num.supported_customer_actions == ["locationUpdate"]

    @pytest.mark.unit
    def test_create_from_graph_api_response(self) -> None:
        """NumberAssignment can be created from Graph API JSON response."""
        api_response = {
            "id": "num-abc-123",
            "telephoneNumber": "+12052582895",
            "operatorId": "op-uuid-123",
            "numberType": "directRouting",
            "activationState": "activated",
            "capabilities": ["userAssignment", "voiceApplicationAssignment"],
            "locationId": "loc-456",
            "civicAddressId": None,
            "networkSiteId": None,
            "assignmentTargetId": "user-uuid-789",
            "assignmentCategory": "primary",
            "assignmentStatus": "userAssigned",
            "portInStatus": "completed",
            "isoCountryCode": "US",
            "city": "Birmingham",
            "numberSource": "online",
            "supportedCustomerActions": ["locationUpdate"],
            "reverseNumberLookupOptions": [],
        }
        num = NumberAssignment.model_validate(api_response)
        assert num.id == "num-abc-123"
        assert num.telephone_number == "+12052582895"
        assert num.number_type == NumberType.DIRECT_ROUTING
        assert num.activation_state == ActivationState.ACTIVATED
        assert num.assignment_category == AssignmentCategory.PRIMARY
        assert num.assignment_status == AssignmentStatus.USER_ASSIGNED
        assert num.city == "Birmingham"

    @pytest.mark.unit
    def test_create_from_snake_case(self) -> None:
        """NumberAssignment can be created with snake_case field names (populate_by_name)."""
        num = NumberAssignment.model_validate(
            {
                "id": "num-123",
                "telephone_number": "+12052582895",
                "number_type": "callingPlan",
                "activation_state": "activated",
                "capabilities": ["userAssignment"],
                "assignment_status": "unassigned",
            }
        )
        assert num.telephone_number == "+12052582895"
        assert num.number_type == NumberType.CALLING_PLAN

    @pytest.mark.unit
    def test_null_optional_fields(self) -> None:
        """NumberAssignment handles null optional fields correctly."""
        api_response: dict[str, object] = {
            "id": "num-123",
            "telephoneNumber": "+12052582895",
            "operatorId": None,
            "numberType": "callingPlan",
            "activationState": "activated",
            "capabilities": [],
            "locationId": None,
            "civicAddressId": None,
            "networkSiteId": None,
            "assignmentTargetId": None,
            "assignmentCategory": None,
            "assignmentStatus": "unassigned",
            "portInStatus": None,
            "isoCountryCode": None,
            "city": None,
            "numberSource": None,
            "supportedCustomerActions": [],
            "reverseNumberLookupOptions": [],
        }
        num = NumberAssignment.model_validate(api_response)
        assert num.operator_id is None
        assert num.location_id is None
        assert num.assignment_category is None
        assert num.city is None

    @pytest.mark.unit
    def test_extra_field_rejected(self) -> None:
        """NumberAssignment rejects unknown fields (extra='forbid')."""
        with pytest.raises(ValidationError) as exc_info:
            NumberAssignment(
                id="num-123",
                telephoneNumber="+12052582895",
                numberType=NumberType.CALLING_PLAN,
                activationState=ActivationState.ACTIVATED,
                capabilities=[],
                assignmentStatus=AssignmentStatus.UNASSIGNED,
                unknown_field="should fail",  # type: ignore[call-arg]
            )
        assert "extra_forbidden" in str(exc_info.value)

    @pytest.mark.unit
    def test_invalid_number_type_rejected(self) -> None:
        """NumberAssignment rejects invalid number type."""
        with pytest.raises(ValidationError) as exc_info:
            NumberAssignment(
                id="num-123",
                telephoneNumber="+12052582895",
                numberType="invalidType",  # type: ignore[arg-type]
                activationState=ActivationState.ACTIVATED,
                capabilities=[],
                assignmentStatus=AssignmentStatus.UNASSIGNED,
            )
        assert "numbertype" in str(exc_info.value).lower()

    @pytest.mark.unit
    def test_invalid_activation_state_rejected(self) -> None:
        """NumberAssignment rejects invalid activation state."""
        with pytest.raises(ValidationError) as exc_info:
            NumberAssignment(
                id="num-123",
                telephoneNumber="+12052582895",
                numberType=NumberType.CALLING_PLAN,
                activationState="invalidState",  # type: ignore[arg-type]
                capabilities=[],
                assignmentStatus=AssignmentStatus.UNASSIGNED,
            )
        assert "activationstate" in str(exc_info.value).lower()

    @pytest.mark.unit
    def test_invalid_assignment_status_rejected(self) -> None:
        """NumberAssignment rejects invalid assignment status."""
        with pytest.raises(ValidationError) as exc_info:
            NumberAssignment(
                id="num-123",
                telephoneNumber="+12052582895",
                numberType=NumberType.CALLING_PLAN,
                activationState=ActivationState.ACTIVATED,
                capabilities=[],
                assignmentStatus="invalidStatus",  # type: ignore[arg-type]
            )
        assert "assignmentstatus" in str(exc_info.value).lower()

    @pytest.mark.unit
    def test_invalid_assignment_category_rejected(self) -> None:
        """NumberAssignment rejects invalid assignment category."""
        with pytest.raises(ValidationError) as exc_info:
            NumberAssignment(
                id="num-123",
                telephoneNumber="+12052582895",
                numberType=NumberType.CALLING_PLAN,
                activationState=ActivationState.ACTIVATED,
                capabilities=[],
                assignmentStatus=AssignmentStatus.UNASSIGNED,
                assignmentCategory="invalidCategory",  # type: ignore[arg-type]
            )
        assert "assignmentcategory" in str(exc_info.value).lower()

    @pytest.mark.unit
    def test_serialization(self) -> None:
        """NumberAssignment serializes to dict correctly."""
        num = NumberAssignment(
            id="num-123",
            telephoneNumber="+12052582895",
            numberType=NumberType.CALLING_PLAN,
            activationState=ActivationState.ACTIVATED,
            capabilities=["userAssignment"],
            assignmentStatus=AssignmentStatus.UNASSIGNED,
        )
        data = num.model_dump()
        assert data["id"] == "num-123"
        assert data["telephone_number"] == "+12052582895"
        assert data["number_type"] == NumberType.CALLING_PLAN
        assert data["capabilities"] == ["userAssignment"]

    @pytest.mark.unit
    def test_serialization_by_alias(self) -> None:
        """NumberAssignment serializes with camelCase aliases."""
        num = NumberAssignment(
            id="num-123",
            telephoneNumber="+12052582895",
            numberType=NumberType.CALLING_PLAN,
            activationState=ActivationState.ACTIVATED,
            capabilities=["userAssignment"],
            assignmentStatus=AssignmentStatus.UNASSIGNED,
        )
        data = num.model_dump(by_alias=True)
        assert "telephoneNumber" in data
        assert "numberType" in data
        assert "activationState" in data
        assert "assignmentStatus" in data
        assert data["telephoneNumber"] == "+12052582895"

    @pytest.mark.unit
    def test_all_number_types(self) -> None:
        """NumberAssignment accepts all valid number types."""
        for number_type in NumberType:
            num = NumberAssignment(
                id="num-123",
                telephoneNumber="+12052582895",
                numberType=number_type,
                activationState=ActivationState.ACTIVATED,
                capabilities=[],
                assignmentStatus=AssignmentStatus.UNASSIGNED,
            )
            assert num.number_type == number_type

    @pytest.mark.unit
    def test_all_activation_states(self) -> None:
        """NumberAssignment accepts all valid activation states."""
        for state in ActivationState:
            num = NumberAssignment(
                id="num-123",
                telephoneNumber="+12052582895",
                numberType=NumberType.CALLING_PLAN,
                activationState=state,
                capabilities=[],
                assignmentStatus=AssignmentStatus.UNASSIGNED,
            )
            assert num.activation_state == state

    @pytest.mark.unit
    def test_all_assignment_statuses(self) -> None:
        """NumberAssignment accepts all valid assignment statuses."""
        for status in AssignmentStatus:
            num = NumberAssignment(
                id="num-123",
                telephoneNumber="+12052582895",
                numberType=NumberType.CALLING_PLAN,
                activationState=ActivationState.ACTIVATED,
                capabilities=[],
                assignmentStatus=status,
            )
            assert num.assignment_status == status

    @pytest.mark.unit
    def test_all_assignment_categories(self) -> None:
        """NumberAssignment accepts all valid assignment categories."""
        for category in AssignmentCategory:
            num = NumberAssignment(
                id="num-123",
                telephoneNumber="+12052582895",
                numberType=NumberType.CALLING_PLAN,
                activationState=ActivationState.ACTIVATED,
                capabilities=[],
                assignmentStatus=AssignmentStatus.UNASSIGNED,
                assignmentCategory=category,
            )
            assert num.assignment_category == category
