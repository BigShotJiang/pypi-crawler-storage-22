"""Unit tests for user-related Pydantic models."""

from datetime import datetime

import pytest
from pydantic import ValidationError

from teams_phone.models import (
    AccountType,
    EffectivePolicyAssignment,
    PolicyAssignmentDetail,
    TelephoneNumber,
    UserConfiguration,
)


class TestAccountTypeEnum:
    """Tests for AccountType enum."""

    @pytest.mark.unit
    def test_user_value(self) -> None:
        """User account type has correct value."""
        assert AccountType.USER.value == "user"

    @pytest.mark.unit
    def test_resource_account_value(self) -> None:
        """Resource account type has correct value."""
        assert AccountType.RESOURCE_ACCOUNT.value == "resourceAccount"

    @pytest.mark.unit
    def test_guest_value(self) -> None:
        """Guest account type has correct value."""
        assert AccountType.GUEST.value == "guest"

    @pytest.mark.unit
    def test_sfb_on_prem_user_value(self) -> None:
        """SfB on-prem user account type has correct value."""
        assert AccountType.SFB_ON_PREM_USER.value == "sfbOnPremUser"

    @pytest.mark.unit
    def test_unknown_value(self) -> None:
        """Unknown account type has correct value."""
        assert AccountType.UNKNOWN.value == "unknown"

    @pytest.mark.unit
    def test_is_string_enum(self) -> None:
        """AccountType is a string enum."""
        assert isinstance(AccountType.USER, str)
        assert isinstance(AccountType.RESOURCE_ACCOUNT, str)


class TestTelephoneNumber:
    """Tests for TelephoneNumber model."""

    @pytest.mark.unit
    def test_create_from_snake_case(self) -> None:
        """TelephoneNumber can be created with snake_case field names (populate_by_name)."""
        # Using model_validate to test snake_case (mypy only knows alias)
        phone = TelephoneNumber.model_validate(
            {"telephone_number": "+13235533696", "assignment_category": "primary"}
        )
        assert phone.telephone_number == "+13235533696"
        assert phone.assignment_category == "primary"

    @pytest.mark.unit
    def test_create_from_camel_case(self) -> None:
        """TelephoneNumber can be created with camelCase aliases."""
        phone = TelephoneNumber(
            telephoneNumber="+13235533696",
            assignmentCategory="primary",
        )
        assert phone.telephone_number == "+13235533696"
        assert phone.assignment_category == "primary"

    @pytest.mark.unit
    def test_extra_field_rejected(self) -> None:
        """TelephoneNumber rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            TelephoneNumber(
                telephoneNumber="+13235533696",
                assignmentCategory="primary",
                extra_field="should fail",  # type: ignore[call-arg]
            )
        assert "extra_forbidden" in str(exc_info.value)

    @pytest.mark.unit
    def test_missing_required_field_rejected(self) -> None:
        """TelephoneNumber requires all fields."""
        with pytest.raises(ValidationError):
            TelephoneNumber(
                telephoneNumber="+13235533696",
                # Missing assignmentCategory
            )  # type: ignore[call-arg]


class TestPolicyAssignmentDetail:
    """Tests for PolicyAssignmentDetail model."""

    @pytest.mark.unit
    def test_create_minimal(self) -> None:
        """PolicyAssignmentDetail can be created without group_id."""
        detail = PolicyAssignmentDetail(
            displayName="Global",
            assignmentType="direct",
            policyId="tag:global",
        )
        assert detail.display_name == "Global"
        assert detail.assignment_type == "direct"
        assert detail.policy_id == "tag:global"
        assert detail.group_id is None

    @pytest.mark.unit
    def test_create_with_group_id(self) -> None:
        """PolicyAssignmentDetail can include group_id."""
        group_id = "12345678-1234-5678-1234-567812345678"
        detail = PolicyAssignmentDetail(
            displayName="Sales Policy",
            assignmentType="group",
            policyId="tag:sales-policy",
            groupId=group_id,
        )
        assert detail.group_id == group_id

    @pytest.mark.unit
    def test_create_from_snake_case(self) -> None:
        """PolicyAssignmentDetail can be created with snake_case field names (populate_by_name)."""
        # Using model_validate to test snake_case (mypy only knows alias)
        detail = PolicyAssignmentDetail.model_validate(
            {
                "display_name": "Global",
                "assignment_type": "direct",
                "policy_id": "tag:global",
                "group_id": None,
            }
        )
        assert detail.display_name == "Global"
        assert detail.assignment_type == "direct"

    @pytest.mark.unit
    def test_extra_field_rejected(self) -> None:
        """PolicyAssignmentDetail rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            PolicyAssignmentDetail(
                displayName="Global",
                assignmentType="direct",
                policyId="tag:global",
                unknown_field="should fail",  # type: ignore[call-arg]
            )
        assert "extra_forbidden" in str(exc_info.value)


class TestEffectivePolicyAssignment:
    """Tests for EffectivePolicyAssignment model."""

    @pytest.mark.unit
    def test_create_with_nested_detail(self) -> None:
        """EffectivePolicyAssignment contains nested PolicyAssignmentDetail."""
        detail = PolicyAssignmentDetail(
            displayName="Global",
            assignmentType="direct",
            policyId="tag:global",
        )
        assignment = EffectivePolicyAssignment(
            policyType="TeamsCallingPolicy",
            policyAssignment=detail,
        )
        assert assignment.policy_type == "TeamsCallingPolicy"
        assert assignment.policy_assignment.display_name == "Global"

    @pytest.mark.unit
    def test_create_from_dict(self) -> None:
        """EffectivePolicyAssignment can be created from nested dict."""
        assignment = EffectivePolicyAssignment.model_validate(
            {
                "policyType": "TeamsCallingPolicy",
                "policyAssignment": {
                    "displayName": "Global",
                    "assignmentType": "direct",
                    "policyId": "tag:global",
                },
            }
        )
        assert assignment.policy_type == "TeamsCallingPolicy"
        assert assignment.policy_assignment.display_name == "Global"

    @pytest.mark.unit
    def test_extra_field_rejected(self) -> None:
        """EffectivePolicyAssignment rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            EffectivePolicyAssignment(
                policyType="TeamsCallingPolicy",
                policyAssignment=PolicyAssignmentDetail(
                    displayName="Global",
                    assignmentType="direct",
                    policyId="tag:global",
                ),
                extra_field="should fail",  # type: ignore[call-arg]
            )
        assert "extra_forbidden" in str(exc_info.value)

    @pytest.mark.unit
    def test_nested_extra_field_rejected(self) -> None:
        """EffectivePolicyAssignment rejects extra fields in nested model."""
        with pytest.raises(ValidationError) as exc_info:
            EffectivePolicyAssignment.model_validate(
                {
                    "policyType": "TeamsCallingPolicy",
                    "policyAssignment": {
                        "displayName": "Global",
                        "assignmentType": "direct",
                        "policyId": "tag:global",
                        "extraField": "should fail",
                    },
                }
            )
        assert "extra_forbidden" in str(exc_info.value)


class TestUserConfiguration:
    """Tests for UserConfiguration model."""

    @pytest.mark.unit
    def test_create_minimal(self) -> None:
        """UserConfiguration can be created with required fields only."""
        user = UserConfiguration(
            id="12345678-1234-5678-1234-567812345678",
            userPrincipalName="user@contoso.com",
            tenantId="87654321-4321-8765-4321-876543218765",
            accountType=AccountType.USER,
            isEnterpriseVoiceEnabled=True,
        )
        assert user.id == "12345678-1234-5678-1234-567812345678"
        assert user.user_principal_name == "user@contoso.com"
        assert user.tenant_id == "87654321-4321-8765-4321-876543218765"
        assert user.account_type == AccountType.USER
        assert user.is_enterprise_voice_enabled is True
        assert user.display_name is None
        assert user.feature_types == []
        assert user.telephone_numbers == []
        assert user.effective_policy_assignments == []
        assert user.created_date_time is None
        assert user.modified_date_time is None

    @pytest.mark.unit
    def test_create_full(self) -> None:
        """UserConfiguration can be created with all fields."""
        created = datetime(2024, 1, 15, 10, 0, 0)
        modified = datetime(2024, 1, 20, 14, 30, 0)

        user = UserConfiguration(
            id="12345678-1234-5678-1234-567812345678",
            userPrincipalName="user@contoso.com",
            tenantId="87654321-4321-8765-4321-876543218765",
            displayName="John Doe",
            accountType=AccountType.USER,
            isEnterpriseVoiceEnabled=True,
            featureTypes=["Teams", "CallingPlan"],
            telephoneNumbers=[
                TelephoneNumber(
                    telephoneNumber="+13235533696",
                    assignmentCategory="primary",
                )
            ],
            effectivePolicyAssignments=[
                EffectivePolicyAssignment(
                    policyType="TeamsCallingPolicy",
                    policyAssignment=PolicyAssignmentDetail(
                        displayName="Global",
                        assignmentType="direct",
                        policyId="tag:global",
                    ),
                )
            ],
            createdDateTime=created,
            modifiedDateTime=modified,
        )
        assert user.display_name == "John Doe"
        assert user.feature_types == ["Teams", "CallingPlan"]
        assert len(user.telephone_numbers) == 1
        assert user.telephone_numbers[0].telephone_number == "+13235533696"
        assert len(user.effective_policy_assignments) == 1
        assert user.effective_policy_assignments[0].policy_type == "TeamsCallingPolicy"
        assert user.created_date_time == created
        assert user.modified_date_time == modified

    @pytest.mark.unit
    def test_create_from_graph_api_response(self) -> None:
        """UserConfiguration can be created from Graph API JSON response."""
        api_response = {
            "id": "12345678-1234-5678-1234-567812345678",
            "userPrincipalName": "user@contoso.com",
            "tenantId": "87654321-4321-8765-4321-876543218765",
            "displayName": "John Doe",
            "accountType": "user",
            "isEnterpriseVoiceEnabled": True,
            "featureTypes": ["Teams", "CallingPlan"],
            "telephoneNumbers": [
                {
                    "telephoneNumber": "+13235533696",
                    "assignmentCategory": "primary",
                }
            ],
            "effectivePolicyAssignments": [
                {
                    "policyType": "TeamsCallingPolicy",
                    "policyAssignment": {
                        "displayName": "Global",
                        "assignmentType": "direct",
                        "policyId": "tag:global",
                    },
                }
            ],
            "createdDateTime": "2024-01-15T10:00:00Z",
            "modifiedDateTime": "2024-01-20T14:30:00Z",
        }
        user = UserConfiguration.model_validate(api_response)
        assert user.id == "12345678-1234-5678-1234-567812345678"
        assert user.user_principal_name == "user@contoso.com"
        assert user.display_name == "John Doe"
        assert user.account_type == AccountType.USER
        assert len(user.telephone_numbers) == 1
        assert user.telephone_numbers[0].assignment_category == "primary"

    @pytest.mark.unit
    def test_account_type_from_string(self) -> None:
        """UserConfiguration parses account_type from string."""
        user = UserConfiguration(
            id="12345678-1234-5678-1234-567812345678",
            userPrincipalName="resource@contoso.com",
            tenantId="87654321-4321-8765-4321-876543218765",
            accountType="resourceAccount",  # type: ignore[arg-type]
            isEnterpriseVoiceEnabled=False,
        )
        assert user.account_type == AccountType.RESOURCE_ACCOUNT

    @pytest.mark.unit
    def test_invalid_account_type_rejected(self) -> None:
        """UserConfiguration rejects invalid account type."""
        with pytest.raises(ValidationError) as exc_info:
            UserConfiguration(
                id="12345678-1234-5678-1234-567812345678",
                userPrincipalName="user@contoso.com",
                tenantId="87654321-4321-8765-4321-876543218765",
                accountType="invalid-type",  # type: ignore[arg-type]
                isEnterpriseVoiceEnabled=True,
            )
        assert "accounttype" in str(exc_info.value).lower()

    @pytest.mark.unit
    def test_extra_field_rejected(self) -> None:
        """UserConfiguration rejects unknown fields (extra='forbid')."""
        with pytest.raises(ValidationError) as exc_info:
            UserConfiguration(
                id="12345678-1234-5678-1234-567812345678",
                userPrincipalName="user@contoso.com",
                tenantId="87654321-4321-8765-4321-876543218765",
                accountType=AccountType.USER,
                isEnterpriseVoiceEnabled=True,
                unknown_field="should fail",  # type: ignore[call-arg]
            )
        assert "extra_forbidden" in str(exc_info.value)

    @pytest.mark.unit
    def test_missing_required_field_rejected(self) -> None:
        """UserConfiguration requires essential fields."""
        with pytest.raises(ValidationError):
            UserConfiguration(
                id="12345678-1234-5678-1234-567812345678",
                # Missing userPrincipalName, tenantId, accountType, isEnterpriseVoiceEnabled
            )  # type: ignore[call-arg]

    @pytest.mark.unit
    def test_serialization(self) -> None:
        """UserConfiguration serializes to dict correctly."""
        user = UserConfiguration(
            id="12345678-1234-5678-1234-567812345678",
            userPrincipalName="user@contoso.com",
            tenantId="87654321-4321-8765-4321-876543218765",
            displayName="John Doe",
            accountType=AccountType.USER,
            isEnterpriseVoiceEnabled=True,
        )
        data = user.model_dump()
        assert data["id"] == "12345678-1234-5678-1234-567812345678"
        assert data["user_principal_name"] == "user@contoso.com"
        assert data["account_type"] == AccountType.USER
        assert data["feature_types"] == []

    @pytest.mark.unit
    def test_serialization_by_alias(self) -> None:
        """UserConfiguration serializes with camelCase aliases."""
        user = UserConfiguration(
            id="12345678-1234-5678-1234-567812345678",
            userPrincipalName="user@contoso.com",
            tenantId="87654321-4321-8765-4321-876543218765",
            accountType=AccountType.USER,
            isEnterpriseVoiceEnabled=True,
        )
        data = user.model_dump(by_alias=True)
        assert "userPrincipalName" in data
        assert "isEnterpriseVoiceEnabled" in data
        assert data["userPrincipalName"] == "user@contoso.com"

    @pytest.mark.unit
    def test_nested_extra_field_rejected_in_telephone(self) -> None:
        """UserConfiguration rejects extra fields in nested TelephoneNumber."""
        with pytest.raises(ValidationError) as exc_info:
            UserConfiguration.model_validate(
                {
                    "id": "12345678-1234-5678-1234-567812345678",
                    "userPrincipalName": "user@contoso.com",
                    "tenantId": "87654321-4321-8765-4321-876543218765",
                    "accountType": "user",
                    "isEnterpriseVoiceEnabled": True,
                    "telephoneNumbers": [
                        {
                            "telephoneNumber": "+13235533696",
                            "assignmentCategory": "primary",
                            "extraField": "should fail",
                        }
                    ],
                }
            )
        assert "extra_forbidden" in str(exc_info.value)
