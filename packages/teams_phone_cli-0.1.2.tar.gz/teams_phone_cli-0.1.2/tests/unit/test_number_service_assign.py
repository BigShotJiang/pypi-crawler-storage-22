"""Unit tests for NumberService assignment operations."""

from datetime import datetime, timezone
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch
from unittest.mock import MagicMock as SyncMock

import pytest

from teams_phone.exceptions import ValidationError

# Import infrastructure first to avoid circular import
from teams_phone.infrastructure import GraphClient  # noqa: F401
from teams_phone.models import (
    AsyncOperation,
    NumberType,
    OperationStatus,
)
from teams_phone.services.number_service import NumberService


def make_operation_dict(
    operation_id: str = "op-123",
    status: str = "succeeded",
    created_date_time: str = "2025-02-03T22:03:26Z",
    numbers: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Create an async operation dictionary for testing.

    Args:
        operation_id: Unique identifier for the operation.
        status: Operation status (notStarted, running, succeeded, failed, skipped).
        created_date_time: ISO 8601 timestamp of operation creation.
        numbers: List of number status dictionaries.

    Returns:
        Dictionary matching Graph API async operation response format.
    """
    if numbers is None:
        numbers = [
            {
                "resourceLocation": f"https://graph.microsoft.com/beta/.../numberAssignments/{operation_id}",
                "status": status,
            }
        ]
    return {
        "@odata.type": "#microsoft.graph.teamsAdministration.telephoneNumberLongRunningOperation",
        "id": operation_id,
        "createdDateTime": created_date_time,
        "status": status,
        "numbers": numbers,
    }


class TestNumberServicePollOperation:
    """Tests for NumberService.poll_operation method."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_poll_operation_returns_on_success(
        self, mock_graph_client: MagicMock
    ) -> None:
        """poll_operation returns AsyncOperation when status is succeeded."""
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(status="succeeded")
        )

        service = NumberService(mock_graph_client)
        result = await service.poll_operation("op-123")

        assert isinstance(result, AsyncOperation)
        assert result.status == OperationStatus.SUCCEEDED
        assert result.id == "op-123"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_poll_operation_returns_on_failed(
        self, mock_graph_client: MagicMock
    ) -> None:
        """poll_operation returns AsyncOperation when status is failed."""
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(status="failed")
        )

        service = NumberService(mock_graph_client)
        result = await service.poll_operation("op-123")

        assert isinstance(result, AsyncOperation)
        assert result.status == OperationStatus.FAILED

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_poll_operation_returns_on_skipped(
        self, mock_graph_client: MagicMock
    ) -> None:
        """poll_operation returns AsyncOperation when status is skipped."""
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(status="skipped")
        )

        service = NumberService(mock_graph_client)
        result = await service.poll_operation("op-123")

        assert isinstance(result, AsyncOperation)
        assert result.status == OperationStatus.SKIPPED

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_poll_operation_polls_until_success(
        self, mock_graph_client: MagicMock
    ) -> None:
        """poll_operation polls multiple times until terminal state."""
        responses = [
            make_operation_dict(status="notStarted"),
            make_operation_dict(status="running"),
            make_operation_dict(status="succeeded"),
        ]
        mock_graph_client.get = AsyncMock(side_effect=responses)

        service = NumberService(mock_graph_client)

        # Patch asyncio.sleep to avoid actual delays
        with patch(
            "teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()
        ):
            result = await service.poll_operation("op-123")

        assert result.status == OperationStatus.SUCCEEDED
        assert mock_graph_client.get.call_count == 3

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_poll_operation_uses_correct_endpoint(
        self, mock_graph_client: MagicMock
    ) -> None:
        """poll_operation calls get with correct endpoint."""
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(status="succeeded")
        )

        service = NumberService(mock_graph_client)
        await service.poll_operation("my-operation-id")

        mock_graph_client.get.assert_called_once_with(
            "/admin/teams/telephoneNumberManagement/operations/my-operation-id"
        )

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_poll_operation_timeout_raises_error(
        self, mock_graph_client: MagicMock
    ) -> None:
        """poll_operation raises TimeoutError when timeout exceeded."""
        # Always return running status
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(status="running")
        )

        service = NumberService(mock_graph_client)

        # Mock time.time() to simulate timeout
        start_time = 1000.0
        call_count = 0

        def mock_time() -> float:
            nonlocal call_count
            call_count += 1
            # First call: start time, subsequent calls: beyond timeout
            if call_count == 1:
                return start_time
            return start_time + 61  # Beyond 60s timeout

        with (
            patch(
                "teams_phone.services.number_service.time.time", side_effect=mock_time
            ),
            patch("teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()),
            pytest.raises(TimeoutError) as exc_info,
        ):
            await service.poll_operation("op-123", timeout=60)

        assert "op-123" in str(exc_info.value)
        assert "60s" in str(exc_info.value)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_poll_operation_invokes_progress_callback(
        self, mock_graph_client: MagicMock
    ) -> None:
        """poll_operation invokes on_progress callback on each iteration."""
        responses = [
            make_operation_dict(status="running"),
            make_operation_dict(status="succeeded"),
        ]
        mock_graph_client.get = AsyncMock(side_effect=responses)
        progress_callback = SyncMock()

        service = NumberService(mock_graph_client)

        with patch(
            "teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()
        ):
            await service.poll_operation("op-123", on_progress=progress_callback)

        assert progress_callback.call_count == 2
        # First call with running status
        first_call_arg = progress_callback.call_args_list[0][0][0]
        assert isinstance(first_call_arg, AsyncOperation)
        assert first_call_arg.status == OperationStatus.RUNNING
        # Second call with succeeded status
        second_call_arg = progress_callback.call_args_list[1][0][0]
        assert second_call_arg.status == OperationStatus.SUCCEEDED

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_poll_operation_no_callback_when_none(
        self, mock_graph_client: MagicMock
    ) -> None:
        """poll_operation works correctly when on_progress is None."""
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(status="succeeded")
        )

        service = NumberService(mock_graph_client)
        # Should not raise any errors
        result = await service.poll_operation("op-123", on_progress=None)

        assert result.status == OperationStatus.SUCCEEDED

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_poll_operation_custom_timeout(
        self, mock_graph_client: MagicMock
    ) -> None:
        """poll_operation respects custom timeout parameter."""
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(status="running")
        )

        service = NumberService(mock_graph_client)

        start_time = 1000.0
        call_count = 0

        def mock_time() -> float:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return start_time
            return start_time + 11  # Beyond 10s custom timeout

        with (
            patch(
                "teams_phone.services.number_service.time.time", side_effect=mock_time
            ),
            patch("teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()),
            pytest.raises(TimeoutError) as exc_info,
        ):
            await service.poll_operation("op-123", timeout=10)

        assert "10s" in str(exc_info.value)


class TestNumberServiceExtractOperationId:
    """Tests for NumberService._extract_operation_id method."""

    @pytest.mark.unit
    def test_extracts_id_from_full_url(self, mock_graph_client: MagicMock) -> None:
        """_extract_operation_id extracts ID from full Graph API URL."""
        service = NumberService(mock_graph_client)
        header = (
            "https://graph.microsoft.com/beta/admin/teams/"
            "telephoneNumberManagement/operations('op-123-abc')"
        )

        result = service._extract_operation_id(header)

        assert result == "op-123-abc"

    @pytest.mark.unit
    def test_extracts_id_from_base64_encoded_id(
        self, mock_graph_client: MagicMock
    ) -> None:
        """_extract_operation_id extracts base64-encoded operation ID."""
        service = NumberService(mock_graph_client)
        # Example from API docs - base64 encoded operation ID
        header = (
            "https://graph.microsoft.com/beta/admin/teams/"
            "telephoneNumberManagement/operations('QXNzaWdubWVudHw2Y2E4Yjc0Ni0=')"
        )

        result = service._extract_operation_id(header)

        assert result == "QXNzaWdubWVudHw2Y2E4Yjc0Ni0="

    @pytest.mark.unit
    def test_extracts_id_from_minimal_path(self, mock_graph_client: MagicMock) -> None:
        """_extract_operation_id extracts ID from minimal path."""
        service = NumberService(mock_graph_client)
        header = "operations('simple-id')"

        result = service._extract_operation_id(header)

        assert result == "simple-id"

    @pytest.mark.unit
    def test_extracts_id_with_query_params(self, mock_graph_client: MagicMock) -> None:
        """_extract_operation_id extracts ID when URL has query parameters."""
        service = NumberService(mock_graph_client)
        header = (
            "https://graph.microsoft.com/beta/admin/teams/"
            "telephoneNumberManagement/operations('op-123')?api-version=beta"
        )

        result = service._extract_operation_id(header)

        assert result == "op-123"

    @pytest.mark.unit
    def test_extracts_id_with_special_characters(
        self, mock_graph_client: MagicMock
    ) -> None:
        """_extract_operation_id handles IDs with special characters."""
        service = NumberService(mock_graph_client)
        # Operation IDs may contain pipes, equals, dashes
        header = "operations('Assignment|6ca8b746-1234-5678|abc=')"

        result = service._extract_operation_id(header)

        assert result == "Assignment|6ca8b746-1234-5678|abc="

    @pytest.mark.unit
    def test_raises_validation_error_for_empty_string(
        self, mock_graph_client: MagicMock
    ) -> None:
        """_extract_operation_id raises ValidationError for empty string."""
        service = NumberService(mock_graph_client)

        with pytest.raises(ValidationError) as exc_info:
            service._extract_operation_id("")

        assert "Invalid Location header format" in str(exc_info.value)
        assert exc_info.value.remediation is not None
        assert "operations('{operation_id}')" in exc_info.value.remediation

    @pytest.mark.unit
    def test_raises_validation_error_for_missing_quotes(
        self, mock_graph_client: MagicMock
    ) -> None:
        """_extract_operation_id raises ValidationError when quotes are missing."""
        service = NumberService(mock_graph_client)
        # Wrong format - no quotes around ID
        header = "operations(op-123)"

        with pytest.raises(ValidationError) as exc_info:
            service._extract_operation_id(header)

        assert "Invalid Location header format" in str(exc_info.value)

    @pytest.mark.unit
    def test_raises_validation_error_for_wrong_parentheses(
        self, mock_graph_client: MagicMock
    ) -> None:
        """_extract_operation_id raises ValidationError for wrong format."""
        service = NumberService(mock_graph_client)
        # Wrong format - uses brackets instead of parentheses
        header = "operations['op-123']"

        with pytest.raises(ValidationError) as exc_info:
            service._extract_operation_id(header)

        assert "Invalid Location header format" in str(exc_info.value)

    @pytest.mark.unit
    def test_raises_validation_error_for_no_operations_keyword(
        self, mock_graph_client: MagicMock
    ) -> None:
        """_extract_operation_id raises ValidationError when operations keyword missing."""
        service = NumberService(mock_graph_client)
        header = "https://graph.microsoft.com/beta/some/other/path"

        with pytest.raises(ValidationError) as exc_info:
            service._extract_operation_id(header)

        assert "Invalid Location header format" in str(exc_info.value)

    @pytest.mark.unit
    def test_raises_validation_error_for_empty_id(
        self, mock_graph_client: MagicMock
    ) -> None:
        """_extract_operation_id raises ValidationError when ID is empty."""
        service = NumberService(mock_graph_client)
        # Pattern requires at least one character between quotes
        header = "operations('')"

        with pytest.raises(ValidationError) as exc_info:
            service._extract_operation_id(header)

        assert "Invalid Location header format" in str(exc_info.value)

    @pytest.mark.unit
    def test_validation_error_includes_header_in_message(
        self, mock_graph_client: MagicMock
    ) -> None:
        """_extract_operation_id includes the malformed header in error message."""
        service = NumberService(mock_graph_client)
        bad_header = "some/bad/path"

        with pytest.raises(ValidationError) as exc_info:
            service._extract_operation_id(bad_header)

        assert bad_header in str(exc_info.value)

    @pytest.mark.unit
    def test_validation_error_suggests_api_change(
        self, mock_graph_client: MagicMock
    ) -> None:
        """_extract_operation_id remediation suggests API format change."""
        service = NumberService(mock_graph_client)

        with pytest.raises(ValidationError) as exc_info:
            service._extract_operation_id("invalid")

        assert exc_info.value.remediation is not None
        assert "API response format change" in exc_info.value.remediation


class TestNumberServiceAssignNumber:
    """Tests for NumberService.assign_number method."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_calling_plan_without_location_raises_validation_error(
        self, mock_graph_client: MagicMock
    ) -> None:
        """assign_number raises ValidationError for CallingPlan without location_id."""
        service = NumberService(mock_graph_client)

        with pytest.raises(ValidationError) as exc_info:
            await service.assign_number(
                user_id="user-123",
                phone_number="+12065551234",
                number_type=NumberType.CALLING_PLAN,
            )

        assert "Emergency location required" in str(exc_info.value)
        assert "+12065551234" in str(exc_info.value)
        assert exc_info.value.remediation is not None
        assert "--location" in exc_info.value.remediation

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_calling_plan_with_location_succeeds(
        self, mock_graph_client: MagicMock
    ) -> None:
        """assign_number succeeds for CallingPlan when location_id provided."""
        # Mock response with Location header
        mock_response = SyncMock()
        mock_response.headers = {
            "location": "https://graph.microsoft.com/beta/admin/teams/"
            "telephoneNumberManagement/operations('op-123')"
        }
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(status="succeeded")
        )

        service = NumberService(mock_graph_client)

        with patch(
            "teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()
        ):
            result = await service.assign_number(
                user_id="user-123",
                phone_number="+12065551234",
                number_type=NumberType.CALLING_PLAN,
                location_id="loc-456",
            )

        assert result.status == OperationStatus.SUCCEEDED
        # Verify POST was called with correct body
        call_args = mock_graph_client.post_with_response.call_args
        body = call_args[0][1]
        assert body["telephoneNumber"] == "12065551234"  # Digits only
        assert body["numberType"] == "callingPlan"
        assert body["assignmentTargetId"] == "user-123"
        assert body["locationId"] == "loc-456"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_direct_routing_without_location_succeeds(
        self, mock_graph_client: MagicMock
    ) -> None:
        """assign_number succeeds for DirectRouting without location_id."""
        mock_response = SyncMock()
        mock_response.headers = {"location": "operations('op-123')"}
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(status="succeeded")
        )

        service = NumberService(mock_graph_client)

        with patch(
            "teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()
        ):
            result = await service.assign_number(
                user_id="user-123",
                phone_number="+12065551234",
                number_type=NumberType.DIRECT_ROUTING,
            )

        assert result.status == OperationStatus.SUCCEEDED
        # Verify locationId was not included in body
        call_args = mock_graph_client.post_with_response.call_args
        body = call_args[0][1]
        assert "locationId" not in body

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_operator_connect_without_location_succeeds(
        self, mock_graph_client: MagicMock
    ) -> None:
        """assign_number succeeds for OperatorConnect without location_id."""
        mock_response = SyncMock()
        mock_response.headers = {"location": "operations('op-123')"}
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(status="succeeded")
        )

        service = NumberService(mock_graph_client)

        with patch(
            "teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()
        ):
            result = await service.assign_number(
                user_id="user-123",
                phone_number="+12065551234",
                number_type=NumberType.OPERATOR_CONNECT,
            )

        assert result.status == OperationStatus.SUCCEEDED

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_phone_number_normalized_via_format_for_assign(
        self, mock_graph_client: MagicMock
    ) -> None:
        """assign_number normalizes phone number using format_for_assign."""
        mock_response = SyncMock()
        mock_response.headers = {"location": "operations('op-123')"}
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(status="succeeded")
        )

        service = NumberService(mock_graph_client)

        with patch(
            "teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()
        ):
            await service.assign_number(
                user_id="user-123",
                phone_number="+1 (206) 555-1234",  # Formatted input
                number_type=NumberType.DIRECT_ROUTING,
            )

        # Verify POST body has digits-only phone number
        call_args = mock_graph_client.post_with_response.call_args
        body = call_args[0][1]
        assert body["telephoneNumber"] == "12065551234"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_request_body_includes_all_required_fields(
        self, mock_graph_client: MagicMock
    ) -> None:
        """assign_number constructs correct request body."""
        mock_response = SyncMock()
        mock_response.headers = {"location": "operations('op-123')"}
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(status="succeeded")
        )

        service = NumberService(mock_graph_client)

        with patch(
            "teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()
        ):
            await service.assign_number(
                user_id="user-abc-123",
                phone_number="+14255551234",
                number_type=NumberType.DIRECT_ROUTING,
                location_id="loc-xyz",
            )

        # Verify endpoint
        call_args = mock_graph_client.post_with_response.call_args
        endpoint = call_args[0][0]
        assert (
            endpoint
            == "/admin/teams/telephoneNumberManagement/numberAssignments/assignNumber"
        )

        # Verify body
        body = call_args[0][1]
        assert body["telephoneNumber"] == "14255551234"
        assert body["numberType"] == "directRouting"
        assert body["assignmentTargetId"] == "user-abc-123"
        assert body["locationId"] == "loc-xyz"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_extracts_operation_id_from_location_header(
        self, mock_graph_client: MagicMock
    ) -> None:
        """assign_number extracts operation ID from 202 Location header."""
        mock_response = SyncMock()
        mock_response.headers = {
            "location": "https://graph.microsoft.com/beta/admin/teams/"
            "telephoneNumberManagement/operations('my-operation-id-abc')"
        }
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(
                operation_id="my-operation-id-abc", status="succeeded"
            )
        )

        service = NumberService(mock_graph_client)

        with patch(
            "teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()
        ):
            result = await service.assign_number(
                user_id="user-123",
                phone_number="+12065551234",
                number_type=NumberType.DIRECT_ROUTING,
            )

        # poll_operation should have been called with extracted ID
        mock_graph_client.get.assert_called_once_with(
            "/admin/teams/telephoneNumberManagement/operations/my-operation-id-abc"
        )
        assert result.id == "my-operation-id-abc"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_wait_true_polls_for_completion(
        self, mock_graph_client: MagicMock
    ) -> None:
        """assign_number with wait=True polls until operation completes."""
        mock_response = SyncMock()
        mock_response.headers = {"location": "operations('op-123')"}
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)

        # Poll returns running, then succeeded
        responses = [
            make_operation_dict(status="running"),
            make_operation_dict(status="succeeded"),
        ]
        mock_graph_client.get = AsyncMock(side_effect=responses)

        service = NumberService(mock_graph_client)

        with patch(
            "teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()
        ):
            result = await service.assign_number(
                user_id="user-123",
                phone_number="+12065551234",
                number_type=NumberType.DIRECT_ROUTING,
                wait=True,
            )

        assert result.status == OperationStatus.SUCCEEDED
        assert mock_graph_client.get.call_count == 2

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_wait_false_returns_immediately(
        self, mock_graph_client: MagicMock
    ) -> None:
        """assign_number with wait=False returns AsyncOperation immediately."""
        mock_response = SyncMock()
        mock_response.headers = {"location": "operations('op-immediate')"}
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)

        service = NumberService(mock_graph_client)

        result = await service.assign_number(
            user_id="user-123",
            phone_number="+12065551234",
            number_type=NumberType.DIRECT_ROUTING,
            wait=False,
        )

        assert isinstance(result, AsyncOperation)
        assert result.id == "op-immediate"
        assert result.status == OperationStatus.NOT_STARTED
        assert result.numbers == []
        # graph_client.get should NOT have been called (no polling)
        mock_graph_client.get.assert_not_called()

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_wait_false_includes_created_datetime(
        self, mock_graph_client: MagicMock
    ) -> None:
        """assign_number with wait=False sets created_date_time."""
        mock_response = SyncMock()
        mock_response.headers = {"location": "operations('op-123')"}
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)

        service = NumberService(mock_graph_client)

        before = datetime.now(timezone.utc)
        result = await service.assign_number(
            user_id="user-123",
            phone_number="+12065551234",
            number_type=NumberType.DIRECT_ROUTING,
            wait=False,
        )
        after = datetime.now(timezone.utc)

        assert before <= result.created_date_time <= after

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_timeout_passed_to_poll_operation(
        self, mock_graph_client: MagicMock
    ) -> None:
        """assign_number passes timeout parameter to poll_operation."""
        mock_response = SyncMock()
        mock_response.headers = {"location": "operations('op-123')"}
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)

        # Always return running - we'll verify timeout is passed
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(status="running")
        )

        service = NumberService(mock_graph_client)

        start_time = 1000.0
        call_count = 0

        def mock_time() -> float:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return start_time
            return start_time + 31  # Beyond 30s custom timeout

        with (
            patch(
                "teams_phone.services.number_service.time.time", side_effect=mock_time
            ),
            patch("teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()),
            pytest.raises(TimeoutError) as exc_info,
        ):
            await service.assign_number(
                user_id="user-123",
                phone_number="+12065551234",
                number_type=NumberType.DIRECT_ROUTING,
                timeout=30,
            )

        assert "30s" in str(exc_info.value)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_invalid_location_header_raises_validation_error(
        self, mock_graph_client: MagicMock
    ) -> None:
        """assign_number raises ValidationError for invalid Location header."""
        mock_response = SyncMock()
        mock_response.headers = {"location": "invalid-header-format"}
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)

        service = NumberService(mock_graph_client)

        with pytest.raises(ValidationError) as exc_info:
            await service.assign_number(
                user_id="user-123",
                phone_number="+12065551234",
                number_type=NumberType.DIRECT_ROUTING,
            )

        assert "Invalid Location header format" in str(exc_info.value)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_missing_location_header_raises_validation_error(
        self, mock_graph_client: MagicMock
    ) -> None:
        """assign_number raises ValidationError when Location header is missing."""
        mock_response = SyncMock()
        mock_response.headers = {}  # No Location header
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)

        service = NumberService(mock_graph_client)

        with pytest.raises(ValidationError) as exc_info:
            await service.assign_number(
                user_id="user-123",
                phone_number="+12065551234",
                number_type=NumberType.DIRECT_ROUTING,
            )

        assert "Invalid Location header format" in str(exc_info.value)
