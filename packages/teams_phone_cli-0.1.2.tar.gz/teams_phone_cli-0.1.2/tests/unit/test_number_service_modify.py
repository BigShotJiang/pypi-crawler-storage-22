"""Unit tests for NumberService modification operations."""

from datetime import datetime, timezone
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch
from unittest.mock import MagicMock as SyncMock

import pytest

from teams_phone.exceptions import ValidationError

# Import infrastructure first to avoid circular import
from teams_phone.infrastructure import GraphClient  # noqa: F401
from teams_phone.models import (
    AsyncOperation,
    NumberType,
    OperationStatus,
)
from teams_phone.services.number_service import NumberService


def make_operation_dict(
    operation_id: str = "op-123",
    status: str = "succeeded",
    created_date_time: str = "2025-02-03T22:03:26Z",
    numbers: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Create an async operation dictionary for testing.

    Args:
        operation_id: Unique identifier for the operation.
        status: Operation status (notStarted, running, succeeded, failed, skipped).
        created_date_time: ISO 8601 timestamp of operation creation.
        numbers: List of number status dictionaries.

    Returns:
        Dictionary matching Graph API async operation response format.
    """
    if numbers is None:
        numbers = [
            {
                "resourceLocation": f"https://graph.microsoft.com/beta/.../numberAssignments/{operation_id}",
                "status": status,
            }
        ]
    return {
        "@odata.type": "#microsoft.graph.teamsAdministration.telephoneNumberLongRunningOperation",
        "id": operation_id,
        "createdDateTime": created_date_time,
        "status": status,
        "numbers": numbers,
    }


class TestNumberServiceUnassignNumber:
    """Tests for NumberService.unassign_number method."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_successful_unassign_with_wait(
        self, mock_graph_client: MagicMock
    ) -> None:
        """unassign_number successfully unassigns number with wait=True."""
        mock_response = SyncMock()
        mock_response.headers = {
            "location": "https://graph.microsoft.com/beta/admin/teams/"
            "telephoneNumberManagement/operations('unassign-op-123')"
        }
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(
                operation_id="unassign-op-123", status="succeeded"
            )
        )

        service = NumberService(mock_graph_client)

        with patch(
            "teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()
        ):
            result = await service.unassign_number(
                phone_number="+12065551234",
                number_type=NumberType.DIRECT_ROUTING,
            )

        assert result.status == OperationStatus.SUCCEEDED
        assert result.id == "unassign-op-123"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_request_body_contains_only_required_fields(
        self, mock_graph_client: MagicMock
    ) -> None:
        """unassign_number request body contains only telephoneNumber and numberType."""
        mock_response = SyncMock()
        mock_response.headers = {"location": "operations('op-123')"}
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(status="succeeded")
        )

        service = NumberService(mock_graph_client)

        with patch(
            "teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()
        ):
            await service.unassign_number(
                phone_number="+12065551234",
                number_type=NumberType.CALLING_PLAN,
            )

        # Verify endpoint
        call_args = mock_graph_client.post_with_response.call_args
        endpoint = call_args[0][0]
        assert (
            endpoint
            == "/admin/teams/telephoneNumberManagement/numberAssignments/unassignNumber"
        )

        # Verify body has ONLY telephoneNumber and numberType (no userId, no locationId)
        body = call_args[0][1]
        assert body == {
            "telephoneNumber": "12065551234",
            "numberType": "callingPlan",
        }
        assert "assignmentTargetId" not in body
        assert "locationId" not in body

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_phone_number_normalized_via_format_for_assign(
        self, mock_graph_client: MagicMock
    ) -> None:
        """unassign_number normalizes phone number using format_for_assign."""
        mock_response = SyncMock()
        mock_response.headers = {"location": "operations('op-123')"}
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(status="succeeded")
        )

        service = NumberService(mock_graph_client)

        with patch(
            "teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()
        ):
            await service.unassign_number(
                phone_number="+1 (206) 555-1234",  # Formatted input
                number_type=NumberType.DIRECT_ROUTING,
            )

        # Verify POST body has digits-only phone number
        call_args = mock_graph_client.post_with_response.call_args
        body = call_args[0][1]
        assert body["telephoneNumber"] == "12065551234"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_wait_true_polls_for_completion(
        self, mock_graph_client: MagicMock
    ) -> None:
        """unassign_number with wait=True polls until operation completes."""
        mock_response = SyncMock()
        mock_response.headers = {"location": "operations('op-123')"}
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)

        # Poll returns running, then succeeded
        responses = [
            make_operation_dict(status="running"),
            make_operation_dict(status="succeeded"),
        ]
        mock_graph_client.get = AsyncMock(side_effect=responses)

        service = NumberService(mock_graph_client)

        with patch(
            "teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()
        ):
            result = await service.unassign_number(
                phone_number="+12065551234",
                number_type=NumberType.DIRECT_ROUTING,
                wait=True,
            )

        assert result.status == OperationStatus.SUCCEEDED
        assert mock_graph_client.get.call_count == 2

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_wait_false_returns_immediately(
        self, mock_graph_client: MagicMock
    ) -> None:
        """unassign_number with wait=False returns AsyncOperation immediately."""
        mock_response = SyncMock()
        mock_response.headers = {"location": "operations('op-immediate')"}
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)

        service = NumberService(mock_graph_client)

        result = await service.unassign_number(
            phone_number="+12065551234",
            number_type=NumberType.DIRECT_ROUTING,
            wait=False,
        )

        assert isinstance(result, AsyncOperation)
        assert result.id == "op-immediate"
        assert result.status == OperationStatus.NOT_STARTED
        assert result.numbers == []
        # graph_client.get should NOT have been called (no polling)
        mock_graph_client.get.assert_not_called()

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_wait_false_includes_created_datetime(
        self, mock_graph_client: MagicMock
    ) -> None:
        """unassign_number with wait=False sets created_date_time."""
        mock_response = SyncMock()
        mock_response.headers = {"location": "operations('op-123')"}
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)

        service = NumberService(mock_graph_client)

        before = datetime.now(timezone.utc)
        result = await service.unassign_number(
            phone_number="+12065551234",
            number_type=NumberType.DIRECT_ROUTING,
            wait=False,
        )
        after = datetime.now(timezone.utc)

        assert before <= result.created_date_time <= after

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_timeout_passed_to_poll_operation(
        self, mock_graph_client: MagicMock
    ) -> None:
        """unassign_number passes timeout parameter to poll_operation."""
        mock_response = SyncMock()
        mock_response.headers = {"location": "operations('op-123')"}
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)

        # Always return running - we'll verify timeout is passed
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(status="running")
        )

        service = NumberService(mock_graph_client)

        start_time = 1000.0
        call_count = 0

        def mock_time() -> float:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return start_time
            return start_time + 31  # Beyond 30s custom timeout

        with (
            patch(
                "teams_phone.services.number_service.time.time", side_effect=mock_time
            ),
            patch("teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()),
            pytest.raises(TimeoutError) as exc_info,
        ):
            await service.unassign_number(
                phone_number="+12065551234",
                number_type=NumberType.DIRECT_ROUTING,
                timeout=30,
            )

        assert "30s" in str(exc_info.value)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_invalid_location_header_raises_validation_error(
        self, mock_graph_client: MagicMock
    ) -> None:
        """unassign_number raises ValidationError for invalid Location header."""
        mock_response = SyncMock()
        mock_response.headers = {"location": "invalid-header-format"}
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)

        service = NumberService(mock_graph_client)

        with pytest.raises(ValidationError) as exc_info:
            await service.unassign_number(
                phone_number="+12065551234",
                number_type=NumberType.DIRECT_ROUTING,
            )

        assert "Invalid Location header format" in str(exc_info.value)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_missing_location_header_raises_validation_error(
        self, mock_graph_client: MagicMock
    ) -> None:
        """unassign_number raises ValidationError when Location header is missing."""
        mock_response = SyncMock()
        mock_response.headers = {}  # No Location header
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)

        service = NumberService(mock_graph_client)

        with pytest.raises(ValidationError) as exc_info:
            await service.unassign_number(
                phone_number="+12065551234",
                number_type=NumberType.DIRECT_ROUTING,
            )

        assert "Invalid Location header format" in str(exc_info.value)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_operation_failure_returns_failed_status(
        self, mock_graph_client: MagicMock
    ) -> None:
        """unassign_number returns failed status when operation fails."""
        mock_response = SyncMock()
        mock_response.headers = {"location": "operations('op-123')"}
        mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)
        mock_graph_client.get = AsyncMock(
            return_value=make_operation_dict(status="failed")
        )

        service = NumberService(mock_graph_client)

        with patch(
            "teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()
        ):
            result = await service.unassign_number(
                phone_number="+12065551234",
                number_type=NumberType.DIRECT_ROUTING,
            )

        assert result.status == OperationStatus.FAILED

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_all_number_types_supported(
        self, mock_graph_client: MagicMock
    ) -> None:
        """unassign_number works with all number types."""
        service = NumberService(mock_graph_client)

        for number_type in [
            NumberType.DIRECT_ROUTING,
            NumberType.CALLING_PLAN,
            NumberType.OPERATOR_CONNECT,
        ]:
            mock_response = SyncMock()
            mock_response.headers = {"location": "operations('op-123')"}
            mock_graph_client.post_with_response = AsyncMock(return_value=mock_response)
            mock_graph_client.get = AsyncMock(
                return_value=make_operation_dict(status="succeeded")
            )

            with patch(
                "teams_phone.services.number_service.asyncio.sleep", new=AsyncMock()
            ):
                result = await service.unassign_number(
                    phone_number="+12065551234",
                    number_type=number_type,
                )

            assert result.status == OperationStatus.SUCCEEDED

            # Verify correct numberType in body
            call_args = mock_graph_client.post_with_response.call_args
            body = call_args[0][1]
            assert body["numberType"] == number_type.value


class TestNumberServiceUpdateNumber:
    """Tests for NumberService.update_number method."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_update_with_location_id(self, mock_graph_client: MagicMock) -> None:
        """update_number sends location_id in request body."""
        mock_graph_client.post = AsyncMock(return_value={})

        service = NumberService(mock_graph_client)

        await service.update_number(
            phone_number="+12065551234",
            location_id="loc-abc-123",
        )

        # Verify endpoint and body
        call_args = mock_graph_client.post.call_args
        endpoint = call_args[0][0]
        body = call_args[0][1]
        assert (
            endpoint
            == "/admin/teams/telephoneNumberManagement/numberAssignments/updateNumber"
        )
        assert body["telephoneNumber"] == "+12065551234"
        assert body["locationId"] == "loc-abc-123"
        assert "networkSiteId" not in body

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_update_with_clear_location(
        self, mock_graph_client: MagicMock
    ) -> None:
        """update_number sends empty string to clear location."""
        mock_graph_client.post = AsyncMock(return_value={})

        service = NumberService(mock_graph_client)

        await service.update_number(
            phone_number="+12065551234",
            clear_location=True,
        )

        # Verify body has empty string for locationId
        call_args = mock_graph_client.post.call_args
        body = call_args[0][1]
        assert body["telephoneNumber"] == "+12065551234"
        assert body["locationId"] == ""
        assert "networkSiteId" not in body

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_update_with_network_site_id(
        self, mock_graph_client: MagicMock
    ) -> None:
        """update_number sends network_site_id in request body."""
        mock_graph_client.post = AsyncMock(return_value={})

        service = NumberService(mock_graph_client)

        await service.update_number(
            phone_number="+12065551234",
            network_site_id="site-xyz-789",
        )

        # Verify body
        call_args = mock_graph_client.post.call_args
        body = call_args[0][1]
        assert body["telephoneNumber"] == "+12065551234"
        assert body["networkSiteId"] == "site-xyz-789"
        assert "locationId" not in body

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_update_with_clear_network_site(
        self, mock_graph_client: MagicMock
    ) -> None:
        """update_number sends empty string to clear network site."""
        mock_graph_client.post = AsyncMock(return_value={})

        service = NumberService(mock_graph_client)

        await service.update_number(
            phone_number="+12065551234",
            clear_network_site=True,
        )

        # Verify body has empty string for networkSiteId
        call_args = mock_graph_client.post.call_args
        body = call_args[0][1]
        assert body["telephoneNumber"] == "+12065551234"
        assert body["networkSiteId"] == ""
        assert "locationId" not in body

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_update_with_both_location_and_network_site(
        self, mock_graph_client: MagicMock
    ) -> None:
        """update_number can update both location and network site at once."""
        mock_graph_client.post = AsyncMock(return_value={})

        service = NumberService(mock_graph_client)

        await service.update_number(
            phone_number="+12065551234",
            location_id="loc-abc",
            network_site_id="site-xyz",
        )

        # Verify body has both fields
        call_args = mock_graph_client.post.call_args
        body = call_args[0][1]
        assert body["telephoneNumber"] == "+12065551234"
        assert body["locationId"] == "loc-abc"
        assert body["networkSiteId"] == "site-xyz"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_phone_number_uses_format_for_update_with_plus_prefix(
        self, mock_graph_client: MagicMock
    ) -> None:
        """update_number formats phone number with + prefix (E.164)."""
        mock_graph_client.post = AsyncMock(return_value={})

        service = NumberService(mock_graph_client)

        await service.update_number(
            phone_number="1 (206) 555-1234",  # Unformatted input
            location_id="loc-123",
        )

        # Verify phone number has + prefix
        call_args = mock_graph_client.post.call_args
        body = call_args[0][1]
        assert body["telephoneNumber"] == "+12065551234"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_location_and_clear_location_mutually_exclusive(
        self, mock_graph_client: MagicMock
    ) -> None:
        """update_number raises ValidationError if both location_id and clear_location specified."""
        service = NumberService(mock_graph_client)

        with pytest.raises(ValidationError) as exc_info:
            await service.update_number(
                phone_number="+12065551234",
                location_id="loc-123",
                clear_location=True,
            )

        assert "Cannot specify both --location and --clear-location" in str(
            exc_info.value
        )
        assert exc_info.value.remediation is not None
        # Verify post was NOT called
        mock_graph_client.post.assert_not_called()

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_network_site_and_clear_network_site_mutually_exclusive(
        self, mock_graph_client: MagicMock
    ) -> None:
        """update_number raises ValidationError if both network_site_id and clear_network_site specified."""
        service = NumberService(mock_graph_client)

        with pytest.raises(ValidationError) as exc_info:
            await service.update_number(
                phone_number="+12065551234",
                network_site_id="site-123",
                clear_network_site=True,
            )

        assert "Cannot specify both --network-site and --clear-network-site" in str(
            exc_info.value
        )
        assert exc_info.value.remediation is not None
        # Verify post was NOT called
        mock_graph_client.post.assert_not_called()

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_no_update_parameters_raises_validation_error(
        self, mock_graph_client: MagicMock
    ) -> None:
        """update_number raises ValidationError if no update parameters provided."""
        service = NumberService(mock_graph_client)

        with pytest.raises(ValidationError) as exc_info:
            await service.update_number(
                phone_number="+12065551234",
                # No location or network site parameters
            )

        assert "No update parameters specified" in str(exc_info.value)
        assert exc_info.value.remediation is not None
        # Verify post was NOT called
        mock_graph_client.post.assert_not_called()

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_returns_none_on_success(self, mock_graph_client: MagicMock) -> None:
        """update_number returns None (void) on successful update."""
        mock_graph_client.post = AsyncMock(return_value={})

        service = NumberService(mock_graph_client)

        await service.update_number(
            phone_number="+12065551234",
            location_id="loc-123",
        )
        # update_number returns None (void function) - test passes if no exception raised

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_clear_location_and_set_network_site(
        self, mock_graph_client: MagicMock
    ) -> None:
        """update_number can clear location while setting network site."""
        mock_graph_client.post = AsyncMock(return_value={})

        service = NumberService(mock_graph_client)

        await service.update_number(
            phone_number="+12065551234",
            clear_location=True,
            network_site_id="site-xyz",
        )

        # Verify body has empty string for location and value for network site
        call_args = mock_graph_client.post.call_args
        body = call_args[0][1]
        assert body["locationId"] == ""
        assert body["networkSiteId"] == "site-xyz"
