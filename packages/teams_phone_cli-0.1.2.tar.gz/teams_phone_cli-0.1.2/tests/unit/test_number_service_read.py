"""Unit tests for NumberService read operations."""

from collections.abc import AsyncIterator
from typing import Any
from unittest.mock import MagicMock

import pytest

from teams_phone.exceptions import NotFoundError

# Import infrastructure first to avoid circular import
from teams_phone.infrastructure import GraphClient  # noqa: F401
from teams_phone.models import (
    AssignmentStatus,
    NumberAssignment,
    NumberType,
)
from teams_phone.services.number_service import NumberService


def make_number_dict(
    number_id: str = "num-1",
    telephone_number: str = "+14255551234",
    number_type: str = "directRouting",
    activation_state: str = "activated",
    assignment_status: str = "unassigned",
    city: str | None = "Seattle",
    location_id: str | None = None,
    assignment_target_id: str | None = None,
) -> dict[str, Any]:
    """Create a number assignment dictionary for testing.

    Args:
        number_id: Unique identifier for the number.
        telephone_number: Phone number in E.164 format.
        number_type: Type of phone number.
        activation_state: Activation state of the number.
        assignment_status: Assignment status.
        city: City associated with the number.
        location_id: Emergency location ID.
        assignment_target_id: Assigned user or resource ID.

    Returns:
        Dictionary matching Graph API number assignment response format.
    """
    return {
        "id": number_id,
        "telephoneNumber": telephone_number,
        "numberType": number_type,
        "activationState": activation_state,
        "assignmentStatus": assignment_status,
        "capabilities": ["userAssignment"],
        "city": city,
        "locationId": location_id,
        "assignmentTargetId": assignment_target_id,
    }


class TestNumberServiceInit:
    """Tests for NumberService initialization."""

    @pytest.mark.unit
    def test_accepts_graph_client(self, mock_graph_client: MagicMock) -> None:
        """NumberService accepts GraphClient in constructor."""
        service = NumberService(mock_graph_client)

        assert service.graph_client is mock_graph_client


class TestNumberServiceListNumbers:
    """Tests for NumberService.list_numbers method."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_list_numbers_returns_empty_list(
        self, mock_graph_client: MagicMock
    ) -> None:
        """list_numbers returns empty list when no numbers exist."""

        async def mock_paginated(
            *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            return
            yield  # pragma: no cover - makes this an async generator

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        numbers = await service.list_numbers()

        assert numbers == []

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_list_numbers_returns_number_assignments(
        self, mock_graph_client: MagicMock
    ) -> None:
        """list_numbers returns list of NumberAssignment objects."""
        number_data = [
            make_number_dict("num-1", "+14255551001"),
            make_number_dict("num-2", "+14255551002"),
        ]

        async def mock_paginated(
            *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            for item in number_data:
                yield item

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        numbers = await service.list_numbers()

        assert len(numbers) == 2
        assert all(isinstance(n, NumberAssignment) for n in numbers)
        assert numbers[0].id == "num-1"
        assert numbers[1].id == "num-2"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_list_numbers_uses_correct_endpoint(
        self, mock_graph_client: MagicMock
    ) -> None:
        """list_numbers calls get_paginated with correct endpoint."""

        async def mock_paginated(
            endpoint: str, *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            assert (
                endpoint == "/admin/teams/telephoneNumberManagement/numberAssignments"
            )
            return
            yield  # pragma: no cover

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        await service.list_numbers()

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_list_numbers_with_status_filter(
        self, mock_graph_client: MagicMock
    ) -> None:
        """list_numbers passes status filter in OData $filter."""
        captured_params: dict[str, Any] = {}

        async def mock_paginated(
            endpoint: str, *, params: dict[str, Any] | None = None, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            captured_params.update(params or {})
            return
            yield  # pragma: no cover

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        await service.list_numbers(status=AssignmentStatus.UNASSIGNED)

        assert "$filter" in captured_params
        assert "assignmentStatus eq 'unassigned'" in captured_params["$filter"]

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_list_numbers_with_number_type_filter(
        self, mock_graph_client: MagicMock
    ) -> None:
        """list_numbers passes number_type filter in OData $filter."""
        captured_params: dict[str, Any] = {}

        async def mock_paginated(
            endpoint: str, *, params: dict[str, Any] | None = None, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            captured_params.update(params or {})
            return
            yield  # pragma: no cover

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        await service.list_numbers(number_type=NumberType.DIRECT_ROUTING)

        assert "$filter" in captured_params
        assert "numberType eq 'directRouting'" in captured_params["$filter"]

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_list_numbers_with_city_filter(
        self, mock_graph_client: MagicMock
    ) -> None:
        """list_numbers applies city filter client-side."""
        number_data = [
            make_number_dict("num-1", "+14255551001", city="Seattle"),
            make_number_dict("num-2", "+14255551002", city="Redmond"),
            make_number_dict("num-3", "+14255551003", city="Seattle"),
        ]

        async def mock_paginated(
            *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            for item in number_data:
                yield item

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        numbers = await service.list_numbers(city="Seattle")

        assert len(numbers) == 2
        assert all(n.city == "Seattle" for n in numbers)
        assert numbers[0].id == "num-1"
        assert numbers[1].id == "num-3"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_list_numbers_with_city_filter_no_odata(
        self, mock_graph_client: MagicMock
    ) -> None:
        """list_numbers does not include city in OData $filter."""
        captured_params: dict[str, Any] = {}

        async def mock_paginated(
            endpoint: str, *, params: dict[str, Any] | None = None, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            captured_params.update(params or {})
            return
            yield  # pragma: no cover

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        await service.list_numbers(city="Seattle")

        # City should NOT be in $filter - it's client-side only
        assert "$filter" not in captured_params

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_list_numbers_with_multiple_filters(
        self, mock_graph_client: MagicMock
    ) -> None:
        """list_numbers combines multiple filters with ' and '."""
        captured_params: dict[str, Any] = {}

        async def mock_paginated(
            endpoint: str, *, params: dict[str, Any] | None = None, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            captured_params.update(params or {})
            return
            yield  # pragma: no cover

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        await service.list_numbers(
            status=AssignmentStatus.USER_ASSIGNED, number_type=NumberType.CALLING_PLAN
        )

        assert "$filter" in captured_params
        filter_str = captured_params["$filter"]
        assert "assignmentStatus eq 'userAssigned'" in filter_str
        assert "numberType eq 'callingPlan'" in filter_str
        assert " and " in filter_str

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_list_numbers_with_page_size(
        self, mock_graph_client: MagicMock
    ) -> None:
        """list_numbers passes page_size as $top parameter."""
        captured_params: dict[str, Any] = {}

        async def mock_paginated(
            endpoint: str, *, params: dict[str, Any] | None = None, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            captured_params.update(params or {})
            return
            yield  # pragma: no cover

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        await service.list_numbers(page_size=50)

        assert captured_params["$top"] == "50"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_list_numbers_caps_page_size_at_999(
        self, mock_graph_client: MagicMock
    ) -> None:
        """list_numbers caps page_size at 999."""
        captured_params: dict[str, Any] = {}

        async def mock_paginated(
            endpoint: str, *, params: dict[str, Any] | None = None, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            captured_params.update(params or {})
            return
            yield  # pragma: no cover

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        await service.list_numbers(page_size=5000)

        assert captured_params["$top"] == "999"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_list_numbers_with_max_items(
        self, mock_graph_client: MagicMock
    ) -> None:
        """list_numbers passes max_items to get_paginated."""
        captured_kwargs: dict[str, Any] = {}

        async def mock_paginated(
            endpoint: str, *, params: dict[str, Any] | None = None, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            captured_kwargs.update(kwargs)
            return
            yield  # pragma: no cover

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        await service.list_numbers(max_items=25)

        assert captured_kwargs.get("max_items") == 25

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_list_numbers_default_page_size(
        self, mock_graph_client: MagicMock
    ) -> None:
        """list_numbers uses default page_size of 100."""
        captured_params: dict[str, Any] = {}

        async def mock_paginated(
            endpoint: str, *, params: dict[str, Any] | None = None, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            captured_params.update(params or {})
            return
            yield  # pragma: no cover

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        await service.list_numbers()

        assert captured_params["$top"] == "100"


class TestNumberServiceGetNumber:
    """Tests for NumberService.get_number method."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_get_number_returns_number_assignment(
        self, mock_graph_client: MagicMock
    ) -> None:
        """get_number returns NumberAssignment object."""
        number_data = make_number_dict("num-1", "+12065551234")

        async def mock_paginated(
            *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            yield number_data

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        result = await service.get_number("+12065551234")

        assert isinstance(result, NumberAssignment)
        assert result.id == "num-1"
        assert result.telephone_number == "+12065551234"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_get_number_normalizes_e164_input(
        self, mock_graph_client: MagicMock
    ) -> None:
        """get_number normalizes E.164 format input."""
        captured_params: dict[str, Any] = {}
        number_data = make_number_dict("num-1", "+12065551234")

        async def mock_paginated(
            endpoint: str, *, params: dict[str, Any] | None = None, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            captured_params.update(params or {})
            yield number_data

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        await service.get_number("+12065551234")

        assert captured_params["$filter"] == "telephoneNumber eq '+12065551234'"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_get_number_normalizes_digits_only_input(
        self, mock_graph_client: MagicMock
    ) -> None:
        """get_number normalizes digits-only input to E.164 format."""
        captured_params: dict[str, Any] = {}
        number_data = make_number_dict("num-1", "+12065551234")

        async def mock_paginated(
            endpoint: str, *, params: dict[str, Any] | None = None, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            captured_params.update(params or {})
            yield number_data

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        await service.get_number("12065551234")

        assert captured_params["$filter"] == "telephoneNumber eq '+12065551234'"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_get_number_normalizes_formatted_input(
        self, mock_graph_client: MagicMock
    ) -> None:
        """get_number normalizes formatted input to E.164 format."""
        captured_params: dict[str, Any] = {}
        number_data = make_number_dict("num-1", "+12065551234")

        async def mock_paginated(
            endpoint: str, *, params: dict[str, Any] | None = None, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            captured_params.update(params or {})
            yield number_data

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        await service.get_number("+1-206-555-1234")

        assert captured_params["$filter"] == "telephoneNumber eq '+12065551234'"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_get_number_uses_correct_endpoint(
        self, mock_graph_client: MagicMock
    ) -> None:
        """get_number calls get_paginated with correct endpoint."""
        captured_endpoint: str = ""
        number_data = make_number_dict("num-1", "+12065551234")

        async def mock_paginated(
            endpoint: str, *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            nonlocal captured_endpoint
            captured_endpoint = endpoint
            yield number_data

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        await service.get_number("+12065551234")

        assert (
            captured_endpoint
            == "/admin/teams/telephoneNumberManagement/numberAssignments"
        )

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_get_number_uses_correct_filter(
        self, mock_graph_client: MagicMock
    ) -> None:
        """get_number uses telephoneNumber eq filter."""
        captured_params: dict[str, Any] = {}
        number_data = make_number_dict("num-1", "+14255559999")

        async def mock_paginated(
            endpoint: str, *, params: dict[str, Any] | None = None, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            captured_params.update(params or {})
            yield number_data

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        await service.get_number("+14255559999")

        assert "$filter" in captured_params
        assert captured_params["$filter"] == "telephoneNumber eq '+14255559999'"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_get_number_raises_not_found_for_missing_number(
        self, mock_graph_client: MagicMock
    ) -> None:
        """get_number raises NotFoundError when number not found."""

        async def mock_paginated(
            *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            return
            yield  # pragma: no cover - makes this an async generator

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        with pytest.raises(NotFoundError) as exc_info:
            await service.get_number("+12065559999")

        assert "+12065559999" in str(exc_info.value)
        assert exc_info.value.remediation is not None
        assert "teams-phone numbers list" in exc_info.value.remediation

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_get_number_passes_max_items_one(
        self, mock_graph_client: MagicMock
    ) -> None:
        """get_number passes max_items=1 to get_paginated."""
        captured_kwargs: dict[str, Any] = {}
        number_data = make_number_dict("num-1", "+12065551234")

        async def mock_paginated(
            endpoint: str, *, params: dict[str, Any] | None = None, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            captured_kwargs.update(kwargs)
            yield number_data

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        await service.get_number("+12065551234")

        assert captured_kwargs.get("max_items") == 1


class TestNumberServiceSearchNumbers:
    """Tests for NumberService.search_numbers method."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_search_numbers_prefix_pattern(
        self, mock_graph_client: MagicMock
    ) -> None:
        """search_numbers matches prefix patterns (206*)."""
        number_data = [
            make_number_dict("num-1", "+12065551001"),
            make_number_dict("num-2", "+14255551002"),
            make_number_dict("num-3", "+12065551003"),
        ]

        async def mock_paginated(
            *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            for item in number_data:
                yield item

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        results = await service.search_numbers("206*")

        assert len(results) == 2
        assert all("206" in r.telephone_number for r in results)
        assert results[0].id == "num-1"
        assert results[1].id == "num-3"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_search_numbers_suffix_pattern(
        self, mock_graph_client: MagicMock
    ) -> None:
        """search_numbers matches suffix patterns (*1234)."""
        number_data = [
            make_number_dict("num-1", "+12065551234"),
            make_number_dict("num-2", "+14255555678"),
            make_number_dict("num-3", "+13035551234"),
        ]

        async def mock_paginated(
            *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            for item in number_data:
                yield item

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        results = await service.search_numbers("*1234")

        assert len(results) == 2
        assert all(r.telephone_number.endswith("1234") for r in results)
        assert results[0].id == "num-1"
        assert results[1].id == "num-3"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_search_numbers_contains_pattern(
        self, mock_graph_client: MagicMock
    ) -> None:
        """search_numbers matches contains patterns (*555*)."""
        number_data = [
            make_number_dict("num-1", "+12065551234"),
            make_number_dict("num-2", "+14256661002"),
            make_number_dict("num-3", "+13035559999"),
        ]

        async def mock_paginated(
            *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            for item in number_data:
                yield item

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        results = await service.search_numbers("*555*")

        assert len(results) == 2
        assert all("555" in r.telephone_number for r in results)
        assert results[0].id == "num-1"
        assert results[1].id == "num-3"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_search_numbers_exact_substring(
        self, mock_graph_client: MagicMock
    ) -> None:
        """search_numbers matches exact substring patterns (no wildcards)."""
        number_data = [
            make_number_dict("num-1", "+12065551234"),
            make_number_dict("num-2", "+14255551002"),
            make_number_dict("num-3", "+13036661234"),
        ]

        async def mock_paginated(
            *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            for item in number_data:
                yield item

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        results = await service.search_numbers("1234")

        assert len(results) == 2
        assert results[0].id == "num-1"
        assert results[1].id == "num-3"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_search_numbers_empty_pattern_returns_empty(
        self, mock_graph_client: MagicMock
    ) -> None:
        """search_numbers returns empty list for empty pattern."""
        number_data = [
            make_number_dict("num-1", "+12065551234"),
        ]

        async def mock_paginated(
            *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            for item in number_data:
                yield item

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        results = await service.search_numbers("")

        assert results == []

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_search_numbers_no_matches(
        self, mock_graph_client: MagicMock
    ) -> None:
        """search_numbers returns empty list when no numbers match."""
        number_data = [
            make_number_dict("num-1", "+12065551234"),
            make_number_dict("num-2", "+14255551002"),
        ]

        async def mock_paginated(
            *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            for item in number_data:
                yield item

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        results = await service.search_numbers("999*")

        assert results == []

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_search_numbers_max_results_limits_output(
        self, mock_graph_client: MagicMock
    ) -> None:
        """search_numbers respects max_results parameter."""
        number_data = [
            make_number_dict("num-1", "+12065551001"),
            make_number_dict("num-2", "+12065551002"),
            make_number_dict("num-3", "+12065551003"),
            make_number_dict("num-4", "+12065551004"),
            make_number_dict("num-5", "+12065551005"),
        ]

        async def mock_paginated(
            *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            for item in number_data:
                yield item

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        results = await service.search_numbers("206*", max_results=3)

        assert len(results) == 3
        assert results[0].id == "num-1"
        assert results[1].id == "num-2"
        assert results[2].id == "num-3"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_search_numbers_default_max_results(
        self, mock_graph_client: MagicMock
    ) -> None:
        """search_numbers uses default max_results of 100."""
        # Create 150 numbers
        number_data = [
            make_number_dict(f"num-{i}", f"+1206555{1000 + i}") for i in range(150)
        ]

        async def mock_paginated(
            *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            for item in number_data:
                yield item

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        results = await service.search_numbers("206*")

        assert len(results) == 100

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_search_numbers_wildcard_only_matches_all(
        self, mock_graph_client: MagicMock
    ) -> None:
        """search_numbers with '*' pattern matches all numbers."""
        number_data = [
            make_number_dict("num-1", "+12065551001"),
            make_number_dict("num-2", "+14255551002"),
            make_number_dict("num-3", "+13035551003"),
        ]

        async def mock_paginated(
            *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            for item in number_data:
                yield item

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        results = await service.search_numbers("*")

        assert len(results) == 3

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_search_numbers_returns_number_assignment_objects(
        self, mock_graph_client: MagicMock
    ) -> None:
        """search_numbers returns list of NumberAssignment objects."""
        number_data = [
            make_number_dict("num-1", "+12065551234"),
        ]

        async def mock_paginated(
            *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            for item in number_data:
                yield item

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        results = await service.search_numbers("206*")

        assert len(results) == 1
        assert isinstance(results[0], NumberAssignment)
        assert results[0].id == "num-1"
        assert results[0].telephone_number == "+12065551234"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_search_numbers_empty_inventory(
        self, mock_graph_client: MagicMock
    ) -> None:
        """search_numbers returns empty list when inventory is empty."""

        async def mock_paginated(
            *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            return
            yield  # pragma: no cover - makes this an async generator

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        results = await service.search_numbers("206*")

        assert results == []

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_search_numbers_calls_list_numbers(
        self, mock_graph_client: MagicMock
    ) -> None:
        """search_numbers fetches numbers via list_numbers."""
        captured_endpoint: str = ""

        async def mock_paginated(
            endpoint: str, *args: Any, **kwargs: Any
        ) -> AsyncIterator[dict[str, Any]]:
            nonlocal captured_endpoint
            captured_endpoint = endpoint
            return
            yield  # pragma: no cover

        mock_graph_client.get_paginated = mock_paginated

        service = NumberService(mock_graph_client)
        await service.search_numbers("206*")

        assert (
            captured_endpoint
            == "/admin/teams/telephoneNumberManagement/numberAssignments"
        )
