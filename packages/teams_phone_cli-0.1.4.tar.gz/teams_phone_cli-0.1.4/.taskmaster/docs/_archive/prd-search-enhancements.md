# PRD: Search Enhancements Release

**Version:** 1.0
**Date:** 2026-02-02
**Author:** Claude Code
**Status:** Draft

---

## 1. Executive Summary

Teams Phone CLI search commands have inconsistent behavior (case sensitivity, pattern support) and lack key features like finding numbers by user assignment. This release delivers 5 targeted enhancements to unify search behavior and add high-value lookup capabilities, improving admin efficiency for phone inventory management.

---

## 2. Problem Statement

### Current Situation

Teams Phone administrators use the CLI to manage phone number inventory, user assignments, and location data. The current search implementation has evolved organically, resulting in:

- **Inconsistent filtering:** `numbers list --city` is case-sensitive while `locations list --city` is case-insensitive
- **Missing patterns:** Only `numbers search` supports wildcards; users expect `users search "Jo*"` to work
- **No reverse lookup:** Finding all numbers assigned to a user requires multiple commands (`users show` → manual lookup)
- **Exact-match friction:** List filters require exact matches; users expect `--city Sea` to find "Seattle"
- **Silent large fetches:** Pattern searches fetch entire inventory without feedback, causing confusion

### User Impact

- **IT Administrators** waste time running multiple commands for common lookups
- **Muscle memory breaks** when filters behave differently across commands
- **Help desk staff** cannot quickly answer "what numbers does user X have?"

### Business Impact

- Reduced CLI adoption due to friction
- Increased support burden from inconsistent behavior
- Slower incident response when lookups require multiple steps

### Why Now

This is the first dedicated release after the core MVP. Users have provided feedback on these gaps, and addressing them now prevents technical debt from accumulating.

---

## 3. Goals & Success Metrics

| Goal | Metric | Baseline | Target | Timeframe |
|------|--------|----------|--------|-----------|
| Feature completeness | All 5 enhancements merged with tests | 0/5 | 5/5 | Release |
| Consistency achieved | Case-insensitive filters | 1 command inconsistent | 0 inconsistencies | Release |
| Pattern support parity | Commands supporting wildcards | 1 (numbers search) | 3 (+ users, locations) | Release |
| Reverse lookup enabled | `--assigned-to` filter available | Not available | Available in numbers commands | Release |
| Test coverage maintained | Unit test coverage | Current baseline | ≥ Current baseline | Release |

---

## 4. User Stories

### US-001: Case-Insensitive City Filter

**As a** Teams Phone administrator
**I want** the `--city` filter to match regardless of case
**So that** I don't have to remember the exact capitalization of city names

**Acceptance Criteria:**
- [ ] `numbers list --city seattle` matches "Seattle"
- [ ] `numbers list --city SEATTLE` matches "Seattle"
- [ ] `numbers list --city SeAtTlE` matches "Seattle"
- [ ] Existing exact-case matches continue to work
- [ ] Help text does not change (case-insensitivity is default expectation)

**Implementation Tasks:**
- Update city comparison in `NumberService.list_numbers()` to use `.lower()`

---

### US-002: Performance Warnings for Large Searches

**As a** Teams Phone administrator
**I want** feedback when a search will process many items
**So that** I understand why a command takes time and know it's working

**Acceptance Criteria:**
- [ ] When fetching >1000 items for client-side filtering, display warning
- [ ] Warning shows count: "Filtering 5,234 numbers for pattern matching..."
- [ ] Warning appears before filtering begins, not after
- [ ] `--quiet` flag suppresses the warning
- [ ] Warning goes to stderr, not stdout (doesn't break piping)

**Implementation Tasks:**
- Add count check after pagination completes in search commands
- Add `--quiet` flag to relevant commands
- Use `console.print(..., stderr=True)` for warnings

---

### US-003: Numbers Search by Assignment

**As a** Teams Phone administrator
**I want** to find all numbers assigned to a specific user
**So that** I can audit assignments or troubleshoot user issues in one command

**Acceptance Criteria:**
- [ ] `numbers list --assigned-to john@contoso.com` returns numbers assigned to that user
- [ ] Accepts UPN, display name, or user ID as input
- [ ] Returns empty list (not error) if user has no numbers
- [ ] Returns clear error if user not found
- [ ] Works in combination with other filters (`--status`, `--type`, `--city`)

**Implementation Tasks:**
- Add `--assigned-to` option to `numbers list` command
- Resolve user via `UserService` (reuse existing resolution logic)
- Filter numbers by `assignedTo.id` matching resolved user ID
- Add unit tests for user resolution + number filtering

---

### US-004: Wildcard Support for Locations Search

**As a** Teams Phone administrator
**I want** to use wildcard patterns in location searches
**So that** I can find locations with patterns like "Main*" or "*HQ"

**Acceptance Criteria:**
- [ ] `locations search "Main*"` matches "Main Office", "Main Street"
- [ ] `locations search "*HQ"` matches "Seattle HQ", "NYC HQ"
- [ ] `locations search "*central*"` matches "Central Office", "NY Central"
- [ ] Pattern applies to all searchable fields (description, city, address)
- [ ] Existing substring search remains default when no wildcards present
- [ ] Help text documents wildcard support with examples

**Implementation Tasks:**
- Import `match_pattern()` from `utils.py` into location search
- Detect wildcard presence (`*` in query)
- Apply pattern matching when wildcards detected, substring otherwise
- Update command help text

---

### US-005: Wildcard Support for Users Search

**As a** Teams Phone administrator
**I want** to use wildcard patterns in user searches
**So that** I can find users matching patterns like "Jo*" or "*admin*"

**Acceptance Criteria:**
- [ ] `users search "Jo*"` matches "John Smith", "Joanna Chen"
- [ ] `users search "*admin*"` matches users with "admin" in display name
- [ ] Pattern applies to display name (primary search field)
- [ ] Existing auto-detection (phone vs UPN vs name) continues to work for non-wildcard queries
- [ ] Help text documents wildcard support with examples

**Implementation Tasks:**
- Detect wildcard in query before routing decision
- If wildcard detected, fetch broader result set and apply `match_pattern()` client-side
- Preserve existing server-side `startsWith` optimization when possible
- Update command help text

---

### US-006: Partial Matching for List Filters

**As a** Teams Phone administrator
**I want** list command filters to support partial/substring matching
**So that** I can use `--city Sea` to find "Seattle" without typing the full name

**Acceptance Criteria:**
- [ ] `numbers list --city Sea --contains` matches "Seattle"
- [ ] `locations list --city New --contains` matches "New York", "New Jersey"
- [ ] `--contains` flag enables substring matching (opt-in, not default)
- [ ] Works with all string-type filters across list commands
- [ ] Without `--contains`, exact match behavior preserved (backward compatible)
- [ ] Help text explains the `--contains` flag

**Implementation Tasks:**
- Add `--contains` flag to list commands with string filters
- Update filter logic to use `in` comparison when flag set
- Ensure case-insensitive partial matching
- Add tests for partial match scenarios

---

## 5. Functional Requirements

| ID | Requirement | Priority | Notes |
|----|-------------|----------|-------|
| REQ-001 | City filter in `numbers list` SHALL perform case-insensitive comparison | Must | Single line change |
| REQ-002 | Search commands SHALL display warning when filtering >1000 items locally | Should | Threshold configurable via constant |
| REQ-003 | `--quiet` flag SHALL suppress performance warnings | Should | Standard CLI pattern |
| REQ-004 | `numbers list` SHALL accept `--assigned-to` option with user identifier | Must | High-value feature |
| REQ-005 | `--assigned-to` SHALL resolve UPN, display name, or user GUID | Must | Reuse UserService resolution |
| REQ-006 | `--assigned-to` SHALL return empty list when user has no numbers | Must | Not an error condition |
| REQ-007 | `locations search` SHALL support `*` wildcard patterns | Must | Use existing `match_pattern()` |
| REQ-008 | `locations search` SHALL default to substring when no wildcards present | Must | Backward compatible |
| REQ-009 | `users search` SHALL support `*` wildcard patterns in display name | Must | Client-side filtering |
| REQ-010 | `users search` SHALL preserve server-side optimization for non-wildcard queries | Should | Performance consideration |
| REQ-011 | List commands SHALL accept `--contains` flag for substring matching | Should | Opt-in partial matching |
| REQ-012 | All filter changes SHALL maintain backward compatibility | Must | Existing scripts must work |
| REQ-013 | All new options SHALL include help text with examples | Must | Discoverability |

---

## 6. Non-Functional Requirements

### Performance

| Metric | Target | Rationale |
|--------|--------|-----------|
| Warning threshold | 1000 items | Balances feedback vs noise |
| User resolution latency | < 500ms p95 | Single Graph API call |
| Pattern matching overhead | < 100ms for 10K items | Regex is fast |

### Compatibility

- Python 3.10+ (existing requirement)
- No new dependencies required
- All changes additive (no breaking changes)

### Security

- No new authentication requirements
- `--assigned-to` reuses existing user lookup permissions
- No sensitive data in warning messages

### Reliability

- Failed user resolution for `--assigned-to` returns clear error with exit code 4 (NotFoundError)
- Malformed wildcard patterns handled gracefully (treated as literal)

---

## 7. Technical Considerations

### Architecture

Changes are localized to existing service and CLI layers:

```
src/teams_phone/
├── cli/
│   ├── numbers.py    # Add --assigned-to, --contains, --quiet
│   ├── users.py      # Wildcard detection in search
│   └── locations.py  # Wildcard detection in search
├── services/
│   ├── number_service.py   # Add user resolution, case-insensitive city
│   ├── user_service.py     # Add wildcard pattern matching
│   └── location_service.py # Add wildcard pattern matching
└── utils.py          # Existing match_pattern() - no changes
```

### API Constraints (Graph API)

| Capability | Server-Side | Client-Side | Impact |
|------------|-------------|-------------|--------|
| Wildcard patterns | ❌ Not supported | ✅ Use `match_pattern()` | Fetch all, filter locally |
| City filter | ❌ Not supported | ✅ Post-process | Already client-side |
| Case-insensitive text | ❌ Limited | ✅ `.lower()` comparison | No API change |
| User by ID | ✅ Supported | - | Efficient lookup |

### Implementation Patterns

**Case-Insensitive Fix (REQ-001):**
```python
# Before
if city and number.city != city:
    continue

# After
if city and number.city.lower() != city.lower():
    continue
```

**Wildcard Detection:**
```python
from teams_phone.utils import match_pattern

def has_wildcard(query: str) -> bool:
    return "*" in query

# In search method
if has_wildcard(query):
    # Fetch broader set, apply pattern client-side
    results = [item for item in all_items if match_pattern(item.name, query)]
else:
    # Use existing optimized path
    results = await self._server_side_search(query)
```

**Warning Output:**
```python
if len(items) > LARGE_RESULT_THRESHOLD and not quiet:
    console.print(
        f"Filtering {len(items):,} items for pattern matching...",
        style="yellow",
        stderr=True
    )
```

### Testing Strategy

| Test Type | Coverage |
|-----------|----------|
| Unit tests | Each new filter option with mock data |
| Edge cases | Empty results, special characters in patterns, very long city names |
| Integration | `--assigned-to` with real Graph API (contract test) |
| Regression | Existing filter behavior unchanged |

---

## 8. Implementation Roadmap

### Phase 1: Quick Wins (1-2 tasks)

| Task | Depends On | Complexity |
|------|------------|------------|
| REQ-001: Case-insensitive city filter | None | Low |
| REQ-002/003: Performance warnings + --quiet | None | Low |

### Phase 2: High-Value Feature (2-3 tasks)

| Task | Depends On | Complexity |
|------|------------|------------|
| REQ-004/005/006: --assigned-to filter | None | Medium |
| Unit tests for user resolution + filtering | REQ-004 | Low |

### Phase 3: Wildcard Consistency (2-3 tasks)

| Task | Depends On | Complexity |
|------|------------|------------|
| REQ-007/008: Locations wildcard support | None | Low |
| REQ-009/010: Users wildcard support | None | Medium |
| Update help text for wildcards | REQ-007, REQ-009 | Low |

### Phase 4: Partial Matching (1-2 tasks)

| Task | Depends On | Complexity |
|------|------------|------------|
| REQ-011: --contains flag implementation | None | Medium |
| REQ-012/013: Help text and backward compat verification | REQ-011 | Low |

### Suggested Sequence

1. Case-insensitive city (quick win, builds confidence)
2. --assigned-to filter (high value, unblocks common use case)
3. Locations wildcard (easier, validates pattern)
4. Users wildcard (more complex, builds on locations)
5. Performance warnings (polish)
6. --contains flag (additive, lower priority)

---

## 9. Out of Scope

The following are explicitly **NOT** included in this release:

| Item | Reason | Future Consideration |
|------|--------|---------------------|
| Cross-entity global search | Significant complexity, deserves own release | Next release candidate |
| Search result caching | Optimization, not core functionality | Future enhancement |
| Saved searches / aliases | Power user feature, low priority | Future enhancement |
| Interactive search mode | High effort TUI work | Unlikely near-term |
| JMESPath query filtering | Adds dependency, niche use case | Evaluate demand |
| CSV/JSON export formats | Separate concern from search | Different release |

---

## 10. Open Questions & Risks

### Open Questions

| Question | Owner | Status |
|----------|-------|--------|
| Should `--contains` be the default in future major version? | Product | Open |
| Should warnings be configurable via config file? | Engineering | Open |
| Should wildcards work in `--assigned-to` value? | Product | Recommend: No |

### Risks

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Graph API beta changes break user resolution | Low | Medium | Contract tests detect changes |
| Performance regression for large inventories | Low | Medium | Warn users, maintain existing pagination |
| Users expect wildcards to work server-side (faster) | Medium | Low | Document client-side behavior in help |

---

## 11. Validation Checkpoints

### Milestone 1: Quick Wins Complete
- [ ] Case-insensitive city filter merged
- [ ] All existing tests pass
- [ ] Manual verification: `numbers list --city seattle` works

### Milestone 2: Assignment Lookup Complete
- [ ] `--assigned-to` filter merged
- [ ] User resolution works for UPN, name, and ID
- [ ] Empty result handled gracefully
- [ ] Manual verification with real user

### Milestone 3: Wildcard Parity Complete
- [ ] Locations wildcard support merged
- [ ] Users wildcard support merged
- [ ] Help text updated
- [ ] Manual verification: `locations search "Main*"` works

### Milestone 4: Release Ready
- [ ] All 5 enhancements merged
- [ ] Performance warnings implemented
- [ ] `--contains` flag implemented
- [ ] Full test suite passes
- [ ] Help text complete for all new options

---

## Appendix: Current vs Enhanced Behavior

| Command | Current | Enhanced |
|---------|---------|----------|
| `numbers list --city seattle` | ❌ No match (case-sensitive) | ✅ Matches "Seattle" |
| `numbers list --assigned-to john@co.com` | ❌ Not available | ✅ Returns John's numbers |
| `locations search "Main*"` | ⚠️ Literal search for "Main*" | ✅ Wildcard match |
| `users search "Jo*"` | ⚠️ Searches for literal "Jo*" | ✅ Wildcard match |
| `numbers list --city Sea --contains` | ❌ Not available | ✅ Partial match "Seattle" |
| Large pattern search | Silent fetching | ⚠️ Warning displayed |
