# Product Requirements Document: Batch Migration Feature

**Version:** 1.2
**Date:** 2026-02-03
**Author:** Generated with Claude Code
**Status:** Draft - Revised

---

## 1. Executive Summary

The batch migration feature enables Teams Phone administrators to execute bulk number assignments with persistent job tracking, pre-flight validation, and automated failure recovery. This eliminates the manual, error-prone process of assigning hundreds of phone numbers individually, reducing migration time by 80%+ while providing complete visibility into job state across multiple iteration cycles.

---

## 2. Problem Statement

### Current Situation

Teams Phone administrators currently manage bulk number assignments through a combination of manual CLI commands, spreadsheet tracking, and ad-hoc file management. When assigning hundreds of numbers:

1. **Manual execution** - Each assignment requires individual command invocation
2. **No pre-flight validation** - Issues discovered only at execution time
3. **File chaos** - Multiple CSV files (original, failed-v1, failed-v2, etc.) with unclear naming
4. **Lost state** - No persistent record of what ran, what succeeded, what failed
5. **Painful iteration** - Resolving failures requires manual CSV editing and re-running

### User Impact

| User | Pain Point |
|------|------------|
| Teams Phone Admins | Hours spent on repetitive tasks; anxiety about losing track of progress |
| MSPs/Consultants | Reduced billable efficiency; client frustration with migration timelines |

### Business Impact

- **Time cost**: 4-8 hours manual work for a 500-number migration vs. potential 1-hour automated process
- **Error rate**: 10-20% preventable failures due to lack of validation (typos, unlicensed users, wrong formats)
- **Rework**: Average of 2-3 iteration cycles per migration due to poor tooling
- **Risk**: Lost state can mean duplicate assignments or missed numbers

### Why Solve This Now

The CLI already has the foundational services (UserService, NumberService, GraphClient) and async patterns needed. Adding batch orchestration builds on existing capabilities with high ROI. Users are actively requesting this functionality.

---

## 3. Goals & Success Metrics

| Goal | Metric | Baseline | Target | Timeframe |
|------|--------|----------|--------|-----------|
| Reduce migration time | Time to complete 500-number migration | 4-8 hours (manual) | < 1 hour (automated) | Per migration |
| Improve first-pass success rate | % of items succeeding on first batch run | ~80% (no validation) | > 95% (with validation) | Per batch |
| Eliminate state loss | # of migrations with lost/confused state | Common occurrence | 0 (persistent jobs) | Ongoing |
| Reduce iteration cycles | Average cycles to complete migration | 2-3 cycles | 1-2 cycles | Per migration |
| Catch errors pre-flight | % of preventable errors caught before execution | 0% | > 90% | Per batch |

---

## 4. User Stories

### US-001: Create a Migration Job

**As a** Teams Phone administrator
**I want to** create a batch job from a CSV file
**So that I can** track my migration as a persistent entity rather than loose files

**Acceptance Criteria:**
- [ ] CLI accepts a CSV file path and creates a named job
- [ ] Job is persisted to `.teams-phone/jobs/<job-id>/` directory
- [ ] Job metadata includes: name, creation time, input file hash, item count
- [ ] Invalid CSV format returns clear error message with line numbers
- [ ] Duplicate job names are allowed (job-id is unique)

**Implementation Tasks:**
- Define Job Pydantic model with all required fields
- Implement CSV parser with schema validation
- Create job storage service (JSON file persistence)
- Add `batch create` CLI command

---

### US-002: Validate Before Execution

**As a** Teams Phone administrator
**I want to** validate my batch before running it
**So that I can** catch preventable errors and fix them upfront

**Acceptance Criteria:**
- [ ] Validation checks: user exists, number exists in tenant, number is unassigned (or assigned to expected user), phone number format is valid
- [ ] Optional license validation with `--check-licenses` flag: user has Teams Phone license
- [ ] Validation report shows: total items, valid count, invalid count, issues by category
- [ ] Each validation issue includes: line number, field, value, error message, suggested fix
- [ ] Validation can be re-run after fixing input CSV
- [ ] Validation does NOT make any changes to tenant

**Implementation Tasks:**
- Implement validation service with pluggable validators
- Add user existence/license check via Graph API
- Add number existence/assignment check via Graph API
- Add phone number format validation (E.164)
- Create validation report formatter
- Add `batch validate` CLI command

---

### US-003: Execute Batch with Progress Tracking

**As a** Teams Phone administrator
**I want to** run my validated batch with real-time progress
**So that I can** monitor execution and know when it completes

**Acceptance Criteria:**
- [ ] Execution processes items with configurable concurrency (default: 3, flag: `--concurrency`)
- [ ] Progress displayed: current/total, success/fail counts, estimated time remaining
- [ ] Each item result is persisted immediately (crash-safe)
- [ ] Rate limiting (429) is handled automatically with backoff
- [ ] Execution can be interrupted (Ctrl+C) gracefully with state preserved
- [ ] On resume, progress bar continues from last completed count (not reset to zero)
- [ ] Terminal output shows: "Resuming job: 45/500 items completed" when resuming

**Implementation Tasks:**
- Implement batch executor with asyncio semaphore for concurrency control
- Add progress tracking with rich/click progress bar
- Persist item results incrementally to job state with atomic writes
- Implement execution.log persistence with timestamps
- Handle SIGINT for graceful shutdown (set status to INTERRUPTED)
- Add `batch run` CLI command with `--concurrency` and `--dry-run` flags

---

### US-004: Retry Failed Items

**As a** Teams Phone administrator
**I want to** retry only the failed items from a previous run
**So that I can** iterate efficiently without re-processing successes

**Acceptance Criteria:**
- [ ] Retry command identifies failed items from job state
- [ ] Only failed items are re-processed
- [ ] New results update job state (failed -> success or failed -> failed with new error)
- [ ] Retry count is tracked per item
- [ ] Items that fail 3+ times are flagged for manual review

**Implementation Tasks:**
- Add retry logic to batch executor (filter by status=FAILED)
- Add resume logic to batch executor (continue from last state, process in_progress + pending)
- Track attempt count per item in job state
- Add `batch retry` CLI command (failed items only)
- Add `batch resume` CLI command (interrupted jobs)
- Add "needs_review" status for items with 3+ failed attempts

---

### US-005: Export Job Results

**As a** Teams Phone administrator
**I want to** export failed items as a new CSV
**So that I can** share with colleagues or use with other tools

**Acceptance Criteria:**
- [ ] Export generates CSV with same base columns as input (user_upn, phone_number)
- [ ] Export options: `--failed`, `--succeeded`, `--all`
- [ ] Failed item exports include additional columns: error_code, error_message, attempts
- [ ] Succeeded/all exports can be re-imported (error columns ignored on import)
- [ ] Export file path is configurable (default: `<job-name>-<filter>.csv`)

**Implementation Tasks:**
- Implement CSV export service
- Add error column for failed items
- Add `batch export` CLI command

---

### US-006: View Job Status and History

**As a** Teams Phone administrator
**I want to** see the status of my jobs
**So that I can** track progress and find past migrations

**Acceptance Criteria:**
- [ ] `batch status` (no args) lists all jobs with summary stats
- [ ] `batch status <job-id>` shows detailed job information
- [ ] Status includes: created, last run, total/success/failed/pending counts
- [ ] Jobs are retained for 30 days (configurable)
- [ ] Old jobs can be manually deleted

**Implementation Tasks:**
- Implement job listing with summary stats
- Implement detailed job view
- Add job retention/cleanup logic
- Add `batch status` and `batch delete` CLI commands

---

## 5. Functional Requirements

### Core Job Management

| ID | Requirement | Priority | Notes |
|----|-------------|----------|-------|
| REQ-001 | System SHALL create batch jobs from CSV input files | Must | CSV schema: `user_upn,phone_number` minimum |
| REQ-002 | System SHALL persist job state to `.teams-phone/jobs/` directory | Must | JSON format, one directory per job |
| REQ-003 | System SHALL generate unique job IDs using format: YYYYMMDD-HHMMSS-{random4}-{name-slug} | Must | Example: `20260203-143015-a1b2-q1-migration`. Random 4-char hex suffix prevents collision. |
| REQ-004 | System SHALL allow optional job naming for user reference | Should | Default: input filename (slugified) |
| REQ-005 | System SHALL track job metadata: created_at, updated_at, status, item_count | Must | |
| REQ-006 | System SHALL prevent multiple jobs from running concurrently using lock file | Must | Prevents rate limit conflicts and state corruption |
| REQ-007 | System SHALL return clear error if attempting to run while another job is active | Must | Exit code 13, show active job ID |

**Command → Job Status Matrix:**

| Command | Valid Source Statuses | Result Status | Notes |
|---------|----------------------|---------------|-------|
| `batch validate` | CREATED | VALIDATED (or CREATED if errors) | First validation |
| `batch validate` | VALIDATED | VALIDATED | Re-validate (e.g., after tenant changes) |
| `batch run` | VALIDATED | RUNNING → COMPLETED | First execution |
| `batch resume` | INTERRUPTED | RUNNING → COMPLETED | Continue from saved state |
| `batch retry` | COMPLETED | RUNNING → COMPLETED | Re-process FAILED items only |
| `batch export` | VALIDATED, COMPLETED, INTERRUPTED | N/A | Export available after validation |
| `batch status` | Any | N/A | Always allowed |
| `batch delete` | Any | N/A | Always allowed |

Note: To change input CSV, create a new job. Job input is immutable after creation.

### Validation

| ID | Requirement | Priority | Notes |
|----|-------------|----------|-------|
| REQ-010 | System SHALL validate phone number format (E.164) | Must | Use existing `normalize_phone_number` util |
| REQ-011 | System SHALL validate user exists via Graph API | Must | Individual lookup per user |
| REQ-012 | System SHALL validate user has Teams Phone license | Could | Opt-in with `--check-licenses` flag (adds latency) |
| REQ-013 | System SHALL validate phone number exists in tenant | Must | Via NumberService |
| REQ-014 | System SHALL treat phone number already assigned to target user as SUCCESS | Must | Idempotent behavior for retries |
| REQ-015 | System SHALL report validation errors with line numbers and suggested fixes | Must | |
| REQ-016 | System SHALL support `--strict` mode that fails on any warning | Could | Default: report warnings, continue |
| REQ-017 | System SHALL validate CSV has required headers (user_upn, phone_number) | Must | Fail with clear error if headers missing |
| REQ-018 | System SHALL detect and reject duplicate phone numbers within batch | Must | Prevent double-assignment attempts |
| REQ-019 | System SHALL detect and reject duplicate user assignments within batch | Must | Prevent assigning multiple numbers to same user |
| REQ-020 | System SHALL ignore empty lines and tolerate extra columns in CSV | Must | Flexible parsing for real-world data |
| REQ-020a | System SHALL handle CRLF, LF, and CR line endings in CSV | Must | Excel/Windows compatibility |
| REQ-020b | System SHALL reject rows with empty user_upn or phone_number values | Must | Report line number and column |
| REQ-020c | System SHALL strip phone number extensions (;ext=NNN) and warn user | Should | E.164 does not include extensions |

**Validation Strategy:**

The system implements two-phase validation to balance pre-flight error detection with runtime safety:

- **Pre-flight validation** (`batch validate`): Checks user existence, number availability, phone number format. Provides early feedback before execution.
- **Runtime validation** (during `batch run`): Re-checks number availability immediately before assignment to prevent TOCTOU (Time-of-Check-Time-of-Use) race conditions.
- **Rationale**: State may change between `validate` and `run` (minutes or hours apart). Runtime re-validation ensures consistency without blocking pre-flight reporting.

**Validation Result Persistence:**
- Pre-flight validation results are persisted to job.json (job status → VALIDATED or remains CREATED if errors)
- Validation errors are stored per-item in `JobItem.error_code` and `JobItem.error_message`
- Items with validation errors have status=FAILED before execution begins
- Console output shows summary; `batch status <job-id>` shows full details

### Execution

| ID | Requirement | Priority | Notes |
|----|-------------|----------|-------|
| REQ-021 | System SHALL execute number assignments via existing NumberService | Must | Reuse existing Graph integration |
| REQ-022 | System SHALL support configurable concurrency (1-10 concurrent) | Must | Default: 3. Max 10 to avoid overwhelming Graph API (empirical limit before consistent 429s). |
| REQ-023 | System SHALL support `--dry-run` mode that simulates execution without API calls | Must | Critical for testing before production runs |
| REQ-024 | System SHALL handle Graph API 429 responses with exponential backoff | Must | Existing retry logic |
| REQ-025 | System SHALL poll async operations (202 responses) to completion with 10-minute timeout | Must | Existing pattern in GraphClient. Timeout exceeded = FAILED with TIMEOUT error code. |
| REQ-026 | System SHALL persist item results immediately after each completion | Must | Crash-safe state |
| REQ-027 | System SHALL persist execution log with timestamps, item IDs, API responses | Must | For debugging and audit trail |
| REQ-028 | System SHALL display progress: items completed, success/fail counts, ETA | Must | Real-time feedback |
| REQ-029 | System SHALL handle graceful interruption (Ctrl+C) preserving state | Must | Set status to INTERRUPTED |
| REQ-030 | System SHALL skip already-succeeded items when re-running completed jobs | Must | Only re-process failed/pending items |

### Retry and Recovery

| ID | Requirement | Priority | Notes |
|----|-------------|----------|-------|
| REQ-031 | System SHALL support `batch retry` to re-process only items with status=FAILED | Must | Core iteration workflow |
| REQ-032 | System SHALL support `batch resume` to continue interrupted jobs from last state | Must | Treats IN_PROGRESS items as PENDING (safe due to idempotency) |
| REQ-033 | System SHALL track retry attempt count per item | Must | Stored in JobItem.attempts |
| REQ-034 | System SHALL flag items failing 3+ times as "needs_review" | Should | Prevent infinite retry loops |
| REQ-035 | System SHALL treat network failures as transient errors (retry with backoff) | Must | Network-safe execution |
| REQ-036 | System SHALL persist state before and after each API call | Must | Recovery from network interruption |
| REQ-037 | System SHALL mark items with network timeout as FAILED with retriable error code | Must | Allows retry without data loss |

### Export and Reporting

| ID | Requirement | Priority | Notes |
|----|-------------|----------|-------|
| REQ-038 | System SHALL create job.json.backup before updating job state | Must | Atomic write pattern for recovery |
| REQ-039 | System SHALL validate job.json on load and offer recovery from backup if corrupted | Must | Corruption recovery mechanism |
| REQ-040 | System SHALL normalize phone numbers (remove spaces, dashes) before validation | Must | Accept user-friendly input formats |
| REQ-041 | System SHALL normalize user UPNs (lowercase) to match Graph API canonical form | Must | Prevent case-sensitivity issues |
| REQ-042 | System SHALL strip BOM (byte order mark) from CSV if present | Must | Excel compatibility |
| REQ-043 | System SHALL export items as CSV with `--output` flag for file path | Must | Default: `<job-name>-<filter>.csv` |
| REQ-044 | System SHALL support export filters: `--failed`, `--succeeded`, `--all` | Must | Flexible result export |
| REQ-045 | System SHALL include error details in failed item exports | Must | error_code, error_message, attempts columns |
| REQ-046 | System SHALL generate detailed summary report after execution | Must | See Appendix D for format |

### Job Lifecycle

| ID | Requirement | Priority | Notes |
|----|-------------|----------|-------|
| REQ-047 | System SHALL list all jobs with summary statistics | Must | `batch status` with no args |
| REQ-048 | System SHALL show detailed status for a specific job | Must | `batch status <job-id>` |
| REQ-049 | System SHALL support deleting completed jobs | Should | Manual cleanup via `batch delete` |
| REQ-050 | System SHALL auto-cleanup jobs older than 30 days | Could | Configurable retention period |

---

## 6. Non-Functional Requirements

### Performance

| Metric | Target | Rationale |
|--------|--------|-----------|
| Job creation time | < 5 seconds for 1000-item CSV | CSV parsing and validation schema |
| Validation throughput | > 50 items/second (API-bound) | Individual or batch Graph API calls |
| Execution throughput | > 10 items/minute at concurrency=3 | Limited by Graph API and async polling |
| Progress update latency | < 1 second | Real-time feedback |

**Batch Size Performance Targets** (at concurrency=3):

| Batch Size | Expected Duration | Memory Limit | Notes |
|------------|-------------------|--------------|-------|
| 100 items  | ~10 minutes      | < 50 MB      | Small migration |
| 500 items  | ~45 minutes      | < 100 MB     | Typical migration |
| 1000 items | ~90 minutes      | < 200 MB     | Large migration |
| 5000 items | ~7 hours         | < 500 MB     | Enterprise migration |
| 10000 items | ~14 hours       | < 1 GB       | Maximum supported (overnight run) |

### Reliability

| Metric | Target | Rationale |
|--------|--------|-----------|
| State persistence | 100% - no data loss on crash/interrupt | Incremental saves after each item |
| Retry success rate | > 80% of transient failures recovered | Exponential backoff for 429/503 |
| Idempotency | 100% safe to re-run | Skip succeeded, retry failed only |

### Scalability

| Metric | Target | Rationale |
|--------|--------|-----------|
| Maximum batch size | 10,000 items | Practical limit for single migration |
| Concurrent jobs | 1 active per tenant | Avoid rate limit conflicts |
| Job history retention | 100+ jobs | 30-day retention typical |

### Usability

| Metric | Target | Rationale |
|--------|--------|-----------|
| Time to first job | < 2 minutes from CSV | Minimal learning curve |
| Error message clarity | Actionable in 90% of cases | Include line number, value, fix suggestion |
| Documentation | Complete CLI help + examples | `--help` sufficient for basic use |

---

## 7. Technical Considerations

### Architecture

The batch feature integrates with existing layers:

```
┌─────────────────────────────────────────────────────────────┐
│ CLI Layer (cli/batch.py)                                    │
│   batch create | validate | run | retry | status | export   │
├─────────────────────────────────────────────────────────────┤
│ Service Layer                                               │
│   BatchService (new)    - orchestrates batch operations     │
│   JobService (new)      - job CRUD and state management     │
│   ValidationService (new) - pre-flight validation           │
│   UserService (existing) - user lookups                     │
│   NumberService (existing) - number assignment              │
├─────────────────────────────────────────────────────────────┤
│ Infrastructure Layer                                        │
│   JobStore (new)        - JSON file persistence             │
│   GraphClient (existing) - Graph API access                 │
│   CacheManager (existing) - CSV cache access                │
└─────────────────────────────────────────────────────────────┘
```

### Data Models

**Job Model:**
```python
class JobStatus(str, Enum):
    CREATED = "created"
    VALIDATING = "validating"
    VALIDATED = "validated"
    RUNNING = "running"
    COMPLETED = "completed"
    INTERRUPTED = "interrupted"

# Valid state transitions:
# CREATED → VALIDATING → VALIDATED → RUNNING → COMPLETED
# RUNNING → INTERRUPTED → RUNNING (resume)
# Any state → INTERRUPTED (on Ctrl+C or network failure)
# VALIDATED → VALIDATING (re-validate after CSV changes)
# COMPLETED → RUNNING (re-run to retry failed items)

class ItemStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    NEEDS_REVIEW = "needs_review"

class JobItem(BaseModel):
    line_number: int
    user_upn: str
    phone_number: str
    status: ItemStatus = ItemStatus.PENDING
    attempts: int = 0
    error_code: str | None = None
    error_message: str | None = None
    completed_at: datetime | None = None

class Job(BaseModel):
    id: str
    name: str
    status: JobStatus
    created_at: datetime
    updated_at: datetime
    started_at: datetime | None = None      # First execution start
    completed_at: datetime | None = None    # Final completion (success or all retries done)
    input_file: str
    input_hash: str                         # SHA-256 of input CSV contents
    items: list[JobItem]

    # Computed properties
    @property
    def total_count(self) -> int: ...
    @property
    def succeeded_count(self) -> int: ...
    @property
    def failed_count(self) -> int: ...
    @property
    def pending_count(self) -> int: ...
    @property
    def duration(self) -> timedelta | None: ...  # completed_at - started_at
```

**CSV Input Schema:**
```csv
user_upn,phone_number
john.doe@contoso.com,+14255551234
jane.smith@contoso.com,+14255555678
```

### Job Storage Structure

```
.teams-phone/
└── jobs/
    ├── 20260203-143015-a1b2-q1-migration/
    │   ├── job.json          # Job metadata and item states
    │   ├── job.json.backup   # Last known good state
    │   ├── input.csv         # Copy of original input
    │   └── execution.log     # Timestamped execution log
    └── 20260205-091542-c3d4-dept-move/
        ├── job.json
        ├── job.json.backup
        ├── input.csv
        └── execution.log
```

**Atomic Write Pattern for Job State:**

To prevent job state corruption from crashes, network failures, or interrupted writes:

```python
# Atomic write pattern for job.json updates:
1. Write updated state to job.json.tmp
2. Fsync to ensure data is on disk
3. Copy current job.json to job.json.backup (if exists)
4. Atomic rename job.json.tmp to job.json
5. Fsync parent directory

# On load, validate job.json:
1. Attempt to parse job.json
2. If corrupted, check job.json.backup
3. If backup valid, restore from backup and warn user
4. If both corrupted, fail with error and preserve files for manual recovery
```

This ensures:
- No partial writes visible to readers
- Always have a recovery path from last known good state
- Network interruptions don't leave job in invalid state

### API Interactions

**Validation Phase** (`batch validate`):
- `GET /users/{upn}` - Check user exists (individual lookups, 404 = user not found)
- `GET /users/{upn}/licenseDetails` - Check Teams Phone license (only with `--check-licenses`)
- Use `NumberService.get_number(phone_number)` to check number exists and current assignment (add method if not exists)
- No changes made to tenant (read-only operations)

**Execution Phase** (`batch run`):
- Runtime re-validation: Check number availability immediately before assignment (TOCTOU protection)
- Use existing `NumberService.assign_number()` which handles:
  - POST to assign endpoint
  - 202 response handling
  - Polling for completion
  - Retry with exponential backoff
  - Error handling and classification

### Error Handling

Extend existing exception hierarchy with batch-specific exit codes:

```python
class BatchError(TeamsPhoneError):
    """Base class for batch operation errors."""
    exit_code = 9

class BatchValidationError(BatchError):
    """Validation failed for one or more items (preventable errors detected)."""
    exit_code = 10

class BatchExecutionError(BatchError):
    """Execution failed but state is preserved (runtime errors)."""
    exit_code = 11

class JobNotFoundError(BatchError):
    """Job ID does not exist."""
    exit_code = 12

class JobLockError(BatchError):
    """Another job is already running (concurrent execution prevented)."""
    exit_code = 13
```

**Exit Code Reference:**
- 0: Success
- 1: Unexpected error (unhandled exception, CLI framework error)
- 2-8: Existing exception hierarchy (auth, authorization, not-found, validation, rate-limit, config, contract)
- 9: Batch error (base class, should not be raised directly)
- 10: Batch validation failed (use `batch validate` to see details)
- 11: Batch execution failed (state preserved, safe to retry)
- 12: Job not found (check job ID with `batch status`)
- 13: Job already running (wait for completion or use different job)

### Testing Strategy

| Test Type | Coverage |
|-----------|----------|
| Unit tests | Job model, CSV parsing, validation logic, state management |
| Integration tests | Full batch workflow with mocked Graph API (respx) |
| Contract tests | Validation against real Graph API responses |
| E2E tests | Manual testing with real tenant (not automated) |

---

## 8. Key Decisions

This section documents critical design decisions made during PRD development:

| Decision | Rationale | Requirement |
|----------|-----------|-------------|
| **Job ID Format: Timestamp + Random + Name Slug** | Format: `YYYYMMDD-HHMMSS-{random4hex}-{name-slug}`. Human-readable, sortable, collision-resistant. Random suffix prevents same-second collisions. | REQ-003 |
| **Idempotent Assignment Behavior** | Numbers already assigned to target user = SUCCESS. Enables safe retries and re-runs without manual filtering. | REQ-014 |
| **License Validation: Opt-in** | `--check-licenses` flag required. Default OFF to avoid latency. Most orgs pre-validate licensing separately. | REQ-012 |
| **Concurrency Default: 3** | Conservative to avoid Graph API rate limits. Users can increase with `--concurrency` flag if needed. | REQ-022 |
| **Atomic Write Pattern** | Write to .tmp, fsync, rename. Prevents state corruption from crashes. Always maintain .backup for recovery. | REQ-038, REQ-039 |
| **Two-Phase Validation** | Pre-flight (`batch validate`) for early feedback + runtime re-validation for TOCTOU protection. State can change between validate and run. | Validation Strategy |
| **Separate Commands: Run/Resume/Retry** | `run` = full execution, `resume` = continue interrupted, `retry` = failed only. Clear semantics prevent user confusion. | REQ-030, REQ-031, REQ-032 |
| **Execution Log Persistence** | Separate `execution.log` file with timestamps for debugging. Console output ephemeral, log file permanent. | REQ-027 |
| **Network Errors: Retriable** | Network failures = FAILED status with retriable error code. User can `batch retry` without manual intervention. | REQ-035-037 |
| **CSV Export: Error Details in Columns** | Failed exports include error_code, error_message, attempts columns. Not directly re-importable but provides full context. | REQ-045 |
| **Job Input Update: Not Supported** | Cannot update CSV after job creation. Complicates state management and hash validation. Create new job instead. | Open Questions (resolved) |
| **Concurrent Job Limit: 1** | Lock file prevents multiple jobs running simultaneously. Avoids rate limit conflicts and state corruption. | REQ-006, REQ-007 |

---

## 9. Implementation Roadmap

### Phase 1: Foundation (Sprint 1)

**Goal:** Core job management and basic validation

| Task | Requirements | Complexity |
|------|--------------|------------|
| Define Job and JobItem Pydantic models with state transitions | REQ-001, REQ-005 | Low |
| Implement JobStore (JSON file persistence with atomic writes) | REQ-002, REQ-003, REQ-038, REQ-039 | Medium |
| Implement CSV parser with header/duplicate/normalization/line endings | REQ-001, REQ-017-020, REQ-020a-c, REQ-040-042 | Medium |
| Add job locking mechanism for concurrent execution prevention | REQ-006, REQ-007 | Medium |
| Add `batch create` command | REQ-001, REQ-004 | Low |
| Add `batch status` command (list and detail) | REQ-047, REQ-048 | Low |
| Implement basic validation (format checks, duplicates) | REQ-010, REQ-015, REQ-017-020 | Medium |
| Add `batch validate` command | REQ-010-020 | Low |

**Deliverable:** Can create jobs, validate phone number formats and CSV structure, view job status

### Phase 2: Validation & Execution (Sprint 2)

**Goal:** Full validation and batch execution with progress

| Task | Requirements | Complexity |
|------|--------------|------------|
| Add user existence validation via Graph API | REQ-011 | Medium |
| Add number availability validation (pre-flight + runtime) | REQ-013, REQ-014 | Medium |
| Implement BatchExecutor with concurrency control (asyncio semaphore) | REQ-021, REQ-022 | Medium |
| Add execution.log persistence with timestamps | REQ-027 | Low |
| Add progress display with resume support (rich progress bar) | REQ-028 | Medium |
| Implement incremental state persistence with atomic writes | REQ-026, REQ-038 | Medium |
| Handle graceful interruption (SIGINT) and network failures | REQ-029, REQ-035-037 | Medium |
| Add `batch run` command with `--concurrency` and `--dry-run` | REQ-021-030 | Low |

**Deliverable:** Can validate against Graph API and execute batches with progress, dry-run, and crash safety

### Phase 3: Iteration & Export (Sprint 3)

**Goal:** Retry workflow and export capabilities

| Task | Requirements | Complexity |
|------|--------------|------------|
| Implement retry logic (failed items only) | REQ-031, REQ-033 | Medium |
| Implement resume logic (interrupted jobs) | REQ-032 | Medium |
| Add "needs_review" flagging for persistent failures | REQ-034 | Low |
| Add `batch retry` command | REQ-031, REQ-033, REQ-034 | Low |
| Add `batch resume` command | REQ-032 | Low |
| Implement CSV export service with filters | REQ-043, REQ-044, REQ-045 | Low |
| Add `batch export` command with `--failed/--succeeded/--all` | REQ-043-045 | Low |
| Add detailed summary report formatter | REQ-046 | Low |
| Add `batch delete` command | REQ-049 | Low |

**Deliverable:** Full iteration workflow (run/resume/retry) with export and detailed reporting

### Phase 4: Polish (Optional)

| Task | Requirements | Complexity |
|------|--------------|------------|
| Add Teams Phone license validation (`--check-licenses` flag) | REQ-012 | Medium |
| Add strict validation mode (`--strict` flag) | REQ-016 | Low |
| Add job auto-cleanup (30-day retention) | REQ-050 | Low |
| Optimize validation with batch Graph API lookups | - | Medium |
| Add JSON output format for automation (`--format json`) | - | Low |

---

## 10. Out of Scope

The following are explicitly **NOT** included in this feature:

| Item | Rationale | Future Consideration |
|------|-----------|---------------------|
| Policy assignment in batch | Separate concern, adds complexity | Phase 2 feature |
| Number unassignment in batch | Different workflow, less common | Phase 2 feature |
| Multi-tenant batch operations | MSP feature, requires tenant switching | Future enhancement |
| Web UI for batch management | CLI-first tool | Out of scope |
| Real-time notifications (email/webhook) | Over-engineering for CLI tool | Out of scope |
| Rollback capability | Complex, rarely needed | Out of scope |
| Scheduling/cron integration | Use OS scheduler if needed | Out of scope |
| Import from Excel (.xlsx) | CSV is sufficient, Excel adds dependency | Out of scope |

---

## 11. Open Questions & Risks

### Open Questions

| Question | Owner | Status | Decision |
|----------|-------|--------|----------|
| Should validation check licenses by default or only with `--check-licenses`? | PM | **RESOLVED** | Opt-in with `--check-licenses` flag (REQ-012 priority: Could). License checks add API latency; most orgs pre-validate licensing. |
| What's the right default concurrency? | Eng | **RESOLVED** | Default: 3 concurrent items. Conservative to avoid rate limits. Users can increase with `--concurrency` flag. |
| Should we support updating job input CSV after creation? | PM | **RESOLVED** | No. Complicates state management and hash validation. User should create new job with updated CSV. |
| How to handle numbers already assigned to the target user? | Eng | **RESOLVED** | Treat as SUCCESS (idempotent behavior per REQ-014). Enables safe retries and re-runs. |
| Should we implement batch user lookups for validation? | Eng | **RESOLVED** | **No** for Phase 1-3. Use individual user lookups (`GET /users/{upn}`). Simpler implementation, clearer error handling per user. Batch lookups with `$filter` or `$batch` endpoint can be investigated as Phase 4 optimization if validation performance becomes a bottleneck. Prioritize working implementation over premature optimization. |

### Risks

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Graph API rate limits hit with large batches | High | Medium | Configurable concurrency, exponential backoff, default=3 |
| Async polling takes longer than expected | Medium | Low | Configurable timeout, network error handling |
| CSV data quality issues not caught by validation | Medium | Medium | Duplicate detection, normalization, strict mode option |
| Job state corruption | Low | High | Atomic writes with fsync, job.json.backup recovery |
| User confusion with job IDs | Low | Low | Human-readable timestamp-based IDs (resolved) |
| Network interruption during execution | Medium | Medium | Incremental state persistence, network error retry, resume capability |
| Race conditions between validate and run | Low | Low | Runtime re-validation before assignment (TOCTOU protection) |

---

## 12. Validation Checkpoints

### Phase 1 Completion
- [ ] Can create a job from valid CSV with timestamp-based job ID (with random suffix)
- [ ] Job locking prevents concurrent execution (exit code 13)
- [ ] Can view job list and job details
- [ ] CSV validation catches: missing headers, duplicate numbers, duplicate users, empty values
- [ ] Phone number normalization handles spaces/dashes, strips extensions with warning
- [ ] CSV parsing handles BOM, CRLF/LF/CR line endings
- [ ] Invalid CSV returns clear error with line numbers
- [ ] Job persists across CLI restarts with atomic writes
- [ ] Job state corruption recovery from backup works

### Phase 2 Completion
- [ ] Validation catches: non-existent users, unavailable numbers
- [ ] Batch execution completes successfully for valid inputs
- [ ] Dry-run mode simulates without API calls
- [ ] Progress bar shows accurate counts and resumes correctly
- [ ] Execution log captures timestamps and API responses
- [ ] Ctrl+C preserves state and sets status to INTERRUPTED
- [ ] Network failures handled with retry and state preservation
- [ ] Rate limiting handled gracefully with backoff
- [ ] Idempotency: numbers already assigned to target user = success

### Phase 3 Completion
- [ ] Resume processes interrupted jobs from last state
- [ ] Retry processes only failed items
- [ ] Export generates CSV with error details
- [ ] Summary report shows detailed breakdown by error code
- [ ] Full migration workflow (create → validate → run → resume → retry → export) works end-to-end
- [ ] Items failing 3+ times flagged as "needs_review"

### Definition of Done
- [ ] All Must-have requirements implemented
- [ ] Unit test coverage > 80% for new code
- [ ] Integration tests for happy path and key error cases
- [ ] CLI help text complete and accurate
- [ ] CLAUDE.md updated with batch commands

---

## Appendix A: CLI Command Reference

```bash
# Create a new batch job from CSV
teams-phone batch create <input.csv> [--name "Migration Name"]

# Validate a job (no changes made to tenant)
teams-phone batch validate <job-id> [--strict] [--check-licenses]

# Execute a job
teams-phone batch run <job-id> [--concurrency 3] [--dry-run]

# Resume an interrupted job
teams-phone batch resume <job-id> [--concurrency 3]

# Retry only failed items
teams-phone batch retry <job-id> [--concurrency 3]

# View job status
teams-phone batch status              # List all jobs
teams-phone batch status <job-id>     # Detailed view

# Export results
teams-phone batch export <job-id> --failed [--output failed.csv]
teams-phone batch export <job-id> --succeeded [--output succeeded.csv]
teams-phone batch export <job-id> --all [--output all-results.csv]

# Delete a job
teams-phone batch delete <job-id> [--force]
```

## Appendix B: CSV Schema

**Minimum Required:**
```csv
user_upn,phone_number
```

**Full Schema (future):**
```csv
user_upn,phone_number,voice_routing_policy,calling_policy,dial_plan
```

## Appendix C: Error Codes

| Code | Name | Description |
|------|------|-------------|
| BATCH_001 | INVALID_CSV | CSV file cannot be parsed (missing headers, malformed) |
| BATCH_002 | INVALID_FORMAT | Phone number format invalid (not E.164) |
| BATCH_003 | USER_NOT_FOUND | User UPN does not exist in tenant |
| BATCH_004 | USER_NOT_LICENSED | User lacks Teams Phone license (only with `--check-licenses`) |
| BATCH_005 | NUMBER_NOT_FOUND | Phone number not in tenant inventory |
| BATCH_006 | NUMBER_UNAVAILABLE | Phone number assigned to another user |
| BATCH_007 | ASSIGNMENT_FAILED | Graph API assignment operation failed |
| BATCH_008 | TIMEOUT | Async operation polling timed out |
| BATCH_009 | DUPLICATE_PHONE | Duplicate phone number within batch |
| BATCH_010 | DUPLICATE_USER | Duplicate user assignment within batch |
| BATCH_011 | NETWORK_ERROR | Network failure during API call (retriable) |
| BATCH_012 | EMPTY_VALUE | Required field (user_upn or phone_number) is empty |
| BATCH_013 | EXTENSION_STRIPPED | Phone extension was stripped (warning, not error) |

## Appendix D: Summary Report Format

After `batch run` completes, the system SHALL display a summary report in this format:

```
================================================================================
Batch Execution Summary
================================================================================
Job: q1-migration
Job ID: 20260203-143015-a1b2-q1-migration
Duration: 45m 23s
Items: 500 total

Results:
  ✓ 487 succeeded (97.4%)
  ✗ 13 failed (2.6%)
  ⧗ 0 pending

Failures by Error Code:
  • USER_NOT_LICENSED (8 items)
  • NUMBER_UNAVAILABLE (3 items)
  • TIMEOUT (2 items)

Next Steps:
  1. Review failures: teams-phone batch status 20260203-143015-a1b2-q1-migration
  2. Export failed items: teams-phone batch export 20260203-143015-a1b2-q1-migration --failed
  3. Fix issues in CSV and retry: teams-phone batch retry 20260203-143015-a1b2-q1-migration

Execution log: .teams-phone/jobs/20260203-143015-a1b2-q1-migration/execution.log
================================================================================
```

**For interrupted jobs** (Ctrl+C), append:
```
⚠ Job interrupted by user
  Progress saved: 245/500 items completed
  Resume with: teams-phone batch resume 20260203-143015-a1b2-q1-migration
```

**For jobs with items needing manual review** (3+ failures):
```
⚠ 5 items flagged for manual review (failed 3+ times)
  Review with: teams-phone batch status 20260203-143015-a1b2-q1-migration
```
