# Search Enhancement Ideas

This document captures ideas for improving search functionality across the Teams Phone CLI, based on analysis of current implementations.

## Current State Summary

| Command | Server-Side Filters | Client-Side Filters | Pattern Type |
|---------|---------------------|---------------------|--------------|
| `numbers list` | status, type | city | Exact match |
| `numbers search` | None | pattern | Wildcard (`*`) |
| `users list` | licensed, account-type | assigned | Exact match |
| `users search` | phone, UPN, displayName | None | Auto-detected routing |
| `locations list` | N/A (CSV) | city | Exact match |
| `locations search` | N/A (CSV) | query | Substring |
| `policies list` | N/A (CSV) | policy_type | Exact match |

### Current Strengths

- **Smart query detection** in `users search` auto-routes based on input format
- **Wildcard support** in `numbers search` for flexible pattern matching
- **Multi-field search** in `locations search` with optional `--field` narrowing
- **Consistent pagination** with `--limit` and `--all` flags

### Current Inconsistencies

- `numbers list --city` is case-sensitive; all other filters are case-insensitive
- `locations list --city` uses exact match; `locations search --field city` uses substring
- Only `numbers search` supports wildcard patterns

---

## Enhancement Ideas

### 1. Unify Case Sensitivity

**Problem:** `numbers list --city` is case-sensitive while `locations list --city` is case-insensitive.

**Solution:** Standardize all string filters to case-insensitive matching.

**Files affected:**
- `src/teams_phone/cli/numbers.py` - Update city filter logic

**Priority:** Low (minor UX inconsistency)

---

### 2. Add Partial Matching to List Filters

**Problem:** List commands use exact match for filters, but search commands use substring. Users may expect `--city Sea` to match "Seattle".

**Solution:** Add `--contains` flag or change default behavior to substring matching.

**Example:**
```bash
# Current: exact match only
teams-phone locations list --city "Seattle"

# Enhanced: partial match option
teams-phone locations list --city "Sea" --contains
```

**Priority:** Medium

---

### 3. Cross-Entity Search Command

**Problem:** Users must know which entity type to search. Finding "who has number X" or "what numbers does user Y have" requires multiple commands.

**Solution:** Add a global search command that searches across all entities.

**Example:**
```bash
# Search everywhere
teams-phone search "John"
# Returns: Users matching "John", numbers assigned to users named "John", locations with "John" in description

# With entity filter
teams-phone search "206" --type numbers,users
```

**Considerations:**
- Performance: May need to limit concurrent API calls
- Output format: Need clear entity type indicators in results
- Could be implemented as parallel searches with merged output

**Priority:** High (significant UX improvement)

---

### 4. Numbers Search by Assignment

**Problem:** Finding numbers assigned to a specific user requires `users show` then manual lookup.

**Solution:** Add `--assigned-to` filter to numbers commands.

**Example:**
```bash
# Find all numbers assigned to a user
teams-phone numbers list --assigned-to "john@contoso.com"

# Or as part of search
teams-phone numbers search --assigned-to "john@contoso.com"
```

**Implementation notes:**
- Resolve user first, then filter by assignedTo.id
- Could use Graph API OData filter if supported

**Priority:** High (common use case)

---

### 5. Wildcard Support Consistency

**Problem:** Only `numbers search` supports wildcards. Users may expect `users search "Jo*"` to work.

**Solution:** Add wildcard support to `locations search` and `users search`.

**Example:**
```bash
# Currently not supported
teams-phone users search "Jo*"
teams-phone locations search "Main*"

# Enhanced: wildcard patterns work everywhere
```

**Implementation notes:**
- For `users search`, wildcards would need client-side filtering (Graph `startsWith` is server-side)
- For `locations search`, already client-side so easy to add
- Reuse `match_pattern()` from `utils.py`

**Priority:** Medium

---

### 6. Export with Query Filtering

**Problem:** Power users want to extract specific fields or filter output programmatically.

**Solution:** Add `--output json` with optional JMESPath or field selection.

**Example:**
```bash
# JSON output (basic)
teams-phone users list --output json

# With field selection
teams-phone users list --output json --fields "displayName,telephoneNumber"

# With JMESPath query
teams-phone users list --output json --query "[?telephoneNumbers[0]].{name: displayName, phone: telephoneNumbers[0]}"
```

**Considerations:**
- JMESPath adds a dependency
- Simple field selection might be sufficient for most cases
- Could also support CSV output format

**Priority:** Medium (power user feature)

---

### 7. Search Result Caching

**Problem:** Refining a broad search requires re-fetching all data. `numbers search "*"` followed by `numbers search "206*"` makes two full API calls.

**Solution:** Cache recent search results with TTL, allow refinement without re-fetch.

**Example:**
```bash
# First search caches results
teams-phone numbers search "*" --limit 1000
# Cached: 1000 numbers

# Refinement uses cache
teams-phone numbers search "206*" --from-cache
# Filters cached results, no API call
```

**Implementation notes:**
- SQLite or in-memory cache with configurable TTL
- `--from-cache` or `--refine` flag to use cached results
- `--refresh` flag to bypass cache

**Priority:** Low (optimization for power users)

---

### 8. Performance Warnings for Large Searches

**Problem:** `numbers search` fetches all numbers for client-side filtering. Users may not realize performance impact on large inventories.

**Solution:** Add CLI warning when fetching large result sets.

**Example output:**
```
Fetching all numbers for pattern matching...
Warning: 5,234 numbers to filter. This may take a moment.
Found 47 numbers matching "206*"
```

**Implementation notes:**
- Check total count before or during pagination
- Configurable threshold (e.g., warn if >1000)
- `--quiet` flag to suppress warnings

**Priority:** Low (nice-to-have UX improvement)

---

### 9. Saved Searches / Search Aliases

**Problem:** Users frequently run the same complex searches.

**Solution:** Allow saving search parameters as named aliases.

**Example:**
```bash
# Save a search
teams-phone search save "unassigned-206" "numbers list --status unassigned --city Seattle"

# Run saved search
teams-phone search run "unassigned-206"

# List saved searches
teams-phone search list
```

**Considerations:**
- Store in config file (`~/.teams-phone/searches.json`)
- Support parameter substitution for dynamic values

**Priority:** Low (power user feature)

---

### 10. Interactive Search Mode

**Problem:** CLI requires re-running commands to refine searches.

**Solution:** Add interactive mode with real-time filtering.

**Example:**
```bash
teams-phone numbers search --interactive
# Opens TUI with:
# - Live filter input
# - Results update as you type
# - Arrow keys to navigate
# - Enter to select and show details
```

**Considerations:**
- Requires TUI library (rich, textual, or prompt_toolkit)
- Significant implementation effort
- May be out of scope for CLI tool

**Priority:** Low (nice-to-have, high effort)

---

## Recommended Priority Order

1. **Cross-Entity Search** - Highest impact for user experience
2. **Numbers Search by Assignment** - Common use case, fills a gap
3. **Unify Case Sensitivity** - Quick fix, improves consistency
4. **Wildcard Support Consistency** - Reuses existing code
5. **Partial Matching for List Filters** - Medium effort, good UX
6. **Export with Query Filtering** - Power user feature
7. **Performance Warnings** - Nice-to-have
8. **Search Result Caching** - Optimization
9. **Saved Searches** - Power user feature
10. **Interactive Search Mode** - High effort, lower priority

---

## Implementation Notes

### Reusable Components

- `match_pattern()` in `utils.py` - Already handles wildcard conversion to regex
- User resolution logic in `UserService` - Can be reused for `--assigned-to` filters
- Pagination patterns - Consistent across all list commands

### Graph API Limitations

- No wildcard support in OData `$filter`
- No `$count` on nested collections (telephoneNumbers)
- City field not filterable on number assignments
- URL length limits require batching for large ID lists

### Testing Considerations

- Add unit tests for new filter combinations
- Contract tests for any new Graph API queries
- Performance tests for large result set handling
