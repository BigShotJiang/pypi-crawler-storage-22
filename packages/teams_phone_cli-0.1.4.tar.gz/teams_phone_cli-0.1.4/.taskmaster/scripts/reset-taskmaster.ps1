<#
.SYNOPSIS
    Archives completed TaskMaster phase and resets for a new feature cycle.

.DESCRIPTION
    Moves task files, recon notes, and optionally the complexity report to archive
    directories, then creates a fresh tasks.json for the next phase.

.PARAMETER PhaseName
    Name for the archive folder (e.g., 'search-enhancements', 'mvp', 'auth-refactor').
    Will be used as the subdirectory name under _archive/.

.PARAMETER ArchiveReport
    If specified, also moves the task-complexity-report.json to the archive.

.PARAMETER DryRun
    If specified, shows what would be moved without actually moving files.

.EXAMPLE
    .\reset-taskmaster.ps1 -PhaseName search-enhancements
    Archives current tasks and recon to _archive/search-enhancements/

.EXAMPLE
    .\reset-taskmaster.ps1 -PhaseName search-enhancements -ArchiveReport
    Also archives the complexity report.

.EXAMPLE
    .\reset-taskmaster.ps1 -PhaseName search-enhancements -DryRun
    Preview what would be archived without making changes.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidatePattern('^[a-z0-9-]+$')]
    [string]$PhaseName,

    [Parameter(Mandatory = $false)]
    [switch]$ArchiveReport,

    [Parameter(Mandatory = $false)]
    [switch]$DryRun
)

# Resolve paths relative to .taskmaster directory
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$taskmasterDir = Split-Path -Parent $scriptDir

$tasksDir = Join-Path $taskmasterDir "tasks"
$reconDir = Join-Path $taskmasterDir "recon"
$reportsDir = Join-Path $taskmasterDir "reports"

$tasksArchiveDir = Join-Path $tasksDir "_archive" $PhaseName
$reconArchiveDir = Join-Path $reconDir "_archive" $PhaseName

# Counters for summary
$taskFilesMoved = 0
$reconFilesMoved = 0
$reportMoved = $false

function Write-Action {
    param([string]$Message, [string]$Color = "White")
    if ($DryRun) {
        Write-Host "[DRY RUN] $Message" -ForegroundColor DarkGray
    } else {
        Write-Host $Message -ForegroundColor $Color
    }
}

# Header
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "TaskMaster Reset: $PhaseName" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

if ($DryRun) {
    Write-Host "DRY RUN MODE - No files will be modified" -ForegroundColor Yellow
    Write-Host ""
}

# Check if archive already exists
if (Test-Path $tasksArchiveDir) {
    Write-Host "ERROR: Archive already exists: $tasksArchiveDir" -ForegroundColor Red
    Write-Host "Choose a different phase name or remove the existing archive." -ForegroundColor Red
    exit 1
}

# Step 1: Archive task files
Write-Host "Step 1: Archiving task files..." -ForegroundColor Yellow

$taskFiles = Get-ChildItem -Path $tasksDir -Filter "*.md" -File -ErrorAction SilentlyContinue
$tasksJson = Join-Path $tasksDir "tasks.json"

if (($taskFiles.Count -eq 0) -and (-not (Test-Path $tasksJson))) {
    Write-Host "  No task files to archive" -ForegroundColor DarkGray
} else {
    if (-not $DryRun) {
        New-Item -ItemType Directory -Path $tasksArchiveDir -Force | Out-Null
    }
    Write-Action "  Created: $tasksArchiveDir" "Green"

    # Move task markdown files
    foreach ($file in $taskFiles) {
        $dest = Join-Path $tasksArchiveDir $file.Name
        Write-Action "  Moving: $($file.Name)"
        if (-not $DryRun) {
            Move-Item -Path $file.FullName -Destination $dest
        }
        $taskFilesMoved++
    }

    # Move tasks.json
    if (Test-Path $tasksJson) {
        $dest = Join-Path $tasksArchiveDir "tasks.json"
        Write-Action "  Moving: tasks.json"
        if (-not $DryRun) {
            Move-Item -Path $tasksJson -Destination $dest
        }
        $taskFilesMoved++
    }
}

Write-Host ""

# Step 2: Archive recon files
Write-Host "Step 2: Archiving recon files..." -ForegroundColor Yellow

$reconFiles = Get-ChildItem -Path $reconDir -Filter "*.md" -File -ErrorAction SilentlyContinue

if ($reconFiles.Count -eq 0) {
    Write-Host "  No recon files to archive" -ForegroundColor DarkGray
} else {
    if (-not $DryRun) {
        New-Item -ItemType Directory -Path $reconArchiveDir -Force | Out-Null
    }
    Write-Action "  Created: $reconArchiveDir" "Green"

    foreach ($file in $reconFiles) {
        $dest = Join-Path $reconArchiveDir $file.Name
        Write-Action "  Moving: $($file.Name)"
        if (-not $DryRun) {
            Move-Item -Path $file.FullName -Destination $dest
        }
        $reconFilesMoved++
    }
}

Write-Host ""

# Step 3: Optionally archive complexity report
if ($ArchiveReport) {
    Write-Host "Step 3: Archiving complexity report..." -ForegroundColor Yellow

    $complexityReport = Join-Path $reportsDir "task-complexity-report.json"
    if (Test-Path $complexityReport) {
        $reportArchiveDir = Join-Path $tasksArchiveDir "reports"
        if (-not $DryRun) {
            New-Item -ItemType Directory -Path $reportArchiveDir -Force | Out-Null
            Move-Item -Path $complexityReport -Destination (Join-Path $reportArchiveDir "task-complexity-report.json")
        }
        Write-Action "  Moving: task-complexity-report.json" "Green"
        $reportMoved = $true
    } else {
        Write-Host "  No complexity report found" -ForegroundColor DarkGray
    }
    Write-Host ""
}

# Step 4: Create fresh tasks.json
Write-Host "Step 4: Creating fresh tasks.json..." -ForegroundColor Yellow

$emptyTasksJson = @{
    tasks = @()
    metadata = @{
        createdAt = (Get-Date -Format "o")
        previousPhase = $PhaseName
    }
} | ConvertTo-Json -Depth 10

if (-not $DryRun) {
    $emptyTasksJson | Set-Content -Path $tasksJson -Encoding UTF8
}
Write-Action "  Created: tasks.json (empty)" "Green"

Write-Host ""

# Summary
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Summary" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Task files archived:  $taskFilesMoved" -ForegroundColor White
Write-Host "  Recon files archived: $reconFilesMoved" -ForegroundColor White
if ($ArchiveReport) {
    Write-Host "  Report archived:      $reportMoved" -ForegroundColor White
}
Write-Host ""

if ($DryRun) {
    Write-Host "DRY RUN COMPLETE - No files were modified" -ForegroundColor Yellow
    Write-Host "Run without -DryRun to apply changes." -ForegroundColor Yellow
} else {
    Write-Host "Reset complete! Ready for next feature phase." -ForegroundColor Green
}
Write-Host ""
