# Task ID: 1

**Title:** Implement case-insensitive city filter for numbers list

**Status:** pending

**Dependencies:** None

**Priority:** high

**Description:** Update the NumberService.list_numbers() method to perform case-insensitive comparison when filtering by city, ensuring that `numbers list --city seattle` matches "Seattle".

**Details:**

**Location:** `src/teams_phone/services/number_service.py:112`

**Current Implementation:**
```python
# Client-side city filter (OData doesn't support city filter)
if city is not None and number.city != city:
    continue
```

**Updated Implementation:**
```python
# Client-side city filter (OData doesn't support city filter)
# Case-insensitive comparison per US-001
if city is not None and (number.city or "").lower() != city.lower():
    continue
```

**Notes:**
- Handle `None` city values gracefully with `or ""` to avoid AttributeError
- No changes to CLI help text needed (case-insensitivity is expected default behavior)
- Also update the help text in `src/teams_phone/cli/numbers.py:286` to remove "(case-sensitive, client-side filter)" note

**Test Strategy:**

**Unit Tests:**
1. Test `--city seattle` matches "Seattle" (lowercase query)
2. Test `--city SEATTLE` matches "Seattle" (uppercase query)
3. Test `--city SeAtTlE` matches "Seattle" (mixed case)
4. Test exact case still works (`--city Seattle`)
5. Test numbers with `None` city are not matched
6. Test empty string city filter behavior

**Test File:** `tests/unit/test_number_service_read.py`

**Example Test:**
```python
async def test_list_numbers_city_filter_case_insensitive(mock_graph_client):
    mock_numbers = [
        create_number_assignment(city="Seattle"),
        create_number_assignment(city="New York"),
    ]
    # Mock paginated response
    result = await service.list_numbers(city="seattle")
    assert len(result) == 1
    assert result[0].city == "Seattle"
```

---

## Implementation Notes

### Session: 2026-02-03 12:20 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Modified `src/teams_phone/services/number_service.py:112` to use case-insensitive comparison: `(number.city or "").lower() != city.lower()`
- Updated docstring at line 76 to remove "case-sensitive" reference
- Updated CLI help text in `src/teams_phone/cli/numbers.py:286` to remove "(case-sensitive, client-side filter)" note
- Added 4 new unit tests in `tests/unit/test_number_service_read.py`:
  - `test_list_numbers_city_filter_case_insensitive_lowercase` - lowercase filter matches mixed-case cities
  - `test_list_numbers_city_filter_case_insensitive_uppercase` - uppercase filter matches mixed-case cities
  - `test_list_numbers_city_filter_case_insensitive_mixed` - mixed-case filter (SeAtTlE) matches any case
  - `test_list_numbers_city_filter_handles_none_city` - None city values handled gracefully

#### Key Decisions Made
- Used `(number.city or "").lower()` pattern for None-safe lowercase conversion (empty string when city is None)
- Kept existing comment and added new comment: `# Case-insensitive comparison per US-001`
- Simplified CLI help text to just "Filter by city." since case-insensitivity is now the default

#### Patterns Discovered
- The `make_number_dict()` helper in tests supports `city` parameter with default "Seattle"
- Test pattern uses async generator `mock_paginated` to yield mock data

#### Open Items for Next Agent
- None - task is complete

#### Gotchas and Warnings
- The city filter is client-side only (OData doesn't support city filtering)
- Always handle None city values when doing string operations
