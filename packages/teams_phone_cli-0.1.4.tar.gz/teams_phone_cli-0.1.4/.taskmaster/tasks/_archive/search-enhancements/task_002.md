# Task ID: 2

**Title:** Add --assigned-to filter to numbers list command

**Status:** pending

**Dependencies:** None

**Priority:** high

**Description:** Implement a new `--assigned-to` option for the `numbers list` command that filters numbers by the user they are assigned to. The filter should accept UPN, display name, or user GUID.

**Details:**

**CLI Changes:** `src/teams_phone/cli/numbers.py`

Add new option to `list_numbers` command:
```python
@numbers_app.command("list")
def list_numbers(
    ctx: typer.Context,
    # ... existing options ...
    assigned_to: str | None = typer.Option(
        None,
        "--assigned-to",
        "-u",
        help="Filter by assigned user (UPN, display name, or object ID).",
    ),
) -> None:
```

**Service Changes:** `src/teams_phone/services/number_service.py`

Add `assigned_to_user_id` parameter to `list_numbers()`:
```python
async def list_numbers(
    self,
    *,
    status: AssignmentStatus | None = None,
    number_type: NumberType | None = None,
    city: str | None = None,
    assigned_to_user_id: str | None = None,  # New parameter
    page_size: int = 100,
    max_items: int | None = None,
) -> list[NumberAssignment]:
```

Add client-side filter after pagination:
```python
# Client-side assigned_to filter
if assigned_to_user_id is not None:
    if number.assignment_target_id != assigned_to_user_id:
        continue
```

**CLI Logic:** Resolve user before calling service:
```python
if assigned_to:
    from teams_phone.services.user_service import UserService
    # Need to resolve user first - requires async context
    # Use run_with_service pattern to create services
```

**Implementation Pattern:**
Since `run_with_service` only creates one service, we need to modify the CLI to:
1. First resolve the user to get their ID
2. Then call list_numbers with the resolved user_id

Use similar pattern to `_run_assign_async` for creating multiple services.

**Test Strategy:**

**Unit Tests:**
1. Test `--assigned-to john@contoso.com` returns only John's numbers
2. Test `--assigned-to "John Smith"` resolves and filters correctly
3. Test `--assigned-to <user-guid>` works with object ID
4. Test returns empty list (not error) when user has no numbers
5. Test returns NotFoundError (exit code 4) when user doesn't exist
6. Test combination with other filters (`--assigned-to john@contoso.com --status unassigned`)
7. Test with JSON output mode

**Test Files:**
- `tests/unit/test_number_service_read.py` - Service layer tests
- `tests/unit/test_cli_numbers_list.py` - CLI integration tests

**Mock Setup:**
- Mock UserService.resolve_user() to return a user with known ID
- Mock NumberService.list_numbers() to return numbers with matching assignment_target_id

## Subtasks

### 2.1. Add assigned_to_user_id parameter to NumberService.list_numbers() with client-side filtering

**Status:** pending  
**Dependencies:** None  

Extend the NumberService.list_numbers() method to accept an optional assigned_to_user_id parameter and implement client-side filtering by comparing against number.assignment_target_id.

**Details:**

In `src/teams_phone/services/number_service.py`, add `assigned_to_user_id: str | None = None` parameter to the `list_numbers()` method signature. After pagination loop retrieves numbers, add client-side filter logic: `if assigned_to_user_id is not None and number.assignment_target_id != assigned_to_user_id: continue`. This filters out numbers not assigned to the specified user. The parameter expects a resolved user GUID (object ID), not UPN or display name - resolution happens at CLI layer.

### 2.2. Add --assigned-to CLI option with user resolution using _run_assign_async pattern

**Status:** done
**Dependencies:** 2.1  

Add the --assigned-to/-u option to the numbers list command and implement user resolution logic that converts UPN, display name, or object ID to a user GUID before calling NumberService.

**Details:**

In `src/teams_phone/cli/numbers.py`, add `assigned_to: str | None = typer.Option(None, '--assigned-to', '-u', help='Filter by assigned user (UPN, display name, or object ID).')` to `list_numbers()` command. Create async helper function similar to `_run_assign_async` pattern (lines 69-102) that: (1) Creates both UserService and NumberService using GraphClient context manager, (2) Resolves user via `user_service.get_user(assigned_to)` to get user.id, (3) Passes resolved user_id to `number_service.list_numbers(assigned_to_user_id=user.id)`. Handle NotFoundError from user resolution with appropriate error message.

### 2.3. Write unit tests for NumberService.list_numbers() assigned_to_user_id filtering

**Status:** done
**Dependencies:** 2.1  

Create comprehensive unit tests for the service layer filtering logic, mocking GraphClient responses to verify correct client-side filtering behavior.

**Details:**

In `tests/unit/test_number_service_*.py` (follow existing split pattern), add test class for assigned_to filtering. Use respx to mock Graph API responses returning multiple NumberAssignment objects with different assignment_target_id values. Test cases: (1) `test_list_numbers_filters_by_assigned_user_id` - verify only matching numbers returned, (2) `test_list_numbers_assigned_to_none_returns_all` - verify no filtering when parameter is None, (3) `test_list_numbers_assigned_to_user_with_no_numbers_returns_empty_list` - verify empty list (not error) when user has no assigned numbers, (4) `test_list_numbers_combined_filters` - verify assigned_to works with status/city/number_type filters.

### 2.4. Write CLI integration tests for user resolution with UPN, display name, and object ID

**Status:** done
**Dependencies:** 2.2

Create CLI-level tests that verify the --assigned-to option correctly resolves different user identifier formats and integrates with the number filtering.

**Details:**

In `tests/unit/test_cli_numbers.py` or new test file, add tests for the CLI command with --assigned-to option. Mock both UserService.get_user() and NumberService.list_numbers() calls. Test cases: (1) `test_assigned_to_with_upn` - verify UPN like 'john@contoso.com' is passed to get_user and resolved ID is used for filtering, (2) `test_assigned_to_with_display_name` - verify display name 'John Smith' resolution, (3) `test_assigned_to_with_object_id` - verify GUID format is handled, (4) `test_assigned_to_user_not_found` - verify NotFoundError handling with correct exit code, (5) `test_assigned_to_combined_with_other_filters` - verify --assigned-to works alongside --status, --city, --type options.

---

## Implementation Notes

### Session: 2026-02-03 - Agent: claude-opus-4-5-20251101

**Subtask:** 2.1 - Add assigned_to_user_id parameter to NumberService.list_numbers() with client-side filtering

**Status:** Implemented

#### What Was Done
- Added `assigned_to_user_id: str | None = None` parameter to `NumberService.list_numbers()` method signature
- Implemented client-side filter following the existing city filter pattern at line 121
- Updated docstring to document the new parameter, including notes about client-side filtering behavior
- Created comprehensive test class `TestNumberServiceAssignedToFilter` with 7 test cases

#### Files Modified
- `src/teams_phone/services/number_service.py` - Added parameter and filter logic (lines 57, 79-81, 121-125)
- `tests/unit/test_number_service_read.py` - Added test class with 7 tests (lines 463-681)

#### Key Decisions Made
- **Used combined if statement**: Initially wrote nested if statements, but ruff SIM102 flagged this. Combined them following the city filter pattern for consistency.
- **Case-sensitive comparison for GUIDs**: Unlike the city filter which is case-insensitive, GUID comparison is exact match since Graph API returns consistent casing.
- **None handling**: Unassigned numbers have `assignment_target_id=None`, so the filter naturally excludes them when filtering for a specific user (correct behavior).

#### Patterns Discovered
- Client-side filter pattern: See `number_service.py:111-114` (city filter) - used same structure for assigned_to
- Async generator mock pattern: See `test_number_service_read.py:104-108` - used for all new tests
- `make_number_dict` factory already supports `assignment_target_id` parameter - no test infrastructure changes needed

#### Test Cases Added
1. `test_list_numbers_filters_by_assigned_user_id` - Filters correctly
2. `test_list_numbers_assigned_to_none_returns_all` - No filtering when param is None
3. `test_list_numbers_assigned_to_user_with_no_numbers_returns_empty_list` - Returns empty list, not error
4. `test_list_numbers_combined_filters_status_and_assigned_to` - OData + client-side combo
5. `test_list_numbers_combined_filters_city_and_assigned_to` - Two client-side filters combo
6. `test_list_numbers_assigned_to_filter_excludes_unassigned_numbers` - Handles None target
7. `test_list_numbers_assigned_to_filter_not_in_odata` - Confirms no OData filter sent

#### Open Items for Next Agent
- [ ] Subtask 2.2 depends on this: Implement CLI --assigned-to option
- [ ] Subtask 2.3 is now complete (merged into this subtask)

#### Gotchas and Warnings
- The city filter is case-insensitive, but GUID comparison is exact match - this is intentional
- max_items applies before client-side filters, so with both city and assigned_to filters, fewer results may be returned than max_items

---

### Session: 2026-02-03 - Agent: claude-opus-4-5-20251101

**Subtask:** 2.2 - Add --assigned-to CLI option with user resolution using _run_assign_async pattern

**Status:** Implemented

#### What Was Done
- Added `--assigned-to/-u` Typer option to `list_numbers()` command signature
- Created new helper function `_run_list_with_user_filter()` following the `_run_assign_async` pattern
- Modified `list_numbers()` to use new helper when `--assigned-to` is provided
- Added 7 new unit tests in `TestNumbersListAssignedToFilter` test class

#### Files Modified
- `src/teams_phone/cli/numbers.py` - Added helper function (lines 267-314) and option (lines 343-348), modified logic (lines 381-399)
- `tests/unit/test_cli_numbers_list.py` - Added imports (lines 7, 11, 15) and test class with 7 tests (lines 158-269)

#### Key Decisions Made
- **Created separate helper function**: Rather than modifying `run_with_service`, created `_run_list_with_user_filter()` following the existing `_run_assign_async` pattern for multi-service operations
- **Conditional branching**: Only use multi-service helper when `--assigned-to` is provided; otherwise use existing `run_with_service` path for efficiency
- **User resolution first**: Resolve user to GUID before calling `NumberService.list_numbers()` with `assigned_to_user_id`

#### Patterns Discovered
- `_run_assign_async` pattern at `numbers.py:69-102` - Followed same structure for new helper
- Patching both UserService and NumberService in tests - Use `patch("teams_phone.cli.numbers.UserService")` and `patch("teams_phone.cli.numbers.NumberService")`
- `mock_cli_infrastructure` fixture patches infrastructure at both helpers and numbers module levels

#### Test Cases Added
1. `test_assigned_to_option_appears_in_help` - Verifies option in help output
2. `test_list_with_assigned_to_resolves_user_and_filters` - Main happy path test
3. `test_list_with_assigned_to_short_option` - Verifies `-u` short form works
4. `test_list_with_assigned_to_user_not_found` - Error handling with exit code 4
5. `test_list_with_assigned_to_combined_with_other_filters` - Works with --status, --city, --type
6. `test_list_with_assigned_to_json_output` - JSON output format correct
7. `test_list_with_assigned_to_empty_result` - Shows info message when no numbers match

#### Open Items for Next Agent
- [x] Subtask 2.2 is now complete
- [x] Subtask 2.3 is marked pending but tests were already written in 2.1 - may need status update
- [ ] Subtask 2.4 CLI tests completed as part of this subtask - may need status update
- [ ] Parent task 2 may now be ready to close if all acceptance criteria met

#### Gotchas and Warnings
- The new helper `_run_list_with_user_filter` creates services internally, so tests must patch `UserService` and `NumberService` classes, not instances
- Tests need `mock_cli_infrastructure` fixture first to patch CacheManager, AuthService, GraphClient

---

### Session: 2026-02-03 18:52 - Agent: claude-opus-4-5-20251101

**Subtask:** 2.3 - Write unit tests for NumberService.list_numbers() assigned_to_user_id filtering

**Status:** Complete (tests were already implemented in subtask 2.1)

#### What Was Done
- Verified existing tests in `TestNumberServiceAssignedToFilter` class pass (7/7 tests)
- Confirmed all acceptance criteria are covered by existing tests
- Updated task status from pending → done

#### Verification Summary
All acceptance criteria from subtask 2.3 are satisfied by tests implemented in subtask 2.1:

| Acceptance Criteria | Test Method | Line |
|---------------------|-------------|------|
| Filter by assigned user ID | `test_list_numbers_filters_by_assigned_user_id` | 468 |
| None returns all | `test_list_numbers_assigned_to_none_returns_all` | 503 |
| Empty list for no matches | `test_list_numbers_assigned_to_user_with_no_numbers_returns_empty_list` | 534 |
| Combined filters (status) | `test_list_numbers_combined_filters_status_and_assigned_to` | 567 |
| Combined filters (city) | `test_list_numbers_combined_filters_city_and_assigned_to` | 619 |

Plus 2 additional edge case tests:
- `test_list_numbers_assigned_to_filter_excludes_unassigned_numbers` (666)
- `test_list_numbers_assigned_to_filter_not_in_odata` (696)

#### Key Decisions Made
- **No new code needed**: Tests were proactively written during subtask 2.1 implementation
- **Status update only**: This is a bookkeeping task to mark the subtask complete

#### Open Items for Next Agent
- [x] Subtask 2.4 needs review - may also be complete (CLI tests in 2.2)
- [ ] Parent task 2 may be ready for final review

---

### Session: 2026-02-03 19:05 - Agent: claude-opus-4-5-20251101

**Subtask:** 2.4 - Write CLI integration tests for user resolution with UPN, display name, and object ID

**Status:** Implemented

#### What Was Done
- Reviewed existing `TestNumbersListAssignedToFilter` test class (7 tests implemented in 2.2)
- Found gaps in coverage: missing explicit tests for display name and object ID resolution
- Added 2 new tests to complete acceptance criteria coverage:
  - `test_list_with_assigned_to_display_name` - Tests display name resolution
  - `test_list_with_assigned_to_object_id` - Tests GUID/object ID resolution

#### Files Modified
- `tests/unit/test_cli_numbers_list.py` - Added 2 new tests (lines 369-455)

#### Key Decisions Made
- **Explicit tests for each identifier type**: While the underlying `resolve_user` method handles all identifier types the same way, the acceptance criteria explicitly called for tests with each format. Added tests that explicitly pass display name and GUID formats to verify the CLI correctly passes these to `resolve_user`.

#### Coverage Verification
All 5 acceptance criteria from subtask 2.4 are now satisfied:

| Acceptance Criteria | Test Method | Status |
|---------------------|-------------|--------|
| UPN resolution | `test_list_with_assigned_to_resolves_user_and_filters` | ✅ (from 2.2) |
| Display name resolution | `test_list_with_assigned_to_display_name` | ✅ NEW |
| Object ID/GUID resolution | `test_list_with_assigned_to_object_id` | ✅ NEW |
| NotFoundError handling | `test_list_with_assigned_to_user_not_found` | ✅ (from 2.2) |
| Combined filters | `test_list_with_assigned_to_combined_with_other_filters` | ✅ (from 2.2) |

Total tests in class: 9 (7 from 2.2 + 2 new)

#### Test Results
All 9 tests in `TestNumbersListAssignedToFilter` pass:
- All quality checks pass (ruff check, mypy, ruff format)
- Full test file (21 tests) passes

#### Open Items for Next Agent
- [x] All subtasks (2.1, 2.2, 2.3, 2.4) are now complete
- [ ] Parent task 2 is ready for final review and status update

---
