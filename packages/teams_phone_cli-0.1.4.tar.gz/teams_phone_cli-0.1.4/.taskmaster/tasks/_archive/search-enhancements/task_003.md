# Task ID: 3

**Title:** Implement wildcard pattern support for locations search

**Status:** pending

**Dependencies:** None

**Priority:** high

**Description:** Add wildcard pattern matching (`*`) support to the `locations search` command, using the existing `match_pattern()` function from utils.py. When no wildcards are present, maintain existing substring search behavior.

**Details:**

**Location:** `src/teams_phone/cli/locations.py`

**Helper Function:** Add wildcard detection at module level:
```python
from teams_phone.utils import match_pattern

def _has_wildcard(query: str) -> bool:
    """Check if query contains wildcard characters."""
    return "*" in query

def _text_matches_pattern(text: str | None, pattern: str) -> bool:
    """Check if text matches pattern (supports wildcards).
    
    Wildcards use * for any characters. Without wildcards,
    performs substring search.
    """
    if text is None:
        return False
    if not _has_wildcard(pattern):
        return pattern.lower() in text.lower()
    # Use regex pattern matching for wildcards
    import re
    # Convert wildcards to regex: * -> .*
    regex_pattern = re.escape(pattern).replace(r"\*", ".*")
    return bool(re.search(regex_pattern, text, re.IGNORECASE))
```

**Update `_location_matches_query` function:**
```python
def _location_matches_query(
    loc: EmergencyLocation, query: str, field: SearchField | None
) -> bool:
    field_values: dict[SearchField | None, list[str | None]] = {
        SearchField.NAME: [loc.description],
        SearchField.ADDRESS: [loc.address],
        SearchField.CITY: [loc.city],
        SearchField.COMPANY: [loc.company_name],
        None: [loc.description, loc.address, loc.city, loc.company_name],
    }
    values_to_check = field_values.get(field, [])
    return any(_text_matches_pattern(value, query) for value in values_to_check)
```

**Update Help Text:**
```python
query: str = typer.Argument(
    ...,
    help="Search term (partial match or wildcards: 'Main*', '*HQ').",
),
```

**Test Strategy:**

**Unit Tests:**
1. Test `locations search "Main*"` matches "Main Office", "Main Street"
2. Test `locations search "*HQ"` matches "Seattle HQ", "NYC HQ"
3. Test `locations search "*central*"` matches "Central Office", "NY Central"
4. Test pattern applies to all searchable fields (description, city, address, company)
5. Test existing substring search works when no wildcards present
6. Test case-insensitive wildcard matching
7. Test with `--field` option combined with wildcards

**Test File:** `tests/unit/test_cli_locations.py`

**Example Test:**
```python
def test_search_locations_wildcard_prefix(cli_runner, mock_locations):
    result = cli_runner.invoke(["locations", "search", "Main*"])
    assert result.exit_code == 0
    assert "Main Office" in result.output
    assert "Main Street" in result.output
    assert "Annex Building" not in result.output
```

---

## Implementation Notes

### Session: 2026-02-03 16:50 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Added `re` module import at module level in `locations.py:9`
- Implemented `_has_wildcard()` helper function at `locations.py:85-87`
- Implemented `_text_matches_pattern()` helper function at `locations.py:90-111`
- Updated `_location_matches_query()` to use new pattern matching at `locations.py:114-135`
- Updated query argument help text to mention wildcards at `locations.py:279`
- Updated `search_locations` command to pass query directly (not lowercased) since `_text_matches_pattern` handles case-insensitivity internally
- Added 12 comprehensive unit tests in `TestLocationsSearchWildcard` class at `tests/unit/test_cli_locations.py:665-890`

#### Key Decisions Made
- **Did NOT reuse `match_pattern()` from utils.py**: The recon report warned that `match_pattern()` is phone-number specific (normalizes by removing non-digits). Created text-specific `_text_matches_pattern()` instead.
- **Regex import at module level**: Per conventions, imported `re` at module top rather than inside functions.
- **Empty pattern returns False**: Consistent with existing `match_pattern()` behavior.
- **Single star (`*`) matches everything**: Converts to `.*` regex which matches any text.

#### Patterns Discovered
- Factory `make_location()` defaults to address "123 Main St" - test data must explicitly override address when testing patterns to avoid unintended matches.

#### Open Items for Next Agent
- None - task is complete.

#### Gotchas and Warnings
- When writing tests for wildcard prefix matching (e.g., `Main*`), ensure test locations that should NOT match don't have "Main" in their default address field.

---
