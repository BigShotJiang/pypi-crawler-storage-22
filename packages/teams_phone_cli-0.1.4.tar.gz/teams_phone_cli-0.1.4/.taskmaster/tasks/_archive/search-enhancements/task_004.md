# Task ID: 4

**Title:** Implement wildcard pattern support for users search

**Status:** pending

**Dependencies:** None

**Priority:** high

**Description:** Add wildcard pattern matching (`*`) support to the `users search` command for display name searches. When wildcards are detected, fetch broader results and apply client-side pattern matching while preserving server-side optimization for non-wildcard queries.

**Details:**

**Location:** `src/teams_phone/services/user_service.py`

**Add helper function:**
```python
import fnmatch

def _has_wildcard(query: str) -> bool:
    """Check if query contains wildcard characters."""
    return "*" in query

def _matches_wildcard(text: str | None, pattern: str) -> bool:
    """Check if text matches wildcard pattern (case-insensitive)."""
    if text is None:
        return False
    return fnmatch.fnmatch(text.lower(), pattern.lower())
```

**Update `search_users` method:**
```python
async def search_users(
    self,
    query: str,
    *,
    max_results: int = 25,
) -> list[UserConfiguration]:
    # Check for wildcard in display name search
    if _has_wildcard(query) and not query.startswith("+") and "@" not in query:
        # Wildcard display name search - fetch all users and filter client-side
        return await self._search_users_wildcard(query, max_results=max_results)
    
    # ... existing logic for phone/UPN/display name ...
```

**Add new method:**
```python
async def _search_users_wildcard(
    self,
    pattern: str,
    *,
    max_results: int = 25,
) -> list[UserConfiguration]:
    """Search users by wildcard pattern on display name.
    
    Fetches users from directory and applies client-side pattern matching.
    """
    # Fetch users from v1.0 /users endpoint with broad filter
    # Extract prefix before first * for server-side optimization
    prefix = pattern.split("*")[0]
    
    url = f"{GRAPH_API_V1_BASE}/users"
    params: dict[str, Any] = {
        "$select": "id,displayName",
        "$top": "999",  # Fetch larger set for client-side filtering
    }
    if prefix:
        params["$filter"] = f"startsWith(displayName, '{prefix}')"
    
    # Fetch and filter
    matching_users: list[dict[str, str | None]] = []
    async for item in self.graph_client.get_paginated_url(url, params=params):
        display_name = item.get("displayName")
        if _matches_wildcard(display_name, pattern):
            matching_users.append({"id": str(item["id"]), "displayName": display_name})
            if len(matching_users) >= max_results:
                break
    
    # Fetch Teams configurations for matched users
    users = []
    for dir_user in matching_users:
        try:
            user_config = await self.get_user(dir_user["id"])
            if user_config.display_name is None and dir_user.get("displayName"):
                user_config = user_config.model_copy(
                    update={"display_name": dir_user["displayName"]}
                )
            users.append(user_config)
        except NotFoundError:
            continue
    
    return users
```

**Update CLI help text:** `src/teams_phone/cli/users.py`
```python
query: str = typer.Argument(
    ...,
    help="Search term (partial match or wildcards: 'Jo*', '*admin*').",
),
```

**Test Strategy:**

**Unit Tests:**
1. Test `users search "Jo*"` matches "John Smith", "Joanna Chen"
2. Test `users search "*admin*"` matches users with "admin" in display name
3. Test `users search "*son"` matches "Johnson", "Wilson"
4. Test existing server-side startsWith optimization preserved for non-wildcard queries
5. Test auto-detection (phone vs UPN vs name) still works for non-wildcard queries
6. Test case-insensitive wildcard matching
7. Test performance with large result sets

**Test Files:**
- `tests/unit/test_user_service.py` - Service layer tests
- `tests/unit/test_cli_users.py` - CLI tests

**Mock Setup:**
- Mock get_paginated_url to return directory users
- Mock get_user to return Teams configuration for matched users

## Subtasks

### 4.1. Add wildcard detection and matching helper functions to user_service.py

**Status:** pending  
**Dependencies:** None  

Create _has_wildcard() and _matches_wildcard() helper functions at module level in user_service.py for detecting wildcard patterns and performing case-insensitive fnmatch-based pattern matching.

**Details:**

Add two private helper functions at module level in src/teams_phone/services/user_service.py:

1. `_has_wildcard(query: str) -> bool`: Returns True if query contains '*' character. Simple check: `return '*' in query`

2. `_matches_wildcard(text: str | None, pattern: str) -> bool`: Performs case-insensitive pattern matching using fnmatch.fnmatch(). Returns False if text is None, otherwise converts both text and pattern to lowercase and returns fnmatch result.

Add `import fnmatch` at the top of the file. Place these functions after the existing `_strip_odata_metadata()` helper function (around line 29) to keep module-level helpers grouped together.

### 4.2. Implement _search_users_wildcard method in UserService

**Status:** pending  
**Dependencies:** 4.1  

Add a new private async method _search_users_wildcard() that fetches directory users with optional prefix-based server-side filtering and applies client-side wildcard pattern matching before fetching Teams configurations.

**Details:**

Add `_search_users_wildcard` method to UserService class (after _search_directory_users, around line 262):

1. Extract prefix before first '*' for server-side optimization: `prefix = pattern.split('*')[0]`
2. Build URL using GRAPH_API_V1_BASE/users with params: $select='id,displayName', $top='999'
3. If prefix is non-empty, add $filter: `startsWith(displayName, '{prefix}')`
4. Use get_paginated_url to iterate results, calling _matches_wildcard on each displayName
5. Collect matching users into list[dict[str, str | None]] until max_results reached
6. For each matched directory user, call self.get_user(user_id) wrapped in try/except NotFoundError
7. If user_config.display_name is None, inject it from the directory result using model_copy
8. Return list[UserConfiguration]

This follows the existing two-stage pattern in search_users for display name search (lines 326-359).

### 4.3. Update search_users to route wildcard display name queries to _search_users_wildcard

**Status:** pending  
**Dependencies:** 4.1, 4.2  

Modify the search_users() method to detect wildcard patterns in display name queries and route them to the new _search_users_wildcard method while preserving existing behavior for phone/UPN/non-wildcard queries.

**Details:**

Update search_users method in UserService (lines 263-359) to add wildcard detection at the beginning of the display name branch:

1. Keep existing logic for phone number detection (line 290: `if query.startswith('+') or re.match(r'^\d+$', query)`)
2. Keep existing logic for UPN detection (line 310: `elif '@' in query`)
3. In the else branch (display name search, line 326), add wildcard detection BEFORE calling _search_directory_users:
   ```python
   else:
       # Check for wildcard in display name search
       if _has_wildcard(query):
           return await self._search_users_wildcard(query, max_results=max_results)
       # Existing non-wildcard display name logic continues...
   ```

This ensures wildcards with '+' or '@' are treated as phone/UPN searches (existing behavior), only display name queries get wildcard support.

### 4.4. Update CLI help text to document wildcard support for users search

**Status:** pending  
**Dependencies:** None  

Update the help text for the query argument in the users search command to indicate wildcard pattern support with examples.

**Details:**

In src/teams_phone/cli/users.py, update the search_users command's query argument help text (line 321-324):

Change from:
```python
query: str = typer.Argument(
    ...,
    help="Search term (partial match supported).",
),
```

To:
```python
query: str = typer.Argument(
    ...,
    help="Search term (partial match or wildcards: 'Jo*', '*admin*').",
),
```

This documents the wildcard feature without changing any functional behavior. The help text is concise and provides two practical examples showing leading and surrounding wildcard usage.

### 4.5. Write comprehensive unit tests for wildcard pattern search functionality

**Status:** pending  
**Dependencies:** 4.1, 4.2, 4.3  

Create thorough unit tests covering all wildcard pattern scenarios including prefix patterns, suffix patterns, middle patterns, edge cases, and integration with existing search behavior.

**Details:**

Add new test class TestUserServiceWildcardSearch to tests/unit/test_user_service.py with the following test cases:

1. test_search_wildcard_prefix_pattern: 'Jo*' matches 'John Smith', 'Joanna Chen', not 'Mary Johnson'
2. test_search_wildcard_suffix_pattern: '*son' matches 'Johnson', 'Wilson', not 'Sonny'
3. test_search_wildcard_contains_pattern: '*admin*' matches 'Admin User', 'Site Administrator', 'admin'
4. test_search_wildcard_case_insensitive: 'JO*' matches 'john', 'JOHN', 'John'
5. test_search_wildcard_with_prefix_uses_server_filter: verify 'Jo*' sends startsWith filter
6. test_search_wildcard_without_prefix_no_filter: verify '*admin*' sends no $filter
7. test_search_wildcard_respects_max_results: stops after max_results matches
8. test_search_wildcard_skips_users_without_teams_config: NotFoundError users excluded
9. test_search_wildcard_injects_display_name: Teams API None -> directory displayName used
10. test_search_non_wildcard_still_uses_starts_with: 'John' uses _search_directory_users

Use existing mock patterns from TestUserServiceSearchUsers class. Mock get_paginated_url for directory search and get for Teams config fetches.

---

## Implementation Notes

### Session: 2026-02-03 - Agent: claude-opus-4-5-20251101

**Subtask:** 4.1 - Add wildcard detection and matching helper functions

**Status:** Implemented

#### What Was Done
- Added `import fnmatch` to imports section in `src/teams_phone/services/user_service.py`
- Created `_has_wildcard(query: str) -> bool` helper function that checks for `*` in query
- Created `_matches_wildcard(text: str | None, pattern: str) -> bool` helper function using fnmatch with case-insensitive matching
- Added 16 comprehensive unit tests in `tests/unit/test_user_service.py` class `TestWildcardHelpers`

#### Key Decisions Made
- **fnmatch over regex**: Used `fnmatch.fnmatch()` as specified in task, which is simpler than the regex approach used in `cli/locations.py`. This keeps the implementation straightforward for shell-style glob patterns.
- **Explicit lowercase conversion**: Both text and pattern are converted to lowercase before matching to ensure consistent case-insensitive behavior across platforms (fnmatch behavior varies by OS).
- **Test placement**: Added test class `TestWildcardHelpers` before `TestUserServiceInit` to group module-level helper tests near the top of the test file.

#### Patterns Discovered
- Existing helper pattern from `_strip_odata_metadata()` at line 21-28: module-level private functions with docstrings
- Test class structure follows pattern from existing `TestUserServiceInit` class

#### Files Changed
- `src/teams_phone/services/user_service.py:9-10` - Added fnmatch import
- `src/teams_phone/services/user_service.py:31-56` - Added `_has_wildcard()` and `_matches_wildcard()` functions
- `tests/unit/test_user_service.py:15-18` - Updated imports to include new helper functions
- `tests/unit/test_user_service.py:54-119` - Added `TestWildcardHelpers` test class with 16 tests

#### Open Items for Next Agent
- [ ] Subtask 4.2: Implement `_search_users_wildcard` method using these helpers
- [ ] Subtask 4.3: Update `search_users` routing to use wildcard helpers
- [ ] Subtask 4.4: Update CLI help text
- [ ] Subtask 4.5: Write integration tests for wildcard search

#### Gotchas and Warnings
- The helpers are now exported from `user_service.py` and tested directly - they need to remain accessible for subtask 4.2/4.3 to use
- fnmatch treats `?` as single-character wildcard - task only specifies `*` support, so `?` behavior is implicit but untested

---

### Session: 2026-02-03 - Agent: claude-opus-4-5-20251101

**Subtask:** 4.4 - Update CLI help text to document wildcard support

**Status:** Implemented

#### What Was Done
- Updated help text for `query` argument in `users search` command
- Changed from `"Search term (partial match supported)."` to `"Search term (partial match or wildcards: 'Jo*', '*admin*')."`
- Verified with `uv run python -m teams_phone users search --help`

#### Key Decisions Made
- **Concise examples**: Used `'Jo*'` and `'*admin*'` as examples to demonstrate both prefix and contains patterns in a compact format
- **Follows existing pattern**: Help text style matches similar wildcard documentation in `locations.py` and `numbers.py`

#### Patterns Discovered
- Wildcard help text patterns exist in other commands:
  - `locations.py:288`: `"Search term. Use * as wildcard (e.g., 'Main*', '*HQ', '*central*')."`
  - `numbers.py:566`: `"Search pattern (supports wildcards: 206*, *1234, *555*)."`

#### Files Changed
- `src/teams_phone/cli/users.py:323` - Updated help text string

#### Open Items for Next Agent
- [ ] Subtask 4.2: Implement `_search_users_wildcard` method
- [ ] Subtask 4.3: Update `search_users` routing
- [ ] Subtask 4.5: Write integration tests for wildcard search

#### Gotchas and Warnings
- This is a documentation-only change - the actual wildcard functionality (4.2, 4.3) is not yet implemented
- Help text documents feature before full implementation is complete (acceptable per task specification)

---

### Session: 2026-02-03 19:45 - Agent: claude-opus-4-5-20251101

**Subtask:** 4.2 - Implement _search_users_wildcard method in UserService

**Status:** Implemented

#### What Was Done
- Added `_search_users_wildcard()` async method to UserService class in `src/teams_phone/services/user_service.py`
- Added two helper methods to keep complexity under linting threshold (C901):
  - `_fetch_directory_users_by_pattern()` - Fetches directory users matching wildcard pattern
  - `_fetch_teams_configs_for_directory_users()` - Fetches Teams configs and injects displayName
- Added 7 comprehensive unit tests in `TestUserServiceSearchUsersWildcard` test class

#### Key Decisions Made
- **Refactored for complexity**: Initial implementation exceeded ruff's C901 complexity threshold (11 > 10). Split into three methods to maintain clean code.
- **Reusable helper**: `_fetch_teams_configs_for_directory_users()` can potentially be reused by the existing display name search branch in `search_users()` in a future refactor.
- **Follows existing patterns**: Copied structure from `_search_directory_users()` and the for-loop pattern from `search_users()` display name branch.
- **$top=999 fixed**: Used hardcoded $top=999 for the directory fetch (as specified in task), with max_results controlling how many matching users are collected client-side.

#### Patterns Discovered
- **Two-stage search pattern**: Directory users fetched via v1.0 /users endpoint, then Teams configs fetched individually via get_user(). This is the existing pattern in search_users (lines 357-390).
- **model_copy for immutable updates**: Pydantic models use `model_copy(update={...})` rather than direct mutation.
- **NotFoundError handling**: Users in directory without Teams config are silently skipped (not an error condition).

#### Files Changed
- `src/teams_phone/services/user_service.py:294-390` - Added three new methods:
  - `_search_users_wildcard()` - Main entry point, orchestrates the two-stage search
  - `_fetch_directory_users_by_pattern()` - Fetches and filters directory users
  - `_fetch_teams_configs_for_directory_users()` - Fetches Teams configs for matched users
- `tests/unit/test_user_service.py:893-1000` - Added `TestUserServiceSearchUsersWildcard` class with 7 tests

#### Tests Added
1. `test_prefix_pattern_applies_server_filter` - Verifies $filter applied for 'Jo*'
2. `test_contains_pattern_no_server_filter` - Verifies no $filter for '*admin*'
3. `test_returns_only_matching_users` - Verifies client-side wildcard matching works
4. `test_respects_max_results` - Verifies stops at max_results limit
5. `test_skips_users_without_teams_config` - Verifies NotFoundError handling
6. `test_injects_display_name_from_directory` - Verifies displayName injection
7. `test_returns_empty_list_when_no_matches` - Verifies empty result handling

#### Open Items for Next Agent
- [ ] Subtask 4.3: Update `search_users` to route wildcard queries to `_search_users_wildcard`
- [ ] Subtask 4.5: Write additional integration tests for end-to-end wildcard search

#### Gotchas and Warnings
- The method is private (`_search_users_wildcard`) and not yet called by `search_users` - subtask 4.3 will add the routing
- The `_fetch_teams_configs_for_directory_users()` helper duplicates some logic from `search_users` display name branch (lines 370-388) - could be refactored to reuse this helper in a future cleanup
- Pattern like `*` (just wildcard) will fetch ALL directory users with no filter - could be slow in large tenants

---

### Session: 2026-02-03 19:55 - Agent: claude-opus-4-5-20251101

**Subtask:** 4.3 - Update search_users to route wildcard display name queries to _search_users_wildcard

**Status:** Implemented

#### What Was Done
- Added wildcard routing logic at the start of the `else` branch (display name search) in `search_users()` method
- Added 4 new routing verification tests in `TestUserServiceSearchUsers` class
- Added `# noqa: C901` comment to `search_users` method (routing logic pushes complexity to 11 > 10)

#### Key Decisions Made
- **Routing inside else branch**: Wildcard detection is INSIDE the else branch, not at the top of the method. This ensures phone queries like `+1555*` and UPN queries like `admin@*` continue to route to phone/UPN search (not treated as wildcards).
- **Early return pattern**: Uses `if _has_wildcard(query): return await self._search_users_wildcard(...)` for clean routing with no code duplication.
- **noqa for complexity**: The routing logic in `search_users` now has 4 branches (phone, UPN, wildcard, non-wildcard display name). Added `# noqa: C901 - Routing logic for phone/UPN/wildcard/display-name searches` per project convention.

#### Patterns Discovered
- The project uses `# noqa: C901` with explanatory comments for complex functions (see `graph_client.py:561`, `bulk_operations.py:483`, etc.)
- Routing order matters: phone → UPN → display name (wildcard or non-wildcard)

#### Files Changed
- `src/teams_phone/services/user_service.py:399` - Added noqa comment to search_users definition
- `src/teams_phone/services/user_service.py:462-468` - Added wildcard routing in else branch
- `tests/unit/test_user_service.py:723-816` - Added 4 routing tests:
  - `test_search_wildcard_routes_to_wildcard_method`
  - `test_search_non_wildcard_routes_to_directory_search`
  - `test_search_phone_with_wildcard_routes_to_phone_search`
  - `test_search_upn_with_wildcard_routes_to_upn_search`

#### Tests Added
1. `test_search_wildcard_routes_to_wildcard_method` - Verifies `'Jo*'` uses v1.0 /users endpoint (wildcard path)
2. `test_search_non_wildcard_routes_to_directory_search` - Verifies `'John'` uses startsWith filter (non-wildcard path)
3. `test_search_phone_with_wildcard_routes_to_phone_search` - Verifies `'+1555*'` routes to phone search (telephoneNumber filter)
4. `test_search_upn_with_wildcard_routes_to_upn_search` - Verifies `'admin@*'` routes to UPN search (userPrincipalName filter)

#### Open Items for Next Agent
- [ ] Subtask 4.5: Write additional integration tests for end-to-end wildcard search

#### Gotchas and Warnings
- Wildcard in phone/UPN queries is NOT treated as a wildcard pattern - it's treated as a literal character in the phone/UPN search. This is intentional per acceptance criteria.
- The complexity increase (10 → 11) is minimal and the noqa is justified by the clear routing logic.

---

### Session: 2026-02-03 20:10 - Agent: claude-opus-4-5-20251101

**Subtask:** 4.5 - Write comprehensive unit tests for wildcard pattern search functionality

**Status:** Implemented

#### What Was Done
- Analyzed existing tests in `TestUserServiceSearchUsersWildcard` class against the 10 required test cases
- Added 4 new tests to complete coverage of all 10 acceptance criteria
- Renamed `test_returns_only_matching_users` to `test_search_wildcard_prefix_pattern` with enhanced assertions for negative case

#### Test Coverage Assessment
| Required Test | Implementation | Status |
|--------------|----------------|--------|
| 1. `test_search_wildcard_prefix_pattern` | Added new test with negative case | ✅ NEW |
| 2. `test_search_wildcard_suffix_pattern` | Added new test | ✅ NEW |
| 3. `test_search_wildcard_contains_pattern` | Added new test | ✅ NEW |
| 4. `test_search_wildcard_case_insensitive` | Added new test | ✅ NEW |
| 5. `test_search_wildcard_with_prefix_uses_server_filter` | Existing: `test_prefix_pattern_applies_server_filter` | ✅ EXISTS |
| 6. `test_search_wildcard_without_prefix_no_filter` | Existing: `test_contains_pattern_no_server_filter` | ✅ EXISTS |
| 7. `test_search_wildcard_respects_max_results` | Existing: `test_respects_max_results` | ✅ EXISTS |
| 8. `test_search_wildcard_skips_users_without_teams_config` | Existing: `test_skips_users_without_teams_config` | ✅ EXISTS |
| 9. `test_search_wildcard_injects_display_name` | Existing: `test_injects_display_name_from_directory` | ✅ EXISTS |
| 10. `test_search_non_wildcard_still_uses_starts_with` | Existing: `test_search_non_wildcard_routes_to_directory_search` (in TestUserServiceSearchUsers) | ✅ EXISTS |

#### Key Decisions Made
- **Kept existing test names**: Existing tests have semantic equivalents to the specified names. Renaming would break CI history and provide no functional benefit.
- **Enhanced prefix test**: Replaced `test_returns_only_matching_users` with `test_search_wildcard_prefix_pattern` that includes the negative case ('Mary Johnson' should NOT match 'Jo*').
- **Test class naming**: Kept existing `TestUserServiceSearchUsersWildcard` class name rather than renaming to `TestUserServiceWildcardSearch` - the existing name is more descriptive.

#### Patterns Discovered
- Async generator mock pattern: `async def mock_paginated_url(url, *, params=None, **kwargs) -> AsyncIterator[dict[str, Any]]`
- NotFoundError handling in mock_get: Pattern from line 1145 for simulating users without Teams config

#### Files Changed
- `tests/unit/test_user_service.py:1042-1183` - Replaced `test_returns_only_matching_users` with 4 new comprehensive tests:
  - `test_search_wildcard_prefix_pattern` - Tests 'Jo*' matches John/Joanna, NOT Mary Johnson
  - `test_search_wildcard_suffix_pattern` - Tests '*son' matches Johnson/Wilson, NOT Sonny
  - `test_search_wildcard_contains_pattern` - Tests '*admin*' matches Admin User/Site Administrator/admin
  - `test_search_wildcard_case_insensitive` - Tests 'JO*' matches john/JOHN/John

#### Tests Added
All 4 new tests in `TestUserServiceSearchUsersWildcard`:
1. `test_search_wildcard_prefix_pattern` - Validates prefix pattern matching with negative case
2. `test_search_wildcard_suffix_pattern` - Validates suffix pattern matching with negative case
3. `test_search_wildcard_contains_pattern` - Validates contains pattern matching with negative case
4. `test_search_wildcard_case_insensitive` - Validates case-insensitive matching across mixed case inputs

#### Quality Gates Passed
- [x] All 59 tests in test_user_service.py pass
- [x] ruff check passes with no errors
- [x] mypy source check passes (test file has pre-existing import-untyped warnings)

#### Open Items for Next Agent
- Parent task 4 can now be marked as done - all 5 subtasks (4.1-4.5) are complete

#### Gotchas and Warnings
- Test names don't exactly match specification (e.g., `test_prefix_pattern_applies_server_filter` vs `test_search_wildcard_with_prefix_uses_server_filter`) but provide equivalent coverage
- The `TestUserServiceSearchUsersWildcard` class now has 10 tests total (4 new + 6 existing)
