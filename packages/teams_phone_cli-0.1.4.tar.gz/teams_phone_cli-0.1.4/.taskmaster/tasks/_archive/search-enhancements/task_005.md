# Task ID: 5

**Title:** Add performance warnings for large search operations

**Status:** pending

**Dependencies:** None

**Priority:** medium

**Description:** Display a warning message to stderr when search operations will filter more than 1000 items client-side. Add `--quiet` flag to suppress the warning.

**Details:**

**Constants:** `src/teams_phone/constants.py`
```python
LARGE_RESULT_THRESHOLD = 1000
"""Warning threshold for client-side filtering operations."""
```

**CLI Updates:** Add `--quiet` flag to search commands

`src/teams_phone/cli/numbers.py` - `search_numbers`:
```python
@numbers_app.command("search")
def search_numbers(
    ctx: typer.Context,
    pattern: str = typer.Argument(...),
    limit: int = typer.Option(25, "--limit", "-l"),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        help="Suppress performance warnings.",
    ),
) -> None:
```

**Service Layer Changes:** `src/teams_phone/services/number_service.py`

Return item count from search to enable warnings:
```python
async def search_numbers(
    self,
    pattern: str,
    *,
    max_results: int = 100,
) -> tuple[list[NumberAssignment], int]:  # Return (results, total_fetched)
    all_numbers = await self.list_numbers()
    total_fetched = len(all_numbers)
    # ... filter logic ...
    return results, total_fetched
```

**CLI Warning Output:**
```python
if total_fetched > LARGE_RESULT_THRESHOLD and not quiet:
    formatter.console.print(
        f"Filtering {total_fetched:,} numbers for pattern matching...",
        style="yellow",
        stderr=True,
    )
```

**Note:** Warning goes to stderr (not stdout) to avoid breaking piped output. Use `console.print(..., stderr=True)` in Rich.

**Apply to:**
- `numbers search` command
- `locations search` command (if filtering large CSV)
- `users search` wildcard queries

**Test Strategy:**

**Unit Tests:**
1. Test warning appears when filtering >1000 items
2. Test warning NOT shown when filtering <=1000 items
3. Test `--quiet` flag suppresses warning
4. Test warning goes to stderr, not stdout (verify pipe-safe)
5. Test warning shows correct count with thousands separator
6. Test warning appears BEFORE filtering begins (timing)
7. Test JSON mode does not show warning

**Test File:** `tests/unit/test_cli_numbers_list.py`, `tests/unit/test_cli_locations.py`

**Example Test:**
```python
def test_search_numbers_large_result_warning(cli_runner, mock_large_inventory):
    result = cli_runner.invoke(["numbers", "search", "206*"])
    assert "Filtering 5,234 numbers" in result.stderr
    assert result.exit_code == 0

def test_search_numbers_quiet_suppresses_warning(cli_runner, mock_large_inventory):
    result = cli_runner.invoke(["numbers", "search", "206*", "--quiet"])
    assert "Filtering" not in result.stderr
```

## Subtasks

### 5.1. Add LARGE_RESULT_THRESHOLD constant and modify search_numbers to return total fetched count

**Status:** done  
**Dependencies:** None  

Add the LARGE_RESULT_THRESHOLD constant to constants.py and update NumberService.search_numbers() to return a tuple containing both the filtered results and the total fetched count, enabling the CLI to determine when to display performance warnings.

**Details:**

1. Add to `src/teams_phone/constants.py`:
```python
LARGE_RESULT_THRESHOLD = 1000
"""Warning threshold for client-side filtering operations."""
```

2. Modify `src/teams_phone/services/number_service.py` search_numbers method:
- Change return type from `list[NumberAssignment]` to `tuple[list[NumberAssignment], int]`
- Capture `total_fetched = len(all_numbers)` after fetching all numbers
- Return `(results, total_fetched)` instead of just `results`

3. Update any existing callers of search_numbers to handle the tuple return type (likely just the CLI command in numbers.py)

### 5.2. Add --quiet flag to CLI search commands and implement stderr warning output

**Status:** done
**Dependencies:** 5.1  

Add the --quiet/-q flag to numbers search, locations search, and users search commands. Implement the performance warning that displays to stderr when filtering more than LARGE_RESULT_THRESHOLD items, respecting the quiet flag.

**Details:**

1. Update `src/teams_phone/cli/numbers.py` search_numbers command:
- Add `quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress performance warnings.")`
- After calling service.search_numbers(), check if `total_fetched > LARGE_RESULT_THRESHOLD and not quiet`
- Display warning via `formatter.console.print(f"Filtering {total_fetched:,} numbers for pattern matching...", style="yellow", stderr=True)`

2. Apply same pattern to `src/teams_phone/cli/locations.py` search command (if it filters large CSV data)

3. Apply same pattern to `src/teams_phone/cli/users.py` search command for wildcard queries

4. Import LARGE_RESULT_THRESHOLD from constants in each CLI module

5. Ensure warning uses thousands separator ({:,}) for readability

### 5.3. Write unit tests verifying warning appears/suppressed correctly and goes to stderr

**Status:** pending  
**Dependencies:** 5.1, 5.2  

Create comprehensive unit tests for the performance warning feature, verifying that warnings appear when threshold is exceeded, are suppressed with --quiet, and are correctly routed to stderr to avoid breaking piped output.

**Details:**

1. Create/update test file `tests/unit/cli/test_numbers_search_warnings.py`:
- Test warning appears when filtering >1000 items (mock service to return large total_fetched)
- Test warning NOT shown when filtering <=1000 items
- Test --quiet flag suppresses warning even with >1000 items
- Test warning goes to stderr, not stdout (use capsys or capture stderr separately)
- Test warning shows correct count with thousands separator (e.g., "1,234" not "1234")
- Test warning message contains expected text

2. Use CliRunner from typer.testing with mix_stderr=False to separate stdout/stderr

3. Mock NumberService.search_numbers to return controlled (results, total_fetched) tuples

4. Add similar tests for locations search and users search commands if they implement warnings

---

## Implementation Notes

### Session: 2026-02-03 14:45 - Agent: claude-opus-4-5-20251101

**Status:** Implemented (Subtask 5.1)

#### What Was Done
- Added `LARGE_RESULT_THRESHOLD = 1000` constant to `src/teams_phone/constants.py` (line 51-55)
- Updated `NumberService.search_numbers()` return type from `list[NumberAssignment]` to `tuple[list[NumberAssignment], int]`
- Modified return statement to include `total_fetched = len(all_numbers)` before filtering
- Updated CLI caller in `src/teams_phone/cli/numbers.py:584` to unpack tuple: `(numbers, _total_fetched), _ = run_with_service(...)`
- Updated 12 tests in `tests/unit/test_number_service_read.py` (TestNumberServiceSearchNumbers class) to handle new tuple return
- Updated 5 CLI tests in `tests/unit/test_cli_numbers_show.py` (TestNumbersSearchCommand class) to mock tuple returns

#### Key Decisions Made
- Placed `LARGE_RESULT_THRESHOLD` in the "Cache and Timeout Settings" section of constants.py alongside other threshold constants
- Used underscore prefix `_total_fetched` in CLI to indicate the value is captured but not yet used (will be used in subtask 5.2)
- Added `total_fetched` assertions to all search tests to verify the new return value is accurate

#### Patterns Discovered
- CLI uses `run_with_service` helper which returns `(service_result, elapsed_time)` tuple - when service returns tuple, unpacking becomes nested: `(inner_tuple, elapsed) = run_with_service(...)`
- Test mocks for service methods need to return the full tuple: `AsyncMock(return_value=(results, total_fetched))`

#### Open Items for Next Agent
- [ ] Subtask 5.2: Add `--quiet` flag and implement stderr warning output using `total_fetched`
- [ ] Subtask 5.3: Write unit tests for warning display and suppression

#### Gotchas and Warnings
- The CLI test file `test_cli_numbers_show.py` had 5 tests mocking `search_numbers` - don't forget to update mock return values when changing service signatures
- The `total_fetched` count reflects ALL numbers fetched, even when `max_results` limits output - this is intentional for accurate performance warnings

---

### Session: 2026-02-03 20:45 - Agent: claude-opus-4-5-20251101

**Status:** Implemented (Subtask 5.2)

#### What Was Done
- Added `--quiet/-q` flag to `search_numbers` command in `src/teams_phone/cli/numbers.py`
- Added `--quiet/-q` flag to `search_locations` command in `src/teams_phone/cli/locations.py`
- Added `--quiet/-q` flag to `search_users` command in `src/teams_phone/cli/users.py`
- Added `LARGE_RESULT_THRESHOLD` import to numbers.py and locations.py
- Implemented warning output for numbers search using `total_fetched` from service return tuple
- Implemented warning output for locations search by capturing `len(all_locs)` before filtering
- Warning outputs to stderr using `Console(stderr=True).print(...)`
- Warning uses thousands separator via Python's `{:,}` format specifier

#### Files Changed
- `src/teams_phone/cli/numbers.py` - Added --quiet flag, import, warning logic
- `src/teams_phone/cli/locations.py` - Added --quiet flag, import, warning logic
- `src/teams_phone/cli/users.py` - Added --quiet flag only (warning deferred)

#### Key Decisions Made
- **Rich Console stderr**: Used `Console(stderr=True).print()` instead of `console.print(..., stderr=True)` because Rich's Console.print() doesn't have a `stderr` parameter - the Console itself is configured for stderr at construction
- **Users search warning deferred**: UserService.search_users doesn't return total_fetched count. Would require service changes to implement warning. Added --quiet flag for API consistency but skipped warning implementation. This is a candidate for a follow-up task.
- **Warning condition order**: Check `not cli_ctx.json_output` first to avoid creating Console instance when in JSON mode

#### Patterns Discovered
- Rich Console's stderr output is configured at construction: `Console(stderr=True)` not `console.print(stderr=True)`
- Local import of Console within the conditional block keeps it lazy and avoids import at module level
- Locations search computes `total_fetched = len(all_locs)` locally since it doesn't go through a service method that could return the count

#### Open Items for Next Agent
- [ ] Subtask 5.3: Write unit tests for warning display and suppression
- [ ] Consider adding `total_fetched` return to UserService.search_users for wildcard queries (separate task)

#### Gotchas and Warnings
- The task spec suggested `formatter.console.print(..., stderr=True)` but this doesn't work with Rich - must use a separate Console instance
- Users search has --quiet flag but no warning implementation - this is intentional, not a bug
- Warning message format: "Filtering X items for pattern matching..." where X is the total fetched count with thousands separator

---

### Session: 2026-02-03 21:30 - Agent: claude-opus-4-5-20251101

**Status:** Implemented (Subtask 5.3)

#### What Was Done
- Added `TestNumbersSearchWarnings` class to `tests/unit/test_cli_numbers_show.py` with 8 tests
- Added `TestLocationsSearchWarnings` class to `tests/unit/test_cli_locations.py` with 8 tests
- Added `LARGE_RESULT_THRESHOLD` import to both test files

#### Tests Created (16 total)
**Numbers search tests:**
1. `test_warning_appears_when_exceeds_threshold` - Verifies warning with >1000 items
2. `test_warning_not_shown_at_threshold` - Verifies no warning at exactly 1000 items
3. `test_warning_not_shown_below_threshold` - Verifies no warning with <1000 items
4. `test_quiet_flag_suppresses_warning` - Verifies --quiet suppresses warning
5. `test_warning_shows_thousands_separator` - Verifies "5,234" not "5234"
6. `test_json_output_no_warning` - Verifies JSON mode has no warning in stdout
7. `test_warning_contains_expected_text` - Verifies full message format
8. `test_warning_goes_to_stderr_not_stdout` - Verifies pipe-safe behavior

**Locations search tests:** Same 8 test cases mirrored for locations search

#### Key Decisions Made
- **Used `result.output` for warning assertions**: The CliRunner captures both stdout and stderr in `result.output`, while `result.stdout` contains only stdout. Tests use `result.output` to verify warnings appear and `result.stdout` to verify they don't pollute stdout.
- **Skipped users search warning tests**: Per recon notes, users search has --quiet flag but no warning implementation (deferred). Only tested that flag acceptance works.
- **Added tests to existing files**: Rather than creating new test files, added test classes to existing `test_cli_numbers_show.py` and `test_cli_locations.py` for consistency with project structure.
- **Used `LARGE_RESULT_THRESHOLD` constant in tests**: Imported constant from `teams_phone.constants` to keep tests in sync with implementation threshold.

#### Patterns Discovered
- **CliRunner output vs stdout**: The custom `CliRunner` in `tests/conftest.py` wraps results but `stdout` only gives stdout while `output` gives combined stdout+stderr. This is critical for testing stderr warnings.
- **Creating large mock datasets**: For locations tests, used list comprehension to create thousands of test locations: `[make_location(location_id=f"loc-{i}", ...) for i in range(N)]`
- **Mock pattern for search_numbers tuple**: `AsyncMock(return_value=(numbers_list, total_fetched_int))`

#### Files Changed
- `tests/unit/test_cli_numbers_show.py` - Added import, TestNumbersSearchWarnings class (8 tests)
- `tests/unit/test_cli_locations.py` - Added import, TestLocationsSearchWarnings class (8 tests)

#### Open Items for Next Agent
- [ ] Parent task 5 can now be marked complete - all subtasks done
- [ ] Consider adding `total_fetched` return to UserService.search_users for wildcard queries (separate task)

#### Gotchas and Warnings
- **stdout vs output distinction**: When testing stderr output, use `result.output` (combined) to verify presence and `result.stdout` to verify absence. The warning goes to stderr via `Console(stderr=True)`.
- **Existing mypy errors on test files**: Running `mypy tests/unit/...` shows import errors for teams_phone modules - this is a pre-existing issue with test file type checking, not related to changes. Source code (`mypy src/`) passes cleanly.
