# Task ID: 6

**Title:** Add --contains flag for substring matching in list filters

**Status:** pending

**Dependencies:** 1

**Priority:** medium

**Description:** Implement a `--contains` flag for list commands that enables substring matching on string filters like `--city`. By default (without `--contains`), filters use exact match for backward compatibility.

**Details:**

**CLI Changes:** Add `--contains` flag to list commands

`src/teams_phone/cli/numbers.py` - `list_numbers`:
```python
@numbers_app.command("list")
def list_numbers(
    ctx: typer.Context,
    # ... existing options ...
    contains: bool = typer.Option(
        False,
        "--contains",
        help="Enable substring matching for string filters (e.g., --city Sea matches 'Seattle').",
    ),
) -> None:
```

`src/teams_phone/cli/locations.py` - `list_locations`:
```python
@locations_app.command("list")
def list_locations(
    ctx: typer.Context,
    # ... existing options ...
    contains: bool = typer.Option(
        False,
        "--contains",
        help="Enable substring matching for string filters.",
    ),
) -> None:
```

**Service Layer Changes:** `src/teams_phone/services/number_service.py`

Add `contains` parameter to `list_numbers()`:
```python
async def list_numbers(
    self,
    *,
    city: str | None = None,
    contains: bool = False,  # New parameter
    # ... other params ...
) -> list[NumberAssignment]:
    # ...
    # Client-side city filter
    if city is not None:
        city_lower = city.lower()
        number_city = (number.city or "").lower()
        if contains:
            # Substring match
            if city_lower not in number_city:
                continue
        else:
            # Exact match (case-insensitive per task 1)
            if number_city != city_lower:
                continue
```

**Backward Compatibility:**
- Without `--contains`: exact match behavior (case-insensitive per task 1)
- With `--contains`: substring match
- Existing scripts using exact city names continue to work

**Apply to:**
- `numbers list --city`
- `locations list --city`

**Test Strategy:**

**Unit Tests:**
1. Test `numbers list --city Sea --contains` matches "Seattle"
2. Test `numbers list --city Sea` (without --contains) does NOT match "Seattle" (exact match)
3. Test `locations list --city New --contains` matches "New York", "New Jersey"
4. Test backward compatibility: `--city Seattle` still works without --contains
5. Test case-insensitive partial matching
6. Test empty string handling with --contains
7. Test JSON output with --contains flag

**Test Files:**
- `tests/unit/test_number_service_read.py`
- `tests/unit/test_cli_numbers_list.py`
- `tests/unit/test_cli_locations.py`

**Example Test:**
```python
async def test_list_numbers_city_contains(mock_graph_client):
    mock_numbers = [
        create_number_assignment(city="Seattle"),
        create_number_assignment(city="New Seattle"),
        create_number_assignment(city="Portland"),
    ]
    result = await service.list_numbers(city="Sea", contains=True)
    assert len(result) == 2  # Seattle and New Seattle
```

---

## Implementation Notes

### Session: 2026-02-03 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Added `contains: bool = False` parameter to `NumberService.list_numbers()` in `src/teams_phone/services/number_service.py:56`
- Updated city filter logic to support substring matching when `contains=True`
- Added `--contains` option to `numbers list` CLI command in `src/teams_phone/cli/numbers.py:344-348`
- Updated `_run_list_with_user_filter` helper to accept and pass `contains` parameter
- Added `--contains` option to `locations list` CLI command in `src/teams_phone/cli/locations.py:153-157`
- Updated locations city filter logic for substring matching when `contains=True`

#### Tests Added
- `tests/unit/test_number_service_read.py`:
  - `test_list_numbers_with_city_filter_contains_matches_substring`
  - `test_list_numbers_with_city_filter_contains_case_insensitive`
  - `test_list_numbers_with_city_filter_exact_match_default`
  - `test_list_numbers_with_city_filter_contains_false_explicit`
  - `test_list_numbers_with_city_filter_contains_handles_none_city`
- `tests/unit/test_cli_numbers_list.py`:
  - `test_list_with_contains_flag`
  - `test_list_without_contains_flag_defaults_false`
- `tests/unit/test_cli_locations.py`:
  - `test_list_with_contains_flag`
  - `test_list_without_contains_uses_exact_match`
  - `test_list_with_contains_case_insensitive`

#### Key Decisions Made
- `contains` defaults to `False` for backward compatibility
- Substring match uses Python's `in` operator after lowercasing both strings
- Pattern follows existing city filter logic with `(number.city or "").lower()` for None-safety

#### Patterns Discovered
- Service parameters use keyword-only syntax with `*,` separator
- CLI options use `typer.Option(False, "--flag-name", help="...")` pattern
- Filter tests follow `make_number_dict`/`make_location` factory pattern

#### Open Items for Next Agent
- None - task is complete

#### Gotchas and Warnings
- The `_run_list_with_user_filter` helper in numbers.py also needed the `contains` parameter added to its signature and passed through to the service
- Locations command implements city filtering inline in the CLI (not in a service layer), so the filter logic was added directly in locations.py

---
