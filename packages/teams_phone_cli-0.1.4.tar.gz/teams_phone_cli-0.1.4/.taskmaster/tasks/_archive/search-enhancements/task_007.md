# Task ID: 7

**Title:** Update CLI help text for all new options

**Status:** pending

**Dependencies:** 1, 2, 3, 4, 5, 6

**Priority:** low

**Description:** Update help text for all modified commands to document new wildcard support, --assigned-to filter, --contains flag, and --quiet option with usage examples.

**Details:**

**Files to Update:**

1. `src/teams_phone/cli/numbers.py`:
   - `list_numbers`: Update `--city` help to note case-insensitivity, document `--assigned-to` and `--contains`
   - `search_numbers`: Document `--quiet` flag, add wildcard examples to docstring

2. `src/teams_phone/cli/users.py`:
   - `search_users`: Add wildcard examples to help text and docstring

3. `src/teams_phone/cli/locations.py`:
   - `search_locations`: Add wildcard examples to help text and docstring
   - `list_locations`: Document `--contains` flag

**Help Text Updates:**

```python
# numbers.py - list_numbers
city: str | None = typer.Option(
    None,
    "--city",
    "-c",
    help="Filter by city (case-insensitive). Use --contains for partial match.",
),

assigned_to: str | None = typer.Option(
    None,
    "--assigned-to",
    "-u",
    help="Filter by assigned user (UPN, display name, or object ID).",
),

contains: bool = typer.Option(
    False,
    "--contains",
    help="Enable substring matching for --city filter (e.g., --city Sea matches 'Seattle').",
),

# numbers.py - search_numbers docstring
"""Search phone numbers by pattern.

Supports wildcards: '206*' (prefix), '*1234' (suffix), '*555*' (contains).
Note: Searches all numbers client-side; use --quiet to suppress progress warnings.
"""

# users.py - search_users
query: str = typer.Argument(
    ...,
    help="Search term. Supports wildcards for names: 'Jo*', '*admin*'.",
),

# locations.py - search_locations
query: str = typer.Argument(
    ...,
    help="Search term. Supports wildcards: 'Main*', '*HQ'.",
),
```

**Docstring Updates:**
Update command docstrings with Examples sections showing new functionality.

**Test Strategy:**

**Verification:**
1. Run `teams-phone numbers list --help` and verify all new options documented
2. Run `teams-phone numbers search --help` and verify wildcard examples shown
3. Run `teams-phone users search --help` and verify wildcard examples shown
4. Run `teams-phone locations search --help` and verify wildcard examples shown
5. Run `teams-phone locations list --help` and verify --contains documented

**Automated Tests:**
- Add help text assertions to existing CLI tests
- Verify no typos or missing options in help output

**Manual Review:**
- Ensure help text is consistent in style across all commands
- Verify examples are realistic and work as documented

---

## Implementation Notes

### Session: 2026-02-03 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Verified all CLI help text is already correctly documented (tasks 1-6 updated help during implementation)
- `numbers list --help`: Shows `--city`, `--contains` with substring example, `--assigned-to` with full help
- `numbers search --help`: Shows wildcard examples (206*, *1234, *555*) and `--quiet`/`-q` flag
- `users search --help`: Shows wildcard examples (Jo*, *admin*) and `--quiet`/`-q` flag
- `locations list --help`: Shows `--city` and `--contains` with substring example
- `locations search --help`: Shows wildcard examples (Main*, *HQ, *central*) and `--quiet`/`-q` flag
- Added 8 new help text assertion tests to verify REQ-013 requirements:
  - `test_cli_numbers_list.py`: `test_contains_option_appears_in_help`
  - `test_cli_numbers_show.py`: `test_search_pattern_help_shows_wildcards`, `test_search_quiet_option_appears_in_help`
  - `test_cli_locations.py`: `test_contains_option_appears_in_help`, `test_search_query_help_shows_wildcards`, `test_search_quiet_option_appears_in_help`
  - `test_cli_users.py`: `test_search_query_help_shows_wildcards`, `test_search_quiet_option_appears_in_help`

#### Key Decisions Made
- No source code changes needed - help text was already updated during feature implementation (tasks 1-6)
- Focus on test coverage to verify help text is present and includes expected content
- Added tests following existing pattern from `test_assigned_to_option_appears_in_help` at `test_cli_numbers_list.py:187-192`

#### Patterns Discovered
- Help text testing pattern: `runner.invoke(app, ["command", "subcommand", "--help"])` then assert expected strings in `result.stdout`
- Help text style: Concise description with examples in parentheses, no trailing period

#### Open Items for Next Agent
- None - all acceptance criteria met

#### Gotchas and Warnings
- mypy is only configured to check `src/` per pyproject.toml, not test files
- Test files need to be formatted with `ruff format` after editing
