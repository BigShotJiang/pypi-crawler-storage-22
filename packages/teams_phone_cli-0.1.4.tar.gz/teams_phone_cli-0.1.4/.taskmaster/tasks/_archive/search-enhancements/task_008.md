# Task ID: 8

**Title:** Add integration tests for search enhancements

**Status:** pending

**Dependencies:** 1, 2, 3, 4, 5, 6

**Priority:** medium

**Description:** Create integration tests that verify the end-to-end behavior of all search enhancements, including case-insensitive filters, wildcard patterns, --assigned-to lookup, and --contains flag.

**Details:**

**Test File:** `tests/integration/cli/test_search_enhancements.py`

**Test Scenarios:**

```python
import pytest
from typer.testing import CliRunner

@pytest.mark.integration
class TestSearchEnhancements:
    """Integration tests for search enhancement features."""
    
    def test_numbers_list_city_case_insensitive(self, cli_runner, live_config):
        """Verify --city filter is case-insensitive."""
        # Run with lowercase city name
        result = cli_runner.invoke(["numbers", "list", "--city", "seattle", "--limit", "5"])
        assert result.exit_code == 0
        # If we have Seattle numbers, they should appear
    
    def test_numbers_list_assigned_to_upn(self, cli_runner, live_config, test_user_upn):
        """Verify --assigned-to works with UPN."""
        result = cli_runner.invoke(["numbers", "list", "--assigned-to", test_user_upn])
        assert result.exit_code == 0
        # Numbers returned should be assigned to that user
    
    def test_locations_search_wildcard(self, cli_runner, live_config):
        """Verify wildcard pattern matching in locations search."""
        result = cli_runner.invoke(["locations", "search", "*Office*"])
        assert result.exit_code == 0
    
    def test_users_search_wildcard(self, cli_runner, live_config):
        """Verify wildcard pattern matching in users search."""
        result = cli_runner.invoke(["users", "search", "J*", "--limit", "5"])
        assert result.exit_code == 0
    
    def test_numbers_list_contains_partial_city(self, cli_runner, live_config):
        """Verify --contains enables partial city matching."""
        result = cli_runner.invoke(["numbers", "list", "--city", "Sea", "--contains", "--limit", "5"])
        assert result.exit_code == 0
```

**Contract Tests:** Add to `tests/contract/test_number_contracts.py`
- Test that resolved user ID format is valid GUID
- Test that assignment_target_id can be used for filtering

**Fixtures:**
- Reuse existing integration test fixtures from `tests/integration/cli/conftest.py`
- Add test data setup if needed for predictable results

**Test Strategy:**

**Integration Test Requirements:**
1. Tests require live API access (mark with `@pytest.mark.integration`)
2. Tests should be idempotent and not modify tenant data
3. Use `--limit` to keep test runtime reasonable
4. Skip tests gracefully if required test data not present

**Test Coverage Matrix:**
| Feature | Unit Test | Integration Test |
|---------|-----------|------------------|
| Case-insensitive city | ✓ | ✓ |
| --assigned-to filter | ✓ | ✓ |
| Locations wildcard | ✓ | ✓ |
| Users wildcard | ✓ | ✓ |
| --quiet flag | ✓ | - |
| --contains flag | ✓ | ✓ |

**Run with:** `uv run pytest tests/integration/ -m integration -v`

## Subtasks

### 8.1. Create test_search_enhancements.py with base structure and fixtures

**Status:** pending  
**Dependencies:** None  

Create the new integration test file following existing patterns in tests/integration/cli/. Set up the test class structure, imports, and any additional fixtures needed specifically for search enhancement testing (e.g., a composite fixture that combines numbers, users, and locations service mocks for cross-feature testing).

**Details:**

Create `tests/integration/cli/test_search_enhancements.py` following the exact patterns from existing integration tests:

1. **File Structure:**
   - Standard imports (json, unittest.mock, pytest, typer.testing)
   - Import from teams_phone.cli.main, teams_phone.exceptions, teams_phone.models
   - Import factory helpers from tests.integration.cli.conftest

2. **Test Class Setup:**
   - `TestSearchEnhancementsNumbers` - for numbers list filters
   - `TestSearchEnhancementsLocations` - for locations wildcard search
   - `TestSearchEnhancementsUsers` - for users wildcard search

3. **Additional Fixtures (if needed):**
   - Leverage existing `mock_cli_services_numbers`, `mock_cli_services_locations`, `mock_cli_services_users` from conftest.py
   - May need composite fixture if testing cross-service --assigned-to filter

4. **Decorator Pattern:**
   - All tests marked with `@pytest.mark.integration`
   - Tests use runner and mock_cli_services_* fixtures

Reference existing patterns in test_numbers_integration.py:32-60 and test_users_integration.py:21-44 for class/method structure.

### 8.2. Write integration tests for case-insensitive and --contains filters

**Status:** pending  
**Dependencies:** 8.1  

Implement integration tests for the case-insensitive city filter (Task 1) and the --contains partial matching flag (if implemented). Tests should verify that lowercase, uppercase, and mixed-case city queries all match correctly, and that --contains enables substring matching behavior.

**Details:**

Add tests to `TestSearchEnhancementsNumbers` class:

1. **Case-Insensitive City Filter Tests:**
   - `test_numbers_list_city_lowercase_matches_titlecase` - `--city seattle` matches "Seattle"
   - `test_numbers_list_city_uppercase_matches_titlecase` - `--city SEATTLE` matches "Seattle"
   - `test_numbers_list_city_mixedcase_matches_titlecase` - `--city SeAtTlE` matches "Seattle"
   - `test_numbers_list_city_none_excluded` - numbers with None city don't match any city filter

2. **--contains Flag Tests (if applicable):**
   - `test_numbers_list_contains_partial_city` - `--city Sea --contains` matches "Seattle"
   - `test_numbers_list_contains_case_insensitive` - `--city sea --contains` matches "Seattle"
   - `test_numbers_list_without_contains_requires_full_match` - `--city Sea` (no --contains) doesn't match "Seattle"

3. **Test Implementation Pattern:**
   ```python
   mocks["number_service"].list_numbers.return_value = [
       make_number(telephone_number="+14255551234", city="Seattle"),
   ]
   result = runner.invoke(app, ["--no-color", "numbers", "list", "--city", "seattle"])
   assert result.exit_code == 0
   # The mock returns data; CLI displays it. The service layer handles case-insensitivity.
   ```

Follow assertion patterns from test_numbers_integration.py:140-161 for verifying service call arguments.

### 8.3. Write integration tests for wildcard pattern matching across commands

**Status:** pending  
**Dependencies:** 8.1  

Implement integration tests for wildcard pattern matching (*) support in locations search and users search commands. Tests should verify that wildcard patterns like 'Main*', '*Office*', and '*HQ' work correctly and that non-wildcard queries maintain existing substring behavior.

**Details:**

Add tests to `TestSearchEnhancementsLocations` and `TestSearchEnhancementsUsers` classes:

1. **Locations Wildcard Tests:**
   - `test_locations_search_wildcard_prefix` - `locations search "Main*"` matches "Main Office", "Main Street"
   - `test_locations_search_wildcard_suffix` - `locations search "*HQ"` matches "Seattle HQ", "NYC HQ"
   - `test_locations_search_wildcard_contains` - `locations search "*central*"` matches "Central Office"
   - `test_locations_search_no_wildcard_substring` - `locations search "Office"` (no *) performs substring match
   - `test_locations_search_wildcard_case_insensitive` - `locations search "*hq"` matches "Seattle HQ"

2. **Users Wildcard Tests:**
   - `test_users_search_wildcard_prefix` - `users search "Jo*"` matches "John Smith", "Joanna Chen"
   - `test_users_search_wildcard_suffix` - `users search "*son"` matches "Johnson", "Wilson"
   - `test_users_search_wildcard_contains` - `users search "*admin*"` matches users with "admin" in name
   - `test_users_search_no_wildcard_startswith` - `users search "John"` uses existing startsWith optimization

3. **Test Implementation Pattern:**
   ```python
   mocks["location_service"].list_locations.return_value = [
       make_location(description="Seattle HQ"),
       make_location(location_id="loc-2", description="Portland Office"),
   ]
   result = runner.invoke(app, ["--no-color", "locations", "search", "*HQ"])
   assert result.exit_code == 0
   assert "Seattle HQ" in result.stdout
   assert "Portland Office" not in result.stdout
   ```

Follow assertion patterns from test_locations_integration.py:286-312 and test_users_integration.py:334-356.

---

## Implementation Notes

### Session: 2026-02-03 - Agent: claude-opus-4-5-20251101

**Subtask:** 8.1 - Create test_search_enhancements.py with base structure and fixtures

**Status:** Implemented

#### What Was Done
- Created `tests/integration/cli/test_search_enhancements.py` with proper structure
- Added three test classes:
  - `TestSearchEnhancementsNumbers` - for case-insensitive city, --contains, --assigned-to tests
  - `TestSearchEnhancementsLocations` - for wildcard pattern matching tests
  - `TestSearchEnhancementsUsers` - for wildcard pattern matching tests
- Each class has a placeholder test marked with `@pytest.mark.integration`
- Tests use existing composite fixtures (`mock_cli_services_numbers`, `mock_cli_services_locations`, `mock_cli_services_users`)
- No new composite fixtures needed - existing fixtures provide adequate coverage

#### Key Decisions Made
- **Used existing fixtures**: Rather than creating a new composite fixture for cross-service operations, decided to use existing `mock_cli_services_*` fixtures. The --assigned-to tests in subtask 8.2 will need to patch additional services inline (see `_run_list_with_user_filter()` pattern from Task 2 notes).
- **Placeholder tests**: Added minimal placeholder tests that verify basic CLI invocation works. This ensures the file structure is correct and test discovery works, while keeping the scope focused on scaffolding.
- **Removed unused imports**: Initial scaffold included `json` and `AssignmentStatus` imports anticipating future use, but removed them to pass ruff lint checks. Future subtasks can add them back as needed.

#### Patterns Discovered
- Test discovery verified with `pytest --collect-only` - all 3 classes visible
- Existing `mock_cli_services_*` fixtures handle all patching for single-command integration tests
- Module docstring pattern from `test_numbers_integration.py` followed for consistency

#### Files Reference
- `tests/integration/cli/test_search_enhancements.py` - new file (100 lines)
- Pattern reference: `tests/integration/cli/test_numbers_integration.py:32-60`
- Fixtures reference: `tests/integration/cli/conftest.py:562-630`

#### Open Items for Next Agent
- [x] Subtask 8.2: Add actual test cases for case-insensitive city filter and --contains flag - DONE
- [ ] Subtask 8.3: Add actual test cases for wildcard pattern matching in locations and users

#### Gotchas and Warnings
- **Multi-service --assigned-to tests**: When adding tests for `--assigned-to` in subtask 8.2, the test will need to patch both `UserService` and `NumberService`. The `_run_list_with_user_filter()` helper in `numbers.py:267-314` creates its own service instances, so inline patching similar to `tests/unit/test_cli_numbers_list.py:158-269` will be needed.
- **search_numbers returns tuple**: Remember `search_numbers` returns `(results, total_fetched)` tuple, not just a list. Use `AsyncMock(return_value=(results, total))` pattern.

---

### Session: 2026-02-03 20:45 - Agent: claude-opus-4-5-20251101

**Subtask:** 8.2 - Write integration tests for case-insensitive and --contains filters

**Status:** Implemented

#### What Was Done
- Replaced the placeholder test with 7 actual integration tests in `TestSearchEnhancementsNumbers` class:
  1. `test_numbers_list_city_lowercase_matches_titlecase` - verifies `--city seattle` matches "Seattle"
  2. `test_numbers_list_city_uppercase_matches_titlecase` - verifies `--city SEATTLE` matches "Seattle"
  3. `test_numbers_list_city_mixedcase_matches_titlecase` - verifies `--city SeAtTlE` matches "Seattle"
  4. `test_numbers_list_city_filter_excludes_none_city` - verifies city filter passes correct parameter (service handles None exclusion)
  5. `test_numbers_list_contains_partial_city_match` - verifies `--city Sea --contains` enables partial matching
  6. `test_numbers_list_contains_case_insensitive` - verifies `--city sea --contains` works case-insensitively
  7. `test_numbers_list_without_contains_requires_exact_match` - verifies `--city Sea` (no --contains) uses exact match

- All tests follow the pattern from `test_numbers_integration.py:140-161`
- Tests verify both CLI output and service call arguments via `call_args[1]`

#### Key Decisions Made
- **Service-layer filtering verification**: Tests verify that the CLI passes the correct `city` and `contains` parameters to the service. Actual filtering logic is tested at the unit test level in `test_number_service_read.py`.
- **Mock return values**: Tests set up mock return values based on expected behavior (e.g., empty list for non-matching exact match test).
- **Removed placeholder test**: The original placeholder was replaced with the first real test rather than kept separately.

#### Patterns Followed
- `@pytest.mark.integration` decorator on all tests
- `mock_cli_services_numbers` fixture pattern
- `runner.invoke(app, ["--no-color", "numbers", "list", ...])` invocation
- `call_kwargs = mocks["number_service"].list_numbers.call_args[1]` for argument verification

#### Files Modified
- `tests/integration/cli/test_search_enhancements.py` - added 7 test methods (lines 38-185)

#### Test Results
- All 9 tests in `test_search_enhancements.py` pass (7 new + 2 placeholders for other classes)
- Pre-existing failures in `TestNumbersSearchIntegration` class unrelated to these changes

#### Open Items for Next Agent
- [ ] Subtask 8.3: Add wildcard pattern matching tests for locations and users
- [ ] Note: --assigned-to tests NOT in scope for 8.2 - those belong in 8.3 or a separate subtask

#### Gotchas and Warnings
- **Pre-existing test failures**: 4 tests in `tests/integration/cli/test_numbers_integration.py::TestNumbersSearchIntegration` fail due to `search_numbers` returning tuple vs list mismatch. These are unrelated to the search enhancements work.
- **mypy errors on test file**: Mypy reports `import-untyped` errors for `teams_phone.cli.main` - this is a known project-wide issue with missing py.typed marker, not a new problem.

---

### Session: 2026-02-03 21:15 - Agent: claude-opus-4-5-20251101

**Subtask:** 8.3 - Write integration tests for wildcard pattern matching across commands

**Status:** Implemented

#### What Was Done
- Replaced placeholder tests with 9 actual integration tests for wildcard patterns:

**TestSearchEnhancementsLocations (5 tests):**
1. `test_locations_search_wildcard_prefix` - verifies `"Alpha*"` matches "Alpha Office", "Alpha Campus"
2. `test_locations_search_wildcard_suffix` - verifies `"*HQ"` matches "Seattle HQ", "NYC HQ"
3. `test_locations_search_wildcard_contains` - verifies `"*central*"` matches "Central Office", "Downtown Central"
4. `test_locations_search_no_wildcard_substring` - verifies `"Office"` (no *) performs substring match
5. `test_locations_search_wildcard_case_insensitive` - verifies `"*hq"` (lowercase) matches "Seattle HQ" (uppercase)

**TestSearchEnhancementsUsers (4 tests):**
1. `test_users_search_wildcard_prefix` - verifies `"Jo*"` matches "John Doe", "Joanna Chen"
2. `test_users_search_wildcard_suffix` - verifies `"*son"` matches "Bob Johnson", "Tom Wilson"
3. `test_users_search_wildcard_contains` - verifies `"*admin*"` matches users with "admin" in name
4. `test_users_search_no_wildcard_startswith` - verifies `"John"` uses existing startsWith optimization

#### Key Decisions Made
- **Locations filtering is CLI-side**: The `_location_matches_query()` function in `locations.py:116-142` filters at the CLI layer. Tests mock `list_locations.return_value` with ALL locations, and the CLI filters them using wildcard regex matching. Assertions verify expected matches appear AND non-matches are excluded.
- **Users filtering is service-side**: Unlike locations, `users search` delegates to `UserService.search_users()`, which internally routes to `_search_users_wildcard()`. Tests mock `search_users.return_value` with the expected filtered results since the service handles the filtering.
- **Test data isolation**: Changed the prefix test to use "Alpha*" instead of "Main*" because the default `make_location()` address is "123 Main St", which would cause false matches when searching all fields (description, address, city, company).

#### Patterns Followed
- `@pytest.mark.integration` decorator on all tests
- `mock_cli_services_locations` / `mock_cli_services_users` fixtures
- `mocks["location_service"].get_staleness_warning.return_value = None` - prevents staleness warnings
- `mocks["user_service"].search_users.return_value = users` - returns pre-filtered results

#### Files Modified
- `tests/integration/cli/test_search_enhancements.py` - replaced 2 placeholder tests with 9 wildcard tests

#### Test Results
- All 16 tests pass in `test_search_enhancements.py`:
  - 7 tests in `TestSearchEnhancementsNumbers`
  - 5 tests in `TestSearchEnhancementsLocations`
  - 4 tests in `TestSearchEnhancementsUsers`

#### Gotchas and Warnings
- **Locations search searches ALL fields**: When field=None, `_location_matches_query()` checks description, address, city, and company_name. This means test data must avoid patterns that accidentally match other fields (e.g., "Main*" matches "123 Main St" in the address).
- **Users search returns list, not tuple**: Unlike `search_numbers`, `search_users` returns a simple list. Mock with `return_value = [user1, user2]`, not a tuple.

---
