# Task ID: 2

**Title:** Implement JobStore for JSON persistence

**Status:** pending

**Dependencies:** 1

**Priority:** high

**Description:** Create a JobStore class that handles job persistence to JSON files in `.teams-phone/jobs/<job-id>/` directory with atomic write pattern and backup recovery.

**Details:**

Create `src/teams_phone/infrastructure/job_store.py`:

```python
import hashlib
import os
import secrets
from datetime import datetime, timezone
from pathlib import Path
import re

from teams_phone.exceptions import ConfigurationError
from teams_phone.models.batch import Job, JobStatus

class JobStore:
    def __init__(self, base_path: Path | None = None):
        """Initialize with base path, defaults to .teams-phone/jobs in cwd."""
        self.base_path = base_path or Path.cwd() / ".teams-phone" / "jobs"

    def _generate_job_id(self, name: str) -> str:
        """Generate job ID: YYYYMMDD-HHMMSS-{random4hex}-{name-slug}."""
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
        random_suffix = secrets.token_hex(2)  # 4 hex chars
        slug = re.sub(r'[^a-z0-9]+', '-', name.lower()).strip('-')[:30]
        return f"{timestamp}-{random_suffix}-{slug}"

    def _job_dir(self, job_id: str) -> Path:
        return self.base_path / job_id

    def _job_file(self, job_id: str) -> Path:
        return self._job_dir(job_id) / "job.json"

    def _backup_file(self, job_id: str) -> Path:
        return self._job_dir(job_id) / "job.json.backup"

    def _atomic_write(self, path: Path, content: str) -> None:
        """Atomic write with fsync: write to tmp, backup current, rename."""
        tmp_path = path.with_suffix(".tmp")
        backup_path = path.with_suffix(".backup")
        
        # Write to temp file
        tmp_path.write_text(content, encoding="utf-8")
        # Fsync to ensure data on disk
        with tmp_path.open("a") as f:
            os.fsync(f.fileno())
        
        # Backup current if exists
        if path.exists():
            path.replace(backup_path)
        
        # Atomic rename
        tmp_path.rename(path)

    def create_job(self, name: str, input_file: Path, items: list[dict]) -> Job:
        """Create a new job from parsed CSV items."""
        job_id = self._generate_job_id(name)
        job_dir = self._job_dir(job_id)
        job_dir.mkdir(parents=True, exist_ok=True)
        
        # Copy input CSV
        input_copy = job_dir / "input.csv"
        input_copy.write_bytes(input_file.read_bytes())
        
        # Compute hash
        input_hash = hashlib.sha256(input_file.read_bytes()).hexdigest()
        
        now = datetime.now(timezone.utc)
        job = Job(
            id=job_id,
            name=name,
            status=JobStatus.CREATED,
            created_at=now,
            updated_at=now,
            input_file=str(input_file),
            input_hash=input_hash,
            items=[JobItem(**item) for item in items]
        )
        
        self.save_job(job)
        return job

    def save_job(self, job: Job) -> None:
        """Save job state with atomic write."""
        job.updated_at = datetime.now(timezone.utc)
        content = job.model_dump_json(indent=2)
        self._atomic_write(self._job_file(job.id), content)

    def load_job(self, job_id: str) -> Job:
        """Load job, falling back to backup if corrupted."""
        # Implementation with backup recovery
        pass

    def list_jobs(self) -> list[Job]:
        """List all jobs sorted by created_at descending."""
        pass

    def delete_job(self, job_id: str) -> None:
        """Delete job directory."""
        pass
```

Include error handling for corrupted JSON with backup recovery per REQ-039.

**Test Strategy:**

Unit tests in `tests/unit/test_job_store.py`:
1. Test job ID generation format (timestamp-random-slug)
2. Test create_job creates directory structure and files
3. Test atomic write pattern (verify tmp → backup → rename sequence)
4. Test save_job updates updated_at timestamp
5. Test load_job returns Job model
6. Test load_job recovers from backup when job.json corrupted
7. Test list_jobs returns sorted results
8. Test delete_job removes directory
9. Use tmp_path fixture for isolated filesystem tests

## Subtasks

### 2.1. Implement JobStore core class structure with path management and job ID generation

**Status:** done
**Dependencies:** None  

Create the foundational JobStore class with constructor, path helpers, and job ID generation logic following the project's infrastructure patterns.

**Details:**

Create `src/teams_phone/infrastructure/job_store.py` with:

1. **Imports**: `hashlib`, `os`, `secrets`, `datetime`, `timezone`, `Path`, `re`, plus `ConfigurationError`, `NotFoundError` from exceptions and `Job`, `JobStatus`, `JobItem` from models.batch

2. **Constructor**: Accept optional `base_path: Path | None`, defaulting to `Path.cwd() / '.teams-phone' / 'jobs'`. Store as `self.base_path`.

3. **Path helper methods**:
   - `_job_dir(job_id: str) -> Path`: Returns `self.base_path / job_id`
   - `_job_file(job_id: str) -> Path`: Returns `self._job_dir(job_id) / 'job.json'`
   - `_backup_file(job_id: str) -> Path`: Returns `self._job_dir(job_id) / 'job.json.backup'`

4. **Job ID generation** (`_generate_job_id(name: str) -> str`):
   - Format: `YYYYMMDD-HHMMSS-{random4hex}-{name-slug}`
   - Use `datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')` for timestamp
   - Use `secrets.token_hex(2)` for 4 random hex chars
   - Slugify name: `re.sub(r'[^a-z0-9]+', '-', name.lower()).strip('-')[:30]`

5. Follow ConfigManager patterns: type hints, docstrings, use Path throughout (not strings).

### 2.2. Implement create_job method with input file copying and SHA-256 hashing

**Status:** pending  
**Dependencies:** 2.1  

Add the create_job method that initializes a new job from CSV data, copies the input file to the job directory, computes file hash, and creates the initial Job model.

**Details:**

Add `create_job` method to JobStore:

```python
def create_job(self, name: str, input_file: Path, items: list[dict]) -> Job:
    """Create a new job from parsed CSV items.
    
    Args:
        name: Human-readable job name for display/identification
        input_file: Path to the original CSV file
        items: List of dicts from CSV parser, each dict becomes a JobItem
    
    Returns:
        Job: The created and persisted job instance
    
    Raises:
        ConfigurationError: If job directory cannot be created
    """
```

Implementation steps:
1. Generate job ID via `_generate_job_id(name)`
2. Create job directory: `job_dir.mkdir(parents=True, exist_ok=True)` - wrap in try/except for PermissionError → ConfigurationError
3. Copy input CSV to `job_dir / 'input.csv'`: use `write_bytes(input_file.read_bytes())`
4. Compute SHA-256 hash: `hashlib.sha256(input_file.read_bytes()).hexdigest()`
5. Create Job instance with:
   - `id=job_id`, `name=name`, `status=JobStatus.CREATED`
   - `created_at=now`, `updated_at=now` (use `datetime.now(timezone.utc)`)
   - `input_file=str(input_file)` (original path for reference)
   - `input_hash=input_hash`
   - `items=[JobItem(**item) for item in items]`
6. Call `self.save_job(job)` to persist
7. Return the job

### 2.3. Implement atomic write with fsync and backup for cross-platform reliability

**Status:** pending  
**Dependencies:** 2.1  

Create the _atomic_write private method that provides crash-safe file persistence using temp file, backup, and atomic rename with proper fsync handling for Windows and Unix.

**Details:**

Add `_atomic_write` and `save_job` methods:

```python
def _atomic_write(self, path: Path, content: str) -> None:
    """Atomic write with fsync: write to tmp, backup current, rename.
    
    Provides crash-safe persistence by:
    1. Writing to .tmp file first
    2. Calling fsync to ensure data on disk
    3. Backing up current file (if exists) to .backup
    4. Atomic rename from .tmp to target
    
    Cross-platform notes:
    - Windows: os.replace() provides atomic rename on same volume
    - Unix: rename() is atomic per POSIX
    - fsync on directory not needed for file rename atomicity
    """
```

Implementation:
1. Define paths: `tmp_path = path.with_suffix('.json.tmp')`, `backup_path = path.with_suffix('.json.backup')`
2. Write content to tmp: `tmp_path.write_text(content, encoding='utf-8')`
3. Fsync the file:
   ```python
   with tmp_path.open('rb') as f:  # Use 'rb' mode for fsync-only
       os.fsync(f.fileno())
   ```
4. Backup current if exists: `if path.exists(): path.replace(backup_path)` (replace is atomic)
5. Atomic rename: `tmp_path.replace(path)` (os.replace equivalent, works cross-platform)

**save_job method:**
```python
def save_job(self, job: Job) -> None:
    """Save job state with atomic write."""
    job.updated_at = datetime.now(timezone.utc)
    content = job.model_dump_json(indent=2)
    self._atomic_write(self._job_file(job.id), content)
```

Error handling: Wrap in try/except for OSError → ConfigurationError with appropriate message.

### 2.4. Implement load_job, list_jobs, and delete_job with backup recovery per REQ-039

**Status:** pending  
**Dependencies:** 2.1, 2.2, 2.3  

Add methods to load a job with automatic backup recovery on corruption, list all jobs sorted by creation date, and delete job directories with proper error handling.

**Details:**

Add three methods to complete JobStore:

**load_job with backup recovery (REQ-039):**
```python
def load_job(self, job_id: str) -> Job:
    """Load job, falling back to backup if corrupted.
    
    Raises:
        NotFoundError: If job directory or files don't exist
        ConfigurationError: If both main and backup are corrupted
    """
```
Implementation:
1. Check `_job_file(job_id).exists()` → if not, check backup → if neither, raise NotFoundError
2. Try loading main file: `Job.model_validate_json(path.read_text(encoding='utf-8'))`
3. On JSONDecodeError or ValidationError: try backup file
4. If backup works, restore it (copy backup → main) and log warning
5. If both fail: raise ConfigurationError with details about corruption

**list_jobs:**
```python
def list_jobs(self) -> list[Job]:
    """List all jobs sorted by created_at descending (newest first)."""
```
Implementation:
1. If `self.base_path` doesn't exist, return empty list
2. Iterate directories: `[d for d in self.base_path.iterdir() if d.is_dir() and not d.name.startswith('.')]`
3. Load each job (skip failures with warning to stderr)
4. Sort by `job.created_at` descending

**delete_job:**
```python
def delete_job(self, job_id: str) -> None:
    """Delete job directory and all contents.
    
    Raises:
        NotFoundError: If job doesn't exist
    """
```
Implementation: Use `shutil.rmtree(self._job_dir(job_id))` with NotFoundError if dir doesn't exist.

---

## Implementation Notes

### Session: 2026-02-04 - Agent: claude-opus-4-5-20251101

**Subtask:** 2.1 - Implement JobStore core class structure with path management and job ID generation

**Status:** Implemented

#### What Was Done
- Created `src/teams_phone/infrastructure/job_store.py` with JobStore class
- Implemented constructor accepting `Path | None` with default `Path.cwd() / ".teams-phone" / "jobs"`
- Implemented path helpers: `_job_dir`, `_job_file`, `_backup_file`
- Implemented `_generate_job_id` with format: `YYYYMMDD-HHMMSS-{hex4}-{slug}`
- Updated `src/teams_phone/infrastructure/__init__.py` to export JobStore
- Created `tests/unit/test_job_store.py` with 15 unit tests covering all functionality

#### Key Decisions Made
- Used explicit conditional `if base_path is not None` rather than falsy check to allow empty Path objects
- Did NOT import exception classes (ConfigurationError, NotFoundError) in this subtask - they will be needed in subsequent subtasks (2.2, 2.4) when error handling is added
- Did NOT import batch models (Job, JobItem, JobStatus) - they will be needed in subtask 2.2 for create_job

#### Patterns Discovered
- ConfigManager pattern at `config_manager.py:31-39` provides ideal template for constructor with optional path
- Test patterns in `test_config_manager.py` show using `tmp_path` fixture for isolated filesystem tests

#### Files Created/Modified
- Created: `src/teams_phone/infrastructure/job_store.py`
- Modified: `src/teams_phone/infrastructure/__init__.py` (added JobStore export)
- Created: `tests/unit/test_job_store.py`

#### Test Coverage
- 15 tests passing covering:
  - Constructor with default/custom/None path
  - All three path helpers returning correct structure
  - Job ID format validation via regex
  - Slug generation: lowercase, special chars, truncation, dash stripping
  - Uniqueness of random portion
  - UTC timestamp format

#### Open Items for Next Agent
- [ ] Subtask 2.2: Implement `create_job` method - will need to import Job, JobItem, JobStatus models
- [ ] Subtask 2.3: Implement `_atomic_write` and `save_job` methods
- [ ] Subtask 2.4: Implement `load_job`, `list_jobs`, `delete_job` with backup recovery

#### Gotchas and Warnings
- The recon report warned about computed fields + `extra="forbid"`: When serializing Job to JSON and loading back, computed fields must be stripped before `model_validate()` - this will be relevant in subtask 2.4 when implementing `load_job`

---

### Session: 2026-02-04 22:15 - Agent: claude-opus-4-5-20251101

**Subtask:** 2.2 - Implement create_job method with input file copying and SHA-256 hashing

**Status:** Implemented

#### What Was Done
- Added imports for `hashlib`, `shutil`, `typing.Any`, `ConfigurationError`, `Job`, `JobItem`, `JobStatus` to job_store.py
- Implemented `create_job(name, input_file, items)` method that:
  - Generates unique job ID via `_generate_job_id(name)`
  - Creates job directory with `mkdir(parents=True, exist_ok=True)`
  - Handles PermissionError by raising ConfigurationError with remediation
  - Copies input CSV to job directory as `input.csv` using `shutil.copy2()`
  - Computes SHA-256 hash of original input file
  - Creates Job instance with all required fields and items
  - Calls `save_job(job)` to persist
- Implemented basic `save_job(job)` method (stub for subtask 2.3 to enhance with atomic write)
  - Writes JSON to job_file using `model_dump_json(indent=2)`
- Added 10 unit tests for `create_job` covering:
  - Job directory creation
  - Input file copying
  - SHA-256 hash computation
  - Job fields initialization
  - JobItems creation from dicts
  - JSON persistence verification
  - PermissionError handling → ConfigurationError
  - Job ID slug derivation from name
- Added 2 unit tests for `save_job` covering JSON file writing and formatting

#### Key Decisions Made
- Used `shutil.copy2()` instead of `write_bytes(read_bytes())` - preserves metadata and handles edge cases
- Used `list[dict[str, Any]]` type annotation for items parameter - mypy strict mode requires this for **kwargs unpacking
- Implemented basic `save_job` as a stub since `create_job` calls it; subtask 2.3 will add atomic write pattern
- Did NOT update `updated_at` in `save_job` - leaving that for subtask 2.3's atomic write implementation to match task spec

#### Patterns Discovered
- ConfigManager's PermissionError handling at `config_manager.py:49-58` - replicated for job directory creation
- Test patterns: Using fixtures (`tmp_path`, `input_csv`, `sample_items`) for isolated tests

#### Files Modified
- Modified: `src/teams_phone/infrastructure/job_store.py` (added imports, `create_job`, `save_job`)
- Modified: `tests/unit/test_job_store.py` (added imports, `TestJobStoreCreateJob`, `TestJobStoreSaveJob`)

#### Test Coverage
- 25 total tests passing (15 from 2.1 + 10 new)
- Tests cover: directory creation, file copying, hashing, field initialization, item creation, JSON persistence, error handling

#### Open Items for Next Agent
- [ ] Subtask 2.3: Implement `_atomic_write` with fsync and backup - enhance `save_job` to use it
- [ ] Subtask 2.4: Implement `load_job`, `list_jobs`, `delete_job` with backup recovery

#### Gotchas and Warnings
- The basic `save_job` does NOT do atomic writes - subtask 2.3 must add `_atomic_write` pattern
- When implementing `load_job` in 2.4, remember computed fields issue: they're included in JSON but must be excluded during `model_validate()` due to `extra="forbid"`

---

### Session: 2026-02-04 - Agent: claude-opus-4-5-20251101

**Subtask:** 2.3 - Implement atomic write with fsync and backup for cross-platform reliability

**Status:** Implemented

#### What Was Done
- Added imports for `contextlib` and `os` modules to job_store.py
- Implemented `_atomic_write(self, path: Path, content: str) -> None` method that:
  - Writes content to `.tmp` file first
  - Calls `os.fsync()` to ensure data is on disk
  - Backs up existing file to `.backup` if it exists (using `path.replace()`)
  - Performs atomic rename from `.tmp` to target (using `tmp_path.replace()`)
  - Wraps all operations in try/except for OSError → ConfigurationError
  - Cleans up temp file on failure using `contextlib.suppress(OSError)`
- Updated `save_job(self, job: Job) -> None` method to:
  - Update `job.updated_at = datetime.now(timezone.utc)` before writing
  - Use `_atomic_write()` instead of direct `write_text()`
  - Updated docstring to document atomic write behavior
- Added 9 unit tests for `_atomic_write` in `TestJobStoreAtomicWrite` class:
  - File creation with correct content
  - Backup creation when overwriting
  - Backup contains previous content
  - Temp file cleanup after success
  - No backup on first write
  - ConfigurationError on PermissionError
  - ConfigurationError on OSError
  - Multiple rapid saves preserve data integrity
  - Backup overwrites on subsequent writes
- Added 4 unit tests for updated `save_job` in `TestJobStoreSaveJob`:
  - Updates `updated_at` timestamp
  - Produces reloadable JSON
  - Creates backup on subsequent save
  - Raises ConfigurationError on write failure

#### Key Decisions Made
- Used string concatenation `path.parent / (path.name + '.tmp')` instead of `path.with_suffix()` to avoid issues with compound suffixes like `.json.backup` becoming just `.backup`
- Used `'ab'` mode for fsync instead of `'rb'` - cannot open a file in read mode for fsync, append mode works cross-platform
- Used `contextlib.suppress(OSError)` for cleanup instead of try/except/pass per ruff SIM105 rule
- Used `Path.replace()` for both backup creation and atomic rename - cross-platform equivalent of `os.replace()`

#### Patterns Discovered
- fsync pattern: Open file in `'ab'` mode (append binary), then call `os.fsync(f.fileno())` - this works on Windows and Unix
- Atomic rename: `Path.replace(target)` is the cross-platform way to do atomic renames on the same filesystem
- Error handling cleanup: Use `contextlib.suppress()` for cleanup operations that may fail but shouldn't stop the main error propagation

#### Files Modified
- Modified: `src/teams_phone/infrastructure/job_store.py` (added imports, `_atomic_write`, updated `save_job`)
- Modified: `tests/unit/test_job_store.py` (added `TestJobStoreAtomicWrite`, expanded `TestJobStoreSaveJob`)

#### Test Coverage
- 38 total tests passing (25 from previous + 13 new)
- Tests verify: atomic write sequence, backup creation, timestamp updates, error propagation, data integrity under rapid writes

#### Open Items for Next Agent
- [ ] Subtask 2.4: Implement `load_job`, `list_jobs`, `delete_job` with backup recovery per REQ-039

#### Gotchas and Warnings
- When implementing `load_job` in 2.4, the backup file will be at `job.json.backup` (compound suffix), not `.backup`
- Computed fields are included in the JSON output - when loading, they must be stripped before `model_validate()` due to `extra="forbid"` on the Job model
- The `updated_at` timestamp is always updated on save, even if the job content hasn't changed - this is intentional for tracking save times

---

### Session: 2026-02-04 - Agent: claude-opus-4-5-20251101

**Subtask:** 2.4 - Implement load_job, list_jobs, and delete_job with backup recovery per REQ-039

**Status:** Implemented

#### What Was Done
- Added imports for `json`, `sys`, `PydanticValidationError`, and `NotFoundError` to job_store.py
- Added `_COMPUTED_FIELDS` class constant (frozenset) listing computed fields that must be stripped during load
- Implemented `_load_job_from_file(self, file_path: Path) -> Job` helper method:
  - Parses JSON using `json.loads()` to get dict
  - Strips computed fields (`total_count`, `succeeded_count`, `failed_count`, `pending_count`, `duration`)
  - Validates with `Job.model_validate(data)`
- Implemented `load_job(self, job_id: str) -> Job` method with backup recovery per REQ-039:
  - Checks if job directory exists, raises NotFoundError if not
  - Attempts to load from main job.json file
  - On JSONDecodeError or PydanticValidationError: falls back to backup file
  - On successful backup load: restores main file using `shutil.copy2()`
  - Raises ConfigurationError if both files are corrupted
  - Raises NotFoundError if job directory exists but has no files
- Implemented `list_jobs(self) -> list[Job]` method:
  - Returns empty list if base_path doesn't exist
  - Iterates directories, skips hidden (`.xxx`) directories
  - Loads each job using `load_job()`, catches errors and logs to stderr
  - Returns list sorted by `created_at` descending (newest first)
- Implemented `delete_job(self, job_id: str) -> None` method:
  - Checks if job directory exists, raises NotFoundError if not
  - Uses `shutil.rmtree()` to remove entire directory and contents
- Added 8 unit tests for `load_job` in `TestJobStoreLoadJob` class:
  - Returns valid job from job.json
  - Raises NotFoundError when directory missing
  - Falls back to backup on corruption (invalid JSON)
  - Raises ConfigurationError when both main and backup corrupted
  - Restores main file from backup after successful recovery
  - Handles missing backup gracefully (only main exists)
  - Raises NotFoundError when no job files exist in directory
  - Raises ConfigurationError on validation failure (valid JSON, invalid data)
- Added 5 unit tests for `list_jobs` in `TestJobStoreListJobs` class:
  - Returns empty list when no jobs exist
  - Returns empty list when base_path doesn't exist
  - Returns jobs sorted by created_at descending
  - Skips hidden directories (starting with `.`)
  - Continues loading when one job is corrupted (logs warning)
- Added 3 unit tests for `delete_job` in `TestJobStoreDeleteJob` class:
  - Removes entire job directory
  - Raises NotFoundError for non-existent job
  - Removes all files (job.json, backup, input.csv)

#### Key Decisions Made
- Used `json.loads()` to parse JSON to dict first, then strip computed fields, then `Job.model_validate(data)` - this is the only safe way to handle computed fields with `extra="forbid"`
- Created `_load_job_from_file()` helper to avoid code duplication between main file and backup loading
- Used `frozenset` for `_COMPUTED_FIELDS` for immutability and O(1) lookup
- Logged warnings to `sys.stderr` in `list_jobs()` to not interfere with stdout for CLI output
- Used `shutil.copy2()` for backup restoration to preserve metadata

#### Patterns Discovered
- Computed fields pattern: JSON includes computed fields, but they must be removed before validation due to `extra="forbid"`. Solution: parse to dict, pop fields, then validate.
- Directory iteration pattern: `[d for d in path.iterdir() if d.is_dir() and not d.name.startswith('.')]`
- Sorting pattern: `sorted(jobs, key=lambda j: j.created_at, reverse=True)` for descending order

#### Files Modified
- Modified: `src/teams_phone/infrastructure/job_store.py` (added imports, `_COMPUTED_FIELDS`, `_load_job_from_file`, `load_job`, `list_jobs`, `delete_job`)
- Modified: `tests/unit/test_job_store.py` (added imports, `TestJobStoreLoadJob`, `TestJobStoreListJobs`, `TestJobStoreDeleteJob`)

#### Test Coverage
- 54 total tests passing (38 from previous + 16 new)
- Tests verify: job loading, backup recovery, corruption handling, directory listing, sorting, hidden directory skipping, job deletion

#### Completed Items
- [x] Subtask 2.4: All methods implemented with backup recovery per REQ-039
- [x] JobStore is now fully implemented with all CRUD operations

#### Gotchas and Warnings
- The computed fields list must be kept in sync with the Job model - if new computed fields are added, `_COMPUTED_FIELDS` must be updated
- `list_jobs()` writes to stderr for warnings - this may need to be changed to use logging in the future
- Backup recovery is automatic and silent except for `list_jobs()` warnings - no logging in `load_job()` when recovery succeeds
