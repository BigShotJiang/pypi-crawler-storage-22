# Task ID: 3

**Title:** Implement job locking mechanism

**Status:** pending

**Dependencies:** 2

**Priority:** high

**Description:** Add a lock file mechanism to JobStore to prevent concurrent job execution, supporting REQ-006 and REQ-007 for single active job enforcement.

**Details:**

Extend `job_store.py` with locking:

```python
import fcntl  # Unix, need cross-platform for Windows
import sys
from contextlib import contextmanager

class JobLockError(Exception):
    """Raised when job lock cannot be acquired."""
    def __init__(self, active_job_id: str):
        self.active_job_id = active_job_id
        super().__init__(f"Another job is running: {active_job_id}")

class JobStore:
    def _lock_file(self) -> Path:
        return self.base_path / ".lock"

    def _lock_info_file(self) -> Path:
        return self.base_path / ".lock_info.json"

    @contextmanager
    def acquire_lock(self, job_id: str):
        """Context manager for job lock acquisition.
        
        Writes lock info (job_id, pid, timestamp) for debugging.
        Uses file locking for cross-process safety.
        """
        self.base_path.mkdir(parents=True, exist_ok=True)
        lock_path = self._lock_file()
        
        # Check for existing lock info
        if self._lock_info_file().exists():
            try:
                info = json.loads(self._lock_info_file().read_text())
                # Check if process still running
                # If stale, allow override
            except (json.JSONDecodeError, KeyError):
                pass
        
        # Cross-platform locking
        if sys.platform == "win32":
            import msvcrt
            # Windows file locking with msvcrt
        else:
            # Unix fcntl.flock
            pass
        
        # Write lock info
        lock_info = {
            "job_id": job_id,
            "pid": os.getpid(),
            "started_at": datetime.now(timezone.utc).isoformat()
        }
        self._lock_info_file().write_text(json.dumps(lock_info))
        
        try:
            yield
        finally:
            # Release lock and clean up
            self._lock_info_file().unlink(missing_ok=True)
            lock_path.unlink(missing_ok=True)

    def get_active_job_id(self) -> str | None:
        """Return active job ID if one is running, None otherwise."""
        if self._lock_info_file().exists():
            # Parse and return job_id, checking if process alive
            pass
        return None
```

Add `JobLockError` to exceptions.py with exit_code=13 per PRD spec.

**Test Strategy:**

Unit tests in `tests/unit/test_job_store_locking.py`:
1. Test acquire_lock succeeds when no lock exists
2. Test acquire_lock raises JobLockError when lock held
3. Test lock is released after context manager exits (normal)
4. Test lock is released after context manager exits (exception)
5. Test stale lock detection (process no longer running)
6. Test get_active_job_id returns correct value
7. Test cross-platform behavior (mock fcntl/msvcrt as needed)

## Subtasks

### 3.1. Implement cross-platform file locking for Windows (msvcrt) and Unix (fcntl)

**Status:** pending  
**Dependencies:** None  

Create the low-level file locking mechanism with platform-specific implementations using msvcrt.locking on Windows and fcntl.flock on Unix.

**Details:**

Add platform-specific file locking to `job_store.py`:

1. **Imports**: Add `import sys`, `import json`, `from contextlib import contextmanager`. Conditionally import locking modules based on platform.

2. **Windows implementation (primary - sys.platform == 'win32')**:
   - Use `import msvcrt` for Windows file locking
   - `msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)` for non-blocking exclusive lock
   - `msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)` to release
   - Catch `OSError` (errno 36 EDEADLK or 13 EACCES) when lock held by another process

3. **Unix fallback (sys.platform != 'win32')**:
   - Use `import fcntl`
   - `fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)` for non-blocking exclusive lock
   - `fcntl.flock(fd, fcntl.LOCK_UN)` to release
   - Catch `BlockingIOError` when lock held

4. **Helper methods in JobStore**:
   - `_lock_file(self) -> Path`: Returns `self.base_path / '.lock'`
   - `_acquire_file_lock(self, fd: int) -> None`: Platform-specific lock acquisition
   - `_release_file_lock(self, fd: int) -> None`: Platform-specific lock release

5. Ensure lock file is opened in binary write mode ('wb') for consistent cross-platform behavior with file descriptor operations.

### 3.2. Implement lock info file management with stale lock detection

**Status:** pending  
**Dependencies:** 3.1  

Create lock info JSON file tracking (job_id, pid, timestamp) and implement stale lock detection by checking if the locking process is still running.

**Details:**

Add lock info management to `job_store.py`:

1. **Path helper**: `_lock_info_file(self) -> Path`: Returns `self.base_path / '.lock_info.json'`

2. **Lock info structure** (JSON):
   ```python
   lock_info = {
       'job_id': str,
       'pid': int,
       'started_at': str  # ISO 8601 timestamp
   }
   ```

3. **Stale lock detection**: `_is_process_running(pid: int) -> bool`:
   - Windows: Use `os.kill(pid, 0)` wrapped in try/except - raises `OSError` if process doesn't exist
   - Alternative for Windows: `ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)` returns 0 if process doesn't exist
   - Unix: Same `os.kill(pid, 0)` approach works
   - Handle `PermissionError` (process exists but different user)

4. **Read lock info**: `_read_lock_info(self) -> dict | None`:
   - Return None if file doesn't exist
   - Parse JSON, return None on decode errors
   - Validate expected fields present

5. **Write lock info**: `_write_lock_info(self, job_id: str) -> None`:
   - Write JSON with current job_id, os.getpid(), datetime.now(timezone.utc).isoformat()

6. **Check stale**: If lock_info exists and process is NOT running, the lock is stale and can be overridden (clean up old lock file and info file).

### 3.3. Implement acquire_lock context manager and get_active_job_id with proper cleanup

**Status:** pending  
**Dependencies:** 3.1, 3.2  

Create the acquire_lock context manager that combines file locking with info tracking, handles both success and exception paths, and add get_active_job_id query method.

**Details:**

Complete the locking API in `job_store.py`:

1. **Context manager** `acquire_lock(self, job_id: str)`:
   ```python
   @contextmanager
   def acquire_lock(self, job_id: str):
       self.base_path.mkdir(parents=True, exist_ok=True)
       lock_path = self._lock_file()
       
       # Check for stale lock
       existing_info = self._read_lock_info()
       if existing_info:
           if self._is_process_running(existing_info['pid']):
               raise JobLockError(existing_info['job_id'])
           # Stale lock - clean up
           self._lock_info_file().unlink(missing_ok=True)
           lock_path.unlink(missing_ok=True)
       
       # Acquire file lock
       lock_fd = open(lock_path, 'wb')
       try:
           self._acquire_file_lock(lock_fd.fileno())
       except (OSError, BlockingIOError):
           lock_fd.close()
           existing = self._read_lock_info()
           raise JobLockError(existing['job_id'] if existing else 'unknown')
       
       # Write lock info
       self._write_lock_info(job_id)
       
       try:
           yield
       finally:
           # Cleanup: release lock, delete files
           self._release_file_lock(lock_fd.fileno())
           lock_fd.close()
           self._lock_info_file().unlink(missing_ok=True)
           lock_path.unlink(missing_ok=True)
   ```

2. **Query method** `get_active_job_id(self) -> str | None`:
   - Read lock_info file
   - If exists and process running, return job_id
   - Otherwise return None

3. **Add JobLockError to exceptions.py** following existing pattern:
   - Inherit from `BatchError` (Task 5 adds this, or use `TeamsPhoneError` if BatchError not yet available)
   - `exit_code = 13` (JOB_LOCK_ERROR)
   - Constructor takes `active_job_id: str`, stores it, passes message to super()
   - Include remediation message suggesting user check `batch status`

4. **Add to constants.py**: `JOB_LOCK_ERROR = 13` in ExitCode enum

---

## Implementation Notes

### Session: 2026-02-04 22:45 - Agent: claude-opus-4-5-20251101

**Status:** Subtask 3.1 Implemented

#### What Was Done
- Added `_lock_file()` path helper method that returns `self.base_path / ".lock"` (job_store.py:82-92)
- Added `_acquire_file_lock(fd: int)` with platform detection for Windows (msvcrt.LK_NBLCK) and Unix (fcntl.LOCK_EX | LOCK_NB) (job_store.py:94-117)
- Added `_release_file_lock(fd: int)` with platform detection for Windows (msvcrt.LK_UNLCK) and Unix (fcntl.LOCK_UN) (job_store.py:119-137)
- Created comprehensive test suite: `tests/unit/test_job_store_locking.py` with 11 tests

#### Files Modified
- `src/teams_phone/infrastructure/job_store.py` - Added 3 locking methods after `_backup_file()`
- `tests/unit/test_job_store_locking.py` (new) - 11 unit tests for locking functionality

#### Key Decisions Made
- **Conditional imports inside methods**: Platform-specific modules (msvcrt, fcntl) are imported inside the methods rather than at module level. This avoids ImportError on platforms where the other module doesn't exist.
- **Exceptions propagate raw**: `_acquire_file_lock()` raises OSError (Windows) or BlockingIOError (Unix) directly. This follows the recon recommendation to let subtask 3.3's context manager wrap it in JobLockError with the active job ID.
- **Lock file at base_path level**: Lock file is `.teams-phone/jobs/.lock` (directly in base_path), not inside a job directory. This ensures global locking across all jobs.

#### Patterns Discovered
- **sys already imported**: `sys` import already exists in job_store.py at line 15 for stderr writes in list_jobs()
- **Path helper pattern**: Followed existing `_job_dir`, `_job_file`, `_backup_file` pattern exactly (job_store.py:49-80)

#### Test Structure
```
TestJobStoreLockFile (3 tests) - Path helper tests
TestJobStoreAcquireFileLock (4 tests) - Windows/Unix mock tests + error propagation
TestJobStoreReleaseFileLock (2 tests) - Windows/Unix mock tests
TestJobStoreFileLockingIntegration (2 tests) - Real lock/unlock on current platform
```

#### Open Items for Next Agent (Subtask 3.2)
- [ ] Implement `_lock_info_file()` path helper returning `.lock_info.json`
- [ ] Implement `_is_process_running(pid)` for stale lock detection
- [ ] Implement `_read_lock_info()` and `_write_lock_info()` methods
- [ ] Note: JobLockError already exists in exceptions.py:195-217 with exit_code=13

#### Gotchas and Warnings
- **msvcrt.locking requires file opened in binary mode**: Tests verify 'wb' mode works correctly for cross-platform compatibility
- **Windows error codes for lock contention**: errno 13 (EACCES) or errno 36 (EDEADLK) - tested in mocked Windows tests
- **Unix error for lock contention**: BlockingIOError with errno 11 (EAGAIN) - tested in mocked Unix tests

---

### Session: 2026-02-04 23:05 - Agent: claude-opus-4-5-20251101

**Status:** Subtask 3.2 Implemented

#### What Was Done
- Added `_lock_info_file()` path helper method returning `self.base_path / ".lock_info.json"` (job_store.py:93-103)
- Added `_is_process_running(pid: int) -> bool` using `os.kill(pid, 0)` for cross-platform process detection (job_store.py:152-171)
- Added `_read_lock_info(self) -> dict[str, Any] | None` to parse lock info JSON with field validation (job_store.py:173-198)
- Added `_write_lock_info(self, job_id: str) -> None` to create lock info JSON (job_store.py:200-222)
- Extended `tests/unit/test_job_store_locking.py` with 18 new tests (now 29 total)

#### Files Modified
- `src/teams_phone/infrastructure/job_store.py` - Added 4 new methods for lock info management
- `tests/unit/test_job_store_locking.py` - Added 5 new test classes with 18 tests

#### Key Decisions Made
- **Exception order in `_is_process_running`**: `PermissionError` must be caught before `OSError` since `PermissionError` is a subclass of `OSError`. PermissionError means the process exists but is owned by another user, so we return True.
- **Explicit type annotation for JSON data**: Added `data: dict[str, Any]` type hint to satisfy mypy strict mode (`no-any-return` rule).
- **Field validation in `_read_lock_info`**: Returns None if any of the required fields (`job_id`, `pid`, `started_at`) are missing, rather than raising an exception.

#### Patterns Discovered
- **`os.kill(pid, 0)` works cross-platform**: On both Windows and Unix, sending signal 0 checks process existence without actually sending a signal.
- **Path.write_text creates parent directories**: The `_write_lock_info` method creates parent directories using `mkdir(parents=True, exist_ok=True)` to handle fresh installations.

#### Test Structure
```
TestJobStoreLockInfoFile (3 tests) - Path helper tests
TestJobStoreIsProcessRunning (4 tests) - Process detection with current/nonexistent PIDs and error handling
TestJobStoreReadLockInfo (5 tests) - Missing file, valid JSON, malformed JSON, missing fields, OSError
TestJobStoreWriteLockInfo (6 tests) - File creation, job_id, PID, timestamp, parent directory, overwrite
```

#### Open Items for Next Agent (Subtask 3.3)
- [ ] Implement `acquire_lock(job_id)` context manager combining file lock + lock info
- [ ] Implement `get_active_job_id() -> str | None` query method
- [ ] Use JobLockError (already exists at exceptions.py:195-217) for lock contention
- [ ] Handle stale lock detection: if lock_info exists but process not running, clean up and allow new lock

#### Gotchas and Warnings
- **PermissionError is a subclass of OSError**: Exception handler order matters - catch PermissionError first
- **Lock info is advisory**: The file lock (from 3.1) is authoritative; lock info is for debugging and stale detection
- **JSON parsing errors return None**: `_read_lock_info` silently returns None on parse errors, letting the caller decide how to handle

---

### Session: 2026-02-04 23:30 - Agent: claude-opus-4-5-20251101

**Status:** Subtask 3.3 Implemented

#### What Was Done
- Added `get_active_job_id(self) -> str | None` query method (job_store.py:222-239)
- Added `acquire_lock(self, job_id: str)` context manager (job_store.py:241-293)
- Added imports: `Generator` from `collections.abc`, `contextmanager` from `contextlib`, `JobLockError` from exceptions
- Extended `tests/unit/test_job_store_locking.py` with 14 new tests (now 43 total)

#### Files Modified
- `src/teams_phone/infrastructure/job_store.py` - Added 2 public methods (acquire_lock, get_active_job_id) and updated imports
- `tests/unit/test_job_store_locking.py` - Added 3 new test classes with 14 tests

#### Key Decisions Made
- **Context manager uses `Generator[None, None, None]`**: Standard pattern for void-yielding context managers with proper type annotation
- **`str()` cast for job_id return**: Explicit cast from `dict[str, Any]` to satisfy mypy's `no-any-return` check
- **Exception chaining**: Used `raise JobLockError(active_id) from err` when file lock fails to preserve the original exception context
- **`noqa: SIM115` for open()**: The `open()` call cannot be replaced with a context manager because we need to keep the file descriptor open across the yield boundary

#### Patterns Discovered
- **Two-phase lock check**: First check stale lock from lock_info, then acquire actual file lock. This handles both crashed processes and active locks.
- **Lock cleanup on any exit**: The finally block ensures both lock file and lock info are cleaned up whether exiting normally or via exception.

#### Test Structure
```
TestJobStoreGetActiveJobId (3 tests) - None when no lock, job_id when held, None when stale
TestJobStoreAcquireLock (7 tests) - Success, normal exit cleanup, exception cleanup, stale cleanup,
                                    JobLockError on active lock, nested lock raises, creates base_path
TestJobLockErrorProperties (4 tests) - exit_code 13, stores active_job_id, message, remediation
```

#### Quality Gates Verified
- [x] All 43 tests pass
- [x] mypy strict mode: no issues found
- [x] ruff check: All checks passed
- [x] All acceptance criteria from task details met

#### Acceptance Criteria Verification
1. ✅ `acquire_lock(job_id)` context manager:
   - Checks for stale locks and cleans them up
   - Acquires file lock and writes lock info
   - Properly releases lock and cleans up files on normal exit
   - Properly releases lock and cleans up files on exception exit
   - Raises `JobLockError` when lock cannot be acquired
2. ✅ `get_active_job_id() -> str | None` query method:
   - Returns job_id if lock exists and process is running
   - Returns None if no lock or stale lock
3. ✅ Uses existing `JobLockError` from `exceptions.py`
4. ✅ Uses existing `JOB_LOCK_ERROR = 13` from `constants.py`

---
