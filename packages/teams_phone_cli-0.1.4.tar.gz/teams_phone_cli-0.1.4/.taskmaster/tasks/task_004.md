# Task ID: 4

**Title:** Implement CSV parser with validation

**Status:** pending

**Dependencies:** 1

**Priority:** high

**Description:** Create a batch CSV parser that handles BOM, various line endings, header validation, duplicate detection, phone number normalization, and extension stripping per REQ-017-020.

**Details:**

Create `src/teams_phone/services/batch_csv_parser.py`:

```python
import csv
import hashlib
import re
from pathlib import Path
from dataclasses import dataclass, field

from teams_phone.exceptions import ValidationError
from teams_phone.models.batch import JobItem, ItemStatus
from teams_phone.utils import normalize_phone_number

@dataclass
class CSVParseResult:
    items: list[dict]  # Raw dicts ready for JobItem creation
    warnings: list[str]
    input_hash: str

@dataclass
class CSVValidationError:
    line_number: int
    field: str
    value: str
    message: str
    suggested_fix: str | None = None

def parse_batch_csv(file_path: Path) -> CSVParseResult:
    """Parse batch migration CSV with full validation.
    
    Handles:
    - BOM stripping (utf-8-sig encoding)
    - CRLF, LF, CR line endings
    - Required headers: user_upn, phone_number
    - Empty value rejection
    - Phone number normalization and extension stripping
    - UPN lowercase normalization
    - Duplicate phone number detection
    - Duplicate user assignment detection
    """
    if not file_path.exists():
        raise ValidationError(
            f"CSV file not found: {file_path}",
            remediation="Verify the file path is correct."
        )
    
    # Read with BOM support
    content = file_path.read_bytes()
    input_hash = hashlib.sha256(content).hexdigest()
    
    # Normalize line endings to \n
    text = content.decode("utf-8-sig")  # Strips BOM
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    
    lines = text.split("\n")
    if not lines or not lines[0].strip():
        raise ValidationError(
            "CSV file is empty or has no header row",
            remediation="Provide a CSV with 'user_upn,phone_number' header."
        )
    
    reader = csv.DictReader(lines)
    
    # Validate headers
    if reader.fieldnames is None:
        raise ValidationError("CSV has no header row")
    
    headers = set(h.lower().strip() for h in reader.fieldnames)
    required = {"user_upn", "phone_number"}
    missing = required - headers
    if missing:
        raise ValidationError(
            f"CSV missing required columns: {', '.join(sorted(missing))}",
            remediation="Add 'user_upn' and 'phone_number' columns."
        )
    
    items = []
    warnings = []
    seen_phones = {}  # phone -> line_number
    seen_users = {}   # upn -> line_number
    errors = []
    
    for line_num, row in enumerate(reader, start=2):
        upn = row.get("user_upn", "").strip().lower()
        phone = row.get("phone_number", "").strip()
        
        # Empty value checks
        if not upn:
            errors.append(CSVValidationError(
                line_number=line_num,
                field="user_upn",
                value="",
                message="Required field is empty"
            ))
            continue
        if not phone:
            errors.append(CSVValidationError(
                line_number=line_num,
                field="phone_number", 
                value="",
                message="Required field is empty"
            ))
            continue
        
        # Strip extension (;ext=NNN)
        if ";ext=" in phone.lower():
            phone = re.split(r";ext=", phone, flags=re.IGNORECASE)[0]
            warnings.append(f"Line {line_num}: Phone extension stripped")
        
        # Normalize phone
        try:
            normalized_phone = normalize_phone_number(phone)
            phone = f"+{normalized_phone}"  # E.164
        except ValidationError:
            errors.append(CSVValidationError(
                line_number=line_num,
                field="phone_number",
                value=phone,
                message="Invalid phone number format"
            ))
            continue
        
        # Duplicate phone check
        if phone in seen_phones:
            errors.append(CSVValidationError(
                line_number=line_num,
                field="phone_number",
                value=phone,
                message=f"Duplicate phone number (first seen at line {seen_phones[phone]})"
            ))
            continue
        seen_phones[phone] = line_num
        
        # Duplicate user check
        if upn in seen_users:
            errors.append(CSVValidationError(
                line_number=line_num,
                field="user_upn",
                value=upn,
                message=f"Duplicate user assignment (first seen at line {seen_users[upn]})"
            ))
            continue
        seen_users[upn] = line_num
        
        items.append({
            "line_number": line_num,
            "user_upn": upn,
            "phone_number": phone,
            "status": ItemStatus.PENDING,
            "attempts": 0
        })
    
    if errors:
        # Format errors for display
        error_lines = [f"Line {e.line_number}: {e.field} - {e.message}" for e in errors]
        raise ValidationError(
            f"CSV validation failed with {len(errors)} errors:\n" + "\n".join(error_lines[:10]),
            remediation="Fix the reported errors and try again."
        )
    
    return CSVParseResult(items=items, warnings=warnings, input_hash=input_hash)
```

**Test Strategy:**

Unit tests in `tests/unit/test_batch_csv_parser.py`:
1. Test valid CSV parsing with minimal columns
2. Test BOM handling (write file with BOM, verify parsed)
3. Test CRLF, LF, CR line endings all parse correctly
4. Test missing required headers raises ValidationError
5. Test empty user_upn raises error with line number
6. Test empty phone_number raises error with line number
7. Test phone extension stripping generates warning
8. Test phone number normalization (various formats)
9. Test duplicate phone number detection with correct line refs
10. Test duplicate user assignment detection
11. Test extra columns are ignored (tolerant parsing)
12. Test empty lines are skipped
13. Use tmp_path fixture with test CSV files

## Subtasks

### 4.1. Implement core CSV parsing with BOM and line ending handling

**Status:** pending  
**Dependencies:** None  

Create the batch_csv_parser.py module with core parsing functionality that handles UTF-8 BOM stripping and normalizes CRLF/LF/CR line endings to ensure cross-platform compatibility.

**Details:**

Create `src/teams_phone/services/batch_csv_parser.py` with:

1. Define dataclasses for results:
   - `CSVParseResult(items: list[dict], warnings: list[str], input_hash: str)`
   - `CSVValidationError(line_number: int, field: str, value: str, message: str, suggested_fix: str | None = None)`

2. Implement `parse_batch_csv(file_path: Path) -> CSVParseResult` function:
   - Check file existence, raise ValidationError if missing
   - Read raw bytes and compute SHA-256 hash for `input_hash`
   - Decode with 'utf-8-sig' encoding to strip BOM
   - Normalize line endings: replace CRLF with LF, then CR with LF
   - Split into lines and handle empty file case
   - Use csv.DictReader to parse the normalized text

3. Import from teams_phone.exceptions.ValidationError and teams_phone.models.batch.ItemStatus

### 4.2. Implement header validation and row-level field validation

**Status:** pending  
**Dependencies:** 4.1  

Add header validation for required columns (user_upn, phone_number) and row-level validation including empty value rejection, phone number normalization using existing utils, and extension stripping.

**Details:**

Extend the parser with header and field validation:

1. Header validation:
   - Check reader.fieldnames is not None
   - Normalize headers to lowercase and strip whitespace
   - Validate required columns {'user_upn', 'phone_number'} are present
   - Raise ValidationError listing missing columns with remediation

2. Row iteration with validation:
   - Iterate rows with enumerate(reader, start=2) for 1-based line numbers
   - Extract and normalize user_upn: strip().lower()
   - Extract phone_number: strip()
   - Empty value checks: collect CSVValidationError for empty upn/phone

3. Phone number processing:
   - Strip extensions: use regex `re.split(r';ext=', phone, flags=re.IGNORECASE)[0]` and add warning
   - Normalize using existing `normalize_phone_number()` from utils.py
   - Format as E.164 with + prefix
   - Catch ValidationError for invalid format, collect as CSVValidationError

4. Build item dict with line_number, user_upn, phone_number, status=ItemStatus.PENDING, attempts=0

### 4.3. Implement duplicate detection with line number tracking

**Status:** pending  
**Dependencies:** 4.2  

Add duplicate detection for phone numbers and user UPNs, tracking the first occurrence line number for helpful error messages. Aggregate all validation errors and format for display.

**Details:**

Add duplicate detection and error aggregation:

1. Duplicate tracking structures:
   - `seen_phones: dict[str, int]` - maps normalized phone to first line number
   - `seen_users: dict[str, int]` - maps lowercase UPN to first line number
   - `errors: list[CSVValidationError]` - accumulates all validation errors

2. Duplicate phone detection:
   - After normalization, check if phone in seen_phones
   - If duplicate, create CSVValidationError with message like 'Duplicate phone number (first seen at line N)'
   - Otherwise, record phone -> line_number in seen_phones

3. Duplicate user detection:
   - Check if lowercase upn in seen_users
   - If duplicate, create CSVValidationError with first seen line reference
   - Otherwise, record upn -> line_number in seen_users

4. Error aggregation and display:
   - After processing all rows, check if errors list is non-empty
   - Format up to 10 errors as 'Line N: field - message'
   - Raise ValidationError with count and formatted errors
   - Include remediation: 'Fix the reported errors and try again.'

5. Return CSVParseResult with items, warnings, and input_hash

---

## Implementation Notes

### Session: 2026-02-04 22:30 - Agent: claude-opus-4-5-20251101

**Subtask:** 4.1 - Implement core CSV parsing with BOM and line ending handling

**Status:** Implemented

#### What Was Done
- Created `src/teams_phone/services/batch_csv_parser.py` with:
  - `CSVValidationError` dataclass for field-level validation errors
  - `CSVParseResult` dataclass with items, warnings, and input_hash
  - `parse_batch_csv(file_path: Path)` function with full BOM and line ending handling
- Created `tests/unit/test_batch_csv_parser.py` with 15 unit tests covering:
  - Dataclass instantiation and defaults
  - Valid CSV parsing with correct item counts
  - UTF-8 BOM handling (both bytes and text character)
  - CRLF, LF, and CR line ending normalization
  - Empty file validation error
  - Non-existent file validation error with remediation
  - Consistent SHA-256 hash computation
  - Header-only CSV returns empty items list
  - All columns preserved in output dicts

#### Key Decisions Made
- Used `dict[str, str]` for items instead of `dict` for better type safety
- Used `io.StringIO` to parse normalized text through csv.DictReader instead of passing list of lines directly (DictReader expects an iterable that yields strings including newlines or a file-like object)
- Empty file check happens before hash computation since empty files have a valid hash but should error immediately
- Header-only CSV is valid (returns empty items) vs empty file which raises error

#### Patterns Discovered
- **Circular import workaround**: Tests must import `GraphClient` before importing from `services.batch_csv_parser` due to circular import chain. See `test_bulk_operations_assignment_parsing.py:9-11` for pattern.
- **BOM handling pattern**: Using `utf-8-sig` codec handles BOM stripping automatically - no need for manual byte checking

#### Open Items for Next Agent
- Subtask 4.2 will add header validation for required columns (user_upn, phone_number) and row-level field validation
- Subtask 4.3 will add duplicate detection with line number tracking

#### Gotchas and Warnings
- Tests require the circular import workaround comment and `GraphClient` import at the top
- The `CSVValidationError` dataclass is defined but not yet used - it will be used in subtask 4.2 for field-level validation errors

---

### Session: 2026-02-04 23:45 - Agent: claude-opus-4-5-20251101

**Subtask:** 4.2 - Implement header validation and row-level field validation

**Status:** Implemented

#### What Was Done
- Extended `batch_csv_parser.py` with:
  - New imports: `re`, `normalize_phone_number` from utils, `ItemStatus` from models.batch
  - `_validate_headers()` helper function for case-insensitive header validation
  - `_validate_row()` helper function for row-level field validation
  - Header validation with case-insensitive matching (e.g., `User_UPN` matches `user_upn`)
  - Empty value rejection with line number tracking
  - Phone extension stripping with warnings (handles `;ext=NNN` case-insensitively)
  - Phone number normalization using `normalize_phone_number()` utility
  - E.164 formatting with `+` prefix
  - UPN lowercase normalization
  - Refactored to reduce cyclomatic complexity (extracted helper functions)
- Updated `CSVParseResult.items` type from `list[dict[str, str]]` to `list[dict[str, Any]]` to support `ItemStatus` enum values
- Updated test file constants from `user` to `user_upn` header format
- Added 14 new tests in `tests/unit/test_batch_csv_parser.py`:
  - `TestHeaderValidation` class (4 tests): missing user_upn, missing phone_number, missing both, case-insensitive matching
  - `TestFieldValidation` class (6 tests): empty user_upn, empty phone_number, phone extension stripping with warning, invalid phone format, valid phone normalization to E.164, UPN lowercased
  - `TestValidatedItemStructure` class (4 tests): required fields present, line_number correct, status is PENDING, attempts is 0

#### Key Decisions Made
- **Case-insensitive header matching**: Headers are normalized to lowercase for matching but original names are preserved for row access via a mapping dictionary
- **Item structure change**: Changed from raw CSV dicts to validated items with `line_number`, `user_upn`, `phone_number`, `status`, `attempts` fields
- **Error aggregation**: All validation errors are collected and raised together with line numbers for easy debugging
- **Refactored for complexity**: Extracted `_validate_headers()` and `_validate_row()` helper functions to reduce cyclomatic complexity from 16 to under 10

#### Patterns Discovered
- **Header case normalization pattern**: Build a mapping from normalized (lowercase) header names to original names: `{h.lower().strip(): h for h in fieldnames}`. This allows case-insensitive matching while preserving access to the original column names in the row dict.
- **Row validation pattern**: Return `None` for invalid rows, append to items list only for valid rows. This keeps the validation logic clean and avoids partial state.

#### Open Items for Next Agent
- Subtask 4.3 will add duplicate detection for phone numbers and user UPNs with line number tracking

#### Gotchas and Warnings
- The `normalize_phone_number()` function only extracts digits - a 10-digit number like `(206) 555-5678` becomes `+2065555678`, not `+12065555678` (no country code added)
- E.164 format is just `+` followed by digits - the function doesn't add country codes automatically
- Tests were updated to use `user_upn` header instead of legacy `user` header

---

### Session: 2026-02-05 00:00 - Agent: claude-opus-4-5-20251101

**Subtask:** 4.3 - Implement duplicate detection with line number tracking

**Status:** Implemented

#### What Was Done
- Extended `batch_csv_parser.py` with duplicate detection and error formatting:
  - Added `_check_duplicates()` helper function that tracks first occurrence of phones/UPNs
  - Added `_format_validation_errors()` helper function to format errors with 10-error limit
  - Duplicate phone numbers detected with message "Duplicate phone number (first seen at line N)"
  - Duplicate user UPNs detected with message "Duplicate user assignment (first seen at line N)"
  - Error format changed to "Line N: field - message" per spec
  - Display limited to first 10 errors with "... and N more error(s)" suffix
  - Refactored to keep parse_batch_csv under complexity limit (C901)
- Added 9 new tests in `tests/unit/test_batch_csv_parser.py` (`TestDuplicateDetection` class):
  - `test_duplicate_phone_number_raises_validation_error` - exact same phone number
  - `test_duplicate_upn_raises_validation_error` - exact same UPN
  - `test_duplicate_phone_different_formats_detected` - different formats normalize to same
  - `test_duplicate_upn_case_insensitive` - `User@Contoso.COM` matches `user@contoso.com`
  - `test_multiple_errors_aggregated` - empty field + duplicate in same file
  - `test_error_display_limited_to_10` - 11 duplicates shows 10 + "1 more"
  - `test_valid_csv_no_duplicates_returns_result` - happy path
  - `test_error_format_includes_field_name` - validates "Line N: field - message" format
  - `test_warnings_include_extension_stripped` - extension warnings still work

#### Key Decisions Made
- **Duplicate tracking uses normalized values**: Phone numbers are checked after E.164 normalization, UPNs after lowercase normalization - this catches duplicates with different formatting
- **Duplicates skip tracking dict update**: When a duplicate is found, it's not added to seen_phones/seen_users to prevent cascading errors (first occurrence wins)
- **Error limit is display-only**: All errors are collected for count, but only first 10 are shown in message
- **Refactored for complexity**: Extracted `_check_duplicates()` and `_format_validation_errors()` to stay under ruff C901 limit of 10

#### Patterns Discovered
- **First-seen tracking pattern**: `dict[str, int]` mapping value -> line_number, check before adding, only add on first occurrence
- **Error aggregation with limit pattern**: Collect all errors, format subset with count indicator

#### Completion Notes
- Task 4 (CSV parser with validation) is now complete with all 3 subtasks done
- Total test coverage: 38 tests in test_batch_csv_parser.py, all passing
- All quality gates pass: pytest, mypy, ruff

#### Gotchas and Warnings
- Duplicate detection happens AFTER field validation passes - rows with empty/invalid fields don't enter duplicate tracking
- The `continue` after duplicate detection skips adding to items list but doesn't prevent future rows from being checked
