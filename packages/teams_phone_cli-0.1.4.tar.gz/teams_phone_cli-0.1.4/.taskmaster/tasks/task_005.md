# Task ID: 5

**Title:** Add batch-specific exceptions

**Status:** pending

**Dependencies:** None

**Priority:** high

**Description:** Extend the exception hierarchy with BatchError, BatchValidationError, BatchExecutionError, JobNotFoundError, and JobLockError with specific exit codes 9-13.

**Details:**

Add to `src/teams_phone/exceptions.py`:

```python
class BatchError(TeamsPhoneError):
    """Base class for batch operation errors (exit code 9).
    
    Should not be raised directly - use specific subclasses.
    """
    exit_code: int = 9  # Note: Add to ExitCode enum

class BatchValidationError(BatchError):
    """Validation failed for one or more batch items (exit code 10).
    
    Raised when pre-flight validation detects preventable errors
    like non-existent users, unavailable numbers, or format issues.
    """
    exit_code: int = 10

class BatchExecutionError(BatchError):
    """Execution failed but state is preserved (exit code 11).
    
    Raised when runtime errors occur during batch execution.
    Job state is safely persisted and can be retried.
    """
    exit_code: int = 11

class JobNotFoundError(BatchError):
    """Job ID does not exist (exit code 12).
    
    Raised when attempting to access a job that doesn't exist
    in the jobs directory.
    """
    exit_code: int = 12

class JobLockError(BatchError):
    """Another job is already running (exit code 13).
    
    Raised when attempting to run a job while another is active.
    Only one job can run at a time to prevent rate limit conflicts.
    """
    exit_code: int = 13

    def __init__(self, active_job_id: str) -> None:
        self.active_job_id = active_job_id
        super().__init__(
            f"Another job is already running: {active_job_id}",
            remediation=f"Wait for job {active_job_id} to complete, or use 'batch status' to check progress."
        )
```

Update `src/teams_phone/constants.py` ExitCode enum:

```python
class ExitCode(IntEnum):
    # ... existing codes ...
    BATCH_ERROR = 9
    BATCH_VALIDATION_ERROR = 10
    BATCH_EXECUTION_ERROR = 11
    JOB_NOT_FOUND = 12
    JOB_LOCK_ERROR = 13
```

**Test Strategy:**

Unit tests in `tests/unit/test_exceptions.py` (extend existing):
1. Test BatchError has exit_code 9
2. Test BatchValidationError has exit_code 10
3. Test BatchExecutionError has exit_code 11
4. Test JobNotFoundError has exit_code 12
5. Test JobLockError has exit_code 13 and stores active_job_id
6. Test JobLockError remediation message includes job ID
7. Test all batch exceptions inherit from TeamsPhoneError

---

## Implementation Notes

### Session: 2026-02-04 16:15 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Added 5 new exit codes to `ExitCode` enum in `src/teams_phone/constants.py:107-119`
  - BATCH_ERROR (9), BATCH_VALIDATION_ERROR (10), BATCH_EXECUTION_ERROR (11), JOB_NOT_FOUND (12), JOB_LOCK_ERROR (13)
- Added 5 new exception classes to `src/teams_phone/exceptions.py:141-210`
  - `BatchError` - base class for all batch exceptions
  - `BatchValidationError` - pre-flight validation failures
  - `BatchExecutionError` - runtime failures with preserved state
  - `JobNotFoundError` - missing job IDs
  - `JobLockError` - concurrent execution prevention with custom `__init__`
- Added 17 new unit tests in `tests/unit/test_exceptions.py:227-339`
  - `TestBatchExceptionExitCodes` - 5 tests for exit code mapping
  - `TestBatchExceptionInheritance` - 5 tests for inheritance chain
  - `TestJobLockErrorBehavior` - 4 tests for custom `active_job_id` handling
  - `TestBatchExceptionRaising` - 3 tests for raise/catch behavior

#### Key Decisions Made
- Batch exceptions inherit from `BatchError` → `TeamsPhoneError` (two-level hierarchy)
- Used `ExitCode` enum values consistently in exception classes (not raw integers)
- Added section divider comment in exceptions.py for batch exceptions

#### Patterns Discovered
- Exception pattern: Set `exit_code: int` as class attribute referencing `ExitCode.<NAME>`
- Custom init pattern for `JobLockError`: Store attribute first, then call `super().__init__()` with message and remediation
- Test pattern: Assert both enum value and integer value for exit codes

#### Open Items for Next Agent
- [ ] None - task complete

#### Gotchas and Warnings
- Exit codes 0-8 were already in use - batch codes start at 9
- `JobLockError` is the only batch exception with custom `__init__` - remember to pass `active_job_id` not message

---
