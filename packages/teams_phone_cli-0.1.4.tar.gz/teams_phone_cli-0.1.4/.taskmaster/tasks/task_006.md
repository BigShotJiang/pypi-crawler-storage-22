# Task ID: 6

**Title:** Implement batch create CLI command

**Status:** pending

**Dependencies:** 2, 4, 5

**Priority:** high

**Description:** Add the `teams-phone batch create` command that creates a job from a CSV file, validates structure, generates job ID, and persists initial state.

**Details:**

Create `src/teams_phone/cli/batch.py`:

```python
from pathlib import Path
from typing import Annotated

import typer

from teams_phone.cli.context import CLIContext
from teams_phone.infrastructure.job_store import JobStore
from teams_phone.services.batch_csv_parser import parse_batch_csv

batch_app = typer.Typer(
    name="batch",
    help="Batch migration operations for bulk phone number assignments.",
    no_args_is_help=True,
)

@batch_app.command("create")
def batch_create(
    ctx: typer.Context,
    input_csv: Annotated[
        Path,
        typer.Argument(
            help="Path to CSV file with user_upn and phone_number columns.",
            exists=True,
            readable=True,
        ),
    ],
    name: Annotated[
        str | None,
        typer.Option(
            "--name", "-n",
            help="Job name for reference. Defaults to input filename.",
        ),
    ] = None,
) -> None:
    """Create a new batch migration job from a CSV file.
    
    The CSV must have 'user_upn' and 'phone_number' columns. Additional
    columns are ignored. The job is assigned a unique ID and persisted
    to .teams-phone/jobs/ for tracking.
    
    Example:
        teams-phone batch create migration.csv --name "Q1 Migration"
    """
    cli_ctx: CLIContext = ctx.obj
    formatter = cli_ctx.output_formatter
    
    # Default name to filename without extension
    job_name = name or input_csv.stem
    
    # Parse and validate CSV structure
    formatter.info(f"Parsing CSV: {input_csv}")
    try:
        parse_result = parse_batch_csv(input_csv)
    except ValidationError as e:
        formatter.error(str(e))
        raise typer.Exit(code=e.exit_code)
    
    # Show warnings if any
    for warning in parse_result.warnings:
        formatter.warning(warning)
    
    # Create job
    job_store = JobStore()
    job = job_store.create_job(
        name=job_name,
        input_file=input_csv,
        items=parse_result.items,
    )
    
    # Display result
    if cli_ctx.json_output:
        formatter.json_output(job.model_dump(mode="json"))
    else:
        formatter.success(f"Created job: {job.id}")
        formatter.info(f"  Name: {job.name}")
        formatter.info(f"  Items: {job.total_count}")
        formatter.info(f"  Status: {job.status.value}")
        formatter.info(f"\nNext step: teams-phone batch validate {job.id}")
```

Register in `cli/main.py`:
```python
from teams_phone.cli.batch import batch_app
app.add_typer(batch_app, name="batch", help="Batch migration operations.")
```

**Test Strategy:**

Unit tests in `tests/unit/test_cli_batch_create.py`:
1. Test valid CSV creates job with correct ID format
2. Test --name option sets job name
3. Test default name uses input filename
4. Test invalid CSV shows validation errors
5. Test JSON output format (--json flag)
6. Test job directory structure created correctly
7. Test warnings are displayed for extension stripping
8. Use CliRunner with tmp_path for test CSVs

---

## Implementation Notes

### Session: 2026-02-04 23:45 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Created `src/teams_phone/cli/batch.py` with `batch_app` Typer instance and `batch_create` command
- Registered `batch_app` in `src/teams_phone/cli/main.py`
- Created comprehensive unit tests in `tests/unit/test_cli_batch_create.py` (17 tests)

#### Key Decisions Made
- **CLI Context pattern**: Used `get_context(ctx)` and `cli_ctx.get_output_formatter()` instead of direct `ctx.obj` access, following numbers.py pattern
- **Error handling**: Catches `TeamsPhoneError` (base class) to handle both `ValidationError` from CSV parsing and `ConfigurationError` from JobStore
- **Argument type**: Used `Annotated[Path, typer.Argument(...)]` with `exists=True, readable=True, resolve_path=True` for automatic path validation
- **JSON output structure**: Exposed key job fields (job_id, name, status, item_count, input_file, input_hash, created_at) matching task spec

#### Patterns Discovered
- **ANSI stripping in tests**: Tests must use `result.plain_stdout` instead of `result.stdout` when checking for strings with numbers (ANSI codes are inserted around numeric values by Rich)
- **OutputFormatter access**: Use `cli_ctx.get_output_formatter()` method rather than `cli_ctx.output_formatter` directly (though both work since main.py callback initializes it)

#### Code References for Future Tasks
- CLI command pattern: `src/teams_phone/cli/batch.py:26-98`
- Test pattern with JobStore mock: `tests/unit/test_cli_batch_create.py:67-96`
- JSON output test pattern: `tests/unit/test_cli_batch_create.py:119-136`

#### Open Items for Next Agent
- [ ] Task 7: Implement `batch validate` command (validates users and numbers against Graph API)
- [ ] Task 8: Implement `batch execute` command (executes the migration)

#### Gotchas and Warnings
- When testing CLI output containing job IDs with numbers, use `result.plain_stdout` to avoid ANSI code interference
- JobStore mock must be patched at `teams_phone.cli.batch.JobStore` (where it's imported), not the infrastructure module

---
