# Task ID: 7

**Title:** Implement batch status CLI command

**Status:** pending

**Dependencies:** 2, 6

**Priority:** high

**Description:** Add `teams-phone batch status` command for listing all jobs (no args) and showing detailed status for a specific job (with job-id).

**Details:**

Extend `src/teams_phone/cli/batch.py`:

```python
from rich.table import Table
from rich.console import Console

@batch_app.command("status")
def batch_status(
    ctx: typer.Context,
    job_id: Annotated[
        str | None,
        typer.Argument(
            help="Job ID to show details for. If omitted, lists all jobs.",
        ),
    ] = None,
) -> None:
    """View batch job status.
    
    Without arguments, lists all jobs with summary statistics.
    With a job ID, shows detailed information about that specific job.
    
    Examples:
        teams-phone batch status                    # List all jobs
        teams-phone batch status 20260203-143015-a1b2-q1-migration  # Show details
    """
    cli_ctx: CLIContext = ctx.obj
    formatter = cli_ctx.output_formatter
    job_store = JobStore()
    
    if job_id is None:
        # List all jobs
        jobs = job_store.list_jobs()
        
        if not jobs:
            formatter.info("No batch jobs found.")
            formatter.info("Create a job with: teams-phone batch create <csv-file>")
            return
        
        if cli_ctx.json_output:
            formatter.json_output([j.model_dump(mode="json") for j in jobs])
            return
        
        # Rich table output
        console = Console(no_color=cli_ctx.no_color)
        table = Table(title="Batch Jobs")
        table.add_column("Job ID", style="cyan")
        table.add_column("Name")
        table.add_column("Status")
        table.add_column("Total")
        table.add_column("Succeeded", style="green")
        table.add_column("Failed", style="red")
        table.add_column("Pending")
        table.add_column("Created")
        
        for job in jobs:
            status_style = {
                JobStatus.COMPLETED: "green",
                JobStatus.RUNNING: "yellow",
                JobStatus.INTERRUPTED: "red",
            }.get(job.status, "")
            
            table.add_row(
                job.id,
                job.name,
                f"[{status_style}]{job.status.value}[/{status_style}]" if status_style else job.status.value,
                str(job.total_count),
                str(job.succeeded_count),
                str(job.failed_count),
                str(job.pending_count),
                job.created_at.strftime("%Y-%m-%d %H:%M"),
            )
        
        console.print(table)
    else:
        # Show specific job details
        try:
            job = job_store.load_job(job_id)
        except JobNotFoundError:
            formatter.error(f"Job not found: {job_id}")
            formatter.info("Use 'teams-phone batch status' to list available jobs.")
            raise typer.Exit(code=12)
        
        if cli_ctx.json_output:
            formatter.json_output(job.model_dump(mode="json"))
            return
        
        # Detailed view with items breakdown
        formatter.info(f"Job: {job.id}")
        formatter.info(f"Name: {job.name}")
        formatter.info(f"Status: {job.status.value}")
        formatter.info(f"Created: {job.created_at}")
        # ... additional details including failed items with errors
```

**Test Strategy:**

Unit tests in `tests/unit/test_cli_batch_status.py`:
1. Test status with no jobs shows helpful message
2. Test status lists all jobs in table format
3. Test status with job_id shows detailed info
4. Test status with invalid job_id shows error
5. Test JSON output for list and detail views
6. Test status colors based on job status
7. Test failed items are shown with error details

---

## Implementation Notes

### Session: 2026-02-04 23:50 - Agent: claude-opus-4-5-20251101

**Status:** Implemented

#### What Was Done
- Added `batch_status` command to `src/teams_phone/cli/batch.py` with optional `job_id` argument
- Implemented list view (no args) showing Rich table with all jobs and summary statistics
- Implemented detail view (with job_id) showing comprehensive job information including:
  - Job header with ID, name, status, input file, timestamps
  - Progress counts (total, succeeded, failed, pending)
  - Failed items table with error details
  - Needs review items table with reasons
  - Next steps guidance based on job status
- Added JSON output support for both views with structured data suitable for automation
- Refactored display logic into smaller helper functions to reduce cyclomatic complexity:
  - `_display_job_list()` - handles list view
  - `_display_job_detail()` - orchestrates detail view
  - `_display_job_detail_json()` - JSON output for detail
  - `_display_job_header()` - job header section
  - `_display_job_progress()` - progress counts section
  - `_display_job_problem_items()` - failed/needs_review tables
  - `_display_job_next_steps()` - next steps guidance
- Created comprehensive test suite in `tests/unit/test_cli_batch_status.py` (19 tests)

#### Key Decisions Made
- **NotFoundError vs JobNotFoundError**: Used `NotFoundError` (exit code 4) as raised by JobStore.load_job(), matching existing patterns (Task 6 notes warned about this)
- **Rich table for job list**: Used Rich Table directly with Console for custom styling, matching the pattern from other CLI commands
- **Status color mapping**: Created `STATUS_STYLES` dict at module level for consistent status coloring (green=success states, yellow=in-progress, red=error states)
- **Complexity refactor**: Split `_display_job_detail()` into 5 smaller functions to satisfy C901 complexity limit (10)

#### Patterns Discovered
- CLI context usage: Use `get_context(ctx)` from `teams_phone.cli.context` to get typed `CLIContext`
- Type hints for imports: Add runtime imports to `TYPE_CHECKING` block, use bare names in annotations (not quoted strings)
- Rich table truncation: Long job IDs get truncated by Rich tables; tests should check for prefixes

#### Open Items for Next Agent
- None - task fully implemented

#### Gotchas and Warnings
- **ANSI in tests**: Use `result.plain_stdout` instead of `result.stdout` for reliable string matching (ANSI codes can split text)
- **Job ID truncation**: Rich tables may truncate long job IDs; if testing table output, check for prefixes not full IDs
- **Unused imports**: Don't put imports inside function bodies for type hints; use `TYPE_CHECKING` block instead

---
