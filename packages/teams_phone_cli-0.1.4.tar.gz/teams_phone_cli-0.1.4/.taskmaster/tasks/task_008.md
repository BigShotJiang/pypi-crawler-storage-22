# Task ID: 8

**Title:** Implement ValidationService for pre-flight checks

**Status:** pending

**Dependencies:** 1, 5

**Priority:** high

**Description:** Create a ValidationService that performs pre-flight validation: user existence via Graph API, number availability via NumberService, and phone format validation.

**Details:**

Create `src/teams_phone/services/validation_service.py`:

```python
from dataclasses import dataclass
from typing import TYPE_CHECKING

from teams_phone.exceptions import NotFoundError, ValidationError
from teams_phone.models.batch import Job, JobItem, ItemStatus
from teams_phone.models import AssignmentStatus

if TYPE_CHECKING:
    from teams_phone.services.user_service import UserService
    from teams_phone.services.number_service import NumberService

@dataclass
class ValidationIssue:
    line_number: int
    field: str
    value: str
    error_code: str
    error_message: str
    suggested_fix: str | None = None

@dataclass  
class ValidationReport:
    total_items: int
    valid_count: int
    invalid_count: int
    issues: list[ValidationIssue]
    warnings: list[str]

class ValidationService:
    """Pre-flight validation for batch operations."""
    
    def __init__(
        self,
        user_service: "UserService",
        number_service: "NumberService",
    ) -> None:
        self.user_service = user_service
        self.number_service = number_service
    
    async def validate_job(
        self,
        job: Job,
        *,
        check_licenses: bool = False,
    ) -> tuple[Job, ValidationReport]:
        """Validate all items in a job.
        
        Performs:
        - Phone number format validation (E.164)
        - User existence check via Graph API
        - Optional license validation (--check-licenses)
        - Number existence and availability check
        - Idempotency: number already assigned to target user = valid
        
        Returns:
            Tuple of (updated_job, validation_report)
        """
        issues = []
        warnings = []
        
        for item in job.items:
            # Skip already completed items
            if item.status in (ItemStatus.SUCCEEDED, ItemStatus.NEEDS_REVIEW):
                continue
            
            # Validate user exists
            try:
                user = await self.user_service.resolve_user(item.user_upn)
                user_id = user.id
            except NotFoundError:
                issues.append(ValidationIssue(
                    line_number=item.line_number,
                    field="user_upn",
                    value=item.user_upn,
                    error_code="BATCH_003",
                    error_message="User not found in tenant",
                    suggested_fix="Verify the UPN is correct and user exists in Azure AD."
                ))
                item.status = ItemStatus.FAILED
                item.error_code = "BATCH_003"
                item.error_message = "User not found"
                continue
            
            # Optional license check
            if check_licenses:
                # Check user.is_enterprise_voice_enabled
                if not user.is_enterprise_voice_enabled:
                    issues.append(ValidationIssue(
                        line_number=item.line_number,
                        field="user_upn",
                        value=item.user_upn,
                        error_code="BATCH_004",
                        error_message="User lacks Teams Phone license",
                        suggested_fix="Assign Teams Phone license to user."
                    ))
                    item.status = ItemStatus.FAILED
                    item.error_code = "BATCH_004"
                    item.error_message = "User not licensed"
                    continue
            
            # Validate number exists and is available
            try:
                number = await self.number_service.get_number(item.phone_number)
                
                # Check idempotency: already assigned to this user = success
                if number.assignment_target_id == user_id:
                    item.status = ItemStatus.SUCCEEDED
                    item.error_message = "Already assigned (idempotent)"
                    continue
                
                # Check if available
                if number.assignment_status != AssignmentStatus.UNASSIGNED:
                    issues.append(ValidationIssue(
                        line_number=item.line_number,
                        field="phone_number",
                        value=item.phone_number,
                        error_code="BATCH_006",
                        error_message=f"Number assigned to another user",
                        suggested_fix="Use an unassigned number or unassign first."
                    ))
                    item.status = ItemStatus.FAILED
                    item.error_code = "BATCH_006"
                    item.error_message = "Number unavailable"
                    continue
                    
            except NotFoundError:
                issues.append(ValidationIssue(
                    line_number=item.line_number,
                    field="phone_number",
                    value=item.phone_number,
                    error_code="BATCH_005",
                    error_message="Number not found in tenant inventory",
                    suggested_fix="Verify the number exists in your Teams Phone inventory."
                ))
                item.status = ItemStatus.FAILED
                item.error_code = "BATCH_005"
                item.error_message = "Number not found"
                continue
        
        valid_count = sum(1 for i in job.items if i.status != ItemStatus.FAILED)
        invalid_count = len(issues)
        
        report = ValidationReport(
            total_items=len(job.items),
            valid_count=valid_count,
            invalid_count=invalid_count,
            issues=issues,
            warnings=warnings,
        )
        
        return job, report
```

**Test Strategy:**

Unit tests in `tests/unit/test_validation_service.py`:
1. Test user exists validation (mock UserService.resolve_user)
2. Test user not found sets FAILED status with BATCH_003
3. Test license check when --check-licenses enabled
4. Test number exists validation (mock NumberService.get_number)
5. Test number not found sets FAILED with BATCH_005
6. Test number unavailable (assigned to other user) sets BATCH_006
7. Test idempotency: number already assigned to target user = SUCCEEDED
8. Test validation report counts are correct
9. Test skipping already SUCCEEDED items

## Subtasks

### 8.1. Create ValidationService class structure with service dependencies

**Status:** pending  
**Dependencies:** None  

Create the ValidationService class with UserService and NumberService injected dependencies, along with ValidationIssue and ValidationReport dataclasses for structured error reporting.

**Details:**

Create `src/teams_phone/services/validation_service.py` with:

1. Import statements:
   - `from dataclasses import dataclass`
   - `from typing import TYPE_CHECKING`
   - `from teams_phone.exceptions import NotFoundError, ValidationError`
   - Use TYPE_CHECKING guard for UserService and NumberService imports to avoid circular imports

2. Define `ValidationIssue` dataclass with fields:
   - `line_number: int` - CSV line number for error reference
   - `field: str` - The field that failed validation ('user_upn' or 'phone_number')
   - `value: str` - The invalid value
   - `error_code: str` - Batch error code (BATCH_003 through BATCH_006)
   - `error_message: str` - Human-readable error description
   - `suggested_fix: str | None = None` - Optional remediation guidance

3. Define `ValidationReport` dataclass with fields:
   - `total_items: int` - Total items in the job
   - `valid_count: int` - Count of items that passed validation
   - `invalid_count: int` - Count of items that failed (len of issues)
   - `issues: list[ValidationIssue]` - Collected validation issues
   - `warnings: list[str]` - Non-fatal warnings

4. Create `ValidationService` class:
   - `__init__(self, user_service: 'UserService', number_service: 'NumberService')` - Store both services as instance attributes
   - Add docstring explaining the service coordinates pre-flight validation for batch operations

5. Add placeholder `validate_job` async method signature that will be implemented in subsequent subtasks.

### 8.2. Implement user existence and license validation logic

**Status:** pending  
**Dependencies:** 8.1  

Add user validation logic to validate_job that checks user existence via UserService.resolve_user() and optionally validates Teams Phone license via is_enterprise_voice_enabled.

**Details:**

Extend the `validate_job` method to perform user validation:

1. Method signature:
   ```python
   async def validate_job(
       self,
       job: Job,
       *,
       check_licenses: bool = False,
   ) -> tuple[Job, ValidationReport]:
   ```

2. Initialize tracking variables:
   - `issues: list[ValidationIssue] = []`
   - `warnings: list[str] = []`

3. Iterate through `job.items` and for each item:
   - Skip items with status `ItemStatus.SUCCEEDED` or `ItemStatus.NEEDS_REVIEW` (already processed)
   - Attempt user resolution:
     ```python
     try:
         user = await self.user_service.resolve_user(item.user_upn)
         user_id = user.id
     except NotFoundError:
         # Create ValidationIssue with BATCH_003
         # Set item.status = ItemStatus.FAILED
         # Set item.error_code = 'BATCH_003'
         # Set item.error_message = 'User not found'
         # continue to next item
     ```

4. When `check_licenses=True`, after successful user resolution:
   - Check `user.is_enterprise_voice_enabled`
   - If False, create ValidationIssue with:
     - error_code='BATCH_004'
     - error_message='User lacks Teams Phone license'
     - suggested_fix='Assign Teams Phone license to user.'
   - Set item.status = ItemStatus.FAILED, error_code='BATCH_004'
   - continue to next item

5. Store `user_id` for number validation in next subtask (can use a local variable or dict).

Note: Requires importing Job, JobItem, ItemStatus from teams_phone.models.batch (which will be created per task dependencies).

### 8.3. Implement number existence and availability validation

**Status:** pending  
**Dependencies:** 8.2  

Add phone number validation logic to validate_job that checks number existence via NumberService.get_number() and verifies the number is unassigned or available.

**Details:**

Extend `validate_job` to perform number validation after successful user validation:

1. After user validation passes (user exists and optionally licensed), validate the phone number:
   ```python
   try:
       number = await self.number_service.get_number(item.phone_number)
   except NotFoundError:
       # Create ValidationIssue with BATCH_005
       issues.append(ValidationIssue(
           line_number=item.line_number,
           field='phone_number',
           value=item.phone_number,
           error_code='BATCH_005',
           error_message='Number not found in tenant inventory',
           suggested_fix='Verify the number exists in your Teams Phone inventory.'
       ))
       item.status = ItemStatus.FAILED
       item.error_code = 'BATCH_005'
       item.error_message = 'Number not found'
       continue
   ```

2. Check number availability using AssignmentStatus enum:
   - Import `from teams_phone.models import AssignmentStatus`
   - If `number.assignment_status != AssignmentStatus.UNASSIGNED`:
     - AND number is NOT assigned to the target user (idempotency handled in subtask 4)
     - Create ValidationIssue with BATCH_006:
       - error_code='BATCH_006'
       - error_message='Number assigned to another user'
       - suggested_fix='Use an unassigned number or unassign first.'
     - Set item.status = ItemStatus.FAILED
     - Set item.error_code = 'BATCH_006'
     - Set item.error_message = 'Number unavailable'
     - continue to next item

3. The number model (`NumberAssignment`) has:
   - `assignment_status: AssignmentStatus` - enum with UNASSIGNED, USER_ASSIGNED, etc.
   - `assignment_target_id: str | None` - the user ID the number is assigned to (used for idempotency in subtask 4)

### 8.4. Implement idempotency detection and ValidationReport generation

**Status:** pending  
**Dependencies:** 8.3  

Add idempotency handling to detect when a number is already assigned to the target user (mark as succeeded), and finalize the ValidationReport with aggregated issue counts.

**Details:**

Complete the `validate_job` method with idempotency logic and report generation:

1. During number availability check (before BATCH_006 error), add idempotency detection:
   ```python
   # Check idempotency: already assigned to this user = success
   if number.assignment_target_id == user_id:
       item.status = ItemStatus.SUCCEEDED
       item.error_message = 'Already assigned (idempotent)'
       continue  # Skip to next item, no issues added
   ```
   This must come BEFORE the UNASSIGNED check, since the number IS assigned but to the correct user.

2. After processing all items, calculate final counts:
   ```python
   valid_count = sum(
       1 for i in job.items 
       if i.status != ItemStatus.FAILED
   )
   invalid_count = len(issues)
   ```

3. Build and return the ValidationReport:
   ```python
   report = ValidationReport(
       total_items=len(job.items),
       valid_count=valid_count,
       invalid_count=invalid_count,
       issues=issues,
       warnings=warnings,
   )
   return job, report
   ```

4. Add comprehensive docstring to `validate_job` explaining:
   - What validations are performed (E.164 format, user existence, optional license, number existence, availability)
   - Idempotency behavior (number already assigned to target = valid)
   - Return value semantics (tuple of updated job and validation report)

5. Export ValidationService, ValidationIssue, ValidationReport from services package:
   - Update `src/teams_phone/services/__init__.py` to include new exports

---

## Implementation Notes

### Session: 2026-02-04 17:45 - Agent: claude-opus-4-5-20251101

**Status:** Implemented (Subtask 8.1 only)

#### What Was Done
- Created `src/teams_phone/services/validation_service.py` with:
  - `ValidationIssue` dataclass with all required fields (line_number, field, value, error_code, error_message, suggested_fix)
  - `ValidationReport` dataclass with all required fields (total_items, valid_count, invalid_count, issues, warnings)
  - `ValidationService` class with UserService and NumberService dependencies injected
  - Placeholder `validate_job` async method signature returning tuple[Job, ValidationReport]
- Created `tests/unit/test_validation_service.py` with 9 unit tests covering:
  - ValidationIssue dataclass instantiation with required and optional fields
  - ValidationReport dataclass instantiation with counts, issues, and warnings
  - ValidationService initialization accepting both service dependencies
  - validate_job method returning correct tuple type and placeholder counts

#### Key Decisions Made
- **Used TYPE_CHECKING guard**: Following project pattern from user_service.py and number_service.py to avoid circular imports
- **Used dataclasses instead of Pydantic**: ValidationIssue and ValidationReport are simple data containers used internally, not API contracts. Dataclasses are simpler and follow the pattern used in batch_csv_parser.py for CSVValidationError
- **Placeholder returns all valid**: The placeholder validate_job marks all items as valid (valid_count = len(items), invalid_count = 0) since actual validation will be implemented in subtasks 8.2-8.4
- **Issues and warnings default to empty lists**: Using `field(default_factory=list)` for mutable default values

#### Patterns Discovered
- Circular import workaround in tests: Import `GraphClient` from infrastructure before importing from services to break circular import chain (see `test_user_service.py:11-13`)
- Service pattern: Services accept other services or GraphClient in constructor, stored as instance attributes
- Dataclass pattern for validation errors: See `batch_csv_parser.py:23-40` for CSVValidationError as reference

#### Open Items for Next Agent
- [ ] Subtask 8.2: Implement user existence and license validation logic
- [ ] Subtask 8.3: Implement number existence and availability validation
- [ ] Subtask 8.4: Implement idempotency detection and ValidationReport generation
- [ ] ValidationService is NOT exported from services/__init__.py (same pattern as UserService/NumberService due to circular import concerns)

#### Gotchas and Warnings
- **Do not export from services/__init__.py**: Following pattern from UserService/NumberService comment at line 9-12 of __init__.py. Import directly: `from teams_phone.services.validation_service import ValidationService`
- **Test imports require GraphClient import first**: Tests must import `from teams_phone.infrastructure import GraphClient` before importing from services modules to avoid circular import error

---

### Session: 2026-02-04 18:30 - Agent: claude-opus-4-5-20251101

**Status:** Implemented (Subtask 8.2)

#### What Was Done
- Modified `src/teams_phone/services/validation_service.py`:
  - Added imports: `NotFoundError` from exceptions, `ItemStatus` from batch
  - Updated `validate_job` method signature with `check_licenses: bool = False` parameter
  - Implemented user validation loop:
    - Skips items with `ItemStatus.SUCCEEDED` or `ItemStatus.NEEDS_REVIEW`
    - Calls `resolve_user` via UserService
    - Creates `BATCH_003` issue when user not found, sets item to FAILED
    - Creates `BATCH_004` issue when license check enabled and user not licensed
  - Calculates `valid_count` and `invalid_count` properly, accounting for skipped items
- Extended `tests/unit/test_validation_service.py`:
  - Added imports: `AsyncMock`, `NotFoundError`, `ItemStatus`, `UserConfiguration`
  - Added `make_user_dict()` helper function for creating test user configurations
  - Updated `make_job_item()` to accept optional `status` parameter
  - Added 10 new tests in `TestValidationServiceUserValidation` class:
    - `test_user_exists_no_issues_added`
    - `test_user_not_found_creates_batch_003_issue`
    - `test_license_check_enabled_user_licensed_no_issues`
    - `test_license_check_enabled_user_unlicensed_creates_batch_004`
    - `test_license_check_disabled_unlicensed_user_no_issues`
    - `test_skips_succeeded_items`
    - `test_skips_needs_review_items`
    - `test_processes_multiple_items`
    - `test_mixed_success_and_failure`

#### Key Decisions Made
- **Mutable item patterns**: Items are mutated in place (status, error_code, error_message) following the pattern from the task details
- **Skipped items in valid_count**: Skipped items (SUCCEEDED/NEEDS_REVIEW) are excluded from valid_count since they were already processed in a previous validation run
- **Keywords-only for check_licenses**: Used `*` in signature to force keyword argument, matching the pattern in the task spec

#### Patterns Discovered
- **AsyncMock with side_effect for multiple calls**: `AsyncMock(side_effect=[result1, result2, NotFoundError(...)])` for testing multiple user lookups
- **UserConfiguration from dict**: Use `UserConfiguration(**make_user_dict())` to create test user objects from the same dict format as Graph API

#### Open Items for Next Agent
- [ ] Subtask 8.3: Implement number existence and availability validation (store user_id from resolve_user for idempotency check)
- [ ] Subtask 8.4: Implement idempotency detection and ValidationReport generation
- [ ] The `user_id` from resolved users is not currently stored - subtask 8.3 will need to capture it

#### Gotchas and Warnings
- **Test requires UserConfiguration import**: Add `from teams_phone.models.user import UserConfiguration` to test imports
- **Item status is mutated in place**: Tests should verify both the returned `report.issues` AND the `job.items[x].status` changes
- **valid_count calculation complexity**: Need to handle skipped items (pre-existing SUCCEEDED/NEEDS_REVIEW) separately from items that failed validation

---

### Session: 2026-02-04 23:55 - Agent: claude-opus-4-5-20251101

**Status:** Implemented (Subtask 8.3)

#### What Was Done
- Modified `src/teams_phone/services/validation_service.py`:
  - Added import: `AssignmentStatus` from `teams_phone.models`
  - Added number validation logic after license check (lines 153-189):
    - Calls `get_number` via NumberService with the item's phone number
    - Creates `BATCH_005` issue when number not found, sets item to FAILED
    - Creates `BATCH_006` issue when number is assigned (not UNASSIGNED), sets item to FAILED
  - Added comment noting idempotency check is handled in subtask 8.4
- Extended `tests/unit/test_validation_service.py`:
  - Added import: `NumberAssignment` from `teams_phone.models.number`
  - Added `make_number_dict()` helper function for creating test number assignment data
  - Updated existing user validation tests to mock `get_number` with AsyncMock (tests now pass user validation then hit number validation)
  - Added 8 new tests in `TestValidationServiceNumberValidation` class:
    - `test_number_exists_and_unassigned_no_issues`
    - `test_number_not_found_creates_batch_005_issue`
    - `test_number_assigned_to_another_user_creates_batch_006_issue`
    - `test_number_assigned_to_conference_creates_batch_006_issue`
    - `test_number_assigned_to_voice_app_creates_batch_006_issue`
    - `test_mixed_number_states_correct_counts`
    - `test_user_failure_skips_number_validation`
    - `test_license_failure_skips_number_validation`

#### Key Decisions Made
- **BATCH_006 applies to all non-UNASSIGNED states**: Any `assignment_status` that is not `UNASSIGNED` (userAssigned, conferenceAssigned, voiceApplicationAssigned) triggers BATCH_006
- **Idempotency deferred to subtask 8.4**: As specified, we do NOT check if the number is assigned to the target user yet - that check happens in subtask 8.4
- **Number validation after user/license validation**: Following the validation order in the spec, number checks only occur if user validation passes

#### Patterns Discovered
- **NumberAssignment from dict**: Use `NumberAssignment(**make_number_dict())` to create test number objects
- **AsyncMock return vs side_effect**: `AsyncMock(return_value=number)` for success, `AsyncMock(side_effect=NotFoundError(...))` for failures
- **Existing tests needed updating**: User validation tests now require mocking `get_number` since number validation runs after user validation passes

#### Open Items for Next Agent
- [ ] Subtask 8.4: Implement idempotency detection (check if `number.assignment_target_id == user_id`)
- [ ] Subtask 8.4: Store `user_id` from resolved user to enable idempotency comparison
- [ ] Note: Current implementation will incorrectly fail idempotent cases until subtask 8.4 is complete

#### Gotchas and Warnings
- **All user validation tests needed updates**: After adding number validation, existing tests that pass user validation now also need to mock `get_number` to avoid TypeError
- **AssignmentStatus import from models**: Use `from teams_phone.models import AssignmentStatus` (not from models.number)
- **Tests verify number service NOT called on user failure**: Important to confirm number validation is skipped when user validation fails (avoid unnecessary API calls)

---

### Session: 2026-02-05 00:30 - Agent: claude-opus-4-5-20251101

**Status:** Implemented (Subtask 8.4 - Final subtask)

#### What Was Done
- Modified `src/teams_phone/services/validation_service.py`:
  - Captured `user_id = user.id` after successful `resolve_user()` call (line 119)
  - Added idempotency check BEFORE the UNASSIGNED check (lines 198-202):
    ```python
    if number.assignment_target_id == user_id:
        item.status = ItemStatus.SUCCEEDED
        item.error_message = "Already assigned (idempotent)"
        continue
    ```
  - Simplified `valid_count` calculation to match task spec (line 222):
    ```python
    valid_count = sum(1 for item in job.items if item.status != ItemStatus.FAILED)
    ```
  - Added comprehensive docstring to `validate_job` documenting all 5 validation steps, item status updates, and return semantics
- Modified `src/teams_phone/services/__init__.py`:
  - Added comment documenting how to import ValidationService (lines 13-16) following same pattern as UserService/NumberService
- Extended `tests/unit/test_validation_service.py`:
  - Added `TestValidationServiceIdempotency` class with 3 tests:
    - `test_idempotent_assignment_marks_item_succeeded`
    - `test_idempotent_vs_assigned_to_other_user`
    - `test_multiple_idempotent_items`
  - Added `TestValidationServiceReportCounts` class with 6 tests:
    - `test_valid_count_includes_pending_and_idempotent`
    - `test_mixed_valid_idempotent_and_failed`
    - `test_pre_existing_succeeded_items_skipped_but_count_as_valid`
    - `test_issues_list_preserves_order`
    - `test_warnings_list_passed_through`
    - `test_comprehensive_job_with_all_states` (integration test)

#### Key Decisions Made
- **Idempotency check BEFORE UNASSIGNED check**: Critical ordering - if a number is assigned to the target user, we mark SUCCEEDED without checking if it's UNASSIGNED (since it obviously isn't, being assigned to someone)
- **valid_count includes all non-FAILED items**: Per task spec, `valid_count = sum(1 for i in job.items if i.status != ItemStatus.FAILED)`. This means PENDING, SUCCEEDED (both idempotent and pre-existing), and NEEDS_REVIEW all count as valid
- **error_code is None for idempotent items**: Idempotent cases set `error_message` but NOT `error_code`, since it's not an error - it's a success that doesn't need execution
- **Export via comment only**: Following existing pattern for UserService/NumberService, ValidationService is NOT directly exported from `__init__.py` to avoid circular imports. Import directly from the module.

#### Patterns Discovered
- **Idempotency detection flow**: Check `number.assignment_target_id == user_id` to determine if the number is already assigned to the target user. This must happen AFTER `get_number()` succeeds but BEFORE the `assignment_status != UNASSIGNED` check.
- **Report count formula**: `valid_count` = all items that are not FAILED (PENDING + SUCCEEDED + NEEDS_REVIEW). `invalid_count` = len(issues) which equals FAILED count.

#### Open Items for Next Agent
- ValidationService is now fully implemented
- Task 8 can be marked as done once all subtasks are verified
- ValidationService can be used by the BatchService (task 9) for pre-flight validation

#### Gotchas and Warnings
- **Idempotent items have no error_code**: Tests should verify `job.items[x].error_code is None` for idempotent cases
- **valid_count includes idempotent SUCCEEDED**: Pre-task 8.4 tests may have assumed SUCCEEDED items were excluded from valid_count - they're not
- **Import pattern**: `from teams_phone.services.validation_service import ValidationService, ValidationIssue, ValidationReport`
