# Task ID: 9

**Title:** Implement batch validate CLI command

**Status:** pending

**Dependencies:** 7, 8

**Priority:** high

**Description:** Add `teams-phone batch validate` command that runs pre-flight validation on a job and displays a validation report.

**Details:**

Extend `src/teams_phone/cli/batch.py`:

```python
import asyncio

from teams_phone.services.validation_service import ValidationService
from teams_phone.models.batch import JobStatus

@batch_app.command("validate")
def batch_validate(
    ctx: typer.Context,
    job_id: Annotated[
        str,
        typer.Argument(help="Job ID to validate."),
    ],
    strict: Annotated[
        bool,
        typer.Option(
            "--strict",
            help="Fail on any validation warning.",
        ),
    ] = False,
    check_licenses: Annotated[
        bool,
        typer.Option(
            "--check-licenses",
            help="Validate users have Teams Phone license (adds latency).",
        ),
    ] = False,
) -> None:
    """Validate a batch job before execution.
    
    Performs pre-flight validation without making any changes to your tenant:
    - Verifies all users exist in Azure AD
    - Verifies all phone numbers are in your inventory
    - Checks that numbers are unassigned (or assigned to target user)
    - Optionally checks Teams Phone licensing with --check-licenses
    
    Example:
        teams-phone batch validate 20260203-143015-a1b2-migration --check-licenses
    """
    cli_ctx: CLIContext = ctx.obj
    formatter = cli_ctx.output_formatter
    
    # Load job
    job_store = JobStore()
    try:
        job = job_store.load_job(job_id)
    except JobNotFoundError:
        formatter.error(f"Job not found: {job_id}")
        raise typer.Exit(code=12)
    
    # Verify job in valid state for validation
    if job.status not in (JobStatus.CREATED, JobStatus.VALIDATED):
        formatter.error(f"Job cannot be validated in {job.status.value} state")
        raise typer.Exit(code=5)
    
    # Run validation
    job.status = JobStatus.VALIDATING
    job_store.save_job(job)
    
    async def run_validation():
        # Set up services (need auth context)
        config_manager = cli_ctx.get_config_manager()
        tenant_name = cli_ctx.tenant or config_manager.get_default_tenant()
        tenant = config_manager.get_tenant(tenant_name)
        auth_service = AuthService(tenant)
        
        async with GraphClient(auth_service) as client:
            user_service = UserService(client)
            number_service = NumberService(client)
            validation_service = ValidationService(user_service, number_service)
            
            return await validation_service.validate_job(
                job,
                check_licenses=check_licenses,
            )
    
    formatter.info(f"Validating job: {job_id}")
    with formatter.progress() as progress:
        task = progress.add_task("Validating...", total=job.total_count)
        updated_job, report = asyncio.run(run_validation())
        progress.update(task, completed=job.total_count)
    
    # Update job status based on validation result
    updated_job.status = JobStatus.VALIDATED if report.invalid_count == 0 else JobStatus.CREATED
    job_store.save_job(updated_job)
    
    # Display report
    if cli_ctx.json_output:
        formatter.json_output({
            "job_id": job_id,
            "valid": report.invalid_count == 0,
            "total": report.total_items,
            "valid_count": report.valid_count,
            "invalid_count": report.invalid_count,
            "issues": [vars(i) for i in report.issues],
        })
        return
    
    formatter.info(f"\nValidation Results:")
    formatter.info(f"  Total items: {report.total_items}")
    formatter.success(f"  Valid: {report.valid_count}")
    if report.invalid_count > 0:
        formatter.error(f"  Invalid: {report.invalid_count}")
    
    if report.issues:
        formatter.info("\nIssues:")
        for issue in report.issues[:20]:  # Limit display
            formatter.error(f"  Line {issue.line_number}: [{issue.error_code}] {issue.error_message}")
            if issue.suggested_fix:
                formatter.info(f"    Fix: {issue.suggested_fix}")
    
    if report.invalid_count > 0:
        formatter.info(f"\nFix issues and re-run: teams-phone batch validate {job_id}")
        raise typer.Exit(code=10)  # BatchValidationError exit code
    else:
        formatter.success("\nValidation passed!")
        formatter.info(f"Next step: teams-phone batch run {job_id}")
```

**Test Strategy:**

Unit tests in `tests/unit/test_cli_batch_validate.py`:
1. Test validate on CREATED job succeeds
2. Test validate on already VALIDATED job succeeds (re-validation)
3. Test validate on RUNNING job fails with error
4. Test validation issues are displayed with line numbers
5. Test --check-licenses flag passes to ValidationService
6. Test --strict flag behavior
7. Test JSON output format
8. Test job status updated to VALIDATED on success
9. Test job status remains CREATED on validation failure
10. Mock GraphClient and services for isolated testing

## Subtasks

### 9.1. Implement job loading and state validation for batch validate command

**Status:** pending  
**Dependencies:** None  

Add job loading via JobStore.load_job() and validate that the job is in an allowed state (CREATED or VALIDATED) before proceeding with validation. Handle JobNotFoundError with appropriate error message and exit code 12.

**Details:**

Implement the initial portion of the batch_validate command that: 1) Extracts CLIContext and formatter from typer context using get_context(), 2) Instantiates JobStore and calls load_job(job_id) wrapped in try/except for JobNotFoundError, 3) Validates job.status is in (JobStatus.CREATED, JobStatus.VALIDATED) set - reject with exit code 5 (ValidationError) if job is in RUNNING, COMPLETED, FAILED, or CANCELLED state, 4) Transitions job.status to JobStatus.VALIDATING and saves via job_store.save_job(job). Follow the pattern from numbers.py for formatter.error() calls with remediation text.

### 9.2. Implement async execution setup with GraphClient and ValidationService

**Status:** pending  
**Dependencies:** 9.1  

Set up the async execution context with GraphClient, UserService, NumberService, and ValidationService to run validate_job(). Wire up progress display during validation using formatter.progress().

**Details:**

Implement the async validation execution block: 1) Define inner async function run_validation() that creates ConfigManager, resolves tenant via cli_ctx.tenant or config_manager.get_default_tenant(), creates AuthService(tenant), and uses async with GraphClient(auth_service) as client context, 2) Inside GraphClient context, instantiate UserService(client), NumberService(client), and ValidationService(user_service, number_service), 3) Call await validation_service.validate_job(job, check_licenses=check_licenses), 4) Outside async function, show progress using formatter.progress() context manager with task for job.total_count items, 5) Call asyncio.run(run_validation()) to execute, 6) Update progress.update(task, completed=job.total_count) after completion. Follow _run_bulk_assign_async pattern from numbers.py for service wiring.

### 9.3. Implement validation report display and job status update

**Status:** pending
**Dependencies:** 9.2

Display the validation report with issue details, update job status based on results (VALIDATED if no errors, back to CREATED if errors), and provide next-step guidance to the user.

**Details:**

Implement the report display and status update logic: 1) Update job status: set to JobStatus.VALIDATED if report.invalid_count == 0, else JobStatus.CREATED, then save via job_store.save_job(updated_job), 2) For JSON output mode (cli_ctx.json_output): output dict with job_id, valid boolean, total/valid_count/invalid_count, and issues list using vars(i) for each ValidationIssue, 3) For human output: display summary with formatter.info() for total items, formatter.success() for valid count, formatter.error() for invalid count when > 0, 4) Display issues section limited to first 20 issues showing line number, error_code, error_message, and suggested_fix if present, 5) On validation failure (invalid_count > 0): show fix guidance and raise typer.Exit(code=10), 6) On success: show 'Validation passed!' message and 'Next step: teams-phone batch run {job_id}'. Handle --strict flag by treating warnings as failures.

---

## Implementation Notes

### Session: 2026-02-04 23:55 - Agent: claude-opus-4-5-20251101

**Status:** Implemented (Subtask 9.1)

#### What Was Done
- Added `batch_validate` command to `src/teams_phone/cli/batch.py`
- Added `ValidationError` to imports for state validation errors
- Defined `VALIDATABLE_STATES = {JobStatus.CREATED, JobStatus.VALIDATED}` constant
- Implemented command with `job_id` argument and `--strict`/`-s`, `--check-licenses`/`-l` options
- Job loading via `JobStore.load_job(job_id)` with `NotFoundError` handling (exit code 4)
- State validation rejects VALIDATING, RUNNING, COMPLETED, INTERRUPTED states (exit code 5)
- Transitions job to VALIDATING state and saves via `job_store.save_job(job)`
- Created tests: `tests/unit/test_cli_batch_validate.py` with 20 tests covering:
  - Command help and argument requirements
  - Job loading and NotFoundError handling
  - State validation for all JobStatus values
  - State transition to VALIDATING
  - All command-line options (--strict, -s, --check-licenses, -l)
  - Output display

#### Key Decisions Made
- **Exit code 4 (NotFoundError) for job not found**: Task description mentioned exit code 12 (JobNotFoundError), but JobStore.load_job() raises NotFoundError (exit code 4). Used NotFoundError for consistency with batch status command.
- **Placeholder output for options**: Added temporary output showing strict mode and check-licenses flags so tests can verify option parsing. Subtasks 9.2 and 9.3 will implement actual functionality.
- **Error message format**: Used single quotes around state values in error messages (e.g., "'running' state") for clarity.

#### Patterns Discovered
- **CLI context pattern**: Use `cli_ctx = get_context(ctx)` then `formatter = cli_ctx.get_output_formatter()` - see `batch.py:80-81`
- **Error handling pattern**: Wrap in `try/except TeamsPhoneError`, call `formatter.error(e.message, remediation=e.remediation)`, then `raise typer.Exit(e.exit_code) from None`
- **Test runner result**: Use `result.plain_stdout` (not `result.stdout`) for assertions to avoid ANSI escape code issues

#### Open Items for Next Agent
- [ ] Subtask 9.2: Implement async validation execution with GraphClient and ValidationService
- [ ] Subtask 9.3: Implement validation report display and job status update based on results

#### Gotchas and Warnings
- `JobStore.load_job()` raises `NotFoundError` (exit code 4), NOT `JobNotFoundError` (exit code 12). The task description is misleading.
- Typer returns exit code 2 for missing required arguments (not exit code 1)
- `result.stdout` may be empty when special Unicode characters cause encoding issues; use `result.plain_stdout` for test assertions

---

### Session: 2026-02-04 - Agent: claude-opus-4-5-20251101

**Status:** Implemented (Subtask 9.2)

#### What Was Done
- Added imports for async execution: `asyncio`, `CacheManager`, `GraphClient`, `AuthService`, `ValidationService`, `UserService`, `NumberService`, `ValidationReport`
- Implemented inner `run_validation()` async function inside `batch_validate` command
- Set up service wiring: `CacheManager` → `AuthService` → `GraphClient` → `UserService` + `NumberService` → `ValidationService`
- Called `validation_service.validate_job(job, check_licenses=check_licenses)` to perform validation
- Wrapped async execution with `formatter.progress(job.total_count, "Validating")` context manager
- Used `asyncio.run(run_validation())` to execute async code from sync CLI context
- Updated progress bar to 100% after completion
- Updated existing tests that were checking for old placeholder output
- Added new test class `TestBatchValidateAsyncExecution` with 4 tests:
  - `test_creates_services_with_graph_client` - verifies service chain creation
  - `test_calls_validate_job_with_check_licenses_false` - default check_licenses=False
  - `test_calls_validate_job_with_check_licenses_true` - flag passes through correctly
  - `test_validation_error_from_service_propagates` - errors bubble up correctly
- Updated test `test_displays_validation_results` to mock services and verify output

#### Key Decisions Made
- **Progress bar pattern**: Used `formatter.progress(total, "Validating")` with all-at-once completion update after `asyncio.run()` completes. This matches the task description and keeps progress display simple.
- **Direct service import**: Imported `ValidationService` directly from `teams_phone.services.validation_service` (not from `teams_phone.services`) per recon warning about circular imports.
- **CacheManager and AuthService usage**: AuthService takes `(config_manager, cache_manager)` not just tenant profile - followed pattern from `numbers.py:126-127`.

#### Patterns Discovered
- **Async context manager mocking pattern**: For GraphClient, use `mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)` and `mock_graph.__aexit__ = AsyncMock(return_value=None)`
- **Service call verification**: Use `mock_validation.validate_job.assert_awaited_once_with(job, check_licenses=True/False)` to verify async calls

#### Open Items for Next Agent
- [ ] Subtask 9.3: Implement validation report display and job status update based on results
  - Update job status to VALIDATED or CREATED based on `report.invalid_count`
  - Display validation summary and issues
  - Handle --strict flag behavior
  - Implement JSON output format

#### Gotchas and Warnings
- Tests that were checking for placeholder output (`"Check licenses: True"`) needed to be updated to properly mock the async services since validation now actually runs
- When mocking GraphClient, must mock both `__aenter__` and `__aexit__` as AsyncMock
- The `validated_job` returned from `validate_job()` is the same job object with items mutated in place

---

### Session: 2026-02-04 - Agent: claude-opus-4-5-20251101

**Status:** Implemented (Subtask 9.3)

#### What Was Done
- Replaced placeholder output with full validation report display implementation
- Added `ExitCode` import from `teams_phone.constants` for exit code 10
- Implemented job status update: `VALIDATED` on success, `CREATED` on failure
- Implemented JSON output format with `job_id`, `valid`, `total`, `valid_count`, `invalid_count`, `warning_count`, and `issues` list
- Implemented human output format with:
  - Validation summary (total, valid with green checkmark, invalid with red error)
  - Issues display limited to first 20 with line numbers, error codes, messages, and suggested fixes
  - Warnings display in strict mode (limited to first 10)
  - Success/failure messages with next-step guidance
- Implemented `--strict` flag logic: fails validation if `invalid_count > 0` OR `warnings` exist
- Exit code 10 (`BATCH_VALIDATION_ERROR`) on validation failure
- Created helper functions `_display_validation_issues()` and `_display_validation_report_human()` to reduce complexity
- Added 15 new tests in `TestBatchValidateReportDisplay` class covering:
  - JSON output format validation
  - Issues display with line numbers and error codes
  - Suggested fix display when present
  - First 20 issues limit with "and X more" message
  - Exit code 0 on success, exit code 10 on failure
  - Next-step guidance on success
  - Job status transitions (VALIDATED on success, CREATED on failure)
  - `--strict` mode fails on warnings
  - Fix guidance on validation failure
- Updated existing tests that checked for old placeholder output

#### Key Decisions Made
- **Strict mode behavior**: Implemented to fail on warnings (when warnings list is non-empty) in addition to errors. Since ValidationService doesn't populate warnings yet, this is future-proofing.
- **Issue display limit**: Hardcoded to 20 issues with "... and X more issues" message for readability
- **Warning display limit**: Hardcoded to 10 warnings in strict mode
- **JSON output always exits 0**: JSON mode doesn't raise typer.Exit on failure since the valid=false field indicates failure. This allows pipeline tools to parse JSON regardless of validation result.
- **Refactored for complexity**: Extracted `_display_validation_issues()` and `_display_validation_report_human()` helper functions to pass ruff C901 complexity check (max 10)

#### Patterns Discovered
- **Conditional formatter method**: Can use `valid_display = formatter.success if count > 0 else formatter.info` pattern to select appropriate output method
- **vars() on dataclass**: `vars(issue)` works correctly on dataclasses for JSON serialization
- **Tracking state in tests**: When testing multiple `save_job` calls with same mutable object, use `side_effect` to capture the status value at each call

#### Open Items for Next Agent
- None - parent task 9 is now complete

#### Gotchas and Warnings
- **Same object reference**: The job object is mutated in place, so tests checking multiple `save_job` calls need to track status values at each call time (use `side_effect` with list capture)
- **Exit code in JSON mode**: The implementation doesn't raise `typer.Exit(10)` in JSON mode to keep clean JSON output
- **warnings list currently empty**: ValidationService doesn't populate warnings yet. `--strict` will only fail on warnings when that's implemented
