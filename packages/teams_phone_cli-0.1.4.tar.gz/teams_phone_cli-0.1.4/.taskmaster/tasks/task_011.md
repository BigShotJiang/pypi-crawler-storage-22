# Task ID: 11

**Title:** Implement batch run CLI command

**Status:** pending

**Dependencies:** 9, 10, 22

**Priority:** high

**Description:** Add `teams-phone batch run` command that executes a validated job with progress display, concurrency control, and dry-run support.

**Details:**

Extend `src/teams_phone/cli/batch.py`:

```python
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn, TimeRemainingColumn

from teams_phone.services.batch_executor import BatchExecutor, ExecutionProgress

@batch_app.command("run")
def batch_run(
    ctx: typer.Context,
    job_id: Annotated[
        str,
        typer.Argument(help="Job ID to execute."),
    ],
    concurrency: Annotated[
        int,
        typer.Option(
            "--concurrency", "-c",
            help="Number of concurrent operations (1-10).",
            min=1,
            max=10,
        ),
    ] = 3,
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            help="Simulate execution without making API calls.",
        ),
    ] = False,
) -> None:
    """Execute a batch job.
    
    Runs the validated batch job, assigning phone numbers to users.
    Progress is displayed in real-time and state is saved incrementally.
    
    Use --dry-run to test without making changes to your tenant.
    Use --concurrency to adjust parallel operations (default: 3).
    
    Example:
        teams-phone batch run 20260203-143015-a1b2-migration --concurrency 5
    """
    cli_ctx: CLIContext = ctx.obj
    formatter = cli_ctx.output_formatter
    
    # Load job
    job_store = JobStore()
    try:
        job = job_store.load_job(job_id)
    except JobNotFoundError:
        formatter.error(f"Job not found: {job_id}")
        raise typer.Exit(code=12)
    
    # Verify job in valid state
    if job.status != JobStatus.VALIDATED:
        formatter.error(f"Job must be validated before running (current: {job.status.value})")
        formatter.info(f"Run: teams-phone batch validate {job_id}")
        raise typer.Exit(code=5)
    
    # Check for concurrent execution
    active_job = job_store.get_active_job_id()
    if active_job and active_job != job_id:
        formatter.error(f"Another job is running: {active_job}")
        raise typer.Exit(code=13)
    
    if dry_run:
        formatter.warning("DRY RUN - No changes will be made")
    
    async def run_execution():
        config_manager = cli_ctx.get_config_manager()
        tenant_name = cli_ctx.tenant or config_manager.get_default_tenant()
        tenant = config_manager.get_tenant(tenant_name)
        auth_service = AuthService(tenant)
        
        async with GraphClient(auth_service) as client:
            user_service = UserService(client)
            number_service = NumberService(client)
            
            executor = BatchExecutor(
                user_service=user_service,
                number_service=number_service,
                job_store=job_store,
                concurrency=concurrency,
                dry_run=dry_run,
            )
            
            with job_store.acquire_lock(job_id):
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    BarColumn(),
                    TaskProgressColumn(),
                    TimeRemainingColumn(),
                    disable=cli_ctx.json_output,
                ) as progress:
                    task = progress.add_task(
                        f"Executing {job.name}...",
                        total=job.total_count,
                    )
                    
                    def on_progress(p: ExecutionProgress):
                        progress.update(task, completed=p.completed)
                    
                    return await executor.execute_job(job, on_progress=on_progress)
    
    formatter.info(f"Executing job: {job_id}")
    formatter.info(f"Items: {job.total_count}, Concurrency: {concurrency}")
    
    try:
        result_job = asyncio.run(run_execution())
    except JobLockError as e:
        formatter.error(str(e))
        raise typer.Exit(code=13)
    
    # Display summary report (Appendix D format)
    _display_summary_report(formatter, result_job, cli_ctx.json_output)
    
    if result_job.failed_count > 0:
        raise typer.Exit(code=11)

def _display_summary_report(formatter, job: Job, json_mode: bool) -> None:
    """Display execution summary per Appendix D format."""
    if json_mode:
        formatter.json_output(job.model_dump(mode="json"))
        return
    
    # Rich formatted summary
    formatter.info("=" * 80)
    formatter.info("Batch Execution Summary")
    formatter.info("=" * 80)
    formatter.info(f"Job: {job.name}")
    formatter.info(f"Job ID: {job.id}")
    if job.duration:
        formatter.info(f"Duration: {job.duration}")
    formatter.info(f"Items: {job.total_count} total")
    formatter.info("")
    formatter.info("Results:")
    pct = (job.succeeded_count / job.total_count * 100) if job.total_count else 0
    formatter.success(f"  ✓ {job.succeeded_count} succeeded ({pct:.1f}%)")
    if job.failed_count:
        formatter.error(f"  ✗ {job.failed_count} failed")
    if job.pending_count:
        formatter.info(f"  ⧗ {job.pending_count} pending")
    
    # Show failures by error code
    error_counts = {}
    for item in job.items:
        if item.error_code:
            error_counts[item.error_code] = error_counts.get(item.error_code, 0) + 1
    
    if error_counts:
        formatter.info("\nFailures by Error Code:")
        for code, count in sorted(error_counts.items()):
            formatter.info(f"  • {code} ({count} items)")
    
    formatter.info("\nNext Steps:")
    if job.status == JobStatus.INTERRUPTED:
        formatter.warning(f"  ⚠ Job interrupted - Resume with: teams-phone batch resume {job.id}")
    if job.failed_count > 0:
        formatter.info(f"  1. Review failures: teams-phone batch status {job.id}")
        formatter.info(f"  2. Export failed: teams-phone batch export {job.id} --failed")
        formatter.info(f"  3. Retry failed: teams-phone batch retry {job.id}")
    
    formatter.info("=" * 80)
```

**Test Strategy:**

Unit tests in `tests/unit/test_cli_batch_run.py`:
1. Test run on non-validated job shows error
2. Test run with --dry-run doesn't call assign_number
3. Test --concurrency flag passed to executor
4. Test progress bar updates during execution
5. Test summary report displays correct counts
6. Test exit code 11 when failures occur
7. Test exit code 0 when all succeed
8. Test job lock prevents concurrent execution
9. Test SIGINT interruption handled gracefully
10. Test JSON output mode

## Subtasks

### 11.1. Implement job loading with state validation

**Status:** done
**Dependencies:** None

Load job by ID from JobStore and validate it's in the correct state (VALIDATED) before execution can proceed.

**Details:**

Add the initial job loading logic to the `batch_run` command:

1. Import JobStore and required exceptions (JobNotFoundError, JobLockError) from the batch infrastructure
2. Load the job using `job_store.load_job(job_id)` with proper error handling:
   - Catch `JobNotFoundError` and display error with exit code 12
   - Use `formatter.error()` to show 'Job not found: {job_id}'
3. Validate job status is `JobStatus.VALIDATED`:
   - If not validated, show error with current status
   - Provide remediation hint: 'Run: teams-phone batch validate {job_id}'
   - Exit with code 5 (validation error)
4. Check for concurrent execution using `job_store.get_active_job_id()`:
   - If another job is running (and it's not the current job), show error with the active job ID
   - Exit with code 13 (JobLockError)
5. Handle the `--dry-run` flag by displaying a warning message via `formatter.warning('DRY RUN - No changes will be made')`

This subtask sets up the guard conditions that prevent invalid execution attempts.

### 11.2. Implement lock acquisition and async execution context

**Status:** pending  
**Dependencies:** 11.1  

Set up the job locking mechanism and async execution context with GraphClient, UserService, NumberService, and BatchExecutor initialization.

**Details:**

Implement the async execution context setup within the `batch_run` command:

1. Define the inner `async def run_execution()` coroutine:
   - Get ConfigManager and resolve tenant name (using `cli_ctx.tenant` or default)
   - Create AuthService with tenant configuration
   - Use `async with GraphClient(auth_service) as client:` context manager pattern
   - Initialize UserService and NumberService with the GraphClient
   - Create BatchExecutor instance with:
     - user_service and number_service dependencies
     - job_store reference for state persistence
     - concurrency parameter (from CLI option, 1-10)
     - dry_run flag (from CLI option)

2. Wrap execution in `job_store.acquire_lock(job_id)` context manager:
   - This prevents concurrent execution of the same job
   - Lock is automatically released on exit (normal or exception)

3. Handle lock acquisition failure:
   - Catch `JobLockError` when calling `asyncio.run(run_execution())`
   - Display error message via `formatter.error(str(e))`
   - Exit with code 13

4. Display pre-execution info:
   - 'Executing job: {job_id}'
   - 'Items: {job.total_count}, Concurrency: {concurrency}'

### 11.3. Implement Rich progress bar integration

**Status:** pending  
**Dependencies:** 11.2  

Add real-time progress display using Rich Progress component that updates as BatchExecutor processes items.

**Details:**

Integrate Rich Progress display within the execution context:

1. Import Rich progress components at the top of batch.py:
   ```python
   from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn, TimeRemainingColumn
   ```

2. Create Progress instance with appropriate columns:
   - SpinnerColumn() for activity indicator
   - TextColumn('[progress.description]{task.description}') for job name
   - BarColumn() for visual progress bar
   - TaskProgressColumn() for completed/total count
   - TimeRemainingColumn() for ETA
   - Use `disable=cli_ctx.json_output` to suppress in JSON mode

3. Set up the progress task:
   - Add task with description 'Executing {job.name}...' and total=job.total_count
   - For resumed jobs, initialize completed count to match current progress

4. Implement the on_progress callback:
   - Define `def on_progress(p: ExecutionProgress):` that receives progress updates
   - Update the progress task: `progress.update(task, completed=p.completed)`
   - Pass callback to `executor.execute_job(job, on_progress=on_progress)`

5. Follow existing progress patterns from OutputFormatter.progress() method:
   - Use get_spinner_name() for ASCII-safe spinner on Windows
   - Ensure proper context manager nesting (Progress inside lock)

6. Handle keyboard interrupt (Ctrl+C):
   - Progress bar should clean up gracefully
   - Job state should be saved by BatchExecutor before exit

### 11.4. Implement summary report display (Appendix D format)

**Status:** pending  
**Dependencies:** 11.3  

Add the _display_summary_report function that shows execution results with success/failure counts, error breakdowns, and next-step guidance.

**Details:**

Implement the `_display_summary_report(formatter, job: Job, json_mode: bool)` helper function:

1. Handle JSON mode output:
   - If `json_mode=True`, output `job.model_dump(mode='json')` via `formatter.json_output()`
   - Return early (no Rich formatting)

2. Display the summary header:
   - '=' * 80 separator line
   - 'Batch Execution Summary' title
   - '=' * 80 separator line
   - Job name: `job.name`
   - Job ID: `job.id`
   - Duration: `job.duration` (if available, formatted nicely)
   - Total items: `job.total_count`

3. Display results section:
   - Use `formatter.success()` for succeeded count with percentage
   - Use `formatter.error()` for failed count (if > 0)
   - Use `formatter.info()` for pending count (if > 0)
   - Use ASCII-safe markers (✓ → 'OK:', ✗ → 'FAIL:', ⧗ → '*') for Windows compatibility

4. Display failures by error code:
   - Aggregate error_code counts from `job.items` where `item.error_code` is not None
   - Sort by error code and display as bullet list: '• {code} ({count} items)'

5. Display next steps section:
   - If status is INTERRUPTED: '⚠ Job interrupted - Resume with: teams-phone batch resume {job.id}'
   - If failed_count > 0:
     - '1. Review failures: teams-phone batch status {job.id}'
     - '2. Export failed: teams-phone batch export {job.id} --failed'
     - '3. Retry failed: teams-phone batch retry {job.id}'

6. Exit code handling:
   - After calling _display_summary_report, check `result_job.failed_count > 0`
   - If failures exist, raise `typer.Exit(code=11)` (BatchExecutionError)

---

## Implementation Notes

### Session: 2026-02-05 - Agent: claude-opus-4-6

**Status:** Implemented (Subtask 11.1)

#### What Was Done
- Added `batch_run` command to `src/teams_phone/cli/batch.py` (after `batch_validate` command, ~line 600)
- Implemented all guard conditions: job loading, VALIDATED state check, concurrent execution check, dry-run warning
- Added `JobLockError` import to batch.py
- Command parameters: `job_id` (Argument), `--concurrency/-c` (Option, int, 1-10, default 3), `--dry-run` (Option, bool)
- Placeholder output for execution logic (subtask 11.2 will replace)
- Created `tests/unit/test_cli_batch_run.py` with 22 tests covering all guard conditions

#### Key Decisions Made
- **NotFoundError vs JobNotFoundError**: Followed the `batch validate` pattern -- let `NotFoundError` (exit code 4) from `load_job()` propagate to the generic `TeamsPhoneError` handler. Did NOT catch `JobNotFoundError` (exit code 12) because `load_job()` doesn't raise it. This is consistent with `batch validate` behavior.
- **Concurrent execution check**: Included `get_active_job_id()` pre-check in 11.1 as specified by the task. This is advisory only; actual file-based locking (`acquire_lock()`) belongs in subtask 11.2.
- **JobLockError usage**: Used `JobLockError(active_job_id)` directly rather than manual error formatting. This gives exit code 13 with the active job ID in the error message and remediation hint.
- **State validation pattern**: Used `ValidationError` (exit code 5) for state validation, matching `batch validate` pattern.

#### Patterns Discovered
- `batch run` tests are much simpler than `batch validate` tests because no async services need mocking -- only `JobStore` needs patching for guard conditions
- Typer's `min`/`max` on `Option` handles range validation and returns exit code 2 automatically

#### Open Items for Next Agent
- [x] Subtask 11.2: Replace placeholder output with actual `acquire_lock()` + async execution context
- [ ] Subtask 11.3: Add Rich progress bar integration
- [ ] Subtask 11.4: Add summary report display

#### Gotchas and Warnings
- The task spec's sample code uses `cli_ctx: CLIContext = ctx.obj` and `formatter = cli_ctx.output_formatter` but the real pattern is `cli_ctx = get_context(ctx)` and `formatter = cli_ctx.get_output_formatter()`. Always use the real pattern.
- The task spec references `JobNotFoundError` (exit code 12) but `load_job()` raises `NotFoundError` (exit code 4). Follow the existing pattern.
- `formatter.warning()` is suppressed in JSON mode -- the dry-run warning won't appear in `--json` output

---

## Implementation Notes - Subtask 11.2

### Session: 2026-02-05 - Agent: claude-opus-4-6

**Status:** Implemented

#### What Was Done
- Added `from teams_phone.services.batch_executor import BatchExecutor` import to `batch.py`
- Replaced placeholder output (lines 666-670) with full async execution context:
  - Pre-execution info messages (`formatter.info()`) displayed before `asyncio.run()`
  - Inner `async def run_execution() -> Job` coroutine with service wiring
  - `with job_store.acquire_lock(job_id)` synchronous context manager inside coroutine
  - `JobLockError` caught explicitly from `asyncio.run()` (exit code 13)
- Updated all existing tests that pass guard conditions to use full 7-patch async mock context
- Created `mock_execution_context()` helper to reduce test boilerplate
- Added 8 new tests in `TestBatchRunAsyncExecution` class
- Modified: `src/teams_phone/cli/batch.py`
- Modified: `tests/unit/test_cli_batch_run.py`

#### Key Decisions Made
- **Lock uses CLI `job_id` argument, not `mock_job.id`**: The `acquire_lock(job_id)` call receives the CLI argument string, which may differ from `Job.id`. This is correct because the lock should match what the user provided.
- **Pre-execution info before `asyncio.run()`**: Info messages are displayed synchronously before entering the async execution, matching the `batch validate` pattern.
- **`JobLockError` caught in nested try/except**: A separate `try/except JobLockError` wraps `asyncio.run()`, placed inside the outer `try/except TeamsPhoneError` block. This ensures specific handling with exit code 13 rather than falling through to the generic handler.
- **Test helper as module-level function**: `mock_execution_context()` is a `@contextmanager` function (not a fixture) yielding a dict of mock references, allowing tests to access specific mocks for assertions.

#### Patterns Discovered
- **7-patch pattern for batch run tests**: JobStore, CacheManager, AuthService, GraphClient, UserService, NumberService, BatchExecutor all need mocking for any test that reaches `asyncio.run()`. Guard condition tests (wrong state, concurrent execution) only need JobStore since they exit before reaching async execution.
- **`acquire_lock` context manager mocking**: Must set both `__enter__` and `__exit__` on `mock_store.acquire_lock.return_value` for the `with` statement to work correctly.

#### Open Items for Next Agent
- [ ] Subtask 11.3: Add Rich progress bar -- needs `on_progress` callback passed to `executor.execute_job(job, on_progress=...)`
- [ ] Subtask 11.4: Add summary report -- needs to use `result_job` return value from `asyncio.run(run_execution())`

#### Gotchas and Warnings
- `execute_job()` accepts an `on_progress` callback (keyword-only). For 11.2 it's not passed (defaults to None). 11.3 will need to add it.
- The `result_job` from `asyncio.run(run_execution())` is currently unused (assigned to nothing). 11.4 will need to capture it for the summary report.
- `acquire_lock` is synchronous (`@contextmanager`, not `@asynccontextmanager`), so use `with` not `async with` inside the async coroutine.

---

## Implementation Notes - Subtask 11.3

### Session: 2026-02-05 - Agent: claude-opus-4-6

**Status:** Implemented

#### What Was Done
- Added Rich progress imports to `batch.py`: `BarColumn`, `Progress`, `SpinnerColumn`, `TaskProgressColumn`, `TextColumn`, `TimeRemainingColumn`
- Added `ExecutionProgress` import from `batch_executor` for type annotation in callback
- Modified `run_execution()` coroutine to wrap `executor.execute_job()` in a Rich Progress context manager
- Progress bar uses combined `with` statement (lock + Progress) per ruff SIM117 rule
- Progress bar columns: SpinnerColumn (Windows-safe), TextColumn, BarColumn, TaskProgressColumn, TimeRemainingColumn
- Progress disabled in JSON mode via `disable=cli_ctx.json_output`
- Progress initialized with `completed=job.total_count - job.pending_count` for resumed jobs
- `on_progress` callback calls `progress.update(task, completed=p.completed)`
- Updated existing test assertion for `execute_job` to use `on_progress=ANY`
- Added 5 new tests in `TestBatchRunProgressBar` class
- Modified: `src/teams_phone/cli/batch.py`
- Modified: `tests/unit/test_cli_batch_run.py`

#### Key Decisions Made
- **Custom Progress (not `formatter.progress()`)**: Created a new Progress instance directly instead of using `formatter.progress()` because the batch run command needs `TimeRemainingColumn` which `formatter.progress()` doesn't include.
- **Combined `with` statement**: Used `with (job_store.acquire_lock(...), Progress(...) as progress):` instead of nested `with` to satisfy ruff SIM117 lint rule.
- **Resume support**: Initialized `completed=job.total_count - job.pending_count` on `add_task()` so resumed jobs show accurate initial progress rather than starting from 0.
- **Mocking Progress in tests**: For tests that assert on Progress constructor args (JSON disable, total count), patched `teams_phone.cli.batch.Progress` directly rather than trying to capture real Progress output.

#### Patterns Discovered
- **`--json` flag position**: The `--json` flag is a global option on the root app, must come BEFORE the subcommand in test invocations: `["--json", "batch", "run", ...]` not `["batch", "run", ..., "--json"]`.
- **Progress mock setup**: Must set `__enter__`, `__exit__`, and `add_task.return_value = 0` on the mock Progress for the `with` statement and `progress.update()` to work.

#### Open Items for Next Agent
- [ ] Subtask 11.4: Add summary report -- needs to capture `result_job` return value from `asyncio.run(run_execution())`

#### Gotchas and Warnings
- The `--json` flag must precede subcommands in CLI invocations (it's a global option on the root Typer app). Tests that put it after the subcommand will get exit code 2.
- `TimeRemainingColumn` is NOT in the existing `output_formatter.py` imports -- it's a new import specific to `batch.py`.
- The `ExecutionProgress` import is used only for the type annotation on the `on_progress` callback parameter.

---

## Implementation Notes - Subtask 11.4

### Session: 2026-02-05 - Agent: claude-opus-4-6

**Status:** Implemented

#### What Was Done
- Added `from datetime import timedelta` import to `batch.py`
- Added `_format_duration(delta: timedelta) -> str` helper function that converts timedelta to human-readable format ("2m 15s", "1h 2m 3s", "45s")
- Added `_display_summary_error_codes(formatter, job)` helper to display error code breakdown
- Added `_display_summary_next_steps(formatter, job)` helper to display next steps guidance
- Added `_display_summary_report(formatter, job, json_mode)` main function implementing Appendix D format
- Changed `asyncio.run(run_execution())` to `result_job = asyncio.run(run_execution())` to capture return value
- Added `_display_summary_report(formatter, result_job, cli_ctx.json_output)` call after execution
- Added `if result_job.failed_count > 0: raise typer.Exit(code=ExitCode.BATCH_EXECUTION_ERROR)` for exit code 11
- Added `make_completed_job()` factory helper to test file for creating completed jobs with specific outcomes
- Added `TestBatchRunSummaryReport` class with 20 tests covering all acceptance criteria
- Modified: `src/teams_phone/cli/batch.py`
- Modified: `tests/unit/test_cli_batch_run.py`

#### Key Decisions Made
- **Split `_display_summary_report` into 3 functions**: Extracted `_display_summary_error_codes()` and `_display_summary_next_steps()` to keep cyclomatic complexity under ruff's C901 limit of 10.
- **Used `formatter.success()` and `formatter.error()` for result lines**: These methods handle ASCII-safe markers automatically ("OK:" on Windows, checkmark on Unicode terminals). This avoids accessing `formatter._use_ascii` private attribute directly.
- **`formatter.json()` not `formatter.json_output()`**: The task spec incorrectly referenced `formatter.json_output()` which doesn't exist. Used `formatter.json()` per the actual OutputFormatter API.
- **Duration formatting with hours support**: `_format_duration()` handles hours, minutes, seconds with smart omission (no "0m" between hours and seconds, shows "0s" for zero duration).
- **Next steps section only shown when relevant**: The "Next Steps:" header is only displayed when `job.status == INTERRUPTED` or `failed_count > 0`, keeping the output clean for fully successful jobs.
- **No execution log line**: Appendix D shows an "Execution log:" line but this was not in the acceptance criteria and the `execution.log` feature doesn't exist yet, so omitted.

#### Patterns Discovered
- **`make_completed_job()` factory pattern**: Separate factory from `make_job()` because completed jobs need specific item statuses (SUCCEEDED, FAILED with error codes, PENDING), timestamps for duration, and different default status.
- **`mock_execution_context` override pattern**: For summary tests, create input job with `make_job()` and result job with `make_completed_job()`, then override `mocks["executor"].execute_job.return_value = result_job`.
- **JSON mode test pattern**: Use `["--json", "batch", "run", ...]` and parse `result.plain_stdout` with `json.loads()` to validate JSON output structure.

#### Open Items for Next Agent
- This is the final subtask for task 11. Parent task 11 can be marked as done.

#### Gotchas and Warnings
- The `model_dump(mode="json")` serialization converts `timedelta` to total seconds (float), not the human-readable format. This is correct for JSON mode since consumers will format it themselves.
- All existing tests still pass because the default `mock_job` (from `make_job()`) has all PENDING items and `failed_count == 0`, so no exit code 11 is raised.
- `formatter.error()` prepends "Error:" to the message. The summary shows "Error: N failed" which is slightly different from Appendix D's "cross N failed" format, but consistent with the codebase's existing patterns.
