# Task ID: 12

**Title:** Implement batch resume CLI command

**Status:** pending

**Dependencies:** 10, 11, 22, 23

**Priority:** medium

**Description:** Add `teams-phone batch resume` command that continues an interrupted job from its saved state.

**Details:**

Extend `src/teams_phone/cli/batch.py`:

```python
@batch_app.command("resume")
def batch_resume(
    ctx: typer.Context,
    job_id: Annotated[
        str,
        typer.Argument(help="Job ID to resume."),
    ],
    concurrency: Annotated[
        int,
        typer.Option(
            "--concurrency", "-c",
            help="Number of concurrent operations (1-10).",
            min=1,
            max=10,
        ),
    ] = 3,
) -> None:
    """Resume an interrupted batch job.
    
    Continues execution from where the job was interrupted. Items that
    were IN_PROGRESS are treated as PENDING (safe due to idempotency).
    Already succeeded items are skipped.
    
    Example:
        teams-phone batch resume 20260203-143015-a1b2-migration
    """
    cli_ctx: CLIContext = ctx.obj
    formatter = cli_ctx.output_formatter
    
    # Load job
    job_store = JobStore()
    try:
        job = job_store.load_job(job_id)
    except JobNotFoundError:
        formatter.error(f"Job not found: {job_id}")
        raise typer.Exit(code=12)
    
    # Verify job can be resumed
    if job.status != JobStatus.INTERRUPTED:
        formatter.error(f"Job is not interrupted (current: {job.status.value})")
        if job.status == JobStatus.COMPLETED:
            formatter.info(f"Use 'batch retry' to re-process failed items.")
        raise typer.Exit(code=5)
    
    # Reset IN_PROGRESS items to PENDING (safe due to idempotency)
    in_progress_count = 0
    for item in job.items:
        if item.status == ItemStatus.IN_PROGRESS:
            item.status = ItemStatus.PENDING
            in_progress_count += 1
    
    if in_progress_count > 0:
        formatter.info(f"Reset {in_progress_count} in-progress items to pending")
    
    # Display resume info
    completed = sum(1 for i in job.items if i.status == ItemStatus.SUCCEEDED)
    pending = sum(1 for i in job.items if i.status == ItemStatus.PENDING)
    formatter.info(f"Resuming job: {completed}/{job.total_count} items completed")
    formatter.info(f"Remaining: {pending} items")
    
    # Reuse execution logic from batch_run
    async def run_resume():
        # Same as batch_run execution logic
        pass
    
    try:
        result_job = asyncio.run(run_resume())
    except JobLockError as e:
        formatter.error(str(e))
        raise typer.Exit(code=13)
    
    _display_summary_report(formatter, result_job, cli_ctx.json_output)
    
    if result_job.failed_count > 0:
        raise typer.Exit(code=11)
```

Note: The actual execution logic can be extracted to a shared helper used by both `run` and `resume` commands.

**Test Strategy:**

Unit tests in `tests/unit/test_cli_batch_resume.py`:
1. Test resume on INTERRUPTED job succeeds
2. Test resume on COMPLETED job shows error with hint to use retry
3. Test resume on RUNNING job shows error
4. Test IN_PROGRESS items reset to PENDING
5. Test only PENDING items are processed
6. Test SUCCEEDED items are skipped
7. Test progress display shows "Resuming: X/Y completed"
8. Test summary report after resume completes

---

## Implementation Notes

### Session: 2026-02-05 - Agent: claude-opus-4-6

**Status:** Implemented

#### What Was Done
- Added `batch_resume` command to `src/teams_phone/cli/batch.py` (after `batch_run`, before `batch_export`)
- Extracted `_validate_resume_state()` and `_reset_in_progress_items()` helper functions to satisfy C901 complexity limit
- Created comprehensive test file `tests/unit/test_cli_batch_resume.py` with 41 tests across 10 test classes
- All quality gates pass: 95 tests (41 resume + 54 run), mypy clean, ruff clean, ruff format clean

#### Key Decisions Made
- **Extracted helpers instead of shared run/resume function**: The task spec suggested extracting shared execution logic between `run` and `resume`. Instead, I extracted `_validate_resume_state()` and `_reset_in_progress_items()` to reduce complexity (C901) while keeping the async execution logic inline in each command. This avoids over-abstraction since the two commands have different guard conditions, different pre-execution steps, and different BatchExecutor kwargs (run has `dry_run`, resume does not).
- **Save after IN_PROGRESS reset**: Added `job_store.save_job(job)` after resetting IN_PROGRESS items to PENDING. This persists the reset to disk before execution begins, closing the small crash window noted in the recon report.
- **No --dry-run flag**: Intentionally omitted per task spec — resume is for continuing real work. A test verifies `--dry-run` is rejected (exit code 2).
- **Followed real patterns, not task spec code**: The task spec code used `ctx.obj`, `cli_ctx.output_formatter`, `JobNotFoundError`, etc. — all incorrect. Used the real patterns from `batch_run`: `get_context(ctx)`, `cli_ctx.get_output_formatter()`, `NotFoundError`, `ValidationError` with remediation, etc.

#### Patterns Discovered
- `_validate_resume_state()` at `batch.py:838-854`: Reusable pattern for state-gated commands with status-specific remediation hints
- `_reset_in_progress_items()` at `batch.py:857-877`: Item status reset with conditional save and user feedback
- `mock_execution_context()` in test file mirrors `test_cli_batch_run.py` pattern — future commands (retry) should copy this

#### Open Items for Next Agent
- [ ] Task 13 (batch retry) can reuse the same `mock_execution_context()` test helper pattern
- [ ] Consider extracting shared async execution into a helper if a third command (retry) needs it — but not before then

#### Gotchas and Warnings
- `batch_run` has `dry_run=dry_run` in BatchExecutor kwargs; `batch_resume` intentionally omits it — don't copy blindly
- The `make_interrupted_job()` factory in the test file supports `in_progress` parameter for testing IN_PROGRESS reset; `make_job()` defaults to `INTERRUPTED` status (unlike `batch_run` tests which default to `VALIDATED`)
- `pending_count` is a computed property that counts items with `ItemStatus.PENDING` — after resetting IN_PROGRESS items, the count updates automatically

---
