# Task ID: 13

**Title:** Implement batch retry CLI command

**Status:** pending

**Dependencies:** 10, 11, 22, 23

**Priority:** medium

**Description:** Add `teams-phone batch retry` command that re-processes only failed items from a completed job.

**Details:**

Extend `src/teams_phone/cli/batch.py`:

```python
@batch_app.command("retry")
def batch_retry(
    ctx: typer.Context,
    job_id: Annotated[
        str,
        typer.Argument(help="Job ID to retry failed items."),
    ],
    concurrency: Annotated[
        int,
        typer.Option(
            "--concurrency", "-c",
            help="Number of concurrent operations (1-10).",
            min=1,
            max=10,
        ),
    ] = 3,
) -> None:
    """Retry only failed items from a completed batch job.
    
    Re-processes items that previously failed. Items that succeeded
    are skipped. Items marked as 'needs_review' (3+ failures) are
    also retried unless manually excluded.
    
    Example:
        teams-phone batch retry 20260203-143015-a1b2-migration
    """
    cli_ctx: CLIContext = ctx.obj
    formatter = cli_ctx.output_formatter
    
    # Load job
    job_store = JobStore()
    try:
        job = job_store.load_job(job_id)
    except JobNotFoundError:
        formatter.error(f"Job not found: {job_id}")
        raise typer.Exit(code=12)
    
    # Verify job can be retried
    if job.status not in (JobStatus.COMPLETED, JobStatus.INTERRUPTED):
        formatter.error(f"Job cannot be retried (current: {job.status.value})")
        formatter.info("Job must be completed or interrupted to retry.")
        raise typer.Exit(code=5)
    
    # Count retryable items
    retryable_statuses = (ItemStatus.FAILED, ItemStatus.NEEDS_REVIEW)
    retryable_items = [i for i in job.items if i.status in retryable_statuses]
    
    if not retryable_items:
        formatter.success("No failed items to retry - job is complete!")
        return
    
    # Reset failed items to pending for retry
    for item in retryable_items:
        item.status = ItemStatus.PENDING
        item.error_code = None
        item.error_message = None
        # Keep attempts count to track total retries
    
    job_store.save_job(job)
    
    formatter.info(f"Retrying {len(retryable_items)} failed items")
    
    # Show items needing review (3+ failures)
    needs_review = [i for i in job.items if i.attempts >= 3]
    if needs_review:
        formatter.warning(f"  {len(needs_review)} items have failed 3+ times")
    
    # Execute retry (same logic as run)
    async def run_retry():
        # Same execution setup as batch_run
        pass
    
    try:
        result_job = asyncio.run(run_retry())
    except JobLockError as e:
        formatter.error(str(e))
        raise typer.Exit(code=13)
    
    _display_summary_report(formatter, result_job, cli_ctx.json_output)
    
    if result_job.failed_count > 0:
        raise typer.Exit(code=11)
```

**Test Strategy:**

Unit tests in `tests/unit/test_cli_batch_retry.py`:
1. Test retry on COMPLETED job succeeds
2. Test retry on INTERRUPTED job succeeds
3. Test retry on RUNNING job shows error
4. Test only FAILED items are re-processed
5. Test SUCCEEDED items are not touched
6. Test NEEDS_REVIEW items are included in retry
7. Test attempts counter preserved and incremented
8. Test no failed items shows success message
9. Test warning shown for items with 3+ failures

---

## Implementation Notes

### Session: 2026-02-05 - Agent: claude-opus-4-6

**Status:** Implemented

#### What Was Done
- Added `_validate_retry_state()` helper to validate COMPLETED/INTERRUPTED state
- Added `_reset_failed_items()` helper to reset FAILED/NEEDS_REVIEW items to PENDING, clear error fields, and warn about 3+ attempt items
- Added `batch_retry` command to `src/teams_phone/cli/batch.py` with full async execution context (same pattern as `batch_resume`)
- Created `tests/unit/test_cli_batch_retry.py` with 46 unit tests across 12 test classes

#### Key Decisions Made
- **Helper extraction**: Extracted `_validate_retry_state()` and `_reset_failed_items()` as module-level helpers (like `_validate_resume_state()` and `_reset_in_progress_items()`) to keep `batch_retry` under C901 complexity limit
- **Warning timing**: High-attempt warnings (3+ failures) are calculated and shown BEFORE items are reset to PENDING, since the attempts count is preserved but status changes
- **Return value from `_reset_failed_items()`**: Returns count of reset items so the command can early-exit when count is 0
- **State validation**: Followed task spec allowing both COMPLETED and INTERRUPTED (not just COMPLETED as PRD suggests)
- **No `--dry-run`**: Deliberately omitted per task spec (matches `batch_resume` behavior)
- **Used `NotFoundError`**: Followed the established `batch_run`/`batch_resume` pattern (letting `NotFoundError` propagate to generic `TeamsPhoneError` handler) instead of the task spec's incorrect `JobNotFoundError`
- **Used `get_context(ctx)`**: Followed established pattern instead of task spec's `ctx.obj`

#### Patterns Discovered
- `_reset_failed_items()` returns an `int` count (unlike `_reset_in_progress_items()` which returns `None`). This enables the early-exit logic cleanly.
- `make_completed_job()` factory extended with `needs_review` and `attempts_override` parameters for retry-specific test scenarios.

#### Open Items for Next Agent
- [ ] None - task is complete

#### Gotchas and Warnings
- The task spec code sample used incorrect patterns (`ctx.obj`, `JobNotFoundError`, `cli_ctx.output_formatter`). All were corrected to match established codebase patterns per recon report.
- `--json` flag must precede subcommands in test invocations: `["--json", "batch", "retry", ...]`
