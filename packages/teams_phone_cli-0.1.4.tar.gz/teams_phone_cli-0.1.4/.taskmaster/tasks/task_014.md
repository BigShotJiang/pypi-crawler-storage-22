# Task ID: 14

**Title:** Implement batch export CLI command

**Status:** pending

**Dependencies:** 7, 22, 23

**Priority:** medium

**Description:** Add `teams-phone batch export` command that exports job results to CSV with filters for failed, succeeded, or all items.

**Details:**

Extend `src/teams_phone/cli/batch.py`:

```python
import csv

@batch_app.command("export")
def batch_export(
    ctx: typer.Context,
    job_id: Annotated[
        str,
        typer.Argument(help="Job ID to export."),
    ],
    failed: Annotated[
        bool,
        typer.Option(
            "--failed",
            help="Export only failed items.",
        ),
    ] = False,
    succeeded: Annotated[
        bool,
        typer.Option(
            "--succeeded",
            help="Export only succeeded items.",
        ),
    ] = False,
    all_items: Annotated[
        bool,
        typer.Option(
            "--all",
            help="Export all items.",
        ),
    ] = False,
    output: Annotated[
        Path | None,
        typer.Option(
            "--output", "-o",
            help="Output file path. Defaults to <job-name>-<filter>.csv",
        ),
    ] = None,
) -> None:
    """Export batch job results to CSV.
    
    Exports items from a job to a CSV file. Failed items include
    additional error columns (error_code, error_message, attempts).
    
    Examples:
        teams-phone batch export <job-id> --failed
        teams-phone batch export <job-id> --succeeded -o results.csv
        teams-phone batch export <job-id> --all
    """
    cli_ctx: CLIContext = ctx.obj
    formatter = cli_ctx.output_formatter
    
    # Validate filter options (exactly one required)
    filter_count = sum([failed, succeeded, all_items])
    if filter_count != 1:
        formatter.error("Specify exactly one filter: --failed, --succeeded, or --all")
        raise typer.Exit(code=5)
    
    # Load job
    job_store = JobStore()
    try:
        job = job_store.load_job(job_id)
    except JobNotFoundError:
        formatter.error(f"Job not found: {job_id}")
        raise typer.Exit(code=12)
    
    # Filter items
    if failed:
        filter_name = "failed"
        items = [i for i in job.items if i.status in (ItemStatus.FAILED, ItemStatus.NEEDS_REVIEW)]
    elif succeeded:
        filter_name = "succeeded"
        items = [i for i in job.items if i.status == ItemStatus.SUCCEEDED]
    else:  # all_items
        filter_name = "all"
        items = job.items
    
    if not items:
        formatter.info(f"No {filter_name} items to export.")
        return
    
    # Determine output path
    if output is None:
        slug = re.sub(r'[^a-z0-9]+', '-', job.name.lower()).strip('-')
        output = Path(f"{slug}-{filter_name}.csv")
    
    # Write CSV
    fieldnames = ["user_upn", "phone_number"]
    if failed or all_items:
        fieldnames.extend(["status", "error_code", "error_message", "attempts"])
    
    with output.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        
        for item in items:
            row = {
                "user_upn": item.user_upn,
                "phone_number": item.phone_number,
            }
            if failed or all_items:
                row.update({
                    "status": item.status.value,
                    "error_code": item.error_code or "",
                    "error_message": item.error_message or "",
                    "attempts": item.attempts,
                })
            writer.writerow(row)
    
    formatter.success(f"Exported {len(items)} items to {output}")
```

**Test Strategy:**

Unit tests in `tests/unit/test_cli_batch_export.py`:
1. Test --failed exports only FAILED and NEEDS_REVIEW items
2. Test --succeeded exports only SUCCEEDED items
3. Test --all exports all items
4. Test no filter shows error
5. Test multiple filters shows error
6. Test --output sets custom path
7. Test default filename uses job-name-filter.csv format
8. Test failed export includes error columns
9. Test succeeded export has only basic columns
10. Test empty result shows appropriate message

---

## Implementation Notes

### Session: 2026-02-05 — Agent: claude-opus-4-6

**Status:** Implemented

#### What Was Done
- Added `batch_export` command to `src/teams_phone/cli/batch.py`
- Added `import csv` and `import re` to batch.py imports
- Added `JobItem` to TYPE_CHECKING imports (used in helper function type annotations)
- Extracted `_filter_items()` helper for item filtering by status
- Extracted `_write_export_csv()` helper for CSV file writing
- Added `EXPORTABLE_STATES` constant (VALIDATED, COMPLETED, INTERRUPTED) per PRD US-005
- Created `tests/unit/test_cli_batch_export.py` with 19 unit tests

#### Key Decisions Made
- **State restriction added**: PRD says export is only allowed in VALIDATED, COMPLETED, or INTERRUPTED states. The task spec did not mention this, but the PRD requirement (US-005) was followed for consistency.
- **TeamsPhoneError catch pattern**: Used generic `TeamsPhoneError` catch (existing pattern) instead of task spec's `JobNotFoundError` — `JobStore.load_job()` raises `NotFoundError` (exit code 4), not `JobNotFoundError`.
- **Helper extraction**: Split into `_filter_items()` and `_write_export_csv()` to keep `batch_export` cyclomatic complexity under C901 limit of 10.
- **Error columns for --all**: Followed task spec — `--all` includes error columns (status, error_code, error_message, attempts).
- **Filter validation**: Used `ValidationError` (exit code 5) for invalid filter combinations, consistent with existing validation pattern.

#### Patterns Discovered
- `from __future__ import annotations` in batch.py means TYPE_CHECKING imports are safe for all annotations — `JobItem` added to TYPE_CHECKING block rather than runtime imports.
- Test pattern: `_write_export_csv` can be mocked to test default filename generation without file I/O.

#### Open Items for Next Agent
- None — task fully implemented.

#### Gotchas and Warnings
- `--all` is a Typer option mapped to `all_items` parameter (avoiding shadowing Python builtin `all`).
- Empty error_code/error_message are written as empty strings (not None) in CSV output.
