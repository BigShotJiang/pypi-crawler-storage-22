# Task ID: 15

**Title:** Implement batch delete CLI command

**Status:** pending

**Dependencies:** 7, 22, 23

**Priority:** low

**Description:** Add `teams-phone batch delete` command that removes a job and its associated files from the jobs directory.

**Details:**

Extend `src/teams_phone/cli/batch.py`:

```python
@batch_app.command("delete")
def batch_delete(
    ctx: typer.Context,
    job_id: Annotated[
        str,
        typer.Argument(help="Job ID to delete."),
    ],
    force: Annotated[
        bool,
        typer.Option(
            "--force", "-f",
            help="Skip confirmation prompt.",
        ),
    ] = False,
) -> None:
    """Delete a batch job and its files.
    
    Removes the job directory including job state, input CSV copy,
    and execution logs. This action cannot be undone.
    
    Example:
        teams-phone batch delete 20260203-143015-a1b2-migration --force
    """
    cli_ctx: CLIContext = ctx.obj
    formatter = cli_ctx.output_formatter
    
    # Load job to verify it exists
    job_store = JobStore()
    try:
        job = job_store.load_job(job_id)
    except JobNotFoundError:
        formatter.error(f"Job not found: {job_id}")
        raise typer.Exit(code=12)
    
    # Check if job is currently running
    if job.status == JobStatus.RUNNING:
        formatter.error("Cannot delete a running job")
        formatter.info("Wait for completion or interrupt with Ctrl+C first.")
        raise typer.Exit(code=5)
    
    # Confirmation prompt
    if not force:
        formatter.warning(f"This will permanently delete job: {job.id}")
        formatter.info(f"  Name: {job.name}")
        formatter.info(f"  Items: {job.total_count}")
        formatter.info(f"  Succeeded: {job.succeeded_count}")
        formatter.info(f"  Failed: {job.failed_count}")
        
        confirm = typer.confirm("Are you sure you want to delete this job?")
        if not confirm:
            formatter.info("Cancelled.")
            raise typer.Exit(code=0)
    
    # Delete job
    job_store.delete_job(job_id)
    formatter.success(f"Deleted job: {job_id}")
```

Implement `delete_job` in JobStore:

```python
def delete_job(self, job_id: str) -> None:
    """Delete a job directory recursively."""
    import shutil
    
    job_dir = self._job_dir(job_id)
    if not job_dir.exists():
        raise JobNotFoundError(job_id)
    
    shutil.rmtree(job_dir)
```

**Test Strategy:**

Unit tests in `tests/unit/test_cli_batch_delete.py`:
1. Test delete with --force skips confirmation
2. Test delete without --force prompts for confirmation
3. Test delete removes job directory
4. Test delete on non-existent job shows error
5. Test delete on RUNNING job shows error
6. Test confirmation 'n' cancels deletion
7. Test job directory completely removed after delete

---

## Implementation Notes

### Session: 2026-02-05 - Agent: claude-opus-4-6

**Status:** Implemented

#### What Was Done
- Added `batch_delete` command to `src/teams_phone/cli/batch.py` (appended after `batch_export`)
- Created `tests/unit/test_cli_batch_delete.py` with 15 tests across 5 test classes
- Command supports `--force`/`-f` flag to skip confirmation prompt
- RUNNING jobs are rejected with ValidationError (exit code 5)
- Non-existent jobs produce NotFoundError (exit code 4) via `job_store.load_job()`
- JSON output mode supported via `--json` global flag
- Confirmation prompt shows job name, total items, succeeded count, and failed count

#### Key Decisions Made
- **NotFoundError over JobNotFoundError**: Task spec referenced `JobNotFoundError` (exit code 12) but the actual codebase uses `NotFoundError` (exit code 4) from `load_job()`. Followed the codebase pattern.
- **ValidationError for RUNNING guard**: Used `ValidationError` (exit code 5) with remediation hint, consistent with other batch commands' state validation patterns.
- **Confirmation prompt format**: Used `typer.confirm()` with a single-line prompt including job stats (name, items, succeeded, failed) rather than the multi-line format in the task spec. This follows the existing `tenants remove` pattern more closely.
- **No JSON output for cancellation**: Cancellation always outputs text "Deletion cancelled" even in JSON mode, matching `tenants remove` behavior.
- **JobStore.delete_job() already existed**: No service-layer changes needed; `delete_job()` was already implemented at job_store.py:620-640.

#### Patterns Discovered
- `typer.confirm()` returns bool, doesn't raise — check return value and `raise typer.Exit(0)` on cancel
- Test confirmation with `input="y\n"` / `input="n\n"` on `runner.invoke()`
- Use `result.plain_stdout` for reliable assertion matching (strips ANSI)

#### Open Items for Next Agent
- None — task is fully complete

#### Gotchas and Warnings
- The task spec code sample uses `cli_ctx: CLIContext = ctx.obj` and `cli_ctx.output_formatter` — the actual codebase uses `get_context(ctx)` and `cli_ctx.get_output_formatter()`. Always follow codebase patterns.
- The task spec references `JobNotFoundError` which doesn't exist in the codebase's exception hierarchy. Use `NotFoundError`.

---
