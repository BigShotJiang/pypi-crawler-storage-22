# Task ID: 16

**Title:** Add execution log persistence

**Status:** pending

**Dependencies:** 10, 22

**Priority:** medium

**Description:** Enhance BatchExecutor to write detailed execution logs with timestamps, item IDs, and API responses to execution.log file.

**Details:**

Enhance `batch_executor.py` with proper logging:

```python
import json
from datetime import datetime, timezone

class ExecutionLogger:
    """Writes execution events to execution.log in job directory."""
    
    def __init__(self, log_path: Path):
        self.log_path = log_path
        # Ensure file exists
        self.log_path.touch()
    
    def log_event(self, event_type: str, data: dict) -> None:
        """Append a timestamped event to the log."""
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "event": event_type,
            **data
        }
        with self.log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    
    def log_start(self, job_id: str, total_items: int, concurrency: int) -> None:
        self.log_event("execution_start", {
            "job_id": job_id,
            "total_items": total_items,
            "concurrency": concurrency,
        })
    
    def log_item_start(self, item: JobItem) -> None:
        self.log_event("item_start", {
            "line_number": item.line_number,
            "user_upn": item.user_upn,
            "phone_number": item.phone_number,
            "attempt": item.attempts,
        })
    
    def log_item_complete(
        self,
        item: JobItem,
        duration_ms: int,
        api_response: dict | None = None,
    ) -> None:
        self.log_event("item_complete", {
            "line_number": item.line_number,
            "user_upn": item.user_upn,
            "status": item.status.value,
            "error_code": item.error_code,
            "error_message": item.error_message,
            "duration_ms": duration_ms,
            "api_response": api_response,
        })
    
    def log_end(self, job: Job, interrupted: bool = False) -> None:
        self.log_event("execution_end", {
            "job_id": job.id,
            "status": "interrupted" if interrupted else job.status.value,
            "succeeded_count": job.succeeded_count,
            "failed_count": job.failed_count,
            "duration_seconds": job.duration.total_seconds() if job.duration else None,
        })
```

Integrate into BatchExecutor._assign_number to log API responses and timing.

**Test Strategy:**

Unit tests in `tests/unit/test_execution_logger.py`:
1. Test log_start writes correct JSON format
2. Test log_item_start includes all item fields
3. Test log_item_complete includes duration and status
4. Test log_end includes final counts
5. Test multiple events append to same file
6. Test log file is JSON Lines format (one object per line)
7. Test timestamps are ISO format UTC

---

## Implementation Notes

### Session: 2026-02-05 — Agent: claude-opus-4-6

**Status:** Implemented

#### What Was Done
- Created `ExecutionLogger` class in `src/teams_phone/services/batch_executor.py` (lines 31-168)
- Methods: `__init__`, `_write_event`, `log_start`, `log_item_start`, `log_item_complete`, `log_end`
- Integrated `ExecutionLogger` into `BatchExecutor._process_item()` and `execute_job()`:
  - Replaced pipe-delimited `_log_item_entry()` static method with JSON Lines logging
  - Replaced inline JOB_START/JOB_COMPLETED pipe-delimited writes with structured events
  - Added per-item `item_start` event before processing
  - Added per-item `item_complete` event with `duration_ms` timing via `time.monotonic()`
  - Added `execution_start` event at job begin with job_id, total_items, concurrency
  - Added `execution_end` event at job end with status, succeeded/failed counts, total_duration_ms
- Removed old `_log_item_entry()` static method
- Created `tests/unit/test_execution_logger.py` with 14 unit tests covering:
  - Init (file creation, no truncation of existing content)
  - _write_event (valid JSON, UTC timestamp, append, empty data)
  - log_start, log_item_start, log_item_complete, log_end
  - Full workflow end-to-end test
- Updated 8 existing tests in `TestBatchExecutorProgressAndLogging` to verify JSON Lines format

#### Key Decisions Made
- **Class placement**: Kept `ExecutionLogger` in `batch_executor.py` (co-located with `BatchExecutor`) since they are tightly coupled. Test file is separate per task spec.
- **Method signatures**: Used explicit parameters instead of passing `JobItem`/`Job` objects directly. This makes the logger independent of model changes and easier to test.
- **Optional fields**: `error_code`, `error_message`, and `api_response` are omitted from JSON output when `None` (cleaner log entries for successful items).
- **`api_response` parameter**: Included in `log_item_complete()` signature but passed as `None` since current service methods don't expose raw responses. Ready for future population.
- **Duration timing**: Used `time.monotonic()` for per-item and total job duration, converted to milliseconds as integers.

#### Patterns Discovered
- Circular import avoidance: Tests importing from `teams_phone.services.batch_executor` must first import `from teams_phone.infrastructure import GraphClient  # noqa: F401` (see `test_execution_logger.py:10`)

#### Open Items for Next Agent
- [ ] `api_response` field in `log_item_complete()` is always `None` currently. Future tasks can populate it if service methods expose raw API responses.

#### Gotchas and Warnings
- Existing log files from previous pipe-delimited runs will have mixed formats if a job is resumed. Each line is independent so this is safe — JSON Lines entries parse independently.
- The `_write_event` method is not async. Since asyncio is single-threaded, concurrent log writes are serialized naturally. No file locking needed.

---
