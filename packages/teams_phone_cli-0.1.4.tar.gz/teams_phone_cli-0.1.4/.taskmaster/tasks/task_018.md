# Task ID: 18

**Title:** Add --check-licenses flag implementation

**Status:** pending

**Dependencies:** 8, 22, 24

**Priority:** low

**Description:** Implement the optional license validation in ValidationService that checks if users have Teams Phone license via Graph API.

**Details:**

Enhance ValidationService to support license checks:

```python
class ValidationService:
    async def _check_user_license(self, user_id: str) -> bool:
        """Check if user has Teams Phone license.
        
        Queries /users/{id}/licenseDetails and checks for:
        - Microsoft 365 Phone System (MCOEV)
        - Microsoft Teams Phone Standard (MCOEV_VIRTUALUSER for resource accounts)
        - Or other qualifying SKUs
        """
        # Use the UserConfiguration model which has is_enterprise_voice_enabled
        try:
            user = await self.user_service.get_user(user_id)
            return user.is_enterprise_voice_enabled
        except NotFoundError:
            return False
    
    async def validate_job(
        self,
        job: Job,
        *,
        check_licenses: bool = False,
    ) -> tuple[Job, ValidationReport]:
        # ... existing validation ...
        
        if check_licenses:
            for item in job.items:
                if item.status == ItemStatus.FAILED:
                    continue  # Already failed, skip
                
                # User was already resolved above
                if not await self._check_user_license(user_id):
                    issues.append(ValidationIssue(
                        line_number=item.line_number,
                        field="user_upn",
                        value=item.user_upn,
                        error_code="BATCH_004",
                        error_message="User lacks Teams Phone license",
                        suggested_fix="Assign Teams Phone license in Microsoft 365 admin center."
                    ))
                    item.status = ItemStatus.FAILED
                    item.error_code = "BATCH_004"
                    item.error_message = "User not licensed for Teams Phone"
```

Note: The UserService already fetches user configuration which includes `is_enterprise_voice_enabled` field, so we can leverage existing data without additional API calls when the user is resolved.

**Test Strategy:**

Unit tests in `tests/unit/test_validation_service_licenses.py`:
1. Test license check disabled by default (check_licenses=False)
2. Test license check enabled adds validation for unlicensed users
3. Test licensed user passes validation
4. Test unlicensed user fails with BATCH_004
5. Test is_enterprise_voice_enabled from UserConfiguration used
6. Test license check skipped for already failed items

---

## Implementation Notes

### Session: 2026-02-05 — Agent: claude-opus-4-6

**Status:** Already Implemented (verified and marked done)

#### What Was Done
- Verified that Task 18's `--check-licenses` functionality was **already fully implemented** during Task 8 (subtask 8.2)
- Ran all 8 existing license-related tests (4 service + 4 CLI) — all pass
- Verified all 6 acceptance criteria are covered by existing implementation and tests

#### Acceptance Criteria Verification
| # | Criterion | Evidence | Pass |
|---|-----------|----------|------|
| 1 | License check disabled by default | `validation_service.py:94` — `check_licenses: bool = False` | YES |
| 2 | License check enabled validates unlicensed users | `validation_service.py:163-177` + test at line 383 | YES |
| 3 | Licensed user passes validation | `test_license_check_enabled_user_licensed_no_issues` (line 360) | YES |
| 4 | Unlicensed user fails with BATCH_004 | `test_license_check_enabled_user_unlicensed_creates_batch_004` (line 383) | YES |
| 5 | `is_enterprise_voice_enabled` from UserConfiguration used | `validation_service.py:163` — `user.is_enterprise_voice_enabled` | YES |
| 6 | License check skipped for already failed items | `test_license_failure_skips_number_validation` (line 794) | YES |

#### Key Decisions Made
- **No code changes needed**: The implementation in Task 8.2 already covers everything Task 18 describes, using a better approach (inline check on already-resolved user) instead of the separate `_check_user_license` method proposed in the task description
- **No separate test file created**: Tests are well-organized in `test_validation_service.py` and `test_cli_batch_validate.py` — creating `test_validation_service_licenses.py` would duplicate existing tests
- **Task marked as done without code changes**: This is the correct outcome when prior tasks already implemented the functionality

#### Existing Test Coverage
- `test_license_check_enabled_user_licensed_no_issues` — test_validation_service.py:360
- `test_license_check_enabled_user_unlicensed_creates_batch_004` — test_validation_service.py:383
- `test_license_check_disabled_unlicensed_user_no_issues` — test_validation_service.py:416
- `test_license_failure_skips_number_validation` — test_validation_service.py:794
- `test_check_licenses_option_accepted` — test_cli_batch_validate.py:505
- `test_check_licenses_short_option_accepted` — test_cli_batch_validate.py:551
- `test_calls_validate_job_with_check_licenses_false` — test_cli_batch_validate.py:757
- `test_calls_validate_job_with_check_licenses_true` — test_cli_batch_validate.py:800

#### Gotchas and Warnings
- Task 18 was written before Task 8 was implemented, but Task 8 (subtask 8.2) included the full license check functionality
- The task description proposes a `_check_user_license` private method that makes a separate `get_user()` call — the actual implementation is better because it uses the user already resolved by `resolve_user()`, avoiding an extra API call

---
