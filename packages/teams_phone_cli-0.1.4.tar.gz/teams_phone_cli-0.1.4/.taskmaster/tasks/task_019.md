# Task ID: 19

**Title:** Add progress bar with resume support

**Status:** pending

**Dependencies:** 11, 12, 22, 24

**Priority:** medium

**Description:** Enhance the progress display to correctly show resumed progress when continuing interrupted jobs, showing "Resuming job: X/Y completed".

**Details:**

Enhance batch CLI commands with resume-aware progress:

```python
from rich.progress import (
    Progress,
    SpinnerColumn,
    TextColumn,
    BarColumn,
    TaskProgressColumn,
    TimeRemainingColumn,
    MofNCompleteColumn,
)

def create_execution_progress(
    job: Job,
    *,
    no_color: bool = False,
    json_mode: bool = False,
) -> tuple[Progress, int]:
    """Create progress bar with correct initial state for resumed jobs.
    
    Returns:
        Tuple of (Progress instance, task_id)
    """
    # Calculate already completed items
    already_completed = sum(
        1 for i in job.items
        if i.status in (ItemStatus.SUCCEEDED, ItemStatus.FAILED, ItemStatus.NEEDS_REVIEW)
    )
    
    progress = Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        MofNCompleteColumn(),
        TimeRemainingColumn(),
        disable=json_mode,
        console=Console(no_color=no_color),
    )
    
    # Create task with correct initial completed count
    if already_completed > 0:
        description = f"Resuming {job.name} ({already_completed}/{job.total_count} done)..."
    else:
        description = f"Executing {job.name}..."
    
    task_id = progress.add_task(
        description,
        total=job.total_count,
        completed=already_completed,  # Start from previous progress
    )
    
    return progress, task_id

# In batch_run and batch_resume:
def batch_run(...):
    # ...
    with create_execution_progress(job, no_color=cli_ctx.no_color, json_mode=cli_ctx.json_output) as (progress, task_id):
        def on_progress(p: ExecutionProgress):
            progress.update(task_id, completed=p.completed)
        
        result = await executor.execute_job(job, on_progress=on_progress)
```

Also add terminal output for resume:
```
Resuming job: 45/500 items completed
Remaining: 455 items to process
```

**Test Strategy:**

Unit tests in `tests/unit/test_batch_progress.py`:
1. Test new job starts progress at 0
2. Test resumed job starts progress at already_completed count
3. Test description shows "Resuming" for resumed jobs
4. Test progress updates correctly during execution
5. Test JSON mode disables progress display
6. Test no_color mode applies to progress console

---

## Implementation Notes

### Session: 2026-02-05 - Agent: claude-opus-4-6

**Status:** Implemented

#### What Was Done
- Created `_create_execution_progress()` helper in `src/teams_phone/cli/batch.py` (lines ~492-530)
- Refactored `batch_run`, `batch_resume`, and `batch_retry` to use the shared helper
- Replaced `TaskProgressColumn` with `MofNCompleteColumn` for clearer "45/500" style display
- Added `Console(no_color=...)` to the Progress constructor for color control
- Added `TaskID` import from `rich.progress` for proper return type annotation
- Created `tests/unit/test_batch_progress.py` with 13 unit tests covering all acceptance criteria

#### Key Decisions Made
- **Used explicit `action` parameter** instead of auto-detecting from `already_completed`: The task spec suggested auto-detecting "Resuming" vs "Executing" based on `already_completed > 0`, but this would cause retry commands to show "Resuming" instead of "Retrying". An explicit `action` parameter preserves per-command semantics.
- **Named as `_create_execution_progress`** (private): Consistent with existing helper naming convention (`_display_summary_report`, `_validate_resume_state`, etc.). Tests import it directly since it's in the same package.
- **Used `job.total_count - job.pending_count`** for completed count: Equivalent to counting terminal statuses after `_reset_in_progress_items()` runs, but simpler and consistent with existing code pattern.
- **Progress created before `with` block**: Rich's `Progress.add_task()` works before `__enter__()`, so the helper returns `(Progress, TaskID)` as a plain tuple. The caller uses the Progress as a context manager in the `with` statement.

#### Patterns Discovered
- Rich `Progress.add_task()` can be called before entering the context manager — tasks are tracked internally regardless of live display state.
- Existing tests patch `teams_phone.cli.batch.Progress` and work through the refactor because the helper lives in the same module.

#### Open Items for Next Agent
- None — all acceptance criteria met, all tests passing.

#### Gotchas and Warnings
- The `TaskProgressColumn` import was removed and replaced with `MofNCompleteColumn`. Any test that checks for `TaskProgressColumn` in constructor args would need updating (none exist currently).
- The `Console` import was already present in `batch.py` (line 17), so no new import was needed for it.
