# Task ID: 25

**Title:** Phase 4 Validation Gate (Definition of Done)

**Status:** pending

**Dependencies:** 24, 18, 19, 20, 21

**Priority:** high

**Description:** Final validation checkpoint confirming all Phase 4 Polish work and Definition of Done criteria are met. This gate verifies: license validation, progress bar with resume support, integration tests, and documentation updates.

**Details:**

Phase 4 Completion Criteria (from PRD):
- [x] --check-licenses flag validates Teams Phone license
- [x] Progress bar resumes correctly showing "Resuming: X/Y completed"
- [x] Integration tests cover full batch workflow
- [x] CLI help text complete and accurate
- [x] CLAUDE.md updated with batch commands

Definition of Done (from PRD):
- [x] All Must-have requirements implemented
- [x] Unit test coverage > 80% for new code (12 dedicated batch test files + 5 supporting)
- [x] Integration tests for happy path and key error cases
- [x] CLI help text complete and accurate
- [x] CLAUDE.md updated with batch commands

This is the final gate - mark as done when batch migration feature is ready for release.

**Test Strategy:**

No test strategy provided.

---

## Live Validation (2026-02-06)

### Automated Checks
- Unit tests: all passing (`uv run pytest tests/ -m unit`)
- Integration tests: all passing (`uv run pytest tests/ -m integration`)
- Lint/format: clean (`uv run ruff check src/ tests/`)
- Type check: clean (`uv run mypy src/`)

### End-to-End Live Test (hvk-consulting.com test tenant)

**Test scenario:** Unassigned 3 users (Claude Code, Scoobie Doo, Testy Tests) from their current numbers, then batch-assigned them new Chicago Direct Routing numbers.

**Workflow executed:**
1. `batch create test-migration.csv` — 3-item job created
2. `batch validate --check-licenses` — correctly detected enterprise voice disabled post-unassign (BATCH_004)
3. `batch validate` (without license flag) — 3/3 valid
4. `batch run` — 3/3 succeeded in 6s with concurrent workers
5. `batch status` — confirmed completed state with timing
6. `batch export --succeeded` — CSV export worked
7. `users show` — verified all 3 users had new Chicago numbers assigned

**Reversal batch:** Created restore-migration.csv, ran full create → validate → run workflow. 3/3 succeeded in 5s. All users confirmed restored to original numbers.

**Commands validated against live API:**
- `batch create`, `batch validate`, `batch validate --check-licenses`, `batch run`, `batch run --dry-run`, `batch status`, `batch export`, `batch delete`

### Bugs Found During Live Testing

1. **Re-validation doesn't reset failed items (see task 26)** — Running `validate --check-licenses` (items fail with BATCH_004) then re-running `validate` (without flag) skips already-failed items instead of resetting their status. Workaround: delete and recreate the job.

2. **Dry run marks job as completed (see task 27)** — `batch run --dry-run` transitions job status to "completed", which blocks subsequent real `batch run`. Dry run should preserve the "validated" state so users can proceed to a real run afterward.
