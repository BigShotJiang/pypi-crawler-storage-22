# Changelog

## [0.1.4](https://github.com/hvkc/teams-phone/compare/teams-phone-cli-v0.1.3...teams-phone-cli-v0.1.4) (2026-02-06)


### Features

* add batch migration system for bulk phone number operations ([31998ff](https://github.com/hvkc/teams-phone/commit/31998ff223dc5153d0d44dc4945684e63450e9d0))
* **cli:** add async execution and service wiring for batch validate ([535fe1b](https://github.com/hvkc/teams-phone/commit/535fe1ba0119840f99c3edf7e917612706260390))
* **cli:** add batch create command for CSV-based migrations ([fbf24ed](https://github.com/hvkc/teams-phone/commit/fbf24ed0973c8de431f726f19f551351bf5f4517))
* **cli:** add batch delete command for removing completed jobs ([f93e249](https://github.com/hvkc/teams-phone/commit/f93e249946e17e39739e81a3a83b74fd92c7f8c9))
* **cli:** add batch export command for CSV result export ([544096c](https://github.com/hvkc/teams-phone/commit/544096c20d3dacd148adb187cff93f25de92d13b))
* **cli:** add batch resume command for interrupted jobs ([9ee75ab](https://github.com/hvkc/teams-phone/commit/9ee75abe147ca485bd049e41477c5fe25ad39e60))
* **cli:** add batch retry command for re-processing failed items ([71e4770](https://github.com/hvkc/teams-phone/commit/71e4770d2a760ca85366ad6887820d77b6a55718))
* **cli:** add batch run command with guard conditions ([f65eb24](https://github.com/hvkc/teams-phone/commit/f65eb2414b98ad787823b08416801f6ab7af6db9))
* **cli:** add batch status command for job monitoring ([c4e40e1](https://github.com/hvkc/teams-phone/commit/c4e40e19bdb90f492d3660111a9bbd2fe4819c20))
* **cli:** add job loading and state validation for batch validate command ([4ef6300](https://github.com/hvkc/teams-phone/commit/4ef630088a1d77b32f8d452a900e31b30b6db976))
* **cli:** add Rich progress bar to batch run command ([fab858f](https://github.com/hvkc/teams-phone/commit/fab858f7c79cc481b932298c508d98a6a75b0fa4))
* **cli:** add summary report display to batch run command ([ec1797a](https://github.com/hvkc/teams-phone/commit/ec1797a6cb4ffb38ac301d6ddf79d796681c79df))
* **cli:** implement async execution context for batch run command ([af1c38f](https://github.com/hvkc/teams-phone/commit/af1c38f17ba283382552ea2468e3b746555913d2))
* **cli:** implement validation report display for batch validate command ([d31a361](https://github.com/hvkc/teams-phone/commit/d31a361917f8046432e04da4823e6a11526b750c))
* **core:** add batch-specific exception hierarchy ([7d2bde0](https://github.com/hvkc/teams-phone/commit/7d2bde06810b1544d7fa7ff9094ec37480860c3d))
* **core:** enhance job state backup and recovery with atomic write pattern ([37fe099](https://github.com/hvkc/teams-phone/commit/37fe0996bded7780459e7c888a83ccae9ccadbbb))
* **core:** implement acquire_lock context manager and get_active_job_id ([98959c2](https://github.com/hvkc/teams-phone/commit/98959c2300bb2a4c0acb58639740d59987786b8c))
* **core:** implement atomic write with fsync and backup for JobStore ([3cad6db](https://github.com/hvkc/teams-phone/commit/3cad6db4a4d85d25fb059abe0cffee0f124898ba))
* **core:** implement cross-platform file locking for JobStore ([dd82b24](https://github.com/hvkc/teams-phone/commit/dd82b24e3ea996a9c2ee6a88631c1513876991e2))
* **core:** implement JobStore core structure with path management ([2957055](https://github.com/hvkc/teams-phone/commit/295705583a157a3781275b4bb33b490b65ca0c42))
* **core:** implement JobStore create_job with file copy and SHA-256 hashing ([e66452d](https://github.com/hvkc/teams-phone/commit/e66452db59b39b88ef3ff51a6ec00dbbf6038dbf))
* **core:** implement load_job, list_jobs, and delete_job with backup recovery ([95443e0](https://github.com/hvkc/teams-phone/commit/95443e070390bb4710cf2b8569552f7243d40356))
* **core:** implement lock info file management with stale lock detection ([fe1301c](https://github.com/hvkc/teams-phone/commit/fe1301c14b9bb5ba8e190e2cb3c71c83044a0b8b))
* **models:** add batch job Pydantic models for migration tracking ([a8430b9](https://github.com/hvkc/teams-phone/commit/a8430b91e60873ab9a6d68d83106211de7138551))
* **services:** add cross-platform SIGINT handler for graceful batch interruption ([0101ff3](https://github.com/hvkc/teams-phone/commit/0101ff3b066531669532e5085e9c0aa3effe2151))
* **services:** add idempotency detection and complete ValidationService ([b74048f](https://github.com/hvkc/teams-phone/commit/b74048f9c5dabafbd4a4ebc8ca8f72aebfb61415))
* **services:** add progress callback and execution logging to BatchExecutor ([1bbd7c1](https://github.com/hvkc/teams-phone/commit/1bbd7c1992aae2395000c3c26eb721af81550adc))
* **services:** add structured JSON Lines execution logging to BatchExecutor ([4c19940](https://github.com/hvkc/teams-phone/commit/4c1994038690670b2e015b2586a49fe5f08c4c4e))
* **services:** create BatchExecutor class with semaphore-based concurrency control ([7a01293](https://github.com/hvkc/teams-phone/commit/7a0129374dbbc162e9f7be0d79d8c6b9280f75f1))
* **services:** create ValidationService class structure with service dependencies ([3370e50](https://github.com/hvkc/teams-phone/commit/3370e50f26835da460571719bcb8e505d204e39f))
* **services:** implement core CSV parsing with BOM and line ending handling ([f9ce448](https://github.com/hvkc/teams-phone/commit/f9ce448680bf30490305fc344a7073453fd4c004))
* **services:** implement CSV header and field validation with phone normalization ([11a151b](https://github.com/hvkc/teams-phone/commit/11a151b8f5ceaf00f246ffb099c277dd1a51aec6))
* **services:** implement duplicate detection with line tracking for CSV parser ([fb7d517](https://github.com/hvkc/teams-phone/commit/fb7d51763db53c9d168507c6fef8dd9a10d410bf))
* **services:** implement item processing loop with incremental state persistence ([bcb71a1](https://github.com/hvkc/teams-phone/commit/bcb71a178899a5197734ec5b747957db81e4f8f4))
* **services:** implement number assignment logic with runtime re-validation ([6698e3b](https://github.com/hvkc/teams-phone/commit/6698e3ba9297b1c54d8c41281b7cb2d2b1957e2e))
* **services:** implement number existence and availability validation in ValidationService ([2f3f289](https://github.com/hvkc/teams-phone/commit/2f3f289b0c4883c95a3854ac6dc93dca013e76a2))
* **services:** implement user existence and license validation in ValidationService ([90d0f72](https://github.com/hvkc/teams-phone/commit/90d0f724c55792b08c31bbd6f0981ab9a6dfca8d))


### Bug Fixes

* **core:** use OpenProcess for Windows process check instead of os.kill ([2ec1c87](https://github.com/hvkc/teams-phone/commit/2ec1c872c42a9d8ea4e41989f7f69ad7346a72fe))
* **services:** prevent dry-run from persisting job state ([eca3da7](https://github.com/hvkc/teams-phone/commit/eca3da74259fb40b4475945d60e9828ed02450a2))
* **services:** reset failed item status on re-validation ([10eac8a](https://github.com/hvkc/teams-phone/commit/10eac8a1eb06a615240668c055ae73c6edf4e20b))


### Documentation

* **claude:** update CLAUDE.md with batch migration documentation ([127e1bf](https://github.com/hvkc/teams-phone/commit/127e1bf5db81c71a3540b287afb65f1fb7ca81e4))
* **prd:** refine batch migration PRD with architecture decisions and clarifications ([3380c90](https://github.com/hvkc/teams-phone/commit/3380c90043357baf28ce8bf926cc7803ff0c5b7f))
* **prd:** resolve final open question on batch user lookups ([20a86e4](https://github.com/hvkc/teams-phone/commit/20a86e48ca1337fa7d8fe0d0817ebe08cf8a4775))

## [0.1.3](https://github.com/hvkc/teams-phone/compare/teams-phone-cli-v0.1.2...teams-phone-cli-v0.1.3) (2026-02-03)


### Features

* add search enhancements for numbers, users, and locations ([35166b3](https://github.com/hvkc/teams-phone/commit/35166b3c7c69db55d4139e7dc1ed70504907ecc4))
* add search enhancements for numbers, users, and locations ([35166b3](https://github.com/hvkc/teams-phone/commit/35166b3c7c69db55d4139e7dc1ed70504907ecc4))
* **cli:** add --assigned-to filter to numbers list command ([bd4757b](https://github.com/hvkc/teams-phone/commit/bd4757b29786841548a1a464e1ec41b15c0fed63))
* **cli:** add --contains flag for substring matching in list filters ([831459e](https://github.com/hvkc/teams-phone/commit/831459e901ceee1e5dbb1242591aa6e3ad73e9c6))
* **cli:** add --quiet flag and performance warnings to search commands ([2485ced](https://github.com/hvkc/teams-phone/commit/2485ced257aec1d9f35175b31a5154fa25e0805b))
* **cli:** add wildcard pattern support to locations search ([c19657e](https://github.com/hvkc/teams-phone/commit/c19657e9b0a672c7005108ad6b44f9693693f8a1))
* **numbers:** add case-insensitive city filter ([2517d98](https://github.com/hvkc/teams-phone/commit/2517d98079fe9f14efca24b85d7eed652e3c5e65))
* **services:** add assigned_to_user_id filter to NumberService.list_numbers() ([21156ff](https://github.com/hvkc/teams-phone/commit/21156ff60345bf135f135869e5147b32ce0e80dd))
* **services:** add LARGE_RESULT_THRESHOLD and return total count from search_numbers ([28c3ba9](https://github.com/hvkc/teams-phone/commit/28c3ba9d587d5be39c667df64adf764c2cf5a884))
* **services:** add wildcard helper functions to UserService ([48e1c28](https://github.com/hvkc/teams-phone/commit/48e1c2895160ddba722ceab4de5aacac2a53e223))
* **services:** implement _search_users_wildcard method ([2326f98](https://github.com/hvkc/teams-phone/commit/2326f9851c67fb05602438900317a8f9c91a359e))
* **services:** route wildcard display name queries to wildcard search ([5dc3846](https://github.com/hvkc/teams-phone/commit/5dc3846b775530f5cc33ba824c1c5fc7278c169e))


### Bug Fixes

* **tests:** use plain_stdout for help text assertions in CI ([a637986](https://github.com/hvkc/teams-phone/commit/a637986432f4b9180a32f030853883c4d96bfa1e))


### Documentation

* **cli:** document wildcard support in users search help text ([9133cb5](https://github.com/hvkc/teams-phone/commit/9133cb5b0c7cb9db842440aaaae7811dfd39f42b))

## [0.1.2](https://github.com/hvkc/teams-phone/compare/teams-phone-cli-v0.1.1...teams-phone-cli-v0.1.2) (2026-02-03)


### Features

* **cli:** add run_with_service helper to eliminate code duplication ([4d75908](https://github.com/hvkc/teams-phone/commit/4d75908d27cd79a555c086b4ffc363aa8253fc30))


### Bug Fixes

* **ci:** add test summary job for branch protection ([8136aa2](https://github.com/hvkc/teams-phone/commit/8136aa2305b34ab15d22ef466579eebc13cae8ad))
* **lint:** remove unused Path imports from graph client tests ([4309e3f](https://github.com/hvkc/teams-phone/commit/4309e3f04b85a1f72a9b0b66cd2fbbd2fb7ae3c2))
* **pre-commit:** limit mypy to src/ and add missing dependencies ([bf471c1](https://github.com/hvkc/teams-phone/commit/bf471c1b024e6baa6deb104b85b7edb7e75b68fc))
* **test:** correct patch targets in mock_cli_services_users fixture ([ca5596c](https://github.com/hvkc/teams-phone/commit/ca5596c85a2f7f395a9640b7281f25be1a389d7b))


### Documentation

* **claude:** add new skill for analyzing test file line counts and refactoring suggestions ([d77e5b7](https://github.com/hvkc/teams-phone/commit/d77e5b74e2b5da206ab7a69701ae2b2a6dbd179b))
* **taskmaster:** create RUFF_IGNORES.md tracking document ([bd0e9c0](https://github.com/hvkc/teams-phone/commit/bd0e9c0761e8ea12f360e1e658c7667ca1b674c3))
* **tests:** add comprehensive docstrings to fixtures and factories ([7b8c3fb](https://github.com/hvkc/teams-phone/commit/7b8c3fb58a878b8a22d83c44bf60d07728c3aae8))

## [0.1.1](https://github.com/hvkc/teams-phone/compare/teams-phone-cli-v0.1.0...teams-phone-cli-v0.1.1) (2026-02-01)


### Features

* **auth:** add client-secret authentication to AuthService ([e148450](https://github.com/hvkc/teams-phone/commit/e148450842b0a164a4eb07c9ec68a3e411286a5b))
* **auth:** implement login, logout, status, and auth check methods ([8cce0bd](https://github.com/hvkc/teams-phone/commit/8cce0bd7c30840fdd284964c95f83b69bd855264))
* **auth:** implement MSAL certificate-based authentication for AuthService ([4baa21b](https://github.com/hvkc/teams-phone/commit/4baa21b1b1e3820baaab36d124c930af0621092a))
* **auth:** implement token caching and refresh logic ([9836aca](https://github.com/hvkc/teams-phone/commit/9836aca690285217821e750191a60801c7c26e73))
* **claude:** Add commit-changes skill for conventional commits ([8832e08](https://github.com/hvkc/teams-phone/commit/8832e08ae4901d8fa171e79dc146595e88afd607))
* **claude:** Add multi-agent planning document critique skill ([b3c39f7](https://github.com/hvkc/teams-phone/commit/b3c39f7ae1b01ca5a0d51763110d5167d9c866ca))
* **claude:** Add skill generator and template for creating Claude Code skills ([083e1d3](https://github.com/hvkc/teams-phone/commit/083e1d346d99fb4a358784c04d45d3c11d0ab84b))
* **claude:** Add standalone PRD generator skill ([0f609d8](https://github.com/hvkc/teams-phone/commit/0f609d8929bbd45ae029fb5c5c7e1b60b04418a0))
* **claude:** Add task-recon and task-implement workflow skills ([d9bfe92](https://github.com/hvkc/teams-phone/commit/d9bfe92a5775468eacc4f4d4a2b476394234dd6d))
* **cli:** add api-check command for contract validation ([c4e4860](https://github.com/hvkc/teams-phone/commit/c4e48600260d98384af42957398bb730890d302e))
* **cli:** add bulk-assign command with CSV validation phase ([0dffbd7](https://github.com/hvkc/teams-phone/commit/0dffbd7f6648c1c55e07838272951990f12c1a31))
* **cli:** add CSV parsing and validation for policies bulk-assign ([78e8ecf](https://github.com/hvkc/teams-phone/commit/78e8ecf7683e93db06cba465658ed3dc4d3e820a))
* **cli:** add entry point and register command groups ([c4a1f9a](https://github.com/hvkc/teams-phone/commit/c4a1f9ac56d6273b5017a6bc27463e5c11902e72))
* **cli:** add numbers assign command with user resolution and E911 validation ([2eb007b](https://github.com/hvkc/teams-phone/commit/2eb007bae8de1e359fff560bf96fae0fb143a635))
* **cli:** add numbers unassign command with confirmation prompt ([600767f](https://github.com/hvkc/teams-phone/commit/600767fa0651497f6679c44ce53b3c8bb5a45899))
* **cli:** add numbers update command for location/network-site changes ([1498052](https://github.com/hvkc/teams-phone/commit/14980523ce53dab5a6100f3ae1df2639992deaff))
* **cli:** add phone number list, show, and search commands ([ba54a14](https://github.com/hvkc/teams-phone/commit/ba54a14e4b67b9f2a6f72362e084b0bced0dbec7))
* **cli:** add progress spinner for assign/unassign operations ([a2cd770](https://github.com/hvkc/teams-phone/commit/a2cd770de088a9bdc3af43c341d37bbd2f430a59))
* **cli:** complete error handling and results output for bulk-assign ([d8561ee](https://github.com/hvkc/teams-phone/commit/d8561ee25043bde26bff1a0857eed029989babaf))
* **cli:** complete execution loop for policies bulk-assign ([0dff9d0](https://github.com/hvkc/teams-phone/commit/0dff9d0ea605a5ce07529ebf99278d27af86cc6e))
* **cli:** create main Typer app with global options callback ([0235abb](https://github.com/hvkc/teams-phone/commit/0235abbdd0c15ab58f983c13ef7f7c4ea2e8e6e8))
* **cli:** implement auth command group with login, logout, status, and refresh ([cda0658](https://github.com/hvkc/teams-phone/commit/cda0658cd1145a66bc2ef37c8f82e9bc08fe4e96))
* **cli:** implement locations command group with list, show, search ([351ef1a](https://github.com/hvkc/teams-phone/commit/351ef1acb1d53922970618fe07ed694003454509))
* **cli:** implement policies command group with list, show, and assign ([5fe6888](https://github.com/hvkc/teams-phone/commit/5fe6888c9875ff0a41cfeb994a603f3e67e5c3ba))
* **cli:** implement progress bar with real-time counters for bulk-assign ([e9a8b1f](https://github.com/hvkc/teams-phone/commit/e9a8b1f898f3dbfcb9bacf9c62b857be03d60549))
* **cli:** implement tenants command group with multi-tenant management ([7d1a8a0](https://github.com/hvkc/teams-phone/commit/7d1a8a09fca7641a8c01e95fc1726cce47356db6))
* **cli:** implement typed CLIContext for dependency injection ([8c24f5f](https://github.com/hvkc/teams-phone/commit/8c24f5f127ca79a847232a48a35e5c7619331973))
* **cli:** implement users command group with list, show, search ([d985d4c](https://github.com/hvkc/teams-phone/commit/d985d4c4a9d7acc09b0b5e7bb57dcb2394eb246a))
* **core:** add cache metadata and staleness detection ([94a2e20](https://github.com/hvkc/teams-phone/commit/94a2e20757a0b824e8b62a54808d520b53a7528c))
* **core:** add constants and exception hierarchy ([a67c756](https://github.com/hvkc/teams-phone/commit/a67c75669b43d698494061d102e86351e6efac50))
* **core:** add CSV reading methods to CacheManager ([0d820ff](https://github.com/hvkc/teams-phone/commit/0d820ffc676b187df501397da1e2402b7b93cb12))
* **core:** add default tenant management to ConfigManager ([0f4e63c](https://github.com/hvkc/teams-phone/commit/0f4e63c3c1fa4e6b241db0d4fbb6e784793d58a2))
* **core:** add phone number and async operation models ([c0d6255](https://github.com/hvkc/teams-phone/commit/c0d6255f806f6a75cd08b22130564c7105eb2e26))
* **core:** add policy, location, and generic API response models ([8a24d8c](https://github.com/hvkc/teams-phone/commit/8a24d8ca96693430848c0ffc4e1ae6b0243df17f))
* **core:** add Pydantic models for configuration and authentication ([7475e5a](https://github.com/hvkc/teams-phone/commit/7475e5a7a496006afdb9cefbc51e532c6e789ba7))
* **core:** add user configuration models for Graph API ([7f0eea2](https://github.com/hvkc/teams-phone/commit/7f0eea218cd48802054b5807435460b4ea7f33f0))
* **core:** implement CacheManager with token storage ([34d764d](https://github.com/hvkc/teams-phone/commit/34d764d4a8bf6282adbf93c9adc2d027379d7be0))
* **core:** implement ConfigManager TOML loading and saving ([cde48bc](https://github.com/hvkc/teams-phone/commit/cde48bc37b4087d320f96529d4bdb4fd89d11507))
* **core:** implement phone number utility functions ([601c36c](https://github.com/hvkc/teams-phone/commit/601c36c6c1e541c63f74ba5efe51f229914465e0))
* **core:** implement tenant CRUD operations in ConfigManager ([fbe6491](https://github.com/hvkc/teams-phone/commit/fbe6491e79c69d71de35c628d38a4a095f7b3e2e))
* **graph:** add retry logic with tenacity for transient failures ([d720ffc](https://github.com/hvkc/teams-phone/commit/d720ffcac7f9e87ee0f3cf2fd5164897fb7b9428))
* **graph:** implement error mapping to exception hierarchy ([59bb59b](https://github.com/hvkc/teams-phone/commit/59bb59b3be42785b1f1f358620b1a268881fb0bd))
* **graph:** implement httpx async client with auth header injection ([767ccd1](https://github.com/hvkc/teams-phone/commit/767ccd11f5279f09ccb444b2aec80b8d49a6d2c5))
* **graph:** implement pagination handling with AsyncIterator ([87667de](https://github.com/hvkc/teams-phone/commit/87667dee943ba910cce49532abdef62ab803b72d))
* **infrastructure:** add debug logging with --debug-log flag ([6e739af](https://github.com/hvkc/teams-phone/commit/6e739af0beecff2ad3283f2a623d9f59e6cf0600))
* **infrastructure:** implement OutputFormatter for rich CLI output ([4f81bbe](https://github.com/hvkc/teams-phone/commit/4f81bbeaa57ea27fff24000120ea7841d6ebb959))
* **scripts:** Add PowerShell export script for Teams Phone data ([510cbeb](https://github.com/hvkc/teams-phone/commit/510cbebc06d807fba9cf66a1107d455e46656596))
* **services:** add assign_policy method to PolicyService ([1b6990c](https://github.com/hvkc/teams-phone/commit/1b6990c5d9493f76f31066be765ce0d68bc23e7c))
* **services:** add get_number method to NumberService with normalization ([62882e8](https://github.com/hvkc/teams-phone/commit/62882e81f1e17837d9136762ab9c0db271121f59))
* **services:** add get_user_policies method to PolicyService ([3365415](https://github.com/hvkc/teams-phone/commit/336541548a46f6693248f711d5b409980a3c739e))
* **services:** add operation ID extraction helper to NumberService ([6091630](https://github.com/hvkc/teams-phone/commit/60916308eab44a70fd87c1b1254b021aa9d42aa8))
* **services:** add poll_operation method to NumberService ([499f039](https://github.com/hvkc/teams-phone/commit/499f0390f8171283c0a9f1e0939907ea7981fed8))
* **services:** add results file generation for bulk CSV operations ([eeab31c](https://github.com/hvkc/teams-phone/commit/eeab31c2ac0fbe977bdbfb57358b67be406a8383))
* **services:** add test_connection method to TenantService ([6a5a4a3](https://github.com/hvkc/teams-phone/commit/6a5a4a3b9c18c36465c391c2b796c9eb8008eacd))
* **services:** implement assign_number method with E911 location enforcement ([5f5e960](https://github.com/hvkc/teams-phone/commit/5f5e960baaf8296da548974de62834849aef3fcf))
* **services:** implement async validation for bulk CSV operations ([6b2f8ce](https://github.com/hvkc/teams-phone/commit/6b2f8ceff58d38a71db13fdb109cacfc1e3f3c3d))
* **services:** implement CSV parsing for bulk phone number assignments ([07eb687](https://github.com/hvkc/teams-phone/commit/07eb6870e11d49cf3de383b0a343a3edd2359804))
* **services:** implement LocationService for emergency locations ([1084424](https://github.com/hvkc/teams-phone/commit/10844241aa8c8bf2e41628e27ef87a5574527ca6))
* **services:** implement NumberService with list_numbers method ([7d1fb2f](https://github.com/hvkc/teams-phone/commit/7d1fb2f0fd0ae9ee6b594050523c9f3cfa4a060f))
* **services:** implement PolicyService with CSV cache reading ([df6117c](https://github.com/hvkc/teams-phone/commit/df6117c01a2d70b2cf85cea0f5c4507dae735196))
* **services:** implement search_numbers method with wildcard pattern matching ([8c35c45](https://github.com/hvkc/teams-phone/commit/8c35c4569cae6949535e292622790e1bc50a4079))
* **services:** implement switch_tenant with auto-login logic ([28ae2df](https://github.com/hvkc/teams-phone/commit/28ae2df78c1b5db799aacd2baa7d1136dce8a26d))
* **services:** implement TenantService with CRUD operations ([e3d76fc](https://github.com/hvkc/teams-phone/commit/e3d76fc6622f652dc39ed152cac72ef90627231a))
* **services:** implement unassign_number method in NumberService ([38ae3cc](https://github.com/hvkc/teams-phone/commit/38ae3ccb237f5c5a518a4cfaba6ae42d18ae0d26))
* **services:** implement UserService for user voice configuration operations ([84e113e](https://github.com/hvkc/teams-phone/commit/84e113e8cf814c558a31278bc6f95edea1524f9d))
* **taskmaster:** Add detailed task breakdown for implementation ([c1b40cb](https://github.com/hvkc/teams-phone/commit/c1b40cb556ec317c1f8467fe33b4466488778a1b))
* **taskmaster:** Add initial task breakdown and complexity analysis ([04cc4ba](https://github.com/hvkc/teams-phone/commit/04cc4baa5dcf53c429235ab269023af65961e33b))
* **taskmaster:** add PowerShell script for batch task implementation ([719149a](https://github.com/hvkc/teams-phone/commit/719149a2441a583432580d0c812b03966dd56d69))
* **taskmaster:** Add validation checkpoint gates for phased implementation ([4b405e9](https://github.com/hvkc/teams-phone/commit/4b405e92adbf6d14f571f9e37b9b6e719a087532))
* **users:** display show command output as formatted tables ([68d20f4](https://github.com/hvkc/teams-phone/commit/68d20f4bcdbdfd7b4b7d82b6c81e887467bba597))


### Bug Fixes

* **api:** improve Location header parsing and error messages ([cbe469a](https://github.com/hvkc/teams-phone/commit/cbe469a8cd4cf4e11aff2dd6e9947d7897da6b72))
* **cli:** add ASCII fallback for Windows legacy console encoding ([2ab2050](https://github.com/hvkc/teams-phone/commit/2ab2050edc35aa0acde139a12dae9718abddc5e6))
* **contract:** resolve Windows asyncio event loop issues in contract tests ([cf83a03](https://github.com/hvkc/teams-phone/commit/cf83a039ea5dc106668a9fe422ade5ab5320d73d))
* **models:** add ineligibleUser account type, client-side assigned filter ([91ff085](https://github.com/hvkc/teams-phone/commit/91ff085a7a4323dacc81c49b4cd6c759b3aad5db))
* **models:** correct AsyncOperation contract for polling responses ([74755f3](https://github.com/hvkc/teams-phone/commit/74755f32ccf5722aee8e9d1938b6c24d6784d366))
* **scripts:** correct nested path construction in OutputPath parameter ([e00cc7a](https://github.com/hvkc/teams-phone/commit/e00cc7a9539c91334553c3161746cd640f7e352b))
* **services:** implement runtime policyId resolution for policy assignment ([25d94ba](https://github.com/hvkc/teams-phone/commit/25d94bac55691c5c0f54ea330be65f63cb5acddb))
* **taskmaster:** resolve circular dependency in tasks 19-22 and 40 ([a5c22b1](https://github.com/hvkc/teams-phone/commit/a5c22b1c48fdd47a726c3b4c8df19608d599b8b9))
* **tests:** mock CSV writers in bulk-assign tests to prevent file creation ([e911792](https://github.com/hvkc/teams-phone/commit/e9117921109bca7102612f3eb93d4bb5ba44dcf6))
* **tests:** monkeypatch shutil.get_terminal_size for consistent Rich rendering ([bf481cb](https://github.com/hvkc/teams-phone/commit/bf481cb57e5541f1ddfa18065dab04b7a877d14f))
* **tests:** set COLUMNS env var in CliRunner for consistent terminal width ([d9fabf2](https://github.com/hvkc/teams-phone/commit/d9fabf2a876ea164994bb9204b94595425486384))
* **tests:** use checkmark symbol in success messages ([81ef310](https://github.com/hvkc/teams-phone/commit/81ef310ae7ccdc397c42be6e02f9fcff94c08675))
* **users:** enrich display names from directory for all user queries ([52ddac4](https://github.com/hvkc/teams-phone/commit/52ddac4976f08f49639667dc37361b5c056cee2e))
* **users:** use v1.0 /users endpoint for display name search ([93c91a2](https://github.com/hvkc/teams-phone/commit/93c91a20907f31ac6fbd79cfd234f7bdfda01b47))


### Documentation

* add CLAUDE.md for Claude Code guidance ([6132299](https://github.com/hvkc/teams-phone/commit/61322998da45e17472c554cb5eeb550d2d0f4d10))
* add comprehensive user documentation ([63df33d](https://github.com/hvkc/teams-phone/commit/63df33d5918e1c59b7c77b0e8edf2c2b148c9bd4))
* **architecture:** Add comprehensive architecture document for Teams Phone CLI ([17df81c](https://github.com/hvkc/teams-phone/commit/17df81c17ab7635931a8986fa103788b893b26ec))
* **architecture:** Restructure architecture into modular sections ([a58930f](https://github.com/hvkc/teams-phone/commit/a58930fa480aa8ad977abb3c4424790b2c339a11))
* **claude:** Add prd and claude scope patterns to commit-changes ([e705c09](https://github.com/hvkc/teams-phone/commit/e705c097da37a06a4e22ac5e4f221d4f22baf2cd))
* **cli:** Restructure CLI specification into modular sections ([b6e5d7a](https://github.com/hvkc/teams-phone/commit/b6e5d7a8a5a72d84e2a7bf88805b18b3c957e58a))
* fix GitHub repository URLs in documentation ([ec921f9](https://github.com/hvkc/teams-phone/commit/ec921f9ec505465aa74e15163f6377f76e8c3af3))
* **graph:** Restructure Graph API contracts into modular sections ([abff4b9](https://github.com/hvkc/teams-phone/commit/abff4b9d9b7f887e549b53e578ee3a2cf05e33b0))
* improve CLAUDE.md with testing patterns and key details ([61f7423](https://github.com/hvkc/teams-phone/commit/61f742376cd54f33df2ffcc422005321b01a3b2e))
* **prd:** Integrate testing into roadmap phases instead of deferring to end ([1db7071](https://github.com/hvkc/teams-phone/commit/1db7071e0024cb17a88d2f307b7230fa99470e90))
* **prd:** Restructure PRD into modular sections ([111cac5](https://github.com/hvkc/teams-phone/commit/111cac554a1a5b601354977be88733bc9562f54e))
* **prd:** Strengthen API contract validation requirements ([eaa9644](https://github.com/hvkc/teams-phone/commit/eaa9644b740011180047d94296d86da2a4f1cd65))
* **taskmaster:** Add CLI specification and Graph API contracts ([af6f5dc](https://github.com/hvkc/teams-phone/commit/af6f5dc23555bd2ed37612b185cf0544f01408c8))
* **taskmaster:** Add comprehensive PRD for Teams Phone CLI ([9bbc388](https://github.com/hvkc/teams-phone/commit/9bbc3885454e56916bf01724883f5a2a47a1671d))
* **taskmaster:** Remove device-code auth, make certificate the default ([21acb2a](https://github.com/hvkc/teams-phone/commit/21acb2acf240291d65f47e8673c6b1885a1486aa))
* update test commands to use uv run ([dc37a4b](https://github.com/hvkc/teams-phone/commit/dc37a4b79f0185693a040e4d33525c4a4dc54581))
