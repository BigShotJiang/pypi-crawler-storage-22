# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Teams Phone CLI - A Python CLI tool for managing Microsoft Teams Phone configurations via Microsoft Graph API. Uses certificate-based authentication with Microsoft Entra ID.

## Commands

```bash
# Install dependencies (uses uv package manager)
uv pip install -e ".[dev]"

# Run the CLI
python -m teams_phone

# Testing
uv run pytest tests/                    # All tests
uv run pytest tests/ -m unit            # Unit tests only
uv run pytest tests/ -m integration     # Integration tests (requires API access)
uv run pytest tests/ -m contract        # Contract validation tests
uv run pytest tests/unit/test_exceptions.py -v  # Single test file
uv run pytest tests/unit/test_graph_client_core.py::TestGraphClientInit::test_accepts_auth_service -v  # Single test

# Code quality
uv run ruff check src/ tests/    # Lint
uv run ruff format src/ tests/   # Format
uv run mypy src/                 # Type check (strict mode)
uv run pre-commit run --all-files  # Run all hooks

# Batch migration commands
teams-phone batch create <csv_file>                  # Create job from CSV
teams-phone batch status                              # List all jobs
teams-phone batch status <job_id>                     # Show job details
teams-phone batch validate <job_id>                   # Pre-flight validation
teams-phone batch validate <job_id> --check-licenses  # Validate with license checks
teams-phone batch run <job_id>                        # Execute validated job
teams-phone batch run <job_id> --dry-run              # Simulate execution
teams-phone batch resume <job_id>                     # Resume interrupted job
teams-phone batch retry <job_id>                      # Retry failed items
teams-phone batch export <job_id> --failed            # Export failed items to CSV
teams-phone batch export <job_id> --succeeded         # Export succeeded items
teams-phone batch export <job_id> --all               # Export all items
teams-phone batch delete <job_id>                     # Delete job and files
```

## Architecture

**Layered Monolith:**
```
src/teams_phone/
├── cli/
│   ├── main.py             # Root CLI app and global options
│   └── batch.py            # Batch migration commands (create, status, validate, run, resume, retry, export, delete)
├── services/
│   ├── user_service.py     # User lookup and management
│   ├── number_service.py   # Phone number assignment/unassignment
│   ├── batch_executor.py   # Concurrent batch execution with progress callbacks
│   ├── batch_csv_parser.py # CSV parsing and structural validation
│   └── validation_service.py  # Pre-flight validation (user existence, number availability)
├── infrastructure/
│   ├── graph_client.py     # Async Graph API client (context manager)
│   ├── cache_manager.py    # CSV cache for locations/policies
│   ├── config_manager.py   # App configuration and auth settings
│   └── job_store.py        # Batch job persistence (JSON files)
├── models/
│   ├── graph.py            # Graph API response models
│   └── batch.py            # Job, JobItem, JobStatus, ItemStatus models
├── constants.py            # API URLs, exit codes, defaults
├── exceptions.py           # Exception hierarchy with exit codes
└── utils.py                # Phone number normalization
```

**Batch Job Storage:**
```
.teams-phone/jobs/<job-id>/
├── job.json            # Job state (items, status, timestamps)
└── input.csv           # Copy of original CSV
```

**Key Patterns:**
- Services abstract Graph API + CSV cache access (repository pattern)
- Graph assign/unassign operations return 202 and require polling
- CSV cache for locations/policies (Graph API limitations) - exported via PowerShell script
- Exponential backoff retry (3 retries) for Graph API throttling (429, 503)
- Pydantic models use `extra="forbid"` to fail-fast on unexpected API fields (contract validation)
- GraphClient is an async context manager: `async with GraphClient(...) as client:`
- Batch executor uses semaphore-based concurrency (1-10 workers) with per-item progress callbacks
- Job store uses file locking to prevent concurrent execution of the same job

**Exception Hierarchy:** All inherit from `TeamsPhoneError` with specific exit codes (2-8) for auth, authorization, not-found, validation, rate-limit, config, and contract errors. Batch operations add exit codes 9-13 for CSV parse, validation, execution, lock, and interruption errors.

## Task Management

This project uses TaskMaster for phased implementation tracking. Tasks are in `.taskmaster/tasks/`.

```bash
# Use these Claude skills for task workflow
/task-recon [task-id]    # Deep reconnaissance before implementation
/task-implement          # Execute implementation with context
```

## Documentation

- `.taskmaster/docs/architecture/` - Architecture decisions and component design
- `.taskmaster/docs/cli-specification/` - CLI command specifications
- `.taskmaster/docs/graph-api-contracts/` - Graph API endpoint contracts
- `scripts/README.md` - PowerShell CSV export setup and troubleshooting

## Graph API Notes

- Uses beta endpoint (`graph.microsoft.com/beta`) for Teams Phone operations
- Requires 8 application permissions + Teams Administrator role
- Certificate-based auth via MSAL
- Async operations (number assignment) return 202 - must poll for completion

## Testing Notes

- Unit tests mock GraphClient with `respx` for HTTP-level mocking
- Contract tests validate real API responses against Pydantic models (requires API access)
- Tests use `asyncio_mode = "strict"` - async tests must be explicitly marked with `@pytest.mark.asyncio`
- Large test files are split by concern (e.g., `test_graph_client_*.py`, `test_number_service_*.py`)
- Shared test fixtures and factories live in `tests/unit/conftest.py`
