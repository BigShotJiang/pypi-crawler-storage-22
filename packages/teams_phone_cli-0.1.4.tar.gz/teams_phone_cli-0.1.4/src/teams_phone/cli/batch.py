"""Batch migration CLI commands.

This module provides commands for batch migration operations including
creating jobs from CSV files, validating them, and executing migrations.
"""

from __future__ import annotations

import asyncio
import csv
import re
from datetime import timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Annotated

import typer
from rich.console import Console
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TaskID,
    TextColumn,
    TimeRemainingColumn,
)
from rich.table import Table

from teams_phone.cli.context import CLIContext, get_context
from teams_phone.constants import ExitCode
from teams_phone.exceptions import JobLockError, TeamsPhoneError, ValidationError
from teams_phone.infrastructure import CacheManager, GraphClient
from teams_phone.infrastructure.job_store import JobStore
from teams_phone.models.batch import ItemStatus, JobStatus
from teams_phone.services import AuthService
from teams_phone.services.batch_csv_parser import parse_batch_csv
from teams_phone.services.batch_executor import BatchExecutor, ExecutionProgress
from teams_phone.services.number_service import NumberService
from teams_phone.services.user_service import UserService
from teams_phone.services.validation_service import ValidationReport, ValidationService


if TYPE_CHECKING:
    from teams_phone.infrastructure.output_formatter import OutputFormatter
    from teams_phone.models.batch import Job, JobItem


# Status styles for Rich table coloring
STATUS_STYLES: dict[JobStatus, str] = {
    JobStatus.CREATED: "",
    JobStatus.VALIDATING: "yellow",
    JobStatus.VALIDATED: "green",
    JobStatus.RUNNING: "yellow",
    JobStatus.COMPLETED: "green",
    JobStatus.INTERRUPTED: "red",
}


batch_app = typer.Typer(
    name="batch",
    help="Batch migration operations.",
    no_args_is_help=True,
)


@batch_app.command("create")
def batch_create(
    ctx: typer.Context,
    csv_file: Annotated[
        Path,
        typer.Argument(
            help="Path to the CSV file containing migration data.",
            exists=True,
            readable=True,
            resolve_path=True,
        ),
    ],
    name: Annotated[
        str | None,
        typer.Option(
            "--name",
            "-n",
            help="Custom job name (defaults to CSV filename).",
        ),
    ] = None,
) -> None:
    """Create a batch migration job from a CSV file.

    Parses the CSV file, validates its structure, generates a unique job ID,
    and persists the initial job state.

    The CSV file must contain columns:
    - user_upn: User principal name (email)
    - phone_number: Phone number in E.164 format

    Example:
        teams-phone batch create migrations.csv
        teams-phone batch create migrations.csv --name "Q1 Migration"
    """
    cli_ctx = get_context(ctx)
    formatter = cli_ctx.get_output_formatter()

    try:
        # Parse and validate CSV
        parse_result = parse_batch_csv(csv_file)

        # Display warnings for extension stripping
        for warning in parse_result.warnings:
            formatter.warning(warning)

        # Determine job name
        job_name = name if name else csv_file.stem

        # Create job using JobStore
        job_store = JobStore()
        job = job_store.create_job(
            name=job_name,
            input_file=csv_file,
            items=parse_result.items,
        )

        # Output result
        if cli_ctx.json_output:
            formatter.json(
                {
                    "job_id": job.id,
                    "name": job.name,
                    "status": job.status.value,
                    "item_count": len(job.items),
                    "input_file": str(csv_file),
                    "input_hash": job.input_hash,
                    "created_at": job.created_at.isoformat(),
                }
            )
        else:
            formatter.success(f"Created job: {job.id}")
            formatter.info(f"  Name: {job.name}")
            formatter.info(f"  Items: {len(job.items)}")
            formatter.info(f"  Status: {job.status.value}")
            formatter.info("")
            formatter.info("Next steps:")
            formatter.info(
                "  1. Validate the job: teams-phone batch validate " + job.id
            )
            formatter.info("  2. Execute the job: teams-phone batch run " + job.id)

    except TeamsPhoneError as e:
        formatter.error(e.message, remediation=e.remediation)
        raise typer.Exit(e.exit_code) from None


@batch_app.command("status")
def batch_status(
    ctx: typer.Context,
    job_id: Annotated[
        str | None,
        typer.Argument(
            help="Job ID to show details for. If omitted, lists all jobs.",
        ),
    ] = None,
) -> None:
    """View batch job status.

    Without arguments, lists all jobs with summary statistics.
    With a job ID, shows detailed information about that specific job.

    Examples:
        teams-phone batch status
        teams-phone batch status 20260203-143015-a1b2-q1-migration
    """
    cli_ctx = get_context(ctx)
    formatter = cli_ctx.get_output_formatter()

    try:
        job_store = JobStore()

        if job_id is None:
            _display_job_list(cli_ctx, formatter, job_store)
        else:
            _display_job_detail(cli_ctx, formatter, job_store, job_id)

    except TeamsPhoneError as e:
        formatter.error(e.message, remediation=e.remediation)
        raise typer.Exit(e.exit_code) from None


def _display_job_list(
    cli_ctx: CLIContext,
    formatter: OutputFormatter,
    job_store: JobStore,
) -> None:
    """Display list of all jobs."""
    jobs = job_store.list_jobs()

    if cli_ctx.json_output:
        formatter.json(
            [
                {
                    "id": job.id,
                    "name": job.name,
                    "status": job.status.value,
                    "total_count": job.total_count,
                    "succeeded_count": job.succeeded_count,
                    "failed_count": job.failed_count,
                    "pending_count": job.pending_count,
                    "created_at": job.created_at.isoformat(),
                    "updated_at": job.updated_at.isoformat(),
                }
                for job in jobs
            ]
        )
        return

    if not jobs:
        formatter.info("No batch jobs found.")
        formatter.info("")
        formatter.info("To create a job:")
        formatter.info("  teams-phone batch create <csv_file>")
        return

    console = Console(no_color=cli_ctx.no_color)
    table = Table(title="Batch Jobs")
    table.add_column("Job ID", style="cyan")
    table.add_column("Name")
    table.add_column("Status")
    table.add_column("Total", justify="right")
    table.add_column("Succeeded", justify="right", style="green")
    table.add_column("Failed", justify="right", style="red")
    table.add_column("Pending", justify="right")
    table.add_column("Created")

    for job in jobs:
        status_style = STATUS_STYLES.get(job.status, "")
        status_text = (
            f"[{status_style}]{job.status.value}[/{status_style}]"
            if status_style
            else job.status.value
        )
        table.add_row(
            job.id,
            job.name,
            status_text,
            str(job.total_count),
            str(job.succeeded_count),
            str(job.failed_count),
            str(job.pending_count),
            job.created_at.strftime("%Y-%m-%d %H:%M"),
        )

    console.print(table)


def _display_job_detail(
    cli_ctx: CLIContext,
    formatter: OutputFormatter,
    job_store: JobStore,
    job_id: str,
) -> None:
    """Display detailed information about a specific job."""
    job = job_store.load_job(job_id)

    if cli_ctx.json_output:
        _display_job_detail_json(formatter, job)
        return

    console = Console(no_color=cli_ctx.no_color)
    _display_job_header(console, job)
    _display_job_progress(console, job)
    _display_job_problem_items(console, job)
    _display_job_next_steps(console, formatter, job)


def _display_job_detail_json(formatter: OutputFormatter, job: Job) -> None:
    """Output job detail as JSON."""
    formatter.json(
        {
            "id": job.id,
            "name": job.name,
            "status": job.status.value,
            "created_at": job.created_at.isoformat(),
            "updated_at": job.updated_at.isoformat(),
            "started_at": job.started_at.isoformat() if job.started_at else None,
            "completed_at": job.completed_at.isoformat() if job.completed_at else None,
            "input_file": job.input_file,
            "input_hash": job.input_hash,
            "total_count": job.total_count,
            "succeeded_count": job.succeeded_count,
            "failed_count": job.failed_count,
            "pending_count": job.pending_count,
            "items": [
                {
                    "line_number": item.line_number,
                    "user_upn": item.user_upn,
                    "phone_number": item.phone_number,
                    "status": item.status.value,
                    "error_code": item.error_code,
                    "error_message": item.error_message,
                }
                for item in job.items
            ],
        }
    )


def _display_job_header(console: Console, job: Job) -> None:
    """Display job header information."""
    status_style = STATUS_STYLES.get(job.status, "")
    status_text = (
        f"[{status_style}]{job.status.value}[/{status_style}]"
        if status_style
        else job.status.value
    )

    console.print(f"\n[bold]Job: {job.id}[/bold]")
    console.print(f"  Name: {job.name}")
    console.print(f"  Status: {status_text}")
    console.print(f"  Input: {job.input_file}")
    console.print(f"  Created: {job.created_at.strftime('%Y-%m-%d %H:%M:%S')}")

    if job.started_at:
        console.print(f"  Started: {job.started_at.strftime('%Y-%m-%d %H:%M:%S')}")
    if job.completed_at:
        console.print(f"  Completed: {job.completed_at.strftime('%Y-%m-%d %H:%M:%S')}")
    if job.duration:
        console.print(f"  Duration: {job.duration}")


def _display_job_progress(console: Console, job: Job) -> None:
    """Display job progress counts."""
    console.print("\n[bold]Progress:[/bold]")
    console.print(f"  Total: {job.total_count}")
    console.print(f"  [green]Succeeded: {job.succeeded_count}[/green]")
    console.print(f"  [red]Failed: {job.failed_count}[/red]")
    console.print(f"  Pending: {job.pending_count}")

    needs_review_count = sum(
        1 for item in job.items if item.status == ItemStatus.NEEDS_REVIEW
    )
    if needs_review_count > 0:
        console.print(f"  [yellow]Needs Review: {needs_review_count}[/yellow]")


def _display_job_problem_items(console: Console, job: Job) -> None:
    """Display failed and needs_review items with details."""
    # Show failed items with error details
    failed_items = [item for item in job.items if item.status == ItemStatus.FAILED]
    if failed_items:
        console.print("\n[bold red]Failed Items:[/bold red]")
        failed_table = Table()
        failed_table.add_column("Line", justify="right")
        failed_table.add_column("User UPN")
        failed_table.add_column("Phone Number")
        failed_table.add_column("Error")

        for item in failed_items:
            error_text = item.error_message or item.error_code or "Unknown error"
            failed_table.add_row(
                str(item.line_number),
                item.user_upn,
                item.phone_number,
                error_text,
            )
        console.print(failed_table)

    # Show needs_review items
    needs_review_items = [
        item for item in job.items if item.status == ItemStatus.NEEDS_REVIEW
    ]
    if needs_review_items:
        console.print("\n[bold yellow]Needs Review:[/bold yellow]")
        review_table = Table()
        review_table.add_column("Line", justify="right")
        review_table.add_column("User UPN")
        review_table.add_column("Phone Number")
        review_table.add_column("Reason")

        for item in needs_review_items:
            reason = item.error_message or item.error_code or "Manual review required"
            review_table.add_row(
                str(item.line_number),
                item.user_upn,
                item.phone_number,
                reason,
            )
        console.print(review_table)


def _display_job_next_steps(
    console: Console, formatter: OutputFormatter, job: Job
) -> None:
    """Display next steps guidance based on job status."""
    console.print("")
    if job.status == JobStatus.CREATED:
        formatter.info("Next steps:")
        formatter.info(f"  1. Validate the job: teams-phone batch validate {job.id}")
        formatter.info(f"  2. Execute the job: teams-phone batch run {job.id}")
    elif job.status == JobStatus.VALIDATED:
        formatter.info("Next steps:")
        formatter.info(f"  Execute the job: teams-phone batch run {job.id}")
    elif job.status == JobStatus.INTERRUPTED:
        formatter.info("Next steps:")
        formatter.info(f"  Resume the job: teams-phone batch resume {job.id}")
    elif job.status == JobStatus.COMPLETED and job.failed_count > 0:
        formatter.info("Some items failed. Review errors above and consider:")
        formatter.info("  - Fixing issues in a new CSV and creating a new job")
        formatter.info("  - Manually addressing failed items")


def _format_duration(delta: timedelta) -> str:
    """Format a timedelta as human-readable string (e.g., '2m 15s', '1h 23m')."""
    total_seconds = int(delta.total_seconds())
    hours, remainder = divmod(total_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    parts: list[str] = []
    if hours > 0:
        parts.append(f"{hours}h")
    if minutes > 0:
        parts.append(f"{minutes}m")
    if seconds > 0 or not parts:
        parts.append(f"{seconds}s")
    return " ".join(parts)


def _display_summary_error_codes(formatter: OutputFormatter, job: Job) -> None:
    """Display error code breakdown for failed items."""
    error_counts: dict[str, int] = {}
    for item in job.items:
        if item.error_code:
            error_counts[item.error_code] = error_counts.get(item.error_code, 0) + 1
    if error_counts:
        formatter.info("")
        formatter.info("Failures by Error Code:")
        for code, count in sorted(error_counts.items()):
            formatter.info(f"  - {code} ({count} items)")


def _display_summary_next_steps(formatter: OutputFormatter, job: Job) -> None:
    """Display next steps guidance based on job outcome."""
    if job.status != JobStatus.INTERRUPTED and job.failed_count == 0:
        return

    formatter.info("")
    formatter.info("Next Steps:")
    if job.status == JobStatus.INTERRUPTED:
        formatter.warning(
            f"Job interrupted - Resume with: teams-phone batch resume {job.id}"
        )
    if job.failed_count > 0:
        formatter.info(f"  1. Review failures: teams-phone batch status {job.id}")
        formatter.info(
            f"  2. Export failed: teams-phone batch export {job.id} --failed"
        )
        formatter.info(f"  3. Retry failed: teams-phone batch retry {job.id}")


def _display_summary_report(
    formatter: OutputFormatter,
    job: Job,
    json_mode: bool,
) -> None:
    """Display execution summary per Appendix D format."""
    if json_mode:
        formatter.json(job.model_dump(mode="json"))
        return

    separator = "=" * 80
    formatter.info(separator)
    formatter.info("Batch Execution Summary")
    formatter.info(separator)
    formatter.info(f"Job: {job.name}")
    formatter.info(f"Job ID: {job.id}")
    if job.duration is not None:
        formatter.info(f"Duration: {_format_duration(job.duration)}")
    formatter.info(f"Items: {job.total_count} total")
    formatter.info("")

    # Results
    formatter.info("Results:")
    pct = (job.succeeded_count / job.total_count * 100) if job.total_count else 0
    formatter.success(f"{job.succeeded_count} succeeded ({pct:.1f}%)")
    if job.failed_count:
        formatter.error(f"{job.failed_count} failed")
    if job.pending_count:
        formatter.info(f"  * {job.pending_count} pending")

    _display_summary_error_codes(formatter, job)
    _display_summary_next_steps(formatter, job)

    formatter.info(separator)


def _create_execution_progress(
    job: Job,
    formatter: OutputFormatter,
    *,
    action: str,
    json_mode: bool = False,
    no_color: bool = False,
) -> tuple[Progress, TaskID]:
    """Create a Rich progress bar configured for batch execution.

    Builds a Progress instance with spinner, description, bar, M/N counter,
    and time remaining columns. The progress task starts at the number of
    already-completed items so resumed/retried jobs show correct progress.

    Args:
        job: The batch job to track.
        formatter: Output formatter (used for Windows-safe spinner selection).
        action: Verb for the progress description (e.g. "Executing", "Resuming", "Retrying").
        json_mode: When True, disables the progress display entirely.
        no_color: When True, disables color output on the progress console.

    Returns:
        A tuple of (Progress instance, task ID) ready for use as a context manager.
    """
    progress = Progress(
        SpinnerColumn(spinner_name=formatter.get_spinner_name()),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        MofNCompleteColumn(),
        TimeRemainingColumn(),
        console=Console(no_color=no_color),
        disable=json_mode,
    )
    already_completed = job.total_count - job.pending_count
    task_id = progress.add_task(
        f"{action} {job.name}...",
        total=job.total_count,
        completed=already_completed,
    )
    return progress, task_id


# Valid states for starting validation
VALIDATABLE_STATES = {JobStatus.CREATED, JobStatus.VALIDATED}


def _display_validation_issues(
    formatter: OutputFormatter,
    report: ValidationReport,
    strict: bool,
) -> None:
    """Display validation issues and warnings.

    Args:
        formatter: Output formatter for display.
        report: Validation report with results.
        strict: Whether strict mode is enabled.
    """
    # Display issues (limited to first 20)
    if report.issues:
        formatter.info("")
        formatter.info("Issues found:")
        for issue in report.issues[:20]:
            formatter.error(
                f"  Line {issue.line_number}: [{issue.error_code}] "
                f"{issue.error_message}"
            )
            if issue.suggested_fix:
                formatter.info(f"    Fix: {issue.suggested_fix}")
        if len(report.issues) > 20:
            formatter.info(f"  ... and {len(report.issues) - 20} more issues")

    # Display warnings in strict mode
    if strict and report.warnings:
        formatter.info("")
        formatter.info("Warnings (treated as errors in strict mode):")
        for warning in report.warnings[:10]:
            formatter.error(f"  {warning}")
        if len(report.warnings) > 10:
            formatter.info(f"  ... and {len(report.warnings) - 10} more warnings")


def _display_validation_report_human(
    formatter: OutputFormatter,
    job: Job,
    report: ValidationReport,
    strict: bool,
    validation_failed: bool,
) -> None:
    """Display validation report in human-readable format.

    Args:
        formatter: Output formatter for display.
        job: The validated job.
        report: Validation report with results.
        strict: Whether strict mode is enabled.
        validation_failed: Whether validation failed.
    """
    # Display summary
    formatter.info(f"Validation summary for job: {job.id}")
    formatter.info(f"  Total items: {report.total_items}")
    valid_display = formatter.success if report.valid_count > 0 else formatter.info
    valid_display(f"  Valid: {report.valid_count}")
    invalid_display = formatter.error if report.invalid_count > 0 else formatter.info
    invalid_display(f"  Invalid: {report.invalid_count}")

    # Display issues and warnings
    _display_validation_issues(formatter, report, strict)

    formatter.info("")

    # Show result message and next steps
    if validation_failed:
        formatter.error("Validation failed")
        formatter.info("")
        formatter.info("Fix the issues above and re-run validation:")
        formatter.info(f"  teams-phone batch validate {job.id}")
    else:
        formatter.success("Validation passed!")
        formatter.info("")
        formatter.info(f"Next step: teams-phone batch run {job.id}")


@batch_app.command("validate")
def batch_validate(
    ctx: typer.Context,
    job_id: Annotated[
        str,
        typer.Argument(
            help="Job ID to validate.",
        ),
    ],
    strict: Annotated[
        bool,
        typer.Option(
            "--strict",
            "-s",
            help="Fail if any validation issues are found (exit code 10).",
        ),
    ] = False,
    check_licenses: Annotated[
        bool,
        typer.Option(
            "--check-licenses",
            "-l",
            help="Verify users have Teams Phone licenses (slower).",
        ),
    ] = False,
) -> None:
    """Validate a batch migration job before execution.

    Runs pre-flight validation checks on all items in the job:
    - User existence in Azure AD
    - Phone number availability
    - Optionally: Teams Phone license assignment (--check-licenses)

    The job must be in 'created' or 'validated' state. Running validation
    on an already-validated job will re-run all checks.

    Examples:
        teams-phone batch validate 20260204-143015-abcd-migration
        teams-phone batch validate 20260204-143015-abcd-migration --strict
        teams-phone batch validate 20260204-143015-abcd-migration --check-licenses
    """
    cli_ctx = get_context(ctx)
    formatter = cli_ctx.get_output_formatter()

    try:
        job_store = JobStore()

        # Load job from disk
        job = job_store.load_job(job_id)

        # Validate job state
        if job.status not in VALIDATABLE_STATES:
            raise ValidationError(
                f"Job cannot be validated in '{job.status.value}' state",
                remediation=(
                    f"Job must be in 'created' or 'validated' state. "
                    f"Current state: '{job.status.value}'."
                ),
            )

        # Transition to VALIDATING state
        job.status = JobStatus.VALIDATING
        job_store.save_job(job)

        # Define async validation function
        config_manager = cli_ctx.get_config_manager()

        async def run_validation() -> tuple[Job, ValidationReport]:
            """Execute validation with async services."""
            cache_manager = CacheManager()
            auth_service = AuthService(config_manager, cache_manager)

            async with GraphClient(auth_service) as graph_client:
                user_service = UserService(graph_client)
                number_service = NumberService(graph_client)
                validation_service = ValidationService(user_service, number_service)
                return await validation_service.validate_job(
                    job, check_licenses=check_licenses
                )

        # Execute validation with progress display
        with formatter.progress(job.total_count, "Validating") as progress:
            task_id = list(progress.task_ids)[0]
            validated_job, report = asyncio.run(run_validation())
            progress.update(task_id, completed=job.total_count)

        # Determine if validation failed
        # In strict mode, warnings also count as failures
        has_errors = report.invalid_count > 0
        has_warnings = len(report.warnings) > 0
        validation_failed = has_errors or (strict and has_warnings)

        # Update job status based on validation result
        if validation_failed:
            validated_job.status = JobStatus.CREATED
        else:
            validated_job.status = JobStatus.VALIDATED
        job_store.save_job(validated_job)

        # Output validation results
        if cli_ctx.json_output:
            formatter.json(
                {
                    "job_id": validated_job.id,
                    "valid": not validation_failed,
                    "total": report.total_items,
                    "valid_count": report.valid_count,
                    "invalid_count": report.invalid_count,
                    "warning_count": len(report.warnings),
                    "issues": [vars(i) for i in report.issues],
                }
            )
        else:
            _display_validation_report_human(
                formatter, validated_job, report, strict, validation_failed
            )
            if validation_failed:
                raise typer.Exit(code=ExitCode.BATCH_VALIDATION_ERROR)

    except TeamsPhoneError as e:
        formatter.error(e.message, remediation=e.remediation)
        raise typer.Exit(e.exit_code) from None


@batch_app.command("run")
def batch_run(
    ctx: typer.Context,
    job_id: Annotated[
        str,
        typer.Argument(
            help="Job ID to execute.",
        ),
    ],
    concurrency: Annotated[
        int,
        typer.Option(
            "--concurrency",
            "-c",
            help="Number of concurrent operations (1-10).",
            min=1,
            max=10,
        ),
    ] = 3,
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            help="Simulate execution without making changes.",
        ),
    ] = False,
) -> None:
    """Execute a validated batch migration job.

    Runs the batch job, assigning phone numbers to users via Microsoft
    Graph API with concurrent operations and progress display.

    The job must be in 'validated' state before execution. Use
    'batch validate' to validate a job first.

    Examples:
        teams-phone batch run 20260204-143015-abcd-migration
        teams-phone batch run 20260204-143015-abcd-migration --concurrency 5
        teams-phone batch run 20260204-143015-abcd-migration --dry-run
    """
    cli_ctx = get_context(ctx)
    formatter = cli_ctx.get_output_formatter()

    try:
        job_store = JobStore()

        # Load job from disk
        job = job_store.load_job(job_id)

        # Validate job state - must be VALIDATED to run
        if job.status != JobStatus.VALIDATED:
            raise ValidationError(
                f"Job must be validated before running (current: '{job.status.value}')",
                remediation=f"Run: teams-phone batch validate {job_id}",
            )

        # Check for concurrent execution
        active_job_id = job_store.get_active_job_id()
        if active_job_id is not None:
            raise JobLockError(active_job_id)

        # Display dry-run warning
        if dry_run:
            formatter.warning("DRY RUN - No changes will be made")

        # Pre-execution info
        formatter.info(f"Executing job: {job_id}")
        formatter.info(f"  Items: {job.total_count}, Concurrency: {concurrency}")

        # Define async execution coroutine
        config_manager = cli_ctx.get_config_manager()

        async def run_execution() -> Job:
            """Execute batch job with async services."""
            cache_manager = CacheManager()
            auth_service = AuthService(config_manager, cache_manager)

            async with GraphClient(auth_service) as graph_client:
                user_service = UserService(graph_client)
                number_service = NumberService(graph_client)

                executor = BatchExecutor(
                    user_service=user_service,
                    number_service=number_service,
                    job_store=job_store,
                    concurrency=concurrency,
                    dry_run=dry_run,
                )

                progress, task = _create_execution_progress(
                    job,
                    formatter,
                    action="Executing",
                    json_mode=cli_ctx.json_output,
                    no_color=cli_ctx.no_color,
                )

                with (
                    job_store.acquire_lock(job_id),
                    progress,
                ):

                    def on_progress(
                        p: ExecutionProgress,
                    ) -> None:
                        progress.update(task, completed=p.completed)

                    return await executor.execute_job(job, on_progress=on_progress)

        try:
            result_job = asyncio.run(run_execution())
        except JobLockError as e:
            formatter.error(e.message, remediation=e.remediation)
            raise typer.Exit(e.exit_code) from None

        _display_summary_report(formatter, result_job, cli_ctx.json_output)

        if result_job.failed_count > 0:
            raise typer.Exit(code=ExitCode.BATCH_EXECUTION_ERROR)

    except TeamsPhoneError as e:
        formatter.error(e.message, remediation=e.remediation)
        raise typer.Exit(e.exit_code) from None


def _validate_resume_state(job: Job, job_id: str) -> None:
    """Validate that a job is in INTERRUPTED state for resuming.

    Args:
        job: The job to validate.
        job_id: Job ID for remediation hint.

    Raises:
        ValidationError: If job is not in INTERRUPTED state.
    """
    if job.status != JobStatus.INTERRUPTED:
        msg = f"Job is not interrupted (current: '{job.status.value}')"
        remediation = None
        if job.status == JobStatus.COMPLETED:
            remediation = (
                f"Use 'batch retry' to re-process failed items: "
                f"teams-phone batch retry {job_id}"
            )
        raise ValidationError(msg, remediation=remediation)


def _reset_in_progress_items(
    job: Job,
    job_store: JobStore,
    formatter: OutputFormatter,
) -> None:
    """Reset IN_PROGRESS items to PENDING and persist if needed.

    Args:
        job: The job whose items to reset.
        job_store: Store to save the job after reset.
        formatter: Output formatter for status messages.
    """
    in_progress_count = 0
    for item in job.items:
        if item.status == ItemStatus.IN_PROGRESS:
            item.status = ItemStatus.PENDING
            in_progress_count += 1
    if in_progress_count > 0:
        formatter.info(f"Reset {in_progress_count} in-progress item(s) to pending")
        job_store.save_job(job)


def _validate_retry_state(job: Job, job_id: str) -> None:
    """Validate that a job is in a retryable state (COMPLETED or INTERRUPTED).

    Args:
        job: The job to validate.
        job_id: Job ID for remediation hint.

    Raises:
        ValidationError: If job is not in a retryable state.
    """
    retryable_states = (JobStatus.COMPLETED, JobStatus.INTERRUPTED)
    if job.status not in retryable_states:
        raise ValidationError(
            f"Job cannot be retried in '{job.status.value}' state",
            remediation=(
                f"Job must be in 'completed' or 'interrupted' state. "
                f"Current state: '{job.status.value}'."
            ),
        )


def _reset_failed_items(
    job: Job,
    job_store: JobStore,
    formatter: OutputFormatter,
) -> int:
    """Reset FAILED and NEEDS_REVIEW items to PENDING for retry.

    Clears error_code and error_message but preserves the attempts counter
    to track cumulative retry count.

    Args:
        job: The job whose items to reset.
        job_store: Store to save the job after reset.
        formatter: Output formatter for status messages.

    Returns:
        Number of items reset for retry.
    """
    retryable_statuses = (ItemStatus.FAILED, ItemStatus.NEEDS_REVIEW)
    retryable_items = [i for i in job.items if i.status in retryable_statuses]

    # Warn about items with 3+ attempts before resetting
    high_attempt_items = [i for i in retryable_items if i.attempts >= 3]
    if high_attempt_items:
        formatter.warning(
            f"{len(high_attempt_items)} item(s) have failed 3 or more times"
        )

    for item in retryable_items:
        item.status = ItemStatus.PENDING
        item.error_code = None
        item.error_message = None

    if retryable_items:
        job_store.save_job(job)

    return len(retryable_items)


@batch_app.command("resume")
def batch_resume(
    ctx: typer.Context,
    job_id: Annotated[
        str,
        typer.Argument(
            help="Job ID to resume.",
        ),
    ],
    concurrency: Annotated[
        int,
        typer.Option(
            "--concurrency",
            "-c",
            help="Number of concurrent operations (1-10).",
            min=1,
            max=10,
        ),
    ] = 3,
) -> None:
    """Resume an interrupted batch job.

    Continues an interrupted batch job from its saved state. Items that
    were in-progress when interrupted are reset to pending (safe due to
    idempotent assignments). Already-succeeded items are skipped.

    The job must be in 'interrupted' state. Use 'batch retry' to
    re-process failed items in a completed job.

    Examples:
        teams-phone batch resume 20260204-143015-abcd-migration
        teams-phone batch resume 20260204-143015-abcd-migration --concurrency 5
    """
    cli_ctx = get_context(ctx)
    formatter = cli_ctx.get_output_formatter()

    try:
        job_store = JobStore()

        # Load job from disk
        job = job_store.load_job(job_id)

        # Validate job state - must be INTERRUPTED to resume
        _validate_resume_state(job, job_id)

        # Check for concurrent execution
        active_job_id = job_store.get_active_job_id()
        if active_job_id is not None:
            raise JobLockError(active_job_id)

        # Reset IN_PROGRESS items to PENDING (safe due to idempotency)
        _reset_in_progress_items(job, job_store, formatter)

        # Display resume info
        completed = job.succeeded_count
        pending = job.pending_count
        formatter.info(f"Resuming job: {completed}/{job.total_count} items completed")
        formatter.info(f"  Remaining: {pending} items")
        formatter.info(f"  Items: {job.total_count}, Concurrency: {concurrency}")

        # Define async execution coroutine
        config_manager = cli_ctx.get_config_manager()

        async def run_execution() -> Job:
            """Execute batch job with async services."""
            cache_manager = CacheManager()
            auth_service = AuthService(config_manager, cache_manager)

            async with GraphClient(auth_service) as graph_client:
                user_service = UserService(graph_client)
                number_service = NumberService(graph_client)

                executor = BatchExecutor(
                    user_service=user_service,
                    number_service=number_service,
                    job_store=job_store,
                    concurrency=concurrency,
                )

                progress, task = _create_execution_progress(
                    job,
                    formatter,
                    action="Resuming",
                    json_mode=cli_ctx.json_output,
                    no_color=cli_ctx.no_color,
                )

                with (
                    job_store.acquire_lock(job_id),
                    progress,
                ):

                    def on_progress(
                        p: ExecutionProgress,
                    ) -> None:
                        progress.update(task, completed=p.completed)

                    return await executor.execute_job(job, on_progress=on_progress)

        try:
            result_job = asyncio.run(run_execution())
        except JobLockError as e:
            formatter.error(e.message, remediation=e.remediation)
            raise typer.Exit(e.exit_code) from None

        _display_summary_report(formatter, result_job, cli_ctx.json_output)

        if result_job.failed_count > 0:
            raise typer.Exit(code=ExitCode.BATCH_EXECUTION_ERROR)

    except TeamsPhoneError as e:
        formatter.error(e.message, remediation=e.remediation)
        raise typer.Exit(e.exit_code) from None


@batch_app.command("retry")
def batch_retry(
    ctx: typer.Context,
    job_id: Annotated[
        str,
        typer.Argument(
            help="Job ID to retry failed items.",
        ),
    ],
    concurrency: Annotated[
        int,
        typer.Option(
            "--concurrency",
            "-c",
            help="Number of concurrent operations (1-10).",
            min=1,
            max=10,
        ),
    ] = 3,
) -> None:
    """Retry failed items in a batch job.

    Re-processes only items with FAILED or NEEDS_REVIEW status from a
    completed or interrupted batch job. Already-succeeded items are not
    touched. The attempt counter is preserved to track cumulative retries.

    Items that have failed 3 or more times will trigger a warning before
    retry execution begins.

    Examples:
        teams-phone batch retry 20260204-143015-abcd-migration
        teams-phone batch retry 20260204-143015-abcd-migration --concurrency 5
    """
    cli_ctx = get_context(ctx)
    formatter = cli_ctx.get_output_formatter()

    try:
        job_store = JobStore()

        # Load job from disk
        job = job_store.load_job(job_id)

        # Validate job state - must be COMPLETED or INTERRUPTED
        _validate_retry_state(job, job_id)

        # Check for concurrent execution
        active_job_id = job_store.get_active_job_id()
        if active_job_id is not None:
            raise JobLockError(active_job_id)

        # Reset FAILED/NEEDS_REVIEW items to PENDING
        retry_count = _reset_failed_items(job, job_store, formatter)

        # Early exit if no items to retry
        if retry_count == 0:
            formatter.success("No failed items to retry - all items succeeded!")
            return

        # Display retry info
        formatter.info(f"Retrying {retry_count} failed item(s)")
        formatter.info(f"  Items: {job.total_count}, Concurrency: {concurrency}")

        # Define async execution coroutine
        config_manager = cli_ctx.get_config_manager()

        async def run_execution() -> Job:
            """Execute batch job with async services."""
            cache_manager = CacheManager()
            auth_service = AuthService(config_manager, cache_manager)

            async with GraphClient(auth_service) as graph_client:
                user_service = UserService(graph_client)
                number_service = NumberService(graph_client)

                executor = BatchExecutor(
                    user_service=user_service,
                    number_service=number_service,
                    job_store=job_store,
                    concurrency=concurrency,
                )

                progress, task = _create_execution_progress(
                    job,
                    formatter,
                    action="Retrying",
                    json_mode=cli_ctx.json_output,
                    no_color=cli_ctx.no_color,
                )

                with (
                    job_store.acquire_lock(job_id),
                    progress,
                ):

                    def on_progress(
                        p: ExecutionProgress,
                    ) -> None:
                        progress.update(task, completed=p.completed)

                    return await executor.execute_job(job, on_progress=on_progress)

        try:
            result_job = asyncio.run(run_execution())
        except JobLockError as e:
            formatter.error(e.message, remediation=e.remediation)
            raise typer.Exit(e.exit_code) from None

        _display_summary_report(formatter, result_job, cli_ctx.json_output)

        if result_job.failed_count > 0:
            raise typer.Exit(code=ExitCode.BATCH_EXECUTION_ERROR)

    except TeamsPhoneError as e:
        formatter.error(e.message, remediation=e.remediation)
        raise typer.Exit(e.exit_code) from None


# Valid states for exporting job results (per PRD US-005)
EXPORTABLE_STATES = {JobStatus.VALIDATED, JobStatus.COMPLETED, JobStatus.INTERRUPTED}

# CSV columns for each export filter type
_BASE_COLUMNS = ["user_upn", "phone_number"]
_ERROR_COLUMNS = ["status", "error_code", "error_message", "attempts"]


def _filter_items(job: Job, filter_type: str) -> list[JobItem]:
    """Filter job items by export filter type.

    Args:
        job: The job to filter items from.
        filter_type: One of "failed", "succeeded", or "all".

    Returns:
        Filtered list of job items.
    """
    if filter_type == "failed":
        return [
            item
            for item in job.items
            if item.status in (ItemStatus.FAILED, ItemStatus.NEEDS_REVIEW)
        ]
    if filter_type == "succeeded":
        return [item for item in job.items if item.status == ItemStatus.SUCCEEDED]
    return list(job.items)


def _write_export_csv(
    items: list[JobItem],
    output_path: Path,
    include_errors: bool,
) -> None:
    """Write job items to a CSV file.

    Args:
        items: Job items to write.
        output_path: Path for the output CSV file.
        include_errors: Whether to include error columns.
    """
    fieldnames = _BASE_COLUMNS + _ERROR_COLUMNS if include_errors else _BASE_COLUMNS

    with output_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for item in items:
            row: dict[str, str | int | None] = {
                "user_upn": item.user_upn,
                "phone_number": item.phone_number,
            }
            if include_errors:
                row["status"] = item.status.value
                row["error_code"] = item.error_code or ""
                row["error_message"] = item.error_message or ""
                row["attempts"] = item.attempts
            writer.writerow(row)


@batch_app.command("export")
def batch_export(
    ctx: typer.Context,
    job_id: Annotated[
        str,
        typer.Argument(
            help="Job ID to export results from.",
        ),
    ],
    failed: Annotated[
        bool,
        typer.Option(
            "--failed",
            help="Export only failed and needs-review items.",
        ),
    ] = False,
    succeeded: Annotated[
        bool,
        typer.Option(
            "--succeeded",
            help="Export only succeeded items.",
        ),
    ] = False,
    all_items: Annotated[
        bool,
        typer.Option(
            "--all",
            help="Export all items.",
        ),
    ] = False,
    output: Annotated[
        Path | None,
        typer.Option(
            "--output",
            "-o",
            help="Output file path (default: <job-name-slug>-<filter>.csv).",
        ),
    ] = None,
) -> None:
    """Export batch job results to CSV.

    Exports job items filtered by status to a CSV file. Exactly one
    filter must be specified: --failed, --succeeded, or --all.

    Failed and all exports include additional error columns
    (status, error_code, error_message, attempts).

    Examples:
        teams-phone batch export 20260204-143015-abcd-migration --failed
        teams-phone batch export 20260204-143015-abcd-migration --succeeded
        teams-phone batch export 20260204-143015-abcd-migration --all -o results.csv
    """
    cli_ctx = get_context(ctx)
    formatter = cli_ctx.get_output_formatter()

    try:
        # Validate exactly one filter is specified
        filters = [("failed", failed), ("succeeded", succeeded), ("all", all_items)]
        active = [name for name, value in filters if value]

        if len(active) != 1:
            raise ValidationError(
                "Exactly one filter must be specified: --failed, --succeeded, or --all",
                remediation="Example: teams-phone batch export <job-id> --failed",
            )

        filter_type = active[0]

        job_store = JobStore()
        job = job_store.load_job(job_id)

        # Validate job state
        if job.status not in EXPORTABLE_STATES:
            raise ValidationError(
                f"Job cannot be exported in '{job.status.value}' state",
                remediation=(
                    "Job must be in 'validated', 'completed', or 'interrupted' state. "
                    f"Current state: '{job.status.value}'."
                ),
            )

        # Filter items
        items = _filter_items(job, filter_type)

        if not items:
            formatter.info(f"No {filter_type} items found in job '{job_id}'.")
            return

        # Determine output path
        if output is None:
            slug = re.sub(r"[^a-z0-9]+", "-", job.name.lower()).strip("-")
            output = Path(f"{slug}-{filter_type}.csv")

        # Write CSV
        include_errors = filter_type in ("failed", "all")
        _write_export_csv(items, output, include_errors)

        formatter.success(f"Exported {len(items)} items to {output}")

    except TeamsPhoneError as e:
        formatter.error(e.message, remediation=e.remediation)
        raise typer.Exit(e.exit_code) from None


@batch_app.command("delete")
def batch_delete(
    ctx: typer.Context,
    job_id: Annotated[
        str,
        typer.Argument(
            help="Job ID to delete.",
        ),
    ],
    force: Annotated[
        bool,
        typer.Option(
            "--force",
            "-f",
            help="Skip confirmation prompt.",
        ),
    ] = False,
) -> None:
    """Delete a batch job and its associated files.

    Removes a job directory and all its contents (job.json, backups,
    input CSV copy). Running jobs cannot be deleted.

    Examples:
        teams-phone batch delete 20260204-143015-abcd-migration
        teams-phone batch delete 20260204-143015-abcd-migration --force
    """
    cli_ctx = get_context(ctx)
    formatter = cli_ctx.get_output_formatter()

    try:
        job_store = JobStore()

        # Load job to verify it exists and check status
        job = job_store.load_job(job_id)

        # Refuse to delete a running job
        if job.status == JobStatus.RUNNING:
            raise ValidationError(
                "Cannot delete a running job",
                remediation=(
                    "Wait for the job to complete or interrupt it first. "
                    f"Check status: teams-phone batch status {job_id}"
                ),
            )

        # Prompt for confirmation unless --force
        if not force:
            confirm = typer.confirm(
                f"Delete job '{job.name}' ({job.total_count} items, "
                f"{job.succeeded_count} succeeded, {job.failed_count} failed)?"
            )
            if not confirm:
                formatter.info("Deletion cancelled")
                raise typer.Exit(0)

        # Delete the job directory
        job_store.delete_job(job_id)

        if cli_ctx.json_output:
            formatter.json(
                {
                    "status": "deleted",
                    "job_id": job_id,
                }
            )
        else:
            formatter.success(f"Deleted job: {job_id}")

    except TeamsPhoneError as e:
        formatter.error(e.message, remediation=e.remediation)
        raise typer.Exit(e.exit_code) from None
