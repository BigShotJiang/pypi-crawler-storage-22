"""Emergency location management commands for Teams Phone CLI.

This module provides CLI commands for listing, showing, and searching
emergency locations from the CSV cache.
"""

from __future__ import annotations

import re
from enum import Enum
from typing import TYPE_CHECKING, Any

import typer

from teams_phone.cli.context import get_context
from teams_phone.constants import LARGE_RESULT_THRESHOLD
from teams_phone.exceptions import TeamsPhoneError
from teams_phone.infrastructure import CacheManager
from teams_phone.models import EmergencyLocation
from teams_phone.services import LocationService


if TYPE_CHECKING:
    from teams_phone.infrastructure import OutputFormatter

locations_app = typer.Typer(
    name="locations",
    help="Manage emergency locations.",
    no_args_is_help=True,
)


class SearchField(str, Enum):
    """Search field options for location search."""

    NAME = "name"
    ADDRESS = "address"
    CITY = "city"
    COMPANY = "company"


def _format_default(is_default: bool) -> str:
    """Format default status for display."""
    return "Yes" if is_default else "No"


def _location_to_list_dict(location: EmergencyLocation) -> dict[str, Any]:
    """Convert EmergencyLocation to dict for list/search table display."""
    return {
        "description": location.description or "—",
        "address": location.address or "—",
        "city": location.city or "—",
        "state": location.state_or_province or "—",
        "default": _format_default(location.is_default),
    }


def _location_to_json_dict(location: EmergencyLocation) -> dict[str, Any]:
    """Convert EmergencyLocation to dict for JSON output."""
    return {
        "location_id": location.location_id,
        "civic_address_id": location.civic_address_id,
        "description": location.description,
        "company_name": location.company_name,
        "address": location.address,
        "city": location.city,
        "state_or_province": location.state_or_province,
        "postal_code": location.postal_code,
        "country_or_region": location.country_or_region,
        "is_default": location.is_default,
    }


def _get_service() -> LocationService:
    """Create a LocationService instance."""
    cache_manager = CacheManager()
    return LocationService(cache_manager)


def _check_staleness(service: LocationService, formatter: OutputFormatter) -> None:
    """Check for staleness warning and display if needed."""
    staleness_warning = service.get_staleness_warning()
    if staleness_warning:
        formatter.warning(staleness_warning)


def _has_wildcard(query: str) -> bool:
    """Check if query contains wildcard characters."""
    return "*" in query


def _text_matches_pattern(text: str | None, pattern: str) -> bool:
    """Check if text matches pattern (supports wildcards).

    Wildcards use * for any sequence of characters. Without wildcards,
    performs case-insensitive substring search.

    Args:
        text: The text to check (may be None).
        pattern: The search pattern, optionally with wildcards.

    Returns:
        True if the text matches the pattern.
    """
    if text is None:
        return False
    if not pattern:
        return False
    if not _has_wildcard(pattern):
        return pattern.lower() in text.lower()
    # Convert wildcards to regex: * -> .*
    regex_pattern = re.escape(pattern).replace(r"\*", ".*")
    return bool(re.search(regex_pattern, text, re.IGNORECASE))


def _location_matches_query(
    loc: EmergencyLocation, query: str, field: SearchField | None
) -> bool:
    """Check if a location matches the search query.

    Supports wildcard patterns with * for any sequence of characters.
    Without wildcards, performs case-insensitive substring search.

    Args:
        loc: The location to check.
        query: The search query (may contain wildcards).
        field: Optional field to limit search, or None for all fields.

    Returns:
        True if the location matches the query.
    """
    # Define field-to-value mapping
    field_values: dict[SearchField | None, list[str | None]] = {
        SearchField.NAME: [loc.description],
        SearchField.ADDRESS: [loc.address],
        SearchField.CITY: [loc.city],
        SearchField.COMPANY: [loc.company_name],
        None: [loc.description, loc.address, loc.city, loc.company_name],
    }

    values_to_check = field_values.get(field, [])
    return any(_text_matches_pattern(value, query) for value in values_to_check)


@locations_app.command("list")
def list_locations(
    ctx: typer.Context,
    city: str | None = typer.Option(
        None,
        "--city",
        "-c",
        help="Filter by city.",
    ),
    contains: bool = typer.Option(
        False,
        "--contains",
        help="Enable substring matching for string filters (e.g., --city New matches 'New York').",
    ),
    limit: int | None = typer.Option(
        None,
        "--limit",
        "-l",
        help="Limit results to n locations.",
    ),
    all_locations: bool = typer.Option(
        False,
        "--all",
        help="Fetch all locations (default behavior when no limit specified).",
    ),
) -> None:
    """List emergency locations from CSV cache."""
    cli_ctx = get_context(ctx)
    formatter = cli_ctx.get_output_formatter()

    # Validate mutually exclusive options
    if limit is not None and all_locations:
        formatter.error(
            "Cannot specify both --limit and --all",
            remediation="Use either --limit <n> to limit results or --all to fetch all locations.",
        )
        raise typer.Exit(5)  # ValidationError exit code

    try:
        service = _get_service()

        # Check for staleness before output
        _check_staleness(service, formatter)

        locations = service.list_locations()

        # Filter by city if specified
        if city:
            city_lower = city.lower()
            if contains:
                # Substring match
                locations = [
                    loc for loc in locations if city_lower in (loc.city or "").lower()
                ]
            else:
                # Exact match (case-insensitive)
                locations = [
                    loc for loc in locations if (loc.city or "").lower() == city_lower
                ]

        # Apply limit if specified
        if limit is not None:
            locations = locations[:limit]

        if cli_ctx.json_output:
            formatter.json([_location_to_json_dict(loc) for loc in locations])
        else:
            if not locations:
                formatter.info("No locations found matching the specified criteria")
            else:
                formatter.table(
                    data=[_location_to_list_dict(loc) for loc in locations],
                    columns=[
                        "description",
                        "address",
                        "city",
                        "state",
                        "default",
                    ],
                    title="Emergency Locations",
                )
    except TeamsPhoneError as e:
        formatter.error(e.message, remediation=e.remediation)
        raise typer.Exit(e.exit_code) from None


@locations_app.command("show")
def show_location(
    ctx: typer.Context,
    location: str = typer.Argument(
        ...,
        help="Location identifier: ID (GUID) or description.",
    ),
) -> None:
    """Show detailed information for a specific emergency location."""
    cli_ctx = get_context(ctx)
    formatter = cli_ctx.get_output_formatter()

    try:
        service = _get_service()

        # Check for staleness before output
        _check_staleness(service, formatter)

        loc = service.validate_location(location)

        if cli_ctx.json_output:
            formatter.json(_location_to_json_dict(loc))
        else:
            # Identity section
            formatter.table(
                data=[
                    {"field": "Description", "value": loc.description or "—"},
                    {"field": "Location ID", "value": loc.location_id},
                    {"field": "Civic Address ID", "value": loc.civic_address_id},
                    {"field": "Company Name", "value": loc.company_name or "—"},
                ],
                columns=["field", "value"],
                title="Location Details",
            )

            # Address section
            formatter.table(
                data=[
                    {"field": "Street", "value": loc.address or "—"},
                    {"field": "City", "value": loc.city or "—"},
                    {"field": "State/Province", "value": loc.state_or_province or "—"},
                    {"field": "Postal Code", "value": loc.postal_code or "—"},
                    {"field": "Country", "value": loc.country_or_region or "—"},
                ],
                columns=["field", "value"],
                title="Address",
            )

            # Status section
            formatter.table(
                data=[
                    {
                        "field": "Default Location",
                        "value": _format_default(loc.is_default),
                    },
                ],
                columns=["field", "value"],
                title="Status",
            )

    except TeamsPhoneError as e:
        formatter.error(e.message, remediation=e.remediation)
        raise typer.Exit(e.exit_code) from None


@locations_app.command("search")
def search_locations(
    ctx: typer.Context,
    query: str = typer.Argument(
        ...,
        help="Search term. Use * as wildcard (e.g., 'Main*', '*HQ', '*central*').",
    ),
    field: SearchField | None = typer.Option(
        None,
        "--field",
        "-f",
        help="Limit search to: name, address, city, company.",
    ),
    limit: int = typer.Option(
        25,
        "--limit",
        "-l",
        help="Maximum results (default: 25).",
    ),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        help="Suppress performance warnings.",
    ),
) -> None:
    """Search emergency locations by name, address, or city."""
    cli_ctx = get_context(ctx)
    formatter = cli_ctx.get_output_formatter()

    try:
        service = _get_service()

        # Check for staleness before output
        _check_staleness(service, formatter)

        # Get all locations for filtered search
        all_locs = service.list_locations()
        total_fetched = len(all_locs)

        if (
            not cli_ctx.json_output
            and not quiet
            and total_fetched > LARGE_RESULT_THRESHOLD
        ):
            from rich.console import Console

            Console(stderr=True).print(
                f"Filtering {total_fetched:,} locations for pattern matching...",
                style="yellow",
            )

        # Filter locations using helper function and apply limit
        results = [
            loc for loc in all_locs if _location_matches_query(loc, query, field)
        ][:limit]

        if cli_ctx.json_output:
            formatter.json([_location_to_json_dict(loc) for loc in results])
        else:
            if not results:
                formatter.info(f"No locations found matching '{query}'")
            else:
                formatter.table(
                    data=[_location_to_list_dict(loc) for loc in results],
                    columns=[
                        "description",
                        "address",
                        "city",
                        "state",
                        "default",
                    ],
                    title=f"Search Results for '{query}'",
                )
    except TeamsPhoneError as e:
        formatter.error(e.message, remediation=e.remediation)
        raise typer.Exit(e.exit_code) from None
