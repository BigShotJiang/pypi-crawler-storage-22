"""Main Typer application for Teams Phone CLI.

This module defines the root Typer app with global options (--json, --verbose,
--tenant, --no-color) that are captured in the context for downstream commands.
"""

from __future__ import annotations

from pathlib import Path

import typer

from teams_phone.cli.api_check import api_check
from teams_phone.cli.auth import auth_app
from teams_phone.cli.batch import batch_app
from teams_phone.cli.context import CLIContext
from teams_phone.cli.locations import locations_app
from teams_phone.cli.numbers import numbers_app
from teams_phone.cli.policies import policies_app
from teams_phone.cli.tenants import tenants_app
from teams_phone.cli.users import users_app
from teams_phone.infrastructure import OutputFormatter
from teams_phone.infrastructure.debug_logger import DebugLogger


app = typer.Typer(
    name="teams-phone",
    help="Manage Microsoft Teams Phone configurations via Microsoft Graph API.",
    no_args_is_help=True,
)


@app.callback()
def main(
    ctx: typer.Context,
    json_output: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output in JSON format for automation.",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show detailed output and debug information.",
    ),
    tenant: str | None = typer.Option(
        None,
        "--tenant",
        "-t",
        help="Override default tenant for this command.",
    ),
    no_color: bool = typer.Option(
        False,
        "--no-color",
        help="Disable color output.",
    ),
    debug_log: Path | None = typer.Option(
        None,
        "--debug-log",
        help="Write debug logs to specified file (JSON Lines format).",
    ),
) -> None:
    """Teams Phone CLI - Manage Microsoft Teams Phone configurations.

    This command provides access to Teams Phone management operations including
    user management, phone number assignment, policy configuration, and more.
    """
    # Create typed context with global options
    cli_ctx = CLIContext(
        json_output=json_output,
        verbose=verbose,
        tenant=tenant,
        no_color=no_color,
        debug_log_path=debug_log,
    )
    # Initialize OutputFormatter immediately (cheap operation)
    cli_ctx.output_formatter = OutputFormatter(
        json_mode=json_output,
        no_color=no_color,
    )
    # Initialize DebugLogger if debug log path is specified
    if debug_log is not None:
        cli_ctx.debug_logger = DebugLogger(debug_log)
    # ConfigManager is lazily initialized when needed to avoid disk I/O on --help
    ctx.obj = cli_ctx


# Register command groups with main app
# Note: auth_app is imported from teams_phone.cli.auth
app.add_typer(users_app, name="users", help="Manage Teams users.")
app.add_typer(numbers_app, name="numbers", help="Manage phone numbers.")
app.add_typer(policies_app, name="policies", help="Manage voice policies.")
app.add_typer(locations_app, name="locations", help="Manage emergency locations.")
app.add_typer(tenants_app, name="tenants", help="Manage tenant profiles.")
app.add_typer(auth_app, name="auth", help="Authentication commands.")
app.add_typer(batch_app, name="batch", help="Batch migration operations.")

# Register standalone commands
app.command("api-check")(api_check)
