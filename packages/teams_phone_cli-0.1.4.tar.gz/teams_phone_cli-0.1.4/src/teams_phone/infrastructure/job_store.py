"""Job store for batch migration job persistence.

This module provides the JobStore class for persisting batch migration jobs
to JSON files. Jobs are stored in `.teams-phone/jobs/<job-id>/` directories
with atomic write patterns for crash-safe persistence.
"""

import contextlib
import hashlib
import json
import logging
import os
import re
import secrets
import shutil
import sys
from collections.abc import Generator
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pydantic import ValidationError as PydanticValidationError

from teams_phone.exceptions import ConfigurationError, JobLockError, NotFoundError
from teams_phone.models.batch import Job, JobItem, JobStatus


class JobStore:
    """Manages batch migration job persistence to JSON files.

    Jobs are stored in individual directories under the base path, with each
    job directory containing the job JSON file and backup. The directory
    structure is: `<base_path>/<job-id>/job.json`.

    Attributes:
        base_path: Base directory for job storage.
    """

    def __init__(self, base_path: Path | None = None) -> None:
        """Initialize the JobStore.

        Args:
            base_path: Base directory for job storage. Defaults to
                `.teams-phone/jobs` in the current working directory.
        """
        if base_path is not None:
            self.base_path = base_path
        else:
            self.base_path = Path.cwd() / ".teams-phone" / "jobs"

    def _job_dir(self, job_id: str) -> Path:
        """Get the directory path for a job.

        Args:
            job_id: The unique job identifier.

        Returns:
            Path to the job directory.
        """
        return self.base_path / job_id

    def _job_file(self, job_id: str) -> Path:
        """Get the path to a job's JSON file.

        Args:
            job_id: The unique job identifier.

        Returns:
            Path to the job.json file.
        """
        return self._job_dir(job_id) / "job.json"

    def _backup_file(self, job_id: str) -> Path:
        """Get the path to a job's backup JSON file.

        Args:
            job_id: The unique job identifier.

        Returns:
            Path to the job.json.backup file.
        """
        return self._job_dir(job_id) / "job.json.backup"

    def _lock_file(self) -> Path:
        """Get the path to the job lock file.

        The lock file is used to prevent concurrent job execution. It is
        created in the base jobs directory (not within a specific job).

        Returns:
            Path to the .lock file in the jobs directory.
        """
        return self.base_path / ".lock"

    def _lock_info_file(self) -> Path:
        """Get the path to the lock info JSON file.

        The lock info file contains metadata about the current lock holder:
        job_id, pid, and timestamp. Used for stale lock detection when the
        locking process has crashed.

        Returns:
            Path to the .lock_info.json file in the jobs directory.
        """
        return self.base_path / ".lock_info.json"

    def _acquire_file_lock(self, fd: int) -> None:
        """Acquire an exclusive non-blocking lock on a file descriptor.

        Uses platform-specific locking: msvcrt.locking on Windows and
        fcntl.flock on Unix. The lock is non-blocking and will raise an
        exception immediately if the lock cannot be acquired.

        Args:
            fd: File descriptor to lock.

        Raises:
            OSError: On Windows when lock cannot be acquired (errno 13 or 36).
            BlockingIOError: On Unix when lock cannot be acquired.
        """
        if sys.platform == "win32":
            import msvcrt

            msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
        else:
            import fcntl

            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)

    def _release_file_lock(self, fd: int) -> None:
        """Release a lock on a file descriptor.

        Uses platform-specific unlocking: msvcrt.locking on Windows and
        fcntl.flock on Unix.

        Args:
            fd: File descriptor to unlock.
        """
        if sys.platform == "win32":
            import msvcrt

            msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
        else:
            import fcntl

            fcntl.flock(fd, fcntl.LOCK_UN)

    def _is_process_running(self, pid: int) -> bool:
        """Check if a process with the given PID is currently running.

        On Windows, uses ctypes OpenProcess since os.kill(pid, 0) sends
        CTRL_C_EVENT which kills the calling process. On Unix, uses the
        standard os.kill(pid, 0) signal-0 check.

        Args:
            pid: Process ID to check.

        Returns:
            True if the process is running, False otherwise.
        """
        if sys.platform == "win32":
            import ctypes

            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            handle = ctypes.windll.kernel32.OpenProcess(
                PROCESS_QUERY_LIMITED_INFORMATION, False, pid
            )
            if handle:
                ctypes.windll.kernel32.CloseHandle(handle)
                return True
            return False

        try:
            os.kill(pid, 0)
            return True
        except PermissionError:
            # Process exists but owned by different user
            return True
        except OSError:
            # Process doesn't exist
            return False

    def _read_lock_info(self) -> dict[str, Any] | None:
        """Read and parse the lock info JSON file.

        Returns the lock info dict if the file exists and contains valid JSON
        with the required fields (job_id, pid, started_at). Returns None if
        the file doesn't exist or is malformed.

        Returns:
            Dict with 'job_id', 'pid', 'started_at' keys, or None if unavailable.
        """
        lock_info_file = self._lock_info_file()

        if not lock_info_file.exists():
            return None

        try:
            content = lock_info_file.read_text(encoding="utf-8")
            data: dict[str, Any] = json.loads(content)

            # Validate required fields exist
            if not all(key in data for key in ("job_id", "pid", "started_at")):
                return None

            return data
        except (json.JSONDecodeError, OSError):
            return None

    def _write_lock_info(self, job_id: str) -> None:
        """Write lock info JSON file with current process details.

        Creates a JSON file containing the job_id, current process PID, and
        ISO 8601 timestamp. This file is advisory metadata for debugging and
        stale lock detection.

        Args:
            job_id: The job ID that is acquiring the lock.
        """
        lock_info = {
            "job_id": job_id,
            "pid": os.getpid(),
            "started_at": datetime.now(timezone.utc).isoformat(),
        }

        lock_info_file = self._lock_info_file()

        # Ensure parent directory exists
        lock_info_file.parent.mkdir(parents=True, exist_ok=True)

        lock_info_file.write_text(json.dumps(lock_info, indent=2), encoding="utf-8")

    def get_active_job_id(self) -> str | None:
        """Return active job ID if one is running, None otherwise.

        Checks the lock info file and verifies the locking process is still
        running. Returns None if no lock exists or if the lock is stale.

        Returns:
            The job ID of the currently running job, or None if no active job.
        """
        lock_info = self._read_lock_info()
        if lock_info is None:
            return None

        if self._is_process_running(lock_info["pid"]):
            return str(lock_info["job_id"])

        # Stale lock - process no longer running
        return None

    @contextmanager
    def acquire_lock(self, job_id: str) -> Generator[None, None, None]:
        """Context manager for job lock acquisition.

        Acquires an exclusive lock to prevent concurrent job execution.
        Checks for stale locks from crashed processes and cleans them up.
        On normal or exception exit, releases the lock and cleans up files.

        Args:
            job_id: The job ID that is acquiring the lock.

        Yields:
            None - the context manager provides no value.

        Raises:
            JobLockError: If lock cannot be acquired (another job is running).
        """
        # Ensure base path exists
        self.base_path.mkdir(parents=True, exist_ok=True)
        lock_path = self._lock_file()

        # Check for stale lock
        existing_info = self._read_lock_info()
        if existing_info is not None:
            if self._is_process_running(existing_info["pid"]):
                raise JobLockError(existing_info["job_id"])
            # Stale lock - clean up
            self._lock_info_file().unlink(missing_ok=True)
            lock_path.unlink(missing_ok=True)

        # Acquire file lock
        lock_fd = open(lock_path, "wb")  # noqa: SIM115
        try:
            self._acquire_file_lock(lock_fd.fileno())
        except (OSError, BlockingIOError) as err:
            lock_fd.close()
            # Re-read lock info in case another process just acquired it
            existing = self._read_lock_info()
            active_id = existing["job_id"] if existing else "unknown"
            raise JobLockError(active_id) from err

        # Write lock info
        self._write_lock_info(job_id)

        try:
            yield
        finally:
            # Cleanup: release lock, close file, delete files
            self._release_file_lock(lock_fd.fileno())
            lock_fd.close()
            self._lock_info_file().unlink(missing_ok=True)
            lock_path.unlink(missing_ok=True)

    def _atomic_write(self, path: Path, content: str) -> None:
        """Atomic write with fsync: write to tmp, backup current, rename.

        Provides crash-safe persistence by:
        1. Writing to .tmp file first
        2. Calling fsync to ensure data is on disk
        3. Copying current file (if exists) to .backup (preserves original until new is in place)
        4. Atomic rename from .tmp to target
        5. Fsync parent directory (Unix only) for rename durability

        Cross-platform notes:
            - Windows: Path.replace() uses os.replace() for atomic rename on same volume
            - Unix: rename() is atomic per POSIX; directory fsync ensures durability
            - Backup uses copy (not rename) to preserve original until new file is in place

        Args:
            path: Target file path to write.
            content: String content to write.

        Raises:
            ConfigurationError: If file operations fail due to permission or I/O errors.
        """
        tmp_path = path.parent / (path.name + ".tmp")
        backup_path = path.parent / (path.name + ".backup")

        try:
            # Write content to temporary file
            tmp_path.write_text(content, encoding="utf-8")

            # Fsync to ensure data is on disk before rename
            with tmp_path.open("ab") as f:
                os.fsync(f.fileno())

            # Backup existing file if it exists (copy, not rename, to preserve original)
            if path.exists():
                shutil.copy2(path, backup_path)

            # Atomic rename from tmp to target
            tmp_path.replace(path)

            # Fsync parent directory for rename durability (Unix only)
            if hasattr(os, "O_DIRECTORY"):
                dir_fd = os.open(path.parent, os.O_DIRECTORY)
                try:
                    os.fsync(dir_fd)
                finally:
                    os.close(dir_fd)

        except OSError as e:
            # Clean up tmp file if it exists
            if tmp_path.exists():
                with contextlib.suppress(OSError):
                    tmp_path.unlink()
            raise ConfigurationError(
                f"Failed to write file {path}: {e}",
                remediation=(
                    f"Check that you have write permissions to {path.parent}.\n"
                    "Ensure the disk has sufficient space and is not read-only."
                ),
            ) from e

    def _generate_job_id(self, name: str) -> str:
        """Generate a unique job ID with timestamp, random suffix, and name slug.

        Format: YYYYMMDD-HHMMSS-{random4hex}-{name-slug}
        Example: 20260203-143015-a1b2-q1-migration

        The name is slugified by:
        - Converting to lowercase
        - Replacing non-alphanumeric sequences with single dashes
        - Stripping leading/trailing dashes
        - Truncating to 30 characters

        Args:
            name: Human-readable job name to slugify.

        Returns:
            Unique job ID string.
        """
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
        random_suffix = secrets.token_hex(2)  # 4 hex chars
        slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:30]
        return f"{timestamp}-{random_suffix}-{slug}"

    def create_job(
        self, name: str, input_file: Path, items: list[dict[str, Any]]
    ) -> Job:
        """Create a new job from parsed CSV items.

        Generates a unique job ID, creates the job directory, copies the input
        CSV file for preservation, computes a SHA-256 hash of the input file,
        and creates a Job instance with all items.

        Args:
            name: Human-readable job name for display/identification.
            input_file: Path to the original CSV file.
            items: List of dicts from CSV parser, each dict becomes a JobItem.
                Each dict must contain: line_number, user_upn, phone_number.

        Returns:
            The created and persisted Job instance.

        Raises:
            ConfigurationError: If job directory cannot be created due to
                permission error.
        """
        job_id = self._generate_job_id(name)
        job_dir = self._job_dir(job_id)

        # Create job directory
        try:
            job_dir.mkdir(parents=True, exist_ok=True)
        except PermissionError as e:
            raise ConfigurationError(
                f"Cannot create job directory {job_dir}: {e}",
                remediation=(
                    f"Check that you have write permissions to {job_dir.parent}.\n"
                    "You may need to create the directory manually or run with "
                    "elevated privileges."
                ),
            ) from e

        # Copy input CSV to job directory
        input_copy_path = job_dir / "input.csv"
        shutil.copy2(input_file, input_copy_path)

        # Compute SHA-256 hash of input file
        input_hash = hashlib.sha256(input_file.read_bytes()).hexdigest()

        # Create Job instance
        now = datetime.now(timezone.utc)
        job = Job(
            id=job_id,
            name=name,
            status=JobStatus.CREATED,
            created_at=now,
            updated_at=now,
            input_file=str(input_file),
            input_hash=input_hash,
            items=[JobItem(**item) for item in items],
        )

        # Persist job to disk
        self.save_job(job)

        return job

    def save_job(self, job: Job) -> None:
        """Persist a job to its JSON file using atomic write.

        Updates the job's `updated_at` timestamp and writes the job state
        to disk using the atomic write pattern for crash-safe persistence.

        Args:
            job: The Job instance to save.

        Raises:
            ConfigurationError: If file operations fail due to permission or I/O errors.
        """
        job.updated_at = datetime.now(timezone.utc)
        content = job.model_dump_json(indent=2)
        self._atomic_write(self._job_file(job.id), content)

    # Computed fields that must be stripped when loading JSON
    # (Job model uses extra="forbid", but model_dump_json includes these)
    _COMPUTED_FIELDS = frozenset(
        {
            "total_count",
            "succeeded_count",
            "failed_count",
            "pending_count",
            "duration",
        }
    )

    def _load_job_from_file(self, file_path: Path) -> Job:
        """Load and validate a Job from a JSON file.

        Parses the JSON, strips computed fields (which are serialized but
        cause validation errors due to extra="forbid"), and validates.

        Args:
            file_path: Path to the job.json or backup file.

        Returns:
            Validated Job instance.

        Raises:
            json.JSONDecodeError: If file contains invalid JSON.
            PydanticValidationError: If data fails Job model validation.
        """
        content = file_path.read_text(encoding="utf-8")
        data = json.loads(content)

        # Strip computed fields that would fail validation
        for field in self._COMPUTED_FIELDS:
            data.pop(field, None)

        return Job.model_validate(data)

    def load_job(self, job_id: str) -> Job:
        """Load a job from its JSON file with automatic backup recovery.

        Attempts to load from the main job.json file. If that fails due to
        corruption (invalid JSON or validation error), falls back to the
        backup file. If backup recovery succeeds, restores the main file
        from the backup.

        Args:
            job_id: The unique job identifier.

        Returns:
            The loaded Job instance.

        Raises:
            NotFoundError: If job directory or both main and backup files
                don't exist.
            ConfigurationError: If both main and backup files are corrupted.
        """
        job_file = self._job_file(job_id)
        backup_file = self._backup_file(job_id)

        # Check if job directory exists
        job_dir = self._job_dir(job_id)
        if not job_dir.exists():
            raise NotFoundError(
                f"Job '{job_id}' not found",
                remediation="Run 'teams-phone batch jobs list' to see existing jobs.",
            )

        # Try loading from main file first
        main_error: Exception | None = None
        if job_file.exists():
            try:
                return self._load_job_from_file(job_file)
            except (json.JSONDecodeError, PydanticValidationError) as e:
                main_error = e

        # Try loading from backup
        if backup_file.exists():
            try:
                job = self._load_job_from_file(backup_file)
                # Restore main file from backup after successful recovery
                logging.warning(
                    "Recovered job '%s' from backup file (main file was corrupted)",
                    job_id,
                )
                shutil.copy2(backup_file, job_file)
                return job
            except (json.JSONDecodeError, PydanticValidationError):
                # Both files are corrupted
                raise ConfigurationError(
                    f"Job '{job_id}' is corrupted: both main and backup files are invalid",
                    remediation=(
                        f"The job files at {job_dir} are corrupted.\n"
                        "You may need to manually inspect and repair the files, "
                        "or delete the job and create a new one."
                    ),
                ) from main_error

        # Neither main nor backup exists
        if main_error is not None:
            # Main was corrupted, no backup
            raise ConfigurationError(
                f"Job '{job_id}' is corrupted and no backup exists",
                remediation=(
                    f"The job file at {job_file} is corrupted with no backup.\n"
                    "You may need to delete the job and create a new one."
                ),
            ) from main_error

        # Job directory exists but no files
        raise NotFoundError(
            f"Job '{job_id}' has no job file",
            remediation=(
                f"The job directory {job_dir} exists but contains no job.json.\n"
                "The job may have been partially deleted."
            ),
        )

    def list_jobs(self) -> list[Job]:
        """List all jobs sorted by creation date descending.

        Iterates through job directories, loads each job, and returns them
        sorted with newest first. Hidden directories (starting with '.') are
        skipped. Corrupted jobs are logged to stderr but don't prevent other
        jobs from loading.

        Returns:
            List of Job instances sorted by created_at descending (newest first).
            Returns empty list if base_path doesn't exist or contains no jobs.
        """
        if not self.base_path.exists():
            return []

        jobs: list[Job] = []

        for entry in self.base_path.iterdir():
            # Skip non-directories and hidden directories
            if not entry.is_dir() or entry.name.startswith("."):
                continue

            try:
                job = self.load_job(entry.name)
                jobs.append(job)
            except (NotFoundError, ConfigurationError) as e:
                # Log warning to stderr and continue
                sys.stderr.write(f"Warning: Failed to load job '{entry.name}': {e}\n")

        # Sort by created_at descending (newest first)
        return sorted(jobs, key=lambda j: j.created_at, reverse=True)

    def delete_job(self, job_id: str) -> None:
        """Delete a job and its entire directory.

        Removes the job directory and all its contents (job.json, backup,
        input.csv).

        Args:
            job_id: The unique job identifier.

        Raises:
            NotFoundError: If job directory doesn't exist.
        """
        job_dir = self._job_dir(job_id)

        if not job_dir.exists():
            raise NotFoundError(
                f"Job '{job_id}' not found",
                remediation="Run 'teams-phone batch jobs list' to see existing jobs.",
            )

        shutil.rmtree(job_dir)
