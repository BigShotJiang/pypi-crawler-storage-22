"""Pydantic models for API responses and domain objects."""

from teams_phone.models.api_responses import (
    GraphErrorDetail,
    GraphErrorResponse,
    GraphListResponse,
)
from teams_phone.models.auth import (
    AuthStatus,
    AuthStatusType,
    CachedToken,
    ConnectionTestResult,
)
from teams_phone.models.batch import (
    ItemStatus,
    Job,
    JobItem,
    JobStatus,
)
from teams_phone.models.cache import CacheMetadata
from teams_phone.models.config import CacheSettings, Config, NetworkSettings
from teams_phone.models.location import EmergencyLocation
from teams_phone.models.number import (
    ActivationState,
    AssignmentCategory,
    AssignmentStatus,
    AsyncOperation,
    NumberAssignment,
    NumberType,
    OperationNumber,
    OperationStatus,
)
from teams_phone.models.policy import Policy
from teams_phone.models.tenant import AuthMethod, TenantProfile
from teams_phone.models.user import (
    AccountType,
    EffectivePolicyAssignment,
    PolicyAssignmentDetail,
    TelephoneNumber,
    UserConfiguration,
)


__all__ = [
    # API response models
    "GraphErrorDetail",
    "GraphErrorResponse",
    "GraphListResponse",
    # Auth models
    "AuthStatus",
    "AuthStatusType",
    "CachedToken",
    "ConnectionTestResult",
    # Batch models
    "ItemStatus",
    "Job",
    "JobItem",
    "JobStatus",
    # Cache models
    "CacheMetadata",
    # Config models
    "CacheSettings",
    "Config",
    "NetworkSettings",
    # Number models
    "ActivationState",
    "AssignmentCategory",
    "AssignmentStatus",
    "AsyncOperation",
    "NumberAssignment",
    "NumberType",
    "OperationNumber",
    "OperationStatus",
    # Location models
    "EmergencyLocation",
    # Policy models
    "Policy",
    # Tenant models
    "AuthMethod",
    "TenantProfile",
    # User models
    "AccountType",
    "EffectivePolicyAssignment",
    "PolicyAssignmentDetail",
    "TelephoneNumber",
    "UserConfiguration",
]
