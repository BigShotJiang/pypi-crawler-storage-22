"""Batch migration job models for tracking phone number assignment operations.

These models represent the internal job state for batch phone number migrations.
Jobs persist to disk as JSON and track progress across interrupted sessions.
All models use `extra="forbid"` for strict validation.
"""

from datetime import datetime, timedelta
from enum import Enum

from pydantic import BaseModel, ConfigDict, computed_field


class JobStatus(str, Enum):
    """Batch job lifecycle status.

    Attributes:
        CREATED: Job initialized but not yet validated.
        VALIDATING: Input CSV being validated against Graph API.
        VALIDATED: All users and numbers verified, ready to run.
        RUNNING: Actively processing phone number assignments.
        COMPLETED: All items processed (may include failures).
        INTERRUPTED: Execution stopped by user or error, can resume.
    """

    CREATED = "created"
    VALIDATING = "validating"
    VALIDATED = "validated"
    RUNNING = "running"
    COMPLETED = "completed"
    INTERRUPTED = "interrupted"


class ItemStatus(str, Enum):
    """Individual job item status.

    Attributes:
        PENDING: Not yet processed.
        IN_PROGRESS: Currently being processed.
        SUCCEEDED: Phone number assigned successfully.
        FAILED: Assignment failed after all retry attempts.
        NEEDS_REVIEW: Requires manual intervention (e.g., user already has number).
    """

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    NEEDS_REVIEW = "needs_review"


class JobItem(BaseModel):
    """A single row from the input CSV being processed.

    Attributes:
        line_number: 1-indexed line number from the input CSV.
        user_upn: User principal name (email) from the CSV.
        phone_number: Phone number to assign in E.164 format.
        status: Current processing status of this item.
        attempts: Number of assignment attempts made.
        error_code: Error code from last failed attempt.
        error_message: Human-readable error description.
        completed_at: Timestamp when processing finished.
    """

    model_config = ConfigDict(extra="forbid")

    line_number: int
    user_upn: str
    phone_number: str
    status: ItemStatus = ItemStatus.PENDING
    attempts: int = 0
    error_code: str | None = None
    error_message: str | None = None
    completed_at: datetime | None = None


class Job(BaseModel):
    """Batch migration job tracking phone number assignments.

    Attributes:
        id: Unique job identifier (format: YYYYMMDD-HHMMSS-{hex4}-{name-slug}).
        name: Human-readable job name from user.
        status: Current job lifecycle status.
        created_at: Timestamp when job was created.
        updated_at: Timestamp of last modification.
        started_at: Timestamp when execution first began.
        completed_at: Timestamp when job finished (success or all retries done).
        input_file: Path to the input CSV file.
        input_hash: SHA-256 hash of input CSV contents for change detection.
        items: List of job items being processed.
    """

    model_config = ConfigDict(extra="forbid")

    id: str
    name: str
    status: JobStatus
    created_at: datetime
    updated_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None
    input_file: str
    input_hash: str
    items: list[JobItem]

    @computed_field  # type: ignore[prop-decorator]
    @property
    def total_count(self) -> int:
        """Total number of items in the job."""
        return len(self.items)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def succeeded_count(self) -> int:
        """Number of items that completed successfully."""
        return sum(1 for item in self.items if item.status == ItemStatus.SUCCEEDED)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def failed_count(self) -> int:
        """Number of items that failed permanently."""
        return sum(1 for item in self.items if item.status == ItemStatus.FAILED)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def pending_count(self) -> int:
        """Number of items not yet processed."""
        return sum(1 for item in self.items if item.status == ItemStatus.PENDING)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def duration(self) -> timedelta | None:
        """Elapsed time from start to completion, or None if not completed."""
        if self.started_at is None or self.completed_at is None:
            return None
        return self.completed_at - self.started_at
