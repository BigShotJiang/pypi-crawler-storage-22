"""Batch CSV parser with BOM and line ending handling.

Provides core CSV parsing functionality for batch migration jobs, including
UTF-8 BOM stripping, line ending normalization, and SHA-256 hash computation
for input file tracking.
"""

from __future__ import annotations

import csv
import hashlib
import io
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from teams_phone.exceptions import ValidationError
from teams_phone.models.batch import ItemStatus
from teams_phone.utils import normalize_phone_number


@dataclass
class CSVValidationError:
    """A validation error for a specific field in a CSV row.

    Attributes:
        line_number: 1-indexed line number in the CSV file.
        field: Name of the field that failed validation.
        value: The invalid value that was found.
        message: Human-readable error message.
        suggested_fix: Optional suggestion for how to fix the error.
    """

    line_number: int
    field: str
    value: str
    message: str
    suggested_fix: str | None = None


@dataclass
class CSVParseResult:
    """Result of parsing a batch CSV file.

    Attributes:
        items: List of validated item dictionaries with line_number, user_upn,
            phone_number (E.164), status (ItemStatus.PENDING), and attempts (0).
        warnings: List of warning messages encountered during parsing.
        input_hash: SHA-256 hash of the raw input file for tracking.
    """

    items: list[dict[str, Any]]
    warnings: list[str] = field(default_factory=list)
    input_hash: str = ""


def _validate_headers(
    fieldnames: list[str] | None,
) -> tuple[dict[str, str], str, str]:
    """Validate CSV headers and return header mapping with column names.

    Args:
        fieldnames: List of header names from csv.DictReader.

    Returns:
        Tuple of (normalized_headers dict, upn_header, phone_header).

    Raises:
        ValidationError: If required headers are missing.
    """
    required_columns = {"user_upn", "phone_number"}

    if fieldnames is None:
        raise ValidationError(
            "CSV file has no header row",
            remediation="Provide a CSV file with a header row containing "
            "'user_upn' and 'phone_number' columns.",
        )

    # Normalize headers to lowercase and strip whitespace
    normalized_headers = {h.lower().strip(): h for h in fieldnames}
    header_columns = set(normalized_headers.keys())
    missing_columns = required_columns - header_columns

    if missing_columns:
        raise ValidationError(
            f"CSV missing required columns: {', '.join(sorted(missing_columns))}",
            remediation="Ensure the CSV header includes 'user_upn' and "
            "'phone_number' columns.",
        )

    return (
        normalized_headers,
        normalized_headers["user_upn"],
        normalized_headers["phone_number"],
    )


def _validate_row(
    line_number: int,
    row: dict[str, str],
    upn_header: str,
    phone_header: str,
    errors: list[CSVValidationError],
    warnings: list[str],
) -> dict[str, Any] | None:
    """Validate a single CSV row and return validated item dict or None.

    Args:
        line_number: 1-indexed line number for error reporting.
        row: Row data from csv.DictReader.
        upn_header: Original header name for user_upn column.
        phone_header: Original header name for phone_number column.
        errors: List to append validation errors to.
        warnings: List to append warnings to.

    Returns:
        Validated item dict, or None if validation failed.
    """
    # Extract and normalize user_upn
    raw_upn = row.get(upn_header, "")
    upn = raw_upn.strip().lower() if raw_upn else ""

    # Extract phone_number
    raw_phone = row.get(phone_header, "")
    phone = raw_phone.strip() if raw_phone else ""

    # Validate required fields are not empty
    if not upn:
        errors.append(
            CSVValidationError(
                line_number=line_number,
                field="user_upn",
                value=raw_upn,
                message="Missing required field: user_upn",
                suggested_fix="Provide a valid user principal name (email address).",
            )
        )

    if not phone:
        errors.append(
            CSVValidationError(
                line_number=line_number,
                field="phone_number",
                value=raw_phone,
                message="Missing required field: phone_number",
                suggested_fix="Provide a valid phone number in E.164 format.",
            )
        )

    # Skip further validation if required fields are empty
    if not upn or not phone:
        return None

    # Strip phone extension (;ext=NNN) - case insensitive
    if ";ext=" in phone.lower():
        phone = re.split(r";ext=", phone, flags=re.IGNORECASE)[0]
        warnings.append(
            f"Line {line_number}: Phone extension stripped from '{raw_phone}'"
        )

    # Normalize and validate phone number
    try:
        normalized_digits = normalize_phone_number(phone)
        phone_e164 = f"+{normalized_digits}"
    except ValidationError:
        errors.append(
            CSVValidationError(
                line_number=line_number,
                field="phone_number",
                value=phone,
                message=f"Invalid phone number format: '{phone}'",
                suggested_fix="Provide a valid phone number with at least "
                "10 digits (e.g., +12065551234).",
            )
        )
        return None

    return {
        "line_number": line_number,
        "user_upn": upn,
        "phone_number": phone_e164,
        "status": ItemStatus.PENDING,
        "attempts": 0,
    }


def _check_duplicates(
    item: dict[str, Any],
    line_number: int,
    seen_phones: dict[str, int],
    seen_users: dict[str, int],
    errors: list[CSVValidationError],
) -> bool:
    """Check for duplicate phone numbers and UPNs, tracking first occurrence.

    Args:
        item: Validated item dict with phone_number and user_upn.
        line_number: Current line number for error reporting.
        seen_phones: Dict mapping phone numbers to first seen line number.
        seen_users: Dict mapping UPNs to first seen line number.
        errors: List to append duplicate errors to.

    Returns:
        True if item is unique (no duplicates), False if duplicate found.
    """
    phone_e164 = item["phone_number"]
    if phone_e164 in seen_phones:
        errors.append(
            CSVValidationError(
                line_number=line_number,
                field="phone_number",
                value=phone_e164,
                message=f"Duplicate phone number (first seen at line {seen_phones[phone_e164]})",
            )
        )
        return False
    seen_phones[phone_e164] = line_number

    user_upn = item["user_upn"]
    if user_upn in seen_users:
        errors.append(
            CSVValidationError(
                line_number=line_number,
                field="user_upn",
                value=user_upn,
                message=f"Duplicate user assignment (first seen at line {seen_users[user_upn]})",
            )
        )
        return False
    seen_users[user_upn] = line_number

    return True


def _format_validation_errors(errors: list[CSVValidationError]) -> str:
    """Format validation errors for display, limiting to first 10.

    Args:
        errors: List of CSVValidationError objects.

    Returns:
        Formatted error summary string.
    """
    error_messages = [
        f"Line {err.line_number}: {err.field} - {err.message}" for err in errors
    ]
    displayed_errors = error_messages[:10]
    total_errors = len(errors)
    error_summary = f"CSV validation failed with {total_errors} error(s):\n"
    error_summary += "\n".join(displayed_errors)
    if total_errors > 10:
        error_summary += f"\n... and {total_errors - 10} more error(s)"
    return error_summary


def parse_batch_csv(file_path: Path) -> CSVParseResult:
    """Parse a batch migration CSV file.

    Reads a CSV file with support for:
    - UTF-8 BOM stripping (handles PowerShell exports)
    - Line ending normalization (CRLF, LF, CR all converted to LF)
    - SHA-256 hash computation for input tracking

    Args:
        file_path: Path to the CSV file to parse.

    Returns:
        CSVParseResult containing parsed items, warnings, and input hash.

    Raises:
        ValidationError: If the file doesn't exist or is empty.

    Note:
        Uses 'utf-8-sig' encoding to automatically strip UTF-8 BOM if present.
        Line endings are normalized before parsing to ensure cross-platform
        compatibility.
    """
    if not file_path.exists():
        raise ValidationError(
            f"CSV file not found: {file_path}",
            remediation="Ensure the file path is correct and the file exists.",
        )

    # Read raw bytes for hash computation
    raw_bytes = file_path.read_bytes()

    # Check for empty file before computing hash
    if len(raw_bytes) == 0:
        raise ValidationError(
            "CSV file is empty",
            remediation="Provide a CSV file with a header row and at least one data row.",
        )

    # Compute SHA-256 hash of raw input
    input_hash = hashlib.sha256(raw_bytes).hexdigest()

    # Decode with BOM stripping
    text = raw_bytes.decode("utf-8-sig")

    # Normalize line endings: CRLF -> LF, then CR -> LF
    text = text.replace("\r\n", "\n").replace("\r", "\n")

    # Split into lines and check for content
    lines = text.split("\n")

    # Remove trailing empty line if present (from final newline)
    if lines and lines[-1] == "":
        lines = lines[:-1]

    # Check if file has only whitespace or no content after BOM strip
    if not lines or all(line.strip() == "" for line in lines):
        raise ValidationError(
            "CSV file is empty",
            remediation="Provide a CSV file with a header row and at least one data row.",
        )

    # Use csv.DictReader with the normalized text
    reader = csv.DictReader(io.StringIO("\n".join(lines)))

    # Validate headers and get column mappings
    _, upn_header, phone_header = _validate_headers(
        list(reader.fieldnames) if reader.fieldnames else None
    )

    # Parse and validate all rows
    items: list[dict[str, Any]] = []
    errors: list[CSVValidationError] = []
    warnings: list[str] = []

    # Track seen values for duplicate detection (value -> first line number)
    seen_phones: dict[str, int] = {}
    seen_users: dict[str, int] = {}

    try:
        # Row number starts at 2 (1-indexed, accounting for header row)
        for line_number, row in enumerate(reader, start=2):
            item = _validate_row(
                line_number, row, upn_header, phone_header, errors, warnings
            )
            if item is None:
                continue

            # Check for duplicates and skip if found
            if not _check_duplicates(
                item, line_number, seen_phones, seen_users, errors
            ):
                continue

            items.append(item)

    except csv.Error as e:
        raise ValidationError(
            f"CSV parsing error: {e}",
            remediation="Check the CSV file for formatting issues such as "
            "unbalanced quotes or invalid characters.",
        ) from e

    # If there were validation errors, raise with formatted error list
    if errors:
        raise ValidationError(
            _format_validation_errors(errors),
            remediation="Fix the reported errors and try again.",
        )

    return CSVParseResult(
        items=items,
        warnings=warnings,
        input_hash=input_hash,
    )
