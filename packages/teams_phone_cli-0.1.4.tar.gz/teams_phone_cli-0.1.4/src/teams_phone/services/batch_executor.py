"""Batch executor for processing phone number assignment jobs.

This module provides the BatchExecutor class for executing batch migration
jobs with configurable concurrency using asyncio semaphore-based control.
"""

from __future__ import annotations

import asyncio
import json
import signal
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from types import FrameType
from typing import TYPE_CHECKING, Any

from teams_phone.exceptions import NotFoundError, ValidationError
from teams_phone.infrastructure.job_store import JobStore
from teams_phone.models import OperationStatus
from teams_phone.models.batch import ItemStatus, Job, JobItem, JobStatus


if TYPE_CHECKING:
    from teams_phone.services.number_service import NumberService
    from teams_phone.services.user_service import UserService


class ExecutionLogger:
    """Writes structured JSON Lines execution logs for batch jobs.

    Each log entry is a single JSON object on its own line (JSON Lines format).
    All entries include an ISO 8601 UTC timestamp and an event type.

    Args:
        log_path: Path to the execution.log file.
    """

    def __init__(self, log_path: Path) -> None:
        self.log_path = log_path
        self.log_path.touch()

    def _write_event(self, event_type: str, data: dict[str, Any]) -> None:
        """Write a single JSON Lines entry to the log file.

        Args:
            event_type: The event type identifier.
            data: Additional key-value pairs for the log entry.
        """
        entry: dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "event": event_type,
            **data,
        }
        with self.log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")

    def log_start(self, job_id: str, total_items: int, concurrency: int) -> None:
        """Log the start of a batch execution.

        Args:
            job_id: The unique job identifier.
            total_items: Total number of items to process.
            concurrency: Concurrency level for this execution.
        """
        self._write_event(
            "execution_start",
            {
                "job_id": job_id,
                "total_items": total_items,
                "concurrency": concurrency,
            },
        )

    def log_item_start(
        self,
        line_number: int,
        user_upn: str,
        phone_number: str,
        attempt: int,
    ) -> None:
        """Log the start of processing a single item.

        Args:
            line_number: CSV line number of the item.
            user_upn: User principal name being processed.
            phone_number: Phone number being assigned.
            attempt: Current attempt number.
        """
        self._write_event(
            "item_start",
            {
                "line_number": line_number,
                "user_upn": user_upn,
                "phone_number": phone_number,
                "attempt": attempt,
            },
        )

    def log_item_complete(
        self,
        line_number: int,
        user_upn: str,
        phone_number: str,
        status: str,
        duration_ms: int,
        error_code: str | None = None,
        error_message: str | None = None,
        api_response: dict[str, Any] | None = None,
    ) -> None:
        """Log the completion of processing a single item.

        Args:
            line_number: CSV line number of the item.
            user_upn: User principal name processed.
            phone_number: Phone number assigned.
            status: Final status of the item.
            duration_ms: Processing duration in milliseconds.
            error_code: Error code if the item failed.
            error_message: Error description if the item failed.
            api_response: Raw API response data (reserved for future use).
        """
        data: dict[str, Any] = {
            "line_number": line_number,
            "user_upn": user_upn,
            "phone_number": phone_number,
            "status": status,
            "duration_ms": duration_ms,
        }
        if error_code is not None:
            data["error_code"] = error_code
        if error_message is not None:
            data["error_message"] = error_message
        if api_response is not None:
            data["api_response"] = api_response
        self._write_event("item_complete", data)

    def log_end(
        self,
        job_id: str,
        status: str,
        succeeded: int,
        failed: int,
        total_duration_ms: int,
    ) -> None:
        """Log the end of a batch execution.

        Args:
            job_id: The unique job identifier.
            status: Final job status.
            succeeded: Number of items that succeeded.
            failed: Number of items that failed.
            total_duration_ms: Total execution duration in milliseconds.
        """
        self._write_event(
            "execution_end",
            {
                "job_id": job_id,
                "status": status,
                "succeeded": succeeded,
                "failed": failed,
                "total_duration_ms": total_duration_ms,
            },
        )


@dataclass
class ExecutionProgress:
    """Progress snapshot during batch job execution.

    Attributes:
        total: Total number of items to process.
        completed: Number of items processed so far.
        succeeded: Number of items that succeeded.
        failed: Number of items that failed.
        current_item: Description of the item currently being processed.
    """

    total: int
    completed: int
    succeeded: int
    failed: int
    current_item: str | None


class BatchExecutor:
    """Executes batch migration jobs with concurrency control.

    Processes job items concurrently using an asyncio semaphore to limit
    the number of simultaneous Graph API calls. Concurrency is clamped
    to 1-10 to avoid overwhelming the Graph API.

    Attributes:
        user_service: UserService instance for user resolution.
        number_service: NumberService instance for number assignment.
        job_store: JobStore instance for persisting job state.
        concurrency: Number of concurrent operations (1-10).
        dry_run: If True, simulate execution without making changes.
        timeout: Maximum execution time in seconds.
    """

    def __init__(
        self,
        user_service: UserService,
        number_service: NumberService,
        job_store: JobStore,
        concurrency: int = 3,
        dry_run: bool = False,
        timeout: int = 600,
    ) -> None:
        """Initialize the BatchExecutor.

        Args:
            user_service: UserService instance for user resolution.
            number_service: NumberService instance for number assignment.
            job_store: JobStore instance for persisting job state.
            concurrency: Number of concurrent operations (default 3, clamped 1-10).
            dry_run: If True, simulate execution without making changes.
            timeout: Maximum execution time in seconds.
        """
        self.user_service = user_service
        self.number_service = number_service
        self.job_store = job_store
        self.concurrency = min(max(1, concurrency), 10)
        self.dry_run = dry_run
        self.timeout = timeout
        self._semaphore: asyncio.Semaphore | None = None
        self._interrupted: bool = False
        self._original_sigint_handler: (
            Callable[[int, FrameType | None], Any] | int | None
        ) = signal.SIG_DFL

    def _setup_signal_handlers(self) -> None:
        """Register a SIGINT handler for graceful interruption.

        Saves the original handler so it can be restored after execution.
        The new handler sets ``_interrupted`` to ``True``, which causes the
        processing loop to stop picking up new items.
        """

        def handler(signum: int, frame: FrameType | None) -> None:
            self._interrupted = True

        self._original_sigint_handler = signal.signal(signal.SIGINT, handler)

    def _restore_signal_handlers(self) -> None:
        """Restore the original SIGINT handler saved during setup."""
        signal.signal(signal.SIGINT, self._original_sigint_handler)

    @staticmethod
    def _report_progress(
        on_progress: Callable[[ExecutionProgress], None],
        job: Job,
        current_item: str,
    ) -> None:
        """Calculate and report execution progress via the callback.

        Args:
            on_progress: The progress callback function.
            job: The job to calculate progress from.
            current_item: UPN of the item just completed.
        """
        completed = sum(
            1
            for i in job.items
            if i.status
            in (ItemStatus.SUCCEEDED, ItemStatus.FAILED, ItemStatus.NEEDS_REVIEW)
        )
        on_progress(
            ExecutionProgress(
                total=len(job.items),
                completed=completed,
                succeeded=job.succeeded_count,
                failed=job.failed_count,
                current_item=current_item,
            )
        )

    async def _process_item(
        self,
        item: JobItem,
        job: Job,
        semaphore: asyncio.Semaphore,
        logger: ExecutionLogger | None,
        on_progress: Callable[[ExecutionProgress], None] | None,
    ) -> None:
        """Process a single job item with concurrency control.

        Acquires the semaphore, performs the assignment (or dry-run
        simulation), persists state, writes to the execution log, and
        invokes the progress callback.

        Args:
            item: The job item to process.
            job: The parent job (for state persistence and progress).
            semaphore: Semaphore for concurrency control.
            logger: ExecutionLogger for structured JSON Lines logging.
            on_progress: Optional progress callback.
        """
        if self._interrupted:
            return
        async with semaphore:
            if self._interrupted:
                return
            if not self.dry_run:
                item.status = ItemStatus.IN_PROGRESS
                item.attempts += 1
                self.job_store.save_job(job)  # Persist before API call

                assert logger is not None
                logger.log_item_start(
                    line_number=item.line_number,
                    user_upn=item.user_upn,
                    phone_number=item.phone_number,
                    attempt=item.attempts,
                )

            start = time.monotonic()
            try:
                if self.dry_run:
                    await asyncio.sleep(0.1)
                    item.status = ItemStatus.SUCCEEDED
                else:
                    await self._assign_number(item, job)
            except Exception as e:
                item.status = ItemStatus.FAILED
                item.error_code = "BATCH_007"
                item.error_message = str(e)
                if item.attempts >= 3:
                    item.status = ItemStatus.NEEDS_REVIEW
            duration_ms = int((time.monotonic() - start) * 1000)

            if not self.dry_run:
                item.completed_at = datetime.now(timezone.utc)
                self.job_store.save_job(job)  # Persist after completion

                assert logger is not None
                logger.log_item_complete(
                    line_number=item.line_number,
                    user_upn=item.user_upn,
                    phone_number=item.phone_number,
                    status=item.status.value,
                    duration_ms=duration_ms,
                    error_code=item.error_code,
                    error_message=item.error_message,
                )
            if on_progress is not None:
                self._report_progress(on_progress, job, item.user_upn)

    async def execute_job(
        self,
        job: Job,
        *,
        on_progress: Callable[[ExecutionProgress], None] | None = None,
    ) -> Job:
        """Execute a batch migration job.

        Creates a semaphore for concurrency control, filters items that
        need processing (PENDING or IN_PROGRESS), and processes them
        concurrently. Persists state before and after each item for
        crash safety.

        Registers a SIGINT handler for graceful interruption. The original
        handler is restored after execution completes.

        Args:
            job: The batch job to execute.
            on_progress: Optional callback invoked after each item completes
                with an ExecutionProgress snapshot.

        Returns:
            The updated job with processed item statuses.
        """
        self._interrupted = False

        items_to_process = [
            item
            for item in job.items
            if item.status in (ItemStatus.PENDING, ItemStatus.IN_PROGRESS)
        ]

        if not items_to_process:
            return job

        self._setup_signal_handlers()
        try:
            self._semaphore = asyncio.Semaphore(self.concurrency)

            logger: ExecutionLogger | None = None
            if not self.dry_run:
                # Transition job to RUNNING
                job.status = JobStatus.RUNNING
                if job.started_at is None:
                    job.started_at = datetime.now(timezone.utc)
                self.job_store.save_job(job)

                # Initialize execution logger (append mode for resume support)
                log_path = self.job_store._job_dir(job.id) / "execution.log"
                logger = ExecutionLogger(log_path)
                logger.log_start(
                    job_id=job.id,
                    total_items=len(job.items),
                    concurrency=self.concurrency,
                )

            job_start = time.monotonic()
            tasks = [
                self._process_item(item, job, self._semaphore, logger, on_progress)
                for item in items_to_process
            ]
            await asyncio.gather(*tasks, return_exceptions=True)

            if not self.dry_run:
                # Set final job status
                if self._interrupted:
                    job.status = JobStatus.INTERRUPTED
                else:
                    job.status = JobStatus.COMPLETED
                job.completed_at = datetime.now(timezone.utc)
                self.job_store.save_job(job)

                total_duration_ms = int((time.monotonic() - job_start) * 1000)
                assert logger is not None
                logger.log_end(
                    job_id=job.id,
                    status=job.status.value,
                    succeeded=job.succeeded_count,
                    failed=job.failed_count,
                    total_duration_ms=total_duration_ms,
                )

            return job
        finally:
            self._restore_signal_handlers()

    async def _assign_number(self, item: JobItem, job: Job) -> None:
        """Assign a phone number to a user via Graph API.

        Performs runtime re-validation (TOCTOU protection) by resolving the
        user and checking number availability before assignment. Handles
        idempotent detection when the number is already assigned to the
        target user.

        All known error types are caught and mapped to batch-specific error
        codes. The item status is set directly and the method returns
        normally for handled errors. Unhandled exceptions propagate to the
        outer ``process_item()`` handler which sets BATCH_007.

        Args:
            item: The job item containing user and phone number details.
            job: The parent job for context.
        """
        # Step 1: Resolve user (BATCH_003 if not found, BATCH_002 if ambiguous)
        try:
            user = await self.user_service.resolve_user(item.user_upn)
        except NotFoundError:
            item.status = ItemStatus.FAILED
            item.error_code = "BATCH_003"
            item.error_message = f"User '{item.user_upn}' not found"
            return
        except ValidationError as e:
            item.status = ItemStatus.FAILED
            item.error_code = "BATCH_002"
            item.error_message = str(e)
            return

        # Step 2: Re-validate number availability (BATCH_005 if not found)
        try:
            number = await self.number_service.get_number(item.phone_number)
        except NotFoundError:
            item.status = ItemStatus.FAILED
            item.error_code = "BATCH_005"
            item.error_message = f"Phone number '{item.phone_number}' not found"
            return

        # Step 3: Idempotent check -- already assigned to target user (REQ-014)
        if number.assignment_target_id == user.id:
            item.status = ItemStatus.SUCCEEDED
            item.error_message = "Already assigned"
            return

        # Step 4: Perform assignment
        try:
            operation = await self.number_service.assign_number(
                user_id=user.id,
                phone_number=item.phone_number,
                number_type=number.number_type,
                wait=True,
                timeout=self.timeout,
            )
        except TimeoutError:
            item.status = ItemStatus.FAILED
            item.error_code = "BATCH_008"
            item.error_message = (
                f"Assignment timed out after {self.timeout}s for "
                f"'{item.phone_number}' -> '{item.user_upn}'"
            )
            return
        except ValidationError as e:
            item.status = ItemStatus.FAILED
            item.error_code = "BATCH_002"
            item.error_message = str(e)
            return
        except Exception as e:
            item.status = ItemStatus.FAILED
            item.error_code = "BATCH_011"
            item.error_message = str(e)
            return

        # Step 5: Check operation result
        if operation.status == OperationStatus.SUCCEEDED:
            item.status = ItemStatus.SUCCEEDED
        else:
            item.status = ItemStatus.FAILED
            item.error_code = "BATCH_007"
            item.error_message = (
                f"Assignment operation {operation.status.value} for "
                f"'{item.phone_number}' -> '{item.user_upn}'"
            )
