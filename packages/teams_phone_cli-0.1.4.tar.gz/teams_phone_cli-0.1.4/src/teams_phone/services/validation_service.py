"""Validation service for pre-flight batch migration checks.

This module provides the ValidationService class for validating batch migration
jobs before execution, including user existence, number availability, and
phone format validation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from teams_phone.exceptions import NotFoundError
from teams_phone.models import AssignmentStatus
from teams_phone.models.batch import ItemStatus, Job


if TYPE_CHECKING:
    from teams_phone.services.number_service import NumberService
    from teams_phone.services.user_service import UserService


@dataclass
class ValidationIssue:
    """A validation issue for a specific item in a batch job.

    Attributes:
        line_number: 1-indexed line number from the input CSV.
        field: Name of the field that failed validation (e.g., 'user_upn', 'phone_number').
        value: The value that failed validation.
        error_code: Machine-readable error code (e.g., 'BATCH_003').
        error_message: Human-readable error description.
        suggested_fix: Optional suggestion for how to resolve the issue.
    """

    line_number: int
    field: str
    value: str
    error_code: str
    error_message: str
    suggested_fix: str | None = None


@dataclass
class ValidationReport:
    """Summary report of batch job validation results.

    Attributes:
        total_items: Total number of items validated.
        valid_count: Number of items that passed validation.
        invalid_count: Number of items with validation errors.
        issues: List of validation errors that block execution.
        warnings: List of non-blocking warnings (e.g., idempotent assignments).
    """

    total_items: int
    valid_count: int
    invalid_count: int
    issues: list[ValidationIssue] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


class ValidationService:
    """Service for pre-flight validation of batch migration jobs.

    Performs validation checks before batch execution including:
    - User existence and Teams Phone licensing via Graph API
    - Phone number availability via tenant inventory
    - Detection of idempotent (already-assigned) items

    Attributes:
        user_service: UserService instance for user lookups.
        number_service: NumberService instance for number lookups.
    """

    def __init__(
        self,
        user_service: UserService,
        number_service: NumberService,
    ) -> None:
        """Initialize the ValidationService.

        Args:
            user_service: UserService instance for user lookups.
            number_service: NumberService instance for number lookups.
        """
        self.user_service = user_service
        self.number_service = number_service

    async def validate_job(
        self,
        job: Job,
        *,
        check_licenses: bool = False,
    ) -> tuple[Job, ValidationReport]:
        """Validate all items in a batch job before execution.

        Performs pre-flight validation on each job item in sequence. Items
        that are already SUCCEEDED or NEEDS_REVIEW are skipped.

        Validation Steps (per item):
            1. User existence (BATCH_003): Resolve UPN via Graph API. Fails if
               user does not exist in the tenant.
            2. License check (BATCH_004): If check_licenses=True, verify user
               has Enterprise Voice enabled (Teams Phone license).
            3. Number existence (BATCH_005): Look up phone number in tenant
               inventory. Fails if number not found.
            4. Idempotency detection: If the number is already assigned to the
               target user, mark the item as SUCCEEDED with message "Already
               assigned (idempotent)" - no execution needed.
            5. Number availability (BATCH_006): If number is assigned to a
               different user/resource, fail with "Number unavailable".

        Item Status Updates:
            - FAILED: Item failed one of the validation checks (error_code set)
            - SUCCEEDED: Idempotent case - number already assigned to target user
            - PENDING: Item passed validation and is ready for execution

        Args:
            job: The batch job to validate. Items are mutated in place.
            check_licenses: When True, verify users have Teams Phone license.
                Defaults to False for faster validation when license status
                is known to be correct.

        Returns:
            Tuple of (job, report) where:
                - job: The same Job object with item statuses updated
                - report: ValidationReport with counts and issues list

        Note:
            valid_count includes both PENDING items (ready for execution) and
            idempotent SUCCEEDED items. invalid_count equals len(issues).
        """
        issues: list[ValidationIssue] = []
        warnings: list[str] = []

        for item in job.items:
            # Skip already-processed items
            if item.status in (ItemStatus.SUCCEEDED, ItemStatus.NEEDS_REVIEW):
                continue

            # Reset item state so re-validation starts clean
            item.status = ItemStatus.PENDING
            item.error_code = None
            item.error_message = None

            # Resolve user via Graph API
            try:
                user = await self.user_service.resolve_user(item.user_upn)
                user_id = user.id  # Capture for idempotency check
            except NotFoundError:
                issues.append(
                    ValidationIssue(
                        line_number=item.line_number,
                        field="user_upn",
                        value=item.user_upn,
                        error_code="BATCH_003",
                        error_message="User not found in tenant",
                        suggested_fix="Verify the UPN is correct and user exists in Azure AD.",
                    )
                )
                item.status = ItemStatus.FAILED
                item.error_code = "BATCH_003"
                item.error_message = "User not found"
                continue

            # Check Teams Phone license if requested
            if check_licenses and not user.is_enterprise_voice_enabled:
                issues.append(
                    ValidationIssue(
                        line_number=item.line_number,
                        field="user_upn",
                        value=item.user_upn,
                        error_code="BATCH_004",
                        error_message="User lacks Teams Phone license",
                        suggested_fix="Assign Teams Phone license to user.",
                    )
                )
                item.status = ItemStatus.FAILED
                item.error_code = "BATCH_004"
                item.error_message = "User not licensed"
                continue

            # Validate phone number existence and availability
            try:
                number = await self.number_service.get_number(item.phone_number)
            except NotFoundError:
                issues.append(
                    ValidationIssue(
                        line_number=item.line_number,
                        field="phone_number",
                        value=item.phone_number,
                        error_code="BATCH_005",
                        error_message="Number not found in tenant inventory",
                        suggested_fix="Verify the number exists in your Teams Phone inventory.",
                    )
                )
                item.status = ItemStatus.FAILED
                item.error_code = "BATCH_005"
                item.error_message = "Number not found"
                continue

            # Check idempotency: if number already assigned to this user, mark as success
            if number.assignment_target_id == user_id:
                item.status = ItemStatus.SUCCEEDED
                item.error_message = "Already assigned (idempotent)"
                continue

            # Check if number is available (not assigned to another user)
            if number.assignment_status != AssignmentStatus.UNASSIGNED:
                issues.append(
                    ValidationIssue(
                        line_number=item.line_number,
                        field="phone_number",
                        value=item.phone_number,
                        error_code="BATCH_006",
                        error_message="Number assigned to another user",
                        suggested_fix="Use an unassigned number or unassign first.",
                    )
                )
                item.status = ItemStatus.FAILED
                item.error_code = "BATCH_006"
                item.error_message = "Number unavailable"
                continue

        # Calculate counts
        # valid_count: items that are not FAILED (includes PENDING, SUCCEEDED, NEEDS_REVIEW)
        valid_count = sum(1 for item in job.items if item.status != ItemStatus.FAILED)
        # invalid_count: number of validation issues (equals FAILED items)
        invalid_count = len(issues)

        report = ValidationReport(
            total_items=len(job.items),
            valid_count=valid_count,
            invalid_count=invalid_count,
            issues=issues,
            warnings=warnings,
        )
        return job, report
