"""Integration tests for batch workflow: create -> validate -> run -> retry -> export.

This module provides shared fixtures and helpers used by all batch workflow
integration tests (happy path, interrupt/resume, retry scenarios).

Fixtures:
    batch_csv: Creates a valid CSV file with test migration data.
    jobs_dir: Isolates JobStore to a temporary directory via monkeypatch.chdir.
    mock_cli_services_batch: Patches all 7 services at teams_phone.cli.batch level.
    mock_graph_responses: Pre-configured response data for batch operations.

Helpers:
    extract_job_id: Parses a job ID from CLI output text.
"""

from __future__ import annotations

import json
import re
from collections.abc import Generator
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.infrastructure.job_store import JobStore
from teams_phone.models.batch import ItemStatus, JobStatus
from teams_phone.services.batch_executor import ExecutionProgress
from teams_phone.services.validation_service import ValidationReport
from tests.conftest import CliRunner


runner = CliRunner()

# Pattern for timestamp-based job IDs: YYYYMMDD-HHMMSS-{hex4}-{name-slug}
JOB_ID_PATTERN = re.compile(r"\b\d{8}-\d{6}-[a-f0-9]{4}-[\w-]+\b")


# =============================================================================
# Helper Functions
# =============================================================================


def extract_job_id(output: str) -> str:
    """Extract a job ID from CLI output text.

    Parses the timestamp-based job ID from output containing
    "Created job: <id>" or similar patterns.

    Args:
        output: Plain text CLI output (use result.plain_stdout).

    Returns:
        The extracted job ID string.

    Raises:
        ValueError: If no job ID pattern is found in the output.
    """
    match = JOB_ID_PATTERN.search(output)
    if match is None:
        msg = f"No job ID found in output: {output!r}"
        raise ValueError(msg)
    return match.group(0)


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def batch_csv(tmp_path: Path) -> Path:
    """Create a valid batch migration CSV file.

    Creates a CSV with user_upn and phone_number columns containing
    3 test rows suitable for batch create/validate/run operations.

    Returns:
        Path to the temporary CSV file.
    """
    csv_file = tmp_path / "test_migration.csv"
    csv_file.write_text(
        "user_upn,phone_number\n"
        "alice@contoso.com,+14255551001\n"
        "bob@contoso.com,+14255551002\n"
        "carol@contoso.com,+14255551003\n",
        encoding="utf-8",
    )
    return csv_file


@pytest.fixture
def jobs_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Isolate JobStore to a temporary directory.

    Changes the working directory to tmp_path so that JobStore()
    (which defaults to Path.cwd() / ".teams-phone" / "jobs") uses
    an isolated location for each test.

    Returns:
        Path to the temporary working directory.
    """
    monkeypatch.chdir(tmp_path)
    return tmp_path


@pytest.fixture
def mock_cli_services_batch() -> Generator[dict[str, Any], None, None]:
    """Patch all services needed for batch CLI commands that use async execution.

    Mocks the 7 dependencies at teams_phone.cli.batch module level:
    JobStore, CacheManager, AuthService, GraphClient, UserService,
    NumberService, and BatchExecutor.

    This fixture is used for validate/run/retry/resume commands that
    create services internally. The batch create command uses JobStore
    directly without async services, so it typically uses the jobs_dir
    fixture with a real JobStore instead.

    Yields:
        Dict with mock references keyed by service name:
        - store: MagicMock (JobStore instance)
        - store_cls: MagicMock (JobStore class)
        - cache_manager: MagicMock
        - auth_service: MagicMock
        - graph_client: MagicMock (with async context manager)
        - user_service: MagicMock
        - number_service: MagicMock
        - executor: MagicMock (BatchExecutor instance)
        - executor_cls: MagicMock (BatchExecutor class)
        - validation_service: MagicMock
        - validation_service_cls: MagicMock (ValidationService class)
    """
    with (
        patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
        patch("teams_phone.cli.batch.CacheManager") as mock_cache_cls,
        patch("teams_phone.cli.batch.AuthService") as mock_auth_cls,
        patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
        patch("teams_phone.cli.batch.UserService") as mock_user_cls,
        patch("teams_phone.cli.batch.NumberService") as mock_number_cls,
        patch("teams_phone.cli.batch.BatchExecutor") as mock_executor_cls,
        patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
    ):
        # JobStore instance
        mock_store = MagicMock()
        mock_store.acquire_lock.return_value.__enter__ = MagicMock(return_value=None)
        mock_store.acquire_lock.return_value.__exit__ = MagicMock(return_value=False)
        mock_store_cls.return_value = mock_store

        # GraphClient async context manager
        mock_graph = MagicMock()
        mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
        mock_graph.__aexit__ = AsyncMock(return_value=None)
        mock_graph_cls.return_value = mock_graph

        # BatchExecutor instance
        mock_executor = MagicMock()
        mock_executor.execute_job = AsyncMock()
        mock_executor_cls.return_value = mock_executor

        # ValidationService instance
        mock_validation = MagicMock()
        mock_validation.validate_job = AsyncMock()
        mock_validation_cls.return_value = mock_validation

        yield {
            "store": mock_store,
            "store_cls": mock_store_cls,
            "cache_manager": mock_cache_cls.return_value,
            "auth_service": mock_auth_cls.return_value,
            "graph_client": mock_graph,
            "user_service": mock_user_cls.return_value,
            "number_service": mock_number_cls.return_value,
            "executor": mock_executor,
            "executor_cls": mock_executor_cls,
            "validation_service": mock_validation,
            "validation_service_cls": mock_validation_cls,
        }


@pytest.fixture
def mock_graph_responses() -> dict[str, Any]:
    """Pre-configured response data for batch operations.

    Provides data matching the test CSV rows (alice, bob, carol)
    that can be used to configure mock service return values for
    validation, execution, and export operations.

    Returns:
        Dict with pre-built response data:
        - validation_report: A clean ValidationReport (all valid).
        - execution_progress: An ExecutionProgress snapshot.
        - completed_items: List of item status dicts after successful execution.
    """
    return {
        "validation_report": ValidationReport(
            total_items=3,
            valid_count=3,
            invalid_count=0,
            issues=[],
            warnings=[],
        ),
        "execution_progress": ExecutionProgress(
            total=3,
            completed=3,
            succeeded=3,
            failed=0,
            current_item=None,
        ),
        "completed_items": [
            {
                "user_upn": "alice@contoso.com",
                "phone_number": "+14255551001",
                "status": ItemStatus.SUCCEEDED,
            },
            {
                "user_upn": "bob@contoso.com",
                "phone_number": "+14255551002",
                "status": ItemStatus.SUCCEEDED,
            },
            {
                "user_upn": "carol@contoso.com",
                "phone_number": "+14255551003",
                "status": ItemStatus.SUCCEEDED,
            },
        ],
    }


# =============================================================================
# Smoke Tests
# =============================================================================


class TestBatchWorkflowFixtures:
    """Smoke tests to verify all fixtures work together."""

    @pytest.mark.integration
    def test_batch_csv_creates_valid_file(self, batch_csv: Path) -> None:
        """batch_csv fixture creates a readable CSV with expected content."""
        assert batch_csv.exists()
        content = batch_csv.read_text(encoding="utf-8")
        assert "user_upn,phone_number" in content
        assert "alice@contoso.com" in content
        assert "bob@contoso.com" in content
        assert "carol@contoso.com" in content
        # Verify 3 data rows + 1 header
        lines = content.strip().splitlines()
        assert len(lines) == 4

    @pytest.mark.integration
    def test_jobs_dir_isolates_jobstore(self, jobs_dir: Path, batch_csv: Path) -> None:
        """jobs_dir fixture isolates JobStore to a temp directory."""
        from teams_phone.infrastructure.job_store import JobStore

        store = JobStore()
        assert store.base_path == jobs_dir / ".teams-phone" / "jobs"

    @pytest.mark.integration
    def test_batch_create_with_isolated_jobstore(
        self, jobs_dir: Path, batch_csv: Path
    ) -> None:
        """batch create command works with isolated JobStore."""
        result = runner.invoke(app, ["batch", "create", str(batch_csv)])
        assert result.exit_code == 0
        assert "Created job:" in result.plain_stdout

        job_id = extract_job_id(result.plain_stdout)
        assert len(job_id) > 0

    @pytest.mark.integration
    def test_mock_cli_services_batch_patches_services(
        self, mock_cli_services_batch: dict[str, Any]
    ) -> None:
        """mock_cli_services_batch fixture provides all expected mock keys."""
        expected_keys = {
            "store",
            "store_cls",
            "cache_manager",
            "auth_service",
            "graph_client",
            "user_service",
            "number_service",
            "executor",
            "executor_cls",
            "validation_service",
            "validation_service_cls",
        }
        assert set(mock_cli_services_batch.keys()) == expected_keys

    @pytest.mark.integration
    def test_mock_graph_responses_has_expected_data(
        self, mock_graph_responses: dict[str, Any]
    ) -> None:
        """mock_graph_responses fixture provides all expected response types."""
        assert isinstance(mock_graph_responses["validation_report"], ValidationReport)
        assert isinstance(mock_graph_responses["execution_progress"], ExecutionProgress)
        assert len(mock_graph_responses["completed_items"]) == 3

    @pytest.mark.integration
    def test_extract_job_id_from_created_output(self) -> None:
        """extract_job_id parses job ID from typical CLI output."""
        output = "Created job: 20260204-120000-abcd-test-migration"
        job_id = extract_job_id(output)
        assert job_id == "20260204-120000-abcd-test-migration"

    @pytest.mark.integration
    def test_extract_job_id_raises_on_missing(self) -> None:
        """extract_job_id raises ValueError when no job ID is found."""
        with pytest.raises(ValueError, match="No job ID found"):
            extract_job_id("No job ID here")


# =============================================================================
# Happy Path Workflow Tests
# =============================================================================


class TestBatchWorkflow:
    """Integration tests for the complete batch workflow happy path."""

    @pytest.mark.integration
    def test_full_workflow(
        self,
        jobs_dir: Path,
        batch_csv: Path,
        mock_cli_services_batch: dict[str, Any],
        mock_graph_responses: dict[str, Any],
    ) -> None:
        """Full workflow: create -> validate -> run (dry-run) -> status -> export."""
        mocks = mock_cli_services_batch
        report: ValidationReport = mock_graph_responses["validation_report"]

        # --- Step 1: batch create (real JobStore via jobs_dir) ---
        # mock_cli_services_batch patches JobStore at module level, so batch
        # create will use the mock store.  We configure it to delegate to a
        # real JobStore so we get a genuine Job persisted to disk.
        real_store = JobStore()
        # Let the patched JobStore() constructor return the real store
        mocks["store_cls"].return_value = real_store

        result = runner.invoke(app, ["batch", "create", str(batch_csv)])
        assert result.exit_code == 0, result.plain_stdout
        assert "Created job:" in result.plain_stdout

        job_id = extract_job_id(result.plain_stdout)
        assert len(job_id) > 0

        # Load the real job from disk for subsequent mock configuration
        real_job = real_store.load_job(job_id)
        assert real_job.status == JobStatus.CREATED
        assert len(real_job.items) == 3

        # --- Step 2: batch validate (mocked services) ---
        # Now switch to the mock store for validate (needs async mocking)
        validated_job = real_job.model_copy(update={"status": JobStatus.VALIDATED})
        mocks["store"].load_job.return_value = real_job
        mocks["store"].save_job.return_value = None
        mocks["validation_service"].validate_job.return_value = (
            validated_job,
            report,
        )

        result = runner.invoke(app, ["batch", "validate", job_id])
        assert result.exit_code == 0, result.plain_stdout
        assert "Validation passed!" in result.plain_stdout

        # --- Step 3: batch run --dry-run (mocked services) ---
        completed_items = [
            item.model_copy(update={"status": ItemStatus.SUCCEEDED})
            for item in real_job.items
        ]
        completed_job = validated_job.model_copy(
            update={"status": JobStatus.COMPLETED, "items": completed_items}
        )

        mocks["store"].load_job.return_value = validated_job
        mocks["store"].get_active_job_id.return_value = None
        mocks["executor"].execute_job = AsyncMock(return_value=completed_job)

        result = runner.invoke(app, ["batch", "run", job_id, "--dry-run"])
        assert result.exit_code == 0, result.plain_stdout
        assert "DRY RUN" in result.plain_stdout

        # --- Step 4: batch status (mock store) ---
        mocks["store"].load_job.return_value = completed_job

        result = runner.invoke(app, ["batch", "status", job_id])
        assert result.exit_code == 0, result.plain_stdout

        # --- Step 5: batch export --all (mock store) ---
        mocks["store"].load_job.return_value = completed_job

        result = runner.invoke(app, ["batch", "export", job_id, "--all"])
        assert result.exit_code == 0, result.plain_stdout
        assert "Exported" in result.plain_stdout

    @pytest.mark.integration
    def test_full_workflow_json_output(
        self,
        jobs_dir: Path,
        batch_csv: Path,
        mock_cli_services_batch: dict[str, Any],
        mock_graph_responses: dict[str, Any],
    ) -> None:
        """Verify JSON output mode for key batch commands."""
        mocks = mock_cli_services_batch
        report: ValidationReport = mock_graph_responses["validation_report"]

        # --- Create job (real JobStore) ---
        real_store = JobStore()
        mocks["store_cls"].return_value = real_store

        result = runner.invoke(app, ["--json", "batch", "create", str(batch_csv)])
        assert result.exit_code == 0, result.plain_stdout
        data = json.loads(result.plain_stdout)
        assert "job_id" in data
        assert data["status"] == "created"
        assert data["item_count"] == 3

        job_id = data["job_id"]
        real_job = real_store.load_job(job_id)

        # --- Validate (JSON) ---
        validated_job = real_job.model_copy(update={"status": JobStatus.VALIDATED})
        mocks["store"].load_job.return_value = real_job
        mocks["store"].save_job.return_value = None
        mocks["validation_service"].validate_job.return_value = (
            validated_job,
            report,
        )

        result = runner.invoke(app, ["--json", "batch", "validate", job_id])
        assert result.exit_code == 0, result.plain_stdout
        data = json.loads(result.plain_stdout)
        assert data["valid"] is True
        assert data["total"] == 3
        assert data["invalid_count"] == 0

        # --- Status (JSON) ---
        mocks["store"].load_job.return_value = validated_job

        result = runner.invoke(app, ["--json", "batch", "status", job_id])
        assert result.exit_code == 0, result.plain_stdout
        data = json.loads(result.plain_stdout)
        assert data["id"] == job_id
        assert data["status"] == "validated"

    @pytest.mark.integration
    def test_interrupt_and_resume(
        self,
        jobs_dir: Path,
        batch_csv: Path,
        mock_cli_services_batch: dict[str, Any],
        mock_graph_responses: dict[str, Any],
    ) -> None:
        """Interrupt/resume workflow: create -> validate -> run (interrupted) -> resume (completed)."""
        mocks = mock_cli_services_batch
        report: ValidationReport = mock_graph_responses["validation_report"]

        # --- Step 1: batch create (real JobStore via jobs_dir) ---
        real_store = JobStore()
        mocks["store_cls"].return_value = real_store

        result = runner.invoke(app, ["batch", "create", str(batch_csv)])
        assert result.exit_code == 0, result.plain_stdout
        assert "Created job:" in result.plain_stdout

        job_id = extract_job_id(result.plain_stdout)
        real_job = real_store.load_job(job_id)
        assert real_job.status == JobStatus.CREATED
        assert len(real_job.items) == 3

        # Switch back to mock store for all subsequent commands
        mocks["store_cls"].return_value = mocks["store"]

        # --- Step 2: batch validate (mocked services) ---
        validated_job = real_job.model_copy(update={"status": JobStatus.VALIDATED})
        mocks["store"].load_job.return_value = real_job
        mocks["store"].save_job.return_value = None
        mocks["validation_service"].validate_job.return_value = (
            validated_job,
            report,
        )

        result = runner.invoke(app, ["batch", "validate", job_id])
        assert result.exit_code == 0, result.plain_stdout
        assert "Validation passed!" in result.plain_stdout

        # --- Step 3: batch run -> INTERRUPTED (first item succeeds, rest pending) ---
        interrupted_items = [
            item.model_copy(update={"status": ItemStatus.SUCCEEDED}) if i == 0 else item
            for i, item in enumerate(validated_job.items)
        ]
        interrupted_job = validated_job.model_copy(
            update={"status": JobStatus.INTERRUPTED, "items": interrupted_items}
        )

        mocks["store"].load_job.return_value = validated_job
        mocks["store"].get_active_job_id.return_value = None
        mocks["executor"].execute_job = AsyncMock(return_value=interrupted_job)

        result = runner.invoke(app, ["batch", "run", job_id])
        assert result.exit_code == 0, result.plain_stdout
        assert "interrupted" in result.plain_stdout.lower()

        # Verify summary shows partial completion: 1 succeeded, 2 pending
        assert "1 succeeded" in result.plain_stdout
        assert "2 pending" in result.plain_stdout

        # --- Step 4: batch status -> shows INTERRUPTED ---
        mocks["store"].load_job.return_value = interrupted_job

        result = runner.invoke(app, ["batch", "status", job_id])
        assert result.exit_code == 0, result.plain_stdout
        assert "interrupted" in result.plain_stdout.lower()

        # --- Step 5: batch resume -> COMPLETED (all items succeed) ---
        completed_items = [
            item.model_copy(update={"status": ItemStatus.SUCCEEDED})
            for item in interrupted_job.items
        ]
        completed_job = interrupted_job.model_copy(
            update={"status": JobStatus.COMPLETED, "items": completed_items}
        )

        mocks["store"].load_job.return_value = interrupted_job
        mocks["store"].get_active_job_id.return_value = None
        mocks["executor"].execute_job = AsyncMock(return_value=completed_job)

        result = runner.invoke(app, ["batch", "resume", job_id])
        assert result.exit_code == 0, result.plain_stdout
        assert "3 succeeded" in result.plain_stdout

        # --- Step 6: Verify previously succeeded items were not re-processed ---
        # The executor receives the interrupted job (1 SUCCEEDED, 2 PENDING).
        # BatchExecutor.execute_job filters to only process PENDING items,
        # so we verify the executor was called with the interrupted job state.
        call_args = mocks["executor"].execute_job.call_args
        job_arg = call_args[0][0]
        succeeded_before_resume = [
            item for item in job_arg.items if item.status == ItemStatus.SUCCEEDED
        ]
        pending_before_resume = [
            item for item in job_arg.items if item.status == ItemStatus.PENDING
        ]
        assert len(succeeded_before_resume) == 1
        assert len(pending_before_resume) == 2

    @pytest.mark.integration
    def test_retry_failed_items(
        self,
        jobs_dir: Path,
        batch_csv: Path,
        mock_cli_services_batch: dict[str, Any],
        mock_graph_responses: dict[str, Any],
    ) -> None:
        """Retry workflow: create -> validate -> run (mixed results) -> retry -> verify."""
        mocks = mock_cli_services_batch
        report: ValidationReport = mock_graph_responses["validation_report"]

        # --- Step 1: batch create (real JobStore via jobs_dir) ---
        real_store = JobStore()
        mocks["store_cls"].return_value = real_store

        result = runner.invoke(app, ["batch", "create", str(batch_csv)])
        assert result.exit_code == 0, result.plain_stdout
        assert "Created job:" in result.plain_stdout

        job_id = extract_job_id(result.plain_stdout)
        real_job = real_store.load_job(job_id)
        assert real_job.status == JobStatus.CREATED
        assert len(real_job.items) == 3

        # CRITICAL: Reset store_cls to mock store for subsequent commands
        mocks["store_cls"].return_value = mocks["store"]

        # --- Step 2: batch validate (mocked services) ---
        validated_job = real_job.model_copy(update={"status": JobStatus.VALIDATED})
        mocks["store"].load_job.return_value = real_job
        mocks["store"].save_job.return_value = None
        mocks["validation_service"].validate_job.return_value = (
            validated_job,
            report,
        )

        result = runner.invoke(app, ["batch", "validate", job_id])
        assert result.exit_code == 0, result.plain_stdout
        assert "Validation passed!" in result.plain_stdout

        # --- Step 3: batch run -> COMPLETED with mixed results ---
        # alice: SUCCEEDED, bob: FAILED, carol: NEEDS_REVIEW
        run_items = [
            validated_job.items[0].model_copy(
                update={"status": ItemStatus.SUCCEEDED, "attempts": 1}
            ),
            validated_job.items[1].model_copy(
                update={
                    "status": ItemStatus.FAILED,
                    "error_code": "BATCH_003",
                    "error_message": "User not found",
                    "attempts": 1,
                }
            ),
            validated_job.items[2].model_copy(
                update={
                    "status": ItemStatus.NEEDS_REVIEW,
                    "error_code": "BATCH_005",
                    "error_message": "Number unavailable",
                    "attempts": 1,
                }
            ),
        ]
        completed_with_failures = validated_job.model_copy(
            update={"status": JobStatus.COMPLETED, "items": run_items}
        )

        mocks["store"].load_job.return_value = validated_job
        mocks["store"].get_active_job_id.return_value = None
        mocks["executor"].execute_job = AsyncMock(return_value=completed_with_failures)

        result = runner.invoke(app, ["batch", "run", job_id])
        assert result.exit_code == 11, result.plain_stdout  # BATCH_EXECUTION_ERROR

        # --- Step 4: batch status -> shows mixed results ---
        mocks["store"].load_job.return_value = completed_with_failures

        result = runner.invoke(app, ["batch", "status", job_id])
        assert result.exit_code == 0, result.plain_stdout
        assert "Succeeded: 1" in result.plain_stdout

        # --- Step 5: batch retry -> all items succeed ---
        # _reset_failed_items() will mutate completed_with_failures in-place:
        #   bob (FAILED -> PENDING), carol (NEEDS_REVIEW -> PENDING)
        # Then executor runs and returns all-succeeded job.
        all_succeeded_items = [
            item.model_copy(update={"status": ItemStatus.SUCCEEDED, "attempts": 1})
            for item in completed_with_failures.items
        ]
        all_succeeded_job = completed_with_failures.model_copy(
            update={"status": JobStatus.COMPLETED, "items": all_succeeded_items}
        )

        mocks["store"].load_job.return_value = completed_with_failures
        mocks["store"].save_job.return_value = None
        mocks["store"].get_active_job_id.return_value = None
        mocks["executor"].execute_job = AsyncMock(return_value=all_succeeded_job)

        result = runner.invoke(app, ["batch", "retry", job_id])
        assert result.exit_code == 0, result.plain_stdout
        assert "3 succeeded" in result.plain_stdout

        # --- Step 6: Verify retry only processed failed/needs_review items ---
        # _reset_failed_items() mutates the job in-place before passing to executor.
        # After mutation: alice=SUCCEEDED (untouched), bob=PENDING, carol=PENDING.
        call_args = mocks["executor"].execute_job.call_args
        job_arg = call_args[0][0]
        succeeded_in_retry = [
            item for item in job_arg.items if item.status == ItemStatus.SUCCEEDED
        ]
        pending_in_retry = [
            item for item in job_arg.items if item.status == ItemStatus.PENDING
        ]
        assert len(succeeded_in_retry) == 1  # alice (untouched)
        assert (
            len(pending_in_retry) == 2
        )  # bob + carol (reset from FAILED/NEEDS_REVIEW)

        # Verify error fields were cleared on reset items
        for item in pending_in_retry:
            assert item.error_code is None
            assert item.error_message is None

        # Verify attempts counter was preserved (not reset)
        for item in job_arg.items:
            assert item.attempts >= 1

        # --- Step 7: Edge case - retry when no failed items exist ---
        mocks["store"].load_job.return_value = all_succeeded_job

        result = runner.invoke(app, ["batch", "retry", job_id])
        assert result.exit_code == 0, result.plain_stdout
        assert "no failed items" in result.plain_stdout.lower()
