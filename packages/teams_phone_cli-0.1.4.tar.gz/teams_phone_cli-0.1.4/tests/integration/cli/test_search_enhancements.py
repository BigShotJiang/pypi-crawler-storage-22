"""Integration tests for search enhancement features across CLI commands.

This module tests the end-to-end behavior of search enhancements including:
- Case-insensitive city filter for numbers
- --contains flag for substring matching in numbers list
- --assigned-to filter for listing numbers by user
- Wildcard pattern matching for locations search
- Wildcard pattern matching for users search

These tests verify that the CLI commands correctly pass filter parameters
to services and display results appropriately.
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest
from typer.testing import CliRunner

from teams_phone.cli.main import app
from tests.integration.cli.conftest import (
    make_location,
    make_number,
    make_user_config,
)


class TestSearchEnhancementsNumbers:
    """Integration tests for numbers list search enhancements.

    Tests cover:
    - Case-insensitive city filter
    - --contains flag for substring matching
    - --assigned-to filter for user lookup
    """

    @pytest.mark.integration
    def test_numbers_list_city_lowercase_matches_titlecase(
        self,
        runner: CliRunner,
        mock_cli_services_numbers: dict[str, MagicMock],
    ) -> None:
        """--city filter with lowercase query matches title-case city."""
        mocks = mock_cli_services_numbers
        numbers = [make_number(telephone_number="+14255551234", city="Seattle")]
        mocks["number_service"].list_numbers.return_value = numbers

        result = runner.invoke(
            app, ["--no-color", "numbers", "list", "--city", "seattle"]
        )
        assert result.exit_code == 0
        assert "+14255551234" in result.stdout
        assert "Seattle" in result.stdout

        call_kwargs = mocks["number_service"].list_numbers.call_args[1]
        assert call_kwargs["city"] == "seattle"

    @pytest.mark.integration
    def test_numbers_list_city_uppercase_matches_titlecase(
        self,
        runner: CliRunner,
        mock_cli_services_numbers: dict[str, MagicMock],
    ) -> None:
        """--city filter with UPPERCASE query matches title-case city."""
        mocks = mock_cli_services_numbers
        numbers = [make_number(telephone_number="+14255551234", city="Seattle")]
        mocks["number_service"].list_numbers.return_value = numbers

        result = runner.invoke(
            app, ["--no-color", "numbers", "list", "--city", "SEATTLE"]
        )
        assert result.exit_code == 0
        assert "+14255551234" in result.stdout
        assert "Seattle" in result.stdout

        call_kwargs = mocks["number_service"].list_numbers.call_args[1]
        assert call_kwargs["city"] == "SEATTLE"

    @pytest.mark.integration
    def test_numbers_list_city_mixedcase_matches_titlecase(
        self,
        runner: CliRunner,
        mock_cli_services_numbers: dict[str, MagicMock],
    ) -> None:
        """--city filter with MiXeD case query matches title-case city."""
        mocks = mock_cli_services_numbers
        numbers = [make_number(telephone_number="+14255551234", city="Seattle")]
        mocks["number_service"].list_numbers.return_value = numbers

        result = runner.invoke(
            app, ["--no-color", "numbers", "list", "--city", "SeAtTlE"]
        )
        assert result.exit_code == 0
        assert "+14255551234" in result.stdout
        assert "Seattle" in result.stdout

        call_kwargs = mocks["number_service"].list_numbers.call_args[1]
        assert call_kwargs["city"] == "SeAtTlE"

    @pytest.mark.integration
    def test_numbers_list_city_filter_excludes_none_city(
        self,
        runner: CliRunner,
        mock_cli_services_numbers: dict[str, MagicMock],
    ) -> None:
        """--city filter excludes numbers with None city from results."""
        mocks = mock_cli_services_numbers
        # Service returns only matching numbers (filtering happens at service level)
        # Numbers with None city are excluded by the filter
        numbers = [make_number(telephone_number="+14255551234", city="Seattle")]
        mocks["number_service"].list_numbers.return_value = numbers

        result = runner.invoke(
            app, ["--no-color", "numbers", "list", "--city", "seattle"]
        )
        assert result.exit_code == 0
        assert "+14255551234" in result.stdout

        call_kwargs = mocks["number_service"].list_numbers.call_args[1]
        assert call_kwargs["city"] == "seattle"

    @pytest.mark.integration
    def test_numbers_list_contains_partial_city_match(
        self,
        runner: CliRunner,
        mock_cli_services_numbers: dict[str, MagicMock],
    ) -> None:
        """--contains flag enables partial substring matching for city."""
        mocks = mock_cli_services_numbers
        numbers = [make_number(telephone_number="+14255551234", city="Seattle")]
        mocks["number_service"].list_numbers.return_value = numbers

        result = runner.invoke(
            app, ["--no-color", "numbers", "list", "--city", "Sea", "--contains"]
        )
        assert result.exit_code == 0
        assert "+14255551234" in result.stdout
        assert "Seattle" in result.stdout

        call_kwargs = mocks["number_service"].list_numbers.call_args[1]
        assert call_kwargs["city"] == "Sea"
        assert call_kwargs["contains"] is True

    @pytest.mark.integration
    def test_numbers_list_contains_case_insensitive(
        self,
        runner: CliRunner,
        mock_cli_services_numbers: dict[str, MagicMock],
    ) -> None:
        """--contains flag works with case-insensitive matching."""
        mocks = mock_cli_services_numbers
        numbers = [make_number(telephone_number="+14255551234", city="Seattle")]
        mocks["number_service"].list_numbers.return_value = numbers

        result = runner.invoke(
            app, ["--no-color", "numbers", "list", "--city", "sea", "--contains"]
        )
        assert result.exit_code == 0
        assert "+14255551234" in result.stdout
        assert "Seattle" in result.stdout

        call_kwargs = mocks["number_service"].list_numbers.call_args[1]
        assert call_kwargs["city"] == "sea"
        assert call_kwargs["contains"] is True

    @pytest.mark.integration
    def test_numbers_list_without_contains_requires_exact_match(
        self,
        runner: CliRunner,
        mock_cli_services_numbers: dict[str, MagicMock],
    ) -> None:
        """Without --contains, city filter uses exact match (case-insensitive)."""
        mocks = mock_cli_services_numbers
        # Service returns empty list because "Sea" doesn't exact-match "Seattle"
        mocks["number_service"].list_numbers.return_value = []

        result = runner.invoke(app, ["--no-color", "numbers", "list", "--city", "Sea"])
        assert result.exit_code == 0
        # No numbers should be displayed since "Sea" != "Seattle"
        assert "+14255551234" not in result.stdout

        call_kwargs = mocks["number_service"].list_numbers.call_args[1]
        assert call_kwargs["city"] == "Sea"
        assert call_kwargs["contains"] is False


class TestSearchEnhancementsLocations:
    """Integration tests for locations search wildcard enhancements.

    Tests cover:
    - Wildcard pattern matching with * character
    - Case-insensitive wildcard matching
    - Non-wildcard substring search behavior
    """

    @pytest.mark.integration
    def test_locations_search_wildcard_prefix(
        self,
        runner: CliRunner,
        mock_cli_services_locations: dict[str, MagicMock],
    ) -> None:
        """locations search 'Alpha*' matches locations starting with 'Alpha'."""
        mocks = mock_cli_services_locations
        locations = [
            make_location(
                location_id="loc-1",
                description="Alpha Office",
                city="Redmond",
                address="100 Pine St",
                company_name="Contoso",
            ),
            make_location(
                location_id="loc-2",
                description="Alpha Campus",
                city="Bellevue",
                address="200 Oak St",
                company_name="Contoso",
            ),
            make_location(
                location_id="loc-3",
                description="Beta Branch",
                city="Portland",
                address="300 Elm Ave",
                company_name="Fabrikam",
            ),
        ]
        mocks["location_service"].list_locations.return_value = locations
        mocks["location_service"].get_staleness_warning.return_value = None

        result = runner.invoke(app, ["--no-color", "locations", "search", "Alpha*"])
        assert result.exit_code == 0
        assert "Alpha Office" in result.stdout
        assert "Alpha Campus" in result.stdout
        assert "Beta Branch" not in result.stdout

    @pytest.mark.integration
    def test_locations_search_wildcard_suffix(
        self,
        runner: CliRunner,
        mock_cli_services_locations: dict[str, MagicMock],
    ) -> None:
        """locations search '*HQ' matches locations ending with 'HQ'."""
        mocks = mock_cli_services_locations
        locations = [
            make_location(
                location_id="loc-1", description="Seattle HQ", city="Seattle"
            ),
            make_location(location_id="loc-2", description="NYC HQ", city="New York"),
            make_location(
                location_id="loc-3", description="Portland Office", city="Portland"
            ),
        ]
        mocks["location_service"].list_locations.return_value = locations
        mocks["location_service"].get_staleness_warning.return_value = None

        result = runner.invoke(app, ["--no-color", "locations", "search", "*HQ"])
        assert result.exit_code == 0
        assert "Seattle HQ" in result.stdout
        assert "NYC HQ" in result.stdout
        assert "Portland Office" not in result.stdout

    @pytest.mark.integration
    def test_locations_search_wildcard_contains(
        self,
        runner: CliRunner,
        mock_cli_services_locations: dict[str, MagicMock],
    ) -> None:
        """locations search '*central*' matches locations containing 'central'."""
        mocks = mock_cli_services_locations
        locations = [
            make_location(
                location_id="loc-1", description="Central Office", city="Seattle"
            ),
            make_location(
                location_id="loc-2", description="Downtown Central", city="Portland"
            ),
            make_location(
                location_id="loc-3", description="North Branch", city="Tacoma"
            ),
        ]
        mocks["location_service"].list_locations.return_value = locations
        mocks["location_service"].get_staleness_warning.return_value = None

        result = runner.invoke(app, ["--no-color", "locations", "search", "*central*"])
        assert result.exit_code == 0
        assert "Central Office" in result.stdout
        assert "Downtown Central" in result.stdout
        assert "North Branch" not in result.stdout

    @pytest.mark.integration
    def test_locations_search_no_wildcard_substring(
        self,
        runner: CliRunner,
        mock_cli_services_locations: dict[str, MagicMock],
    ) -> None:
        """locations search 'Office' (no *) performs substring match."""
        mocks = mock_cli_services_locations
        locations = [
            make_location(
                location_id="loc-1", description="Main Office", city="Seattle"
            ),
            make_location(
                location_id="loc-2", description="Branch Office", city="Portland"
            ),
            make_location(
                location_id="loc-3", description="Seattle HQ", city="Seattle"
            ),
        ]
        mocks["location_service"].list_locations.return_value = locations
        mocks["location_service"].get_staleness_warning.return_value = None

        result = runner.invoke(app, ["--no-color", "locations", "search", "Office"])
        assert result.exit_code == 0
        assert "Main Office" in result.stdout
        assert "Branch Office" in result.stdout
        assert "Seattle HQ" not in result.stdout

    @pytest.mark.integration
    def test_locations_search_wildcard_case_insensitive(
        self,
        runner: CliRunner,
        mock_cli_services_locations: dict[str, MagicMock],
    ) -> None:
        """locations search '*hq' (lowercase) matches 'Seattle HQ' (uppercase)."""
        mocks = mock_cli_services_locations
        locations = [
            make_location(
                location_id="loc-1", description="Seattle HQ", city="Seattle"
            ),
            make_location(location_id="loc-2", description="NYC HQ", city="New York"),
            make_location(
                location_id="loc-3", description="Portland Office", city="Portland"
            ),
        ]
        mocks["location_service"].list_locations.return_value = locations
        mocks["location_service"].get_staleness_warning.return_value = None

        result = runner.invoke(app, ["--no-color", "locations", "search", "*hq"])
        assert result.exit_code == 0
        assert "Seattle HQ" in result.stdout
        assert "NYC HQ" in result.stdout
        assert "Portland Office" not in result.stdout


class TestSearchEnhancementsUsers:
    """Integration tests for users search wildcard enhancements.

    Tests cover:
    - Wildcard pattern matching with * character
    - Search routing (phone -> UPN -> wildcard/display name)
    """

    @pytest.mark.integration
    def test_users_search_wildcard_prefix(
        self,
        runner: CliRunner,
        mock_cli_services_users: dict[str, MagicMock],
    ) -> None:
        """users search 'Jo*' matches users starting with 'Jo'."""
        mocks = mock_cli_services_users
        users = [
            make_user_config(
                user_id="user-1",
                upn="john.doe@contoso.com",
                display_name="John Doe",
            ),
            make_user_config(
                user_id="user-2",
                upn="joanna.chen@contoso.com",
                display_name="Joanna Chen",
            ),
        ]
        mocks["user_service"].search_users.return_value = users

        result = runner.invoke(app, ["--no-color", "users", "search", "Jo*"])
        assert result.exit_code == 0
        assert "John Doe" in result.stdout
        assert "Joanna Chen" in result.stdout

    @pytest.mark.integration
    def test_users_search_wildcard_suffix(
        self,
        runner: CliRunner,
        mock_cli_services_users: dict[str, MagicMock],
    ) -> None:
        """users search '*son' matches users ending with 'son'."""
        mocks = mock_cli_services_users
        users = [
            make_user_config(
                user_id="user-1",
                upn="bob.johnson@contoso.com",
                display_name="Bob Johnson",
            ),
            make_user_config(
                user_id="user-2",
                upn="tom.wilson@contoso.com",
                display_name="Tom Wilson",
            ),
        ]
        mocks["user_service"].search_users.return_value = users

        result = runner.invoke(app, ["--no-color", "users", "search", "*son"])
        assert result.exit_code == 0
        assert "Bob Johnson" in result.stdout
        assert "Tom Wilson" in result.stdout

    @pytest.mark.integration
    def test_users_search_wildcard_contains(
        self,
        runner: CliRunner,
        mock_cli_services_users: dict[str, MagicMock],
    ) -> None:
        """users search '*admin*' matches users with 'admin' in name."""
        mocks = mock_cli_services_users
        users = [
            make_user_config(
                user_id="user-1",
                upn="site.admin@contoso.com",
                display_name="Site Admin",
            ),
            make_user_config(
                user_id="user-2",
                upn="admin.user@contoso.com",
                display_name="Admin User",
            ),
        ]
        mocks["user_service"].search_users.return_value = users

        result = runner.invoke(app, ["--no-color", "users", "search", "*admin*"])
        assert result.exit_code == 0
        assert "Site Admin" in result.stdout
        assert "Admin User" in result.stdout

    @pytest.mark.integration
    def test_users_search_no_wildcard_startswith(
        self,
        runner: CliRunner,
        mock_cli_services_users: dict[str, MagicMock],
    ) -> None:
        """users search 'John' (no *) uses existing startsWith optimization."""
        mocks = mock_cli_services_users
        users = [
            make_user_config(
                user_id="user-1",
                upn="john.doe@contoso.com",
                display_name="John Doe",
            ),
            make_user_config(
                user_id="user-2",
                upn="johnny.smith@contoso.com",
                display_name="Johnny Smith",
            ),
        ]
        mocks["user_service"].search_users.return_value = users

        result = runner.invoke(app, ["--no-color", "users", "search", "John"])
        assert result.exit_code == 0
        assert "John Doe" in result.stdout
        assert "Johnny Smith" in result.stdout
