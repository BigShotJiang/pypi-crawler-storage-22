"""Unit tests for batch_csv_parser module."""

from pathlib import Path

import pytest

from teams_phone.exceptions import ValidationError

# Import infrastructure first to avoid circular import
# (graph_client imports auth_service which imports infrastructure)
from teams_phone.infrastructure import GraphClient  # noqa: F401
from teams_phone.models.batch import ItemStatus
from teams_phone.services.batch_csv_parser import (
    CSVParseResult,
    CSVValidationError,
    parse_batch_csv,
)


# Sample CSV content for tests (updated to use user_upn header)
VALID_CSV = """user_upn,phone_number,location
user1@contoso.com,+14255551234,loc-001
user2@contoso.com,+14255555678,loc-002"""

VALID_CSV_WITH_BOM = "\ufeffuser_upn,phone_number\nuser1@contoso.com,+14255551234"

VALID_CSV_CRLF = "user_upn,phone_number\r\nuser1@contoso.com,+14255551234\r\nuser2@contoso.com,+14255555678"

VALID_CSV_CR = "user_upn,phone_number\ruser1@contoso.com,+14255551234\ruser2@contoso.com,+14255555678"

VALID_CSV_LF = "user_upn,phone_number\nuser1@contoso.com,+14255551234\nuser2@contoso.com,+14255555678"

HEADER_ONLY_CSV = "user_upn,phone_number,location"

# Sample CSV content using new required headers (user_upn, phone_number)
VALID_CSV_NEW = """user_upn,phone_number
user1@contoso.com,+14255551234
user2@contoso.com,+14255555678"""

VALID_CSV_MIXED_CASE_HEADERS = """User_UPN,PHONE_NUMBER
user1@contoso.com,+14255551234"""

VALID_CSV_WITH_EXTENSION = """user_upn,phone_number
user1@contoso.com,+14255551234;ext=123
user2@contoso.com,+14255555678;EXT=456"""

CSV_MISSING_USER_UPN = """phone_number
+14255551234"""

CSV_MISSING_PHONE_NUMBER = """user_upn
user1@contoso.com"""

CSV_MISSING_BOTH = """location
loc-001"""

CSV_EMPTY_USER_UPN = """user_upn,phone_number
,+14255551234"""

CSV_EMPTY_PHONE_NUMBER = """user_upn,phone_number
user1@contoso.com,"""

CSV_INVALID_PHONE = """user_upn,phone_number
user1@contoso.com,abc"""

CSV_MIXED_CASE_UPN = """user_upn,phone_number
User@Domain.COM,+14255551234"""

# Duplicate detection test data
CSV_DUPLICATE_PHONE = """user_upn,phone_number
user1@contoso.com,+14255551234
user2@contoso.com,+14255551234"""

CSV_DUPLICATE_UPN = """user_upn,phone_number
user1@contoso.com,+14255551234
user1@contoso.com,+14255555678"""

CSV_DUPLICATE_PHONE_DIFFERENT_FORMAT = """user_upn,phone_number
user1@contoso.com,+1-425-555-1234
user2@contoso.com,14255551234"""

CSV_DUPLICATE_UPN_CASE = """user_upn,phone_number
User@Contoso.COM,+14255551234
user@contoso.com,+14255555678"""

CSV_MULTIPLE_ERRORS = """user_upn,phone_number
user1@contoso.com,+14255551234
,+14255555678
user1@contoso.com,+14255559012"""

CSV_MANY_DUPLICATES = """user_upn,phone_number
user1@contoso.com,+14255551234
user2@contoso.com,+14255551234
user3@contoso.com,+14255551234
user4@contoso.com,+14255551234
user5@contoso.com,+14255551234
user6@contoso.com,+14255551234
user7@contoso.com,+14255551234
user8@contoso.com,+14255551234
user9@contoso.com,+14255551234
user10@contoso.com,+14255551234
user11@contoso.com,+14255551234
user12@contoso.com,+14255551234"""

CSV_NO_DUPLICATES = """user_upn,phone_number
user1@contoso.com,+14255551234
user2@contoso.com,+14255555678
user3@contoso.com,+14255559012"""


class TestCSVValidationError:
    """Tests for CSVValidationError dataclass."""

    @pytest.mark.unit
    def test_creates_with_all_fields(self) -> None:
        """CSVValidationError stores all fields correctly."""
        error = CSVValidationError(
            line_number=5,
            field="phone_number",
            value="invalid",
            message="Invalid phone number format",
            suggested_fix="Use E.164 format like +14255551234",
        )

        assert error.line_number == 5
        assert error.field == "phone_number"
        assert error.value == "invalid"
        assert error.message == "Invalid phone number format"
        assert error.suggested_fix == "Use E.164 format like +14255551234"

    @pytest.mark.unit
    def test_suggested_fix_defaults_to_none(self) -> None:
        """CSVValidationError.suggested_fix defaults to None."""
        error = CSVValidationError(
            line_number=2,
            field="user",
            value="",
            message="Missing required field",
        )

        assert error.suggested_fix is None


class TestCSVParseResult:
    """Tests for CSVParseResult dataclass."""

    @pytest.mark.unit
    def test_creates_with_all_fields(self) -> None:
        """CSVParseResult stores all fields correctly."""
        result = CSVParseResult(
            items=[{"user": "test@example.com"}],
            warnings=["Some warning"],
            input_hash="abc123",
        )

        assert result.items == [{"user": "test@example.com"}]
        assert result.warnings == ["Some warning"]
        assert result.input_hash == "abc123"

    @pytest.mark.unit
    def test_warnings_default_to_empty_list(self) -> None:
        """CSVParseResult.warnings defaults to empty list."""
        result = CSVParseResult(items=[], input_hash="hash")

        assert result.warnings == []


class TestParseBatchCsv:
    """Tests for parse_batch_csv function."""

    @pytest.mark.unit
    def test_parses_valid_csv_returns_correct_items_count(self, tmp_path: Path) -> None:
        """parse_batch_csv parses valid CSV and returns correct item count."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(VALID_CSV, encoding="utf-8")

        result = parse_batch_csv(csv_file)

        assert len(result.items) == 2
        assert result.items[0]["user_upn"] == "user1@contoso.com"
        assert result.items[0]["phone_number"] == "+14255551234"
        assert result.items[1]["user_upn"] == "user2@contoso.com"

    @pytest.mark.unit
    def test_handles_utf8_bom(self, tmp_path: Path) -> None:
        """parse_batch_csv strips UTF-8 BOM from PowerShell exports."""
        csv_file = tmp_path / "batch.csv"
        # Write with explicit BOM bytes
        csv_file.write_bytes(b"\xef\xbb\xbf" + VALID_CSV.encode("utf-8"))

        result = parse_batch_csv(csv_file)

        assert len(result.items) == 2
        # Verify BOM was stripped from first column name
        assert "user_upn" in result.items[0]
        assert result.items[0]["user_upn"] == "user1@contoso.com"

    @pytest.mark.unit
    def test_handles_bom_in_text(self, tmp_path: Path) -> None:
        """parse_batch_csv handles BOM written as text character."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(VALID_CSV_WITH_BOM, encoding="utf-8")

        result = parse_batch_csv(csv_file)

        assert len(result.items) == 1
        assert "user_upn" in result.items[0]
        assert result.items[0]["user_upn"] == "user1@contoso.com"

    @pytest.mark.unit
    def test_handles_crlf_line_endings(self, tmp_path: Path) -> None:
        """parse_batch_csv parses files with CRLF line endings correctly."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_bytes(VALID_CSV_CRLF.encode("utf-8"))

        result = parse_batch_csv(csv_file)

        assert len(result.items) == 2
        assert result.items[0]["user_upn"] == "user1@contoso.com"
        assert result.items[1]["user_upn"] == "user2@contoso.com"

    @pytest.mark.unit
    def test_handles_lf_line_endings(self, tmp_path: Path) -> None:
        """parse_batch_csv parses files with LF line endings correctly."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_bytes(VALID_CSV_LF.encode("utf-8"))

        result = parse_batch_csv(csv_file)

        assert len(result.items) == 2
        assert result.items[0]["user_upn"] == "user1@contoso.com"
        assert result.items[1]["user_upn"] == "user2@contoso.com"

    @pytest.mark.unit
    def test_handles_cr_line_endings(self, tmp_path: Path) -> None:
        """parse_batch_csv parses files with CR line endings correctly."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_bytes(VALID_CSV_CR.encode("utf-8"))

        result = parse_batch_csv(csv_file)

        assert len(result.items) == 2
        assert result.items[0]["user_upn"] == "user1@contoso.com"
        assert result.items[1]["user_upn"] == "user2@contoso.com"

    @pytest.mark.unit
    def test_empty_file_raises_validation_error(self, tmp_path: Path) -> None:
        """parse_batch_csv raises ValidationError for empty file."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text("", encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_batch_csv(csv_file)

        assert "empty" in str(exc_info.value).lower()

    @pytest.mark.unit
    def test_nonexistent_file_raises_validation_error(self, tmp_path: Path) -> None:
        """parse_batch_csv raises ValidationError with remediation for missing file."""
        csv_file = tmp_path / "nonexistent.csv"

        with pytest.raises(ValidationError) as exc_info:
            parse_batch_csv(csv_file)

        assert "not found" in str(exc_info.value).lower()
        assert exc_info.value.remediation is not None
        assert "file path" in exc_info.value.remediation.lower()

    @pytest.mark.unit
    def test_input_hash_computed_consistently(self, tmp_path: Path) -> None:
        """parse_batch_csv computes consistent SHA-256 hash for input file."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(VALID_CSV, encoding="utf-8")

        result1 = parse_batch_csv(csv_file)
        result2 = parse_batch_csv(csv_file)

        # Hash should be consistent across calls
        assert result1.input_hash == result2.input_hash
        # Hash should be 64 hex characters (SHA-256)
        assert len(result1.input_hash) == 64
        assert all(c in "0123456789abcdef" for c in result1.input_hash)

    @pytest.mark.unit
    def test_header_only_csv_returns_empty_items(self, tmp_path: Path) -> None:
        """parse_batch_csv returns empty items list for header-only CSV."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(HEADER_ONLY_CSV, encoding="utf-8")

        result = parse_batch_csv(csv_file)

        assert result.items == []
        assert result.input_hash != ""

    @pytest.mark.unit
    def test_preserves_required_fields_in_output(self, tmp_path: Path) -> None:
        """parse_batch_csv includes required fields in validated items."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(VALID_CSV, encoding="utf-8")

        result = parse_batch_csv(csv_file)

        # Validated items have the expected fields
        assert "user_upn" in result.items[0]
        assert "phone_number" in result.items[0]
        assert "line_number" in result.items[0]
        assert "status" in result.items[0]
        assert "attempts" in result.items[0]


class TestHeaderValidation:
    """Tests for CSV header validation."""

    @pytest.mark.unit
    def test_missing_user_upn_header_raises_validation_error(
        self, tmp_path: Path
    ) -> None:
        """parse_batch_csv raises ValidationError when user_upn header is missing."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(CSV_MISSING_USER_UPN, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_batch_csv(csv_file)

        assert "user_upn" in str(exc_info.value).lower()
        assert "missing" in str(exc_info.value).lower()

    @pytest.mark.unit
    def test_missing_phone_number_header_raises_validation_error(
        self, tmp_path: Path
    ) -> None:
        """parse_batch_csv raises ValidationError when phone_number header is missing."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(CSV_MISSING_PHONE_NUMBER, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_batch_csv(csv_file)

        assert "phone_number" in str(exc_info.value).lower()
        assert "missing" in str(exc_info.value).lower()

    @pytest.mark.unit
    def test_missing_both_headers_lists_both_in_error(self, tmp_path: Path) -> None:
        """parse_batch_csv lists both missing columns when both are absent."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(CSV_MISSING_BOTH, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_batch_csv(csv_file)

        error_msg = str(exc_info.value).lower()
        assert "phone_number" in error_msg
        assert "user_upn" in error_msg

    @pytest.mark.unit
    def test_case_insensitive_header_matching(self, tmp_path: Path) -> None:
        """parse_batch_csv accepts headers with different case (User_UPN, PHONE_NUMBER)."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(VALID_CSV_MIXED_CASE_HEADERS, encoding="utf-8")

        result = parse_batch_csv(csv_file)

        assert len(result.items) == 1
        assert result.items[0]["user_upn"] == "user1@contoso.com"


class TestFieldValidation:
    """Tests for CSV row-level field validation."""

    @pytest.mark.unit
    def test_empty_user_upn_value_rejected_with_line_number(
        self, tmp_path: Path
    ) -> None:
        """parse_batch_csv rejects empty user_upn and reports line number."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(CSV_EMPTY_USER_UPN, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_batch_csv(csv_file)

        error_msg = str(exc_info.value)
        assert "user_upn" in error_msg.lower()
        assert "Line 2" in error_msg  # First data row is line 2

    @pytest.mark.unit
    def test_empty_phone_number_value_rejected_with_line_number(
        self, tmp_path: Path
    ) -> None:
        """parse_batch_csv rejects empty phone_number and reports line number."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(CSV_EMPTY_PHONE_NUMBER, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_batch_csv(csv_file)

        error_msg = str(exc_info.value)
        assert "phone_number" in error_msg.lower()
        assert "Line 2" in error_msg

    @pytest.mark.unit
    def test_phone_extension_stripped_with_warning(self, tmp_path: Path) -> None:
        """parse_batch_csv strips ;ext=NNN from phone numbers and adds warning."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(VALID_CSV_WITH_EXTENSION, encoding="utf-8")

        result = parse_batch_csv(csv_file)

        # Extensions should be stripped
        assert result.items[0]["phone_number"] == "+14255551234"
        assert result.items[1]["phone_number"] == "+14255555678"
        # Warnings should be added
        assert len(result.warnings) == 2
        assert "extension" in result.warnings[0].lower()
        assert "extension" in result.warnings[1].lower()

    @pytest.mark.unit
    def test_invalid_phone_format_collected_as_validation_error(
        self, tmp_path: Path
    ) -> None:
        """parse_batch_csv collects invalid phone format as CSVValidationError."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(CSV_INVALID_PHONE, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_batch_csv(csv_file)

        error_msg = str(exc_info.value)
        assert "phone" in error_msg.lower()
        assert "invalid" in error_msg.lower() or "format" in error_msg.lower()

    @pytest.mark.unit
    def test_valid_phone_number_normalized_to_e164(self, tmp_path: Path) -> None:
        """parse_batch_csv normalizes valid phone numbers to E.164 (+digits)."""
        csv_file = tmp_path / "batch.csv"
        # Test with various valid formats - normalize_phone_number extracts digits only
        csv_content = """user_upn,phone_number
user1@contoso.com,1-206-555-1234
user2@contoso.com,(206) 555-5678
user3@contoso.com,+1 206 555 9012"""
        csv_file.write_text(csv_content, encoding="utf-8")

        result = parse_batch_csv(csv_file)

        # E.164 format: + followed by digits extracted by normalize_phone_number
        assert result.items[0]["phone_number"] == "+12065551234"  # 11 digits
        assert (
            result.items[1]["phone_number"] == "+2065555678"
        )  # 10 digits (no country code)
        assert result.items[2]["phone_number"] == "+12065559012"  # 11 digits

    @pytest.mark.unit
    def test_upn_lowercased(self, tmp_path: Path) -> None:
        """parse_batch_csv lowercases UPN (User@Domain.COM -> user@domain.com)."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(CSV_MIXED_CASE_UPN, encoding="utf-8")

        result = parse_batch_csv(csv_file)

        assert result.items[0]["user_upn"] == "user@domain.com"


class TestValidatedItemStructure:
    """Tests for validated item dictionary structure."""

    @pytest.mark.unit
    def test_item_has_required_fields(self, tmp_path: Path) -> None:
        """Validated items have line_number, user_upn, phone_number, status, attempts."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(VALID_CSV_NEW, encoding="utf-8")

        result = parse_batch_csv(csv_file)

        item = result.items[0]
        assert "line_number" in item
        assert "user_upn" in item
        assert "phone_number" in item
        assert "status" in item
        assert "attempts" in item

    @pytest.mark.unit
    def test_item_line_number_is_correct(self, tmp_path: Path) -> None:
        """Item line_number is 1-indexed (header=1, first data row=2)."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(VALID_CSV_NEW, encoding="utf-8")

        result = parse_batch_csv(csv_file)

        assert result.items[0]["line_number"] == 2
        assert result.items[1]["line_number"] == 3

    @pytest.mark.unit
    def test_item_status_is_pending(self, tmp_path: Path) -> None:
        """Validated items have status=ItemStatus.PENDING."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(VALID_CSV_NEW, encoding="utf-8")

        result = parse_batch_csv(csv_file)

        assert result.items[0]["status"] == ItemStatus.PENDING
        assert result.items[1]["status"] == ItemStatus.PENDING

    @pytest.mark.unit
    def test_item_attempts_is_zero(self, tmp_path: Path) -> None:
        """Validated items have attempts=0."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(VALID_CSV_NEW, encoding="utf-8")

        result = parse_batch_csv(csv_file)

        assert result.items[0]["attempts"] == 0
        assert result.items[1]["attempts"] == 0


class TestDuplicateDetection:
    """Tests for duplicate phone number and UPN detection."""

    @pytest.mark.unit
    def test_duplicate_phone_number_raises_validation_error(
        self, tmp_path: Path
    ) -> None:
        """parse_batch_csv raises ValidationError for duplicate phone numbers."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(CSV_DUPLICATE_PHONE, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_batch_csv(csv_file)

        error_msg = str(exc_info.value)
        assert "duplicate phone number" in error_msg.lower()
        assert "first seen at line 2" in error_msg.lower()
        assert "Line 3" in error_msg

    @pytest.mark.unit
    def test_duplicate_upn_raises_validation_error(self, tmp_path: Path) -> None:
        """parse_batch_csv raises ValidationError for duplicate user UPNs."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(CSV_DUPLICATE_UPN, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_batch_csv(csv_file)

        error_msg = str(exc_info.value)
        assert "duplicate user assignment" in error_msg.lower()
        assert "first seen at line 2" in error_msg.lower()
        assert "Line 3" in error_msg

    @pytest.mark.unit
    def test_duplicate_phone_different_formats_detected(self, tmp_path: Path) -> None:
        """parse_batch_csv detects duplicates when phone formats differ but normalize same."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(CSV_DUPLICATE_PHONE_DIFFERENT_FORMAT, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_batch_csv(csv_file)

        error_msg = str(exc_info.value)
        assert "duplicate phone number" in error_msg.lower()

    @pytest.mark.unit
    def test_duplicate_upn_case_insensitive(self, tmp_path: Path) -> None:
        """parse_batch_csv detects duplicate UPNs case-insensitively."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(CSV_DUPLICATE_UPN_CASE, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_batch_csv(csv_file)

        error_msg = str(exc_info.value)
        assert "duplicate user assignment" in error_msg.lower()

    @pytest.mark.unit
    def test_multiple_errors_aggregated(self, tmp_path: Path) -> None:
        """parse_batch_csv aggregates multiple error types (empty field + duplicate)."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(CSV_MULTIPLE_ERRORS, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_batch_csv(csv_file)

        error_msg = str(exc_info.value)
        # Should have both missing field and duplicate errors
        assert "2 error(s)" in error_msg
        assert "user_upn" in error_msg.lower()
        assert "duplicate" in error_msg.lower()

    @pytest.mark.unit
    def test_error_display_limited_to_10(self, tmp_path: Path) -> None:
        """parse_batch_csv limits error display to first 10 errors."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(CSV_MANY_DUPLICATES, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_batch_csv(csv_file)

        error_msg = str(exc_info.value)
        # Total count should show all errors
        assert "11 error(s)" in error_msg
        # Should indicate more errors
        assert "and 1 more error(s)" in error_msg
        # Should show lines 3-12 (first 10 duplicates) but not line 13
        assert "Line 3:" in error_msg
        assert "Line 12:" in error_msg
        # Line 13 should NOT appear in displayed errors (only in "more" count)
        lines_in_errors = error_msg.count("Line 13:")
        assert lines_in_errors == 0

    @pytest.mark.unit
    def test_valid_csv_no_duplicates_returns_result(self, tmp_path: Path) -> None:
        """parse_batch_csv returns CSVParseResult for valid CSV without duplicates."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(CSV_NO_DUPLICATES, encoding="utf-8")

        result = parse_batch_csv(csv_file)

        assert len(result.items) == 3
        assert result.items[0]["user_upn"] == "user1@contoso.com"
        assert result.items[1]["user_upn"] == "user2@contoso.com"
        assert result.items[2]["user_upn"] == "user3@contoso.com"

    @pytest.mark.unit
    def test_error_format_includes_field_name(self, tmp_path: Path) -> None:
        """parse_batch_csv error format is 'Line N: field - message'."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(CSV_DUPLICATE_PHONE, encoding="utf-8")

        with pytest.raises(ValidationError) as exc_info:
            parse_batch_csv(csv_file)

        error_msg = str(exc_info.value)
        # Check format: "Line N: field - message"
        assert "Line 3: phone_number - Duplicate phone number" in error_msg

    @pytest.mark.unit
    def test_warnings_include_extension_stripped(self, tmp_path: Path) -> None:
        """parse_batch_csv warnings list contains extension-stripped messages."""
        csv_file = tmp_path / "batch.csv"
        csv_file.write_text(VALID_CSV_WITH_EXTENSION, encoding="utf-8")

        result = parse_batch_csv(csv_file)

        assert len(result.warnings) == 2
        assert "extension stripped" in result.warnings[0].lower()
        assert "extension stripped" in result.warnings[1].lower()
