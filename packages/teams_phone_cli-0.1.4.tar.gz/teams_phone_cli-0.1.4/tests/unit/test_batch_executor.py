"""Unit tests for BatchExecutor."""

import json
import signal
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from teams_phone.exceptions import NotFoundError, ValidationError

# Import infrastructure first to avoid circular import
from teams_phone.infrastructure import GraphClient  # noqa: F401
from teams_phone.models import OperationStatus
from teams_phone.models.batch import ItemStatus, Job, JobItem, JobStatus
from teams_phone.services.batch_executor import BatchExecutor, ExecutionProgress
from tests.fixtures import make_number, make_operation, make_user


def make_job(
    job_id: str = "20240101-120000-abcd-test",
    name: str = "Test Job",
    items: list[JobItem] | None = None,
) -> Job:
    """Create a Job instance for testing."""
    now = datetime.now(timezone.utc)
    return Job(
        id=job_id,
        name=name,
        status=JobStatus.CREATED,
        created_at=now,
        updated_at=now,
        input_file="test.csv",
        input_hash="abc123",
        items=items or [],
    )


def make_job_item(
    line_number: int = 1,
    user_upn: str = "user@contoso.com",
    phone_number: str = "+14155551234",
    status: ItemStatus = ItemStatus.PENDING,
) -> JobItem:
    """Create a JobItem instance for testing."""
    return JobItem(
        line_number=line_number,
        user_upn=user_upn,
        phone_number=phone_number,
        status=status,
    )


def make_mock_job_store(tmp_path: Path) -> MagicMock:
    """Create a MagicMock job_store with _job_dir returning a real directory.

    The execution log feature requires a writable directory from _job_dir().
    """
    job_store = MagicMock()
    job_dir = tmp_path / "jobs" / "test-job"
    job_dir.mkdir(parents=True, exist_ok=True)
    job_store._job_dir.return_value = job_dir
    return job_store


class TestExecutionProgress:
    """Tests for the ExecutionProgress dataclass."""

    @pytest.mark.unit
    def test_creation_with_all_fields(self) -> None:
        progress = ExecutionProgress(
            total=10,
            completed=5,
            succeeded=4,
            failed=1,
            current_item="user@contoso.com",
        )
        assert progress.total == 10
        assert progress.completed == 5
        assert progress.succeeded == 4
        assert progress.failed == 1
        assert progress.current_item == "user@contoso.com"

    @pytest.mark.unit
    def test_creation_with_none_current_item(self) -> None:
        progress = ExecutionProgress(
            total=0,
            completed=0,
            succeeded=0,
            failed=0,
            current_item=None,
        )
        assert progress.current_item is None


class TestBatchExecutorInit:
    """Tests for BatchExecutor constructor."""

    @pytest.mark.unit
    def test_default_parameters(self) -> None:
        user_service = MagicMock()
        number_service = MagicMock()
        job_store = MagicMock()

        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=job_store,
        )

        assert executor.user_service is user_service
        assert executor.number_service is number_service
        assert executor.job_store is job_store
        assert executor.concurrency == 3
        assert executor.dry_run is False
        assert executor.timeout == 600
        assert executor._semaphore is None
        assert executor._interrupted is False

    @pytest.mark.unit
    def test_custom_parameters(self) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=MagicMock(),
            concurrency=5,
            dry_run=True,
            timeout=300,
        )

        assert executor.concurrency == 5
        assert executor.dry_run is True
        assert executor.timeout == 300

    @pytest.mark.unit
    @pytest.mark.parametrize(
        ("input_value", "expected"),
        [
            (0, 1),
            (-1, 1),
            (-100, 1),
            (1, 1),
            (5, 5),
            (10, 10),
            (11, 10),
            (100, 10),
        ],
    )
    def test_concurrency_clamping(self, input_value: int, expected: int) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=MagicMock(),
            concurrency=input_value,
        )
        assert executor.concurrency == expected


class TestBatchExecutorExecuteJob:
    """Tests for BatchExecutor.execute_job()."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_empty_items_returns_job_unchanged(self) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=MagicMock(),
        )
        job = make_job(items=[])

        result = await executor.execute_job(job)

        assert result is job
        assert executor._semaphore is None

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_all_succeeded_items_returns_job_unchanged(self) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=MagicMock(),
        )
        job = make_job(
            items=[
                make_job_item(line_number=1, status=ItemStatus.SUCCEEDED),
                make_job_item(line_number=2, status=ItemStatus.SUCCEEDED),
            ]
        )

        result = await executor.execute_job(job)

        assert result is job
        assert executor._semaphore is None

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_all_failed_items_returns_job_unchanged(self) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=MagicMock(),
        )
        job = make_job(
            items=[
                make_job_item(line_number=1, status=ItemStatus.FAILED),
                make_job_item(line_number=2, status=ItemStatus.NEEDS_REVIEW),
            ]
        )

        result = await executor.execute_job(job)

        assert result is job
        assert executor._semaphore is None

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_pending_items_creates_semaphore(self, tmp_path: Path) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=make_mock_job_store(tmp_path),
            concurrency=5,
            dry_run=True,
        )
        job = make_job(items=[make_job_item(line_number=1, status=ItemStatus.PENDING)])

        await executor.execute_job(job)

        assert executor._semaphore is not None
        # Semaphore internal value should match concurrency
        assert executor._semaphore._value == 5  # type: ignore[attr-defined]

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_in_progress_items_creates_semaphore(self, tmp_path: Path) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=make_mock_job_store(tmp_path),
            concurrency=3,
            dry_run=True,
        )
        job = make_job(
            items=[make_job_item(line_number=1, status=ItemStatus.IN_PROGRESS)]
        )

        await executor.execute_job(job)

        assert executor._semaphore is not None

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_mixed_statuses_filters_correctly(self, tmp_path: Path) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=make_mock_job_store(tmp_path),
            dry_run=True,
        )
        job = make_job(
            items=[
                make_job_item(line_number=1, status=ItemStatus.PENDING),
                make_job_item(line_number=2, status=ItemStatus.SUCCEEDED),
                make_job_item(line_number=3, status=ItemStatus.IN_PROGRESS),
                make_job_item(line_number=4, status=ItemStatus.FAILED),
            ]
        )

        result = await executor.execute_job(job)

        # Semaphore should be created because there are PENDING/IN_PROGRESS items
        assert executor._semaphore is not None
        assert result is job


class TestBatchExecutorProcessingLoop:
    """Tests for the item processing loop in execute_job()."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_job_transitions_to_running(self, tmp_path: Path) -> None:
        user = make_user()
        number = make_number()
        operation = make_operation(status=OperationStatus.SUCCEEDED)
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)
        number_service.assign_number = AsyncMock(return_value=operation)

        job_store = make_mock_job_store(tmp_path)
        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=job_store,
        )
        job = make_job(items=[make_job_item()])

        await executor.execute_job(job)

        # Job should have transitioned through RUNNING to COMPLETED
        assert job.status == JobStatus.COMPLETED

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_started_at_set_on_first_run(self, tmp_path: Path) -> None:
        user = make_user()
        number = make_number()
        operation = make_operation(status=OperationStatus.SUCCEEDED)
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)
        number_service.assign_number = AsyncMock(return_value=operation)

        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=make_mock_job_store(tmp_path),
        )
        job = make_job(items=[make_job_item()])
        assert job.started_at is None

        await executor.execute_job(job)

        assert job.started_at is not None

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_started_at_not_overwritten_on_resume(self, tmp_path: Path) -> None:
        user = make_user()
        number = make_number()
        operation = make_operation(status=OperationStatus.SUCCEEDED)
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)
        number_service.assign_number = AsyncMock(return_value=operation)

        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=make_mock_job_store(tmp_path),
        )
        original_started = datetime(2024, 1, 1, tzinfo=timezone.utc)
        job = make_job(items=[make_job_item()])
        job.started_at = original_started

        await executor.execute_job(job)

        assert job.started_at == original_started

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_completed_at_set_on_finish(self, tmp_path: Path) -> None:
        user = make_user()
        number = make_number()
        operation = make_operation(status=OperationStatus.SUCCEEDED)
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)
        number_service.assign_number = AsyncMock(return_value=operation)

        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=make_mock_job_store(tmp_path),
        )
        job = make_job(items=[make_job_item()])

        await executor.execute_job(job)

        assert job.completed_at is not None

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_dry_run_succeeds_without_api_call(self, tmp_path: Path) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=make_mock_job_store(tmp_path),
            dry_run=True,
        )
        item = make_job_item()
        job = make_job(items=[item])

        await executor.execute_job(job)

        assert item.status == ItemStatus.SUCCEEDED
        assert item.completed_at is None
        assert item.attempts == 0

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_dry_run_multiple_items_all_succeed(self, tmp_path: Path) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=make_mock_job_store(tmp_path),
            dry_run=True,
        )
        items = [
            make_job_item(line_number=1, user_upn="user1@contoso.com"),
            make_job_item(line_number=2, user_upn="user2@contoso.com"),
            make_job_item(line_number=3, user_upn="user3@contoso.com"),
        ]
        job = make_job(items=items)

        await executor.execute_job(job)

        for item in items:
            assert item.status == ItemStatus.SUCCEEDED
            assert item.attempts == 0
            assert item.completed_at is None
        # Dry run should NOT change job status
        assert job.status == JobStatus.CREATED

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_dry_run_does_not_persist_state(self, tmp_path: Path) -> None:
        job_store = make_mock_job_store(tmp_path)
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=job_store,
            dry_run=True,
        )
        job = make_job(items=[make_job_item()])

        await executor.execute_job(job)

        # Dry run must never persist state to disk
        job_store.save_job.assert_not_called()

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_state_persisted_before_and_after_each_item(
        self, tmp_path: Path
    ) -> None:
        user = make_user()
        number = make_number()
        operation = make_operation(status=OperationStatus.SUCCEEDED)
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)
        number_service.assign_number = AsyncMock(return_value=operation)

        job_store = make_mock_job_store(tmp_path)
        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=job_store,
        )
        job = make_job(items=[make_job_item()])

        await executor.execute_job(job)

        # save_job called: 1 (RUNNING) + 1 (before) + 1 (after) + 1 (COMPLETED) = 4
        assert job_store.save_job.call_count == 4

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_state_persisted_for_multiple_items(self, tmp_path: Path) -> None:
        user = make_user()
        number = make_number()
        operation = make_operation(status=OperationStatus.SUCCEEDED)
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)
        number_service.assign_number = AsyncMock(return_value=operation)

        job_store = make_mock_job_store(tmp_path)
        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=job_store,
        )
        items = [make_job_item(line_number=1), make_job_item(line_number=2)]
        job = make_job(items=items)

        await executor.execute_job(job)

        # save_job called: 1 (RUNNING) + 2*(before+after) + 1 (COMPLETED) = 6
        assert job_store.save_job.call_count == 6

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_item_attempts_incremented(self, tmp_path: Path) -> None:
        user = make_user()
        number = make_number()
        operation = make_operation(status=OperationStatus.SUCCEEDED)
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)
        number_service.assign_number = AsyncMock(return_value=operation)

        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=make_mock_job_store(tmp_path),
        )
        item = make_job_item()
        assert item.attempts == 0
        job = make_job(items=[item])

        await executor.execute_job(job)

        assert item.attempts == 1

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_failed_item_gets_error_code_and_message(
        self, tmp_path: Path
    ) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=make_mock_job_store(tmp_path),
            dry_run=False,
        )
        item = make_job_item()
        job = make_job(items=[item])

        await executor.execute_job(job)

        # _assign_number raises NotImplementedError, so item should fail
        assert item.status == ItemStatus.FAILED
        assert item.error_code == "BATCH_007"
        assert item.error_message is not None
        assert item.completed_at is not None

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_item_with_3_plus_attempts_gets_needs_review(
        self, tmp_path: Path
    ) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=make_mock_job_store(tmp_path),
            dry_run=False,
        )
        item = make_job_item()
        item.attempts = 2  # Will be incremented to 3 during processing
        job = make_job(items=[item])

        await executor.execute_job(job)

        assert item.attempts == 3
        assert item.status == ItemStatus.NEEDS_REVIEW

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_item_with_2_attempts_stays_failed(self, tmp_path: Path) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=make_mock_job_store(tmp_path),
            dry_run=False,
        )
        item = make_job_item()
        item.attempts = 1  # Will be incremented to 2
        job = make_job(items=[item])

        await executor.execute_job(job)

        assert item.attempts == 2
        assert item.status == ItemStatus.FAILED

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_interrupted_flag_sets_interrupted_status(
        self, tmp_path: Path
    ) -> None:
        user = make_user()
        number = make_number()
        operation = make_operation(status=OperationStatus.SUCCEEDED)
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)
        number_service.assign_number = AsyncMock(return_value=operation)

        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=make_mock_job_store(tmp_path),
        )
        job = make_job(items=[make_job_item()])

        def set_interrupted() -> None:
            executor._interrupted = True

        with (
            patch.object(
                executor, "_setup_signal_handlers", side_effect=set_interrupted
            ),
            patch.object(executor, "_restore_signal_handlers"),
        ):
            await executor.execute_job(job)

        assert job.status == JobStatus.INTERRUPTED

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_interrupted_skips_item_processing(self, tmp_path: Path) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=make_mock_job_store(tmp_path),
            dry_run=True,
        )
        item = make_job_item()
        job = make_job(items=[item])

        def set_interrupted() -> None:
            executor._interrupted = True

        with (
            patch.object(
                executor, "_setup_signal_handlers", side_effect=set_interrupted
            ),
            patch.object(executor, "_restore_signal_handlers"),
        ):
            await executor.execute_job(job)

        # Item should remain PENDING since processing was skipped
        assert item.status == ItemStatus.PENDING
        assert item.attempts == 0

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_only_pending_and_in_progress_items_processed(
        self, tmp_path: Path
    ) -> None:
        user = make_user()
        number = make_number()
        operation = make_operation(status=OperationStatus.SUCCEEDED)
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)
        number_service.assign_number = AsyncMock(return_value=operation)

        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=make_mock_job_store(tmp_path),
        )
        pending_item = make_job_item(line_number=1, status=ItemStatus.PENDING)
        succeeded_item = make_job_item(line_number=2, status=ItemStatus.SUCCEEDED)
        in_progress_item = make_job_item(line_number=3, status=ItemStatus.IN_PROGRESS)
        failed_item = make_job_item(line_number=4, status=ItemStatus.FAILED)

        job = make_job(
            items=[pending_item, succeeded_item, in_progress_item, failed_item]
        )

        await executor.execute_job(job)

        # Only PENDING and IN_PROGRESS items should be processed
        assert pending_item.status == ItemStatus.SUCCEEDED
        assert pending_item.attempts == 1
        assert in_progress_item.status == ItemStatus.SUCCEEDED
        assert in_progress_item.attempts == 1
        # SUCCEEDED and FAILED items should remain unchanged
        assert succeeded_item.status == ItemStatus.SUCCEEDED
        assert succeeded_item.attempts == 0
        assert failed_item.status == ItemStatus.FAILED
        assert failed_item.attempts == 0

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_item_completed_at_timestamp_set(self, tmp_path: Path) -> None:
        user = make_user()
        number = make_number()
        operation = make_operation(status=OperationStatus.SUCCEEDED)
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)
        number_service.assign_number = AsyncMock(return_value=operation)

        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=make_mock_job_store(tmp_path),
        )
        item = make_job_item()
        assert item.completed_at is None
        job = make_job(items=[item])

        before = datetime.now(timezone.utc)
        await executor.execute_job(job)
        after = datetime.now(timezone.utc)

        assert item.completed_at is not None
        assert before <= item.completed_at <= after


class TestBatchExecutorSignalHandling:
    """Tests for SIGINT signal handler setup and behavior."""

    @pytest.mark.unit
    def test_setup_registers_sigint_handler(self) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=MagicMock(),
        )

        with patch("teams_phone.services.batch_executor.signal.signal") as mock_signal:
            mock_signal.return_value = signal.SIG_DFL
            executor._setup_signal_handlers()

            mock_signal.assert_called_once()
            args = mock_signal.call_args
            assert args[0][0] == signal.SIGINT

    @pytest.mark.unit
    def test_handler_sets_interrupted_flag(self) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=MagicMock(),
        )
        assert executor._interrupted is False

        # Capture the handler by calling _setup_signal_handlers with a mock
        captured_handler = None

        def capture_handler(signum: int, handler: object) -> signal.Handlers:
            nonlocal captured_handler
            captured_handler = handler
            return signal.SIG_DFL

        with patch(
            "teams_phone.services.batch_executor.signal.signal",
            side_effect=capture_handler,
        ):
            executor._setup_signal_handlers()

        assert captured_handler is not None
        captured_handler(signal.SIGINT, None)  # type: ignore[misc]
        assert executor._interrupted is True

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_execute_job_calls_setup_and_restore(self, tmp_path: Path) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=make_mock_job_store(tmp_path),
            dry_run=True,
        )
        job = make_job(items=[make_job_item()])

        with (
            patch.object(executor, "_setup_signal_handlers") as mock_setup,
            patch.object(executor, "_restore_signal_handlers") as mock_restore,
        ):
            await executor.execute_job(job)

            mock_setup.assert_called_once()
            mock_restore.assert_called_once()

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_original_handler_restored_after_execution(
        self, tmp_path: Path
    ) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=make_mock_job_store(tmp_path),
            dry_run=True,
        )
        job = make_job(items=[make_job_item()])

        original_handler = signal.getsignal(signal.SIGINT)

        with patch(
            "teams_phone.services.batch_executor.signal.signal",
            wraps=signal.signal,
        ) as mock_signal:
            await executor.execute_job(job)

            # Last call should restore the original handler
            last_call = mock_signal.call_args_list[-1]
            assert last_call[0][0] == signal.SIGINT

        # Handler should be restored to what it was before
        restored_handler = signal.getsignal(signal.SIGINT)
        assert restored_handler is original_handler

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_handler_restored_even_on_exception(self, tmp_path: Path) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=make_mock_job_store(tmp_path),
        )
        job = make_job(items=[make_job_item()])

        original_handler = signal.getsignal(signal.SIGINT)

        # Force an exception during execution by making save_job raise
        executor.job_store.save_job.side_effect = RuntimeError("test error")

        with pytest.raises(RuntimeError, match="test error"):
            await executor.execute_job(job)

        # Handler should still be restored despite the exception
        restored_handler = signal.getsignal(signal.SIGINT)
        assert restored_handler is original_handler

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_execute_job_resets_interrupted_flag(self, tmp_path: Path) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=make_mock_job_store(tmp_path),
            dry_run=True,
        )
        job = make_job(items=[make_job_item()])

        # Set interrupted from a previous run
        executor._interrupted = True

        # Execute with fresh items -- _interrupted should reset
        with (
            patch.object(executor, "_setup_signal_handlers"),
            patch.object(executor, "_restore_signal_handlers"),
        ):
            await executor.execute_job(job)

        # Items should be processed (flag was reset)
        assert job.items[0].status == ItemStatus.SUCCEEDED

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_no_signal_setup_when_no_items_to_process(self) -> None:
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=MagicMock(),
        )
        job = make_job(items=[])

        with patch.object(executor, "_setup_signal_handlers") as mock_setup:
            await executor.execute_job(job)

            mock_setup.assert_not_called()


class TestBatchExecutorAssignNumber:
    """Tests for BatchExecutor._assign_number() error handling and assignment logic."""

    USER_ID = "11111111-1111-1111-1111-111111111111"
    USER_UPN = "user@contoso.com"
    PHONE_NUMBER = "+14155551234"

    def _make_executor(
        self,
        user_service: MagicMock | None = None,
        number_service: MagicMock | None = None,
        timeout: int = 60,
        job_store: MagicMock | None = None,
    ) -> BatchExecutor:
        """Create a BatchExecutor with mocked services for _assign_number tests."""
        return BatchExecutor(
            user_service=user_service or MagicMock(),
            number_service=number_service or MagicMock(),
            job_store=job_store or MagicMock(),
            dry_run=False,
            timeout=timeout,
        )

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_successful_assignment(self) -> None:
        """Successful assign_number -> item SUCCEEDED."""
        user = make_user(id=self.USER_ID)
        number = make_number(telephone_number=self.PHONE_NUMBER)
        operation = make_operation(status=OperationStatus.SUCCEEDED)

        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)
        number_service.assign_number = AsyncMock(return_value=operation)

        executor = self._make_executor(user_service, number_service)
        item = make_job_item(user_upn=self.USER_UPN, phone_number=self.PHONE_NUMBER)
        job = make_job(items=[item])

        await executor._assign_number(item, job)

        assert item.status == ItemStatus.SUCCEEDED
        assert item.error_code is None
        number_service.assign_number.assert_awaited_once()

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_idempotent_already_assigned(self) -> None:
        """Number already assigned to target user -> SUCCEEDED with 'Already assigned'."""
        user = make_user(id=self.USER_ID)
        number = make_number(
            telephone_number=self.PHONE_NUMBER,
            assignment_target_id=self.USER_ID,
        )

        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)

        executor = self._make_executor(user_service, number_service)
        item = make_job_item(user_upn=self.USER_UPN, phone_number=self.PHONE_NUMBER)
        job = make_job(items=[item])

        await executor._assign_number(item, job)

        assert item.status == ItemStatus.SUCCEEDED
        assert item.error_message == "Already assigned"
        # assign_number should NOT have been called
        number_service.assign_number = AsyncMock()
        number_service.assign_number.assert_not_awaited()

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_user_not_found(self) -> None:
        """resolve_user raises NotFoundError -> FAILED with BATCH_003."""
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(
            side_effect=NotFoundError("User not found")
        )

        executor = self._make_executor(user_service)
        item = make_job_item(user_upn=self.USER_UPN, phone_number=self.PHONE_NUMBER)
        job = make_job(items=[item])

        await executor._assign_number(item, job)

        assert item.status == ItemStatus.FAILED
        assert item.error_code == "BATCH_003"
        assert "not found" in item.error_message

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_user_ambiguous_validation_error(self) -> None:
        """resolve_user raises ValidationError (ambiguous) -> FAILED with BATCH_002."""
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(
            side_effect=ValidationError("Multiple users match 'John'")
        )

        executor = self._make_executor(user_service)
        item = make_job_item(user_upn="John", phone_number=self.PHONE_NUMBER)
        job = make_job(items=[item])

        await executor._assign_number(item, job)

        assert item.status == ItemStatus.FAILED
        assert item.error_code == "BATCH_002"
        assert "Multiple users" in item.error_message

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_number_not_found(self) -> None:
        """get_number raises NotFoundError -> FAILED with BATCH_005."""
        user = make_user(id=self.USER_ID)
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(
            side_effect=NotFoundError("Phone number not found")
        )

        executor = self._make_executor(user_service, number_service)
        item = make_job_item(user_upn=self.USER_UPN, phone_number=self.PHONE_NUMBER)
        job = make_job(items=[item])

        await executor._assign_number(item, job)

        assert item.status == ItemStatus.FAILED
        assert item.error_code == "BATCH_005"
        assert "not found" in item.error_message

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_assignment_operation_failed(self) -> None:
        """assign_number returns FAILED operation -> FAILED with BATCH_007."""
        user = make_user(id=self.USER_ID)
        number = make_number(telephone_number=self.PHONE_NUMBER)
        operation = make_operation(status=OperationStatus.FAILED)

        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)
        number_service.assign_number = AsyncMock(return_value=operation)

        executor = self._make_executor(user_service, number_service)
        item = make_job_item(user_upn=self.USER_UPN, phone_number=self.PHONE_NUMBER)
        job = make_job(items=[item])

        await executor._assign_number(item, job)

        assert item.status == ItemStatus.FAILED
        assert item.error_code == "BATCH_007"
        assert "failed" in item.error_message

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_assignment_timeout(self) -> None:
        """assign_number raises TimeoutError -> FAILED with BATCH_008."""
        user = make_user(id=self.USER_ID)
        number = make_number(telephone_number=self.PHONE_NUMBER)

        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)
        number_service.assign_number = AsyncMock(
            side_effect=TimeoutError("Polling timed out")
        )

        executor = self._make_executor(user_service, number_service, timeout=30)
        item = make_job_item(user_upn=self.USER_UPN, phone_number=self.PHONE_NUMBER)
        job = make_job(items=[item])

        await executor._assign_number(item, job)

        assert item.status == ItemStatus.FAILED
        assert item.error_code == "BATCH_008"
        assert "timed out" in item.error_message

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_assignment_validation_error(self) -> None:
        """assign_number raises ValidationError (e.g., missing E911) -> FAILED with BATCH_002."""
        user = make_user(id=self.USER_ID)
        number = make_number(telephone_number=self.PHONE_NUMBER)

        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)
        number_service.assign_number = AsyncMock(
            side_effect=ValidationError("Emergency location required")
        )

        executor = self._make_executor(user_service, number_service)
        item = make_job_item(user_upn=self.USER_UPN, phone_number=self.PHONE_NUMBER)
        job = make_job(items=[item])

        await executor._assign_number(item, job)

        assert item.status == ItemStatus.FAILED
        assert item.error_code == "BATCH_002"
        assert "Emergency location" in item.error_message

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_network_error(self) -> None:
        """Generic exception during assignment -> FAILED with BATCH_011."""
        user = make_user(id=self.USER_ID)
        number = make_number(telephone_number=self.PHONE_NUMBER)

        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)
        number_service.assign_number = AsyncMock(
            side_effect=ConnectionError("Network unreachable")
        )

        executor = self._make_executor(user_service, number_service)
        item = make_job_item(user_upn=self.USER_UPN, phone_number=self.PHONE_NUMBER)
        job = make_job(items=[item])

        await executor._assign_number(item, job)

        assert item.status == ItemStatus.FAILED
        assert item.error_code == "BATCH_011"
        assert "Network unreachable" in item.error_message

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_skipped_operation_treated_as_failed(self) -> None:
        """assign_number returns SKIPPED operation -> FAILED with BATCH_007."""
        user = make_user(id=self.USER_ID)
        number = make_number(telephone_number=self.PHONE_NUMBER)
        operation = make_operation(status=OperationStatus.SKIPPED)

        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)
        number_service.assign_number = AsyncMock(return_value=operation)

        executor = self._make_executor(user_service, number_service)
        item = make_job_item(user_upn=self.USER_UPN, phone_number=self.PHONE_NUMBER)
        job = make_job(items=[item])

        await executor._assign_number(item, job)

        assert item.status == ItemStatus.FAILED
        assert item.error_code == "BATCH_007"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_assign_number_passes_correct_args(self) -> None:
        """Verify assign_number is called with correct user_id, phone_number, number_type."""
        user = make_user(id=self.USER_ID)
        number = make_number(telephone_number=self.PHONE_NUMBER)
        operation = make_operation(status=OperationStatus.SUCCEEDED)

        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)
        number_service.assign_number = AsyncMock(return_value=operation)

        executor = self._make_executor(user_service, number_service, timeout=120)
        item = make_job_item(user_upn=self.USER_UPN, phone_number=self.PHONE_NUMBER)
        job = make_job(items=[item])

        await executor._assign_number(item, job)

        number_service.assign_number.assert_awaited_once_with(
            user_id=self.USER_ID,
            phone_number=self.PHONE_NUMBER,
            number_type=number.number_type,
            wait=True,
            timeout=120,
        )

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_integration_through_execute_job(self, tmp_path: Path) -> None:
        """End-to-end: execute_job with dry_run=False calls _assign_number and succeeds."""
        user = make_user(id=self.USER_ID)
        number = make_number(telephone_number=self.PHONE_NUMBER)
        operation = make_operation(status=OperationStatus.SUCCEEDED)

        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=number)
        number_service.assign_number = AsyncMock(return_value=operation)

        executor = self._make_executor(
            user_service, number_service, job_store=make_mock_job_store(tmp_path)
        )
        item = make_job_item(user_upn=self.USER_UPN, phone_number=self.PHONE_NUMBER)
        job = make_job(items=[item])

        result = await executor.execute_job(job)

        assert item.status == ItemStatus.SUCCEEDED
        assert item.completed_at is not None
        assert item.attempts == 1
        assert result.status == JobStatus.COMPLETED

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_unhandled_error_falls_through_to_outer_handler(
        self, tmp_path: Path
    ) -> None:
        """Errors not caught by _assign_number fall to outer handler with BATCH_007."""
        user = make_user(id=self.USER_ID)

        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=user)
        number_service = MagicMock()
        # get_number raises a non-standard error that _assign_number doesn't catch
        # (NotFoundError and ValidationError are caught, but RuntimeError is not
        # caught at the get_number level -- it would be caught by the generic
        # Exception handler in the assign step, but get_number errors are only
        # caught as NotFoundError)
        number_service.get_number = AsyncMock(
            side_effect=RuntimeError("Unexpected internal error")
        )

        executor = self._make_executor(
            user_service, number_service, job_store=make_mock_job_store(tmp_path)
        )
        item = make_job_item(user_upn=self.USER_UPN, phone_number=self.PHONE_NUMBER)
        job = make_job(items=[item])

        # Call through execute_job so the outer handler catches it
        await executor.execute_job(job)

        assert item.status == ItemStatus.FAILED
        assert item.error_code == "BATCH_007"
        assert "Unexpected internal error" in item.error_message


class TestBatchExecutorProgressAndLogging:
    """Tests for progress callback integration and execution logging."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_progress_callback_called_after_each_item(
        self, tmp_path: Path
    ) -> None:
        """on_progress is invoked once per processed item."""
        callback = MagicMock()
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=make_mock_job_store(tmp_path),
            dry_run=True,
        )
        items = [
            make_job_item(line_number=1, user_upn="a@contoso.com"),
            make_job_item(line_number=2, user_upn="b@contoso.com"),
        ]
        job = make_job(items=items)

        await executor.execute_job(job, on_progress=callback)

        assert callback.call_count == 2

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_progress_callback_has_correct_counts(self, tmp_path: Path) -> None:
        """Progress snapshot reflects accurate succeeded/failed counts."""
        callback = MagicMock()
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=make_mock_job_store(tmp_path),
            dry_run=True,
        )
        job = make_job(items=[make_job_item()])

        await executor.execute_job(job, on_progress=callback)

        progress = callback.call_args[0][0]
        assert isinstance(progress, ExecutionProgress)
        assert progress.total == 1
        assert progress.completed == 1
        assert progress.succeeded == 1
        assert progress.failed == 0
        assert progress.current_item == "user@contoso.com"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_progress_callback_none_does_not_raise(self, tmp_path: Path) -> None:
        """on_progress=None (default) works without errors."""
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=make_user())
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=make_number())
        number_service.assign_number = AsyncMock(
            return_value=make_operation(status=OperationStatus.SUCCEEDED)
        )

        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=make_mock_job_store(tmp_path),
        )
        job = make_job(items=[make_job_item()])

        # Should not raise
        await executor.execute_job(job)

        assert job.status == JobStatus.COMPLETED

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_execution_log_file_created(self, tmp_path: Path) -> None:
        """execution.log is created in the job directory."""
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=make_user())
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=make_number())
        number_service.assign_number = AsyncMock(
            return_value=make_operation(status=OperationStatus.SUCCEEDED)
        )

        job_store = make_mock_job_store(tmp_path)
        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=job_store,
        )
        job = make_job(items=[make_job_item()])

        await executor.execute_job(job)

        log_path = job_store._job_dir(job.id) / "execution.log"
        assert log_path.exists()

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_log_contains_execution_start_entry(self, tmp_path: Path) -> None:
        """Log file begins with execution_start JSON event."""
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=make_user())
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=make_number())
        number_service.assign_number = AsyncMock(
            return_value=make_operation(status=OperationStatus.SUCCEEDED)
        )

        job_store = make_mock_job_store(tmp_path)
        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=job_store,
        )
        job = make_job(name="Migration Batch 1", items=[make_job_item()])

        await executor.execute_job(job)

        log_path = job_store._job_dir(job.id) / "execution.log"
        lines = log_path.read_text(encoding="utf-8").strip().splitlines()
        entry = json.loads(lines[0])
        assert entry["event"] == "execution_start"
        assert entry["job_id"] == job.id
        assert entry["total_items"] == 1

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_log_contains_item_entries(self, tmp_path: Path) -> None:
        """Log file contains per-item JSON entries with UPN, phone, and status."""
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=make_user())
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=make_number())
        number_service.assign_number = AsyncMock(
            return_value=make_operation(status=OperationStatus.SUCCEEDED)
        )

        job_store = make_mock_job_store(tmp_path)
        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=job_store,
        )
        item = make_job_item(user_upn="alice@contoso.com", phone_number="+12125551234")
        job = make_job(items=[item])

        await executor.execute_job(job)

        log_path = job_store._job_dir(job.id) / "execution.log"
        lines = log_path.read_text(encoding="utf-8").strip().splitlines()
        # Find the item_complete entry
        complete_entries = [
            json.loads(line)
            for line in lines
            if json.loads(line)["event"] == "item_complete"
        ]
        assert len(complete_entries) == 1
        entry = complete_entries[0]
        assert entry["user_upn"] == "alice@contoso.com"
        assert entry["phone_number"] == "+12125551234"
        assert entry["status"] == "succeeded"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_log_contains_execution_end_summary(self, tmp_path: Path) -> None:
        """Log file ends with execution_end JSON event."""
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=make_user())
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=make_number())
        number_service.assign_number = AsyncMock(
            return_value=make_operation(status=OperationStatus.SUCCEEDED)
        )

        job_store = make_mock_job_store(tmp_path)
        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=job_store,
        )
        items = [
            make_job_item(line_number=1, user_upn="a@contoso.com"),
            make_job_item(line_number=2, user_upn="b@contoso.com"),
        ]
        job = make_job(items=items)

        await executor.execute_job(job)

        log_path = job_store._job_dir(job.id) / "execution.log"
        lines = log_path.read_text(encoding="utf-8").strip().splitlines()
        entry = json.loads(lines[-1])
        assert entry["event"] == "execution_end"
        assert entry["status"] == "completed"
        assert entry["succeeded"] == 2
        assert entry["failed"] == 0

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_log_contains_interrupted_summary(self, tmp_path: Path) -> None:
        """Log file ends with execution_end event with interrupted status."""
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=make_user())
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=make_number())
        number_service.assign_number = AsyncMock(
            return_value=make_operation(status=OperationStatus.SUCCEEDED)
        )

        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=make_mock_job_store(tmp_path),
        )
        job = make_job(items=[make_job_item()])

        def set_interrupted() -> None:
            executor._interrupted = True

        with (
            patch.object(
                executor, "_setup_signal_handlers", side_effect=set_interrupted
            ),
            patch.object(executor, "_restore_signal_handlers"),
        ):
            await executor.execute_job(job)

        log_path = executor.job_store._job_dir(job.id) / "execution.log"
        lines = log_path.read_text(encoding="utf-8").strip().splitlines()
        entry = json.loads(lines[-1])
        assert entry["event"] == "execution_end"
        assert entry["status"] == "interrupted"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_log_appends_on_resume(self, tmp_path: Path) -> None:
        """Log file appends (not truncates) when resuming a job."""
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=make_user())
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=make_number())
        number_service.assign_number = AsyncMock(
            return_value=make_operation(status=OperationStatus.SUCCEEDED)
        )

        job_store = make_mock_job_store(tmp_path)
        log_path = job_store._job_dir("20240101-120000-abcd-test") / "execution.log"

        # Write pre-existing content to simulate a previous run
        log_path.write_text("previous-run-entry\n", encoding="utf-8")

        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=job_store,
        )
        job = make_job(items=[make_job_item()])

        await executor.execute_job(job)

        content = log_path.read_text(encoding="utf-8")
        assert content.startswith("previous-run-entry\n")
        # New entries should be valid JSON Lines
        new_lines = content.strip().splitlines()[1:]
        assert len(new_lines) >= 1
        first_new = json.loads(new_lines[0])
        assert first_new["event"] == "execution_start"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_failed_item_log_includes_error_details(self, tmp_path: Path) -> None:
        """Failed items include error code and message in the JSON log entry."""
        job_store = make_mock_job_store(tmp_path)
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=job_store,
            dry_run=False,
        )
        item = make_job_item()
        job = make_job(items=[item])

        await executor.execute_job(job)

        log_path = job_store._job_dir(job.id) / "execution.log"
        lines = log_path.read_text(encoding="utf-8").strip().splitlines()
        complete_entries = [
            json.loads(line)
            for line in lines
            if json.loads(line)["event"] == "item_complete"
        ]
        assert len(complete_entries) == 1
        entry = complete_entries[0]
        assert entry["status"] in ("failed", "needs_review")
        assert entry["error_code"] == "BATCH_007"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_log_entries_have_iso_timestamps(self, tmp_path: Path) -> None:
        """All JSON log entries contain ISO 8601 timestamps."""
        user_service = MagicMock()
        user_service.resolve_user = AsyncMock(return_value=make_user())
        number_service = MagicMock()
        number_service.get_number = AsyncMock(return_value=make_number())
        number_service.assign_number = AsyncMock(
            return_value=make_operation(status=OperationStatus.SUCCEEDED)
        )

        job_store = make_mock_job_store(tmp_path)
        executor = BatchExecutor(
            user_service=user_service,
            number_service=number_service,
            job_store=job_store,
        )
        job = make_job(items=[make_job_item()])

        await executor.execute_job(job)

        log_path = job_store._job_dir(job.id) / "execution.log"
        lines = log_path.read_text(encoding="utf-8").strip().splitlines()
        for line in lines:
            entry = json.loads(line)
            assert "timestamp" in entry
            # Should parse as a valid datetime
            datetime.fromisoformat(entry["timestamp"])

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_progress_reflects_mixed_outcomes(self, tmp_path: Path) -> None:
        """Progress callback reflects mixed succeeded/failed counts."""
        callback = MagicMock()
        job_store = make_mock_job_store(tmp_path)
        executor = BatchExecutor(
            user_service=MagicMock(),
            number_service=MagicMock(),
            job_store=job_store,
            dry_run=True,
            concurrency=1,
        )
        # Pre-set one item as already failed (won't be processed)
        items = [
            make_job_item(line_number=1, status=ItemStatus.FAILED),
            make_job_item(line_number=2, status=ItemStatus.PENDING),
        ]
        job = make_job(items=items)

        await executor.execute_job(job, on_progress=callback)

        # Only the PENDING item was processed
        assert callback.call_count == 1
        progress = callback.call_args[0][0]
        assert progress.total == 2
        # completed = SUCCEEDED + FAILED + NEEDS_REVIEW = 1 (succeeded) + 1 (pre-existing failed)
        assert progress.completed == 2
        assert progress.succeeded == 1
        assert progress.failed == 1
