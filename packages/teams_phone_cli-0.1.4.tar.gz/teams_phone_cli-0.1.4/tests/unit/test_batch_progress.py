"""Unit tests for _create_execution_progress helper function."""

from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest
from rich.progress import MofNCompleteColumn

from teams_phone.cli.batch import _create_execution_progress
from teams_phone.models.batch import ItemStatus, Job, JobItem, JobStatus


def _make_job(
    name: str = "test-job",
    item_count: int = 5,
    pending: int | None = None,
    succeeded: int = 0,
    failed: int = 0,
) -> Job:
    """Create a Job with specific item status counts.

    Args:
        name: Job name.
        item_count: Total items (used only when pending is None).
        pending: Explicit number of pending items. When set, total = succeeded + failed + pending.
        succeeded: Number of succeeded items.
        failed: Number of failed items.
    """
    now = datetime.now(timezone.utc)
    items: list[JobItem] = []

    for i in range(succeeded):
        items.append(
            JobItem(
                line_number=i + 2,
                user_upn=f"user{i}@example.com",
                phone_number=f"+1425555100{i}",
                status=ItemStatus.SUCCEEDED,
            )
        )

    for i in range(failed):
        items.append(
            JobItem(
                line_number=succeeded + i + 2,
                user_upn=f"failed{i}@example.com",
                phone_number=f"+1425555200{i}",
                status=ItemStatus.FAILED,
                error_code="BATCH_003",
                error_message="Test error",
            )
        )

    remaining = pending if pending is not None else item_count - succeeded - failed
    for i in range(remaining):
        items.append(
            JobItem(
                line_number=succeeded + failed + i + 2,
                user_upn=f"pending{i}@example.com",
                phone_number=f"+1425555300{i}",
                status=ItemStatus.PENDING,
            )
        )

    return Job(
        id="20260204-120000-abcd-test",
        name=name,
        status=JobStatus.VALIDATED,
        created_at=now,
        updated_at=now,
        input_file="/path/to/test.csv",
        input_hash="abc123" * 10 + "abcd",
        items=items,
    )


def _make_formatter() -> MagicMock:
    """Create a mock OutputFormatter with get_spinner_name."""
    formatter = MagicMock()
    formatter.get_spinner_name.return_value = "dots"
    return formatter


class TestCreateExecutionProgress:
    """Tests for the _create_execution_progress helper."""

    @pytest.mark.unit
    def test_new_job_starts_at_zero(self) -> None:
        """New job (all items pending) starts progress at 0 completed."""
        job = _make_job(item_count=10)
        formatter = _make_formatter()

        progress, task_id = _create_execution_progress(
            job, formatter, action="Executing"
        )

        tasks = progress.tasks
        assert len(tasks) == 1
        assert tasks[0].completed == 0
        assert tasks[0].total == 10

    @pytest.mark.unit
    def test_resumed_job_starts_at_already_completed(self) -> None:
        """Resumed job starts progress at the already-completed count."""
        job = _make_job(succeeded=5, pending=3)
        formatter = _make_formatter()

        progress, task_id = _create_execution_progress(
            job, formatter, action="Resuming"
        )

        tasks = progress.tasks
        assert tasks[0].completed == 5
        assert tasks[0].total == 8

    @pytest.mark.unit
    def test_description_shows_executing_for_new_jobs(self) -> None:
        """Description shows 'Executing' action for new jobs."""
        job = _make_job(name="q1-migration", item_count=3)
        formatter = _make_formatter()

        progress, _ = _create_execution_progress(job, formatter, action="Executing")

        assert progress.tasks[0].description == "Executing q1-migration..."

    @pytest.mark.unit
    def test_description_shows_resuming_for_resumed_jobs(self) -> None:
        """Description shows 'Resuming' action for resumed jobs."""
        job = _make_job(name="q1-migration", succeeded=2, pending=1)
        formatter = _make_formatter()

        progress, _ = _create_execution_progress(job, formatter, action="Resuming")

        assert progress.tasks[0].description == "Resuming q1-migration..."

    @pytest.mark.unit
    def test_description_shows_retrying_for_retried_jobs(self) -> None:
        """Description shows 'Retrying' action for retried jobs."""
        job = _make_job(name="q1-migration", succeeded=2, failed=1, pending=1)
        formatter = _make_formatter()

        progress, _ = _create_execution_progress(job, formatter, action="Retrying")

        assert progress.tasks[0].description == "Retrying q1-migration..."

    @pytest.mark.unit
    def test_json_mode_disables_progress(self) -> None:
        """JSON mode sets disable=True on the Progress instance."""
        job = _make_job(item_count=3)
        formatter = _make_formatter()

        progress, _ = _create_execution_progress(
            job, formatter, action="Executing", json_mode=True
        )

        assert progress.disable is True

    @pytest.mark.unit
    def test_progress_enabled_by_default(self) -> None:
        """Progress is enabled when json_mode is False (default)."""
        job = _make_job(item_count=3)
        formatter = _make_formatter()

        progress, _ = _create_execution_progress(job, formatter, action="Executing")

        assert progress.disable is False

    @pytest.mark.unit
    def test_no_color_passed_to_console(self) -> None:
        """no_color flag is passed through to the Console."""
        job = _make_job(item_count=3)
        formatter = _make_formatter()

        with patch("teams_phone.cli.batch.Console") as mock_console_cls:
            mock_console_cls.return_value = MagicMock()

            _create_execution_progress(
                job, formatter, action="Executing", no_color=True
            )

            mock_console_cls.assert_called_once_with(no_color=True)

    @pytest.mark.unit
    def test_uses_mofn_complete_column(self) -> None:
        """Progress bar uses MofNCompleteColumn for '45/500' style display."""
        job = _make_job(item_count=3)
        formatter = _make_formatter()

        progress, _ = _create_execution_progress(job, formatter, action="Executing")

        column_types = [type(col) for col in progress.columns]
        assert MofNCompleteColumn in column_types

    @pytest.mark.unit
    def test_uses_formatter_spinner_name(self) -> None:
        """Progress bar uses the spinner name from the formatter."""
        job = _make_job(item_count=3)
        formatter = _make_formatter()
        formatter.get_spinner_name.return_value = "line"

        progress, _ = _create_execution_progress(job, formatter, action="Executing")

        formatter.get_spinner_name.assert_called_once()

    @pytest.mark.unit
    def test_returns_valid_task_id(self) -> None:
        """Returns a valid TaskID that can be used with progress.update."""
        job = _make_job(item_count=5)
        formatter = _make_formatter()

        progress, task_id = _create_execution_progress(
            job, formatter, action="Executing"
        )

        # TaskID should reference a valid task in the progress bar
        assert progress.tasks[task_id] is not None

    @pytest.mark.unit
    def test_progress_is_context_manager(self) -> None:
        """Returned Progress can be used as a context manager."""
        job = _make_job(item_count=3)
        formatter = _make_formatter()

        progress, task_id = _create_execution_progress(
            job, formatter, action="Executing"
        )

        with progress:
            progress.update(task_id, completed=1)
            assert progress.tasks[0].completed == 1

    @pytest.mark.unit
    def test_mixed_status_items_counted_correctly(self) -> None:
        """Jobs with succeeded + failed items count both as completed."""
        job = _make_job(succeeded=3, failed=2, pending=5)
        formatter = _make_formatter()

        progress, _ = _create_execution_progress(job, formatter, action="Retrying")

        assert progress.tasks[0].total == 10
        assert progress.tasks[0].completed == 5
