"""Unit tests for batch create CLI command."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.models.batch import ItemStatus, Job, JobItem, JobStatus
from tests.conftest import CliRunner


runner = CliRunner()


def make_job(
    job_id: str = "20260204-120000-abcd-test",
    name: str = "test",
    item_count: int = 2,
) -> Job:
    """Create a Job instance for testing."""
    from datetime import datetime, timezone

    now = datetime.now(timezone.utc)
    items = [
        JobItem(
            line_number=i + 2,
            user_upn=f"user{i}@example.com",
            phone_number=f"+1425555000{i}",
            status=ItemStatus.PENDING,
        )
        for i in range(item_count)
    ]
    return Job(
        id=job_id,
        name=name,
        status=JobStatus.CREATED,
        created_at=now,
        updated_at=now,
        input_file="/path/to/test.csv",
        input_hash="abc123" * 10 + "abcd",
        items=items,
    )


class TestBatchCreateCommand:
    """Tests for the batch create command."""

    @pytest.mark.unit
    def test_help_shows_usage(self) -> None:
        """Help displays command usage."""
        result = runner.invoke(app, ["batch", "create", "--help"])
        assert result.exit_code == 0
        assert "Create a batch migration job" in result.stdout

    @pytest.mark.unit
    def test_no_args_shows_help(self) -> None:
        """batch create without args shows help."""
        result = runner.invoke(app, ["batch", "--help"])
        assert result.exit_code == 0
        assert "create" in result.stdout

    @pytest.mark.unit
    def test_batch_command_group_exists(self) -> None:
        """batch command group is registered."""
        result = runner.invoke(app, ["--help"])
        assert "batch" in result.stdout
        assert "Batch migration operations" in result.stdout

    @pytest.mark.unit
    def test_valid_csv_creates_job(self, tmp_path: Path) -> None:
        """Valid CSV creates a job with correct structure."""
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(
            "user_upn,phone_number\n"
            "user1@example.com,+14255551234\n"
            "user2@example.com,+14255555678\n"
        )

        mock_job = make_job(name="test")

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.create_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "create", str(csv_file)])

            assert result.exit_code == 0
            assert "Created job:" in result.plain_stdout
            assert mock_job.id in result.plain_stdout
            mock_store.create_job.assert_called_once()

    @pytest.mark.unit
    def test_custom_name_option(self, tmp_path: Path) -> None:
        """--name option sets custom job name."""
        csv_file = tmp_path / "test.csv"
        csv_file.write_text("user_upn,phone_number\nuser1@example.com,+14255551234\n")

        mock_job = make_job(name="Custom Migration")

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.create_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app, ["batch", "create", str(csv_file), "--name", "Custom Migration"]
            )

            assert result.exit_code == 0
            # Verify name was passed to create_job
            call_kwargs = mock_store.create_job.call_args
            assert call_kwargs.kwargs["name"] == "Custom Migration"

    @pytest.mark.unit
    def test_name_defaults_to_filename_stem(self, tmp_path: Path) -> None:
        """Job name defaults to CSV filename without extension."""
        csv_file = tmp_path / "my-migration.csv"
        csv_file.write_text("user_upn,phone_number\nuser1@example.com,+14255551234\n")

        mock_job = make_job(name="my-migration")

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.create_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "create", str(csv_file)])

            assert result.exit_code == 0
            call_kwargs = mock_store.create_job.call_args
            assert call_kwargs.kwargs["name"] == "my-migration"

    @pytest.mark.unit
    def test_json_output_format(self, tmp_path: Path) -> None:
        """--json flag outputs JSON format."""
        csv_file = tmp_path / "test.csv"
        csv_file.write_text("user_upn,phone_number\nuser1@example.com,+14255551234\n")

        mock_job = make_job()

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.create_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["--json", "batch", "create", str(csv_file)])

            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data["job_id"] == mock_job.id
            assert data["name"] == mock_job.name
            assert data["status"] == "created"
            assert data["item_count"] == 2

    @pytest.mark.unit
    def test_displays_next_steps(self, tmp_path: Path) -> None:
        """Success output shows next steps guidance."""
        csv_file = tmp_path / "test.csv"
        csv_file.write_text("user_upn,phone_number\nuser1@example.com,+14255551234\n")

        mock_job = make_job()

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.create_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "create", str(csv_file)])

            assert result.exit_code == 0
            assert "Next steps:" in result.stdout
            assert "batch validate" in result.stdout
            assert "batch run" in result.stdout


class TestBatchCreateValidation:
    """Tests for CSV validation in batch create."""

    @pytest.mark.unit
    def test_missing_file_error(self, tmp_path: Path) -> None:
        """Non-existent file produces error."""
        csv_file = tmp_path / "nonexistent.csv"

        result = runner.invoke(app, ["batch", "create", str(csv_file)])

        # Typer handles file existence check before our code
        assert result.exit_code != 0

    @pytest.mark.unit
    def test_empty_file_error(self, tmp_path: Path) -> None:
        """Empty CSV produces validation error."""
        csv_file = tmp_path / "empty.csv"
        csv_file.write_text("")

        result = runner.invoke(app, ["batch", "create", str(csv_file)])

        assert result.exit_code == 5  # ValidationError exit code
        assert "empty" in result.stdout.lower()

    @pytest.mark.unit
    def test_missing_required_columns_error(self, tmp_path: Path) -> None:
        """CSV missing required columns produces error."""
        csv_file = tmp_path / "bad.csv"
        csv_file.write_text("name,email\njohn,john@example.com\n")

        result = runner.invoke(app, ["batch", "create", str(csv_file)])

        assert result.exit_code == 5  # ValidationError exit code

    @pytest.mark.unit
    def test_invalid_phone_number_error(self, tmp_path: Path) -> None:
        """Invalid phone number format produces error."""
        csv_file = tmp_path / "bad.csv"
        csv_file.write_text("user_upn,phone_number\nuser@example.com,not-a-phone\n")

        result = runner.invoke(app, ["batch", "create", str(csv_file)])

        assert result.exit_code == 5  # ValidationError exit code

    @pytest.mark.unit
    def test_duplicate_phone_error(self, tmp_path: Path) -> None:
        """Duplicate phone numbers produce error."""
        csv_file = tmp_path / "dupes.csv"
        csv_file.write_text(
            "user_upn,phone_number\n"
            "user1@example.com,+14255551234\n"
            "user2@example.com,+14255551234\n"
        )

        result = runner.invoke(app, ["batch", "create", str(csv_file)])

        assert result.exit_code == 5  # ValidationError exit code
        assert "duplicate" in result.stdout.lower()


class TestBatchCreateWarnings:
    """Tests for warning handling in batch create."""

    @pytest.mark.unit
    def test_extension_warning_displayed(self, tmp_path: Path) -> None:
        """Warnings about extension stripping are displayed."""
        csv_file = tmp_path / "test.csv"
        csv_file.write_text(
            "user_upn,phone_number\nuser1@example.com,+14255551234;ext=100\n"
        )

        mock_job = make_job(item_count=1)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.create_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "create", str(csv_file)])

            assert result.exit_code == 0
            # Warning about extension should be in output
            assert "extension" in result.stdout.lower()


class TestBatchCreateEdgeCases:
    """Tests for edge cases in batch create."""

    @pytest.mark.unit
    def test_short_name_option(self, tmp_path: Path) -> None:
        """-n short option works for name."""
        csv_file = tmp_path / "test.csv"
        csv_file.write_text("user_upn,phone_number\nuser1@example.com,+14255551234\n")

        mock_job = make_job(name="Short")

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.create_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app, ["batch", "create", str(csv_file), "-n", "Short"]
            )

            assert result.exit_code == 0
            call_kwargs = mock_store.create_job.call_args
            assert call_kwargs.kwargs["name"] == "Short"

    @pytest.mark.unit
    def test_csv_with_bom(self, tmp_path: Path) -> None:
        """CSV with UTF-8 BOM is parsed correctly."""
        csv_file = tmp_path / "bom.csv"
        # Write with BOM
        csv_file.write_bytes(
            b"\xef\xbb\xbf"  # UTF-8 BOM
            b"user_upn,phone_number\n"
            b"user@example.com,+14255551234\n"
        )

        mock_job = make_job(item_count=1)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.create_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "create", str(csv_file)])

            assert result.exit_code == 0
            mock_store.create_job.assert_called_once()

    @pytest.mark.unit
    def test_csv_with_crlf_line_endings(self, tmp_path: Path) -> None:
        """CSV with Windows CRLF line endings is parsed correctly."""
        csv_file = tmp_path / "crlf.csv"
        csv_file.write_bytes(
            b"user_upn,phone_number\r\nuser@example.com,+14255551234\r\n"
        )

        mock_job = make_job(item_count=1)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.create_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "create", str(csv_file)])

            assert result.exit_code == 0
            mock_store.create_job.assert_called_once()
