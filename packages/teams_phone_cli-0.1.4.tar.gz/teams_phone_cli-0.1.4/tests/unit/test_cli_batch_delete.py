"""Unit tests for batch delete CLI command."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.exceptions import NotFoundError
from teams_phone.models.batch import ItemStatus, Job, JobItem, JobStatus
from tests.conftest import CliRunner


runner = CliRunner()


def make_job(
    job_id: str = "20260204-120000-abcd-test",
    name: str = "test",
    status: JobStatus = JobStatus.COMPLETED,
    item_count: int = 2,
    failed_count: int = 0,
) -> Job:
    """Create a Job instance for testing."""
    now = datetime.now(timezone.utc)
    items: list[JobItem] = []

    for i in range(item_count):
        item_status = ItemStatus.FAILED if i < failed_count else ItemStatus.SUCCEEDED
        items.append(
            JobItem(
                line_number=i + 2,
                user_upn=f"user{i}@example.com",
                phone_number=f"+1425555100{i}",
                status=item_status,
            )
        )

    return Job(
        id=job_id,
        name=name,
        status=status,
        created_at=now,
        updated_at=now,
        started_at=now if status != JobStatus.CREATED else None,
        completed_at=now if status == JobStatus.COMPLETED else None,
        input_file="/path/to/test.csv",
        input_hash="abc123" * 10 + "abcd",
        items=items,
    )


class TestBatchDeleteForce:
    """Tests for batch delete with --force flag."""

    @pytest.mark.unit
    def test_delete_force_skips_confirmation(self) -> None:
        """delete --force skips confirmation and deletes the job."""
        mock_job = make_job()
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app, ["batch", "delete", "20260204-120000-abcd-test", "--force"]
            )

            assert result.exit_code == 0
            assert "Deleted job" in result.plain_stdout
            mock_store.delete_job.assert_called_once_with("20260204-120000-abcd-test")

    @pytest.mark.unit
    def test_delete_force_short_flag(self) -> None:
        """delete -f short flag works the same as --force."""
        mock_job = make_job()
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app, ["batch", "delete", "20260204-120000-abcd-test", "-f"]
            )

            assert result.exit_code == 0
            assert "Deleted job" in result.plain_stdout
            mock_store.delete_job.assert_called_once()


class TestBatchDeleteConfirmation:
    """Tests for batch delete confirmation prompt."""

    @pytest.mark.unit
    def test_delete_confirmed(self) -> None:
        """delete proceeds when user confirms with 'y'."""
        mock_job = make_job(failed_count=1)
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app,
                ["batch", "delete", "20260204-120000-abcd-test"],
                input="y\n",
            )

            assert result.exit_code == 0
            assert "Deleted job" in result.plain_stdout
            mock_store.delete_job.assert_called_once_with("20260204-120000-abcd-test")

    @pytest.mark.unit
    def test_delete_cancelled(self) -> None:
        """delete is cancelled when user answers 'n'."""
        mock_job = make_job()
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app,
                ["batch", "delete", "20260204-120000-abcd-test"],
                input="n\n",
            )

            assert result.exit_code == 0
            assert "cancelled" in result.plain_stdout.lower()
            mock_store.delete_job.assert_not_called()

    @pytest.mark.unit
    def test_confirmation_shows_job_details(self) -> None:
        """Confirmation prompt includes job name, item count, and results."""
        mock_job = make_job(name="q1-migration", item_count=5, failed_count=2)
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app,
                ["batch", "delete", "20260204-120000-abcd-test"],
                input="n\n",
            )

            # Prompt should show job name, total items, succeeded, and failed
            output = result.plain_stdout.lower()
            assert "q1-migration" in output
            assert "5 items" in output
            assert "3 succeeded" in output
            assert "2 failed" in output


class TestBatchDeleteErrors:
    """Tests for batch delete error handling."""

    @pytest.mark.unit
    def test_delete_nonexistent_job(self) -> None:
        """delete shows error when job does not exist."""
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.side_effect = NotFoundError(
                "Job 'no-such-job' not found"
            )
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "delete", "no-such-job", "--force"])

            assert result.exit_code == 4
            assert "not found" in result.plain_stdout.lower()
            mock_store.delete_job.assert_not_called()

    @pytest.mark.unit
    def test_delete_running_job(self) -> None:
        """delete refuses to delete a running job."""
        mock_job = make_job(status=JobStatus.RUNNING)
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app, ["batch", "delete", "20260204-120000-abcd-test", "--force"]
            )

            assert result.exit_code == 5
            assert "running" in result.plain_stdout.lower()
            mock_store.delete_job.assert_not_called()


class TestBatchDeleteStates:
    """Tests for batch delete across different job states."""

    @pytest.mark.unit
    @pytest.mark.parametrize(
        "status",
        [
            JobStatus.CREATED,
            JobStatus.VALIDATED,
            JobStatus.COMPLETED,
            JobStatus.INTERRUPTED,
            JobStatus.VALIDATING,
        ],
    )
    def test_delete_allowed_for_non_running_states(self, status: JobStatus) -> None:
        """delete succeeds for all non-RUNNING states."""
        mock_job = make_job(status=status)
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app, ["batch", "delete", "20260204-120000-abcd-test", "--force"]
            )

            assert result.exit_code == 0
            mock_store.delete_job.assert_called_once()


class TestBatchDeleteJsonOutput:
    """Tests for batch delete JSON output mode."""

    @pytest.mark.unit
    def test_delete_json_output(self) -> None:
        """delete --json outputs structured JSON response."""
        mock_job = make_job()
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app,
                ["--json", "batch", "delete", "20260204-120000-abcd-test", "--force"],
            )

            assert result.exit_code == 0
            data = json.loads(result.plain_stdout)
            assert data["status"] == "deleted"
            assert data["job_id"] == "20260204-120000-abcd-test"


class TestBatchDeleteHelp:
    """Tests for batch delete help output."""

    @pytest.mark.unit
    def test_delete_help(self) -> None:
        """delete --help shows usage information."""
        result = runner.invoke(app, ["batch", "delete", "--help"])

        assert result.exit_code == 0
        output = result.plain_stdout
        assert "delete" in output.lower()
        assert "job-id" in output.lower() or "JOB_ID" in output

    @pytest.mark.unit
    def test_batch_help_shows_delete(self) -> None:
        """batch --help lists the delete subcommand."""
        result = runner.invoke(app, ["batch", "--help"])

        assert result.exit_code == 0
        assert "delete" in result.plain_stdout.lower()
