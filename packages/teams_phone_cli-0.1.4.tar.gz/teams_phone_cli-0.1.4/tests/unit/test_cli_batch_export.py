"""Unit tests for batch export CLI command."""

from __future__ import annotations

import csv
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.exceptions import NotFoundError
from teams_phone.models.batch import ItemStatus, Job, JobItem, JobStatus
from tests.conftest import CliRunner


runner = CliRunner()


def make_job(
    job_id: str = "20260204-120000-abcd-test",
    name: str = "Test Export",
    status: JobStatus = JobStatus.COMPLETED,
    item_count: int = 3,
    failed_count: int = 0,
    succeeded_count: int = 0,
    needs_review_count: int = 0,
) -> Job:
    """Create a Job instance for testing.

    Args:
        job_id: Unique job identifier.
        name: Job name.
        status: Job lifecycle status.
        item_count: Total number of items to create.
        failed_count: Number of items to mark as failed.
        succeeded_count: Number of items to mark as succeeded.
        needs_review_count: Number of items to mark as needs_review.
    """
    now = datetime.now(timezone.utc)
    items: list[JobItem] = []

    for i in range(failed_count):
        items.append(
            JobItem(
                line_number=i + 2,
                user_upn=f"failed{i}@example.com",
                phone_number=f"+1425555100{i}",
                status=ItemStatus.FAILED,
                attempts=3,
                error_code="UserNotFound",
                error_message=f"User failed{i}@example.com not found in tenant",
            )
        )

    for i in range(succeeded_count):
        items.append(
            JobItem(
                line_number=i + 2 + failed_count,
                user_upn=f"success{i}@example.com",
                phone_number=f"+1425555200{i}",
                status=ItemStatus.SUCCEEDED,
                completed_at=now,
            )
        )

    for i in range(needs_review_count):
        items.append(
            JobItem(
                line_number=i + 2 + failed_count + succeeded_count,
                user_upn=f"review{i}@example.com",
                phone_number=f"+1425555300{i}",
                status=ItemStatus.NEEDS_REVIEW,
                error_code="AlreadyAssigned",
                error_message="User already has a phone number assigned",
                attempts=1,
            )
        )

    pending_count = item_count - failed_count - succeeded_count - needs_review_count
    for i in range(pending_count):
        items.append(
            JobItem(
                line_number=i + 2 + failed_count + succeeded_count + needs_review_count,
                user_upn=f"pending{i}@example.com",
                phone_number=f"+1425555400{i}",
                status=ItemStatus.PENDING,
            )
        )

    return Job(
        id=job_id,
        name=name,
        status=status,
        created_at=now,
        updated_at=now,
        started_at=now
        if status in (JobStatus.RUNNING, JobStatus.COMPLETED, JobStatus.INTERRUPTED)
        else None,
        completed_at=now if status == JobStatus.COMPLETED else None,
        input_file="/path/to/test.csv",
        input_hash="abc123" * 10 + "abcd",
        items=items,
    )


class TestBatchExportCommand:
    """Tests for the batch export command basics."""

    @pytest.mark.unit
    def test_help_shows_usage(self) -> None:
        """Help displays command usage."""
        result = runner.invoke(app, ["batch", "export", "--help"])
        assert result.exit_code == 0
        assert "Export" in result.stdout

    @pytest.mark.unit
    def test_batch_command_shows_export(self) -> None:
        """batch --help shows export subcommand."""
        result = runner.invoke(app, ["batch", "--help"])
        assert result.exit_code == 0
        assert "export" in result.stdout


class TestBatchExportFilterValidation:
    """Tests for filter validation."""

    @pytest.mark.unit
    def test_no_filter_shows_error(self) -> None:
        """No filter specified shows validation error."""
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "export", "test-job"])

            assert result.exit_code == 5
            assert "Exactly one filter" in result.plain_stdout

    @pytest.mark.unit
    def test_multiple_filters_shows_error(self) -> None:
        """Multiple filters specified shows validation error."""
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app, ["batch", "export", "test-job", "--failed", "--succeeded"]
            )

            assert result.exit_code == 5
            assert "Exactly one filter" in result.plain_stdout


class TestBatchExportStateValidation:
    """Tests for job state validation."""

    @pytest.mark.unit
    def test_created_state_rejected(self) -> None:
        """Job in created state cannot be exported."""
        mock_job = make_job(status=JobStatus.CREATED)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "export", "test-job", "--failed"])

            assert result.exit_code == 5
            assert "cannot be exported" in result.plain_stdout

    @pytest.mark.unit
    def test_running_state_rejected(self) -> None:
        """Job in running state cannot be exported."""
        mock_job = make_job(status=JobStatus.RUNNING)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "export", "test-job", "--failed"])

            assert result.exit_code == 5
            assert "cannot be exported" in result.plain_stdout

    @pytest.mark.unit
    def test_completed_state_allowed(self, tmp_path: Path) -> None:
        """Job in completed state can be exported."""
        mock_job = make_job(
            status=JobStatus.COMPLETED,
            item_count=2,
            succeeded_count=2,
        )

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app,
                [
                    "batch",
                    "export",
                    "test-job",
                    "--succeeded",
                    "--output",
                    str(tmp_path / "out.csv"),
                ],
            )

            assert result.exit_code == 0

    @pytest.mark.unit
    def test_interrupted_state_allowed(self, tmp_path: Path) -> None:
        """Job in interrupted state can be exported."""
        mock_job = make_job(
            status=JobStatus.INTERRUPTED,
            item_count=2,
            failed_count=1,
            succeeded_count=1,
        )

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app,
                [
                    "batch",
                    "export",
                    "test-job",
                    "--failed",
                    "--output",
                    str(tmp_path / "out.csv"),
                ],
            )

            assert result.exit_code == 0

    @pytest.mark.unit
    def test_validated_state_allowed(self, tmp_path: Path) -> None:
        """Job in validated state can be exported."""
        mock_job = make_job(
            status=JobStatus.VALIDATED,
            item_count=2,
            succeeded_count=0,
        )

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app,
                [
                    "batch",
                    "export",
                    "test-job",
                    "--all",
                    "--output",
                    str(tmp_path / "out.csv"),
                ],
            )

            assert result.exit_code == 0


class TestBatchExportFiltering:
    """Tests for item filtering by status."""

    @pytest.mark.unit
    def test_failed_filter_exports_failed_and_needs_review(
        self, tmp_path: Path
    ) -> None:
        """--failed exports only FAILED and NEEDS_REVIEW items."""
        mock_job = make_job(
            status=JobStatus.COMPLETED,
            item_count=5,
            failed_count=2,
            succeeded_count=2,
            needs_review_count=1,
        )
        output_file = tmp_path / "failed.csv"

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app,
                [
                    "batch",
                    "export",
                    "test-job",
                    "--failed",
                    "--output",
                    str(output_file),
                ],
            )

            assert result.exit_code == 0
            assert "3 items" in result.plain_stdout

            rows = _read_csv(output_file)
            assert len(rows) == 3
            upns = {row["user_upn"] for row in rows}
            assert "failed0@example.com" in upns
            assert "failed1@example.com" in upns
            assert "review0@example.com" in upns

    @pytest.mark.unit
    def test_succeeded_filter_exports_only_succeeded(self, tmp_path: Path) -> None:
        """--succeeded exports only SUCCEEDED items."""
        mock_job = make_job(
            status=JobStatus.COMPLETED,
            item_count=5,
            failed_count=2,
            succeeded_count=3,
        )
        output_file = tmp_path / "succeeded.csv"

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app,
                [
                    "batch",
                    "export",
                    "test-job",
                    "--succeeded",
                    "--output",
                    str(output_file),
                ],
            )

            assert result.exit_code == 0
            assert "3 items" in result.plain_stdout

            rows = _read_csv(output_file)
            assert len(rows) == 3
            assert all(row["user_upn"].startswith("success") for row in rows)

    @pytest.mark.unit
    def test_all_filter_exports_all_items(self, tmp_path: Path) -> None:
        """--all exports all items regardless of status."""
        mock_job = make_job(
            status=JobStatus.COMPLETED,
            item_count=5,
            failed_count=1,
            succeeded_count=2,
            needs_review_count=1,
        )
        output_file = tmp_path / "all.csv"

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app,
                ["batch", "export", "test-job", "--all", "--output", str(output_file)],
            )

            assert result.exit_code == 0
            assert "5 items" in result.plain_stdout

            rows = _read_csv(output_file)
            assert len(rows) == 5

    @pytest.mark.unit
    def test_empty_result_no_file_written(self, tmp_path: Path) -> None:
        """Empty result set shows message, no file written."""
        mock_job = make_job(
            status=JobStatus.COMPLETED,
            item_count=3,
            succeeded_count=3,
        )
        output_file = tmp_path / "failed.csv"

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app,
                [
                    "batch",
                    "export",
                    "test-job",
                    "--failed",
                    "--output",
                    str(output_file),
                ],
            )

            assert result.exit_code == 0
            assert "No failed items" in result.plain_stdout
            assert not output_file.exists()


class TestBatchExportCsvContent:
    """Tests for CSV content and column structure."""

    @pytest.mark.unit
    def test_failed_export_includes_error_columns(self, tmp_path: Path) -> None:
        """Failed export CSV includes status, error_code, error_message, attempts."""
        mock_job = make_job(
            status=JobStatus.COMPLETED,
            item_count=2,
            failed_count=1,
            succeeded_count=1,
        )
        output_file = tmp_path / "failed.csv"

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            runner.invoke(
                app,
                [
                    "batch",
                    "export",
                    "test-job",
                    "--failed",
                    "--output",
                    str(output_file),
                ],
            )

            rows = _read_csv(output_file)
            assert len(rows) == 1
            row = rows[0]
            assert row["user_upn"] == "failed0@example.com"
            assert row["phone_number"] == "+14255551000"
            assert row["status"] == "failed"
            assert row["error_code"] == "UserNotFound"
            assert "not found" in row["error_message"]
            assert row["attempts"] == "3"

    @pytest.mark.unit
    def test_succeeded_export_has_only_base_columns(self, tmp_path: Path) -> None:
        """Succeeded export CSV has only user_upn and phone_number."""
        mock_job = make_job(
            status=JobStatus.COMPLETED,
            item_count=2,
            succeeded_count=2,
        )
        output_file = tmp_path / "succeeded.csv"

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            runner.invoke(
                app,
                [
                    "batch",
                    "export",
                    "test-job",
                    "--succeeded",
                    "--output",
                    str(output_file),
                ],
            )

            rows = _read_csv(output_file)
            assert len(rows) == 2
            assert list(rows[0].keys()) == ["user_upn", "phone_number"]

    @pytest.mark.unit
    def test_all_export_includes_error_columns(self, tmp_path: Path) -> None:
        """All export CSV includes error columns."""
        mock_job = make_job(
            status=JobStatus.COMPLETED,
            item_count=3,
            failed_count=1,
            succeeded_count=2,
        )
        output_file = tmp_path / "all.csv"

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            runner.invoke(
                app,
                ["batch", "export", "test-job", "--all", "--output", str(output_file)],
            )

            rows = _read_csv(output_file)
            assert len(rows) == 3
            headers = list(rows[0].keys())
            assert "status" in headers
            assert "error_code" in headers
            assert "error_message" in headers
            assert "attempts" in headers


class TestBatchExportOutputPath:
    """Tests for output file path handling."""

    @pytest.mark.unit
    def test_custom_output_path(self, tmp_path: Path) -> None:
        """--output sets custom path."""
        mock_job = make_job(
            status=JobStatus.COMPLETED,
            item_count=1,
            succeeded_count=1,
        )
        output_file = tmp_path / "custom-output.csv"

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app,
                [
                    "batch",
                    "export",
                    "test-job",
                    "--succeeded",
                    "--output",
                    str(output_file),
                ],
            )

            assert result.exit_code == 0
            assert output_file.exists()

    @pytest.mark.unit
    def test_default_filename_uses_slug(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Default filename is <job-name-slug>-<filter>.csv."""
        mock_job = make_job(
            name="Q1 Migration 2026",
            status=JobStatus.COMPLETED,
            item_count=1,
            succeeded_count=1,
        )

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            with patch("teams_phone.cli.batch._write_export_csv") as mock_write:
                runner.invoke(app, ["batch", "export", "test-job", "--succeeded"])

                assert mock_write.called
                call_args = mock_write.call_args
                output_path = call_args[0][1]
                assert output_path == Path("q1-migration-2026-succeeded.csv")


class TestBatchExportErrors:
    """Tests for error handling in batch export."""

    @pytest.mark.unit
    def test_job_not_found_error(self) -> None:
        """Invalid job ID shows user-friendly error."""
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.side_effect = NotFoundError(
                "Job 'nonexistent' not found",
                remediation="Run 'teams-phone batch status' to see existing jobs.",
            )
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "export", "nonexistent", "--failed"])

            assert result.exit_code == 4
            assert "not found" in result.plain_stdout.lower()


def _read_csv(path: Path) -> list[dict[str, str]]:
    """Read a CSV file and return rows as dicts."""
    with path.open(encoding="utf-8") as f:
        return list(csv.DictReader(f))
