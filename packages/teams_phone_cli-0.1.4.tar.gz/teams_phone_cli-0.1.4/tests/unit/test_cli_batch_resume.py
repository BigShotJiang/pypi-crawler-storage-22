"""Unit tests for batch resume CLI command - state validation, IN_PROGRESS reset, async execution, and summary report."""

from __future__ import annotations

import json
from collections.abc import Generator
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from typing import Any
from unittest.mock import ANY, AsyncMock, MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.exceptions import JobLockError, NotFoundError
from teams_phone.models.batch import ItemStatus, Job, JobItem, JobStatus
from tests.conftest import CliRunner


runner = CliRunner()


def make_job(
    job_id: str = "20260204-120000-abcd-test",
    name: str = "test",
    status: JobStatus = JobStatus.INTERRUPTED,
    item_count: int = 2,
) -> Job:
    """Create a Job instance for testing.

    Args:
        job_id: Unique job identifier.
        name: Job name.
        status: Job lifecycle status (defaults to INTERRUPTED for resume tests).
        item_count: Total number of items to create.
    """
    now = datetime.now(timezone.utc)
    items: list[JobItem] = []

    for i in range(item_count):
        items.append(
            JobItem(
                line_number=i + 2,
                user_upn=f"user{i}@example.com",
                phone_number=f"+1425555100{i}",
                status=ItemStatus.PENDING,
            )
        )

    return Job(
        id=job_id,
        name=name,
        status=status,
        created_at=now,
        updated_at=now,
        started_at=now
        if status in (JobStatus.RUNNING, JobStatus.COMPLETED, JobStatus.INTERRUPTED)
        else None,
        completed_at=now if status == JobStatus.COMPLETED else None,
        input_file="/path/to/test.csv",
        input_hash="abc123" * 10 + "abcd",
        items=items,
    )


def make_interrupted_job(
    succeeded: int = 3,
    failed: int = 0,
    pending: int = 2,
    in_progress: int = 0,
    error_codes: list[str] | None = None,
    duration_seconds: int = 135,
) -> Job:
    """Create an INTERRUPTED Job with specific item outcome counts.

    Args:
        succeeded: Number of succeeded items.
        failed: Number of failed items.
        pending: Number of pending items.
        in_progress: Number of in-progress items.
        error_codes: Error codes for failed items.
        duration_seconds: Duration in seconds for started_at delta.
    """
    now = datetime.now(timezone.utc)
    items: list[JobItem] = []

    for i in range(succeeded):
        items.append(
            JobItem(
                line_number=i + 2,
                user_upn=f"user{i}@example.com",
                phone_number=f"+1425555100{i}",
                status=ItemStatus.SUCCEEDED,
            )
        )

    for i in range(failed):
        code = error_codes[i % len(error_codes)] if error_codes else "BATCH_003"
        items.append(
            JobItem(
                line_number=succeeded + i + 2,
                user_upn=f"failed{i}@example.com",
                phone_number=f"+1425555200{i}",
                status=ItemStatus.FAILED,
                error_code=code,
                error_message=f"Error for {code}",
            )
        )

    for i in range(pending):
        items.append(
            JobItem(
                line_number=succeeded + failed + i + 2,
                user_upn=f"pending{i}@example.com",
                phone_number=f"+1425555300{i}",
                status=ItemStatus.PENDING,
            )
        )

    for i in range(in_progress):
        items.append(
            JobItem(
                line_number=succeeded + failed + pending + i + 2,
                user_upn=f"inprogress{i}@example.com",
                phone_number=f"+1425555400{i}",
                status=ItemStatus.IN_PROGRESS,
            )
        )

    return Job(
        id="20260204-120000-abcd-test",
        name="test",
        status=JobStatus.INTERRUPTED,
        created_at=now - timedelta(minutes=5),
        updated_at=now,
        started_at=now - timedelta(seconds=duration_seconds),
        completed_at=None,
        input_file="/path/to/test.csv",
        input_hash="abc123" * 10 + "abcd",
        items=items,
    )


def make_completed_job(
    succeeded: int = 3,
    failed: int = 0,
    pending: int = 0,
    error_codes: list[str] | None = None,
    status: JobStatus = JobStatus.COMPLETED,
    duration_seconds: int = 135,
) -> Job:
    """Create a completed Job with specific outcome counts for summary report tests.

    Args:
        succeeded: Number of succeeded items.
        failed: Number of failed items.
        pending: Number of pending items.
        error_codes: Error codes for failed items.
        status: Job status (COMPLETED or INTERRUPTED).
        duration_seconds: Duration in seconds for started_at/completed_at delta.
    """
    now = datetime.now(timezone.utc)
    items: list[JobItem] = []

    for i in range(succeeded):
        items.append(
            JobItem(
                line_number=i + 2,
                user_upn=f"user{i}@example.com",
                phone_number=f"+1425555100{i}",
                status=ItemStatus.SUCCEEDED,
            )
        )

    for i in range(failed):
        code = error_codes[i % len(error_codes)] if error_codes else "BATCH_003"
        items.append(
            JobItem(
                line_number=succeeded + i + 2,
                user_upn=f"failed{i}@example.com",
                phone_number=f"+1425555200{i}",
                status=ItemStatus.FAILED,
                error_code=code,
                error_message=f"Error for {code}",
            )
        )

    for i in range(pending):
        items.append(
            JobItem(
                line_number=succeeded + failed + i + 2,
                user_upn=f"pending{i}@example.com",
                phone_number=f"+1425555300{i}",
                status=ItemStatus.PENDING,
            )
        )

    return Job(
        id="20260204-120000-abcd-test",
        name="test",
        status=status,
        created_at=now - timedelta(minutes=5),
        updated_at=now,
        started_at=now - timedelta(seconds=duration_seconds),
        completed_at=now,
        input_file="/path/to/test.csv",
        input_hash="abc123" * 10 + "abcd",
        items=items,
    )


@contextmanager
def mock_execution_context(
    mock_job: Job,
    *,
    active_job_id: str | None = None,
) -> Generator[dict[str, Any], None, None]:
    """Set up full async mock context for batch resume tests.

    Mocks all 7 dependencies needed for async execution:
    JobStore, CacheManager, AuthService, GraphClient, UserService,
    NumberService, and BatchExecutor.

    Args:
        mock_job: The Job instance to return from load_job.
        active_job_id: Value for get_active_job_id (None = no active job).

    Yields:
        Dict with mock references: store, graph, executor, executor_cls.
    """
    with (
        patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
        patch("teams_phone.cli.batch.CacheManager"),
        patch("teams_phone.cli.batch.AuthService"),
        patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
        patch("teams_phone.cli.batch.UserService"),
        patch("teams_phone.cli.batch.NumberService"),
        patch("teams_phone.cli.batch.BatchExecutor") as mock_executor_cls,
    ):
        mock_store = MagicMock()
        mock_store.load_job.return_value = mock_job
        mock_store.get_active_job_id.return_value = active_job_id
        mock_store.acquire_lock.return_value.__enter__ = MagicMock(return_value=None)
        mock_store.acquire_lock.return_value.__exit__ = MagicMock(return_value=False)
        mock_store_cls.return_value = mock_store

        mock_graph = MagicMock()
        mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
        mock_graph.__aexit__ = AsyncMock(return_value=None)
        mock_graph_cls.return_value = mock_graph

        mock_executor = MagicMock()
        mock_executor.execute_job = AsyncMock(return_value=mock_job)
        mock_executor_cls.return_value = mock_executor

        yield {
            "store": mock_store,
            "store_cls": mock_store_cls,
            "graph": mock_graph,
            "graph_cls": mock_graph_cls,
            "executor": mock_executor,
            "executor_cls": mock_executor_cls,
        }


class TestBatchResumeCommand:
    """Tests for the batch resume command basics."""

    @pytest.mark.unit
    def test_help_shows_usage(self) -> None:
        """Help displays command usage."""
        result = runner.invoke(app, ["batch", "resume", "--help"])
        assert result.exit_code == 0
        assert "Resume an interrupted batch job" in result.stdout

    @pytest.mark.unit
    def test_batch_command_shows_resume(self) -> None:
        """batch --help shows resume subcommand."""
        result = runner.invoke(app, ["batch", "--help"])
        assert result.exit_code == 0
        assert "resume" in result.stdout

    @pytest.mark.unit
    def test_requires_job_id_argument(self) -> None:
        """Resume command requires job_id argument."""
        result = runner.invoke(app, ["batch", "resume"])
        assert result.exit_code == 2


class TestBatchResumeJobLoading:
    """Tests for job loading functionality."""

    @pytest.mark.unit
    def test_loads_job_from_store(self) -> None:
        """Resume command loads job via JobStore."""
        mock_job = make_job(status=JobStatus.INTERRUPTED)

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(app, ["batch", "resume", "test-job-id"])

            mocks["store"].load_job.assert_called_once_with("test-job-id")
            assert result.exit_code == 0

    @pytest.mark.unit
    def test_job_not_found_error(self) -> None:
        """Invalid job ID shows user-friendly error."""
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.side_effect = NotFoundError(
                "Job 'nonexistent' not found",
                remediation="Run 'teams-phone batch status' to see existing jobs.",
            )
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "resume", "nonexistent"])

            assert result.exit_code == 4
            assert "not found" in result.plain_stdout.lower()


class TestBatchResumeStateValidation:
    """Tests for job state validation - only INTERRUPTED is allowed."""

    @pytest.mark.unit
    def test_allows_interrupted_state(self) -> None:
        """Resume allowed for jobs in INTERRUPTED state."""
        mock_job = make_job(status=JobStatus.INTERRUPTED)

        with mock_execution_context(mock_job):
            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 0

    @pytest.mark.unit
    def test_rejects_completed_state_with_retry_hint(self) -> None:
        """Resume rejected for COMPLETED jobs with batch retry hint."""
        mock_job = make_job(status=JobStatus.COMPLETED)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 5
            assert "batch retry" in result.plain_stdout

    @pytest.mark.unit
    def test_rejects_running_state(self) -> None:
        """Resume rejected for jobs already running."""
        mock_job = make_job(status=JobStatus.RUNNING)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 5
            assert "running" in result.plain_stdout.lower()

    @pytest.mark.unit
    def test_rejects_created_state(self) -> None:
        """Resume rejected for CREATED jobs."""
        mock_job = make_job(status=JobStatus.CREATED)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 5
            assert "created" in result.plain_stdout.lower()

    @pytest.mark.unit
    def test_rejects_validated_state(self) -> None:
        """Resume rejected for VALIDATED jobs."""
        mock_job = make_job(status=JobStatus.VALIDATED)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 5
            assert "validated" in result.plain_stdout.lower()

    @pytest.mark.unit
    def test_state_error_shows_current_status(self) -> None:
        """State validation error includes the current status."""
        mock_job = make_job(status=JobStatus.RUNNING)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 5
            assert "not interrupted" in result.plain_stdout.lower()


class TestBatchResumeInProgressReset:
    """Tests for IN_PROGRESS item reset to PENDING."""

    @pytest.mark.unit
    def test_resets_in_progress_items_to_pending(self) -> None:
        """IN_PROGRESS items are reset to PENDING before execution."""
        mock_job = make_interrupted_job(succeeded=2, pending=1, in_progress=2)

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 0
            # Verify the items were reset
            in_progress_items = [
                item for item in mock_job.items if item.status == ItemStatus.IN_PROGRESS
            ]
            assert len(in_progress_items) == 0
            # Verify save was called after reset
            mocks["store"].save_job.assert_called_with(mock_job)

    @pytest.mark.unit
    def test_reset_count_displayed(self) -> None:
        """Reset count message is displayed when items are reset."""
        mock_job = make_interrupted_job(succeeded=2, pending=1, in_progress=3)

        with mock_execution_context(mock_job):
            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 0
            assert "Reset 3 in-progress item(s) to pending" in result.plain_stdout

    @pytest.mark.unit
    def test_no_reset_message_when_no_in_progress(self) -> None:
        """No reset message when there are no IN_PROGRESS items."""
        mock_job = make_interrupted_job(succeeded=2, pending=3, in_progress=0)

        with mock_execution_context(mock_job):
            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 0
            assert "Reset" not in result.plain_stdout

    @pytest.mark.unit
    def test_no_save_when_no_in_progress(self) -> None:
        """Job is not saved if no IN_PROGRESS items need reset."""
        mock_job = make_interrupted_job(succeeded=2, pending=3, in_progress=0)

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 0
            mocks["store"].save_job.assert_not_called()


class TestBatchResumeInfo:
    """Tests for resume info display."""

    @pytest.mark.unit
    def test_displays_completed_count(self) -> None:
        """Resume info shows completed/total count."""
        mock_job = make_interrupted_job(succeeded=5, pending=3, in_progress=0)

        with mock_execution_context(mock_job):
            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 0
            assert "Resuming job: 5/8 items completed" in result.plain_stdout

    @pytest.mark.unit
    def test_displays_remaining_count(self) -> None:
        """Resume info shows remaining item count."""
        mock_job = make_interrupted_job(succeeded=5, pending=3, in_progress=0)

        with mock_execution_context(mock_job):
            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 0
            assert "Remaining: 3 items" in result.plain_stdout


class TestBatchResumeConcurrentExecution:
    """Tests for concurrent execution detection."""

    @pytest.mark.unit
    def test_rejects_when_another_job_active(self) -> None:
        """Resume rejected when another job is already running."""
        mock_job = make_job(status=JobStatus.INTERRUPTED)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store.get_active_job_id.return_value = "20260204-other-job"
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 13
            assert "20260204-other-job" in result.plain_stdout

    @pytest.mark.unit
    def test_allows_when_no_active_job(self) -> None:
        """Resume allowed when no other job is active."""
        mock_job = make_job(status=JobStatus.INTERRUPTED)

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 0
            mocks["store"].get_active_job_id.assert_called_once()


class TestBatchResumeConcurrencyOption:
    """Tests for concurrency option."""

    @pytest.mark.unit
    def test_default_concurrency_is_3(self) -> None:
        """Default concurrency value is 3."""
        mock_job = make_job(status=JobStatus.INTERRUPTED)

        with mock_execution_context(mock_job):
            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 0
            assert "Concurrency: 3" in result.plain_stdout

    @pytest.mark.unit
    def test_custom_concurrency_accepted(self) -> None:
        """Custom concurrency value is accepted."""
        mock_job = make_job(status=JobStatus.INTERRUPTED)

        with mock_execution_context(mock_job):
            result = runner.invoke(
                app, ["batch", "resume", "test-job", "--concurrency", "5"]
            )

            assert result.exit_code == 0
            assert "Concurrency: 5" in result.plain_stdout

    @pytest.mark.unit
    def test_short_concurrency_option(self) -> None:
        """Short -c option is accepted."""
        mock_job = make_job(status=JobStatus.INTERRUPTED)

        with mock_execution_context(mock_job):
            result = runner.invoke(app, ["batch", "resume", "test-job", "-c", "7"])

            assert result.exit_code == 0
            assert "Concurrency: 7" in result.plain_stdout

    @pytest.mark.unit
    def test_concurrency_below_minimum_rejected(self) -> None:
        """Concurrency below 1 is rejected."""
        result = runner.invoke(
            app, ["batch", "resume", "test-job", "--concurrency", "0"]
        )
        assert result.exit_code == 2

    @pytest.mark.unit
    def test_concurrency_above_maximum_rejected(self) -> None:
        """Concurrency above 10 is rejected."""
        result = runner.invoke(
            app, ["batch", "resume", "test-job", "--concurrency", "11"]
        )
        assert result.exit_code == 2


class TestBatchResumeAsyncExecution:
    """Tests for async execution context, lock acquisition, and BatchExecutor invocation."""

    @pytest.mark.unit
    def test_acquires_lock_during_execution(self) -> None:
        """Lock is acquired with the job ID during execution."""
        mock_job = make_job(status=JobStatus.INTERRUPTED)

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 0
            mocks["store"].acquire_lock.assert_called_once_with("test-job")

    @pytest.mark.unit
    def test_lock_failure_shows_error_with_exit_13(self) -> None:
        """JobLockError during lock acquisition results in exit code 13."""
        mock_job = make_job(status=JobStatus.INTERRUPTED)

        with mock_execution_context(mock_job) as mocks:
            mocks["store"].acquire_lock.return_value.__enter__ = MagicMock(
                side_effect=JobLockError("20260204-other-job")
            )

            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 13
            assert "20260204-other-job" in result.plain_stdout

    @pytest.mark.unit
    def test_graph_client_used_as_async_context_manager(self) -> None:
        """GraphClient is entered and exited as async context manager."""
        mock_job = make_job(status=JobStatus.INTERRUPTED)

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 0
            mocks["graph"].__aenter__.assert_called_once()
            mocks["graph"].__aexit__.assert_called_once()

    @pytest.mark.unit
    def test_executor_created_with_correct_params(self) -> None:
        """BatchExecutor is created with correct parameters."""
        mock_job = make_job(status=JobStatus.INTERRUPTED)

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(
                app, ["batch", "resume", "test-job", "--concurrency", "5"]
            )

            assert result.exit_code == 0
            mocks["executor_cls"].assert_called_once()
            call_kwargs = mocks["executor_cls"].call_args[1]
            assert call_kwargs["concurrency"] == 5
            assert call_kwargs["job_store"] is mocks["store"]

    @pytest.mark.unit
    def test_executor_no_dry_run_flag(self) -> None:
        """BatchExecutor is created without dry_run parameter."""
        mock_job = make_job(status=JobStatus.INTERRUPTED)

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 0
            call_kwargs = mocks["executor_cls"].call_args[1]
            assert "dry_run" not in call_kwargs

    @pytest.mark.unit
    def test_execute_job_called_with_job(self) -> None:
        """executor.execute_job() is called with the loaded job."""
        mock_job = make_job(status=JobStatus.INTERRUPTED)

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 0
            mocks["executor"].execute_job.assert_called_once_with(
                mock_job, on_progress=ANY
            )

    @pytest.mark.unit
    def test_lock_context_manager_exits_on_success(self) -> None:
        """Lock context manager __exit__ is called after successful execution."""
        mock_job = make_job(status=JobStatus.INTERRUPTED)

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 0
            mocks["store"].acquire_lock.return_value.__exit__.assert_called_once()


class TestBatchResumeProgressBar:
    """Tests for Rich progress bar integration during resume execution."""

    @pytest.mark.unit
    def test_on_progress_callback_passed_to_executor(self) -> None:
        """execute_job receives a callable on_progress argument."""
        mock_job = make_job(status=JobStatus.INTERRUPTED)

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 0
            call_kwargs = mocks["executor"].execute_job.call_args[1]
            assert "on_progress" in call_kwargs
            assert callable(call_kwargs["on_progress"])

    @pytest.mark.unit
    def test_progress_bar_disabled_in_json_mode(self) -> None:
        """Progress bar is disabled when --json flag is set."""
        mock_job = make_job(status=JobStatus.INTERRUPTED)

        with (
            mock_execution_context(mock_job),
            patch("teams_phone.cli.batch.Progress") as mock_progress_cls,
        ):
            mock_progress = MagicMock()
            mock_progress.__enter__ = MagicMock(return_value=mock_progress)
            mock_progress.__exit__ = MagicMock(return_value=False)
            mock_progress.add_task.return_value = 0
            mock_progress_cls.return_value = mock_progress

            result = runner.invoke(app, ["--json", "batch", "resume", "test-job"])

            assert result.exit_code == 0
            call_kwargs = mock_progress_cls.call_args[1]
            assert call_kwargs["disable"] is True

    @pytest.mark.unit
    def test_progress_description_says_resuming(self) -> None:
        """Progress task description says 'Resuming' instead of 'Executing'."""
        mock_job = make_job(name="q1-migration", status=JobStatus.INTERRUPTED)

        with (
            mock_execution_context(mock_job),
            patch("teams_phone.cli.batch.Progress") as mock_progress_cls,
        ):
            mock_progress = MagicMock()
            mock_progress.__enter__ = MagicMock(return_value=mock_progress)
            mock_progress.__exit__ = MagicMock(return_value=False)
            mock_progress.add_task.return_value = 0
            mock_progress_cls.return_value = mock_progress

            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 0
            call_args = mock_progress.add_task.call_args[0]
            assert "Resuming" in call_args[0]
            assert "q1-migration" in call_args[0]

    @pytest.mark.unit
    def test_progress_starts_at_already_completed_count(self) -> None:
        """Progress bar starts at the number of already-completed items."""
        mock_job = make_interrupted_job(succeeded=5, pending=3, in_progress=0)

        with (
            mock_execution_context(mock_job),
            patch("teams_phone.cli.batch.Progress") as mock_progress_cls,
        ):
            mock_progress = MagicMock()
            mock_progress.__enter__ = MagicMock(return_value=mock_progress)
            mock_progress.__exit__ = MagicMock(return_value=False)
            mock_progress.add_task.return_value = 0
            mock_progress_cls.return_value = mock_progress

            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 0
            call_kwargs = mock_progress.add_task.call_args[1]
            assert call_kwargs["total"] == 8
            assert call_kwargs["completed"] == 5


class TestBatchResumeSummaryReport:
    """Tests for post-execution summary report display."""

    @pytest.mark.unit
    def test_summary_displayed_after_execution(self) -> None:
        """Summary report is displayed after execution completes."""
        input_job = make_job(status=JobStatus.INTERRUPTED)
        result_job = make_completed_job(succeeded=5, failed=0)

        with mock_execution_context(input_job) as mocks:
            mocks["executor"].execute_job.return_value = result_job
            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert "Batch Execution Summary" in result.plain_stdout
            assert "5 succeeded (100.0%)" in result.plain_stdout

    @pytest.mark.unit
    def test_exit_code_11_when_failures(self) -> None:
        """Exit code is 11 (BATCH_EXECUTION_ERROR) when failures exist."""
        input_job = make_job(status=JobStatus.INTERRUPTED)
        result_job = make_completed_job(
            succeeded=3, failed=2, error_codes=["BATCH_003"]
        )

        with mock_execution_context(input_job) as mocks:
            mocks["executor"].execute_job.return_value = result_job
            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 11

    @pytest.mark.unit
    def test_exit_code_0_when_all_succeed(self) -> None:
        """Exit code is 0 when all items succeeded."""
        input_job = make_job(status=JobStatus.INTERRUPTED)
        result_job = make_completed_job(succeeded=5, failed=0)

        with mock_execution_context(input_job) as mocks:
            mocks["executor"].execute_job.return_value = result_job
            result = runner.invoke(app, ["batch", "resume", "test-job"])

            assert result.exit_code == 0

    @pytest.mark.unit
    def test_json_mode_outputs_job_model_dump(self) -> None:
        """--json flag outputs full job as JSON."""
        input_job = make_job(status=JobStatus.INTERRUPTED)
        result_job = make_completed_job(succeeded=3, failed=0)

        with mock_execution_context(input_job) as mocks:
            mocks["executor"].execute_job.return_value = result_job
            result = runner.invoke(app, ["--json", "batch", "resume", "test-job"])

            data = json.loads(result.plain_stdout)
            assert data["id"] == "20260204-120000-abcd-test"
            assert data["status"] == "completed"
            assert data["succeeded_count"] == 3

    @pytest.mark.unit
    def test_json_mode_no_rich_output(self) -> None:
        """--json flag suppresses human-readable summary."""
        input_job = make_job(status=JobStatus.INTERRUPTED)
        result_job = make_completed_job(succeeded=3, failed=0)

        with mock_execution_context(input_job) as mocks:
            mocks["executor"].execute_job.return_value = result_job
            result = runner.invoke(app, ["--json", "batch", "resume", "test-job"])

            assert "Batch Execution Summary" not in result.plain_stdout


class TestBatchResumeNoDryRun:
    """Verify that resume command does NOT have a --dry-run flag."""

    @pytest.mark.unit
    def test_no_dry_run_option(self) -> None:
        """--dry-run flag is not accepted by resume command."""
        result = runner.invoke(app, ["batch", "resume", "test-job", "--dry-run"])
        assert result.exit_code == 2
