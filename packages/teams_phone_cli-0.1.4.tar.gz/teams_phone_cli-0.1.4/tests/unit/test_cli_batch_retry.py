"""Unit tests for batch retry CLI command - state validation, failed item reset, async execution, and summary report."""

from __future__ import annotations

import json
from collections.abc import Generator
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from typing import Any
from unittest.mock import ANY, AsyncMock, MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.exceptions import JobLockError, NotFoundError
from teams_phone.models.batch import ItemStatus, Job, JobItem, JobStatus
from tests.conftest import CliRunner


runner = CliRunner()


def make_job(
    job_id: str = "20260204-120000-abcd-test",
    name: str = "test",
    status: JobStatus = JobStatus.COMPLETED,
    item_count: int = 2,
) -> Job:
    """Create a Job instance for testing.

    Args:
        job_id: Unique job identifier.
        name: Job name.
        status: Job lifecycle status (defaults to COMPLETED for retry tests).
        item_count: Total number of items to create.
    """
    now = datetime.now(timezone.utc)
    items: list[JobItem] = []

    for i in range(item_count):
        items.append(
            JobItem(
                line_number=i + 2,
                user_upn=f"user{i}@example.com",
                phone_number=f"+1425555100{i}",
                status=ItemStatus.PENDING,
            )
        )

    return Job(
        id=job_id,
        name=name,
        status=status,
        created_at=now,
        updated_at=now,
        started_at=now
        if status in (JobStatus.RUNNING, JobStatus.COMPLETED, JobStatus.INTERRUPTED)
        else None,
        completed_at=now if status == JobStatus.COMPLETED else None,
        input_file="/path/to/test.csv",
        input_hash="abc123" * 10 + "abcd",
        items=items,
    )


def make_completed_job(
    succeeded: int = 3,
    failed: int = 0,
    needs_review: int = 0,
    error_codes: list[str] | None = None,
    status: JobStatus = JobStatus.COMPLETED,
    duration_seconds: int = 135,
    attempts_override: dict[int, int] | None = None,
) -> Job:
    """Create a completed Job with specific outcome counts.

    Args:
        succeeded: Number of succeeded items.
        failed: Number of failed items.
        needs_review: Number of needs_review items.
        error_codes: Error codes for failed items.
        status: Job status (COMPLETED or INTERRUPTED).
        duration_seconds: Duration in seconds for started_at/completed_at delta.
        attempts_override: Dict mapping item index -> attempts count.
    """
    now = datetime.now(timezone.utc)
    items: list[JobItem] = []

    for i in range(succeeded):
        items.append(
            JobItem(
                line_number=i + 2,
                user_upn=f"user{i}@example.com",
                phone_number=f"+1425555100{i}",
                status=ItemStatus.SUCCEEDED,
            )
        )

    for i in range(failed):
        code = error_codes[i % len(error_codes)] if error_codes else "BATCH_003"
        item_attempts = 1
        if attempts_override and (succeeded + i) in attempts_override:
            item_attempts = attempts_override[succeeded + i]
        items.append(
            JobItem(
                line_number=succeeded + i + 2,
                user_upn=f"failed{i}@example.com",
                phone_number=f"+1425555200{i}",
                status=ItemStatus.FAILED,
                error_code=code,
                error_message=f"Error for {code}",
                attempts=item_attempts,
            )
        )

    for i in range(needs_review):
        code = "BATCH_005"
        item_attempts = 3
        if attempts_override and (succeeded + failed + i) in attempts_override:
            item_attempts = attempts_override[succeeded + failed + i]
        items.append(
            JobItem(
                line_number=succeeded + failed + i + 2,
                user_upn=f"review{i}@example.com",
                phone_number=f"+1425555300{i}",
                status=ItemStatus.NEEDS_REVIEW,
                error_code=code,
                error_message=f"Error for {code}",
                attempts=item_attempts,
            )
        )

    return Job(
        id="20260204-120000-abcd-test",
        name="test",
        status=status,
        created_at=now - timedelta(minutes=5),
        updated_at=now,
        started_at=now - timedelta(seconds=duration_seconds),
        completed_at=now if status == JobStatus.COMPLETED else None,
        input_file="/path/to/test.csv",
        input_hash="abc123" * 10 + "abcd",
        items=items,
    )


@contextmanager
def mock_execution_context(
    mock_job: Job,
    *,
    active_job_id: str | None = None,
) -> Generator[dict[str, Any], None, None]:
    """Set up full async mock context for batch retry tests.

    Mocks all 7 dependencies needed for async execution:
    JobStore, CacheManager, AuthService, GraphClient, UserService,
    NumberService, and BatchExecutor.

    Args:
        mock_job: The Job instance to return from load_job.
        active_job_id: Value for get_active_job_id (None = no active job).

    Yields:
        Dict with mock references: store, graph, executor, executor_cls.
    """
    with (
        patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
        patch("teams_phone.cli.batch.CacheManager"),
        patch("teams_phone.cli.batch.AuthService"),
        patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
        patch("teams_phone.cli.batch.UserService"),
        patch("teams_phone.cli.batch.NumberService"),
        patch("teams_phone.cli.batch.BatchExecutor") as mock_executor_cls,
    ):
        mock_store = MagicMock()
        mock_store.load_job.return_value = mock_job
        mock_store.get_active_job_id.return_value = active_job_id
        mock_store.acquire_lock.return_value.__enter__ = MagicMock(return_value=None)
        mock_store.acquire_lock.return_value.__exit__ = MagicMock(return_value=False)
        mock_store_cls.return_value = mock_store

        mock_graph = MagicMock()
        mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
        mock_graph.__aexit__ = AsyncMock(return_value=None)
        mock_graph_cls.return_value = mock_graph

        mock_executor = MagicMock()
        mock_executor.execute_job = AsyncMock(return_value=mock_job)
        mock_executor_cls.return_value = mock_executor

        yield {
            "store": mock_store,
            "store_cls": mock_store_cls,
            "graph": mock_graph,
            "graph_cls": mock_graph_cls,
            "executor": mock_executor,
            "executor_cls": mock_executor_cls,
        }


class TestBatchRetryCommand:
    """Tests for the batch retry command basics."""

    @pytest.mark.unit
    def test_help_shows_usage(self) -> None:
        """Help displays command usage."""
        result = runner.invoke(app, ["batch", "retry", "--help"])
        assert result.exit_code == 0
        assert "Retry failed items" in result.stdout

    @pytest.mark.unit
    def test_batch_command_shows_retry(self) -> None:
        """batch --help shows retry subcommand."""
        result = runner.invoke(app, ["batch", "--help"])
        assert result.exit_code == 0
        assert "retry" in result.stdout

    @pytest.mark.unit
    def test_requires_job_id_argument(self) -> None:
        """Retry command requires job_id argument."""
        result = runner.invoke(app, ["batch", "retry"])
        assert result.exit_code == 2


class TestBatchRetryJobLoading:
    """Tests for job loading functionality."""

    @pytest.mark.unit
    def test_loads_job_from_store(self) -> None:
        """Retry command loads job via JobStore."""
        mock_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(app, ["batch", "retry", "test-job-id"])

            mocks["store"].load_job.assert_called_once_with("test-job-id")
            assert result.exit_code in (0, 11)

    @pytest.mark.unit
    def test_job_not_found_error(self) -> None:
        """Invalid job ID shows user-friendly error."""
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.side_effect = NotFoundError(
                "Job 'nonexistent' not found",
                remediation="Run 'teams-phone batch status' to see existing jobs.",
            )
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "retry", "nonexistent"])

            assert result.exit_code == 4
            assert "not found" in result.plain_stdout.lower()


class TestBatchRetryStateValidation:
    """Tests for job state validation - COMPLETED and INTERRUPTED allowed."""

    @pytest.mark.unit
    def test_allows_completed_state(self) -> None:
        """Retry allowed for jobs in COMPLETED state."""
        mock_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job):
            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code in (0, 11)

    @pytest.mark.unit
    def test_allows_interrupted_state(self) -> None:
        """Retry allowed for jobs in INTERRUPTED state."""
        mock_job = make_completed_job(
            succeeded=3,
            failed=2,
            error_codes=["BATCH_003"],
            status=JobStatus.INTERRUPTED,
        )

        with mock_execution_context(mock_job):
            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code in (0, 11)

    @pytest.mark.unit
    def test_rejects_running_state(self) -> None:
        """Retry rejected for jobs already running."""
        mock_job = make_job(status=JobStatus.RUNNING)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code == 5
            assert "running" in result.plain_stdout.lower()

    @pytest.mark.unit
    def test_rejects_created_state(self) -> None:
        """Retry rejected for CREATED jobs."""
        mock_job = make_job(status=JobStatus.CREATED)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code == 5
            assert "created" in result.plain_stdout.lower()

    @pytest.mark.unit
    def test_rejects_validated_state(self) -> None:
        """Retry rejected for VALIDATED jobs."""
        mock_job = make_job(status=JobStatus.VALIDATED)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code == 5
            assert "validated" in result.plain_stdout.lower()

    @pytest.mark.unit
    def test_rejects_validating_state(self) -> None:
        """Retry rejected for VALIDATING jobs."""
        mock_job = make_job(status=JobStatus.VALIDATING)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code == 5
            assert "validating" in result.plain_stdout.lower()

    @pytest.mark.unit
    def test_state_error_shows_current_status(self) -> None:
        """State validation error includes the current status."""
        mock_job = make_job(status=JobStatus.RUNNING)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code == 5
            assert "running" in result.plain_stdout.lower()


class TestBatchRetryItemReset:
    """Tests for FAILED/NEEDS_REVIEW item reset to PENDING."""

    @pytest.mark.unit
    def test_resets_failed_items_to_pending(self) -> None:
        """FAILED items are reset to PENDING before execution."""
        mock_job = make_completed_job(succeeded=2, failed=3, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job):
            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code in (0, 11)
            failed_items = [
                item for item in mock_job.items if item.status == ItemStatus.FAILED
            ]
            assert len(failed_items) == 0

    @pytest.mark.unit
    def test_resets_needs_review_items_to_pending(self) -> None:
        """NEEDS_REVIEW items are reset to PENDING before execution."""
        mock_job = make_completed_job(succeeded=2, needs_review=2)

        with mock_execution_context(mock_job):
            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code in (0, 11)
            review_items = [
                item
                for item in mock_job.items
                if item.status == ItemStatus.NEEDS_REVIEW
            ]
            assert len(review_items) == 0

    @pytest.mark.unit
    def test_clears_error_code_and_message(self) -> None:
        """Error code and message are cleared on reset."""
        mock_job = make_completed_job(succeeded=1, failed=1, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job):
            runner.invoke(app, ["batch", "retry", "test-job"])

            # Find the item that was failed (now pending)
            reset_items = [
                item for item in mock_job.items if item.user_upn.startswith("failed")
            ]
            assert len(reset_items) == 1
            assert reset_items[0].error_code is None
            assert reset_items[0].error_message is None

    @pytest.mark.unit
    def test_preserves_attempts_count(self) -> None:
        """Attempts counter is preserved (not reset) on retry."""
        mock_job = make_completed_job(
            succeeded=1,
            failed=1,
            error_codes=["BATCH_003"],
            attempts_override={1: 2},
        )

        with mock_execution_context(mock_job):
            runner.invoke(app, ["batch", "retry", "test-job"])

            reset_items = [
                item for item in mock_job.items if item.user_upn.startswith("failed")
            ]
            assert len(reset_items) == 1
            assert reset_items[0].attempts == 2

    @pytest.mark.unit
    def test_saves_job_after_reset(self) -> None:
        """Job is saved after resetting failed items."""
        mock_job = make_completed_job(succeeded=2, failed=2, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job) as mocks:
            runner.invoke(app, ["batch", "retry", "test-job"])

            mocks["store"].save_job.assert_called_with(mock_job)

    @pytest.mark.unit
    def test_succeeded_items_not_touched(self) -> None:
        """SUCCEEDED items remain unchanged during retry."""
        mock_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job):
            runner.invoke(app, ["batch", "retry", "test-job"])

            succeeded_items = [
                item for item in mock_job.items if item.status == ItemStatus.SUCCEEDED
            ]
            assert len(succeeded_items) == 3

    @pytest.mark.unit
    def test_retry_count_displayed(self) -> None:
        """Number of items being retried is displayed."""
        mock_job = make_completed_job(succeeded=2, failed=3, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job):
            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert "Retrying 3 failed item(s)" in result.plain_stdout


class TestBatchRetryNoFailedItems:
    """Tests for early exit when no items need retry."""

    @pytest.mark.unit
    def test_shows_success_message(self) -> None:
        """Shows success message when no failed items exist."""
        mock_job = make_completed_job(succeeded=5, failed=0)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store.get_active_job_id.return_value = None
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code == 0
            assert "no failed items" in result.plain_stdout.lower()

    @pytest.mark.unit
    def test_no_execution_when_no_failed_items(self) -> None:
        """No async execution is performed when no failed items exist."""
        mock_job = make_completed_job(succeeded=5, failed=0)

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.BatchExecutor") as mock_executor_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store.get_active_job_id.return_value = None
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code == 0
            mock_executor_cls.assert_not_called()


class TestBatchRetryWarnings:
    """Tests for warning about items with 3+ attempts."""

    @pytest.mark.unit
    def test_warns_about_high_attempt_items(self) -> None:
        """Warning shown for items with 3+ failure attempts."""
        mock_job = make_completed_job(
            succeeded=1,
            failed=2,
            error_codes=["BATCH_003"],
            attempts_override={1: 3, 2: 4},
        )

        with mock_execution_context(mock_job):
            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert "2 item(s) have failed 3 or more times" in result.plain_stdout

    @pytest.mark.unit
    def test_no_warning_when_low_attempts(self) -> None:
        """No warning when all items have fewer than 3 attempts."""
        mock_job = make_completed_job(
            succeeded=1,
            failed=2,
            error_codes=["BATCH_003"],
            attempts_override={1: 1, 2: 2},
        )

        with mock_execution_context(mock_job):
            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert "failed 3 or more times" not in result.plain_stdout


class TestBatchRetryConcurrentExecution:
    """Tests for concurrent execution detection."""

    @pytest.mark.unit
    def test_rejects_when_another_job_active(self) -> None:
        """Retry rejected when another job is already running."""
        mock_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store.get_active_job_id.return_value = "20260204-other-job"
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code == 13
            assert "20260204-other-job" in result.plain_stdout

    @pytest.mark.unit
    def test_allows_when_no_active_job(self) -> None:
        """Retry allowed when no other job is active."""
        mock_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code in (0, 11)
            mocks["store"].get_active_job_id.assert_called_once()


class TestBatchRetryConcurrencyOption:
    """Tests for concurrency option."""

    @pytest.mark.unit
    def test_default_concurrency_is_3(self) -> None:
        """Default concurrency value is 3."""
        mock_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job):
            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert "Concurrency: 3" in result.plain_stdout

    @pytest.mark.unit
    def test_custom_concurrency_accepted(self) -> None:
        """Custom concurrency value is accepted."""
        mock_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job):
            result = runner.invoke(
                app, ["batch", "retry", "test-job", "--concurrency", "5"]
            )

            assert "Concurrency: 5" in result.plain_stdout

    @pytest.mark.unit
    def test_short_concurrency_option(self) -> None:
        """Short -c option is accepted."""
        mock_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job):
            result = runner.invoke(app, ["batch", "retry", "test-job", "-c", "7"])

            assert "Concurrency: 7" in result.plain_stdout

    @pytest.mark.unit
    def test_concurrency_below_minimum_rejected(self) -> None:
        """Concurrency below 1 is rejected."""
        result = runner.invoke(
            app, ["batch", "retry", "test-job", "--concurrency", "0"]
        )
        assert result.exit_code == 2

    @pytest.mark.unit
    def test_concurrency_above_maximum_rejected(self) -> None:
        """Concurrency above 10 is rejected."""
        result = runner.invoke(
            app, ["batch", "retry", "test-job", "--concurrency", "11"]
        )
        assert result.exit_code == 2


class TestBatchRetryAsyncExecution:
    """Tests for async execution context, lock acquisition, and BatchExecutor invocation."""

    @pytest.mark.unit
    def test_acquires_lock_during_execution(self) -> None:
        """Lock is acquired with the job ID during execution."""
        mock_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code in (0, 11)
            mocks["store"].acquire_lock.assert_called_once_with("test-job")

    @pytest.mark.unit
    def test_lock_failure_shows_error_with_exit_13(self) -> None:
        """JobLockError during lock acquisition results in exit code 13."""
        mock_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job) as mocks:
            mocks["store"].acquire_lock.return_value.__enter__ = MagicMock(
                side_effect=JobLockError("20260204-other-job")
            )

            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code == 13
            assert "20260204-other-job" in result.plain_stdout

    @pytest.mark.unit
    def test_graph_client_used_as_async_context_manager(self) -> None:
        """GraphClient is entered and exited as async context manager."""
        mock_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code in (0, 11)
            mocks["graph"].__aenter__.assert_called_once()
            mocks["graph"].__aexit__.assert_called_once()

    @pytest.mark.unit
    def test_executor_created_with_correct_params(self) -> None:
        """BatchExecutor is created with correct parameters."""
        mock_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(
                app, ["batch", "retry", "test-job", "--concurrency", "5"]
            )

            assert result.exit_code in (0, 11)
            mocks["executor_cls"].assert_called_once()
            call_kwargs = mocks["executor_cls"].call_args[1]
            assert call_kwargs["concurrency"] == 5
            assert call_kwargs["job_store"] is mocks["store"]

    @pytest.mark.unit
    def test_executor_no_dry_run_flag(self) -> None:
        """BatchExecutor is created without dry_run parameter."""
        mock_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code in (0, 11)
            call_kwargs = mocks["executor_cls"].call_args[1]
            assert "dry_run" not in call_kwargs

    @pytest.mark.unit
    def test_execute_job_called_with_job(self) -> None:
        """executor.execute_job() is called with the loaded job."""
        mock_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code in (0, 11)
            mocks["executor"].execute_job.assert_called_once_with(
                mock_job, on_progress=ANY
            )

    @pytest.mark.unit
    def test_lock_context_manager_exits_on_success(self) -> None:
        """Lock context manager __exit__ is called after successful execution."""
        mock_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code in (0, 11)
            mocks["store"].acquire_lock.return_value.__exit__.assert_called_once()


class TestBatchRetryProgressBar:
    """Tests for Rich progress bar integration during retry execution."""

    @pytest.mark.unit
    def test_on_progress_callback_passed_to_executor(self) -> None:
        """execute_job receives a callable on_progress argument."""
        mock_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])

        with mock_execution_context(mock_job) as mocks:
            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code in (0, 11)
            call_kwargs = mocks["executor"].execute_job.call_args[1]
            assert "on_progress" in call_kwargs
            assert callable(call_kwargs["on_progress"])

    @pytest.mark.unit
    def test_progress_bar_disabled_in_json_mode(self) -> None:
        """Progress bar is disabled when --json flag is set."""
        mock_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])

        with (
            mock_execution_context(mock_job),
            patch("teams_phone.cli.batch.Progress") as mock_progress_cls,
        ):
            mock_progress = MagicMock()
            mock_progress.__enter__ = MagicMock(return_value=mock_progress)
            mock_progress.__exit__ = MagicMock(return_value=False)
            mock_progress.add_task.return_value = 0
            mock_progress_cls.return_value = mock_progress

            result = runner.invoke(app, ["--json", "batch", "retry", "test-job"])

            assert result.exit_code in (0, 11)
            call_kwargs = mock_progress_cls.call_args[1]
            assert call_kwargs["disable"] is True

    @pytest.mark.unit
    def test_progress_description_says_retrying(self) -> None:
        """Progress task description says 'Retrying' instead of 'Executing'."""
        mock_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])
        mock_job.name = "q1-migration"

        with (
            mock_execution_context(mock_job),
            patch("teams_phone.cli.batch.Progress") as mock_progress_cls,
        ):
            mock_progress = MagicMock()
            mock_progress.__enter__ = MagicMock(return_value=mock_progress)
            mock_progress.__exit__ = MagicMock(return_value=False)
            mock_progress.add_task.return_value = 0
            mock_progress_cls.return_value = mock_progress

            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code in (0, 11)
            call_args = mock_progress.add_task.call_args[0]
            assert "Retrying" in call_args[0]
            assert "q1-migration" in call_args[0]


class TestBatchRetrySummaryReport:
    """Tests for post-execution summary report display."""

    @pytest.mark.unit
    def test_summary_displayed_after_execution(self) -> None:
        """Summary report is displayed after execution completes."""
        input_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])
        result_job = make_completed_job(succeeded=5, failed=0)

        with mock_execution_context(input_job) as mocks:
            mocks["executor"].execute_job.return_value = result_job
            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert "Batch Execution Summary" in result.plain_stdout
            assert "5 succeeded (100.0%)" in result.plain_stdout

    @pytest.mark.unit
    def test_exit_code_11_when_failures(self) -> None:
        """Exit code is 11 (BATCH_EXECUTION_ERROR) when failures exist."""
        input_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])
        result_job = make_completed_job(
            succeeded=4, failed=1, error_codes=["BATCH_003"]
        )

        with mock_execution_context(input_job) as mocks:
            mocks["executor"].execute_job.return_value = result_job
            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code == 11

    @pytest.mark.unit
    def test_exit_code_0_when_all_succeed(self) -> None:
        """Exit code is 0 when all items succeeded."""
        input_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])
        result_job = make_completed_job(succeeded=5, failed=0)

        with mock_execution_context(input_job) as mocks:
            mocks["executor"].execute_job.return_value = result_job
            result = runner.invoke(app, ["batch", "retry", "test-job"])

            assert result.exit_code == 0

    @pytest.mark.unit
    def test_json_mode_outputs_job_model_dump(self) -> None:
        """--json flag outputs full job as JSON."""
        input_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])
        result_job = make_completed_job(succeeded=5, failed=0)

        with mock_execution_context(input_job) as mocks:
            mocks["executor"].execute_job.return_value = result_job
            result = runner.invoke(app, ["--json", "batch", "retry", "test-job"])

            data = json.loads(result.plain_stdout)
            assert data["id"] == "20260204-120000-abcd-test"
            assert data["status"] == "completed"
            assert data["succeeded_count"] == 5

    @pytest.mark.unit
    def test_json_mode_no_rich_output(self) -> None:
        """--json flag suppresses human-readable summary."""
        input_job = make_completed_job(succeeded=3, failed=2, error_codes=["BATCH_003"])
        result_job = make_completed_job(succeeded=5, failed=0)

        with mock_execution_context(input_job) as mocks:
            mocks["executor"].execute_job.return_value = result_job
            result = runner.invoke(app, ["--json", "batch", "retry", "test-job"])

            assert "Batch Execution Summary" not in result.plain_stdout


class TestBatchRetryNoDryRun:
    """Verify that retry command does NOT have a --dry-run flag."""

    @pytest.mark.unit
    def test_no_dry_run_option(self) -> None:
        """--dry-run flag is not accepted by retry command."""
        result = runner.invoke(app, ["batch", "retry", "test-job", "--dry-run"])
        assert result.exit_code == 2
