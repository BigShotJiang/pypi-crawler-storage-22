"""Unit tests for batch status CLI command."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.exceptions import NotFoundError
from teams_phone.models.batch import ItemStatus, Job, JobItem, JobStatus
from tests.conftest import CliRunner


runner = CliRunner()


def make_job(
    job_id: str = "20260204-120000-abcd-test",
    name: str = "test",
    status: JobStatus = JobStatus.CREATED,
    item_count: int = 2,
    failed_count: int = 0,
    succeeded_count: int = 0,
    needs_review_count: int = 0,
) -> Job:
    """Create a Job instance for testing.

    Args:
        job_id: Unique job identifier.
        name: Job name.
        status: Job lifecycle status.
        item_count: Total number of items to create.
        failed_count: Number of items to mark as failed.
        succeeded_count: Number of items to mark as succeeded.
        needs_review_count: Number of items to mark as needs_review.
    """
    now = datetime.now(timezone.utc)
    items: list[JobItem] = []

    # Create specified failed items
    for i in range(failed_count):
        items.append(
            JobItem(
                line_number=i + 2,
                user_upn=f"failed{i}@example.com",
                phone_number=f"+1425555100{i}",
                status=ItemStatus.FAILED,
                error_code="UserNotFound",
                error_message=f"User failed{i}@example.com not found in tenant",
            )
        )

    # Create specified succeeded items
    for i in range(succeeded_count):
        items.append(
            JobItem(
                line_number=i + 2 + failed_count,
                user_upn=f"success{i}@example.com",
                phone_number=f"+1425555200{i}",
                status=ItemStatus.SUCCEEDED,
                completed_at=now,
            )
        )

    # Create specified needs_review items
    for i in range(needs_review_count):
        items.append(
            JobItem(
                line_number=i + 2 + failed_count + succeeded_count,
                user_upn=f"review{i}@example.com",
                phone_number=f"+1425555300{i}",
                status=ItemStatus.NEEDS_REVIEW,
                error_message="User already has a phone number assigned",
            )
        )

    # Fill remaining with pending items
    pending_count = item_count - failed_count - succeeded_count - needs_review_count
    for i in range(pending_count):
        items.append(
            JobItem(
                line_number=i + 2 + failed_count + succeeded_count + needs_review_count,
                user_upn=f"pending{i}@example.com",
                phone_number=f"+1425555400{i}",
                status=ItemStatus.PENDING,
            )
        )

    return Job(
        id=job_id,
        name=name,
        status=status,
        created_at=now,
        updated_at=now,
        started_at=now
        if status in (JobStatus.RUNNING, JobStatus.COMPLETED, JobStatus.INTERRUPTED)
        else None,
        completed_at=now if status == JobStatus.COMPLETED else None,
        input_file="/path/to/test.csv",
        input_hash="abc123" * 10 + "abcd",
        items=items,
    )


class TestBatchStatusCommand:
    """Tests for the batch status command basics."""

    @pytest.mark.unit
    def test_help_shows_usage(self) -> None:
        """Help displays command usage."""
        result = runner.invoke(app, ["batch", "status", "--help"])
        assert result.exit_code == 0
        assert "View batch job status" in result.stdout

    @pytest.mark.unit
    def test_batch_command_shows_status(self) -> None:
        """batch --help shows status subcommand."""
        result = runner.invoke(app, ["batch", "--help"])
        assert result.exit_code == 0
        assert "status" in result.stdout


class TestBatchStatusList:
    """Tests for listing all jobs (no job_id argument)."""

    @pytest.mark.unit
    def test_empty_job_list(self) -> None:
        """Empty job list shows helpful message."""
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.list_jobs.return_value = []
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "status"])

            assert result.exit_code == 0
            assert "No batch jobs found" in result.plain_stdout
            assert "batch create" in result.plain_stdout

    @pytest.mark.unit
    def test_list_shows_table_headers(self) -> None:
        """Job list shows table with correct headers."""
        mock_job = make_job()

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.list_jobs.return_value = [mock_job]
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "status"])

            assert result.exit_code == 0
            assert "Job ID" in result.plain_stdout
            assert "Name" in result.plain_stdout
            assert "Status" in result.plain_stdout
            assert "Total" in result.plain_stdout

    @pytest.mark.unit
    def test_list_shows_job_data(self) -> None:
        """Job list shows job information."""
        mock_job = make_job(
            job_id="20260204-143015-abcd-q1-migration",
            name="Q1 Migration",
            item_count=5,
            succeeded_count=3,
            failed_count=1,
        )

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.list_jobs.return_value = [mock_job]
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "status"])

            assert result.exit_code == 0
            # Job ID may be truncated by Rich table, check for prefix
            assert "20260204-143015-abcd-q1-migrat" in result.plain_stdout
            assert "Q1 Migration" in result.plain_stdout

    @pytest.mark.unit
    def test_list_multiple_jobs(self) -> None:
        """Job list shows multiple jobs."""
        job1 = make_job(job_id="job-1", name="First Job")
        job2 = make_job(job_id="job-2", name="Second Job")

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.list_jobs.return_value = [job1, job2]
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "status"])

            assert result.exit_code == 0
            assert "job-1" in result.plain_stdout
            assert "job-2" in result.plain_stdout
            assert "First Job" in result.plain_stdout
            assert "Second Job" in result.plain_stdout

    @pytest.mark.unit
    def test_list_json_output_empty(self) -> None:
        """--json flag outputs empty JSON array for no jobs."""
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.list_jobs.return_value = []
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["--json", "batch", "status"])

            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data == []

    @pytest.mark.unit
    def test_list_json_output_with_jobs(self) -> None:
        """--json flag outputs correct JSON structure for jobs."""
        mock_job = make_job(
            job_id="test-job-id",
            name="Test Job",
            item_count=10,
            succeeded_count=7,
            failed_count=2,
        )

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.list_jobs.return_value = [mock_job]
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["--json", "batch", "status"])

            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert len(data) == 1
            assert data[0]["id"] == "test-job-id"
            assert data[0]["name"] == "Test Job"
            assert data[0]["status"] == "created"
            assert data[0]["total_count"] == 10
            assert data[0]["succeeded_count"] == 7
            assert data[0]["failed_count"] == 2
            assert data[0]["pending_count"] == 1
            assert "created_at" in data[0]
            assert "updated_at" in data[0]


class TestBatchStatusDetail:
    """Tests for showing specific job details (with job_id argument)."""

    @pytest.mark.unit
    def test_detail_shows_job_info(self) -> None:
        """Detail view shows job information."""
        mock_job = make_job(
            job_id="20260204-143015-abcd-q1-migration",
            name="Q1 Migration",
            status=JobStatus.CREATED,
            item_count=5,
        )

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(
                app, ["batch", "status", "20260204-143015-abcd-q1-migration"]
            )

            assert result.exit_code == 0
            assert "20260204-143015-abcd-q1-migration" in result.plain_stdout
            assert "Q1 Migration" in result.plain_stdout
            assert "created" in result.plain_stdout

    @pytest.mark.unit
    def test_detail_shows_progress(self) -> None:
        """Detail view shows progress counts."""
        mock_job = make_job(
            item_count=10,
            succeeded_count=5,
            failed_count=2,
        )

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "status", "test-job"])

            assert result.exit_code == 0
            assert "Progress" in result.plain_stdout

    @pytest.mark.unit
    def test_detail_shows_failed_items(self) -> None:
        """Detail view shows failed items with error details."""
        mock_job = make_job(
            status=JobStatus.COMPLETED,
            item_count=3,
            failed_count=1,
            succeeded_count=2,
        )

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "status", "test-job"])

            assert result.exit_code == 0
            assert "Failed Items" in result.plain_stdout
            assert "failed0@example.com" in result.plain_stdout
            assert (
                "UserNotFound" in result.plain_stdout
                or "not found" in result.plain_stdout
            )

    @pytest.mark.unit
    def test_detail_shows_needs_review_items(self) -> None:
        """Detail view shows needs_review items."""
        mock_job = make_job(
            status=JobStatus.COMPLETED,
            item_count=3,
            needs_review_count=1,
            succeeded_count=2,
        )

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "status", "test-job"])

            assert result.exit_code == 0
            assert "Needs Review" in result.plain_stdout
            assert "review0@example.com" in result.plain_stdout

    @pytest.mark.unit
    def test_detail_shows_next_steps_created(self) -> None:
        """Detail view shows next steps for created job."""
        mock_job = make_job(status=JobStatus.CREATED)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "status", "test-job"])

            assert result.exit_code == 0
            assert "batch validate" in result.plain_stdout

    @pytest.mark.unit
    def test_detail_shows_next_steps_validated(self) -> None:
        """Detail view shows next steps for validated job."""
        mock_job = make_job(status=JobStatus.VALIDATED)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "status", "test-job"])

            assert result.exit_code == 0
            assert "batch run" in result.plain_stdout

    @pytest.mark.unit
    def test_detail_shows_next_steps_interrupted(self) -> None:
        """Detail view shows resume guidance for interrupted job."""
        mock_job = make_job(status=JobStatus.INTERRUPTED)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "status", "test-job"])

            assert result.exit_code == 0
            assert "batch resume" in result.plain_stdout


class TestBatchStatusDetailJson:
    """Tests for JSON output in detail view."""

    @pytest.mark.unit
    def test_detail_json_output(self) -> None:
        """--json flag outputs correct JSON structure for job detail."""
        mock_job = make_job(
            job_id="test-job-id",
            name="Test Job",
            item_count=5,
            succeeded_count=3,
            failed_count=1,
        )

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["--json", "batch", "status", "test-job-id"])

            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data["id"] == "test-job-id"
            assert data["name"] == "Test Job"
            assert data["status"] == "created"
            assert data["total_count"] == 5
            assert data["succeeded_count"] == 3
            assert data["failed_count"] == 1
            assert data["pending_count"] == 1
            assert "input_file" in data
            assert "input_hash" in data
            assert "items" in data
            assert len(data["items"]) == 5

    @pytest.mark.unit
    def test_detail_json_includes_item_errors(self) -> None:
        """JSON output includes error details for failed items."""
        mock_job = make_job(
            item_count=2,
            failed_count=1,
            succeeded_count=1,
        )

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["--json", "batch", "status", "test-job"])

            assert result.exit_code == 0
            data = json.loads(result.stdout)
            failed_item = next(
                item for item in data["items"] if item["status"] == "failed"
            )
            assert failed_item["error_code"] == "UserNotFound"
            assert "not found" in failed_item["error_message"]


class TestBatchStatusErrors:
    """Tests for error handling in batch status."""

    @pytest.mark.unit
    def test_job_not_found_error(self) -> None:
        """Invalid job ID shows user-friendly error."""
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.side_effect = NotFoundError(
                "Job 'nonexistent' not found",
                remediation="Run 'teams-phone batch jobs list' to see existing jobs.",
            )
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "status", "nonexistent"])

            # NotFoundError has exit code 4
            assert result.exit_code == 4
            assert "not found" in result.plain_stdout.lower()

    @pytest.mark.unit
    def test_job_not_found_json_error(self) -> None:
        """Invalid job ID with --json still shows error."""
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.side_effect = NotFoundError(
                "Job 'nonexistent' not found",
                remediation="Run 'teams-phone batch jobs list' to see existing jobs.",
            )
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["--json", "batch", "status", "nonexistent"])

            assert result.exit_code == 4
