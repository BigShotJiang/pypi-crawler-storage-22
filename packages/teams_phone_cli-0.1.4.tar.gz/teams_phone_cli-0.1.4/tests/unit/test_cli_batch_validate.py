"""Unit tests for batch validate CLI command - job loading and state validation."""

from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.exceptions import NotFoundError
from teams_phone.models.batch import ItemStatus, Job, JobItem, JobStatus
from tests.conftest import CliRunner


runner = CliRunner()


def make_job(
    job_id: str = "20260204-120000-abcd-test",
    name: str = "test",
    status: JobStatus = JobStatus.CREATED,
    item_count: int = 2,
) -> Job:
    """Create a Job instance for testing.

    Args:
        job_id: Unique job identifier.
        name: Job name.
        status: Job lifecycle status.
        item_count: Total number of items to create.
    """
    now = datetime.now(timezone.utc)
    items: list[JobItem] = []

    for i in range(item_count):
        items.append(
            JobItem(
                line_number=i + 2,
                user_upn=f"user{i}@example.com",
                phone_number=f"+1425555100{i}",
                status=ItemStatus.PENDING,
            )
        )

    return Job(
        id=job_id,
        name=name,
        status=status,
        created_at=now,
        updated_at=now,
        started_at=now
        if status in (JobStatus.RUNNING, JobStatus.COMPLETED, JobStatus.INTERRUPTED)
        else None,
        completed_at=now if status == JobStatus.COMPLETED else None,
        input_file="/path/to/test.csv",
        input_hash="abc123" * 10 + "abcd",
        items=items,
    )


class TestBatchValidateCommand:
    """Tests for the batch validate command basics."""

    @pytest.mark.unit
    def test_help_shows_usage(self) -> None:
        """Help displays command usage."""
        result = runner.invoke(app, ["batch", "validate", "--help"])
        assert result.exit_code == 0
        assert "Validate a batch migration job" in result.stdout

    @pytest.mark.unit
    def test_batch_command_shows_validate(self) -> None:
        """batch --help shows validate subcommand."""
        result = runner.invoke(app, ["batch", "--help"])
        assert result.exit_code == 0
        assert "validate" in result.stdout

    @pytest.mark.unit
    def test_requires_job_id_argument(self) -> None:
        """Validate command requires job_id argument."""
        result = runner.invoke(app, ["batch", "validate"])
        # Typer/Click returns exit code 2 for missing arguments
        assert result.exit_code == 2


class TestBatchValidateJobLoading:
    """Tests for job loading functionality."""

    @pytest.mark.unit
    def test_loads_job_from_store(self) -> None:
        """Validate command loads job via JobStore."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=2, valid_count=2, invalid_count=0, issues=[], warnings=[]
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job-id"])

            mock_store.load_job.assert_called_once_with("test-job-id")
            assert result.exit_code == 0

    @pytest.mark.unit
    def test_job_not_found_error(self) -> None:
        """Invalid job ID shows user-friendly error."""
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.side_effect = NotFoundError(
                "Job 'nonexistent' not found",
                remediation="Run 'teams-phone batch status' to see existing jobs.",
            )
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "validate", "nonexistent"])

            # NotFoundError has exit code 4
            assert result.exit_code == 4
            assert "not found" in result.plain_stdout.lower()

    @pytest.mark.unit
    def test_job_not_found_json_error(self) -> None:
        """Invalid job ID with --json still shows error."""
        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.side_effect = NotFoundError(
                "Job 'nonexistent' not found",
                remediation="Run 'teams-phone batch status' to see existing jobs.",
            )
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["--json", "batch", "validate", "nonexistent"])

            assert result.exit_code == 4


class TestBatchValidateStateValidation:
    """Tests for job state validation."""

    @pytest.mark.unit
    def test_allows_created_state(self) -> None:
        """Validation allowed for jobs in CREATED state."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=2, valid_count=2, invalid_count=0, issues=[], warnings=[]
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job"])

            assert result.exit_code == 0

    @pytest.mark.unit
    def test_allows_validated_state(self) -> None:
        """Validation allowed for jobs in VALIDATED state (re-validation)."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(status=JobStatus.VALIDATED)
        mock_report = ValidationReport(
            total_items=2, valid_count=2, invalid_count=0, issues=[], warnings=[]
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job"])

            assert result.exit_code == 0

    @pytest.mark.unit
    def test_rejects_validating_state(self) -> None:
        """Validation rejected for jobs already validating."""
        mock_job = make_job(status=JobStatus.VALIDATING)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "validate", "test-job"])

            # ValidationError has exit code 5
            assert result.exit_code == 5
            assert "validating" in result.plain_stdout.lower()
            assert (
                "created" in result.plain_stdout.lower()
                or "validated" in result.plain_stdout.lower()
            )

    @pytest.mark.unit
    def test_rejects_running_state(self) -> None:
        """Validation rejected for jobs that are running."""
        mock_job = make_job(status=JobStatus.RUNNING)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "validate", "test-job"])

            assert result.exit_code == 5
            assert "running" in result.plain_stdout.lower()

    @pytest.mark.unit
    def test_rejects_completed_state(self) -> None:
        """Validation rejected for completed jobs."""
        mock_job = make_job(status=JobStatus.COMPLETED)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "validate", "test-job"])

            assert result.exit_code == 5
            assert "completed" in result.plain_stdout.lower()

    @pytest.mark.unit
    def test_rejects_interrupted_state(self) -> None:
        """Validation rejected for interrupted jobs."""
        mock_job = make_job(status=JobStatus.INTERRUPTED)

        with patch("teams_phone.cli.batch.JobStore") as mock_store_cls:
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            result = runner.invoke(app, ["batch", "validate", "test-job"])

            assert result.exit_code == 5
            assert "interrupted" in result.plain_stdout.lower()


class TestBatchValidateStateTransition:
    """Tests for job state transition to VALIDATING."""

    @pytest.mark.unit
    def test_transitions_to_validating_state(self) -> None:
        """Job state changes to VALIDATING during validation, then VALIDATED on success."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=2, valid_count=2, invalid_count=0, issues=[], warnings=[]
        )

        # Track the status values at each save call
        saved_statuses: list[JobStatus] = []

        def track_save(job: Job) -> None:
            saved_statuses.append(job.status)

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store.save_job.side_effect = track_save
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job"])

            assert result.exit_code == 0
            # Verify job was saved twice with correct status sequence
            assert len(saved_statuses) == 2
            assert saved_statuses[0] == JobStatus.VALIDATING
            assert saved_statuses[1] == JobStatus.VALIDATED

    @pytest.mark.unit
    def test_transitions_from_validated_to_validating(self) -> None:
        """Re-validation transitions from VALIDATED to VALIDATING."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(status=JobStatus.VALIDATED)
        mock_report = ValidationReport(
            total_items=2, valid_count=2, invalid_count=0, issues=[], warnings=[]
        )

        # Track the status values at each save call
        saved_statuses: list[JobStatus] = []

        def track_save(job: Job) -> None:
            saved_statuses.append(job.status)

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store.save_job.side_effect = track_save
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job"])

            assert result.exit_code == 0
            # Verify job was saved twice with correct status sequence
            assert len(saved_statuses) == 2
            assert saved_statuses[0] == JobStatus.VALIDATING
            assert saved_statuses[1] == JobStatus.VALIDATED


class TestBatchValidateOptions:
    """Tests for command-line options."""

    @pytest.mark.unit
    def test_strict_option_accepted(self) -> None:
        """--strict option is accepted."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=2, valid_count=2, invalid_count=0, issues=[], warnings=[]
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job", "--strict"])

            assert result.exit_code == 0
            assert "Validation passed!" in result.plain_stdout

    @pytest.mark.unit
    def test_strict_short_option_accepted(self) -> None:
        """Short -s option is accepted."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=2, valid_count=2, invalid_count=0, issues=[], warnings=[]
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job", "-s"])

            assert result.exit_code == 0
            assert "Validation passed!" in result.plain_stdout

    @pytest.mark.unit
    def test_check_licenses_option_accepted(self) -> None:
        """--check-licenses option is accepted and passed to ValidationService."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=2, valid_count=2, invalid_count=0, issues=[], warnings=[]
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(
                app, ["batch", "validate", "test-job", "--check-licenses"]
            )

            assert result.exit_code == 0
            # Verify check_licenses was passed to validate_job
            mock_validation.validate_job.assert_awaited_once_with(
                mock_job, check_licenses=True
            )

    @pytest.mark.unit
    def test_check_licenses_short_option_accepted(self) -> None:
        """Short -l option is accepted and passed to ValidationService."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=2, valid_count=2, invalid_count=0, issues=[], warnings=[]
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job", "-l"])

            assert result.exit_code == 0
            mock_validation.validate_job.assert_awaited_once_with(
                mock_job, check_licenses=True
            )

    @pytest.mark.unit
    def test_both_options_accepted(self) -> None:
        """Both --strict and --check-licenses can be used together."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=2, valid_count=2, invalid_count=0, issues=[], warnings=[]
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(
                app,
                ["batch", "validate", "test-job", "--strict", "--check-licenses"],
            )

            assert result.exit_code == 0
            assert "Validation passed!" in result.plain_stdout
            mock_validation.validate_job.assert_awaited_once_with(
                mock_job, check_licenses=True
            )


class TestBatchValidateOutput:
    """Tests for command output."""

    @pytest.mark.unit
    def test_displays_validation_results(self) -> None:
        """Validate command displays validation results with counts."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(
            job_id="20260204-143015-abcd-test",
            item_count=5,
            status=JobStatus.CREATED,
        )
        mock_report = ValidationReport(
            total_items=5,
            valid_count=4,
            invalid_count=1,
            issues=[],
            warnings=[],
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            # Set up async context manager for GraphClient
            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            # Set up ValidationService mock
            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(
                app, ["batch", "validate", "20260204-143015-abcd-test"]
            )

            # invalid_count > 0 means validation failed with exit code 10
            assert result.exit_code == 10
            assert "20260204-143015-abcd-test" in result.plain_stdout
            assert "Valid: 4" in result.plain_stdout
            assert "Invalid: 1" in result.plain_stdout


class TestBatchValidateAsyncExecution:
    """Tests for async execution and service wiring."""

    @pytest.mark.unit
    def test_creates_services_with_graph_client(self) -> None:
        """Validation creates services inside GraphClient context."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(status=JobStatus.CREATED, item_count=3)
        mock_report = ValidationReport(
            total_items=3,
            valid_count=3,
            invalid_count=0,
            issues=[],
            warnings=[],
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager") as mock_cache_cls,
            patch("teams_phone.cli.batch.AuthService") as mock_auth_cls,
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService") as mock_user_cls,
            patch("teams_phone.cli.batch.NumberService") as mock_number_cls,
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job"])

            assert result.exit_code == 0

            # Verify service creation chain
            mock_cache_cls.assert_called_once()
            mock_auth_cls.assert_called_once()
            mock_graph_cls.assert_called_once()
            mock_user_cls.assert_called_once_with(mock_graph)
            mock_number_cls.assert_called_once_with(mock_graph)
            mock_validation_cls.assert_called_once()

    @pytest.mark.unit
    def test_calls_validate_job_with_check_licenses_false(self) -> None:
        """ValidationService.validate_job called with check_licenses=False by default."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=2, valid_count=2, invalid_count=0, issues=[], warnings=[]
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job"])

            assert result.exit_code == 0
            mock_validation.validate_job.assert_awaited_once_with(
                mock_job, check_licenses=False
            )

    @pytest.mark.unit
    def test_calls_validate_job_with_check_licenses_true(self) -> None:
        """ValidationService.validate_job called with check_licenses=True when flag set."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=2, valid_count=2, invalid_count=0, issues=[], warnings=[]
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(
                app, ["batch", "validate", "test-job", "--check-licenses"]
            )

            assert result.exit_code == 0
            mock_validation.validate_job.assert_awaited_once_with(
                mock_job, check_licenses=True
            )

    @pytest.mark.unit
    def test_validation_error_from_service_propagates(self) -> None:
        """Validation errors from ValidationService propagate correctly."""
        from unittest.mock import AsyncMock

        from teams_phone.exceptions import AuthenticationError

        mock_job = make_job(status=JobStatus.CREATED)

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                side_effect=AuthenticationError(
                    "Certificate expired",
                    remediation="Renew the certificate.",
                )
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job"])

            # AuthenticationError has exit code 2
            assert result.exit_code == 2
            assert "Certificate expired" in result.plain_stdout


class TestBatchValidateReportDisplay:
    """Tests for validation report display and job status update (subtask 9.3)."""

    @pytest.mark.unit
    def test_json_output_format(self) -> None:
        """JSON output contains expected fields."""
        import json
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import (
            ValidationIssue,
            ValidationReport,
        )

        mock_job = make_job(job_id="test-job-json", status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=5,
            valid_count=3,
            invalid_count=2,
            issues=[
                ValidationIssue(
                    line_number=2,
                    field="user_upn",
                    value="invalid@example.com",
                    error_code="BATCH_003",
                    error_message="User not found",
                    suggested_fix="Check the user principal name",
                ),
            ],
            warnings=["User already assigned"],
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(
                app, ["--json", "batch", "validate", "test-job-json"]
            )

            # JSON output has exit code 0 because validation failures are in JSON
            # Exit code 10 is only for human output mode
            output = json.loads(result.plain_stdout)
            assert output["job_id"] == "test-job-json"
            assert output["valid"] is False
            assert output["total"] == 5
            assert output["valid_count"] == 3
            assert output["invalid_count"] == 2
            assert output["warning_count"] == 1
            assert len(output["issues"]) == 1
            assert output["issues"][0]["line_number"] == 2
            assert output["issues"][0]["error_code"] == "BATCH_003"

    @pytest.mark.unit
    def test_issues_display_with_line_numbers(self) -> None:
        """Issues are displayed with line numbers and error codes."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import (
            ValidationIssue,
            ValidationReport,
        )

        mock_job = make_job(job_id="test-issues", status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=3,
            valid_count=1,
            invalid_count=2,
            issues=[
                ValidationIssue(
                    line_number=2,
                    field="user_upn",
                    value="bad@example.com",
                    error_code="BATCH_003",
                    error_message="User not found in directory",
                    suggested_fix=None,
                ),
                ValidationIssue(
                    line_number=4,
                    field="phone_number",
                    value="+1invalid",
                    error_code="BATCH_001",
                    error_message="Invalid phone number format",
                    suggested_fix="Use E.164 format: +1XXXXXXXXXX",
                ),
            ],
            warnings=[],
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-issues"])

            assert result.exit_code == 10
            assert "Line 2:" in result.plain_stdout
            assert "[BATCH_003]" in result.plain_stdout
            assert "User not found" in result.plain_stdout
            assert "Line 4:" in result.plain_stdout
            assert "[BATCH_001]" in result.plain_stdout
            assert "Invalid phone number format" in result.plain_stdout

    @pytest.mark.unit
    def test_suggested_fix_displayed_when_present(self) -> None:
        """Suggested fix is displayed when available."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import (
            ValidationIssue,
            ValidationReport,
        )

        mock_job = make_job(status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=1,
            valid_count=0,
            invalid_count=1,
            issues=[
                ValidationIssue(
                    line_number=2,
                    field="phone_number",
                    value="+1invalid",
                    error_code="BATCH_001",
                    error_message="Invalid phone number",
                    suggested_fix="Use E.164 format",
                ),
            ],
            warnings=[],
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job"])

            assert result.exit_code == 10
            assert "Fix: Use E.164 format" in result.plain_stdout

    @pytest.mark.unit
    def test_issues_limited_to_first_20(self) -> None:
        """Only first 20 issues are displayed with indication of more."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import (
            ValidationIssue,
            ValidationReport,
        )

        mock_job = make_job(status=JobStatus.CREATED, item_count=30)
        # Create 25 issues
        issues = [
            ValidationIssue(
                line_number=i + 2,
                field="user_upn",
                value=f"user{i}@example.com",
                error_code="BATCH_003",
                error_message=f"User {i} not found",
                suggested_fix=None,
            )
            for i in range(25)
        ]
        mock_report = ValidationReport(
            total_items=30,
            valid_count=5,
            invalid_count=25,
            issues=issues,
            warnings=[],
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job"])

            assert result.exit_code == 10
            # Should show first 20 issues
            assert "Line 2:" in result.plain_stdout
            assert "Line 21:" in result.plain_stdout
            # Should NOT show issue 21 (line 22)
            assert "Line 22:" not in result.plain_stdout
            # Should indicate more issues
            assert "5 more issues" in result.plain_stdout

    @pytest.mark.unit
    def test_exit_code_0_on_validation_success(self) -> None:
        """Exit code 0 when validation passes."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=2,
            valid_count=2,
            invalid_count=0,
            issues=[],
            warnings=[],
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job"])

            assert result.exit_code == 0
            assert "Validation passed!" in result.plain_stdout

    @pytest.mark.unit
    def test_exit_code_10_on_validation_failure(self) -> None:
        """Exit code 10 when validation fails."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import (
            ValidationIssue,
            ValidationReport,
        )

        mock_job = make_job(status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=2,
            valid_count=1,
            invalid_count=1,
            issues=[
                ValidationIssue(
                    line_number=2,
                    field="user_upn",
                    value="bad@example.com",
                    error_code="BATCH_003",
                    error_message="User not found",
                    suggested_fix=None,
                ),
            ],
            warnings=[],
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job"])

            assert result.exit_code == 10
            assert "Validation failed" in result.plain_stdout

    @pytest.mark.unit
    def test_next_step_guidance_on_success(self) -> None:
        """Next step guidance shown on successful validation."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(job_id="test-next-step", status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=2,
            valid_count=2,
            invalid_count=0,
            issues=[],
            warnings=[],
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-next-step"])

            assert result.exit_code == 0
            assert (
                "Next step: teams-phone batch run test-next-step" in result.plain_stdout
            )

    @pytest.mark.unit
    def test_job_status_validated_on_success(self) -> None:
        """Job status updated to VALIDATED when validation passes."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=2,
            valid_count=2,
            invalid_count=0,
            issues=[],
            warnings=[],
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job"])

            assert result.exit_code == 0
            # Job should be saved twice: once for VALIDATING, once for VALIDATED
            assert mock_store.save_job.call_count == 2
            final_save = mock_store.save_job.call_args_list[-1]
            saved_job = final_save[0][0]
            assert saved_job.status == JobStatus.VALIDATED

    @pytest.mark.unit
    def test_job_status_created_on_failure(self) -> None:
        """Job status set back to CREATED when validation fails."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import (
            ValidationIssue,
            ValidationReport,
        )

        mock_job = make_job(status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=2,
            valid_count=1,
            invalid_count=1,
            issues=[
                ValidationIssue(
                    line_number=2,
                    field="user_upn",
                    value="bad@example.com",
                    error_code="BATCH_003",
                    error_message="User not found",
                    suggested_fix=None,
                ),
            ],
            warnings=[],
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job"])

            assert result.exit_code == 10
            # Job should be saved twice: once for VALIDATING, once for CREATED
            assert mock_store.save_job.call_count == 2
            final_save = mock_store.save_job.call_args_list[-1]
            saved_job = final_save[0][0]
            assert saved_job.status == JobStatus.CREATED

    @pytest.mark.unit
    def test_strict_mode_fails_on_warnings(self) -> None:
        """--strict flag causes failure when warnings exist."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=2,
            valid_count=2,
            invalid_count=0,  # No errors
            issues=[],
            warnings=["User user0@example.com already has phone +14255551000 assigned"],
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job", "--strict"])

            assert result.exit_code == 10
            assert "Validation failed" in result.plain_stdout
            assert "strict mode" in result.plain_stdout.lower()

    @pytest.mark.unit
    def test_strict_mode_passes_without_warnings(self) -> None:
        """--strict flag passes when no warnings exist."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import ValidationReport

        mock_job = make_job(status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=2,
            valid_count=2,
            invalid_count=0,
            issues=[],
            warnings=[],  # No warnings
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-job", "--strict"])

            assert result.exit_code == 0
            assert "Validation passed!" in result.plain_stdout

    @pytest.mark.unit
    def test_fix_guidance_on_validation_failure(self) -> None:
        """Fix guidance shown when validation fails."""
        from unittest.mock import AsyncMock

        from teams_phone.services.validation_service import (
            ValidationIssue,
            ValidationReport,
        )

        mock_job = make_job(job_id="test-fix-guidance", status=JobStatus.CREATED)
        mock_report = ValidationReport(
            total_items=2,
            valid_count=1,
            invalid_count=1,
            issues=[
                ValidationIssue(
                    line_number=2,
                    field="user_upn",
                    value="bad@example.com",
                    error_code="BATCH_003",
                    error_message="User not found",
                    suggested_fix=None,
                ),
            ],
            warnings=[],
        )

        with (
            patch("teams_phone.cli.batch.JobStore") as mock_store_cls,
            patch("teams_phone.cli.batch.CacheManager"),
            patch("teams_phone.cli.batch.AuthService"),
            patch("teams_phone.cli.batch.GraphClient") as mock_graph_cls,
            patch("teams_phone.cli.batch.UserService"),
            patch("teams_phone.cli.batch.NumberService"),
            patch("teams_phone.cli.batch.ValidationService") as mock_validation_cls,
        ):
            mock_store = MagicMock()
            mock_store.load_job.return_value = mock_job
            mock_store_cls.return_value = mock_store

            mock_graph = MagicMock()
            mock_graph.__aenter__ = AsyncMock(return_value=mock_graph)
            mock_graph.__aexit__ = AsyncMock(return_value=None)
            mock_graph_cls.return_value = mock_graph

            mock_validation = MagicMock()
            mock_validation.validate_job = AsyncMock(
                return_value=(mock_job, mock_report)
            )
            mock_validation_cls.return_value = mock_validation

            result = runner.invoke(app, ["batch", "validate", "test-fix-guidance"])

            assert result.exit_code == 10
            assert "teams-phone batch validate test-fix-guidance" in result.plain_stdout
