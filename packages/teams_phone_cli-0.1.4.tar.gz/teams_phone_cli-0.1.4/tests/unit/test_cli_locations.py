"""Unit tests for CLI locations commands."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.constants import LARGE_RESULT_THRESHOLD
from teams_phone.exceptions import NotFoundError
from teams_phone.models import EmergencyLocation
from tests.conftest import CliRunner
from tests.fixtures import make_location


runner = CliRunner()


class TestLocationsListCommand:
    """Tests for locations list command."""

    @pytest.mark.unit
    def test_list_shows_in_help(self) -> None:
        """list command appears in locations help."""
        result = runner.invoke(app, ["locations", "--help"])
        assert result.exit_code == 0
        assert "list" in result.stdout

    @pytest.mark.unit
    def test_contains_option_appears_in_help(self) -> None:
        """--contains option appears in list command help with example."""
        result = runner.invoke(app, ["locations", "list", "--help"])
        assert result.exit_code == 0
        assert "--contains" in result.plain_stdout
        assert "substring matching" in result.plain_stdout

    @pytest.mark.unit
    def test_list_empty(self) -> None:
        """list shows empty message when no locations found."""
        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = []
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["locations", "list"])
            assert result.exit_code == 0
            assert "No locations found" in result.stdout

    @pytest.mark.unit
    def test_list_shows_locations(self) -> None:
        """list shows locations in table format."""
        locations = [
            make_location(description="Seattle HQ", city="Seattle"),
            make_location(
                location_id="loc-2",
                description="Portland Office",
                city="Portland",
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["--no-color", "locations", "list"])
            assert result.exit_code == 0
            assert "Seattle HQ" in result.stdout
            assert "Portland Office" in result.stdout

    @pytest.mark.unit
    def test_list_json_output(self) -> None:
        """list outputs valid JSON with --json flag."""
        locations = [make_location(description="Seattle HQ")]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["--json", "locations", "list"])
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert len(data) == 1
            assert data[0]["description"] == "Seattle HQ"
            assert data[0]["city"] == "Seattle"
            assert data[0]["is_default"] is True

    @pytest.mark.unit
    def test_list_json_empty(self) -> None:
        """list outputs empty JSON array when no locations."""
        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = []
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["--json", "locations", "list"])
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data == []

    @pytest.mark.unit
    def test_list_with_city_filter(self) -> None:
        """list filters locations by city."""
        locations = [
            make_location(description="Seattle HQ", city="Seattle"),
            make_location(
                location_id="loc-2",
                description="Portland Office",
                city="Portland",
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "locations", "list", "--city", "Seattle"]
            )
            assert result.exit_code == 0
            assert "Seattle HQ" in result.stdout
            assert "Portland Office" not in result.stdout

    @pytest.mark.unit
    def test_list_city_filter_case_insensitive(self) -> None:
        """list city filter is case insensitive."""
        locations = [
            make_location(description="Seattle HQ", city="Seattle"),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "locations", "list", "--city", "seattle"]
            )
            assert result.exit_code == 0
            assert "Seattle HQ" in result.stdout

    @pytest.mark.unit
    def test_list_with_contains_flag(self) -> None:
        """list with --contains matches city substring."""
        locations = [
            make_location(
                location_id="loc-1", description="Seattle HQ", city="Seattle"
            ),
            make_location(
                location_id="loc-2",
                description="New Seattle Office",
                city="New Seattle",
            ),
            make_location(
                location_id="loc-3", description="Portland Office", city="Portland"
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "locations", "list", "--city", "Sea", "--contains"]
            )
            assert result.exit_code == 0
            # Should match Seattle and New Seattle (both contain "Sea")
            assert "Seattle HQ" in result.stdout
            assert "New Seattle Office" in result.stdout
            # Should not match Portland
            assert "Portland Office" not in result.stdout

    @pytest.mark.unit
    def test_list_without_contains_uses_exact_match(self) -> None:
        """list without --contains uses exact city match."""
        locations = [
            make_location(
                location_id="loc-1", description="Seattle HQ", city="Seattle"
            ),
            make_location(
                location_id="loc-2",
                description="New Seattle Office",
                city="New Seattle",
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "locations", "list", "--city", "Seattle"]
            )
            assert result.exit_code == 0
            # Should only match exact "Seattle"
            assert "Seattle HQ" in result.stdout
            # Should NOT match "New Seattle" (not exact match)
            assert "New Seattle Office" not in result.stdout

    @pytest.mark.unit
    def test_list_with_contains_case_insensitive(self) -> None:
        """list with --contains is case insensitive."""
        locations = [
            make_location(
                location_id="loc-1", description="New York Office", city="New York"
            ),
            make_location(
                location_id="loc-2",
                description="Newark Office",
                city="Newark",
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "locations", "list", "--city", "new", "--contains"]
            )
            assert result.exit_code == 0
            # Should match both (case-insensitive substring match)
            assert "New York Office" in result.stdout
            assert "Newark Office" in result.stdout

    @pytest.mark.unit
    def test_list_with_limit(self) -> None:
        """list respects --limit option."""
        locations = [
            make_location(location_id="loc-1", description="Location 1"),
            make_location(location_id="loc-2", description="Location 2"),
            make_location(location_id="loc-3", description="Location 3"),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["--json", "locations", "list", "--limit", "2"])
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert len(data) == 2

    @pytest.mark.unit
    def test_list_limit_and_all_mutually_exclusive(self) -> None:
        """list errors when both --limit and --all are specified."""
        result = runner.invoke(app, ["locations", "list", "--limit", "10", "--all"])
        assert result.exit_code == 5  # ValidationError exit code
        assert "Cannot specify both --limit and --all" in result.stdout

    @pytest.mark.unit
    def test_list_shows_staleness_warning(self) -> None:
        """list shows staleness warning when cache is stale."""
        locations = [make_location()]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = (
                "Location cache is 45 days old (threshold: 30 days). "
                "Consider refreshing by running the PowerShell export script."
            )
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["--no-color", "locations", "list"])
            assert result.exit_code == 0
            # Check for key parts of the warning message (ANSI codes may affect literal match)
            assert "days old" in result.stdout
            assert "threshold" in result.stdout


class TestLocationsShowCommand:
    """Tests for locations show command."""

    @pytest.mark.unit
    def test_show_shows_in_help(self) -> None:
        """show command appears in locations help."""
        result = runner.invoke(app, ["locations", "--help"])
        assert result.exit_code == 0
        assert "show" in result.stdout

    @pytest.mark.unit
    def test_show_requires_location_argument(self) -> None:
        """show requires location argument."""
        result = runner.invoke(app, ["locations", "show"])
        assert result.exit_code == 2
        output = result.stdout + (result.stderr or "")
        assert (
            "LOCATION" in output
            or "Missing argument" in output
            or result.exit_code == 2
        )

    @pytest.mark.unit
    def test_show_displays_location(self) -> None:
        """show displays location details."""
        location = make_location(description="Seattle HQ")

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.validate_location.return_value = location
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "locations", "show", "Seattle HQ"]
            )
            assert result.exit_code == 0
            assert "Seattle HQ" in result.stdout
            # Check for parts of address (ANSI codes may affect literal match)
            assert "Main St" in result.stdout
            assert "Seattle" in result.stdout
            assert "Contoso" in result.stdout

    @pytest.mark.unit
    def test_show_json_output(self) -> None:
        """show outputs valid JSON with --json flag."""
        location = make_location(description="Seattle HQ")

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.validate_location.return_value = location
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["--json", "locations", "show", "Seattle HQ"])
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data["description"] == "Seattle HQ"
            assert data["address"] == "123 Main St"
            assert data["city"] == "Seattle"
            assert data["is_default"] is True

    @pytest.mark.unit
    def test_show_not_found(self) -> None:
        """show exits with error when location not found."""
        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.validate_location.side_effect = NotFoundError(
                "Location 'nonexistent' not found",
                remediation="Verify the location ID or description is correct.",
            )
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["locations", "show", "nonexistent"])
            assert result.exit_code == 4  # NotFoundError exit code

    @pytest.mark.unit
    def test_show_staleness_warning(self) -> None:
        """show displays staleness warning when cache is stale."""
        location = make_location()

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.validate_location.return_value = location
            mock_service.get_staleness_warning.return_value = (
                "Location cache not found. "
                "Run the PowerShell export script to create the cache."
            )
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "locations", "show", "Seattle HQ"]
            )
            assert result.exit_code == 0
            assert "cache not found" in result.stdout


class TestLocationsSearchCommand:
    """Tests for locations search command."""

    @pytest.mark.unit
    def test_search_shows_in_help(self) -> None:
        """search command appears in locations help."""
        result = runner.invoke(app, ["locations", "--help"])
        assert result.exit_code == 0
        assert "search" in result.stdout

    @pytest.mark.unit
    def test_search_query_help_shows_wildcards(self) -> None:
        """search query help shows wildcard examples."""
        result = runner.invoke(app, ["locations", "search", "--help"])
        assert result.exit_code == 0
        assert "wildcard" in result.stdout.lower()
        assert "Main*" in result.stdout
        assert "*HQ" in result.stdout

    @pytest.mark.unit
    def test_search_quiet_option_appears_in_help(self) -> None:
        """--quiet option appears in search command help."""
        result = runner.invoke(app, ["locations", "search", "--help"])
        assert result.exit_code == 0
        assert "--quiet" in result.plain_stdout
        assert "-q" in result.plain_stdout

    @pytest.mark.unit
    def test_search_requires_query_argument(self) -> None:
        """search requires query argument."""
        result = runner.invoke(app, ["locations", "search"])
        assert result.exit_code == 2
        output = result.stdout + (result.stderr or "")
        assert (
            "QUERY" in output or "Missing argument" in output or result.exit_code == 2
        )

    @pytest.mark.unit
    def test_search_shows_results(self) -> None:
        """search shows matching locations."""
        locations = [
            make_location(description="Seattle HQ", city="Seattle"),
            make_location(
                location_id="loc-2",
                description="Seattle Satellite",
                city="Seattle",
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "locations", "search", "Seattle"]
            )
            assert result.exit_code == 0
            assert "Seattle HQ" in result.stdout
            assert "Seattle Satellite" in result.stdout

    @pytest.mark.unit
    def test_search_no_results(self) -> None:
        """search shows message when no locations found."""
        locations = [make_location(description="Seattle HQ", city="Seattle")]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "locations", "search", "nonexistent"]
            )
            assert result.exit_code == 0
            assert "No locations found matching" in result.stdout
            assert "nonexistent" in result.stdout

    @pytest.mark.unit
    def test_search_json_output(self) -> None:
        """search outputs valid JSON with --json flag."""
        locations = [make_location(description="Seattle HQ")]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["--json", "locations", "search", "Seattle"])
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert len(data) == 1
            assert data[0]["description"] == "Seattle HQ"

    @pytest.mark.unit
    def test_search_json_empty(self) -> None:
        """search outputs empty JSON array when no results."""
        locations: list[EmergencyLocation] = []

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["--json", "locations", "search", "anything"])
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert data == []

    @pytest.mark.unit
    def test_search_with_limit(self) -> None:
        """search respects --limit option."""
        locations = [
            make_location(location_id="loc-1", description="Seattle 1"),
            make_location(location_id="loc-2", description="Seattle 2"),
            make_location(location_id="loc-3", description="Seattle 3"),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--json", "locations", "search", "Seattle", "--limit", "2"]
            )
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert len(data) == 2

    @pytest.mark.unit
    def test_search_default_limit(self) -> None:
        """search uses default limit of 25."""
        # Create 30 locations
        locations = [
            make_location(location_id=f"loc-{i}", description=f"Seattle {i}")
            for i in range(30)
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["--json", "locations", "search", "Seattle"])
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert len(data) == 25

    @pytest.mark.unit
    def test_search_with_field_name(self) -> None:
        """search with --field name only searches description."""
        locations = [
            make_location(description="Seattle HQ", city="Portland"),
            make_location(
                location_id="loc-2",
                description="Portland Office",
                city="Seattle",
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app,
                ["--no-color", "locations", "search", "Seattle", "--field", "name"],
            )
            assert result.exit_code == 0
            assert "Seattle HQ" in result.stdout
            # Portland Office has Seattle in city, but we're only searching name
            assert "Portland Office" not in result.stdout

    @pytest.mark.unit
    def test_search_with_field_city(self) -> None:
        """search with --field city only searches city."""
        locations = [
            make_location(description="Seattle HQ", city="Seattle"),
            make_location(
                location_id="loc-2",
                description="Portland Office",
                city="Portland",
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app,
                ["--no-color", "locations", "search", "Seattle", "--field", "city"],
            )
            assert result.exit_code == 0
            assert "Seattle HQ" in result.stdout
            assert "Portland Office" not in result.stdout

    @pytest.mark.unit
    def test_search_with_field_address(self) -> None:
        """search with --field address only searches address."""
        locations = [
            make_location(description="HQ", address="123 Main St", city="Seattle"),
            make_location(
                location_id="loc-2",
                description="Office",
                address="456 Oak Ave",
                city="Seattle",
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app,
                ["--no-color", "locations", "search", "Main", "--field", "address"],
            )
            assert result.exit_code == 0
            assert "HQ" in result.stdout
            assert "Office" not in result.stdout

    @pytest.mark.unit
    def test_search_with_field_company(self) -> None:
        """search with --field company only searches company name."""
        locations = [
            make_location(description="HQ", company_name="Contoso"),
            make_location(
                location_id="loc-2",
                description="Office",
                company_name="Fabrikam",
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app,
                ["--no-color", "locations", "search", "Contoso", "--field", "company"],
            )
            assert result.exit_code == 0
            assert "HQ" in result.stdout
            assert "Office" not in result.stdout


class TestLocationsSearchWildcard:
    """Tests for wildcard pattern support in locations search."""

    @pytest.mark.unit
    def test_search_wildcard_prefix(self) -> None:
        """search with 'Main*' matches locations starting with Main."""
        locations = [
            make_location(description="Main Office", city="Seattle"),
            make_location(
                location_id="loc-2",
                description="Main Street",
                city="Seattle",
            ),
            make_location(
                location_id="loc-3",
                description="Portland Office",
                city="Portland",
                address="456 Oak Ave",  # No "Main" in address
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["--no-color", "locations", "search", "Main*"])
            assert result.exit_code == 0
            assert "Main Office" in result.stdout
            assert "Main Street" in result.stdout
            assert "Portland Office" not in result.stdout

    @pytest.mark.unit
    def test_search_wildcard_suffix(self) -> None:
        """search with '*HQ' matches locations ending with HQ."""
        locations = [
            make_location(description="Seattle HQ", city="Seattle"),
            make_location(
                location_id="loc-2",
                description="NYC HQ",
                city="New York",
            ),
            make_location(
                location_id="loc-3",
                description="Portland Office",
                city="Portland",
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["--no-color", "locations", "search", "*HQ"])
            assert result.exit_code == 0
            assert "Seattle HQ" in result.stdout
            assert "NYC HQ" in result.stdout
            assert "Portland Office" not in result.stdout

    @pytest.mark.unit
    def test_search_wildcard_contains(self) -> None:
        """search with '*central*' matches locations containing central."""
        locations = [
            make_location(description="Central Office", city="Seattle"),
            make_location(
                location_id="loc-2",
                description="NY Central",
                city="New York",
            ),
            make_location(
                location_id="loc-3",
                description="Portland Office",
                city="Portland",
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "locations", "search", "*central*"]
            )
            assert result.exit_code == 0
            assert "Central Office" in result.stdout
            assert "NY Central" in result.stdout
            assert "Portland Office" not in result.stdout

    @pytest.mark.unit
    def test_search_wildcard_case_insensitive(self) -> None:
        """search wildcards are case insensitive."""
        locations = [
            make_location(description="Seattle HQ", city="Seattle"),
            make_location(
                location_id="loc-2",
                description="NYC hq",
                city="New York",
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["--no-color", "locations", "search", "*hq"])
            assert result.exit_code == 0
            assert "Seattle HQ" in result.stdout
            assert "NYC hq" in result.stdout

    @pytest.mark.unit
    def test_search_wildcard_with_field_option(self) -> None:
        """search wildcards work with --field option."""
        locations = [
            make_location(
                description="Main Office", address="456 Oak St", city="Seattle"
            ),
            make_location(
                location_id="loc-2",
                description="Seattle Branch",
                address="123 Main St",
                city="Seattle",
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            # Search for Main* in name field only
            result = runner.invoke(
                app,
                ["--no-color", "locations", "search", "Main*", "--field", "name"],
            )
            assert result.exit_code == 0
            assert "Main Office" in result.stdout
            # Seattle Branch has Main in address, not name
            assert "Seattle Branch" not in result.stdout

    @pytest.mark.unit
    def test_search_wildcard_matches_address(self) -> None:
        """search wildcards match address field."""
        locations = [
            make_location(description="Office A", address="123 Main St"),
            make_location(
                location_id="loc-2",
                description="Office B",
                address="456 Oak Ave",
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["--no-color", "locations", "search", "*Main*"])
            assert result.exit_code == 0
            assert "Office A" in result.stdout
            assert "Office B" not in result.stdout

    @pytest.mark.unit
    def test_search_wildcard_matches_city(self) -> None:
        """search wildcards match city field."""
        locations = [
            make_location(description="Office A", city="Seattle"),
            make_location(
                location_id="loc-2",
                description="Office B",
                city="Portland",
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["--no-color", "locations", "search", "Sea*"])
            assert result.exit_code == 0
            assert "Office A" in result.stdout
            assert "Office B" not in result.stdout

    @pytest.mark.unit
    def test_search_wildcard_matches_company(self) -> None:
        """search wildcards match company_name field."""
        locations = [
            make_location(description="Office A", company_name="Contoso Ltd"),
            make_location(
                location_id="loc-2",
                description="Office B",
                company_name="Fabrikam Inc",
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["--no-color", "locations", "search", "Con*"])
            assert result.exit_code == 0
            assert "Office A" in result.stdout
            assert "Office B" not in result.stdout

    @pytest.mark.unit
    def test_search_wildcard_star_alone_matches_all(self) -> None:
        """search with '*' alone matches all locations."""
        locations = [
            make_location(description="Office A"),
            make_location(location_id="loc-2", description="Office B"),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["--json", "locations", "search", "*"])
            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert len(data) == 2

    @pytest.mark.unit
    def test_search_without_wildcard_still_works(self) -> None:
        """search without wildcards performs substring search (backward compat)."""
        locations = [
            make_location(description="Seattle HQ", city="Seattle"),
            make_location(
                location_id="loc-2",
                description="Portland Office",
                city="Portland",
            ),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["--no-color", "locations", "search", "attle"])
            assert result.exit_code == 0
            assert "Seattle HQ" in result.stdout
            assert "Portland Office" not in result.stdout

    @pytest.mark.unit
    def test_search_wildcard_no_matches(self) -> None:
        """search wildcard with no matches shows appropriate message."""
        locations = [
            make_location(description="Seattle HQ", city="Seattle"),
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "locations", "search", "Chicago*"]
            )
            assert result.exit_code == 0
            assert "No locations found matching" in result.stdout


class TestLocationsSearchWarnings:
    """Tests for performance warning in locations search command.

    Note: Warnings are written to stderr via Rich Console(stderr=True).
    The CliRunner captures both stdout and stderr in result.output,
    while result.stdout contains only stdout. We use result.output to
    verify warnings appear, and result.stdout to verify they don't
    pollute stdout (important for JSON mode piping).
    """

    @pytest.mark.unit
    def test_warning_appears_when_exceeds_threshold(self) -> None:
        """Warning shown when filtering > LARGE_RESULT_THRESHOLD items."""
        # Create enough locations to exceed threshold when list_locations returns them
        locations = [
            make_location(location_id=f"loc-{i}", description=f"Location {i}")
            for i in range(LARGE_RESULT_THRESHOLD + 1)
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "locations", "search", "Location*"]
            )
            assert result.exit_code == 0
            # Warning appears in combined output (stdout + stderr)
            assert "Filtering 1,001 locations" in result.output

    @pytest.mark.unit
    def test_warning_not_shown_at_threshold(self) -> None:
        """Warning NOT shown when filtering exactly LARGE_RESULT_THRESHOLD items."""
        locations = [
            make_location(location_id=f"loc-{i}", description=f"Location {i}")
            for i in range(LARGE_RESULT_THRESHOLD)
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "locations", "search", "Location*"]
            )
            assert result.exit_code == 0
            # Warning should not appear anywhere in output
            assert "Filtering" not in result.output

    @pytest.mark.unit
    def test_warning_not_shown_below_threshold(self) -> None:
        """Warning NOT shown when filtering < LARGE_RESULT_THRESHOLD items."""
        locations = [
            make_location(location_id=f"loc-{i}", description=f"Location {i}")
            for i in range(500)
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "locations", "search", "Location*"]
            )
            assert result.exit_code == 0
            # Warning should not appear anywhere in output
            assert "Filtering" not in result.output

    @pytest.mark.unit
    def test_quiet_flag_suppresses_warning(self) -> None:
        """--quiet flag suppresses warning even with large results."""
        locations = [
            make_location(location_id=f"loc-{i}", description=f"Location {i}")
            for i in range(5000)
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "locations", "search", "--quiet", "Location*"]
            )
            assert result.exit_code == 0
            # Warning should not appear anywhere in output
            assert "Filtering" not in result.output

    @pytest.mark.unit
    def test_warning_shows_thousands_separator(self) -> None:
        """Warning message uses thousands separator formatting."""
        locations = [
            make_location(location_id=f"loc-{i}", description=f"Location {i}")
            for i in range(5234)
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "locations", "search", "Location*"]
            )
            assert result.exit_code == 0
            # Should be formatted as "5,234" not "5234" (in combined output)
            assert "5,234" in result.output
            assert "5234 locations" not in result.output

    @pytest.mark.unit
    def test_json_output_no_warning(self) -> None:
        """JSON output mode does not include warning text in stdout."""
        locations = [
            make_location(location_id=f"loc-{i}", description=f"Location {i}")
            for i in range(5000)
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(app, ["--json", "locations", "search", "Location*"])
            assert result.exit_code == 0
            # JSON should be parseable (stdout only)
            data = json.loads(result.stdout)
            # Should have results (limit is 25 by default)
            assert len(data) <= 25
            # Warning should not appear in stdout (JSON pipe-safe)
            assert "Filtering" not in result.stdout

    @pytest.mark.unit
    def test_warning_contains_expected_text(self) -> None:
        """Warning message contains expected text format."""
        locations = [
            make_location(location_id=f"loc-{i}", description=f"Location {i}")
            for i in range(2500)
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "locations", "search", "Location*"]
            )
            assert result.exit_code == 0
            # Verify full message format (in combined output)
            assert "Filtering 2,500 locations for pattern matching" in result.output

    @pytest.mark.unit
    def test_warning_goes_to_stderr_not_stdout(self) -> None:
        """Warning is written to stderr, not stdout (for pipe safety)."""
        locations = [
            make_location(location_id=f"loc-{i}", description=f"Location {i}")
            for i in range(5000)
        ]

        with (
            patch("teams_phone.cli.locations.CacheManager") as mock_cm_class,
            patch("teams_phone.cli.locations.LocationService") as mock_ls_class,
        ):
            mock_cm = MagicMock()
            mock_cm_class.return_value = mock_cm

            mock_service = MagicMock()
            mock_service.list_locations.return_value = locations
            mock_service.get_staleness_warning.return_value = None
            mock_ls_class.return_value = mock_service

            result = runner.invoke(
                app, ["--no-color", "locations", "search", "Location*"]
            )
            assert result.exit_code == 0
            # Warning appears in combined output but NOT in stdout
            assert "Filtering" in result.output
            assert "Filtering" not in result.stdout


class TestLocationsCommandIntegration:
    """Integration tests for locations command group."""

    @pytest.mark.unit
    def test_locations_commands_appear_in_help(self) -> None:
        """All locations commands appear in locations --help."""
        result = runner.invoke(app, ["locations", "--help"])
        assert result.exit_code == 0
        assert "list" in result.stdout
        assert "show" in result.stdout
        assert "search" in result.stdout

    @pytest.mark.unit
    def test_locations_no_args_shows_help(self) -> None:
        """locations with no args shows help (exit code 2)."""
        result = runner.invoke(app, ["locations"])
        assert result.exit_code == 2
        assert "Usage:" in result.stdout

    @pytest.mark.unit
    def test_locations_appears_in_main_help(self) -> None:
        """locations command group appears in main help."""
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "locations" in result.stdout
