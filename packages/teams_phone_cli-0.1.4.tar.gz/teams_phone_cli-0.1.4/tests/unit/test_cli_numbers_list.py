"""Unit tests for CLI numbers list command."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from teams_phone.cli.main import app
from teams_phone.exceptions import NotFoundError
from teams_phone.models import AssignmentStatus, NumberType
from tests.conftest import CliRunner
from tests.fixtures import make_number, make_user


if TYPE_CHECKING:
    pass

runner = CliRunner()


class TestNumbersListCommand:
    """Tests for numbers list command."""

    @pytest.mark.unit
    def test_list_shows_in_help(self) -> None:
        """list command appears in numbers help."""
        result = runner.invoke(app, ["numbers", "--help"])
        assert result.exit_code == 0
        assert "list" in result.stdout

    @pytest.mark.unit
    def test_list_empty(self, mock_number_service: dict[str, Any]) -> None:
        """list shows empty message when no numbers found."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])

        result = runner.invoke(app, ["numbers", "list"])
        assert result.exit_code == 0
        assert "No numbers found" in result.stdout

    @pytest.mark.unit
    def test_list_shows_numbers(self, mock_number_service: dict[str, Any]) -> None:
        """list shows numbers in table format."""
        numbers = [
            make_number(telephone_number="+14255551001", city="Seattle"),
            make_number(telephone_number="+14255551002", city="Portland"),
        ]
        mock_number_service["number_service"].list_numbers = AsyncMock(
            return_value=numbers
        )

        result = runner.invoke(app, ["--no-color", "numbers", "list"])
        assert result.exit_code == 0
        assert "+14255551001" in result.stdout
        assert "+14255551002" in result.stdout
        assert "Seattle" in result.stdout
        assert "Portland" in result.stdout

    @pytest.mark.unit
    def test_list_json_output(self, mock_number_service: dict[str, Any]) -> None:
        """list outputs valid JSON with --json flag."""
        numbers = [make_number()]
        mock_number_service["number_service"].list_numbers = AsyncMock(
            return_value=numbers
        )

        result = runner.invoke(app, ["--json", "numbers", "list"])
        assert result.exit_code == 0
        data = json.loads(result.stdout)
        assert len(data) == 1
        assert data[0]["telephone_number"] == "+14255551234"
        assert data[0]["number_type"] == "directRouting"
        assert data[0]["assignment_status"] == "unassigned"

    @pytest.mark.unit
    def test_list_json_empty(self, mock_number_service: dict[str, Any]) -> None:
        """list outputs empty JSON array when no numbers."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])

        result = runner.invoke(app, ["--json", "numbers", "list"])
        assert result.exit_code == 0
        data = json.loads(result.stdout)
        assert data == []

    @pytest.mark.unit
    def test_list_with_status_filter(self, mock_number_service: dict[str, Any]) -> None:
        """list passes status filter to service."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])

        result = runner.invoke(app, ["numbers", "list", "--status", "unassigned"])
        assert result.exit_code == 0
        mock_number_service["number_service"].list_numbers.assert_called_once()
        call_kwargs = mock_number_service["number_service"].list_numbers.call_args[1]
        assert call_kwargs["status"] == AssignmentStatus.UNASSIGNED

    @pytest.mark.unit
    def test_list_with_type_filter(self, mock_number_service: dict[str, Any]) -> None:
        """list passes type filter to service."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])

        result = runner.invoke(app, ["numbers", "list", "--type", "callingPlan"])
        assert result.exit_code == 0
        mock_number_service["number_service"].list_numbers.assert_called_once()
        call_kwargs = mock_number_service["number_service"].list_numbers.call_args[1]
        assert call_kwargs["number_type"] == NumberType.CALLING_PLAN

    @pytest.mark.unit
    def test_list_with_city_filter(self, mock_number_service: dict[str, Any]) -> None:
        """list passes city filter to service."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])

        result = runner.invoke(app, ["numbers", "list", "--city", "Seattle"])
        assert result.exit_code == 0
        mock_number_service["number_service"].list_numbers.assert_called_once()
        call_kwargs = mock_number_service["number_service"].list_numbers.call_args[1]
        assert call_kwargs["city"] == "Seattle"

    @pytest.mark.unit
    def test_list_with_contains_flag(self, mock_number_service: dict[str, Any]) -> None:
        """list passes contains flag to service."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])

        result = runner.invoke(app, ["numbers", "list", "--city", "Sea", "--contains"])
        assert result.exit_code == 0
        call_kwargs = mock_number_service["number_service"].list_numbers.call_args[1]
        assert call_kwargs["city"] == "Sea"
        assert call_kwargs["contains"] is True

    @pytest.mark.unit
    def test_list_without_contains_flag_defaults_false(
        self, mock_number_service: dict[str, Any]
    ) -> None:
        """list passes contains=False when --contains not specified."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])

        result = runner.invoke(app, ["numbers", "list", "--city", "Seattle"])
        assert result.exit_code == 0
        call_kwargs = mock_number_service["number_service"].list_numbers.call_args[1]
        assert call_kwargs["contains"] is False

    @pytest.mark.unit
    def test_list_with_limit(self, mock_number_service: dict[str, Any]) -> None:
        """list passes limit to service."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])

        result = runner.invoke(app, ["numbers", "list", "--limit", "10"])
        assert result.exit_code == 0
        call_kwargs = mock_number_service["number_service"].list_numbers.call_args[1]
        assert call_kwargs["max_items"] == 10

    @pytest.mark.unit
    def test_list_with_all_flag(self, mock_number_service: dict[str, Any]) -> None:
        """list passes None max_items for --all flag."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])

        result = runner.invoke(app, ["numbers", "list", "--all"])
        assert result.exit_code == 0
        call_kwargs = mock_number_service["number_service"].list_numbers.call_args[1]
        assert call_kwargs["max_items"] is None

    @pytest.mark.unit
    def test_list_limit_and_all_mutually_exclusive(self) -> None:
        """list errors when both --limit and --all are specified."""
        result = runner.invoke(app, ["numbers", "list", "--limit", "10", "--all"])
        assert result.exit_code == 5  # ValidationError exit code
        assert "Cannot specify both --limit and --all" in result.stdout

    @pytest.mark.unit
    def test_list_default_limit(self, mock_number_service: dict[str, Any]) -> None:
        """list uses default limit of 100 when no limit specified."""
        mock_number_service["number_service"].list_numbers = AsyncMock(return_value=[])

        result = runner.invoke(app, ["numbers", "list"])
        assert result.exit_code == 0
        call_kwargs = mock_number_service["number_service"].list_numbers.call_args[1]
        assert call_kwargs["max_items"] == 100


class TestNumbersListAssignedToFilter:
    """Tests for --assigned-to/-u filter on numbers list command."""

    @pytest.mark.unit
    def test_assigned_to_option_appears_in_help(self) -> None:
        """--assigned-to option appears in list command help."""
        result = runner.invoke(app, ["numbers", "list", "--help"])
        assert result.exit_code == 0
        assert "--assigned-to" in result.plain_stdout
        assert "-u" in result.plain_stdout

    @pytest.mark.unit
    def test_contains_option_appears_in_help(self) -> None:
        """--contains option appears in list command help with example."""
        result = runner.invoke(app, ["numbers", "list", "--help"])
        assert result.exit_code == 0
        assert "--contains" in result.plain_stdout
        assert "substring matching" in result.plain_stdout

    @pytest.mark.unit
    def test_list_with_assigned_to_resolves_user_and_filters(
        self, mock_cli_infrastructure: dict[str, Any]
    ) -> None:
        """list --assigned-to resolves user and passes ID to NumberService."""
        mock_user = make_user(
            id="user-guid-123",
            user_principal_name="john@contoso.com",
            display_name="John Smith",
        )
        numbers = [
            make_number(
                telephone_number="+14255551234",
                assignment_target_id="user-guid-123",
                assignment_status=AssignmentStatus.USER_ASSIGNED,
            ),
        ]

        with (
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(return_value=mock_user)
            mock_us_class.return_value = mock_user_service

            mock_number_service = MagicMock()
            mock_number_service.list_numbers = AsyncMock(return_value=numbers)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app, ["numbers", "list", "--assigned-to", "john@contoso.com"]
            )

            assert result.exit_code == 0
            assert "+14255551234" in result.stdout

            # Verify user was resolved
            mock_user_service.resolve_user.assert_called_once_with("john@contoso.com")

            # Verify list_numbers was called with resolved user ID
            mock_number_service.list_numbers.assert_called_once()
            call_kwargs = mock_number_service.list_numbers.call_args[1]
            assert call_kwargs["assigned_to_user_id"] == "user-guid-123"

    @pytest.mark.unit
    def test_list_with_assigned_to_short_option(
        self, mock_cli_infrastructure: dict[str, Any]
    ) -> None:
        """list -u works as short form of --assigned-to."""
        mock_user = make_user(id="user-guid-456")

        with (
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(return_value=mock_user)
            mock_us_class.return_value = mock_user_service

            mock_number_service = MagicMock()
            mock_number_service.list_numbers = AsyncMock(return_value=[])
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(app, ["numbers", "list", "-u", "jane@contoso.com"])

            assert result.exit_code == 0
            mock_user_service.resolve_user.assert_called_once_with("jane@contoso.com")

    @pytest.mark.unit
    def test_list_with_assigned_to_user_not_found(
        self, mock_cli_infrastructure: dict[str, Any]
    ) -> None:
        """list --assigned-to shows error when user not found."""
        with (
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService"),
        ):
            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(
                side_effect=NotFoundError(
                    "User 'unknown@contoso.com' not found",
                    remediation="Verify the user principal name is correct.",
                )
            )
            mock_us_class.return_value = mock_user_service

            result = runner.invoke(
                app, ["numbers", "list", "--assigned-to", "unknown@contoso.com"]
            )

            assert result.exit_code == 4  # NotFoundError exit code
            assert "User 'unknown@contoso.com' not found" in result.stdout

    @pytest.mark.unit
    def test_list_with_assigned_to_combined_with_other_filters(
        self, mock_cli_infrastructure: dict[str, Any]
    ) -> None:
        """list --assigned-to works with --status, --city, --type filters."""
        mock_user = make_user(id="user-guid-789")

        with (
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(return_value=mock_user)
            mock_us_class.return_value = mock_user_service

            mock_number_service = MagicMock()
            mock_number_service.list_numbers = AsyncMock(return_value=[])
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app,
                [
                    "numbers",
                    "list",
                    "--assigned-to",
                    "user@contoso.com",
                    "--status",
                    "userAssigned",
                    "--city",
                    "Seattle",
                    "--type",
                    "callingPlan",
                ],
            )

            assert result.exit_code == 0

            # Verify all filters passed to list_numbers
            call_kwargs = mock_number_service.list_numbers.call_args[1]
            assert call_kwargs["assigned_to_user_id"] == "user-guid-789"
            assert call_kwargs["status"] == AssignmentStatus.USER_ASSIGNED
            assert call_kwargs["city"] == "Seattle"
            assert call_kwargs["number_type"] == NumberType.CALLING_PLAN

    @pytest.mark.unit
    def test_list_with_assigned_to_json_output(
        self, mock_cli_infrastructure: dict[str, Any]
    ) -> None:
        """list --assigned-to outputs valid JSON."""
        mock_user = make_user(id="user-guid-abc")
        numbers = [
            make_number(
                telephone_number="+14255559999",
                assignment_target_id="user-guid-abc",
                assignment_status=AssignmentStatus.USER_ASSIGNED,
            ),
        ]

        with (
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(return_value=mock_user)
            mock_us_class.return_value = mock_user_service

            mock_number_service = MagicMock()
            mock_number_service.list_numbers = AsyncMock(return_value=numbers)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app, ["--json", "numbers", "list", "--assigned-to", "user@contoso.com"]
            )

            assert result.exit_code == 0
            data = json.loads(result.stdout)
            assert len(data) == 1
            assert data[0]["telephone_number"] == "+14255559999"
            assert data[0]["assignment_target_id"] == "user-guid-abc"

    @pytest.mark.unit
    def test_list_with_assigned_to_empty_result(
        self, mock_cli_infrastructure: dict[str, Any]
    ) -> None:
        """list --assigned-to shows info message when no numbers match."""
        mock_user = make_user(id="user-guid-empty")

        with (
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(return_value=mock_user)
            mock_us_class.return_value = mock_user_service

            mock_number_service = MagicMock()
            mock_number_service.list_numbers = AsyncMock(return_value=[])
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app, ["numbers", "list", "--assigned-to", "user@contoso.com"]
            )

            assert result.exit_code == 0
            assert "No numbers found" in result.stdout

    @pytest.mark.unit
    def test_list_with_assigned_to_display_name(
        self, mock_cli_infrastructure: dict[str, Any]
    ) -> None:
        """list --assigned-to resolves display name to user ID."""
        mock_user = make_user(
            id="user-guid-display",
            user_principal_name="john.smith@contoso.com",
            display_name="John Smith",
        )
        numbers = [
            make_number(
                telephone_number="+14255551111",
                assignment_target_id="user-guid-display",
                assignment_status=AssignmentStatus.USER_ASSIGNED,
            ),
        ]

        with (
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(return_value=mock_user)
            mock_us_class.return_value = mock_user_service

            mock_number_service = MagicMock()
            mock_number_service.list_numbers = AsyncMock(return_value=numbers)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(
                app, ["numbers", "list", "--assigned-to", "John Smith"]
            )

            assert result.exit_code == 0
            assert "+14255551111" in result.stdout

            # Verify display name was passed to resolve_user
            mock_user_service.resolve_user.assert_called_once_with("John Smith")

            # Verify list_numbers was called with resolved user ID
            call_kwargs = mock_number_service.list_numbers.call_args[1]
            assert call_kwargs["assigned_to_user_id"] == "user-guid-display"

    @pytest.mark.unit
    def test_list_with_assigned_to_object_id(
        self, mock_cli_infrastructure: dict[str, Any]
    ) -> None:
        """list --assigned-to resolves object ID (GUID) to user ID."""
        user_guid = "12345678-1234-1234-1234-123456789abc"
        mock_user = make_user(
            id=user_guid,
            user_principal_name="jane.doe@contoso.com",
            display_name="Jane Doe",
        )
        numbers = [
            make_number(
                telephone_number="+14255552222",
                assignment_target_id=user_guid,
                assignment_status=AssignmentStatus.USER_ASSIGNED,
            ),
        ]

        with (
            patch("teams_phone.cli.numbers.UserService") as mock_us_class,
            patch("teams_phone.cli.numbers.NumberService") as mock_ns_class,
        ):
            mock_user_service = MagicMock()
            mock_user_service.resolve_user = AsyncMock(return_value=mock_user)
            mock_us_class.return_value = mock_user_service

            mock_number_service = MagicMock()
            mock_number_service.list_numbers = AsyncMock(return_value=numbers)
            mock_ns_class.return_value = mock_number_service

            result = runner.invoke(app, ["numbers", "list", "--assigned-to", user_guid])

            assert result.exit_code == 0
            assert "+14255552222" in result.stdout

            # Verify GUID was passed to resolve_user
            mock_user_service.resolve_user.assert_called_once_with(user_guid)

            # Verify list_numbers was called with resolved user ID
            call_kwargs = mock_number_service.list_numbers.call_args[1]
            assert call_kwargs["assigned_to_user_id"] == user_guid
