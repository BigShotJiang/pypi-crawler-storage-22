"""Unit tests for Teams Phone CLI exception hierarchy."""

import pytest

from teams_phone.constants import ExitCode
from teams_phone.exceptions import (
    AuthenticationError,
    AuthorizationError,
    BatchError,
    BatchExecutionError,
    BatchValidationError,
    ConfigurationError,
    ContractError,
    JobLockError,
    JobNotFoundError,
    NotFoundError,
    RateLimitError,
    TeamsPhoneError,
    ValidationError,
)


class TestTeamsPhoneError:
    """Tests for the base TeamsPhoneError class."""

    @pytest.mark.unit
    def test_base_exception_exit_code(self) -> None:
        """Base exception has GENERAL_ERROR exit code."""
        exc = TeamsPhoneError("Something went wrong")
        assert exc.exit_code == ExitCode.GENERAL_ERROR
        assert exc.exit_code == 1

    @pytest.mark.unit
    def test_message_attribute(self) -> None:
        """Exception stores message as attribute."""
        message = "Something went wrong"
        exc = TeamsPhoneError(message)
        assert exc.message == message

    @pytest.mark.unit
    def test_str_without_remediation(self) -> None:
        """String representation without remediation is just the message."""
        message = "Something went wrong"
        exc = TeamsPhoneError(message)
        assert str(exc) == message

    @pytest.mark.unit
    def test_str_with_remediation(self) -> None:
        """String representation includes remediation guidance."""
        message = "Token expired"
        remediation = "Run: teams-phone auth login"
        exc = TeamsPhoneError(message, remediation=remediation)
        result = str(exc)
        assert message in result
        assert "To fix:" in result
        assert remediation in result

    @pytest.mark.unit
    def test_remediation_none_by_default(self) -> None:
        """Remediation is None when not provided."""
        exc = TeamsPhoneError("Error")
        assert exc.remediation is None

    @pytest.mark.unit
    def test_inherits_from_exception(self) -> None:
        """Base class inherits from Exception."""
        exc = TeamsPhoneError("Error")
        assert isinstance(exc, Exception)


class TestExitCodeMapping:
    """Tests verifying each exception maps to correct exit code."""

    @pytest.mark.unit
    def test_authentication_error_exit_code(self) -> None:
        """AuthenticationError maps to AUTH_ERROR (2)."""
        exc = AuthenticationError("Token expired")
        assert exc.exit_code == ExitCode.AUTH_ERROR
        assert exc.exit_code == 2

    @pytest.mark.unit
    def test_authorization_error_exit_code(self) -> None:
        """AuthorizationError maps to AUTHZ_ERROR (3)."""
        exc = AuthorizationError("Missing permissions")
        assert exc.exit_code == ExitCode.AUTHZ_ERROR
        assert exc.exit_code == 3

    @pytest.mark.unit
    def test_not_found_error_exit_code(self) -> None:
        """NotFoundError maps to NOT_FOUND (4)."""
        exc = NotFoundError("User not found")
        assert exc.exit_code == ExitCode.NOT_FOUND
        assert exc.exit_code == 4

    @pytest.mark.unit
    def test_validation_error_exit_code(self) -> None:
        """ValidationError maps to VALIDATION_ERROR (5)."""
        exc = ValidationError("Invalid phone number")
        assert exc.exit_code == ExitCode.VALIDATION_ERROR
        assert exc.exit_code == 5

    @pytest.mark.unit
    def test_rate_limit_error_exit_code(self) -> None:
        """RateLimitError maps to RATE_LIMIT (6)."""
        exc = RateLimitError("Too many requests")
        assert exc.exit_code == ExitCode.RATE_LIMIT
        assert exc.exit_code == 6

    @pytest.mark.unit
    def test_configuration_error_exit_code(self) -> None:
        """ConfigurationError maps to CONFIG_ERROR (7)."""
        exc = ConfigurationError("Invalid config")
        assert exc.exit_code == ExitCode.CONFIG_ERROR
        assert exc.exit_code == 7

    @pytest.mark.unit
    def test_contract_error_exit_code(self) -> None:
        """ContractError maps to CONTRACT_ERROR (8)."""
        exc = ContractError("Schema mismatch")
        assert exc.exit_code == ExitCode.CONTRACT_ERROR
        assert exc.exit_code == 8


class TestInheritanceHierarchy:
    """Tests verifying exception inheritance chain."""

    @pytest.mark.unit
    def test_authentication_error_inherits_from_base(self) -> None:
        """AuthenticationError inherits from TeamsPhoneError."""
        exc = AuthenticationError("Error")
        assert isinstance(exc, TeamsPhoneError)
        assert isinstance(exc, Exception)

    @pytest.mark.unit
    def test_authorization_error_inherits_from_base(self) -> None:
        """AuthorizationError inherits from TeamsPhoneError."""
        exc = AuthorizationError("Error")
        assert isinstance(exc, TeamsPhoneError)
        assert isinstance(exc, Exception)

    @pytest.mark.unit
    def test_not_found_error_inherits_from_base(self) -> None:
        """NotFoundError inherits from TeamsPhoneError."""
        exc = NotFoundError("Error")
        assert isinstance(exc, TeamsPhoneError)
        assert isinstance(exc, Exception)

    @pytest.mark.unit
    def test_validation_error_inherits_from_base(self) -> None:
        """ValidationError inherits from TeamsPhoneError."""
        exc = ValidationError("Error")
        assert isinstance(exc, TeamsPhoneError)
        assert isinstance(exc, Exception)

    @pytest.mark.unit
    def test_rate_limit_error_inherits_from_base(self) -> None:
        """RateLimitError inherits from TeamsPhoneError."""
        exc = RateLimitError("Error")
        assert isinstance(exc, TeamsPhoneError)
        assert isinstance(exc, Exception)

    @pytest.mark.unit
    def test_configuration_error_inherits_from_base(self) -> None:
        """ConfigurationError inherits from TeamsPhoneError."""
        exc = ConfigurationError("Error")
        assert isinstance(exc, TeamsPhoneError)
        assert isinstance(exc, Exception)

    @pytest.mark.unit
    def test_contract_error_inherits_from_base(self) -> None:
        """ContractError inherits from TeamsPhoneError."""
        exc = ContractError("Error")
        assert isinstance(exc, TeamsPhoneError)
        assert isinstance(exc, Exception)


class TestRemediationHandling:
    """Tests for remediation message handling across exception types."""

    @pytest.mark.unit
    def test_subclass_with_remediation(self) -> None:
        """Subclass exceptions support remediation messages."""
        remediation = "Check your credentials and try again"
        exc = AuthenticationError("Invalid credentials", remediation=remediation)
        assert exc.remediation == remediation
        assert remediation in str(exc)

    @pytest.mark.unit
    def test_subclass_without_remediation(self) -> None:
        """Subclass exceptions work without remediation."""
        message = "Invalid credentials"
        exc = AuthenticationError(message)
        assert exc.remediation is None
        assert str(exc) == message

    @pytest.mark.unit
    def test_remediation_formatting(self) -> None:
        """Remediation is formatted with 'To fix:' prefix."""
        message = "Configuration file not found"
        remediation = "1. Create ~/.teams-phone/config.toml\n2. Add tenant credentials"
        exc = ConfigurationError(message, remediation=remediation)
        result = str(exc)
        expected = f"{message}\n\nTo fix:\n{remediation}"
        assert result == expected


class TestExceptionRaising:
    """Tests verifying exceptions can be raised and caught."""

    @pytest.mark.unit
    def test_raise_and_catch_base(self) -> None:
        """Base exception can be raised and caught."""
        with pytest.raises(TeamsPhoneError) as exc_info:
            raise TeamsPhoneError("Test error")
        assert str(exc_info.value) == "Test error"

    @pytest.mark.unit
    def test_raise_subclass_catch_as_base(self) -> None:
        """Subclass exception can be caught as base class."""
        with pytest.raises(TeamsPhoneError) as exc_info:
            raise AuthenticationError("Token expired")
        assert exc_info.value.exit_code == ExitCode.AUTH_ERROR

    @pytest.mark.unit
    def test_raise_subclass_catch_specific(self) -> None:
        """Subclass exception can be caught by specific type."""
        with pytest.raises(AuthenticationError) as exc_info:
            raise AuthenticationError("Token expired")
        assert exc_info.value.exit_code == ExitCode.AUTH_ERROR


class TestBatchExceptionExitCodes:
    """Tests verifying batch exception exit codes."""

    @pytest.mark.unit
    def test_batch_error_exit_code(self) -> None:
        """BatchError maps to BATCH_ERROR (9)."""
        exc = BatchError("Batch operation failed")
        assert exc.exit_code == ExitCode.BATCH_ERROR
        assert exc.exit_code == 9

    @pytest.mark.unit
    def test_batch_validation_error_exit_code(self) -> None:
        """BatchValidationError maps to BATCH_VALIDATION_ERROR (10)."""
        exc = BatchValidationError("Invalid CSV format")
        assert exc.exit_code == ExitCode.BATCH_VALIDATION_ERROR
        assert exc.exit_code == 10

    @pytest.mark.unit
    def test_batch_execution_error_exit_code(self) -> None:
        """BatchExecutionError maps to BATCH_EXECUTION_ERROR (11)."""
        exc = BatchExecutionError("Network error during batch")
        assert exc.exit_code == ExitCode.BATCH_EXECUTION_ERROR
        assert exc.exit_code == 11

    @pytest.mark.unit
    def test_job_not_found_error_exit_code(self) -> None:
        """JobNotFoundError maps to JOB_NOT_FOUND (12)."""
        exc = JobNotFoundError("Job abc123 not found")
        assert exc.exit_code == ExitCode.JOB_NOT_FOUND
        assert exc.exit_code == 12

    @pytest.mark.unit
    def test_job_lock_error_exit_code(self) -> None:
        """JobLockError maps to JOB_LOCK_ERROR (13)."""
        exc = JobLockError("job-456")
        assert exc.exit_code == ExitCode.JOB_LOCK_ERROR
        assert exc.exit_code == 13


class TestBatchExceptionInheritance:
    """Tests verifying batch exception inheritance chain."""

    @pytest.mark.unit
    def test_batch_error_inherits_from_base(self) -> None:
        """BatchError inherits from TeamsPhoneError."""
        exc = BatchError("Error")
        assert isinstance(exc, TeamsPhoneError)
        assert isinstance(exc, Exception)

    @pytest.mark.unit
    def test_batch_validation_error_inherits_from_batch_error(self) -> None:
        """BatchValidationError inherits from BatchError and TeamsPhoneError."""
        exc = BatchValidationError("Error")
        assert isinstance(exc, BatchError)
        assert isinstance(exc, TeamsPhoneError)
        assert isinstance(exc, Exception)

    @pytest.mark.unit
    def test_batch_execution_error_inherits_from_batch_error(self) -> None:
        """BatchExecutionError inherits from BatchError and TeamsPhoneError."""
        exc = BatchExecutionError("Error")
        assert isinstance(exc, BatchError)
        assert isinstance(exc, TeamsPhoneError)
        assert isinstance(exc, Exception)

    @pytest.mark.unit
    def test_job_not_found_error_inherits_from_batch_error(self) -> None:
        """JobNotFoundError inherits from BatchError and TeamsPhoneError."""
        exc = JobNotFoundError("Error")
        assert isinstance(exc, BatchError)
        assert isinstance(exc, TeamsPhoneError)
        assert isinstance(exc, Exception)

    @pytest.mark.unit
    def test_job_lock_error_inherits_from_batch_error(self) -> None:
        """JobLockError inherits from BatchError and TeamsPhoneError."""
        exc = JobLockError("job-123")
        assert isinstance(exc, BatchError)
        assert isinstance(exc, TeamsPhoneError)
        assert isinstance(exc, Exception)


class TestJobLockErrorBehavior:
    """Tests for JobLockError specific behavior."""

    @pytest.mark.unit
    def test_stores_active_job_id(self) -> None:
        """JobLockError stores the active job ID as attribute."""
        job_id = "job-abc-123"
        exc = JobLockError(job_id)
        assert exc.active_job_id == job_id

    @pytest.mark.unit
    def test_message_includes_job_id(self) -> None:
        """JobLockError message includes the active job ID."""
        job_id = "job-xyz-789"
        exc = JobLockError(job_id)
        assert job_id in exc.message
        assert "already running" in exc.message

    @pytest.mark.unit
    def test_remediation_includes_job_id(self) -> None:
        """JobLockError remediation includes the job ID and guidance."""
        job_id = "job-test-456"
        exc = JobLockError(job_id)
        assert exc.remediation is not None
        assert job_id in exc.remediation
        assert "batch status" in exc.remediation

    @pytest.mark.unit
    def test_str_includes_remediation(self) -> None:
        """JobLockError string representation includes remediation."""
        job_id = "job-full-test"
        exc = JobLockError(job_id)
        result = str(exc)
        assert job_id in result
        assert "To fix:" in result
        assert "batch status" in result


class TestBatchExceptionRaising:
    """Tests verifying batch exceptions can be raised and caught."""

    @pytest.mark.unit
    def test_raise_batch_error_catch_as_teams_phone_error(self) -> None:
        """BatchError can be caught as TeamsPhoneError."""
        with pytest.raises(TeamsPhoneError) as exc_info:
            raise BatchError("Batch failed")
        assert exc_info.value.exit_code == ExitCode.BATCH_ERROR

    @pytest.mark.unit
    def test_raise_batch_subclass_catch_as_batch_error(self) -> None:
        """Batch subclass exceptions can be caught as BatchError."""
        with pytest.raises(BatchError) as exc_info:
            raise BatchValidationError("Invalid input")
        assert exc_info.value.exit_code == ExitCode.BATCH_VALIDATION_ERROR

    @pytest.mark.unit
    def test_raise_job_lock_error_catch_specific(self) -> None:
        """JobLockError can be caught by specific type."""
        with pytest.raises(JobLockError) as exc_info:
            raise JobLockError("active-job")
        assert exc_info.value.active_job_id == "active-job"
