"""Unit tests for ExecutionLogger."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

import pytest

# Import infrastructure first to avoid circular import
from teams_phone.infrastructure import GraphClient  # noqa: F401
from teams_phone.services.batch_executor import ExecutionLogger


class TestExecutionLoggerInit:
    """Tests for ExecutionLogger initialization."""

    @pytest.mark.unit
    def test_creates_log_file_on_init(self, tmp_path: Path) -> None:
        log_path = tmp_path / "execution.log"
        assert not log_path.exists()

        ExecutionLogger(log_path)

        assert log_path.exists()

    @pytest.mark.unit
    def test_does_not_truncate_existing_file(self, tmp_path: Path) -> None:
        log_path = tmp_path / "execution.log"
        log_path.write_text("previous-content\n", encoding="utf-8")

        ExecutionLogger(log_path)

        assert log_path.read_text(encoding="utf-8") == "previous-content\n"


class TestExecutionLoggerWriteEvent:
    """Tests for the internal _write_event method."""

    @pytest.mark.unit
    def test_writes_valid_json_line(self, tmp_path: Path) -> None:
        log_path = tmp_path / "execution.log"
        logger = ExecutionLogger(log_path)

        logger._write_event("test_event", {"key": "value"})

        lines = log_path.read_text(encoding="utf-8").strip().splitlines()
        assert len(lines) == 1
        entry = json.loads(lines[0])
        assert entry["event"] == "test_event"
        assert entry["key"] == "value"
        assert "timestamp" in entry

    @pytest.mark.unit
    def test_timestamp_is_utc_iso8601(self, tmp_path: Path) -> None:
        log_path = tmp_path / "execution.log"
        logger = ExecutionLogger(log_path)

        fixed_time = datetime(2025, 6, 15, 10, 30, 0, tzinfo=timezone.utc)
        with patch("teams_phone.services.batch_executor.datetime") as mock_dt:
            mock_dt.now.return_value = fixed_time
            mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)
            logger._write_event("test", {})

        entry = json.loads(log_path.read_text(encoding="utf-8").strip().splitlines()[0])
        assert entry["timestamp"] == "2025-06-15T10:30:00+00:00"

    @pytest.mark.unit
    def test_appends_multiple_events(self, tmp_path: Path) -> None:
        log_path = tmp_path / "execution.log"
        logger = ExecutionLogger(log_path)

        logger._write_event("event_1", {"n": 1})
        logger._write_event("event_2", {"n": 2})
        logger._write_event("event_3", {"n": 3})

        lines = log_path.read_text(encoding="utf-8").strip().splitlines()
        assert len(lines) == 3
        for i, line in enumerate(lines, start=1):
            entry = json.loads(line)
            assert entry["event"] == f"event_{i}"
            assert entry["n"] == i

    @pytest.mark.unit
    def test_handles_empty_data_dict(self, tmp_path: Path) -> None:
        log_path = tmp_path / "execution.log"
        logger = ExecutionLogger(log_path)

        logger._write_event("empty_event", {})

        entry = json.loads(log_path.read_text(encoding="utf-8").strip().splitlines()[0])
        assert entry["event"] == "empty_event"
        assert "timestamp" in entry


class TestExecutionLoggerLogStart:
    """Tests for log_start()."""

    @pytest.mark.unit
    def test_writes_execution_start_event(self, tmp_path: Path) -> None:
        log_path = tmp_path / "execution.log"
        logger = ExecutionLogger(log_path)

        logger.log_start(
            job_id="20250101-120000-abcd-test",
            total_items=10,
            concurrency=3,
        )

        entry = json.loads(log_path.read_text(encoding="utf-8").strip().splitlines()[0])
        assert entry["event"] == "execution_start"
        assert entry["job_id"] == "20250101-120000-abcd-test"
        assert entry["total_items"] == 10
        assert entry["concurrency"] == 3
        assert "timestamp" in entry


class TestExecutionLoggerLogItemStart:
    """Tests for log_item_start()."""

    @pytest.mark.unit
    def test_writes_item_start_event(self, tmp_path: Path) -> None:
        log_path = tmp_path / "execution.log"
        logger = ExecutionLogger(log_path)

        logger.log_item_start(
            line_number=5,
            user_upn="alice@contoso.com",
            phone_number="+14155551234",
            attempt=1,
        )

        entry = json.loads(log_path.read_text(encoding="utf-8").strip().splitlines()[0])
        assert entry["event"] == "item_start"
        assert entry["line_number"] == 5
        assert entry["user_upn"] == "alice@contoso.com"
        assert entry["phone_number"] == "+14155551234"
        assert entry["attempt"] == 1


class TestExecutionLoggerLogItemComplete:
    """Tests for log_item_complete()."""

    @pytest.mark.unit
    def test_writes_item_complete_event_succeeded(self, tmp_path: Path) -> None:
        log_path = tmp_path / "execution.log"
        logger = ExecutionLogger(log_path)

        logger.log_item_complete(
            line_number=3,
            user_upn="bob@contoso.com",
            phone_number="+12125551234",
            status="succeeded",
            duration_ms=150,
        )

        entry = json.loads(log_path.read_text(encoding="utf-8").strip().splitlines()[0])
        assert entry["event"] == "item_complete"
        assert entry["line_number"] == 3
        assert entry["user_upn"] == "bob@contoso.com"
        assert entry["phone_number"] == "+12125551234"
        assert entry["status"] == "succeeded"
        assert entry["duration_ms"] == 150
        assert "error_code" not in entry
        assert "error_message" not in entry

    @pytest.mark.unit
    def test_writes_item_complete_event_failed_with_errors(
        self, tmp_path: Path
    ) -> None:
        log_path = tmp_path / "execution.log"
        logger = ExecutionLogger(log_path)

        logger.log_item_complete(
            line_number=7,
            user_upn="carol@contoso.com",
            phone_number="+16505551234",
            status="failed",
            duration_ms=250,
            error_code="BATCH_003",
            error_message="User 'carol@contoso.com' not found",
        )

        entry = json.loads(log_path.read_text(encoding="utf-8").strip().splitlines()[0])
        assert entry["event"] == "item_complete"
        assert entry["status"] == "failed"
        assert entry["error_code"] == "BATCH_003"
        assert entry["error_message"] == "User 'carol@contoso.com' not found"
        assert entry["duration_ms"] == 250

    @pytest.mark.unit
    def test_omits_none_error_fields(self, tmp_path: Path) -> None:
        log_path = tmp_path / "execution.log"
        logger = ExecutionLogger(log_path)

        logger.log_item_complete(
            line_number=1,
            user_upn="user@contoso.com",
            phone_number="+14155551234",
            status="succeeded",
            duration_ms=100,
            error_code=None,
            error_message=None,
            api_response=None,
        )

        entry = json.loads(log_path.read_text(encoding="utf-8").strip().splitlines()[0])
        assert "error_code" not in entry
        assert "error_message" not in entry
        assert "api_response" not in entry

    @pytest.mark.unit
    def test_includes_api_response_when_provided(self, tmp_path: Path) -> None:
        log_path = tmp_path / "execution.log"
        logger = ExecutionLogger(log_path)

        logger.log_item_complete(
            line_number=1,
            user_upn="user@contoso.com",
            phone_number="+14155551234",
            status="succeeded",
            duration_ms=100,
            api_response={"operationId": "abc123", "status": "completed"},
        )

        entry = json.loads(log_path.read_text(encoding="utf-8").strip().splitlines()[0])
        assert entry["api_response"] == {
            "operationId": "abc123",
            "status": "completed",
        }


class TestExecutionLoggerLogEnd:
    """Tests for log_end()."""

    @pytest.mark.unit
    def test_writes_execution_end_event(self, tmp_path: Path) -> None:
        log_path = tmp_path / "execution.log"
        logger = ExecutionLogger(log_path)

        logger.log_end(
            job_id="20250101-120000-abcd-test",
            status="completed",
            succeeded=8,
            failed=2,
            total_duration_ms=5000,
        )

        entry = json.loads(log_path.read_text(encoding="utf-8").strip().splitlines()[0])
        assert entry["event"] == "execution_end"
        assert entry["job_id"] == "20250101-120000-abcd-test"
        assert entry["status"] == "completed"
        assert entry["succeeded"] == 8
        assert entry["failed"] == 2
        assert entry["total_duration_ms"] == 5000
        assert "timestamp" in entry


class TestExecutionLoggerFullWorkflow:
    """End-to-end test for a complete execution logging session."""

    @pytest.mark.unit
    def test_full_execution_log_session(self, tmp_path: Path) -> None:
        log_path = tmp_path / "execution.log"
        logger = ExecutionLogger(log_path)

        logger.log_start(job_id="job-1", total_items=2, concurrency=3)
        logger.log_item_start(
            line_number=1,
            user_upn="a@contoso.com",
            phone_number="+11111111111",
            attempt=1,
        )
        logger.log_item_complete(
            line_number=1,
            user_upn="a@contoso.com",
            phone_number="+11111111111",
            status="succeeded",
            duration_ms=120,
        )
        logger.log_item_start(
            line_number=2,
            user_upn="b@contoso.com",
            phone_number="+12222222222",
            attempt=1,
        )
        logger.log_item_complete(
            line_number=2,
            user_upn="b@contoso.com",
            phone_number="+12222222222",
            status="failed",
            duration_ms=200,
            error_code="BATCH_003",
            error_message="User not found",
        )
        logger.log_end(
            job_id="job-1",
            status="completed",
            succeeded=1,
            failed=1,
            total_duration_ms=350,
        )

        lines = log_path.read_text(encoding="utf-8").strip().splitlines()
        assert len(lines) == 6

        events = [json.loads(line) for line in lines]
        assert events[0]["event"] == "execution_start"
        assert events[1]["event"] == "item_start"
        assert events[2]["event"] == "item_complete"
        assert events[2]["status"] == "succeeded"
        assert events[3]["event"] == "item_start"
        assert events[4]["event"] == "item_complete"
        assert events[4]["status"] == "failed"
        assert events[4]["error_code"] == "BATCH_003"
        assert events[5]["event"] == "execution_end"
        assert events[5]["succeeded"] == 1
        assert events[5]["failed"] == 1

        # Verify all entries are valid JSON with timestamps
        for entry in events:
            assert "timestamp" in entry
            # Should parse as valid datetime
            datetime.fromisoformat(entry["timestamp"])
