"""Unit tests for JobStore."""

import hashlib
import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

import pytest

from teams_phone.exceptions import ConfigurationError, NotFoundError
from teams_phone.infrastructure import JobStore
from teams_phone.models.batch import ItemStatus, Job, JobItem, JobStatus


class TestJobStoreInit:
    """Tests for JobStore initialization."""

    @pytest.mark.unit
    def test_default_path(self) -> None:
        """JobStore uses default path when not specified."""
        store = JobStore()
        assert store.base_path == Path.cwd() / ".teams-phone" / "jobs"

    @pytest.mark.unit
    def test_custom_path(self, tmp_path: Path) -> None:
        """JobStore accepts custom base_path."""
        custom_path = tmp_path / "custom" / "jobs"
        store = JobStore(base_path=custom_path)
        assert store.base_path == custom_path

    @pytest.mark.unit
    def test_none_uses_default(self) -> None:
        """JobStore with None base_path uses default."""
        store = JobStore(base_path=None)
        assert store.base_path == Path.cwd() / ".teams-phone" / "jobs"


class TestJobStorePathHelpers:
    """Tests for JobStore path helper methods."""

    @pytest.mark.unit
    def test_job_dir_returns_correct_path(self, tmp_path: Path) -> None:
        """_job_dir returns base_path / job_id."""
        store = JobStore(base_path=tmp_path)
        job_id = "20260203-143015-a1b2-test-job"
        assert store._job_dir(job_id) == tmp_path / job_id

    @pytest.mark.unit
    def test_job_file_returns_json_path(self, tmp_path: Path) -> None:
        """_job_file returns job directory with job.json."""
        store = JobStore(base_path=tmp_path)
        job_id = "20260203-143015-a1b2-test-job"
        assert store._job_file(job_id) == tmp_path / job_id / "job.json"

    @pytest.mark.unit
    def test_backup_file_returns_backup_path(self, tmp_path: Path) -> None:
        """_backup_file returns job directory with job.json.backup."""
        store = JobStore(base_path=tmp_path)
        job_id = "20260203-143015-a1b2-test-job"
        assert store._backup_file(job_id) == tmp_path / job_id / "job.json.backup"

    @pytest.mark.unit
    def test_path_helpers_consistent(self, tmp_path: Path) -> None:
        """Path helpers return consistent nested structure."""
        store = JobStore(base_path=tmp_path)
        job_id = "20260203-143015-a1b2-test-job"

        job_dir = store._job_dir(job_id)
        job_file = store._job_file(job_id)
        backup_file = store._backup_file(job_id)

        assert job_file.parent == job_dir
        assert backup_file.parent == job_dir


class TestJobStoreGenerateJobId:
    """Tests for JobStore job ID generation."""

    @pytest.mark.unit
    def test_format_matches_pattern(self, tmp_path: Path) -> None:
        """Job ID matches expected format: YYYYMMDD-HHMMSS-{hex4}-{slug}."""
        store = JobStore(base_path=tmp_path)
        job_id = store._generate_job_id("Test Job")

        # Format: YYYYMMDD-HHMMSS-{4hex}-{slug}
        pattern = r"^\d{8}-\d{6}-[a-f0-9]{4}-.+$"
        assert re.match(pattern, job_id), f"Job ID '{job_id}' doesn't match pattern"

    @pytest.mark.unit
    def test_slug_lowercase(self, tmp_path: Path) -> None:
        """Job ID slug is lowercase."""
        store = JobStore(base_path=tmp_path)
        job_id = store._generate_job_id("My Test JOB")

        # Extract slug (everything after third dash)
        parts = job_id.split("-", 3)
        slug = parts[3]
        assert slug == slug.lower()

    @pytest.mark.unit
    def test_slug_replaces_special_chars(self, tmp_path: Path) -> None:
        """Job ID slug replaces special characters with dashes."""
        store = JobStore(base_path=tmp_path)
        job_id = store._generate_job_id("Test!@#Job$%^Name")

        # Extract slug
        parts = job_id.split("-", 3)
        slug = parts[3]

        # Should only contain lowercase letters, numbers, and dashes
        assert re.match(r"^[a-z0-9-]+$", slug), f"Slug '{slug}' has invalid chars"

    @pytest.mark.unit
    def test_slug_truncates_at_30_chars(self, tmp_path: Path) -> None:
        """Job ID slug is truncated to 30 characters."""
        store = JobStore(base_path=tmp_path)
        long_name = "a" * 50  # 50 character name
        job_id = store._generate_job_id(long_name)

        # Extract slug
        parts = job_id.split("-", 3)
        slug = parts[3]
        assert len(slug) <= 30, f"Slug '{slug}' exceeds 30 chars"

    @pytest.mark.unit
    def test_slug_strips_leading_trailing_dashes(self, tmp_path: Path) -> None:
        """Job ID slug strips leading and trailing dashes."""
        store = JobStore(base_path=tmp_path)
        job_id = store._generate_job_id("---test job---")

        # Extract slug
        parts = job_id.split("-", 3)
        slug = parts[3]
        assert not slug.startswith("-"), f"Slug '{slug}' has leading dash"
        assert not slug.endswith("-"), f"Slug '{slug}' has trailing dash"

    @pytest.mark.unit
    def test_uniqueness_different_random(self, tmp_path: Path) -> None:
        """Multiple job IDs have different random portions."""
        store = JobStore(base_path=tmp_path)
        job_ids = [store._generate_job_id("test") for _ in range(10)]

        # Extract random portions (third segment)
        randoms = [jid.split("-")[2] for jid in job_ids]

        # With 10 IDs, we should have multiple unique values
        # (extremely unlikely to have all same with 65536 possibilities)
        assert len(set(randoms)) > 1, "Random portions are not unique"

    @pytest.mark.unit
    def test_timestamp_utc_format(self, tmp_path: Path) -> None:
        """Job ID uses UTC timestamp in expected format."""
        store = JobStore(base_path=tmp_path)

        with patch("teams_phone.infrastructure.job_store.datetime") as mock_dt:
            from datetime import datetime, timezone

            mock_now = datetime(2026, 2, 3, 14, 30, 15, tzinfo=timezone.utc)
            mock_dt.now.return_value = mock_now
            mock_dt.timezone = timezone

            job_id = store._generate_job_id("test")

        # Check timestamp portion
        assert job_id.startswith("20260203-143015-")

    @pytest.mark.unit
    def test_spaces_become_single_dash(self, tmp_path: Path) -> None:
        """Multiple spaces in name become single dash in slug."""
        store = JobStore(base_path=tmp_path)
        job_id = store._generate_job_id("test   multiple   spaces")

        # Extract slug
        parts = job_id.split("-", 3)
        slug = parts[3]

        # Should not have consecutive dashes
        assert "--" not in slug, f"Slug '{slug}' has consecutive dashes"


class TestJobStoreCreateJob:
    """Tests for JobStore.create_job method."""

    @pytest.fixture
    def sample_items(self) -> list[dict]:
        """Sample item dicts for testing."""
        return [
            {
                "line_number": 1,
                "user_upn": "user1@contoso.com",
                "phone_number": "+14155551001",
            },
            {
                "line_number": 2,
                "user_upn": "user2@contoso.com",
                "phone_number": "+14155551002",
            },
        ]

    @pytest.fixture
    def input_csv(self, tmp_path: Path) -> Path:
        """Create a sample input CSV file."""
        csv_content = "user_upn,phone_number\nuser1@contoso.com,+14155551001\nuser2@contoso.com,+14155551002\n"
        csv_file = tmp_path / "input" / "migration.csv"
        csv_file.parent.mkdir(parents=True, exist_ok=True)
        csv_file.write_text(csv_content, encoding="utf-8")
        return csv_file

    @pytest.mark.unit
    def test_creates_job_directory(
        self, tmp_path: Path, input_csv: Path, sample_items: list[dict]
    ) -> None:
        """create_job creates job directory under base_path."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job = store.create_job("Test Migration", input_csv, sample_items)

        job_dir = jobs_path / job.id
        assert job_dir.exists()
        assert job_dir.is_dir()

    @pytest.mark.unit
    def test_copies_input_file(
        self, tmp_path: Path, input_csv: Path, sample_items: list[dict]
    ) -> None:
        """create_job copies input CSV to job directory as input.csv."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job = store.create_job("Test Migration", input_csv, sample_items)

        copied_file = jobs_path / job.id / "input.csv"
        assert copied_file.exists()
        assert copied_file.read_text() == input_csv.read_text()

    @pytest.mark.unit
    def test_computes_sha256_hash(
        self, tmp_path: Path, input_csv: Path, sample_items: list[dict]
    ) -> None:
        """create_job computes SHA-256 hash of input file."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job = store.create_job("Test Migration", input_csv, sample_items)

        expected_hash = hashlib.sha256(input_csv.read_bytes()).hexdigest()
        assert job.input_hash == expected_hash

    @pytest.mark.unit
    def test_creates_job_with_correct_fields(
        self, tmp_path: Path, input_csv: Path, sample_items: list[dict]
    ) -> None:
        """create_job creates Job with all required fields."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job = store.create_job("Test Migration", input_csv, sample_items)

        assert job.name == "Test Migration"
        assert job.status == JobStatus.CREATED
        assert job.input_file == str(input_csv)
        assert job.created_at is not None
        assert job.updated_at is not None
        assert job.started_at is None
        assert job.completed_at is None

    @pytest.mark.unit
    def test_creates_job_items_from_dicts(
        self, tmp_path: Path, input_csv: Path, sample_items: list[dict]
    ) -> None:
        """create_job creates JobItems from item dicts."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job = store.create_job("Test Migration", input_csv, sample_items)

        assert len(job.items) == 2
        assert job.items[0].line_number == 1
        assert job.items[0].user_upn == "user1@contoso.com"
        assert job.items[0].phone_number == "+14155551001"
        assert job.items[0].status == ItemStatus.PENDING
        assert job.items[1].line_number == 2
        assert job.items[1].user_upn == "user2@contoso.com"

    @pytest.mark.unit
    def test_persists_job_json(
        self, tmp_path: Path, input_csv: Path, sample_items: list[dict]
    ) -> None:
        """create_job writes job.json to job directory."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job = store.create_job("Test Migration", input_csv, sample_items)

        job_file = jobs_path / job.id / "job.json"
        assert job_file.exists()

        # Verify JSON content is valid and contains expected data
        data = json.loads(job_file.read_text())
        assert data["name"] == "Test Migration"
        assert data["status"] == "created"
        assert len(data["items"]) == 2

    @pytest.mark.unit
    def test_permission_error_raises_configuration_error(
        self, tmp_path: Path, input_csv: Path, sample_items: list[dict]
    ) -> None:
        """create_job raises ConfigurationError on permission failure."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        with (
            patch.object(Path, "mkdir", side_effect=PermissionError("Access denied")),
            pytest.raises(ConfigurationError) as exc_info,
        ):
            store.create_job("Test Migration", input_csv, sample_items)

        assert "Cannot create job directory" in str(exc_info.value)
        assert exc_info.value.remediation is not None
        assert "write permissions" in exc_info.value.remediation

    @pytest.mark.unit
    def test_job_id_uses_name_in_slug(
        self, tmp_path: Path, input_csv: Path, sample_items: list[dict]
    ) -> None:
        """create_job generates job ID with name slug."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job = store.create_job("Q1 Migration", input_csv, sample_items)

        # Job ID should contain slugified name
        assert "q1-migration" in job.id


class TestJobStoreAtomicWrite:
    """Tests for JobStore._atomic_write method."""

    @pytest.mark.unit
    def test_creates_file_with_correct_content(self, tmp_path: Path) -> None:
        """_atomic_write creates file with expected content."""
        store = JobStore(base_path=tmp_path)
        target_file = tmp_path / "test.json"

        store._atomic_write(target_file, '{"key": "value"}')

        assert target_file.exists()
        assert target_file.read_text(encoding="utf-8") == '{"key": "value"}'

    @pytest.mark.unit
    def test_creates_backup_when_overwriting(self, tmp_path: Path) -> None:
        """_atomic_write creates .backup when overwriting existing file."""
        store = JobStore(base_path=tmp_path)
        target_file = tmp_path / "test.json"
        backup_file = tmp_path / "test.json.backup"

        # Create initial file
        target_file.write_text("original content", encoding="utf-8")

        # Overwrite with new content
        store._atomic_write(target_file, "new content")

        assert backup_file.exists()

    @pytest.mark.unit
    def test_backup_contains_previous_content(self, tmp_path: Path) -> None:
        """_atomic_write backup contains the previous file content."""
        store = JobStore(base_path=tmp_path)
        target_file = tmp_path / "test.json"
        backup_file = tmp_path / "test.json.backup"

        # Create initial file
        target_file.write_text("original content", encoding="utf-8")

        # Overwrite with new content
        store._atomic_write(target_file, "new content")

        assert backup_file.read_text(encoding="utf-8") == "original content"
        assert target_file.read_text(encoding="utf-8") == "new content"

    @pytest.mark.unit
    def test_tmp_file_cleaned_up_after_success(self, tmp_path: Path) -> None:
        """_atomic_write cleans up .tmp file after successful write."""
        store = JobStore(base_path=tmp_path)
        target_file = tmp_path / "test.json"
        tmp_file = tmp_path / "test.json.tmp"

        store._atomic_write(target_file, "content")

        assert target_file.exists()
        assert not tmp_file.exists()

    @pytest.mark.unit
    def test_no_backup_on_first_write(self, tmp_path: Path) -> None:
        """_atomic_write does not create backup when file doesn't exist."""
        store = JobStore(base_path=tmp_path)
        target_file = tmp_path / "test.json"
        backup_file = tmp_path / "test.json.backup"

        store._atomic_write(target_file, "content")

        assert target_file.exists()
        assert not backup_file.exists()

    @pytest.mark.unit
    def test_raises_configuration_error_on_permission_error(
        self, tmp_path: Path
    ) -> None:
        """_atomic_write raises ConfigurationError on permission failure."""
        store = JobStore(base_path=tmp_path)
        target_file = tmp_path / "test.json"

        with (
            patch.object(
                Path, "write_text", side_effect=PermissionError("Access denied")
            ),
            pytest.raises(ConfigurationError) as exc_info,
        ):
            store._atomic_write(target_file, "content")

        assert "Failed to write file" in str(exc_info.value)
        assert exc_info.value.remediation is not None
        assert "write permissions" in exc_info.value.remediation

    @pytest.mark.unit
    def test_raises_configuration_error_on_oserror(self, tmp_path: Path) -> None:
        """_atomic_write raises ConfigurationError on OSError."""
        store = JobStore(base_path=tmp_path)
        target_file = tmp_path / "test.json"

        with (
            patch.object(Path, "write_text", side_effect=OSError("Disk full")),
            pytest.raises(ConfigurationError) as exc_info,
        ):
            store._atomic_write(target_file, "content")

        assert "Failed to write file" in str(exc_info.value)
        assert "disk" in exc_info.value.remediation.lower()

    @pytest.mark.unit
    def test_multiple_rapid_saves_preserve_data(self, tmp_path: Path) -> None:
        """Multiple rapid atomic writes don't corrupt data."""
        store = JobStore(base_path=tmp_path)
        target_file = tmp_path / "test.json"

        # Perform many rapid writes
        for i in range(20):
            content = f'{{"iteration": {i}}}'
            store._atomic_write(target_file, content)

        # Final content should be the last write
        assert target_file.read_text(encoding="utf-8") == '{"iteration": 19}'

    @pytest.mark.unit
    def test_backup_overwritten_on_subsequent_writes(self, tmp_path: Path) -> None:
        """_atomic_write overwrites backup on each write."""
        store = JobStore(base_path=tmp_path)
        target_file = tmp_path / "test.json"
        backup_file = tmp_path / "test.json.backup"

        # First write
        store._atomic_write(target_file, "content1")
        # Second write
        store._atomic_write(target_file, "content2")
        # Third write
        store._atomic_write(target_file, "content3")

        # Backup should contain content2 (the previous write before content3)
        assert backup_file.read_text(encoding="utf-8") == "content2"
        assert target_file.read_text(encoding="utf-8") == "content3"


class TestJobStoreSaveJob:
    """Tests for JobStore.save_job method."""

    @pytest.mark.unit
    def test_writes_json_to_job_file(self, tmp_path: Path) -> None:
        """save_job writes JSON to correct file path."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        # Create job directory manually
        job_id = "20260204-120000-abcd-test"
        job_dir = jobs_path / job_id
        job_dir.mkdir(parents=True)

        from datetime import datetime, timezone

        job = Job(
            id=job_id,
            name="Test Job",
            status=JobStatus.CREATED,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
            input_file="/path/to/input.csv",
            input_hash="abc123",
            items=[],
        )

        store.save_job(job)

        job_file = jobs_path / job_id / "job.json"
        assert job_file.exists()

        data = json.loads(job_file.read_text())
        assert data["id"] == job_id
        assert data["name"] == "Test Job"

    @pytest.mark.unit
    def test_json_is_formatted(self, tmp_path: Path) -> None:
        """save_job writes formatted (indented) JSON."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job_id = "20260204-120000-abcd-test"
        job_dir = jobs_path / job_id
        job_dir.mkdir(parents=True)

        from datetime import datetime, timezone

        job = Job(
            id=job_id,
            name="Test Job",
            status=JobStatus.CREATED,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
            input_file="/path/to/input.csv",
            input_hash="abc123",
            items=[],
        )

        store.save_job(job)

        job_file = jobs_path / job_id / "job.json"
        content = job_file.read_text()
        # Indented JSON has newlines
        assert "\n" in content
        # Should have proper indentation
        assert '  "' in content

    @pytest.mark.unit
    def test_updates_updated_at_timestamp(self, tmp_path: Path) -> None:
        """save_job updates the job's updated_at timestamp."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job_id = "20260204-120000-abcd-test"
        job_dir = jobs_path / job_id
        job_dir.mkdir(parents=True)

        from datetime import datetime, timedelta, timezone

        old_updated_at = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        job = Job(
            id=job_id,
            name="Test Job",
            status=JobStatus.CREATED,
            created_at=datetime.now(timezone.utc),
            updated_at=old_updated_at,
            input_file="/path/to/input.csv",
            input_hash="abc123",
            items=[],
        )

        store.save_job(job)

        # updated_at should be changed to a recent time
        assert job.updated_at > old_updated_at
        # Should be within last minute
        assert datetime.now(timezone.utc) - job.updated_at < timedelta(minutes=1)

    @pytest.mark.unit
    def test_produces_reloadable_json(self, tmp_path: Path) -> None:
        """save_job produces valid JSON that can be parsed."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job_id = "20260204-120000-abcd-test"
        job_dir = jobs_path / job_id
        job_dir.mkdir(parents=True)

        from datetime import datetime, timezone

        job = Job(
            id=job_id,
            name="Test Job",
            status=JobStatus.CREATED,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
            input_file="/path/to/input.csv",
            input_hash="abc123",
            items=[],
        )

        store.save_job(job)

        job_file = jobs_path / job_id / "job.json"
        data = json.loads(job_file.read_text())

        # Verify all key fields are present and valid
        assert data["id"] == job_id
        assert data["name"] == "Test Job"
        assert data["status"] == "created"
        assert "created_at" in data
        assert "updated_at" in data

    @pytest.mark.unit
    def test_creates_backup_on_subsequent_save(self, tmp_path: Path) -> None:
        """save_job creates backup file when overwriting."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job_id = "20260204-120000-abcd-test"
        job_dir = jobs_path / job_id
        job_dir.mkdir(parents=True)

        from datetime import datetime, timezone

        job = Job(
            id=job_id,
            name="Test Job",
            status=JobStatus.CREATED,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
            input_file="/path/to/input.csv",
            input_hash="abc123",
            items=[],
        )

        # First save
        store.save_job(job)
        backup_file = jobs_path / job_id / "job.json.backup"
        assert not backup_file.exists()

        # Second save should create backup
        job.status = JobStatus.RUNNING
        store.save_job(job)
        assert backup_file.exists()

        # Backup should contain previous data (status=created)
        backup_data = json.loads(backup_file.read_text())
        assert backup_data["status"] == "created"

    @pytest.mark.unit
    def test_raises_configuration_error_on_write_failure(self, tmp_path: Path) -> None:
        """save_job raises ConfigurationError when atomic write fails."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job_id = "20260204-120000-abcd-test"
        job_dir = jobs_path / job_id
        job_dir.mkdir(parents=True)

        from datetime import datetime, timezone

        job = Job(
            id=job_id,
            name="Test Job",
            status=JobStatus.CREATED,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
            input_file="/path/to/input.csv",
            input_hash="abc123",
            items=[],
        )

        with (
            patch.object(
                Path, "write_text", side_effect=PermissionError("Access denied")
            ),
            pytest.raises(ConfigurationError) as exc_info,
        ):
            store.save_job(job)

        assert "Failed to write file" in str(exc_info.value)


class TestJobStoreLoadJob:
    """Tests for JobStore.load_job method."""

    def _create_job_file(self, tmp_path: Path, job_id: str, job: Job) -> Path:
        """Helper to create a job JSON file for testing."""
        job_dir = tmp_path / job_id
        job_dir.mkdir(parents=True, exist_ok=True)
        job_file = job_dir / "job.json"
        job_file.write_text(job.model_dump_json(indent=2), encoding="utf-8")
        return job_file

    @pytest.fixture
    def sample_job(self) -> Job:
        """Create a sample Job for testing."""
        now = datetime.now(timezone.utc)
        return Job(
            id="20260204-120000-abcd-test",
            name="Test Job",
            status=JobStatus.CREATED,
            created_at=now,
            updated_at=now,
            input_file="/path/to/input.csv",
            input_hash="abc123def456",
            items=[
                JobItem(
                    line_number=1,
                    user_upn="user1@test.com",
                    phone_number="+14155551001",
                ),
                JobItem(
                    line_number=2,
                    user_upn="user2@test.com",
                    phone_number="+14155551002",
                ),
            ],
        )

    @pytest.mark.unit
    def test_returns_valid_job(self, tmp_path: Path, sample_job: Job) -> None:
        """load_job returns valid Job from job.json."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)
        self._create_job_file(jobs_path, sample_job.id, sample_job)

        loaded = store.load_job(sample_job.id)

        assert loaded.id == sample_job.id
        assert loaded.name == sample_job.name
        assert loaded.status == sample_job.status
        assert len(loaded.items) == 2

    @pytest.mark.unit
    def test_raises_not_found_when_directory_missing(self, tmp_path: Path) -> None:
        """load_job raises NotFoundError when job directory doesn't exist."""
        store = JobStore(base_path=tmp_path)

        with pytest.raises(NotFoundError) as exc_info:
            store.load_job("nonexistent-job-id")

        assert "Job 'nonexistent-job-id' not found" in str(exc_info.value)
        assert exc_info.value.remediation is not None
        assert "list" in exc_info.value.remediation

    @pytest.mark.unit
    def test_falls_back_to_backup_on_corruption(
        self, tmp_path: Path, sample_job: Job
    ) -> None:
        """load_job falls back to backup when main file has invalid JSON."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        # Create job directory with corrupted main file
        job_dir = jobs_path / sample_job.id
        job_dir.mkdir(parents=True)
        job_file = job_dir / "job.json"
        backup_file = job_dir / "job.json.backup"

        # Write corrupted JSON to main file
        job_file.write_text("{ invalid json }", encoding="utf-8")
        # Write valid JSON to backup
        backup_file.write_text(sample_job.model_dump_json(indent=2), encoding="utf-8")

        loaded = store.load_job(sample_job.id)

        assert loaded.id == sample_job.id
        assert loaded.name == sample_job.name

    @pytest.mark.unit
    def test_raises_configuration_error_when_both_corrupted(
        self, tmp_path: Path, sample_job: Job
    ) -> None:
        """load_job raises ConfigurationError when both main and backup are corrupted."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        # Create job directory with corrupted files
        job_dir = jobs_path / sample_job.id
        job_dir.mkdir(parents=True)
        job_file = job_dir / "job.json"
        backup_file = job_dir / "job.json.backup"

        job_file.write_text("{ invalid json }", encoding="utf-8")
        backup_file.write_text("{ also invalid }", encoding="utf-8")

        with pytest.raises(ConfigurationError) as exc_info:
            store.load_job(sample_job.id)

        assert "corrupted" in str(exc_info.value).lower()
        assert exc_info.value.remediation is not None

    @pytest.mark.unit
    def test_backup_recovery_restores_main_file(
        self, tmp_path: Path, sample_job: Job
    ) -> None:
        """load_job restores main file from backup after successful recovery."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        # Create job directory with corrupted main file
        job_dir = jobs_path / sample_job.id
        job_dir.mkdir(parents=True)
        job_file = job_dir / "job.json"
        backup_file = job_dir / "job.json.backup"

        job_file.write_text("{ invalid json }", encoding="utf-8")
        backup_file.write_text(sample_job.model_dump_json(indent=2), encoding="utf-8")

        # Load from backup (should restore main)
        store.load_job(sample_job.id)

        # Main file should now be valid
        content = job_file.read_text(encoding="utf-8")
        data = json.loads(content)
        assert data["id"] == sample_job.id

    @pytest.mark.unit
    def test_handles_missing_backup_gracefully(
        self, tmp_path: Path, sample_job: Job
    ) -> None:
        """load_job works when only main file exists (no backup)."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)
        self._create_job_file(jobs_path, sample_job.id, sample_job)

        # Ensure no backup file exists
        backup_file = jobs_path / sample_job.id / "job.json.backup"
        assert not backup_file.exists()

        loaded = store.load_job(sample_job.id)
        assert loaded.id == sample_job.id

    @pytest.mark.unit
    def test_raises_not_found_when_no_files_exist(self, tmp_path: Path) -> None:
        """load_job raises NotFoundError when job directory has no job files."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        # Create empty job directory
        job_dir = jobs_path / "empty-job"
        job_dir.mkdir(parents=True)

        with pytest.raises(NotFoundError) as exc_info:
            store.load_job("empty-job")

        assert "no job file" in str(exc_info.value).lower()

    @pytest.mark.unit
    def test_raises_configuration_error_on_validation_failure(
        self, tmp_path: Path
    ) -> None:
        """load_job raises ConfigurationError when JSON is valid but data fails validation."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        # Create job directory with invalid data (missing required fields)
        job_dir = jobs_path / "invalid-data-job"
        job_dir.mkdir(parents=True)
        job_file = job_dir / "job.json"
        job_file.write_text('{"id": "test", "name": "test"}', encoding="utf-8")

        with pytest.raises(ConfigurationError) as exc_info:
            store.load_job("invalid-data-job")

        assert "corrupted" in str(exc_info.value).lower()


class TestJobStoreListJobs:
    """Tests for JobStore.list_jobs method."""

    def _create_job_file(self, tmp_path: Path, job: Job) -> None:
        """Helper to create a job JSON file for testing."""
        job_dir = tmp_path / job.id
        job_dir.mkdir(parents=True, exist_ok=True)
        job_file = job_dir / "job.json"
        job_file.write_text(job.model_dump_json(indent=2), encoding="utf-8")

    def _make_job(self, job_id: str, created_at: datetime) -> Job:
        """Helper to create a Job with specific created_at."""
        return Job(
            id=job_id,
            name=f"Job {job_id}",
            status=JobStatus.CREATED,
            created_at=created_at,
            updated_at=created_at,
            input_file="/path/to/input.csv",
            input_hash="abc123",
            items=[],
        )

    @pytest.mark.unit
    def test_returns_empty_list_when_no_jobs(self, tmp_path: Path) -> None:
        """list_jobs returns empty list when no jobs exist."""
        jobs_path = tmp_path / "jobs"
        jobs_path.mkdir()
        store = JobStore(base_path=jobs_path)

        result = store.list_jobs()

        assert result == []

    @pytest.mark.unit
    def test_returns_empty_list_when_base_path_missing(self, tmp_path: Path) -> None:
        """list_jobs returns empty list when base_path doesn't exist."""
        store = JobStore(base_path=tmp_path / "nonexistent")

        result = store.list_jobs()

        assert result == []

    @pytest.mark.unit
    def test_returns_jobs_sorted_descending(self, tmp_path: Path) -> None:
        """list_jobs returns jobs sorted by created_at descending (newest first)."""
        jobs_path = tmp_path / "jobs"
        jobs_path.mkdir()
        store = JobStore(base_path=jobs_path)

        # Create jobs with different timestamps
        now = datetime.now(timezone.utc)
        oldest = self._make_job("job-oldest", now - timedelta(days=2))
        middle = self._make_job("job-middle", now - timedelta(days=1))
        newest = self._make_job("job-newest", now)

        # Create in random order
        self._create_job_file(jobs_path, middle)
        self._create_job_file(jobs_path, oldest)
        self._create_job_file(jobs_path, newest)

        result = store.list_jobs()

        assert len(result) == 3
        assert result[0].id == "job-newest"
        assert result[1].id == "job-middle"
        assert result[2].id == "job-oldest"

    @pytest.mark.unit
    def test_skips_hidden_directories(self, tmp_path: Path) -> None:
        """list_jobs skips directories starting with dot."""
        jobs_path = tmp_path / "jobs"
        jobs_path.mkdir()
        store = JobStore(base_path=jobs_path)

        now = datetime.now(timezone.utc)
        visible_job = self._make_job("visible-job", now)
        self._create_job_file(jobs_path, visible_job)

        # Create hidden directory
        hidden_dir = jobs_path / ".hidden-job"
        hidden_dir.mkdir()
        hidden_file = hidden_dir / "job.json"
        hidden_file.write_text('{"should": "be ignored"}', encoding="utf-8")

        result = store.list_jobs()

        assert len(result) == 1
        assert result[0].id == "visible-job"

    @pytest.mark.unit
    def test_continues_loading_on_corruption(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """list_jobs continues loading when one job is corrupted."""
        jobs_path = tmp_path / "jobs"
        jobs_path.mkdir()
        store = JobStore(base_path=jobs_path)

        now = datetime.now(timezone.utc)
        valid_job = self._make_job("valid-job", now)
        self._create_job_file(jobs_path, valid_job)

        # Create corrupted job
        corrupted_dir = jobs_path / "corrupted-job"
        corrupted_dir.mkdir()
        corrupted_file = corrupted_dir / "job.json"
        corrupted_file.write_text("{ invalid json }", encoding="utf-8")

        result = store.list_jobs()

        # Should still return the valid job
        assert len(result) == 1
        assert result[0].id == "valid-job"

        # Should have logged warning to stderr
        captured = capsys.readouterr()
        assert "Warning" in captured.err
        assert "corrupted-job" in captured.err


class TestJobStoreDeleteJob:
    """Tests for JobStore.delete_job method."""

    def _create_full_job_directory(self, tmp_path: Path, job_id: str) -> Path:
        """Create a job directory with all typical files."""
        job_dir = tmp_path / job_id
        job_dir.mkdir(parents=True)

        # Create all typical job files
        (job_dir / "job.json").write_text('{"id": "test"}', encoding="utf-8")
        (job_dir / "job.json.backup").write_text(
            '{"id": "test-backup"}', encoding="utf-8"
        )
        (job_dir / "input.csv").write_text(
            "upn,phone\nuser@test.com,+1234", encoding="utf-8"
        )

        return job_dir

    @pytest.mark.unit
    def test_removes_entire_job_directory(self, tmp_path: Path) -> None:
        """delete_job removes entire job directory."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job_dir = self._create_full_job_directory(jobs_path, "job-to-delete")
        assert job_dir.exists()

        store.delete_job("job-to-delete")

        assert not job_dir.exists()

    @pytest.mark.unit
    def test_raises_not_found_for_nonexistent_job(self, tmp_path: Path) -> None:
        """delete_job raises NotFoundError for non-existent job."""
        jobs_path = tmp_path / "jobs"
        jobs_path.mkdir()
        store = JobStore(base_path=jobs_path)

        with pytest.raises(NotFoundError) as exc_info:
            store.delete_job("nonexistent-job")

        assert "Job 'nonexistent-job' not found" in str(exc_info.value)
        assert exc_info.value.remediation is not None

    @pytest.mark.unit
    def test_removes_all_job_files(self, tmp_path: Path) -> None:
        """delete_job removes all files in the job directory."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job_dir = self._create_full_job_directory(jobs_path, "job-with-files")

        # Verify files exist before deletion
        assert (job_dir / "job.json").exists()
        assert (job_dir / "job.json.backup").exists()
        assert (job_dir / "input.csv").exists()

        store.delete_job("job-with-files")

        # Verify everything is gone
        assert not job_dir.exists()
        assert not (job_dir / "job.json").exists()
        assert not (job_dir / "job.json.backup").exists()
        assert not (job_dir / "input.csv").exists()
