"""Unit tests for JobStore file locking."""

import json
import os
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from teams_phone.infrastructure import JobStore


class TestJobStoreLockFile:
    """Tests for JobStore._lock_file method."""

    @pytest.mark.unit
    def test_lock_file_returns_correct_path(self, tmp_path: Path) -> None:
        """_lock_file returns base_path / '.lock'."""
        store = JobStore(base_path=tmp_path)
        assert store._lock_file() == tmp_path / ".lock"

    @pytest.mark.unit
    def test_lock_file_is_in_base_path_not_job_dir(self, tmp_path: Path) -> None:
        """_lock_file returns path in base_path, not a job directory."""
        store = JobStore(base_path=tmp_path)
        lock_path = store._lock_file()

        # Lock file should be directly in base_path
        assert lock_path.parent == tmp_path

    @pytest.mark.unit
    def test_lock_file_name_is_hidden(self, tmp_path: Path) -> None:
        """_lock_file returns a hidden file (starts with dot)."""
        store = JobStore(base_path=tmp_path)
        lock_path = store._lock_file()

        assert lock_path.name.startswith(".")


class TestJobStoreAcquireFileLock:
    """Tests for JobStore._acquire_file_lock method."""

    @pytest.mark.unit
    def test_acquire_file_lock_calls_msvcrt_on_windows(self, tmp_path: Path) -> None:
        """_acquire_file_lock uses msvcrt.locking on Windows."""
        store = JobStore(base_path=tmp_path)

        mock_msvcrt = MagicMock()
        mock_msvcrt.LK_NBLCK = 2  # Real value on Windows

        with (
            patch.object(sys, "platform", "win32"),
            patch.dict("sys.modules", {"msvcrt": mock_msvcrt}),
        ):
            store._acquire_file_lock(5)  # fd=5

        mock_msvcrt.locking.assert_called_once_with(5, mock_msvcrt.LK_NBLCK, 1)

    @pytest.mark.unit
    def test_acquire_file_lock_calls_fcntl_on_unix(self, tmp_path: Path) -> None:
        """_acquire_file_lock uses fcntl.flock on Unix."""
        store = JobStore(base_path=tmp_path)

        mock_fcntl = MagicMock()
        mock_fcntl.LOCK_EX = 2
        mock_fcntl.LOCK_NB = 4

        with (
            patch.object(sys, "platform", "linux"),
            patch.dict("sys.modules", {"fcntl": mock_fcntl}),
        ):
            store._acquire_file_lock(5)  # fd=5

        mock_fcntl.flock.assert_called_once_with(
            5, mock_fcntl.LOCK_EX | mock_fcntl.LOCK_NB
        )

    @pytest.mark.unit
    def test_acquire_file_lock_propagates_oserror_on_windows(
        self, tmp_path: Path
    ) -> None:
        """_acquire_file_lock propagates OSError when Windows lock fails."""
        store = JobStore(base_path=tmp_path)

        mock_msvcrt = MagicMock()
        mock_msvcrt.LK_NBLCK = 2
        mock_msvcrt.locking.side_effect = OSError(13, "Permission denied")

        with (
            patch.object(sys, "platform", "win32"),
            patch.dict("sys.modules", {"msvcrt": mock_msvcrt}),
            pytest.raises(OSError) as exc_info,
        ):
            store._acquire_file_lock(5)

        assert exc_info.value.errno == 13

    @pytest.mark.unit
    def test_acquire_file_lock_propagates_blockingio_on_unix(
        self, tmp_path: Path
    ) -> None:
        """_acquire_file_lock propagates BlockingIOError when Unix lock fails."""
        store = JobStore(base_path=tmp_path)

        mock_fcntl = MagicMock()
        mock_fcntl.LOCK_EX = 2
        mock_fcntl.LOCK_NB = 4
        mock_fcntl.flock.side_effect = BlockingIOError(
            11, "Resource temporarily unavailable"
        )

        with (
            patch.object(sys, "platform", "linux"),
            patch.dict("sys.modules", {"fcntl": mock_fcntl}),
            pytest.raises(BlockingIOError) as exc_info,
        ):
            store._acquire_file_lock(5)

        assert exc_info.value.errno == 11


class TestJobStoreReleaseFileLock:
    """Tests for JobStore._release_file_lock method."""

    @pytest.mark.unit
    def test_release_file_lock_calls_msvcrt_on_windows(self, tmp_path: Path) -> None:
        """_release_file_lock uses msvcrt.locking with LK_UNLCK on Windows."""
        store = JobStore(base_path=tmp_path)

        mock_msvcrt = MagicMock()
        mock_msvcrt.LK_UNLCK = 0  # Real value on Windows

        with (
            patch.object(sys, "platform", "win32"),
            patch.dict("sys.modules", {"msvcrt": mock_msvcrt}),
        ):
            store._release_file_lock(5)  # fd=5

        mock_msvcrt.locking.assert_called_once_with(5, mock_msvcrt.LK_UNLCK, 1)

    @pytest.mark.unit
    def test_release_file_lock_calls_fcntl_on_unix(self, tmp_path: Path) -> None:
        """_release_file_lock uses fcntl.flock with LOCK_UN on Unix."""
        store = JobStore(base_path=tmp_path)

        mock_fcntl = MagicMock()
        mock_fcntl.LOCK_UN = 8

        with (
            patch.object(sys, "platform", "linux"),
            patch.dict("sys.modules", {"fcntl": mock_fcntl}),
        ):
            store._release_file_lock(5)  # fd=5

        mock_fcntl.flock.assert_called_once_with(5, mock_fcntl.LOCK_UN)


class TestJobStoreFileLockingIntegration:
    """Integration tests for file locking on the current platform."""

    @pytest.mark.unit
    def test_acquire_and_release_real_lock(self, tmp_path: Path) -> None:
        """Can acquire and release a real lock on the current platform."""
        store = JobStore(base_path=tmp_path)
        tmp_path.mkdir(parents=True, exist_ok=True)

        lock_file = store._lock_file()
        lock_file.touch()

        # Open file in binary write mode as per requirements
        with lock_file.open("wb") as f:
            fd = f.fileno()

            # Should not raise - file is not locked
            store._acquire_file_lock(fd)

            # Release should not raise
            store._release_file_lock(fd)

    @pytest.mark.unit
    def test_lock_file_binary_mode_compatibility(self, tmp_path: Path) -> None:
        """Lock file opens in binary write mode for cross-platform compatibility."""
        store = JobStore(base_path=tmp_path)
        tmp_path.mkdir(parents=True, exist_ok=True)

        lock_file = store._lock_file()

        # Binary write mode as required by acceptance criteria
        with lock_file.open("wb") as f:
            fd = f.fileno()
            # Should be able to lock a binary-mode file
            store._acquire_file_lock(fd)
            store._release_file_lock(fd)


class TestJobStoreLockInfoFile:
    """Tests for JobStore._lock_info_file method."""

    @pytest.mark.unit
    def test_lock_info_file_returns_correct_path(self, tmp_path: Path) -> None:
        """_lock_info_file returns base_path / '.lock_info.json'."""
        store = JobStore(base_path=tmp_path)
        assert store._lock_info_file() == tmp_path / ".lock_info.json"

    @pytest.mark.unit
    def test_lock_info_file_is_in_base_path_not_job_dir(self, tmp_path: Path) -> None:
        """_lock_info_file returns path in base_path, not a job directory."""
        store = JobStore(base_path=tmp_path)
        lock_info_path = store._lock_info_file()

        # Lock info file should be directly in base_path
        assert lock_info_path.parent == tmp_path

    @pytest.mark.unit
    def test_lock_info_file_name_is_hidden(self, tmp_path: Path) -> None:
        """_lock_info_file returns a hidden file (starts with dot)."""
        store = JobStore(base_path=tmp_path)
        lock_info_path = store._lock_info_file()

        assert lock_info_path.name.startswith(".")


class TestJobStoreIsProcessRunning:
    """Tests for JobStore._is_process_running method."""

    @pytest.mark.unit
    def test_is_process_running_returns_true_for_current_process(
        self, tmp_path: Path
    ) -> None:
        """_is_process_running returns True for current process."""
        store = JobStore(base_path=tmp_path)
        current_pid = os.getpid()

        assert store._is_process_running(current_pid) is True

    @pytest.mark.unit
    def test_is_process_running_returns_false_for_nonexistent_pid(
        self, tmp_path: Path
    ) -> None:
        """_is_process_running returns False for non-existent PID."""
        store = JobStore(base_path=tmp_path)
        # Use a very large PID that almost certainly doesn't exist
        nonexistent_pid = 999999999

        assert store._is_process_running(nonexistent_pid) is False

    @pytest.mark.unit
    def test_is_process_running_handles_permission_error_unix(
        self, tmp_path: Path
    ) -> None:
        """_is_process_running returns True on PermissionError (Unix path)."""
        store = JobStore(base_path=tmp_path)

        with (
            patch.object(sys, "platform", "linux"),
            patch("os.kill", side_effect=PermissionError("Access denied")),
        ):
            # PermissionError means process exists but different user
            assert store._is_process_running(12345) is True

    @pytest.mark.unit
    def test_is_process_running_handles_oserror_unix(self, tmp_path: Path) -> None:
        """_is_process_running returns False on OSError (Unix path)."""
        store = JobStore(base_path=tmp_path)

        with (
            patch.object(sys, "platform", "linux"),
            patch("os.kill", side_effect=OSError(3, "No such process")),
        ):
            assert store._is_process_running(12345) is False


class TestJobStoreReadLockInfo:
    """Tests for JobStore._read_lock_info method."""

    @pytest.mark.unit
    def test_read_lock_info_returns_none_when_file_missing(
        self, tmp_path: Path
    ) -> None:
        """_read_lock_info returns None when lock info file doesn't exist."""
        store = JobStore(base_path=tmp_path)
        tmp_path.mkdir(parents=True, exist_ok=True)

        assert store._read_lock_info() is None

    @pytest.mark.unit
    def test_read_lock_info_returns_parsed_dict(self, tmp_path: Path) -> None:
        """_read_lock_info returns parsed dict when file exists with valid JSON."""
        store = JobStore(base_path=tmp_path)
        tmp_path.mkdir(parents=True, exist_ok=True)

        lock_info = {
            "job_id": "20260203-143015-a1b2-migration",
            "pid": 12345,
            "started_at": "2026-02-03T14:30:15.123456+00:00",
        }
        lock_info_file = store._lock_info_file()
        lock_info_file.write_text(json.dumps(lock_info), encoding="utf-8")

        result = store._read_lock_info()

        assert result == lock_info

    @pytest.mark.unit
    def test_read_lock_info_returns_none_on_malformed_json(
        self, tmp_path: Path
    ) -> None:
        """_read_lock_info returns None when file contains invalid JSON."""
        store = JobStore(base_path=tmp_path)
        tmp_path.mkdir(parents=True, exist_ok=True)

        lock_info_file = store._lock_info_file()
        lock_info_file.write_text("not valid json {{{", encoding="utf-8")

        assert store._read_lock_info() is None

    @pytest.mark.unit
    def test_read_lock_info_returns_none_on_missing_fields(
        self, tmp_path: Path
    ) -> None:
        """_read_lock_info returns None when required fields are missing."""
        store = JobStore(base_path=tmp_path)
        tmp_path.mkdir(parents=True, exist_ok=True)

        # Missing 'pid' field
        incomplete_info = {
            "job_id": "20260203-143015-a1b2-migration",
            "started_at": "2026-02-03T14:30:15.123456+00:00",
        }
        lock_info_file = store._lock_info_file()
        lock_info_file.write_text(json.dumps(incomplete_info), encoding="utf-8")

        assert store._read_lock_info() is None

    @pytest.mark.unit
    def test_read_lock_info_returns_none_on_oserror(self, tmp_path: Path) -> None:
        """_read_lock_info returns None when file read fails with OSError."""
        store = JobStore(base_path=tmp_path)
        tmp_path.mkdir(parents=True, exist_ok=True)

        lock_info_file = store._lock_info_file()
        lock_info_file.write_text("{}", encoding="utf-8")

        with patch.object(Path, "read_text", side_effect=OSError("Read error")):
            assert store._read_lock_info() is None


class TestJobStoreWriteLockInfo:
    """Tests for JobStore._write_lock_info method."""

    @pytest.mark.unit
    def test_write_lock_info_creates_json_file(self, tmp_path: Path) -> None:
        """_write_lock_info creates lock info JSON file."""
        store = JobStore(base_path=tmp_path)

        store._write_lock_info("20260203-143015-a1b2-migration")

        lock_info_file = store._lock_info_file()
        assert lock_info_file.exists()

    @pytest.mark.unit
    def test_write_lock_info_contains_job_id(self, tmp_path: Path) -> None:
        """_write_lock_info writes correct job_id."""
        store = JobStore(base_path=tmp_path)
        job_id = "20260203-143015-a1b2-migration"

        store._write_lock_info(job_id)

        lock_info_file = store._lock_info_file()
        data = json.loads(lock_info_file.read_text(encoding="utf-8"))
        assert data["job_id"] == job_id

    @pytest.mark.unit
    def test_write_lock_info_contains_current_pid(self, tmp_path: Path) -> None:
        """_write_lock_info writes current process PID."""
        store = JobStore(base_path=tmp_path)

        store._write_lock_info("test-job")

        lock_info_file = store._lock_info_file()
        data = json.loads(lock_info_file.read_text(encoding="utf-8"))
        assert data["pid"] == os.getpid()

    @pytest.mark.unit
    def test_write_lock_info_contains_iso_timestamp(self, tmp_path: Path) -> None:
        """_write_lock_info writes ISO 8601 timestamp."""
        store = JobStore(base_path=tmp_path)

        store._write_lock_info("test-job")

        lock_info_file = store._lock_info_file()
        data = json.loads(lock_info_file.read_text(encoding="utf-8"))

        # Should be valid ISO 8601 format with timezone
        started_at = data["started_at"]
        assert "T" in started_at  # ISO 8601 separator
        assert "+" in started_at or "Z" in started_at  # Has timezone

    @pytest.mark.unit
    def test_write_lock_info_creates_parent_directory(self, tmp_path: Path) -> None:
        """_write_lock_info creates parent directory if it doesn't exist."""
        # Use a nested path that doesn't exist
        nested_path = tmp_path / "deeply" / "nested" / "jobs"
        store = JobStore(base_path=nested_path)

        store._write_lock_info("test-job")

        assert nested_path.exists()
        assert store._lock_info_file().exists()

    @pytest.mark.unit
    def test_write_lock_info_overwrites_existing_file(self, tmp_path: Path) -> None:
        """_write_lock_info overwrites existing lock info file."""
        store = JobStore(base_path=tmp_path)
        tmp_path.mkdir(parents=True, exist_ok=True)

        # Write initial lock info
        store._write_lock_info("first-job")

        # Overwrite with new job
        store._write_lock_info("second-job")

        lock_info_file = store._lock_info_file()
        data = json.loads(lock_info_file.read_text(encoding="utf-8"))
        assert data["job_id"] == "second-job"


class TestJobStoreGetActiveJobId:
    """Tests for JobStore.get_active_job_id method."""

    @pytest.mark.unit
    def test_get_active_job_id_returns_none_when_no_lock(self, tmp_path: Path) -> None:
        """get_active_job_id returns None when no lock info file exists."""
        store = JobStore(base_path=tmp_path)
        tmp_path.mkdir(parents=True, exist_ok=True)

        assert store.get_active_job_id() is None

    @pytest.mark.unit
    def test_get_active_job_id_returns_job_id_when_lock_held(
        self, tmp_path: Path
    ) -> None:
        """get_active_job_id returns job_id when lock is held by running process."""
        store = JobStore(base_path=tmp_path)
        tmp_path.mkdir(parents=True, exist_ok=True)

        # Write lock info with current process PID (definitely running)
        job_id = "20260203-143015-a1b2-migration"
        lock_info = {
            "job_id": job_id,
            "pid": os.getpid(),
            "started_at": "2026-02-03T14:30:15.123456+00:00",
        }
        lock_info_file = store._lock_info_file()
        lock_info_file.write_text(json.dumps(lock_info), encoding="utf-8")

        assert store.get_active_job_id() == job_id

    @pytest.mark.unit
    def test_get_active_job_id_returns_none_when_stale_lock_exists(
        self, tmp_path: Path
    ) -> None:
        """get_active_job_id returns None when lock is held by dead process."""
        store = JobStore(base_path=tmp_path)
        tmp_path.mkdir(parents=True, exist_ok=True)

        # Write lock info with non-existent PID (stale lock)
        lock_info = {
            "job_id": "20260203-143015-a1b2-migration",
            "pid": 999999999,  # Very unlikely to be a real process
            "started_at": "2026-02-03T14:30:15.123456+00:00",
        }
        lock_info_file = store._lock_info_file()
        lock_info_file.write_text(json.dumps(lock_info), encoding="utf-8")

        assert store.get_active_job_id() is None


class TestJobStoreAcquireLock:
    """Tests for JobStore.acquire_lock context manager."""

    @pytest.mark.unit
    def test_acquire_lock_succeeds_when_no_lock_exists(self, tmp_path: Path) -> None:
        """acquire_lock succeeds when no lock exists."""
        store = JobStore(base_path=tmp_path)

        with store.acquire_lock("test-job"):
            # Lock acquired successfully - verify lock info was written
            lock_info = store._read_lock_info()
            assert lock_info is not None
            assert lock_info["job_id"] == "test-job"
            assert lock_info["pid"] == os.getpid()

    @pytest.mark.unit
    def test_lock_released_on_normal_context_manager_exit(self, tmp_path: Path) -> None:
        """Lock is released when context manager exits normally."""
        store = JobStore(base_path=tmp_path)

        with store.acquire_lock("test-job"):
            # Lock is held
            assert store._lock_file().exists()
            assert store._lock_info_file().exists()

        # After exiting context, files are cleaned up
        assert not store._lock_file().exists()
        assert not store._lock_info_file().exists()

    @pytest.mark.unit
    def test_lock_released_on_exception_within_context(self, tmp_path: Path) -> None:
        """Lock is released when exception occurs within context."""
        store = JobStore(base_path=tmp_path)

        with (
            pytest.raises(ValueError, match="test exception"),
            store.acquire_lock("test-job"),
        ):
            # Lock is held
            assert store._lock_file().exists()
            assert store._lock_info_file().exists()
            raise ValueError("test exception")

        # After exception, files are cleaned up
        assert not store._lock_file().exists()
        assert not store._lock_info_file().exists()

    @pytest.mark.unit
    def test_stale_lock_cleanup_allows_new_lock_acquisition(
        self, tmp_path: Path
    ) -> None:
        """Stale lock from dead process is cleaned up, allowing new lock."""
        store = JobStore(base_path=tmp_path)
        tmp_path.mkdir(parents=True, exist_ok=True)

        # Create stale lock files manually
        lock_file = store._lock_file()
        lock_file.touch()

        stale_lock_info = {
            "job_id": "stale-job",
            "pid": 999999999,  # Non-existent process
            "started_at": "2026-02-03T14:30:15.123456+00:00",
        }
        lock_info_file = store._lock_info_file()
        lock_info_file.write_text(json.dumps(stale_lock_info), encoding="utf-8")

        # Should be able to acquire lock (stale lock cleaned up)
        with store.acquire_lock("new-job"):
            lock_info = store._read_lock_info()
            assert lock_info is not None
            assert lock_info["job_id"] == "new-job"

    @pytest.mark.unit
    def test_acquire_lock_raises_job_lock_error_when_active_lock_held(
        self, tmp_path: Path
    ) -> None:
        """acquire_lock raises JobLockError when active lock is held."""
        from teams_phone.exceptions import JobLockError

        store = JobStore(base_path=tmp_path)
        tmp_path.mkdir(parents=True, exist_ok=True)

        # Simulate an active lock from current process
        lock_info = {
            "job_id": "active-job",
            "pid": os.getpid(),  # Current process, so it's "running"
            "started_at": "2026-02-03T14:30:15.123456+00:00",
        }
        lock_info_file = store._lock_info_file()
        lock_info_file.write_text(json.dumps(lock_info), encoding="utf-8")

        with pytest.raises(JobLockError) as exc_info, store.acquire_lock("new-job"):
            pass  # pragma: no cover

        assert exc_info.value.active_job_id == "active-job"

    @pytest.mark.unit
    def test_nested_acquire_lock_calls_raise_job_lock_error(
        self, tmp_path: Path
    ) -> None:
        """Nested acquire_lock calls raise JobLockError."""
        from teams_phone.exceptions import JobLockError

        store = JobStore(base_path=tmp_path)

        with store.acquire_lock("first-job"):
            # Trying to acquire again while holding lock should fail
            with (
                pytest.raises(JobLockError) as exc_info,
                store.acquire_lock("second-job"),
            ):
                pass  # pragma: no cover

            assert exc_info.value.active_job_id == "first-job"

    @pytest.mark.unit
    def test_acquire_lock_creates_base_path_if_missing(self, tmp_path: Path) -> None:
        """acquire_lock creates base_path directory if it doesn't exist."""
        nested_path = tmp_path / "deeply" / "nested" / "jobs"
        store = JobStore(base_path=nested_path)

        # Directory doesn't exist yet
        assert not nested_path.exists()

        with store.acquire_lock("test-job"):
            # Directory was created
            assert nested_path.exists()


class TestJobLockErrorProperties:
    """Tests for JobLockError exception properties."""

    @pytest.mark.unit
    def test_job_lock_error_has_exit_code_13(self) -> None:
        """JobLockError has exit_code 13 (JOB_LOCK_ERROR)."""
        from teams_phone.exceptions import JobLockError

        error = JobLockError("test-job")
        assert error.exit_code == 13

    @pytest.mark.unit
    def test_job_lock_error_stores_active_job_id(self) -> None:
        """JobLockError stores the active_job_id."""
        from teams_phone.exceptions import JobLockError

        job_id = "20260203-143015-a1b2-migration"
        error = JobLockError(job_id)

        assert error.active_job_id == job_id

    @pytest.mark.unit
    def test_job_lock_error_message_contains_job_id(self) -> None:
        """JobLockError message contains the active job ID."""
        from teams_phone.exceptions import JobLockError

        job_id = "20260203-143015-a1b2-migration"
        error = JobLockError(job_id)

        assert job_id in str(error)

    @pytest.mark.unit
    def test_job_lock_error_has_remediation_message(self) -> None:
        """JobLockError includes remediation guidance."""
        from teams_phone.exceptions import JobLockError

        job_id = "test-job"
        error = JobLockError(job_id)

        assert error.remediation is not None
        assert job_id in error.remediation
        assert "batch status" in error.remediation
