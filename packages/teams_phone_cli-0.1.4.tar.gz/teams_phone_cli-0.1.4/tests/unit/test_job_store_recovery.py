"""Unit tests for JobStore backup and recovery functionality.

Tests covering:
- Atomic write with backup creation (copy, not rename)
- Directory fsync on Unix systems
- Recovery from backup when main file is corrupted
- Logging during recovery operations
"""

import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

import pytest

from teams_phone.exceptions import ConfigurationError
from teams_phone.infrastructure import JobStore
from teams_phone.models.batch import Job, JobItem, JobStatus


@pytest.fixture
def sample_job() -> Job:
    """Create a sample Job for testing."""
    now = datetime.now(timezone.utc)
    return Job(
        id="20260204-120000-abcd-test",
        name="Test Job",
        status=JobStatus.CREATED,
        created_at=now,
        updated_at=now,
        input_file="/path/to/input.csv",
        input_hash="abc123def456",
        items=[
            JobItem(
                line_number=1,
                user_upn="user1@test.com",
                phone_number="+14155551001",
            ),
        ],
    )


class TestAtomicWriteBackupBehavior:
    """Tests for _atomic_write backup creation using copy (not rename)."""

    @pytest.mark.unit
    def test_backup_uses_copy_not_rename(self, tmp_path: Path) -> None:
        """_atomic_write creates backup using copy, preserving original until new is in place."""
        store = JobStore(base_path=tmp_path)
        target_file = tmp_path / "test.json"
        backup_file = tmp_path / "test.json.backup"

        # Create initial file
        original_content = "original content"
        target_file.write_text(original_content, encoding="utf-8")

        # Overwrite with new content
        new_content = "new content"
        store._atomic_write(target_file, new_content)

        # Both files should exist with correct content
        assert target_file.exists()
        assert backup_file.exists()
        assert target_file.read_text(encoding="utf-8") == new_content
        assert backup_file.read_text(encoding="utf-8") == original_content

    @pytest.mark.unit
    def test_atomic_write_creates_tmp_then_renames(self, tmp_path: Path) -> None:
        """_atomic_write creates temp file then atomically renames to target."""
        store = JobStore(base_path=tmp_path)
        target_file = tmp_path / "test.json"

        # Track operations
        operations: list[str] = []
        original_write_text = Path.write_text
        original_replace = Path.replace

        def tracked_write_text(
            self: Path, content: str, encoding: str = "utf-8"
        ) -> int:
            operations.append(f"write:{self.name}")
            return original_write_text(self, content, encoding=encoding)

        def tracked_replace(self: Path, target: Path) -> Path:
            operations.append(f"replace:{self.name}->{target.name}")
            return original_replace(self, target)

        with (
            patch.object(Path, "write_text", tracked_write_text),
            patch.object(Path, "replace", tracked_replace),
        ):
            store._atomic_write(target_file, "content")

        # Verify order: write to tmp, then rename tmp to target
        assert "write:test.json.tmp" in operations
        assert "replace:test.json.tmp->test.json" in operations
        write_idx = operations.index("write:test.json.tmp")
        replace_idx = operations.index("replace:test.json.tmp->test.json")
        assert write_idx < replace_idx

    @pytest.mark.unit
    def test_fsync_called_on_file(self, tmp_path: Path) -> None:
        """_atomic_write calls fsync on the temp file before rename."""
        store = JobStore(base_path=tmp_path)
        target_file = tmp_path / "test.json"

        with patch("os.fsync") as mock_fsync:
            store._atomic_write(target_file, "content")

            # fsync should be called at least once (on the file)
            assert mock_fsync.call_count >= 1

    @pytest.mark.unit
    def test_backup_preserves_metadata_with_copy2(self, tmp_path: Path) -> None:
        """_atomic_write uses shutil.copy2 to preserve file metadata."""
        store = JobStore(base_path=tmp_path)
        target_file = tmp_path / "test.json"

        # Create initial file
        target_file.write_text("original", encoding="utf-8")

        with patch("shutil.copy2") as mock_copy2:
            store._atomic_write(target_file, "new content")

            mock_copy2.assert_called_once()
            call_args = mock_copy2.call_args[0]
            assert call_args[0] == target_file
            assert str(call_args[1]).endswith(".backup")


class TestAtomicWriteDirectoryFsync:
    """Tests for directory fsync behavior in _atomic_write."""

    @pytest.mark.unit
    @pytest.mark.skipif(
        not hasattr(os, "O_DIRECTORY"),
        reason="Directory fsync only available on Unix",
    )
    def test_directory_fsync_called_on_unix(self, tmp_path: Path) -> None:
        """_atomic_write calls fsync on parent directory on Unix systems."""
        store = JobStore(base_path=tmp_path)
        target_file = tmp_path / "test.json"

        with (
            patch("os.open", return_value=42) as mock_open,
            patch("os.fsync"),
            patch("os.close") as mock_close,
        ):
            store._atomic_write(target_file, "content")

            # Check directory fsync was called
            mock_open.assert_any_call(tmp_path, os.O_DIRECTORY)
            mock_close.assert_any_call(42)

    @pytest.mark.unit
    def test_no_directory_fsync_when_o_directory_unavailable(
        self, tmp_path: Path
    ) -> None:
        """_atomic_write skips directory fsync when O_DIRECTORY not available."""
        store = JobStore(base_path=tmp_path)
        target_file = tmp_path / "test.json"

        with (
            patch("os.open") as mock_open,
            patch.object(os, "O_DIRECTORY", None, create=True),
            patch(
                "builtins.hasattr",
                side_effect=lambda obj, name: (
                    name != "O_DIRECTORY" and hasattr(obj, name)
                ),
            ),
        ):
            store._atomic_write(target_file, "content")

            # os.open should not be called with O_DIRECTORY
            for call in mock_open.call_args_list:
                if len(call[0]) >= 2:
                    assert call[0][1] != os.O_DIRECTORY


class TestBackupRecoveryLogging:
    """Tests for logging during backup recovery operations."""

    @pytest.mark.unit
    def test_recovery_warning_logged_on_backup_fallback(
        self, tmp_path: Path, sample_job: Job, caplog: pytest.LogCaptureFixture
    ) -> None:
        """load_job logs warning when recovering from backup file."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        # Create job directory with corrupted main file and valid backup
        job_dir = jobs_path / sample_job.id
        job_dir.mkdir(parents=True)
        job_file = job_dir / "job.json"
        backup_file = job_dir / "job.json.backup"

        job_file.write_text("{ invalid json }", encoding="utf-8")
        backup_file.write_text(sample_job.model_dump_json(indent=2), encoding="utf-8")

        with caplog.at_level(logging.WARNING):
            store.load_job(sample_job.id)

        # Verify warning was logged
        assert len(caplog.records) >= 1
        warning_logged = any(
            "Recovered job" in record.message and "backup" in record.message
            for record in caplog.records
            if record.levelno == logging.WARNING
        )
        assert warning_logged, (
            f"Expected recovery warning, got: {[r.message for r in caplog.records]}"
        )

    @pytest.mark.unit
    def test_no_warning_when_main_file_valid(
        self, tmp_path: Path, sample_job: Job, caplog: pytest.LogCaptureFixture
    ) -> None:
        """load_job does not log warning when main file loads successfully."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        # Create valid main file
        job_dir = jobs_path / sample_job.id
        job_dir.mkdir(parents=True)
        job_file = job_dir / "job.json"
        job_file.write_text(sample_job.model_dump_json(indent=2), encoding="utf-8")

        with caplog.at_level(logging.WARNING):
            store.load_job(sample_job.id)

        # No recovery warning should be logged
        recovery_warnings = [
            r
            for r in caplog.records
            if r.levelno == logging.WARNING and "Recovered" in r.message
        ]
        assert len(recovery_warnings) == 0


class TestRecoveryScenarios:
    """Tests for various recovery scenarios."""

    @pytest.mark.unit
    def test_load_job_succeeds_with_valid_main_file(
        self, tmp_path: Path, sample_job: Job
    ) -> None:
        """load_job succeeds when main job.json is valid."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job_dir = jobs_path / sample_job.id
        job_dir.mkdir(parents=True)
        job_file = job_dir / "job.json"
        job_file.write_text(sample_job.model_dump_json(indent=2), encoding="utf-8")

        loaded = store.load_job(sample_job.id)

        assert loaded.id == sample_job.id
        assert loaded.name == sample_job.name

    @pytest.mark.unit
    def test_load_job_recovers_from_backup_when_main_corrupted(
        self, tmp_path: Path, sample_job: Job
    ) -> None:
        """load_job recovers from backup when main file has invalid JSON."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job_dir = jobs_path / sample_job.id
        job_dir.mkdir(parents=True)
        job_file = job_dir / "job.json"
        backup_file = job_dir / "job.json.backup"

        job_file.write_text("{ invalid json }", encoding="utf-8")
        backup_file.write_text(sample_job.model_dump_json(indent=2), encoding="utf-8")

        loaded = store.load_job(sample_job.id)

        assert loaded.id == sample_job.id
        assert loaded.name == sample_job.name

    @pytest.mark.unit
    def test_load_job_fails_gracefully_when_both_corrupted(
        self, tmp_path: Path, sample_job: Job
    ) -> None:
        """load_job raises ConfigurationError when both main and backup are corrupted."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job_dir = jobs_path / sample_job.id
        job_dir.mkdir(parents=True)
        job_file = job_dir / "job.json"
        backup_file = job_dir / "job.json.backup"

        job_file.write_text("{ invalid json }", encoding="utf-8")
        backup_file.write_text("{ also invalid }", encoding="utf-8")

        with pytest.raises(ConfigurationError) as exc_info:
            store.load_job(sample_job.id)

        assert "corrupted" in str(exc_info.value).lower()
        assert exc_info.value.remediation is not None

    @pytest.mark.unit
    def test_load_job_restores_main_from_backup_after_recovery(
        self, tmp_path: Path, sample_job: Job
    ) -> None:
        """load_job restores main file from backup after successful recovery."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job_dir = jobs_path / sample_job.id
        job_dir.mkdir(parents=True)
        job_file = job_dir / "job.json"
        backup_file = job_dir / "job.json.backup"

        job_file.write_text("{ invalid json }", encoding="utf-8")
        backup_file.write_text(sample_job.model_dump_json(indent=2), encoding="utf-8")

        # Load should trigger recovery
        store.load_job(sample_job.id)

        # Main file should now be restored from backup
        import json

        content = job_file.read_text(encoding="utf-8")
        data = json.loads(content)
        assert data["id"] == sample_job.id

    @pytest.mark.unit
    def test_recovery_from_validation_error(
        self, tmp_path: Path, sample_job: Job
    ) -> None:
        """load_job recovers from backup when main file has validation error."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job_dir = jobs_path / sample_job.id
        job_dir.mkdir(parents=True)
        job_file = job_dir / "job.json"
        backup_file = job_dir / "job.json.backup"

        # Main file has valid JSON but invalid schema (missing required fields)
        job_file.write_text('{"id": "test", "name": "test"}', encoding="utf-8")
        backup_file.write_text(sample_job.model_dump_json(indent=2), encoding="utf-8")

        loaded = store.load_job(sample_job.id)

        assert loaded.id == sample_job.id


class TestCorruptionSimulation:
    """Tests using file corruption simulation."""

    @pytest.mark.unit
    def test_truncated_json_triggers_recovery(
        self, tmp_path: Path, sample_job: Job
    ) -> None:
        """Truncated JSON file triggers backup recovery."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job_dir = jobs_path / sample_job.id
        job_dir.mkdir(parents=True)
        job_file = job_dir / "job.json"
        backup_file = job_dir / "job.json.backup"

        # Simulate truncated JSON (incomplete write)
        valid_json = sample_job.model_dump_json(indent=2)
        truncated_json = valid_json[: len(valid_json) // 2]

        job_file.write_text(truncated_json, encoding="utf-8")
        backup_file.write_text(valid_json, encoding="utf-8")

        loaded = store.load_job(sample_job.id)

        assert loaded.id == sample_job.id

    @pytest.mark.unit
    def test_garbage_text_triggers_recovery(
        self, tmp_path: Path, sample_job: Job
    ) -> None:
        """Garbage text (not JSON) in file triggers backup recovery."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job_dir = jobs_path / sample_job.id
        job_dir.mkdir(parents=True)
        job_file = job_dir / "job.json"
        backup_file = job_dir / "job.json.backup"

        # Write garbage text that's valid UTF-8 but not valid JSON
        job_file.write_text("garbage text that is not json at all!!!", encoding="utf-8")
        backup_file.write_text(sample_job.model_dump_json(indent=2), encoding="utf-8")

        # Should recover from backup despite garbage content
        loaded = store.load_job(sample_job.id)

        assert loaded.id == sample_job.id

    @pytest.mark.unit
    def test_empty_file_triggers_recovery(
        self, tmp_path: Path, sample_job: Job
    ) -> None:
        """Empty main file triggers backup recovery."""
        jobs_path = tmp_path / "jobs"
        store = JobStore(base_path=jobs_path)

        job_dir = jobs_path / sample_job.id
        job_dir.mkdir(parents=True)
        job_file = job_dir / "job.json"
        backup_file = job_dir / "job.json.backup"

        job_file.write_text("", encoding="utf-8")
        backup_file.write_text(sample_job.model_dump_json(indent=2), encoding="utf-8")

        loaded = store.load_job(sample_job.id)

        assert loaded.id == sample_job.id
