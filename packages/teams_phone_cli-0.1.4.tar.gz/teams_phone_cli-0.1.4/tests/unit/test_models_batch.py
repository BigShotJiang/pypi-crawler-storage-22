"""Unit tests for batch migration Pydantic models."""

from datetime import datetime, timedelta, timezone

import pytest
from pydantic import ValidationError

from teams_phone.models import (
    ItemStatus,
    Job,
    JobItem,
    JobStatus,
)


class TestJobStatusEnum:
    """Tests for JobStatus enum."""

    @pytest.mark.unit
    def test_created_value(self) -> None:
        """Created status has correct value."""
        assert JobStatus.CREATED.value == "created"

    @pytest.mark.unit
    def test_validating_value(self) -> None:
        """Validating status has correct value."""
        assert JobStatus.VALIDATING.value == "validating"

    @pytest.mark.unit
    def test_validated_value(self) -> None:
        """Validated status has correct value."""
        assert JobStatus.VALIDATED.value == "validated"

    @pytest.mark.unit
    def test_running_value(self) -> None:
        """Running status has correct value."""
        assert JobStatus.RUNNING.value == "running"

    @pytest.mark.unit
    def test_completed_value(self) -> None:
        """Completed status has correct value."""
        assert JobStatus.COMPLETED.value == "completed"

    @pytest.mark.unit
    def test_interrupted_value(self) -> None:
        """Interrupted status has correct value."""
        assert JobStatus.INTERRUPTED.value == "interrupted"

    @pytest.mark.unit
    def test_is_string_enum(self) -> None:
        """JobStatus is a string enum."""
        assert isinstance(JobStatus.CREATED, str)
        assert isinstance(JobStatus.VALIDATING, str)
        assert isinstance(JobStatus.VALIDATED, str)
        assert isinstance(JobStatus.RUNNING, str)
        assert isinstance(JobStatus.COMPLETED, str)
        assert isinstance(JobStatus.INTERRUPTED, str)


class TestItemStatusEnum:
    """Tests for ItemStatus enum."""

    @pytest.mark.unit
    def test_pending_value(self) -> None:
        """Pending status has correct value."""
        assert ItemStatus.PENDING.value == "pending"

    @pytest.mark.unit
    def test_in_progress_value(self) -> None:
        """In progress status has correct value."""
        assert ItemStatus.IN_PROGRESS.value == "in_progress"

    @pytest.mark.unit
    def test_succeeded_value(self) -> None:
        """Succeeded status has correct value."""
        assert ItemStatus.SUCCEEDED.value == "succeeded"

    @pytest.mark.unit
    def test_failed_value(self) -> None:
        """Failed status has correct value."""
        assert ItemStatus.FAILED.value == "failed"

    @pytest.mark.unit
    def test_needs_review_value(self) -> None:
        """Needs review status has correct value."""
        assert ItemStatus.NEEDS_REVIEW.value == "needs_review"

    @pytest.mark.unit
    def test_is_string_enum(self) -> None:
        """ItemStatus is a string enum."""
        assert isinstance(ItemStatus.PENDING, str)
        assert isinstance(ItemStatus.IN_PROGRESS, str)
        assert isinstance(ItemStatus.SUCCEEDED, str)
        assert isinstance(ItemStatus.FAILED, str)
        assert isinstance(ItemStatus.NEEDS_REVIEW, str)


class TestJobItem:
    """Tests for JobItem model."""

    @pytest.mark.unit
    def test_minimal_creation(self) -> None:
        """JobItem can be created with minimal required fields."""
        item = JobItem(
            line_number=1,
            user_upn="user@contoso.com",
            phone_number="+14255550100",
        )
        assert item.line_number == 1
        assert item.user_upn == "user@contoso.com"
        assert item.phone_number == "+14255550100"

    @pytest.mark.unit
    def test_default_status(self) -> None:
        """JobItem defaults to PENDING status."""
        item = JobItem(
            line_number=1,
            user_upn="user@contoso.com",
            phone_number="+14255550100",
        )
        assert item.status == ItemStatus.PENDING

    @pytest.mark.unit
    def test_default_attempts(self) -> None:
        """JobItem defaults to 0 attempts."""
        item = JobItem(
            line_number=1,
            user_upn="user@contoso.com",
            phone_number="+14255550100",
        )
        assert item.attempts == 0

    @pytest.mark.unit
    def test_default_optional_fields(self) -> None:
        """JobItem optional fields default to None."""
        item = JobItem(
            line_number=1,
            user_upn="user@contoso.com",
            phone_number="+14255550100",
        )
        assert item.error_code is None
        assert item.error_message is None
        assert item.completed_at is None

    @pytest.mark.unit
    def test_full_creation(self) -> None:
        """JobItem can be created with all fields."""
        completed_at = datetime(2026, 2, 4, 12, 0, 0, tzinfo=timezone.utc)
        item = JobItem(
            line_number=5,
            user_upn="failed@contoso.com",
            phone_number="+14255550199",
            status=ItemStatus.FAILED,
            attempts=3,
            error_code="USER_NOT_FOUND",
            error_message="User does not exist in tenant",
            completed_at=completed_at,
        )
        assert item.line_number == 5
        assert item.user_upn == "failed@contoso.com"
        assert item.phone_number == "+14255550199"
        assert item.status == ItemStatus.FAILED
        assert item.attempts == 3
        assert item.error_code == "USER_NOT_FOUND"
        assert item.error_message == "User does not exist in tenant"
        assert item.completed_at == completed_at

    @pytest.mark.unit
    def test_extra_field_rejected(self) -> None:
        """JobItem rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            JobItem(
                line_number=1,
                user_upn="user@contoso.com",
                phone_number="+14255550100",
                extra_field="should fail",  # type: ignore[call-arg]
            )
        assert "extra_forbidden" in str(exc_info.value)

    @pytest.mark.unit
    def test_serialization_roundtrip(self) -> None:
        """JobItem serializes and deserializes correctly."""
        completed_at = datetime(2026, 2, 4, 12, 0, 0, tzinfo=timezone.utc)
        item = JobItem(
            line_number=3,
            user_upn="user@contoso.com",
            phone_number="+14255550100",
            status=ItemStatus.SUCCEEDED,
            attempts=1,
            completed_at=completed_at,
        )
        data = item.model_dump()
        restored = JobItem.model_validate(data)
        assert restored.line_number == item.line_number
        assert restored.user_upn == item.user_upn
        assert restored.phone_number == item.phone_number
        assert restored.status == item.status
        assert restored.attempts == item.attempts
        assert restored.completed_at == item.completed_at


class TestJob:
    """Tests for Job model."""

    @pytest.fixture
    def sample_items(self) -> list[JobItem]:
        """Create a sample list of job items with mixed statuses."""
        return [
            JobItem(
                line_number=1,
                user_upn="user1@contoso.com",
                phone_number="+14255550101",
                status=ItemStatus.SUCCEEDED,
            ),
            JobItem(
                line_number=2,
                user_upn="user2@contoso.com",
                phone_number="+14255550102",
                status=ItemStatus.SUCCEEDED,
            ),
            JobItem(
                line_number=3,
                user_upn="user3@contoso.com",
                phone_number="+14255550103",
                status=ItemStatus.FAILED,
            ),
            JobItem(
                line_number=4,
                user_upn="user4@contoso.com",
                phone_number="+14255550104",
                status=ItemStatus.PENDING,
            ),
            JobItem(
                line_number=5,
                user_upn="user5@contoso.com",
                phone_number="+14255550105",
                status=ItemStatus.PENDING,
            ),
        ]

    @pytest.mark.unit
    def test_minimal_creation(self, sample_items: list[JobItem]) -> None:
        """Job can be created with required fields."""
        now = datetime(2026, 2, 4, 10, 0, 0, tzinfo=timezone.utc)
        job = Job(
            id="20260204-100000-a1b2-test-job",
            name="test-job",
            status=JobStatus.CREATED,
            created_at=now,
            updated_at=now,
            input_file="migrations/test.csv",
            input_hash="abc123def456",
            items=sample_items,
        )
        assert job.id == "20260204-100000-a1b2-test-job"
        assert job.name == "test-job"
        assert job.status == JobStatus.CREATED
        assert job.created_at == now
        assert job.updated_at == now
        assert job.input_file == "migrations/test.csv"
        assert job.input_hash == "abc123def456"
        assert len(job.items) == 5

    @pytest.mark.unit
    def test_default_optional_fields(self, sample_items: list[JobItem]) -> None:
        """Job optional fields default to None."""
        now = datetime(2026, 2, 4, 10, 0, 0, tzinfo=timezone.utc)
        job = Job(
            id="20260204-100000-a1b2-test-job",
            name="test-job",
            status=JobStatus.CREATED,
            created_at=now,
            updated_at=now,
            input_file="test.csv",
            input_hash="abc123",
            items=sample_items,
        )
        assert job.started_at is None
        assert job.completed_at is None

    @pytest.mark.unit
    def test_computed_total_count(self, sample_items: list[JobItem]) -> None:
        """Job.total_count returns total item count."""
        now = datetime(2026, 2, 4, 10, 0, 0, tzinfo=timezone.utc)
        job = Job(
            id="20260204-100000-a1b2-test-job",
            name="test-job",
            status=JobStatus.RUNNING,
            created_at=now,
            updated_at=now,
            input_file="test.csv",
            input_hash="abc123",
            items=sample_items,
        )
        assert job.total_count == 5

    @pytest.mark.unit
    def test_computed_succeeded_count(self, sample_items: list[JobItem]) -> None:
        """Job.succeeded_count returns count of succeeded items."""
        now = datetime(2026, 2, 4, 10, 0, 0, tzinfo=timezone.utc)
        job = Job(
            id="20260204-100000-a1b2-test-job",
            name="test-job",
            status=JobStatus.RUNNING,
            created_at=now,
            updated_at=now,
            input_file="test.csv",
            input_hash="abc123",
            items=sample_items,
        )
        assert job.succeeded_count == 2

    @pytest.mark.unit
    def test_computed_failed_count(self, sample_items: list[JobItem]) -> None:
        """Job.failed_count returns count of failed items."""
        now = datetime(2026, 2, 4, 10, 0, 0, tzinfo=timezone.utc)
        job = Job(
            id="20260204-100000-a1b2-test-job",
            name="test-job",
            status=JobStatus.RUNNING,
            created_at=now,
            updated_at=now,
            input_file="test.csv",
            input_hash="abc123",
            items=sample_items,
        )
        assert job.failed_count == 1

    @pytest.mark.unit
    def test_computed_pending_count(self, sample_items: list[JobItem]) -> None:
        """Job.pending_count returns count of pending items."""
        now = datetime(2026, 2, 4, 10, 0, 0, tzinfo=timezone.utc)
        job = Job(
            id="20260204-100000-a1b2-test-job",
            name="test-job",
            status=JobStatus.RUNNING,
            created_at=now,
            updated_at=now,
            input_file="test.csv",
            input_hash="abc123",
            items=sample_items,
        )
        assert job.pending_count == 2

    @pytest.mark.unit
    def test_computed_duration_when_completed(
        self, sample_items: list[JobItem]
    ) -> None:
        """Job.duration returns timedelta when job is completed."""
        started = datetime(2026, 2, 4, 10, 0, 0, tzinfo=timezone.utc)
        completed = datetime(2026, 2, 4, 10, 30, 0, tzinfo=timezone.utc)
        job = Job(
            id="20260204-100000-a1b2-test-job",
            name="test-job",
            status=JobStatus.COMPLETED,
            created_at=started,
            updated_at=completed,
            started_at=started,
            completed_at=completed,
            input_file="test.csv",
            input_hash="abc123",
            items=sample_items,
        )
        assert job.duration == timedelta(minutes=30)

    @pytest.mark.unit
    def test_computed_duration_when_not_completed(
        self, sample_items: list[JobItem]
    ) -> None:
        """Job.duration returns None when job is not completed."""
        now = datetime(2026, 2, 4, 10, 0, 0, tzinfo=timezone.utc)
        job = Job(
            id="20260204-100000-a1b2-test-job",
            name="test-job",
            status=JobStatus.RUNNING,
            created_at=now,
            updated_at=now,
            started_at=now,
            input_file="test.csv",
            input_hash="abc123",
            items=sample_items,
        )
        assert job.duration is None

    @pytest.mark.unit
    def test_computed_duration_when_not_started(
        self, sample_items: list[JobItem]
    ) -> None:
        """Job.duration returns None when job has not started."""
        now = datetime(2026, 2, 4, 10, 0, 0, tzinfo=timezone.utc)
        job = Job(
            id="20260204-100000-a1b2-test-job",
            name="test-job",
            status=JobStatus.VALIDATED,
            created_at=now,
            updated_at=now,
            input_file="test.csv",
            input_hash="abc123",
            items=sample_items,
        )
        assert job.duration is None

    @pytest.mark.unit
    def test_extra_field_rejected(self, sample_items: list[JobItem]) -> None:
        """Job rejects unknown fields."""
        now = datetime(2026, 2, 4, 10, 0, 0, tzinfo=timezone.utc)
        with pytest.raises(ValidationError) as exc_info:
            Job(
                id="20260204-100000-a1b2-test-job",
                name="test-job",
                status=JobStatus.CREATED,
                created_at=now,
                updated_at=now,
                input_file="test.csv",
                input_hash="abc123",
                items=sample_items,
                extra_field="should fail",  # type: ignore[call-arg]
            )
        assert "extra_forbidden" in str(exc_info.value)

    @pytest.mark.unit
    def test_serialization_includes_computed_fields(
        self, sample_items: list[JobItem]
    ) -> None:
        """Job.model_dump includes computed fields."""
        started = datetime(2026, 2, 4, 10, 0, 0, tzinfo=timezone.utc)
        completed = datetime(2026, 2, 4, 10, 15, 0, tzinfo=timezone.utc)
        job = Job(
            id="20260204-100000-a1b2-test-job",
            name="test-job",
            status=JobStatus.COMPLETED,
            created_at=started,
            updated_at=completed,
            started_at=started,
            completed_at=completed,
            input_file="test.csv",
            input_hash="abc123",
            items=sample_items,
        )
        data = job.model_dump()
        assert data["total_count"] == 5
        assert data["succeeded_count"] == 2
        assert data["failed_count"] == 1
        assert data["pending_count"] == 2
        assert data["duration"] == timedelta(minutes=15)

    @pytest.mark.unit
    def test_serialization_roundtrip(self, sample_items: list[JobItem]) -> None:
        """Job serializes and deserializes correctly (excluding computed fields)."""
        started = datetime(2026, 2, 4, 10, 0, 0, tzinfo=timezone.utc)
        completed = datetime(2026, 2, 4, 10, 30, 0, tzinfo=timezone.utc)
        job = Job(
            id="20260204-100000-a1b2-test-job",
            name="test-job",
            status=JobStatus.COMPLETED,
            created_at=started,
            updated_at=completed,
            started_at=started,
            completed_at=completed,
            input_file="migrations/q1.csv",
            input_hash="sha256hash123",
            items=sample_items,
        )
        # Exclude computed fields for roundtrip (they're recomputed from items)
        data = job.model_dump(
            exclude={
                "total_count",
                "succeeded_count",
                "failed_count",
                "pending_count",
                "duration",
            }
        )
        restored = Job.model_validate(data)
        assert restored.id == job.id
        assert restored.name == job.name
        assert restored.status == job.status
        assert restored.created_at == job.created_at
        assert restored.updated_at == job.updated_at
        assert restored.started_at == job.started_at
        assert restored.completed_at == job.completed_at
        assert restored.input_file == job.input_file
        assert restored.input_hash == job.input_hash
        assert len(restored.items) == len(job.items)
        # Computed fields are recalculated from items
        assert restored.total_count == job.total_count
        assert restored.succeeded_count == job.succeeded_count
        assert restored.failed_count == job.failed_count
        assert restored.pending_count == job.pending_count
        assert restored.duration == job.duration

    @pytest.mark.unit
    def test_empty_items_list(self) -> None:
        """Job can be created with empty items list."""
        now = datetime(2026, 2, 4, 10, 0, 0, tzinfo=timezone.utc)
        job = Job(
            id="20260204-100000-a1b2-empty-job",
            name="empty-job",
            status=JobStatus.CREATED,
            created_at=now,
            updated_at=now,
            input_file="empty.csv",
            input_hash="empty123",
            items=[],
        )
        assert job.total_count == 0
        assert job.succeeded_count == 0
        assert job.failed_count == 0
        assert job.pending_count == 0
