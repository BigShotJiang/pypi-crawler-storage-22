"""Unit tests for ValidationService."""

from datetime import datetime, timezone
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from teams_phone.exceptions import NotFoundError

# Import infrastructure first to avoid circular import
# (graph_client imports auth_service which imports infrastructure)
from teams_phone.infrastructure import GraphClient  # noqa: F401
from teams_phone.models.batch import ItemStatus, Job, JobItem, JobStatus
from teams_phone.models.number import NumberAssignment
from teams_phone.models.user import UserConfiguration
from teams_phone.services.validation_service import (
    ValidationIssue,
    ValidationReport,
    ValidationService,
)


def make_job(
    job_id: str = "20240101-120000-abcd-test",
    name: str = "Test Job",
    items: list[JobItem] | None = None,
) -> Job:
    """Create a Job instance for testing.

    Args:
        job_id: Unique job identifier.
        name: Human-readable job name.
        items: List of job items (defaults to empty list).

    Returns:
        A Job instance configured for testing.
    """
    now = datetime.now(timezone.utc)
    return Job(
        id=job_id,
        name=name,
        status=JobStatus.CREATED,
        created_at=now,
        updated_at=now,
        input_file="test.csv",
        input_hash="abc123",
        items=items or [],
    )


def make_job_item(
    line_number: int = 1,
    user_upn: str = "user@contoso.com",
    phone_number: str = "+14155551234",
    status: ItemStatus = ItemStatus.PENDING,
) -> JobItem:
    """Create a JobItem instance for testing.

    Args:
        line_number: 1-indexed line number from CSV.
        user_upn: User principal name.
        phone_number: Phone number in E.164 format.
        status: Initial item status.

    Returns:
        A JobItem instance configured for testing.
    """
    return JobItem(
        line_number=line_number,
        user_upn=user_upn,
        phone_number=phone_number,
        status=status,
    )


def make_user_dict(
    user_id: str = "user-1",
    upn: str = "user1@contoso.com",
    tenant_id: str = "tenant-123",
    display_name: str | None = "Test User",
    account_type: str = "user",
    enterprise_voice: bool = True,
    phone_numbers: list[dict[str, str]] | None = None,
) -> dict[str, Any]:
    """Create a user configuration dictionary for testing.

    Args:
        user_id: User's Entra object ID.
        upn: User principal name (email).
        tenant_id: Tenant ID.
        display_name: User's display name.
        account_type: Account type value.
        enterprise_voice: Whether enterprise voice is enabled.
        phone_numbers: List of phone number dicts.

    Returns:
        Dictionary matching Graph API user configuration response format.
    """
    return {
        "id": user_id,
        "userPrincipalName": upn,
        "tenantId": tenant_id,
        "displayName": display_name,
        "accountType": account_type,
        "isEnterpriseVoiceEnabled": enterprise_voice,
        "featureTypes": ["Teams"],
        "telephoneNumbers": phone_numbers or [],
        "effectivePolicyAssignments": [],
    }


def make_number_dict(
    number_id: str = "num-1",
    telephone_number: str = "+14155551234",
    number_type: str = "directRouting",
    activation_state: str = "activated",
    assignment_status: str = "unassigned",
    city: str | None = "Seattle",
    location_id: str | None = None,
    assignment_target_id: str | None = None,
) -> dict[str, Any]:
    """Create a number assignment dictionary for testing.

    Args:
        number_id: Unique identifier for the number.
        telephone_number: Phone number in E.164 format.
        number_type: Type of phone number.
        activation_state: Activation state of the number.
        assignment_status: Assignment status.
        city: City associated with the number.
        location_id: Emergency location ID.
        assignment_target_id: Assigned user or resource ID.

    Returns:
        Dictionary matching Graph API number assignment response format.
    """
    return {
        "id": number_id,
        "telephoneNumber": telephone_number,
        "numberType": number_type,
        "activationState": activation_state,
        "assignmentStatus": assignment_status,
        "capabilities": ["userAssignment"],
        "city": city,
        "locationId": location_id,
        "assignmentTargetId": assignment_target_id,
    }


class TestValidationIssueDataclass:
    """Tests for ValidationIssue dataclass."""

    @pytest.mark.unit
    def test_creates_with_required_fields(self) -> None:
        """ValidationIssue can be created with all required fields."""
        issue = ValidationIssue(
            line_number=5,
            field="user_upn",
            value="invalid@example",
            error_code="BATCH_003",
            error_message="User not found in tenant",
        )

        assert issue.line_number == 5
        assert issue.field == "user_upn"
        assert issue.value == "invalid@example"
        assert issue.error_code == "BATCH_003"
        assert issue.error_message == "User not found in tenant"
        assert issue.suggested_fix is None

    @pytest.mark.unit
    def test_creates_with_suggested_fix(self) -> None:
        """ValidationIssue can include an optional suggested_fix."""
        issue = ValidationIssue(
            line_number=3,
            field="phone_number",
            value="555-1234",
            error_code="BATCH_005",
            error_message="Number not found in tenant inventory",
            suggested_fix="Verify the number is assigned to your tenant",
        )

        assert issue.suggested_fix == "Verify the number is assigned to your tenant"


class TestValidationReportDataclass:
    """Tests for ValidationReport dataclass."""

    @pytest.mark.unit
    def test_creates_with_required_fields(self) -> None:
        """ValidationReport can be created with required count fields."""
        report = ValidationReport(
            total_items=10,
            valid_count=8,
            invalid_count=2,
        )

        assert report.total_items == 10
        assert report.valid_count == 8
        assert report.invalid_count == 2
        assert report.issues == []
        assert report.warnings == []

    @pytest.mark.unit
    def test_creates_with_issues_list(self) -> None:
        """ValidationReport can include a list of validation issues."""
        issue = ValidationIssue(
            line_number=1,
            field="user_upn",
            value="missing@contoso.com",
            error_code="BATCH_003",
            error_message="User not found",
        )
        report = ValidationReport(
            total_items=5,
            valid_count=4,
            invalid_count=1,
            issues=[issue],
        )

        assert len(report.issues) == 1
        assert report.issues[0].error_code == "BATCH_003"

    @pytest.mark.unit
    def test_creates_with_warnings_list(self) -> None:
        """ValidationReport can include a list of warning messages."""
        report = ValidationReport(
            total_items=3,
            valid_count=3,
            invalid_count=0,
            warnings=["User already has this number assigned (idempotent)"],
        )

        assert len(report.warnings) == 1
        assert "idempotent" in report.warnings[0]


class TestValidationServiceInit:
    """Tests for ValidationService initialization."""

    @pytest.mark.unit
    def test_accepts_user_and_number_services(self) -> None:
        """ValidationService accepts UserService and NumberService dependencies."""
        mock_user_service = MagicMock()
        mock_number_service = MagicMock()

        service = ValidationService(mock_user_service, mock_number_service)

        assert service.user_service is mock_user_service
        assert service.number_service is mock_number_service


class TestValidationServiceValidateJob:
    """Tests for ValidationService.validate_job method."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_validate_job_returns_job_and_report(self) -> None:
        """validate_job returns a tuple of (Job, ValidationReport)."""
        user = UserConfiguration(**make_user_dict())
        number = NumberAssignment(**make_number_dict(assignment_status="unassigned"))
        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(return_value=number)
        service = ValidationService(mock_user_service, mock_number_service)

        items = [
            make_job_item(1, "user1@contoso.com", "+14155551001"),
            make_job_item(2, "user2@contoso.com", "+14155551002"),
        ]
        job = make_job(items=items)

        result_job, report = await service.validate_job(job)

        assert result_job is not None
        assert isinstance(report, ValidationReport)

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_validate_job_empty_job_returns_zero_counts(self) -> None:
        """validate_job handles empty job with zero items."""
        mock_user_service = MagicMock()
        mock_number_service = MagicMock()
        service = ValidationService(mock_user_service, mock_number_service)

        job = make_job(items=[])

        _, report = await service.validate_job(job)

        assert report.total_items == 0
        assert report.valid_count == 0
        assert report.invalid_count == 0


class TestValidationServiceUserValidation:
    """Tests for ValidationService user existence and license validation."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_user_exists_no_issues_added(self) -> None:
        """When user exists, no validation issues are added."""
        user = UserConfiguration(
            **make_user_dict(
                user_id="user-123",
                upn="user1@contoso.com",
                enterprise_voice=True,
            )
        )
        number = NumberAssignment(**make_number_dict(assignment_status="unassigned"))
        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(return_value=number)
        service = ValidationService(mock_user_service, mock_number_service)

        job = make_job(items=[make_job_item(1, "user1@contoso.com", "+14155551001")])

        _, report = await service.validate_job(job)

        assert report.issues == []
        assert report.invalid_count == 0
        assert report.valid_count == 1
        assert job.items[0].status == ItemStatus.PENDING

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_user_not_found_creates_batch_003_issue(self) -> None:
        """When user not found, BATCH_003 issue is created and item marked FAILED."""
        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(
            side_effect=NotFoundError("User not found")
        )
        mock_number_service = MagicMock()
        service = ValidationService(mock_user_service, mock_number_service)

        job = make_job(items=[make_job_item(1, "missing@contoso.com", "+14155551001")])

        _, report = await service.validate_job(job)

        assert len(report.issues) == 1
        issue = report.issues[0]
        assert issue.line_number == 1
        assert issue.field == "user_upn"
        assert issue.value == "missing@contoso.com"
        assert issue.error_code == "BATCH_003"
        assert issue.error_message == "User not found in tenant"
        assert issue.suggested_fix is not None

        assert report.invalid_count == 1
        assert report.valid_count == 0

        assert job.items[0].status == ItemStatus.FAILED
        assert job.items[0].error_code == "BATCH_003"
        assert job.items[0].error_message == "User not found"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_license_check_enabled_user_licensed_no_issues(self) -> None:
        """When license check enabled and user has license, no issues added."""
        user = UserConfiguration(
            **make_user_dict(
                upn="user1@contoso.com",
                enterprise_voice=True,
            )
        )
        number = NumberAssignment(**make_number_dict(assignment_status="unassigned"))
        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(return_value=number)
        service = ValidationService(mock_user_service, mock_number_service)

        job = make_job(items=[make_job_item(1, "user1@contoso.com", "+14155551001")])

        _, report = await service.validate_job(job, check_licenses=True)

        assert report.issues == []
        assert report.invalid_count == 0
        assert report.valid_count == 1

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_license_check_enabled_user_unlicensed_creates_batch_004(
        self,
    ) -> None:
        """When license check enabled and user unlicensed, BATCH_004 issue created."""
        user = UserConfiguration(
            **make_user_dict(
                upn="user1@contoso.com",
                enterprise_voice=False,  # No Teams Phone license
            )
        )
        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service = MagicMock()
        service = ValidationService(mock_user_service, mock_number_service)

        job = make_job(items=[make_job_item(1, "user1@contoso.com", "+14155551001")])

        _, report = await service.validate_job(job, check_licenses=True)

        assert len(report.issues) == 1
        issue = report.issues[0]
        assert issue.line_number == 1
        assert issue.field == "user_upn"
        assert issue.value == "user1@contoso.com"
        assert issue.error_code == "BATCH_004"
        assert issue.error_message == "User lacks Teams Phone license"
        assert issue.suggested_fix is not None

        assert report.invalid_count == 1
        assert report.valid_count == 0

        assert job.items[0].status == ItemStatus.FAILED
        assert job.items[0].error_code == "BATCH_004"
        assert job.items[0].error_message == "User not licensed"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_license_check_disabled_unlicensed_user_no_issues(self) -> None:
        """When license check disabled, unlicensed user does not cause issues."""
        user = UserConfiguration(
            **make_user_dict(
                upn="user1@contoso.com",
                enterprise_voice=False,  # No license, but check disabled
            )
        )
        number = NumberAssignment(**make_number_dict(assignment_status="unassigned"))
        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(return_value=number)
        service = ValidationService(mock_user_service, mock_number_service)

        job = make_job(items=[make_job_item(1, "user1@contoso.com", "+14155551001")])

        # check_licenses defaults to False
        _, report = await service.validate_job(job)

        assert report.issues == []
        assert report.invalid_count == 0
        assert report.valid_count == 1

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_skips_succeeded_items(self) -> None:
        """Items with SUCCEEDED status are skipped during validation."""
        user = UserConfiguration(**make_user_dict())
        number = NumberAssignment(**make_number_dict(assignment_status="unassigned"))
        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(return_value=number)
        service = ValidationService(mock_user_service, mock_number_service)

        items = [
            make_job_item(
                1, "user1@contoso.com", "+14155551001", status=ItemStatus.SUCCEEDED
            ),
            make_job_item(2, "user2@contoso.com", "+14155551002"),
        ]
        job = make_job(items=items)

        _, report = await service.validate_job(job)

        # resolve_user should only be called once (for the pending item)
        assert mock_user_service.resolve_user.call_count == 1
        assert report.total_items == 2

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_skips_needs_review_items(self) -> None:
        """Items with NEEDS_REVIEW status are skipped during validation."""
        user = UserConfiguration(**make_user_dict())
        number = NumberAssignment(**make_number_dict(assignment_status="unassigned"))
        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(return_value=number)
        service = ValidationService(mock_user_service, mock_number_service)

        items = [
            make_job_item(
                1, "user1@contoso.com", "+14155551001", status=ItemStatus.NEEDS_REVIEW
            ),
            make_job_item(2, "user2@contoso.com", "+14155551002"),
        ]
        job = make_job(items=items)

        _, report = await service.validate_job(job)

        # resolve_user should only be called once (for the pending item)
        assert mock_user_service.resolve_user.call_count == 1
        assert report.total_items == 2

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_processes_multiple_items(self) -> None:
        """Multiple items are processed and each is validated."""
        user1 = UserConfiguration(
            **make_user_dict(user_id="u1", upn="user1@contoso.com")
        )
        user2 = UserConfiguration(
            **make_user_dict(user_id="u2", upn="user2@contoso.com")
        )
        number = NumberAssignment(**make_number_dict(assignment_status="unassigned"))

        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(side_effect=[user1, user2])
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(return_value=number)
        service = ValidationService(mock_user_service, mock_number_service)

        items = [
            make_job_item(1, "user1@contoso.com", "+14155551001"),
            make_job_item(2, "user2@contoso.com", "+14155551002"),
        ]
        job = make_job(items=items)

        _, report = await service.validate_job(job)

        assert mock_user_service.resolve_user.call_count == 2
        assert report.total_items == 2
        assert report.valid_count == 2
        assert report.invalid_count == 0
        assert report.issues == []

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_mixed_success_and_failure(self) -> None:
        """Mix of valid and invalid users produces correct counts."""
        user1 = UserConfiguration(
            **make_user_dict(user_id="u1", upn="user1@contoso.com")
        )
        number = NumberAssignment(**make_number_dict(assignment_status="unassigned"))

        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(
            side_effect=[
                user1,
                NotFoundError("User not found"),
            ]
        )
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(return_value=number)
        service = ValidationService(mock_user_service, mock_number_service)

        items = [
            make_job_item(1, "user1@contoso.com", "+14155551001"),
            make_job_item(2, "missing@contoso.com", "+14155551002"),
        ]
        job = make_job(items=items)

        _, report = await service.validate_job(job)

        assert report.total_items == 2
        assert report.valid_count == 1
        assert report.invalid_count == 1
        assert len(report.issues) == 1
        assert report.issues[0].error_code == "BATCH_003"

        assert (
            job.items[0].status == ItemStatus.PENDING
        )  # First user succeeded validation
        assert job.items[1].status == ItemStatus.FAILED  # Second user not found


class TestValidationServiceNumberValidation:
    """Tests for ValidationService number existence and availability validation."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_number_exists_and_unassigned_no_issues(self) -> None:
        """When number exists and is unassigned, no validation issues are added."""
        user = UserConfiguration(
            **make_user_dict(
                user_id="user-123",
                upn="user1@contoso.com",
                enterprise_voice=True,
            )
        )
        number = NumberAssignment(
            **make_number_dict(
                telephone_number="+14155551001",
                assignment_status="unassigned",
            )
        )

        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(return_value=number)
        service = ValidationService(mock_user_service, mock_number_service)

        job = make_job(items=[make_job_item(1, "user1@contoso.com", "+14155551001")])

        _, report = await service.validate_job(job)

        assert report.issues == []
        assert report.invalid_count == 0
        assert report.valid_count == 1
        assert job.items[0].status == ItemStatus.PENDING

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_number_not_found_creates_batch_005_issue(self) -> None:
        """When number not found, BATCH_005 issue is created and item marked FAILED."""
        user = UserConfiguration(
            **make_user_dict(
                user_id="user-123",
                upn="user1@contoso.com",
            )
        )

        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(
            side_effect=NotFoundError("Number not found")
        )
        service = ValidationService(mock_user_service, mock_number_service)

        job = make_job(items=[make_job_item(1, "user1@contoso.com", "+14155559999")])

        _, report = await service.validate_job(job)

        assert len(report.issues) == 1
        issue = report.issues[0]
        assert issue.line_number == 1
        assert issue.field == "phone_number"
        assert issue.value == "+14155559999"
        assert issue.error_code == "BATCH_005"
        assert issue.error_message == "Number not found in tenant inventory"
        assert issue.suggested_fix is not None

        assert report.invalid_count == 1
        assert report.valid_count == 0

        assert job.items[0].status == ItemStatus.FAILED
        assert job.items[0].error_code == "BATCH_005"
        assert job.items[0].error_message == "Number not found"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_number_assigned_to_another_user_creates_batch_006_issue(
        self,
    ) -> None:
        """When number assigned to another user, BATCH_006 issue is created."""
        user = UserConfiguration(
            **make_user_dict(
                user_id="user-123",
                upn="user1@contoso.com",
            )
        )
        # Number is assigned to different user
        number = NumberAssignment(
            **make_number_dict(
                telephone_number="+14155551001",
                assignment_status="userAssigned",
                assignment_target_id="other-user-456",
            )
        )

        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(return_value=number)
        service = ValidationService(mock_user_service, mock_number_service)

        job = make_job(items=[make_job_item(1, "user1@contoso.com", "+14155551001")])

        _, report = await service.validate_job(job)

        assert len(report.issues) == 1
        issue = report.issues[0]
        assert issue.line_number == 1
        assert issue.field == "phone_number"
        assert issue.value == "+14155551001"
        assert issue.error_code == "BATCH_006"
        assert issue.error_message == "Number assigned to another user"
        assert issue.suggested_fix is not None

        assert report.invalid_count == 1
        assert report.valid_count == 0

        assert job.items[0].status == ItemStatus.FAILED
        assert job.items[0].error_code == "BATCH_006"
        assert job.items[0].error_message == "Number unavailable"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_number_assigned_to_conference_creates_batch_006_issue(self) -> None:
        """When number assigned to conference, BATCH_006 issue is created."""
        user = UserConfiguration(
            **make_user_dict(
                user_id="user-123",
                upn="user1@contoso.com",
            )
        )
        # Number is assigned to a conference
        number = NumberAssignment(
            **make_number_dict(
                telephone_number="+14155551001",
                assignment_status="conferenceAssigned",
            )
        )

        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(return_value=number)
        service = ValidationService(mock_user_service, mock_number_service)

        job = make_job(items=[make_job_item(1, "user1@contoso.com", "+14155551001")])

        _, report = await service.validate_job(job)

        assert len(report.issues) == 1
        assert report.issues[0].error_code == "BATCH_006"
        assert job.items[0].status == ItemStatus.FAILED

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_number_assigned_to_voice_app_creates_batch_006_issue(self) -> None:
        """When number assigned to voice application, BATCH_006 issue is created."""
        user = UserConfiguration(
            **make_user_dict(
                user_id="user-123",
                upn="user1@contoso.com",
            )
        )
        # Number is assigned to a voice application
        number = NumberAssignment(
            **make_number_dict(
                telephone_number="+14155551001",
                assignment_status="voiceApplicationAssigned",
            )
        )

        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(return_value=number)
        service = ValidationService(mock_user_service, mock_number_service)

        job = make_job(items=[make_job_item(1, "user1@contoso.com", "+14155551001")])

        _, report = await service.validate_job(job)

        assert len(report.issues) == 1
        assert report.issues[0].error_code == "BATCH_006"
        assert job.items[0].status == ItemStatus.FAILED

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_mixed_number_states_correct_counts(self) -> None:
        """Multiple items with mixed number states produce correct counts."""
        user1 = UserConfiguration(
            **make_user_dict(user_id="u1", upn="user1@contoso.com")
        )
        user2 = UserConfiguration(
            **make_user_dict(user_id="u2", upn="user2@contoso.com")
        )
        user3 = UserConfiguration(
            **make_user_dict(user_id="u3", upn="user3@contoso.com")
        )

        number_available = NumberAssignment(
            **make_number_dict(
                number_id="n1",
                telephone_number="+14155551001",
                assignment_status="unassigned",
            )
        )
        number_assigned = NumberAssignment(
            **make_number_dict(
                number_id="n2",
                telephone_number="+14155551002",
                assignment_status="userAssigned",
                assignment_target_id="other-user",
            )
        )

        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(side_effect=[user1, user2, user3])
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(
            side_effect=[
                number_available,  # First item: available
                NotFoundError("Number not found"),  # Second item: not found
                number_assigned,  # Third item: assigned to other
            ]
        )
        service = ValidationService(mock_user_service, mock_number_service)

        items = [
            make_job_item(1, "user1@contoso.com", "+14155551001"),  # Valid
            make_job_item(2, "user2@contoso.com", "+14155559999"),  # BATCH_005
            make_job_item(3, "user3@contoso.com", "+14155551002"),  # BATCH_006
        ]
        job = make_job(items=items)

        _, report = await service.validate_job(job)

        assert report.total_items == 3
        assert report.valid_count == 1
        assert report.invalid_count == 2
        assert len(report.issues) == 2

        error_codes = {issue.error_code for issue in report.issues}
        assert error_codes == {"BATCH_005", "BATCH_006"}

        assert job.items[0].status == ItemStatus.PENDING  # Available number
        assert job.items[1].status == ItemStatus.FAILED  # Number not found
        assert job.items[2].status == ItemStatus.FAILED  # Number unavailable

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_user_failure_skips_number_validation(self) -> None:
        """When user validation fails, number validation is skipped."""
        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(
            side_effect=NotFoundError("User not found")
        )
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock()
        service = ValidationService(mock_user_service, mock_number_service)

        job = make_job(items=[make_job_item(1, "missing@contoso.com", "+14155551001")])

        _, report = await service.validate_job(job)

        # Number service should not be called if user validation failed
        mock_number_service.get_number.assert_not_called()

        # Only user error (BATCH_003) should be in issues
        assert len(report.issues) == 1
        assert report.issues[0].error_code == "BATCH_003"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_license_failure_skips_number_validation(self) -> None:
        """When license validation fails, number validation is skipped."""
        user = UserConfiguration(
            **make_user_dict(
                upn="user1@contoso.com",
                enterprise_voice=False,  # No license
            )
        )

        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock()
        service = ValidationService(mock_user_service, mock_number_service)

        job = make_job(items=[make_job_item(1, "user1@contoso.com", "+14155551001")])

        _, report = await service.validate_job(job, check_licenses=True)

        # Number service should not be called if license validation failed
        mock_number_service.get_number.assert_not_called()

        # Only license error (BATCH_004) should be in issues
        assert len(report.issues) == 1
        assert report.issues[0].error_code == "BATCH_004"


class TestValidationServiceIdempotency:
    """Tests for idempotency detection in ValidationService."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_idempotent_assignment_marks_item_succeeded(self) -> None:
        """When number is already assigned to target user, item marked SUCCEEDED."""
        user = UserConfiguration(
            **make_user_dict(
                user_id="user-123",
                upn="user1@contoso.com",
            )
        )
        # Number is assigned to the SAME user (idempotent case)
        number = NumberAssignment(
            **make_number_dict(
                telephone_number="+14155551001",
                assignment_status="userAssigned",
                assignment_target_id="user-123",  # Same as user.id
            )
        )

        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(return_value=number)
        service = ValidationService(mock_user_service, mock_number_service)

        job = make_job(items=[make_job_item(1, "user1@contoso.com", "+14155551001")])

        _, report = await service.validate_job(job)

        # Item should be marked SUCCEEDED, not FAILED
        assert job.items[0].status == ItemStatus.SUCCEEDED
        assert job.items[0].error_message == "Already assigned (idempotent)"
        assert job.items[0].error_code is None  # Not an error
        # No issues should be added for idempotent assignments
        assert report.issues == []
        assert report.invalid_count == 0
        assert report.valid_count == 1

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_idempotent_vs_assigned_to_other_user(self) -> None:
        """Idempotent case (same user) vs BATCH_006 (different user) handled correctly."""
        user1 = UserConfiguration(
            **make_user_dict(
                user_id="user-123",
                upn="user1@contoso.com",
            )
        )
        user2 = UserConfiguration(
            **make_user_dict(
                user_id="user-456",
                upn="user2@contoso.com",
            )
        )

        # Number 1 is assigned to user1 (idempotent for user1)
        number1 = NumberAssignment(
            **make_number_dict(
                number_id="n1",
                telephone_number="+14155551001",
                assignment_status="userAssigned",
                assignment_target_id="user-123",
            )
        )
        # Number 2 is assigned to user1 but requested for user2 (BATCH_006)
        number2 = NumberAssignment(
            **make_number_dict(
                number_id="n2",
                telephone_number="+14155551002",
                assignment_status="userAssigned",
                assignment_target_id="user-123",  # Assigned to user1, not user2
            )
        )

        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(side_effect=[user1, user2])
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(side_effect=[number1, number2])
        service = ValidationService(mock_user_service, mock_number_service)

        items = [
            make_job_item(1, "user1@contoso.com", "+14155551001"),  # Idempotent
            make_job_item(2, "user2@contoso.com", "+14155551002"),  # BATCH_006
        ]
        job = make_job(items=items)

        _, report = await service.validate_job(job)

        # First item: idempotent success
        assert job.items[0].status == ItemStatus.SUCCEEDED
        assert job.items[0].error_message == "Already assigned (idempotent)"
        assert job.items[0].error_code is None

        # Second item: BATCH_006 failure (number assigned to different user)
        assert job.items[1].status == ItemStatus.FAILED
        assert job.items[1].error_code == "BATCH_006"

        # Report should have 1 issue (BATCH_006)
        assert len(report.issues) == 1
        assert report.issues[0].error_code == "BATCH_006"
        assert report.valid_count == 1  # Idempotent counts as valid
        assert report.invalid_count == 1

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_multiple_idempotent_items(self) -> None:
        """Multiple idempotent items all marked SUCCEEDED."""
        user1 = UserConfiguration(
            **make_user_dict(user_id="u1", upn="user1@contoso.com")
        )
        user2 = UserConfiguration(
            **make_user_dict(user_id="u2", upn="user2@contoso.com")
        )

        number1 = NumberAssignment(
            **make_number_dict(
                number_id="n1",
                telephone_number="+14155551001",
                assignment_status="userAssigned",
                assignment_target_id="u1",
            )
        )
        number2 = NumberAssignment(
            **make_number_dict(
                number_id="n2",
                telephone_number="+14155551002",
                assignment_status="userAssigned",
                assignment_target_id="u2",
            )
        )

        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(side_effect=[user1, user2])
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(side_effect=[number1, number2])
        service = ValidationService(mock_user_service, mock_number_service)

        items = [
            make_job_item(1, "user1@contoso.com", "+14155551001"),
            make_job_item(2, "user2@contoso.com", "+14155551002"),
        ]
        job = make_job(items=items)

        _, report = await service.validate_job(job)

        assert job.items[0].status == ItemStatus.SUCCEEDED
        assert job.items[1].status == ItemStatus.SUCCEEDED
        assert report.issues == []
        assert report.valid_count == 2
        assert report.invalid_count == 0


class TestValidationServiceRevalidation:
    """Tests for re-validation resetting previously failed items."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_revalidation_resets_failed_items(self) -> None:
        """Re-validation resets FAILED items so they can pass on second run.

        Regression test: items that failed with BATCH_004 (license check) on
        first validation should pass when re-validated without --check-licenses.
        """
        user = UserConfiguration(
            **make_user_dict(
                user_id="user-123",
                upn="user1@contoso.com",
                enterprise_voice=False,  # No license
            )
        )
        number = NumberAssignment(
            **make_number_dict(
                assignment_status="unassigned",
            )
        )

        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(return_value=number)
        service = ValidationService(mock_user_service, mock_number_service)

        item = make_job_item(1, "user1@contoso.com", "+14155551234")
        job = make_job(items=[item])

        # First validation with license check — item fails
        _, report1 = await service.validate_job(job, check_licenses=True)
        assert item.status == ItemStatus.FAILED
        assert item.error_code == "BATCH_004"

        # Second validation without license check — item should pass
        mock_user_service.resolve_user.reset_mock()
        mock_number_service.get_number.reset_mock()
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service.get_number = AsyncMock(return_value=number)

        _, report2 = await service.validate_job(job, check_licenses=False)

        assert item.status == ItemStatus.PENDING
        assert item.error_code is None
        assert item.error_message is None
        assert report2.valid_count == 1
        assert report2.invalid_count == 0

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_revalidation_clears_error_fields(self) -> None:
        """Re-validation clears error_code and error_message from previous run."""
        user = UserConfiguration(
            **make_user_dict(
                user_id="user-123",
                upn="user1@contoso.com",
            )
        )
        number = NumberAssignment(**make_number_dict(assignment_status="unassigned"))

        mock_user_service = MagicMock()
        mock_number_service = MagicMock()
        service = ValidationService(mock_user_service, mock_number_service)

        item = make_job_item(1, "user1@contoso.com", "+14155551234")
        job = make_job(items=[item])

        # Simulate a previous validation failure
        item.status = ItemStatus.FAILED
        item.error_code = "BATCH_003"
        item.error_message = "User not found"

        # Now user exists — re-validation should pass
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service.get_number = AsyncMock(return_value=number)

        _, report = await service.validate_job(job)

        assert item.status == ItemStatus.PENDING
        assert item.error_code is None
        assert item.error_message is None
        assert report.valid_count == 1
        assert report.invalid_count == 0


class TestValidationServiceReportCounts:
    """Tests for ValidationReport count calculations."""

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_valid_count_includes_pending_and_idempotent(self) -> None:
        """valid_count includes both PENDING and idempotent SUCCEEDED items."""
        user1 = UserConfiguration(
            **make_user_dict(user_id="u1", upn="user1@contoso.com")
        )
        user2 = UserConfiguration(
            **make_user_dict(user_id="u2", upn="user2@contoso.com")
        )

        # Number 1: unassigned (will be PENDING)
        number1 = NumberAssignment(
            **make_number_dict(
                number_id="n1",
                telephone_number="+14155551001",
                assignment_status="unassigned",
            )
        )
        # Number 2: assigned to user2 (idempotent SUCCEEDED)
        number2 = NumberAssignment(
            **make_number_dict(
                number_id="n2",
                telephone_number="+14155551002",
                assignment_status="userAssigned",
                assignment_target_id="u2",
            )
        )

        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(side_effect=[user1, user2])
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(side_effect=[number1, number2])
        service = ValidationService(mock_user_service, mock_number_service)

        items = [
            make_job_item(1, "user1@contoso.com", "+14155551001"),  # PENDING
            make_job_item(
                2, "user2@contoso.com", "+14155551002"
            ),  # SUCCEEDED (idempotent)
        ]
        job = make_job(items=items)

        _, report = await service.validate_job(job)

        assert job.items[0].status == ItemStatus.PENDING
        assert job.items[1].status == ItemStatus.SUCCEEDED
        assert report.valid_count == 2  # Both count as valid
        assert report.invalid_count == 0

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_mixed_valid_idempotent_and_failed(self) -> None:
        """Report correctly counts valid, idempotent, and failed items."""
        user1 = UserConfiguration(
            **make_user_dict(user_id="u1", upn="user1@contoso.com")
        )
        user2 = UserConfiguration(
            **make_user_dict(user_id="u2", upn="user2@contoso.com")
        )
        user3 = UserConfiguration(
            **make_user_dict(user_id="u3", upn="user3@contoso.com")
        )

        number_unassigned = NumberAssignment(
            **make_number_dict(
                number_id="n1",
                telephone_number="+14155551001",
                assignment_status="unassigned",
            )
        )
        number_idempotent = NumberAssignment(
            **make_number_dict(
                number_id="n2",
                telephone_number="+14155551002",
                assignment_status="userAssigned",
                assignment_target_id="u2",  # Same as user2
            )
        )
        number_other = NumberAssignment(
            **make_number_dict(
                number_id="n3",
                telephone_number="+14155551003",
                assignment_status="userAssigned",
                assignment_target_id="other-user",  # Different user
            )
        )

        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(side_effect=[user1, user2, user3])
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(
            side_effect=[number_unassigned, number_idempotent, number_other]
        )
        service = ValidationService(mock_user_service, mock_number_service)

        items = [
            make_job_item(1, "user1@contoso.com", "+14155551001"),  # PENDING
            make_job_item(
                2, "user2@contoso.com", "+14155551002"
            ),  # SUCCEEDED (idempotent)
            make_job_item(3, "user3@contoso.com", "+14155551003"),  # FAILED (BATCH_006)
        ]
        job = make_job(items=items)

        _, report = await service.validate_job(job)

        assert job.items[0].status == ItemStatus.PENDING
        assert job.items[1].status == ItemStatus.SUCCEEDED
        assert job.items[2].status == ItemStatus.FAILED

        assert report.total_items == 3
        assert report.valid_count == 2  # PENDING + idempotent SUCCEEDED
        assert report.invalid_count == 1  # FAILED
        assert len(report.issues) == 1

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_pre_existing_succeeded_items_skipped_but_count_as_valid(
        self,
    ) -> None:
        """Items already SUCCEEDED before validation are skipped but count as valid."""
        user = UserConfiguration(
            **make_user_dict(user_id="u1", upn="user1@contoso.com")
        )
        number = NumberAssignment(
            **make_number_dict(
                assignment_status="unassigned",
            )
        )

        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(return_value=number)
        service = ValidationService(mock_user_service, mock_number_service)

        items = [
            # Pre-existing SUCCEEDED item (already completed in previous run)
            make_job_item(
                1, "user1@contoso.com", "+14155551001", status=ItemStatus.SUCCEEDED
            ),
            # New PENDING item
            make_job_item(2, "user2@contoso.com", "+14155551002"),
        ]
        job = make_job(items=items)

        _, report = await service.validate_job(job)

        # Pre-existing SUCCEEDED should be skipped (user service not called for it)
        assert mock_user_service.resolve_user.call_count == 1
        # valid_count includes all non-FAILED items (both SUCCEEDED and PENDING)
        assert report.valid_count == 2
        assert report.total_items == 2
        assert report.invalid_count == 0

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_issues_list_preserves_order(self) -> None:
        """Issues are added to the list in validation order."""
        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(
            side_effect=[
                NotFoundError("User not found"),  # Item 1: BATCH_003
                NotFoundError("User not found"),  # Item 2: BATCH_003
                NotFoundError("User not found"),  # Item 3: BATCH_003
            ]
        )
        mock_number_service = MagicMock()
        service = ValidationService(mock_user_service, mock_number_service)

        items = [
            make_job_item(1, "missing1@contoso.com", "+14155551001"),
            make_job_item(2, "missing2@contoso.com", "+14155551002"),
            make_job_item(3, "missing3@contoso.com", "+14155551003"),
        ]
        job = make_job(items=items)

        _, report = await service.validate_job(job)

        assert len(report.issues) == 3
        # Issues should be in line_number order
        assert report.issues[0].line_number == 1
        assert report.issues[0].value == "missing1@contoso.com"
        assert report.issues[1].line_number == 2
        assert report.issues[1].value == "missing2@contoso.com"
        assert report.issues[2].line_number == 3
        assert report.issues[2].value == "missing3@contoso.com"

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_warnings_list_passed_through(self) -> None:
        """Warnings list in report is empty (no warning conditions implemented yet)."""
        user = UserConfiguration(**make_user_dict())
        number = NumberAssignment(**make_number_dict(assignment_status="unassigned"))

        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(return_value=user)
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(return_value=number)
        service = ValidationService(mock_user_service, mock_number_service)

        job = make_job(items=[make_job_item(1, "user1@contoso.com", "+14155551001")])

        _, report = await service.validate_job(job)

        # Warnings are initialized but not populated (future feature)
        assert report.warnings == []

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_comprehensive_job_with_all_states(self) -> None:
        """Integration test: job with idempotent, valid, and multiple failure types."""
        user1 = UserConfiguration(
            **make_user_dict(user_id="u1", upn="user1@contoso.com")
        )
        user2 = UserConfiguration(
            **make_user_dict(
                user_id="u2",
                upn="user2@contoso.com",
                enterprise_voice=False,  # No license
            )
        )
        user3 = UserConfiguration(
            **make_user_dict(user_id="u3", upn="user3@contoso.com")
        )
        user5 = UserConfiguration(
            **make_user_dict(user_id="u5", upn="user5@contoso.com")
        )
        user6 = UserConfiguration(
            **make_user_dict(user_id="u6", upn="user6@contoso.com")
        )

        number_idempotent = NumberAssignment(
            **make_number_dict(
                number_id="n1",
                telephone_number="+14155551001",
                assignment_status="userAssigned",
                assignment_target_id="u1",  # Same user - idempotent
            )
        )
        number_available = NumberAssignment(
            **make_number_dict(
                number_id="n3",
                telephone_number="+14155551003",
                assignment_status="unassigned",
            )
        )
        number_assigned = NumberAssignment(
            **make_number_dict(
                number_id="n5",
                telephone_number="+14155551005",
                assignment_status="userAssigned",
                assignment_target_id="other-user",
            )
        )

        mock_user_service = MagicMock()
        mock_user_service.resolve_user = AsyncMock(
            side_effect=[
                user1,  # Item 1: user exists
                user2,  # Item 2: user exists but no license
                user3,  # Item 3: user exists
                NotFoundError("User not found"),  # Item 4: BATCH_003
                user5,  # Item 5: user exists
                user6,  # Item 6: user exists (valid case)
            ]
        )
        mock_number_service = MagicMock()
        mock_number_service.get_number = AsyncMock(
            side_effect=[
                number_idempotent,  # Item 1: idempotent
                # Item 2: license failed, number not called
                number_available,  # Item 3: available
                # Item 4: user not found, number not called
                NotFoundError("Number not found"),  # Item 5: BATCH_005
                number_assigned,  # Item 6: BATCH_006
            ]
        )
        service = ValidationService(mock_user_service, mock_number_service)

        items = [
            make_job_item(1, "user1@contoso.com", "+14155551001"),  # Idempotent
            make_job_item(
                2, "user2@contoso.com", "+14155551002"
            ),  # BATCH_004 (no license)
            make_job_item(3, "user3@contoso.com", "+14155551003"),  # Valid (PENDING)
            make_job_item(4, "missing@contoso.com", "+14155551004"),  # BATCH_003
            make_job_item(5, "user5@contoso.com", "+14155559999"),  # BATCH_005
            make_job_item(6, "user6@contoso.com", "+14155551005"),  # BATCH_006
        ]
        job = make_job(items=items)

        _, report = await service.validate_job(job, check_licenses=True)

        # Verify item statuses
        assert job.items[0].status == ItemStatus.SUCCEEDED  # Idempotent
        assert job.items[0].error_message == "Already assigned (idempotent)"
        assert job.items[1].status == ItemStatus.FAILED  # BATCH_004
        assert job.items[1].error_code == "BATCH_004"
        assert job.items[2].status == ItemStatus.PENDING  # Valid
        assert job.items[3].status == ItemStatus.FAILED  # BATCH_003
        assert job.items[3].error_code == "BATCH_003"
        assert job.items[4].status == ItemStatus.FAILED  # BATCH_005
        assert job.items[4].error_code == "BATCH_005"
        assert job.items[5].status == ItemStatus.FAILED  # BATCH_006
        assert job.items[5].error_code == "BATCH_006"

        # Verify report counts
        assert report.total_items == 6
        assert report.valid_count == 2  # Idempotent + PENDING
        assert report.invalid_count == 4  # All failures

        # Verify all error codes present in issues
        error_codes = {issue.error_code for issue in report.issues}
        assert error_codes == {"BATCH_003", "BATCH_004", "BATCH_005", "BATCH_006"}
