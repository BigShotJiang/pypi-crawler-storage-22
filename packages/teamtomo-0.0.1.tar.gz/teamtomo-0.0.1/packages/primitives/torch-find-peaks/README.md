# torch-find-peaks

[![License](https://img.shields.io/pypi/l/torch-find-peaks.svg?color=green)](https://github.com/jojoelfe/torch-find-peaks/raw/main/LICENSE)
[![PyPI](https://img.shields.io/pypi/v/torch-find-peaks.svg?color=green)](https://pypi.org/project/torch-find-peaks)
[![Python Version](https://img.shields.io/pypi/pyversions/torch-find-peaks.svg?color=green)](https://python.org)
[![CI](https://github.com/jojoelfe/torch-find-peaks/actions/workflows/ci.yml/badge.svg)](https://github.com/jojoelfe/torch-find-peaks/actions/workflows/ci.yml)
[![codecov](https://codecov.io/gh/jojoelfe/torch-find-peaks/branch/main/graph/badge.svg)](https://codecov.io/gh/jojoelfe/torch-find-peaks)

Peak finding and fitting using torch
