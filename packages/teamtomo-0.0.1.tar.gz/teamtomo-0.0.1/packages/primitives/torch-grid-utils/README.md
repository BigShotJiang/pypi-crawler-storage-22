# torch-grid-utils

[![License](https://img.shields.io/pypi/l/torch-grids.svg?color=green)](https://github.com/alisterburt/torch-grids/raw/main/LICENSE)
[![PyPI](https://img.shields.io/pypi/v/torch-grids.svg?color=green)](https://pypi.org/project/torch-grids)
[![Python Version](https://img.shields.io/pypi/pyversions/torch-grids.svg?color=green)](https://python.org)
[![CI](https://github.com/alisterburt/torch-grids/actions/workflows/ci.yml/badge.svg)](https://github.com/alisterburt/torch-grids/actions/workflows/ci.yml)
[![codecov](https://codecov.io/gh/alisterburt/torch-grids/branch/main/graph/badge.svg)](https://codecov.io/gh/alisterburt/torch-grids)

*torch-grid-utils* provides grids for 2D/3D image manipulations in PyTorch.


