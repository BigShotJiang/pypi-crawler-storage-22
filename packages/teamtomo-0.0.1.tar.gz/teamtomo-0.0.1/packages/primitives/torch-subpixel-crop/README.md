# torch-subpixel-crop

[![License](https://img.shields.io/pypi/l/torch-subimage.svg?color=green)](https://github.com/alisterburt/torch-subimage/raw/main/LICENSE)
[![PyPI](https://img.shields.io/pypi/v/torch-subimage.svg?color=green)](https://pypi.org/project/torch-subimage)
[![Python Version](https://img.shields.io/pypi/pyversions/torch-subimage.svg?color=green)](https://python.org)
[![CI](https://github.com/alisterburt/torch-subimage/actions/workflows/ci.yml/badge.svg)](https://github.com/alisterburt/torch-subimage/actions/workflows/ci.yml)
[![codecov](https://codecov.io/gh/alisterburt/torch-subimage/branch/main/graph/badge.svg)](https://codecov.io/gh/alisterburt/torch-subimage)

Crop 2D/3D images with subpixel precision in PyTorch
