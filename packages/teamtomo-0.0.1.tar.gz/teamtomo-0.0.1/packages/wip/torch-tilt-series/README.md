# torch-tomogram

[![License](https://img.shields.io/pypi/l/torch-tomogram.svg?color=green)](https://github.com/teamtomo/torch-tomogram/raw/main/LICENSE)
[![PyPI](https://img.shields.io/pypi/v/torch-tomogram.svg?color=green)](https://pypi.org/project/torch-tomogram)
[![Python Version](https://img.shields.io/pypi/pyversions/torch-tomogram.svg?color=green)](https://python.org)
[![CI](https://github.com/teamtomo/torch-tomogram/actions/workflows/ci.yml/badge.svg)](https://github.com/teamtomo/torch-tomogram/actions/workflows/ci.yml)
[![codecov](https://codecov.io/gh/teamtomo/torch-tomogram/branch/main/graph/badge.svg)](https://codecov.io/gh/teamtomo/torch-tomogram)

(sub-)Tomogram reconstruction, subtilt extraction for cryo-ET.
