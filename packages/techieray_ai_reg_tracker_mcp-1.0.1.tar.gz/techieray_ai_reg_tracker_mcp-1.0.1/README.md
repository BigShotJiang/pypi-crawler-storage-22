# AI Regulation Tracker - Python Client

A Python client library for accessing AI regulation data from 195+ countries and jurisdictions through the AI Regulation Tracker MCP server.

## Installation

```bash
pip install ai-regulation-tracker
```

## Quick Start

```python
from techieray_ai_reg_tracker_mcp import AIRegulationTracker, Categories

# Create a client
tracker = AIRegulationTracker(api_key="your-api-key")

# List all countries
countries = tracker.list_countries()
print(f"Total countries: {countries.total}")

# Get country overview
overview = tracker.get_country_overview("US")
print(f"Categories available for {overview.name}:")
for cat in overview.available_categories:
    print(f"  - {cat.category}: {cat.item_count} items")

# Get regulations by category
regulations = tracker.get_regulations_by_category(
    "US",
    Categories.ACTS_BILLS_REFORM,
    limit=5
)
for item in regulations.items:
    print(f"- {item.label}")

# Clean up
tracker.close()
```

## Using as a Context Manager

```python
from ai_regulation_tracker import AIRegulationTracker

with AIRegulationTracker(api_key="your-api-key") as tracker:
    countries = tracker.list_countries()
    print(f"Total: {countries.total}")
# Session is automatically closed
```

## API Reference

### AIRegulationTracker

The main client class for interacting with the AI Regulation Tracker API.

#### Constructor

```python
AIRegulationTracker(
    api_key: str,
    server_url: str = None,  # Optional custom server URL
    language: str = "eng"    # "eng" or "chn"
)
```

### Methods

#### list_countries()

List all available countries/jurisdictions.

```python
result = tracker.list_countries()
# Returns: CountryListResult
#   - total: int
#   - countries: list[Country]
```

#### get_country_overview(country_code)

Get an overview of available regulation categories for a country.

```python
overview = tracker.get_country_overview("US")
# Returns: CountryOverview
#   - code: str
#   - name: str
#   - available_categories: list[CategoryInfo]
```

#### get_regulations_by_category(country_code, category, limit=10)

Get regulations for a specific country and category.

```python
from ai_regulation_tracker import Categories

regulations = tracker.get_regulations_by_category(
    "US",
    Categories.ACTS_BILLS_REFORM,
    limit=10
)
# Returns: RegulationsByCategoryResult
#   - country: str
#   - category: str
#   - total_available: int
#   - returned: int
#   - items: list[RegulationItem]
```

#### search_regulations(keyword, country_code=None, category=None, limit=20)

Search regulations by keyword.

```python
results = tracker.search_regulations(
    "artificial intelligence",
    country_code="US",  # Optional
    limit=20
)
# Returns: SearchRegulationsResult
#   - keyword: str
#   - results_count: int
#   - results: list[SearchResult]
```

#### search_by_date(date, country_code=None)

Search for regulation updates by date.

```python
results = tracker.search_by_date("2024-01-15")
# Returns: DateSearchResult
#   - date: str
#   - results_count: int
#   - results: list[RegulationItem]
```

#### compare_countries(country_codes, category, limit_per_country=5)

Compare regulations across 2-5 countries.

```python
comparison = tracker.compare_countries(
    ["US", "Europe", "CN"],
    Categories.ACTS_BILLS_REFORM,
    limit_per_country=5
)
# Returns: CompareCountriesResult
#   - category: str
#   - countries_compared: int
#   - comparison: dict[str, CountryComparison]
```

#### set_language(language)

Change the language for subsequent requests.

```python
tracker.set_language("chn")  # Switch to Chinese
```

#### initialize()

Explicitly initialize the MCP session (optional - happens automatically).

```python
result = tracker.initialize()
# Returns: InitializeResult
```

#### close()

Close the session and release resources.

```python
tracker.close()
```

## Categories

Available regulation categories:

```python
from ai_regulation_tracker import Categories

Categories.LATEST_NEWS                      # "latest_news"
Categories.SECTOR_NEWS                      # "sector_news"
Categories.BILATERAL_MULTILATERAL_NEWS      # "bilateral_multilateral_news"
Categories.OFFICIAL_MATERIALS               # "official_materials"
Categories.ACTS_BILLS_REFORM                # "acts_bills_reform"
Categories.ORDERS_ADMIN_REGS                # "orders_admin_regs"
Categories.GUIDELINES_STANDARDS_FRAMEWORKS  # "guidelines_standards_frameworks"
```

## Languages

Supported languages:

```python
from ai_regulation_tracker import Language

Language.ENGLISH  # "eng"
Language.CHINESE  # "chn"
```

## Error Handling

```python
from ai_regulation_tracker import (
    AIRegulationTracker,
    AIRegulationTrackerError,
    APIKeyError,
    ConnectionError,
    ServerError,
)

try:
    tracker = AIRegulationTracker(api_key="invalid-key")
    countries = tracker.list_countries()
except APIKeyError as e:
    print(f"Invalid API key: {e}")
except ConnectionError as e:
    print(f"Connection failed: {e}")
except ServerError as e:
    print(f"Server error: {e}")
except AIRegulationTrackerError as e:
    print(f"General error: {e}")
```

## Data Types

### Country

```python
@dataclass
class Country:
    code: str   # e.g., "US", "Europe", "CN"
    name: str   # e.g., "United States"
```

### RegulationItem

```python
@dataclass
class RegulationItem:
    label: str | None   # Title
    desc: str | None    # Description
    link: str | None    # URL
    extra: dict         # Additional fields
```

### SearchResult

```python
@dataclass
class SearchResult:
    country_code: str
    country_name: str
    category: str
    label: str | None
    desc: str | None
    link: str | None
```

## Requirements

- Python 3.10+
- requests >= 2.28.0

## License

MIT License
