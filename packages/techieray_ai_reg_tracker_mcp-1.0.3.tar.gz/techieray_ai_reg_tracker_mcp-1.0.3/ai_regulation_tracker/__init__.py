"""
AI Regulation Tracker - Python Client Library

A Python client for accessing AI regulation data from 195+ countries/jurisdictions
through the AI Regulation Tracker MCP server.

Example:
    >>> from ai_regulation_tracker import AIRegulationTracker, Categories
    >>>
    >>> # Create client
    >>> tracker = AIRegulationTracker(api_key="your-api-key")
    >>>
    >>> # List all countries
    >>> countries = tracker.list_countries()
    >>> print(f"Total countries: {countries.total}")
    >>>
    >>> # Get regulations by category
    >>> regs = tracker.get_regulations_by_category("US", Categories.ACTS_BILLS_REFORM)
    >>> for item in regs.items:
    ...     print(f"- {item.label}")
    >>>
    >>> # Clean up
    >>> tracker.close()

Using as a context manager:
    >>> with AIRegulationTracker(api_key="your-api-key") as tracker:
    ...     countries = tracker.list_countries()
    ...     print(f"Total: {countries.total}")
"""

__version__ = "1.0.0"

from .client import AIRegulationTracker
from .types import (
    Language,
    Categories,
    Country,
    CategoryInfo,
    CountryListResult,
    CountryOverview,
    RegulationItem,
    RegulationsByCategoryResult,
    SearchResult,
    SearchRegulationsResult,
    DateSearchResult,
    CountryComparison,
    CompareCountriesResult,
    InitializeResult,
    ClientConfig,
)
from .exceptions import (
    AIRegulationTrackerError,
    APIKeyError,
    ConnectionError,
    ServerError,
    RateLimitError,
    NotFoundError,
    InvalidRequestError,
)

__all__ = [
    # Main client
    "AIRegulationTracker",
    # Enums
    "Language",
    "Categories",
    # Data types
    "Country",
    "CategoryInfo",
    "CountryListResult",
    "CountryOverview",
    "RegulationItem",
    "RegulationsByCategoryResult",
    "SearchResult",
    "SearchRegulationsResult",
    "DateSearchResult",
    "CountryComparison",
    "CompareCountriesResult",
    "InitializeResult",
    "ClientConfig",
    # Exceptions
    "AIRegulationTrackerError",
    "APIKeyError",
    "ConnectionError",
    "ServerError",
    "RateLimitError",
    "NotFoundError",
    "InvalidRequestError",
]
