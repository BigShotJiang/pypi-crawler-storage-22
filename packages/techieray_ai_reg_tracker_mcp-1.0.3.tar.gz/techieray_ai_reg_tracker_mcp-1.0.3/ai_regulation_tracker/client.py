"""Main AI Regulation Tracker client implementation."""

import json
import re
import uuid
from typing import Optional, Any

import requests

from .types import (
    Language,
    Categories,
    Country,
    CategoryInfo,
    CountryListResult,
    CountryOverview,
    RegulationItem,
    RegulationsByCategoryResult,
    SearchResult,
    SearchRegulationsResult,
    DateSearchResult,
    CountryComparison,
    CompareCountriesResult,
    InitializeResult,
    ClientConfig,
)
from .exceptions import (
    AIRegulationTrackerError,
    APIKeyError,
    ConnectionError,
    ServerError,
)


class AIRegulationTracker:
    """
    Client for interacting with the AI Regulation Tracker MCP server.

    Provides access to AI regulation data from 195+ countries/jurisdictions.

    Example:
        >>> tracker = AIRegulationTracker(api_key="your-api-key")
        >>> countries = tracker.list_countries()
        >>> print(f"Total countries: {countries.total}")
        >>> tracker.close()
    """

    DEFAULT_SERVER_URL = "https://mcp-server-206499018463.australia-southeast1.run.app"

    def __init__(
        self,
        api_key: str,
        server_url: Optional[str] = None,
        language: str | Language = Language.ENGLISH,
    ):
        """
        Initialize the AI Regulation Tracker client.

        Args:
            api_key: Your API key for authentication.
            server_url: Optional custom server URL. Defaults to the hosted server.
            language: Language for responses ('eng' or 'chn'). Defaults to English.
        """
        if not api_key:
            raise APIKeyError("API key is required")

        self._api_key = api_key
        self._server_url = server_url or self.DEFAULT_SERVER_URL
        self._session_id = self._generate_session_id()
        self._language = Language(language) if isinstance(language, str) else language
        self._session = requests.Session()

    def _generate_session_id(self) -> str:
        """Generate a unique session ID."""
        return f"session-{uuid.uuid4().hex[:13]}"

    def _make_request(self, tool_name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        """
        Make a request to the MCP server.

        Args:
            tool_name: The name of the tool to call.
            arguments: The arguments to pass to the tool.

        Returns:
            The parsed response data.

        Raises:
            ConnectionError: If the request fails.
            ServerError: If the server returns an error.
        """
        # Add API key and language to arguments
        arguments = {
            "api_key": self._api_key,
            "language": self._language.value,
            **arguments,
        }

        payload = {
            "jsonrpc": "2.0",
            "id": int(uuid.uuid4().int % (10**12)),
            "method": "tools/call",
            "params": {
                "name": tool_name,
                "arguments": arguments,
            },
        }

        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
            "mcp-session-id": self._session_id,
        }

        try:
            response = self._session.post(
                f"{self._server_url}/mcp",
                json=payload,
                headers=headers,
                timeout=60,
            )
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            raise ConnectionError(f"Failed to connect to server: {e}") from e

        return self._parse_response(response.text)

    def _parse_response(self, response_text: str) -> dict[str, Any]:
        """
        Parse the response from the MCP server.

        Handles both JSON and SSE formats.

        Args:
            response_text: The raw response text.

        Returns:
            The parsed response data.

        Raises:
            ServerError: If the response contains an error.
        """
        data: dict[str, Any] = {}

        # Try parsing as JSON first
        try:
            data = json.loads(response_text)
        except json.JSONDecodeError:
            # Try SSE format
            match = re.search(r"^data: (.+)$", response_text, re.MULTILINE)
            if match:
                try:
                    data = json.loads(match.group(1))
                except json.JSONDecodeError:
                    raise ServerError(f"Failed to parse response: {response_text}")
            else:
                raise ServerError(f"Failed to parse response: {response_text}")

        # Check for errors
        if "error" in data:
            raise ServerError(data["error"].get("message", "Unknown server error"))

        result = data.get("result", {})

        if result.get("isError"):
            content = result.get("content", [{}])
            if content:
                error_text = content[0].get("text", "Unknown error")
                raise ServerError(error_text)

        # Extract and parse content
        content = result.get("content", [])
        if content and content[0].get("type") == "text":
            text = content[0].get("text", "{}")
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                return {"text": text}

        return result

    def initialize(self) -> InitializeResult:
        """
        Initialize the MCP session.

        This is optional - sessions are initialized automatically on first request.

        Returns:
            Session initialization details.
        """
        payload = {
            "jsonrpc": "2.0",
            "id": int(uuid.uuid4().int % (10**12)),
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {
                    "name": "ai-regulation-tracker-python",
                    "version": "1.0.0",
                },
            },
        }

        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "mcp-session-id": self._session_id,
        }

        try:
            response = self._session.post(
                f"{self._server_url}/mcp",
                json=payload,
                headers=headers,
                timeout=30,
            )
            response.raise_for_status()
            data = response.json()
        except requests.exceptions.RequestException as e:
            raise ConnectionError(f"Failed to initialize session: {e}") from e

        result = data.get("result", {})
        return InitializeResult(
            protocol_version=result.get("protocolVersion", ""),
            server_info=result.get("serverInfo", {}),
            capabilities=result.get("capabilities", {}),
        )

    def close(self) -> None:
        """Close the MCP session and release resources."""
        try:
            headers = {"mcp-session-id": self._session_id}
            self._session.delete(f"{self._server_url}/mcp", headers=headers, timeout=10)
        except requests.exceptions.RequestException:
            pass  # Ignore errors on close
        finally:
            self._session.close()

    def set_language(self, language: str | Language) -> None:
        """
        Set the language for subsequent requests.

        Args:
            language: Language code ('eng' or 'chn').
        """
        self._language = Language(language) if isinstance(language, str) else language

    @property
    def language(self) -> Language:
        """Get the current language setting."""
        return self._language

    @property
    def session_id(self) -> str:
        """Get the current session ID."""
        return self._session_id

    def list_countries(self) -> CountryListResult:
        """
        List all available countries/jurisdictions.

        Returns:
            A result containing the total count and list of countries.

        Example:
            >>> result = tracker.list_countries()
            >>> print(f"Found {result.total} countries")
            >>> for country in result.countries[:5]:
            ...     print(f"{country.code}: {country.name}")
        """
        data = self._make_request("list_countries", {})

        countries = [
            Country(code=c.get("code", ""), name=c.get("name", ""))
            for c in data.get("countries", [])
        ]

        return CountryListResult(
            total=data.get("total", len(countries)),
            countries=countries,
        )

    def get_country_overview(self, country_code: str) -> CountryOverview:
        """
        Get an overview of available categories for a country.

        Args:
            country_code: The country code (e.g., 'US', 'EU', 'CN').

        Returns:
            An overview of the country with available categories.

        Example:
            >>> overview = tracker.get_country_overview("US")
            >>> print(f"Country: {overview.name}")
            >>> for cat in overview.available_categories:
            ...     print(f"  {cat.category}: {cat.item_count} items")
        """
        data = self._make_request("get_country_overview", {"country_code": country_code})

        categories = [
            CategoryInfo(
                category=c.get("category", ""),
                item_count=c.get("item_count", 0),
            )
            for c in data.get("available_categories", [])
        ]

        return CountryOverview(
            code=data.get("code", country_code),
            name=data.get("name", ""),
            available_categories=categories,
        )

    def get_regulations_by_category(
        self,
        country_code: str,
        category: str | Categories,
        limit: int = 10,
    ) -> RegulationsByCategoryResult:
        """
        Get regulations for a country filtered by category.

        Args:
            country_code: The country code (e.g., 'US', 'EU', 'CN').
            category: The regulation category (use Categories enum).
            limit: Maximum number of items to return. Defaults to 10.

        Returns:
            Regulations for the specified category.

        Example:
            >>> from ai_regulation_tracker import Categories
            >>> regs = tracker.get_regulations_by_category(
            ...     "US",
            ...     Categories.ACTS_BILLS_REFORM,
            ...     limit=5
            ... )
            >>> for item in regs.items:
            ...     print(f"- {item.label}")
        """
        cat_value = category.value if isinstance(category, Categories) else category

        data = self._make_request("get_regulations_by_category", {
            "country_code": country_code,
            "category": cat_value,
            "limit": limit,
        })

        items = [
            RegulationItem.from_dict(item)
            for item in data.get("items", [])
        ]

        return RegulationsByCategoryResult(
            country=data.get("country", country_code),
            category=data.get("category", cat_value),
            total_available=data.get("total_available", len(items)),
            returned=data.get("returned", len(items)),
            items=items,
        )

    def search_by_date(
        self,
        date: str,
        country_code: Optional[str] = None,
    ) -> DateSearchResult:
        """
        Search for regulation updates by date.

        Args:
            date: The date to search for (format: yyyy-mm-dd).
            country_code: Optional country code to filter results.

        Returns:
            Regulations updated on the specified date.

        Example:
            >>> results = tracker.search_by_date("2024-01-15")
            >>> print(f"Found {results.results_count} updates")
        """
        arguments: dict[str, Any] = {"date": date}
        if country_code:
            arguments["country_code"] = country_code

        data = self._make_request("search_by_date", arguments)

        results = None
        if "results" in data and data["results"]:
            results = [
                RegulationItem.from_dict(item)
                for item in data["results"]
            ]

        return DateSearchResult(
            date=data.get("date", date),
            results_count=data.get("results_count"),
            results=results,
            total_results=data.get("total_results"),
            countries_with_updates=data.get("countries_with_updates"),
        )

    def search_regulations(
        self,
        keyword: str,
        country_code: Optional[str] = None,
        category: Optional[str | Categories] = None,
        limit: int = 20,
    ) -> SearchRegulationsResult:
        """
        Search regulations by keyword.

        Args:
            keyword: The keyword to search for.
            country_code: Optional country code to filter results.
            category: Optional category to filter results.
            limit: Maximum number of results. Defaults to 20.

        Returns:
            Matching regulations.

        Example:
            >>> results = tracker.search_regulations("artificial intelligence")
            >>> for r in results.results:
            ...     print(f"[{r.country_code}] {r.label}")
        """
        arguments: dict[str, Any] = {"keyword": keyword, "limit": limit}
        if country_code:
            arguments["country_code"] = country_code
        if category:
            arguments["category"] = category.value if isinstance(category, Categories) else category

        data = self._make_request("search_regulations", arguments)

        results = [
            SearchResult.from_dict(item)
            for item in data.get("results", [])
        ]

        return SearchRegulationsResult(
            keyword=data.get("keyword", keyword),
            results_count=data.get("results_count", len(results)),
            results=results,
        )

    def compare_countries(
        self,
        country_codes: list[str],
        category: str | Categories,
        limit_per_country: int = 5,
    ) -> CompareCountriesResult:
        """
        Compare regulations across multiple countries.

        Args:
            country_codes: List of 2-5 country codes to compare.
            category: The category to compare.
            limit_per_country: Maximum items per country. Defaults to 5.

        Returns:
            Comparison of regulations across countries.

        Raises:
            InvalidRequestError: If fewer than 2 or more than 5 countries specified.

        Example:
            >>> result = tracker.compare_countries(
            ...     ["US", "EU", "CN"],
            ...     Categories.ACTS_BILLS_REFORM
            ... )
            >>> for code, comp in result.comparison.items():
            ...     print(f"{comp.country_name}: {comp.total_items} items")
        """
        if len(country_codes) < 2 or len(country_codes) > 5:
            raise AIRegulationTrackerError("Must specify 2-5 country codes")

        cat_value = category.value if isinstance(category, Categories) else category

        data = self._make_request("compare_countries", {
            "country_codes": country_codes,
            "category": cat_value,
            "limit_per_country": limit_per_country,
        })

        comparison = {}
        for code, comp_data in data.get("comparison", {}).items():
            items = [
                RegulationItem.from_dict(item)
                for item in comp_data.get("items", [])
            ]
            comparison[code] = CountryComparison(
                country_name=comp_data.get("country_name", ""),
                category=comp_data.get("category", cat_value),
                available=comp_data.get("available", False),
                total_items=comp_data.get("total_items", 0),
                items=items,
                error=comp_data.get("error"),
            )

        return CompareCountriesResult(
            category=data.get("category", cat_value),
            countries_compared=data.get("countries_compared", len(country_codes)),
            comparison=comparison,
        )

    def __enter__(self) -> "AIRegulationTracker":
        """Support usage as a context manager."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Close the session when exiting the context."""
        self.close()
