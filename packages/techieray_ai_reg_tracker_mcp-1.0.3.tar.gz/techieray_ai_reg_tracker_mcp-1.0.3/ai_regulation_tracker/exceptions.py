"""Custom exceptions for the AI Regulation Tracker client."""


class AIRegulationTrackerError(Exception):
    """Base exception for AI Regulation Tracker errors."""
    pass


class APIKeyError(AIRegulationTrackerError):
    """Raised when there's an API key validation error."""
    pass


class ConnectionError(AIRegulationTrackerError):
    """Raised when there's a connection error."""
    pass


class InvalidRequestError(AIRegulationTrackerError):
    """Raised when the request is invalid."""
    pass


class ServerError(AIRegulationTrackerError):
    """Raised when the server returns an error."""
    pass


class RateLimitError(AIRegulationTrackerError):
    """Raised when rate limit is exceeded."""
    pass


class NotFoundError(AIRegulationTrackerError):
    """Raised when a resource is not found."""
    pass
