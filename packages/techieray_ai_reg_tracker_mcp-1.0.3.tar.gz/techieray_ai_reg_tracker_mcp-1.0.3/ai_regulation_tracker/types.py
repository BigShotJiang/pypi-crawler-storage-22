"""Type definitions for the AI Regulation Tracker client."""

from dataclasses import dataclass, field
from typing import Optional, Any
from enum import Enum


class Language(str, Enum):
    """Supported languages."""
    ENGLISH = "eng"
    CHINESE = "chn"


class Categories(str, Enum):
    """Available regulation categories."""
    LATEST_NEWS = "latest_news"
    SECTOR_NEWS = "sector_news"
    BILATERAL_MULTILATERAL_NEWS = "bilateral_multilateral_news"
    OFFICIAL_MATERIALS = "official_materials"
    ACTS_BILLS_REFORM = "acts_bills_reform"
    ORDERS_ADMIN_REGS = "orders_admin_regs"
    GUIDELINES_STANDARDS_FRAMEWORKS = "guidelines_standards_frameworks"


@dataclass
class Country:
    """Represents a country/jurisdiction."""
    code: str
    name: str


@dataclass
class CategoryInfo:
    """Information about a regulation category."""
    category: str
    item_count: int


@dataclass
class CountryListResult:
    """Result from listing countries."""
    total: int
    countries: list[Country]


@dataclass
class CountryOverview:
    """Overview of available categories for a country."""
    code: str
    name: str
    available_categories: list[CategoryInfo]


@dataclass
class RegulationItem:
    """A single regulation item."""
    label: Optional[str] = None
    desc: Optional[str] = None
    link: Optional[str] = None
    extra: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RegulationItem":
        """Create a RegulationItem from a dictionary."""
        known_keys = {"label", "desc", "link"}
        extra = {k: v for k, v in data.items() if k not in known_keys}
        return cls(
            label=data.get("label"),
            desc=data.get("desc"),
            link=data.get("link"),
            extra=extra
        )


@dataclass
class RegulationsByCategoryResult:
    """Result from getting regulations by category."""
    country: str
    category: str
    total_available: int
    returned: int
    items: list[RegulationItem]


@dataclass
class SearchResult:
    """A search result item."""
    country_code: str
    country_name: str
    category: str
    label: Optional[str] = None
    desc: Optional[str] = None
    link: Optional[str] = None
    extra: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SearchResult":
        """Create a SearchResult from a dictionary."""
        known_keys = {"country_code", "country_name", "category", "label", "desc", "link"}
        extra = {k: v for k, v in data.items() if k not in known_keys}
        return cls(
            country_code=data.get("country_code", ""),
            country_name=data.get("country_name", ""),
            category=data.get("category", ""),
            label=data.get("label"),
            desc=data.get("desc"),
            link=data.get("link"),
            extra=extra
        )


@dataclass
class SearchRegulationsResult:
    """Result from searching regulations."""
    keyword: str
    results_count: int
    results: list[SearchResult]


@dataclass
class DateSearchResult:
    """Result from searching by date."""
    date: str
    results_count: Optional[int] = None
    results: Optional[list[RegulationItem]] = None
    total_results: Optional[int] = None
    countries_with_updates: Optional[int] = None


@dataclass
class CountryComparison:
    """Comparison data for a single country."""
    country_name: str
    category: str
    available: bool
    total_items: int
    items: list[RegulationItem]
    error: Optional[str] = None


@dataclass
class CompareCountriesResult:
    """Result from comparing countries."""
    category: str
    countries_compared: int
    comparison: dict[str, CountryComparison]


@dataclass
class InitializeResult:
    """Result from initializing a session."""
    protocol_version: str
    server_info: dict[str, Any]
    capabilities: dict[str, Any]


@dataclass
class ClientConfig:
    """Configuration for the AI Regulation Tracker client."""
    api_key: str
    server_url: str = "https://mcp-server-206499018463.australia-southeast1.run.app"
    language: Language = Language.ENGLISH
