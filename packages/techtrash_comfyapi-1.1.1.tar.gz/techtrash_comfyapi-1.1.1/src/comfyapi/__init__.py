"""TechTrash ComfyAPI – orchestrate ComfyUI instances on multiple GPUs."""

import logging

from .comfyapi import ComfyAPI
from ._types import (
    ComfyAPIError,
    ComfyUIInstance,
    ComfyUIStartupError,
    ComfyUITimeoutError,
    DownloadError,
    GPUDetectionError,
    GPUInfo,
    LoRARef,
    ModelNotFoundError,
    ModelRef,
    WorkflowError,
)

__all__ = [
    "ComfyAPI",
    "ComfyAPIError",
    "ComfyUIInstance",
    "ComfyUIStartupError",
    "ComfyUITimeoutError",
    "DownloadError",
    "GPUDetectionError",
    "GPUInfo",
    "LoRARef",
    "ModelNotFoundError",
    "ModelRef",
    "WorkflowError",
]

logging.getLogger(__name__).addHandler(logging.NullHandler())
