"""Async HTTP client for a single ComfyUI instance."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

import httpx

from ._types import (
    ComfyUIInstance,
    ComfyUITimeoutError,
    WorkflowError,
)

logger = logging.getLogger(__name__)

_CONNECT_TIMEOUT = 10.0
_READ_TIMEOUT = 60.0
_WRITE_TIMEOUT = 30.0
_POOL_TIMEOUT = 10.0


class ComfyUIClient:
    """Async client that talks to a single ComfyUI HTTP API."""

    def __init__(self, instance: ComfyUIInstance) -> None:
        self.instance = instance
        transport = httpx.AsyncHTTPTransport(retries=3)
        self._http = httpx.AsyncClient(
            base_url=instance.base_url,
            transport=transport,
            timeout=httpx.Timeout(
                connect=_CONNECT_TIMEOUT,
                read=_READ_TIMEOUT,
                write=_WRITE_TIMEOUT,
                pool=_POOL_TIMEOUT,
            ),
        )

    async def aclose(self) -> None:
        await self._http.aclose()

    # -- readiness ----------------------------------------------------------

    async def wait_until_ready(self, timeout: float = 120.0) -> None:
        """Poll ``/history`` until ComfyUI responds with 200.

        Raises ``ComfyUITimeoutError`` after *timeout* seconds.
        """
        deadline = asyncio.get_event_loop().time() + timeout
        url = self.instance.base_url
        while True:
            remaining = deadline - asyncio.get_event_loop().time()
            if remaining <= 0:
                raise ComfyUITimeoutError(
                    f"ComfyUI at {url} did not become ready within {timeout}s"
                )
            try:
                resp = await self._http.get("/history")
                if resp.status_code == 200:
                    logger.info("ComfyUI ready at %s", url)
                    return
            except httpx.HTTPError:
                pass
            await asyncio.sleep(min(0.5, remaining))

    # -- workflow submission ------------------------------------------------

    async def submit_workflow(self, workflow: dict[str, Any]) -> str:
        """POST the workflow to ``/prompt`` and return the ``prompt_id``."""
        resp = await self._http.post("/prompt", json={"prompt": workflow})
        if resp.status_code != 200:
            raise WorkflowError(
                f"ComfyUI rejected workflow (HTTP {resp.status_code}): {resp.text}"
            )
        prompt_id: str = resp.json()["prompt_id"]
        logger.info("Workflow submitted – prompt_id=%s", prompt_id)
        return prompt_id

    # -- result polling -----------------------------------------------------

    async def poll_result(
        self,
        prompt_id: str,
        *,
        interval: float = 2.0,
    ) -> list[str]:
        """Poll ``/history/{prompt_id}`` until success.

        Returns a list of output image filenames (relative to instance
        output dir).  Runs indefinitely — the container-level timeout
        (e.g. RunPod ``executionTimeoutMs``) is expected to be the
        single source of truth for max execution time.
        """
        while True:
            resp = await self._http.get(f"/history/{prompt_id}")
            data = resp.json()

            if data and data[prompt_id]["status"]["status_str"] == "success":
                outputs = data[prompt_id]["outputs"]
                images: list[str] = []
                for value in outputs.values():
                    for img in value.get("images", []):
                        if img["type"] == "output":
                            images.append(img["filename"])
                logger.info(
                    "Prompt %s finished – %d image(s)", prompt_id, len(images)
                )
                return images

            logger.debug("Prompt %s still running…", prompt_id)
            await asyncio.sleep(interval)

    # -- convenience --------------------------------------------------------

    async def execute(
        self,
        workflow: dict[str, Any],
        *,
        ready_timeout: float = 120.0,
    ) -> list[str]:
        """Wait for readiness, submit workflow, poll for results.

        Returns output image filenames.
        """
        await self.wait_until_ready(timeout=ready_timeout)
        prompt_id = await self.submit_workflow(workflow)
        return await self.poll_result(prompt_id)
