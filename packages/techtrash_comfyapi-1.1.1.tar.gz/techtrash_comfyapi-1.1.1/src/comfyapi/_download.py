"""Async file downloads (LoRAs, input images)."""

from __future__ import annotations

import logging
import os
from pathlib import Path

import httpx

from ._types import DownloadError, LoRARef, ModelNotFoundError, ModelRef

logger = logging.getLogger(__name__)


async def download_file(
    client: httpx.AsyncClient,
    url: str,
    dest: str | Path,
) -> None:
    """Stream-download *url* to *dest* with atomic write (.tmp → rename)."""
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".tmp")

    try:
        async with client.stream("GET", url) as resp:
            if resp.status_code != 200:
                raise DownloadError(
                    f"HTTP {resp.status_code} downloading {url}"
                )
            with open(tmp, "wb") as fh:
                async for chunk in resp.aiter_bytes(chunk_size=64 * 1024):
                    fh.write(chunk)
        os.replace(tmp, dest)
        logger.info("Downloaded %s → %s", url, dest)
    except DownloadError:
        raise
    except Exception as exc:
        tmp.unlink(missing_ok=True)
        raise DownloadError(f"Failed to download {url}: {exc}") from exc


async def ensure_loras(
    client: httpx.AsyncClient,
    loras: list[LoRARef],
    models_path: str | Path,
) -> None:
    """Download any LoRAs that are not already on disk."""
    loras_dir = Path(models_path) / "loras"
    loras_dir.mkdir(parents=True, exist_ok=True)

    for lora in loras:
        dest = loras_dir / lora.name
        if dest.exists():
            logger.debug("LoRA already present: %s", lora.name)
            continue
        logger.info("Downloading LoRA %s from %s", lora.name, lora.url)
        await download_file(client, lora.url, dest)


def verify_models(
    models: list[ModelRef],
    models_path: str | Path,
) -> None:
    """Verify that every model file exists on disk.

    Raises ``ModelNotFoundError`` for the first missing model.
    """
    base = Path(models_path)
    for model in models:
        full = base / model.type / model.name
        if not full.exists():
            raise ModelNotFoundError(
                f"Model {model.name} not found at {full}"
            )
    logger.debug("All %d model(s) verified", len(models))