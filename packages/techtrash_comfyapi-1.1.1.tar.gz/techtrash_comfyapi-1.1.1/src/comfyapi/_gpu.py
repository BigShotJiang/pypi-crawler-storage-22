"""Simplified GPU detection using pynvml."""

from __future__ import annotations

import logging

from ._types import GPUInfo

logger = logging.getLogger(__name__)


def detect_gpus() -> GPUInfo:
    """Detect available CUDA GPUs via pynvml.

    Returns ``GPUInfo(cuda_available=False, device_count=0)`` when pynvml is
    not installed or the NVIDIA driver is unavailable.
    """
    try:
        import pynvml  # type: ignore[import-untyped]

        pynvml.nvmlInit()
        count = pynvml.nvmlDeviceGetCount()
        pynvml.nvmlShutdown()
        logger.info("Detected %d CUDA device(s)", count)
        return GPUInfo(cuda_available=count > 0, device_count=count)
    except Exception:
        logger.warning("pynvml unavailable – assuming no CUDA GPUs")
        return GPUInfo(cuda_available=False, device_count=0)