"""ComfyUI subprocess management."""

from __future__ import annotations

import logging
import os
import subprocess

from ._types import ComfyUIInstance, ComfyUIStartupError

logger = logging.getLogger(__name__)


def start_comfyui(
    instance: ComfyUIInstance,
    gpu_index: int,
) -> subprocess.Popen[bytes]:
    """Launch a ComfyUI process pinned to *gpu_index*.

    Returns the ``Popen`` handle.  Raises ``ComfyUIStartupError`` if the
    process cannot be created.
    """
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(gpu_index)

    cmd = [
        "python",
        "main.py",
        "--listen", "0.0.0.0",
        "--port", str(instance.port),
        "--disable-auto-launch",
        "--disable-metadata",
        "--output-directory", instance.output_dir,
        "--temp-directory", str(os.path.join(instance.path, "temp")),
    ]

    try:
        proc = subprocess.Popen(cmd, env=env, cwd=instance.path)
    except OSError as exc:
        raise ComfyUIStartupError(
            f"Failed to start ComfyUI at {instance.path}: {exc}"
        ) from exc

    logger.info(
        "ComfyUI started on GPU %d – port %d (pid %d)",
        gpu_index,
        instance.port,
        proc.pid,
    )
    return proc
