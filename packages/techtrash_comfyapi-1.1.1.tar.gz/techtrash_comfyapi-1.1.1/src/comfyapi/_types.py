"""Dataclasses and exceptions for comfyapi."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class ComfyUIInstance:
    path: str
    port: int

    @property
    def base_url(self) -> str:
        return f"http://localhost:{self.port}"

    @property
    def output_dir(self) -> str:
        return str(Path(self.path) / "output")

    @property
    def input_dir(self) -> str:
        return str(Path(self.path) / "input")


@dataclass(frozen=True, slots=True)
class GPUInfo:
    cuda_available: bool
    device_count: int


@dataclass(frozen=True, slots=True)
class ModelRef:
    type: str
    name: str


@dataclass(frozen=True, slots=True)
class LoRARef:
    name: str
    url: str
    strength: float


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class ComfyAPIError(Exception):
    """Base exception for all comfyapi errors."""


class GPUDetectionError(ComfyAPIError):
    """CUDA is not available or GPU detection failed."""


class ComfyUIStartupError(ComfyAPIError):
    """ComfyUI subprocess failed to start."""


class ComfyUITimeoutError(ComfyAPIError):
    """Ready-check or result polling exceeded timeout."""


class WorkflowError(ComfyAPIError):
    """ComfyUI rejected the workflow."""


class DownloadError(ComfyAPIError):
    """A file download failed."""


class ModelNotFoundError(ComfyAPIError):
    """A required model is not present on disk."""
