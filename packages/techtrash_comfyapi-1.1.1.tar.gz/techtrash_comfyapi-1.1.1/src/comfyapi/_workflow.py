"""Pure functions for workflow JSON preparation."""

from __future__ import annotations

import copy
import logging
from typing import Any, Callable

from ._types import LoRARef

logger = logging.getLogger(__name__)

# Expected shape of each param value:
# {
#     "type": "integer" | "string" | "image",
#     "value": <any>,
#     "node_mappings": "API - STEP",
#     "gpu_scale": true  # optional, only for integers
# }
WorkflowParams = dict[str, dict[str, Any]]


def distribute(total: int, gpu_count: int) -> list[int]:
    """Distribute *total* fairly across *gpu_count* slots.

    >>> distribute(4, 3)
    [2, 1, 1]
    >>> distribute(6, 3)
    [2, 2, 2]
    >>> distribute(1, 3)
    [1, 0, 0]
    """
    base, remainder = divmod(total, gpu_count)
    return [base + (1 if i < remainder else 0) for i in range(gpu_count)]


def prepare_workflow(
    workflow: dict[str, Any],
    gpu_count: int,
    gpu_index: int,
    params: WorkflowParams,
    loras: list[LoRARef],
    picture_resolver: Callable[[str], str] | None = None,
) -> dict[str, Any]:
    """Return a deep-copied workflow with injected parameters for one GPU.

    *params* is a unified dict where each entry can be:
    - ``type: "integer"`` / ``"string"`` → injects ``value`` into the
      matching node's ``inputs.value``.
    - ``type: "image"`` → downloads the image via *picture_resolver* and
      injects the local filename into ``inputs.image``.
    - ``gpu_scale: true`` → distributes the integer value fairly across
      GPUs using ``distribute()``.  GPU *gpu_index* gets its share.

    *loras* are injected into ``Power Lora Loader (rgthree)`` nodes.

    This function performs **no I/O**.  The optional *picture_resolver*
    callback is the only side-effect hook (used by the orchestrator to
    download input images).
    """
    wf: dict[str, Any] = copy.deepcopy(workflow)

    # Build a lookup: node_mappings title → param config
    param_by_title: dict[str, dict[str, Any]] = {}
    for cfg in params.values():
        title = cfg["node_mappings"]
        param_by_title[title] = cfg

    for node in wf.values():
        meta_title: str = node["_meta"]["title"]

        cfg = param_by_title.get(meta_title)
        if cfg is not None:
            ptype = cfg["type"]
            value = cfg["value"]

            if ptype == "image" and picture_resolver is not None:
                node["inputs"]["image"] = picture_resolver(str(value))
            elif cfg.get("gpu_scale"):
                shares = distribute(int(value), gpu_count)
                node["inputs"]["value"] = shares[gpu_index]
            else:
                node["inputs"]["value"] = value

        if node.get("class_type") == "Power Lora Loader (rgthree)":
            for i, lora in enumerate(loras):
                node["inputs"][f"lora_{i + 1}"] = {
                    "on": True,
                    "lora": lora.name,
                    "strength": lora.strength,
                }

    logger.debug(
        "Workflow prepared (gpu %d/%d, %d param(s))",
        gpu_index, gpu_count, len(params),
    )
    return wf


def inject_seed(workflow: dict[str, Any], seed: int) -> dict[str, Any]:
    """Return a deep-copied workflow with *seed* injected into the seed node."""
    wf: dict[str, Any] = copy.deepcopy(workflow)
    for node in wf.values():
        if node["_meta"]["title"] == "K - SEED":
            node["inputs"]["value"] = seed
            logger.debug("Injected seed %d", seed)
            break
    return wf
