"""ComfyAPI – orchestrator for multiple ComfyUI instances on GPU."""

from __future__ import annotations

import asyncio
import logging
import os
import random
import subprocess
from pathlib import Path
from typing import Any

import httpx
from ._client import ComfyUIClient
from ._download import ensure_loras, verify_models
from ._gpu import detect_gpus
from ._process import start_comfyui
from ._types import (
    ComfyUIInstance,
    GPUInfo,
    LoRARef,
    ModelRef,
)
from ._workflow import inject_seed, prepare_workflow

logger = logging.getLogger(__name__)


class ComfyAPI:
    """High-level orchestrator for parallel ComfyUI execution.

    Use as an async context manager::

        async with ComfyAPI(s3_config, instances, models_path) as api:
            images = await api.execute_workflow(workflow, ...)
    """

    def __init__(
        self,
        instances: list[ComfyUIInstance],
        models_path: str | Path,
        *,
        gpu: GPUInfo | None = None,
        auto_start: bool = True,
    ) -> None:
        self.instances = instances
        self.models_path = Path(models_path)
        self.gpu = gpu or detect_gpus()

        self._processes: list[subprocess.Popen[bytes]] = []
        self._clients: list[ComfyUIClient] = []
        self._download_client = httpx.AsyncClient(
            timeout=httpx.Timeout(connect=10.0, read=300.0, write=30.0, pool=10.0),
        )

        if auto_start:
            self._start_instances()

    # -- lifecycle ----------------------------------------------------------

    def _start_instances(self) -> None:
        active = self.instances[: self.gpu.device_count]
        logger.info(
            "Starting %d ComfyUI instance(s) on %d GPU(s)",
            len(active),
            self.gpu.device_count,
        )
        for i, inst in enumerate(active):
            proc = start_comfyui(inst, gpu_index=i)
            self._processes.append(proc)
            self._clients.append(ComfyUIClient(inst))

    async def aclose(self) -> None:
        """Shut down HTTP clients. Subprocesses are left running."""
        for client in self._clients:
            await client.aclose()
        await self._download_client.aclose()

    async def __aenter__(self) -> ComfyAPI:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()

    # -- picture helper -----------------------------------------------------

    def _resolve_picture(self, url: str) -> str:
        """Download an input picture to every ComfyUI input dir.

        Returns the filename (basename) for use in the workflow.
        Uses httpx synchronous client (called during workflow preparation,
        before the async fan-out).
        """
        name = url.split("/")[-1]
        for inst in self.instances[: self.gpu.device_count]:
            dest = Path(inst.input_dir) / name
            if not dest.exists():
                resp = httpx.get(url, timeout=120.0)
                resp.raise_for_status()
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(resp.content)
                logger.info("Input picture downloaded → %s", dest)
        return name

    # -- main entry point ---------------------------------------------------

    async def execute_workflow(
        self,
        workflow: dict[str, Any],
        *,
        models: list[ModelRef],
        loras: list[LoRARef],
        params: dict[str, dict[str, Any]],
    ) -> list[str]:
        """Run the workflow across all active GPUs and collect image paths.

        *params* is a unified dict — each key maps to a config with
        ``type``, ``value``, ``node_mappings``, and optionally ``gpu_scale``.

        **Partial-failure behaviour**: if some GPUs succeed and others
        fail, errors are logged and partial results are returned.  If
        *all* GPUs fail, the first exception is re-raised.
        """
        # 1. Verify models exist on disk
        verify_models(models, self.models_path)

        # 2. Download missing LoRAs
        await ensure_loras(self._download_client, loras, self.models_path)

        # 3. Prepare one workflow per GPU (each gets its fair share of gpu_scale values)
        gpu_count = self.gpu.device_count
        gpu_workflows: list[dict[str, Any]] = []
        for gpu_index in range(gpu_count):
            wf = prepare_workflow(
                workflow,
                gpu_count=gpu_count,
                gpu_index=gpu_index,
                params=params,
                loras=loras,
                picture_resolver=self._resolve_picture,
            )
            gpu_workflows.append(inject_seed(wf, random.randint(0, 999_998)))

        # 4. Fan-out: one task per GPU
        async def _run_on_gpu(
            client: ComfyUIClient, wf: dict[str, Any],
        ) -> list[str]:
            filenames = await client.execute(wf)
            return [
                os.path.join(client.instance.output_dir, f) for f in filenames
            ]

        results = await asyncio.gather(
            *[
                _run_on_gpu(c, wf)
                for c, wf in zip(self._clients, gpu_workflows)
            ],
            return_exceptions=True,
        )

        # 5. Collect results, handle partial failures
        images: list[str] = []
        errors: list[BaseException] = []
        for i, result in enumerate(results):
            if isinstance(result, BaseException):
                logger.error(
                    "GPU %d failed: %s", i, result, exc_info=result
                )
                errors.append(result)
            else:
                images.extend(result)

        if errors and not images:
            raise errors[0]

        if errors:
            logger.warning(
                "%d/%d GPU(s) failed – returning %d partial image(s)",
                len(errors),
                len(self._clients),
                len(images),
            )

        logger.info("Workflow complete – %d image(s) collected", len(images))
        return images
