# Teicor Python SDK

For full external integration setup (install flow, auth, core/runtime interaction, and troubleshooting), see:

- [SDK hub](../README.md)
- [External App Integration Guide](../EXTERNAL_APP_INTEGRATION.md)
- [AI Agent Integration Spec](../AI_AGENT_INTEGRATION_SPEC.md)

This SDK helps installed Teicor apps interact with:

- Runtime proxy APIs
- Core app-scoped state in Teicor core DB

## Install from PyPI

Add to your `requirements.txt` (pin versions):

```txt
teicor-sdk==0.2.2
```

Example install command from PyPI:

```bash
pip install teicor-sdk==0.2.2
```

## Usage

```python
from teicor_sdk import TeicorClient

client = TeicorClient(
    base_url="https://api.teicor.com",
    team_slug="client-a",
    app_slug="shopify",
    service_token="tkmkt_...",
)

context = client.get_context()
state = client.get_core_state()
state = client.patch_core_state({"cursor": "next-page-token"})
rows = client.runtime_request(method="GET", runtime_path="api/schemas")
```

## SDK CRUD quickstart (schema/table/column/record)

```python
from teicor_sdk import TeicorClient

client = TeicorClient(
    base_url="https://api.teicor.com",
    team_slug="client-a",
    app_slug="shopify",
    service_token="tkmkt_...",
)

# Context + runtime access descriptor
ctx = client.get_context()
print(ctx.runtime_access_mode)      # proxy (today)
print(ctx.runtime_proxy_base_url)   # use now
print(ctx.runtime_api_base_url)     # future direct mode

# ---------- Schema ----------
client.create_schema("app_shopify")
schemas = client.list_schemas()
client.update_schema("app_shopify", new_schema_name="app_shopify_v2")

# ---------- Table ----------
table = client.create_table(
    name="oauth_tokens",
    schema_name="app_shopify_v2",
    is_private=True,
)
table_id = str(table["id"])

tables = client.list_tables()
table_details = client.get_table(table_id)
client.update_table(table_id, name="oauth_tokens_v2")

# ---------- Column ----------
column = client.create_column(
    table_id=table_id,
    name="Provider Account Id",
    column_type="single_line_text",  # see TeicorClient.COLUMN_TYPES
    config={"unique": True},
)
column_id = str(column["id"])

columns = client.list_columns(table_id)
client.update_column(
    table_id=table_id,
    column_id=column_id,
    name="Provider Account ID",
    config={"unique": True},
)

# ---------- Record ----------
created = client.create_record(
    table_id=table_id,
    data={column_id: "acct_123"},
)
record_id = str(created["id"])

records = client.list_records(
    table_id=table_id,
    limit=50,
    offset=0,
    filter_expr={
        "and": [
            {
                "column_id": column_id,
                "op": "contains",  # see TeicorClient.FILTER_OPS
                "value": "acct_",
            }
        ]
    },
    sort=[{"column_id": column_id, "direction": "asc"}],
)

first = client.find_record(
    table_id=table_id,
    filter_expr={
        "and": [
            {"column_id": column_id, "op": "eq", "value": "acct_123"}
        ]
    },
)

client.update_record(
    table_id=table_id,
    record_id=record_id,
    data={column_id: "acct_456"},
)

client.delete_record(table_id=table_id, record_id=record_id)

# ---------- Cleanup ----------
client.delete_column(table_id=table_id, column_id=column_id)
client.delete_table(table_id)
client.delete_schema("app_shopify_v2")
```

## Package maintainers

Build artifacts:

```bash
python -m pip install --upgrade build
python -m build
```

Publish to PyPI:

```bash
python -m pip install --upgrade twine
python -m twine upload dist/*
```

## Auth headers used

- `Authorization: Bearer <service_token>`
- `X-Teicor-App-Slug: <app_slug>`

## Notes

- `core/state` is app-scoped per team installation.
- Runtime calls are proxied through Teicor backend.
- Source package is in [sdk/python/src/teicor_sdk](src/teicor_sdk).
