from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlencode
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


class TeicorSdkError(RuntimeError):
    """Base SDK exception."""


class TeicorApiError(TeicorSdkError):
    """Raised when Teicor API responds with an error status code."""

    def __init__(
        self,
        *,
        status_code: int,
        detail: str,
        request_id: str | None = None,
        response_body: str | None = None,
    ):
        self.status_code = status_code
        self.detail = detail
        self.request_id = request_id
        self.response_body = response_body
        message = f"HTTP {status_code}: {detail}"
        if request_id:
            message = f"{message} (request_id={request_id})"
        super().__init__(message)


@dataclass(frozen=True)
class TeicorContext:
    team_id: int
    team_slug: str
    runtime_proxy_base_url: str
    runtime_api_base_url: str
    runtime_access_mode: str
    core_state_url: str
    app_slug: str


class TeicorClient:
    """SDK for installed Teicor apps.

    Auth headers:
    - Authorization: Bearer <service_token>
    - X-Teicor-App-Slug: <app_slug>
    """

    SDK_VERSION = "0.2.2"
    COLUMN_TYPES = (
        "link",
        "lookup",
        "rollup",
        "single_line_text",
        "long_text",
        "checkbox",
        "date",
        "number",
        "percent",
        "created_time",
        "last_modified_time",
        "autonumber",
    )
    FILTER_OPS = (
        "eq",
        "contains",
        "gt",
        "gte",
        "lt",
        "lte",
        "is_empty",
        "is_not_empty",
    )

    def __init__(
        self,
        *,
        base_url: str,
        team_slug: str,
        app_slug: str,
        service_token: str,
        timeout_seconds: int = 20,
    ):
        self.base_url = base_url.rstrip("/")
        self.team_slug = team_slug
        self.app_slug = app_slug
        self.service_token = service_token
        self.timeout_seconds = timeout_seconds

    def _headers(self, include_json_content_type: bool) -> dict[str, str]:
        headers = {
            "Accept": "application/json",
            "Authorization": f"Bearer {self.service_token}",
            "X-Teicor-App-Slug": self.app_slug,
            "User-Agent": f"teicor-sdk-python/{self.SDK_VERSION}",
        }
        if include_json_content_type:
            headers["Content-Type"] = "application/json"
        return headers

    @staticmethod
    def _to_json(raw: str) -> Any:
        if not raw:
            return {}
        return json.loads(raw)

    def _request(
        self,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
        query: dict[str, Any] | None = None,
    ) -> Any:
        url = f"{self.base_url}{path}"
        if query:
            encoded: dict[str, str] = {}
            for key, value in query.items():
                if value is None:
                    continue
                if isinstance(value, (dict, list)):
                    encoded[key] = json.dumps(value)
                else:
                    encoded[key] = str(value)
            if encoded:
                url = f"{url}?{urlencode(encoded)}"
        body: bytes | None = None
        if payload is not None:
            body = json.dumps(payload).encode("utf-8")

        req = Request(
            url=url,
            method=method.upper(),
            data=body,
            headers=self._headers(
                include_json_content_type=payload is not None
            ),
        )
        try:
            with urlopen(req, timeout=self.timeout_seconds) as res:
                raw = res.read().decode("utf-8") if res.readable() else "{}"
                return self._to_json(raw)
        except HTTPError as exc:
            raw = exc.read().decode("utf-8") if hasattr(exc, "read") else ""
            detail = raw or f"HTTP {exc.code}"
            try:
                parsed = self._to_json(raw)
                if isinstance(parsed, dict) and isinstance(
                    parsed.get("detail"), str
                ):
                    detail = str(parsed["detail"])
            except (
                json.JSONDecodeError,
                TypeError,
                AttributeError,
                ValueError,
                TeicorSdkError,
            ):
                pass
            request_id = (
                exc.headers.get("X-Request-ID") if exc.headers else None
            )
            raise TeicorApiError(
                status_code=int(exc.code),
                detail=detail,
                request_id=request_id,
                response_body=raw or None,
            ) from exc
        except URLError as exc:
            raise TeicorSdkError(
                f"Network error calling Teicor API: {exc}"
            ) from exc
        except TimeoutError as exc:
            raise TeicorSdkError("Timed out calling Teicor API") from exc
        except json.JSONDecodeError as exc:
            raise TeicorSdkError(
                f"Invalid JSON response from Teicor API: {exc}"
            ) from exc

    def get_context(self) -> TeicorContext:
        payload = self._request(
            "GET",
            (f"/v1/teams/{self.team_slug}/context/"),
        )
        if not isinstance(payload, dict):
            raise TeicorSdkError("Invalid context response")
        team = payload.get("team") or {}
        app = payload.get("app") or {}
        runtime_access = payload.get("runtime_access") or {}
        runtime_proxy_base_url = str(
            payload.get("runtime_proxy_base_url")
            or runtime_access.get("runtime_proxy_base_url")
            or ""
        )
        runtime_api_base_url = str(
            payload.get("runtime_api_base_url")
            or runtime_access.get("runtime_api_base_url")
            or ""
        )
        runtime_access_mode = str(
            payload.get("runtime_access_mode")
            or runtime_access.get("mode")
            or "proxy"
        )
        return TeicorContext(
            team_id=int(team.get("id", 0)),
            team_slug=str(team.get("slug", self.team_slug)),
            runtime_proxy_base_url=runtime_proxy_base_url,
            runtime_api_base_url=runtime_api_base_url,
            runtime_access_mode=runtime_access_mode,
            core_state_url=str(payload.get("core_state_url", "")),
            app_slug=str(app.get("slug", self.app_slug)),
        )

    def get_core_state(self) -> dict[str, Any]:
        payload = self._request(
            "GET",
            (f"/v1/teams/{self.team_slug}/core/state/"),
        )
        if not isinstance(payload, dict):
            raise TeicorSdkError("Invalid core state response")
        return dict(payload.get("state") or {})

    def set_core_state(self, state: dict[str, Any]) -> dict[str, Any]:
        payload = self._request(
            "PUT",
            (f"/v1/teams/{self.team_slug}/core/state/"),
            {"state": state},
        )
        if not isinstance(payload, dict):
            raise TeicorSdkError("Invalid core state response")
        return dict(payload.get("state") or {})

    def patch_core_state(self, patch: dict[str, Any]) -> dict[str, Any]:
        payload = self._request(
            "PATCH",
            (f"/v1/teams/{self.team_slug}/core/state/"),
            {"state": patch},
        )
        if not isinstance(payload, dict):
            raise TeicorSdkError("Invalid core state response")
        return dict(payload.get("state") or {})

    def runtime_request(
        self,
        *,
        method: str,
        runtime_path: str,
        payload: dict[str, Any] | None = None,
        query: dict[str, Any] | None = None,
    ) -> Any:
        safe_path = (runtime_path or "").strip().lstrip("/")
        if safe_path.startswith("api/"):
            safe_path = safe_path[4:]
        if safe_path.startswith("runtime/"):
            safe_path = safe_path[8:]
        return self._request(
            method,
            (f"/v1/teams/{self.team_slug}/runtime/{safe_path}"),
            payload,
            query,
        )

    # ---------- Schemas ----------
    def list_schemas(self) -> list[str]:
        payload = self.runtime_request(method="GET", runtime_path="schemas")
        return list(payload.get("schemas") or [])

    def create_schema(self, schema_name: str) -> dict[str, Any]:
        return self.runtime_request(
            method="POST",
            runtime_path="schemas",
            payload={"schema_name": schema_name},
        )

    def update_schema(
        self, schema_name: str, *, new_schema_name: str
    ) -> dict[str, Any]:
        return self.runtime_request(
            method="PATCH",
            runtime_path=f"schemas/{schema_name}",
            payload={"new_schema_name": new_schema_name},
        )

    def delete_schema(self, schema_name: str) -> dict[str, Any]:
        return self.runtime_request(
            method="DELETE",
            runtime_path=f"schemas/{schema_name}",
        )

    # ---------- Tables ----------
    def list_tables(self) -> list[dict[str, Any]]:
        payload = self.runtime_request(method="GET", runtime_path="tables")
        if isinstance(payload, list):
            return [x for x in payload if isinstance(x, dict)]
        return []

    def get_table(self, table_id: str) -> dict[str, Any]:
        return self.runtime_request(
            method="GET",
            runtime_path=f"tables/{table_id}",
        )

    def create_table(
        self,
        *,
        name: str,
        schema_name: str = "public",
        is_private: bool = False,
    ) -> dict[str, Any]:
        return self.runtime_request(
            method="POST",
            runtime_path="tables",
            payload={
                "name": name,
                "schema_name": schema_name,
                "is_private": is_private,
            },
        )

    def update_table(self, table_id: str, *, name: str) -> dict[str, Any]:
        return self.runtime_request(
            method="PATCH",
            runtime_path=f"tables/{table_id}",
            payload={"name": name},
        )

    def delete_table(self, table_id: str) -> dict[str, Any]:
        return self.runtime_request(
            method="DELETE",
            runtime_path=f"tables/{table_id}",
        )

    # ---------- Columns ----------
    def list_columns(self, table_id: str) -> list[dict[str, Any]]:
        payload = self.runtime_request(
            method="GET",
            runtime_path=f"tables/{table_id}/columns",
        )
        if isinstance(payload, list):
            return [x for x in payload if isinstance(x, dict)]
        return []

    def create_column(
        self,
        *,
        table_id: str,
        name: str,
        column_type: str,
        config: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return self.runtime_request(
            method="POST",
            runtime_path=f"tables/{table_id}/columns",
            payload={
                "table_id": table_id,
                "name": name,
                "type": column_type,
                "config": config,
            },
        )

    def update_column(
        self,
        *,
        table_id: str,
        column_id: str,
        name: str | None = None,
        config: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if config is not None:
            payload["config"] = config
        return self.runtime_request(
            method="PATCH",
            runtime_path=f"tables/{table_id}/columns/{column_id}",
            payload=payload,
        )

    def delete_column(
        self, *, table_id: str, column_id: str
    ) -> dict[str, Any]:
        return self.runtime_request(
            method="DELETE",
            runtime_path=f"tables/{table_id}/columns/{column_id}",
        )

    # ---------- Records ----------
    def list_records(
        self,
        *,
        table_id: str,
        limit: int | None = None,
        offset: int | None = None,
        filter_expr: dict[str, Any] | None = None,
        sort: list[dict[str, Any]] | None = None,
        fields: list[str] | str | None = None,
        response_format: str | None = None,
    ) -> dict[str, Any] | list[dict[str, Any]]:
        query: dict[str, Any] = {
            "limit": limit,
            "offset": offset,
            "filter": filter_expr,
            "sort": sort,
            "format": response_format,
        }
        if isinstance(fields, list):
            query["fields"] = fields
        elif isinstance(fields, str):
            query["fields"] = fields

        return self.runtime_request(
            method="GET",
            runtime_path=f"tables/{table_id}/records",
            query=query,
        )

    def find_record(
        self,
        *,
        table_id: str,
        filter_expr: dict[str, Any],
        sort: list[dict[str, Any]] | None = None,
        fields: list[str] | str | None = None,
    ) -> dict[str, Any] | None:
        payload = self.list_records(
            table_id=table_id,
            limit=1,
            offset=0,
            filter_expr=filter_expr,
            sort=sort,
            fields=fields,
            response_format="object",
        )
        if isinstance(payload, list):
            return payload[0] if payload else None
        records = payload.get("records") if isinstance(payload, dict) else None
        if isinstance(records, list) and records:
            first = records[0]
            if isinstance(first, dict):
                return first
        return None

    def create_record(
        self,
        *,
        table_id: str,
        data: dict[str, Any],
        fields: list[str] | str | None = None,
        response_format: str | None = None,
        on_conflict: str | None = None,
    ) -> dict[str, Any]:
        query: dict[str, Any] = {
            "format": response_format,
            "on_conflict": on_conflict,
        }
        if isinstance(fields, list):
            query["fields"] = fields
        elif isinstance(fields, str):
            query["fields"] = fields

        return self.runtime_request(
            method="POST",
            runtime_path=f"tables/{table_id}/records",
            payload={"data": data},
            query=query,
        )

    def update_record(
        self,
        *,
        table_id: str,
        record_id: str,
        data: dict[str, Any],
        fields: list[str] | str | None = None,
        response_format: str | None = None,
    ) -> dict[str, Any]:
        query: dict[str, Any] = {"format": response_format}
        if isinstance(fields, list):
            query["fields"] = fields
        elif isinstance(fields, str):
            query["fields"] = fields

        return self.runtime_request(
            method="PATCH",
            runtime_path=f"tables/{table_id}/records/{record_id}",
            payload={"data": data},
            query=query,
        )

    def delete_record(
        self, *, table_id: str, record_id: str
    ) -> dict[str, Any]:
        return self.runtime_request(
            method="DELETE",
            runtime_path=f"tables/{table_id}/records/{record_id}",
        )

    def create_records_bulk(
        self,
        *,
        table_id: str,
        records: list[dict[str, Any]],
        on_conflict: str | None = None,
    ) -> dict[str, Any]:
        return self.runtime_request(
            method="POST",
            runtime_path=f"tables/{table_id}/records/bulk",
            payload={"records": [{"data": r} for r in records]},
            query={"on_conflict": on_conflict},
        )

    def delete_records_bulk(
        self, *, table_id: str, record_ids: list[str]
    ) -> dict[str, Any]:
        return self.runtime_request(
            method="POST",
            runtime_path=f"tables/{table_id}/records/bulk-delete",
            payload={"record_ids": record_ids},
        )
