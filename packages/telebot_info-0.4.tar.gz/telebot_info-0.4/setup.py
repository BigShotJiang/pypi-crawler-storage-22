from setuptools import setup, find_packages

setup(
    name="telebot_info",
    version="0.4",
    packages=find_packages(),
    author="fuckkkkk you 2 3 4",
    description="Simple Scopper Library",
    classifiers=[
        "Programming Language :: Python :: 3",
    ],
    python_requires='>=3.6',
)
