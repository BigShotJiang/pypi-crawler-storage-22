"""
cornea.py

This module provides the SDK interface for Cornea functions.

Cornea is a component of the Telekinesis project. Use this module to access and interact with Cornea-related features programmatically.

Functions:
    (Add function documentation here as you implement them.)

Example:
    import cornea
    # Use cornea functions here

"""

import requests
import os
import uuid
from typing import Dict, Any, Optional, Union, List
from cgi import parse_header
from requests_toolbelt.multipart import decoder
from loguru import logger
import numpy as np
import cv2
from datatypes import datatypes, serializer
from utils import profiler

_CORNEA_API_BASE_URL = "https://api.telekinesis.ai/cornea/v1/"

def _profiling_enabled() -> bool:
    """
    Check if profiling is enabled based on environment variable.

    Returns:
        bool: True if profiling is enabled, False otherwise.
    """
    _ENABLE_PROFILER = False
    return _ENABLE_PROFILER == True


def _load_api_key() -> str:
    """
    Load the Telekinesis API key from the environment variable.

    Retrieves the API key required for authentication with Telekinesis services
    from the TELEKINESIS_API_KEY environment variable.

    Returns:
        str: The API key string.

    Raises:
        RuntimeError: If TELEKINESIS_API_KEY environment variable is not set.
    """
    api_key = os.getenv("TELEKINESIS_API_KEY")
    if not api_key:
        raise RuntimeError("Telekinesis API key not found.\n\n"
                           "Set the TELEKINESIS_API_KEY environment variable.")

    return api_key


def _send_request(endpoint: str, input_data: dict) -> dict:
    """
    Send Telekinesis datatypes via multipart/mixed request.

    Serializes input data to Arrow IPC format and sends it as a multipart/mixed
    HTTP request to the specified endpoint.

    Args:
        endpoint (str): The API endpoint to send the request to.
        input_data (dict): Dictionary of data to serialize and send.

    Returns:
        dict: Deserialized response data from the server.

    Raises:
        RuntimeError: If API key is not found, response is not multipart,
            or response part is missing a name.
        requests.RequestException: If the HTTP request fails.
    """
    
    if _profiling_enabled():
        profiler_instance = profiler.Profiler(
            endpoint=endpoint,
            method="POST",
            enabled=_profiling_enabled(),
            base_url=_CORNEA_API_BASE_URL,
        )
        profiler_instance.start()

    API_KEY = _load_api_key()

    def write_multipart_request(parts: dict[str, bytes]) -> tuple[bytes, str]:
        boundary = uuid.uuid4().hex
        body = bytearray()

        for name, payload in parts.items():
            body.extend(
                f"--{boundary}\r\n"
                f"Content-Type: application/vnd.apache.arrow.stream\r\n"
                f"Content-Disposition: inline; name=\"{name}\"\r\n\r\n"
                .encode()
            )
            body.extend(payload)
            body.extend(b"\r\n")

        body.extend(f"--{boundary}--\r\n".encode())
        return bytes(body), boundary

    # ---------- BUILD REQUEST ----------
    if _profiling_enabled():
        profiler_instance.mark("build_start")

    fields = {}
    total_request_bytes = 0

    if _profiling_enabled():
        profiler_instance.mark("serialize_start")

    for name, value in input_data.items():
        arrow_bytes = serializer.serialize_to_pyarrow_ipc(value)
        total_request_bytes += len(arrow_bytes)
        fields[name] = arrow_bytes
    
    if _profiling_enabled():
        profiler_instance.mark("serialize_end")

    body, boundary = write_multipart_request(fields)

    if _profiling_enabled():
        profiler_instance.mark("build_end")

    headers = {
        "X-API-Key": API_KEY,
        "Content-Type": f"multipart/mixed; boundary={boundary}",
        "Content-Length": str(len(body)),
    }

    # ---------- HTTP ----------
    try:
        if _profiling_enabled():
            profiler_instance.mark("http_start")

        response = requests.post(
            f"{_CORNEA_API_BASE_URL}{endpoint}",
            data=body,
            headers=headers,
            timeout=130,
            stream=True,
        )

        response_content = response.content  # force full download

        if _profiling_enabled():
            profiler_instance.mark("http_end")

    except requests.RequestException as e:
        logger.error(f"Request failed: {e}")
        raise

    # ---------- error handling ----------

    if not response.ok:
        content_type = response.headers.get("Content-Type", "")
        error = response.json() if "application/json" in content_type else response.text
        raise RuntimeError(f"Request failed [{response.status_code}]: {error}")

    # ---------- PARSE RESPONSE ----------

    if _profiling_enabled():
        profiler_instance.mark("parse_start")

    content_type = response.headers.get("Content-Type", "")
    if "multipart/" not in content_type:
        raise RuntimeError("Expected multipart response from server")

    decoded_data = decoder.MultipartDecoder.from_response(response)

    output_data = {}
    total_response_bytes = 0

    if _profiling_enabled():
        profiler_instance.mark("deserialize_start")

    for part in decoded_data.parts:
        total_response_bytes += len(part.content)

        cd = part.headers.get(b"Content-Disposition", b"").decode()
        _, params = parse_header(cd)
        name = params.get("name")
        if not name:
            raise RuntimeError("Missing name in multipart response part")

        output_data[name] = serializer.deserialize_from_pyarrow_ipc(part.content)
    
    if _profiling_enabled():
        profiler_instance.mark("deserialize_end")
    
    if _profiling_enabled():
        profiler_instance.mark("parse_end")

    # ---------- finalize profiling ----------

    if _profiling_enabled():
        profiler_instance.add_sizes(
            request_bytes=total_request_bytes,
            response_bytes=total_response_bytes,
        )
        profiler_instance.end()
    
    return output_data


# Color Segmentation Functions


def segment_image_using_rgb(
    image: datatypes.Image | np.ndarray,
    lower_bound: Union[List[int], tuple[int]] = (0, 0, 0),
    upper_bound: Union[List[int], tuple[int]] = (255, 255, 255),
    image_id: datatypes.Int | int = 0,
) -> Dict[str, Any]:
    """
    Perform RGB color space segmentation.

    Segments an image by filtering pixels within the specified RGB color range.
    Pixels within the lower and upper bounds are considered part of the segment.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W, 3).
        lower_bound (List[int] or tuple[int]): Lower bound for RGB range [R, G, B].
            Default: [0, 0, 0].
        upper_bound (List[int] or tuple[int]): Upper bound for RGB range [R, G, B].
            Default: [255, 255, 255].
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Segmentation results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If lower_bound or upper_bound is not a list.
        TypeError: If image_id is not an Int object or int.
        ValueError: If lower_bound or upper_bound does not have 3 elements.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )
    if not isinstance(lower_bound, (list, tuple)):
        raise TypeError(
            f"lower_bound must be a list or tuple, class received: {type(lower_bound).__name__}"
        )
    if len(lower_bound) != 3:
        raise ValueError(
            f"lower_bound must have 3 elements, got {len(lower_bound)}"
        )
    for i in lower_bound:
        if not isinstance(i, int):
            raise TypeError(
                f"lower_bound elements must be integers, class received: {type(i).__name__}"
            )

    if not isinstance(upper_bound, (list, tuple)):
        raise TypeError(
            f"upper_bound must be a list or tuple, class received: {type(upper_bound).__name__}"
        )
    if len(upper_bound) != 3:
        raise ValueError(
            f"upper_bound must have 3 elements, got {len(upper_bound)}"
        )
    for i in upper_bound:
        if not isinstance(i, int):
            raise TypeError(
                f"upper_bound elements must be integers, class received: {type(i).__name__}"
            )

    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)

    # Convert lists to Vector3D
    lower_bound = datatypes.Vector3D(xyz=np.array(lower_bound, dtype=np.uint8))
    upper_bound = datatypes.Vector3D(xyz=np.array(upper_bound, dtype=np.uint8))

    input_data = {
        "image": image,
        "lower_bound": lower_bound,
        "upper_bound": upper_bound,
        "image_id": image_id,
    }

    end_point = "segment_image_using_rgb"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


def segment_image_using_hsv(
    image: datatypes.Image | np.ndarray,
    lower_bound: Union[List[int], tuple[int]] = (0, 0, 0),
    upper_bound: Union[List[int], tuple[int]] = (180, 255, 255),
    image_id: datatypes.Int | int = 0,
) -> Dict[str, Any]:
    """
    Perform HSV color space segmentation.

    Segments an image by filtering pixels within the specified HSV color range.
    Useful for color-based object detection where hue is more reliable than RGB.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W, 3).
        lower_bound (List[int] or tuple[int]): Lower bound for HSV range [H: 0-180, S: 0-255, V: 0-255].
            Default: [0, 0, 0].
        upper_bound (List[int] or tuple[int]): Upper bound for HSV range [H: 0-180, S: 0-255, V: 0-255].
            Default: [180, 255, 255].
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Segmentation results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If lower_bound or upper_bound is not a list.
        TypeError: If image_id is not an Int object or int.
        ValueError: If lower_bound or upper_bound does not have 3 elements.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )
    if not isinstance(lower_bound, (list, tuple)):
        raise TypeError(
            f"lower_bound must be a list or tuple, class received: {type(lower_bound).__name__}"
        )
    if len(lower_bound) != 3:
        raise ValueError(
            f"lower_bound must have 3 elements, got {len(lower_bound)}"
        )

    for i, val in enumerate(lower_bound):
        if not isinstance(val, int):
            raise TypeError(
                f"lower_bound[{i}] must be an int, class received: {type(val).__name__}"
            )

    if not isinstance(upper_bound, (list, tuple)):
        raise TypeError(
            f"upper_bound must be a list or tuple, class received: {type(upper_bound).__name__}"
        )
    if len(upper_bound) != 3:
        raise ValueError(
            f"upper_bound must have 3 elements, got {len(upper_bound)}"
        )

    for i, val in enumerate(upper_bound):
        if not isinstance(val, int):
            raise TypeError(
                f"upper_bound[{i}] must be an int, class received: {type(val).__name__}"
            )

    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)

    # Convert lists to Vector3D
    lower_bound = datatypes.Vector3D(xyz=np.array(lower_bound, dtype=np.uint8))
    upper_bound = datatypes.Vector3D(xyz=np.array(upper_bound, dtype=np.uint8))

    input_data = {
        "image": image,
        "lower_bound": lower_bound,
        "upper_bound": upper_bound,
        "image_id": image_id,
    }

    end_point = "segment_image_using_hsv"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


def segment_image_using_lab(
    image: datatypes.Image | np.ndarray,
    lower_bound: Union[List[int], tuple[int]] = [0, 0, 0],
    upper_bound: Union[List[int], tuple[int]] = [255, 255, 255],
    image_id: datatypes.Int | int = 0,
) -> Dict[str, Any]:
    """
    Perform LAB color space segmentation.

    Segments an image by filtering pixels within the specified LAB color range.
    LAB color space is perceptually uniform, making it suitable for color-based
    segmentation tasks where perceived color differences matter.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W, 3).
        lower_bound (List[int] or tuple[int]): Lower bound for LAB range [L, A, B].
            Default: [0, 0, 0].
        upper_bound (List[int] or tuple[int]): Upper bound for LAB range [L, A, B].
            Default: [255, 255, 255].
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Segmentation results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If lower_bound or upper_bound is not a list.
        TypeError: If image_id is not an Int object or int.
        ValueError: If lower_bound or upper_bound does not have 3 elements.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )
    if not isinstance(lower_bound, (list, tuple)):
        raise TypeError(
            f"lower_bound must be a list or tuple, class received: {type(lower_bound).__name__}"
        )
    if len(lower_bound) != 3:
        raise ValueError(
            f"lower_bound must have 3 elements, got {len(lower_bound)}"
        )
    for i in lower_bound:
        if not isinstance(i, int):
            raise TypeError(
                f"lower_bound elements must be integers, class received: {type(i).__name__}"
            )

    if not isinstance(upper_bound, (list, tuple)):
        raise TypeError(
            f"upper_bound must be a list or tuple, class received: {type(upper_bound).__name__}"
        )
    if len(upper_bound) != 3:
        raise ValueError(
            f"upper_bound must have 3 elements, got {len(upper_bound)}"
        )
    for i in upper_bound:
        if not isinstance(i, int):
            raise TypeError(
                f"upper_bound elements must be integers, class received: {type(i).__name__}"
            )
    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)

    # Convert lists to Vector3D
    lower_bound = datatypes.Vector3D(xyz=np.array(lower_bound, dtype=np.uint8))
    upper_bound = datatypes.Vector3D(xyz=np.array(upper_bound, dtype=np.uint8))

    input_data = {
        "image": image,
        "lower_bound": lower_bound,
        "upper_bound": upper_bound,
        "image_id": image_id,
    }

    end_point = "segment_image_using_lab"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


def segment_image_using_ycrcb(
    image: datatypes.Image | np.ndarray,
    lower_bound: Union[List[int], tuple[int]] = [0, 133, 77],
    upper_bound: Union[List[int], tuple[int]] = [255, 173, 127],
    image_id: datatypes.Int | int = 0,
) -> Dict[str, Any]:
    """
    Perform YCrCb color space segmentation.

    Segments an image by filtering pixels within the specified YCrCb color range.
    YCrCb separates luminance from chrominance, making it useful for skin detection
    and other applications where lighting variations should be minimized.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W, 3).
        lower_bound (List[int] or tuple[int]): Lower bound for YCrCb range [Y, Cr, Cb].
            Default: [0, 133, 77].
        upper_bound (List[int] or tuple[int]): Upper bound for YCrCb range [Y, Cr, Cb].
            Default: [255, 173, 127].
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Segmentation results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If lower_bound or upper_bound is not a list.
        TypeError: If image_id is not an Int object or int.
        ValueError: If lower_bound or upper_bound does not have 3 elements.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )
    if not isinstance(lower_bound, (list, tuple)):
        raise TypeError(
            f"lower_bound must be a list or tuple, class received: {type(lower_bound).__name__}"
        )
    if len(lower_bound) != 3:
        raise ValueError(
            f"lower_bound must have 3 elements, got {len(lower_bound)}"
        )

    for i in lower_bound:
        if not isinstance(i, int):
            raise TypeError(
                f"lower_bound elements must be integers, class received: {type(i).__name__}"
            )

    if not isinstance(upper_bound, (list, tuple)):
        raise TypeError(
            f"upper_bound must be a list or tuple, class received: {type(upper_bound).__name__}"
        )
    if len(upper_bound) != 3:
        raise ValueError(
            f"upper_bound must have 3 elements, got {len(upper_bound)}"
        )
    for i in upper_bound:
        if not isinstance(i, int):
            raise TypeError(
                f"upper_bound elements must be integers, class received: {type(i).__name__}"
            )

    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)
    if image.color_model != 'BGR':
        image_np = image.to_numpy()
        image_bgr = cv2.cvtColor(image_np, cv2.COLOR_RGB2BGR)
        image = datatypes.Image(image=image_bgr, color_model='BGR')

    # Convert lists to Vector3D
    lower_bound = datatypes.Vector3D(xyz=np.array(lower_bound, dtype=np.uint8))
    upper_bound = datatypes.Vector3D(xyz=np.array(upper_bound, dtype=np.uint8))

    input_data = {
        "image": image,
        "lower_bound": lower_bound,
        "upper_bound": upper_bound,
        "image_id": image_id,
    }

    end_point = "segment_image_using_ycrcb"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


# Region Segmentation Functions


def segment_image_using_flood_fill(
    image: datatypes.Image | np.ndarray,
    seed_point: datatypes.Points2D | np.ndarray | list | tuple = [0, 0],
    tolerance: datatypes.Int | int = 10,
    image_id: datatypes.Int | int = 0,
) -> Dict[str, Any]:
    """
    Perform flood fill segmentation.

    Fills a connected region starting from the seed point, including all neighboring
    pixels whose values are within the specified tolerance of the seed pixel value.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W) or (H, W, 3).
        seed_point (datatypes.Points2D | np.ndarray | list | tuple): Starting point for
            flood fill [x, y]. Default: [0, 0].
        tolerance (datatypes.Int | int): Color tolerance for flood fill.
            Default: 10.
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Segmentation results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If seed_point is not a Points2D, np.ndarray, or list.
        TypeError: If tolerance is not an Int object or int.
        TypeError: If image_id is not an Int object or int.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(seed_point, (datatypes.Points2D, np.ndarray, list, tuple)):
        raise TypeError(
            f"seed_point must be a Points2D, np.ndarray, list, or tuple, class received: {type(seed_point).__name__}"
        )
    if not isinstance(tolerance, (datatypes.Int, int)):
        raise TypeError(
            f"tolerance must be an Int object or int, class received: {type(tolerance).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )

    # Convert seed_point to Points2D
    if isinstance(seed_point, list):
        # Convert [x, y] to [[x, y]] format for Points2D
        if isinstance(seed_point[0], (int, float)):
            seed_point = datatypes.Points2D(positions=np.array([seed_point], dtype=np.float32))
        else:
            seed_point = datatypes.Points2D(positions=np.array(seed_point, dtype=np.float32))
    elif isinstance(seed_point, np.ndarray):
        # Ensure it's in the right shape for Points2D (N, 2)
        if seed_point.ndim == 1:
            seed_point = datatypes.Points2D(positions=np.array([seed_point], dtype=np.float32))
        else:
            seed_point = datatypes.Points2D(positions=np.array(seed_point, dtype=np.float32))
    elif isinstance(seed_point, tuple):
        if len(seed_point) == 2 and all(isinstance(i, (int, float)) for i in seed_point):
            seed_point = datatypes.Points2D(positions=np.array([seed_point], dtype=np.float32))

    if isinstance(tolerance, int):
        tolerance = datatypes.Int(tolerance)
    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)

    input_data = {
        "image": image,
        "seed_point": seed_point,
        "tolerance": tolerance,
        "image_id": image_id
    }

    end_point = "segment_image_using_flood_fill"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


def segment_image_using_watershed(
    image: datatypes.Image | np.ndarray,
    markers: datatypes.Image | np.ndarray,
    connectivity: datatypes.Int | int = 1,
    image_id: datatypes.Int | int = 0,
) -> Dict[str, Any]:
    """
    Perform watershed segmentation.

    Uses the watershed algorithm to segment the image based on provided marker
    regions. Markers define the initial seeds for each segment, and the algorithm
    grows these regions until they meet at watershed lines.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W) or (H, W, 3).
        markers (datatypes.Image | np.ndarray): Marker image for watershed
            segmentation.
        connectivity (datatypes.Int | int): Connectivity for watershed (1 or 2).
            Default: 1.
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Segmentation results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If markers is not an Image object or np.ndarray.
        TypeError: If connectivity is not an Int object or int.
        TypeError: If image_id is not an Int object or int.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if isinstance(markers, np.ndarray):
        markers = datatypes.Image(image=markers)
    if not isinstance(markers, datatypes.Image):
        raise TypeError(
            f"markers must be an Image object or np.ndarray, class received: {type(markers).__name__}"
        )
    if not isinstance(connectivity, (datatypes.Int, int)):
        raise TypeError(
            f"connectivity must be an Int object or int, class received: {type(connectivity).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )

    if isinstance(connectivity, int):
        connectivity = datatypes.Int(connectivity)
    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)

    input_data = {
        "image": image,
        "markers": markers,
        "connectivity": connectivity,
        "image_id": image_id,
    }

    end_point = "segment_image_using_watershed"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


def segment_image_using_focus_region(
    image: datatypes.Image | np.ndarray,
    blur_kernel_size: datatypes.Int | int = 10,
    threshold: datatypes.Int | int = 1,
    image_id: datatypes.Int | int = 0,
) -> Dict[str, Any]:
    """
    Segment the in-focus regions of an image.

    Detects and segments regions of the image that are in focus by analyzing
    local variance or sharpness. Useful for depth-of-field based segmentation.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W) or (H, W, 3).
        blur_kernel_size (datatypes.Int | int): Kernel size for blur operation.
            Default: 10.
        threshold (datatypes.Int | int): Threshold for focus detection.
            Default: 1.
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Segmentation results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If blur_kernel_size is not an Int object or int.
        TypeError: If threshold is not an Int object or int.
        TypeError: If image_id is not an Int object or int.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(blur_kernel_size, (datatypes.Int, int)):
        raise TypeError(
            f"blur_kernel_size must be an Int object or int, class received: {type(blur_kernel_size).__name__}"
        )
    if not isinstance(threshold, (datatypes.Int, int)):
        raise TypeError(
            f"threshold must be an Int object or int, class received: {type(threshold).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )

    if isinstance(blur_kernel_size, int):
        blur_kernel_size = datatypes.Int(blur_kernel_size)
    if isinstance(threshold, int):
        threshold = datatypes.Int(threshold)
    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)

    input_data = {
        "image": image,
        "blur_kernel_size": blur_kernel_size,
        "threshold": threshold,
        "image_id": image_id,
    }

    end_point = "segment_image_using_focus_region"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


# Threshold Segmentation Functions


def segment_image_using_otsu_threshold(
    image: datatypes.Image | np.ndarray,
    image_id: datatypes.Int | int = 0,
) -> Dict[str, Any]:
    """
    Perform Otsu threshold segmentation.

    Automatically determines the optimal threshold value using Otsu's method,
    which minimizes the intra-class variance between foreground and background.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W) or (H, W, 3).
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Segmentation results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If image_id is not an Int object or int.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )

    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)

    input_data = {
        "image": image,
        "image_id": image_id,
    }

    end_point = "segment_image_using_otsu_threshold"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


def segment_image_using_local_threshold(
    image: datatypes.Image | np.ndarray,
    block_size: datatypes.Int | int = 35,
    image_id: datatypes.Int | int = 0,
) -> Dict[str, Any]:
    """
    Perform local threshold segmentation.

    Applies thresholding locally by computing a threshold for each pixel based
    on the local neighborhood. Effective for images with varying illumination.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W) or (H, W, 3).
        block_size (datatypes.Int | int): Block size for local threshold
            computation. Default: 35.
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Segmentation results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If block_size is not an Int object or int.
        TypeError: If image_id is not an Int object or int.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(block_size, (datatypes.Int, int)):
        raise TypeError(
            f"block_size must be an Int object or int, class received: {type(block_size).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )

    if isinstance(block_size, int):
        block_size = datatypes.Int(block_size)
    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)

    input_data = {
        "image": image,
        "block_size": block_size,
        "image_id": image_id,
    }

    end_point = "segment_image_using_local_threshold"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


def segment_image_using_yen_threshold(
    image: datatypes.Image | np.ndarray,
    image_id: datatypes.Int | int = 0,
) -> Dict[str, Any]:
    """
    Perform Yen threshold segmentation.

    Automatically determines the optimal threshold value using Yen's method,
    which maximizes the correlation between the original and binarized image.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W) or (H, W, 3).
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Segmentation results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If image_id is not an Int object or int.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )

    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)

    input_data = {
        "image": image,
        "image_id": image_id,
    }

    end_point = "segment_image_using_yen_threshold"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


def segment_image_using_threshold(
    image: datatypes.Image | np.ndarray,
    min_value: datatypes.Int | int = 127,
    max_value: datatypes.Int | int = 255,
    threshold_type: datatypes.String | str = 'binary',
    image_id: datatypes.Int | int = 0,
) -> Dict[str, Any]:
    """
    Perform basic threshold segmentation.

    Applies a fixed threshold to segment the image into foreground and background
    based on specified minimum and maximum values.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W) or (H, W, 3).
        min_value (datatypes.Int | int): Minimum threshold value. Default: 127.
        max_value (datatypes.Int | int): Maximum threshold value. Default: 255.
        threshold_type (datatypes.String | str): Type of threshold ('binary',
            'binary_inv', 'trunc', 'tozero', 'tozero_inv'). Default: 'binary'.
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Segmentation results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If min_value or max_value is not an Int object or int.
        TypeError: If threshold_type is not a String object or str.
        TypeError: If image_id is not an Int object or int.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(min_value, (datatypes.Int, int)):
        raise TypeError(
            f"min_value must be an Int object or int, class received: {type(min_value).__name__}"
        )
    if not isinstance(max_value, (datatypes.Int, int)):
        raise TypeError(
            f"max_value must be an Int object or int, class received: {type(max_value).__name__}"
        )
    if not isinstance(threshold_type, (datatypes.String, str)):
        raise TypeError(
            f"threshold_type must be a String object or str, class received: {type(threshold_type).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )


    if isinstance(min_value, int):
        min_value = datatypes.Int(min_value)
    if isinstance(max_value, int):
        max_value = datatypes.Int(max_value)
    if isinstance(threshold_type, str):
        threshold_type = datatypes.String(threshold_type)
    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)


    input_data = {
        "image": image,
        "min_value": min_value,
        "max_value": max_value,
        "threshold_type": threshold_type,
        "image_id": image_id,
    }

    end_point = "segment_image_using_threshold"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


def segment_image_using_adaptive_threshold(
    image: datatypes.Image | np.ndarray,
    max_value: datatypes.Int | int = 255,
    adaptive_method: datatypes.String | str = "gaussian constant",
    threshold_type: datatypes.String | str = 'binary',
    block_size: datatypes.Int | int = 11,
    offset_constant: datatypes.Int | int = 2,
    image_id: datatypes.Int | int = 0
) -> Dict[str, Any]:
    """
    Perform adaptive threshold segmentation.

    Applies adaptive thresholding where the threshold value is calculated for
    each pixel based on a weighted sum of neighboring pixel values.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W) or (H, W, 3).
        max_value (datatypes.Int | int): Maximum value for threshold.
            Default: 255.
        adaptive_method (datatypes.String | str): Adaptive method ('mean constant'
            or 'gaussian constant'). Default: "gaussian constant".
        threshold_type (datatypes.String | str): Type of threshold.
            Default: 'binary'.
        block_size (datatypes.Int | int): Block size for adaptive threshold.
            Default: 11.
        offset_constant (datatypes.Int | int): Constant subtracted from mean.
            Default: 2.
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Segmentation results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If max_value, block_size, or offset_constant is not an Int
            object or int.
        TypeError: If adaptive_method or threshold_type is not a String object
            or str.
        TypeError: If image_id is not an Int object or int.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(max_value, (datatypes.Int, int)):
        raise TypeError(
            f"max_value must be an Int object or int, class received: {type(max_value).__name__}"
        )
    if not isinstance(adaptive_method, (datatypes.String, str)):
        raise TypeError(
            f"adaptive_method must be a String object or str, class received: {type(adaptive_method).__name__}"
        )
    if not isinstance(threshold_type, (datatypes.String, str)):
        raise TypeError(
            f"threshold_type must be a String object or str, class received: {type(threshold_type).__name__}"
        )
    if not isinstance(block_size, (datatypes.Int, int)):
        raise TypeError(
            f"block_size must be an Int object or int, class received: {type(block_size).__name__}"
        )
    if not isinstance(offset_constant, (datatypes.Int, int)):
        raise TypeError(
            f"offset_constant must be an Int object or int, class received: {type(offset_constant).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )

    if isinstance(max_value, int):
        max_value = datatypes.Int(max_value)
    if isinstance(adaptive_method, str):
        adaptive_method = datatypes.String(adaptive_method)
    if isinstance(threshold_type, str):
        threshold_type = datatypes.String(threshold_type)
    if isinstance(block_size, int):
        block_size = datatypes.Int(block_size)
    if isinstance(offset_constant, int):
        offset_constant = datatypes.Int(offset_constant)
    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)

    input_data = {
        "image": image,
        "max_value": max_value,
        "adaptive_method": adaptive_method,
        "threshold_type": threshold_type,
        "block_size": block_size,
        "offset_constant": offset_constant,
        "image_id": image_id,
    }

    end_point = "segment_image_using_adaptive_threshold"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


def segment_image_using_laplacian_threshold(
    image: datatypes.Image | np.ndarray,
    image_id: datatypes.Int | int = 0,
) -> Dict[str, Any]:
    """
    Perform Laplacian threshold segmentation.

    Uses the Laplacian operator to detect edges and applies thresholding to
    create a binary segmentation based on edge information.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W) or (H, W, 3).
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Segmentation results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If image_id is not an Int object or int.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )

    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)

    input_data = {
        "image": image,
        "image_id": image_id,
    }

    end_point = "segment_image_using_laplacian_threshold"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


# Superpixel Segmentation Functions


def segment_image_using_felzenszwalb(
    image: datatypes.Image | np.ndarray,
    scale: datatypes.Int | int = 100,
    sigma: datatypes.Float | float = 0.5,
    min_size: datatypes.Int | int = 50,
    image_id: datatypes.Int | int = 0,
) -> Dict[str, Any]:
    """
    Perform Felzenszwalb segmentation.

    Segments the image using graph-based segmentation algorithm by Felzenszwalb
    and Huttenlocher. Creates superpixels by greedily merging regions.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W, 3).
        scale (datatypes.Int | int): Controls segment size preference.
            Default: 100.
        sigma (datatypes.Float | float): Gaussian smoothing sigma. Default: 0.5.
        min_size (datatypes.Int | int): Minimum segment size. Default: 50.
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Segmentation results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If scale or min_size is not an Int object or int.
        TypeError: If sigma is not a Float object or float.
        TypeError: If image_id is not an Int object or int.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(scale, (datatypes.Int, int)):
        raise TypeError(
            f"scale must be an Int object or int, class received: {type(scale).__name__}"
        )
    if not isinstance(sigma, (datatypes.Float, float, datatypes.Int, int)):
        raise TypeError(
            f"sigma must be a Float object or float, class received: {type(sigma).__name__}"
        )
    if not isinstance(min_size, (datatypes.Int, int)):
        raise TypeError(
            f"min_size must be an Int object or int, class received: {type(min_size).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )

    if isinstance(scale, int):
        scale = datatypes.Int(scale)

    if isinstance(sigma, (float, int)):
        sigma = datatypes.Float(sigma)
    if isinstance(sigma, datatypes.Int):
        sigma = datatypes.Float(sigma.value)

    if isinstance(min_size, int):
        min_size = datatypes.Int(min_size)
    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)

    input_data = {
        "image": image,
        "scale": scale,
        "sigma": sigma,
        "min_size": min_size,
        "image_id": image_id,
    }

    end_point = "segment_image_using_felzenszwalb"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


def segment_image_using_slic_superpixel(
    image: datatypes.Image | np.ndarray,
    num_segments: datatypes.Int | int = 100,
    compactness: datatypes.Float | float = 10.0,
    max_iterations: datatypes.Int | int = 10,
    sigma: datatypes.Float | float = 0.0,
    spacing: Optional[List[int]] = None,
    convert_to_lab: Optional[datatypes.Bool | bool] = None,
    enforce_connectivity: datatypes.Bool | bool = True,
    min_size_factor: datatypes.Float | float = 0.5,
    max_size_factor: datatypes.Float | float = 3.0,
    use_slic_zero: datatypes.Bool | bool = False,
    start_label: datatypes.Int | int = 1,
    mask: Optional[datatypes.Image | np.ndarray] = None,
    channel_axis: datatypes.Int | int = -1,
    image_id: datatypes.Int | int = 0,
) -> Dict[str, Any]:
    """
    Perform SLIC superpixel segmentation.

    Segments the image using Simple Linear Iterative Clustering (SLIC) algorithm
    to generate compact, nearly uniform superpixels.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W, 3).
        num_segments (datatypes.Int | int): Approximate number of segments.
            Default: 100.
        compactness (datatypes.Float | float): Balance between color and spatial
            proximity. Default: 10.0.
        max_iterations (datatypes.Int | int): Maximum iterations. Default: 10.
        sigma (datatypes.Float | float): Gaussian smoothing sigma. Default: 0.0.
        spacing (Optional[List[int]]): Spacing between pixels [y, x].
            Default: None.
        convert_to_lab (Optional[datatypes.Bool | bool]): Convert to LAB color
            space. Default: None.
        enforce_connectivity (datatypes.Bool | bool): Enforce segment connectivity.
            Default: True.
        min_size_factor (datatypes.Float | float): Minimum size factor.
            Default: 0.5.
        max_size_factor (datatypes.Float | float): Maximum size factor.
            Default: 3.0.
        use_slic_zero (datatypes.Bool | bool): Use SLIC zero variant.
            Default: False.
        start_label (datatypes.Int | int): Starting label value. Default: 1.
        mask (Optional[datatypes.Image | np.ndarray]): Optional mask image.
            Default: None.
        channel_axis (datatypes.Int | int): Channel axis position. Default: -1.
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Segmentation results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If num_segments, max_iterations, start_label, or channel_axis
            is not an Int object or int.
        TypeError: If compactness, sigma, min_size_factor, or max_size_factor
            is not a Float object or float.
        TypeError: If convert_to_lab, enforce_connectivity, or use_slic_zero
            is not a Bool object or bool.
        TypeError: If spacing is not a list or None.
        TypeError: If mask is not an Image object, np.ndarray, or None.
        TypeError: If image_id is not an Int object or int.
        ValueError: If spacing is provided but does not have 2 elements.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(num_segments, (datatypes.Int, int)):
        raise TypeError(
            f"num_segments must be an Int object or int, class received: {type(num_segments).__name__}"
        )
    if not isinstance(compactness, (datatypes.Float, float, datatypes.Int, int)):
        raise TypeError(
            f"compactness must be a Float object or float, class received: {type(compactness).__name__}"
        )
    if not isinstance(max_iterations, (datatypes.Int, int)):
        raise TypeError(
            f"max_iterations must be an Int object or int, class received: {type(max_iterations).__name__}"
        )
    if not isinstance(sigma, (datatypes.Float, float, datatypes.Int, int)):
        raise TypeError(
            f"sigma must be a Float object or float, class received: {type(sigma).__name__}"
        )
    if convert_to_lab is not None and not isinstance(convert_to_lab, (datatypes.Bool, bool)):
        raise TypeError(
            f"convert_to_lab must be a Bool object, bool, or None, class received: {type(convert_to_lab).__name__}"
        )
    if not isinstance(enforce_connectivity, (datatypes.Bool, bool)):
        raise TypeError(
            f"enforce_connectivity must be a Bool object or bool, class received: {type(enforce_connectivity).__name__}"
        )
    if not isinstance(min_size_factor, (datatypes.Float, float, datatypes.Int, int)):
        raise TypeError(
            f"min_size_factor must be a Float object or float, class received: {type(min_size_factor).__name__}"
        )
    if not isinstance(max_size_factor, (datatypes.Float, float, datatypes.Int, int)):
        raise TypeError(
            f"max_size_factor must be a Float object or float, class received: {type(max_size_factor).__name__}"
        )
    if not isinstance(use_slic_zero, (datatypes.Bool, bool)):
        raise TypeError(
            f"use_slic_zero must be a Bool object or bool, class received: {type(use_slic_zero).__name__}"
        )
    if not isinstance(start_label, (datatypes.Int, int)):
        raise TypeError(
            f"start_label must be an Int object or int, class received: {type(start_label).__name__}"
        )
    if mask is not None:
        if isinstance(mask, np.ndarray):
            mask = datatypes.Image(image=mask)
        if not isinstance(mask, datatypes.Image):
            raise TypeError(
                f"mask must be an Image object, np.ndarray, or None, class received: {type(mask).__name__}"
            )
    if not isinstance(channel_axis, (datatypes.Int, int)):
        raise TypeError(
            f"channel_axis must be an Int object or int, class received: {type(channel_axis).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )

    if spacing is not None:
        if not isinstance(spacing, list):
            raise TypeError(
                f"spacing must be a list or None, class received: {type(spacing).__name__}"
            )
        if len(spacing) != 2:
            raise ValueError(
                f"spacing must have 2 elements, got {len(spacing)}"
            )

    if isinstance(num_segments, int):
        num_segments = datatypes.Int(num_segments)
    if isinstance(compactness, (float, int)):
        compactness = datatypes.Float(compactness)
    if isinstance(compactness, datatypes.Int):
        compactness = datatypes.Float(compactness.value)

    if isinstance(max_iterations, int):
        max_iterations = datatypes.Int(max_iterations)
    if isinstance(sigma, (float, int)):
        sigma = datatypes.Float(sigma)
    if isinstance(sigma, datatypes.Int):
        sigma = datatypes.Float(sigma.value)
    if isinstance(convert_to_lab, bool):
        convert_to_lab = datatypes.Bool(convert_to_lab)
    if isinstance(enforce_connectivity, bool):
        enforce_connectivity = datatypes.Bool(enforce_connectivity)
    if isinstance(min_size_factor, (float, int)):
        min_size_factor = datatypes.Float(min_size_factor)
    if isinstance(min_size_factor, datatypes.Int):
        min_size_factor = datatypes.Float(min_size_factor.value)
    if isinstance(max_size_factor, float):
        max_size_factor = datatypes.Float(max_size_factor)
    if isinstance(max_size_factor, datatypes.Int):
        max_size_factor = datatypes.Float(max_size_factor.value)
    if isinstance(use_slic_zero, bool):
        use_slic_zero = datatypes.Bool(use_slic_zero)
    if isinstance(start_label, int):
        start_label = datatypes.Int(start_label)
    if isinstance(channel_axis, int):
        channel_axis = datatypes.Int(channel_axis)
    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)


    input_data = {
        "image": image,
        "num_segments": num_segments,
        "compactness": compactness,
        "max_iterations": max_iterations,
        "sigma": sigma,
        "enforce_connectivity": enforce_connectivity,
        "min_size_factor": min_size_factor,
        "max_size_factor": max_size_factor,
        "use_slic_zero": use_slic_zero,
        "start_label": start_label,
        "channel_axis": channel_axis,
        "image_id": image_id,
        "spacing": spacing,
        "convert_to_lab": convert_to_lab,
        "mask": mask,
    }

    optional_parameters = ["spacing", "convert_to_lab", "mask"]
    for optional_parameter in optional_parameters:
        if input_data[optional_parameter] is None:
            input_data.pop(optional_parameter)

    end_point = "segment_image_using_slic_superpixel"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


# Superpixel Filter Functions


def filter_segments_by_area(
    image: datatypes.Image | np.ndarray,
    labels: datatypes.Image | np.ndarray,
    min_area: datatypes.Int | int = 20,
    max_area: datatypes.Int | int = 1000,
    image_id: datatypes.Int | int = 0,
) -> Dict[str, Any]:
    """
    Filter superpixels based on area.

    Removes superpixels whose area falls outside the specified minimum and
    maximum bounds.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W, 3).
        labels (datatypes.Image | np.ndarray): Label image containing superpixel
            assignments.
        min_area (datatypes.Int | int): Minimum area threshold. Default: 20.
        max_area (datatypes.Int | int): Maximum area threshold. Default: 1000.
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Filtered results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If labels is not an Image object or np.ndarray.
        TypeError: If min_area or max_area is not an Int object or int.
        TypeError: If image_id is not an Int object or int.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if isinstance(labels, np.ndarray):
        labels = datatypes.Image(image=labels)
    if not isinstance(labels, datatypes.Image):
        raise TypeError(
            f"labels must be an Image object or np.ndarray, class received: {type(labels).__name__}"
        )
    if not isinstance(min_area, (datatypes.Int, int)):
        raise TypeError(
            f"min_area must be an Int object or int, class received: {type(min_area).__name__}"
        )
    if not isinstance(max_area, (datatypes.Int, int)):
        raise TypeError(
            f"max_area must be an Int object or int, class received: {type(max_area).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )

    if isinstance(min_area, int):
        min_area = datatypes.Int(min_area)
    if isinstance(max_area, int):
        max_area = datatypes.Int(max_area)
    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)

    input_data = {
        "image": image,
        "labels": labels,
        "min_area": min_area,
        "max_area": max_area,
        "image_id": image_id,
    }

    end_point = "filter_segments_by_area"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


def filter_segments_by_color(
    image: datatypes.Image | np.ndarray,
    labels: datatypes.Image | np.ndarray,
    min_color: datatypes.Float | float = 0.0,
    max_color: datatypes.Float | float = 255.0,
    image_id: datatypes.Int | int = 0
) -> Dict[str, Any]:
    """
    Filter superpixels based on color.

    Removes superpixels whose mean color intensity falls outside the specified
    minimum and maximum bounds.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W, 3).
        labels (datatypes.Image | np.ndarray): Label image containing superpixel
            assignments.
        min_color (datatypes.Float | float): Minimum color intensity.
            Default: 0.0.
        max_color (datatypes.Float | float): Maximum color intensity.
            Default: 255.0.
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Filtered results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If labels is not an Image object or np.ndarray.
        TypeError: If min_color or max_color is not a Float object or float.
        TypeError: If image_id is not an Int object or int.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if isinstance(labels, np.ndarray):
        labels = datatypes.Image(image=labels)
    if not isinstance(labels, datatypes.Image):
        raise TypeError(
            f"labels must be an Image object or np.ndarray, class received: {type(labels).__name__}"
        )
    if not isinstance(min_color, (datatypes.Float, float, datatypes.Int, int)):
        raise TypeError(
            f"min_color must be a Float object or float, class received: {type(min_color).__name__}"
        )
    if not isinstance(max_color, (datatypes.Float, float, datatypes.Int, int)):
        raise TypeError(
            f"max_color must be a Float object or float, class received: {type(max_color).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )

    if isinstance(min_color, (float, int)):
        min_color = datatypes.Float(min_color)
    if isinstance(min_color, datatypes.Int):
        min_color = datatypes.Float(min_color.value)
    if isinstance(max_color, (float, int)):
        max_color = datatypes.Float(max_color)
    if isinstance(max_color, datatypes.Int):
        max_color = datatypes.Float(max_color.value)
    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)

    input_data = {
        "image": image,
        "labels": labels,
        "min_color": min_color,
        "max_color": max_color,
        "image_id": image_id
    }

    end_point = "filter_segments_by_color"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


def filter_segments_by_mask(
    image: datatypes.Image | np.ndarray,
    labels: datatypes.Image | np.ndarray,
    mask: datatypes.Image | np.ndarray,
    image_id: datatypes.Int | int = 0
) -> Dict[str, Any]:
    """
    Filter superpixels based on a mask.

    Keeps only superpixels that overlap with the provided binary mask.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W, 3).
        labels (datatypes.Image | np.ndarray): Label image containing superpixel
            assignments.
        mask (datatypes.Image | np.ndarray): Binary mask image.
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Filtered results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If labels is not an Image object or np.ndarray.
        TypeError: If mask is not an Image object or np.ndarray.
        TypeError: If image_id is not an Int object or int.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if isinstance(labels, np.ndarray):
        labels = datatypes.Image(image=labels)
    if not isinstance(labels, datatypes.Image):
        raise TypeError(
            f"labels must be an Image object or np.ndarray, class received: {type(labels).__name__}"
        )
    if isinstance(mask, np.ndarray):
        mask = datatypes.Image(image=mask)
    if not isinstance(mask, datatypes.Image):
        raise TypeError(
            f"mask must be an Image object or np.ndarray, class received: {type(mask).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )

    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)

    input_data = {
        "image": image,
        "labels": labels,
        "mask": mask,
        "image_id": image_id,
    }

    end_point = "filter_segments_by_mask"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


# Graph Functions


def segment_image_using_grab_cut(
    image: datatypes.Image | np.ndarray,
    bbox: Optional[List[int]] | datatypes.Boxes2D | np.ndarray = None,
    num_iterations: datatypes.Int | int = 5,
    image_id: datatypes.Int | int = 0
) -> Dict[str, Any]:
    """
    Perform GrabCut segmentation.

    Uses the GrabCut algorithm for interactive foreground extraction based on
    an initial bounding box or mask.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W, 3).
        bbox (Optional[List[int]] | datatypes.Boxes2D | np.ndarray): Initial
            bounding box [x, y, w, h]. Default: None.
        num_iterations (datatypes.Int | int): Number of iterations. Default: 5.
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Segmentation results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If num_iterations is not an Int object or int.
        TypeError: If bbox is not a list, Boxes2D, np.ndarray, or None.
        TypeError: If image_id is not an Int object or int.
        TypeError: If bbox array format is not 'XYWH'.
        ValueError: If bbox list does not have 4 elements.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(num_iterations, (datatypes.Int, int)):
        raise TypeError(
            f"num_iterations must be an Int object or int, class received: {type(num_iterations).__name__}"
        )
    if bbox is not None and not isinstance(bbox, (list, datatypes.Boxes2D, np.ndarray)):
        raise TypeError(
            f"bbox must be a list, datatypes.Boxes2D, np.ndarray, or None, class received: {type(bbox).__name__}"
        )
    if isinstance(bbox, list) and len(bbox) != 4:
        raise ValueError(
            f"bbox must have 4 elements [x, y, w, h], got {len(bbox)}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )

    if isinstance(num_iterations, int):
        num_iterations = datatypes.Int(num_iterations)
    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)
    if isinstance(bbox, (list, np.ndarray)):
        bbox = datatypes.Boxes2D(arrays=bbox, array_format="XYWH")
    if bbox is not None and bbox.array_format.value != "XYWH":
        raise TypeError(
            (f"Parameter bboxes has to be a list of Boxes2D with array format 'XYWH', given was {bbox.array_format.value}."
             " Please use parameter array_format when creating Boxes2D")
        )

    input_data = {
        "image": image,
        "num_iterations": num_iterations,
        "image_id": image_id,
        "bbox": bbox,
    }

    optional_parameters = ["bbox"]
    for optional_parameter in optional_parameters:
        if input_data[optional_parameter] is None:
            input_data.pop(optional_parameter)

    end_point = "segment_image_using_grab_cut"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data['annotation']


# Deep Learning Functions


def segment_image_using_foreground_birefnet(
    image: datatypes.Image | np.ndarray,
    input_height: datatypes.Int | int = 1024,
    input_width: datatypes.Int | int = 1024,
    threshold: datatypes.Int | int = 0,
    image_id: datatypes.Int | int = 0,
) -> Dict[str, Any]:
    """
    Segment the foreground using BiRefNet.

    Uses the BiRefNet deep learning model for high-quality foreground/background
    segmentation, particularly effective for salient object detection.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W, 3).
        input_height (datatypes.Int | int): Image height for model input.
            Default: 1024.
        input_width (datatypes.Int | int): Image width for model input.
            Default: 1024.
        threshold (datatypes.Int | int): Pixel value threshold for binarization.
            Default: 0.
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Segmentation results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If input_height, input_width, or threshold is not an Int
            object or int.
        TypeError: If image_id is not an Int object or int.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(input_height, (datatypes.Int, int)):
        raise TypeError(
            f"input_height must be an Int object or int, class received: {type(input_height).__name__}"
        )
    if not isinstance(input_width, (datatypes.Int, int)):
        raise TypeError(
            f"input_width must be an Int object or int, class received: {type(input_width).__name__}"
        )
    if not isinstance(threshold, (datatypes.Int, int)):
        raise TypeError(
            f"threshold must be an Int object or int, class received: {type(threshold).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )

    if isinstance(input_height, int):
        input_height = datatypes.Int(input_height)
    if isinstance(input_width, int):
        input_width = datatypes.Int(input_width)
    if isinstance(threshold, int):
        threshold = datatypes.Int(threshold)
    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)

    input_data = {
        "image": image,
        "input_height": input_height,
        "input_width": input_width,
        "threshold": threshold,
        "image_id": image_id,
    }

    end_point = "segment_image_using_foreground_birefnet"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]


def segment_image_using_sam(
    image: datatypes.Image | np.ndarray,
    bboxes: List[List[int]] | datatypes.Boxes2D,
    threshold: datatypes.Float | float = 0.5,
    image_id: datatypes.Int | int = 0,
) -> Dict[str, Any]:
    """
    Perform segmentation using SAM (Segment Anything Model).

    Uses the Segment Anything Model to generate precise segmentation masks
    for objects specified by bounding boxes.

    Args:
        image (datatypes.Image | np.ndarray): Input image (H, W, 3) or (H, W, 4).
        bboxes (List[List[int]] | datatypes.Boxes2D): List of bounding boxes
            [[x1_min, y1_min, x1_max, y1_max], ...] in XYXY format.
        threshold (datatypes.Float | float): Threshold for mask binarization in the probability map. 
            Default: 0.5.
        image_id (datatypes.Int | int): Image identifier for COCO format.
            Default: 0.

    Returns:
        Dict[str, Any]: Segmentation results in COCO panoptic format.

    Raises:
        TypeError: If image is not an Image object or np.ndarray.
        TypeError: If bboxes is not a list or Boxes2D.
        TypeError: If bboxes is a list but elements are not lists.
        TypeError: If bboxes array format is not 'XYXY'.
        TypeError: If threshold is not a Float object or float.
        TypeError: If image_id is not an Int object or int.
    """
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    if not isinstance(image, datatypes.Image):
        raise TypeError(
            f"image must be an Image object or np.ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(bboxes, (list, datatypes.Boxes2D)):
        raise TypeError(
            f"bboxes must be a list or Boxes2D, class received: {type(bboxes).__name__}"
        )
    if isinstance(bboxes, list) and len(bboxes) > 0 and not isinstance(bboxes[0], list):
        raise TypeError(
            f"If bboxes is of type python list, then its elements have to be list also, class received: {type(bboxes[0]).__name__}"
        )
    if not isinstance(threshold, (datatypes.Float, float)):
        raise TypeError(
            f"threshold must be a Float object or float, class received: {type(threshold).__name__}"
        )
    if not isinstance(image_id, (datatypes.Int, int)):
        raise TypeError(
            f"image_id must be an Int object or int, class received: {type(image_id).__name__}"
        )

    if isinstance(bboxes, list):
        box2d_list = []
        for bbox in bboxes:
            box2d_list.append(bbox)
        bboxes = datatypes.Boxes2D(arrays=box2d_list, array_format="XYXY")

    if bboxes.array_format.value != "XYXY":
        raise TypeError(
            (f"Parameter bboxes has to have array format 'XYXY', given was { bboxes.array_format.value}."
                "Please use parameter array_format when creating Boxes2D")
        )
    if isinstance(threshold, (float, int)):
        threshold = datatypes.Float(threshold)
    
    if isinstance(image_id, int):
        image_id = datatypes.Int(image_id)

    input_data = {
        "image": image,
        "bboxes": bboxes,
        "threshold": threshold,
        "image_id": image_id,
    }

    end_point = "segment_image_using_sam"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["annotation"]
