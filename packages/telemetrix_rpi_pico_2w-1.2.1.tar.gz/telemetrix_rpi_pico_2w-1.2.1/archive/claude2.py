"""
Minimal example of using Telemetrix over BLE
"""

import time
from telemetrix_rpi_pico_2w_ble import TelemetrixRpiPico2wBle


def on_data_received(sender, data):
    """Called when data arrives from the Pico"""
    print(f"<< Received: {list(data)}")


# Create and connect
print("Connecting to Pico...")
board = TelemetrixRpiPico2wBle("Tmx4Pico2W", receive_callback=on_data_received)

if board.connect():
    print("Connected!\n")

    # Send some test commands
    print(">> Sending: [1, 62]")
    board.write([1, 62])
    time.sleep(1)

    print(">> Sending: [1, 62]")
    board.write([1, 62])
    time.sleep(1)

    print(">> Sending: [1, 62]")
    board.write([1, 62])
    time.sleep(1)

    # Disconnect
    board.disconnect()
    print("\nDone!")
else:
    print("Failed to connect!")