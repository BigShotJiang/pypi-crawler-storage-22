import time

# s = input("Eval: ")
# b = s.encode("utf-8")
x = [0x44, 0x45, 0x46]
y = bytes(x)

time.sleep(1)
print(s)