"""
Example usage of TelemetrixBle with synchronous API
Works in both regular Python and Jupyter notebooks
"""

from telemetrix_ble import TelemetrixBle


def notification_handler(sender, data):
    """
    Callback function to handle received BLE notifications
    
    :param sender: The characteristic that sent the notification
    :param data: The received data bytes
    """
    print(f"Received data from {sender}: {data}")


def example_basic_usage():
    """Basic usage example"""
    # Create the BLE client
    ble = TelemetrixBle(
        ble_device_name="MyPico2W",
        receive_notification_callback=notification_handler
    )
    
    try:
        # Connect to device (synchronous call)
        ble.connect()
        print("Connected successfully!")
        
        # Write some data (synchronous call)
        data_to_send = b"Hello, Pico!"
        ble.write(data_to_send)
        print(f"Sent: {data_to_send}")
        
        # Keep connection alive for a bit to receive notifications
        import time
        time.sleep(2)
        
    finally:
        # Disconnect (synchronous call)
        ble.disconnect()
        print("Disconnected")


def example_context_manager():
    """Usage with context manager (recommended)"""
    with TelemetrixBle("MyPico2W", notification_handler) as ble:
        # Send multiple messages
        for i in range(5):
            ble.write(f"Message {i}".encode())
            import time
            time.sleep(0.5)


def example_jupyter_compatible():
    """
    This same code works in Jupyter notebooks!
    
    The key difference from the async version is that all methods
    are synchronous, but internally they use the bleak async library
    running in a separate thread.
    """
    ble = TelemetrixBle("MyPico2W", notification_handler)
    
    # All these calls work synchronously in Jupyter
    ble.connect()
    ble.write(b"Test from Jupyter")
    
    # You can even mix with other Jupyter operations
    import time
    for i in range(3):
        ble.write(f"Count: {i}".encode())
        time.sleep(1)
        # Do other Jupyter work here
        print(f"Iteration {i} complete")
    
    ble.disconnect()


if __name__ == "__main__":
    print("Example 1: Basic usage")
    print("-" * 50)
    example_basic_usage()
    
    print("\n\nExample 2: Context manager usage")
    print("-" * 50)
    example_context_manager()
