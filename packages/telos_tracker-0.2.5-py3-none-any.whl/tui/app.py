"""Main Textual TUI application."""

import asyncio
from datetime import datetime
from typing import Optional, List, Dict, Any
from textual.app import App, ComposeResult
from textual.reactive import reactive

from utils.config_manager import ConfigManager
from tui.workers import capture_worker_task, db_polling_worker
from tui.workers.session_worker import session_worker_task
from tui.screens import (
    DashboardScreen, TimelineScreen, SummaryScreen, SettingsScreen, ChatScreen,
    HelpScreen, UpgradeScreen, WelcomeProScreen, GettingStartedScreen,
    SplashScreen
)
from tui.widgets import TrialBanner
from core.trial_manager import TrialManager


class TelosApp(App):
    """Main TUI application for Telos."""

    # Reactive properties - state that auto-updates UI
    # Capture loop status
    loop_status: reactive[str] = reactive("stopped")
    idle_seconds: reactive[int] = reactive(0)
    error_message: reactive[str] = reactive("")

    # Current activity
    current_category: reactive[str] = reactive("idle")
    current_emoji: reactive[str] = reactive("💤")
    current_color: reactive[str] = reactive("#95a5a6")
    current_app: reactive[str] = reactive("None")
    current_window_title: reactive[str] = reactive("No window")  # Raw window title (instant)
    current_task: reactive[str] = reactive("No activity")
    last_analysis_source: reactive[str] = reactive("none")  # backend, local, none
    activity_start_time: reactive[Optional[datetime]] = reactive(None)

    # Today's stats (in seconds)
    total_captures: reactive[int] = reactive(0)
    work_seconds: reactive[int] = reactive(0)
    learning_seconds: reactive[int] = reactive(0)
    browsing_seconds: reactive[int] = reactive(0)
    entertainment_seconds: reactive[int] = reactive(0)
    idle_seconds_total: reactive[int] = reactive(0)

    # API quota
    api_calls_used: reactive[int] = reactive(0)

    # Styling for the application
    CSS = """
    #session-table {
        width: 60%;
        height: 100%;
    }
    #detail-panel {
        width: 40%;
        height: 100%;
        border-left: solid #333;
        padding: 1 2;
        background: #1a1a1a;
    }
    #detail-title {
        color: #ffaa00;
        text-style: bold;
        margin-bottom: 1;
        border-bottom: solid #333;
    }
    #detail-content {
        color: #ddd;
        overflow-y: scroll;
    }
    """

    # Recent captures (list of dicts)
    recent_captures: reactive[List[Dict[str, Any]]] = reactive([])

    # Phase 3: Session tracking
    sessions_today: reactive[int] = reactive(0)
    daily_productivity_score: reactive[float] = reactive(0.0)

    BINDINGS = [
        ("d", "show_dashboard", "Dashboard"),
        ("t", "show_timeline", "Timeline"),
        ("s", "show_summary", "Summary"),
        ("c", "show_settings", "Settings"),
        ("a", "show_chat", "AI Chat"),
        ("h", "show_help", "Help"),
        ("q", "quit", "Quit"),
        ("f", "show_feedback", "Feedback"),
    ]

    def __init__(self, config: ConfigManager):
        """Initialize the TUI application.

        Args:
            config: Configuration manager instance
        """
        super().__init__()
        self.config = config

        # Store max API calls as regular attribute (not reactive)
        self.api_calls_max = config.get('capture', 'max_daily_requests', default=1500)

        # Worker shutdown flag and task handles
        self.shutting_down = False
        self.capture_worker = None
        self.db_worker = None
        self.session_worker = None
        self.email_worker_task = None
        self.firestore_sync_worker_task = None
        
        # Trial manager
        self.trial_manager = TrialManager(config, trial_duration_days=7)
        self.trial_banner = None

    def on_mount(self) -> None:
        """Called when app is mounted - show splash then start."""
        self.title = "Telos"
        self.sub_title = "Live Activity Dashboard"

        # Show splash screen while the app initializes
        self.push_screen(SplashScreen())

        # After a brief moment, replace splash with dashboard and start workers
        self.set_timer(2.5, self._finish_startup)

    def _finish_startup(self) -> None:
        """Transition from splash to dashboard and start workers."""
        # Pop the splash screen and push dashboard
        self.pop_screen()
        self.push_screen(DashboardScreen())

        # Show the Getting Started overlay on the very first launch after
        # onboarding — helps users know what happens next and promotes MCP.
        self._maybe_show_getting_started()

        # Sync account status from backend (non-blocking, best effort)
        backend_enabled = self.config.get('backend', 'enabled', default=False)
        if backend_enabled:
            try:
                backend_url = self.config.get('backend', 'url')
                firebase_api_key = self.config.get('firebase', 'api_key')
                if backend_url and firebase_api_key:
                    self.trial_manager.refresh_account_status(backend_url, firebase_api_key)
            except Exception as e:
                print(f"[APP] Failed to sync account status: {e}")
        
        # Show one-time Pro welcome screen if user just upgraded
        show_pro_welcome = self.config.config.get('account', {}).get('show_pro_welcome', False)
        if show_pro_welcome and self.trial_manager.is_pro():
            self.set_timer(1.5, lambda: self.push_screen(WelcomeProScreen()))
        
        # Check if trial is expired - enforce restrictions
        is_expired = self.trial_manager.is_trial_expired()
        
        # Check for upgrade prompts (skip if Pro)
        if not self.trial_manager.is_pro():
            prompt_type = self.trial_manager.should_show_upgrade_prompt()
            if prompt_type or is_expired:
                self.set_timer(2, lambda: self.push_screen(UpgradeScreen(self.trial_manager)))

        # Only start workers if trial is active or user is Pro
        if is_expired:
            self.notify(
                "Trial expired. Tracking disabled. Upgrade to continue.",
                severity="warning",
                timeout=10
            )
            # Show subtle post-expiry nudge on every 3rd launch
            post_expiry_nudge = self.trial_manager.get_post_expiry_nudge()
            if post_expiry_nudge:
                self.set_timer(5, lambda: self.notify(
                    post_expiry_nudge, severity="information", timeout=8
                ))
            return  # Don't start workers

        # Start background workers
        self.capture_worker = asyncio.create_task(capture_worker_task(self))
        self.db_worker = asyncio.create_task(db_polling_worker(self))
        self.session_worker = asyncio.create_task(session_worker_task(self))

        # Start local web dashboard server
        try:
            from core.dashboard_server import DashboardServer
            db_path = self.config.get('storage', 'database_path')
            dashboard_port = self.config.get('dashboard', 'port', default=5555)
            self.dashboard_server = DashboardServer(db_path, port=int(dashboard_port))
            self.dashboard_server.start()
        except Exception as e:
            print(f"[APP] Dashboard server failed to start: {e}")
        
        # Start email worker if enabled
        email_enabled = self.config.get('email', 'enabled', default=False)
        if email_enabled:
            from tui.workers.email_worker import EmailWorker
            from core.email_reporter import EmailReporter
            from core.database import Database
            from core.analyzer import GeminiAnalyzer
            from core.goal_manager import AnalysisGoalManager
            from core.daily_aggregator import DailyAggregator
            
            # Initialize components for email worker
            db = Database(self.config.get('storage', 'database_path'))
            analyzer = GeminiAnalyzer(
                self.config.get('gemini', 'api_key'),
                self.config.get('gemini', 'model'),
                user_email=self.config.get('account', 'email', default=None)
            )
            goal_manager = AnalysisGoalManager(db)
            daily_aggregator = DailyAggregator(db, analyzer, goal_manager)
            email_reporter = EmailReporter(
                smtp_host=self.config.get('email', 'smtp_host'),
                smtp_port=self.config.get('email', 'smtp_port'),
                sender_email=self.config.get('email', 'sender_email'),
                sender_password=self.config.get('email', 'sender_password'),
                recipient_email=self.config.get('email', 'recipient_email')
            )
            
            email_worker = EmailWorker(
                db=db,
                daily_aggregator=daily_aggregator,
                email_reporter=email_reporter,
                send_time=self.config.get('email', 'send_time', default='21:00')
            )
            self.email_worker_task = asyncio.create_task(email_worker.start())

        # Start Firestore sync worker if backend is enabled
        if backend_enabled:
            from core.firestore_sync import FirestoreSync
            from core.database import Database
            from core.firebase_auth import FirebaseAuth

            # Initialize components for Firestore sync
            db = Database(self.config.get('storage', 'database_path'))
            firebase_api_key = self.config.get('firebase', 'api_key')
            firebase_project_id = self.config.get('firebase', 'project_id', default='gen-lang-client-0772617718')

            firebase_auth = FirebaseAuth(firebase_api_key)

            # Store firestore_sync as instance variable for status checks
            self.firestore_sync = FirestoreSync(
                db=db,
                firebase_auth=firebase_auth,
                firebase_project_id=firebase_project_id,
                # Default: 4-hour interval for reliable email data availability
            )
            self.firestore_sync_worker_task = asyncio.create_task(self.firestore_sync.start())
            print("[APP] Firestore sync worker started (4-hour interval)")

    async def on_unmount(self) -> None:
        """Called when app is being unmounted (shutdown)."""
        self.shutting_down = True

        # Cancel workers if they're still running
        if self.capture_worker and not self.capture_worker.done():
            self.capture_worker.cancel()
            try:
                await self.capture_worker
            except asyncio.CancelledError:
                pass

        if self.db_worker and not self.db_worker.done():
            self.db_worker.cancel()
            try:
                await self.db_worker
            except asyncio.CancelledError:
                pass

        if self.session_worker and not self.session_worker.done():
            self.session_worker.cancel()
            try:
                await self.session_worker
            except asyncio.CancelledError:
                pass
        
        if self.email_worker_task and not self.email_worker_task.done():
            self.email_worker_task.cancel()
            try:
                await self.email_worker_task
            except asyncio.CancelledError:
                pass

        if self.firestore_sync_worker_task and not self.firestore_sync_worker_task.done():
            self.firestore_sync_worker_task.cancel()
            try:
                await self.firestore_sync_worker_task
            except asyncio.CancelledError:
                pass

    # ------------------------------------------------------------------
    # Getting Started overlay (shown once after onboarding)
    # ------------------------------------------------------------------

    def _maybe_show_getting_started(self) -> None:
        """Show the Getting Started overlay on the first launch after
        onboarding.  Uses a flag file so it only fires once."""
        from pathlib import Path

        flag = Path.home() / ".telos" / ".getting_started_shown"
        onboarding_done = Path.home() / ".telos" / "onboarding_complete"

        if onboarding_done.exists() and not flag.exists():
            # Create the flag immediately so it won't show again
            try:
                flag.touch()
            except OSError:
                pass

            def _handle_gs_result(result):
                if result == "chat":
                    self.action_show_chat()

            self.set_timer(1.0, lambda: self.push_screen(
                GettingStartedScreen(), _handle_gs_result
            ))

    def action_show_dashboard(self) -> None:
        """Show the dashboard screen."""
        self.switch_screen(DashboardScreen())

    def action_show_timeline(self) -> None:
        """Show the timeline screen."""
        self.push_screen(TimelineScreen())

    def action_show_summary(self) -> None:
        """Show the summary screen."""
        self.push_screen(SummaryScreen())

    def action_show_settings(self) -> None:
        """Show the settings screen."""
        self.push_screen(SettingsScreen())

    def action_show_chat(self) -> None:
        """Show the AI chat screen."""
        self.push_screen(ChatScreen())
    
    def action_show_help(self) -> None:
        """Show the help screen."""
        self.push_screen(HelpScreen())
    
    def action_show_feedback(self) -> None:
        """Show feedback modal from any screen."""
        from tui.screens.feedback_modal import FeedbackModal
        from typing import Optional
        
        # Get current screen for context
        current_screen = self.screen
        screen_name = current_screen.__class__.__name__.replace('Screen', '').lower()
        
        context = {
            'type': 'general',
            'screen': screen_name,
        }
        
        def handle_feedback(result: Optional[str]) -> None:
            """Handle feedback submission."""
            if not result or not result.strip():
                return
            
            # Check if backend is enabled
            backend_enabled = self.config.get('backend', 'enabled', default=False)
            
            if not backend_enabled:
                self.notify(
                    "Feedback collected but backend not configured.",
                    severity="warning",
                    timeout=5
                )
                return
            
            # Submit feedback - delegate to current screen if it has the method
            if hasattr(current_screen, '_submit_feedback_async'):
                current_screen.run_worker(current_screen._submit_feedback_async(result.strip(), context))
            else:
                self.notify(
                    "Feedback submitted (no handler on this screen)",
                    severity="information",
                    timeout=3
                )
        
        try:
            self.push_screen(FeedbackModal(context), handle_feedback)
        except Exception as e:
            self.notify(
                f"Error opening feedback modal: {str(e)}",
                severity="error",
                timeout=5
            )
