# temp_text

## usage

```python
from time import sleep

import temp_text

for i in range(100):
    if i % 10 == 0:
        print(f"Found special number: {i}")
    temp_text.prnt(f"Looking at {i}")
    sleep(0.3)
```

```python
from time import sleep
from itertools import *

import temp_text

for c in chain.from_iterable(tee("-\\|/", 10)):
    temp_text.prnt(c)
    sleep(0.3)
```

```python
import os

import temp_text

for d, _, _ in os.walk("/"):
    temp_text.prnt(d)
```

## description

A simple package to allow for text on the terminal which is
overwritten by the next call to print.

## prnt

Print a temporary string to the console.
Must not contain newline characters, because
only the line the cursor is currently on is cleared.
This function calls hide if there is a temporary string
on the console.

If trim_to_width is True (this is the default), then
the string has some characters in the middle replaced with
ellipsis so it does not span multiple lines.

## hide

Clears the line the cursor is currently on
if there is a temporary string there.

Hide is also called if the program exits.

## use_write_guards

If this setting is True (this is the default) then 
calling regular print (or any other function that invokes
sys.stdout.write or sys.stderr.write) first clears the current
line, assuming there is a temporary string there.

```python
import temp_text
temp_text.use_write_guards = False
temp_text.prnt("Hello, World")
# Output: "Hello, World"
print("Hello, World!")
# Output: "Hello, WorldHello, World!"
# If you inserted a temp_text.hide() before the print,
# then the output would be the expected "Hello, World!"
# use_write_guards = True does this automatically
```