import atexit
import os
import sys

import colorama.ansi

_right_padding: int = 20
_temp_string: bool = False
use_write_guards: bool = True


def _trim_to_terminal_width(string: str) -> str:
    string = str(string)
    try:
        terminal_width = os.get_terminal_size().columns - _right_padding
    except OSError:
        return string

    if len(string) <= terminal_width:
        return string

    return string[:terminal_width // 2 - 3] + "..." + string[len(string) - terminal_width // 2:]


class _WriteGuard:
    def __init__(self, original):
        self.original = original

    def __call__(self, *args, **kwargs):
        assert _temp_string
        hide()
        self.original(*args, **kwargs)


def _install_write_guard(name):
    stream = getattr(sys, name)
    stream.write = _WriteGuard(stream.write)


def _uninstall_write_guard(name):
    stream = getattr(sys, name)
    if isinstance(stream.write, _WriteGuard):
        setattr(stream, "write", stream.write.original)


def prnt(string: str, trim_to_width: bool = True):
    """Print a temporary string to the console"""
    hide()
    global _temp_string
    _temp_string = True
    if trim_to_width:
        string = _trim_to_terminal_width(string)
    print(string, end="", flush=True)

    if use_write_guards:
        _install_write_guard("stdout")
        _install_write_guard("stderr")


def hide():
    """Remove the current temporary string from the console"""
    global _temp_string
    if not _temp_string:
        return
    _temp_string = False

    if use_write_guards:
        _uninstall_write_guard("stdout")
        _uninstall_write_guard("stderr")

    print(colorama.ansi.clear_line() + "\r", end="", flush=True)


atexit.register(hide)