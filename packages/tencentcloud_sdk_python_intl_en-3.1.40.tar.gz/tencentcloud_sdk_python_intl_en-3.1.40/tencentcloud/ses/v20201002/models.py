# -*- coding: utf8 -*-
# Copyright (c) 2017-2025 Tencent. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import warnings

from tencentcloud.common.abstract_model import AbstractModel


class AddressUnsubscribeConfigData(AbstractModel):
    r"""Address-Level unsubscribe configuration.

    """

    def __init__(self):
        r"""
        :param _Address: Sender address.
        :type Address: str
        :param _UnsubscribeConfig: Unsubscription link option 0: do not include unsubscription link 1: simplified chinese 2: english 3: traditional chinese 4: spanish 5: french 6: german 7: japanese 8: korean 9: arabic 10: thai.
        :type UnsubscribeConfig: str
        :param _Status: 0: disabled; 1: enabled.
        :type Status: int
        """
        self._Address = None
        self._UnsubscribeConfig = None
        self._Status = None

    @property
    def Address(self):
        r"""Sender address.
        :rtype: str
        """
        return self._Address

    @Address.setter
    def Address(self, Address):
        self._Address = Address

    @property
    def UnsubscribeConfig(self):
        r"""Unsubscription link option 0: do not include unsubscription link 1: simplified chinese 2: english 3: traditional chinese 4: spanish 5: french 6: german 7: japanese 8: korean 9: arabic 10: thai.
        :rtype: str
        """
        return self._UnsubscribeConfig

    @UnsubscribeConfig.setter
    def UnsubscribeConfig(self, UnsubscribeConfig):
        self._UnsubscribeConfig = UnsubscribeConfig

    @property
    def Status(self):
        r"""0: disabled; 1: enabled.
        :rtype: int
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status


    def _deserialize(self, params):
        self._Address = params.get("Address")
        self._UnsubscribeConfig = params.get("UnsubscribeConfig")
        self._Status = params.get("Status")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class Attachment(AbstractModel):
    r"""Attachment structure, including attachment name and Base64-encoded attachment content

    """

    def __init__(self):
        r"""
        :param _FileName: Attachment name, which cannot exceed 255 characters. Some attachment types are not supported. For details, see [Attachment Types](https://intl.cloud.tencent.com/document/product/1288/51951?from_cn_redirect=1).
        :type FileName: str
        :param _Content: The Base64-encoded attachment content supports a maximum of 4M. note: tencent cloud API supports up to 8M request packets. the attachment content is expected to expand by 1.5 times after Base64 encoding. you should control the total size of all attachments within 4M. the API will return an error if the overall request exceeds 8M.
        :type Content: str
        :param _FileURL: Attachment URL. do not use the open function.
        :type FileURL: str
        """
        self._FileName = None
        self._Content = None
        self._FileURL = None

    @property
    def FileName(self):
        r"""Attachment name, which cannot exceed 255 characters. Some attachment types are not supported. For details, see [Attachment Types](https://intl.cloud.tencent.com/document/product/1288/51951?from_cn_redirect=1).
        :rtype: str
        """
        return self._FileName

    @FileName.setter
    def FileName(self, FileName):
        self._FileName = FileName

    @property
    def Content(self):
        r"""The Base64-encoded attachment content supports a maximum of 4M. note: tencent cloud API supports up to 8M request packets. the attachment content is expected to expand by 1.5 times after Base64 encoding. you should control the total size of all attachments within 4M. the API will return an error if the overall request exceeds 8M.
        :rtype: str
        """
        return self._Content

    @Content.setter
    def Content(self, Content):
        self._Content = Content

    @property
    def FileURL(self):
        r"""Attachment URL. do not use the open function.
        :rtype: str
        """
        return self._FileURL

    @FileURL.setter
    def FileURL(self, FileURL):
        self._FileURL = FileURL


    def _deserialize(self, params):
        self._FileName = params.get("FileName")
        self._Content = params.get("Content")
        self._FileURL = params.get("FileURL")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class BatchSendEmailRequest(AbstractModel):
    r"""BatchSendEmail request structure.

    """

    def __init__(self):
        r"""
        :param _FromEmailAddress: Sender'S email address. please fill in the sender's email address, such as noreply@mail.qcloud.com. if you need to fill in the sender's description, please follow.
Sender &lt;email address&gt; via fill in, such as:.
Tencent cloud team &lt;noreply@mail.qcloud.com&gt;.
        :type FromEmailAddress: str
        :param _ReceiverId: Recipient list ID.
        :type ReceiverId: int
        :param _Subject: Email subject.
        :type Subject: str
        :param _TaskType: Task type 1: send now 2: scheduled sending 3: cycle (frequency) sending.
        :type TaskType: int
        :param _ReplyToAddresses: The "reply" email address of the mail. can be filled with an email address you can receive mail from, can be a personal mailbox. if left empty, the recipient's reply mail will fail to send.
        :type ReplyToAddresses: str
        :param _Template: When using a template to send, fill in the related parameters of the template.
<Dx-Alert infotype="notice" title="note">this field must be specified if you have not applied for special configuration.</dx-alert>.
        :type Template: :class:`tencentcloud.ses.v20201002.models.Template`
        :param _Simple: Abandoned<Dx-Alert infotype="notice" title="description">only customers who historically applied for special configuration require the use of it. if you have not applied for special configuration, this field does not exist.</dx-alert>.
        :type Simple: :class:`tencentcloud.ses.v20201002.models.Simple`
        :param _Attachments: Send attachment when required. fill in related parameters (not supported).
        :type Attachments: list of Attachment
        :param _CycleParam: Required parameter for sending tasks periodically.
        :type CycleParam: :class:`tencentcloud.ses.v20201002.models.CycleEmailParam`
        :param _TimedParam: Required parameter for scheduled task assignment.
        :type TimedParam: :class:`tencentcloud.ses.v20201002.models.TimedEmailParam`
        :param _Unsubscribe: Unsubscription link options 0: do not add 1: english 2: simplified chinese 3: traditional chinese 4: spanish 5: french 6: german 7: japanese 8: korean 9: arabic 10: thai.
        :type Unsubscribe: str
        :param _ADLocation: Whether to add an ad flag. valid values: 0 (do not add), 1 (add to the previous subject), 2 (add to the following subject).
        :type ADLocation: int
        """
        self._FromEmailAddress = None
        self._ReceiverId = None
        self._Subject = None
        self._TaskType = None
        self._ReplyToAddresses = None
        self._Template = None
        self._Simple = None
        self._Attachments = None
        self._CycleParam = None
        self._TimedParam = None
        self._Unsubscribe = None
        self._ADLocation = None

    @property
    def FromEmailAddress(self):
        r"""Sender'S email address. please fill in the sender's email address, such as noreply@mail.qcloud.com. if you need to fill in the sender's description, please follow.
Sender &lt;email address&gt; via fill in, such as:.
Tencent cloud team &lt;noreply@mail.qcloud.com&gt;.
        :rtype: str
        """
        return self._FromEmailAddress

    @FromEmailAddress.setter
    def FromEmailAddress(self, FromEmailAddress):
        self._FromEmailAddress = FromEmailAddress

    @property
    def ReceiverId(self):
        r"""Recipient list ID.
        :rtype: int
        """
        return self._ReceiverId

    @ReceiverId.setter
    def ReceiverId(self, ReceiverId):
        self._ReceiverId = ReceiverId

    @property
    def Subject(self):
        r"""Email subject.
        :rtype: str
        """
        return self._Subject

    @Subject.setter
    def Subject(self, Subject):
        self._Subject = Subject

    @property
    def TaskType(self):
        r"""Task type 1: send now 2: scheduled sending 3: cycle (frequency) sending.
        :rtype: int
        """
        return self._TaskType

    @TaskType.setter
    def TaskType(self, TaskType):
        self._TaskType = TaskType

    @property
    def ReplyToAddresses(self):
        r"""The "reply" email address of the mail. can be filled with an email address you can receive mail from, can be a personal mailbox. if left empty, the recipient's reply mail will fail to send.
        :rtype: str
        """
        return self._ReplyToAddresses

    @ReplyToAddresses.setter
    def ReplyToAddresses(self, ReplyToAddresses):
        self._ReplyToAddresses = ReplyToAddresses

    @property
    def Template(self):
        r"""When using a template to send, fill in the related parameters of the template.
<Dx-Alert infotype="notice" title="note">this field must be specified if you have not applied for special configuration.</dx-alert>.
        :rtype: :class:`tencentcloud.ses.v20201002.models.Template`
        """
        return self._Template

    @Template.setter
    def Template(self, Template):
        self._Template = Template

    @property
    def Simple(self):
        r"""Abandoned<Dx-Alert infotype="notice" title="description">only customers who historically applied for special configuration require the use of it. if you have not applied for special configuration, this field does not exist.</dx-alert>.
        :rtype: :class:`tencentcloud.ses.v20201002.models.Simple`
        """
        return self._Simple

    @Simple.setter
    def Simple(self, Simple):
        self._Simple = Simple

    @property
    def Attachments(self):
        r"""Send attachment when required. fill in related parameters (not supported).
        :rtype: list of Attachment
        """
        return self._Attachments

    @Attachments.setter
    def Attachments(self, Attachments):
        self._Attachments = Attachments

    @property
    def CycleParam(self):
        r"""Required parameter for sending tasks periodically.
        :rtype: :class:`tencentcloud.ses.v20201002.models.CycleEmailParam`
        """
        return self._CycleParam

    @CycleParam.setter
    def CycleParam(self, CycleParam):
        self._CycleParam = CycleParam

    @property
    def TimedParam(self):
        r"""Required parameter for scheduled task assignment.
        :rtype: :class:`tencentcloud.ses.v20201002.models.TimedEmailParam`
        """
        return self._TimedParam

    @TimedParam.setter
    def TimedParam(self, TimedParam):
        self._TimedParam = TimedParam

    @property
    def Unsubscribe(self):
        r"""Unsubscription link options 0: do not add 1: english 2: simplified chinese 3: traditional chinese 4: spanish 5: french 6: german 7: japanese 8: korean 9: arabic 10: thai.
        :rtype: str
        """
        return self._Unsubscribe

    @Unsubscribe.setter
    def Unsubscribe(self, Unsubscribe):
        self._Unsubscribe = Unsubscribe

    @property
    def ADLocation(self):
        r"""Whether to add an ad flag. valid values: 0 (do not add), 1 (add to the previous subject), 2 (add to the following subject).
        :rtype: int
        """
        return self._ADLocation

    @ADLocation.setter
    def ADLocation(self, ADLocation):
        self._ADLocation = ADLocation


    def _deserialize(self, params):
        self._FromEmailAddress = params.get("FromEmailAddress")
        self._ReceiverId = params.get("ReceiverId")
        self._Subject = params.get("Subject")
        self._TaskType = params.get("TaskType")
        self._ReplyToAddresses = params.get("ReplyToAddresses")
        if params.get("Template") is not None:
            self._Template = Template()
            self._Template._deserialize(params.get("Template"))
        if params.get("Simple") is not None:
            self._Simple = Simple()
            self._Simple._deserialize(params.get("Simple"))
        if params.get("Attachments") is not None:
            self._Attachments = []
            for item in params.get("Attachments"):
                obj = Attachment()
                obj._deserialize(item)
                self._Attachments.append(obj)
        if params.get("CycleParam") is not None:
            self._CycleParam = CycleEmailParam()
            self._CycleParam._deserialize(params.get("CycleParam"))
        if params.get("TimedParam") is not None:
            self._TimedParam = TimedEmailParam()
            self._TimedParam._deserialize(params.get("TimedParam"))
        self._Unsubscribe = params.get("Unsubscribe")
        self._ADLocation = params.get("ADLocation")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class BatchSendEmailResponse(AbstractModel):
    r"""BatchSendEmail response structure.

    """

    def __init__(self):
        r"""
        :param _TaskId: Send task ID.
        :type TaskId: int
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._TaskId = None
        self._RequestId = None

    @property
    def TaskId(self):
        r"""Send task ID.
        :rtype: int
        """
        return self._TaskId

    @TaskId.setter
    def TaskId(self, TaskId):
        self._TaskId = TaskId

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._TaskId = params.get("TaskId")
        self._RequestId = params.get("RequestId")


class BlackAddressDetail(AbstractModel):
    r"""Blocklist description.

    """

    def __init__(self):
        r"""
        :param _Id: Blocklist address id.
        :type Id: int
        :param _Email: Email address.
        :type Email: str
        :param _CreateTime: Creation time.


        :type CreateTime: str
        :param _ExpireDate: Expiration time
        :type ExpireDate: str
        :param _Status: Blocklist status. valid values: 0 (expired), 1 (active).
        :type Status: int
        """
        self._Id = None
        self._Email = None
        self._CreateTime = None
        self._ExpireDate = None
        self._Status = None

    @property
    def Id(self):
        r"""Blocklist address id.
        :rtype: int
        """
        return self._Id

    @Id.setter
    def Id(self, Id):
        self._Id = Id

    @property
    def Email(self):
        r"""Email address.
        :rtype: str
        """
        return self._Email

    @Email.setter
    def Email(self, Email):
        self._Email = Email

    @property
    def CreateTime(self):
        r"""Creation time.


        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def ExpireDate(self):
        r"""Expiration time
        :rtype: str
        """
        return self._ExpireDate

    @ExpireDate.setter
    def ExpireDate(self, ExpireDate):
        self._ExpireDate = ExpireDate

    @property
    def Status(self):
        r"""Blocklist status. valid values: 0 (expired), 1 (active).
        :rtype: int
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status


    def _deserialize(self, params):
        self._Id = params.get("Id")
        self._Email = params.get("Email")
        self._CreateTime = params.get("CreateTime")
        self._ExpireDate = params.get("ExpireDate")
        self._Status = params.get("Status")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class BlackEmailAddress(AbstractModel):
    r"""Email blocklist structure describes the blocked email address, blocklist time, and reason.

    """

    def __init__(self):
        r"""
        :param _BounceTime: Time when the email address is blocklisted.
        :type BounceTime: str
        :param _EmailAddress: Blocklisted email address.
        :type EmailAddress: str
        :param _IspDesc: Reason for being blacklisted.
        :type IspDesc: str
        """
        self._BounceTime = None
        self._EmailAddress = None
        self._IspDesc = None

    @property
    def BounceTime(self):
        r"""Time when the email address is blocklisted.
        :rtype: str
        """
        return self._BounceTime

    @BounceTime.setter
    def BounceTime(self, BounceTime):
        self._BounceTime = BounceTime

    @property
    def EmailAddress(self):
        r"""Blocklisted email address.
        :rtype: str
        """
        return self._EmailAddress

    @EmailAddress.setter
    def EmailAddress(self, EmailAddress):
        self._EmailAddress = EmailAddress

    @property
    def IspDesc(self):
        r"""Reason for being blacklisted.
        :rtype: str
        """
        return self._IspDesc

    @IspDesc.setter
    def IspDesc(self, IspDesc):
        self._IspDesc = IspDesc


    def _deserialize(self, params):
        self._BounceTime = params.get("BounceTime")
        self._EmailAddress = params.get("EmailAddress")
        self._IspDesc = params.get("IspDesc")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateAddressUnsubscribeConfigRequest(AbstractModel):
    r"""CreateAddressUnsubscribeConfig request structure.

    """

    def __init__(self):
        r"""
        :param _Address: Sender address.
        :type Address: str
        :param _UnsubscribeConfig: Unsubscribe link option. 0: Do not add unsubscribe link; 1: English 2: Simplified Chinese; 3: Traditional Chinese; 4: Spanish; 5: French; 6: German; 7: Japanese; 8: Korean; 9: Arabic; 10: Thai
        :type UnsubscribeConfig: str
        :param _Status: 0: disabled; 1: enabled.
        :type Status: int
        """
        self._Address = None
        self._UnsubscribeConfig = None
        self._Status = None

    @property
    def Address(self):
        r"""Sender address.
        :rtype: str
        """
        return self._Address

    @Address.setter
    def Address(self, Address):
        self._Address = Address

    @property
    def UnsubscribeConfig(self):
        r"""Unsubscribe link option. 0: Do not add unsubscribe link; 1: English 2: Simplified Chinese; 3: Traditional Chinese; 4: Spanish; 5: French; 6: German; 7: Japanese; 8: Korean; 9: Arabic; 10: Thai
        :rtype: str
        """
        return self._UnsubscribeConfig

    @UnsubscribeConfig.setter
    def UnsubscribeConfig(self, UnsubscribeConfig):
        self._UnsubscribeConfig = UnsubscribeConfig

    @property
    def Status(self):
        r"""0: disabled; 1: enabled.
        :rtype: int
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status


    def _deserialize(self, params):
        self._Address = params.get("Address")
        self._UnsubscribeConfig = params.get("UnsubscribeConfig")
        self._Status = params.get("Status")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateAddressUnsubscribeConfigResponse(AbstractModel):
    r"""CreateAddressUnsubscribeConfig response structure.

    """

    def __init__(self):
        r"""
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class CreateCustomBlacklistRequest(AbstractModel):
    r"""CreateCustomBlacklist request structure.

    """

    def __init__(self):
        r"""
        :param _Emails: Add to blocklist email address.
        :type Emails: list of str
        :param _ExpireDate: Expiration date.
        :type ExpireDate: str
        """
        self._Emails = None
        self._ExpireDate = None

    @property
    def Emails(self):
        r"""Add to blocklist email address.
        :rtype: list of str
        """
        return self._Emails

    @Emails.setter
    def Emails(self, Emails):
        self._Emails = Emails

    @property
    def ExpireDate(self):
        r"""Expiration date.
        :rtype: str
        """
        return self._ExpireDate

    @ExpireDate.setter
    def ExpireDate(self, ExpireDate):
        self._ExpireDate = ExpireDate


    def _deserialize(self, params):
        self._Emails = params.get("Emails")
        self._ExpireDate = params.get("ExpireDate")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateCustomBlacklistResponse(AbstractModel):
    r"""CreateCustomBlacklist response structure.

    """

    def __init__(self):
        r"""
        :param _TotalCount: Total number of recipients.
        :type TotalCount: int
        :param _ValidCount: Actual uploaded quantity.
        :type ValidCount: int
        :param _TooLongCount: Data too long quantity.
        :type TooLongCount: int
        :param _RepeatCount: Repetition count.
        :type RepeatCount: int
        :param _InvalidCount: Incorrect format count.
        :type InvalidCount: int
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._TotalCount = None
        self._ValidCount = None
        self._TooLongCount = None
        self._RepeatCount = None
        self._InvalidCount = None
        self._RequestId = None

    @property
    def TotalCount(self):
        r"""Total number of recipients.
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def ValidCount(self):
        r"""Actual uploaded quantity.
        :rtype: int
        """
        return self._ValidCount

    @ValidCount.setter
    def ValidCount(self, ValidCount):
        self._ValidCount = ValidCount

    @property
    def TooLongCount(self):
        r"""Data too long quantity.
        :rtype: int
        """
        return self._TooLongCount

    @TooLongCount.setter
    def TooLongCount(self, TooLongCount):
        self._TooLongCount = TooLongCount

    @property
    def RepeatCount(self):
        r"""Repetition count.
        :rtype: int
        """
        return self._RepeatCount

    @RepeatCount.setter
    def RepeatCount(self, RepeatCount):
        self._RepeatCount = RepeatCount

    @property
    def InvalidCount(self):
        r"""Incorrect format count.
        :rtype: int
        """
        return self._InvalidCount

    @InvalidCount.setter
    def InvalidCount(self, InvalidCount):
        self._InvalidCount = InvalidCount

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._TotalCount = params.get("TotalCount")
        self._ValidCount = params.get("ValidCount")
        self._TooLongCount = params.get("TooLongCount")
        self._RepeatCount = params.get("RepeatCount")
        self._InvalidCount = params.get("InvalidCount")
        self._RequestId = params.get("RequestId")


class CreateEmailAddressRequest(AbstractModel):
    r"""CreateEmailAddress request structure.

    """

    def __init__(self):
        r"""
        :param _EmailAddress: Your sender address. (You can create up to 10 sender addresses for each domain.)
        :type EmailAddress: str
        :param _EmailSenderName: Sender name.
        :type EmailSenderName: str
        """
        self._EmailAddress = None
        self._EmailSenderName = None

    @property
    def EmailAddress(self):
        r"""Your sender address. (You can create up to 10 sender addresses for each domain.)
        :rtype: str
        """
        return self._EmailAddress

    @EmailAddress.setter
    def EmailAddress(self, EmailAddress):
        self._EmailAddress = EmailAddress

    @property
    def EmailSenderName(self):
        r"""Sender name.
        :rtype: str
        """
        return self._EmailSenderName

    @EmailSenderName.setter
    def EmailSenderName(self, EmailSenderName):
        self._EmailSenderName = EmailSenderName


    def _deserialize(self, params):
        self._EmailAddress = params.get("EmailAddress")
        self._EmailSenderName = params.get("EmailSenderName")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateEmailAddressResponse(AbstractModel):
    r"""CreateEmailAddress response structure.

    """

    def __init__(self):
        r"""
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class CreateEmailIdentityRequest(AbstractModel):
    r"""CreateEmailIdentity request structure.

    """

    def __init__(self):
        r"""
        :param _EmailIdentity: Your sender domain. You are advised to use a third-level domain, for example, mail.qcloud.com.
        :type EmailIdentity: str
        :param _DKIMOption: Generated dkim key length. valid values: 0 (1024), 1 (2048).
        :type DKIMOption: int
        :param _TagList: tag.
        :type TagList: list of TagList
        """
        self._EmailIdentity = None
        self._DKIMOption = None
        self._TagList = None

    @property
    def EmailIdentity(self):
        r"""Your sender domain. You are advised to use a third-level domain, for example, mail.qcloud.com.
        :rtype: str
        """
        return self._EmailIdentity

    @EmailIdentity.setter
    def EmailIdentity(self, EmailIdentity):
        self._EmailIdentity = EmailIdentity

    @property
    def DKIMOption(self):
        r"""Generated dkim key length. valid values: 0 (1024), 1 (2048).
        :rtype: int
        """
        return self._DKIMOption

    @DKIMOption.setter
    def DKIMOption(self, DKIMOption):
        self._DKIMOption = DKIMOption

    @property
    def TagList(self):
        r"""tag.
        :rtype: list of TagList
        """
        return self._TagList

    @TagList.setter
    def TagList(self, TagList):
        self._TagList = TagList


    def _deserialize(self, params):
        self._EmailIdentity = params.get("EmailIdentity")
        self._DKIMOption = params.get("DKIMOption")
        if params.get("TagList") is not None:
            self._TagList = []
            for item in params.get("TagList"):
                obj = TagList()
                obj._deserialize(item)
                self._TagList.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateEmailIdentityResponse(AbstractModel):
    r"""CreateEmailIdentity response structure.

    """

    def __init__(self):
        r"""
        :param _IdentityType: Verification type. The value is fixed to `DOMAIN`.
        :type IdentityType: str
        :param _VerifiedForSendingStatus: Verification passed or not.
        :type VerifiedForSendingStatus: bool
        :param _Attributes: DNS information that needs to be configured.
        :type Attributes: list of DNSAttributes
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._IdentityType = None
        self._VerifiedForSendingStatus = None
        self._Attributes = None
        self._RequestId = None

    @property
    def IdentityType(self):
        r"""Verification type. The value is fixed to `DOMAIN`.
        :rtype: str
        """
        return self._IdentityType

    @IdentityType.setter
    def IdentityType(self, IdentityType):
        self._IdentityType = IdentityType

    @property
    def VerifiedForSendingStatus(self):
        r"""Verification passed or not.
        :rtype: bool
        """
        return self._VerifiedForSendingStatus

    @VerifiedForSendingStatus.setter
    def VerifiedForSendingStatus(self, VerifiedForSendingStatus):
        self._VerifiedForSendingStatus = VerifiedForSendingStatus

    @property
    def Attributes(self):
        r"""DNS information that needs to be configured.
        :rtype: list of DNSAttributes
        """
        return self._Attributes

    @Attributes.setter
    def Attributes(self, Attributes):
        self._Attributes = Attributes

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._IdentityType = params.get("IdentityType")
        self._VerifiedForSendingStatus = params.get("VerifiedForSendingStatus")
        if params.get("Attributes") is not None:
            self._Attributes = []
            for item in params.get("Attributes"):
                obj = DNSAttributes()
                obj._deserialize(item)
                self._Attributes.append(obj)
        self._RequestId = params.get("RequestId")


class CreateEmailTemplateRequest(AbstractModel):
    r"""CreateEmailTemplate request structure.

    """

    def __init__(self):
        r"""
        :param _TemplateName: Template name.
        :type TemplateName: str
        :param _TemplateContent: Template content.
        :type TemplateContent: :class:`tencentcloud.ses.v20201002.models.TemplateContent`
        """
        self._TemplateName = None
        self._TemplateContent = None

    @property
    def TemplateName(self):
        r"""Template name.
        :rtype: str
        """
        return self._TemplateName

    @TemplateName.setter
    def TemplateName(self, TemplateName):
        self._TemplateName = TemplateName

    @property
    def TemplateContent(self):
        r"""Template content.
        :rtype: :class:`tencentcloud.ses.v20201002.models.TemplateContent`
        """
        return self._TemplateContent

    @TemplateContent.setter
    def TemplateContent(self, TemplateContent):
        self._TemplateContent = TemplateContent


    def _deserialize(self, params):
        self._TemplateName = params.get("TemplateName")
        if params.get("TemplateContent") is not None:
            self._TemplateContent = TemplateContent()
            self._TemplateContent._deserialize(params.get("TemplateContent"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateEmailTemplateResponse(AbstractModel):
    r"""CreateEmailTemplate response structure.

    """

    def __init__(self):
        r"""
        :param _TemplateID: Template ID
        :type TemplateID: int
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._TemplateID = None
        self._RequestId = None

    @property
    def TemplateID(self):
        r"""Template ID
        :rtype: int
        """
        return self._TemplateID

    @TemplateID.setter
    def TemplateID(self, TemplateID):
        self._TemplateID = TemplateID

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._TemplateID = params.get("TemplateID")
        self._RequestId = params.get("RequestId")


class CreateReceiverDetailRequest(AbstractModel):
    r"""CreateReceiverDetail request structure.

    """

    def __init__(self):
        r"""
        :param _ReceiverId: Recipient group ID
        :type ReceiverId: int
        :param _Emails: Email address
        :type Emails: list of str
        """
        self._ReceiverId = None
        self._Emails = None

    @property
    def ReceiverId(self):
        r"""Recipient group ID
        :rtype: int
        """
        return self._ReceiverId

    @ReceiverId.setter
    def ReceiverId(self, ReceiverId):
        self._ReceiverId = ReceiverId

    @property
    def Emails(self):
        r"""Email address
        :rtype: list of str
        """
        return self._Emails

    @Emails.setter
    def Emails(self, Emails):
        self._Emails = Emails


    def _deserialize(self, params):
        self._ReceiverId = params.get("ReceiverId")
        self._Emails = params.get("Emails")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateReceiverDetailResponse(AbstractModel):
    r"""CreateReceiverDetail response structure.

    """

    def __init__(self):
        r"""
        :param _TotalCount: Total number of recipients.
        :type TotalCount: int
        :param _ValidCount: Actual uploaded quantity.
        :type ValidCount: int
        :param _TooLongCount: Data too long quantity.
        :type TooLongCount: int
        :param _EmptyEmailCount: Number of empty email addresses.
        :type EmptyEmailCount: int
        :param _RepeatCount: Repetition count.
        :type RepeatCount: int
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._TotalCount = None
        self._ValidCount = None
        self._TooLongCount = None
        self._EmptyEmailCount = None
        self._RepeatCount = None
        self._RequestId = None

    @property
    def TotalCount(self):
        r"""Total number of recipients.
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def ValidCount(self):
        r"""Actual uploaded quantity.
        :rtype: int
        """
        return self._ValidCount

    @ValidCount.setter
    def ValidCount(self, ValidCount):
        self._ValidCount = ValidCount

    @property
    def TooLongCount(self):
        r"""Data too long quantity.
        :rtype: int
        """
        return self._TooLongCount

    @TooLongCount.setter
    def TooLongCount(self, TooLongCount):
        self._TooLongCount = TooLongCount

    @property
    def EmptyEmailCount(self):
        r"""Number of empty email addresses.
        :rtype: int
        """
        return self._EmptyEmailCount

    @EmptyEmailCount.setter
    def EmptyEmailCount(self, EmptyEmailCount):
        self._EmptyEmailCount = EmptyEmailCount

    @property
    def RepeatCount(self):
        r"""Repetition count.
        :rtype: int
        """
        return self._RepeatCount

    @RepeatCount.setter
    def RepeatCount(self, RepeatCount):
        self._RepeatCount = RepeatCount

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._TotalCount = params.get("TotalCount")
        self._ValidCount = params.get("ValidCount")
        self._TooLongCount = params.get("TooLongCount")
        self._EmptyEmailCount = params.get("EmptyEmailCount")
        self._RepeatCount = params.get("RepeatCount")
        self._RequestId = params.get("RequestId")


class CreateReceiverDetailWithDataRequest(AbstractModel):
    r"""CreateReceiverDetailWithData request structure.

    """

    def __init__(self):
        r"""
        :param _ReceiverId: Recipient list ID.
        :type ReceiverId: int
        :param _Datas: Recipient mailbox and template parameters in array format. limit on the number of recipients not exceeding 20000.
        :type Datas: list of ReceiverInputData
        """
        self._ReceiverId = None
        self._Datas = None

    @property
    def ReceiverId(self):
        r"""Recipient list ID.
        :rtype: int
        """
        return self._ReceiverId

    @ReceiverId.setter
    def ReceiverId(self, ReceiverId):
        self._ReceiverId = ReceiverId

    @property
    def Datas(self):
        r"""Recipient mailbox and template parameters in array format. limit on the number of recipients not exceeding 20000.
        :rtype: list of ReceiverInputData
        """
        return self._Datas

    @Datas.setter
    def Datas(self, Datas):
        self._Datas = Datas


    def _deserialize(self, params):
        self._ReceiverId = params.get("ReceiverId")
        if params.get("Datas") is not None:
            self._Datas = []
            for item in params.get("Datas"):
                obj = ReceiverInputData()
                obj._deserialize(item)
                self._Datas.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateReceiverDetailWithDataResponse(AbstractModel):
    r"""CreateReceiverDetailWithData response structure.

    """

    def __init__(self):
        r"""
        :param _TotalCount: Recipient total number.
        :type TotalCount: int
        :param _ValidCount: Uploaded quantity.
        :type ValidCount: int
        :param _TooLongCount: Data too long quantity.
        :type TooLongCount: int
        :param _EmptyEmailCount: Number of empty email addresses.
        :type EmptyEmailCount: int
        :param _RepeatCount: Repetition count.
        :type RepeatCount: int
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._TotalCount = None
        self._ValidCount = None
        self._TooLongCount = None
        self._EmptyEmailCount = None
        self._RepeatCount = None
        self._RequestId = None

    @property
    def TotalCount(self):
        r"""Recipient total number.
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def ValidCount(self):
        r"""Uploaded quantity.
        :rtype: int
        """
        return self._ValidCount

    @ValidCount.setter
    def ValidCount(self, ValidCount):
        self._ValidCount = ValidCount

    @property
    def TooLongCount(self):
        r"""Data too long quantity.
        :rtype: int
        """
        return self._TooLongCount

    @TooLongCount.setter
    def TooLongCount(self, TooLongCount):
        self._TooLongCount = TooLongCount

    @property
    def EmptyEmailCount(self):
        r"""Number of empty email addresses.
        :rtype: int
        """
        return self._EmptyEmailCount

    @EmptyEmailCount.setter
    def EmptyEmailCount(self, EmptyEmailCount):
        self._EmptyEmailCount = EmptyEmailCount

    @property
    def RepeatCount(self):
        r"""Repetition count.
        :rtype: int
        """
        return self._RepeatCount

    @RepeatCount.setter
    def RepeatCount(self, RepeatCount):
        self._RepeatCount = RepeatCount

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._TotalCount = params.get("TotalCount")
        self._ValidCount = params.get("ValidCount")
        self._TooLongCount = params.get("TooLongCount")
        self._EmptyEmailCount = params.get("EmptyEmailCount")
        self._RepeatCount = params.get("RepeatCount")
        self._RequestId = params.get("RequestId")


class CreateReceiverRequest(AbstractModel):
    r"""CreateReceiver request structure.

    """

    def __init__(self):
        r"""
        :param _ReceiversName: Recipient group name
        :type ReceiversName: str
        :param _Desc: Recipient group description
        :type Desc: str
        """
        self._ReceiversName = None
        self._Desc = None

    @property
    def ReceiversName(self):
        r"""Recipient group name
        :rtype: str
        """
        return self._ReceiversName

    @ReceiversName.setter
    def ReceiversName(self, ReceiversName):
        self._ReceiversName = ReceiversName

    @property
    def Desc(self):
        r"""Recipient group description
        :rtype: str
        """
        return self._Desc

    @Desc.setter
    def Desc(self, Desc):
        self._Desc = Desc


    def _deserialize(self, params):
        self._ReceiversName = params.get("ReceiversName")
        self._Desc = params.get("Desc")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateReceiverResponse(AbstractModel):
    r"""CreateReceiver response structure.

    """

    def __init__(self):
        r"""
        :param _ReceiverId: Recipient group ID, by which recipient email addresses are uploaded
        :type ReceiverId: int
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._ReceiverId = None
        self._RequestId = None

    @property
    def ReceiverId(self):
        r"""Recipient group ID, by which recipient email addresses are uploaded
        :rtype: int
        """
        return self._ReceiverId

    @ReceiverId.setter
    def ReceiverId(self, ReceiverId):
        self._ReceiverId = ReceiverId

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._ReceiverId = params.get("ReceiverId")
        self._RequestId = params.get("RequestId")


class CycleEmailParam(AbstractModel):
    r"""Parameter required to create a recurring sending task

    """

    def __init__(self):
        r"""
        :param _BeginTime: Start time of the task
        :type BeginTime: str
        :param _IntervalTime: Task recurrence in hours
        :type IntervalTime: int
        :param _TermCycle: Specifies whether to end the cycle. This parameter is used to update the task. Valid values: 0: No; 1: Yes.
        :type TermCycle: int
        """
        self._BeginTime = None
        self._IntervalTime = None
        self._TermCycle = None

    @property
    def BeginTime(self):
        r"""Start time of the task
        :rtype: str
        """
        return self._BeginTime

    @BeginTime.setter
    def BeginTime(self, BeginTime):
        self._BeginTime = BeginTime

    @property
    def IntervalTime(self):
        r"""Task recurrence in hours
        :rtype: int
        """
        return self._IntervalTime

    @IntervalTime.setter
    def IntervalTime(self, IntervalTime):
        self._IntervalTime = IntervalTime

    @property
    def TermCycle(self):
        r"""Specifies whether to end the cycle. This parameter is used to update the task. Valid values: 0: No; 1: Yes.
        :rtype: int
        """
        return self._TermCycle

    @TermCycle.setter
    def TermCycle(self, TermCycle):
        self._TermCycle = TermCycle


    def _deserialize(self, params):
        self._BeginTime = params.get("BeginTime")
        self._IntervalTime = params.get("IntervalTime")
        self._TermCycle = params.get("TermCycle")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DNSAttributes(AbstractModel):
    r"""Describes the domain name, record type, expected value, and currently configured value of DNS records.

    """

    def __init__(self):
        r"""
        :param _Type: Record types: CNAME, A, TXT, and MX.
        :type Type: str
        :param _SendDomain: Domain name.
        :type SendDomain: str
        :param _ExpectedValue: Expected value.
        :type ExpectedValue: str
        :param _CurrentValue: Currently configured value.
        :type CurrentValue: str
        :param _Status: Approved or not. The default value is `false`.
        :type Status: bool
        """
        self._Type = None
        self._SendDomain = None
        self._ExpectedValue = None
        self._CurrentValue = None
        self._Status = None

    @property
    def Type(self):
        r"""Record types: CNAME, A, TXT, and MX.
        :rtype: str
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        self._Type = Type

    @property
    def SendDomain(self):
        r"""Domain name.
        :rtype: str
        """
        return self._SendDomain

    @SendDomain.setter
    def SendDomain(self, SendDomain):
        self._SendDomain = SendDomain

    @property
    def ExpectedValue(self):
        r"""Expected value.
        :rtype: str
        """
        return self._ExpectedValue

    @ExpectedValue.setter
    def ExpectedValue(self, ExpectedValue):
        self._ExpectedValue = ExpectedValue

    @property
    def CurrentValue(self):
        r"""Currently configured value.
        :rtype: str
        """
        return self._CurrentValue

    @CurrentValue.setter
    def CurrentValue(self, CurrentValue):
        self._CurrentValue = CurrentValue

    @property
    def Status(self):
        r"""Approved or not. The default value is `false`.
        :rtype: bool
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status


    def _deserialize(self, params):
        self._Type = params.get("Type")
        self._SendDomain = params.get("SendDomain")
        self._ExpectedValue = params.get("ExpectedValue")
        self._CurrentValue = params.get("CurrentValue")
        self._Status = params.get("Status")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteAddressUnsubscribeConfigRequest(AbstractModel):
    r"""DeleteAddressUnsubscribeConfig request structure.

    """

    def __init__(self):
        r"""
        :param _Address: Sender address.
        :type Address: str
        """
        self._Address = None

    @property
    def Address(self):
        r"""Sender address.
        :rtype: str
        """
        return self._Address

    @Address.setter
    def Address(self, Address):
        self._Address = Address


    def _deserialize(self, params):
        self._Address = params.get("Address")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteAddressUnsubscribeConfigResponse(AbstractModel):
    r"""DeleteAddressUnsubscribeConfig response structure.

    """

    def __init__(self):
        r"""
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class DeleteBlackListRequest(AbstractModel):
    r"""DeleteBlackList request structure.

    """

    def __init__(self):
        r"""
        :param _EmailAddressList: List of email addresses to be unblocklisted. Enter at least one address.
        :type EmailAddressList: list of str
        """
        self._EmailAddressList = None

    @property
    def EmailAddressList(self):
        r"""List of email addresses to be unblocklisted. Enter at least one address.
        :rtype: list of str
        """
        return self._EmailAddressList

    @EmailAddressList.setter
    def EmailAddressList(self, EmailAddressList):
        self._EmailAddressList = EmailAddressList


    def _deserialize(self, params):
        self._EmailAddressList = params.get("EmailAddressList")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteBlackListResponse(AbstractModel):
    r"""DeleteBlackList response structure.

    """

    def __init__(self):
        r"""
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class DeleteCustomBlackListRequest(AbstractModel):
    r"""DeleteCustomBlackList request structure.

    """

    def __init__(self):
        r"""
        :param _Emails: Email address that needs to be deleted.
        :type Emails: list of str
        """
        self._Emails = None

    @property
    def Emails(self):
        r"""Email address that needs to be deleted.
        :rtype: list of str
        """
        return self._Emails

    @Emails.setter
    def Emails(self, Emails):
        self._Emails = Emails


    def _deserialize(self, params):
        self._Emails = params.get("Emails")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteCustomBlackListResponse(AbstractModel):
    r"""DeleteCustomBlackList response structure.

    """

    def __init__(self):
        r"""
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class DeleteEmailAddressRequest(AbstractModel):
    r"""DeleteEmailAddress request structure.

    """

    def __init__(self):
        r"""
        :param _EmailAddress: Sender address.
        :type EmailAddress: str
        """
        self._EmailAddress = None

    @property
    def EmailAddress(self):
        r"""Sender address.
        :rtype: str
        """
        return self._EmailAddress

    @EmailAddress.setter
    def EmailAddress(self, EmailAddress):
        self._EmailAddress = EmailAddress


    def _deserialize(self, params):
        self._EmailAddress = params.get("EmailAddress")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteEmailAddressResponse(AbstractModel):
    r"""DeleteEmailAddress response structure.

    """

    def __init__(self):
        r"""
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class DeleteEmailIdentityRequest(AbstractModel):
    r"""DeleteEmailIdentity request structure.

    """

    def __init__(self):
        r"""
        :param _EmailIdentity: Sender domain.
        :type EmailIdentity: str
        """
        self._EmailIdentity = None

    @property
    def EmailIdentity(self):
        r"""Sender domain.
        :rtype: str
        """
        return self._EmailIdentity

    @EmailIdentity.setter
    def EmailIdentity(self, EmailIdentity):
        self._EmailIdentity = EmailIdentity


    def _deserialize(self, params):
        self._EmailIdentity = params.get("EmailIdentity")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteEmailIdentityResponse(AbstractModel):
    r"""DeleteEmailIdentity response structure.

    """

    def __init__(self):
        r"""
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class DeleteEmailTemplateRequest(AbstractModel):
    r"""DeleteEmailTemplate request structure.

    """

    def __init__(self):
        r"""
        :param _TemplateID: Template ID
        :type TemplateID: int
        """
        self._TemplateID = None

    @property
    def TemplateID(self):
        r"""Template ID
        :rtype: int
        """
        return self._TemplateID

    @TemplateID.setter
    def TemplateID(self, TemplateID):
        self._TemplateID = TemplateID


    def _deserialize(self, params):
        self._TemplateID = params.get("TemplateID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteEmailTemplateResponse(AbstractModel):
    r"""DeleteEmailTemplate response structure.

    """

    def __init__(self):
        r"""
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class DeleteReceiverRequest(AbstractModel):
    r"""DeleteReceiver request structure.

    """

    def __init__(self):
        r"""
        :param _ReceiverId: Recipient group ID, which is returned when a recipient group is created.
        :type ReceiverId: int
        """
        self._ReceiverId = None

    @property
    def ReceiverId(self):
        r"""Recipient group ID, which is returned when a recipient group is created.
        :rtype: int
        """
        return self._ReceiverId

    @ReceiverId.setter
    def ReceiverId(self, ReceiverId):
        self._ReceiverId = ReceiverId


    def _deserialize(self, params):
        self._ReceiverId = params.get("ReceiverId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteReceiverResponse(AbstractModel):
    r"""DeleteReceiver response structure.

    """

    def __init__(self):
        r"""
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class EmailIdentity(AbstractModel):
    r"""Sender domain verification list structure

    """

    def __init__(self):
        r"""
        :param _IdentityName: Sender domain.
        :type IdentityName: str
        :param _IdentityType: Verification type. The value is fixed to `DOMAIN`.
        :type IdentityType: str
        :param _SendingEnabled: Verification passed or not.
        :type SendingEnabled: bool
        :param _CurrentReputationLevel: Current reputation level
        :type CurrentReputationLevel: int
        :param _DailyQuota: Maximum number of messages sent per day
        :type DailyQuota: int
        :param _SendIp: Independent ip for domain configuration.
        :type SendIp: list of str
        :param _TagList: tag.
        :type TagList: list of TagList
        """
        self._IdentityName = None
        self._IdentityType = None
        self._SendingEnabled = None
        self._CurrentReputationLevel = None
        self._DailyQuota = None
        self._SendIp = None
        self._TagList = None

    @property
    def IdentityName(self):
        r"""Sender domain.
        :rtype: str
        """
        return self._IdentityName

    @IdentityName.setter
    def IdentityName(self, IdentityName):
        self._IdentityName = IdentityName

    @property
    def IdentityType(self):
        r"""Verification type. The value is fixed to `DOMAIN`.
        :rtype: str
        """
        return self._IdentityType

    @IdentityType.setter
    def IdentityType(self, IdentityType):
        self._IdentityType = IdentityType

    @property
    def SendingEnabled(self):
        r"""Verification passed or not.
        :rtype: bool
        """
        return self._SendingEnabled

    @SendingEnabled.setter
    def SendingEnabled(self, SendingEnabled):
        self._SendingEnabled = SendingEnabled

    @property
    def CurrentReputationLevel(self):
        r"""Current reputation level
        :rtype: int
        """
        return self._CurrentReputationLevel

    @CurrentReputationLevel.setter
    def CurrentReputationLevel(self, CurrentReputationLevel):
        self._CurrentReputationLevel = CurrentReputationLevel

    @property
    def DailyQuota(self):
        r"""Maximum number of messages sent per day
        :rtype: int
        """
        return self._DailyQuota

    @DailyQuota.setter
    def DailyQuota(self, DailyQuota):
        self._DailyQuota = DailyQuota

    @property
    def SendIp(self):
        r"""Independent ip for domain configuration.
        :rtype: list of str
        """
        return self._SendIp

    @SendIp.setter
    def SendIp(self, SendIp):
        self._SendIp = SendIp

    @property
    def TagList(self):
        r"""tag.
        :rtype: list of TagList
        """
        return self._TagList

    @TagList.setter
    def TagList(self, TagList):
        self._TagList = TagList


    def _deserialize(self, params):
        self._IdentityName = params.get("IdentityName")
        self._IdentityType = params.get("IdentityType")
        self._SendingEnabled = params.get("SendingEnabled")
        self._CurrentReputationLevel = params.get("CurrentReputationLevel")
        self._DailyQuota = params.get("DailyQuota")
        self._SendIp = params.get("SendIp")
        if params.get("TagList") is not None:
            self._TagList = []
            for item in params.get("TagList"):
                obj = TagList()
                obj._deserialize(item)
                self._TagList.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class EmailSender(AbstractModel):
    r"""Describes sender information.

    """

    def __init__(self):
        r"""
        :param _EmailAddress: Sender address.
        :type EmailAddress: str
        :param _EmailSenderName: Sender alias.
        :type EmailSenderName: str
        :param _CreatedTimestamp: Creation time.


        :type CreatedTimestamp: int
        :param _SmtpPwdType: smtp password type. 0=not set. 1=already set up.
        :type SmtpPwdType: int
        """
        self._EmailAddress = None
        self._EmailSenderName = None
        self._CreatedTimestamp = None
        self._SmtpPwdType = None

    @property
    def EmailAddress(self):
        r"""Sender address.
        :rtype: str
        """
        return self._EmailAddress

    @EmailAddress.setter
    def EmailAddress(self, EmailAddress):
        self._EmailAddress = EmailAddress

    @property
    def EmailSenderName(self):
        r"""Sender alias.
        :rtype: str
        """
        return self._EmailSenderName

    @EmailSenderName.setter
    def EmailSenderName(self, EmailSenderName):
        self._EmailSenderName = EmailSenderName

    @property
    def CreatedTimestamp(self):
        r"""Creation time.


        :rtype: int
        """
        return self._CreatedTimestamp

    @CreatedTimestamp.setter
    def CreatedTimestamp(self, CreatedTimestamp):
        self._CreatedTimestamp = CreatedTimestamp

    @property
    def SmtpPwdType(self):
        r"""smtp password type. 0=not set. 1=already set up.
        :rtype: int
        """
        return self._SmtpPwdType

    @SmtpPwdType.setter
    def SmtpPwdType(self, SmtpPwdType):
        self._SmtpPwdType = SmtpPwdType


    def _deserialize(self, params):
        self._EmailAddress = params.get("EmailAddress")
        self._EmailSenderName = params.get("EmailSenderName")
        self._CreatedTimestamp = params.get("CreatedTimestamp")
        self._SmtpPwdType = params.get("SmtpPwdType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GetEmailIdentityRequest(AbstractModel):
    r"""GetEmailIdentity request structure.

    """

    def __init__(self):
        r"""
        :param _EmailIdentity: Sender domain.
        :type EmailIdentity: str
        """
        self._EmailIdentity = None

    @property
    def EmailIdentity(self):
        r"""Sender domain.
        :rtype: str
        """
        return self._EmailIdentity

    @EmailIdentity.setter
    def EmailIdentity(self, EmailIdentity):
        self._EmailIdentity = EmailIdentity


    def _deserialize(self, params):
        self._EmailIdentity = params.get("EmailIdentity")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GetEmailIdentityResponse(AbstractModel):
    r"""GetEmailIdentity response structure.

    """

    def __init__(self):
        r"""
        :param _IdentityType: Verification type. The value is fixed to `DOMAIN`.
        :type IdentityType: str
        :param _VerifiedForSendingStatus: Verification passed or not.
        :type VerifiedForSendingStatus: bool
        :param _Attributes: DNS configuration details.
        :type Attributes: list of DNSAttributes
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._IdentityType = None
        self._VerifiedForSendingStatus = None
        self._Attributes = None
        self._RequestId = None

    @property
    def IdentityType(self):
        r"""Verification type. The value is fixed to `DOMAIN`.
        :rtype: str
        """
        return self._IdentityType

    @IdentityType.setter
    def IdentityType(self, IdentityType):
        self._IdentityType = IdentityType

    @property
    def VerifiedForSendingStatus(self):
        r"""Verification passed or not.
        :rtype: bool
        """
        return self._VerifiedForSendingStatus

    @VerifiedForSendingStatus.setter
    def VerifiedForSendingStatus(self, VerifiedForSendingStatus):
        self._VerifiedForSendingStatus = VerifiedForSendingStatus

    @property
    def Attributes(self):
        r"""DNS configuration details.
        :rtype: list of DNSAttributes
        """
        return self._Attributes

    @Attributes.setter
    def Attributes(self, Attributes):
        self._Attributes = Attributes

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._IdentityType = params.get("IdentityType")
        self._VerifiedForSendingStatus = params.get("VerifiedForSendingStatus")
        if params.get("Attributes") is not None:
            self._Attributes = []
            for item in params.get("Attributes"):
                obj = DNSAttributes()
                obj._deserialize(item)
                self._Attributes.append(obj)
        self._RequestId = params.get("RequestId")


class GetEmailTemplateRequest(AbstractModel):
    r"""GetEmailTemplate request structure.

    """

    def __init__(self):
        r"""
        :param _TemplateID: Template ID.
        :type TemplateID: int
        """
        self._TemplateID = None

    @property
    def TemplateID(self):
        r"""Template ID.
        :rtype: int
        """
        return self._TemplateID

    @TemplateID.setter
    def TemplateID(self, TemplateID):
        self._TemplateID = TemplateID


    def _deserialize(self, params):
        self._TemplateID = params.get("TemplateID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GetEmailTemplateResponse(AbstractModel):
    r"""GetEmailTemplate response structure.

    """

    def __init__(self):
        r"""
        :param _TemplateContent: Template content.
        :type TemplateContent: :class:`tencentcloud.ses.v20201002.models.TemplateContent`
        :param _TemplateStatus: Template status. Valid values: `0` (approved); `1` (pending approval); `2` (rejected).
        :type TemplateStatus: int
        :param _TemplateName: Template name
        :type TemplateName: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._TemplateContent = None
        self._TemplateStatus = None
        self._TemplateName = None
        self._RequestId = None

    @property
    def TemplateContent(self):
        r"""Template content.
        :rtype: :class:`tencentcloud.ses.v20201002.models.TemplateContent`
        """
        return self._TemplateContent

    @TemplateContent.setter
    def TemplateContent(self, TemplateContent):
        self._TemplateContent = TemplateContent

    @property
    def TemplateStatus(self):
        r"""Template status. Valid values: `0` (approved); `1` (pending approval); `2` (rejected).
        :rtype: int
        """
        return self._TemplateStatus

    @TemplateStatus.setter
    def TemplateStatus(self, TemplateStatus):
        self._TemplateStatus = TemplateStatus

    @property
    def TemplateName(self):
        r"""Template name
        :rtype: str
        """
        return self._TemplateName

    @TemplateName.setter
    def TemplateName(self, TemplateName):
        self._TemplateName = TemplateName

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("TemplateContent") is not None:
            self._TemplateContent = TemplateContent()
            self._TemplateContent._deserialize(params.get("TemplateContent"))
        self._TemplateStatus = params.get("TemplateStatus")
        self._TemplateName = params.get("TemplateName")
        self._RequestId = params.get("RequestId")


class GetSendEmailStatusRequest(AbstractModel):
    r"""GetSendEmailStatus request structure.

    """

    def __init__(self):
        r"""
        :param _RequestDate: Date sent. This parameter is required. You can only query the sending status for a single date at a time.
        :type RequestDate: str
        :param _Offset: Offset. Default value: `0`.
        :type Offset: int
        :param _Limit: Maximum number of pulled entries. Maximum value: `100`.
        :type Limit: int
        :param _MessageId: The `MessageId` field returned by the `SendMail` API.
        :type MessageId: str
        :param _ToEmailAddress: Recipient email address.
        :type ToEmailAddress: str
        """
        self._RequestDate = None
        self._Offset = None
        self._Limit = None
        self._MessageId = None
        self._ToEmailAddress = None

    @property
    def RequestDate(self):
        r"""Date sent. This parameter is required. You can only query the sending status for a single date at a time.
        :rtype: str
        """
        return self._RequestDate

    @RequestDate.setter
    def RequestDate(self, RequestDate):
        self._RequestDate = RequestDate

    @property
    def Offset(self):
        r"""Offset. Default value: `0`.
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def Limit(self):
        r"""Maximum number of pulled entries. Maximum value: `100`.
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def MessageId(self):
        r"""The `MessageId` field returned by the `SendMail` API.
        :rtype: str
        """
        return self._MessageId

    @MessageId.setter
    def MessageId(self, MessageId):
        self._MessageId = MessageId

    @property
    def ToEmailAddress(self):
        r"""Recipient email address.
        :rtype: str
        """
        return self._ToEmailAddress

    @ToEmailAddress.setter
    def ToEmailAddress(self, ToEmailAddress):
        self._ToEmailAddress = ToEmailAddress


    def _deserialize(self, params):
        self._RequestDate = params.get("RequestDate")
        self._Offset = params.get("Offset")
        self._Limit = params.get("Limit")
        self._MessageId = params.get("MessageId")
        self._ToEmailAddress = params.get("ToEmailAddress")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GetSendEmailStatusResponse(AbstractModel):
    r"""GetSendEmailStatus response structure.

    """

    def __init__(self):
        r"""
        :param _EmailStatusList: Status of sent emails
        :type EmailStatusList: list of SendEmailStatus
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._EmailStatusList = None
        self._RequestId = None

    @property
    def EmailStatusList(self):
        r"""Status of sent emails
        :rtype: list of SendEmailStatus
        """
        return self._EmailStatusList

    @EmailStatusList.setter
    def EmailStatusList(self, EmailStatusList):
        self._EmailStatusList = EmailStatusList

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("EmailStatusList") is not None:
            self._EmailStatusList = []
            for item in params.get("EmailStatusList"):
                obj = SendEmailStatus()
                obj._deserialize(item)
                self._EmailStatusList.append(obj)
        self._RequestId = params.get("RequestId")


class GetStatisticsReportRequest(AbstractModel):
    r"""GetStatisticsReport request structure.

    """

    def __init__(self):
        r"""
        :param _StartDate: Start date.
        :type StartDate: str
        :param _EndDate: End date.
        :type EndDate: str
        :param _Domain: Sender domain.
        :type Domain: str
        :param _ReceivingMailboxType: Recipient address type, for example, gmail.com.
        :type ReceivingMailboxType: str
        """
        self._StartDate = None
        self._EndDate = None
        self._Domain = None
        self._ReceivingMailboxType = None

    @property
    def StartDate(self):
        r"""Start date.
        :rtype: str
        """
        return self._StartDate

    @StartDate.setter
    def StartDate(self, StartDate):
        self._StartDate = StartDate

    @property
    def EndDate(self):
        r"""End date.
        :rtype: str
        """
        return self._EndDate

    @EndDate.setter
    def EndDate(self, EndDate):
        self._EndDate = EndDate

    @property
    def Domain(self):
        r"""Sender domain.
        :rtype: str
        """
        return self._Domain

    @Domain.setter
    def Domain(self, Domain):
        self._Domain = Domain

    @property
    def ReceivingMailboxType(self):
        r"""Recipient address type, for example, gmail.com.
        :rtype: str
        """
        return self._ReceivingMailboxType

    @ReceivingMailboxType.setter
    def ReceivingMailboxType(self, ReceivingMailboxType):
        self._ReceivingMailboxType = ReceivingMailboxType


    def _deserialize(self, params):
        self._StartDate = params.get("StartDate")
        self._EndDate = params.get("EndDate")
        self._Domain = params.get("Domain")
        self._ReceivingMailboxType = params.get("ReceivingMailboxType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GetStatisticsReportResponse(AbstractModel):
    r"""GetStatisticsReport response structure.

    """

    def __init__(self):
        r"""
        :param _DailyVolumes: Daily email sending statistics.
        :type DailyVolumes: list of Volume
        :param _OverallVolume: Overall email sending statistics.
        :type OverallVolume: :class:`tencentcloud.ses.v20201002.models.Volume`
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._DailyVolumes = None
        self._OverallVolume = None
        self._RequestId = None

    @property
    def DailyVolumes(self):
        r"""Daily email sending statistics.
        :rtype: list of Volume
        """
        return self._DailyVolumes

    @DailyVolumes.setter
    def DailyVolumes(self, DailyVolumes):
        self._DailyVolumes = DailyVolumes

    @property
    def OverallVolume(self):
        r"""Overall email sending statistics.
        :rtype: :class:`tencentcloud.ses.v20201002.models.Volume`
        """
        return self._OverallVolume

    @OverallVolume.setter
    def OverallVolume(self, OverallVolume):
        self._OverallVolume = OverallVolume

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("DailyVolumes") is not None:
            self._DailyVolumes = []
            for item in params.get("DailyVolumes"):
                obj = Volume()
                obj._deserialize(item)
                self._DailyVolumes.append(obj)
        if params.get("OverallVolume") is not None:
            self._OverallVolume = Volume()
            self._OverallVolume._deserialize(params.get("OverallVolume"))
        self._RequestId = params.get("RequestId")


class ListAddressUnsubscribeConfigRequest(AbstractModel):
    r"""ListAddressUnsubscribeConfig request structure.

    """

    def __init__(self):
        r"""
        :param _Offset: Offset.
        :type Offset: int
        :param _Limit: specifies the maximum number of entries to retrieve, with a cap of 100.
        :type Limit: str
        """
        self._Offset = None
        self._Limit = None

    @property
    def Offset(self):
        r"""Offset.
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def Limit(self):
        r"""specifies the maximum number of entries to retrieve, with a cap of 100.
        :rtype: str
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit


    def _deserialize(self, params):
        self._Offset = params.get("Offset")
        self._Limit = params.get("Limit")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ListAddressUnsubscribeConfigResponse(AbstractModel):
    r"""ListAddressUnsubscribeConfig response structure.

    """

    def __init__(self):
        r"""
        :param _AddressUnsubscribeConfigList: Address-Level unsubscribe configuration.
        :type AddressUnsubscribeConfigList: list of AddressUnsubscribeConfigData
        :param _Total: Total number.
        :type Total: int
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._AddressUnsubscribeConfigList = None
        self._Total = None
        self._RequestId = None

    @property
    def AddressUnsubscribeConfigList(self):
        r"""Address-Level unsubscribe configuration.
        :rtype: list of AddressUnsubscribeConfigData
        """
        return self._AddressUnsubscribeConfigList

    @AddressUnsubscribeConfigList.setter
    def AddressUnsubscribeConfigList(self, AddressUnsubscribeConfigList):
        self._AddressUnsubscribeConfigList = AddressUnsubscribeConfigList

    @property
    def Total(self):
        r"""Total number.
        :rtype: int
        """
        return self._Total

    @Total.setter
    def Total(self, Total):
        self._Total = Total

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("AddressUnsubscribeConfigList") is not None:
            self._AddressUnsubscribeConfigList = []
            for item in params.get("AddressUnsubscribeConfigList"):
                obj = AddressUnsubscribeConfigData()
                obj._deserialize(item)
                self._AddressUnsubscribeConfigList.append(obj)
        self._Total = params.get("Total")
        self._RequestId = params.get("RequestId")


class ListBlackEmailAddressRequest(AbstractModel):
    r"""ListBlackEmailAddress request structure.

    """

    def __init__(self):
        r"""
        :param _StartDate: Start date in the format of `YYYY-MM-DD`
        :type StartDate: str
        :param _EndDate: End date in the format of `YYYY-MM-DD`
        :type EndDate: str
        :param _Limit: Common parameter. It must be used with `Offset`.
        :type Limit: int
        :param _Offset: Common parameter. It must be used with `Limit`. Maximum value of `Limit`: `100`.
        :type Offset: int
        :param _EmailAddress: You can specify an email address to query.
        :type EmailAddress: str
        :param _TaskID: This parameter has been deprecated.
        :type TaskID: str
        """
        self._StartDate = None
        self._EndDate = None
        self._Limit = None
        self._Offset = None
        self._EmailAddress = None
        self._TaskID = None

    @property
    def StartDate(self):
        r"""Start date in the format of `YYYY-MM-DD`
        :rtype: str
        """
        return self._StartDate

    @StartDate.setter
    def StartDate(self, StartDate):
        self._StartDate = StartDate

    @property
    def EndDate(self):
        r"""End date in the format of `YYYY-MM-DD`
        :rtype: str
        """
        return self._EndDate

    @EndDate.setter
    def EndDate(self, EndDate):
        self._EndDate = EndDate

    @property
    def Limit(self):
        r"""Common parameter. It must be used with `Offset`.
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def Offset(self):
        r"""Common parameter. It must be used with `Limit`. Maximum value of `Limit`: `100`.
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def EmailAddress(self):
        r"""You can specify an email address to query.
        :rtype: str
        """
        return self._EmailAddress

    @EmailAddress.setter
    def EmailAddress(self, EmailAddress):
        self._EmailAddress = EmailAddress

    @property
    def TaskID(self):
        r"""This parameter has been deprecated.
        :rtype: str
        """
        return self._TaskID

    @TaskID.setter
    def TaskID(self, TaskID):
        self._TaskID = TaskID


    def _deserialize(self, params):
        self._StartDate = params.get("StartDate")
        self._EndDate = params.get("EndDate")
        self._Limit = params.get("Limit")
        self._Offset = params.get("Offset")
        self._EmailAddress = params.get("EmailAddress")
        self._TaskID = params.get("TaskID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ListBlackEmailAddressResponse(AbstractModel):
    r"""ListBlackEmailAddress response structure.

    """

    def __init__(self):
        r"""
        :param _BlackList: List of blocklisted addresses.
        :type BlackList: list of BlackEmailAddress
        :param _TotalCount: Total number of blocklisted addresses.
        :type TotalCount: int
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._BlackList = None
        self._TotalCount = None
        self._RequestId = None

    @property
    def BlackList(self):
        r"""List of blocklisted addresses.
        :rtype: list of BlackEmailAddress
        """
        return self._BlackList

    @BlackList.setter
    def BlackList(self, BlackList):
        self._BlackList = BlackList

    @property
    def TotalCount(self):
        r"""Total number of blocklisted addresses.
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("BlackList") is not None:
            self._BlackList = []
            for item in params.get("BlackList"):
                obj = BlackEmailAddress()
                obj._deserialize(item)
                self._BlackList.append(obj)
        self._TotalCount = params.get("TotalCount")
        self._RequestId = params.get("RequestId")


class ListCustomBlacklistRequest(AbstractModel):
    r"""ListCustomBlacklist request structure.

    """

    def __init__(self):
        r"""
        :param _Offset: Offset, int, starts from 0.
        :type Offset: int
        :param _Limit: Number limit, int, no more than 100.
        :type Limit: int
        :param _Status: Filter the state of the blocklist. valid values: 0 (expired), 1 (active), 2 (all).
        :type Status: int
        :param _Email: Email address in blocklist.
        :type Email: str
        """
        self._Offset = None
        self._Limit = None
        self._Status = None
        self._Email = None

    @property
    def Offset(self):
        r"""Offset, int, starts from 0.
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def Limit(self):
        r"""Number limit, int, no more than 100.
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def Status(self):
        r"""Filter the state of the blocklist. valid values: 0 (expired), 1 (active), 2 (all).
        :rtype: int
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def Email(self):
        r"""Email address in blocklist.
        :rtype: str
        """
        return self._Email

    @Email.setter
    def Email(self, Email):
        self._Email = Email


    def _deserialize(self, params):
        self._Offset = params.get("Offset")
        self._Limit = params.get("Limit")
        self._Status = params.get("Status")
        self._Email = params.get("Email")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ListCustomBlacklistResponse(AbstractModel):
    r"""ListCustomBlacklist response structure.

    """

    def __init__(self):
        r"""
        :param _TotalCount: Total Quantity of Lists
        :type TotalCount: int
        :param _Data: Blocklist description.
        :type Data: list of BlackAddressDetail
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._TotalCount = None
        self._Data = None
        self._RequestId = None

    @property
    def TotalCount(self):
        r"""Total Quantity of Lists
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def Data(self):
        r"""Blocklist description.
        :rtype: list of BlackAddressDetail
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._TotalCount = params.get("TotalCount")
        if params.get("Data") is not None:
            self._Data = []
            for item in params.get("Data"):
                obj = BlackAddressDetail()
                obj._deserialize(item)
                self._Data.append(obj)
        self._RequestId = params.get("RequestId")


class ListEmailAddressRequest(AbstractModel):
    r"""ListEmailAddress request structure.

    """


class ListEmailAddressResponse(AbstractModel):
    r"""ListEmailAddress response structure.

    """

    def __init__(self):
        r"""
        :param _EmailSenders: List of sender addresses description.
        :type EmailSenders: list of EmailSender
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._EmailSenders = None
        self._RequestId = None

    @property
    def EmailSenders(self):
        r"""List of sender addresses description.
        :rtype: list of EmailSender
        """
        return self._EmailSenders

    @EmailSenders.setter
    def EmailSenders(self, EmailSenders):
        self._EmailSenders = EmailSenders

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("EmailSenders") is not None:
            self._EmailSenders = []
            for item in params.get("EmailSenders"):
                obj = EmailSender()
                obj._deserialize(item)
                self._EmailSenders.append(obj)
        self._RequestId = params.get("RequestId")


class ListEmailIdentitiesRequest(AbstractModel):
    r"""ListEmailIdentities request structure.

    """

    def __init__(self):
        r"""
        :param _TagList: tag.
        :type TagList: list of TagList
        :param _Limit: Pagination limit.
        :type Limit: int
        :param _Offset: Paging offset.
        :type Offset: int
        """
        self._TagList = None
        self._Limit = None
        self._Offset = None

    @property
    def TagList(self):
        r"""tag.
        :rtype: list of TagList
        """
        return self._TagList

    @TagList.setter
    def TagList(self, TagList):
        self._TagList = TagList

    @property
    def Limit(self):
        r"""Pagination limit.
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def Offset(self):
        r"""Paging offset.
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset


    def _deserialize(self, params):
        if params.get("TagList") is not None:
            self._TagList = []
            for item in params.get("TagList"):
                obj = TagList()
                obj._deserialize(item)
                self._TagList.append(obj)
        self._Limit = params.get("Limit")
        self._Offset = params.get("Offset")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ListEmailIdentitiesResponse(AbstractModel):
    r"""ListEmailIdentities response structure.

    """

    def __init__(self):
        r"""
        :param _EmailIdentities: List of sender domains.
        :type EmailIdentities: list of EmailIdentity
        :param _MaxReputationLevel: Maximum reputation level
        :type MaxReputationLevel: int
        :param _MaxDailyQuota: Maximum number of emails sent per domain name
        :type MaxDailyQuota: int
        :param _Total: Total number.
        :type Total: int
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._EmailIdentities = None
        self._MaxReputationLevel = None
        self._MaxDailyQuota = None
        self._Total = None
        self._RequestId = None

    @property
    def EmailIdentities(self):
        r"""List of sender domains.
        :rtype: list of EmailIdentity
        """
        return self._EmailIdentities

    @EmailIdentities.setter
    def EmailIdentities(self, EmailIdentities):
        self._EmailIdentities = EmailIdentities

    @property
    def MaxReputationLevel(self):
        r"""Maximum reputation level
        :rtype: int
        """
        return self._MaxReputationLevel

    @MaxReputationLevel.setter
    def MaxReputationLevel(self, MaxReputationLevel):
        self._MaxReputationLevel = MaxReputationLevel

    @property
    def MaxDailyQuota(self):
        r"""Maximum number of emails sent per domain name
        :rtype: int
        """
        return self._MaxDailyQuota

    @MaxDailyQuota.setter
    def MaxDailyQuota(self, MaxDailyQuota):
        self._MaxDailyQuota = MaxDailyQuota

    @property
    def Total(self):
        r"""Total number.
        :rtype: int
        """
        return self._Total

    @Total.setter
    def Total(self, Total):
        self._Total = Total

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("EmailIdentities") is not None:
            self._EmailIdentities = []
            for item in params.get("EmailIdentities"):
                obj = EmailIdentity()
                obj._deserialize(item)
                self._EmailIdentities.append(obj)
        self._MaxReputationLevel = params.get("MaxReputationLevel")
        self._MaxDailyQuota = params.get("MaxDailyQuota")
        self._Total = params.get("Total")
        self._RequestId = params.get("RequestId")


class ListEmailTemplatesRequest(AbstractModel):
    r"""ListEmailTemplates request structure.

    """

    def __init__(self):
        r"""
        :param _Limit: Number of templates to get. This parameter is used for pagination.
        :type Limit: int
        :param _Offset: Template offset to get. This parameter is used for pagination.
        :type Offset: int
        """
        self._Limit = None
        self._Offset = None

    @property
    def Limit(self):
        r"""Number of templates to get. This parameter is used for pagination.
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def Offset(self):
        r"""Template offset to get. This parameter is used for pagination.
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset


    def _deserialize(self, params):
        self._Limit = params.get("Limit")
        self._Offset = params.get("Offset")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ListEmailTemplatesResponse(AbstractModel):
    r"""ListEmailTemplates response structure.

    """

    def __init__(self):
        r"""
        :param _TemplatesMetadata: List of email templates.
        :type TemplatesMetadata: list of TemplatesMetadata
        :param _TotalCount: Total number of templates
        :type TotalCount: int
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._TemplatesMetadata = None
        self._TotalCount = None
        self._RequestId = None

    @property
    def TemplatesMetadata(self):
        r"""List of email templates.
        :rtype: list of TemplatesMetadata
        """
        return self._TemplatesMetadata

    @TemplatesMetadata.setter
    def TemplatesMetadata(self, TemplatesMetadata):
        self._TemplatesMetadata = TemplatesMetadata

    @property
    def TotalCount(self):
        r"""Total number of templates
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("TemplatesMetadata") is not None:
            self._TemplatesMetadata = []
            for item in params.get("TemplatesMetadata"):
                obj = TemplatesMetadata()
                obj._deserialize(item)
                self._TemplatesMetadata.append(obj)
        self._TotalCount = params.get("TotalCount")
        self._RequestId = params.get("RequestId")


class ListReceiverDetailsRequest(AbstractModel):
    r"""ListReceiverDetails request structure.

    """

    def __init__(self):
        r"""
        :param _ReceiverId: Recipient list ID. specifies the value returned during API creation of a recipient list via the CreateReceiver api.
        :type ReceiverId: int
        :param _Offset: Offset, int, starts from 0.
        :type Offset: int
        :param _Limit: Number limit, int, no more than 100.
        :type Limit: int
        :param _Email: Recipient address. length: 0-50. example: xxx@te.com. fuzzy query is supported.
        :type Email: str
        :param _CreateTimeBegin: Find start time.
        :type CreateTimeBegin: str
        :param _CreateTimeEnd: Search end time.
        :type CreateTimeEnd: str
        :param _Status: 1: valid; 2: invalid.
        :type Status: int
        """
        self._ReceiverId = None
        self._Offset = None
        self._Limit = None
        self._Email = None
        self._CreateTimeBegin = None
        self._CreateTimeEnd = None
        self._Status = None

    @property
    def ReceiverId(self):
        r"""Recipient list ID. specifies the value returned during API creation of a recipient list via the CreateReceiver api.
        :rtype: int
        """
        return self._ReceiverId

    @ReceiverId.setter
    def ReceiverId(self, ReceiverId):
        self._ReceiverId = ReceiverId

    @property
    def Offset(self):
        r"""Offset, int, starts from 0.
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def Limit(self):
        r"""Number limit, int, no more than 100.
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def Email(self):
        r"""Recipient address. length: 0-50. example: xxx@te.com. fuzzy query is supported.
        :rtype: str
        """
        return self._Email

    @Email.setter
    def Email(self, Email):
        self._Email = Email

    @property
    def CreateTimeBegin(self):
        r"""Find start time.
        :rtype: str
        """
        return self._CreateTimeBegin

    @CreateTimeBegin.setter
    def CreateTimeBegin(self, CreateTimeBegin):
        self._CreateTimeBegin = CreateTimeBegin

    @property
    def CreateTimeEnd(self):
        r"""Search end time.
        :rtype: str
        """
        return self._CreateTimeEnd

    @CreateTimeEnd.setter
    def CreateTimeEnd(self, CreateTimeEnd):
        self._CreateTimeEnd = CreateTimeEnd

    @property
    def Status(self):
        r"""1: valid; 2: invalid.
        :rtype: int
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status


    def _deserialize(self, params):
        self._ReceiverId = params.get("ReceiverId")
        self._Offset = params.get("Offset")
        self._Limit = params.get("Limit")
        self._Email = params.get("Email")
        self._CreateTimeBegin = params.get("CreateTimeBegin")
        self._CreateTimeEnd = params.get("CreateTimeEnd")
        self._Status = params.get("Status")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ListReceiverDetailsResponse(AbstractModel):
    r"""ListReceiverDetails response structure.

    """

    def __init__(self):
        r"""
        :param _TotalCount: Total number.
        :type TotalCount: int
        :param _Data: Data record.
        :type Data: list of ReceiverDetail
        :param _ValidCount: Number of valid email addresses.
        :type ValidCount: int
        :param _InvalidCount: Number of invalid email addresses.
        :type InvalidCount: int
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._TotalCount = None
        self._Data = None
        self._ValidCount = None
        self._InvalidCount = None
        self._RequestId = None

    @property
    def TotalCount(self):
        r"""Total number.
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def Data(self):
        r"""Data record.
        :rtype: list of ReceiverDetail
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def ValidCount(self):
        r"""Number of valid email addresses.
        :rtype: int
        """
        return self._ValidCount

    @ValidCount.setter
    def ValidCount(self, ValidCount):
        self._ValidCount = ValidCount

    @property
    def InvalidCount(self):
        r"""Number of invalid email addresses.
        :rtype: int
        """
        return self._InvalidCount

    @InvalidCount.setter
    def InvalidCount(self, InvalidCount):
        self._InvalidCount = InvalidCount

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._TotalCount = params.get("TotalCount")
        if params.get("Data") is not None:
            self._Data = []
            for item in params.get("Data"):
                obj = ReceiverDetail()
                obj._deserialize(item)
                self._Data.append(obj)
        self._ValidCount = params.get("ValidCount")
        self._InvalidCount = params.get("InvalidCount")
        self._RequestId = params.get("RequestId")


class ListReceiversRequest(AbstractModel):
    r"""ListReceivers request structure.

    """

    def __init__(self):
        r"""
        :param _Offset: Offset, starting from 0. The value is an integer.
        :type Offset: int
        :param _Limit: Number of records to query. The value is an integer not exceeding 100.
        :type Limit: int
        :param _Status: Group status (`1`: to be uploaded; `2` uploading; `3` uploaded). To query groups in all states, do not pass in this parameter.
        :type Status: int
        :param _KeyWord: Group name keyword for fuzzy query
        :type KeyWord: str
        """
        self._Offset = None
        self._Limit = None
        self._Status = None
        self._KeyWord = None

    @property
    def Offset(self):
        r"""Offset, starting from 0. The value is an integer.
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def Limit(self):
        r"""Number of records to query. The value is an integer not exceeding 100.
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def Status(self):
        r"""Group status (`1`: to be uploaded; `2` uploading; `3` uploaded). To query groups in all states, do not pass in this parameter.
        :rtype: int
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def KeyWord(self):
        r"""Group name keyword for fuzzy query
        :rtype: str
        """
        return self._KeyWord

    @KeyWord.setter
    def KeyWord(self, KeyWord):
        self._KeyWord = KeyWord


    def _deserialize(self, params):
        self._Offset = params.get("Offset")
        self._Limit = params.get("Limit")
        self._Status = params.get("Status")
        self._KeyWord = params.get("KeyWord")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ListReceiversResponse(AbstractModel):
    r"""ListReceivers response structure.

    """

    def __init__(self):
        r"""
        :param _TotalCount: Total number
        :type TotalCount: int
        :param _Data: Data record
        :type Data: list of ReceiverData
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._TotalCount = None
        self._Data = None
        self._RequestId = None

    @property
    def TotalCount(self):
        r"""Total number
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def Data(self):
        r"""Data record
        :rtype: list of ReceiverData
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._TotalCount = params.get("TotalCount")
        if params.get("Data") is not None:
            self._Data = []
            for item in params.get("Data"):
                obj = ReceiverData()
                obj._deserialize(item)
                self._Data.append(obj)
        self._RequestId = params.get("RequestId")


class ListSendTasksRequest(AbstractModel):
    r"""ListSendTasks request structure.

    """

    def __init__(self):
        r"""
        :param _Offset: Offset, starting from 0. The value is an integer. `0` means to skip 0 entries.
        :type Offset: int
        :param _Limit: Number of records to query. The value is an integer not exceeding 100.
        :type Limit: int
        :param _Status: Task status. `1`: to start; `5`: sending; `6`: sending suspended today; `7`: sending error; `10`: sent. To query tasks in all states, do not pass in this parameter.
        :type Status: int
        :param _ReceiverId: Recipient group ID
        :type ReceiverId: int
        :param _TaskType: Task type. `1`: immediate; `2`: scheduled; `3`: recurring. To query tasks of all types, do not pass in this parameter.
        :type TaskType: int
        """
        self._Offset = None
        self._Limit = None
        self._Status = None
        self._ReceiverId = None
        self._TaskType = None

    @property
    def Offset(self):
        r"""Offset, starting from 0. The value is an integer. `0` means to skip 0 entries.
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def Limit(self):
        r"""Number of records to query. The value is an integer not exceeding 100.
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def Status(self):
        r"""Task status. `1`: to start; `5`: sending; `6`: sending suspended today; `7`: sending error; `10`: sent. To query tasks in all states, do not pass in this parameter.
        :rtype: int
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def ReceiverId(self):
        r"""Recipient group ID
        :rtype: int
        """
        return self._ReceiverId

    @ReceiverId.setter
    def ReceiverId(self, ReceiverId):
        self._ReceiverId = ReceiverId

    @property
    def TaskType(self):
        r"""Task type. `1`: immediate; `2`: scheduled; `3`: recurring. To query tasks of all types, do not pass in this parameter.
        :rtype: int
        """
        return self._TaskType

    @TaskType.setter
    def TaskType(self, TaskType):
        self._TaskType = TaskType


    def _deserialize(self, params):
        self._Offset = params.get("Offset")
        self._Limit = params.get("Limit")
        self._Status = params.get("Status")
        self._ReceiverId = params.get("ReceiverId")
        self._TaskType = params.get("TaskType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ListSendTasksResponse(AbstractModel):
    r"""ListSendTasks response structure.

    """

    def __init__(self):
        r"""
        :param _TotalCount: Total number
        :type TotalCount: int
        :param _Data: Data record
        :type Data: list of SendTaskData
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._TotalCount = None
        self._Data = None
        self._RequestId = None

    @property
    def TotalCount(self):
        r"""Total number
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def Data(self):
        r"""Data record
        :rtype: list of SendTaskData
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._TotalCount = params.get("TotalCount")
        if params.get("Data") is not None:
            self._Data = []
            for item in params.get("Data"):
                obj = SendTaskData()
                obj._deserialize(item)
                self._Data.append(obj)
        self._RequestId = params.get("RequestId")


class ReceiverData(AbstractModel):
    r"""Recipient group data type

    """

    def __init__(self):
        r"""
        :param _ReceiverId: Recipient group ID
        :type ReceiverId: int
        :param _ReceiversName: Recipient group name
        :type ReceiversName: str
        :param _Count: Total number of recipient email addresses
        :type Count: int
        :param _Desc: Recipient list description.
        :type Desc: str
        :param _ReceiversStatus: List status (1 to be uploaded 2 uploading 3 upload complete).
        :type ReceiversStatus: int
        :param _CreateTime: Creation time, such as 2021-09-28 16:40:35
        :type CreateTime: str
        :param _InvalidCount: Invalid number of recipients.
        :type InvalidCount: int
        """
        self._ReceiverId = None
        self._ReceiversName = None
        self._Count = None
        self._Desc = None
        self._ReceiversStatus = None
        self._CreateTime = None
        self._InvalidCount = None

    @property
    def ReceiverId(self):
        r"""Recipient group ID
        :rtype: int
        """
        return self._ReceiverId

    @ReceiverId.setter
    def ReceiverId(self, ReceiverId):
        self._ReceiverId = ReceiverId

    @property
    def ReceiversName(self):
        r"""Recipient group name
        :rtype: str
        """
        return self._ReceiversName

    @ReceiversName.setter
    def ReceiversName(self, ReceiversName):
        self._ReceiversName = ReceiversName

    @property
    def Count(self):
        r"""Total number of recipient email addresses
        :rtype: int
        """
        return self._Count

    @Count.setter
    def Count(self, Count):
        self._Count = Count

    @property
    def Desc(self):
        r"""Recipient list description.
        :rtype: str
        """
        return self._Desc

    @Desc.setter
    def Desc(self, Desc):
        self._Desc = Desc

    @property
    def ReceiversStatus(self):
        r"""List status (1 to be uploaded 2 uploading 3 upload complete).
        :rtype: int
        """
        return self._ReceiversStatus

    @ReceiversStatus.setter
    def ReceiversStatus(self, ReceiversStatus):
        self._ReceiversStatus = ReceiversStatus

    @property
    def CreateTime(self):
        r"""Creation time, such as 2021-09-28 16:40:35
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def InvalidCount(self):
        r"""Invalid number of recipients.
        :rtype: int
        """
        return self._InvalidCount

    @InvalidCount.setter
    def InvalidCount(self, InvalidCount):
        self._InvalidCount = InvalidCount


    def _deserialize(self, params):
        self._ReceiverId = params.get("ReceiverId")
        self._ReceiversName = params.get("ReceiversName")
        self._Count = params.get("Count")
        self._Desc = params.get("Desc")
        self._ReceiversStatus = params.get("ReceiversStatus")
        self._CreateTime = params.get("CreateTime")
        self._InvalidCount = params.get("InvalidCount")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ReceiverDetail(AbstractModel):
    r"""Recipient list details.

    """

    def __init__(self):
        r"""
        :param _Email: Recipient's address.
        :type Email: str
        :param _CreateTime: Creation time.


        :type CreateTime: str
        :param _TemplateData: Template parameter.
        :type TemplateData: str
        :param _Reason: Invalid reason.
        :type Reason: str
        :param _Status: 1: valid; 2: invalid.
        :type Status: int
        :param _EmailId: Recipient address id.
        :type EmailId: int
        """
        self._Email = None
        self._CreateTime = None
        self._TemplateData = None
        self._Reason = None
        self._Status = None
        self._EmailId = None

    @property
    def Email(self):
        r"""Recipient's address.
        :rtype: str
        """
        return self._Email

    @Email.setter
    def Email(self, Email):
        self._Email = Email

    @property
    def CreateTime(self):
        r"""Creation time.


        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def TemplateData(self):
        r"""Template parameter.
        :rtype: str
        """
        return self._TemplateData

    @TemplateData.setter
    def TemplateData(self, TemplateData):
        self._TemplateData = TemplateData

    @property
    def Reason(self):
        r"""Invalid reason.
        :rtype: str
        """
        return self._Reason

    @Reason.setter
    def Reason(self, Reason):
        self._Reason = Reason

    @property
    def Status(self):
        r"""1: valid; 2: invalid.
        :rtype: int
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def EmailId(self):
        r"""Recipient address id.
        :rtype: int
        """
        return self._EmailId

    @EmailId.setter
    def EmailId(self, EmailId):
        self._EmailId = EmailId


    def _deserialize(self, params):
        self._Email = params.get("Email")
        self._CreateTime = params.get("CreateTime")
        self._TemplateData = params.get("TemplateData")
        self._Reason = params.get("Reason")
        self._Status = params.get("Status")
        self._EmailId = params.get("EmailId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ReceiverInputData(AbstractModel):
    r"""Recipient details input parameter, including recipient email and template parameter.

    """

    def __init__(self):
        r"""
        :param _Email: Recipient email.
        :type Email: str
        :param _TemplateData: For variable parameters in template, please use json.dump to format the json object into string type. the object is a set of Key-value pairs. each Key represents a variable in template. variable usage in template is represented by {{Key}}. the appropriate value will be replaced with {{value}} when sent.
Note: the parameter value cannot be data of complex type such as html. the entire JSON structure of TemplateData has a length limit of 800 bytes.
        :type TemplateData: str
        """
        self._Email = None
        self._TemplateData = None

    @property
    def Email(self):
        r"""Recipient email.
        :rtype: str
        """
        return self._Email

    @Email.setter
    def Email(self, Email):
        self._Email = Email

    @property
    def TemplateData(self):
        r"""For variable parameters in template, please use json.dump to format the json object into string type. the object is a set of Key-value pairs. each Key represents a variable in template. variable usage in template is represented by {{Key}}. the appropriate value will be replaced with {{value}} when sent.
Note: the parameter value cannot be data of complex type such as html. the entire JSON structure of TemplateData has a length limit of 800 bytes.
        :rtype: str
        """
        return self._TemplateData

    @TemplateData.setter
    def TemplateData(self, TemplateData):
        self._TemplateData = TemplateData


    def _deserialize(self, params):
        self._Email = params.get("Email")
        self._TemplateData = params.get("TemplateData")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class SendEmailRequest(AbstractModel):
    r"""SendEmail request structure.

    """

    def __init__(self):
        r"""
        :param _FromEmailAddress: Sender'S email address. when not using an alias, enter the sender's email address directly, for example: noreply@mail.qcloud.com. to enter a sender alias, follow this format (note that a space must separate the alias and email address): alias+space+<email address>. the alias cannot contain a colon (:).
        :type FromEmailAddress: str
        :param _Destination: Recipient email address, supports up to 50 recipients in mass sending. note: the email content displays all recipient addresses. for non-mass sending, call the API multiple times to send.
        :type Destination: list of str
        :param _Subject: Email subject.
        :type Subject: str
        :param _ReplyToAddresses: The "reply" email address of the mail. can be filled with an email address where you can receive mail, which can be a personal mailbox. if left empty, the recipient's reply mail will fail to send.
        :type ReplyToAddresses: str
        :param _Cc: Cc recipient email address, supports up to 20 carbon copies.
        :type Cc: list of str
        :param _Bcc: Bcc email address, supports up to 20 carbon copies. Bcc and Destination must be unique.
        :type Bcc: list of str
        :param _Template: Use template for sending and fill in related parameters.
<dx-alert infotype="notice" title="note">this field must be specified if you have not applied for special configuration.</dx-alert>.
        :type Template: :class:`tencentcloud.ses.v20201002.models.Template`
        :param _Simple: This parameter has been deprecated.
<dx-alert infotype="notice" title="description"> only customers who have applied for special configuration in the past need to use this. if you have not applied for special configuration, this field does not exist.</dx-alert>.
        :type Simple: :class:`tencentcloud.ses.v20201002.models.Simple`
        :param _Attachments: When sending an attachment, fill in the related parameters. the tencent cloud API request supports a maximum of 8M request packet. the attachment content transits Base64 and is expected to expand by 1.5 times. you should control the total size of all attachments within 4M. the API will return an error if the overall request exceeds 8M.
        :type Attachments: list of Attachment
        :param _Unsubscribe: Unsubscription link options 0: do not add unsubscription link 1: english 2: simplified chinese 3: traditional chinese 4: spanish 5: french 6: german 7: japanese 8: korean 9: arabic 10: thai.
        :type Unsubscribe: str
        :param _TriggerType: Mail trigger type. 0: non-trigger class, default type, select this type for marketing emails and non-instant emails. 1: trigger class, instant delivery emails such as captcha-intl. if the mail exceeds a certain size, the system will automatically select the non-trigger class channel.
        :type TriggerType: int
        :param _SmtpMessageId: Message-Id field in the smtp header.
        :type SmtpMessageId: str
        :param _SmtpHeaders: Other fields that can be set in the smtp header.
        :type SmtpHeaders: str
        :param _HeaderFrom: from field in the smtp header. the domain name should be consistent with FromEmailAddress.
        :type HeaderFrom: str
        """
        self._FromEmailAddress = None
        self._Destination = None
        self._Subject = None
        self._ReplyToAddresses = None
        self._Cc = None
        self._Bcc = None
        self._Template = None
        self._Simple = None
        self._Attachments = None
        self._Unsubscribe = None
        self._TriggerType = None
        self._SmtpMessageId = None
        self._SmtpHeaders = None
        self._HeaderFrom = None

    @property
    def FromEmailAddress(self):
        r"""Sender'S email address. when not using an alias, enter the sender's email address directly, for example: noreply@mail.qcloud.com. to enter a sender alias, follow this format (note that a space must separate the alias and email address): alias+space+<email address>. the alias cannot contain a colon (:).
        :rtype: str
        """
        return self._FromEmailAddress

    @FromEmailAddress.setter
    def FromEmailAddress(self, FromEmailAddress):
        self._FromEmailAddress = FromEmailAddress

    @property
    def Destination(self):
        r"""Recipient email address, supports up to 50 recipients in mass sending. note: the email content displays all recipient addresses. for non-mass sending, call the API multiple times to send.
        :rtype: list of str
        """
        return self._Destination

    @Destination.setter
    def Destination(self, Destination):
        self._Destination = Destination

    @property
    def Subject(self):
        r"""Email subject.
        :rtype: str
        """
        return self._Subject

    @Subject.setter
    def Subject(self, Subject):
        self._Subject = Subject

    @property
    def ReplyToAddresses(self):
        r"""The "reply" email address of the mail. can be filled with an email address where you can receive mail, which can be a personal mailbox. if left empty, the recipient's reply mail will fail to send.
        :rtype: str
        """
        return self._ReplyToAddresses

    @ReplyToAddresses.setter
    def ReplyToAddresses(self, ReplyToAddresses):
        self._ReplyToAddresses = ReplyToAddresses

    @property
    def Cc(self):
        r"""Cc recipient email address, supports up to 20 carbon copies.
        :rtype: list of str
        """
        return self._Cc

    @Cc.setter
    def Cc(self, Cc):
        self._Cc = Cc

    @property
    def Bcc(self):
        r"""Bcc email address, supports up to 20 carbon copies. Bcc and Destination must be unique.
        :rtype: list of str
        """
        return self._Bcc

    @Bcc.setter
    def Bcc(self, Bcc):
        self._Bcc = Bcc

    @property
    def Template(self):
        r"""Use template for sending and fill in related parameters.
<dx-alert infotype="notice" title="note">this field must be specified if you have not applied for special configuration.</dx-alert>.
        :rtype: :class:`tencentcloud.ses.v20201002.models.Template`
        """
        return self._Template

    @Template.setter
    def Template(self, Template):
        self._Template = Template

    @property
    def Simple(self):
        r"""This parameter has been deprecated.
<dx-alert infotype="notice" title="description"> only customers who have applied for special configuration in the past need to use this. if you have not applied for special configuration, this field does not exist.</dx-alert>.
        :rtype: :class:`tencentcloud.ses.v20201002.models.Simple`
        """
        return self._Simple

    @Simple.setter
    def Simple(self, Simple):
        self._Simple = Simple

    @property
    def Attachments(self):
        r"""When sending an attachment, fill in the related parameters. the tencent cloud API request supports a maximum of 8M request packet. the attachment content transits Base64 and is expected to expand by 1.5 times. you should control the total size of all attachments within 4M. the API will return an error if the overall request exceeds 8M.
        :rtype: list of Attachment
        """
        return self._Attachments

    @Attachments.setter
    def Attachments(self, Attachments):
        self._Attachments = Attachments

    @property
    def Unsubscribe(self):
        r"""Unsubscription link options 0: do not add unsubscription link 1: english 2: simplified chinese 3: traditional chinese 4: spanish 5: french 6: german 7: japanese 8: korean 9: arabic 10: thai.
        :rtype: str
        """
        return self._Unsubscribe

    @Unsubscribe.setter
    def Unsubscribe(self, Unsubscribe):
        self._Unsubscribe = Unsubscribe

    @property
    def TriggerType(self):
        r"""Mail trigger type. 0: non-trigger class, default type, select this type for marketing emails and non-instant emails. 1: trigger class, instant delivery emails such as captcha-intl. if the mail exceeds a certain size, the system will automatically select the non-trigger class channel.
        :rtype: int
        """
        return self._TriggerType

    @TriggerType.setter
    def TriggerType(self, TriggerType):
        self._TriggerType = TriggerType

    @property
    def SmtpMessageId(self):
        r"""Message-Id field in the smtp header.
        :rtype: str
        """
        return self._SmtpMessageId

    @SmtpMessageId.setter
    def SmtpMessageId(self, SmtpMessageId):
        self._SmtpMessageId = SmtpMessageId

    @property
    def SmtpHeaders(self):
        r"""Other fields that can be set in the smtp header.
        :rtype: str
        """
        return self._SmtpHeaders

    @SmtpHeaders.setter
    def SmtpHeaders(self, SmtpHeaders):
        self._SmtpHeaders = SmtpHeaders

    @property
    def HeaderFrom(self):
        r"""from field in the smtp header. the domain name should be consistent with FromEmailAddress.
        :rtype: str
        """
        return self._HeaderFrom

    @HeaderFrom.setter
    def HeaderFrom(self, HeaderFrom):
        self._HeaderFrom = HeaderFrom


    def _deserialize(self, params):
        self._FromEmailAddress = params.get("FromEmailAddress")
        self._Destination = params.get("Destination")
        self._Subject = params.get("Subject")
        self._ReplyToAddresses = params.get("ReplyToAddresses")
        self._Cc = params.get("Cc")
        self._Bcc = params.get("Bcc")
        if params.get("Template") is not None:
            self._Template = Template()
            self._Template._deserialize(params.get("Template"))
        if params.get("Simple") is not None:
            self._Simple = Simple()
            self._Simple._deserialize(params.get("Simple"))
        if params.get("Attachments") is not None:
            self._Attachments = []
            for item in params.get("Attachments"):
                obj = Attachment()
                obj._deserialize(item)
                self._Attachments.append(obj)
        self._Unsubscribe = params.get("Unsubscribe")
        self._TriggerType = params.get("TriggerType")
        self._SmtpMessageId = params.get("SmtpMessageId")
        self._SmtpHeaders = params.get("SmtpHeaders")
        self._HeaderFrom = params.get("HeaderFrom")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class SendEmailResponse(AbstractModel):
    r"""SendEmail response structure.

    """

    def __init__(self):
        r"""
        :param _MessageId: Uniquely generated message identifier for receive message.
        :type MessageId: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._MessageId = None
        self._RequestId = None

    @property
    def MessageId(self):
        r"""Uniquely generated message identifier for receive message.
        :rtype: str
        """
        return self._MessageId

    @MessageId.setter
    def MessageId(self, MessageId):
        self._MessageId = MessageId

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._MessageId = params.get("MessageId")
        self._RequestId = params.get("RequestId")


class SendEmailStatus(AbstractModel):
    r"""Describes the email sending status

    """

    def __init__(self):
        r"""
        :param _MessageId: The `MessageId` field returned by the `SendEmail` API
        :type MessageId: str
        :param _ToEmailAddress: Recipient email address
        :type ToEmailAddress: str
        :param _FromEmailAddress: Sender email address
        :type FromEmailAddress: str
        :param _SendStatus: Tencent Cloud processing status
0: Successful.
1001: Internal system exception.
1002: Internal system exception.
1003: Internal system exception.
1003: Internal system exception.
1004: Email sending timed out.
1005: Internal system exception.
1006: You have sent too many emails to the same address in a short period.
1007: The email address is in the blocklist.
1008: The sender domain is rejected by the recipient.
1009: Internal system exception.
1010: The daily email sending limit is exceeded.
1011: You have no permission to send custom content. Use a template.
1013: The sender domain is unsubscribed from by the recipient.
2001: No results were found.
3007: The template ID is invalid or the template is unavailable.
3008: The sender domain is temporarily blocked by the recipient domain.
3009: You have no permission to use this template.
3010: The format of the `TemplateData` field is incorrect. 
3014: The email cannot be sent because the sender domain is not verified.
3020: The recipient email address is in the blocklist.
3024: Failed to precheck the email address format.
3030: Email sending is restricted temporarily due to a high bounce rate.
3033: The account has insufficient balance or overdue payment.
        :type SendStatus: int
        :param _DeliverStatus: Recipient processing status
0: Tencent Cloud has accepted the request and added it to the send queue.
1: The email is delivered successfully. `DeliverTime` indicates the time when the email is delivered successfully.
2: The email is discarded. `DeliverMessage` indicates the reason for discarding.
3: The recipient's ESP rejects the email, probably because the email address does not exist or due to other reasons.
8: The email is delayed by the ESP. `DeliverMessage` indicates the reason for delay.
        :type DeliverStatus: int
        :param _DeliverMessage: Description of the recipient processing status
        :type DeliverMessage: str
        :param _RequestTime: Timestamp when the request arrives at Tencent Cloud
        :type RequestTime: int
        :param _DeliverTime: Timestamp when Tencent Cloud delivers the email
        :type DeliverTime: int
        :param _UserOpened: Whether the recipient has opened the email
        :type UserOpened: bool
        :param _UserClicked: Whether the recipient has clicked the links in the email
        :type UserClicked: bool
        :param _UserUnsubscribed: Whether the recipient has unsubscribed from the email sent by the sender
        :type UserUnsubscribed: bool
        :param _UserComplainted: Whether the recipient has reported the sender
        :type UserComplainted: bool
        :param _UserComplained: Whether the user reports the sender.
        :type UserComplained: bool
        """
        self._MessageId = None
        self._ToEmailAddress = None
        self._FromEmailAddress = None
        self._SendStatus = None
        self._DeliverStatus = None
        self._DeliverMessage = None
        self._RequestTime = None
        self._DeliverTime = None
        self._UserOpened = None
        self._UserClicked = None
        self._UserUnsubscribed = None
        self._UserComplainted = None
        self._UserComplained = None

    @property
    def MessageId(self):
        r"""The `MessageId` field returned by the `SendEmail` API
        :rtype: str
        """
        return self._MessageId

    @MessageId.setter
    def MessageId(self, MessageId):
        self._MessageId = MessageId

    @property
    def ToEmailAddress(self):
        r"""Recipient email address
        :rtype: str
        """
        return self._ToEmailAddress

    @ToEmailAddress.setter
    def ToEmailAddress(self, ToEmailAddress):
        self._ToEmailAddress = ToEmailAddress

    @property
    def FromEmailAddress(self):
        r"""Sender email address
        :rtype: str
        """
        return self._FromEmailAddress

    @FromEmailAddress.setter
    def FromEmailAddress(self, FromEmailAddress):
        self._FromEmailAddress = FromEmailAddress

    @property
    def SendStatus(self):
        r"""Tencent Cloud processing status
0: Successful.
1001: Internal system exception.
1002: Internal system exception.
1003: Internal system exception.
1003: Internal system exception.
1004: Email sending timed out.
1005: Internal system exception.
1006: You have sent too many emails to the same address in a short period.
1007: The email address is in the blocklist.
1008: The sender domain is rejected by the recipient.
1009: Internal system exception.
1010: The daily email sending limit is exceeded.
1011: You have no permission to send custom content. Use a template.
1013: The sender domain is unsubscribed from by the recipient.
2001: No results were found.
3007: The template ID is invalid or the template is unavailable.
3008: The sender domain is temporarily blocked by the recipient domain.
3009: You have no permission to use this template.
3010: The format of the `TemplateData` field is incorrect. 
3014: The email cannot be sent because the sender domain is not verified.
3020: The recipient email address is in the blocklist.
3024: Failed to precheck the email address format.
3030: Email sending is restricted temporarily due to a high bounce rate.
3033: The account has insufficient balance or overdue payment.
        :rtype: int
        """
        return self._SendStatus

    @SendStatus.setter
    def SendStatus(self, SendStatus):
        self._SendStatus = SendStatus

    @property
    def DeliverStatus(self):
        r"""Recipient processing status
0: Tencent Cloud has accepted the request and added it to the send queue.
1: The email is delivered successfully. `DeliverTime` indicates the time when the email is delivered successfully.
2: The email is discarded. `DeliverMessage` indicates the reason for discarding.
3: The recipient's ESP rejects the email, probably because the email address does not exist or due to other reasons.
8: The email is delayed by the ESP. `DeliverMessage` indicates the reason for delay.
        :rtype: int
        """
        return self._DeliverStatus

    @DeliverStatus.setter
    def DeliverStatus(self, DeliverStatus):
        self._DeliverStatus = DeliverStatus

    @property
    def DeliverMessage(self):
        r"""Description of the recipient processing status
        :rtype: str
        """
        return self._DeliverMessage

    @DeliverMessage.setter
    def DeliverMessage(self, DeliverMessage):
        self._DeliverMessage = DeliverMessage

    @property
    def RequestTime(self):
        r"""Timestamp when the request arrives at Tencent Cloud
        :rtype: int
        """
        return self._RequestTime

    @RequestTime.setter
    def RequestTime(self, RequestTime):
        self._RequestTime = RequestTime

    @property
    def DeliverTime(self):
        r"""Timestamp when Tencent Cloud delivers the email
        :rtype: int
        """
        return self._DeliverTime

    @DeliverTime.setter
    def DeliverTime(self, DeliverTime):
        self._DeliverTime = DeliverTime

    @property
    def UserOpened(self):
        r"""Whether the recipient has opened the email
        :rtype: bool
        """
        return self._UserOpened

    @UserOpened.setter
    def UserOpened(self, UserOpened):
        self._UserOpened = UserOpened

    @property
    def UserClicked(self):
        r"""Whether the recipient has clicked the links in the email
        :rtype: bool
        """
        return self._UserClicked

    @UserClicked.setter
    def UserClicked(self, UserClicked):
        self._UserClicked = UserClicked

    @property
    def UserUnsubscribed(self):
        r"""Whether the recipient has unsubscribed from the email sent by the sender
        :rtype: bool
        """
        return self._UserUnsubscribed

    @UserUnsubscribed.setter
    def UserUnsubscribed(self, UserUnsubscribed):
        self._UserUnsubscribed = UserUnsubscribed

    @property
    def UserComplainted(self):
        warnings.warn("parameter `UserComplainted` is deprecated", DeprecationWarning) 

        r"""Whether the recipient has reported the sender
        :rtype: bool
        """
        return self._UserComplainted

    @UserComplainted.setter
    def UserComplainted(self, UserComplainted):
        warnings.warn("parameter `UserComplainted` is deprecated", DeprecationWarning) 

        self._UserComplainted = UserComplainted

    @property
    def UserComplained(self):
        r"""Whether the user reports the sender.
        :rtype: bool
        """
        return self._UserComplained

    @UserComplained.setter
    def UserComplained(self, UserComplained):
        self._UserComplained = UserComplained


    def _deserialize(self, params):
        self._MessageId = params.get("MessageId")
        self._ToEmailAddress = params.get("ToEmailAddress")
        self._FromEmailAddress = params.get("FromEmailAddress")
        self._SendStatus = params.get("SendStatus")
        self._DeliverStatus = params.get("DeliverStatus")
        self._DeliverMessage = params.get("DeliverMessage")
        self._RequestTime = params.get("RequestTime")
        self._DeliverTime = params.get("DeliverTime")
        self._UserOpened = params.get("UserOpened")
        self._UserClicked = params.get("UserClicked")
        self._UserUnsubscribed = params.get("UserUnsubscribed")
        self._UserComplainted = params.get("UserComplainted")
        self._UserComplained = params.get("UserComplained")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class SendTaskData(AbstractModel):
    r"""Email sending task data

    """

    def __init__(self):
        r"""
        :param _TaskId: Task ID
        :type TaskId: int
        :param _FromEmailAddress: Sender address
        :type FromEmailAddress: str
        :param _ReceiverId: Recipient group ID
        :type ReceiverId: int
        :param _TaskStatus: Task status. `1`: to start; `5`: sending; `6`: sending suspended today; `7`: sending error; `10`: sent
        :type TaskStatus: int
        :param _TaskType: Task type. `1`: immediate; `2`: scheduled; `3`: recurring
        :type TaskType: int
        :param _RequestCount: Number of emails requested to be sent
        :type RequestCount: int
        :param _SendCount: Number of emails sent
        :type SendCount: int
        :param _CacheCount: Number of emails cached
        :type CacheCount: int
        :param _CreateTime: Task creation time
        :type CreateTime: str
        :param _UpdateTime: Task update time
        :type UpdateTime: str
        :param _Subject: Email subject
        :type Subject: str
        :param _Template: Template and template data.
        :type Template: :class:`tencentcloud.ses.v20201002.models.Template`
        :param _CycleParam: Parameters of a recurring task
Note: This field may return `null`, indicating that no valid value can be found.
        :type CycleParam: :class:`tencentcloud.ses.v20201002.models.CycleEmailParam`
        :param _TimedParam: Parameters of a scheduled task
Note: This field may return `null`, indicating that no valid value can be found.
        :type TimedParam: :class:`tencentcloud.ses.v20201002.models.TimedEmailParam`
        :param _ErrMsg: Task exception information.
        :type ErrMsg: str
        :param _ReceiversName: Recipient group name
        :type ReceiversName: str
        """
        self._TaskId = None
        self._FromEmailAddress = None
        self._ReceiverId = None
        self._TaskStatus = None
        self._TaskType = None
        self._RequestCount = None
        self._SendCount = None
        self._CacheCount = None
        self._CreateTime = None
        self._UpdateTime = None
        self._Subject = None
        self._Template = None
        self._CycleParam = None
        self._TimedParam = None
        self._ErrMsg = None
        self._ReceiversName = None

    @property
    def TaskId(self):
        r"""Task ID
        :rtype: int
        """
        return self._TaskId

    @TaskId.setter
    def TaskId(self, TaskId):
        self._TaskId = TaskId

    @property
    def FromEmailAddress(self):
        r"""Sender address
        :rtype: str
        """
        return self._FromEmailAddress

    @FromEmailAddress.setter
    def FromEmailAddress(self, FromEmailAddress):
        self._FromEmailAddress = FromEmailAddress

    @property
    def ReceiverId(self):
        r"""Recipient group ID
        :rtype: int
        """
        return self._ReceiverId

    @ReceiverId.setter
    def ReceiverId(self, ReceiverId):
        self._ReceiverId = ReceiverId

    @property
    def TaskStatus(self):
        r"""Task status. `1`: to start; `5`: sending; `6`: sending suspended today; `7`: sending error; `10`: sent
        :rtype: int
        """
        return self._TaskStatus

    @TaskStatus.setter
    def TaskStatus(self, TaskStatus):
        self._TaskStatus = TaskStatus

    @property
    def TaskType(self):
        r"""Task type. `1`: immediate; `2`: scheduled; `3`: recurring
        :rtype: int
        """
        return self._TaskType

    @TaskType.setter
    def TaskType(self, TaskType):
        self._TaskType = TaskType

    @property
    def RequestCount(self):
        r"""Number of emails requested to be sent
        :rtype: int
        """
        return self._RequestCount

    @RequestCount.setter
    def RequestCount(self, RequestCount):
        self._RequestCount = RequestCount

    @property
    def SendCount(self):
        r"""Number of emails sent
        :rtype: int
        """
        return self._SendCount

    @SendCount.setter
    def SendCount(self, SendCount):
        self._SendCount = SendCount

    @property
    def CacheCount(self):
        r"""Number of emails cached
        :rtype: int
        """
        return self._CacheCount

    @CacheCount.setter
    def CacheCount(self, CacheCount):
        self._CacheCount = CacheCount

    @property
    def CreateTime(self):
        r"""Task creation time
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def UpdateTime(self):
        r"""Task update time
        :rtype: str
        """
        return self._UpdateTime

    @UpdateTime.setter
    def UpdateTime(self, UpdateTime):
        self._UpdateTime = UpdateTime

    @property
    def Subject(self):
        r"""Email subject
        :rtype: str
        """
        return self._Subject

    @Subject.setter
    def Subject(self, Subject):
        self._Subject = Subject

    @property
    def Template(self):
        r"""Template and template data.
        :rtype: :class:`tencentcloud.ses.v20201002.models.Template`
        """
        return self._Template

    @Template.setter
    def Template(self, Template):
        self._Template = Template

    @property
    def CycleParam(self):
        r"""Parameters of a recurring task
Note: This field may return `null`, indicating that no valid value can be found.
        :rtype: :class:`tencentcloud.ses.v20201002.models.CycleEmailParam`
        """
        return self._CycleParam

    @CycleParam.setter
    def CycleParam(self, CycleParam):
        self._CycleParam = CycleParam

    @property
    def TimedParam(self):
        r"""Parameters of a scheduled task
Note: This field may return `null`, indicating that no valid value can be found.
        :rtype: :class:`tencentcloud.ses.v20201002.models.TimedEmailParam`
        """
        return self._TimedParam

    @TimedParam.setter
    def TimedParam(self, TimedParam):
        self._TimedParam = TimedParam

    @property
    def ErrMsg(self):
        r"""Task exception information.
        :rtype: str
        """
        return self._ErrMsg

    @ErrMsg.setter
    def ErrMsg(self, ErrMsg):
        self._ErrMsg = ErrMsg

    @property
    def ReceiversName(self):
        r"""Recipient group name
        :rtype: str
        """
        return self._ReceiversName

    @ReceiversName.setter
    def ReceiversName(self, ReceiversName):
        self._ReceiversName = ReceiversName


    def _deserialize(self, params):
        self._TaskId = params.get("TaskId")
        self._FromEmailAddress = params.get("FromEmailAddress")
        self._ReceiverId = params.get("ReceiverId")
        self._TaskStatus = params.get("TaskStatus")
        self._TaskType = params.get("TaskType")
        self._RequestCount = params.get("RequestCount")
        self._SendCount = params.get("SendCount")
        self._CacheCount = params.get("CacheCount")
        self._CreateTime = params.get("CreateTime")
        self._UpdateTime = params.get("UpdateTime")
        self._Subject = params.get("Subject")
        if params.get("Template") is not None:
            self._Template = Template()
            self._Template._deserialize(params.get("Template"))
        if params.get("CycleParam") is not None:
            self._CycleParam = CycleEmailParam()
            self._CycleParam._deserialize(params.get("CycleParam"))
        if params.get("TimedParam") is not None:
            self._TimedParam = TimedEmailParam()
            self._TimedParam._deserialize(params.get("TimedParam"))
        self._ErrMsg = params.get("ErrMsg")
        self._ReceiversName = params.get("ReceiversName")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class Simple(AbstractModel):
    r"""Email content, which can be plain text (TEXT), pure code (HTML), or a combination of TEXT and HTML (recommended).

    """

    def __init__(self):
        r"""
        :param _Html: HTML code after base64 encoding. To ensure correct display, this parameter should include all code information and cannot contain external CSS.
        :type Html: str
        :param _Text: Plain text content after base64 encoding. If HTML is not involved, the plain text will be displayed in the email. Otherwise, this parameter represents the plain text style of the email.
        :type Text: str
        """
        self._Html = None
        self._Text = None

    @property
    def Html(self):
        r"""HTML code after base64 encoding. To ensure correct display, this parameter should include all code information and cannot contain external CSS.
        :rtype: str
        """
        return self._Html

    @Html.setter
    def Html(self, Html):
        self._Html = Html

    @property
    def Text(self):
        r"""Plain text content after base64 encoding. If HTML is not involved, the plain text will be displayed in the email. Otherwise, this parameter represents the plain text style of the email.
        :rtype: str
        """
        return self._Text

    @Text.setter
    def Text(self, Text):
        self._Text = Text


    def _deserialize(self, params):
        self._Html = params.get("Html")
        self._Text = params.get("Text")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class TagList(AbstractModel):
    r"""Tag.

    """

    def __init__(self):
        r"""
        :param _TagKey: Product.
        :type TagKey: str
        :param _TagValue: ses
        :type TagValue: str
        """
        self._TagKey = None
        self._TagValue = None

    @property
    def TagKey(self):
        r"""Product.
        :rtype: str
        """
        return self._TagKey

    @TagKey.setter
    def TagKey(self, TagKey):
        self._TagKey = TagKey

    @property
    def TagValue(self):
        r"""ses
        :rtype: str
        """
        return self._TagValue

    @TagValue.setter
    def TagValue(self, TagValue):
        self._TagValue = TagValue


    def _deserialize(self, params):
        self._TagKey = params.get("TagKey")
        self._TagValue = params.get("TagValue")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class Template(AbstractModel):
    r"""Template information, including template ID, template variable parameters, etc.

    """

    def __init__(self):
        r"""
        :param _TemplateID: Template ID. If you don’t have any template, please create one.
        :type TemplateID: int
        :param _TemplateData: Variable parameters in the template. Please use `json.dump` to format the JSON object into a string type. The object is a set of key-value pairs. Each key denotes a variable, which is represented by {{key}}. The key will be replaced with the corresponding value (represented by {{value}}) when sending the email.
Note: The parameter value cannot be data of a complex type such as HTML.
Example: {"name":"xxx","age":"xx"}
        :type TemplateData: str
        """
        self._TemplateID = None
        self._TemplateData = None

    @property
    def TemplateID(self):
        r"""Template ID. If you don’t have any template, please create one.
        :rtype: int
        """
        return self._TemplateID

    @TemplateID.setter
    def TemplateID(self, TemplateID):
        self._TemplateID = TemplateID

    @property
    def TemplateData(self):
        r"""Variable parameters in the template. Please use `json.dump` to format the JSON object into a string type. The object is a set of key-value pairs. Each key denotes a variable, which is represented by {{key}}. The key will be replaced with the corresponding value (represented by {{value}}) when sending the email.
Note: The parameter value cannot be data of a complex type such as HTML.
Example: {"name":"xxx","age":"xx"}
        :rtype: str
        """
        return self._TemplateData

    @TemplateData.setter
    def TemplateData(self, TemplateData):
        self._TemplateData = TemplateData


    def _deserialize(self, params):
        self._TemplateID = params.get("TemplateID")
        self._TemplateData = params.get("TemplateData")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class TemplateContent(AbstractModel):
    r"""Template content, which must include at least one of TEXT and HTML. A combination of TEXT and HTML is recommended.

    """

    def __init__(self):
        r"""
        :param _Html: HTML code after base64 encoding.
        :type Html: str
        :param _Text: Text content after base64 encoding.
        :type Text: str
        """
        self._Html = None
        self._Text = None

    @property
    def Html(self):
        r"""HTML code after base64 encoding.
        :rtype: str
        """
        return self._Html

    @Html.setter
    def Html(self, Html):
        self._Html = Html

    @property
    def Text(self):
        r"""Text content after base64 encoding.
        :rtype: str
        """
        return self._Text

    @Text.setter
    def Text(self, Text):
        self._Text = Text


    def _deserialize(self, params):
        self._Html = params.get("Html")
        self._Text = params.get("Text")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class TemplatesMetadata(AbstractModel):
    r"""Template list structure.

    """

    def __init__(self):
        r"""
        :param _CreatedTimestamp: Creation time.
        :type CreatedTimestamp: int
        :param _TemplateName: Template name.
        :type TemplateName: str
        :param _TemplateStatus: Template status. 1: under review; 0: approved; 2: rejected; other values: unavailable.
        :type TemplateStatus: int
        :param _TemplateID: Template ID.
        :type TemplateID: int
        :param _ReviewReason: Review reply
        :type ReviewReason: str
        """
        self._CreatedTimestamp = None
        self._TemplateName = None
        self._TemplateStatus = None
        self._TemplateID = None
        self._ReviewReason = None

    @property
    def CreatedTimestamp(self):
        r"""Creation time.
        :rtype: int
        """
        return self._CreatedTimestamp

    @CreatedTimestamp.setter
    def CreatedTimestamp(self, CreatedTimestamp):
        self._CreatedTimestamp = CreatedTimestamp

    @property
    def TemplateName(self):
        r"""Template name.
        :rtype: str
        """
        return self._TemplateName

    @TemplateName.setter
    def TemplateName(self, TemplateName):
        self._TemplateName = TemplateName

    @property
    def TemplateStatus(self):
        r"""Template status. 1: under review; 0: approved; 2: rejected; other values: unavailable.
        :rtype: int
        """
        return self._TemplateStatus

    @TemplateStatus.setter
    def TemplateStatus(self, TemplateStatus):
        self._TemplateStatus = TemplateStatus

    @property
    def TemplateID(self):
        r"""Template ID.
        :rtype: int
        """
        return self._TemplateID

    @TemplateID.setter
    def TemplateID(self, TemplateID):
        self._TemplateID = TemplateID

    @property
    def ReviewReason(self):
        r"""Review reply
        :rtype: str
        """
        return self._ReviewReason

    @ReviewReason.setter
    def ReviewReason(self, ReviewReason):
        self._ReviewReason = ReviewReason


    def _deserialize(self, params):
        self._CreatedTimestamp = params.get("CreatedTimestamp")
        self._TemplateName = params.get("TemplateName")
        self._TemplateStatus = params.get("TemplateStatus")
        self._TemplateID = params.get("TemplateID")
        self._ReviewReason = params.get("ReviewReason")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class TimedEmailParam(AbstractModel):
    r"""Time parameter required to create a scheduled sending task, such as the start time

    """

    def __init__(self):
        r"""
        :param _BeginTime: Start time of a scheduled sending task
        :type BeginTime: str
        """
        self._BeginTime = None

    @property
    def BeginTime(self):
        r"""Start time of a scheduled sending task
        :rtype: str
        """
        return self._BeginTime

    @BeginTime.setter
    def BeginTime(self, BeginTime):
        self._BeginTime = BeginTime


    def _deserialize(self, params):
        self._BeginTime = params.get("BeginTime")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class UpdateAddressUnsubscribeConfigRequest(AbstractModel):
    r"""UpdateAddressUnsubscribeConfig request structure.

    """

    def __init__(self):
        r"""
        :param _Address: Sender address.
        :type Address: str
        :param _UnsubscribeConfig: Unsubscribe link option. 0: Do not add unsubscribe link; 1: English 2: Simplified Chinese; 3: Traditional Chinese; 4: Spanish; 5: French; 6: German; 7: Japanese; 8: Korean; 9: Arabic; 10: Thai
        :type UnsubscribeConfig: str
        :param _Status: 0: disable; 1: enable.
        :type Status: int
        """
        self._Address = None
        self._UnsubscribeConfig = None
        self._Status = None

    @property
    def Address(self):
        r"""Sender address.
        :rtype: str
        """
        return self._Address

    @Address.setter
    def Address(self, Address):
        self._Address = Address

    @property
    def UnsubscribeConfig(self):
        r"""Unsubscribe link option. 0: Do not add unsubscribe link; 1: English 2: Simplified Chinese; 3: Traditional Chinese; 4: Spanish; 5: French; 6: German; 7: Japanese; 8: Korean; 9: Arabic; 10: Thai
        :rtype: str
        """
        return self._UnsubscribeConfig

    @UnsubscribeConfig.setter
    def UnsubscribeConfig(self, UnsubscribeConfig):
        self._UnsubscribeConfig = UnsubscribeConfig

    @property
    def Status(self):
        r"""0: disable; 1: enable.
        :rtype: int
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status


    def _deserialize(self, params):
        self._Address = params.get("Address")
        self._UnsubscribeConfig = params.get("UnsubscribeConfig")
        self._Status = params.get("Status")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class UpdateAddressUnsubscribeConfigResponse(AbstractModel):
    r"""UpdateAddressUnsubscribeConfig response structure.

    """

    def __init__(self):
        r"""
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class UpdateCustomBlackListRequest(AbstractModel):
    r"""UpdateCustomBlackList request structure.

    """

    def __init__(self):
        r"""
        :param _Id: Blocklist id that needs to change.
        :type Id: int
        :param _Email: After modification email address.
        :type Email: str
        :param _ExpireDate: Expiration time. if left empty, it indicates permanent validity.
        :type ExpireDate: str
        """
        self._Id = None
        self._Email = None
        self._ExpireDate = None

    @property
    def Id(self):
        r"""Blocklist id that needs to change.
        :rtype: int
        """
        return self._Id

    @Id.setter
    def Id(self, Id):
        self._Id = Id

    @property
    def Email(self):
        r"""After modification email address.
        :rtype: str
        """
        return self._Email

    @Email.setter
    def Email(self, Email):
        self._Email = Email

    @property
    def ExpireDate(self):
        r"""Expiration time. if left empty, it indicates permanent validity.
        :rtype: str
        """
        return self._ExpireDate

    @ExpireDate.setter
    def ExpireDate(self, ExpireDate):
        self._ExpireDate = ExpireDate


    def _deserialize(self, params):
        self._Id = params.get("Id")
        self._Email = params.get("Email")
        self._ExpireDate = params.get("ExpireDate")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class UpdateCustomBlackListResponse(AbstractModel):
    r"""UpdateCustomBlackList response structure.

    """

    def __init__(self):
        r"""
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class UpdateEmailIdentityRequest(AbstractModel):
    r"""UpdateEmailIdentity request structure.

    """

    def __init__(self):
        r"""
        :param _EmailIdentity: Domain to be verified.
        :type EmailIdentity: str
        """
        self._EmailIdentity = None

    @property
    def EmailIdentity(self):
        r"""Domain to be verified.
        :rtype: str
        """
        return self._EmailIdentity

    @EmailIdentity.setter
    def EmailIdentity(self, EmailIdentity):
        self._EmailIdentity = EmailIdentity


    def _deserialize(self, params):
        self._EmailIdentity = params.get("EmailIdentity")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class UpdateEmailIdentityResponse(AbstractModel):
    r"""UpdateEmailIdentity response structure.

    """

    def __init__(self):
        r"""
        :param _IdentityType: Verification type. The value is fixed to `DOMAIN`.
        :type IdentityType: str
        :param _VerifiedForSendingStatus: Verification passed or not.
        :type VerifiedForSendingStatus: bool
        :param _Attributes: DNS information that needs to be configured.
        :type Attributes: list of DNSAttributes
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._IdentityType = None
        self._VerifiedForSendingStatus = None
        self._Attributes = None
        self._RequestId = None

    @property
    def IdentityType(self):
        r"""Verification type. The value is fixed to `DOMAIN`.
        :rtype: str
        """
        return self._IdentityType

    @IdentityType.setter
    def IdentityType(self, IdentityType):
        self._IdentityType = IdentityType

    @property
    def VerifiedForSendingStatus(self):
        r"""Verification passed or not.
        :rtype: bool
        """
        return self._VerifiedForSendingStatus

    @VerifiedForSendingStatus.setter
    def VerifiedForSendingStatus(self, VerifiedForSendingStatus):
        self._VerifiedForSendingStatus = VerifiedForSendingStatus

    @property
    def Attributes(self):
        r"""DNS information that needs to be configured.
        :rtype: list of DNSAttributes
        """
        return self._Attributes

    @Attributes.setter
    def Attributes(self, Attributes):
        self._Attributes = Attributes

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._IdentityType = params.get("IdentityType")
        self._VerifiedForSendingStatus = params.get("VerifiedForSendingStatus")
        if params.get("Attributes") is not None:
            self._Attributes = []
            for item in params.get("Attributes"):
                obj = DNSAttributes()
                obj._deserialize(item)
                self._Attributes.append(obj)
        self._RequestId = params.get("RequestId")


class UpdateEmailSmtpPassWordRequest(AbstractModel):
    r"""UpdateEmailSmtpPassWord request structure.

    """

    def __init__(self):
        r"""
        :param _Password: SMTP password. Length limit: 64.
        :type Password: str
        :param _EmailAddress: Email address. Length limit: 128.
        :type EmailAddress: str
        """
        self._Password = None
        self._EmailAddress = None

    @property
    def Password(self):
        r"""SMTP password. Length limit: 64.
        :rtype: str
        """
        return self._Password

    @Password.setter
    def Password(self, Password):
        self._Password = Password

    @property
    def EmailAddress(self):
        r"""Email address. Length limit: 128.
        :rtype: str
        """
        return self._EmailAddress

    @EmailAddress.setter
    def EmailAddress(self, EmailAddress):
        self._EmailAddress = EmailAddress


    def _deserialize(self, params):
        self._Password = params.get("Password")
        self._EmailAddress = params.get("EmailAddress")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class UpdateEmailSmtpPassWordResponse(AbstractModel):
    r"""UpdateEmailSmtpPassWord response structure.

    """

    def __init__(self):
        r"""
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class UpdateEmailTemplateRequest(AbstractModel):
    r"""UpdateEmailTemplate request structure.

    """

    def __init__(self):
        r"""
        :param _TemplateContent: Template content.
        :type TemplateContent: :class:`tencentcloud.ses.v20201002.models.TemplateContent`
        :param _TemplateID: Template ID.
        :type TemplateID: int
        :param _TemplateName: Template name
        :type TemplateName: str
        """
        self._TemplateContent = None
        self._TemplateID = None
        self._TemplateName = None

    @property
    def TemplateContent(self):
        r"""Template content.
        :rtype: :class:`tencentcloud.ses.v20201002.models.TemplateContent`
        """
        return self._TemplateContent

    @TemplateContent.setter
    def TemplateContent(self, TemplateContent):
        self._TemplateContent = TemplateContent

    @property
    def TemplateID(self):
        r"""Template ID.
        :rtype: int
        """
        return self._TemplateID

    @TemplateID.setter
    def TemplateID(self, TemplateID):
        self._TemplateID = TemplateID

    @property
    def TemplateName(self):
        r"""Template name
        :rtype: str
        """
        return self._TemplateName

    @TemplateName.setter
    def TemplateName(self, TemplateName):
        self._TemplateName = TemplateName


    def _deserialize(self, params):
        if params.get("TemplateContent") is not None:
            self._TemplateContent = TemplateContent()
            self._TemplateContent._deserialize(params.get("TemplateContent"))
        self._TemplateID = params.get("TemplateID")
        self._TemplateName = params.get("TemplateName")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class UpdateEmailTemplateResponse(AbstractModel):
    r"""UpdateEmailTemplate response structure.

    """

    def __init__(self):
        r"""
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class Volume(AbstractModel):
    r"""Statistics structure.

    """

    def __init__(self):
        r"""
        :param _SendDate: Date
        :type SendDate: str
        :param _RequestCount: Number of email requests.
        :type RequestCount: int
        :param _AcceptedCount: Number of email requests accepted by Tencent Cloud.
        :type AcceptedCount: int
        :param _DeliveredCount: Number of delivered emails.
        :type DeliveredCount: int
        :param _OpenedCount: Number of users (deduplicated) who opened emails.
        :type OpenedCount: int
        :param _ClickedCount: Number of recipients who clicked on links in emails.
        :type ClickedCount: int
        :param _BounceCount: Number of bounced emails.
        :type BounceCount: int
        :param _UnsubscribeCount: Number of users for unsubscription.
        :type UnsubscribeCount: int
        """
        self._SendDate = None
        self._RequestCount = None
        self._AcceptedCount = None
        self._DeliveredCount = None
        self._OpenedCount = None
        self._ClickedCount = None
        self._BounceCount = None
        self._UnsubscribeCount = None

    @property
    def SendDate(self):
        r"""Date
        :rtype: str
        """
        return self._SendDate

    @SendDate.setter
    def SendDate(self, SendDate):
        self._SendDate = SendDate

    @property
    def RequestCount(self):
        r"""Number of email requests.
        :rtype: int
        """
        return self._RequestCount

    @RequestCount.setter
    def RequestCount(self, RequestCount):
        self._RequestCount = RequestCount

    @property
    def AcceptedCount(self):
        r"""Number of email requests accepted by Tencent Cloud.
        :rtype: int
        """
        return self._AcceptedCount

    @AcceptedCount.setter
    def AcceptedCount(self, AcceptedCount):
        self._AcceptedCount = AcceptedCount

    @property
    def DeliveredCount(self):
        r"""Number of delivered emails.
        :rtype: int
        """
        return self._DeliveredCount

    @DeliveredCount.setter
    def DeliveredCount(self, DeliveredCount):
        self._DeliveredCount = DeliveredCount

    @property
    def OpenedCount(self):
        r"""Number of users (deduplicated) who opened emails.
        :rtype: int
        """
        return self._OpenedCount

    @OpenedCount.setter
    def OpenedCount(self, OpenedCount):
        self._OpenedCount = OpenedCount

    @property
    def ClickedCount(self):
        r"""Number of recipients who clicked on links in emails.
        :rtype: int
        """
        return self._ClickedCount

    @ClickedCount.setter
    def ClickedCount(self, ClickedCount):
        self._ClickedCount = ClickedCount

    @property
    def BounceCount(self):
        r"""Number of bounced emails.
        :rtype: int
        """
        return self._BounceCount

    @BounceCount.setter
    def BounceCount(self, BounceCount):
        self._BounceCount = BounceCount

    @property
    def UnsubscribeCount(self):
        r"""Number of users for unsubscription.
        :rtype: int
        """
        return self._UnsubscribeCount

    @UnsubscribeCount.setter
    def UnsubscribeCount(self, UnsubscribeCount):
        self._UnsubscribeCount = UnsubscribeCount


    def _deserialize(self, params):
        self._SendDate = params.get("SendDate")
        self._RequestCount = params.get("RequestCount")
        self._AcceptedCount = params.get("AcceptedCount")
        self._DeliveredCount = params.get("DeliveredCount")
        self._OpenedCount = params.get("OpenedCount")
        self._ClickedCount = params.get("ClickedCount")
        self._BounceCount = params.get("BounceCount")
        self._UnsubscribeCount = params.get("UnsubscribeCount")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        