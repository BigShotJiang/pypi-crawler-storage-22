"""
TENGWAR - The AI-Native Programming Language

Built from first principles for machine intelligence.
Zero ambiguity. Maximum semantic density. Binary AST protocol.
"""

__version__ = "0.3.6"
__author__ = "TENGWAR Project"

from .lexer import tokenize
from .parser import parse
from .interpreter import Interpreter
from .repl import repl, run_file
from .errors import TengwarError, LexError, ParseError, RuntimeError_, ProofError
from .binary_ast import (
    encode, decode, run_binary, encode_b64, run_b64,
    ASTBuilder, Encoder, Decoder, Op
)
from .vm import VM, Compiler
