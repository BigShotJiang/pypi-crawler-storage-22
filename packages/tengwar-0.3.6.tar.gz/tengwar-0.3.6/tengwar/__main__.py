"""Run Tengwar REPL or execute files: python -m tengwar [file.tw]"""
import sys
from .repl import repl, run_file

if len(sys.argv) > 1:
    run_file(sys.argv[1])
else:
    repl()
