"""
TENGWAR Error Types

Structured error reporting with precise source locations.
"""


class TengwarError(Exception):
    def __init__(self, message: str, line: int = 0, col: int = 0):
        self.message = message
        self.line = line
        self.col = col
        super().__init__(f"[{line}:{col}] {message}")


class LexError(TengwarError):
    """Tokenization error"""
    pass


class ParseError(TengwarError):
    """Parsing error"""
    pass


class TypeError_(TengwarError):
    """Type checking error"""
    pass


class RuntimeError_(TengwarError):
    """Runtime evaluation error"""
    pass


class ProofError(TengwarError):
    """Proof obligation failed"""
    pass


class EffectError(TengwarError):
    """Unhandled or disallowed effect"""
    pass
