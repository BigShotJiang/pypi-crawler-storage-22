from tensorbored._vendor.bleach._vendor.parse import urlparse  # noqa
