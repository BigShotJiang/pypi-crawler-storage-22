import hashlib
from typing import Any, Callable, Dict, List

from tensorlake.applications import (
    Function,
    InternalError,
)
from tensorlake.applications.algorithms import (
    copy_awaitable_tree,
    dfs_bottom_up,
    reduce_operation_to_function_call_chain,
)
from tensorlake.applications.function.application_call import (
    SerializedApplicationArgument,
    deserialize_application_function_call_arguments,
)
from tensorlake.applications.function.function_call import (
    set_self_arg,
)
from tensorlake.applications.function.user_data_serializer import (
    deserialize_value_with_metadata,
    function_input_serializer,
    serialize_value,
)
from tensorlake.applications.interface.awaitables import (
    Awaitable,
    AwaitableList,
    FunctionCallAwaitable,
    ReduceOperationAwaitable,
    _request_scoped_id,
)
from tensorlake.applications.metadata import (
    CollectionItemMetadata,
    CollectionMetadata,
    FunctionCallArgumentMetadata,
    FunctionCallMetadata,
    ReduceOperationMetadata,
    ValueMetadata,
    deserialize_metadata,
    serialize_metadata,
)
from tensorlake.applications.registry import get_function
from tensorlake.applications.user_data_serializer import (
    UserDataSerializer,
)

from ...applications.internal_logger import InternalLogger
from ..proto.function_executor_pb2 import (
    ExecutionPlanUpdate,
    ExecutionPlanUpdates,
    FunctionArg,
    FunctionCall,
    FunctionRef,
    SerializedObjectInsideBLOB,
)
from .http_request_parse import (
    parse_application_function_call_arg_from_single_payload,
    parse_application_function_call_args_from_http_request,
    parse_application_function_call_args_from_multipart_form_data,
)
from .value import SerializedValue, Value


def to_runnable_awaitable_tree(root: Awaitable) -> Awaitable:
    """Returns a new awaitable tree semantically equivalent to the supplied tree but that can run on Server.

    The tree must be validated already.
    Raises InternalError on error.
    """
    new_root: Awaitable = _to_runnable(copy_awaitable_tree(root))
    stack: list[Awaitable] = [new_root]

    while len(stack) > 0:
        node: Awaitable = stack.pop()

        if isinstance(node, AwaitableList):
            for i in range(len(node.items)):
                runnable_item: Awaitable | Any = _to_runnable(node.items[i])
                if isinstance(runnable_item, Awaitable):
                    node.items[i] = runnable_item
                    stack.append(runnable_item)

        elif isinstance(node, FunctionCallAwaitable):
            for i in range(len(node.args)):
                runnable_arg: Awaitable | Any = _to_runnable(node.args[i])
                if isinstance(runnable_arg, Awaitable):
                    node.args[i] = runnable_arg
                    stack.append(runnable_arg)
            for kwarg_key in node.kwargs.keys():
                kwarg: Awaitable | Any = _to_runnable(node.kwargs[kwarg_key])
                if isinstance(kwarg, Awaitable):
                    node.kwargs[kwarg_key] = kwarg
                    stack.append(kwarg)

        # ReduceOperationAwaitable should have been already converted into FunctionCallAwaitable chain.
        else:
            raise InternalError(f"Unexpected Awaitable subclass: {type(node)}")

    return new_root


def _to_runnable(node: Awaitable | Any) -> Awaitable | Any:
    if isinstance(node, ReduceOperationAwaitable):
        return reduce_operation_to_function_call_chain(node)
    else:
        return node


def to_durable_awaitable_tree(
    root: Awaitable,
    parent_function_call_id: str,
    previous_awaitable_id: str,
) -> Awaitable:
    """Returns a semantically equivalent shallow copy of the supplied Awaitable tree with Awaitable IDs supporting durable execution.

    The shallow copy has a semantically equivalent structure as the original tree, but each Awaitable in the tree has its ID replaced
    with a durable ID. User provided values are kept in the returned tree as is.

    parent_function_call_id is ID of the function call that created the awaitable tree.
    previous_awaitable_id is ID of the previous awaitable created by the parent function call.

    Durable Awaitable IDs are the same across different executions (allocations) of the same parent function call
    if the parent function call is deterministic, i.e. it creates the same awaitable trees in the same order each
    time it's executed. If this is not the case then the Awaitable IDs will differ between executions, which may
    lead to re-execution of some function calls even if their inputs are the same as in a previous execution.

    To produce a durable Awaitable ID, we compute it as a hash of:
    - parent_function_call_id, this scopes each durable ID to its parent function call and allows to generate them locally while running
      the parent function call.
    - previous_awaitable_id, this ties each durable ID in the awaitable tree to the previous awaitable created by the parent function call.
      If while replaying the parent function call it follows a different execution path (i.e. running a different function call) then this new
      function call and all next function calls won't be replayed because their durable IDs will be different due to different previous_awaitable_id
      in their durable ID hash. This ensures that any drift in the execution path gets detected and gets handled according to the replay mode used.
    - next_awaitable_sequence_number, this ensures that any two Awaitables created inside the same awaitable tree get different durable IDs even
      if the Awaitables are otherwise identical (i.e. two calls of the same function with same parameters). If we didn't do this then every call
      of the same function (with any parameters) in the same awaitable tree will have the same durable ID which leads to function output caching
      while also ignoring function parameter values. This is very wrong. In the end, this ensures that each durable ID inside the same awaitable tree
      is unique.
    - Awaitable-specific metadata. This ensures that we detect changes inside each Awaitable tree node, i.e. a change of called function name.
    - Deterministically ordered durable IDs of all immediate child Awaitables.
      This ensures that changes in the structure of the awaitable tree leads to different durable IDs of its nodes
      starting from root so it's easy to detect a drift on Server side just by comparing durable ID of root.

    We're deliberately not hashing entire awaitables to produce their durable IDs. This is because hashing entire awaitables
    is an expensive operation (i.e. hashing gigabytes of arbitrary user supplied objects which are function call parameters).
    This also results in better UX, i.e. this allows:
    - Seamless Schema Evolution: Users may want to change the schema of function parameters (e.g. add a new field with a default value
      to a pydantic model).
    - Use of non-deterministic functions: Users may want to use non-deterministic functions (e.g. functions that return current time or random values)
      inside otherwise deterministic function call trees.
    - To avoid "Serialization Flakiness": Strict equality checks on serialized data are fragile and can lead to false positive
      re-executions due to minor, non-semantic changes in serialization (e.g. different field ordering in protobufs, or insertion order in dicts).
    - To decouple Logic from Data. We adhere to a philosophy of being Strict on Control Flow but Lenient on Data. "The History is the Source of Truth."

    Raises TensorlakeError on error.
    """
    # Warning: any change of ordering of operations in this function may lead to different durable IDs being generated
    # which may lead to re-execution of function calls on Server side even if nothing changed in the awaitable tree.
    awaitable_id_to_durable_awaitable: Dict[str, Awaitable] = {}
    next_awaitable_sequence_number: int = 0

    for awaitable in dfs_bottom_up(root, leaf_awaitable_types=()):
        awaitable: Awaitable
        durable_awaitable, next_awaitable_sequence_number = _to_durable_awaitable(
            awaitable=awaitable,
            parent_function_call_id=parent_function_call_id,
            previous_awaitable_id=previous_awaitable_id,
            next_awaitable_sequence_number=next_awaitable_sequence_number,
            awaitable_id_to_durable_awaitable=awaitable_id_to_durable_awaitable,
        )
        awaitable_id_to_durable_awaitable[awaitable.id] = durable_awaitable

    return awaitable_id_to_durable_awaitable[root.id]


def _to_durable_awaitable(
    awaitable: Awaitable,
    parent_function_call_id: str,
    previous_awaitable_id: str,
    next_awaitable_sequence_number: int,
    awaitable_id_to_durable_awaitable: Dict[str, Awaitable],
) -> tuple[Awaitable, int]:
    """Returns a durable version of the given awaitable.

    This function assumes that all child awaitables of the given awaitable have been already converted into
    durable versions and are present in awaitable_id_to_durable_awaitable.
    """
    # Warning: any change of ordering of operations in this function may lead to different durable IDs being generated
    # which may lead to re-execution of function calls on Server side even if nothing changed in the awaitable tree.
    durable_id_attrs: list[str] = [
        parent_function_call_id,
        previous_awaitable_id,
        str(next_awaitable_sequence_number),
    ]
    next_awaitable_sequence_number += 1

    if isinstance(awaitable, AwaitableList):
        awaitable: AwaitableList
        # Awaitable specific metadata, part of durable ID.
        durable_id_attrs.append(awaitable.metadata.durability_key)
        durable_items: list[Awaitable | Any] = []
        for item in awaitable.items:
            durable_item: Awaitable | Any
            if isinstance(item, Awaitable):
                durable_item = awaitable_id_to_durable_awaitable[item.id]
            else:
                durable_item = item
            durable_items.append(durable_item)
            _add_durable_id_attr(durable_item, durable_id_attrs)

        return (
            AwaitableList(
                id=_sha256_hash_strings(durable_id_attrs),
                items=durable_items,
                metadata=awaitable.metadata,
            ),
            next_awaitable_sequence_number,
        )

    elif isinstance(awaitable, FunctionCallAwaitable):
        awaitable: FunctionCallAwaitable
        # Awaitable specific metadata, part of durable ID.
        durable_id_attrs.extend(["FunctionCall", awaitable.function_name])
        durable_args: list[Awaitable | Any] = []
        for arg in awaitable.args:
            durable_arg: Awaitable | Any
            if isinstance(arg, Awaitable):
                durable_arg = awaitable_id_to_durable_awaitable[arg.id]
            else:
                durable_arg = arg
            durable_args.append(durable_arg)
            _add_durable_id_attr(durable_arg, durable_id_attrs)

        durable_kwargs: dict[str, Awaitable | Any] = {}
        # Iterate over sorted dict keys to ensure deterministic hash key order.
        sorted_kwarg_keys: list[str] = sorted(awaitable.kwargs.keys())
        for kwarg_name in sorted_kwarg_keys:
            kwarg_value: Awaitable | Any = awaitable.kwargs[kwarg_name]
            durable_kwarg: Awaitable | Any
            if isinstance(kwarg_value, Awaitable):
                durable_kwarg = awaitable_id_to_durable_awaitable[kwarg_value.id]
            else:
                durable_kwarg = kwarg_value
            durable_kwargs[kwarg_name] = durable_kwarg
            _add_durable_id_attr(durable_kwargs[kwarg_name], durable_id_attrs)

        return (
            FunctionCallAwaitable(
                id=_sha256_hash_strings(durable_id_attrs),
                function_name=awaitable.function_name,
                args=durable_args,
                kwargs=durable_kwargs,
            ),
            next_awaitable_sequence_number,
        )
    # ReduceOperationAwaitable should have been already converted into FunctionCallAwaitable chain
    # by reduce_operation_to_function_call_chain before calling this function.
    else:
        raise InternalError(f"Unexpected Awaitable subclass: {type(awaitable)}")


def serialize_user_value(
    value: Any, serializer: UserDataSerializer, type_hint: Any
) -> SerializedValue:
    """Serializes a user value into SerializedValue."""
    data: bytes
    metadata: ValueMetadata
    data, metadata = serialize_value(
        value=value,
        serializer=serializer,
        value_id=_request_scoped_id(),
        type_hint=type_hint,
    )
    return SerializedValue(
        metadata=metadata,
        data=data,
        content_type=metadata.content_type,
    )


def replace_user_values_with_serialized_values(
    root: Awaitable,
    root_serializer: UserDataSerializer,
) -> Dict[str, SerializedValue]:
    """Replaces user values in the given Awaitable tree with their SerializedValues.

    The provided Awaitable tree is modified in-place with each user supplied value being
    SerializedValue instead of the original user object.

    Returns a mapping from value ID to SerializedValue for all serialized user values in the tree.

    Raises SerializationError if serialization of any value fails.
    Raises TensorlakeError for other errors.
    """
    serialized_values: Dict[str, SerializedValue] = {}

    def to_serialized_value(
        value: Any, value_serializer: UserDataSerializer
    ) -> SerializedValue:
        serialized_value: SerializedValue = serialize_user_value(
            value=value,
            serializer=value_serializer,
            type_hint=type(value),
        )
        serialized_values[serialized_value.metadata.id] = serialized_value
        return serialized_value

    # NB: This code needs to be in sync with LocalRunner where it's doing a similar thing.
    stack: list[tuple[Awaitable, UserDataSerializer]] = [(root, root_serializer)]
    while len(stack) > 0:
        awaitable: Awaitable
        awaitable_serializer: UserDataSerializer
        awaitable, awaitable_serializer = stack.pop()

        if isinstance(awaitable, AwaitableList):
            # Iterating over list copy to allow modifying the original list.
            for index, item in enumerate(list(awaitable.items)):
                if isinstance(item, Awaitable):
                    stack.append((item, awaitable_serializer))
                else:
                    awaitable.items[index] = to_serialized_value(
                        value=item, value_serializer=awaitable_serializer
                    )
        elif isinstance(awaitable, FunctionCallAwaitable):
            args_serializer: UserDataSerializer = function_input_serializer(
                get_function(awaitable.function_name), app_call=False
            )
            # Iterating over list copy to allow modifying the original list.
            for index, arg in enumerate(list(awaitable.args)):
                if isinstance(arg, Awaitable):
                    stack.append((arg, args_serializer))
                else:
                    awaitable.args[index] = to_serialized_value(
                        value=arg, value_serializer=args_serializer
                    )
            # Iterating over dict copy to allow modifying the original list.
            for kwarg_name, kwarg_value in dict(awaitable.kwargs).items():
                if isinstance(kwarg_value, Awaitable):
                    stack.append((kwarg_value, args_serializer))
                else:
                    awaitable.kwargs[kwarg_name] = to_serialized_value(
                        value=kwarg_value, value_serializer=args_serializer
                    )
        # ReduceOperationAwaitable should have been already converted into FunctionCallAwaitable
        # by to_durable_awaitable_tree before calling this function.
        else:
            raise InternalError(f"Unexpected Awaitable subclass: {type(awaitable)}")

    return serialized_values


def to_execution_plan_updates(
    awaitable: Awaitable,
    uploaded_serialized_objects: Dict[str, SerializedObjectInsideBLOB],
    output_serializer_name_override: str,
    has_output_type_hint_override: bool,
    output_type_hint_override: Any,
    function_ref: FunctionRef,
) -> ExecutionPlanUpdates:
    """Traverses the awaitable tree and constructs ExecutionPlanUpdates proto.

    The awaitable must be validated already. The root awaitable must not be an AwaitableList.
    Caller must call this function for each item in the AwaitableList separately instead.
    Each value in the awaitable tree must be a SerializedValue present in uploaded_serialized_objects.

    Raises TensorlakeError on error.
    """
    updates: List[ExecutionPlanUpdate] = []
    _fill_execution_plan_updates(
        root=awaitable,
        uploaded_serialized_objects=uploaded_serialized_objects,
        output_serializer_name_override=output_serializer_name_override,
        has_output_type_hint_override=has_output_type_hint_override,
        output_type_hint_override=output_type_hint_override,
        destination=updates,
        function_ref=function_ref,
    )
    return ExecutionPlanUpdates(
        updates=updates,
        root_function_call_id=awaitable.id,
    )


def _fill_execution_plan_updates(
    root: Awaitable,
    uploaded_serialized_objects: Dict[str, SerializedObjectInsideBLOB],
    output_serializer_name_override: str | None,
    has_output_type_hint_override: bool,
    output_type_hint_override: Any,
    destination: List[ExecutionPlanUpdate],
    function_ref: FunctionRef,
) -> None:
    stack: list[Awaitable] = [root]
    while len(stack) > 0:
        node: Awaitable = stack.pop()
        # Only override at root function call.
        node_output_serializer_name_override = (
            output_serializer_name_override if node is root else None
        )
        node_has_output_type_hint_override = (
            has_output_type_hint_override if node is root else False
        )
        node_output_type_hint_override = (
            output_type_hint_override if node is root else None
        )

        if isinstance(node, FunctionCallAwaitable):
            destination.append(
                _function_call_execution_plan_update(
                    awaitable=node,
                    uploaded_serialized_objects=uploaded_serialized_objects,
                    output_serializer_name_override=node_output_serializer_name_override,
                    has_output_type_hint_override=node_has_output_type_hint_override,
                    output_type_hint_override=node_output_type_hint_override,
                    function_ref=function_ref,
                )
            )
            for arg_value in node.args:
                if isinstance(arg_value, Awaitable):
                    stack.append(arg_value)

            for kwarg_value in node.kwargs.values():
                if isinstance(kwarg_value, Awaitable):
                    stack.append(kwarg_value)

        elif isinstance(node, AwaitableList):
            # This collection is fully embedded now into function call args but its function
            # calls are not in the execution plan yet.
            for item in node.items:
                if isinstance(item, Awaitable):
                    stack.append(item)

        else:
            raise InternalError(f"Unexpected Awaitable subclass: {type(node)}")


def _function_call_execution_plan_update(
    awaitable: FunctionCallAwaitable,
    uploaded_serialized_objects: Dict[str, SerializedObjectInsideBLOB],
    output_serializer_name_override: str | None,
    has_output_type_hint_override: bool,
    output_type_hint_override: Any,
    function_ref: FunctionRef,
) -> ExecutionPlanUpdate:
    metadata: FunctionCallMetadata = FunctionCallMetadata(
        id=awaitable.id,
        output_serializer_name_override=output_serializer_name_override,
        output_type_hint_override=output_type_hint_override,
        has_output_type_hint_override=has_output_type_hint_override,
        args=[],
        kwargs={},
    )
    function_pb_args: List[FunctionArg] = []

    def process_function_call_argument(arg: Any) -> FunctionCallArgumentMetadata:
        if isinstance(arg, SerializedValue):
            function_pb_args.append(
                FunctionArg(
                    value=uploaded_serialized_objects[arg.metadata.id],
                )
            )
            return FunctionCallArgumentMetadata(
                value_id=arg.metadata.id,
                collection=None,
            )
        elif isinstance(arg, AwaitableList):
            _embed_collection_into_function_pb_args(
                awaitable=arg,
                uploaded_serialized_objects=uploaded_serialized_objects,
                function_pb_args=function_pb_args,
            )
            return FunctionCallArgumentMetadata(
                value_id=None,
                collection=_to_collection_metadata(arg),
            )
        elif isinstance(arg, (FunctionCallAwaitable, ReduceOperationAwaitable)):
            function_pb_args.append(
                FunctionArg(
                    function_call_id=arg.id,
                )
            )
            return FunctionCallArgumentMetadata(
                value_id=arg.id,
                collection=None,
            )
        else:
            raise InternalError(
                f"Unexpected type of function call argument: {type(arg)}"
            )

    for arg in awaitable.args:
        metadata.args.append(process_function_call_argument(arg))

    for kwarg_name, kwarg_value in awaitable.kwargs.items():
        metadata.kwargs[kwarg_name] = process_function_call_argument(kwarg_value)

    return ExecutionPlanUpdate(
        function_call=FunctionCall(
            id=awaitable.id,
            target=FunctionRef(
                namespace=function_ref.namespace,
                application_name=function_ref.application_name,
                function_name=awaitable.function_name,
                application_version=function_ref.application_version,
            ),
            args=function_pb_args,
            call_metadata=serialize_metadata(metadata),
        )
    )


def _to_collection_metadata(awaitable: AwaitableList) -> CollectionMetadata:
    result: CollectionMetadata = CollectionMetadata(items=[])
    stack: list[(AwaitableList, CollectionMetadata)] = [(awaitable, result)]
    while len(stack) > 0:
        awaitable, collection_metadata = stack.pop()
        awaitable: AwaitableList
        collection_metadata: CollectionMetadata

        for item in awaitable.items:
            if isinstance(item, SerializedValue):
                collection_metadata.items.append(
                    CollectionItemMetadata(
                        value_id=item.metadata.id,
                        collection=None,
                    )
                )
            elif isinstance(item, AwaitableList):
                item_collection_metadata = CollectionMetadata(items=[])
                stack.append((item, item_collection_metadata))
                collection_metadata.items.append(
                    CollectionItemMetadata(
                        value_id=None,
                        collection=item_collection_metadata,
                    )
                )
            elif isinstance(item, (FunctionCallAwaitable, ReduceOperationAwaitable)):
                collection_metadata.items.append(
                    CollectionItemMetadata(
                        value_id=item.id,
                        collection=None,
                    )
                )
            else:
                raise InternalError(
                    f"Unexpected type of AwaitableList item: {type(item)}"
                )

    return result


def _embed_collection_into_function_pb_args(
    awaitable: AwaitableList,
    uploaded_serialized_objects: Dict[str, SerializedObjectInsideBLOB],
    function_pb_args: List[FunctionArg],
) -> None:
    stack: list[list[Awaitable | Any]] = [awaitable.items]
    while len(stack) > 0:
        collection = stack.pop()
        for item in collection:
            if isinstance(item, SerializedValue):
                function_pb_args.append(
                    FunctionArg(
                        value=uploaded_serialized_objects[item.metadata.id],
                    )
                )
            elif isinstance(item, AwaitableList):
                stack.append(item.items)
            elif isinstance(item, (FunctionCallAwaitable, ReduceOperationAwaitable)):
                function_pb_args.append(
                    FunctionArg(
                        function_call_id=item.id,
                    )
                )
            else:
                raise InternalError(
                    f"Unexpected type of AwaitableList item: {type(item)}"
                )


def deserialize_application_function_call_args(
    function: Function,
    payload: SerializedValue,
    function_instance_arg: Any | None,
) -> tuple[List[Any], Dict[str, Any]]:
    """Returns a mapping from application function positional argument index or keyword to its deserialized Value.

    Raises DeserializationError if deserialization of any argument fails.
    Raises InternalError on other errors.
    """
    input_serializer: UserDataSerializer = function_input_serializer(
        function, app_call=True
    )
    serialized_args: list[SerializedApplicationArgument]
    serialized_kwargs: dict[str, SerializedApplicationArgument]

    if payload.content_type == "message/http":
        # Future mode for application function calls where the HTTP request is forwarded from Server.
        # Server will start doing this only once all users migrated to FE version 1.2+.
        serialized_args, serialized_kwargs = (
            parse_application_function_call_args_from_http_request(payload.data)
        )
    elif payload.content_type is not None and payload.content_type.startswith(
        "multipart/form-data"
    ):
        # Current mode for multi-parameter application function calls (>1 parameter).
        # Legacy mode for multi-parameter application function calls (>1 parameter).
        serialized_args, serialized_kwargs = (
            parse_application_function_call_args_from_multipart_form_data(
                body_buffer=payload.data,
                body_offset=0,
                content_type=payload.content_type,
            )
        )
    else:
        # Current mode for application function calls with a single argument.
        content_type: str = (
            input_serializer.content_type
            if payload.content_type is None
            else payload.content_type
        )
        serialized_arg: SerializedApplicationArgument = (
            parse_application_function_call_arg_from_single_payload(
                body_buffer=payload.data,
                body_offset=0,
                body_end_offset=len(payload.data),
                content_type=content_type,
            )
        )
        # Single payload is always mapped to the first positional application function argument.
        serialized_args = [serialized_arg]
        serialized_kwargs = {}

    args, kwargs = deserialize_application_function_call_arguments(
        application=function,
        serialized_args=serialized_args,
        serialized_kwargs=serialized_kwargs,
    )

    if function_instance_arg is not None:
        set_self_arg(args, function_instance_arg)

    return args, kwargs


def validate_and_deserialize_function_call_metadata(
    serialized_function_call_metadata: bytes,
    serialized_args: List[SerializedValue],
    function: Function,
    logger: InternalLogger,
) -> FunctionCallMetadata | ReduceOperationMetadata | None:
    if len(serialized_function_call_metadata) > 0:
        # Function call created by SDK.
        for serialized_arg in serialized_args:
            if serialized_arg.metadata is None:
                logger.error(
                    "function argument is missing metadata",
                )
                raise InternalError("Function argument is missing metadata.")

        function_call_metadata = deserialize_metadata(serialized_function_call_metadata)
        if not isinstance(
            function_call_metadata, (FunctionCallMetadata, ReduceOperationMetadata)
        ):
            logger.error(
                "unexpected function call metadata type",
                metadata_type=type(function_call_metadata),
            )
            raise InternalError(
                f"Unexpected function call metadata type: {type(function_call_metadata)}"
            )

        if (
            isinstance(function_call_metadata, ReduceOperationMetadata)
            and len(serialized_args) != 2
        ):
            raise InternalError(
                f"Expected 2 arguments for reducer function call, got {len(serialized_args)}"
            )

        return function_call_metadata
    else:
        # Application function call created by Server.
        if len(serialized_args) != 1:
            logger.error(
                "expected exactly one function argument for server-created application function call",
                num_args=len(serialized_args),
            )
            raise InternalError(
                f"Expected exactly one function argument for server-created application "
                f"function call, got {len(serialized_args)}."
            )

        if function._application_config is None:
            raise InternalError(
                "Non-application function was called without SDK metadata"
            )

        return None


def deserialize_sdk_function_call_args(
    serialized_args: List[SerializedValue],
) -> Dict[str, Value]:
    """Returns a mapping from serialized argument IDs to their deserialized Values.

    Raises TensorlakeError on error.
    """
    args: Dict[str, Value] = {}
    for ix, serialized_arg in enumerate(serialized_args):
        if serialized_arg.metadata is None:
            raise InternalError("SDK function call arguments must have metadata.")

        args[serialized_arg.metadata.id] = Value(
            metadata=serialized_arg.metadata,
            object=deserialize_value_with_metadata(
                serialized_value=serialized_arg.data,
                metadata=serialized_arg.metadata,
            ),
            input_ix=ix,
        )

    return args


def reconstruct_sdk_function_call_args(
    function_call_metadata: FunctionCallMetadata | ReduceOperationMetadata,
    arg_values: Dict[str, Value],
    function_instance_arg: Any | None,
) -> tuple[List[Any], Dict[str, Any]]:
    """Returns function call args and kwargs reconstructed from arg_values."""
    args, kwargs = _reconstruct_sdk_function_call_args(
        function_call_metadata=function_call_metadata,
        arg_values=arg_values,
    )

    if function_instance_arg is not None:
        set_self_arg(args, function_instance_arg)

    return args, kwargs


def _reconstruct_sdk_function_call_args(
    function_call_metadata: FunctionCallMetadata | ReduceOperationMetadata,
    arg_values: Dict[str, Value],
) -> tuple[List[Any], Dict[str, Any]]:
    if isinstance(function_call_metadata, FunctionCallMetadata):
        args: List[Any] = []
        kwargs: Dict[str, Any] = {}

        for arg_metadata in function_call_metadata.args:
            args.append(_reconstruct_function_arg_value(arg_metadata, arg_values))
        for kwarg_key, kwarg_metadata in function_call_metadata.kwargs.items():
            kwargs[kwarg_key] = _reconstruct_function_arg_value(
                kwarg_metadata, arg_values
            )
        return args, kwargs
    elif isinstance(function_call_metadata, ReduceOperationMetadata):
        if len(arg_values) != 2:
            raise InternalError(
                f"Expected exactly 2 argument values for reducer function call, got {len(arg_values)}"
            )
        args: List[Value] = list(arg_values.values())
        # Server provides accumulator first, item second
        args.sort(key=lambda arg: arg.input_ix)
        return [arg.object for arg in args], {}


def _reconstruct_function_arg_value(
    arg_metadata: FunctionCallArgumentMetadata, arg_values: Dict[str, Value]
) -> Any:
    """Reconstructs the original value from function arg metadata."""
    # NB: This code needs to be in sync with LocalRunner where it's doing a similar thing.
    if arg_metadata.collection is None:
        return arg_values[arg_metadata.value_id].object
    else:
        return _reconstruct_collection_value(arg_metadata.collection, arg_values)


def _reconstruct_collection_value(
    collection_metadata: CollectionMetadata, arg_values: Dict[str, Value]
) -> List[Any]:
    """Reconstructs the original values from the supplied collection metadata."""
    # NB: This code needs to be in sync with LocalRunner where it's doing a similar thing.
    result: list[Any] = []
    stack: list[tuple[CollectionMetadata, list[Any]]] = [(collection_metadata, result)]
    while len(stack) > 0:
        collection_metadata, collection_values = stack.pop()

        for item in collection_metadata.items:
            if item.collection is None:
                collection_values.append(arg_values[item.value_id].object)
            else:
                item_collection: list[Any] = []
                stack.append((item.collection, item_collection))
                collection_values.append(item_collection)

    return result


def _add_durable_id_attr(node: Awaitable | Any, durable_attrs: list[str]) -> None:
    # We don't hash user provided values. Only hash Awaitables to verify tree structure.
    if isinstance(node, Awaitable):
        durable_attrs.append(node.id)


def _sha256_hash_strings(strings: list[str]) -> str:
    """Returns sha256 hash of the concatenation of strings in the given list.

    If the strings are sha256 hashes, the result is also a high quality sha256 hash
    of the original hashed values. See https://en.wikipedia.org/wiki/Merkle_tree.
    """
    sha256 = hashlib.sha256()
    for s in strings:
        sha256.update(s.encode("utf-8"))
        sha256.update(b"|")  # Separator to avoid collisions of neighbouring strings.
    return sha256.hexdigest()
