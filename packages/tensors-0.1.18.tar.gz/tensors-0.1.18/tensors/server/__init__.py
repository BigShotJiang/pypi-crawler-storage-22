"""Tensors server — FastAPI app for gallery and CivitAI management."""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

from fastapi import Depends, FastAPI
from scalar_fastapi import get_scalar_api_reference

from tensors.config import get_server_api_key
from tensors.server.civitai_routes import create_civitai_router
from tensors.server.db_routes import create_db_router
from tensors.server.download_routes import create_download_router
from tensors.server.gallery_routes import create_gallery_router

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from fastapi.responses import HTMLResponse

__all__ = ["app", "create_app"]

logger = logging.getLogger(__name__)


def create_app() -> FastAPI:
    """Build the FastAPI application for gallery and model management."""

    @asynccontextmanager
    async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
        api_key = get_server_api_key()
        if api_key:
            logger.info("Tensors server starting (auth enabled)")
        else:
            logger.info("Tensors server starting (no auth)")
        yield

    app = FastAPI(
        title="tensors",
        description="API for CivitAI model management and image gallery",
        version="0.1.18",
        lifespan=lifespan,
        docs_url=None,
        redoc_url=None,
    )

    # Public endpoints (no auth)
    @app.get("/status")
    async def status() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/docs", include_in_schema=False)
    async def scalar_docs() -> HTMLResponse:
        return get_scalar_api_reference(
            openapi_url=app.openapi_url or "/openapi.json",
            title="tensors API",
        )

    # Protected routers (auth required if configured)
    from tensors.server.auth import verify_api_key  # noqa: PLC0415

    app.include_router(create_civitai_router(), dependencies=[Depends(verify_api_key)])
    app.include_router(create_db_router(), dependencies=[Depends(verify_api_key)])
    app.include_router(create_gallery_router(), dependencies=[Depends(verify_api_key)])
    app.include_router(create_download_router(), dependencies=[Depends(verify_api_key)])
    return app


# Module-level app instance for uvicorn
app = create_app()
