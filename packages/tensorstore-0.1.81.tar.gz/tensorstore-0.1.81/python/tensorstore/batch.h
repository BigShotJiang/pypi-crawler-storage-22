// Copyright 2020 The TensorStore Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef PYTHON_TENSORSTORE_BATCH_H_
#define PYTHON_TENSORSTORE_BATCH_H_

#include <pybind11/pybind11.h>
// Other headers must be included after pybind11 to ensure header-order
// inclusion constraints are satisfied.

#include <optional>

#include "python/tensorstore/locking_type_casters.h"  // IWYU pragma: keep
#include "tensorstore/batch.h"

namespace tensorstore {
namespace internal_python {

Batch ValidateOptionalBatch(std::optional<Batch> batch);

}  // namespace internal_python
}  // namespace tensorstore

#endif  // PYTHON_TENSORSTORE_BATCH_H_
