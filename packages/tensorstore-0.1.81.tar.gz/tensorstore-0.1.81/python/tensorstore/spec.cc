// Copyright 2020 The TensorStore Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
// Other headers must be included after pybind11 to ensure header-order
// inclusion constraints are satisfied.

#include "python/tensorstore/spec.h"

// Other headers
#include <optional>
#include <string>
#include <utility>

#include "absl/time/time.h"
#include <nlohmann/json_fwd.hpp>
#include "python/tensorstore/critical_section.h"
#include "python/tensorstore/homogeneous_tuple.h"
#include "python/tensorstore/index_space.h"
#include "python/tensorstore/intrusive_ptr_holder.h"
#include "python/tensorstore/json_type_caster.h"
#include "python/tensorstore/keyword_arguments.h"
#include "python/tensorstore/locking_type_casters.h"  // IWYU pragma: keep
#include "python/tensorstore/result_type_caster.h"
#include "python/tensorstore/serialization.h"
#include "python/tensorstore/status.h"
#include "python/tensorstore/tensorstore_module_components.h"
#include "python/tensorstore/with_handle.h"
#include "tensorstore/array.h"
#include "tensorstore/chunk_layout.h"
#include "tensorstore/codec_spec.h"
#include "tensorstore/data_type.h"
#include "tensorstore/driver/driver.h"
#include "tensorstore/index.h"
#include "tensorstore/index_space/index_domain.h"
#include "tensorstore/index_space/index_transform.h"
#include "tensorstore/internal/global_initializer.h"
#include "tensorstore/internal/intrusive_ptr.h"
#include "tensorstore/internal/json/pprint_python.h"
#include "tensorstore/internal/meta/type_traits.h"
#include "tensorstore/json_serialization_options.h"
#include "tensorstore/json_serialization_options_base.h"
#include "tensorstore/kvstore/spec.h"
#include "tensorstore/open_mode.h"
#include "tensorstore/open_options.h"
#include "tensorstore/rank.h"
#include "tensorstore/schema.h"
#include "tensorstore/spec.h"
#include "tensorstore/staleness_bound.h"
#include "tensorstore/util/executor.h"
#include "tensorstore/util/span.h"
#include "tensorstore/util/str_cat.h"
#include "tensorstore/util/unit.h"

namespace tensorstore {
namespace internal_python {
namespace {

namespace py = pybind11;

std::optional<DimensionIndex> RankToOptional(DimensionIndex rank) {
  if (rank == dynamic_rank) return std::nullopt;
  return rank;
}

std::optional<HomogeneousTuple<std::optional<Unit>>> GetDimensionUnits(
    DimensionIndex rank, span<const std::optional<Unit>> units) {
  if (rank == dynamic_rank) return std::nullopt;
  if (units.empty()) {
    const std::optional<Unit> units_vec[kMaxRank];
    return internal_python::SpanToHomogeneousTuple<std::optional<Unit>>(
        span(&units_vec[0], rank));
  }
  return internal_python::SpanToHomogeneousTuple<std::optional<Unit>>(units);
}

constexpr auto WithSpecKeywordArguments = [](auto callback,
                                             auto... other_param) {
  WithSchemaKeywordArguments(
      callback, other_param..., spec_setters::SetOpenMode{},
      spec_setters::SetOpen{}, spec_setters::SetCreate{},
      spec_setters::SetDeleteExisting{}, spec_setters::SetAssumeMetadata{},
      spec_setters::SetAssumeCachedMetadata{}, spec_setters::SetUnbindContext{},
      spec_setters::SetStripContext{}, spec_setters::SetContext{},
      spec_setters::SetKvstore{}, spec_setters::SetMinimalSpec{},
      spec_setters::SetRecheckCachedMetadata{},
      spec_setters::SetRecheckCachedData{}, spec_setters::SetRecheckCached{});
};

using SpecCls = py::class_<PythonSpecObject>;

auto MakeSpecClass(py::module m) {
  auto cls = PythonSpecObject::Define(R"(
Specification for opening or creating a :py:obj:`.TensorStore`.

Group:
  Spec

Constructors
============

Accessors
=========

Indexing
========

Comparison operators
====================

)");
  m.attr("Spec") = cls;
  return cls;
}

void DefineSpecAttributes(SpecCls& cls) {
  using Self = PythonSpecObject;

  cls.def(
      "__new__",
      [](py::handle cls, ::nlohmann::json json) {
        return ValueOrThrow(Spec::FromJson(std::move(json)));
      },
      R"(
Constructs from the :json:schema:`JSON representation<TensorStore>`.

Example:

  >>> spec = ts.Spec({'driver': 'n5', 'kvstore': {'driver': 'memory'}})
  >>> spec
  Spec({'driver': 'n5', 'kvstore': {'driver': 'memory'}})

)",
      py::arg("json"));

  WithSpecKeywordArguments([&](auto... param_def) {
    std::string doc = R"(
Adds additional constraints or changes the open mode.

Example:

  >>> spec = ts.Spec({'driver': 'n5', 'kvstore': {'driver': 'memory'}})
  >>> spec.update(shape=[100, 200, 300])
  >>> spec
  Spec({
    'driver': 'n5',
    'kvstore': {'driver': 'memory'},
    'schema': {
      'domain': {'exclusive_max': [100, 200, 300], 'inclusive_min': [0, 0, 0]},
    },
    'transform': {
      'input_exclusive_max': [[100], [200], [300]],
      'input_inclusive_min': [0, 0, 0],
    },
  })

Args:
)";
    AppendKeywordArgumentDocs(doc, param_def...);
    doc += R"(

Group:
  Mutators
)";
    struct Update {
      void operator()(Self& self,
                      KeywordArgument<decltype(param_def)>... kwarg) const {
        SpecConvertOptions options;
        ApplyKeywordArguments<decltype(param_def)...>(options, kwarg...);
        ScopedPyCriticalSection cs(reinterpret_cast<PyObject*>(&self));
        ThrowStatusException(self.value.Set(std::move(options)));
        self.UpdatePythonRefs();
      }
    };
    cls.def("update", Update{}, doc.c_str(), py::kw_only(),
            MakeKeywordArgumentPyArg(param_def)...);
  });

  struct GetOpenMode {
    OpenMode operator()(const Self& self) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      return self.value.open_mode();
    }
  };
  cls.def_property_readonly("open_mode", GetOpenMode{},
                            R"(
Open mode with which the driver will be opened.

If not applicable, equal to :python:`OpenMode()`.

Example:

  >>> spec = ts.Spec({'driver': 'zarr', 'kvstore': 'memory://'})
  >>> spec.open_mode
  OpenMode(open=True)
  >>> spec.update(create=True, delete_existing=True)
  >>> spec.open_mode
  OpenMode(create=True, delete_existing=True)
  >>> spec.update(open_mode=ts.OpenMode(open=True, create=True))
  >>> spec.open_mode
  OpenMode(open=True, create=True)

.. note::

   This is a read-only accessor.  Mutating the returned `OpenMode` object does
   not affect this `Spec` object.  To change the open mode, use `.update`.

Group:
  Accessors
)");

  struct GetDtype {
    std::optional<DataType> operator()(const Self& self) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      if (const auto& dtype = self.value.dtype(); dtype.valid()) {
        return dtype;
      }
      return std::nullopt;
    }
  };
  cls.def_property_readonly("dtype", GetDtype{},
                            R"(
Data type, or :python:`None` if unspecified.

Example:

  >>> spec = ts.Spec({'driver': 'n5', 'kvstore': {'driver': 'memory'}})
  >>> print(spec.dtype)
  None

  >>> spec = ts.Spec({
  ...     'driver': 'n5',
  ...     'kvstore': {
  ...         'driver': 'memory'
  ...     },
  ...     'metadata': {
  ...         'dataType': 'uint8'
  ...     }
  ... })
  >>> spec.dtype
  dtype("uint8")

Group:
  Accessors
)");

  struct GetTransform {
    std::optional<IndexTransform<>> operator()(const Self& self) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      if (const auto& transform = self.value.transform(); transform.valid()) {
        return transform;
      }
      return std::nullopt;
    }
  };
  cls.def_property_readonly("transform", GetTransform{},
                            R"(
The :ref:`index transform<index-transform>`, or `None` if unspecified.

Example:

  >>> spec = ts.Spec({'driver': 'n5', 'kvstore': {'driver': 'memory'}})
  >>> print(spec.transform)
  None

  >>> spec = ts.Spec({
  ...     'driver': 'n5',
  ...     'kvstore': {
  ...         'driver': 'memory'
  ...     },
  ...     'metadata': {
  ...         'dimensions': [100, 200],
  ...         'axes': ['x', 'y']
  ...     }
  ... })
  >>> spec.transform
  Rank 2 -> 2 index space transform:
    Input domain:
      0: [0, 100*) "x"
      1: [0, 200*) "y"
    Output index maps:
      out[0] = 0 + 1 * in[0]
      out[1] = 0 + 1 * in[1]
  >>> spec[ts.d['x'].translate_by[5]].transform
  Rank 2 -> 2 index space transform:
    Input domain:
      0: [5, 105*) "x"
      1: [0, 200*) "y"
    Output index maps:
      out[0] = -5 + 1 * in[0]
      out[1] = 0 + 1 * in[1]

Group:
  Accessors
)");

  struct GetDomainFromTransform {
    std::optional<IndexDomain<>> operator()(const Self& self) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      if (const auto& transform = self.value.transform(); transform.valid()) {
        return transform.domain();
      }
      return std::nullopt;
    }
  };
  cls.def_property_readonly("domain", GetDomainFromTransform{},
                            R"(
Returns the :ref:`index domain<index-domain>`, or `None` if unspecified.

Example:

  >>> spec = ts.Spec({'driver': 'n5', 'kvstore': {'driver': 'memory'}})
  >>> print(spec.domain)
  None

  >>> spec = ts.Spec({
  ...     'driver': 'n5',
  ...     'kvstore': {
  ...         'driver': 'memory'
  ...     },
  ...     'metadata': {
  ...         'dimensions': [100, 200],
  ...         'axes': ['x', 'y']
  ...     }
  ... })
  >>> spec.domain
  { "x": [0, 100*), "y": [0, 200*) }

Group:
  Accessors
)");

  struct GetRank {
    std::optional<DimensionIndex> operator()(const Self& self) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      return RankToOptional(self.value.rank());
    }
  };
  cls.def_property_readonly("rank", GetRank{},
                            R"(
Returns the rank of the domain, or `None` if unspecified.

Example:

  >>> spec = ts.Spec({'driver': 'n5', 'kvstore': {'driver': 'memory'}})
  >>> print(spec.rank)
  None

  >>> spec = ts.Spec({
  ...     'driver': 'n5',
  ...     'kvstore': {
  ...         'driver': 'memory'
  ...     },
  ...     'metadata': {
  ...         'dimensions': [100, 200]
  ...     }
  ... })
  >>> spec.rank
  2

Group:
  Accessors
)");

  struct GetNdim {
    std::optional<DimensionIndex> operator()(const Self& self) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      return RankToOptional(self.value.rank());
    }
  };
  cls.def_property_readonly("ndim", GetNdim{},
                            R"(
Alias for :py:obj:`.rank`.

Example:

  >>> spec = ts.Spec({'driver': 'n5', 'kvstore': {'driver': 'memory'}})
  >>> print(spec.ndim)
  None

  >>> spec = ts.Spec({
  ...     'driver': 'n5',
  ...     'kvstore': {
  ...         'driver': 'memory'
  ...     },
  ...     'metadata': {
  ...         'dimensions': [100, 200]
  ...     }
  ... })
  >>> spec.ndim
  2

Group:
  Accessors
)");

  struct GetSchema {
    Schema operator()(const Self& self) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      return ValueOrThrow(self.value.schema());
    }
  };
  cls.def_property_readonly("schema", GetSchema{},
                            R"(
Effective :ref:`schema<schema>`, including any constraints implied by driver-specific options.

Example:

  >>> spec = ts.Spec({
  ...     'driver': 'zarr',
  ...     'kvstore': {
  ...         'driver': 'memory'
  ...     },
  ...     'metadata': {
  ...         'dtype': '<u2',
  ...         'chunks': [100, 200, 300],
  ...         'shape': [1000, 2000, 3000],
  ...         'order': 'C'
  ...     }
  ... })
  >>> spec.schema
  Schema({
    'chunk_layout': {
      'grid_origin': [0, 0, 0],
      'inner_order': [0, 1, 2],
      'read_chunk': {'shape': [100, 200, 300]},
      'write_chunk': {'shape': [100, 200, 300]},
    },
    'codec': {'driver': 'zarr'},
    'domain': {
      'exclusive_max': [[1000], [2000], [3000]],
      'inclusive_min': [0, 0, 0],
    },
    'dtype': 'uint16',
    'rank': 3,
  })

Note:

  This does not perform any I/O.  Only directly-specified constraints are
  included.

Group:
  Accessors
)");

  struct GetDomain {
    std::optional<IndexDomain<>> operator()(const Self& self) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      auto domain = ValueOrThrow(self.value.domain());
      if (!domain.valid()) return std::nullopt;
      return domain;
    }
  };
  cls.def_property_readonly("domain", GetDomain{},
                            R"(

Effective :ref:`index domain<index-domain>`, including any constraints implied
by driver-specific options.

Example:

  >>> spec = ts.Spec({
  ...     'driver': 'zarr',
  ...     'kvstore': {
  ...         'driver': 'memory'
  ...     },
  ...     'metadata': {
  ...         'dtype': '<u2',
  ...         'shape': [1000, 2000, 3000],
  ...     }
  ... })
  >>> spec.domain
  { [0, 1000*), [0, 2000*), [0, 3000*) }

Note:

  This does not perform any I/O.  Only directly-specified constraints are
  included.

Group:
  Accessors


)");

  struct GetChunkLayout {
    ChunkLayout operator()(const Self& self) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      return ValueOrThrow(self.value.chunk_layout());
    }
  };
  cls.def_property_readonly("chunk_layout", GetChunkLayout{},
                            R"(

Effective :ref:`chunk layout<chunk-layout>`, including any constraints implied
by driver-specific options.

Example:

  >>> spec = ts.Spec({
  ...     'driver': 'zarr',
  ...     'kvstore': {
  ...         'driver': 'memory'
  ...     },
  ...     'metadata': {
  ...         'chunks': [100, 200, 300],
  ...         'order': 'C'
  ...     }
  ... })
  >>> spec.chunk_layout
  ChunkLayout({})

Note:

  This does not perform any I/O.  Only directly-specified constraints are
  included.

Group:
  Accessors

)");

  struct GetCodec {
    std::optional<internal::IntrusivePtr<const internal::CodecDriverSpec>>
    operator()(const Self& self) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      auto codec = ValueOrThrow(self.value.codec());
      if (!codec.valid()) return std::nullopt;
      return internal::IntrusivePtr<const internal::CodecDriverSpec>(
          std::move(codec));
    }
  };
  cls.def_property_readonly("codec", GetCodec{},
                            R"(

Effective :ref:`codec<codec>`, including any constraints implied
by driver-specific options.

Example:

  >>> spec = ts.Spec({
  ...     'driver': 'zarr',
  ...     'kvstore': {
  ...         'driver': 'memory'
  ...     },
  ...     'metadata': {
  ...         'compressor': None,
  ...     }
  ... })
  >>> spec.codec
  CodecSpec({'compressor': None, 'driver': 'zarr'})

Note:

  This does not perform any I/O.  Only directly-specified constraints are
  included.

Group:
  Accessors

)");

  struct GetFillValue {
    std::optional<SharedArray<const void>> operator()(const Self& self) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      auto fill_value = ValueOrThrow(self.value.fill_value());
      if (!fill_value.valid()) return std::nullopt;
      return SharedArray<const void>(std::move(fill_value));
    }
  };
  cls.def_property_readonly("fill_value", GetFillValue{},
                            R"(

Effective fill value, including any constraints implied by driver-specific
options.

Example:

  >>> spec = ts.Spec({
  ...     'driver': 'zarr',
  ...     'kvstore': {
  ...         'driver': 'memory'
  ...     },
  ...     'metadata': {
  ...         'compressor': None,
  ...         'dtype': '<f4',
  ...         'fill_value': 42,
  ...     }
  ... })
  >>> spec.fill_value
  array(42., dtype=float32)

Note:

  This does not perform any I/O.  Only directly-specified constraints are
  included.

Group:
  Accessors

)");

  struct GetDimensionUnits {
    std::optional<HomogeneousTuple<std::optional<Unit>>> operator()(
        const Self& self) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      return internal_python::GetDimensionUnits(
          self.value.rank(), ValueOrThrow(self.value.dimension_units()));
    }
  };
  cls.def_property_readonly("dimension_units", GetDimensionUnits{},
                            R"(

Effective physical units of each dimension of the domain, including any
constraints implied by driver-specific options.

Example:

  >>> spec = ts.Spec({
  ...     'driver': 'n5',
  ...     'kvstore': {
  ...         'driver': 'memory'
  ...     },
  ...     'metadata': {
  ...         'units': ['nm', 'nm', 'um'],
  ...         'resolution': [200, 300, 1],
  ...     }
  ... })
  >>> spec.dimension_units
  (Unit(200, "nm"), Unit(300, "nm"), Unit(1, "um"))

Note:

  This does not perform any I/O.  Only directly-specified constraints are
  included.

Group:
  Accessors

)");

  struct GetKvstore {
    std::optional<kvstore::Spec> operator()(const Self& self) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      auto kvstore = self.value.kvstore();
      if (!kvstore.valid()) return std::nullopt;
      return kvstore;
    }
  };
  cls.def_property_readonly("kvstore", GetKvstore{},
                            R"(

Spec of the associated key-value store used as the underlying storage.

Equal to :python:`None` if the driver does not use a key-value store or the
key-value store has not been specified.

Example:

  >>> spec = ts.Spec({
  ...     'driver': 'n5',
  ...     'kvstore': {
  ...         'driver': 'memory',
  ...         'path': 'abc/',
  ...     },
  ... })
  >>> spec.kvstore
  KvStore.Spec({'driver': 'memory', 'path': 'abc/'})

Group:
  Accessors

       )");

  struct GetUrl {
    std::string operator()(const Self& self) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      return ValueOrThrow(self.value.ToUrl());
    }
  };
  cls.def_property_readonly("url", GetUrl{},
                            R"(
:json:schema:`URL representation<TensorStoreUrl>` of the TensorStore specification.

Example:

    >>> spec = ts.Spec({
    ...     'driver': 'n5',
    ...     'kvstore': {
    ...         'driver': 'gcs',
    ...         'bucket': 'my-bucket',
    ...         'path': 'path/to/array/'
    ...     }
    ... })
    >>> spec.url
    'gs://my-bucket/path/to/array/|n5:'

Group:
  Accessors
)");

  struct GetBase {
    std::optional<Spec> operator()(const Self& self) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      auto spec = ValueOrThrow(self.value.base());
      if (!spec.valid()) return std::nullopt;
      return spec;
    }
  };
  cls.def_property_readonly("base", GetBase{},
                            R"(

Spec of the underlying `TensorStore`, if this is an adapter of a single
underlying `TensorStore`.

Otherwise, equal to :python:`None`.

Drivers that support this method include:

- :ref:`driver/cast`
- :ref:`driver/downsample`

Example:

  >>> spec = ts.Spec({
  ...     'driver': 'zarr',
  ...     'kvstore': 'memory://',
  ... })
  >>> spec.update(shape=[100, 200], dtype=ts.uint32)
  >>> cast_spec = ts.cast(spec, ts.float32)
  >>> cast_spec
  Spec({
    'base': {
      'driver': 'zarr',
      'dtype': 'uint32',
      'kvstore': {'driver': 'memory'},
      'schema': {
        'domain': {'exclusive_max': [100, 200], 'inclusive_min': [0, 0]},
      },
    },
    'driver': 'cast',
    'dtype': 'float32',
    'transform': {
      'input_exclusive_max': [[100], [200]],
      'input_inclusive_min': [0, 0],
    },
  })
  >>> cast_spec[30:40, 20:25].base
  Spec({
    'driver': 'zarr',
    'dtype': 'uint32',
    'kvstore': {'driver': 'memory'},
    'schema': {'domain': {'exclusive_max': [100, 200], 'inclusive_min': [0, 0]}},
    'transform': {
      'input_exclusive_max': [40, 25],
      'input_inclusive_min': [30, 20],
    },
  })
  >>> downsampled_spec = ts.downsample(spec,
  ...                                  downsample_factors=[2, 4],
  ...                                  method='mean')
  >>> downsampled_spec
  Spec({
    'base': {
      'driver': 'zarr',
      'kvstore': {'driver': 'memory'},
      'schema': {
        'domain': {'exclusive_max': [100, 200], 'inclusive_min': [0, 0]},
      },
      'transform': {
        'input_exclusive_max': [[100], [200]],
        'input_inclusive_min': [0, 0],
      },
    },
    'downsample_factors': [2, 4],
    'downsample_method': 'mean',
    'driver': 'downsample',
    'dtype': 'uint32',
    'transform': {
      'input_exclusive_max': [[50], [50]],
      'input_inclusive_min': [0, 0],
    },
  })
  >>> downsampled_spec[30:40, 20:25].base

Group:
  Accessors

)");

  struct ToJson {
    ::nlohmann::json operator()(const Self& self, bool include_defaults) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      return ValueOrThrow(
          self.value.ToJson({IncludeDefaults{include_defaults}}));
    }
  };
  cls.def("to_json", ToJson{},
          R"(
Converts to the :json:schema:`JSON representation<TensorStore>`.

Example:

  >>> spec = ts.Spec({
  ...     'driver': 'n5',
  ...     'kvstore': {
  ...         'driver': 'memory'
  ...     },
  ...     'metadata': {
  ...         'dimensions': [100, 200]
  ...     }
  ... })
  >>> spec = spec[ts.d[0].translate_by[5]]
  >>> spec.to_json()
  {'driver': 'n5',
   'kvstore': {'driver': 'memory'},
   'metadata': {'dimensions': [100, 200]},
   'transform': {'input_exclusive_max': [[105], [200]],
                 'input_inclusive_min': [5, 0],
                 'output': [{'input_dimension': 0, 'offset': -5},
                            {'input_dimension': 1}]}}

Group:
  Accessors
)",
          py::arg("include_defaults") = false);

  struct CopyFunctor {
    Spec operator()(const Self& self) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      return self.value;
    }
  };

  cls.def("copy", CopyFunctor{},
          R"(
Returns a copy of the spec.

Example:

  >>> a = ts.Spec({'driver': 'n5', 'kvstore': {'driver': 'memory'}})
  >>> b = a.copy()
  >>> a.update(dtype=ts.uint8)
  >>> b.update(dtype=ts.uint16)
  >>> a
  Spec({'driver': 'n5', 'dtype': 'uint8', 'kvstore': {'driver': 'memory'}})
  >>> b
  Spec({'driver': 'n5', 'dtype': 'uint16', 'kvstore': {'driver': 'memory'}})

Group:
  Accessors
)");

  cls.def("__copy__", CopyFunctor{});

  struct DeepCopyFunctor {
    Spec operator()(const Self& self, py::dict memo) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      return self.value;
    }
  };
  cls.def("__deepcopy__", DeepCopyFunctor{}, py::arg("memo"));

  struct Repr {
    std::string operator()(const Self& self) const {
      ScopedPyCriticalSection cs(reinterpret_cast<const PyObject*>(&self));
      JsonSerializationOptions options;
      options.preserve_bound_context_resources_ = true;
      return internal_python::PrettyPrintJsonAsPythonRepr(
          self.value.ToJson(options), "Spec(", ")");
    }
  };
  cls.def("__repr__", Repr{},
          R"(
Returns a string representation based on the :json:schema:`JSON representation<TensorStore>`.

Example:

  >>> spec = ts.Spec({'driver': 'n5', 'kvstore': {'driver': 'memory'}})
  >>> spec
  Spec({'driver': 'n5', 'kvstore': {'driver': 'memory'}})

  Bound :json:schema:`context resources<ContextResource>` are indicated by
  single-element arrays:

  >>> spec.update(context=ts.Context())
  >>> spec
  Spec({
    'cache_pool': ['cache_pool'],
    'context': {
      'cache_pool': {},
      'data_copy_concurrency': {},
      'memory_key_value_store': {},
    },
    'data_copy_concurrency': ['data_copy_concurrency'],
    'driver': 'n5',
    'kvstore': {
      'driver': 'memory',
      'memory_key_value_store': ['memory_key_value_store'],
    },
  })

)");

  struct Eq {
    bool operator()(const Self& self, const Self& other) const {
      ScopedPyCriticalSection2 cs(reinterpret_cast<const PyObject*>(&self),
                                  reinterpret_cast<const PyObject*>(&other));
      return self.value == other.value;
    }
  };
  cls.def("__eq__", Eq{}, py::arg("other"),
          R"(
Compares with another :py:obj:`Spec` for equality based on the :json:schema:`JSON representation<TensorStore>`.

The comparison is based on the JSON representation, except that any bound
context resources are compared by identity (not by their JSON representation).

Example:

  >>> spec = ts.Spec({'driver': 'n5', 'kvstore': {'driver': 'memory'}})
  >>> assert spec == spec
  >>> a, b = spec.copy(), spec.copy()
  >>> context_a, context_b = ts.Context(), ts.Context()
  >>> a.update(context=context_a)
  >>> b.update(context=context_b)
  >>> assert a == a
  >>> assert a != b

)");

  EnableGarbageCollectedObjectPicklingFromSerialization(
      cls, internal::SpecNonNullSerializer{});

  cls.attr("__iter__") = py::none();

  DefineIndexTransformOperations</*WithLocking=*/true>(
      &cls,
      /*doc_strings=*/
      {
          /*numpy_indexing=*/{
              /*kDefault*/ {R"(
Transforms the spec using :ref:`NumPy-style indexing<python-numpy-style-indexing>` with default index array semantics.

Example:

    >>> spec = ts.Spec({
    ...     'driver': 'zarr',
    ...     'kvstore': {
    ...         'driver': 'memory'
    ...     },
    ...     'transform': {
    ...         'input_shape': [[70], [80]],
    ...     }
    ... })
    >>> spec[[5, 10, 20], 6:10]
    Spec({
      'driver': 'zarr',
      'kvstore': {'driver': 'memory'},
      'transform': {
        'input_exclusive_max': [3, 10],
        'input_inclusive_min': [0, 6],
        'output': [{'index_array': [[5], [10], [20]]}, {'input_dimension': 1}],
      },
    })

Returns:
  New spec with the indexing operation applied.

Raises:
  ValueError: If :py:obj:`self.transform<.transform>` is :python:`None`.

See also:

   - :ref:`python-numpy-style-indexing`
   - :py:obj:`IndexTransform.__getitem__(indices)`
   - :py:obj:`Spec.oindex`
   - :py:obj:`Spec.vindex`

Group:
  Indexing

Overload:
  indices
)"},
              /*kOindex*/ {R"(
Transforms the spec using :ref:`NumPy-style indexing<python-numpy-style-indexing>` with :ref:`outer indexing semantics<python-oindex-indexing>`.

This is similar to :py:obj:`.__getitem__(indices)`, but differs in that any
integer or boolean array indexing terms are applied orthogonally.

Example:

    >>> spec = ts.Spec({
    ...     'driver': 'zarr',
    ...     'kvstore': {
    ...         'driver': 'memory'
    ...     },
    ...     'transform': {
    ...         'input_shape': [[70], [80]],
    ...     }
    ... })
    >>> spec.oindex[[5, 10, 20], [7, 8, 10]]
    Spec({
      'driver': 'zarr',
      'kvstore': {'driver': 'memory'},
      'transform': {
        'input_exclusive_max': [3, 3],
        'input_inclusive_min': [0, 0],
        'output': [
          {'index_array': [[5], [10], [20]]},
          {'index_array': [[7, 8, 10]]},
        ],
      },
    })

Returns:
  New spec with the indexing operation applied.

Raises:
  ValueError: If :py:obj:`self.transform<.transform>` is :python:`None`.

See also:

   - :ref:`python-numpy-style-indexing`
   - :py:obj:`IndexTransform.oindex`
   - :py:obj:`Spec.__getitem__(indices)`
   - :py:obj:`Spec.vindex`

Group:
  Indexing
)"},
              /*kVindex*/ {R"(
Transforms the spec using :ref:`NumPy-style indexing<python-numpy-style-indexing>` with :ref:`vectorized indexing semantics<python-vindex-indexing>`.

This is similar to :py:obj:`.__getitem__(indices)`, but differs in that if
:python:`indices` specifies any array indexing terms, the broadcasted array
dimensions are unconditionally added as the first dimensions of the result
domain.

Example:

    >>> spec = ts.Spec({
    ...     'driver': 'zarr',
    ...     'kvstore': {
    ...         'driver': 'memory'
    ...     },
    ...     'transform': {
    ...         'input_shape': [[70], [80]],
    ...     }
    ... })
    >>> spec.vindex[[5, 10, 20], [7, 8, 10]]
    Spec({
      'driver': 'zarr',
      'kvstore': {'driver': 'memory'},
      'transform': {
        'input_exclusive_max': [3],
        'input_inclusive_min': [0],
        'output': [{'index_array': [5, 10, 20]}, {'index_array': [7, 8, 10]}],
      },
    })

Returns:
  New spec with the indexing operation applied.

Raises:
  ValueError: If :py:obj:`self.transform<.transform>` is :python:`None`.

See also:

   - :ref:`python-numpy-style-indexing`
   - :py:obj:`IndexTransform.vindex`
   - :py:obj:`Spec.__getitem__(indices)`
   - :py:obj:`Spec.oindex`

Group:
  Indexing
)"},
          },
          /*index_transform*/ {R"(
Transforms the spec using an explicit :ref:`index transform<index-transform>`.

This composes :python:`self.transform` with :python:`transform`.

Example:

    >>> spec = ts.Spec({
    ...     'driver': 'zarr',
    ...     'kvstore': {
    ...         'driver': 'memory'
    ...     },
    ...     'transform': {
    ...         'input_shape': [[70], [80]],
    ...     }
    ... })
    >>> transform = ts.IndexTransform(
    ...     input_shape=[3],
    ...     output=[
    ...         ts.OutputIndexMap(index_array=[1, 2, 3]),
    ...         ts.OutputIndexMap(index_array=[5, 4, 3])
    ...     ])
    >>> spec[transform]
    Spec({
      'driver': 'zarr',
      'kvstore': {'driver': 'memory'},
      'transform': {
        'input_exclusive_max': [3],
        'input_inclusive_min': [0],
        'output': [{'index_array': [1, 2, 3]}, {'index_array': [5, 4, 3]}],
      },
    })

Args:

  transform: Index transform, :python:`transform.output_rank` must equal
    :python:`self.rank`.

Returns:

  New spec of rank :python:`transform.input_rank` and transform
  :python:`self.transform[transform]`.

Raises:
  ValueError: If :py:obj:`self.transform<.transform>` is :python:`None`.

See also:

   - :ref:`python-numpy-style-indexing`
   - :py:obj:`IndexTransform.__getitem__(transform)`
   - :py:obj:`Spec.__getitem__(indices)`
   - :py:obj:`Spec.__getitem__(expr)`
   - :py:obj:`Spec.__getitem__(domain)`
   - :py:obj:`Spec.oindex`
   - :py:obj:`Spec.vindex`

Overload:
  transform

Group:
  Indexing
)"},
          /*index_domain*/ {R"(
Transforms the spec using an explicit :ref:`index domain<index-domain>`.

The transform of the resultant spec is computed as in
:py:obj:`IndexTransform.__getitem__(domain)`.

Example:

    >>> spec = ts.Spec({
    ...     'driver': 'zarr',
    ...     'kvstore': {
    ...         'driver': 'memory'
    ...     },
    ...     'transform': {
    ...         'input_shape': [[60], [70], [80]],
    ...         'input_labels': ['x', 'y', 'z'],
    ...     }
    ... })
    >>> domain = ts.IndexDomain(labels=['x', 'z'],
    ...                         inclusive_min=[5, 6],
    ...                         exclusive_max=[8, 9])
    >>> spec[domain]
    Spec({
      'driver': 'zarr',
      'kvstore': {'driver': 'memory'},
      'transform': {
        'input_exclusive_max': [8, [70], 9],
        'input_inclusive_min': [5, 0, 6],
        'input_labels': ['x', 'y', 'z'],
      },
    })

Args:

  domain: Index domain, must have dimension labels that can be
    :ref:`aligned<index-domain-alignment>` to :python:`self.domain`.

Returns:

  New spec with transform equal to :python:`self.transform[domain]`.

Raises:
  ValueError: If :py:obj:`self.transform<.transform>` is :python:`None`.

Group:
  Indexing

Overload:
  domain

See also:

   - :ref:`index-domain`
   - :ref:`index-domain-alignment`
   - :py:obj:`IndexTransform.__getitem__(domain)`
)"},
          /*dim_expression*/ {R"(
Transforms the spec using a :ref:`dimension expression<python-dim-expressions>`.

Example:

    >>> spec = ts.Spec({
    ...     'driver': 'zarr',
    ...     'kvstore': {
    ...         'driver': 'memory'
    ...     },
    ...     'transform': {
    ...         'input_shape': [[60], [70], [80]],
    ...         'input_labels': ['x', 'y', 'z'],
    ...     }
    ... })
    >>> spec[ts.d['x', 'z'][5:10, 6:9]]
    Spec({
      'driver': 'zarr',
      'kvstore': {'driver': 'memory'},
      'transform': {
        'input_exclusive_max': [10, [70], 9],
        'input_inclusive_min': [5, 0, 6],
        'input_labels': ['x', 'y', 'z'],
      },
    })

Returns:
  New spec with transform equal to :python:`self.transform[expr]`.

Raises:
  ValueError: If :py:obj:`self.transform<.transform>` is :python:`None`.

Group:
  Indexing

Overload:
  expr

See also:

   - :ref:`python-dim-expressions`
   - :py:obj:`IndexTransform.__getitem__(expr)`
)"},
      },
      /*get_transform=*/
      [](const Self& self) {
        return ValueOrThrow(self.value.GetTransformForIndexingOperation());
      },
      /*apply_transform=*/
      [](const Self& self, IndexTransform<> new_transform) {
        Spec copy = self.value;
        internal_spec::SpecAccess::impl(copy).transform =
            std::move(new_transform);
        return PythonSpec(std::move(copy));
      });
}

auto MakeSchemaClass(py::module m) {
  return py::class_<Schema>(m, "Schema",
                            R"(
Driver-independent options for defining a TensorStore schema.

Group:
  Spec
)");
}

void DefineSchemaAttributes(py::class_<Schema>& cls) {
  using Self = with_handle<Schema&>;
  using ConstSelf = with_handle<const Schema&>;

  struct SchemaFromJson {
    Schema operator()(::nlohmann::json json) const {
      return ValueOrThrow(Schema::FromJson(std::move(json)));
    }
  };
  cls.def(py::init(SchemaFromJson{}),
          R"(
Constructs from its :json:schema:`JSON representation<Schema>`.

Example:

  >>> ts.Schema({
  ...     'dtype': 'uint8',
  ...     'chunk_layout': {
  ...         'grid_origin': [1, 2, 3],
  ...         'inner_order': [0, 2, 1]
  ...     }
  ... })
  Schema({
    'chunk_layout': {'grid_origin': [1, 2, 3], 'inner_order': [0, 2, 1]},
    'dtype': 'uint8',
    'rank': 3,
  })

Overload:
  json
)",
          py::arg("json"));

  WithSchemaKeywordArguments([&](auto... param_def) {
    {
      std::string doc = R"(
Constructs from component parts.

Example:

  >>> ts.Schema(dtype=ts.uint8,
  ...           chunk_layout=ts.ChunkLayout(grid_origin=[1, 2, 3],
  ...                                       inner_order=[0, 2, 1]))
  Schema({
    'chunk_layout': {'grid_origin': [1, 2, 3], 'inner_order': [0, 2, 1]},
    'dtype': 'uint8',
    'rank': 3,
  })

Args:
)";
      AppendKeywordArgumentDocs(doc, param_def...);
      doc += R"(

Overload:
  components
)";
      struct SchemaInitComponents {
        Schema operator()(KeywordArgument<decltype(param_def)>... kwarg) const {
          Schema self;
          ApplyKeywordArguments<decltype(param_def)...>(self, kwarg...);
          return self;
        }
      };
      cls.def(py::init(SchemaInitComponents{}), doc.c_str(), py::kw_only(),
              MakeKeywordArgumentPyArg(param_def)...);
    }

    {
      std::string doc = R"(
Adds additional constraints.

Example:

  >>> schema = ts.Schema(rank=3)
  >>> schema
  Schema({'rank': 3})
  >>> schema.update(dtype=ts.uint8)
  >>> schema
  Schema({'dtype': 'uint8', 'rank': 3})

Args:
)";
      AppendKeywordArgumentDocs(doc, param_def...);
      doc += R"(

Group:
  Mutators
)";
      struct SchemaUpdate {
        void operator()(Self self,
                        KeywordArgument<decltype(param_def)>... kwarg) const {
          ScopedPyCriticalSection cs(self.handle.ptr());
          ApplyKeywordArguments<decltype(param_def)...>(self.value, kwarg...);
        }
      };
      cls.def("update", SchemaUpdate{}, doc.c_str(), py::kw_only(),
              MakeKeywordArgumentPyArg(param_def)...);
    }
  });

  struct GetRank {
    std::optional<DimensionIndex> operator()(ConstSelf self) const {
      ScopedPyCriticalSection cs(self.handle.ptr());
      return RankToOptional(self.value.rank());
    }
  };
  cls.def_property_readonly("rank", GetRank{},
                            R"(
Rank of the schema, or `None` if unspecified.

Example:

  >>> schema = ts.Schema(dtype=ts.uint8)
  >>> print(schema.rank)
  None
  >>> schema.update(chunk_layout=ts.ChunkLayout(grid_origin=[0, 1, 2]))
  >>> schema.rank
  3

Group:
  Accessors
)");

  struct GetNdim {
    std::optional<DimensionIndex> operator()(ConstSelf self) const {
      ScopedPyCriticalSection cs(self.handle.ptr());
      return RankToOptional(self.value.rank());
    }
  };
  cls.def_property_readonly("ndim", GetNdim{},
                            R"(
Alias for :py:obj:`.rank`.

Example:

  >>> schema = ts.Schema(rank=3)
  >>> schema.ndim
  3

Group:
  Accessors
)");

  struct GetDtype {
    std::optional<DataType> operator()(ConstSelf self) const {
      ScopedPyCriticalSection cs(self.handle.ptr());
      if (self.value.dtype().valid()) return self.value.dtype();
      return std::nullopt;
    }
  };
  cls.def_property_readonly("dtype", GetDtype{},
                            R"(
Data type, or :python:`None` if unspecified.

Example:

  >>> schema = ts.Schema(rank=3)
  >>> print(spec.dtype)
  None

  >>> spec = ts.Schema(dtype=ts.uint8, rank=3)
  >>> spec.dtype
  dtype("uint8")

Group:
  Accessors
)");

  struct GetDomain {
    std::optional<IndexDomain<>> operator()(ConstSelf self) const {
      ScopedPyCriticalSection cs(self.handle.ptr());
      auto domain = self.value.domain();
      if (!domain.valid()) return std::nullopt;
      return domain;
    }
  };
  cls.def_property_readonly("domain", GetDomain{},
                            R"(
Domain of the schema, or `None` if unspecified.

Example:

  >>> schema = ts.Schema()
  >>> print(schema.domain)
  None
  >>> schema.update(domain=ts.IndexDomain(labels=['x', 'y', 'z']))
  >>> schema.update(domain=ts.IndexDomain(shape=[100, 200, 300]))
  >>> schema.domain
  { "x": [0, 100), "y": [0, 200), "z": [0, 300) }

Group:
  Accessors
)");

  struct GetChunkLayout {
    ChunkLayout operator()(ConstSelf self) const {
      ScopedPyCriticalSection cs(self.handle.ptr());
      return self.value.chunk_layout();
    }
  };
  cls.def_property_readonly("chunk_layout", GetChunkLayout{},
                            R"(
Chunk layout constraints specified by the schema.

Example:

  >>> schema = ts.Schema(chunk_layout=ts.ChunkLayout(inner_order=[0, 1, 2]))
  >>> schema.update(chunk_layout=ts.ChunkLayout(grid_origin=[0, 0, 0]))
  >>> schema.chunk_layout
  ChunkLayout({'grid_origin': [0, 0, 0], 'inner_order': [0, 1, 2]})

Note:

  Each access to this property returns a new copy of the chunk layout.
  Modifying the returned chunk layout (e.g. by calling
  :py:obj:`tensorstore.ChunkLayout.update`) will not affect the schema object
  from which it was obtained.

Group:
  Accessors
)");

  struct GetCodec {
    std::optional<internal::IntrusivePtr<const internal::CodecDriverSpec>>
    operator()(ConstSelf self) const {
      ScopedPyCriticalSection cs(self.handle.ptr());
      auto codec = self.value.codec();
      if (!codec.valid()) return std::nullopt;
      return internal::IntrusivePtr<const internal::CodecDriverSpec>(
          std::move(codec));
    }
  };
  cls.def_property_readonly("codec", GetCodec{},
                            R"(
Codec constraints specified by the schema.

Example:

  >>> schema = ts.Schema()
  >>> print(schema.codec)
  None
  >>> schema.update(codec=ts.CodecSpec({
  ...     'driver': 'zarr',
  ...     'compressor': None
  ... }))
  >>> schema.update(codec=ts.CodecSpec({'driver': 'zarr', 'filters': None}))
  >>> schema.codec
  CodecSpec({'compressor': None, 'driver': 'zarr', 'filters': None})

Group:
  Accessors
)");

  struct GetFillValue {
    std::optional<SharedArray<const void>> operator()(ConstSelf self) const {
      ScopedPyCriticalSection cs(self.handle.ptr());
      auto fill_value = self.value.fill_value();
      if (!fill_value.valid()) return std::nullopt;
      return SharedArray<const void>(
          static_cast<SharedArrayView<const void>&&>(fill_value));
    }
  };
  cls.def_property_readonly("fill_value", GetFillValue{},
                            R"(
Fill value specified by the schema.

Example:

  >>> schema = ts.Schema()
  >>> print(schema.fill_value)
  None
  >>> schema.update(fill_value=42)
  >>> schema.fill_value
  array(42)

Group:
  Accessors
)");

  struct GetDimensionUnits {
    std::optional<HomogeneousTuple<std::optional<Unit>>> operator()(
        ConstSelf self) const {
      ScopedPyCriticalSection cs(self.handle.ptr());
      return internal_python::GetDimensionUnits(self.value.rank(),
                                                self.value.dimension_units());
    }
  };
  cls.def_property_readonly("dimension_units", GetDimensionUnits{},
                            R"(
Physical units of each dimension of the domain.

The *physical unit* for a dimension is the physical quantity corresponding to a
single index increment along each dimension.

A value of :python:`None` indicates that the unit is unknown/unconstrained.  A
dimension-less quantity is indicated by a unit of :python:`ts.Unit(1, "")`.

When creating a new TensorStore, the specified units may be stored as part of
the metadata.

When opening an existing TensorStore, the specified units serve as a constraint,
to ensure the units are as expected.  Additionally, for drivers like
:ref:`neuroglancer_precomputed<driver/neuroglancer_precomputed>` that support
multiple scales, the desired scale can be selected by specifying constraints on
the units.

Example:

  >>> schema = ts.Schema()
  >>> print(schema.dimension_units)
  None
  >>> schema.update(rank=3)
  >>> schema.dimension_units
  (None, None, None)
  >>> schema.update(dimension_units=['3nm', None, ''])
  >>> schema.dimension_units
  (Unit(3, "nm"), None, Unit(1, ""))
  >>> schema.update(dimension_units=[None, '4nm', None])
  >>> schema.dimension_units
  (Unit(3, "nm"), Unit(4, "nm"), Unit(1, ""))

Group:
  Accessors
)");

  struct ToJson {
    ::nlohmann::json operator()(ConstSelf self, bool include_defaults) const {
      ScopedPyCriticalSection cs(self.handle.ptr());
      return ValueOrThrow(self.value.ToJson(IncludeDefaults{include_defaults}));
    }
  };
  cls.def("to_json", ToJson{},
          R"(
Converts to the :json:schema:`JSON representation<Schema>`.

Example:

  >>> schema = ts.Schema(dtype=ts.uint8,
  ...                    chunk_layout=ts.ChunkLayout(grid_origin=[0, 0, 0],
  ...                                                inner_order=[0, 2, 1]))
  >>> schema.to_json()
  {'chunk_layout': {'grid_origin': [0, 0, 0], 'inner_order': [0, 2, 1]},
   'dtype': 'uint8',
   'rank': 3}

Group:
  Accessors
)",
          py::arg("include_defaults") = false);

  struct Copy {
    Schema operator()(ConstSelf self) const {
      ScopedPyCriticalSection cs(self.handle.ptr());
      return self.value;
    }
  };
  cls.def("copy", Copy{},
          R"(
Returns a copy of the schema.

Example:

  >>> a = ts.Schema(dtype=ts.uint8)
  >>> b = a.copy()
  >>> a.update(rank=2)
  >>> b.update(rank=3)
  >>> a
  Schema({'dtype': 'uint8', 'rank': 2})
  >>> b
  Schema({'dtype': 'uint8', 'rank': 3})

Group:
  Accessors
)");

  cls.def("__copy__", Copy{});

  struct DeepCopyFunctor {
    Schema operator()(ConstSelf self, py::dict memo) const {
      ScopedPyCriticalSection cs(self.handle.ptr());
      return self.value;
    }
  };
  cls.def("__deepcopy__", DeepCopyFunctor{}, py::arg("memo"));

  struct Repr {
    std::string operator()(ConstSelf self) const {
      ScopedPyCriticalSection cs(self.handle.ptr());
      return internal_python::PrettyPrintJsonAsPythonRepr(
          self.value.ToJson(IncludeDefaults{false}), "Schema(", ")");
    }
  };
  cls.def("__repr__", Repr{},
          R"(
Returns a string representation based on the  :json:schema:`JSON representation<Schema>`.

Example:

  >>> schema = ts.Schema(rank=5, dtype=ts.uint8)
  >>> schema
  Schema({'dtype': 'uint8', 'rank': 5})

)");

  struct Eq {
    bool operator()(ConstSelf self, ConstSelf other) const {
      ScopedPyCriticalSection2 cs(self.handle.ptr(), other.handle.ptr());
      return self.value == other.value;
    }
  };
  cls.def("__eq__", Eq{}, py::arg("other"),
          R"(
Compares with another :py:obj:`Schema` for equality based on the :json:schema:`JSON representation<Schema>`.

The comparison is based on the JSON representation.

Example:

  >>> schema = ts.Schema(dtype=ts.int32, rank=3)
  >>> assert schema == schema
  >>> a, b = spec.copy(), spec.copy()
  >>> a.update(fill_value=42)
  >>> assert a == a
  >>> assert a != b

)");

  DefineIndexTransformOperations</*WithLocking=*/true>(
      &cls,
      /*doc_strings=*/
      {
          /*numpy_indexing=*/{
              /*kDefault*/ {R"(
Transforms the schema using :ref:`NumPy-style indexing<python-numpy-style-indexing>` with default index array semantics.

Example:

    >>> schema = ts.Schema(
    ...     domain=ts.IndexDomain(labels=['x', 'y', 'z'],
    ...                           shape=[1000, 2000, 3000]),
    ...     chunk_layout=ts.ChunkLayout(grid_origin=[100, 200, 300],
    ...                                 inner_order=[0, 1, 2]),
    ... )
    >>> schema[[5, 10, 20], 6:10]
    Schema({
      'chunk_layout': {'grid_origin': [None, 200, 300], 'inner_order': [1, 2, 0]},
      'domain': {
        'exclusive_max': [3, 10, 3000],
        'inclusive_min': [0, 6, 0],
        'labels': ['', 'y', 'z'],
      },
      'rank': 3,
    })

Returns:
  New schema with the indexing operation applied.

Raises:
  ValueError: If :py:obj:`self.rank<.rank>` is :python:`None`.

See also:

   - :ref:`python-numpy-style-indexing`
   - :py:obj:`IndexTransform.__getitem__(indices)`
   - :py:obj:`Schema.oindex`
   - :py:obj:`Schema.vindex`

Group:
  Indexing

Overload:
  indices
)"},
              /*kOindex*/ {R"(
Transforms the schema using :ref:`NumPy-style indexing<python-numpy-style-indexing>` with :ref:`outer indexing semantics<python-oindex-indexing>`.

This is similar to :py:obj:`.__getitem__(indices)`, but differs in that any
integer or boolean array indexing terms are applied orthogonally.

Example:

    >>> schema = ts.Schema(
    ...     domain=ts.IndexDomain(labels=['x', 'y', 'z'],
    ...                           shape=[1000, 2000, 3000]),
    ...     chunk_layout=ts.ChunkLayout(grid_origin=[100, 200, 300],
    ...                                 inner_order=[0, 1, 2]),
    ... )
    >>> schema.oindex[[5, 10, 20], [7, 8, 10]]
    Schema({
      'chunk_layout': {'grid_origin': [None, None, 300], 'inner_order': [2, 0, 1]},
      'domain': {
        'exclusive_max': [3, 3, 3000],
        'inclusive_min': [0, 0, 0],
        'labels': ['', '', 'z'],
      },
      'rank': 3,
    })

Returns:
  New schema with the indexing operation applied.

Raises:
  ValueError: If :py:obj:`self.rank<.rank>` is :python:`None`.

See also:

   - :ref:`python-numpy-style-indexing`
   - :py:obj:`IndexTransform.oindex`
   - :py:obj:`Schema.__getitem__(indices)`
   - :py:obj:`Schema.vindex`

Group:
  Indexing
)"},
              /*kVindex*/ {R"(
Transforms the schema using :ref:`NumPy-style indexing<python-numpy-style-indexing>` with :ref:`vectorized indexing semantics<python-vindex-indexing>`.

This is similar to :py:obj:`.__getitem__(indices)`, but differs in that if
:python:`indices` specifies any array indexing terms, the broadcasted array
dimensions are unconditionally added as the first dimensions of the result
domain.

Example:

    >>> schema = ts.Schema(
    ...     domain=ts.IndexDomain(labels=['x', 'y', 'z'],
    ...                           shape=[1000, 2000, 3000]),
    ...     chunk_layout=ts.ChunkLayout(grid_origin=[100, 200, 300],
    ...                                 inner_order=[0, 1, 2]),
    ... )
    >>> schema.vindex[[5, 10, 20], [7, 8, 10]]
    Schema({
      'chunk_layout': {'grid_origin': [None, 300], 'inner_order': [1, 0]},
      'domain': {
        'exclusive_max': [3, 3000],
        'inclusive_min': [0, 0],
        'labels': ['', 'z'],
      },
      'rank': 2,
    })

Returns:
  New schema with the indexing operation applied.

Raises:
  ValueError: If :py:obj:`self.rank<.rank>` is :python:`None`.

See also:

   - :ref:`python-numpy-style-indexing`
   - :py:obj:`IndexTransform.vindex`
   - :py:obj:`Schema.__getitem__(indices)`
   - :py:obj:`Schema.oindex`

Group:
  Indexing
)"},
          },
          /*index_transform*/ {R"(
Transforms the schema using an explicit :ref:`index transform<index-transform>`.

Example:

    >>> schema = ts.Schema(
    ...     domain=ts.IndexDomain(labels=['x', 'y', 'z'],
    ...                           shape=[1000, 2000, 3000]),
    ...     chunk_layout=ts.ChunkLayout(grid_origin=[100, 200, 300],
    ...                                 inner_order=[0, 1, 2]),
    ... )
    >>> transform = ts.IndexTransform(
    ...     input_shape=[3],
    ...     output=[
    ...         ts.OutputIndexMap(index_array=[1, 2, 3]),
    ...         ts.OutputIndexMap(index_array=[5, 4, 3])
    ...     ])
    >>> schema[transform]
    Traceback (most recent call last):
        ...
    IndexError: Rank 3 -> 3 transform cannot be composed with rank 1 -> 2 transform...

Args:

  transform: Index transform, :python:`transform.output_rank` must equal
    :python:`self.rank`.

Returns:

  New schema of rank :python:`transform.input_rank`.

Raises:
  ValueError: If :py:obj:`self.rank<.rank>` is :python:`None`.

See also:

   - :ref:`python-numpy-style-indexing`
   - :py:obj:`IndexTransform.__getitem__(transform)`
   - :py:obj:`Schema.__getitem__(indices)`
   - :py:obj:`Schema.__getitem__(expr)`
   - :py:obj:`Schema.__getitem__(domain)`
   - :py:obj:`Schema.oindex`
   - :py:obj:`Schema.vindex`

Overload:
  transform

Group:
  Indexing
)"},
          /*index_domain*/ {R"(
Transforms the schema using an explicit :ref:`index domain<index-domain>`.

The domain of the resultant spec is computed as in
:py:obj:`IndexDomain.__getitem__(domain)`.

Example:

    >>> schema = ts.Schema(
    ...     domain=ts.IndexDomain(labels=['x', 'y', 'z'],
    ...                           shape=[1000, 2000, 3000]),
    ...     chunk_layout=ts.ChunkLayout(grid_origin=[100, 200, 300],
    ...                                 inner_order=[0, 1, 2]),
    ... )
    >>> domain = ts.IndexDomain(labels=['x', 'z'],
    ...                         inclusive_min=[5, 6],
    ...                         exclusive_max=[8, 9])
    >>> schema[domain]
    Schema({
      'chunk_layout': {'grid_origin': [100, 200, 300], 'inner_order': [0, 1, 2]},
      'domain': {
        'exclusive_max': [8, 2000, 9],
        'inclusive_min': [5, 0, 6],
        'labels': ['x', 'y', 'z'],
      },
      'rank': 3,
    })

Args:

  domain: Index domain, must have dimension labels that can be
    :ref:`aligned<index-domain-alignment>` to :python:`self.domain`.

Returns:

  New schema with domain equal to :python:`self.domain[domain]`.

Raises:
  ValueError: If :py:obj:`self.rank<.rank>` is :python:`None`.

Group:
  Indexing

Overload:
  domain

See also:

   - :ref:`index-domain`
   - :ref:`index-domain-alignment`
   - :py:obj:`IndexDomain.__getitem__(domain)`
)"},
          /*dim_expression*/ {R"(
Transforms the schema using a :ref:`dimension expression<python-dim-expressions>`.

Example:

    >>> schema = ts.Schema(
    ...     domain=ts.IndexDomain(labels=['x', 'y', 'z'],
    ...                           shape=[1000, 2000, 3000]),
    ...     chunk_layout=ts.ChunkLayout(grid_origin=[100, 200, 300],
    ...                                 inner_order=[0, 1, 2]),
    ... )
    >>> schema[ts.d['x', 'z'][5:10, 6:9]]
    Schema({
      'chunk_layout': {'grid_origin': [100, 200, 300], 'inner_order': [0, 1, 2]},
      'domain': {
        'exclusive_max': [10, 2000, 9],
        'inclusive_min': [5, 0, 6],
        'labels': ['x', 'y', 'z'],
      },
      'rank': 3,
    })

Returns:
  New schema with domain equal to :python:`self.domain[expr]`.

Raises:
  ValueError: If :py:obj:`self.rank<.rank>` is :python:`None`.

Group:
  Indexing

Overload:
  expr

See also:

   - :ref:`python-dim-expressions`
   - :py:obj:`IndexDomain.__getitem__(expr)`
)"},
      },
      /*get_transform=*/
      [](const Schema& self) {
        return ValueOrThrow(self.GetTransformForIndexingOperation());
      },
      /*apply_transform=*/
      [](Schema self, IndexTransform<> new_transform) {
        return ValueOrThrow(
            ApplyIndexTransform(std::move(new_transform), std::move(self)));
      });

  EnablePicklingFromSerialization</*WithLocking=*/true>(cls);
}

using ClsCodecSpec =
    py::class_<internal::CodecDriverSpec,
               internal::IntrusivePtr<internal::CodecDriverSpec>>;

auto MakeCodecSpecClass(py::module m) {
  return ClsCodecSpec(m, "CodecSpec", R"(
Specifies driver-specific encoding/decoding parameters.

Group:
  Spec
)");
}

void DefineCodecSpecAttributes(ClsCodecSpec& cls) {
  using Self = internal::IntrusivePtr<internal::CodecDriverSpec>;
  cls.def(py::init([](::nlohmann::json json) -> Self {
            return internal::const_pointer_cast<internal::CodecDriverSpec>(
                ValueOrThrow(CodecSpec::FromJson(std::move(json))));
          }),
          R"(
Constructs from the :json:schema:`JSON representation<Codec>`.
)",
          py::arg("json"));

  cls.def("__repr__", [](Self self) {
    return internal_python::PrettyPrintJsonAsPythonRepr(
        CodecSpec(std::move(self)).ToJson(IncludeDefaults{false}), "CodecSpec(",
        ")");
  });

  cls.def(
      "to_json",
      [](Self self, bool include_defaults) {
        return ValueOrThrow(CodecSpec(std::move(self))
                                .ToJson(IncludeDefaults{include_defaults}));
      },
      R"(
Converts to the :json:schema:`JSON representation<Codec>`.
)",
      py::arg("include_defaults") = false);

  EnablePicklingFromSerialization</*WithLocking=*/false, Self>(
      cls, internal::CodecSpecNonNullDirectSerializer{});
}

///

using ClsOpenMode = py::class_<PythonOpenMode>;

auto MakeOpenModeClass(py::module m) {
  return ClsOpenMode(m, "OpenMode", R"(
Specifies the mode to use when opening a `TensorStore`.

Group:
  Spec
)");
}

struct OpenModeValueOpen {
  static constexpr OpenMode mode = OpenMode::open;
  static constexpr const char* name = "open";
  static constexpr const char* doc = R"(
Allow opening an existing TensorStore.
)";
};

struct OpenModeValueCreate {
  static constexpr OpenMode mode = OpenMode::create;
  static constexpr const char* name = "create";
  static constexpr const char* doc = R"(
Allow creating a new TensorStore.
)";
};

struct OpenModeValueDeleteExisting {
  static constexpr OpenMode mode = OpenMode::delete_existing;
  static constexpr const char* name = "delete_existing";
  static constexpr const char* doc = R"(
Delete any existing data before creating a new array.
)";
};

struct OpenModeValueAssumeMetadata {
  static constexpr OpenMode mode = OpenMode::assume_metadata;
  static constexpr const char* name = "assume_metadata";
  static constexpr const char* doc = R"(
Don't access the stored metadata.
)";
};

struct OpenModeValueAssumeCachedMetadata {
  static constexpr OpenMode mode = OpenMode::assume_cached_metadata;
  static constexpr const char* name = "assume_cached_metadata";
  static constexpr const char* doc = R"(
Skip reading the metadata when opening.
)";
};

template <typename ModeDef>
void DefineOpenModeAccessor(ClsOpenMode& cls) {
  using ConstHandle = with_handle<const PythonOpenMode&>;
  using MutableHandle = with_handle<PythonOpenMode&>;

  std::string doc_str = ModeDef::doc;
  doc_str += R"(

Group:
  Accessors
)";
  cls.def_property(
      ModeDef::name,
      [](ConstHandle self) -> bool {
        ScopedPyCriticalSection cs(self.handle.ptr());
        return !!(self.value.value & ModeDef::mode);
      },
      [](MutableHandle self, bool value) {
        ScopedPyCriticalSection cs(self.handle.ptr());
        self.value.value = value ? (self.value.value | ModeDef::mode)
                                 : (self.value.value & ~ModeDef::mode);
      },
      doc_str.c_str());
}

constexpr auto WithOpenModes = [](auto callback, auto... other_params) {
  callback(other_params...,  //
           OpenModeValueOpen{}, OpenModeValueCreate{},
           OpenModeValueDeleteExisting{}, OpenModeValueAssumeMetadata{},
           OpenModeValueAssumeCachedMetadata{});
};

void DefineOpenModeAttributes(ClsOpenMode& cls) {
  using ConstHandle = with_handle<const PythonOpenMode&>;

  WithOpenModes([&](auto... mode_info) {
    std::string doc = R"(
Constructs an open mode.

Args:
)";
    internal_python::AppendKeywordArgumentDocs(doc, mode_info...);

    cls.def(
        py::init(
            [](
                // One `bool` argument per open mode.
                //
                // To avoid
                // https://developercommunity.visualstudio.com/t/Argument-pack-incorrectly-expanded-when/10375693
                // this parameter must not have the same name as the member.
                internal::FirstType<bool, decltype(mode_info)>... mode_arg) {
              return PythonOpenMode{(
                  // Binary OR together all open modes corresponding to
                  // `true` arguments.
                  (mode_arg ? decltype(mode_info)::mode : OpenMode{}) | ...)};
            }),
        doc.c_str(), py::kw_only(),
        // All open mode arguments default to `false`.
        (py::arg(mode_info.name) = false)...);

    // Define read-write property for each open mode.
    (DefineOpenModeAccessor<decltype(mode_info)>(cls), ...);

    cls.def("__repr__", [](ConstHandle self) {
      ScopedPyCriticalSection cs(self.handle.ptr());
      std::string repr = "OpenMode(";
      // Comma-separated list of open modes that are `true`.
      bool first = true;
      ((!!(self.value.value & decltype(mode_info)::mode)
            ? (tensorstore::StrAppend(&repr, first ? "" : ", ",
                                      decltype(mode_info)::name, "=True"),
               (first = false))
            : true),
       ...);
      repr += ")";
      return repr;
    });
  });

  cls.def("__eq__", [](ConstHandle self, ConstHandle other) {
    ScopedPyCriticalSection2 cs(self.handle.ptr(), other.handle.ptr());
    return self.value.value == other.value.value;
  });

  EnablePicklingFromSerialization</*WithLocking=*/true>(cls);
}

void RegisterSpecBindings(pybind11::module m, Executor defer) {
  defer([cls = MakeSpecClass(m)]() mutable { DefineSpecAttributes(cls); });
  defer([cls = MakeSchemaClass(m)]() mutable { DefineSchemaAttributes(cls); });
  defer([cls = MakeCodecSpecClass(m)]() mutable {
    DefineCodecSpecAttributes(cls);
  });
  defer([cls = MakeOpenModeClass(m)]() mutable {
    DefineOpenModeAttributes(cls);
  });
}

TENSORSTORE_GLOBAL_INITIALIZER {
  RegisterPythonComponent(RegisterSpecBindings, /*priority=*/-700);
}
}  // namespace
}  // namespace internal_python
}  // namespace tensorstore

namespace pybind11 {
namespace detail {

bool type_caster<tensorstore::internal_python::SpecLike>::load(handle src,
                                                               bool convert) {
  using tensorstore::internal_python::PythonSpecObject;
  // Handle the case that `src` is already a Python-wrapped
  // `tensorstore::Spec`.
  if (Py_TYPE(src.ptr()) == PythonSpecObject::python_type) {
    auto& obj = *reinterpret_cast<PythonSpecObject*>(src.ptr());
    value.spec = obj.value;
    value.reference_manager = obj.reference_manager();
    return true;
  }
  if (!convert) return false;
  // Attempt to convert argument to `::nlohmann::json`, then to
  // `tensorstore::Spec`.
  value.spec =
      tensorstore::internal_python::ValueOrThrow(tensorstore::Spec::FromJson(
          tensorstore::internal_python::PyObjectToJson(src)));
  return true;
}

bool type_caster<tensorstore::RecheckCacheOption>::load(handle src,
                                                        bool convert) {
  using tensorstore::RecheckCacheOption;
  if (src.ptr() == Py_False) {
    value = RecheckCacheOption{false};
    return true;
  }

  if (src.ptr() == Py_True) {
    value = RecheckCacheOption{true};
    return true;
  }

  if (PyUnicode_Check(src.ptr()) &&
      PyUnicode_CompareWithASCIIString(src.ptr(), "open") == 0) {
    value = RecheckCacheOption::AtOpen();
    return true;
  }

  double x = PyFloat_AsDouble(src.ptr());
  if (x == -1 && PyErr_Occurred()) {
    PyErr_Clear();
  } else {
    value = RecheckCacheOption{absl::UnixEpoch() + absl::Seconds(x)};
    return true;
  }

  return false;
}

}  // namespace detail
}  // namespace pybind11
