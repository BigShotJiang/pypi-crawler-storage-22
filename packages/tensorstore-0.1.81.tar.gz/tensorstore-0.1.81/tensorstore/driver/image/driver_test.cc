// Copyright 2021 The TensorStore Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <stdint.h>

#include <cassert>
#include <string>
#include <type_traits>

#include <gmock/gmock.h>
#include <gtest/gtest.h>
#include "absl/status/status.h"
#include "absl/strings/cord.h"
#include "absl/strings/string_view.h"
#include <nlohmann/json.hpp>
#include "tensorstore/array.h"
#include "tensorstore/box.h"
#include "tensorstore/context.h"
#include "tensorstore/driver/driver_testutil.h"
#include "tensorstore/driver/image/test_image.h"
#include "tensorstore/index.h"
#include "tensorstore/index_space/dim_expression.h"
#include "tensorstore/internal/testing/json_gtest.h"
#include "tensorstore/kvstore/kvstore.h"
#include "tensorstore/kvstore/operations.h"
#include "tensorstore/open.h"
#include "tensorstore/open_mode.h"
#include "tensorstore/strided_layout.h"
#include "tensorstore/tensorstore.h"
#include "tensorstore/transaction.h"
#include "tensorstore/util/result.h"
#include "tensorstore/util/status.h"
#include "tensorstore/util/status_testutil.h"
#include "tensorstore/util/str_cat.h"

namespace {

using ::tensorstore::Context;
using ::tensorstore::DimensionIndex;
using ::tensorstore::Index;
using ::tensorstore::MatchesJson;
using ::tensorstore::StatusIs;
using ::tensorstore::internal::TestTensorStoreUrlRoundtrip;
using ::testing::HasSubstr;

struct P {
  std::string driver;
  std::string path;
  absl::Cord data;

  /// Values at predefined points in the image.
  /// image drivers return c-order: y, x, c
  uint8_t a[3] = {100, 50, 0};   // (50,100)
  uint8_t b[3] = {200, 100, 0};  // (100,200)
};

// Implements ::testing::PrintToStringParamName().
[[maybe_unused]] std::string PrintToString(const P& p) { return p.driver; }

P ParamPng() {
  return {"png", "a.png", ::tensorstore::internal_image_driver::GetPng()};
}

P ParamJpeg() {
  return {
      "jpeg",
      "b.jpg",
      ::tensorstore::internal_image_driver::GetJpeg(),
      {98, 55, 2},   // (50,100)
      {200, 104, 1}  // (100,200)
  };
}

P ParamAvif() {
  return {"avif", "c.avif", ::tensorstore::internal_image_driver::GetAvif()};
}

P ParamTiff() {
  return {"tiff", "d.tiff", ::tensorstore::internal_image_driver::GetTiff()};
}

P ParamWebP() {
  return {"webp", "e.webp", ::tensorstore::internal_image_driver::GetWebP()};
}

P ParamBmp() {
  return {"bmp", "e.bmp", ::tensorstore::internal_image_driver::GetBmp()};
}

class ImageDriverReadTest : public ::testing::TestWithParam<P> {
 public:
  ::nlohmann::json GetSpec() {
    return ::nlohmann::json{
        {"driver", GetParam().driver},
        {"kvstore", {{"driver", "memory"}, {"path", GetParam().path}}},
    };
  }

  ::nlohmann::json GetFullSpec() {
    return ::nlohmann::json{
        {"driver", GetParam().driver},
        {"dtype", "uint8"},
        {"kvstore", {{"driver", "memory"}, {"path", GetParam().path}}},
        {"transform",
         {
             {"input_exclusive_max", {256, 256, 3}},
             {"input_inclusive_min", {0, 0, 0}},
         }},
    };
  }

  tensorstore::Result<tensorstore::Context> PrepareTest(
      const ::nlohmann::json& spec) {
    auto context = tensorstore::Context::Default();
    TENSORSTORE_ASSIGN_OR_RETURN(
        auto kvs,
        tensorstore::kvstore::Open(spec.at("kvstore"), context).result());
    TENSORSTORE_RETURN_IF_ERROR(
        tensorstore::kvstore::Write(kvs, {}, GetParam().data));
    return context;
  }
};

INSTANTIATE_TEST_SUITE_P(ReadTests, ImageDriverReadTest,
                         testing::Values(ParamPng(), ParamJpeg(), ParamAvif(),
                                         ParamTiff(), ParamWebP(), ParamBmp()),
                         testing::PrintToStringParamName());

TEST_P(ImageDriverReadTest, OpenAndResolveBounds) {
  auto spec = GetSpec();
  TENSORSTORE_ASSERT_OK_AND_ASSIGN(auto context, PrepareTest(spec));

  TENSORSTORE_ASSERT_OK_AND_ASSIGN(auto store,
                                   tensorstore::Open(spec, context).result());

  {
    TENSORSTORE_ASSERT_OK_AND_ASSIGN(auto spec, store.spec());
    EXPECT_THAT(spec.ToJson(), ::testing::Optional(MatchesJson(GetFullSpec())));
  }

  TENSORSTORE_ASSERT_OK_AND_ASSIGN(auto resolved,
                                   ResolveBounds(store).result());

  // Bounds are effectively resolved at open.
  {
    TENSORSTORE_ASSERT_OK_AND_ASSIGN(auto spec, resolved.spec());
    EXPECT_THAT(spec.ToJson(), ::testing::Optional(MatchesJson(GetFullSpec())));
  }
}

TEST_P(ImageDriverReadTest, UrlRoundtrip) {
  TestTensorStoreUrlRoundtrip(
      {{"driver", GetParam().driver},
       {"dtype", "uint8"},
       {"rank", 3},
       {"schema", {{"domain", {{"inclusive_min", {0, 0, 0}}}}}},
       {"kvstore", {{"driver", "memory"}, {"path", GetParam().path}}}},
      tensorstore::StrCat("memory://", GetParam().path, "|", GetParam().driver,
                          ":"));
}

TEST_P(ImageDriverReadTest, AutoDetect) {
  TENSORSTORE_ASSERT_OK_AND_ASSIGN(auto context, PrepareTest(GetSpec()));
  TENSORSTORE_ASSERT_OK_AND_ASSIGN(
      auto store,
      tensorstore::Open(tensorstore::StrCat("memory://", GetParam().path),
                        context)
          .result());
  TENSORSTORE_ASSERT_OK_AND_ASSIGN(auto spec_obj, store.spec());
  EXPECT_THAT(spec_obj.ToJson(),
              ::testing::Optional(MatchesJson(GetFullSpec())));
}

TEST_P(ImageDriverReadTest, OpenSchemaDomainTooSmall) {
  /// The schema domain is smaller than the image bounds; that's a failure.
  ::nlohmann::json spec{
      {"driver", GetParam().driver},
      {"kvstore", {{"driver", "memory"}, {"path", GetParam().path}}},
      {"schema",
       {
           {"domain",
            {
                {"exclusive_max", {200, 200, 2}},
                {"inclusive_min", {0, 0, 0}},
            }},
       }},
  };

  TENSORSTORE_ASSERT_OK_AND_ASSIGN(auto context, PrepareTest(spec));

  EXPECT_THAT(
      tensorstore::Open(spec, context).result(),
      StatusIs(absl::StatusCode::kInvalidArgument, HasSubstr("Schema domain")));
}

TEST_P(ImageDriverReadTest, OpenSchemaDomainTooLarge) {
  /// The schema domain exceeds image bounds; that's a failure.
  ::nlohmann::json spec{
      {"driver", GetParam().driver},
      {"kvstore", {{"driver", "memory"}, {"path", GetParam().path}}},
      {"schema",
       {
           {"domain",
            {
                {"exclusive_max", {300, 400, 3}},
                {"inclusive_min", {0, 0, 0}},
            }},
       }},
  };

  TENSORSTORE_ASSERT_OK_AND_ASSIGN(auto context, PrepareTest(spec));

  EXPECT_THAT(
      tensorstore::Open(spec, context).result(),
      StatusIs(absl::StatusCode::kInvalidArgument, HasSubstr("Schema domain")));
}

TEST_P(ImageDriverReadTest, OpenTransformTooLarge) {
  // Transform input domain exceeds image bounds; that's a failure.
  ::nlohmann::json spec{
      {"driver", GetParam().driver},
      {"kvstore", {{"driver", "memory"}, {"path", GetParam().path}}},
      {"transform",
       {
           {"input_labels", {"y", "x", "c"}},
           {"input_inclusive_min", {0, 0, 0}},
           {"input_exclusive_max", {512, 512, 3}},
           {"output",
            {{{"input_dimension", 0}},
             {{"input_dimension", 1}},
             {{"input_dimension", 2}}}},
       }},
  };

  TENSORSTORE_ASSERT_OK_AND_ASSIGN(auto context, PrepareTest(spec));

  EXPECT_THAT(tensorstore::Open(spec, context).result(),
              StatusIs(absl::StatusCode::kOutOfRange));
}

TEST_P(ImageDriverReadTest, OpenTransformSmall) {
  // Transform input domain is smaller than the image; that's OK.
  ::nlohmann::json spec{
      {"driver", GetParam().driver},
      {"kvstore", {{"driver", "memory"}, {"path", GetParam().path}}},
      {"transform",
       {
           {"input_labels", {"y", "x", "c"}},
           {"input_inclusive_min", {0, 0, 0}},
           {"input_exclusive_max", {200, 200, 2}},
           {"output",
            {{{"input_dimension", 0}},
             {{"input_dimension", 1}},
             {{"input_dimension", 2}}}},
       }},
  };

  TENSORSTORE_ASSERT_OK_AND_ASSIGN(auto context, PrepareTest(spec));

  TENSORSTORE_ASSERT_OK_AND_ASSIGN(auto store,
                                   tensorstore::Open(spec, context).result());

  EXPECT_EQ(store.domain().box(),
            tensorstore::BoxView({0, 0, 0}, {200, 200, 2}));
}

TEST_P(ImageDriverReadTest, Read) {
  auto spec = GetSpec();
  TENSORSTORE_ASSERT_OK_AND_ASSIGN(auto context, PrepareTest(spec));

  // Path is embedded in kvstore, so we don't write it.
  TENSORSTORE_ASSERT_OK_AND_ASSIGN(auto store,
                                   tensorstore::Open(spec, context).result());

  TENSORSTORE_ASSERT_OK_AND_ASSIGN(auto array,
                                   tensorstore::Read(store).result());

  EXPECT_THAT(array.shape(), ::testing::ElementsAre(256, 256, 3));
  EXPECT_THAT(array[50][100], tensorstore::MakeArray<uint8_t>(GetParam().a));
  EXPECT_THAT(array[100][200], tensorstore::MakeArray<uint8_t>(GetParam().b));
}

TEST_P(ImageDriverReadTest, ReadWithTransform) {
  auto spec = GetSpec();
  TENSORSTORE_ASSERT_OK_AND_ASSIGN(auto context, PrepareTest(spec));

  TENSORSTORE_ASSERT_OK_AND_ASSIGN(auto store,
                                   tensorstore::Open(spec, context).result());

  auto transformed =
      store | tensorstore::Dims(0, 1).SizedInterval({100, 200}, {1, 1});
  TENSORSTORE_ASSERT_OK_AND_ASSIGN(
      auto array,
      tensorstore::Read<tensorstore::zero_origin>(transformed).result());

  EXPECT_THAT(array.shape(), ::testing::ElementsAre(1, 1, 3));
  EXPECT_THAT(array[0][0], tensorstore::MakeArray<uint8_t>(GetParam().b));
}

TEST_P(ImageDriverReadTest, ReadTransactionError) {
  auto spec = GetSpec();
  TENSORSTORE_ASSERT_OK_AND_ASSIGN(auto context, PrepareTest(spec));

  // Open with transaction succeeds
  tensorstore::Transaction transaction(tensorstore::TransactionMode::isolated);
  TENSORSTORE_ASSERT_OK_AND_ASSIGN(
      auto store, tensorstore::Open(spec, context, transaction).result());

  // But read/write/resolve are unsupported.
  EXPECT_THAT(
      tensorstore::Read(store).result(),
      StatusIs(absl::StatusCode::kUnimplemented, HasSubstr("transaction")));
}

TEST_P(ImageDriverReadTest, MissingPath_Open) {
  auto context = tensorstore::Context::Default();
  auto spec = GetSpec();
  EXPECT_THAT(tensorstore::Open(spec).result(),
              StatusIs(absl::StatusCode::kNotFound));
}

TEST(ImageDriverErrors, NoKvStore) {
  EXPECT_THAT(
      tensorstore::Open({
                            {"driver", "png"},
                        })
          .result(),
      StatusIs(absl::StatusCode::kInvalidArgument, HasSubstr("\"kvstore\"")));
}

TEST(ImageDriverErrors, Mode) {
  for (auto mode : {tensorstore::ReadWriteMode::write,
                    tensorstore::ReadWriteMode::read_write}) {
    SCOPED_TRACE(tensorstore::StrCat("mode=", mode));
    EXPECT_THAT(tensorstore::Open(
                    {
                        {"driver", "png"},
                        {"dtype", "uint8"},
                        {"kvstore", {{"driver", "memory"}, {"path", "a.png"}}},
                    },
                    mode)
                    .result(),
                StatusIs(absl::StatusCode::kInvalidArgument,
                         HasSubstr(": only reading is supported")));
  }
}

TEST(ImageDriverErrors, RankMismatch) {
  EXPECT_THAT(tensorstore::Open(
                  {
                      {"driver", "png"},
                      {"kvstore", {{"driver", "memory"}, {"path", "a.png"}}},
                      {"schema",
                       {
                           {"domain", {{"rank", 2}}},
                       }},
                  })
                  .result(),
              StatusIs(absl::StatusCode::kInvalidArgument, HasSubstr("rank")));
}

TEST(ImageDriverErrors, DomainOrigin) {
  EXPECT_THAT(
      tensorstore::Open(
          {
              {"driver", "png"},
              {"kvstore", {{"driver", "memory"}, {"path", "a.png"}}},
              {"schema",
               {
                   {"domain", {{"inclusive_min", {0, 0, 1}}}},
               }},
          })
          .result(),
      StatusIs(absl::StatusCode::kInvalidArgument, HasSubstr("origin")));
}

TEST(ImageDriverErrors, DimensionUnits) {
  EXPECT_THAT(tensorstore::Open(
                  {
                      {"driver", "png"},
                      {"kvstore", {{"driver", "memory"}, {"path", "a.png"}}},
                      {"schema",
                       {
                           {"dimension_units", {"1ft", "2ft"}},
                       }},
                  })
                  .result(),
              // dimension_units sets schema.rank
              StatusIs(absl::StatusCode::kInvalidArgument, HasSubstr("rank")));
}

// TODO: schema.fill_value

}  // namespace
