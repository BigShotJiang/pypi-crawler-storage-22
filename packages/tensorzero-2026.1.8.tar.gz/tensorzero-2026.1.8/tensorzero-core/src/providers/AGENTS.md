# Model Providers

- We are gradually migrating types related to model providers to a separate crate `tensorzero-types-providers`. If you're creating a new type, (e.g. `MyProviderUsage`), prefer creating it under `tensorzero-types-providers` and importing it.
