This release fixes an issue with diff tests failing when using multi-word Tenzir commands.

## 🐞 Bug fixes

### Tuple unpacking in diff runner for multi-word commands

Fixed an error that occurred when running diff tests with multi-word Tenzir commands like `uvx tenzir`.

*By @mavam and @claude in #8.*
