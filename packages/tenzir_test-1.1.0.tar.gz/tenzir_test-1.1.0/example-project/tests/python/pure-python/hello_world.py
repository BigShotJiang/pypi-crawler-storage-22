#!/usr/bin/env python3

# Smallest possible Python test: no harness helpers or fixtures involved.
# Baseline lives next to this script (.txt).
numbers = [1, 2, 3]
print(f"sum of {numbers} is {sum(numbers)}")
