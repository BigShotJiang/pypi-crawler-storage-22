# TenZorneFlow

Библиотека для работы с тензорами и изображениями.

## Установка

```bash
pip install tenzorneflow