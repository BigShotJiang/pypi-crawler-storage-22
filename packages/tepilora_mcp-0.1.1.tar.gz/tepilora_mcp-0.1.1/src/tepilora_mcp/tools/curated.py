"""Curated high-value tools with typed parameters."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

from .errors import handle_tool_errors
from .generic import _call_operation
from ..server import mcp


# --- Raw functions (testable directly) ---

@handle_tool_errors
async def _search_securities(
    query: str,
    limit: int = 20,
    filters: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    params: Dict[str, Any] = {"query": query, "limit": limit}
    if filters:
        params["filters"] = filters
    return await _call_operation("securities.search", params=params)


@handle_tool_errors
async def _get_security_details(identifier: str) -> Dict[str, Any]:
    return await _call_operation("securities.description", params={"identifier": identifier})


@handle_tool_errors
async def _get_price_history(
    identifiers: Union[str, List[str]],
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    limit: int = 1000,
) -> Dict[str, Any]:
    params: Dict[str, Any] = {"identifiers": identifiers, "limit": limit}
    if start_date:
        params["start_date"] = start_date
    if end_date:
        params["end_date"] = end_date
    return await _call_operation("securities.history", params=params)


@handle_tool_errors
async def _create_portfolio(
    name: str,
    input_type: str = "fixed_weights",
    input_data: Optional[Dict[str, float]] = None,
) -> Dict[str, Any]:
    params: Dict[str, Any] = {"name": name, "input_type": input_type}
    if input_data:
        params["input_data"] = input_data
    return await _call_operation("portfolio.create", params=params)


@handle_tool_errors
async def _get_portfolio_returns(
    id: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    return_method: str = "twr",
) -> Dict[str, Any]:
    params: Dict[str, Any] = {"id": id, "return_method": return_method}
    if start_date:
        params["start_date"] = start_date
    if end_date:
        params["end_date"] = end_date
    return await _call_operation("portfolio.returns", params=params)


@handle_tool_errors
async def _run_analytics(
    function: str,
    identifiers: Optional[Union[str, List[str]]] = None,
    params: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    call_params: Dict[str, Any] = dict(params or {})
    if identifiers:
        call_params["identifiers"] = identifiers
    return await _call_operation(f"analytics.{function}", params=call_params)


@handle_tool_errors
async def _search_news(
    query: str,
    limit: int = 20,
    finance_only: bool = True,
) -> Dict[str, Any]:
    return await _call_operation("news.search", params={
        "query": query,
        "limit": limit,
        "finance_only": finance_only,
    })


@handle_tool_errors
async def _screen_bonds(
    criteria: Optional[Dict[str, Any]] = None,
    limit: int = 50,
) -> Dict[str, Any]:
    params: Dict[str, Any] = {"limit": limit}
    if criteria:
        params["criteria"] = criteria
    return await _call_operation("bonds.screen", params=params)


@handle_tool_errors
async def _get_yield_curve(
    currency: str = "EUR",
    date: Optional[str] = None,
) -> Dict[str, Any]:
    params: Dict[str, Any] = {"currency": currency}
    if date:
        params["date"] = date
    return await _call_operation("bonds.curve", params=params)


# --- MCP tool registration ---

@mcp.tool
async def search_securities(
    query: str,
    limit: int = 20,
    filters: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Search for securities (stocks, ETFs, bonds, funds) by name, ISIN, or ticker.

    Args:
        query: Search text (e.g. "MSCI World", "Apple", "IE00B4L5Y983")
        limit: Maximum results to return (default 20)
        filters: Optional filters (e.g. {"Currency": "EUR", "TepiloraType": "ETF"})
    """
    return await _search_securities(query, limit, filters)


@mcp.tool
async def get_security_details(identifier: str) -> Dict[str, Any]:
    """Get detailed information about a specific security.

    Args:
        identifier: Security identifier (e.g. "IE00B4L5Y983EURXMIL")
    """
    return await _get_security_details(identifier)


@mcp.tool
async def get_price_history(
    identifiers: Union[str, List[str]],
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    limit: int = 1000,
) -> Dict[str, Any]:
    """Get historical price data for one or more securities.

    Args:
        identifiers: One or more security identifiers
        start_date: Start date (YYYY-MM-DD)
        end_date: End date (YYYY-MM-DD)
        limit: Maximum data points (default 1000)
    """
    return await _get_price_history(identifiers, start_date, end_date, limit)


@mcp.tool
async def create_portfolio(
    name: str,
    input_type: str = "fixed_weights",
    input_data: Optional[Dict[str, float]] = None,
) -> Dict[str, Any]:
    """Create a new portfolio.

    Args:
        name: Portfolio name
        input_type: Type of input (e.g. "fixed_weights", "transactions")
        input_data: Portfolio composition (e.g. {"ISIN1": 0.6, "ISIN2": 0.4})
    """
    return await _create_portfolio(name, input_type, input_data)


@mcp.tool
async def get_portfolio_returns(
    id: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    return_method: str = "twr",
) -> Dict[str, Any]:
    """Get portfolio return data.

    Args:
        id: Portfolio ID
        start_date: Start date (YYYY-MM-DD)
        end_date: End date (YYYY-MM-DD)
        return_method: Return calculation method ("twr" or "mwr")
    """
    return await _get_portfolio_returns(id, start_date, end_date, return_method)


@mcp.tool
async def run_analytics(
    function: str,
    identifiers: Optional[Union[str, List[str]]] = None,
    params: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Run any analytics function (rolling volatility, Sharpe, drawdown, etc.).

    There are 68 analytics functions. Use `list_operations("analytics")` to see them all.

    Args:
        function: Analytics function name (e.g. "rolling_volatility", "rolling_sharpe")
        identifiers: Security identifier(s) to analyze
        params: Function-specific parameters (e.g. {"Period": 252, "rf": 0.02})
    """
    return await _run_analytics(function, identifiers, params)


@mcp.tool
async def search_news(
    query: str,
    limit: int = 20,
    finance_only: bool = True,
) -> Dict[str, Any]:
    """Search financial news articles.

    Args:
        query: Search text (e.g. "bitcoin", "interest rates", "AAPL earnings")
        limit: Maximum results (default 20)
        finance_only: Only return finance-related news (default True)
    """
    return await _search_news(query, limit, finance_only)


@mcp.tool
async def screen_bonds(
    criteria: Optional[Dict[str, Any]] = None,
    limit: int = 50,
) -> Dict[str, Any]:
    """Screen bonds by criteria (yield, duration, rating, etc.).

    Args:
        criteria: Screening criteria (e.g. {"min_yield": 4.0, "max_duration": 5.0})
        limit: Maximum results (default 50)
    """
    return await _screen_bonds(criteria, limit)


@mcp.tool
async def get_yield_curve(
    currency: str = "EUR",
    date: Optional[str] = None,
) -> Dict[str, Any]:
    """Get the yield curve for a currency.

    Args:
        currency: Currency code (e.g. "EUR", "USD", "GBP")
        date: Date for historical curve (YYYY-MM-DD), defaults to latest
    """
    return await _get_yield_curve(currency, date)
