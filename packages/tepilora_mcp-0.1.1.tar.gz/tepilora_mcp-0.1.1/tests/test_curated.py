"""Tests for curated high-value tools."""

from unittest.mock import AsyncMock

from tepilora_mcp.tools.curated import (
    _search_securities,
    _get_security_details,
    _get_price_history,
    _create_portfolio,
    _get_portfolio_returns,
    _run_analytics,
    _search_news,
    _screen_bonds,
    _get_yield_curve,
)


class TestSearchSecurities:
    async def test_basic_search(self, mock_transport):
        result = await _search_securities("MSCI World")
        assert result is not None
        assert mock_transport.calls[-1]["payload"]["action"] == "securities.search"
        assert mock_transport.calls[-1]["payload"]["params"]["query"] == "MSCI World"
        assert mock_transport.calls[-1]["payload"]["params"]["limit"] == 20

    async def test_with_filters(self, mock_transport):
        await _search_securities("ETF", filters={"Currency": "EUR"})
        params = mock_transport.calls[-1]["payload"]["params"]
        assert params["filters"] == {"Currency": "EUR"}

    async def test_propagates_client_errors(self, mock_client):
        mock_client.call = AsyncMock(side_effect=RuntimeError("search failed"))
        result = await _search_securities("MSCI World")
        assert result["error"] == "Unexpected error while calling Tepilora API."
        assert "RuntimeError: search failed" in result["details"]


class TestGetSecurityDetails:
    async def test_basic(self, mock_transport):
        await _get_security_details("IE00B4L5Y983EURXMIL")
        assert mock_transport.calls[-1]["payload"]["action"] == "securities.description"


class TestGetPriceHistory:
    async def test_basic(self, mock_transport):
        await _get_price_history("IE00B4L5Y983EURXMIL", start_date="2024-01-01")
        payload = mock_transport.calls[-1]["payload"]
        assert payload["action"] == "securities.history"
        assert payload["params"]["start_date"] == "2024-01-01"

    async def test_omits_optional_dates_when_not_provided(self, mock_transport):
        await _get_price_history("ID")
        params = mock_transport.calls[-1]["payload"]["params"]
        assert "start_date" not in params
        assert "end_date" not in params

    async def test_includes_end_date_when_provided(self, mock_transport):
        await _get_price_history("ID", end_date="2024-12-31")
        params = mock_transport.calls[-1]["payload"]["params"]
        assert params["end_date"] == "2024-12-31"


class TestCreatePortfolio:
    async def test_basic(self, mock_transport):
        await _create_portfolio("Test", input_data={"ISIN1": 0.6, "ISIN2": 0.4})
        payload = mock_transport.calls[-1]["payload"]
        assert payload["action"] == "portfolio.create"
        assert payload["params"]["name"] == "Test"

    async def test_omits_input_data_when_not_provided(self, mock_transport):
        await _create_portfolio("name")
        params = mock_transport.calls[-1]["payload"]["params"]
        assert "input_data" not in params

    async def test_includes_input_data_when_provided(self, mock_transport):
        await _create_portfolio("name", input_data={"ISIN1": 1.0})
        params = mock_transport.calls[-1]["payload"]["params"]
        assert params["input_data"] == {"ISIN1": 1.0}


class TestGetPortfolioReturns:
    async def test_basic(self, mock_transport):
        await _get_portfolio_returns("abc-123")
        payload = mock_transport.calls[-1]["payload"]
        assert payload["action"] == "portfolio.returns"
        assert payload["params"]["id"] == "abc-123"

    async def test_omits_optional_dates_when_not_provided(self, mock_transport):
        await _get_portfolio_returns("id")
        params = mock_transport.calls[-1]["payload"]["params"]
        assert "start_date" not in params
        assert "end_date" not in params

    async def test_includes_optional_dates_when_provided(self, mock_transport):
        await _get_portfolio_returns("id", start_date="2024-01-01", end_date="2024-12-31")
        params = mock_transport.calls[-1]["payload"]["params"]
        assert params["start_date"] == "2024-01-01"
        assert params["end_date"] == "2024-12-31"


class TestRunAnalytics:
    async def test_basic(self, mock_transport):
        await _run_analytics("rolling_volatility", identifiers="IE00B4L5Y983EURXMIL", params={"Period": 252})
        payload = mock_transport.calls[-1]["payload"]
        assert payload["action"] == "analytics.rolling_volatility"
        assert payload["params"]["identifiers"] == "IE00B4L5Y983EURXMIL"
        assert payload["params"]["Period"] == 252

    async def test_identifiers_injected_when_provided(self, mock_transport):
        await _run_analytics("rolling_sharpe", identifiers="ID")
        params = mock_transport.calls[-1]["payload"]["params"]
        assert params["identifiers"] == "ID"

    async def test_does_not_mutate_original_params(self, mock_transport):
        original_params = {"Period": 252}
        await _run_analytics("rolling_volatility", identifiers="ID", params=original_params)
        assert original_params == {"Period": 252}

        call_params = mock_transport.calls[-1]["payload"]["params"]
        assert call_params["Period"] == 252
        assert call_params["identifiers"] == "ID"

    async def test_without_identifiers_uses_params_only(self, mock_transport):
        await _run_analytics("rolling_volatility", params={"Period": 63})
        params = mock_transport.calls[-1]["payload"]["params"]
        assert params["Period"] == 63
        assert "identifiers" not in params


class TestSearchNews:
    async def test_basic(self, mock_transport):
        await _search_news("bitcoin")
        payload = mock_transport.calls[-1]["payload"]
        assert payload["action"] == "news.search"
        assert payload["params"]["query"] == "bitcoin"


class TestScreenBonds:
    async def test_basic(self, mock_transport):
        await _screen_bonds(criteria={"min_yield": 4.0})
        payload = mock_transport.calls[-1]["payload"]
        assert payload["action"] == "bonds.screen"

    async def test_omits_criteria_when_not_provided(self, mock_transport):
        await _screen_bonds()
        params = mock_transport.calls[-1]["payload"]["params"]
        assert "criteria" not in params

    async def test_includes_criteria_when_provided(self, mock_transport):
        await _screen_bonds(criteria={"min_yield": 4.0})
        params = mock_transport.calls[-1]["payload"]["params"]
        assert params["criteria"] == {"min_yield": 4.0}


class TestGetYieldCurve:
    async def test_basic(self, mock_transport):
        await _get_yield_curve("USD")
        payload = mock_transport.calls[-1]["payload"]
        assert payload["action"] == "bonds.curve"
        assert payload["params"]["currency"] == "USD"

    async def test_omits_date_when_not_provided(self, mock_transport):
        await _get_yield_curve("EUR")
        params = mock_transport.calls[-1]["payload"]["params"]
        assert "date" not in params

    async def test_includes_date_when_provided(self, mock_transport):
        await _get_yield_curve("EUR", date="2024-01-15")
        params = mock_transport.calls[-1]["payload"]["params"]
        assert params["date"] == "2024-01-15"
