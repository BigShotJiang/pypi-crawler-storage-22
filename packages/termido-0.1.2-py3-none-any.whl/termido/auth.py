import requests

LOGIN_API = "https://termid.free.nf/api/login.php"

class Session:
    def __init__(self, username: str, api_key: str):
        self.username = username
        self.api_key = api_key

def login(api_key: str) -> Session:
    if not api_key or len(api_key) < 10:
        raise ValueError("Invalid API key")

    r = requests.post(
        LOGIN_API,
        json={"api_key": api_key},
        timeout=10
    )

    if r.status_code != 200:
        raise RuntimeError("Login failed. Check API key.")

    data = r.json()
    return Session(username=data["username"], api_key=api_key)