from .auth import login
from .project import Project

_session = None

def log(api_key: str):
    global _session
    _session = login(api_key)
    return True

def new(name: str):
    if _session is None:
        raise RuntimeError("Please login first using termido.log(API_KEY)")
    return Project(_session, name)

def help():
    print("""
TERMIDO – Beginner Usage

termido.log("API_KEY")

p = termido.new("project_name")
p.add("index.html", "<h1>Hello</h1>")
p.add("app.js", "alert('Hi')")
p.go()
p.open()
""")