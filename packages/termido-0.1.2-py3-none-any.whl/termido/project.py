import requests
import webbrowser
from .utils import check_file

PUBLISH_API = "https://termid.free.nf/api/publish.php"

class Project:
    def __init__(self, session, name: str):
        if not name:
            raise ValueError("Project name required")

        self.session = session
        self.name = name
        self.files = {}
        self.url = None

    def add(self, file: str, content: str):
        check_file(file, content)
        self.files[file] = content

    def clear(self):
        self.files = {}

    def go(self):
        if "index.html" not in self.files:
            raise RuntimeError("index.html is required")

        payload = {
            "username": self.session.username,
            "api_key": self.session.api_key,
            "project": self.name,
            "files": self.files
        }

        r = requests.post(
            PUBLISH_API,
            json=payload,
            timeout=20
        )

        if r.status_code != 200:
            raise RuntimeError("Publish failed")

        self.url = r.json()["url"]
        return self.url

    def open(self):
        if not self.url:
            raise RuntimeError("Run go() before open()")
        webbrowser.open(self.url))