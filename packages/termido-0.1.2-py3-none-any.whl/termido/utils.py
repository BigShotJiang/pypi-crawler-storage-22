ALLOWED_EXT = (".html", ".css", ".js", ".json", ".png", ".jpg", ".jpeg")
MAX_SIZE =  500_000  # 200 KB

def check_file(filename: str, content: str):
    if not filename.endswith(ALLOWED_EXT):
        raise ValueError("This file type is not allowed")

    if not isinstance(content, str):
        raise ValueError("File content must be text")

    if len(content) > MAX_SIZE:
        raise ValueError("File is too large (max 200KB)")