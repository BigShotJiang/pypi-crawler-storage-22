# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import TypedDict

__all__ = ["AgentAPIKeyListParams"]


class AgentAPIKeyListParams(TypedDict, total=False):
    agent_id: Optional[str]

    agent_name: Optional[str]

    limit: int

    page_number: int
