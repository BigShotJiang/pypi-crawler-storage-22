# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Required, TypedDict

__all__ = ["StateCreateParams"]


class StateCreateParams(TypedDict, total=False):
    agent_id: Required[str]

    state: Required[Dict[str, object]]

    task_id: Required[str]
