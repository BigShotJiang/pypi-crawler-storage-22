# Changelog

## [0.23.0](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.22.0...python-sdk-v0.23.0) (2026-02-04)


### Features

* **cli:** Improve tu deploy UX with SSE streaming, trace_id, and better feedback ([#59](https://github.com/terminal-use/monorepo/issues/59)) ([048da80](https://github.com/terminal-use/monorepo/commit/048da8002ed8de3ad44aa4486985d83ae904c61b))
* **infra:** Security-harden OTel Collector + document observability architecture ([#76](https://github.com/terminal-use/monorepo/issues/76)) ([e5c28c2](https://github.com/terminal-use/monorepo/commit/e5c28c26395939ae7bd2666f358b7275f9791cab))
* **nucleus:** increase deployment timeout to 8 minutes ([c72e3a7](https://github.com/terminal-use/monorepo/commit/c72e3a7b2b748ea8534bd4c89b76451412ffddb2))
* **nucleus:** unify message storage in raw_messages collection ([#74](https://github.com/terminal-use/monorepo/issues/74)) ([f894493](https://github.com/terminal-use/monorepo/commit/f894493f7d59e1790579e974cdf85480af0cf394))
* **templates:** add observability extras and improve init templates ([01969c0](https://github.com/terminal-use/monorepo/commit/01969c0c3ad34b58bc6f2ee7ebe4f72b5cd1db9c))


### Bug Fixes

* **cli:** build only for linux/amd64 platform ([289308b](https://github.com/terminal-use/monorepo/commit/289308b88e6a9ecd10089d64a0d3cc5a9829c231))
* **cli:** improve error messages with detailed context ([#71](https://github.com/terminal-use/monorepo/issues/71)) ([d569707](https://github.com/terminal-use/monorepo/commit/d56970786e0f2d102d2a85497267c9d432ad67e2))
* **dev:** pin minikube static IP to 192.168.49.2 ([#79](https://github.com/terminal-use/monorepo/issues/79)) ([d9b8661](https://github.com/terminal-use/monorepo/commit/d9b8661495e1c8a10f0b35a63919714b1abf5e45))

## [0.22.0](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.21.0...python-sdk-v0.22.0) (2026-02-03)


### ⚠ BREAKING CHANGES

* Custom exports are now imported from terminaluse.lib:

### Features

* **api:** add x-trace-id header to all HTTP responses ([#61](https://github.com/terminal-use/monorepo/issues/61)) ([f2b4d91](https://github.com/terminal-use/monorepo/commit/f2b4d91585b64a669651fa997765e6769f1863fd))
* **cli:** auto-detect agent for tu logs command ([#56](https://github.com/terminal-use/monorepo/issues/56)) ([3b8578a](https://github.com/terminal-use/monorepo/commit/3b8578ac7da233b90ae0ea88e8f7c2b20b10affb))
* implement Messaging System v2 with adapter pattern ([#3](https://github.com/terminal-use/monorepo/issues/3)) ([a0cab54](https://github.com/terminal-use/monorepo/commit/a0cab5434f283dbf915a77631dc532d1af70b09e))


### Bug Fixes

* **cli:** standardize error handling to use CLIError framework ([#58](https://github.com/terminal-use/monorepo/issues/58)) ([e7faee7](https://github.com/terminal-use/monorepo/commit/e7faee758d1d7b874a27e0f39a5df8325e524ac8))

## [0.21.0](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.20.1...python-sdk-v0.21.0) (2026-02-02)


### Features

* **cli:** add centralized error handling for humans and agents ([#32](https://github.com/terminal-use/monorepo/issues/32)) ([d5dbf89](https://github.com/terminal-use/monorepo/commit/d5dbf89597cc2f3ade0f749fb612848fe4d9db2c))
* **python-sdk:** migrate from Poetry to PEP 621 with hatchling ([#54](https://github.com/terminal-use/monorepo/issues/54)) ([83b72aa](https://github.com/terminal-use/monorepo/commit/83b72aa9b2aad0633046d1c92fd717e7adf684bd))


### Bug Fixes

* AlertManager config + ClickHouse alert labels + observability updates ([#51](https://github.com/terminal-use/monorepo/issues/51)) ([16db76d](https://github.com/terminal-use/monorepo/commit/16db76db41d17c3383f0de116a6304b94ec77728))
* **cli:** add loading spinner for credential auto-refresh ([#50](https://github.com/terminal-use/monorepo/issues/50)) ([dcaffee](https://github.com/terminal-use/monorepo/commit/dcaffeeb2b44718561fc697462df8a0b16f9cad2))
* **python-sdk:** fix lint issues and remove duplicate CLI code ([#55](https://github.com/terminal-use/monorepo/issues/55)) ([7c539c1](https://github.com/terminal-use/monorepo/commit/7c539c1a2a4023abac36ac11cb75e84d45ec37fb))
* **python-sdk:** remove poetry-dynamic-versioning for Docker compatibility ([#52](https://github.com/terminal-use/monorepo/issues/52)) ([760e87d](https://github.com/terminal-use/monorepo/commit/760e87d899a6bf850f1ea23c76cf09666758e7d1))
* **routing:** add diagnostic logging for task branch routing ([#45](https://github.com/terminal-use/monorepo/issues/45)) ([9e7b4dd](https://github.com/terminal-use/monorepo/commit/9e7b4dd37cb8cda6db20ff01ff1f2e87bc4bad38))

## [0.20.1](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.20.0...python-sdk-v0.20.1) (2026-02-01)


### Bug Fixes

* **python-sdk:** use poetry-dynamic-versioning for git tag versions ([#40](https://github.com/terminal-use/monorepo/issues/40)) ([ff95b70](https://github.com/terminal-use/monorepo/commit/ff95b7047608ef321888b9b99057a906c5c7a172))

## [0.20.0](https://github.com/terminal-use/monorepo/compare/python-sdk-v0.19.0...python-sdk-v0.20.0) (2026-02-01)


### Features

* **api:** add TaskStream event types to tasks endpoint ([10ef53d](https://github.com/terminal-use/monorepo/commit/10ef53d1cbd0b05e508252b39ff12c4b507ad3e6))
* **cli:** add real-time log streaming with -f/--follow flag ([#30](https://github.com/terminal-use/monorepo/issues/30)) ([f8942b0](https://github.com/terminal-use/monorepo/commit/f8942b0a3ca0a5be42855ca05258f4841980d4f3))
* **cli:** Add tu logs command and fix SDK HTTPS validation ([#13](https://github.com/terminal-use/monorepo/issues/13)) ([589a9a4](https://github.com/terminal-use/monorepo/commit/589a9a479ce7b98dc892fc2c9097e99611181a75))
* **cli:** comprehensive UX improvements for tu CLI ([#20](https://github.com/terminal-use/monorepo/issues/20)) ([f7e4a9a](https://github.com/terminal-use/monorepo/commit/f7e4a9adcab457a104f74d7e2a52e2d724ccdab3))
* **python-sdk:** pass task_id to tracer for span creation ([#8](https://github.com/terminal-use/monorepo/issues/8)) ([20eb956](https://github.com/terminal-use/monorepo/commit/20eb956648fa0e718cf88745c61ff28cec1f5e98))
* switch Fern to local generation and add TaskStream event types ([02e717d](https://github.com/terminal-use/monorepo/commit/02e717d96a6875981e02c5e9681c181c981f9a69))


### Bug Fixes

* **python-sdk:** correct type annotation in print_task_message_update ([#11](https://github.com/terminal-use/monorepo/issues/11)) ([14b5073](https://github.com/terminal-use/monorepo/commit/14b5073b09e26da48e01e2fd34fb398806c182d9))
* **python-sdk:** Fix CI and add type checking with ty ([28aee9f](https://github.com/terminal-use/monorepo/commit/28aee9fc99dca061c44403d5e8bd6d84b27179a2))
* **python-sdk:** Fix CI and add type checking with ty ([5bd7263](https://github.com/terminal-use/monorepo/commit/5bd7263b31d284d9c6b15db14ed9bf640fd87995))
* **python-sdk:** resolve mypy type errors and runtime bugs ([83513f4](https://github.com/terminal-use/monorepo/commit/83513f4b66d80e18375ee72e42894c6f6935a4d8))
* **python-sdk:** resolve mypy type errors and runtime bugs ([5fbca31](https://github.com/terminal-use/monorepo/commit/5fbca313ca50feafc0c4185196b3310506c48334))
* use TaskStreamEvent types for SSE stream handling ([8f7b885](https://github.com/terminal-use/monorepo/commit/8f7b8855bfa7c4cad4f483610448a0aa5312b75f))
* use TaskStreamEvent types for SSE stream handling ([f35eb23](https://github.com/terminal-use/monorepo/commit/f35eb23ec8ff4f5b81601f73118eefb04c6f95ad))
