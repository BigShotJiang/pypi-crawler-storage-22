"""SDK version detection utilities."""

from __future__ import annotations


def get_claude_sdk_version() -> str:
    """Get the Claude SDK version, with fallback."""
    try:
        import claude_agent_sdk

        return claude_agent_sdk.__version__
    except (ImportError, AttributeError):
        return "0.0.0-unknown"


# SDK type constants
SDK_TYPE_CLAUDE = "claude"
SDK_TYPE_TERMINAL_USE = "terminal_use"
DEFAULT_TERMINAL_USE_VERSION = "1.0.0"
