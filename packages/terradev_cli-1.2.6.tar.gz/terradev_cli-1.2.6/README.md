# Terradev

**Parallel provisioning and orchestration for cross-cloud cost optimization.**

Developers overpay for compute by only accessing single-cloud workflows or using slow sequential provisioning with inefficient egress and rate-limiting.

Terradev is a cross-cloud arbitrage CLI that saves developers **60%** on end-to-end compute provisioning costs. It works faster than any sequential tool to compress + stage datasets, parallel-provision optimal instances + nodes, and deploy **5x faster** than baseline provisions, at an average of **3 minutes**, with egress optimization.

Terradev is built modular, managing APIs through the end-client's discrete portfolio of cloud credentials (BYOAPI).

## Installation

```bash
pip install terradev-cli
```

With cloud provider extras:

```bash
pip install terradev-cli[all]     # AWS + GCP + Azure SDKs
pip install terradev-cli[aws]     # Just AWS (boto3)
pip install terradev-cli[gcp]     # Just GCP
pip install terradev-cli[azure]   # Just Azure
```

## Quick Start

```bash
# 1. Configure your cloud credentials (BYOAPI — you own your keys)
terradev configure --provider runpod
terradev configure --provider aws
terradev configure --provider vastai

# 2. Get real-time quotes across all configured providers
terradev quote -g A100

# 3. Provision the cheapest instance (real API call)
terradev provision -g A100

# 4. Provision 4x H100s in parallel across multiple clouds
terradev provision -g H100 -n 4 --parallel 6

# 5. Dry-run to see the allocation plan without launching
terradev provision -g A100 -n 2 --dry-run

# 6. Manage running instances
terradev status --live
terradev manage -i <instance-id> -a stop
terradev manage -i <instance-id> -a start
terradev manage -i <instance-id> -a terminate

# 7. Execute commands on provisioned instances
terradev execute -i <instance-id> -c "python train.py"

# 8. Stage datasets near compute (compress + chunk + upload)
terradev stage -d ./my-dataset --target-regions us-east-1,eu-west-1

# 9. View cost analytics from the tracking database
terradev analytics --days 30

# 10. Find cheaper alternatives for running instances
terradev optimize

# 11. One-command Docker workload (provision + deploy + run)
terradev run --gpu A100 --image pytorch/pytorch:latest -c "python train.py"

# 12. Keep an inference server alive
terradev run --gpu H100 --image vllm/vllm-openai:latest --keep-alive --port 8000
```

## BYOAuth — Bring Your Own Authentication

Terradev never touches, stores, or proxies your cloud credentials through a third party. Your API keys stay on your machine in `~/.terradev/credentials.json` — encrypted at rest, never transmitted.

**How it works:**
1. You run `terradev configure --provider <name>` and enter your API key
2. Credentials are stored locally in your home directory — never sent to Terradev servers
3. Every API call goes directly from your machine to the cloud provider
4. No middleman account, no shared credentials, no markup on provider pricing

**Why this matters:**
- **Zero trust exposure** — No third party holds your AWS/GCP/Azure keys
- **No vendor lock-in** — If you stop using Terradev, your cloud accounts are untouched
- **Enterprise-ready** — Compliant with SOC2, HIPAA, and internal security policies that prohibit sharing credentials with SaaS vendors
- **Full audit trail** — Every provision is logged locally with provider, cost, and timestamp

## CLI Commands

| Command | Description |
|---------|-------------|
| `terradev configure` | Set up API credentials for any provider |
| `terradev quote` | Get real-time GPU pricing across all clouds |
| `terradev provision` | Provision instances with parallel multi-cloud arbitrage |
| `terradev manage` | Stop, start, terminate, or check instance status |
| `terradev status` | View all instances and cost summary |
| `terradev execute` | Run commands on provisioned instances |
| `terradev stage` | Compress, chunk, and stage datasets near compute |
| `terradev analytics` | Cost analytics with daily spend trends |
| `terradev optimize` | Find cheaper alternatives for running instances |
| `terradev run` | Provision + deploy Docker container + execute in one command |

## Supported Cloud Providers

| Provider | GPU Types | Spot Savings | Regions |
|----------|-----------|-------------|---------|
| **AWS** | A100, H100, A10G, RTX 4090 | 70-90% | Global |
| **Google Cloud** | A100, H100, L4, T4 | 60-80% | Global |
| **Azure** | A100, H100, ND A100 v4 | 65-85% | Global |
| **RunPod** | A100, H100, RTX 4090 | 50-70% | Global |
| **Vast.ai** | A100, H100, RTX 4090 | 50-75% | Global |
| **Lambda Labs** | A100, H100, RTX 3090 | 40-60% | US/EU |
| **CoreWeave** | A100, H100, RTX 4090 | 45-65% | US/EU |
| **TensorDock** | A100, RTX 4090, RTX 3090 | 50-70% | Global |
| **Oracle Cloud** | A100, GPU3, GPU2 | 40-60% | Global |
| **Baseten** | A100, H100 | Inference-optimized | US/EU |

## Infrastructure Hooks

Terradev integrates with end-user managed infrastructure when available:

- **Kubernetes** — Deploy to existing K8s clusters
- **Karpenter** — Multi-cloud node provisioning via Karpenter CRDs
- **Grafana** — Dashboard creation for training job monitoring
- **Open Policy Agent** — Policy-as-code compliance enforcement

## Cost Savings Examples

| GPU Type | On-Demand (AWS) | Best Spot Price | **Terradev Best** | **Savings** |
|----------|----------------|-----------------|---------------------|-------------|
| A100 | $4.06/hr | $1.22/hr | **$0.84/hr** | **79%** |
| H100 | $7.20/hr | $2.16/hr | **$1.50/hr** | **79%** |
| RTX 4090 | $1.21/hr | $0.36/hr | **$0.25/hr** | **79%** |

*Prices queried in real-time from all 9 providers. Actual savings vary by availability.*

## Project Structure

```
terradev_cli/
├── cli.py                   # Main CLI (quote, provision, manage, status, etc.)
├── core/
│   ├── cost_tracker.py      # SQLite cost tracking database
│   ├── dataset_stager.py    # Compression, chunking, parallel staging
│   ├── egress_optimizer.py  # Cross-cloud data transfer cost optimization
│   ├── parallel_provisioner.py  # Concurrent multi-cloud deployment engine
│   ├── tier_manager.py      # Research / Research+ / Enterprise tier logic
│   └── rate_limiter.py      # API rate limiting
├── providers/
│   ├── base_provider.py     # Abstract provider interface
│   ├── aws_provider.py      # AWS EC2 (boto3)
│   ├── gcp_provider.py      # Google Cloud Compute
│   ├── azure_provider.py    # Azure Compute
│   ├── runpod_provider.py   # RunPod GraphQL API
│   ├── vastai_provider.py   # Vast.ai REST API
│   ├── lambda_labs_provider.py  # Lambda Cloud API
│   ├── coreweave_provider.py    # CoreWeave API
│   ├── tensordock_provider.py   # TensorDock API
│   └── provider_factory.py  # Dynamic provider instantiation
└── utils/
    └── formatters.py        # Output formatting
```

## Pricing Tiers

| | Research (Free) | Research+ ($49.99/mo) | Enterprise ($299.99/mo) |
|---|---|---|---|
| Provisions/month | 10 | 100 | Unlimited |
| Max concurrent instances | 1 | 4 | 32 |
| Providers | All 10 | All 10 | All 10 + priority |
| Cost tracking | Yes | Yes | Yes |
| Dataset staging | Yes | Yes | Yes |
| Egress optimization | Basic | Full | Full + custom routes |

## Integrations

### Jupyter / Colab / VS Code Notebooks

```bash
pip install terradev-jupyter
```

```python
%load_ext terradev_jupyter

%terradev quote -g A100
%terradev provision -g H100 --dry-run
%terradev run --gpu A100 --image pytorch/pytorch:latest --dry-run
```

### GitHub Actions

```yaml
- uses: theoddden/terradev-action@v1
  with:
    gpu-type: A100
    max-price: "1.50"
  env:
    TERRADEV_RUNPOD_KEY: ${{ secrets.RUNPOD_API_KEY }}
```

### Docker (One-Command Workloads)

```bash
terradev run --gpu A100 --image pytorch/pytorch:latest -c "python train.py"
terradev run --gpu H100 --image vllm/vllm-openai:latest --keep-alive --port 8000
```

## Requirements

- Python >= 3.9
- Cloud provider API keys (configured via `terradev configure`)

## License

MIT License - see LICENSE file for details
