from setuptools import setup, find_packages
from pathlib import Path

long_description = ""
readme = Path(__file__).parent / "README.md"
if readme.exists():
    long_description = readme.read_text(encoding="utf-8")

setup(
    name="terradev-cli",
    version="1.2.6",
    author="Terradev Team",
    author_email="team@terradev.com",
    description="Real multi-cloud GPU arbitrage — provision across 10 clouds in parallel with BYOAuth",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/terradev/terradev-cli",
    project_urls={
        "Bug Tracker": "https://github.com/terradev/terradev-cli/issues",
        "Documentation": "https://docs.terradev.com",
        "Source Code": "https://github.com/terradev/terradev-cli",
    },
    packages=find_packages(include=["terradev_cli", "terradev_cli.*"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "Topic :: System :: Systems Administration",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.9",
    install_requires=[
        "click>=8.0.0",
        "aiohttp>=3.9.0",
        "pyyaml>=6.0",
        "cryptography>=41.0.0",
    ],
    extras_require={
        "aws": ["boto3>=1.34.0"],
        "gcp": ["google-cloud-compute>=1.8.0"],
        "azure": ["azure-mgmt-compute>=29.0.0", "azure-identity>=1.12.0"],
        "all": [
            "boto3>=1.34.0",
            "google-cloud-compute>=1.8.0",
            "azure-mgmt-compute>=29.0.0",
            "azure-identity>=1.12.0",
        ],
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "black>=22.0.0",
            "flake8>=5.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "terradev=terradev_cli.cli:cli",
        ],
    },
    include_package_data=True,
    package_data={
        "terradev_cli": [
            "templates/*.yaml",
            "templates/*.json",
            "config/*.json",
        ],
    },
    zip_safe=False,
    keywords=[
        "cloud", "gpu", "provisioning", "multi-cloud", "arbitrage",
        "aws", "gcp", "azure", "runpod", "vastai", "machine-learning",
        "cost-optimization", "parallel",
    ],
)
