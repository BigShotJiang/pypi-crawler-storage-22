"""
Terradev CLI - Cross-Cloud Compute Optimization Platform
Parallel provisioning and orchestration for optimized compute costs
"""

__version__ = "1.2.6"
__author__ = "Terradev Team"
__description__ = (
    "Real multi-cloud GPU arbitrage — provision across 11 clouds in parallel"
)
