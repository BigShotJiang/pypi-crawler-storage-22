#!/usr/bin/env python3
"""
GPU Price Intelligence Engine — GARCH volatility, delta, gamma, and
training/inference price segmentation.

All data lives in the same ~/.terradev/cost_tracking.db alongside the
existing cost tracker tables.  New tables:

    price_ticks     – raw tick-level price observations (one row per
                      gpu_type × provider × region × workload_type per
                      observation timestamp)
    price_stats     – pre-computed rolling statistics (σ, δ, γ) refreshed
                      on every new tick batch
    garch_params    – fitted GARCH(1,1) parameters (ω, α, β) per series
    price_alerts    – user-defined price thresholds and trigger history

The module exposes:
    record_price_tick()          – called by quote/provision paths
    compute_delta()              – first derivative (rate of change)
    compute_gamma()              – second derivative (acceleration)
    fit_garch()                  – GARCH(1,1) MLE fit for a series
    forecast_volatility()        – h-step ahead σ² forecast
    get_price_series()           – retrieve time-series for a key
    get_insights()               – full dashboard dict for a GPU type
    refresh_stats()              – batch recompute δ/γ/σ for all series
"""

import sqlite3
import math
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple

DB_PATH = Path.home() / ".terradev" / "cost_tracking.db"


# ═══════════════════════════════════════════════════════════════════════
# Database helpers
# ═══════════════════════════════════════════════════════════════════════

def _conn() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    _ensure_price_schema(conn)
    return conn


def _ensure_price_schema(conn: sqlite3.Connection):
    conn.executescript("""
        -- Raw price observations (tick level)
        CREATE TABLE IF NOT EXISTS price_ticks (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            ts              TEXT    NOT NULL DEFAULT (datetime('now')),
            gpu_type        TEXT    NOT NULL,
            provider        TEXT    NOT NULL,
            region          TEXT    NOT NULL DEFAULT '',
            price_hr        REAL    NOT NULL,
            spot            INTEGER NOT NULL DEFAULT 0,
            workload_type   TEXT    NOT NULL DEFAULT 'training',
            source          TEXT    NOT NULL DEFAULT 'quote'
        );

        CREATE INDEX IF NOT EXISTS idx_ticks_series
            ON price_ticks (gpu_type, provider, spot, workload_type, ts);

        CREATE INDEX IF NOT EXISTS idx_ticks_ts
            ON price_ticks (ts);

        -- Pre-computed rolling statistics per series
        CREATE TABLE IF NOT EXISTS price_stats (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            ts              TEXT    NOT NULL DEFAULT (datetime('now')),
            gpu_type        TEXT    NOT NULL,
            provider        TEXT    NOT NULL,
            spot            INTEGER NOT NULL DEFAULT 0,
            workload_type   TEXT    NOT NULL DEFAULT 'training',
            -- Current price snapshot
            price_latest    REAL,
            -- Delta (rate of change)
            delta_1h        REAL,
            delta_24h       REAL,
            delta_7d        REAL,
            -- Gamma (acceleration)
            gamma_1h        REAL,
            gamma_24h       REAL,
            gamma_7d        REAL,
            -- Volatility
            volatility_24h  REAL,
            volatility_7d   REAL,
            volatility_30d  REAL,
            -- GARCH forecast
            garch_sigma_1h  REAL,
            garch_sigma_24h REAL,
            -- Descriptive
            price_min_24h   REAL,
            price_max_24h   REAL,
            price_mean_24h  REAL,
            price_min_7d    REAL,
            price_max_7d    REAL,
            price_mean_7d   REAL,
            tick_count       INTEGER NOT NULL DEFAULT 0,
            UNIQUE(gpu_type, provider, spot, workload_type)
        );

        -- Fitted GARCH(1,1) parameters per series
        CREATE TABLE IF NOT EXISTS garch_params (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            ts              TEXT    NOT NULL DEFAULT (datetime('now')),
            gpu_type        TEXT    NOT NULL,
            provider        TEXT    NOT NULL,
            spot            INTEGER NOT NULL DEFAULT 0,
            workload_type   TEXT    NOT NULL DEFAULT 'training',
            omega           REAL    NOT NULL DEFAULT 0.0001,
            alpha           REAL    NOT NULL DEFAULT 0.1,
            beta            REAL    NOT NULL DEFAULT 0.85,
            log_likelihood  REAL,
            n_obs           INTEGER NOT NULL DEFAULT 0,
            UNIQUE(gpu_type, provider, spot, workload_type)
        );

        -- Price alerts
        CREATE TABLE IF NOT EXISTS price_alerts (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at      TEXT    NOT NULL DEFAULT (datetime('now')),
            gpu_type        TEXT    NOT NULL,
            provider        TEXT,
            spot            INTEGER,
            workload_type   TEXT,
            direction       TEXT    NOT NULL DEFAULT 'below',
            threshold       REAL    NOT NULL,
            triggered_at    TEXT,
            active          INTEGER NOT NULL DEFAULT 1
        );
    """)
    conn.commit()


# ═══════════════════════════════════════════════════════════════════════
# Tick recording
# ═══════════════════════════════════════════════════════════════════════

def record_price_tick(
    gpu_type: str,
    provider: str,
    price_hr: float,
    region: str = "",
    spot: bool = False,
    workload_type: str = "training",
    source: str = "quote",
):
    """Record a single price observation."""
    conn = _conn()
    conn.execute(
        "INSERT INTO price_ticks "
        "(gpu_type, provider, region, price_hr, spot, workload_type, source) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (gpu_type.upper(), provider.lower(), region, price_hr,
         1 if spot else 0, workload_type.lower(), source),
    )
    conn.commit()
    conn.close()


def record_price_ticks_batch(ticks: List[Dict[str, Any]]):
    """Record multiple price observations in one transaction."""
    conn = _conn()
    for t in ticks:
        conn.execute(
            "INSERT INTO price_ticks "
            "(gpu_type, provider, region, price_hr, spot, workload_type, source) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                t.get("gpu_type", "").upper(),
                t.get("provider", "").lower(),
                t.get("region", ""),
                t.get("price", t.get("price_hr", 0)),
                1 if t.get("spot") or t.get("availability") == "spot" else 0,
                t.get("workload_type", "training").lower(),
                t.get("source", "quote"),
            ),
        )
    conn.commit()
    conn.close()


# ═══════════════════════════════════════════════════════════════════════
# Time-series retrieval
# ═══════════════════════════════════════════════════════════════════════

def get_price_series(
    gpu_type: str,
    provider: Optional[str] = None,
    spot: Optional[bool] = None,
    workload_type: Optional[str] = None,
    hours: int = 168,
) -> List[Dict[str, Any]]:
    """Retrieve price time-series for a given GPU type.

    Returns list of {ts, price_hr, provider, spot, workload_type}.
    Default window: 168 hours (7 days).
    """
    conn = _conn()
    cutoff = (datetime.utcnow() - timedelta(hours=hours)).isoformat()
    sql = "SELECT ts, price_hr, provider, region, spot, workload_type FROM price_ticks WHERE gpu_type = ? AND ts >= ?"
    params: list = [gpu_type.upper(), cutoff]

    if provider:
        sql += " AND provider = ?"
        params.append(provider.lower())
    if spot is not None:
        sql += " AND spot = ?"
        params.append(1 if spot else 0)
    if workload_type:
        sql += " AND workload_type = ?"
        params.append(workload_type.lower())

    sql += " ORDER BY ts ASC"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _get_prices_array(
    conn: sqlite3.Connection,
    gpu_type: str,
    provider: str,
    spot: int,
    workload_type: str,
    hours: int,
) -> List[float]:
    """Internal: get raw price array for a series within a time window."""
    cutoff = (datetime.utcnow() - timedelta(hours=hours)).isoformat()
    rows = conn.execute(
        "SELECT price_hr FROM price_ticks "
        "WHERE gpu_type = ? AND provider = ? AND spot = ? AND workload_type = ? AND ts >= ? "
        "ORDER BY ts ASC",
        (gpu_type, provider, spot, workload_type, cutoff),
    ).fetchall()
    return [r["price_hr"] for r in rows]


# ═══════════════════════════════════════════════════════════════════════
# Delta — first derivative (rate of price change)
# ═══════════════════════════════════════════════════════════════════════

def compute_delta(prices: List[float], window: int = 1) -> Optional[float]:
    """Compute percentage price change over `window` observations.

    δ = (P_t - P_{t-window}) / P_{t-window}

    Returns None if insufficient data.
    """
    if len(prices) < window + 1:
        return None
    p_now = prices[-1]
    p_prev = prices[-(window + 1)]
    if p_prev == 0:
        return None
    return (p_now - p_prev) / p_prev


def compute_delta_absolute(prices: List[float], window: int = 1) -> Optional[float]:
    """Absolute price change over `window` observations."""
    if len(prices) < window + 1:
        return None
    return prices[-1] - prices[-(window + 1)]


# ═══════════════════════════════════════════════════════════════════════
# Gamma — second derivative (acceleration of price change)
# ═══════════════════════════════════════════════════════════════════════

def compute_gamma(prices: List[float], window: int = 1) -> Optional[float]:
    """Compute acceleration of price change (second derivative).

    γ = δ_t - δ_{t-1}

    where δ_t = (P_t - P_{t-1}) / P_{t-1}

    Positive gamma = price acceleration (increasing faster)
    Negative gamma = price deceleration (slowing down or reversing)

    Returns None if insufficient data.
    """
    if len(prices) < window + 2:
        return None

    # Current delta
    delta_now = compute_delta(prices, window)
    # Previous delta (shift back by 1)
    delta_prev = compute_delta(prices[:-1], window)

    if delta_now is None or delta_prev is None:
        return None

    return delta_now - delta_prev


# ═══════════════════════════════════════════════════════════════════════
# Realized volatility
# ═══════════════════════════════════════════════════════════════════════

def compute_realized_volatility(prices: List[float]) -> Optional[float]:
    """Compute annualized realized volatility from log returns.

    σ = std(log_returns) × √(observations_per_year)

    Assumes ~hourly observations → 8760 obs/year.
    Returns None if < 3 observations.
    """
    if len(prices) < 3:
        return None

    log_returns = []
    for i in range(1, len(prices)):
        if prices[i] > 0 and prices[i - 1] > 0:
            log_returns.append(math.log(prices[i] / prices[i - 1]))

    if len(log_returns) < 2:
        return None

    mean_r = sum(log_returns) / len(log_returns)
    variance = sum((r - mean_r) ** 2 for r in log_returns) / (len(log_returns) - 1)
    std_dev = math.sqrt(variance)

    # Annualize assuming hourly observations
    annualized = std_dev * math.sqrt(8760)
    return annualized


# ═══════════════════════════════════════════════════════════════════════
# GARCH(1,1) — Generalized Autoregressive Conditional Heteroskedasticity
# ═══════════════════════════════════════════════════════════════════════

def _log_returns(prices: List[float]) -> List[float]:
    """Compute log returns from a price series."""
    returns = []
    for i in range(1, len(prices)):
        if prices[i] > 0 and prices[i - 1] > 0:
            returns.append(math.log(prices[i] / prices[i - 1]))
    return returns


def _garch_log_likelihood(
    returns: List[float],
    omega: float,
    alpha: float,
    beta: float,
) -> float:
    """Compute GARCH(1,1) log-likelihood.

    σ²_t = ω + α·ε²_{t-1} + β·σ²_{t-1}

    L = -0.5 × Σ [log(2π) + log(σ²_t) + ε²_t / σ²_t]
    """
    n = len(returns)
    if n < 2:
        return -1e18

    # Initialize variance at sample variance
    sigma2 = sum(r ** 2 for r in returns) / n
    ll = 0.0

    for t in range(1, n):
        sigma2 = omega + alpha * (returns[t - 1] ** 2) + beta * sigma2
        sigma2 = max(sigma2, 1e-12)  # floor to avoid log(0)
        ll += -0.5 * (math.log(2 * math.pi) + math.log(sigma2) + (returns[t] ** 2) / sigma2)

    return ll


def fit_garch(
    prices: List[float],
    max_iter: int = 200,
    tol: float = 1e-8,
) -> Dict[str, float]:
    """Fit GARCH(1,1) via grid search + coordinate descent.

    No external dependencies (no scipy/arch). Pure Python MLE.

    Returns {omega, alpha, beta, log_likelihood, n_obs}.
    """
    returns = _log_returns(prices)
    n = len(returns)

    if n < 10:
        # Not enough data — return default params
        return {
            "omega": 0.0001,
            "alpha": 0.1,
            "beta": 0.85,
            "log_likelihood": None,
            "n_obs": n,
        }

    sample_var = sum(r ** 2 for r in returns) / n

    # Grid search for initial parameters
    best_ll = -1e18
    best_params = (0.0001, 0.1, 0.85)

    for alpha_init in [0.03, 0.05, 0.08, 0.10, 0.15, 0.20]:
        for beta_init in [0.70, 0.75, 0.80, 0.85, 0.88, 0.90, 0.93]:
            if alpha_init + beta_init >= 0.999:
                continue
            omega_init = sample_var * (1 - alpha_init - beta_init)
            omega_init = max(omega_init, 1e-10)
            ll = _garch_log_likelihood(returns, omega_init, alpha_init, beta_init)
            if ll > best_ll:
                best_ll = ll
                best_params = (omega_init, alpha_init, beta_init)

    omega, alpha, beta = best_params

    # Coordinate descent refinement
    step_sizes = [0.02, 0.01, 0.005, 0.002, 0.001]
    for step in step_sizes:
        improved = True
        iterations = 0
        while improved and iterations < max_iter:
            improved = False
            iterations += 1

            # Try adjusting alpha
            for d_alpha in [step, -step]:
                new_alpha = alpha + d_alpha
                if 0.001 < new_alpha < 0.5 and new_alpha + beta < 0.999:
                    new_omega = max(sample_var * (1 - new_alpha - beta), 1e-10)
                    ll = _garch_log_likelihood(returns, new_omega, new_alpha, beta)
                    if ll > best_ll + tol:
                        best_ll = ll
                        alpha = new_alpha
                        omega = new_omega
                        improved = True
                        break

            # Try adjusting beta
            for d_beta in [step, -step]:
                new_beta = beta + d_beta
                if 0.5 < new_beta < 0.999 and alpha + new_beta < 0.999:
                    new_omega = max(sample_var * (1 - alpha - new_beta), 1e-10)
                    ll = _garch_log_likelihood(returns, new_omega, alpha, new_beta)
                    if ll > best_ll + tol:
                        best_ll = ll
                        beta = new_beta
                        omega = new_omega
                        improved = True
                        break

    return {
        "omega": round(omega, 10),
        "alpha": round(alpha, 6),
        "beta": round(beta, 6),
        "log_likelihood": round(best_ll, 4),
        "n_obs": n,
    }


def forecast_volatility(
    prices: List[float],
    omega: float,
    alpha: float,
    beta: float,
    steps: int = 1,
) -> List[float]:
    """Forecast h-step ahead conditional variance using GARCH(1,1).

    σ²_{t+h} = ω·Σ(α+β)^i + (α+β)^h · σ²_t

    Returns list of forecasted σ (standard deviations) for each step.
    """
    returns = _log_returns(prices)
    if len(returns) < 2:
        return [0.0] * steps

    # Compute final conditional variance from the series
    sigma2 = sum(r ** 2 for r in returns) / len(returns)
    for t in range(1, len(returns)):
        sigma2 = omega + alpha * (returns[t - 1] ** 2) + beta * sigma2
        sigma2 = max(sigma2, 1e-12)

    # Last squared return
    last_eps2 = returns[-1] ** 2

    # One-step ahead
    sigma2_forecast = omega + alpha * last_eps2 + beta * sigma2

    forecasts = []
    for h in range(steps):
        forecasts.append(math.sqrt(max(sigma2_forecast, 1e-12)))
        # Multi-step: σ²_{t+h+1} = ω + (α+β)·σ²_{t+h}
        sigma2_forecast = omega + (alpha + beta) * sigma2_forecast

    return forecasts


# ═══════════════════════════════════════════════════════════════════════
# Stats refresh — recompute all rolling statistics
# ═══════════════════════════════════════════════════════════════════════

def refresh_stats():
    """Recompute δ, γ, σ, and GARCH params for all active series."""
    conn = _conn()

    # Get all unique series
    series = conn.execute(
        "SELECT DISTINCT gpu_type, provider, spot, workload_type FROM price_ticks"
    ).fetchall()

    for s in series:
        gpu_type = s["gpu_type"]
        provider = s["provider"]
        spot = s["spot"]
        wtype = s["workload_type"]

        # Get price arrays for different windows
        prices_1h = _get_prices_array(conn, gpu_type, provider, spot, wtype, 1)
        prices_24h = _get_prices_array(conn, gpu_type, provider, spot, wtype, 24)
        prices_7d = _get_prices_array(conn, gpu_type, provider, spot, wtype, 168)
        prices_30d = _get_prices_array(conn, gpu_type, provider, spot, wtype, 720)

        # Latest price
        price_latest = prices_7d[-1] if prices_7d else None

        # Delta (percentage change)
        delta_1h = compute_delta(prices_1h) if len(prices_1h) >= 2 else None
        delta_24h = compute_delta(prices_24h) if len(prices_24h) >= 2 else None
        delta_7d = compute_delta(prices_7d) if len(prices_7d) >= 2 else None

        # Gamma (acceleration)
        gamma_1h = compute_gamma(prices_1h) if len(prices_1h) >= 3 else None
        gamma_24h = compute_gamma(prices_24h) if len(prices_24h) >= 3 else None
        gamma_7d = compute_gamma(prices_7d) if len(prices_7d) >= 3 else None

        # Realized volatility
        vol_24h = compute_realized_volatility(prices_24h)
        vol_7d = compute_realized_volatility(prices_7d)
        vol_30d = compute_realized_volatility(prices_30d)

        # Descriptive stats
        price_min_24h = min(prices_24h) if prices_24h else None
        price_max_24h = max(prices_24h) if prices_24h else None
        price_mean_24h = sum(prices_24h) / len(prices_24h) if prices_24h else None
        price_min_7d = min(prices_7d) if prices_7d else None
        price_max_7d = max(prices_7d) if prices_7d else None
        price_mean_7d = sum(prices_7d) / len(prices_7d) if prices_7d else None

        # GARCH fit (use 30d data if available, else 7d)
        garch_prices = prices_30d if len(prices_30d) >= 20 else prices_7d
        garch_result = fit_garch(garch_prices)

        # GARCH forecast
        garch_sigma_1h = None
        garch_sigma_24h = None
        if garch_result["log_likelihood"] is not None:
            forecasts = forecast_volatility(
                garch_prices,
                garch_result["omega"],
                garch_result["alpha"],
                garch_result["beta"],
                steps=24,
            )
            garch_sigma_1h = forecasts[0] if forecasts else None
            garch_sigma_24h = forecasts[-1] if len(forecasts) >= 24 else None

        tick_count = len(prices_30d)

        # Upsert price_stats
        conn.execute(
            """INSERT INTO price_stats
               (gpu_type, provider, spot, workload_type,
                price_latest,
                delta_1h, delta_24h, delta_7d,
                gamma_1h, gamma_24h, gamma_7d,
                volatility_24h, volatility_7d, volatility_30d,
                garch_sigma_1h, garch_sigma_24h,
                price_min_24h, price_max_24h, price_mean_24h,
                price_min_7d, price_max_7d, price_mean_7d,
                tick_count, ts)
               VALUES (?, ?, ?, ?,
                       ?, ?, ?, ?,
                       ?, ?, ?,
                       ?, ?, ?,
                       ?, ?,
                       ?, ?, ?,
                       ?, ?, ?,
                       ?, datetime('now'))
               ON CONFLICT(gpu_type, provider, spot, workload_type)
               DO UPDATE SET
                   price_latest = excluded.price_latest,
                   delta_1h = excluded.delta_1h,
                   delta_24h = excluded.delta_24h,
                   delta_7d = excluded.delta_7d,
                   gamma_1h = excluded.gamma_1h,
                   gamma_24h = excluded.gamma_24h,
                   gamma_7d = excluded.gamma_7d,
                   volatility_24h = excluded.volatility_24h,
                   volatility_7d = excluded.volatility_7d,
                   volatility_30d = excluded.volatility_30d,
                   garch_sigma_1h = excluded.garch_sigma_1h,
                   garch_sigma_24h = excluded.garch_sigma_24h,
                   price_min_24h = excluded.price_min_24h,
                   price_max_24h = excluded.price_max_24h,
                   price_mean_24h = excluded.price_mean_24h,
                   price_min_7d = excluded.price_min_7d,
                   price_max_7d = excluded.price_max_7d,
                   price_mean_7d = excluded.price_mean_7d,
                   tick_count = excluded.tick_count,
                   ts = excluded.ts
            """,
            (gpu_type, provider, spot, wtype,
             price_latest,
             delta_1h, delta_24h, delta_7d,
             gamma_1h, gamma_24h, gamma_7d,
             vol_24h, vol_7d, vol_30d,
             garch_sigma_1h, garch_sigma_24h,
             price_min_24h, price_max_24h, price_mean_24h,
             price_min_7d, price_max_7d, price_mean_7d,
             tick_count),
        )

        # Upsert garch_params
        if garch_result["log_likelihood"] is not None:
            conn.execute(
                """INSERT INTO garch_params
                   (gpu_type, provider, spot, workload_type,
                    omega, alpha, beta, log_likelihood, n_obs)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT(gpu_type, provider, spot, workload_type)
                   DO UPDATE SET
                       omega = excluded.omega,
                       alpha = excluded.alpha,
                       beta = excluded.beta,
                       log_likelihood = excluded.log_likelihood,
                       n_obs = excluded.n_obs,
                       ts = datetime('now')
                """,
                (gpu_type, provider, spot, wtype,
                 garch_result["omega"], garch_result["alpha"],
                 garch_result["beta"], garch_result["log_likelihood"],
                 garch_result["n_obs"]),
            )

    conn.commit()
    conn.close()
    return len(series)


# ═══════════════════════════════════════════════════════════════════════
# Insights — full dashboard for a GPU type
# ═══════════════════════════════════════════════════════════════════════

def get_insights(
    gpu_type: str,
    workload_type: Optional[str] = None,
) -> Dict[str, Any]:
    """Get full price intelligence dashboard for a GPU type.

    Returns dict with per-provider stats, deltas, gammas, volatility,
    GARCH forecasts, and recommendations.
    """
    conn = _conn()

    sql = "SELECT * FROM price_stats WHERE gpu_type = ?"
    params: list = [gpu_type.upper()]
    if workload_type:
        sql += " AND workload_type = ?"
        params.append(workload_type.lower())

    rows = conn.execute(sql, params).fetchall()

    providers = []
    for r in rows:
        entry = dict(r)
        # Add GARCH params if available
        garch = conn.execute(
            "SELECT omega, alpha, beta, log_likelihood, n_obs FROM garch_params "
            "WHERE gpu_type = ? AND provider = ? AND spot = ? AND workload_type = ?",
            (r["gpu_type"], r["provider"], r["spot"], r["workload_type"]),
        ).fetchone()
        if garch:
            entry["garch"] = dict(garch)

        # Stability score: lower volatility + lower |gamma| = more stable
        vol = r["volatility_7d"] or 0
        gamma = abs(r["gamma_24h"] or 0)
        entry["stability_score"] = round(max(0, 100 - (vol * 100) - (gamma * 500)), 1)

        providers.append(entry)

    conn.close()

    # Sort by price
    providers.sort(key=lambda x: x.get("price_latest") or 999)

    # Recommendations
    cheapest = providers[0] if providers else None
    most_stable = max(providers, key=lambda x: x.get("stability_score", 0)) if providers else None

    # Find best value: cheapest among stable options (stability > 60)
    stable_options = [p for p in providers if p.get("stability_score", 0) > 60]
    best_value = min(stable_options, key=lambda x: x.get("price_latest") or 999) if stable_options else cheapest

    return {
        "gpu_type": gpu_type.upper(),
        "workload_type": workload_type or "all",
        "providers": providers,
        "recommendations": {
            "cheapest": {
                "provider": cheapest["provider"] if cheapest else None,
                "price": cheapest["price_latest"] if cheapest else None,
                "spot": bool(cheapest["spot"]) if cheapest else None,
            } if cheapest else None,
            "most_stable": {
                "provider": most_stable["provider"] if most_stable else None,
                "stability_score": most_stable["stability_score"] if most_stable else None,
                "price": most_stable["price_latest"] if most_stable else None,
            } if most_stable else None,
            "best_value": {
                "provider": best_value["provider"] if best_value else None,
                "price": best_value["price_latest"] if best_value else None,
                "stability_score": best_value["stability_score"] if best_value else None,
                "reason": "Cheapest option with stability score > 60",
            } if best_value else None,
        },
        "summary": {
            "total_providers": len(providers),
            "price_range": (
                f"${min(p['price_latest'] for p in providers if p.get('price_latest')):.2f}"
                f" — ${max(p['price_latest'] for p in providers if p.get('price_latest')):.2f}"
            ) if providers and any(p.get("price_latest") for p in providers) else "N/A",
        },
    }


def get_all_tracked_gpus() -> List[str]:
    """Return list of all GPU types with price data."""
    conn = _conn()
    rows = conn.execute("SELECT DISTINCT gpu_type FROM price_ticks ORDER BY gpu_type").fetchall()
    conn.close()
    return [r["gpu_type"] for r in rows]


def get_training_vs_inference(gpu_type: str) -> Dict[str, Any]:
    """Compare training vs inference pricing for a GPU type."""
    conn = _conn()

    result = {}
    for wtype in ["training", "inference"]:
        row = conn.execute(
            "SELECT * FROM price_stats WHERE gpu_type = ? AND workload_type = ? ORDER BY price_latest ASC",
            (gpu_type.upper(), wtype),
        ).fetchall()
        result[wtype] = {
            "providers": len(row),
            "cheapest": dict(row[0]) if row else None,
            "all": [dict(r) for r in row],
        }

    conn.close()

    # Compute premium/discount
    train_price = result["training"]["cheapest"]["price_latest"] if result["training"]["cheapest"] else None
    infer_price = result["inference"]["cheapest"]["price_latest"] if result["inference"]["cheapest"] else None

    if train_price and infer_price and train_price > 0:
        result["inference_premium"] = round((infer_price - train_price) / train_price * 100, 1)
    else:
        result["inference_premium"] = None

    return result
