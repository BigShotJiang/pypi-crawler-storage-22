#!/usr/bin/env python3
"""
Terradev Production Application
Elastic Beanstalk Entry Point
"""

import os
from api_main_simple import app

if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get('PORT', 8000))
    uvicorn.run(app, host="0.0.0.0", port=port)
