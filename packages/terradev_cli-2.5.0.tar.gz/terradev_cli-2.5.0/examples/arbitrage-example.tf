# Example: Real-time GPU arbitrage deployment
# This example shows how to use Terradev for cross-cloud GPU arbitrage

terraform {
  required_version = ">= 1.0"
  required_providers {
    terradev = {
      source  = "terradev/terradev"
      version = "~> 1.0"
    }
  }
}

# Configure user and tier
locals {
  user_id = "demo-user-123"
  tier    = "freemium"  # Change to "paid" for unlimited access
}

# Real-time GPU price arbitrage data source
data "terradev_gpu_price" "global" {
  providers = ["aws", "gcp", "azure", "runpod", "lambda", "coreweave"]
  gpu_types = ["a100", "h100", "a10g"]
  spot_only = true
  max_price_per_hour = 5.0
  
  depends_on = [
    module.tier_management
  ]
}

# Check user tier and usage limits
module "tier_management" {
  source = "../modules/tier-management"
  
  user_id          = local.user_id
  tier             = local.tier
  gpu_hours_used   = 3.5  # Current usage this month
  model_name       = "llama"
  dataset_source   = "huggingface"
  dataset_size_gb  = 25
}

# Deploy to cheapest available GPU
module "spot_cluster" {
  source = "../modules/gpu-compute"
  
  count = module.tier_management.deployment_approved ? 1 : 0
  
  name_prefix      = "${local.user_id}-${local.tier}"
  instance_type    = data.terradev_gpu_price.global.cheapest.type
  instance_count   = local.tier == "freemium" ? 1 : 2
  subnet_id        = var.subnet_id
  security_group_ids = var.security_group_ids
  
  # GPU-specific configuration
  ami_id           = data.aws_ami.gpu_optimized.id
  root_volume_size = 100
  assign_public_ip = true
  
  # Auto-scaling (paid tier only)
  enable_auto_scaling = local.tier == "paid"
  min_instances      = local.tier == "paid" ? 1 : 1
  max_instances      = local.tier == "paid" ? 10 : 1
  desired_instances  = local.tier == "paid" ? 2 : 1
  
  # Monitoring
  enable_monitoring = true
  alarm_actions     = [var.alarm_topic_arn]
  
  tags = {
    User        = local.user_id
    Tier        = local.tier
    Project     = "ML-Training"
    CostCenter  = "AI-Research"
    GPU-Type    = data.terradev_gpu_price.global.cheapest.type
    Provider    = data.terradev_gpu_price.global.cheapest.provider
    Spot-Price  = data.terradev_gpu_price.global.cheapest.price
  }
}

# Hugging Face dataset integration (freemium tier only)
module "hf_dataset" {
  source = "../modules/huggingface"
  count  = local.tier == "freemium" ? 1 : 0
  
  dataset_name     = "coco"
  tier             = local.tier
  hf_token         = var.hf_token
  max_dataset_size_gb = 50
  
  # Preprocessing configuration
  preprocess_config = {
    tokenize = true
    max_length = 512
    image_size = 224
    normalize = true
    augment = false
  }
}

# Custom dataset support (paid tier only)
module "custom_dataset" {
  source = "../modules/data-feeds"
  count  = local.tier == "paid" ? 1 : 0
  
  dataset_source   = var.custom_dataset_source
  dataset_path     = var.custom_dataset_path
  format           = var.custom_dataset_format
  preprocessing    = true
  
  # Data provenance tracking (paid tier feature)
  enable_provenance = true
  provenance_config = {
    track_lineage = true
    checksum_verification = true
    metadata_collection = true
  }
}

# Cost tracking and monitoring
module "cost_tracking" {
  source = "../modules/cost-tracking"
  
  user_id     = local.user_id
  tier        = local.tier
  project_id  = "${local.user_id}-ml-training"
  
  # Budget alerts
  monthly_budget = local.tier == "freemium" ? 50 : 1000
  alert_threshold = 0.8
  
  # Cost allocation tags
  cost_tags = {
    User = local.user_id
    Tier = local.tier
    Project = "ML-Training"
    Environment = "production"
  }
}

# Output deployment information
output "arbitrage_results" {
  value = {
    deployment_approved = module.tier_management.deployment_approved
    cheapest_gpu = {
      provider = data.terradev_gpu_price.global.cheapest.provider
      type     = data.terradev_gpu_price.global.cheapest.type
      price    = data.terradev_gpu_price.global.cheapest.price
      savings  = data.terradev_gpu_price.global.cheapest.savings
    }
    estimated_monthly_cost = data.terradev_gpu_price.global.cheapest.price * 24 * 30
    potential_savings = data.terradev_gpu_price.global.cheapest.savings_pct
    usage_status = module.tier_management.usage_status
  }
}

output "cluster_info" {
  value = length(module.spot_cluster) > 0 ? {
    instance_count = length(module.spot_cluster[0].gpu_instances)
    instance_type  = data.terradev_gpu_price.global.cheapest.type
    provider       = data.terradev_gpu_price.global.cheapest.provider
    hourly_cost    = data.terradev_gpu_price.global.cheapest.price
    monthly_cost   = data.terradev_gpu_price.global.cheapest.price * 24 * 30
  } : null
}

output "dataset_info" {
  value = local.tier == "freemium" && length(module.hf_dataset) > 0 ? {
    dataset_name = "coco"
    size_gb = module.hf_dataset[0].dataset_metadata.size_gb
    compatible = module.hf_dataset[0].dataset_compatible
    recommended_models = module.hf_dataset[0].recommended_models
  } : null
}
