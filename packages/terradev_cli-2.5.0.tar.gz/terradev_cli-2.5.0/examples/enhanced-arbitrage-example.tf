# Enhanced GPU Arbitrage Example
# This example shows how to use Terradev with smart financial insights

terraform {
  required_providers {
    terradev = {
      source = "terradev/terradev"
    }
  }
}

# Configure providers
provider "aws" {
  region = "us-west-2"
}

provider "gcp" {
  region = "us-central1"
}

# Basic GPU arbitrage with smart financial insights
module "gpu_arbitrage" {
  source = "../modules/arbitrage"
  
  # Core configuration
  user_id = "user123"
  tier = "freemium"
  gpu_hours_used = 5
  monthly_gpu_hours_limit = 10
  
  # GPU preferences
  gpu_types = ["a100", "h100", "a10g"]
  providers = ["aws", "gcp", "azure", "runpod", "lambda", "coreweave"]
  spot_only = true
  max_price_per_hour = 5.0
  
  # Enhanced financial insights (optional - defaults are good)
  enable_financial_insights = true
  confidence_threshold = 0.7  # 70% confidence required
  max_risk_score = 0.5        # Medium risk tolerance
  enable_price_prediction = true
  enable_market_analysis = true
  risk_tolerance = "moderate"
}

# Example: Conservative deployment for production workloads
module "production_gpu" {
  source = "../modules/arbitrage"
  
  user_id = "prod_user456"
  tier = "paid"
  
  gpu_types = ["a100"]
  providers = ["aws", "gcp", "azure"]  # Only major clouds for production
  
  # Conservative financial settings
  enable_financial_insights = true
  confidence_threshold = 0.85  # Higher confidence for production
  max_risk_score = 0.3        # Lower risk tolerance
  risk_tolerance = "conservative"
}

# Example: Aggressive deployment for development/testing
module "dev_gpu" {
  source = "../modules/arbitrage"
  
  user_id = "dev_user789"
  tier = "freemium"
  
  gpu_types = ["a10g", "rtx4090"]  # Cheaper GPUs for dev
  providers = ["runpod", "lambda", "coreweave"]  # Specialty providers
  
  # Aggressive financial settings
  enable_financial_insights = true
  confidence_threshold = 0.5   # Lower confidence acceptable
  max_risk_score = 0.7        # Higher risk tolerance
  risk_tolerance = "aggressive"
}

# Outputs - What users see
output "cheapest_gpu" {
  description = "Overall cheapest GPU found"
  value = module.gpu_arbitrage.cheapest_gpu
}

output "savings_analysis" {
  description = "Detailed savings analysis"
  value = module.gpu_arbitrage.enhanced_cost_analysis
}

output "financial_insights" {
  description = "Smart financial insights and risk assessment"
  value = module.gpu_arbitrage.financial_insights
}

output "deployment_decision" {
  description = "Should we deploy now?"
  value = module.gpu_arbitrage.deployment_decision
}

output "market_intelligence" {
  description = "Market efficiency and volatility data"
  value = module.gpu_arbitrage.market_intelligence
}

# Example usage commands:
# terraform plan
# terraform apply
# terraform output financial_insights
# terraform output deployment_decision
