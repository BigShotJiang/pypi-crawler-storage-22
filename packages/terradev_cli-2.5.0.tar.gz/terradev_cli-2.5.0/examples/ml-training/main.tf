# ML Training Example Configuration
# This example demonstrates setting up GPU instances for machine learning training
# with integrated data feeds for training datasets

terraform {
  required_version = ">= 1.0"
  
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

# Variables specific to ML training
variable "training_job_name" {
  description = "Name of the ML training job"
  type        = string
  default     = "ml-training-job"
}

variable "dataset_source" {
  description = "Source URL for training dataset"
  type        = string
  default     = "https://example.com/datasets/training-data.zip"
}

variable "model_type" {
  description = "Type of ML model to train"
  type        = string
  default     = "image-classification"
  
  validation {
    condition = contains(["image-classification", "nlp", "reinforcement-learning", "time-series"], var.model_type)
    error_message = "Model type must be one of: image-classification, nlp, reinforcement-learning, time-series."
  }
}

variable "training_duration_hours" {
  description = "Expected training duration in hours"
  type        = number
  default     = 24
}

# GPU Compute Module for ML Training
module "gpu_cluster" {
  source = "../../modules/gpu-compute"

  name_prefix = var.training_job_name
  instance_count = var.gpu_instance_count
  instance_type = var.gpu_instance_type
  ami_id = data.aws_ami.deep_learning.id
  
  subnet_id = aws_subnet.training_subnet.id
  security_group_ids = [aws_security_group.training_sg.id]
  assign_public_ip = true
  
  root_volume_size = 200
  data_volumes = [
    {
      device_name = "/dev/sdf"
      volume_type = "gp3"
      volume_size = 500
    }
  ]
  
  enable_auto_scaling = true
  min_instances = 1
  max_instances = 4
  desired_instances = var.gpu_instance_count
  
  enable_monitoring = true
  
  tags = {
    Project = "Terradev-ML"
    Environment = var.environment
    JobType = var.model_type
  }
  
  user_data = base64encode(templatefile("${path.module}/user-data.sh", {
    training_script = base64encode(file("${path.module}/training-script.py"))
    dataset_url = var.dataset_source
    model_type = var.model_type
    s3_bucket = module.storage.s3_bucket_name
  }))
}

# Storage Module for ML Artifacts
module "storage" {
  source = "../../modules/storage"

  name_prefix = var.training_job_name
  
  enable_versioning = true
  enable_lifecycle = true
  enable_efs = true
  subnet_ids = [aws_subnet.training_subnet.id]
  efs_security_groups = [aws_security_group.training_sg.id]
  enable_dynamodb = true
  enable_logging = true
  
  tags = {
    Project = "Terradev-ML"
    Environment = var.environment
    JobType = var.model_type
  }
}

# Data Feeds Module for Training Data
module "data_feeds" {
  source = "../../modules/data-feeds"

  name_prefix = var.training_job_name
  environment = var.environment
  
  data_feeds = [
    {
      name = "training-dataset"
      type = "http"
      source_url = var.dataset_source
      update_freq = "daily"
      enabled = true
      format = "zip"
      compression = true
    },
    {
      name = "model-checkpoints"
      type = "s3"
      source_url = "s3://model-checkpoints/"
      update_freq = "hourly"
      enabled = true
      format = "binary"
    }
  ]
  
  enable_processing = true
  enable_api = true
  
  tags = {
    Project = "Terradev-ML"
    Environment = var.environment
    JobType = var.model_type
  }
}

# Networking
resource "aws_vpc" "training_vpc" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = {
    Name = "${var.training_job_name}-vpc"
    Project = "Terradev-ML"
  }
}

resource "aws_subnet" "training_subnet" {
  vpc_id            = aws_vpc.training_vpc.id
  cidr_block        = "10.0.1.0/24"
  availability_zone = "${var.aws_region}a"

  tags = {
    Name = "${var.training_job_name}-subnet"
    Project = "Terradev-ML"
  }
}

resource "aws_internet_gateway" "training_igw" {
  vpc_id = aws_vpc.training_vpc.id

  tags = {
    Name = "${var.training_job_name}-igw"
    Project = "Terradev-ML"
  }
}

resource "aws_route_table" "training_rt" {
  vpc_id = aws_vpc.training_vpc.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.training_igw.id
  }

  tags = {
    Name = "${var.training_job_name}-rt"
    Project = "Terradev-ML"
  }
}

resource "aws_route_table_association" "training_rta" {
  subnet_id      = aws_subnet.training_subnet.id
  route_table_id = aws_route_table.training_rt.id
}

# Security Group
resource "aws_security_group" "training_sg" {
  name        = "${var.training_job_name}-sg"
  description = "Security group for ML training instances"
  vpc_id      = aws_vpc.training_vpc.id

  ingress {
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "${var.training_job_name}-sg"
    Project = "Terradev-ML"
  }
}

# Data source for Deep Learning AMI
data "aws_ami" "deep_learning" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["Deep Learning AMI GPU TensorFlow*"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

# CloudWatch Dashboard for Training Monitoring
resource "aws_cloudwatch_dashboard" "training_dashboard" {
  dashboard_name = "${var.training_job_name}-dashboard"

  dashboard_body = jsonencode({
    widgets = [
      {
        type   = "metric"
        x      = 0
        y      = 0
        width  = 12
        height = 6

        properties = {
          metrics = [
            ["AWS/EC2", "CPUUtilization", "InstanceId", module.gpu_cluster.instance_ids[0]],
            [".", "NetworkIn", ".", "."],
            [".", "NetworkOut", ".", "."]
          ]
          period = 300
          stat   = "Average"
          region = var.aws_region
          title  = "Instance Metrics"
        }
      },
      {
        type   = "metric"
        x      = 12
        y      = 0
        width  = 12
        height = 6

        properties = {
          metrics = [
            ["AWS/EC2", "GPUUtilization", "InstanceId", module.gpu_cluster.instance_ids[0]],
            [".", "GPUMemoryUtilization", ".", "."]
          ]
          period = 300
          stat   = "Average"
          region = var.aws_region
          title  = "GPU Metrics"
        }
      }
    ]
  })
}

# SNS Topic for Training Notifications
resource "aws_sns_topic" "training_notifications" {
  name = "${var.training_job_name}-notifications"

  tags = {
    Project = "Terradev-ML"
  }
}

# CloudWatch Alarm for Training Completion
resource "aws_cloudwatch_metric_alarm" "training_completion" {
  alarm_name          = "${var.training_job_name}-completion"
  comparison_operator = "LessThanThreshold"
  evaluation_periods  = "2"
  metric_name         = "CPUUtilization"
  namespace           = "AWS/EC2"
  period              = "300"
  statistic           = "Average"
  threshold           = "5"
  alarm_description   = "Training job completed (low CPU utilization)"
  alarm_actions       = [aws_sns_topic.training_notifications.arn]

  dimensions = {
    InstanceId = module.gpu_cluster.instance_ids[0]
  }

  tags = {
    Project = "Terradev-ML"
  }
}

# Outputs
output "gpu_instance_ids" {
  description = "IDs of GPU training instances"
  value       = module.gpu_cluster.instance_ids
}

output "gpu_instance_public_ips" {
  description = "Public IP addresses of GPU instances"
  value       = module.gpu_cluster.instance_public_ips
}

output "storage_bucket" {
  description = "S3 bucket for training artifacts"
  value       = module.storage.s3_bucket_name
}

output "efs_filesystem_id" {
  description = "EFS filesystem ID for shared storage"
  value       = module.storage.efs_file_system_id
}

output "data_feed_api_url" {
  description = "API URL for data feed access"
  value       = module.data_feeds.api_gateway_url
}

output "dashboard_url" {
  description = "CloudWatch dashboard URL"
  value       = "https://${var.aws_region}.console.aws.amazon.com/cloudwatch/home?region=${var.aws_region}#dashboards:name=${aws_cloudwatch_dashboard.training_dashboard.dashboard_name}"
}
