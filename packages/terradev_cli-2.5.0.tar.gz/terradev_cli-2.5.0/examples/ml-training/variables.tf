variable "aws_region" {
  description = "AWS region for ML training"
  type        = string
  default     = "us-west-2"
}

variable "environment" {
  description = "Environment for ML training"
  type        = string
  default     = "dev"
}

variable "gpu_instance_count" {
  description = "Number of GPU instances for training"
  type        = number
  default     = 2
}

variable "gpu_instance_type" {
  description = "GPU instance type for training"
  type        = string
  default     = "p3.2xlarge"
  
  validation {
    condition = contains([
      "p3.2xlarge", "p3.8xlarge", "p3.16xlarge",
      "p4d.24xlarge", "g4dn.xlarge", "g4dn.2xlarge",
      "g5.xlarge", "g5.2xlarge", "g5.4xlarge"
    ], var.gpu_instance_type)
    error_message = "GPU instance type must be a supported training instance."
  }
}

variable "training_hyperparameters" {
  description = "Training hyperparameters"
  type = object({
    learning_rate    = number
    batch_size       = number
    epochs           = number
    optimizer        = string
    loss_function    = string
  })
  default = {
    learning_rate = 0.001
    batch_size    = 32
    epochs        = 100
    optimizer     = "adam"
    loss_function = "categorical_crossentropy"
  }
}

variable "enable_distributed_training" {
  description = "Enable distributed training across multiple instances"
  type        = bool
  default     = false
}

variable "checkpoint_interval" {
  description = "Interval for saving model checkpoints (in epochs)"
  type        = number
  default     = 10
}

variable "enable_tensorboard" {
  description = "Enable TensorBoard monitoring"
  type        = bool
  default     = true
}

variable "notification_email" {
  description = "Email address for training notifications"
  type        = string
  default     = ""
}
