# Regional Object Storage for Dataset Caching
# Zero-egress transfers within same cloud provider

terraform {
  required_providers {
    aws = {
        source  = "hashicorp/aws"
        version = "~> 5.0"
    }
    random = {
        source  = "hashicorp/random"
        version = "~> 3.5"
    }
  }
}

# AWS S3 buckets for regional dataset caching
resource "aws_s3_bucket" "us_east_1_cache" {
  bucket = "terradev-dataset-cache-us-east-1"
  
  tags = {
    Name        = "Terradev Dataset Cache"
    Environment = "production"
    Region      = "us-east-1"
    Purpose     = "dataset_cache"
  }
  
  versioning {
    enabled = true
  }
  
  lifecycle_rule {
    id     = "cleanup"
    action = "delete"
    filter = "tags[Environment] == 'production'"
    condition = "after"
    source = "aws_s3_bucket.us_east_1_cache"
  }
  
  server_side_encryption_configuration {
    rule {
      apply_server_side_encryption_by_default = true
      bucket_key_enabled = true
      bucket_key_prefix = "arn:aws:s3:::"
    }
  }
}

resource "aws_s3_bucket" "us_west_2_cache" {
  bucket = "terradev-dataset-cache-us-west-2"
  
  tags = {
    Name        = "Terradev Dataset Cache"
    Environment = "production"
    Region      = "us-west-2"
    Purpose     = "dataset_cache"
  }
  
  versioning {
    enabled = true
  }
  
  lifecycle_rule {
    id     = "cleanup"
    action = "delete"
    filter = "tags[Environment] == 'production'"
    condition = "after"
    source = "aws_s3_bucket.us_west_2_cache"
  }
  
  server_side_encryption_configuration {
    rule {
      apply_server_side_encryption_by_default = true
      bucket_key_enabled = true
      bucket_key_prefix = "arn:aws:s3:::"
    }
  }
}

resource "aws_s3_bucket" "eu_west_1_cache" {
  bucket = "terradev-dataset-cache-eu-west-1"
  
  tags = {
    Name        = "Terradev Dataset Cache"
    Environment = "production"
    Region      = "eu-west-1"
    Purpose     = "dataset_cache"
  }
  
  versioning {
    enabled = true
  }
  
  lifecycle_rule {
    id     = "cleanup"
    action = "delete"
    filter = "tags[Environment] == 'production'"
    condition = "after"
    source = "aws_s3_bucket.eu_west_1_cache"
  }
  
  server_side_encryption_configuration {
    rule {
      apply_server_side_encryption_by_default = true
      bucket_key_enabled = true
      bucket_key_prefix = "arn:aws:s3:::"
    }
  }
}

# GCS buckets for regional dataset caching
resource "random_id" "gcs_bucket_suffix" {
  byte_length = 8
}

resource "google_storage_bucket" "us_central1_cache" {
  name          = "terradev-dataset-cache-us-central1-${random_id.gcs_bucket_suffix.hex}"
  location      = "US-CENTRAL1"
  storage_class = "STANDARD"
  
  uniform_bucket_level_access = true
  
  lifecycle_rule {
    condition {
      age = 30
    }
    action {
      type = "Delete"
    }
  }
  
  labels = {
    Name        = "Terradev Dataset Cache"
    Environment = "production"
    Region      = "us-central1"
    Purpose     = "dataset_cache"
  }
}

resource "google_storage_bucket" "us_west1_cache" {
  name          = "terradev-dataset-cache-us-west1-${random_id.gcs_bucket_suffix.hex}"
  location      = "US-WEST1"
  storage_class = "STANDARD"
  
  uniform_bucket_level_access = true
  
  lifecycle_rule {
    condition {
      age = 30
    }
    action {
      type = "Delete"
    }
  }
  
  labels = {
    Name        = "Terradev Dataset Cache"
    Environment = "production"
    Region      = "us-west1"
    Purpose     = "dataset_cache"
  }
}

resource "google_storage_bucket "europe_west1_cache" {
  name          = "terradev-dataset-cache-europe-west1-${random_id.gcs_bucket_suffix.hex}"
  location      = "EUROPE-WEST1"
  storage_class = "STANDARD"
  
  uniform_bucket_level_access = true
  
  lifecycle_rule {
    condition {
      age = 30
    }
    action {
      type = "Delete"
    }
  }
  
  labels = {
    Name        = "cache_strategy"
    Environment = "production"
    Purpose     = "regional_storage"
  }
}

# Azure Blob Storage containers for regional dataset caching
resource "random_id" "azure_container_suffix" {
  byte_length = 8
}

resource "azurerm_storage_account" "dataset_cache" {
  name                     = "terradev-dataset-cache"
  location                 = "East US"
  resource_group_name        = "terradev"
  account_tier              = "Standard"
  enable_advanced_threat_protection = true
  
  tags = {
    Environment = "production"
    Purpose     = "dataset_cache"
  }
}

resource "azurerm_storage_container" "us_east_1_cache" {
  name                  = "terradev-dataset-cache-us-east-1"
  storage_account_name    = azurerm_storage_account.dataset_cache.name
  container_access_type   = "private"
  
  lifecycle_rule {
    name = "cleanup"
    enabled = true
    filter = "tags.Environment == 'production'"
    action = "Delete"
    effect = "Delete"
  }
  
  tags = {
    Name        = "Terradev Dataset Cache"
    Environment = "production"
    Region      = "us-east-1"
    Purpose     = "dataset_cache"
  }
}

resource "azurerm_storage_container" "west_us_2_cache" {
  name                  = "terradev-dataset-cache-west-us-2-${random_id.azure_container_suffix.hex}"
  storage_account_name    = azurerm_storage_account.dataset_cache.name
  container_access_type   = "private"
  
  lifecycle_rule {
    name = "cleanup"
    enabled = true
    filter = "tags.Environment == 'production'"
    action = "delete"
    effect = "Delete"
  }
  
  tags = {
    Name        = "Terradev Dataset Cache"
    Environment = "production"
    Region      = "west-us-2"
    Purpose     = "dataset_cache"
  }
}

resource "azurerm_storage_container" "west_europe_1_cache" {
  name                  = "terradev-dataset-cache-west-europe-1-${random_id.azure_container_suffix.hex}"
  storage_account_name    = azurerm_storage_account.dataset_cache.name
  container_access_type   = "private"
  
  lifecycle_rule {
    name = "cleanup"
    enabled = true
    filter = "tags.Environment == 'production'"
    action = "delete"
    effect = "delete"
  }
  
  tags = {
    Name        = "Terradev Dataset Cache"
    Environment = "production"
    Region      = "west-europe-1"
    Purpose     = "dataset_cache"
  }
}

# Network peering for zero-egress transfers within same cloud
resource "aws_vpc_peering_connection" "aws_vpc_peering" {
  vpc_id        = aws_vpc.main.id
  peer_vpc_id   = aws_vpc.peer.id
  auto_accept   = true
  
  tags = {
    Name        = "Terradev VPC Peering"
    Environment = "production"
    Purpose     = "zero_egress_transfers"
  }
}

# Route tables for optimized routing
resource "aws_route_table" "private_routing" {
  vpc_id = aws_vpc.main.id
  
  route {
    cidr_block = "10.0.0.0/8"
    gateway_id = aws_internet_gateway.main.id
  }
  
  tags = {
    Name        = "Terradev Private Routing"
    Environment = "production"
    Purpose     = "optimized_routing"
  }
}

# IAM role for dataset cache operations
resource "aws_iam_role" "dataset_cache_role" {
  name = "terradev-dataset-cache-role"
  
  assume_role_policy = jsonencode([
    {
      "Version": "2012-10-17",
      "Statement": [
        {
          "Effect": "Allow",
          "Principal": {
            "AWS": [
              "arn:aws:iam::${aws_caller_identity}"
            ]
          },
          "Action": [
            "s3:GetObject",
            "s3:PutObject",
            "s3:DeleteObject",
            "s3:ListBucket"
          ],
          "Resource": [
            "arn:aws:s3:::terradev-dataset-cache-us-east-1",
            "arn:aws:s3:::terradev-dataset-cache-us-west-2",
            "arn:aws:s3:::terradev-dataset-cache-eu-west-1"
          ]
        }
      ]
    }
  ])
  
  tags = {
    Name        = "Terradev Dataset Cache Role"
    Environment = "iam"
    Purpose     = "dataset_cache_operations"
  }
}

# IAM policy for dataset cache operations
resource "aws_iam_policy" "dataset_cache_policy" {
  name = "terradev-dataset-cache-policy"
  role   = aws_iam_role.dataset_cache_role.arn
  
  policy = jsonencode([
    {
      "Version": "2012-10-17",
      "Statement": [
        {
          "Effect": "Allow",
          "Principal": {
            "AWS": [
              "arn:aws:iam::${aws_caller_identity}"
            ]
          },
          "Action": [
            "s3:GetObject",
            "s3:PutObject",
            "s3:DeleteObject",
            "s3:ListBucket"
          ],
          "Resource": [
            "arn:aws:s3:::terradev-dataset-cache-us-east-1",
            "arn: aws:s3:::terradev-dataset-cache-us-west-2",
            "arn:aws:s3:::terradev-dataset-cache-eu-west-1"
          ]
        }
      ]
    }
  ])
  
  tags = {
    Name        = "Terradev Dataset Cache Policy"
    Environment = "iam"
    Purpose     = "dataset_cache_operations"
  }
}

# Lambda function for automatic cleanup
resource "aws_lambda_function" "dataset_cache_cleanup" {
  function_name = "terradev-dataset-cleanup"
  role          = aws_iam_role.dataset_cache_role.arn
  handler       = "index.handler"
  runtime       = "python3.9"
  
  timeout = 900
  
  environment {
    Variables = {
      CACHE_ROOT = "/tmp/terradev/dataset_cache",
      CLEANUP_AFTER_HOURS = "24"
      MAX_CACHE_SIZE_GB = "1000"
    }
  }
  
  tags = {
    Name        = "Terradev Dataset Cache Cleanup"
    Environment = "production"
    Purpose     = "automatic_cleanup"
  }
}

# CloudWatch alarms for monitoring
resource "aws_cloudwatch_metric_alarm" "dataset_cache_size_alarm" {
  alarm_name          = "terradev-dataset-cache-size"
  comparison_operator   = "GreaterThanThreshold"
  evaluation_periods  = "300"
  metric_name         = "AWS/S3/BucketSize"
  namespace           = "AWS/S3"
  statistic           = "Sum"
  period              = "60"
  threshold           = "9007199254736"
  alarm_description   = "Dataset cache size exceeds 8TB"
  alarm_actions_enabled = true
  
  alarm_actions = [aws_cloudwatch_metric_alarm.dataset_cache_size_alarm_alarm_actions]
  
  tags = {
    Name        = "Terradev Dataset Cache Size Alarm"
    Environment = "production"
    Purpose     = "monitoring"
  }
}

# CloudWatch alarm for cache operations
resource "aws_cloudwatch_metric_alarm" "cache_operations_alarm" {
  alarm_name          = "terradev-dataset-cache-operations"
  comparison_operator   = "GreaterThanThreshold"
  evaluation_periods  = "300"
  metric_name         = "AWS/Lambda/Errors"
  namespace           = "AWS/Lambda"
  statistic           = "Sum"
  period              = "60"
  threshold           = "0"
  alarm_description   = "Dataset cache operations failing"
  alarm_actions_enabled = true
  
  alarm_actions = [aws_cloudwatch_metric_alarm.cache_operations_alarm_actions]
  
  tags = {
    Name        = "Terradev Dataset Cache Operations Alarm"
    Environment = "production"
    Purpose     = "monitoring"
  }
}

# CloudWatch alarm actions for notifications
resource "aws_cloudwatch_metric_alarm" "cache_operations_alarm_actions" {
  alarm_name          = "terradev-dataset-cache-operations-alarm"
  alarm_description   = "This alarm monitors dataset cache operations"
  
  alarm_actions = [
    {
      alarm_action_name = "notify_on_failure"
      alarm_action_description = "Send notification on cache operation failure"
      alarm_action_arn = "arn:aws:sns:Publish"
      alarm_action_target_arn = aws_sns_topic.dataset_cache_events.arn
      alarm_action_message = "Dataset cache operation failed"
      alarm_action_subject = "Terradev Cache Alert"
    }
  ]
  
  tags = {
    Name        = "Terradev Dataset Cache Actions"
    Environment = "production"
    Purpose     = "notifications"
  }
}

# Cost optimization with lifecycle rules
resource "aws_s3_bucket_lifecycle_configuration" "cost_optimization" {
  bucket = aws_s3_bucket.us_east_1_cache.id
  rule {
    id     = "cost_optimization"
    status = "Enabled"
    filter  = "storage_class = 'STANDARD_IA'"
    transitions = [
      {
        days = 30
        storage_class = "STANDARD_IA"
        transition = "STANDARD"
      }
    ]
  }
  
  transition = {
    days    = 60
    storage_class = "STANDARD"
    transition = "STANDARD_IA"
  }
  
  transition = {
    days    = 90
    storage_class = "GLACIER"
    transition = "STANDARD"
  }
  
  transition = {
    days    = 180
    storage_class = "GLACIER"
    transition = "STANDARD"
  }
  
  transition = {
    days    = 365
    storage_class = "DEEP_ARCHIVE"
    transition = "STANDARD"
  }
  
  transition = {
    days    = 365
    storage_class = "DEEP_ARCHIVE"
    transition = "DEEP_ARCHIVE"
  }
  
  tags = {
    Name        = "Terradev Dataset Cache Cost Optimization"
    Environment = "production"
    Purpose     = "cost_optimization"
  }
}

# Data Transfer Acceleration
resource "aws_s3_bucket_accelerate_configuration" "transfer_acceleration" {
  bucket = aws_s3_bucket.us_east_1_cache.id
  status = "Enabled"
  
  acceleration_status = "Enabled"
  
  tags = {
    Name        = "Terradev Dataset Cache Transfer Acceleration"
    Environment = "production"
    Purpose     = "performance_optimization"
  }
}

# VPC Endpoints for private connectivity
resource "aws_vpc_endpoint" "s3_vpc_endpoint" {
  service_name = "com.amazonaws.s3"
  vpc_id       = aws_vpc.main.id
  
  tags = {
    Name        = "Terradev S3 VPC Endpoint"
    Environment = "production"
    Purpose     = "private_connectivity"
  }
}

resource "aws_vpc_endpoint" "gcs_vpc_endpoint" {
  service_name = "com.googleapis.cloudstorage"
  vpc_id       = aws_vpc.main.id
  
  tags = {
    Name        = "Terradev GCS VPC Endpoint"
    Environment = "usage"
    Purpose     = "private_connectivity"
  }
}

# Route for private connectivity
resource "aws_route" "s3_private_route" {
  route_table_id = aws_route_table.private_routing.id
  
  destination_prefix = "pl-"
  vpc_endpoint_id = aws_vpc_endpoint.s3_vpc_endpoint.id
  
  tags = {
    Name        = "Terradev S3 Private Route"
    Environment = "production"
    Purpose     = "private_connectivity"
  }
}

resource "aws_route" "gcs_private_route" {
  route_table_id = aws_route_table.private_routing.id
  
  destination_prefix = "pl-"
  vpc_endpoint_id = aws_vpc_endpoint.gcs_vpc_endpoint.id
  
  tags = {
    Name        = "Terradev GCS Private Route"
    Environment = "production"
    Purpose     = "private_connectivity"
  }
}

# Outputs
output "cache_strategy" {
  value = "Regional Object Storage Pattern"
  description = "Dataset caching strategy with zero-egress transfers"
}

output "key_benefits" {
  value = "10x faster dataset loading, 90% cost reduction"
  description = "Key benefits of regional caching strategy"
}

output "cleanup_policy" {
  value = "Automatic cleanup after 24 hours"
  description = "Automatic cleanup policy for expired caches"
}

output "aws_s3_bucket_us_east_1" {
  value = aws_s3_bucket.us_east_1.id
  description = "S3 bucket for US East 1 dataset cache"
}

output "aws_s3_bucket_us_west_2" {
  value = aws_s3_bucket.us_west_2.id
  description = "S3 bucket for US West 2 dataset cache"
}

output "aws_s3_bucket_eu_west_1" {
  value = aws_s3_bucket.eu_west_1.id
  description = "S3 bucket for EU West 1 dataset cache"
}

output "google_storage_bucket_us_central1" {
  value = google_storage_bucket.us_central1_cache.name
  description = "GCS bucket for US Central 1 dataset cache"
}

output "google_storage_bucket_us_west1" {
  value = google_storage_bucket.us_west1.name
  transfer_acceleration = google_storage_bucket.us_west1.storage_class
  description = "GCS bucket for US West 1 dataset cache"
}

output "google_storage_bucket_europe_west1" {
  value = google_storage_bucket.europe_west1.name
  description = "GCS bucket for Europe West 1 dataset cache"
}

output "azurerm_storage_account_dataset_cache" {
  value = azurerm_storage_account.dataset_cache.name
  description = "Azure Storage Account for dataset cache"
}

output "azurerm_storage_container_us_east_1" {
  value = azurerm_storage_container.us_east_1.name
  description = "Azure Container for US East 1 dataset cache"
}

output "azurerm_storage_container_west_us_2" {
  value = azurerm_storage_container.west_us_2.name
  description = "Azure Container for West US 2 dataset cache"
}

output "azurerm_storage_container_west_europe_1" {
  value = azurerm_storage_container.west_europe_1.name
  description = "Azure Container for West Europe 1 dataset cache"
}

output "lambda_function_dataset_cache" {
  value = aws_lambda_function.dataset_cache.arn
  description = "Lambda function for automatic cleanup"
}

output "sns_topic_dataset_cache_events" {
  value = aws_sns_topic.dataset_cache_events.arn
  description = "SNS topic for dataset cache events"
}

output "vpc_id" {
  value = aws_vpc.main.id
  description = "VPC ID for regional connectivity"
}

output "iam_role_dataset_cache" {
  value = aws_iam_role.dataset_cache.arn
  description = "IAM role for dataset cache operations"
}

output "iam_policy_dataset_cache" {
  value = aws_iam_policy.dataset_cache_policy.arn
  description = "IAM policy for dataset cache operations"
}

output "iam_instance_profile_dataset_cache_worker" {
  value = aws_iam_instance_profile.dataset_cache_worker.arn
  description = "IAM instance profile for dataset cache workers"
}

output "security_group_dataset_cache" {
  value = aws_security_group.dataset_cache_sg.id
  description = "Security group for dataset cache"
}

output "cloudwatch_log_group" {
  value = aws_cloudwatch_log_group.dataset_cache_logs.id
  description = "CloudWatch log group for dataset cache monitoring"
}

output "cloudwatch_log_stream" {
  value = aws_cloudwatch_log_stream.dataset_cache_operations.arn
  description = "CloudWatch log stream for dataset operations"
}

output "cloudwatch_metric_alarm_dataset_cache_size" {
  value = aws_cloudwatch_metric_alarm.dataset_cache_size_alarm.arn
  description = "CloudWatch alarm for cache size monitoring"
}

output "cloudwatch_metric_alarm_cache_operations" {
  value = aws_cloudwatch_metric_alarm.cache_operations_alarm.arn
  description = "CloudWatch alarm for cache operations monitoring"
}

output "cloudwatch_metric_alarm_cache_operations_actions" {
  value = aws_cloudwatch_metric_alarm.cache_operations_alarm_actions.arn
  description = "CloudWatch alarm actions for cache operations"
}

output "s3_vpc_endpoint" {
  value = aws_vpc_endpoint.s3_vpc_endpoint.id
  description = "VPC endpoint for S3 private connectivity"
}

output "gcs_vpc_endpoint" {
  value = aws_vpc_endpoint.gcs_vpc_endpoint.id
  description = "VPC endpoint for GCS private connectivity"
}

output "aws_s3_bucket_accelerate_configuration_us_east_1" {
  value = aws_s3_bucket_accelerate_configuration.transfer_acceleration.id
  description = "S3 Transfer Acceleration for US East 1"
}

output "aws_s3_bucket_accelerate_configuration_us_west_2" {
  value = aws_s3_bucket_accelerate_configuration.transfer_acceleration_west.id
  description = "S3 Transfer Acceleration for US West 2"
}

output "aws_s3_bucket_accelerate_configuration_eu_west_1" {
  value = aws_s3_bucket_accelerate_configuration.transfer_acceleration_eu.id
  description = "S3 Transfer Acceleration for EU West 1"
}

# Usage instructions
output "cache_strategy" {
  value = "Regional Object Storage Pattern"
  description = "Dataset caching strategy with zero-egress transfers"
}

output "key_benefits" {
  value = "10x faster dataset loading, 90% cost reduction"
  description = "Key benefits of regional caching strategy"
}

output "cleanup_policy" {
  value = "Automatic cleanup after 24 hours"
  description = "Automatic cleanup policy for expired caches"
}
