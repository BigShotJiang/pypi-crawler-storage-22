# GPU Price Arbitrage Module
# This module provides real-time GPU price comparison across multiple cloud providers
# Enhanced with smart financial insights for optimal deployment decisions

terraform {
  required_providers {
    http = {
      source  = "hashicorp/http"
      version = "~> 3.0"
    }
    local = {
      source  = "hashicorp/local"
      version = "~> 2.0"
    }
    external = {
      source  = "hashicorp/external"
      version = "~> 2.0"
    }
  }
}

# Data source for GPU pricing across all providers
data "http" "gpu_pricing" {
  for_each = toset(var.providers)
  
  url = "${var.pricing_apis[each.key].base_url}/${var.pricing_apis[each.key].endpoint}"
  
  request_headers = {
    Accept = "application/json"
    Authorization = each.key == "runpod" || each.key == "lambda" || each.key == "coreweave" ? "Bearer ${var.api_keys[each.key]}" : null
  }
  
  lifecycle {
    postcondition {
      condition     = self.status_code == 200
      error_message = "Failed to fetch GPU pricing from ${each.key}: ${self.status_code}"
    }
  }
}

# Enhanced financial insights via external script
data "external" "financial_insights" {
  count = var.enable_financial_insights ? 1 : 0
  
  program = ["python3", "${path.module}/../../scripts/arbitrage-engine.py"]
  
  query = {
    action = "financial_insights"
    gpu_types = join(",", var.gpu_types)
    providers = join(",", var.providers)
    confidence_threshold = var.confidence_threshold
    max_risk_score = var.max_risk_score
  }
}

# Parse and process pricing data
locals {
  gpu_pricing_data = {
    for provider in var.providers :
    provider => jsondecode(data.http.gpu_pricing[provider].response_body)
  }
  
  # Extract available GPU types and prices
  available_gpus = flatten([
    for provider, pricing in local.gpu_pricing_data : [
      for gpu_type in var.gpu_types : {
        provider = provider
        type     = gpu_type
        price    = try(pricing[gpu_type], null)
        region   = try(pricing.region, "us-west-2")
        spot     = try(pricing.spot_price, pricing.on_demand_price * 0.3)
        on_demand = try(pricing.on_demand_price, null)
      }
    ]
  ])
  
  # Filter out null prices and find cheapest options
  valid_gpus = [
    for gpu in local.available_gpus :
    gpu if gpu.price != null && gpu.spot != null
  ]
  
  # Group by GPU type and find cheapest provider
  cheapest_by_type = {
    for gpu_type in var.gpu_types :
    gpu_type => {
      cheapest = min([
        for gpu in local.valid_gpus :
        gpu if gpu.type == gpu_type
      ], gpu.spot)
      alternatives = [
        for gpu in local.valid_gpus :
        gpu if gpu.type == gpu_type && gpu.spot > gpu.cheapest.spot
      ]
    }
  }
  
  # Overall cheapest GPU
  overall_cheapest = min(local.valid_gpus, gpu.spot)
  
  # Enhanced financial insights
  financial_data = var.enable_financial_insights ? data.external.financial_insights[0].result : {}
  
  # Arbitrage confidence score
  arbitrage_confidence = var.enable_financial_insights ? 
    try(local.financial_data.arbitrage_confidence, 0.8) : 0.8
  
  # Risk assessment
  risk_score = var.enable_financial_insights ? 
    try(local.financial_data.risk_score, 0.3) : 0.3
  
  # Market efficiency
  market_efficiency = var.enable_financial_insights ? 
    try(local.financial_data.market_efficiency, 0.75) : 0.75
  
  # Optimal timing recommendation
  optimal_timing = var.enable_financial_insights ? 
    try(local.financial_data.optimal_timing, "now") : "now"
  
  # Price stability score
  price_stability = var.enable_financial_insights ? 
    try(local.financial_data.price_stability, 0.8) : 0.8
}

# Decision logic: Should we deploy now?
locals {
  # Check if we meet confidence threshold
  meets_confidence = local.arbitrage_confidence >= var.confidence_threshold
  
  # Check if we meet risk tolerance
  within_risk_tolerance = local.risk_score <= var.max_risk_score
  
  # Check if timing is optimal
  timing_is_optimal = local.optimal_timing == "now"
  
  # Final deployment decision
  should_deploy = local.meets_confidence && local.within_risk_tolerance && local.timing_is_optimal
  
  # Deployment message
  deployment_message = local.should_deploy ? 
    "Optimal conditions met - deploying now" : 
    "Waiting for better conditions - ${local.optimal_timing}"
}

# Output cheapest GPU configuration with financial insights
resource "local_file" "cheapest_gpu_config" {
  filename = "${path.module}/cheapest_gpu.json"
  content  = jsonencode({
    timestamp = timestamp()
    cheapest_gpu = local.overall_cheapest
    all_options = local.valid_gpus
    recommendations = {
      for gpu_type, data in local.cheapest_by_type :
      gpu_type => {
        provider = data.cheapest.provider
        price    = data.cheapest.spot
        savings  = data.cheapest.on_demand > 0 ? 
                  round((data.cheapest.on_demand - data.cheapest.spot) / data.cheapest.on_demand * 100, 1) : null
      }
    }
    # Enhanced financial insights
    financial_insights = {
      arbitrage_confidence = local.arbitrage_confidence
      risk_score = local.risk_score
      market_efficiency = local.market_efficiency
      optimal_timing = local.optimal_timing
      price_stability = local.price_stability
      should_deploy = local.should_deploy
      deployment_message = local.deployment_message
    }
  })
}

# Usage tracking for freemium tier
resource "local_file" "usage_tracker" {
  filename = "${path.module}/usage.json"
  content  = jsonencode({
    user_id     = var.user_id
    tier        = var.tier
    gpu_hours_used = var.gpu_hours_used
    monthly_limit = var.monthly_gpu_hours_limit
    last_updated = timestamp()
    can_deploy   = var.tier == "freemium" ? var.gpu_hours_used < var.monthly_gpu_hours_limit : true
    # Enhanced with financial context
    financial_context = {
      confidence_threshold = var.confidence_threshold
      max_risk_score = var.max_risk_score
      enable_financial_insights = var.enable_financial_insights
    }
  })
}

# Cost estimation with enhanced metrics
locals {
  cost_estimate = {
    for gpu in local.valid_gpus :
    "${gpu.provider}-${gpu.type}" => {
      hourly_cost_spot    = gpu.spot
      hourly_cost_ondemand = gpu.on_demand
      monthly_cost_spot    = gpu.spot * 24 * 30
      monthly_cost_ondemand = gpu.on_demand * 24 * 30
      potential_savings    = gpu.on_demand > 0 ? 
                            round((gpu.on_demand - gpu.spot) / gpu.on_demand * 100, 1) : 0
      # Enhanced metrics
      risk_adjusted_savings = gpu.on_demand > 0 ? 
                            round((gpu.on_demand - gpu.spot) / gpu.on_demand * 100 * (1 - local.risk_score), 1) : 0
      confidence_weighted_savings = gpu.on_demand > 0 ? 
                                  round((gpu.on_demand - gpu.spot) / gpu.on_demand * 100 * local.arbitrage_confidence, 1) : 0
    }
  }
  
  # Best GPU based on financial metrics
  best_gpu_by_savings = local.overall_cheapest
  best_gpu_by_risk_adjusted = min([
    for gpu in local.valid_gpus :
    gpu if (gpu.on_demand - gpu.spot) / gpu.on_demand * (1 - local.risk_score) > 0
  ], gpu.spot)
  best_gpu_by_confidence = local.should_deploy ? local.overall_cheapest : null
}

# Conditional deployment based on financial insights
resource "null_resource" "gpu_deployment" {
  count = local.should_deploy ? 1 : 0
  
  triggers = {
    gpu_type = local.overall_cheapest.type
    provider = local.overall_cheapest.provider
    price = local.overall_cheapest.spot
    confidence = local.arbitrage_confidence
    timestamp = timestamp()
  }
  
  provisioner "local-exec" {
    command = "echo 'Deploying ${local.overall_cheapest.type} on ${local.overall_cheapest.provider} at $${local.overall_cheapest.spot}/hour with ${local.arbitrage_confidence}% confidence'"
  }
}

# Alert for non-optimal conditions
resource "null_resource" "wait_alert" {
  count = local.should_deploy ? 0 : 1
  
  triggers = {
    message = local.deployment_message
    confidence = local.arbitrage_confidence
    risk_score = local.risk_score
    timing = local.optimal_timing
  }
  
  provisioner "local-exec" {
    command = "echo 'Waiting for optimal conditions: ${local.deployment_message}'"
  }
}
