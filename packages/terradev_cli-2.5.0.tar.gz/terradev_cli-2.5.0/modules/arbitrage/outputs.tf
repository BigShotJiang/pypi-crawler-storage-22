output "cheapest_gpu" {
  description = "Overall cheapest GPU configuration across all providers"
  value = {
    provider = local.overall_cheapest.provider
    type     = local.overall_cheapest.type
    price    = local.overall_cheapest.spot
    region   = local.overall_cheapest.region
    savings  = local.overall_cheapest.on_demand > 0 ? 
              round((local.overall_cheapest.on_demand - local.overall_cheapest.spot) / local.overall_cheapest.on_demand * 100, 1) : null
  }
}

output "gpu_recommendations" {
  description = "GPU recommendations by type showing cheapest options"
  value = {
    for gpu_type, data in local.cheapest_by_type :
    gpu_type => {
      provider    = data.cheapest.provider
      price       = data.cheapest.spot
      region      = data.cheapest.region
      savings_pct = data.cheapest.on_demand > 0 ? 
                   round((data.cheapest.on_demand - data.cheapest.spot) / data.cheapest.on_demand * 100, 1) : null
      alternatives = length(data.alternatives) > 0 ? [
        for alt in data.alternatives : {
          provider = alt.provider
          price    = alt.spot
          region   = alt.region
        }
      ] : []
    }
  }
}

output "all_available_gpus" {
  description = "All available GPU options across providers"
  value = local.valid_gpus
}

output "cost_estimates" {
  description = "Cost estimates for all GPU configurations"
  value = local.cost_estimate
}

output "usage_status" {
  description = "Current usage status and limits"
  value = {
    tier              = var.tier
    gpu_hours_used    = var.gpu_hours_used
    monthly_limit     = var.monthly_gpu_hours_limit
    hours_remaining   = var.tier == "freemium" ? max(0, var.monthly_gpu_hours_limit - var.gpu_hours_used) : null
    can_deploy        = var.tier == "freemium" ? var.gpu_hours_used < var.monthly_gpu_hours_limit : true
    usage_percentage  = var.tier == "freemium" ? round(var.gpu_hours_used / var.monthly_gpu_hours_limit * 100, 1) : null
  }
}

output "spot_savings_analysis" {
  description = "Analysis of spot vs on-demand savings"
  value = {
    for gpu in local.valid_gpus :
    "${gpu.provider}-${gpu.type}" => {
      spot_price       = gpu.spot
      on_demand_price = gpu.on_demand
      hourly_savings   = gpu.on_demand > 0 ? gpu.on_demand - gpu.spot : null
      monthly_savings  = gpu.on_demand > 0 ? (gpu.on_demand - gpu.spot) * 24 * 30 : null
      savings_pct     = gpu.on_demand > 0 ? round((gpu.on_demand - gpu.spot) / gpu.on_demand * 100, 1) : null
    }
  }
}

# Enhanced financial insights outputs
output "financial_insights" {
  description = "Advanced financial insights and risk assessment"
  value = {
    arbitrage_confidence = local.arbitrage_confidence
    risk_score = local.risk_score
    market_efficiency = local.market_efficiency
    optimal_timing = local.optimal_timing
    price_stability = local.price_stability
    should_deploy = local.should_deploy
    deployment_message = local.deployment_message
  }
}

output "deployment_decision" {
  description = "Final deployment decision based on financial analysis"
  value = {
    deploy = local.should_deploy
    confidence = local.arbitrage_confidence
    risk_acceptable = local.within_risk_tolerance
    timing_optimal = local.timing_is_optimal
    message = local.deployment_message
    recommended_gpu = local.should_deploy ? local.overall_cheapest : null
  }
}

output "enhanced_cost_analysis" {
  description = "Enhanced cost analysis with risk-adjusted metrics"
  value = {
    for gpu in local.valid_gpus :
    "${gpu.provider}-${gpu.type}" => {
      spot_price = gpu.spot
      on_demand_price = gpu.on_demand
      potential_savings = gpu.on_demand > 0 ? round((gpu.on_demand - gpu.spot) / gpu.on_demand * 100, 1) : 0
      risk_adjusted_savings = gpu.on_demand > 0 ? 
        round((gpu.on_demand - gpu.spot) / gpu.on_demand * 100 * (1 - local.risk_score), 1) : 0
      confidence_weighted_savings = gpu.on_demand > 0 ? 
        round((gpu.on_demand - gpu.spot) / gpu.on_demand * 100 * local.arbitrage_confidence, 1) : 0
      risk_score = local.risk_score
      confidence_score = local.arbitrage_confidence
    }
  }
}

output "market_intelligence" {
  description = "Market intelligence and efficiency metrics"
  value = {
    market_efficiency = local.market_efficiency
    price_stability = local.price_stability
    optimal_timing = local.optimal_timing
    total_providers = length(var.providers)
    available_gpu_types = length(local.valid_gpus)
    price_volatility = local.price_stability < 0.7 ? "high" : local.price_stability < 0.9 ? "medium" : "low"
    market_state = local.market_efficiency > 0.8 ? "efficient" : local.market_efficiency > 0.6 ? "moderate" : "inefficient"
  }
}
