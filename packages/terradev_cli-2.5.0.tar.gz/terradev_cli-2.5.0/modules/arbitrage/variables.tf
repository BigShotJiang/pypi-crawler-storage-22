variable "providers" {
  description = "List of cloud providers to query for GPU pricing"
  type        = list(string)
  default     = ["aws", "gcp", "azure", "runpod", "lambda", "coreweave"]
}

variable "gpu_types" {
  description = "GPU types to search for"
  type        = list(string)
  default     = ["a100", "h100", "a10g", "rtx4090", "rtx3090"]
}

variable "pricing_apis" {
  description = "API endpoints for each provider's pricing data"
  type = map(object({
    base_url = string
    endpoint = string
  }))
  default = {
    aws = {
      base_url = "https://pricing.us-east-1.amazonaws.com"
      endpoint = "offers/v1.0/aws/AmazonEC2/current/index.json"
    }
    gcp = {
      base_url = "https://cloudbilling.googleapis.com"
      endpoint = "v1/services/6F81-5844-456A/skus"
    }
    azure = {
      base_url = "https://prices.azure.com"
      endpoint = "api/retail/prices"
    }
    runpod = {
      base_url = "https://api.runpod.io"
      endpoint = "v1/gpu/pricing"
    }
    lambda = {
      base_url = "https://api.labs.lambda.cloud"
      endpoint = "v1/gpu/pricing"
    }
    coreweave = {
      base_url = "https://api.coreweave.com"
      endpoint = "v1/gpu/pricing"
    }
  }
}

variable "api_keys" {
  description = "API keys for providers that require authentication"
  type        = map(string)
  default     = {}
  sensitive   = true
}

variable "user_id" {
  description = "Unique identifier for the user"
  type        = string
}

variable "tier" {
  description = "User subscription tier (freemium or paid)"
  type        = string
  default     = "freemium"
  
  validation {
    condition     = contains(["freemium", "paid"], var.tier)
    error_message = "Tier must be either 'freemium' or 'paid'."
  }
}

variable "gpu_hours_used" {
  description = "Current GPU hours used in the current billing cycle"
  type        = number
  default     = 0
}

variable "monthly_gpu_hours_limit" {
  description = "Monthly GPU hours limit for the user's tier"
  type        = number
  default     = 10
}

variable "preferred_regions" {
  description = "Preferred regions for GPU deployment"
  type        = list(string)
  default     = ["us-west-2", "us-east-1", "europe-west1"]
}

variable "spot_only" {
  description = "Whether to only consider spot instances for cost savings"
  type        = bool
  default     = true
}

variable "max_price_per_hour" {
  description = "Maximum price per hour willing to pay"
  type        = number
  default     = 10.0
}

# Enhanced financial insights variables
variable "enable_financial_insights" {
  description = "Enable advanced financial insights and risk assessment"
  type        = bool
  default     = true
}

variable "confidence_threshold" {
  description = "Minimum confidence threshold for deployment (0.0-1.0)"
  type        = number
  default     = 0.7
  
  validation {
    condition     = var.confidence_threshold >= 0.0 && var.confidence_threshold <= 1.0
    error_message = "Confidence threshold must be between 0.0 and 1.0."
  }
}

variable "max_risk_score" {
  description = "Maximum acceptable risk score (0.0-1.0, where 0 is lowest risk)"
  type        = number
  default     = 0.5
  
  validation {
    condition     = var.max_risk_score >= 0.0 && var.max_risk_score <= 1.0
    error_message = "Risk score must be between 0.0 and 1.0."
  }
}

variable "enable_price_prediction" {
  description = "Enable price movement prediction for optimal timing"
  type        = bool
  default     = true
}

variable "enable_market_analysis" {
  description = "Enable market efficiency and volatility analysis"
  type        = bool
  default     = true
}

variable "risk_tolerance" {
  description = "Risk tolerance level (conservative, moderate, aggressive)"
  type        = string
  default     = "moderate"
  
  validation {
    condition     = contains(["conservative", "moderate", "aggressive"], var.risk_tolerance)
    error_message = "Risk tolerance must be one of: conservative, moderate, aggressive."
  }
}
