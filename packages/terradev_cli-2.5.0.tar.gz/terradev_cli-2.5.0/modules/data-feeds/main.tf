# Data Feed Integration Module

# S3 Bucket for data feed storage
resource "aws_s3_bucket" "data_feed_bucket" {
  bucket = "${var.name_prefix}-data-feeds-${random_id.bucket_suffix.hex}"

  tags = merge(
    var.tags,
    {
      Name = "${var.name_prefix}-data-feeds"
      Type = "Data-Storage"
    }
  )
}

resource "random_id" "bucket_suffix" {
  byte_length = 4
}

# S3 Bucket versioning
resource "aws_s3_bucket_versioning" "data_feed_versioning" {
  bucket = aws_s3_bucket.data_feed_bucket.id
  versioning_configuration {
    status = "Enabled"
  }
}

# S3 Bucket encryption
resource "aws_s3_bucket_server_side_encryption_configuration" "data_feed_encryption" {
  bucket = aws_s3_bucket.data_feed_bucket.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

# S3 Bucket public access block
resource "aws_s3_bucket_public_access_block" "data_feed_pab" {
  bucket = aws_s3_bucket.data_feed_bucket.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# Lambda function for data feed processing
resource "aws_lambda_function" "data_processor" {
  count = var.enable_processing ? 1 : 0

  function_name = "${var.name_prefix}-data-processor"
  role          = aws_iam_role.lambda_role.arn
  handler       = "data_processor.lambda_handler"
  runtime       = "python3.9"

  filename = "data_processor.zip"

  environment {
    variables = {
      S3_BUCKET = aws_s3_bucket.data_feed_bucket.id
      DATA_FEEDS = jsonencode(var.data_feeds)
    }
  }

  tags = merge(
    var.tags,
    {
      Name = "${var.name_prefix}-data-processor"
      Type = "Data-Processing"
    }
  )
}

# IAM Role for Lambda function
resource "aws_iam_role" "lambda_role" {
  name = "${var.name_prefix}-lambda-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "lambda.amazonaws.com"
        }
      }
    ]
  })

  tags = var.tags
}

# IAM Policy for Lambda function
resource "aws_iam_role_policy" "lambda_policy" {
  name = "${var.name_prefix}-lambda-policy"
  role = aws_iam_role.lambda_role.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "logs:CreateLogGroup",
          "logs:CreateLogStream",
          "logs:PutLogEvents"
        ]
        Resource = "arn:aws:logs:*:*:*"
      },
      {
        Effect = "Allow"
        Action = [
          "s3:GetObject",
          "s3:PutObject",
          "s3:ListBucket"
        ]
        Resource = [
          aws_s3_bucket.data_feed_bucket.arn,
          "${aws_s3_bucket.data_feed_bucket.arn}/*"
        ]
      }
    ]
  })
}

# EventBridge Rule for scheduled data feed updates
resource "aws_cloudwatch_event_rule" "data_feed_schedule" {
  count = length(var.data_feeds) > 0 ? 1 : 0

  name                = "${var.name_prefix}-data-feed-schedule"
  description         = "Trigger data feed updates on schedule"
  schedule_expression = var.schedule_expression

  tags = var.tags
}

# EventBridge Target for Lambda function
resource "aws_cloudwatch_event_target" "lambda_target" {
  count = var.enable_processing && length(var.data_feeds) > 0 ? 1 : 0

  rule      = aws_cloudwatch_event_rule.data_feed_schedule[0].name
  target_id = "DataProcessorLambda"
  arn       = aws_lambda_function.data_processor[0].arn
}

# Lambda Permission for EventBridge
resource "aws_lambda_permission" "allow_eventbridge" {
  count = var.enable_processing && length(var.data_feeds) > 0 ? 1 : 0

  statement_id  = "AllowExecutionFromEventBridge"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.data_processor[0].function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.data_feed_schedule[0].arn
}

# API Gateway for data feed endpoints
resource "aws_api_gateway_rest_api" "data_feed_api" {
  count = var.enable_api ? 1 : 0

  name        = "${var.name_prefix}-data-feed-api"
  description = "API for accessing data feeds"

  tags = var.tags
}

# API Gateway Resource
resource "aws_api_gateway_resource" "data_feed_resource" {
  count = var.enable_api ? 1 : 0

  rest_api_id = aws_api_gateway_rest_api.data_feed_api[0].id
  parent_id   = aws_api_gateway_rest_api.data_feed_api[0].root_resource_id
  path_part   = "feeds"
}

# API Gateway Method
resource "aws_api_gateway_method" "data_feed_method" {
  count = var.enable_api ? 1 : 0

  rest_api_id   = aws_api_gateway_rest_api.data_feed_api[0].id
  resource_id   = aws_api_gateway_resource.data_feed_resource[0].id
  http_method   = "GET"
  authorization = "NONE"
}

# API Gateway Integration
resource "aws_api_gateway_integration" "data_feed_integration" {
  count = var.enable_api ? 1 : 0

  rest_api_id = aws_api_gateway_rest_api.data_feed_api[0].id
  resource_id = aws_api_gateway_resource.data_feed_resource[0].id
  http_method = aws_api_gateway_method.data_feed_method[0].http_method

  type                    = "MOCK"
  request_templates = {
    "application/json" = jsonencode({
      feeds = var.data_feeds
    })
  }
}

# API Gateway Deployment
resource "aws_api_gateway_deployment" "data_feed_deployment" {
  count = var.enable_api ? 1 : 0

  rest_api_id = aws_api_gateway_rest_api.data_feed_api[0].id

  triggers = {
    redeployment = sha1(jsonencode([
      aws_api_gateway_resource.data_feed_resource[0].id,
      aws_api_gateway_method.data_feed_method[0].http_method,
      aws_api_gateway_integration.data_feed_integration[0].uri
    ]))
  }

  lifecycle {
    create_before_destroy = true
  }
}

# API Gateway Stage
resource "aws_api_gateway_stage" "data_feed_stage" {
  count = var.enable_api ? 1 : 0

  deployment_id = aws_api_gateway_deployment.data_feed_deployment[0].id
  rest_api_id   = aws_api_gateway_rest_api.data_feed_api[0].id
  stage_name    = var.environment

  tags = var.tags
}
