output "bucket_name" {
  description = "Name of the S3 bucket for data feeds"
  value       = aws_s3_bucket.data_feed_bucket.id
}

output "bucket_arn" {
  description = "ARN of the S3 bucket for data feeds"
  value       = aws_s3_bucket.data_feed_bucket.arn
}

output "feed_endpoints" {
  description = "List of configured data feed endpoints"
  value = {
    for feed in var.data_feeds : feed.name => {
      type       = feed.type
      source_url = feed.source_url
      enabled    = feed.enabled
      s3_path    = "s3://${aws_s3_bucket.data_feed_bucket.id}/${feed.name}/"
    }
  }
}

output "lambda_function_name" {
  description = "Name of the data processing Lambda function"
  value       = var.enable_processing ? aws_lambda_function.data_processor[0].function_name : null
}

output "lambda_function_arn" {
  description = "ARN of the data processing Lambda function"
  value       = var.enable_processing ? aws_lambda_function.data_processor[0].arn : null
}

output "api_gateway_url" {
  description = "URL of the API Gateway endpoint"
  value       = var.enable_api ? "${aws_api_gateway_deployment.data_feed_deployment[0].invoke_url}/${aws_api_gateway_stage.data_feed_stage[0].stage_name}/feeds" : null
}

output "event_rule_arn" {
  description = "ARN of the EventBridge rule for scheduled updates"
  value       = length(var.data_feeds) > 0 ? aws_cloudwatch_event_rule.data_feed_schedule[0].arn : null
}

output "iam_role_arn" {
  description = "ARN of the IAM role for Lambda function"
  value       = aws_iam_role.lambda_role.arn
}
