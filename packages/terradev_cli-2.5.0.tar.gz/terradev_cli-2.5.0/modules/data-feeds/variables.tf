variable "name_prefix" {
  description = "Prefix for resource names"
  type        = string
}

variable "environment" {
  description = "Environment name"
  type        = string
  default     = "dev"
}

variable "data_feeds" {
  description = "List of data feed configurations"
  type = list(object({
    name        = string
    type        = string
    source_url  = string
    update_freq = string
    enabled     = bool
    format      = optional(string, "json")
    compression = optional(bool, false)
  }))
  default = []
}

variable "schedule_expression" {
  description = "Cron expression for data feed updates"
  type        = string
  default     = "rate(6 hours)"
}

variable "enable_processing" {
  description = "Enable Lambda data processing"
  type        = bool
  default     = true
}

variable "enable_api" {
  description = "Enable API Gateway for data feed access"
  type        = bool
  default     = true
}

variable "tags" {
  description = "Tags to apply to all resources"
  type        = map(string)
  default     = {}
}

variable "lambda_timeout" {
  description = "Lambda function timeout in seconds"
  type        = number
  default     = 300
}

variable "lambda_memory" {
  description = "Lambda function memory in MB"
  type        = number
  default     = 512
}

variable "retention_days" {
  description = "CloudWatch logs retention in days"
  type        = number
  default     = 14
}
