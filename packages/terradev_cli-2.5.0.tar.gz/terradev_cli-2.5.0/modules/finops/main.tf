terraform {
  required_version = ">= 1.0"
  required_providers {
    random = {
      source  = "hashicorp/random"
      version = "~> 3.1"
    }
    external = {
      source  = "hashicorp/external"
      version = "~> 2.1"
    }
    http = {
      source  = "hashicorp/http"
      version = "~> 3.1"
    }
    local = {
      source  = "hashicorp/local"
      version = "~> 2.1"
    }
  }
}

# Token-based unified billing system
locals {
  # Token economics - optimized for conversion and retention
  free_tier_tokens = var.free_tier_tokens  # Default: 1000 tokens
  token_value_usd = var.token_value_usd    # Default: $0.01 per token
  
  # Token consumption rates by workload type
  token_consumption_rates = {
    "inference_request" = 1      # 1 token per inference request
    "training_hour"     = 100    # 100 tokens per GPU training hour
    "api_call"          = 0.1    # 0.1 tokens per API call
    "storage_gb_month"  = 10     # 10 tokens per GB-month storage
    "network_gb"        = 5      # 5 tokens per GB data transfer
  }
  
  # Provider-specific token multipliers (for arbitrage incentives)
  provider_multipliers = {
    "aws"       = 1.0
    "azure"     = 0.95  # 5% bonus for Azure
    "gcp"       = 0.90  # 10% bonus for GCP
    "runpod"    = 0.85  # 15% bonus for RunPod
    "lambda"    = 0.80  # 20% bonus for Lambda Labs
    "coreweave" = 0.75  # 25% bonus for CoreWeave
  }
  
  # Calculate optimal free token allocation
  optimal_free_tokens = ceil(
    # Average user needs 50 inference requests + 2 training hours per month
    (50 * local.token_consumption_rates["inference_request"]) +
    (2 * local.token_consumption_rates["training_hour"]) +
    # Plus buffer for API calls and data transfer
    (100 * local.token_consumption_rates["api_call"]) +
    (10 * local.token_consumption_rates["network_gb"])
  )
  
  # Conversion optimization metrics
  target_conversion_rate = 0.15    # 15% free to paid conversion
  avg_monthly_paid_tokens = 5000  # Average paid user consumption
  
  # Revenue projections
  monthly_revenue_per_paid_user = local.avg_monthly_paid_tokens * local.token_value_usd
  ltv_cac_ratio = 3.0  # Lifetime Value to Customer Acquisition Cost ratio
}

# Token account management
resource "random_id" "token_account" {
  count = var.num_token_accounts
  byte_length = 16
  
  keepers = {
    user_id = element(var.user_ids, count.index)
  }
}

# Token balance tracking
resource "local_file" "token_balances" {
  filename = "${path.module}/token_balances.json"
  
  content = jsonencode({
    token_accounts = [
      for i, account_id in random_id.token_account[*].hex :
      {
        account_id     = account_id
        user_id        = element(var.user_ids, i)
        balance        = var.initial_token_balance
        tier           = var.token_tier
        created_at     = timestamp()
        last_activity  = timestamp()
        consumption    = {}
        attribution    = {}
      }
    ]
    token_economics = {
      free_tier_tokens    = local.optimal_free_tokens
      token_value_usd     = local.token_value_usd
      consumption_rates   = local.token_consumption_rates
      provider_multipliers = local.provider_multipliers
    }
    billing_metrics = {
      target_conversion_rate     = local.target_conversion_rate
      avg_monthly_paid_tokens    = local.avg_monthly_paid_tokens
      monthly_revenue_per_user  = local.monthly_revenue_per_paid_user
      ltv_cac_ratio            = local.ltv_cac_ratio
    }
  })
}

# Token consumption calculator
data "external" "calculate_token_consumption" {
  for_each = var.token_consumption_events
  
  program = ["python3", "${path.module}/scripts/token_calculator.py"]
  
  query = {
    event_type       = each.value.event_type
    quantity         = each.value.quantity
    provider         = each.value.provider
    account_id       = each.value.account_id
    token_rates      = jsonencode(local.token_consumption_rates)
    multipliers      = jsonencode(local.provider_multipliers)
  }
}

# Token balance updates
resource "local_file" "updated_balances" {
  for_each = data.external.calculate_token_consumption
  
  filename = "${path.module}/balance_updates/${each.key}.json"
  
  content = jsonencode({
    account_id    = each.value.account_id
    tokens_consumed = each.value.tokens_consumed
    new_balance    = each.value.new_balance
    event_metadata = each.value.event_metadata
    timestamp      = timestamp()
  })
  
  depends_on = [local_file.token_balances]
}

# Unified billing aggregation
data "external" "unified_billing" {
  depends_on = [local_file.updated_balances]
  
  program = ["python3", "${path.module}/scripts/unified_billing.py"]
  
  query = {
    billing_period    = var.billing_period
    token_value_usd   = local.token_value_usd
    provider_rates    = jsonencode(var.provider_hourly_rates)
    accounts_file     = local_file.token_balances.filename
    updates_dir       = "${path.module}/balance_updates"
  }
}

# Billing reports
resource "local_file" "billing_report" {
  filename = "${path.module}/billing_reports/${data.external.unified_billing.result["billing_period"]}.json"
  
  content = jsonencode({
    billing_period      = data.external.unified_billing.result["billing_period"]
    total_tokens_consumed = tonumber(data.external.unified_billing.result["total_tokens_consumed"])
    total_revenue_usd   = tonumber(data.external.unified_billing.result["total_revenue_usd"])
    active_accounts     = jsondecode(data.external.unified_billing.result["active_accounts"])
    provider_breakdown  = jsondecode(data.external.unified_billing.result["provider_breakdown"])
    tier_breakdown      = jsondecode(data.external.unified_billing.result["tier_breakdown"])
    conversion_metrics  = jsondecode(data.external.unified_billing.result["conversion_metrics"])
    cost_attribution    = jsondecode(data.external.unified_billing.result["cost_attribution"])
    generated_at        = timestamp()
  })
}

# Token tier management
resource "random_pet" "tier_upgrades" {
  count = length(var.tier_upgrade_requests)
  
  keepers = {
    account_id = element(var.tier_upgrade_requests, count.index).account_id
    requested_tier = element(var.tier_upgrade_requests, count.index).requested_tier
  }
}

# Tier upgrade processing
data "external" "process_tier_upgrade" {
  for_each = random_pet.tier_upgrades
  
  program = ["python3", "${path.module}/scripts/tier_manager.py"]
  
  query = {
    account_id      = element(var.tier_upgrade_requests, each.key).account_id
    current_tier    = element(var.tier_upgrade_requests, each.key).current_tier
    requested_tier  = element(var.tier_upgrade_requests, each.key).requested_tier
    current_balance = element(var.tier_upgrade_requests, each.key).current_balance
    upgrade_criteria = jsonencode(var.tier_upgrade_criteria)
  }
}

# Cost attribution engine
data "external" "cost_attribution" {
  depends_on = [local_file.billing_report]
  
  program = ["python3", "${path.module}/scripts/cost_attribution.py"]
  
  query = {
    billing_report_file = local_file.billing_report.filename
    attribution_rules   = jsonencode(var.cost_attribution_rules)
    team_hierarchy      = jsonencode(var.team_hierarchy)
  }
}

# Attribution reports
resource "local_file" "attribution_report" {
  filename = "${path.module}/attribution_reports/${data.external.cost_attribution.result["report_id"]}.json"
  
  content = jsonencode({
    report_id         = data.external.cost_attribution.result["report_id"]
    attribution_data  = jsondecode(data.external.cost_attribution.result["attribution_data"])
    team_costs        = jsondecode(data.external.cost_attribution.result["team_costs"])
    project_costs     = jsondecode(data.external.cost_attribution.result["project_costs"])
    business_unit_costs = jsondecode(data.external.cost_attribution.result["business_unit_costs"])
    unattributed_costs = jsondecode(data.external.cost_attribution.result["unattributed_costs"])
    generated_at      = timestamp()
  })
}

# Budget monitoring and alerts
data "external" "budget_monitoring" {
  depends_on = [local_file.attribution_report]
  
  program = ["python3", "${path.module}/scripts/budget_monitor.py"]
  
  query = {
    attribution_report_file = local_file.attribution_report.filename
    budget_limits          = jsonencode(var.budget_limits)
    alert_thresholds       = jsonencode(var.alert_thresholds)
  }
}

# Alert notifications
resource "local_file" "budget_alerts" {
  for_each = toset(jsondecode(data.external.budget_monitoring.result["alerts"]))
  
  filename = "${path.module}/alerts/${each.value}.json"
  
  content = jsonencode({
    alert_id       = each.value
    alert_type     = jsondecode(data.external.budget_monitoring.result["alert_details"])[each.value].alert_type
    cost_center    = jsondecode(data.external.budget_monitoring.result["alert_details"])[each.value].cost_center
    current_spend  = jsondecode(data.external.budget_monitoring.result["alert_details"])[each.value].current_spend
    budget_limit   = jsondecode(data.external.budget_monitoring.result["alert_details"])[each.value].budget_limit
    percentage_used = jsondecode(data.external.budget_monitoring.result["alert_details"])[each.value].percentage_used
    message        = jsondecode(data.external.budget_monitoring.result["alert_details"])[each.value].message
    recipients     = jsondecode(data.external.budget_monitoring.result["alert_details"])[each.value].recipients
    triggered_at   = timestamp()
  })
}

# Token economics optimization
data "external" "optimize_token_economics" {
  depends_on = [local_file.billing_report]
  
  program = ["python3", "${path.module}/scripts/token_optimizer.py"]
  
  query = {
    current_free_tokens    = local.optimal_free_tokens
    current_token_value    = local.token_value_usd
    conversion_rate        = local.target_conversion_rate
    billing_data          = local_file.billing_report.filename
    market_data           = jsonencode(var.market_competitor_data)
  }
}

# Optimization recommendations
resource "local_file" "optimization_report" {
  filename = "${path.module}/optimization_reports/${timestamp()}.json"
  
  content = jsonencode({
    optimization_id    = data.external.optimize_token_economics.result["optimization_id"]
    current_economics  = jsondecode(data.external.optimize_token_economics.result["current_economics"])
    recommended_economics = jsondecode(data.external.optimize_token_economics.result["recommended_economics"])
    projected_impact   = jsondecode(data.external.optimize_token_economics.result["projected_impact"])
    implementation_plan = jsondecode(data.external.optimize_token_economics.result["implementation_plan"])
    confidence_score   = tonumber(data.external.optimize_token_economics.result["confidence_score"])
    generated_at       = timestamp()
  })
}
