output "token_economics_summary" {
  description = "Summary of token economics and optimal configuration"
  value = {
    optimal_free_tokens = local.optimal_free_tokens
    token_value_usd = local.token_value_usd
    conversion_metrics = {
      target_conversion_rate = local.target_conversion_rate
      avg_monthly_paid_tokens = local.avg_monthly_paid_tokens
      monthly_revenue_per_paid_user = local.monthly_revenue_per_paid_user
      ltv_cac_ratio = local.ltv_cac_ratio
    }
    consumption_rates = local.token_consumption_rates
    provider_multipliers = local.provider_multipliers
  }
}

output "token_accounts_created" {
  description = "List of created token accounts"
  value = [
    for i, account_id in random_id.token_account[*].hex : {
      account_id = account_id
      user_id = element(var.user_ids, i)
      initial_balance = var.initial_token_balance
      tier = var.token_tier
      created_at = timestamp()
    }
  ]
}

output "billing_summary" {
  description = "Unified billing summary for the period"
  value = {
    billing_period = data.external.unified_billing.result["billing_period"]
    total_tokens_consumed = tonumber(data.external.unified_billing.result["total_tokens_consumed"])
    total_revenue_usd = tonumber(data.external.unified_billing.result["total_revenue_usd"])
    active_accounts = jsondecode(data.external.unified_billing.result["active_accounts"])
    provider_breakdown = jsondecode(data.external.unified_billing.result["provider_breakdown"])
    tier_breakdown = jsondecode(data.external.unified_billing.result["tier_breakdown"])
    conversion_metrics = jsondecode(data.external.unified_billing.result["conversion_metrics"])
  }
  depends_on = [local_file.billing_report]
}

output "cost_attribution_summary" {
  description = "Cost attribution summary by organizational units"
  value = {
    report_id = data.external.cost_attribution.result["report_id"]
    total_attributed_costs = jsondecode(data.external.cost_attribution.result["total_attributed_costs"])
    team_costs = jsondecode(data.external.cost_attribution.result["team_costs"])
    project_costs = jsondecode(data.external.cost_attribution.result["project_costs"])
    business_unit_costs = jsondecode(data.external.cost_attribution.result["business_unit_costs"])
    attribution_coverage = jsondecode(data.external.cost_attribution.result["attribution_coverage"])
    unattributed_percentage = jsondecode(data.external.cost_attribution.result["unattributed_percentage"])
  }
  depends_on = [local_file.attribution_report]
}

output "budget_alerts_summary" {
  description = "Summary of budget alerts triggered"
  value = {
    total_alerts = length(jsondecode(data.external.budget_monitoring.result["alerts"]))
    alert_types = jsondecode(data.external.budget_monitoring.result["alert_types"])
    cost_centers_with_alerts = jsondecode(data.external.budget_monitoring.result["cost_centers_with_alerts"])
    highest_utilization = jsondecode(data.external.budget_monitoring.result["highest_utilization"])
  }
  depends_on = [local_file.budget_alerts]
}

output "optimization_recommendations" {
  description = "Token economics optimization recommendations"
  value = {
    optimization_id = data.external.optimize_token_economics.result["optimization_id"]
    recommended_free_tokens = jsondecode(data.external.optimize_token_economics.result["recommended_free_tokens"])
    recommended_token_value = jsondecode(data.external.optimize_token_economics.result["recommended_token_value"])
    projected_conversion_improvement = jsondecode(data.external.optimize_token_economics.result["projected_conversion_improvement"])
    revenue_impact = jsondecode(data.external.optimize_token_economics.result["revenue_impact"])
    confidence_score = tonumber(data.external.optimize_token_economics.result["confidence_score"])
    implementation_priority = jsondecode(data.external.optimize_token_economics.result["implementation_priority"])
  }
  depends_on = [local_file.optimization_report]
}

output "tier_upgrades_processed" {
  description = "Summary of processed tier upgrades"
  value = {
    for upgrade in data.external.process_tier_upgrade : upgrade.key => {
      account_id = element(var.tier_upgrade_requests, tonumber(upgrade.key)).account_id
      current_tier = element(var.tier_upgrade_requests, tonumber(upgrade.key)).current_tier
      requested_tier = element(var.tier_upgrade_requests, tonumber(upgrade.key)).requested_tier
      upgrade_approved = upgrade.result["upgrade_approved"]
      new_balance = tonumber(upgrade.result["new_balance"])
      effective_date = upgrade.result["effective_date"]
    }
  }
  depends_on = [data.external.process_tier_upgrade]
}

output "token_consumption_events_processed" {
  description = "Summary of processed token consumption events"
  value = {
    for event in data.external.calculate_token_consumption : event.key => {
      event_type = var.token_consumption_events[event.key].event_type
      quantity = var.token_consumption_events[event.key].quantity
      provider = var.token_consumption_events[event.key].provider
      tokens_consumed = tonumber(event.result["tokens_consumed"])
      new_balance = tonumber(event.result["new_balance"])
      cost_savings = event.result["cost_savings"]
      arbitrage_applied = event.result["arbitrage_applied"]
    }
  }
  depends_on = [data.external.calculate_token_consumption]
}

output "unified_billing_file_path" {
  description = "Path to the unified billing report file"
  value = local_file.billing_report.filename
}

output "attribution_report_file_path" {
  description = "Path to the cost attribution report file"
  value = local_file.attribution_report.filename
}

output "optimization_report_file_path" {
  description = "Path to the optimization recommendations report"
  value = local_file.optimization_report.filename
}

output "token_balances_file_path" {
  description = "Path to the token balances file"
  value = local_file.token_balances.filename
}

output "budget_alerts_directory" {
  description = "Directory containing budget alert files"
  value = "${path.module}/alerts"
}

output "conversion_funnel_metrics" {
  description = "Conversion funnel metrics and analysis"
  value = {
    free_tier_users = jsondecode(data.external.unified_billing.result["free_tier_users"])
    paid_tier_users = jsondecode(data.external.unified_billing.result["paid_tier_users"])
    conversion_rate = jsondecode(data.external.unified_billing.result["conversion_rate"])
    avg_time_to_conversion = jsondecode(data.external.unified_billing.result["avg_time_to_conversion"])
    churn_rate = jsondecode(data.external.unified_billing.result["churn_rate"])
    customer_lifetime_value = jsondecode(data.external.unified_billing.result["customer_lifetime_value"])
  }
  depends_on = [local_file.billing_report]
}

output "provider_arbitrage_savings" {
  description = "Savings achieved through provider arbitrage"
  value = {
    total_savings_usd = jsondecode(data.external.unified_billing.result["total_arbitrage_savings"])
    savings_by_provider = jsondecode(data.external.unified_billing.result["savings_by_provider"])
    arbitrage_opportunities = jsondecode(data.external.unified_billing.result["arbitrage_opportunities"])
    most_used_provider = jsondecode(data.external.unified_billing.result["most_used_provider"])
    cheapest_provider = jsondecode(data.external.unified_billing.result["cheapest_provider"])
  }
  depends_on = [local_file.billing_report]
}
