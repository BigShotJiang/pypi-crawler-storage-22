variable "free_tier_tokens" {
  description = "Number of free tokens allocated to new users"
  type        = number
  default     = 1000
  
  validation {
    condition     = var.free_tier_tokens >= 500 && var.free_tier_tokens <= 5000
    error_message = "Free tier tokens must be between 500 and 5000 for optimal conversion."
  }
}

variable "token_value_usd" {
  description = "USD value of one token"
  type        = number
  default     = 0.01
  
  validation {
    condition     = var.token_value_usd >= 0.001 && var.token_value_usd <= 0.10
    error_message = "Token value must be between $0.001 and $0.10 for market competitiveness."
  }
}

variable "num_token_accounts" {
  description = "Number of token accounts to create"
  type        = number
  default     = 100
}

variable "user_ids" {
  description = "List of user IDs for token accounts"
  type        = list(string)
  default     = []
}

variable "initial_token_balance" {
  description = "Initial token balance for new accounts"
  type        = number
  default     = 1000
}

variable "token_tier" {
  description = "Token tier for accounts (free, basic, pro, enterprise)"
  type        = string
  default     = "free"
  
  validation {
    condition     = contains(["free", "basic", "pro", "enterprise"], var.token_tier)
    error_message = "Token tier must be one of: free, basic, pro, enterprise."
  }
}

variable "token_consumption_events" {
  description = "Token consumption events to process"
  type        = map(object({
    event_type = string
    quantity   = number
    provider   = string
    account_id = string
  }))
  default     = {}
}

variable "billing_period" {
  description = "Billing period for unified billing (YYYY-MM format)"
  type        = string
  default     = formatdate("YYYY-MM", timestamp())
}

variable "provider_hourly_rates" {
  description = "Hourly rates by provider and GPU type"
  type        = map(map(number))
  default = {
    aws = {
      "p4d.24xlarge" = 32.77
      "p3.2xlarge"   = 3.06
      "g5.xlarge"    = 1.21
    }
    azure = {
      "Standard_ND96asr_v4" = 25.00
      "Standard_NC6s_v3"     = 3.06
      "Standard_NC4as_T4_v3" = 0.52
    }
    gcp = {
      "a2-highgpu-8g" = 28.00
      "a2-megagpu-16g" = 45.00
      "n1-standard-4" = 0.15
    }
    runpod = {
      "A100-40GB" = 2.50
      "A100-80GB" = 3.50
      "RTX-4090"  = 1.20
    }
    lambda = {
      "A100"     = 2.40
      "RTX-6000" = 0.90
      "RTX-3090" = 0.35
    }
    coreweave = {
      "A40"      = 2.50
      "A100"     = 3.50
      "RTX-4090" = 1.50
    }
  }
}

variable "tier_upgrade_requests" {
  description = "Token tier upgrade requests"
  type        = list(object({
    account_id     = string
    current_tier   = string
    requested_tier = string
    current_balance = number
  }))
  default     = []
}

variable "tier_upgrade_criteria" {
  description = "Criteria for tier upgrades"
  type        = object({
    basic_to_pro = object({
      min_tokens_consumed = number
      min_months_active   = number
      payment_required    = bool
    })
    pro_to_enterprise = object({
      min_tokens_consumed = number
      min_months_active   = number
      payment_required    = bool
      approval_required   = bool
    })
  })
  default = {
    basic_to_pro = {
      min_tokens_consumed = 5000
      min_months_active   = 2
      payment_required    = true
    }
    pro_to_enterprise = {
      min_tokens_consumed = 50000
      min_months_active   = 6
      payment_required    = true
      approval_required   = true
    }
  }
}

variable "cost_attribution_rules" {
  description = "Rules for cost attribution to teams, projects, business units"
  type        = object({
    default_team = string
    tag_mapping = map(string)
    hierarchy_rules = map(list(string))
  })
  default = {
    default_team = "unattributed"
    tag_mapping = {
      "team"      = "team_id"
      "project"   = "project_id"
      "department" = "business_unit_id"
    }
    hierarchy_rules = {
      "ml-team" = ["ai-division"]
      "inference-team" = ["ai-division"]
      "data-team" = ["platform-division"]
    }
  }
}

variable "team_hierarchy" {
  description = "Organizational hierarchy for cost attribution"
  type        = map(object({
    parent_id = string
    budget_limit = optional(number)
    alert_threshold = optional(number, 80)
    owners = list(string)
  }))
  default = {
    "ai-division" = {
      parent_id = "company"
      budget_limit = 100000
      alert_threshold = 85
      owners = ["cto@company.com", "vp-engineering@company.com"]
    }
    "platform-division" = {
      parent_id = "company"
      budget_limit = 50000
      alert_threshold = 80
      owners = ["vp-platform@company.com"]
    }
    "ml-team" = {
      parent_id = "ai-division"
      budget_limit = 40000
      owners = ["ml-lead@company.com"]
    }
    "inference-team" = {
      parent_id = "ai-division"
      budget_limit = 30000
      owners = ["inference-lead@company.com"]
    }
  }
}

variable "budget_limits" {
  description = "Budget limits for cost centers"
  type        = map(number)
  default = {
    "ml-team"         = 40000
    "inference-team"  = 30000
    "data-team"       = 20000
    "ai-division"     = 100000
    "platform-division" = 50000
  }
}

variable "alert_thresholds" {
  description = "Alert thresholds for budget monitoring"
  type        = map(number)
  default = {
    "warning"  = 80
    "critical" = 95
    "exceeded" = 100
  }
}

variable "market_competitor_data" {
  description = "Market competitor data for token economics optimization"
  type        = object({
    avg_free_allowance = number
    avg_paid_price = number
    conversion_rates = map(number)
    market_growth_rate = number
  })
  default = {
    avg_free_allowance = 800
    avg_paid_price = 0.015
    conversion_rates = {
      "competitor_a" = 0.12
      "competitor_b" = 0.18
      "competitor_c" = 0.15
    }
    market_growth_rate = 0.25
  }
}
