# AWS GPU Instance Module
resource "aws_instance" "gpu_instances" {
  count = var.instance_count

  ami           = var.ami_id
  instance_type = var.instance_type
  
  subnet_id                   = var.subnet_id
  vpc_security_group_ids      = var.security_group_ids
  associate_public_ip_address = var.assign_public_ip
  
  root_block_device {
    volume_type = "gp3"
    volume_size = var.root_volume_size
    encrypted   = true
  }

  # EBS volumes for data storage
  dynamic "ebs_block_device" {
    for_each = var.data_volumes
    content {
      device_name = ebs_block_device.value.device_name
      volume_type = ebs_block_device.value.volume_type
      volume_size = ebs_block_device.value.volume_size
      encrypted   = true
    }
  }

  user_data = var.user_data

  tags = merge(
    var.tags,
    {
      Name = "${var.name_prefix}-gpu-${count.index + 1}"
      Type = "GPU-Instance"
    }
  )

  lifecycle {
    create_before_destroy = true
  }
}

# Auto Scaling Group for GPU instances (if enabled)
resource "aws_autoscaling_group" "gpu_asg" {
  count = var.enable_auto_scaling ? 1 : 0

  name                = "${var.name_prefix}-gpu-asg"
  vpc_zone_identifier = var.subnet_ids
  target_group_arns   = var.target_group_arns
  health_check_type   = "EC2"
  health_check_grace_period = 300

  launch_template {
    id      = aws_launch_template.gpu_lt[0].id
    version = "$Latest"
  }

  min_size         = var.min_instances
  max_size         = var.max_instances
  desired_capacity = var.desired_instances

  tag {
    key                 = "Name"
    value               = "${var.name_prefix}-gpu-asg"
    propagate_at_launch = true
  }

  tag {
    key                 = "Project"
    value               = var.tags["Project"]
    propagate_at_launch = true
  }

  tag {
    key                 = "Environment"
    value               = var.tags["Environment"]
    propagate_at_launch = true
  }
}

# Launch Template for Auto Scaling
resource "aws_launch_template" "gpu_lt" {
  count = var.enable_auto_scaling ? 1 : 0

  name_prefix   = "${var.name_prefix}-gpu-"
  image_id      = var.ami_id
  instance_type = var.instance_type

  network_interfaces {
    associate_public_ip_address = var.assign_public_ip
    security_groups             = var.security_group_ids
  }

  block_device_mappings {
    device_name = "/dev/sda1"
    ebs {
      volume_type = "gp3"
      volume_size = var.root_volume_size
      encrypted   = true
    }
  }

  dynamic "block_device_mappings" {
    for_each = var.data_volumes
    content {
      device_name = block_device_mappings.value.device_name
      ebs {
        volume_type = block_device_mappings.value.volume_type
        volume_size = block_device_mappings.value.volume_size
        encrypted   = true
      }
    }
  }

  user_data = var.user_data

  tag_specifications {
    resource_type = "instance"
    tags = merge(
      var.tags,
      {
        Name = "${var.name_prefix}-gpu"
        Type = "GPU-Instance"
      }
    )
  }
}

# CloudWatch Monitoring for GPU instances
resource "aws_cloudwatch_metric_alarm" "gpu_utilization" {
  count = var.enable_monitoring ? length(aws_instance.gpu_instances) : 0

  alarm_name          = "${var.name_prefix}-gpu-util-${count.index}"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = "2"
  metric_name         = "GPUUtilization"
  namespace           = "AWS/EC2"
  period              = "300"
  statistic           = "Average"
  threshold           = "80"
  alarm_description   = "This metric monitors GPU utilization"
  alarm_actions       = var.alarm_actions

  dimensions = {
    InstanceId = aws_instance.gpu_instances[count.index].id
  }

  tags = var.tags
}
