output "instance_ids" {
  description = "IDs of created GPU instances"
  value       = aws_instance.gpu_instances[*].id
}

output "instance_public_ips" {
  description = "Public IP addresses of GPU instances"
  value       = aws_instance.gpu_instances[*].public_ip
}

output "instance_private_ips" {
  description = "Private IP addresses of GPU instances"
  value       = aws_instance.gpu_instances[*].private_ip
}

output "instance_arns" {
  description = "ARNs of GPU instances"
  value       = aws_instance.gpu_instances[*].arn
}

output "security_group_ids" {
  description = "Security group IDs attached to instances"
  value       = var.security_group_ids
}

output "subnet_id" {
  description = "Subnet ID where instances are deployed"
  value       = var.subnet_id
}

output "launch_template_id" {
  description = "ID of the launch template (if auto scaling enabled)"
  value       = var.enable_auto_scaling ? aws_launch_template.gpu_lt[0].id : null
}

output "autoscaling_group_name" {
  description = "Name of the auto scaling group (if enabled)"
  value       = var.enable_auto_scaling ? aws_autoscaling_group.gpu_asg[0].name : null
}

output "cloudwatch_alarm_names" {
  description = "Names of CloudWatch alarms (if monitoring enabled)"
  value       = var.enable_monitoring ? aws_cloudwatch_metric_alarm.gpu_utilization[*].alarm_name : []
}
