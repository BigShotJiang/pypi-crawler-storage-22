variable "name_prefix" {
  description = "Prefix for resource names"
  type        = string
}

variable "instance_count" {
  description = "Number of GPU instances to create"
  type        = number
  default     = 1
}

variable "instance_type" {
  description = "EC2 instance type for GPU instances"
  type        = string
  default     = "p3.2xlarge"
  
  validation {
    condition = contains([
      "p3.2xlarge", "p3.8xlarge", "p3.16xlarge",
      "p4d.24xlarge", "p4de.24xlarge",
      "g4dn.xlarge", "g4dn.2xlarge", "g4dn.4xlarge", "g4dn.8xlarge", "g4dn.12xlarge", "g4dn.16xlarge",
      "g5.xlarge", "g5.2xlarge", "g5.4xlarge", "g5.8xlarge", "g5.12xlarge", "g5.16xlarge", "g5.24xlarge", "g5.48xlarge"
    ], var.instance_type)
    error_message = "Instance type must be a supported GPU instance type."
  }
}

variable "ami_id" {
  description = "AMI ID for GPU instances"
  type        = string
  default     = "ami-0c02fb55956c7d316" # Deep Learning AMI
}

variable "subnet_id" {
  description = "VPC subnet ID for instances"
  type        = string
}

variable "subnet_ids" {
  description = "List of VPC subnet IDs for auto scaling"
  type        = list(string)
  default     = []
}

variable "security_group_ids" {
  description = "List of security group IDs"
  type        = list(string)
  default     = []
}

variable "assign_public_ip" {
  description = "Whether to assign public IP addresses"
  type        = bool
  default     = true
}

variable "root_volume_size" {
  description = "Size of root volume in GB"
  type        = number
  default     = 100
}

variable "data_volumes" {
  description = "Additional EBS volumes for data storage"
  type = list(object({
    device_name = string
    volume_type = string
    volume_size = number
  }))
  default = []
}

variable "user_data" {
  description = "User data script for instance initialization"
  type        = string
  default     = ""
}

variable "tags" {
  description = "Tags to apply to all resources"
  type        = map(string)
  default     = {}
}

variable "enable_auto_scaling" {
  description = "Enable auto scaling group"
  type        = bool
  default     = false
}

variable "min_instances" {
  description = "Minimum number of instances in auto scaling group"
  type        = number
  default     = 1
}

variable "max_instances" {
  description = "Maximum number of instances in auto scaling group"
  type        = number
  default     = 10
}

variable "desired_instances" {
  description = "Desired number of instances in auto scaling group"
  type        = number
  default     = 2
}

variable "target_group_arns" {
  description = "Target group ARNs for load balancer"
  type        = list(string)
  default     = []
}

variable "enable_monitoring" {
  description = "Enable CloudWatch monitoring"
  type        = bool
  default     = true
}

variable "alarm_actions" {
  description = "List of alarm action ARNs"
  type        = list(string)
  default     = []
}
