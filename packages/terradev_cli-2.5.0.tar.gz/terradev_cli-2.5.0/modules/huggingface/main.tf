# Hugging Face Dataset Integration Module
# This module provides integration with Hugging Face datasets for ML training

terraform {
  required_providers {
    http = {
      source  = "hashicorp/http"
      version = "~> 3.0"
    }
    local = {
      source  = "hashicorp/local"
      version = "~> 2.0"
    }
  }
}

# Get dataset information from Hugging Face API
data "http" "hf_dataset_info" {
  url = "https://huggingface.co/api/datasets/${var.dataset_name}"
  
  request_headers = {
    Accept = "application/json"
    Authorization = var.hf_token != "" ? "Bearer ${var.hf_token}" : null
  }
  
  lifecycle {
    postcondition {
      condition     = self.status_code == 200
      error_message = "Failed to fetch dataset info from Hugging Face: ${self.status_code}"
    }
  }
}

# Parse dataset information
locals {
  dataset_info = jsondecode(data.http.hf_dataset_info.response_body)
  
  # Extract relevant dataset metadata
  dataset_metadata = {
    name        = local.dataset_info.id
    description = try(local.dataset_info.description, "")
    tags        = try(local.dataset_info.tags, [])
    size_gb     = try(local.dataset_info.cardData.size_in_bytes, 0) / (1024 * 1024 * 1024)
    downloads   = try(local.dataset_info.cardData.downloads, 0)
    likes       = try(local.dataset_info.cardData.likes, 0)
    last_modified = try(local.dataset_info.lastModified, "")
    card_data   = try(local.dataset_info.cardData, {})
  }
  
  # Check if dataset is compatible with freemium tier
  dataset_compatible = var.tier == "freemium" ? (
    contains(var.supported_datasets, var.dataset_name) && 
    local.dataset_metadata.size_gb <= var.max_dataset_size_gb
  ) : true
  
  # Dataset splits information
  dataset_splits = try(local.dataset_info.cardData.splits, {})
  
  # Recommended models for this dataset
  recommended_models = {
    "coco" = ["stable-diffusion", "yolos", "detr"]
    "imagenet-1k" = ["resnet", "efficientnet", "vit"]
    "squad" = ["bert", "roberta", "gpt2"]
    "wikitext" = ["gpt2", "llama", "mistral"]
    "glue" = ["bert", "roberta", "distilbert"]
  }
  
  # Get recommended models for this dataset
  current_recommended_models = try(
    local.recommended_models[var.dataset_name], 
    ["bert", "gpt2", "llama"]  # Default fallback
  )
}

# Download dataset configuration
resource "local_file" "dataset_config" {
  filename = "${path.module}/datasets/${var.dataset_name}/config.json"
  content = jsonencode({
    dataset_name = var.dataset_name
    metadata = local.dataset_metadata
    splits = local.dataset_splits
    download_config = {
      cache_dir = "/tmp/hf_cache/${var.dataset_name}"
      use_auth_token = var.hf_token != ""
      num_proc = var.download_workers
    }
    preprocessing = {
      max_samples = var.max_samples
      validation_split = var.validation_split
      test_split = var.test_split
    }
    compatibility = {
      tier_compatible = local.dataset_compatible
      recommended_models = local.current_recommended_models
      size_warning = local.dataset_metadata.size_gb > var.max_dataset_size_gb * 0.8
    }
  })
}

# Dataset download script
resource "local_file" "download_script" {
  filename = "${path.module}/scripts/download_dataset.py"
  content = <<-EOT
    #!/usr/bin/env python3
    """
    Dataset Download Script for Hugging Face Integration
    """
    
    import os
    import json
    import argparse
    from datasets import load_dataset
    from transformers import AutoTokenizer
    
    def main():
        parser = argparse.ArgumentParser(description='Download Hugging Face dataset')
        parser.add_argument('--dataset', required=True, help='Dataset name')
        parser.add_argument('--config', help='Path to config file')
        parser.add_argument('--cache-dir', default='/tmp/hf_cache', help='Cache directory')
        parser.add_argument('--token', help='Hugging Face token')
        parser.add_argument('--max-samples', type=int, help='Maximum samples to download')
        parser.add_argument('--split', default='train', help='Dataset split to download')
        
        args = parser.parse_args()
        
        # Load dataset
        try:
            print(f"Loading dataset {args.dataset}...")
            dataset = load_dataset(
                args.dataset,
                split=args.split,
                cache_dir=args.cache_dir,
                use_auth_token=args.token
            )
            
            # Limit samples if specified
            if args.max_samples and len(dataset) > args.max_samples:
                print(f"Limiting to {args.max_samples} samples from {len(dataset)} total")
                dataset = dataset.select(range(args.max_samples))
            
            print(f"Successfully loaded {len(dataset)} samples")
            print(f"Dataset features: {dataset.features}")
            
            # Save dataset info
            info = {
                "dataset": args.dataset,
                "split": args.split,
                "num_samples": len(dataset),
                "features": [str(feature) for feature in dataset.features],
                "cache_dir": args.cache_dir
            }
            
            with open(f"{args.cache_dir}/{args.dataset}_info.json", "w") as f:
                json.dump(info, f, indent=2)
            
        except Exception as e:
            print(f"Error loading dataset: {e}")
            return 1
        
        return 0
    
    if __name__ == "__main__":
        exit(main())
  EOT
}

# Dataset preprocessing script
resource "local_file" "preprocessing_script" {
  filename = "${path.module}/scripts/preprocess_dataset.py"
  content = <<-EOT
    #!/usr/bin/env python3
    """
    Dataset Preprocessing Script for ML Training
    """
    
    import os
    import json
    import argparse
    from datasets import load_from_disk, DatasetDict
    from transformers import AutoTokenizer
    
    def preprocess_text_dataset(dataset, tokenizer_name, max_length=512):
        """Preprocess text dataset for training."""
        tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)
        
        def tokenize_function(examples):
            return tokenizer(
                examples["text"],
                padding="max_length",
                truncation=True,
                max_length=max_length
            )
        
        tokenized_dataset = dataset.map(
            tokenize_function,
            batched=True,
            remove_columns=dataset.column_names
        )
        
        return tokenized_dataset
    
    def preprocess_image_dataset(dataset, image_size=224):
        """Preprocess image dataset for training."""
        def transform_function(examples):
            # Add image preprocessing logic here
            examples["pixel_values"] = examples["image"]
            return examples
        
        transformed_dataset = dataset.map(
            transform_function,
            batched=True,
            remove_columns=["image"]
        )
        
        return transformed_dataset
    
    def main():
        parser = argparse.ArgumentParser(description='Preprocess dataset')
        parser.add_argument('--dataset-path', required=True, help='Path to dataset')
        parser.add_argument('--output-path', required=True, help='Output path')
        parser.add_argument('--type', choices=['text', 'image'], required=True, help='Dataset type')
        parser.add_argument('--tokenizer', help='Tokenizer for text datasets')
        parser.add_argument('--max-length', type=int, default=512, help='Max sequence length')
        parser.add_argument('--image-size', type=int, default=224, help='Image size')
        parser.add_argument('--validation-split', type=float, default=0.1, help='Validation split ratio')
        
        args = parser.parse_args()
        
        try:
            # Load dataset
            dataset = load_from_disk(args.dataset_path)
            
            # Preprocess based on type
            if args.type == "text":
                if not args.tokenizer:
                    print("Tokenizer required for text datasets")
                    return 1
                processed_dataset = preprocess_text_dataset(dataset, args.tokenizer, args.max_length)
            else:
                processed_dataset = preprocess_image_dataset(dataset, args.image_size)
            
            # Split dataset
            if args.validation_split > 0:
                split_dataset = processed_dataset.train_test_split(test_size=args.validation_split)
                final_dataset = DatasetDict({
                    "train": split_dataset["train"],
                    "validation": split_dataset["test"]
                })
            else:
                final_dataset = DatasetDict({"train": processed_dataset})
            
            # Save processed dataset
            final_dataset.save_to_disk(args.output_path)
            
            print(f"Successfully preprocessed and saved dataset to {args.output_path}")
            
        except Exception as e:
            print(f"Error preprocessing dataset: {e}")
            return 1
        
        return 0
    
    if __name__ == "__main__":
        exit(main())
  EOT
}

# Dataset compatibility check
resource "local_file" "compatibility_report" {
  filename = "${path.module}/datasets/${var.dataset_name}/compatibility.json"
  content = jsonencode({
    dataset_name = var.dataset_name
    tier = var.tier
    compatibility = {
      can_download = local.dataset_compatible
      size_gb = local.dataset_metadata.size_gb
      size_limit_gb = var.max_dataset_size_gb
      is_supported = contains(var.supported_datasets, var.dataset_name)
      recommended_models = local.current_recommended_models
    }
    warnings = [
      for warning in [
        local.dataset_metadata.size_gb > var.max_dataset_size_gb * 0.8 ? "Dataset size approaching tier limit" : "",
        !contains(var.supported_datasets, var.dataset_name) ? "Dataset not in freemium supported list" : "",
        local.dataset_metadata.size_gb > var.max_dataset_size_gb ? "Dataset exceeds tier size limit" : ""
      ] : warning if warning != ""
    ]
    recommendations = [
      for rec in [
        var.tier == "freemium" && !local.dataset_compatible ? "Upgrade to paid tier for unlimited dataset access" : "",
        var.tier == "freemium" ? "Consider using supported datasets: ${join(", ", var.supported_datasets)}" : "",
        local.dataset_metadata.size_gb > 10 ? "This dataset may take significant time to download" : ""
      ] : rec if rec != ""
    ]
  })
}
