variable "dataset_name" {
  description = "Name of the Hugging Face dataset to download"
  type        = string
  default     = "coco"
}

variable "tier" {
  description = "User subscription tier (freemium or paid)"
  type        = string
  default     = "freemium"
  
  validation {
    condition     = contains(["freemium", "paid"], var.tier)
    error_message = "Tier must be either 'freemium' or 'paid'."
  }
}

variable "hf_token" {
  description = "Hugging Face API token for private datasets"
  type        = string
  default     = ""
  sensitive   = true
}

variable "supported_datasets" {
  description = "List of datasets supported in freemium tier"
  type        = list(string)
  default     = [
    "coco",
    "imagenet-1k",
    "squad",
    "wikitext",
    "glue",
    "mnist",
    "cifar10",
    "fashion_mnist",
    "imdb",
    "ag_news"
  ]
}

variable "max_dataset_size_gb" {
  description = "Maximum dataset size in GB for freemium tier"
  type        = number
  default     = 50
}

variable "download_workers" {
  description = "Number of parallel workers for dataset download"
  type        = number
  default     = 4
}

variable "max_samples" {
  description = "Maximum number of samples to download (for testing)"
  type        = number
  default     = null
}

variable "validation_split" {
  description = "Fraction of data to use for validation"
  type        = number
  default     = 0.1
}

variable "test_split" {
  description = "Fraction of data to use for testing"
  type        = number
  default     = 0.1
}

variable "cache_dir" {
  description = "Directory to cache downloaded datasets"
  type        = string
  default     = "/tmp/hf_cache"
}

variable "preprocess_config" {
  description = "Configuration for dataset preprocessing"
  type = object({
    tokenize = bool
    max_length = number
    image_size = number
    normalize = bool
    augment = bool
  })
  default = {
    tokenize = true
    max_length = 512
    image_size = 224
    normalize = true
    augment = false
  }
}
