# Model Registry Module
# Manages open source model discovery and deployment

resource "aws_s3_bucket" "model_registry" {
  bucket = "${var.name_prefix}-model-registry-${random_id.registry_suffix.hex}"

  tags = merge(
    var.tags,
    {
      Name = "${var.name_prefix}-model-registry"
      Type = "Model-Registry"
    }
  )
}

resource "random_id" "registry_suffix" {
  byte_length = 4
}

# Model Registry Database
resource "aws_dynamodb_table" "model_registry" {
  name = "${var.name_prefix}-model-registry"
  billing_mode = "PAY_PER_REQUEST"
  
  hash_key = "model_id"
  
  attribute {
    name = "model_id"
    type = "S"
  }
  
  attribute {
    name = "framework"
    type = "S"
  }
  
  attribute {
    name = "task_type"
    type = "S"
  }
  
  attribute {
    name = "popularity"
    type = "N"
  }
  
  global_secondary_index {
    name     = "FrameworkIndex"
    hash_key = "framework"
    range_key = "popularity"
  }
  
  global_secondary_index {
    name     = "TaskTypeIndex"
    hash_key = "task_type"
    range_key = "popularity"
  }
  
  tags = var.tags
}

# Lambda Function for Model Discovery
resource "aws_lambda_function" "model_discovery" {
  function_name = "${var.name_prefix}-model-discovery"
  role          = aws_iam_role.model_discovery_role.arn
  handler       = "model_discovery.lambda_handler"
  runtime       = "python3.9"
  
  filename = "model_discovery.zip"
  
  environment {
    variables = {
      MODEL_REGISTRY_TABLE = aws_dynamodb_table.model_registry.name
      S3_BUCKET = aws_s3_bucket.model_registry.id
    }
  }
  
  tags = merge(
    var.tags,
    {
      Name = "${var.name_prefix}-model-discovery"
      Type = "Model-Discovery"
    }
  )
}

# API Gateway for Model Registry
resource "aws_api_gateway_rest_api" "model_registry_api" {
  name        = "${var.name_prefix}-model-registry-api"
  description = "API for model discovery and management"
  
  tags = var.tags
}

# Model Deployment Lambda
resource "aws_lambda_function" "model_deployment" {
  function_name = "${var.name_prefix}-model-deployment"
  role          = aws_iam_role.model_deployment_role.arn
  handler       = "model_deployment.lambda_handler"
  runtime       = "python3.9"
  timeout       = 900  # 15 minutes
  
  filename = "model_deployment.zip"
  
  environment {
    variables = {
      MODEL_REGISTRY_TABLE = aws_dynamodb_table.model_registry.name
      S3_BUCKET = aws_s3_bucket.model_registry.id
      GPU_INSTANCE_TYPE = var.default_gpu_instance
    }
  }
  
  tags = merge(
    var.tags,
    {
      Name = "${var.name_prefix}-model-deployment"
      Type = "Model-Deployment"
    }
  )
}
