# Storage Module for Terradev

# S3 Bucket for general storage
resource "aws_s3_bucket" "storage_bucket" {
  bucket = "${var.name_prefix}-storage-${random_id.storage_suffix.hex}"

  tags = merge(
    var.tags,
    {
      Name = "${var.name_prefix}-storage"
      Type = "General-Storage"
    }
  )
}

resource "random_id" "storage_suffix" {
  byte_length = 4
}

# S3 Bucket configuration
resource "aws_s3_bucket_versioning" "storage_versioning" {
  bucket = aws_s3_bucket.storage_bucket.id
  versioning_configuration {
    status = var.enable_versioning ? "Enabled" : "Disabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "storage_encryption" {
  bucket = aws_s3_bucket.storage_bucket.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = var.encryption_algorithm
    }
  }
}

resource "aws_s3_bucket_public_access_block" "storage_pab" {
  bucket = aws_s3_bucket.storage_bucket.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# S3 Bucket lifecycle configuration
resource "aws_s3_bucket_lifecycle_configuration" "storage_lifecycle" {
  count = var.enable_lifecycle ? 1 : 0

  bucket = aws_s3_bucket.storage_bucket.id

  dynamic "rule" {
    for_each = var.lifecycle_rules
    content {
      id     = rule.value.id
      status = rule.value.status

      dynamic "filter" {
        for_each = rule.value.filter != null ? [rule.value.filter] : []
        content {
          prefix = filter.value.prefix
        }
      }

      dynamic "transition" {
        for_each = rule.value.transitions
        content {
          days          = transition.value.days
          storage_class = transition.value.storage_class
        }
      }

      dynamic "expiration" {
        for_each = rule.value.expiration != null ? [rule.value.expiration] : []
        content {
          days = expiration.value.days
        }
      }
    }
  }
}

# EFS File System for shared storage
resource "aws_efs_file_system" "shared_storage" {
  count = var.enable_efs ? 1 : 0

  creation_token = "${var.name_prefix}-efs"

  tags = merge(
    var.tags,
    {
      Name = "${var.name_prefix}-efs"
      Type = "Shared-Storage"
    }
  )
}

# EFS Mount targets
resource "aws_efs_mount_target" "efs_mount" {
  count = var.enable_efs ? length(var.subnet_ids) : 0

  file_system_id  = aws_efs_file_system.shared_storage[0].id
  subnet_id       = var.subnet_ids[count.index]
  security_groups = var.efs_security_groups
}

# EBS Volume for additional storage
resource "aws_ebs_volume" "data_volume" {
  count = var.enable_ebs ? var.ebs_volume_count : 0

  availability_zone = var.availability_zones[count.index % length(var.availability_zones)]
  size              = var.ebs_volume_size
  type              = var.ebs_volume_type
  encrypted         = true

  tags = merge(
    var.tags,
    {
      Name = "${var.name_prefix}-data-volume-${count.index + 1}"
      Type = "EBS-Storage"
    }
  )
}

# DynamoDB Table for metadata
resource "aws_dynamodb_table" "metadata_table" {
  count = var.enable_dynamodb ? 1 : 0

  name           = "${var.name_prefix}-metadata"
  billing_mode   = "PAY_PER_REQUEST"
  hash_key       = "id"

  attribute {
    name = "id"
    type = "S"
  }

  attribute {
    name = "type"
    type = "S"
  }

  attribute {
    name = "created_at"
    type = "S"
  }

  global_secondary_index {
    name     = "TypeIndex"
    hash_key = "type"
    range_key = "created_at"
  }

  tags = merge(
    var.tags,
    {
      Name = "${var.name_prefix}-metadata"
      Type = "Metadata-Storage"
    }
  )
}

# CloudWatch Log Group for application logs
resource "aws_cloudwatch_log_group" "app_logs" {
  count = var.enable_logging ? 1 : 0

  name              = "/aws/terradev/${var.name_prefix}"
  retention_in_days = var.log_retention_days

  tags = var.tags
}
