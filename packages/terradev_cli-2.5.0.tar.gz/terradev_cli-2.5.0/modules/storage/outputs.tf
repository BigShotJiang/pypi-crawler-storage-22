output "s3_bucket_name" {
  description = "Name of the S3 storage bucket"
  value       = aws_s3_bucket.storage_bucket.id
}

output "s3_bucket_arn" {
  description = "ARN of the S3 storage bucket"
  value       = aws_s3_bucket.storage_bucket.arn
}

output "s3_bucket_domain_name" {
  description = "Domain name of the S3 storage bucket"
  value       = aws_s3_bucket.storage_bucket.bucket_domain_name
}

output "efs_file_system_id" {
  description = "ID of the EFS file system"
  value       = var.enable_efs ? aws_efs_file_system.shared_storage[0].id : null
}

output "efs_file_system_arn" {
  description = "ARN of the EFS file system"
  value       = var.enable_efs ? aws_efs_file_system.shared_storage[0].arn : null
}

output "efs_mount_target_ids" {
  description = "IDs of EFS mount targets"
  value       = var.enable_efs ? aws_efs_mount_target.efs_mount[*].id : []
}

output "ebs_volume_ids" {
  description = "IDs of EBS volumes"
  value       = var.enable_ebs ? aws_ebs_volume.data_volume[*].id : []
}

output "ebs_volume_arns" {
  description = "ARNs of EBS volumes"
  value       = var.enable_ebs ? aws_ebs_volume.data_volume[*].arn : []
}

output "dynamodb_table_name" {
  description = "Name of the DynamoDB metadata table"
  value       = var.enable_dynamodb ? aws_dynamodb_table.metadata_table[0].name : null
}

output "dynamodb_table_arn" {
  description = "ARN of the DynamoDB metadata table"
  value       = var.enable_dynamodb ? aws_dynamodb_table.metadata_table[0].arn : null
}

output "cloudwatch_log_group_name" {
  description = "Name of the CloudWatch log group"
  value       = var.enable_logging ? aws_cloudwatch_log_group.app_logs[0].name : null
}

output "cloudwatch_log_group_arn" {
  description = "ARN of the CloudWatch log group"
  value       = var.enable_logging ? aws_cloudwatch_log_group.app_logs[0].arn : null
}
