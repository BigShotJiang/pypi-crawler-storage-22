variable "name_prefix" {
  description = "Prefix for resource names"
  type        = string
}

variable "tags" {
  description = "Tags to apply to all resources"
  type        = map(string)
  default     = {}
}

variable "enable_versioning" {
  description = "Enable S3 bucket versioning"
  type        = bool
  default     = true
}

variable "encryption_algorithm" {
  description = "S3 bucket encryption algorithm"
  type        = string
  default     = "AES256"
  
  validation {
    condition = contains(["AES256", "aws:kms"], var.encryption_algorithm)
    error_message = "Encryption algorithm must be either AES256 or aws:kms."
  }
}

variable "enable_lifecycle" {
  description = "Enable S3 bucket lifecycle rules"
  type        = bool
  default     = true
}

variable "lifecycle_rules" {
  description = "S3 bucket lifecycle rules"
  type = list(object({
    id          = string
    status      = string
    filter      = optional(object({ prefix = string }), null)
    transitions = list(object({
      days          = number
          storage_class = string
    }))
    expiration = optional(object({ days = number }), null)
  }))
  default = [
    {
      id          = "standard_ia_transition"
      status      = "Enabled"
      transitions = [
        { days = 30, storage_class = "STANDARD_IA" },
        { days = 60, storage_class = "GLACIER" }
      ]
      expiration = null
      filter     = null
    }
  ]
}

variable "enable_efs" {
  description = "Enable EFS file system"
  type        = bool
  default     = false
}

variable "subnet_ids" {
  description = "List of subnet IDs for EFS mount targets"
  type        = list(string)
  default     = []
}

variable "efs_security_groups" {
  description = "Security groups for EFS mount targets"
  type        = list(string)
  default     = []
}

variable "enable_ebs" {
  description = "Enable EBS volumes"
  type        = bool
  default     = false
}

variable "ebs_volume_count" {
  description = "Number of EBS volumes to create"
  type        = number
  default     = 1
}

variable "ebs_volume_size" {
  description = "Size of EBS volumes in GB"
  type        = number
  default     = 100
}

variable "ebs_volume_type" {
  description = "Type of EBS volumes"
  type        = string
  default     = "gp3"
  
  validation {
    condition = contains(["gp2", "gp3", "io1", "io2", "st1", "sc1"], var.ebs_volume_type)
    error_message = "EBS volume type must be a valid AWS EBS volume type."
  }
}

variable "availability_zones" {
  description = "List of availability zones for EBS volumes"
  type        = list(string)
  default     = []
}

variable "enable_dynamodb" {
  description = "Enable DynamoDB table for metadata"
  type        = bool
  default     = false
}

variable "enable_logging" {
  description = "Enable CloudWatch log group"
  type        = bool
  default     = true
}

variable "log_retention_days" {
  description = "CloudWatch log retention in days"
  type        = number
  default     = 14
  
  validation {
    condition = contains([1, 3, 5, 7, 14, 30, 60, 90, 120, 180, 365, 400, 545, 730, 1825, 3650], var.log_retention_days)
    error_message = "Log retention days must be a valid CloudWatch retention period."
  }
}
