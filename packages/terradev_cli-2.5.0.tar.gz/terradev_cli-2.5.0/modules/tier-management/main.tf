# User Tier Management Module
# This module manages freemium vs paid tier limitations and features

terraform {
  required_providers {
    random = {
      source  = "hashicorp/random"
      version = "~> 3.0"
    }
    local = {
      source  = "hashicorp/local"
      version = "~> 2.0"
    }
  }
}

# User tier configuration
locals {
  tier_config = {
    freemium = {
      gpu_hours_limit      = 10
      max_concurrent_gpus  = 1
      supported_models     = ["llama", "gpt2", "bert", "stable-diffusion", "mistral"]
      dataset_sources      = ["huggingface"]
      max_dataset_size_gb  = 50
      cost_tracking        = true
      auto_scaling         = false
      custom_models        = false
      custom_datasets      = false
      instance_optimization = false
      data_provenance      = false
    }
    paid = {
      gpu_hours_limit      = -1  # Unlimited
      max_concurrent_gpus  = -1  # Unlimited
      supported_models     = []   # All models supported
      dataset_sources      = []   # All sources supported
      max_dataset_size_gb  = -1  # Unlimited
      cost_tracking        = true
      auto_scaling         = true
      custom_models        = true
      custom_datasets      = true
      instance_optimization = true
      data_provenance      = true
    }
  }
  
  current_tier_config = local.tier_config[var.tier]
  
  # Check if user can deploy based on tier limits
  can_deploy = var.tier == "freemium" ? var.gpu_hours_used < local.current_tier_config.gpu_hours_limit : true
  
  # Check if model is supported for freemium tier
  model_supported = var.tier == "freemium" ? contains(local.current_tier_config.supported_models, var.model_name) : true
  
  # Check if dataset source is supported
  dataset_supported = var.tier == "freemium" ? contains(local.current_tier_config.dataset_sources, var.dataset_source) : true
  
  # Check dataset size limit
  dataset_size_ok = var.tier == "freemium" ? var.dataset_size_gb <= local.current_tier_config.max_dataset_size_gb : true
  
  # Overall deployment approval
  deployment_approved = local.can_deploy && local.model_supported && local.dataset_supported && local.dataset_size_ok
}

# User usage tracking file
resource "local_file" "user_usage" {
  filename = "${path.module}/users/${var.user_id}/usage.json"
  content = jsonencode({
    user_id           = var.user_id
    tier              = var.tier
    gpu_hours_used    = var.gpu_hours_used
    gpu_hours_limit   = local.current_tier_config.gpu_hours_limit
    hours_remaining   = var.tier == "freemium" ? max(0, local.current_tier_config.gpu_hours_limit - var.gpu_hours_used) : "unlimited"
    usage_percentage  = var.tier == "freemium" ? round(var.gpu_hours_used / local.current_tier_config.gpu_hours_limit * 100, 1) : null
    last_updated      = timestamp()
    can_deploy        = local.deployment_approved
    deployment_checks = {
      hours_available = local.can_deploy
      model_supported = local.model_supported
      dataset_supported = local.dataset_supported
      dataset_size_ok = local.dataset_size_ok
    }
  })
}

# Tier limitations file for reference
resource "local_file" "tier_limitations" {
  filename = "${path.module}/users/${var.user_id}/tier_limitations.json"
  content = jsonencode({
    tier = var.tier
    limitations = local.current_tier_config
    current_usage = {
      gpu_hours_used = var.gpu_hours_used
      model_name = var.model_name
      dataset_source = var.dataset_source
      dataset_size_gb = var.dataset_size_gb
    }
    approval_status = {
      can_deploy = local.deployment_approved
      reasons = [
        for check, result in {
          hours_available = local.can_deploy
          model_supported = local.model_supported
          dataset_supported = local.dataset_supported
          dataset_size_ok = local.dataset_size_ok
        } : check if !result
      ]
    }
  })
}

# Freemium tier specific restrictions
resource "random_id" "freemium_session" {
  count = var.tier == "freemium" ? 1 : 0
  
  keepers = {
    user_id = var.user_id
    session_start = timestamp()
  }
  
  byte_length = 8
}

# Usage warning for freemium users approaching limits
resource "local_file" "usage_warning" {
  count = var.tier == "freemium" && var.gpu_hours_used >= local.current_tier_config.gpu_hours_limit * 0.8 ? 1 : 0
  
  filename = "${path.module}/users/${var.user_id}/usage_warning.txt"
  content = <<-EOT
    USAGE WARNING: You have used ${var.gpu_hours_used} of ${local.current_tier_config.gpu_hours_limit} GPU hours this month.
    
    Remaining hours: ${max(0, local.current_tier_config.gpu_hours_limit - var.gpu_hours_used)}
    
    To continue using Terradev without interruption, please upgrade to the paid tier for unlimited GPU hours.
    
    Upgrade benefits:
    - Unlimited GPU hours
    - Multi-model support
    - Custom dataset imports
    - Auto-scaling capabilities
    - Instance optimization
    - Data and model provenance
  EOT
}
