variable "user_id" {
  description = "Unique identifier for the user"
  type        = string
}

variable "tier" {
  description = "User subscription tier (freemium or paid)"
  type        = string
  default     = "freemium"
  
  validation {
    condition     = contains(["freemium", "paid"], var.tier)
    error_message = "Tier must be either 'freemium' or 'paid'."
  }
}

variable "gpu_hours_used" {
  description = "Current GPU hours used in the current billing cycle"
  type        = number
  default     = 0
}

variable "model_name" {
  description = "Name of the model to be deployed"
  type        = string
  default     = "llama"
}

variable "dataset_source" {
  description = "Source of the dataset to be used"
  type        = string
  default     = "huggingface"
}

variable "dataset_size_gb" {
  description = "Size of the dataset in GB"
  type        = number
  default     = 10
}

variable "billing_cycle_start" {
  description = "Start date of the current billing cycle"
  type        = string
  default     = ""
}

variable "auto_upgrade" {
  description = "Whether to automatically upgrade tier when limits are reached"
  type        = bool
  default     = false
}

variable "notification_preferences" {
  description = "User notification preferences"
  type = object({
    usage_warnings      = bool
    limit_approaching   = bool
    upgrade_suggestions = bool
    cost_alerts         = bool
  })
  default = {
    usage_warnings      = true
    limit_approaching   = true
    upgrade_suggestions = true
    cost_alerts         = true
  }
}
