package application.authz

# Only owner can update the pet's information. Ownership
# information is provided as part of the request data from
# the application.
default allow := false

allow if {
	input.method == "PUT"
	some petid
	input.path = ["pets", petid]
	input.user == input.owner
}

# Additional authorization rules for pet management

# Allow staff to read any pet information
allow if {
	input.method == "GET"
	some petid
	input.path = ["pets", petid]
	is_staff(input.user)
}

# Allow owners to read their own pets
allow if {
	input.method == "GET"
	some petid
	input.path = ["pets", petid]
	input.user == input.owner
}

# Allow owners to create new pets
allow if {
	input.method == "POST"
	input.path = ["pets"]
	is_valid_pet_creation(input.user, input.pet)
}

# Allow staff to delete any pet
allow if {
	input.method == "DELETE"
	some petid
	input.path = ["pets", petid]
	is_staff(input.user)
}

# Allow owners to delete their own pets
allow if {
	input.method == "DELETE"
	some petid
	input.path = ["pets", petid]
	input.user == input.owner
}

# Helper functions

is_staff(user) {
	user_roles[user][_] == "staff"
}

is_valid_pet_creation(user, pet) {
	pet.owner == user
	pet.name != ""
	pet.species != ""
}

# User roles data (this would typically come from external data)
user_roles := {
	"alice@example.com": ["staff", "admin"],
	"bob@example.com": ["user"],
	"charlie@example.com": ["staff"],
	"diana@example.com": ["user"]
}

# Pet ownership data (this would typically come from external data)
pet_owners := {
	"pet113-987": "bob@example.com",
	"pet456-789": "alice@example.com",
	"pet789-012": "charlie@example.com"
}

# Enhanced policy with more comprehensive checks

# Allow veterinarians to update medical records
allow if {
	input.method == "PUT"
	some petid
	input.path = ["pets", petid, "medical"]
	is_veterinarian(input.user)
}

# Allow groomers to update grooming records
allow if {
	input.method == "PUT"
	some petid
	input.path = ["pets", petid, "grooming"]
	is_groomer(input.user)
}

# Deny access to sensitive fields for non-staff
deny if {
	input.method == "GET"
	some petid
	input.path = ["pets", petid, "medical"]
	not is_staff(input.user)
	not is_veterinarian(input.user)
}

deny if {
	input.method == "GET"
	some petid
	input.path = ["pets", petid, "billing"]
	not is_staff(input.user)
	not input.user == input.owner
}

# Helper functions for additional roles

is_veterinarian(user) {
	user_roles[user][_] == "veterinarian"
}

is_groomer(user) {
	user_roles[user][_] == "groomer"
}

# Audit logging helper
allowed_actions := {
	"action": input.method,
	"resource": concat("/", input.path),
	"user": input.user,
	"allowed": allow,
	"reason": get_reason()
}

get_reason() := "owner_update" if {
	input.method == "PUT"
	input.user == input.owner
} else := "staff_access" if {
	is_staff(input.user)
} else := "veterinarian_access" if {
	is_veterinarian(input.user)
} else := "groomer_access" if {
	is_groomer(input.user)
} else := "denied"
