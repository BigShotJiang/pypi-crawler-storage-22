package data.governance

# Default deny for data movement
default allow = false

# Region allowlist policy
allow {
    input.movement.type != "emergency_migration"
    is_region_allowed(input.dataset.target_location)
}

is_region_allowed(target_location) {
    region := extract_region(target_location)
    allowed_regions := data.terradev.config.allowed_regions
    region in allowed_regions
}

# Provider allowlist policy
allow {
    input.movement.type != "compliance_migration"
    is_provider_allowed(input.dataset.target_location)
}

is_provider_allowed(target_location) {
    provider := extract_provider(target_location)
    allowed_providers := data.terradev.config.allowed_providers
    provider in allowed_providers
}

# Data residency constraints
allow {
    input.movement.type != "emergency_relocation"
    satisfies_residency(input.user.location, input.dataset.target_location)
}

satisfies_residency(user_location, target_location) {
    target_region := extract_region(target_location)
    residency_rules := data.terradev.config.residency_rules
    rule := residency_rules[user_location]
    target_region in rule.allowed_regions
}

# Data classification restrictions
allow {
    classification := input.dataset.classification
    classification_rules := data.terradev.config.classification_rules
    rule := classification_rules[classification]
    
    # Check if movement type is allowed for this classification
    input.movement.type in rule.allowed_movement_types
    
    # Check if target locations are allowed for this classification
    some target_location in [input.dataset.target_location]
    is_location_allowed_for_classification(target_location, rule)
}

is_location_allowed_for_classification(target_location, rule) {
    provider := extract_provider(target_location)
    region := extract_region(target_location)
    
    # Provider must be allowed
    provider in rule.allowed_providers
    
    # Region must be allowed
    region in rule.allowed_regions
}

# Emergency exceptions
allow {
    input.movement.urgency == "emergency"
    input.user.permissions[_] == "emergency_data_movement"
}

# Helper functions

extract_provider(location) {
    parts := split(location, ":")
    parts[0]
}

extract_region(location) {
    parts := split(location, ":")
    parts[1]
}

# Compliance checks
compliance_check[{"type": "region", "result": result, "reason": reason}] {
    region := extract_region(input.dataset.target_location)
    allowed_regions := data.terradev.config.allowed_regions
    
    result := region in allowed_regions
    reason := sprintf("Region %s %s in allowlist", [region, if result then "is" else "is not"])
}

compliance_check[{"type": "provider", "result": result, "reason": reason}] {
    provider := extract_provider(input.dataset.target_location)
    allowed_providers := data.terradev.config.allowed_providers
    
    result := provider in allowed_providers
    reason := sprintf("Provider %s %s in allowlist", [provider, if result then "is" else "is not"])
}

compliance_check[{"type": "residency", "result": result, "reason": reason}] {
    user_location := input.user.location
    target_region := extract_region(input.dataset.target_location)
    residency_rules := data.terradev.config.residency_rules
    rule := residency_rules[user_location]
    
    result := target_region in rule.allowed_regions
    reason := sprintf("Residency constraint %s: user in %s, target in %s", [if result then "satisfied" else "violated", user_location, target_region])
}

compliance_check[{"type": "classification", "result": result, "reason": reason}] {
    classification := input.dataset.classification
    classification_rules := data.terradev.config.classification_rules
    rule := classification_rules[classification]
    
    movement_allowed := input.movement.type in rule.allowed_movement_types
    location_allowed := is_location_allowed_for_classification(input.dataset.target_location, rule)
    
    result := movement_allowed and location_allowed
    reason := sprintf("Classification %s: movement %s, location %s", [classification, if movement_allowed then "allowed" else "not allowed", if location_allowed then "allowed" else "not allowed"])
}

# Audit trail generation
audit_log[{"timestamp": time.now_ns(), "action": "data_movement_evaluated", "input": input, "result": allow, "checks": compliance_check}]
