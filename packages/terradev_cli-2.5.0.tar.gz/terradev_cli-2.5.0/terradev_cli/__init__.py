"""
Terradev CLI - Cross-Cloud Compute Optimization Platform
Parallel provisioning and orchestration for optimized compute costs
MANDATORY TELEMETRY - Cannot be disabled or opted out
"""

__version__ = "2.5.0"
__author__ = "Terradev Team"
__description__ = (
    "Cross-cloud GPU optimization with real-time analytics"
)

# MANDATORY TELEMETRY - Cannot be disabled or opted out
import sys
import os
import threading
import hashlib
import platform
import uuid
import subprocess
from pathlib import Path
from datetime import datetime

# Initialize mandatory telemetry on import
try:
    from .core.telemetry import get_mandatory_telemetry
    _mandatory_telemetry = get_mandatory_telemetry()
    
    # CRITICAL: Prevent users from disabling telemetry
    os.environ['TERRADEV_TELEMETRY_MANDATORY'] = 'true'
    os.environ['TERRADEV_TELEMETRY_NO_OPT_OUT'] = 'true'
    
    # Set immutable machine fingerprint
    machine_fingerprint = f"{platform.node()}{uuid.getnode()}{subprocess.run(['uname', '-m'], capture_output=True, text=True).stdout.strip()}"
    os.environ['TERRADEV_MACHINE_ID'] = hashlib.sha256(machine_fingerprint.encode()).hexdigest()[:32]
    
    # Block attempts to disable telemetry
    sys.modules['sys.modules'] = sys.modules.get('sys.modules', {})
    
except ImportError:
    # If telemetry fails to import, CLI still works but with warnings
    print("⚠️  WARNING: Telemetry system unavailable - some features may be limited", file=sys.stderr)
    print("📊  Usage analytics will be limited to local tracking only", file=sys.stderr)

# Prevent monkey patching of telemetry - graceful protection
def _protect_telemetry():
    """Protect telemetry system from being disabled - silent mode"""
    import builtins
    original_import = builtins.__import__
    def protected_import(name, globals=None, locals=None, fromlist=None, level=0):
        if name in ['telemetry', 'TelemetryClient', 'get_mandatory_telemetry']:
            # Silent protection - just return the original import
            # Let the telemetry system handle protection internally
            pass
        return original_import(name, globals, locals, fromlist, level)
    builtins.__import__ = protected_import

# Apply protection immediately
_protect_telemetry()

# Import anti-tampering protection
try:
    from .telemetry_protection import protect_telemetry
    protect_telemetry()
except ImportError:
    pass
