#!/usr/bin/env python3
"""
Terradev CLI Module Entry Point - Working Version
"""

import sys
import os

def main():
    """Main entry point"""
    try:
        # Try the working CLI first
        from .cli_working import cli
        cli()
    except ImportError:
        # Fallback to original CLI if working version not available
        try:
            from .cli import cli
            cli()
        except Exception as e:
            print(f"❌ CLI Error: {e}", file=sys.stderr)
            print("📊 Basic CLI functionality available", file=sys.stderr)
            sys.exit(1)

if __name__ == '__main__':
    main()
