#!/usr/bin/env python3
"""
MANDATORY Terradev Telemetry & License Server Integration
Cannot be opted out - baked into CLI core for compliance and business intelligence
"""

import json
import time
import hashlib
import threading
import platform
import uuid
import subprocess
import os
import sys
from typing import Dict, Any
from pathlib import Path
import requests
from datetime import datetime

class MandatoryTelemetryClient:
    """MANDATORY telemetry client - cannot be disabled or opted out"""
    
    def __init__(self):
        # Generate immutable machine ID that cannot be changed
        self.machine_id = self._generate_immutable_id()
        self.install_id = self._get_or_generate_install_id()
        self.api_key = f"tdv_mandatory_{hashlib.sha256(f'{self.machine_id}{self.install_id}'.encode()).hexdigest()[:32]}"
        
        # Telemetry server endpoints
        self.base_url = "https://api.terradev.cloud"  # Production
        self.fallback_url = "http://34.207.59.52:8080"  # AWS production backup
        
        # Background telemetry thread
        self._telemetry_thread = None
        self._stop_telemetry = threading.Event()
        
        # Start mandatory telemetry collection
        self._start_mandatory_telemetry()
    
    def _generate_immutable_id(self) -> str:
        """Generate immutable machine fingerprint that cannot be changed"""
        try:
            # Combine multiple hardware identifiers
            mac = hex(uuid.getnode()).upper()
            cpu_info = subprocess.run(['uname', '-m'], capture_output=True, text=True).stdout.strip()
            machine_id = subprocess.run(['uname', '-n'], capture_output=True, text=True).stdout.strip()
            
            # Create immutable hash
            fingerprint = f"{mac}:{cpu_info}:{machine_id}:{platform.system()}"
            return hashlib.sha256(fingerprint.encode()).hexdigest()[:32]
        except:
            # Fallback to basic machine ID
            return hashlib.sha256(f"{platform.node()}{uuid.getnode()}".encode()).hexdigest()[:32]
    
    def _get_or_generate_install_id(self) -> str:
        """Get or generate installation ID (persistent across reinstalls)"""
        install_file = Path.home() / ".terradev" / "install_id.json"
        
        if install_file.exists():
            try:
                with open(install_file, 'r') as f:
                    data = json.load(f)
                    return data.get('install_id', self._generate_new_install_id())
            except:
                pass
        
        # Generate new install ID
        install_id = self._generate_new_install_id()
        
        # Save with hidden attributes to prevent deletion
        install_file.parent.mkdir(parents=True, exist_ok=True)
        with open(install_file, 'w') as f:
            json.dump({
                'install_id': install_id,
                'created': datetime.now().isoformat(),
                'machine_hash': self.machine_id,
                'protected': True
            }, f)
        
        # Set file to be difficult to delete
        try:
            os.chmod(install_file, 0o444)  # Read-only
        except:
            pass
        
        return install_id
    
    def _generate_new_install_id(self) -> str:
        """Generate new installation ID"""
        timestamp = datetime.now().isoformat()
        random_component = uuid.uuid4().hex[:16]
        return hashlib.sha256(f"{timestamp}{random_component}{self.machine_id}".encode()).hexdigest()[:32]
    
    def _start_mandatory_telemetry(self):
        """Start mandatory background telemetry collection"""
        if self._telemetry_thread is None or not self._telemetry_thread.is_alive():
            self._telemetry_thread = threading.Thread(target=self._telemetry_loop, daemon=True)
            self._telemetry_thread.start()
    
    def _telemetry_loop(self):
        """Background telemetry collection loop"""
        while not self._stop_telemetry.is_set():
            try:
                self._send_heartbeat()
                self._check_license_compliance()
                time.sleep(300)  # Every 5 minutes
            except Exception:
                time.sleep(60)  # Retry after 1 minute on error
    
    def _send_heartbeat(self):
        """Send mandatory heartbeat to telemetry server"""
        try:
            payload = {
                'machine_id': self.machine_id,
                'install_id': self.install_id,
                'api_key': self.api_key,
                'action': 'heartbeat',
                'timestamp': datetime.now().isoformat(),
                'version': self._get_cli_version(),
                'platform': platform.system(),
                'python_version': platform.python_version(),
                'details': {
                    'mandatory': True,
                    'opt_out': False,
                    'compliance': 'enforced'
                }
            }
            
            # Try primary server first
            self._send_telemetry(payload, self.base_url)
            
        except Exception as e:
            print(f"Telemetry heartbeat failed: {e}", file=sys.stderr)
    
    def _send_telemetry(self, payload: Dict[str, Any], url: str):
        """Send telemetry data to server"""
        try:
            response = requests.post(
                f"{url}/log-usage",
                json=payload,
                timeout=10,
                headers={'User-Agent': f'Terradev-CLI/{self._get_cli_version()}'}
            )
            
            if response.status_code != 200:
                # Try fallback server
                if url != self.fallback_url:
                    self._send_telemetry(payload, self.fallback_url)
                    
        except Exception:
            # Try fallback server
            if url != self.fallback_url:
                try:
                    self._send_telemetry(payload, self.fallback_url)
                except:
                    pass
    
    def _get_cli_version(self) -> str:
        """Get CLI version"""
        try:
            return "2.5.0"
        except:
            return "2.5.0"
    
    def _check_license_compliance(self):
        """Check license compliance and enforce tier limits"""
        try:
            payload = {
                'machine_id': self.machine_id,
                'install_id': self.install_id,
                'api_key': self.api_key,
                'action': 'compliance_check',
                'timestamp': datetime.now().isoformat(),
                'details': {
                    'mandatory': True,
                    'enforcement': 'active'
                }
            }
            
            response = requests.post(
                f"{self.base_url}/check-license",
                json=payload,
                timeout=10
            )
            
            if response.status_code == 200:
                result = response.json()
                if not result.get('allowed', True):
                    self._enforce_paywall(result)
                    
        except Exception:
            pass  # Continue with local checks if server unavailable
    
    def _enforce_paywall(self, license_result: Dict[str, Any]):
        """Enforce paywall when limits exceeded"""
        tier = license_result.get('tier', 'research')
        limit = license_result.get('limit', 10)
        usage = license_result.get('usage', 0)
        
        print(f"\n{'='*60}")
        print(f"🚫 TIER LIMIT REACHED - UPGRADE REQUIRED")
        print(f"{'='*60}")
        print(f"Current Tier: {tier.title()}")
        print(f"Limit: {limit} provisions/month")
        print(f"Used: {usage} provisions")
        print(f"\n💰 UPGRADE OPTIONS:")
        print(f"Research+: $49/month - 80 provisions")
        print(f"Enterprise: $199/month - Unlimited provisions")
        print(f"\n🔗 Upgrade: https://terradev.cloud/pricing")
        print(f"{'='*60}")
        
        # Exit with error code to prevent usage
        sys.exit(1)
    
    def log_action(self, action: str, details: Dict[str, Any] = None):
        """Log user action (mandatory)"""
        payload = {
            'machine_id': self.machine_id,
            'install_id': self.install_id,
            'api_key': self.api_key,
            'action': action,
            'timestamp': datetime.now().isoformat(),
            'details': details or {},
            'mandatory': True
        }
        
        # Send asynchronously to avoid blocking CLI
        threading.Thread(target=self._send_telemetry, args=(payload, self.base_url), daemon=True).start()
    
    def check_license(self, action: str = 'provision') -> Dict[str, Any]:
        """Check license (mandatory - cannot be bypassed)"""
        try:
            payload = {
                'machine_id': self.machine_id,
                'install_id': self.install_id,
                'api_key': self.api_key,
                'action': action,
                'timestamp': datetime.now().isoformat(),
                'details': {
                    'mandatory': True,
                    'enforcement': 'active'
                }
            }
            
            response = requests.post(
                f"{self.base_url}/check-license",
                json=payload,
                timeout=5
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                # Try fallback server
                response = requests.post(
                    f"{self.fallback_url}/check-license",
                    json=payload,
                    timeout=5
                )
                if response.status_code == 200:
                    return response.json()
                    
        except Exception:
            pass
        
        # Fallback to local enforcement if server unavailable
        return self._local_license_check(action)
    
    def _local_license_check(self, action: str) -> Dict[str, Any]:
        """Local license check when server unavailable"""
        try:
            # Default to allowed if all checks fail
            return {
                'allowed': True,
                'tier': 'research',
                'limit': 10,
                'usage': 0,
                'reason': 'Default allowed'
            }
        except:
            pass

# Global mandatory telemetry instance (cannot be disabled)
_mandatory_telemetry = None

def get_mandatory_telemetry() -> MandatoryTelemetryClient:
    """Get global mandatory telemetry instance"""
    global _mandatory_telemetry
    if _mandatory_telemetry is None:
        _mandatory_telemetry = MandatoryTelemetryClient()
    return _mandatory_telemetry

# Alias for backward compatibility
TelemetryClient = MandatoryTelemetryClient
