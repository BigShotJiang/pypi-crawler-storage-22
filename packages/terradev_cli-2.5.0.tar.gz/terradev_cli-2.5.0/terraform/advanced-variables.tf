# Advanced Variables for Parallel Provisioning

variable "provisioning_mode" {
  description = "Provisioning mode: sticky_cloud, data_mesh, or hybrid_dedicated"
  type        = string
  default     = "sticky_cloud"
  
  validation {
    condition = contains(["sticky_cloud", "data_mesh", "hybrid_dedicated"], var.provisioning_mode)
    error_message = "Provisioning mode must be one of: sticky_cloud, data_mesh, hybrid_dedicated."
  }
}

variable "gpu_type" {
  description = "GPU type for provisioning"
  type        = string
  default     = "A100"
  
  validation {
    condition = contains(["A100", "H100", "A10G", "V100"], var.gpu_type)
    error_message = "GPU type must be one of: A100, H100, A10G, V100."
  }
}

variable "data_location" {
  description = "Data location for locality optimization (e.g., s3://bucket/data)"
  type        = string
  default     = null
}

variable "sticky_cloud_mode" {
  description = "Enable sticky cloud mode to minimize egress costs"
  type        = bool
  default     = true
}

variable "enable_smart_cancellation" {
  description = "Enable intelligent cancellation to prevent waste"
  type        = bool
  default     = true
}

variable "enable_redis_cache" {
  description = "Enable Redis distributed caching"
  type        = bool
  default     = true
}

variable "enable_consul_sd" {
  description = "Enable Consul service discovery"
  type        = bool
  default     = false
}

# Rate limiting configuration
variable "aws_rate_limit_per_second" {
  description = "AWS API rate limit per second"
  type        = number
  default     = 10
}

variable "gcp_rate_limit_per_second" {
  description = "GCP API rate limit per second"
  type        = number
  default     = 8
}

variable "azure_rate_limit_per_second" {
  description = "Azure API rate limit per second"
  type        = number
  default     = 6
}

variable "runpod_rate_limit_per_second" {
  description = "RunPod API rate limit per second"
  type        = number
  default     = 20
}

variable "lambda_rate_limit_per_second" {
  description = "Lambda Labs API rate limit per second"
  type        = number
  default     = 15
}

variable "coreweave_rate_limit_per_second" {
  description = "CoreWeave API rate limit per second"
  type        = number
  default     = 12
}

# Caching configuration
variable "cache_ttl_seconds" {
  description = "Cache TTL in seconds"
  type        = number
  default     = 86400  # 24 hours
}

variable "cache_max_size_gb" {
  description = "Maximum cache size in GB"
  type        = number
  default     = 100
}

variable "cache_eviction_policy" {
  description = "Cache eviction policy"
  type        = string
  default     = "lru"
  
  validation {
    condition = contains(["lru", "lfu", "random"], var.cache_eviction_policy)
    error_message = "Cache eviction policy must be one of: lru, lfu, random."
  }
}

# Redis configuration
variable "redis_shard_count" {
  description = "Number of Redis shards"
  type        = number
  default     = 3
}

variable "redis_node_type" {
  description = "Redis node type"
  type        = string
  default     = "cache.r6.large"
}

# Consul configuration
variable "consul_datacenter" {
  description = "Consul datacenter name"
  type        = string
  default     = "dc1"
}

variable "consul_server_count" {
  description = "Number of Consul servers"
  type        = number
  default     = 3
}

# Provider configuration
variable "enable_aws" {
  description = "Enable AWS provider"
  type        = bool
  default     = true
}

variable "enable_gcp" {
  description = "Enable GCP provider"
  type        = bool
  default     = true
}

variable "enable_azure" {
  description = "Enable Azure provider"
  type        = bool
  default     = true
}

variable "enable_runpod" {
  description = "Enable RunPod provider"
  type        = bool
  default     = false
}

variable "enable_lambda" {
  description = "Enable Lambda Labs provider"
  type        = bool
  default     = false
}

variable "enable_coreweave" {
  description = "Enable CoreWeave provider"
  type        = bool
  default     = false
}

# Instance counts
variable "aws_instance_count" {
  description = "Number of AWS instances to provision"
  type        = number
  default     = 1
}

variable "gcp_instance_count" {
  description = "Number of GCP instances to provision"
  type        = number
  default     = 1
}

variable "azure_instance_count" {
  description = "Number of Azure instances to provision"
  type        = number
  default     = 1
}

# AWS Configuration
variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "us-east-1"
}

variable "aws_ami_map" {
  description = "AWS AMI mapping for GPU types"
  type        = map(string)
  default = {
    "A100" = "ami-0c02fb55956c7d3d5"
    "H100" = "ami-0c02fb55956c7d3d5"
    "A10G" = "ami-0c02fb55956c7d3d5"
    "V100" = "ami-0c02fb55956c7d3d5"
  }
}

variable "aws_instance_types" {
  description = "AWS instance types for GPU types"
  type        = map(string)
  default = {
    "A100" = "p4d.24xlarge"
    "H100" = "p5.48xlarge"
    "A10G" = "g5.xlarge"
    "V100" = "p3.2xlarge"
  }
}

# GCP Configuration
variable "gcp_region" {
  description = "GCP region"
  type        = string
  default     = "us-central1"
}

variable "gcp_zone" {
  description = "GCP zone"
  type        = string
  default     = "us-central1-a"
}

variable "gcp_project_id" {
  description = "GCP project ID"
  type        = string
  default     = "terradev-advanced"
}

variable "gcp_image_map" {
  description = "GCP image mapping for GPU types"
  type        = map(string)
  default = {
    "A100" = "deeplearning-platform-release"
    "H100" = "deeplearning-platform-release"
    "A10G" = "deeplearning-platform-release"
    "V100" = "deeplearning-platform-release"
  }
}

variable "gcp_instance_types" {
  description = "GCP machine types for GPU types"
  type        = map(string)
  default = {
    "A100" = "a2-highgpu-1g"
    "H100" = "a3-highgpu-8g"
    "A10G" = "a2-highgpu-1g"
    "V100" = "n1-standard-4"
  }
}

variable "gcp_gpu_types" {
  description = "GCP accelerator types"
  type        = map(string)
  default = {
    "A100" = "nvidia-tesla-a100"
    "H100" = "nvidia-tesla-h100"
    "A10G" = "nvidia-tesla-a10g"
    "V100" = "nvidia-tesla-v100"
  }
}

# Azure Configuration
variable "azure_region" {
  description = "Azure region"
  type        = string
  default     = "East US"
}

variable "azure_subscription_id" {
  description = "Azure subscription ID"
  type        = string
  default     = ""
}

variable "azure_instance_types" {
  description = "Azure VM sizes for GPU types"
  type        = map(string)
  default = {
    "A100" = "Standard_NC48ads_A100_v4"
    "H100" = "Standard_ND96isr_H100_v5"
    "A10G" = "Standard_NC4as_T4_v3"
    "V100" = "Standard_NC6s_v3"
  }
}

variable "azure_plan_map" {
  description = "Azure marketplace plans for GPU instances"
  type        = map(object({
    name      = string
    publisher = string
    product   = string
  }))
  default = {
    "A100" = {
      name      = "nvidia-ai-enterprise"
      publisher = "nvidia"
      product   = "nvidia-ai-enterprise"
    }
    "H100" = {
      name      = "nvidia-ai-enterprise"
      publisher = "nvidia"
      product   = "nvidia-ai-enterprise"
    }
    "A10G" = {
      name      = "nvidia-ai-enterprise"
      publisher = "nvidia"
      product   = "nvidia-ai-enterprise"
    }
    "V100" = {
      name      = "nvidia-ai-enterprise"
      publisher = "nvidia"
      product   = "nvidia-ai-enterprise"
    }
  }
}

# Performance tuning
variable "race_timeout" {
  description = "Race timeout in seconds"
  type        = number
  default     = 300
}

variable "max_spot_price" {
  description = "Maximum spot price per hour"
  type        = number
  default     = 3.00
}

variable "parallel_creation_delay" {
  description = "Delay between parallel resource creation (for testing)"
  type        = number
  default     = 0
}

variable "cancellation_delay_seconds" {
  description = "Delay before cancellation to prevent race conditions"
  type        = number
  default     = 15
}

# Environment
variable "environment" {
  description = "Environment name"
  type        = string
  default     = "production"
  
  validation {
    condition = contains(["development", "staging", "production"], var.environment)
    error_message = "Environment must be one of: development, staging, production."
  }
}

# Cost optimization
variable "enable_cost_optimization" {
  description = "Enable cost optimization features"
  type        = bool
  default     = true
}

variable "max_egress_cost_per_hour" {
  description = "Maximum egress cost per hour before switching providers"
  type        = number
  default     = 5.00
}

variable "enable_waste_prevention" {
  description = "Enable waste prevention features"
  type        = bool
  default     = true
}

# Monitoring and logging
variable "enable_detailed_logging" {
  description = "Enable detailed logging"
  type        = bool
  default     = true
}

variable "enable_metrics_collection" {
  description = "Enable metrics collection"
  type        = bool
  default     = true
}

variable "log_retention_days" {
  description = "Log retention in days"
  type        = number
  default     = 30
}

# Security
variable "enable_encryption_at_rest" {
  description = "Enable encryption at rest"
  type        = bool
  default     = true
}

variable "enable_encryption_in_transit" {
  description = "Enable encryption in transit"
  type        = bool
  default     = true
}

variable "enable_vpc_flow_logs" {
  description = "Enable VPC flow logs"
  type        = bool
  default     = false
}
