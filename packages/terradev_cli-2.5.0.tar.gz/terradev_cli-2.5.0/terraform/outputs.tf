# Outputs for Terradev SkyPilot Wrapper infrastructure

output "infrastructure_config" {
  description = "Infrastructure configuration for Terradev wrapper"
  value       = local.infrastructure_config
}

output "aws_config" {
  description = "AWS infrastructure configuration"
  value = {
    region               = var.aws_region
    vpc_id              = aws_vpc.main.id
    subnet_ids          = aws_subnet.private[*].id
    security_group_id   = aws_security_group.gpu_workload.id
    iam_instance_profile = aws_iam_instance_profile.skypilot.name
    s3_bucket           = aws_s3_bucket.terradev_data.bucket
    sns_topic_arn       = aws_sns_topic.latency_alerts.arn
  }
}

output "gcp_config" {
  description = "GCP infrastructure configuration"
  value = {
    region      = var.gcp_region
    network_id  = google_compute_network.vpc_network.id
    subnet_id   = google_compute_subnetwork.subnet.id
    project_id  = var.gcp_project_id
  }
}

output "azure_config" {
  description = "Azure infrastructure configuration"
  value = {
    region                = var.azure_region
    resource_group_name   = azurerm_resource_group.main.name
    virtual_network_name  = azurerm_virtual_network.main.name
    subnet_name           = azurerm_subnet.main.name
    nsg_name              = azurerm_network_security_group.main.name
  }
}

output "monitoring_config" {
  description = "Monitoring and alerting configuration"
  value = {
    latency_threshold     = var.latency_threshold
    gpu_latency_threshold = var.gpu_latency_threshold
    sns_topic_arn        = aws_sns_topic.latency_alerts.arn
    cloudwatch_alarms = {
      high_latency     = aws_cloudwatch_metric_alarm.high_latency.name
      high_gpu_latency = aws_cloudwatch_metric_alarm.high_gpu_latency.name
    }
  }
}

output "attribution_storage" {
  description = "Storage configuration for attribution data"
  value = {
    s3_bucket = aws_s3_bucket.terradev_data.bucket
  }
}

output "infrastructure_ready" {
  description = "Infrastructure readiness status"
  value = {
    timestamp = timestamp()
    status    = "ready"
    providers = ["aws", "gcp", "azure"]
    features  = ["latency_monitoring", "gpu_monitoring", "attribution_tracking"]
  }
}
