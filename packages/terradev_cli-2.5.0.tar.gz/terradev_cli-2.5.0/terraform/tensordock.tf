# Terraform Configuration for TensorDock Provider
# Production-ready infrastructure as code for Terradev

terraform {
  required_version = ">= 1.0"
  required_providers {
    tensordock = {
      source  = "terraform-providers/tensordock"
      version = "~> 1.0"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.0"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 2.0"
    }
  }
}

# Configure TensorDock Provider
provider "tensordock" {
  client_id = var.tensordock_client_id
  api_token = var.tensordock_api_token
  
  # Rate limiting configuration
  rate_limit {
    requests_per_second = 10
    burst = 20
  }
  
  # Retry configuration
  retry {
    max_attempts = 3
    min_delay = "1s"
    max_delay = "10s"
  }
}

# Variables
variable "tensordock_client_id" {
  type        = string
  description = "TensorDock Client ID"
  sensitive   = true
}

variable "tensordock_api_token" {
  type        = string
  description = "TensorDock API Token"
  sensitive   = true
}

variable "environment" {
  type        = string
  default     = "development"
  description = "Environment name (development, staging, production)"
  
  validation {
    condition = contains(["development", "staging", "production"], var.environment)
    error_message = "Environment must be one of: development, staging, production."
  }
}

variable "region" {
  type        = string
  default     = "us-east"
  description = "TensorDock region/location"
}

variable "ssh_public_key" {
  type        = string
  description = "SSH public key for instance access"
  default     = ""
}

variable "enable_monitoring" {
  type        = bool
  default     = true
  description = "Enable monitoring and logging"
}

variable "enable_auto_scaling" {
  type        = bool
  default     = false
  description = "Enable auto-scaling for production"
}

# Local values for configuration
locals {
  environment_config = {
    development = {
      instance_count = 1
      instance_type = "ml-small"
      min_nodes = 1
      max_nodes = 2
      enable_monitoring = false
      enable_auto_scaling = false
    }
    staging = {
      instance_count = 2
      instance_type = "ml-medium"
      min_nodes = 1
      max_nodes = 4
      enable_monitoring = true
      enable_auto_scaling = false
    }
    production = {
      instance_count = 3
      instance_type = "ml-large"
      min_nodes = 2
      max_nodes = 10
      enable_monitoring = true
      enable_auto_scaling = true
    }
  }
  
  config = local.environment_config[var.environment]
  
  # Cloud-init configuration
  cloud_init_config = {
    package_update = true
    package_upgrade = true
    packages = [
      "python3", "python3-pip", "python3-venv", "git", "curl", "wget",
      "build-essential", "cuda-toolkit", "nvidia-driver-535",
      "docker.io", "docker-compose", "nginx", "htop", "prometheus-node-exporter"
    ]
    runcmd = [
      "systemctl enable docker",
      "usermod -aG docker ubuntu",
      "pip3 install --upgrade pip",
      "pip3 install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118",
      "pip3 install tensorflow-gpu==2.13.0",
      "pip3 install jupyterlab pandas numpy scikit-learn matplotlib seaborn",
      "echo '🚀 Terradev TensorDock Instance Ready!' > /etc/motd"
    ]
    write_files = [
      {
        path = "/etc/motd"
        content = "🚀 Welcome to Terradev TensorDock Instance!\n🔥 GPU Accelerated Machine Learning Ready\n💡 Environment: ${var.environment}\n📊 Monitoring: ${local.config.enable_monitoring ? "Enabled" : "Disabled"}"
        owner = "root:root"
        permissions = "0644"
      },
      {
        path = "/home/ubuntu/.bashrc"
        content = "export PATH=$PATH:/usr/local/cuda/bin\nexport LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/cuda/lib64\nexport CUDA_VISIBLE_DEVICES=0,1\nalias terradev-status='curl -s http://localhost:8080/health'\n"
        owner = "ubuntu:ubuntu"
        permissions = "0644"
      }
    ]
  }
}

# Resource: TensorDock Instance
resource "tensordock_instance" "ml_instances" {
  count = local.config.instance_count
  
  name = "${var.environment}-ml-${count.index + 1}"
  image = "ubuntu2404"
  
  resources {
    vcpu_count = lookup({
      "ml-small" = 4
      "ml-medium" = 8
      "ml-large" = 16
      "training" = 32
    }, local.config.instance_type, 8)
    
    ram_gb = lookup({
      "ml-small" = 16
      "ml-medium" = 32
      "ml-large" = 64
      "training" = 128
    }, local.config.instance_type, 32)
    
    storage_gb = lookup({
      "ml-small" = 100
      "ml-medium" = 200
      "ml-large" = 500
      "training" = 1000
    }, local.config.instance_type, 200)
    
    gpus = {
      "geforcertx4090-pcie-24gb" = {
        count = lookup({
          "ml-small" = 1
          "ml-medium" = 1
          "ml-large" = 2
          "training" = 4
        }, local.config.instance_type, 1)
      }
    }
  }
  
  location_id = var.region
  use_dedicated_ip = true
  
  # SSH key configuration
  ssh_key = var.ssh_public_key != "" ? var.ssh_public_key : null
  
  # Cloud-init configuration
  cloud_init = local.cloud_init_config
  
  # Tags
  tags = {
    Environment = var.environment
    Project = "Terradev"
    InstanceType = local.config.instance_type
    ManagedBy = "Terraform"
  }
  
  # Wait for instance to be ready
  wait_for_ready = true
  
  # Timeouts
  timeouts {
    create = "15m"
    delete = "10m"
    update = "10m"
  }
}

# Resource: Kubernetes Namespace
resource "kubernetes_namespace" "terradev" {
  count = var.enable_monitoring ? 1 : 0
  
  metadata {
    name = "terradev-${var.environment}"
    labels = {
      Environment = var.environment
      Project = "Terradev"
    }
  }
}

# Resource: Kubernetes ConfigMap for monitoring
resource "kubernetes_config_map" "monitoring" {
  count = var.enable_monitoring ? 1 : 0
  
  metadata {
    name = "monitoring-config"
    namespace = kubernetes_namespace.terradev[0].metadata[0].name
  }
  
  data = {
    "prometheus.yml" = <<-EOT
      global:
        scrape_interval: 15s
        evaluation_interval: 15s
      
      rule_files:
        - "terradev_rules.yml"
      
      scrape_configs:
        - job_name: 'terradev-nodes'
          static_configs:
            - targets: ${jsonencode([for instance in tensordock_instance.ml_instances : instance.ip_address])}
          metrics_path: /metrics
          scrape_interval: 30s
        
        - job_name: 'terradev-gpu'
          static_configs:
            - targets: ${jsonencode([for instance in tensordock_instance.ml_instances : instance.ip_address])}
          metrics_path: /gpu/metrics
          scrape_interval: 30s
    EOT
    
    "terradev_rules.yml" = <<-EOT
      groups:
        - name: terradev
          rules:
            - alert: InstanceDown
              expr: up == 0
              for: 5m
              labels:
                severity: critical
              annotations:
                summary: "Instance {{ $labels.instance }} is down"
                description: "Instance {{ $labels.instance }} has been down for more than 5 minutes."
            
            - alert: HighGPUUtilization
              expr: gpu_utilization > 0.9
              for: 10m
              labels:
                severity: warning
              annotations:
                summary: "High GPU utilization on {{ $labels.instance }}"
                description: "GPU utilization is above 90% for more than 10 minutes."
            
            - alert: HighMemoryUsage
              expr: (node_memory_MemTotal_bytes - node_memory_MemAvailable_bytes) / node_memory_MemTotal_bytes > 0.9
              for: 5m
              labels:
                severity: warning
              annotations:
                summary: "High memory usage on {{ $labels.instance }}"
                description: "Memory usage is above 90% for more than 5 minutes."
    EOT
  }
}

# Resource: Kubernetes Deployment
resource "kubernetes_deployment" "terradev_ml" {
  count = var.enable_monitoring ? 1 : 0
  
  metadata {
    name = "terradev-ml-${var.environment}"
    namespace = kubernetes_namespace.terradev[0].metadata[0].name
    labels = {
      app = "terradev-ml"
      environment = var.environment
    }
  }
  
  spec {
    replicas = local.config.instance_count
    
    selector {
      match_labels = {
        app = "terradev-ml"
      }
    }
    
    template {
      metadata {
        labels = {
          app = "terradev-ml"
          environment = var.environment
        }
      }
      
      spec {
        container {
          name = "ml-worker"
          image = "terradev/ml-worker:latest"
          
          port {
            container_port = 8080
            protocol = "TCP"
          }
          
          env {
            name = "ENVIRONMENT"
            value = var.environment
          }
          
          env {
            name = "INSTANCE_TYPE"
            value = local.config.instance_type
          }
          
          resources {
            requests = {
              cpu = lookup({
                "ml-small" = "2"
                "ml-medium" = "4"
                "ml-large" = "8"
                "training" = "16"
              }, local.config.instance_type, "4")
              
              memory = lookup({
                "ml-small" = "8Gi"
                "ml-medium" = "16Gi"
                "ml-large" = "32Gi"
                "training" = "64Gi"
              }, local.config.instance_type, "16Gi")
              
              # GPU requests
              "nvidia.com/gpu" = lookup({
                "ml-small" = "1"
                "ml-medium" = "1"
                "ml-large" = "2"
                "training" = "4"
              }, local.config.instance_type, "1")
            }
            
            limits = {
              cpu = lookup({
                "ml-small" = "4"
                "ml-medium" = "8"
                "ml-large" = "16"
                "training" = "32"
              }, local.config.instance_type, "8")
              
              memory = lookup({
                "ml-small" = "16Gi"
                "ml-medium" = "32Gi"
                "ml-large" = "64Gi"
                "training" = "128Gi"
              }, local.config.instance_type, "32Gi")
              
              # GPU limits
              "nvidia.com/gpu" = lookup({
                "ml-small" = "1"
                "ml-medium" = "1"
                "ml-large" = "2"
                "training" = "4"
              }, local.config.instance_type, "1")
            }
          }
          
          # Health checks
          liveness_probe {
            http_get {
              path = "/health"
              port = 8080
            }
            initial_delay_seconds = 30
            period_seconds = 10
            timeout_seconds = 5
            failure_threshold = 3
          }
          
          readiness_probe {
            http_get {
              path = "/ready"
              port = 8080
            }
            initial_delay_seconds = 5
            period_seconds = 5
            timeout_seconds = 3
            failure_threshold = 3
          }
        }
      }
    }
  }
}

# Resource: Horizontal Pod Autoscaler (if auto-scaling enabled)
resource "kubernetes_horizontal_pod_autoscaler" "terradev_ml_hpa" {
  count = var.enable_auto_scaling && var.enable_monitoring ? 1 : 0
  
  metadata {
    name = "terradev-ml-hpa-${var.environment}"
    namespace = kubernetes_namespace.terradev[0].metadata[0].name
  }
  
  spec {
    scale_target_ref {
      api_version = "apps/v1"
      kind = "Deployment"
      name = kubernetes_deployment.terradev_ml[0].metadata[0].name
    }
    
    min_replicas = local.config.min_nodes
    max_replicas = local.config.max_nodes
    
    metric {
      type = "Resource"
      resource {
        name = "cpu"
        target {
          type = "Utilization"
          average_utilization = 70
        }
      }
    }
    
    metric {
      type = "Resource"
      resource {
        name = "memory"
        target {
          type = "Utilization"
          average_utilization = 80
        }
      }
    }
    
    behavior {
      scale_up {
        stabilization_window_seconds = 60
        policy {
          type = "Percent"
          value = 100
          period_seconds = 15
        }
      }
      
      scale_down {
        stabilization_window_seconds = 300
        policy {
          type = "Percent"
          value = 10
          period_seconds = 60
        }
      }
    }
  }
}

# Resource: Kubernetes Service
resource "kubernetes_service" "terradev_ml" {
  count = var.enable_monitoring ? 1 : 0
  
  metadata {
    name = "terradev-ml-${var.environment}"
    namespace = kubernetes_namespace.terradev[0].metadata[0].name
    labels = {
      app = "terradev-ml"
      environment = var.environment
    }
  }
  
  spec {
    selector = {
      app = "terradev-ml"
    }
    
    port {
      port = 80
      target_port = 8080
      protocol = "TCP"
    }
    
    type = "ClusterIP"
  }
}

# Resource: Helm Release for monitoring stack
resource "helm_release" "monitoring" {
  count = var.enable_monitoring ? 1 : 0
  
  name       = "terradev-monitoring-${var.environment}"
  namespace  = kubernetes_namespace.terradev[0].metadata[0].name
  repository = "https://prometheus-community.github.io/helm-charts"
  chart      = "kube-prometheus-stack"
  version    = "45.0.0"
  
  values = [
    yamlencode({
      prometheus = {
        prometheusSpec = {
          retention = "7d"
          storageSpec = {
            volumeClaimTemplate = {
              spec = {
                storageClassName = "gp2"
                accessModes = ["ReadWriteOnce"]
                resources = {
                  requests = {
                    storage = "50Gi"
                  }
                }
              }
            }
          }
        }
      }
      
      grafana = {
        adminPassword = "terradev-admin-${var.environment}"
        persistence = {
          enabled = true
          size = "10Gi"
        }
        dashboards = {
          default = {
            terradev = {
              datasource = {
                type = "prometheus"
                uid = "prometheus"
              }
              panels = [
                {
                  title = "Instance Status"
                  type = "stat"
                  targets = [
                    {
                      expr = "up{job=\"terradev-nodes\"}"
                      legendFormat = "{{ instance }}"
                    }
                  ]
                },
                {
                  title = "GPU Utilization"
                  type = "graph"
                  targets = [
                    {
                      expr = "gpu_utilization"
                      legendFormat = "{{ instance }}"
                    }
                  ]
                },
                {
                  title = "Memory Usage"
                  type = "graph"
                  targets = [
                    {
                      expr = "(node_memory_MemTotal_bytes - node_memory_MemAvailable_bytes) / node_memory_MemTotal_bytes * 100"
                      legendFormat = "{{ instance }}"
                    }
                  ]
                }
              ]
            }
          }
        }
      }
      
      alertmanager = {
        enabled = true
        config = {
          global = {
            smtp_smarthost = "localhost:587"
            smtp_from = "alerts@terradev.com"
          }
          route = {
            group_by = ["alertname"]
            group_wait = "10s"
            group_interval = "10s"
            repeat_interval = "1h"
            receiver = "web.hook"
          }
          receivers = [
            {
              name = "web.hook"
              slack_configs = [
                {
                  api_url = "https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK"
                  channel = "#terradev-alerts"
                  title = "Terradev Alert: {{ .GroupLabels.alertname }}"
                  text = "{{ range .Alerts }}{{ .Annotations.description }}{{ end }}"
                }
              ]
            }
          ]
        }
      }
    })
  ]
  
  depends_on = [kubernetes_namespace.terradev]
}

# Outputs
output "instance_ids" {
  description = "TensorDock instance IDs"
  value       = [for instance in tensordock_instance.ml_instances : instance.id]
}

output "instance_ips" {
  description = "TensorDock instance IP addresses"
  value       = [for instance in tensordock_instance.ml_instances : instance.ip_address]
}

output "instance_names" {
  description = "TensorDock instance names"
  value       = [for instance in tensordock_instance.ml_instances : instance.name]
}

output "environment_config" {
  description = "Environment configuration"
  value       = local.config
}

output "kubernetes_namespace" {
  description = "Kubernetes namespace"
  value       = var.enable_monitoring ? kubernetes_namespace.terradev[0].metadata[0].name : null
}

output "monitoring_enabled" {
  description = "Whether monitoring is enabled"
  value       = var.enable_monitoring
}

output "total_hourly_cost" {
  description = "Total hourly cost for all instances"
  value       = length(tensordock_instance.ml_instances) * lookup({
    "ml-small" = 0.5
    "ml-medium" = 1.0
    "ml-large" = 2.0
    "training" = 8.0
  }, local.config.instance_type, 1.0)
}
