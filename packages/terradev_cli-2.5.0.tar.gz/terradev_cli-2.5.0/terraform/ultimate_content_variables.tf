# Ultimate Content-Addressed Variables
# Per-Provider Mirrors + Warm Pools + Cost Accounting

variable "content_hash" {
  description = "Content hash for deduplication and addressing"
  type        = string
  default     = ""
}

variable "model_configurations" {
  description = "Model configurations for warm pools"
  type = map(object({
    name           = string
    size_gb        = number
    download_count = number
    priority       = string
    content_hash   = string
  }))
  default = {}
}

variable "dataset_configurations" {
  description = "Dataset configurations for warm pools"
  type = map(object({
    name           = string
    size_gb        = number
    download_count = number
    priority       = string
    content_hash   = string
  }))
  default = {}
}

variable "request_config" {
  description = "Current request configuration"
  type = object({
    resource_type    = string
    gpu_required     = bool
    compute_required = bool
    storage_required = bool
    priority         = string
    max_cost_hour    = number
    data_location    = string
    mode             = string
  })
  default = {
    resource_type    = "model"
    gpu_required     = true
    compute_required = false
    storage_required = true
    priority         = "high"
    max_cost_hour    = 10.0
    data_location    = "hf://terradev/models/"
    mode             = "data_mesh"
  }
}

variable "provider_mirrors" {
  description = "Per-provider mirror configurations"
  type = map(object({
    storage_class  = string
    replication    = string
    cdn_endpoint   = string
    warm_pool_size = number
  }))
  default = {
    aws = {
      storage_class  = "STANDARD"
      replication    = "cross-region"
      cdn_endpoint   = "cloudfront"
      warm_pool_size = 100
    }
    gcp = {
      storage_class  = "STANDARD"
      replication    = "multi-region"
      cdn_endpoint   = "cloudcdn"
      warm_pool_size = 100
    }
    azure = {
      storage_class  = "Standard_LRS"
      replication    = "geo-redundant"
      cdn_endpoint   = "azure-cdn"
      warm_pool_size = 100
    }
    huggingface = {
      storage_class  = "free"
      replication    = "global"
      cdn_endpoint   = "hf-cdn"
      warm_pool_size = 1000
    }
    runpod = {
      storage_class  = "premium"
      replication    = "regional"
      cdn_endpoint   = "runpod-cdn"
      warm_pool_size = 50
    }
    lambda = {
      storage_class  = "standard"
      replication    = "multi-region"
      cdn_endpoint   = "lambda-cdn"
      warm_pool_size = 50
    }
    coreweave = {
      storage_class  = "standard"
      replication    = "regional"
      cdn_endpoint   = "coreweave-cdn"
      warm_pool_size = 50
    }
  }
}

variable "cost_accounting_config" {
  description = "Cost accounting configuration per provider"
  type = map(object({
    storage_cost_per_gb = number
    cdn_cost_per_gb     = number
    cache_miss_cost     = number
    warm_pool_cost      = number
  }))
  default = {
    aws = {
      storage_cost_per_gb = 0.023
      cdn_cost_per_gb     = 0.085
      cache_miss_cost     = 0.10
      warm_pool_cost      = 0.05
    }
    gcp = {
      storage_cost_per_gb = 0.020
      cdn_cost_per_gb     = 0.08
      cache_miss_cost     = 0.09
      warm_pool_cost      = 0.04
    }
    azure = {
      storage_cost_per_gb = 0.018
      cdn_cost_per_gb     = 0.082
      cache_miss_cost     = 0.11
      warm_pool_cost      = 0.06
    }
    huggingface = {
      storage_cost_per_gb = 0.000
      cdn_cost_per_gb     = 0.000
      cache_miss_cost     = 0.001
      warm_pool_cost      = 0.000
    }
    runpod = {
      storage_cost_per_gb = 0.025
      cdn_cost_per_gb     = 0.09
      cache_miss_cost     = 0.12
      warm_pool_cost      = 0.07
    }
    lambda = {
      storage_cost_per_gb = 0.022
      cdn_cost_per_gb     = 0.088
      cache_miss_cost     = 0.10
      warm_pool_cost      = 0.05
    }
    coreweave = {
      storage_cost_per_gb = 0.021
      cdn_cost_per_gb     = 0.087
      cache_miss_cost     = 0.09
      warm_pool_cost      = 0.04
    }
  }
}

variable "popular_models" {
  description = "Popular models for warm pools"
  type = map(object({
    content_hash   = string
    size_gb        = number
    download_count = number
    priority       = string
  }))
  default = {
    "gpt2" = {
      content_hash   = "a364b5c5d1b2c3d4e5f6a7b8c9d0e1f2"
      size_gb        = 1.5
      download_count = 1000000
      priority       = "high"
    }
    "bert-base-uncased" = {
      content_hash   = "b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7"
      size_gb        = 0.4
      download_count = 2000000
      priority       = "high"
    }
    "stable-diffusion-xl" = {
      content_hash   = "c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8"
      size_gb        = 6.9
      download_count = 500000
      priority       = "medium"
    }
  }
}

variable "warm_pool_config" {
  description = "Warm pool configuration"
  type = object({
    enabled              = bool
    auto_populate        = bool
    cache_hit_threshold  = number
    max_cache_age_hours  = number
    prewarm_popular      = bool
    content_deduplication = bool
  })
  default = {
    enabled              = true
    auto_populate        = true
    cache_hit_threshold  = 0.8
    max_cache_age_hours  = 720  # 30 days
    prewarm_popular      = true
    content_deduplication = true
  }
}

variable "race_coordination" {
  description = "Race coordination configuration"
  type = object({
    timeout_seconds      = number
    parallel_providers   = bool
    content_aware        = bool
    cost_optimization    = bool
    smart_cancellation   = bool
    backup_providers     = number
  })
  default = {
    timeout_seconds      = 60
    parallel_providers   = true
    content_aware        = true
    cost_optimization    = true
    smart_cancellation   = true
    backup_providers     = 2
  }
}

variable "monitoring_config" {
  description = "Monitoring and observability configuration"
  type = object({
    enable_metrics       = bool
    enable_logging       = bool
    enable_tracing      = bool
    cost_tracking       = bool
    performance_tracking = bool
    cache_analytics     = bool
  })
  default = {
    enable_metrics       = true
    enable_logging       = true
    enable_tracing      = true
    cost_tracking       = true
    performance_tracking = true
    cache_analytics     = true
  }
}

# AWS Configuration
variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "us-east-1"
}

variable "aws_credentials" {
  description = "AWS credentials"
  type = object({
    access_key = string
    secret_key = string
  })
  sensitive   = true
  default     = null
}

# GCP Configuration  
variable "gcp_project" {
  description = "GCP project ID"
  type        = string
  default     = ""
}

variable "gcp_region" {
  description = "GCP region"
  type        = string
  default     = "us-central1"
}

variable "gcp_credentials" {
  description = "GCP credentials"
  type        = string
  sensitive   = true
  default     = null
}

# Azure Configuration
variable "azure_location" {
  description = "Azure location"
  type        = string
  default     = "East US"
}

variable "azure_credentials" {
  description = "Azure credentials"
  type = object({
    subscription_id = string
    tenant_id       = string
    client_id       = string
    client_secret   = string
  })
  sensitive   = true
  default     = null
}

# HuggingFace Configuration
variable "huggingface_token" {
  description = "HuggingFace API token"
  type        = string
  sensitive   = true
  default     = ""
}

# RunPod Configuration
variable "runpod_api_key" {
  description = "RunPod API key"
  type        = string
  sensitive   = true
  default     = ""
}

# Lambda Labs Configuration
variable "lambda_api_key" {
  description = "Lambda Labs API key"
  type        = string
  sensitive   = true
  default     = ""
}

# CoreWeave Configuration
variable "coreweave_api_token" {
  description = "CoreWeave API token"
  type        = string
  sensitive   = true
  default     = ""
}
