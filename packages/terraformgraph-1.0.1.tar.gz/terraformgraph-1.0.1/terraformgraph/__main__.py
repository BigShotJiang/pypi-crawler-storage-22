"""Entry point for running as a module: python -m terraform_diagram"""

from .main import main

if __name__ == '__main__':
    main()
