import logging
import os
from logging.handlers import TimedRotatingFileHandler

# 配置日志
def setup_logger(app_name="MyApp", log_dir="./logs"):
    os.makedirs(log_dir, exist_ok=True)
    log_filename = os.path.join(log_dir, f'{app_name}.log')  # 固定名字，滚动文件自动加日期
    logger = logging.getLogger(app_name)
    logger.setLevel(logging.DEBUG)

    # 每天生成一个新文件，保留30天
    file_handler = TimedRotatingFileHandler(
        log_filename, when='midnight', interval=1, backupCount=30, encoding='utf-8'
    )
    file_handler.setLevel(logging.DEBUG)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)

    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    logger.handlers = []
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger