import pymysql
import traceback

import pymysql
from pymysql.cursors import DictCursor

class MysqlUtil:
    def __init__(self, host, user, password, database, port=3306, dict_result=False, debug=True):
        """
        初始化数据库连接
        :param dict_result: 是否返回 dict
        :param debug: 是否打印 SQL 调试信息
        """
        self.conn_params = {
            "host": host,
            "user": user,
            "password": password,
            "database": database,
            "port": port,
            "charset": "utf8mb4",
            "autocommit": False,  # 手动事务管理
        }
        if dict_result:
            self.conn_params["cursorclass"] = DictCursor

        self.conn = None
        self.debug = debug
        self._connect()

    def _connect(self):
        """建立连接"""
        self.conn = pymysql.connect(**self.conn_params)

    def _ensure_connection(self):
        """确保连接可用，失效时自动重连"""
        try:
            self.conn.ping(reconnect=True)
        except Exception:
            self._connect()

    def _execute(self, func, sql=None, params=None):
        """
        通用执行器，保证 commit/rollback
        """
        self._ensure_connection()
        try:
            if self.debug and sql:
                # print(f"[DEBUG SQL] {sql} | params={params}")
                pass
            result = func()
            self.conn.commit()
            return result
        except Exception:
            traceback.print_exc()
            self.conn.rollback()
            raise

    def execute(self, sql, params=None):
        """执行单条增删改"""
        def run():
            with self.conn.cursor() as cursor:
                return cursor.execute(sql, params or ())
        return self._execute(run, sql, params)

    def execute_by_sqls(self, sqls):
        """执行多条 SQL"""
        def run():
            with self.conn.cursor() as cursor:
                for sql in sqls:
                    if self.debug:
                        print(f"[DEBUG SQL] {sql}")
                    cursor.execute(sql)
        return self._execute(run)

    def executemany(self, sql, param_list):
        """批量执行"""
        def run():
            with self.conn.cursor() as cursor:
                return cursor.executemany(sql, param_list)
        return self._execute(run, sql, param_list)

    def fetchone(self, sql, params=None):
        """查询一条"""
        def run():
            with self.conn.cursor() as cursor:
                cursor.execute(sql, params or ())
                return cursor.fetchone()
        return self._execute(run, sql, params)

    def fetchall(self, sql, params=None):
        """查询多条"""
        def run():
            with self.conn.cursor() as cursor:
                cursor.execute(sql, params or ())
                return cursor.fetchall()
        return self._execute(run, sql, params)

    def close(self):
        """关闭连接"""
        if self.conn:
            self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

