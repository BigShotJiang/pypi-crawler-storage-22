from datetime import datetime, date, timedelta
import calendar
import re

class DateUtils:
    """企业级 Python 日期工具类"""

    COMMON_FORMATS = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%d",
        "%d/%m/%Y",
        "%d-%m-%Y",
        "%Y/%m/%d",
    ]

    # -------------------- 基础获取 --------------------
    @staticmethod
    def now(fmt="%Y-%m-%d %H:%M:%S"):
        """当前时间"""
        return datetime.now().strftime(fmt)

    @staticmethod
    def today(fmt="%Y-%m-%d"):
        """今天"""
        return date.today().strftime(fmt)

    @staticmethod
    def datetime_now():
        """返回datetime对象"""
        return datetime.now()

    @staticmethod
    def date_today():
        """返回date对象"""
        return date.today()

    # -------------------- 字符串与datetime互转 --------------------
    @staticmethod
    def parse(date_str, fmt=None):
        """尝试多种格式解析字符串"""
        if isinstance(date_str, (int, float)):
            return datetime.fromtimestamp(date_str)
        if isinstance(date_str, datetime):
            return date_str
        if fmt:
            return datetime.strptime(date_str, fmt)
        for f in DateUtils.COMMON_FORMATS:
            try:
                return datetime.strptime(date_str, f)
            except:
                continue
        raise ValueError(f"无法解析日期: {date_str}")

    @staticmethod
    def format(dt, fmt="%Y-%m-%d %H:%M:%S"):
        if isinstance(dt, str):
            dt = DateUtils.parse(dt)
        return dt.strftime(fmt)

    @staticmethod
    def to_timestamp(dt):
        dt = DateUtils.parse(dt) if isinstance(dt, (str, int, float)) else dt
        return int(dt.timestamp())

    @staticmethod
    def from_timestamp(ts):
        return datetime.fromtimestamp(ts)

    # -------------------- 日期加减 --------------------
    @staticmethod
    def add_days(dt, days):
        dt = DateUtils.parse(dt)
        return dt + timedelta(days=days)

    @staticmethod
    def add_seconds(dt, seconds, ft):
        dt = DateUtils.parse(dt, ft)
        return dt + timedelta(seconds=seconds)

    @staticmethod
    def add_months(dt, months):
        dt = DateUtils.parse(dt)
        month = dt.month - 1 + months
        year = dt.year + month // 12
        month = month % 12 + 1
        day = min(dt.day, calendar.monthrange(year, month)[1])
        return dt.replace(year=year, month=month, day=day)

    @staticmethod
    def add_years(dt, years):
        dt = DateUtils.parse(dt)
        try:
            return dt.replace(year=dt.year + years)
        except ValueError:
            # 闰年2月29日处理
            return dt.replace(month=2, day=28, year=dt.year + years)

    # -------------------- 周/月/季度起止 --------------------
    @staticmethod
    def start_of_day(dt=None):
        dt = DateUtils.parse(dt) if dt else datetime.now()
        return datetime(dt.year, dt.month, dt.day, 0, 0, 0)

    @staticmethod
    def end_of_day(dt=None):
        dt = DateUtils.parse(dt) if dt else datetime.now()
        return datetime(dt.year, dt.month, dt.day, 23, 59, 59)

    @staticmethod
    def start_of_week(dt=None):
        dt = DateUtils.parse(dt) if dt else datetime.now()
        start = dt - timedelta(days=dt.weekday())
        return datetime(start.year, start.month, start.day)

    @staticmethod
    def end_of_week(dt=None):
        dt = DateUtils.parse(dt) if dt else datetime.now()
        end = dt + timedelta(days=6 - dt.weekday())
        return datetime(end.year, end.month, end.day, 23, 59, 59)

    @staticmethod
    def start_of_month(dt=None):
        dt = DateUtils.parse(dt) if dt else datetime.now()
        return datetime(dt.year, dt.month, 1)

    @staticmethod
    def end_of_month(dt=None):
        dt = DateUtils.parse(dt) if dt else datetime.now()
        last_day = calendar.monthrange(dt.year, dt.month)[1]
        return datetime(dt.year, dt.month, last_day, 23, 59, 59)

    @staticmethod
    def start_of_quarter(dt=None):
        dt = DateUtils.parse(dt) if dt else datetime.now()
        month = ((dt.month - 1) // 3) * 3 + 1
        return datetime(dt.year, month, 1)

    @staticmethod
    def end_of_quarter(dt=None):
        dt = DateUtils.parse(dt) if dt else datetime.now()
        month = ((dt.month - 1) // 3 + 1) * 3
        last_day = calendar.monthrange(dt.year, month)[1]
        return datetime(dt.year, month, last_day, 23, 59, 59)

    # -------------------- 日期判断 --------------------
    @staticmethod
    def is_leap_year(year):
        return calendar.isleap(year)

    @staticmethod
    def weekday(dt=None):
        dt = DateUtils.parse(dt) if dt else datetime.now()
        return dt.weekday()  # 0=周一

    @staticmethod
    def is_weekend(dt=None):
        return DateUtils.weekday(dt) >= 5

    @staticmethod
    def days_between(start, end):
        start = DateUtils.parse(start)
        end = DateUtils.parse(end)
        return (end - start).days

    # -------------------- 日期区间 --------------------
    @staticmethod
    def date_range(start, end, step=1):
        start = DateUtils.parse(start)
        end = DateUtils.parse(end)
        days = []
        delta = timedelta(days=step)
        current = start
        while current <= end:
            days.append(current)
            current += delta
        return days

    # -------------------- 自然语言解析 --------------------
    @staticmethod
    def smart_parse(text):
        """支持 '今天','明天','昨天','上周一','下个月15号'"""
        today = datetime.now()
        text = text.strip()
        if text == "今天":
            return today
        elif text == "明天":
            return today + timedelta(days=1)
        elif text == "昨天":
            return today - timedelta(days=1)
        m = re.match(r"上周([一二三四五六日])", text)
        if m:
            weekday_map = {"一":0,"二":1,"三":2,"四":3,"五":4,"六":5,"日":6}
            target_weekday = weekday_map[m.group(1)]
            delta_days = today.weekday() - target_weekday + 7
            return today - timedelta(days=delta_days)
        # TODO: 可继续扩展自然语言解析
        return DateUtils.parse(text)

    @staticmethod
    def add_days_str(date_str, days, fmt="%Y-%m-%d"):
        """直接对字符串日期加减天数，返回字符串"""
        dt = datetime.strptime(date_str, fmt)
        dt += timedelta(days=days)
        return dt.strftime(fmt)

    @staticmethod
    def format_day(date_str, fmt="%Y-%m-%d"):
        """直接对字符串日期加减天数，返回字符串"""
        dt = datetime.strptime(date_str, fmt)
        return dt.strftime("%Y年%m月%d日")

    @staticmethod
    def to_timestamp(dt):
        dt = DateUtils.parse(dt) if isinstance(dt, (str, int, float)) else dt
        return int(dt.timestamp())
# ------------------------ 测试 ------------------------
if __name__ == "__main__":
    print("现在时间:", DateUtils.now())
    print("今天:", DateUtils.today())
    print("月初:", DateUtils.start_of_month())
    print("月末:", DateUtils.end_of_month())
    print("季度开始:", DateUtils.start_of_quarter())
    print("季度结束:", DateUtils.end_of_quarter())
    print("加3天:", DateUtils.add_days(datetime.now(), 3))
    print("是否周末:", DateUtils.is_weekend())
    print("自然语言解析 明天:", DateUtils.smart_parse("明天"))
    print("日期区间:", [d.strftime("%Y-%m-%d") for d in DateUtils.date_range("2025-12-01", "2025-12-05")])
