"""tescmd — A Python CLI for querying and controlling Tesla vehicles via the Fleet API."""

__version__ = "0.1.2"
