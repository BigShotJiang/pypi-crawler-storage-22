"""Allow running as: python -m tescmd"""

from tescmd.cli.main import main

main()
