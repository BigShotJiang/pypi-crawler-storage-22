"""Authentication: OAuth2 PKCE flow, token persistence, callback server."""
