"""Output formatting for tescmd."""

from tescmd.output.formatter import OutputFormatter

__all__ = ["OutputFormatter"]
