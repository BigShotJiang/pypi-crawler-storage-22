"""Vendored protobuf message definitions for Tesla Vehicle Command Protocol.

These are minimal, hand-written message definitions that are wire-compatible
with Tesla's published `.proto` schemas.  Generated ``_pb2.py`` files can
replace them when full ``protoc`` generation is wired up.
"""
