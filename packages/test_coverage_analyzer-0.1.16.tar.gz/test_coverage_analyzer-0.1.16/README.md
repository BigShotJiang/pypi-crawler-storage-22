# Test Coverage Analyzer

多语言测试文件查找和覆盖率分析工具，支持Python、Java、Go、C++等语言。

## 功能特点

- 🔍 **自动查找源代码对应的测试文件** - 智能识别多种语言的测试文件命名规则
- 📊 **分析代码覆盖率** - 精确计算测试覆盖率和未覆盖的代码元素
- 📈 **评估代码复杂度** - 计算圈复杂度和依赖复杂度，帮助识别高风险代码
- 🎯 **生成增量测试提示** - 基于覆盖率分析生成针对性的单元测试用例提示
- 📝 **多格式报告输出** - 支持 JSON、Markdown 等多种格式
- ⚙️ **灵活的配置选项** - 支持阈值过滤、数量限制等高级功能

## 安装

### 从 PyPI 安装

```bash
pip install test-coverage-analyzer
```

### 本地打包

```bash
# 构建分发包
python setup.py sdist bdist_wheel

# 或者使用 build 命令（推荐）
pip install build
python -m build
```

#### 本地安装打包文件
```bash
# 安装构建好的包
pip install dist/test_coverage_analyzer-0.1.9-py3-none-any.whl

# 或者从源码目录安装
pip install .
```

## 使用方法

### 命令行使用

#### 基本用法
```bash
test-coverage-analyzer <源代码路径> [输出目录] [文件名前缀] [选项]
```

#### 参数说明
- `<源代码路径>` - 必填，待分析的项目源码路径
- `<输出目录>` - 可选，结果输出目录（默认当前目录）
- `<文件名前缀>` - 可选，输出文件名前缀（默认：test_scanner_result）

#### 可选参数
- `--threshold <阈值>` - 覆盖率阈值（0-100），过滤覆盖率高于阈值的文件
- `--limit <数量>` - 限制处理的文件数量（最大200）
- `--prompt` - 对 JSON 结果进行二次处理，生成文件粒度的单测 prompts
- `--print` - 将结果打印到终端
- `-h, --help` - 显示帮助信息

#### 使用示例

```bash
# 基本分析
test-coverage-analyzer ./my_project

# 指定输出目录和文件名前缀
test-coverage-analyzer ./my_project ./reports my_result

# 只分析覆盖率低于50%的文件
test-coverage-analyzer ./my_project ./reports my_result --threshold 50

# 限制处理100个文件，覆盖率阈值50%
test-coverage-analyzer ./my_project ./reports my_result --limit 100 --threshold 50

# 生成测试用例提示并打印到终端
test-coverage-analyzer ./my_project ./reports my_result --threshold 80 --prompt --print
```

## 支持的语言

| 语言 | 测试文件识别规则 | 特性支持 |
|------|------------------|----------|
| **Python** | `*_test.py`, `test_*.py` | ✅ 覆盖率分析<br>✅ 复杂度分析<br>✅ 测试提示生成 |
| **Java** | `*Test.java`, `*Tests.java` | ✅ 覆盖率分析<br>✅ 复杂度分析<br>✅ 测试提示生成 |
| **Go** | `*_test.go` | ✅ 覆盖率分析<br>✅ 复杂度分析<br>✅ 测试提示生成 |
| **C++** | `*_test.cpp`, `*_test.cc` | ✅ 覆盖率分析<br>✅ 复杂度分析<br>✅ 测试提示生成 |

## 输出报告

### 报告格式

工具会生成以下格式的报告：

- **JSON 格式** - 结构化数据，便于程序处理和二次开发
- **Markdown 格式** - 人类可读的详细报告，包含文件列表和统计信息
- **Prompt 格式**（可选）- 为每个文件生成针对性的单元测试用例提示

### 报告内容

```json
{
  "coverage_results": [
    {
      "source_file": "src/main.py",
      "test_file": "tests/test_main.py",
      "language": "python",
      "coverage_percentage": 75.5,
      "uncovered_elements": ["function: calculate", "class: DataProcessor"],
      "cyclomatic_complexity": 8,
      "dependency_complexity": 3
    }
  ],
  "unmatched": [
    {
      "source_file": "src/utils.py",
      "test_file": null,
      "language": "python",
      "cyclomatic_complexity": 5,
      "dependency_complexity": 2
    }
  ]
}
```

### 测试提示格式

启用 `--prompt` 选项后，工具会生成针对每个文件的测试用例提示：

```json
[
  {
    "id": "uuid-string",
    "prompt": "请给python代码文件src/main.py生成增量单元测试用例，它对应的测试文件为tests/test_main.py，当前测试代码未覆盖的测试元素为['function: calculate', 'class: DataProcessor'],待测文件的圈复杂度为8，依赖复杂度为3。接下来你要根据给定的文件的复杂度增量生成单元测试，使得待测文件的覆盖率尽可能高。"
  }
]
```

## 高级功能

### 阈值过滤

使用 `--threshold` 参数可以只分析覆盖率低于指定阈值的文件，帮助您优先关注需要改进的代码：

```bash
# 只分析覆盖率低于60%的文件
test-coverage-analyzer ./my_project --threshold 60
```

### 数量限制

使用 `--limit` 参数可以限制分析的文件数量，避免处理大型项目时时间过长：

```bash
# 最多处理50个文件
test-coverage-analyzer ./my_project --limit 50
```

### 测试用例生成

启用 `--prompt` 选项后，工具会为每个文件生成详细的单元测试用例提示，包括：

- 对于有测试文件的：生成增量测试用例提示，专注于未覆盖的代码元素
- 对于没有测试文件的：生成全量测试用例提示，从零开始构建测试

## 项目信息

- **版本**: 0.1.9
- **作者**: Xisang
- **邮箱**: xisang@gmail.com
- **许可证**: MIT License
- **GitHub**: https://github.com/Xisang/test-coverage-analyzer

## 依赖要求

- Python >= 3.8
- lizard >= 1.19.0

## 许可证

本项目采用 MIT 许可证，详见 LICENSE 文件。