import re
import os
from typing import Dict, Any, Tuple

from .base_code_analyzer import BaseCodeAnalyzer, CoverageResult, read_file


class CCodeAnalyzer(BaseCodeAnalyzer):
    language = 'c'

    _COMPLEXITY_PATTERNS = (
        r'\bif\s*\(',
        r'\belse\s+if\s*\(',
        r'\bfor\s*\(',
        r'\bwhile\s*\(',
        r'\bcase\b',
        r'\?',
        r'&&',
        r'\|\|',
    )

    _COMPLEXITY_REGEX = re.compile("|".join(_COMPLEXITY_PATTERNS))

    _C_KEYWORDS = {
        'if', 'for', 'while', 'switch', 'return',
        'static', 'const', 'volatile',
        'typedef', 'struct', 'union', 'enum',
        'goto', 'break', 'continue',
        'sizeof'
    }

    _IGNORE_FUNCTIONS = {
        'main',
        'printf', 'fprintf', 'sprintf', 'snprintf',
        'scanf', 'sscanf',
        'malloc', 'free'
    }

    _FUNCTION_PATTERN = re.compile(
        r'''
        ^\s*
        [\w\*\s]+?\s+
        (\w+)\s*
        \(([^;{)]*)\)\s*
        \{
        ''',
        re.VERBOSE | re.MULTILINE
    )

    def _is_config_or_constants(self, filename: str) -> bool:
        name = os.path.basename(filename).lower()
        return any(k in name for k in ('config', 'constants', 'settings'))

    def _extract_testable_elements(
        self, source_code: str, source_file: str
    ) -> list[str]:

        elements = []

        for name, params in self._FUNCTION_PATTERN.findall(source_code):
            if name in self._C_KEYWORDS:
                continue
            if name in self._IGNORE_FUNCTIONS:
                continue

            elements.append(name)

        return list(set(elements))

    def _find_tested_elements(
        self, test_code: str, elements: list[str]
    ) -> list[str]:

        tested = []

        for fn in elements:
            pattern = rf'\b{re.escape(fn)}\s*\('
            if re.search(pattern, test_code):
                tested.append(fn)

        return list(set(tested))

    def calculate_cyclomatic_complexity(self, source_code: str) -> int:
        if not source_code:
            return 1

        complexity = 1
        complexity += len(self._COMPLEXITY_REGEX.findall(source_code))
        return complexity

    def calculate_dependency_complexity(
        self, source_code: str
    ) -> Tuple[int, int]:

        if not source_code:
            return 0, 0

        include_pattern = r'^\s*#\s*include\s+"[^"]+"'
        dependency_complexity = len(
            re.findall(include_pattern, source_code, re.MULTILINE)
        )

        param_complexity = 0

        for _, params in self._FUNCTION_PATTERN.findall(source_code):
            params = params.strip()
            if not params or params == 'void':
                continue

            param_complexity += len(
                [p for p in params.split(',') if p.strip()]
            )

        return dependency_complexity, param_complexity

    def analyze(self, source_file: str, test_file: str) -> Dict[str, Any]:
        try:
            if self._is_config_or_constants(source_file):
                return CoverageResult(
                    source_file=source_file,
                    test_file=test_file,
                    language=self.language
                )

            source_code = read_file(source_file)

            cyclomatic_complexity = self.calculate_cyclomatic_complexity(
                source_code
            )
            dependency_complexity, param_complexity = (
                self.calculate_dependency_complexity(source_code)
            )

            testable_elements = self._extract_testable_elements(
                source_code, source_file
            )

            if not test_file:
                return CoverageResult(
                    source_file=source_file,
                    test_file=test_file,
                    language=self.language,
                    total_testable_elements=len(testable_elements),
                    uncovered_elements=testable_elements,
                    cyclomatic_complexity=cyclomatic_complexity,
                    dependency_complexity=dependency_complexity,
                    param_complexity=param_complexity
                )

            test_code = read_file(test_file)

            tested_elements = self._find_tested_elements(
                test_code, testable_elements
            )

            total = len(testable_elements)
            tested = len(tested_elements)
            coverage = tested / total * 100 if total else 0.0
            uncovered = [
                e for e in testable_elements if e not in tested_elements
            ]

            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language=self.language,
                total_testable_elements=total,
                tested_elements=tested,
                coverage_percentage=coverage,
                uncovered_elements=uncovered,
                cyclomatic_complexity=cyclomatic_complexity,
                dependency_complexity=dependency_complexity,
                param_complexity=param_complexity
            )

        except Exception:
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language=self.language
            )
