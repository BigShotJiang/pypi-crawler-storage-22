import re
import os
from typing import Dict, Any, Tuple

from .base_code_analyzer import BaseCodeAnalyzer, CoverageResult, read_file


class CppCodeAnalyzer(BaseCodeAnalyzer):
    language = 'cpp'

    # 圈复杂度相关
    _COMPLEXITY_PATTERNS = (
        r'\bif\s*\(',
        r'\belse\s+if\s*\(',
        r'\bfor\s*\(',
        r'\bwhile\s*\(',
        r'\bcase\b',
        r'\bcatch\s*\(',
        r'\?',
        r'&&',
        r'\|\|',
    )

    _COMPLEXITY_REGEX = re.compile("|".join(_COMPLEXITY_PATTERNS))

    _CPP_KEYWORDS = {
        'if', 'for', 'while', 'switch', 'return',
        'class', 'struct', 'enum',
        'public', 'private', 'protected',
        'static', 'const', 'virtual', 'inline',
        'namespace', 'using', 'new', 'delete',
        'try', 'catch', 'throw'
    }

    _IGNORE_ELEMENTS = {
        'main',
        'printf', 'fprintf', 'sprintf', 'snprintf',
        'scanf', 'sscanf',
        'malloc', 'free',
        'operator=', 'operator<<', 'operator>>',
    }

    _CONST_PATTERN = re.compile(
        r'''
        ^\s*
        (?:static\s+)?                 # 可选 static
        (?:const|constexpr)\s+         # const / constexpr
        [\w:<>&*\s]+?\s+               # 类型
        \w+\s*                         # 变量名
        (=|;)                          # 赋值或声明结束
        ''',
        re.VERBOSE
    )

    _DEFINE_PATTERN = re.compile(r'^\s*#\s*define\s+\w+')

    # 方法匹配，支持：
    # 1. 类内声明
    # 2. cpp 实现 Foo::bar(...)
    _METHOD_PATTERN = re.compile(
        r'''
        (?:virtual\s+)?                 
        [\w:<>&*\s]+?\s+               
        (?:(\w+)::)?(\w+)\s*           
        \([^;{)]*\)\s*                 
        (?:\{|$)                       
        ''',
        re.VERBOSE
    )

    _METHOD_PARAM_PATTERN = re.compile(
        r'''
        (?:virtual\s+)?[\w:<>&*\s]+?\s+
        (?:(\w+)::)?\w+\s*
        \(([^)]*)\)
        ''',
        re.VERBOSE
    )

    _CLASS_PATTERN = re.compile(
        r'\b(class|struct)\s+(\w+)'
    )

    def _is_config_or_constants(self, filename: str) -> bool:
        name = os.path.basename(filename).lower()
        return any(k in name for k in ('config', 'constants', 'settings'))

    def _extract_testable_elements(
        self, source_code: str, source_file: str
    ) -> list[str]:

        elements = []

        for line in source_code.splitlines():
            # 忽略宏常量
            if self._DEFINE_PATTERN.search(line):
                continue

            # 忽略 const / constexpr 常量
            if self._CONST_PATTERN.search(line):
                continue

            m = self._METHOD_PATTERN.search(line)
            if not m:
                continue

            cls, name = m.groups()
            if cls == 'std':
                continue

            if name in self._CPP_KEYWORDS:
                continue
            if name in self._IGNORE_ELEMENTS:
                continue

            if cls:
                elements.append(f"{cls}::{name}")
            else:
                elements.append(name)

        for _, cls in self._CLASS_PATTERN.findall(source_code):
            elements.append(f"class_{cls}")

        return list(set(elements))

    def _find_tested_elements(
        self, test_code: str, elements: list[str]
    ) -> list[str]:

        tested = []

        for el in elements:
            if el.startswith('class_'):
                name = el[6:]
                pattern = rf'\b{name}\b'
            elif '::' in el:
                cls, fn = el.split('::', 1)
                pattern = rf'\b{cls}\s*::\s*{fn}\s*\('
            else:
                pattern = rf'\b{re.escape(el)}\s*\('

            if re.search(pattern, test_code):
                tested.append(el)

        return list(set(tested))

    def calculate_cyclomatic_complexity(self, source_code: str) -> int:
        if not source_code:
            return 1

        complexity = 1
        complexity += len(self._COMPLEXITY_REGEX.findall(source_code))
        return complexity

    def calculate_dependency_complexity(
        self, source_code: str
    ) -> Tuple[int, int]:

        if not source_code:
            return 0, 0

        include_pattern = r'^\s*#\s*include\s+"[^"]+"'
        dependency_complexity = len(
            re.findall(include_pattern, source_code, re.MULTILINE)
        )

        param_complexity = 0

        for line in source_code.splitlines():
            m = self._METHOD_PARAM_PATTERN.search(line)
            if not m:
                continue

            _, params = m.groups()
            params = params.strip()
            if not params:
                continue

            param_complexity += len(
                [p for p in params.split(',') if p.strip()]
            )

        return dependency_complexity, param_complexity

    def analyze(self, source_file: str, test_file: str) -> Dict[str, Any]:
        try:
            if self._is_config_or_constants(source_file):
                return CoverageResult(
                    source_file=source_file,
                    test_file=test_file,
                    language=self.language
                )

            source_code = read_file(source_file)

            cyclomatic_complexity = self.calculate_cyclomatic_complexity(
                source_code
            )
            dependency_complexity, param_complexity = (
                self.calculate_dependency_complexity(source_code)
            )

            testable_elements = self._extract_testable_elements(
                source_code, source_file
            )

            if not test_file:
                return CoverageResult(
                    source_file=source_file,
                    test_file=test_file,
                    language=self.language,
                    total_testable_elements=len(testable_elements),
                    uncovered_elements=testable_elements,
                    cyclomatic_complexity=cyclomatic_complexity,
                    dependency_complexity=dependency_complexity,
                    param_complexity=param_complexity
                )

            test_code = read_file(test_file)

            tested_elements = self._find_tested_elements(
                test_code, testable_elements
            )

            total = len(testable_elements)
            tested = len(tested_elements)
            coverage = tested / total * 100 if total else 0.0
            uncovered = [
                e for e in testable_elements if e not in tested_elements
            ]

            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language=self.language,
                total_testable_elements=total,
                tested_elements=tested,
                coverage_percentage=coverage,
                uncovered_elements=uncovered,
                cyclomatic_complexity=cyclomatic_complexity,
                dependency_complexity=dependency_complexity,
                param_complexity=param_complexity
            )

        except Exception:
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language=self.language
            )
