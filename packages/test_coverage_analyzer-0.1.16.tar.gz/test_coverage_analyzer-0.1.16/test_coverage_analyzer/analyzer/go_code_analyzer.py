import re
import os
from typing import Dict, Any, List, Tuple

from .base_code_analyzer import BaseCodeAnalyzer, CoverageResult, read_file

class GoCodeAnalyzer(BaseCodeAnalyzer):
    """
    Go代码静态分析器
    支持圈复杂度、依赖复杂度、函数参数复杂度等分析
    """
    language = 'go'

    # 预编译正则表达式，提高性能
    _IF_PATTERN = re.compile(r'\bif\s*\(')
    _FOR_PATTERN = re.compile(r'\bfor\s*[^\{]*\{')
    _SWITCH_PATTERN = re.compile(r'\bswitch\s*[^\{]*\{')
    _SELECT_PATTERN = re.compile(r'\bselect\s*\{')
    _BOOL_OP_PATTERN = re.compile(r'&&|\|\|')
    _IMPORT_PATTERN = re.compile(r'^\s*import\s+(?P<bracket>\(|\S)', re.MULTILINE)
    _MULTI_IMPORT_START = re.compile(r'^\s*import\s*\(', re.MULTILINE)
    _MULTI_IMPORT_END = re.compile(r'^\s*\)', re.MULTILINE)
    _FUNC_DECL_PATTERN = re.compile(r'func\s+(?P<recv>\([^)]+\)\s+)?(?P<name>\w+)\s*\((?P<params>[^)]*)\)(?P<results>[^{]*)\{', re.MULTILINE | re.DOTALL)
    _SIMPLE_FUNC_PATTERN = re.compile(r'func\s+(?P<name>\w+)\s*\((?P<params>[^)]*)\)(?P<results>[^{]*)\{', re.MULTILINE | re.DOTALL)
    _RECEIVER_FUNC_PATTERN = re.compile(r'func\s+\((?P<receiver>[^)]+)\)\s+(?P<name>\w+)\s*\((?P<params>[^)]*)\)(?P<results>[^{]*)\{', re.MULTILINE | re.DOTALL)
    _STRUCT_PATTERN = re.compile(r'type\s+(?P<name>\w+)\s+struct\s*\{(?P<fields>[^}]*)\}', re.MULTILINE | re.DOTALL)
    _INTERFACE_PATTERN = re.compile(r'type\s+(?P<name>\w+)\s+interface\s*\{(?P<methods>[^}]*)\}', re.MULTILINE | re.DOTALL)
    _VAR_DECL_PATTERN = re.compile(r'\bvar\s+(?P<name>\w+)\s+(?P<type>[^;=]+)', re.MULTILINE)
    _CONST_DECL_PATTERN = re.compile(r'\bconst\s+(?P<name>\w+)\s+', re.MULTILINE)
    _TYPE_ALIAS_PATTERN = re.compile(r'type\s+(?P<name>\w+)\s+=\s+(?P<type>\w+)', re.MULTILINE)
    _COMMENT_PATTERN = re.compile(r'//.*?$|/\*.*?\*/', re.DOTALL | re.MULTILINE)
    _STRING_LITERAL_PATTERN = re.compile(r'"(?:[^"\\]|\\.)*"|\'(?:[^\'\\]|\\.)*\'', re.MULTILINE)
    _BACKTICK_STRING_PATTERN = re.compile(r'`(?:[^`\\]|\\.)*`', re.MULTILINE)
    _CASE_PATTERN = re.compile(r'\bcase\s+[^:]+:')
    _FUNC_PATTERN = re.compile(r'func\s*\([^)]*\)\s*\{')
    _GO_PATTERN = re.compile(r'\bgo\s+\w+')
    _DEFER_PATTERN = re.compile(r'\bdefer\s+')
    _MULTI_IMPORT_PATTERN = re.compile(r'^\s*import\s+(?:\w+\s+|\.\s+|)\s*"([^"]+)"', re.MULTILINE)
    _QUOTED_IMPORTS = re.compile(r'"([^"]+)"')
    
    # 新增用于查找公共元素的正则
    _PUBLIC_FUNC_PATTERN = re.compile(r'func\s+([A-Z]\w+)\s*\([^)]*\)')
    _TYPE_PATTERN = re.compile(r'type\s+([A-Z]\w+)')
    _TEST_FUNC_PATTERN = re.compile(r'func\s+Test\w+\s*\([^)]*\)')
    _IMPORT_WEIGHT = 3 # 外部导入包依赖权重
    _PARAM_WEIGHT = 1.5  # 参数复杂度权重
    _RETURN_WEIGHT = 0.5  # 返回值复杂度权重
    _STRUCT_WEIGHT = 1  # 结构体字段复杂度权重
    _INTERFACE_WEIGHT = 2  # 接口方法复杂度权重
    _PATH_DEPTH_WEIGHT = 0.5 # 外部导入包深度复杂度权重

    # Go标准库常见包，这些不应计入依赖复杂度
    STANDARD_LIB_PACKAGES = {
        'fmt', 'io', 'os', 'strings', 'strconv', 'bytes', 'bufio', 'errors', 'context',
        'time', 'math', 'sort', 'sync', 'flag', 'path', 'path/filepath', 'net', 'http',
        'json', 'xml', 'html', 'template', 'text/template', 'regexp', 'crypto', 'hash',
        'encoding', 'compress', 'archive', 'image', 'database/sql', 'log', 'reflect',
        'runtime', 'testing', 'unsafe', 'syscall', 'plugin', 'debug', 'internal',
        'runtime/debug', 'runtime/pprof', 'runtime/trace', 'expvar', 'go', 'go/ast',
        'go/parser', 'go/token', 'go/types', 'go/format', 'go/build', 'go/doc',
        'go/importer', 'go/scanner', 'go/printer', 'go/constant', 'go/exact',
        'go/internal/gccgoimporter', 'go/internal/gcimporter', 'go/internal/srcimporter',
        'go/internal/typeparams', 'go/internal/typeparams/test', 'go/internal/srcimporter',
        'crypto/tls', 'crypto/x509', 'crypto/ecdsa', 'crypto/elliptic', 'crypto/rand',
        'crypto/sha256', 'crypto/sha512', 'crypto/md5', 'crypto/sha1', 'crypto/hmac',
        'crypto/cipher', 'crypto/aes', 'crypto/des', 'crypto/rc4', 'crypto/subtle',
        'crypto/rsa', 'crypto/dsa', 'crypto/x509/pkix', 'encoding/base64',
        'encoding/binary', 'encoding/csv', 'encoding/gob', 'encoding/hex',
        'encoding/json', 'encoding/pem', 'encoding/xml', 'compress/bzip2',
        'compress/flate', 'compress/gzip', 'compress/lzw', 'compress/zlib',
        'archive/tar', 'archive/zip', 'image/color', 'image/png', 'image/jpeg',
        'image/gif', 'math/big', 'math/bits', 'math/cmplx', 'math/rand',
        'net/http', 'net/url', 'net/smtp', 'net/textproto', 'net/rpc',
        'net/rpc/jsonrpc', 'html', 'html/template', 'text/template', 'text/tabwriter',
        'text/template/parse', 'regexp/syntax', 'runtime/cgo', 'runtime/debug',
        'runtime/metrics', 'runtime/pprof', 'runtime/trace', 'sync/atomic',
        'syscall/unix', 'syscall/windows', 'syscall/js', 'unicode', 'unicode/utf8',
        'unicode/utf16', 'container/heap', 'container/list', 'container/ring',
        'context', 'embed', 'go/format', 'go/version', 'index/suffixarray',
        'internal/cpu', 'internal/fmtsort', 'internal/nettrace', 'internal/oserror',
        'internal/poll', 'internal/reflectlite', 'internal/singleflight',
        'internal/syscall/execenv', 'internal/syscall/unix', 'internal/syscall/windows',
        'internal/syscall/windows/registry', 'internal/syscall/windows/sysdll',
        'internal/testenv', 'internal/testlog', 'internal/unsafeheader', 'math/bits',
        'plugin', 'runtime/debug', 'runtime/metrics', 'runtime/pprof', 'runtime/trace',
        'sync/atomic', 'syscall', 'time/tzdata'
    }

    # 忽略列表，包含Go语言内置函数和关键字
    _IGNORE_ELEMENTS = {
        'main', 'len', 'append', 'copy', 'close', 'delete', 'make', 'new', 'panic', 
        'print', 'println', 'recover', 'cap', 'complex', 'imag', 'real', 'Type', 
        'Value', 'error', 'string', 'int', 'int64', 'int32', 'float64', 'bool', 
        'byte', 'rune', 'map', 'slice', 'chan', 'struct', 'interface', 'func', 
        'var', 'const', 'type', 'package', 'import', 'return', 'if', 'else', 
        'for', 'range', 'switch', 'case', 'default', 'break', 'continue', 
        'goto', 'fallthrough', 'defer', 'go', 'select', 'true', 'false', 'nil',
        'iota', 'uintptr', 'complex64', 'complex128', 'float32', 'int16', 'int8',
        'uint', 'uint16', 'uint32', 'uint64', 'uint8'
    }

    _CONTROL_ELEMENTS = [
        'if', 'for', 'range', 'switch', 'return', 'func', 
        'var', 'const', 'type', 'import', 'package', 
        'go', 'defer', 'select', 'case', 'default', 
        'break', 'continue', 'goto', 'fallthrough'
    ]

    def remove_comments_and_strings(self, source_code: str) -> str:
        """移除注释和字符串字面量，避免在其中匹配模式"""
        # 先移除字符串字面量，用占位符替换
        code = self._STRING_LITERAL_PATTERN.sub('""', source_code)
        code = self._BACKTICK_STRING_PATTERN.sub('""', code)
        # 再移除注释
        code = self._COMMENT_PATTERN.sub('', code)
        return code

    def calculate_cyclomatic_complexity(self, source_code: str) -> int:
        """计算Go代码圈复杂度"""
        code_without_comments = self.remove_comments_and_strings(source_code)

        complexity = 1  # 基础复杂度

        # 计算圈复杂度：控制结构
        complexity += len(self._IF_PATTERN.findall(code_without_comments))
        complexity += len(self._FOR_PATTERN.findall(code_without_comments))
        complexity += len(self._SWITCH_PATTERN.findall(code_without_comments))
        complexity += len(self._SELECT_PATTERN.findall(code_without_comments))

        # 计算布尔运算符
        complexity += len(self._BOOL_OP_PATTERN.findall(code_without_comments))

        # 计算case语句，每个case增加复杂度
        complexity += len(self._CASE_PATTERN.findall(code_without_comments))

        # 计算嵌套函数声明
        complexity += len(self._FUNC_PATTERN.findall(code_without_comments))

        # 计算goroutine和channel操作（增加并发复杂度）
        complexity += len(self._GO_PATTERN.findall(code_without_comments))

        complexity += len(self._DEFER_PATTERN.findall(code_without_comments))

        return complexity

    def extract_imports(self, source_code: str) -> List[str]:
        """提取导入的包"""
        imports = []
        
        # 检查是否有括号形式的多行导入
        multi_start_matches = [(m.start(), m.end()) for m in self._MULTI_IMPORT_START.finditer(source_code)]
        multi_end_matches = [(m.start(), m.end()) for m in self._MULTI_IMPORT_END.finditer(source_code)]
        
        # 找到每对括号的位置
        for start_match in multi_start_matches:
            for end_match in multi_end_matches:
                if end_match[0] > start_match[1]:  # 确保结束位置在开始位置之后
                    import_block = source_code[start_match[1]:end_match[0]]
                    # 提取引号内的包路径
                    quoted_imports = self._QUOTED_IMPORTS.findall(import_block)
                    imports.extend(quoted_imports)
                    break

        imports.extend(self._MULTI_IMPORT_PATTERN.findall(source_code))
        
        return list(set(imports))  # 去重

    def extract_function_params_complexity(self, source_code: str) -> Tuple[int, int, List[Dict]]:
        """提取函数参数复杂度信息"""
        code_without_comments = self.remove_comments_and_strings(source_code)
        
        # 使用更复杂的正则来匹配函数定义
        functions = []
        
        # 匹配普通函数
        for match in self._SIMPLE_FUNC_PATTERN.finditer(code_without_comments):
            name = match.group('name')
            params_str = match.group('params')
            results_str = match.group('results')
            
            param_count = self._count_parameters(params_str)
            result_count = self._count_parameters(results_str)
            
            functions.append({
                'name': name,
                'param_count': param_count,
                'result_count': result_count,
                'param_types': self._extract_param_types(params_str),
                'result_types': self._extract_param_types(results_str)
            })
        
        # 匹配方法（带接收者）
        for match in self._RECEIVER_FUNC_PATTERN.finditer(code_without_comments):
            name = match.group('name')
            params_str = match.group('params')
            results_str = match.group('results')
            
            param_count = self._count_parameters(params_str)
            result_count = self._count_parameters(results_str)
            
            functions.append({
                'name': name,
                'param_count': param_count,
                'result_count': result_count,
                'param_types': self._extract_param_types(params_str),
                'result_types': self._extract_param_types(results_str)
            })
        
        total_param_complexity = sum(f['param_count'] for f in functions)
        total_result_complexity = sum(f['result_count'] for f in functions)
        
        return len(functions), total_param_complexity, total_result_complexity, functions

    def _count_parameters(self, params_str: str) -> int:
        """计算参数数量，处理多个变量共享类型的情况"""
        if not params_str.strip():
            return 0
            
        # 分割参数，但要注意匿名参数和命名参数
        params = [p.strip() for p in params_str.split(',') if p.strip()]
        
        count = 0
        for param in params:
            # 检查是否是形如 "a, b, c int" 的情况
            parts = param.split()
            if len(parts) >= 2:
                # 最后一部分通常是类型
                type_part = parts[-1]
                # 前面的部分是变量名
                var_parts = parts[:-1]
                
                # 检查是否是多个变量共享类型，如 "a, b int"
                comma_vars = [v for v in var_parts if ',' in v]
                if comma_vars:
                    # 分割变量名
                    for var_group in var_parts:
                        vars_in_group = [v.strip() for v in var_group.split(',') if v.strip()]
                        count += len(vars_in_group)
                else:
                    # 每个变量名是一个参数
                    count += len(var_parts)
            elif len(parts) == 1:
                # 可能是匿名参数
                count += 1
                
        return count

    def _extract_param_types(self, params_str: str) -> List[str]:
        """提取参数类型列表"""
        if not params_str.strip():
            return []
            
        types = []
        params = [p.strip() for p in params_str.split(',') if p.strip()]
        
        for param in params:
            parts = param.split()
            if len(parts) >= 2:
                # 最后一部分是类型
                types.append(parts[-1])
            elif len(parts) == 1 and not param.isidentifier():
                # 可能是匿名参数
                types.append(param)
                
        return types

    def extract_struct_info(self, source_code: str) -> List[Dict]:
        """提取结构体信息"""
        structs = []
        code_without_comments = self.remove_comments_and_strings(source_code)
        
        for match in self._STRUCT_PATTERN.finditer(code_without_comments):
            name = match.group('name')
            fields_content = match.group('fields')
            
            # 计算字段数量
            fields = [f.strip() for f in fields_content.split('\n') if f.strip() and not f.strip().startswith('//')]
            field_count = 0
            for field_line in fields:
                # 移除标签部分
                field_clean = re.sub(r'`\w+.*?`', '', field_line).strip()
                if field_clean and not field_clean.startswith('*') and not field_clean.startswith('[]'):
                    # 计算这一行有几个字段定义
                    field_def = field_clean.split()
                    if len(field_def) >= 2:  # 有字段名和类型
                        field_count += 1
            
            structs.append({
                'name': name,
                'field_count': field_count
            })
        
        return structs

    def extract_interface_info(self, source_code: str) -> List[Dict]:
        """提取接口信息"""
        interfaces = []
        code_without_comments = self.remove_comments_and_strings(source_code)
        
        for match in self._INTERFACE_PATTERN.finditer(code_without_comments):
            name = match.group('name')
            methods_content = match.group('methods')
            
            # 计算方法数量
            methods = [m.strip() for m in methods_content.split('\n') if m.strip() and not m.strip().startswith('//')]
            method_count = 0
            for method_line in methods:
                # 检查是否是方法定义
                if '(' in method_line and ')' in method_line:
                    method_count += 1
            
            interfaces.append({
                'name': name,
                'method_count': method_count
            })
        
        return interfaces

    def calculate_dependency_complexity(self, source_code: str) -> Tuple[float, float]:
        """计算依赖复杂度：导入包数量、函数参数复杂度等，返回两个参数"""
        imports = self.extract_imports(source_code)
        
        func_count, total_param_complexity, total_result_complexity, functions = self.extract_function_params_complexity(source_code)
        
        structs = self.extract_struct_info(source_code)
        interfaces = self.extract_interface_info(source_code)
        
        # 识别非标准库的依赖包
        external_imports = [imp for imp in imports if not any(imp.startswith(std_pkg) for std_pkg in self.STANDARD_LIB_PACKAGES)]
        
        # 计算包导入复杂度，仅考虑外部依赖
        import_complexity = len(external_imports) * self._IMPORT_WEIGHT  # 外部依赖包权重更高
        
        # 考虑包路径深度，深层路径表示更具体的子包
        path_depth_complexity = 0
        for imp in external_imports:
            path_depth_complexity += max(0, imp.count('/') - 1)  # 减去1是因为顶级路径不算额外复杂度
        path_depth_complexity = path_depth_complexity * self._PATH_DEPTH_WEIGHT
        # 计算函数参数复杂度
        func_param_complexity = total_param_complexity * self._PARAM_WEIGHT  # 参数复杂度权重
        func_result_complexity = total_result_complexity * self._RETURN_WEIGHT  # 返回值复杂度权重
        
        # 计算结构体和接口复杂度
        struct_complexity = sum(s['field_count'] for s in structs) * self._STRUCT_WEIGHT  # 结构体字段复杂度
        interface_complexity = sum(i['method_count'] for i in interfaces) * self._INTERFACE_WEIGHT  # 接口方法复杂度
        
        # 计算依赖复杂度得分
        dependency_complexity = (
            import_complexity + 
            path_depth_complexity +
            interface_complexity
        )
        
        # 计算参数复杂度的集成量化指标
        param_complexity = (
            func_param_complexity + 
            func_result_complexity +
            struct_complexity
        )
        
        return dependency_complexity, param_complexity

    def analyze(self, source_file: str, test_file: str) -> Dict[str, Any]:
        """分析Go文件的覆盖率"""
        try:
            source_code = read_file(source_file)
            # 复杂度
            cyclomatic_complexity = self.calculate_cyclomatic_complexity(source_code)
            dependency_complexity, param_complexity = self.calculate_dependency_complexity(source_code)

            # 检查是否是配置文件，如果是则不进行分析
            filename = os.path.basename(source_file)
            if 'config' in filename.lower() or 'settings' in filename.lower():
                # 返回空结果，因为这些文件不需要测试
                return CoverageResult(
                    source_file=source_file,
                    test_file=test_file,
                    language='go'
                )

            # 移除注释以避免在注释中的匹配
            source_code_no_comments = self._COMMENT_PATTERN.sub('', source_code)

            # 提取Go公共函数和类型（大写字母开头）
            testable_elements = set()

            # 提取公共函数（以大写字母开头）
            functions = self._PUBLIC_FUNC_PATTERN.findall(source_code_no_comments)
            # 过滤掉常见的控制结构关键字
            valid_functions = [f for f in functions 
                              if f not in self._CONTROL_ELEMENTS]
            testable_elements.update(valid_functions)

            # 提取公共类型（以大写字母开头）
            types = self._TYPE_PATTERN.findall(source_code_no_comments)
            for t in types:
                testable_elements.add(f"type_{t}")
            # 过滤掉常见的不需要测试的元素
            testable_elements = [e for e in testable_elements if e not in self._IGNORE_ELEMENTS]

            if not test_file:
                return CoverageResult(
                    source_file=source_file,
                    test_file=test_file,
                    language=self.language,
                    total_testable_elements=len(testable_elements),
                    uncovered_elements=testable_elements,
                    cyclomatic_complexity=cyclomatic_complexity,
                    dependency_complexity=dependency_complexity,
                    param_complexity=param_complexity
                )

            # 读取测试文件
            test_code = read_file(test_file)

            # 查找测试函数中调用的源元素
            tested_elements = set()
            for element in testable_elements:
                if element.startswith('type_'):
                    # 检查类型是否在测试中被使用
                    type_name = element[5:]  # 移除 'type_' 前缀
                    pattern = r'\b' + re.escape(type_name) + r'\b'
                else:
                    # 检查函数是否在测试中被调用
                    pattern = r'\b' + re.escape(element) + r'\s*\('

                if re.search(pattern, test_code):
                    tested_elements.add(element)

            # 过滤掉常见的不需要测试的元素
            tested_elements = [e for e in tested_elements if e not in self._IGNORE_ELEMENTS]

            total = len(testable_elements)
            tested = len(tested_elements)
            coverage = (tested / total * 100) if total > 0 else 0.0
            uncovered = [e for e in testable_elements if e not in tested_elements]

            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language=self.language,
                total_testable_elements=total,
                tested_elements=tested,
                coverage_percentage=coverage,
                uncovered_elements=uncovered,
                cyclomatic_complexity=cyclomatic_complexity,
                dependency_complexity=dependency_complexity,
                param_complexity=param_complexity
            )
        except Exception:
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language=self.language
            )


