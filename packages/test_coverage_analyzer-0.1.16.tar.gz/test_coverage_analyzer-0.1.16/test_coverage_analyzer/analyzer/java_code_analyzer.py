import re
import os

from typing import Dict, Any

from .base_code_analyzer import BaseCodeAnalyzer, CoverageResult, read_file


class JavaCodeAnalyzer(BaseCodeAnalyzer):
    language = 'java'

    # 所有会增加圈复杂度的结构统一管理
    _COMPLEXITY_PATTERNS = (
        r'\bif\s*\(', # 控制结构
        r'\bfor\s*\(',
        r'\bwhile\s*\(',
        r'\bcase\b',
        r'\bcatch\s*\(',
        r'\b\?\s*.*?:',  # 三目表达式
        r'&&', # 布尔运算符
        r'\|\|',
    )

    # 统一编译，避免多次扫描源码
    _COMPLEXITY_REGEX = re.compile(
        "|".join(_COMPLEXITY_PATTERNS)
    )

    _JAVA_KEYWORDS = {
        'if', 'for', 'while', 'switch', 'return',
        'class', 'interface', 'enum',
        'public', 'private', 'protected',
        'static', 'final', 'abstract', 'default',
        'import', 'package', 'new',
        'try', 'catch', 'finally', 'throw', 'throws',
        'extends', 'implements'
    }
    _IGNORE_ELEMENTS = {
        'main', 'log', 'logger', 'System', 'out',
        'println', 'print', 'compile', 'matcher',
        'matches', 'indexOf', 'substring', 'length',
        'charAt', 'append', 'toString',
        'intValue', 'doubleValue', 'booleanValue',
        'equals', 'hashCode', 'getClass', 'clone',
        'finalize', 'notify', 'notifyAll'
    }

    _GETTER_SETTER_PATTERN = re.compile(r'^(get|set|is)[A-Z]\w*$')
    _PACKAGE_PATTERN = re.compile(
        r'^\s*package\s+([\w.*]+);',
        re.MULTILINE
    )
    _IMPORT_PATTERN = re.compile(
        r'^\s*import\s+(?:static\s+)?([\w.*]+);',
        re.MULTILINE
    )
    _METHOD_PARAM_PATTERN = re.compile(
        r'''
        (?:public|protected|private)?\s*     # 访问修饰符
        (?:static\s+)?                       # static
        (?:final\s+)?                        # final
        [\w<>\[\]]+\s+                       # 返回类型（支持泛型）
        \w+\s*                               # 方法名
        \(([^)]*)\)                          # 参数列表（捕获组）
        ''',
        re.VERBOSE
    )
    _METHOD_PATTERN = re.compile(
        r'''
        (?:public|protected|private)?\s*
        (?:static\s+)?  
        (?:final\s+)?   
        [\w<>\[\]]+\s+     # 返回类型
        (\w+)\s*           # 方法名（捕获）
        \([^)]*\)\s*
        \{
        ''',
        re.VERBOSE
    )
    _CLASS_PATTERN = re.compile(
        r'(?:public\s+)?(?:class|interface|enum)\s+(\w+)'
    )

    def _is_internal_import(self, package_name: str, import_path: str) -> bool:
        """
        判断Java导包语句是否为包内的导包

        Args:
            package_name: Java类的包名，如 'org.nlpcn.commons.lang.bloomFilter.bitMap'
            import_path: 导入的包路径，如 ' org.nlpcn.commons.lang.bloomFilter.iface.BitMap'

        Returns:
            bool: 是否为包内导包
        """

        # 获取当前包的层级结构
        package_parts = package_name.strip().split('.')
        import_parts = import_path.strip().split('.')

        # 检查是否有共享的父包
        min_len = min(len(package_parts), len(import_parts))
        shared_depth = 0

        for i in range(min_len):
            if package_parts[i] == import_parts[i]:
                shared_depth += 1
            else:
                break

        # 如果有共享的父包，且共享深度至少为2（避免只共享顶级域名如com、org）
        return shared_depth >= 2

    def _is_config_or_constants(self, filename: str) -> bool:
        name = os.path.basename(filename).lower()
        return any(k in name for k in ('config', 'constants', 'settings'))

    def _extract_testable_elements(self, source_code: str, source_file: str) -> list[str]:
        elements = []

        # 方法提取
        methods = self._METHOD_PATTERN.findall(source_code)

        class_name = os.path.splitext(os.path.basename(source_file))[0]

        for m in methods:
            if m == class_name:  # 构造函数
                continue
            if m in self._JAVA_KEYWORDS:
                continue
            if self._GETTER_SETTER_PATTERN.match(m):
                continue
            if m in self._IGNORE_ELEMENTS:
                continue
            elements.append(m)

        # 类提取（只保留 concrete class）
        classes = self._CLASS_PATTERN.findall(source_code)
        for cls in classes:
            if f'abstract class {cls}' in source_code:
                continue
            if f'interface {cls}' in source_code:
                continue
            if f'enum {cls}' in source_code:
                continue
            elements.append(f"class_{cls}")

        return list(set(elements))

    def _find_tested_elements(self, test_code: str, elements: list[str]) -> list[str]:
        tested = []

        for el in elements:
            if el.startswith('class_'):
                name = el[6:]
                pattern = rf'\b{name}\b'
            else:
                pattern = rf'\b{el}\s*\('

            if re.search(pattern, test_code):
                tested.append(el)

        return list(set(tested))

    def calculate_cyclomatic_complexity(self, source_code: str) -> int:
        """计算Java代码圈复杂度"""
        if not source_code:
            return 1

        # 基础复杂度
        complexity = 1

        # 计算圈复杂度：控制结构
        matches = self._COMPLEXITY_REGEX.findall(source_code)
        complexity += len(matches)

        return complexity

    def calculate_dependency_complexity(self, source_code: str) -> int:
        """计算导包依赖复杂度"""
        if not source_code:
            return 0

        dependency_complexity = 0

        # 计算导入模块数量（依赖复杂度）
        package_statements = self._PACKAGE_PATTERN.findall(source_code)
        import_statements = self._IMPORT_PATTERN.findall(source_code)

        if len(import_statements) > 0:
            # TODO: 仅考虑包内的导包
            # dependency_complexity += len(import_statements)
            # 如果存在package语句，计算package语句中包含的import数量
            if len(package_statements) > 0:
                import_statements_ = [i_s for i_s in import_statements \
                    if self._is_internal_import(package_statements[0], i_s)]
                # 增加包内的import占比
                dependency_complexity += len(import_statements_)

        # 计算方法参数数量（增加依赖复杂度）
        param_complexity = self.calculate_param_complexity(source_code)

        return dependency_complexity, param_complexity

    def calculate_param_complexity(self, source_code: str) -> int:
        """计算函数参数复杂度"""
        if not source_code:
            return 0

        param_complexity = 0

        # 计算方法参数数量（增加依赖复杂度）
        method_params = self._METHOD_PARAM_PATTERN.findall(source_code)
        for param_group in method_params:
            param_group = param_group.strip()

            if not param_group:
                continue

            params = [p.strip() for p in param_group.split(',') if p.strip()]
            param_complexity += len(params)

        return param_complexity

    def analyze(self, source_file: str, test_file: str) -> Dict[str, Any]:
        """分析Java文件的覆盖率"""
        try:
            # 配置类 / 常量类直接跳过
            if self._is_config_or_constants(source_file):
                # TODO: config文件应该在finder过程中就被过滤掉
                return CoverageResult(
                    source_file=source_file,
                    test_file=test_file,
                    language=self.language
                )

            source_code = read_file(source_file)
            # 计算代码圈复杂度和依赖复杂度
            cyclomatic_complexity, dependency_complexity, param_complexity = self.calculate_complexity(source_code)

            # 提取Java公共方法（方法名）
            testable_elements = self._extract_testable_elements(source_code, source_file)

            if not test_file:
                return CoverageResult(
                    source_file=source_file,
                    test_file=test_file,
                    language=self.language,
                    total_testable_elements=len(testable_elements),
                    uncovered_elements=testable_elements,
                    cyclomatic_complexity=cyclomatic_complexity,
                    dependency_complexity=dependency_complexity,
                    param_complexity=param_complexity
                )

            # 读取测试文件
            test_code = read_file(test_file)
            # 查找测试方法中调用的源元素
            tested_elements = self._find_tested_elements(test_code, testable_elements)

            total = len(testable_elements)
            tested = len([el for el in tested_elements if el in testable_elements])
            coverage = (tested / total * 100) if total > 0 else 0.0
            uncovered = [e for e in testable_elements if e not in tested_elements]

            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language=self.language,
                total_testable_elements=total,
                tested_elements=tested,
                coverage_percentage=coverage,
                uncovered_elements=uncovered,
                cyclomatic_complexity=cyclomatic_complexity,
                dependency_complexity=dependency_complexity,
                param_complexity=param_complexity
            )

        except Exception as e:
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language=self.language
            )
