import re
import os
import ast

from typing import Set, Dict, Any, Optional
from pathlib import Path

from .base_code_analyzer import BaseCodeAnalyzer, CoverageResult, read_file


class PythonCodeAnalyzer(BaseCodeAnalyzer):

    def build_dir_index(self, project_root: str) -> Set[str]:
        """构建项目目录索引
        递归遍历项目根目录，收集所有子目录名称，排除常见的无关目录。
        Args:
            project_root: 项目根目录路径

        Returns:
            包含所有子目录名称的集合，用于快速判断路径是否属于项目内部。
        """
        EXCLUDED_DIRS = {
                ".git", ".github", ".idea", ".vscode", "__pycache__", "node_modules", "js", "static", "htmlcov", "docs", "templates",
                "build", "dist", "target", ".venv", "venv", ".mypy_cache", ".pytest_cache", 'migrations', "css"
            }
        root = Path(project_root)
        ex = set(EXCLUDED_DIRS)
        names: Set[str] = set()
        for cur, dirs, _ in os.walk(root):
            # 就地过滤可大幅减少遍历分支
            dirs[:] = [d for d in dirs if d not in ex]
            names.update(dirs)
        return names

    @staticmethod
    def _first_segment(module: Optional[str]) -> Optional[str]:
        if not module:
            return None
        return module.split('.', 1)[0]
    
    def analysis_failure(self, source_code: str, dir_index: list = None):
        # 退化：只按文本统计“项目内导入”，并按成员数计
        norm = re.sub(r"\\\s*\n", " ", source_code)  # 合并反斜杠续行
        import_count = 0

        for raw in norm.splitlines():
            line = raw.split("#", 1)[0].strip()
            if not line:
                continue

            # from xxx import a, b
            if line.startswith("from "):
                m = re.match(r"from\s+(\S+)\s+import\s+(.+)$", line)
                if not m:
                    continue
                mod, names = m.group(1).strip(), m.group(2).strip()
                seg = self._first_segment(mod)
                internal = mod.startswith(".") or bool(seg and seg in dir_index)
                if not internal:
                    continue

                names = names.replace("(", " ").replace(")", " ")
                if "*" in names:
                    import_count += 1
                else:
                    import_count += sum(1 for x in names.split(",") if x.strip())

            # import a, b.c as x
            elif line.startswith("import "):
                mods = line[len("import "):].strip()
                for part in mods.split(","):
                    token = part.strip().split(" as ", 1)[0].strip()
                    root = token.split(".", 1)[0] if token else ""
                    if root and root in dir_index:
                        import_count += 1

        return import_count  # 退化场景下不统计参数（无法可靠解析）

    def calculate_cyclomatic_complexity(self, source_code: str) -> int:
        """
        计算 Python 代码圈复杂度（McCabe）：
        - 基础复杂度为 1
        - 计入的决策点包括：
          * if / elif
          * for / while / async for
          * 布尔运算 and / or（a and b and c => +2）
          * 三元表达式 x if cond else y
          * try 中的每个 except 分支
          * 推导式中的 for / if（list/set/dict/generator comprehensions）
          * match 中的每个 case（Python 3.10+）
          * assert
        """
        try:
            tree = ast.parse(source_code)
        except SyntaxError:
            # 解析失败时，退化为按行数估算
            return max(1, len(source_code.splitlines()))

        complexity = 1  # 基础复杂度

        for node in ast.walk(tree):
            # if / elif
            if isinstance(node, ast.If):
                complexity += 1

            # for / while / async for
            elif isinstance(node, (ast.For, ast.While)):
                complexity += 1
            elif isinstance(node, ast.AsyncFor):
                complexity += 1

            # 布尔运算 and / or
            elif isinstance(node, ast.BoolOp):
                # a and b and c -> 增加 2
                complexity += max(0, len(node.values) - 1)

            # 三元表达式 x if cond else y
            elif isinstance(node, ast.IfExp):
                complexity += 1

            # try/except：每个 except 分支算一个决策点
            elif isinstance(node, ast.Try):
                complexity += len(node.handlers)

            # 推导式中的 for / if：ast.comprehension
            elif isinstance(node, ast.comprehension):
                # 一个 for
                complexity += 1
                # 可能有多个 if 过滤条件
                complexity += len(node.ifs)

            # Python 3.10+ 的 match/case
            # hasattr 防止在低版本 Python 上 AttributeError
            elif hasattr(ast, "Match") and isinstance(node, ast.Match):
                complexity += len(node.cases)

            # assert 也视作一个隐式条件判断
            elif isinstance(node, ast.Assert):
                complexity += 1

            # 注意：不对 with / async with 加复杂度
            # 一般它们不被当作“分支决策点”

        return complexity

    def calculate_dependency_complexity(self, source_code: str, dir_index: list = None) -> int:
        """
        粗略的“依赖复杂度”估计：
        - import / from ... import 的数量（按导入的名字数计）
        - 函数/方法的参数数量（包含 *args / **kwargs / kwonlyargs 等，
          并默认不把 self/cls 算在内）
        """

        import_count = 0
        param_count = 0

        try:
            tree = ast.parse(source_code)
        except SyntaxError:
            # 解析失败时退化：用 import 行数做个大致估计
            import_count = self.analysis_failure(source_code, dir_index)

            return import_count, param_count
        
       
        for node in ast.walk(tree):
            # 1） import 语句
            if isinstance(node, ast.Import):
                for alias in node.names:
                    root = self._first_segment(alias.name)
                    if root in dir_index:
                        import_count += 1
            #  or from ... import ...
            elif isinstance(node, ast.ImportFrom):
                # 是否满足“相对导入”或“项目内绝对导入”
                is_relative = getattr(node, "level", 0) >= 1
                first_seg = self._first_segment(getattr(node, "module", None))
                is_internal_abs = (first_seg in dir_index) if first_seg else False
                if not (is_relative or is_internal_abs):
                    continue
              
                # 统计 import 的成员数量；若为 * 用 1 表示
                if any(alias.name == '*' for alias in node.names):
                    import_count += 1
                else:
                    import_count += len(node.names)
            # 2) 函数 / 方法参数
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                args = node.args

                # 位置仅参数（3.8+）+ 普通位置参数
                posonly = getattr(args, "posonlyargs", [])
                total_args = len(posonly) + len(args.args)

                # 关键字仅参数
                total_args += len(args.kwonlyargs)

                # *args / **kwargs
                if args.vararg is not None:
                    total_args += 1
                if args.kwarg is not None:
                    total_args += 1

                # 方法的第一个参数如果叫 self / cls，可以不算依赖复杂度
                first_params = (posonly + args.args)
                if first_params:
                    first_name = first_params[0].arg
                    if first_name in ("self", "cls"):
                        total_args = max(0, total_args - 1)

                param_count += max(0, total_args)

        dependency_complexity = import_count + param_count
        return import_count, param_count

    def _should_skip_file(self, filename: str) -> bool:
        """判断是否是可以跳过的特殊 Python 文件."""
        lower = filename.lower()
        if filename == "__init__.py":
            return True
        if "config" in lower or "settings" in lower:
            return True
        # 以后可以在这里继续加 rules
        return False

    def analyze(self, source_file: str, test_file: str, root_path: str = None) -> Dict[str, Any]:
        """分析 Python 文件的覆盖率"""
        filename = os.path.basename(source_file)

        #找出项目的所有目录名字
        dir_index = self.build_dir_index(root_path)

        # 先判断是否需要跳过
        if self._should_skip_file(filename):
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language="python",
                total_testable_elements=0,
                tested_elements=0,
                coverage_percentage=0.0,
                uncovered_elements=[],
                code_similarity=0.0,
                cyclomatic_complexity=0,
                dependency_complexity=0,
            )

        # 读源代码
        try:
            source_code = read_file(source_file)
        except OSError:
            # 文件读不到，直接给默认结果
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language="python"
            )

        # 提取可测试元素
        def _collect_testable_elements(tree: ast.AST):
            elements = []

            for node in ast.walk(tree):
                # 普通函数 / 异步函数
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    # 跳过私有方法、main
                    if node.name.startswith("_") or node.name == "main":
                        continue

                    # 判断是否“无逻辑”的简单函数
                    body = node.body or []
                    if not body:
                        continue
                    if len(body) == 1:
                        stmt = body[0]
                        # 只有 pass
                        if isinstance(stmt, ast.Pass):
                            continue
                        # 只有一个 docstring
                        if (
                            isinstance(stmt, ast.Expr)
                            and isinstance(stmt.value, (ast.Constant, ast.Str))
                        ):
                            continue

                    elements.append(node.name)

                # 类：只把有“有意义方法”的非抽象类算作一个可测试元素
                elif isinstance(node, ast.ClassDef):
                    class_name = node.name
                    if class_name.startswith("_"):
                        continue

                    # 粗略判断是否抽象基类
                    is_abstract = False
                    for base in node.bases:
                        if isinstance(base, ast.Name) and base.id in ("ABC", "ABCMeta"):
                            is_abstract = True
                            break
                    if not is_abstract:
                        # 原代码里通过 AnnAssign + abstractmethod 检查，这里保留
                        for stmt in ast.walk(node):
                            if (
                                isinstance(stmt, ast.AnnAssign)
                                and isinstance(stmt.value, ast.Call)
                                and getattr(stmt.value.func, "id", "") == "abstractmethod"
                            ):
                                is_abstract = True
                                break

                    if is_abstract:
                        continue

                    # 跳过“纯数据类”：只有魔法方法或私有方法
                    methods = [n for n in node.body if isinstance(n, ast.FunctionDef)]
                    meaningful_methods = [
                        m
                        for m in methods
                        if not m.name.startswith("_")
                        or m.name in ("__eq__", "__hash__", "__str__", "__repr__")
                    ]
                    if not meaningful_methods:
                        continue

                    elements.append(f"class_{class_name}")

            return elements

        try:
            tree = ast.parse(source_code)
        except SyntaxError:
            # 源文件语法都不合法，没法分析逻辑，只算复杂度
            cyclomatic, dependency, param_complexity = self.calculate_complexity(source_code, dir_index)
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language="python",
                total_testable_elements=0,
                tested_elements=0,
                coverage_percentage=0.0,
                uncovered_elements=[],
                code_similarity=0.0,
                cyclomatic_complexity=cyclomatic,
                dependency_complexity=dependency,
                param_complexity=param_complexity
            )

        try:
            cyclomatic, dependency, param_complexity = self.calculate_complexity(source_code, dir_index)
        except Exception:
            cyclomatic, dependency, param_complexity = 0, 0, 0

        testable_elements = _collect_testable_elements(tree)

        # 读测试文件：读失败就当“没有任何测试覆盖”
        try:
            test_code = ''
            if test_file is not None:
                test_code = read_file(test_file)
        except OSError:
            return CoverageResult(
                    source_file=source_file,
                    test_file=test_file,
                    language=self.language,
                    total_testable_elements=len(testable_elements),
                    uncovered_elements=testable_elements,
                    cyclomatic_complexity=cyclomatic,
                    dependency_complexity=dependency,
                    param_complexity=param_complexity
                )

        # 查找测试函数中调用的源元素（简单基于正则，想更精确可以换成 AST）
        tested_elements = []
        uncovered_elements = []
        for element in testable_elements:
            if element.startswith("class_"):
                class_name = element[6:]
                pattern = r"\b" + re.escape(class_name) + r"\b"
            else:
                # 函数：匹配 foo( 这种调用形式
                pattern = r"\b" + re.escape(element) + r"\s*\("

            if re.search(pattern, test_code):
                tested_elements.append(element)
            else:
                uncovered_elements.append(element)

        total = len(testable_elements)
        tested = len(tested_elements)
        coverage = round(tested / total * 100, 2) if total > 0 else 100.0

        return CoverageResult(
            source_file=source_file,
            test_file=test_file,
            language="python",
            total_testable_elements=total,
            tested_elements=tested,
            coverage_percentage=coverage,
            uncovered_elements=uncovered_elements,
            cyclomatic_complexity=cyclomatic,
            dependency_complexity=dependency,
            param_complexity=param_complexity
        )
