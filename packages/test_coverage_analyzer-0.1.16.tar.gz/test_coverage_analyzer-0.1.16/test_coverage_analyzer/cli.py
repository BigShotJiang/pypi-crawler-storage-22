"""命令行接口"""
import os
import sys
import traceback
from typing import List, Dict, Optional

from pathlib import Path

# from .finder import TestFileFinder
# from .analyzer import AnalyzerFactory
# from .utils import (
#     process_results_to_prompts,
#     process_results_to_json,
#     merge_sort_coverage_data
# )
# from .common import write_file
# from .prompts import project_files_template
# from .gitops.repo import GitRepo

# TODO: for debugging
from .finder import TestFileFinder
from .analyzer import AnalyzerFactory
from .utils import (
    process_results_to_prompts,
    process_results_to_json,
    merge_sort_coverage_data
)
from .common import write_file, write_json
from .prompts import project_files_template, unittest_augmentation_template, unittest_generation_template
from .common.tempfile_utils import temp_dir
from .gitops.repo import GitRepo
from .gitops.diff_analyzer import GitDiffAnalyzer


def print_help():
    print("用法:")
    print("  test-coverage-analyzer <源代码路径> [输出目录] [文件名前缀] [options]")
    print("  test-coverage-analyzer --git <repo_url> --target-branch <branch> "
          "[--source-branch <branch>] [输出目录] [文件名前缀] [options]")
    print("  test-coverage-analyzer --compare-dirs --source-dir <dir> --target-dir <dir> "
          "[输出目录] [文件名前缀] [options]")
    print()
    print("代码来源参数（三选一）:")
    print("  <源代码路径>              本地项目源码路径")
    print("  --git <repo_url>          Git 仓库地址（HTTP/SSH）")
    print("  --compare-dirs            比较两个本地目录的差异（无需Git仓库）")
    print()
    print("Git 分支参数（Git 模式必需）:")
    print("  --target-branch <branch>  目标分支（可选，通常为 develop/main/master）")
    print("  --source-branch <branch>  源分支（必填）")
    print("  --diff-only               仅分析 source 相对 target 的 diff 文件")
    print()
    print("本地目录比较参数（Compare Dirs 模式必需）:")
    print("  --source-dir <directory>  源目录路径（通常是 feature 分支的副本）")
    print("  --target-dir <directory>  目标目录路径（通常是 develop 分支的副本）")
    print()
    print("分析参数:")
    print("  --threshold <阈值>        覆盖率阈值（0-100），过滤覆盖率高于阈值的文件")
    print("  --limit <数量>            限制处理的文件数量（0-200）")
    print("  --prompt                  对 JSON 结果进行二次处理，生成文件粒度的单测 prompts")
    print("  --print                   将结果打印到终端（默认不打印）")
    print("  -h, --help                显示帮助信息")
    print()
    print("环境变量（Git 模式下必需）:")
    print("  GITLAB_USERNAME")
    print("  GITLAB_TOKEN")
    print("  GITLAB_INSTANCE_URL")
    print("  GIT_WORKDIR")
    print()
    print("示例:")
    print("  test-coverage-analyzer ./my_project")
    print("  test-coverage-analyzer ./my_project ./reports my_result --threshold 50")
    print("  test-coverage-analyzer --git https://gitlab.xxx.com/a/b.git "
          "--target-branch main --source-branch feature_x --diff-only --prompt")
    print()
    print("本地目录比较示例:")
    print("  test-coverage-analyzer --compare-dirs --source-dir ./feature_branch_code "
          "--target-dir ./develop_branch_code --prompt")


def compare_dirs(source_dir: str, target_dir: str) -> List[Dict]:
    """
    比较两个目录的差异，生成类似git diff的结果

    Args:
        source_dir: 源目录（通常是feature分支）
        target_dir: 目标目录（通常是develop分支）

    Returns:
        List[Dict]: 包含file、change_type、patch的字典列表
    """
    from difflib import unified_diff

    diffs = []

    source_files = {}
    target_files = {}

    for root, dirs, files in os.walk(source_dir):
        for f in files:
            full_path = os.path.join(root, f)
            rel_path = os.path.relpath(full_path, source_dir)
            source_files[rel_path] = full_path

    for root, dirs, files in os.walk(target_dir):
        for f in files:
            full_path = os.path.join(root, f)
            rel_path = os.path.relpath(full_path, target_dir)
            target_files[rel_path] = full_path

    all_files = set(source_files.keys()) | set(target_files.keys())

    for rel_path in all_files:
        source_file = source_files.get(rel_path)
        target_file = target_files.get(rel_path)

        if source_file and not target_file:
            try:
                with open(source_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                patch_lines = ["+++ " + source_file, "@@ -0,0 +1,@@"]
                patch_lines.extend("+ " + line for line in content.splitlines())
                patch = "\n".join(patch_lines)
                diffs.append({
                    "file": source_file,
                    "change_type": "added",
                    "patch": patch,
                })
            except Exception:
                pass
        elif not source_file and target_file:
            diffs.append({
                "file": target_file,
                "change_type": "deleted",
                "patch": "",
            })
        elif source_file and target_file:
            try:
                with open(source_file, 'r', encoding='utf-8') as f:
                    source_content = f.read()
                with open(target_file, 'r', encoding='utf-8') as f:
                    target_content = f.read()

                if source_content != target_content:
                    source_lines = target_content.splitlines()
                    target_lines = source_content.splitlines()
                    diff = list(unified_diff(
                        source_lines, target_lines,
                        fromfile=os.path.relpath(target_file, target_dir),
                        tofile=os.path.relpath(source_file, source_dir),
                        lineterm=''
                    ))
                    patch = "\n".join(diff)
                    diffs.append({
                        "file": source_file,
                        "change_type": "modified",
                        "patch": patch,
                    })
            except Exception:
                pass

    return diffs


def analyse_compare_dirs(source_dir: str, target_dir: str, output_dir: str, file_prefix: str, prompt: bool, print_to_terminal: bool):
    """基于两个本地目录的差异分析模式"""
    md_path = os.path.join(output_dir, f"{file_prefix}.md")
    try:
        print(f"正在分析目录差异: {target_dir} -> {source_dir}")

        diffs = compare_dirs(source_dir, target_dir)
        print(f"获取到 {len(diffs)} 个差异文件")

        filtered_diffs = GitDiffAnalyzer.filter_deleted(diffs)
        print(f"过滤 deleted 后剩余 {len(filtered_diffs)} 个文件")

        finder = TestFileFinder()

        need_generation_added = []
        need_generation_modified = []
        need_augmentation = []
        skipped = 0

        for diff in filtered_diffs:
            file_path = diff['file']
            change_type = diff.get('change_type', 'modified')

            if GitDiffAnalyzer.should_skip_file(file_path):
                skipped += 1
                continue

            has_test = _check_has_test_file(file_path, finder)

            analysis = GitDiffAnalyzer.analyze_diff(diff, has_test)
            if analysis is None:
                skipped += 1
                continue

            if change_type == 'added':
                need_generation_added.append({
                    'source_file': file_path,
                    'change_type': 'added',
                })
            elif change_type == 'modified':
                if not has_test:
                    need_generation_modified.append({
                        'source_file': file_path,
                        'change_type': 'modified',
                    })
                else:
                    if analysis.needs_augmentation:
                        need_augmentation.append({
                            'source_file': file_path,
                            'test_file': _find_test_file(file_path, finder),
                            'changed_functions': analysis.changed_functions,
                            'change_type': 'modified',
                        })

        print(f"分析完成: 生成新增={len(need_generation_added)}, 生成修改={len(need_generation_modified)}, 增量={len(need_augmentation)}, 跳过={skipped}")

        if prompt:
            prompt_data = []

            for item in need_generation_added:
                prompt_data.append({
                    'id': item['source_file'],
                    'prompt': unittest_generation_template.format(source_file=item['source_file'])
                })

            for item in need_generation_modified:
                prompt_data.append({
                    'id': item['source_file'],
                    'prompt': unittest_generation_template.format(source_file=item['source_file'])
                })

            for item in need_augmentation:
                prompt_data.append({
                    'id': item['source_file'],
                    'prompt': unittest_augmentation_template.format(
                        source_file=item['source_file'],
                        test_file=item['test_file'],
                        uncovered_elements=item.get('changed_functions', []),
                    )
                })

            prompt_json_path = os.path.join(output_dir, f"{file_prefix}_prompt.json")
            write_json(prompt_json_path, prompt_data)
            print(f"  Prompt JSON文件: {prompt_json_path}")

        added_files = [item['source_file'] for item in need_generation_added]
        modified_files = [item['source_file'] for item in need_generation_modified]
        augmented_files = [item['source_file'] for item in need_augmentation]

        md_content = f"""=== 待测文件列表 ===

=== 新增文件 (added) - 需要生成单元测试 ===
{chr(10).join(added_files) if added_files else '无'}

=== 修改文件(modified) - 无测试文件需生成，有测试文件需增量补充 ===
{chr(10).join(modified_files) if modified_files else '无'}

=== 需要增量补充测试(augmentation) ===
{chr(10).join(augmented_files) if augmented_files else '无'}

=== 所有待处理文件 ===
{chr(10).join(added_files + modified_files + augmented_files) if (added_files + modified_files + augmented_files) else '无'}
"""

        write_file(md_path, md_content)
        print(f"结果已保存到: {md_path}")

        if print_to_terminal:
            print(md_content)

    except Exception as e:
        print(f"错误: {e}")
        traceback.print_exc()
        sys.exit(1)


def analyse_diff_only(source_path, repo, source_branch, target_branch, output_dir, file_prefix, prompt, limit, print_to_terminal):
    """基于 git diff 的增量分析模式"""
    md_path = os.path.join(output_dir, f"{file_prefix}.md")
    try:
        print(f"正在分析 git diff: {source_branch} -> {target_branch}")

        diffs = repo.get_merge_request_diffs(source_branch, target_branch)
        print(f"获取到 {len(diffs)} 个差异文件")

        filtered_diffs = GitDiffAnalyzer.filter_deleted(diffs)
        print(f"过滤 deleted 后剩余 {len(filtered_diffs)} 个文件")

        finder = TestFileFinder()

        need_generation = []
        need_augmentation = []
        skipped = 0

        for diff in filtered_diffs:
            file_path = diff['file']
            change_type = diff.get('change_type', 'modified')

            if GitDiffAnalyzer.should_skip_file(file_path):
                skipped += 1
                continue

            has_test = _check_has_test_file(file_path, finder)

            analysis = GitDiffAnalyzer.analyze_diff(diff, has_test)
            if analysis is None:
                skipped += 1
                continue

            if change_type == 'added':
                need_generation.append({
                    'source_file': file_path,
                    'change_type': 'added',
                })
            elif change_type == 'modified':
                if not has_test:
                    need_generation.append({
                        'source_file': file_path,
                        'change_type': 'modified',
                    })
                else:
                    if analysis.needs_augmentation:
                        need_augmentation.append({
                            'source_file': file_path,
                            'test_file': _find_test_file(file_path, finder),
                            'changed_functions': analysis.changed_functions,
                        })

        print(f"分析完成: 生成={len(need_generation)}, 增量={len(need_augmentation)}, 跳过={skipped}")

        if prompt:
            prompt_data = []
            for item in need_generation:
                prompt_data.append({
                    'id': item['source_file'],
                    'prompt': unittest_generation_template.format(source_file=item['source_file'])
                })
            for item in need_augmentation:
                prompt_data.append({
                    'id': item['source_file'],
                    'prompt': unittest_augmentation_template.format(
                        source_file=item['source_file'],
                        test_file=item['test_file'],
                        uncovered_elements=item.get('changed_functions', []),
                    )
                })
            prompt_json_path = os.path.join(output_dir, f"{file_prefix}_prompt.json")
            write_json(prompt_json_path, prompt_data)
            print(f"  Prompt JSON文件: {prompt_json_path}")

        file_result = [item['source_file'] for item in need_generation + need_augmentation]
        project_res_prompts = project_files_template.format(file_result="\n".join(file_result))

        write_file(md_path, project_res_prompts)
        print(f"结果已保存到: {md_path}")

        if print_to_terminal:
            print(project_res_prompts)

    except Exception as e:
        print(f"错误: {e}")
        traceback.print_exc()
        sys.exit(1)


def _check_has_test_file(file_path: str, finder: TestFileFinder) -> bool:
    """检查文件是否有对应的测试文件"""
    try:
        lang = _detect_language(file_path)
        if lang is None:
            return False

        matcher = finder.registry.get(lang)
        if matcher is None:
            return False

        possible_test_names = matcher.build_possible_test_names(file_path)

        # 查找策略：多个可能的位置
        search_paths = []

        # 统一使用正斜杠处理路径（兼容Windows）
        normalized_path = file_path.replace('\\', '/')

        # 1. 同目录
        file_dir = os.path.dirname(file_path)
        search_paths.append(file_dir)

        # 2. 对于Java项目，尝试 src/test/java 对应 src/main/java 的结构
        if 'src/main/java' in normalized_path:
            test_dir = normalized_path.replace('src/main/java', 'src/test/java')
            search_paths.append(os.path.dirname(test_dir).replace('/', os.sep))
        # 3. 对于Java项目，反过来尝试
        elif 'src/test/java' in normalized_path:
            main_dir = normalized_path.replace('src/test/java', 'src/main/java')
            search_paths.append(os.path.dirname(main_dir).replace('/', os.sep))

        # 4. 查找最近的test目录
        parts = file_path.replace('\\', '/').split('/')
        for i, part in enumerate(parts):
            if part in ['test', 'tests', 'src']:
                if part == 'src':
                    if i + 2 < len(parts) and parts[i + 1] == 'main':
                        test_candidate = os.sep.join(parts[:i] + ['src', 'test'] + parts[i + 2:])
                        search_paths.append(test_candidate)
                    elif i + 2 < len(parts) and parts[i + 1] == 'test':
                        main_candidate = os.sep.join(parts[:i] + ['src', 'main'] + parts[i + 2:])
                        search_paths.append(main_candidate)

        for test_dir in search_paths:
            for test_name in possible_test_names:
                test_path = os.path.join(test_dir, test_name)
                if os.path.exists(test_path):
                    return True

        return False
    except Exception:
        return False


def _find_test_file(file_path: str, finder: TestFileFinder) -> str:
    """查找文件对应的测试文件路径"""
    try:
        lang = _detect_language(file_path)
        if lang is None:
            return None

        matcher = finder.registry.get(lang)
        if matcher is None:
            return None

        possible_test_names = matcher.build_possible_test_names(file_path)

        # 查找策略：多个可能的位置
        search_paths = []

        # 统一使用正斜杠处理路径（兼容Windows）
        normalized_path = file_path.replace('\\', '/')

        # 1. 同目录
        file_dir = os.path.dirname(file_path)
        search_paths.append(file_dir)

        # 2. 对于Java项目，尝试 src/test/java 对应 src/main/java 的结构
        if 'src/main/java' in normalized_path:
            test_dir = normalized_path.replace('src/main/java', 'src/test/java')
            search_paths.append(os.path.dirname(test_dir).replace('/', os.sep))
        # 3. 对于Java项目，反过来尝试
        elif 'src/test/java' in normalized_path:
            main_dir = normalized_path.replace('src/test/java', 'src/main/java')
            search_paths.append(os.path.dirname(main_dir).replace('/', os.sep))

        # 4. 查找最近的test目录
        parts = normalized_path.split('/')
        for i, part in enumerate(parts):
            if part in ['test', 'tests', 'src']:
                if part == 'src':
                    if i + 2 < len(parts) and parts[i + 1] == 'main':
                        test_candidate = os.sep.join(parts[:i] + ['src', 'test'] + parts[i + 2:])
                        search_paths.append(test_candidate)
                    elif i + 2 < len(parts) and parts[i + 1] == 'test':
                        main_candidate = os.sep.join(parts[:i] + ['src', 'main'] + parts[i + 2:])
                        search_paths.append(main_candidate)

        for test_dir in search_paths:
            for test_name in possible_test_names:
                test_path = os.path.join(test_dir, test_name)
                if os.path.exists(test_path):
                    return test_path

        return None
    except Exception:
        return None


def _detect_language(file_path: str) -> str:
    """根据文件扩展名检测语言"""
    ext = os.path.splitext(file_path)[1].lower()
    lang_map = {
        '.py': 'python',
        '.java': 'java',
        '.go': 'go',
        '.cpp': 'cpp',
        '.cc': 'cpp',
        '.c': 'c',
        '.js': 'javascript',
        '.ts': 'typescript',
    }
    return lang_map.get(ext)


def analyse(source_path, threshold, prompt, limit, print_to_terminal, output_dir, file_prefix):
    """全量分析模式"""
    finder = TestFileFinder()
    md_path = os.path.join(output_dir, f"{file_prefix}.md")
    try:
        print(f"正在分析路径: {source_path}")

        matches, unmatched = finder.find_test_files(source_path)

        coverage_results = []
        for match in matches:
            if match.language == 'python':
                coverage_result = AnalyzerFactory.get_analyzer(match.language).analyze(
                    match.source_file, 
                    match.test_file,
                    source_path
                )
            else:
                coverage_result = AnalyzerFactory.get_analyzer(match.language).analyze(
                    match.source_file, 
                    match.test_file
                )
            coverage_result.compute_roi_score()
            coverage_results.append(coverage_result)

        if threshold is not None:
            filtered_matches = []
            filtered_coverage_results = []

            for match, coverage_result in zip(matches, coverage_results):
                if coverage_result.coverage_percentage < threshold:
                    filtered_matches.append(match)
                    filtered_coverage_results.append(coverage_result)

            matches = filtered_matches
            coverage_results = filtered_coverage_results

        unmatched_results = []
        for m in unmatched:
            if m.language == 'python':
                unmatched_result = AnalyzerFactory.get_analyzer(m.language).analyze(
                    m.source_file, 
                    m.test_file,
                    source_path
                )
            else:
                unmatched_result = AnalyzerFactory.get_analyzer(m.language).analyze(
                    m.source_file, 
                    m.test_file
                )
            if not unmatched_result.uncovered_elements:
                continue
            unmatched_result.compute_roi_score()
            unmatched_results.append(unmatched_result)

        json_data = process_results_to_json(matches, unmatched, coverage_results, unmatched_results)

        if prompt:
            prompt_data = process_results_to_prompts(json_data)
            prompt_json_path = os.path.join(output_dir, f"{file_prefix}_prompt.json")
            write_json(prompt_json_path, prompt_data)
            print(f"  Prompt JSON文件: {prompt_json_path}")

        json_results = merge_sort_coverage_data(json_data, limit=limit)
        project_res_prompts = project_files_template.format(file_result="\n".join([file_res['source_file'] \
            for file_res in json_results['coverage_results']]))

        write_file(md_path, project_res_prompts)
        print(f"结果已保存到: {md_path}")

        if print_to_terminal:
            print(project_res_prompts)

    except Exception as e:
        print(f"错误: {e}")
        traceback.print_exc()
        sys.exit(1)
    finder = TestFileFinder()
    # 构建完整的文件路径
    md_path = os.path.join(output_dir, f"{file_prefix}.md")
    try:
        print(f"正在分析路径: {source_path}")

        matches, unmatched = finder.find_test_files(source_path)

        # 分析覆盖率
        coverage_results = []
        for match in matches:
            if match.language == 'python':
                coverage_result = AnalyzerFactory.get_analyzer(match.language).analyze(
                    match.source_file, 
                    match.test_file,
                    source_path
                )
            else:
                coverage_result = AnalyzerFactory.get_analyzer(match.language).analyze(
                    match.source_file, 
                    match.test_file
                )
            coverage_result.compute_roi_score()
            coverage_results.append(coverage_result)

        # 应用阈值过滤
        if threshold is not None:
            filtered_matches = []
            filtered_coverage_results = []

            for match, coverage_result in zip(matches, coverage_results):
                if coverage_result.coverage_percentage < threshold:
                    filtered_matches.append(match)
                    filtered_coverage_results.append(coverage_result)

            matches = filtered_matches
            coverage_results = filtered_coverage_results

        # 分析未匹配文件的复杂度
        unmatched_results = []
        for m in unmatched:
            if m.language == 'python':
                unmatched_result = AnalyzerFactory.get_analyzer(m.language).analyze(
                    m.source_file, 
                    m.test_file,
                    source_path
                )
            else:
                unmatched_result = AnalyzerFactory.get_analyzer(m.language).analyze(
                    m.source_file, 
                    m.test_file
                )
            # 跳过没有可测元素的文件（抽象类、接口类）
            if not unmatched_result.uncovered_elements:
                continue
            unmatched_result.compute_roi_score()
            unmatched_results.append(unmatched_result)

        # 保存结果
        json_data = process_results_to_json(matches, unmatched, coverage_results, unmatched_results)

        # 如果开启prompt处理
        if prompt:
            # 转换为prompt格式
            prompt_data = process_results_to_prompts(json_data)
            # 保存prompt文件
            prompt_json_path = os.path.join(output_dir, f"{file_prefix}_prompt.json")
            write_json(prompt_json_path, prompt_data)
            print(f"  Prompt JSON文件: {prompt_json_path}")

        json_results = merge_sort_coverage_data(json_data, limit=limit)
        project_res_prompts = project_files_template.format(file_result="\n".join([file_res['source_file'] \
            for file_res in json_results['coverage_results']]))

        write_file(md_path, project_res_prompts)
        print(f"结果已保存到: {md_path}")

        if print_to_terminal:
            print(project_res_prompts)

    except Exception as e:
        print(f"错误: {e}")
        traceback.print_exc()
        sys.exit(1)


def main():
    """主函数，提供命令行接口"""
    # 处理 --help / -h
    if len(sys.argv) == 1 or any(arg in ("-h", "--help") for arg in sys.argv):
        print_help()
        sys.exit(0)
    # -------------------------
    # 默认值
    # -------------------------
    source_path = None          # 本地源码路径
    git_repo = None             # Git 仓库地址
    target_branch = None
    source_branch = None
    diff_only = False
    compare_dirs_mode = False   # 本地目录比较模式
    source_dir = None           # 比较模式下的源目录
    target_dir = None           # 比较模式下的目标目录

    default_output_dir = "./"
    default_file_prefix = "test_scanner_result"
    output_dir = default_output_dir
    file_prefix = default_file_prefix

    # 默认不开启prompt处理
    prompt = False
    # 覆盖率默认阈值80%
    threshold = 80
    # 默认限制文件个数200
    limit = 200
    # 是否打印到终端，默认不开启
    print_to_terminal = False

    # -------------------------
    # 命令行参数解析
    # -------------------------
    arg_index = 1
    while arg_index < len(sys.argv):
        arg = sys.argv[arg_index]
        if arg == '--git':
            arg_index += 1
            if arg_index >= len(sys.argv):
                print("错误: --git 需要指定仓库地址")
                sys.exit(1)
            git_repo = sys.argv[arg_index]

        elif arg == '--target-branch':
            arg_index += 1
            if arg_index >= len(sys.argv):
                print("错误: --target-branch 需要指定分支名")
                sys.exit(1)
            target_branch = sys.argv[arg_index]

        elif arg == '--source-branch':
            arg_index += 1
            if arg_index >= len(sys.argv):
                print("错误: --source-branch 需要指定分支名")
                sys.exit(1)
            source_branch = sys.argv[arg_index]

        elif arg == '--diff-only':
            diff_only = True

        elif arg == '--compare-dirs':
            compare_dirs_mode = True

        elif arg == '--source-dir':
            arg_index += 1
            if arg_index >= len(sys.argv):
                print("错误: --source-dir 需要指定源目录路径")
                sys.exit(1)
            source_dir = sys.argv[arg_index]

        elif arg == '--target-dir':
            arg_index += 1
            if arg_index >= len(sys.argv):
                print("错误: --target-dir 需要指定目标目录路径")
                sys.exit(1)
            target_dir = sys.argv[arg_index]

        elif arg == '--threshold':
            arg_index += 1
            if arg_index >= len(sys.argv):
                print("错误: --threshold 参数需要指定一个数值")
                sys.exit(1)
            try:
                threshold = float(sys.argv[arg_index])
                if threshold < 0 or threshold > 100:
                    raise ValueError
            except Exception:
                print(f"错误:  --threshold 必须是 0-100 之间的数字，得到: {sys.argv[arg_index]}")
                sys.exit(1)

        elif arg == '--limit':
            arg_index += 1
            if arg_index >= len(sys.argv):
                print("错误: --limit 参数需要指定一个数值")
                sys.exit(1)
            try:
                limit = int(sys.argv[arg_index])
                if limit < 0 or limit > 200:
                    raise ValueError
            except Exception:
                print(f"错误: --limit 必须是 0-200 之间的整数，得到: {sys.argv[arg_index]}")
                sys.exit(1)

        elif arg == '--prompt':
            prompt = True

        elif arg == '--print':
            print_to_terminal = True

        elif not arg.startswith('--'):
            if source_path is None and git_repo is None:
                source_path = arg
            # 位置参数：输出目录和文件名前缀
            elif output_dir == default_output_dir:
                output_dir = arg
            elif file_prefix == default_file_prefix:
                file_prefix = arg
            else:
                print(f"错误: 无效参数 '{arg}'")
                sys.exit(1)
        else:
            print(f"错误: 未知参数 '{arg}'")
            sys.exit(1)

        arg_index += 1

    base_workdir = os.environ.get("GIT_WORKDIR", "./temp")
    repo = None

    try:
        Path(output_dir).mkdir(parents=True, exist_ok=True)
    except Exception as e:
        print(f"错误: 无法创建输出目录 '{output_dir}': {e}")
        sys.exit(1)

    if compare_dirs_mode:
        if not source_dir or not target_dir:
            print("错误: --compare-dirs 模式需要同时指定 --source-dir 和 --target-dir")
            sys.exit(1)

        if not os.path.exists(source_dir):
            print(f"错误: 源目录 '{source_dir}' 不存在")
            sys.exit(1)

        if not os.path.exists(target_dir):
            print(f"错误: 目标目录 '{target_dir}' 不存在")
            sys.exit(1)

        analyse_compare_dirs(
            source_dir, target_dir,
            output_dir, file_prefix, prompt, print_to_terminal
        )
    else:
        with temp_dir(prefix=f"git_{os.environ.get('GITLAB_USERNAME', '')}_", base_dir=base_workdir) as git_workdir:
            if git_repo is not None:
                try:
                    repo = GitRepo(
                        repo_dir=git_workdir,
                        repo_url=git_repo,
                        source_branch=source_branch
                    )
                    source_path = repo.repo.working_dir
                except Exception as e:
                    print(f"错误: {e}")
                    traceback.print_exc()
                    sys.exit(1)

            if source_path and not os.path.exists(source_path):
                print(f"错误: 源路径 '{source_path}' 不存在")
                sys.exit(1)

            if diff_only and repo is not None:
                analyse_diff_only(
                    source_path, repo, source_branch, target_branch,
                    output_dir, file_prefix, prompt, limit, print_to_terminal
                )
            elif source_path:
                analyse(source_path, threshold, prompt, limit, print_to_terminal, output_dir, file_prefix)
            else:
                print("错误: 请指定源路径或使用 --git / --compare-dirs 模式")
                sys.exit(1)


if __name__ == "__main__":
    main()
