import os
import sys
import pexpect
import psutil
import platform
import subprocess

from io import BytesIO


def run_cmd(command, verbose=False, error_print=None, cwd=None):
    try:
        if sys.stdin.isatty() and hasattr(pexpect, "spawn") and platform.system() != "Windows":
            return run_cmd_pexpect(command, verbose, cwd)

        return run_cmd_subprocess(command, verbose, cwd)
    except OSError as e:
        error_message = f"Error occurred while running command '{command}': {str(e)}"
        if error_print is None:
            print(error_message)
        else:
            error_print(error_message)
        return 1, error_message


def get_windows_parent_process_name():
    try:
        current_process = psutil.Process()
        while True:
            parent = current_process.parent()
            if parent is None:
                break
            parent_name = parent.name().lower()
            if parent_name in ["powershell.exe", "cmd.exe"]:
                return parent_name
            current_process = parent
        return None
    except Exception:
        return None


def run_cmd_subprocess(command, verbose=False, cwd=None, encoding=sys.stdout.encoding):
    """使用subprocess模块执行命令并实时输出结果。
    
    该函数通过subprocess.Popen执行指定的命令，支持实时输出显示，
    并根据操作系统环境自动选择合适的shell。在Windows环境下会检测
    父进程类型，如果是PowerShell则使用PowerShell语法执行命令。
    
    Args:
        command (str): 要执行的命令字符串
        verbose (bool, optional): 是否显示详细执行信息，默认为False
        cwd (str, optional): 命令执行的工作目录，默认为None（使用当前目录）
        encoding (str, optional): 输出编码格式，默认使用sys.stdout.encoding
    
    Returns:
        tuple: 包含两个元素的元组 (returncode, output)
            - returncode (int): 命令执行返回码，0表示成功，1表示异常
            - output (str): 命令执行输出的完整内容
    
    Note:
        - 使用shell=True执行命令，存在安全风险，请确保command参数安全
        - 实时输出通过逐字符读取实现，适合长时间运行的命令
        - Windows环境下自动适配PowerShell执行模式
    """
    if verbose:
        print("Using run_cmd_subprocess:", command)

    try:
        shell = os.environ.get("SHELL", "/bin/sh")
        parent_process = None

        # Determine the appropriate shell
        if platform.system() == "Windows":
            parent_process = get_windows_parent_process_name()
            if parent_process == "powershell.exe":
                command = f"powershell -Command {command}"

        if verbose:
            print("Running command:", command)
            print("SHELL:", shell)
            if platform.system() == "Windows":
                print("Parent process:", parent_process)

        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,      # 捕获标准输出
            stderr=subprocess.STDOUT,   # 将标准错误重定向到标准输出
            text=True,                  # 以文本模式处理输出
            shell=True,                 # 通过shell执行命令
            encoding=encoding,          # 指定输出编码
            errors="replace",           # 编码错误时使用替换字符
            bufsize=0,                  # 设置为0实现无缓冲输出
            universal_newlines=True,    # 启用通用换行符模式
            cwd=cwd,                    # 设置工作目录
        )

        output = []
        while True:
            chunk = process.stdout.read(1)
            if not chunk:
                break
            print(chunk, end="", flush=True)  # Print the chunk in real-time
            output.append(chunk)  # Store the chunk for later use

        process.wait()
        return process.returncode, "".join(output)
    except Exception as e:
        return 1, str(e)


def run_cmd_pexpect(command, verbose=False, cwd=None):
    """
    Run a shell command interactively using pexpect, capturing all output.

    :param command: The command to run as a string.
    :param verbose: If True, print output in real-time.
    :return: A tuple containing (exit_status, output)
    """
    if verbose:
        print("Using run_cmd_pexpect:", command)

    output = BytesIO()

    def output_callback(b):
        output.write(b)
        return b

    try:
        # Use the SHELL environment variable, falling back to /bin/sh if not set
        shell = os.environ.get("SHELL", "/bin/sh")
        if verbose:
            print("With shell:", shell)

        if os.path.exists(shell):
            # Use the shell from SHELL environment variable
            if verbose:
                print("Running pexpect.spawn with shell:", shell)
            child = pexpect.spawn(shell, args=["-i", "-c", command], encoding="utf-8", cwd=cwd)
        else:
            # Fall back to spawning the command directly
            if verbose:
                print("Running pexpect.spawn without shell.")
            child = pexpect.spawn(command, encoding="utf-8", cwd=cwd)

        # Transfer control to the user, capturing output
        child.interact(output_filter=output_callback)

        # Wait for the command to finish and get the exit status
        child.close()
        return child.exitstatus, output.getvalue().decode("utf-8", errors="replace")

    except (pexpect.ExceptionPexpect, TypeError, ValueError) as e:
        error_msg = f"Error running command {command}: {e}"
        return 1, error_msg
