# -*- coding: utf-8 -*-

# ----------------------------------------------------------------------
# Copyright © 2014-2026 China Mobile (SuZhou) Software Technology Co.,Ltd.
#
# The programs can not be copied and/or distributed without the express
# permission of China Mobile (SuZhou) Software Technology Co.,Ltd.
#
# Project name: test_coverage_analyzer
# Desc: 提供线程安全、多进程安全的临时目录创建和管理功能。
# 支持自动清理、上下文管理器等多种使用方式
#
# Create by wangaodi at 2026/02/04
#
# ----------------------------------------------------------------------
import os
import tempfile
import shutil
import contextlib
from typing import Optional, Generator, Callable


def create_temp_dir(
    prefix: str = "tmp_",
    suffix: str = "",
    base_dir: Optional[str] = None,
) -> str:
    """
    创建临时目录（多进程安全）

    """
    if base_dir:
        os.makedirs(base_dir, exist_ok=True)
    # mkdtemp 是 OS 级原子操作，可避免并发冲突
    return tempfile.mkdtemp(prefix=prefix, suffix=suffix, dir=base_dir)


def cleanup_temp_dir(path: str, ignore_errors: bool = True) -> None:
    """清理临时目录"""
    if not path:
        return
    shutil.rmtree(path, ignore_errors=ignore_errors)


@contextlib.contextmanager
def temp_dir(
    prefix: str = "tmp_",
    suffix: str = "",
    base_dir: Optional[str] = None,
    auto_cleanup: bool = True,
) -> Generator[str, None, None]:
    """
    临时目录上下文管理器
    """
    path = create_temp_dir(prefix, suffix, base_dir)
    try:
        yield path
    finally:
        if auto_cleanup:
            cleanup_temp_dir(path)


@contextlib.contextmanager
def temp_dir_chdir(
    prefix: str = "tmp_",
    suffix: str = "",
    base_dir: Optional[str] = None,
) -> Generator[str, None, None]:
    """
    创建临时目录并切换 cwd
    """
    path = create_temp_dir(prefix, suffix, base_dir)
    old_cwd = os.getcwd()

    try:
        os.chdir(path)
        yield path
    finally:
        try:
            os.chdir(old_cwd)
        finally:
            cleanup_temp_dir(path)


def with_temp_dir(
    param_name: str = "temp_dir",
    prefix: str = "func_",
    suffix: str = "",
    base_dir: Optional[str] = None,
    auto_cleanup: bool = True,
) -> Callable:
    """
    装饰器：为函数注入临时目录参数
    """
    def decorator(func: Callable) -> Callable:
        def wrapper(*args, **kwargs):
            path = create_temp_dir(prefix, suffix, base_dir)
            try:
                kwargs[param_name] = path
                return func(*args, **kwargs)
            finally:
                if auto_cleanup:
                    cleanup_temp_dir(path)
        return wrapper
    return decorator
