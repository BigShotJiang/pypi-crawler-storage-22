import os
from pathlib import Path
from typing import TYPE_CHECKING

from .base_test_matcher import BaseTestMatcher
from ..models import TestFileMatch

if TYPE_CHECKING:
    from .test_file_finder import TestFileFinder


class CTestMatcher(BaseTestMatcher):
    def __init__(self):
        super().__init__(
            language="c",
            source_pattern=r'.*\.c$',
            test_patterns=[
                r'.*_test\.c$',
                r'test_.*\.c$',
                r'.*_ut\.c$',
                r'.*_unittest\.c$'
            ],
            language_excludes=[
                r'.*config\.h$',
                r'.*constants\.h$',
                r'.*settings\.h$'
            ]
        )

        self.C_EXTENSIONS = [".c"]
        self.EXCLUDE_DIRS = {
            "build", "out", "dist", "bin", "obj",
            "third_party", "vendor", "deps", "external",
        }

        self.TEST_DIR_NAMES = {"test", "tests", "unit", "unittest"}

    def build_possible_test_names(self, source_file: str):
        name = Path(source_file).stem
        return [
            f"{name}_test.c",
            f"test_{name}.c",
            f"{name}_ut.c",
            f"{name}_unittest.c",
        ]

    def _is_test_file(self, filename: str, matcher: BaseTestMatcher) -> bool:
        return any(p.match(filename) for p in matcher.test_patterns)

    def is_matching_test(self, source_name: str, test_filename: str) -> bool:
        return (
            test_filename == f"{source_name}_test.c"
            or test_filename == f"test_{source_name}.c"
            or test_filename == f"{source_name}_ut.c"
            or test_filename == f"{source_name}_unittest.c"
        )

    def find_test_files(self, path: str, finder: "TestFileFinder"):
        all_files = []
        for root, dirs, files in os.walk(path):
            dirs[:] = [d for d in dirs if d.lower() not in self.EXCLUDE_DIRS]
            for f in files:
                all_files.append(os.path.join(root, f))

        all_files_set = set(all_files)

        dir_index = {}
        for f in all_files:
            dir_index.setdefault(os.path.dirname(f), []).append(f)

        test_dirs = {
            d for d in dir_index
            if os.path.basename(d).lower() in self.TEST_DIR_NAMES
        }

        matches = []
        unmatched = []

        for source in all_files:
            matcher = finder._get_language_matcher(source)
            if not matcher or matcher.language != "c":
                continue

            filename = os.path.basename(source)
            if finder._should_exclude(filename, matcher):
                continue

            if self._is_test_file(filename, matcher):
                continue

            source_name = Path(source).stem
            source_dir = os.path.dirname(source)

            # 同目录匹配
            for test_name in self.build_possible_test_names(source):
                test_path = os.path.join(source_dir, test_name)
                if test_path in all_files_set:
                    matches.append(TestFileMatch(source, test_path, matcher.language))
                    break
            else:
                found = False

                # test 目录匹配
                for td in test_dirs:
                    for f in dir_index.get(td, []):
                        test_filename = os.path.basename(f)
                        if self.is_matching_test(source_name, test_filename):
                            matches.append(TestFileMatch(source, f, matcher.language))
                            found = True
                            break
                    if found:
                        break

                if not found:
                    unmatched.append(TestFileMatch(source, None, matcher.language))

        return matches, unmatched
