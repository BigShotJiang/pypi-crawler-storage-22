import re
from typing import List, Dict, Optional
from dataclasses import dataclass


@dataclass
class DiffAnalysisResult:
    file: str
    change_type: str
    has_test_file: bool
    needs_augmentation: bool
    changed_functions: List[str]


class GitDiffAnalyzer:

    EXCLUDED_FILES = {
        "__init__.py", "__main__.py", "setup.py", "requirements.txt",
        "requirements.py", "config.py", "settings.py", "manage.py", "tests.py",
        "Dockerfile", "docker-compose.yml", "docker-compose.yaml",
        "Pipfile", "pyproject.toml", "tox.ini",
        "package.json", "package-lock.json", "yarn.lock",
        "pom.xml", "build.gradle", "settings.gradle",
        "Makefile", "CMakeLists.txt",
        "__init__.py",
    }

    EXCLUDED_PATTERNS = {
        '.py': [
            r'.*__init__\.py$',
            r'.*config\.py$',
            r'.*settings\.py$',
            r'.*setup\.py$',
            r'.*manage\.py$',
            r'.*tests\.py$',
            r'.*Pipfile$',
            r'.*pyproject\.toml$',
            r'.*tox\.ini$',
            r'.*migrations/.*\.py$',
            r'.*\.migrations/.*\.py$',
            r'.*__main__\.py$',
            r'.*types\.py$',
            r'.*typing\.py$',
            r'.*constants\.py$',
            r'.*_version\.py$',
            r'.*version\.py$',
            r'.*_meta\.py$',
            r'.*hooks\.py$',
            r'.*signals\.py$',
            r'.*events\.py$',
            r'.*apps\.py$',
            r'.*urls\.py$',
            r'.*wsgi\.py$',
            r'.*asgi\.py$',
        ],
        '.java': [
            r'.*Config\.java$',
            r'.*Settings\.java$',
            r'.*Constants\.java$',
            r'.*Application\.java$',
            r'.*pom\.xml$',
            r'^[rR]\.java$',
            r'.*BuildConfig\.java$',
            r'.*Manifest\.java$',
        ],
        '.kt': [
            r'.*Config\.kt$',
            r'.*Settings\.kt$',
            r'.*Application\.kt$',
            r'.*Constants\.kt$',
        ],
        '.go': [
            r'.*config\.go$',
            r'.*settings\.go$',
            r'^main\.go$',
        ],
        '.cpp': [
            r'.*config\.cpp$',
            r'.*config\.h$',
            r'.*main\.cpp$',
            r'.*main\.c$',
            r'.*main\.h$',
        ],
        '.c': [
            r'.*config\.c$',
            r'.*main\.c$',
        ],
        '.h': [
            r'.*config\.h$',
            r'.*constants\.h$',
            r'.*types\.h$',
        ],
        '.js': [
            r'.*config\.js$',
            r'.*settings\.js$',
            r'.*package\.json$',
            r'.*package-lock\.json$',
            r'.*yarn\.lock$',
            r'.*index\.js$',
            r'.*webpack\.config\.js$',
            r'.*babel\.config\.js$',
            r'.*eslint\.config\.js$',
            r'.*prettier\.config\.js$',
            r'.*eslintrc\..+$',
            r'^\.eslintrc$',
            r'.*babelrc\..+$',
            r'^\.babelrc$',
            r'.*prettierignore\..+$',
            r'^\.prettierignore$',
        ],
        '.json': [
            r'.*package\.json$',
            r'.*package-lock\.json$',
            r'.*tsconfig\.json$',
            r'.*webpack\.config\.json$',
            r'.*eslint\.config\.json$',
            r'.*prettier\.config\.json$',
            r'.*babel\.config\.json$',
        ],
        '.ts': [
            r'.*config\.ts$',
            r'.*settings\.ts$',
            r'.*package\.json$',
            r'.*index\.ts$',
            r'.*webpack\.config\.ts$',
            r'.*tsconfig\.json$',
        ],
        '.vue': [
            r'.*config\.vue$',
        ],
        '.md': [
            r'.*README\.md$',
            r'.*CHANGELOG\.md$',
            r'.*LICENSE\.md$',
            r'.*CONTRIBUTING\.md$',
        ],
        '.xml': [
            r'.*pom\.xml$',
            r'.*\.settings\.xml$',
            r'.*web\.xml$',
            r'.*application\.xml$',
        ],
        '.gradle': [
            r'.*build\.gradle$',
            r'.*settings\.gradle$',
        ],
        '.rs': [
            r'.*main\.rs$',
            r'.*lib\.rs$',
            r'.*Cargo\.toml$',
        ],
        '.toml': [
            r'.*Cargo\.toml$',
            r'.*pyproject\.toml$',
            r'.*Pipfile$',
            r'.*settings\.toml$',
        ],
        '.rb': [
            r'.*config\.rb$',
            r'^Gemfile$',
            r'^Gemfile\.lock$',
            r'.*Rakefile$',
        ],
        '.lock': [
            r'.*package-lock\.json$',
            r'.*yarn\.lock$',
            r'^Gemfile\.lock$',
        ],
        '.txt': [
            r'.*\.txt$',
        ],
        '.dic': [
            r'.*\.dic$',
        ],
        '.iml': [
            r'.*\.iml$',
        ],
        '.class': [
            r'.*\.class$',
        ],
        '.jar': [
            r'.*\.jar$',
            r'.*\.war$',
            r'.*\.ear$',
        ],
        '.o': [
            r'.*\.o$',
        ],
        '.obj': [
            r'.*\.obj$',
        ],
        '.so': [
            r'.*\.so$',
            r'.*\.so\..+$',
        ],
        '.dll': [
            r'.*\.dll$',
        ],
        '.exe': [
            r'.*\.exe$',
        ],
        '.dylib': [
            r'.*\.dylib$',
        ],
        '.pyo': [
            r'.*\.pyo$',
        ],
        '.egg': [
            r'.*\.egg$',
            r'.*\.whl$',
        ],
        '.zip': [
            r'.*\.zip$',
            r'.*\.tar\.gz$',
            r'.*\.tar$',
            r'.*\.rar$',
            r'.*\.7z$',
        ],
        '.csv': [
            r'.*\.csv$',
        ],
        '.json': [
            r'.*package\.json$',
            r'.*package-lock\.json$',
            r'.*tsconfig\.json$',
            r'.*webpack\.config\.json$',
            r'.*eslint\.config\.json$',
            r'.*prettier\.config\.json$',
            r'.*babel\.config\.json$',
            r'.*_test\.json$',
            r'.*_tests\.json$',
            r'.*_spec\.json$',
            r'.*schema.*\.json$',
            r'.*data\.json$',
            r'.*output\.json$',
            r'.*eslintrc\..+$',
            r'^\.eslintrc$',
            r'.*prettierrc\..+$',
            r'^\.prettierrc$',
            r'.*babelrc\..+$',
            r'^\.babelrc$',
        ],
        '.log': [
            r'.*\.log$',
            r'.*debug\.log$',
            r'.*error\.log$',
            r'.*access\.log$',
        ],
        '.eslintrc': [
            r'.*eslintrc\..+$',
            r'^\.eslintrc$',
        ],
        '.prettierrc': [
            r'.*prettierrc\..+$',
            r'^\.prettierrc$',
        ],
        '.editorconfig': [
            r'.*\.editorconfig$',
        ],
        '.gitattributes': [
            r'.*\.gitattributes$',
        ],
        '.gitignore': [
            r'.*\.gitignore$',
        ],
        '.dockerignore': [
            r'.*\.dockerignore$',
        ],
        '.babelignore': [
            r'.*babelignore\..+$',
            r'^\.babelignore$',
        ],
        '.gitattributes': [
            r'.*\.gitattributes$',
        ],
        '.gitignore': [
            r'.*\.gitignore$',
        ],
        '.dockerignore': [
            r'.*\.dockerignore$',
        ],
        '.babelrc': [
            r'.*babelrc\..+$',
            r'^\.babelrc$',
        ],
        '.babelignore': [
            r'.*babelignore\..+$',
            r'^\.babelignore$',
        ],
        '.prettierignore': [
            r'.*prettierignore\..+$',
            r'^\.prettierignore$',
        ],
        '.travis': [
            r'.*\.travis\.yml$',
            r'.*\.travis\.yaml$',
        ],
        '.gitlab-ci': [
            r'.*\.gitlab-ci\.yml$',
            r'.*\.gitlab-ci\.yaml$',
        ],
        '.db': [
            r'.*\.db$',
            r'.*\.sqlite$',
            r'.*\.sqlite3$',
        ],
        '.pyc': [
            r'.*\.pyc$',
            r'.*\.pyo$',
        ],
        '.parquet': [
            r'.*\.parquet$',
        ],
        '.pkl': [
            r'.*\.pkl$',
            r'.*\.pickle$',
        ],
        '.tmp': [
            r'.*\.tmp$',
            r'.*\.temp$',
            r'.*\.swp$',
            r'.*\.swo$',
        ],
        '.yaml': [
            r'.*config\.yaml$',
            r'.*settings\.yaml$',
            r'.*\.yaml$',
            r'.*eslintrc\..+$',
            r'^\.eslintrc$',
            r'.*prettierrc\..+$',
            r'^\.prettierrc$',
            r'.*babelrc\..+$',
            r'^\.babelrc$',
            r'.*\.travis\.yml$',
            r'.*\.gitlab-ci\.yml$',
        ],
        '.yml': [
            r'.*config\.yml$',
            r'.*settings\.yml$',
            r'.*\.yml$',
            r'.*eslintrc\..+$',
            r'^\.eslintrc$',
            r'.*prettierrc\..+$',
            r'^\.prettierrc$',
            r'.*babelrc\..+$',
            r'^\.babelrc$',
            r'.*\.travis\.yml$',
            r'.*\.gitlab-ci\.yml$',
        ],
        '.xml': [
            r'.*pom\.xml$',
            r'.*\.settings\.xml$',
            r'.*web\.xml$',
            r'.*application\.xml$',
        ],
        '.ini': [
            r'.*\.ini$',
        ],
        '.cfg': [
            r'.*\.cfg$',
        ],
        '.conf': [
            r'.*\.conf$',
        ],
        '.properties': [
            r'.*\.properties$',
        ],
        '.env': [
            r'.*\.env$',
            r'.*\.env\..+$',
        ],
        '.php': [
            r'.*config\.php$',
            r'.*settings\.php$',
            r'.*bootstrap\.php$',
            r'.*wp-config\.php$',
            r'.*index\.php$',
        ],
        '.cs': [
            r'.*Config\.cs$',
            r'.*Settings\.cs$',
            r'.*Program\.cs$',
            r'.*Startup\.cs$',
            r'.*AssemblyInfo\.cs$',
        ],
        '.swift': [
            r'.*Config\.swift$',
            r'.*Settings\.swift$',
            r'.*AppDelegate\.swift$',
            r'.*SceneDelegate\.swift$',
        ],
        '.scala': [
            r'.*Config\.scala$',
            r'.*Settings\.scala$',
            r'.*Main\.scala$',
        ],
    }

    SKIPPED_BASENAMES = {
        '__init__', 'config', 'settings', 'setup', 'manage',
        'constants', 'application', 'readme', 'changelog',
        'license', '.gitignore', '.dockerignore',
        'types', 'typing', 'version', '_meta',
        'hooks', 'signals', 'events', 'urls',
        'migrations', '_migrations',
        'index', 'app', 'bootstrap', 'startup',
        'gemfile', 'rakefile',
    }

    TEST_FILE_PATTERNS = {
        '.py': [
            r'.*_test\.py$',
            r'.*test_.*\.py$',
            r'.*_tests\.py$',
            r'.*tests\.py$',
        ],
        '.java': [
            r'.*Test\.java$',
            r'.*Tests\.java$',
            r'.*TestCase\.java$',
        ],
        '.kt': [
            r'.*Test\.kt$',
            r'.*Tests\.kt$',
            r'.*TestCase\.kt$',
        ],
        '.go': [
            r'.*_test\.go$',
            r'.*_tests\.go$',
        ],
        '.cpp': [
            r'.*_test\.cpp$',
            r'.*_test\.cc$',
            r'.*_tests\.cpp$',
            r'.*_tests\.cc$',
        ],
        '.c': [
            r'.*_test\.c$',
            r'.*_tests\.c$',
        ],
        '.js': [
            r'.*\.test\.js$',
            r'.*\.spec\.js$',
            r'.*_test\.js$',
        ],
        '.ts': [
            r'.*\.test\.ts$',
            r'.*\.spec\.ts$',
            r'.*_test\.ts$',
        ],
        '.rs': [
            r'.*_test\.rs$',
            r'.*_tests\.rs$',
        ],
        '.rb': [
            r'.*_test\.rb$',
            r'.*_tests\.rb$',
            r'.*_spec\.rb$',
        ],
        '.php': [
            r'.*Test\.php$',
            r'.*Tests\.php$',
        ],
        '.cs': [
            r'.*Test\.cs$',
            r'.*Tests\.cs$',
            r'.*TestCase\.cs$',
        ],
        '.swift': [
            r'.*Test\.swift$',
            r'.*Tests\.swift$',
        ],
        '.scala': [
            r'.*Test\.scala$',
            r'.*Tests\.scala$',
        ],
    }

    SKIPPED_DIRS = {
        'migrations', '_migrations',
    }

    EXCLUDED_DIRS = {
        '.git', '.github', '.idea', '.vscode', '__pycache__',
        'node_modules', '.venv', 'venv', 'env', '.env',
        'build', 'dist', 'target', 'out', 'bin', 'obj',
        '.mypy_cache', '.pytest_cache', '.tox',
        'static', 'templates', 'migrations',
        '.gradle', 'build', 'dist',
    }

    EXCLUDED_DIR_PATTERNS = [
        r'node_modules/',
        r'\.venv/',
        r'venv/',
        r'build/',
        r'dist/',
        r'target/',
        r'\.git/',
        r'\.github/',
        r'\.gitlab/',
        r'\.idea/',
        r'\.vscode/',
        r'\.cache/',
        r'\.pytest_cache/',
        r'\.mypy_cache/',
        r'\.tox/',
        r'__pycache__/',
        r'static/',
        r'templates/',
        r'migrations/',
        r'resources/',
        r'assets/',
        r'config/',
        r'\.gradle/',
        r'.gradle/',
        r'\.sass-cache/',
    ]

    PATCH_PATTERNS = {
        'signature_change': re.compile(
            r'^[-+ ]\s*(?:'
            r'def\s+\w+\s*\(|'  # Python: def func(
            r'func\s+\w+\s*\(|'  # Go: func func()
            r'fn\s+\w+\s*\(|'  # Rust: fn func()
            r'(?:(?:public|private|protected|override|abstract|static|final|synchronized)\s+)*'
            r'(?:<[^>]*>\s*)?'
            r'(?:void|int|bool|char|double|float|long|short|byte|boolean|[A-Z]\w*)\s+\w+\s*\([^)]*\)\s*(?:\{?$)'
            r')',
            re.MULTILINE
        ),
        'new_function': re.compile(
            r'^\+\s*(?:'
            r'def\s+\w+\s*\(|'
            r'func\s+\w+\s*\(|'
            r'fn\s+\w+\s*\(|'
            r'(?:(?:public|private|protected|override|abstract|static|final|synchronized)\s+)*'
            r'(?:<[^>]*>\s*)?'
            r'(?:void|int|bool|char|double|float|long|short|byte|boolean|[A-Z]\w*)\s+\w+\s*\([^)]*\)\s*(?:\{?$)'
            r')',
            re.MULTILINE
        ),
        'logic_change': re.compile(
            r'^[-+]\s+(return|raise|if |else:|elif |for |while |try:|except |catch |'
            r'throw|throws |goto |break |continue |switch |case |default:)',
            re.MULTILINE
        ),
        'changed_function': re.compile(
            r'^[-+ ]\s*(?:'
            r'def\s+(\w+)\s*\(|'
            r'func\s+(\w+)\s*\(|'
            r'fn\s+(\w+)\s*\(|'
            r'(?:(?:public|private|protected|override|abstract|static|final|synchronized)\s+)*'
            r'(?:<[^>]*>\s*)?'
            r'(?:void|int|bool|char|double|float|long|short|byte|boolean|[A-Z]\w*)\s+(\w+)\s*\([^)]*\)'
            r')',
            re.MULTILINE
        ),
    }

    @staticmethod
    def filter_deleted(diffs: List[Dict]) -> List[Dict]:
        return [d for d in diffs if d.get('change_type') != 'deleted']

    @classmethod
    def should_skip_file(cls, file_path: str) -> bool:
        normalized_path = file_path.replace('\\', '/')
        filename = normalized_path.split('/')[-1]
        dirs = normalized_path.split('/')

        if filename in cls.EXCLUDED_FILES:
            return True

        for dir_pattern in cls.EXCLUDED_DIR_PATTERNS:
            if re.search(dir_pattern, normalized_path):
                return True

        if any(d in cls.EXCLUDED_DIRS for d in dirs):
            return True

        if any(d in cls.SKIPPED_DIRS for d in dirs):
            return True

        ext = '.' + filename.split('.')[-1].lower() if '.' in filename else ''

        if ext in cls.EXCLUDED_PATTERNS:
            for pattern in cls.EXCLUDED_PATTERNS[ext]:
                if re.match(pattern, filename, re.IGNORECASE):
                    return True

        if filename in cls.SKIPPED_BASENAMES:
            return True

        name_without_ext = filename.rsplit('.', 1)[0].lower()
        if name_without_ext in cls.SKIPPED_BASENAMES:
            return True

        if ext in cls.TEST_FILE_PATTERNS:
            for pattern in cls.TEST_FILE_PATTERNS[ext]:
                if re.match(pattern, filename, re.IGNORECASE):
                    return True

        return False

    @classmethod
    def is_test_file(cls, file_path: str) -> bool:
        """判断文件是否是测试文件"""
        normalized_path = file_path.replace('\\', '/')
        filename = normalized_path.split('/')[-1]
        ext = '.' + filename.split('.')[-1].lower() if '.' in filename else ''

        if ext in cls.TEST_FILE_PATTERNS:
            for pattern in cls.TEST_FILE_PATTERNS[ext]:
                if re.match(pattern, filename, re.IGNORECASE):
                    return True
        return False

    @classmethod
    def analyze_patch_impact(cls, patch: str) -> Dict:
        result = {
            "has_signature_change": False,
            "has_new_function": False,
            "has_logic_change": False,
            "changed_functions": [],
        }

        result["has_signature_change"] = bool(
            cls.PATCH_PATTERNS['signature_change'].search(patch)
        )
        result["has_new_function"] = bool(
            cls.PATCH_PATTERNS['new_function'].search(patch)
        )
        result["has_logic_change"] = bool(
            cls.PATCH_PATTERNS['logic_change'].search(patch)
        )

        matches = cls.PATCH_PATTERNS['changed_function'].findall(patch)
        changed_funcs = set()
        for m in matches:
            for group in m:
                if group:
                    changed_funcs.add(group)
        result["changed_functions"] = list(changed_funcs)

        return result

    @classmethod
    def should_augment_test(cls, impact: Dict) -> bool:
        return (
            impact["has_signature_change"] or
            impact["has_new_function"] or
            impact["has_logic_change"]
        )

    @classmethod
    def analyze_diff(cls, diff: Dict, has_test_file: bool) -> Optional[DiffAnalysisResult]:
        file_path = diff['file']
        change_type = diff.get('change_type', 'modified')
        patch = diff.get('patch', '')

        if cls.is_test_file(file_path):
            return None

        result = DiffAnalysisResult(
            file=file_path,
            change_type=change_type,
            has_test_file=has_test_file,
            needs_augmentation=False,
            changed_functions=[],
        )

        if change_type == 'added':
            if cls.should_skip_file(file_path):
                return None
        elif change_type == 'modified':
            if not has_test_file:
                pass
            else:
                impact = cls.analyze_patch_impact(patch)
                result.changed_functions = impact["changed_functions"]
                result.needs_augmentation = cls.should_augment_test(impact)

                if not result.needs_augmentation:
                    return None

        return result
