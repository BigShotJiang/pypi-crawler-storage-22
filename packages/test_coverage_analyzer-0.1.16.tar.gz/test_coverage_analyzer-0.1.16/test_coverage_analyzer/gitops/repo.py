# -*- coding: utf-8 -*-

# ----------------------------------------------------------------------
# Copyright © 2014-2026 China Mobile (SuZhou) Software Technology Co.,Ltd.
#
# The programs can not be copied and/or distributed without the express
# permission of China Mobile (SuZhou) Software Technology Co.,Ltd.
#
# Project name: test_coverage_analyzer
# Desc: ［用于详细说明此程序文件完成的主要功能，与其他模块或函数的接口，输出值
# 取值范围、含义及参数间的控制、顺序、独立或依赖等关系］
#
# Create by wangaodi at 2026/02/04
#
# ----------------------------------------------------------------------

import os
import git
import contextlib

from . import utils as utils

from typing import Optional, Dict, List
from pathlib import Path, PurePosixPath
from dataclasses import dataclass
from urllib.parse import urlparse, quote

try:
    import git

    ANY_GIT_ERROR = [
        git.exc.ODBError,
        git.exc.GitError,
        git.exc.InvalidGitRepositoryError,
        git.exc.GitCommandNotFound,
    ]
except ImportError:
    git = None
    ANY_GIT_ERROR = []

from ..common.file_utils import detect_file_encoding
from ..models.simple_io import SimpleIO


ANY_GIT_ERROR += [
    OSError,
    IndexError,
    BufferError,
    TypeError,
    ValueError,
    AttributeError,
    AssertionError,
    TimeoutError,
]
ANY_GIT_ERROR = tuple(ANY_GIT_ERROR)


@contextlib.contextmanager
def set_git_env(var_name, value, original_value):
    """Temporarily set a Git environment variable."""
    os.environ[var_name] = value
    try:
        yield
    finally:
        if original_value is not None:
            os.environ[var_name] = original_value
        elif var_name in os.environ:
            del os.environ[var_name]


@dataclass
class GitLabAuth:
    """GitLab认证信息"""
    username: Optional[str] = None
    token: Optional[str] = None  # API令牌
    instance_url: Optional[str] = None  # GitLab实例URL

    def validate_credentials(self) -> bool:
        """
        验证认证信息是否完整有效

        Returns:
            bool: 认证信息是否有效
  
        Raises:
            ValueError: 当认证信息不完整时抛出
        """
        if self.username is None or self.username.strip() == "":
            raise ValueError("GitLab用户名不能为空")

        if self.token is None or self.token.strip() == "":
            raise ValueError("GitLab访问令牌不能为空")

        if self.instance_url is None or self.instance_url.strip() == "":
            raise ValueError("GitLab实例URL不能为空")

        return True

    def inject_basic_auth(
        self,
        repo_url: str,
    ) -> str:
        """
        https://gitlab.company.com/a/b.git
        ->
        https://username:TOKEN@gitlab.company.com/a/b.git
        """
        # 验证认证信息完整性
        self.validate_credentials()

        try:
            parsed = urlparse(repo_url)
        except Exception as e:
            raise ValueError(f"无效的Git仓库URL: {repo_url}") from e

        # 防止特殊字符破坏 URL
        user = quote(self.username, safe="") if self.username is not None else ""
        pwd = quote(self.token, safe="") if self.token is not None else ""

        return (
            f"{parsed.scheme}://{user}:{pwd}@"
            f"{parsed.netloc}{parsed.path}"
        )


class GitRepo:
    repo = None
    ignore_file_cache = {}

    def __init__(
        self,
        io=None,
        repo_dir: str = None,
        repo_url: str = None,
        source_branch: str = None,
        git_commit_verify=True,
    ):
        self.io = io or SimpleIO()

        self.normalized_path = {}
        self.tree_files = {}

        self.git_commit_verify = git_commit_verify

        # GitLab认证管理器
        self.gitlab_auth = GitLabAuth(
            username=os.environ.get("GITLAB_USERNAME"),
            token=os.environ.get("GITLAB_TOKEN"),
            instance_url=os.environ.get("GITLAB_INSTANCE_URL", "http://gitlab.cmss.com"),
        )

        if repo_url and repo_url and source_branch:
            try:
                self.repo = self.prepare_repo(repo_dir, repo_url, source_branch)
            except ANY_GIT_ERROR as err:
                raise err
        else:
            check_fnames = ["."]
            repo_paths = []
            for fname in check_fnames:
                fname = Path(fname)
                fname = fname.resolve()

                if not fname.exists() and fname.parent.exists():
                    fname = fname.parent

                try:
                    repo_path = git.Repo(fname, search_parent_directories=True).working_dir
                    repo_path = utils.safe_abs_path(repo_path)
                    repo_paths.append(repo_path)
                except ANY_GIT_ERROR:
                    pass

            num_repos = len(set(repo_paths))

            if num_repos == 0:
                raise FileNotFoundError("未找到git仓库")
            if num_repos > 1:
                self.io.tool_error("文件在不同的git仓库中。")
                raise FileNotFoundError

            # https://github.com/gitpython-developers/GitPython/issues/427
            self.repo = git.Repo(repo_paths.pop(), odbt=git.GitDB)
        self.root = utils.safe_abs_path(self.repo.working_tree_dir)

    def get_project_name(self, repo_url: str) -> str:
        path = urlparse(repo_url).path.rstrip("/")  # 先移除末尾的斜杠
        repo = os.path.basename(path)
        return repo.removesuffix(".git")

    def prepare_repo(
        self,
        repo_dir: str,
        repo_url: str,
        source_branch: str,
    ) -> git.Repo:
        """
        准备Git仓库
        
        Args:
            repo_dir: 本地仓库路径
            repo_url: 仓库URL
            source_branch: 源分支名
        
        Returns:
            git.Repo: Git仓库对象
        """
        auth_url = self.gitlab_auth.inject_basic_auth(repo_url)
        repo_path = os.path.join(repo_dir, self.get_project_name(repo_url))

        if not os.path.exists(repo_path):
            try:
                repo = git.Repo.clone_from(
                    auth_url,
                    repo_path,
                    branch=source_branch,
                )
            except ANY_GIT_ERROR as err:
                self.io.tool_error(f"克隆仓库失败: {err}")
                raise git.exc.GitError(f"克隆仓库失败: {err}") from err
        else:
            try:
                repo = git.Repo(repo_path)
            except ANY_GIT_ERROR as err:
                self.io.tool_error(f"打开仓库失败: {err}")
                raise git.exc.GitError(f"打开仓库失败: {err}") from err

            # 更新仓库
            try:
                repo.remotes.origin.fetch(prune=True)
            except ANY_GIT_ERROR as err:
                self.io.tool_error(f"获取远程更新失败: {err}")
                raise git.exc.GitError(f"获取远程更新失败: {err}") from err

        # 切换到指定分支
        try:
            repo.git.checkout(source_branch)
            repo.git.pull("origin", source_branch)
        except ANY_GIT_ERROR as err:
            self.io.tool_error(f"切换分支失败: {err}")
            raise git.exc.GitError(f"切换分支失败: {err}") from err

        return repo

    def commit(self, fnames=None, context=None, message=None):
        """
        提交指定的文件或所有未提交的更改。

        Args:
            fnames (list, optional): 要提交的文件名列表。默认为None（提交所有未提交的文件）。
            context (str, optional): 生成提交消息的上下文。默认为None。
            message (str, optional): 显式的提交消息。默认为None（生成消息）。

        Returns:
            tuple(str, str) or None: 如果成功，返回提交哈希和提交消息，否则返回None。
        """
        if not fnames and not self.repo.is_dirty():
            return

        diffs = self.get_diffs(fnames)
        if not diffs:
            return

        if message:
            commit_message = message
        else:
            commit_message = self.get_commit_message(diffs, context)

        if not commit_message:
            commit_message = "(未提供提交消息)"

        cmd = ["-m", commit_message]
        if not self.git_commit_verify:
            cmd.append("--no-verify")
        if fnames:
            fnames = [str(self.abs_root_path(fn)) for fn in fnames]
            for fname in fnames:
                try:
                    self.repo.git.add(fname)
                except ANY_GIT_ERROR as err:
                    self.io.tool_error(f"无法添加 {fname}: {err}")
            cmd += ["--"] + fnames
        else:
            cmd += ["-a"]

        try:
            # Perform the commit
            self.repo.git.commit(cmd)
            commit_hash = self.get_head_commit_sha(short=True)
            self.io.tool_output(f"提交 {commit_hash} {commit_message}")
            return commit_hash, commit_message

        except ANY_GIT_ERROR as err:
            self.io.tool_error(f"无法提交: {err}")

    def get_rel_repo_dir(self):
        try:
            return os.path.relpath(self.repo.git_dir, os.getcwd())
        except (ValueError, OSError):
            return self.repo.git_dir

    def get_commit_message(self, diffs, context=None):
        diffs = "# 差异:\n" + diffs

        content = ""
        if context:
            content += context + "\n"
        content += diffs

        # 简单的提交消息生成逻辑
        lines = diffs.split('\n')
        added_files = set()
        modified_files = set()
        
        for line in lines:
            if line.startswith('+++ b/'):
                filename = line[6:]
                if filename != '/dev/null':
                    added_files.add(filename)
            elif line.startswith('--- a/'):
                filename = line[6:]
                if filename != '/dev/null':
                    modified_files.add(filename)

        if added_files and not modified_files:
            commit_message = f"添加文件: {', '.join(list(added_files)[:3])}"
        elif modified_files and not added_files:
            commit_message = f"修改文件: {', '.join(list(modified_files)[:3])}"
        else:
            all_files = list(added_files | modified_files)
            commit_message = f"更新文件: {', '.join(all_files[:3])}"

        return commit_message

    def get_diffs(self, fnames=None):
        """获取指定文件的 Git 差异信息。
        
        根据当前分支是否有提交历史，采用不同的差异获取策略：
        - 如果有提交历史：获取 HEAD 与工作目录的差异
        - 如果无提交历史：分别获取暂存区和工作目录的差异
        
        Args:
            fnames (list, optional): 要获取差异的文件名列表。如果为 None，则返回空字符串。
                                    默认为 None。
        
        Returns:
            str: 包含所有指定文件差异信息的字符串。对于仓库外的新增文件，
                会标注 "Added {filename}"。如果发生错误则返回已获取的部分差异。
        
        Note:
            总是会获取暂存区和工作目录的差异信息，即使没有提供文件名列表。
        """
        current_branch_has_commits = False
        try:
            active_branch = self.repo.active_branch
            try:
                commits = self.repo.iter_commits(active_branch)
                current_branch_has_commits = any(commits)
            except ANY_GIT_ERROR:
                pass
        except (TypeError,) + ANY_GIT_ERROR:
            pass

        if not fnames:
            fnames = []

        diffs = ""
        for fname in fnames:
            if not self.path_in_repo(fname):
                diffs += f"Added {fname}\n"

        try:
            if current_branch_has_commits:
                args = ["HEAD", "--"] + list(fnames)
                diffs += self.repo.git.diff(*args, stdout_as_string=False).decode(
                    self.io.encoding, "replace"
                )
                return diffs

            wd_args = ["--"] + list(fnames)
            index_args = ["--cached"] + wd_args

            diffs += self.repo.git.diff(*index_args, stdout_as_string=False).decode(
                self.io.encoding, "replace"
            )
            diffs += self.repo.git.diff(*wd_args, stdout_as_string=False).decode(
                self.io.encoding, "replace"
            )

            return diffs
        except ANY_GIT_ERROR as err:
            self.io.tool_error(f"Unable to diff: {err}")

    def diff_commits(self, pretty, from_commit, to_commit):
        """比较两个提交之间的差异
        
        用于获取指定两个提交之间的代码差异信息，支持彩色输出控制。
        
        Args:
            pretty (bool): 是否启用彩色输出。True 时启用彩色显示，False 时禁用彩色
            from_commit (str): 起始提交的哈希值或引用
            to_commit (str): 目标提交的哈希值或引用
        
        Returns:
            str: 两个提交之间的差异内容，编码格式与 self.io.encoding 一致
            
        Note:
            使用 git diff 命令获取差异，通过 --color 参数控制输出格式
            返回的字符串使用 'replace' 错误处理策略进行解码
        """
        args = []
        if pretty:
            args += ["--color"]
        else:
            args += ["--color=never"]

        args += [from_commit, to_commit]
        diffs = self.repo.git.diff(*args, stdout_as_string=False).decode(
            self.io.encoding, "replace"
        )

        return diffs

    def get_tracked_files(self):
        """获取 Git 仓库中所有被跟踪的文件列表。
        
        包括已提交的文件和暂存区中的文件。该方法会遍历当前 HEAD 提交的树结构，
        收集所有 blob 对象（文件）的路径，并将其与暂存区中的文件合并。
        
        Returns:
            set: 包含所有被跟踪文件路径的集合，路径已标准化处理。
                如果仓库不存在或发生错误，返回空集合。
                
        Note:
            - 使用缓存机制避免重复遍历相同提交的树结构
            - 处理各种 Git 相关异常，确保方法鲁棒性
            - 路径会通过 normalize_path 方法进行标准化
        """
        if not self.repo:
            return []

        try:
            commit = self.repo.head.commit
        except ValueError:
            commit = None
        except ANY_GIT_ERROR as err:
            self.io.tool_error(f"Unable to list files in git repo: {err}")
            self.io.tool_output("Is your git repo corrupted?")
            return []

        files = set()
        if commit:
            if commit in self.tree_files:
                files = self.tree_files[commit]
            else:
                try:
                    iterator = commit.tree.traverse()
                    blob = None  # Initialize blob
                    while True:
                        try:
                            blob = next(iterator)
                            if blob.type == "blob":  # blob is a file
                                files.add(blob.path)
                        except IndexError:
                            # Handle potential index error during tree traversal
                            # without relying on potentially unassigned 'blob'
                            self.io.tool_warning(
                                "GitRepo: Index error encountered while reading git tree object."
                                " Skipping."
                            )
                            continue
                        except StopIteration:
                            break
                except ANY_GIT_ERROR as err:
                    self.io.tool_error(f"Unable to list files in git repo: {err}")
                    self.io.tool_output("Is your git repo corrupted?")
                    return []
                files = set(self.normalize_path(path) for path in files)
                self.tree_files[commit] = set(files)

        # Add staged files
        index = self.repo.index
        try:
            staged_files = [path for path, _ in index.entries.keys()]
            files.update(self.normalize_path(path) for path in staged_files)
        except ANY_GIT_ERROR as err:
            self.io.tool_error(f"Unable to read staged files: {err}")

        return files

    def normalize_path(self, path):
        orig_path = path
        res = self.normalized_path.get(orig_path)
        if res:
            return res

        path = str(Path(PurePosixPath((Path(self.root) / path).relative_to(self.root))))
        self.normalized_path[orig_path] = path
        return path

    def git_ignored_file(self, path):
        if not self.repo:
            return
        try:
            if self.repo.ignored(path):
                return True
        except ANY_GIT_ERROR:
            return False

    def path_in_repo(self, path):
        if not self.repo:
            return
        if not path:
            return

        tracked_files = set(self.get_tracked_files())
        return self.normalize_path(path) in tracked_files

    def abs_root_path(self, path):
        res = Path(self.root) / path
        return utils.safe_abs_path(res)

    def get_dirty_files(self):
        """
        Returns a list of all files which are dirty (not committed), either staged or in the working
        directory.
        """
        dirty_files = set()

        # Get staged files
        staged_files = self.repo.git.diff("--name-only", "--cached").splitlines()
        dirty_files.update(staged_files)

        # Get unstaged files
        unstaged_files = self.repo.git.diff("--name-only").splitlines()
        dirty_files.update(unstaged_files)

        return list(dirty_files)

    def is_dirty(self, path=None):
        if path and not self.path_in_repo(path):
            return True

        return self.repo.is_dirty(path=path)

    def get_head_commit(self):
        try:
            return self.repo.head.commit
        except (ValueError,) + ANY_GIT_ERROR:
            return None

    def get_head_commit_sha(self, short=False):
        commit = self.get_head_commit()
        if not commit:
            return
        if short:
            return commit.hexsha[:7]
        return commit.hexsha

    def get_head_commit_message(self, default=None):
        commit = self.get_head_commit()
        if not commit:
            return default
        return commit.message

    def get_merge_request_diffs(
        self,
        source_branch: str,
        target_branch: str,
    ) -> List[Dict[str, str]]:
        """
        获取两个分支之间的合并请求差异信息。

        此方法用于比较源分支和目标分支之间的差异，等价于执行以下Git命令：
        git diff origin/target...origin/source

        Args:
            source_branch (str): 源分支名称，通常是功能分支或待合并的分支
            target_branch (str): 目标分支名称，通常是主分支或合并目标分支

        Returns:
            List[Dict[str, str]]: 包含差异信息的字典列表，每个字典包含：
                - file (str): 文件路径
                - change_type (str): 变更类型，值为 "added"、"deleted" 或 "modified"
                - patch (str): 具体的差异补丁内容

        Example:
            >>> diffs = get_merge_request_diffs("feature-branch", "main")
            >>> for diff in diffs:
            ...     print(f"文件: {diff['file']}, 变更类型: {diff['change_type']}")

        Note:
            - 方法会先从远程仓库获取最新的分支信息
            - 使用三点差异比较，比较的是目标分支到源分支的变更
            - 返回的差异补丁可以直接用于代码审查或合并分析
        """

        # 确保远端分支是最新的
        self.repo.remotes.origin.fetch(prune=True)

        diff_index = self.repo.commit(
            f"origin/{target_branch}"
        ).diff(
            f"origin/{source_branch}",
            create_patch=True,
        )

        diffs = []
        for d in diff_index:
            # 新文件 / 删除文件 / 修改文件
            if d.deleted_file:
                change = "deleted"
            elif d.new_file:
                change = "added"
            else:
                change = "modified"

            path = d.b_path or d.a_path

            if not path:
                continue

            full_path = os.path.join(self.repo.working_tree_dir, path)
            enc = detect_file_encoding(full_path)
            patch = (
                d.diff.decode(enc or "utf-8", errors="ignore")
                if d.diff else ""
            )

            diffs.append({
                "file": full_path,
                "change_type": change,
                "patch": patch,
            })

        return diffs
