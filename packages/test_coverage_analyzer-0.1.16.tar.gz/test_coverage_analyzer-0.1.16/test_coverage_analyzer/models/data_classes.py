from typing import List
from dataclasses import dataclass, field

from ..common import normalize_path


@dataclass
class TestFileMatch:
    """测试文件匹配结果"""
    source_file: str
    test_file: str
    language: str


@dataclass
class CoverageResult:
    """覆盖率结果"""
    source_file: str
    test_file: str = None
    language: str = None
    total_testable_elements: int = 0
    tested_elements: int = 0
    coverage_percentage: float = 0.0
    uncovered_elements: List[str] = field(default_factory=list)
    code_similarity: float = 0.0
    cyclomatic_complexity: int = 0
    dependency_complexity: int = 0
    param_complexity: int = 0
    roi_score: float = 0.0

    def __post_init__(self):
        """实例化后自动统一路径分隔符"""
        if self.source_file:
            self.source_file = normalize_path(self.source_file, for_storage=False)

        if self.test_file:
            self.test_file = normalize_path(self.test_file, for_storage=False)

    def roi_cyclomatic_gain(self):
        """圈复杂度做「倒 U 型收益」"""
        # 太简单，收益低
        if self.cyclomatic_complexity < 2:
            return 0.1
        # 最佳圈复杂度区间中心
        if 2 <= self.cyclomatic_complexity <= 10:
            return 1.0
        if 10 < self.cyclomatic_complexity <= 20:
            return 0.6
        # 圈复杂度极高，需要大量case才能覆盖，测试生成失败率高
        return 0.3

    def roi_dependency_gain(self):
        """依赖复杂度做「倒 U 型收益」"""
        # 过低依赖，生成成功率高，覆盖扩散小
        if self.dependency_complexity <= 1:
            return 0.3
        # 最佳依赖复杂度区间中心
        if 2 <= self.dependency_complexity <= 5:
            return 1.0
        if 6 <= self.dependency_complexity <= 10:
            return 0.6
        # 过高依赖，Mock 成本爆炸，测试生成失败率高
        return 0.2

    def roi_parameter_gain(self):
        """参数复杂度做「倒 U 型收益」"""
        if self.param_complexity <= 1:
            return 0.4
        # 最佳参数复杂度区间中心
        if 2 <= self.param_complexity <= 4:
            return 1.0
        if 5 <= self.param_complexity <= 7:
            return 0.5
        # 参数复杂度极高，需要大量case才能覆盖，测试生成失败率高
        return 0.2

    def coverage_discount(self):
        """根据覆盖率计算折扣因子"""
        if self.coverage_percentage >= 80:
            return 0.4
        if self.coverage_percentage >= 60:
            return 0.7
        return 1.0

    def compute_roi_score(
        self,
        w_c: float = 0.5,
        w_d: float = 0.35,
        w_p: float = 0.15,
        use_coverage_discount: bool = True
    ):
        """计算覆盖收益 ROI 评分"""
        if (
            self.cyclomatic_complexity <= 0
            and self.dependency_complexity <= 0
            and self.param_complexity <= 0
        ):
            # 复杂度没算出来的文件，不参与 ROI 排序
            self.roi_score = 0.0
            return 0.0

        c_gain = self.roi_cyclomatic_gain()
        dep_gain = self.roi_dependency_gain()
        param_gain = self.roi_parameter_gain()
        self.roi_score = (
            w_c * c_gain
            + w_d * dep_gain
            + w_p * param_gain
        )
        
        if use_coverage_discount:
            self.roi_score *= self.coverage_discount()

        return self.roi_score


@dataclass
class LanguagePatterns:
    """语言模式配置"""
    source_pattern: str
    test_patterns: List[str]
    exclude_patterns: List[str]
