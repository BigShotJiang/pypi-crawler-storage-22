# -*- coding: utf-8 -*-

# ----------------------------------------------------------------------
# Copyright © 2014-2026 China Mobile (SuZhou) Software Technology Co.,Ltd.
#
# The programs can not be copied and/or distributed without the express
# permission of China Mobile (SuZhou) Software Technology Co.,Ltd.
#
# Project name: test_coverage_analyzer
# Desc: ［用于详细说明此程序文件完成的主要功能，与其他模块或函数的接口，输出值
# 取值范围、含义及参数间的控制、顺序、独立或依赖等关系］
#
# Create by wangaodi at 2026/02/04
#
# ----------------------------------------------------------------------
import sys


class SimpleIO:
    """简化的输入输出处理类"""

    def __init__(self):
        self.encoding = "utf-8"

    def tool_output(self, message, bold=False):
        """输出工具消息"""
        if bold:
            print(f"\033[1m{message}\033[0m")
        else:
            print(message)

    def tool_error(self, message):
        """输出错误消息"""
        print(f"\033[31m错误: {message}\033[0m", file=sys.stderr)
    
    def tool_warning(self, message):
        """输出警告消息"""
        print(f"\033[33m警告: {message}\033[0m", file=sys.stderr)
    
    def confirm_ask(self, question, default="y", subject=None):
        """确认询问，简化版本总是返回True"""
        return True
