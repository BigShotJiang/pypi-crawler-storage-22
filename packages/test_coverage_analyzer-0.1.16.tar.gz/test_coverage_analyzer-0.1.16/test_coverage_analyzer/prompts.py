project_res_template = """
=== 文件级覆盖明细 ===
{file_result}"""

project_files_template = """=== 待测文件列表 ===
{file_result}"""

file_res_template = """源文件：{source_file}
测试文件：{test_file}
圈复杂度：{cyclomatic_complexity}
依赖复杂度：{dependency_complexity}
"""

file_res_template_with_uncovered = """源文件：{source_file}
测试文件：{test_file}
测试覆盖率：{coverage_percentage}%
未覆盖元素：{uncovered_elements}
圈复杂度：{cyclomatic_complexity}
依赖复杂度：{dependency_complexity}
"""


unittest_augmentation_template = """请严格按照单元测试规范，为 {source_file} 补充单元测试用例，测试文件为 {test_file}。
重点覆盖当前尚未覆盖的测试元素：{uncovered_elements}。
在不破坏现有测试用例的前提下完成补充，并执行测试验证，确保全部测试通过（通过率100%）。
"""

unittest_generation_template = """请严格按照单元测试规范，为 {source_file} 生成单元测试用例，并执行测试验证，确保全部测试通过（通过率100%）。"""