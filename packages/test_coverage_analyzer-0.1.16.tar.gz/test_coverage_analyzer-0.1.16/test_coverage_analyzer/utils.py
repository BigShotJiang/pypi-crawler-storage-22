import os
import json
import uuid
from typing import List, Tuple
from dataclasses import asdict
from pathlib import Path

from .models import (
    TestFileMatch,
    CoverageResult
)
from .prompts import unittest_augmentation_template, unittest_generation_template


def process_results_to_prompts(json_data):
    """
    将JSON数据转换为prompt格式的处理函数
    返回结构化的prompt数据（字典格式）
    """
    prompt_data = []

    if 'coverage_results' in json_data and len(json_data['coverage_results']) > 0:
        for item in json_data['coverage_results']:
            prompt_data.append({
                'id': item["source_file"],
                'prompt': unittest_augmentation_template.format(
                    source_file=item["source_file"],
                    test_file=item["test_file"],
                    uncovered_elements=item["uncovered_elements"],
                )
            })

    if 'unmatched' in json_data and len(json_data['unmatched'])>0:
        for item in json_data['unmatched']:
            prompt_data.append({
                'id': item["source_file"],
                'prompt': unittest_generation_template.format(source_file=item["source_file"])
            })

    return prompt_data


def process_results_to_json(
        matches: List[TestFileMatch],
        unmatched: List[Tuple[str, str]],
        coverage_results: List[CoverageResult],
        unmatched_results: List[CoverageResult]
    ):
    """将匹配结果和覆盖率分析保存到JSON文件"""
    # 转换数据为字典格式
    matches_dict = [asdict(match) for match in matches]
    coverage_dict = [asdict(cr) for cr in coverage_results]
    unmatched_dict = [asdict(ur) for ur in unmatched_results]

    # 构建最终JSON结构
    result = {
        "matches": matches_dict,
        "unmatched": unmatched_dict,
        "coverage_results": coverage_dict,
        "summary": {
            "total_matches": len(matches),
            "total_unmatched": len(unmatched),
            "total_coverage_analyzed": len(coverage_results),
            "total_unmatched_analyzed": len(unmatched_results),
            # 统计覆盖率摘要
            "coverage_summary": {
                "total_testable_elements": sum(cr["total_testable_elements"] for cr in coverage_dict),
                "total_tested_elements": sum(cr["tested_elements"] for cr in coverage_dict),
                "avg_coverage_percentage": (sum(cr["coverage_percentage"] for cr in coverage_dict) / len(coverage_dict)) if coverage_dict else 0,
                "avg_cyclomatic_complexity_matched": (sum(cr["cyclomatic_complexity"] for cr in coverage_dict) / len(coverage_dict)) if coverage_dict else 0,
                "avg_dependency_complexity_matched": (sum(cr["dependency_complexity"] for cr in coverage_dict) / len(coverage_dict)) if coverage_dict else 0
            },
            # 未匹配文件的复杂度统计
            "unmatched_summary": {
                "avg_cyclomatic_complexity": (sum(ur["cyclomatic_complexity"] for ur in unmatched_dict) / len(unmatched_dict)) if unmatched_dict else 0,
                "avg_dependency_complexity": (sum(ur["dependency_complexity"] for ur in unmatched_dict) / len(unmatched_dict)) if unmatched_dict else 0
            },
            # 按语言统计
            "language_stats": {}
        }
    }

    # 按语言统计详细信息
    lang_stats = {}

    # 处理匹配文件
    for cr in coverage_dict:
        lang = cr["language"]
        if lang not in lang_stats:
            lang_stats[lang] = {
                "matched": {
                    "count": 0,
                    "total_testable": 0,
                    "total_tested": 0,
                    "coverage_sum": 0,
                    "cyclomatic_sum": 0,
                    "dependency_sum": 0
                },
                "unmatched": {
                    "count": 0,
                    "cyclomatic_sum": 0,
                    "dependency_sum": 0
                }
            }
        lang_stats[lang]["matched"]["count"] += 1
        lang_stats[lang]["matched"]["total_testable"] += cr["total_testable_elements"]
        lang_stats[lang]["matched"]["total_tested"] += cr["tested_elements"]
        lang_stats[lang]["matched"]["coverage_sum"] += cr["coverage_percentage"]
        lang_stats[lang]["matched"]["cyclomatic_sum"] += cr["cyclomatic_complexity"]
        lang_stats[lang]["matched"]["dependency_sum"] += cr["dependency_complexity"]

    # 处理未匹配文件
    for ur in unmatched_dict:
        lang = ur["language"]
        if lang not in lang_stats:
            lang_stats[lang] = {
                "matched": {
                    "count": 0,
                    "total_testable": 0,
                    "total_tested": 0,
                    "coverage_sum": 0,
                    "cyclomatic_sum": 0,
                    "dependency_sum": 0
                },
                "unmatched": {
                    "count": 0,
                    "cyclomatic_sum": 0,
                    "dependency_sum": 0
                }
            }
        lang_stats[lang]["unmatched"]["count"] += 1
        lang_stats[lang]["unmatched"]["cyclomatic_sum"] += ur["cyclomatic_complexity"]
        lang_stats[lang]["unmatched"]["dependency_sum"] += ur["dependency_complexity"]

    # 计算各语言的平均值
    for lang, stats in lang_stats.items():
        result["summary"]["language_stats"][lang] = {
            "total_files": stats["matched"]["count"] + stats["unmatched"]["count"],
            "matched_files": stats["matched"]["count"],
            "unmatched_files": stats["unmatched"]["count"],
            "matched_stats": {
                "avg_coverage": stats["matched"]["coverage_sum"] / stats["matched"]["count"] if stats["matched"]["count"] > 0 else 0,
                "avg_cyclomatic": stats["matched"]["cyclomatic_sum"] / stats["matched"]["count"] if stats["matched"]["count"] > 0 else 0,
                "avg_dependency": stats["matched"]["dependency_sum"] / stats["matched"]["count"] if stats["matched"]["count"] > 0 else 0,
                "total_testable_elements": stats["matched"]["total_testable"],
                "coverage_ratio": (stats["matched"]["total_tested"] / stats["matched"]["total_testable"] * 100) if stats["matched"]["total_testable"] > 0 else 0
            },
            "unmatched_stats": {
                "avg_cyclomatic": stats["unmatched"]["cyclomatic_sum"] / stats["unmatched"]["count"] if stats["unmatched"]["count"] > 0 else 0,
                "avg_dependency": stats["unmatched"]["dependency_sum"] / stats["unmatched"]["count"] if stats["unmatched"]["count"] > 0 else 0
            }
        }

    return result


def merge_sort_coverage_data(json_data, limit=None):
    # 提取 coverage_results 和 unmatched
    coverage_results = json_data.get("coverage_results", [])
    unmatched = json_data.get("unmatched", [])

    # 合并 coverage_results 和 normalized_unmatched
    combined = sorted(
            coverage_results + unmatched,
            key=lambda x: (x["coverage_percentage"], -x["roi_score"])
        )
    if not combined:
        raise ValueError(f"Something went wrong, the tool cannot be used to analyze the project.")
    if limit:
        combined = combined[:limit]
    all_results = {}
    # 按覆盖率和圈复杂度升序排序（由易到难）
    min_path_parts_len = min([len(Path(r["source_file"]).resolve().parts) for r in combined])
    for r in combined:
        common_path_parts = Path(r["source_file"]).resolve().parts[:min_path_parts_len]
        common_path = str(Path(*common_path_parts))
        if common_path not in all_results:
            all_results[common_path] = []
        all_results[common_path].append(r)
    for path, results in all_results.items():
        all_results[path] = sorted(
            results,
            key=lambda x: (x["coverage_percentage"], -x["roi_score"])
        )
    combined_sorted = sorted(
        all_results.items(),
        key=lambda x: (sum([r["coverage_percentage"] for r in x[1]]) / len(x[1]) if len(x[1]) > 0 else 0,
                       -sum([r["roi_score"] for r in x[1]]) / len(x[1]) if len(x[1]) > 0 else 0,
                       )
    )
    combined_sorted_ = sum([x[1] for x in combined_sorted], [])

    # 返回新结构（不含 matches，只保留处理后的结果）
    result = {
        "coverage_results": combined_sorted_
    }

    return result
