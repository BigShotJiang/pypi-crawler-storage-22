'''
[default]
aws_access_key_id = AKIAZ6Z5IX4RANIZ57NZ
aws_secret_access_key = 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
output = json
region = us-east-2
'''