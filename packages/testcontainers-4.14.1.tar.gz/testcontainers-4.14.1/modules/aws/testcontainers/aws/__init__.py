from .aws_lambda import AWSLambdaContainer  # noqa: F401
