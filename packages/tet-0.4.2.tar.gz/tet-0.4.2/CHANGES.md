# Changes


2025-01-28  Antti Haapala  <antti.haapala@anttipatterns.com>

    * Add Python 3.12, 3.13, 3.14 support. Drop Python 3.6-3.8 support.
    * Add Sphinx documentation and ReadTheDocs integration.

2021-03-19  Antti Haapala  <antti.haapala@anttipatterns.com>

    * The tet.di request scoped services are now truly instantiated per request!

2016-08-19  Antti Haapala  <antti.haapala@anttipatterns.com>

    * SQLAlchemy root factory now gives NotFound on DataError; made into a implicit-namespace package;
      fixed backports.typing to greater than or equal to 1.1.

2013-09-07  Antti Haapala  <antti.haapala@anttipatterns.com>

    * renamed the package to `tet`

