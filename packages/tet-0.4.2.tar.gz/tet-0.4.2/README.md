![tet](https://raw.githubusercontent.com/tetframework/tet/master/docs/_static/tet.png)

[![PyPI version](https://img.shields.io/pypi/v/tet.svg)](https://pypi.org/project/tet/)
[![Python versions](https://img.shields.io/pypi/pyversions/tet.svg)](https://pypi.org/project/tet/)
[![License](https://img.shields.io/pypi/l/tet.svg)](https://pypi.org/project/tet/)
[![Documentation Status](https://readthedocs.org/projects/tet/badge/?version=latest)](https://tet.readthedocs.io/en/latest/?badge=latest)
[![GitHub stars](https://img.shields.io/github/stars/tetframework/tet.svg?style=social)](https://github.com/tetframework/tet)

Unearthly intelligent batteries-included application framework built on Pyramid.

## How to install

```
pip install tet
```
