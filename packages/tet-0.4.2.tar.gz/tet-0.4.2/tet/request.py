from pyramid.request import *

