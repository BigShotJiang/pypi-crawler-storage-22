from __future__ import annotations
from functools import partial
from typing import Any, Literal


Cardinality = Literal['one', 'many']
#T = TypeVar('T')
#U = TypeVar('U')
#V = TypeVar('V')


def _get_relation(self, *, relreg: RelationRegistry):
    # naive implementation that searches through the relmgr's set of relation
    # tuples until we find self._me. Return the related item
    for rel in relreg.items:
        if rel[0] == self:
            return rel[1]
        elif rel[1] == self:
            return rel[0]
    return None

def _set_relation(self, value: Any, *, relreg: RelationRegistry):
    for rel in set(relreg.items):
        if rel[0] == self:
            relreg.items.remove(rel)
        if rel[1] == self:
            relreg.items.remove(rel)
    me_type = type(self)
    if relreg.a_type == me_type:
        relreg.items.add((self, value))
    elif relreg.b_type == me_type:
        relreg.items.add((value, self))

def _del_relation(self, *, relreg: RelationRegistry):
    for rel in set(relreg.items):
        if rel[0] == self:
            relreg.items.remove(rel)
        elif rel[1] == self:
            relreg.items.remove(rel)

def _get_relationset(self, *, relreg: RelationRegistry):
    relset = RelationSet(relreg=relreg, srcitem=self)
    return relset

class RelationSet:
    def __init__(self, relreg: RelationRegistry, srcitem: Any) -> None:
        self._srcitem = srcitem
        self._relmgr = relreg
        self._iternum = 0

    def __and__(self):
        raise NotImplementedError()

    def __contains__(self, other_item: Any) -> bool:
        if (self._srcitem, other_item) in self._relmgr.items:
            return True
        elif (other_item, self._srcitem) in self._relmgr.items:
            return True
        else:
            return False

    def __eq__(self, other) -> bool:
        for x in self:
            if x not in other:
                return False
        for x in other:
            if x not in self:
                return False
        return True

    def __iter__(self) -> RelationSet:
        return self

    def __next__(self):
        cur = 0
        for iteritem in self._relmgr.items:
            if cur < self._iternum:
                cur += 1
                continue
            if self._srcitem is iteritem[0]:
                self._iternum += 1
                cur += 1
                return iteritem[1]
            elif self._srcitem is iteritem[1]:
                self._iternum += 1
                cur += 1
                return iteritem[0]
        raise StopIteration


    def __len__(self) -> int:
        count = 0
        for iteritem in self._relmgr.items:
            if self._srcitem is iteritem[0]:
                count += 1
            elif self._srcitem is iteritem[1]:
                count += 1
        return count

    def __repr__(self):
        x = (set(self))
        return str(x)

    def __str__(self):
        return self.__repr__()

    def add(self, value):
        if type(self._srcitem) == self._relmgr.a_type:
            if type(value) != self._relmgr.b_type:
                raise TypeError()
            self._relmgr.items.add((self._srcitem, value))
        elif type(self._srcitem) == self._relmgr.b_type:
            if type(value) != self._relmgr.a_type:
                raise TypeError()
            self._relmgr.items.add((value, self._srcitem))

    def clear(self):
        raise NotImplementedError()

    def copy(self):
        raise NotImplementedError()

    def difference(self):
        raise NotImplementedError()

    def difference_update(self):
        raise NotImplementedError()

    def discard(self, value):
        if type(self._srcitem) == self._relmgr.a_type:
            self._relmgr.items.discard((self._srcitem, value))
        elif type(self._srcitem) == self._relmgr.b_type:
            self._relmgr.items.discard((value, self._srcitem))

    def intersection(self):
        raise NotImplementedError()

    def intersection_update(self):
        raise NotImplementedError()

    def isdisjoint(self):
        raise NotImplementedError()

    def issubset(self):
        raise NotImplementedError()

    def issuperset(self):
        raise NotImplementedError()

    def pop(self, index: int = None):
        raise NotImplementedError()

    def remove(self, value):
        if type(self._srcitem) == self._relmgr.a_type:
            if (self._srcitem, value) not in self._relmgr.items:
                raise KeyError(value)
        elif type(self._srcitem) == self._relmgr.b_type:
            if (value, self._srcitem) not in self._relmgr.items:
                raise KeyError(value)

        if type(self._srcitem) == self._relmgr.a_type:
            self._relmgr.items.discard((self._srcitem, value))
        elif type(self._srcitem) == self._relmgr.b_type:
            self._relmgr.items.discard((value, self._srcitem))

    def symmetric_difference(self):
        raise NotImplementedError()

    def symmetric_difference_update(self):
        raise NotImplementedError()

    def union(self):
        raise NotImplementedError()

    def update(self):
        raise NotImplementedError()


class RelationRegistry:
    def __init__(self,
                 name: str,
                 a_type: Any,
                 a_cardinality: Cardinality,
                 b_type: Any,
                 b_cardinality: Cardinality,
                 dependancy: bool = False
    ) -> None:
        self.name: str = name
        self.items: set[tuple[Any, Any]] = set()
        self.a_type: Any = a_type
        self.a_cardinality: Cardinality = a_cardinality
        self.b_type: Any = b_type
        self.b_cardinality: Cardinality = b_cardinality
        self.dependancy: bool = dependancy


def create_relation(name: str,
                    a_type: Any,
                    a_cardinality: Cardinality,
                    b_type: Any,
                    b_cardinality: Cardinality,
                    a_attrname: str = '',
                    b_attrname: str = '',
                    dependancy: bool = False
                    ) -> RelationRegistry:
    relreg = RelationRegistry(name=name,
                              a_type=a_type,
                              a_cardinality=a_cardinality,
                              b_type=b_type,
                              b_cardinality=b_cardinality,
                              dependancy=dependancy
                              )
    if a_cardinality == 'one':
        get_part = partial(_get_relation, relreg=relreg)
        set_part = partial(_set_relation, relreg=relreg)
        del_part = partial(_del_relation, relreg=relreg)
        prop = property(get_part, set_part, del_part)
        if a_attrname == '':
            setattr(b_type, a_type.single, prop)
        else:
            setattr(b_type, a_attrname, prop)
    elif a_cardinality == 'many':
        get_part = partial(_get_relationset, relreg=relreg)
        prop = property(get_part)
        if a_attrname == '':
            setattr(b_type, a_type.plural, prop)
        else:
            setattr(b_type, a_attrname, prop)
    if b_cardinality == 'one':
        get_part = partial(_get_relation, relreg=relreg)
        set_part = partial(_set_relation, relreg=relreg)
        del_part = partial(_del_relation, relreg=relreg)
        prop = property(get_part, set_part, del_part)
        if b_attrname == '':
            setattr(a_type, b_type.single, prop)
        else:
            setattr(a_type, b_attrname, prop)
    elif b_cardinality == 'many':
        get_part = partial(_get_relationset, relreg=relreg)
        prop = property(get_part)
        if b_attrname == '':
            setattr(a_type, b_type.plural, prop)
        else:
            setattr(a_type, b_attrname, prop)

    return relreg

#def get_relations(self, registry: RelationRegistry) -> Iterable:
#    if type(self) == registry.a_type:
#        key: str = 'a'
#        value: str = 'b'
#        cardinality: Cardinality = registry.a_cardinality
#    else:
#        key: str = 'b'
#        value: str = 'a'
#        cardinality: Cardinality = registry.b_cardinality
#    for item in registry.items:
#        if getattr(item, key) == self:
#            if cardinality == 'one':
#                return getattr(item, value)
#            elif cardinality == 'many':
#                yield getattr(item, value)
#    if cardinality == 'one':
#        return None
