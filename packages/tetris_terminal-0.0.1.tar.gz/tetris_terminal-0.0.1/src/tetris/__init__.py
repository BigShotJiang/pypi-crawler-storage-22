from .tetris import Tetris

__all__ = ["Tetris"]
