"""Checkpoint and rollback management."""
