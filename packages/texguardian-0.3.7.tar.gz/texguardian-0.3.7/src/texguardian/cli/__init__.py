"""CLI module for TexGuardian."""
