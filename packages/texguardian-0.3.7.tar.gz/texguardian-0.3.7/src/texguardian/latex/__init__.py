"""LaTeX compilation and parsing."""
