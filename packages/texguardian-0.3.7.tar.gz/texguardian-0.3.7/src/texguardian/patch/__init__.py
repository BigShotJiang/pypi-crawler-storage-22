"""Patch parsing and application."""
