"""Safety guards and validation."""
