"""Visual verification pipeline."""
