"""TexGuardian test suite."""
