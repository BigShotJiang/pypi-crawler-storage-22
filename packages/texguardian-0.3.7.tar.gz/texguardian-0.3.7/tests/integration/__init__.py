"""Integration tests for TexGuardian."""
