"""Unit tests for TexGuardian."""
