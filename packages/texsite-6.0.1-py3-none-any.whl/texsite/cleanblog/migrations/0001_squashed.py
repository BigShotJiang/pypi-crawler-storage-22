from django.db import migrations


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        ('texsitecore', '0008_migrate_pages_to_universal'),
    ]

    operations = [
        migrations.RunSQL(
            'DROP TABLE IF EXISTS texsitecleanblog_cleanblogpage',
            migrations.RunSQL.noop,
        ),
    ]
