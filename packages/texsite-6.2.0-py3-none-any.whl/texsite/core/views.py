from django.shortcuts import render

from texsite.core.models import DEFAULT_THEME, get_theme_for_request


def _resolve_error_template(request):
    try:
        theme = get_theme_for_request(request)
    except Exception:
        theme = DEFAULT_THEME
    return f'texsite{theme}/error.html'


def page_not_found(request, exception):
    template = _resolve_error_template(request)
    context = {'error_message': 'Sorry, this page could not be found.'}
    return render(request, template, context=context, status=404)


def server_error(request):
    template = _resolve_error_template(request)
    context = {
        'error_message': (
            'Sorry, there seems to be an error. Please try again soon.'
        )
    }
    return render(request, template, context=context, status=500)
