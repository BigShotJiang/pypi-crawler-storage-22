# about.py

__version__ = "0.1.8"
__package__ = "text_to_speech_program"
__program_server__ = "tts-program-server"
__program_client__ = "tts-program-client"
__author__ = "Fernando Pujaico Rivera" 
__email__  = "fernando.pujaico.rivera@gmail.com"
__description__ = "A text-to-speech server and client using gtts and pydub"
__url_source__  = "https://github.com/trucomanx/text_to_speech_program"
__url_doc__  = "https://github.com/trucomanx/text_to_speech_program/tree/main/doc"
__url_funding__ = "https://trucomanx.github.io/en/funding.html"
__url_bugs__    = "https://github.com/trucomanx/text_to_speech_program/issues"
