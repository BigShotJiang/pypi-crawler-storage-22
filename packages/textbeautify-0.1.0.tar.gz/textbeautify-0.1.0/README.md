A TextBeautify Library That Beautifys Your Text!
# Installation
```bash
pip install TextBeautify
```
# Usage
```python
import TextBeautify

print(TextBeautify.beautify("Any Text Here"))
```
# Output
```bash
*★ Any Text Here ★*
```
