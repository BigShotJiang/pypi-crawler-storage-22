"""
A TextBeautify Library that Beautifys Your Text!
"""

def beautify(message):
    return "*★ " + message + " ★*"

