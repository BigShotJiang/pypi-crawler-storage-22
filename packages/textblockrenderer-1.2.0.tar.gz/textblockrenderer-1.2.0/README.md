# Text Block Renderer

A Python library for parsing HTML text, splitting text into blocks by
dimensions, and rendering blocks to PNG images.\
一个用于解析 HTML 文本、按尺寸拆分文本块并将其渲染为 PNG 图片的 Python
库。

------------------------------------------------------------------------

## Installation \| 安装

Install from PyPI:

``` bash
pip install textblockrenderer
```

Or install from source:

``` bash
cd textblockrenderer
pip install -e .
```

从源码安装：

``` bash
cd textblockrenderer
pip install -e .
```

------------------------------------------------------------------------

## Features \| 功能特性

-   **HTML Parsing**: Parse HTML text with color and font-size styles\
    **HTML 解析**：支持解析带颜色与字号样式的 HTML 文本

-   **Text Splitting**: Split text into blocks within specified
    dimensions\
    **文本拆分**：根据尺寸约束拆分文本块

-   **PNG Rendering**: Render text blocks to PNG images with
    customizable styles\
    **PNG 渲染**：将文本块渲染为可自定义样式的 PNG 图片

-   **Newline Support**: Preserve `\n` as explicit line breaks\
    **换行支持**：保留 `\n` 作为显式换行

-   **Unlimited Height**: Use `max_height=0` to disable height limits\
    **无限高度模式**：设置 `max_height=0` 可取消高度限制

-   **O(n) Performance**: Incremental measurement algorithm for
    efficient splitting\
    **O(n) 性能**：使用增量测量算法提升拆分效率

-   **RTL Language Support**: Full support for Arabic and Hebrew (Right-to-Left)\
    **RTL 语言支持**：完整支持阿拉伯语和希伯来语（从右到左书写）

------------------------------------------------------------------------

## Usage \| 使用示例

``` python
from textblockrenderer import (
    FontSpec, RenderConstraint, SplitConfig,
    TextMeasurer, split_html_paragraphs,
    split_html_to_colored_blocks, render_colored_block
)

# 1. Parse HTML paragraphs
html_text = '<p>Hello <span style="color: red;">World</span></p>'
paragraphs = split_html_paragraphs(html_text)

# Or combine paragraphs with newlines
combined = split_html_paragraphs(html_text, combine=True)

# 2. Configure font and constraints
font_spec = FontSpec(font_path="arialbd.ttf", font_size=36)
measurer = TextMeasurer(font_spec)
constraint = RenderConstraint(max_width=680, max_height=300)
# Configure language for better semantic splitting (default "EN")
config = SplitConfig(min_words_per_block=8, language="DE")

# 3. Split text into blocks
blocks = split_html_to_colored_blocks(paragraphs[0], measurer, constraint, config)

# 4. Render to PNG
for i, block in enumerate(blocks):
    img = render_colored_block(
        block,
        measurer,
        background_color=(0, 0, 0, 0),
        default_color="white",
        align="center"
    )
    img.save(f"block_{i}.png")
```

### Explanation \| 说明

-   Parse HTML into paragraphs\
    将 HTML 文本解析为段落

-   Configure font and layout constraints\
    配置字体与尺寸限制

-   Split paragraphs into renderable blocks\
    将段落拆分为可渲染文本块

-   Render blocks into PNG images\
    将文本块渲染为 PNG 图片

------------------------------------------------------------------------

## Newline Support \| 换行支持

``` python
text = "First line\nSecond line\n\nAfter empty line"
blocks = split_html_to_colored_blocks(text, measurer, constraint, config)
```

Result:

-   Line 1: First line\
-   Line 2: Second line\
-   Line 3: empty line\
-   Line 4: After empty line

结果：

-   第1行：First line
-   第2行：Second line
-   第3行：空行
-   第4行：After empty line

------------------------------------------------------------------------

## Unlimited Height \| 无限高度模式

``` python
constraint = RenderConstraint(max_width=680, max_height=0)
blocks = split_html_to_colored_blocks(text, measurer, constraint, config)
```

All text will remain in a single block.

所有文本将保留在一个块中。

------------------------------------------------------------------------

## API Reference \| API 参考

### HTML Parsing \| HTML 解析

-   `parse_html_text(html_text, base_font_size, target_font_size)`\
-   `split_html_paragraphs(html_text, combine=False)`

------------------------------------------------------------------------

### Text Splitting \| 文本拆分

-   `TextMeasurer(font_spec)`
-   `split_paragraph_to_blocks(paragraph, measurer, constraint, config)`
-   `split_html_to_colored_blocks(html_paragraph, measurer, constraint, config)`

------------------------------------------------------------------------

### PNG Rendering \| PNG 渲染

-   `render_colored_block(block, measurer, ...)`

------------------------------------------------------------------------

### Data Models \| 数据模型

-   `FontSpec` --- Font configuration / 字体配置
-   `RenderConstraint` --- Size constraints / 尺寸限制
-   `SplitConfig` --- Split configuration / 拆分配置
-   `ColoredWord` --- Styled word object / 带样式的单词对象
-   `ColoredSubtitleBlock` --- Styled text block / 带样式文本块

------------------------------------------------------------------------

## Version History \| 版本历史

### 1.2.0

-   RTL Language Support / 从右到左语言支持 (Arabic, Hebrew)
-   Arabic reshaping for connected letters / 阿拉伯语字母连接
-   Bidirectional text rendering / 双向文本渲染
-   RTL-aware semantic break detection / RTL 感知的语义断点检测
-   Performance optimization with batch RTL processing / 批量 RTL 处理性能优化

### 1.1.0

-   Multi-language Support / 多语言支持 (19 languages)
-   Language-specific semantic splitting / 特定语言的语义拆分
-   Greek question mark support / 希腊语问号支持

### 1.0.0

-   Stable release / 稳定版本发布
-   O(n) incremental measurement / O(n) 增量测量算法
-   Newline support / 支持换行
-   Unlimited height mode / 无限高度模式
-   Paragraph combination support / 支持段落合并

------------------------------------------------------------------------

## License \| 许可证

MIT License

------------------------------------------------------------------------

## Todo / Roadmap

-   [ ] A simplified API that is easy and quick to use / 简化版 API，方便快捷
-   [ ] Chinese, Japanese and Korean language support / 中日韩语言支持
