"""Text Block Renderer - A library for parsing HTML text, splitting text into blocks, and rendering blocks to PNG images."""

from .models import (
    ColoredSpan,
    ColoredWord,
    FontSpec,
    RenderConstraint,
    SubtitleBlock,
    ColoredSubtitleBlock,
    SplitConfig,
)
from .htmlparser import (
    ColorHTMLParser,
    parse_html_text,
    split_html_paragraphs,
)
from .splitter import (
    TextMeasurer,
    find_semantic_break,
    split_paragraph_to_blocks,
    find_colored_semantic_break,
    split_html_to_colored_blocks,
)
from .renderer import (
    optimize_polygon_x_alignment,
    round_polygon_corners,
    render_colored_block,
)
from .rtl_processor import (
    is_rtl_language,
    is_rtl_text,
    process_rtl_text,
    RTL_AVAILABLE,
)

__version__ = "1.2.0"

__all__ = [
    # Models
    "ColoredSpan",
    "ColoredWord",
    "FontSpec",
    "RenderConstraint",
    "SubtitleBlock",
    "ColoredSubtitleBlock",
    "SplitConfig",
    # HTML Parser
    "ColorHTMLParser",
    "parse_html_text",
    "split_html_paragraphs",
    # Splitter
    "TextMeasurer",
    "find_semantic_break",
    "split_paragraph_to_blocks",
    "find_colored_semantic_break",
    "split_html_to_colored_blocks",
    # Renderer
    "optimize_polygon_x_alignment",
    "round_polygon_corners",
    "render_colored_block",
    # RTL Utilities
    "is_rtl_language",
    "is_rtl_text",
    "process_rtl_text",
    "RTL_AVAILABLE",
]
