"""HTML parsing utilities for extracting text with color and font-size styles."""

from typing import List, Optional, Tuple
from html.parser import HTMLParser
import re

from .models import ColoredSpan, ColoredWord


class ColorHTMLParser(HTMLParser):
    """解析HTML提取文本、颜色和字号信息"""

    def __init__(self, base_font_size: int = 16, target_font_size: int = 36):
        """
        Args:
            base_font_size: HTML 中的字号基准
            target_font_size: 实际渲染的目标字号
        """
        super().__init__()
        self.base_font_size = base_font_size
        self.target_font_size = target_font_size
        self.colored_spans: List[ColoredSpan] = []
        self.current_color: Optional[str] = None
        self.current_font_size: Optional[int] = None  # 存储缩放后的字号
        self.color_stack: List[Optional[str]] = []
        self.font_size_stack: List[Optional[int]] = []

    def _parse_font_size(self, value: str) -> Optional[int]:
        """解析字号值，按比例缩放到目标字号

        缩放公式: 实际字号 = (HTML字号 / 基准字号) * 目标字号
        """
        value = value.strip().lower()
        # 匹配数字和单位
        match = re.match(r"([\d.]+)(px|pt|em|rem|%)?", value)
        if match:
            num = float(match.group(1))
            unit = match.group(2) or "px"

            # 转换为 HTML 像素值
            if unit == "px":
                html_px = num
            elif unit == "pt":
                html_px = num * 1.333
            elif unit in ("em", "rem"):
                html_px = num * self.base_font_size
            elif unit == "%":
                html_px = num / 100 * self.base_font_size
            else:
                html_px = num

            # 按比例缩放到目标字号
            scaled = (html_px / self.base_font_size) * self.target_font_size
            return int(scaled)
        return None

    def handle_starttag(self, tag: str, attrs: List[Tuple[str, str]]):
        if tag in ("span", "font", "p", "div", "b", "i", "strong", "em"):
            color = None
            font_size = None
            for attr_name, attr_value in attrs:
                if attr_name == "color":
                    color = attr_value
                elif attr_name == "size":
                    # <font size="5"> 格式
                    font_size = self._parse_font_size(attr_value)
                elif attr_name == "style":
                    # 解析 style="color: red; font-size: 24px"
                    color_match = re.search(r"color:\s*([^;]+)", attr_value)
                    if color_match:
                        color = color_match.group(1).strip()
                    size_match = re.search(r"font-size:\s*([^;]+)", attr_value)
                    if size_match:
                        font_size = self._parse_font_size(size_match.group(1))

            # 压入栈，继承父级样式
            self.color_stack.append(color if color else self.current_color)
            self.font_size_stack.append(
                font_size if font_size else self.current_font_size
            )
            if color:
                self.current_color = color
            if font_size:
                self.current_font_size = font_size

    def handle_endtag(self, tag: str):
        if (
            tag in ("span", "font", "p", "div", "b", "i", "strong", "em")
            and self.color_stack
        ):
            self.color_stack.pop()
            self.font_size_stack.pop()
            self.current_color = self.color_stack[-1] if self.color_stack else None
            self.current_font_size = (
                self.font_size_stack[-1] if self.font_size_stack else None
            )

    def handle_data(self, data: str):
        if data.strip():
            self.colored_spans.append(
                ColoredSpan(
                    text=data,
                    color=self.current_color,
                    font_size=self.current_font_size,
                )
            )

    def get_colored_words(self) -> List[ColoredWord]:
        """将文本片段转换为带样式的单词列表，支持 \\n 换行

        换行符会被当作字符处理：
        - 单词后的 \\n 会设置 force_newline=True
        - 空行（连续的 \\n\\n）会添加一个特殊的换行标记单词
        """
        words = []
        for span in self.colored_spans:
            # 按换行符分割，保留换行信息
            lines = span.text.split("\n")
            for line_idx, line in enumerate(lines):
                line_words = line.split()
                is_not_last_line = line_idx < len(lines) - 1

                if not line_words:
                    # 空行：添加一个特殊的换行标记（只在非最后一行时添加）
                    if is_not_last_line:
                        words.append(
                            ColoredWord(
                                word="",  # 空单词作为换行标记
                                color=span.color,
                                font_size=span.font_size,
                                force_newline=True,
                            )
                        )
                else:
                    for word_idx, word in enumerate(line_words):
                        # 如果是该行最后一个单词，且不是最后一行，标记 force_newline
                        is_last_word_in_line = word_idx == len(line_words) - 1
                        force_newline = is_last_word_in_line and is_not_last_line

                        words.append(
                            ColoredWord(
                                word=word,
                                color=span.color,
                                font_size=span.font_size,
                                force_newline=force_newline,
                            )
                        )
        return words


def parse_html_text(
    html_text: str,
    base_font_size: int = 16,
    target_font_size: int = 36,
) -> Tuple[str, List[ColoredWord]]:
    """
    解析HTML文本

    Args:
        html_text: HTML 格式的文本
        base_font_size: HTML 中的字号基准（默认 16px）
        target_font_size: 实际渲染的目标字号（默认 36px）

    返回: (纯文本, 带样式的单词列表)
    """
    parser = ColorHTMLParser(base_font_size, target_font_size)
    parser.feed(html_text)
    colored_words = parser.get_colored_words()
    plain_text = " ".join(w.word for w in colored_words)
    return plain_text, colored_words


def split_html_paragraphs(html_text: str, combine: bool = False) -> str | List[str]:
    """
    按HTML段落标签或换行符分割文本
    支持 <p>, <br>, <div> 等标签作为分隔符
    如果文本不包含HTML标签，则按 \\n 分割

    Args:
        html_text: HTML 格式的文本
        combine: 如果为 True，将所有段落用换行符组合成单一字符串返回

    Returns:
        分割后的段落列表（每个段落保留内部标签如span）
    """
    # 检测是否包含 HTML 标签
    has_html_tags = bool(re.search(r"<[a-zA-Z][^>]*>", html_text))

    if not has_html_tags:
        if combine:
            return [html_text]
        # 纯文本模式：按换行符分割
        paragraphs = html_text.split("\n")
        result = [p.strip() for p in paragraphs if p.strip()]
        return result
    else:
        # HTML 模式：匹配 </p><p> 或 <br> 或 </div><div> 等作为段落分隔
        paragraphs = re.split(
            r"</p>\s*(?:<p[^>]*>)?|<br\s*/?>|</div>\s*(?:<div[^>]*>)?", html_text
        )

        result = []
        for p in paragraphs:
            # 清理开头的 <p> 或 <div> 标签
            cleaned = re.sub(r"^<(p|div)[^>]*>", "", p.strip())
            # 清理结尾的 </p> 或 </div>
            cleaned = re.sub(r"</(p|div)>$", "", cleaned)
            # 去除纯空白段落
            # if cleaned.strip():
            result.append(cleaned)

        if combine:
            return ["\n".join(result)]
        return result
