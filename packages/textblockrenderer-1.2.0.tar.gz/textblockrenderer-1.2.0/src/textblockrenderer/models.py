"""Shared data models for text block rendering."""

from typing import List, Optional, Tuple
from pydantic import BaseModel, Field
from dataclasses import dataclass


@dataclass
class ColoredSpan:
    """带颜色和字号的文本片段"""

    text: str
    color: Optional[str] = None
    font_size: Optional[int] = None  # 字号（像素）


@dataclass
class ColoredWord:
    """单个单词及其样式"""

    word: str
    color: Optional[str] = None
    font_size: Optional[int] = None  # 字号（像素），None 表示使用默认字号
    force_newline: bool = False  # 该单词后是否强制换行


class FontSpec(BaseModel):
    """字体配置"""

    font_path: str
    font_size: int
    line_spacing: int = 4  # 额外行距


class RenderConstraint(BaseModel):
    """渲染约束

    Attributes:
        max_width: 最大宽度（像素）
        max_height: 最大高度（像素），设置为 0 表示高度无限制
    """

    max_width: int
    max_height: int = 0  # 默认值 0 表示高度无限制


class SubtitleBlock(BaseModel):
    """纯文本字幕块"""

    text: str
    lines: List[str]

    width: int
    height: int

    area_used: int
    area_remaining: int


class ColoredSubtitleBlock(BaseModel):
    """支持颜色和字号的字幕块"""

    plain_text: str  # 纯文本（去除HTML标签）
    colored_words: List[ColoredWord]  # 带样式的单词列表
    lines: List[List[ColoredWord]]  # 按行分组的带样式单词
    line_heights: List[int] = []  # 每行的高度（支持不同字号）
    width: int
    height: int
    area_used: int
    area_remaining: int
    rtl_mode: bool = False  # 是否为 RTL（右到左）文本

    class Config:
        arbitrary_types_allowed = True


class SplitConfig(BaseModel):
    """分割配置"""

    min_words_per_block: int = Field(3, ge=1)
    language: str = "EN"
