"""PNG rendering utilities for text blocks."""

from typing import List, Tuple
from PIL import Image, ImageDraw
import math

from .models import ColoredSubtitleBlock
from .splitter import TextMeasurer


def optimize_polygon_x_alignment(
    points: List[Tuple[int, int]], threshold: int = 5, side: str = "right"
) -> List[Tuple[int, int]]:
    """
    优化多边形顶点的 x 坐标对齐

    对于相邻的两个点，如果它们的 x 坐标差值在阈值范围内，
    根据边的位置进行对齐：
    - 右侧边界 (side="right")：合并到较大的 x 值（向右扩展）
    - 左侧边界 (side="left")：合并到较小的 x 值（向左扩展）

    使用多轮迭代确保级联合并：当 x1 合并到 x0 后，x2 会按照新的 x1 计算。

    Args:
        points: 多边形顶点列表 [(x, y), ...]
        threshold: x 坐标对齐的阈值（像素），默认为 5
        side: 边的位置，"left" 或 "right"

    Returns:
        优化后的顶点列表
    """
    if len(points) <= 4:
        return points

    optimized = list(points)

    changed = True
    while changed:
        changed = False
        for i in range(len(optimized) - 1):
            curr_x, curr_y = optimized[i]
            next_x, next_y = optimized[i + 1]

            x_diff = abs(next_x - curr_x)

            if x_diff <= threshold and x_diff > 0:
                if side == "right":
                    # 右侧边界：合并到较大的 x 值
                    target_x = max(curr_x, next_x)
                else:
                    # 左侧边界：合并到较小的 x 值
                    target_x = min(curr_x, next_x)

                if optimized[i][0] != target_x or optimized[i + 1][0] != target_x:
                    optimized[i] = (target_x, curr_y)
                    optimized[i + 1] = (target_x, next_y)
                    changed = True

    return optimized


def round_polygon_corners(
    points: List[Tuple[int, int]], radius: int = 12, segments: int = 8
) -> List[Tuple[int, int]]:
    """
    对多边形的外凸角进行圆角处理

    使用向量叉积判断角的凸凹性：
    - 对于顺时针绑线的多边形，叉积 < 0 表示外凸角
    - 仅对外凸角生成圆弧，凹角保持尖锐

    Args:
        points: 多边形顶点列表 [(x, y), ...]，顺时针方向
        radius: 圆角半径
        segments: 圆弧采样点数量, PIL的polygon绑制不支持抗锯齿, 绘制时去整了

    Returns:
        带圆角的顶点列表
    """
    if len(points) < 3 or radius <= 0:
        return points

    n = len(points)
    result = []

    for i in range(n):
        p0 = points[(i - 1) % n]
        p1 = points[i]
        p2 = points[(i + 1) % n]

        v1 = (p1[0] - p0[0], p1[1] - p0[1])
        v2 = (p2[0] - p1[0], p2[1] - p1[1])
        cross = v1[0] * v2[1] - v1[1] * v2[0]
        len1 = math.sqrt(v1[0] ** 2 + v1[1] ** 2)
        len2 = math.sqrt(v2[0] ** 2 + v2[1] ** 2)

        # 凹角或共线，保留原点
        if len1 == 0 or len2 == 0 or cross <= 0:
            result.append(p1)
            continue

        # 外凸角：生成圆弧
        u1 = (-v1[0] / len1, -v1[1] / len1)
        u2 = (v2[0] / len2, v2[1] / len2)
        max_radius = min(len1 / 2, len2 / 2, radius)

        if max_radius < 1:
            result.append(p1)
            continue

        # 二次贝塞尔曲线近似圆弧
        t1 = (p1[0] + u1[0] * max_radius, p1[1] + u1[1] * max_radius)
        t2 = (p1[0] + u2[0] * max_radius, p1[1] + u2[1] * max_radius)
        for j in range(segments + 1):
            t = j / segments
            one_minus_t = 1 - t
            bx = (
                one_minus_t * one_minus_t * t1[0]
                + 2 * one_minus_t * t * p1[0]
                + t * t * t2[0]
            )
            by = (
                one_minus_t * one_minus_t * t1[1]
                + 2 * one_minus_t * t * p1[1]
                + t * t * t2[1]
            )
            result.append((int(round(bx)), int(round(by))))

    return result


def render_colored_block(
    block: ColoredSubtitleBlock,
    measurer: TextMeasurer,
    background_color: Tuple[int, int, int, int] = (0, 0, 0, 0),
    default_color: str | Tuple[int, int, int, int] = "white",
    align: str = "left",
    padding: Tuple[int, int] = (4, 4),
    mask_offset: Tuple[int, int] = (0, 0),
    mask_mode: int = 0,
    mask_color: Tuple[int, int, int, int] = (0, 0, 0, 180),
    mask_radius: int = 8,
) -> Image.Image:
    """
    渲染带颜色和字号的字幕块为图片

    Args:
        block: 带样式的字幕块
        measurer: 文本测量器
        background_color: 背景颜色 (R, G, B, A)
        default_color: 默认文字颜色
        align: 对齐方式 - "left"(左对齐), "center"(居中), "right"(右对齐)
        padding: 内边距 (水平, 垂直)，图片边缘和底框的距离
        mask_offset: 底框偏移 (水平, 垂直)，在 padding 内圈，底框和文字的距离
        mask_mode: 底框模式 - 0=无底框, 1=矩形圆角底框, 2=按行独立底框
        mask_color: 底框颜色 (R, G, B, A)
        mask_radius: 圆角半径（仅 mask_mode=1/2 时生效）

    Returns:
        PIL Image 对象
    """
    padding_x, padding_y = padding
    mask_offset_x, mask_offset_y = mask_offset
    img_width = block.width + padding_x * 2 + mask_offset_x * 2
    img_height = block.height + padding_y * 2 + mask_offset_y * 2
    img = Image.new("RGBA", (img_width, img_height), background_color)
    draw = ImageDraw.Draw(img)

    # RTL 模式强制右对齐
    effective_align = align
    if block.rtl_mode:
        effective_align = "right"

    line_metrics = []
    default_font_size = measurer.font_spec.font_size
    total_text_height = 0

    # 计算每行的 metrics
    for line in block.lines:
        max_ascent = 0
        max_descent = 0

        if not line:
            a, d = measurer.get_metrics(default_font_size)
            max_ascent = a
            max_descent = d
        else:
            for cword in line:
                font_size = cword.font_size or default_font_size
                ascent, descent = measurer.get_metrics(font_size)
                max_ascent = max(max_ascent, ascent)
                max_descent = max(max_descent, descent)

        current_height = max_ascent + max_descent
        line_metrics.append((max_ascent, max_descent, current_height))
        total_text_height += current_height

    if len(line_metrics) > 1:
        total_text_height += (len(line_metrics) - 1) * measurer.line_spacing

    total_offset_y = padding_y + mask_offset_y
    base_y = total_offset_y + (block.height - total_text_height) // 2
    line_positions = []
    temp_y = base_y

    for line_idx, line in enumerate(block.lines):
        ascent, descent, height = line_metrics[line_idx]

        line_width = 0
        for i, cword in enumerate(line):
            word_width = measurer.measure_word(cword.word, cword.font_size)
            line_width += word_width
            if i < len(line) - 1:
                space_width = measurer.measure_word(" ", cword.font_size)
                line_width += space_width

        total_offset_x = padding_x + mask_offset_x
        if effective_align == "center":
            line_x = total_offset_x + (block.width - line_width) // 2
        elif effective_align == "right":
            line_x = total_offset_x + block.width - line_width
        else:  # left
            line_x = total_offset_x

        line_positions.append(
            {
                "x": line_x,
                "y": temp_y,
                "width": line_width,
                "height": height,
                "ascent": ascent,
            }
        )

        temp_y += height + measurer.line_spacing

    # 绘制底框
    if mask_mode == 1:
        mask_x0 = padding_x
        mask_y0 = padding_y
        mask_x1 = img_width - padding_x
        mask_y1 = img_height - padding_y
        draw.rounded_rectangle(
            [(mask_x0, mask_y0), (mask_x1, mask_y1)],
            radius=mask_radius,
            fill=mask_color,
        )
    elif mask_mode == 2:
        if line_positions:
            line_boxes = []
            line_padding_x = mask_offset_x
            line_padding_y = mask_offset_y
            for i, pos in enumerate(line_positions):
                x0 = pos["x"] - line_padding_x
                y0 = pos["y"] - (line_padding_y if i == 0 else 0)
                x1 = pos["x"] + pos["width"] + line_padding_x

                y1 = (
                    pos["y"]
                    + pos["height"]
                    + (line_padding_y if i == len(line_positions) - 1 else 0)
                )

                line_boxes.append((x0, y0, x1, y1))

            # 顺时针收集多边形顶点：右侧边界（从上到下）
            right_points = []
            right_points.append((line_boxes[0][2], line_boxes[0][1]))  # 第一行右上

            for i in range(len(line_boxes)):
                curr_box = line_boxes[i]
                if i == len(line_boxes) - 1:
                    right_points.append((curr_box[2], curr_box[3]))  # 最后一行右下
                else:
                    next_box = line_boxes[i + 1]
                    curr_x1 = curr_box[2]
                    next_x1 = next_box[2]

                    if next_x1 > curr_x1:
                        turn_y = next_box[1]
                        right_points.append((curr_x1, turn_y))
                        right_points.append((next_x1, turn_y))
                    elif next_x1 < curr_x1:
                        turn_y = curr_box[3]
                        right_points.append((curr_x1, turn_y))
                        right_points.append((next_x1, turn_y))

            # 左侧边界（从下到上）
            left_points = []
            left_points.append((line_boxes[-1][0], line_boxes[-1][3]))

            for i in range(len(line_boxes) - 1, -1, -1):
                curr_box = line_boxes[i]
                if i == 0:
                    left_points.append((curr_box[0], curr_box[1]))
                else:
                    prev_box = line_boxes[i - 1]
                    curr_x0 = curr_box[0]
                    prev_x0 = prev_box[0]

                    if prev_x0 < curr_x0:
                        turn_y = curr_box[1]
                        left_points.append((curr_x0, turn_y))
                        left_points.append((prev_x0, turn_y))
                    elif prev_x0 > curr_x0:
                        turn_y = prev_box[3]
                        left_points.append((curr_x0, turn_y))
                        left_points.append((prev_x0, turn_y))

            # 优化边界对齐并圆角处理
            right_points = optimize_polygon_x_alignment(
                right_points, threshold=20, side="right"
            )
            left_points = optimize_polygon_x_alignment(
                left_points, threshold=20, side="left"
            )
            polygon_points = right_points + left_points
            if len(polygon_points) >= 3:
                polygon_points = round_polygon_corners(
                    polygon_points, radius=mask_radius, segments=8
                )
                draw.polygon(polygon_points, fill=mask_color)

    # 绘制文本
    for line_idx, line in enumerate(block.lines):
        pos = line_positions[line_idx]
        x = pos["x"]
        baseline_y = pos["y"] + pos["ascent"]

        # RTL 模式下反转行内单词顺序，使第一个单词在最右边
        draw_line = list(reversed(line)) if block.rtl_mode else line

        for i, cword in enumerate(draw_line):
            color = cword.color or default_color
            font = measurer.get_font(cword.font_size)
            word_font_size = cword.font_size or default_font_size
            ascent, descent = measurer.get_metrics(word_font_size)
            draw_y = baseline_y - ascent

            draw.text((x, draw_y), cword.word, font=font, fill=color)

            x += measurer.measure_word(cword.word, cword.font_size)
            if i < len(draw_line) - 1:
                space_width = measurer.measure_word(" ", cword.font_size)
                x += space_width

    return img
