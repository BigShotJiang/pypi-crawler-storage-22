"""Benchmark test to compare old vs new splitting performance."""

import time

from textblockrenderer import (
    FontSpec,
    TextMeasurer,
    RenderConstraint,
    SplitConfig,
    split_html_to_colored_blocks,
)


def generate_long_text(word_count: int) -> str:
    """Generate long test text with some HTML styling."""
    base_words = [
        "Hello",
        "world",
        "this",
        "is",
        "a",
        "test",
        "message",
        "with",
        "many",
        "words",
        "for",
        "performance",
        "testing",
        "the",
        "incremental",
        "measurement",
        "algorithm",
    ]
    words = []
    for i in range(word_count):
        word = base_words[i % len(base_words)]
        # Add some color styling every 10 words
        if i % 10 == 0:
            word = f'<span style="color: red;">{word}</span>'
        words.append(word)
    return " ".join(words)


def benchmark_split(word_count: int):
    """Benchmark the splitting function."""
    print(f"\n=== Benchmark: {word_count} words ===")

    # Setup
    font_spec = FontSpec(font_path="arialbd.ttf", font_size=36)
    measurer = TextMeasurer(font_spec)
    constraint = RenderConstraint(max_width=400, max_height=200)
    config = SplitConfig(min_words_per_block=3)

    text = generate_long_text(word_count)

    # Benchmark
    start = time.perf_counter()
    blocks = split_html_to_colored_blocks(text, measurer, constraint, config)
    elapsed = time.perf_counter() - start

    print(f"   Time: {elapsed*1000:.2f} ms")
    print(f"   Blocks: {len(blocks)}")
    print(f"   Words/ms: {word_count / (elapsed * 1000):.1f}")

    return elapsed


if __name__ == "__main__":
    print("=" * 50)
    print("Performance Benchmark: split_html_to_colored_blocks")
    print("=" * 50)

    # Run benchmarks with increasing word counts
    for count in [100, 500, 1000, 2000]:
        benchmark_split(count)

    print("\n" + "=" * 50)
    print("Benchmark complete!")
    print("=" * 50)
