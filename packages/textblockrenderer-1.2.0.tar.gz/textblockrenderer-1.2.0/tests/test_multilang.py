from textblockrenderer.lang_constants import CONJUNCTIONS_MAP
from textblockrenderer import find_semantic_break, SplitConfig


def test_language_conjunctions():
    """测试不同语言的连词加载"""
    assert "and" in CONJUNCTIONS_MAP["EN"]
    assert "und" in CONJUNCTIONS_MAP["DE"]
    assert "et" in CONJUNCTIONS_MAP["FR"]
    assert "i" in CONJUNCTIONS_MAP["PL"]


def test_semantic_break_german():
    """测试德语语义断行"""
    words = ["Ich", "bin", "müde,", "aber", "ich", "muss", "arbeiten"]
    break_idx = find_semantic_break(words, 0, 6, min_words=2, language="DE")
    assert break_idx == 3  # Should break after comma


def test_semantic_break_greek_question():
    """测试希腊语问号 (;)"""
    words = ["Ti", "kaneis\u037e", "Eimai", "kala"]
    break_idx = find_semantic_break(words, 0, 3, min_words=1, language="EL")
    assert break_idx == 2  # Should break after question mark


def test_semantic_break_english_default():
    words = ["Hello", "world", "and", "universe"]
    break_idx = find_semantic_break(words, 0, 4, min_words=1, language="EN")
    assert break_idx == 3


if __name__ == "__main__":
    test_language_conjunctions()
    test_semantic_break_german()
    test_semantic_break_greek_question()
    test_semantic_break_english_default()
    print("All tests passed!")
