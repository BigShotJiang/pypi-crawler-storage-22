"""Test newline support in split_html_to_colored_blocks."""

from textblockrenderer import (
    FontSpec,
    TextMeasurer,
    RenderConstraint,
    SplitConfig,
    split_html_to_colored_blocks,
    render_colored_block,
    parse_html_text,
)
import os

# Test newline detection in HTML parser
text_with_newline = "Hello World\nThis is second line\nThird line here"
plain, words = parse_html_text(text_with_newline, 18, 36)

print("=== Testing \\n detection in parser ===")
for i, w in enumerate(words):
    print(f"  [{i}] '{w.word}' force_newline={w.force_newline}")

# Test splitting with newlines
print("\n=== Testing split with \\n ===")
font_spec = FontSpec(font_path="arialbd.ttf", font_size=36)
measurer = TextMeasurer(font_spec)
constraint = RenderConstraint(max_width=600, max_height=0)  # unlimited height
config = SplitConfig(min_words_per_block=1)

blocks = split_html_to_colored_blocks(text_with_newline, measurer, constraint, config)
print(f"Blocks: {len(blocks)}")
for i, b in enumerate(blocks):
    print(f"  [{i+1}] '{b.plain_text}' - lines: {len(b.lines)}")
    for j, line in enumerate(b.lines):
        line_text = " ".join(w.word for w in line)
        print(f"       Line {j+1}: '{line_text}'")

# Render
os.makedirs("test_output", exist_ok=True)
if blocks:
    img = render_colored_block(
        blocks[0], measurer, background_color=(50, 50, 50, 255), default_color="white"
    )
    img.save("test_output/newline_test.png")
    print(f"\nSaved: test_output/newline_test.png ({img.size[0]}x{img.size[1]})")
