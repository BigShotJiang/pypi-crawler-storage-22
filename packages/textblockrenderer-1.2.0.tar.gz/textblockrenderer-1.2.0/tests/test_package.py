"""Test script for textblockrenderer package."""

import os
from textblockrenderer import (
    FontSpec,
    RenderConstraint,
    SplitConfig,
    TextMeasurer,
    split_html_paragraphs,
    split_html_to_colored_blocks,
    render_colored_block,
)


def test_package():
    """Test all three main features of the package."""

    print("=" * 50)
    print("Testing textblockrenderer package")
    print("=" * 50)

    # 1. Test HTML parsing
    print("\n[1] Testing HTML parsing...")
    html_text = """
    <p>Hello <span style="color: red;">World</span>!</p>
    <p>This is a <span style="color: blue; font-size: 24px;">test</span> paragraph.</p>
    """
    paragraphs = split_html_paragraphs(html_text)
    print(f"   Parsed {len(paragraphs)} paragraphs")
    for i, p in enumerate(paragraphs):
        print(f"   [{i+1}] {p[:50]}...")

    # 2. Test text splitting
    print("\n[2] Testing text splitting...")
    font_spec = FontSpec(font_path="arialbd.ttf", font_size=36, line_spacing=4)
    measurer = TextMeasurer(font_spec)
    constraint = RenderConstraint(max_width=400, max_height=200)
    config = SplitConfig(min_words_per_block=3)

    test_html = 'Hello <span style="color: rgb(255, 0, 0);">World</span> this is a test message for splitting.'
    blocks = split_html_to_colored_blocks(test_html, measurer, constraint, config)
    print(f"   Split into {len(blocks)} blocks")
    for i, block in enumerate(blocks):
        print(f"   [{i+1}] {block.plain_text} ({block.width}x{block.height})")

    # 3. Test PNG rendering
    print("\n[3] Testing PNG rendering...")
    os.makedirs("test_output", exist_ok=True)
    for i, block in enumerate(blocks):
        img = render_colored_block(
            block,
            measurer,
            background_color=(50, 50, 50, 255),
            default_color="white",
            align="center",
            padding=(10, 10),
        )
        output_path = f"test_output/test_block_{i+1}.png"
        img.save(output_path)
        print(f"   Saved: {output_path}")

    print("\n" + "=" * 50)
    print("All tests passed!")
    print("=" * 50)


if __name__ == "__main__":
    test_package()
