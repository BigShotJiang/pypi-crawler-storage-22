"""RTL (Right-to-Left) language support tests for Arabic and Hebrew."""

import pytest
from textblockrenderer import (
    FontSpec,
    RenderConstraint,
    SplitConfig,
    TextMeasurer,
    split_html_to_colored_blocks,
    render_colored_block,
    is_rtl_language,
    is_rtl_text,
    RTL_AVAILABLE,
)


class TestRTLDetection:
    """测试 RTL 语言检测功能"""

    def test_is_rtl_language_arabic(self):
        """Test Arabic is detected as RTL"""
        assert is_rtl_language("AR") is True
        assert is_rtl_language("ar") is True

    def test_is_rtl_language_hebrew(self):
        """Test Hebrew is detected as RTL"""
        assert is_rtl_language("HE") is True
        assert is_rtl_language("he") is True

    def test_is_rtl_language_persian(self):
        """Test Persian/Farsi is detected as RTL"""
        assert is_rtl_language("FA") is True

    def test_is_rtl_language_urdu(self):
        """Test Urdu is detected as RTL"""
        assert is_rtl_language("UR") is True

    def test_is_rtl_language_english(self):
        """Test English is not RTL"""
        assert is_rtl_language("EN") is False

    def test_is_rtl_language_german(self):
        """Test German is not RTL"""
        assert is_rtl_language("DE") is False

    def test_is_rtl_text_arabic(self):
        """Test Arabic text detection"""
        assert is_rtl_text("مرحبا بالعالم") is True
        assert is_rtl_text("Hello World") is False

    def test_is_rtl_text_hebrew(self):
        """Test Hebrew text detection"""
        assert is_rtl_text("שלום עולם") is True

    def test_is_rtl_text_mixed(self):
        """Test mixed RTL/LTR text detection"""
        # Contains Arabic characters
        assert is_rtl_text("Hello مرحبا World") is True


@pytest.mark.skipif(not RTL_AVAILABLE, reason="RTL libraries not installed")
class TestRTLTextProcessing:
    """测试 RTL 文本处理功能"""

    def test_arabic_splitting_creates_rtl_blocks(self):
        """Test that Arabic text creates blocks with rtl_mode=True"""
        font_spec = FontSpec(font_path="arial.ttf", font_size=36)
        measurer = TextMeasurer(font_spec)
        constraint = RenderConstraint(max_width=500, max_height=200)
        config = SplitConfig(min_words_per_block=2, language="AR")

        arabic_text = "مرحبا بالعالم العربي"
        blocks = split_html_to_colored_blocks(arabic_text, measurer, constraint, config)

        assert len(blocks) > 0
        for block in blocks:
            assert block.rtl_mode is True

    def test_hebrew_splitting_creates_rtl_blocks(self):
        """Test that Hebrew text creates blocks with rtl_mode=True"""
        font_spec = FontSpec(font_path="arial.ttf", font_size=36)
        measurer = TextMeasurer(font_spec)
        constraint = RenderConstraint(max_width=500, max_height=200)
        config = SplitConfig(min_words_per_block=2, language="HE")

        hebrew_text = "שלום עולם"
        blocks = split_html_to_colored_blocks(hebrew_text, measurer, constraint, config)

        assert len(blocks) > 0
        for block in blocks:
            assert block.rtl_mode is True

    def test_english_splitting_creates_ltr_blocks(self):
        """Test that English text creates blocks with rtl_mode=False"""
        font_spec = FontSpec(font_path="arial.ttf", font_size=36)
        measurer = TextMeasurer(font_spec)
        constraint = RenderConstraint(max_width=500, max_height=200)
        config = SplitConfig(min_words_per_block=2, language="EN")

        english_text = "Hello World"
        blocks = split_html_to_colored_blocks(
            english_text, measurer, constraint, config
        )

        assert len(blocks) > 0
        for block in blocks:
            assert block.rtl_mode is False


@pytest.mark.skipif(not RTL_AVAILABLE, reason="RTL libraries not installed")
class TestRTLRendering:
    """测试 RTL 渲染功能"""

    def test_rtl_block_renders_without_error(self):
        """Test that RTL blocks can be rendered without errors"""
        font_spec = FontSpec(font_path="arial.ttf", font_size=36)
        measurer = TextMeasurer(font_spec)
        constraint = RenderConstraint(max_width=500, max_height=200)
        config = SplitConfig(min_words_per_block=2, language="AR")

        arabic_text = "مرحبا"
        blocks = split_html_to_colored_blocks(arabic_text, measurer, constraint, config)

        assert len(blocks) > 0
        # Should not raise any exceptions
        img = render_colored_block(
            blocks[0],
            measurer,
            background_color=(0, 0, 0, 0),
            default_color="white",
        )
        assert img is not None
        assert img.width > 0
        assert img.height > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
