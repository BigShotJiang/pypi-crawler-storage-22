"""Test unlimited height constraint."""

from textblockrenderer import (
    FontSpec,
    TextMeasurer,
    RenderConstraint,
    SplitConfig,
    split_html_to_colored_blocks,
    render_colored_block,
)
import os

# Test unlimited height (max_height=0)
font_spec = FontSpec(font_path="arialbd.ttf", font_size=36)
measurer = TextMeasurer(font_spec)

# With unlimited height
constraint_unlimited = RenderConstraint(max_width=300, max_height=0)
# With limited height
constraint_limited = RenderConstraint(max_width=300, max_height=100)

config = SplitConfig(min_words_per_block=3)

test_text = "This is a very long text that would normally be split into multiple blocks but now with unlimited height it should all be in one block because there is no height restriction."

print("=== Testing max_height=0 (unlimited) ===")
blocks_unlimited = split_html_to_colored_blocks(
    test_text, measurer, constraint_unlimited, config
)
print(f"Blocks: {len(blocks_unlimited)}")
for i, b in enumerate(blocks_unlimited):
    print(f"  [{i+1}] {b.width}x{b.height}px - {len(b.plain_text.split())} words")

print("\n=== Testing max_height=100 (limited) ===")
blocks_limited = split_html_to_colored_blocks(
    test_text, measurer, constraint_limited, config
)
print(f"Blocks: {len(blocks_limited)}")
for i, b in enumerate(blocks_limited):
    print(f"  [{i+1}] {b.width}x{b.height}px - {len(b.plain_text.split())} words")

# Render and save
os.makedirs("test_output", exist_ok=True)
img = render_colored_block(
    blocks_unlimited[0],
    measurer,
    background_color=(50, 50, 50, 255),
    default_color="white",
)
img.save("test_output/unlimited_height.png")
print(f"\nSaved: test_output/unlimited_height.png ({img.size[0]}x{img.size[1]})")
