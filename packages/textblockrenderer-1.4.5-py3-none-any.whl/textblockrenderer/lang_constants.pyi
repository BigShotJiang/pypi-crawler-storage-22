from _typeshed import Incomplete

EN_CONJUNCTIONS: Incomplete
DEFAULT_SENTENCE_END: Incomplete
DEFAULT_COMMA_END: Incomplete
EL_SENTENCE_END: Incomplete
SENTENCE_END_MAP: Incomplete
COMMA_END_MAP: Incomplete
RTL_LANGUAGES: Incomplete
AR_SENTENCE_END: Incomplete
AR_COMMA_END: Incomplete
HE_SENTENCE_END: Incomplete
HE_COMMA_END: Incomplete
CONJUNCTIONS_MAP: Incomplete
DEFAULT_WPM: int
WPM_MAP: Incomplete

def get_wpm_for_language(language: str) -> int: ...
