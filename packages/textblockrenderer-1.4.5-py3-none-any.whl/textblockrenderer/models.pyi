from dataclasses import dataclass
from pydantic import BaseModel

@dataclass
class ColoredSpan:
    text: str
    color: str | None = ...
    font_size: int | None = ...

@dataclass
class ColoredWord:
    word: str
    color: str | None = ...
    font_size: int | None = ...
    force_newline: bool = ...

class FontSpec(BaseModel):
    font_path: str
    font_size: int
    line_spacing: int

class RenderConstraint(BaseModel):
    max_width: int
    max_height: int

class SubtitleBlock(BaseModel):
    text: str
    lines: list[str]
    width: int
    height: int
    area_used: int
    area_remaining: int

class ColoredSubtitleBlock(BaseModel):
    plain_text: str
    colored_words: list[ColoredWord]
    lines: list[list[ColoredWord]]
    line_heights: list[int]
    width: int
    height: int
    area_used: int
    area_remaining: int
    rtl_mode: bool
    image_width: int
    image_height: int
    class Config:
        arbitrary_types_allowed: bool

class SplitConfig(BaseModel):
    min_words_per_block: int
    language: str

class RenderStyle(BaseModel):
    text_color: str
    bg_color: str | None
    alignment: str
    padding: tuple[int, int]
    mask_mode: int
    mask_color: tuple[int, int, int, int]
    mask_offset: tuple[int, int]
    corner_radius: int
    stroke_size: int
    stroke_color: tuple[int, int, int, int]
    class Config:
        arbitrary_types_allowed: bool

class FrameSubtitle(BaseModel):
    block: ColoredSubtitleBlock
    save_path: str
    read_time: float
    image_width: int
    image_height: int
    class Config:
        arbitrary_types_allowed: bool

@dataclass
class BlockTiming:
    block: ColoredSubtitleBlock
    save_path: str
    start_time: float
    end_time: float
    image_width: int = ...
    image_height: int = ...

class OverlappingFrameSubtitle(BaseModel):
    block_timings: list[BlockTiming]
    frame_end_time: float
    class Config:
        arbitrary_types_allowed: bool
