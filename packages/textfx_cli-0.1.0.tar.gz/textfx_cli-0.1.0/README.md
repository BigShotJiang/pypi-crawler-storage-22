# textfx

Text effects and transforms CLI - unicode fonts, leetspeak, zalgo, and more.

Transform plain text into fancy unicode, mocking spongebob case, binary, morse code, and 30+ other styles.

## Installation

```bash
pip install textfx-cli
```

## Usage

```bash
# Direct command for each transform
textfx bold "Hello World"       # 𝐇𝐞𝐥𝐥𝐨 𝐖𝐨𝐫𝐥𝐝
textfx zalgo "spooky"           # s̸̰͝p̷͎̊o̵̳͝ǫ̵̛k̴̤͝y̷̹͑
textfx spongebob "whatever"     # wHaTeVeR
textfx leet "hacker"            # #4(<3|2

# Pipe from stdin
echo "transform me" | textfx vaporwave

# Preview all transforms
textfx preview "Test"

# List available transforms
textfx list
```

## Available Transforms

### Unicode Fonts
- `bold` - 𝐁𝐨𝐥𝐝 𝐭𝐞𝐱𝐭
- `italic` - 𝐼𝑡𝑎𝑙𝑖𝑐 𝑡𝑒𝑥𝑡
- `bold-italic` - 𝑩𝒐𝒍𝒅 𝒊𝒕𝒂𝒍𝒊𝒄
- `script` - 𝒮𝒸𝓇𝒾𝓅𝓉
- `bold-script` - 𝓑𝓸𝓵𝓭 𝓼𝓬𝓻𝓲𝓹𝓽
- `fraktur` - 𝔉𝔯𝔞𝔨𝔱𝔲𝔯
- `double-struck` - 𝔻𝕠𝕦𝕓𝕝𝕖-𝕤𝕥𝕣𝕦𝕔𝕜
- `monospace` - 𝙼𝚘𝚗𝚘𝚜𝚙𝚊𝚌𝚎
- `sans` / `sans-bold` - Sans-serif variants
- `circled` - Ⓒⓘⓡⓒⓛⓔⓓ
- `fullwidth` - Ｆｕｌｌｗｉｄｔｈ
- `squared` / `negative-squared` - 🅂🅀🅄🄰🅁🄴🄳
- `small-caps` - sᴍᴀʟʟ ᴄᴀᴘs
- `parenthesized` - ⒫⒜⒭⒠⒩⒯⒣⒠⒮⒤⒵⒠⒟

### Effects
- `reverse` - Reverse text
- `upside-down` - Flip text upside down (ǝʇou ǝǝs)
- `leet` - |_337 5|>34|<
- `spongebob` - aLtErNaTiNg CaSe
- `zalgo` / `zalgo-mild` / `zalgo-intense` - C̴̢̛r̵̼̊e̸̲͑e̵̢̓p̸̱̉y̵̯̌ text
- `morse` - .-. --- ... .
- `binary` - 01001000 01101001
- `strikethrough` - S̶t̶r̶i̶k̶e̶t̶h̶r̶o̶u̶g̶h̶
- `underline` / `double-underline` - U̲n̲d̲e̲r̲l̲i̲n̲e̲
- `vaporwave` - Ａ　ｅ　ｓ　ｔ　ｈ　ｅ　ｔ　ｉ　ｃ
- `scramble` - Rnaodmly slcarembd wdros
- `uwu` - UwU-ify text owo
- `pig-latin` - Igpay atinlay

## JSON Output

Add `--json` to any command for machine-readable output:

```bash
textfx bold "Hello" --json
```

```json
{
  "input": "Hello",
  "transform": "bold",
  "output": "𝐇𝐞𝐥𝐥𝐨"
}
```

## Python API

```python
from textfx import transform, list_transforms

# Apply a transform
result = transform("Hello", "bold")  # "𝐇𝐞𝐥𝐥𝐨"

# List all transforms
transforms = list_transforms()
```

## For AI Agents

See [SKILL.md](SKILL.md) for agent-optimized documentation.

## License

MIT
