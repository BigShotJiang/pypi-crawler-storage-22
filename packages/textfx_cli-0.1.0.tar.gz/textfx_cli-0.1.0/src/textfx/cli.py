"""textfx CLI - Text effects and transforms."""

import json
import sys
import click

from .transforms import TRANSFORMS, list_transforms, transform, FONTS


@click.group()
@click.version_option()
def cli():
    """Text effects and transforms CLI.
    
    Transform text with unicode fonts, leetspeak, zalgo, and more.
    
    Examples:
    
        textfx bold "Hello World"
        
        textfx zalgo "spooky text"
        
        echo "pipe me" | textfx spongebob
        
        textfx list
    """
    pass


@cli.command("list")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def list_cmd(as_json: bool):
    """List all available transforms."""
    transforms = list_transforms()
    
    if as_json:
        click.echo(json.dumps({"transforms": transforms}))
    else:
        click.echo("Available transforms:")
        click.echo()
        
        # Group by category
        fonts = [t for t in transforms if t in FONTS or t in [
            "bold", "italic", "bold-italic", "script", "bold-script",
            "fraktur", "double-struck", "monospace", "sans", "sans-bold",
            "circled", "fullwidth", "parenthesized", "squared", 
            "negative-squared", "small-caps"
        ]]
        effects = [t for t in transforms if t not in fonts]
        
        click.echo("  Fonts:")
        for t in sorted(fonts):
            click.echo(f"    {t}")
        
        click.echo()
        click.echo("  Effects:")
        for t in sorted(effects):
            click.echo(f"    {t}")


@cli.command("preview")
@click.argument("text", default="Hello World")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def preview_cmd(text: str, as_json: bool):
    """Preview text with all transforms."""
    results = {}
    for name in list_transforms():
        try:
            results[name] = transform(text, name)
        except Exception as e:
            results[name] = f"[error: {e}]"
    
    if as_json:
        click.echo(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        for name, result in sorted(results.items()):
            click.echo(f"{name:20} {result}")


def make_transform_command(transform_name: str):
    """Factory to create a command for each transform."""
    @click.argument("text", required=False)
    @click.option("--json", "as_json", is_flag=True, help="Output as JSON")
    def cmd(text: str | None, as_json: bool):
        # Read from stdin if no text provided
        if text is None:
            if sys.stdin.isatty():
                raise click.UsageError("Text required. Provide as argument or pipe via stdin.")
            text = sys.stdin.read().rstrip('\n')
        
        result = transform(text, transform_name)
        
        if as_json:
            click.echo(json.dumps({
                "input": text,
                "transform": transform_name,
                "output": result
            }, ensure_ascii=False))
        else:
            click.echo(result)
    
    cmd.__doc__ = f"Apply {transform_name} transform to text."
    return cmd


# Register all transforms as commands
for name in list_transforms():
    # Convert to valid command name (no underscores)
    cmd = make_transform_command(name)
    cli.add_command(click.command(name=name)(cmd))


# Aliases for common transforms
@cli.command("fonts")
@click.argument("text", default="Hello")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def fonts_cmd(text: str, as_json: bool):
    """Preview text in all unicode fonts."""
    font_names = list(FONTS.keys())
    results = {}
    
    for name in font_names:
        try:
            from .transforms import apply_font
            results[name] = apply_font(text, name)
        except Exception:
            pass
    
    if as_json:
        click.echo(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        for name, result in results.items():
            click.echo(f"{name:20} {result}")


@cli.command("all")
@click.argument("text")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def all_cmd(text: str, as_json: bool):
    """Apply all transforms to text (alias for preview)."""
    ctx = click.get_current_context()
    ctx.invoke(preview_cmd, text=text, as_json=as_json)


if __name__ == "__main__":
    cli()
