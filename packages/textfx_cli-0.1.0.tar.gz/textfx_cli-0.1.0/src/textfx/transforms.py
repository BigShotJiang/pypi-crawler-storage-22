"""Text transformation functions."""

import random
import string

# Unicode font mappings
FONTS = {
    "bold": {
        "upper": "𝐀𝐁𝐂𝐃𝐄𝐅𝐆𝐇𝐈𝐉𝐊𝐋𝐌𝐍𝐎𝐏𝐐𝐑𝐒𝐓𝐔𝐕𝐖𝐗𝐘𝐙",
        "lower": "𝐚𝐛𝐜𝐝𝐞𝐟𝐠𝐡𝐢𝐣𝐤𝐥𝐦𝐧𝐨𝐩𝐪𝐫𝐬𝐭𝐮𝐯𝐰𝐱𝐲𝐳",
        "digits": "𝟎𝟏𝟐𝟑𝟒𝟓𝟔𝟕𝟖𝟗",
    },
    "italic": {
        "upper": "𝐴𝐵𝐶𝐷𝐸𝐹𝐺𝐻𝐼𝐽𝐾𝐿𝑀𝑁𝑂𝑃𝑄𝑅𝑆𝑇𝑈𝑉𝑊𝑋𝑌𝑍",
        "lower": "𝑎𝑏𝑐𝑑𝑒𝑓𝑔ℎ𝑖𝑗𝑘𝑙𝑚𝑛𝑜𝑝𝑞𝑟𝑠𝑡𝑢𝑣𝑤𝑥𝑦𝑧",
        "digits": None,
    },
    "bold-italic": {
        "upper": "𝑨𝑩𝑪𝑫𝑬𝑭𝑮𝑯𝑰𝑱𝑲𝑳𝑴𝑵𝑶𝑷𝑸𝑹𝑺𝑻𝑼𝑽𝑾𝑿𝒀𝒁",
        "lower": "𝒂𝒃𝒄𝒅𝒆𝒇𝒈𝒉𝒊𝒋𝒌𝒍𝒎𝒏𝒐𝒑𝒒𝒓𝒔𝒕𝒖𝒗𝒘𝒙𝒚𝒛",
        "digits": None,
    },
    "script": {
        "upper": "𝒜ℬ𝒞𝒟ℰℱ𝒢ℋℐ𝒥𝒦ℒℳ𝒩𝒪𝒫𝒬ℛ𝒮𝒯𝒰𝒱𝒲𝒳𝒴𝒵",
        "lower": "𝒶𝒷𝒸𝒹ℯ𝒻ℊ𝒽𝒾𝒿𝓀𝓁𝓂𝓃ℴ𝓅𝓆𝓇𝓈𝓉𝓊𝓋𝓌𝓍𝓎𝓏",
        "digits": None,
    },
    "bold-script": {
        "upper": "𝓐𝓑𝓒𝓓𝓔𝓕𝓖𝓗𝓘𝓙𝓚𝓛𝓜𝓝𝓞𝓟𝓠𝓡𝓢𝓣𝓤𝓥𝓦𝓧𝓨𝓩",
        "lower": "𝓪𝓫𝓬𝓭𝓮𝓯𝓰𝓱𝓲𝓳𝓴𝓵𝓶𝓷𝓸𝓹𝓺𝓻𝓼𝓽𝓾𝓿𝔀𝔁𝔂𝔃",
        "digits": None,
    },
    "fraktur": {
        "upper": "𝔄𝔅ℭ𝔇𝔈𝔉𝔊ℌℑ𝔍𝔎𝔏𝔐𝔑𝔒𝔓𝔔ℜ𝔖𝔗𝔘𝔙𝔚𝔛𝔜ℨ",
        "lower": "𝔞𝔟𝔠𝔡𝔢𝔣𝔤𝔥𝔦𝔧𝔨𝔩𝔪𝔫𝔬𝔭𝔮𝔯𝔰𝔱𝔲𝔳𝔴𝔵𝔶𝔷",
        "digits": None,
    },
    "double-struck": {
        "upper": "𝔸𝔹ℂ𝔻𝔼𝔽𝔾ℍ𝕀𝕁𝕂𝕃𝕄ℕ𝕆ℙℚℝ𝕊𝕋𝕌𝕍𝕎𝕏𝕐ℤ",
        "lower": "𝕒𝕓𝕔𝕕𝕖𝕗𝕘𝕙𝕚𝕛𝕜𝕝𝕞𝕟𝕠𝕡𝕢𝕣𝕤𝕥𝕦𝕧𝕨𝕩𝕪𝕫",
        "digits": "𝟘𝟙𝟚𝟛𝟜𝟝𝟞𝟟𝟠𝟡",
    },
    "monospace": {
        "upper": "𝙰𝙱𝙲𝙳𝙴𝙵𝙶𝙷𝙸𝙹𝙺𝙻𝙼𝙽𝙾𝙿𝚀𝚁𝚂𝚃𝚄𝚅𝚆𝚇𝚈𝚉",
        "lower": "𝚊𝚋𝚌𝚍𝚎𝚏𝚐𝚑𝚒𝚓𝚔𝚕𝚖𝚗𝚘𝚙𝚚𝚛𝚜𝚝𝚞𝚟𝚠𝚡𝚢𝚣",
        "digits": "𝟶𝟷𝟸𝟹𝟺𝟻𝟼𝟽𝟾𝟿",
    },
    "sans": {
        "upper": "𝖠𝖡𝖢𝖣𝖤𝖥𝖦𝖧𝖨𝖩𝖪𝖫𝖬𝖭𝖮𝖯𝖰𝖱𝖲𝖳𝖴𝖵𝖶𝖷𝖸𝖹",
        "lower": "𝖺𝖻𝖼𝖽𝖾𝖿𝗀𝗁𝗂𝗃𝗄𝗅𝗆𝗇𝗈𝗉𝗊𝗋𝗌𝗍𝗎𝗏𝗐𝗑𝗒𝗓",
        "digits": "𝟢𝟣𝟤𝟥𝟦𝟧𝟨𝟩𝟪𝟫",
    },
    "sans-bold": {
        "upper": "𝗔𝗕𝗖𝗗𝗘𝗙𝗚𝗛𝗜𝗝𝗞𝗟𝗠𝗡𝗢𝗣𝗤𝗥𝗦𝗧𝗨𝗩𝗪𝗫𝗬𝗭",
        "lower": "𝗮𝗯𝗰𝗱𝗲𝗳𝗴𝗵𝗶𝗷𝗸𝗹𝗺𝗻𝗼𝗽𝗾𝗿𝘀𝘁𝘂𝘃𝘄𝘅𝘆𝘇",
        "digits": "𝟬𝟭𝟮𝟯𝟰𝟱𝟲𝟳𝟴𝟵",
    },
    "circled": {
        "upper": "ⒶⒷⒸⒹⒺⒻⒼⒽⒾⒿⓀⓁⓂⓃⓄⓅⓆⓇⓈⓉⓊⓋⓌⓍⓎⓏ",
        "lower": "ⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩ",
        "digits": "⓪①②③④⑤⑥⑦⑧⑨",
    },
    "fullwidth": {
        "upper": "ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺ",
        "lower": "ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ",
        "digits": "０１２３４５６７８９",
    },
    "parenthesized": {
        "upper": "🄐🄑🄒🄓🄔🄕🄖🄗🄘🄙🄚🄛🄜🄝🄞🄟🄠🄡🄢🄣🄤🄥🄦🄧🄨🄩",
        "lower": "⒜⒝⒞⒟⒠⒡⒢⒣⒤⒥⒦⒧⒨⒩⒪⒫⒬⒭⒮⒯⒰⒱⒲⒳⒴⒵",
        "digits": None,
    },
    "squared": {
        "upper": "🄰🄱🄲🄳🄴🄵🄶🄷🄸🄹🄺🄻🄼🄽🄾🄿🅀🅁🅂🅃🅄🅅🅆🅇🅈🅉",
        "lower": None,  # No lowercase squared
        "digits": None,
    },
    "negative-squared": {
        "upper": "🅰🅱🅲🅳🅴🅵🅶🅷🅸🅹🅺🅻🅼🅽🅾🅿🆀🆁🆂🆃🆄🆅🆆🆇🆈🆉",
        "lower": None,
        "digits": None,
    },
    "small-caps": {
        "upper": "ABCDEFGHIJKLMNOPQRSTUVWXYZ",  # Keep uppercase as-is
        "lower": "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ",
        "digits": None,
    },
}

# Upside down character mapping
UPSIDE_DOWN = {
    'a': 'ɐ', 'b': 'q', 'c': 'ɔ', 'd': 'p', 'e': 'ǝ', 'f': 'ɟ', 'g': 'ƃ',
    'h': 'ɥ', 'i': 'ᴉ', 'j': 'ɾ', 'k': 'ʞ', 'l': 'l', 'm': 'ɯ', 'n': 'u',
    'o': 'o', 'p': 'd', 'q': 'b', 'r': 'ɹ', 's': 's', 't': 'ʇ', 'u': 'n',
    'v': 'ʌ', 'w': 'ʍ', 'x': 'x', 'y': 'ʎ', 'z': 'z',
    'A': '∀', 'B': 'q', 'C': 'Ɔ', 'D': 'p', 'E': 'Ǝ', 'F': 'Ⅎ', 'G': '⅁',
    'H': 'H', 'I': 'I', 'J': 'ſ', 'K': 'ʞ', 'L': '˥', 'M': 'W', 'N': 'N',
    'O': 'O', 'P': 'Ԁ', 'Q': 'Q', 'R': 'ɹ', 'S': 'S', 'T': '⊥', 'U': '∩',
    'V': 'Λ', 'W': 'M', 'X': 'X', 'Y': '⅄', 'Z': 'Z',
    '0': '0', '1': 'Ɩ', '2': 'ᄅ', '3': 'Ɛ', '4': 'ㄣ', '5': 'ϛ',
    '6': '9', '7': 'ㄥ', '8': '8', '9': '6',
    '.': '˙', ',': "'", "'": ',', '"': '„', '!': '¡', '?': '¿',
    '[': ']', ']': '[', '(': ')', ')': '(', '{': '}', '}': '{',
    '<': '>', '>': '<', '&': '⅋', '_': '‾',
}

# Leetspeak mappings
LEET = {
    'a': '4', 'b': '8', 'c': '(', 'd': '|)', 'e': '3', 'f': '|=',
    'g': '9', 'h': '#', 'i': '1', 'j': '_|', 'k': '|<', 'l': '1',
    'm': '|V|', 'n': '|\\|', 'o': '0', 'p': '|>', 'q': '0_', 'r': '|2',
    's': '5', 't': '7', 'u': '|_|', 'v': '\\/', 'w': '\\/\\/', 'x': '><',
    'y': '`/', 'z': '2',
}

# Morse code
MORSE = {
    'a': '.-', 'b': '-...', 'c': '-.-.', 'd': '-..', 'e': '.', 'f': '..-.',
    'g': '--.', 'h': '....', 'i': '..', 'j': '.---', 'k': '-.-', 'l': '.-..',
    'm': '--', 'n': '-.', 'o': '---', 'p': '.--.', 'q': '--.-', 'r': '.-.',
    's': '...', 't': '-', 'u': '..-', 'v': '...-', 'w': '.--', 'x': '-..-',
    'y': '-.--', 'z': '--..',
    '0': '-----', '1': '.----', '2': '..---', '3': '...--', '4': '....-',
    '5': '.....', '6': '-....', '7': '--...', '8': '---..', '9': '----.',
    '.': '.-.-.-', ',': '--..--', '?': '..--..', "'": '.----.', '!': '-.-.--',
    '/': '-..-.', '(': '-.--.', ')': '-.--.-', '&': '.-...', ':': '---...',
    ';': '-.-.-.', '=': '-...-', '+': '.-.-.', '-': '-....-', '_': '..--.-',
    '"': '.-..-.', '$': '...-..-', '@': '.--.-.',
}

# Zalgo combining characters
ZALGO_UP = [
    '\u0300', '\u0301', '\u0302', '\u0303', '\u0304', '\u0305', '\u0306',
    '\u0307', '\u0308', '\u0309', '\u030A', '\u030B', '\u030C', '\u030D',
    '\u030E', '\u030F', '\u0310', '\u0311', '\u0312', '\u0313', '\u0314',
    '\u0315', '\u031A', '\u033D', '\u033E', '\u033F', '\u0340', '\u0341',
    '\u0342', '\u0343', '\u0344', '\u0346', '\u034A', '\u034B', '\u034C',
]
ZALGO_MID = [
    '\u0315', '\u031B', '\u0334', '\u0335', '\u0336', '\u0337', '\u0338',
]
ZALGO_DOWN = [
    '\u0316', '\u0317', '\u0318', '\u0319', '\u031C', '\u031D', '\u031E',
    '\u031F', '\u0320', '\u0321', '\u0322', '\u0323', '\u0324', '\u0325',
    '\u0326', '\u0327', '\u0328', '\u0329', '\u032A', '\u032B', '\u032C',
    '\u032D', '\u032E', '\u032F', '\u0330', '\u0331', '\u0332', '\u0333',
    '\u0339', '\u033A', '\u033B', '\u033C', '\u0345', '\u0347', '\u0348',
    '\u0349',
]


def apply_font(text: str, font_name: str) -> str:
    """Apply a unicode font to text."""
    if font_name not in FONTS:
        raise ValueError(f"Unknown font: {font_name}. Available: {list(FONTS.keys())}")
    
    font = FONTS[font_name]
    result = []
    
    for char in text:
        if char.isupper() and font["upper"]:
            idx = ord(char) - ord('A')
            if 0 <= idx < len(font["upper"]):
                result.append(font["upper"][idx])
            else:
                result.append(char)
        elif char.islower() and font["lower"]:
            idx = ord(char) - ord('a')
            if 0 <= idx < len(font["lower"]):
                result.append(font["lower"][idx])
            else:
                result.append(char)
        elif char.isdigit() and font.get("digits"):
            idx = ord(char) - ord('0')
            if 0 <= idx < len(font["digits"]):
                result.append(font["digits"][idx])
            else:
                result.append(char)
        else:
            result.append(char)
    
    return ''.join(result)


def reverse(text: str) -> str:
    """Reverse the text."""
    return text[::-1]


def upside_down(text: str) -> str:
    """Flip text upside down."""
    result = []
    for char in text:
        result.append(UPSIDE_DOWN.get(char, char))
    return ''.join(reversed(result))


def leetspeak(text: str) -> str:
    """Convert to leetspeak."""
    result = []
    for char in text.lower():
        result.append(LEET.get(char, char))
    return ''.join(result)


def spongebob(text: str) -> str:
    """aLtErNaTiNg CaSe (mocking spongebob)."""
    result = []
    upper = False
    for char in text:
        if char.isalpha():
            result.append(char.upper() if upper else char.lower())
            upper = not upper
        else:
            result.append(char)
    return ''.join(result)


def zalgo(text: str, intensity: int = 3) -> str:
    """Add zalgo/glitch effect to text."""
    result = []
    for char in text:
        result.append(char)
        if char.isalnum():
            # Add combining characters
            for _ in range(random.randint(1, intensity)):
                result.append(random.choice(ZALGO_UP))
            for _ in range(random.randint(0, intensity // 2)):
                result.append(random.choice(ZALGO_MID))
            for _ in range(random.randint(1, intensity)):
                result.append(random.choice(ZALGO_DOWN))
    return ''.join(result)


def morse(text: str) -> str:
    """Convert to morse code."""
    result = []
    for char in text.lower():
        if char == ' ':
            result.append('/')
        elif char in MORSE:
            result.append(MORSE[char])
    return ' '.join(result)


def binary(text: str) -> str:
    """Convert to binary."""
    return ' '.join(format(ord(char), '08b') for char in text)


def strikethrough(text: str) -> str:
    """Add strikethrough effect."""
    return ''.join(char + '\u0336' for char in text)


def underline(text: str) -> str:
    """Add underline effect."""
    return ''.join(char + '\u0332' for char in text)


def double_underline(text: str) -> str:
    """Add double underline effect."""
    return ''.join(char + '\u0333' for char in text)


def bubble(text: str) -> str:
    """Convert to bubble text (circled letters)."""
    return apply_font(text, "circled")


def square(text: str) -> str:
    """Convert to squared letters."""
    return apply_font(text.upper(), "squared")


def vaporwave(text: str) -> str:
    """Ｖａｐｏｒｗａｖｅ ａｅｓｔｈｅｔｉｃ (fullwidth with spaces)."""
    result = apply_font(text, "fullwidth")
    # Add spaces between characters for extra aesthetic
    return ' '.join(result)


def scramble(text: str) -> str:
    """Randomly scramble letters within words (keep first/last)."""
    words = text.split()
    result = []
    for word in words:
        if len(word) <= 3:
            result.append(word)
        else:
            middle = list(word[1:-1])
            random.shuffle(middle)
            result.append(word[0] + ''.join(middle) + word[-1])
    return ' '.join(result)


def uwu(text: str) -> str:
    """UwU-ify text."""
    text = text.lower()
    # Replace common patterns
    text = text.replace('r', 'w').replace('l', 'w')
    text = text.replace('ove', 'uv')
    text = text.replace('th', 'd')
    # Add occasional faces
    words = text.split()
    for i in range(len(words)):
        if random.random() < 0.2:
            words[i] += random.choice([' uwu', ' owo', ' >w<', ' :3'])
    return ' '.join(words)


def pig_latin(text: str) -> str:
    """Convert to pig latin."""
    vowels = 'aeiouAEIOU'
    words = text.split()
    result = []
    
    for word in words:
        # Keep punctuation
        punct = ''
        clean_word = word
        while clean_word and not clean_word[-1].isalnum():
            punct = clean_word[-1] + punct
            clean_word = clean_word[:-1]
        
        if not clean_word:
            result.append(word)
            continue
            
        if clean_word[0] in vowels:
            result.append(clean_word + 'yay' + punct)
        else:
            # Find first vowel
            for i, char in enumerate(clean_word):
                if char in vowels:
                    result.append(clean_word[i:] + clean_word[:i] + 'ay' + punct)
                    break
            else:
                result.append(clean_word + 'ay' + punct)
    
    return ' '.join(result)


# Registry of all transforms
TRANSFORMS = {
    "reverse": reverse,
    "upside-down": upside_down,
    "leet": leetspeak,
    "spongebob": spongebob,
    "zalgo": lambda t: zalgo(t, 3),
    "zalgo-mild": lambda t: zalgo(t, 1),
    "zalgo-intense": lambda t: zalgo(t, 6),
    "morse": morse,
    "binary": binary,
    "strikethrough": strikethrough,
    "underline": underline,
    "double-underline": double_underline,
    "bubble": bubble,
    "square": square,
    "vaporwave": vaporwave,
    "scramble": scramble,
    "uwu": uwu,
    "pig-latin": pig_latin,
    # Font transforms
    "bold": lambda t: apply_font(t, "bold"),
    "italic": lambda t: apply_font(t, "italic"),
    "bold-italic": lambda t: apply_font(t, "bold-italic"),
    "script": lambda t: apply_font(t, "script"),
    "bold-script": lambda t: apply_font(t, "bold-script"),
    "fraktur": lambda t: apply_font(t, "fraktur"),
    "double-struck": lambda t: apply_font(t, "double-struck"),
    "monospace": lambda t: apply_font(t, "monospace"),
    "sans": lambda t: apply_font(t, "sans"),
    "sans-bold": lambda t: apply_font(t, "sans-bold"),
    "circled": lambda t: apply_font(t, "circled"),
    "fullwidth": lambda t: apply_font(t, "fullwidth"),
    "parenthesized": lambda t: apply_font(t, "parenthesized"),
    "squared": lambda t: apply_font(t.upper(), "squared"),
    "negative-squared": lambda t: apply_font(t.upper(), "negative-squared"),
    "small-caps": lambda t: apply_font(t, "small-caps"),
}


def list_transforms() -> list[str]:
    """Return list of available transform names."""
    return sorted(TRANSFORMS.keys())


def transform(text: str, transform_name: str) -> str:
    """Apply a named transform to text."""
    if transform_name not in TRANSFORMS:
        raise ValueError(f"Unknown transform: {transform_name}. Available: {list_transforms()}")
    return TRANSFORMS[transform_name](text)
