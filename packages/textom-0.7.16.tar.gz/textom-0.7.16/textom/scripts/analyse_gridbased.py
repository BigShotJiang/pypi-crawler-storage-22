import glob
import os
import shutil
import sys

os.environ["MKL_NUM_THREADS"] = "1" 
os.environ["NUMEXPR_NUM_THREADS"] = "1" 
os.environ["OMP_NUM_THREADS"] = "1"
# matplotlib.use('tkagg')
from importlib import reload  # this is to reload
from time import time
from typing import Optional, Union

import h5py
import hdf5plugin
import imageio.v3 as iio
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import orix.quaternion.symmetry as osym
from numba import njit, prange

import textom.src.analysis.orix_plugins as orx
import textom.src.handle as hdl
import textom.src.misc as msc
import textom.src.model.rotation as rot
import textom.src.model.symmetries as sym
import textom.src.odf.gridbased as grd
import textom.src.optimization.optimizer as opt
import textom.src.plotting as plot
from textom.config import data_type
from textom.src.model.model_textom import model_textom, rotate_difflets_stack
from textom.src.optimization.fitting import fitting

sample_dir = '/dataSATA/data_synchrotron/esrf_id13_2023_09_ihmi1513_biomorphs/ihmi1531/id13/20230914/PROCESSED_DATA/integ/helix_s7'
mod = model_textom( sample_dir )
fit = fitting( sample_dir, mod )

if not os.path.isfile(os.path.join(sample_dir,'analysis','difflets_gridbased.h5')):
    # get rotation group quaternions
    gen = sym.generators(mod.symmetry)
    Q_gen = rot.QfromOTP(gen)
    Q_group = rot.generate_group(Q_gen)

    # sample rotation quaternions
    Qs = rot.QfromOTP( mod.Gs )

    # sample SO(3) for grid-based functions
    resolution = 25 # degree 
    pg = getattr( osym, sym.get_SFnotation( mod.symmetry ) )
    Q_grid = rot.get_sample_fundamental(
                resolution,
                point_group= pg,
                method='cubochoric'
        ).data.astype(data_type)

    # print('regrouping single crystal patterns')
    # # group single crystal images into peak regions
    # Isc_grouped = np.empty((mod.Isc.shape[0], *fit.detShape), data_type)
    # q_det = mod.Qq_det.reshape(mod.detShape)[:,0]
    # Isc = mod.Isc.reshape(mod.Isc.shape[0],*mod.detShape) / mod.Isc.max() #renormalize to avoid overflow
    # for k in range(Isc.shape[0]):
    #     dlet_tmp = np.empty( fit.detShape, data_type)
    #     for r, reg in enumerate(fit.peak_reg):
    #         mask_reg = ((q_det >= reg[0]) & (q_det <= reg[1]))
    #         dlet_tmp[r] = Isc[k][mask_reg].sum(axis=0)
    #     if np.any(np.isnan(dlet_tmp)):
    #         stop=1
    #     Isc_grouped[k] = dlet_tmp
    #
    with h5py.File(os.path.join(sample_dir,'analysis','difflets_gridbased_.h5'),'r') as hf:
        Isc_grouped = hf['Isc_grouped'][()]

    print('calculating rotated diffractlets')
    # make fisher distribution diffractlets
    kappa = 250
    Qc = rot.QfromOTP( mod.Gc )
    t0=time()
    difflets_rot = grd.get_rotated_diffractlets(Qc, Qs, Q_grid, 
                                                Q_group, kappa, Isc_grouped, fit.detShape )
    print(f'\ttook {time()-t0} s')

    # save stuff
    with h5py.File(os.path.join(sample_dir,'analysis','difflets_gridbased.h5'),'w') as hf:
        hf.create_dataset('concentration_parameter', data=kappa)
        hf.create_dataset('grid_quaternions', data=Q_grid)
        hf.create_dataset('sample_quaternions', data=Qs)
        hf.create_dataset('crystal_quaternions', data=Qc)
        hf.create_dataset('difflets_rot', data=difflets_rot)
        hf.create_dataset('Isc_grouped', data=Isc_grouped)

else:
    # load stuff
    with h5py.File(os.path.join(sample_dir,'analysis','difflets_gridbased.h5'),'r') as hf:
        Q_grid = hf['grid_quaternions'][()]
        difflets_rot = hf['difflets_rot'][()]
        kappa = hf['concentration_parameter'][()]
        Qs = hf['sample_quaternions'][()]

# set up 
fit.C = np.zeros((mod.x_p.shape[0], Q_grid.shape[0]), data_type)
fit.difflets_rot_masked = difflets_rot.reshape( (Qs.shape[0], Q_grid.shape[0], np.prod(fit.detShape)) )[:,:,fit.mask_detector]

# Optimisation
# ## test stepsize
fit.choose_projections(mode='notilt')#'full')#
loss0 = fit.loss(fit.C)
grad = fit.grad_full(fit.C)
# calculate inverse lipschitz constants
L = fit.lipschitz().reshape((fit.C.shape[0],1))
L[ L < 1e-4*L.max() ] = 0.
invL = np.zeros_like(L)
invL[L!=0] = 2/L[L!=0]
gam = np.tile( invL, (1,fit.C.shape[1]) )
direction = - gam * grad
# # this could be built into the optimizer #
step_size_init = 1e-5#5e-8
step_size, best_loss = opt.line_search(fit.loss,fit.C,direction,step_size_init)
# should i take stepsize *2 ? as the factor 2 in gam?
# c_next = fit.C + step_size * direction
# loss_next=fit.loss(c_next)
# print(loss0/loss_next)
# ##
fit.C, opt_result = opt.optimize(fit, 2, 
         alg='quadratic', # simple
         tol=1e-5, minstep=1e-9, itermax=200,
         step_size_0=step_size,
         project_all=True,
         )
os.makedirs(os.path.join(sample_dir,'analysis','fits'), exist_ok=True)
hdl.save_dict_to_h5( opt_result, os.path.join(sample_dir,'analysis','fits','gridbased'+opt_result['resname']))
plot.loss(opt_result['loss'],opt_result['resname'])
#
plot.projection_residuals( fit )
#
print('Index\tInner\tOuter')
for g in range(mod.Omega.size):
    print(f'{g}\t{np.round(mod.Omega[g]*180/np.pi,1)}\t{np.round(mod.Kappa[g]*180/np.pi,1)}')
#
g=0
title = f'Sum of Residuals\nProjection {g}: kap {np.round(mod.Kappa[g]*180/np.pi,1)}, ome {np.round(mod.Omega[g]*180/np.pi,1)}'
plot.image_residuals( fit, g, mod.fov, title=title )
#
g=0
title = f'Projection {g}: kap {np.round(mod.Kappa[g]*180/np.pi,1)}, ome {np.round(mod.Omega[g]*180/np.pi,1)}'
ori_dat, ori_fit = fit.check_orientations(g)
fov = mod.fov
plot.compare_projection_ori( 
    ori_dat.reshape((ori_dat.shape[0],*fov)), 
    ori_fit.reshape((ori_dat.shape[0],*fov)),
    fit.q, title=title, )
#

# ## this could be done after fitting 0 order
# fit.C = np.full(np.flip(fit.C.shape), fit.C.mean(axis=1)).T
# #
# fit.C = np.full(fit.C.shape, 0, np.float32)

# load an optimization
# opt_file = 'gridbasedopt_helix_s7_C_nmax0_2025_05_15_02h56.h5'
opt_file = 'gridbasedopt_helix_s7_C_nmax0_2025_05_15_16h33.h5'
with h5py.File(os.path.join(sample_dir,'analysis','fits',opt_file),'r') as hf:
    fit.C = hf['c'][()]
#
    
# plot odf
Qc = rot.QfromOTP( mod.Gc )
gen = sym.generators(mod.symmetry)
Q_gen = rot.QfromOTP(gen)
Q_group = rot.generate_group(Q_gen)
#
n_highest = np.argmax(fit.C.sum(axis=1))
C_vox = fit.C[n_highest]#[mod.mask_voxels][0]
odf = np.zeros_like(Qc[:,0])
for c in range(C_vox.size):
    if C_vox[c] > C_vox.max()/100:
        odf += grd.fisher_SO3( Qc, Q_grid[c], kappa, Q_group)
orx.plot_odf(mod.Gc, odf, mod.symmetry, num_samples=1000)
# concentrate more on peaks
bg = odf.max()*0.4
odf -= bg
odf[odf<0] = 0
orx.plot_odf(mod.Gc, odf, mod.symmetry, num_samples=1000)
#

# get maximum orientations
####### simple ##########
ig_max = np.argmax( fit.C[mod.mask_voxels], axis=1 )
Q_pref = np.array([Q_grid[i] for i in ig_max])
####### more elaborate ############ careful, slow!!
Q_pref = grd.get_odf_max_orientations( fit.C, Qc, Q_grid, Q_group, kappa )
#
G_pref = rot.OTPfromQ(Q_pref)
A_pref,B_pref,C_pref = mod.abc_pref_sample(G_pref)
# orient everything up ###
for g in range(Q_pref.shape[0]):
    if C_pref[g,2] < 0:
        C_pref[g] *= -1
        A_pref[g] *= -1
        B_pref[g] *= -1
###

# make results file and output
scaling = fit.C[mod.mask_voxels].sum(axis=1)
results = {}
results['scaling'] = mod.insert_sparse_tomogram(scaling)
results['g_pref'] = mod.insert_sparse_tomogram(G_pref)
results['a_pref'] = mod.insert_sparse_tomogram(A_pref)
results['b_pref'] = mod.insert_sparse_tomogram(B_pref)
results['c_pref'] = mod.insert_sparse_tomogram(C_pref)
results['inv_pf'] = orx.inverse_pf_stack(results['g_pref'], mod)
print("\tAdded to results: 'g_pref', 'a_pref', 'b_pref', 'c_pref', 'inv_pf'")

with h5py.File(os.path.join(sample_dir,'analysis','projectors.h5'), 'r') as hf:
    nVox = hf['nVox'][()]
title = os.path.basename(os.path.dirname(sample_dir))
types, names = [], []
res_name = f'resultsPV_{msc.timestring()}'
with h5py.File( 
    os.path.join(sample_dir,'results',f'{res_name}.h5'), 'w' ) as hf:
    hf.create_dataset('title', data=title)
    for key, value in results.items():
        if isinstance(value,np.ndarray):
            if value.ndim == 3:
                types.append('Scalar')
                names.append(key)
                hf.create_dataset( key, data = value.transpose((2,1,0)) )
            elif (value.ndim == 4 and not key == 'g_pref'):
                types.append('Vector')
                names.append(key)
                hf.create_dataset( key, data = value.transpose((2,1,0,3)) )
print(f'\tCreated results file: {res_name}')
hdl.write_xdmf_reader(
    os.path.join(sample_dir,'results',f'{res_name}.xdmf'),
    os.path.join(sample_dir,'results',f'{res_name}.h5'),
    (nVox[2],nVox[1],nVox[0]), names, types
)

stop=1
