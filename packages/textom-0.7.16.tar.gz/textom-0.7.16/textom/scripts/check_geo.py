from textom.src.integration import pyfai_plugins as pyf

path_data = 'textom/input/test_data/al2o3_al2o3_m290/al2o3_al2o3_m290.h5'
data_sub_path = '2.1'
frame = 0
geo = 'textom/input/geometry.py'
intpar = 'textom/input/test_data/integration_parameters.py'

pyf.check_detector_geometry(intpar,path_data,data_sub_path,frame,geo)