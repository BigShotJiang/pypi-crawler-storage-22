import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d.art3d import Poly3DCollection


def is_inside_wedge(x, y, z, tip, axis, alpha, theta_min, theta_max, origin_vec, pos_dir_vec):
    """
    Check if a point (x, y, z) is inside the wedge of a cone.
    """
    # Shift coordinates to cone's tip
    x_shift, y_shift, z_shift = x - tip[0], y - tip[1], z - tip[2]
    
    # Project point onto the cone's axis
    dot_product = x_shift * axis[0] + y_shift * axis[1] + z_shift * axis[2]
    
    # Compute radial distance from the axis
    projected = np.array([dot_product * axis[i] for i in range(3)])
    radial_vector = np.array([x_shift, y_shift, z_shift]) - projected
    r = np.linalg.norm(radial_vector)
    h = np.linalg.norm(projected)
    
    # Check if point is within cone's angle
    if h <= 0 or r / h > np.tan(alpha):
        return False
    
    # Compute azimuthal angle relative to origin_vec and pos_dir_vec
    radial_unit = radial_vector / (np.linalg.norm(radial_vector) + 1e-10)
    theta = np.arctan2(np.dot(radial_unit, pos_dir_vec), np.dot(radial_unit, origin_vec))
    if theta < 0:
        theta += 2 * np.pi
    
    return theta_min <= theta <= theta_max

def integrate_wedge(grid, x_vals, y_vals, z_vals, tip, axis, alpha, theta_min, theta_max, origin_vec, pos_dir_vec):
    """
    Perform numerical integration over a wedge of a cone inside a 3D grid.
    """
    integral = 0.0
    dx = x_vals[1] - x_vals[0]
    dy = y_vals[1] - y_vals[0]
    dz = z_vals[1] - z_vals[0]
    volume_element = dx * dy * dz
    
    for i, x in enumerate(x_vals):
        for j, y in enumerate(y_vals):
            for k, z in enumerate(z_vals):
                if is_inside_wedge(x, y, z, tip, axis, alpha, theta_min, theta_max, origin_vec, pos_dir_vec):
                    integral += grid[i, j, k] * volume_element
    
    return integral

def plot_wedge(tip, axis, alpha, theta_min, theta_max, origin_vec, pos_dir_vec):
    """
    Plot the wedge of a cone in 3D.
    """
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    
    # Generate cone surface
    h = 5  # Arbitrary height
    r = h * np.tan(alpha)
    
    theta_vals = np.linspace(theta_min, theta_max, 30)
    z_vals = np.linspace(0, h, 10)
    
    for z in z_vals:
        r_z = z * np.tan(alpha)
        x = tip[0] + r_z * np.cos(theta_vals)
        y = tip[1] + r_z * np.sin(theta_vals)
        ax.plot(x, y, tip[2] + z, 'b')
    
    ax.scatter(*tip, color='r', label='Tip')
    ax.quiver(*tip, *axis, length=2, color='g', label='Axis')
    
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    plt.legend()
    plt.show()

# Example usage
x_vals = np.linspace(-5, 5, 50)
y_vals = np.linspace(-5, 5, 50)
z_vals = np.linspace(-5, 5, 50)
grid = np.random.rand(50, 50, 50)  # Example 3D data

tip = (0, 0, 0)  # Tip of the cone
axis = (1, 0, 0)  # Cone axis as a unit vector
alpha = np.pi / 6  # Opening angle of the cone
theta_min = np.pi / 4 # Starting angle of the wedge
theta_max = 2*np.pi / 4  # Ending angle of the wedge
origin_vec = (0, 0, 1)  # Reference origin direction (must be perpendicular to axis)
pos_dir_vec = (0, -1, 0)  # Positive direction for measuring theta (perpendicular to axis and origin_vec)

result = integrate_wedge(grid, x_vals, y_vals, z_vals, tip, axis, alpha, theta_min, theta_max, origin_vec, pos_dir_vec)
print("Integral over the wedge of a cone:", result)

# Plot the wedge
plot_wedge(tip, axis, alpha, theta_min, theta_max, origin_vec, pos_dir_vec)
