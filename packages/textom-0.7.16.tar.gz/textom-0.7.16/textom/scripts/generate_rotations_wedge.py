#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 25 20:14:29 2021

@author: tilman & Moritz

originally written for defining rotations at ID1
here it is adapted for 15 with Isabella's stage
"""

import numpy as np

################ input ###################

title = 'biomorph_blobb'
# total number of projections:
N_tot = 263
# zero tilt angle number of projections:
N_0 = 100 # int(N_tot/3)
# Number of tilt angles (including 0)
n_tilts = 5
# Starting tilt angle (kappa)
tilt_start = 0.0
# Ending tilt angle (kappa)
tilt_end  = 45.
# Tilt order scrambled mode (e.g. [0, 20, 40, 30, 10])
scram = True
# Add a scan over zero tilt and rotation after each tilt angle
check_zero = True
# cut out wedges:
avoid_rot = [[0,10],[180,190]]
# define z_position per tilt angle:
z_tilt = [1.0, 1.1, 1.2, 1.3, 1.4]

#Diameter of your sample in um (to estimate a reasonable sampling criterion)
dia = 100
#resolution aim (should somewhat correlate with beam size) in um
reso = 0.5

### for estimating time (all in seconds)
#estimated time per scan 
t_scan = 146
#estimated time per pre-alignment map
tmap_align = 0
# movement overhead for one tilt angle
t_tilt = 10
# movement overhead for one rot angle
t_rot = 5

#############################################
#The theoretical sampling
theo_N0 = dia/reso
print('Theoretical N0: %u, used: %u' % (theo_N0, N_0) )

fid = open( 'rotations_'+title+'.txt', 'w') 
tilt_angles = np.linspace(tilt_start, tilt_end, n_tilts) # equally spaced tilt-angles

# decide order of measurement
if scram:
    tilt_order = np.concatenate((np.arange(0,n_tilts,2),np.arange(n_tilts-1,0,-2)))
else:
    tilt_order = np.arange(n_tilts)#[::-1]
# tilt_order = [8,7,6,5,4,3,2,1,0,9]

# get rotation angles so we have equally spaced projections
weights = np.cos( tilt_angles[1:]*np.pi/180 )
n_rot_tilted = np.ceil( ( N_tot - N_0 ) * weights/weights.sum() ).astype(int)

rot_angle_list = [] # list of rotation angles [[angles at tilt 0],[at tilt 1],etc]
idx = 0 # total projection index (output first column)
c = 1 # this is needed for adding the safety check scan
for k in range(0, int(n_tilts) ):    
    tilt_i = tilt_angles[tilt_order[k]] # tilt angle in chosen order
    z_tilt_i = z_tilt[tilt_order[k]] # z_start for tilt angle k
    
    if tilt_i == 0.0:
        max_angle = 180
        n_rot = N_0 # number of rotation angles at this tilt
    else:
        max_angle = 360
        n_rot = n_rot_tilted[ tilt_order[k]-1 ] # number of rotation angles at this tilt
    
    delta_rot = max_angle/n_rot
    if np.mod(k,2) != 0:
        zero_angle = delta_rot/2.0
    else:
        zero_angle = 0
    
    # list of rotation angles at this tilt:
    rot_angles = np.linspace(zero_angle, max_angle, n_rot, endpoint=False)
    # cut out wedges
    for wedge in avoid_rot:
        rot_angles = np.delete( rot_angles,
            np.where((rot_angles > wedge[0]) & (rot_angles < wedge[1])))
    rot_angle_list.append(rot_angles)    

    print('tilt angle: %.3f °, rot angle increment: %.3f °, number of rotations: %d' % (tilt_i, delta_rot, n_rot) )
    print(np.round(rot_angles, 3))

    # write a file that can be copied into the ID15 code:
    for k in range(rot_angles.shape[0]):
        fid.write(f'{idx+k:d}, {tilt_i:.1f}, {rot_angles[k]:.3f}, {z_tilt_i:.3f}\n')
    
    if check_zero: # add another scan at tilt and rot 0 after each tilt
        fid.write(f'{idx+k+1:d}, {0:.1f}, {0:.3f}, {z_tilt[0]:.3f}\n')
        # fid.write('%u, %u, %.3f\n' % (idx+k+1, 0, 0))
        c = 2
        
    idx = idx + k + c

#and a little time estimation section
count = 0
for listElem in rot_angle_list:
    count += len(listElem)
t_total = count* ( t_scan+tmap_align+t_rot ) + t_tilt*len(tilt_angles) 
  
print('Total No of angles: %u, projections: %u, rotation damage checks: %u' % (
    count, count-check_zero*n_tilts, check_zero*n_tilts))
print('Total time: %.2f h' % (t_total/3600))            
