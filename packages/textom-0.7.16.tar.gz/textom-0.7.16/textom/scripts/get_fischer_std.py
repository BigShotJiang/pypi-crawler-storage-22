import glob
import os
import shutil
import sys

os.environ["MKL_NUM_THREADS"] = "1" 
os.environ["NUMEXPR_NUM_THREADS"] = "1" 
os.environ["OMP_NUM_THREADS"] = "1"
# matplotlib.use('tkagg')
from importlib import reload  # this is to reload
from time import time
from typing import Optional, Union

import h5py
import hdf5plugin
import imageio.v3 as iio
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import orix.quaternion.symmetry as osym
from numba import njit, prange

import textom.src.analysis.orix_plugins as orx
import textom.src.handle as hdl
import textom.src.misc as msc
import textom.src.model.rotation as rot
import textom.src.model.symmetries as sym
import textom.src.odf.gridbased as grd
import textom.src.optimization.optimizer as opt
import textom.src.plotting as plot
from textom.config import data_type
from textom.src.model.model_textom import model_textom, rotate_difflets_stack
from textom.src.optimization.fitting import fitting

sample_dir = '/Users/moritz/Documents/papers/biomorphs/helix_s7_textom/'
mod = model_textom( sample_dir )
gen = sym.generators(mod.symmetry)
Q_gen = rot.QfromOTP(gen)
Q_group = rot.generate_group(Q_gen)

kappas = np.linspace(10, 1000, num=100)
stds = []
for k in kappas:
    odf = grd.fisher_SO3( rot.QfromOTP(mod.Gc), np.array([1,0,0,0]), k, Q_group  )
    stds.append(np.sqrt( ( odf * mod.Gc[:,0]**2 ) @ mod.dV / (odf @ mod.dV) ))

plt.figure()
plt.plot(kappas, np.array(stds)*180/np.pi)
plt.title('Concentration parameter vs Standard deviation for Fischer distribution in SO(3)')
plt.xlabel('kappa')
plt.ylabel('std')
plt.show()