import csv
import re

import requests
from bs4 import BeautifulSoup
from selenium import webdriver


def extract_reflection_conditions(url):
    # load html content from the page
    driver = webdriver.Firefox()
    driver.get(url)
    html = driver.page_source  # Get rendered HTML from Selenium
    soup = BeautifulSoup(html, "html.parser")
    driver.quit()

    # Extract last columns from all tables from there
    extracted_data = []
    tables = soup.find_all("table")
    for table in tables:
    # if table:
        rows = table.find_all("tr")
        for row in rows:
            cols = row.find_all("td")  # Get all columns
            if cols:
                last_col = cols[-1].text.strip()  # Extract last column
                extracted_data.append(last_col)

    # filter out reflection conditions
    pattern = re.compile(r"[h0][k0][l0]:")  # Matches 'hkl:', 'h0l:', '00l:', etc.
    filtered_data = [entry for entry in extracted_data if pattern.search(entry)]
    filtered_data = [entry.replace('\xa0','') for entry in filtered_data]
    
    # divide into indiviual conditions:
    divided_data = []
    for entry in filtered_data:
        while entry.count(':') > 1:
            splitpos = entry.find(':',4) - 3
            divided_data.append( entry[:splitpos] )
            entry = entry[splitpos:]
        divided_data.append(entry)

    # remove duplicates:
    reflection_conditions = list(set(divided_data))

    # tables = soup.find_all("table")

    # space_group = soup.find('h1').text.strip()  # Assuming space group name is in h1
    # conditions = []
    
    # for table in soup.find_all('table'):
    #     rows = table.find_all('tr')
    #     for row in rows:
    #         cols = row.find_all('td')
    #         if len(cols) > 1 and 'Reflection conditions' in cols[0].text:
    #             conditions.append(cols[1].text.strip())
    
    return reflection_conditions

def main():
    with open('textom/ressources/reflection_conditions.csv', 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["Space Group", "Reflection Conditions"])
        for n_sg in range(1,231):
            url = f'https://onlinelibrary.wiley.com/iucr/itc/Ac/ch2o3v0001/sgtable2o3o{str(n_sg).zfill(3)}/'

            conditions = extract_reflection_conditions(url)
            writer.writerow([n_sg, '; '.join(conditions)])
            print(f"Extracted: {n_sg}")

if __name__ == "__main__":
    main()
