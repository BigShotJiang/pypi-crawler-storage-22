import textom.textom as txt

sample_dir = '/Users/moritz/Documents/papers/biomorphs/helix_s7_textom/'
txt.set_path(sample_dir)

txt.integration_test(dset_no=0)