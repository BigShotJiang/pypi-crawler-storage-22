import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D, art3d


def extract_wireframe_collection(ax):
    """
    Extracts a wireframe collection from an Axes3D object.
    
    Parameters:
    ax (mpl_toolkits.mplot3d.Axes3D): The original axes containing the wireframe.
    
    Returns:
    list: A list of Line3DCollection objects (wireframe lines).
    """
    wireframe_collections = []
    
    for collection in ax.collections:
        if isinstance(collection, art3d.Line3DCollection):  # Check if it's a wireframe
            wireframe_collections.append(collection)
    
    if not wireframe_collections:
        print("No wireframe collection found.")
        return None
    
    return wireframe_collections

def transfer_wireframe_collection(wireframe_collections, ax_new):
    """
    Transfers extracted wireframe collections to a new Axes3D object.
    
    Parameters:
    wireframe_collections (list): List of extracted Line3DCollection objects.
    ax_new (mpl_toolkits.mplot3d.Axes3D): The new axis to transfer the wireframe to.
    """
    if wireframe_collections is None:
        print("No valid wireframe collection to transfer.")
        return

    for collection in wireframe_collections:
        # Clone the collection and add it to the new axis
        prop = collection.properties()
        rm_list = ["segments","children","fill","tightbbox",
                   'transformed_clip_path_and_affine','transforms',
                   'window_extent']
        for el in rm_list:
            prop.pop(el,None)
        new_collection = type(collection)(collection.get_segments(), **prop)
        # new_collection.set_segments(collection.get_segments())
        ax_new.add_collection3d(new_collection)

# # --- Example Usage ---
# # Step 1: Create Original Wireframe
# fig1 = plt.figure(figsize=(6, 6))
# ax1 = fig1.add_subplot(111, projection='3d')

# # Create a wireframe using meshgrid
# X = np.linspace(-1, 1, 10)
# Y = np.linspace(-1, 1, 10)
# X, Y = np.meshgrid(X, Y)
# Z = np.sin(np.pi * X) * np.cos(np.pi * Y)  # Example surface

# # Plot wireframe in the first figure
# ax1.plot_wireframe(X, Y, Z, color='r')

# plt.show()

import orix.quaternion.symmetry as osym  # import C1, Oh, D2
from orix.quaternion import Misorientation, Orientation, OrientationRegion, Rotation

from textom.textom import rot, sym

# plot a single piont in a unit cell with vector pointing to it
axan = np.array([[np.pi/2,np.pi/4,np.pi/4]])
symmetries = ['1','222','6','432']#

fig = plt.figure(figsize=(6, 6))
ax = fig.add_subplot(111, projection='3d')

k=1
for symmetry in symmetries[:1]:
    quat = rot.QfromOTP(axan)
    axan_vec = quat[0,1:]/np.linalg.norm(quat[0,1:]) * axan[0,0]
    oror = Orientation(Rotation(quat))
    oror.symmetry = getattr( osym, sym.get_SFnotation(symmetry))
    # f.add_axes([0.1, 0.1, 0.8, 0.8])
    fn = oror.scatter(return_figure=True)
    k+=1

    wireframe_collections = extract_wireframe_collection(plt.gca())

    transfer_wireframe_collection(wireframe_collections, ax)

    plt.show()
