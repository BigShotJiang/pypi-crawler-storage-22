import matplotlib.pyplot as plt
import numpy as np
from scipy.integrate import quad


def gaussian(x, sigma=1):
    """The target Gaussian function: e^(-x^2 / (2*sigma^2))"""
    return 1/(np.sqrt(2*np.pi)*sigma)*np.exp(-x**2 / (2 * sigma**2))

def fourier_coefficient(n, L, sigma):
    """Computes the Fourier coefficients numerically"""
    a_n = quad(lambda x: gaussian(x, sigma) * np.cos(n * np.pi * x / L), -L, L)[0] / L
    b_n = quad(lambda x: gaussian(x, sigma) * np.sin(n * np.pi * x / L), -L, L)[0] / L
    return a_n, b_n

def fourier_series(x, N, L, sigma):
    """Computes the Fourier series approximation up to order N"""
    a_0 = quad(lambda x: gaussian(x, sigma), -L, L)[0] / (2 * L)  # DC component
    series = a_0
    
    for n in range(1, N+1):
        a_n, b_n = fourier_coefficient(n, L, sigma)
        series += a_n * np.cos(n * np.pi * x / L) + b_n * np.sin(n * np.pi * x / L)
    
    return series

def plot_gaussian_fourier(L=2, sigma=0.2, orders=[1, 3, 5, 10]):
    """Plots the Gaussian function and its Fourier series approximations"""
    x = np.linspace(-L, L, 400)
    
    plt.figure(figsize=(8, 6))
    plt.plot(x, gaussian(x, sigma), 'k-', label="Gaussian", linewidth=2)
    
    for N in orders:
        plt.plot(x, fourier_series(x, N, L, sigma), label=f"Fourier N={N}")

    plt.xlabel("φ [° ]")
    plt.ylabel("f(φ)")
    plt.title(f"Fourier Series Approximation of a Gaussian (std={sigma} °)")
    plt.xlim((-L,L))
    plt.legend()
    plt.grid()
    plt.gca().set_axisbelow(True)

def plot_gaussian_bar(L=2, sigma=0.2, sampling=50):
    """Plots the Gaussian function and its Fourier series approximations"""
    x = np.linspace(-L, L, 400)
    
    plt.figure(figsize=(8, 6))
    plt.plot(x, gaussian(x, sigma), 'k-', label="Gaussian", linewidth=2)
    
    x_bar =  np.linspace(-L, L, sampling)
    plt.bar(x_bar, gaussian(x_bar, sigma), width=(0.9*2*L/sampling),
            label="Discretization")
    plt.xlabel("φ [° ]")
    plt.ylabel("f(φ)")
    plt.title(f"Discretization of a Gaussian (std={sigma} °)")
    plt.legend()
    plt.xlim((-L,L))
    plt.grid()
    plt.gca().set_axisbelow(True)

# Run the function
L = 180
sigma = 20
binning = 50
plot_gaussian_fourier(L,sigma)
plot_gaussian_bar(L,sigma,binning)
plt.show()
