# from ase.io import read # for reading .cif files
import importlib as imp  # for reading input files
import os
import shutil
import sys
from time import time

import h5py
import matplotlib.pyplot as plt
import numpy as np
import orix.quaternion.symmetry as osym
from numba import njit, prange
from orix.quaternion import Orientation, Rotation
from orix.sampling import get_sample_fundamental
from scipy import ndimage

import textom.src.model.rotation as rot
import textom.src.model.symmetries as sym
from textom.src.plotting import set_axes_equal_3d

data_type=np.float32

def define_angles(sampling, symmetry, dchi ):
    """Defines the grid of angles for crystallite rotation

    Attributes created
    ------------
    Gc : 2D ndarray, float
        register of axis-angle rotations
        dim: 0: rotation index, 1: [omega, theta, phi]
    dV : 1D ndarray, float
        volume element for integrating over the odf
        dim: 0: rotation index
    V_fz : float
        volume of the fundamental zone
    """
    try:
        if sampling=='cubochoric':
            pg = getattr( osym, sym.get_SFnotation( symmetry ) )
            rot_orix = get_sample_fundamental(
                    dchi*180/np.pi, ##### needs to be verified
                    point_group= pg,
                    method=sampling
            )
            
            Gc = rot.OTPfromQ(rot_orix.data)

            # cubochoric is equal volume mapped
            # Sing and De Graef, 2016
            dV = 1/dchi**3 * np.ones( 
                Gc.shape[0], data_type)
    except:
        sampling = 'simple'
    
    if sampling == 'simple':
        ## set up angles used to rotate the single crystal patterns
        ome = np.linspace( 
            dchi/2, np.pi-dchi/2, int(np.pi/dchi), endpoint=True)
        tta = np.linspace( 
            dchi/2, np.pi-dchi/2, int(np.pi/dchi), endpoint=True)
        phi = np.linspace( 0, 2*np.pi, int(2*np.pi/dchi), endpoint=False)
        TTA, PHI, OME = np.meshgrid(tta, phi, ome)
        Ome, Tta, Phi = OME.flatten(), TTA.flatten(), PHI.flatten()
        Gc = np.column_stack((Ome,Tta,Phi))

        ## apply the crystal symmetry conditions on Tta, Phi, Ome, so in the following 
        # only these are calculated by only choosing rotations in the fundamental zone 
        # of the proper point group
        fz = sym.zone(symmetry,Gc)
        Tta, Phi, Ome = Tta[fz], Phi[fz], Ome[fz] # these are the angles that effectively will be used
        Gc = Gc[fz] # cut away the redundand ones from the rotation array

        # volume element for integrating over the odf
        # see Mason/Patala, arXiv (2019), appendix C
        # omitted factor 1/2 here, since we use omega only from 0 to pi
        dV = np.sin(Ome/2)**2 * np.sin(Tta) * dchi**3 

    # import matplotlib.pyplot as plt
    # fig = plt.figure(figsize=(15, 10))
    # scatter_kwargs = dict(
    #     projection="rodrigues",
    #     figure=fig,
    #     wireframe_kwargs=dict(color="k", linewidth=1, alpha=0.1),
    #     s=5,
    # )
    # ori_plain = Orientation(Rotation([rot.QfromOTP( Gc)]), symmetry=pg).get_random_sample(10000)
    # ori_orix = Orientation(rot_orix, symmetry=pg).get_random_sample(10000)
    # ori_orix.scatter(position=231, c="C0", **scatter_kwargs)
    # ori_plain.scatter(position=232, c="C1", **scatter_kwargs)
    # # ori_quat2.scatter(position=233, c="C2", **scatter_kwargs)

    # ori_orix.scatter(position=234, c="C0", **scatter_kwargs)
    # ori_plain.scatter(position=235, c="C1", **scatter_kwargs)
    # # ori_quat2.scatter(position=236, c="C2", **scatter_kwargs)

    # titles = ["cubochoric", "plain"]#, "quaternion"]
    # for i, title in zip([0, 1], titles):
    #     fig.axes[i].view_init(elev=90, azim=0)
    #     fig.axes[i].set_title(titles[i])
    # for i in [2, 3]:
    #     fig.axes[i].view_init(elev=0, azim=0)

    # volume of the fundamental zone [rad^3]
    V_fz = dV.sum()
    return Gc, dV

Gc_cub, dV_cub = define_angles('cubochoric','432',2*np.pi/200)
Gc_sim, dV_sim = define_angles('simple','432',2*np.pi/120)

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
skip = 100
x = Gc_cub[::skip,0] * np.sin(Gc_cub[::skip,1])* np.cos(Gc_cub[::skip,2])
y = Gc_cub[::skip,0] * np.sin(Gc_cub[::skip,1])* np.sin(Gc_cub[::skip,2])
z = Gc_cub[::skip,0] * np.cos(Gc_cub[::skip,1])
ax.scatter( x,y,z )
ax.set_title('cubochoric')
set_axes_equal_3d(ax)

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
skip = 100
x = Gc_sim[::skip,0] * np.sin(Gc_sim[::skip,1])* np.cos(Gc_sim[::skip,2])
y = Gc_sim[::skip,0] * np.sin(Gc_sim[::skip,1])* np.sin(Gc_sim[::skip,2])
z = Gc_sim[::skip,0] * np.cos(Gc_sim[::skip,1])
ax.scatter( x,y,z )
ax.set_title('simple')
set_axes_equal_3d(ax)

print(Gc_sim.shape[0])
print(Gc_cub.shape[0])
plt.show()