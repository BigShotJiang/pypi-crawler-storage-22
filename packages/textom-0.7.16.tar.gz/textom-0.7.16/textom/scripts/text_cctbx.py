from cctbx import crystal, miller
from iotbx import cif


def get_hkl_from_cif(cif_file):
    """
    Reads a CIF file and extracts a list of Miller indices (hkl vectors).
    
    :param cif_file: Path to the CIF file
    :return: List of (h, k, l) tuples representing Miller indices
    """
    cif_object = cif.reader(file_path=cif_file)
    cif_model = cif_object.model()
    block = list(cif_model.values())[0]  # Assuming first block contains the data
    
    # Get crystal symmetry
    symmetry = crystal.symmetry(
        unit_cell=block.get('_cell_length_a', None),
        space_group_symbol=block.get('_space_group_name_H-M_alt', None)
    )
    
    # Extract reflections
    miller_set = miller.build_set(symmetry, anomalous_flag=False, d_min=0.5)
    hkl_list = list(miller_set.indices())
    
    return hkl_list

# Example usage
hkl_vectors = get_hkl_from_cif("/Users/moritz/Documents/code/textom/textom/input/BaCO3.cif")
print(hkl_vectors)
