"""Data treatment subpackage for textom."""
