"""Optimization subpackage for textom."""
