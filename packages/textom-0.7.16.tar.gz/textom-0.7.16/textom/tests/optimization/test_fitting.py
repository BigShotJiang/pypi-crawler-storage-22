import numpy as np
import pytest

from textom.config import data_type
from textom.src.optimization.fitting import (
    _grad_c0,
    _grad_full,
    _lipschitz_c0,
    _loss,
    _projection,
)


@pytest.fixture
def test_problem():
    C = np.array([[1.0, 2.0], [3.0, 4.0]], dtype=data_type)
    data = np.array(
        [[2.0, 3.5, 5.0], [1.5, 3.5, 4.5]],
        dtype=data_type,
    )
    difflets_rot = np.array(
        [[[1.0, 0.0, 1.0], [0.0, 1.0, 1.0]]],
        dtype=data_type,
    )
    Beams = np.zeros((1, 2, 4), dtype=data_type)
    Beams[0, 0, :2] = [0.4, 0.6]
    Beams[0, 1, :2] = [0.5, 0.5]
    iBeams = np.full((1, 2, 4), np.uint64(2**32 - 1), dtype=np.uint64)
    iBeams[0, :, :2] = np.array([[0, 1], [0, 1]])
    gt_mask = np.array([[0, 0], [0, 1]], dtype=np.int64)
    scanmask = np.array([[True, True]], dtype=bool)
    expected_images = np.array(
        [[2.2, 3.2, 5.4], [2.0, 3.0, 5.0]],
        dtype=data_type,
    )
    expected_loss = float(((data - expected_images) ** 2).sum())
    data_av = np.array([2.5, 1.5], dtype=data_type)
    expected_grad_c0 = np.array([0.26, 0.14], dtype=data_type)
    expected_lipschitz = np.array([0.9, 1.1], dtype=data_type)
    return {
        "C": C,
        "data": data,
        "difflets_rot": difflets_rot,
        "Beams": Beams,
        "iBeams": iBeams,
        "gt_mask": gt_mask,
        "scanmask": scanmask,
        "expected_images": expected_images,
        "expected_loss": expected_loss,
        "data_av": data_av,
        "expected_grad_c0": expected_grad_c0,
        "expected_lipschitz": expected_lipschitz,
    }


def _finite_difference_grad(test_inputs, eps=1e-3):
    C = test_inputs["C"]
    grad = np.zeros_like(C, dtype=np.float64)
    for i in range(C.shape[0]):
        for j in range(C.shape[1]):
            C_plus = C.copy()
            C_minus = C.copy()
            C_plus[i, j] += eps
            C_minus[i, j] -= eps
            loss_plus = _loss(
                C_plus,
                test_inputs["data"],
                test_inputs["gt_mask"],
                test_inputs["Beams"],
                test_inputs["iBeams"],
                test_inputs["difflets_rot"],
            )
            loss_minus = _loss(
                C_minus,
                test_inputs["data"],
                test_inputs["gt_mask"],
                test_inputs["Beams"],
                test_inputs["iBeams"],
                test_inputs["difflets_rot"],
            )
            grad[i, j] = (loss_plus - loss_minus) / (2 * eps)
    return grad.astype(C.dtype)


def test_loss_matches_expected_value(test_problem):
    loss = _loss(
        test_problem["C"],
        test_problem["data"],
        test_problem["gt_mask"],
        test_problem["Beams"],
        test_problem["iBeams"],
        test_problem["difflets_rot"],
    )
    assert loss == pytest.approx(test_problem["expected_loss"], rel=1e-6)


def test_grad_full_matches_numeric(test_problem):
    grad = _grad_full(
        test_problem["C"],
        test_problem["data"],
        test_problem["gt_mask"],
        test_problem["Beams"],
        test_problem["iBeams"],
        test_problem["difflets_rot"],
    )
    grad_numeric = _finite_difference_grad(test_problem)
    assert grad.shape == grad_numeric.shape
    # Numba kernels run in single precision here, so expect tiny differences
    # versus the finite-difference baseline; loosen tolerance accordingly.
    np.testing.assert_allclose(grad, grad_numeric, rtol=1e-3, atol=5e-4)


def test_grad_c0_and_lipschitz_match_manual_computation(test_problem):
    grad_c0 = _grad_c0(
        test_problem["C"],
        test_problem["data_av"],
        test_problem["gt_mask"],
        test_problem["Beams"],
        test_problem["iBeams"],
    )
    assert np.allclose(grad_c0[:, 0], test_problem["expected_grad_c0"], atol=1e-6)
    assert np.all(grad_c0[:, 1:] == 0)
    lipschitz = _lipschitz_c0(
        test_problem["C"],
        test_problem["gt_mask"],
        test_problem["Beams"],
        test_problem["iBeams"],
    )
    assert np.allclose(lipschitz, test_problem["expected_lipschitz"], atol=1e-6)


def test_projection_respects_scanmask_and_difflets(test_problem):
    images = _projection(
        test_problem["C"],
        0,
        test_problem["scanmask"],
        test_problem["Beams"],
        test_problem["iBeams"],
        test_problem["difflets_rot"],
    )
    assert images.shape == (test_problem["Beams"].shape[1], test_problem["difflets_rot"].shape[2])
    np.testing.assert_allclose(images, test_problem["expected_images"], rtol=1e-6, atol=1e-6)
