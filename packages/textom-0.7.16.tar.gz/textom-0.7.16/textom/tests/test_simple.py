from textom import textom as ttm


def test_set_path_creates_expected_structure(tmp_path, capsys):
    test_dir = tmp_path
    ttm.set_path(str(test_dir))

    assert (test_dir / "analysis" / "fits").is_dir()
    assert (test_dir / "results" / "images").is_dir()

    # Should run without errors and print status
    ttm.check_state()
    captured = capsys.readouterr()
    assert "Checking state of analysis" in captured.out
