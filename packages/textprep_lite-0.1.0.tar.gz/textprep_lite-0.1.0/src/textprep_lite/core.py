import re
import unicodedata
from typing import Dict, Optional

def clean_text(
    text: str,
    lowercase: bool = True,
    strip_html: bool = True,
    normalize_whitespace: bool = True,
    strip_accents: bool = False,
    remove_punct: bool = False,
    remove_digits: bool = False,
    keep_newlines: bool = False,
) -> str:
    """
    Standardize and clean text.
    """
    if not text:
        return ""

    # 1. Strip HTML
    if strip_html:
        # Simple regex for HTML tags
        text = re.sub(r'<[^>]+>', ' ', text)

    # 2. Strip accents
    if strip_accents:
        text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('utf-8', 'ignore')

    # 3. Lowercase
    if lowercase:
        text = text.lower()

    # 4. Remove punctuation
    if remove_punct:
        # This regex matches any character that is NOT a word char or whitespace
        text = re.sub(r'[^\w\s]', '', text)

    # 5. Remove digits
    if remove_digits:
        text = re.sub(r'\d+', '', text)

    # 6. Normalize whitespace
    if normalize_whitespace:
        if keep_newlines:
            # Collapse spaces/tabs but keep newlines
            lines = text.splitlines()
            cleaned_lines = []
            for line in lines:
                # Collapse internal whitespace in the line
                cleaned_line = re.sub(r'[ \t]+', ' ', line).strip()
                cleaned_lines.append(cleaned_line)
            text = '\n'.join(cleaned_lines)
            # Collapse multiple newlines if needed? 
            # The prompt says "collapse multiple spaces/tabs/newlines into a single space by default (unless keep_newlines=True)"
            # So if keep_newlines is True, we likely just want straight \n, maybe max 1 empty line? 
            # For simplicity: just join with \n. Real-world "keep newlines" usually implies we care about structure.
        else:
            # Collapse all whitespace (including newlines) to single space
            text = re.sub(r'\s+', ' ', text).strip()
    
    return text.strip()


def anonymize_text(
    text: str,
    mask_emails: bool = True,
    mask_phones: bool = True,
    mask_urls: bool = True,
    mask_ip: bool = False,
    replacement: str = "[REDACTED]",
) -> str:
    """
    Mask sensitive information in text.
    """
    if not text:
        return ""

    # Patterns
    
    # URL: http/https followed by non-whitespace
    # A bit naive but standard for "lite" tools
    url_pattern = r'https?://\S+|www\.\S+'
    
    # Email: standard simple regex
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    
    # Phone: International + simple formats. 
    # Matches +1-234-567-8900, (123) 456-7890, 123 456 7890
    # This matches common patterns but avoids simple numbers like "2023" unless they look like phones.
    # Start with optional +, then digits/paerns/dashes/spaces. 
    # Must have at least ~7 digits total. 
    # This is hard to perfect in "lite". let's use a known robust-ish patterns for reasonable phones.
    # Pattern below: Optional +, then sequences of digits separated by - . or space. 
    # We look for a block that has at least 7 digits.
    # For a "lite" library, we might use a slightly simpler heuristic or just specific patterns.
    # "(?:\+\d{1,3}[-. ]?)?\(?\d{3}\)?[-. ]?\d{3}[-. ]?\d{4}" handles US/Intl standard well.
    # Phone: Simple robust pattern for US/Intl
    # Matches groups of digits separated by common delimiters.
    # e.g. +44 7700 900123, (555) 123-4567, +1-555-0199
    # Strategy: Look for 3+ groups of digits or a long block, with optional + prefix.
    # This is a trade-off: might match some non-phones, but covers most "lite" needs.
    # Phone: More flexible pattern
    # Optional country code, then 2-5 digits, then 1-3 groups of 2-10 digits.
    # Handles: +1-555-0199, +44 7700 900123, (555) 123-4567
    # Note: Dots are excluded from separators to avoid matching IPs (e.g. 192.168.1.1)
    # Also allows parens around country code e.g. (+1)
    phone_pattern = r'(?:(?:\(?\+?\d{1,3}\)?)[-\s]?)?\(?\d{2,5}\)?(?:[-\s]?\d{2,10}){1,3}'
    
    # IP: IPv4
    ip_pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'

    if mask_urls:
        text = re.sub(url_pattern, replacement, text)

    if mask_emails:
        text = re.sub(email_pattern, replacement, text)

    if mask_phones:
        text = re.sub(phone_pattern, replacement, text)

    if mask_ip:
        text = re.sub(ip_pattern, replacement, text)

    return text


def preprocess_text(
    text: str,
    clean_config: Optional[Dict] = None,
    anonymize_config: Optional[Dict] = None,
) -> str:
    """
    Apply cleaning and anonymization in sequence.
    """
    if clean_config is None:
        clean_config = {}
    if anonymize_config is None:
        anonymize_config = {}

    cleaned = clean_text(text, **clean_config)
    processed = anonymize_text(cleaned, **anonymize_config)
    
    return processed
