import pytest
from textprep_lite import anonymize_text

def test_anonymize_email():
    text = "Contact me at john.doe@example.com."
    assert anonymize_text(text) == "Contact me at [REDACTED]."

def test_anonymize_phone():
    text = "Call +1-555-0199 now"
    assert anonymize_text(text) == "Call [REDACTED] now"

def test_anonymize_url():
    text = "Visit https://example.com/foo"
    assert anonymize_text(text) == "Visit [REDACTED]"

def test_anonymize_ip():
    text = "Server at 192.168.1.1"
    assert anonymize_text(text, mask_ip=True) == "Server at [REDACTED]"
    assert anonymize_text(text, mask_ip=False) == "Server at 192.168.1.1"

def test_custom_replacement():
    text = "user@example.com"
    assert anonymize_text(text, replacement="<HIDDEN>") == "<HIDDEN>"

def test_multiple():
    text = "Email: a@b.com, Phone: 555-555-5555"
    expected = "Email: [REDACTED], Phone: [REDACTED]"
    assert anonymize_text(text) == expected
