import pytest
from textprep_lite import clean_text

def test_clean_text_basic():
    text = "  Hello   World  "
    assert clean_text(text) == "hello world"

def test_clean_text_html():
    text = "<p>Hello</p><br>World"
    assert clean_text(text, strip_html=True) == "hello world"

def test_clean_text_accents():
    text = "café"
    assert clean_text(text, strip_accents=True) == "cafe"

def test_clean_text_punct():
    text = "Hello, World!"
    assert clean_text(text, remove_punct=True) == "hello world"

def test_clean_text_digits():
    text = "Model T-800"
    assert clean_text(text, remove_digits=True) == "model t-"

def test_clean_text_keep_newlines():
    text = "Line 1\n  Line 2  "
    # Should collapse line whitespace but keep the newline
    assert clean_text(text, keep_newlines=True) == "line 1\nline 2"

def test_clean_text_no_lowercase():
    text = "Hello World"
    assert clean_text(text, lowercase=False) == "Hello World"
