An Text To Binary Code Converter Library Made In Python.
# Installation
```python
pip install TextToBinary
```
# Usage
```python
import TextToBinary

print(TextToBinary.convert("Example Text))
```
