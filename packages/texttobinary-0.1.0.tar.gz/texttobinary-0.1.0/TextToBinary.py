def convert(text):
    binary = ''.join(format(ord(char), '08b') for char in text)
    return binary

