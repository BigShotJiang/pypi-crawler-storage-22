"""Entry point for textual-reactive examples."""


def main():
    """Run the counter example."""
    from examples.counter import Counter
    Counter().run()


if __name__ == "__main__":
    main()
