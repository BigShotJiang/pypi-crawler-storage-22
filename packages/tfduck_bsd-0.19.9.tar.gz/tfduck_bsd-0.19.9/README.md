# Example Package

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
> 测试命令行工具
```
tfd a1 a2
```

> 测试脚本内容
```
    >>> from tfduck_pkg.helloworld import HelloWorld
    >>> HelloWorld().test()
```