# # coding=utf-8

# ISTEST = True  # 为True就是测试模式
# BDPTOKEN = 'your token'  # 需要自己填写bdp_token，找相关人员索要
# MAX_DATA_LENGTH = 5000
# # 定义上传的表的结构
# PUBLIC_ACTIVATE_HEADER = (
#     ("app_name", "string"),
#     ("date", "date"),
#     ("country", "string"),
#     ("active_count", "number"),
# )

# PUBLIC_ACTIVATE_HEADER1 = (
#     ("app_name", "string"),
#     ("date", "date"),
#     ("country", "string"),
#     ("active_count", "number"),
# )

# # 定义表名
# HEADERDEFINE = {
#     "af_active": PUBLIC_ACTIVATE_HEADER,
#     "af_active1": PUBLIC_ACTIVATE_HEADER1,
# }
# # 定义表和表结构映射关系
# BDPTABDEFINE = [
#     {
#         'headers': HEADERDEFINE['af_active'],
#         'bdpTbName': "af_active",
#     },
#     {
#         'headers': HEADERDEFINE['af_active1'],
#         'bdpTbName': "af_active1",
#     },
# ]
