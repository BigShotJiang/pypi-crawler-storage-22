# tftree-manager

TF 树梳理与变换管理：从 YAML 目录加载/保存外参与顺序，构建无向图、路径查找、环检测、变换矩阵计算。

## 安装

```bash
pip install tftree-manager
```

## 功能特性

- 从 `yaml_dir/extrinsics/*.yaml` 与 `order_manifest.yaml` 加载/保存外参与顺序
- 无向图构建、BFS 路径查找、有向环检测
- 沿路径累积 4x4 变换矩阵、从根节点计算到所有可达节点
- 更新变换、求逆、重排顺序并写回 YAML
- 可选 Flask API 服务与命令行入口

## 快速开始

```python
from tftree_manager import TFTreeManager

manager = TFTreeManager("/path/to/yaml_dir")
manager.load_from_yaml()

# 所有坐标系
frames = manager.get_all_frames()

# 两节点间变换矩阵
T = manager.get_transform("lidar", "camera")

# 从根节点计算到所有节点
transforms = manager.compute_all_transforms_from_root("world")

# 检测环
cycles = manager.detect_cycles()

# 保存
manager.save_to_yaml()
```

## 命令行

```bash
# 以 YAML 目录为参数，加载并打印树与环信息
tftree-manager /path/to/yaml_dir

# 启动 Flask API 服务（默认 0.0.0.0:5000）
tftree-manager-server
```

环境变量 `TFTREE_DATA_DIR` 可指定 API 默认数据目录（默认 `./data`）。

## 依赖

- Python >= 3.10
- numpy >= 1.20.0
- PyYAML >= 5.4.0
- Flask >= 2.0.0（API 与 server 入口需要）

## License

MIT
