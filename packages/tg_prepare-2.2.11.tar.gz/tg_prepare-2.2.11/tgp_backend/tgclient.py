# -*- coding: utf-8 -*-
# Copyright (C) 2023-2026 TU-Dresden (ZIH)
# ralf.klammer@tu-dresden.de
# moritz.wilhelm@tu-dresden.de
import logging

from tgadmin.tgadmin import _crud_delete_op

from tgclients import (
    TextgridAuth,
    TextgridConfig,
    TextgridCrud,
    TextgridSearch,
)
from tgclients.config import PROD_SERVER, TEST_SERVER

log = logging.getLogger(__name__)


class TGclient(object):
    def _get_category_mime_types(self, category):
        if category == "tei":
            return ["text/xml"]
        elif category == "images":
            return ["image/jpeg", "image/png", "image/gif"]
        elif category == "other":
            return [
                "image/png",
                "text/markdown",
                "application/xslt+xml",
                "text/tg.portalconfig+xml",
            ]
        else:
            return None

    def __init__(self, sid, instance="test", verbose=False):
        self.sid = sid

        if instance == "live":
            self.server = PROD_SERVER
        else:
            self.server = TEST_SERVER
        self.config = TextgridConfig(self.server)

        self.crud = TextgridCrud(self.config)
        self.tgauth = TextgridAuth(self.config)
        self.tgsearch = TextgridSearch(self.config, nonpublic=True)

        self._contents = {}

    def check_session(self):
        try:
            if self.sid:
                self.tgsearch.search(sid=self.sid, limit=1)
                return True
        except Exception as e:
            log.error(f"Error checking session id: {self.sid} : {e}")
        return False
        # return self.tgauth.check_session(self.sid)  # returns username

    def create_project(self, name, description=""):
        log.info(f"Creating project {name}")
        return self.tgauth.create_project(self.sid, name, description)

    def clear_project(self, project_id):
        # delete content of project
        # repeat until whole content has been deleted
        # (necessary because of default limit in '_crud_delete_op')
        log.info(f"Clearing project contents {project_id}")
        content = self._query_contents(project_id)
        handled_count = 0
        initial_count = int(content.hits)
        while handled_count < initial_count:
            for tgobj in content.result:
                # can only delete objects that are not already published
                if tgobj.object_value.generic.generated.availability == None:
                    _crud_delete_op(self, tgobj)
                handled_count += 1
            content = self._query_contents(project_id)

    def delete_project(self, project_id):
        self.clear_project(project_id)

        log.info(f"Deleting project {project_id}")
        return self.tgauth.delete_project(self.sid, project_id)

    def _query_contents(self, tg_project_id):
        if not self._contents.get(tg_project_id):
            log.debug(f"Querying contents for project id: {tg_project_id}")
            try:
                self._contents[tg_project_id] = self.tgsearch.search(
                    filters=["project.id:" + tg_project_id],
                    facet=["format"],
                    sid=self.sid,
                    limit=10000,
                )
            except Exception as e:
                log.error(f"Error querying contents for project: {e}")
                return []

        return self._contents[tg_project_id]

    def _count_all_categories(self, tg_project_id):
        contents = self._query_contents(tg_project_id)
        counts = {"tei": 0, "images": 0, "other": 0, "all": 0}
        tei_formats = self._get_category_mime_types("tei")
        image_formats = self._get_category_mime_types("images")
        other_formats = self._get_category_mime_types("other")
        for facet_group in contents.facet_response.facet_group:
            if facet_group.name == "format":
                for facet in facet_group.facet:
                    if tei_formats and facet.value in tei_formats:
                        counts["tei"] += facet.count
                    if image_formats and facet.value in image_formats:
                        counts["images"] += facet.count
                    if other_formats and facet.value in other_formats:
                        counts["other"] += facet.count
                    counts["all"] += facet.count
        return counts

    def get_project_contents(
        self,
        tg_project_id,
        public=None,
        count=False,
        category=None,
    ):
        if count:
            counts = self._count_all_categories(tg_project_id)
            if category == "tei":
                return counts["tei"]
            elif category == "images":
                return counts["images"]
            elif category == "other":
                return counts["other"]
            elif category is None:
                return counts
            else:
                raise ValueError(f"Unknown category for counting: {category}")

        contents = self._query_contents(tg_project_id)
        results = {}
        mime_filter = self._get_category_mime_types(category)
        for tgobj in contents.result:
            result = {}
            result["title"] = tgobj.object_value.generic.provided.title[0]
            result["tguri"] = (
                tgobj.object_value.generic.generated.textgrid_uri.value
            )
            result["mime"] = tgobj.object_value.generic.provided.format
            result["published"] = (
                tgobj.object_value.generic.generated.availability is not None
            )
            log.debug(f"Found object: {result}")

            if mime_filter is None or result["mime"] in mime_filter:
                results[result["title"]] = result
            else:
                log.info(
                    "Skipping object with irrelevant mime-type: %s"
                    % result["mime"]
                )
        return results

    def get_project_description(self, project_id):
        if project_id is None:
            return
        desc = self.tgauth.get_project_description(project_id)
        if desc:
            counts = self.get_project_contents(project_id, count=True)
            return {
                "id": project_id,
                "name": desc.name,
                "description": desc.description,
                "tei_count": counts["tei"],
                "img_count": counts["images"],
                "other_count": counts["other"],
                "content_count": counts["all"],
            }
        else:
            log.warning(f"Cannot find project description for: {project_id}")

    def get_assigned_projects(self):
        log.info("Listing assigned projects")
        try:
            _projects = self.tgauth.list_assigned_projects(self.sid)
        except Exception as e:
            log.error(f"Error listing assigned projects: {e}")
            return []

        for project_id in reversed(_projects):
            yield self.get_project_description(project_id)

    # def upload(self, filenames: list[str], project_id: str, imex_file: str):
    #     tg_importer = TGimport(
    #         self.sid,
    #         self.crud,
    #         project_id=project_id,
    #         ignore_warnings=True,
    #         imex_location=imex_file,
    #     )
    #     tg_importer.upload(filenames=filenames, threaded=True)

    def publish(self, tg_project_id):
        log.info(f"Publishing project {tg_project_id}")
        # TODO: implement publish logic in tgclients
        # see tgadmin.tgadmin.publish() tgadmin.py::Z646
        breakpoint()
