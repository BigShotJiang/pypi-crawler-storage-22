"""Telegram File Sender - Send files to Telegram contacts from your CLI."""

__version__ = "1.2.0"
