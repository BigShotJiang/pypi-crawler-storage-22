"""ETL process for fetching, transforming, and loading news articles.

This module provides the NewsEtl class which orchestrates the extraction,
transformation, and loading of news articles from external sources into
a Parquet data store.
"""

import logging
from typing import Any
from datetime import datetime, UTC
import pandas as pd
from tgedr_dataops_abs.etl import Etl
from tgedr_dataops.store.parquet_store import ParquetStore

from tgedr_datasets.ticker.fetcher import TickerFetcher

logger = logging.getLogger(__name__)


class TickerEtl(Etl):
    """ETL process for fetching, transforming, and loading tickers."""

    def __init__(self, configuration: dict[str, Any] | None = None) -> None:  # pragma: no cover
        """Initialize TickerEtl with optional configuration.

        Args:
            configuration : dict[str, Any]
                source for configuration injection

        """
        super().__init__(configuration)
        self._data: list[str] = []
        self._result: pd.DataFrame = None

    @Etl.inject_configuration
    def extract(self, source: str) -> None:
        """Extract ticker data from specified sources.

        Args:
            source: Comma-separated string of data sources to fetch tickers from.

        """
        logger.info(f"[extract|in] ({source})")

        sources = [s.strip() for s in source.split(",")]
        self._data = TickerFetcher().fetch(sources)

        logger.info("[extract|out] tickers len: %d", len(self._data))

    def transform(self) -> None:
        """Transform extracted ticker data into a DataFrame with date information."""
        logger.info("[transform|in]")

        today = datetime.now(UTC).date()
        epoch: int = int(datetime(today.year, today.month, today.day, tzinfo=UTC).timestamp())

        self._result = pd.DataFrame(self._data, columns=["ticker"])
        self._result["date"] = epoch

        logger.info("[transform|out]")

    @Etl.inject_configuration
    def load(self, target_url: str) -> str:
        """Load transformed ticker data into a Parquet store.

        Args:
            target_url: File path where the Parquet data will be saved.

        Returns:
            The target path where data was saved.

        """
        logger.info(f"[load|in] ({target_url})")

        ParquetStore().update(df=self._result, key=target_url, key_fields=["date", "ticker"])

        logger.info(f"[load|out] => {target_url}")
        return target_url

