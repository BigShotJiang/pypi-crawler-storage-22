# tgedr-pycommons

![Coverage](./coverage.svg)
[![PyPI](https://img.shields.io/pypi/v/tgedr-pycommons)](https://pypi.org/project/tgedr-pycommons/)


Common code to be used across projects


## development
- main requirements:
  - _uv_  
  - _bash_
- Clone the repository like this:

  ``` bash
  git clone git@github.com:tgedr/pycommons
  ```
- cd into the folder: `cd pycommons`
- install requirements: `./helper.sh reqs`
