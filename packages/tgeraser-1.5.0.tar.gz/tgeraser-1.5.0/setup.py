"""
For development mode only
"""

import setuptools
setuptools.setup()
