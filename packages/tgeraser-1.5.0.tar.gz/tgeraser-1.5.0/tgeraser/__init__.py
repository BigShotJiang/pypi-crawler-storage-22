"""
__init__.py
"""
from . import __version__
from .eraser import Eraser
