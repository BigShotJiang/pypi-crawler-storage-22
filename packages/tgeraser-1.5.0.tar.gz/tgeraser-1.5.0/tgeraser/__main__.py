"""
Code so python -m will executed
"""

from . import core

if __name__ == "__main__":
    core.entry()
