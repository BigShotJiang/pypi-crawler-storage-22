"""
Version file
"""

VERSION = "1.5.0"
