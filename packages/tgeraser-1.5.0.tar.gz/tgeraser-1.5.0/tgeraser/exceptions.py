"""
Custom exceptions
"""


class TgEraserException(Exception):
    pass
