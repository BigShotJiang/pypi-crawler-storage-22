"""
Shared utilities for telemetry message sending.

Provides common functions used by both regular and historical message sending.
"""

import json
import logging
from datetime import datetime
from typing import Optional

from ..config.schemas import DeviceSchema
from ..connectivity.iot_hub_client import IoTHubClient
from .telemetry_generator import TelemetryGenerator

logger = logging.getLogger(__name__)


async def generate_and_send_message(
    generator: TelemetryGenerator,
    iot_client: IoTHubClient,
    message_type: str,
    device_schema: DeviceSchema,
    timestamp_override: Optional[str] = None,
) -> int:
    """
    Generate and send telemetry message(s) for a given type.

    Args:
        generator: TelemetryGenerator instance
        iot_client: IoTHubClient for sending messages
        message_type: Type of message to generate (measurement, state, events, sw_logs)
        device_schema: Device schema for generation
        timestamp_override: Optional timestamp to display (for historical data)

    Returns:
        Number of messages sent
    """
    try:
        # Generate messages with timestamp_override
        messages = generator.generate_telemetry(
            message_type, device_schema, timestamp_override
        )

        if not messages:
            logger.warning(f"No {message_type} messages generated")
            return 0

        sent_count = 0
        for message in messages:
            # Send message
            await iot_client.send_message(message, message_type)
            sent_count += 1

            # Log and print
            logger.debug(f"[D2C] Sent {message_type}: {json.dumps(message, indent=2)}")

            # Print status with timestamp
            display_timestamp = (
                timestamp_override if timestamp_override else datetime.now().isoformat()
            )
            print(f"{display_timestamp} Sent {message_type}")

        return sent_count

    except Exception as e:
        logger.error(f"Error generating/sending {message_type}: {e}")
        raise
