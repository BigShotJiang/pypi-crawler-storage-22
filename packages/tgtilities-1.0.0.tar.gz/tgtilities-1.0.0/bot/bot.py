import asyncio
import logging

from tgtilities.analytics import setup_analytics
from tgtilities.routers import include_routers
from tgtilities.sqlalchemy.session import AsyncSessionManagerFactory
from tgtilities.utils.logging import setup_logging

from aiogram import Bot, Dispatcher

setup_logging(logging.DEBUG, levels={
	"aiogram.event": logging.WARNING
})

session_manager_factory = AsyncSessionManagerFactory("users.db")

async def main():
	bot = Bot(token="7659457511:AAGbU2nydXarlXfacgOFg1iGA7XNK7IpFno")

	dispatcher = Dispatcher()

	await setup_analytics(dispatcher)
	include_routers(dispatcher, "handlers", hot_reload=True)
	
	await dispatcher.start_polling(bot, session_factory=session_manager_factory)

if __name__ == "__main__":
	asyncio.run(main())