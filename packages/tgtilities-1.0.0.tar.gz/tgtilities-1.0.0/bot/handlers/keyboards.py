from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message, ReplyKeyboardRemove

from tgtilities.keyboard import static_reply_markup, static_inline_markup 

router = Router(name="keyboards")

@static_reply_markup
def reply_markup():
	return [
		["Меню"],
		["Профиль", "Настройки"]
	]

@static_inline_markup
def inline_markup():
	return [
		[("Меню", "menu"), ("Товары", "products")],
		[("Настройки", "settings")]
	]

@router.message(Command("reply"))
async def reply(message: Message):
	await message.answer(
		"Выбери кнопку ниже 👇",
		reply_markup=reply_markup()
	)

@router.message(Command("inline"))
async def inline(message: Message):
	await message.answer(
		"Выбери инлайн-кнопку ниже 👇",
		reply_markup=inline_markup()
	)

@router.message(Command("remove"))
async def remove(message: Message):
	await message.answer(
		"Клавиатура убрана",
		reply_markup=ReplyKeyboardRemove()
	)