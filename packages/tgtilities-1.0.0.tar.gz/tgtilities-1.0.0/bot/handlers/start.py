from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message

router = Router(name="start")

@router.message(CommandStart())
async def start(message: Message):
	await message.answer("Hello!")