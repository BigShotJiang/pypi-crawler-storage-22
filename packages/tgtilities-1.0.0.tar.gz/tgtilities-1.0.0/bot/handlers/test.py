from aiogram import Router
from aiogram.enums import ParseMode
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton

from tgtilities.sqlalchemy.session import AsyncSessionManagerFactory
from tgtilities.utils.errors import SupressNotModified

router = Router(name="test")

@router.message(Command("add"))
async def add(message: Message, session_factory: AsyncSessionManagerFactory):
	await message.answer()

@router.callback_query()
async def callback_query(callback: CallbackQuery):
	button = [button for buttons in callback.message.reply_markup.inline_keyboard for button in buttons if button.callback_data == callback.data][0]

	with SupressNotModified():
		await callback.message.edit_text(
			f"You just hit the <code>{callback.data}</code> button! Click it again 👇",
			reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=button.text, callback_data=button.callback_data)]]),
			parse_mode=ParseMode.HTML
		)

	await callback.answer()