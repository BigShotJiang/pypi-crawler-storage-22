from .setup import setup_analytics

__all__ = ["setup_analytics"]