from .static import (
	reply as static_reply_markup,
	inline as static_inline_markup
)

from .dynamic import (
	reply as dynamic_reply_markup,
	inline as dynamic_inline_markup
)

__all__ = [
	"static_reply_markup", "static_inline_markup",
	"dynamic_reply_markup", "dynamic_inline_markup"
]