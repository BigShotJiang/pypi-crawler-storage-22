import functools
from typing import Callable
from typing_extensions import TypeVar, ParamSpec

from aiogram.types import ReplyKeyboardMarkup, InlineKeyboardMarkup
from aiogram.utils.keyboard import ReplyKeyboardBuilder, InlineKeyboardBuilder

T = TypeVar("T")
P = ParamSpec("P")

def reply(function: Callable[P, T]):
	@functools.wraps(function)
	def wrapper(*args: P.args, **kwargs: P.kwargs) -> ReplyKeyboardMarkup:
		builder = ReplyKeyboardBuilder()
		
		function(builder, *args, **kwargs)

		return builder.as_markup()
		
	return wrapper

def inline(function: Callable[P, T]):
	@functools.wraps(function)
	def wrapper(*args: P.args, **kwargs: P.kwargs) -> InlineKeyboardMarkup:
		builder = InlineKeyboardBuilder()
		
		function(builder, *args, **kwargs)

		return builder.as_markup()
	
	return wrapper

__all__ = ["reply", "inline"]