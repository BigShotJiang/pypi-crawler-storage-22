class ReprMixin:
	"""
	Mixin with a simple `__repr__` implementation for SQLAlchemy models.
	"""

	def __repr__(self):
		attributes = ", ".join(
			f"{key}={value}"
			for key, value in vars(self).items()
			if not key.startswith("_") and not hasattr(value, "_sa_adapter") and not hasattr(value, "_sa_instance_state")
		)

		return f"<{self.__class__.__name__}({attributes})>"

__all__ = ["ReprMixin"]