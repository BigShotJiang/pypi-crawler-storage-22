from aiogram.exceptions import TelegramBadRequest

class SupressTelegramBadRequest:
	def __init__(self, message: str | None=None):
		self.message = message

	def __enter__(self):
		return self
	
	def __exit__(self, exc_type: type[Exception], exc: Exception, tb):
		return (
			isinstance(exc, TelegramBadRequest)
			and self.message in exc.message
		)
	
class SupressNotModified(SupressTelegramBadRequest):
	def __init__(self):
		super().__init__("message is not modified")