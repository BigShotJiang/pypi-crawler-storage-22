import logging as _logging

_package_name = "tgtilities"

logging = _logging.getLogger(f"{_package_name}.logging")
routers = _logging.getLogger(f"{_package_name}.routers")
sqlalchemy = _logging.getLogger(f"{_package_name}.sqlalchemy")
analytics = _logging.getLogger(f"{_package_name}.analytics")

__all__ = ["logging", "routers", "analytics"]