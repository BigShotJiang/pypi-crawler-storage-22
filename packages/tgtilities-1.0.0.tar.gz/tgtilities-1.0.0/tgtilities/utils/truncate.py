def truncate(string: str, left: int, right: int):
	"""
	Truncate `string` by keeping `left` characters from the start and `right` characters from the end.

	Example::

		truncate("Hajimemashite!", 4, 4)
		# Haji...ite!

	:param string: String to truncate
	:param left: Number of characters to keep from the start
	:param right: Number of characters to keep from the end

	:return: Truncated string
	:rtype: str
	"""

	return string[:left] + "..." + string[-right:]

def ltruncate(string: str, length: int, ellipsis: bool=True):
	"""
	Truncate `string` from the start.

	Example::

		truncate("Hajimemashite!", 4)
		# ...ite!

	:param string: String to truncate
	:param length: Number of characters to keep
	:param ellipsis: Whether to prepend an ellipsis

	:return: Truncated string
	:rtype: str
	"""

	result = string[-length:]
	
	if ellipsis:
		return "..." + result
	else:
		return result

def rtruncate(string: str, length: int, ellipsis: bool=True):
	"""
	Truncate `string` from the end.

	Example::

		truncate("Hajimemashite!", 4)
		# Haji...

	:param string: String to truncate
	:param length: Number of characters to keep
	:param ellipsis: Whether to append an ellipsis

	:return: Truncated string
	:rtype: str
	"""

	result = string[:length]
	
	if ellipsis:
		return result + "..."
	else:
		return result