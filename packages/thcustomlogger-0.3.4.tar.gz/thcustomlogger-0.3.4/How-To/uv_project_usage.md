# UV Project Usage Guide

## Overview
This guide provides comprehensive instructions for using `uv` to manage Python projects. UV is a fast Python package installer and resolver written in Rust that replaces pip, pip-tools, pipx, poetry, pyenv, virtualenv, and more.

## Table of Contents
- [Installation](#installation)
- [Initial Setup](#initial-setup)
- [Common Commands](#common-commands)
- [Dependency Management](#dependency-management)
- [Building Distributions](#building-distributions)
- [Running Code](#running-code)
- [Development Workflow](#development-workflow)
- [Testing](#testing)
- [Troubleshooting](#troubleshooting)

## Installation

### Install UV
```bash
# macOS/Linux
curl -LsSf https://astral.sh/uv/install.sh | sh

# Or using Homebrew (macOS)
brew install uv

# Windows (PowerShell)
powershell -c "irm https://astral.sh/uv/install.ps1 | iex"
```

### Verify Installation
```bash
uv --version
```

## Initial Setup

### Create a New Project
```bash
# Create a new Python project
uv init my-project
cd my-project

# Or initialize in current directory
uv init
```

### Clone Existing Project
```bash
git clone <repository-url>
cd <project-directory>

# Sync dependencies from existing pyproject.toml
uv sync
```

### Python Version Management
```bash
# Install a specific Python version
uv python install 3.12

# Use a specific Python version for the project
uv python pin 3.12

# List available Python versions
uv python list

# List installed Python versions
uv python list --only-installed
```

## Common Commands

### Virtual Environment Management
```bash
# Create virtual environment (uv does this automatically)
uv venv

# Create with specific Python version
uv venv --python 3.12

# Activate virtual environment
# macOS/Linux:
source .venv/bin/activate

# Windows:
.venv\Scripts\activate

# Note: Many uv commands work without activating the venv
```

### Sync Dependencies
```bash
# Sync project dependencies from pyproject.toml
uv sync

# Sync only production dependencies (exclude dev dependencies)
uv sync --no-dev

# Sync with specific extras
uv sync --extra dev --extra test
```

## Dependency Management

### Adding Dependencies

#### Add Production Dependencies
```bash
# Add a package to dependencies
uv add requests

# Add with version constraint
uv add "requests>=2.28.0"
uv add "requests~=2.28.0"  # Compatible release
uv add "requests==2.28.0"  # Exact version

# Add multiple packages
uv add requests pandas numpy
```

#### Add Development Dependencies
```bash
# Add to dev dependencies
uv add --dev pytest

# Add multiple dev dependencies
uv add --dev pytest black ruff mypy
```

#### Add Optional Dependencies (Extras)
```bash
# Add to a specific extras group
uv add --optional docs sphinx sphinx-rtd-theme

# Add to multiple groups
uv add --optional test pytest pytest-cov
```

### Removing Dependencies
```bash
# Remove a package
uv remove requests

# Remove dev dependency
uv remove --dev pytest

# Remove from extras
uv remove --optional docs sphinx
```

### Updating Dependencies
```bash
# Update all dependencies
uv lock --upgrade

# Update specific package
uv lock --upgrade-package requests

# Update multiple packages
uv lock --upgrade-package requests --upgrade-package pandas
```

### Listing Dependencies
```bash
# List installed packages
uv pip list

# Show dependency tree
uv tree

# Show outdated packages
uv pip list --outdated
```

### Lock File Management
```bash
# Generate/update uv.lock
uv lock

# Update all packages in lock file
uv lock --upgrade

# Lock with specific Python version
uv lock --python-version 3.12
```

## Building Distributions

### Build Package
```bash
# Build source distribution and wheel
uv build

# Build only wheel
uv build --wheel

# Build only source distribution
uv build --sdist

# Build to specific directory
uv build --out-dir dist/
```

### Publish Package
```bash
# Publish to PyPI (requires twine or similar)
uv publish

# Publish to test PyPI
uv publish --repository testpypi

# Publish with specific token
uv publish --token <your-token>
```

### Install Local Package
```bash
# Install package in editable mode
uv pip install -e .

# Or use uv's native command
uv sync --dev
```

## Running Code

### Run Python Scripts
```bash
# Run Python file
uv run python script.py

# Run module
uv run python -m mymodule

# Run with specific Python version
uv run --python 3.12 python script.py
```

### Run Project Commands
```bash
# Run entry point defined in pyproject.toml [project.scripts]
uv run my-command

# Run with arguments
uv run my-command --arg1 value1
```

### Run One-off Scripts
```bash
# Run script with inline dependencies
uv run --with requests python fetch_data.py

# Run with multiple dependencies
uv run --with requests --with pandas python analyze.py
```

## Development Workflow

### Typical Workflow

#### 1. Initialize Project
```bash
uv init my-project
cd my-project
```

#### 2. Add Dependencies
```bash
# Add production dependencies
uv add requests sqlalchemy

# Add development dependencies
uv add --dev pytest black ruff
```

#### 3. Develop Code
Edit your Python files in `src/` or project directory

#### 4. Run Tests
```bash
uv run pytest
```

#### 5. Update Dependencies
```bash
# Update lock file
uv lock --upgrade

# Sync to install updates
uv sync
```

#### 6. Build Distribution
```bash
uv build
```

## pyproject.toml Structure

### Basic Structure
```toml
[project]
name = "my-project"
version = "0.1.0"
description = "My Python project"
requires-python = ">=3.12"
dependencies = [
    "requests>=2.28.0",
    "sqlalchemy>=2.0.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=7.0.0",
    "black>=23.0.0",
    "ruff>=0.1.0",
]

[project.scripts]
my-command = "my_project.main:main"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.uv]
dev-dependencies = [
    "pytest>=7.0.0",
]
```

### Sync Dependencies to pyproject.toml

UV automatically updates `pyproject.toml` when you use `uv add` or `uv remove`. The dependency is added to the appropriate section:

```bash
# This command:
uv add requests

# Automatically adds to pyproject.toml:
# [project]
# dependencies = ["requests>=2.31.0"]

# And updates uv.lock with resolved versions
```

To manually edit and sync:
1. Edit `pyproject.toml` manually
2. Run `uv lock` to update the lock file
3. Run `uv sync` to install dependencies

## Testing

### Run Tests
```bash
# Run all tests
uv run pytest

# Run specific test file
uv run pytest tests/test_example.py

# Run with coverage
uv run pytest --cov=src

# Run with verbose output
uv run pytest -v
```

### Add Testing Dependencies
```bash
uv add --dev pytest pytest-cov pytest-asyncio
```

## Key Files

### pyproject.toml
- Project metadata (name, version, description)
- Python version requirement
- Production dependencies
- Optional dependencies (extras)
- Development dependencies
- Build system configuration
- Entry points and scripts
- Tool configurations

### uv.lock
- Locked versions of all dependencies
- Complete dependency resolution
- Ensures reproducible installations
- Auto-generated by `uv lock`
- Should be committed to version control

### .python-version
- Specifies Python version for the project
- Created by `uv python pin`
- Used by uv to select correct Python version

## Troubleshooting

### Issue: Dependencies not resolving
```bash
# Clear UV cache
uv cache clean

# Try again
uv sync --refresh
```

### Issue: Lock file out of sync
```bash
# Regenerate lock file
rm uv.lock
uv lock

# Then sync
uv sync
```

### Issue: Python version conflicts
```bash
# Check current Python version
uv python list --only-installed

# Install required version
uv python install 3.12

# Pin to project
uv python pin 3.12
```

### Issue: Package conflicts
```bash
# Show dependency tree to identify conflicts
uv tree

# Try updating with conflict resolution
uv lock --upgrade
```

### Issue: Virtual environment corrupted
```bash
# Remove and recreate
rm -rf .venv
uv sync
```

## Advanced Features

### Working with Extras
```bash
# Install with specific extras
uv sync --extra dev --extra test

# Add dependency to extras group
uv add --optional docs sphinx
```

### Using UV with CI/CD
```bash
# In CI, use exact lock file
uv sync --frozen

# Don't update lock file
uv sync --locked
```

### Environment Variables
```bash
# Set UV cache directory
export UV_CACHE_DIR=/custom/cache/dir

# Disable cache
export UV_NO_CACHE=1

# Set custom index URL
export UV_INDEX_URL=https://custom.pypi.org/simple
```

### Global Tool Installation
```bash
# Install tool globally
uv tool install black

# Run global tool
uvx black .

# Update global tool
uv tool upgrade black

# Uninstall global tool
uv tool uninstall black
```

## Best Practices

1. **Always use uv.lock** - Commit it to version control for reproducible builds
2. **Use `uv add`** - Don't manually edit dependencies unless necessary
3. **Pin Python version** - Use `uv python pin` to ensure consistency
4. **Separate dev dependencies** - Use `--dev` flag for development tools
5. **Use extras for optional features** - Group related optional dependencies
6. **Run `uv sync` after pulling** - Ensure dependencies are up to date
7. **Build before release** - Always test `uv build` before publishing
8. **Use `uv run`** - Run scripts with `uv run` to use project environment

## Migration from Other Tools

### From pip + requirements.txt
```bash
# Convert requirements.txt to pyproject.toml
uv add $(cat requirements.txt)

# Or import directly
uv pip install -r requirements.txt
uv pip freeze | uv add
```

### From Poetry
```bash
# UV can read poetry.lock and pyproject.toml
uv sync

# Dependencies are already in pyproject.toml
```

### From Pipenv
```bash
# Export from Pipenv
pipenv requirements > requirements.txt

# Import to UV
uv add $(cat requirements.txt)
```

## Common Workflows

### Starting a New Project
```bash
uv init my-project
cd my-project
uv python pin 3.12
uv add requests sqlalchemy
uv add --dev pytest black ruff
uv sync
```

### Contributing to Existing Project
```bash
git clone <repo>
cd <repo>
uv sync
# Make changes
uv run pytest
uv build
```

### Creating a CLI Tool
```bash
uv init my-cli-tool
cd my-cli-tool

# Add dependencies
uv add click

# Edit pyproject.toml to add entry point
# [project.scripts]
# my-tool = "my_cli_tool.main:cli"

# Test it
uv run my-tool

# Build and publish
uv build
uv publish
```

## Additional Resources

- [UV Documentation](https://docs.astral.sh/uv/)
- [GitHub Repository](https://github.com/astral-sh/uv)
- [Python Packaging Guide](https://packaging.python.org/)
- [pyproject.toml Specification (PEP 621)](https://peps.python.org/pep-0621/)

---

*UV is actively developed by Astral, the creators of Ruff.*
