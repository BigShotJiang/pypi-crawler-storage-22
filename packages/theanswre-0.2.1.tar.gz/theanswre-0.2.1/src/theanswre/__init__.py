__version__ = "0.1.0"

print(42)