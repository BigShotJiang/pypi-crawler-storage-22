__version__ = "0.1.0"

print("__init__ 42")