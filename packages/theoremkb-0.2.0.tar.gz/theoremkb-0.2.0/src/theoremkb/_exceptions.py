class TheoremKBError(Exception):
    """Base exception for theoremkb."""


class UnknownDatasetError(TheoremKBError):
    """Raised when the requested dataset name is unknown."""


class InvalidSplitError(TheoremKBError):
    """Raised when the requested split does not exist for a dataset."""


class TrustRemoteCodeRequiredError(TheoremKBError):
    """Raised when a dataset requires trust_remote_code=True."""


class UnsupportedFormatError(TheoremKBError):
    """Raised when output format is unsupported."""
