from __future__ import annotations

from collections.abc import Sequence
from typing import Any


def _require_datasets():
    try:
        import datasets  # type: ignore[import]
    except ImportError as exc:  # pragma: no cover - import guard
        raise ImportError(
            "The 'datasets' package is required. Install with `pip install theoremkb`."
        ) from exc
    return datasets


def _raise_if_dataset_script_error(exc: Exception, dataset_path: str | None) -> None:
    message = str(exc)
    if "Dataset scripts are no longer supported" not in message:
        return
    hint = (
        "This dataset currently requires legacy Hugging Face dataset scripts. "
        "Install a compatible version with `pip install \"datasets<3\"` "
        "or recreate your environment from theoremkb's pinned dependencies."
    )
    if dataset_path:
        hint = f"Failed dataset: '{dataset_path}'. {hint}"
    raise RuntimeError(hint) from exc


def _raise_if_network_or_ssl_error(exc: Exception, dataset_path: str | None) -> None:
    err_type = exc.__class__.__name__.lower()
    message = str(exc).lower()
    looks_like_network_error = (
        "connecterror" in err_type
        or "sslerror" in err_type
        or "networkerror" in err_type
        or "timeout" in err_type
        or "unexpected_eof_while_reading" in message
        or "certificate verify failed" in message
        or "failed to establish a new connection" in message
        or "nodename nor servname provided" in message
        or "name or service not known" in message
    )
    if not looks_like_network_error:
        return
    prefix = f"Failed dataset: '{dataset_path}'. " if dataset_path else ""
    hint = (
        f"{prefix}Network/TLS connection to Hugging Face failed. "
        "Check your VPN/proxy/firewall and local certificates. "
        "If you use a proxy, set HTTPS_PROXY/HTTP_PROXY and REQUESTS_CA_BUNDLE. "
        "Temporary workaround for debugging only: set HF_HUB_DISABLE_SSL_VERIFICATION=1."
    )
    raise RuntimeError(hint) from exc


def load_dataset(**kwargs: Any) -> Any:
    datasets = _require_datasets()
    try:
        return datasets.load_dataset(**kwargs)
    except Exception as exc:
        _raise_if_dataset_script_error(exc, kwargs.get("path"))
        _raise_if_network_or_ssl_error(exc, kwargs.get("path"))
        raise


def get_dataset_split_names(**kwargs: Any) -> Sequence[str]:
    datasets = _require_datasets()
    try:
        return datasets.get_dataset_split_names(**kwargs)
    except Exception as exc:
        _raise_if_dataset_script_error(exc, kwargs.get("path"))
        _raise_if_network_or_ssl_error(exc, kwargs.get("path"))
        raise
