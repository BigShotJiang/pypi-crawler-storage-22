from __future__ import annotations

from itertools import islice
from pathlib import Path
from typing import Any, Literal

from ._exceptions import (
    InvalidSplitError,
    TrustRemoteCodeRequiredError,
    UnsupportedFormatError,
)
from . import hf_adapter
from .registry import get_dataset_spec

ReturnFormat = Literal["datasets", "records", "pandas"]

_VALID_FORMATS = {"datasets", "records", "pandas"}
_SPLIT_ALIASES = {
    "dev": "validation",
    "valid": "validation",
    "val": "validation",
}


def _normalize_split(split: str | None) -> str | None:
    if split is None:
        return None
    normalized = split.strip().lower()
    if not normalized:
        return None
    if normalized in {"all", "*"}:
        return None
    return _SPLIT_ALIASES.get(normalized, normalized)


def _path_to_str(path: str | Path | None) -> str | None:
    if path is None:
        return None
    return str(path)


def _ensure_remote_code_permission(name: str, trust_remote_code: bool) -> None:
    spec = get_dataset_spec(name)
    if spec.requires_trust_remote_code and not trust_remote_code:
        raise TrustRemoteCodeRequiredError(
            f"Dataset '{name}' requires trust_remote_code=True."
        )


def available_splits(
    dataset: str,
    *,
    subset: str | None = None,
    revision: str | None = None,
    token: str | bool | None = None,
    trust_remote_code: bool = False,
) -> tuple[str, ...]:
    spec = get_dataset_spec(dataset)
    _ensure_remote_code_permission(dataset, trust_remote_code)
    resolved_subset = subset if subset is not None else spec.default_subset
    try:
        splits = hf_adapter.get_dataset_split_names(
            path=spec.huggingface_id,
            config_name=resolved_subset,
            revision=revision,
            token=token,
            trust_remote_code=trust_remote_code,
        )
        return tuple(splits)
    except Exception:
        if spec.fallback_splits is not None:
            return spec.fallback_splits
        raise


def load(
    dataset: str,
    *,
    split: str | None = None,
    subset: str | None = None,
    cache_dir: str | Path | None = None,
    revision: str | None = None,
    token: str | bool | None = None,
    force_download: bool = False,
    streaming: bool = False,
    trust_remote_code: bool = False,
    shuffle: bool = False,
    seed: int = 42,
    max_samples: int | None = None,
    as_format: ReturnFormat = "datasets",
    drop_empty_fields: bool = True,
    validate_split: bool = True,
) -> Any:
    if as_format not in _VALID_FORMATS:
        raise UnsupportedFormatError(
            f"Unsupported as_format '{as_format}'. "
            "Use one of: datasets, records, pandas."
        )
    if max_samples is not None and max_samples <= 0:
        raise ValueError("max_samples must be a positive integer.")
    if streaming and as_format == "datasets" and max_samples is not None:
        raise ValueError(
            "max_samples is not supported with streaming=True and as_format='datasets'. "
            "Use as_format='records' or 'pandas' for bounded materialization."
        )
    if streaming and as_format in {"records", "pandas"} and max_samples is None:
        raise ValueError(
            "When streaming=True and as_format is records/pandas, set max_samples."
        )

    spec = get_dataset_spec(dataset)
    _ensure_remote_code_permission(dataset, trust_remote_code)
    resolved_subset = subset if subset is not None else spec.default_subset
    resolved_split = _normalize_split(split)

    if validate_split and resolved_split is not None:
        splits = available_splits(
            dataset,
            subset=resolved_subset,
            revision=revision,
            token=token,
            trust_remote_code=trust_remote_code,
        )
        if resolved_split not in set(splits):
            raise InvalidSplitError(
                f"Split '{resolved_split}' not found for '{dataset}'. "
                f"Available splits: {', '.join(splits)}."
            )

    download_mode = "force_redownload" if force_download else "reuse_dataset_if_exists"
    loaded = hf_adapter.load_dataset(
        path=spec.huggingface_id,
        name=resolved_subset,
        split=resolved_split,
        cache_dir=_path_to_str(cache_dir),
        revision=revision,
        token=token,
        download_mode=download_mode,
        streaming=streaming,
        trust_remote_code=trust_remote_code,
    )

    processed = _post_process(
        loaded,
        shuffle=shuffle,
        seed=seed,
        max_samples=max_samples,
        streaming=streaming,
    )
    return _convert_format(
        processed,
        as_format=as_format,
        max_samples=max_samples,
        streaming=streaming,
        drop_empty_fields=drop_empty_fields,
    )


def _post_process(
    dataset_obj: Any,
    *,
    shuffle: bool,
    seed: int,
    max_samples: int | None,
    streaming: bool,
) -> Any:
    if isinstance(dataset_obj, dict):
        return {
            split_name: _post_process_single(
                split_dataset,
                shuffle=shuffle,
                seed=seed,
                max_samples=max_samples,
                streaming=streaming,
            )
            for split_name, split_dataset in dataset_obj.items()
        }
    return _post_process_single(
        dataset_obj,
        shuffle=shuffle,
        seed=seed,
        max_samples=max_samples,
        streaming=streaming,
    )


def _post_process_single(
    dataset_obj: Any,
    *,
    shuffle: bool,
    seed: int,
    max_samples: int | None,
    streaming: bool,
) -> Any:
    current = dataset_obj
    if shuffle and hasattr(current, "shuffle"):
        current = current.shuffle(seed=seed)
    if max_samples is not None and not streaming and hasattr(current, "select"):
        limit = min(max_samples, len(current))
        current = current.select(range(limit))
    return current


def _convert_format(
    dataset_obj: Any,
    *,
    as_format: ReturnFormat,
    max_samples: int | None,
    streaming: bool,
    drop_empty_fields: bool,
) -> Any:
    if as_format == "datasets":
        return dataset_obj
    if as_format == "records":
        return _to_records(
            dataset_obj,
            max_samples=max_samples,
            streaming=streaming,
            drop_empty_fields=drop_empty_fields,
        )
    return _to_pandas(
        dataset_obj,
        max_samples=max_samples,
        streaming=streaming,
        drop_empty_fields=drop_empty_fields,
    )


def _to_records(
    dataset_obj: Any,
    *,
    max_samples: int | None,
    streaming: bool,
    drop_empty_fields: bool,
) -> Any:
    if isinstance(dataset_obj, dict):
        return {
            split_name: _to_records_single(
                split_dataset,
                max_samples=max_samples,
                streaming=streaming,
                drop_empty_fields=drop_empty_fields,
            )
            for split_name, split_dataset in dataset_obj.items()
        }
    return _to_records_single(
        dataset_obj,
        max_samples=max_samples,
        streaming=streaming,
        drop_empty_fields=drop_empty_fields,
    )


def _to_records_single(
    dataset_obj: Any,
    *,
    max_samples: int | None,
    streaming: bool,
    drop_empty_fields: bool,
) -> list[dict[str, Any]]:
    if streaming:
        if max_samples is None:
            raise ValueError("max_samples is required for streaming conversion to records.")
        records = list(islice(iter(dataset_obj), max_samples))
        return _drop_empty_fields(records) if drop_empty_fields else records

    if max_samples is not None and hasattr(dataset_obj, "select"):
        limit = min(max_samples, len(dataset_obj))
        dataset_obj = dataset_obj.select(range(limit))
    if hasattr(dataset_obj, "to_list"):
        records = dataset_obj.to_list()
    else:
        records = list(dataset_obj)
    return _drop_empty_fields(records) if drop_empty_fields else records


def _drop_empty_fields(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {key: value for key, value in record.items() if value not in ("", None)}
        for record in records
    ]


def _to_pandas(
    dataset_obj: Any,
    *,
    max_samples: int | None,
    streaming: bool,
    drop_empty_fields: bool,
) -> Any:
    try:
        import pandas as pd  # type: ignore[import]
    except ImportError as exc:
        raise ImportError(
            "pandas is required for as_format='pandas'. "
            "Install with `pip install theoremkb[pandas]`."
        ) from exc

    if isinstance(dataset_obj, dict):
        return {
            split_name: pd.DataFrame(
                _to_records_single(
                    split_dataset,
                    max_samples=max_samples,
                    streaming=streaming,
                    drop_empty_fields=drop_empty_fields,
                )
            )
            for split_name, split_dataset in dataset_obj.items()
        }
    return pd.DataFrame(
        _to_records_single(
            dataset_obj,
            max_samples=max_samples,
            streaming=streaming,
            drop_empty_fields=drop_empty_fields,
        )
    )


def load_esnli(
    *,
    split: str | None = None,
    subset: str | None = None,
    cache_dir: str | Path | None = None,
    revision: str | None = None,
    token: str | bool | None = None,
    force_download: bool = False,
    streaming: bool = False,
    trust_remote_code: bool = False,
    shuffle: bool = False,
    seed: int = 42,
    max_samples: int | None = None,
    as_format: ReturnFormat = "datasets",
    drop_empty_fields: bool = True,
    validate_split: bool = True,
) -> Any:
    return load(
        "esnli",
        split=split,
        subset=subset,
        cache_dir=cache_dir,
        revision=revision,
        token=token,
        force_download=force_download,
        streaming=streaming,
        trust_remote_code=trust_remote_code,
        shuffle=shuffle,
        seed=seed,
        max_samples=max_samples,
        as_format=as_format,
        drop_empty_fields=drop_empty_fields,
        validate_split=validate_split,
    )


def load_qasc(
    *,
    split: str | None = None,
    subset: str | None = None,
    cache_dir: str | Path | None = None,
    revision: str | None = None,
    token: str | bool | None = None,
    force_download: bool = False,
    streaming: bool = False,
    trust_remote_code: bool = False,
    shuffle: bool = False,
    seed: int = 42,
    max_samples: int | None = None,
    as_format: ReturnFormat = "datasets",
    drop_empty_fields: bool = True,
    validate_split: bool = True,
) -> Any:
    return load(
        "qasc",
        split=split,
        subset=subset,
        cache_dir=cache_dir,
        revision=revision,
        token=token,
        force_download=force_download,
        streaming=streaming,
        trust_remote_code=trust_remote_code,
        shuffle=shuffle,
        seed=seed,
        max_samples=max_samples,
        as_format=as_format,
        drop_empty_fields=drop_empty_fields,
        validate_split=validate_split,
    )


def load_worldtree(
    *,
    split: str | None = None,
    subset: str | None = None,
    cache_dir: str | Path | None = None,
    revision: str | None = None,
    token: str | bool | None = None,
    force_download: bool = False,
    streaming: bool = False,
    trust_remote_code: bool = False,
    shuffle: bool = False,
    seed: int = 42,
    max_samples: int | None = None,
    as_format: ReturnFormat = "datasets",
    drop_empty_fields: bool = True,
    validate_split: bool = True,
) -> Any:
    return load(
        "worldtree",
        split=split,
        subset=subset,
        cache_dir=cache_dir,
        revision=revision,
        token=token,
        force_download=force_download,
        streaming=streaming,
        trust_remote_code=trust_remote_code,
        shuffle=shuffle,
        seed=seed,
        max_samples=max_samples,
        as_format=as_format,
        drop_empty_fields=drop_empty_fields,
        validate_split=validate_split,
    )

