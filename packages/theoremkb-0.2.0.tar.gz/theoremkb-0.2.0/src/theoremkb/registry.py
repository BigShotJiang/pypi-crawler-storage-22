from __future__ import annotations

from dataclasses import dataclass
from typing import Final

from ._exceptions import UnknownDatasetError


@dataclass(frozen=True, slots=True)
class DatasetSpec:
    key: str
    huggingface_id: str
    aliases: tuple[str, ...]
    default_subset: str | None = None
    requires_trust_remote_code: bool = False
    fallback_splits: tuple[str, ...] | None = None


DATASET_REGISTRY: Final[dict[str, DatasetSpec]] = {
    "esnli": DatasetSpec(
        key="esnli",
        huggingface_id="esnli/esnli",
        aliases=("esnli", "e-snli", "e_snli"),
        requires_trust_remote_code=True,
    ),
    "qasc": DatasetSpec(
        key="qasc",
        huggingface_id="allenai/qasc",
        aliases=("qasc",),
    ),
    "worldtree": DatasetSpec(
        key="worldtree",
        huggingface_id="nguyen-brat/worldtree",
        aliases=("worldtree", "world tree", "world-tree"),
    ),
}


def _normalize_dataset_name(name: str) -> str:
    if not name or not name.strip():
        raise UnknownDatasetError("Dataset name cannot be empty.")
    return "".join(ch for ch in name.strip().lower() if ch.isalnum())


ALIAS_TO_KEY: Final[dict[str, str]] = {
    _normalize_dataset_name(alias): key
    for key, spec in DATASET_REGISTRY.items()
    for alias in spec.aliases
}


def list_datasets() -> tuple[str, ...]:
    return tuple(DATASET_REGISTRY.keys())


def get_dataset_spec(name: str) -> DatasetSpec:
    normalized = _normalize_dataset_name(name)
    key = ALIAS_TO_KEY.get(normalized)
    if key is None:
        supported = ", ".join(sorted(list_datasets()))
        raise UnknownDatasetError(
            f"Unknown dataset '{name}'. Supported datasets: {supported}."
        )
    return DATASET_REGISTRY[key]
