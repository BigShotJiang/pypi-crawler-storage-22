import pytest

from theoremkb import hf_adapter


class _FakeDatasets:
    @staticmethod
    def load_dataset(**kwargs):  # noqa: ARG004
        raise RuntimeError("Dataset scripts are no longer supported, but found esnli.py")

    @staticmethod
    def get_dataset_split_names(**kwargs):  # noqa: ARG004
        raise RuntimeError("Dataset scripts are no longer supported, but found esnli.py")


class _FakeDatasetsNetwork:
    @staticmethod
    def load_dataset(**kwargs):  # noqa: ARG004
        raise Exception("[SSL: UNEXPECTED_EOF_WHILE_READING] EOF occurred in violation of protocol")

    @staticmethod
    def get_dataset_split_names(**kwargs):  # noqa: ARG004
        raise Exception("[SSL: UNEXPECTED_EOF_WHILE_READING] EOF occurred in violation of protocol")


def test_load_dataset_rewrites_script_error(monkeypatch):
    monkeypatch.setattr(hf_adapter, "_require_datasets", lambda: _FakeDatasets)
    with pytest.raises(RuntimeError, match="pip install \"datasets<3\""):
        hf_adapter.load_dataset(path="esnli/esnli")


def test_get_split_names_rewrites_script_error(monkeypatch):
    monkeypatch.setattr(hf_adapter, "_require_datasets", lambda: _FakeDatasets)
    with pytest.raises(RuntimeError, match="Failed dataset: 'esnli/esnli'"):
        hf_adapter.get_dataset_split_names(path="esnli/esnli")


def test_load_dataset_rewrites_network_error(monkeypatch):
    monkeypatch.setattr(hf_adapter, "_require_datasets", lambda: _FakeDatasetsNetwork)
    with pytest.raises(RuntimeError, match="Network/TLS connection to Hugging Face failed"):
        hf_adapter.load_dataset(path="allenai/qasc")


def test_get_split_names_rewrites_network_error(monkeypatch):
    monkeypatch.setattr(hf_adapter, "_require_datasets", lambda: _FakeDatasetsNetwork)
    with pytest.raises(RuntimeError, match="HF_HUB_DISABLE_SSL_VERIFICATION=1"):
        hf_adapter.get_dataset_split_names(path="allenai/qasc")
