import inspect

import pytest

from theoremkb._exceptions import InvalidSplitError, TrustRemoteCodeRequiredError
from theoremkb import loader


class FakeDataset:
    def __init__(self, rows):
        self.rows = list(rows)

    def __len__(self):
        return len(self.rows)

    def __iter__(self):
        return iter(self.rows)

    def shuffle(self, seed=42):  # noqa: ARG002
        return FakeDataset(list(reversed(self.rows)))

    def select(self, indices):
        return FakeDataset([self.rows[i] for i in indices])

    def to_list(self):
        return list(self.rows)


class FakeStreamDataset:
    def __init__(self, rows):
        self.rows = list(rows)

    def __iter__(self):
        return iter(self.rows)

    def shuffle(self, seed=42):  # noqa: ARG002
        return self


def _install_backend(monkeypatch, dataset_obj):
    calls = {}

    def fake_get_splits(**kwargs):
        calls["splits_kwargs"] = kwargs
        return ("train", "validation", "test")

    def fake_load_dataset(**kwargs):
        calls["load_kwargs"] = kwargs
        return dataset_obj

    monkeypatch.setattr(loader.hf_adapter, "get_dataset_split_names", fake_get_splits)
    monkeypatch.setattr(loader.hf_adapter, "load_dataset", fake_load_dataset)
    return calls


def test_loader_wrappers_share_the_same_signature():
    functions = [
        loader.load_esnli,
        loader.load_qasc,
        loader.load_worldtree,
    ]
    first = inspect.signature(functions[0])
    for function in functions[1:]:
        assert inspect.signature(function) == first


def test_split_alias_is_normalized(monkeypatch):
    calls = _install_backend(
        monkeypatch,
        FakeDataset([{"id": 1}, {"id": 2}]),
    )

    result = loader.load_qasc(
        split="dev",
        as_format="records",
        max_samples=1,
    )

    assert len(result) == 1
    assert calls["load_kwargs"]["split"] == "validation"


def test_invalid_split_raises(monkeypatch):
    _install_backend(monkeypatch, FakeDataset([{"id": 1}]))

    with pytest.raises(InvalidSplitError):
        loader.load_qasc(split="unknown-split")


def test_esnli_requires_trust_remote_code():
    with pytest.raises(TrustRemoteCodeRequiredError):
        loader.load_esnli(split="train")


def test_streaming_records_requires_max_samples(monkeypatch):
    _install_backend(monkeypatch, FakeStreamDataset([{"id": 1}, {"id": 2}]))

    with pytest.raises(ValueError):
        loader.load_qasc(streaming=True, as_format="records")


def test_dict_output_conversion(monkeypatch):
    fake_dict = {
        "train": FakeDataset([{"x": 1}, {"x": 2}]),
        "validation": FakeDataset([{"x": 3}, {"x": 4}]),
    }
    _install_backend(monkeypatch, fake_dict)

    result = loader.load_qasc(
        split=None,
        validate_split=False,
        as_format="records",
        max_samples=1,
    )

    assert set(result.keys()) == {"train", "validation"}
    assert len(result["train"]) == 1
    assert len(result["validation"]) == 1


def test_drop_empty_fields_default_true(monkeypatch):
    _install_backend(
        monkeypatch,
        FakeDataset(
            [
                {"a": 1, "b": "", "c": None},
            ]
        ),
    )
    result = loader.load_qasc(
        split="train",
        as_format="records",
        max_samples=1,
    )
    assert result == [{"a": 1}]


def test_drop_empty_fields_false_keeps_empty_values(monkeypatch):
    _install_backend(
        monkeypatch,
        FakeDataset(
            [
                {"a": 1, "b": "", "c": None},
            ]
        ),
    )
    result = loader.load_qasc(
        split="train",
        as_format="records",
        max_samples=1,
        drop_empty_fields=False,
    )
    assert result == [{"a": 1, "b": "", "c": None}]
