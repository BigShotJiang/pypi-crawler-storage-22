import pytest

from theoremkb._exceptions import UnknownDatasetError
from theoremkb.registry import get_dataset_spec, list_datasets


def test_list_datasets_has_expected_entries():
    expected = {
        "esnli",
        "qasc",
        "worldtree",
    }
    assert set(list_datasets()) == expected


@pytest.mark.parametrize(
    ("name", "expected_key"),
    [
        ("esnli", "esnli"),
        ("e-snli", "esnli"),
        ("world tree", "worldtree"),
        ("qasc", "qasc"),
    ],
)
def test_alias_resolution(name, expected_key):
    assert get_dataset_spec(name).key == expected_key


def test_unknown_dataset_raises():
    with pytest.raises(UnknownDatasetError):
        get_dataset_spec("not-a-real-dataset")
