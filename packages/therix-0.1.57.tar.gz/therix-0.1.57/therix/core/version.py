"""Version utilities for retrieving the current package version."""

from importlib.metadata import PackageNotFoundError, version


def get_current_version() -> str:
    """
    Get the current version of the therix package.

    Returns:
        str: The version string (e.g., "0.1.56").

    Raises:
        PackageNotFoundError: If the package is not installed.
    """
    library_name = 'therix'
    return version(library_name)


async def async_get_current_version() -> str:
    """
    Async wrapper for get_current_version() for use in async contexts.

    Returns:
        str: The version string (e.g., "0.1.56").

    Raises:
        PackageNotFoundError: If the package is not installed.
    """
    library_name = 'therix'
    return version(library_name)