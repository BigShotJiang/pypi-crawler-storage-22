"""Allow running theron as a module: python -m theron"""

from .main import main

if __name__ == "__main__":
    main()
