"""Dashboard module for Theron."""

from .api import create_dashboard_app

__all__ = ["create_dashboard_app"]
