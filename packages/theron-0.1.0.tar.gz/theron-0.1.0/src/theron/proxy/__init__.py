"""Proxy module for Theron."""

from .server import create_proxy_app

__all__ = ["create_proxy_app"]
