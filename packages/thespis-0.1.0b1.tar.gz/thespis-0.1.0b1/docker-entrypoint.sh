#!/bin/bash
set -e

rm -f /tmp/.X99-lock /tmp/.X11-unix/X99

echo "Starting Xvfb..."
Xvfb :99 -screen 0 1920x1080x24 -ac &
XVFB_PID=$!

sleep 2

if ! kill -0 $XVFB_PID 2>/dev/null; then
    echo "❌ Error: Xvfb failed to start"
    exit 1
fi

echo "✅ Xvfb started (PID: $XVFB_PID)"
echo "📺 Display: $DISPLAY"
echo ""

cleanup() {
    echo "🛑 Stopping Xvfb..."
    kill $XVFB_PID 2>/dev/null || true
    wait $XVFB_PID 2>/dev/null || true
    rm -f /tmp/.X99-lock /tmp/.X11-unix/X99
}
trap cleanup EXIT INT TERM

exec "$@"
