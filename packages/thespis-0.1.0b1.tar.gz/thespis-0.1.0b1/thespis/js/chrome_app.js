if (!globalThis.chrome) {
    // Basic structure for Chrome
    const installDetails = {
        InstallState: {
            DISABLED: 'disabled',
            INSTALLED: 'installed',
            NOT_INSTALLED: 'not_installed'
        },
        RunningState: {
            CANNOT_RUN: 'cannot_run',
            READY_TO_RUN: 'ready_to_run',
            RUNNING: 'running'
        },
        getDetails: function getDetails() {},
        getIsInstalled: function getIsInstalled() {},
        runningState: function runningState() {}
    };

    const runtime = {
        OnInstalledReason: {
            CHROME_UPDATE: 'chrome_update',
            INSTALL: 'install',
            SHARED_MODULE_UPDATE: 'shared_module_update',
            UPDATE: 'update'
        },
        OnRestartRequiredReason: {
            APP_UPDATE: 'app_update',
            OS_UPDATE: 'os_update',
            PERIODIC: 'periodic'
        },
        PlatformArch: {
            ARM: 'arm',
            ARM64: 'arm64',
            MIPS: 'mips',
            MIPS64: 'mips64',
            X86_32: 'x86-32',
            X86_64: 'x86-64'
        },
        PlatformNaclArch: {
            ARM: 'arm',
            MIPS: 'mips',
            MIPS64: 'mips64',
            X86_32: 'x86-32',
            X86_64: 'x86-64'
        },
        PlatformOs: {
            ANDROID: 'android',
            CROS: 'cros',
            LINUX: 'linux',
            MAC: 'mac',
            OPENBSD: 'openbsd',
            WIN: 'win'
        },
        RequestUpdateCheckStatus: {
            NO_UPDATE: 'no_update',
            THROTTLED: 'throttled',
            UPDATE_AVAILABLE: 'update_available'
        },
        connect: function connect() {},
        sendMessage: function sendMessage() {}
    };

    const chromeObj = {
        app: installDetails,
        runtime: runtime,
        // Add other properties as needed
        loadTimes: function() {},
        csi: function() {} 
    };
    
    // Use defineProperty to avoid enumeration if needed, but 'chrome' is usually enumerable
    Object.defineProperty(globalThis, 'chrome', {
        value: chromeObj,
        writable: true,
        enumerable: true,
        configurable: false // Often not configurable
    });
}

