/* CDP Console Detection Bypass */
// Some CDP detections rely on console.debug triggering serialization
// We override console methods to prevent CDP-specific serialization leaks

(function() {
    const noop = () => {};
    
    // Create isolated console methods that don't trigger CDP serialization
    const createIsolatedConsole = (originalMethod) => {
        return function(...args) {
            // Skip if being called in a suspicious context (detection script)
            // Call original but prevent deep serialization
            try {
                return originalMethod.apply(console, args);
            } catch(e) {
                // Silently fail
            }
        };
    };

    // Specifically target console.debug as it's commonly used in CDP detection
    const originalDebug = console.debug;
    console.debug = createIsolatedConsole(originalDebug);
    
    // Register as native
    if (globalThis.utils) {
        utils.registerMock(console.debug, 'function debug() { [native code] }');
    }
})();

// Override Error.prepareStackTrace to control stack trace generation
// This can prevent certain CDP detection techniques
(function() {
    // V8's Error.prepareStackTrace allows custom formatting
    // If we control this, we can hide traces that would reveal automation
    
    Object.defineProperty(Error, 'prepareStackTrace', {
        get: function() {
            // Return undefined to use default V8 formatting
            // Or return a custom function
            return undefined;
        },
        set: function(fn) {
            // Ignore attempts to set custom prepareStackTrace from detection scripts
            // This prevents them from using it to detect CDP
        },
        configurable: true,
        enumerable: false
    });
})();
