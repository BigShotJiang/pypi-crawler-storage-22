/* Early Worker Interception - Must run FIRST */
// This runs before any page script can save a Worker reference
(function() {
    const originalWorker = globalThis.Worker;
    if (!originalWorker) return;
    
    console.log('[Thespis Early] Intercepting Worker constructor');
    
    // Immediately replace Worker with a proxy that will be enhanced later
    const earlyProxy = function Worker(scriptURL, options) {
        console.log('[Thespis Early] Worker created:', scriptURL);
        
        // Check if bundle is ready
        const bundle = globalThis.__STEALTH_BUNDLE__;
        if (!bundle) {
            console.warn('[Thespis Early] Bundle not ready, creating normal worker');
            return new originalWorker(scriptURL, options);
        }
        
        // Bundle is ready, inject it
        if (typeof scriptURL === 'string') {
            let finalURL = scriptURL;
            if (!scriptURL.startsWith('blob:') && !scriptURL.startsWith('data:')) {
                finalURL = new URL(scriptURL, location.href).href;
            }
            
            const wrapperCode = `
                console.log('[Thespis Worker] Executing stealth bundle');
                ${bundle}
                console.log('[Thespis Worker] Bundle complete, loading original script');
                try {
                    importScripts("${finalURL}");
                } catch(e) {
                    console.error('[Thespis Worker] Failed to load script:', e);
                }
            `;
            
            const blob = new Blob([wrapperCode], { type: 'text/javascript' });
            return new originalWorker(URL.createObjectURL(blob), options);
        }
        
        return new originalWorker(scriptURL, options);
    };
    
    // Copy prototype
    earlyProxy.prototype = originalWorker.prototype;
    
    // Replace globally using defineProperty to prevent bypass
    Object.defineProperty(globalThis, 'Worker', {
        value: earlyProxy,
        writable: true,
        configurable: true,
        enumerable: false
    });
    
    console.log('[Thespis Early] Worker intercepted');
})();
