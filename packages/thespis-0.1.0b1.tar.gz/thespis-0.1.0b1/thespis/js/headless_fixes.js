/* Headless/Automation Signal Fixes */

// 1. Add taskbar/badge API (missing in headless) - MUST be on Navigator prototype
(function() {
    if (!navigator.setAppBadge) {
        const setAppBadgeFn = function(contents) {
            return Promise.resolve();
        };
        
        Object.defineProperty(Navigator.prototype, 'setAppBadge', {
            value: setAppBadgeFn,
            writable: true,
            enumerable: true,
            configurable: true
        });
        
        if (globalThis.utils) {
            utils.registerMock(setAppBadgeFn, 'function setAppBadge() { [native code] }');
        }
    }
    
    if (!navigator.clearAppBadge) {
        const clearAppBadgeFn = function() {
            return Promise.resolve();
        };
        
        Object.defineProperty(Navigator.prototype, 'clearAppBadge', {
            value: clearAppBadgeFn,
            writable: true,
            enumerable: true,
            configurable: true
        });
        
        if (globalThis.utils) {
            utils.registerMock(clearAppBadgeFn, 'function clearAppBadge() { [native code] }');
        }
    }
})();

// 2. Fix prefers-color-scheme to match system (default to dark on macOS)
(function() {
    const originalMatchMedia = window.matchMedia;
    
    window.matchMedia = function(query) {
        const result = originalMatchMedia.call(window, query);
        
        // Override prefers-color-scheme to appear more realistic
        if (query.includes('prefers-color-scheme')) {
            // Most modern systems default to dark mode
            if (query.includes('dark')) {
                return {
                    ...result,
                    matches: true,
                    media: query
                };
            } else if (query.includes('light')) {
                return {
                    ...result,
                    matches: false,
                    media: query
                };
            }
        }
        
        return result;
    };
    
    if (globalThis.utils) {
        utils.registerMock(window.matchMedia, 'function matchMedia() { [native code] }');
    }
})();

// 3. Add missing Navigator APIs that appear in normal Chrome
(function() {
    // getUserMedia (if not present)
    if (!navigator.getUserMedia && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.getUserMedia = function(constraints, successCallback, errorCallback) {
            navigator.mediaDevices.getUserMedia(constraints)
                .then(successCallback)
                .catch(errorCallback);
        };
        
        if (globalThis.utils) {
            utils.registerMock(navigator.getUserMedia, 'function getUserMedia() { [native code] }');
        }
    }
    
    // webkitGetUserMedia (legacy)
    if (!navigator.webkitGetUserMedia && navigator.getUserMedia) {
        navigator.webkitGetUserMedia = navigator.getUserMedia;
    }
})();

// 4. Ensure navigator.plugins and mimeTypes are properly populated
// (Already should be handled by Chrome, but ensure they're not empty in headless)
(function() {
    // In headless Chrome, plugins/mimeTypes might be empty
    // We can't easily mock this as it's a complex PluginArray
    // But we can ensure the objects exist and have proper toString
    
    if (navigator.plugins && navigator.plugins.length === 0) {
        // Can't easily add fake plugins without breaking toString detection
        // Best to leave empty but ensure the object itself looks native
    }
    
    if (navigator.mimeTypes && navigator.mimeTypes.length === 0) {
        // Same for mimeTypes
    }
})();

// 5. Add ServiceWorker API enhancements
(function() {
    if (navigator.serviceWorker) {
        // Ensure serviceWorker.controller looks realistic
        // Most normal pages don't have a controller, so undefined is fine
    }
})();

// 6. Fix Notification.permission if it's in wrong state
(function() {
    if (typeof Notification !== 'undefined') {
        // Notification.permission is usually 'default', 'granted', or 'denied'
        // 'default' is most common for new sites
        // We already handle this in permissions.js
    }
})();
