// OffscreenCanvas WebGL Spoofing - IMMEDIATE EXECUTION
// Creepjs uses OffscreenCanvas in workers to test WebGL
// CRITICAL: This must run BEFORE any code tries to use OffscreenCanvas

(function() {
    console.log('[Thespis Worker] offscreen_canvas.js IIFE - scope:', typeof self, typeof window, typeof OffscreenCanvas);
    
    if (typeof OffscreenCanvas === 'undefined') {
        console.warn('[Thespis] OffscreenCanvas not available in this context');
        return;
    }
    
    console.log('[Thespis] Patching OffscreenCanvas.prototype.getContext...');
    
    const originalGetContext = OffscreenCanvas.prototype.getContext;
    
    if (!originalGetContext) {
        console.error('[Thespis] OffscreenCanvas.prototype.getContext not found!');
        return;
    }
    
    OffscreenCanvas.prototype.getContext = function(contextType, ...args) {
        console.log('[Thespis Worker] OffscreenCanvas.getContext called with:', contextType);
        const context = originalGetContext.apply(this, [contextType, ...args]);
        
        // Only patch WebGL contexts
        if (!context || (contextType !== 'webgl' && contextType !== 'webgl2')) {
            return context;
        }
        
        console.log('[Thespis Worker] Patching WebGL context from OffscreenCanvas');
        
        // Patch getParameter to hide SwiftShader
        const originalGetParameter = context.getParameter;
        context.getParameter = function(parameter) {
            const result = originalGetParameter.apply(this, arguments);
            
            // Log all renderer queries
            if (parameter === 37445 || parameter === 37446) {
                console.log('[Thespis Worker] getParameter', parameter, '=', result);
            }
            
            // UNMASKED_RENDERER_WEBGL (37446) - hide SwiftShader
            if (parameter === 37446 && result && /SwiftShader/i.test(result)) {
                console.log('[Thespis Worker] Hiding SwiftShader in OffscreenCanvas:', result);
                return result.replace(/SwiftShader/gi, 'Graphics');
            }
            
            return result;
        };
        
        // Also patch getExtension to ensure debug info works
        const originalGetExtension = context.getExtension;
        context.getExtension = function(name) {
            const ext = originalGetExtension.apply(this, arguments);
            if (name === 'WEBGL_debug_renderer_info' && ext) {
                console.log('[Thespis Worker] WEBGL_debug_renderer_info requested');
            }
            return ext;
        };
        
        console.log('[Thespis Worker] WebGL context patched successfully');
        return context;
    };
    
    console.log('[Thespis] OffscreenCanvas.prototype.getContext patched successfully!');
})();

