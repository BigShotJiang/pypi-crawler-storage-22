const originalQuery = window.navigator.permissions.query;
const queryMock = (parameters) => (
  parameters.name === 'notifications' ?
    Promise.resolve({ state: Notification.permission }) :
    originalQuery(parameters)
);

if (window.utils) {
    utils.replaceWithNative(window.navigator.permissions, 'query', queryMock);
} else {
    window.navigator.permissions.query = queryMock;
}
