/* Screen Resolution Fixes */
(function() {
    // Headless Chrome often has suspicious screen resolutions
    // Common headless: 800x600, 1024x768
    // We need realistic desktop resolutions
    
    // Check current screen dimensions
    const currentWidth = screen.width;
    const currentHeight = screen.height;
    
    // Common realistic resolutions: 1920x1080, 2560x1440, 1440x900 (MacBook)
    const realWidth = 1920;
    const realHeight = 1080;
    const realAvailWidth = 1920;
    const realAvailHeight = 1055; // MUST be less than height (taskbar/dock takes ~25-40px)
    
    try {
        Object.defineProperties(screen, {
            width: {
                get: () => realWidth,
                configurable: true
            },
            height: {
                get: () => realHeight,
                configurable: true
            },
            availWidth: {
                get: () => realAvailWidth,
                configurable: true
            },
            availHeight: {
                get: () => realAvailHeight,  // CRITICAL: Less than height
                configurable: true
            }
        });
        
        // Also update window.screen to return our mocked screen
        if (globalThis.utils) {
            const screenGetter = Object.getOwnPropertyDescriptor(window, 'screen')?.get;
            if (screenGetter) {
                utils.registerMock(screenGetter, 'function get screen() { [native code] }');
            }
        }
    } catch(e) {
        // If we can't override (some environments protect screen properties), fail silently
    }
})();

