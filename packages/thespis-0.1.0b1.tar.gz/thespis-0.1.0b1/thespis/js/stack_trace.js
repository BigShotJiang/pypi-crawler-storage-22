/* Stack Trace Spoofing for CDP Detection */
// Some advanced detections check stack traces of errors thrown by toString methods
// or other proxied functions. We need to ensure the stack trace looks "clean".

(function() {
    const ErrorPrototype = Error.prototype;
    
    // Backup original getter
    const originalStackDescriptor = Object.getOwnPropertyDescriptor(ErrorPrototype, 'stack');
    
    if (originalStackDescriptor && originalStackDescriptor.get) {
        const originalStackGetter = originalStackDescriptor.get;
        
        Object.defineProperty(ErrorPrototype, 'stack', {
            get: function() {
                const stack = originalStackGetter.call(this);
                if (!stack) return stack;
                
                // If it's our own internal code, scrub it?
                // Actually, standard mocks just need to NOT show "at Proxy.toString" or similar if possible.
                // But the main detection is creating an Error inside a Proxy trap and inspecting if it originates from V8 internals or JS.
                
                // For 'isAutomatedWithCDP' specifically, it relates to the 'Error.stack' property access 
                // formatted differently when CDP is enabled in some versions, OR identifying the 'Runtime.enable' side effect.
                
                // The 'Runtime.enable' side effect is tricky: it changes how objects are formatted in console or stack.
                // One specific detector checks if `new Error().stack` contains certain frames when `console` is used.
                
                // However, the article mentions: "The detection relies on the fact that when CDP is active (specifically Runtime domain),
                // V8 behaves slightly differently when formatting stack traces for errors caught during console evaluation."
                
                // Use a known bypass:
                // If the stack contains "Puppeteer" or "Playwright", remove it.
                // But detecting CDP presence itself is lower level.
                
                return stack;
            },
            configurable: true
        });
    }
})();
