
// Mock navigator.userAgentData
(() => {
  const majorVersion = "133";
  const fullVersion = "133.0.6943.53";
  
  const brands = [
    { brand: "Not(A:Brand", version: "99" },
    { brand: "Google Chrome", version: majorVersion },
    { brand: "Chromium", version: majorVersion }
  ];

  const fullVersionList = [
    { brand: "Not(A:Brand", version: "99.0.0.0" },
    { brand: "Google Chrome", version: fullVersion },
    { brand: "Chromium", version: fullVersion }
  ];

  const highEntropyValues = {
      architecture: "x86", // or arm
      bitness: "64",
      brands: brands,
      fullVersionList: fullVersionList,
      mobile: false,
      model: "",
      platform: "macOS",
      platformVersion: "14.4.1", // Adjust as needed
      uaFullVersion: fullVersion,
      wow64: false
  };

  // 1. Attempt to delete existing property on instance if it exists
  try {
      if (Object.prototype.hasOwnProperty.call(navigator, 'userAgentData')) {
          delete navigator.userAgentData;
      }
  } catch(e) {}

  // 2. Define on prototype using correct descriptor
  try {
    if (window.utils) {
        utils.mockGetter(Object.getPrototypeOf(navigator), 'userAgentData', function() {
            return {
                get brands() { return brands; },
                get mobile() { return false; },
                get platform() { return "macOS"; },
                toJSON: function() { 
                    return {
                        brands: brands,
                        mobile: false,
                        platform: "macOS"
                    };
                },
                getHighEntropyValues: function(hints) { 
                    return Promise.resolve(highEntropyValues);
                }
            };
        });
    } else {
        Object.defineProperty(Object.getPrototypeOf(navigator), 'userAgentData', {
            get: function() {
              return {
                get brands() { return brands; },
                get mobile() { return false; },
                get platform() { return "macOS"; },
                toJSON: function() { 
                    return {
                        brands: brands,
                        mobile: false,
                        platform: "macOS"
                    };
                },
                getHighEntropyValues: function(hints) { 
                    return Promise.resolve(highEntropyValues);
                }
              };
            },
            configurable: true,
            enumerable: true
        });
    }
  } catch(e) {
      console.error("Failed to spoof userAgentData:", e);
  }
})();
