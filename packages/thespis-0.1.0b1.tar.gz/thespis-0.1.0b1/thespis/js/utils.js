/* Ultra-Stealth Utils for Thespis */

// Instead of hooking Function.prototype.toString globally (which is detectable),
// we'll manually patch each function's toString property individually
// This is much harder to detect

const utils = {
  /**
   * Replaces a method/property with a value that mimics a native function.
   * Instead of global hook, we patch individual toString
   */
  replaceWithNative: (target, key, value) => {
    const nativeString = `function ${key}() { [native code] }`;
    
    // Patch the individual function's toString
    Object.defineProperty(value, 'toString', {
      value: function() { return nativeString; },
      writable: true,
      enumerable: false,
      configurable: true
    });
    
    // Also patch toSource if it exists (Firefox)
    if (value.toSource) {
      Object.defineProperty(value, 'toSource', {
        value: function() { return nativeString; },
        writable: true,
        enumerable: false,
        configurable: true
      });
    }

    Object.defineProperty(target, key, {
      value: value,
      writable: true,
      enumerable: false,
      configurable: true,
    });
  },
  
  /**
   * Mocks a getter. Patches its toString individually.
   */
  mockGetter: (target, key, getValueFn) => {
    const nativeString = `function get ${key}() { [native code] }`;
    
    Object.defineProperty(getValueFn, 'toString', {
      value: function() { return nativeString; },
      writable: true,
      enumerable: false,
      configurable: true
    });
    
    Object.defineProperty(target, key, {
      get: getValueFn,
      configurable: true,
      enumerable: true
    });
  },
  
  /**
   * Helper to manually register a function
   */
  registerMock: (fn, asString) => {
    Object.defineProperty(fn, 'toString', {
      value: function() { return asString; },
      writable: true,
      enumerable: false,
      configurable: true
    });
  }
};

// Polyfill window in workers
if (typeof window === 'undefined') {
    try {
        globalThis.window = globalThis;
    } catch (e) { }
}

globalThis.utils = utils;
