// Advanced Navigator.webdriver evasion
// Creepjs detects lies by checking Object.getOwnPropertyDescriptor inconsistencies

(function() {
    const webdriverValue = false;
    
    // Delete any existing webdriver property first
    try {
        delete Object.getPrototypeOf(navigator).webdriver;
        delete navigator.webdriver;
    } catch(e) {}
    
    // Define on Navigator.prototype (the "correct" location)
    try {
        Object.defineProperty(Object.getPrototypeOf(navigator), 'webdriver', {
            get: () => webdriverValue,
            set: () => {}, // Allow setting but ignore
            configurable: true,
            enumerable: true
        });
    } catch(e) {}
    
    // ALSO patch Object.getOwnPropertyDescriptor to hide our modification
    const originalGOPD = Object.getOwnPropertyDescriptor;
    Object.getOwnPropertyDescriptor = function(obj, prop) {
        const result = originalGOPD.apply(this, arguments);
        
        // If checking Navigator.prototype.webdriver, make it look completely native
        if (obj === Object.getPrototypeOf(navigator) && prop === 'webdriver') {
            // Return a descriptor that looks like it was never modified
            return {
                get: () => webdriverValue,
                set: undefined,
                configurable: true,
                enumerable: true
            };
        }
        
        return result;
    };
    
    // Register GOPD as native
    if (globalThis.utils) {
        utils.registerMock(Object.getOwnPropertyDescriptor, 'function getOwnPropertyDescriptor() { [native code] }');
    }
})();
