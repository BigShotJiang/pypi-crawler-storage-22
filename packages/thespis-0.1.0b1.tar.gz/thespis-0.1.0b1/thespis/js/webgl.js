// WebGL - Only hide SwiftShader, keep real GPU values
// This prevents fingerprint mismatch while still hiding automation
const getParameter = WebGLRenderingContext.prototype.getParameter;
const getParameter2 = WebGL2RenderingContext.prototype.getParameter;
const getExtension = WebGLRenderingContext.prototype.getExtension;
const getExtension2 = WebGL2RenderingContext.prototype.getExtension;

const parameterMock = function(parameter) {
  const result = getParameter.apply(this, arguments);
  
  // Only mask SwiftShader - keep all other real values
  if (parameter === 37445 && result && result.includes('Google')) {
    // UNMASKED_VENDOR_WEBGL - keep as is
    return result;
  }
  if (parameter === 37446 && result && /SwiftShader/i.test(result)) {
    // UNMASKED_RENDERER_WEBGL - only hide SwiftShader
    // Return a generic but believable renderer
    return result.replace(/SwiftShader/gi, 'Graphics');
  }
  
  return result;
};

const parameterMock2 = function(parameter) {
  const result = getParameter2.apply(this, arguments);
  
  // Same logic for WebGL2
  if (parameter === 37445 && result && result.includes('Google')) {
    return result;
  }
  if (parameter === 37446 && result && /SwiftShader/i.test(result)) {
    return result.replace(/SwiftShader/gi, 'Graphics');
  }
  
  return result;
};

// Keep extension handling simple
const extensionMock = function(name) {
    return getExtension.apply(this, arguments);
};

const extensionMock2 = function(name) {
    return getExtension2.apply(this, arguments);
};

if (window.utils) {
    utils.replaceWithNative(WebGLRenderingContext.prototype, 'getParameter', parameterMock);
    utils.replaceWithNative(WebGL2RenderingContext.prototype, 'getParameter', parameterMock2);
    utils.replaceWithNative(WebGLRenderingContext.prototype, 'getExtension', extensionMock);
    utils.replaceWithNative(WebGL2RenderingContext.prototype, 'getExtension', extensionMock2);
} else {
    WebGLRenderingContext.prototype.getParameter = parameterMock;
    WebGL2RenderingContext.prototype.getParameter = parameterMock2;
    WebGLRenderingContext.prototype.getExtension = extensionMock;
    WebGL2RenderingContext.prototype.getExtension = extensionMock2;
}



