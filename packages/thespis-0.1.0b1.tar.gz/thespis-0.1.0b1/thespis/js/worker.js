/* Worker Proxy for Thespis Stealth */
const originalWorker = globalThis.Worker;

if (originalWorker) {
    console.log('[Thespis] Worker proxy initialized');
    
    const WorkerProxy = function(scriptURL, options) {
        console.log('[Thespis] Worker constructor called with:', scriptURL, options);
        
        try {
            const bundle = globalThis.__STEALTH_BUNDLE__;
            if (!bundle) {
                console.warn('[Thespis] __STEALTH_BUNDLE__ not found');
                return new originalWorker(scriptURL, options);
            }
            
            console.log('[Thespis] Bundle found, length:', bundle.length);
            
            // Handle string URLs (most common case)
            if (typeof scriptURL === 'string') {
                let finalURL = scriptURL;
                
                // For relative/absolute URLs, make absolute
                if (!scriptURL.startsWith('blob:') && !scriptURL.startsWith('data:')) {
                    finalURL = new URL(scriptURL, location.href).href;
                }
                
                console.log('[Thespis] Creating worker with bundle injection');
                
                // Create wrapper that injects bundle before loading original script
                const wrapperCode = `
                    console.log('[Thespis Worker] Starting stealth injection');
                    ${bundle}
                    console.log('[Thespis Worker] Stealth bundle executed');
                    try {
                        importScripts("${finalURL}");
                        console.log('[Thespis Worker] Original script loaded');
                    } catch(e) {
                        console.error("[Thespis Worker] importScripts failed:", e);
                    }
                `;
                
                const blob = new Blob([wrapperCode], { type: 'text/javascript' });
                const blobURL = URL.createObjectURL(blob);
                console.log('[Thespis] Created blob URL:', blobURL);
                return new originalWorker(blobURL, options);
            }
        } catch (e) {
            console.error('[Thespis] Worker proxy error:', e);
        }
        
        // Fallback
        console.log('[Thespis] Using fallback - original worker');
        return new originalWorker(scriptURL, options);
    };
    
    // Copy prototype
    WorkerProxy.prototype = originalWorker.prototype;
    
    // Replace Worker constructor
    if (globalThis.utils) {
        utils.replaceWithNative(globalThis, 'Worker', WorkerProxy);
        console.log('[Thespis] Worker masked with utils');
    } else {
        globalThis.Worker = WorkerProxy;
        console.log('[Thespis] Worker replaced (no utils)');
    }
}


