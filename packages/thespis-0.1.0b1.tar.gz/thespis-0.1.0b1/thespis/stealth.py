import json
import os

from playwright.async_api import Page as PageAsync
from playwright.sync_api import Page as PageSync

# Determine the absolute path to the 'js' directory
SCRIPTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "js")


def _read_script(name: str) -> str:
    """Reads a JavaScript file from the 'js' directory."""
    path = os.path.join(SCRIPTS_DIR, name)
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        print(f"Warning: Script {name} not found in {SCRIPTS_DIR}")
        return ""


def apply_stealth(page):
    """
    Applies stealth JavaScript to the given page.
    Injects evasion scripts to mask automation signals.
    Works with both sync and async Page objects.

    IMPORTANT: For best results, launch browser with:
        browser = p.chromium.launch(
            args=['--disable-blink-features=AutomationControlled']
        )
    This prevents navigator.webdriver from being set without causing "lie" detection.

    The page.add_init_script calls run before page content loads,
    because add_init_script is not awaitable/is consistent.
    """
    # 0. Load all scripts and prepare bundle
    # Order matters: utils first, then console/devtools detection bypasses
    # NOTE: webdriver.js is NOT included - we use --disable-blink-features=AutomationControlled instead
    # NOTE: offscreen_canvas.js is injected SEPARATELY before the bundle for early execution
    scripts = [
        "utils.js",
        "console_cdp.js",
        "devtools.js",
        "screen.js",
        "headless_fixes.js",
        "chrome_app.js",
        "permissions.js",
        "user_agent.js",
        "webgl.js",
    ]
    bundle_parts = []

    for s in scripts:
        content = _read_script(s)
        # Don't wrap in try/catch - let errors surface for debugging
        bundle_parts.append(content)

    full_bundle = "\n".join(bundle_parts)

    # CRITICAL ORDER - Each script must inject at the right time:
    # 0. FIRST: Patch OffscreenCanvas before ANYTHING else (for workers)
    page.add_init_script(_read_script("offscreen_canvas.js"))

    # 1. Second: Inject early worker interceptor (before ANY page script can save Worker ref)
    page.add_init_script(_read_script("early_worker.js"))

    # 2. Define global bundle string for Worker injection
    bundle_json = json.dumps(full_bundle)
    page.add_init_script(f"window.__STEALTH_BUNDLE__ = {bundle_json};")

    # 3. Run the bundle in the Main Page
    page.add_init_script(full_bundle)

    # 4. Viewport adjustment
    # Don't set viewport to exact screen size - this triggers hasVvpScreenRes
    # Set to a common browser window size that's LESS than screen
    # Common: 1366x768, 1440x900, 1536x864 (not fullscreen)
    try:
        page.set_viewport_size({"width": 1366, "height": 768})
    except Exception:
        # Can fail if context was created with viewport=None (no fixed size)
        pass


def stealth_sync(page: PageSync):
    """Sync version of stealth"""
    apply_stealth(page)


async def stealth_async(page: PageAsync):
    """Async version of stealth"""
    apply_stealth(page)
