from typing import Optional, Dict

from pydantic import BaseModel, Field, ConfigDict


class DockerContainerMappings(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    directory_mappings: Dict[str, str] = Field(default_factory=dict, alias='directoryMappings')
    port_mappings: Dict[str, str] = Field(default_factory=dict, alias='portMappings')


class DockerContainerCreateRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    instance_rented_public_id: Optional[str] = Field(None, alias='instanceRentedPublicId')
    instance_rented_slug: Optional[str] = Field(None, alias='instanceRentedSlug')
    selfhosted_instance_public_id: Optional[str] = Field(None, alias='selfhostedInstancePublicId')
    selfhosted_instance_slug: Optional[str] = Field(None, alias='selfhostedInstanceSlug')
    project_public_id: Optional[str] = Field(..., alias='projectPublicId')
    project_slug: Optional[str] = Field(..., alias='projectSlug')
    container_slug: str = Field(..., alias='containerSlug')
    docker_image_id: int = Field(..., alias='dockerImageId')
    assigned_cpus: Optional[int] = Field(None, alias='assignedCpus')
    is_unlimited_cpus: bool = Field(False, alias='isUnlimitedCpus')
    assigned_gpus: Optional[int] = Field(None, alias='assignedGpus')
    is_unlimited_gpus: bool = Field(False, alias='isUnlimitedGpus')
    mappings: DockerContainerMappings = Field(default_factory=DockerContainerMappings, alias='mappings')
