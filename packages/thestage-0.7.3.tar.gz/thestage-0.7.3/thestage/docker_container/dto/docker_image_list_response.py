from typing import List, Optional

from pydantic import Field, ConfigDict

from thestage.docker_container.dto.container_response import DockerImageDto
from thestage.services.clients.thestage_api.dtos.base_response import TheStageBaseResponse
from thestage.services.clients.thestage_api.dtos.paginated_entity_list import PaginatedEntityList


class DockerImageListResponse(TheStageBaseResponse):
    model_config = ConfigDict(use_enum_values=True)

    paginatedList: PaginatedEntityList[DockerImageDto] = Field(None, alias='paginatedList')
