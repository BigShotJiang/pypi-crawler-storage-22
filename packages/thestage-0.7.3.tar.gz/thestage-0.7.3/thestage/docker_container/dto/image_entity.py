from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class DockerImageEntity(BaseModel):

    model_config = ConfigDict(
        populate_by_name=True,
        use_enum_values=True,
    )

    image: Optional[str] = Field(None, alias='IMAGE')
    tag: Optional[str] = Field(None, alias='TAG')
