from typing import Optional

from thestage.project.dto.project_entity import ProjectEntity
from thestage.project.dto.project_response import ProjectDto
from thestage.services.abstract_mapper import AbstractMapper

class ProjectMapper(AbstractMapper):

    def build_entity(self, item: ProjectDto) -> Optional[ProjectEntity]:
        if not item:
            return None

        return ProjectEntity(
            public_id=item.public_id or '',
            slug=item.slug or '',
            status=item.status or '',
            last_commit_hash=item.last_commit_hash or ''
        )