from typing import Dict

from pydantic import ConfigDict, Field

from thestage.project.dto.project_response import ProjectDto
from thestage.services.clients.thestage_api.dtos.base_response import TheStageBaseResponse
from thestage.services.clients.thestage_api.dtos.paginated_entity_list import PaginatedEntityList


class ProjectListResponse(TheStageBaseResponse):
    model_config = ConfigDict(use_enum_values=True)

    paginatedList: PaginatedEntityList[ProjectDto] = Field(None, alias='paginatedList')

class ProjectBusinessStatusMapperResponse(TheStageBaseResponse):
    model_config = ConfigDict(use_enum_values=True)
    project_business_status_map: Dict[str, str] = Field(default={}, alias='projectStatusMap')