from typing import Optional, List

from pydantic import BaseModel, Field


class TheStageBaseResponse(BaseModel):
    message: Optional[str] = Field(None, alias='message')
    isSuccess: Optional[bool] = Field(None, alias='isSuccess')
    fieldsWithError: List[str] = Field(None, alias='fieldsWithError')


# TODO: add Generic then back doing that
class TheStageBasePaginatedResponse(TheStageBaseResponse):
    fieldsWithError: List[str] = Field(None, alias='fieldsWithError')
