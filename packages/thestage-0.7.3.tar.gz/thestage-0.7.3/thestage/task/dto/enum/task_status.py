from enum import Enum
from typing import List

# TODO reduce usage of statuses to zero
class TaskStatus(str, Enum):
    NEW: str = 'NEW'
    SCHEDULED: str = 'SCHEDULED'
    RUNNING: str = 'RUNNING'
    FINISHED: str = 'FINISHED'
    CANCELING: str = 'CANCELING'
    CANCELED: str = 'CANCELED'
    FAILED: str = 'FAILED'
