"""Things MCP - Model Context Protocol server for Things 3 task management app."""

from .server import mcp

__all__ = ["mcp"]
