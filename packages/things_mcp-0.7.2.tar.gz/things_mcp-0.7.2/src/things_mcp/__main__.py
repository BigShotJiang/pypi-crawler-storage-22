"""Entry point for running things-mcp as a module or via uvx."""

from .server import main

if __name__ == "__main__":
    main()
