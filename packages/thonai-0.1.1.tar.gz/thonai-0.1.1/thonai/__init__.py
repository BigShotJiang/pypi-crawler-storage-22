import huggingface_hub as _hf

from .hub import ThonHub
from .auth import thon_login

# реэкспорт нужных вещей явно
HfApi = _hf.HfApi
snapshot_download = _hf.snapshot_download

__all__ = [
    "ThonHub",
    "thon_login",
    "HfApi",
    "snapshot_download",
]
