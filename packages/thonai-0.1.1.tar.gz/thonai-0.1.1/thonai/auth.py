from huggingface_hub import login


def thon_login(token: str):
    login(token=token)
