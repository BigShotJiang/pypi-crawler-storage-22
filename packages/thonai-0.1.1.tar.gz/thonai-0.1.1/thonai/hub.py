from huggingface_hub import HfApi


class ThonHub:
    def __init__(self, token: str | None = None):
        self.api = HfApi(token=token)

    def list_models(self, limit: int = 10):
        return list(self.api.list_models(limit=limit))

    def model_info(self, model_id: str):
        return self.api.model_info(model_id)

    def list_datasets(self, limit: int = 10):
        return list(self.api.list_datasets(limit=limit))
