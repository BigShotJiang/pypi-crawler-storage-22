import huggingface_hub as _hf

from .hub import ThonHub
from .auth import thon_login

HfApi = _hf.HfApi
snapshot_download = _hf.snapshot_download
InferenceClient = _hf.InferenceClient  # ← добавляем

del _hf

__all__ = [
    "ThonHub",
    "thon_login",
    "HfApi",
    "snapshot_download",
    "InferenceClient",  # ← добавляем
]
