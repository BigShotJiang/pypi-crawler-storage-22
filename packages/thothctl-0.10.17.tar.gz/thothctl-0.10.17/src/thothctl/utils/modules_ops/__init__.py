"""Module operations utilities."""
