import os
import sys
import queue
import unittest
import argparse
from unittest.mock import patch
from unittest.mock import call
from unittest.mock import Mock
from thread_order.scheduler import (
    Scheduler,dmark, mark, TaskStatus, _split_target, _load_module, _collect_functions, load_and_collect_functions)

class TestScheduler(unittest.TestCase):

    @patch('thread_order.scheduler.configure_logging')
    def test_init_setup_logging(self, configure_logging_patch, *patches):
        Scheduler(setup_logging=True)
        configure_logging_patch.assert_called_once()

    def test_register_ValueError(self, *patches):
        s = Scheduler(workers=2)
        with self.assertRaises(ValueError):
            s.register('not_callable', 'not_callable')

    def test_register(self, *patches):
        s = Scheduler(workers=2)

        def sample_task():
            pass

        s.register(sample_task, 'task1')
        self.assertIn('task1', s._callables)
        self.assertIn('task1', s.graph.nodes())

    @patch('thread_order.scheduler.Scheduler.register')
    def test_dregister_with_state(self, register_patch, *patches):
        mock_function = Mock(__name__='mock_function')
        s = Scheduler()
        decorated_function = s.dregister(with_state=True)(mock_function)
        result = decorated_function()
        register_patch.assert_called_once_with(decorated_function, 'mock_function', after=None, with_state=True)
        self.assertEqual(decorated_function.__original__, mock_function)
        self.assertEqual(result, mock_function.return_value)

    @patch('thread_order.scheduler.Scheduler.register')
    def test_dregister_defaults(self, register_patch, *patches):
        mock_function = Mock(__name__ = 'mock_function2')
        s = Scheduler()
        decorated_function = s.dregister()(mock_function)
        register_patch.assert_called_once_with(decorated_function, 'mock_function2', after=None, with_state=False)
        self.assertEqual(decorated_function.__original__, mock_function)

    @patch('thread_order.scheduler.Scheduler.register')
    def test_dregister_with_after(self, register_patch, *patches):
        mock_function = Mock(__name__ = 'mock_function3')
        s = Scheduler()
        decorated_function = s.dregister(after=['dep1'], with_state=True)(mock_function)
        register_patch.assert_called_once_with(decorated_function, 'mock_function3', after=['dep1'], with_state=True)
        self.assertEqual(decorated_function.__original__, mock_function)

    @patch('thread_order.scheduler.Scheduler._submit')
    def test_maybe_schedule_next_NoFree(self, submit_patch, *patches):
        s = Scheduler(workers=1)
        s._active.add('task')
        s._maybe_schedule_next(Mock())
        self.assertEqual(len(s._active), 1)
        submit_patch.assert_not_called()

    @patch('thread_order.scheduler.Scheduler._submit')
    def test_maybe_schedule_next_When_NoSkip(self, submit_patch, *patches):
        s = Scheduler(workers=2)
        graph_mock = Mock()
        graph_mock.get_candidates.return_value = ['task1', 'task2']
        s._graph = graph_mock
        s._maybe_schedule_next(Mock())
        submit_patch.assert_has_calls([call('task1'), call('task2')])

    @patch('thread_order.scheduler.Scheduler._submit')
    def test_maybe_schedule_next_WhenSkip(self, submit_patch,*patches):
        s = Scheduler(workers=2, skip_dependents=True)
        s._failed.append('task1')
        graph_mock = Mock()
        graph_mock.get_candidates.return_value = ['task3', 'task4']
        # original parent of task3 and task4 are task1 and task2 respectively
        # task1 failed, so task3 should be skipped
        # task4 should be scheduled
        graph_mock.original_parents_of.side_effect = [['task1'], ['task2']]
        s._graph = graph_mock
        s._maybe_schedule_next(Mock())
        s._submit.assert_has_calls([call('task4')])

    @patch('thread_order.scheduler.Scheduler._maybe_schedule_next')
    @patch('thread_order.scheduler.Scheduler._callback')
    def test_handle_done_When_Ok(self, callback_patch, *patches):
        s = Scheduler()
        graph_mock = Mock()
        graph_mock.is_empty.return_value = False
        s._graph = graph_mock
        function_mock = Mock()
        s.on_task_done(function_mock)
        mock_payload = ('task1', 'thread_0', True, '', '')
        s._handle_done(mock_payload, Mock())
        callback_patch.assert_called_once_with((function_mock, (), {}), 'task1', 'thread_0', TaskStatus.PASSED, 1)
        self.assertIn('task1', s._ran)

    @patch('thread_order.scheduler.Scheduler._maybe_schedule_next')
    @patch('thread_order.scheduler.Scheduler._callback')
    def test_handle_done_When_NotOk(self, callback_patch, *patches):
        s = Scheduler()
        graph_mock = Mock()
        graph_mock.is_empty.return_value = True
        s._graph = graph_mock
        function_mock = Mock()
        s.on_task_done(function_mock)
        mock_payload = ('task1', 'thread_0', False, 'ValueError', 'ValueError')
        s._handle_done(mock_payload, Mock())
        callback_patch.assert_called_once_with((function_mock, (), {}), 'task1', 'thread_0',TaskStatus.FAILED, 1)
        self.assertIn('task1', s._failed)
        self.assertIn('task1', s._ran)

    @patch('thread_order.scheduler.Scheduler._maybe_schedule_next')
    @patch('thread_order.scheduler.Scheduler._callback')
    def test_handle_done_When_NotOkDependencyError(self, callback_patch, *patches):
        s = Scheduler()
        graph_mock = Mock()
        graph_mock.is_empty.return_value = True
        s._graph = graph_mock
        function_mock = Mock()
        s.on_task_done(function_mock)
        mock_payload = ('task1', 'thread_0', False, 'DependencyError', 'DependencyError')
        s._handle_done(mock_payload, Mock())
        callback_patch.assert_called_once_with((function_mock, (), {}), 'task1', 'thread_0', TaskStatus.SKIPPED, 1)
        self.assertIn('task1', s._skipped)
        self.assertIn('task1', s._ran)

    @patch('thread_order.scheduler.Scheduler._callback')
    def test_handle_event_When_Start(self, callback_patch, *patches):
        s = Scheduler()
        function_mock = Mock()
        s.on_task_start(function_mock)
        with patch.object(s, '_events') as events_patch:
            events_patch.get_nowait.side_effect = [('start', 'task1'), queue.Empty()]
            s._handle_event()
            callback_patch.assert_called_once_with((function_mock, (), {}), 'task1')

    @patch('thread_order.scheduler.Scheduler._callback')
    def test_handle_event_When_Run(self, callback_patch, *patches):
        s = Scheduler()
        function_mock = Mock()
        s.on_task_run(function_mock)
        with patch.object(s, '_events') as events_patch:
            events_patch.get_nowait.side_effect = [('run', ('task1', 'thread1')), queue.Empty()]
            s._handle_event()
            callback_patch.assert_called_once_with((function_mock, (), {}), 'task1', 'thread1')

    @patch('thread_order.scheduler.logging.getLogger')
    @patch('thread_order.scheduler.Scheduler._handle_done')
    def test_handle_event_When_Done(self, handle_done_patch, get_logger_patch, *patches):
        s = Scheduler()
        function_mock = Mock()
        s.on_task_done(function_mock)
        with patch.object(s, '_events') as events_patch:
            events_patch.get_nowait.side_effect = [('done', ('task1', True, '', '')), queue.Empty()]
            s._handle_event()
            handle_done_patch.assert_called_once_with(('task1', True, '', ''), get_logger_patch.return_value)

    def test_build_summary(self, *patches):
        s = Scheduler()
        s._build_summary()

    def test_handle_interrupt(self, *patches):
        s = Scheduler()
        s._active.add('task1')
        with patch.object(s, '_futures') as futures_patch:
            fmock1 = Mock()
            fmock2 = Mock()
            fmock2.cancel.side_effect = RuntimeError('runtime error')
            futures_patch.keys.return_value = [fmock1, fmock2]
            s._handle_interrupt(Mock())
            fmock1.cancel.assert_called_once()
            fmock2.cancel.assert_called_once()
            self.assertEqual(s._results['task1'], {'ok': False, 'error_type': 'CancelledError', 'error': 'cancelled'})

    def test_prep_start(self, *patches):
        s = Scheduler()
        with patch.object(s, '_events') as events_patch:
            events_patch.get_nowait.side_effect = [('done', ('task1', True, '', '')), queue.Empty()]
            s._prep_start()
            self.assertEqual(s.state['results'], {})

    @patch('thread_order.scheduler.ThreadPoolExecutor')
    @patch('thread_order.scheduler.Scheduler._build_summary')
    @patch('thread_order.scheduler.Scheduler._handle_event')
    @patch('thread_order.scheduler.Scheduler._submit')
    @patch('thread_order.scheduler.Scheduler._prep_start')
    @patch('thread_order.scheduler.Scheduler._callback')
    def test_start(self, callback_patch, prep_start_patch, submit_patch, handle_event_patch, build_summary_patch, *patches):
        s = Scheduler()
        scheduler_start_mock = Mock()
        scheduler_done_mock = Mock()
        s.on_scheduler_start(scheduler_start_mock)
        s.on_scheduler_done(scheduler_done_mock)
        graph_mock = Mock()
        graph_mock.get_candidates.return_value = ['task1', 'task2']
        s._graph = graph_mock
        with patch.object(s, '_completed') as completed_patch:
            completed_patch.wait.side_effect = [False, False, False, True]
            s.start()
        prep_start_patch.assert_called_once()
        submit_patch.assert_has_calls([call('task1'), call('task2')])
        handle_event_patch.assert_called()
        build_summary_patch.assert_called_once()
        callback_patch.assert_called()

    @patch('thread_order.scheduler.ThreadPoolExecutor')
    @patch('thread_order.scheduler.Scheduler._build_summary')
    @patch('thread_order.scheduler.Scheduler._handle_event')
    @patch('thread_order.scheduler.Scheduler._submit')
    @patch('thread_order.scheduler.Scheduler._prep_start')
    @patch('thread_order.scheduler.Scheduler._callback')
    def test_start_When_KeyboardInterrupt(self, callback_patch, prep_start_patch, submit_patch, handle_event_patch, build_summary_patch, *patches):
        s = Scheduler()
        graph_mock = Mock()
        graph_mock.get_candidates.return_value = ['task1', 'task2']
        s._graph = graph_mock
        with patch.object(s, '_completed') as completed_patch:
            completed_patch.wait.side_effect = [False, False, False, KeyboardInterrupt]
            result = s.start()
        self.assertEqual(result, build_summary_patch.return_value)

    def test_submit(self, *patches):
        s = Scheduler()
        with patch.object(s, '_events') as events_patch, \
            patch.object(s, '_executor') as executor_patch:
            future_mock = Mock()
            executor_patch.submit.return_value = future_mock
            s._submit('task1')
            events_patch.put.assert_called_once_with(('start', 'task1'))
            self.assertEqual(s._futures[future_mock], 'task1')
            future_mock.add_done_callback.assert_called_once_with(s._done)

    def test_done(self, *patches):
        s = Scheduler()
        with patch.object(s, '_events') as events_patch, \
            patch.object(s, '_futures') as futures_patch:
            future_mock = Mock()
            future_mock.result.return_value = ('task1', True, '', '')
            s._done(future_mock)
            events_patch.put.assert_called_once_with(('done', ('task1', True, '', '')))

    def test_done_When_Exception(self, *patches):
        s = Scheduler()
        with patch.object(s, '_events') as events_patch, \
            patch.object(s, '_futures') as futures_patch:
            futures_patch.get.return_value = 'task1'
            future_mock = Mock()
            future_mock.result.side_effect = Exception('error')
            s._done(future_mock)
            events_patch.put.assert_called_once_with(('done', ('task1', False, 'Exception', 'error')))

    def test_run_When_WithState(self, *patches):
        s = Scheduler(store_results=True)
        function_mock = Mock(__name__='task1')
        s._callables = {'task1': (function_mock, True)}
        with patch.object(s, '_events') as events_patch:
            result = s._run('task1')
            function_mock.assert_called_once_with(s.state)
            self.assertEqual(s.state['results']['task1'], function_mock.return_value)
            self.assertEqual(result, ('task1', 'MainThread', True, None, None))

    def test_run_When_WithNoState(self, *patches):
        s = Scheduler(store_results=False)
        function_mock = Mock(__name__='task1')
        s._callables = {'task1': (function_mock, False)}
        with patch.object(s, '_events') as events_patch:
            result = s._run('task1')
            function_mock.assert_called_once_with()
            self.assertEqual(result, ('task1', 'MainThread', True, None, None))

    def test_run_When_Exception(self, *patches):
        s = Scheduler(store_results=True)
        function_mock = Mock(__name__='task1')
        function_mock.side_effect = Exception('error')
        s._callables = {'task1': (function_mock, True)}
        with patch.object(s, '_events') as events_patch:
            result = s._run('task1')
            function_mock.assert_called_once_with(s.state)
            self.assertEqual(result, ('task1', 'MainThread', False, 'Exception', 'error'))

    def test_callback_When_NoCallback(self, *patches):
        s = Scheduler()
        s._callback(None, 'task1')

    def test_callback_When_CallbackIsTuple(self, *patches):
        s = Scheduler()
        callback_mock = Mock()
        s._callback((callback_mock, ('arg1', 'arg2'), {'k1': 'v1'}), 'task1')
        callback_mock.assert_called_once_with('task1', 'arg1', 'arg2', k1='v1')

    def test_callback_When_CallbackIsCallable(self, *patches):
        s = Scheduler()
        callback_mock = Mock()
        s._callback(callback_mock, 'task1')
        callback_mock.assert_called_once_with('task1')

    def test_callback_When_CallbackException(self, *patches):
        s = Scheduler()
        callback_mock = Mock(side_effect=Exception('error'))
        s._callback(callback_mock, 'task1')

    def test_sanitized_state(self, *patches):
        s = Scheduler()
        self.assertTrue('_state_lock' not in s.sanitized_state)

    def test_mark(self, *patches):
        function_mock = Mock(__name__='task1')
        decorated_function = mark(with_state=True, tags='t1,t2')(function_mock)
        thread_order = {
            'after': [],
            'with_state': True,
            'orig_name': 'task1',
            'tags': ['t1', 't2']
        }
        self.assertEqual(decorated_function.__thread_order__, thread_order)
        decorated_function()

    def test_dmark(self, *patches):
        function_mock = Mock(__name__='task1')
        decorated_function = dmark(with_state=True, tags='t1,t2')(function_mock)
        thread_order = {
            'after': [],
            'with_state': True,
            'orig_name': 'task1',
            'tags': ['t1', 't2']
        }
        self.assertEqual(decorated_function.__thread_order__, thread_order)
        decorated_function()

    def test_split_target(self, *patches):
        target = 'module.submodule::function'
        module_path, function_name = _split_target(target)
        self.assertEqual(module_path, 'module.submodule')
        self.assertEqual(function_name, 'function')

        target = 'module.submodule'
        module_path, function_name = _split_target(target)
        self.assertEqual(module_path, 'module.submodule')
        self.assertIsNone(function_name)

    @patch('thread_order.scheduler.Path')
    def test_load_module_non_existent_module(self, path_patch, *patches):
        path_mock = Mock()
        path_mock.exists.return_value = False
        path_patch.return_value = path_mock
        with self.assertRaises(FileNotFoundError):
            _load_module('non_existent_module')

    @patch('thread_order.scheduler.importlib.util.spec_from_file_location', return_value=None)
    @patch('thread_order.scheduler.Path')
    def test_load_module_import_error(self, path_patch, *patches):
        path_mock = Mock()
        path_mock.exists.return_value = True
        path_patch.return_value = path_mock
        with self.assertRaises(ImportError):
            _load_module('module')

    @patch('thread_order.scheduler.importlib.util')
    @patch('thread_order.scheduler.Path')
    def test_load_module(self, path_patch, util_patch, *patches):
        path_mock = Mock()
        path_mock.exists.return_value = True
        path_patch.return_value = path_mock
        spec_mock = Mock()
        util_patch.spec_from_file_location.return_value = spec_mock
        result = _load_module('module')
        self.assertEqual(result, util_patch.module_from_spec.return_value)

    @patch('thread_order.scheduler._load_module')
    @patch('thread_order.scheduler._collect_functions')
    def test_load_and_collect_functions_no_marked_functions(self, collect_functions_patch, *patches):
        collect_functions_patch.return_value = []
        with self.assertRaises(SystemExit) as exception:
            load_and_collect_functions('target_module')
        self.assertTrue('No @mark functions found in target_module' in str(exception.exception))

    @patch('thread_order.scheduler._load_module')
    @patch('thread_order.scheduler._collect_functions')
    def test_load_and_collect_functions_no_filtered_functions(self, collect_functions_patch, *patches):
        collect_functions_patch.return_value = [('fn_b', Mock(), False), ('fn_c', Mock(), False)]
        with self.assertRaises(SystemExit) as exception:
            load_and_collect_functions('target_module::fn_a')
        self.assertTrue("function 'fn_a' not found" in str(exception.exception))

    @patch('thread_order.scheduler._load_module')
    @patch('thread_order.scheduler._collect_functions')
    def test_load_and_collect_functions(self, collect_functions_patch, load_module_patch, *patches):
        collect_functions_patch.return_value = [('fn_a', Mock(), True), ('fn_b', Mock(), False)]
        result = load_and_collect_functions('target_module')
        self.assertEqual(result[0], load_module_patch.return_value)
        self.assertEqual(result[1], collect_functions_patch.return_value)
        self.assertEqual(result[2], False)

    @patch('thread_order.scheduler._load_module')
    @patch('thread_order.scheduler._collect_functions')
    def test_load_and_collect_functions_filtered(self, collect_functions_patch, load_module_patch, *patches):
        function_mock = Mock()
        collect_functions_patch.return_value = [('fn_a', function_mock, False), ('fn_b', Mock(), False)]
        result = load_and_collect_functions('target_module::fn_a')
        self.assertEqual(result[0], load_module_patch.return_value)
        self.assertEqual(result[1], [('fn_a', function_mock, False)])
        self.assertEqual(result[2], True)
