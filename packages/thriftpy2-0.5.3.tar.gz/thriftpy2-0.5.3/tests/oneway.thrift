service echo {
    oneway void Test(1: string req)
}
