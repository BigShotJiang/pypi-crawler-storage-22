exception FooExc {
    1:string detail,
}


exception FooExc {
    1:i64 code,
}
