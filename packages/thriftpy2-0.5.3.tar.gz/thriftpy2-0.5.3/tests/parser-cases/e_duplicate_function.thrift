service FooSvc {
    i32 do_foo(1:i32 foo),
    void do_foo(1:i64 foo),
}
