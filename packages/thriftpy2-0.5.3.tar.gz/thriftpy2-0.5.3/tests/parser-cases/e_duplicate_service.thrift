service FooSvc {
    i32 do_foo(1:i32 foo),
}

service FooSvc {
    i32 do_bar(1:i32 bar),
}
