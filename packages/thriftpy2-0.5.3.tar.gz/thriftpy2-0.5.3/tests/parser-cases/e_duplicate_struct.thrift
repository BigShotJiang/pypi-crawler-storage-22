struct Foo {
    1:i64 foo_id
}

struct Foo {
    1:string foo_idstring
}
