include "shared.thrift"

service PingService extends shared.NotExistService {

}
