struct Person {
    1: string name,
    2: i32 age,
}

const Person jack = {'name': 'jack', 'age': 1.8}
