struct Cookbook {
    1: string name
}

const Cookbook cookbook = Cookbook
