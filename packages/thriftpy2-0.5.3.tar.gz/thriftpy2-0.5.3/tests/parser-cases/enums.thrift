enum Lang {
    C,
    Go,
    Java,
    Javascript,
    PHP,
    Python,
    Ruby,
}


enum Country {
    US = 1,
    UK,
    CN,
}


enum OS {
    OSX,
    Win = 3,
    Linux
}
