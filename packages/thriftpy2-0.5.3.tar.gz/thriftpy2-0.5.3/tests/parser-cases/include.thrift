include "included.thrift"
include "include/included_1.thrift"

const included.Timestamp datetime = 1422009523
