struct A {
    1: string value
}
