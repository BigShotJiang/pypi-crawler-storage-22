include "./issue_121.include.thrift"

struct B {
    1: issue_121.include.A a
}
