struct Test {
    1: required i64 trueNum;
}

const bool abool = true
const i32 falseValue = 123
