struct Container {
    1: list<map<string, A>> field1;
    2: list<list<A>> field2;
    3: list<list<list<A>>> field3;
}


struct A {
    1: string value
}
