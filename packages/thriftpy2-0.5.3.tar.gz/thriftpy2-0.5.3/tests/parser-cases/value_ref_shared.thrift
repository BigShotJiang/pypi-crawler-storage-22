const i32 int32 = 39;
const map <string, list<i32>> container = {'key': [1, 2, 3]};
