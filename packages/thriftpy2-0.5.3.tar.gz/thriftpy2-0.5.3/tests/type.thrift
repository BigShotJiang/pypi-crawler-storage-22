struct Set {
    1: required set<string> a_set
}
