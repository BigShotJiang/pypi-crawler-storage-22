/* tslint:disable */
/* eslint-disable */

/**
 * Token states in the TIBET lifecycle
 */
export enum TokenState {
    Created = 0,
    Detected = 1,
    Classified = 2,
    Mitigated = 3,
    Resolved = 4,
}

export class WasmTibetEngine {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Create a token and return as JSON
     */
    create_token(token_type: string, erin: string, eraan: string, eromheen: string, erachter: string, actor: string, parent_id?: string | null): string;
    constructor();
    /**
     * Verify a token from JSON
     */
    verify(token_json: string): boolean;
    readonly public_key: string;
}

export function tibet_version(): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_wasmtibetengine_free: (a: number, b: number) => void;
    readonly tibet_version: (a: number) => void;
    readonly wasmtibetengine_create_token: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number, p: number) => void;
    readonly wasmtibetengine_new: () => number;
    readonly wasmtibetengine_public_key: (a: number, b: number) => void;
    readonly wasmtibetengine_verify: (a: number, b: number, c: number) => number;
    readonly __wbindgen_export: (a: number) => void;
    readonly __wbindgen_add_to_stack_pointer: (a: number) => number;
    readonly __wbindgen_export2: (a: number, b: number, c: number) => void;
    readonly __wbindgen_export3: (a: number, b: number) => number;
    readonly __wbindgen_export4: (a: number, b: number, c: number, d: number) => number;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
