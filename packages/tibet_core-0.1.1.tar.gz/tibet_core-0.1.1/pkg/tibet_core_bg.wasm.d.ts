/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_wasmtibetengine_free: (a: number, b: number) => void;
export const tibet_version: (a: number) => void;
export const wasmtibetengine_create_token: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number, p: number) => void;
export const wasmtibetengine_new: () => number;
export const wasmtibetengine_public_key: (a: number, b: number) => void;
export const wasmtibetengine_verify: (a: number, b: number, c: number) => number;
export const __wbindgen_export: (a: number) => void;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
export const __wbindgen_export2: (a: number, b: number, c: number) => void;
export const __wbindgen_export3: (a: number, b: number) => number;
export const __wbindgen_export4: (a: number, b: number, c: number, d: number) => number;
