"""K-line (OHLCV) data resources for TickFlow API."""

from __future__ import annotations

import asyncio
import concurrent.futures
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    List,
    Literal,
    Optional,
    Tuple,
    Union,
    overload,
)

from .._types import NOT_GIVEN, NotGiven
from ..utils import (
    instrument_timestamp_to_trade_date,
    instrument_timestamp_to_trade_time,
)
from ._base import AsyncResource, SyncResource

if TYPE_CHECKING:
    import pandas as pd

    from ..generated_model import CompactKlineData, Period

# Maximum symbols per batch request (API limit)
MAX_SYMBOLS_PER_BATCH = 100


def _klines_to_dataframe(
    data: "CompactKlineData",
    symbol: Optional[str] = None,
) -> "pd.DataFrame":
    """Convert compact K-line data to a pandas DataFrame.

    Parameters
    ----------
    data : CompactKlineData
        Compact columnar K-line data from the API.
    symbol : str, optional
        Symbol code to include as a column.
    period : Period, optional
        K-line period. One of: "1m", "5m", "10m", "15m", "30m", "60m",
        "4h", "1d", "1w", "1M". Defaults to "1d".
    Returns
    -------
    pd.DataFrame
        DataFrame with columns: timestamp, open, high, low, close, volume, amount.
        Index is set to timestamp converted to datetime.
    """
    import pandas as pd

    df = pd.DataFrame(
        {
            "timestamp": data["timestamp"],
            "trade_date": [
                instrument_timestamp_to_trade_date(symbol, x) for x in data["timestamp"]
            ],
            "trade_time": [
                instrument_timestamp_to_trade_time(symbol, x) for x in data["timestamp"]
            ],
            "open": data["open"],
            "high": data["high"],
            "low": data["low"],
            "close": data["close"],
            "volume": data["volume"],
            "amount": data.get("amount", [0.0] * len(data["timestamp"])),
        }
    )

    if symbol:
        df.insert(0, "symbol", symbol)

    return df


def _batch_klines_to_dataframe(data: Dict[str, "CompactKlineData"]) -> "pd.DataFrame":
    """Convert batch K-line data to a single pandas DataFrame.

    Parameters
    ----------
    data : dict
        Dictionary mapping symbol codes to compact K-line data.

    Returns
    -------
    pd.DataFrame
        Combined DataFrame with a 'symbol' column and MultiIndex (symbol, timestamp).
    """
    import pandas as pd

    dfs = []
    for symbol, kline_data in data.items():
        df = _klines_to_dataframe(kline_data, symbol=symbol)
        dfs.append(df)

    if not dfs:
        return pd.DataFrame()

    combined = pd.concat(dfs)
    combined.reset_index(inplace=True)
    combined.set_index(["symbol", "timestamp"], inplace=True)
    combined.sort_index(inplace=True)

    return combined


def _chunk_list(lst: List[str], chunk_size: int) -> List[List[str]]:
    """Split a list into chunks of specified size.

    Parameters
    ----------
    lst : list
        The list to chunk.
    chunk_size : int
        Maximum size of each chunk.

    Returns
    -------
    list of list
        List of chunks.
    """
    return [lst[i : i + chunk_size] for i in range(0, len(lst), chunk_size)]


def _get_progress_bar(total: int, desc: str, show_progress: bool):
    """Get a progress bar iterator or a simple range.

    Parameters
    ----------
    total : int
        Total number of items.
    desc : str
        Description for the progress bar.
    show_progress : bool
        Whether to show the progress bar.

    Returns
    -------
    iterator
        tqdm progress bar or range.
    """
    if show_progress:
        try:
            from tqdm.auto import tqdm

            return tqdm(total=total, desc=desc, leave=False)
        except ImportError:
            # tqdm not installed, fall back to no progress bar
            pass
    return None


class Klines(SyncResource):
    """Synchronous interface for K-line (OHLCV) data endpoints.

    Supports returning data as raw dicts or pandas DataFrames.

    Examples
    --------
    >>> client = TickFlow(api_key="your-key")
    >>>
    >>> # Get raw K-line data
    >>> klines = client.klines.get("600000.SH", count=100)
    >>>
    >>> # Get as DataFrame
    >>> df = client.klines.get("600000.SH", count=100, as_dataframe=True)
    >>> print(df.head())
    """

    @overload
    def get(
        self,
        symbol: str,
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[False] = False,
    ) -> "CompactKlineData": ...

    @overload
    def get(
        self,
        symbol: str,
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[True],
    ) -> "pd.DataFrame": ...

    def get(
        self,
        symbol: str,
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: bool = False,
    ) -> Union["CompactKlineData", "pd.DataFrame"]:
        """Get K-line (OHLCV) data for a single symbol.

        Parameters
        ----------
        symbol : str
            Symbol code (e.g., "600000.SH", "AAPL.US").
        period : str, optional
            K-line period. One of: "1m", "5m", "10m", "15m", "30m", "60m",
            "4h", "1d", "1w", "1M". Defaults to "1d".
        count : int, optional
            Number of K-lines to return. Default 100, max 10000.
        start_time : int, optional
            Start timestamp in milliseconds.
        end_time : int, optional
            End timestamp in milliseconds.
        as_dataframe : bool, optional
            If True, return a pandas DataFrame. If False (default), return
            the raw compact columnar data.

        Returns
        -------
        CompactKlineData or pd.DataFrame
            If as_dataframe=False: dict with keys 'timestamp', 'open', 'high',
            'low', 'close', 'volume', 'amount' (each a list).
            If as_dataframe=True: pandas DataFrame with datetime index.

        Examples
        --------
        >>> # Get raw data
        >>> data = client.klines.get("600000.SH", period="1d", count=10)
        >>> print(data["close"][-1])  # Latest close price

        >>> # Get as DataFrame for analysis
        >>> df = client.klines.get("600000.SH", period="1d", count=100, as_dataframe=True)
        >>> print(df.tail())
        >>>
        >>> # Calculate 20-day moving average
        >>> df["ma20"] = df["close"].rolling(20).mean()
        """
        params: Dict[str, Any] = {"symbol": symbol}
        if not isinstance(period, NotGiven):
            params["period"] = period
        if not isinstance(count, NotGiven):
            params["count"] = count
        if not isinstance(start_time, NotGiven) and start_time is not None:
            params["start_time"] = start_time
        if not isinstance(end_time, NotGiven) and end_time is not None:
            params["end_time"] = end_time

        response = self._client.get("/v1/klines", params=params)
        data = response["data"]

        if as_dataframe:
            return _klines_to_dataframe(data, symbol=symbol)
        return data

    def _fetch_batch_chunk(
        self,
        symbols: List[str],
        params: Dict[str, Any],
    ) -> Tuple[Dict[str, "CompactKlineData"], List[Tuple[str, Exception]]]:
        """Fetch a single batch chunk.

        Returns
        -------
        tuple
            (data dict, list of (symbol, error) for failed symbols)
        """
        symbols_str = ",".join(symbols)
        chunk_params = {**params, "symbols": symbols_str}

        try:
            response = self._client.get("/v1/klines/batch", params=chunk_params)
            return response["data"], []
        except Exception as e:
            # Return empty data and record the error for all symbols in this chunk
            return {}, [(s, e) for s in symbols]

    @overload
    def batch(
        self,
        symbols: List[str],
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[False] = False,
        show_progress: bool = False,
        max_workers: int = 5,
    ) -> Dict[str, "CompactKlineData"]: ...

    @overload
    def batch(
        self,
        symbols: List[str],
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[True],
        show_progress: bool = False,
        max_workers: int = 5,
    ) -> "pd.DataFrame": ...

    def batch(
        self,
        symbols: List[str],
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: bool = False,
        show_progress: bool = False,
        max_workers: int = 5,
    ) -> Union[Dict[str, "CompactKlineData"], "pd.DataFrame"]:
        """Get K-line data for multiple symbols in batched concurrent requests.

        This method automatically handles the API limit of 100 symbols per request
        by splitting into chunks and fetching concurrently. Failed chunks don't
        affect other chunks - partial results are returned.

        Parameters
        ----------
        symbols : list of str
            List of symbol codes. Can exceed 100 - will be automatically chunked.
        period : str, optional
            K-line period. Defaults to "1d".
        count : int, optional
            Number of K-lines per symbol. Default 100.
        start_time : int, optional
            Start timestamp in milliseconds.
        end_time : int, optional
            End timestamp in milliseconds.
        as_dataframe : bool, optional
            If True, return a combined pandas DataFrame with MultiIndex.
            If False (default), return a dict mapping symbols to K-line data.
        show_progress : bool, optional
            If True, display a progress bar (requires tqdm). Default False.
        max_workers : int, optional
            Maximum number of concurrent requests. Default 5.

        Returns
        -------
        dict or pd.DataFrame
            If as_dataframe=False: dict mapping symbol codes to CompactKlineData.
            If as_dataframe=True: pandas DataFrame with MultiIndex (symbol, timestamp).

        Notes
        -----
        - The API limits batch requests to 100 symbols. This method automatically
          splits larger requests into chunks.
        - Failed chunks are logged but don't cause the entire request to fail.
        - Use `show_progress=True` for large requests to see progress.

        Examples
        --------
        >>> # Get data for 500 symbols with progress bar
        >>> symbols = client.exchanges.get_symbols("SH")[:500]
        >>> df = client.klines.batch(symbols, as_dataframe=True, show_progress=True)
        >>> print(f"Got data for {len(df.index.get_level_values('symbol').unique())} symbols")
        """
        if not symbols:
            return {} if not as_dataframe else _batch_klines_to_dataframe({})

        # Build base params
        params: Dict[str, Any] = {}
        if not isinstance(period, NotGiven):
            params["period"] = period
        if not isinstance(count, NotGiven):
            params["count"] = count
        if not isinstance(start_time, NotGiven) and start_time is not None:
            params["start_time"] = start_time
        if not isinstance(end_time, NotGiven) and end_time is not None:
            params["end_time"] = end_time

        # Split symbols into chunks
        chunks = _chunk_list(symbols, MAX_SYMBOLS_PER_BATCH)

        # If only one chunk, no need for concurrency
        if len(chunks) == 1:
            data, errors = self._fetch_batch_chunk(chunks[0], params)
            if as_dataframe:
                return _batch_klines_to_dataframe(data)
            return data

        # Setup progress bar
        pbar = _get_progress_bar(len(chunks), "Fetching K-lines", show_progress)

        # Fetch chunks concurrently
        all_data: Dict[str, "CompactKlineData"] = {}
        all_errors: List[Tuple[str, Exception]] = []

        try:
            with concurrent.futures.ThreadPoolExecutor(
                max_workers=max_workers
            ) as executor:
                futures = {
                    executor.submit(self._fetch_batch_chunk, chunk, params): chunk
                    for chunk in chunks
                }

                for future in concurrent.futures.as_completed(futures):
                    try:
                        data, errors = future.result()
                        all_data.update(data)
                        all_errors.extend(errors)
                    except Exception as e:
                        chunk = futures[future]
                        all_errors.extend((s, e) for s in chunk)

                    if pbar:
                        pbar.update(1)
        finally:
            if pbar:
                pbar.close()

        # Log errors if any (could use logging module in production)
        if all_errors:
            error_symbols = [s for s, _ in all_errors]
            # Silently continue - partial results are better than no results
            # Users can check if their symbols are in the result

        if as_dataframe:
            return _batch_klines_to_dataframe(all_data)
        return all_data


class AsyncKlines(AsyncResource):
    """Asynchronous interface for K-line (OHLCV) data endpoints.

    Supports returning data as raw dicts or pandas DataFrames.

    Examples
    --------
    >>> async with AsyncTickFlow(api_key="your-key") as client:
    ...     # Get raw K-line data
    ...     klines = await client.klines.get("600000.SH", count=100)
    ...
    ...     # Get as DataFrame
    ...     df = await client.klines.get("600000.SH", count=100, as_dataframe=True)
    """

    @overload
    async def get(
        self,
        symbol: str,
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[False] = False,
    ) -> "CompactKlineData": ...

    @overload
    async def get(
        self,
        symbol: str,
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[True],
    ) -> "pd.DataFrame": ...

    async def get(
        self,
        symbol: str,
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: bool = False,
    ) -> Union["CompactKlineData", "pd.DataFrame"]:
        """Get K-line (OHLCV) data for a single symbol.

        Parameters
        ----------
        symbol : str
            Symbol code (e.g., "600000.SH", "AAPL.US").
        period : str, optional
            K-line period. One of: "1m", "5m", "10m", "15m", "30m", "60m",
            "4h", "1d", "1w", "1M". Defaults to "1d".
        count : int, optional
            Number of K-lines to return. Default 100, max 10000.
        start_time : int, optional
            Start timestamp in milliseconds.
        end_time : int, optional
            End timestamp in milliseconds.
        as_dataframe : bool, optional
            If True, return a pandas DataFrame. If False (default), return
            the raw compact columnar data.

        Returns
        -------
        CompactKlineData or pd.DataFrame
            If as_dataframe=False: dict with keys 'timestamp', 'open', 'high',
            'low', 'close', 'volume', 'amount' (each a list).
            If as_dataframe=True: pandas DataFrame with datetime index.

        Examples
        --------
        >>> df = await client.klines.get("600000.SH", period="1d", as_dataframe=True)
        >>> print(df.tail())
        """
        params: Dict[str, Any] = {"symbol": symbol}
        if not isinstance(period, NotGiven):
            params["period"] = period
        if not isinstance(count, NotGiven):
            params["count"] = count
        if not isinstance(start_time, NotGiven) and start_time is not None:
            params["start_time"] = start_time
        if not isinstance(end_time, NotGiven) and end_time is not None:
            params["end_time"] = end_time

        response = await self._client.get("/v1/klines", params=params)
        data = response["data"]

        if as_dataframe:
            return _klines_to_dataframe(data, symbol=symbol)
        return data

    async def _fetch_batch_chunk(
        self,
        symbols: List[str],
        params: Dict[str, Any],
    ) -> Tuple[Dict[str, "CompactKlineData"], List[Tuple[str, Exception]]]:
        """Fetch a single batch chunk asynchronously.

        Returns
        -------
        tuple
            (data dict, list of (symbol, error) for failed symbols)
        """
        symbols_str = ",".join(symbols)
        chunk_params = {**params, "symbols": symbols_str}

        try:
            response = await self._client.get("/v1/klines/batch", params=chunk_params)
            return response["data"], []
        except Exception as e:
            return {}, [(s, e) for s in symbols]

    @overload
    async def batch(
        self,
        symbols: List[str],
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[False] = False,
        show_progress: bool = False,
        max_concurrency: int = 5,
    ) -> Dict[str, "CompactKlineData"]: ...

    @overload
    async def batch(
        self,
        symbols: List[str],
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[True],
        show_progress: bool = False,
        max_concurrency: int = 5,
    ) -> "pd.DataFrame": ...

    async def batch(
        self,
        symbols: List[str],
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: bool = False,
        show_progress: bool = False,
        max_concurrency: int = 5,
    ) -> Union[Dict[str, "CompactKlineData"], "pd.DataFrame"]:
        """Get K-line data for multiple symbols in batched concurrent requests.

        This method automatically handles the API limit of 100 symbols per request
        by splitting into chunks and fetching concurrently. Failed chunks don't
        affect other chunks - partial results are returned.

        Parameters
        ----------
        symbols : list of str
            List of symbol codes. Can exceed 100 - will be automatically chunked.
        period : str, optional
            K-line period. Defaults to "1d".
        count : int, optional
            Number of K-lines per symbol. Default 100.
        start_time : int, optional
            Start timestamp in milliseconds.
        end_time : int, optional
            End timestamp in milliseconds.
        as_dataframe : bool, optional
            If True, return a combined pandas DataFrame with MultiIndex.
            If False (default), return a dict mapping symbols to K-line data.
        show_progress : bool, optional
            If True, display a progress bar (requires tqdm). Default False.
        max_concurrency : int, optional
            Maximum number of concurrent requests. Default 5.

        Returns
        -------
        dict or pd.DataFrame
            If as_dataframe=False: dict mapping symbol codes to CompactKlineData.
            If as_dataframe=True: pandas DataFrame with MultiIndex (symbol, timestamp).

        Notes
        -----
        - The API limits batch requests to 100 symbols. This method automatically
          splits larger requests into chunks.
        - Failed chunks are logged but don't cause the entire request to fail.
        - Use `show_progress=True` for large requests to see progress.

        Examples
        --------
        >>> # Get data for many symbols with progress bar
        >>> symbols = await client.exchanges.get_symbols("SH")
        >>> df = await client.klines.batch(symbols[:500], as_dataframe=True, show_progress=True)
        """
        if not symbols:
            return {} if not as_dataframe else _batch_klines_to_dataframe({})

        # Build base params
        params: Dict[str, Any] = {}
        if not isinstance(period, NotGiven):
            params["period"] = period
        if not isinstance(count, NotGiven):
            params["count"] = count
        if not isinstance(start_time, NotGiven) and start_time is not None:
            params["start_time"] = start_time
        if not isinstance(end_time, NotGiven) and end_time is not None:
            params["end_time"] = end_time

        # Split symbols into chunks
        chunks = _chunk_list(symbols, MAX_SYMBOLS_PER_BATCH)

        # If only one chunk, no need for semaphore
        if len(chunks) == 1:
            data, errors = await self._fetch_batch_chunk(chunks[0], params)
            if as_dataframe:
                return _batch_klines_to_dataframe(data)
            return data

        # Setup progress bar
        pbar = _get_progress_bar(len(chunks), "Fetching K-lines", show_progress)

        # Use semaphore to limit concurrency
        semaphore = asyncio.Semaphore(max_concurrency)

        async def fetch_with_semaphore(
            chunk: List[str],
        ) -> Tuple[Dict[str, "CompactKlineData"], List[Tuple[str, Exception]]]:
            async with semaphore:
                result = await self._fetch_batch_chunk(chunk, params)
                if pbar:
                    pbar.update(1)
                return result

        # Fetch all chunks concurrently
        all_data: Dict[str, "CompactKlineData"] = {}
        all_errors: List[Tuple[str, Exception]] = []

        try:
            tasks = [fetch_with_semaphore(chunk) for chunk in chunks]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    all_errors.extend((s, result) for s in chunks[i])
                else:
                    data, errors = result
                    all_data.update(data)
                    all_errors.extend(errors)
        finally:
            if pbar:
                pbar.close()

        if as_dataframe:
            return _batch_klines_to_dataframe(all_data)
        return all_data
