"""TickFlow Python SDK - Market Data API Client.

A high-quality Python client for TickFlow market data API, supporting
A-shares (China), US stocks, and Hong Kong stocks.

Quick Start
-----------
>>> from tickflow import TickFlow
>>>
>>> # Initialize client
>>> client = TickFlow(api_key="your-api-key")
>>>
>>> # Get K-line data as pandas DataFrame
>>> df = client.klines.get("600000.SH", period="1d", count=100, as_dataframe=True)
>>> print(df.tail())
>>>
>>> # Get real-time quotes
>>> quotes = client.quotes.get(symbols=["600000.SH", "AAPL.US"])
>>> for q in quotes:
...     print(f"{q['symbol']}: {q['last_price']}")

Async Usage
-----------
>>> import asyncio
>>> from tickflow import AsyncTickFlow
>>>
>>> async def main():
...     async with AsyncTickFlow(api_key="your-api-key") as client:
...         df = await client.klines.get("AAPL.US", as_dataframe=True)
...         print(df.tail())
>>>
>>> asyncio.run(main())

Environment Variables
---------------------
- TICKFLOW_API_KEY: API key for authentication
- TICKFLOW_BASE_URL: Custom base URL (optional)
"""

from ._exceptions import (
    APIError,
    AuthenticationError,
    BadRequestError,
    ConnectionError,
    InternalServerError,
    NotFoundError,
    PermissionError,
    RateLimitError,
    TickFlowError,
    TimeoutError,
)
from ._types import NOT_GIVEN, NotGiven
from .client import AsyncTickFlow, TickFlow

# Re-export generated types for convenience
from .generated_model import (  # Core types; K-line types; Quote types; Symbol types; Exchange types; Universe types; Error types
    ApiError,
    BidAsk,
    CNQuoteExt,
    CNSymbolExt,
    CompactKlineData,
    ExchangeListResponse,
    ExchangeSummary,
    ExchangeSymbolsResponse,
    HKQuoteExt,
    HKSymbolExt,
    Kline,
    KlinesBatchResponse,
    KlinesResponse,
    Period,
    Quote,
    QuotesResponse,
    Region,
    SessionStatus,
    SymbolMeta,
    SymbolMetaResponse,
    Universe,
    UniverseDetail,
    UniverseDetailResponse,
    UniverseListResponse,
    UniverseSummary,
    USQuoteExt,
    USSymbolExt,
)

__version__ = "0.1.0"

__all__ = [
    # Main clients
    "TickFlow",
    "AsyncTickFlow",
    # Exceptions
    "TickFlowError",
    "APIError",
    "AuthenticationError",
    "PermissionError",
    "NotFoundError",
    "BadRequestError",
    "RateLimitError",
    "InternalServerError",
    "ConnectionError",
    "TimeoutError",
    # Sentinel
    "NOT_GIVEN",
    "NotGiven",
    # Generated types
    "Period",
    "Region",
    "SessionStatus",
    "CompactKlineData",
    "Kline",
    "KlinesResponse",
    "KlinesBatchResponse",
    "Quote",
    "QuotesResponse",
    "BidAsk",
    "CNQuoteExt",
    "USQuoteExt",
    "HKQuoteExt",
    "SymbolMeta",
    "SymbolMetaResponse",
    "CNSymbolExt",
    "USSymbolExt",
    "HKSymbolExt",
    "ExchangeSummary",
    "ExchangeListResponse",
    "ExchangeSymbolsResponse",
    "Universe",
    "UniverseSummary",
    "UniverseDetail",
    "UniverseListResponse",
    "UniverseDetailResponse",
    "ApiError",
    # Version
    "__version__",
]
