"""Main client classes for TickFlow API.

This module provides the primary interfaces for interacting with the TickFlow API:
- `TickFlow`: Synchronous client
- `AsyncTickFlow`: Asynchronous client

Both clients provide access to the same resources with consistent method signatures.
"""

from __future__ import annotations

from typing import Any, Optional

from ._base_client import AsyncAPIClient, SyncAPIClient
from ._types import Headers, Timeout
from .resources import (
    AsyncExchanges,
    AsyncKlines,
    AsyncQuotes,
    AsyncSymbols,
    AsyncUniverses,
    Exchanges,
    Klines,
    Quotes,
    Symbols,
    Universes,
)

__all__ = ["TickFlow", "AsyncTickFlow"]


class TickFlow:
    """Synchronous client for TickFlow market data API.

    Provides access to market data including K-lines, quotes, symbol metadata,
    exchanges, and universes.

    Parameters
    ----------
    api_key : str, optional
        API key for authentication. If not provided, reads from TICKFLOW_API_KEY
        environment variable.
    base_url : str, optional
        Base URL for the API. Defaults to https://api.tickflow.org.
        Can also be set via TICKFLOW_BASE_URL environment variable.
    timeout : float, optional
        Request timeout in seconds. Defaults to 30.0.
    default_headers : dict, optional
        Default headers to include in all requests.

    Attributes
    ----------
    klines : Klines
        K-line (OHLCV) data endpoints. Supports DataFrame conversion.
    quotes : Quotes
        Real-time quote endpoints.
    symbols : Symbols
        Symbol metadata endpoints.
    exchanges : Exchanges
        Exchange list endpoints.
    universes : Universes
        Universe (symbol pool) endpoints.

    Examples
    --------
    Basic usage:

    >>> from tickflow import TickFlow
    >>>
    >>> # Initialize client
    >>> client = TickFlow(api_key="your-api-key")
    >>>
    >>> # Get K-line data as DataFrame
    >>> df = client.klines.get("600000.SH", period="1d", count=100, as_dataframe=True)
    >>> print(df.tail())
    >>>
    >>> # Get real-time quotes
    >>> quotes = client.quotes.get(symbols=["600000.SH", "AAPL.US"])
    >>> for q in quotes:
    ...     print(f"{q['symbol']}: {q['last_price']}")

    Using context manager:

    >>> with TickFlow(api_key="your-api-key") as client:
    ...     df = client.klines.get("AAPL.US", as_dataframe=True)
    ...     print(df.tail())

    Using environment variable:

    >>> import os
    >>> os.environ["TICKFLOW_API_KEY"] = "your-api-key"
    >>> client = TickFlow()  # Uses TICKFLOW_API_KEY
    """

    klines: Klines
    quotes: Quotes
    symbols: Symbols
    exchanges: Exchanges
    universes: Universes

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        timeout: Timeout = 30.0,
        default_headers: Optional[Headers] = None,
    ) -> None:
        self._client = SyncAPIClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            default_headers=default_headers,
        )

        # Initialize resources
        self.klines = Klines(self._client)
        self.quotes = Quotes(self._client)
        self.symbols = Symbols(self._client)
        self.exchanges = Exchanges(self._client)
        self.universes = Universes(self._client)

    def __enter__(self) -> "TickFlow":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def close(self) -> None:
        """Close the underlying HTTP client.

        This releases any network resources held by the client.
        Called automatically when using the client as a context manager.
        """
        self._client.close()

    @property
    def api_key(self) -> str:
        """The API key used for authentication."""
        return self._client.api_key

    @property
    def base_url(self) -> str:
        """The base URL for API requests."""
        return self._client.base_url


class AsyncTickFlow:
    """Asynchronous client for TickFlow market data API.

    Provides access to market data including K-lines, quotes, symbol metadata,
    exchanges, and universes. All methods are async and must be awaited.

    Parameters
    ----------
    api_key : str, optional
        API key for authentication. If not provided, reads from TICKFLOW_API_KEY
        environment variable.
    base_url : str, optional
        Base URL for the API. Defaults to https://api.tickflow.org.
        Can also be set via TICKFLOW_BASE_URL environment variable.
    timeout : float, optional
        Request timeout in seconds. Defaults to 30.0.
    default_headers : dict, optional
        Default headers to include in all requests.

    Attributes
    ----------
    klines : AsyncKlines
        K-line (OHLCV) data endpoints. Supports DataFrame conversion.
    quotes : AsyncQuotes
        Real-time quote endpoints.
    symbols : AsyncSymbols
        Symbol metadata endpoints.
    exchanges : AsyncExchanges
        Exchange list endpoints.
    universes : AsyncUniverses
        Universe (symbol pool) endpoints.

    Examples
    --------
    Basic usage:

    >>> import asyncio
    >>> from tickflow import AsyncTickFlow
    >>>
    >>> async def main():
    ...     async with AsyncTickFlow(api_key="your-api-key") as client:
    ...         # Get K-line data as DataFrame
    ...         df = await client.klines.get("600000.SH", as_dataframe=True)
    ...         print(df.tail())
    ...
    ...         # Get multiple symbols in parallel
    ...         import asyncio
    ...         tasks = [
    ...             client.klines.get(s, as_dataframe=True)
    ...             for s in ["600000.SH", "000001.SZ", "AAPL.US"]
    ...         ]
    ...         results = await asyncio.gather(*tasks)
    >>>
    >>> asyncio.run(main())

    Manual resource management:

    >>> async def main():
    ...     client = AsyncTickFlow(api_key="your-api-key")
    ...     try:
    ...         quotes = await client.quotes.get(symbols=["AAPL.US"])
    ...         print(quotes)
    ...     finally:
    ...         await client.close()
    """

    klines: AsyncKlines
    quotes: AsyncQuotes
    symbols: AsyncSymbols
    exchanges: AsyncExchanges
    universes: AsyncUniverses

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        timeout: Timeout = 30.0,
        default_headers: Optional[Headers] = None,
    ) -> None:
        self._client = AsyncAPIClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            default_headers=default_headers,
        )

        # Initialize resources
        self.klines = AsyncKlines(self._client)
        self.quotes = AsyncQuotes(self._client)
        self.symbols = AsyncSymbols(self._client)
        self.exchanges = AsyncExchanges(self._client)
        self.universes = AsyncUniverses(self._client)

    async def __aenter__(self) -> "AsyncTickFlow":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def close(self) -> None:
        """Close the underlying HTTP client.

        This releases any network resources held by the client.
        Called automatically when using the client as an async context manager.
        """
        await self._client.close()

    @property
    def api_key(self) -> str:
        """The API key used for authentication."""
        return self._client.api_key

    @property
    def base_url(self) -> str:
        """The base URL for API requests."""
        return self._client.base_url
