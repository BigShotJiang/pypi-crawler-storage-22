"""Exchange resources for TickFlow API."""

from __future__ import annotations

from typing import TYPE_CHECKING, List

from ._base import AsyncResource, SyncResource

if TYPE_CHECKING:
    from ..generated_model import ExchangeSummary


class Exchanges(SyncResource):
    """Synchronous interface for exchange endpoints.

    Examples
    --------
    >>> client = TickFlow(api_key="your-key")
    >>> exchanges = client.exchanges.list()
    >>> for exchange in exchanges:
    ...     print(f"{exchange['exchange']}: {exchange['count']} symbols")
    """

    def list(self) -> List["ExchangeSummary"]:
        """Get list of all exchanges with symbol counts.

        Returns
        -------
        list of ExchangeSummary
            List of exchange information containing:
            - exchange: Exchange code (e.g., "SH", "SZ", "US")
            - region: Region code (e.g., "CN", "US", "HK")
            - count: Number of symbols in the exchange

        Examples
        --------
        >>> exchanges = client.exchanges.list()
        >>> print(exchanges)
        [{'exchange': 'SH', 'region': 'CN', 'count': 2100}, ...]
        """
        response = self._client.get("/v1/exchanges")
        return response["data"]

    def get_symbols(self, exchange: str) -> List[str]:
        """Get all symbols for a specific exchange.

        Parameters
        ----------
        exchange : str
            Exchange code (e.g., "SH", "SZ", "BJ", "US", "HK").

        Returns
        -------
        list of str
            List of symbol codes.

        Examples
        --------
        >>> symbols = client.exchanges.get_symbols("SH")
        >>> print(symbols[:5])
        ['600000.SH', '600001.SH', '600002.SH', ...]
        """
        response = self._client.get(f"/v1/exchanges/{exchange}/symbols")
        return response["data"]


class AsyncExchanges(AsyncResource):
    """Asynchronous interface for exchange endpoints.

    Examples
    --------
    >>> async with AsyncTickFlow(api_key="your-key") as client:
    ...     exchanges = await client.exchanges.list()
    """

    async def list(self) -> List["ExchangeSummary"]:
        """Get list of all exchanges with symbol counts.

        Returns
        -------
        list of ExchangeSummary
            List of exchange information containing:
            - exchange: Exchange code (e.g., "SH", "SZ", "US")
            - region: Region code (e.g., "CN", "US", "HK")
            - count: Number of symbols in the exchange

        Examples
        --------
        >>> exchanges = await client.exchanges.list()
        >>> print(exchanges)
        [{'exchange': 'SH', 'region': 'CN', 'count': 2100}, ...]
        """
        response = await self._client.get("/v1/exchanges")
        return response["data"]

    async def get_symbols(self, exchange: str) -> List[str]:
        """Get all symbols for a specific exchange.

        Parameters
        ----------
        exchange : str
            Exchange code (e.g., "SH", "SZ", "BJ", "US", "HK").

        Returns
        -------
        list of str
            List of symbol codes.

        Examples
        --------
        >>> symbols = await client.exchanges.get_symbols("SH")
        >>> print(symbols[:5])
        ['600000.SH', '600001.SH', '600002.SH', ...]
        """
        response = await self._client.get(f"/v1/exchanges/{exchange}/symbols")
        return response["data"]
