"""Symbol metadata resources for TickFlow API."""

from __future__ import annotations

from typing import TYPE_CHECKING, List, Union, overload

from ._base import AsyncResource, SyncResource

if TYPE_CHECKING:
    from ..generated_model import SymbolMeta


class Symbols(SyncResource):
    """Synchronous interface for symbol metadata endpoints.

    Examples
    --------
    >>> client = TickFlow(api_key="your-key")
    >>> meta = client.symbols.get("600000.SH")
    >>> print(f"{meta['symbol']}: {meta['name']}")
    """

    @overload
    def get(self, symbol: str) -> "SymbolMeta": ...

    @overload
    def get(self, symbol: List[str]) -> List["SymbolMeta"]: ...

    def get(
        self, symbol: Union[str, List[str]]
    ) -> Union["SymbolMeta", List["SymbolMeta"]]:
        """Get metadata for one or more symbols.

        Parameters
        ----------
        symbol : str or list of str
            Symbol code(s). Can be a single symbol string or a list of symbols.

        Returns
        -------
        SymbolMeta or list of SymbolMeta
            If a single symbol is provided, returns a single SymbolMeta dict.
            If a list is provided, returns a list of SymbolMeta dicts.

            Each SymbolMeta contains:
            - symbol: Full symbol code (e.g., "600000.SH")
            - code: Exchange-specific code (e.g., "600000")
            - exchange: Exchange code (e.g., "SH")
            - region: Region code (e.g., "CN")
            - name: Symbol name
            - symbol_type: Type (stock, etf, index, etc.)
            - ext: Market-specific extension data

        Examples
        --------
        >>> # Single symbol
        >>> meta = client.symbols.get("600000.SH")
        >>> print(meta['name'])

        >>> # Multiple symbols
        >>> metas = client.symbols.get(["600000.SH", "AAPL.US"])
        >>> for m in metas:
        ...     print(f"{m['symbol']}: {m['name']}")
        """
        if isinstance(symbol, str):
            response = self._client.get("/v1/symbols", params={"symbols": symbol})
            data = response["data"]
            return data[0] if data else {}
        else:
            # Use POST for batch queries
            response = self._client.post("/v1/symbols", json={"symbols": symbol})
            return response["data"]

    def batch(self, symbols: List[str]) -> List["SymbolMeta"]:
        """Get metadata for multiple symbols.

        This method uses POST to handle large batches without URL length limits.

        Parameters
        ----------
        symbols : list of str
            List of symbol codes (up to 1000).

        Returns
        -------
        list of SymbolMeta
            List of symbol metadata dicts.

        Examples
        --------
        >>> metas = client.symbols.batch(["600000.SH", "000001.SZ", "AAPL.US"])
        >>> for m in metas:
        ...     print(f"{m['symbol']}: {m['name']}")
        """
        response = self._client.post("/v1/symbols", json={"symbols": symbols})
        return response["data"]


class AsyncSymbols(AsyncResource):
    """Asynchronous interface for symbol metadata endpoints.

    Examples
    --------
    >>> async with AsyncTickFlow(api_key="your-key") as client:
    ...     meta = await client.symbols.get("600000.SH")
    """

    @overload
    async def get(self, symbol: str) -> "SymbolMeta": ...

    @overload
    async def get(self, symbol: List[str]) -> List["SymbolMeta"]: ...

    async def get(
        self, symbol: Union[str, List[str]]
    ) -> Union["SymbolMeta", List["SymbolMeta"]]:
        """Get metadata for one or more symbols.

        Parameters
        ----------
        symbol : str or list of str
            Symbol code(s). Can be a single symbol string or a list of symbols.

        Returns
        -------
        SymbolMeta or list of SymbolMeta
            If a single symbol is provided, returns a single SymbolMeta dict.
            If a list is provided, returns a list of SymbolMeta dicts.

            Each SymbolMeta contains:
            - symbol: Full symbol code (e.g., "600000.SH")
            - code: Exchange-specific code (e.g., "600000")
            - exchange: Exchange code (e.g., "SH")
            - region: Region code (e.g., "CN")
            - name: Symbol name
            - symbol_type: Type (stock, etf, index, etc.)
            - ext: Market-specific extension data

        Examples
        --------
        >>> # Single symbol
        >>> meta = await client.symbols.get("600000.SH")
        >>> print(meta['name'])

        >>> # Multiple symbols
        >>> metas = await client.symbols.get(["600000.SH", "AAPL.US"])
        """
        if isinstance(symbol, str):
            response = await self._client.get("/v1/symbols", params={"symbols": symbol})
            data = response["data"]
            return data[0] if data else {}
        else:
            response = await self._client.post("/v1/symbols", json={"symbols": symbol})
            return response["data"]

    async def batch(self, symbols: List[str]) -> List["SymbolMeta"]:
        """Get metadata for multiple symbols.

        This method uses POST to handle large batches without URL length limits.

        Parameters
        ----------
        symbols : list of str
            List of symbol codes (up to 1000).

        Returns
        -------
        list of SymbolMeta
            List of symbol metadata dicts.

        Examples
        --------
        >>> metas = await client.symbols.batch(["600000.SH", "000001.SZ", "AAPL.US"])
        """
        response = await self._client.post("/v1/symbols", json={"symbols": symbols})
        return response["data"]
