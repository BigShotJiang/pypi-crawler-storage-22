"""Ticksupply - Official Python client for Ticksupply market data API.

This package provides both synchronous and asynchronous clients for
interacting with the Ticksupply API.

Basic Usage:

    Synchronous client::

        from ticksupply import Client

        # API key from TICKSUPPLY_API_KEY env var
        client = Client()

        # Or with explicit API key
        client = Client(api_key="key_xxx.secret")

        # List exchanges
        for exchange in client.exchanges.list():
            print(f"{exchange.code}: {exchange.display_name}")

    Asynchronous client::

        import asyncio
        from ticksupply import AsyncClient

        async def main():
            async with AsyncClient() as client:
                exchanges = await client.exchanges.list()
                for exchange in exchanges:
                    print(f"{exchange.code}: {exchange.display_name}")

        asyncio.run(main())

For more information, see the documentation at https://docs.ticksupply.com
"""

from __future__ import annotations

from ticksupply.async_client import AsyncClient
from ticksupply.client import Client
from ticksupply.exceptions import (
    APIError,
    AuthenticationError,
    ConflictError,
    InvalidArgumentError,
    NetworkError,
    NotFoundError,
    PaymentRequiredError,
    PermissionDeniedError,
    RateLimitError,
    ServerError,
    TicksupplyError,
)

__version__ = "0.1.0"

__all__ = [
    # Clients
    "Client",
    "AsyncClient",
    # Exceptions
    "TicksupplyError",
    "APIError",
    "AuthenticationError",
    "PermissionDeniedError",
    "NotFoundError",
    "ConflictError",
    "RateLimitError",
    "PaymentRequiredError",
    "InvalidArgumentError",
    "ServerError",
    "NetworkError",
]
