"""Ticksupply API data models.

This module exports all Pydantic models used by the Ticksupply client.
"""

from __future__ import annotations

from ticksupply.models.catalog import (
    DatastreamInfo,
    Exchange,
    Instrument,
    PaginatedDatastreams,
    PaginatedInstruments,
)
from ticksupply.models.common import ErrorResponse
from ticksupply.models.export import (
    ArtifactDownload,
    AvailabilityRange,
    AvailabilityResponse,
    ExportDownloadResponse,
    ExportJob,
    ExportStatus,
    PaginatedExportJobs,
)
from ticksupply.models.subscription import (
    PaginatedSubscriptions,
    Subscription,
    SubscriptionResponse,
    SubscriptionSpan,
    SubscriptionStatus,
)

__all__ = [
    # Common
    "ErrorResponse",
    # Catalog
    "Exchange",
    "Instrument",
    "PaginatedInstruments",
    "DatastreamInfo",
    "PaginatedDatastreams",
    # Subscription
    "Subscription",
    "SubscriptionResponse",
    "SubscriptionSpan",
    "SubscriptionStatus",
    "PaginatedSubscriptions",
    # Export
    "ExportJob",
    "ExportStatus",
    "PaginatedExportJobs",
    "ExportDownloadResponse",
    "ArtifactDownload",
    "AvailabilityRange",
    "AvailabilityResponse",
]
