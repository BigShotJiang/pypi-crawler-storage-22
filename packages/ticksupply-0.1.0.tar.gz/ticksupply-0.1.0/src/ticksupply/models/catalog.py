"""Catalog models for exchanges, instruments, stream types, and datastreams."""

from __future__ import annotations

from ticksupply.models.common import BaseAPIModel


class Exchange(BaseAPIModel):
    """An exchange available in the platform.

    Attributes:
        code: Exchange code (e.g., "binance", "coinbase").
        display_name: Human-readable name.
    """

    code: str
    display_name: str


class Instrument(BaseAPIModel):
    """A trading instrument (symbol) on an exchange.

    Attributes:
        symbol: Trading symbol (e.g., "BTCUSDT").
        base: Base asset (e.g., "BTC").
        quote: Quote asset (e.g., "USDT").
        instrument_type: Type of instrument (e.g., "spot", "perpetual").
    """

    symbol: str
    base: str | None = None
    quote: str | None = None
    instrument_type: str | None = None


class PaginatedInstruments(BaseAPIModel):
    """Paginated list of instruments."""

    items: list[Instrument]
    total: int
    limit: int
    next_page_token: str | None = None

    @property
    def has_next(self) -> bool:
        """Check if there are more pages."""
        return self.next_page_token is not None


class DatastreamInfo(BaseAPIModel):
    """Simplified datastream information for catalog queries.

    Attributes:
        datastream_id: Unique identifier for subscriptions and exports.
        exchange: Exchange code.
        instrument: Instrument symbol.
        stream_type: Stream type code (e.g., trade, depth).
        wire_format: Wire format code (e.g., json, sbe).
    """

    datastream_id: int
    exchange: str
    instrument: str
    stream_type: str
    wire_format: str


class PaginatedDatastreams(BaseAPIModel):
    """Paginated list of datastreams."""

    items: list[DatastreamInfo]
    total: int
    limit: int
    next_page_token: str | None = None

    @property
    def has_next(self) -> bool:
        """Check if there are more pages."""
        return self.next_page_token is not None
