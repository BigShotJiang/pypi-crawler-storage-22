"""Common models shared across the API."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class BaseAPIModel(BaseModel):
    """Base model for all API responses.

    Configured to ignore extra fields for forward compatibility.
    """

    model_config = ConfigDict(extra="ignore")


class ErrorDetail(BaseAPIModel):
    """Error detail from API response."""

    code: str
    message: str
    trace_id: str | None = None


class ErrorResponse(BaseAPIModel):
    """Error response wrapper."""

    error: ErrorDetail
