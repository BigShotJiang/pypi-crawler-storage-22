"""Subscription models."""

from __future__ import annotations

from datetime import datetime
from enum import Enum

from ticksupply.models.catalog import DatastreamInfo
from ticksupply.models.common import BaseAPIModel


class SubscriptionStatus(str, Enum):
    """Status of a subscription."""

    ACTIVE = "active"
    PAUSED = "paused"
    DELETED = "deleted"


class SubscriptionSpan(BaseAPIModel):
    """A time span during which a subscription was active.

    Attributes:
        id: Unique identifier for the span (prefixed format, e.g., spn_xxx).
        started_at: When this span started.
        ended_at: When this span ended (None if still active).
    """

    id: str
    started_at: datetime
    ended_at: datetime | None = None


class SubscriptionResponse(BaseAPIModel):
    """Full subscription response with datastream details.

    Attributes:
        id: Unique subscription ID (prefixed format, e.g., sub_xxx).
        status: Current subscription status.
        datastream: Datastream information.
        created_at: When the subscription was created.
        spans: List of activity spans.
    """

    id: str
    status: SubscriptionStatus
    datastream: DatastreamInfo
    created_at: datetime
    spans: list[SubscriptionSpan]


class Subscription(BaseAPIModel):
    """Subscription in list responses.

    Attributes:
        id: Unique subscription ID (prefixed format, e.g., sub_xxx).
        datastream_id: ID of the datastream.
        status: Current subscription status.
        created_at: When the subscription was created.
        datastream: Optional datastream information (included when expanded).
    """

    id: str
    datastream_id: int
    status: SubscriptionStatus
    created_at: datetime
    datastream: DatastreamInfo | None = None


class PaginatedSubscriptions(BaseAPIModel):
    """Paginated list of subscriptions."""

    items: list[Subscription]
    total: int
    limit: int
    next_page_token: str | None = None

    @property
    def has_next(self) -> bool:
        """Check if there are more pages."""
        return self.next_page_token is not None
