"""Ticksupply API resource classes."""

from __future__ import annotations

from ticksupply.resources.availability import AsyncAvailabilityResource, AvailabilityResource
from ticksupply.resources.datastreams import AsyncDatastreamsResource, DatastreamsResource
from ticksupply.resources.exchanges import AsyncExchangesResource, ExchangesResource
from ticksupply.resources.exports import AsyncExportsResource, ExportsResource
from ticksupply.resources.subscriptions import AsyncSubscriptionsResource, SubscriptionsResource

__all__ = [
    "AsyncAvailabilityResource",
    "AsyncDatastreamsResource",
    "AsyncExchangesResource",
    "AsyncExportsResource",
    "AsyncSubscriptionsResource",
    "AvailabilityResource",
    "DatastreamsResource",
    "ExchangesResource",
    "ExportsResource",
    "SubscriptionsResource",
]
