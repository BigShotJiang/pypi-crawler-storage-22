"""Availability resource for data availability queries."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ticksupply.models.export import AvailabilityResponse
from ticksupply.resources.base import AsyncResource, SyncResource

if TYPE_CHECKING:
    from ticksupply._base import AsyncHTTPClient, SyncHTTPClient


class AvailabilityResource(SyncResource):
    """Synchronous resource for data availability queries.

    Use this to check what data is available for a specific datastream.
    """

    def __init__(self, client: SyncHTTPClient) -> None:
        super().__init__(client)

    def get(self, datastream_id: int) -> AvailabilityResponse:
        """Get data availability for a datastream.

        Args:
            datastream_id: Datastream ID to check availability for.

        Returns:
            Availability information including time ranges and row estimates.

        Example:
            >>> avail = client.availability.get(123)
            >>> for range_ in avail.ranges:
            ...     print(f"{range_.from_ns} - {range_.to_ns}: ~{range_.rows_estimate} rows")
        """
        response = self._client.get(
            "/availability",
            params={"datastream_id": datastream_id},
        )
        return AvailabilityResponse.model_validate(response.json())


class AsyncAvailabilityResource(AsyncResource):
    """Asynchronous resource for data availability queries.

    Use this to check what data is available for a specific datastream.
    """

    def __init__(self, client: AsyncHTTPClient) -> None:
        super().__init__(client)

    async def get(self, datastream_id: int) -> AvailabilityResponse:
        """Get data availability for a datastream.

        Args:
            datastream_id: Datastream ID to check availability for.

        Returns:
            Availability information including time ranges and row estimates.
        """
        response = await self._client.get(
            "/availability",
            params={"datastream_id": datastream_id},
        )
        return AvailabilityResponse.model_validate(response.json())
