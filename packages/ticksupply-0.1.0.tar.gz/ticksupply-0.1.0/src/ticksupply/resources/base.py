"""Base resource class for API resources."""

from __future__ import annotations

from typing import TYPE_CHECKING, TypeVar

if TYPE_CHECKING:
    from ticksupply._base import AsyncHTTPClient, SyncHTTPClient

T = TypeVar("T")


class SyncResource:
    """Base class for synchronous API resources."""

    def __init__(self, client: SyncHTTPClient) -> None:
        self._client = client


class AsyncResource:
    """Base class for asynchronous API resources."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        self._client = client
