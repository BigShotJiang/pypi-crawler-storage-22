"""Datastreams resource for catalog operations."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ticksupply.models.catalog import PaginatedDatastreams
from ticksupply.resources.base import AsyncResource, SyncResource

if TYPE_CHECKING:
    from ticksupply._base import AsyncHTTPClient, SyncHTTPClient


class DatastreamsResource(SyncResource):
    """Synchronous resource for datastream catalog operations."""

    def __init__(self, client: SyncHTTPClient) -> None:
        super().__init__(client)

    def list(
        self,
        *,
        exchange: str | None = None,
        instrument: str | None = None,
        stream_type: str | None = None,
        wire_format: str | None = None,
        limit: int = 100,
        page_token: str | None = None,
    ) -> PaginatedDatastreams:
        """List datastreams with optional filters.

        Args:
            exchange: Filter by exchange code.
            instrument: Filter by instrument symbol.
            stream_type: Filter by stream type.
            wire_format: Filter by wire format.
            limit: Maximum results per page (1-1000).
            page_token: Pagination cursor.

        Returns:
            Paginated list of datastreams.

        Example:
            >>> # List all datastreams
            >>> all_streams = client.datastreams.list()

            >>> # Filter by exchange
            >>> binance_streams = client.datastreams.list(exchange="binance")

            >>> # Filter by exchange and instrument
            >>> btc_streams = client.datastreams.list(
            ...     exchange="binance",
            ...     instrument="BTCUSDT"
            ... )
        """
        response = self._client.get(
            "/datastreams",
            params={
                "exchange": exchange,
                "instrument": instrument,
                "stream_type": stream_type,
                "wire_format": wire_format,
                "limit": limit,
                "page_token": page_token,
            },
        )
        return PaginatedDatastreams.model_validate(response.json())


class AsyncDatastreamsResource(AsyncResource):
    """Asynchronous resource for datastream catalog operations."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        super().__init__(client)

    async def list(
        self,
        *,
        exchange: str | None = None,
        instrument: str | None = None,
        stream_type: str | None = None,
        wire_format: str | None = None,
        limit: int = 100,
        page_token: str | None = None,
    ) -> PaginatedDatastreams:
        """List datastreams with optional filters.

        Args:
            exchange: Filter by exchange code.
            instrument: Filter by instrument symbol.
            stream_type: Filter by stream type.
            wire_format: Filter by wire format.
            limit: Maximum results per page (1-1000).
            page_token: Pagination cursor.

        Returns:
            Paginated list of datastreams.

        Example:
            >>> # List all datastreams
            >>> all_streams = await client.datastreams.list()

            >>> # Filter by exchange
            >>> binance_streams = await client.datastreams.list(exchange="binance")

            >>> # Filter by exchange and instrument
            >>> btc_streams = await client.datastreams.list(
            ...     exchange="binance",
            ...     instrument="BTCUSDT"
            ... )
        """
        response = await self._client.get(
            "/datastreams",
            params={
                "exchange": exchange,
                "instrument": instrument,
                "stream_type": stream_type,
                "wire_format": wire_format,
                "limit": limit,
                "page_token": page_token,
            },
        )
        return PaginatedDatastreams.model_validate(response.json())
