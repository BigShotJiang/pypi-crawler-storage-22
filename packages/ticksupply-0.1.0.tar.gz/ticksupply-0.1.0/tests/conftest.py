"""Pytest configuration and fixtures."""

import pytest


@pytest.fixture
def api_key() -> str:
    """Return a test API key."""
    return "key_test123.secret456"


@pytest.fixture
def base_url() -> str:
    """Return a test base URL."""
    return "https://api.test.ticksupply.com/v1"
