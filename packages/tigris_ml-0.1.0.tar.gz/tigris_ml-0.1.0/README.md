# TiGrIS

**Ti**led **Gr**aph **I**nference **S**cheduler — a host-side analysis toolchain
for deploying neural networks on memory-constrained embedded devices.

TiGrIS loads an ONNX model, computes tensor lifetimes and peak activation
memory, partitions the graph into stages that fit within an SRAM budget, and
reports what it finds — all from the command line.

## Install

```
pip install tigris-ml
```

## Quick Start

```
# Analyze a model — reports memory, stages, tiling feasibility
tigris analyze model.onnx --mem 256K

# Generate a YAML execution plan
tigris plan model.onnx -m 256K

# Compile to binary for on-device deployment
tigris compile model.onnx -m 256K -o model.plan.bin
```

```
╭──────────────────── TiGrIS — mobilenetv2-12 ────────────────────╮
│ Operators        105                                             │
│ Tensors          283 (106 activations)                           │
│ Peak activation  4.59 MiB                                       │
│ SRAM budget      256.00 KiB                                     │
│ Stages           69                                              │
╰──────────────────────────────────────────────────────────────────╯
╭──────────────────────────── Verdict ─────────────────────────────╮
│ [FAIL] Peak memory (4.59 MiB) is 18.4x the budget (256.00 KiB). │
│ 58 of 69 stages (84%) exceed budget — tiled streaming required.  │
╰──────────────────────────────────────────────────────────────────╯
```

## Vision

Today, when a developer tries to deploy a neural network on an MCU and the
model doesn't fit in SRAM, the options are: shrink the model (lose accuracy),
add external memory (lose latency), or give up and use a bigger chip.
Tiled streaming — executing layers on spatial patches so only a fraction of
activations need to be resident — can solve this, but every existing
implementation is locked to specific hardware (Arm Vela → Ethos-U, DORY → PULP,
TinyEngine → MCUNet architectures).

TiGrIS takes a different approach: **separate the analysis from the execution.**

```
┌─────────────────────────────────────────────────────────┐
│  tigris (this repo)                                     │
│  Python · ONNX-native · hardware-agnostic               │
│                                                         │
│  analyze → partition → tile plan → YAML / binary plan    │
└────────────────────────┬────────────────────────────────┘
                         │  plan.yaml / plan.bin
     ┌───────────────────┼───────────────────┐
     ▼                   ▼                   ▼
┌─────────┐       ┌─────────────┐     ┌───────────┐
│ tigris-  │       │ tigris-     │     │ tigris-   │
│ esp32    │       │ cortex-m    │     │ risc-v    │
│ (C)      │       │ (C)        │     │ (C)       │
└─────────┘       └─────────────┘     └───────────┘
  ESP-NN             CMSIS-NN           custom
  kernels            kernels            kernels
```

- **The analyzer is the product.** Hardware-agnostic, ONNX-native, CLI-first.
  Answers "will this model fit?" and "how should it be partitioned?" before
  you commit to any silicon.
- **The plan format is the standard.** YAML for human inspection (readable,
  diffable, commentable) and a compact binary for on-device deployment.
  Both describe stages, tile sizes, buffer offsets, halo overlap — everything
  a runtime needs to execute without doing any planning itself.
- **The runtimes are platform-specific reference implementations.** Thin C
  libraries (target: 5-15 KB flash) that consume a plan and dispatch tile
  loops to platform-optimized kernels.

## What It Does

1. **Loads** any ONNX model (runs shape inference, topological sort)
2. **Normalizes** the graph (BN folding, depthwise/Conv1D relabeling, Clip→Relu6, shape-op folding)
3. **Computes** tensor lifetimes — when each activation is born and dies
4. **Estimates** peak activation memory via event-sweep timeline
5. **Partitions** the graph into depth-axis stages that respect a memory budget
6. **Analyzes** spatial tiling — receptive field computation, tile height solving
7. **Reports** a verdict (pass/fail), largest tensors, spill/reload I/O cost,
   INT8 quantization estimate, and a budget comparison sweep
8. **Exports** a YAML execution plan or a compact binary for on-device deployment

## CLI Commands

```
# Analysis report with Rich terminal output
tigris analyze model.onnx --mem 256K

# YAML execution plan (human-readable, diffable)
tigris plan model.onnx -m 256K -o model.plan.yaml

# Binary plan for on-device deployment
tigris compile model.onnx -m 256K -o model.plan.bin

# Step-by-step execution trace
tigris simulate model.onnx -m 256K

# Generate C runtime test fixtures
tigris gen-fixtures mobilenetv2.onnx -o fixtures/ -m 256K
```

## Python API

```python
from tigris.loaders import load_model
from tigris.analysis.lifetime import compute_lifetimes
from tigris.analysis.memory import compute_memory_timeline
from tigris.analysis.partition_temporal import partition_temporal
from tigris.analysis.partition_spatial import partition_spatial

ag = load_model("model.onnx")
ag = compute_lifetimes(ag)
ag = compute_memory_timeline(ag)
ag = partition_temporal(ag, budget=256 * 1024)
ag = partition_spatial(ag)

print(f"Peak: {ag.peak_memory_bytes} bytes, Stages: {len(ag.stages)}")

from tigris.emitters.binary.writer import emit_binary
emit_binary(ag, "model.plan.bin")
```

## Project Structure

```
src/tigris/
├── cli/
│   ├── __init__.py       # CLI entry point, shared pipeline
│   ├── analyze.py        # tigris analyze — Rich terminal report
│   ├── compile.py        # tigris compile — binary plan output
│   ├── plan.py           # tigris plan — YAML plan output
│   ├── simulate.py       # tigris simulate — step-by-step trace
│   └── fixtures.py       # tigris gen-fixtures — C runtime test fixtures
├── graph/
│   └── ir.py             # Core IR (TensorInfo, OpNode, Stage, TilePlan, AnalyzedGraph)
├── loaders/
│   ├── __init__.py       # load_model() dispatcher
│   └── onnx/
│       ├── loader.py     # ONNX loading, shape inference, topo sort
│       └── normalize.py  # BN fold, relabeling, clip→relu6, shape-op fold
├── analysis/
│   ├── lifetime.py       # Tensor birth/death step computation
│   ├── memory.py         # Event-sweep memory timeline
│   ├── partition_temporal.py  # Greedy depth-axis stage partitioning
│   ├── partition_spatial.py   # Receptive field + tile solver
│   └── findings.py       # Structured analysis results + budget sweep
└── emitters/
    ├── yaml.py           # YAML execution plan
    └── binary/
        ├── defs.py       # Binary format struct definitions
        ├── writer.py     # Binary plan serialization
        └── reader.py     # Binary plan deserialization
```

## Supported Models

Tested end-to-end (Python toolchain → C runtime → numerical validation against ONNX Runtime):

| Model | Domain | Ops | Plan Size | Max Error vs ORT |
|---|---|---|---|---|
| DS-CNN | Keyword spotting | 21 | 92 KB | 2.18e-11 |
| FC Autoencoder | Anomaly detection | 20 | 539 KB | 5.96e-08 |
| TCN | Activity recognition | 13 | 62 KB | 5.22e-08 |
| MobileNetV2 | Image classification | 100 | 13.3 MB | identical (tiled) |

## Development

```
pip install -e ".[dev]"
pytest
```

## License

Apache 2.0 — Copyright The TiGrIS Authors
