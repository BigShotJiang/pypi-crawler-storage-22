"""Auto-generate actionable findings from an AnalyzedGraph.

Pure data — no HTML, no formatting. Used by both CLI and report."""

import copy
from dataclasses import dataclass, field

from tigris.graph.ir import AnalyzedGraph
from tigris.analysis.partition_temporal import partition_temporal


def _fmt_bytes(b: int) -> str:
    if b >= 1024 * 1024:
        return f"{b / (1024 * 1024):.2f} MiB"
    if b >= 1024:
        return f"{b / 1024:.2f} KiB"
    return f"{b} B"


@dataclass
class BudgetRow:
    budget: int
    budget_str: str
    stages: int
    need_tiling: int
    ok: bool


@dataclass
class Findings:
    # verdict
    verdict: str = ""  # "ok", "partitioned", "needs_tiling"
    verdict_text: str = ""

    # basics
    peak_bytes: int = 0
    budget: int = 0
    ratio: float = 0.0
    total_stages: int = 0
    stages_needing_tiling: int = 0

    # largest tensor
    largest_tensor_name: str = ""
    largest_tensor_shape: str = ""
    largest_tensor_bytes: int = 0

    # minimum budget to avoid tiling
    min_budget_no_tiling: int = 0

    # spill/reload
    total_spill_bytes: int = 0
    total_reload_bytes: int = 0
    stage_transitions: int = 0

    # tiling
    stages_tileable: int = 0
    stages_untileable: int = 0
    total_tiles: int = 0
    max_halo: int = 0

    # quantization
    is_float32: bool = False
    int8_estimate_bytes: int = 0
    int8_fits_budget: bool = False

    # budget sweep
    budget_sweep: list[BudgetRow] = field(default_factory=list)


def compute_findings(ag: AnalyzedGraph) -> Findings:
    """Analyze the graph and produce structured findings."""
    f = Findings()
    peak = ag.peak_memory_bytes
    budget = ag.mem_budget
    f.peak_bytes = peak
    f.budget = budget

    if not ag.lifetimes:
        return f

    # ── Largest tensor ───────────────────────────────────────────
    sorted_lt = sorted(ag.lifetimes.values(), key=lambda lt: -lt.size_bytes)
    largest = sorted_lt[0]
    largest_info = ag.tensors.get(largest.tensor_name)
    f.largest_tensor_name = largest.tensor_name
    f.largest_tensor_bytes = largest.size_bytes
    if largest_info:
        f.largest_tensor_shape = "x".join(str(d) for d in largest_info.shape)

    # ── Min budget to avoid tiling ───────────────────────────────
    f.min_budget_no_tiling = max(
        (s.live_bytes for s in ag.timeline), default=peak
    )

    # ── Verdict ──────────────────────────────────────────────────
    if budget > 0:
        f.ratio = peak / budget
        f.stages_needing_tiling = sum(1 for s in ag.stages if s.warnings)
        f.total_stages = len(ag.stages)

        if f.ratio <= 1.0:
            f.verdict = "ok"
            f.verdict_text = (
                f"Peak memory ({_fmt_bytes(peak)}) fits within budget "
                f"({_fmt_bytes(budget)}). Depth-axis partitioning into "
                f"{f.total_stages} stage(s) is sufficient."
            )
        elif f.stages_needing_tiling == 0:
            f.verdict = "partitioned"
            pct = f.ratio
            f.verdict_text = (
                f"Peak memory is {pct:.1f}x the budget, but depth-axis "
                f"partitioning into {f.total_stages} stages handles it "
                f"— no tiled streaming needed."
            )
        else:
            pct = 100 * f.stages_needing_tiling / f.total_stages
            f.verdict = "needs_tiling"
            f.verdict_text = (
                f"Peak memory ({_fmt_bytes(peak)}) is {f.ratio:.1f}x the "
                f"budget ({_fmt_bytes(budget)}). {f.stages_needing_tiling} of "
                f"{f.total_stages} stages ({pct:.0f}%) exceed budget — "
                f"tiled streaming required."
            )

    # ── Tiling results ─────────────────────────────────────────
    for s in ag.stages:
        if s.tile_plan is not None:
            if s.tile_plan.tileable:
                f.stages_tileable += 1
                f.total_tiles += s.tile_plan.num_tiles
                if s.tile_plan.halo > f.max_halo:
                    f.max_halo = s.tile_plan.halo
            else:
                f.stages_untileable += 1

    if f.verdict == "needs_tiling" and (f.stages_tileable or f.stages_untileable):
        tiling_detail = ""
        if f.stages_tileable:
            tiling_detail += (
                f" {f.stages_tileable} stage(s) tileable "
                f"({f.total_tiles} total tiles, max halo {f.max_halo})."
            )
        if f.stages_untileable:
            tiling_detail += (
                f" {f.stages_untileable} stage(s) contain untileable ops."
            )
        f.verdict_text += tiling_detail

    # ── Spill/reload cost ────────────────────────────────────────
    if ag.stages and len(ag.stages) > 1:
        f.stage_transitions = len(ag.stages) - 1
        for s in ag.stages:
            for tname in s.output_tensors:
                info = ag.tensors.get(tname)
                if info:
                    f.total_spill_bytes += info.size_bytes
            for tname in s.input_tensors:
                info = ag.tensors.get(tname)
                if info:
                    f.total_reload_bytes += info.size_bytes

    # ── Quantization estimate ────────────────────────────────────
    float_tensors = [
        lt for lt in ag.lifetimes.values()
        if ag.tensors.get(lt.tensor_name)
        and ag.tensors[lt.tensor_name].dtype == 1
    ]
    if float_tensors:
        f.is_float32 = True
        f.int8_estimate_bytes = peak // 4
        f.int8_fits_budget = budget > 0 and f.int8_estimate_bytes < budget

    # ── Budget sweep ─────────────────────────────────────────────
    f.budget_sweep = _budget_sweep(ag)

    return f


def _budget_sweep(ag: AnalyzedGraph) -> list[BudgetRow]:
    if not ag.lifetimes or not ag.timeline:
        return []

    peak = ag.peak_memory_bytes
    budgets = [
        b for b in [32 * 1024, 64 * 1024, 128 * 1024, 256 * 1024,
                     512 * 1024, 1024 * 1024, 2 * 1024 * 1024, 4 * 1024 * 1024]
        if b <= peak * 2
    ]
    if not budgets:
        return []

    ag_clean = copy.deepcopy(ag)
    for op in ag_clean.ops:
        op.stage = -1
    ag_clean.stages = []

    rows: list[BudgetRow] = []
    for b in budgets:
        ag_copy = copy.deepcopy(ag_clean)
        ag_copy = partition_temporal(ag_copy, b)
        n_stages = len(ag_copy.stages)
        n_tiling = sum(1 for s in ag_copy.stages if s.warnings)
        rows.append(BudgetRow(
            budget=b,
            budget_str=_fmt_bytes(b),
            stages=n_stages,
            need_tiling=n_tiling,
            ok=n_tiling == 0,
        ))
    return rows
