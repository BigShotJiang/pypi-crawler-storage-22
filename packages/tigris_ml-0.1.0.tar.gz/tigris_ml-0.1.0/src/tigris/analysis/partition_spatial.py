"""Spatial partitioning — receptive field computation and tile solving.

For stages whose peak memory exceeds the SRAM budget, determines whether ops
are spatially tileable, computes the receptive field (halo overlap), and solves
for tile dimensions that fit within budget.
"""

import math
from enum import Enum

from tigris.graph.ir import AnalyzedGraph, OpNode, TilePlan


# ── Op classification ────────────────────────────────────────────────


class TileCategory(Enum):
    CONV = "conv"
    POOL = "pool"
    POINTWISE = "pointwise"
    UNTILEABLE = "untileable"


# Op types that are spatially tileable (operate on spatial dims independently)
_OP_CATEGORY: dict[str, TileCategory] = {
    # Convolutions
    "Conv": TileCategory.CONV,
    "Conv1D": TileCategory.CONV,
    "ConvTranspose": TileCategory.CONV,
    # Pooling
    "MaxPool": TileCategory.POOL,
    "AveragePool": TileCategory.POOL,
    "GlobalAveragePool": TileCategory.POOL,
    "GlobalMaxPool": TileCategory.POOL,
    # Pointwise / element-wise (pass through spatial dims unchanged)
    "Relu": TileCategory.POINTWISE,
    "LeakyRelu": TileCategory.POINTWISE,
    "Sigmoid": TileCategory.POINTWISE,
    "Tanh": TileCategory.POINTWISE,
    "Clip": TileCategory.POINTWISE,
    "Add": TileCategory.POINTWISE,
    "Sub": TileCategory.POINTWISE,
    "Mul": TileCategory.POINTWISE,
    "Div": TileCategory.POINTWISE,
    "BatchNormalization": TileCategory.POINTWISE,
    "InstanceNormalization": TileCategory.POINTWISE,
    "Concat": TileCategory.POINTWISE,
    "Resize": TileCategory.POINTWISE,
    "Pad": TileCategory.POINTWISE,
    # Untileable — these collapse or reshape spatial dims
    "Flatten": TileCategory.UNTILEABLE,
    "Reshape": TileCategory.UNTILEABLE,
    "Gemm": TileCategory.UNTILEABLE,
    "MatMul": TileCategory.UNTILEABLE,
    "Softmax": TileCategory.UNTILEABLE,
    "ReduceMean": TileCategory.UNTILEABLE,
    "Squeeze": TileCategory.UNTILEABLE,
    "Unsqueeze": TileCategory.UNTILEABLE,
    "Transpose": TileCategory.UNTILEABLE,
}


def classify_op(op_type: str) -> TileCategory:
    """Classify an op type into a tile category. Unknown ops are UNTILEABLE."""
    return _OP_CATEGORY.get(op_type, TileCategory.UNTILEABLE)


# ── Receptive field computation ──────────────────────────────────────


def compute_receptive_field(ops: list[OpNode]) -> tuple[int, int]:
    """Compute the receptive field and total stride for a sequence of ops.

    Walks the ops in reverse, accumulating RF and jump (cumulative stride).
    Returns (receptive_field, total_jump).

    For pointwise ops, RF and jump are unchanged.
    For conv/pool ops, RF grows based on effective kernel size.
    """
    rf = 1
    jump = 1

    for op in reversed(ops):
        cat = classify_op(op.op_type)
        if cat in (TileCategory.CONV, TileCategory.POOL):
            kernel = _get_kernel_h(op)
            stride = _get_stride_h(op)
            dilation = _get_dilation_h(op)

            effective_k = dilation * (kernel - 1) + 1
            rf = rf + (effective_k - 1) * jump
            jump = jump * stride

    return rf, jump


def _get_kernel_h(op: OpNode) -> int:
    """Get the height dimension of the kernel (first element of kernel_shape)."""
    ks = op.attrs.get("kernel_shape")
    if ks and len(ks) >= 1:
        return int(ks[0])
    return 1


def _get_stride_h(op: OpNode) -> int:
    """Get the height dimension of the stride."""
    strides = op.attrs.get("strides")
    if strides and len(strides) >= 1:
        return int(strides[0])
    return 1


def _get_dilation_h(op: OpNode) -> int:
    """Get the height dimension of the dilation."""
    dilations = op.attrs.get("dilations")
    if dilations and len(dilations) >= 1:
        return int(dilations[0])
    return 1


# ── Tile solver ──────────────────────────────────────────────────────


def partition_spatial(ag: AnalyzedGraph) -> AnalyzedGraph:
    """Analyze each stage and attach a TilePlan where needed.

    Only stages whose peak_bytes exceed mem_budget are analyzed.
    Stages that fit within budget get no tile_plan (None).
    """
    if not ag.stages or ag.mem_budget <= 0:
        return ag

    budget = ag.mem_budget

    for stage in ag.stages:
        if stage.peak_bytes <= budget:
            continue  # fits, no tiling needed

        stage_ops = [ag.ops[i] for i in stage.op_indices]

        # Check if all ops are tileable
        untileable: list[str] = []
        for op in stage_ops:
            cat = classify_op(op.op_type)
            if cat == TileCategory.UNTILEABLE:
                untileable.append(f"{op.name} ({op.op_type})")

        if untileable:
            stage.tile_plan = TilePlan(
                tileable=False,
                untileable_ops=untileable,
                warnings=[f"Stage {stage.stage_id} contains untileable ops"],
            )
            continue

        # Compute receptive field
        rf, _jump = compute_receptive_field(stage_ops)
        halo = rf - 1

        # Find input height (NCHW layout, index 2)
        input_h = _find_input_height(ag, stage)
        if input_h <= 0:
            stage.tile_plan = TilePlan(
                tileable=False,
                warnings=[f"Stage {stage.stage_id}: cannot determine spatial height"],
            )
            continue

        # Solve for tile height
        peak = stage.peak_bytes
        tile_h = math.floor(budget * input_h / peak) - halo
        tile_h = max(tile_h, 1)

        num_tiles = math.ceil(input_h / tile_h)

        # Estimate tiled peak memory
        tiled_peak = int(peak * (tile_h + halo) / input_h)

        # Overhead: extra halo reads per tile boundary
        # Each internal tile boundary reads halo rows extra from the input
        halo_tensor_bytes = _estimate_halo_bytes(ag, stage, halo, input_h)
        overhead = halo_tensor_bytes * max(num_tiles - 1, 0)

        warnings: list[str] = []
        if tiled_peak > budget:
            warnings.append(
                f"Stage {stage.stage_id} tiled peak ({tiled_peak:,} bytes) "
                f"still exceeds budget ({budget:,} bytes)"
            )

        stage.tile_plan = TilePlan(
            tileable=True,
            tile_height=tile_h,
            num_tiles=num_tiles,
            halo=halo,
            receptive_field=rf,
            original_height=input_h,
            tiled_peak_bytes=tiled_peak,
            overhead_bytes=overhead,
            warnings=warnings,
        )

    return ag


def _find_input_height(ag: AnalyzedGraph, stage) -> int:
    """Find the spatial height of the stage's primary input tensor (NCHW dim 2)."""
    # Check stage input tensors first, then look at first op's inputs
    candidates = stage.input_tensors.copy()
    if not candidates:
        first_op = ag.ops[stage.op_indices[0]]
        candidates = [n for n in first_op.inputs if n in ag.tensors]

    for name in candidates:
        info = ag.tensors.get(name)
        if info and len(info.shape) >= 4:
            return int(info.shape[2])  # NCHW → H is dim 2

    return 0


def _estimate_halo_bytes(ag: AnalyzedGraph, stage, halo: int, input_h: int) -> int:
    """Estimate bytes for one halo region of the stage's input tensor."""
    candidates = stage.input_tensors.copy()
    if not candidates:
        first_op = ag.ops[stage.op_indices[0]]
        candidates = [n for n in first_op.inputs if n in ag.tensors]

    for name in candidates:
        info = ag.tensors.get(name)
        if info and len(info.shape) >= 4:
            # bytes per row = total_bytes / H
            if input_h > 0:
                return int(info.size_bytes * halo / input_h)

    return 0
