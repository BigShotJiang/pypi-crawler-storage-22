"""``tigris analyze`` command."""

import click
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from tigris.cli import cli, console, _fmt, _parse_size, _run_pipeline


@cli.command()
@click.argument("model", type=click.Path(exists=True))
@click.option("--mem", "-m", multiple=True, help="Memory pool size, fast to slow (e.g. 256K, 512K 8M)")
def analyze(model: str, mem: tuple[str, ...]):
    """Analyze an ONNX model for memory-constrained deployment."""
    from tigris.analysis.findings import compute_findings

    mem_pools = [_parse_size(m) for m in mem]
    ag, budget = _run_pipeline(model, mem)

    with console.status("Computing findings..."):
        findings = compute_findings(ag)

    # ── Summary ──────────────────────────────────────────────────
    summary = Table.grid(padding=(0, 2))
    summary.add_column(style="bold")
    summary.add_column()
    summary.add_row("Operators", str(len(ag.ops)))
    summary.add_row("Tensors", f"{len(ag.tensors)} ({len(ag.lifetimes)} activations)")
    summary.add_row("Peak activation", _fmt(ag.peak_memory_bytes))
    if budget > 0:
        summary.add_row("Memory budget", _fmt(budget))
        if len(mem_pools) > 1:
            for i, pool in enumerate(mem_pools[1:], 1):
                summary.add_row(f"  pool {i+1} (slow)", _fmt(pool))
        summary.add_row("Stages", str(findings.total_stages))

    console.print(Panel(summary, title=f"[bold]TiGrIS — {ag.model_name}[/]", border_style="blue"))

    # ── Verdict ──────────────────────────────────────────────────
    if findings.verdict:
        style_map = {"ok": "green", "partitioned": "yellow", "needs_tiling": "red"}
        label_map = {"ok": "PASS", "partitioned": "PASS", "needs_tiling": "FAIL"}
        style = style_map.get(findings.verdict, "white")
        label = label_map.get(findings.verdict, "?")
        console.print(Panel(
            f"[bold {style}][{label}][/] {findings.verdict_text}",
            title="[bold]Verdict[/]",
            border_style=style,
        ))

    # ── Key Metrics ──────────────────────────────────────────────
    metrics = Table.grid(padding=(0, 2))
    metrics.add_column(style="bold")
    metrics.add_column()
    metrics.add_row("Largest activation", _fmt(findings.largest_tensor_bytes))
    if findings.largest_tensor_shape:
        metrics.add_row("  tensor", findings.largest_tensor_name)
        metrics.add_row("  shape", findings.largest_tensor_shape)
    metrics.add_row("Min budget (no tile)", _fmt(findings.min_budget_no_tiling))

    if findings.stage_transitions > 0:
        metrics.add_row("Spill I/O", _fmt(findings.total_spill_bytes))
        metrics.add_row("Reload I/O", _fmt(findings.total_reload_bytes))
        metrics.add_row("Stage transitions", str(findings.stage_transitions))

    if findings.is_float32:
        est = _fmt(findings.int8_estimate_bytes)
        if findings.int8_fits_budget:
            est += "  [green](fits budget)[/]"
        metrics.add_row("INT8 estimate", est)

    console.print(Panel(metrics, title="[bold]Key Metrics[/]", border_style="cyan"))

    # ── Budget Sweep ─────────────────────────────────────────────
    if findings.budget_sweep:
        table = Table(title="Budget Comparison", border_style="dim")
        table.add_column("Budget", justify="right")
        table.add_column("Stages", justify="right")
        table.add_column("Need Tiling", justify="right")
        table.add_column("Status")

        for row in findings.budget_sweep:
            is_current = row.budget == budget
            status = Text("OK", style="green") if row.ok else Text(
                f"{row.need_tiling} need tiling", style="red"
            )
            style = "bold" if is_current else ""
            marker = " ◄" if is_current else ""
            table.add_row(
                row.budget_str + marker,
                str(row.stages),
                str(row.need_tiling),
                status,
                style=style,
            )

        console.print(table)

    # ── Stages ───────────────────────────────────────────────────
    if ag.stages:
        table = Table(title=f"Stages ({len(ag.stages)})", border_style="dim")
        table.add_column("#", justify="right")
        table.add_column("Ops", justify="right")
        table.add_column("Peak", justify="right")
        table.add_column("In", justify="right")
        table.add_column("Out", justify="right")
        table.add_column("Note")

        for s in ag.stages:
            note = Text("NEEDS TILING", style="red") if s.warnings else Text("")
            table.add_row(
                str(s.stage_id),
                str(len(s.op_indices)),
                _fmt(s.peak_bytes),
                str(len(s.input_tensors)),
                str(len(s.output_tensors)),
                note,
            )

        console.print(table)

    # ── Tiling Analysis ─────────────────────────────────────────
    tiled_stages = [s for s in ag.stages if s.tile_plan is not None]
    if tiled_stages:
        table = Table(title="Tiling Analysis", border_style="dim")
        table.add_column("Stage", justify="right")
        table.add_column("Tileable?")
        table.add_column("Tile H", justify="right")
        table.add_column("Tiles", justify="right")
        table.add_column("Halo", justify="right")
        table.add_column("RF", justify="right")
        table.add_column("Tiled Peak", justify="right")

        for s in tiled_stages:
            tp = s.tile_plan
            tileable = Text("Yes", style="green") if tp.tileable else Text("No", style="red")
            tile_h = str(tp.tile_height) if tp.tileable else "-"
            tiles = str(tp.num_tiles) if tp.tileable else "-"
            halo_str = str(tp.halo) if tp.tileable else "-"
            rf_str = str(tp.receptive_field) if tp.tileable else "-"
            tiled_peak = _fmt(tp.tiled_peak_bytes) if tp.tileable else "-"

            table.add_row(
                str(s.stage_id), tileable, tile_h, tiles,
                halo_str, rf_str, tiled_peak,
            )

        console.print(table)
