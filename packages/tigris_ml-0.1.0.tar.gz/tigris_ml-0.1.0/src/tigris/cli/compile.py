"""``tigris compile`` command."""

from pathlib import Path

import click

from tigris.cli import cli, console, _fmt, _run_pipeline


@cli.command()
@click.argument("model", type=click.Path(exists=True))
@click.option("--mem", "-m", multiple=True, required=True, help="Memory pool size, fast to slow (e.g. 256K)")
@click.option("--output", "-o", default=None, help="Output path (default: <model>.plan.bin)")
def compile(model: str, mem: tuple[str, ...], output: str | None):
    """Compile an ONNX model to binary deployment format."""
    from tigris.emitters.binary.writer import emit_binary

    ag, budget = _run_pipeline(model, mem)

    out = Path(output) if output else Path(model).with_suffix(".plan.bin")
    with console.status("Writing binary plan..."):
        emit_binary(ag, out)

    console.print(f"[bold green]Binary plan written to {out}[/]")
    console.print(f"  {len(ag.ops)} ops, {len(ag.stages)} stages @ {_fmt(budget)} budget", style="dim")
