"""Inline ONNX model builders + ``tigris gen-fixtures`` command."""

from __future__ import annotations

from pathlib import Path

import click
import numpy as np
import onnx
from onnx import TensorProto, helper, numpy_helper

from tigris.cli import cli, console, _run_pipeline


# ── linear_3op ────────────────────────────────────────────────────────

def build_linear_3op() -> onnx.ModelProto:
    """Add → ReLU → Add.  Input/output: [1, 64]."""
    X = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 64])
    Y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 64])

    w0 = helper.make_tensor("w0", TensorProto.FLOAT, [1, 64],
                            np.zeros((1, 64), dtype=np.float32).flatten().tolist())
    w1 = helper.make_tensor("w1", TensorProto.FLOAT, [1, 64],
                            np.zeros((1, 64), dtype=np.float32).flatten().tolist())

    add0 = helper.make_node("Add", ["input", "w0"], ["t0"], name="add0")
    relu = helper.make_node("Relu", ["t0"], ["t1"], name="relu0")
    add1 = helper.make_node("Add", ["t1", "w1"], ["output"], name="add1")

    graph = helper.make_graph([add0, relu, add1], "linear_3op", [X], [Y],
                              initializer=[w0, w1])
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)])
    model.ir_version = 8
    return model


# ── conv_relu_chain ───────────────────────────────────────────────────

def build_conv_relu_chain() -> onnx.ModelProto:
    """Conv → ReLU → Conv.  Input [1,3,32,32], output [1,8,28,28]."""
    X = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 3, 32, 32])
    Y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 8, 28, 28])

    w0 = helper.make_tensor("w0", TensorProto.FLOAT, [8, 3, 3, 3],
                            np.zeros((8, 3, 3, 3), dtype=np.float32).flatten().tolist())
    b0 = helper.make_tensor("b0", TensorProto.FLOAT, [8],
                            np.zeros(8, dtype=np.float32).tolist())
    w1 = helper.make_tensor("w1", TensorProto.FLOAT, [8, 8, 3, 3],
                            np.zeros((8, 8, 3, 3), dtype=np.float32).flatten().tolist())
    b1 = helper.make_tensor("b1", TensorProto.FLOAT, [8],
                            np.zeros(8, dtype=np.float32).tolist())

    conv0 = helper.make_node("Conv", ["input", "w0", "b0"], ["t0"], name="conv0",
                             kernel_shape=[3, 3], strides=[1, 1], pads=[0, 0, 0, 0])
    relu = helper.make_node("Relu", ["t0"], ["t1"], name="relu0")
    conv1 = helper.make_node("Conv", ["t1", "w1", "b1"], ["output"], name="conv1",
                             kernel_shape=[3, 3], strides=[1, 1], pads=[0, 0, 0, 0])

    graph = helper.make_graph([conv0, relu, conv1], "conv_relu_chain",
                              [X], [Y], initializer=[w0, b0, w1, b1])
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)])
    model.ir_version = 8
    return model


# ── DS-CNN (keyword spotting) ─────────────────────────────────────────

def build_ds_cnn() -> onnx.ModelProto:
    """MLPerf Tiny DS-CNN: depthwise-separable CNN for keyword spotting.

    Conv(10x4,s2)→BN→ReLU → 4×[DWConv(3x3)→BN→ReLU→Conv(1x1)→BN→ReLU]
    → GlobalAvgPool → Flatten → FC(12).
    Input: [1, 1, 49, 10] (NCHW, mel spectrogram).
    Output: [1, 12] (12 keyword classes).
    """
    np.random.seed(42)

    def _conv_bn_relu(prefix, x_name, out_name, c_in, c_out, kh, kw, sh, sw, group=1):
        nodes, inits = [], []
        conv_out = f"{prefix}_conv_out"
        w = np.random.randn(c_out, c_in // group, kh, kw).astype(np.float32) * 0.1
        b = np.zeros(c_out, dtype=np.float32)
        inits.append(numpy_helper.from_array(w, f"{prefix}_w"))
        inits.append(numpy_helper.from_array(b, f"{prefix}_b"))
        pad_h, pad_w = max(0, kh - 1), max(0, kw - 1)
        pt, pb = pad_h // 2, pad_h - pad_h // 2
        pl, pr = pad_w // 2, pad_w - pad_w // 2
        nodes.append(helper.make_node(
            "Conv", [x_name, f"{prefix}_w", f"{prefix}_b"], [conv_out],
            name=f"{prefix}_conv", kernel_shape=[kh, kw], strides=[sh, sw],
            pads=[pt, pl, pb, pr], group=group))
        bn_out = f"{prefix}_bn_out"
        for suffix, data in [("scale", np.ones(c_out)), ("bias", np.zeros(c_out)),
                             ("mean", np.zeros(c_out)), ("var", np.ones(c_out))]:
            inits.append(numpy_helper.from_array(data.astype(np.float32), f"{prefix}_{suffix}"))
        nodes.append(helper.make_node(
            "BatchNormalization",
            [conv_out, f"{prefix}_scale", f"{prefix}_bias", f"{prefix}_mean", f"{prefix}_var"],
            [bn_out], name=f"{prefix}_bn"))
        nodes.append(helper.make_node("Relu", [bn_out], [out_name], name=f"{prefix}_relu"))
        return nodes, inits

    all_nodes, all_inits = [], []
    X = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 1, 49, 10])

    n, i = _conv_bn_relu("block0", "input", "b0_out", 1, 64, 10, 4, 2, 2)
    all_nodes.extend(n); all_inits.extend(i)

    prev = "b0_out"
    for idx in range(1, 5):
        n, i = _conv_bn_relu(f"dw{idx}", prev, f"dw{idx}_out", 64, 64, 3, 3, 1, 1, group=64)
        all_nodes.extend(n); all_inits.extend(i)
        n, i = _conv_bn_relu(f"pw{idx}", f"dw{idx}_out", f"pw{idx}_out", 64, 64, 1, 1, 1, 1)
        all_nodes.extend(n); all_inits.extend(i)
        prev = f"pw{idx}_out"

    all_nodes.append(helper.make_node("GlobalAveragePool", [prev], ["pool_out"], name="gap"))
    all_nodes.append(helper.make_node("Flatten", ["pool_out"], ["flat_out"], name="flatten", axis=1))
    fc_w = np.random.randn(12, 64).astype(np.float32) * 0.1
    fc_b = np.zeros(12, dtype=np.float32)
    all_inits.append(numpy_helper.from_array(fc_w, "fc_w"))
    all_inits.append(numpy_helper.from_array(fc_b, "fc_b"))
    all_nodes.append(helper.make_node("Gemm", ["flat_out", "fc_w", "fc_b"], ["output"],
                                      name="fc", transB=1))
    Y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 12])

    graph = helper.make_graph(all_nodes, "ds_cnn", [X], [Y], initializer=all_inits)
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)])
    model.ir_version = 8
    onnx.checker.check_model(model)
    return model


# ── FC Autoencoder (anomaly detection) ────────────────────────────────

def build_fc_autoencoder() -> onnx.ModelProto:
    """MLPerf Tiny FC autoencoder for anomaly detection.

    128→128→128→128→128→8 (encoder) → 128→128→128→128 (decoder) → Sigmoid.
    Input: [1, 128] (log-mel spectrogram frame).
    Output: [1, 128] (reconstructed frame).
    """
    np.random.seed(43)

    all_nodes, all_inits = [], []
    X = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 128])

    layer_dims = [128, 128, 128, 128, 128, 8, 128, 128, 128, 128]
    prev = "input"
    prev_dim = 128

    for idx, dim_out in enumerate(layer_dims):
        prefix = f"fc{idx}"
        fc_out = f"{prefix}_out"
        w = np.random.randn(dim_out, prev_dim).astype(np.float32) * 0.1
        b = np.zeros(dim_out, dtype=np.float32)
        all_inits.append(numpy_helper.from_array(w, f"{prefix}_w"))
        all_inits.append(numpy_helper.from_array(b, f"{prefix}_b"))
        all_nodes.append(helper.make_node(
            "Gemm", [prev, f"{prefix}_w", f"{prefix}_b"], [fc_out],
            name=prefix, transB=1))

        if idx < len(layer_dims) - 1:
            relu_out = f"{prefix}_relu_out"
            all_nodes.append(helper.make_node("Relu", [fc_out], [relu_out],
                                              name=f"{prefix}_relu"))
            prev = relu_out
        else:
            all_nodes.append(helper.make_node("Sigmoid", [fc_out], ["output"],
                                              name="output_sigmoid"))
            prev = "output"

        prev_dim = dim_out

    Y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 128])

    graph = helper.make_graph(all_nodes, "fc_autoencoder", [X], [Y], initializer=all_inits)
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)])
    model.ir_version = 8
    onnx.checker.check_model(model)
    return model


# ── Gated TCN (time-series classification) ───────────────────────────

def build_tcn() -> onnx.ModelProto:
    """Gated TCN for activity recognition (accelerometer time-series).

    Input: [1, 3, 128] (NCL: 3 accel axes, 128 timesteps).
    Output: [1, 6] (6 activity classes).

    Architecture:
      Block 1: Conv1D(3→16, k=3, d=1, causal) → BN → ReLU
      Block 2: Conv1D(16→16, k=3, d=2, causal) → BN → ReLU
      Gated:   Conv1D(16→16, k=3, d=4, causal) → BN → Tanh  ─┐
               Conv1D(16→16, k=3, d=4, causal) → BN → Sigmoid ─ Mul
      Block 4: Conv1D(16→16, k=3, d=8, causal) → BN → ReLU
      Flatten → FC(2048→6)

    Causal padding: pad_left = dilation * (kernel - 1), pad_right = 0.
    """
    np.random.seed(44)

    def _conv1d_bn(prefix, x_name, out_name, c_in, c_out, k, dilation, act):
        """Conv1D → BN → activation. Returns (nodes, initializers)."""
        nodes, inits = [], []
        conv_out = f"{prefix}_conv_out"
        w = np.random.randn(c_out, c_in, k).astype(np.float32) * 0.1
        b = np.zeros(c_out, dtype=np.float32)
        inits.append(numpy_helper.from_array(w, f"{prefix}_w"))
        inits.append(numpy_helper.from_array(b, f"{prefix}_b"))
        # Causal padding: pad_left = dilation * (k - 1), pad_right = 0
        pad_begin = dilation * (k - 1)
        nodes.append(helper.make_node(
            "Conv", [x_name, f"{prefix}_w", f"{prefix}_b"], [conv_out],
            name=f"{prefix}_conv", kernel_shape=[k], strides=[1],
            pads=[pad_begin, 0], dilations=[dilation]))

        bn_out = f"{prefix}_bn_out"
        for suffix, data in [("scale", np.ones(c_out)), ("bias", np.zeros(c_out)),
                             ("mean", np.zeros(c_out)), ("var", np.ones(c_out))]:
            inits.append(numpy_helper.from_array(data.astype(np.float32), f"{prefix}_{suffix}"))
        nodes.append(helper.make_node(
            "BatchNormalization",
            [conv_out, f"{prefix}_scale", f"{prefix}_bias", f"{prefix}_mean", f"{prefix}_var"],
            [bn_out], name=f"{prefix}_bn"))

        nodes.append(helper.make_node(act, [bn_out], [out_name], name=f"{prefix}_{act.lower()}"))
        return nodes, inits

    all_nodes, all_inits = [], []
    X = helper.make_tensor_value_info("input", TensorProto.FLOAT, [1, 3, 128])

    # Block 1: Conv1D(3→16, k=3, d=1) → BN → ReLU
    n, i = _conv1d_bn("block1", "input", "b1_out", 3, 16, 3, 1, "Relu")
    all_nodes.extend(n); all_inits.extend(i)

    # Block 2: Conv1D(16→16, k=3, d=2) → BN → ReLU
    n, i = _conv1d_bn("block2", "b1_out", "b2_out", 16, 16, 3, 2, "Relu")
    all_nodes.extend(n); all_inits.extend(i)

    # Gated block: two parallel Conv1D(16→16, k=3, d=4) → BN → Tanh / Sigmoid → Mul
    n, i = _conv1d_bn("gate_t", "b2_out", "gate_tanh_out", 16, 16, 3, 4, "Tanh")
    all_nodes.extend(n); all_inits.extend(i)
    n, i = _conv1d_bn("gate_s", "b2_out", "gate_sig_out", 16, 16, 3, 4, "Sigmoid")
    all_nodes.extend(n); all_inits.extend(i)
    all_nodes.append(helper.make_node("Mul", ["gate_tanh_out", "gate_sig_out"], ["gate_out"],
                                      name="gate_mul"))

    # Block 4: Conv1D(16→16, k=3, d=8) → BN → ReLU
    n, i = _conv1d_bn("block4", "gate_out", "b4_out", 16, 16, 3, 8, "Relu")
    all_nodes.extend(n); all_inits.extend(i)

    # Flatten → FC(2048→6)
    all_nodes.append(helper.make_node("Flatten", ["b4_out"], ["flat_out"], name="flatten", axis=1))
    fc_w = np.random.randn(6, 2048).astype(np.float32) * 0.1
    fc_b = np.zeros(6, dtype=np.float32)
    all_inits.append(numpy_helper.from_array(fc_w, "fc_w"))
    all_inits.append(numpy_helper.from_array(fc_b, "fc_b"))
    all_nodes.append(helper.make_node("Gemm", ["flat_out", "fc_w", "fc_b"], ["output"],
                                      name="fc", transB=1))

    Y = helper.make_tensor_value_info("output", TensorProto.FLOAT, [1, 6])

    graph = helper.make_graph(all_nodes, "tcn", [X], [Y], initializer=all_inits)
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)])
    model.ir_version = 8
    onnx.checker.check_model(model)
    return model


# ── gen-fixtures command ──────────────────────────────────────────────

@cli.command("gen-fixtures")
@click.argument("model", type=click.Path(exists=True))
@click.option("--output-dir", "-o", required=True, type=click.Path(), help="Output directory for fixture files")
@click.option("--mem", "-m", default="256K", help="Memory budget for MobileNetV2 (default: 256K)")
def gen_fixtures(model: str, output_dir: str, mem: str):
    """Regenerate all C test fixtures (small models + MobileNetV2 plan + reference)."""
    import tempfile

    import onnxruntime as ort

    from tigris.emitters.binary.writer import emit_binary

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    # Inline models: build ONNX → compile → emit plan (+ reference for E2E models)
    _INLINE = [
        ("linear_3op",      build_linear_3op,      "4K",   False),
        ("conv_relu_chain", build_conv_relu_chain,  "32K",  False),
        ("ds_cnn",          build_ds_cnn,           "256K", True),
        ("fc_autoencoder",  build_fc_autoencoder,   "256K", True),
        ("tcn",             build_tcn,              "256K", True),
    ]

    for name, builder, budget, gen_ref in _INLINE:
        console.print(f"[bold]Generating {name} fixture...[/]")
        onnx_model = builder()
        with tempfile.TemporaryDirectory() as tmp:
            onnx_path = Path(tmp) / f"{name}.onnx"
            onnx.save(onnx_model, str(onnx_path))
            ag, _ = _run_pipeline(str(onnx_path), (budget,))
            plan_path = out / f"{name}.plan.bin"
            emit_binary(ag, plan_path)
            console.print(f"  {plan_path} ({plan_path.stat().st_size} bytes)")

            if gen_ref:
                sess = ort.InferenceSession(str(onnx_path))
                inp_meta = sess.get_inputs()[0]
                shape = [1 if isinstance(d, str) else d for d in inp_meta.shape]
                inp_data = np.ones(shape, dtype=np.float32)
                results = sess.run(None, {inp_meta.name: inp_data})
                ref_data = b"".join(r.astype(np.float32).tobytes() for r in results)
                ref_path = out / f"{name}.reference.bin"
                ref_path.write_bytes(ref_data)
                console.print(f"  {ref_path} ({len(ref_data)} bytes, {len(ref_data)//4} floats)")

    # ── MobileNetV2 (external ONNX) ──────────────────────────────
    console.print(f"[bold]Compiling MobileNetV2: {model}...[/]")
    ag, budget_val = _run_pipeline(model, (mem,))
    plan_path = out / "mobilenetv2.plan.bin"
    emit_binary(ag, plan_path)
    console.print(f"  Plan: {plan_path} ({plan_path.stat().st_size} bytes)")

    console.print("[bold]Generating MobileNetV2 reference output...[/]")
    sess = ort.InferenceSession(model)
    inp_meta = sess.get_inputs()[0]
    shape = [1 if isinstance(d, str) else d for d in inp_meta.shape]
    inp_data = np.ones(shape, dtype=np.float32)
    results = sess.run(None, {inp_meta.name: inp_data})
    ref_data = b"".join(r.astype(np.float32).tobytes() for r in results)
    ref_path = out / "mobilenetv2.reference.bin"
    ref_path.write_bytes(ref_data)
    console.print(f"  Reference: {ref_path} ({len(ref_data)} bytes, {len(ref_data)//4} floats)")

    console.print(f"\n[bold green]All fixtures written to {out}/[/]")
