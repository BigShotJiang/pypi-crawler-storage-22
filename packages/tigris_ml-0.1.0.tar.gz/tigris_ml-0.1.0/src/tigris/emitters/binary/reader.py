"""Binary plan reader — deserialization for test validation."""

import struct

from .defs import (
    HEADER_SIZE,
    MAGIC,
    OP_SIZE,
    SECTION_ENTRY_SIZE,
    SEC_INDEX_POOL,
    SEC_OPS,
    SEC_SHAPE_POOL,
    SEC_STAGES,
    SEC_STRINGS,
    SEC_TENSORS,
    SEC_TILE_PLANS,
    SEC_WEIGHTS,
    STAGE_SIZE,
    TENSOR_SIZE,
    TILE_PLAN_SIZE,
    WEIGHT_ENTRY_SIZE,
)


def read_binary_plan(data: bytes) -> dict:
    """Parse a binary plan file into a dict for test validation.

    Returns a dict with keys: magic, version, file_size, num_tensors, num_ops,
    num_stages, num_tile_plans, budget, peak, model_name, tensors, ops, stages,
    tile_plans, model_inputs, model_outputs.
    """
    if len(data) < HEADER_SIZE:
        raise ValueError(f"File too small: {len(data)} < {HEADER_SIZE}")

    # Parse header
    (
        magic, version, _pad,
        file_size, section_dir_off,
        num_tensors, num_ops, num_stages, num_tile_plans,
        budget, peak,
        model_name_str,
        model_io_off, num_model_inputs, num_model_outputs,
        num_weights, _reserved0, _reserved1,
    ) = struct.unpack_from("<4sHH II HHHH II I HBB HH I", data, 0)

    if magic != MAGIC:
        raise ValueError(f"Bad magic: {magic!r}")
    if file_size != len(data):
        raise ValueError(f"File size mismatch: header says {file_size}, got {len(data)}")

    # Parse section directory
    sections: dict[int, int] = {}
    off = section_dir_off
    while off + SECTION_ENTRY_SIZE <= len(data):
        sec_type, sec_off = struct.unpack_from("<II", data, off)
        off += SECTION_ENTRY_SIZE
        if sec_type == 0:
            break
        sections[sec_type] = sec_off

    def _read_string(str_off: int) -> str:
        base = sections[SEC_STRINGS]
        pos = base + str_off
        end = data.index(0, pos)
        return data[pos:end].decode("utf-8")

    def _read_index_pool(pool_off: int, count: int) -> list[int]:
        base = sections[SEC_INDEX_POOL]
        pos = base + pool_off * 2
        return list(struct.unpack_from(f"<{count}H", data, pos))

    def _read_shape(shape_off: int, ndim: int) -> list[int]:
        base = sections[SEC_SHAPE_POOL]
        pos = base + shape_off * 4
        return list(struct.unpack_from(f"<{ndim}i", data, pos))

    model_name = _read_string(model_name_str)

    # Parse tensors
    tensors = []
    t_base = sections[SEC_TENSORS]
    for i in range(num_tensors):
        pos = t_base + i * TENSOR_SIZE
        name_off, size_bytes, shape_off, ndim, dtype, flags = struct.unpack_from(
            "<IIHBBBxxx", data, pos
        )
        tensors.append({
            "name": _read_string(name_off),
            "size_bytes": size_bytes,
            "shape": _read_shape(shape_off, ndim),
            "ndim": ndim,
            "dtype": dtype,
            "flags": flags,
        })

    # Parse ops
    ops = []
    o_base = sections[SEC_OPS]
    for i in range(num_ops):
        pos = o_base + i * OP_SIZE
        name_off, op_type, num_inp, num_out, stage, inp_off, out_off = struct.unpack_from(
            "<IBBBB HH", data, pos
        )
        spatial_pos = pos + 12  # after the first 12 bytes
        (kh, kw, sh, sw, pt, pb, pl, pr, dh, dw, group) = struct.unpack_from(
            "<10BH", data, spatial_pos
        )
        weight_idx_val, bias_idx_val = struct.unpack_from("<HH", data, pos + 24)
        ops.append({
            "name": _read_string(name_off),
            "op_type": op_type,
            "inputs": _read_index_pool(inp_off, num_inp),
            "outputs": _read_index_pool(out_off, num_out),
            "stage": stage,
            "spatial": {
                "kernel_h": kh, "kernel_w": kw,
                "stride_h": sh, "stride_w": sw,
                "pad_top": pt, "pad_bottom": pb,
                "pad_left": pl, "pad_right": pr,
                "dilation_h": dh, "dilation_w": dw,
                "group": group,
            },
            "weight_idx": weight_idx_val,
            "bias_idx": bias_idx_val,
        })

    # Parse stages
    stages = []
    s_base = sections.get(SEC_STAGES, 0)
    for i in range(num_stages):
        pos = s_base + i * STAGE_SIZE
        (
            peak_bytes,
            ops_off, ops_count,
            inp_off, inp_count,
            out_off, out_count,
            tile_idx, _pad,
            _reserved, _reserved2,
        ) = struct.unpack_from("<I HHHHHH HH II", data, pos)
        stages.append({
            "peak_bytes": peak_bytes,
            "ops": _read_index_pool(ops_off, ops_count),
            "inputs": _read_index_pool(inp_off, inp_count),
            "outputs": _read_index_pool(out_off, out_count),
            "tile_plan_idx": tile_idx,
        })

    # Parse tile plans
    tile_plans = []
    tp_base = sections.get(SEC_TILE_PLANS, 0)
    for i in range(num_tile_plans):
        pos = tp_base + i * TILE_PLAN_SIZE
        (
            tileable, _pad, tile_height,
            n_tiles, halo,
            rf, orig_h,
            tiled_peak, overhead, _reserved,
        ) = struct.unpack_from("<BBH HH HH I I I", data, pos)
        tile_plans.append({
            "tileable": bool(tileable),
            "tile_height": tile_height,
            "num_tiles": n_tiles,
            "halo": halo,
            "receptive_field": rf,
            "original_height": orig_h,
            "tiled_peak_bytes": tiled_peak,
            "overhead_bytes": overhead,
        })

    # Parse weights
    weights = []
    w_base = sections.get(SEC_WEIGHTS, 0)
    if w_base and num_weights > 0:
        entries_size = num_weights * WEIGHT_ENTRY_SIZE
        blob_base = w_base + entries_size
        for i in range(num_weights):
            pos = w_base + i * WEIGHT_ENTRY_SIZE
            w_name_off, w_offset, w_size = struct.unpack_from("<III", data, pos)
            weights.append({
                "name": _read_string(w_name_off),
                "offset": w_offset,
                "size_bytes": w_size,
                "blob_base": blob_base,
            })

    # Resolve model I/O from index pool
    all_io = _read_index_pool(model_io_off, num_model_inputs + num_model_outputs)
    model_inputs_idx = all_io[:num_model_inputs]
    model_outputs_idx = all_io[num_model_inputs:]

    return {
        "magic": magic,
        "version": version,
        "file_size": file_size,
        "num_tensors": num_tensors,
        "num_ops": num_ops,
        "num_stages": num_stages,
        "num_tile_plans": num_tile_plans,
        "num_weights": num_weights,
        "budget": budget,
        "peak": peak,
        "model_name": model_name,
        "tensors": tensors,
        "ops": ops,
        "stages": stages,
        "tile_plans": tile_plans,
        "weights": weights,
        "model_inputs": model_inputs_idx,
        "model_outputs": model_outputs_idx,
    }
