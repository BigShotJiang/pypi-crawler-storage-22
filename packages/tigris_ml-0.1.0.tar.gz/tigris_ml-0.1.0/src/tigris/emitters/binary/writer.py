"""Binary plan emitter — serialization (pool helpers + emit)."""

import struct
from pathlib import Path

import numpy as np

from tigris import SCHEMA_VERSION
from tigris.graph.ir import AnalyzedGraph, OpNode

from .defs import (
    HEADER_SIZE,
    MAGIC,
    NO_WEIGHT,
    OP_TYPE_MAP,
    OP_TYPE_UNKNOWN,
    SEC_INDEX_POOL,
    SEC_OPS,
    SEC_SHAPE_POOL,
    SEC_STAGES,
    SEC_STRINGS,
    SEC_TENSORS,
    SEC_TILE_PLANS,
    SEC_WEIGHTS,
    SECTION_ENTRY_SIZE,
    STAGE_SIZE,
    TENSOR_FLAG_CONSTANT,
    TENSOR_FLAG_MODEL_INPUT,
    TENSOR_FLAG_MODEL_OUTPUT,
    WEIGHT_ENTRY_SIZE,
)


# ── Helper: String Table ─────────────────────────────────────────────


class _StringTable:
    """Deduplicating null-terminated string pool."""

    def __init__(self) -> None:
        self._map: dict[str, int] = {}
        self._buf = bytearray()

    def add(self, s: str) -> int:
        """Add string, return byte offset. Empty string → offset 0."""
        if not s:
            # ensure we have an empty string at offset 0
            if 0 not in self._map.values() or not self._buf:
                if not self._buf:
                    self._map[""] = 0
                    self._buf.append(0)
            return self._map.get("", 0)
        if s in self._map:
            return self._map[s]
        offset = len(self._buf)
        self._map[s] = offset
        self._buf.extend(s.encode("utf-8"))
        self._buf.append(0)
        return offset

    def data(self) -> bytes:
        if not self._buf:
            self._buf.append(0)  # at least one null byte
        return bytes(self._buf)


# ── Helper: Index Pool ───────────────────────────────────────────────


class _IndexPool:
    """Shared uint16 index array pool."""

    def __init__(self) -> None:
        self._items: list[int] = []

    def add(self, indices: list[int]) -> tuple[int, int]:
        """Add a list of indices, return (offset, count)."""
        offset = len(self._items)
        count = len(indices)
        self._items.extend(indices)
        return offset, count

    def data(self) -> bytes:
        return struct.pack(f"<{len(self._items)}H", *self._items) if self._items else b""


# ── Helper: Shape Pool ───────────────────────────────────────────────


class _ShapePool:
    """Shared int32 shape dimension pool."""

    def __init__(self) -> None:
        self._items: list[int] = []

    def add(self, shape: tuple[int, ...]) -> tuple[int, int]:
        """Add shape dims, return (offset, ndim)."""
        offset = len(self._items)
        self._items.extend(int(d) for d in shape)
        return offset, len(shape)

    def data(self) -> bytes:
        return struct.pack(f"<{len(self._items)}i", *self._items) if self._items else b""


# ── Spatial attrs packing ─────────────────────────────────────────────


def _pack_spatial_attrs(op: OpNode) -> bytes:
    """Pack 12 bytes of spatial attributes.

    Layout:
        kernel_h(u8) kernel_w(u8) stride_h(u8) stride_w(u8)
        pad_top(u8) pad_bottom(u8) pad_left(u8) pad_right(u8)
        dilation_h(u8) dilation_w(u8) group(u16 LE)
    Total: 12 bytes
    """
    attrs = op.attrs
    ks = attrs.get("kernel_shape", [])
    st = attrs.get("strides", [])
    pa = attrs.get("pads", [])
    di = attrs.get("dilations", [])
    gr = int(attrs.get("group", 1))

    is_1d = len(ks) == 1

    kernel_h = int(ks[0]) if len(ks) >= 1 else 0
    kernel_w = int(ks[1]) if len(ks) >= 2 else (1 if is_1d else (kernel_h if ks else 0))
    stride_h = int(st[0]) if len(st) >= 1 else 0
    stride_w = int(st[1]) if len(st) >= 2 else (1 if is_1d else (stride_h if st else 0))
    dilation_h = int(di[0]) if len(di) >= 1 else 0
    dilation_w = int(di[1]) if len(di) >= 2 else (1 if is_1d else (dilation_h if di else 0))

    if is_1d and len(pa) == 2:
        # ONNX Conv1D pads: [begin, end]
        pad_top = int(pa[0])
        pad_bottom = int(pa[1])
        pad_left = 0
        pad_right = 0
    else:
        pad_top = int(pa[0]) if len(pa) >= 1 else 0
        pad_left = int(pa[1]) if len(pa) >= 2 else 0
        pad_bottom = int(pa[2]) if len(pa) >= 3 else 0
        pad_right = int(pa[3]) if len(pa) >= 4 else 0

    return struct.pack(
        "<10BH",
        kernel_h, kernel_w, stride_h, stride_w,
        pad_top, pad_bottom, pad_left, pad_right,
        dilation_h, dilation_w,
        gr,
    )


# ── Build functions ───────────────────────────────────────────────────


def _build_weights(
    ag: AnalyzedGraph,
    strings: _StringTable,
) -> tuple[bytes, dict[str, int]]:
    """Build weight entries and contiguous weight blob.

    Returns (section_bytes, name→weight_index map).
    Section layout: weight_entry_t[num_weights] + contiguous weight blob.
    """
    if not ag.weight_data:
        return b"", {}

    weight_idx: dict[str, int] = {}
    entries_buf = bytearray()
    blob_buf = bytearray()

    for idx, (name, arr) in enumerate(ag.weight_data.items()):
        weight_idx[name] = idx
        raw = arr.astype(np.float32).tobytes()
        name_off = strings.add(name)
        blob_offset = len(blob_buf)
        entries_buf.extend(struct.pack(
            "<III",
            name_off,
            blob_offset,
            len(raw),
        ))
        blob_buf.extend(raw)

    return bytes(entries_buf) + bytes(blob_buf), weight_idx


def _build_tensors(
    ag: AnalyzedGraph,
    strings: _StringTable,
    shapes: _ShapePool,
) -> tuple[bytes, dict[str, int]]:
    """Build tensor table. Returns (bytes, name→index map)."""
    buf = bytearray()
    tensor_idx: dict[str, int] = {}
    idx = 0

    for name, info in ag.tensors.items():
        if info.is_constant:
            continue

        tensor_idx[name] = idx
        idx += 1

        name_off = strings.add(name)
        shape_off, ndim = shapes.add(info.shape)

        flags = 0
        if info.is_constant:
            flags |= TENSOR_FLAG_CONSTANT
        if name in ag.model_inputs:
            flags |= TENSOR_FLAG_MODEL_INPUT
        if name in ag.model_outputs:
            flags |= TENSOR_FLAG_MODEL_OUTPUT

        # tigris_tensor_t: 16 bytes
        # name_str(u32) size_bytes(u32) shape_offset(u16) ndim(u8) dtype(u8) flags(u8) pad(3)
        buf.extend(struct.pack(
            "<IIHBBBxxx",
            name_off,
            info.size_bytes,
            shape_off,
            ndim,
            info.dtype,
            flags,
        ))

    return bytes(buf), tensor_idx


def _resolve_weight_bias(op: OpNode, weight_idx: dict[str, int]) -> tuple[int, int]:
    """Map an op's constant inputs to weight/bias indices.

    Convention: for ops like Conv/Gemm, input[1] is the weight and input[2]
    is the optional bias. For all ops, the first constant input is the weight
    and the second (if any) is the bias.
    Returns (weight_idx, bias_idx) with NO_WEIGHT for missing entries.
    """
    w_idx = NO_WEIGHT
    b_idx = NO_WEIGHT

    # Walk the op's inputs and find those that are weights
    const_inputs = [inp for inp in op.inputs if inp in weight_idx]

    if len(const_inputs) >= 1:
        w_idx = weight_idx[const_inputs[0]]
    if len(const_inputs) >= 2:
        b_idx = weight_idx[const_inputs[1]]

    return w_idx, b_idx


def _build_ops(
    ag: AnalyzedGraph,
    tensor_idx: dict[str, int],
    weight_idx: dict[str, int],
    strings: _StringTable,
    index_pool: _IndexPool,
) -> bytes:
    """Build op table. Returns bytes."""
    buf = bytearray()

    for op in ag.ops:
        name_off = strings.add(op.name)
        op_type = OP_TYPE_MAP.get(op.op_type, OP_TYPE_UNKNOWN)

        # Map input/output tensor names to indices (skip constants)
        inp_indices = [tensor_idx[n] for n in op.inputs if n in tensor_idx]
        out_indices = [tensor_idx[n] for n in op.outputs if n in tensor_idx]

        inp_off, inp_count = index_pool.add(inp_indices)
        out_off, out_count = index_pool.add(out_indices)

        spatial = _pack_spatial_attrs(op)

        # Resolve weight/bias indices from op's constant inputs
        w_idx, b_idx = _resolve_weight_bias(op, weight_idx)

        # tigris_op_t: 28 bytes
        # name_str(u32) op_type(u8) num_inputs(u8) num_outputs(u8) stage(u8)
        # inputs_offset(u16) outputs_offset(u16)
        # spatial_attrs(12 bytes)
        # weight_idx(u16) bias_idx(u16)
        buf.extend(struct.pack(
            "<IBBBB HH",
            name_off,
            op_type,
            inp_count,
            out_count,
            max(op.stage, 0) & 0xFF,
            inp_off,
            out_off,
        ))
        buf.extend(spatial)
        buf.extend(struct.pack("<HH", w_idx, b_idx))

    return bytes(buf)


def _build_stages(
    ag: AnalyzedGraph,
    tensor_idx: dict[str, int],
    index_pool: _IndexPool,
) -> bytes:
    """Build stage table. Returns bytes."""
    buf = bytearray()

    for stage in ag.stages:
        ops_off, ops_count = index_pool.add(stage.op_indices)

        inp_indices = [tensor_idx[n] for n in stage.input_tensors if n in tensor_idx]
        out_indices = [tensor_idx[n] for n in stage.output_tensors if n in tensor_idx]

        inp_off, inp_count = index_pool.add(inp_indices)
        out_off, out_count = index_pool.add(out_indices)

        # tile_plan_idx: index into tile_plan table, or 0xFFFF if none
        tile_idx = 0xFFFF
        # We'll set this after building tile plans; for now track stage_id → tile_plan_idx
        # Actually, we build tile plans in order of stages that have them
        # Let the caller patch this

        # tigris_stage_t: 28 bytes
        # peak_bytes(u32)
        # ops_offset(u16) ops_count(u16)
        # inputs_offset(u16) inputs_count(u16)
        # outputs_offset(u16) outputs_count(u16)
        # tile_plan_idx(u16) pad(u16)
        # reserved(u32) reserved2(u32)
        buf.extend(struct.pack(
            "<I HHHHHH HH II",
            stage.peak_bytes,
            ops_off, ops_count,
            inp_off, inp_count,
            out_off, out_count,
            tile_idx, 0,
            0,  # reserved
            0,  # reserved2
        ))

    return bytes(buf)


def _build_tile_plans(ag: AnalyzedGraph) -> tuple[bytes, dict[int, int]]:
    """Build tile plan table. Returns (bytes, stage_id→tile_plan_index map)."""
    buf = bytearray()
    stage_to_tile: dict[int, int] = {}
    idx = 0

    for stage in ag.stages:
        tp = stage.tile_plan
        if tp is None:
            continue

        stage_to_tile[stage.stage_id] = idx
        idx += 1

        # tigris_tile_plan_t: 24 bytes
        # tileable(u8) pad(u8) tile_height(u16)
        # num_tiles(u16) halo(u16)
        # receptive_field(u16) original_height(u16)
        # tiled_peak_bytes(u32)
        # overhead_bytes(u32)
        # reserved(u32)
        buf.extend(struct.pack(
            "<BBH HH HH I I I",
            1 if tp.tileable else 0,
            0,  # pad
            tp.tile_height,
            tp.num_tiles,
            tp.halo,
            tp.receptive_field,
            tp.original_height,
            tp.tiled_peak_bytes,
            tp.overhead_bytes,
            0,  # reserved
        ))

    return bytes(buf), stage_to_tile


def _patch_stage_tile_indices(stage_data: bytearray, ag: AnalyzedGraph, stage_to_tile: dict[int, int]) -> bytes:
    """Patch tile_plan_idx in stage entries."""
    for i, stage in enumerate(ag.stages):
        tile_idx = stage_to_tile.get(stage.stage_id, 0xFFFF)
        offset = i * STAGE_SIZE + 16  # offset of tile_plan_idx within stage struct
        struct.pack_into("<H", stage_data, offset, tile_idx)
    return bytes(stage_data)


# ── Main emit function ────────────────────────────────────────────────


def emit_binary(ag: AnalyzedGraph, path: Path) -> None:
    """Write an execution plan as a binary file to *path*."""
    data = emit_binary_bytes(ag)
    with open(path, "wb") as f:
        f.write(data)


def emit_binary_bytes(ag: AnalyzedGraph) -> bytes:
    """Build the complete binary plan and return as bytes."""
    strings = _StringTable()
    shapes = _ShapePool()
    index_pool = _IndexPool()

    # Add model name to strings first
    model_name_off = strings.add(ag.model_name)

    # Build weights section (must happen before ops so weight_idx map is ready)
    weight_data, weight_idx = _build_weights(ag, strings)

    # Add model I/O to index pool
    tensor_data, tensor_idx = _build_tensors(ag, strings, shapes)

    model_inp_indices = [tensor_idx[n] for n in ag.model_inputs if n in tensor_idx]
    model_out_indices = [tensor_idx[n] for n in ag.model_outputs if n in tensor_idx]
    model_io_off, model_io_count = index_pool.add(model_inp_indices + model_out_indices)

    op_data = _build_ops(ag, tensor_idx, weight_idx, strings, index_pool)
    stage_data = bytearray(_build_stages(ag, tensor_idx, index_pool))
    tile_data, stage_to_tile = _build_tile_plans(ag)
    stage_data_final = _patch_stage_tile_indices(stage_data, ag, stage_to_tile)

    index_data = index_pool.data()
    shape_data = shapes.data()
    string_data = strings.data()

    # Counts
    num_tensors = len(tensor_idx)
    num_ops = len(ag.ops)
    num_stages = len(ag.stages)
    num_tile_plans = len(stage_to_tile)
    num_weights = len(weight_idx)

    # Section directory (one entry per section + sentinel)
    has_weights = num_weights > 0
    num_sections = 7 + (1 if has_weights else 0)
    section_dir_size = (num_sections + 1) * SECTION_ENTRY_SIZE  # +1 for sentinel

    body_start = HEADER_SIZE + section_dir_size

    current = body_start
    sec_tensors_off = current; current += len(tensor_data)
    sec_ops_off = current; current += len(op_data)
    sec_stages_off = current; current += len(stage_data_final)
    sec_tiles_off = current; current += len(tile_data)
    sec_index_off = current; current += len(index_data)
    sec_shape_off = current; current += len(shape_data)
    sec_strings_off = current; current += len(string_data)
    if has_weights:
        sec_weights_off = current; current += len(weight_data)
    file_size = current

    sections = [
        (SEC_TENSORS, sec_tensors_off),
        (SEC_OPS, sec_ops_off),
        (SEC_STAGES, sec_stages_off),
        (SEC_TILE_PLANS, sec_tiles_off),
        (SEC_INDEX_POOL, sec_index_off),
        (SEC_SHAPE_POOL, sec_shape_off),
        (SEC_STRINGS, sec_strings_off),
    ]
    if has_weights:
        sections.append((SEC_WEIGHTS, sec_weights_off))

    # Build section directory
    sec_dir = bytearray()
    for sec_type, sec_off in sections:
        sec_dir.extend(struct.pack("<II", sec_type, sec_off))
    sec_dir.extend(struct.pack("<II", 0, 0))  # sentinel

    # Build header (48 bytes)
    # magic(4) version(u16) pad(u16)
    # file_size(u32) section_dir_offset(u32)
    # num_tensors(u16) num_ops(u16) num_stages(u16) num_tile_plans(u16)
    # budget(u32) peak(u32)
    # model_name_str(u32)
    # model_io_offset(u16) num_model_inputs(u8) num_model_outputs(u8)
    # num_weights(u16) _reserved0(u16) reserved1(u32)
    header = struct.pack(
        "<4sHH II HHHH II I HBB HH I",
        MAGIC,
        SCHEMA_VERSION,
        0,  # pad
        file_size,
        HEADER_SIZE,  # section_dir starts right after header
        num_tensors,
        num_ops,
        num_stages,
        num_tile_plans,
        ag.mem_budget,
        ag.peak_memory_bytes,
        model_name_off,
        model_io_off,
        len(model_inp_indices),
        len(model_out_indices),
        num_weights,
        0,  # _reserved0
        0,  # reserved1
    )
    assert len(header) == HEADER_SIZE, f"Header is {len(header)} bytes, expected {HEADER_SIZE}"

    # Assemble
    out = bytearray()
    out.extend(header)
    out.extend(sec_dir)
    out.extend(tensor_data)
    out.extend(op_data)
    out.extend(stage_data_final)
    out.extend(tile_data)
    out.extend(index_data)
    out.extend(shape_data)
    out.extend(string_data)
    if has_weights:
        out.extend(weight_data)

    assert len(out) == file_size, f"Output is {len(out)} bytes, expected {file_size}"
    return bytes(out)
