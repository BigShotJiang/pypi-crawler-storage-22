"""Graph IR — core data structures for the TiGrIS execution plan."""
