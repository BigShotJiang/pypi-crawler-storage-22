"""ONNX-specific normalizations for deployment.

Five transformations applied in sequence:

1. **BN fold**: For each Conv→BatchNormalization pattern, fold the BN
   parameters (gamma, beta, mean, var, epsilon) into the convolution
   weights and bias, then remove the BN op and rewire outputs.

2. **DepthwiseConv relabeling**: Convolutions where ``group == C_in``
   (i.e., depthwise) are relabeled from ``Conv`` to ``DepthwiseConv``
   so the runtime can dispatch a specialised kernel.

3. **Conv1D relabeling**: Conv ops with ``len(kernel_shape) == 1`` are
   relabeled from ``Conv`` to ``Conv1D`` for dedicated 1D kernel dispatch.

4. **Clip(0, 6) → Relu6**: Replace ``Clip`` ops whose min/max are 0/6
   with the simpler ``Relu6`` op type.

5. **Shape op folding**: Remove chains of shape-computation ops
   (Constant, Shape, Gather, Unsqueeze, Concat) that feed Reshape's
   shape input.  All shapes are static at compile time.
"""

import numpy as np

from tigris.graph.ir import AnalyzedGraph, OpNode, TensorInfo


def normalize(ag: AnalyzedGraph) -> AnalyzedGraph:
    """Apply BN folding, DepthwiseConv relabeling, Conv1D relabeling, Clip→Relu6, and shape op folding."""
    ag = _fold_bn(ag)
    ag = _relabel_depthwise(ag)
    ag = _relabel_conv1d(ag)
    ag = _clip_to_relu6(ag)
    ag = _fold_shape_ops(ag)
    return ag


# ── BN fold ──────────────────────────────────────────────────────────


def _fold_bn(ag: AnalyzedGraph) -> AnalyzedGraph:
    """Fold Conv → BatchNormalization into a single Conv with updated weights."""
    # Build output→op index map
    output_to_op: dict[str, int] = {}
    for i, op in enumerate(ag.ops):
        for out in op.outputs:
            output_to_op[out] = i

    # Build input consumer map: tensor_name → list of op indices
    input_to_consumers: dict[str, list[int]] = {}
    for i, op in enumerate(ag.ops):
        for inp in op.inputs:
            input_to_consumers.setdefault(inp, []).append(i)

    removed: set[int] = set()

    for i, op in enumerate(ag.ops):
        if op.op_type != "BatchNormalization":
            continue

        # BN inputs: X, scale(gamma), B(beta), mean, var
        if len(op.inputs) < 5:
            continue

        bn_input = op.inputs[0]
        if bn_input not in output_to_op:
            continue

        conv_idx = output_to_op[bn_input]
        conv_op = ag.ops[conv_idx]

        if conv_op.op_type not in ("Conv",):
            continue

        # Conv must have exactly one consumer (the BN)
        consumers = input_to_consumers.get(bn_input, [])
        if len(consumers) != 1:
            continue

        # Get BN parameters from weight_data
        gamma_name = op.inputs[1]
        beta_name = op.inputs[2]
        mean_name = op.inputs[3]
        var_name = op.inputs[4]

        if not all(n in ag.weight_data for n in [gamma_name, beta_name, mean_name, var_name]):
            continue

        gamma = ag.weight_data[gamma_name]
        beta = ag.weight_data[beta_name]
        mean = ag.weight_data[mean_name]
        var = ag.weight_data[var_name]
        eps = op.attrs.get("epsilon", 1e-5)

        # Conv weight: inputs[1]
        if len(conv_op.inputs) < 2 or conv_op.inputs[1] not in ag.weight_data:
            continue
        conv_w_name = conv_op.inputs[1]
        W = ag.weight_data[conv_w_name].copy()

        # Conv bias: inputs[2] (optional)
        has_bias = len(conv_op.inputs) >= 3 and conv_op.inputs[2] in ag.weight_data
        if has_bias:
            conv_b_name = conv_op.inputs[2]
            B = ag.weight_data[conv_b_name].copy()
        else:
            B = np.zeros(W.shape[0], dtype=np.float32)

        # Fold: scale = gamma / sqrt(var + eps)
        inv_std = 1.0 / np.sqrt(var + eps)
        scale = gamma * inv_std

        # W_new[oc] = W[oc] * scale[oc]  (broadcast over spatial dims)
        # For NCHW layout, W shape is [OC, IC/G, KH, KW]
        scale_shape = [len(scale)] + [1] * (W.ndim - 1)
        W_new = W * scale.reshape(scale_shape)
        B_new = (B - mean) * inv_std * gamma + beta

        # Update weight_data
        ag.weight_data[conv_w_name] = W_new.astype(np.float32)

        if has_bias:
            ag.weight_data[conv_b_name] = B_new.astype(np.float32)
        else:
            # Create a new bias tensor
            bias_name = conv_w_name.replace("weight", "bias")
            if bias_name == conv_w_name:
                bias_name = conv_w_name + "_bias"
            ag.weight_data[bias_name] = B_new.astype(np.float32)
            ag.tensors[bias_name] = TensorInfo(
                name=bias_name,
                shape=B_new.shape,
                dtype=1,  # FLOAT
                is_constant=True,
            )
            conv_op.inputs = list(conv_op.inputs[:2]) + [bias_name] + list(conv_op.inputs[3:])

        # Rewire: conv's output becomes the BN's output
        bn_output = op.outputs[0]
        conv_op.outputs = [bn_output]

        # Remove the intermediate tensor
        if bn_input in ag.tensors and not ag.tensors[bn_input].is_constant:
            del ag.tensors[bn_input]

        # Clean up BN weight tensors from weight_data (no longer needed)
        for wname in [gamma_name, beta_name, mean_name, var_name]:
            if wname in ag.weight_data:
                del ag.weight_data[wname]
            if wname in ag.tensors:
                del ag.tensors[wname]

        removed.add(i)

    if removed:
        ag.ops = [op for i, op in enumerate(ag.ops) if i not in removed]
        # Re-assign step indices
        for step, op in enumerate(ag.ops):
            op.step = step

    return ag


# ── DepthwiseConv relabeling ─────────────────────────────────────────


def _relabel_depthwise(ag: AnalyzedGraph) -> AnalyzedGraph:
    """Relabel Conv ops with group == C_in as DepthwiseConv."""
    for op in ag.ops:
        if op.op_type != "Conv":
            continue
        group = op.attrs.get("group", 1)
        if group <= 1:
            continue
        # For depthwise: group == C_in. Check via weight shape.
        w_name = op.inputs[1] if len(op.inputs) >= 2 else None
        if w_name and w_name in ag.weight_data:
            W = ag.weight_data[w_name]
            # Standard Conv weight: [OC, IC/G, KH, KW]
            # Depthwise: group == OC and IC/G == 1
            if W.ndim >= 2 and W.shape[1] == 1 and group == W.shape[0]:
                op.op_type = "DepthwiseConv"
        elif group > 1:
            # No weight data but group > 1 — check tensor info
            if w_name and w_name in ag.tensors:
                w_info = ag.tensors[w_name]
                if len(w_info.shape) >= 2 and w_info.shape[1] == 1 and group == w_info.shape[0]:
                    op.op_type = "DepthwiseConv"

    return ag


# ── Conv1D relabeling ───────────────────────────────────────────────


def _relabel_conv1d(ag: AnalyzedGraph) -> AnalyzedGraph:
    """Relabel Conv ops with 1D kernel_shape as Conv1D.

    Must run after BN fold (which only matches Conv→BN, not Conv1D→BN)
    and after depthwise relabeling (which already changed group==C_in convs).
    """
    for op in ag.ops:
        if op.op_type != "Conv":
            continue
        ks = op.attrs.get("kernel_shape", [])
        if len(ks) == 1:
            op.op_type = "Conv1D"

    return ag


# ── Clip(0, 6) → Relu6 ──────────────────────────────────────────────


def _clip_to_relu6(ag: AnalyzedGraph) -> AnalyzedGraph:
    """Replace Clip(min=0, max=6) with Relu6."""
    for op in ag.ops:
        if op.op_type != "Clip":
            continue

        min_val = None
        max_val = None

        # Clip can have min/max as attributes (opset < 11) or inputs (opset >= 11)
        if "min" in op.attrs:
            min_val = op.attrs["min"]
        if "max" in op.attrs:
            max_val = op.attrs["max"]

        # Check inputs: Clip(input, min, max) — opset >= 11
        if min_val is None and len(op.inputs) >= 2 and op.inputs[1] in ag.weight_data:
            arr = ag.weight_data[op.inputs[1]]
            if arr.size == 1:
                min_val = float(arr.flat[0])
        if max_val is None and len(op.inputs) >= 3 and op.inputs[2] in ag.weight_data:
            arr = ag.weight_data[op.inputs[2]]
            if arr.size == 1:
                max_val = float(arr.flat[0])

        if min_val is not None and max_val is not None:
            if abs(min_val) < 1e-6 and abs(max_val - 6.0) < 1e-6:
                op.op_type = "Relu6"
                # Keep only the data input, drop min/max constant inputs
                op.inputs = [op.inputs[0]]
                op.attrs = {}

    return ag


# ── Shape op folding ─────────────────────────────────────────────────

_SHAPE_OP_TYPES = frozenset({"Shape", "Gather", "Constant", "Unsqueeze", "Concat"})


def _fold_shape_ops(ag: AnalyzedGraph) -> AnalyzedGraph:
    """Remove shape-computation op chains that feed Reshape's shape input.

    In models like MobileNetV2, a chain of Constant→Shape→Gather→Unsqueeze→
    Concat computes the target shape for Reshape at runtime.  Since all shapes
    are static at compile time, these ops can be removed.  The intermediate
    tensors are marked ``is_constant=True`` so the binary emitter skips them.
    """
    # Build output→op index map
    output_to_op: dict[str, int] = {}
    for i, op in enumerate(ag.ops):
        for out in op.outputs:
            output_to_op[out] = i

    removed: set[int] = set()

    for i, op in enumerate(ag.ops):
        if op.op_type != "Reshape":
            continue
        if len(op.inputs) < 2:
            continue

        # Reshape's second input is the target shape tensor
        shape_tensor = op.inputs[1]

        # BFS backward to collect all producer ops
        visited_ops: set[int] = set()
        queue = [shape_tensor]
        seen_tensors: set[str] = set()
        all_shape_ops = True

        while queue:
            tname = queue.pop()
            if tname in seen_tensors:
                continue
            seen_tensors.add(tname)

            if tname not in output_to_op:
                continue  # model input or initializer — not an op output

            prod_idx = output_to_op[tname]
            if prod_idx in visited_ops:
                continue
            visited_ops.add(prod_idx)

            prod_op = ag.ops[prod_idx]
            if prod_op.op_type not in _SHAPE_OP_TYPES:
                all_shape_ops = False
                break

            # Shape and Constant ops don't need to follow inputs:
            # Shape reads shape metadata (not data), Constant has none.
            if prod_op.op_type in ("Shape", "Constant"):
                continue

            # Continue BFS through this op's inputs
            for inp in prod_op.inputs:
                queue.append(inp)

        if all_shape_ops and visited_ops:
            removed |= visited_ops
            # Mark all intermediate tensors as constant
            for tname in seen_tensors:
                if tname in ag.tensors:
                    ag.tensors[tname].is_constant = True

    if removed:
        ag.ops = [op for i, op in enumerate(ag.ops) if i not in removed]
        for step, op in enumerate(ag.ops):
            op.step = step

    # Fix Reshape output shapes that ONNX shape inference couldn't resolve
    _fix_reshape_shapes(ag)

    return ag


def _fix_reshape_shapes(ag: AnalyzedGraph) -> None:
    """Compute correct output shapes for Reshape ops with unknown outputs.

    ONNX shape inference often can't resolve Reshape output shapes when the
    target shape comes from a dynamic computation chain (Shape→Gather→Concat).
    After folding those chains, we can compute the shape statically from the
    data input shape.
    """
    for op in ag.ops:
        if op.op_type != "Reshape":
            continue
        if len(op.inputs) < 2 or len(op.outputs) < 1:
            continue

        out_name = op.outputs[0]
        out_info = ag.tensors.get(out_name)
        if out_info is None or out_info.shape:
            continue  # shape already known

        data_name = op.inputs[0]
        data_info = ag.tensors.get(data_name)
        if data_info is None or not data_info.shape:
            continue

        # Try to get target shape from weight_data (constant initializer)
        shape_name = op.inputs[1]
        if shape_name in ag.weight_data:
            target = ag.weight_data[shape_name].flatten().tolist()
        else:
            # Infer from data input: flatten to [batch, -1]
            target = [data_info.shape[0], -1]

        # Resolve -1 dimension
        total = 1
        for d in data_info.shape:
            total *= d
        neg_idx = None
        known_product = 1
        resolved = []
        for i, d in enumerate(target):
            d = int(d)
            if d == -1:
                neg_idx = i
                resolved.append(-1)
            elif d == 0:
                # 0 means "copy from input"
                resolved.append(data_info.shape[i] if i < len(data_info.shape) else 1)
                known_product *= resolved[-1]
            else:
                resolved.append(d)
                known_product *= d

        if neg_idx is not None:
            resolved[neg_idx] = total // known_product

        out_info.shape = tuple(resolved)
