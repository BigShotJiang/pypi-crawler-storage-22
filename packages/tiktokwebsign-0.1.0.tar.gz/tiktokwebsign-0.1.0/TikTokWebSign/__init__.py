from .TikTokWebSign import TikTokWebSign, xgnarly, xbogus

__version__ = '1.0.0'
__author__ = 'KED'
__all__ = ['TikTokWebSign', 'xgnarly', 'xbogus']

print("\033[92m[*] For More -> https://github.com/keddn\033[0m")