"""EduBridge tests."""
