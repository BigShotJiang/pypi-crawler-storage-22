"""Server adapters."""

from .fastapi import to_fastapi_router

__all__ = ["to_fastapi_router"]
