"""
Integrations 模組 - 外部服務整合
"""

from .google_chat import ChatManager

__all__ = ["ChatManager"]
