"""
Google Chat 整合模組
"""

from .chat_manager import ChatManager

__all__ = ["ChatManager"]
