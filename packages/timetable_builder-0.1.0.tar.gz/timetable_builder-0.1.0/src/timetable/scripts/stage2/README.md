# Stage 2 Scripts

This directory contains modular scripts for generating Stage 2 data from Stage 1 inputs.

## Overview

Stage 2 enriches the basic Stage 1 data with:
- Expanded component details from credit patterns
- Faculty workload calculations (in whole hours)
- Comprehensive assignment with sections and student groups
- Proper handling of elective student groups (AD and SS categories)

**Key Features:**
- Hours are calculated as **whole numbers** using ceiling function on total minutes
- Elective subjects properly map to student groups:
  - **AD electives** (24MCAAD1/4/5): 2 separate groups (ELEC_AD_A1, ELEC_AD_B1) - teaches twice
  - **SS electives** (24MCASS2/3/5): 1 mixed group (ELEC_SS_G1) - teaches once
- Workload correctly accounts for multiple student groups
- Reports include both sections and student group information

## Scripts

### Core Modules

#### `data_loader.py`
**Purpose**: Load all Stage 1 JSON files  
**Usage**: Import as module or run for testing
```bash
python3 data_loader.py
```

#### `expand_components.py`
**Purpose**: Expand credit patterns into detailed component objects  
**Key Logic**: Converts `[T, Tu, P]` credit pattern into component objects with session durations, weekly hours, room requirements  
**Usage**: Import as module or run for testing
```bash
python3 expand_components.py
```

#### `calculate_workload.py`
**Purpose**: Calculate faculty workload statistics  
**Key Logic**: 
- Parses faculty assignments from Stage 1 format
- Converts minutes to whole hours using `math.ceil()`
- Handles elective student groups from `electiveStudentGroups`
- Properly counts workload for multiple student groups
- Uses `max(num_sections, num_student_groups)` for correct multiplier

**Usage**: Import as module or run for testing
```bash
python3 calculate_workload.py
```

**Important Implementation Details:**
- For regular subjects: Uses `sections` list to determine workload multiplier
- For elective subjects: Uses `studentGroupIds` list to determine workload multiplier
- Extracts sections from `electiveStudentGroups[].sections` field
- Hours calculation: `math.ceil(total_minutes / 60)` ensures whole numbers

### Build Scripts

#### `build_subjects_full.py`
**Purpose**: Generate `subjects2Full.json`  
**Input**: Stage 1 subject files  
**Output**: 
- `subjects2Full.json` - All subjects with expanded components
- `subjects_build_report.txt` - Human-readable report

**Usage**:
```bash
python3 build_subjects_full.py
```

**What it does**:
1. Loads all Stage 1 subjects (core, elective, diff)
2. Expands credit patterns into component objects
3. Enriches manually-defined components (diff subjects)
4. Validates all components
5. Saves output and generates report

#### `build_faculty_full.py`
**Purpose**: Generate `faculty2Full.json`  
**Input**: 
- Stage 1 facultyBasic.json
- Stage 2 subjects2Full.json

**Output**: 
- `faculty2Full.json` - Faculty with assignments and workload
- `faculty_build_report.txt` - Human-readable report

**Usage**:
```bash
python3 build_faculty_full.py
```

**What it does**:
1. Loads faculty from Stage 1
2. Loads subjects from Stage 2
3. Parses assigned subjects into structured assignments
4. Calculates workload statistics
5. Adds supporting assignments
6. Saves output and generates report

### Validation

#### `validate_stage2.py`
**Purpose**: Validate generated Stage 2 data  
**Checks**:
- Required fields present
- No duplicate IDs
- Subject references valid
- Component calculations correct
- Workload sums accurate

**Usage**:
```bash
python3 validate_stage2.py
```

Returns exit code 0 if valid, 1 if errors found.

### Master Build Script

#### `build_all.py`
**Purpose**: Run complete Stage 2 build pipeline  
**Usage**:
```bash
# Full build and validation
python3 build_all.py

# Only validate existing data
python3 build_all.py --validate-only

# Build without validation
python3 build_all.py --skip-validation
```

**Pipeline**:
1. Build subjects2Full.json
2. Build faculty2Full.json
3. Validate all data
4. Generate summary

## Workflow

### First-time Setup
```bash
cd stage_2/scripts
python3 build_all.py
```

### After Stage 1 Changes
If you modify Stage 1 data, rebuild Stage 2:
```bash
python3 build_all.py
```

### Just Validation
To check existing Stage 2 data without rebuilding:
```bash
python3 build_all.py --validate-only
```

### Rebuild Specific Files
To rebuild only subjects:
```bash
python3 build_subjects_full.py
```

To rebuild only faculty:
```bash
python3 build_faculty_full.py
```

## Output Files

Generated in parent directory (`stage_2/`):

| File | Description |
|------|-------------|
| `subjects2Full.json` | All subjects with expanded components |
| `faculty2Full.json` | All faculty with assignments and workload |
| `subjects_build_report.txt` | Human-readable subjects summary |
| `faculty_build_report.txt` | Human-readable faculty summary |

## Data Flow

```
Stage 1                       Stage 2 Scripts                 Stage 2 Output
--------                      ---------------                 --------------
config.json          ─────►   data_loader.py
                              expand_components.py
subjects*Basic.json  ─────►   build_subjects_full.py  ─────► subjects2Full.json
                                                              subjects_build_report.txt

facultyBasic.json    ─────►   calculate_workload.py
studentGroups.json   ─────►   build_faculty_full.py   ─────► faculty2Full.json
subjects2Full.json   ────┘                                    faculty_build_report.txt

                              validate_stage2.py      ─────► Validation report
```

## Key Design Principles

1. **Modular**: Each script has single responsibility
2. **Testable**: All modules can be run independently
3. **Reusable**: Core logic in modules, build scripts import them
4. **Validated**: Validation at each step
5. **Transparent**: Reports generated for human review

## Troubleshooting

### "subjects2Full.json not found"
Run `build_subjects_full.py` before `build_faculty_full.py`

### Validation Errors
Check the validation report for specific issues. Common problems:
- Missing fields in Stage 1 data
- Calculation mismatches
- Invalid references

### Component Expansion Issues
Test the expansion logic:
```bash
python3 expand_components.py
```

### Workload Calculation Issues
Test the calculator:
```bash
python3 calculate_workload.py
```

## Development

### Adding New Validations
Edit `validate_stage2.py` and add checks to appropriate methods.

### Changing Component Logic
Edit `expand_components.py`, specifically the `_create_component` method.

### Modifying Workload Calculation
Edit `calculate_workload.py`, specifically the `calculate_workload_stats` method.

## Notes

- All scripts use UTF-8 encoding for international characters
- JSON files are formatted with 2-space indentation
- **Hours are whole integers** (not decimals) - calculated using `math.ceil()`
- Exit code 0 = success, 1 = error

## Elective Subject Handling

Stage 2 properly handles two types of elective configurations:

### Advanced Development (AD) Electives
- **Subjects**: 24MCAAD1, 24MCAAD4, 24MCAAD5
- **Student Groups**: 2 separate groups
  - `ELEC_AD_A1` (Section A only)
  - `ELEC_AD_B1` (Section B only)
- **Teaching Pattern**: Faculty teaches **separately to each section**
- **Workload Calculation**: `hours_per_section × 2 groups`
- **Example**: 24MCAAD5 = 6h/group × 2 groups = **12h total**

### Systems & Security (SS) Electives
- **Subjects**: 24MCASS2, 24MCASS3, 24MCASS5
- **Student Groups**: 1 mixed group
  - `ELEC_SS_G1` (Both sections A and B together)
- **Teaching Pattern**: Faculty teaches **once to combined group**
- **Workload Calculation**: `hours_per_section × 1 group`
- **Example**: 24MCASS5 = 4h/group × 1 group = **4h total**

### Configuration in Stage 1
The `studentGroups.json` file includes:
```json
"electiveStudentGroups": [
  {
    "studentGroupId": "ELEC_AD_A1",
    "parentGroupId": "ELEC_CAT_AD",
    "sections": ["A"],  // Section A only
    ...
  },
  {
    "studentGroupId": "ELEC_SS_G1",
    "parentGroupId": "ELEC_CAT_SS",
    "sections": ["A", "B"],  // Both sections together
    ...
  }
]
```

The scripts automatically:
1. Look up the subject in `electiveSubjectGroups` to find parent category
2. Find matching groups in `electiveStudentGroups` by `parentGroupId`
3. Extract sections from each group's `sections` field
4. Calculate workload based on number of groups
