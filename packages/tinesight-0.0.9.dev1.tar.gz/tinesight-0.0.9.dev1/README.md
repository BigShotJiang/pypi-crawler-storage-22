# Tinesight SDK

Standalone python package for Tinesight SDK, published in the Python package `tinesight`.

Check out [SDK Documentation](http://devsdk.tinesight.com)
