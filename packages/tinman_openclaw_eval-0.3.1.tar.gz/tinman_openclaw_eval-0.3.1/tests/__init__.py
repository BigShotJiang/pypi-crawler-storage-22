"""Tests for tinman-openclaw-eval."""
