
__name__ = 'tinybird_cli'
__description__ = 'Tinybird Command Line Tool'
__url__ = 'https://www.tinybird.co/docs/cli'
__author__ = 'Tinybird'
__author_email__ = 'support@tinybird.co'
__version__ = '6.1.0'
__revision__ = 'cdfa249'
