BASE_URL = 'https://api.search.brave.com/res/v1/'

MAX_QUERY_LENGTH = 400
MAX_QUERY_TERMS = 50

DEFAULT_MAX_RETRIES = 3
DEFAULT_TIMEOUT = 20  # seconds
