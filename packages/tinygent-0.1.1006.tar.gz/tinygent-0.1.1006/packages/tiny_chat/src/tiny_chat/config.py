import os

VERSION = '1.0.0'

BACKEND_ROOT = os.path.dirname(__file__)
PACKAGE_ROOT = os.path.dirname(BACKEND_ROOT)
