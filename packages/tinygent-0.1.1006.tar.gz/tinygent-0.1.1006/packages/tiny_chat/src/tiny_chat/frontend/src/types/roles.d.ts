declare type Role = 'user' | 'agent'
