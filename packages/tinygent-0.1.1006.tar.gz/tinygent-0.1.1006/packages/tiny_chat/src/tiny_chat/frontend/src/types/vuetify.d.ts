declare module 'vuetify/components'
declare module 'vuetify/directives'
