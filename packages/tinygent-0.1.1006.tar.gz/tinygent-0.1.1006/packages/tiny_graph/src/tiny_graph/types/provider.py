from enum import Enum


class GraphProvider(Enum):
    NEO4J = 'neo4j'
