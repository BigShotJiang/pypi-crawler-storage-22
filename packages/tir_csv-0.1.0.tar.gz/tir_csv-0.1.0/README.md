# tir-csv

CSV/TSV <-> TIR converter backend for tirenvi.

## Install

```bash
pip install tir-csv
```

## Usage

tir-csv parse file.csv
