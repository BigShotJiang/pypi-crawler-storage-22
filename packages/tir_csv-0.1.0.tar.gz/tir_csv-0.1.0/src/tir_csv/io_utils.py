from contextlib import contextmanager
from typing import cast, Optional, TextIO, Iterator, ContextManager
import sys
import io


def _stream(
    path: Optional[str],
    *,
    mode: str,
    stdio,
    newline: Optional[str],
) -> ContextManager[TextIO]:
    @contextmanager
    def cm() -> Iterator[TextIO]:
        if path is None or path == "-":
            yield io.TextIOWrapper(
                stdio.buffer,
                encoding="utf-8",
                newline=newline,
            )
        else:
            with open(path, mode, encoding="utf-8", newline=newline) as f:
                yield cast(TextIO, f)

    return cm()


@contextmanager
def input_stream(path: Optional[str]) -> Iterator[TextIO]:
    with _stream(path, mode="r", stdio=sys.stdin, newline=None) as f:
        yield f


@contextmanager
def output_stream(path: Optional[str]) -> Iterator[TextIO]:
    with _stream(path, mode="w", stdio=sys.stdout, newline=None) as f:
        yield f


@contextmanager
def input_stream_csv(path: Optional[str]) -> Iterator[TextIO]:
    with _stream(path, mode="r", stdio=sys.stdin, newline="") as f:
        yield f


@contextmanager
def output_stream_csv(path: Optional[str]) -> Iterator[TextIO]:
    with _stream(path, mode="w", stdio=sys.stdout, newline="") as f:
        yield f
