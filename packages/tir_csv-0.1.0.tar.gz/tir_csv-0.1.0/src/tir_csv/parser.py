#!/usr/bin/env python3

import csv
import json
import sys
import os
from typing import Optional
from tir_csv.io_utils import input_stream_csv, output_stream_csv

__version__ = "0.1.0"
FORMAT_VERSION = "tir/0.1"

# ------------------------------------------------------------
# parse : CSV -> TIR (NDJSON)
# ------------------------------------------------------------


def parse(input_file_path: Optional[str], delimiter: str = ",") -> None:
    with input_stream_csv(input_file_path) as input_stream:
        if input_file_path is None or input_file_path == "-":
            absolute_path = None
        else:
            absolute_path = os.path.abspath(input_file_path)
        file_attr_record = {
            "kind": "file_attr",
            "version": FORMAT_VERSION,
            "file_path": absolute_path,
        }
        print(json.dumps(file_attr_record, ensure_ascii=False))
        csv_reader = csv.reader(input_stream, delimiter=delimiter)
        for row in csv_reader:
            grid_record = {
                "kind": "grid",
                "row": [
                    normalize_cell(cell) if cell is not None else "" for cell in row
                ],
            }
            print(json.dumps(grid_record, ensure_ascii=False))


# ------------------------------------------------------------
# unparse : TIR (NDJSON) -> CSV
# ------------------------------------------------------------


def unparse(output_file_path: Optional[str], delimiter: str = ",") -> None:
    with output_stream_csv(output_file_path) as output_stream:
        csv_writer = csv.writer(output_stream, delimiter=delimiter)
        for line in sys.stdin:
            if not line.strip():
                continue
            record = json.loads(line)
            record_kind = record.get("kind")
            if record_kind in ("file_attr", "block_start"):
                continue
            if record_kind == "plain":
                cell_value = record.get("line", "")
                csv_writer.writerow([cell_value])
            elif record_kind == "grid":
                row = record.get("row", [])
                csv_writer.writerow(row)


# ------------------------------------------------------------
# utilities
# ------------------------------------------------------------


def normalize_cell(cell: str) -> str:
    return cell.replace("\r\n", "\n").replace("\r", "\n")


def usage() -> None:
    print(
        f"""tir-csv {__version__}

usage:
  tir-csv parse   [--delimiter DELIM] [file|-]
  tir-csv unparse [--delimiter DELIM] [file|-]
  tir-csv --version

Options:
  --delimiter DELIM   Field delimiter (default: ',')
                      Use '\\t' for TSV.

If file is omitted or '-', parse reads from stdin.
If file is omitted or '-', unparse writes to stdout.
""",
        file=sys.stderr,
    )


def parse_args(argv):
    delimiter = ","
    remaining_args = []

    argument_iterator = iter(argv)

    for argument in argument_iterator:
        if argument == "--delimiter":
            try:
                delimiter = next(argument_iterator)
            except StopIteration:
                raise ValueError("--delimiter requires an argument")

            if delimiter == r"\t":
                delimiter = "\t"
        else:
            remaining_args.append(argument)

    return delimiter, remaining_args


# ------------------------------------------------------------
# pip entry point
# ------------------------------------------------------------


def run(argv) -> int:
    try:
        delimiter, args = parse_args(argv)
    except Exception as error:
        print(str(error), file=sys.stderr)
        usage()
        return 1

    if not args:
        usage()
        return 1

    if args[0] == "--version":
        print(__version__)
        return 0

    if len(args) not in (1, 2):
        usage()
        return 1

    command = args[0]
    file_argument = args[1] if len(args) == 2 else None

    try:
        if command == "parse":
            parse(file_argument, delimiter=delimiter)
        elif command == "unparse":
            unparse(file_argument, delimiter=delimiter)
        else:
            print(f"unknown sub command: {command}", file=sys.stderr)
            usage()
            return 1

    except Exception as error:
        print(str(error), file=sys.stderr)
        return 1

    return 0
