import re
from typing import Dict, Any
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

class Tirikchilik:
    def __init__(self, project_name: str):
        self.base_url = 'https://api.tirikchilik.uz/api/ProjectPay'
        self.user_url = 'https://api.tirikchilik.uz/api/User'
        self.session = self._create_session()
        self.project_id = self._get_project_by_name(project_name)

    def _create_session(self):
        session = requests.Session()
        retries = Retry(total=3, backoff_factor=0.1, status_forcelist=[500, 502, 503, 504])
        adapter = HTTPAdapter(max_retries=retries, pool_connections=10, pool_maxsize=10)
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        return session

    def _make_request(self, method: str, url: str, payload: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Make HTTP request and handle response
        """
        try:
            kwargs = {
                'timeout': (3.05, 10),  # (connect timeout, read timeout)
                'headers': {'Content-Type': 'application/json'}
            }

            if method.lower() == 'post':
                response = self.session.post(url, json=payload, **kwargs)
            elif method.lower() == 'get':
                response = self.session.get(url, **kwargs)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")

            response.raise_for_status()
            data = response.json()

            if data.get('success'):
                return data
            else:
                self._handle_error(data.get('error', {}))

        except requests.RequestException as e:
            raise PaymentError(f"Request failed: {str(e)}")

    def _handle_error(self, error: Dict[str, Any]):
        """
        Handle API errors
        """
        code = error.get('code')
        message = error.get('message', {}).get('en', 'Unknown error')
        description = error.get('description', '')
        if code == "ERROR_NOT_FOUND":
            raise PaymentNotFoundError(message, code, description)
        else:
            raise PaymentError(message, code, description)

    def _get_project_by_name(self, name: str) -> int:
        """
        Get project ID by name
        """
        url = f'{self.user_url}/GetByName?userName={name}'
        response = self._make_request('get', url)

        if response['success'] and response['data']:
            return response['data']['donateId']
        else:
            raise UserNotFoundError(f"User '{name}' not found")

    def create_payment(self, amount: int, donater: str, notes: str, return_url: str = None) -> Dict[str, Any]:
        """
        Create payment via Click payment system
        :param amount: int - amount of payment in tiyin
        :param donater: str - name of donater
        :param notes: str - notes for payment
        :param return_url: str - URL to redirect user after payment (optional)
        :return: dict with payId, checkoutUrl, donateAmount, commissionAmount, totalAmount
        """
        url = f'{self.base_url}/Create'
        payload = {
            "projectId": self.project_id,
            "amount": int(amount),
            "source": "",
            "donater": donater,
            "notes": notes,
            "paymentSystem": "click"
        }

        response = self._make_request('post', url, payload)

        if return_url and response and response.get('data', {}).get('checkoutUrl'):
            checkout_url = response['data']['checkoutUrl']
            response['data']['checkoutUrl'] = re.sub(
                r'return_url=[^&]*',
                f'return_url={requests.utils.quote(return_url, safe="")}',
                checkout_url
            )

        return response

    def get_payment_status(self, payment_id: int) -> Dict[str, Any]:
        """
        Get payment status
        :param payment_id: int - payment id
        :return: dict example: {'data': 'Paid', 'success': True, 'error': None}
        """
        url = f'{self.base_url}/Status?payId={payment_id}'
        return self._make_request('get', url)


class PaymentError(Exception):
    def __init__(self, message: str, code: str = None, description: str = None):
        self.code = code
        self.message = message
        self.description = description
        super().__init__(f"PaymentError. Code: {self.code}. Message: {self.message}. Description: {self.description}")


class PaymentNotFoundError(PaymentError):
    pass

class UserNotFoundError(PaymentError):
    pass