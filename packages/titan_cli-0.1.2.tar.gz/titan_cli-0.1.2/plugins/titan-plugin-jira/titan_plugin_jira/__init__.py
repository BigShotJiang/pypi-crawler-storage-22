# plugins/titan-plugin-jira/titan_plugin_jira/__init__.py
"""
Titan Plugin: JIRA

AI-powered JIRA integration plugin for Titan CLI.
"""

__version__ = "1.0.0"
