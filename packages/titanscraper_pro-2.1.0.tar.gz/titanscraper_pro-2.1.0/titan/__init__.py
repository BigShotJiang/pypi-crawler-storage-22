"""
TitanScraper - Advanced Anti-Detection Web Scaping Library
"""
from .core.scraper import TitanScraper

__version__ = "1.0.0"
