"""titiler-pgstac logger."""

import logging

logger = logging.getLogger("titiler-pgstac")
