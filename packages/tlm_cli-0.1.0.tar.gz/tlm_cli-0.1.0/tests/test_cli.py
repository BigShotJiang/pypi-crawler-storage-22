"""
Tests for TLM CLI — auth --url, signup, and auto-project-creation.
"""

import json
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from tlm.cli import cmd_auth, cmd_signup, main, _get_backend
from tlm.engine import Project


# ─── Fixtures ─────────────────────────────────────────────────

@pytest.fixture
def credentials_dir(tmp_path):
    """Temporary directory for credentials."""
    cred_dir = tmp_path / ".tlm"
    cred_dir.mkdir()
    return str(cred_dir)


@pytest.fixture
def cred_file(credentials_dir):
    """Path to the credentials.json in tmp dir."""
    return Path(credentials_dir) / "credentials.json"


# ─── cmd_auth Tests ─────────────────────────────────────────

class TestCmdAuth:
    @patch("tlm.cli.save_credentials")
    def test_auth_saves_key(self, mock_save):
        """tlm auth <key> saves the API key."""
        cmd_auth("tlm_sk_test123")
        mock_save.assert_called_once_with("tlm_sk_test123", base_url=None)

    @patch("tlm.cli.save_credentials")
    def test_auth_with_url_saves_both(self, mock_save):
        """tlm auth <key> --url <url> saves both key and URL."""
        cmd_auth("tlm_sk_test123", base_url="http://localhost:8000")
        mock_save.assert_called_once_with("tlm_sk_test123", base_url="http://localhost:8000")

    def test_auth_rejects_invalid_key(self):
        """tlm auth rejects keys not starting with tlm_sk_."""
        with pytest.raises(SystemExit):
            cmd_auth("bad_key_format")

    @patch("tlm.cli.save_credentials")
    def test_auth_url_none_by_default(self, mock_save):
        """When no --url is given, base_url=None is passed (preserves existing)."""
        cmd_auth("tlm_sk_abc")
        _, kwargs = mock_save.call_args
        assert kwargs["base_url"] is None


# ─── cmd_signup Tests ────────────────────────────────────────

class TestCmdSignup:
    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    @patch("builtins.input", side_effect=["test@example.com", "password123"])
    def test_signup_prompts_and_saves(self, mock_input, mock_client_cls, mock_save):
        """tlm signup prompts for email+password, calls API, saves credentials."""
        mock_client = MagicMock()
        mock_client.signup.return_value = {
            "api_key": "tlm_sk_new123",
            "user_id": 1,
            "email": "test@example.com",
        }
        mock_client_cls.return_value = mock_client

        cmd_signup("http://localhost:8000")

        mock_client.signup.assert_called_once_with("test@example.com", "password123")
        mock_save.assert_called_once_with("tlm_sk_new123", base_url="http://localhost:8000")

    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    @patch("builtins.input", side_effect=["user@test.com", "pass"])
    def test_signup_uses_provided_url(self, mock_input, mock_client_cls, mock_save):
        """tlm signup --url uses the provided URL."""
        mock_client = MagicMock()
        mock_client.signup.return_value = {
            "api_key": "tlm_sk_abc",
            "user_id": 1,
            "email": "user@test.com",
        }
        mock_client_cls.return_value = mock_client

        cmd_signup("http://custom-server:9000")

        mock_client_cls.assert_called_once_with(api_key="", base_url="http://custom-server:9000")

    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    @patch("builtins.input", side_effect=["user@test.com", "pass"])
    def test_signup_uses_default_url_when_none(self, mock_input, mock_client_cls, mock_save):
        """tlm signup without --url uses DEFAULT_BASE_URL."""
        from tlm.api_client import DEFAULT_BASE_URL
        mock_client = MagicMock()
        mock_client.signup.return_value = {
            "api_key": "tlm_sk_abc",
            "user_id": 1,
            "email": "user@test.com",
        }
        mock_client_cls.return_value = mock_client

        cmd_signup()

        mock_client_cls.assert_called_once_with(api_key="", base_url=DEFAULT_BASE_URL)
        mock_save.assert_called_once_with("tlm_sk_abc", base_url=DEFAULT_BASE_URL)

    @patch("tlm.cli.TLMClient")
    @patch("builtins.input", side_effect=["user@test.com", "pass"])
    def test_signup_handles_server_error(self, mock_input, mock_client_cls):
        """tlm signup exits on server error."""
        from tlm.api_client import TLMServerError
        mock_client = MagicMock()
        mock_client.signup.side_effect = TLMServerError("Email already registered")
        mock_client_cls.return_value = mock_client

        with pytest.raises(SystemExit):
            cmd_signup("http://localhost:8000")

    @patch("tlm.cli.TLMClient")
    @patch("builtins.input", side_effect=["user@test.com", "pass"])
    def test_signup_handles_connection_error(self, mock_input, mock_client_cls):
        """tlm signup exits on connection error."""
        from tlm.api_client import TLMConnectionError
        mock_client = MagicMock()
        mock_client.signup.side_effect = TLMConnectionError("Connection refused")
        mock_client_cls.return_value = mock_client

        with pytest.raises(SystemExit):
            cmd_signup("http://localhost:8000")


# ─── Main argument parsing Tests ─────────────────────────────

class TestMainArgParsing:
    @patch("tlm.cli.cmd_auth")
    def test_main_auth_with_url(self, mock_auth):
        """main() parses --url flag for auth command."""
        import sys
        with patch.object(sys, 'argv', ['tlm', 'auth', 'tlm_sk_test', '--url', 'http://localhost:8000']):
            main()
        mock_auth.assert_called_once_with("tlm_sk_test", base_url="http://localhost:8000")

    @patch("tlm.cli.cmd_auth")
    def test_main_auth_without_url(self, mock_auth):
        """main() passes None for base_url when no --url."""
        import sys
        with patch.object(sys, 'argv', ['tlm', 'auth', 'tlm_sk_test']):
            main()
        mock_auth.assert_called_once_with("tlm_sk_test", base_url=None)

    @patch("tlm.cli.cmd_signup")
    def test_main_signup_with_url(self, mock_signup):
        """main() parses signup command with --url override."""
        import sys
        with patch.object(sys, 'argv', ['tlm', 'signup', '--url', 'http://localhost:8000']):
            main()
        mock_signup.assert_called_once_with("http://localhost:8000")

    @patch("tlm.cli.cmd_signup")
    def test_main_signup_without_url_uses_default(self, mock_signup):
        """main() calls cmd_signup with no args when --url is omitted."""
        import sys
        with patch.object(sys, 'argv', ['tlm', 'signup']):
            main()
        mock_signup.assert_called_once_with(None)


# ─── _get_backend auto-project-creation Tests ────────────────

class TestGetBackendAutoProject:
    @patch("tlm.cli.get_client")
    def test_creates_project_on_server_when_no_project_id(self, mock_get_client, tmp_path):
        """_get_backend auto-creates project on server when project_id is missing."""
        mock_client = MagicMock()
        mock_client.create_project.return_value = {
            "project_id": 42,
            "name": "my-project",
            "fingerprint": "abc123",
        }
        mock_get_client.return_value = mock_client

        project = Project(str(tmp_path))
        project.init()

        _, client, project_id = _get_backend(project)

        assert project_id == 42
        mock_client.create_project.assert_called_once()

    @patch("tlm.cli.get_client")
    def test_saves_project_id_to_config(self, mock_get_client, tmp_path):
        """Auto-created project_id is saved to .tlm/config.json."""
        mock_client = MagicMock()
        mock_client.create_project.return_value = {
            "project_id": 99,
            "name": "test-proj",
            "fingerprint": "xyz",
        }
        mock_get_client.return_value = mock_client

        project = Project(str(tmp_path))
        project.init()

        _get_backend(project)

        config = json.loads(project.config_file.read_text())
        assert config["project_id"] == 99

    @patch("tlm.cli.get_client")
    def test_reuses_existing_project_id(self, mock_get_client, tmp_path):
        """_get_backend does NOT create project if project_id already exists."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        project = Project(str(tmp_path))
        project.init()
        config = json.loads(project.config_file.read_text())
        config["project_id"] = 77
        project.config_file.write_text(json.dumps(config))

        _, client, project_id = _get_backend(project)

        assert project_id == 77
        mock_client.create_project.assert_not_called()

    @patch("tlm.cli.get_client")
    def test_no_project_skips_creation(self, mock_get_client):
        """_get_backend without a project arg doesn't try to create one."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        _, client, project_id = _get_backend(None)

        assert project_id is None
        mock_client.create_project.assert_not_called()
