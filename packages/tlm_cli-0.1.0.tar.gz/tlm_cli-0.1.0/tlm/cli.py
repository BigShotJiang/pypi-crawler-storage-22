"""
TLM CLI — Your AI Tech Lead + Manager

Getting started:
    tlm signup                        Create account on TLM server
    tlm install                       One-time setup: scan, approve config, install hooks + CLAUDE.md

Commands:
    tlm signup [--url <server_url>]   Create account (--url optional, has default)
    tlm auth <api_key> [--url <url>]  Save API key (and optionally server URL)
    tlm install                       One-time setup: scan, approve config, install hooks + CLAUDE.md
    tlm uninstall                     Remove TLM hooks + rules (keeps .tlm/ data)
    tlm check [spec_path]             Mechanical checks + spec review before commit
    tlm status                        Project stats + enforcement status
    tlm specs                         List generated specs
    tlm learn                         Analyze recent commits, extract lessons
    tlm learn --all                   Full history analysis (archaeological dig)

Workflow:
    1. tlm signup                      (one-time: create account)
    2. cd ~/your-project && tlm install   (per-project: scan, approve, install hooks)
    3. Open Claude Code               (TLM activates automatically on significant work)
    4. Work normally                   (TLM interviews, enforces TDD, checks compliance)
"""

import sys
import os
import stat
import json
import subprocess
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from tlm.engine import (
    Project, Scanner, DiscoveryEngine, ComplianceChecker,
    ConfigGenerator, DriftDetector,
)
from tlm.enforcer import Enforcer
from tlm.api_client import (
    save_credentials, load_credentials, get_client, TLMClient,
    TLMServerError, TLMConnectionError,
)


# ─── Colors ────────────────────────────────────────────────────
C = "\033[36m"    # cyan
P = "\033[35m"    # purple
G = "\033[32m"    # green
Y = "\033[33m"    # yellow
R = "\033[31m"    # red
D = "\033[2m"     # dim
B = "\033[1m"     # bold
X = "\033[0m"     # reset

OVERRIDE_PHRASE = "OVERRIDE"


def logo():
    print(f"""
{C}╔═══════════════════════════════════════════════╗
║  {B}TLM{X}{C} — Tech Lead + Manager                    ║
║  {D}The annoying agent that makes Claude{X}{C}          ║
║  {D}do the right thing.{X}{C}                           ║
╚═══════════════════════════════════════════════╝{X}
""")


def _get_backend(project: Project = None) -> tuple:
    """Get the LLM backend — TLM server API client.

    Returns: (claude, api_client, project_id)
    - Server mode: (None, TLMClient, "project_id")

    Auto-creates project on server if project exists locally but has no project_id.
    """
    client = get_client()
    if client:
        project_id = None
        if project and project.config_file.exists():
            try:
                config = json.loads(project.config_file.read_text())
                project_id = config.get("project_id")
            except (json.JSONDecodeError, OSError):
                config = {}

            if project_id is None:
                # Auto-register this project on the server
                import hashlib
                fingerprint = hashlib.sha256(
                    str(project.root).encode()
                ).hexdigest()[:16]
                result = client.create_project(
                    project.root.name, fingerprint
                )
                project_id = result["project_id"]
                # Save project_id locally
                config["project_id"] = project_id
                project.config_file.write_text(json.dumps(config, indent=2))

        return None, client, project_id

    print(f"{R}✗ Not authenticated.{X}")
    print(f"  Run {C}tlm auth <api_key>{X} to connect to TLM server.")
    print(f"  Get your API key at {C}https://tlm.dev{X}\n")
    sys.exit(1)


def require_auth():
    """Verify the user is authenticated with TLM server."""
    client = get_client()
    if client:
        return
    print(f"{R}✗ Not authenticated.{X}")
    print(f"  Run {C}tlm auth <api_key>{X} to connect to TLM server.\n")
    sys.exit(1)


def require_init(project: Project):
    if not project.initialized:
        print(f"{R}✗ Not a TLM project. Run `tlm init` first.{X}\n")
        sys.exit(1)


def require_approved_config(project: Project):
    if not project.enforcement.approved:
        print(f"{R}✗ No approved enforcement config.{X}")
        print(f"{D}  Run `tlm init` to scan your project and approve enforcement rules.{X}\n")
        sys.exit(1)


# ─── INIT ──────────────────────────────────────────────────────

def cmd_init():
    """Scan project, generate enforcement config, interactive approval."""
    logo()

    project = Project(".")
    project.init()
    claude, api_client, project_id = _get_backend(project)

    # Phase 1: Scan project
    print(f"{C}TLM ▸ Scanning your project...{X}\n")
    scanner = Scanner(project, claude, api_client=api_client, project_id=project_id)
    profile = scanner.scan()

    print(f"{G}✓{X} Project scanned\n")
    print(f"{D}{'─'*60}{X}")
    print(profile)
    print(f"{D}{'─'*60}{X}")

    # Phase 2: Generate enforcement config
    print(f"\n{C}TLM ▸ Generating enforcement rules...{X}\n")
    config_gen = ConfigGenerator(project, claude, api_client=api_client, project_id=project_id)
    config = config_gen.generate()

    # Phase 3: Interactive approval
    _interactive_config_approval(config_gen, config, project)

    # Phase 4: Archaeological dig — learn from existing history
    try:
        result = subprocess.run(
            ["git", "rev-list", "--count", "HEAD"],
            capture_output=True, text=True, cwd=str(project.root), timeout=5,
        )
        if result.returncode == 0:
            commit_count = int(result.stdout.strip())
            if commit_count > 0:
                print(f"\n{C}TLM ▸ This project has {commit_count} commits.{X}")
                print(f"  Want me to analyze your history to learn your project's patterns?")
                print(f"  This makes my interviews much better from day one.\n")
                print(f"  {G}yes{X}  — Analyze all {commit_count} commits")
                print(f"  {D}no{X}   — Start fresh, I'll learn as we go\n")

                try:
                    user_input = input(f"{G}You:{X} ").strip()
                except (KeyboardInterrupt, EOFError):
                    user_input = "no"

                if user_input.lower() in ("yes", "y"):
                    cmd_learn(full_history=True)
    except Exception:
        pass  # No git, no problem


def _interactive_config_approval(config_gen: ConfigGenerator, config: dict, project: Project):
    """Present config to user, let them correct, then approve."""

    while True:
        _display_config(config)

        print(f"\n{B}Does this look right?{X}")
        print(f"  {G}yes{X}    — Approve and save (becomes your enforcement contract)")
        print(f"  {Y}[correction]{X} — Tell me what's wrong and I'll fix it")
        print(f"  {R}quit{X}   — Exit without saving\n")

        try:
            user_input = input(f"{G}You:{X} ").strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n{Y}Exiting without saving config.{X}\n")
            return

        if not user_input:
            continue

        if user_input.lower() in ("yes", "y", "approve", "looks good", "lgtm"):
            config_gen.save_approved(config)
            print(f"\n{G}✓ Enforcement config approved and saved.{X}")
            print(f"  {D}Saved to .tlm/enforcement.json{X}")
            print(f"\n  This is now your enforcement contract.")
            print(f"  Every `tlm check` and `tlm build` will enforce these rules mechanically.")
            print(f"\n{D}Next: {X}{C}tlm build \"your feature description\"{X}\n")
            return

        if user_input.lower() in ("quit", "exit", "q"):
            print(f"\n{Y}Exiting without saving. Run `tlm init` again when ready.{X}\n")
            return

        # User is correcting — send feedback to LLM
        print(f"\n{C}TLM ▸ Updating config...{X}\n")
        try:
            config = config_gen.update_config(config, user_input)
        except Exception as e:
            print(f"{R}Error updating config: {e}{X}")
            print(f"{D}Try again with different wording.{X}\n")
            continue


def _display_config(config: dict):
    """Display the enforcement config in a readable format."""

    print(f"\n{'='*60}")
    print(f"  {B}TLM Enforcement Config{X}")
    print(f"{'='*60}")

    # Summary
    summary = config.get("project_summary", "")
    if summary:
        print(f"\n  {D}{summary}{X}")

    # Environments
    envs = config.get("environments", {})
    print(f"\n  {B}Environments ({len(envs)}):{X}")
    for name, env in envs.items():
        print(f"    {C}{name}{X}: {env.get('description', '')}")
        print(f"      {D}Check: {env.get('check_exists_command', 'none')}{X}")
        print(f"      {D}Deploy: {env.get('deploy_command', 'none')}{X}")
        if env.get('env_file'):
            print(f"      {D}Env file: {env['env_file']}{X}")

    # Checks
    checks = config.get("checks", [])
    print(f"\n  {B}Quality Checks ({len(checks)}):{X}")
    for check in checks:
        blocker_icon = f"{R}●{X}" if check.get("blocker") else f"{Y}○{X}"
        when = check.get("when", "")
        print(f"    {blocker_icon} {check.get('name', '?')} {D}[{when}]{X}")
        print(f"      {D}{check.get('command', 'no command')}{X}")
        if check.get("description"):
            print(f"      {D}{check['description']}{X}")

    # Coverage
    cov = config.get("coverage", {})
    if cov and cov.get("command"):
        print(f"\n  {B}Coverage:{X}")
        print(f"    {D}Command: {cov['command']}{X}")
        print(f"    {D}Min line: {cov.get('min_line_coverage', 50)}% | "
              f"Min branch: {cov.get('min_branch_coverage', 30)}%{X}")

    # Drift files
    drift = config.get("drift_files", [])
    if drift:
        print(f"\n  {B}Drift Detection:{X}")
        print(f"    {D}Watching: {', '.join(drift)}{X}")

    print(f"\n  {D}● = blocker (blocks commit)  ○ = warning{X}")
    print(f"{'='*60}")


# ─── BUILD ─────────────────────────────────────────────────────

def cmd_build(feature_request: str):
    """Discovery → spec → CLAUDE.md, with drift detection and enforcement."""
    logo()

    project = Project(".")
    if not project.initialized:
        print(f"{Y}No .tlm/ found. Run `tlm init` first.{X}\n")
        sys.exit(1)

    claude, api_client, project_id = _get_backend(project)

    # ─── LEARNING SCAN ──────────────────────────
    from tlm.learner import Learner
    learner = Learner(project, claude, api_client=api_client, project_id=project_id)
    commit_count = learner.get_commit_count_since_last_session()

    if commit_count > 0:
        print(f"{C}TLM ▸ Learning from {commit_count} commits since last session...{X}\n")

        def _learn_progress(current, total, hash_str, summary):
            print(f"  {D}[{current}/{total}]{X} {hash_str} — {summary[:60]}")

        synthesis = learner.learn_since_last_session(progress_callback=_learn_progress)

        if synthesis.get("total_commits", 0) > 0:
            accuracy = synthesis.get("spec_accuracy_percent", "?")
            bugs = len(synthesis.get("bug_patterns", []))
            unplanned_n = len(synthesis.get("unplanned_features", []))

            print(f"\n  {B}Learning Summary:{X}")
            print(f"  Spec accuracy: {accuracy}%")
            if bugs:
                print(f"  Bug patterns found: {bugs}")
                for bp in synthesis.get("bug_patterns", []):
                    print(f"    {Y}•{X} {bp.get('pattern', '?')} ({bp.get('frequency', '?')}x)")
            if unplanned_n:
                print(f"  Unplanned features: {unplanned_n}")
                for uf in synthesis.get("unplanned_features", []):
                    print(f"    {Y}•{X} {uf.get('what', '?')}")

            improvements = synthesis.get("interview_improvements", [])
            if improvements:
                print(f"\n  {G}Lessons injected into this interview:{X}")
                for imp in improvements[:5]:
                    print(f"    {C}→{X} {imp[:80]}")

            print()

    # ─── DRIFT DETECTION ─────────────────────────
    if project.enforcement.approved:
        print(f"{C}TLM ▸ Checking for config drift...{X}\n")
        detector = DriftDetector(project, claude, api_client=api_client, project_id=project_id)
        drift = detector.check()

        if drift.get("stale"):
            print(f"{R}{'='*60}{X}")
            print(f"{R}  ✗ ENFORCEMENT CONFIG IS STALE{X}")
            print(f"{R}{'='*60}{X}")
            print(f"\n  Changed files: {', '.join(drift['changed_files'])}")
            print(f"  Reason: {drift.get('reason', 'unknown')}")
            print(f"\n{R}  Your project has changed since you approved the enforcement config.{X}")
            print(f"  Run {C}tlm init{X} to re-scan and re-approve.\n")
            print(f"  {D}Or type {B}{OVERRIDE_PHRASE}{X}{D} to proceed anyway (at your own risk).{X}\n")

            try:
                user_input = input(f"{G}You:{X} ").strip()
            except (KeyboardInterrupt, EOFError):
                print(f"\n{Y}Aborting.{X}\n")
                sys.exit(1)

            if user_input.strip() != OVERRIDE_PHRASE:
                print(f"\n{R}Build blocked. Run `tlm init` to update your config.{X}\n")
                sys.exit(1)
            else:
                print(f"\n{Y}⚠ Override accepted. Proceeding with stale config.{X}\n")

        elif drift.get("drifted"):
            # Files changed but LLM says it's not meaningful
            print(f"  {D}Some files changed but config is still valid.{X}\n")
        else:
            print(f"  {G}✓{X} Config is current.\n")
    else:
        print(f"{R}✗ No approved enforcement config. Run `tlm init` first.{X}")
        print(f"{D}  Or type {B}{OVERRIDE_PHRASE}{X}{D} to proceed without enforcement.{X}\n")

        try:
            user_input = input(f"{G}You:{X} ").strip()
        except (KeyboardInterrupt, EOFError):
            sys.exit(1)

        if user_input.strip() != OVERRIDE_PHRASE:
            sys.exit(1)
        print(f"\n{Y}⚠ Override accepted. No enforcement active.{X}\n")

    # ─── PRE-BUILD ENFORCEMENT ────────────────────
    if project.enforcement.approved:
        print(f"{C}TLM ▸ Pre-build enforcement checks...{X}\n")
        enforcer = Enforcer(".")
        env_report = enforcer.run_environment_checks()

        for check in env_report.checks:
            print(str(check))
            for d in check.details:
                print(f"      {D}{d}{X}")

        if not env_report.passed:
            print(f"\n{R}✗ Environment checks failed.{X}")
            print(f"  Fix environment setup, or type {B}{OVERRIDE_PHRASE}{X} to proceed.\n")

            try:
                user_input = input(f"{G}You:{X} ").strip()
            except (KeyboardInterrupt, EOFError):
                sys.exit(1)

            if user_input.strip() != OVERRIDE_PHRASE:
                sys.exit(1)
            print(f"\n{Y}⚠ Override accepted.{X}\n")
        else:
            print(f"\n{G}✓ Environment checks passed.{X}\n")

        # Run pre_build checks
        build_report = enforcer.run_checks("pre_build")
        if build_report.checks:
            for check in build_report.checks:
                print(str(check))
            if not build_report.passed:
                print(f"\n{R}✗ Pre-build checks failed.{X}")
                print(f"  Fix issues above, or type {B}{OVERRIDE_PHRASE}{X} to proceed.\n")
                try:
                    user_input = input(f"{G}You:{X} ").strip()
                except (KeyboardInterrupt, EOFError):
                    sys.exit(1)
                if user_input.strip() != OVERRIDE_PHRASE:
                    sys.exit(1)
                print(f"\n{Y}⚠ Override accepted.{X}\n")

    # ─── DISCOVERY SESSION ────────────────────────
    config = project.get_config()
    print(f"{D}Sessions used: {config.get('sessions_used', 0)}{X}")

    print(f"\n{'='*60}")
    print(f"  {C}TLM ▸ Discovery Session{X}")
    print(f"  Feature: {B}{feature_request}{X}")
    print(f"{'='*60}\n")

    engine = DiscoveryEngine(project, claude, api_client=api_client, project_id=project_id)
    first_q = engine.start(feature_request)
    print(f"{P}TLM:{X} {first_q}\n")

    question_count = 1
    while True:
        try:
            user_input = input(f"{G}You:{X} ").strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n\n{Y}Session interrupted.{X}")
            if question_count >= 3:
                print(f"{D}Generating spec with what we have...{X}\n")
                _finish_session(engine, project, feature_request)
            sys.exit(0)

        if not user_input:
            continue

        if user_input.lower() in ("done", "/done", "generate", "/generate", "spec"):
            print(f"\n{C}TLM ▸ Generating spec + instructions...{X}\n")
            _finish_session(engine, project, feature_request)
            return

        if user_input.lower() in ("quit", "exit", "/quit"):
            print(f"\n{Y}Session ended.{X}\n")
            return

        response = engine.respond(user_input)
        question_count += 1

        if engine.is_complete(response):
            print(f"\n{P}TLM:{X} {response}\n")
            print(f"{C}TLM ▸ Generating spec + TDD instructions...{X}\n")
            _finish_session(engine, project, feature_request)
            return

        print(f"\n{P}TLM:{X} {response}\n")


def _finish_session(engine: DiscoveryEngine, project: Project, feature_request: str):
    """Generate spec, CLAUDE.md, update knowledge base."""

    print(f"  {D}Generating feature spec...{X}")
    spec, instructions = engine.generate_outputs()

    spec_path = project.save_spec(feature_request, spec)
    print(f"  {G}✓{X} Spec saved → {spec_path}")

    claude_path = project.save_claude_md(instructions)
    print(f"  {G}✓{X} CLAUDE.md updated → {claude_path}")

    print(f"  {D}Updating knowledge base...{X}")
    knowledge = engine.extract_knowledge(spec)
    project.append_knowledge(knowledge)
    print(f"  {G}✓{X} Knowledge base updated")

    project.increment_sessions()

    # Preview spec
    print(f"\n{'='*60}")
    print(f"  {G}✓ Session Complete{X}")
    print(f"{'='*60}\n")

    lines = spec.split("\n")
    preview = "\n".join(lines[:30])
    print(f"{D}{'─'*60}{X}")
    print(preview)
    if len(lines) > 30:
        print(f"\n{D}  ... ({len(lines) - 30} more lines){X}")
    print(f"{D}{'─'*60}{X}")

    print(f"""
{B}What just happened:{X}

  1. {C}Spec{X} → {spec_path}
  2. {C}CLAUDE.md{X} → {claude_path}
  3. {C}Knowledge base{X} → .tlm/knowledge.md

{B}Enforcement (mechanical — runs real commands, checks exit codes):{X}

  Before you commit, {C}tlm check{X} will run every check from
  your approved enforcement config. Tests must pass. Coverage
  must meet thresholds. Linting, type checks, migrations —
  whatever your config includes. Hard pass/fail.

{B}Next steps:{X}

  1. Review the spec:  {D}cat {spec_path}{X}
  2. Open Claude Code:  {D}claude{X}
  3. Before committing:  {D}tlm check{X}
  4. Auto-enforce:  {D}tlm hook install{X}
""")


# ─── CHECK ─────────────────────────────────────────────────────

def cmd_check(spec_path: str = None):
    """Mechanical enforcement + spec review."""
    logo()
    project = Project(".")
    require_init(project)
    require_approved_config(project)

    claude, api_client, project_id = _get_backend(project)
    enforcer = Enforcer(".")

    # ─── PHASE 1: Mechanical checks from enforcement.json ─────
    print(f"{B}Phase 1: Mechanical Enforcement{X}\n")
    report = enforcer.run_checks("pre_commit")

    # Also run coverage
    cov_result = enforcer.run_coverage_check()
    report.checks.append(cov_result)

    print(report.summary())

    if not report.passed:
        print(f"\n{R}✗ Mechanical checks FAILED.{X}")
        for b in report.blockers:
            print(f"  {R}•{X} {b.name}: {b.message}")
        print(f"\n{D}Fix blockers above, then run `tlm check` again.{X}\n")
        sys.exit(1)

    print(f"\n{G}✓ Mechanical checks passed.{X}\n")

    # ─── PHASE 2: LLM spec compliance review ─────
    if spec_path:
        if not Path(spec_path).exists():
            print(f"{R}✗ Spec not found: {spec_path}{X}\n")
            sys.exit(1)
    else:
        specs = sorted(project.specs_dir.glob("*.md"), reverse=True)
        if specs:
            spec_path = str(specs[0])
            print(f"{D}Using latest spec: {spec_path}{X}")
        else:
            print(f"{Y}No specs found. Skipping spec review.{X}\n")
            print(f"{G}✓ All mechanical checks passed. Safe to commit.{X}\n")
            return

    print(f"\n{B}Phase 2: Spec Compliance Review{X}\n")
    checker = ComplianceChecker(project, claude, api_client=api_client, project_id=project_id)
    result = checker.check(spec_path)
    print(result)

    if "### Verdict: FAIL" in result:
        print(f"\n{R}✗ Spec review FAILED. Fix blockers before committing.{X}\n")
        sys.exit(1)
    elif "PASS WITH WARNINGS" in result:
        print(f"\n{Y}⚠ Passed with warnings.{X}\n")
    else:
        print(f"\n{G}✓ All checks passed. Safe to commit.{X}\n")


# ─── STATUS ────────────────────────────────────────────────────

def cmd_status():
    """Show project status + enforcement status."""
    logo()
    project = Project(".")
    require_init(project)

    config = project.get_config()
    knowledge = project.get_knowledge()
    specs = list(project.specs_dir.glob("*.md"))

    facts = [l for l in knowledge.split("\n")
             if l.strip() and not l.startswith(("_", "#", "---"))]

    print(f"  {B}Project:{X}  {config.get('project_name', 'unknown')}")
    print(f"  {B}Created:{X}  {config.get('created', 'unknown')}")
    print()
    print(f"  {C}Sessions used:{X}     {config.get('sessions_used', 0)}")
    print(f"  {C}Specs generated:{X}   {len(specs)}")
    print(f"  {C}Knowledge facts:{X}   {len(facts)}")
    print()

    # Enforcement status
    print(f"  {B}Enforcement:{X}")

    has_claude_md = project.claude_md.exists()
    print(f"    CLAUDE.md:  {'%s✓ Exists%s' % (G, X) if has_claude_md else '%s✗ Missing%s' % (R, X)}")

    if project.enforcement.approved:
        ec = project.enforcement.load()
        envs = ec.get("environments", {})
        checks = ec.get("checks", [])
        blockers = [c for c in checks if c.get("blocker")]
        warnings = [c for c in checks if not c.get("blocker")]

        print(f"    Config:     {G}✓ Approved{X}")
        print(f"    Envs:       {len(envs)} configured ({', '.join(envs.keys())})")
        print(f"    Checks:     {len(blockers)} blockers, {len(warnings)} warnings")

        # Quick drift check (file-level only, no LLM)
        drift = project.enforcement.check_drift()
        if drift["drifted"]:
            print(f"    Drift:      {Y}⚠ Files changed: {', '.join(drift['changed_files'])}{X}")
        else:
            print(f"    Drift:      {G}✓ No drift{X}")
    else:
        print(f"    Config:     {R}✗ Not approved — run `tlm init`{X}")

    # Git hooks
    hook_path = project.root / ".git" / "hooks" / "pre-commit"
    has_hook = hook_path.exists() and "tlm check" in (hook_path.read_text() if hook_path.exists() else "")
    print(f"    Pre-commit: {'%s✓ Installed%s' % (G, X) if has_hook else '%s○ Not installed%s' % (D, X)}")

    post_hook_path = project.root / ".git" / "hooks" / "post-commit"
    has_post_hook = post_hook_path.exists() and "TLM" in (post_hook_path.read_text() if post_hook_path.exists() else "")
    print(f"    Post-commit: {'%s✓ Installed%s' % (G, X) if has_post_hook else '%s○ Not installed%s' % (D, X)}")

    # Learning metrics
    accuracy_history = config.get("spec_accuracy_history", [])
    total_analyzed = config.get("total_commits_analyzed", 0)

    if accuracy_history:
        latest = accuracy_history[-1]
        first = accuracy_history[0]
        trend = ""
        if len(accuracy_history) >= 2:
            delta = latest["accuracy"] - first["accuracy"]
            if delta > 0:
                trend = f" {G}(↑ from {first['accuracy']}% on first analysis){X}"
            elif delta < 0:
                trend = f" {R}(↓ from {first['accuracy']}%){X}"

        print(f"\n  {B}Learning:{X}")
        print(f"    Spec accuracy:      {latest['accuracy']}%{trend}")
        print(f"    Commits analyzed:   {total_analyzed}")
        print(f"    Learning sessions:  {len(accuracy_history)}")

    print()

    # Knowledge health
    health = min(100, len(facts) * 5)
    filled = int(health / 5)
    bar = f"{'█' * filled}{'░' * (20 - filled)}"
    print(f"  {B}Knowledge Health:{X} [{C}{bar}{X}] {health}%")

    if specs:
        print(f"\n  {B}Recent Specs:{X}")
        for s in sorted(specs, reverse=True)[:5]:
            print(f"    {D}•{X} {s.name}")

    print()


# ─── LEARN ────────────────────────────────────────────────────

def cmd_learn(full_history: bool = False):
    """Analyze git commits and extract lessons."""
    logo()
    project = Project(".")
    require_init(project)
    claude, api_client, project_id = _get_backend(project)

    from tlm.learner import Learner
    learner = Learner(project, claude, api_client=api_client, project_id=project_id)

    if full_history:
        try:
            result = subprocess.run(
                ["git", "rev-list", "--count", "HEAD"],
                capture_output=True, text=True, cwd=str(project.root), timeout=5,
            )
            total = int(result.stdout.strip())
        except Exception:
            total = "unknown number of"

        print(f"{C}TLM ▸ Archaeological dig: analyzing {total} commits...{X}")
        print(f"{D}  This will take a while. Getting smart about your project's history.{X}\n")

        def progress(current, total_n, hash_str, summary):
            print(f"  {D}[{current}/{total_n}]{X} {hash_str} — {summary[:60]}")

        synthesis = learner.learn_full_history(progress_callback=progress)
    else:
        commit_count = learner.get_commit_count_since_last_session()
        if commit_count == 0:
            print(f"{D}No new commits since last session.{X}\n")
            return

        print(f"{C}TLM ▸ Analyzing {commit_count} commits since last session...{X}\n")

        def progress(current, total_n, hash_str, summary):
            print(f"  {D}[{current}/{total_n}]{X} {hash_str} — {summary[:60]}")

        synthesis = learner.learn_since_last_session(progress_callback=progress)

    if synthesis.get("total_commits", 0) == 0:
        print(f"\n{D}Nothing to learn from.{X}\n")
        return

    # Display full results
    accuracy = synthesis.get("spec_accuracy_percent", "?")
    print(f"\n{'='*60}")
    print(f"  {B}Learning Report{X}")
    print(f"{'='*60}\n")

    print(f"  Commits analyzed:  {synthesis.get('total_commits', 0)}")
    print(f"  Planned work:      {synthesis.get('planned_commits', 0)}")
    print(f"  Unplanned work:    {synthesis.get('unplanned_commits', 0)}")
    print(f"  Spec accuracy:     {accuracy}%")

    for bp in synthesis.get("bug_patterns", []):
        print(f"\n  {R}Bug Pattern: {bp.get('pattern')}{X} ({bp.get('frequency', '?')}x, {bp.get('severity', '?')} severity)")
        print(f"  {D}{bp.get('lesson', '')}{X}")
        for q in bp.get("interview_questions", []):
            print(f"    {C}→{X} {q}")

    for uf in synthesis.get("unplanned_features", []):
        print(f"\n  {Y}Unplanned: {uf.get('what')}{X}")
        print(f"  {D}{uf.get('lesson', '')}{X}")

    for ae in synthesis.get("architecture_evolutions", []):
        print(f"\n  {P}Evolution: {ae.get('what')}{X}")
        print(f"  {D}{ae.get('lesson', '')}{X}")

    improvements = synthesis.get("interview_improvements", [])
    if improvements:
        print(f"\n  {B}Future Interview Improvements:{X}")
        for imp in improvements:
            print(f"    {G}→{X} {imp}")

    print(f"\n{G}✓ Lessons saved to knowledge base.{X}")
    print(f"{D}  These will be injected into your next `tlm build` interview.{X}\n")


# ─── SPECS ─────────────────────────────────────────────────────

def cmd_specs():
    project = Project(".")
    require_init(project)

    specs = sorted(project.specs_dir.glob("*.md"), reverse=True)
    if not specs:
        print(f"\n{Y}No specs yet. Run `tlm build \"feature\"` to create one.{X}\n")
        return

    print(f"\n  {B}Generated Specs:{X}\n")
    for s in specs:
        title = s.read_text().split("\n")[0]
        size = len(s.read_text().split("\n"))
        print(f"  {C}•{X} {s.name} {D}({size} lines){X}")
        print(f"    {D}{title}{X}")
    print()


# ─── GIT HOOKS ─────────────────────────────────────────────────

PRE_COMMIT_HOOK = """#!/bin/sh
# TLM Pre-Commit Quality Gate
echo ""
echo "\\033[36mTLM ▸ Pre-commit quality gate...\\033[0m"
echo ""

if ! command -v tlm &> /dev/null; then
    echo "\\033[33m⚠ TLM not found in PATH. Skipping.\\033[0m"
    exit 0
fi

# Check for TLM server auth OR Anthropic key
if [ -z "$ANTHROPIC_API_KEY" ] && [ ! -f "$HOME/.tlm/credentials.json" ]; then
    echo "\\033[33m⚠ Not authenticated. Skipping TLM check.\\033[0m"
    exit 0
fi

if [ ! -f ".tlm/enforcement.json" ]; then
    echo "\\033[2mNo enforcement config. Skipping.\\033[0m"
    exit 0
fi

tlm check
exit $?
"""


POST_COMMIT_HOOK = """#!/bin/sh
# TLM Post-Commit Learner — analyzes commits in background
# This runs silently after every commit. Never blocks git.

if ! command -v tlm &> /dev/null; then
    exit 0
fi

if [ ! -d ".tlm" ]; then
    exit 0
fi

# Check for TLM server auth OR Anthropic key
if [ -z "$ANTHROPIC_API_KEY" ] && [ ! -f "$HOME/.tlm/credentials.json" ]; then
    exit 0
fi

# Run analysis in background — never block the developer
nohup tlm _analyze-last-commit > /dev/null 2>&1 &
"""


def _cmd_analyze_last_commit():
    """Internal command for post-commit hook. Silently analyzes the last commit."""
    try:
        project = Project(".")
        if not project.initialized:
            return

        client = get_client()
        if not client:
            return

        project_id = None
        if project.config_file.exists():
            try:
                config = json.loads(project.config_file.read_text())
                project_id = config.get("project_id")
            except (json.JSONDecodeError, OSError):
                pass

        from tlm.learner import Learner
        learner = Learner(project, api_client=client, project_id=project_id)
        learner.learn_last_commit()
    except Exception:
        pass  # Never crash, never block git


def _install_hook(hooks_dir: Path, hook_name: str, hook_content: str, description: str):
    """Install a single git hook with backup."""
    hook_path = hooks_dir / hook_name

    if hook_path.exists():
        existing = hook_path.read_text()
        if "TLM" in existing:
            print(f"  {Y}{hook_name} already installed.{X}")
            return
        backup = hooks_dir / f"{hook_name}.backup"
        hook_path.rename(backup)
        print(f"  {D}Existing {hook_name} backed up → {backup}{X}")

    hook_path.write_text(hook_content)
    hook_path.chmod(hook_path.stat().st_mode | stat.S_IEXEC)
    print(f"  {G}✓{X} {hook_name} installed — {description}")


def _uninstall_hook(hooks_dir: Path, hook_name: str):
    """Uninstall a single git hook with backup restore."""
    hook_path = hooks_dir / hook_name
    if hook_path.exists() and "TLM" in hook_path.read_text():
        hook_path.unlink()
        backup = hooks_dir / f"{hook_name}.backup"
        if backup.exists():
            backup.rename(hook_path)
        print(f"  {G}✓{X} {hook_name} removed.")
        return True
    return False


def cmd_hook(action: str):
    project = Project(".")
    git_dir = project.root / ".git"

    if not git_dir.exists():
        print(f"{R}✗ Not a git repository.{X}\n")
        sys.exit(1)

    hooks_dir = git_dir / "hooks"
    hooks_dir.mkdir(exist_ok=True)

    if action == "install":
        print(f"\n{Y}Note: `tlm hook install` is deprecated. Use `tlm install` instead.{X}")
        print(f"{D}  `tlm install` sets up everything: CLAUDE.md, Claude Code hooks, and git hooks.{X}\n")
        _install_hook(hooks_dir, "pre-commit", PRE_COMMIT_HOOK,
                       "runs `tlm check` before every commit")
        _install_hook(hooks_dir, "post-commit", POST_COMMIT_HOOK,
                       "analyzes commits in background for learning")
        print(f"\n{G}✓{X} Git hooks installed.\n")

    elif action == "uninstall":
        print(f"\n{Y}Note: `tlm hook uninstall` is deprecated. Use `tlm uninstall` instead.{X}\n")
        removed_pre = _uninstall_hook(hooks_dir, "pre-commit")
        removed_post = _uninstall_hook(hooks_dir, "post-commit")
        if removed_pre or removed_post:
            print(f"\n{G}✓{X} TLM hooks removed.\n")
        else:
            print(f"{Y}No TLM hooks found.{X}\n")
    else:
        print(f"{R}Usage: tlm hook [install|uninstall]{X}\n")


# ─── INSTALL / UNINSTALL ─────────────────────────────────────

def cmd_install():
    """Full TLM installation: scan + approve config + install hooks + CLAUDE.md."""
    logo()

    project = Project(".")
    project.init()
    claude, api_client, project_id = _get_backend(project)

    # Phase 1: Scan project
    print(f"{C}TLM ▸ Scanning your project...{X}\n")
    scanner = Scanner(project, claude, api_client=api_client, project_id=project_id)
    profile = scanner.scan()

    print(f"{G}✓{X} Project scanned\n")
    print(f"{D}{'─'*60}{X}")
    print(profile)
    print(f"{D}{'─'*60}{X}")

    # Phase 2: Generate enforcement config
    print(f"\n{C}TLM ▸ Generating enforcement rules...{X}\n")
    config_gen = ConfigGenerator(project, claude, api_client=api_client, project_id=project_id)
    config = config_gen.generate()

    # Phase 3: Interactive approval
    _interactive_config_approval(config_gen, config, project)

    # Phase 4: Install hooks + CLAUDE.md
    if project.enforcement.approved:
        print(f"\n{C}TLM ▸ Installing Claude Code integration...{X}\n")

        from tlm.installer import Installer
        installer = Installer(".")
        installer.install()

        print(f"  {G}✓{X} CLAUDE.md generated with TLM rules")
        print(f"  {G}✓{X} Claude Code hooks installed (.claude/settings.json)")
        print(f"  {G}✓{X} Git post-commit hook installed (passive learning)")
        print(f"  {G}✓{X} State initialized (.tlm/state.json)")

    # Phase 5: Archaeological dig
    try:
        result = subprocess.run(
            ["git", "rev-list", "--count", "HEAD"],
            capture_output=True, text=True, cwd=str(project.root), timeout=5,
        )
        if result.returncode == 0:
            commit_count = int(result.stdout.strip())
            if commit_count > 0:
                print(f"\n{C}TLM ▸ This project has {commit_count} commits.{X}")
                print(f"  Want me to analyze your history to learn your project's patterns?")
                print(f"  This makes my interviews much better from day one.\n")
                print(f"  {G}yes{X}  — Analyze all {commit_count} commits")
                print(f"  {D}no{X}   — Start fresh, I'll learn as we go\n")

                try:
                    user_input = input(f"{G}You:{X} ").strip()
                except (KeyboardInterrupt, EOFError):
                    user_input = "no"

                if user_input.lower() in ("yes", "y"):
                    cmd_learn(full_history=True)
    except Exception:
        pass

    print(f"""
{G}{'='*60}{X}
  {B}TLM is now installed.{X}
{G}{'='*60}{X}

  TLM is now an invisible layer inside Claude Code.
  Open Claude Code and start working — TLM activates automatically
  on any significant engineering activity.

  {B}What happens now:{X}
  - Ask to build a feature → TLM interviews you first
  - Ask about readiness → TLM does thorough assessment
  - Write code → TLM enforces TDD
  - Commit code → TLM checks spec compliance
  - Every commit → TLM learns in background

  {B}Manual commands (still available):{X}
  - {C}tlm check{X}      — Run quality gate manually
  - {C}tlm learn{X}      — Trigger learning manually
  - {C}tlm status{X}     — See project status
  - {C}tlm uninstall{X}  — Remove TLM integration
""")


def cmd_uninstall():
    """Remove TLM integration from project."""
    logo()

    project = Project(".")
    if not project.initialized:
        print(f"{Y}No TLM installation found.{X}\n")
        return

    from tlm.installer import Installer
    installer = Installer(".")
    installer.uninstall()

    print(f"  {G}✓{X} TLM rules removed from CLAUDE.md")
    print(f"  {G}✓{X} Claude Code hooks removed from .claude/settings.json")
    print(f"  {G}✓{X} Hook scripts removed")
    print(f"  {G}✓{X} Git hooks removed")
    print(f"\n  {D}.tlm/ data preserved (knowledge, specs, lessons).{X}")
    print(f"  {D}Run `tlm install` to re-install.{X}\n")


# ─── AUTH ─────────────────────────────────────────────────────

def cmd_auth(api_key: str, base_url: str = None):
    """Save TLM API key (and optionally server URL) for authentication."""
    if not api_key.startswith("tlm_sk_"):
        print(f"{R}✗ Invalid API key format. Keys start with 'tlm_sk_'{X}")
        sys.exit(1)

    save_credentials(api_key, base_url=base_url)
    print(f"{G}✓{X} API key saved to ~/.tlm/credentials.json")
    if base_url:
        print(f"  Server URL: {C}{base_url}{X}")
    print(f"{D}  You're authenticated. Run `tlm install` in your project.{X}\n")


def cmd_signup(server_url: str = None):
    """Sign up for TLM server — creates account and saves credentials."""
    from tlm.api_client import DEFAULT_BASE_URL
    server_url = server_url or DEFAULT_BASE_URL
    print(f"\n{C}TLM ▸ Sign up{X}")
    print(f"  Server: {server_url}\n")

    try:
        email = input(f"  Email: ").strip()
        password = input(f"  Password: ").strip()
    except (KeyboardInterrupt, EOFError):
        print(f"\n{Y}Cancelled.{X}\n")
        sys.exit(1)

    if not email or not password:
        print(f"{R}✗ Email and password are required.{X}")
        sys.exit(1)

    client = TLMClient(api_key="", base_url=server_url)
    try:
        result = client.signup(email, password)
    except TLMConnectionError as e:
        print(f"{R}✗ Cannot reach server: {e}{X}")
        sys.exit(1)
    except TLMServerError as e:
        print(f"{R}✗ {e}{X}")
        sys.exit(1)

    api_key = result["api_key"]
    save_credentials(api_key, base_url=server_url)

    print(f"\n{G}✓{X} Account created!")
    print(f"  API key saved to ~/.tlm/credentials.json")
    print(f"  Server: {C}{server_url}{X}")
    print(f"\n{D}  Run `tlm install` in your project to get started.{X}\n")


# ─── HOOK HANDLERS ───────────────────────────────────────────

def _cmd_hook(hook_name: str):
    """Internal hook handler called by Claude Code hook scripts."""
    from tlm.hooks import hook_session_start, hook_prompt_submit, hook_guard, hook_compliance_gate

    if hook_name == "session":
        # SessionStart: print context to stdout
        result = hook_session_start(".")
        print(result)

    elif hook_name == "prompt":
        # UserPromptSubmit: read stdin, return JSON to stdout
        try:
            stdin_data = sys.stdin.read()
        except Exception:
            stdin_data = "{}"
        result = hook_prompt_submit(".")
        print(json.dumps(result))

    elif hook_name == "guard":
        # PreToolUse (Write/Edit): read tool input from stdin, return JSON
        try:
            stdin_data = json.loads(sys.stdin.read())
        except Exception:
            stdin_data = {}
        result = hook_guard(".", stdin_data)
        if result:
            print(json.dumps(result))

    elif hook_name == "compliance":
        # PreToolUse (Bash): check for git commit, inject compliance reminder
        try:
            stdin_data = json.loads(sys.stdin.read())
            tool_input = stdin_data.get("tool_input", stdin_data)
        except Exception:
            tool_input = {}
        result = hook_compliance_gate(".", tool_input)
        if result:
            print(json.dumps(result))

    else:
        sys.exit(1)


# ─── MAIN ─────────────────────────────────────────────────────

def main():
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help", "help"):
        print(__doc__)
        return

    cmd = args[0]

    # ─── New commands ─────────────────────────────
    if cmd == "auth":
        if len(args) < 2:
            print(f"{R}Usage: tlm auth <api_key> [--url <server_url>]{X}")
            sys.exit(1)
        auth_url = None
        api_key = args[1]
        if "--url" in args:
            url_idx = args.index("--url")
            if url_idx + 1 < len(args):
                auth_url = args[url_idx + 1]
        cmd_auth(api_key, base_url=auth_url)
    elif cmd == "signup":
        signup_url = None
        if "--url" in args:
            url_idx = args.index("--url")
            if url_idx + 1 < len(args):
                signup_url = args[url_idx + 1]
        cmd_signup(signup_url)
    elif cmd == "install":
        cmd_install()
    elif cmd == "uninstall":
        cmd_uninstall()
    elif cmd == "_hook":
        if len(args) < 2:
            sys.exit(1)
        _cmd_hook(args[1])

    # ─── Preserved commands ───────────────────────
    elif cmd == "check":
        cmd_check(args[1] if len(args) > 1 else None)
    elif cmd == "status":
        cmd_status()
    elif cmd == "specs":
        cmd_specs()
    elif cmd == "learn":
        full = "--all" in args or "--full" in args
        cmd_learn(full_history=full)
    elif cmd == "_analyze-last-commit":
        _cmd_analyze_last_commit()

    # ─── Deprecated commands (still work) ─────────
    elif cmd == "init":
        print(f"\n{Y}Note: `tlm init` is deprecated. Use `tlm install` instead.{X}")
        print(f"{D}  `tlm install` does everything init does, plus installs Claude Code hooks.{X}\n")
        cmd_init()
    elif cmd == "build":
        print(f"\n{Y}Note: `tlm build` is deprecated.{X}")
        print(f"{D}  Use `tlm install` then work in Claude Code directly.{X}")
        print(f"{D}  TLM now activates automatically on significant engineering activities.{X}\n")
        if len(args) < 2:
            print(f'{R}Usage: tlm build "feature description"{X}')
            sys.exit(1)
        cmd_build(" ".join(args[1:]).strip("\"'"))
    elif cmd == "hook":
        if len(args) < 2:
            print(f"{R}Usage: tlm hook [install|uninstall]{X}")
            sys.exit(1)
        cmd_hook(args[1])

    else:
        print(f"{R}Unknown command: {cmd}{X}")
        print(f"{D}Run `tlm --help` for usage.{X}")
        sys.exit(1)


if __name__ == "__main__":
    main()
