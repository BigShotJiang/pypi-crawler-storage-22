"""
TLM Hook Handlers — Context injection for Claude Code.

These are lightweight handlers that read state files and return context.
No API calls, no LLM calls. Just file reads and JSON output.

Hook handlers:
    hook_session_start   — SessionStart: loads project context
    hook_prompt_submit   — UserPromptSubmit: reminds Claude of TLM rules
    hook_guard           — PreToolUse (Write/Edit): TDD enforcement
    hook_compliance_gate — PreToolUse (Bash): compliance check on git commit
"""

import json
import re
from pathlib import Path

from tlm.state import read_state
from tlm.api_client import get_client, TLMConnectionError
from tlm.cache import TLMCache


def _try_server_sync(project_root: str) -> dict | None:
    """Try to sync project data from TLM server. Returns sync data or None."""
    root = Path(project_root)
    config_file = root / ".tlm" / "config.json"

    # Need both API client and project_id
    client = get_client()
    if not client:
        return None

    if not config_file.exists():
        return None

    try:
        config = json.loads(config_file.read_text())
    except (json.JSONDecodeError, OSError):
        return None

    project_id = config.get("project_id")
    if not project_id:
        return None

    try:
        return client.sync(project_id, timeout=3.0)
    except (TLMConnectionError, Exception):
        return None


def hook_session_start(project_root: str) -> str:
    """SessionStart hook: inject project context into Claude's session.

    Sync protocol:
    1. Try GET /sync from TLM server (3s timeout)
    2. If successful, cache the data locally
    3. If failed, use cached data
    4. If no cache, fall back to raw .tlm/ files

    Returns a context string that gets printed to stdout for Claude Code.
    """
    root = Path(project_root)
    tlm_dir = root / ".tlm"

    if not tlm_dir.exists():
        return "TLM is not initialized in this project. Run `tlm install` to set up."

    # Try server sync → cache → raw files
    cache = TLMCache(str(tlm_dir))
    sync_data = _try_server_sync(project_root)

    if sync_data:
        cache.write_sync(sync_data)

    parts = ["[TLM] You are operating under TLM rules. Read CLAUDE.md for full details.\n"]

    # Current state
    state = read_state(project_root)
    phase = state.get("phase", "idle")
    activity = state.get("activity_type")
    active_spec = state.get("active_spec")

    parts.append(f"Current phase: {phase}")
    if activity:
        parts.append(f"Activity type: {activity}")
    if active_spec:
        spec_path = root / active_spec
        if spec_path.exists():
            spec_preview = spec_path.read_text()[:500]
            parts.append(f"Active spec: {active_spec}")
            parts.append(f"Spec preview:\n{spec_preview}")

    # Knowledge — prefer cache/sync, fall back to file
    knowledge = cache.get_knowledge_with_fallback()
    if knowledge:
        facts = [l.strip() for l in knowledge.split("\n")
                 if l.strip() and not l.startswith(("#", "_", "---"))]
        if facts:
            parts.append(f"\nProject knowledge ({len(facts)} facts):")
            for fact in facts[:10]:
                parts.append(f"  {fact}")
            if len(facts) > 10:
                parts.append(f"  ... and {len(facts) - 10} more (see .tlm/knowledge.md)")

    # Latest lessons — prefer cache/sync, fall back to files
    cached = cache.read_sync()
    if cached and cached.get("latest_synthesis"):
        synthesis = cached["latest_synthesis"]
        improvements = synthesis.get("interview_improvements", [])
        accuracy = synthesis.get("spec_accuracy_percent")
        if accuracy is not None:
            parts.append(f"\nLearning: spec accuracy {accuracy}%")
        if improvements:
            parts.append("Lesson-driven interview additions:")
            for imp in improvements[:5]:
                parts.append(f"  - MUST ASK: {imp}")
    else:
        # Fall back to local lessons files
        lessons_dir = tlm_dir / "lessons"
        if lessons_dir.exists():
            synthesis_files = sorted(lessons_dir.glob("*-synthesis.json"), reverse=True)
            if synthesis_files:
                try:
                    synthesis = json.loads(synthesis_files[0].read_text())
                    improvements = synthesis.get("interview_improvements", [])
                    accuracy = synthesis.get("spec_accuracy_percent")
                    if accuracy is not None:
                        parts.append(f"\nLearning: spec accuracy {accuracy}%")
                    if improvements:
                        parts.append("Lesson-driven interview additions:")
                        for imp in improvements[:5]:
                            parts.append(f"  - MUST ASK: {imp}")
                except (json.JSONDecodeError, OSError):
                    pass

    # Unprocessed commits count
    commits_dir = tlm_dir / "commits"
    if commits_dir.exists():
        unprocessed = [f for f in commits_dir.glob("*.json")
                       if not f.name.endswith("-processed.json")]
        if unprocessed:
            parts.append(f"\n{len(unprocessed)} commits analyzed since last synthesis.")

    # Enforcement config — prefer cache/sync, fall back to file
    enforcement_config = cache.get_enforcement_config_with_fallback()
    if enforcement_config and enforcement_config.get("approved"):
        envs = list(enforcement_config.get("environments", {}).keys())
        checks_count = len(enforcement_config.get("checks", []))
        parts.append(f"\nEnforcement: {checks_count} checks, environments: {', '.join(envs)}")
    elif not (cached and cached.get("enforcement_config")):
        # Fall back to local file only if cache didn't have it
        enforcement_file = tlm_dir / "enforcement.json"
        if enforcement_file.exists():
            try:
                config = json.loads(enforcement_file.read_text())
                if config.get("approved"):
                    envs = list(config.get("environments", {}).keys())
                    checks_count = len(config.get("checks", []))
                    parts.append(f"\nEnforcement: {checks_count} checks, environments: {', '.join(envs)}")
            except (json.JSONDecodeError, OSError):
                pass

    return "\n".join(parts)


def hook_prompt_submit(project_root: str) -> dict:
    """UserPromptSubmit hook: remind Claude of TLM state.

    Returns dict with additionalContext key for Claude Code.
    """
    state = read_state(project_root)
    phase = state.get("phase", "idle")
    activity = state.get("activity_type")
    active_spec = state.get("active_spec")

    if phase == "idle":
        context = (
            "[TLM] Before responding, classify this request: "
            "Is it a significant engineering activity? "
            "Check Tier 1 (always activate) and Tier 2 (self-classify) "
            "in CLAUDE.md. If significant, enter interview mode first."
        )
    elif phase == "tlm_active":
        context = (
            f"[TLM] You are in interview mode (activity: {activity or 'unknown'}). "
            "Continue asking questions one at a time. "
            "Do not write code until the interview is complete and spec is generated."
        )
    elif phase == "implementation":
        spec_note = f" Active spec: {active_spec}." if active_spec else ""
        context = (
            f"[TLM] Implementation phase.{spec_note} "
            "TDD is mandatory: write tests first, verify they fail, "
            "then implement, then verify they pass."
        )
    elif phase == "deployment":
        context = (
            "[TLM] Deployment phase. Follow the deployment pipeline "
            "from enforcement config. Never skip environments."
        )
    else:
        context = "[TLM] TLM rules are active. Check CLAUDE.md."

    return {"additionalContext": context}


def hook_guard(project_root: str, tool_input: dict) -> dict:
    """PreToolUse hook for Write/Edit tools: TDD enforcement.

    Args:
        project_root: Path to project root.
        tool_input: Dict with tool_name and tool_input from Claude Code.

    Returns:
        Empty dict (pass through) or dict with additionalContext.
    """
    tool_name = tool_input.get("tool_name", "")
    file_input = tool_input.get("tool_input", {})
    file_path = file_input.get("file_path", "")

    # Only guard Write and Edit tools
    if tool_name not in ("Write", "Edit"):
        return {}

    state = read_state(project_root)
    phase = state.get("phase", "idle")

    # Idle phase — no guardrails
    if phase == "idle":
        return {}

    # Check if this is a test file
    is_test_file = _is_test_file(file_path)

    # During interview (tlm_active): warn about writing source code
    if phase == "tlm_active" and not is_test_file:
        # Allow writing to .tlm/ directory (state, specs, etc.)
        if "/.tlm/" in file_path or file_path.startswith(".tlm/"):
            return {}
        return {
            "additionalContext": (
                "[TLM] You are still in interview/assessment mode. "
                "Complete your interview and generate a spec before writing code. "
                "If the assessment is complete, update .tlm/state.json to 'implementation' phase."
            )
        }

    # During implementation: TDD reminder for non-test files
    if phase == "implementation" and not is_test_file:
        # Allow .tlm/ files
        if "/.tlm/" in file_path or file_path.startswith(".tlm/"):
            return {}
        return {
            "additionalContext": (
                "[TLM] TDD reminder: Have you written and run the tests for this change first? "
                "Tests should fail before implementation, then pass after. "
                "If tests are already written and failing, proceed with implementation."
            )
        }

    return {}


def hook_compliance_gate(project_root: str, tool_input: dict) -> dict:
    """PreToolUse hook for Bash: compliance check on git commit.

    Injects a compliance reminder when Claude is about to git commit.
    This ensures spec compliance is checked even if CLAUDE.md instructions
    are partially ignored.

    Args:
        project_root: Path to project root.
        tool_input: Dict with command from Bash tool input.

    Returns:
        Empty dict (pass through) or dict with additionalContext.
    """
    command = tool_input.get("command", "")

    # Only care about git commit commands
    if not _is_git_commit(command):
        return {}

    root = Path(project_root)
    tlm_dir = root / ".tlm"

    # No TLM — pass through
    if not tlm_dir.exists():
        return {}

    state = read_state(project_root)
    active_spec = state.get("active_spec")

    parts = ["[TLM] COMPLIANCE CHECK before commit:"]

    # Check for active spec
    if active_spec:
        spec_path = root / active_spec
        if spec_path.exists():
            parts.append(f"\n1. Verify changes against spec: {active_spec}")
            parts.append("   - Are ALL spec items implemented?")
            parts.append("   - Are ALL specified test cases written and passing?")
            parts.append("   - Are there changes NOT covered by the spec?")

    # Check for enforcement config
    enforcement_file = tlm_dir / "enforcement.json"
    if enforcement_file.exists():
        try:
            config = json.loads(enforcement_file.read_text())
            if config.get("approved"):
                checks = config.get("checks", [])
                pre_commit_checks = [c for c in checks if c.get("when") == "pre_commit"]
                if pre_commit_checks:
                    parts.append(f"\n2. Run ALL pre-commit enforcement checks ({len(pre_commit_checks)} configured):")
                    for check in pre_commit_checks:
                        blocker = "BLOCKER" if check.get("blocker") else "warning"
                        parts.append(f"   - [{blocker}] {check.get('name', '?')}: `{check.get('command', '?')}`")
                    parts.append("\n   Run these checks and verify they pass before committing.")
        except (json.JSONDecodeError, OSError):
            pass

    # If no spec and no enforcement, still give a gentle reminder
    if len(parts) == 1:
        parts.append("Ensure all tests pass before committing.")

    parts.append("\nIf you have NOT verified compliance, pause and check now.")

    return {"additionalContext": "\n".join(parts)}


# ─── Internal helpers ─────────────────────────────────────────

def _is_test_file(file_path: str) -> bool:
    """Check if a file path looks like a test file."""
    path_lower = file_path.lower()
    test_indicators = (
        "/test_", "/tests/", "test.", "_test.", ".test.",
        "/spec/", "_spec.", ".spec.",
        "/__tests__/",
    )
    return any(indicator in path_lower for indicator in test_indicators)


def _is_git_commit(command: str) -> bool:
    """Check if a shell command is a git commit."""
    # Match: git commit, git commit -m, git commit --amend, etc.
    # But not: git commit-tree, echo "git commit"
    return bool(re.search(r'\bgit\s+commit\b', command))
