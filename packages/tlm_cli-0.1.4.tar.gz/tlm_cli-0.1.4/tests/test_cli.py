"""
Tests for TLM CLI — auth (manual + interactive), signup deprecation, error messages.
"""

import json
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock, call

import pytest

from tlm.cli import cmd_auth, cmd_signup, main, _get_backend
from tlm.api_client import TLMAuthError, TLMConnectionError, DEFAULT_BASE_URL
from tlm.engine import Project


# ─── Fixtures ─────────────────────────────────────────────────

@pytest.fixture
def credentials_dir(tmp_path):
    """Temporary directory for credentials."""
    cred_dir = tmp_path / ".tlm"
    cred_dir.mkdir()
    return str(cred_dir)


@pytest.fixture
def cred_file(credentials_dir):
    """Path to the credentials.json in tmp dir."""
    return Path(credentials_dir) / "credentials.json"


# ─── cmd_auth manual key Tests ────────────────────────────────

class TestCmdAuth:
    @patch("tlm.cli.save_credentials")
    def test_manual_key_saves(self, mock_save):
        """tlm auth <key> saves the API key."""
        cmd_auth(api_key="tlm_sk_test123")
        mock_save.assert_called_once_with("tlm_sk_test123", base_url=None)

    @patch("tlm.cli.save_credentials")
    def test_manual_key_with_url(self, mock_save):
        """tlm auth <key> --url <url> saves both key and URL."""
        cmd_auth(api_key="tlm_sk_test123", base_url="http://localhost:8000")
        mock_save.assert_called_once_with("tlm_sk_test123", base_url="http://localhost:8000")

    def test_manual_key_rejects_invalid(self):
        """tlm auth rejects keys not starting with tlm_sk_."""
        with pytest.raises(SystemExit):
            cmd_auth(api_key="bad_key_format")

    @patch("tlm.cli.save_credentials")
    def test_manual_key_none_url_preserves(self, mock_save):
        """When no --url is given, base_url=None is passed (preserves existing)."""
        cmd_auth(api_key="tlm_sk_abc")
        _, kwargs = mock_save.call_args
        assert kwargs["base_url"] is None


# ─── cmd_auth interactive Tests ──────────────────────────────

class TestCmdAuthInteractive:
    @patch("tlm.cli.get_client", return_value=None)
    @patch("builtins.input", return_value="tlm_sk_abc123")
    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_prints_auth_url(self, mock_cls, mock_save, mock_input, mock_gc, capsys):
        """Interactive auth prints the server auth page URL."""
        mock_cls.return_value.me.return_value = {"email": "a@b.com"}
        cmd_auth()
        out = capsys.readouterr().out
        assert "/auth" in out

    @patch("tlm.cli.get_client", return_value=None)
    @patch("builtins.input", return_value="tlm_sk_abc123")
    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_prompts_for_key_paste(self, mock_cls, mock_save, mock_input, mock_gc):
        """Interactive auth calls input() to prompt for key."""
        mock_cls.return_value.me.return_value = {"email": "a@b.com"}
        cmd_auth()
        mock_input.assert_called_once()

    @patch("tlm.cli.get_client", return_value=None)
    @patch("builtins.input", return_value="tlm_sk_abc123")
    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_valid_key_paste_saves(self, mock_cls, mock_save, mock_input, mock_gc):
        """Pasting a valid key saves it."""
        mock_cls.return_value.me.return_value = {"email": "a@b.com"}
        cmd_auth()
        mock_save.assert_called_once()
        saved_key = mock_save.call_args[0][0]
        assert saved_key == "tlm_sk_abc123"

    @patch("tlm.cli.get_client", return_value=None)
    @patch("builtins.input", return_value="garbage_key")
    def test_invalid_key_paste_exits(self, mock_input, mock_gc):
        """Pasting an invalid key exits."""
        with pytest.raises(SystemExit):
            cmd_auth()

    @patch("tlm.cli.get_client")
    def test_already_authenticated_shows_status(self, mock_gc, capsys):
        """If already authenticated, shows email and doesn't prompt."""
        mock_client = MagicMock()
        mock_client.me.return_value = {"email": "user@test.com"}
        mock_gc.return_value = mock_client
        cmd_auth()
        out = capsys.readouterr().out
        assert "user@test.com" in out

    @patch("tlm.cli.get_client")
    @patch("builtins.input", return_value="tlm_sk_new")
    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_stale_creds_prompts(self, mock_cls, mock_save, mock_input, mock_gc, capsys):
        """If me() fails (stale creds), shows URL and prompts for new key."""
        mock_client = MagicMock()
        mock_client.me.side_effect = TLMAuthError("bad key")
        mock_gc.return_value = mock_client
        mock_cls.return_value.me.return_value = {"email": "a@b.com"}
        cmd_auth()
        out = capsys.readouterr().out
        assert "/auth" in out
        mock_input.assert_called_once()

    @patch("tlm.cli.get_client", return_value=None)
    @patch("builtins.input", return_value="tlm_sk_abc123")
    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_verifies_after_save(self, mock_cls, mock_save, mock_input, mock_gc):
        """After saving, calls me() on new client to verify."""
        mock_new_client = MagicMock()
        mock_new_client.me.return_value = {"email": "a@b.com"}
        mock_cls.return_value = mock_new_client
        cmd_auth()
        mock_new_client.me.assert_called_once()

    @patch("tlm.cli.get_client", return_value=None)
    @patch("builtins.input", return_value="tlm_sk_abc123")
    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_verify_failure_warns_but_saves(self, mock_cls, mock_save, mock_input, mock_gc, capsys):
        """If verification fails, key is still saved with a warning."""
        mock_cls.return_value.me.side_effect = TLMAuthError("bad")
        cmd_auth()
        mock_save.assert_called_once()
        out = capsys.readouterr().out
        assert "Could not verify" in out or "saved" in out.lower()

    @patch("tlm.cli.get_client", return_value=None)
    @patch("builtins.input", return_value="tlm_sk_abc123")
    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_connection_error_on_verify_warns(self, mock_cls, mock_save, mock_input, mock_gc, capsys):
        """If server unreachable during verify, saves key and warns."""
        mock_cls.return_value.me.side_effect = TLMConnectionError("unreachable")
        cmd_auth()
        mock_save.assert_called_once()
        out = capsys.readouterr().out
        assert "saved" in out.lower() or "unreachable" in out.lower()

    @patch("tlm.cli.get_client", return_value=None)
    @patch("builtins.input", side_effect=KeyboardInterrupt)
    def test_keyboard_interrupt_clean_exit(self, mock_input, mock_gc):
        """KeyboardInterrupt during input exits cleanly."""
        with pytest.raises(SystemExit):
            cmd_auth()


# ─── cmd_signup (deprecated) Tests ───────────────────────────

class TestCmdSignup:
    @patch("tlm.cli.cmd_auth")
    def test_signup_prints_deprecation(self, mock_auth, capsys):
        """tlm signup prints deprecation notice and calls cmd_auth."""
        cmd_signup()
        out = capsys.readouterr().out
        assert "deprecated" in out.lower() or "tlm auth" in out
        mock_auth.assert_called_once()


# ─── Main argument parsing Tests ─────────────────────────────

class TestMainArgParsing:
    @patch("tlm.cli.cmd_auth")
    def test_main_auth_no_args(self, mock_auth):
        """tlm auth (no key) calls cmd_auth() with no api_key."""
        with patch.object(sys, 'argv', ['tlm', 'auth']):
            main()
        mock_auth.assert_called_once_with(api_key=None, base_url=None)

    @patch("tlm.cli.cmd_auth")
    def test_main_auth_with_key(self, mock_auth):
        """tlm auth <key> passes api_key."""
        with patch.object(sys, 'argv', ['tlm', 'auth', 'tlm_sk_test']):
            main()
        mock_auth.assert_called_once_with(api_key="tlm_sk_test", base_url=None)

    @patch("tlm.cli.cmd_auth")
    def test_main_auth_with_url(self, mock_auth):
        """tlm auth --url <url> passes base_url."""
        with patch.object(sys, 'argv', ['tlm', 'auth', '--url', 'http://localhost:8000']):
            main()
        mock_auth.assert_called_once_with(api_key=None, base_url="http://localhost:8000")

    @patch("tlm.cli.cmd_auth")
    def test_main_auth_key_and_url(self, mock_auth):
        """tlm auth <key> --url <url> passes both."""
        with patch.object(sys, 'argv', ['tlm', 'auth', 'tlm_sk_test', '--url', 'http://localhost:8000']):
            main()
        mock_auth.assert_called_once_with(api_key="tlm_sk_test", base_url="http://localhost:8000")

    @patch("tlm.cli.cmd_signup")
    def test_main_signup_deprecated(self, mock_signup):
        """tlm signup calls cmd_signup (which prints deprecation)."""
        with patch.object(sys, 'argv', ['tlm', 'signup']):
            main()
        mock_signup.assert_called_once()


# ─── Error message Tests ────────────────────────────────────

class TestErrorMessages:
    @patch("tlm.cli.get_client", return_value=None)
    def test_get_backend_says_tlm_auth(self, mock_gc, capsys):
        """_get_backend error message says 'tlm auth'."""
        with pytest.raises(SystemExit):
            _get_backend()
        out = capsys.readouterr().out
        assert "tlm auth" in out

    @patch("tlm.cli.get_client", return_value=None)
    def test_get_backend_no_tlm_dev(self, mock_gc, capsys):
        """_get_backend error message does NOT reference tlm.dev."""
        with pytest.raises(SystemExit):
            _get_backend()
        out = capsys.readouterr().out
        assert "tlm.dev" not in out


# ─── _get_backend auto-project-creation Tests ────────────────

class TestGetBackendAutoProject:
    @patch("tlm.cli.get_client")
    def test_creates_project_on_server_when_no_project_id(self, mock_get_client, tmp_path):
        """_get_backend auto-creates project on server when project_id is missing."""
        mock_client = MagicMock()
        mock_client.create_project.return_value = {
            "project_id": 42,
            "name": "my-project",
            "fingerprint": "abc123",
        }
        mock_get_client.return_value = mock_client

        project = Project(str(tmp_path))
        project.init()

        _, client, project_id = _get_backend(project)

        assert project_id == 42
        mock_client.create_project.assert_called_once()

    @patch("tlm.cli.get_client")
    def test_saves_project_id_to_config(self, mock_get_client, tmp_path):
        """Auto-created project_id is saved to .tlm/config.json."""
        mock_client = MagicMock()
        mock_client.create_project.return_value = {
            "project_id": 99,
            "name": "test-proj",
            "fingerprint": "xyz",
        }
        mock_get_client.return_value = mock_client

        project = Project(str(tmp_path))
        project.init()

        _get_backend(project)

        config = json.loads(project.config_file.read_text())
        assert config["project_id"] == 99

    @patch("tlm.cli.get_client")
    def test_reuses_existing_project_id(self, mock_get_client, tmp_path):
        """_get_backend does NOT create project if project_id already exists."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        project = Project(str(tmp_path))
        project.init()
        config = json.loads(project.config_file.read_text())
        config["project_id"] = 77
        project.config_file.write_text(json.dumps(config))

        _, client, project_id = _get_backend(project)

        assert project_id == 77
        mock_client.create_project.assert_not_called()

    @patch("tlm.cli.get_client")
    def test_no_project_skips_creation(self, mock_get_client):
        """_get_backend without a project arg doesn't try to create one."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        _, client, project_id = _get_backend(None)

        assert project_id is None
        mock_client.create_project.assert_not_called()
