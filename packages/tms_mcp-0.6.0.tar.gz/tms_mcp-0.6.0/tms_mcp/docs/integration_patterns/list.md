| pattern_id | description |
| --- | --- |
| last_mile/basic | This guide outlines a streamlined, three-step process for basic last-mile delivery. |
| last_mile/navigation | This guide outlines a streamlined, four-step process for last-mile delivery, with navigation path generation. |
