"""
tns-py - A Python package for loading and transmitting variables.

This package provides functionality to:
- Load variables from .env files
- Read system variables
- Transmit variables to endpoints
"""

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .quasar_handler import ZephyrCollector, quasar_execute, nebula_execute

__all__ = ["ZephyrCollector", "quasar_execute", "nebula_execute"]

