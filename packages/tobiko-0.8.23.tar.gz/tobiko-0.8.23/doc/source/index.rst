.. include:: ../../README.rst

.. include:: content.rst
