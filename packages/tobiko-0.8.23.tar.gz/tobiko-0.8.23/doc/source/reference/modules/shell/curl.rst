tobiko.shell.curl
-----------------

.. automodule:: tobiko.shell.curl
    :members:
    :imported-members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
