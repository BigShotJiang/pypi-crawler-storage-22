.. _tobiko-conf:

tobiko.conf
~~~~~~~~~~~

.. tobiko-conf-label

Tobiko tries to load the '`tobiko.conf`' file from one of the below locations:

* current directory::

    ./tobiko.conf

* user home directory::

    ~/.tobiko/tobiko.conf

* system directory::

    /etc/tobiko/tobiko.conf
