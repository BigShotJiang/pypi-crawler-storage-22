# todoist-toolkit

Todoist CLI + Claude skill + MCP server built on the official `todoist-api-python` SDK.

## Features
- `todo` CLI for add/list/get/update/complete/delete/projects/recap
- Claude skill + MCP stdio server (`todoist_mcp`) exposing the same operations as tools
- Shared core layer with structured errors and JSON-friendly output
- Optional recap summarization via Gemini (`GOOGLE_API_KEY`)

## Install (editable)
```bash
pip install -e packages/todoist-toolkit[all]
```

## Environment
- `TODOIST_API_KEY` (required): Todoist REST API token
- `GOOGLE_API_KEY` (optional): enables LLM summaries for `todo recap`

## CLI Examples
```bash
# List active tasks
todo list

# Add a task
todo add "Prep deck" --due "tomorrow 9am" --priority 4 --project "Work"

# Complete a task
todo complete 2995104339

# Recap (uses Gemini if GOOGLE_API_KEY is set)
todo recap --days 1
```

## MCP / Claude Skill
Start the stdio server:
```bash
python -m todoist_toolkit.mcp_server
```

Add to Claude config (example):
```json
{
  "mcpServers": {
    "todoist": {
      "command": "python3",
      "args": ["/home/coolhand/packages/todoist-toolkit/src/todoist_toolkit/mcp_server.py"],
      "env": {"TODOIST_API_KEY": "<token>", "GOOGLE_API_KEY": "<optional>"}
    }
  }
}
```

## Tests
```bash
cd packages/todoist-toolkit
pytest
```
