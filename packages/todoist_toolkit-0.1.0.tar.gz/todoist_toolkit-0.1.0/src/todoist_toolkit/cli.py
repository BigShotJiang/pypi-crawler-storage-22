"""Todoist CLI entrypoint (Typer)."""

from __future__ import annotations

import json
from typing import Optional

import typer

from .client import TodoistService, TaskData, priority_label
from .recap import build_recap

app = typer.Typer(help="Todoist CLI with recap and MCP-friendly JSON output")
_service_instance: Optional[TodoistService] = None


def _service() -> TodoistService:
    global _service_instance
    if _service_instance is None:
        _service_instance = TodoistService()
    return _service_instance


def _project_id_from_name(name: Optional[str]) -> Optional[str]:
    if not name:
        return None
    service = _service()
    project_id = service.find_project_id(name)
    if not project_id:
        raise typer.BadParameter(f"Project '{name}' not found")
    return project_id


def _print_tasks(tasks: list[TaskData]) -> None:
    if not tasks:
        typer.echo("No tasks found.")
        return
    for task in tasks:
        due = task.due or "No date"
        prio = priority_label(task.priority)
        labels = f" [{', '.join(task.labels)}]" if task.labels else ""
        typer.echo(f"{task.id}: {task.content} (due: {due}, {prio}){labels}")


@app.command(name="list")
@app.command(name="ls")
@app.command(name="tasks")
def list_tasks(
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project name"),
    label: Optional[str] = typer.Option(None, "--label", "-l", help="Label name"),
    filter_query: Optional[str] = typer.Option(None, "--filter", "-f", help="Todoist filter"),
    json_output: bool = typer.Option(False, "--json", help="Output JSON"),
):
    service = _service()
    project_id = _project_id_from_name(project) if project else None
    tasks = service.list_tasks(project_id=project_id, label=label, filter_query=filter_query)
    if json_output:
        typer.echo(json.dumps([t.to_dict() for t in tasks], indent=2))
    else:
        _print_tasks(tasks)


@app.command()
def projects(json_output: bool = typer.Option(False, "--json", help="Output JSON")):
    service = _service()
    projects = service.list_projects()
    if json_output:
        typer.echo(json.dumps([{ "id": p.id, "name": p.name } for p in projects], indent=2))
    else:
        for proj in projects:
            typer.echo(f"{proj.id}: {proj.name}")


@app.command()
def add(
    content: str = typer.Argument(..., help="Task content"),
    due: Optional[str] = typer.Option(None, "--due", "-d", help="Natural language due date"),
    priority: int = typer.Option(1, "--priority", "-P", min=1, max=4, help="1-4"),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project name"),
    labels: Optional[str] = typer.Option(None, "--labels", "-l", help="Comma separated labels"),
    description: Optional[str] = typer.Option(None, "--description", "-m", help="Description"),
    json_output: bool = typer.Option(False, "--json", help="Output JSON"),
):
    service = _service()
    project_id = _project_id_from_name(project) if project else None
    label_list = [lbl.strip() for lbl in labels.split(",")] if labels else None
    task = service.add_task(
        content=content,
        due=due,
        priority=priority,
        project_id=project_id,
        labels=label_list,
        description=description,
    )
    if json_output:
        typer.echo(json.dumps(task.to_dict(), indent=2))
    else:
        typer.echo(f"Created {task.id}: {task.content}")


@app.command()
def update(
    task_id: str = typer.Argument(..., help="Task ID"),
    content: Optional[str] = typer.Option(None, "--content", "-c"),
    due: Optional[str] = typer.Option(None, "--due", "-d"),
    priority: Optional[int] = typer.Option(None, "--priority", "-P", min=1, max=4),
    labels: Optional[str] = typer.Option(None, "--labels", "-l"),
    description: Optional[str] = typer.Option(None, "--description", "-m"),
):
    service = _service()
    label_list = [lbl.strip() for lbl in labels.split(",")] if labels else None
    changed = service.update_task(
        task_id,
        content=content,
        due=due,
        priority=priority,
        labels=label_list,
        description=description,
    )
    if not changed:
        raise typer.Exit(code=1)
    typer.echo(f"Updated {task_id}.")


@app.command()
def complete(task_id: str = typer.Argument(..., help="Task ID")):
    service = _service()
    ok = service.complete_task(task_id)
    if not ok:
        raise typer.Exit(code=1)
    typer.echo(f"Completed {task_id}.")


@app.command()
def delete(task_id: str = typer.Argument(..., help="Task ID")):
    service = _service()
    ok = service.delete_task(task_id)
    if not ok:
        raise typer.Exit(code=1)
    typer.echo(f"Deleted {task_id}.")


@app.command()
def get(task_id: str = typer.Argument(..., help="Task ID"), json_output: bool = typer.Option(False, "--json")):
    service = _service()
    task = service.get_task(task_id)
    if json_output:
        typer.echo(json.dumps(task.to_dict(), indent=2))
    else:
        typer.echo(f"{task.id}: {task.content}\nDue: {task.due or 'No date'}\nPriority: {priority_label(task.priority)}\nLabels: {', '.join(task.labels) if task.labels else 'None'}\nDescription: {task.description or 'None'}")


@app.command()
def recap(
    days: int = typer.Option(1, "--days", help="Lookback window in days"),
    json_output: bool = typer.Option(False, "--json", help="Output JSON"),
    include_active: bool = typer.Option(True, "--include-active/--no-include-active"),
):
    service = _service()
    summary = build_recap(service, days=days, include_active=include_active, use_llm=True)
    if json_output:
        typer.echo(json.dumps(summary, indent=2))
    else:
        if summary.get("summary"):
            typer.echo(summary["summary"])
        else:
            typer.echo("Summary not available (no Gemini key).")


if __name__ == "__main__":
    app()
