"""Shared Todoist client wrapper with typed helpers."""

from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timedelta, timezone
from typing import Dict, Iterable, List, Optional

from todoist_api_python.api import Task, TodoistAPI

from .config import TodoistConfig, load_config


@dataclass
class TaskData:
    id: str
    content: str
    description: str
    project_id: Optional[str]
    section_id: Optional[str]
    labels: List[str]
    priority: int
    due: Optional[str]
    url: Optional[str]
    completed: bool = False

    @classmethod
    def from_task(cls, task: Task, completed: bool = False) -> "TaskData":
        return cls(
            id=task.id,
            content=task.content,
            description=getattr(task, "description", "") or "",
            project_id=getattr(task, "project_id", None),
            section_id=getattr(task, "section_id", None),
            labels=list(getattr(task, "labels", []) or []),
            priority=getattr(task, "priority", 1),
            due=getattr(task.due, "string", None) if getattr(task, "due", None) else None,
            url=getattr(task, "url", None),
            completed=completed,
        )

    def to_dict(self) -> Dict:
        return asdict(self)


class TodoistService:
    """High-level wrapper around the Todoist API."""

    def __init__(self, config: Optional[TodoistConfig] = None):
        self.config = config or load_config()
        self.api = TodoistAPI(self.config.api_key)

    def list_projects(self):
        return self.api.get_projects()

    def find_project_id(self, name: str) -> Optional[str]:
        for project in self.api.get_projects():
            if project.name.lower() == name.lower():
                return project.id
        return None

    def list_tasks(
        self,
        *,
        project_id: Optional[str] = None,
        filter_query: Optional[str] = None,
        label: Optional[str] = None,
    ) -> List[TaskData]:
        tasks: List[Task] = self.api.get_tasks(
            project_id=project_id,
            label=label,
            filter=filter_query,
        )
        return [TaskData.from_task(task) for task in tasks]

    def list_completed_tasks(
        self,
        *,
        since: datetime,
        until: datetime,
        project_id: Optional[str] = None,
        limit: Optional[int] = 200,
    ) -> List[TaskData]:
        items: List[TaskData] = []
        for page in self.api.get_completed_tasks_by_completion_date(
            since=since,
            until=until,
            filter_query=None,
            filter_lang=None,
            limit=limit,
        ):
            for task in page:
                if project_id and getattr(task, "project_id", None) != project_id:
                    continue
                items.append(TaskData.from_task(task, completed=True))
        return items

    def add_task(
        self,
        *,
        content: str,
        due: Optional[str] = None,
        priority: int = 1,
        project_id: Optional[str] = None,
        labels: Optional[List[str]] = None,
        description: Optional[str] = None,
    ) -> TaskData:
        task = self.api.add_task(
            content=content,
            priority=priority,
            project_id=project_id,
            labels=labels,
            description=description,
            due_string=due,
        )
        return TaskData.from_task(task)

    def update_task(
        self,
        task_id: str,
        *,
        content: Optional[str] = None,
        due: Optional[str] = None,
        priority: Optional[int] = None,
        labels: Optional[List[str]] = None,
        description: Optional[str] = None,
    ) -> bool:
        kwargs = {}
        if content:
            kwargs["content"] = content
        if due:
            kwargs["due_string"] = due
        if priority:
            kwargs["priority"] = priority
        if labels is not None:
            kwargs["labels"] = labels
        if description is not None:
            kwargs["description"] = description

        if not kwargs:
            raise ValueError("No updates provided")

        return self.api.update_task(task_id=task_id, **kwargs)

    def complete_task(self, task_id: str) -> bool:
        return self.api.complete_task(task_id=task_id)

    def delete_task(self, task_id: str) -> bool:
        return self.api.delete_task(task_id=task_id)

    def get_task(self, task_id: str) -> TaskData:
        task = self.api.get_task(task_id=task_id)
        return TaskData.from_task(task)


def priority_label(priority: int) -> str:
    return {4: "P1 (High)", 3: "P2", 2: "P3", 1: "P4 (Normal)"}.get(priority, "P4")


def today_bounds(days: int = 1) -> tuple[datetime, datetime]:
    now = datetime.now(timezone.utc)
    start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    end = start + timedelta(days=days)
    return start, end


__all__ = ["TodoistService", "TaskData", "priority_label", "today_bounds"]
