"""Configuration helpers for Todoist Toolkit."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

ENV_KEY = "TODOIST_API_KEY"


@dataclass
class TodoistConfig:
    api_key: str


class ConfigError(RuntimeError):
    """Raised when configuration is missing or invalid."""


def _config_paths() -> list[Path]:
    return [
        Path.home() / ".config" / "todoist" / "config.json",
        Path.cwd() / ".env",
        Path.home() / ".env",
    ]


def _load_env_file(path: Path) -> dict:
    """Load key/value pairs from a simple .env file without extra deps."""
    data = {}
    try:
        for line in path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue
            key, value = line.split("=", 1)
            data[key.strip()] = value.strip().strip('"').strip("'")
    except FileNotFoundError:
        return {}
    return data


def _load_json_config(path: Path) -> dict:
    try:
        return json.loads(path.read_text())
    except FileNotFoundError:
        return {}
    except json.JSONDecodeError:
        raise ConfigError(f"Invalid JSON in config file: {path}")


def load_config() -> TodoistConfig:
    """Load Todoist configuration from env or fallback files."""
    api_key = os.environ.get(ENV_KEY)
    if api_key:
        return TodoistConfig(api_key=api_key)

    for path in _config_paths():
        if path.suffix == ".json":
            cfg = _load_json_config(path)
            api_key = cfg.get("api_key") or cfg.get(ENV_KEY)
        else:
            cfg = _load_env_file(path)
            api_key = cfg.get(ENV_KEY)
        if api_key:
            return TodoistConfig(api_key=api_key)

    raise ConfigError(
        "Todoist API key not found. Set TODOIST_API_KEY or add it to ~/.config/todoist/config.json"
    )


__all__ = ["TodoistConfig", "ConfigError", "load_config", "ENV_KEY"]
