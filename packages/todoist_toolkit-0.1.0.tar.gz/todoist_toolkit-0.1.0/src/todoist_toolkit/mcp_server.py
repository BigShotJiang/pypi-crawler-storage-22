"""MCP stdio server exposing Todoist tools."""

from __future__ import annotations

import asyncio
import json
import sys
from typing import Any, Dict, Optional

from .client import TodoistService
from .recap import build_recap


def tool_defs():
    return [
        {
            "name": "todo_list",
            "description": "List active Todoist tasks",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "project": {"type": "string", "description": "Project name"},
                    "filter": {"type": "string", "description": "Todoist filter"},
                    "label": {"type": "string", "description": "Label"},
                },
            },
        },
        {
            "name": "todo_add",
            "description": "Add a Todoist task",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "content": {"type": "string"},
                    "due": {"type": "string"},
                    "priority": {"type": "integer", "default": 1},
                    "project": {"type": "string"},
                    "labels": {"type": "array", "items": {"type": "string"}},
                    "description": {"type": "string"},
                },
                "required": ["content"],
            },
        },
        {
            "name": "todo_update",
            "description": "Update a Todoist task",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "task_id": {"type": "string"},
                    "content": {"type": "string"},
                    "due": {"type": "string"},
                    "priority": {"type": "integer"},
                    "labels": {"type": "array", "items": {"type": "string"}},
                    "description": {"type": "string"},
                },
                "required": ["task_id"],
            },
        },
        {
            "name": "todo_complete",
            "description": "Complete a Todoist task",
            "inputSchema": {
                "type": "object",
                "properties": {"task_id": {"type": "string"}},
                "required": ["task_id"],
            },
        },
        {
            "name": "todo_delete",
            "description": "Delete a Todoist task",
            "inputSchema": {
                "type": "object",
                "properties": {"task_id": {"type": "string"}},
                "required": ["task_id"],
            },
        },
        {
            "name": "todo_get",
            "description": "Fetch a Todoist task",
            "inputSchema": {
                "type": "object",
                "properties": {"task_id": {"type": "string"}},
                "required": ["task_id"],
            },
        },
        {
            "name": "todo_recap",
            "description": "Summarize recent Todoist activity",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "days": {"type": "integer", "default": 1},
                    "include_active": {"type": "boolean", "default": True},
                },
            },
        },
    ]


class MCPServer:
    def __init__(self):
        self.service = TodoistService()

    async def run(self):
        while True:
            line = await asyncio.get_event_loop().run_in_executor(None, sys.stdin.readline)
            if not line:
                break
            try:
                message = json.loads(line)
            except json.JSONDecodeError:
                continue
            response = await self.handle(message)
            if response:
                print(json.dumps(response), flush=True)

    async def handle(self, message: Dict[str, Any]):
        msg_id = message.get("id")
        method = message.get("method")
        params = message.get("params", {})
        if not msg_id:
            return None
        try:
            if method == "initialize":
                return {
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "result": {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {"tools": {}},
                        "serverInfo": {"name": "todoist-toolkit", "version": "0.1.0"},
                    },
                }
            if method == "tools/list":
                return {"jsonrpc": "2.0", "id": msg_id, "result": {"tools": tool_defs()}}
            if method == "tools/call":
                name = params.get("name")
                args = params.get("arguments", {})
                result = await self.call_tool(name, args)
                return {
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "result": {"content": [{"type": "text", "text": json.dumps(result, indent=2)}]},
                }
            if method == "ping":
                return {"jsonrpc": "2.0", "id": msg_id, "result": {}}
            return {"jsonrpc": "2.0", "id": msg_id, "error": {"code": -32601, "message": "Method not found"}}
        except Exception as exc:  # pragma: no cover - defensive
            return {"jsonrpc": "2.0", "id": msg_id, "error": {"code": -32603, "message": str(exc)}}

    async def call_tool(self, name: str, args: Dict[str, Any]):
        if name == "todo_list":
            tasks = self.service.list_tasks(
                project_id=self._project_id(args.get("project")),
                filter_query=args.get("filter"),
                label=args.get("label"),
            )
            return [t.to_dict() for t in tasks]
        if name == "todo_add":
            task = self.service.add_task(
                content=args["content"],
                due=args.get("due"),
                priority=args.get("priority", 1),
                project_id=self._project_id(args.get("project")),
                labels=args.get("labels"),
                description=args.get("description"),
            )
            return task.to_dict()
        if name == "todo_update":
            changed = self.service.update_task(
                args["task_id"],
                content=args.get("content"),
                due=args.get("due"),
                priority=args.get("priority"),
                labels=args.get("labels"),
                description=args.get("description"),
            )
            return {"updated": bool(changed)}
        if name == "todo_complete":
            return {"completed": bool(self.service.complete_task(args["task_id"]))}
        if name == "todo_delete":
            return {"deleted": bool(self.service.delete_task(args["task_id"]))}
        if name == "todo_get":
            return self.service.get_task(args["task_id"]).to_dict()
        if name == "todo_recap":
            summary = build_recap(
                self.service,
                days=int(args.get("days", 1)),
                include_active=bool(args.get("include_active", True)),
                use_llm=True,
            )
            return summary
        raise ValueError(f"Unknown tool: {name}")

    def _project_id(self, name: Optional[str]) -> Optional[str]:
        if not name:
            return None
        return self.service.find_project_id(name)


def main():
    server = MCPServer()
    asyncio.run(server.run())


if __name__ == "__main__":
    main()
