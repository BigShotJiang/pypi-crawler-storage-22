"""Recap helpers for summarizing recent Todoist activity."""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Dict, List, Optional

from .client import TaskData, TodoistService, priority_label, today_bounds
from .summarizer import summarize


def _format_task_line(task: TaskData) -> str:
    due = task.due or "No date"
    prio = priority_label(task.priority)
    label_str = f" [{', '.join(task.labels)}]" if task.labels else ""
    return f"- {task.content} (due: {due}, priority: {prio}){label_str}"


def build_recap(
    service: TodoistService,
    *,
    days: int = 1,
    include_active: bool = True,
    use_llm: bool = True,
) -> Dict:
    since, until = today_bounds(days)
    completed = service.list_completed_tasks(since=since, until=until)
    active: List[TaskData] = service.list_tasks(filter_query=None) if include_active else []

    overdue = [t for t in active if t.due and _is_past_due(t.due)]
    due_soon = [t for t in active if t.due and not _is_past_due(t.due)]

    recap = {
        "completed": [t.to_dict() for t in completed],
        "overdue": [t.to_dict() for t in overdue],
        "upcoming": [t.to_dict() for t in due_soon],
    }

    if use_llm:
        prompt = _recap_prompt(completed, overdue, due_soon, days)
        summary = summarize(prompt)
        if summary:
            recap["summary"] = summary

    return recap


def _is_past_due(due_str: str) -> bool:
    try:
        # Todoist returns natural language strings; rough parse by ISO first.
        return datetime.fromisoformat(due_str) < datetime.utcnow()
    except ValueError:
        return False


def _recap_prompt(
    completed: List[TaskData], overdue: List[TaskData], upcoming: List[TaskData], days: int
) -> str:
    lines = [
        "You are summarizing Todoist activity for the user.",
        f"Time window: last {days} day(s).",
        "Completed tasks:",
    ]
    if completed:
        lines.extend(_format_task_line(t) for t in completed)
    else:
        lines.append("- None")
    lines.append("Overdue tasks:")
    if overdue:
        lines.extend(_format_task_line(t) for t in overdue)
    else:
        lines.append("- None")
    lines.append("Upcoming tasks:")
    if upcoming:
        lines.extend(_format_task_line(t) for t in upcoming)
    else:
        lines.append("- None")
    lines.append("Summarize concisely with bullet points and next steps.")
    return "\n".join(lines)


__all__ = ["build_recap"]
