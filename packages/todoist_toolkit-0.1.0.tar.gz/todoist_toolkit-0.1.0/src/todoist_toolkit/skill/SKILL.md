---
name: todoist
description: Todoist CLI + MCP tools for adding, listing, and recapping tasks with Gemini summaries.
---

## Overview
Provides Todoist task management as a Claude Skill and MCP server. Supports add/list/update/complete/delete/get plus recap summaries.

## MCP Config
```json
{
  "mcpServers": {
    "todoist": {
      "command": "python3",
      "args": ["/home/coolhand/packages/todoist-toolkit/src/todoist_toolkit/mcp_server.py"],
      "env": {
        "TODOIST_API_KEY": "<token>",
        "GOOGLE_API_KEY": "<optional>"
      }
    }
  }
}
```

## Tools
- `todo_list` (project, label, filter)
- `todo_add` (content, due, priority, project, labels, description)
- `todo_update` (task_id, content, due, priority, labels, description)
- `todo_complete` (task_id)
- `todo_delete` (task_id)
- `todo_get` (task_id)
- `todo_recap` (days, include_active)

## CLI
`todo` (alias `todoist`) exposes the same operations plus human-readable output and `--json` for scripting.

## Environment
- `TODOIST_API_KEY` (required)
- `GOOGLE_API_KEY` (optional; enables Gemini summaries for `todo recap`)
