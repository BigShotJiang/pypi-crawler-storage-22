"""Summarization utilities (Gemini optional)."""

from __future__ import annotations

import os
from typing import Optional

try:
    import google.generativeai as genai
except ImportError:  # pragma: no cover - optional dependency
    genai = None


def summarize_with_gemini(prompt: str, model: str = "gemini-1.5-flash") -> Optional[str]:
    if not genai:
        return None
    api_key = os.environ.get("GOOGLE_API_KEY")
    if not api_key:
        return None
    genai.configure(api_key=api_key)
    llm = genai.GenerativeModel(model)
    resp = llm.generate_content(prompt)
    return getattr(resp, "text", None)


def summarize(prompt: str) -> Optional[str]:
    return summarize_with_gemini(prompt)


__all__ = ["summarize", "summarize_with_gemini"]
