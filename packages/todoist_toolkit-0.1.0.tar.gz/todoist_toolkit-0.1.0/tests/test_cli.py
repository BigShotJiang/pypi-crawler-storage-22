import json
from types import SimpleNamespace

from typer.testing import CliRunner

from todoist_toolkit import cli
from todoist_toolkit.client import TodoistService
from todoist_toolkit.config import TodoistConfig


class DummyAPI:
    def __init__(self):
        self.called = {}

    def get_projects(self):
        return [SimpleNamespace(id="p1", name="Work")]

    def get_tasks(self, **kwargs):
        self.called["get_tasks"] = kwargs
        return [
            SimpleNamespace(
                id="1",
                content="Task one",
                description="",
                project_id="p1",
                section_id=None,
                labels=["work"],
                priority=1,
                due=SimpleNamespace(string="2025-12-20T10:00:00"),
                url=None,
            )
        ]

    def add_task(self, **kwargs):
        self.called["add_task"] = kwargs
        return self.get_tasks()[0]

    def update_task(self, **kwargs):
        self.called["update_task"] = kwargs
        return True

    def complete_task(self, task_id: str):
        self.called["complete_task"] = task_id
        return True

    def delete_task(self, task_id: str):
        self.called["delete_task"] = task_id
        return True

    def get_task(self, task_id: str):
        self.called["get_task"] = task_id
        return self.get_tasks()[0]


def install_dummy_service(monkeypatch):
    service = TodoistService(TodoistConfig(api_key="fake"))
    monkeypatch.setattr(service, "api", DummyAPI())
    monkeypatch.setattr(cli, "_service", lambda: service)
    monkeypatch.setattr(cli, "_service_instance", service)
    return service


def test_list_json(monkeypatch):
    install_dummy_service(monkeypatch)
    runner = CliRunner()
    result = runner.invoke(cli.app, ["list", "--json"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert data[0]["id"] == "1"


def test_add(monkeypatch):
    service = install_dummy_service(monkeypatch)
    runner = CliRunner()
    result = runner.invoke(cli.app, ["add", "Do it", "--json"])
    assert result.exit_code == 0
    assert service.api.called["add_task"]["content"] == "Do it"
