from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

import pytest

from todoist_toolkit.client import TaskData, TodoistService


class DummyAPI:
    def __init__(self):
        self.tasks = [
            SimpleNamespace(
                id="1",
                content="Task one",
                description="",
                project_id="p1",
                section_id=None,
                labels=["work"],
                priority=4,
                due=SimpleNamespace(string="2025-12-20T10:00:00"),
                url=None,
            )
        ]

    def get_projects(self):
        return [SimpleNamespace(id="p1", name="Work")]

    def get_tasks(self, **kwargs):
        return self.tasks

    def get_completed_tasks_by_completion_date(self, **kwargs):
        return [
            [
                SimpleNamespace(
                    id="2",
                    content="Finished",
                    description="",
                    project_id="p1",
                    section_id=None,
                    labels=[],
                    priority=1,
                    due=SimpleNamespace(string="2025-12-19"),
                    url=None,
                )
            ]
        ]

    def add_task(self, **kwargs):
        return self.tasks[0]

    def update_task(self, **kwargs):
        return True

    def complete_task(self, task_id: str):
        return True

    def delete_task(self, task_id: str):
        return True

    def get_task(self, task_id: str):
        return self.tasks[0]


class DummyConfig:
    def __init__(self):
        self.api_key = "fake"


@pytest.fixture
def service(monkeypatch):
    svc = TodoistService(DummyConfig())
    monkeypatch.setattr(svc, "api", DummyAPI())
    return svc


def test_list_tasks(service):
    tasks = service.list_tasks()
    assert len(tasks) == 1
    assert isinstance(tasks[0], TaskData)


def test_completed_tasks(service):
    since = datetime.now(timezone.utc) - timedelta(days=1)
    until = datetime.now(timezone.utc)
    tasks = service.list_completed_tasks(since=since, until=until)
    assert tasks[0].completed is True


def test_find_project_id(service):
    assert service.find_project_id("Work") == "p1"
    assert service.find_project_id("Missing") is None
