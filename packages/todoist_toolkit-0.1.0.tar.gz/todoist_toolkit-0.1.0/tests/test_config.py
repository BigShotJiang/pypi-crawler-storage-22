import os
from pathlib import Path

import pytest

from todoist_toolkit.config import ConfigError, load_config


def test_load_config_from_env(monkeypatch):
    monkeypatch.setenv("TODOIST_API_KEY", "abc")
    cfg = load_config()
    assert cfg.api_key == "abc"


def test_load_config_missing(monkeypatch, tmp_path):
    monkeypatch.delenv("TODOIST_API_KEY", raising=False)
    monkeypatch.chdir(tmp_path)
    with pytest.raises(ConfigError):
        load_config()


def test_load_config_from_env_file(monkeypatch, tmp_path):
    env_file = tmp_path / ".env"
    env_file.write_text("TODOIST_API_KEY=from_env_file")
    monkeypatch.delenv("TODOIST_API_KEY", raising=False)
    monkeypatch.chdir(tmp_path)
    cfg = load_config()
    assert cfg.api_key == "from_env_file"
