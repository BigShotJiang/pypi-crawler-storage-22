"""
toggletest - ToggleTest Python SDK with WASM-based local evaluation

This is the package entry point. It re-exports only the types and classes
that SDK consumers need. Internal implementation details (WasmEngine,
RulesStore, SseConnection, EventBuffer) are NOT exported.

Usage:
    from toggletest import ToggleTestClient
    from toggletest import EvalContext, EvalResults, FlagResult, TestResult

    client = ToggleTestClient(
        api_key="tt_...",
        base_url="http://localhost:3001",
        environment="production",
    )
    client.start()

    if client.is_enabled("dark-mode", user_id="user-123"):
        ...

    client.close()
"""

# -- Main client class --
from .client import ToggleTestClient

# -- Configuration and context types --
from .types import ToggleTestConfig, EvalContext

# -- Evaluation result types --
from .types import FlagResult, TestResult, EvalResults

# -- Event tracking types --
from .types import SdkEvent

# -- Listener types --
from .types import RulesUpdateListener

__all__ = [
    # Client
    "ToggleTestClient",
    # Config / context
    "ToggleTestConfig",
    "EvalContext",
    # Evaluation results
    "FlagResult",
    "TestResult",
    "EvalResults",
    # Events
    "SdkEvent",
    # Listeners
    "RulesUpdateListener",
]
