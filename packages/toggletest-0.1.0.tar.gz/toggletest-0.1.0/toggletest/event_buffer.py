"""
event_buffer.py - Batched event tracking with evaluation_reason support

Architecture overview:
  The event buffer collects analytics events (flag evaluations, variant
  assignments, conversions) and sends them to the server in batches.

  Key changes from the old SDK:
    - Events now include an ``evaluation_reason`` field that comes from the
      WASM evaluation result.  This lets the backend know *why* a flag was
      enabled or which rule matched, enabling richer analytics.
    - Auth uses x-api-key header instead of Bearer token.
    - Optional x-environment header for multi-environment support.

  Batching strategy:
    - Events are flushed every N seconds (default: 10s).
    - If the buffer reaches a max size (default: 100), it flushes immediately.
    - On flush failure (network error or non-2xx), events are re-queued for
      retry on the next flush cycle.
    - On close(), a final flush is attempted to avoid data loss.

Thread-safety:
  The event list is guarded by a ``threading.Lock``.  The periodic flush
  runs on a background daemon timer thread.
"""

from __future__ import annotations

import logging
import threading
from dataclasses import asdict
from typing import Dict, List, Optional

import httpx

from .types import SdkEvent

logger = logging.getLogger("toggletest")

# Default interval between automatic flushes (seconds).
DEFAULT_FLUSH_INTERVAL = 10.0

# Default maximum number of events before an immediate flush is triggered.
DEFAULT_MAX_BATCH_SIZE = 100


class EventBuffer:
    """Batched event buffer that periodically flushes to the server.

    Events are accumulated in-memory and sent via POST /sdk/events.
    The buffer handles retries by re-queuing failed batches.
    """

    MAX_BUFFER_SIZE = 10000

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        environment: Optional[str] = None,
        flush_interval: float = DEFAULT_FLUSH_INTERVAL,
        max_batch_size: int = DEFAULT_MAX_BATCH_SIZE,
    ) -> None:
        """Initialize the event buffer.

        No network calls are made in the constructor. The flush timer is
        started by ``start()``.

        Args:
            base_url:       Base URL of the ToggleTest API.
            api_key:        SDK API key sent as x-api-key header.
            environment:    Optional environment identifier.
            flush_interval: Seconds between automatic flushes.
            max_batch_size: Max events before triggering an immediate flush.
        """
        self._base_url = base_url
        self._api_key = api_key
        self._environment = environment
        self._flush_interval = flush_interval
        self._max_batch_size = max_batch_size

        # -- Mutable state (guarded by _lock) --
        self._lock = threading.Lock()
        self._events: List[SdkEvent] = []
        self._drop_warned = False

        # -- Shared HTTP client (set via set_http_client) --
        self._http_client: Optional[httpx.Client] = None

        # -- Timer state --
        self._timer: Optional[threading.Timer] = None
        self._running = False

    def set_http_client(self, client: httpx.Client) -> None:
        """Assign a shared httpx.Client for connection reuse."""
        self._http_client = client

    # ------------------------------------------------------------------
    # Header helpers
    # ------------------------------------------------------------------

    def _build_headers(self) -> Dict[str, str]:
        """Build the common headers used for event submission.

        Uses x-api-key for auth (not Bearer token) to match the new SDK
        protocol.
        """
        headers: Dict[str, str] = {
            "Content-Type": "application/json",
            "x-api-key": self._api_key,
        }
        if self._environment:
            headers["x-environment"] = self._environment
        return headers

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Start the periodic flush timer.

        Safe to call multiple times (no-op if already running).
        """
        self._running = True
        self._schedule_flush()

    def stop(self) -> None:
        """Stop the periodic flush timer and perform a final flush.

        Called during ``client.close()`` to avoid losing buffered events.
        The final flush is best-effort: if it fails, events are lost
        (acceptable on shutdown).
        """
        self._running = False
        if self._timer is not None:
            self._timer.cancel()
            self._timer = None

        # Final flush attempt.
        self.flush()

    # ------------------------------------------------------------------
    # Event ingestion
    # ------------------------------------------------------------------

    def push(self, event: SdkEvent) -> None:
        """Add an event to the buffer.

        If the buffer reaches ``max_batch_size``, an immediate flush is
        triggered.  If the buffer exceeds ``MAX_BUFFER_SIZE``, the oldest
        events are dropped.

        Args:
            event: The analytics event to buffer.
        """
        with self._lock:
            while len(self._events) >= self.MAX_BUFFER_SIZE:
                self._events.pop(0)  # drop oldest
                if not self._drop_warned:
                    logger.warning('[ToggleTest] Event buffer full. Dropping oldest events.')
                    self._drop_warned = True

            self._events.append(event)
            if len(self._events) >= self._max_batch_size:
                self._do_flush()

    # ------------------------------------------------------------------
    # Flushing
    # ------------------------------------------------------------------

    def flush(self) -> None:
        """Flush all buffered events to the server.

        Thread-safe.  Acquires the lock, drains the buffer, and sends
        events in a single POST request.  On failure, events are re-queued
        at the front of the buffer for retry on the next flush cycle.
        """
        with self._lock:
            self._do_flush()

    def _do_flush(self) -> None:
        """Internal flush implementation.  Caller must hold ``_lock``.

        Atomically drains the current buffer, sends the batch to the
        server, and re-queues on failure.
        """
        if not self._events:
            return

        # Drain the buffer.
        batch = list(self._events)
        self._events.clear()

        # Build the payload, stripping None values for cleaner JSON.
        payload = {
            "events": [
                {k: v for k, v in asdict(e).items() if v is not None}
                for e in batch
            ]
        }

        try:
            client = self._http_client or httpx.Client(timeout=10.0)
            resp = client.post(
                f"{self._base_url}/sdk/events",
                json=payload,
                headers=self._build_headers(),
                timeout=10.0,
            )
            if resp.status_code == 429:
                # Evaluation limit reached — drop events, don't retry.
                # The WASM engine still evaluates flags locally; only tracking is affected.
                logger.warning("Evaluation limit reached. Events dropped.")
            elif resp.status_code != 200:
                # Other server error — re-queue for retry.
                self._events = batch + self._events
        except Exception:
            # Network error (e.g. offline).  Re-queue for retry.
            logger.debug("Failed to flush events, re-queueing")
            self._events = batch + self._events

    # ------------------------------------------------------------------
    # Timer management
    # ------------------------------------------------------------------

    def _schedule_flush(self) -> None:
        """Schedule the next periodic flush.

        Uses ``threading.Timer`` so the flush runs on a separate daemon
        thread after the configured interval.
        """
        if not self._running:
            return

        self._timer = threading.Timer(self._flush_interval, self._timer_flush)
        self._timer.daemon = True
        self._timer.start()

    def _timer_flush(self) -> None:
        """Called by the timer thread. Flushes and reschedules."""
        self.flush()
        self._schedule_flush()
