"""
types.py - Type definitions for the ToggleTest WASM-based SDK

This SDK evaluates feature flags and A/B tests locally using a WASM engine.
The server provides a compiled rules JSON blob and a WASM evaluator binary.
All flag/test evaluation happens client-side with zero network latency.

Mirrors the TypeScript SDK's type definitions so both SDKs share the same
data contract with the server and WASM evaluator.
"""

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Literal, Optional


# ---------------------------------------------------------------------------
# Client configuration
# ---------------------------------------------------------------------------


@dataclass
class ToggleTestConfig:
    """Configuration for the ToggleTest client.

    Attributes:
        api_key:     SDK API key, typically prefixed with "tt_".
                     Sent as the x-api-key header on all requests.
        base_url:    Base URL of the ToggleTest API
                     (e.g. "http://localhost:3001").
        environment: Optional environment identifier (e.g. "production").
                     Sent as x-environment header so the server scopes
                     rules to the correct environment.
        on_ready:    Called once the WASM engine is loaded and rules are fetched.
        on_error:    Called when a non-fatal error occurs (SSE disconnect, etc).
    """

    api_key: str
    base_url: str
    environment: Optional[str] = None
    on_ready: Optional[Callable[[], None]] = None
    on_error: Optional[Callable[[Exception], None]] = None


# ---------------------------------------------------------------------------
# WASM evaluation context
# ---------------------------------------------------------------------------


@dataclass
class EvalContext:
    """Context passed into every evaluation call.

    The WASM engine uses this to match targeting rules and compute
    bucket assignments.

    Attributes:
        user_id:    Unique identifier for the end-user being evaluated.
        attributes: Arbitrary user/request attributes used in targeting rules.
                    Example: {"plan": "pro", "country": "US", "beta": True}
    """

    user_id: str
    attributes: Optional[Dict[str, Any]] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# WASM evaluation results
# ---------------------------------------------------------------------------


@dataclass
class FlagResult:
    """Result of evaluating a single feature flag.

    Attributes:
        value:   The evaluated value of the flag (bool, str, number, or dict).
        reason:  Human-readable reason for the result
                 (e.g. "rule_match", "default", "disabled", "not_found").
        rule_id: The ID of the rule that matched, if any.
    """

    value: Any
    reason: str
    rule_id: Optional[str] = None


@dataclass
class TestResult:
    """Result of evaluating a single A/B test assignment.

    Attributes:
        variant: The variant the user was assigned to
                 (e.g. "control", "variant_a").
        bucket:  The deterministic bucket value (0-9999) computed from
                 user_id + test key. Ensures consistent assignment
                 without server-side state.
    """

    variant: str
    bucket: int


@dataclass
class EvalResults:
    """Full evaluation result returned by the WASM engine.

    Contains every flag and every test evaluated against the provided
    context.

    Attributes:
        flags: Map of flag key -> evaluation result.
        tests: Map of test key -> variant assignment.
    """

    flags: Dict[str, FlagResult]
    tests: Dict[str, TestResult]


# ---------------------------------------------------------------------------
# Listener type alias
# ---------------------------------------------------------------------------

# Called whenever rules are updated. Receives the new version hash (ETag).
RulesUpdateListener = Callable[[str], None]


# ---------------------------------------------------------------------------
# Event tracking types
# ---------------------------------------------------------------------------


@dataclass
class SdkEvent:
    """An analytics event sent to the ToggleTest backend in batches.

    Includes an evaluation_reason field so the backend knows *why* the
    event occurred (e.g. which rule matched, or which variant was assigned).

    Attributes:
        event_type:        The kind of event being tracked.
        end_user_id:       The end-user this event is about.
        flag_key:          The flag key relevant to this event, if any.
        test_key:          The A/B test key relevant to this event, if any.
        variant_name:      The variant name for assignment/conversion events.
        evaluation_reason: The reason the evaluation produced this result.
                           Comes directly from the WASM engine.
        metadata:          Arbitrary metadata attached to the event.
    """

    event_type: Literal["flag_evaluation", "variant_assignment", "conversion"]
    end_user_id: str
    flag_key: Optional[str] = None
    test_key: Optional[str] = None
    variant_name: Optional[str] = None
    evaluation_reason: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
