"""TokenCrush - LLM token optimization CLI."""

__version__ = "0.1.0"
