"""HTTP client and LiteLLM response metadata capture utilities.

This module provides a reusable HTTP client class that extends httpx.Client with
automatic LiteLLM cost tracking and Azure storage integration.

Features:
- Captures x-litellm-response-cost and x-request-id headers
- Logs cost data automatically
- Uploads cost tracking to Azure Blob Storage
- Fully compatible with httpx.Client API
"""

import os
import httpx
from typing import Optional
from datetime import datetime


class LiteLLMHttpClient(httpx.Client):
    """HTTP client with automatic LiteLLM cost tracking and Azure storage integration.
    
    This client extends httpx.Client and automatically captures LiteLLM response costs,
    logs them, and optionally uploads to Azure Blob Storage.
    
    Args:
        azure_storage: Optional AzureStorage instance for cost tracking.
        logger: Optional logger instance for logging. If None, uses get_logger().
        timeout: Request timeout in seconds (default: 60.0).
        **kwargs: Additional arguments passed to httpx.Client.
    
    Example:
        >>> client = LiteLLMHttpClient()
        >>> response = client.post("https://api.example.com", json={...})
        
        >>> # With custom config
        >>> from src.helpers.logger import get_logger
        >>> from src.services.azure_storage import get_azure_storage
        >>> client = LiteLLMHttpClient(
        ...     azure_storage=get_azure_storage(),
        ...     logger=get_logger(),
        ...     timeout=120.0
        ... )
    """
    
    def __init__(
        self,
        azure_storage=None,
        logger=None,
        timeout: float = 60.0,
        **kwargs
    ):
        self._azure_storage = azure_storage
        self._logger = logger
        
        # Initialize parent httpx.Client with event hook
        super().__init__(
            timeout=timeout,
            event_hooks={"response": [self._capture_litellm_headers]},
            follow_redirects=True,
            **kwargs
        )
    
    def _capture_litellm_headers(self, response: httpx.Response) -> None:
        """Capture LiteLLM headers from response and track costs.
        
        Args:
            response: The HTTP response object.
        
        Side Effects:
            Logs cost data and uploads to Azure if configured.
            Streaming responses (text/event-stream) are ignored.
        """
        # Ignore streaming responses
        if "text/event-stream" in response.headers.get("content-type", ""):
            return

        cost = response.headers.get("x-litellm-response-cost")
        request_id = response.headers.get("x-request-id")

        # LiteLLM only sets cost on the FINAL response
        if cost is None:
            return

        self._logger.info(f"LiteLLM cost captured: {cost} (request_id: {request_id})")

        print("=== LITELLM COST ===")
        print(f"cost: {cost}")
        print(f"request_id: {request_id}")
        print(f"status_code: {response.status_code}")
        
        # Upload cost to Azure Blob Storage
        if self._azure_storage:
            try:
                model = os.getenv("MODEL", "unknown")
                cost_entry = {
                    "timestamp": datetime.utcnow().isoformat() + "Z",
                    "cost": cost,
                    "request_id": request_id,
                    "status_code": response.status_code,
                    "model": model,
                }
                self._azure_storage.append_to_azure(
                    content=cost_entry,
                    blob_name="cost.log"
                )
            except Exception as e:
                self._logger.debug(f"Failed to upload cost to Azure: {e}")
