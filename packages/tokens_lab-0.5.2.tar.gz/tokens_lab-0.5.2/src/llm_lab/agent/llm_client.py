"""Thin wrapper around the OpenAI client for chat and response generation."""

from __future__ import annotations

from typing import Any

import httpx
from openai import OpenAI


class LLMClient:
    """OpenAI-compatible LLM client with configurable transport.

    Args:
        api_key: API key for authentication.
        base_url: Base URL of the LLM endpoint.
        model_name: Default model identifier for requests.
        timeout: Request timeout in seconds.
        max_retries: Number of automatic retries on transient failures.
        http_client: Optional pre-configured ``httpx.Client`` (e.g. from
            :func:`~llm_lab.agent.litellm_http.make_litellm_http_client`).
    """

    def __init__(
        self,
        api_key: str,
        base_url: str,
        model_name: str,
        timeout: float = 60.0,
        max_retries: int = 2,
        http_client: httpx.Client | None = None,
    ) -> None:
        try:
            self.client = OpenAI(
                api_key=api_key,
                base_url=base_url,
                timeout=timeout,
                max_retries=max_retries,
                http_client=http_client,
            )
            self.model_name = model_name
        except Exception as e:
            raise RuntimeError(f"Failed to initialize LLM client: {e}") from e

    def complete_chat(
        self,
        prompt: list[dict[str, Any]],
        temperature: float = 0.7,
        reasoning: dict[str, Any] | None = None,
    ) -> str:
        """Send a chat-completion request and return the assistant's reply.

        Args:
            prompt: List of message dicts (OpenAI chat format).
            temperature: Sampling temperature (0.0–2.0).
            reasoning: Optional reasoning configuration dict (e.g.
                ``{"effort": "high"}``).  Passed directly to the API
                when provided.

        Returns:
            The text content of the first response choice.
        """
        try:
            kwargs: dict[str, Any] = dict(
                model=self.model_name,
                messages=prompt,
                temperature=temperature,
            )
            if reasoning is not None:
                kwargs["reasoning"] = reasoning
            response = self.client.chat.completions.create(**kwargs)
            return response.choices[0].message.content
        except Exception as e:
            raise RuntimeError(f"LLM request failed: {e}") from e

    def generate_response(
        self,
        prompt: str,
        reasoning: dict[str, Any] | None = None,
    ) -> str:
        """Generate a text response using the *responses* API.

        Args:
            prompt: User prompt string.
            reasoning: Optional reasoning configuration dict (e.g.
                ``{"effort": "high"}``).  Passed directly to the API
                when provided.

        Returns:
            The generated output text.
        """
        try:
            kwargs: dict[str, Any] = dict(
                model=self.model_name,
                input=prompt,
            )
            if reasoning is not None:
                kwargs["reasoning"] = reasoning
            response = self.client.responses.create(**kwargs)
            return response.output_text
        except Exception as e:
            raise RuntimeError(f"LLM request failed: {e}") from e
