from azure.storage.blob import BlobServiceClient

class Azure:
    def __init__(self, conn_string, account_name=None, account_key=None):
        self.conn_string = conn_string
        self.account_name = account_name
        self.account_key = account_key
        self.blob_service_client = self.get_blob_service_client()

    def get_blob_service_client(self):
        """Create Azure Blob Service Client using environment credentials.
        
        Returns:
            BlobServiceClient if configured, None otherwise.
        """
        try:
            if self.conn_string:
                return BlobServiceClient.from_connection_string(self.conn_string)
            
            if self.account_name and self.account_key:
                account_url = f"https://{self.account_name}.blob.core.windows.net"
                return BlobServiceClient(account_url=account_url, credential=self.account_key)
            
            return None
        except Exception as e:
            return None