"""Azure Blob Storage utilities for LLM cost tracking and log uploads."""

import json
import logging
from typing import Any, Optional, Union
from datetime import datetime
from azure.storage.blob import ContentSettings

from .azure import Azure

class AzureStorage(Azure):
    def __init__(self, conn_string, container_name, account_name=None, account_key=None, logger=None):
        super().__init__(conn_string=conn_string, account_name=account_name, account_key=account_key)
        self.container_name = container_name
        self.logger = logger or logging.getLogger(__name__)
        self.container_client = self.get_container_client()

    def get_container_client(self):
        return self.blob_service_client.get_container_client(
            self.container_name
        )

    def get_blob_client(self, blob_name):
        blob_client = self.blob_service_client.get_blob_client(
            container=self.container_name, 
            blob=blob_name
        )

        return blob_client
    

    def upload_to_blob(
        self,
        blob_name: str,
        data: bytes,
        content_type: str = "application/octet-stream",
    ) -> bool:
        """Upload data to a blob in Azure Blob Storage, creating the container if needed.

        Args:
            blob_name: Target blob path.
            data: Raw bytes to upload.
            content_type: MIME type for the blob.

        Returns:
            True if uploaded successfully.
        """
        try:
            # Ensure container exists
            try:
                if not self.container_client.exists():
                    self.container_client.create_container()
            except Exception:
                pass

            blob_client = self.get_blob_client(blob_name)
            blob_client.upload_blob(
                data,
                overwrite=True,
                content_settings=ContentSettings(content_type=content_type),
            )
            return True

        except Exception as e:
            self.logger.error(f"Failed to upload blob {blob_name}: {str(e)}", exc_info=True)
            return False

    def append_to_azure(
        self,
        content: Union[str, dict, Any],
        blob_name: str,
    ) -> bool:
        """Append JSON-serializable content as a new line to a blob in Azure.

        Args:
            content: Data to append (will be JSON-serialized).
            blob_name: Target blob path.

        Returns:
            True if saved successfully.
        """
        try:
            self.logger.info(f"Appending data to Azure blob {blob_name}: {content}")
            json_line = json.dumps(content, ensure_ascii=False) + "\n"

            # Download existing content and append, or start fresh
            try:
                existing_data = self.get_blob_client(blob_name).download_blob().readall()
                new_data = existing_data + json_line.encode('utf-8')
            except Exception:
                new_data = json_line.encode('utf-8')

            success = self.upload_to_blob(blob_name, new_data, content_type="application/x-ndjson")
            if success:
                self.logger.info(f"Successfully appended to Azure blob {blob_name}")
            return success

        except Exception as e:
            self.logger.error(f"Failed to append to Azure blob {blob_name}: {str(e)}", exc_info=True)
            return False

    def retrieve_from_azure(self, blob_name):
        blob_client = self.get_blob_client(blob_name)

        if not blob_client.exists():
            return None
        
        data = blob_client.download_blob().readall().decode('utf-8')
        return data
            
