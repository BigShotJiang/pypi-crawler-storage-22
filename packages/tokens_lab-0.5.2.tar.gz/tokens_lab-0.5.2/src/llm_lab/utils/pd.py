import pandas as pd
from io import BytesIO



def load_excel_from_bytes(bytes_data: bytes) -> pd.DataFrame:
    try:
        return pd.read_excel(BytesIO(bytes_data), engine="openpyxl")
    except:
        raise