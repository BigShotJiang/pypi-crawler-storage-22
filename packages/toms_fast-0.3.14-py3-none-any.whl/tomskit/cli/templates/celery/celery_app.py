"""
Celery app template
Template for generating celery_app.py file.
"""

TEMPLATE = '''"""
{project_name} Celery 应用入口

此文件是 Celery worker 进程的入口点，用于创建和配置 Celery 应用实例。

注意：
- Celery worker 中使用的数据库连接池会在 worker 启动时自动创建，无需在此处创建
- 任务导入应在 ext_celery.py 的 init_worker() 函数中配置
- 此模块级别的 celery_app 实例会被 Celery worker 自动导入使用
"""

import os
import logging
    
from tomskit.celery import AsyncCelery


def create_celery_app() -> AsyncCelery:
    """
    创建并初始化 Celery 应用实例

    初始化流程：
    1. 初始化日志系统
    2. 初始化 Celery 应用（worker 模式）

    Returns:
        AsyncCelery: 配置完成的 Celery 应用实例
    """

    from tomskit.logger import configure_logging
    from tomskit.logger import ContextField
    from tomskit.celery import AsyncRuntime
    from tomskit.celery import task_id_field
    from tomskit.celery.context import set_task_id, clear_task_id
    from configs import app_settings

    logger = logging.getLogger(__name__)

    # 先初始化日志系统，确保后续初始化过程有日志输出
    prefix_field = ContextField(name="prefix", var=None, default="celery")
    configure_logging(app_settings.logger, [task_id_field, prefix_field], app_type="celery")
    
    # 初始化 Celery 应用（worker 模式，app=None）
    from extensions.ext_celery import init_app as init_celery
    celery_app: AsyncCelery = init_celery()

    def worker_init(**kwargs):
        # 在 worker 初始化时，重新配置日志系统，确保每个 worker 子进程都有独立的日志输出
        # 因为 worker 子进程会继承父进程的日志系统，如果父进程的日志系统没有配置，会导致子进程的日志输出不正常
        configure_logging(app_settings.logger, [task_id_field, prefix_field], app_type="celery")
        AsyncRuntime.init(celery_app)
        logger.info(f"Celery worker({os.getpid()}) successfully initialized")
    
    def worker_shutdown(**kwargs):
        AsyncRuntime.shutdown()
        logger.info(f"Celery worker({os.getpid()}) successfully shutdown")

    def task_prerun(**kwargs):
        set_task_id(kwargs['task_id'])
        pass

    def task_postrun(**kwargs):
        clear_task_id()
        pass

    celery_app.register_worker_init_handler(worker_init)
    celery_app.register_worker_shutdown_handler(worker_shutdown)
    celery_app.register_task_prerun_handler(task_prerun)
    celery_app.register_task_postrun_handler(task_postrun)
    
    return celery_app


# Celery worker 会自动导入此模块级别的 celery_app 实例
celery_app = create_celery_app()

__all__ = ["celery_app"]

'''
