"""
Logger Extension Template for tomskit CLI

This template file contains the template for generating ext_logger.py file.
"""

TEMPLATE = '''"""
Logger extension initialization
"""
from typing import Any, Optional, Dict, Tuple
from contextvars import ContextVar

from tomskit.logger import configure_logging
from configs import app_settings


def is_enabled() -> bool:
    """Check if the extension is enabled."""
    return True


def init_app(
    app: Any = None,
):
    """
    Initialize the logger system from app settings.

    Args:
        app: FastAPI application instance (optional, for future use)
    Returns:
        None
    """
    from tomskit.server.context import request_id_field

    configure_logging(app_settings.logger, context_registry=[request_id_field], app_type='fastapi')
'''
