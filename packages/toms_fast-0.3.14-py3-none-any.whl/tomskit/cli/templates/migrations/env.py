"""
Migrations env template
Template for generating migrations/env.py file.
"""

TEMPLATE = '''"""
"""
Alembic {project_name} 环境配置文件, 用于数据库迁移
"""

import sys
import logging
from pathlib import Path

from sqlalchemy import pool
from sqlalchemy.engine import Connection
from sqlalchemy import create_engine

from alembic import context

# 添加项目根目录到 Python 路径
# migrations 在 backend/migrations，backend 在项目根目录下
_project_root = Path(__file__).resolve().parent.parent
if str(_project_root) not in sys.path:
    sys.path.insert(0, str(_project_root))
project_root = _project_root


# 导入应用配置
try:
    from configs import app_settings
except ImportError:
    print("⚠️  警告: 未找到 app_settings 配置")

# 导入数据库配置和模型
try:
    from app.models import Base  # 导入所有模型
    target_metadata = Base.metadata
except ImportError:
    # 如果模型还没有定义，创建一个空的 metadata
    from sqlalchemy import MetaData
    target_metadata = MetaData()
    print("⚠️  警告: 未找到 app.models，使用空的 metadata")

#

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

def setup_logging():
    """配置日志系统：控制台 + 文件，避免用 fileConfig 解析 .ini 时 % 插值导致格式串被当消息打印"""
    logs_dir = project_root / "logs"
    logs_dir.mkdir(exist_ok=True)
    log_file_path = project_root / "logs" / "alembic.log"

    formatter = logging.Formatter(
        fmt="%(levelname)-5.5s [%(asctime)s] [%(name)s] %(message)s",
        datefmt="%H:%M:%S",
    )
    # 控制台
    console = logging.StreamHandler(sys.stderr)
    console.setLevel(logging.INFO)
    console.setFormatter(formatter)
    # 文件
    file_handler = logging.FileHandler(
        log_file_path, mode="a", encoding="utf-8"
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)

    # 只给 root 加 handler，子 logger 会 propagate 上来，避免每条日志写两遍
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    if not any(isinstance(h, logging.StreamHandler) for h in root.handlers):
        root.addHandler(console)
    if not any(
        isinstance(h, logging.FileHandler)
        and getattr(h, "baseFilename", "") == str(log_file_path.resolve())
        for h in root.handlers
    ):
        root.addHandler(file_handler)


# 初始化日志配置
setup_logging()

# other values from the config, defined by the needs of env.py,
# can be acquired:
# my_important_option = config.get_main_option("my_important_option")
# ... etc.


def render_item(type_, object_, autogen_context):
    """
    autogenerate 时把 tomskit.sqlalchemy.types.StringUUID 按数据库方言渲染：
    - PostgreSQL：原生 UUID 类型
    - MySQL/其他：CHAR(36)
    生成的迁移文件不再依赖 tomskit，无需手动加 import。
    """
    if type_ == "type":
        # object_ 是类型实例，type(object_) 才是类型类（StringUUID）
        type_cls = type(object_)
        if type_cls.__name__ == "StringUUID" and "tomskit" in getattr(type_cls, "__module__", ""):
            dialect_name = autogen_context.migration_context.dialect.name
            if dialect_name == "postgresql":
                return "sa.dialects.postgresql.UUID(as_uuid=False)"
            return "sa.CHAR(36)"
    return False


def get_url():

    if app_settings is None:
        raise ValueError("app_settings 配置不可用")
    return app_settings.database.SQLALCHEMY_DATABASE_SYNC_URI


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    url = get_url()
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        render_item=render_item,
    )

    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection: Connection) -> None:
    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        render_item=render_item,
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode."""
    url = get_url()
    
    # 使用同步引擎（Alembic 需要同步连接）
    connectable = create_engine(
        url,
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        do_run_migrations(connection)

    connectable.dispose()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
'''
