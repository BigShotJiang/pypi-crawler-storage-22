# Logger 模块

基于 Python 标准库 `logging` 的日志配置与上下文注入，支持 FastAPI / Celery / Alembic 按类型一键配置、ContextVar 上下文字段、以及可选的异步队列写盘。

## 特性

- **按类型配置**：`app_type` 为 `fastapi` / `celery` / `alembic`，一键配置对应 logger（应用、访问、SQL、Celery tasks/schedule、第三方降噪等）
- **上下文字段**：`ContextField` + `ContextRegistry`，用 ContextVar 向 LogRecord 注入 `trace_id`、`prefix` 等，协程/线程安全
- **异步写盘**：可选 `AsyncQueueHandler`（内存队列 + 后台线程），解耦磁盘 I/O，由 `LOG_ASYNC_ENABLED` 控制
- **配置统一**：`LoggerConfig`（Pydantic Settings），支持环境变量与轮转、格式、级别等

## 快速开始

```python
from tomskit.logger import configure_logging, LoggerConfig

config = LoggerConfig(LOG_DIR="logs", LOG_LEVEL="INFO")
configure_logging(config, app_type="fastapi")

import logging
logger = logging.getLogger(__name__)
logger.info("hello")
```

## 安装与导入

```python
from tomskit.logger import (
    configure_logging,
    LoggerConfig,
    ContextField,
    ContextRegistry,
    ContextFilter,
    AsyncQueueHandler,
    SafeFormatter,
    create_timed_handler,
    FastAPILogging,
    CeleryLogging,
    AlembicLogging,
    LoggingBase,
    AppType,
)
```

## 配置类 LoggerConfig

继承自 Pydantic Settings，支持环境变量。常用字段：

| 分类     | 字段 | 说明 | 默认 |
|----------|------|------|------|
| 基础     | `LOG_PREFIX` | 日志前缀，会添加到每条日志记录中 | `""` |
|          | `LOG_DIR` | 日志目录 | `logs` |
|          | `LOG_NAME` | 应用日志文件名（无扩展名） | `apps` |
|          | `LOG_LEVEL` | 级别 | `INFO` |
|          | `LOG_FORMAT` | 格式，可用 `%(trace_id)s`、`%(prefix)s` 等 | 见 config |
|          | `LOG_USE_UTC` | 是否使用 UTC 时间 | `False` |
|          | `LOG_DATE_FORMAT` | 日期格式 | `%Y-%m-%d %H:%M:%S` |
|          | `LOG_BACKUP_COUNT` | 轮转保留份数，0 不保留 | `0` |
|          | `LOG_ROTATE_WHEN` | 轮转单位：`midnight` / D / H / M / S | `midnight` |
|          | `LOG_ROTATE_USE_UTC` | 轮转是否按 UTC 零点 | `False` |
| 异步队列 | `LOG_ASYNC_ENABLED` | 是否用 AsyncQueueHandler 写盘 | `False` |
|          | `LOG_ASYNC_QUEUE_SIZE` | 队列最大长度 | `8192` |
| 访问     | `LOG_ACCESS_NAME` / `LOG_ACCESS_FORMAT` | 访问日志 | `access` / Apache CLF |
| SQL      | `LOG_SQL_ENABLED` / `LOG_SQL_NAME` / `LOG_SQL_LEVEL` | SQL 独立文件 | 默认关 |
| Celery   | `LOG_CELERY_ENABLED` | 是否启用独立 Celery 日志文件 | `False` |
|          | `LOG_CELERY_NAME` / `LOG_CELERY_FORMAT` / `LOG_CELERY_LEVEL` 等 | Celery 日志 | 见 config |
|          | `LOG_CELERY_TASKS_FORMAT` / `LOG_CELERY_SCHEDULE_FORMAT` | tasks / schedule 独立格式 | 见 config |
|          | `LOG_CELERY_ROTATE_WHEN` / `LOG_CELERY_BACKUP_COUNT` | Celery 轮转 | `midnight` / `0` |
| 第三方   | `LOG_THIRD_PARTY_LEVEL` | 第三方库级别（降噪） | `WARNING` |

完整字段见 `tomskit.logger.config.LoggerConfig`。

## 入口函数 configure_logging

```python
def configure_logging(
    settings: LoggerConfig,
    context_registry: Optional[Iterable[ContextField]] = None,
    app_type: AppType = "fastapi",
) -> None
```

- **settings**：日志配置，一般来自环境或 `LoggerConfig()`。
- **context_registry**：上下文字段列表；为 `None` 时使用空 `ContextRegistry([])`，格式占位符缺字段时由 SafeFormatter 的 defaults 兜底，不会报错。
- **app_type**：`"fastapi"` | `"celery"` | `"alembic"`  
  - `fastapi`：应用（root）+ uvicorn.access + 可选 SQL，并配置第三方降噪  
  - `celery`：Celery 通用 + celery + tasks + schedule（各自格式），可选 SQL  
  - `alembic`：仅 root，写入 alembic 日志  

## 上下文字段（ContextVar）

在请求/任务入口设置 ContextVar，通过 `ContextField` 注册后，每条日志会自动带上对应属性（如 `trace_id`、`prefix`），供 `LOG_FORMAT` 中的 `%(trace_id)s`、`%(prefix)s` 使用。

```python
from contextvars import ContextVar
from tomskit.logger import configure_logging, LoggerConfig, ContextField

trace_id_var: ContextVar[str] = ContextVar("trace_id", default="-")
prefix_var: ContextVar[str] = ContextVar("prefix", default="")

fields = [
    ContextField("trace_id", trace_id_var, "-"),
    ContextField("prefix", prefix_var, ""),
]
config = LoggerConfig(LOG_FORMAT="[%(asctime)s] [%(trace_id)s] %(message)s")
configure_logging(config, context_registry=fields, app_type="fastapi")
```

在 FastAPI 中间件里设置：

```python
from starlette.middleware.base import BaseHTTPMiddleware
import uuid

class TraceIdMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        trace_id = request.headers.get("X-Trace-Id") or str(uuid.uuid4())
        trace_id_var.set(trace_id)
        response = await call_next(request)
        response.headers["X-Trace-Id"] = trace_id
        return response

app.add_middleware(TraceIdMiddleware)
```

## 异步队列写盘（AsyncQueueHandler）

当 `LOG_ASYNC_ENABLED=True` 时，`_file_logger` 会使用 `AsyncQueueHandler`：主线程只往内存队列写，后台线程负责落盘（并可选控制台），减少 I/O 对请求线程的影响。

- 队列大小由 `LOG_ASYNC_QUEUE_SIZE` 控制。
- 内部使用 `ContextAwareQueueHandler` 在入队前将 ContextVar 注入到 LogRecord，保证后台线程中仍有上下文。
- 文件轮转与同步模式一致，复用 `create_timed_handler`（`LOG_ROTATE_WHEN` / `LOG_BACKUP_COUNT` / `LOG_ROTATE_USE_UTC`）。
- 进程退出时通过 `atexit` 调用 `AsyncQueueHandler.close_all()` 排空队列并关闭。

也可单独使用（**必须传入 ContextRegistry**）：

```python
from tomskit.logger import AsyncQueueHandler, LoggerConfig, ContextRegistry

config = LoggerConfig()
registry = ContextRegistry([])  # 或包含 ContextField 的列表
handler = AsyncQueueHandler(
    registry=registry,
    filename=f"{config.LOG_DIR}/{config.LOG_NAME}.log",
    fmt=config.LOG_FORMAT,
    datefmt=config.LOG_DATE_FORMAT,
    queue_size=config.LOG_ASYNC_QUEUE_SIZE,
    when=config.LOG_ROTATE_WHEN,
    backup_count=config.LOG_BACKUP_COUNT,
    utc=config.LOG_ROTATE_USE_UTC,
)
logging.getLogger("").addHandler(handler)
```

## 按类型直接 setup

不需要统一入口时，可传入 `LoggerConfig` 和 `ContextRegistry`，直接调用对应类：

```python
from tomskit.logger import (
    LoggerConfig,
    ContextRegistry,
    FastAPILogging,
    CeleryLogging,
    AlembicLogging,
)

config = LoggerConfig()
registry = ContextRegistry([...])  # 或 ContextRegistry([])

FastAPILogging(config, registry).setup()
# 或
CeleryLogging(config, registry).setup()
# 或
AlembicLogging(config, registry).setup()
```

- **FastAPILogging**：root（应用）+ uvicorn（访问）+ 可选 sqlalchemy（SQL）。
- **CeleryLogging**：root + celery + tasks + schedule（tasks/schedule 使用独立格式，如含 `%(task_id)s`），可选 sqlalchemy。
- **AlembicLogging**：仅 root，文件名 `alembic.log`。

## 扩展：自定义 Handler / Formatter

- **SafeFormatter**：格式时缺占位符不抛错，可通过 `defaults` 传入兜底字典（如 `ContextRegistry.defaults()`）。
- **create_timed_handler**：按时间轮转的文件 Handler，与当前轮转配置一致。
- **ContextFilter**：将 `ContextRegistry` 中的 ContextVar 注入到每条 LogRecord，可挂在 root 或 Handler 上。
- **AsyncQueueHandler**：见上文；内部文件落地复用 `create_timed_handler`。

```python
from tomskit.logger import SafeFormatter, create_timed_handler, ContextFilter, ContextRegistry

registry = ContextRegistry([...])
defaults = registry.defaults()
fmt = SafeFormatter("%(levelname)s %(message)s", "%Y-%m-%d %H:%M:%S", defaults=defaults)
handler = create_timed_handler("logs/app.log", "midnight", 30, False)
handler.setFormatter(fmt)
handler.addFilter(ContextFilter(registry))
logger.addHandler(handler)
```

## 环境变量

所有 `LoggerConfig` 字段均可通过环境变量覆盖，例如：

```bash
export LOG_DIR="logs"
export LOG_LEVEL="INFO"
export LOG_ASYNC_ENABLED="true"
export LOG_SQL_ENABLED="true"
```

```python
from tomskit.logger import configure_logging, LoggerConfig
config = LoggerConfig()  # 从环境读取
configure_logging(config, app_type="fastapi")
```

## 日志文件布局

典型目录结构（以默认名为例）：

```
logs/
├── apps.log          # 应用日志（root）
├── access.log        # 访问日志（uvicorn）
├── sql.log           # SQL 日志（LOG_SQL_ENABLED=True 时）
├── celery.log        # Celery（app_type=celery 时，root/celery/tasks/schedule 共用）
├── alembic.log       # Alembic（app_type=alembic 时）
```

轮转后会有带日期的历史文件（如 `apps.2026-01-22.log`），由 `LOG_ROTATE_WHEN` / `LOG_BACKUP_COUNT` 控制。

## 注意事项

1. **先配置再打日志**：使用前需先调用 `configure_logging(...)` 或对应 `*Logging(...).setup()`。
2. **上下文需在入口设置**：trace_id / prefix 等要在中间件或任务入口通过 ContextVar 设置，否则格式里对应占位符为默认值。
3. **格式占位符**：要在日志中看到上下文字段，`LOG_FORMAT` 里需包含对应占位符（如 `%(trace_id)s`、`%(prefix)s`）。
4. **目录权限**：确保进程对 `LOG_DIR` 有写权限。
5. **异步队列**：`LOG_ASYNC_ENABLED=True` 时，退出时 atexit 会调用 `AsyncQueueHandler.close_all()` 排空队列；若需严格顺序，可在 shutdown 时留短暂等待或显式调用 `handler.close()`。

## 参考

- [Python logging](https://docs.python.org/3/library/logging.html)
- [logging.handlers — QueueHandler / QueueListener](https://docs.python.org/3/library/logging.handlers.html#queuehandler)
