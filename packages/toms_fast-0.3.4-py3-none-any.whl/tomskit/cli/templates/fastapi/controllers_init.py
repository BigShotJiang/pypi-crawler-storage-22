"""
Controllers init template
Template for generating app/controllers/__init__.py file.
"""

TEMPLATE = '''"""
Controllers 目录
"""

'''
