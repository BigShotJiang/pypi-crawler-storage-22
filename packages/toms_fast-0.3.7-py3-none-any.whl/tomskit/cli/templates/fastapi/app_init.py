"""
App init template
Template for generating app/__init__.py file.
"""

TEMPLATE = ""
