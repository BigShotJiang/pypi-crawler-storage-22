"""
CLI 模块入口，支持 python -m tomskit.cli
"""

from . import main

if __name__ == "__main__":
    main()
