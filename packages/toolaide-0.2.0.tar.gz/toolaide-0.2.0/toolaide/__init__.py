"""Toolaide - Tool-calling agent for GLM-4.7-Flash."""

__version__ = "0.2.0"
