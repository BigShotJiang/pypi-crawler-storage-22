from .check_cli import main as check_main
from .print_cli import main as print_main
from .count_cli import main as count_main
