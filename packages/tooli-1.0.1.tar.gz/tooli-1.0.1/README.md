# Tooli

[![CI](https://github.com/weisberg/tooli/actions/workflows/ci.yml/badge.svg)](https://github.com/weisberg/tooli/actions/workflows/ci.yml)
[![PyPI version](https://img.shields.io/pypi/v/tooli)](https://pypi.org/project/tooli/)
[![Python 3.10+](https://img.shields.io/pypi/pyversions/tooli)](https://pypi.org/project/tooli/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

The agent-native CLI framework for Python. Write one function, get a CLI, an MCP tool, and a self-documenting schema.

The name comes from "tool" + "CLI" = "tooli".

Tooli turns typed Python functions into CLI commands that are simultaneously human-friendly (Rich output, shell completions) and machine-consumable (JSON schemas, structured output, MCP compatibility). No separate "agent version" of your tool required.

## Why Tooli?

AI agents invoke thousands of CLI commands daily, but standard CLIs were designed for humans:

- **Interactive prompts hang agents** that can't navigate pagers or password dialogs
- **Unstructured output wastes tokens** — agents parse text with regex instead of reading JSON
- **Vague errors prevent self-correction** — "Error: invalid input" gives agents nothing to work with
- **No discoverability** — agents hallucinate flags for undocumented tools

Tooli fixes all of this. One decorated function produces a CLI, a JSON Schema, an MCP tool definition, structured errors with recovery suggestions, and auto-generated documentation — from a single source of truth.

## Features

- **Dual-mode output** — Rich tables for humans, JSON/JSONL for agents, auto-detected via TTY
- **Structured errors** — actionable error objects with suggestion fields that guide agent self-correction
- **Schema generation** — JSON Schema from type hints, compatible with MCP `inputSchema` and OpenAI function-calling
- **MCP server mode** — serve your CLI as an MCP tool server over stdio or HTTP with zero extra code
- **SKILL.md generation** — auto-generated agent-readable documentation, always in sync with code
- **stdin/file parity** — `StdinOr[T]` type makes files, URLs, and piped data interchangeable
- **Standard global flags** — `--json`, `--jsonl`, `--plain`, `--quiet`, `--dry-run`, `--schema` injected automatically
- **Agent-safe by default** — no interactive prompts in non-TTY mode, no stdout pollution, strict exit codes

## Installation

```bash
pip install tooli
```

Optional extras:

```bash
pip install tooli[mcp]   # MCP server support (fastmcp)
pip install tooli[api]   # HTTP API server (starlette, uvicorn)
```

## Quick Start

```python
from tooli import Tooli, Annotated, Option, Argument
from tooli.annotations import ReadOnly, Idempotent
from pathlib import Path

app = Tooli(
    name="file-tools",
    description="File manipulation utilities",
    version="1.0.0",
)

@app.command(
    annotations=ReadOnly | Idempotent,
    examples=[
        {"args": ["--pattern", "*.py", "--root", "/project"],
         "description": "Find all Python files in a project"},
    ],
)
def find_files(
    pattern: Annotated[str, Argument(help="Glob pattern to match files")],
    root: Annotated[Path, Option(help="Root directory to search from")] = Path("."),
    max_depth: Annotated[int, Option(help="Maximum directory depth")] = 10,
) -> list[dict]:
    """Find files matching a glob pattern in a directory tree."""
    results = []
    for path in root.rglob(pattern):
        results.append({"path": str(path), "size": path.stat().st_size})
    return results

if __name__ == "__main__":
    app()
```

### Human usage

```bash
$ file-tools find-files "*.py" --root ./src
┌──────────────────────┬───────┐
│ Path                 │ Size  │
├──────────────────────┼───────┤
│ src/main.py          │ 1,204 │
│ src/utils.py         │   892 │
└──────────────────────┴───────┘
```

### Agent usage

```bash
$ file-tools find-files "*.py" --root ./src --json
{
  "ok": true,
  "result": [
    {"path": "src/main.py", "size": 1204},
    {"path": "src/utils.py", "size": 892}
  ],
  "meta": {"tool": "file-tools.find-files", "version": "1.0.0", "duration_ms": 34}
}
```

### Schema export

```bash
$ file-tools find-files --schema
{
  "name": "find-files",
  "description": "Find files matching a glob pattern in a directory tree.",
  "inputSchema": {
    "type": "object",
    "properties": {
      "pattern": {"type": "string", "description": "Glob pattern to match files"},
      "root": {"type": "string", "default": ".", "description": "Root directory to search from"},
      "max_depth": {"type": "integer", "default": 10, "description": "Maximum directory depth"}
    },
    "required": ["pattern"]
  },
  "annotations": {"readOnlyHint": true, "idempotentHint": true}
}
```

### MCP server mode

```bash
$ file-tools mcp serve --transport stdio
$ file-tools mcp serve --transport http --host 127.0.0.1 --port 8080
```

Add to your MCP client config and every command becomes a tool.

For SSE-enabled clients, use:

```bash
$ file-tools mcp serve --transport sse --host 127.0.0.1 --port 8080
```

## Structured Errors

When something goes wrong, agents get actionable recovery guidance instead of opaque messages:

```bash
$ file-tools find-files "*.rs" --root ./src --json
{
  "ok": false,
  "error": {
    "code": "E3001",
    "category": "state",
    "message": "No files matched pattern '*.rs' in ./src",
    "suggestion": {
      "action": "retry_with_modified_input",
      "fix": "The directory contains .py files. Try pattern '*.py' instead.",
      "example": "find-files '*.py' --root ./src"
    },
    "is_retryable": true
  }
}
```

## Output Modes

Tooli auto-detects the right output format, or you can be explicit:

| Flag | Behavior |
|---|---|
| *(TTY, no flag)* | Rich formatted output for humans |
| `--json` | Single JSON envelope to stdout |
| `--jsonl` | Newline-delimited JSON for streaming |
| `--plain` | Unformatted text for grep/awk pipelines |
| `--quiet` | Suppress non-essential output |

## Optional Telemetry

Tooli supports anonymous, opt-in usage telemetry for tool authors.

- Disabled by default.
- Enable with `TOOLI_TELEMETRY=true` or `Tooli(telemetry=True)`.
- Records only command identifiers, duration (ms), success/failure outcome, and exit/error codes.
- No command arguments or command output payloads are recorded.
- Local-first by default to `~/.config/tooli/telemetry/events.jsonl`.
- Remote forwarding is opt-in via `TOOLI_TELEMETRY_ENDPOINT` or `Tooli(telemetry_endpoint=...)`.
- Retention policy is local-only by default: entries older than 30 days are pruned.

## Dry-Run Planning

Tooli supports opt-in dry-run planning via `@dry_run_support`.

- Decorate command functions with `@dry_run_support`.
- Use `record_dry_action(action, target, details={...})` to add plan steps.
- Invoke with `--dry-run` to return the action plan instead of executing side effects.
- In JSON output, dry-run responses set `meta.dry_run` to `true`.

## Auto-Generated Documentation

```bash
# Agent-readable skill documentation
$ file-tools generate-skill > SKILL.md

# LLM-friendly docs (llms.txt standard)
$ file-tools docs llms

# Unix man page
$ file-tools docs man
```

## Input Unification

The `StdinOr[T]` type makes files, URLs, and piped data interchangeable:

```python
from tooli import StdinOr

@app.command()
def process(
    input_data: Annotated[StdinOr[Path], Argument(help="Input file, URL, or stdin")],
) -> dict:
    """Process data from any input source."""
    ...
```

```bash
# All equivalent:
$ file-tools process data.csv
$ file-tools process https://example.com/data.csv
$ cat data.csv | file-tools process -
```

## Global Flags

Every Tooli command automatically gets:

```
--output, -o       auto|json|jsonl|text|plain
--json/--jsonl     Convenience aliases
--quiet, -q        Suppress non-essential output
--verbose, -v      Increase verbosity (-vvv)
--dry-run          Preview without executing
--yes              Skip confirmation prompts (for automation/agents)
--no-color         Disable colors (also respects NO_COLOR)
--print0           Emit NUL-separated output for list types in text/plain modes
--timeout          Max execution time in seconds
--null             Parse NUL-delimited list input from stdin (list-processing)
--schema           Print JSON Schema and exit
--response-format  concise|detailed
--help-agent       Token-optimized help for agents
```

## Architecture

Tooli builds on the Python typing + decorator pipeline, adding a parallel schema generation path:

```
          @app.command()
     Python function + type hints
            │              │
            ▼              ▼
      CLI Pipeline    Schema Pipeline
     → CLI params     → Pydantic model
     → CLI parser     → JSON Schema
            │              │
            ▼              ▼
      CLI Output       Agent Output
      Rich tables      MCP tool schema
      Completions      SKILL.md / JSON
```

Key design decisions:
- **Library-first API** — the public surface is Tooli-native (no framework objects leaked into user code)
- **Pydantic schemas** — same pipeline as FastAPI and FastMCP
- **Functions stay callable** — no mutation; test with `CliRunner` or call directly as Python

## Examples

The [`examples/`](examples/) directory contains 18 complete CLI apps built with Tooli, each demonstrating different features:

| App | Features |
|---|---|
| **[docq](examples/docq/)** | ReadOnly, paginated, stdin input, output formats |
| **[gitsum](examples/gitsum/)** | ReadOnly, subprocess, StdinOr for diffs |
| **[csvkit_t](examples/csvkit_t/)** | StdinOr, JSONL output, paginated, OpenWorld |
| **[syswatch](examples/syswatch/)** | ReadOnly, paginated, structured errors |
| **[taskr](examples/taskr/)** | Idempotent, Destructive, paginated CRUD |
| **[proj](examples/proj/)** | Destructive, DryRunRecorder, Idempotent |
| **[envar](examples/envar/)** | SecretInput, AuthContext scopes |
| **[imgsort](examples/imgsort/)** | Destructive+Idempotent, DryRunRecorder, batch ops |
| **[note_indexer](examples/note_indexer/)** | ReadOnly, paginated, JSON index, error handling |

See the [examples README](examples/README.md) for the full list and usage guide.

## Development

```bash
# Clone and install for development
git clone https://github.com/weisberg/tooli.git
cd tooli
pip install -e ".[dev]"

# Run tests
pytest

# Lint and type check
ruff check .
mypy tooli
```

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## License

MIT License. See [LICENSE](LICENSE) for details.
