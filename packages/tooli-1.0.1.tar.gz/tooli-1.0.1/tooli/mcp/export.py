"""MCP tool definition export for Tooli."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, ConfigDict, Field

if TYPE_CHECKING:
    from tooli.app import Tooli


class MCPToolDefinition(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    name: str
    description: str
    input_schema: dict[str, Any] = Field(alias="inputSchema")
    annotations: dict[str, Any] | None = None


def export_mcp_tools(app: Tooli) -> list[dict[str, Any]]:
    """Export all registered commands as MCP tool definitions."""
    from tooli.annotations import ToolAnnotation
    from tooli.command_meta import get_command_meta
    from tooli.schema import generate_tool_schema

    tools = []
    for tool_def in app.get_tools():
        if tool_def.hidden:
            continue

        callback = tool_def.callback
        schema = generate_tool_schema(callback, name=tool_def.name)
        meta = get_command_meta(callback)

        mcp_tool = {
            "name": tool_def.name,
            "description": tool_def.help or schema.description,
            "inputSchema": schema.input_schema,
            "version": schema.version,
        }

        if schema.deprecated:
            mcp_tool["deprecated"] = True  # type: ignore[assignment]
            if schema.deprecated_message:
                mcp_tool["deprecatedMessage"] = schema.deprecated_message

        if required_scopes := meta.auth:
            mcp_tool["auth"] = list(required_scopes)  # type: ignore[assignment]

        # Add behavioral annotations as MCP hints
        annotations = meta.annotations
        if isinstance(annotations, ToolAnnotation):
            hints = {}
            if annotations.read_only:
                hints["readOnlyHint"] = True
            if annotations.idempotent:
                hints["idempotentHint"] = True
            if annotations.destructive:
                hints["destructiveHint"] = True
            if annotations.open_world:
                hints["openWorldHint"] = True
            if hints:
                mcp_tool["annotations"] = hints

        tools.append(mcp_tool)

    return tools
