"""
EuropePMC_get_citations

Get citations for an article from Europe PMC. Citations are articles that cite the specified arti...
"""

from typing import Any, Optional, Callable
from ._shared_client import get_shared_client


def EuropePMC_get_citations(
    article_id: str,
    source: Optional[str] = "MED",
    page_size: Optional[int] = 25,
    page: Optional[int] = 1,
    *,
    stream_callback: Optional[Callable[[str], None]] = None,
    use_cache: bool = False,
    validate: bool = True,
) -> dict[str, Any]:
    """
    Get citations for an article from Europe PMC. Citations are articles that cite the specified arti...

    Parameters
    ----------
    source : str
        Source database (e.g., 'MED' for PubMed, 'PMC' for PMC). Usually 'MED' for mo...
    article_id : str
        Article ID from the source database (e.g., PMID for MED source)
    page_size : int
        Number of citations to retrieve (default: 25, max: 1000)
    page : int
        Page number for pagination (default: 1)
    stream_callback : Callable, optional
        Callback for streaming output
    use_cache : bool, default False
        Enable caching
    validate : bool, default True
        Validate parameters

    Returns
    -------
    dict[str, Any]
    """
    # Handle mutable defaults to avoid B006 linting error

    return get_shared_client().run_one_function(
        {
            "name": "EuropePMC_get_citations",
            "arguments": {
                "source": source,
                "article_id": article_id,
                "page_size": page_size,
                "page": page,
            },
        },
        stream_callback=stream_callback,
        use_cache=use_cache,
        validate=validate,
    )


__all__ = ["EuropePMC_get_citations"]
