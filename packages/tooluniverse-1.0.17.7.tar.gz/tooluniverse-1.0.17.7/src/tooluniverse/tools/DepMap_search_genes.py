"""
DepMap_search_genes

Search for genes in DepMap/Sanger by symbol or name. Returns matching genes with Ensembl IDs and ...
"""

from typing import Any, Optional, Callable
from ._shared_client import get_shared_client


def DepMap_search_genes(
    query: str,
    *,
    stream_callback: Optional[Callable[[str], None]] = None,
    use_cache: bool = False,
    validate: bool = True,
) -> dict[str, Any]:
    """
    Search for genes in DepMap/Sanger by symbol or name. Returns matching genes with Ensembl IDs and ...

    Parameters
    ----------
    query : str
        Gene symbol or name to search (e.g., 'WDR7', 'EGFR', 'TP53')
    stream_callback : Callable, optional
        Callback for streaming output
    use_cache : bool, default False
        Enable caching
    validate : bool, default True
        Validate parameters

    Returns
    -------
    dict[str, Any]
    """
    # Handle mutable defaults to avoid B006 linting error

    return get_shared_client().run_one_function(
        {"name": "DepMap_search_genes", "arguments": {"query": query}},
        stream_callback=stream_callback,
        use_cache=use_cache,
        validate=validate,
    )


__all__ = ["DepMap_search_genes"]
