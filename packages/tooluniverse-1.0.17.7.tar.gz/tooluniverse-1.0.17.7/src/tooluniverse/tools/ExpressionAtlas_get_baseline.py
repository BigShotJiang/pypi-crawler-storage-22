"""
ExpressionAtlas_get_baseline

Get baseline gene expression experiments from EBI Expression Atlas. Shows which tissues/cell type...
"""

from typing import Any, Optional, Callable
from ._shared_client import get_shared_client


def ExpressionAtlas_get_baseline(
    gene: str,
    species: Optional[str] = "homo sapiens",
    *,
    stream_callback: Optional[Callable[[str], None]] = None,
    use_cache: bool = False,
    validate: bool = True,
) -> dict[str, Any]:
    """
    Get baseline gene expression experiments from EBI Expression Atlas. Shows which tissues/cell type...

    Parameters
    ----------
    gene : str
        Gene symbol (e.g., 'TP53', 'WDR7') or Ensembl ID (e.g., 'ENSG00000141510')
    species : str
        Species name (default: 'homo sapiens'). Also supports 'mus musculus', 'rattus...
    stream_callback : Callable, optional
        Callback for streaming output
    use_cache : bool, default False
        Enable caching
    validate : bool, default True
        Validate parameters

    Returns
    -------
    dict[str, Any]
    """
    # Handle mutable defaults to avoid B006 linting error

    return get_shared_client().run_one_function(
        {
            "name": "ExpressionAtlas_get_baseline",
            "arguments": {"gene": gene, "species": species},
        },
        stream_callback=stream_callback,
        use_cache=use_cache,
        validate=validate,
    )


__all__ = ["ExpressionAtlas_get_baseline"]
