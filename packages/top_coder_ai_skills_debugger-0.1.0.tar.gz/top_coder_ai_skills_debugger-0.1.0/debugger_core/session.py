"""High-level debug session orchestrator.

``DebugSession`` is the single entry-point consumed by both:

* **MCP server** -- keeps the session in memory (long-running process).
* **Skill scripts** -- persist session state to a JSON file so that
  sequential CLI invocations can reconnect via a background daemon.

Supports two debug protocols:

* **CDP** (Chrome DevTools Protocol) -- for Node.js.
* **DAP** (Debug Adapter Protocol) -- for Python (via ``debugpy``).

All public methods return **plain-text strings** ready to hand to an LLM.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import signal
import socket
import subprocess
import sys
from typing import Any

from debugger_core.adapters.python import PythonAdapter
from debugger_core.cdp_client import CDPClient
from debugger_core.dap_client import DAPClient
from debugger_core.formatters import (
    format_stack_trace,
    format_stopped_at,
    format_variables,
)
from debugger_core.protocol import (
    TIMEOUT_DAEMON_CMD,
    TIMEOUT_LAUNCH,
    TIMEOUT_RESUME,
    DebugClient,
    DebugMessage,
)

logger = logging.getLogger(__name__)

_SESSION_FILE = ".debug_session.json"

# Languages that use CDP (direct Node.js inspector, zero deps).
_CDP_LANGUAGES = {"node"}
# Languages that use DAP (external debug adapter).
_DAP_LANGUAGES = {"python"}
_ALL_LANGUAGES = _CDP_LANGUAGES | _DAP_LANGUAGES


# ---------------------------------------------------------------------------
# DebugSession
# ---------------------------------------------------------------------------


class DebugSession:
    """Manages a single debug session (CDP or DAP).

    Usage (in-memory, e.g. from MCP server)::

        session = DebugSession()
        print(await session.start("app.js", "node"))
        print(await session.add_breakpoint("app.js", 10))
        print(await session.resume())
        print(await session.inspect("myVar"))
        print(await session.stop())

    Usage (file-based, e.g. from skill scripts)::

        session = DebugSession.from_file_or_new(language="node")
        # session.start(...)  on first invocation
        # session.resume()    on subsequent invocations
        # session.stop()      to clean up
    """

    def __init__(self) -> None:
        self._client: DebugClient | None = None
        self._language: str | None = None
        self._program: str | None = None
        self._breakpoints: dict[str, list[int]] = {}  # file -> lines
        self._persist_file: str | None = None
        # Daemon state (for file-backed interactive sessions)
        self._daemon_port: int | None = None
        self._daemon_pid: int | None = None

    # ------------------------------------------------------------------
    # Constructors
    # ------------------------------------------------------------------

    @classmethod
    def from_file_or_new(
        cls,
        language: str | None = None,
        session_file: str = _SESSION_FILE,
    ) -> DebugSession:
        """Restore a session from a JSON file, or create a fresh one.

        Used by skill CLI scripts where each invocation is a new process.
        """
        session = cls()
        session._persist_file = os.path.abspath(session_file)

        if os.path.isfile(session._persist_file):
            try:
                with open(session._persist_file, encoding="utf-8") as f:
                    data = json.load(f)
                session._language = data.get("language", language)
                session._program = data.get("program")
                session._breakpoints = data.get("breakpoints", {})
                session._daemon_port = data.get("daemon_port")
                session._daemon_pid = data.get("daemon_pid")
                logger.info("Restored session from %s", session._persist_file)
            except (json.JSONDecodeError, OSError) as exc:
                logger.warning("Failed to restore session file: %s", exc)

        # Validate the daemon is still alive.
        if session._daemon_pid:
            try:
                os.kill(session._daemon_pid, 0)
            except OSError:
                logger.info("Daemon pid %d is gone, clearing.", session._daemon_pid)
                session._daemon_port = None
                session._daemon_pid = None

        if language:
            session._language = language

        return session

    # ------------------------------------------------------------------
    # Session lifecycle
    # ------------------------------------------------------------------

    @staticmethod
    def _create_client(language: str) -> DebugClient:
        """Factory: create the right debug client for *language*."""
        if language in _CDP_LANGUAGES:
            return CDPClient()
        return DAPClient(PythonAdapter())

    async def start(self, program: str, language: str | None = None) -> str:
        """Launch the debugger for *program*.

        Returns a human-readable status string.

        In file-backed mode (skill scripts), a background **daemon** is
        spawned so that the debugger connection stays alive between
        separate CLI invocations.
        """
        lang = language or self._language
        if not lang:
            return "Error: language must be specified (node | python)"

        if lang not in _ALL_LANGUAGES:
            return f"Error: unsupported language '{lang}'. Choose: {', '.join(sorted(_ALL_LANGUAGES))}"

        # File-backed mode → delegate to the daemon.
        if self._persist_file:
            return await self._start_daemon(program, lang)

        # In-memory mode (MCP server) → direct connection.
        self._client = self._create_client(lang)
        self._language = lang
        self._program = os.path.abspath(program)
        self._breakpoints = {}

        try:
            await self._client.start()
            await self._client.launch(self._program)
        except Exception as exc:
            return f"Error launching debugger: {exc}"

        self._save()
        return f"Debugger started for {os.path.basename(program)} ({lang}). Ready for breakpoints."

    async def stop(self) -> str:
        """Disconnect and clean up."""
        # Daemon mode → send stop command, then kill.
        if self._daemon_port:
            try:
                result = await self._send_to_daemon({"action": "stop"})
            except Exception:
                result = "Debug session ended (daemon unreachable)."

            if self._daemon_pid:
                try:
                    os.kill(self._daemon_pid, signal.SIGTERM)
                except OSError:
                    pass

            self._daemon_port = None
            self._daemon_pid = None
            self._delete_session_file()
            return result

        # Direct mode (MCP server).
        if self._client:
            await self._client.disconnect()
            self._client = None

        self._delete_session_file()
        return "Debug session ended."

    # ------------------------------------------------------------------
    # Breakpoints
    # ------------------------------------------------------------------

    async def add_breakpoint(self, file: str, line: int) -> str:
        """Set a breakpoint at *file*:*line*."""
        abs_path = os.path.abspath(file)

        if self._daemon_port:
            return await self._send_to_daemon({
                "action": "breakpoint",
                "file": abs_path,
                "line": line,
            })

        if not self._client:
            return "Error: no active debug session. Call start() first."

        existing = self._breakpoints.get(abs_path, [])
        if line not in existing:
            existing.append(line)
        self._breakpoints[abs_path] = existing

        try:
            resp = await self._client.set_breakpoints(abs_path, existing)
        except Exception as exc:
            return f"Error setting breakpoint: {exc}"

        bps = resp.get("breakpoints", [])
        verified = [b for b in bps if b.get("verified")]
        self._save()
        return (
            f"Breakpoint at {os.path.basename(abs_path)}:{line} "
            f"({'verified' if len(verified) == len(bps) else 'pending'})"
        )

    # ------------------------------------------------------------------
    # Execution control
    # ------------------------------------------------------------------

    async def resume(self) -> str:
        """Continue execution until the next breakpoint or termination."""
        if self._daemon_port:
            return await self._send_to_daemon({"action": "resume"})

        if not self._client:
            return "Error: no active debug session."

        try:
            stop_info = await self._client.continue_()
        except asyncio.TimeoutError:
            return f"Execution resumed but no breakpoint hit within {int(TIMEOUT_RESUME)} s."
        except Exception as exc:
            return f"Error resuming: {exc}"

        return await self._describe_stop(stop_info)

    async def step(self, action: str = "next") -> str:
        """Step over (``next``) or into (``step_in``)."""
        if self._daemon_port:
            return await self._send_to_daemon({
                "action": "step", "step_action": action,
            })

        if not self._client:
            return "Error: no active debug session."

        try:
            if action == "step_in":
                stop_info = await self._client.step_in()
            else:
                stop_info = await self._client.next_()
        except asyncio.TimeoutError:
            return f"Step timed out ({int(TIMEOUT_RESUME)} s)."
        except Exception as exc:
            return f"Error stepping: {exc}"

        return await self._describe_stop(stop_info)

    # ------------------------------------------------------------------
    # Inspection
    # ------------------------------------------------------------------

    async def inspect(self, expression: str) -> str:
        """Evaluate *expression* in the current top frame."""
        if self._daemon_port:
            return await self._send_to_daemon({
                "action": "inspect", "expression": expression,
            })

        if not self._client:
            return "Error: no active debug session."

        frame_id = await self._top_frame_id()
        if frame_id is None:
            return "Error: could not determine current frame."

        try:
            resp = await self._client.evaluate(expression, frame_id=frame_id)
        except Exception as exc:
            return f"Error evaluating '{expression}': {exc}"

        result = resp.get("result", str(resp))
        var_type = resp.get("type", "")
        prefix = f"({var_type}) " if var_type else ""
        return f"{prefix}{result}"

    async def get_stack(self) -> str:
        """Return the current stack trace as formatted text."""
        if self._daemon_port:
            return await self._send_to_daemon({"action": "stack"})

        if not self._client:
            return "Error: no active debug session."

        try:
            resp = await self._client.stack_trace()
        except Exception as exc:
            return f"Error fetching stack: {exc}"

        frames = resp.get("stackFrames", [])
        return format_stack_trace(frames)

    async def get_local_variables(self) -> str:
        """Return local variables of the top frame as formatted text."""
        if self._daemon_port:
            return await self._send_to_daemon({"action": "variables"})

        if not self._client:
            return "Error: no active debug session."

        variables = await self._fetch_locals()
        return format_variables(variables)

    # ------------------------------------------------------------------
    # Probe (one-shot)
    # ------------------------------------------------------------------

    async def probe(
        self,
        program: str,
        file: str,
        line: int,
        language: str | None = None,
    ) -> str:
        """One-shot: start, break at *line*, dump state, stop.

        Returns a comprehensive probe report (location + stack + vars).
        Always uses a fresh in-memory session (no daemon) because
        everything happens within a single call.
        """
        tmp = DebugSession()

        try:
            return await self._run_probe(tmp, program, file, line, language)
        finally:
            await tmp.stop()

    @staticmethod
    async def _run_probe(
        session: DebugSession,
        program: str,
        file: str,
        line: int,
        language: str | None,
    ) -> str:
        """Execute a probe using *session*'s public API only."""
        # 1. Start
        start_msg = await session.start(program, language)
        if start_msg.startswith("Error"):
            return start_msg

        # 2. Set breakpoint
        bp_msg = await session.add_breakpoint(file, line)
        if bp_msg.startswith("Error"):
            return bp_msg

        # 3. Run to breakpoint
        stop_info = await session.resume()
        if "Error" in stop_info or "no breakpoint" in stop_info.lower():
            return stop_info

        # 4. Collect data via public methods
        stack_text = await session.get_stack()
        vars_text = await session.get_local_variables()

        # 5. Parse reason from the stop description
        reason = "breakpoint"
        if "(" in stop_info and ")" in stop_info:
            reason = stop_info.split("(")[1].split(")")[0]

        return "\n".join([
            format_stopped_at(os.path.abspath(file), line, reason),
            "",
            "--- Stack Trace ---",
            stack_text,
            "",
            "--- Local Variables ---",
            vars_text,
        ])

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _top_frame_id(self) -> int | None:
        """Return the frameId of the top stack frame, or None."""
        if not self._client:
            return None
        try:
            resp = await self._client.stack_trace()
            frames = resp.get("stackFrames", [])
            return frames[0]["id"] if frames else None
        except Exception:
            return None

    async def _fetch_locals(self) -> list[dict[str, Any]]:
        """Fetch local-scope variables from the top frame."""
        if not self._client:
            return []

        frame_id = await self._top_frame_id()
        if frame_id is None:
            return []

        try:
            scopes_resp = await self._client.scopes(frame_id)
            scopes = scopes_resp.get("scopes", [])
            # Find the "Locals" scope (usually the first one).
            local_scope = next(
                (s for s in scopes if s.get("name", "").lower() in ("locals", "local")),
                scopes[0] if scopes else None,
            )
            if local_scope is None:
                return []

            vars_resp = await self._client.variables(
                local_scope["variablesReference"]
            )
            return vars_resp.get("variables", [])
        except Exception:
            return []

    async def _describe_stop(self, stop_info: DebugMessage) -> str:
        """Build a human-readable description of why we stopped."""
        reason = stop_info.get("reason", "unknown")

        # Program exited -- no stack to inspect.
        if reason == "terminated":
            output = ""
            if self._client and self._client.output_lines:
                output = "\n--- Program output ---\n" + "\n".join(self._client.output_lines)
            return f"Program terminated.{output}"

        # Try to get the current location from the stack.
        if self._client:
            try:
                stack_resp = await self._client.stack_trace()
                frames = stack_resp.get("stackFrames", [])
                if frames:
                    top = frames[0]
                    source = top.get("source", {})
                    file_path = source.get("path", source.get("name", "?"))
                    line = top.get("line", 0)
                    return format_stopped_at(file_path, line, reason)
            except Exception:
                pass

        return f"Stopped ({reason})."

    # ------------------------------------------------------------------
    # Daemon helpers (file-backed interactive sessions)
    # ------------------------------------------------------------------

    @staticmethod
    def _find_free_port() -> int:
        """Ask the OS for an unused TCP port."""
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("", 0))
            return s.getsockname()[1]

    async def _start_daemon(self, program: str, language: str) -> str:
        """Spawn a background :class:`SessionDaemon` and wait for readiness."""
        port = self._find_free_port()

        proc = subprocess.Popen(
            [
                sys.executable, "-m", "debugger_core.daemon",
                "--port", str(port),
                "--language", language,
                "--program", os.path.abspath(program),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            start_new_session=True,  # Fully detach so daemon survives parent exit.
        )

        # The daemon prints a JSON line to stdout when ready.
        # Use a thread executor so we don't block the event loop, with a
        # timeout so a hung daemon doesn't block forever.
        loop = asyncio.get_running_loop()
        try:
            raw = await asyncio.wait_for(
                loop.run_in_executor(None, proc.stdout.readline),  # type: ignore[union-attr]
                timeout=TIMEOUT_LAUNCH,
            )
            msg = json.loads(raw.decode()) if raw else {}
        except asyncio.TimeoutError:
            proc.kill()
            return "Error: daemon did not start within timeout."
        except (json.JSONDecodeError, UnicodeDecodeError):
            msg = {}

        if "error" in msg:
            return msg["error"]
        if not msg.get("ready"):
            proc.kill()
            return "Error: daemon did not signal readiness."

        self._daemon_port = msg.get("port", port)
        self._daemon_pid = proc.pid
        self._language = language
        self._program = os.path.abspath(program)
        self._breakpoints = {}
        self._save()

        return (
            f"Debugger started for {os.path.basename(program)} ({language}). "
            f"Ready for breakpoints."
        )

    async def _send_to_daemon(self, cmd: dict[str, Any]) -> str:
        """Send a JSON command to the daemon and return the text result."""
        reader, writer = await asyncio.open_connection(
            "127.0.0.1", self._daemon_port,
        )
        try:
            writer.write(json.dumps(cmd).encode() + b"\n")
            await writer.drain()

            raw = await asyncio.wait_for(reader.readline(), timeout=TIMEOUT_DAEMON_CMD)
            resp = json.loads(raw.decode()) if raw else {}

            if "error" in resp:
                return f"Error (daemon): {resp['error']}"
            return resp.get("result", "No response from daemon.")
        finally:
            writer.close()
            await writer.wait_closed()

    # ------------------------------------------------------------------
    # Persistence (file-based state for skill scripts)
    # ------------------------------------------------------------------

    def _save(self) -> None:
        """Persist minimal session state to disk."""
        if not self._persist_file:
            return
        data = {
            "language": self._language,
            "program": self._program,
            "breakpoints": self._breakpoints,
            "daemon_port": self._daemon_port,
            "daemon_pid": self._daemon_pid,
        }
        try:
            with open(self._persist_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except OSError:
            logger.warning("Could not save session file %s", self._persist_file)

    def _delete_session_file(self) -> None:
        if self._persist_file and os.path.isfile(self._persist_file):
            try:
                os.remove(self._persist_file)
            except OSError:
                pass
