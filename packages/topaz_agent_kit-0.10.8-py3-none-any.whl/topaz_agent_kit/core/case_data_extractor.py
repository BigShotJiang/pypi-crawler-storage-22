"""
Case Data Extractor Module

Extracts display-relevant fields from the upstream context based on case configuration.
This creates the lightweight case_data stored in pipeline_cases table.
"""

import re
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from topaz_agent_kit.utils.logger import Logger


class CaseDataExtractor:
    """
    Extracts case data from upstream context based on case configuration.
    
    The case config defines which fields to extract using dot-notation paths
    like "agent_id.field_name" or "agent_id.nested.field".
    """
    
    def __init__(self):
        self.logger = Logger("CaseDataExtractor")
    
    def extract_case_id(
        self,
        upstream: Dict[str, Any],
        case_config: Dict[str, Any],
        fallback_id: Optional[str] = None,
    ) -> str:
        """
        Extract the case ID from upstream context based on config.
        
        Returns a unique case_id in format: PREFIX-UUID (e.g., BATCH-ABC12345)
        The expression/data is stored in case_data, not in the ID.
        
        Args:
            upstream: The upstream context containing all agent outputs
            case_config: The case configuration with identity settings
            fallback_id: Fallback ID to use if extraction fails (unused now, kept for compatibility)
            
        Returns:
            Unique case_id string
        """
        identity_config = case_config.get("identity", {})
        prefix = identity_config.get("prefix", "")
        uniqueness = identity_config.get("uniqueness", "uuid_suffix")
        
        # Simplified: Just use prefix + UUID (no id_source needed)
        # The expression/data is already stored in case_data, so we don't need it in the ID
        # This keeps IDs simple, URL-safe, and database-friendly: BATCH-ABC12345
        if prefix:
            base_id = prefix
        else:
            base_id = "CASE"  # Default prefix if none provided
        
        # Generate unique case_id based on uniqueness strategy
        # For uuid_suffix, this will add UUID suffix: BATCH-ABC12345
        # For invoice_id, this will use the invoice_id from current_invoice to create deterministic ID
        case_id = self._make_unique(base_id, uniqueness, upstream)
        
        self.logger.debug(
            "Extracted case ID: {} (strategy: {})",
            case_id, uniqueness
        )
        
        return case_id
    
    def _make_unique(self, display_id: str, uniqueness: str, upstream: Optional[Dict[str, Any]] = None) -> str:
        """
        Make the display_id unique based on the uniqueness strategy.
        
        Args:
            display_id: The human-readable display ID
            uniqueness: Strategy - "uuid_suffix", "timestamp", "none", "invoice_id"
            upstream: Optional upstream context for extracting invoice_id when uniqueness="invoice_id"
            
        Returns:
            Unique case_id (stored in uppercase)
        """
        # Convert display_id to uppercase for case_id
        display_id_upper = display_id.upper()
        
        if uniqueness == "uuid_suffix":
            suffix = uuid.uuid4().hex[:8].upper()
            return f"{display_id_upper}-{suffix}"
        elif uniqueness == "timestamp":
            suffix = datetime.now().strftime("%Y%m%d-%H%M%S-%f")[:20].upper()  # Include microseconds for uniqueness
            return f"{display_id_upper}-{suffix}"
        elif uniqueness == "invoice_id":
            # Extract invoice_id from current_invoice.invoice_id in upstream
            if upstream:
                invoice_id = self._get_nested_value(upstream, "current_invoice.invoice_id")
                if invoice_id:
                    # Sanitize the invoice_id and use it as the suffix
                    sanitized_invoice_id = self._sanitize_id(str(invoice_id))
                    # Use sanitized invoice_id as suffix to create deterministic case_id
                    # This ensures the same invoice always gets the same case_id
                    return f"{display_id_upper}-{sanitized_invoice_id.upper()}"
                else:
                    self.logger.warning(
                        "uniqueness='invoice_id' specified but current_invoice.invoice_id not found in upstream. "
                        "Falling back to uuid_suffix."
                    )
                    # Fall back to uuid_suffix if invoice_id not found
                    suffix = uuid.uuid4().hex[:8].upper()
                    return f"{display_id_upper}-{suffix}"
            else:
                self.logger.warning(
                    "uniqueness='invoice_id' specified but upstream not provided. "
                    "Falling back to uuid_suffix."
                )
                # Fall back to uuid_suffix if upstream not provided
                suffix = uuid.uuid4().hex[:8].upper()
                return f"{display_id_upper}-{suffix}"
        elif uniqueness == "none":
            # No uniqueness guarantee - use at your own risk
            return display_id_upper
        else:
            # Default to uuid_suffix
            suffix = uuid.uuid4().hex[:8].upper()
            return f"{display_id_upper}-{suffix}"
    
    def _sanitize_id(self, raw_id: str) -> str:
        """
        Sanitize an ID to make it URL-safe and database-friendly.
        
        Replaces special characters with safe alternatives:
        - Spaces → underscores
        - Special chars (*, +, /, etc.) → underscores
        - Multiple underscores → single underscore
        - Trims underscores from start/end
        
        Args:
            raw_id: The raw ID string (e.g., "((4+5)* 2-5)/2 + 9** 2")
            
        Returns:
            Sanitized ID (e.g., "__4_5__2_5__2__9__2")
        """
        if not raw_id:
            return raw_id
        
        # Replace spaces with underscores
        sanitized = raw_id.replace(" ", "_")
        
        # Replace common special characters with underscores
        # Keep alphanumeric, underscores, and hyphens
        sanitized = re.sub(r'[^a-zA-Z0-9_-]', '_', sanitized)
        
        # Collapse multiple underscores into one
        sanitized = re.sub(r'_+', '_', sanitized)
        
        # Remove leading/trailing underscores
        sanitized = sanitized.strip('_')
        
        # If result is empty or too short, use a hash
        if not sanitized or len(sanitized) < 3:
            # Use first 8 chars of hash as fallback
            import hashlib
            hash_id = hashlib.md5(raw_id.encode()).hexdigest()[:8].upper()
            return hash_id
        
        return sanitized
    
    def _generate_fallback_display_id(self, prefix: str = "") -> str:
        """Generate a fallback display ID when extraction fails"""
        short_id = uuid.uuid4().hex[:6].upper()
        if prefix:
            return f"{prefix}-{short_id}"
        return f"CASE-{short_id}"
    
    def extract_case_data(
        self,
        upstream: Dict[str, Any],
        case_config: Dict[str, Any],
        case_meta: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Extract display-relevant data from upstream context.
        
        Args:
            upstream: The upstream context containing all agent outputs
            case_config: The case configuration defining what to extract
            case_meta: Optional dictionary of case metadata (common fields like case_id,
                      pipeline_id, status, etc.) to make available in template expressions.
                      These are database columns, not agent outputs.
            
        Returns:
            Dictionary of extracted case data for display
        """
        case_data = {}
        
        # Extract detail view fields (primary - used in case detail modal)
        # Read from views.detail structure
        views_config = case_config.get("views", {})
        detail_view_config = views_config.get("detail", {})
        # Initialize tabs_config early so it's available throughout the function
        tabs_config = detail_view_config.get("tabs_config", {}) if detail_view_config else {}
        
        if detail_view_config:
            # Extract sections from tabs_config
            tabs_config_dict = detail_view_config.get("tabs_config", {})
            # Combine sections from all tabs (for backwards compatibility)
            # Note: This combined view is deprecated in favor of tab-specific sections in _detail_view_tabs
            all_sections = []
            for tab_id, tab_config in tabs_config_dict.items():
                if isinstance(tab_config, dict):
                    tab_sections = tab_config.get("sections", [])
                    # Resolve section references for backwards compatibility
                    for section_config_raw in tab_sections:
                        if isinstance(section_config_raw, dict):
                            resolved_section = self._resolve_section_reference(section_config_raw, case_config)
                            if resolved_section is not None:
                                all_sections.append(resolved_section)
            # Use combined sections for _detail_view (backwards compatibility)
            if all_sections:
                detail_view_for_extraction = {"sections": all_sections}
                case_data["_detail_view"] = self._extract_detail_view_data(upstream, detail_view_for_extraction, case_config)

            # Optional: modal header configuration for Case Detail modal
            # Title and subtitle are direct properties (not nested under modal)
            modal_config = {
                "title": detail_view_config.get("title"),
                "subtitle": detail_view_config.get("subtitle"),
                "title_expression": detail_view_config.get("title_expression"),
                "subtitle_expression": detail_view_config.get("subtitle_expression"),
            }
            if isinstance(modal_config, dict) and modal_config:
                from topaz_agent_kit.utils.expression_evaluator import evaluate_expression_value

                resolved_modal: Dict[str, Any] = {}

                # Base context for expression evaluation (same pattern as extract_field)
                expr_context: Dict[str, Any] = {"upstream": upstream}
                # Also expose upstream agents at top level for shorthand resolution
                expr_context.update({k: v for k, v in upstream.items() if not k.startswith("_")})
                
                # Add case metadata (common fields) to expression context
                # This allows templates to use {{ case_id }}, {{ pipeline_id }}, {{ status }}, etc.
                if case_meta:
                    expr_context.update(case_meta)

                def _resolve_centralized_field_value(field_key: str) -> Optional[str]:
                    """
                    Resolve a centralized field key to its formatted value.
                    
                    Args:
                        field_key: The key of a centralized field (e.g., "contract_stage")
                        
                    Returns:
                        Formatted value string, or None if field not found or value is None
                    """
                    # Get centralized field definitions
                    fields_raw = case_config.get("fields", {})
                    
                    # Convert list format to dict format if needed
                    fields_registry = {}
                    if isinstance(fields_raw, list):
                        for field_def in fields_raw:
                            if isinstance(field_def, dict):
                                key = field_def.get("key")
                                if key:
                                    fields_registry[key] = field_def
                    elif isinstance(fields_raw, dict):
                        fields_registry = fields_raw
                    
                    # Check if this is a centralized field key
                    if field_key not in fields_registry:
                        return None
                    
                    field_config = fields_registry[field_key]
                    
                    # Evaluate field-level condition if present
                    # This ensures conditional fields (like co_version for change_order only)
                    # don't appear in titles when the condition is not met
                    field_condition = field_config.get("condition")
                    if field_condition:
                        try:
                            from topaz_agent_kit.utils.expression_evaluator import evaluate_expression
                            # Build context for condition evaluation (same pattern as list view)
                            condition_context: Dict[str, Any] = {"upstream": upstream}
                            for agent_id, agent_data in upstream.items():
                                if not agent_id.startswith("_"):
                                    if isinstance(agent_data, dict):
                                        parsed = agent_data.get("parsed", agent_data)
                                        condition_context[agent_id] = parsed if parsed else None
                                    else:
                                        condition_context[agent_id] = agent_data
                            
                            condition_result = evaluate_expression(field_condition, condition_context)
                            if not condition_result:
                                self.logger.debug(
                                    "Centralized field '{}' condition '{}' not met, returning None",
                                    field_key,
                                    field_condition
                                )
                                return None  # Condition not met, don't display this field
                        except Exception as exc:
                            self.logger.debug(
                                "Condition evaluation failed for centralized field '{}': {}",
                                field_key,
                                exc
                            )
                            return None  # On error, don't display the field
                    
                    field_path = field_config.get("field") or field_config.get("source")
                    if not field_path:
                        return None
                    
                    # Extract the raw value
                    raw_value = self.extract_field(upstream, field_path)
                    if raw_value is None:
                        return None
                    
                    # Apply value mapping if specified
                    mapped_value = self._apply_value_mapping(
                        raw_value,
                        field_config.get("value_mapping")
                    )
                    
                    # Apply text transform if specified
                    text_transform = field_config.get("text_transform")
                    if text_transform:
                        mapped_value_str = str(mapped_value)
                        if text_transform == "uppercase":
                            mapped_value = mapped_value_str.upper()
                        elif text_transform == "lowercase":
                            mapped_value = mapped_value_str.lower()
                        elif text_transform == "capitalize":
                            # Capitalize first letter of each word
                            mapped_value = re.sub(r'\b\w', lambda m: m.group(0).upper(), mapped_value_str)
                        else:
                            # For other transforms, just use the string as-is
                            mapped_value = mapped_value_str
                    
                    return str(mapped_value)

                def _extract_grouping_key() -> Optional[str]:
                    """
                    Extract grouping key from upstream context if grouping is configured.
                    
                    Returns:
                        Grouping key string or None if not available
                    """
                    # Read from views.grouped structure
                    views_config = case_config.get("views", {})
                    grouped_view_config = views_config.get("grouped", {})
                    
                    # Read grouping_key_expression from views.grouped
                    grouping_key_expression = grouped_view_config.get("grouping_key_expression") if grouped_view_config else None
                    if not grouping_key_expression:
                        return None
                    
                    try:
                        from topaz_agent_kit.core.grouping_extractor import GroupingExtractor
                        grouping_extractor = GroupingExtractor()
                        grouping_key = grouping_extractor.extract_grouping_key(
                            upstream=upstream,
                            grouping_key_expression=grouping_key_expression
                        )
                        return grouping_key
                    except Exception as exc:
                        self.logger.debug(
                            "Failed to extract grouping key for template: {}",
                            exc
                        )
                        return None

                def _render_template(value: str) -> str:
                    """
                    Render a template string with {{ }} placeholders using the expression evaluator.

                    Each {{ ... }} is treated as an expression in the existing expression language,
                    not full Jinja. Failures are logged and replaced with an empty string.
                    
                    Also supports:
                    - Centralized field keys (e.g., {{ contract_stage }}) which will be
                      resolved and formatted according to their field definitions.
                    - Special placeholder {{ grouped_case_link }} which resolves to the grouping_key
                      if grouping is configured, or empty string if not.
                    """
                    if not isinstance(value, str) or "{{" not in value:
                        return value

                    rendered = value
                    # Find all {{ ... }} occurrences
                    pattern = r"{{\s*(.*?)\s*}}"
                    matches = re.findall(pattern, value)
                    for expr in matches:
                        try:
                            expr_stripped = expr.strip()
                            
                            # Special placeholder for grouped case link
                            if expr_stripped == "grouped_case_link":
                                grouping_key = _extract_grouping_key()
                                replacement = grouping_key if grouping_key else ""
                            # First, try to resolve as a centralized field key
                            # (simple identifier without dots, not an expression)
                            elif "." not in expr_stripped and not any(op in expr_stripped for op in [" ", "if", "else", "+", "-", "*", "/", "==", "!=", "<", ">", "and", "or"]):
                                centralized_value = _resolve_centralized_field_value(expr_stripped)
                                if centralized_value is not None:
                                    replacement = centralized_value
                                else:
                                    # Not a centralized field, try expression evaluation
                                    result = evaluate_expression_value(expr, expr_context)
                                    replacement = "" if result is None else str(result)
                            else:
                                # Contains dots or operators - treat as expression
                                result = evaluate_expression_value(expr, expr_context)
                                replacement = "" if result is None else str(result)
                        except Exception as exc:  # pragma: no cover - defensive
                            self.logger.warning(
                                "Failed to evaluate detail_view.modal template expression '{}': {}",
                                expr,
                                exc,
                            )
                            replacement = ""
                        rendered = re.sub(r"{{\s*" + re.escape(expr) + r"\s*}}", replacement, rendered, count=1)
                    return rendered

                # 1) Template-based title/subtitle
                raw_title = modal_config.get("title")
                raw_subtitle = modal_config.get("subtitle")
                title: Optional[str] = _render_template(raw_title) if raw_title is not None else None
                subtitle: Optional[str] = _render_template(raw_subtitle) if raw_subtitle is not None else None
                
                # Clean up subtitle: remove " | Grouped Case: " part if grouped_case_link is empty
                if subtitle and "| Grouped Case:" in subtitle:
                    # Check if grouped_case_link was empty (subtitle ends with " | Grouped Case: " or just " | Grouped Case:")
                    # Remove the grouped case part if it's empty (ends with " | Grouped Case: " or " | Grouped Case:")
                    subtitle = re.sub(r'\s*\|\s*Grouped Case:\s*$', '', subtitle)

                # 2) Expression-based title/subtitle (takes precedence when provided)
                title_expr = modal_config.get("title_expression")
                if isinstance(title_expr, str):
                    try:
                        expr_value = evaluate_expression_value(title_expr, expr_context)
                        if expr_value is not None:
                            title = str(expr_value)
                    except Exception as exc:  # pragma: no cover - defensive
                        self.logger.warning(
                            "Failed to evaluate detail_view.modal.title_expression '{}': {}",
                            title_expr,
                            exc,
                        )

                subtitle_expr = modal_config.get("subtitle_expression")
                if isinstance(subtitle_expr, str):
                    try:
                        expr_value = evaluate_expression_value(subtitle_expr, expr_context)
                        if expr_value is not None:
                            subtitle = str(expr_value)
                    except Exception as exc:  # pragma: no cover - defensive
                        self.logger.warning(
                            "Failed to evaluate detail_view.modal.subtitle_expression '{}': {}",
                            subtitle_expr,
                            exc,
                        )

                if title is not None:
                    resolved_modal["title"] = title
                if subtitle is not None:
                    resolved_modal["subtitle"] = subtitle

                if resolved_modal:
                    case_data["_detail_view_modal"] = resolved_modal

            # Optional: tab configuration for Case Detail modal
            # Tab order is in views.detail.tabs.order
            # Tab-specific configs (label, title, sections) are in views.detail.tabs_config[tab_id]
            tabs_order_config = detail_view_config.get("tabs") or {}
            tabs_config_dict = detail_view_config.get("tabs_config", {})
            # Update tabs_config with the latest value
            tabs_config = tabs_config_dict
            
            if isinstance(tabs_order_config, dict) or isinstance(tabs_config_dict, dict):
                from topaz_agent_kit.utils.expression_evaluator import evaluate_expression_value

                resolved_tabs: Dict[str, Any] = {}

                # Order: keep as-is if a list of strings
                order = tabs_order_config.get("order") if isinstance(tabs_order_config, dict) else None
                if isinstance(order, list):
                    resolved_tabs["order"] = [str(t) for t in order]

                # Shared expression context for template rendering
                expr_context_tabs: Dict[str, Any] = {"upstream": upstream}
                expr_context_tabs.update({k: v for k, v in upstream.items() if not k.startswith("_")})
                # Add case metadata (common fields) to expression context for tabs
                if case_meta:
                    expr_context_tabs.update(case_meta)

                def _render_label_template(value: str) -> str:
                    if not isinstance(value, str) or "{{" not in value:
                        return value
                    rendered = value
                    pattern = r"{{\s*(.*?)\s*}}"
                    matches = re.findall(pattern, value)
                    for expr in matches:
                        try:
                            result = evaluate_expression_value(expr, expr_context_tabs)
                            replacement = "" if result is None else str(result)
                        except Exception as exc:  # pragma: no cover - defensive
                            self.logger.warning(
                                "Failed to evaluate tab label/title template '{}': {}",
                                expr,
                                exc,
                            )
                            replacement = ""
                        rendered = re.sub(r"{{\s*" + re.escape(expr) + r"\s*}}", replacement, rendered, count=1)
                    return rendered

                # Extract labels and titles from tabs_config[tab_id] (new structure)
                # Also support backward compatibility with tabs.labels and tabs.titles
                labels: Dict[str, str] = {}
                titles: Dict[str, Any] = {}
                
                # New structure: read from tabs_config[tab_id].label and tabs_config[tab_id].title
                if isinstance(tabs_config_dict, dict):
                    for tab_id, tab_config in tabs_config_dict.items():
                        if not isinstance(tab_config, dict):
                            continue
                        
                        # Extract label from tab config
                        tab_label = tab_config.get("label")
                        if tab_label:
                            if isinstance(tab_label, str):
                                labels[tab_id] = _render_label_template(tab_label)
                            else:
                                labels[tab_id] = str(tab_label)
                        
                        # Extract title from tab config
                        tab_title = tab_config.get("title")
                        if tab_title:
                            if isinstance(tab_title, str):
                                # Simple string title
                                titles[tab_id] = {"text": _render_label_template(tab_title)}
                            elif isinstance(tab_title, dict):
                                # Title with config (text, align, text_transform, font_size, bold, italic, underline, text_color, background_color, background_scope)
                                title_obj: Dict[str, Any] = {}
                                if "text" in tab_title:
                                    title_text = tab_title["text"]
                                    if isinstance(title_text, str):
                                        title_obj["text"] = _render_label_template(title_text)
                                if "align" in tab_title and tab_title["align"] in ["left", "center", "right"]:
                                    title_obj["align"] = tab_title["align"]
                                if "text_transform" in tab_title:
                                    title_obj["text_transform"] = tab_title["text_transform"]
                                if "font_size" in tab_title:
                                    title_obj["font_size"] = tab_title["font_size"]
                                if "bold" in tab_title:
                                    title_obj["bold"] = bool(tab_title["bold"])
                                if "italic" in tab_title:
                                    title_obj["italic"] = bool(tab_title["italic"])
                                if "underline" in tab_title:
                                    title_obj["underline"] = bool(tab_title["underline"])
                                if "text_color" in tab_title:
                                    title_obj["text_color"] = str(tab_title["text_color"])
                                if "background_color" in tab_title:
                                    title_obj["background_color"] = str(tab_title["background_color"])
                                if "background_scope" in tab_title and tab_title["background_scope"] in ["text", "row"]:
                                    title_obj["background_scope"] = str(tab_title["background_scope"])
                                if title_obj:
                                    titles[tab_id] = title_obj
                
                # Backward compatibility: also check tabs.labels and tabs.titles (old structure)
                if isinstance(tabs_order_config, dict):
                    raw_labels = tabs_order_config.get("labels") or {}
                    if isinstance(raw_labels, dict):
                        for tab_id, value in raw_labels.items():
                            if tab_id not in labels:  # Only use if not already set from tabs_config
                                if isinstance(value, str):
                                    labels[tab_id] = _render_label_template(value)
                                else:
                                    labels[tab_id] = str(value)
                    
                    raw_titles = tabs_order_config.get("titles") or {}
                    if isinstance(raw_titles, dict):
                        for tab_id, title_config in raw_titles.items():
                            if tab_id not in titles:  # Only use if not already set from tabs_config
                                if isinstance(title_config, str):
                                    titles[tab_id] = {"text": _render_label_template(title_config)}
                                elif isinstance(title_config, dict):
                                    title_obj: Dict[str, Any] = {}
                                    if "text" in title_config:
                                        title_text = title_config["text"]
                                        if isinstance(title_text, str):
                                            title_obj["text"] = _render_label_template(title_text)
                                    if "align" in title_config and title_config["align"] in ["left", "center", "right"]:
                                        title_obj["align"] = title_config["align"]
                                    if "text_transform" in title_config:
                                        title_obj["text_transform"] = title_config["text_transform"]
                                    if "font_size" in title_config:
                                        title_obj["font_size"] = title_config["font_size"]
                                    if "bold" in title_config:
                                        title_obj["bold"] = bool(title_config["bold"])
                                    if "italic" in title_config:
                                        title_obj["italic"] = bool(title_config["italic"])
                                    if "underline" in title_config:
                                        title_obj["underline"] = bool(title_config["underline"])
                                    if "text_color" in title_config:
                                        title_obj["text_color"] = str(title_config["text_color"])
                                    if "background_color" in title_config:
                                        title_obj["background_color"] = str(title_config["background_color"])
                                    if "background_scope" in title_config and title_config["background_scope"] in ["text", "row"]:
                                        title_obj["background_scope"] = str(title_config["background_scope"])
                                    if title_obj:
                                        titles[tab_id] = title_obj

                if labels:
                    resolved_tabs["labels"] = labels
                if titles:
                    resolved_tabs["titles"] = titles

                # Extract custom tabs from tabs.custom_tabs
                if isinstance(tabs_order_config, dict):
                    custom_tabs = tabs_order_config.get("custom_tabs")
                    if isinstance(custom_tabs, list):
                        resolved_tabs["custom_tabs"] = custom_tabs
                
                # Extract tab-specific sections (with section reference resolution)
                # Each tab's sections are extracted separately and stored in _detail_view_tabs[tab_id].sections
                tab_sections_data: Dict[str, Dict[str, Any]] = {}
                if isinstance(tabs_config_dict, dict):
                    for tab_id, tab_config in tabs_config_dict.items():
                        if not isinstance(tab_config, dict):
                            continue
                        
                        tab_sections_raw = tab_config.get("sections", [])
                        if not tab_sections_raw:
                            continue
                        
                        # Resolve section references (section: "id") to centralized section definitions
                        resolved_sections = []
                        for section_config_raw in tab_sections_raw:
                            if not isinstance(section_config_raw, dict):
                                continue
                            
                            # Resolve section reference if it's a reference to centralized sections
                            resolved_section = self._resolve_section_reference(section_config_raw, case_config)
                            if resolved_section is not None:
                                resolved_sections.append(resolved_section)
                        
                        # Extract data for this tab's sections
                        if resolved_sections:
                            tab_detail_view_config = {"sections": resolved_sections}
                            tab_extracted_data = self._extract_detail_view_data(upstream, tab_detail_view_config, case_config)
                            if tab_extracted_data and tab_extracted_data.get("sections"):
                                tab_sections_data[tab_id] = tab_extracted_data
                
                if tab_sections_data:
                    resolved_tabs["sections"] = tab_sections_data
                
                if resolved_tabs:
                    case_data["_detail_view_tabs"] = resolved_tabs
        
        # Extract list view fields (for case list display with tabs)
        # Read from views.list structure
        views_config = case_config.get("views", {})
        list_view_config = views_config.get("list", {})
        if list_view_config:
            case_data["_list_view"] = self._extract_list_view_data(upstream, list_view_config, case_config)
        
        # Extract documents information (for Documents tab)
        # Read from views.detail.tabs_config.documents structure
        # tabs_config is already defined above
        documents_config = tabs_config.get("documents", {})
        documents_sections = documents_config.get("sections", []) if isinstance(documents_config, dict) else []
        if documents_sections:
            case_data["_documents"] = self._extract_documents_data(upstream, documents_sections)
        
        # Extract review response outcome fields (for Review Response Outcome tab)
        # Read from views.detail.tabs_config.review_response_outcome structure
        review_response_outcome_config = tabs_config.get("review_response_outcome", {})
        review_response_outcome_sections = review_response_outcome_config.get("sections", []) if isinstance(review_response_outcome_config, dict) else []
        if review_response_outcome_sections:
            case_data["_review_response_outcome"] = self._extract_detail_view_data(upstream, {"sections": review_response_outcome_sections}, case_config)
        
        # Extract timeline configuration (for Timeline tab)
        # Timeline config can be in two places:
        # 1. views.detail.tabs_config.timeline (tab-specific overrides like sort_order, display_mode)
        # 2. Top-level timeline (main config with system_events, custom_events, order)
        # Merge them: tab-specific overrides take precedence, but inherit from top-level
        tab_timeline_config = tabs_config.get("timeline", {})
        top_level_timeline_config = case_config.get("timeline", {})
        
        # Merge: start with top-level, then override with tab-specific
        timeline_config = {}
        if top_level_timeline_config:
            timeline_config = dict(top_level_timeline_config)  # Copy to avoid modifying original
        if tab_timeline_config:
            # Override with tab-specific settings (like sort_order, display_mode)
            timeline_config.update(tab_timeline_config)
            # But preserve system_events and custom_events from top-level if not in tab config
            if "system_events" not in tab_timeline_config and "system_events" in top_level_timeline_config:
                timeline_config["system_events"] = top_level_timeline_config["system_events"]
            if "custom_events" not in tab_timeline_config and "custom_events" in top_level_timeline_config:
                timeline_config["custom_events"] = top_level_timeline_config["custom_events"]
            if "order" not in tab_timeline_config and "order" in top_level_timeline_config:
                timeline_config["order"] = top_level_timeline_config["order"]
        
        if timeline_config:
            case_data["_timeline_config"] = self._extract_timeline_config(upstream, timeline_config, case_config)
        
        # Also store raw agent outputs for flexibility
        # Only include agents that are referenced in the config
        referenced_agents = self._get_referenced_agents(case_config)
        for agent_id in referenced_agents:
            if agent_id in upstream:
                case_data[agent_id] = upstream[agent_id]
        
        return case_data
    
    def extract_field(
        self,
        upstream: Dict[str, Any],
        source_path: str,
    ) -> Any:
        """
        Extract a single field from upstream using dot-notation path or expression.
        
        Supports two formats:
        1. Simple dot-notation: "agent_id.field" or "agent_id.nested.field"
        2. Ternary expression: "agent_a.field if agent_a else agent_b.field"
        
        Args:
            upstream: The upstream context
            source_path: Dot-notation path or expression string
            
        Returns:
            The extracted value or None if not found
        """
        # Check if source_path is an expression (contains ternary operator)
        if " if " in source_path and " else " in source_path:
            # Use ExpressionEvaluator to evaluate the expression
            from topaz_agent_kit.utils.expression_evaluator import evaluate_expression_value
            
            try:
                # Prepare context for expression evaluator
                # ExpressionEvaluator expects context with upstream data accessible via dot notation
                # It looks for context.upstream[agent_id] and then accesses parsed or direct fields
                context = {"upstream": upstream}
                
                # Extract agent names from expression to ensure they exist in context
                # This is important for ternary expressions like "aegis_translator.field if aegis_translator else ..."
                # where aegis_translator might not exist in upstream (skipped conditional node)
                agent_pattern = r'([a-zA-Z_][a-zA-Z0-9_]*)\.'
                expression_agents = set(re.findall(agent_pattern, source_path))
                
                # Add agents from upstream to context
                for agent_id, agent_data in upstream.items():
                    if not agent_id.startswith("_"):
                        # Add agent data directly to context for expression evaluation
                        # This allows expressions to access agents directly (e.g., "aegis_translator")
                        # For simple checks like "if aegis_translator", this provides the agent object
                        if isinstance(agent_data, dict):
                            # For dict agents, add the parsed data if available
                            # This allows "if aegis_translator" to check if agent exists and has data
                            parsed = agent_data.get("parsed", agent_data)
                            context[agent_id] = parsed if parsed else None
                        else:
                            context[agent_id] = agent_data
                
                # Add missing agents (referenced in expression but not in upstream) as None
                # This allows ternary expressions to work correctly when agents are skipped
                for agent_id in expression_agents:
                    if agent_id not in context and agent_id not in upstream:
                        context[agent_id] = None
                        # Also add to upstream as None so ExpressionEvaluator can find it
                        context["upstream"][agent_id] = None
                        self.logger.debug(
                            "Added missing agent '{}' as None to context for expression evaluation",
                            agent_id
                        )
                
                # Evaluate the expression
                result = evaluate_expression_value(source_path, context)
                self.logger.debug(
                    "Evaluated expression '{}' to value: {}",
                    source_path,
                    result
                )
                return result
            except Exception as e:
                self.logger.warning(
                    "Failed to evaluate expression '{}': {}. Falling back to simple path resolution.",
                    source_path,
                    e
                )
                # Fall back to simple path resolution if expression evaluation fails
                # Extract the first path from the expression as fallback
                # e.g., "a.translated_data.invoice_data.invoice_number if a else b.invoice_data.invoice_number"
                # -> try "a.translated_data.invoice_data.invoice_number" first
                if " if " in source_path:
                    first_path = source_path.split(" if ")[0].strip()
                    return self._get_nested_value(upstream, first_path)
                return None
        else:
            # Simple dot-notation path - use existing logic
            return self._get_nested_value(upstream, source_path)
    
    def _resolve_field_reference(
        self,
        field_config: Dict[str, Any],
        case_config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Resolve a field configuration, supporting both inline definitions and references.
        
        If field_config has a 'key' but no 'field' or 'source', look it up in case_config.fields[key].
        Merge the referenced definition with any inline overrides.
        
        Supports both list and dict formats for fields:
        - List format: fields: [{key: "field1", ...}, {key: "field2", ...}]
        - Dict format: fields: {field1: {...}, field2: {...}}
        
        Args:
            field_config: Field configuration (may be a reference or inline definition)
            case_config: Full case configuration containing top-level 'fields' section
            
        Returns:
            Resolved field configuration with all properties merged
        """
        # Get centralized field definitions
        fields_raw = case_config.get("fields", {})
        
        # Convert list format to dict format if needed
        fields_registry = {}
        if isinstance(fields_raw, list):
            # List format: [{key: "field1", ...}, {key: "field2", ...}]
            for field_def in fields_raw:
                if isinstance(field_def, dict):
                    field_key = field_def.get("key")
                    if field_key:
                        fields_registry[field_key] = field_def
        elif isinstance(fields_raw, dict):
            # Dict format: {field1: {...}, field2: {...}}
            fields_registry = fields_raw
        
        # Check if this is a reference (has 'key' but no 'field' or 'source')
        field_key = field_config.get("key")
        has_field_path = field_config.get("field") or field_config.get("source")
        
        if field_key and not has_field_path and field_key in fields_registry:
            # This is a reference - merge referenced definition with inline overrides
            referenced_field = fields_registry[field_key].copy()
            # Inline overrides take precedence
            merged = {**referenced_field, **field_config}
            # Ensure key is preserved
            merged["key"] = field_key
            self.logger.debug(
                "Resolved field reference '{}' from centralized fields. Merged config has field: {}",
                field_key,
                merged.get("field") or merged.get("source")
            )
            return merged
        elif field_key and not has_field_path:
            # Key provided but not found in registry - log warning
            self.logger.warning(
                "Field reference '{}' not found in centralized fields registry. "
                "Available keys: {}. Using field config as-is.",
                field_key,
                list(fields_registry.keys())[:10]
            )
        else:
            # Inline definition or key not found in registry - use as-is
            pass
        return field_config.copy()
    
    def _resolve_section_reference(
        self,
        section_config: Dict[str, Any],
        case_config: Dict[str, Any],
    ) -> Optional[Dict[str, Any]]:
        """
        Resolve a section configuration, supporting both inline definitions and references.
        
        If section_config has a 'section' key (reference to centralized section),
        look it up in case_config.sections and merge with any inline overrides.
        
        Supports list format for sections:
        - List format: sections: [{id: "section1", name: "...", fields: [...]}, ...]
        
        Args:
            section_config: Section configuration (may be a reference or inline definition)
            case_config: Full case configuration containing top-level 'sections' section
            
        Returns:
            Resolved section configuration with all properties merged, or None if reference not found
        """
        # Get centralized section definitions
        sections_raw = case_config.get("sections", [])
        
        # Build sections registry by id
        sections_registry: Dict[str, Dict[str, Any]] = {}
        if isinstance(sections_raw, list):
            for section_def in sections_raw:
                if isinstance(section_def, dict):
                    section_id = section_def.get("id")
                    if section_id:
                        sections_registry[section_id] = section_def
        
        # Check if this is a reference (has 'section' key pointing to centralized section)
        section_ref = section_config.get("section")
        
        if section_ref and section_ref in sections_registry:
            # This is a reference - merge referenced definition with inline overrides
            referenced_section = sections_registry[section_ref].copy()
            # Inline overrides take precedence (except 'section' key which is just the reference)
            merged = {**referenced_section}
            for k, v in section_config.items():
                if k != "section":  # Don't copy the reference key itself
                    merged[k] = v
            self.logger.debug(
                "Resolved section reference '{}' from centralized sections. Section name: {}",
                section_ref,
                merged.get("name") or merged.get("title") or merged.get("id")
            )
            return merged
        elif section_ref:
            # Reference provided but not found in registry - log warning
            self.logger.warning(
                "Section reference '{}' not found in centralized sections registry. "
                "Available ids: {}. Skipping section.",
                section_ref,
                list(sections_registry.keys())
            )
            return None
        
        # Not a reference - return as-is (inline section definition)
        return section_config.copy()
    
    def _extract_list_view_data(
        self,
        upstream: Dict[str, Any],
        list_view_config: Dict[str, Any],
        case_config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Extract fields for list view display.
        
        New structure:
        - pipeline_fields: Define pipeline-specific fields with key, field path, label, type
        - column_order: Define which columns to show and in what order (mix of common and pipeline field keys)
        
        Common fields (always available, don't need to define):
        - case_id, pipeline_id, status, hitl_gate_title, hitl_description,
          hitl_status, hitl_decision, responded_by, created_at, updated_at
        
        Also supports legacy structures for backwards compatibility.
        """
        data = {}
        
        # New structure: pipeline_fields and column_order
        pipeline_fields = list_view_config.get("pipeline_fields", [])
        column_order = list_view_config.get("column_order", [])
        
        if pipeline_fields or column_order:
            # Debug: Log what's available in upstream for common loop item keys
            for loop_key in ["current_journal", "current_invoice", "current_claim", "current_problem", "loop_item"]:
                if loop_key in upstream:
                    loop_item = upstream[loop_key]
                    if isinstance(loop_item, dict):
                        self.logger.debug(
                            "Found loop item '{}' in upstream with keys: {}",
                            loop_key,
                            list(loop_item.keys())[:30]
                        )
            # Extract pipeline-specific fields
            data["pipeline_fields"] = {}
            self.logger.debug(
                "Extracting list view pipeline fields. Total fields to process: {}. "
                "Available agents in upstream: {}",
                len(pipeline_fields),
                [k for k in upstream.keys() if not k.startswith("_")][:10]
            )
            for field_config_raw in pipeline_fields:
                field_key_raw = field_config_raw.get("key", "unknown")
                # Resolve field reference (if it's a reference to centralized fields)
                field_config = self._resolve_field_reference(field_config_raw, case_config)
                
                # Support both "source" and "field" keys
                source = field_config.get("source") or field_config.get("field")
                if not source:
                    # Field reference wasn't resolved or field path is missing
                    field_key = field_config.get("key")
                    self.logger.warning(
                        "Skipping pipeline field '{}' - no 'field' or 'source' path found after resolution. "
                        "Raw config: {}, Resolved config: {}",
                        field_key or "unknown",
                        field_config_raw,
                        field_config
                    )
                    continue
                
                # Evaluate field-level condition if present
                field_condition = field_config.get("condition")
                if field_condition:
                    try:
                        from topaz_agent_kit.utils.expression_evaluator import evaluate_expression
                        # Prepare context for expression evaluator (same as extract_field)
                        context = {"upstream": upstream}
                        # Add agents from upstream to context for better variable resolution
                        # This helps with conditions like "covenant_document_classifier.document_type == 'change_order'"
                        for agent_id, agent_data in upstream.items():
                            if not agent_id.startswith("_"):
                                if isinstance(agent_data, dict):
                                    parsed = agent_data.get("parsed", agent_data)
                                    context[agent_id] = parsed if parsed else None
                                else:
                                    context[agent_id] = agent_data
                        
                        # Debug: Log what we're evaluating
                        self.logger.debug(
                            "Evaluating condition '{}' for pipeline field '{}'. Available agents in context: {}",
                            field_condition,
                            field_key_raw,
                            [k for k in context.keys() if not k.startswith("_")][:10]
                        )
                        
                        condition_result = evaluate_expression(field_condition, context)
                        self.logger.debug(
                            "Condition '{}' for pipeline field '{}' evaluated to: {}",
                            field_condition,
                            field_key_raw,
                            condition_result
                        )
                        
                        if not condition_result:
                            self.logger.debug(
                                "Skipping pipeline field '{}' - condition '{}' evaluated to False",
                                field_key_raw,
                                field_condition
                            )
                            continue
                    except Exception as e:
                        self.logger.warning(
                            "Failed to evaluate condition '{}' for pipeline field '{}': {}. Skipping field.",
                            field_condition,
                            field_key_raw,
                            e
                        )
                        # Don't include field if condition evaluation fails (fail-safe)
                        continue
                
                if source:
                    # Use extract_field to support expressions
                    value = self.extract_field(upstream, source)
                    key = field_config.get("key")
                    if not key:
                        # Fallback: use last part of field path as key
                        key = source.split(".")[-1] if "." in source else source
                    
                    # Debug logging for missing values
                    if value is None:
                        # Check if the parent object exists
                        if "." in source:
                            parent_path = ".".join(source.split(".")[:-1])
                            parent_value = self.extract_field(upstream, parent_path)
                            if parent_value is None:
                                self.logger.debug(
                                    "Field '{}' (key: '{}') is None - parent path '{}' not found in upstream",
                                    source, key, parent_path
                                )
                            else:
                                self.logger.debug(
                                    "Field '{}' (key: '{}') is None - field not found in parent '{}'",
                                    source, key, parent_path
                                )
                        else:
                            self.logger.debug(
                                "Field '{}' (key: '{}') is None - not found in upstream",
                                source, key
                            )
                    
                    # Store original value before mapping (needed for icon/color matching)
                    original_value = value
                    
                    # Apply value mapping if specified
                    mapped_value = self._apply_value_mapping(value, field_config.get("value_mapping"))
                    
                    extracted_field = {
                        "value": mapped_value,  # Mapped value for display
                        "original_value": original_value,  # Original value for icon/color matching
                        "label": field_config.get("label", ""),
                        "type": field_config.get("type", "text"),
                        # Include display configuration from YAML
                        "value_mapping": field_config.get("value_mapping"),
                        "color_mapping": field_config.get("color_mapping"),
                        "icon_mapping": field_config.get("icon_mapping"),
                        "text_transform": field_config.get("text_transform"),
                        "text_transform_options": field_config.get("text_transform_options"),
                        "decimals": field_config.get("decimals"),
                    }
                    
                    data["pipeline_fields"][key] = extracted_field
                    self.logger.debug(
                        "Extracted pipeline field '{}' with value: {} (original: {})",
                        key,
                        mapped_value,
                        original_value
                    )
            
            # Store column order (list of keys: common field keys or pipeline field keys)
            if column_order:
                data["column_order"] = column_order
            
            self.logger.debug(
                "List view extraction complete. Extracted {} pipeline fields: {}",
                len(data.get("pipeline_fields", {})),
                list(data.get("pipeline_fields", {}).keys())
            )
        else:
            # Legacy support: "fields" array or "primary"/"secondary" structure
            fields = list_view_config.get("fields", [])
            if fields:
                # Simple fields array structure
                data["fields"] = []
                for field_config in fields:
                    # Support both "source" and "field" keys
                    source = field_config.get("source") or field_config.get("field")
                    if source:
                        # Use extract_field to support expressions
                        value = self.extract_field(upstream, source)
                        key = field_config.get("key", source.split(".")[-1] if "." in source else source)
                        data["fields"].append({
                            "value": value,
                            "label": field_config.get("label", ""),
                            "type": field_config.get("type", "text"),
                            "key": key,
                        })
            else:
                # Legacy primary/secondary structure
                # Primary field
                primary = list_view_config.get("primary", {})
                if primary:
                    # Support both "source" and "field" keys
                    source = primary.get("source") or primary.get("field")
                    if source:
                        value = self.extract_field(upstream, source)
                        data["primary"] = {
                            "value": value,
                            "label": primary.get("label", ""),
                            "type": primary.get("type", "text"),
                        }
                
                # Secondary fields
                secondary = list_view_config.get("secondary", [])
                data["secondary"] = []
                for field_config in secondary:
                    # Support both "source" and "field" keys
                    source = field_config.get("source") or field_config.get("field")
                    if source:
                        value = self.extract_field(upstream, source)
                        key = field_config.get("key", source.split(".")[-1] if "." in source else source)
                        data["secondary"].append({
                            "value": value,
                            "label": field_config.get("label", ""),
                            "type": field_config.get("type", "text"),
                            "key": key,
                        })
        
        return data
    
    def _extract_documents_data(
        self,
        upstream: Dict[str, Any],
        documents_config: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """
        Extract documents information for the Documents tab.
        
        Supports:
        - Single document: field points to a file path string
        - List of documents: field points to an array of objects with file paths
        - Conditional display: condition expression to show/hide documents
        """
        from topaz_agent_kit.utils.expression_evaluator import evaluate_expression
        
        documents = []
        
        for doc_config in documents_config:
            # Evaluate condition if present
            condition = doc_config.get("condition")
            if condition:
                try:
                    # Build context with agents at top level (same pattern as other conditions)
                    context: Dict[str, Any] = {"upstream": upstream}
                    for agent_id, agent_data in upstream.items():
                        if not agent_id.startswith("_"):
                            if isinstance(agent_data, dict):
                                parsed = agent_data.get("parsed", agent_data)
                                context[agent_id] = parsed if parsed else None
                            else:
                                context[agent_id] = agent_data
                    
                    condition_result = evaluate_expression(condition, context)
                    if not condition_result:
                        self.logger.debug(
                            "Skipping document '{}' - condition '{}' evaluated to False",
                            doc_config.get("key") or doc_config.get("label"),
                            condition
                        )
                        continue
                except Exception as e:
                    self.logger.warning(
                        "Failed to evaluate condition '{}' for document '{}': {}. Skipping document.",
                        condition,
                        doc_config.get("key") or doc_config.get("label"),
                        e
                    )
                    continue
            
            # Extract field value
            field_path = doc_config.get("field")
            if not field_path:
                self.logger.warning(
                    "Document '{}' has no 'field' path specified. Skipping.",
                    doc_config.get("key") or doc_config.get("label")
                )
                continue
            
            value = self.extract_field(upstream, field_path)
            doc_type = doc_config.get("type", "pdf")
            key = doc_config.get("key", "")
            label = doc_config.get("label", self._format_label(key))
            missing_message = doc_config.get("missing_message", "Document not available")
            
            # Handle different document types
            if doc_type == "list":
                # List of documents - each item should have a file path
                if value and isinstance(value, list) and len(value) > 0:
                    item_label_field = doc_config.get("item_label_field", "type")
                    item_path_field = doc_config.get("item_path_field", "file_path")
                    
                    for idx, item in enumerate(value):
                        if not isinstance(item, dict):
                            continue
                        
                        file_path = item.get(item_path_field)
                        # Include even if file_path is missing - will show "not available" message
                        item_label = item.get(item_label_field, f"{label} {idx + 1}")
                        documents.append({
                            "key": f"{key}_{idx}",
                            "label": item_label,
                            "file_path": file_path if file_path else None,
                            "type": doc_type,
                            "missing_message": missing_message,
                        })
                else:
                    # Null, empty list, or not a list - still show the document entry with "not available" message
                    documents.append({
                        "key": key,
                        "label": label,
                        "file_path": None,
                        "type": doc_type,
                        "missing_message": missing_message,
                    })
            else:
                # Single document - value should be the file path (string)
                # For JSON type documents, if value is a dict/object, we can't use it as a file path
                # But we still add the document entry so it shows in the UI
                file_path = None
                raw_value = None  # For inline JSON/markdown data
                
                if value and isinstance(value, str):
                    file_path = value
                elif value and isinstance(value, (dict, list)) and doc_type == "json":
                    # For JSON documents, if the value is a dict/list, store it as raw_value
                    # The frontend can render this directly
                    raw_value = value
                    file_path = None
                    self.logger.debug(
                        "Document '{}' has inline JSON data (not a file path). Storing as raw_value.",
                        key
                    )
                elif value and isinstance(value, str) and doc_type == "markdown":
                    # For markdown, if value is a string, it could be inline markdown content
                    # But typically markdown documents are files, so we treat string as file_path
                    file_path = value
                
                # Always include document entry - even if file_path is None, it will show "not available" message
                # or can be rendered from raw_value
                doc_entry = {
                    "key": key,
                    "label": label,
                    "file_path": file_path,
                    "type": doc_type,
                    "missing_message": missing_message,
                }
                # Include raw_value if it's inline JSON data
                if raw_value is not None:
                    doc_entry["raw_value"] = raw_value
                
                documents.append(doc_entry)
                
                self.logger.debug(
                    "Added document '{}' with file_path: {} (type: {})",
                    key,
                    file_path,
                    doc_type
                )
        
        self.logger.debug(
            "Document extraction complete. Extracted {} documents: {}",
            len(documents),
            [d.get("key") for d in documents]
        )
        return documents
    
    def _extract_detail_view_data(
        self,
        upstream: Dict[str, Any],
        detail_view_config: Dict[str, Any],
        case_config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Extract fields for detail view display"""
        from topaz_agent_kit.utils.expression_evaluator import evaluate_expression
        
        data = {"sections": []}
        
        sections = detail_view_config.get("sections", [])
        for section_config in sections:
            # Evaluate condition if present - skip section if condition is false
            condition = section_config.get("condition")
            if condition:
                try:
                    # Log available agents in upstream for debugging
                    available_agents = [k for k in upstream.keys() if not k.startswith("_")]
                    self.logger.debug(
                        "Evaluating condition '{}' for section '{}'",
                        condition,
                        section_config.get("id") or section_config.get("title") or section_config.get("name")
                    )
                    # Build context with agents at top level (same pattern as other conditions)
                    context: Dict[str, Any] = {"upstream": upstream}
                    for agent_id, agent_data in upstream.items():
                        if not agent_id.startswith("_"):
                            if isinstance(agent_data, dict):
                                parsed = agent_data.get("parsed", agent_data)
                                context[agent_id] = parsed if parsed else None
                            else:
                                context[agent_id] = agent_data
                    
                    condition_result = evaluate_expression(condition, context)
                    if not condition_result:
                        self.logger.debug(
                            "Skipping section '{}' - condition '{}' evaluated to False",
                            section_config.get("id") or section_config.get("title") or section_config.get("name"),
                            condition
                        )
                        continue
                except Exception as e:
                    self.logger.warning(
                        "Failed to evaluate condition '{}' for section '{}': {}. Skipping section.",
                        condition,
                        section_config.get("id") or section_config.get("title") or section_config.get("name"),
                        e
                    )
                    continue
            
            section = {
                "id": section_config.get("id", ""),
                "title": section_config.get("title") or section_config.get("name", ""),  # Support both "title" and "name"
                "fields": [],
            }
            # Preserve columns property if present (for frontend column layout)
            if "columns" in section_config:
                section["columns"] = section_config["columns"]
            
            # Only use explicit fields - don't include all source_agent fields
            # source_agent is just for reference/documentation, explicit fields define what to show
            explicit_fields = section_config.get("fields", [])
            
            # If no explicit fields but source_agent is specified, include all outputs from that agent
            # (fallback for backwards compatibility)
            if not explicit_fields:
                source_agent = section_config.get("source_agent")
                if source_agent and source_agent in upstream:
                    agent_output = upstream[source_agent]
                    if isinstance(agent_output, dict):
                        for key, value in agent_output.items():
                            section["fields"].append({
                                "key": key,
                                "value": value,
                                "label": self._format_label(key),
                                "type": "auto",
                            })
            else:
                # Use only explicit fields
                for field_config_raw in explicit_fields:
                    # Resolve field reference (if it's a reference to centralized fields)
                    field_config = self._resolve_field_reference(field_config_raw, case_config)
                    
                    # Evaluate field-level condition if present
                    field_condition = field_config.get("condition")
                    if field_condition:
                        try:
                            from topaz_agent_kit.utils.expression_evaluator import evaluate_expression
                            # Build context with agents at top level (same pattern as list view)
                            # This enables conditions like "covenant_document_classifier.document_type == 'change_order'"
                            context: Dict[str, Any] = {"upstream": upstream}
                            for agent_id, agent_data in upstream.items():
                                if not agent_id.startswith("_"):
                                    if isinstance(agent_data, dict):
                                        parsed = agent_data.get("parsed", agent_data)
                                        context[agent_id] = parsed if parsed else None
                                    else:
                                        context[agent_id] = agent_data
                            
                            condition_result = evaluate_expression(field_condition, context)
                            if not condition_result:
                                self.logger.debug(
                                    "Skipping section field '{}' - condition '{}' evaluated to False",
                                    field_config.get("label") or field_config.get("key") or field_config.get("field"),
                                    field_condition
                                )
                                continue
                        except Exception as e:
                            self.logger.warning(
                                "Failed to evaluate condition '{}' for section field '{}': {}. Skipping field.",
                                field_condition,
                                field_config.get("label") or field_config.get("key") or field_config.get("field"),
                                e
                            )
                            continue
                    
                    # Support both "source" and "field" keys for field path
                    source = field_config.get("source") or field_config.get("field")
                    
                    # Special handling for entry_comparison type - construct comparison object
                    field_type = field_config.get("type", "text")
                    if field_type == "entry_comparison":
                        original_field = field_config.get("original_field")
                        corrected_field = field_config.get("corrected_field")
                        if original_field and corrected_field:
                            original_value = self.extract_field(upstream, original_field)
                            
                            # For corrected_field, support fallback logic if it contains "OR"
                            # Try each option in order until one returns a non-None value
                            if " OR " in corrected_field.upper():
                                # Split by " OR " and try each path
                                corrected_options = [f.strip() for f in corrected_field.split(" OR ") if f.strip()]
                                corrected_value = None
                                for option in corrected_options:
                                    corrected_value = self.extract_field(upstream, option)
                                    if corrected_value is not None:
                                        break
                                # If all options returned None, use original_value as fallback
                                if corrected_value is None:
                                    corrected_value = original_value
                            else:
                                corrected_value = self.extract_field(upstream, corrected_field)
                                # If corrected_value is None, fall back to original_value
                                if corrected_value is None:
                                    corrected_value = original_value
                            
                            # Only create comparison if original_value is not None
                            # (corrected_value can be None if no corrections were made, that's fine)
                            if original_value is None:
                                self.logger.debug(
                                    "Skipping entry_comparison field '{}' - original_value is None",
                                    field_config.get("label") or field_config.get("key")
                                )
                                continue
                            
                            # Construct comparison object
                            value = {
                                "original": original_value,
                                "corrected": corrected_value
                            }
                            key = field_config.get("key", "entry_comparison")
                        else:
                            # If comparison fields not specified, skip
                            self.logger.warning(
                                "entry_comparison field '{}' requires both original_field and corrected_field. Skipping.",
                                field_config.get("label") or field_config.get("key")
                            )
                            continue
                    elif source:
                        key = field_config.get("key", source.split(".")[-1])
                        # Use extract_field to support both simple paths and expressions
                        value = self.extract_field(upstream, source)
                    else:
                        # No source and not a comparison field - skip
                        continue
                    
                    # Include fields even if value is None, so UI can show "—" instead of "No fields in this section"
                    # This helps users understand what fields are expected vs. what's missing
                    # Only skip if it's a key-only reference (no field path) and value is None
                    is_key_only_reference = field_config.get("key") and not (field_config.get("field") or field_config.get("source"))
                    if value is None and is_key_only_reference:
                        self.logger.debug(
                            "Skipping field '{}' - key-only reference with None value",
                            field_config.get("label") or field_config.get("key")
                        )
                        continue
                    # For all other fields (with explicit paths or centralized field references), include them even if None
                    # The UI will show "—" for None values, which is better than showing "No fields in this section"
                    
                    # Store original value before mapping (needed for icon/color matching)
                    original_value = value
                    
                    # Apply value mapping if specified
                    mapped_value = self._apply_value_mapping(value, field_config.get("value_mapping"))
                    
                    field_data = {
                        "key": key,
                        "value": mapped_value,  # Mapped value for display
                        "original_value": original_value,  # Original value for icon/color matching
                        "label": field_config.get("label", self._format_label(key)),
                        "type": field_type,
                        # Include display configuration from YAML
                        "value_mapping": field_config.get("value_mapping"),
                        "color_mapping": field_config.get("color_mapping"),
                        "icon_mapping": field_config.get("icon_mapping"),
                        "text_transform": field_config.get("text_transform"),
                        "text_transform_options": field_config.get("text_transform_options"),
                        "decimals": field_config.get("decimals"),
                        "format": field_config.get("format"),  # Include format field (e.g., "table" for list fields)
                    }
                    # Pass through UI metadata (collapsible, summary, full_width, etc.)
                    if "collapsible" in field_config:
                        field_data["collapsible"] = field_config["collapsible"]
                    if "collapsible_after" in field_config:
                        field_data["collapsible_after"] = field_config["collapsible_after"]
                    if "summary" in field_config:
                        field_data["summary"] = field_config["summary"]
                    if "full_width" in field_config:
                        field_data["full_width"] = field_config["full_width"]
                    section["fields"].append(field_data)
            
            # Only add section if it has fields (prevents "No fields in this section" messages)
            # This can happen if:
            # 1. Section condition evaluated to True but all fields were filtered out
            # 2. All fields had None values and were skipped (before fix)
            # 3. All fields had field-level conditions that evaluated to False
            if section["fields"]:
                data["sections"].append(section)
            else:
                self.logger.debug(
                    "Skipping section '{}' - no fields after filtering",
                    section.get("title") or section.get("name") or section.get("id")
                )
        
        return data
    
    def _get_nested_value(
        self,
        data: Dict[str, Any],
        path: str,
    ) -> Any:
        """
        Get a nested value from a dictionary using dot-notation path.
        
        Handles agent outputs that may be wrapped in "parsed" or "result" keys.
        For paths like "agent_id.field", tries:
        1. data["agent_id"]["field"] (direct)
        2. data["agent_id"]["parsed"]["field"] (parsed wrapper)
        3. data["agent_id"]["result"]["field"] (result wrapper)
        
        Args:
            data: The dictionary to extract from
            path: Dot-notation path like "agent_id.field" or "agent_id.nested.field"
            
        Returns:
            The value at the path or None if not found
        """
        if not path or not data:
            return None
        
        parts = path.split(".")
        if len(parts) < 2:
            return None
        
        agent_id = parts[0]
        field_path = parts[1:]
        
        # Get agent output from upstream
        agent_output = data.get(agent_id)
        if agent_output is None:
            return None
        
        # IMPORTANT: Try "parsed" wrapper FIRST, as it contains the normalized agent output
        # The "result" wrapper contains raw output and should only be used as fallback
        # This ensures we get the correct extracted value (e.g., math_calculator.result from parsed.result)
        # instead of the raw result wrapper
        if isinstance(agent_output, dict) and "parsed" in agent_output:
            current = agent_output["parsed"]
            for part in field_path:
                if isinstance(current, dict):
                    current = current.get(part)
                elif isinstance(current, list) and part.isdigit():
                    index = int(part)
                    if 0 <= index < len(current):
                        current = current[index]
                    else:
                        current = None
                else:
                    current = None
                
                if current is None:
                    break
            
            if current is not None:
                return current
        
        # If not found in parsed, try direct path (for backwards compatibility)
        current = agent_output
        for part in field_path:
            if isinstance(current, dict):
                current = current.get(part)
            elif isinstance(current, list) and part.isdigit():
                index = int(part)
                if 0 <= index < len(current):
                    current = current[index]
                else:
                    current = None
            else:
                current = None
            
            if current is None:
                break
        
        if current is not None:
            return current
        
        # If still not found, try "result" wrapper
        if isinstance(agent_output, dict) and "result" in agent_output:
            current = agent_output["result"]
            for part in field_path:
                if isinstance(current, dict):
                    current = current.get(part)
                elif isinstance(current, list) and part.isdigit():
                    index = int(part)
                    if 0 <= index < len(current):
                        current = current[index]
                    else:
                        current = None
                else:
                    current = None
                
                if current is None:
                    break
            
            if current is not None:
                return current
        
        # Special case: if field_path is just a single field name and agent_output is a dict,
        # check if that field exists as a top-level key (handles cases where parsed wrapper doesn't exist)
        # BUT only if we haven't already found it in parsed/result wrappers above
        # This is a fallback for edge cases where agent output structure is different
        if isinstance(agent_output, dict) and len(field_path) == 1:
            field_name = field_path[0]
            # Only check top-level if field_name exists and we haven't found it yet
            # This prevents returning wrong values when parsed wrapper exists
            if field_name in agent_output:
                # Double-check: if parsed exists and contains the field, we should have found it above
                # This is just a safety fallback
                if "parsed" not in agent_output or field_name not in agent_output.get("parsed", {}):
                    return agent_output[field_name]
        
        return None
    
    def _get_referenced_agents(
        self,
        case_config: Dict[str, Any],
    ) -> set:
        """Get all agent IDs referenced in the case config"""
        agents = set()
        
        def extract_from_source(source: str):
            if not source:
                return
            
            # Check if source is an expression (contains ternary operator)
            if " if " in source and " else " in source:
                # Extract agent names from expression
                # Match patterns like "agent_id.field" where agent_id is an identifier
                agent_pattern = r'([a-zA-Z_][a-zA-Z0-9_]*)\.'
                matches = re.findall(agent_pattern, source)
                for agent_id in matches:
                    agents.add(agent_id)
            elif "." in source:
                # Simple dot-notation path
                agents.add(source.split(".")[0])
        
        # Identity
        identity = case_config.get("identity", {})
        extract_from_source(identity.get("id_source", ""))
        
        # Detail view - read from views.detail.tabs_config.data structure
        views_config = case_config.get("views", {})
        detail_view_config = views_config.get("detail", {})
        tabs_config = detail_view_config.get("tabs_config", {}) if detail_view_config else {}
        data_tab_config = tabs_config.get("data", {})
        data_sections = data_tab_config.get("sections", []) if isinstance(data_tab_config, dict) else []
        for section in data_sections:
            if section.get("source_agent"):
                agents.add(section["source_agent"])
            for field in section.get("fields", []):
                # Support both "field" and "source" keys (field is used in case configs)
                source = field.get("field", "") or field.get("source", "")
                extract_from_source(source)
        
        # List view - read from views.list structure
        list_view = views_config.get("list", {})
        # New structure: pipeline_fields
        for field_config in list_view.get("pipeline_fields", []):
            source = field_config.get("field", "") or field_config.get("source", "")
            extract_from_source(source)
        # Legacy support
        for field_config in list_view.get("fields", []):
            source = field_config.get("field", "") or field_config.get("source", "")
            extract_from_source(source)
        primary = list_view.get("primary", {})
        if primary:
            source = primary.get("field", "") or primary.get("source", "")
            extract_from_source(source)
        for field_config in list_view.get("secondary", []):
            source = field_config.get("field", "") or field_config.get("source", "")
            extract_from_source(source)
        
        # Documents - read from views.detail.tabs_config.documents structure
        documents_config = tabs_config.get("documents", {})
        documents_sections = documents_config.get("sections", []) if isinstance(documents_config, dict) else []
        for doc_config in documents_sections:
            source = doc_config.get("field", "")
            extract_from_source(source)
        
        # Review response outcome - read from views.detail.tabs_config.review_response_outcome structure
        review_response_outcome_config = tabs_config.get("review_response_outcome", {})
        review_response_outcome_sections = review_response_outcome_config.get("sections", []) if isinstance(review_response_outcome_config, dict) else []
        for section in review_response_outcome_sections:
            if section.get("source_agent"):
                agents.add(section["source_agent"])
            for field in section.get("fields", []):
                # Support both "field" and "source" keys (field is used in case configs)
                source = field.get("field", "") or field.get("source", "")
                extract_from_source(source)
                # Also check for original_field and corrected_field (for entry_comparison type)
                original_field = field.get("original_field")
                corrected_field = field.get("corrected_field")
                if original_field:
                    extract_from_source(original_field)
                if corrected_field:
                    extract_from_source(corrected_field)
        
        # Grouping - extract agents from grouping_key_expression and summary_fields
        # Read from views.grouped structure
        views_config = case_config.get("views", {})
        grouped_view_config = views_config.get("grouped", {})
        
        # Read grouping_key_expression from views.grouped
        grouping_key_expression = grouped_view_config.get("grouping_key_expression", "") if grouped_view_config else ""
        extract_from_source(grouping_key_expression)
        
        # Also check summary_fields in views.grouped
        summary_fields = grouped_view_config.get("summary_fields", []) if grouped_view_config else []
        for field_config in summary_fields:
            source = field_config.get("field", "")
            extract_from_source(source)
        
        return agents
    
    def _format_label(self, key: str) -> str:
        """Convert snake_case or camelCase to Title Case label"""
        # Handle snake_case
        if "_" in key:
            words = key.split("_")
        # Handle camelCase
        elif any(c.isupper() for c in key):
            words = re.findall(r'[A-Z]?[a-z]+|[A-Z]+(?=[A-Z]|$)', key)
        else:
            words = [key]
        
        return " ".join(word.capitalize() for word in words)
    
    def _apply_value_mapping(self, value: Any, value_mapping: Optional[Dict[str, str]]) -> Any:
        """Apply value mapping to transform display values.
        
        Args:
            value: The raw value to map
            value_mapping: Dictionary mapping raw values to display values
            
        Returns:
            Mapped value if mapping exists, otherwise original value
        """
        if not value_mapping or value is None:
            return value
        
        # Try exact match first (handles both string and integer keys)
        # Check if value itself is a key (handles integer keys like 1, 0)
        if value in value_mapping:
            return value_mapping[value]
        
        # Convert value to string for lookup (handles both string and other types)
        value_str = str(value) if value is not None else None
        
        # Check if string version exists as key
        if value_str in value_mapping:
            return value_mapping[value_str]
        
        # Check case-insensitive match
        value_lower = value_str.lower() if value_str else None
        for raw_key, display_value in value_mapping.items():
            # Convert key to string for comparison (handles integer keys like 1, 0)
            raw_key_str = str(raw_key)
            if raw_key_str.lower() == value_lower:
                return display_value
        
        # No mapping found, return original value
        return value
    
    def _extract_timeline_config(
        self,
        upstream: Dict[str, Any],
        timeline_config: Dict[str, Any],
        case_config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Extract timeline configuration for frontend rendering.
        
        This method:
        1. Processes system events configuration (from _timeline array)
        2. Generates custom events from agent outputs based on configuration
        3. Applies formatting, value mapping, etc.
        
        Args:
            upstream: The upstream context containing all agent outputs
            timeline_config: Timeline configuration from case YAML
            case_config: Full case configuration
            
        Returns:
            Timeline configuration with resolved custom events
        """
        # Process system events - extract details like we do for custom events
        system_events_config = timeline_config.get("system_events", {})
        resolved_system_events = {}
        for event_type, event_config in system_events_config.items():
            # Extract details for system events (same as custom events)
            details = []
            details_config = event_config.get("details", [])
            for detail_config in details_config:
                # Resolve field reference if this is a reference to centralized fields
                resolved_detail_config = self._resolve_field_reference(detail_config, case_config)
                
                # Evaluate field-level condition if present
                # This allows conditional display of details within timeline events
                detail_condition = resolved_detail_config.get("condition")
                if detail_condition:
                    try:
                        from topaz_agent_kit.utils.expression_evaluator import evaluate_expression
                        # Build context for condition evaluation (same pattern as other conditions)
                        condition_context: Dict[str, Any] = {"upstream": upstream}
                        for agent_id, agent_data in upstream.items():
                            if not agent_id.startswith("_"):
                                if isinstance(agent_data, dict):
                                    parsed = agent_data.get("parsed", agent_data)
                                    condition_context[agent_id] = parsed if parsed else None
                                else:
                                    condition_context[agent_id] = agent_data
                        
                        condition_result = evaluate_expression(detail_condition, condition_context)
                        if not condition_result:
                            self.logger.debug(
                                "Skipping timeline detail '{}' - condition '{}' not met",
                                resolved_detail_config.get("label") or resolved_detail_config.get("field"),
                                detail_condition
                            )
                            continue  # Skip this detail if condition is not met
                    except Exception as exc:
                        self.logger.debug(
                            "Condition evaluation failed for timeline detail '{}': {}, skipping",
                            resolved_detail_config.get("label") or resolved_detail_config.get("field"),
                            exc
                        )
                        continue  # On error, skip the detail
                
                # Get field path - could be from 'field' or from resolved config
                detail_field = resolved_detail_config.get("field")
                if not detail_field:
                    continue
                
                detail_value = self.extract_field(upstream, detail_field)
                
                # Support both 'format' and 'type' (for compatibility - YAML uses 'type', but we standardize to 'format')
                detail_format = resolved_detail_config.get("format") or resolved_detail_config.get("type") or "text"
                
                # If value extraction failed, still include the detail config (without value)
                # so frontend can try to extract from case_data or use the config for display
                # This is important for cases where the agent output wasn't stored in case_data
                if detail_value is None:
                    # Include detail config even without value - frontend will try to extract
                    # Preserve the 'key' reference if present (for centralized field resolution)
                    detail_item = {
                        "field": detail_field,
                        "label": resolved_detail_config.get("label", ""),
                        "format": detail_format,
                        "decimals": resolved_detail_config.get("decimals"),
                        "value_mapping": resolved_detail_config.get("value_mapping"),  # Include for frontend
                        "color_mapping": resolved_detail_config.get("color_mapping"),
                        "icon_mapping": resolved_detail_config.get("icon_mapping"),
                        "text_transform": resolved_detail_config.get("text_transform"),
                        "text_transform_options": resolved_detail_config.get("text_transform_options"),
                        "collapsible": resolved_detail_config.get("collapsible", False),
                        "condition": resolved_detail_config.get("condition"),  # Include condition for frontend filtering
                    }
                    # Preserve 'key' if it was in the original detail_config (for centralized field reference)
                    if detail_config.get("key"):
                        detail_item["key"] = detail_config.get("key")
                    details.append(detail_item)
                    continue
                
                # Store original value before mapping (needed for icon_mapping and color_mapping matching)
                original_value = detail_value
                
                # Apply value mapping if specified (from resolved config)
                mapped_value = self._apply_value_mapping(
                    detail_value,
                    resolved_detail_config.get("value_mapping")
                )
                
                # Support both 'format' and 'type' (for compatibility - YAML uses 'type', but we standardize to 'format')
                detail_format = resolved_detail_config.get("format") or resolved_detail_config.get("type") or "text"
                detail_type = resolved_detail_config.get("type") or resolved_detail_config.get("format") or "text"
                
                details.append({
                    "field": detail_field,
                    "label": resolved_detail_config.get("label", ""),
                    "value": mapped_value,  # Mapped value for display
                    "original_value": original_value,  # Original value for icon/color mapping matching
                    "format": detail_format,
                    "type": detail_type,  # Include type field for frontend to detect list types even when format is different
                    "decimals": resolved_detail_config.get("decimals"),
                    "value_mapping": resolved_detail_config.get("value_mapping"),  # Include for frontend
                    "color_mapping": resolved_detail_config.get("color_mapping"),
                    "icon_mapping": resolved_detail_config.get("icon_mapping"),
                    "text_transform": resolved_detail_config.get("text_transform"),
                    "text_transform_options": resolved_detail_config.get("text_transform_options"),
                    "collapsible": resolved_detail_config.get("collapsible", False),
                    "condition": resolved_detail_config.get("condition"),  # Include condition for frontend filtering
                })
            
            # Build resolved system event with extracted details
            resolved_system_events[event_type] = {
                **event_config,  # Keep all original config (label, icon, color, etc.)
                "details": details,  # Add extracted details
            }
        
        resolved_config = {
            "sort_order": timeline_config.get("sort_order", "desc"),
            "order": timeline_config.get("order", []),  # Preserve order array for frontend sorting
            "system_events": resolved_system_events,  # Use resolved system events with extracted details
            "custom_events": [],
            "display": timeline_config.get("display", {}),
        }
        
        # Process custom events from agent outputs
        custom_events_config = timeline_config.get("custom_events", [])
        
        for event_config in custom_events_config:
            source_field = event_config.get("source_field")
            if not source_field:
                continue
            
            # Check if source field exists in upstream
            # First try direct access (for simple agent IDs like "midas_assessor")
            # _get_nested_value requires at least 2 parts (agent_id.field), so simple agent IDs won't work
            source_value = None
            if source_field in upstream:
                source_value = upstream[source_field]
            else:
                # Try using extract_field for nested paths (e.g., "agent_id.field")
                source_value = self.extract_field(upstream, source_field)
            
            # Consider empty dict as "not found" - we want actual data
            # But if it's a dict with "parsed" key, check if parsed has data
            if source_value is None:
                continue
            
            # For dict values, check if they have actual data
            if isinstance(source_value, dict):
                # Check if it's an empty dict
                if len(source_value) == 0:
                    continue
                # If it has "parsed" key, check if parsed has data
                if "parsed" in source_value:
                    parsed_value = source_value.get("parsed")
                    if parsed_value is None:
                        continue
                    if isinstance(parsed_value, dict) and len(parsed_value) == 0:
                        continue
                    # Use parsed value as the source value for detail extraction
                    source_value = parsed_value
                # If no "parsed" key, use the dict itself (it might be the actual agent output)
            
            # Check condition if present
            condition = event_config.get("condition")
            if condition:
                try:
                    from topaz_agent_kit.utils.expression_evaluator import evaluate_expression
                    # Strip Jinja2-style {{ }} syntax if present
                    # Handle both full condition wrapped in {{ }} and variables within {{ }}
                    condition_clean = condition.strip()
                    
                    # If entire condition is wrapped: {{ condition }}
                    if condition_clean.startswith("{{") and condition_clean.endswith("}}"):
                        condition_clean = condition_clean[2:-2].strip()
                    else:
                        # Replace {{ variable }} with just variable throughout the condition
                        # e.g., "{{ midas_assessor }} IS NOT NULL" -> "midas_assessor IS NOT NULL"
                        condition_clean = re.sub(r'\{\{\s*([^}]+)\s*\}\}', r'\1', condition_clean)
                    
                    context = {"upstream": upstream}
                    # Also expose upstream agents at top level for shorthand resolution
                    context.update({k: v for k, v in upstream.items() if not k.startswith("_")})
                    condition_result = evaluate_expression(condition_clean, context)
                    if not condition_result:
                        continue
                except Exception as e:
                    # Silently skip on condition evaluation error
                    continue
            
            # Determine timestamp
            timestamp_source = event_config.get("timestamp_source", "case_created")
            timestamp = None
            if timestamp_source == "case_created":
                # Will be set by frontend using case.created_at
                timestamp = None
            elif timestamp_source == "case_updated":
                # Will be set by frontend using case.updated_at
                timestamp = None
            else:
                # Try to extract from field path
                timestamp = self.extract_field(upstream, timestamp_source)
                
                # If not found and source_field is an agent ID, try to get _executed_at from agent output
                if not timestamp and source_field:
                    # Check if source_field is directly in upstream (agent ID)
                    if source_field in upstream:
                        agent_data = upstream[source_field]
                        if isinstance(agent_data, dict):
                            # Try to get _executed_at from the agent's output
                            timestamp = agent_data.get("_executed_at")
                            if not timestamp and "parsed" in agent_data:
                                parsed = agent_data["parsed"]
                                if isinstance(parsed, dict):
                                    timestamp = parsed.get("_executed_at")
                
                # If still not found and timestamp_source contains "_executed_at", 
                # this is likely an old case without agent timestamps
                # Set timestamp to None so frontend can use fallback (case_updated)
                if not timestamp and "_executed_at" in timestamp_source:
                    # Old case - will fallback to case_updated in frontend
                    timestamp = None
            
            # Extract details
            details = []
            details_config = event_config.get("details", [])
            for detail_config in details_config:
                # Resolve field reference if this is a reference to centralized fields
                resolved_detail_config = self._resolve_field_reference(detail_config, case_config)
                
                # Evaluate field-level condition if present
                # This allows conditional display of details within custom timeline events
                detail_condition = resolved_detail_config.get("condition")
                if detail_condition:
                    try:
                        from topaz_agent_kit.utils.expression_evaluator import evaluate_expression
                        # Build context for condition evaluation (same pattern as other conditions)
                        condition_context: Dict[str, Any] = {"upstream": upstream}
                        for agent_id, agent_data in upstream.items():
                            if not agent_id.startswith("_"):
                                if isinstance(agent_data, dict):
                                    parsed = agent_data.get("parsed", agent_data)
                                    condition_context[agent_id] = parsed if parsed else None
                                else:
                                    condition_context[agent_id] = agent_data
                        
                        condition_result = evaluate_expression(detail_condition, condition_context)
                        if not condition_result:
                            self.logger.debug(
                                "Skipping custom event detail '{}' - condition '{}' not met",
                                resolved_detail_config.get("label") or resolved_detail_config.get("field"),
                                detail_condition
                            )
                            continue  # Skip this detail if condition is not met
                    except Exception as exc:
                        self.logger.debug(
                            "Condition evaluation failed for custom event detail '{}': {}, skipping",
                            resolved_detail_config.get("label") or resolved_detail_config.get("field"),
                            exc
                        )
                        continue  # On error, skip the detail
                
                # Get field path - could be from 'field' or from resolved config
                detail_field = resolved_detail_config.get("field")
                if not detail_field:
                    continue
                
                detail_value = self.extract_field(upstream, detail_field)
                if detail_value is None:
                    continue
                
                # Store original value before mapping (needed for icon_mapping and color_mapping matching)
                original_value = detail_value
                
                # Apply value mapping if specified (from resolved config)
                mapped_value = self._apply_value_mapping(
                    detail_value,
                    resolved_detail_config.get("value_mapping")
                )
                
                # Support both 'format' and 'type' (for compatibility - YAML uses 'type', but we standardize to 'format')
                detail_format = resolved_detail_config.get("format") or resolved_detail_config.get("type") or "text"
                detail_type = resolved_detail_config.get("type") or resolved_detail_config.get("format") or "text"
                
                details.append({
                    "field": detail_field,
                    "label": resolved_detail_config.get("label", ""),
                    "value": mapped_value,  # Mapped value for display
                    "original_value": original_value,  # Original value for icon/color mapping matching
                    "format": detail_format,
                    "type": detail_type,  # Include type field for frontend to detect list types even when format is different
                    "decimals": resolved_detail_config.get("decimals"),
                    "value_mapping": resolved_detail_config.get("value_mapping"),  # Include for frontend
                    "color_mapping": resolved_detail_config.get("color_mapping"),
                    "icon_mapping": resolved_detail_config.get("icon_mapping"),
                    "text_transform": resolved_detail_config.get("text_transform"),
                    "text_transform_options": resolved_detail_config.get("text_transform_options"),
                    "collapsible": resolved_detail_config.get("collapsible", False),
                    "condition": resolved_detail_config.get("condition"),  # Include condition for frontend filtering
                })
            
            # Build resolved custom event
            resolved_event = {
                "type": f"custom_{source_field}",
                "label": event_config.get("label", ""),
                "icon": event_config.get("icon", "Circle"),
                "color": event_config.get("color", "zinc"),
                "timestamp_source": timestamp_source,
                "source_field": source_field,
                "show_details": event_config.get("show_details", False),
                "details": details,
            }
            
            resolved_config["custom_events"].append(resolved_event)
        
        return resolved_config