"""
Case Manager Module

Manages pipeline cases - tracking ALL cases (both HITL and straight-through).
Handles case creation, updates, and status transitions.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from topaz_agent_kit.core.chat_database import ChatDatabase
from topaz_agent_kit.core.case_data_extractor import CaseDataExtractor
from topaz_agent_kit.core.grouping_extractor import GroupingExtractor
from topaz_agent_kit.core.grouping_aggregator import GroupingAggregator
from topaz_agent_kit.utils.logger import Logger


class CaseManager:
    """
    Manages pipeline cases in the database.
    
    This class is responsible for:
    - Creating case entries for ALL pipeline iterations
    - Extracting and storing case display data
    - Updating case status throughout the pipeline lifecycle
    - Querying cases with filters
    """
    
    # Case status constants
    STATUS_PROCESSING = "processing"
    STATUS_HITL_PENDING = "hitl_pending"
    STATUS_COMPLETED = "completed"
    STATUS_FAILED = "failed"
    
    def __init__(self, database: ChatDatabase):
        """
        Initialize CaseManager.
        
        Args:
            database: ChatDatabase instance for persistence
        """
        self.database = database
        self.extractor = CaseDataExtractor()
        self.grouping_extractor = GroupingExtractor()
        self.grouping_aggregator = GroupingAggregator()
        self.logger = Logger("CaseManager")
    
    def create_case(
        self,
        pipeline_id: str,
        run_id: str,
        upstream: Dict[str, Any],
        case_config: Dict[str, Any],
        session_id: Optional[str] = None,
        case_type: Optional[str] = None,
        current_step: Optional[str] = None,
        fallback_case_id: Optional[str] = None,
        initial_status: Optional[str] = None,
    ) -> Optional[str]:
        """
        Create a new case entry.
        
        Args:
            pipeline_id: The pipeline identifier
            run_id: The current run ID
            upstream: The upstream context with agent outputs
            case_config: The case configuration for data extraction
            session_id: Optional session ID
            case_type: Optional case type (e.g., "invoice", "order")
            current_step: Optional current step/agent ID
            fallback_case_id: Fallback ID if extraction fails
            
        Returns:
            The created case_id (unique) or None if failed
        """
        # Extract case_id using normal extraction (no sequential IDs for grouping)
        case_id = self.extractor.extract_case_id(
            upstream=upstream,
            case_config=case_config,
            fallback_id=fallback_case_id,
        )
        
        # Check if case already exists (important for deterministic case_ids like invoice_id)
        existing_case = self.get_case(case_id)
        if existing_case:
            self.logger.info(
                "Case {} already exists, reusing existing case (status: {})",
                case_id, existing_case.get("status", "unknown")
            )
            # Update case data if needed (merge new data with existing)
            # This ensures case_data is up-to-date even if case already exists
            # Only store raw agent outputs and documents, not display metadata
            # Build case_meta from existing case for template rendering
            case_meta = {
                "case_id": existing_case.get("case_id"),
                "display_id": existing_case.get("display_id"),
                "pipeline_id": existing_case.get("pipeline_id"),
                "status": existing_case.get("status"),
                "hitl_gate_title": existing_case.get("hitl_gate_title"),
                "hitl_description": existing_case.get("hitl_description"),
                "hitl_status": existing_case.get("hitl_status"),
                "hitl_decision": existing_case.get("hitl_decision"),
                "responded_by": existing_case.get("responded_by"),
                "created_at": existing_case.get("created_at"),
                "updated_at": existing_case.get("updated_at"),
            }
            full_case_data = self.extractor.extract_case_data(
                upstream=upstream,
                case_config=case_config,
                case_meta=case_meta,
            )
            
            # Store only raw data (agent outputs + documents + timeline), not display metadata
            case_data = {}
            if "_documents" in full_case_data:
                case_data["_documents"] = full_case_data["_documents"]
            if "_timeline" in full_case_data:
                case_data["_timeline"] = full_case_data["_timeline"]
            for key, value in full_case_data.items():
                if not key.startswith("_"):  # Raw agent outputs
                    case_data[key] = value
            
            existing_case_data = existing_case.get("case_data", {})
            merged_case_data = self._deep_merge_case_data(existing_case_data, case_data)
            
            # Update case data and status if initial_status was provided
            updates = {"case_data": merged_case_data}
            if initial_status:
                updates["status"] = initial_status
            if current_step:
                updates["current_step"] = current_step
            
            self.database.update_pipeline_case(case_id=case_id, updates=updates)
            return case_id
        
        # display_id is the same as case_id (kept for backwards compatibility with database)
        display_id = case_id
        
        # Extract case data - but only store raw agent outputs and documents
        # Display metadata (_list_view, _detail_view, _detail_view_modal) will be
        # re-extracted on read from current YAML config
        # Build case_meta for template rendering (case_id and pipeline_id are known at creation)
        case_meta = {
            "case_id": case_id,
            "display_id": display_id,
            "pipeline_id": pipeline_id,
            "status": initial_status or self.STATUS_PROCESSING,
        }
        full_case_data = self.extractor.extract_case_data(
            upstream=upstream,
            case_config=case_config,
            case_meta=case_meta,
        )
        
        # Store raw data (agent outputs + documents + timeline) AND display metadata
        # Display metadata is stored at creation for immediate availability, but will be
        # re-extracted on read to reflect YAML changes
        case_data = {}
        # Keep documents (data, not display config)
        if "_documents" in full_case_data:
            case_data["_documents"] = full_case_data["_documents"]
        # Keep timeline (data, not display config)
        if "_timeline" in full_case_data:
            case_data["_timeline"] = full_case_data["_timeline"]
        # Keep display metadata (_list_view, _detail_view, etc.) - stored at creation for immediate use
        # Will be re-extracted on read to reflect YAML changes
        if "_list_view" in full_case_data:
            case_data["_list_view"] = full_case_data["_list_view"]
        if "_detail_view" in full_case_data:
            case_data["_detail_view"] = full_case_data["_detail_view"]
        if "_detail_view_modal" in full_case_data:
            case_data["_detail_view_modal"] = full_case_data["_detail_view_modal"]
        if "_detail_view_tabs" in full_case_data:
            case_data["_detail_view_tabs"] = full_case_data["_detail_view_tabs"]
        # Keep raw agent outputs (needed for field extraction)
        for key, value in full_case_data.items():
            if not key.startswith("_"):  # Raw agent outputs (e.g., midas_assessor, current_item)
                case_data[key] = value
        
        # Determine case type from config if not provided
        if not case_type:
            case_type = case_config.get("case_type", pipeline_id)
        
        # Use provided initial_status, or default to processing (only needed for resume scenarios)
        status = initial_status or self.STATUS_PROCESSING
        
        success = self.database.create_pipeline_case(
            case_id=case_id,
            display_id=display_id,
            pipeline_id=pipeline_id,
            run_id=run_id,
            session_id=session_id,
            case_type=case_type,
            status=status,
            current_step=current_step,
            case_data=case_data,
        )
        
        if success:
            self.logger.info(
                "Created case {} (display: {}) for pipeline {} (run: {})",
                case_id, display_id, pipeline_id, run_id
            )
            # Add timeline entry for case creation
            self._add_timeline_entry(
                case_id=case_id,
                event_type="case_created",
                event_data={
                    "pipeline_id": pipeline_id,
                    "run_id": run_id,
                    "case_type": case_type,
                },
            )
            return case_id
        else:
            self.logger.error("Failed to create case for pipeline {}", pipeline_id)
            return None
    
    def update_case_data(
        self,
        case_id: str,
        upstream: Dict[str, Any],
        case_config: Dict[str, Any],
    ) -> bool:
        """
        Update case data with latest upstream context.
        
        IMPORTANT: This method MERGES new case_data with existing case_data,
        rather than replacing it. This ensures that pre-HITL agent outputs
        (like math_strategist, math_calculator) are preserved when updating
        after a HITL response.
        
        Args:
            case_id: The case ID to update
            upstream: The updated upstream context
            case_config: The case configuration
            
        Returns:
            True if updated successfully
        """
        # Get existing case to preserve existing case_data
        existing_case = self.get_case(case_id)
        existing_case_data = {}
        if existing_case:
            existing_case_data = existing_case.get("case_data", {})
        
        # Extract new case_data from upstream - but only store raw agent outputs and documents
        # Display metadata will be re-extracted on read from current YAML config
        # Build case_meta from existing case for template rendering
        case_meta = {
            "case_id": case_id,
            "display_id": existing_case.get("display_id") if existing_case else case_id,
            "pipeline_id": existing_case.get("pipeline_id") if existing_case else None,
            "status": existing_case.get("status") if existing_case else None,
            "hitl_gate_title": existing_case.get("hitl_gate_title") if existing_case else None,
            "hitl_description": existing_case.get("hitl_description") if existing_case else None,
            "hitl_status": existing_case.get("hitl_status") if existing_case else None,
            "hitl_decision": existing_case.get("hitl_decision") if existing_case else None,
            "responded_by": existing_case.get("responded_by") if existing_case else None,
            "created_at": existing_case.get("created_at") if existing_case else None,
            "updated_at": existing_case.get("updated_at") if existing_case else None,
        }
        full_new_case_data = self.extractor.extract_case_data(
            upstream=upstream,
            case_config=case_config,
            case_meta=case_meta,
        )
        
        # Store only raw data (agent outputs + documents + timeline), not display metadata
        new_case_data = {}
        if "_documents" in full_new_case_data:
            new_case_data["_documents"] = full_new_case_data["_documents"]
        if "_timeline" in full_new_case_data:
            new_case_data["_timeline"] = full_new_case_data["_timeline"]
        for key, value in full_new_case_data.items():
            if not key.startswith("_"):  # Raw agent outputs
                new_case_data[key] = value
        
        # Deep merge: new data updates existing, but doesn't remove existing fields
        # This is critical for HITL cases where pre-HITL agents might not be in
        # the final_upstream after resume (e.g., if they're in sub-pipeline structure)
        # 
        # The merge preserves:
        # - Agent outputs from existing (e.g., math_strategist, math_calculator) that aren't in new upstream
        # - Documents from existing
        # - Adds new agent outputs from new upstream (e.g., math_auditor)
        merged_case_data = self._deep_merge_case_data(existing_case_data, new_case_data)
        
        return self.database.update_pipeline_case(
            case_id=case_id,
            updates={"case_data": merged_case_data},
        )
    
    def _deep_merge_case_data(
        self,
        existing: Dict[str, Any],
        new: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Deep merge two case_data dictionaries.
        
        Strategy:
        - For dicts: Recursively merge
        - For _detail_view.sections: Merge sections by ID/title, merge fields within sections
        - For lists: Replace (new list replaces old) - except for _detail_view.sections
        - For other types: Replace (new value replaces old)
        - Existing keys not in new: Preserve (don't remove)
        
        Args:
            existing: Existing case_data
            new: New case_data to merge in
            
        Returns:
            Merged case_data
        """
        import copy
        result = copy.deepcopy(existing)
        
        for key, new_value in new.items():
            if key in result:
                existing_value = result[key]
                
                # Special handling for _detail_view.sections
                if key == "_detail_view" and isinstance(existing_value, dict) and isinstance(new_value, dict):
                    # Merge _detail_view structure
                    merged_detail_view = self._deep_merge_case_data(existing_value, new_value)
                    
                    # Special handling for sections array
                    if "sections" in existing_value and "sections" in new_value:
                        merged_sections = self._merge_detail_view_sections(
                            existing_value.get("sections", []),
                            new_value.get("sections", [])
                        )
                        merged_detail_view["sections"] = merged_sections
                    
                    result[key] = merged_detail_view
                # If both are dicts, recursively merge
                elif isinstance(existing_value, dict) and isinstance(new_value, dict):
                    result[key] = self._deep_merge_case_data(existing_value, new_value)
                else:
                    # For lists or other types, replace with new value
                    result[key] = copy.deepcopy(new_value)
            else:
                # New key, add it
                result[key] = copy.deepcopy(new_value)
        
        return result
    
    def _merge_detail_view_sections(
        self,
        existing_sections: List[Dict[str, Any]],
        new_sections: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """
        Merge detail view sections intelligently.
        
        Strategy:
        - Merge sections by ID or title
        - If section exists in both: merge fields (preserve existing, add new)
        - If section only in existing: preserve it
        - If section only in new: add it
        
        Args:
            existing_sections: Existing sections from pre-HITL case_data
            new_sections: New sections from post-HITL case_data
            
        Returns:
            Merged sections list
        """
        import copy
        merged = []
        
        # Create a map of existing sections by ID or title
        existing_map = {}
        for section in existing_sections:
            section_id = section.get("id") or section.get("title") or ""
            if section_id:
                existing_map[section_id] = section
        
        # Process new sections
        new_map = {}
        for section in new_sections:
            section_id = section.get("id") or section.get("title") or ""
            if section_id:
                new_map[section_id] = section
        
        # Merge: existing sections that are also in new get merged
        # New sections that don't exist get added
        # Existing sections that don't exist in new get preserved
        all_section_ids = set(existing_map.keys()) | set(new_map.keys())
        
        for section_id in all_section_ids:
            existing_section = existing_map.get(section_id)
            new_section = new_map.get(section_id)
            
            if existing_section and new_section:
                # Both exist: merge fields
                merged_section = copy.deepcopy(existing_section)
                # Merge fields: preserve existing, add new fields
                existing_fields_map = {f.get("key") or f.get("label"): f for f in existing_section.get("fields", [])}
                new_fields = new_section.get("fields", [])
                
                merged_fields = []
                # Add existing fields first
                for field in existing_section.get("fields", []):
                    field_key = field.get("key") or field.get("label")
                    merged_fields.append(copy.deepcopy(field))
                
                # Add new fields that don't exist
                for field in new_fields:
                    field_key = field.get("key") or field.get("label")
                    if field_key not in existing_fields_map:
                        merged_fields.append(copy.deepcopy(field))
                    else:
                        # Field exists: update value if new value is not None
                        existing_field = existing_fields_map[field_key]
                        if field.get("value") is not None:
                            existing_field["value"] = field.get("value")
                
                merged_section["fields"] = merged_fields
                merged.append(merged_section)
            elif existing_section:
                # Only in existing: preserve it
                merged.append(copy.deepcopy(existing_section))
            elif new_section:
                # Only in new: add it
                merged.append(copy.deepcopy(new_section))
        
        return merged
    
    def update_case_status(
        self,
        case_id: str,
        status: str,
        current_step: Optional[str] = None,
    ) -> bool:
        """
        Update case status.
        
        Args:
            case_id: The case ID
            status: New status (processing, hitl_pending, completed, failed)
            current_step: Optional current step
            
        Returns:
            True if updated successfully
        """
        updates = {"status": status}
        if current_step:
            updates["current_step"] = current_step
        
        # Set completed_at if completing
        if status == self.STATUS_COMPLETED:
            updates["completed_at"] = datetime.now().isoformat()
        
        success = self.database.update_pipeline_case(case_id, updates)
        
        if success:
            self.logger.info("Updated case {} status to {}", case_id, status)
        else:
            self.logger.warning(
                "Failed to update case {} status to {}. Case may not exist in database.",
                case_id, status
            )
        
        return success
    
    def mark_hitl_pending(
        self,
        case_id: str,
        gate_id: str,
    ) -> bool:
        """
        Mark case as waiting for HITL response.
        
        Args:
            case_id: The case ID
            gate_id: The HITL gate ID
            
        Returns:
            True if updated successfully
        """
        return self.update_case_status(
            case_id=case_id,
            status=self.STATUS_HITL_PENDING,
            current_step=gate_id,
        )
    
    def mark_completed(
        self,
        case_id: str,
        final_output: Optional[Dict[str, Any]] = None,
        processing_time_ms: Optional[int] = None,
    ) -> bool:
        """
        Mark case as completed.
        
        Args:
            case_id: The case ID
            final_output: Optional final pipeline output
            processing_time_ms: Optional processing time in milliseconds
            
        Returns:
            True if updated successfully
        """
        updates = {
            "status": self.STATUS_COMPLETED,
            "completed_at": datetime.now().isoformat(),
        }
        
        if final_output is not None:
            updates["final_output"] = final_output
            
            # Also add final_output to case_data so it's displayed in the UI
            case = self.get_case(case_id)
            if case:
                case_data = case.get("case_data", {})
                case_data["final_output"] = final_output
                updates["case_data"] = case_data
                self.logger.debug(
                    "Added final_output to case_data for case {}",
                    case_id
                )
        
        if processing_time_ms is not None:
            updates["processing_time_ms"] = processing_time_ms
        
        success = self.database.update_pipeline_case(case_id, updates)
        
        if success:
            self.logger.info("Marked case {} as completed", case_id)
            # Add timeline entry for case completion
            self._add_timeline_entry(
                case_id=case_id,
                event_type="case_completed",
                event_data={
                    "completed_at": updates["completed_at"],
                    "processing_time_ms": processing_time_ms,
                },
            )
        
        return success
    
    def mark_failed(
        self,
        case_id: str,
        error_message: Optional[str] = None,
    ) -> bool:
        """
        Mark case as failed.
        
        Args:
            case_id: The case ID
            error_message: Optional error message
            
        Returns:
            True if updated successfully
        """
        updates = {"status": self.STATUS_FAILED}
        
        if error_message:
            # Store error in case_data
            case = self.get_case(case_id)
            if case:
                case_data = case.get("case_data", {})
                case_data["_error"] = error_message
                updates["case_data"] = case_data
        
        success = self.database.update_pipeline_case(case_id, updates)
        
        if success:
            self.logger.warning("Marked case {} as failed: {}", case_id, error_message or "Unknown error")
            # Add timeline entry for case failure
            self._add_timeline_entry(
                case_id=case_id,
                event_type="case_failed",
                event_data={
                    "error_message": error_message,
                    "failed_at": datetime.now().isoformat(),
                },
            )
        
        return success
    
    def get_case(self, case_id: str) -> Optional[Dict[str, Any]]:
        """
        Get case by ID.
        
        Args:
            case_id: The case ID
            
        Returns:
            Case data or None if not found
        """
        return self.database.get_pipeline_case(case_id)
    
    def list_cases(
        self,
        pipeline_id: Optional[str] = None,
        status: Optional[str] = None,
        run_id: Optional[str] = None,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        List cases with optional filters.
        
        Args:
            pipeline_id: Filter by pipeline
            status: Filter by status
            run_id: Filter by run ID
            from_date: Filter by created_at >= from_date
            to_date: Filter by created_at <= to_date
            limit: Maximum number of results
            offset: Pagination offset
            
        Returns:
            List of case records
        """
        return self.database.list_pipeline_cases(
            pipeline_id=pipeline_id,
            status=status,
            run_id=run_id,
            from_date=from_date,
            to_date=to_date,
            limit=limit,
            offset=offset,
        )
    
    def get_cases_by_run(self, run_id: str) -> List[Dict[str, Any]]:
        """
        Get all cases for a specific run.
        
        Args:
            run_id: The run ID
            
        Returns:
            List of cases for this run
        """
        return self.list_cases(run_id=run_id, limit=1000)
    
    def _re_extract_list_view_data(
        self,
        case: Dict[str, Any],
        case_config: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Re-extract _list_view data from current case config.
        
        This ensures that list view fields reflect current YAML changes immediately,
        even for cases that were created before the YAML was updated.
        
        Args:
            case: Case dictionary from database
            case_config: Current case configuration (YAML)
            
        Returns:
            Updated case dictionary with re-extracted _list_view data
        """
        if not case_config:
            self.logger.debug("Skipping re-extraction: no case_config provided for case {}", case.get("case_id"))
            return case
        
        # Get stored case_data
        stored_case_data = case.get("case_data", {})
        if not stored_case_data:
            self.logger.debug("Skipping re-extraction: no case_data for case {}", case.get("case_id"))
            return case
        
        # Build upstream from stored agent outputs (excluding display metadata)
        upstream = {}
        final_output = case.get("final_output")
        if final_output:
            if isinstance(final_output, dict):
                upstream.update(final_output)
            else:
                upstream["final_output"] = final_output
        
        # Add stored agent outputs (excluding display metadata)
        for key, value in stored_case_data.items():
            if not key.startswith("_"):  # Exclude _list_view, _detail_view, etc.
                upstream[key] = value
        
        # Log available upstream keys for debugging
        self.logger.debug(
            "Re-extracting _list_view for case {}. Available upstream keys: {}",
            case.get("case_id"),
            list(upstream.keys())[:10]  # Log first 10 keys
        )
        
        try:
            # Re-extract display config from current YAML using upstream as data source
            # Build case_meta from case record for template rendering
            case_meta = {
                "case_id": case.get("case_id"),
                "display_id": case.get("display_id"),
                "pipeline_id": case.get("pipeline_id"),
                "status": case.get("status"),
                "hitl_gate_title": case.get("hitl_gate_title"),
                "hitl_description": case.get("hitl_description"),
                "hitl_status": case.get("hitl_status"),
                "hitl_decision": case.get("hitl_decision"),
                "responded_by": case.get("responded_by"),
                "created_at": case.get("created_at"),
                "updated_at": case.get("updated_at"),
            }
            re_extracted = self.extractor.extract_case_data(
                upstream=upstream,
                case_config=case_config,
                case_meta=case_meta,
            )
            
            # Update case_data with re-extracted display config
            # Preserve raw agent outputs, update display metadata
            updated_case_data = stored_case_data.copy()
            
            # Update display metadata from re-extraction
            if "_list_view" in re_extracted:
                updated_case_data["_list_view"] = re_extracted["_list_view"]
                pipeline_fields_count = len(re_extracted.get("_list_view", {}).get("pipeline_fields", {}))
                self.logger.debug(
                    "Re-extracted _list_view for case {}: {} pipeline fields",
                    case.get("case_id"),
                    pipeline_fields_count
                )
            else:
                self.logger.warning(
                    "Re-extraction for case {} did not produce _list_view. Available keys in re_extracted: {}",
                    case.get("case_id"),
                    list(re_extracted.keys())[:10]
                )
            
            # Return updated case with new case_data
            updated_case = case.copy()
            updated_case["case_data"] = updated_case_data
            
            return updated_case
        except Exception as e:
            self.logger.error(
                "Error re-extracting _list_view for case {}: {}. Returning original case.",
                case.get("case_id"),
                e,
                exc_info=True
            )
            return case
    
    def list_grouped_cases(
        self,
        pipeline_id: Optional[str] = None,
        case_config: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """
        List grouped cases (top-level virtual cases with sub-cases).
        
        Args:
            pipeline_id: Filter by pipeline
            case_config: Case configuration (needed for grouping config)
            
        Returns:
            List of grouped case dictionaries with top_level and sub_cases
        """
        # Get all cases for this pipeline
        all_cases = self.list_cases(pipeline_id=pipeline_id, limit=10000)
        
        # Extract grouping_key from case_data for each case (YAML-driven, not database)
        # Read from views.grouped structure
        views_config = case_config.get("views", {}) if case_config else {}
        grouped_view_config = views_config.get("grouped", {})
        
        # Read grouping_key_expression from views.grouped
        grouping_key_expression = grouped_view_config.get("grouping_key_expression") if grouped_view_config else None
        if not grouping_key_expression:
            return []  # No grouping key expression, return empty list
        
        # Group cases by grouping_key extracted from case_data
        grouped = {}
        cases_without_key = 0
        for case in all_cases:
            # Reconstruct upstream from case_data for grouping_key extraction
            # Agent outputs in case_data are stored directly (e.g., {"covenant_document_classifier": {...}})
            # They may have "parsed" and "result" wrappers, which the expression evaluator handles
            case_data = case.get("case_data", {})
            upstream = {}
            # Add raw agent outputs from case_data
            # These are stored as-is from the pipeline execution (with parsed/result wrappers if present)
            for key, value in case_data.items():
                if not key.startswith("_"):  # Raw agent outputs
                    upstream[key] = value
            
            self.logger.debug(
                "Reconstructing upstream for case {}. Available keys: {}, Expression: '{}'",
                case.get("case_id"),
                list(upstream.keys())[:10],
                grouping_key_expression
            )
            
            # Extract grouping_key from case_data using YAML expression
            # The expression evaluator expects context = {"upstream": upstream}
            # and will resolve "covenant_document_classifier.contract_id" as:
            # upstream["covenant_document_classifier"]["parsed"]["contract_id"] or
            # upstream["covenant_document_classifier"]["contract_id"]
            grouping_key = self.grouping_extractor.extract_grouping_key(
                upstream=upstream,
                grouping_key_expression=grouping_key_expression,
            )
            
            if not grouping_key:
                cases_without_key += 1
                # Check if the agent exists in upstream
                agent_id = grouping_key_expression.split(".")[0] if "." in grouping_key_expression else None
                agent_data = upstream.get(agent_id) if agent_id else None
                self.logger.debug(
                    "Case {} has no grouping_key. Expression: '{}', Agent '{}' in upstream: {}, "
                    "Agent data type: {}, Has 'parsed': {}, Available upstream keys: {}",
                    case.get("case_id"),
                    grouping_key_expression,
                    agent_id,
                    agent_id in upstream if agent_id else False,
                    type(agent_data).__name__ if agent_data else None,
                    isinstance(agent_data, dict) and "parsed" in agent_data if agent_data else False,
                    list(upstream.keys())[:10] if upstream else []
                )
                continue  # Skip cases without grouping_key
            else:
                self.logger.debug(
                    "Case {} extracted grouping_key: '{}' from expression: '{}'",
                    case.get("case_id"),
                    grouping_key,
                    grouping_key_expression
                )
            
            if grouping_key not in grouped:
                grouped[grouping_key] = []
            grouped[grouping_key].append(case)
        
        self.logger.info(
            "Grouped {} cases into {} groups. {} cases had no grouping_key. Expression: '{}'",
            len(all_cases),
            len(grouped),
            cases_without_key,
            grouping_key_expression
        )
        
        # Build top-level cases
        result = []
        
        for grouping_key, sub_cases in grouped.items():
            # Sort sub-cases by created_at (no more grouping_index)
            sub_cases.sort(key=lambda c: c.get("created_at") or "")
            
            # Re-extract _list_view data for each sub_case
            if case_config:
                sub_cases = [
                    self._re_extract_list_view_data(case, case_config)
                    for case in sub_cases
                ]
            
            # Build top-level case
            # Read from views.grouped structure
            views_config = case_config.get("views", {}) if case_config else {}
            grouped_view_config = views_config.get("grouped", {})
            if grouped_view_config and grouped_view_config.get("grouping_key_expression"):
                top_level = self.grouping_aggregator.build_top_level_case(
                    grouping_key=grouping_key,
                    sub_cases=sub_cases,
                    grouped_view_config=grouped_view_config,
                    case_config=case_config,
                )
            else:
                # Fallback if no grouped view config
                top_level = {
                    "grouping_key": grouping_key,
                    "display_id": grouping_key,
                    "status": self.grouping_aggregator.aggregate_status(sub_cases),
                    "sub_case_count": len(sub_cases),
                    "sub_case_ids": [c.get("case_id") for c in sub_cases],
                    "summary": {},
                    "created_at": min([c.get("created_at") for c in sub_cases if c.get("created_at")]) if sub_cases else None,
                    "updated_at": max([c.get("updated_at") for c in sub_cases if c.get("updated_at")]) if sub_cases else None,
                    "pipeline_id": sub_cases[0].get("pipeline_id") if sub_cases else None,
                }
            
            result.append({
                "grouping_key": grouping_key,
                "top_level": top_level,
                "sub_cases": sub_cases,
            })
        
        # Sort by created_at (earliest first)
        result.sort(key=lambda g: g["top_level"].get("created_at") or "")
        
        return result
    
    def get_grouped_case(
        self,
        grouping_key: str,
        pipeline_id: str,
        case_config: Optional[Dict[str, Any]] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        Get a single grouped case by grouping_key.
        
        Args:
            grouping_key: The grouping key
            pipeline_id: The pipeline ID
            case_config: Case configuration (needed for grouping config)
            
        Returns:
            Grouped case dictionary with top_level and sub_cases, or None if not found
        """
        # Get all cases for this pipeline
        all_cases = self.list_cases(pipeline_id=pipeline_id, limit=10000)
        
        # Extract grouping_key from case_data for each case and filter by target grouping_key
        # Read from views.grouped structure
        views_config = case_config.get("views", {}) if case_config else {}
        grouped_view_config = views_config.get("grouped", {})
        
        # Read grouping_key_expression from views.grouped
        grouping_key_expression = grouped_view_config.get("grouping_key_expression") if grouped_view_config else None
        if not grouping_key_expression:
            return None
        
        # Filter cases by extracting grouping_key from case_data
        sub_cases = []
        for case in all_cases:
            # Reconstruct upstream from case_data for grouping_key extraction
            case_data = case.get("case_data", {})
            upstream = {}
            # Add raw agent outputs from case_data
            for key, value in case_data.items():
                if not key.startswith("_"):  # Raw agent outputs
                    upstream[key] = value
            
            # Extract grouping_key from case_data using YAML expression
            extracted_key = self.grouping_extractor.extract_grouping_key(
                upstream=upstream,
                grouping_key_expression=grouping_key_expression,
            )
            
            if extracted_key == grouping_key:
                sub_cases.append(case)
            else:
                # Debug logging for mismatched keys
                self.logger.debug(
                    "Case {} grouping_key mismatch: extracted='{}', requested='{}', expression='{}'",
                    case.get("case_id"),
                    extracted_key,
                    grouping_key,
                    grouping_key_expression
                )
        
        if not sub_cases:
            self.logger.warning(
                "No sub-cases found for grouping_key '{}' (pipeline_id: {}, expression: '{}')",
                grouping_key,
                pipeline_id,
                grouping_key_expression
            )
            return None
        
        # Sort sub-cases by created_at (no more grouping_index)
        sub_cases.sort(key=lambda c: c.get("created_at") or "")
        
        # Re-extract _list_view data for each sub_case
        if case_config:
            sub_cases = [
                self._re_extract_list_view_data(case, case_config)
                for case in sub_cases
            ]
        
        # Build top-level case
        # Read from views.grouped structure
        views_config = case_config.get("views", {}) if case_config else {}
        grouped_view_config = views_config.get("grouped", {})
        if grouped_view_config and grouped_view_config.get("grouping_key_expression"):
            top_level = self.grouping_aggregator.build_top_level_case(
                grouping_key=grouping_key,
                sub_cases=sub_cases,
                grouped_view_config=grouped_view_config,
                case_config=case_config,
            )
        else:
            # Fallback if no grouped view config
            top_level = {
                "grouping_key": grouping_key,
                "display_id": grouping_key,
                "status": self.grouping_aggregator.aggregate_status(sub_cases),
                "sub_case_count": len(sub_cases),
                "sub_case_ids": [c.get("case_id") for c in sub_cases],
                "summary": {},
                "created_at": min([c.get("created_at") for c in sub_cases if c.get("created_at")]) if sub_cases else None,
                "updated_at": max([c.get("updated_at") for c in sub_cases if c.get("updated_at")]) if sub_cases else None,
                "pipeline_id": sub_cases[0].get("pipeline_id") if sub_cases else None,
            }
        
        return {
            "grouping_key": grouping_key,
            "top_level": top_level,
            "sub_cases": sub_cases,
        }
    
    def delete_case(self, case_id: str) -> bool:
        """
        Delete a case and all associated data.
        
        Args:
            case_id: The case ID
            
        Returns:
            True if deleted successfully
        """
        success = self.database.delete_pipeline_case(case_id)
        
        if success:
            self.logger.info("Deleted case: {}", case_id)
        
        return success
    
    def delete_cases(
        self,
        pipeline_id: Optional[str] = None,
        status: Optional[str] = None,
    ) -> int:
        """
        Delete multiple cases with filters.
        
        Args:
            pipeline_id: Filter by pipeline ID (optional)
            status: Filter by status (optional)
            
        Returns:
            Number of cases deleted
        """
        deleted_count = self.database.delete_pipeline_cases(
            pipeline_id=pipeline_id,
            status=status,
        )
        
        if deleted_count > 0:
            self.logger.info("Deleted {} cases with filters: pipeline_id={}, status={}", 
                           deleted_count, pipeline_id, status)
        
        return deleted_count
    
    def case_exists(self, case_id: str) -> bool:
        """
        Check if a case exists.
        
        Args:
            case_id: The case ID
            
        Returns:
            True if case exists
        """
        return self.get_case(case_id) is not None
    
    def get_case_summary(
        self,
        pipeline_id: Optional[str] = None,
    ) -> Dict[str, int]:
        """
        Get summary counts by status.
        
        Args:
            pipeline_id: Optional filter by pipeline
            
        Returns:
            Dictionary with counts by status
        """
        # Use status constants instead of hardcoded strings
        summary = {
            self.STATUS_PROCESSING: 0,
            self.STATUS_HITL_PENDING: 0,
            self.STATUS_COMPLETED: 0,
            self.STATUS_FAILED: 0,
            "total": 0,
        }
        
        for status in [self.STATUS_PROCESSING, self.STATUS_HITL_PENDING, self.STATUS_COMPLETED, self.STATUS_FAILED]:
            cases = self.list_cases(
                pipeline_id=pipeline_id,
                status=status,
                limit=10000,  # High limit to get all
            )
            summary[status] = len(cases)
            summary["total"] += len(cases)
        
        return summary
    
    def _add_timeline_entry(
        self,
        case_id: str,
        event_type: str,
        event_data: Dict[str, Any],
    ) -> bool:
        """
        Add a timeline entry to a case's case_data.
        
        Args:
            case_id: The case ID
            event_type: Type of event (e.g., "hitl_queued", "hitl_response")
            event_data: Event-specific data
            
        Returns:
            True if updated successfully
        """
        case = self.get_case(case_id)
        if not case:
            self.logger.error("Case not found for timeline entry: {}", case_id)
            return False
        
        # Get current case_data
        case_data = case.get("case_data", {})
        
        # Initialize _timeline if it doesn't exist
        if "_timeline" not in case_data:
            case_data["_timeline"] = []
        
        # Create timeline entry
        # Use "type" to match frontend expectations (frontend looks for entry.type)
        timeline_entry = {
            "type": event_type,
            "timestamp": datetime.now().isoformat(),
            **event_data,
        }
        
        # Append to timeline
        case_data["_timeline"].append(timeline_entry)
        
        # Update case in database
        success = self.database.update_pipeline_case(
            case_id=case_id,
            updates={"case_data": case_data},
        )
        
        if success:
            self.logger.debug(
                "Added timeline entry to case {}: event_type={}",
                case_id, event_type
            )
        else:
            self.logger.error(
                "Failed to add timeline entry to case {}: event_type={}",
                case_id, event_type
            )
        
        return success
    
