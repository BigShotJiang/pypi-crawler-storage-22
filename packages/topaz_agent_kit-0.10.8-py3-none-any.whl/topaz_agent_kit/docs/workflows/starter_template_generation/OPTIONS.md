# Starter Template Generation Workflow - Options

This document presents three options for creating a workflow to generate new starter templates.

---

## Option 1: Simple Copy-Based Workflow (Recommended)

**Best for**: Quick creation when you know exactly which pipelines to copy

### Workflow Structure

```
1. Gather Requirements (5 questions)
2. Copy Files
3. Generate Global Configs
4. Validate & Summary
```

### Questions Asked:
1. **Template name** (e.g., "author", "content_creator")
2. **Source starter** (e.g., "ensemble", "pa", "icp") - where to copy pipelines from
3. **Pipelines to copy** (list of pipeline IDs, e.g., ["article_smith", "reply_wizard"])
4. **Copy independent agents?** (yes/no, default: no)
5. **Copy tools?** (yes/no, default: no)

### What Gets Copied:
- ✅ Pipeline configs (`config/pipelines/{pipeline_id}.yml`)
- ✅ UI manifests (`config/ui_manifests/{pipeline_id}.yml`)
- ✅ All agent configs for those pipelines
- ✅ All prompt templates for those pipelines
- ✅ All HITL templates for those pipelines
- ✅ All icons (pipeline + agents)
- ✅ Optional: Independent agents (if yes)
- ✅ Optional: Tools directory (if yes)

### What Gets Generated:
- ✅ Global `config/pipeline.yml` (with copied pipelines)
- ✅ Global `config/ui_manifest.yml` (with copied pipelines)
- ✅ Simplified `assistant_intent_classifier.jinja` (with copied pipelines)
- ✅ `operations_assistant.jinja` (copied as-is)

### Pros:
- ✅ Fast and simple
- ✅ Minimal questions
- ✅ Works well for most cases
- ✅ Easy to follow

### Cons:
- ❌ Less flexible for custom configurations
- ❌ Doesn't handle edge cases (custom memory, requisites, etc.)

---

## Option 2: Guided Step-by-Step Workflow

**Best for**: When you want more control and validation at each step

### Workflow Structure

```
1. Requirements Gathering
   - Template name & description
   - Source starter selection
   - Pipeline selection
   - Component selection (agents, tools, memory, etc.)
   
2. File Discovery & Validation
   - Discover all files to copy
   - Check for conflicts
   - Validate dependencies
   
3. Configuration Customization
   - Customize global configs
   - Update assistant_intent_classifier keywords
   - Review UI manifest entries
   
4. File Generation
   - Copy all files
   - Generate global configs
   - Update assistant prompts
   
5. Validation & Summary
   - Verify all files exist
   - Check for missing dependencies
   - Provide testing instructions
```

### Questions Asked:
1. **Template name** (snake_case)
2. **Template description** (what this starter is for)
3. **Source starter** (where to copy from)
4. **Pipelines to copy** (list with validation)
5. **Copy independent agents?** (yes/no)
6. **Which independent agents?** (if yes, list them)
7. **Copy tools?** (yes/no)
8. **Which tools?** (if yes, list them)
9. **Copy memory templates?** (yes/no)
10. **Copy requisites?** (yes/no)
11. **Customize assistant keywords?** (yes/no, if yes, provide keywords)

### Pros:
- ✅ More control over what gets copied
- ✅ Better validation and error checking
- ✅ Handles edge cases
- ✅ More thorough

### Cons:
- ❌ More questions to answer
- ❌ Takes longer
- ❌ May be overkill for simple cases

---

## Option 3: Hybrid Workflow (Recommended for Flexibility)

**Best for**: Balance between simplicity and flexibility

### Workflow Structure

```
1. Quick Setup (Required)
   - Template name
   - Source starter
   - Pipelines to copy
   
2. Optional Components (Skip with defaults)
   - Independent agents (default: no)
   - Tools (default: no)
   - Memory templates (default: no)
   - Requisites (default: no)
   
3. Customization (Optional)
   - Custom description
   - Custom assistant keywords
   - Custom UI branding
   
4. File Generation
   - Copy files
   - Generate configs
   
5. Validation & Summary
```

### Questions Asked:

**Required:**
1. Template name
2. Source starter
3. Pipelines to copy

**Optional (can skip with defaults):**
4. Copy independent agents? (default: no)
5. Copy tools? (default: no)
6. Copy memory templates? (default: no)
7. Copy requisites? (default: no)
8. Custom description? (default: auto-generated)
9. Custom assistant keywords? (default: auto-generated from pipeline names)

### Pros:
- ✅ Fast for simple cases (just answer 3 questions)
- ✅ Flexible for complex cases (answer more questions)
- ✅ Good defaults for common scenarios
- ✅ Best of both worlds

### Cons:
- ❌ Slightly more complex than Option 1
- ❌ Still doesn't handle all edge cases

---

## Recommendation

**Option 1** is recommended for most use cases because:
- It's simple and fast
- Covers 90% of use cases
- Easy to extend later if needed
- Matches the "author" template creation we just did

**Option 3** is recommended if you want more flexibility while keeping it simple.

---

## Next Steps

1. Choose an option
2. I'll create the workflow document in `.mdc` format (similar to `pipeline_generation.mdc`)
3. Place it in `src/topaz_agent_kit/rules/starter_template_generation.mdc`
4. Test it by creating a new starter template
