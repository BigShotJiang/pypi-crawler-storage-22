"""
Covenant Context Manager - Local tools for contract lifecycle management.

Provides tools for:
- Contract ID extraction from file paths
- Contract file operations
- Contract artifact management (read/write JSON artifacts)
- Contract report management (write markdown reports)
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from topaz_agent_kit.local_tools.registry import pipeline_tool
from topaz_agent_kit.utils.logger import Logger

_logger = Logger("CovenantContextManager")


# ---------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------

def _validate_contract_id(contract_id: str) -> None:
    """Validate contract ID or SOW number format.
    
    Now accepts both CONTRACT-YYYY-XXX and SOW-YYYY-XXXX formats.
    """
    if not contract_id:
        raise ValueError("contract_id is required")
    # Accept both old CONTRACT format and new SOW format
    if not (re.match(r"^CONTRACT-\d{4}-\d{3}$", contract_id) or re.match(r"^SOW-\d{4}-\d{4}$", contract_id)):
        raise ValueError(f"Invalid contract_id/SOW format: {contract_id}. Expected format: CONTRACT-YYYY-XXX or SOW-YYYY-XXXX")


def _resolve_path(base_path: str, relative_path: str) -> Path:
    """Resolve absolute path from base and relative path."""
    if not base_path:
        raise ValueError("base_path is required")
    base = Path(base_path)
    if not base.is_absolute():
        raise ValueError(f"base_path must be absolute: {base_path}")
    
    path = base / relative_path
    return path.resolve()


# ---------------------------------------------------------------------
# SOW Number Extraction
# ---------------------------------------------------------------------

@pipeline_tool(toolkit="covenant", name="extract_sow_number_from_path")
def extract_sow_number_from_path(file_path: str) -> str:
    """Extract sow_number from file path.
    
    Supports multiple path patterns:
    - pre_contract/SOW-2025-2019/file.txt → SOW-2025-2019
    - draft_contracts/SOW-2025-2019_draft_v1.pdf → SOW-2025-2019
    - signed_contracts/SOW-2025-2019_signed.pdf → SOW-2025-2019
    - artifacts/SOW-2025-2019/file.json → SOW-2025-2019
    
    Args:
        file_path: File path (absolute or relative)
    
    Returns:
        SOW Number in format SOW-YYYY-XXXX
    
    Raises:
        ValueError: If sow_number cannot be extracted
    """
    try:
        path = Path(file_path)
        
        # Pattern 1: Directory structure (pre_contract/SOW-2025-2019/file.txt)
        # Look for SOW-YYYY-XXXX in path components
        for part in path.parts:
            match = re.match(r"^(SOW-\d{4}-\d{4})", part)
            if match:
                sow_number = match.group(1)
                _logger.debug("Extracted sow_number from path component: {}", sow_number)
                return sow_number
        
        # Pattern 2: Filename (SOW-2025-2019_draft_v1.pdf)
        filename = path.name
        match = re.match(r"^(SOW-\d{4}-\d{4})", filename)
        if match:
            sow_number = match.group(1)
            _logger.debug("Extracted sow_number from filename: {}", sow_number)
            return sow_number
        
        # Pattern 3: Search in full path string
        match = re.search(r"(SOW-\d{4}-\d{4})", str(path))
        if match:
            sow_number = match.group(1)
            _logger.debug("Extracted sow_number from path string: {}", sow_number)
            return sow_number
        
        raise ValueError(f"Could not extract sow_number from path: {file_path}")
    
    except Exception as e:
        _logger.error("Error extracting sow_number from path {}: {}", file_path, e)
        raise ValueError(f"Failed to extract sow_number: {e}")


# Keep old function name for backward compatibility (deprecated)
@pipeline_tool(toolkit="covenant", name="extract_contract_id_from_path")
def extract_contract_id_from_path(file_path: str) -> str:
    """Deprecated: Use extract_sow_number_from_path instead.
    
    This function is kept for backward compatibility but now extracts SOW numbers.
    """
    return extract_sow_number_from_path(file_path)


# ---------------------------------------------------------------------
# Contract File Operations
# ---------------------------------------------------------------------

@pipeline_tool(toolkit="covenant", name="get_contract_files")
def get_contract_files(
    contract_id: str,
    directory: str,
    project_dir: str
) -> List[str]:
    """Get all files for a contract in a specific directory.
    
    Args:
        contract_id: Contract ID (e.g., CONTRACT-2025-318)
        directory: Directory name (e.g., "pre_contract", "draft_contracts", "signed_contracts", "change_orders")
        project_dir: Absolute path to project root directory
    
    Returns:
        List of absolute file paths
    """
    try:
        _validate_contract_id(contract_id)
        
        # Resolve directory path
        if directory == "pre_contract":
            dir_path = _resolve_path(project_dir, f"data/covenant/pre_contract/{contract_id}")
        elif directory == "draft_contracts":
            dir_path = _resolve_path(project_dir, "data/covenant/draft_contracts")
        elif directory == "signed_contracts":
            dir_path = _resolve_path(project_dir, "data/covenant/signed_contracts")
        elif directory == "change_orders":
            dir_path = _resolve_path(project_dir, "data/covenant/change_orders")
        elif directory == "historical_wbs":
            dir_path = _resolve_path(project_dir, "data/covenant/historical_wbs")
        else:
            raise ValueError(f"Unknown directory: {directory}")
        
        if not dir_path.exists():
            _logger.warning("Directory does not exist: {}", dir_path)
            return []
        
        if not dir_path.is_dir():
            raise ValueError(f"Path is not a directory: {dir_path}")
        
        # Get all files (not directories)
        files = []
        for item in dir_path.iterdir():
            if item.is_file():
                # For draft_contracts, signed_contracts, and change_orders, filter by contract_id
                if directory in ["draft_contracts", "signed_contracts", "change_orders"]:
                    if contract_id in item.name:
                        files.append(str(item))
                else:
                    # For pre_contract and historical_wbs, include all files
                    files.append(str(item))
        
        _logger.debug("Found {} files in {} for contract {}", len(files), directory, contract_id)
        return sorted(files)
    
    except Exception as e:
        _logger.error("Error getting contract files for {} in {}: {}", contract_id, directory, e)
        raise


@pipeline_tool(toolkit="covenant", name="list_contract_artifacts")
def list_contract_artifacts(
    contract_id: str,
    project_dir: str
) -> List[str]:
    """List all artifact files for a contract.
    
    Args:
        contract_id: Contract ID (e.g., CONTRACT-2025-318)
        project_dir: Absolute path to project root directory
    
    Returns:
        List of artifact filenames
    """
    try:
        _validate_contract_id(contract_id)
        
        artifacts_dir = _resolve_path(project_dir, f"data/covenant/artifacts/{contract_id}")
        
        if not artifacts_dir.exists():
            _logger.debug("Artifacts directory does not exist: {}", artifacts_dir)
            return []
        
        artifacts = []
        for item in artifacts_dir.iterdir():
            if item.is_file():
                artifacts.append(item.name)
        
        _logger.debug("Found {} artifacts for contract {}", len(artifacts), contract_id)
        return sorted(artifacts)
    
    except Exception as e:
        _logger.error("Error listing artifacts for {}: {}", contract_id, e)
        raise


# ---------------------------------------------------------------------
# Contract Artifact Operations
# ---------------------------------------------------------------------

@pipeline_tool(toolkit="covenant", name="read_contract_artifact")
def read_contract_artifact(
    contract_id: str,
    artifact_name: str,
    project_dir: str
) -> Dict[str, Any]:
    """Read a contract artifact JSON file.
    
    Args:
        contract_id: Contract ID (e.g., CONTRACT-2025-318)
        artifact_name: Artifact filename (e.g., "pre_contract_summary_v1.json")
        project_dir: Absolute path to project root directory
    
    Returns:
        Dictionary containing artifact data
    
    Raises:
        FileNotFoundError: If artifact file does not exist
        ValueError: If artifact file is invalid JSON
    """
    try:
        _validate_contract_id(contract_id)
        
        artifact_path = _resolve_path(project_dir, f"data/covenant/artifacts/{contract_id}/{artifact_name}")
        
        if not artifact_path.exists():
            _logger.warning("Artifact file does not exist: {}", artifact_path)
            raise FileNotFoundError(f"Artifact not found: {artifact_name} for contract {contract_id}")
        
        with open(artifact_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        _logger.debug("Read artifact {} for contract {}", artifact_name, contract_id)
        return data
    
    except FileNotFoundError:
        raise
    except json.JSONDecodeError as e:
        _logger.error("Invalid JSON in artifact {}: {}", artifact_path, e)
        raise ValueError(f"Invalid JSON in artifact {artifact_name}: {e}")
    except Exception as e:
        _logger.error("Error reading artifact {} for {}: {}", artifact_name, contract_id, e)
        raise


@pipeline_tool(toolkit="covenant", name="write_contract_artifact")
def write_contract_artifact(
    contract_id: str,
    artifact_name: str,
    content: Dict[str, Any],
    project_dir: str
) -> str:
    """Write a contract artifact JSON file.
    
    Args:
        contract_id: Contract ID (e.g., CONTRACT-2025-318)
        artifact_name: Artifact filename (e.g., "pre_contract_summary_v1.json")
        content: Dictionary containing artifact data
        project_dir: Absolute path to project root directory
    
    Returns:
        Absolute path to the saved artifact file
    
    Raises:
        ValueError: If content cannot be serialized to JSON
        OSError: If file cannot be written
    """
    try:
        _validate_contract_id(contract_id)
        
        artifacts_dir = _resolve_path(project_dir, f"data/covenant/artifacts/{contract_id}")
        
        # Create directory if it doesn't exist
        artifacts_dir.mkdir(parents=True, exist_ok=True)
        
        artifact_path = artifacts_dir / artifact_name
        
        # Write JSON file
        with open(artifact_path, "w", encoding="utf-8") as f:
            json.dump(content, f, indent=2, ensure_ascii=False)
        
        _logger.debug("Wrote artifact {} for contract {}: {}", artifact_name, contract_id, artifact_path)
        return str(artifact_path)
    
    except (TypeError, ValueError) as e:
        _logger.error("Error serializing artifact {}: {}", artifact_name, e)
        raise ValueError(f"Failed to serialize artifact {artifact_name}: {e}")
    except OSError as e:
        _logger.error("Error writing artifact {}: {}", artifact_path, e)
        raise
    except Exception as e:
        _logger.error("Error writing artifact {} for {}: {}", artifact_name, contract_id, e)
        raise


@pipeline_tool(toolkit="covenant", name="write_contract_report")
def write_contract_report(
    contract_id: str,
    report_name: str,
    report_content: str,
    project_dir: str
) -> str:
    """Write a contract report markdown file.
    
    The tool automatically constructs the path: data/covenant/reports/{contract_id}_{report_name}.md
    
    Args:
        contract_id: Contract ID (e.g., CONTRACT-2025-318)
        report_name: Report name (e.g., "pre_contract_synthesis_report")
        report_content: Markdown content of the report
        project_dir: Absolute path to project root directory
    
    Returns:
        Absolute path to the saved report file
    
    Raises:
        ValueError: If contract_id is invalid
        OSError: If file cannot be written
    """
    try:
        _validate_contract_id(contract_id)
        
        reports_dir = _resolve_path(project_dir, "data/covenant/reports")
        
        # Create directory if it doesn't exist
        reports_dir.mkdir(parents=True, exist_ok=True)
        
        # Construct filename: {contract_id}_{report_name}.md
        filename = f"{contract_id}_{report_name}.md"
        report_path = reports_dir / filename
        
        # Write markdown file
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(report_content)
        
        _logger.debug("Wrote report {} for contract {}: {}", report_name, contract_id, report_path)
        return str(report_path)
    
    except ValueError:
        raise
    except OSError as e:
        _logger.error("Error writing report {}: {}", report_path, e)
        raise
    except Exception as e:
        _logger.error("Error writing report {} for {}: {}", report_name, contract_id, e)
        raise


@pipeline_tool(toolkit="covenant", name="read_file")
def read_file(file_path: str) -> str:
    """Read text content from a file path.
    
    This tool reads arbitrary text files (e.g., markdown, text files) from absolute file paths.
    Use this for reading historical WBS files or other reference documents that are not contract artifacts.
    
    Args:
        file_path: Absolute file path to read
    
    Returns:
        File content as string
    
    Raises:
        FileNotFoundError: If file does not exist
        ValueError: If file cannot be read as text
    """
    try:
        path = Path(file_path)
        
        if not path.exists():
            _logger.warning("File does not exist: {}", file_path)
            raise FileNotFoundError(f"File not found: {file_path}")
        
        if not path.is_file():
            raise ValueError(f"Path is not a file: {file_path}")
        
        # Read file as text
        content = path.read_text(encoding="utf-8")
        
        _logger.debug("Read file {} ({} chars)", file_path, len(content))
        return content
    
    except FileNotFoundError:
        raise
    except UnicodeDecodeError as e:
        _logger.error("Failed to decode file {} as UTF-8: {}", file_path, e)
        raise ValueError(f"File is not valid UTF-8 text: {file_path}")
    except Exception as e:
        _logger.error("Error reading file {}: {}", file_path, e)
        raise


# ---------------------------------------------------------------------
# Database Operations
# ---------------------------------------------------------------------

def _get_database_path(project_dir: str) -> Path:
    """Get the path to the covenant database."""
    return _resolve_path(project_dir, "data/covenant/covenant.db")


def _connect_db(project_dir: str) -> sqlite3.Connection:
    """Connect to the covenant database."""
    db_path = _get_database_path(project_dir)
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    return conn


@pipeline_tool(toolkit="covenant", name="get_database_path")
def get_database_path(project_dir: str) -> str:
    """Get the path to the covenant database.
    
    Args:
        project_dir: Project root directory (absolute path)
    
    Returns:
        Absolute path to covenant.db file
    """
    return str(_get_database_path(project_dir))


@pipeline_tool(toolkit="covenant", name="save_contract")
def save_contract(
    contract_id: str,
    sow_number: str,
    contract_file_path: str,
    contract_date: Optional[str] = None,
    effective_date: Optional[str] = None,
    vendor_id: Optional[str] = None,
    project_id: Optional[str] = None,
    contract_type: Optional[str] = None,
    po_number: Optional[str] = None,
    run_id: Optional[str] = None,
    project_dir: str = ""
) -> Dict[str, Any]:
    """Save or update contract record in database.
    
    **Requirements:**
    - contract_id must follow format: SOW-YYYY-XXXX (e.g., "SOW-2025-2019")
    - contract_file_path must be a valid file path to the contract PDF
    - Dates should be in YYYY-MM-DD format
    - contract_type must be either "LABOR" or "MATERIAL"
    - run_id should be provided from the orchestrator context (available as {{run_id}})
    - project_dir must be the actual project directory path (use Project_Dir from inputs)
    
    **Example:**
    save_contract(
        contract_id="SOW-2025-2019",
        sow_number="SOW-2025-2019",
        contract_file_path="/path/to/contract.pdf",
        contract_date="2025-01-15",
        effective_date="2025-01-15",
        vendor_id="VENDOR-001",
        project_id="PROJ-001",
        contract_type="MATERIAL",
        po_number="PO-2025-001",
        run_id="{{run_id}}",
        project_dir="/path/to/projects/pa"
    )
    
    Args:
        contract_id: Contract ID in format SOW-YYYY-XXXX (e.g., "SOW-2025-2019")
        sow_number: SOW Number (typically same as contract_id)
        contract_file_path: Full path to signed contract PDF file
        contract_date: Contract date in YYYY-MM-DD format (optional)
        effective_date: Effective date in YYYY-MM-DD format (optional)
        vendor_id: Vendor identifier (optional)
        project_id: Project identifier (optional)
        contract_type: Contract type - must be "LABOR" or "MATERIAL" (optional)
        po_number: Purchase Order number (optional)
        run_id: Processing run ID from orchestrator context (use {{run_id}}) (optional)
        project_dir: Project root directory (REQUIRED: use actual Project_Dir value from inputs)
    
    Returns:
        Dictionary with contract record: {"contract_id": "...", "sow_number": "...", "status": "saved"}
    
    Raises:
        ValueError: If contract_id format is invalid
    """
    try:
        _validate_contract_id(contract_id)
        
        conn = _connect_db(project_dir)
        cursor = conn.cursor()
        
        # Insert or replace contract
        cursor.execute("""
            INSERT OR REPLACE INTO contracts (
                contract_id, sow_number, contract_file_path, contract_date,
                effective_date, vendor_id, project_id, contract_type, po_number,
                run_id, status, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', CURRENT_TIMESTAMP)
        """, (contract_id, sow_number, contract_file_path, contract_date, effective_date, 
              vendor_id, project_id, contract_type, po_number, run_id))
        
        conn.commit()
        conn.close()
        
        _logger.debug("Saved contract {} to database", contract_id)
        return {"contract_id": contract_id, "sow_number": sow_number, "status": "saved"}
    
    except Exception as e:
        _logger.error("Error saving contract {}: {}", contract_id, e)
        raise


@pipeline_tool(toolkit="covenant", name="save_contract_terms")
def save_contract_terms(
    contract_id: str,
    terms: List[Dict[str, Any]],
    project_dir: str = ""
) -> Dict[str, Any]:
    """Save contract terms to database.
    
    **Requirements:**
    - Each term in the list must be a dictionary with required fields
    - term_value should be a structured dictionary/JSON object, not a string
    - clause_identifier or clause_number is required for term ID generation
    - project_dir must be the actual project directory path
    
    **Example term structure:**
    {
        "clause_identifier": "Section 3.2",
        "clause_number": "3.2",
        "section_name": "Payment Terms",
        "term_category": "payment",
        "term_text": "Payment terms: Net 30 days from invoice date",
        "term_value": {"payment_terms": "Net 30 days", "days": 30},
        "effective_date": "2025-01-15"
    }
    
    **Example call:**
    save_contract_terms(
        contract_id="SOW-2025-2019",
        terms=[
            {
                "clause_identifier": "Section 3.2",
                "clause_number": "3.2",
                "section_name": "Payment Terms",
                "term_category": "payment",
                "term_text": "Payment terms: Net 30 days from invoice date",
                "term_value": {"payment_terms": "Net 30 days", "days": 30},
                "effective_date": "2025-01-15"
            }
        ],
        project_dir="/path/to/projects/pa"
    )
    
    Args:
        contract_id: Contract ID (e.g., "SOW-2025-2019")
        terms: List of term dictionaries, each containing:
            - clause_identifier: Section identifier (e.g., "Section 3.2")
            - clause_number: Clause number (e.g., "3.2")
            - section_name: Section name (e.g., "Payment Terms")
            - term_category: Category (e.g., "payment", "milestone", "risk")
            - term_text: Full text of the clause
            - term_value: Structured value as dictionary/JSON (e.g., {"payment_terms": "Net 30 days"})
            - effective_date: Effective date in YYYY-MM-DD format (optional)
        project_dir: Project root directory (REQUIRED: use actual Project_Dir value from inputs)
    
    Returns:
        Dictionary with saved term IDs and count: {"contract_id": "...", "terms_saved": 5, "term_ids": ["TERM-...", ...]}
    """
    try:
        _validate_contract_id(contract_id)
        
        conn = _connect_db(project_dir)
        cursor = conn.cursor()
        
        saved_terms = []
        for term in terms:
            term_id = f"TERM-{contract_id}-{term.get('clause_number', term.get('clause_identifier', 'unknown'))}"
            
            # Insert or replace term
            cursor.execute("""
                INSERT OR REPLACE INTO contract_terms (
                    term_id, contract_id, clause_identifier, clause_number,
                    section_name, term_category, term_text, term_value,
                    effective_date, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            """, (
                term_id, contract_id,
                term.get("clause_identifier", ""),
                term.get("clause_number", ""),
                term.get("section_name", ""),
                term.get("term_category", ""),
                term.get("term_text", ""),
                json.dumps(term.get("term_value")) if term.get("term_value") else None,
                term.get("effective_date")
            ))
            
            # Insert history entry for initial creation
            cursor.execute("""
                INSERT INTO term_history (
                    term_id, change_order_id, change_order_version, action,
                    clause_identifier, new_value, new_text, changed_by, changed_at
                ) VALUES (?, NULL, NULL, 'created', ?, ?, ?, 'initial', CURRENT_TIMESTAMP)
            """, (
                term_id,
                term.get("clause_identifier", ""),
                json.dumps(term.get("term_value")) if term.get("term_value") else None,
                term.get("term_text", "")
            ))
            
            saved_terms.append(term_id)
        
        conn.commit()
        conn.close()
        
        _logger.debug("Saved {} terms for contract {} to database", len(saved_terms), contract_id)
        return {"contract_id": contract_id, "terms_saved": len(saved_terms), "term_ids": saved_terms}
    
    except Exception as e:
        _logger.error("Error saving contract terms for {}: {}", contract_id, e)
        raise


@pipeline_tool(toolkit="covenant", name="get_contract_terms")
def get_contract_terms(
    contract_id: str,
    project_dir: str = ""
) -> List[Dict[str, Any]]:
    """Get all current terms for a contract from database.
    
    Args:
        contract_id: Contract ID
        project_dir: Project root directory
    
    Returns:
        List of term dictionaries with current values
    """
    try:
        _validate_contract_id(contract_id)
        
        conn = _connect_db(project_dir)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT term_id, clause_identifier, clause_number, section_name,
                   term_category, term_text, term_value, effective_date
            FROM contract_terms
            WHERE contract_id = ?
            ORDER BY clause_number, clause_identifier
        """, (contract_id,))
        
        terms = []
        for row in cursor.fetchall():
            term_value = json.loads(row["term_value"]) if row["term_value"] else None
            terms.append({
                "term_id": row["term_id"],
                "clause_identifier": row["clause_identifier"],
                "clause_number": row["clause_number"],
                "section_name": row["section_name"],
                "term_category": row["term_category"],
                "term_text": row["term_text"],
                "term_value": term_value,
                "effective_date": row["effective_date"]
            })
        
        conn.close()
        
        _logger.debug("Retrieved {} terms for contract {} from database", len(terms), contract_id)
        return terms
    
    except Exception as e:
        _logger.error("Error getting contract terms for {}: {}", contract_id, e)
        raise


# ---------------------------------------------------------------------
# PO Number Extraction
# ---------------------------------------------------------------------

@pipeline_tool(toolkit="covenant", name="find_po_file")
def find_po_file(
    contract_id: str,
    project_dir: str = ""
) -> Optional[str]:
    """Find associated PO PDF file for a contract.
    
    Looks for PO files in data/covenant/pos/ folder matching pattern:
    {contract_id}_po_*.pdf
    
    Args:
        contract_id: Contract ID (SOW-YYYY-XXXX)
        project_dir: Project root directory
    
    Returns:
        Absolute path to PO PDF file if found, None otherwise
    """
    try:
        _validate_contract_id(contract_id)
        
        pos_dir = _resolve_path(project_dir, "data/covenant/pos")
        
        if not pos_dir.exists():
            _logger.debug("PO directory does not exist: {}", pos_dir)
            return None
        
        # Look for PO files matching pattern: {contract_id}_po_*.pdf
        po_files = list(pos_dir.glob(f"{contract_id}_po_*.pdf"))
        
        if not po_files:
            _logger.debug("No PO file found for contract {}", contract_id)
            return None
        
        # Return the first matching PO file
        po_path = po_files[0]
        _logger.debug("Found PO file for contract {}: {}", contract_id, po_path)
        return str(po_path.resolve())
    
    except Exception as e:
        _logger.error("Error finding PO file for contract {}: {}", contract_id, e)
        return None


@pipeline_tool(toolkit="covenant", name="extract_po_number_from_file")
def extract_po_number_from_file(po_file_path: str) -> Optional[str]:
    """Extract PO number from PO PDF filename or content.
    
    PO files are named: {sow_number}_po_{po_number}.pdf
    Example: SOW-2026-2301_po_PO-2026-2785.pdf → PO-2026-2785
    
    Args:
        po_file_path: Path to PO PDF file
    
    Returns:
        PO number (e.g., PO-2026-2785) if found, None otherwise
    """
    try:
        path = Path(po_file_path)
        
        # Extract from filename pattern: {sow}_po_{po_number}.pdf
        filename = path.stem  # Gets filename without extension
        match = re.search(r"_po_(PO-\d{4}-\d{4})", filename)
        if match:
            po_number = match.group(1)
            _logger.debug("Extracted PO number from filename: {}", po_number)
            return po_number
        
        # If not found in filename, could extract from PDF content in future
        # For now, return None
        _logger.debug("Could not extract PO number from filename: {}", filename)
        return None
    
    except Exception as e:
        _logger.error("Error extracting PO number from file {}: {}", po_file_path, e)
        return None


# ---------------------------------------------------------------------
# Rate Card Operations
# ---------------------------------------------------------------------

@pipeline_tool(toolkit="covenant", name="save_rate_card_terms")
def save_rate_card_terms(
    contract_id: str,
    rate_card_data: List[Dict[str, Any]],
    project_dir: str = ""
) -> Dict[str, Any]:
    """Save rate card entries to contract_terms table.
    
    Args:
        contract_id: Contract ID
        rate_card_data: List of rate card entries, each with:
            - role: Role name (e.g., "Senior Engineer")
            - hourly_rate: Hourly rate (float)
            - allowed_hours: Allowed hours (int)
            - total_amount: Total amount (float)
        project_dir: Project root directory
    
    Returns:
        Dictionary with saved term IDs and count
    """
    try:
        _validate_contract_id(contract_id)
        
        conn = _connect_db(project_dir)
        cursor = conn.cursor()
        
        saved_terms = []
        for idx, role_data in enumerate(rate_card_data, 1):
            term_id = f"TERM-{contract_id}-rate_card_{idx}"
            clause_identifier = f"rate_card_{role_data.get('role', f'role_{idx}')}"
            
            # Create term value JSON
            term_value = {
                "role": role_data.get("role"),
                "hourly_rate": role_data.get("hourly_rate"),
                "allowed_hours": role_data.get("allowed_hours"),
                "total_amount": role_data.get("total_amount")
            }
            
            term_text = f"Role: {role_data.get('role')}, Hourly Rate: £{role_data.get('hourly_rate'):,}, Allowed Hours: {role_data.get('allowed_hours'):,}, Total: £{role_data.get('total_amount'):,}"
            
            # Insert or replace term
            cursor.execute("""
                INSERT OR REPLACE INTO contract_terms (
                    term_id, contract_id, clause_identifier, clause_number,
                    section_name, term_category, term_text, term_value,
                    effective_date, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            """, (
                term_id, contract_id,
                clause_identifier,
                f"rate_card_{idx}",
                "RATE CARD",
                "rate_card",
                term_text,
                json.dumps(term_value),
                None
            ))
            
            # Insert history entry for initial creation
            cursor.execute("""
                INSERT INTO term_history (
                    term_id, change_order_id, change_order_version, action,
                    clause_identifier, new_value, new_text, changed_by, changed_at
                ) VALUES (?, NULL, NULL, 'created', ?, ?, ?, 'initial', CURRENT_TIMESTAMP)
            """, (
                term_id,
                clause_identifier,
                json.dumps(term_value),
                term_text
            ))
            
            saved_terms.append(term_id)
        
        conn.commit()
        conn.close()
        
        _logger.debug("Saved {} rate card entries for contract {} to database", len(saved_terms), contract_id)
        return {"contract_id": contract_id, "terms_saved": len(saved_terms), "term_ids": saved_terms}
    
    except Exception as e:
        _logger.error("Error saving rate card terms for {}: {}", contract_id, e)
        raise


@pipeline_tool(toolkit="covenant", name="get_rate_card_terms")
def get_rate_card_terms(
    contract_id: str,
    project_dir: str = ""
) -> List[Dict[str, Any]]:
    """Get all rate card terms for a contract from database.
    
    Args:
        contract_id: Contract ID
        project_dir: Project root directory
    
    Returns:
        List of rate card entries with role, hourly_rate, allowed_hours, total_amount
    """
    try:
        _validate_contract_id(contract_id)
        
        conn = _connect_db(project_dir)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT term_value
            FROM contract_terms
            WHERE contract_id = ? AND term_category = 'rate_card'
            ORDER BY clause_identifier
        """, (contract_id,))
        
        rate_card = []
        for row in cursor.fetchall():
            if row["term_value"]:
                role_data = json.loads(row["term_value"])
                rate_card.append(role_data)
        
        conn.close()
        
        _logger.debug("Retrieved {} rate card entries for contract {} from database", len(rate_card), contract_id)
        return rate_card
    
    except Exception as e:
        _logger.error("Error getting rate card terms for {}: {}", contract_id, e)
        raise


@pipeline_tool(toolkit="covenant", name="update_rate_card_terms")
def update_rate_card_terms(
    contract_id: str,
    rate_card_changes: List[Dict[str, Any]],
    change_order_id: str,
    change_order_version: str,
    project_dir: str = ""
) -> Dict[str, Any]:
    """Update rate card terms from change order.
    
    Args:
        contract_id: Contract ID
        rate_card_changes: List of rate card changes, each with:
            - role: Role name
            - hourly_rate: New hourly rate (optional)
            - allowed_hours: New allowed hours (optional)
            - total_amount: New total amount (optional)
            - change_type: "added", "modified", or "removed"
        change_order_id: Change order ID
        change_order_version: Change order version
        project_dir: Project root directory
    
    Returns:
        Dictionary with updated term IDs and count
    """
    try:
        _validate_contract_id(contract_id)
        
        # Get existing rate card terms
        existing_rate_card = get_rate_card_terms(contract_id, project_dir)
        
        conn = _connect_db(project_dir)
        cursor = conn.cursor()
        
        updated_terms = []
        for change in rate_card_changes:
            role = change.get("role")
            change_type = change.get("change_type", "modified")
            
            if change_type == "removed":
                # Delete rate card entry
                cursor.execute("""
                    DELETE FROM contract_terms
                    WHERE contract_id = ? AND term_category = 'rate_card'
                    AND term_value LIKE ?
                """, (contract_id, f'%"role": "{role}"%'))
                updated_terms.append(f"removed_{role}")
            
            elif change_type == "added":
                # Add new rate card entry
                term_id = f"TERM-{contract_id}-rate_card_{len(existing_rate_card) + 1}"
                clause_identifier = f"rate_card_{role}"
                
                term_value = {
                    "role": role,
                    "hourly_rate": change.get("hourly_rate", 0),
                    "allowed_hours": change.get("allowed_hours", 0),
                    "total_amount": change.get("total_amount", 0)
                }
                
                term_text = f"Role: {role}, Hourly Rate: £{change.get('hourly_rate', 0):,}, Allowed Hours: {change.get('allowed_hours', 0):,}, Total: £{change.get('total_amount', 0):,}"
                
                cursor.execute("""
                    INSERT INTO contract_terms (
                        term_id, contract_id, clause_identifier, clause_number,
                        section_name, term_category, term_text, term_value,
                        effective_date, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                """, (
                    term_id, contract_id, clause_identifier, f"rate_card_{len(existing_rate_card) + 1}",
                    "RATE CARD", "rate_card", term_text, json.dumps(term_value), None
                ))
                
                # Add history entry
                cursor.execute("""
                    INSERT INTO term_history (
                        term_id, change_order_id, change_order_version, action,
                        clause_identifier, new_value, new_text, changed_by, changed_at
                    ) VALUES (?, ?, ?, 'added', ?, ?, ?, ?, CURRENT_TIMESTAMP)
                """, (
                    term_id, change_order_id, change_order_version,
                    clause_identifier, json.dumps(term_value), term_text, change_order_version
                ))
                
                updated_terms.append(term_id)
            
            else:  # modified
                # Find existing entry and update
                cursor.execute("""
                    SELECT term_id, term_value
                    FROM contract_terms
                    WHERE contract_id = ? AND term_category = 'rate_card'
                    AND term_value LIKE ?
                """, (contract_id, f'%"role": "{role}"%'))
                
                row = cursor.fetchone()
                if row:
                    old_value = json.loads(row["term_value"])
                    new_value = old_value.copy()
                    
                    # Update fields
                    if "hourly_rate" in change:
                        new_value["hourly_rate"] = change["hourly_rate"]
                    if "allowed_hours" in change:
                        new_value["allowed_hours"] = change["allowed_hours"]
                    if "total_amount" in change:
                        new_value["total_amount"] = change["total_amount"]
                    
                    new_text = f"Role: {new_value['role']}, Hourly Rate: £{new_value['hourly_rate']:,}, Allowed Hours: {new_value['allowed_hours']:,}, Total: £{new_value['total_amount']:,}"
                    old_text = f"Role: {old_value['role']}, Hourly Rate: £{old_value['hourly_rate']:,}, Allowed Hours: {old_value['allowed_hours']:,}, Total: £{old_value['total_amount']:,}"
                    
                    # Update term
                    cursor.execute("""
                        UPDATE contract_terms
                        SET term_value = ?, term_text = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE term_id = ?
                    """, (json.dumps(new_value), new_text, row["term_id"]))
                    
                    # Add history entry
                    cursor.execute("""
                        INSERT INTO term_history (
                            term_id, change_order_id, change_order_version, action,
                            old_value, new_value, old_text, new_text, change_description, changed_by, changed_at
                        ) VALUES (?, ?, ?, 'modified', ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    """, (
                        row["term_id"], change_order_id, change_order_version,
                        json.dumps(old_value), json.dumps(new_value),
                        old_text, new_text,
                        f"Rate card updated for role {role}",
                        change_order_version
                    ))
                    
                    updated_terms.append(row["term_id"])
        
        conn.commit()
        conn.close()
        
        _logger.debug("Updated {} rate card entries for contract {} from change order {}", len(updated_terms), contract_id, change_order_version)
        return {"contract_id": contract_id, "terms_updated": len(updated_terms), "term_ids": updated_terms}
    
    except Exception as e:
        _logger.error("Error updating rate card terms for {}: {}", contract_id, e)
        raise


# ---------------------------------------------------------------------
# Milestone Operations
# ---------------------------------------------------------------------

@pipeline_tool(toolkit="covenant", name="save_milestone_terms")
def save_milestone_terms(
    contract_id: str,
    milestones_data: List[Dict[str, Any]],
    project_dir: str = ""
) -> Dict[str, Any]:
    """Save milestone entries to contract_terms table.
    
    Args:
        contract_id: Contract ID
        milestones_data: List of milestone entries, each with:
            - name: Milestone name
            - date: Due date (YYYY-MM-DD or datetime)
            - amount: Milestone amount (float)
        project_dir: Project root directory
    
    Returns:
        Dictionary with saved term IDs and count
    """
    try:
        _validate_contract_id(contract_id)
        
        conn = _connect_db(project_dir)
        cursor = conn.cursor()
        
        saved_terms = []
        for idx, milestone in enumerate(milestones_data, 1):
            term_id = f"TERM-{contract_id}-milestone_{milestone.get('name', f'milestone_{idx}')}"
            clause_identifier = f"milestone_{milestone.get('name', f'milestone_{idx}')}"
            
            # Handle date format
            milestone_date = milestone.get("date")
            if isinstance(milestone_date, str):
                date_str = milestone_date
            else:
                date_str = milestone_date.strftime('%Y-%m-%d') if milestone_date else None
            
            # Create term value JSON
            term_value = {
                "name": milestone.get("name"),
                "date": date_str,
                "amount": milestone.get("amount")
            }
            
            term_text = f"Milestone: {milestone.get('name')}, Due Date: {date_str}, Amount: £{milestone.get('amount', 0):,}"
            
            # Insert or replace term
            cursor.execute("""
                INSERT OR REPLACE INTO contract_terms (
                    term_id, contract_id, clause_identifier, clause_number,
                    section_name, term_category, term_text, term_value,
                    effective_date, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            """, (
                term_id, contract_id,
                clause_identifier,
                f"milestone_{idx}",
                "MILESTONES & DELIVERABLES",
                "milestone",
                term_text,
                json.dumps(term_value),
                None
            ))
            
            # Insert history entry for initial creation
            cursor.execute("""
                INSERT INTO term_history (
                    term_id, change_order_id, change_order_version, action,
                    clause_identifier, new_value, new_text, changed_by, changed_at
                ) VALUES (?, NULL, NULL, 'created', ?, ?, ?, 'initial', CURRENT_TIMESTAMP)
            """, (
                term_id,
                clause_identifier,
                json.dumps(term_value),
                term_text
            ))
            
            saved_terms.append(term_id)
        
        conn.commit()
        conn.close()
        
        _logger.debug("Saved {} milestone entries for contract {} to database", len(saved_terms), contract_id)
        return {"contract_id": contract_id, "terms_saved": len(saved_terms), "term_ids": saved_terms}
    
    except Exception as e:
        _logger.error("Error saving milestone terms for {}: {}", contract_id, e)
        raise


@pipeline_tool(toolkit="covenant", name="get_milestone_terms")
def get_milestone_terms(
    contract_id: str,
    project_dir: str = ""
) -> List[Dict[str, Any]]:
    """Get all milestone terms for a contract from database.
    
    Args:
        contract_id: Contract ID
        project_dir: Project root directory
    
    Returns:
        List of milestone entries with name, date, amount
    """
    try:
        _validate_contract_id(contract_id)
        
        conn = _connect_db(project_dir)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT term_value
            FROM contract_terms
            WHERE contract_id = ? AND term_category = 'milestone'
            ORDER BY clause_identifier
        """, (contract_id,))
        
        milestones = []
        for row in cursor.fetchall():
            if row["term_value"]:
                milestone = json.loads(row["term_value"])
                milestones.append(milestone)
        
        conn.close()
        
        _logger.debug("Retrieved {} milestone entries for contract {} from database", len(milestones), contract_id)
        return milestones
    
    except Exception as e:
        _logger.error("Error getting milestone terms for {}: {}", contract_id, e)
        raise


@pipeline_tool(toolkit="covenant", name="update_milestone_terms")
def update_milestone_terms(
    contract_id: str,
    milestone_changes: List[Dict[str, Any]],
    change_order_id: str,
    change_order_version: str,
    project_dir: str = ""
) -> Dict[str, Any]:
    """Update milestone terms from change order.
    
    Args:
        contract_id: Contract ID
        milestone_changes: List of milestone changes, each with:
            - name: Milestone name
            - date: New due date (optional)
            - amount: New amount (optional)
            - change_type: "added", "modified", or "removed"
        change_order_id: Change order ID
        change_order_version: Change order version
        project_dir: Project root directory
    
    Returns:
        Dictionary with updated term IDs and count
    """
    try:
        _validate_contract_id(contract_id)
        
        # Get existing milestone terms
        existing_milestones = get_milestone_terms(contract_id, project_dir)
        
        conn = _connect_db(project_dir)
        cursor = conn.cursor()
        
        updated_terms = []
        for change in milestone_changes:
            milestone_name = change.get("name")
            change_type = change.get("change_type", "modified")
            
            if change_type == "removed":
                # Delete milestone entry
                cursor.execute("""
                    DELETE FROM contract_terms
                    WHERE contract_id = ? AND term_category = 'milestone'
                    AND term_value LIKE ?
                """, (contract_id, f'%"name": "{milestone_name}"%'))
                updated_terms.append(f"removed_{milestone_name}")
            
            elif change_type == "added":
                # Add new milestone entry
                term_id = f"TERM-{contract_id}-milestone_{milestone_name}"
                clause_identifier = f"milestone_{milestone_name}"
                
                milestone_date = change.get("date")
                if isinstance(milestone_date, str):
                    date_str = milestone_date
                else:
                    date_str = milestone_date.strftime('%Y-%m-%d') if milestone_date else None
                
                term_value = {
                    "name": milestone_name,
                    "date": date_str,
                    "amount": change.get("amount", 0)
                }
                
                term_text = f"Milestone: {milestone_name}, Due Date: {date_str}, Amount: £{change.get('amount', 0):,}"
                
                cursor.execute("""
                    INSERT INTO contract_terms (
                        term_id, contract_id, clause_identifier, clause_number,
                        section_name, term_category, term_text, term_value,
                        effective_date, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                """, (
                    term_id, contract_id, clause_identifier, f"milestone_{len(existing_milestones) + 1}",
                    "MILESTONES & DELIVERABLES", "milestone", term_text, json.dumps(term_value), None
                ))
                
                # Add history entry
                cursor.execute("""
                    INSERT INTO term_history (
                        term_id, change_order_id, change_order_version, action,
                        clause_identifier, new_value, new_text, changed_by, changed_at
                    ) VALUES (?, ?, ?, 'added', ?, ?, ?, ?, CURRENT_TIMESTAMP)
                """, (
                    term_id, change_order_id, change_order_version,
                    clause_identifier, json.dumps(term_value), term_text, change_order_version
                ))
                
                updated_terms.append(term_id)
            
            else:  # modified
                # Find existing entry and update
                cursor.execute("""
                    SELECT term_id, term_value
                    FROM contract_terms
                    WHERE contract_id = ? AND term_category = 'milestone'
                    AND term_value LIKE ?
                """, (contract_id, f'%"name": "{milestone_name}"%'))
                
                row = cursor.fetchone()
                if row:
                    old_value = json.loads(row["term_value"])
                    new_value = old_value.copy()
                    
                    # Update fields
                    if "date" in change:
                        milestone_date = change["date"]
                        if isinstance(milestone_date, str):
                            new_value["date"] = milestone_date
                        else:
                            new_value["date"] = milestone_date.strftime('%Y-%m-%d') if milestone_date else None
                    if "amount" in change:
                        new_value["amount"] = change["amount"]
                    
                    new_text = f"Milestone: {new_value['name']}, Due Date: {new_value['date']}, Amount: £{new_value['amount']:,}"
                    old_text = f"Milestone: {old_value['name']}, Due Date: {old_value['date']}, Amount: £{old_value['amount']:,}"
                    
                    # Update term
                    cursor.execute("""
                        UPDATE contract_terms
                        SET term_value = ?, term_text = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE term_id = ?
                    """, (json.dumps(new_value), new_text, row["term_id"]))
                    
                    # Add history entry
                    cursor.execute("""
                        INSERT INTO term_history (
                            term_id, change_order_id, change_order_version, action,
                            old_value, new_value, old_text, new_text, change_description, changed_by, changed_at
                        ) VALUES (?, ?, ?, 'modified', ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    """, (
                        row["term_id"], change_order_id, change_order_version,
                        json.dumps(old_value), json.dumps(new_value),
                        old_text, new_text,
                        f"Milestone updated: {milestone_name}",
                        change_order_version
                    ))
                    
                    updated_terms.append(row["term_id"])
        
        conn.commit()
        conn.close()
        
        _logger.debug("Updated {} milestone entries for contract {} from change order {}", len(updated_terms), contract_id, change_order_version)
        return {"contract_id": contract_id, "terms_updated": len(updated_terms), "term_ids": updated_terms}
    
    except Exception as e:
        _logger.error("Error updating milestone terms for {}: {}", contract_id, e)
        raise


@pipeline_tool(toolkit="covenant", name="save_change_order")
def save_change_order(
    contract_id: str,
    change_order_version: str,
    change_order_file_path: str,
    change_order_date: str,
    effective_date: Optional[str] = None,
    status: str = "approved",
    run_id: Optional[str] = None,
    project_dir: str = ""
) -> Dict[str, Any]:
    """Save change order record to database.
    
    **Requirements:**
    - contract_id must follow format: SOW-YYYY-XXXX
    - change_order_version should be "v1", "v2", "v3", etc.
    - change_order_file_path must be a valid file path to the change order PDF
    - Dates should be in YYYY-MM-DD format
    - run_id should be provided from orchestrator context (use {{run_id}})
    - project_dir must be the actual project directory path
    
    **Example:**
    save_change_order(
        contract_id="SOW-2025-2019",
        change_order_version="v1",
        change_order_file_path="/path/to/change_order.pdf",
        change_order_date="2025-03-15",
        effective_date="2025-03-15",
        status="approved",
        run_id="{{run_id}}",
        project_dir="/path/to/projects/pa"
    )
    
    Args:
        contract_id: Contract ID in format SOW-YYYY-XXXX (e.g., "SOW-2025-2019")
        change_order_version: Version identifier (e.g., "v1", "v2", "v3")
        change_order_file_path: Full path to change order PDF file
        change_order_date: Change order date in YYYY-MM-DD format
        effective_date: Effective date in YYYY-MM-DD format (optional)
        status: Status - "pending", "approved", "rejected", or "superseded" (default: "approved")
        run_id: Processing run ID from orchestrator context (use {{run_id}}) (optional)
        project_dir: Project root directory (REQUIRED: use actual Project_Dir value from inputs)
    
    Returns:
        Dictionary with change_order_id: {"change_order_id": "CO-SOW-2025-2019-v1", "status": "saved"}
    
    Raises:
        ValueError: If contract_id format is invalid
    """
    try:
        _validate_contract_id(contract_id)
        
        conn = _connect_db(project_dir)
        cursor = conn.cursor()
        
        change_order_id = f"CO-{contract_id}-{change_order_version}"
        
        cursor.execute("""
            INSERT OR REPLACE INTO change_orders (
                change_order_id, contract_id, change_order_version,
                change_order_file_path, change_order_date, effective_date,
                run_id, status, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        """, (change_order_id, contract_id, change_order_version, change_order_file_path,
              change_order_date, effective_date, run_id, status))
        
        conn.commit()
        conn.close()
        
        _logger.debug("Saved change order {} to database", change_order_id)
        return {"change_order_id": change_order_id, "status": "saved"}
    
    except Exception as e:
        _logger.error("Error saving change order {}: {}", change_order_id, e)
        raise


@pipeline_tool(toolkit="covenant", name="update_term_from_change_order")
def update_term_from_change_order(
    term_id: str,
    change_order_id: str,
    change_order_version: str,
    new_value: Dict[str, Any],
    new_text: str,
    old_value: Dict[str, Any],
    old_text: str,
    change_description: str,
    project_dir: str = ""
) -> Dict[str, Any]:
    """Update a term from change order and create audit trail.
    
    **CRITICAL REQUIREMENTS:**
    - Both old_value and new_value MUST be non-empty dictionaries (not None, not empty dict, not strings)
    - old_value must contain the structured data BEFORE the change
    - new_value must contain the structured data AFTER the change
    - Both must be valid JSON-serializable dictionaries
    
    **Example:**
    If payment terms change from "Net 30 days" to "Net 75 days":
    - old_value: {"payment_terms": "Net 30 days"}
    - new_value: {"payment_terms": "Net 75 days"}
    - old_text: "Payment terms: Net 30 days from invoice date"
    - new_text: "Payment terms: Net 75 days from invoice date"
    
    **Common Mistakes to Avoid:**
    - DO NOT pass None for old_value or new_value
    - DO NOT pass empty dictionaries {}
    - DO NOT pass strings like "Net 30 days" - must be dict like {"payment_terms": "Net 30 days"}
    - DO NOT omit project_dir - use the actual Project_Dir value from inputs
    
    Args:
        term_id: Term ID to update (e.g., "TERM-SOW-2026-2269-3.1.payment_terms")
        change_order_id: Change order ID (e.g., "SOW-2026-2269-change-order-v1")
        change_order_version: Change order version (e.g., "v1", "v2")
        new_value: New structured value as a dictionary (REQUIRED: non-empty dict)
            Example: {"payment_terms": "Net 75 days"} or {"contract_value": 500000, "currency": "GBP"}
        new_text: New text value (e.g., "Payment terms: Net 75 days from invoice date")
        old_value: Old structured value as a dictionary (REQUIRED: non-empty dict)
            Example: {"payment_terms": "Net 30 days"} or {"contract_value": 400000, "currency": "GBP"}
        old_text: Old text value (e.g., "Payment terms: Net 30 days from invoice date")
        change_description: Human-readable description (e.g., "Payment terms extended from Net 30 days to Net 75 days")
        project_dir: Project root directory (REQUIRED: use actual Project_Dir value from inputs, e.g., "/path/to/projects/pa")
    
    Returns:
        Dictionary with update status: {"term_id": "...", "status": "updated"}
    
    Raises:
        ValueError: If old_value or new_value is None, empty dict, or not a dict
    """
    # Validate required fields
    # Both old_value and new_value must be non-empty dictionaries for an update operation
    if not new_value or not isinstance(new_value, dict) or len(new_value) == 0:
        _logger.error("Missing or invalid new_value field in update_term_from_change_order tool input: got {} (type: {})", new_value, type(new_value).__name__ if new_value is not None else "None")
        raise ValueError("Failed to update term audit trail in database: missing or invalid new_value field. new_value must be a non-empty dictionary, but got: {} (type: {})".format(new_value, type(new_value).__name__ if new_value is not None else "None"))
    if not old_value or not isinstance(old_value, dict) or len(old_value) == 0:
        _logger.error("Missing or invalid old_value field in update_term_from_change_order tool input: got {} (type: {})", old_value, type(old_value).__name__ if old_value is not None else "None")
        raise ValueError("Failed to update term audit trail in database: missing or invalid old_value field. old_value must be a non-empty dictionary, but got: {} (type: {})".format(old_value, type(old_value).__name__ if old_value is not None else "None"))
    
    try:
        conn = _connect_db(project_dir)
        cursor = conn.cursor()
        
        # Update contract_terms table
        cursor.execute("""
            UPDATE contract_terms
            SET term_value = ?, term_text = ?, updated_at = CURRENT_TIMESTAMP
            WHERE term_id = ?
        """, (json.dumps(new_value) if new_value else None, new_text, term_id))
        
        # Insert history entry
        cursor.execute("""
            INSERT INTO term_history (
                term_id, change_order_id, change_order_version, action,
                old_value, new_value, old_text, new_text, change_description, changed_by, changed_at
            ) VALUES (?, ?, ?, 'modified', ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        """, (
            term_id, change_order_id, change_order_version,
            json.dumps(old_value) if old_value else None,
            json.dumps(new_value) if new_value else None,
            old_text, new_text, change_description, change_order_version
        ))
        
        conn.commit()
        conn.close()
        
        _logger.debug("Updated term {} from change order {}", term_id, change_order_id)
        return {"term_id": term_id, "status": "updated"}
    
    except Exception as e:
        _logger.error("Error updating term {} from change order {}: {}", term_id, change_order_id, e)
        raise


@pipeline_tool(toolkit="covenant", name="get_term_history")
def get_term_history(
    term_id: str,
    project_dir: str = ""
) -> List[Dict[str, Any]]:
    """Get complete audit trail for a term.
    
    Args:
        term_id: Term ID
        project_dir: Project root directory
    
    Returns:
        List of history entries ordered by changed_at
    """
    try:
        conn = _connect_db(project_dir)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT history_id, change_order_id, change_order_version, action,
                   old_value, new_value, old_text, new_text, change_description,
                   changed_by, changed_at
            FROM term_history
            WHERE term_id = ?
            ORDER BY changed_at
        """, (term_id,))
        
        history = []
        for row in cursor.fetchall():
            history.append({
                "history_id": row["history_id"],
                "change_order_id": row["change_order_id"],
                "change_order_version": row["change_order_version"],
                "action": row["action"],
                "old_value": json.loads(row["old_value"]) if row["old_value"] else None,
                "new_value": json.loads(row["new_value"]) if row["new_value"] else None,
                "old_text": row["old_text"],
                "new_text": row["new_text"],
                "change_description": row["change_description"],
                "changed_by": row["changed_by"],
                "changed_at": row["changed_at"]
            })
        
        conn.close()
        
        _logger.debug("Retrieved {} history entries for term {}", len(history), term_id)
        return history
    
    except Exception as e:
        _logger.error("Error getting term history for {}: {}", term_id, e)
        raise


@pipeline_tool(toolkit="covenant", name="get_change_order_modifications")
def get_change_order_modifications(
    change_order_id: str,
    project_dir: str = ""
) -> List[Dict[str, Any]]:
    """Get all term modifications for a change order.
    
    Args:
        change_order_id: Change order ID
        project_dir: Project root directory
    
    Returns:
        List of term modifications
    """
    try:
        conn = _connect_db(project_dir)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT history_id, term_id, change_order_version, action,
                   clause_identifier, old_value, new_value, old_text, new_text,
                   change_description, changed_by, changed_at
            FROM term_history
            WHERE change_order_id = ?
            ORDER BY changed_at
        """, (change_order_id,))
        
        modifications = []
        for row in cursor.fetchall():
            modifications.append({
                "history_id": row["history_id"],
                "term_id": row["term_id"],
                "change_order_version": row["change_order_version"],
                "action": row["action"],
                "clause_identifier": row["clause_identifier"],
                "old_value": json.loads(row["old_value"]) if row["old_value"] else None,
                "new_value": json.loads(row["new_value"]) if row["new_value"] else None,
                "old_text": row["old_text"],
                "new_text": row["new_text"],
                "change_description": row["change_description"],
                "changed_by": row["changed_by"],
                "changed_at": row["changed_at"]
            })
        
        conn.close()
        
        _logger.debug("Retrieved {} modifications for change order {}", len(modifications), change_order_id)
        return modifications
    
    except Exception as e:
        _logger.error("Error getting change order modifications for {}: {}", change_order_id, e)
        raise


@pipeline_tool(toolkit="covenant", name="move_document_to_processed")
def move_document_to_processed(
    file_path: str,
    project_dir: str = ""
) -> Dict[str, Any]:
    """Move a document from pending folder to processed folder.
    
    Args:
        file_path: Absolute path to document in pending folder
        project_dir: Project root directory
    
    Returns:
        Dictionary with new file path and status
    """
    try:
        source_path = Path(file_path)
        
        if not source_path.exists():
            raise FileNotFoundError(f"Source file does not exist: {file_path}")
        
        # Resolve processed folder
        processed_dir = _resolve_path(project_dir, "data/covenant/processed")
        processed_dir.mkdir(parents=True, exist_ok=True)
        
        # Move file
        dest_path = processed_dir / source_path.name
        shutil.move(str(source_path), str(dest_path))
        
        _logger.debug("Moved document from {} to {}", file_path, dest_path)
        return {"status": "moved", "original_path": str(source_path), "processed_path": str(dest_path)}
    
    except Exception as e:
        _logger.error("Error moving document {}: {}", file_path, e)
        raise
