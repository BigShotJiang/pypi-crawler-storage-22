# Merge Current Branch to Main

Merge the current branch into main using --no-ff to preserve branch history.

## Steps:

1. **Get current branch name** (fail if cannot determine)
   ```bash
   CURRENT_BRANCH=$(git branch --show-current)
   if [ -z "$CURRENT_BRANCH" ]; then
     echo "Error: Could not determine current branch"
     exit 1
   fi
   ```

2. **Check if already on main** (prevent accidental merge)
   ```bash
   if [ "$CURRENT_BRANCH" = "main" ]; then
     echo "Error: Already on main branch. Cannot merge main into itself."
     exit 1
   fi
   ```

3. **Check for uncommitted changes** (ensure clean working directory)
   ```bash
   if ! git diff-index --quiet HEAD --; then
     echo "Error: Working directory has uncommitted changes. Please commit or stash them first."
     exit 1
   fi
   ```

4. **Check for untracked files** (optional safety check)
   ```bash
   if [ -n "$(git ls-files --others --exclude-standard)" ]; then
     echo "Warning: Untracked files detected. They will not be affected by merge."
     read -p "Continue anyway? (y/n) " -n 1 -r
     echo
     if [[ ! $REPLY =~ ^[Yy]$ ]]; then
       exit 1
     fi
   fi
   ```

5. **Switch to main and pull latest** (ensure main is up to date)
   ```bash
   git checkout main || exit 1
   git pull origin main || exit 1
   ```

6. **Merge current branch with --no-ff** (preserve branch history)
   ```bash
   git merge --no-ff "$CURRENT_BRANCH" || {
     echo "Error: Merge failed. You may have conflicts to resolve."
     echo "After resolving conflicts, run: git commit"
     exit 1
   }
   ```

7. **Push to remote** (optional - uncomment if desired)
   ```bash
   # git push origin main
   ```

   Note: After merge, you will remain on the `main` branch.

## Complete Command:

```bash
CURRENT_BRANCH=$(git branch --show-current)
[ -z "$CURRENT_BRANCH" ] && { echo "Error: Could not determine current branch"; exit 1; }
[ "$CURRENT_BRANCH" = "main" ] && { echo "Error: Already on main branch"; exit 1; }
git diff-index --quiet HEAD -- || { echo "Error: Uncommitted changes detected"; exit 1; }
git checkout main && git pull origin main && git merge --no-ff "$CURRENT_BRANCH" && echo "Successfully merged $CURRENT_BRANCH into main"
```

## Notes:

- Uses `--no-ff` to create a merge commit even for fast-forward merges
- Fails fast if safety checks don't pass
- Preserves branch history in git log
- Remains on `main` branch after merge (does not switch back to original branch)
- Uncomment push step if you want automatic push to remote
