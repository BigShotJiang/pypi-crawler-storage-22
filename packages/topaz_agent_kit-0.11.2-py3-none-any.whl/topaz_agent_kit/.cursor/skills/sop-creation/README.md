# SOP Creation Skill

This skill provides a systematic workflow for creating Standard Operating Procedures (SOPs) for agents in Topaz Agent Kit.

## Skill Structure

All files required by the skill are contained in this folder:

### Core Workflow Files

- **SKILL.md** - Main skill definition with workflow overview
- **step1_requirements.md** - Requirements gathering guide
- **step2_design.md** - SOP structure design guide
- **step3_refinement.md** - Interactive refinement guide
- **step4_generation.md** - File generation guide
- **step5_validation.md** - Validation and summary guide

### Reference Documentation

- **reference_sop_creation_guide.md** - Comprehensive SOP creation guide
- **reference_minimal_structure.md** - Minimal SOP structure reference
- **reference_quick_reference.md** - Quick reference guide
- **reference_sub_agent_example.md** - Guide for creating a sub-agent that uses this skill

## How to Use

### Option 1: Use the Agent Specialist

The agent specialist (`.cursor/agents/sop-creation-specialist.md`) can be invoked in Cursor to guide you through the workflow.

### Option 2: Create a Sub-Agent

Follow the guide in `reference_sub_agent_example.md` (optional - not required for skill execution) to create an independent agent that uses this skill.

### Option 3: Manual Workflow

Follow the workflow defined in the skill files step by step.

## Workflow Overview

The skill follows a 5-step workflow:

1. **Requirements Gathering** - Collect all information needed
2. **SOP Structure Design** - Design the complete SOP structure
3. **Interactive Refinement** - Incorporate user feedback
4. **File Generation** - Generate all SOP files
5. **Validation & Summary** - Validate and provide completion summary

## Files Generated

The skill generates SOP files in `config/sop/{pipeline}/{agent}/` and updates agent configuration and prompts.

## Self-Contained

**All files required for skill execution are in this folder.** The skill does not depend on files from the `docs/` folder or any external project files. All reference documentation has been copied into this skill folder.

## Optional Reference Example

The skill references the **ReconVoy example** as a best practice reference throughout the workflow files. This example demonstrates a production-ready SOP with all best practices:

- **Location**: `config/sop/reconvoy/sop_matcher/` (in project directory, not in skill folder)
- **Availability**: Only exists in projects scaffolded with the `icp` starter
- **Purpose**: Optional reference for understanding best practices (not required for skill execution)
- **If not available**: The skill can still execute successfully using only the reference documentation in this folder
