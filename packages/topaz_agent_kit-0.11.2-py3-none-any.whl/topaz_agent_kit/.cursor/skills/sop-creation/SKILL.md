---
name: sop-creation
description: Creates Standard Operating Procedures (SOPs) for agents by systematically gathering requirements, designing SOP structure, generating manifest files, and creating documentation. Use when the user wants to create an SOP, generate SOP files, or says "create SOP", "new SOP", "SOP creation", "follow the SOP creation workflow", or "generate SOP config".
---

# SOP Creation

Execute this workflow systematically when creating a new Standard Operating Procedure (SOP) for an agent.

## Quick Reference: Files to Generate

| # | Type | Template | Location |
|---|------|----------|----------|
| 1 | SOP manifest | `manifest.yml` | `config/sop/<pipeline>/<agent>/` |
| 2 | Overview | `overview.md` | `config/sop/<pipeline>/<agent>/` |
| 3 | Step files (×N) | `step_XX_*.md` | `config/sop/<pipeline>/<agent>/steps/` |
| 4 | Scenario examples (×N) | `scenario_*.md` | `config/sop/<pipeline>/<agent>/scenarios/` |
| 5 | Troubleshooting | `troubleshooting.md` | `config/sop/<pipeline>/<agent>/` |
| 6 | Pipeline glossary | `glossary.md` | `config/sop/<pipeline>/` |

**Update existing files:**
- Agent config (`config/agents/{agent_id}.yml`) — Add `sop` path and MCP toolkit configuration
- Agent prompt (`config/prompts/{agent_id}.jinja`) — Add SOP initialization and usage instructions

## Base Path

**🔍 FIRST**: Ask user for:
1. **Pipeline ID** (where the agent belongs)
2. **Agent ID** (which agent needs the SOP)
3. **Project directory** (default: current project)

All file paths are relative to the project directory.

## Workflow Steps

Execute these steps IN ORDER. Do not skip steps. Pause at checkpoints (🔍).

### Step 1: Requirements Gathering
📄 **Reference**: [step1_requirements.md](step1_requirements.md)

**Collect systematically:**
1. Pipeline ID (where agent belongs)
2. Agent ID (which agent needs SOP)
3. Agent role and purpose (what the agent does)
4. Workflow steps (list of steps the agent follows)
5. Tools available (what tools the agent can use)
6. Output format (what the agent returns)
7. Scenarios to document (example use cases)
8. Common errors/issues (troubleshooting needs)
9. Domain terms (glossary requirements)
10. SOP complexity level (minimal/recommended/comprehensive)

**🔍 CHECKPOINT 1**: Present requirements summary. Wait for user approval before proceeding.

### Step 2: SOP Structure Design
📄 **Reference**: [step2_design.md](step2_design.md)

**Design:**
1. Determine SOP structure (minimal/recommended/comprehensive)
2. Define manifest.yml structure with sections
3. Plan overview.md content (role, workflow, tools, output)
4. Design step files (procedure steps with metadata)
5. Plan scenario examples (concrete use cases)
6. Design troubleshooting guide (common issues)
7. Plan glossary terms (domain-specific definitions)
8. Create structure proposal document

**🔍 CHECKPOINT 2**: Present SOP structure proposal. Wait for user approval.

### Step 3: Interactive Refinement
📄 **Reference**: [step3_refinement.md](step3_refinement.md)

1. Review and incorporate user feedback
2. Make adjustments to structure
3. Resolve any conflicts or issues
4. Document final decisions

**🔍 CHECKPOINT 3**: Final confirmation before file generation. Explicit "proceed" required.

### Step 4: File Generation
📄 **Reference**: [step4_generation.md](step4_generation.md)

**Generate files in this order:**

1. **Create directory structure** → `config/sop/<pipeline>/<agent>/`
2. **SOP manifest** → `config/sop/<pipeline>/<agent>/manifest.yml`
3. **Overview** → `config/sop/<pipeline>/<agent>/overview.md`
4. **Step files** → `config/sop/<pipeline>/<agent>/steps/step_XX_*.md` (for each step)
5. **Scenario examples** → `config/sop/<pipeline>/<agent>/scenarios/scenario_*.md` (if any)
6. **Troubleshooting** → `config/sop/<pipeline>/<agent>/troubleshooting.md` (if needed)
7. **Pipeline glossary** → `config/sop/<pipeline>/glossary.md` (if needed)
8. **Update agent config** → Add `sop` path and MCP toolkit to `config/agents/{agent_id}.yml`
9. **Update agent prompt** → Add SOP instructions to `config/prompts/{agent_id}.jinja`

**🔍 CHECKPOINT 4**: Review generated files with user. Ask if any changes needed.

### Step 5: Validation & Summary
📄 **Reference**: [step5_validation.md](step5_validation.md)

**Validate:**
1. All required files exist
2. manifest.yml structure is valid
3. All referenced files exist
4. Agent config includes SOP path and MCP toolkit
5. Agent prompt includes SOP initialization instructions
6. Section IDs match file names
7. No broken references

**Generate summary:**
- SOP location and structure
- Files created
- Agent configuration updates
- Testing instructions

**🔍 CHECKPOINT 5**: Final review and completion confirmation.

## Critical Rules

### Naming Conventions

| Type | Format | Example |
|------|--------|---------|
| Pipeline ID | `snake_case` | `reconvoy`, `article_smith` |
| Agent ID | `snake_case` | `sop_matcher`, `research_analyst` |
| Section ID | `snake_case` | `step_01_identify_target`, `scenario_two_way_match` |
| Step file | `step_XX_description.md` | `step_01_identify_target.md` |
| Scenario file | `scenario_name.md` | `two_way_match.md` |

### File Paths

- All paths are relative to project directory
- SOP location: `config/sop/<pipeline>/<agent>/`
- Glossary location: `config/sop/<pipeline>/glossary.md` (pipeline-level, shared)

### SOP Structure Levels

**Minimal (Bare Minimum):**
- `manifest.yml` only (with `sop_id`, `version`, `description`)

**Recommended (Actually Useful):**
- `manifest.yml` + `overview.md`

**Comprehensive (Best Practice):**
- `manifest.yml` + `overview.md` + `steps/` + `scenarios/` + `troubleshooting.md` + `glossary.md`

### Section Types

| Type | Purpose | read_at | Example |
|------|---------|---------|---------|
| `reference` | Context, overview | `start` or `on_demand` | `overview.md` |
| `procedure` | Step-by-step actions | `on_demand` | `steps/step_01_*.md` |
| `example` | Scenario patterns | `on_demand` | `scenarios/two_way_match.md` |
| `troubleshooting` | Error resolution | `on_demand` | `troubleshooting.md` |

## State Tracking

Track progress through the workflow:

```
SOP Creation State
─────────────────────────────────
Pipeline ID:        [ ]
Agent ID:           [ ]
SOP Complexity:     [ ]
─────────────────────────────────
Step 1 Complete:    [ ]
Step 2 Complete:    [ ]
Step 3 Complete:    [ ]
Step 4 Complete:    [ ]
Step 5 Complete:    [ ]
─────────────────────────────────
Files Created:      [ ]
Agent Config Updated: [ ]
Agent Prompt Updated: [ ]
Validation:         [ ]
```

## Testing Commands

After generation, provide:

```bash
# Test agent with SOP
topaz-agent-kit serve cli --project <project_dir>

# Or test via UI
topaz-agent-kit serve fastapi --project <project_dir>
```

## Completion Checklist

Before marking workflow complete, verify:

- [ ] Directory structure created
- [ ] manifest.yml generated with all sections
- [ ] overview.md created (if recommended/comprehensive)
- [ ] Step files created (if comprehensive)
- [ ] Scenario files created (if comprehensive)
- [ ] Troubleshooting guide created (if comprehensive)
- [ ] Glossary created (if comprehensive)
- [ ] Agent config updated with SOP path and MCP toolkit
- [ ] Agent prompt updated with SOP instructions
- [ ] All file paths validated
- [ ] No broken references
- [ ] User has received testing instructions

## Reference Documentation

- **SOP Creation Guide**: [reference_sop_creation_guide.md](reference_sop_creation_guide.md)
- **Minimal SOP Structure**: [reference_minimal_structure.md](reference_minimal_structure.md)
- **SOP Quick Reference**: [reference_quick_reference.md](reference_quick_reference.md)
- **ReconVoy Example**: `config/sop/reconvoy/sop_matcher/` (best practice reference - in project directory)
