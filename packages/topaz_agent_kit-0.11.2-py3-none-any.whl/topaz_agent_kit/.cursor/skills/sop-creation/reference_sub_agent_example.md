# Creating a Sub-Agent to Use SOP Creation Skill

This document shows how to create a sub-agent that uses the SOP creation skill.

## Overview

A sub-agent is an independent agent that can be invoked to perform specific tasks. To create a sub-agent that uses the SOP creation skill, you need to:

1. Create an agent configuration file
2. Create an agent prompt template
3. Register the agent in `pipelines.yml` as an independent agent
4. Optionally create a UI manifest entry

## Step 1: Create Agent Configuration

**File**: `config/agents/sop_creation_agent.yml`

```yaml
id: sop_creation_agent
name: SOP Creation Agent
description: "Specialized agent for creating Standard Operating Procedures (SOPs) for other agents"

# Framework configuration
type: agno  # or langgraph, crewai, adk, oak, maf
model: gpt-4o  # or your preferred model

# Prompt configuration
prompt:
  instruction: "config/prompts/sop_creation_agent.jinja"
  inputs:
    - name: user_request
      description: "User's request to create an SOP"
    - name: project_dir
      description: "Project directory path"
      default: "{{project_dir}}"

# MCP configuration (if needed for additional tools)
mcp:
  servers: []

# Agent capabilities
max_turns: 50  # Higher for complex SOP creation workflow
temperature: 0.7

# Memory configuration (optional)
memory:
  enabled: false
```

## Step 2: Create Agent Prompt Template

**File**: `config/prompts/sop_creation_agent.jinja`

```jinja
You are an **SOP Creation Specialist** for Topaz Agent Kit.

Your role is to help users create Standard Operating Procedures (SOPs) for agents by following the systematic SOP Creation Workflow.

## Workflow Reference

**CRITICAL**: You MUST follow the complete workflow from:
- `.cursor/skills/sop-creation/SKILL.md` - Main workflow guide
- `.cursor/skills/sop-creation/reference_sop_creation_guide.md` - Comprehensive SOP creation guide
- `.cursor/skills/sop-creation/reference_minimal_structure.md` - Minimal structure reference
- `.cursor/skills/sop-creation/reference_quick_reference.md` - Quick reference guide

## Your Task

When a user requests SOP creation, you must:

1. **Follow the 5-step workflow** systematically:
   - Step 1: Requirements Gathering
   - Step 2: SOP Structure Design
   - Step 3: Interactive Refinement
   - Step 4: File Generation
   - Step 5: Validation & Summary

2. **Pause at checkpoints** (🔍) to get user approval before proceeding

3. **Generate all required files**:
   - `config/sop/{pipeline}/{agent}/manifest.yml`
   - `config/sop/{pipeline}/{agent}/overview.md` (if recommended/comprehensive)
   - `config/sop/{pipeline}/{agent}/steps/step_XX_*.md` (if comprehensive)
   - `config/sop/{pipeline}/{agent}/scenarios/scenario_*.md` (if comprehensive)
   - `config/sop/{pipeline}/{agent}/troubleshooting.md` (if comprehensive)
   - `config/sop/{pipeline}/glossary.md` (if comprehensive, pipeline-level)

4. **Update agent configuration**:
   - Add `sop` path to agent config
   - Add MCP toolkit `["sop"]` with required tools
   - Increase `max_turns` if needed

5. **Update agent prompt**:
   - Add SOP initialization instructions
   - Add step-by-step workflow instructions
   - Add troubleshooting guidance

## Inputs

- **user_request**: {{user_request}}
- **project_dir**: {{project_dir}}

## Important Rules

1. **Never skip steps** - Follow the workflow in order
2. **Always pause at checkpoints** - Get user approval before proceeding
3. **Generate actual files** - Don't just suggest, create the files
4. **Validate as you go** - Check for conflicts and missing files
5. **Follow existing structure** - Match patterns from ReconVoy example
6. **Reference documentation** - Use SOP docs and ReconVoy example

## Reference Examples

**Best Practice Reference**: `config/sop/reconvoy/sop_matcher/`
- Complete structure with all sections
- Full metadata for all steps
- Rich scenario examples
- Comprehensive troubleshooting
- Domain-specific glossary

Begin by reading the workflow documentation and then start Step 1: Requirements Gathering.
```

## Step 3: Register as Independent Agent

**File**: `config/pipelines.yml`

Add to the `independent_agents` section:

```yaml
# =============================================================================
# INDEPENDENT AGENTS SECTION
# =============================================================================
independent_agents:
  - id: sop_creation_agent
    config_file: "agents/sop_creation_agent.yml"
  
  # ... other independent agents
```

## Step 4: Create UI Manifest Entry (Optional)

**File**: `config/ui_manifests/independent_agents.yml`

```yaml
independent_agents:
  - id: sop_creation_agent
    name: "SOP Creation Agent"
    description: "Specialized agent for creating Standard Operating Procedures (SOPs) for other agents"
    icon: "sop_creation_agent.svg"  # Optional icon
    category: "development"
    tags:
      - "sop"
      - "documentation"
      - "workflow"
```

## Step 5: Using the Sub-Agent

### Via Assistant

The assistant can route requests to the SOP creation agent:

```
User: "Create an SOP for the research_analyst agent in the article_smith pipeline"
Assistant: Routes to sop_creation_agent
```

### Via Direct Invocation

You can also invoke the agent directly:

```python
# In your code
from topaz_agent_kit.core.agent_runner import AgentRunner
from topaz_agent_kit.core.configuration_engine import ConfigurationEngine

# Load configuration
config_engine = ConfigurationEngine(project_dir="path/to/project")
config_result = config_engine.load_configuration()

# Create agent runner
agent_runner = AgentRunner(config_result=config_result)

# Invoke the SOP creation agent
result = await agent_runner.execute_agent(
    agent_id="sop_creation_agent",
    inputs={
        "user_request": "Create an SOP for research_analyst agent",
        "project_dir": "path/to/project"
    }
)
```

### Via CLI

```bash
# Start the CLI
topaz-agent-kit serve cli --project path/to/project

# In the CLI, you can invoke:
> execute_agent sop_creation_agent
> user_request: "Create an SOP for research_analyst agent"
```

## Alternative: Create as Pipeline Node

Instead of an independent agent, you can also create the SOP creation agent as a node in a pipeline:

**File**: `config/pipelines/sop_creation_pipeline.yml`

```yaml
id: sop_creation_pipeline
name: SOP Creation Pipeline
description: "Pipeline for creating SOPs for agents"

nodes:
  - id: sop_creation_agent
    config_file: "agents/sop_creation_agent.yml"
    protocol: IN-PROC

pattern:
  type: sequential
  steps:
    - node: sop_creation_agent
```

Then register it in `config/pipelines.yml`:

```yaml
pipelines:
  - id: sop_creation_pipeline
    config_file: "pipelines/sop_creation_pipeline.yml"
```

## Testing the Sub-Agent

### Test via CLI

```bash
# Start CLI
topaz-agent-kit serve cli --project path/to/project

# Invoke the agent
> execute_agent sop_creation_agent
> user_request: "Create a minimal SOP for hello_agent in basic pipeline"
```

### Test via UI

```bash
# Start UI
topaz-agent-kit serve fastapi --project path/to/project

# Navigate to agents section and invoke sop_creation_agent
```

## Example: Complete Agent Configuration

Here's a complete example of an SOP creation agent configuration:

**File**: `config/agents/sop_creation_agent.yml`

```yaml
id: sop_creation_agent
name: SOP Creation Agent
description: "Specialized agent for creating Standard Operating Procedures (SOPs) for other agents"

type: agno
model: gpt-4o

prompt:
  instruction: "config/prompts/sop_creation_agent.jinja"
  inputs:
    - name: user_request
      description: "User's request to create an SOP"
    - name: project_dir
      description: "Project directory path"
      default: "{{project_dir}}"
    - name: pipeline_id
      description: "Pipeline ID where the agent belongs (optional, can be extracted from request)"
    - name: agent_id
      description: "Agent ID that needs the SOP (optional, can be extracted from request)"

mcp:
  servers: []

max_turns: 50
temperature: 0.7

memory:
  enabled: false
```

## Summary

To create a sub-agent that uses the SOP creation skill:

1. ✅ Create agent config: `config/agents/sop_creation_agent.yml`
2. ✅ Create agent prompt: `config/prompts/sop_creation_agent.jinja`
3. ✅ Register in `config/pipelines.yml` as independent agent
4. ✅ (Optional) Create UI manifest entry
5. ✅ Test the agent via CLI or UI

The agent will follow the SOP creation workflow defined in `.cursor/skills/sop-creation/SKILL.md` and create all necessary SOP files for the target agent.
