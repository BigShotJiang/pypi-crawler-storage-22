# Step 1: Requirements Gathering

This step collects ALL information needed before designing the SOP structure. Ask questions systematically before proceeding to design.

## Important Notes

- **Step 1 = COLLECT**: You are gathering information from the user
- **Step 2 = USE**: You will use the collected information to design the SOP structure
- If user doesn't know an answer, provide suggestions based on agent analysis
- If user gives partial information, ask follow-up questions
- If user provides conflicting information, ask for clarification

---

## Information to Collect

### 1. Basic Information

**Ask:**
- **Pipeline ID**: Which pipeline does the agent belong to?
  - Example: `reconvoy`, `article_smith`, `math_demo`
  - Validate: Must be valid pipeline ID from project

- **Agent ID**: Which agent needs the SOP?
  - Example: `sop_matcher`, `research_analyst`, `calculator`
  - Validate: Must be valid agent ID in the pipeline

- **Project Directory**: Where is the project located?
  - Default: Current working directory
  - Validate: Must exist and contain `config/` directory

### 2. Agent Context

**Ask:**
- **Agent Role**: What is the agent's primary role?
  - Example: "Matches reconciliation items", "Researches market data", "Solves math problems"
  - Purpose: Helps write overview.md

- **Agent Purpose**: What does this agent accomplish?
  - Example: "Identifies matching entries between UK and foreign books"
  - Purpose: Helps write overview.md

- **Current Workflow**: How does the agent currently work?
  - List the steps the agent follows
  - Purpose: Identifies procedure steps to document

### 3. Workflow Steps

**Ask systematically:**
- **How many steps** does the agent workflow have?
- **For each step**, ask:
  - Step name/description
  - What tools are used?
  - What inputs are needed?
  - What outputs are produced?
  - What are the dependencies (which steps must complete first)?
  - Are there conditional branches (if/then scenarios)?

**Example:**
```
Step 1: Identify foreign book
  - Tools: reconvoy.identify_foreign_book
  - Inputs: item.currency
  - Outputs: foreign_book_type
  - Dependencies: None
  - Conditionals: If GBP → check both books

Step 2: Find match
  - Tools: reconvoy.find_foreign_book_match
  - Inputs: currency, reference_description, amount
  - Outputs: matched_entry, document_number
  - Dependencies: Step 1
  - Conditionals: If match found → continue, else → return early
```

### 4. Tools and Capabilities

**Ask:**
- **SOP Tools**: Does agent need SOP toolkit?
  - Default: Yes (if creating SOP, agent should use it)
  - Tools: `sop_initialize`, `sop_get_section`, `sop_get_example`, `sop_get_troubleshooting`, `sop_get_glossary_term`

- **Business Tools**: What business tools does the agent use?
  - List all MCP tools, local tools, or framework tools
  - Example: `reconvoy.find_foreign_book_match`, `web_search.search`, `calculator.solve`

### 5. Output Format

**Ask:**
- **What does the agent return?**
  - JSON structure?
  - Specific fields?
  - Example output?

**Example:**
```json
{
  "matched_entry": {...},
  "document_number": "150000881",
  "match_status": "two_way_match"
}
```

### 6. Scenarios and Examples

**Ask:**
- **What scenarios** should be documented?
  - Common use cases
  - Edge cases
  - Complex patterns

**Example scenarios:**
- Two-way match (simple case)
- Three-way match (complex case)
- No match found (edge case)

### 7. Troubleshooting Needs

**Ask:**
- **What errors** does the agent commonly encounter?
- **What issues** need resolution guidance?
- **What edge cases** need special handling?

**Example issues:**
- No match found
- Item already processing
- Reference mismatch
- Wrong foreign book selected

### 8. Domain Terms

**Ask:**
- **What domain-specific terms** need definition?
  - Business terminology
  - Technical terms
  - Acronyms

**Example terms:**
- GBP items
- Foreign book
- BlackLine item
- Two-way match

### 9. SOP Complexity Level

**Ask:**
- **What complexity level** should the SOP have?

**Options:**
- **Minimal**: Just `manifest.yml` (bare minimum)
- **Recommended**: `manifest.yml` + `overview.md` (actually useful)
- **Comprehensive**: Full structure with steps, scenarios, troubleshooting, glossary (best practice)

**Default**: Recommended (unless user specifies otherwise)

---

## Requirements Summary Template

After collecting all information, present this summary:

```
SOP Requirements Summary
═══════════════════════════════════════════════════════════
Pipeline ID:          {pipeline_id}
Agent ID:             {agent_id}
Project Directory:    {project_dir}
───────────────────────────────────────────────────────────
Agent Role:           {agent_role}
Agent Purpose:       {agent_purpose}
───────────────────────────────────────────────────────────
Workflow Steps:       {number} steps
  - Step 1: {step1_name}
  - Step 2: {step2_name}
  ...
───────────────────────────────────────────────────────────
Tools:
  - SOP Tools: {sop_tools}
  - Business Tools: {business_tools}
───────────────────────────────────────────────────────────
Output Format:       {output_format}
───────────────────────────────────────────────────────────
Scenarios:            {number} scenarios
  - {scenario1}
  - {scenario2}
───────────────────────────────────────────────────────────
Troubleshooting:      {number} issues
  - {issue1}
  - {issue2}
───────────────────────────────────────────────────────────
Domain Terms:         {number} terms
  - {term1}
  - {term2}
───────────────────────────────────────────────────────────
SOP Complexity:       {minimal|recommended|comprehensive}
═══════════════════════════════════════════════════════════
```

**🔍 CHECKPOINT 1**: Present this summary and wait for user approval before proceeding to Step 2.

---

## Validation Rules

Before proceeding, validate:

- [ ] Pipeline ID exists in project
- [ ] Agent ID exists in pipeline
- [ ] Project directory exists
- [ ] At least one workflow step identified
- [ ] Tools are listed
- [ ] Output format is defined
- [ ] Complexity level is selected

If any validation fails, ask user to provide missing information.
