# Step 2: SOP Structure Design

This step designs the complete SOP structure based on requirements gathered in Step 1.

## Important Notes

- **Step 2 = DESIGN**: You are creating the structure, not generating files yet
- Use requirements from Step 1 to design the structure
- Present the design for approval before generating files
- Reference SOP documentation for best practices

---

## Design Process

### 1. Determine SOP Structure

Based on complexity level from Step 1:

**Minimal Structure:**
```
config/sop/{pipeline}/{agent}/
└── manifest.yml
```

**Recommended Structure:**
```
config/sop/{pipeline}/{agent}/
├── manifest.yml
└── overview.md
```

**Comprehensive Structure:**
```
config/sop/{pipeline}/{agent}/
├── manifest.yml
├── overview.md
├── steps/
│   ├── step_01_{name}.md
│   ├── step_02_{name}.md
│   └── step_NN_{name}.md
├── scenarios/
│   ├── scenario_{name1}.md
│   └── scenario_{name2}.md
└── troubleshooting.md

config/sop/{pipeline}/
└── glossary.md  (pipeline-level, shared)
```

### 2. Design manifest.yml Structure

**Required fields:**
- `sop_id`: Agent ID
- `version`: "1.0.0"
- `description`: Brief description of SOP purpose

**Sections structure:**

For **Minimal**:
```yaml
sections: []
```

For **Recommended**:
```yaml
sections:
  - id: overview
    file: overview.md
    type: reference
    description: "Overview of the agent's role and workflow"
    read_at: start
```

For **Comprehensive**:
```yaml
sections:
  # =============================================================================
  # OVERVIEW
  # =============================================================================
  - id: overview
    file: overview.md
    type: reference
    description: "High-level workflow and your role"
    read_at: start

  # =============================================================================
  # PROCEDURAL STEPS
  # =============================================================================
  - id: step_01_{name}
    file: steps/step_01_{name}.md
    type: procedure
    description: "{step description}"
    read_at: on_demand
    depends_on: []
    outputs:
      - {output1}
      - {output2}
    tools_used:
      - {tool1}
      - {tool2}

  - id: step_02_{name}
    file: steps/step_02_{name}.md
    type: procedure
    description: "{step description}"
    read_at: on_demand
    depends_on:
      - step_01_{name}
    outputs:
      - {output}
    tools_used:
      - {tool}

  # =============================================================================
  # SCENARIOS / EXAMPLES
  # =============================================================================
  - id: scenario_{name}
    file: scenarios/scenario_{name}.md
    type: example
    description: "{scenario description}"
    read_at: on_demand

  # =============================================================================
  # TROUBLESHOOTING
  # =============================================================================
  - id: troubleshooting
    file: troubleshooting.md
    type: troubleshooting
    description: "Common issues and solutions"
    read_at: on_demand
```

### 3. Plan overview.md Content

**Structure:**
```markdown
# {Agent Name} - Overview

## Your Role

{Agent role description from requirements}

## Simple Workflow

{Visual or text representation of workflow}

## Key Rules

- **Rule 1**: {Important rule}
- **Rule 2**: {Important rule}

## Tools You Have

**SOP Tools** (read instructions):
- `sop_initialize` - Load SOP
- `sop_get_section` - Read a step
- `sop_get_example` - See examples
- `sop_get_troubleshooting` - Get error help
- `sop_get_glossary_term` - Look up terms

**Business Tools** (do work):
- `{tool1}` - {What it does}
- `{tool2}` - {What it does}

## Output Format

Return JSON with these fields:
- `{field1}` - {Description}
- `{field2}` - {Description}
```

### 4. Design Step Files

For each workflow step from requirements:

**Step file structure:**
```markdown
# Step N: {Step Name}

## What You Do

{Clear description of the step's purpose}

## Steps

1. {Action 1 with exact tool call}
2. **If condition:**
   - {Action}
   - {Action}
3. **If other condition:**
   - {Action}

## Why This Matters

{Explanation of why this step is important}

## Save This for Next Step

{What data to accumulate for next step}

## Document in Execution Trace

For this step, record:
- **Input**: {What inputs are used}
- **Tool calls**: {What tools are called}
- **Output**: {What outputs are produced}
- **Decision**: {What decision was made}

## Next

→ Go to Step N+1
```

**Manifest entry:**
```yaml
- id: step_NN_{name}
  file: steps/step_NN_{name}.md
  type: procedure
  description: "{step description}"
  read_at: on_demand
  depends_on: [{previous_steps}]
  outputs:
    - {output1}
    - {output2}
  tools_used:
    - {tool1}
    - {tool2}
```

### 5. Plan Scenario Examples

For each scenario from requirements:

**Scenario file structure:**
```markdown
# Scenario: {Scenario Name}

## Description

{What this scenario represents}

## Pattern

{Visual or text representation of the pattern}

## Example: {Specific Example Name}

### Initial State

**Input Data:**
| Field | Value |
|-------|-------|
| {field1} | {value1} |

### Process

1. **Step 1**: {What happens}
2. **Step 2**: {What happens}

### Expected Output

```json
{
  "{field1}": "{value1}",
  "{field2}": "{value2}"
}
```

## Key Points

1. {Key point 1}
2. {Key point 2}
```

**Manifest entry:**
```yaml
- id: scenario_{name}
  file: scenarios/scenario_{name}.md
  type: example
  description: "{scenario description}"
  read_at: on_demand
```

### 6. Design Troubleshooting Guide

For each issue from requirements:

**Troubleshooting structure:**
```markdown
# Troubleshooting Guide

## Common Issues and Solutions

### {Issue Name}

**Symptom**: {What the agent will see}

**Possible Causes:**

1. **Cause 1**
   - {Explanation}
   - {How to check}

2. **Cause 2**
   - {Explanation}
   - {How to check}

**Action**: {What the agent should do}

---

### {Another Issue}

...
```

**Manifest entry:**
```yaml
- id: troubleshooting
  file: troubleshooting.md
  type: troubleshooting
  description: "Common issues and solutions"
  read_at: on_demand
```

### 7. Plan Glossary Terms

For each domain term from requirements:

**Glossary structure:**
```markdown
# {Pipeline} Glossary

This glossary defines key terms used in the {pipeline} pipeline.

---

## {Term 1}

**Definition**: {Clear definition}

**Role**: {What role it plays in the workflow}

**Key Rules**:
- **Rule 1**: {Important rule}
- **Rule 2**: {Important rule}

**Example**: {Concrete example}

---

## {Term 2}

...
```

**Note**: Glossary is pipeline-level, not agent-level. Place at `config/sop/{pipeline}/glossary.md`

### 8. Plan Agent Configuration Updates

**Agent config updates needed:**
```yaml
# config/agents/{agent_id}.yml
id: {agent_id}
sop: "config/sop/{pipeline}/{agent}/manifest.yml"

mcp:
  servers:
    - url: "http://localhost:8050/mcp"
      toolkits: ["sop"]
      tools: ["sop_initialize", "sop_get_section", "sop_get_example", "sop_get_troubleshooting", "sop_get_glossary_term"]

max_turns: 30  # Increase if SOP has many steps
```

### 9. Plan Agent Prompt Updates

**Agent prompt updates needed:**
```jinja
You are a {Agent Name} (SOP-Driven) responsible for {task}.

Tasks:
1. **Initialize SOP**: Call `sop_initialize` with `project_dir` and `sop_path` from inputs.
2. **Read SOP Overview**: Call `sop_get_section(section_id="overview")`.
3. **Follow SOP Steps in Order**:
   - **Step 1**: Call `sop_get_section(section_id="step_01_...")`, then execute.
   - **Step 2**: Call `sop_get_section(section_id="step_02_...")`, then execute.
4. **If Stuck**: Use `sop_get_example(scenario_name="...")` or `sop_get_troubleshooting(issue="...")`.
5. **If Uncertain About Terms**: Use `sop_get_glossary_term(term_id="<term>")`.
```

---

## Structure Proposal Template

Present this proposal to the user:

```
SOP Structure Proposal
═══════════════════════════════════════════════════════════
Location:              config/sop/{pipeline}/{agent}/
Complexity Level:      {minimal|recommended|comprehensive}
───────────────────────────────────────────────────────────
Files to Create:
  ✅ manifest.yml
  {✅ overview.md}  (if recommended/comprehensive)
  {✅ steps/step_XX_*.md}  (if comprehensive)
  {✅ scenarios/scenario_*.md}  (if comprehensive)
  {✅ troubleshooting.md}  (if comprehensive)
  {✅ ../glossary.md}  (if comprehensive)
───────────────────────────────────────────────────────────
Manifest Sections:     {number} sections
  - overview (reference, read_at: start)
  {  - step_01_... (procedure)}
  {  - step_02_... (procedure)}
  {  - scenario_... (example)}
  {  - troubleshooting (troubleshooting)}
───────────────────────────────────────────────────────────
Agent Config Updates:
  ✅ Add sop: "config/sop/{pipeline}/{agent}/manifest.yml"
  ✅ Add MCP toolkit: ["sop"]
  ✅ Add SOP tools: [sop_initialize, sop_get_section, ...]
  ✅ Increase max_turns: 30
───────────────────────────────────────────────────────────
Agent Prompt Updates:
  ✅ Add SOP initialization instructions
  ✅ Add step-by-step workflow instructions
  ✅ Add troubleshooting guidance
═══════════════════════════════════════════════════════════
```

**🔍 CHECKPOINT 2**: Present this proposal and wait for user approval before proceeding to Step 3.

---

## Validation Rules

Before proceeding, validate:

- [ ] Structure matches complexity level
- [ ] All required sections are planned
- [ ] Step dependencies are correct
- [ ] All tools are listed in tools_used
- [ ] All outputs are documented
- [ ] Agent config updates are planned
- [ ] Agent prompt updates are planned

If user requests changes, update the proposal and re-present.
