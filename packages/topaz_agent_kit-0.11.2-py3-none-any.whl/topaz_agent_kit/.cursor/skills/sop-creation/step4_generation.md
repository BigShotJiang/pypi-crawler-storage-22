# Step 4: File Generation

This step generates all SOP files based on the finalized structure from Step 3.

## Important Notes

- **Step 4 = GENERATE**: You are creating actual files
- Generate files in the specified order
- Use templates and examples from SOP documentation
- Reference ReconVoy example for best practices
- Validate as you generate

---

## Generation Order

Generate files in this exact order:

1. **Create directory structure**
2. **Generate manifest.yml**
3. **Generate overview.md** (if recommended/comprehensive)
4. **Generate step files** (if comprehensive)
5. **Generate scenario files** (if comprehensive)
6. **Generate troubleshooting.md** (if comprehensive)
7. **Generate glossary.md** (if comprehensive, pipeline-level)
8. **Update agent config**
9. **Update agent prompt**

---

## 1. Create Directory Structure

**Create directories:**
```bash
config/sop/{pipeline}/{agent}/
config/sop/{pipeline}/{agent}/steps/  (if comprehensive)
config/sop/{pipeline}/{agent}/scenarios/  (if comprehensive)
config/sop/{pipeline}/  (for glossary if comprehensive)
```

---

## 2. Generate manifest.yml

**Template:**
```yaml
sop_id: {agent_id}
version: "1.0.0"
description: "{SOP description}"

sections:
  # =============================================================================
  # OVERVIEW
  # =============================================================================
  - id: overview
    file: overview.md
    type: reference
    description: "High-level workflow and your role"
    read_at: start

  # =============================================================================
  # PROCEDURAL STEPS
  # =============================================================================
  {# Add procedure steps if comprehensive #}

  # =============================================================================
  # SCENARIOS / EXAMPLES
  # =============================================================================
  {# Add scenarios if comprehensive #}

  # =============================================================================
  # TROUBLESHOOTING
  # =============================================================================
  {# Add troubleshooting if comprehensive #}
```

**For minimal**: Only `sop_id`, `version`, `description`, empty `sections: []`

**For recommended**: Add overview section

**For comprehensive**: Add all sections with full metadata

---

## 3. Generate overview.md

**Template:**
```markdown
# {Agent Name} - Overview

## Your Role

{Agent role description}

## Simple Workflow

{Visual or text workflow representation}

## Key Rules

- **Rule 1**: {Important rule}
- **Rule 2**: {Important rule}

## Tools You Have

**SOP Tools** (read instructions):
- `sop_initialize` - Load SOP
- `sop_get_section` - Read a step
- `sop_get_example` - See examples
- `sop_get_troubleshooting` - Get error help
- `sop_get_glossary_term` - Look up terms

**Business Tools** (do work):
{List all business tools with descriptions}

## Output Format

Return JSON with these fields:
{List all output fields with descriptions}
```

**Reference**: [reference_sop_creation_guide.md](reference_sop_creation_guide.md) for detailed examples

---

## 4. Generate Step Files

**For each step, create file:** `steps/step_NN_{name}.md`

**Template:**
```markdown
# Step N: {Step Name}

## What You Do

{Clear description of the step's purpose}

## Steps

1. {Action 1 with exact tool call}
   ```
   {tool_name}({parameters})
   ```

2. **If condition:**
   - {Action}
   - {Action}

3. **If other condition:**
   - {Action}

## Why This Matters

{Explanation of why this step is important}

## Save This for Next Step

{What data to accumulate for next step}

## Document in Execution Trace

For this step, record:
- **Input**: {What inputs are used}
- **Tool calls**: {What tools are called}
- **Output**: {What outputs are produced}
- **Decision**: {What decision was made}

## Next

→ Go to Step N+1
```

**Reference**: ReconVoy example at `config/sop/reconvoy/sop_matcher/steps/` for best practices

---

## 5. Generate Scenario Files

**For each scenario, create file:** `scenarios/scenario_{name}.md`

**Template:**
```markdown
# Scenario: {Scenario Name}

## Description

{What this scenario represents}

## Pattern

{Visual or text representation of the pattern}

## Example: {Specific Example Name}

### Initial State

**Input Data:**
| Field | Value |
|-------|-------|
| {field1} | {value1} |

### Process

1. **Step 1**: {What happens}
2. **Step 2**: {What happens}

### Expected Output

```json
{
  "{field1}": "{value1}",
  "{field2}": "{value2}"
}
```

## Key Points

1. {Key point 1}
2. {Key point 2}
```

**Reference**: ReconVoy example at `config/sop/reconvoy/sop_matcher/scenarios/` for best practices

---

## 6. Generate troubleshooting.md

**Template:**
```markdown
# Troubleshooting Guide

## Common Issues and Solutions

### {Issue Name}

**Symptom**: {What the agent will see}

**Possible Causes:**

1. **Cause 1**
   - {Explanation}
   - {How to check}

2. **Cause 2**
   - {Explanation}
   - {How to check}

**Action**: {What the agent should do}

---

### {Another Issue}

...
```

**Reference**: ReconVoy example at `config/sop/reconvoy/sop_matcher/troubleshooting.md` for best practices

---

## 7. Generate glossary.md (Pipeline-Level)

**Location**: `config/sop/{pipeline}/glossary.md` (not in agent directory)

**Template:**
```markdown
# {Pipeline} Glossary

This glossary defines key terms used in the {pipeline} pipeline.

---

## {Term 1}

**Definition**: {Clear definition}

**Role**: {What role it plays in the workflow}

**Key Rules**:
- **Rule 1**: {Important rule}
- **Rule 2**: {Important rule}

**Example**: {Concrete example}

---

## {Term 2}

...
```

**Reference**: ReconVoy example at `config/sop/reconvoy/glossary.md` for best practices

---

## 8. Update Agent Config

**File**: `config/agents/{agent_id}.yml`

**Add/Update:**
```yaml
id: {agent_id}
sop: "config/sop/{pipeline}/{agent}/manifest.yml"

mcp:
  servers:
    - url: "http://localhost:8050/mcp"
      toolkits: ["sop"]
      tools: ["sop_initialize", "sop_get_section", "sop_get_example", "sop_get_troubleshooting", "sop_get_glossary_term"]

max_turns: 30  # Increase if SOP has many steps
```

**Note**: If `mcp` section already exists, merge the SOP toolkit and tools into existing configuration.

---

## 9. Update Agent Prompt

**File**: `config/prompts/{agent_id}.jinja`

**Add at the beginning:**
```jinja
You are a {Agent Name} (SOP-Driven) responsible for {task}.

## SOP-Driven Workflow

This agent follows a Standard Operating Procedure (SOP) for consistent, reliable execution.

### Initialization

1. **Initialize SOP**: Call `sop_initialize` with:
   - `project_dir`: "{{project_dir}}"
   - `sop_path`: "config/sop/{pipeline}/{agent}/manifest.yml"

2. **Read Overview**: Call `sop_get_section(section_id="overview")` to understand your role and workflow.

### Execution

3. **Follow SOP Steps in Order**:
   - Before each step, call `sop_get_section(section_id="step_XX_...")` to read the step instructions
   - Execute the step exactly as documented
   - Document your execution in the execution trace

4. **Use Examples When Needed**: If you encounter a pattern, call `sop_get_example(scenario_name="...")` to see how similar cases were handled.

5. **Handle Errors**: If you encounter an error, call `sop_get_troubleshooting(issue="...")` for guidance.

6. **Look Up Terms**: If you're uncertain about a domain term, call `sop_get_glossary_term(term_id="<term>")` for definition.

### Important Rules

- **Always read the step before executing it** - Don't skip `sop_get_section` calls
- **Follow steps in order** - Don't jump ahead
- **Document your execution** - Record inputs, tool calls, outputs, and decisions
- **Use troubleshooting when stuck** - Don't guess, use the SOP tools

{Continue with existing prompt content...}
```

---

## Generation Checklist

As you generate each file, verify:

- [ ] Directory structure created
- [ ] manifest.yml generated with correct structure
- [ ] overview.md generated (if needed)
- [ ] All step files generated (if comprehensive)
- [ ] All scenario files generated (if comprehensive)
- [ ] troubleshooting.md generated (if comprehensive)
- [ ] glossary.md generated at pipeline level (if comprehensive)
- [ ] Agent config updated with SOP path and MCP toolkit
- [ ] Agent prompt updated with SOP instructions
- [ ] All file paths are correct
- [ ] All section IDs match file names

---

## After Generation

**🔍 CHECKPOINT 4**: Present generated files summary and ask if any changes are needed.

**Summary template:**
```
Files Generated
═══════════════════════════════════════════════════════════
✅ Directory structure created
✅ manifest.yml
{✅ overview.md}
{✅ steps/step_XX_*.md (N files)}
{✅ scenarios/scenario_*.md (N files)}
{✅ troubleshooting.md}
{✅ ../glossary.md}
✅ Agent config updated: config/agents/{agent_id}.yml
✅ Agent prompt updated: config/prompts/{agent_id}.jinja
═══════════════════════════════════════════════════════════
```

If user requests changes, make them before proceeding to Step 5.
