# Step 5: Validation & Summary

This step validates all generated files and provides a completion summary.

## Important Notes

- **Step 5 = VALIDATE**: You are checking that everything is correct
- Validate all files exist and are correct
- Check all references are valid
- Provide testing instructions
- Get final confirmation

---

## Validation Checklist

### 1. File Existence

**Check:**
- [ ] Directory structure exists
- [ ] manifest.yml exists
- [ ] overview.md exists (if recommended/comprehensive)
- [ ] All step files exist (if comprehensive)
- [ ] All scenario files exist (if comprehensive)
- [ ] troubleshooting.md exists (if comprehensive)
- [ ] glossary.md exists at pipeline level (if comprehensive)

### 2. manifest.yml Validation

**Check:**
- [ ] `sop_id` matches agent ID
- [ ] `version` is set
- [ ] `description` is present
- [ ] All sections are listed
- [ ] All section `file` paths are correct
- [ ] All section `id` values are unique
- [ ] All section `type` values are valid (reference/procedure/example/troubleshooting)
- [ ] All `read_at` values are valid (start/on_demand)
- [ ] All `depends_on` references valid section IDs
- [ ] All `outputs` are documented
- [ ] All `tools_used` are listed

### 3. File Content Validation

**Check:**
- [ ] overview.md has required sections (Your Role, Workflow, Tools, Output Format)
- [ ] Step files have required sections (What You Do, Steps, Next)
- [ ] Scenario files have required sections (Description, Example, Key Points)
- [ ] troubleshooting.md has issue/solution format
- [ ] glossary.md has term definitions

### 4. Reference Validation

**Check:**
- [ ] All section `file` paths in manifest.yml point to existing files
- [ ] All `depends_on` section IDs exist in manifest
- [ ] No broken file references
- [ ] All scenario names referenced in examples exist
- [ ] All glossary terms referenced exist

### 5. Agent Configuration Validation

**Check:**
- [ ] Agent config has `sop` field pointing to correct path
- [ ] Agent config has `mcp.servers` with SOP toolkit
- [ ] Agent config has all required SOP tools listed
- [ ] `max_turns` is increased if SOP has many steps
- [ ] Agent config file path is correct

### 6. Agent Prompt Validation

**Check:**
- [ ] Agent prompt includes SOP initialization instructions
- [ ] Agent prompt includes step-by-step workflow instructions
- [ ] Agent prompt includes troubleshooting guidance
- [ ] Agent prompt references correct section IDs
- [ ] Agent prompt file path is correct

---

## Validation Errors

**If validation fails:**

1. **Missing file**: Create the file
2. **Invalid reference**: Fix the reference
3. **Broken path**: Correct the path
4. **Missing section**: Add the section
5. **Invalid ID**: Fix the ID

**After fixing errors, re-validate before proceeding.**

---

## Completion Summary

**Generate summary:**

```
SOP Creation Complete
═══════════════════════════════════════════════════════════
Pipeline ID:          {pipeline_id}
Agent ID:             {agent_id}
SOP Location:         config/sop/{pipeline}/{agent}/
Complexity Level:     {minimal|recommended|comprehensive}
───────────────────────────────────────────────────────────
Files Created:
  ✅ manifest.yml
  {✅ overview.md}
  {✅ steps/ (N files)}
  {✅ scenarios/ (N files)}
  {✅ troubleshooting.md}
  {✅ ../glossary.md}
───────────────────────────────────────────────────────────
Agent Configuration:
  ✅ config/agents/{agent_id}.yml - Updated with SOP path and MCP toolkit
  ✅ config/prompts/{agent_id}.jinja - Updated with SOP instructions
───────────────────────────────────────────────────────────
Validation:
  ✅ All files exist
  ✅ All references valid
  ✅ Agent config updated
  ✅ Agent prompt updated
═══════════════════════════════════════════════════════════
```

---

## Testing Instructions

**Provide testing instructions:**

```bash
# Test the agent with SOP
topaz-agent-kit serve cli --project {project_dir}

# Or test via UI
topaz-agent-kit serve fastapi --project {project_dir}

# In the CLI/UI, test the agent:
# 1. The agent should call sop_initialize at start
# 2. The agent should read the overview
# 3. The agent should follow steps in order
# 4. The agent should use SOP tools appropriately
```

---

## Reference Documentation

**Point user to:**
- **SOP Creation Guide**: [reference_sop_creation_guide.md](reference_sop_creation_guide.md)
- **Minimal SOP Structure**: [reference_minimal_structure.md](reference_minimal_structure.md)
- **SOP Quick Reference**: [reference_quick_reference.md](reference_quick_reference.md)
- **ReconVoy Example**: `config/sop/reconvoy/sop_matcher/` (best practice reference - in project directory)

---

## Final Confirmation

**🔍 CHECKPOINT 5**: Present summary and get final confirmation.

**Ask:**
- "SOP creation is complete. Would you like to test it now, or do you have any questions?"

**If user has questions or wants changes:**
- Address questions
- Make requested changes
- Re-validate
- Present updated summary

**If user confirms completion:**
- Mark workflow as complete
- Provide next steps (testing, usage, etc.)

---

## Completion Checklist

Before marking complete, verify:

- [ ] All validation checks passed
- [ ] Summary generated
- [ ] Testing instructions provided
- [ ] Reference documentation linked
- [ ] User has confirmed completion or requested changes
- [ ] All requested changes made (if any)
