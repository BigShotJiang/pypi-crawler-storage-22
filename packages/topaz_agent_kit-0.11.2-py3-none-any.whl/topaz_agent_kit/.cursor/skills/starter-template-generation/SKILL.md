---
name: starter-template-generation
description: Creates new Topaz Agent Kit starter templates by copying pipelines from existing starters and generating required configuration files. Use when the user wants to create a new starter template, copy pipelines to a new starter, or says "create starter template", "new starter", "starter template generation", or "follow the starter template generation workflow".
---

# Starter Template Generation

Execute this workflow systematically when creating a new starter template.

## Base Path

All starter templates are created in:
`src/topaz_agent_kit/templates/starters/{template_name}/`

## Quick Reference: Files to Copy/Generate

| # | Type | Source | Destination |
|---|------|--------|-------------|
| 1 | Pipeline configs | `{source}/config/pipelines/{pipeline_id}.yml` | `{template}/config/pipelines/` |
| 2 | UI manifests | `{source}/config/ui_manifests/{pipeline_id}.yml` | `{template}/config/ui_manifests/` |
| 3 | Agent configs | `{source}/config/agents/{agent_id}.yml` | `{template}/config/agents/` |
| 4 | Prompt templates | `{source}/config/prompts/{agent_id}.jinja` | `{template}/config/prompts/` |
| 5 | HITL templates | `{source}/config/hitl/{gate_id}.jinja` | `{template}/config/hitl/` |
| 6 | Pipeline icons | `{source}/ui/static/assets/{pipeline_id}.svg` | `{template}/ui/static/assets/` |
| 7 | Agent icons | `{source}/ui/static/assets/{agent_id}.svg` | `{template}/ui/static/assets/` |
| 8 | Global pipelines.yml | **GENERATE** | `{template}/config/pipelines.yml` |
| 9 | Global ui_manifest.yml | **GENERATE** | `{template}/config/ui_manifest.yml` |
| 10 | Assistant classifier | **GENERATE** | `{template}/config/prompts/assistant_intent_classifier.jinja` |
| 11 | Operations assistant | Copy from source | `{template}/config/prompts/operations_assistant.jinja` |

**Optional (if requested):**
- Independent agents configs
- Tools directory
- Memory templates
- Requisites directory

## Workflow Steps

Execute these steps IN ORDER. Do not skip steps. Pause at checkpoints (🔍).

### Step 1: Requirements Gathering

**Collect systematically:**

1. **Template name** (snake_case)
   - Example: "author", "content_creator", "finance_analyst"
   - Validate: Must be unique, snake_case format

2. **Source starter** (where to copy pipelines from)
   - Options: "ensemble", "pa", "icp", "basic"
   - Validate: Source starter must exist

3. **Pipelines to copy** (list of pipeline IDs)
   - Example: ["article_smith", "reply_wizard"]
   - Validate: All pipelines must exist in source starter
   - Validate: Check for agent ID conflicts across pipelines

4. **Copy independent agents?** (yes/no, default: no)
   - If yes: Ask which independent agents to copy

5. **Copy tools?** (yes/no, default: no)
   - If yes: Ask which tools to copy (or copy all)

**🔍 CHECKPOINT 1**: Present requirements summary. Wait for user approval before proceeding.

### Step 2: File Discovery & Validation

**For each pipeline to copy:**

1. **Discover pipeline files:**
   - Pipeline config: `config/pipelines/{pipeline_id}.yml`
   - UI manifest: `config/ui_manifests/{pipeline_id}.yml`
   - Read pipeline config to identify all agents

2. **Discover agent files:**
   - Agent configs: `config/agents/{agent_id}.yml` (from pipeline.nodes)
   - Prompt templates: `config/prompts/{agent_id}.jinja`
   - Agent icons: `ui/static/assets/{agent_id}.svg`

3. **Discover HITL files:**
   - HITL templates: `config/hitl/{gate_id}.jinja` (from pipeline.gates)

4. **Discover icons:**
   - Pipeline icon: `ui/static/assets/{pipeline_id}.svg`
   - Workflow diagram: `ui/static/assets/{pipeline_id}_workflow.svg` (if exists)

5. **Validate:**
   - All required files exist
   - No file conflicts in destination
   - Agent IDs don't conflict across pipelines

**🔍 CHECKPOINT 2**: Present file discovery summary. Show what will be copied. Wait for confirmation.

### Step 3: File Generation

**Create directory structure:**
```
{template_name}/
├── config/
│   ├── agents/
│   ├── pipelines/
│   ├── prompts/
│   ├── hitl/
│   └── ui_manifests/
└── ui/
    └── static/
        └── assets/
```

**Copy files in this order:**

1. **Pipeline configs** → `config/pipelines/{pipeline_id}.yml`
2. **UI manifests** → `config/ui_manifests/{pipeline_id}.yml`
3. **Agent configs** → `config/agents/{agent_id}.yml`
4. **Prompt templates** → `config/prompts/{agent_id}.jinja`
5. **HITL templates** → `config/hitl/{gate_id}.jinja`
6. **Icons** → `ui/static/assets/{pipeline_id}.svg` + `{agent_id}.svg`
7. **Operations assistant** → `config/prompts/operations_assistant.jinja` (copy from source)

**Generate files:**

8. **Global pipelines.yml** → `config/pipelines.yml`
   - Use template name and description
   - Add all copied pipelines to `pipelines` section (config_file is optional, defaults to `pipelines/{id}.yml`)
   - Add independent agents to `independent_agents` section if any (config_file is optional, defaults to `agents/{id}.yml`)
   - Include standard server, database, assistant, operations_assistant sections
   - Reference existing starters (pa, icp, ensemble) for structure

9. **Global ui_manifest.yml** → `config/ui_manifest.yml`
   - Use template name and description
   - Add all copied pipelines to `pipelines` section
   - Include standard brand, appearance, chat sections
   - Reference existing starters for structure

10. **Assistant intent classifier** → `config/prompts/assistant_intent_classifier.jinja`
    - Copy base structure from PA template (simpler than ensemble)
    - Add all copied pipelines with appropriate keywords
    - Generate keywords from pipeline names/descriptions
    - Format: `- \`{pipeline_id}\`: {description} **USE THIS when user mentions: {keywords}**`

**Optional (if requested):**

11. **Independent agents** → Copy agent configs and prompts
12. **Tools** → Copy entire tools directory structure
13. **Memory templates** → Copy memory directory
14. **Requisites** → Copy requisites directory

**🔍 CHECKPOINT 3**: Review generated files. Ask if any changes needed.

### Step 4: Validation & Summary

**Validate:**

1. All required files exist
2. All file paths are correct
3. pipelines.yml references all pipelines correctly
4. UI manifest references all pipelines correctly
5. Assistant intent classifier includes all pipelines
6. No missing dependencies (agents, prompts, icons)

**Generate summary:**

- Template name and location
- Pipelines included
- Files copied/generated
- Testing instructions

**🔍 CHECKPOINT 4**: Final review and completion confirmation.

## Critical Rules

### Naming Conventions

| Type | Format | Example |
|------|--------|---------|
| Template name | `snake_case` | `author`, `content_creator` |
| Pipeline ID | `snake_case` | `article_smith` |
| Agent ID | `{pipeline_id}_{role}` | `article_research_analyst` |

### File Paths

- All paths are relative to `src/topaz_agent_kit/templates/starters/{template_name}/`
- Source paths are relative to `src/topaz_agent_kit/templates/starters/{source_starter}/`

### Global Config Files

- **pipelines.yml**: Must include all copied pipelines in `pipelines` section
- **ui_manifest.yml**: Must include all copied pipelines in `pipelines` section
- Both should follow the same structure as existing starters (pa, icp, ensemble)

## State Tracking

Track progress through the workflow:

```
Starter Template Generation State
─────────────────────────────────
Template Name:      [ ]
Source Starter:     [ ]
Pipelines:          [ ]
Independent Agents: [ ]
Tools:              [ ]
─────────────────────────────────
Step 1 Complete:    [ ]
Step 2 Complete:    [ ]
Step 3 Complete:    [ ]
Step 4 Complete:    [ ]
─────────────────────────────────
Files Copied:       [ ]
Files Generated:    [ ]
Validation:         [ ]
```

## Testing Commands

```bash
# Create project from new starter
topaz-agent-kit init --starter {template_name} projects/{template_name}_test

# Test via CLI
topaz-agent-kit serve cli --project projects/{template_name}_test

# Test via UI
topaz-agent-kit serve fastapi --project projects/{template_name}_test
```

## Completion Checklist

Before marking workflow complete, verify:

- [ ] All pipeline files copied
- [ ] All agent files copied
- [ ] All prompt templates copied
- [ ] All HITL templates copied
- [ ] All icons copied
- [ ] Global pipelines.yml generated
- [ ] Global ui_manifest.yml generated
- [ ] Assistant intent classifier generated
- [ ] Operations assistant copied
- [ ] All file paths validated
- [ ] No missing dependencies
- [ ] User has received testing instructions
