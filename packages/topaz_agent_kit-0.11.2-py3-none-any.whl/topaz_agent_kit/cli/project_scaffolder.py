import argparse
import sys
import os
import time
from pathlib import Path
from typing import Dict  # noqa: F401
import textwrap
import shutil

# # Suppress NLTK SSL warnings that come from dependencies
# warnings.filterwarnings("ignore", message=".*SSL: CERTIFICATE_VERIFY_FAILED.*")
# warnings.filterwarnings("ignore", message=".*Error loading.*nltk_data.*")
# warnings.filterwarnings("ignore", message=".*nltk_data.*")

# # Set environment variable to suppress NLTK downloads
# import tempfile
# os.environ.setdefault("NLTK_DATA", str(Path(tempfile.gettempdir()) / "nltk_data"))
# os.environ.setdefault("NLTK_DOWNLOAD", "false")

from topaz_agent_kit.utils.logger import Logger
from topaz_agent_kit.cli.agent_generator import AgentGenerator
from topaz_agent_kit.cli.service_generator import ServiceGenerator


PIPELINE_YML = """name: "{title}"
description: "Generated pipeline from starter template"

nodes:
{nodes_block}

pattern:
  type: sequential
  steps:
{pattern_steps}
"""


class ProjectScaffolder:
    """
    Scaffolds new projects from starter templates.
    Provides extensible framework for creating new agent workflows.
    """

    def __init__(self):
        self.logger = Logger("ProjectScaffolder")

    def _indent(self, n: int, s: str) -> str:
        """Helper method to indent text by n spaces."""
        return " " * n + s

    def _slugify(self, name: str) -> str:
        """Convert name to URL-safe slug."""
        s = (name or "").strip().lower().replace(" ", "_")
        allowed = "abcdefghijklmnopqrstuvwxyz0123456789_"
        return "".join(ch for ch in s if ch in allowed) or "agent"

    def _copy_gmail_credentials(self, target_dir: Path) -> None:
        """Copy Gmail credentials (client_secret.json, credentials.json, gmail_token.json) to target project.
        
        Looks for credentials in multiple locations (in order):
        1. Current working directory (where user runs the command)
        2. Development project root (when running from source)
        3. Target project's parent directory
        
        Copies all found credential files (doesn't stop after first one).
        """
        try:
            import os
            from pathlib import Path
            
            # List of credential files to copy (in order of preference, but copy all found)
            credential_files = ["client_secret.json", "credentials.json", "gmail_token.json"]
            
            # Strategy 1: Check current working directory (where user runs the command)
            # This works for both installed package and development mode
            cwd = Path.cwd()
            
            # Strategy 2: Check development project root (fallback for dev mode)
            # Go up from src/topaz_agent_kit/cli/project_scaffolder.py -> src/topaz_agent_kit/cli/ -> src/topaz_agent_kit/ -> src/ -> project_root/
            dev_project_root = Path(__file__).parent.parent.parent.parent
            
            # Strategy 3: Check target project's parent directory
            target_parent = target_dir.parent
            
            # Try all locations
            search_locations = [
                ("current working directory", cwd),
                ("development project root", dev_project_root),
                ("target project parent", target_parent),
            ]
            
            copied_count = 0
            found_files = set()  # Track which files we've already copied to avoid duplicates
            
            for location_name, search_dir in search_locations:
                for cred_file in credential_files:
                    if cred_file in found_files:
                        continue  # Already copied this file
                    
                    source_file = search_dir / cred_file
                    if source_file.exists() and source_file.is_file():
                        target_file = target_dir / cred_file
                        if not target_file.exists() or self._should_overwrite(target_file):
                            shutil.copy2(source_file, target_file)
                            self.logger.success(
                                "Copied Gmail credentials ({}) from {} to project directory",
                                cred_file,
                                location_name
                            )
                            copied_count += 1
                            found_files.add(cred_file)
            
            if copied_count == 0:
                # No credentials found - this is optional, so just log debug
                self.logger.debug("Gmail credentials not found - email toolkit will search other locations")
            
        except Exception as e:
            self.logger.warning("Failed to copy Gmail credentials: {}", e)
    
    def _should_overwrite(self, file_path: Path) -> bool:
        """Check if file should be overwritten (always True for now, can be made configurable)."""
        return True

    def _write_files(
        self,
        root: Path,
        cfg: dict,
        *,
        overwrite: bool = False,
        generate_stubs: bool = False,
        generate_remote_services: bool = False,
    ) -> None:
        """Write scaffold files to the target directory."""
        # Only create the configuration scaffold; code will be generated via `generate`
        (root / "config").mkdir(parents=True, exist_ok=True)

        # .env
        if overwrite or not (root / ".env").exists():
            (root / ".env").write_text(
                textwrap.dedent(
                    """
            # Azure OpenAI Configuration
            AZURE_OPENAI_API_BASE=
            AZURE_OPENAI_API_KEY=
            AZURE_OPENAI_DEPLOYMENT=
            AZURE_OPENAI_MODEL=
            AZURE_OPENAI_API_VERSION=
            
            # Google AI Configuration
            GOOGLE_API_KEY=
            
            # Anthropic Configuration
            ANTHROPIC_API_KEY=
            
            # OpenAI Configuration
            OPENAI_API_KEY=
            
            # Ollama Configuration (if used)
            OLLAMA_BASE_URL=http://localhost:11434            

            # DeepSeek Configuration (for MCP model selection)
            DEEPSEEK_API_KEY=

            # Temperature and Max Tokens Configuration
            TEMPERATURE=
            MAX_TOKENS=

            # OpenRouter Configuration (for MCP model selection)
            OPENROUTER_API_KEY=

            # Tavily Configuration (for MCP web search tools)
            TAVILY_API_KEY=

            # Browserless Configuration (for MCP browser tools)
            BROWSERLESS_API_KEY=

            # SSL Configuration (Optional - only needed for corporate proxies or custom certificates)
            # Leave empty to use auto-detection: corporate certs → certifi → system defaults
            # SSL_CERT_FILE=
            # GRPC_DEFAULT_SSL_ROOTS_FILE_PATH=  # Optional - for gRPC connections if needed
            """
                ).strip()
                + "\n",
                encoding="utf-8",
            )

        pipeline_path = root / "config" / "pipelines.yml"
        if overwrite or not pipeline_path.exists():
            # Generate pattern-only pipelines.yml (MVP-6.0)
            nodes_block = ""
            pattern_steps = ""

            for a in cfg.get("agents", []):
                aid = a.get("id") or "agent"
                config_file = f"agents/{aid}.yml"

                # Add node definition
                nodes_block += self._indent(2, f"- id: {aid}\n")
                nodes_block += self._indent(4, f"config_file: {config_file}\n")

                # Add pattern step
                pattern_steps += self._indent(4, f"- node: {aid}\n")

            pipeline = PIPELINE_YML.format(
                title=cfg.get("title", "My Demo"),
                nodes_block=nodes_block,
                pattern_steps=pattern_steps,
            )
            pipeline_path.write_text(pipeline, encoding="utf-8")

        # Minimal pyproject.toml so users can `uv sync` per-project deps
        pyproject_path = root / "pyproject.toml"
        if overwrite or not pyproject_path.exists():
            project_pkg = root.name.replace("-", "_")
            pyproject_path.write_text(
                textwrap.dedent(
                    f"""# Generated by topaz-agent-kit scaffold
[project]
name = "{project_pkg}"
version = "0.1.0"
description = "Topaz Agent Kit project"
requires-python = ">=3.9"

[build-system]
requires = ["setuptools>=61.0", "wheel"]
build-backend = "setuptools.build_meta"

[tool.setuptools.packages.find]
where = ["."]
include = ["*"]
exclude = ["tests*", "test*"]
"""
                ),
                encoding="utf-8",
            )

        # README.md
        readme_path = root / "README.md"
        if overwrite or not readme_path.exists():
            readme_path.write_text(
                textwrap.dedent(
                    f"""# {cfg.get("title", "My Demo")}

This project was scaffolded by [Topaz Agent Kit](https://github.com/your-org/topaz-agent-kit).

## Setup

1. Install dependencies: `uv sync`
2. Configure your environment variables in `.env`
3. Run: `uv run python cli_app.py`

## Configuration

- `config/pipelines.yml` - Pipeline registry and configuration
- `config/ui_manifest.yml` - UI configuration
- `.env` - Environment variables

## Development

- `agents/` - Agent implementations
- `services/` - Service wrappers
- `ui/` - Frontend assets
"""
                ),
                encoding="utf-8",
            )

        # Generate stubs if requested
        if generate_stubs:
            try:
                generator = AgentGenerator()
                result = generator.generate_agents(root, overwrite=overwrite)
                if result == 0:
                    self.logger.info("Generated agent stubs")
                else:
                    self.logger.warning("Agent stub generation failed")
            except Exception as e:
                self.logger.warning("Failed to generate agent stubs: {}", e)

        # Generate remote services if requested
        if generate_remote_services:
            try:
                generator = ServiceGenerator()
                result = generator.generate_services(root, overwrite=overwrite)
                if result == 0:
                    self.logger.info("Generated remote service stubs")
                else:
                    self.logger.warning("Remote service stub generation failed")
            except Exception as e:
                self.logger.warning("Failed to generate remote service stubs: {}", e)

    def _scaffold_from_template(
        self,
        template_path: Path,
        target_dir: Path,
        template_type: str,
        template_name: str,
        *,
        overwrite: bool = False,
    ) -> None:
        """
        Generic scaffolding logic shared by all template types (starters, foundations, apps).
        
        Copies all standard folders and files from the template to the target directory.
        Whatever exists in the template gets copied - templates control their own content.
        
        Args:
            template_path: Path to the source template directory
            target_dir: Path to the target project directory
            template_type: Type of template (starter, foundation, app) for logging
            template_name: Name of the template for logging
            overwrite: Whether to overwrite existing files
        """
        self.logger.info(
            "Scaffolding from {} '{}' to {}",
            template_type,
            template_name,
            target_dir,
        )

        # Ensure target directory exists
        target_dir.mkdir(parents=True, exist_ok=True)

        # 1) Copy config/ directory (all YAML configs)
        if (template_path / "config").exists():
            shutil.copytree(
                template_path / "config", target_dir / "config", dirs_exist_ok=True
            )
            self.logger.info("Copied config/")

        # 2) Copy prompts/ to config/prompts/ (legacy location support)
        if (template_path / "prompts").exists():
            prompts_dst = target_dir / "config" / "prompts"
            prompts_dst.mkdir(parents=True, exist_ok=True)
            shutil.copytree(
                template_path / "prompts", prompts_dst, dirs_exist_ok=True
            )
            self.logger.info("Copied prompts/ to config/prompts/")

        # 3) Copy schemas/ to config/schemas/
        if (template_path / "schemas").exists():
            schemas_dst = target_dir / "config" / "schemas"
            schemas_dst.mkdir(parents=True, exist_ok=True)
            shutil.copytree(
                template_path / "schemas", schemas_dst, dirs_exist_ok=True
            )
            self.logger.info("Copied schemas/ to config/schemas/")

        # 4) Copy memory templates
        if (template_path / "config" / "memory" / "shared").exists():
            shared_dst = target_dir / "config" / "memory" / "shared"
            shared_dst.mkdir(parents=True, exist_ok=True)
            shutil.copytree(
                template_path / "config" / "memory" / "shared", shared_dst, dirs_exist_ok=True
            )
            self.logger.info("Copied shared memory templates to config/memory/shared/")

        # Backward compatibility: config/shared/ -> config/memory/shared/pipeline/
        if (template_path / "config" / "shared").exists():
            shared_dst = target_dir / "config" / "memory" / "shared" / "pipeline"
            shared_dst.mkdir(parents=True, exist_ok=True)
            shutil.copytree(
                template_path / "config" / "shared", shared_dst, dirs_exist_ok=True
            )
            self.logger.warning("Found deprecated config/shared/ location. Migrated to config/memory/shared/pipeline/")

        if (template_path / "config" / "memory").exists():
            memory_dst = target_dir / "config" / "memory"
            memory_dst.mkdir(parents=True, exist_ok=True)
            shutil.copytree(
                template_path / "config" / "memory", memory_dst, dirs_exist_ok=True
            )
            self.logger.info("Copied memory prompt templates to config/memory/")

        # 5) Copy standard template folders (only if they exist)
        template_folders = [
            ("data", "data"),
            ("services", "services"),
            ("agents", "agents"),
            ("utils", "utils"),
            ("tools", "tools"),
            ("requisites", "requisites"),
            ("scripts", "scripts"),
            ("ui", "ui"),
            ("docs", "docs"),
        ]
        
        for src_folder, dst_folder in template_folders:
            if (template_path / src_folder).exists():
                shutil.copytree(
                    template_path / src_folder,
                    target_dir / dst_folder,
                    dirs_exist_ok=True,
                )
                self.logger.info("Copied {}/", src_folder)

        # 6) Copy individual files from template
        template_files = [
            "README.md",
            ".env.example",
            ".gitignore",
        ]
        
        for filename in template_files:
            if (template_path / filename).exists():
                shutil.copy2(template_path / filename, target_dir / filename)
                self.logger.info("Copied {}", filename)

        # 7) Copy ui_manifest.yml separately (if exists in config/)
        ui_manifest_src = template_path / "config" / "ui_manifest.yml"
        if ui_manifest_src.exists():
            ui_manifest_dst = target_dir / "config" / "ui_manifest.yml"
            shutil.copy2(ui_manifest_src, ui_manifest_dst)
            self.logger.info("Copied config/ui_manifest.yml")

        # 8) Copy from package (shared resources: .env, requirements.txt, scripts, docs, skills)
        self._copy_package_resources(target_dir)

        # 9) Copy Gmail credentials if they exist
        self._copy_gmail_credentials(target_dir)

        self.logger.success(
            "Scaffolded from {} '{}' to {}", template_type, template_name, target_dir
        )

    def _copy_package_resources(self, target_dir: Path) -> None:
        """
        Copy shared resources from the installed package to the target directory.
        
        This includes .env, requirements.txt, scripts, docs, skills, and agents (subagents)
        that are common to all project types.
        """
        try:
            import topaz_agent_kit

            package_dir = Path(topaz_agent_kit.__file__).parent

            # Copy .env from package
            package_env = package_dir / ".env"
            if package_env.exists():
                shutil.copy2(package_env, target_dir / ".env")
                self.logger.success("Copied .env from package")

            # Copy requirements.txt (check workspace root first, then package)
            workspace_root = Path(__file__).parent.parent.parent.parent
            requirements_src = None

            workspace_requirements = workspace_root / "requirements.txt"
            if workspace_requirements.exists() and workspace_requirements.is_file():
                requirements_src = workspace_requirements
                self.logger.debug("Found requirements.txt in workspace root (dev mode)")

            if not requirements_src:
                package_requirements = package_dir / "requirements.txt"
                if package_requirements.exists() and package_requirements.is_file():
                    requirements_src = package_requirements
                    self.logger.debug("Found requirements.txt in package directory")

            if requirements_src:
                shutil.copy2(requirements_src, target_dir / "requirements.txt")
                self.logger.success("Copied requirements.txt")

            # Copy scripts from package
            scripts_src = package_dir / "scripts"
            scripts_dst = target_dir / "scripts"

            if scripts_src.exists() and scripts_src.is_dir():
                if scripts_src.resolve() != scripts_dst.resolve():
                    if scripts_dst.exists():
                        shutil.rmtree(scripts_dst, ignore_errors=True)
                        # Wait for removal to complete
                        for _ in range(10):
                            if not scripts_dst.exists():
                                break
                            time.sleep(0.1)

                    scripts_dst.parent.mkdir(parents=True, exist_ok=True)
                    try:
                        shutil.copytree(scripts_src, scripts_dst, dirs_exist_ok=True)
                        self.logger.success("Copied scripts from package")
                    except Exception as e:
                        self.logger.warning("Failed to copy scripts: {}", e)

            # Copy entire .cursor/ folder (check workspace root first for dev mode, then package)
            cursor_src = None
            workspace_cursor = workspace_root / ".cursor"
            
            if workspace_cursor.exists() and workspace_cursor.is_dir():
                cursor_src = workspace_cursor
                self.logger.debug("Found .cursor/ folder in workspace root (dev mode)")
            
            if not cursor_src:
                package_cursor = package_dir / ".cursor"
                if package_cursor.exists() and package_cursor.is_dir():
                    cursor_src = package_cursor
                    self.logger.debug("Found .cursor/ folder in package directory")
            
            if cursor_src:
                cursor_dst = target_dir / ".cursor"
                cursor_dst.mkdir(parents=True, exist_ok=True)
                try:
                    # Exclude certain files when copying
                    exclude_patterns = {".DS_Store", "debug.log", "__pycache__", ".pyc"}
                    
                    def ignore_func(src, names):
                        """Ignore certain files and directories."""
                        ignored = []
                        for name in names:
                            if name in exclude_patterns or any(name.endswith(ext) for ext in [".pyc", ".pyo"]):
                                ignored.append(name)
                        return ignored
                    
                    shutil.copytree(cursor_src, cursor_dst, ignore=ignore_func, dirs_exist_ok=True)
                    
                    # Verify what was copied
                    copied_dirs = [d.name for d in cursor_dst.iterdir() if d.is_dir()]
                    self.logger.success("Copied .cursor/ folder")
                    self.logger.debug("Copied directories: {}", ", ".join(copied_dirs))
                except Exception as e:
                    self.logger.warning("Failed to copy .cursor/ folder: {}", e)

        except Exception as e:
            self.logger.warning("Failed to copy package resources: {}", e)

    def scaffold_from_starter(
        self, starter_name: str, target_dir: Path, *, overwrite: bool = False
    ) -> None:
        """Scaffold a project from a starter or foundation template."""
        try:
            template_path = None
            template_type = None

            # First try to locate template from package (when installed)
            try:
                import importlib.resources

                # Try starters first
                package_templates = importlib.resources.files(
                    "topaz_agent_kit.templates.starters"
                )
                template_path = package_templates / starter_name
                if template_path.exists():
                    template_type = "starter"
                    self.logger.info(
                        "Found starter template in package: {}", template_path
                    )
                else:
                    # Try foundations
                    package_templates = importlib.resources.files(
                        "topaz_agent_kit.templates.foundations"
                    )
                    template_path = package_templates / starter_name
                    if template_path.exists():
                        template_type = "foundation"
                        self.logger.info(
                            "Found foundation template in package: {}", template_path
                        )
                    else:
                        template_path = None
            except Exception:
                template_path = None

            # Fallback: Try local development templates
            if not template_path:
                try:
                    project_root = Path(__file__).parent.parent.parent.parent

                    # Try starters first
                    local_templates = (
                        project_root
                        / "src"
                        / "topaz_agent_kit"
                        / "templates"
                        / "starters"
                        / starter_name
                    )
                    if local_templates.exists():
                        template_path = local_templates
                        template_type = "starter"
                        self.logger.info(
                            "Found starter template in development: {}", template_path
                        )
                    else:
                        # Try foundations
                        local_templates = (
                            project_root
                            / "src"
                            / "topaz_agent_kit"
                            / "templates"
                            / "foundations"
                            / starter_name
                        )
                        if local_templates.exists():
                            template_path = local_templates
                            template_type = "foundation"
                            self.logger.info(
                                "Found foundation template in development: {}",
                                template_path,
                            )
                except Exception as e:
                    self.logger.warning("Failed to check local templates: {}", e)

            # Template not found anywhere
            if not template_path:
                self.logger.error(
                    "Template '{}' not found in package or development environment",
                    starter_name,
                )
                return

            # Use the generic scaffolding method
            self._scaffold_from_template(
                template_path, target_dir, template_type, starter_name, overwrite=overwrite
            )

        except Exception as e:
            self.logger.error(
                "Failed to scaffold from starter '{}': {}", starter_name, e
            )

    def scaffold_from_app(
        self, app_name: str, target_dir: Path, *, overwrite: bool = False
    ) -> None:
        """Scaffold a project from an app template.
        
        App templates work exactly like starters/foundations - whatever exists
        in the template gets copied. The template controls its own content.
        """
        try:
            template_path = None

            # Try to find app template in package
            try:
                import importlib.resources

                package_templates = importlib.resources.files(
                    "topaz_agent_kit.templates.apps"
                )
                template_path = package_templates / app_name
                if template_path.exists():
                    self.logger.info(
                        "Found app template in package: {}", template_path
                    )
                else:
                    template_path = None
            except Exception:
                pass

            # Fallback to development directory
            if not template_path:
                try:
                    project_root = Path(__file__).parent.parent.parent.parent

                    local_templates = (
                        project_root
                        / "src"
                        / "topaz_agent_kit"
                        / "templates"
                        / "apps"
                        / app_name
                    )
                    if local_templates.exists():
                        template_path = local_templates
                        self.logger.info(
                            "Found app template in development: {}", template_path
                        )
                except Exception as e:
                    self.logger.warning(
                        "Error checking development templates: {}", e
                    )

            if not template_path:
                self.logger.error(
                    "App template '{}' not found in package or development environment",
                    app_name,
                )
                return

            # Use the generic scaffolding method (same as starters/foundations)
            self._scaffold_from_template(
                template_path, target_dir, "app", app_name, overwrite=overwrite
            )

        except Exception as e:
            self.logger.error(
                "Failed to scaffold from app template '{}': {}", app_name, e
            )
            import traceback
            traceback.print_exc()

    def scaffold_project(
        self,
        target_dir: Path,
        *,
        overwrite: bool = False,
        generate_stubs: bool = True,
        generate_remote_services: bool = True,
    ) -> None:
        """Scaffold a basic project with default configuration."""
        cfg = {"title": "My Demo", "agents": []}
        self._write_files(
            target_dir,
            cfg,
            overwrite=overwrite,
            generate_stubs=generate_stubs,
            generate_remote_services=generate_remote_services,
        )

        # Copy Gmail credentials if they exist in project root
        self._copy_gmail_credentials(target_dir)

        self.logger.info("Created project at {}", target_dir)


def main() -> None:
    """CLI entry point for scaffolding."""
    parser = argparse.ArgumentParser(description="Scaffold a new project")
    parser.add_argument("target", help="Target directory for the new project")
    parser.add_argument("--starter", help="Starter template to use")
    parser.add_argument(
        "--overwrite", action="store_true", help="Overwrite existing files"
    )
    parser.add_argument(
        "--no-stubs", action="store_true", help="Skip agent stub generation"
    )
    parser.add_argument(
        "--no-remote-services",
        action="store_true",
        help="Skip remote service generation",
    )
    args = parser.parse_args()

    target_dir = Path(args.target)
    if target_dir.exists() and not args.overwrite:
        print(
            f"Target directory {target_dir} already exists. Use --overwrite to overwrite."
        )
        sys.exit(1)

    scaffolder = ProjectScaffolder()

    if args.starter:
        # Scaffold from starter template
        scaffolder.scaffold_from_starter(
            args.starter, target_dir, overwrite=args.overwrite
        )
    else:
        # Scaffold basic project
        gen_stubs = not args.no_stubs
        gen_remote = not args.no_remote_services
        scaffolder.scaffold_project(
            target_dir,
            overwrite=args.overwrite,
            generate_stubs=gen_stubs,
            generate_remote_services=gen_remote,
        )


if __name__ == "__main__":  # pragma: no cover
    main()
