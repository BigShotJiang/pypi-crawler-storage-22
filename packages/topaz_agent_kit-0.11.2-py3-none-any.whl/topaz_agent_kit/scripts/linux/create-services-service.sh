#!/bin/bash
# Helper script to create a systemd service for A2A Services (per-project)
# Usage: ./create-services-service.sh <projects-dir> <project-name> [user]
# Example: ./create-services-service.sh /home/nkhare/tak-projects pa nkhare

set -e

PROJECTS_DIR="${1:-}"
PROJECT_NAME="${2:-}"
SERVICE_USER="${3:-$USER}"

if [ -z "$PROJECTS_DIR" ] || [ -z "$PROJECT_NAME" ]; then
    echo "Usage: $0 <projects-dir> <project-name> [user]"
    echo "Example: $0 /home/nkhare/tak-projects pa nkhare"
    exit 1
fi

PROJECT_DIR="$PROJECTS_DIR/$PROJECT_NAME"

if [ ! -d "$PROJECT_DIR" ]; then
    echo "Error: Project directory not found: $PROJECT_DIR"
    exit 1
fi

# Check if unified_service.py exists
if [ ! -f "$PROJECT_DIR/services/unified_service.py" ]; then
    echo "Error: unified_service.py not found at $PROJECT_DIR/services/unified_service.py"
    echo "Please generate services first: topaz-agent-kit generate $PROJECT_DIR --services"
    exit 1
fi

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root (use sudo)"
    exit 1
fi

# Find uv executable
UV_PATH=$(which uv 2>/dev/null || echo "")
if [ -z "$UV_PATH" ]; then
    echo "Error: 'uv' command not found in PATH"
    echo "Please install uv or ensure it's in your PATH"
    exit 1
fi

# Find topaz-agent-kit command
TAK_PATH=$(which topaz-agent-kit 2>/dev/null || echo "")
if [ -z "$TAK_PATH" ]; then
    USE_UV_RUN=true
else
    USE_UV_RUN=false
fi

# Get absolute paths
PROJECTS_DIR=$(realpath "$PROJECTS_DIR")
PROJECT_DIR="$PROJECTS_DIR/$PROJECT_NAME"

# Create log directory (per-project)
LOG_DIR="$PROJECT_DIR/logs"
mkdir -p "$LOG_DIR"
chown "$SERVICE_USER:$SERVICE_USER" "$LOG_DIR"

# Service name (per-project)
SERVICE_NAME="topaz-agent-kit-services-${PROJECT_NAME}"

# Create systemd service file
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"

echo "Creating Services (A2A) systemd service: $SERVICE_NAME"
echo "Projects directory: $PROJECTS_DIR"
echo "Project name: $PROJECT_NAME"
echo "User: $SERVICE_USER"
echo ""

# Determine command to use
# Run from projects directory with project name
if [ "$USE_UV_RUN" = true ]; then
    EXEC_START="$UV_PATH run topaz-agent-kit serve services -p \"$PROJECT_NAME\""
else
    EXEC_START="$TAK_PATH serve services -p \"$PROJECT_NAME\""
fi

# Create service file
cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Topaz Agent Kit - A2A Services (${PROJECT_NAME})
After=network.target topaz-agent-kit-mcp.service

[Service]
Type=simple
User=${SERVICE_USER}
WorkingDirectory=${PROJECTS_DIR}
ExecStart=${EXEC_START}
Restart=always
RestartSec=10
StandardOutput=append:${LOG_DIR}/services-service.log
StandardError=append:${LOG_DIR}/services-service-error.log

# Environment variables
Environment="PATH=/usr/local/bin:/usr/bin:/bin"
Environment="TOPAZ_PROJECTS_DIR=${PROJECTS_DIR}"
Environment="TOPAZ_PROJECT_NAME=${PROJECT_NAME}"
Environment="TOPAZ_LOG_DIR=${LOG_DIR}"

# Resource limits
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF

echo "✅ Service file created: $SERVICE_FILE"
echo ""
echo "Next steps:"
echo "1. Review the service file: sudo cat $SERVICE_FILE"
echo "2. Reload systemd: sudo systemctl daemon-reload"
echo "3. Enable service: sudo systemctl enable $SERVICE_NAME"
echo "4. Start service: sudo systemctl start $SERVICE_NAME"
echo "5. Check status: sudo systemctl status $SERVICE_NAME"
echo "6. View logs: sudo journalctl -u $SERVICE_NAME -f"
echo ""
