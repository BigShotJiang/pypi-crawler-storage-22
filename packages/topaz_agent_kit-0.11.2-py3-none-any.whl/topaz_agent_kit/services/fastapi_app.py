import asyncio
import json
import os
import traceback
import subprocess
import yaml
from typing import Any, Dict, List, Optional, Tuple
from pathlib import Path
import importlib
from datetime import datetime, timedelta
import time

from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse, FileResponse, Response
from starlette.staticfiles import StaticFiles
import logging

from topaz_agent_kit.utils.file_upload import FileUploadError
from topaz_agent_kit.core.ag_ui_event_emitter import AGUIEventEmitter
from topaz_agent_kit.core.pipeline_loader import PipelineLoader
from topaz_agent_kit.orchestration import Orchestrator
from topaz_agent_kit.orchestration.operations_assistant import OperationsAssistant
from topaz_agent_kit.utils.logger import Logger, remove_opentelemetry_console_handlers
from topaz_agent_kit.services.ag_ui_service import AGUIService
from topaz_agent_kit.utils.pdf_highlighter import PDFHighlighter
from topaz_agent_kit.orchestration.assistant import Assistant, AssistantResponse
from topaz_agent_kit.core.file_storage import FileStorageService
from chromadb import PersistentClient
from topaz_agent_kit.core.database_manager import DatabaseManager
from topaz_agent_kit.core.chat_storage import ChatStorage
from topaz_agent_kit.core.session_manager import SessionManager
from topaz_agent_kit.core.app_session_store import AppSessionStore
from topaz_agent_kit.core.triggers.manager import TriggerManager
from topaz_agent_kit.core.exceptions import ConfigurationError
from topaz_agent_kit.utils.path_resolver import find_repository_root, resolve_config_path


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for graceful startup and shutdown"""
    logger = Logger("FastAPIApp")
    # Startup
    logger.info("FastAPI application starting up")
    
    # Initialize trigger manager if orchestrator is available
    trigger_manager = None
    if hasattr(app.state, "orchestrator") and app.state.orchestrator:
        try:
            orchestrator = app.state.orchestrator
            pipeline_configs = orchestrator.validated_config.individual_pipelines
            
            # Get setup_emitter_fn from app.state (stored by create_app)
            setup_emitter_fn = getattr(app.state, "setup_emitter_fn", None)
            if not setup_emitter_fn:
                logger.warning("setup_emitter_fn not found in app.state, trigger manager will run without UI events")
            
            trigger_manager = TriggerManager(
                orchestrator=orchestrator,
                project_dir=app.state.project_dir,
                pipeline_configs=pipeline_configs,
                setup_emitter_fn=setup_emitter_fn,
            )
            await trigger_manager.start()
            app.state.trigger_manager = trigger_manager
            logger.success("Trigger manager started successfully")
        except Exception as e:
            logger.error("Failed to start trigger manager: {}", e)
    
    yield
    
    # Shutdown
    logger.info("FastAPI application shutting down gracefully")
    
    # Stop trigger manager
    if trigger_manager:
        try:
            await trigger_manager.stop()
            logger.info("Trigger manager stopped")
        except Exception as e:
            logger.error("Error stopping trigger manager: {}", e)
    
    # Give time for active connections to close
    await asyncio.sleep(0.1)


def create_app(project_dir: str, ui_dist_dir: str | None = None) -> FastAPI:
    logger = Logger("FastAPIApp")
    logger.info("Creating FastAPI application for project: {}", project_dir)
    
    # Create and cache PipelineLoader instance for reuse across requests
    pipeline_loader = PipelineLoader(project_dir)
    cfg, ui_manifest = pipeline_loader.load()
    logger.debug("Configuration loaded successfully")

    # Get FastAPI configuration from servers.fastapi
    servers_config = cfg.get("servers", {})
    if not servers_config:
        logger.error("Missing 'servers' section in configuration")
        raise ConfigurationError("Missing 'servers' section in configuration")
    
    fastapi_config = servers_config.get("fastapi", {})
    if not fastapi_config:
        logger.error("Missing 'servers.fastapi' section in configuration")
        raise ConfigurationError("Missing 'servers.fastapi' section in configuration")
    
    # Resolve FastAPI title (for API documentation only, not frontend UI):
    # - In app-only mode: use ui_manifest.title, or first app's title from apps/{app_id}.yml
    # - In pipeline mode: use ui_manifest.title, or pipeline name
    # - Default fallback
    fastapi_title = None
    
    # Priority 1: ui_manifest.title (overall project/app title)
    if ui_manifest and isinstance(ui_manifest, dict):
        fastapi_title = ui_manifest.get("title")
    
    # Priority 2: App-only mode - first app's title from apps/{app_id}.yml
    if not fastapi_title and cfg.get("_app_only_mode", False):
        try:
            apps_file = Path(project_dir) / "config" / "apps.yml"
            if apps_file.exists():
                with open(apps_file, "r", encoding="utf-8") as f:
                    apps_registry = yaml.safe_load(f) or {}
                    apps_list = apps_registry.get("apps", [])
                    if apps_list:
                        first_app_entry = apps_list[0]
                        first_app_id = first_app_entry.get("id")
                        if first_app_id:
                            # Load app config with default path resolution
                            config_file = first_app_entry.get("config_file")
                            resolved_config_file = resolve_config_path(config_file, "apps/{id}.yml", first_app_id)
                            if resolved_config_file:
                                app_config_path = Path(project_dir) / "config" / resolved_config_file
                                if app_config_path.exists():
                                    with open(app_config_path, "r", encoding="utf-8") as app_f:
                                        first_app_config = yaml.safe_load(app_f)
                                        if first_app_config:
                                            fastapi_title = first_app_config.get("title")
        except Exception as e:
            logger.debug("Failed to load first app title for FastAPI title: {}", e)
    
    # Priority 3: Pipeline mode - pipeline name
    if not fastapi_title:
        fastapi_title = cfg.get("name")
    
    # Priority 4: Default fallback
    if not fastapi_title:
        fastapi_title = "Topaz Agent Kit API"
    
    # Get CORS configuration (optional, with defaults)
    cors_config = fastapi_config.get("cors", {})
    allow_origins = cors_config.get("allow_origins", ["*"])
    allow_credentials = cors_config.get("allow_credentials", True)
    allow_methods = cors_config.get("allow_methods", ["*"])
    allow_headers = cors_config.get("allow_headers", ["*"])
    
    app = FastAPI(title=fastapi_title, lifespan=lifespan)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=allow_origins,
        allow_credentials=allow_credentials,
        allow_methods=allow_methods,
        allow_headers=allow_headers,
    )
    logger.debug("CORS middleware added with config: origins={}, credentials={}, methods={}, headers={}", 
                 allow_origins, allow_credentials, allow_methods, allow_headers)
    
    # Helper function to resolve logo path from manifest
    def resolve_logo_path() -> str:
        """Resolve logo path from manifest.brand.logo, with fallback to topaz-logo.png"""
        logo_path_str = None
        if ui_manifest and isinstance(ui_manifest, dict):
            brand = ui_manifest.get("brand", {})
            if isinstance(brand, dict):
                logo_path_str = brand.get("logo")
        
        # Normalize path: remove leading slashes, ensure assets/ prefix if needed
        if logo_path_str:
            logo_path_str = logo_path_str.lstrip("/")
            if "/" not in logo_path_str:
                logo_path_str = f"assets/{logo_path_str}"
            elif not logo_path_str.startswith("assets/"):
                logo_path_str = f"assets/{logo_path_str}"
        else:
            # Fallback to default
            logo_path_str = "assets/topaz-logo.png"
        
        return logo_path_str
    
    # Resolve logo path once at startup
    resolved_logo_path = resolve_logo_path()
    
    # Add proxy headers middleware for reverse proxy support (external access)
    # This allows the app to work behind proxies/load balancers
    @app.middleware("http")
    async def proxy_headers_middleware(request: Request, call_next):
        """Handle proxy headers for external access"""
        # Forward common proxy headers to help with external access
        # This is useful when behind reverse proxies, load balancers, or NAT
        forwarded_host = request.headers.get("X-Forwarded-Host")
        forwarded_proto = request.headers.get("X-Forwarded-Proto")
        forwarded_for = request.headers.get("X-Forwarded-For")
        
        # Log proxy headers for debugging (only in debug mode)
        if logger.isEnabledFor(logging.DEBUG) and (forwarded_host or forwarded_proto or forwarded_for):
            logger.debug("Proxy headers detected - Host: {}, Proto: {}, For: {}", 
                        forwarded_host, forwarded_proto, forwarded_for)
        
        response = await call_next(request)
        return response

    # Add cache-busting middleware for JavaScript files and favicons
    @app.middleware("http")
    async def cache_bust_middleware(request: Request, call_next):
        response = await call_next(request)
        path = request.url.path.lower()
        # Cache-bust JavaScript files and icon/favicon files
        if path.endswith('.js') or 'favicon' in path or 'icon' in path or path.endswith('.ico') or path.endswith('.png'):
            # Only apply to icon-related files (not all PNGs)
            # Check for logo path from manifest or default
            logo_in_path = f"/{resolved_logo_path}" in path or f"/assets/topaz-logo.png" in path
            if 'favicon' in path or 'icon' in path or path.endswith('.ico') or logo_in_path:
                response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
                response.headers["Pragma"] = "no-cache"
                response.headers["Expires"] = "0"
            elif path.endswith('.js'):
                response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
                response.headers["Pragma"] = "no-cache"
                response.headers["Expires"] = "0"
        return response

    orchestrator = Orchestrator(cfg, project_dir=project_dir)
    logger.debug("Orchestrator created successfully")
    
    # Store orchestrator, project_dir, pipeline_loader, and loaded config in app state for lifespan
    app.state.orchestrator = orchestrator
    app.state.project_dir = project_dir
    app.state.pipeline_loader = pipeline_loader  # Cache for reuse in endpoints
    app.state.pipeline_config = cfg  # Cache loaded pipeline config
    app.state.loaded_ui_config = ui_manifest  # Cache loaded UI config (includes _operations)
    
    # Create PDF highlighter instance
    pdf_highlighter = PDFHighlighter()
    logger.debug("PDF highlighter created successfully")
    
    # Initialize shared services once (instead of per-request)
    file_storage = None
    chroma_client = None
    chat_storage = None
    session_manager = None
    db_manager = None
    app_session_store = None
    
    def get_shared_services():
        nonlocal file_storage, chroma_client, chat_storage, session_manager, db_manager, app_session_store
        
        if file_storage is None:
            # Get file paths from orchestrator config
            rag_files_path = orchestrator.validated_config.rag_files_path if orchestrator.validated_config else "./data/rag_files"
            user_files_path = orchestrator.validated_config.user_files_path if orchestrator.validated_config else "./data/user_files"
            
            if not Path(rag_files_path).is_absolute():
                rag_files_path = str(Path(project_dir) / rag_files_path)
            if not Path(user_files_path).is_absolute():
                user_files_path = str(Path(project_dir) / user_files_path)
                
            file_storage = FileStorageService(rag_files_path, user_files_path)
            
            # Get ChromaDB path from orchestrator config
            chromadb_path = orchestrator.validated_config.chromadb_path if orchestrator.validated_config else "./data/chroma_db"
            if not Path(chromadb_path).is_absolute():
                chromadb_path = str(Path(project_dir) / chromadb_path)
            
            # Get chat.db path
            chatdb_path = orchestrator.validated_config.chatdb_path if orchestrator.validated_config else "./data/chat.db"
            if not Path(chatdb_path).is_absolute():
                chatdb_path = str(Path(project_dir) / chatdb_path)
            
            # Initialize ChromaDB client
            chroma_client = PersistentClient(path=chromadb_path)
            
            # Initialize chat database
            chat_storage = ChatStorage(chatdb_path)
            session_manager = SessionManager(chat_storage)
            db_manager = DatabaseManager(chat_storage, session_manager)
            
            # Initialize app session store (uses same db as chat)
            app_session_store = AppSessionStore(chatdb_path)
            
            logger.info("Shared services initialized once")
        
        return file_storage, chroma_client, chat_storage, session_manager, db_manager, app_session_store
    
    history: list[dict] = []
    log_buffer: list[str] = []
    activity: list[dict] = []  # bounded buffer of recent activity events

    sessions: dict[int, list[dict]] = {}
    current_session_id: int | None = None
    # AG-UI adapter session queues (session_id -> asyncio.Queue[str])
    agui_session_queues: dict[int, asyncio.Queue[str]] = {}
    # HITL approval waiters: session_id -> { gate_id -> Future }
    hitl_waiters: dict[int, dict[str, asyncio.Future]] = {}
    # AG-UI service instances per session (session_id -> AGUIService)
    agui_services: dict[int, AGUIService] = {}
    # Run counters per session (session_id -> counter)
    session_run_counters: dict[int, int] = {}
    # AG-UI emitters per session (session_id -> AGUIEventEmitter)
    agui_emitters: dict[int, AGUIEventEmitter] = {}
    # Assistant 
    agui_assistants: dict[int, Assistant] = {}
    initialized_assistants: set[int] = set()


    def _fresh_waiter_future(session_id: int, gate_id: str) -> asyncio.Future:
        """Create a fresh Future for HITL gate waiting (non-async since it doesn't await anything)"""
        futs = hitl_waiters.setdefault(session_id, {})
        old = futs.get(gate_id)
        try:
            if old and not old.done():
                old.cancel()
        except Exception:
            pass
        # Use get_running_loop() instead of get_event_loop() to ensure we get the correct loop
        # This is critical when FastAPI runs in a thread
        loop = asyncio.get_running_loop()
        fut = loop.create_future()
        futs[gate_id] = fut
        return fut

    # Setup logging mirror handler for UI logs (mirror FastAPI/uvicorn and app logs)
    class _UIBufferHandler(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:  # type: ignore[override]
            try:
                ts = getattr(record, "asctime", None)
                if not ts:
                    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                level = record.levelname
                name = record.name
                msg = self.format(record)
                # Avoid double timestamp in msg if formatter adds it
                # Keep only message after the last ' - ' if present (uvicorn style)
                if " - " in msg:
                    msg = msg.split(" - ", 2)[-1]
                line = f"{ts} | {level} | {name} | {msg}"
                log_buffer.append(line)
                if len(log_buffer) > 1000:
                    del log_buffer[: len(log_buffer) - 1000]
            except Exception:
                pass

    # UI logging handler - respect global log level instead of forcing DEBUG
    ui_handler = _UIBufferHandler()
    # Don't force DEBUG level - let Topaz Logger control it
    ui_handler.setLevel(logging.getLogger().getEffectiveLevel())
    # Formatter consistent with root logger
    ui_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(name)s - %(message)s"))
    
    # Only add handler to root logger - propagation will handle the rest
    # This prevents duplicate messages from multiple handlers
    root_logger = logging.getLogger()
    if not any(isinstance(h, _UIBufferHandler) for h in root_logger.handlers):
        root_logger.addHandler(ui_handler)
    
    # Remove OpenTelemetry console handlers that output unwanted JSON logs
    # This needs to be called after any observability setup
    remove_opentelemetry_console_handlers()

    # Determine optional override for UI distribution directory
    if not ui_dist_dir:
        ui_dist_dir = os.environ.get("TOPAZ_UI_DIST_DIR") or None

    # Data directory is served via route handler below (not mounted) to allow better control
    # and security checks for file access

    # Register API endpoints BEFORE UI routes to ensure they're matched first
    @app.get("/manifest")
    async def manifest():
        """Return UI manifest with enriched pipeline display info.
        
        Enriches pipelines[] array with display info (title, subtitle, icon) from:
        1. Individual pipeline configs (new pattern)
        2. ui_manifest.yml > pipelines[] (legacy pattern, fallback)
        
        Also exposes operations settings from operations.yml (or legacy ui_manifest.yml).
        """
        manifest = ui_manifest.copy() if ui_manifest else {}
        
        # Reuse cached PipelineLoader instance and loaded configs instead of reloading
        loader = app.state.pipeline_loader
        pipeline_config = app.state.pipeline_config or {}
        loaded_ui = app.state.loaded_ui_config or {}
        
        # Extract operations settings from _operations (set by PipelineLoader)
        try:
            if isinstance(loaded_ui, dict) and "_operations" in loaded_ui:
                operations_config = loaded_ui["_operations"]
                # Expose operations settings at top level for frontend compatibility
                if isinstance(operations_config, dict):
                    if "operations" in operations_config:
                        manifest["operations"] = operations_config["operations"]
                    if "workflow" in operations_config:
                        # Frontend expects operations_workflow (not workflow)
                        manifest["operations_workflow"] = operations_config["workflow"]
        except Exception as e:
            logger.debug("Failed to extract operations config: {}", e)
        
        # Enrich pipelines[] with display info from individual configs
        try:
            
            # Get list of pipelines from pipelines.yml
            pipelines_registry = pipeline_config.get("pipelines", [])
            if pipelines_registry:
                enriched_pipelines = []
                for pipeline_ref in pipelines_registry:
                    if isinstance(pipeline_ref, dict) and "id" in pipeline_ref:
                        pipeline_id = pipeline_ref["id"]
                        # Get display info using new method (with fallback)
                        display_info = loader.get_pipeline_display_info(pipeline_id)
                        
                        # Create enriched pipeline entry
                        enriched_pipeline = {
                            "id": pipeline_id,
                            "title": display_info.get("title", pipeline_id),
                            "subtitle": display_info.get("subtitle", ""),
                            "icon": display_info.get("icon", ""),
                        }
                        
                        # Preserve ui_manifest reference if it exists in legacy pattern
                        if "pipelines" in manifest:
                            for legacy_p in manifest["pipelines"]:
                                if isinstance(legacy_p, dict) and legacy_p.get("id") == pipeline_id:
                                    if "ui_manifest" in legacy_p:
                                        enriched_pipeline["ui_manifest"] = legacy_p["ui_manifest"]
                                    break
                        
                        enriched_pipelines.append(enriched_pipeline)
                
                # Replace pipelines[] in manifest with enriched version
                manifest["pipelines"] = enriched_pipelines
        except Exception as e:
            logger.debug("Failed to enrich pipelines display info: {}", e)
            # Continue with original manifest if enrichment fails
        
        return JSONResponse(manifest)

    # Serve UI from override dist directory if provided, otherwise serve packaged UI
    try:
        if ui_dist_dir and Path(ui_dist_dir).exists() and (Path(ui_dist_dir) / "index.html").exists():
            dist_root = Path(ui_dist_dir)
            logger.info("Serving UI from override dist directory: {}", dist_root)
            
            # Mount project static assets
            use_ui_static = Path(project_dir) / "ui" / "static"
            if use_ui_static.exists():
                app.mount("/static", StaticFiles(directory=str(use_ui_static)), name="static")
                logger.debug("Static files mounted from: {}", use_ui_static)

            @app.get("/")
            async def index():
                index_file = dist_root / "index.html"
                return FileResponse(str(index_file))
            
            # Note: Catch-all route will be registered at the end, after all API routes
        else:
            # Serve packaged UI from topaz_agent_kit.ui.frontend
            try:
                ui_pkg = importlib.resources.files("topaz_agent_kit.ui.frontend")
                logger.info("Serving packaged UI from: {}", ui_pkg)
                
                # Mount project static assets
                use_ui_static = Path(project_dir) / "ui" / "static"
                if use_ui_static.exists():
                    app.mount("/static", StaticFiles(directory=str(use_ui_static)), name="static")
                    logger.debug("Static files mounted from: {}", use_ui_static)

                @app.get("/")
                async def index():
                    try:
                        index_file = ui_pkg / "index.html"
                        logger.debug("Serving packaged index.html from: {}", index_file)
                        # Read file content from importlib.resources (MultiplexedPath)
                        # FileResponse doesn't work with MultiplexedPath, so we read and return content
                        content = (ui_pkg / "index.html").read_bytes()
                        return Response(content=content, media_type="text/html")
                    except Exception as e:
                        logger.error("Failed to serve index.html: {}", e)
                        logger.error("Traceback: {}", traceback.format_exc())
                        return Response(
                            content=f"<html><body><h1>Error loading UI</h1><p>{str(e)}</p></body></html>",
                            media_type="text/html",
                            status_code=500
                        )
                    
                # Mount packaged static assets
                # Note: StaticFiles can't mount from importlib.resources directly
                # We'll handle static files via custom routes if needed
                # For now, skip mounting and let the UI handle asset loading via /static/ mount
                static_dir = ui_pkg / "_next"
                if static_dir.is_dir():
                    try:
                        # Try to get the actual file system path if possible
                        static_path = str(static_dir)
                        # Check if it's a real filesystem path (not MultiplexedPath)
                        if os.path.exists(static_path):
                            app.mount("/_next", StaticFiles(directory=static_path), name="next")
                            logger.debug("Packaged static files mounted from: {}", static_path)
                        else:
                            logger.warning("Cannot mount _next from packaged resources (MultiplexedPath), skipping")
                    except Exception as e:
                        logger.warning("Failed to mount _next static files: {}", e)
                
                # Mount packaged icons
                icons_dir = ui_pkg / "icons"
                if icons_dir.is_dir():
                    try:
                        icons_path = str(icons_dir)
                        if os.path.exists(icons_path):
                            app.mount("/icons", StaticFiles(directory=icons_path), name="icons")
                            logger.debug("Packaged icons mounted from: {}", icons_path)
                        else:
                            logger.warning("Cannot mount icons from packaged resources (MultiplexedPath), skipping")
                    except Exception as e:
                        logger.warning("Failed to mount icons: {}", e)
                
                # Mount packaged assets
                assets_dir = ui_pkg / "assets"
                if assets_dir.is_dir():
                    try:
                        assets_path = str(assets_dir)
                        if os.path.exists(assets_path):
                            app.mount("/assets", StaticFiles(directory=assets_path), name="assets")
                            logger.debug("Packaged assets mounted from: {}", assets_path)
                        else:
                            logger.warning("Cannot mount assets from packaged resources (MultiplexedPath), skipping")
                    except Exception as e:
                        logger.warning("Failed to mount assets: {}", e)
                
                # Note: Catch-all route will be registered at the end, after all API routes
                    
            except Exception as e:
                logger.warning("Failed to mount packaged UI: {}", e)
                logger.error("Traceback: {}", traceback.format_exc())
                # Fallback to simple API response
                @app.get("/")
                async def index():
                    return JSONResponse({
                        "message": "Topaz Agent Kit API",
                        "note": "Packaged UI not available",
                        "endpoints": {
                            "manifest": "/manifest",
                            "health": "/health",
                            "turn": "/agui/turn",
                            "stream": "/agui/stream"
                        }
                    })
    except Exception as e:
        logger.warning("UI mounting failed: {}", e)
        logger.error("UI mounting traceback: {}", traceback.format_exc())
        # Ensure we always have a / endpoint, even if UI mounting completely fails
        @app.get("/")
        async def index_fallback():
            return JSONResponse({
                "message": "Topaz Agent Kit API",
                "note": "UI mounting failed",
                "error": str(e) if logger.isEnabledFor(logging.DEBUG) else "UI unavailable",
                "endpoints": {
                    "manifest": "/manifest",
                    "health": "/health",
                    "turn": "/agui/turn",
                    "stream": "/agui/stream"
                }
            })

    # Add global exception handler to catch and log all unhandled exceptions
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        """Global exception handler to log all unhandled exceptions"""
        logger.error("Unhandled exception in {} {}: {}", request.method, request.url.path, exc)
        logger.error("Exception traceback: {}", traceback.format_exc())
        return JSONResponse(
            status_code=500,
            content={
                "error": "Internal server error",
                "detail": str(exc) if logger.isEnabledFor(logging.DEBUG) else "An error occurred",
                "path": str(request.url.path)
            }
        )

    @app.get("/api/ui_manifests/{pipeline_id}.yml")
    async def get_ui_manifest(pipeline_id: str):
        """Serve individual UI manifest files"""
        manifest_path = Path(project_dir) / "config" / "ui_manifests" / f"{pipeline_id}.yml"
        if manifest_path.exists():
            return FileResponse(str(manifest_path), media_type="text/yaml")
        else:
            return Response(status_code=404)

    @app.get("/api/files")
    async def serve_project_file(file_path: str):
        """Serve files from the project data directory securely.
        
        Args:
            file_path: Absolute file path or path relative to project_dir/data
        """
        try:
            # Normalize the file path
            if os.path.isabs(file_path):
                # Absolute path - validate it's within project_dir/data
                file_path_obj = Path(file_path)
                data_dir = Path(project_dir) / "data"
                try:
                    # Ensure the file is within the data directory
                    file_path_obj.resolve().relative_to(data_dir.resolve())
                except ValueError:
                    logger.warning("File access denied - path outside data directory: {}", file_path)
                    return JSONResponse({"error": "File path must be within project data directory"}, status_code=403)
            else:
                # Relative path - resolve relative to project_dir/data
                file_path_obj = Path(project_dir) / "data" / file_path
            
            # Resolve to absolute path and check it's still within data directory
            file_path_obj = file_path_obj.resolve()
            data_dir = Path(project_dir) / "data"
            try:
                file_path_obj.relative_to(data_dir.resolve())
            except ValueError:
                logger.warning("File access denied - resolved path outside data directory: {}", file_path_obj)
                return JSONResponse({"error": "File path must be within project data directory"}, status_code=403)
            
            # Check if file exists
            if not file_path_obj.exists() or not file_path_obj.is_file():
                logger.debug("File not found: {}", file_path_obj)
                return JSONResponse({"error": "File not found"}, status_code=404)
            
            # Determine media type based on file extension
            media_type = "application/octet-stream"
            ext = file_path_obj.suffix.lower()
            media_type_map = {
                ".pdf": "application/pdf",
                ".png": "image/png",
                ".jpg": "image/jpeg",
                ".jpeg": "image/jpeg",
                ".gif": "image/gif",
                ".svg": "image/svg+xml",
                ".txt": "text/plain",
                ".csv": "text/csv",
                ".json": "application/json",
                ".xml": "application/xml",
                ".html": "text/html",
                ".md": "text/markdown",
            }
            media_type = media_type_map.get(ext, "application/octet-stream")
            
            logger.debug("Serving file: {} (media_type: {})", file_path_obj, media_type)
            
            # For PDFs and images, use inline Content-Disposition so browsers can display them
            # For other files, use attachment to trigger download
            is_inline_type = ext in [".pdf", ".png", ".jpg", ".jpeg", ".gif", ".svg", ".html", ".txt", ".md"]
            content_disposition = "inline" if is_inline_type else "attachment"
            
            return FileResponse(
                str(file_path_obj),
                media_type=media_type,
                headers={
                    "Content-Disposition": f'{content_disposition}; filename="{file_path_obj.name}"',
                    "Cache-Control": "public, max-age=3600"
                }
            )
        except Exception as e:
            logger.error("Error serving file {}: {}", file_path, e)
            logger.error("Traceback: {}", traceback.format_exc())
            return JSONResponse({"error": f"Failed to serve file: {str(e)}"}, status_code=500)

    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.post("/api/sessions/new")
    async def create_new_session() -> JSONResponse:
        """Create a new chat session and return its ID."""
        try:
            session_id = orchestrator.create_session("fastapi")
            return JSONResponse({"session_id": session_id})
        except Exception as e:
            logger.error("Failed to create new session: {}", e)
            return JSONResponse({"error": "session_creation_failed"}, status_code=500)

    # Favicon and icon routes to eliminate 404s
    @app.get("/favicon.ico")
    async def favicon():
        # Try to serve from project static
        use_ui_static = Path(project_dir) / "ui" / "static"
        if use_ui_static.exists():
            icon_path = use_ui_static / resolved_logo_path
            if icon_path.exists():
                logger.debug("Serving favicon from project static: {}", icon_path)
                response = FileResponse(str(icon_path), media_type="image/png")
                response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
                response.headers["Pragma"] = "no-cache"
                response.headers["Expires"] = "0"
                return response
            else:
                logger.debug("Favicon not found at project path: {}", icon_path)
        # Try packaged assets as fallback
        try:
            ui_pkg = importlib.resources.files("topaz_agent_kit.ui.frontend")
            logo_filename = Path(resolved_logo_path).name
            assets_dir = ui_pkg / "assets"
            if assets_dir.is_dir():
                logo_path = assets_dir / logo_filename
                if logo_path.is_file():
                    logger.debug("Serving favicon from packaged assets: {}", logo_path)
                    content = logo_path.read_bytes()
                    response = Response(content=content, media_type="image/png")
                    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
                    response.headers["Pragma"] = "no-cache"
                    response.headers["Expires"] = "0"
                    return response
        except Exception as e:
            logger.debug("Failed to load packaged favicon: {}", e)
        # Return empty response if no icon found
        logger.warning("No favicon found, returning 204")
        return Response(status_code=204)
    
    @app.get("/apple-touch-icon.png")
    async def apple_touch_icon():
        # Try to serve from project static
        use_ui_static = Path(project_dir) / "ui" / "static"
        if use_ui_static.exists():
            icon_path = use_ui_static / resolved_logo_path
            if icon_path.exists():
                response = FileResponse(str(icon_path))
                response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
                response.headers["Pragma"] = "no-cache"
                response.headers["Expires"] = "0"
                return response
        # Try packaged assets as fallback
        try:
            ui_pkg = importlib.resources.files("topaz_agent_kit.ui.frontend")
            logo_filename = Path(resolved_logo_path).name
            assets_dir = ui_pkg / "assets"
            if assets_dir.is_dir():
                logo_path = assets_dir / logo_filename
                if logo_path.is_file():
                    content = logo_path.read_bytes()
                    response = Response(content=content, media_type="image/png")
                    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
                    response.headers["Pragma"] = "no-cache"
                    response.headers["Expires"] = "0"
                    return response
        except Exception:
            pass
        # Return empty response if no icon found
        return Response(status_code=204)

    @app.get("/apple-touch-icon-precomposed.png")
    async def apple_touch_icon_precomposed():
        # Same as above for precomposed variant
        use_ui_static = Path(project_dir) / "ui" / "static"
        if use_ui_static.exists():
            icon_path = use_ui_static / resolved_logo_path
            if icon_path.exists():
                response = FileResponse(str(icon_path))
                response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
                response.headers["Pragma"] = "no-cache"
                response.headers["Expires"] = "0"
                return response
        return Response(status_code=204)
    
    # Explicit route for static assets favicon to ensure proper cache headers
    # Use dynamic path based on manifest logo - support both manifest logo and default
    # Note: Cannot use f-string in route decorator, so we use a path parameter and validate it
    @app.get("/static/{logo_path:path}")
    async def static_favicon(logo_path: str):
        """Serve favicon from static assets with proper cache headers"""
        # Only serve the resolved logo path, reject other paths for security
        if logo_path != resolved_logo_path:
            return Response(status_code=404)
        
        use_ui_static = Path(project_dir) / "ui" / "static"
        if use_ui_static.exists():
            icon_path = use_ui_static / resolved_logo_path
            if icon_path.exists():
                logger.debug("Serving static favicon from: {}", icon_path)
                response = FileResponse(str(icon_path), media_type="image/png")
                response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
                response.headers["Pragma"] = "no-cache"
                response.headers["Expires"] = "0"
                return response
        # Try packaged assets as fallback
        try:
            ui_pkg = importlib.resources.files("topaz_agent_kit.ui.frontend")
            logo_filename = Path(resolved_logo_path).name
            assets_dir = ui_pkg / "assets"
            if assets_dir.is_dir():
                logo_path = assets_dir / logo_filename
                if logo_path.is_file():
                    logger.debug("Serving static favicon from packaged assets: {}", logo_path)
                    content = logo_path.read_bytes()
                    response = Response(content=content, media_type="image/png")
                    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
                    response.headers["Pragma"] = "no-cache"
                    response.headers["Expires"] = "0"
                    return response
        except Exception as e:
            logger.debug("Failed to load packaged static favicon: {}", e)
        logger.warning("Static favicon not found at /static/{}", resolved_logo_path)
        return Response(status_code=404)
    
    # Backward compatibility: also serve the old hardcoded path
    # This ensures old references to /static/assets/topaz-logo.png still work
    if resolved_logo_path != "assets/topaz-logo.png":
        @app.get("/static/assets/topaz-logo.png")
        async def static_favicon_legacy():
            """Legacy route for backward compatibility - redirects to manifest logo"""
            # Try to serve the manifest logo instead
            use_ui_static = Path(project_dir) / "ui" / "static"
            if use_ui_static.exists():
                icon_path = use_ui_static / resolved_logo_path
                if icon_path.exists():
                    logger.debug("Serving legacy favicon route with manifest logo: {}", icon_path)
                    response = FileResponse(str(icon_path), media_type="image/png")
                    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
                    response.headers["Pragma"] = "no-cache"
                    response.headers["Expires"] = "0"
                    return response
            return Response(status_code=404)

    @app.post("/upload")
    async def upload_file(
        file: List[UploadFile] = File(default=[]),
        session_id: str = Form(None),
        app_session_id: str = Form(None),
        message: str = Form(""),
        upload_intent: str = Form("session")  # "session", "rag", or "app_session"
    ) -> JSONResponse:
        """Handle file upload with proper AG-UI events
        
        Supports:
        - Pipeline sessions: session_id + upload_intent="session"
        - App sessions: app_session_id + upload_intent="app_session"
        - RAG ingestion: session_id + upload_intent="rag"
        """
        nonlocal current_session_id
        
        # Validate files
        if not file or len(file) == 0:
            return JSONResponse({"error": "No files provided"}, status_code=400)
        
        logger.info("File upload endpoint called: {} files, intent: {}, session_id: {}, app_session_id: {}", 
                   len(file), upload_intent, session_id, app_session_id)
        
        # Validate upload_intent
        if upload_intent not in ["session", "rag", "app_session"]:
            return JSONResponse({"error": "Invalid upload_intent. Must be 'session', 'rag', or 'app_session'"}, status_code=400)
        
        # Validate session/app_session based on intent
        if upload_intent == "app_session":
            if not app_session_id:
                return JSONResponse({"error": "app_session_id required for app_session upload_intent"}, status_code=400)
        elif upload_intent in ["session", "rag"]:
            if not session_id:
                return JSONResponse({"error": "session_id required for session/rag upload_intent"}, status_code=400)
        
        # Validate all files have filenames
        for f in file:
            if not f.filename:
                return JSONResponse({"error": f"File {file.index(f)} has no filename"}, status_code=400)
        
        try:
            # Handle session/app_session ID based on upload_intent
            if upload_intent == "app_session":
                # Validate app session exists
                _, _, _, _, _, app_store = get_shared_services()
                app_session = app_store.get_session(app_session_id)
                if not app_session:
                    return JSONResponse({"error": "unknown_app_session_id"}, status_code=404)
            else:
                # Handle pipeline session ID
                try:
                    # Validate session exists
                    if not orchestrator.get_session(session_id):
                        return JSONResponse({"error": "unknown_session_id"}, status_code=404)
                    current_session_id = int(session_id)
                except ValueError:
                    return JSONResponse({"error": "Invalid session_id format"}, status_code=400)
            
            # Use shared services
            file_storage, chroma_client, chat_storage, session_manager, db_manager, app_store = get_shared_services()
            
            # Process multiple files
            temp_file_paths = []
            original_filenames = []
            stored_files = []
            
            for f in file:
                # Get file content
                file_content = await f.read()
                
                # Determine file type from filename
                file_ext = Path(f.filename).suffix.lower().lstrip('.') if f.filename else 'unknown'
                
                if upload_intent == "session":
                    # Pipeline session upload: store in user_files/{session_id}/
                    storage_result = file_storage.store_file(
                        file_content=file_content,
                        filename=f.filename,
                        file_type=file_ext,
                        storage_type="session",
                        session_id=session_id
                    )
                    
                    logger.info("File stored for session: {} -> {}", f.filename, storage_result['file_id'])
                    
                    # For session uploads, we don't create temp files - just return the paths
                    stored_files.append({
                        "file_id": storage_result['file_id'],
                        "path": storage_result['path'],
                        "filename": f.filename
                    })
                    
                elif upload_intent == "app_session":
                    # App session upload: store in user_files/app_sessions/{app_session_id}/
                    storage_result = file_storage.store_file(
                        file_content=file_content,
                        filename=f.filename,
                        file_type=file_ext,
                        storage_type="app_session",
                        app_session_id=app_session_id
                    )
                    
                    logger.info("File stored for app session: {} -> {}", f.filename, storage_result['file_id'])
                    
                    # For app session uploads, return file paths (no processing)
                    stored_files.append({
                        "file_id": storage_result['file_id'],
                        "path": storage_result['path'],
                        "filename": f.filename
                    })
                    
                else:
                    # RAG upload: store in rag_files/ and create temp files for processing
                    storage_result = file_storage.store_file(
                        file_content=file_content,
                        filename=f.filename,
                        file_type=file_ext,
                        storage_type="rag"
                    )
                    
                    logger.info("File stored for RAG: {} -> {}", f.filename, storage_result['file_id'])
                    stored_files.append(storage_result)
                    
                    # Create temporary file for orchestrator to process
                    import tempfile
                    import os
                    
                    with tempfile.NamedTemporaryFile(delete=False, suffix=f"_{f.filename}") as temp_file:
                        temp_file.write(file_content)
                        temp_file_path = temp_file.name
                    
                    temp_file_paths.append(temp_file_path)
                    original_filenames.append(f.filename)
            
            if upload_intent == "session":
                # Pipeline session upload: validate message is provided
                if not message.strip():
                    return JSONResponse({
                        "error": "Message required for session uploads",
                        "upload_intent": "session"
                    }, status_code=400)
                
                # Return file paths for session upload (no processing)
                return JSONResponse({
                    "success": True,
                    "upload_intent": "session",
                    "message": "Files uploaded for session attachment",
                    "session_id": current_session_id,
                    "files": stored_files,
                    "user_message": message.strip()
                })
            
            elif upload_intent == "app_session":
                # App session upload: return file paths (no processing, no message required)
                return JSONResponse({
                    "success": True,
                    "upload_intent": "app_session",
                    "message": "Files uploaded for app session",
                    "app_session_id": app_session_id,
                    "files": stored_files
                })
            
            else:
                # RAG upload: process with full ingestion
                try:
                    # Create session-specific run counter (same pattern as /agui/turn)
                    def get_next_run_counter():
                        current_count = session_run_counters.get(current_session_id, 0)
                        session_run_counters[current_session_id] = current_count + 1
                        return current_count
                    
                    # Ensure SSE queue exists for this session (same queue as /agui/turn)
                    q = agui_session_queues.setdefault(current_session_id, asyncio.Queue())
                    
                    # Create emitter for file upload events (same pattern as /agui/turn)
                    captured_events = []
                    
                    def emit_and_capture(evt: Dict[str, Any]) -> None:
                        try:
                            # Capture the event for pipeline_events (same pattern as CLI)
                            captured_events.append(evt)
                            
                            # Get or create AGUIService for this session (int key)
                            agui_service = agui_services.setdefault(current_session_id, AGUIService())
                            
                            # Convert event if needed (handles internal events like HITL)
                            agui_events = agui_service.convert_event(_json_safe(evt))
                            
                            # Enqueue each converted event to the SSE queue
                            for agui_evt in agui_events:
                                payload = f"data: {json.dumps(agui_evt)}\n\n"
                                q.put_nowait(payload)
                        except Exception as e:
                            logger.warning("AGUI emit failed: {}", e)
                    
                    # Use session-scoped emitter to maintain counters across turns (int key, same as /agui/turn)
                    emitter = agui_emitters.setdefault(current_session_id, AGUIEventEmitter(emit_and_capture, get_next_run_counter))
                    emitter._captured_events = captured_events
                    
                    # Process RAG files through assistant
                    assistant = agui_assistants.setdefault(
                        current_session_id,
                        Assistant(cfg, project_dir=project_dir, emitter=emitter, session_id=str(current_session_id)),
                    )
                    if current_session_id not in initialized_assistants:
                        await assistant.initialize()
                        initialized_assistants.add(current_session_id)
                    
                    result = await assistant.execute_assistant_agent(
                        user_input=message if message.strip() else "Process these files",
                        file_paths=temp_file_paths,
                        original_filenames=original_filenames,
                        upload_intent="rag",
                        mode="fastapi"
                    )
                    
                    # Handle AssistantResponse Pydantic model or fallback to dict
                    if isinstance(result, AssistantResponse):
                        success = result.success
                        assistant_response = result.assistant_response or ""
                        # Note: AssistantResponse doesn't have 'summary' field, use assistant_response
                        final_summary = assistant_response if assistant_response else "Unknown result"
                    elif isinstance(result, dict):
                        # Fallback for backward compatibility
                        success = result.get("success", False)
                        assistant_response = result.get("assistant_response", "")
                        summary = result.get("summary", "Unknown result")
                        final_summary = assistant_response if assistant_response else summary
                    else:
                        success = False
                        final_summary = "Unknown result"
                    
                    if success:
                        return JSONResponse({
                            "success": True,
                            "upload_intent": "rag",
                            "summary": final_summary,
                            "session_id": current_session_id,
                            "message": "File uploaded and processed successfully",
                            "files": stored_files
                        })
                    else:
                        return JSONResponse({
                            "success": False,
                            "upload_intent": "rag",
                            "error": final_summary,
                            "session_id": current_session_id
                        }, status_code=400)
                        
                finally:
                    # Clean up temporary files
                    for temp_file_path in temp_file_paths:
                        try:
                            os.unlink(temp_file_path)
                        except Exception:
                            pass
            
        except FileUploadError as e:
            logger.error("File upload validation failed: {}", e)
            return JSONResponse({"error": str(e)}, status_code=400)
        except Exception as e:
            logger.error("File upload failed: {}", e)
            return JSONResponse({"error": f"Upload failed: {str(e)}"}, status_code=500)

    @app.get("/api/sessions/{session_id}/files")
    async def list_session_files(session_id: str):
        """List files for a specific session"""
        try:
            # Use shared services
            file_storage, chroma_client, chat_storage, session_manager, db_manager, _ = get_shared_services()
            
            files = file_storage.list_session_files(session_id)
            
            return JSONResponse({
                "session_id": session_id,
                "files": files,
                "count": len(files)
            })
            
        except Exception as e:
            logger.error("Error listing session files for {}: {}", session_id, e)
            return JSONResponse({"error": f"Failed to list session files: {str(e)}"}, status_code=500)
    
    @app.get("/api/sessions/{session_id}/files/{file_id}")
    async def serve_session_file(session_id: str, file_id: str):
        """Serve a session file"""
        try:
            # Use shared services
            file_storage, chroma_client, chat_storage, session_manager, db_manager, _ = get_shared_services()
            
            file_path = file_storage.get_file_path(file_id, session_id)
            if not file_path:
                return JSONResponse({"error": "File not found"}, status_code=404)
            
            file_info = file_storage.get_file_info(file_id)
            if not file_info:
                return JSONResponse({"error": "File info not found"}, status_code=404)
            
            file_content = file_storage.serve_file(file_id)
            if not file_content:
                return JSONResponse({"error": "File content not found"}, status_code=404)
            
            # Determine media type
            file_type = file_info.get("file_type", "").lower()
            media_type_map = {
                "pdf": "application/pdf",
                "txt": "text/plain",
                "doc": "application/msword",
                "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "jpg": "image/jpeg",
                "jpeg": "image/jpeg",
                "png": "image/png",
                "gif": "image/gif",
                "bmp": "image/bmp",
                "tiff": "image/tiff",
                "tif": "image/tiff",
                "webp": "image/webp"
            }
            media_type = media_type_map.get(file_type, "application/octet-stream")
            
            return Response(
                content=file_content,
                media_type=media_type,
                headers={
                    "Content-Disposition": f"inline; filename=\"{file_info['filename']}\"",
                    "Cache-Control": "public, max-age=3600"
                }
            )
            
        except Exception as e:
            logger.error("Error serving session file {} from session {}: {}", file_id, session_id, e)
            return JSONResponse({"error": f"Failed to serve session file: {str(e)}"}, status_code=500)
    
    @app.get("/api/app/sessions/{app_session_id}/files/{file_id}")
    async def serve_app_session_file(app_session_id: str, file_id: str):
        """Serve an app session file"""
        try:
            # Use shared services
            file_storage, chroma_client, chat_storage, session_manager, db_manager, _ = get_shared_services()
            
            file_path = file_storage.get_file_path(file_id, app_session_id=app_session_id)
            if not file_path:
                return JSONResponse({"error": "File not found"}, status_code=404)
            
            file_info = file_storage.get_file_info(file_id)
            if not file_info:
                return JSONResponse({"error": "File info not found"}, status_code=404)
            
            file_content = file_storage.serve_file(file_id)
            if not file_content:
                return JSONResponse({"error": "File content not found"}, status_code=404)
            
            # Determine media type
            file_type = file_info.get("file_type", "").lower()
            media_type_map = {
                "pdf": "application/pdf",
                "txt": "text/plain",
                "doc": "application/msword",
                "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "jpg": "image/jpeg",
                "jpeg": "image/jpeg",
                "png": "image/png",
                "gif": "image/gif",
                "bmp": "image/bmp",
                "tiff": "image/tiff",
                "tif": "image/tiff",
                "webp": "image/webp",
                "svg": "image/svg+xml"
            }
            media_type = media_type_map.get(file_type, "application/octet-stream")
            
            return Response(
                content=file_content,
                media_type=media_type,
                headers={
                    "Content-Disposition": f"inline; filename=\"{file_info['filename']}\"",
                    "Cache-Control": "public, max-age=3600"
                }
            )
            
        except Exception as e:
            logger.error("Error serving app session file {} from app session {}: {}", file_id, app_session_id, e)
            return JSONResponse({"error": f"Failed to serve app session file: {str(e)}"}, status_code=500)
    
    @app.post("/api/app/sessions/{app_session_id}/export")
    async def export_app_session_document(app_session_id: str, request: Request):
        """Export app session document to a downloadable file"""
        try:
            body = await request.json()
            format = body.get("format", "markdown")
            filename = body.get("filename")
            state_path = body.get("state_path")
            
            # Use shared services
            file_storage, chroma_client, chat_storage, session_manager, db_manager, app_store = get_shared_services()
            
            # Get session state
            session = app_store.get_session(app_session_id)
            if not session:
                return JSONResponse({"success": False, "error": "Session not found"}, status_code=404)
            
            state = session.state
            
            # Extract state at path if specified
            if state_path:
                # Simple path extraction (supports dot notation like "article")
                keys = state_path.split('.')
                export_data = state
                for key in keys:
                    if isinstance(export_data, dict) and key in export_data:
                        export_data = export_data[key]
                    else:
                        export_data = {}
                        break
            else:
                export_data = state
            
            # Generate content based on format
            content_bytes = None
            file_extension = ""
            
            if format.lower() == "markdown":
                content = _generate_markdown(export_data)
                content_bytes = content.encode('utf-8')
                file_extension = "md"
            elif format.lower() == "html":
                content = _generate_html(export_data)
                content_bytes = content.encode('utf-8')
                file_extension = "html"
            elif format.lower() == "txt":
                content = _generate_text(export_data)
                content_bytes = content.encode('utf-8')
                file_extension = "txt"
            elif format.lower() == "pdf":
                # Generate PDF from HTML using WeasyPrint
                html_content = _generate_html(export_data)
                try:
                    import weasyprint
                    pdf_bytes = weasyprint.HTML(string=html_content).write_pdf()
                    content_bytes = pdf_bytes
                    file_extension = "pdf"
                except ImportError:
                    return JSONResponse({
                        "success": False,
                        "error": "PDF export requires weasyprint. Install with: pip install weasyprint"
                    }, status_code=400)
                except Exception as e:
                    logger.error("PDF generation failed: {}", e)
                    return JSONResponse({
                        "success": False,
                        "error": f"PDF generation failed: {str(e)}"
                    }, status_code=500)
            elif format.lower() == "docx":
                # Generate DOCX using python-docx
                try:
                    from docx import Document
                    from io import BytesIO
                    
                    doc = Document()
                    _generate_docx(export_data, doc)
                    
                    # Save to bytes
                    doc_io = BytesIO()
                    doc.save(doc_io)
                    content_bytes = doc_io.getvalue()
                    doc_io.close()
                    file_extension = "docx"
                except ImportError:
                    return JSONResponse({
                        "success": False,
                        "error": "DOCX export requires python-docx. Install with: pip install python-docx"
                    }, status_code=400)
                except Exception as e:
                    logger.error("DOCX generation failed: {}", e)
                    return JSONResponse({
                        "success": False,
                        "error": f"DOCX generation failed: {str(e)}"
                    }, status_code=500)
            elif format.lower() == "pptx":
                # Generate PPTX using python-pptx
                try:
                    from pptx import Presentation
                    from io import BytesIO
                    
                    prs = Presentation()
                    _generate_pptx(export_data, prs)
                    
                    # Save to bytes
                    prs_io = BytesIO()
                    prs.save(prs_io)
                    content_bytes = prs_io.getvalue()
                    prs_io.close()
                    file_extension = "pptx"
                except ImportError:
                    return JSONResponse({
                        "success": False,
                        "error": "PPTX export requires python-pptx. Install with: pip install python-pptx"
                    }, status_code=400)
                except Exception as e:
                    logger.error("PPTX generation failed: {}", e)
                    return JSONResponse({
                        "success": False,
                        "error": f"PPTX generation failed: {str(e)}"
                    }, status_code=500)
            elif format.lower() == "xlsx":
                # Generate XLSX using openpyxl
                try:
                    from openpyxl import Workbook
                    from io import BytesIO
                    
                    wb = Workbook()
                    _generate_xlsx(export_data, wb)
                    
                    # Save to bytes
                    xlsx_io = BytesIO()
                    wb.save(xlsx_io)
                    content_bytes = xlsx_io.getvalue()
                    xlsx_io.close()
                    file_extension = "xlsx"
                except ImportError:
                    return JSONResponse({
                        "success": False,
                        "error": "XLSX export requires openpyxl. Install with: pip install openpyxl"
                    }, status_code=400)
                except Exception as e:
                    logger.error("XLSX generation failed: {}", e)
                    return JSONResponse({
                        "success": False,
                        "error": f"XLSX generation failed: {str(e)}"
                    }, status_code=500)
            else:
                return JSONResponse({
                    "success": False,
                    "error": f"Unsupported format: {format}. Supported: markdown, html, pdf, docx, pptx, xlsx, txt"
                }, status_code=400)
            
            # Generate filename if not provided
            if not filename:
                # Try to extract title from state
                title = None
                if isinstance(export_data, dict):
                    for key in ['title', 'name']:
                        if key in export_data:
                            title = str(export_data[key])
                            break
                
                if title:
                    import re
                    filename = re.sub(r'[^\w\s-]', '', title).strip()
                    filename = re.sub(r'[-\s]+', '-', filename)
                    filename = filename[:50]
                else:
                    from datetime import datetime
                    filename = f"document-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
            
            # Ensure filename has extension
            if not filename.endswith(f".{file_extension}"):
                filename = f"{filename}.{file_extension}"
            storage_info = file_storage.store_file(
                file_content=content_bytes,
                filename=filename,
                file_type=file_extension,
                storage_type="app_session",
                app_session_id=app_session_id,
            )
            
            file_id = storage_info.get("file_id")
            
            logger.info("Exported document: format={}, filename={}, file_id={}", 
                       format, filename, file_id)
            
            return JSONResponse({
                "success": True,
                "file_id": file_id,
                "filename": filename,
                "format": format,
            })
            
        except Exception as e:
            logger.error("Error exporting app session document: {}", e, exc_info=True)
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    # Helper functions for document export
    def _generate_markdown(data: Any) -> str:
        """Generate markdown content from state data"""
        if isinstance(data, dict):
            lines = []
            for key, value in data.items():
                if isinstance(value, dict):
                    lines.append(f"## {key.replace('_', ' ').title()}")
                    lines.append(_generate_markdown(value))
                elif isinstance(value, list):
                    lines.append(f"### {key.replace('_', ' ').title()}")
                    for item in value:
                        if isinstance(item, dict):
                            lines.append("- " + ", ".join(f"{k}: {v}" for k, v in item.items()))
                        else:
                            lines.append(f"- {item}")
                elif value:
                    key_formatted = key.replace('_', ' ').title()
                    if isinstance(value, str) and '\n' in value:
                        lines.append(f"### {key_formatted}\n\n{value}\n")
                    else:
                        lines.append(f"**{key_formatted}**: {value}")
            return "\n\n".join(lines)
        elif isinstance(data, list):
            return "\n".join(f"- {item}" for item in data)
        else:
            return str(data)


    def _generate_html(data: Any) -> str:
        """Generate HTML content from state data"""
        markdown_content = _generate_markdown(data)
        import re
        html = markdown_content
        # Headers
        html = re.sub(r'^### (.+)$', r'<h3>\1</h3>', html, flags=re.MULTILINE)
        html = re.sub(r'^## (.+)$', r'<h2>\1</h2>', html, flags=re.MULTILINE)
        # Bold
        html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html)
        # Lists
        html = re.sub(r'^- (.+)$', r'<li>\1</li>', html, flags=re.MULTILINE)
        html = re.sub(r'(<li>.*</li>)', r'<ul>\1</ul>', html, flags=re.DOTALL)
        # Paragraphs
        paragraphs = html.split('\n\n')
        html = '\n'.join(f'<p>{p.strip()}</p>' if p.strip() and not p.strip().startswith('<') else p for p in paragraphs)
        
        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Exported Document</title>
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 800px; margin: 40px auto; padding: 20px; }}
        h2 {{ color: #333; border-bottom: 2px solid #333; padding-bottom: 10px; }}
        h3 {{ color: #666; margin-top: 20px; }}
        ul {{ line-height: 1.6; }}
        p {{ line-height: 1.6; }}
    </style>
</head>
<body>
{html}
</body>
</html>"""
        return html_content


    def _generate_text(data: Any) -> str:
        """Generate plain text content from state data"""
        return _generate_markdown(data)


    def _generate_docx(data: Any, doc: Any) -> None:
        """Generate DOCX document from state data"""
        from docx.shared import Inches, Pt
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        
        if isinstance(data, dict):
            for key, value in data.items():
                key_formatted = key.replace('_', ' ').title()
                
                if isinstance(value, dict):
                    # Add heading for section
                    heading = doc.add_heading(key_formatted, level=1)
                    _generate_docx(value, doc)
                elif isinstance(value, list):
                    # Add heading for list section
                    heading = doc.add_heading(key_formatted, level=2)
                    for item in value:
                        if isinstance(item, dict):
                            # Add paragraph with item details
                            item_text = ", ".join(f"{k}: {v}" for k, v in item.items())
                            doc.add_paragraph(item_text, style='List Bullet')
                        else:
                            doc.add_paragraph(str(item), style='List Bullet')
                elif value:
                    if isinstance(value, str) and '\n' in value:
                        # Multi-line content - add heading and paragraph
                        doc.add_heading(key_formatted, level=2)
                        for line in value.split('\n'):
                            if line.strip():
                                doc.add_paragraph(line.strip())
                    else:
                        # Simple key-value
                        p = doc.add_paragraph()
                        run = p.add_run(f"{key_formatted}: ")
                        run.bold = True
                        p.add_run(str(value))
        elif isinstance(data, list):
            for item in data:
                doc.add_paragraph(str(item), style='List Bullet')


    def _generate_pptx(data: Any, prs: Any) -> None:
        """Generate PPTX presentation from state data"""
        from pptx.util import Inches, Pt
        
        # Create title slide
        title_slide_layout = prs.slide_layouts[0]
        slide = prs.slides.add_slide(title_slide_layout)
        title = slide.shapes.title
        subtitle = slide.placeholders[1]
        
        # Extract title from data
        doc_title = "Exported Document"
        if isinstance(data, dict):
            for key in ['title', 'name']:
                if key in data:
                    doc_title = str(data[key])
                    break
        
        title.text = doc_title
        subtitle.text = "Generated Document"
        
        # Create content slide
        bullet_slide_layout = prs.slide_layouts[1]
        slide = prs.slides.add_slide(bullet_slide_layout)
        shapes = slide.shapes
        title_shape = shapes.title
        body_shape = shapes.placeholders[1]
        
        title_shape.text = "Content"
        tf = body_shape.text_frame
        tf.text = "Document Details"
        
        # Add content as bullet points
        if isinstance(data, dict):
            for key, value in data.items():
                key_formatted = key.replace('_', ' ').title()
                if isinstance(value, dict):
                    p = tf.add_paragraph()
                    p.text = f"{key_formatted}:"
                    p.level = 0
                    for k, v in value.items():
                        p = tf.add_paragraph()
                        p.text = f"  {k}: {v}"
                        p.level = 1
                elif isinstance(value, list):
                    p = tf.add_paragraph()
                    p.text = f"{key_formatted}:"
                    p.level = 0
                    for item in value:
                        p = tf.add_paragraph()
                        p.text = f"  {item}"
                        p.level = 1
                elif value:
                    p = tf.add_paragraph()
                    p.text = f"{key_formatted}: {value}"
                    p.level = 0


    def _generate_xlsx(data: Any, wb: Any) -> None:
        """Generate XLSX spreadsheet from state data"""
        from openpyxl.styles import Font, Alignment
        
        ws = wb.active
        ws.title = "Document Data"
        
        row = 1
        
        if isinstance(data, dict):
            # Write headers
            ws['A1'] = "Field"
            ws['B1'] = "Value"
            ws['A1'].font = Font(bold=True)
            ws['B1'].font = Font(bold=True)
            row = 2
            
            for key, value in data.items():
                key_formatted = key.replace('_', ' ').title()
                
                if isinstance(value, dict):
                    ws[f'A{row}'] = key_formatted
                    ws[f'A{row}'].font = Font(bold=True)
                    row += 1
                    for k, v in value.items():
                        ws[f'A{row}'] = f"  {k}"
                        ws[f'B{row}'] = str(v)
                        row += 1
                elif isinstance(value, list):
                    ws[f'A{row}'] = key_formatted
                    ws[f'A{row}'].font = Font(bold=True)
                    row += 1
                    for idx, item in enumerate(value, start=1):
                        if isinstance(item, dict):
                            ws[f'A{row}'] = f"  Item {idx}"
                            col = 2
                            for k, v in item.items():
                                ws.cell(row=row, column=col, value=f"{k}: {v}")
                                col += 1
                        else:
                            ws[f'A{row}'] = f"  Item {idx}"
                            ws[f'B{row}'] = str(item)
                        row += 1
                elif value:
                    ws[f'A{row}'] = key_formatted
                    ws[f'B{row}'] = str(value)
                    row += 1
        
        # Auto-adjust column widths
        ws.column_dimensions['A'].width = 30
        ws.column_dimensions['B'].width = 50

    @app.delete("/api/sessions/{session_id}/files/{file_id}")
    async def delete_session_file(session_id: str, file_id: str):
        """Delete a session file"""
        try:
            # Use shared services
            file_storage, chroma_client, chat_storage, session_manager, db_manager, _ = get_shared_services()
            
            success = file_storage.delete_session_file(file_id, session_id)
            
            if success:
                return JSONResponse({
                    "success": True,
                    "message": f"File {file_id} deleted from session {session_id}"
                })
            else:
                return JSONResponse({"error": "File not found or could not be deleted"}, status_code=404)
            
        except Exception as e:
            logger.error("Error deleting session file {} from session {}: {}", file_id, session_id, e)
            return JSONResponse({"error": f"Failed to delete session file: {str(e)}"}, status_code=500)

    @app.get("/api/reports/view")
    async def view_report(path: str):
        """Serve raw markdown report file"""
        try:
            # URL decode the path (FastAPI should do this automatically, but ensure it's decoded)
            from urllib.parse import unquote
            original_path = path
            path = unquote(path)
            
            # Security: Prevent directory traversal
            if '..' in path or path.startswith('/'):
                logger.warning("Invalid file path (security check): {}", path)
                return JSONResponse({"error": "Invalid file path"}, status_code=400)
            
            # Normalize the path - remove leading slashes
            path = path.lstrip('/')
            
            # Build the full report path
            report_path = Path(project_dir) / "data" / path
            
            logger.debug("Serving report - original: {}, decoded: {}, normalized: {}, resolved: {}", 
                        original_path, unquote(original_path), path, report_path)
            
            if not report_path.exists():
                logger.warning("Report file not found: {} (original path: {}, decoded: {})", 
                              report_path, original_path, path)
                # List available files in the reports directory for debugging
                reports_dir = Path(project_dir) / "data" / "tci" / "reports"
                if reports_dir.exists():
                    available_files = [f.name for f in reports_dir.glob("*.md")]
                    if available_files:
                        logger.info("Available report files in {}: {}", reports_dir, available_files)
                    else:
                        logger.warning("Reports directory exists but is empty: {}", reports_dir)
                else:
                    logger.warning("Reports directory does not exist: {}", reports_dir)
                return JSONResponse({"error": "Report file not found"}, status_code=404)
            
            # Ensure the file is within the data directory
            try:
                report_path.resolve().relative_to(Path(project_dir) / "data")
            except ValueError:
                return JSONResponse({"error": "Invalid file path"}, status_code=400)
            
            # Only allow .md files
            if not path.endswith('.md'):
                return JSONResponse({"error": "Only markdown files are supported"}, status_code=400)
            
            # Read and return markdown content
            return FileResponse(
                path=str(report_path),
                media_type="text/markdown",
                headers={
                    "Cache-Control": "public, max-age=3600"
                }
            )
        except Exception as e:
            logger.error("Error serving report {}: {}", path, e)
            return JSONResponse({"error": f"Failed to serve report: {str(e)}"}, status_code=500)

    @app.get("/api/readme")
    async def get_readme():
        """Serve README.md from project root or repository root"""
        try:
            # First try project directory
            readme_path = Path(project_dir) / "README.md"
            if not readme_path.exists():
                # Try repository root (go up from project_dir to find README.md)
                # project_dir is typically like .../projects/ensemble
                # So we go up two levels to get to repository root
                repo_root = Path(project_dir).parent.parent
                readme_path = repo_root / "README.md"
            
            if readme_path.exists():
                with open(readme_path, "r", encoding="utf-8") as f:
                    content = f.read()
                return Response(
                    content=content,
                    media_type="text/markdown",
                    headers={
                        "Cache-Control": "public, max-age=3600"
                    }
                )
            else:
                return JSONResponse({"error": "README.md not found in project root or repository root"}, status_code=404)
        except Exception as e:
            logger.error("Error serving README: {}", e)
            return JSONResponse({"error": f"Failed to serve README: {str(e)}"}, status_code=500)


    @app.get("/api/documents")
    async def list_documents():
        """List all documents with combined metadata from ChromaDB and chat.db"""
        try:
            
            
            # Use shared services (initialized once, reused across requests)
            file_storage, chroma_client, chat_storage, session_manager, db_manager, _ = get_shared_services()
            
            # Get documents from ChromaDB
            documents = []
            try:
                collections = chroma_client.list_collections()
                
                # Process both documents and images collections
                collection_names = ["documents", "images"]
                for collection_name in collection_names:
                    if any(c.name == collection_name for c in collections):
                        collection = chroma_client.get_collection(collection_name)
                        all_docs = collection.get()
                        
                        # Group by filename to get unique documents
                        doc_groups = {}
                        for i, metadata in enumerate(all_docs.get("metadatas", [])):
                            filename = metadata.get("file_name", "unknown")
                            if filename not in doc_groups:
                                doc_groups[filename] = {
                                    "filename": filename,
                                    "file_size": metadata.get("file_size", 0),
                                    "upload_date": metadata.get("upload_date", ""),
                                    "file_hash": metadata.get("file_hash", ""),
                                    "chunks_count": 0,
                                    "collection_type": collection_name
                                }
                            doc_groups[filename]["chunks_count"] += 1
                        
                        # Get analysis results from chat.db
                        for filename, doc_info in doc_groups.items():
                            # Get analysis results
                            analysis_results = db_manager.get_available_content_by_filename(filename)
                            
                            # Get file storage info
                            stored_files = file_storage.list_files()
                            file_storage_info = None
                            for stored_file in stored_files:
                                if stored_file["filename"] == filename:
                                    file_storage_info = stored_file
                                    break
                            
                            # Combine all information
                            document = {
                                "id": file_storage_info["file_id"] if file_storage_info else f"unknown_{filename}",
                                "name": filename,
                                "type": file_storage_info["file_type"] if file_storage_info else "unknown",
                                "size": doc_info["file_size"],
                                "uploadDate": doc_info["upload_date"],
                                "fileHash": doc_info["file_hash"],
                                "chunksCount": doc_info["chunks_count"],
                                "hasStorage": file_storage_info is not None,
                                "summary": analysis_results.get("summary") if analysis_results else None,
                                "topics": analysis_results.get("topics", []) if analysis_results else [],
                                "exampleQuestions": analysis_results.get("example_questions", []) if analysis_results else []
                            }
                            documents.append(document)
                    
                    # Sort by upload date (newest first)
                    documents.sort(key=lambda x: x["uploadDate"], reverse=True)
                    
            except Exception as e:
                logger.warning("Error accessing ChromaDB: {}", e)
            
            return JSONResponse({
                "documents": documents,
                "total": len(documents)
            })
            
        except Exception as e:
            logger.error("Error listing documents: {}", e)
            return JSONResponse({"error": f"Failed to list documents: {str(e)}"}, status_code=500)
    
    @app.get("/api/documents/{document_id}/file")
    async def serve_document_file(document_id: str):
        """Serve original file for preview"""
        try:
            # Get files path from orchestrator config
            rag_files_path = orchestrator.validated_config.rag_files_path if orchestrator.validated_config else "./data/rag_files"
            user_files_path = orchestrator.validated_config.user_files_path if orchestrator.validated_config else "./data/user_files"
            
            if not Path(rag_files_path).is_absolute():
                rag_files_path = str(Path(project_dir) / rag_files_path)
            if not Path(user_files_path).is_absolute():
                user_files_path = str(Path(project_dir) / user_files_path)
            
            file_storage = FileStorageService(rag_files_path, user_files_path)
            
            # First try to serve by document_id directly
            file_content = file_storage.serve_file(document_id)
            
            # If not found, try to find by document name
            if file_content is None:
                # List all files and find by name
                files = file_storage.list_files()
                for file_info in files:
                    if file_info["filename"] == document_id:
                        file_content = file_storage.serve_file(file_info["id"])
                        break
            
            if file_content is None:
                return JSONResponse({"error": "File not found"}, status_code=404)
            
            # Get file info for content type
            # Use the actual file_id that was found
            actual_file_id = document_id
            if file_content is not None:
                # If we found the file by name, get the actual file_id
                files = file_storage.list_files()
                for file_info in files:
                    if file_info["filename"] == document_id:
                        actual_file_id = file_info["id"]
                        break
            
            # Get file info using the correct file_id
            file_info = file_storage.get_file_info(actual_file_id)
            if not file_info:
                # If get_file_info fails, try to build file info from the file path
                files = file_storage.list_files()
                for file_info_item in files:
                    if file_info_item["filename"] == document_id:
                        file_info = file_info_item
                        break
                
                if not file_info:
                    return JSONResponse({"error": "File info not found"}, status_code=404)
            
            # Determine content type
            content_type_map = {
                'pdf': 'application/pdf',
                'txt': 'text/plain',
                'md': 'text/markdown',
                'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                'csv': 'text/csv',
                'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'json': 'application/json',
                'html': 'text/html',
                'jpg': 'image/jpeg',
                'jpeg': 'image/jpeg',
                'png': 'image/png',
                'gif': 'image/gif',
                'bmp': 'image/bmp',
                'tiff': 'image/tiff',
                'tif': 'image/tiff',
                'webp': 'image/webp'
            }
            
            content_type = content_type_map.get(file_info["file_type"], "application/octet-stream")
            
            return Response(
                content=file_content,
                media_type=content_type,
                headers={
                    "Content-Disposition": f"inline; filename=\"{file_info['filename']}\"",
                    "Cache-Control": "public, max-age=3600"
                }
            )
            
        except Exception as e:
            logger.error("Error serving file {}: {}", document_id, e)
            return JSONResponse({"error": f"Failed to serve file: {str(e)}"}, status_code=500)
    
    @app.get("/api/documents/{document_id}/highlighted")
    async def serve_highlighted_document(
        document_id: str,
        text: str,
        page: int = None,
        color: str = "yellow"
    ):
        """
        Serve a PDF document with highlighted text using PyMuPDF
        
        Args:
            document_id: Document ID
            text: Text to highlight
            page: Specific page number (optional)
            color: Highlight color (yellow, green, red, blue)
        """
        try:
            logger.debug("Serving highlighted PDF for document {}", document_id)
            logger.debug("   Text to highlight: {}", text)
            logger.debug("   Page: {}", page)
            logger.debug("   Color: {}", color)
            
            # Use shared services (initialized once, reused across requests)
            file_storage, chroma_client, chat_storage, session_manager, db_manager, _ = get_shared_services()
            
            # Get file info from file storage
            file_info = file_storage.get_file_info(document_id)
            if not file_info:
                return JSONResponse({"error": "Document not found"}, status_code=404)
            
            # Check if it's a PDF
            if file_info["file_type"] != "pdf":
                return JSONResponse({"error": "Highlighting only supported for PDF files"}, status_code=400)
            
            # Get original file content
            file_content = file_storage.serve_file(document_id)
            if not file_content:
                return JSONResponse({"error": "File content not found"}, status_code=404)
            
            # Check cache first
            logger.debug("🔍 Checking cache for document {} with text '{}' and page {}", document_id, text, page)
            cached_content = pdf_highlighter.get_cached_highlighted_pdf(
                document_id, text, page
            )
            
            if cached_content:
                logger.debug("✅ CACHE HIT: Serving cached highlighted PDF for document {}", document_id)
                highlighted_content = cached_content
            else:
                logger.debug("❌ CACHE MISS: Generating new highlighted PDF for document {} with text '{}'", document_id, text)
                # Convert color string to RGB tuple
                color_map = {
                    "yellow": (1, 1, 0),
                    "green": (0, 1, 0),
                    "red": (1, 0, 0),
                    "blue": (0, 0, 1),
                    "orange": (1, 0.5, 0),
                    "purple": (0.5, 0, 1),
                    "pink": (1, 0.5, 0.8),
                    "cyan": (0, 1, 1)
                }
                highlight_color = color_map.get(color.lower(), (1, 1, 0))  # Default to yellow
                
                # Generate highlighted PDF
                logger.debug("Generating highlighted PDF for document {} with text '{}'", document_id, text)
                highlighted_content = pdf_highlighter.highlight_pdf(
                    file_content, text, highlight_color, page
                )
                
                if not highlighted_content:
                    return JSONResponse({"error": "Failed to highlight PDF"}, status_code=500)
                
                # Cache the result
                pdf_highlighter.cache_highlighted_pdf(
                    document_id, text, highlighted_content, page
                )
            
            # Return highlighted PDF
            return Response(
                content=highlighted_content,
                media_type="application/pdf",
                headers={
                    "Content-Disposition": f"inline; filename=\"{file_info['filename']}_highlighted.pdf\"",
                    "Cache-Control": "public, max-age=3600"
                }
            )
            
        except Exception as e:
            logger.error("Error serving highlighted file {}: {}", document_id, e)
            return JSONResponse({"error": f"Failed to serve highlighted file: {str(e)}"}, status_code=500)
    
    @app.delete("/api/documents/{document_id}")
    async def delete_document(document_id: str):
        """Delete document from all storage locations"""
        try:
            # Initialize services
            # Get files path from orchestrator config
            rag_files_path = orchestrator.validated_config.rag_files_path if orchestrator.validated_config else "./data/rag_files"
            user_files_path = orchestrator.validated_config.user_files_path if orchestrator.validated_config else "./data/user_files"
            
            if not Path(rag_files_path).is_absolute():
                rag_files_path = str(Path(project_dir) / rag_files_path)
            if not Path(user_files_path).is_absolute():
                user_files_path = str(Path(project_dir) / user_files_path)
            
            file_storage = FileStorageService(rag_files_path, user_files_path)
            
            # Get file info first
            file_info = file_storage.get_file_info(document_id)
            filename = None
            actual_file_id = None
            
            if file_info:
                # Document exists in file storage
                filename = file_info["filename"]
                actual_file_id = document_id
            else:
                # Document might not exist in file storage but could exist in ChromaDB/chat.db
                # Check if document_id starts with "unknown_" and extract filename
                if document_id.startswith("unknown_"):
                    filename = document_id[8:]  # Remove "unknown_" prefix
                    # Try to find the actual file ID by searching for files with this filename
                    try:
                        stored_files = file_storage.list_files()
                        for file_data in stored_files:
                            if file_data["filename"] == filename:
                                actual_file_id = file_data["id"]
                                break
                    except Exception as e:
                        logger.warning("Failed to search for file by filename: {}", e)
                else:
                    return JSONResponse({"error": "Document not found"}, status_code=404)
            deletion_results = {
                "file_storage": False,
                "chromadb": False,
                "chat_db": False
            }
            
            # 1. Delete from file storage
            try:
                if actual_file_id:
                    deletion_results["file_storage"] = file_storage.delete_file(actual_file_id)
                    logger.info("Deleted file from storage: {} (ID: {})", filename, actual_file_id)
                else:
                    # File doesn't exist in storage, mark as already deleted
                    deletion_results["file_storage"] = True
                    logger.info("File not found in storage, considering it already deleted: {}", filename)
            except Exception as e:
                logger.warning("Failed to delete from file storage: {}", e)
            
            # 2. Delete from ChromaDB
            try:
                chromadb_path = orchestrator.validated_config.chromadb_path if orchestrator.validated_config else "./data/chroma_db"
                if not Path(chromadb_path).is_absolute():
                    chromadb_path = str(Path(project_dir) / chromadb_path)
                
                chroma_client = PersistentClient(path=chromadb_path)
                collections = chroma_client.list_collections()
                
                # Delete from both documents and images collections
                collection_names = ["documents", "images"]
                chromadb_deleted = False
                
                for collection_name in collection_names:
                    if any(c.name == collection_name for c in collections):
                        collection = chroma_client.get_collection(collection_name)
                        # Delete by file_name metadata
                        result = collection.delete(where={"file_name": filename})
                        if result:
                            chromadb_deleted = True
                            logger.info("Deleted from ChromaDB collection '{}': {}", collection_name, filename)
                
                deletion_results["chromadb"] = chromadb_deleted
                    
            except Exception as e:
                logger.warning("Failed to delete from ChromaDB: {}", e)
            
            # 3. Delete from chat.db
            try:
                chatdb_path = orchestrator.validated_config.chatdb_path if orchestrator.validated_config else "./data/chat.db"
                if not Path(chatdb_path).is_absolute():
                    chatdb_path = str(Path(project_dir) / chatdb_path)
                
                chat_storage = ChatStorage(chatdb_path)
                session_manager = SessionManager(chat_storage)
                db_manager = DatabaseManager(chat_storage, session_manager)
                
                # Delete available content by filename
                success = db_manager.delete_available_content_by_filename(filename)
                deletion_results["chat_db"] = success
                
            except Exception as e:
                logger.warning("Failed to delete from chat.db: {}", e)
            
            # Check if any deletion succeeded
            if any(deletion_results.values()):
                return JSONResponse({
                    "success": True,
                    "message": f"Document '{filename}' deleted",
                    "deletion_results": deletion_results
                })
            else:
                return JSONResponse({
                    "success": False,
                    "error": "Failed to delete document from any storage location",
                    "deletion_results": deletion_results
                }, status_code=500)
            
        except Exception as e:
            logger.error("Error deleting document {}: {}", document_id, e)
            return JSONResponse({"error": f"Failed to delete document: {str(e)}"}, status_code=500)
    
    # -----------------------------
    # Scripts Endpoints
    # -----------------------------
    
    def _load_scripts_registry(scripts_dir: Path) -> Dict[str, Any]:
        """Load scripts registry from scripts.yml if it exists"""
        registry_file = scripts_dir / "scripts.yml"
        if registry_file.exists():
            try:
                with open(registry_file, 'r', encoding='utf-8') as f:
                    return yaml.safe_load(f) or {}
            except Exception as e:
                logger.warning("Failed to load scripts registry: {}", e)
        return {}
    
    def _find_script_in_registry(filename: str, registry: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Find script entry in registry by filename"""
        scripts = registry.get("scripts", [])
        for script in scripts:
            if script.get("filename") == filename:
                return script
        return None
    
    @app.get("/api/scripts")
    async def list_scripts():
        """List all executable scripts from project_dir/scripts folder"""
        try:
            scripts_dir = Path(project_dir) / "scripts"
            
            if not scripts_dir.exists():
                return JSONResponse({"scripts": [], "total": 0})
            
            # Load registry
            registry = _load_scripts_registry(scripts_dir)
            
            # Scan for executable files
            executable_extensions = {'.py', '.ps1', '.sh', '.bat', '.cmd'}
            scripts_list = []
            
            for script_path in scripts_dir.rglob("*"):
                if script_path.is_file() and script_path.suffix.lower() in executable_extensions:
                    # Skip __pycache__ and other hidden directories
                    if '__pycache__' in script_path.parts:
                        continue
                    
                    # Get relative path from scripts_dir
                    rel_path = script_path.relative_to(scripts_dir)
                    filename = str(rel_path).replace('\\', '/')  # Normalize path separators
                    
                    # Get registry entry
                    registry_entry = _find_script_in_registry(filename, registry)
                    
                    # Get file stats
                    stat = script_path.stat()
                    
                    script_info = {
                        "filename": filename,
                        "name": registry_entry.get("name", script_path.stem) if registry_entry else script_path.stem,
                        "description": registry_entry.get("description", "") if registry_entry else "",
                        "category": registry_entry.get("category", "Other") if registry_entry else "Other",
                        "extension": script_path.suffix.lower(),
                        "path": str(script_path),
                        "size": stat.st_size,
                        "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                        "parameters": registry_entry.get("parameters", []) if registry_entry else []
                    }
                    scripts_list.append(script_info)
            
            # Sort by name
            scripts_list.sort(key=lambda x: x["name"].lower())
            
            return JSONResponse({
                "scripts": scripts_list,
                "total": len(scripts_list)
            })
            
        except Exception as e:
            logger.error("Error listing scripts: {}", e)
            return JSONResponse({"error": f"Failed to list scripts: {str(e)}"}, status_code=500)
    
    @app.post("/api/scripts/{script_name:path}/run")
    async def run_script(script_name: str, request: Request):
        """Execute a script with optional parameters"""
        try:
            scripts_dir = Path(project_dir) / "scripts"
            script_path = scripts_dir / script_name
            
            # Security check: ensure script is within scripts directory
            try:
                script_path.resolve().relative_to(scripts_dir.resolve())
            except ValueError:
                return JSONResponse({"error": "Invalid script path"}, status_code=400)
            
            if not script_path.exists() or not script_path.is_file():
                return JSONResponse({"error": "Script not found"}, status_code=404)
            
            # Get parameters from request body
            body = await request.json()
            parameters = body.get("parameters", {})
            
            # Load registry to get parameter definitions
            registry = _load_scripts_registry(scripts_dir)
            registry_entry = _find_script_in_registry(script_name, registry)
            
            # Build command based on file extension
            extension = script_path.suffix.lower()
            start_time = time.time()
            
            if extension == '.py':
                # Use current Python interpreter
                import sys
                python_exe = sys.executable
                cmd = [python_exe, str(script_path)]
                # Add parameters as command-line arguments
                # Check if parameter is a flag (boolean) from registry
                for param_name, param_value in parameters.items():
                    # Check if this is a flag parameter
                    is_flag = False
                    if registry_entry:
                        param_def = next(
                            (p for p in registry_entry.get("parameters", []) if p.get("name") == param_name),
                            None
                        )
                        if param_def and param_def.get("type") == "flag":
                            is_flag = True
                    
                    if is_flag:
                        # For flags, only add the flag if value is truthy
                        if param_value and str(param_value).lower() in ("true", "1", "yes", "on"):
                            cmd.append(f"--{param_name}")
                    else:
                        # For regular parameters, add both name and value
                        if param_value:  # Only add non-empty values
                            cmd.extend([f"--{param_name}", str(param_value)])
            elif extension == '.ps1':
                cmd = ["powershell", "-ExecutionPolicy", "Bypass", "-File", str(script_path)]
                # PowerShell parameters
                for param_name, param_value in parameters.items():
                    if param_value:
                        cmd.extend([f"-{param_name}", str(param_value)])
            elif extension in ['.sh', '.bat', '.cmd']:
                cmd = [str(script_path)]
                # Add parameters
                for param_name, param_value in parameters.items():
                    if param_value:
                        cmd.extend([str(param_value)])
            else:
                return JSONResponse({"error": f"Unsupported script type: {extension}"}, status_code=400)
            
            # Execute script
            # Scripts expect to run from repository root (where pyproject.toml is)
            # because they use paths like "projects/ensemble/data/..."
            repo_root = find_repository_root(Path(project_dir))
            logger.debug("Running script from repository root: {} (project_dir: {})", repo_root, project_dir)
            
            try:
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=str(repo_root),  # Working directory is repository root (scripts expect this)
                    env=os.environ.copy()  # Use same environment as FastAPI app
                )
                
                # Wait with timeout (5 minutes)
                try:
                    stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=300.0)
                except asyncio.TimeoutError:
                    process.kill()
                    await process.wait()
                    return JSONResponse({
                        "success": False,
                        "error": "Script execution timed out after 5 minutes",
                        "return_code": -1,
                        "stdout": "",
                        "stderr": "",
                        "execution_time": time.time() - start_time
                    }, status_code=408)
                
                execution_time = time.time() - start_time
                return_code = process.returncode
                
                stdout_text = stdout.decode('utf-8', errors='replace') if stdout else ""
                stderr_text = stderr.decode('utf-8', errors='replace') if stderr else ""
                
                return JSONResponse({
                    "success": return_code == 0,
                    "return_code": return_code,
                    "stdout": stdout_text,
                    "stderr": stderr_text,
                    "execution_time": round(execution_time, 2)
                })
                
            except Exception as e:
                logger.error("Error executing script {}: {}", script_name, e)
                return JSONResponse({
                    "success": False,
                    "error": str(e),
                    "return_code": -1,
                    "stdout": "",
                    "stderr": "",
                    "execution_time": time.time() - start_time
                }, status_code=500)
            
        except Exception as e:
            logger.error("Error running script {}: {}", script_name, e)
            return JSONResponse({"error": f"Failed to run script: {str(e)}"}, status_code=500)
    
    @app.get("/history")
    async def get_history():
        # Return sessions summary: id, count, title (first q), last intent
        out = []
        for sid, turns in sessions.items():
            if not turns:
                continue
            title = (turns[0].get("q") or "")[:80]
            last_intent = turns[-1].get("t")
            out.append({"id": sid, "title": title, "count": len(turns), "t": last_intent})
        # Sort by id desc (newest first)
        out.sort(key=lambda x: x.get("id", 0), reverse=True)
        return JSONResponse(out)

    @app.get("/history/item")
    async def get_history_item(id: int) -> JSONResponse:
        sid = int(id)
        turns = sessions.get(sid) or []
        if turns:
            return JSONResponse({"id": sid, "turns": turns})
        # Fallback: reconstruct from per-session files
        try:
            hist_dir = (Path(project_dir) / "data" / "history")
            # Prefer pretty JSON if available, else JSONL
            jf = hist_dir / f"{sid}.json"
            if jf.exists():
                arr = json.loads(jf.read_text(encoding="utf-8") or "[]")
                return JSONResponse({"id": sid, "turns": arr or []})
            lf = hist_dir / f"{sid}.jsonl"
            if lf.exists():
                found: list[dict] = []
                for line in lf.read_text(encoding="utf-8").splitlines():
                    try:
                        obj = json.loads(line)
                        found.append(obj)
                    except Exception:
                        continue
                if found:
                    return JSONResponse({"id": sid, "turns": found})
        except Exception:
            pass
        return JSONResponse({"error": "not_found"}, status_code=404)

    @app.post("/history/delete")
    async def delete_history_item(req: Request) -> JSONResponse:
        try:
            body = await req.json()
            target_id = int(body.get("id"))
        except Exception:
            return JSONResponse({"error": "bad_request"}, status_code=400)
        # Remove from memory
        try:
            idx = next((i for i, it in enumerate(history) if int(it.get("id", -1)) == target_id), -1)
            if idx >= 0:
                history.pop(idx)
        except Exception:
            pass
        # Delete per-session files and remove from summary
        try:
            # Remove from sessions
            if target_id in sessions:
                sessions.pop(target_id, None)
            hist_dir = (Path(project_dir) / "data" / "history")
            try:
                (hist_dir / f"{target_id}.json").unlink(missing_ok=True)  # type: ignore[arg-type]
            except Exception:
                pass
            try:
                (hist_dir / f"{target_id}.jsonl").unlink(missing_ok=True)  # type: ignore[arg-type]
            except Exception:
                pass
        except Exception:
            pass
        return JSONResponse({"ok": True})

    @app.post("/session/new")
    async def new_session() -> JSONResponse:
        nonlocal current_session_id
        current_session_id = int(time.time() * 1000)
        sessions.setdefault(current_session_id, [])
        return JSONResponse({"id": current_session_id})

    @app.post("/session/select")
    async def select_session(req: Request) -> JSONResponse:
        nonlocal current_session_id
        try:
            body = await req.json()
            sid = int(body.get("id"))
        except Exception:
            return JSONResponse({"error": "bad_request"}, status_code=400)
        current_session_id = sid
        sessions.setdefault(current_session_id, [])
        logger.info("Selected session {} for subsequent turns", current_session_id)
        return JSONResponse({"ok": True, "id": current_session_id})

    # === SQLite Chat Storage API Endpoints ===
    
    @app.get("/api/sessions")
    async def get_chat_sessions() -> JSONResponse:
        """Get all chat sessions from SQLite database"""
        try:
            sessions_data = orchestrator.get_all_sessions('active')
            sessions_list = []
            
            for session in sessions_data:
                # Get turn count for each session
                turns = orchestrator.get_turns_for_session(session.id)
                
                # Use title from database (generated by assistant or fallback)
                title = session.title if hasattr(session, 'title') and session.title else "New chat"
                
                # Get pinned status (default to False if not set)
                pinned = getattr(session, 'pinned', False)
                if isinstance(pinned, int):
                    pinned = bool(pinned)
                
                # Get pinned_order (default to 0 if not set)
                pinned_order = getattr(session, 'pinned_order', 0)
                if not isinstance(pinned_order, int):
                    pinned_order = 0
                
                sessions_list.append({
                    "id": session.id,
                    "title": title,
                    "created_at": session.created_at.isoformat(),
                    "last_accessed": session.last_accessed.isoformat(),
                    "turn_count": len(turns),
                    "status": session.status,
                    "pinned": pinned,
                    "pinned_order": pinned_order
                })
            
            # Sort by last_accessed descending
            sessions_list.sort(key=lambda x: x["last_accessed"], reverse=True)
            
            return JSONResponse({"sessions": sessions_list})
            
        except Exception as e:
            logger.error("Failed to get chat sessions: {}", e)
            return JSONResponse({"error": "Failed to load sessions"}, status_code=500)
    
    @app.get("/api/sessions/{session_id}")
    async def get_chat_session(session_id: str) -> JSONResponse:
        """Get specific chat session with all turns from SQLite database"""
        try:
            # Get session
            session = orchestrator.get_session(session_id)
            if not session:
                return JSONResponse({"error": "Session not found"}, status_code=404)
            
            # Get all turns for this session
            turns = orchestrator.get_turns_for_session(session_id)
            
            # Convert turns to the format expected by the UI
            turns_data = []
            for turn in turns:
                turn_data = {
                    "turn_id": turn.turn_id,
                    "turn_number": turn.turn_number,
                    "pipeline_id": turn.pipeline_id,
                    "run_id": turn.run_id,  # Add run_id for feedback mapping
                    "status": turn.status,
                    "started_at": turn.started_at.isoformat() if turn.started_at else None,
                    "error_message": turn.error_message,
                    "feedback": turn.feedback  # Add feedback data (already parsed in ChatTurn)
                }
                turns_data.append(turn_data)
            
            # Use title from database (generated by assistant or fallback)
            title = session.title if hasattr(session, 'title') and session.title else "New chat"
            
            return JSONResponse({
                "session": {
                    "id": session.id,
                    "title": title,
                    "created_at": session.created_at.isoformat(),
                    "last_accessed": session.last_accessed.isoformat(),
                    "status": session.status
                },
                "turns": turns_data
            })
            
        except Exception as e:
            logger.error("Failed to get chat session {}: {}", session_id, e)
            return JSONResponse({"error": "Failed to load session"}, status_code=500)
    
    @app.get("/api/sessions/{session_id}/entries")
    async def get_session_entries(session_id: str) -> JSONResponse:
        """Get all entries for a session (merged from all turns)"""
        try:
            # Get all entries for the session (merged from all turns)
            all_entries = orchestrator.get_all_session_entries(session_id)
            
            # Extract pipeline names from workflow entries
            pipeline_names: Dict[str, str] = {}
            for entry in all_entries:
                if entry.get("kind") == "workflow" and entry.get("runId"):
                    pipeline_name = entry.get("pipelineName", "Unknown")
                    pipeline_names[entry["runId"]] = pipeline_name
            
            return JSONResponse({
                "entries": all_entries,
                "pipelineNames": pipeline_names
            })
            
        except Exception as e:
            logger.error("Failed to get session entries {}: {}", session_id, e)
            return JSONResponse({"error": "Failed to load entries"}, status_code=500)
    
    @app.post("/api/runs/{run_id}/entries")
    async def save_run_entries(run_id: str, request: Request) -> JSONResponse:
        """Save entries for a run (called from frontend)"""
        try:
            body = await request.json()
            entries = body.get("entries", [])
            
            if not isinstance(entries, list):
                return JSONResponse({"error": "entries must be a list"}, status_code=400)
            
            logger.debug("Saving {} entries for run_id: {}", len(entries), run_id)
            
            # Get turn by run_id via orchestrator
            turn = orchestrator.get_turn_by_run_id(run_id)
            if not turn:
                logger.warning("Turn not found for run_id: {}", run_id)
                return JSONResponse({"error": "Turn not found for run_id", "run_id": run_id}, status_code=404)
            
            turn_id = turn.turn_id
            if not turn_id:
                logger.warning("Turn ID not found for run_id: {}", run_id)
                return JSONResponse({"error": "Turn ID not found", "run_id": run_id}, status_code=404)
            
            logger.debug("Found turn_id {} for run_id {}", turn_id, run_id)
            
            # Update entries for this turn
            success = orchestrator.update_turn_entries(turn_id, entries)
            
            if success:
                logger.info("Saved {} entries for run {} (turn {})", len(entries), run_id, turn_id)
                return JSONResponse({"ok": True, "entries_count": len(entries), "turn_id": turn_id})
            else:
                logger.error("Failed to update entries for turn_id: {}", turn_id)
                return JSONResponse({"error": "Failed to save entries", "turn_id": turn_id}, status_code=500)
            
        except Exception as e:
            logger.error("Failed to save run entries {}: {}", run_id, e, exc_info=True)
            return JSONResponse({"error": "Failed to save entries", "details": str(e)}, status_code=500)

    @app.post("/api/feedback")
    async def submit_feedback(request: Request) -> JSONResponse:
        """Store feedback for a turn"""
        try:
            body = await request.json()
            run_id = body.get("run_id")
            feedback_type = body.get("feedback_type")
            comment = body.get("comment", "")
            
            if not run_id:
                return JSONResponse({"error": "run_id is required"}, status_code=400)
            
            if feedback_type not in ["up", "down"]:
                return JSONResponse({"error": "feedback_type must be 'up' or 'down'"}, status_code=400)
            
            # Get turn by run_id
            turn = orchestrator.get_turn_by_run_id(run_id)
            
            if not turn:
                return JSONResponse({"error": "Turn not found for run_id"}, status_code=404)
            
            # Get turn_id and status from the turn object (ChatTurn dataclass)
            turn_id = turn.turn_id
            current_status = turn.status if turn.status else 'completed'
            
            # Prepare feedback data
            from datetime import datetime, timedelta
            feedback_data = {
                "type": feedback_type,
                "comment": comment,
                "timestamp": datetime.now().isoformat()
            }
            
            # Update turn with feedback using update_turn_status
            # Keep the current status, just add feedback in updates
            success = orchestrator.update_turn_status(turn_id, current_status, {"feedback": feedback_data})
            
            if success:
                logger.info("Stored feedback for turn {} (run_id: {}): {}", turn_id, run_id, feedback_type)
                return JSONResponse({"ok": True, "turn_id": turn_id, "run_id": run_id})
            else:
                logger.error("Failed to store feedback for turn {}", turn_id)
                return JSONResponse({"error": "Failed to store feedback"}, status_code=500)
            
        except Exception as e:
            logger.error("Failed to submit feedback: {}", e, exc_info=True)
            return JSONResponse({"error": "Failed to submit feedback", "details": str(e)}, status_code=500)

    @app.post("/api/sessions/{session_id}/restore")
    async def restore_chat_session(session_id: str) -> JSONResponse:
        """Restore a chat session and set it as current"""
        try:
            # Use session manager to restore the session
            restore_result = orchestrator.restore_session(session_id)
            
            # Set as current session
            nonlocal current_session_id
            current_session_id = int(session_id) if session_id.isdigit() else None
            
            # Get session title from restored session
            session = restore_result.session
            title = session.title if hasattr(session, 'title') and session.title else "New chat"
            
            return JSONResponse({
                "ok": True,
                "session_id": session_id,
                "title": title,
                "turns_restored": len(restore_result.turns)
            })
            
        except Exception as e:
            logger.error("Failed to restore chat session {}: {}", session_id, e)
            return JSONResponse({"error": "Failed to restore session"}, status_code=500)

    @app.delete("/api/sessions/{session_id}")
    async def delete_chat_session(session_id: str) -> JSONResponse:
        """Delete a chat session and all associated turns from chat.db, plus cleanup session files"""
        try:
            # Use shared services
            file_storage, chroma_client, chat_storage, session_manager, db_manager, _ = get_shared_services()
            
            # Verify session exists before deletion
            session = orchestrator.get_session(session_id)
            if not session:
                return JSONResponse({"error": "Session not found"}, status_code=404)
            
            # Delete session from database (this also deletes all associated turns)
            success = session_manager.delete_session(session_id)
            
            if not success:
                logger.error("Failed to delete session {} from database", session_id)
                return JSONResponse({"error": "Failed to delete session from database"}, status_code=500)
            
            # Clean up session files
            try:
                file_storage.cleanup_session_files(session_id)
            except Exception as e:
                logger.warning("Failed to cleanup session files for {}: {}", session_id, e)
                # Don't fail the request if file cleanup fails
            
            # Clear session from in-memory orchestrator state if it exists
            try:
                nonlocal current_session_id
                if current_session_id == int(session_id) if session_id.isdigit() else None:
                    current_session_id = None
                
                # Clean up AG-UI session state
                agui_session_queues.pop(int(session_id), None)
                hitl_waiters.pop(int(session_id), None)
                agui_services.pop(int(session_id), None)
                session_run_counters.pop(int(session_id), None)
                agui_emitters.pop(int(session_id), None)
                agui_assistants.pop(int(session_id), None)
                initialized_assistants.discard(int(session_id))
            except (ValueError, KeyError):
                pass  # Session ID might not be numeric or not in memory state
            
            logger.info("Successfully deleted session {} and all associated data", session_id)
            return JSONResponse({
                "ok": True,
                "session_id": session_id,
                "message": "Session deleted successfully"
            })
            
        except Exception as e:
            logger.error("Failed to delete chat session {}: {}", session_id, e, exc_info=True)
            return JSONResponse({"error": "Failed to delete session"}, status_code=500)

    @app.put("/api/sessions/{session_id}/title")
    async def update_session_title(session_id: str, request: Request) -> JSONResponse:
        """Update the title of a chat session"""
        try:
            body = await request.json()
            new_title = body.get("title", "").strip()
            
            if not new_title:
                return JSONResponse({"error": "Title is required"}, status_code=400)
            
            # Validate title length (max 100 chars for database)
            if len(new_title) > 100:
                new_title = new_title[:100]
                logger.warning("Title truncated to 100 characters for session {}", session_id)
            
            # Verify session exists
            session = orchestrator.get_session(session_id)
            if not session:
                return JSONResponse({"error": "Session not found"}, status_code=404)
            
            # Update title in database via orchestrator
            success = orchestrator.update_session_title(session_id, new_title)
            
            if success:
                logger.info("Updated session title for {}: '{}'", session_id, new_title)
                return JSONResponse({
                    "ok": True,
                    "session_id": session_id,
                    "title": new_title
                })
            else:
                logger.error("Failed to update session title for {}", session_id)
                return JSONResponse({"error": "Failed to update session title"}, status_code=500)
            
        except Exception as e:
            logger.error("Failed to update session title for {}: {}", session_id, e, exc_info=True)
            return JSONResponse({"error": "Failed to update session title"}, status_code=500)
    
    @app.put("/api/sessions/{session_id}/pin")
    async def update_session_pin(session_id: str, request: Request) -> JSONResponse:
        """Update the pinned status of a chat session"""
        try:
            body = await request.json()
            pinned = body.get("pinned", False)
            pinned_order = body.get("pinned_order")
            
            # Ensure pinned is a boolean
            if not isinstance(pinned, bool):
                pinned = bool(pinned)
            
            # Verify session exists
            session = orchestrator.get_session(session_id)
            if not session:
                return JSONResponse({"error": "Session not found"}, status_code=404)
            
            # If pinning, calculate pinned_order if not provided
            if pinned and pinned_order is None:
                # Get max pinned_order and add 1
                all_sessions = orchestrator.get_all_sessions('active')
                max_order = 0
                for s in all_sessions:
                    s_pinned = getattr(s, 'pinned', False)
                    if isinstance(s_pinned, int):
                        s_pinned = bool(s_pinned)
                    if s_pinned:
                        s_order = getattr(s, 'pinned_order', 0)
                        if isinstance(s_order, int) and s_order > max_order:
                            max_order = s_order
                pinned_order = max_order + 1
            elif not pinned:
                # When unpinning, clear pinned_order to 0
                pinned_order = 0
            
            # Update pinned status in database via orchestrator
            success = orchestrator.update_session_pinned(session_id, pinned, pinned_order)
            
            if success:
                logger.info("Updated session pinned status for {}: {}, order: {}", session_id, pinned, pinned_order)
                return JSONResponse({
                    "ok": True,
                    "session_id": session_id,
                    "pinned": pinned,
                    "pinned_order": pinned_order
                })
            else:
                logger.error("Failed to update session pinned status for {}", session_id)
                return JSONResponse({"error": "Failed to update session pinned status"}, status_code=500)
            
        except Exception as e:
            logger.error("Failed to update session pinned status for {}: {}", session_id, e, exc_info=True)
            return JSONResponse({"error": "Failed to update session pinned status"}, status_code=500)
    
    @app.put("/api/sessions/{session_id}/pinned-order")
    async def update_pinned_order(session_id: str, request: Request) -> JSONResponse:
        """Update the pinned order of a chat session"""
        try:
            body = await request.json()
            pinned_order = body.get("pinned_order")
            
            if pinned_order is None or not isinstance(pinned_order, int):
                return JSONResponse({"error": "pinned_order is required and must be an integer"}, status_code=400)
            
            # Verify session exists
            session = orchestrator.get_session(session_id)
            if not session:
                return JSONResponse({"error": "Session not found"}, status_code=404)
            
            # Update pinned order in database via orchestrator
            success = orchestrator.update_pinned_order(session_id, pinned_order)
            
            if success:
                logger.info("Updated session pinned order for {}: {}", session_id, pinned_order)
                return JSONResponse({
                    "ok": True,
                    "session_id": session_id,
                    "pinned_order": pinned_order
                })
            else:
                logger.error("Failed to update session pinned order for {}", session_id)
                return JSONResponse({"error": "Failed to update session pinned order"}, status_code=500)
            
        except Exception as e:
            logger.error("Failed to update session pinned order for {}: {}", session_id, e, exc_info=True)
            return JSONResponse({"error": "Failed to update session pinned order"}, status_code=500)

    @app.get("/activity")
    async def get_activity(limit: int = 200):
        try:
            return JSONResponse(activity[-int(limit) :])
        except Exception:
            return JSONResponse(activity[-200:])


    # Helpers: JSON safety and AG-UI event translation
    def _json_safe(value):
        try:
            json.dumps(value)
            return value
        except Exception:
            if isinstance(value, dict):
                return {str(k): _json_safe(v) for k, v in value.items()}
            if isinstance(value, (list, tuple, set)):
                return [_json_safe(v) for v in value]
            return str(value)


    # -----------------------------
    # Helper function to set up emitter infrastructure for a session
    # -----------------------------
    def _setup_emitter_for_session(session_id: str) -> tuple[AGUIEventEmitter, AGUIService, asyncio.Queue[str]]:
        """
        Set up emitter, AGUIService, and SSE queue for a session.
        
        This helper is used by both /agui/turn and TriggerManager to ensure
        consistent event emission to the frontend.
        
        Args:
            session_id: Session ID (string, will be converted to int for FastAPI compatibility)
            
        Returns:
            Tuple of (emitter, agui_service, queue)
        """
        try:
            fastapi_session_id = int(session_id)
        except (ValueError, TypeError):
            raise ValueError(f"Session ID must be numeric: {session_id}")
        
        # Get or create SSE queue
        q = agui_session_queues.setdefault(fastapi_session_id, asyncio.Queue())
        
        # Create session-specific run counter
        def get_next_run_counter():
            current_count = session_run_counters.get(fastapi_session_id, 0)
            session_run_counters[fastapi_session_id] = current_count + 1
            return current_count
        
        # Get or create AGUIService
        agui_service = agui_services.setdefault(fastapi_session_id, AGUIService())
        
        # Create captured events list
        captured_events = []
        
        def emit_and_capture(evt: Dict[str, Any]) -> None:
            try:
                # Capture the event for pipeline_events
                captured_events.append(evt)
                
                # Convert event if needed (handles internal events like HITL)
                agui_events = agui_service.convert_event(_json_safe(evt))
                
                # Emit each converted event to SSE queue
                for agui_evt in agui_events:
                    payload = f"data: {json.dumps(agui_evt)}\n\n"
                    q.put_nowait(payload)
            except Exception as e:
                logger.warning("AGUI emit failed: {}", e)
        
        # Create or get session-scoped emitter
        emitter = agui_emitters.setdefault(
            fastapi_session_id,
            AGUIEventEmitter(emit_and_capture, get_next_run_counter)
        )
        emitter._captured_events = captured_events
        
        return emitter, agui_service, q

    # Store the function in app.state so lifespan can access it
    app.state.setup_emitter_fn = _setup_emitter_for_session

    # -----------------------------
    # AG-UI Adapter Endpoints (Phase 1)
    # -----------------------------
    @app.post("/agui/turn")
    async def agui_turn(req: Request) -> JSONResponse:
        """Start a turn for AG-UI clients. Fire-and-forget; stream via /agui/stream."""
        try:
            body = await req.json()
        except Exception:
            return JSONResponse({"error": "bad_request"}, status_code=400)

        text = (body.get("text") or "").strip()
        if not text:
            return JSONResponse({"error": "missing_text"}, status_code=400)

        # Extract user_files from request body
        user_files = body.get("user_files", [])
        if not isinstance(user_files, list):
            return JSONResponse({"error": "user_files must be a list"}, status_code=400)

        # Use the session_id from the request (frontend-generated)
        requested_session_id = body.get("session_id")
        if not requested_session_id:
            return JSONResponse({"error": "missing_session_id"}, status_code=400)
        
        # Require an existing backend session; do not accept client-generated IDs
        session_id = requested_session_id
        fastapi_session_id = int(requested_session_id)

        try:
            existing = orchestrator.get_session(session_id)
            if not existing:
                return JSONResponse({"error": "unknown_session_id"}, status_code=404)
            logger.info("Using existing database session: {}", session_id)
        except Exception as e:
            logger.warning("Failed to get database session: {}", e)
            return JSONResponse({"error": "session_lookup_failed"}, status_code=500)
        
        # Use helper to set up emitter infrastructure
        emitter, agui_service, q = _setup_emitter_for_session(session_id)

        async def wait_for_approval(gate_id, timeout_ms=300000):
            """Async waiter function for HITL gates"""
            # Get the Future and await it with timeout
            fut = _fresh_waiter_future(fastapi_session_id, str(gate_id))
            result = await asyncio.wait_for(fut, (timeout_ms or 300000) / 1000.0)
            # Ensure result is always a dict (should be, but guard against edge cases)
            if not isinstance(result, dict):
                logger.warning("Gate result is not a dict, got {} (type: {}), wrapping", result, type(result))
                return {"decision": "approve", "data": result if result else {}}
            return result
        
        hitl_wait_options = {
            "hitl": {
                "wait_for_approval": wait_for_approval
            }
        }

        async def _run_turn():
            # Clear captured events for this turn (same pattern as CLI)
            if hasattr(emitter, "_captured_events") and emitter._captured_events:
                emitter._captured_events.clear()

            try:
                assistant = agui_assistants.setdefault(
                    fastapi_session_id,
                    Assistant(cfg, project_dir=project_dir, emitter=emitter, agui_service=agui_service, session_id=session_id),
                )
                if fastapi_session_id not in initialized_assistants:
                    await assistant.initialize()
                    initialized_assistants.add(fastapi_session_id)

                await assistant.execute_assistant_agent(
                    user_input=text,
                    turn_options=hitl_wait_options,
                    file_paths=user_files,
                    original_filenames=[Path(f).name for f in user_files] if user_files else [],
                    upload_intent="session",
                    mode="fastapi"
                )

            except Exception as e:
                logger.error("Error during assistant turn: {}", e)
                logger.error("Traceback: {}", traceback.format_exc())
            finally:
                # allow queued callbacks to flush then mark done
                await asyncio.sleep(0)
                await q.put("event: done\n\n")

        # Start run in background
        asyncio.create_task(_run_turn())

        return JSONResponse({"ok": True, "session_id": requested_session_id}, status_code=202)

    @app.get("/agui/stream")
    async def agui_stream(session: int) -> StreamingResponse:
        """SSE stream for AG-UI clients. Connect per session id."""
        try:
            session_id = int(session)
        except Exception:
            return StreamingResponse(iter(["data: {\"type\": \"error\", \"message\": \"bad_session\"}\n\n"]), media_type="text/event-stream")

        q = agui_session_queues.setdefault(session_id, asyncio.Queue())

        async def _generator():
            # Session ID is managed client-side, no need to emit event
            while True:
                chunk = await q.get()
                yield chunk
                if chunk.startswith("event: done"):
                    break

        return StreamingResponse(_generator(), media_type="text/event-stream")

    # Phase 4: HITL approval endpoint
    @app.post("/agui/approve")
    async def agui_approve(req: Request) -> JSONResponse:
        try:
            body = await req.json()
            session_id = int(body.get("session_id"))
            gate_id = str(body.get("gate_id"))
            decision = str(body.get("decision") or "").lower() or "approve"
            data = body.get("data")
        except Exception as e:
            return JSONResponse({"error": "bad_request"}, status_code=400)

        fut = hitl_waiters.setdefault(session_id, {}).get(gate_id)
        if not fut or fut.done():
            return JSONResponse({"error": "not_found"}, status_code=404)
        
        # Use AGUIService to resolve the HITL gate
        agui_service = agui_services.setdefault(session_id, AGUIService())
        agui_service.resolve_hitl_gate(gate_id, decision, "user")
        

        try:
            # Ensure data is always a dict
            if data is None:
                data = {}
            elif not isinstance(data, dict):
                data = {"value": data}
            fut.set_result({"decision": decision, "data": data})
        except Exception as e:
            logger.error("Failed to set Future result for gate {}: {}", gate_id, e)
            return JSONResponse({"error": "failed"}, status_code=500)

        # also emit an event so UI can reflect immediately
        try:
            q = agui_session_queues.setdefault(session_id, asyncio.Queue())
            emitter = AGUIEventEmitter(lambda evt: asyncio.create_task(q.put(f"data: {json.dumps(evt)}\n\n")))
            emitter.hitl_result(gate_id, decision, "user", _json_safe(data))
            logger.debug("agui_approve emitted hitl_result event")
        except Exception as e:
            logger.error("agui_approve error emitting event:", e)

        return JSONResponse({"ok": True})

    # =============================================================================
    # ASYNC HITL QUEUE SYSTEM ENDPOINTS
    # =============================================================================
    
    # Initialize async HITL managers (lazy initialization)
    _hitl_managers: Dict[str, Any] = {}
    
    def _get_hitl_managers() -> Dict[str, Any]:
        """Lazily initialize HITL managers"""
        if not _hitl_managers:
            from topaz_agent_kit.core.chat_database import ChatDatabase
            from topaz_agent_kit.core.checkpoint_manager import CheckpointManager
            from topaz_agent_kit.core.case_manager import CaseManager
            from topaz_agent_kit.core.hitl_queue_manager import HITLQueueManager
            from topaz_agent_kit.core.resume_handler import ResumeHandler
            
            # Use same database as chat storage
            # Resolve chatdb_path relative to project_dir (same pattern as get_shared_services)
            chatdb_path = orchestrator.validated_config.chatdb_path if orchestrator.validated_config else "./data/chat.db"
            if not Path(chatdb_path).is_absolute():
                chatdb_path = str(Path(project_dir) / chatdb_path)
            database = ChatDatabase(chatdb_path)
            
            checkpoint_manager = CheckpointManager(database)
            case_manager = CaseManager(database)
            hitl_queue_manager = HITLQueueManager(database)
            resume_handler = ResumeHandler(
                database=database,
                checkpoint_manager=checkpoint_manager,
                case_manager=case_manager,
                hitl_queue_manager=hitl_queue_manager,
            )
            
            # Wire up resume callback to execute pipeline resumption
            async def execute_resume_callback(
                pipeline_id: str,
                context: Dict[str, Any],
                resume_point: str,
                checkpoint: Any,
            ) -> Any:
                """
                Callback to execute pipeline resumption.
                
                This creates a new pipeline runner and executes from the resume point.
                """
                try:
                    from topaz_agent_kit.core.pipeline_runner import PipelineRunner
                    from topaz_agent_kit.core.ag_ui_event_emitter import AGUIEventEmitter
                    from pathlib import Path
                    import yaml
                    
                    # Get orchestrator instance (created at app startup)
                    # We need to access the global orchestrator instance
                    # For now, we'll create a minimal runner setup
                    project_path = Path(orchestrator._project_dir)
                    
                    # Load pipeline config
                    pipeline_config_path = project_path / "config" / "pipelines" / f"{pipeline_id}.yml"
                    if not pipeline_config_path.exists():
                        raise FileNotFoundError(f"Pipeline config not found: {pipeline_config_path}")
                    
                    with open(pipeline_config_path, "r", encoding="utf-8") as f:
                        pipeline_config = yaml.safe_load(f) or {}
                    
                    # Get pattern config
                    pattern_cfg = pipeline_config.get("pattern", {})
                    if not pattern_cfg:
                        raise ValueError(f"No pattern config found in {pipeline_id}")
                    
                    # Create config result (minimal for resumption)
                    from topaz_agent_kit.core.configuration_engine import ConfigurationResult
                    config_result = orchestrator.validated_config
                    config_result.pipeline_config = pipeline_config
                    
                    # Create pipeline runner
                    runner = PipelineRunner(pattern_cfg, config_result=config_result)
                    
                    # Create a minimal emitter for resumption (no UI events needed)
                    emitter = AGUIEventEmitter()
                    
                    # Add required context for resumption
                    context["emitter"] = emitter
                    context["agent_factory"] = orchestrator.agent_factory
                    context["project_dir"] = str(project_path)
                    context["mcp_tools_cache"] = orchestrator._mcp_tools_cache
                    context["mcp_clients"] = orchestrator._mcp_clients
                    
                    # Re-inject async HITL managers into context
                    context["checkpoint_manager"] = checkpoint_manager
                    context["case_manager"] = case_manager
                    context["hitl_queue_manager"] = hitl_queue_manager
                    
                    # Load operations config if needed
                    operations = pipeline_config.get("operations") or {}
                    operations_config_file = operations.get("config_file")
                    
                    # Apply default path resolution if not specified
                    if not operations_config_file:
                        operations_config_file = resolve_config_path(
                            None, "operations/{id}.yml", pipeline_id
                        )
                    
                    if operations_config_file:
                        operations_config_path = project_path / "config" / operations_config_file
                        if operations_config_path.exists():
                            with open(operations_config_path, "r", encoding="utf-8") as f:
                                context["case_config"] = yaml.safe_load(f) or {}
                        else:
                            context["case_config"] = {}
                    else:
                        context["case_config"] = {}

                    # Configure case tracking variable names for async HITL summaries (resume path)
                    tracking_cfg = operations.get("tracking_variables") or {}
                    if isinstance(tracking_cfg, dict):
                        hitl_queued_key = tracking_cfg.get("hitl_queued", "hitl_queued_cases")
                        completed_key = tracking_cfg.get("completed", "completed_cases")
                    else:
                        hitl_queued_key = "hitl_queued_cases"
                        completed_key = "completed_cases"

                    context["case_tracking"] = {
                        "hitl_queued": hitl_queued_key,
                        "completed": completed_key,
                    }
                    
                    # Execute pipeline from resume point
                    logger.info("Resuming pipeline {} from checkpoint {}", pipeline_id, checkpoint.checkpoint_id)
                    result = await runner.run(context=context)
                    
                    # Sanitize context before returning - remove BaseRunner objects that can't be serialized
                    # BaseRunner objects are stored in context for execution but should not be returned
                    from topaz_agent_kit.core.execution_patterns import BaseRunner
                    sanitized_context = {
                        k: v for k, v in context.items() 
                        if not isinstance(v, BaseRunner) and not k.startswith("_gate_array_runner_")
                    }
                    
                    # Return the final context (including updated upstream) so resume handler can update case_data
                    # The context dict is mutated by the pipeline runner, so it contains the final state
                    return {
                        "result": result,
                        "upstream": context.get("upstream", {}),  # Final upstream with all agent outputs
                        "context": sanitized_context,  # Sanitized context (BaseRunner objects removed)
                    }
                    
                except Exception as e:
                    # Check if this is a graceful stop (PipelineStoppedByUser), not an error
                    from topaz_agent_kit.core.exceptions import PipelineStoppedByUser
                    if isinstance(e, PipelineStoppedByUser):
                        # Pipeline was stopped by user (e.g., HITL rejection) - this is expected, not an error
                        logger.info("Pipeline stopped by user during resume for {}: {}", pipeline_id, e)
                    else:
                        # Actual error - log as error
                        logger.error("Failed to resume pipeline {}: {}", pipeline_id, e)
                    raise
            
            # Set the callback
            resume_handler.set_execute_callback(execute_resume_callback)
            
            _hitl_managers["database"] = database
            _hitl_managers["checkpoint_manager"] = checkpoint_manager
            _hitl_managers["case_manager"] = case_manager
            _hitl_managers["hitl_queue_manager"] = hitl_queue_manager
            _hitl_managers["resume_handler"] = resume_handler
            
            logger.info("Initialized async HITL managers with resume callback")
        
        return _hitl_managers
    
    # --- HITL Queue Endpoints ---
    
    @app.get("/api/hitl/queue")
    async def list_hitl_queue(
        pipeline_id: Optional[str] = None,
        status: Optional[str] = None,  # Changed from "pending" to None to return all by default
        priority: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> JSONResponse:
        """List HITL queue items with optional filters. Pass status='pending' to filter to pending only."""
        try:
            managers = _get_hitl_managers()
            hitl_queue_manager = managers["hitl_queue_manager"]
            
            items = hitl_queue_manager.list_queue(
                pipeline_id=pipeline_id,
                status=status,  # None means return all statuses
                priority=priority,
                limit=limit,
                offset=offset,
            )
            
            return JSONResponse({
                "success": True,
                "items": items,
                "count": len(items),
            })
        except Exception as e:
            logger.error("Error listing HITL queue: {}", e)
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)
    
    @app.get("/api/hitl/queue/count")
    async def get_hitl_queue_count(
        pipeline_id: Optional[str] = None,
        status: str = "pending",
    ) -> JSONResponse:
        """Get count of HITL queue items"""
        try:
            managers = _get_hitl_managers()
            hitl_queue_manager = managers["hitl_queue_manager"]
            
            count = hitl_queue_manager.get_queue_count(
                pipeline_id=pipeline_id,
                status=status,
            )
            
            return JSONResponse({"success": True, "count": count})
        except Exception as e:
            logger.error("Error getting HITL queue count: {}", e)
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)
    
    @app.get("/api/hitl/queue/{queue_item_id}")
    async def get_hitl_queue_item(queue_item_id: str) -> JSONResponse:
        """Get a specific HITL queue item with full checkpoint data"""
        try:
            managers = _get_hitl_managers()
            hitl_queue_manager = managers["hitl_queue_manager"]
            checkpoint_manager = managers["checkpoint_manager"]
            
            # Get queue item
            item = hitl_queue_manager.get_queue_item(queue_item_id)
            if not item:
                return JSONResponse({"success": False, "error": "Queue item not found"}, status_code=404)
            
            # Get associated checkpoint for full context
            checkpoint = checkpoint_manager.get_checkpoint(item.get("checkpoint_id", ""))
            
            response = {
                "success": True,
                "item": item,
            }
            
            if checkpoint:
                response["checkpoint"] = {
                    "checkpoint_id": checkpoint.checkpoint_id,
                    "upstream": checkpoint.upstream,
                    "hitl": checkpoint.hitl,
                    "loop_index": checkpoint.loop_index,
                    "resume_point": checkpoint.resume_point,
                }
            
            return JSONResponse(response)
        except Exception as e:
            logger.error("Error getting HITL queue item {}: {}", queue_item_id, e)
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)
    
    @app.post("/api/hitl/queue/{queue_item_id}/respond")
    async def respond_to_hitl_queue(queue_item_id: str, req: Request) -> JSONResponse:
        """Submit a response to a HITL queue item and trigger pipeline resumption"""
        try:
            body = await req.json()
            decision = body.get("decision")
            response_data = body.get("data", {})
            responded_by = body.get("responded_by")
            
            # Get queue item to determine gate type
            managers = _get_hitl_managers()
            hitl_queue_manager = managers["hitl_queue_manager"]
            queue_item = hitl_queue_manager.get_queue_item(queue_item_id)
            
            if not queue_item:
                return JSONResponse({"success": False, "error": "Queue item not found"}, status_code=404)
            
            gate_type = queue_item.get("gate_type", "approval")
            
            # For selection gates, extract decision from selection if decision is "submit"
            # The UI sends decision="submit" for selection gates, but the actual decision
            # should be the selected option value
            if gate_type == "selection" and decision == "submit" and isinstance(response_data, dict) and "selection" in response_data:
                selection_value = response_data.get("selection")
                if selection_value:
                    decision = selection_value
                    logger.info("Extracted decision from selection for queue item {}: {}", queue_item_id, decision)
            
            # For input gates, ensure all user input fields are properly extracted
            # Input gates send decision="submit" or "continue", but all the actual data
            # is in response_data as field values (e.g., {"field_name": "value", "notes": "..."})
            if gate_type == "input":
                # Input gates typically use "continue" or "submit" as decision
                # The actual user input is in response_data as field values
                if decision in ["submit", "continue"]:
                    # Ensure response_data contains all input fields
                    # The UI sends all field values in response_data already, but we should
                    # validate and normalize it
                    if not isinstance(response_data, dict):
                        response_data = {}
                    
                    # Log extracted input fields for debugging
                    if response_data:
                        input_fields = {k: v for k, v in response_data.items() 
                                     if k not in ("selection", "decision") and v is not None}
                        if input_fields:
                            logger.info("Extracted {} input fields from input gate response for queue item {}: {}", 
                                      len(input_fields), queue_item_id, list(input_fields.keys()))
                    
                    # For input gates, decision should be "continue" (default) or "submit"
                    # Keep the decision as-is since it's already correct
                else:
                    # For other decisions (like "retry"), keep as-is
                    pass
            
            if not decision:
                return JSONResponse({"success": False, "error": "Decision is required"}, status_code=400)
            
            resume_handler = managers["resume_handler"]
            
            # Resume from queue response (handles submission and resumption)
            result = await resume_handler.resume_from_queue_response(
                queue_item_id=queue_item_id,
                decision=decision,
                response_data=response_data,
                responded_by=responded_by,
            )
            
            if result.get("success"):
                return JSONResponse(result)
            else:
                return JSONResponse(result, status_code=400)
                
        except Exception as e:
            logger.error("Error responding to HITL queue item {}: {}", queue_item_id, e)
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)
    
    @app.post("/api/app/resolve-case")
    async def resolve_case_from_app(request: Request) -> JSONResponse:
        """Submit resolution decision from app back to case"""
        try:
            body = await request.json()
            case_id = body.get("case_id")
            app_session_id = body.get("app_session_id")
            decision = body.get("decision")
            notes = body.get("notes", "")
            canvas_state = body.get("canvas_state")  # Optional: for audit trail
            
            if not case_id:
                return JSONResponse({"error": "case_id is required"}, status_code=400)
            if not app_session_id:
                return JSONResponse({"error": "app_session_id is required"}, status_code=400)
            if not decision:
                return JSONResponse({"error": "decision is required"}, status_code=400)
            
            # Get managers
            managers = _get_hitl_managers()
            case_manager = managers["case_manager"]
            hitl_queue_manager = managers["hitl_queue_manager"]
            
            # Get case
            case = case_manager.get_case(case_id)
            if not case:
                return JSONResponse({"error": f"Case {case_id} not found"}, status_code=404)
            
            # Validate case is in hitl_pending status
            if case.get("status") != "hitl_pending":
                return JSONResponse({
                    "error": f"Case {case_id} is not in hitl_pending status (current: {case.get('status')})"
                }, status_code=400)
            
            # Get HITL queue item for this case
            queue_items = hitl_queue_manager.list_queue_items(case_id=case_id, status="pending")
            if not queue_items:
                return JSONResponse({
                    "error": f"No pending HITL queue item found for case {case_id}"
                }, status_code=404)
            
            queue_item = queue_items[0]
            queue_item_id = queue_item.get("queue_item_id") or queue_item.get("id")
            
            if not queue_item_id:
                return JSONResponse({"error": "Queue item ID not found"}, status_code=500)
            
            # Map app decision values to HITL gate decision values
            decision_mapping = {
                "approve_anyway": "approve",
                "approve_override": "approve",
                "request_evidence": "request_clarification",
                "request_clarification": "request_clarification",
                "apply_retention": "apply_retention",
                "apply_ld": "apply_ld",
                "reject": "reject"
            }
            
            hitl_decision = decision_mapping.get(decision, decision)
            
            # Determine response type based on gate type
            gate_type = queue_item.get("gate_type", "approval")
            if gate_type == "selection":
                # For selection gates, use "submit" with selection data
                response_data = {
                    "selection": decision,
                    "notes": notes
                }
                hitl_decision = "submit"
            else:
                # For approval gates, use decision directly
                response_data = {
                    "notes": notes
                }
            
            # Store canvas state snapshot in case metadata for audit trail
            if canvas_state:
                case_updates = {
                    "case_data": case.get("case_data", {}).copy()
                }
                case_updates["case_data"]["_app_resolution"] = {
                    "app_session_id": app_session_id,
                    "decision": decision,
                    "notes": notes,
                    "canvas_state_snapshot": canvas_state,
                    "resolved_at": datetime.now().isoformat()
                }
                case_manager.update_case_data(case_id, case_updates.get("case_data"), {})
            
            # Respond to HITL queue item
            result = hitl_queue_manager.respond(
                queue_item_id=queue_item_id,
                decision=hitl_decision,
                response_data=response_data,
                responded_by="user"
            )
            
            if result.get("success"):
                return JSONResponse({
                    "success": True,
                    "case_id": case_id,
                    "decision": decision,
                    "message": "Resolution submitted successfully"
                })
            else:
                return JSONResponse({
                    "success": False,
                    "error": result.get("error", "Failed to submit resolution")
                }, status_code=400)
                
        except Exception as e:
            logger.error("Error resolving case from app: {}", e, exc_info=True)
            return JSONResponse({"error": "Failed to resolve case", "details": str(e)}, status_code=500)
    
    # --- Cases Endpoints ---
    
    @app.get("/api/cases")
    async def list_cases(
        pipeline_id: Optional[str] = None,
        status: Optional[str] = None,
        run_id: Optional[str] = None,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
        group_by: Optional[str] = None,
    ) -> JSONResponse:
        """List pipeline cases with optional filters
        
        Args:
            group_by: If "grouping_key", returns grouped structure instead of flat list
        """
        try:
            managers = _get_hitl_managers()
            case_manager = managers["case_manager"]
            
            # If group_by is specified, return grouped structure
            if group_by == "grouping_key" and pipeline_id:
                case_config = _load_case_config(pipeline_id)
                grouped_cases = case_manager.list_grouped_cases(
                    pipeline_id=pipeline_id,
                    case_config=case_config,
                )
                return JSONResponse({
                    "success": True,
                    "groups": grouped_cases,
                    "count": len(grouped_cases),
                })
            
            # Otherwise, return flat list
            cases = case_manager.list_cases(
                pipeline_id=pipeline_id,
                status=status,
                run_id=run_id,
                from_date=from_date,
                to_date=to_date,
                limit=limit,
                offset=offset,
            )
            
            # Re-extract _list_view data for each case
            if cases:
                if pipeline_id:
                    # Single pipeline - load config once and apply to all cases
                    case_config = _load_case_config(pipeline_id)
                    if case_config:
                        cases = [
                            case_manager._re_extract_list_view_data(case, case_config)
                            for case in cases
                        ]
                else:
                    # Multiple pipelines - group by pipeline_id and re-extract per group
                    from collections import defaultdict
                    cases_by_pipeline = defaultdict(list)
                    cases_without_pipeline = []
                    
                    for case in cases:
                        case_pipeline_id = case.get("pipeline_id")
                        if case_pipeline_id:
                            cases_by_pipeline[case_pipeline_id].append(case)
                        else:
                            cases_without_pipeline.append(case)
                    
                    # Re-extract for each pipeline group
                    updated_cases = []
                    for case_pipeline_id, pipeline_cases in cases_by_pipeline.items():
                        case_config = _load_case_config(case_pipeline_id)
                        if case_config:
                            for case in pipeline_cases:
                                updated_cases.append(
                                    case_manager._re_extract_list_view_data(case, case_config)
                                )
                        else:
                            updated_cases.extend(pipeline_cases)
                    
                    # Add cases without pipeline_id (shouldn't happen, but handle gracefully)
                    updated_cases.extend(cases_without_pipeline)
                    
                    cases = updated_cases
            
            return JSONResponse({
                "success": True,
                "cases": cases,
                "count": len(cases),
            })
        except Exception as e:
            logger.error("Error listing cases: {}", e)
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)
    
    @app.get("/api/cases/summary")
    async def get_cases_summary(pipeline_id: Optional[str] = None) -> JSONResponse:
        """Get summary counts of cases by status"""
        try:
            managers = _get_hitl_managers()
            case_manager = managers["case_manager"]
            
            summary = case_manager.get_case_summary(pipeline_id=pipeline_id)
            
            return JSONResponse({"success": True, "summary": summary})
        except Exception as e:
            logger.error("Error getting cases summary: {}", e)
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)
    
    @app.get("/api/cases/grouped")
    async def list_grouped_cases(
        pipeline_id: Optional[str] = None,
    ) -> JSONResponse:
        """List grouped cases (top-level virtual cases with sub-cases)"""
        try:
            if not pipeline_id:
                return JSONResponse({
                    "success": False,
                    "error": "pipeline_id is required for grouped cases"
                }, status_code=400)
            
            managers = _get_hitl_managers()
            case_manager = managers["case_manager"]
            
            case_config = _load_case_config(pipeline_id)
            grouped_cases = case_manager.list_grouped_cases(
                pipeline_id=pipeline_id,
                case_config=case_config,
            )
            
            return JSONResponse({
                "success": True,
                "groups": grouped_cases,
                "count": len(grouped_cases),
            })
        except Exception as e:
            logger.error("Error listing grouped cases: {}", e)
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)
    
    @app.get("/api/cases/grouped/{grouping_key}")
    async def get_grouped_case(
        grouping_key: str,
        pipeline_id: Optional[str] = None,
    ) -> JSONResponse:
        """Get a single grouped case by grouping_key"""
        try:
            if not pipeline_id:
                return JSONResponse({
                    "success": False,
                    "error": "pipeline_id is required for grouped cases"
                }, status_code=400)
            
            managers = _get_hitl_managers()
            case_manager = managers["case_manager"]
            
            case_config = _load_case_config(pipeline_id)
            grouped_case = case_manager.get_grouped_case(
                grouping_key=grouping_key,
                pipeline_id=pipeline_id,
                case_config=case_config,
            )
            
            if not grouped_case:
                return JSONResponse({
                    "success": False,
                    "error": "Grouped case not found"
                }, status_code=404)
            
            return JSONResponse({
                "success": True,
                "group": grouped_case,
            })
        except Exception as e:
            logger.error("Error getting grouped case {}: {}", grouping_key, e)
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)
    
    @app.get("/api/cases/{case_id}")
    async def get_case(case_id: str) -> JSONResponse:
        """Get a specific case with full details.
        
        Always re-extracts display config from current case YAML using final_output
        (or stored agent outputs) as the data source. This ensures title/subtitle
        and pipeline fields reflect current YAML changes immediately.
        """
        try:
            managers = _get_hitl_managers()
            case_manager = managers["case_manager"]
            checkpoint_manager = managers["checkpoint_manager"]
            
            # Get case
            case = case_manager.get_case(case_id)
            if not case:
                return JSONResponse({"success": False, "error": "Case not found"}, status_code=404)
            
            # Always re-extract display config from current case YAML
            # Use final_output or stored agent outputs as the data source
            pipeline_id = case.get("pipeline_id")
            if pipeline_id:
                case_config = _load_case_config(pipeline_id)
                if case_config:
                    # Get data source: prefer final_output, fallback to stored case_data (agent outputs)
                    final_output = case.get("final_output")
                    stored_case_data = case.get("case_data", {})
                    
                    # Build upstream from final_output or stored agent outputs
                    # Remove display metadata (_list_view, _detail_view, etc.) to get raw agent outputs
                    upstream = {}
                    if final_output:
                        # Use final_output as primary data source
                        if isinstance(final_output, dict):
                            upstream.update(final_output)
                        else:
                            upstream["final_output"] = final_output
                    
                    # Add stored agent outputs (excluding display metadata)
                    for key, value in stored_case_data.items():
                        if not key.startswith("_"):  # Exclude _list_view, _detail_view, etc.
                            upstream[key] = value
                    
                    # Re-extract display config from current YAML using upstream as data source
                    from topaz_agent_kit.core.case_data_extractor import CaseDataExtractor
                    extractor = CaseDataExtractor()
                    # Build case_meta from case record for template rendering
                    case_meta = {
                        "case_id": case.get("case_id"),
                        "display_id": case.get("display_id"),
                        "pipeline_id": case.get("pipeline_id"),
                        "status": case.get("status"),
                        "hitl_gate_title": case.get("hitl_gate_title"),
                        "hitl_description": case.get("hitl_description"),
                        "hitl_status": case.get("hitl_status"),
                        "hitl_decision": case.get("hitl_decision"),
                        "responded_by": case.get("responded_by"),
                        "created_at": case.get("created_at"),
                        "updated_at": case.get("updated_at"),
                    }
                    re_extracted = extractor.extract_case_data(
                        upstream=upstream,
                        case_config=case_config,
                        case_meta=case_meta,
                    )
                    
                    # Update case_data with re-extracted display config
                    # Preserve raw agent outputs, update display metadata
                    updated_case_data = stored_case_data.copy()
                    
                    # Update display metadata from re-extraction
                    # This ensures YAML changes (labels, fields, documents, etc.) take effect immediately
                    display_metadata_fields = [
                        "_list_view",
                        "_detail_view",
                        "_detail_view_modal",
                        "_detail_view_tabs",
                        "_timeline_config",
                        "_documents",  # Documents tab configuration
                        "_review_response_outcome",  # Review response outcome tab
                    ]
                    for field in display_metadata_fields:
                        if field in re_extracted:
                            updated_case_data[field] = re_extracted[field]
                    
                    # Preserve raw agent outputs (don't overwrite with re-extracted)
                    # Re-extracted may have agent outputs, but we want to keep original stored ones
                    for key, value in stored_case_data.items():
                        if not key.startswith("_"):
                            updated_case_data[key] = value
                    
                    case["case_data"] = updated_case_data
            
            
            response = {
                "success": True,
                "case": case,
            }
            
            # If case is HITL pending, include checkpoint preview
            if case.get("status") == "hitl_pending":
                checkpoint = checkpoint_manager.get_checkpoint_by_case(case_id)
                if checkpoint:
                    response["checkpoint_preview"] = {
                        "checkpoint_id": checkpoint.checkpoint_id,
                        "gate_id": checkpoint.gate_id,
                        "resume_point": checkpoint.resume_point,
                        "upstream_keys": list(checkpoint.upstream.keys()),
                    }
            
            return JSONResponse(response)
        except Exception as e:
            logger.error("Error getting case {}: {}", case_id, e)
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)
    
    @app.delete("/api/cases/{case_id}")
    async def delete_case(case_id: str) -> JSONResponse:
        """Delete a specific case and all associated data"""
        try:
            managers = _get_hitl_managers()
            case_manager = managers["case_manager"]
            
            success = case_manager.delete_case(case_id)
            
            if success:
                return JSONResponse({"success": True, "message": f"Case {case_id} deleted successfully"})
            else:
                return JSONResponse({"success": False, "error": "Failed to delete case"}, status_code=500)
                
        except Exception as e:
            logger.error("Error deleting case {}: {}", case_id, e)
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)
    
    @app.delete("/api/cases")
    async def delete_cases(
        pipeline_id: Optional[str] = None,
        status: Optional[str] = None,
    ) -> JSONResponse:
        """Delete multiple cases with optional filters"""
        try:
            managers = _get_hitl_managers()
            case_manager = managers["case_manager"]
            
            deleted_count = case_manager.delete_cases(
                pipeline_id=pipeline_id,
                status=status,
            )
            
            return JSONResponse({
                "success": True,
                "deleted_count": deleted_count,
                "message": f"Deleted {deleted_count} case(s)"
            })
                
        except Exception as e:
            logger.error("Error deleting cases: {}", e)
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)
    
    def _resolve_field_references_in_config(case_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Resolve all field references in case config for frontend consumption.
        
        This ensures that when the frontend reads pipeline_fields, all references
        to centralized fields are resolved with their full definitions.
        
        Args:
            case_config: Raw case config dictionary
            
        Returns:
            Case config with all field references resolved
        """
        from topaz_agent_kit.core.case_data_extractor import CaseDataExtractor
        
        extractor = CaseDataExtractor()
        resolved_config = case_config.copy()
        
        # Resolve views.list.pipeline_fields (unified structure)
        # Note: The legacy list_view structure is not supported - backend extraction only reads from views.list
        if "views" in resolved_config and "list" in resolved_config["views"]:
            list_view = resolved_config["views"]["list"]
            if isinstance(list_view, dict) and "pipeline_fields" in list_view:
                pipeline_fields = list_view["pipeline_fields"]
                if isinstance(pipeline_fields, list):
                    list_view["pipeline_fields"] = [
                        extractor._resolve_field_reference(field_config, resolved_config)
                        for field_config in pipeline_fields
                    ]
        
        # Resolve views.detail.sections[].fields (unified structure)
        # Note: The legacy detail_view structure is not supported - backend extraction only reads from views.detail
        if "views" in resolved_config and "detail" in resolved_config["views"]:
            detail_view = resolved_config["views"]["detail"]
            if isinstance(detail_view, dict) and "sections" in detail_view:
                sections = detail_view["sections"]
                if isinstance(sections, list):
                    for section in sections:
                        if "fields" in section and isinstance(section["fields"], list):
                            section["fields"] = [
                                extractor._resolve_field_reference(field_config, resolved_config)
                                for field_config in section["fields"]
                            ]
            
            # Resolve views.detail.tabs_config.*.sections[].fields
            # This handles tab-specific field definitions (e.g., overview tab)
            if isinstance(detail_view, dict) and "tabs_config" in detail_view:
                tabs_config = detail_view["tabs_config"]
                if isinstance(tabs_config, dict):
                    for tab_id, tab_config in tabs_config.items():
                        if isinstance(tab_config, dict) and "sections" in tab_config:
                            sections = tab_config["sections"]
                            if isinstance(sections, list):
                                for section in sections:
                                    if "fields" in section and isinstance(section["fields"], list):
                                        section["fields"] = [
                                            extractor._resolve_field_reference(field_config, resolved_config)
                                            for field_config in section["fields"]
                                        ]
        
        # Resolve timeline.system_events.*.details field references
        if "timeline" in resolved_config and "system_events" in resolved_config["timeline"]:
            system_events = resolved_config["timeline"]["system_events"]
            if isinstance(system_events, dict):
                for event_key, event_config in system_events.items():
                    if isinstance(event_config, dict) and "details" in event_config:
                        details = event_config["details"]
                        if isinstance(details, list):
                            event_config["details"] = [
                                extractor._resolve_field_reference(detail_config, resolved_config)
                                for detail_config in details
                            ]
        
        return resolved_config
    
    def _load_case_config(pipeline_id: str) -> Optional[Dict[str, Any]]:
        """
        Load case configuration for a pipeline.
        
        Args:
            pipeline_id: Pipeline ID
            
        Returns:
            Case config dictionary with field references resolved, or None if not found
        """
        try:
            project_dir = app.state.project_dir
            project_path = Path(project_dir)
            
            # Load pipeline config to get operations.config_file
            pipeline_config_path = project_path / "config" / "pipelines" / f"{pipeline_id}.yml"
            if not pipeline_config_path.exists():
                logger.warning("Pipeline config not found: {}", pipeline_config_path)
                return None
            
            with open(pipeline_config_path, "r", encoding="utf-8") as f:
                pipeline_config = yaml.safe_load(f) or {}
            
            # Get operations config file path
            operations = pipeline_config.get("operations") or {}
            operations_config_file = operations.get("config_file")
            
            # Apply default path resolution if not specified
            if not operations_config_file:
                operations_config_file = resolve_config_path(
                    None, "operations/{id}.yml", pipeline_id
                )
            
            if not operations_config_file:
                logger.debug("No operations.config_file for pipeline: {}", pipeline_id)
                return None
            
            # Load operations config
            case_config_path = project_path / "config" / operations_config_file
            if not case_config_path.exists():
                logger.warning("Case config file not found: {}", case_config_path)
                return None
            
            with open(case_config_path, "r", encoding="utf-8") as f:
                case_config = yaml.safe_load(f) or {}
            
            # Resolve field references for frontend consumption
            case_config = _resolve_field_references_in_config(case_config)
            
            # Replace {ASSISTANT_NAME} placeholder in summary_label fields with actual assistant name
            from topaz_agent_kit.utils.assistant_config import load_ui_manifest, get_assistant_config
            try:
                ui_manifest = load_ui_manifest(project_path)
                assistant_config = get_assistant_config(ui_manifest, "operations")
                assistant_name = assistant_config.get("name", "Jarvis")
                
                def replace_assistant_name(obj: Any) -> Any:
                    """Recursively replace {ASSISTANT_NAME} placeholder in strings"""
                    if isinstance(obj, dict):
                        return {k: replace_assistant_name(v) for k, v in obj.items()}
                    elif isinstance(obj, list):
                        return [replace_assistant_name(item) for item in obj]
                    elif isinstance(obj, str):
                        return obj.replace("{ASSISTANT_NAME}", assistant_name)
                    return obj
                
                case_config = replace_assistant_name(case_config)
            except Exception as e:
                logger.debug("Failed to replace assistant name placeholder in case config: {}", e)
            
            return case_config
        except Exception as e:
            logger.error("Error loading case config for pipeline {}: {}", pipeline_id, e)
            return None
    
    def _convert_time_range_to_dates(time_range: Optional[str]) -> Tuple[Optional[str], Optional[str]]:
        """
        Convert time_range string to from_date and to_date.
        
        Args:
            time_range: Time range string (today, 7d, 30d, 90d, all)
            
        Returns:
            Tuple of (from_date, to_date) in ISO format
        """
        if not time_range or time_range == "all":
            return (None, None)
        
        now = datetime.now()
        
        if time_range == "today":
            start_date = datetime(now.year, now.month, now.day)
            return (start_date.isoformat(), None)
        elif time_range == "7d":
            start_date = (now - timedelta(days=7)).replace(hour=0, minute=0, second=0, microsecond=0)
            return (start_date.isoformat(), None)
        elif time_range == "30d":
            start_date = (now - timedelta(days=30)).replace(hour=0, minute=0, second=0, microsecond=0)
            return (start_date.isoformat(), None)
        elif time_range == "90d":
            start_date = (now - timedelta(days=90)).replace(hour=0, minute=0, second=0, microsecond=0)
            return (start_date.isoformat(), None)
        else:
            return (None, None)
    
    @app.get("/api/cases/config/{pipeline_id}")
    async def get_case_config(pipeline_id: str) -> JSONResponse:
        """Get case configuration for a pipeline"""
        try:
            case_config = _load_case_config(pipeline_id)
            if not case_config:
                return JSONResponse({
                    "success": False,
                    "error": "Case config not found for this pipeline"
                }, status_code=404)
            
            return JSONResponse({"success": True, "config": case_config})
        except Exception as e:
            logger.error("Error getting case config for pipeline {}: {}", pipeline_id, e)
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)
    
    @app.get("/api/cases/analytics/{pipeline_id}")
    async def get_pipeline_analytics(
        pipeline_id: str,
        status: Optional[str] = None,
        time_range: Optional[str] = None,
        search: Optional[str] = None,
    ) -> JSONResponse:
        """Get pipeline-specific analytics based on case YAML dashboard config"""
        try:
            # Load case config
            case_config = _load_case_config(pipeline_id)
            if not case_config:
                return JSONResponse({
                    "success": False,
                    "error": "Case config not found for this pipeline"
                }, status_code=404)
            
            dashboard_config = case_config.get("dashboard")
            if not dashboard_config:
                # No dashboard section at all -> treat as not enabled
                return JSONResponse({
                    "success": False,
                    "error": "Dashboard not enabled for this pipeline"
                }, status_code=404)
            
            # If an explicit enabled flag is provided and set to false, respect it.
            if dashboard_config.get("enabled") is False:
                return JSONResponse({
                    "success": False,
                    "error": "Dashboard not enabled for this pipeline"
                }, status_code=404)
            
            # Get managers
            managers = _get_hitl_managers()
            case_manager = managers["case_manager"]
            
            # Convert time_range to from_date/to_date
            from_date, to_date = _convert_time_range_to_dates(time_range)
            
            # Get filtered cases (same logic as list_cases endpoint)
            cases = case_manager.list_cases(
                pipeline_id=pipeline_id,
                status=status,
                from_date=from_date,
                to_date=to_date,
                limit=10000,  # High limit to get all cases for aggregation
            )
            
            # Apply search filter if provided
            if search:
                search_upper = search.upper()
                cases = [
                    c for c in cases
                    if search_upper in c.get("case_id", "").upper()
                    or search_upper in c.get("pipeline_id", "").replace("_", " ").upper()
                ]
            
            # Initialize aggregator
            from topaz_agent_kit.core.analytics_aggregator import AnalyticsAggregator
            aggregator = AnalyticsAggregator(logger)
            
            # Process each card configuration
            analytics = {}
            cards = dashboard_config.get("cards", [])
            
            for card_config in cards:
                # Skip default cards (they don't need aggregation)
                if card_config.get("type") == "default":
                    continue
                
                # Generate card ID from title if not provided
                card_id = card_config.get("id")
                if not card_id:
                    title = card_config.get("title", "unknown")
                    # Match frontend logic: replace all whitespace with single underscore
                    import re
                    card_id = re.sub(r'\s+', '_', title.lower()).replace("-", "_")
                
                try:
                    result = aggregator.aggregate(cases, card_config)
                    analytics[card_id] = result
                    logger.debug("Aggregated card '{}' (id: '{}'): {}", card_config.get("title"), card_id, result)
                except Exception as e:
                    logger.error("Error aggregating card {}: {}", card_id, e)
                    analytics[card_id] = {"error": str(e)}
            
            return JSONResponse({"success": True, "analytics": analytics})
        except Exception as e:
            logger.error("Error getting analytics for pipeline {}: {}", pipeline_id, e)
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)
    
    # --- Operations Chat Endpoint ---
    
    # Store operations assistants per session
    operations_assistants: Dict[str, OperationsAssistant] = {}
    
    @app.post("/api/chat/operations")
    async def operations_chat(req: Request) -> JSONResponse:
        """Handle operations chat requests with context-aware assistant"""
        try:
            body = await req.json()
            message = body.get("message", "").strip()
            context = body.get("context", {})  # {case_id, queue_item_id, etc.}
            session_id = body.get("session_id")
            location_data = body.get("location")  # Browser geolocation data (optional)
            
            if not message:
                return JSONResponse({"success": False, "error": "Message is required"}, status_code=400)
            
            # Get or create operations assistant
            # Use a session key based on project_dir to maintain state
            assistant_key = f"{project_dir}-{session_id or 'default'}"
            
            if assistant_key not in operations_assistants:
                try:
                    # Get database and resume handler from HITL managers
                    managers = _get_hitl_managers()
                    hitl_queue_manager = managers["hitl_queue_manager"]
                    case_manager = managers["case_manager"]
                    database = hitl_queue_manager.database
                    resume_handler = managers.get("resume_handler")
                    
                    assistant = OperationsAssistant(
                        config=cfg,
                        project_dir=project_dir,
                        database=database,
                        session_id=session_id,
                        resume_handler=resume_handler,
                        case_manager=case_manager,
                    )
                    await assistant.initialize()
                    operations_assistants[assistant_key] = assistant
                    logger.info("Created new operations assistant for session: {}", assistant_key)
                except Exception as e:
                    logger.error("Failed to create operations assistant: {}", e)
                    logger.error("Traceback: {}", traceback.format_exc())
                    return JSONResponse({"success": False, "error": f"Failed to initialize assistant: {str(e)}"}, status_code=500)
            
            assistant = operations_assistants[assistant_key]
            
            # Set browser location in context (preferred over IP geolocation)
            if location_data and isinstance(location_data, dict):
                latitude = location_data.get("latitude")
                longitude = location_data.get("longitude")
                if latitude is not None and longitude is not None:
                    from topaz_agent_kit.orchestration.assistant_tools import set_browser_location
                    set_browser_location({
                        "latitude": float(latitude),
                        "longitude": float(longitude),
                        "accuracy": location_data.get("accuracy"),  # Optional, in meters
                    })
                    logger.debug("Set browser location in context: lat={}, lon={}", latitude, longitude)
            
            # Extract client IP from request for location geolocation (fallback)
            # Only use IP if browser location is not available
            if not location_data:
                # Try multiple headers in order of preference (some proxies use different headers)
                client_ip = None
                try:
                    # 1. Try X-Forwarded-For header (most common, for proxies/load balancers)
                    forwarded_for = req.headers.get("X-Forwarded-For")
                    if forwarded_for:
                        # X-Forwarded-For can contain multiple IPs, take the first one (original client)
                        client_ip = forwarded_for.split(",")[0].strip()
                        logger.debug("Got client IP from X-Forwarded-For: {}", client_ip)
                    
                    # 2. Try X-Real-IP header (used by some proxies like nginx)
                    if not client_ip or client_ip in ("127.0.0.1", "::1", "localhost"):
                        real_ip = req.headers.get("X-Real-IP")
                        if real_ip:
                            client_ip = real_ip.strip()
                            logger.debug("Got client IP from X-Real-IP: {}", client_ip)
                    
                    # 3. Try CF-Connecting-IP header (Cloudflare)
                    if not client_ip or client_ip in ("127.0.0.1", "::1", "localhost"):
                        cf_ip = req.headers.get("CF-Connecting-IP")
                        if cf_ip:
                            client_ip = cf_ip.strip()
                            logger.debug("Got client IP from CF-Connecting-IP: {}", client_ip)
                    
                    # 4. Fallback to direct client IP
                    if not client_ip or client_ip in ("127.0.0.1", "::1", "localhost"):
                        if req.client:
                            client_ip = req.client.host
                            logger.debug("Got client IP from request.client.host: {}", client_ip)
                except Exception as e:
                    logger.debug("Failed to extract client IP: {}", e)
                
                # Set client IP in context for location tool (skip localhost/reserved IPs)
                # Localhost IPs can't be geolocated, so we'll fall back to server IP
                if client_ip and client_ip not in ("127.0.0.1", "::1", "localhost"):
                    from topaz_agent_kit.orchestration.assistant_tools import set_client_ip
                    set_client_ip(client_ip)
                    logger.debug("Set client IP in context: {}", client_ip)
                elif client_ip:
                    logger.debug("Client IP is localhost ({}), will use server IP for geolocation", client_ip)
            
            # Log user input
            logger.input("Operations Assistant - User message: {}", message)
            if context:
                logger.input("Operations Assistant - Context: {}", context)
            
            # Execute the message (execute() handles context updates internally)
            result = await assistant.execute(user_message=message, context=context)
            
            # Log assistant response
            assistant_response = result.get("assistant_response", "No response generated")
            tool_executed = result.get("tool_executed")
            widgets = result.get("widgets")
            logger.output(
                "Operations Assistant - Response: response_length={}, tool_executed={}, widgets={}",
                len(assistant_response), tool_executed, len(widgets) if widgets else 0
            )
            if assistant_response:
                logger.output("Operations Assistant - Reply preview: {}", assistant_response[:200] + ("..." if len(assistant_response) > 200 else ""))
            if tool_executed:
                logger.output("Operations Assistant - Tool executed: {}", tool_executed)
            if widgets:
                logger.output("Operations Assistant - Widgets: {}", [w.get("widget_type", "unknown") for w in widgets])
            
            response_data = {
                "success": True,
                "response": assistant_response,
                "tool_executed": tool_executed,
                "raw_tool_output": result.get("raw_tool_output"),
            }
            if widgets:
                response_data["widgets"] = widgets
            
            return JSONResponse(response_data)
            
        except Exception as e:
            logger.error("Error in operations chat: {}", e)
            logger.error("Traceback: {}", traceback.format_exc())
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    @app.post("/api/operations/feedback")
    async def operations_feedback(req: Request) -> JSONResponse:
        """Store feedback for operations chat messages"""
        try:
            body = await req.json()
            session_id = body.get("session_id")
            message_id = body.get("message_id")
            feedback_type = body.get("feedback_type")
            comment = body.get("comment", "")
            
            if not session_id:
                return JSONResponse({"error": "session_id is required"}, status_code=400)
            
            if not message_id:
                return JSONResponse({"error": "message_id is required"}, status_code=400)
            
            if feedback_type not in ["up", "down"]:
                return JSONResponse({"error": "feedback_type must be 'up' or 'down'"}, status_code=400)
            
            # Prepare feedback data
            from datetime import datetime
            feedback_data = {
                "type": feedback_type,
                "comment": comment,
                "timestamp": datetime.now().isoformat(),
                "session_id": session_id,
                "message_id": message_id,
            }
            
            # For now, just log the feedback
            # TODO: Store in database if needed (could add a feedback table or store in session metadata)
            logger.info(
                "Operations chat feedback received: session_id={}, message_id={}, type={}, has_comment={}",
                session_id,
                message_id,
                feedback_type,
                bool(comment),
            )
            
            return JSONResponse({
                "ok": True,
                "session_id": session_id,
                "message_id": message_id,
                "feedback_type": feedback_type,
            })
            
        except Exception as e:
            logger.error("Failed to submit operations feedback: {}", e, exc_info=True)
            return JSONResponse({"error": "Failed to submit feedback", "details": str(e)}, status_code=500)

    # ==========================================================================
    # APP SESSION MODE ENDPOINTS
    # ==========================================================================
    
    def _load_app_config_from_registry(app_id: str) -> Optional[Dict[str, Any]]:
        """
        Load app configuration from apps.yml registry with default path resolution.
        
        Args:
            app_id: The app ID to load
            
        Returns:
            App config dict if found, None otherwise
            
        Default behavior:
            - If config_file is missing in registry → defaults to "apps/{app_id}.yml"
            - If config_file is specified → uses explicit path
        """
        try:
            registry_path = Path(project_dir) / "config" / "apps.yml"
            if not registry_path.exists():
                # Fallback: try direct path with default
                default_path = resolve_config_path(None, "apps/{id}.yml", app_id)
                manifest_path = Path(project_dir) / "config" / default_path
                if manifest_path.exists():
                    with open(manifest_path, "r") as f:
                        return yaml.safe_load(f)
                return None
            
            with open(registry_path, "r") as f:
                registry = yaml.safe_load(f) or {}
            
            # Find app entry in registry
            for app_entry in registry.get("apps", []):
                if app_entry.get("id") == app_id:
                    # Apply default path resolution
                    config_file = app_entry.get("config_file")
                    if app_id:
                        resolved_config_file = resolve_config_path(config_file, "apps/{id}.yml", app_id)
                    else:
                        resolved_config_file = config_file
                    
                    if not resolved_config_file:
                        return None
                    
                    manifest_path = Path(project_dir) / "config" / resolved_config_file
                    if manifest_path.exists():
                        with open(manifest_path, "r") as f:
                            return yaml.safe_load(f)
                    break
            
            return None
        except Exception as e:
            logger.debug("Failed to load app config for {}: {}", app_id, e)
            return None
    
    @app.post("/api/app/sessions")
    async def create_app_session(request: Request) -> JSONResponse:
        """Create a new app session"""
        try:
            body = await request.json()
            app_id = body.get("app_id")
            title = body.get("title")
            initial_state = body.get("initial_state", {})
            
            if not app_id:
                return JSONResponse({"error": "app_id is required"}, status_code=400)
            
            _, _, _, _, _, app_store = get_shared_services()
            
            app_session_id = app_store.create_session(
                app_id=app_id,
                title=title,
                initial_state=initial_state,
            )
            
            session = app_store.get_session(app_session_id)
            if not session:
                return JSONResponse({"error": "Failed to retrieve created session"}, status_code=500)
            
            return JSONResponse({
                "app_session_id": session.app_session_id,
                "app_id": session.app_id,
                "title": session.title,
                "state": session.state,
                "created_at": session.created_at.isoformat(),
                "updated_at": session.updated_at.isoformat(),
            }, status_code=201)
            
        except Exception as e:
            logger.error("Failed to create app session: {}", e, exc_info=True)
            return JSONResponse({"error": "Failed to create app session", "details": str(e)}, status_code=500)
    
    @app.post("/api/app/launch-from-case")
    async def launch_app_from_case(request: Request) -> JSONResponse:
        """Launch an app from a case with case data pre-loaded"""
        try:
            body = await request.json()
            case_id = body.get("case_id")
            app_id = body.get("app_id")
            
            if not case_id:
                return JSONResponse({"error": "case_id is required"}, status_code=400)
            if not app_id:
                return JSONResponse({"error": "app_id is required"}, status_code=400)
            
            # Get case manager and app store
            managers = _get_hitl_managers()
            case_manager = managers["case_manager"]
            _, _, _, _, _, app_store = get_shared_services()
            
            # Get case data
            case = case_manager.get_case(case_id)
            if not case:
                return JSONResponse({"error": f"Case {case_id} not found"}, status_code=404)
            
            # Check if case is accessible (status check)
            case_status = case.get("status")
            if case_status not in ["hitl_pending", "processing", "completed", "failed"]:
                return JSONResponse({"error": f"Case {case_id} has invalid status: {case_status}"}, status_code=400)
            
            # Load app config for transformation
            app_config = _load_app_config_from_registry(app_id)
            if not app_config:
                return JSONResponse({"error": f"App config not found for app_id: {app_id}"}, status_code=404)
            
            # Check if a session already exists for this case
            existing_sessions = app_store.list_sessions(app_id=app_id, limit=100, offset=0)
            existing_session = None
            
            for sess in existing_sessions:
                sess_obj = app_store.get_session(sess.app_session_id)
                if sess_obj and sess_obj.state:
                    metadata = sess_obj.state.get("_metadata", {})
                    if metadata.get("case_id") == case_id:
                        existing_session = sess_obj
                        logger.info("Found existing app session for case: {}", case_id)
                        break
            
            # Check if existing session should be refreshed
            should_refresh_session = False
            if existing_session:
                # Check if session has empty data
                if isinstance(existing_session.state, dict) and "invoice_review" in existing_session.state:
                    invoice_review = existing_session.state.get("invoice_review", {})
                    if isinstance(invoice_review, dict):
                        invoice = invoice_review.get("invoice", {})
                        # Check if key fields are empty
                        if not invoice.get("invoice_number") and not invoice.get("vendor_name") and not invoice.get("total_amount"):
                            logger.info("Existing session {} has empty data, will refresh with transformed data", existing_session.app_session_id)
                            should_refresh_session = True
                            # Delete the empty session
                            app_store.delete_session(existing_session.app_session_id)
                            existing_session = None
                
                # Check if case has been updated since session was created
                if not should_refresh_session and existing_session:
                    from datetime import datetime
                    case_updated_at = case.get("updated_at")
                    session_metadata = existing_session.state.get("_metadata", {}) if isinstance(existing_session.state, dict) else {}
                    session_created_at = session_metadata.get("session_created_at")
                    
                    # If session doesn't have creation timestamp (backward compatibility), refresh to ensure fresh data
                    if not session_created_at:
                        logger.info("Existing session {} doesn't have session_created_at timestamp, will refresh to ensure fresh data", existing_session.app_session_id)
                        should_refresh_session = True
                        app_store.delete_session(existing_session.app_session_id)
                        existing_session = None
                    elif case_updated_at:
                        try:
                            # Parse timestamps
                            case_updated = datetime.fromisoformat(case_updated_at.replace('Z', '+00:00')) if isinstance(case_updated_at, str) else case_updated_at
                            session_created = datetime.fromisoformat(session_created_at.replace('Z', '+00:00')) if isinstance(session_created_at, str) else session_created_at
                            
                            # Compare timestamps (case updated after session created)
                            if case_updated > session_created:
                                logger.info("Case {} was updated after session {} was created (case: {}, session: {}), will refresh session", 
                                          case_id, existing_session.app_session_id, case_updated_at, session_created_at)
                                should_refresh_session = True
                                # Delete the old session
                                app_store.delete_session(existing_session.app_session_id)
                                existing_session = None
                        except Exception as e:
                            logger.warning("Failed to compare timestamps for case {} and session {}: {}", case_id, existing_session.app_session_id, e)
                            # On error, don't refresh (safer to reuse existing session)
            
            if existing_session and not should_refresh_session:
                # Use existing session with valid data
                session = existing_session
                logger.info("Reusing existing app session {} for case {}", session.app_session_id, case_id)
            else:
                # Transform case data to app state
                from topaz_agent_kit.core.case_to_app_transformer import CaseToAppTransformer
                project_dir = request.app.state.project_dir
                transformer = CaseToAppTransformer(project_dir=project_dir)
                initial_state = transformer.transform_case_to_app_state(case, app_id, app_config=app_config)
                
                # Log transformation result for debugging
                logger.info("Transformed case data to app state - case_id: {}, app_id: {}, keys: {}, has_invoice_review: {}", 
                           case_id, app_id,
                           list(initial_state.keys()) if isinstance(initial_state, dict) else [],
                           "invoice_review" in initial_state if isinstance(initial_state, dict) else False)
                
                # Log sample values
                if isinstance(initial_state, dict) and "invoice_review" in initial_state:
                    invoice_review = initial_state.get("invoice_review", {})
                    if isinstance(invoice_review, dict):
                        invoice = invoice_review.get("invoice", {})
                        logger.info("Sample transformed values - invoice_number: '{}', vendor: '{}', amount: '{}'",
                                   invoice.get("invoice_number", ""),
                                   invoice.get("vendor_name", ""),
                                   invoice.get("total_amount", ""))
                
                # Merge case_id and session creation timestamp into the initial_state before creating session
                if initial_state:
                    if "_metadata" not in initial_state:
                        initial_state["_metadata"] = {}
                    initial_state["_metadata"]["case_id"] = case_id
                    # Store session creation timestamp for future refresh checks
                    from datetime import datetime
                    initial_state["_metadata"]["session_created_at"] = datetime.now().isoformat()
                
                # Create app session with case_id metadata and initial state
                # Use app title or fallback
                app_title = app_config.get("title", app_id.replace("_", " ").title())
                session_title = f"{app_title}: {case_id}"
                app_session_id = app_store.create_session(
                    app_id=app_id,
                    title=session_title,
                    initial_state=initial_state,
                )
                
                session = app_store.get_session(app_session_id)
            
            if not session:
                return JSONResponse({"error": "Failed to retrieve created session"}, status_code=500)
            
            # Log final session state for debugging
            logger.info("Created app session from case - session_id: {}, case_id: {}, state_keys: {}, has_invoice_review: {}, has_metadata: {}", 
                       session.app_session_id, case_id,
                       list(session.state.keys()) if isinstance(session.state, dict) else [],
                       "invoice_review" in session.state if isinstance(session.state, dict) else False,
                       "_metadata" in session.state if isinstance(session.state, dict) else False)
            
            # Log sample values from final session state
            if isinstance(session.state, dict) and "invoice_review" in session.state:
                invoice_review = session.state.get("invoice_review", {})
                if isinstance(invoice_review, dict):
                    invoice = invoice_review.get("invoice", {})
                    logger.info("Final session state sample - invoice_number: '{}', vendor: '{}', amount: '{}'",
                               invoice.get("invoice_number", ""),
                               invoice.get("vendor_name", ""),
                               invoice.get("total_amount", ""))
            
            return JSONResponse({
                "app_session_id": session.app_session_id,
                "app_id": session.app_id,
                "title": session.title,
                "state": session.state,
                "case_id": case_id,
                "redirect_url": f"/app/{app_id}?session_id={session.app_session_id}",
                "created_at": session.created_at.isoformat(),
                "updated_at": session.updated_at.isoformat(),
            }, status_code=201)
            
        except Exception as e:
            logger.error("Failed to launch app from case: {}", e, exc_info=True)
            return JSONResponse({"error": "Failed to launch app from case", "details": str(e)}, status_code=500)
    
    @app.get("/api/app/sessions")
    async def list_app_sessions(app_id: Optional[str] = None, limit: int = 50, offset: int = 0) -> JSONResponse:
        """List app sessions, optionally filtered by app_id"""
        try:
            _, _, _, _, _, app_store = get_shared_services()
            
            sessions = app_store.list_sessions(app_id=app_id, limit=limit, offset=offset)
            
            return JSONResponse({
                "sessions": [
                    {
                        "app_session_id": s.app_session_id,
                        "app_id": s.app_id,
                        "title": s.title,
                        "state": s.state,
                        "created_at": s.created_at.isoformat(),
                        "updated_at": s.updated_at.isoformat(),
                        "pinned": s.pinned,
                        "pinned_order": s.pinned_order,
                    }
                    for s in sessions
                ],
                "count": len(sessions),
            })
            
        except Exception as e:
            logger.error("Failed to list app sessions: {}", e, exc_info=True)
            return JSONResponse({"error": "Failed to list app sessions", "details": str(e)}, status_code=500)
    
    @app.get("/api/app/sessions/{app_session_id}")
    async def get_app_session(app_session_id: str) -> JSONResponse:
        """Get app session by ID (with chat turns)"""
        try:
            _, _, _, _, _, app_store = get_shared_services()
            
            session_data = app_store.get_session_with_turns(app_session_id)
            if not session_data:
                return JSONResponse({"error": "App session not found"}, status_code=404)
            
            return JSONResponse(session_data)
            
        except Exception as e:
            logger.error("Failed to get app session {}: {}", app_session_id, e, exc_info=True)
            return JSONResponse({"error": "Failed to get app session", "details": str(e)}, status_code=500)
    
    @app.put("/api/app/sessions/{app_session_id}/state")
    async def update_app_session_state(app_session_id: str, request: Request) -> JSONResponse:
        """Update app session canvas state"""
        try:
            body = await request.json()
            state = body.get("state")
            
            if state is None:
                return JSONResponse({"error": "state is required"}, status_code=400)
            
            _, _, _, _, _, app_store = get_shared_services()
            
            success = app_store.update_state(app_session_id, state)
            if not success:
                return JSONResponse({"error": "App session not found"}, status_code=404)
            
            session = app_store.get_session(app_session_id)
            return JSONResponse({
                "app_session_id": session.app_session_id,
                "state": session.state,
                "updated_at": session.updated_at.isoformat(),
            })
            
        except Exception as e:
            logger.error("Failed to update app session state {}: {}", app_session_id, e, exc_info=True)
            return JSONResponse({"error": "Failed to update app session state", "details": str(e)}, status_code=500)
    
    @app.patch("/api/app/sessions/{app_session_id}/state")
    async def patch_app_session_state(app_session_id: str, request: Request) -> JSONResponse:
        """Patch app session canvas state (merge with existing)
        
        Supports validation if app manifest is available.
        Returns validation errors in response if validation fails.
        """
        try:
            body = await request.json()
            patch = body.get("patch")
            
            if patch is None:
                return JSONResponse({"error": "patch is required"}, status_code=400)
            
            _, _, _, _, _, app_store = get_shared_services()
            
            # Try to get app manifest for validation
            manifest = None
            try:
                session = app_store.get_session(app_session_id)
                if session:
                    # Load manifest for this app
                    manifest = _load_app_config_from_registry(session.app_id)
            except Exception as e:
                logger.debug("Could not load manifest for validation: {}", e)
            
            # Patch state with validation
            result = app_store.patch_state(
                app_session_id=app_session_id,
                patch=patch,
                manifest=manifest,
                validate=True
            )
            
            # Handle new return signature: (success, errors)
            if isinstance(result, tuple):
                success, errors = result
            else:
                # Backward compatibility: old signature returns bool
                success = result
                errors = None
            
            if not success:
                if errors:
                    # Validation errors
                    return JSONResponse({
                        "error": "Validation failed",
                        "validation_errors": errors
                    }, status_code=400)
                else:
                    # Session not found
                    return JSONResponse({"error": "App session not found"}, status_code=404)
            
            session = app_store.get_session(app_session_id)
            response_data = {
                "app_session_id": session.app_session_id,
                "state": session.state,
                "updated_at": session.updated_at.isoformat(),
            }
            
            # Include validation warnings if any
            if errors:
                response_data["validation_warnings"] = errors
            
            return JSONResponse(response_data)
            
        except Exception as e:
            logger.error("Failed to patch app session state {}: {}", app_session_id, e, exc_info=True)
            return JSONResponse({"error": "Failed to patch app session state", "details": str(e)}, status_code=500)
    
    @app.put("/api/app/sessions/{app_session_id}/title")
    async def update_app_session_title(app_session_id: str, request: Request) -> JSONResponse:
        """Update app session title"""
        try:
            body = await request.json()
            title = body.get("title")
            
            if title is None:
                return JSONResponse({"error": "title is required"}, status_code=400)
            
            _, _, _, _, _, app_store = get_shared_services()
            
            success = app_store.update_title(app_session_id, title)
            if not success:
                return JSONResponse({"error": "App session not found"}, status_code=404)
            
            session = app_store.get_session(app_session_id)
            return JSONResponse({
                "app_session_id": session.app_session_id,
                "title": session.title,
                "updated_at": session.updated_at.isoformat(),
            })
            
        except Exception as e:
            logger.error("Failed to update app session title {}: {}", app_session_id, e, exc_info=True)
            return JSONResponse({"error": "Failed to update app session title", "details": str(e)}, status_code=500)
    
    @app.delete("/api/app/sessions/{app_session_id}")
    async def delete_app_session(app_session_id: str) -> JSONResponse:
        """Delete app session and its chat turns"""
        try:
            _, _, _, _, _, app_store = get_shared_services()
            
            success = app_store.delete_session(app_session_id)
            if not success:
                return JSONResponse({"error": "App session not found"}, status_code=404)
            
            return JSONResponse({"message": "App session deleted successfully"})
            
        except Exception as e:
            logger.error("Failed to delete app session {}: {}", app_session_id, e, exc_info=True)
            return JSONResponse({"error": "Failed to delete app session", "details": str(e)}, status_code=500)
    
    @app.put("/api/app/sessions/{app_session_id}/pin")
    async def update_app_session_pin(app_session_id: str, request: Request) -> JSONResponse:
        """Update the pinned status of an app session"""
        try:
            body = await request.json()
            pinned = body.get("pinned", False)
            pinned_order = body.get("pinned_order")
            
            _, _, _, _, _, app_store = get_shared_services()
            
            success = app_store.update_pinned(app_session_id, pinned, pinned_order)
            if not success:
                return JSONResponse({"error": "App session not found"}, status_code=404)
            
            return JSONResponse({
                "app_session_id": app_session_id,
                "pinned": pinned,
                "pinned_order": pinned_order or 0,
            })
            
        except Exception as e:
            logger.error("Failed to update app session pin {}: {}", app_session_id, e, exc_info=True)
            return JSONResponse({"error": "Failed to update app session pin", "details": str(e)}, status_code=500)
    
    @app.post("/api/app/sessions/{app_session_id}/chat")
    async def add_app_chat_turn(app_session_id: str, request: Request) -> JSONResponse:
        """Add a chat turn to app session"""
        try:
            body = await request.json()
            role = body.get("role")
            content = body.get("content")
            widgets = body.get("widgets")  # Optional widgets
            
            if not role:
                return JSONResponse({"error": "role is required"}, status_code=400)
            if not content:
                return JSONResponse({"error": "content is required"}, status_code=400)
            
            _, _, _, _, _, app_store = get_shared_services()
            
            turn_id = app_store.add_chat_turn(app_session_id, role, content, widgets)
            if turn_id is None:
                return JSONResponse({"error": "Failed to add chat turn"}, status_code=500)
            
            return JSONResponse({
                "id": turn_id,
                "app_session_id": app_session_id,
                "role": role,
                "content": content,
                "widgets": widgets,  # Include widgets in response
            }, status_code=201)
            
        except Exception as e:
            logger.error("Failed to add chat turn to app session {}: {}", app_session_id, e, exc_info=True)
            return JSONResponse({"error": "Failed to add chat turn", "details": str(e)}, status_code=500)
    
    @app.get("/api/app/sessions/{app_session_id}/chat")
    async def get_app_chat_turns(app_session_id: str, limit: int = 100, offset: int = 0) -> JSONResponse:
        """Get chat turns for app session"""
        try:
            _, _, _, _, _, app_store = get_shared_services()
            
            turns = app_store.get_chat_turns(app_session_id, limit=limit, offset=offset)
            
            return JSONResponse({
                "turns": [
                    {
                        "id": t.id,
                        "app_session_id": t.app_session_id,
                        "role": t.role,
                        "content": t.content,
                        "widgets": t.widgets,  # Include widgets
                        "created_at": t.created_at.isoformat(),
                    }
                    for t in turns
                ],
                "count": len(turns),
            })
            
        except Exception as e:
            logger.error("Failed to get chat turns for app session {}: {}", app_session_id, e, exc_info=True)
            return JSONResponse({"error": "Failed to get chat turns", "details": str(e)}, status_code=500)
    
    @app.delete("/api/app/sessions/{app_session_id}/chat")
    async def clear_app_chat_turns(app_session_id: str) -> JSONResponse:
        """Clear chat turns for app session"""
        try:
            _, _, _, _, _, app_store = get_shared_services()
            
            success = app_store.clear_chat_turns(app_session_id)
            if not success:
                return JSONResponse({"error": "Failed to clear chat turns"}, status_code=500)
            
            return JSONResponse({"message": "Chat turns cleared successfully"})
            
        except Exception as e:
            logger.error("Failed to clear chat turns for app session {}: {}", app_session_id, e, exc_info=True)
            return JSONResponse({"error": "Failed to clear chat turns", "details": str(e)}, status_code=500)
    
    # Store app assistants per session
    app_assistants: Dict[str, Any] = {}  # Any to avoid import at top level
    
    @app.post("/api/app/chat")
    async def app_chat(request: Request) -> JSONResponse:
        """
        Handle app chat requests - run AppAssistant with user message.
        
        Request body:
            app_session_id: str - The session ID
            user_text: str - User's message
            
        Response:
            On success: { reply: str, state: dict }
            On error: { error: str, state: dict }
        """
        try:
            body = await request.json()
            app_session_id = body.get("app_session_id")
            user_text = body.get("user_text", "").strip()
            location_data = body.get("location")  # Browser geolocation data (optional)
            
            if not app_session_id:
                return JSONResponse({"error": "app_session_id is required"}, status_code=400)
            
            if not user_text:
                return JSONResponse({"error": "user_text is required"}, status_code=400)
            
            # Get shared services (initializes app_session_store if needed)
            _, _, _, _, _, app_session_store = get_shared_services()
            
            # Get session to determine app_id
            session = app_session_store.get_session(app_session_id)
            if not session:
                return JSONResponse({"error": f"Session {app_session_id} not found"}, status_code=404)
            
            app_id = session.app_id
            
            # Load app manifest/config from registry with default path resolution
            app_config = _load_app_config_from_registry(app_id)
            if not app_config:
                return JSONResponse({"error": f"App manifest not found for app_id: {app_id}"}, status_code=404)
            
            # Check if app_assistant is configured
            if not app_config.get("app_assistant"):
                return JSONResponse({
                    "error": "App assistant not configured for this app",
                    "state": session.state,
                }, status_code=400)
            
            # Get or create AppAssistant
            assistant_key = f"{project_dir}-{app_session_id}"
            
            if assistant_key not in app_assistants:
                try:
                    from topaz_agent_kit.orchestration.app_assistant import AppAssistant
                    
                    assistant = AppAssistant(
                        app_config=app_config,
                        app_session_id=app_session_id,
                        project_dir=project_dir,
                        app_session_store=app_session_store,
                    )
                    await assistant.initialize()
                    app_assistants[assistant_key] = assistant
                    logger.info("Created new app assistant for session: {}", assistant_key)
                except Exception as e:
                    logger.error("Failed to create app assistant: {}", e)
                    logger.error("Traceback: {}", traceback.format_exc())
                    return JSONResponse({
                        "error": f"Failed to initialize app assistant: {str(e)}",
                        "state": session.state,
                    }, status_code=500)
            
            assistant = app_assistants[assistant_key]
            
            # Extract client IP from request for location geolocation
            # Try multiple headers in order of preference (some proxies use different headers)
            client_ip = None
            try:
                # 1. Try X-Forwarded-For header (most common, for proxies/load balancers)
                forwarded_for = request.headers.get("X-Forwarded-For")
                if forwarded_for:
                    # X-Forwarded-For can contain multiple IPs, take the first one (original client)
                    client_ip = forwarded_for.split(",")[0].strip()
                    logger.debug("Got client IP from X-Forwarded-For: {}", client_ip)
                
                # 2. Try X-Real-IP header (used by some proxies like nginx)
                if not client_ip or client_ip in ("127.0.0.1", "::1", "localhost"):
                    real_ip = request.headers.get("X-Real-IP")
                    if real_ip:
                        client_ip = real_ip.strip()
                        logger.debug("Got client IP from X-Real-IP: {}", client_ip)
                
                # 3. Try CF-Connecting-IP header (Cloudflare)
                if not client_ip or client_ip in ("127.0.0.1", "::1", "localhost"):
                    cf_ip = request.headers.get("CF-Connecting-IP")
                    if cf_ip:
                        client_ip = cf_ip.strip()
                        logger.debug("Got client IP from CF-Connecting-IP: {}", client_ip)
                
                # 4. Fallback to direct client IP
                if not client_ip or client_ip in ("127.0.0.1", "::1", "localhost"):
                    if request.client:
                        client_ip = request.client.host
                        logger.debug("Got client IP from request.client.host: {}", client_ip)
            except Exception as e:
                logger.debug("Failed to extract client IP: {}", e)
            
            # Set browser location in context (preferred over IP geolocation)
            if location_data and isinstance(location_data, dict):
                latitude = location_data.get("latitude")
                longitude = location_data.get("longitude")
                if latitude is not None and longitude is not None:
                    from topaz_agent_kit.orchestration.assistant_tools import set_browser_location
                    set_browser_location({
                        "latitude": float(latitude),
                        "longitude": float(longitude),
                        "accuracy": location_data.get("accuracy"),  # Optional, in meters
                    })
                    logger.debug("Set browser location in context: lat={}, lon={}", latitude, longitude)
            
            # Set client IP in context for location tool (skip localhost/reserved IPs)
            # Only use IP if browser location is not available
            if not location_data:
                if client_ip and client_ip not in ("127.0.0.1", "::1", "localhost"):
                    from topaz_agent_kit.orchestration.assistant_tools import set_client_ip
                    set_client_ip(client_ip)
                    logger.debug("Set client IP in context: {}", client_ip)
                elif client_ip:
                    logger.debug("Client IP is localhost ({}), will use server IP for geolocation", client_ip)
            
            # Log user input
            logger.input("App Assistant - User message: {}", user_text)
            
            # Execute the message
            result = await assistant.execute(user_text=user_text)
            
            # Log assistant response
            reply = result.get("reply", "")
            widgets_count = len(result.get("widgets", [])) if result.get("widgets") else 0
            has_state_update = bool(result.get("state"))
            logger.output(
                "App Assistant - Response: reply_length={}, widgets={}, has_state_update={}",
                len(reply), widgets_count, has_state_update
            )
            if reply:
                logger.output("App Assistant - Reply preview: {}", reply[:200] + ("..." if len(reply) > 200 else ""))
            if widgets_count > 0:
                widget_types = [w.get("widget_type", "unknown") for w in result.get("widgets", [])]
                logger.output("App Assistant - Widgets: {}", ", ".join(widget_types))
            
            if "error" in result:
                logger.error("App Assistant - Error: {}", result.get("error"))
                return JSONResponse({
                    "error": result["error"],
                    "state": result.get("state", {}),
                }, status_code=500)
            
            # Handle session title from assistant or fallback to first message
            suggested_title = None
            try:
                session = app_session_store.get_session(app_session_id)
                if session:
                    # Check if app allows session title updates
                    allow_title_updates = app_config.get("allow_session_title_updates", True)  # Default to True for backward compatibility
                    
                    if not allow_title_updates:
                        logger.debug("Session title updates disabled for app {}, skipping title update", app_id)
                    else:
                        # Check if assistant provided a session_title
                        assistant_title = result.get("session_title")
                        current_title = session.title or ""
                        is_first_turn = not current_title or current_title.strip() == ""
                        
                        logger.debug("Session title check - assistant_title: {}, current_title: {}, is_first_turn: {}", 
                                    assistant_title, current_title, is_first_turn)
                        
                        if assistant_title:
                            # Assistant provided a title - use it if different from current (or if first turn)
                            title_to_use = assistant_title.strip()[:100]  # Max 100 chars for database
                            if is_first_turn or title_to_use != current_title:
                                success = app_session_store.update_title(app_session_id, title_to_use)
                                if success:
                                    suggested_title = title_to_use
                                    logger.info("Updated session title from assistant for {}: '{}' -> '{}'", 
                                              app_session_id, current_title, title_to_use)
                                else:
                                    logger.warning("Failed to update session title for {}", app_session_id)
                            else:
                                logger.debug("Session title unchanged, skipping update: '{}'", title_to_use)
                        elif is_first_turn:
                            # First turn but no title from assistant - use truncated user message as fallback
                            clean_text = user_text.strip().replace("\n", " ")
                            suggested_title = clean_text[:50] + ("…" if len(clean_text) > 50 else "")
                            app_session_store.update_title(app_session_id, suggested_title)
                            logger.info("Auto-generated title from first message for session {}: {}", app_session_id, suggested_title)
            except Exception as title_err:
                logger.warning("Failed to handle session title: {}", title_err, exc_info=True)
            
            response_data = {
                "reply": result.get("reply", ""),
                "state": result.get("state", {}),
            }
            if suggested_title:
                response_data["suggested_title"] = suggested_title
            if result.get("widgets"):
                response_data["widgets"] = result.get("widgets")
            
            return JSONResponse(response_data)
            
        except Exception as e:
            logger.error("App chat error: {}", e, exc_info=True)
            _, _, _, _, _, app_session_store = get_shared_services()
            session = app_session_store.get_session(app_session_id) if app_session_id else None
            return JSONResponse({
                "error": f"App chat failed: {str(e)}",
                "state": session.state if session else {},
            }, status_code=500)
    
    @app.post("/api/app/chat/widget-interaction")
    async def widget_interaction(request: Request) -> JSONResponse:
        """
        Handle widget interactions from chat widgets (e.g., table editor submit).
        
        Request body:
            app_session_id: str - The app session ID
            turn_id: str - Original turn ID where widget was rendered
            widget_id: str - Unique widget identifier
            widget_type: str - Type of widget (e.g., "table_editor")
            action: str - Action type ("submit", "update", "click")
            data: any - Widget data (e.g., table rows)
            
        Response:
            On success: { success: true, assistant_response: str, widgets: list, state: dict }
            On error: { success: false, error: str }
        """
        try:
            body = await request.json()
            app_session_id = body.get("app_session_id")
            turn_id = body.get("turn_id")
            widget_id = body.get("widget_id")
            widget_type = body.get("widget_type")
            action = body.get("action")
            data = body.get("data")
            
            if not app_session_id:
                return JSONResponse({"success": False, "error": "app_session_id is required"}, status_code=400)
            if not widget_type:
                return JSONResponse({"success": False, "error": "widget_type is required"}, status_code=400)
            if not action:
                return JSONResponse({"success": False, "error": "action is required"}, status_code=400)
            
            # Get shared services
            _, _, _, _, _, app_session_store = get_shared_services()
            
            # Get session to determine app_id
            session = app_session_store.get_session(app_session_id)
            if not session:
                return JSONResponse({"success": False, "error": f"Session {app_session_id} not found"}, status_code=404)
            
            app_id = session.app_id
            
            # Load app manifest/config
            app_config = _load_app_config_from_registry(app_id)
            if not app_config:
                return JSONResponse({"success": False, "error": f"App manifest not found for app_id: {app_id}"}, status_code=404)
            
            # Get or create AppAssistant
            assistant_key = f"{project_dir}-{app_session_id}"
            
            if assistant_key not in app_assistants:
                try:
                    from topaz_agent_kit.orchestration.app_assistant import AppAssistant
                    
                    assistant = AppAssistant(
                        app_config=app_config,
                        app_session_id=app_session_id,
                        project_dir=project_dir,
                        app_session_store=app_session_store,
                    )
                    await assistant.initialize()
                    app_assistants[assistant_key] = assistant
                    logger.info("Created new app assistant for widget interaction: {}", assistant_key)
                except Exception as e:
                    logger.error("Failed to create app assistant for widget interaction: {}", e)
                    return JSONResponse({
                        "success": False,
                        "error": f"Failed to initialize app assistant: {str(e)}",
                    }, status_code=500)
            
            assistant = app_assistants[assistant_key]
            
            # Format user message from widget interaction
            if widget_type == "table_editor":
                if action == "submit":
                    # Convert table data to readable format
                    # Data is a 2D array: [[row1col1, row1col2, ...], [row2col1, row2col2, ...], ...]
                    # Headers are stored separately in widget props, but we'll format the data as-is
                    if data and isinstance(data, list) and len(data) > 0:
                        # Format as markdown-style table
                        table_rows = []
                        for row_idx, row in enumerate(data):
                            if row and isinstance(row, list):
                                # Join cells with | separator
                                row_text = " | ".join(str(cell) if cell is not None and cell != "" else "" for cell in row)
                                table_rows.append(row_text)
                        
                        table_text = "\n".join(table_rows)
                        # Make it clear the data is in the message itself, not in canvas
                        user_message = f"I've filled in the table with the following data. Please use this data directly from my message to update the canvas:\n\n{table_text}\n\nPlease extract the values from the table above and update the appropriate canvas fields."
                    else:
                        user_message = "I've submitted the table data. Please process it."
                else:
                    user_message = f"I've updated the {widget_type}."
            else:
                user_message = f"Widget interaction: {widget_type} - {action}"
            
            logger.input("Widget Interaction - {}: {}", widget_type, action)
            
            # Execute assistant with widget interaction message
            result = await assistant.execute(user_text=user_message)
            
            reply = result.get("reply", "")
            widgets = result.get("widgets", [])
            state_update = result.get("state")
            
            logger.output("Widget Interaction - Response: reply_length={}, widgets={}", len(reply), len(widgets))
            
            if "error" in result:
                logger.error("Widget Interaction - Error: {}", result.get("error"))
                return JSONResponse({
                    "success": False,
                    "error": result["error"],
                }, status_code=500)
            
            return JSONResponse({
                "success": True,
                "assistant_response": reply,
                "widgets": widgets,
                "state": state_update,
            }, status_code=200)
            
        except Exception as e:
            logger.error("Widget interaction error: {}", e, exc_info=True)
            return JSONResponse({
                "success": False,
                "error": f"Widget interaction failed: {str(e)}",
            }, status_code=500)
            
            return JSONResponse(response_data)
            
        except Exception as e:
            logger.error("Error in app chat: {}", e)
            logger.error("Traceback: {}", traceback.format_exc())
            
            # Try to get current state
            try:
                if app_session_store and app_session_id:
                    session = app_session_store.get_session(app_session_id)
                    current_state = session.state if session else {}
                else:
                    current_state = {}
            except Exception:
                current_state = {}
            
            return JSONResponse({
                "error": str(e),
                "state": current_state,
            }, status_code=500)
    
    @app.post("/api/app/feedback")
    async def app_feedback(req: Request) -> JSONResponse:
        """Store feedback for app chat messages"""
        try:
            body = await req.json()
            app_session_id = body.get("app_session_id")
            message_id = body.get("message_id")
            feedback_type = body.get("feedback_type")
            comment = body.get("comment", "")
            
            if not app_session_id:
                return JSONResponse({"error": "app_session_id is required"}, status_code=400)
            
            if not message_id:
                return JSONResponse({"error": "message_id is required"}, status_code=400)
            
            if feedback_type not in ["up", "down"]:
                return JSONResponse({"error": "feedback_type must be 'up' or 'down'"}, status_code=400)
            
            # Prepare feedback data
            from datetime import datetime
            feedback_data = {
                "type": feedback_type,
                "comment": comment,
                "timestamp": datetime.now().isoformat(),
                "app_session_id": app_session_id,
                "message_id": message_id,
            }
            
            # For now, just log the feedback
            # TODO: Store in database if needed (could add a feedback table or store in session metadata)
            logger.info(
                "App chat feedback received: app_session_id={}, message_id={}, type={}, has_comment={}",
                app_session_id,
                message_id,
                feedback_type,
                bool(comment),
            )
            
            return JSONResponse({"success": True, "feedback": feedback_data})
        except Exception as e:
            logger.error("Error storing app chat feedback: {}", e)
            return JSONResponse({"error": "Failed to store feedback", "details": str(e)}, status_code=500)
    
    @app.get("/api/app/manifest/{app_id}")
    async def get_app_manifest(app_id: str, request: Request) -> JSONResponse:
        """Get app manifest configuration.
        
        Loads from apps.yml registry with default path resolution: apps/{id}.yml
        Validates manifest against JSON schema.
        """
        try:
            # Load app config from registry with default path resolution
            manifest = _load_app_config_from_registry(app_id)
            
            if not manifest:
                logger.warning("App manifest not found for app_id: {}", app_id)
                return JSONResponse({"error": f"App manifest not found for app_id: {app_id}"}, status_code=404)
            
            # Validate manifest against schema
            try:
                from topaz_agent_kit.core.app_config_validator import AppConfigValidator
                project_dir = request.app.state.project_dir
                validator = AppConfigValidator(project_dir=Path(project_dir))
                is_valid, errors = validator.validate_manifest(manifest)
                
                if not is_valid:
                    logger.warning("App manifest validation failed for {}: {}", app_id, errors)
                    # Return manifest anyway but log warnings (non-blocking for now)
                    # In future, could return 400 with validation errors
                
                # Also validate binding paths semantically
                binding_valid, binding_warnings = validator.validate_binding_paths(manifest)
                if not binding_valid:
                    logger.warning("Binding path validation warnings for {}: {}", app_id, binding_warnings)
            except Exception as validation_error:
                # Don't fail if validation has issues, just log
                logger.debug("App manifest validation skipped: {}", validation_error)
            
            return JSONResponse(manifest)
            
        except yaml.YAMLError as e:
            logger.error("Failed to parse app manifest {}: {}", app_id, e)
            return JSONResponse({"error": "Invalid YAML in app manifest", "details": str(e)}, status_code=500)
        except Exception as e:
            logger.error("Failed to get app manifest {}: {}", app_id, e, exc_info=True)
            return JSONResponse({"error": "Failed to get app manifest", "details": str(e)}, status_code=500)
    
    @app.get("/api/app/manifests")
    async def list_app_manifests() -> JSONResponse:
        """List all available app manifests.
        
        Reads from config/apps.yml registry if present, otherwise scans config/apps/*.yml
        Uses default path resolution: apps/{id}.yml if config_file is not specified
        """
        try:
            apps = []
            
            # Initialize registry to empty dict (will be populated if apps.yml exists)
            registry = {}
            
            # First try to read from apps.yml registry (preferred)
            registry_path = Path(project_dir) / "config" / "apps.yml"
            if registry_path.exists():
                with open(registry_path, "r") as f:
                    registry = yaml.safe_load(f) or {}
                
                for app_entry in registry.get("apps", []):
                    app_id = app_entry.get("id")
                    if not app_id:
                        continue
                    
                    # Apply default path resolution: apps/{id}.yml
                    config_file = app_entry.get("config_file")
                    resolved_config_file = resolve_config_path(config_file, "apps/{id}.yml", app_id)
                    
                    if resolved_config_file:
                        manifest_path = Path(project_dir) / "config" / resolved_config_file
                        if manifest_path.exists():
                            try:
                                with open(manifest_path, "r") as f:
                                    manifest = yaml.safe_load(f)
                                apps.append({
                                    "app_id": app_id,
                                    "title": manifest.get("title", app_id),
                                    "subtitle": manifest.get("subtitle", manifest.get("description", "")),
                                })
                            except Exception as e:
                                logger.warning("Failed to parse manifest for {}: {}", app_id, e)
            else:
                # Fallback: scan config/apps/ directory for *.yml files
                apps_dir = Path(project_dir) / "config" / "apps"
                if apps_dir.exists():
                    for yml_file in apps_dir.glob("*.yml"):
                        try:
                            with open(yml_file, "r") as f:
                                manifest = yaml.safe_load(f)
                            apps.append({
                                "app_id": yml_file.stem,
                                "title": manifest.get("title", yml_file.stem),
                                "subtitle": manifest.get("subtitle", manifest.get("description", "")),
                            })
                        except Exception as e:
                            logger.warning("Failed to parse manifest {}: {}", yml_file.name, e)
            
            # Include widget_theme from apps.yml if present
            widget_theme = registry.get("widget_theme")
            
            return JSONResponse({
                "apps": apps,
                "count": len(apps),
                "widget_theme": widget_theme,  # Apps-level widget theme
            })
            
        except Exception as e:
            logger.error("Failed to list app manifests: {}", e, exc_info=True)
            return JSONResponse({"error": "Failed to list app manifests", "details": str(e)}, status_code=500)

    # Register catch-all route for Next.js client-side routing AT THE END
    # This ensures all API routes are registered first, so FastAPI matches them before the catch-all
    # This handles routes like /operations/, /reports/view/, etc. for client-side routing
    if ui_dist_dir and Path(ui_dist_dir).exists() and (Path(ui_dist_dir) / "index.html").exists():
        dist_root = Path(ui_dist_dir)
        
        # Use a single route decorator with multiple methods to avoid route conflicts
        logger.info("Registering catch-all route for UI dist directory (GET, HEAD, OPTIONS)")
        @app.api_route("/{path:path}", methods=["GET", "HEAD", "OPTIONS"])
        async def catch_all_ui_dist(path: str, request: Request):
            
            # Handle OPTIONS requests (CORS preflight)
            if request.method == "OPTIONS":
                return Response(status_code=200)
            
            # Skip static assets - these are handled by mounts
            # FastAPI will match API routes first (they're registered before this catch-all)
            if path.startswith(("_next/", "static/", "icons/", "assets/")):
                raise HTTPException(status_code=404, detail="Not Found")
            
            # Normalize path: remove leading/trailing slashes
            normalized_path = path.strip("/")
            if not normalized_path:
                # Root path, serve index.html
                index_file = dist_root / "index.html"
                return FileResponse(str(index_file))
            
            # Try to serve {path}/index.html (for trailing slash routes)
            page_file = dist_root / normalized_path / "index.html"
            if page_file.exists():
                return FileResponse(str(page_file))
            
            # Try to serve {path}.html (for non-trailing slash routes)
            page_file = dist_root / f"{normalized_path}.html"
            if page_file.exists():
                return FileResponse(str(page_file))
            
            # Fallback to index.html for client-side routing
            index_file = dist_root / "index.html"
            return FileResponse(str(index_file))
    else:
        # Serve packaged UI - register catch-all for packaged UI
        ui_pkg = None
        try:
            ui_pkg = importlib.resources.files("topaz_agent_kit.ui.frontend")
        except Exception as e:
            logger.warning("Failed to import packaged UI: {}", e)
            logger.warning("Catch-all route will still be registered but may not serve UI files correctly")
        
        # Always register catch-all route, even if UI package import failed
        # This ensures client-side routing works (e.g., /app/invoice_review_app)
        # Use a single route decorator with multiple methods to avoid route conflicts
        logger.info("Registering catch-all route for packaged UI (GET, HEAD, OPTIONS)")
        @app.api_route("/{path:path}", methods=["GET", "HEAD", "OPTIONS"])
        async def catch_all_packaged(path: str, request: Request):
            # Handle OPTIONS requests (CORS preflight)
            if request.method == "OPTIONS":
                return Response(status_code=200)
            
            # Skip static assets - these are handled by mounts
            # FastAPI will match API routes first (they're registered before this catch-all)
            if path.startswith(("_next/", "static/", "icons/", "assets/")):
                raise HTTPException(status_code=404, detail="Not Found")
            
            # If UI package is not available, return 404
            if ui_pkg is None:
                logger.warning("UI package not available, returning 404 for path: {}", path)
                raise HTTPException(status_code=404, detail="UI not available")
            
            try:
                # Normalize path: remove leading/trailing slashes
                normalized_path = path.strip("/")
                
                # Handle RSC (React Server Components) requests for index.txt
                if normalized_path.endswith("/index.txt") or normalized_path == "index.txt":
                    dir_path = normalized_path.replace("/index.txt", "").replace("index.txt", "")
                    try:
                        if not dir_path:
                            txt_file = ui_pkg / "index.txt"
                        else:
                            txt_file = ui_pkg / dir_path / "index.txt"
                        content = txt_file.read_bytes()
                        return Response(content=content, media_type="text/plain")
                    except (FileNotFoundError, OSError):
                        return Response(content="Not Found", status_code=404)
                
                # Special handling for /app/{any-app-id} routes
                # Next.js static export creates /app/_/index.html as a placeholder
                # All /app/* routes should serve /app/_/index.html, and client-side code extracts appId from URL
                if normalized_path.startswith("app/"):
                    app_parts = normalized_path.split("/", 2)  # ["app", "{appId}", ...]
                    if len(app_parts) >= 2:
                        # Serve /app/_/index.html for any /app/{appId} path
                        app_placeholder_file = ui_pkg / "app" / "_" / "index.html"
                        try:
                            content = app_placeholder_file.read_bytes()
                            return Response(content=content, media_type="text/html")
                        except (FileNotFoundError, OSError) as e:
                            logger.warning("App placeholder not found at app/_/index.html, falling back to root index.html: {}", e)
                            # Fall through to root index.html
                
                if not normalized_path:
                    # Root path, serve index.html
                    index_file = ui_pkg / "index.html"
                    content = index_file.read_bytes()
                    return Response(content=content, media_type="text/html")
                
                # Try to serve {path}/index.html (for trailing slash routes like /operations/)
                try:
                    page_file = ui_pkg / normalized_path / "index.html"
                    content = page_file.read_bytes()
                    return Response(content=content, media_type="text/html")
                except (FileNotFoundError, OSError):
                    pass
                
                # Try to serve {path}.html (for non-trailing slash routes)
                try:
                    page_file = ui_pkg / f"{normalized_path}.html"
                    content = page_file.read_bytes()
                    return Response(content=content, media_type="text/html")
                except (FileNotFoundError, OSError):
                    pass
                
                # Fallback to index.html for client-side routing
                index_file = ui_pkg / "index.html"
                content = index_file.read_bytes()
                return Response(content=content, media_type="text/html")
            except Exception as e:
                logger.error("Failed to serve page {}: {}", path, e, exc_info=True)
                try:
                    index_file = ui_pkg / "index.html"
                    content = index_file.read_bytes()
                    return Response(content=content, media_type="text/html")
                except Exception:
                    return Response(content="Not Found", status_code=404)

    logger.info("FastAPI application created successfully")
    return app

