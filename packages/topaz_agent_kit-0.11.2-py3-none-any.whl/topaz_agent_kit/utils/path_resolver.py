"""
Path Resolver Utility

Provides default-based path resolution for configuration files.
Applies consistent defaults across all registries (pipelines, apps, agents, operations, gates, prompts, patterns).
"""

from pathlib import Path
from typing import Optional


def should_apply_default(value: Optional[str]) -> bool:
    """
    Determine if we should apply default path based on value.
    
    Returns True if value looks like a simple ID (not a path or inline template).
    
    Args:
        value: The value to check
        
    Returns:
        True if default should be applied, False otherwise
    """
    if not value or not isinstance(value, str):
        return False
    
    # Don't default if it contains path separators
    if '/' in value or '\\' in value:
        return False
    
    # Don't default if it contains file extension (likely explicit path)
    if '.' in value and any(ext in value for ext in ['.jinja', '.txt', '.md', '.yml', '.yaml', '.json']):
        return False
    
    # Don't default if it looks like inline template (contains template syntax)
    if '{{' in value or '{%' in value:
        return False
    
    # Don't default if it's multi-line (likely inline content)
    if '\n' in value:
        return False
    
    # Simple ID - apply default
    return True


def resolve_config_path(value: Optional[str], default_pattern: str, id_value: str) -> str:
    """
    Resolve config path with defaults.
    
    If value is missing or is a simple ID, applies default pattern.
    Otherwise, returns value as-is (explicit path or inline content).
    
    Args:
        value: The config path value (may be None, simple ID, or explicit path)
        default_pattern: Default pattern string with {id} placeholder
        id_value: The ID to use in default pattern
        
    Returns:
        Resolved path string
    """
    if not value:
        return default_pattern.format(id=id_value)
    
    if should_apply_default(value):
        # Use value as the ID (it's a simple ID, not a path)
        return default_pattern.format(id=value)
    
    # Explicit path or inline content - return as-is
    return value


def find_repository_root(start: Path, max_levels: int = 10) -> Path:
    """
    Find repository root by looking for pyproject.toml starting from a given path.
    
    Args:
        start: Starting path to search from
        max_levels: Maximum number of parent directories to search
        
    Returns:
        Path to the repository root directory containing pyproject.toml
        
    Raises:
        FileNotFoundError: If no repository root is found within max_levels
    """
    current = Path(start).resolve()
    
    for level in range(max_levels):
        pyproject_file = current / "pyproject.toml"
        
        if pyproject_file.exists():
            return current
        
        if current == current.parent:  # Reached root directory
            break
            
        current = current.parent
    
    # No repository root found - fail fast
    error_msg = f"No repository root found (no pyproject.toml) starting from {start} within {max_levels} levels"
    raise FileNotFoundError(error_msg)
