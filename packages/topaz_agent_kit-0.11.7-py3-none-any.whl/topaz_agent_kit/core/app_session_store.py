"""
App Session Store Module
High-level abstraction for app session and canvas state management
"""

import json
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field

from topaz_agent_kit.core.chat_database import ChatDatabase
from topaz_agent_kit.core.exceptions import DatabaseError
from topaz_agent_kit.utils.logger import Logger


@dataclass
class AppSession:
    """App session data structure"""
    app_session_id: str
    app_id: str
    state: Dict[str, Any]
    title: Optional[str]
    created_at: datetime
    updated_at: datetime
    pinned: bool = False
    pinned_order: int = 0
    canvas_structure: Optional[Dict[str, Any]] = None


@dataclass
class AppChatTurn:
    """App chat turn data structure"""
    id: int
    app_session_id: str
    role: str
    content: str
    created_at: datetime
    widgets: Optional[List[Dict[str, Any]]] = None


class AppSessionStore:
    """High-level app session storage abstraction"""
    
    def __init__(self, db_path: str):
        self.logger = Logger("AppSessionStore")
        self.db = ChatDatabase(db_path)
        # Initialize validation engine (lazy import to avoid circular dependencies)
        self._validation_engine = None
        self.logger.info("App session store initialized")
    
    def _get_validation_engine(self):
        """Lazy load validation engine"""
        if self._validation_engine is None:
            from topaz_agent_kit.core.widget_validator import WidgetValidationEngine
            self._validation_engine = WidgetValidationEngine()
        return self._validation_engine
    
    # === SESSION MANAGEMENT ===
    
    def create_session(
        self,
        app_id: str,
        title: Optional[str] = None,
        initial_state: Optional[Dict[str, Any]] = None,
        app_session_id: Optional[str] = None,
    ) -> str:
        """Create a new app session
        
        Args:
            app_id: The app identifier (e.g., "article_app")
            title: Optional session title
            initial_state: Optional initial canvas state
            app_session_id: Optional custom session ID (generated if not provided)
            
        Returns:
            The app session ID
            
        Raises:
            DatabaseError: If session creation fails
        """
        if not app_session_id:
            app_session_id = f"app_{int(datetime.now().timestamp() * 1000)}"
        
        success = self.db.create_app_session(
            app_session_id=app_session_id,
            app_id=app_id,
            title=title,
            initial_state=initial_state,
        )
        
        if success:
            self.logger.info("Created app session: {} for app: {}", app_session_id, app_id)
            return app_session_id
        else:
            self.logger.error("Failed to create app session for app: {}", app_id)
            raise DatabaseError(f"Failed to create app session for app: {app_id}")
    
    def get_session(self, app_session_id: str) -> Optional[AppSession]:
        """Get app session by ID"""
        session_data = self.db.get_app_session(app_session_id)
        if not session_data:
            return None
        
        return self._convert_to_app_session(session_data)
    
    def update_state(self, app_session_id: str, state: Dict[str, Any]) -> bool:
        """Update session canvas state
        
        Args:
            app_session_id: The session ID
            state: New state dictionary (replaces existing state)
            
        Returns:
            True if successful
        """
        success = self.db.update_app_session_state(app_session_id, state)
        if success:
            self.logger.debug("Updated state for session: {}", app_session_id)
        return success
    
    def patch_state(
        self, 
        app_session_id: str, 
        patch: Dict[str, Any],
        manifest: Optional[Dict[str, Any]] = None,
        validate: bool = True
    ) -> Tuple[bool, Optional[List[str]]]:
        """
        Patch session canvas state (deep merge with existing)
        
        Args:
            app_session_id: The session ID
            patch: State patch to deep merge into existing state
            manifest: Optional app manifest for validation
            validate: Whether to validate state updates (default: True)
            
        Returns:
            Tuple of (success, errors) where errors is None if validation disabled or passed
        """
        session = self.get_session(app_session_id)
        if not session:
            self.logger.warning("Session not found for patch: {}", app_session_id)
            return False, None
        
        # Validate if manifest provided and validation enabled
        if validate and manifest:
            validation_errors = self._validate_patch(patch, manifest, session.state)
            if validation_errors:
                self.logger.warning("State patch validation failed: {}", validation_errors)
                return False, validation_errors
        
        # Deep merge patch into existing state
        new_state = self._deep_merge(session.state, patch)
        
        # Normalize empty strings for non-required enum fields before saving
        # This ensures consistency with default_state where optional enum fields can be empty
        state_schema = manifest.get("state_schema") if manifest else None
        if state_schema:
            new_state = self._normalize_empty_enums(new_state, state_schema)
        
        success = self.update_state(app_session_id, new_state)
        return success, None
    
    def _validate_patch(
        self,
        patch: Dict[str, Any],
        manifest: Dict[str, Any],
        current_state: Dict[str, Any]
    ) -> List[str]:
        """
        Validate patch against manifest validation rules
        
        Args:
            patch: State patch to validate
            manifest: App manifest with validation rules
            current_state: Current state (for context)
            
        Returns:
            List of validation error messages
        """
        errors = []
        canvas = manifest.get("canvas", {})
        sections = canvas.get("sections", [])
        
        # Create a map of binding paths to sections
        binding_map = {}
        for section in sections:
            binding = section.get("binding")
            if binding:
                binding_map[binding] = section
        
        # Validate each path in patch
        for path, value in patch.items():
            # Skip validation for empty strings if field is not required and has enum constraint
            # This allows clearing optional enum fields (they'll be removed from state, not set to "")
            if value == "":
                state_schema = manifest.get("state_schema")
                if state_schema:
                    required_paths = self._get_required_paths(state_schema)
                    field_schema = self._get_field_schema(state_schema, path)
                    # If field is not required and has enum constraint, skip validation
                    # The empty string will be normalized away in _normalize_empty_enums
                    if path not in required_paths and field_schema and "enum" in field_schema:
                        continue
            
            # Find section with matching binding
            section = None
            for binding, sec in binding_map.items():
                # Check if path matches binding (supports nested paths)
                if path == binding or path.startswith(binding + "."):
                    section = sec
                    break
            
            if section and section.get("validation"):
                # Get validation engine
                engine = self._get_validation_engine()
                
                # Validate this value
                result = engine.validate_section(section, value, manifest)
                if not result.is_valid:
                    errors.extend([f"{path}: {err}" for err in result.errors])
        
        # Also validate against state_schema if present
        state_schema = manifest.get("state_schema")
        if state_schema:
            # Merge patch into current state for full validation
            from copy import deepcopy
            test_state = deepcopy(current_state)
            test_state = self._deep_merge(test_state, patch)
            
            # Allow empty strings for non-required enum fields
            # This matches the default_state behavior where optional enum fields can be empty
            test_state = self._normalize_empty_enums(test_state, state_schema)
            
            engine = self._get_validation_engine()
            result = engine.validate_state_against_schema(test_state, state_schema)
            if not result.is_valid:
                errors.extend(result.errors)
        
        return errors
    
    def _get_required_paths(self, schema: Dict[str, Any], prefix: str = "") -> List[str]:
        """
        Extract all required field paths from a JSON Schema.
        
        Args:
            schema: JSON Schema dictionary
            prefix: Current path prefix (for recursion)
            
        Returns:
            List of required field paths (e.g., ["article.title", "article.body"])
        """
        required_paths = []
        
        if "required" in schema:
            for field in schema["required"]:
                if prefix:
                    required_paths.append(f"{prefix}.{field}")
                else:
                    required_paths.append(field)
        
        if "properties" in schema:
            for prop_name, prop_schema in schema["properties"].items():
                if isinstance(prop_schema, dict):
                    new_prefix = f"{prefix}.{prop_name}" if prefix else prop_name
                    required_paths.extend(self._get_required_paths(prop_schema, new_prefix))
        
        return required_paths
    
    def _normalize_empty_enums(self, state: Dict[str, Any], schema: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize empty strings for non-required enum fields by removing them.
        This allows clearing optional enum fields without validation errors,
        matching the default_state behavior where optional enum fields can be empty.
        
        Args:
            state: State dictionary to normalize
            schema: JSON Schema for validation
            
        Returns:
            Normalized state dictionary
        """
        from copy import deepcopy
        normalized = deepcopy(state)
        required_paths = self._get_required_paths(schema)
        
        def normalize_dict(d: Dict[str, Any], path: str = "") -> None:
            for key, value in list(d.items()):
                current_path = f"{path}.{key}" if path else key
                
                if isinstance(value, dict):
                    normalize_dict(value, current_path)
                elif isinstance(value, str) and value == "":
                    # Check if this is a non-required enum field
                    if current_path not in required_paths:
                        # Check if field has enum constraint
                        field_schema = self._get_field_schema(schema, current_path)
                        if field_schema and "enum" in field_schema:
                            # Remove empty string for non-required enum field
                            # This allows the field to be unset (not present) rather than empty string
                            if path:
                                parent = normalized
                                for part in path.split("."):
                                    parent = parent.get(part, {})
                                if key in parent:
                                    del parent[key]
                            else:
                                if key in normalized:
                                    del normalized[key]
        
        normalize_dict(normalized)
        return normalized
    
    def _get_field_schema(self, schema: Dict[str, Any], path: str) -> Optional[Dict[str, Any]]:
        """
        Get the schema for a specific field path.
        
        Args:
            schema: JSON Schema dictionary
            path: Field path (e.g., "article.category")
            
        Returns:
            Field schema dictionary or None
        """
        parts = path.split(".")
        current = schema
        
        for part in parts:
            if "properties" in current:
                current = current["properties"].get(part)
                if current is None:
                    return None
            else:
                return None
        
        return current if isinstance(current, dict) else None
    
    def _deep_merge(self, base: Dict[str, Any], patch: Dict[str, Any]) -> Dict[str, Any]:
        """Deep merge patch into base dictionary.
        
        For nested dictionaries, recursively merges. For other types,
        the patch value overwrites the base value.
        """
        result = dict(base)
        
        for key, value in patch.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._deep_merge(result[key], value)
            else:
                result[key] = value
        
        return result
    
    def update_title(self, app_session_id: str, title: str) -> bool:
        """Update session title"""
        success = self.db.update_app_session_title(app_session_id, title)
        if success:
            self.logger.debug("Updated title for session: {}", app_session_id)
        return success
    
    def update_pinned(self, app_session_id: str, pinned: bool, pinned_order: Optional[int] = None) -> bool:
        """Update session pinned status"""
        success = self.db.update_app_session_pinned(app_session_id, pinned, pinned_order)
        if success:
            self.logger.debug("Updated pinned for session: {} -> {}", app_session_id, pinned)
        return success
    
    def list_sessions(
        self,
        app_id: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> List[AppSession]:
        """List app sessions
        
        Args:
            app_id: Optional filter by app ID
            limit: Maximum number of sessions to return
            offset: Pagination offset
            
        Returns:
            List of AppSession objects
        """
        sessions_data = self.db.list_app_sessions(app_id, limit, offset)
        return [self._convert_to_app_session(s) for s in sessions_data]
    
    def delete_session(self, app_session_id: str) -> bool:
        """Delete app session and all associated chat turns"""
        success = self.db.delete_app_session(app_session_id)
        if success:
            self.logger.info("Deleted app session: {}", app_session_id)
        return success
    
    # === CHAT TURN MANAGEMENT ===
    
    def add_chat_turn(
        self,
        app_session_id: str,
        role: str,
        content: str,
        widgets: Optional[List[Dict[str, Any]]] = None,
    ) -> Optional[int]:
        """Add a chat turn to session
        
        Args:
            app_session_id: The session ID
            role: The role (e.g., "user", "assistant")
            content: The message content
            widgets: Optional list of widgets to include with the message
            
        Returns:
            The turn ID if successful, None otherwise
        """
        turn_id = self.db.add_app_chat_turn(app_session_id, role, content, widgets)
        if turn_id:
            self.logger.debug("Added chat turn {} (role: {}) to session: {} (widgets: {})", 
                            turn_id, role, app_session_id, len(widgets) if widgets else 0)
        return turn_id
    
    def get_chat_turns(
        self,
        app_session_id: str,
        limit: int = 100,
        offset: int = 0,
    ) -> List[AppChatTurn]:
        """Get chat turns for a session
        
        Args:
            app_session_id: The session ID
            limit: Maximum number of turns to return
            offset: Pagination offset
            
        Returns:
            List of AppChatTurn objects
        """
        turns_data = self.db.get_app_chat_turns(app_session_id, limit, offset)
        return [self._convert_to_app_chat_turn(t) for t in turns_data]
    
    def clear_chat_turns(self, app_session_id: str) -> bool:
        """Clear all chat turns for a session"""
        success = self.db.clear_app_chat_turns(app_session_id)
        if success:
            self.logger.info("Cleared chat turns for session: {}", app_session_id)
        return success
    
    # === THREAD STATE MANAGEMENT (for conversation memory) ===
    
    def update_thread_state(self, app_session_id: str, thread_state: str) -> bool:
        """Update thread state for a session (serialized agent thread)
        
        Args:
            app_session_id: The session ID
            thread_state: JSON string of serialized thread state
            
        Returns:
            True if successful
        """
        success = self.db.update_app_session_thread_state(app_session_id, thread_state)
        if success:
            self.logger.debug("Updated thread state for session: {}", app_session_id)
        return success
    
    def get_thread_state(self, app_session_id: str) -> Optional[str]:
        """Get thread state for a session
        
        Args:
            app_session_id: The session ID
            
        Returns:
            JSON string of thread state if exists, None otherwise
        """
        return self.db.get_app_session_thread_state(app_session_id)
    
    # === CANVAS STRUCTURE MANAGEMENT ===
    
    def get_canvas_structure(self, app_session_id: str) -> Optional[Dict[str, Any]]:
        """Get canvas structure for a session
        
        Args:
            app_session_id: The session ID
            
        Returns:
            Canvas structure dictionary if exists, None otherwise
        """
        return self.db.get_app_session_canvas_structure(app_session_id)
    
    def update_canvas_structure(
        self,
        app_session_id: str,
        canvas_structure: Dict[str, Any]
    ) -> bool:
        """
        Update canvas structure for a session.
        
        Args:
            app_session_id: The session ID
            canvas_structure: Canvas structure dictionary
            
        Returns:
            True if successful, False otherwise
        """
        # Log incoming structure
        self.logger.info("AppSessionStore.update_canvas_structure - Updating structure for session: {}", app_session_id)
        self.logger.info("  - Incoming structure has {} sections, order length: {}", 
                       len(canvas_structure.get("sections", {})), 
                       len(canvas_structure.get("order", [])))
        self.logger.info("  - Section IDs: {}", list(canvas_structure.get("sections", {}).keys()))
        
        # Log detailed section contents
        for section_id, section in canvas_structure.get("sections", {}).items():
            controls = section.get("controls", [])
            sub_sections = section.get("sections", [])
            self.logger.info("  - Section '{}': {} controls, {} sub-sections", 
                           section_id, len(controls), len(sub_sections))
            for idx, control in enumerate(controls):
                self.logger.debug("    Control {}: id={}, widget={}, binding={}, label={}", 
                                 idx, 
                                 control.get("id", "unknown"),
                                 control.get("widget", "unknown"),
                                 control.get("binding", "none"),
                                 control.get("label", "none"))
        
        session = self.get_session(app_session_id)
        if not session:
            self.logger.warning("AppSessionStore.update_canvas_structure - Session not found: {}", app_session_id)
            return False
        
        # Update canvas structure in database
        success = self.db.update_app_session_canvas_structure(
            app_session_id,
            canvas_structure
        )
        
        if success:
            self.logger.info("AppSessionStore.update_canvas_structure - Successfully saved canvas structure for session: {}", app_session_id)
            # Verify what was saved by reading it back
            updated_session = self.get_session(app_session_id)
            if updated_session and updated_session.canvas_structure:
                saved_sections = updated_session.canvas_structure.get("sections", {})
                self.logger.info("AppSessionStore.update_canvas_structure - Verified saved structure: {} sections", len(saved_sections))
                self.logger.debug("AppSessionStore.update_canvas_structure - Saved section IDs: {}", list(saved_sections.keys()))
        else:
            self.logger.error("AppSessionStore.update_canvas_structure - Failed to save canvas structure for session: {}", app_session_id)
        
        return success
    
    def update_canvas_structure_old(
        self,
        app_session_id: str,
        canvas_structure: Dict[str, Any],
    ) -> bool:
        """Update canvas structure for a session
        
        Args:
            app_session_id: The session ID
            canvas_structure: Canvas structure dictionary
            
        Returns:
            True if successful
        """
        success = self.db.update_app_session_canvas_structure(app_session_id, canvas_structure)
        if success:
            self.logger.debug("Updated canvas_structure for session: {}", app_session_id)
        return success
    
    # === UTILITY METHODS ===
    
    def _convert_to_app_session(self, session_data: Dict[str, Any]) -> AppSession:
        """Convert database session data to AppSession object"""
        pinned_val = session_data.get('pinned', 0)
        return AppSession(
            app_session_id=session_data['app_session_id'],
            app_id=session_data['app_id'],
            state=session_data.get('state', {}),
            title=session_data.get('title'),
            created_at=datetime.fromisoformat(session_data['created_at']) if isinstance(session_data['created_at'], str) else session_data['created_at'],
            updated_at=datetime.fromisoformat(session_data['updated_at']) if isinstance(session_data['updated_at'], str) else session_data['updated_at'],
            pinned=bool(pinned_val) if pinned_val is not None else False,
            pinned_order=int(session_data.get('pinned_order', 0) or 0),
            canvas_structure=session_data.get('canvas_structure'),
        )
    
    def _convert_to_app_chat_turn(self, turn_data: Dict[str, Any]) -> AppChatTurn:
        """Convert database turn data to AppChatTurn object"""
        return AppChatTurn(
            id=turn_data['id'],
            app_session_id=turn_data['app_session_id'],
            role=turn_data['role'],
            content=turn_data['content'],
            created_at=datetime.fromisoformat(turn_data['created_at']) if isinstance(turn_data['created_at'], str) else turn_data['created_at'],
            widgets=turn_data.get('widgets'),  # Include widgets (optional, comes last)
        )
    
    def get_session_with_turns(self, app_session_id: str) -> Optional[Dict[str, Any]]:
        """Get session with all chat turns (convenience method)
        
        Returns a dictionary with session data and turns for API responses.
        """
        session = self.get_session(app_session_id)
        if not session:
            return None
        
        turns = self.get_chat_turns(app_session_id)
        
        return {
            "app_session_id": session.app_session_id,
            "app_id": session.app_id,
            "state": session.state,
            "title": session.title,
            "canvas_structure": session.canvas_structure,  # Include canvas structure for agent/hybrid modes
            "created_at": session.created_at.isoformat(),
            "updated_at": session.updated_at.isoformat(),
            "chat_turns": [
                {
                    "id": t.id,
                    "role": t.role,
                    "content": t.content,
                    "widgets": t.widgets,  # Include widgets
                    "created_at": t.created_at.isoformat(),
                }
                for t in turns
            ],
        }
