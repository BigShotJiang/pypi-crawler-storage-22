import json
from pathlib import Path
from typing import Any, Dict, Tuple, List
import importlib.resources as pkg_resources
from jsonschema import Draft202012Validator

from topaz_agent_kit.utils.logger import Logger
from topaz_agent_kit.utils.env_substitution import env_substitution
from topaz_agent_kit.utils.path_resolver import resolve_config_path
from topaz_agent_kit.frameworks import FrameworkConfigManager
from topaz_agent_kit.core.exceptions import (
    ConfigurationError,
    PipelineError
)

try:
    import yaml  # type: ignore
except Exception:  # pragma: no cover
    yaml = None


class PipelineLoader:
    """Load and lightly validate pipelines.yml and ui_manifest.yml from a project root.
    """

    def __init__(self, root_dir: str | Path) -> None:
        self.root = Path(root_dir)
        self.logger = Logger("PipelineLoader")
        self.logger.info("Initialized with root directory: {}", self.root)

    def __str__(self) -> str:
        """String representation of PipelineLoader."""
        return f"PipelineLoader(root={self.root})"

    def load_yaml(self, file_path: Path) -> Dict[str, Any]:
        self.logger.debug("Loading YAML file: {}", file_path)
        
        # Environment variables are already loaded by Orchestrator
        if yaml is None:
            self.logger.error("PyYAML is required to load pipelines.yml")
            raise ConfigurationError("PyYAML is required to load pipelines.yml")
        try:
            with file_path.open("r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
            if not isinstance(data, dict):
                self.logger.error("YAML root must be a mapping: {}", file_path)
                raise ConfigurationError(f"Invalid YAML format in {file_path}: Root must be a mapping/dictionary")
            
            # Apply environment variable substitution
            data = env_substitution.substitute_in_yaml_data(data)
            
            self.logger.debug("Successfully loaded YAML with {} keys", len(data))
            return data
        except Exception as e:
            self.logger.error("Failed to load YAML file {}: {}", file_path, e)
            raise ConfigurationError(f"Failed to load YAML file {file_path}: {e}")

    def load_json(self, file_path: Path) -> Dict[str, Any]:
        self.logger.debug("Loading JSON file: {}", file_path)
        try:
            with file_path.open("r", encoding="utf-8") as f:
                data = json.load(f) or {}
            if not isinstance(data, dict):
                self.logger.error("JSON root must be an object: {}", file_path)
                raise ConfigurationError(f"Invalid JSON format in {file_path}: Root must be an object/dictionary")
            
            # Apply environment variable substitution
            data = env_substitution.substitute_in_yaml_data(data)
            
            self.logger.debug("Successfully loaded JSON with {} keys", len(data))
            return data
        except Exception as e:
            self.logger.error("Failed to load JSON file {}: {}", file_path, e)
            raise ConfigurationError(f"Failed to load JSON file {file_path}: {e}")

    def load(self) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        self.logger.info("Loading pipeline configuration from: {}", self.root)
        common_file = self.root / "config" / "common.yml"
        pipelines_file = self.root / "config" / "pipelines.yml"
        apps_file = self.root / "config" / "apps.yml"
        ui_yml = self.root / "config" / "ui_manifest.yml"
        ui_yaml = self.root / "config" / "ui_manifest.yaml"
        operations_file = self.root / "config" / "operations.yml"
        
        # Load common.yml first if it exists (shared settings)
        common_config = {}
        if common_file.exists():
            self.logger.debug("Loading common config from: {}", common_file)
            common_config = self.load_yaml(common_file)
            self.logger.info("Loaded common.yml with {} keys", len(common_config))
        
        # Determine project mode: pipeline mode vs app-only mode
        app_only_mode = False
        
        # Use pipelines.yml
        if pipelines_file.exists():
            # Pipeline mode (or hybrid if apps.yml also exists)
            self.logger.debug("Loading pipelines registry from: {}", pipelines_file)
            pipeline = self.load_yaml(pipelines_file)
        elif apps_file.exists():
            # App-only mode: no pipelines.yml but apps.yml exists
            app_only_mode = True
            self.logger.info("App-only mode: no pipelines.yml, using apps.yml")
            pipeline = self._create_app_only_config(common_config)
        else:
            # Error: neither pipelines.yml nor apps.yml exists
            from topaz_agent_kit.core.exceptions import ConfigurationError
            raise ConfigurationError(
                f"No configuration found. Expected either config/pipelines.yml or config/apps.yml in {self.root}"
            )
        
        # Merge common config into pipeline (pipeline values override common)
        # This provides backward compatibility: settings can be in either file
        if common_config and not app_only_mode:
            pipeline = self._merge_configs(common_config, pipeline)
            self.logger.debug("Merged common.yml settings into pipeline config")
        
        # Mark app-only mode in config for downstream use
        pipeline["_app_only_mode"] = app_only_mode
        
        # Note: Agent configurations are loaded separately by AgentFactory when needed
        # Pipeline structure should only contain references (id, config_file)
        
        # YAML-only manifest (preferred): ui_manifest.yml|yaml
        if ui_yml.exists():
            self.logger.debug("Loading UI manifest from: {}", ui_yml)
            ui = self.load_yaml(ui_yml)
        elif ui_yaml.exists():
            self.logger.debug("Loading UI manifest from: {}", ui_yaml)
            ui = self.load_yaml(ui_yaml)
        else:
            self.logger.debug("No UI manifest found, using empty defaults")
            ui = {}
        
        # Load operations.yml if it exists (new file for operations settings)
        operations_config = {}
        if operations_file.exists():
            self.logger.debug("Loading operations config from: {}", operations_file)
            operations_config = self.load_yaml(operations_file)
            self.logger.info("Loaded operations.yml with {} keys", len(operations_config))
        else:
            # Fallback: check if operations settings are in ui_manifest.yml (legacy)
            if "operations" in ui or "operations_workflow" in ui:
                self.logger.warning("DEPRECATION: operations settings found in ui_manifest.yml. "
                                  "Move to config/operations.yml for better organization.")
                # Extract operations settings from ui_manifest for backward compatibility
                if "operations" in ui:
                    operations_config["operations"] = ui.pop("operations")
                if "operations_workflow" in ui:
                    operations_config["workflow"] = ui.pop("operations_workflow")
        
        # Store operations config in ui manifest for now (for backward compatibility with API)
        # TODO: In future, return operations separately or merge into a config dict
        if operations_config:
            ui["_operations"] = operations_config
        
        # Validate UI manifest (warn-only for MVP)
        # Skip validation warnings for app-only mode (pipelines not required)
        try:
            schema_path = pkg_resources.files("topaz_agent_kit.core.schemas") / "ui_manifest.schema.json"
            schema = json.loads(schema_path.read_text(encoding="utf-8"))
            validator = Draft202012Validator(schema)
            errors = sorted(validator.iter_errors(ui), key=lambda e: e.path)
            for err in errors:
                # Suppress 'pipelines' required property warning for app-only mode
                if app_only_mode and ("pipelines" in str(err.path) or "'pipelines' is a required property" in err.message):
                    continue
                # Suppress '_operations' unexpected property warning (it's intentionally added)
                if "'_operations' was unexpected" in err.message:
                    continue
                # Suppress 'chat' required property warning (deprecated in favor of 'assistant')
                if "'chat' is a required property" in err.message or "chat" in str(err.path):
                    continue
                # Suppress 'assistant' unexpected property warning (new field, intentionally added)
                if "'assistant' was unexpected" in err.message:
                    continue
                # Suppress false positive warnings about assistant config string values
                # The validator incorrectly flags string values in assistant.* as "not of type 'object'"
                if "assistant" in str(err.path) and "is not of type 'object'" in err.message:
                    continue
                self.logger.warning("ui_manifest validation: {}", err.message)
        except Exception as e:
            # Non-fatal: schema missing or invalid should not block loading
            self.logger.warning("ui_manifest validation skipped: {}", e)

        # Minimal normalization for forward-compat
        try:
            meta = ui.setdefault("meta", {})
            meta.setdefault("ui_schema_version", "1.0")
            if not ui.get("cards") and not ((ui.get("hero") or {}).get("cards")):
                ui["cards"] = []
        except Exception:
            pass

        # Do not touch defaults here; services inject settings.json into cfg["defaults"].
        # Only ensure meta exists for forward-compat keys.
        self.logger.debug("Normalizing configuration keys (meta only); defaults come from settings.json")
        pipeline.setdefault("meta", {})
        
        # UI toggles moved to ui_manifest.yml; no defaults here
        # Skip validation for app-only mode (no pipelines to validate)
        if not app_only_mode:
            self.logger.debug("Validating pipeline configuration")
            validation_errors = self._validate(pipeline)
            
            if validation_errors:
                error_message = "Pipeline validation failed:\n" + "\n".join(f"- {error}" for error in validation_errors)
                self.logger.error("Pipeline validation failed: {}", error_message)
                raise PipelineError(error_message)
        else:
            self.logger.debug("Skipping pipeline validation (app-only mode)")
        
        # Count agents from pattern-only format (nodes) or pipelines format (multi-pipeline)
        agent_count = 0
        if "nodes" in pipeline and isinstance(pipeline["nodes"], list):
            # Single-pipeline structure (pattern-only)
            agent_count = len(pipeline["nodes"])
        elif "pipelines" in pipeline:
            # Multi-pipeline structure - count agents from individual pipeline files
            for pipeline_ref in pipeline["pipelines"]:
                if isinstance(pipeline_ref, dict):
                    # Apply default path resolution: pipelines/{id}.yml
                    pipeline_id = pipeline_ref.get("id")
                    config_file = pipeline_ref.get("config_file")
                    if pipeline_id:
                        resolved_config_file = resolve_config_path(config_file, "pipelines/{id}.yml", pipeline_id)
                        pipeline_file = self.root / "config" / resolved_config_file
                    elif config_file:
                        # Backward compatibility: explicit path provided
                        pipeline_file = self.root / "config" / config_file
                    else:
                        continue
                    if pipeline_file.exists():
                        try:
                            pipeline_config = self.load_yaml(pipeline_file)
                            if "nodes" in pipeline_config and isinstance(pipeline_config["nodes"], list):
                                agent_count += len(pipeline_config["nodes"])
                        except Exception as e:
                            self.logger.warning("Failed to load pipeline file {} for agent counting: {}", pipeline_file, e)
        
        self.logger.success("Successfully loaded pipeline with {} agents and {} UI config keys", 
                        agent_count, len(ui))
        return pipeline, ui

    def _validate(self, config: Dict[str, Any]) -> List[str]:
        """Validate pipeline configuration"""
        errors = []
        
        # Basic structure validation
        if not isinstance(config, dict):
            errors.append("Pipeline configuration must be a dictionary")
            return errors
        
        # Check if this is a multi-pipeline configuration
        if "pipelines" in config:
            # Multi-pipeline structure: validate pipelines section
            pipeline_errors = self._validate_pipelines_section(config["pipelines"])
            errors.extend(pipeline_errors)
            
            # Validate required fields for multi-pipeline
            required_fields = ["servers", "chatdb_path", "assistant"]
            for field in required_fields:
                if field not in config:
                    errors.append(f"Missing required field: '{field}'")
            
        else:
            errors.append("Configuration must use multi-pipeline structure with 'pipelines' section")
        
        return errors
    
    def _validate_pipelines_section(self, pipelines: List[Dict[str, Any]]) -> List[str]:
        """Validate pipelines section of multi-pipeline configuration"""
        errors = []
        
        if not isinstance(pipelines, list):
            errors.append("Pipelines section must be a list")
            return errors
        
        if not pipelines:
            errors.append("Pipelines list cannot be empty")
            return errors
        
        # Validate each pipeline reference
        for i, pipeline in enumerate(pipelines):
            if not isinstance(pipeline, dict):
                errors.append(f"Pipeline at index {i} must be a dictionary")
                continue
            
            # Check required fields
            if "id" not in pipeline:
                errors.append(f"Pipeline at index {i} missing required field: id")
            elif not isinstance(pipeline["id"], str):
                errors.append(f"Pipeline at index {i} id must be a string")
            
            # config_file is now optional (defaults to pipelines/{id}.yml)
            # But if provided, it must be a string
            if "config_file" in pipeline and not isinstance(pipeline["config_file"], str):
                errors.append(f"Pipeline at index {i} config_file must be a string if provided")
        
        return errors
    
    def _validate_pipeline_section(self, pipeline: Dict[str, Any]) -> List[str]:
        """Validate pipeline section of pipeline configuration"""
        errors = []
        
        if not isinstance(pipeline, dict):
            errors.append("Pipeline section must be a dictionary")
            return errors
        
        # Pipeline section is optional, so no required fields
        # Only validate if steps are present
        if "steps" in pipeline and not isinstance(pipeline["steps"], list):
            errors.append("Pipeline steps must be a list")
        
        return errors
    
    def _validate_agent_types(self, pipeline_config: Dict[str, Any]) -> List[str]:
        """Validate that all agent types are supported frameworks"""
        errors = []
        
        # Get supported frameworks dynamically - fail fast if not available
        supported_frameworks = FrameworkConfigManager().get_available_frameworks()
        
        # Handle both list and dictionary agent formats
        agents = pipeline_config.get("agents", {})
        if isinstance(agents, list):
            # Convert list format to dictionary for validation
            agents_dict = {}
            for i, agent_config in enumerate(agents):
                if isinstance(agent_config, dict) and "id" in agent_config:
                    agents_dict[agent_config["id"]] = agent_config
                else:
                    agents_dict[f"agent_{i}"] = agent_config
            agents = agents_dict
        elif not isinstance(agents, dict):
            # Invalid format
            errors.append("Agents section must be a list or dictionary")
            return errors
        
        for agent_id, agent_config in agents.items():
            if not isinstance(agent_config, dict):
                errors.append(f"Agent '{agent_id}' configuration must be a dictionary")
                continue
                
            agent_type = agent_config.get("type")
            if not agent_type:
                errors.append(f"Agent '{agent_id}' missing 'type' field")
            elif agent_type not in supported_frameworks:
                errors.append(f"Agent '{agent_id}' has unsupported type '{agent_type}'. Supported: {supported_frameworks}")
        
        return errors

    def _merge_configs(self, base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
        """
        Deep merge two configuration dictionaries.
        Values from override take precedence over base.
        
        Args:
            base: Base configuration (e.g., from common.yml)
            override: Override configuration (e.g., from pipelines.yml)
            
        Returns:
            Merged configuration dictionary
        """
        result = base.copy()
        
        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                # Deep merge dictionaries
                result[key] = self._merge_configs(result[key], value)
            else:
                # Override with new value
                result[key] = value
        
        return result

    def _create_app_only_config(self, common_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create a minimal pipeline config for app-only mode.
        
        App-only projects don't have pipelines.yml, so we construct
        a minimal config from common.yml with required fields.
        
        Args:
            common_config: Configuration from common.yml
            
        Returns:
            Minimal pipeline configuration for app-only mode
        """
        # Start with common config as base
        config = common_config.copy() if common_config else {}
        
        # Add required fields with defaults
        config.setdefault("name", "App Project")
        config.setdefault("description", "App-only project")
        config.setdefault("pipelines", [])
        config.setdefault("independent_agents", [])
        
        # Minimal assistant config (not used in app-only mode but required for validation)
        if "assistant" not in config:
            config["assistant"] = {
                "id": "assistant",
                "type": "maf",
                "model": config.get("servers", {}).get("mcp", [{}])[0].get("model", "azure_openai") if config.get("servers", {}).get("mcp") else "azure_openai",
                "prompt": {
                    "instruction": {
                        "inline": "You are a helpful assistant."
                    }
                }
            }
        
        # Ensure required paths exist (use defaults if not in common.yml)
        config.setdefault("chatdb_path", "./data/chat.db")
        config.setdefault("chromadb_path", "./data/chroma_db")
        config.setdefault("rag_files_path", "./data/rag_files")
        config.setdefault("user_files_path", "./data/user_files")
        config.setdefault("embedding_model", "azure_openai_embedding")
        
        self.logger.debug("Created app-only config with {} keys", len(config))
        return config

    def load_framework_configs(self) -> Dict[str, Any]:
        """Load framework-specific configurations for new architecture"""
        try:
            # Import here to make it more mockable in tests
            from topaz_agent_kit.frameworks import FrameworkConfigManager
            
            config_manager = FrameworkConfigManager()
            frameworks = config_manager.get_available_frameworks()
            
            self.logger.info("Loaded {} framework configurations: {}", len(frameworks), frameworks)
            
            # Load configurations for each available framework
            framework_configs = {}
            for framework in frameworks:
                try:
                    config = config_manager.get_framework_config(framework)
                    # Only add framework if config is valid (not None and has content)
                    if config is not None:
                        framework_configs[framework] = config
                        self.logger.debug("Loaded config for framework {}: {} keys", framework, len(config))
                    else:
                        self.logger.warning("Framework {} returned None config, skipping", framework)
                except Exception as e:
                    self.logger.warning("Failed to load config for framework {}: {}", framework, e)
                    continue
            
            self.logger.success("Successfully loaded {} framework configurations", len(framework_configs))
            return framework_configs
            
        except ImportError as e:
            self.logger.warning("Framework configs not available: {}", e)
            self.logger.warning("PipelineLoader will operate without framework awareness")
            return {}
        except Exception as e:
            self.logger.error("Failed to load framework configs: {}", e)
            self.logger.warning("PipelineLoader will operate without framework awareness")
            return {}
    
    def _load_individual_pipeline(self, pipeline_id: str) -> Dict[str, Any] | None:
        """
        Load individual pipeline configuration file.
        
        Pipeline files are linked to UI manifests by matching ID:
        - Backend: config/pipelines/{pipeline_id}.yml
        - UI: config/ui_manifests/{pipeline_id}.yml
        
        The pipeline_id comes from the registry (pipelines.yml) and must match
        the filename (without extension) in both directories.
        
        Args:
            pipeline_id: Pipeline ID to load (must match filename)
            
        Returns:
            Pipeline configuration dict or None if not found
        """
        # Use pipelines.yml (no fallback)
        pipelines_file = self.root / "config" / "pipelines.yml"
        
        if not pipelines_file.exists():
            return None
        
        registry_file = pipelines_file
        
        try:
            pipeline_config = self.load_yaml(registry_file)
            pipelines = pipeline_config.get("pipelines", [])
            
            # Find the pipeline reference
            pipeline_ref = None
            for p in pipelines:
                if isinstance(p, dict) and p.get("id") == pipeline_id:
                    pipeline_ref = p
                    break
            
            if not pipeline_ref:
                return None
            
            # Apply default path resolution: pipelines/{id}.yml
            pipeline_id = pipeline_ref.get("id")
            config_file = pipeline_ref.get("config_file")
            if pipeline_id:
                resolved_config_file = resolve_config_path(config_file, "pipelines/{id}.yml", pipeline_id)
                config_file_path = self.root / "config" / resolved_config_file
            elif config_file:
                # Backward compatibility: explicit path provided
                config_file_path = self.root / "config" / config_file
            else:
                return None
            if config_file_path.exists():
                return self.load_yaml(config_file_path)
            
        except Exception as e:
            self.logger.debug("Failed to load individual pipeline {}: {}", pipeline_id, e)
        
        return None
    
    def _load_ui_manifest(self) -> Dict[str, Any]:
        """
        Load ui_manifest.yml file.
        
        Returns:
            UI manifest configuration dict (empty dict if not found)
        """
        ui_yml = self.root / "config" / "ui_manifest.yml"
        ui_yaml = self.root / "config" / "ui_manifest.yaml"
        
        if ui_yml.exists():
            return self.load_yaml(ui_yml)
        elif ui_yaml.exists():
            return self.load_yaml(ui_yaml)
        
        return {}
    
    def get_pipeline_display_info(self, pipeline_id: str) -> Dict[str, str]:
        """
        Get display info (title, subtitle, icon) for a pipeline.
        
        Pipeline files are linked to UI manifests by matching ID/filename:
        - Backend: config/pipelines/{pipeline_id}.yml
        - UI: config/ui_manifests/{pipeline_id}.yml
        
        The pipeline_id must match the filename (without extension) in both directories.
        
        Uses the following fallback strategy:
        1. Try ui_manifests/{pipeline_id}.yml (all UI metadata here)
        2. Fallback to ui_manifest.yml > pipelines[] (legacy pattern)
        3. Ultimate fallback - use pipeline_id as title
        
        Args:
            pipeline_id: Pipeline ID to get display info for (must match filename)
            
        Returns:
            Dict with 'title', 'subtitle', and 'icon' keys
        """
        # First try ui_manifests/{pipeline_id}.yml (all UI metadata here)
        ui_manifest_file = self.root / "config" / "ui_manifests" / f"{pipeline_id}.yml"
        if ui_manifest_file.exists():
            try:
                ui_config = self.load_yaml(ui_manifest_file)
                if all(k in ui_config for k in ["title", "subtitle", "icon"]):
                    self.logger.debug("Using UI metadata from ui_manifests/{}.yml: {}", pipeline_id, pipeline_id)
                    return {
                        "title": str(ui_config["title"]),
                        "subtitle": str(ui_config["subtitle"]),
                        "icon": str(ui_config["icon"]),
                    }
            except Exception as e:
                self.logger.debug("Failed to load ui_manifest for {}: {}", pipeline_id, e)
        
        # Fallback to ui_manifest.yml > pipelines[] (legacy pattern)
        ui_manifest = self._load_ui_manifest()
        if ui_manifest and "pipelines" in ui_manifest:
            pipelines = ui_manifest["pipelines"]
            if isinstance(pipelines, list):
                for p in pipelines:
                    if isinstance(p, dict) and p.get("id") == pipeline_id:
                        self.logger.debug("Using UI metadata from ui_manifest.yml (legacy pattern): {}", pipeline_id)
                        return {
                            "title": str(p.get("title", pipeline_id)),
                            "subtitle": str(p.get("subtitle", "")),
                            "icon": str(p.get("icon", "")),
                        }
        
        # Ultimate fallback
        self.logger.debug("Using fallback display info for pipeline: {}", pipeline_id)
        return {
            "title": pipeline_id,
            "subtitle": "",
            "icon": "",
        }

