"""
Widget Registry
Central registry for widget types and metadata
Enables plugin-like system for adding new widget types
"""

from typing import Dict, List, Optional
from dataclasses import dataclass, field

from topaz_agent_kit.utils.logger import Logger


@dataclass
class WidgetMetadata:
    """Metadata for a widget type"""
    widget_type: str
    category: str  # "input" | "viewer" | "selection" | "layout" | "array" | "rich" | "container"
    description: str
    default_props: Dict[str, any] = field(default_factory=dict)
    validation_schema: Optional[Dict[str, any]] = None
    supports_editing: bool = True  # False for view-only widgets


class WidgetRegistry:
    """Central registry for widget types and metadata"""
    
    _registry: Dict[str, WidgetMetadata] = {}
    _logger = Logger("WidgetRegistry")
    
    @classmethod
    def register(
        cls,
        widget_type: str,
        category: str,
        description: str,
        default_props: Optional[Dict[str, any]] = None,
        validation_schema: Optional[Dict[str, any]] = None,
        supports_editing: bool = True
    ) -> None:
        """
        Register a widget type
        
        Args:
            widget_type: Widget type identifier (e.g., "text", "markdown_editor")
            category: Widget category (input, viewer, selection, layout, array, rich, container)
            description: Human-readable description
            default_props: Default widget properties
            validation_schema: JSON Schema for widget-specific validation
            supports_editing: Whether widget supports user editing (False for view-only)
        """
        cls._registry[widget_type] = WidgetMetadata(
            widget_type=widget_type,
            category=category,
            description=description,
            default_props=default_props or {},
            validation_schema=validation_schema,
            supports_editing=supports_editing
        )
        cls._logger.debug("Registered widget: {} ({})", widget_type, category)
    
    @classmethod
    def get_metadata(cls, widget_type: str) -> Optional[WidgetMetadata]:
        """
        Get widget metadata
        
        Args:
            widget_type: Widget type identifier
            
        Returns:
            WidgetMetadata if found, None otherwise
        """
        return cls._registry.get(widget_type)
    
    @classmethod
    def list_widgets(cls, category: Optional[str] = None) -> List[WidgetMetadata]:
        """
        List all widgets, optionally filtered by category
        
        Args:
            category: Optional category filter
            
        Returns:
            List of WidgetMetadata objects
        """
        widgets = list(cls._registry.values())
        if category:
            widgets = [w for w in widgets if w.category == category]
        return widgets
    
    @classmethod
    def is_registered(cls, widget_type: str) -> bool:
        """Check if widget type is registered"""
        return widget_type in cls._registry
    
    @classmethod
    def get_default_props(cls, widget_type: str) -> Dict[str, any]:
        """
        Get default properties for a widget type
        
        Args:
            widget_type: Widget type identifier
            
        Returns:
            Dictionary of default properties
        """
        metadata = cls.get_metadata(widget_type)
        return metadata.default_props if metadata else {}
    
    @classmethod
    def supports_editing(cls, widget_type: str) -> bool:
        """
        Check if widget supports editing
        
        Args:
            widget_type: Widget type identifier
            
        Returns:
            True if widget supports editing, False otherwise
        """
        metadata = cls.get_metadata(widget_type)
        return metadata.supports_editing if metadata else True


# Register existing widgets
def _register_builtin_widgets():
    """Register built-in widgets"""
    
    # Text Input Widgets
    WidgetRegistry.register(
        widget_type="text",
        category="input",
        description="Single-line text input",
        default_props={"debounceMs": 500},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="textarea",
        category="input",
        description="Multi-line text input",
        default_props={"debounceMs": 500, "rows": 6},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="markdown_editor",
        category="input",
        description="Rich markdown editor with toolbar",
        default_props={"debounceMs": 800, "toolbar": True, "preview": True},
        supports_editing=True
    )
    
    # Number Input Widgets
    WidgetRegistry.register(
        widget_type="number",
        category="input",
        description="Number input with min/max/step support",
        default_props={"debounceMs": 500, "step": 1},
        supports_editing=True
    )
    
    # Selection Widgets
    WidgetRegistry.register(
        widget_type="select",
        category="selection",
        description="Dropdown select input (single or multiple)",
        default_props={"multiple": False},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="checkbox",
        category="selection",
        description="Single checkbox input",
        default_props={},
        supports_editing=True
    )
    
    # Date/Time Widgets
    WidgetRegistry.register(
        widget_type="date",
        category="input",
        description="Date input",
        default_props={"debounceMs": 500, "type": "date"},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="datetime",
        category="input",
        description="Date and time input",
        default_props={"debounceMs": 500, "type": "datetime-local"},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="time",
        category="input",
        description="Time input",
        default_props={"debounceMs": 500, "type": "time"},
        supports_editing=True
    )
    
    # Viewer Widgets (read-only)
    WidgetRegistry.register(
        widget_type="markdown_viewer",
        category="viewer",
        description="Read-only markdown renderer",
        default_props={},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="html_viewer",
        category="viewer",
        description="Read-only HTML renderer (sandboxed)",
        default_props={},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="json_viewer",
        category="viewer",
        description="Read-only JSON viewer with syntax highlighting",
        default_props={},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="pdf_viewer",
        category="viewer",
        description="Read-only PDF viewer",
        default_props={},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="image_viewer",
        category="viewer",
        description="Read-only image viewer (single or multiple images)",
        default_props={},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="code_viewer",
        category="viewer",
        description="Read-only code viewer with syntax highlighting",
        default_props={"language": "text"},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="video_viewer",
        category="viewer",
        description="Read-only video player",
        default_props={"controls": True, "autoplay": False, "loop": False, "muted": False},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="audio_viewer",
        category="viewer",
        description="Read-only audio player",
        default_props={"controls": True, "autoplay": False, "loop": False},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="map",
        category="viewer",
        description="Interactive map widget for location display and route visualization",
        default_props={"height": "400px", "tileLayer": "openstreetmap", "showControls": True},
        supports_editing=False
    )
    
    # Additional Input Widgets
    WidgetRegistry.register(
        widget_type="email",
        category="input",
        description="Email input with validation",
        default_props={"debounceMs": 500},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="url",
        category="input",
        description="URL input with validation",
        default_props={"debounceMs": 500},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="password",
        category="input",
        description="Password input with show/hide toggle",
        default_props={},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="color",
        category="input",
        description="Color picker input",
        default_props={},
        supports_editing=True
    )
    
    # Array/List Widgets
    WidgetRegistry.register(
        widget_type="list_editor",
        category="array",
        description="Editable list/array editor with add/remove/reorder",
        default_props={"itemType": "text"},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="key_value_form",
        category="array",
        description="Editable key-value pairs form",
        default_props={},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="list_view",
        category="array",
        description="Read-only list view",
        default_props={},
        supports_editing=False
    )
    
    # File Upload Widgets
    WidgetRegistry.register(
        widget_type="file_upload",
        category="input",
        description="File upload widget for app sessions",
        default_props={"multiple": False},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="image_upload",
        category="input",
        description="Image upload widget with preview",
        default_props={"multiple": False},
        supports_editing=True
    )
    
    # Table Widgets
    WidgetRegistry.register(
        widget_type="table_editor",
        category="array",
        description="Editable table/grid editor",
        default_props={},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="table_view",
        category="array",
        description="Read-only table view",
        default_props={},
        supports_editing=False
    )
    
    # Cards Widgets
    WidgetRegistry.register(
        widget_type="card",
        category="container",
        description="Single card widget",
        default_props={},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="cards_grid",
        category="container",
        description="Display array as grid of cards (supports editing)",
        default_props={"columns": 3},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="cards_horizontal",
        category="container",
        description="Display array as horizontal cards (supports editing)",
        default_props={},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="cards_vertical",
        category="container",
        description="Display array as vertical cards (supports editing)",
        default_props={},
        supports_editing=True
    )
    
    # Chips Widgets
    WidgetRegistry.register(
        widget_type="chips_horizontal",
        category="container",
        description="Display array as horizontal chips/tags (supports editing)",
        default_props={},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="chips_vertical",
        category="container",
        description="Display array as vertical chips/tags (supports editing)",
        default_props={},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="chips_view",
        category="container",
        description="Read-only chips display",
        default_props={},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="tags_input",
        category="selection",
        description="Editable tags/chips input",
        default_props={},
        supports_editing=True
    )
    
    # Selection Widgets
    WidgetRegistry.register(
        widget_type="radio",
        category="selection",
        description="Radio button group for single selection",
        default_props={"direction": "vertical"},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="checkbox_group",
        category="selection",
        description="Multiple checkboxes group",
        default_props={"direction": "vertical"},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="multiselect",
        category="selection",
        description="Multi-select dropdown",
        default_props={},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="toggle",
        category="selection",
        description="Toggle switch (on/off)",
        default_props={},
        supports_editing=True
    )
    
    # Editor Widgets
    WidgetRegistry.register(
        widget_type="rich_text_editor",
        category="input",
        description="WYSIWYG rich text editor",
        default_props={},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="code_editor",
        category="input",
        description="Code editor with syntax highlighting",
        default_props={"language": "text"},
        supports_editing=True
    )
    
    # Other Widgets
    WidgetRegistry.register(
        widget_type="slider",
        category="input",
        description="Range slider input",
        default_props={"min": 0, "max": 100, "step": 1, "showValue": True},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="rating",
        category="input",
        description="Star rating widget",
        default_props={"maxRating": 5, "size": "md", "allowHalf": False},
        supports_editing=True
    )
    
    WidgetRegistry.register(
        widget_type="divider",
        category="layout",
        description="Visual divider/separator",
        default_props={"orientation": "horizontal"},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="spacer",
        category="layout",
        description="Spacing widget for layout",
        default_props={"height": "1rem"},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="section",
        category="container",
        description="Section container widget",
        default_props={"collapsible": False, "defaultCollapsed": False},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="tabs",
        category="container",
        description="Tabbed interface widget",
        default_props={},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="accordion",
        category="container",
        description="Accordion/collapsible widget",
        default_props={"allowMultiple": False},
        supports_editing=False
    )
    
    # Download Widget
    WidgetRegistry.register(
        widget_type="download",
        category="viewer",
        description="Download/export widget for exporting documents",
        default_props={
            "allowedFormats": ["markdown", "html", "pdf", "docx", "pptx", "xlsx", "txt"],
            "defaultFormat": "markdown",
            "defaultFilename": "",
            "label": "Download",
        },
        supports_editing=False
    )
    
    # Chart Widgets
    WidgetRegistry.register(
        widget_type="line_chart",
        category="viewer",
        description="Line chart widget for displaying time series or continuous data",
        default_props={"height": 400, "showLegend": True, "showGrid": True},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="bar_chart",
        category="viewer",
        description="Bar chart widget (vertical or horizontal)",
        default_props={"height": 400, "orientation": "vertical", "showLegend": True},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="pie_chart",
        category="viewer",
        description="Pie or donut chart widget",
        default_props={"height": 400, "donut": False, "showLegend": True},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="area_chart",
        category="viewer",
        description="Area chart widget (filled line chart)",
        default_props={"height": 400, "stacked": False, "showLegend": True},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="scatter_chart",
        category="viewer",
        description="Scatter plot chart widget",
        default_props={"height": 400, "showLegend": True},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="radar_chart",
        category="viewer",
        description="Radar/spider chart widget for multi-dimensional data",
        default_props={"height": 400, "showLegend": True},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="gauge_chart",
        category="viewer",
        description="Gauge/speedometer chart widget for single metrics",
        default_props={"height": 300, "min": 0, "max": 100},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="waterfall_chart",
        category="viewer",
        description="Waterfall chart widget for cumulative changes",
        default_props={"height": 400, "showLegend": True},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="bubble_chart",
        category="viewer",
        description="Bubble chart widget (scatter with size dimension)",
        default_props={"height": 400, "showLegend": True},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="funnel_chart",
        category="viewer",
        description="Funnel chart widget for conversion flows",
        default_props={"height": 400, "showLegend": True},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="candlestick_chart",
        category="viewer",
        description="Candlestick chart widget for financial/OHLC data",
        default_props={"height": 400, "showLegend": True},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="sankey_chart",
        category="viewer",
        description="Sankey diagram widget for flow/network visualization",
        default_props={"height": 400},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="heatmap",
        category="viewer",
        description="Heatmap widget for matrix/2D data visualization",
        default_props={"height": 400},
        supports_editing=False
    )
    
    WidgetRegistry.register(
        widget_type="treemap",
        category="viewer",
        description="Treemap widget for hierarchical data visualization",
        default_props={"height": 400},
        supports_editing=False
    )


# Auto-register built-in widgets on module import
_register_builtin_widgets()
