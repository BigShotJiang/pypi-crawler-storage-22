"""
Operations Assistant Module

Specialized assistant for Operations Center that helps users manage HITL requests
and cases through natural language interactions.
"""

import json
from typing import Any, Dict, List, Optional
from pathlib import Path

from agent_framework import ChatAgent, ChatMessage, Role

from topaz_agent_kit.frameworks.framework_config_manager import FrameworkConfigManager
from topaz_agent_kit.frameworks.framework_model_factory import FrameworkModelFactory
from topaz_agent_kit.utils.logger import Logger
from topaz_agent_kit.core.chat_database import ChatDatabase
from topaz_agent_kit.core.hitl_queue_manager import HITLQueueManager
from topaz_agent_kit.core.resume_handler import ResumeHandler
from topaz_agent_kit.core.case_manager import CaseManager
from topaz_agent_kit.utils.prompt_loader import PromptLoader
from topaz_agent_kit.utils.json_utils import JSONUtils
from topaz_agent_kit.utils.assistant_config import get_assistant_config, load_ui_manifest
from topaz_agent_kit.orchestration.assistant_tools import AssistantToolsMixin
from topaz_agent_kit.orchestration.widget_collector import (
    WidgetCollector,
    set_widget_collector,
    get_widget_collector,
)


class OperationsAssistant(AssistantToolsMixin):
    """
    Operations Assistant for managing HITL requests and cases.
    
    Similar to Assistant class but specialized for operations center tasks.
    Provides tools for approving/rejecting HITL requests, viewing cases,
    and managing the operations queue.
    """
    
    def __init__(
        self,
        config: Dict[str, Any],
        project_dir: str,
        database: ChatDatabase,
        session_id: Optional[str] = None,
        resume_handler: Optional[ResumeHandler] = None,
        case_manager: Optional[CaseManager] = None,
    ):
        """
        Initialize Operations Assistant.
        
        Args:
            config: Configuration dictionary (must contain operations_assistant section)
            project_dir: Project directory path
            database: ChatDatabase instance
            session_id: Optional session ID (creates new if not provided)
            resume_handler: Optional ResumeHandler for resuming pipelines after HITL responses
            case_manager: Optional CaseManager for managing cases
        """
        self.logger = Logger("OperationsAssistant")
        self._project_dir = project_dir
        self._database = database
        self._hitl_queue_manager = HITLQueueManager(database)
        self._resume_handler = resume_handler
        self._case_manager = case_manager or CaseManager(database)
        
        # Load operations assistant config
        self._assistant_config = config.get("operations_assistant")
        if not self._assistant_config:
            # Fallback to assistant config if operations_assistant not found
            self._assistant_config = config.get("assistant")
            if not self._assistant_config:
                raise ValueError("operations_assistant or assistant section missing in config")
        
        self._agent_id = self._assistant_config.get("id", "operations_assistant")
        self._framework_type = self._assistant_config.get("type", "maf")
        self._model_type = self._assistant_config.get("model", "azure_openai")
        self._llm = None
        self._agent = None
        
        # Load assistant instruction
        self._prompt_loader = PromptLoader(self._project_dir)
        self._prompt_spec = self._assistant_config.get("prompt", {})
        self._prompt_spec_instruction = self._prompt_spec.get("instruction")
        
        if not self._prompt_spec_instruction:
            # Default prompt path
            self._prompt_spec_instruction = "prompts/operations_assistant.jinja"
        
        # Load the prompt template (raw, not rendered yet)
        # We'll render it with context when creating the agent
        self._assistant_instruction_template = self._prompt_loader.load_prompt(
            self._prompt_spec_instruction
        )
        
        if not self._assistant_instruction_template:
            self.logger.error(
                "Failed to load operations assistant instruction: {}",
                self._prompt_spec_instruction
            )
            raise ValueError(
                f"Operations assistant prompt not found: {self._prompt_spec_instruction}. "
                "Please ensure the prompt file exists in config/prompts/"
            )
        
        # Session management
        if session_id:
            self._session_id = session_id
            self.logger.info("Using provided session ID: {}", session_id)
        else:
            # Create a new session for operations assistant
            self._session_id = f"ops-{Path(project_dir).name}-{id(self)}"
            self.logger.info("Created new operations session ID: {}", self._session_id)
        
        self._thread = None
        
        # Context for current operation (case_id, queue_item_id)
        self._context: Dict[str, Any] = {}
        
        self.logger.success(
            "Operations Assistant initialized with session ID: {}", self._session_id
        )
    
    def set_context(self, context: Dict[str, Any]) -> None:
        """
        Set context for the assistant (case_id, queue_item_id, etc.).
        
        Args:
            context: Context dictionary with case_id, queue_item_id, etc.
        """
        context_changed = self._context != context
        self._context = context.copy()
        self.logger.debug("Updated context: {}", context)
        
        # If context changed and agent already exists, mark it for recreation
        # This ensures the prompt is re-rendered with the new context
        if context_changed and self._agent:
            self.logger.info("Context changed, agent will be recreated on next execute()")
            # Don't delete agent here, let execute() handle recreation to avoid async issues
    
    def get_context(self) -> Dict[str, Any]:
        """Get current context."""
        return self._context.copy()
    
    async def _initialize_llm(self) -> None:
        """Initialize LLM using unified framework-aware factory."""
        try:
            config_manager = FrameworkConfigManager()
            model_config = config_manager.get_model_config(
                model_type=self._model_type,
                framework=self._framework_type,
            )
            
            self._llm = FrameworkModelFactory.get_model(
                model_type=self._model_type,
                framework=self._framework_type,
                **model_config,
            )
            
            self.logger.success(
                "Initialized Operations Assistant with {} {} model",
                self._framework_type.title(),
                self._model_type,
            )
        except Exception as e:
            self.logger.error("Failed to initialize LLM: {}", e)
            raise
    
    async def _create_assistant_agent(self) -> None:
        """Create operations assistant agent with tools."""
        try:
            # Load ui_manifest and get assistant config
            ui_manifest = load_ui_manifest(Path(self._project_dir))
            assistant_config = get_assistant_config(ui_manifest, "operations")
            
            # Render the prompt template with context variables and assistant config
            # The template may contain Jinja2 syntax like {{ context.case_id }}
            instruction = self._prompt_loader.render_prompt(
                self._assistant_instruction_template,
                variables={
                    "context": self._context,
                    "assistant_name": assistant_config["name"],
                    "assistant_subtitle": assistant_config["subtitle"],
                    "assistant_greeting": assistant_config["greeting"],
                }
            )
            
            self._agent = ChatAgent(
                chat_client=self._llm,
                name=self._agent_id,
                description="Operations Assistant - manages HITL requests and cases",
                instructions=instruction,
                tools=[
                    self.approve_hitl_request,
                    self.reject_hitl_request,
                    self.select_hitl_option,
                    self.retry_hitl_response,
                    self.get_case_details,
                    self.get_queue_items,
                    self.get_case_list,
                    self.add_hitl_notes,
                    self.delete_case,
                    self.delete_cases,
                    self.get_agent_count,
                    self.get_agent_list,
                    self.get_agent_details,
                    self.get_current_datetime,
                    self.get_current_location,
                    self.insert_widget,
                    self.send_a2ui_message,
                ],
            )
            
            # Deserialize thread from database if available
            await self._deserialize_session_thread()
            
            self.logger.success("Operations assistant agent created successfully")
        except Exception as e:
            self.logger.error("Failed to create operations assistant agent: {}", e)
            raise
    
    async def initialize(self) -> None:
        """Initialize the operations assistant."""
        await self._initialize_llm()
        await self._create_assistant_agent()
    
    async def execute(
        self,
        user_message: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Execute a user message and return response.
        
        Args:
            user_message: User's message
            context: Optional context (case_id, queue_item_id, etc.)
            
        Returns:
            Dictionary with assistant_response and tool execution results
        """
        # Update context if provided
        context_changed = False
        old_context_was_empty = False
        if context:
            # Check if context actually changed BEFORE setting it
            old_context = self._context.copy() if self._context else {}
            old_context_was_empty = not old_context or len(old_context) == 0
            context_changed = old_context != context
            self.set_context(context)
            # For grouped case modal: inject full grouped case (signed contract + all change orders) so assistant can answer any sub-case or comparison questions
            if (
                self._context.get("is_grouped_case")
                and self._context.get("grouping_key")
                and self._context.get("pipeline_id")
                and self._case_manager
            ):
                case_config = self._load_case_config(self._context["pipeline_id"])
                if case_config:
                    try:
                        grouped_case = self._case_manager.get_grouped_case(
                            grouping_key=self._context["grouping_key"],
                            pipeline_id=self._context["pipeline_id"],
                            case_config=case_config,
                        )
                        if grouped_case:
                            self._context["grouped_case_full_text"] = json.dumps(
                                JSONUtils.normalize_for_ui(grouped_case),
                                indent=2,
                            )
                            sub_count = len(grouped_case.get("sub_cases") or [])
                            self.logger.info(
                                "Injected full grouped case into context (grouping_key={}, sub_cases={})",
                                self._context["grouping_key"],
                                sub_count,
                            )
                    except Exception as group_err:
                        self.logger.warning(
                            "Could not inject full grouped case for context: {}",
                            group_err,
                        )
            self.logger.info("Context updated in execute(). Old was empty: {}, Changed: {}, Has pipeline_metadata: {}", 
                           old_context_was_empty, context_changed, bool(context.get("pipeline_metadata")))
        
        # Initialize or recreate agent if needed
        # Recreate if:
        # 1. Agent doesn't exist yet
        # 2. Context changed
        # 3. Agent exists but was created with empty context and now we have context (initialization case)
        needs_recreation = not self._agent or context_changed or (self._agent and old_context_was_empty and context and len(context) > 0)
        if needs_recreation:
            self.logger.info("Recreating agent. Reason: agent_exists={}, context_changed={}, old_empty={}", 
                           bool(self._agent), context_changed, old_context_was_empty)
            if not self._llm:
                await self._initialize_llm()
            await self._create_assistant_agent()
        
        # Build user message with context
        message_text = user_message
        if self._context:
            context_info = []
            if self._context.get("case_id"):
                context_info.append(f"Case ID: {self._context['case_id']}")
            if self._context.get("queue_item_id"):
                context_info.append(f"Queue Item ID: {self._context['queue_item_id']}")
            if self._context.get("pipeline_id"):
                context_info.append(f"Pipeline: {self._context['pipeline_id']}")
            if context_info:
                message_text = f"{user_message}\n\nContext: {', '.join(context_info)}"
        
        message = ChatMessage(role=Role.USER, text=message_text)
        
        # Initialize widget collector for this turn
        widget_collector = None
        try:
            widget_collector = WidgetCollector()
            widget_limit = self._assistant_config.get("widget_limit", 10)
            widget_collector.set_max_widgets(widget_limit)
            set_widget_collector(widget_collector)
        except Exception as e:
            self.logger.warning("Failed to initialize widget collector: {}", e)
            widget_collector = WidgetCollector()  # Fallback
        
        # Run the agent
        try:
            response = await self._agent.run(
                message,
                tool_choice="required",
                thread=self._thread,
            )
            
            # Extract response
            result = None
            if response.value:
                # Response is a dict with assistant_response, tool_executed, etc.
                result = JSONUtils.normalize_for_ui(response.value)
            else:
                # Fallback to text response
                result = {
                    "assistant_response": str(response),
                    "success": True,
                }
            
            # Extract widgets from collector
            widgets = None
            if widget_collector:
                try:
                    collected_widgets = widget_collector.get_widgets()
                    if collected_widgets:
                        widgets = collected_widgets
                        self.logger.info("Extracted {} widget(s) from collector", len(widgets))
                    else:
                        self.logger.debug("No widgets found in collector")
                except Exception as e:
                    self.logger.warning("Failed to extract widgets from collector: {}", e)
            
            # Include widgets in result
            if widgets:
                # Convert widgets to dict format for JSON serialization
                try:
                    widgets_data = []
                    for widget in widgets:
                        if hasattr(widget, 'model_dump'):
                            widgets_data.append(widget.model_dump())
                        elif isinstance(widget, dict):
                            widgets_data.append(widget)
                        else:
                            # Fallback: try to convert to dict
                            self.logger.warning("Unexpected widget type: {}, converting to dict", type(widget))
                            widgets_data.append({
                                "widget_type": getattr(widget, 'widget_type', 'unknown'),
                                "data": getattr(widget, 'data', {}),
                                "props": getattr(widget, 'props', {}),
                                "binding": getattr(widget, 'binding', None),
                            })
                    result["widgets"] = widgets_data
                    self.logger.info("Including {} widget(s) in result", len(widgets_data))
                except Exception as e:
                    self.logger.error("Failed to convert widgets to dict format: {}", e, exc_info=True)
            
            # Serialize thread to database to maintain conversation history
            await self._serialize_session_thread()
            
            # Clean up widget collector
            if widget_collector:
                try:
                    widget_collector.clear()
                    set_widget_collector(None)
                except Exception as e:
                    self.logger.warning("Failed to clear widget collector: {}", e)
            
            return result
        except Exception as e:
            self.logger.error("Error executing operations assistant: {}", e)
            return {
                "assistant_response": f"I encountered an error: {str(e)}",
                "success": False,
                "error": str(e),
            }
    
    # === OPERATIONS TOOLS ===
    
    async def approve_hitl_request(
        self,
        queue_item_id: str,
        notes: Optional[str] = None,
    ) -> str:
        """
        Tool: Approve a pending HITL request.
        
        Args:
            queue_item_id: The queue item ID to approve
            notes: Optional notes to add
            
        Returns:
            JSON string with result
        """
        try:
            # Use resume handler if available to properly resume the pipeline
            if self._resume_handler:
                result = await self._resume_handler.resume_from_queue_response(
                    queue_item_id=queue_item_id,
                    decision="approve",
                    response_data={"notes": notes} if notes else None,
                    responded_by="assistant",  # Operations assistant responding on behalf of user
                )
            else:
                # Fallback to just submitting response (won't resume pipeline)
                self.logger.warning(
                    "ResumeHandler not available, only submitting response without resuming pipeline"
                )
                result = self._hitl_queue_manager.submit_response(
                    queue_item_id=queue_item_id,
                    decision="approve",
                    response_data={"notes": notes} if notes else None,
                    responded_by="assistant",  # Operations assistant responding on behalf of user
                )
            
            if result.get("success"):
                self.logger.info("Approved HITL request: {}", queue_item_id)
                return JSONUtils.normalize_for_ui({
                    "success": True,
                    "action": "approve",
                    "queue_item_id": queue_item_id,
                    "case_id": result.get("case_id"),
                    "message": f"Successfully approved HITL request {queue_item_id}. Pipeline will resume processing.",
                })
            else:
                error_msg = result.get("error", "Unknown error")
                self.logger.error("Failed to approve HITL request {}: {}", queue_item_id, error_msg)
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": error_msg,
                    "queue_item_id": queue_item_id,
                })
        except Exception as e:
            self.logger.error("Error approving HITL request: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
                "queue_item_id": queue_item_id,
            })
    
    async def reject_hitl_request(
        self,
        queue_item_id: str,
        notes: Optional[str] = None,
    ) -> str:
        """
        Tool: Reject a pending HITL request.
        
        Args:
            queue_item_id: The queue item ID to reject
            notes: Optional notes to add
            
        Returns:
            JSON string with result
        """
        try:
            # Use resume handler if available to properly resume the pipeline
            if self._resume_handler:
                result = await self._resume_handler.resume_from_queue_response(
                    queue_item_id=queue_item_id,
                    decision="reject",
                    response_data={"notes": notes} if notes else None,
                    responded_by="assistant",  # Operations assistant responding on behalf of user
                )
            else:
                # Fallback to just submitting response (won't resume pipeline)
                self.logger.warning(
                    "ResumeHandler not available, only submitting response without resuming pipeline"
                )
                result = self._hitl_queue_manager.submit_response(
                    queue_item_id=queue_item_id,
                    decision="reject",
                    response_data={"notes": notes} if notes else None,
                    responded_by="assistant",  # Operations assistant responding on behalf of user
                )
            
            if result.get("success"):
                self.logger.info("Rejected HITL request: {}", queue_item_id)
                return JSONUtils.normalize_for_ui({
                    "success": True,
                    "action": "reject",
                    "queue_item_id": queue_item_id,
                    "case_id": result.get("case_id"),
                    "message": f"Successfully rejected HITL request {queue_item_id}. Pipeline will resume processing.",
                })
            else:
                error_msg = result.get("error", "Unknown error")
                self.logger.error("Failed to reject HITL request {}: {}", queue_item_id, error_msg)
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": error_msg,
                    "queue_item_id": queue_item_id,
                })
        except Exception as e:
            self.logger.error("Error rejecting HITL request: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
                "queue_item_id": queue_item_id,
                })
    
    async def select_hitl_option(
        self,
        queue_item_id: str,
        option_value: str,
        notes: Optional[str] = None,
    ) -> str:
        """
        Tool: Select an option for a selection gate HITL request.
        
        Use this when the HITL request is a selection gate (has multiple options to choose from).
        First call get_queue_items to see available options for the queue item.
        
        Args:
            queue_item_id: The queue item ID
            option_value: The value/ID of the option to select (must match one of the available options)
            notes: Optional notes to add
            
        Returns:
            JSON string with result
        """
        try:
            # Get queue item to verify it's a selection gate and get available options
            queue_item = self._hitl_queue_manager.get_queue_item(queue_item_id)
            if not queue_item:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": f"Queue item {queue_item_id} not found",
                    "queue_item_id": queue_item_id,
                })
            
            gate_type = queue_item.get("gate_type")
            if gate_type != "selection":
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": f"Queue item {queue_item_id} is not a selection gate (type: {gate_type}). Use approve_hitl_request or reject_hitl_request instead.",
                    "queue_item_id": queue_item_id,
                })
            
            # Get available options
            options = queue_item.get("options") or []
            if not options:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": f"No options available for selection gate {queue_item_id}",
                    "queue_item_id": queue_item_id,
                })
            
            # Verify the option_value matches one of the available options
            # Options can be dicts with 'value' or 'id' keys, or just strings
            option_values = []
            for opt in options:
                if isinstance(opt, dict):
                    option_values.append(opt.get("value") or opt.get("id") or str(opt))
                else:
                    option_values.append(str(opt))
            
            if option_value not in option_values:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": f"Option '{option_value}' not found. Available options: {', '.join(option_values)}",
                    "queue_item_id": queue_item_id,
                    "available_options": option_values,
                })
            
            # Use resume handler if available to properly resume the pipeline
            if self._resume_handler:
                result = await self._resume_handler.resume_from_queue_response(
                    queue_item_id=queue_item_id,
                    decision=option_value,  # For selection gates, decision is the selected option value
                    response_data={"notes": notes, "selection": option_value} if notes else {"selection": option_value},
                    responded_by="assistant",  # Operations assistant responding on behalf of user
                )
            else:
                # Fallback to just submitting response (won't resume pipeline)
                self.logger.warning(
                    "ResumeHandler not available, only submitting response without resuming pipeline"
                )
                result = self._hitl_queue_manager.submit_response(
                    queue_item_id=queue_item_id,
                    decision=option_value,
                    response_data={"notes": notes, "selection": option_value} if notes else {"selection": option_value},
                    responded_by="assistant",  # Operations assistant responding on behalf of user
                )
            
            if result.get("success"):
                self.logger.info("Selected option '{}' for HITL request: {}", option_value, queue_item_id)
                return JSONUtils.normalize_for_ui({
                    "success": True,
                    "action": "select",
                    "queue_item_id": queue_item_id,
                    "case_id": result.get("case_id"),
                    "option_value": option_value,
                    "message": f"Successfully selected option '{option_value}' for HITL request {queue_item_id}. Pipeline will resume processing.",
                })
            else:
                error_msg = result.get("error", "Unknown error")
                self.logger.error("Failed to select option for HITL request {}: {}", queue_item_id, error_msg)
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": error_msg,
                    "queue_item_id": queue_item_id,
                })
        except Exception as e:
            self.logger.error("Error selecting option for HITL request: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
                "queue_item_id": queue_item_id,
            })
    
    async def retry_hitl_response(self, queue_item_id: str) -> str:
        """
        Tool: Retry a failed HITL response.
        
        Use this when a HITL response failed and you want to retry it.
        This resets the queue item back to pending status so you can respond again.
        
        Args:
            queue_item_id: The queue item ID to retry
            
        Returns:
            JSON string with result
        """
        try:
            result = self._hitl_queue_manager.reset_queue_item_for_retry(queue_item_id)
            
            if result.get("success"):
                self.logger.info("Reset queue item for retry: {}", queue_item_id)
                return JSONUtils.normalize_for_ui({
                    "success": True,
                    "queue_item_id": queue_item_id,
                    "previous_status": result.get("previous_status"),
                    "message": f"Queue item {queue_item_id} has been reset to pending. You can now retry the response using approve_hitl_request, reject_hitl_request, or select_hitl_option.",
                })
            else:
                error_msg = result.get("error", "Unknown error")
                self.logger.error("Failed to retry HITL response {}: {}", queue_item_id, error_msg)
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": error_msg,
                    "queue_item_id": queue_item_id,
                })
        except Exception as e:
            self.logger.error("Error retrying HITL response: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
                "queue_item_id": queue_item_id,
            })
    
    async def get_case_details(self, case_id: str) -> str:
        """
        Tool: Get detailed information about a case.
        
        Supports both individual cases and grouped cases:
        - Individual case: case_id (e.g., "ABC-123-1")
        - Grouped case: grouping_key (e.g., "ABC-123")
        
        Args:
            case_id: The case ID or grouping key to retrieve
            
        Returns:
            JSON string with case details (individual case or grouped case)
        """
        try:
            # First, try to get as individual case
            case = self._database.get_pipeline_case(case_id)
            
            if case:
                self.logger.debug("Retrieved case details: {}", case_id)
                return JSONUtils.normalize_for_ui({
                    "success": True,
                    "case": case,
                    "is_grouped": False,
                })
            
            # Check if context provides grouped case information
            # This is more efficient than searching through all cases
            if self._case_manager and self._context:
                context_grouping_key = self._context.get("grouping_key")
                context_pipeline_id = self._context.get("pipeline_id")
                context_is_grouped = self._context.get("is_grouped_case", False)
                
                # If context indicates this is a grouped case and case_id matches grouping_key
                if context_is_grouped and context_grouping_key == case_id and context_pipeline_id:
                    try:
                        case_config = self._load_case_config(context_pipeline_id)
                        if case_config:
                            grouped_case = self._case_manager.get_grouped_case(
                                grouping_key=case_id,
                                pipeline_id=context_pipeline_id,
                                case_config=case_config
                            )
                            
                            if grouped_case:
                                self.logger.debug("Retrieved grouped case details from context: {} (pipeline: {})", case_id, context_pipeline_id)
                                return JSONUtils.normalize_for_ui({
                                    "success": True,
                                    "group": grouped_case,
                                    "is_grouped": True,
                                    "grouping_key": case_id,
                                })
                    except Exception as context_err:
                        self.logger.debug("Error getting grouped case from context: {}", context_err)
                        # Fall through to search logic
            
            # If not found as individual case or via context, try as grouped case
            # For pipelines that use grouping (like covenant), the grouping_key is extracted
            # from case_data dynamically. We need to search through cases and extract
            # grouping_key from case_data to find matches.
            if self._case_manager:
                try:
                    # Search through recent cases to find ones where grouping_key
                    # (extracted from case_data) matches
                    # Limit search to recent 1000 cases to avoid performance issues
                    recent_cases = self._database.list_pipeline_cases(limit=1000)
                    
                    # Group cases by pipeline_id to process them efficiently
                    cases_by_pipeline: Dict[str, List[Dict[str, Any]]] = {}
                    for case_item in recent_cases:
                        pipeline_id = case_item.get("pipeline_id")
                        if pipeline_id:
                            if pipeline_id not in cases_by_pipeline:
                                cases_by_pipeline[pipeline_id] = []
                            cases_by_pipeline[pipeline_id].append(case_item)
                    
                    # For each pipeline, try to find cases with matching grouping_key
                    for pipeline_id, pipeline_cases in cases_by_pipeline.items():
                        try:
                            case_config = self._load_case_config(pipeline_id)
                            if not case_config:
                                continue
                            
                            grouping_config = case_config.get("grouping")
                            if not grouping_config:
                                continue
                            
                            grouping_key_expression = grouping_config.get("grouping_key_expression")
                            if not grouping_key_expression:
                                continue
                            
                            # Check if any case in this pipeline has a matching grouping_key
                            for case_item in pipeline_cases:
                                case_data = case_item.get("case_data", {})
                                if not isinstance(case_data, dict):
                                    continue
                                
                                # Extract grouping_key from case_data
                                try:
                                    # Reconstruct upstream from case_data for grouping_key extraction
                                    upstream = {}
                                    for key, value in case_data.items():
                                        if not key.startswith("_"):  # Raw agent outputs
                                            upstream[key] = value
                                    
                                    # Extract grouping_key using the case manager's grouping extractor
                                    extracted_key = self._case_manager.grouping_extractor.extract_grouping_key(
                                        upstream=upstream,
                                        grouping_key_expression=grouping_key_expression,
                                    )
                                    
                                    if extracted_key == case_id:
                                        # Found a match! Get the grouped case
                                        grouped_case = self._case_manager.get_grouped_case(
                                            grouping_key=case_id,
                                            pipeline_id=pipeline_id,
                                            case_config=case_config
                                        )
                                        
                                        if grouped_case:
                                            self.logger.debug("Retrieved grouped case details: {} (pipeline: {})", case_id, pipeline_id)
                                            return JSONUtils.normalize_for_ui({
                                                "success": True,
                                                "group": grouped_case,
                                                "is_grouped": True,
                                                "grouping_key": case_id,
                                            })
                                except Exception as extract_err:
                                    self.logger.debug("Error extracting grouping_key: {}", extract_err)
                                    continue
                        except Exception as pipeline_err:
                            self.logger.debug("Error processing pipeline {}: {}", pipeline_id, pipeline_err)
                            continue
                            
                except Exception as grouped_err:
                    self.logger.debug("Error trying to get grouped case: {}", grouped_err)
                    # Fall through to not found error
            
            # Not found as individual or grouped case
            self.logger.warning("Case not found: {} (searched individual cases and grouped cases across all pipelines)", case_id)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": f"Case {case_id} not found (checked both individual and grouped cases)",
                "case_id": case_id,
            })
        except Exception as e:
            self.logger.error("Error getting case details: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
                "case_id": case_id,
            })
    
    def _load_case_config(self, pipeline_id: str) -> Optional[Dict[str, Any]]:
        """
        Load case configuration for a pipeline.
        
        Args:
            pipeline_id: Pipeline ID
            
        Returns:
            Case config dictionary or None if not found
        """
        try:
            import yaml
            project_path = Path(self._project_dir)
            
            # Load pipeline config to get operations.config_file
            pipeline_config_path = project_path / "config" / "pipelines" / f"{pipeline_id}.yml"
            if not pipeline_config_path.exists():
                self.logger.debug("Pipeline config not found: {}", pipeline_config_path)
                return None
            
            with open(pipeline_config_path, "r", encoding="utf-8") as f:
                pipeline_config = yaml.safe_load(f) or {}
            
            # Get operations config file path
            operations = pipeline_config.get("operations") or {}
            case_config_file = operations.get("config_file")
            
            # Apply default path resolution if not specified
            if not case_config_file:
                from topaz_agent_kit.utils.path_resolver import resolve_config_path
                case_config_file = resolve_config_path(
                    None, "operations/{id}.yml", pipeline_id
                )
            
            if not case_config_file:
                self.logger.debug("No operations.config_file for pipeline: {}", pipeline_id)
                return None
            
            # Load case config
            case_config_path = project_path / "config" / case_config_file
            if not case_config_path.exists():
                self.logger.debug("Case config file not found: {}", case_config_path)
                return None
            
            with open(case_config_path, "r", encoding="utf-8") as f:
                case_config = yaml.safe_load(f) or {}
            
            return case_config
        except Exception as e:
            self.logger.debug("Error loading case config for pipeline {}: {}", pipeline_id, e)
            return None
    
    async def get_queue_items(
        self,
        status: Optional[str] = None,
        pipeline_id: Optional[str] = None,
        limit: int = 20,
    ) -> str:
        """
        Tool: List HITL queue items with optional filters.
        
        Args:
            status: Filter by status (pending, responded, etc.)
            pipeline_id: Filter by pipeline
            limit: Maximum number of results
            
        Returns:
            JSON string with queue items
        """
        try:
            items = self._hitl_queue_manager.list_queue(
                pipeline_id=pipeline_id,
                status=status,
                limit=limit,
            )
            
            self.logger.debug("Retrieved {} queue items", len(items))
            return JSONUtils.normalize_for_ui({
                "success": True,
                "items": items,
                "count": len(items),
            })
        except Exception as e:
            self.logger.error("Error getting queue items: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
                "items": [],
            })
    
    async def get_case_list(
        self,
        status: Optional[str] = None,
        pipeline_id: Optional[str] = None,
        limit: int = 20,
    ) -> str:
        """
        Tool: List cases with optional filters.
        
        Args:
            status: Filter by status
            pipeline_id: Filter by pipeline
            limit: Maximum number of results
            
        Returns:
            JSON string with cases
        """
        try:
            cases = self._database.list_pipeline_cases(
                pipeline_id=pipeline_id,
                status=status,
                limit=limit,
            )
            
            self.logger.debug("Retrieved {} cases", len(cases))
            return JSONUtils.normalize_for_ui({
                "success": True,
                "cases": cases,
                "count": len(cases),
            })
        except Exception as e:
            self.logger.error("Error getting case list: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
                "cases": [],
            })
    
    async def add_hitl_notes(
        self,
        queue_item_id: str,
        notes: str,
    ) -> str:
        """
        Tool: Add notes to a HITL request.
        
        Args:
            queue_item_id: The queue item ID
            notes: Notes to add
            
        Returns:
            JSON string with result
        """
        try:
            # Get current queue item
            queue_item = self._hitl_queue_manager.get_queue_item(queue_item_id)
            
            if not queue_item:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": f"Queue item {queue_item_id} not found",
                })
            
            # Get existing response_data
            existing_response_data = {}
            if queue_item.get("response_data"):
                try:
                    if isinstance(queue_item["response_data"], str):
                        existing_response_data = json.loads(queue_item["response_data"])
                    else:
                        existing_response_data = queue_item["response_data"]
                except (json.JSONDecodeError, TypeError):
                    existing_response_data = {}
            
            # Append notes to existing notes
            existing_notes = existing_response_data.get("notes", "")
            if existing_notes:
                updated_notes = f"{existing_notes}\n{notes}"
            else:
                updated_notes = notes
            
            # Update response_data with new notes
            updated_response_data = {**existing_response_data, "notes": updated_notes}
            
            # Get current decision or use "pending" if not set
            current_decision = queue_item.get("decision") or queue_item.get("response_action") or "pending"
            
            # Update the database
            success = self._database.update_hitl_queue_response(
                queue_item_id=queue_item_id,
                decision=current_decision,
                response_data=updated_response_data,
            )
            
            if success:
                self.logger.info("Added notes to queue item: {}", queue_item_id)
                return JSONUtils.normalize_for_ui({
                    "success": True,
                    "queue_item_id": queue_item_id,
                    "message": "Notes added successfully",
                })
            else:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": "Failed to update notes",
                    "queue_item_id": queue_item_id,
                })
        except Exception as e:
            self.logger.error("Error adding notes: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
                "queue_item_id": queue_item_id,
            })
    
    async def delete_case(self, case_id: str) -> str:
        """
        Tool: Delete a specific case and all associated data.
        
        Args:
            case_id: The case ID to delete
            
        Returns:
            JSON string with result
        """
        try:
            success = self._case_manager.delete_case(case_id)
            
            if success:
                self.logger.info("Deleted case: {}", case_id)
                return JSONUtils.normalize_for_ui({
                    "success": True,
                    "case_id": case_id,
                    "message": f"Case {case_id} deleted successfully",
                })
            else:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": "Failed to delete case",
                    "case_id": case_id,
                })
        except Exception as e:
            self.logger.error("Error deleting case: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
                "case_id": case_id,
            })
    
    async def delete_cases(
        self,
        pipeline_id: Optional[str] = None,
        status: Optional[str] = None,
    ) -> str:
        """
        Tool: Delete multiple cases with optional filters.
        
        Args:
            pipeline_id: Filter by pipeline (optional)
            status: Filter by status (optional)
            
        Returns:
            JSON string with result including deleted_count
        """
        try:
            deleted_count = self._case_manager.delete_cases(
                pipeline_id=pipeline_id,
                status=status,
            )
            
            self.logger.info("Deleted {} cases", deleted_count)
            return JSONUtils.normalize_for_ui({
                "success": True,
                "deleted_count": deleted_count,
                "message": f"Deleted {deleted_count} case(s)",
                "pipeline_id": pipeline_id,
                "status": status,
            })
        except Exception as e:
            self.logger.error("Error deleting cases: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
                "deleted_count": 0,
            })
    
    async def get_agent_count(self) -> str:
        """
        Tool: Get the number of agents in the current workflow.
        
        Use this when user asks "how many agents", "how many agents do we have", 
        "how many agents are in this workflow", etc.
        
        Returns:
            JSON string with agent count
        """
        try:
            pipeline_metadata = self._context.get("pipeline_metadata") if self._context else None
            if not pipeline_metadata:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": "Pipeline metadata not available in context",
                    "agent_count": 0,
                })
            
            pipeline_agents = pipeline_metadata.get("pipeline_agents", [])
            agent_count = len(pipeline_agents)
            
            self.logger.debug("Retrieved agent count: {}", agent_count)
            return JSONUtils.normalize_for_ui({
                "success": True,
                "agent_count": agent_count,
                "message": f"There are {agent_count} agent{'s' if agent_count != 1 else ''} in this workflow.",
            })
        except Exception as e:
            self.logger.error("Error getting agent count: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
                "agent_count": 0,
            })
    
    async def get_agent_list(self) -> str:
        """
        Tool: Get the list of agent names/titles in the current workflow.
        
        Use this when user asks "name them", "list the agents", "what are the agents", etc.
        
        Returns:
            JSON string with list of agent titles
        """
        try:
            pipeline_metadata = self._context.get("pipeline_metadata") if self._context else None
            if not pipeline_metadata:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": "Pipeline metadata not available in context",
                    "agents": [],
                })
            
            pipeline_agents = pipeline_metadata.get("pipeline_agents", [])
            agent_titles = [agent.get("title") or agent.get("id", "") for agent in pipeline_agents]
            
            self.logger.debug("Retrieved agent list: {}", agent_titles)
            return JSONUtils.normalize_for_ui({
                "success": True,
                "agents": agent_titles,
                "agent_count": len(agent_titles),
                "message": f"The workflow has {len(agent_titles)} agent{'s' if len(agent_titles) != 1 else ''}: {', '.join(agent_titles)}",
            })
        except Exception as e:
            self.logger.error("Error getting agent list: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
                "agents": [],
            })
    
    async def get_agent_details(self, agent_name: str) -> str:
        """
        Tool: Get details about a specific agent, including its purpose/responsibility.
        
        Use this when user asks "what does [agent name] do", "what is the responsibility of [agent name]",
        "what does [agent name] agent do", etc.
        
        Args:
            agent_name: The name or title of the agent (case-insensitive, partial matches OK)
            
        Returns:
            JSON string with agent details including exact purpose/subtitle
        """
        try:
            pipeline_metadata = self._context.get("pipeline_metadata") if self._context else None
            if not pipeline_metadata:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": "Pipeline metadata not available in context",
                })
            
            pipeline_agents = pipeline_metadata.get("pipeline_agents", [])
            agent_name_lower = agent_name.lower().strip()
            
            # Find matching agent (case-insensitive, partial match)
            matched_agent = None
            for agent in pipeline_agents:
                agent_title = (agent.get("title") or "").lower()
                agent_id = (agent.get("id") or "").lower()
                
                if agent_name_lower in agent_title or agent_name_lower in agent_id or agent_title in agent_name_lower:
                    matched_agent = agent
                    break
            
            if not matched_agent:
                # Return list of available agents
                available_titles = [agent.get("title") or agent.get("id", "") for agent in pipeline_agents]
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": f"Agent '{agent_name}' not found",
                    "available_agents": available_titles,
                    "message": f"I couldn't find an agent named '{agent_name}'. Available agents are: {', '.join(available_titles)}",
                })
            
            agent_title = matched_agent.get("title") or matched_agent.get("id", "")
            agent_subtitle = matched_agent.get("subtitle", "")
            
            self.logger.debug("Retrieved agent details for: {}", agent_title)
            return JSONUtils.normalize_for_ui({
                "success": True,
                "agent_title": agent_title,
                "agent_id": matched_agent.get("id", ""),
                "purpose": agent_subtitle,
                "message": f"The {agent_title} agent {agent_subtitle}",
            })
        except Exception as e:
            self.logger.error("Error getting agent details: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
            })
    
    async def _serialize_session_thread(self) -> None:
        """
        Serialize the session thread to database to maintain conversation history.
        """
        if not self._thread:
            self.logger.debug("No thread to serialize")
            return
        
        try:
            self.logger.debug(
                "Serializing session thread to database for session: {}",
                self._session_id,
            )
            serialized_thread = await self._thread.serialize()
            serialized_json = json.dumps(serialized_thread)
            
            # Store thread state in database
            success = self._database.update_chat_session(
                self._session_id, {"thread_state": serialized_json}
            )
            
            if success:
                self.logger.debug(
                    "Thread state saved to database for session: {}", self._session_id
                )
            else:
                self.logger.warning(
                    "Failed to save thread state to database for session: {}",
                    self._session_id,
                )
        except Exception as e:
            self.logger.error("Error serializing thread to database: {}", e)
    
    async def _deserialize_session_thread(self) -> None:
        """
        Deserialize the session thread from database to restore conversation history.
        """
        try:
            # Get session from database
            session_data = self._database.get_chat_session(self._session_id)
            
            if session_data and session_data.get('thread_state'):
                self.logger.debug(
                    "Deserializing session thread from database for session: {}",
                    self._session_id,
                )
                try:
                    serialized_thread = json.loads(session_data['thread_state'])
                    self._thread = await self._agent.deserialize_thread(serialized_thread)
                    self.logger.debug(
                        "Thread state loaded from database for session: {}",
                        self._session_id,
                    )
                except json.JSONDecodeError as e:
                    self.logger.warning(
                        "Failed to parse thread state JSON from database: {}. Creating new thread.",
                        e
                    )
                    self._thread = self._agent.get_new_thread()
            else:
                self.logger.debug(
                    "No thread state found in database for session: {}, creating new thread",
                    self._session_id,
                )
                self._thread = self._agent.get_new_thread()
        except Exception as e:
            self.logger.error("Error deserializing thread from database: {}", e)
            self._thread = self._agent.get_new_thread()