"""
Export Demo Command

Exports a project as a portable demo package that can run with a shared runtime.
"""

import os
import shutil
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Optional

from topaz_agent_kit.utils.logger import Logger


def get_runtime_version_from_environment(project_root: Path, logger: Logger) -> str:
    """Detect current runtime version from installed topaz-agent-kit."""
    try:
        import importlib.metadata
        version = importlib.metadata.version("topaz-agent-kit")
        logger.info(f"Detected Topaz Agent Kit version: {version}")
        return version
    except Exception:
        # Fallback: try to read from pyproject.toml
        try:
            pyproject_path = project_root.parent / "pyproject.toml"
            if pyproject_path.exists():
                with open(pyproject_path, "r") as f:
                    for line in f:
                        if line.strip().startswith("version ="):
                            version = line.split("=")[1].strip().strip('"').strip("'")
                            logger.info(f"Using version from pyproject.toml: {version}")
                            return version
        except Exception:
            pass
        
        logger.warning("Could not detect version, using default")
        return "0.0.0"


def create_launcher_script_sh(project_dir: Path, version: str) -> str:
    """Create shell launcher script."""
    return f"""#!/bin/bash
# Topaz Agent Kit Demo Launcher
# Project: {project_dir.name}
# Required Runtime Version: {version}

# Default service mode
SERVICE_MODE="${{1:-fastapi}}"

# Find runtime
find_runtime() {{
    # Check current directory
    for dir in ./tak-runtime-v*; do
        if [ -d "$dir" ] && [ -f "$dir/VERSION" ]; then
            echo "$dir"
            return 0
        fi
    done
    
    # Check parent directory
    for dir in ../tak-runtime-v*; do
        if [ -d "$dir" ] && [ -f "$dir/VERSION" ]; then
            echo "$dir"
            return 0
        fi
    done
    
    return 1
}}

RUNTIME_DIR=$(find_runtime)
if [ -z "$RUNTIME_DIR" ]; then
    echo "Error: Topaz runtime not found!"
    echo "Please download and extract tak-runtime-v{version}.zip"
    echo "The runtime should be in the same directory or parent directory."
    exit 1
fi

# Flexible version check - extract base versions for comparison
REQUIRED_VERSION="{version}"
RUNTIME_VERSION=$(cat "$RUNTIME_DIR/VERSION" 2>/dev/null)

# Extract base version (remove -dev-* suffix if present)
REQUIRED_BASE=$(echo "$REQUIRED_VERSION" | sed 's/-dev-.*//')
RUNTIME_BASE=$(echo "$RUNTIME_VERSION" | sed 's/-dev-.*//')

# Check if base versions match
if [ "$RUNTIME_BASE" != "$REQUIRED_BASE" ]; then
    echo "Error: Runtime version mismatch"
    echo "  Required base version: $REQUIRED_BASE"
    echo "  Found base version: $RUNTIME_BASE"
    echo "  Full runtime version: $RUNTIME_VERSION"
    echo "Please download a runtime with base version $REQUIRED_BASE"
    exit 1
fi

# Warn if using dev version when expecting release (or vice versa)
if [ "$RUNTIME_VERSION" != "$REQUIRED_VERSION" ]; then
    echo "Warning: Version mismatch (but base versions match)"
    echo "  Required: $REQUIRED_VERSION"
    echo "  Found: $RUNTIME_VERSION"
    echo "  Continuing with available runtime..."
    echo ""
fi

# Use runtime's Python
PYTHON="$RUNTIME_DIR/venv/bin/python"
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Handle "all" mode - start all services
if [ "$SERVICE_MODE" = "all" ]; then
    echo "Starting all services..."
    echo "This will start FastAPI, MCP, and Services in separate terminals/processes"
    echo ""
    
    # Start FastAPI in background
    echo "Starting FastAPI..."
    "$PYTHON" -m topaz_agent_kit.cli.main serve fastapi --project "$PROJECT_DIR" &
    FASTAPI_PID=$!
    echo "FastAPI started (PID: $FASTAPI_PID)"
    
    # Start MCP in background
    echo "Starting MCP server..."
    "$PYTHON" -m topaz_agent_kit.cli.main serve mcp --project "$PROJECT_DIR" &
    MCP_PID=$!
    echo "MCP server started (PID: $MCP_PID)"
    
    # Start Services in background
    echo "Starting unified services..."
    "$PYTHON" -m topaz_agent_kit.cli.main serve services --project "$PROJECT_DIR" &
    SERVICES_PID=$!
    echo "Services started (PID: $SERVICES_PID)"
    
    echo ""
    echo "All services started!"
    echo "Press Ctrl+C to stop all services"
    
    # Wait for interrupt
    trap "kill $FASTAPI_PID $MCP_PID $SERVICES_PID 2>/dev/null; exit" INT TERM
    wait
    
    exit 0
fi

# Validate service mode
case "$SERVICE_MODE" in
    fastapi|mcp|services|cli)
        echo "Starting $SERVICE_MODE service..."
        "$PYTHON" -m topaz_agent_kit.cli.main serve "$SERVICE_MODE" --project "$PROJECT_DIR"
        ;;
    *)
        echo "Error: Unknown service mode: $SERVICE_MODE"
        echo "Usage: $0 [fastapi|mcp|services|cli|all]"
        echo "  fastapi  - Start web interface (default)"
        echo "  mcp      - Start MCP server"
        echo "  services - Start unified agent services"
        echo "  cli      - Start CLI interface"
        echo "  all      - Start all services (FastAPI, MCP, Services)"
        exit 1
        ;;
esac
"""


def create_launcher_script_bat(project_dir: Path, version: str) -> str:
    """Create Windows batch launcher script."""
    return f"""@echo off
REM Topaz Agent Kit Demo Launcher
REM Project: {project_dir.name}
REM Required Runtime Version: {version}

setlocal enabledelayedexpansion

REM Default service mode
set "SERVICE_MODE=%~1"
if "%SERVICE_MODE%"=="" set "SERVICE_MODE=fastapi"

REM Find runtime
set "RUNTIME_DIR="
for /d %%d in (tak-runtime-v*) do (
    if exist "%%d\\VERSION" (
        set "RUNTIME_DIR=%%d"
        goto :found_runtime
    )
)

REM Check parent directory
for /d %%d in (..\\tak-runtime-v*) do (
    if exist "%%d\\VERSION" (
        set "RUNTIME_DIR=%%d"
        goto :found_runtime
    )
)

:not_found
echo Error: Topaz runtime not found!
echo Please download and extract tak-runtime-v{version}.zip
echo The runtime should be in the same directory or parent directory.
pause
exit /b 1

:found_runtime
REM Flexible version check - extract base versions for comparison
set "REQUIRED_VERSION={version}"
set /p RUNTIME_VERSION=<"%RUNTIME_DIR%\\VERSION"

REM Extract base version (remove -dev-* suffix if present)
for /f "tokens=1 delims=-" %%a in ("%REQUIRED_VERSION%") do set "REQUIRED_BASE=%%a"
for /f "tokens=1 delims=-" %%a in ("%RUNTIME_VERSION%") do set "RUNTIME_BASE=%%a"

REM Check if base versions match
if not "%RUNTIME_BASE%"=="%REQUIRED_BASE%" (
    echo Error: Runtime version mismatch
    echo   Required base version: %REQUIRED_BASE%
    echo   Found base version: %RUNTIME_BASE%
    echo   Full runtime version: %RUNTIME_VERSION%
    echo Please download a runtime with base version %REQUIRED_BASE%
    pause
    exit /b 1
)

REM Warn if using dev version when expecting release (or vice versa)
if not "%RUNTIME_VERSION%"=="%REQUIRED_VERSION%" (
    echo Warning: Version mismatch ^(but base versions match^)
    echo   Required: %REQUIRED_VERSION%
    echo   Found: %RUNTIME_VERSION%
    echo   Continuing with available runtime...
    echo.
)

REM Use runtime's Python
set "PYTHON=%RUNTIME_DIR%\\venv\\Scripts\\python.exe"
set "PROJECT_DIR=%~dp0"

REM Handle "all" mode
if "%SERVICE_MODE%"=="all" (
    echo Starting all services...
    echo This will start FastAPI, MCP, and Services in separate windows
    echo.
    
    REM Start FastAPI in new window
    echo Starting FastAPI...
    start "Topaz FastAPI" "%PYTHON%" -m topaz_agent_kit.cli.main serve fastapi --project "%PROJECT_DIR%"
    
    REM Start MCP in new window
    echo Starting MCP server...
    start "Topaz MCP" "%PYTHON%" -m topaz_agent_kit.cli.main serve mcp --project "%PROJECT_DIR%"
    
    REM Start Services in new window
    echo Starting unified services...
    start "Topaz Services" "%PYTHON%" -m topaz_agent_kit.cli.main serve services --project "%PROJECT_DIR%"
    
    echo.
    echo All services started in separate windows!
    echo Close the windows to stop the services.
    pause
    exit /b 0
)

REM Validate service mode
if "%SERVICE_MODE%"=="fastapi" goto :run_fastapi
if "%SERVICE_MODE%"=="mcp" goto :run_mcp
if "%SERVICE_MODE%"=="services" goto :run_services
if "%SERVICE_MODE%"=="cli" goto :run_cli

echo Error: Unknown service mode: %SERVICE_MODE%
echo Usage: %~nx0 [fastapi^|mcp^|services^|cli^|all]
echo   fastapi  - Start web interface (default)
echo   mcp      - Start MCP server
echo   services - Start unified agent services
echo   cli      - Start CLI interface
echo   all      - Start all services (FastAPI, MCP, Services)
pause
exit /b 1

:run_fastapi
echo Starting FastAPI service...
"%PYTHON%" -m topaz_agent_kit.cli.main serve fastapi --project "%PROJECT_DIR%"
goto :end

:run_mcp
echo Starting MCP server...
"%PYTHON%" -m topaz_agent_kit.cli.main serve mcp --project "%PROJECT_DIR%"
goto :end

:run_services
echo Starting unified services...
"%PYTHON%" -m topaz_agent_kit.cli.main serve services --project "%PROJECT_DIR%"
goto :end

:run_cli
echo Starting CLI interface...
"%PYTHON%" -m topaz_agent_kit.cli.main serve cli --project "%PROJECT_DIR%"
goto :end

:end
"""


def should_exclude(path: Path, project_root: Path) -> bool:
    """Check if path should be excluded from export."""
    rel_path = path.relative_to(project_root)
    path_str = str(rel_path)
    path_name = path.name
    
    # Always include .env.example
    if path_name == ".env.example":
        return False
    
    # Exclude specific files (exact match)
    exclude_files = [
        "requirements.txt",
        ".env",  # Exclude actual .env (but .env.example is handled above)
    ]
    
    if path_name in exclude_files:
        return True
    
    # Exclude files/directories containing these names (handles gmail_token.json, client_secret.json, etc.)
    exclude_names = [
        "gmail_token",
        "client_secret",
    ]
    
    for name in exclude_names:
        if name in path_name or name in path_str:
            return True
    
    # Exclude patterns (directories and file extensions)
    # Match as directory names or file extensions, not substrings
    exclude_patterns = [
        ".git",
        "__pycache__",
        ".pyc",
        ".pyo",
        ".DS_Store",
        "*.egg-info",
        ".pytest_cache",
        ".mypy_cache",
        "node_modules",
        ".next",
        "dist",
        "build",
    ]
    
    # Split path into parts to check directory names, not substrings
    path_parts = path_str.split("/")
    
    for pattern in exclude_patterns:
        # Check if pattern matches any directory name in the path (exact match)
        for part in path_parts:
            if pattern == part:
                return True
            # Handle wildcard patterns like "*.egg-info"
            if pattern.startswith("*.") and part.endswith(pattern[1:]):
                return True
        # Check if filename matches pattern (for file extensions and hidden files)
        if path_name == pattern or path_name.endswith(pattern):
            return True
    
    return False


def create_readme(project_dir: Path, version: str) -> str:
    """Create README for demo."""
    project_name = project_dir.name
    return f"""# {project_name} Demo

This is a portable demo project for Topaz Agent Kit.

## Requirements

- Python 3.11+ installed on your system
- Topaz Agent Kit Runtime v{version}

## Quick Start

1. **Extract the runtime** (if not already done):
   ```bash
   unzip tak-runtime-v{version}.zip
   ```

2. **Extract this demo**:
   ```bash
   unzip {project_name}.zip
   cd {project_name}
   ```

3. **Run the demo**:
   
   **Mac/Linux:**
   ```bash
   ./run-demo.sh fastapi    # Start web interface (default)
   ./run-demo.sh mcp        # Start MCP server
   ./run-demo.sh services   # Start unified services
   ./run-demo.sh cli        # Start CLI interface
   ./run-demo.sh all        # Start all services
   ```
   
   **Windows:**
   ```cmd
   run-demo.bat fastapi     # Start web interface (default)
   run-demo.bat mcp         # Start MCP server
   run-demo.bat services    # Start unified agent services
   run-demo.bat cli         # Start CLI interface
   run-demo.bat all         # Start all services
   ```

4. **Access the web interface**:
   - Open your browser to: http://localhost:8090
   - (Port may vary - check the console output)

## Service Modes

- **fastapi** - Web interface with UI (default)
- **mcp** - Model Context Protocol server
- **services** - Unified agent services (A2A)
- **cli** - Command-line interface
- **all** - Start all services simultaneously

## Runtime Location

The launcher script will automatically find the runtime in:
1. Same directory as the project
2. Parent directory

Make sure `tak-runtime-v{version}/` is extracted in one of these locations.

## Configuration

- Copy `.env.example` to `.env` and configure your API keys if needed
- Demo data is pre-populated in the `data/` directory

## Troubleshooting

**Runtime not found:**
- Ensure `tak-runtime-v{version}/` is extracted
- Check it's in the same directory or parent directory

**Version mismatch:**
- Download the correct runtime version: `tak-runtime-v{version}.zip`

**Port already in use:**
- Check `config/pipelines.yml` for port configuration
- Stop other services using the same port
"""


def export_demo(
    project_dir: Path,
    output_path: Path,
    version: str,
    logger: Logger,
    no_zip: bool = False,
) -> None:
    """Export project as demo package."""
    project_dir = project_dir.resolve()
    output_path = output_path.resolve()
    
    logger.info(f"Exporting project: {project_dir}")
    logger.info(f"Output: {output_path}")
    logger.info(f"Required runtime version: {version}")
    
    # Create temporary directory for packaging
    temp_dir = output_path.parent / f".{project_dir.name}_temp"
    if temp_dir.exists():
        shutil.rmtree(temp_dir)
    temp_dir.mkdir(parents=True, exist_ok=True)
    
    try:
        # Copy project files
        logger.info("Copying project files...")
        copied_count = 0
        excluded_count = 0
        
        for root, dirs, files in os.walk(project_dir):
            # Filter out excluded directories
            dirs[:] = [d for d in dirs if not should_exclude(Path(root) / d, project_dir)]
            
            for file in files:
                src_path = Path(root) / file
                if should_exclude(src_path, project_dir):
                    excluded_count += 1
                    # Debug: log excluded files (only for first few to avoid spam)
                    if excluded_count <= 10:
                        logger.warning(f"Excluding: {src_path.relative_to(project_dir)}")
                    continue
                
                try:
                    rel_path = src_path.relative_to(project_dir)
                    dst_path = temp_dir / rel_path
                    dst_path.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src_path, dst_path)
                    copied_count += 1
                except Exception as e:
                    logger.warning(f"Failed to copy {src_path}: {e}")
                    excluded_count += 1
        
        logger.success(f"Copied {copied_count} files (excluded {excluded_count})")
        
        # Create launcher scripts
        logger.info("Creating launcher scripts...")
        launcher_sh = temp_dir / "run-demo.sh"
        with open(launcher_sh, "w") as f:
            f.write(create_launcher_script_sh(project_dir, version))
        launcher_sh.chmod(0o755)  # Make executable
        logger.success("Created run-demo.sh")
        
        launcher_bat = temp_dir / "run-demo.bat"
        with open(launcher_bat, "w") as f:
            f.write(create_launcher_script_bat(project_dir, version))
        logger.success("Created run-demo.bat")
        
        # Create README
        logger.info("Creating README...")
        readme = temp_dir / "README.md"
        with open(readme, "w") as f:
            f.write(create_readme(project_dir, version))
        logger.success("Created README.md")
        
        # Create zip file or keep directory
        if no_zip:
            # Move temp directory to final output location
            if output_path.exists():
                shutil.rmtree(output_path)
            shutil.move(temp_dir, output_path)
            logger.success(f"Demo exported to directory: {output_path}")
            logger.info("You can manually create a zip file if needed")
            # Don't clean up temp_dir since we moved it
            temp_dir = None  # Mark as moved so finally block doesn't try to delete it
        else:
            logger.info(f"Creating zip file: {output_path}")
            with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zipf:
                for root, dirs, files in os.walk(temp_dir):
                    for file in files:
                        file_path = Path(root) / file
                        arcname = file_path.relative_to(temp_dir)
                        zipf.write(file_path, arcname)
            
            logger.success(f"Demo exported to: {output_path}")
        
    finally:
        # Clean up temporary directory (only if it still exists)
        if temp_dir and temp_dir.exists():
            shutil.rmtree(temp_dir)
            logger.info("Cleaned up temporary files")


def main(
    project: str,
    output: Optional[str] = None,
    version: Optional[str] = None,
    no_zip: bool = False,
) -> None:
    """Export demo project."""
    logger = Logger("ExportDemo")
    logger.info("Starting demo export...")
    
    project_dir = Path(project).resolve()
    if not project_dir.exists():
        raise RuntimeError(f"Project directory not found: {project_dir}")
    
    project_name = project_dir.name
    
    # Detect version
    if version:
        runtime_version = version
        logger.info(f"Using provided version: {runtime_version}")
    else:
        # Try to detect from environment
        project_root = Path.cwd()
        if (project_root / "pyproject.toml").exists():
            runtime_version = get_runtime_version_from_environment(project_root, logger)
        else:
            runtime_version = "0.0.0"
            logger.warning("Could not detect version, using default")
    
    # Get current date for filename
    date_str = datetime.now().strftime("%Y%m%d")
    
    # Determine output path
    if no_zip:
        # When --no-zip, output is always a directory
        if output is None:
            # Default: current directory with auto-generated name (includes date)
            output_path = Path.cwd() / f"{project_name}-{date_str}"
            output_path = output_path.resolve()
        else:
            # Directory path
            output_dir = Path(output).resolve()
            # Create output directory if it doesn't exist
            output_dir.mkdir(parents=True, exist_ok=True)
            output_path = output_dir / f"{project_name}-{date_str}"
    else:
        # Normal zip file output
        if output is None:
            # Default: current directory with auto-generated name (includes date)
            output_path = Path.cwd() / f"{project_name}-{date_str}.zip"
            output_path = output_path.resolve()
            # Current directory always exists, no need to create
        elif output.endswith(".zip"):
            # Explicit zip file path
            output_path = Path(output).resolve()
            # Create parent directory if it doesn't exist
            output_path.parent.mkdir(parents=True, exist_ok=True)
        else:
            # Directory path - create zip file with auto-generated name (includes date)
            output_dir = Path(output).resolve()
            # Create output directory if it doesn't exist
            output_dir.mkdir(parents=True, exist_ok=True)
            output_path = output_dir / f"{project_name}-{date_str}.zip"
    
    # Export demo
    export_demo(project_dir, output_path, runtime_version, logger, no_zip=no_zip)
    
    logger.success("=" * 70)
    logger.success("Demo export completed successfully!")
    logger.success("=" * 70)
    logger.info(f"Output: {output_path}")
    logger.info(f"Required runtime version: {runtime_version}")
    logger.info("")
    if no_zip:
        logger.info("Next steps:")
        logger.info("  1. Create a zip file manually if needed: zip -r {}.zip {}".format(output_path.name, output_path.name))
        logger.info("  2. Share the directory or zip file with users")
        logger.info("  3. Users need the matching runtime: tak-runtime-v{}.zip".format(runtime_version))
        logger.info("  4. Users extract both and run: ./run-demo.sh")
    else:
        logger.info("Next steps:")
        logger.info("  1. Share this zip file with users")
        logger.info("  2. Users need the matching runtime: tak-runtime-v{}.zip".format(runtime_version))
        logger.info("  3. Users extract both and run: ./run-demo.sh")
