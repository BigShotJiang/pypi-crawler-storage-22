"""
Export Runtime Command

Creates a portable Python runtime with Topaz Agent Kit pre-installed.
This runtime can be shared and reused across multiple demo projects.
"""

import os
import shutil
import subprocess
import sys
import time
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Optional

from topaz_agent_kit.utils.logger import Logger


def get_version_from_pyproject(project_root: Path) -> str:
    """Extract version from pyproject.toml."""
    pyproject_path = project_root / "pyproject.toml"
    if not pyproject_path.exists():
        raise RuntimeError(f"pyproject.toml not found at {pyproject_path}")
    
    # Simple string parsing (works reliably)
    with open(pyproject_path, "r") as f:
        for line in f:
            if line.strip().startswith("version ="):
                version = line.split("=")[1].strip().strip('"').strip("'")
                return version
    
    raise RuntimeError("Version not found in pyproject.toml")


def get_git_hash(project_root: Path) -> Optional[str]:
    """Get short git commit hash if in a git repository."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=project_root,
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


def get_git_status(project_root: Path) -> bool:
    """Check if there are uncommitted changes."""
    try:
        result = subprocess.run(
            ["git", "diff", "--quiet"],
            cwd=project_root,
            capture_output=True,
        )
        return result.returncode != 0  # True if there are changes
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def determine_version(project_root: Path, dev: bool, custom_version: Optional[str]) -> str:
    """Determine runtime version."""
    if custom_version:
        return custom_version
    
    base_version = get_version_from_pyproject(project_root)
    
    if dev or get_git_status(project_root):
        # Dev build: append timestamp and git hash
        timestamp = datetime.now().strftime("%Y%m%d")
        git_hash = get_git_hash(project_root) or "unknown"
        return f"{base_version}-dev-{timestamp}-{git_hash}"
    
    return base_version


def find_wheel_file(project_root: Path) -> Path:
    """Find the most recent wheel file in dist/."""
    dist_dir = project_root / "dist"
    if not dist_dir.exists():
        raise RuntimeError(f"dist/ directory not found at {dist_dir}")
    
    wheel_files = list(dist_dir.glob("topaz_agent_kit-*.whl"))
    if not wheel_files:
        raise RuntimeError(f"No wheel files found in {dist_dir}. Please run 'python build.py' first.")
    
    # Get the most recent wheel file
    wheel_file = max(wheel_files, key=lambda p: p.stat().st_mtime)
    return wheel_file


def build_wheel_if_needed(project_root: Path, logger: Logger, skip_build: bool = False) -> Path:
    """Build wheel file if needed."""
    if skip_build:
        logger.info("Skipping build step (using existing wheel)...")
        wheel_file = find_wheel_file(project_root)
        logger.info(f"Using existing wheel: {wheel_file}")
        return wheel_file
    
    logger.info("Building package to ensure latest wheel is available...")
    
    try:
        # Run build.py
        result = subprocess.run(
            [sys.executable, "build.py"],
            cwd=project_root,
            capture_output=True,
            text=True,
            check=True,
        )
        logger.success("Package built successfully")
    except subprocess.CalledProcessError as e:
        logger.error("Failed to build package")
        if e.stderr:
            logger.error(e.stderr)
        if e.stdout:
            logger.error(e.stdout)
        raise RuntimeError("Package build failed")
    
    return find_wheel_file(project_root)


def is_pyenv_python(python_path: str) -> bool:
    """Check if Python path is pyenv-managed."""
    return ".pyenv" in python_path or "pyenv" in python_path.lower()


def check_python_version(python_path: str) -> Optional[tuple[int, int, int]]:
    """Check Python version and return (major, minor, patch) or None if invalid."""
    try:
        result = subprocess.run(
            [python_path, "--version"],
            capture_output=True,
            text=True,
            check=True,
        )
        # Parse version string like "Python 3.12.12"
        version_str = result.stdout.strip().split()[-1]
        parts = version_str.split(".")
        if len(parts) >= 2:
            major = int(parts[0])
            minor = int(parts[1])
            patch = int(parts[2]) if len(parts) > 2 else 0
            return (major, minor, patch)
    except (subprocess.CalledProcessError, ValueError, FileNotFoundError):
        pass
    return None


def find_system_python(logger: Logger) -> Optional[str]:
    """Find a system Python (not pyenv-managed) that's 3.11+."""
    # Common system Python locations
    candidates = []
    
    if sys.platform == "win32":
        # Windows common locations
        candidates = [
            r"C:\Python311\python.exe",
            r"C:\Python312\python.exe",
            r"C:\Python313\python.exe",
            r"C:\Program Files\Python311\python.exe",
            r"C:\Program Files\Python312\python.exe",
            r"C:\Program Files\Python313\python.exe",
            r"C:\Program Files (x86)\Python311\python.exe",
            r"C:\Program Files (x86)\Python312\python.exe",
            r"C:\Program Files (x86)\Python313\python.exe",
        ]
        # Also try to find via where command
        try:
            result = subprocess.run(
                ["where", "python"],
                capture_output=True,
                text=True,
                check=True,
            )
            for line in result.stdout.strip().split("\n"):
                if line.strip():
                    candidates.append(line.strip())
        except (subprocess.CalledProcessError, FileNotFoundError):
            pass
    else:
        # Unix-like systems (Linux, macOS)
        candidates = [
            "/usr/bin/python3",
            "/usr/bin/python3.11",
            "/usr/bin/python3.12",
            "/usr/bin/python3.13",
            "/usr/local/bin/python3",
            "/usr/local/bin/python3.11",
            "/usr/local/bin/python3.12",
            "/usr/local/bin/python3.13",
        ]
        # macOS Homebrew locations
        if sys.platform == "darwin":
            candidates.extend([
                "/opt/homebrew/bin/python3",
                "/opt/homebrew/bin/python3.11",
                "/opt/homebrew/bin/python3.12",
                "/opt/homebrew/bin/python3.13",
            ])
    
    # Check each candidate
    for python_path in candidates:
        if not os.path.exists(python_path):
            continue
        
        # Skip if pyenv-managed
        if is_pyenv_python(python_path):
            continue
        
        # Check version
        version = check_python_version(python_path)
        if version and version >= (3, 11, 0):
            logger.info(f"Found system Python {version[0]}.{version[1]}.{version[2]} at: {python_path}")
            return python_path
    
    return None


def update_pyvenv_cfg_for_portability(venv_dir: Path, system_python: str, logger: Logger) -> None:
    """Update pyvenv.cfg to use system Python paths that are more likely to exist on target systems.
    
    Note: Venvs are platform-specific. A venv created on macOS won't work on Linux.
    This function ensures pyvenv.cfg uses system paths (not pyenv) for better portability
    within the same platform.
    """
    pyvenv_cfg = venv_dir / "pyvenv.cfg"
    if not pyvenv_cfg.exists():
        logger.warning("pyvenv.cfg not found, skipping update")
        return
    
    logger.info("Updating pyvenv.cfg to use system Python paths for portability...")
    
    # Get the base directory of the system Python
    system_python_path = Path(system_python)
    if system_python_path.is_symlink():
        system_python_path = system_python_path.resolve()
    
    # Get base prefix (parent of bin directory)
    if sys.platform == "win32":
        # Windows: Scripts/python.exe -> Python312/
        base_prefix = system_python_path.parent.parent
    else:
        # Unix: bin/python3 -> Python312/ or /usr/
        base_prefix = system_python_path.parent.parent
    
    # Read current config
    lines = []
    with open(pyvenv_cfg, "r") as f:
        lines = f.readlines()
    
    # Update paths to use system Python base prefix
    updated_lines = []
    for line in lines:
        line = line.rstrip()
        if line.startswith("home = "):
            # Update home to use system Python base prefix
            updated_lines.append(f"home = {base_prefix}")
            logger.info(f"Updated 'home' to: {base_prefix}")
        elif line.startswith("executable = "):
            # Update executable to use system Python path
            updated_lines.append(f"executable = {system_python_path}")
            logger.info(f"Updated 'executable' to: {system_python_path}")
        elif line.startswith("command = "):
            # Keep command as-is (it's just metadata)
            updated_lines.append(line)
        else:
            # Keep other lines as-is
            updated_lines.append(line)
    
    # Write updated config
    with open(pyvenv_cfg, "w") as f:
        f.write("\n".join(updated_lines) + "\n")
    
    logger.success("Updated pyvenv.cfg with system Python paths")


def resolve_symlinks_in_venv(venv_dir: Path, logger: Logger) -> None:
    """Resolve symlinks in venv Python executable to make it portable."""
    if sys.platform == "win32":
        python_exe = venv_dir / "Scripts" / "python.exe"
        pythonw_exe = venv_dir / "Scripts" / "pythonw.exe"
    else:
        python_exe = venv_dir / "bin" / "python"
        pythonw_exe = None
    
    # Resolve Python executable symlink
    if python_exe.exists() and python_exe.is_symlink():
        target = python_exe.readlink()
        logger.info(f"Resolving symlink: {python_exe} -> {target}")
        
        # Resolve to actual file (follow chain of symlinks)
        real_path = python_exe.resolve()
        logger.info(f"Resolved to actual executable: {real_path}")
        
        # Copy actual executable to replace symlink
        shutil.copy2(real_path, python_exe)
        logger.success(f"Replaced symlink with actual executable")
    
    # Also handle pythonw.exe on Windows if it exists
    if pythonw_exe and pythonw_exe.exists() and pythonw_exe.is_symlink():
        target = pythonw_exe.readlink()
        logger.info(f"Resolving symlink: {pythonw_exe} -> {target}")
        real_path = pythonw_exe.resolve()
        logger.info(f"Resolved to actual executable: {real_path}")
        shutil.copy2(real_path, pythonw_exe)
        logger.success(f"Replaced symlink with actual executable")
    
    # Also check for python3 symlink (common on Unix)
    if sys.platform != "win32":
        python3_exe = venv_dir / "bin" / "python3"
        if python3_exe.exists() and python3_exe.is_symlink():
            target = python3_exe.readlink()
            logger.info(f"Resolving symlink: {python3_exe} -> {target}")
            real_path = python3_exe.resolve()
            logger.info(f"Resolved to actual executable: {real_path}")
            shutil.copy2(real_path, python3_exe)
            logger.success(f"Replaced symlink with actual executable")


def create_runtime(
    project_root: Path,
    output_path: Path,
    version: str,
    wheel_file: Path,
    logger: Logger,
    no_zip: bool = False,
) -> None:
    """Create portable runtime."""
    if no_zip:
        # When no_zip, output_path is already the directory path
        runtime_dir = output_path
    else:
        # When creating zip, create runtime in parent directory
        runtime_dir = output_path.parent / f"tak-runtime-v{version}"
    
    # Clean up if exists
    if runtime_dir.exists():
        logger.warning(f"Removing existing runtime directory: {runtime_dir}")
        shutil.rmtree(runtime_dir)
    
    runtime_dir.mkdir(parents=True, exist_ok=True)
    logger.info(f"Creating runtime at: {runtime_dir}")
    
    # Step 1: Find system Python (not pyenv-managed) for portable venv
    logger.info("Looking for system Python (not pyenv-managed)...")
    system_python = find_system_python(logger)
    
    if system_python:
        logger.success(f"Using system Python: {system_python}")
    else:
        logger.warning("Could not find system Python (non-pyenv), using current Python")
        logger.warning("Runtime may not be portable if current Python is pyenv-managed")
        system_python = sys.executable
    
    # Important note about platform-specificity
    logger.info("Note: Venvs are platform-specific. Runtime created on this platform will only work on the same platform.")
    logger.info(f"Current platform: {sys.platform}")
    if sys.platform == "darwin":
        logger.warning("Runtime created on macOS will NOT work on Linux/Windows. Create runtime on target platform.")
    
    # Step 2: Check if uv is available
    try:
        subprocess.run(
            ["uv", "--version"],
            check=True,
            capture_output=True,
        )
        use_uv = True
        logger.info("Using uv for faster package installation")
    except (subprocess.CalledProcessError, FileNotFoundError):
        logger.error("uv is not available. Please install uv: https://docs.astral.sh/uv/getting-started/installation/")
        raise RuntimeError("uv is required for export runtime. Install it with: curl -LsSf https://astral.sh/uv/install.sh | sh")
    
    # Step 3: Create virtual environment using uv with system Python
    venv_dir = runtime_dir / "venv"
    logger.info("Creating virtual environment with uv using system Python...")
    try:
        # Use --python flag to specify system Python for portability
        subprocess.run(
            ["uv", "venv", "--python", system_python, str(venv_dir)],
            check=True,
            capture_output=True,
        )
        logger.success("Virtual environment created")
        
        # Determine Python executable path
        if sys.platform == "win32":
            python_exe = venv_dir / "Scripts" / "python.exe"
        else:
            python_exe = venv_dir / "bin" / "python"
        
        # Step 3a: Resolve any symlinks in venv Python executable for portability
        logger.info("Resolving symlinks in venv Python executable for portability...")
        resolve_symlinks_in_venv(venv_dir, logger)
        
        # Step 3b: Update pyvenv.cfg to use system Python paths (not pyenv)
        logger.info("Updating pyvenv.cfg for portability...")
        update_pyvenv_cfg_for_portability(venv_dir, system_python, logger)
        
    except subprocess.CalledProcessError as e:
        logger.error("Failed to create virtual environment")
        if e.stderr:
            logger.error(e.stderr.decode() if isinstance(e.stderr, bytes) else e.stderr)
        raise RuntimeError("Virtual environment creation failed")
    
    # Step 4: Install wheel into venv using uv pip
    logger.info("Installing Topaz Agent Kit wheel using uv...")
    logger.info("This should be faster than pip...")
    
    try:
        # Install wheel with progress output using uv pip
        logger.info("Installing Topaz Agent Kit and dependencies...")
        logger.info("Installing: {}".format(wheel_file.name))
        
        # Use uv pip install with the venv's Python interpreter
        # This ensures packages are installed into the correct venv
        # --prerelease allow allows pre-release dependencies (needed for some packages like agent-framework)
        process = subprocess.Popen(
            ["uv", "pip", "install", "--python", str(python_exe), "--prerelease", "allow", str(wheel_file)],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        
        # Stream output line by line with progress
        last_package = None
        package_count = 0
        start_time = time.time()
        
        for line in process.stdout:
            line = line.rstrip()
            # Show progress for package installations
            if "Collecting" in line:
                # Extract package name from "Collecting <package>"
                parts = line.replace("Collecting ", "").split()
                if parts:
                    pkg_name = parts[0].split("==")[0].split("@")[0]  # Remove version and URL parts
                    if pkg_name != last_package and pkg_name and not pkg_name.isdigit():
                        package_count += 1
                        elapsed = int(time.time() - start_time)
                        logger.info("  [{:3d}] Installing: {} ({}s elapsed)".format(package_count, pkg_name, elapsed))
                        last_package = pkg_name
            elif "Resolved" in line and "package" in line.lower():
                # Extract package name from "Resolved X packages"
                parts = line.split()
                for i, part in enumerate(parts):
                    if part.lower() == "packages" and i > 0:
                        try:
                            num_packages = int(parts[i-1])
                            if num_packages > package_count:
                                package_count = num_packages
                        except ValueError:
                            pass
            elif "Successfully installed" in line or "Installed" in line:
                # Try to extract actual package count from the line
                parts = line.split()
                for part in parts:
                    if part.isdigit() and int(part) > package_count:
                        package_count = int(part)
                elapsed = int(time.time() - start_time)
                logger.success("  Installation complete! ({} packages in {}s)".format(package_count, elapsed))
            elif "Building wheel" in line or "Building" in line:
                # Show building progress
                logger.info("  Building packages...")
        
        # Wait for process to complete
        return_code = process.wait()
        if return_code != 0:
            # Try to get error output
            logger.error("uv pip install failed with return code: {}".format(return_code))
            raise subprocess.CalledProcessError(return_code, "uv pip install")
        
        elapsed = int(time.time() - start_time)
        logger.success("Topaz Agent Kit installed successfully ({} packages in {}s)".format(package_count, elapsed))
    except subprocess.CalledProcessError as e:
        logger.error("Failed to install wheel")
        if e.stderr:
            logger.error(e.stderr.decode() if isinstance(e.stderr, bytes) else e.stderr)
        raise RuntimeError("Wheel installation failed")
    
    # Step 5: Create VERSION file
    version_file = runtime_dir / "VERSION"
    with open(version_file, "w") as f:
        f.write(version)
    logger.success(f"Version file created: {version}")
    
    # Step 6: Create README
    readme_file = runtime_dir / "README.md"
    readme_content = f"""# Topaz Agent Kit Runtime v{version}

This is a portable Python runtime with Topaz Agent Kit pre-installed.

## Usage

This runtime is used by demo projects. Extract demo projects alongside this runtime directory.

## Structure

- `venv/` - Virtual environment with Topaz Agent Kit and all dependencies
- `VERSION` - Runtime version
- `README.md` - This file

## Requirements

- Python 3.11+ must be installed on the system
- The venv uses system Python, so Python must be available in PATH

## Version

Runtime Version: {version}
"""
    with open(readme_file, "w") as f:
        f.write(readme_content)
    logger.success("README created")
    
    # Step 7: Create zip file or keep directory
    if no_zip:
        # Runtime directory is already at output_path, no need to move
        logger.success(f"Runtime exported to directory: {output_path}")
        logger.info("You can manually create a zip file if needed")
        # Don't clean up runtime_dir since it's the final output
        runtime_dir = None  # Mark so cleanup doesn't try to delete it
    else:
        logger.info(f"Creating zip file: {output_path}")
        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(runtime_dir):
                # Skip __pycache__ and .pyc files
                dirs[:] = [d for d in dirs if d != "__pycache__"]
                for file in files:
                    if file.endswith(".pyc"):
                        continue
                    file_path = Path(root) / file
                    arcname = file_path.relative_to(runtime_dir.parent)
                    zipf.write(file_path, arcname)
        
        logger.success(f"Runtime exported to: {output_path}")
    
    # Clean up temporary directory
    # Use robust cleanup with retries to handle file locking issues (common with large packages like torch)
    logger.info("Cleaning up temporary files...")
    cleanup_success = False
    max_retries = 3
    retry_delay = 1.0
    
    # Only clean up if runtime_dir still exists (not moved in no_zip mode)
    if runtime_dir and runtime_dir.exists():
        for attempt in range(max_retries):
            try:
                # Small delay to ensure file handles are released
                if attempt > 0:
                    time.sleep(retry_delay * attempt)
                
                # Try to remove the directory
                shutil.rmtree(runtime_dir)
                cleanup_success = True
                logger.success("Cleanup complete")
                break
            except (OSError, PermissionError) as e:
                if attempt < max_retries - 1:
                    logger.warning(f"Cleanup attempt {attempt + 1} failed, retrying... ({e})")
                else:
                    # On final failure, log warning but don't fail the export
                    logger.warning(f"Could not fully clean up temporary directory: {runtime_dir}")
                    logger.warning(f"Error: {e}")
                    if no_zip:
                        logger.info("You can manually delete this directory if needed. The runtime directory was created successfully.")
                    else:
                        logger.info("You can manually delete this directory if needed. The zip file was created successfully.")
                    cleanup_success = False
        
        if not cleanup_success:
            logger.warning("Cleanup incomplete, but export succeeded. Temporary files remain.")


def main(
    output: Optional[str] = None,
    dev: bool = False,
    version: Optional[str] = None,
    skip_build: bool = False,
    no_zip: bool = False,
) -> None:
    """Export portable runtime."""
    logger = Logger("ExportRuntime")
    logger.info("Starting runtime export...")
    
    # Get project root (assume we're running from project root)
    project_root = Path.cwd()
    if not (project_root / "pyproject.toml").exists():
        # Try parent directory
        project_root = project_root.parent
        if not (project_root / "pyproject.toml").exists():
            raise RuntimeError("Could not find project root (pyproject.toml)")
    
    logger.info(f"Project root: {project_root}")
    
    # Determine version
    runtime_version = determine_version(project_root, dev, version)
    logger.info(f"Runtime version: {runtime_version}")
    
    # Build wheel if needed
    wheel_file = build_wheel_if_needed(project_root, logger, skip_build=skip_build)
    logger.info(f"Using wheel: {wheel_file}")
    
    # Check if version already contains a date (YYYYMMDD pattern)
    # Dev versions like "0.11.1-dev-20260209-abc123" already have date
    import re
    date_pattern = r'\d{8}'  # YYYYMMDD pattern
    version_has_date = bool(re.search(date_pattern, runtime_version))
    
    # Get current date for filename (only if version doesn't already have it)
    if version_has_date:
        # Version already has date, don't add it again
        filename_version = runtime_version
    else:
        # Release version, add date to filename
        date_str = datetime.now().strftime("%Y%m%d")
        filename_version = f"{runtime_version}-{date_str}"
    
    # Determine output path
    if no_zip:
        # When --no-zip, output is always a directory
        if output is None:
            # Default: current directory with auto-generated name
            output_path = Path.cwd() / f"tak-runtime-v{filename_version}"
            output_path = output_path.resolve()
        else:
            # Directory path
            output_dir = Path(output).resolve()
            # Create output directory if it doesn't exist
            output_dir.mkdir(parents=True, exist_ok=True)
            output_path = output_dir / f"tak-runtime-v{filename_version}"
    else:
        # Normal zip file output
        if output is None:
            # Default: current directory with auto-generated name
            output_path = Path.cwd() / f"tak-runtime-v{filename_version}.zip"
            output_path = output_path.resolve()
            # Current directory always exists, no need to create
        elif output.endswith(".zip"):
            # Explicit zip file path
            output_path = Path(output).resolve()
            # Create parent directory if it doesn't exist
            output_path.parent.mkdir(parents=True, exist_ok=True)
        else:
            # Directory path - create zip file with auto-generated name
            output_dir = Path(output).resolve()
            # Create output directory if it doesn't exist
            output_dir.mkdir(parents=True, exist_ok=True)
            output_path = output_dir / f"tak-runtime-v{filename_version}.zip"
    
    # Create runtime
    create_runtime(project_root, output_path, runtime_version, wheel_file, logger, no_zip=no_zip)
    
    logger.success("=" * 70)
    logger.success("Runtime export completed successfully!")
    logger.success("=" * 70)
    logger.info(f"Output: {output_path}")
    logger.info(f"Version: {runtime_version}")
    logger.info("")
    if no_zip:
        logger.info("Next steps:")
        logger.info("  1. Create a zip file manually if needed: zip -r {}.zip {}".format(output_path.name, output_path.name))
        logger.info("  2. Share the directory or zip file with users")
        logger.info("  3. Users extract it alongside their demo projects")
        logger.info("  4. Demo projects will automatically find and use this runtime")
    else:
        logger.info("Next steps:")
        logger.info("  1. Share this zip file with users")
        logger.info("  2. Users extract it alongside their demo projects")
        logger.info("  3. Demo projects will automatically find and use this runtime")
    logger.info("")
    logger.info(f"Runtime directory name: tak-runtime-v{version}")