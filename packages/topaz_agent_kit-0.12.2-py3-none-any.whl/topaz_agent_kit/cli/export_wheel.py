"""
Export Wheel Command

Exports the Topaz Agent Kit wheel file with installation instructions.
This is for tech-savvy users who prefer to manage their own Python environment.
"""

import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional

from topaz_agent_kit.utils.logger import Logger


def get_version_from_pyproject(project_root: Path) -> str:
    """Extract version from pyproject.toml."""
    pyproject_path = project_root / "pyproject.toml"
    if not pyproject_path.exists():
        raise RuntimeError(f"pyproject.toml not found at {pyproject_path}")
    
    # Simple string parsing (works reliably)
    with open(pyproject_path, "r") as f:
        for line in f:
            if line.strip().startswith("version ="):
                version = line.split("=")[1].strip().strip('"').strip("'")
                return version
    
    raise RuntimeError("Version not found in pyproject.toml")


def find_wheel_file(project_root: Path) -> Path:
    """Find the most recent wheel file in dist/."""
    dist_dir = project_root / "dist"
    if not dist_dir.exists():
        raise RuntimeError(f"dist/ directory not found at {dist_dir}")
    
    wheel_files = list(dist_dir.glob("topaz_agent_kit-*.whl"))
    if not wheel_files:
        raise RuntimeError(f"No wheel files found in {dist_dir}. Please run 'python build.py' first.")
    
    # Get the most recent wheel file
    wheel_file = max(wheel_files, key=lambda p: p.stat().st_mtime)
    return wheel_file


def build_wheel_if_needed(project_root: Path, logger: Logger, skip_build: bool = False) -> Path:
    """Build wheel file if needed."""
    if skip_build:
        logger.info("Skipping build step (using existing wheel)...")
        wheel_file = find_wheel_file(project_root)
        logger.info(f"Using existing wheel: {wheel_file.name}")
        return wheel_file
    
    # Always build if skip_build is False (ensures fresh build)
    logger.info("Building package to ensure latest wheel is available...")
    
    build_script = project_root / "build.py"
    if not build_script.exists():
        raise RuntimeError(f"build.py not found at {build_script}")
    
    try:
        result = subprocess.run(
            [sys.executable, str(build_script)],
            cwd=project_root,
            capture_output=True,
            text=True,
            check=True,
        )
        logger.success("Package built successfully")
    except subprocess.CalledProcessError as e:
        logger.error("Failed to build package")
        if e.stderr:
            logger.error(e.stderr)
        if e.stdout:
            logger.error(e.stdout)
        raise RuntimeError("Package build failed")
    
    return find_wheel_file(project_root)


def create_wheel_only_readme(wheel_filename: str, project_name: str, version: str) -> str:
    """Create README for wheel-only distribution."""
    return f"""# Topaz Agent Kit - Wheel Installation Guide

This package contains the Topaz Agent Kit wheel file and demo project for developers who prefer to manage their own Python environment.

## Contents

- `{wheel_filename}` - Topaz Agent Kit wheel file (~5-10MB)
- `{project_name}-*.zip` - Demo project package (~20-30MB)
- `INSTALL.md` - This installation guide

## Prerequisites

Before installing, ensure you have:

1. **Python 3.11+** installed and available in your PATH
   ```bash
   python --version  # Should show 3.11 or higher
   ```

2. **Package manager** (choose one):
   - **uv** (recommended - faster installation)
     ```bash
     # Install uv if you don't have it
     curl -LsSf https://astral.sh/uv/install.sh | sh  # Mac/Linux
     # OR
     powershell -c "irm https://astral.sh/uv/install.ps1 | iex"  # Windows
     ```
   - **pip** (standard Python package manager)

## Installation Steps

### Step 1: Extract Demo Project

```bash
unzip {project_name}-*.zip
cd {project_name}-*
```

### Step 2: Create Virtual Environment

**Using uv (recommended):**
```bash
uv venv
source venv/bin/activate  # Mac/Linux
# OR
venv\\Scripts\\activate   # Windows
```

**Using standard venv:**
```bash
python -m venv venv
source venv/bin/activate  # Mac/Linux
# OR
venv\\Scripts\\activate   # Windows
```

### Step 3: Install Topaz Agent Kit Wheel

**Using uv (recommended - faster, handles pre-releases):**
```bash
uv pip install --prerelease allow ../{wheel_filename}
```

**Using pip:**
```bash
pip install ../{wheel_filename}
```

**Note:** The `--prerelease allow` flag may be required for some dependencies that use pre-release versions (e.g., agent-framework/MAF).

### Step 4: Set Up Environment

```bash
# Copy example environment file
cp .env.example .env

# Edit .env with your API keys if needed
# (Demo data works without API keys if pre-populated)
```

### Step 5: Run the Demo

```bash
# Start web interface (default)
python -m topaz_agent_kit.cli.main serve fastapi --project .

# OR start other services
python -m topaz_agent_kit.cli.main serve mcp --project .
python -m topaz_agent_kit.cli.main serve services --project .
python -m topaz_agent_kit.cli.main serve cli --project .
```

### Step 6: Access Web Interface

Open your browser to: **http://localhost:8090**

(Port may vary - check the console output)

## Service Modes

- **fastapi** - Web interface with UI (default)
- **mcp** - Model Context Protocol server
- **services** - Unified agent services (A2A)
- **cli** - Command-line interface

## Troubleshooting

### Installation Issues

**Error: "No module named 'topaz_agent_kit'"**
- Ensure virtual environment is activated
- Verify wheel file was installed: `pip list | grep topaz-agent-kit`

**Error: "Pre-release version required"**
- Use `uv pip install --prerelease allow` instead of `pip install`
- Or upgrade pip: `pip install --upgrade pip`

**Error: "Python version not supported"**
- Ensure Python 3.11+ is installed
- Check version: `python --version`

### Runtime Issues

**Port already in use:**
- Check `config/pipelines.yml` for port configuration
- Stop other services using the same port
- Or change the port in config

**Module import errors:**
- Ensure virtual environment is activated
- Reinstall wheel: `pip install --force-reinstall ../{wheel_filename}`

## Benefits of Wheel-Only Distribution

✅ **Smaller download** - ~25-40MB total vs ~220-330MB runtime  
✅ **Use your own Python** - Manage dependencies yourself  
✅ **More control** - Easier to update Topaz Agent Kit  
✅ **Development friendly** - Better for customization and debugging  

## Version Information

- **Topaz Agent Kit Version:** {version}
- **Wheel File:** {wheel_filename}
- **Demo Project:** {project_name}

## Need Help?

For issues or questions:
1. Check the demo project's README.md
2. Review Topaz Agent Kit documentation
3. Check console output for error messages

## Alternative: Full Runtime Distribution

If you prefer a pre-configured environment, ask for the full runtime distribution which includes:
- Pre-installed Python virtual environment
- All dependencies pre-configured
- Simple launcher scripts

The full runtime is larger (~200-300MB) but requires no setup.
"""


def main(
    output: Optional[str] = None,
    skip_build: bool = False,
    version: Optional[str] = None,
    dev: bool = False,
) -> None:
    """
    Export wheel file with installation instructions.
    
    Args:
        output: Output directory (default: current directory)
        skip_build: Skip building wheel (use existing wheel from dist/)
        version: Custom version string (overrides auto-detection)
        dev: Create dev build (currently unused, kept for API consistency)
    """
    logger = Logger("ExportWheel")
    
    # Determine output directory
    if output:
        output_dir = Path(output)
        output_dir.mkdir(parents=True, exist_ok=True)
    else:
        output_dir = Path.cwd()
    
    # Find project root (where pyproject.toml is)
    project_root = Path.cwd()
    if not (project_root / "pyproject.toml").exists():
        project_root = project_root.parent
        if not (project_root / "pyproject.toml").exists():
            raise RuntimeError("Could not find project root (pyproject.toml)")
    
    logger.info("Exporting wheel file...")
    logger.info(f"Project root: {project_root}")
    logger.info(f"Output directory: {output_dir}")
    
    # Build or find wheel file
    logger.info("Step 1/2: Preparing wheel file...")
    wheel_file = build_wheel_if_needed(project_root, logger, skip_build=skip_build)
    
    # Copy wheel file to output directory
    wheel_dest = output_dir / wheel_file.name
    logger.info(f"Copying wheel file to: {wheel_dest}")
    shutil.copy2(wheel_file, wheel_dest)
    logger.success(f"Wheel file copied: {wheel_file.name}")
    
    # Get version for README
    try:
        if version:
            wheel_version = version
        else:
            wheel_version = get_version_from_pyproject(project_root)
    except Exception as e:
        logger.warning(f"Could not determine version: {e}")
        wheel_version = "0.0.0"
    
    # Create wheel-only README
    logger.info("Step 2/2: Creating installation README...")
    readme_content = create_wheel_only_readme(
        wheel_file.name,
        "demo-project",  # Generic name since we don't know project name here
        wheel_version
    )
    readme_path = output_dir / "INSTALL.md"
    with open(readme_path, "w") as f:
        f.write(readme_content)
    logger.success("Created INSTALL.md")
    
    logger.success("=" * 70)
    logger.success("Wheel export completed successfully!")
    logger.success("=" * 70)
    logger.info(f"Output directory: {output_dir}")
    logger.info("Created files:")
    logger.info(f"  • {wheel_file.name}")
    logger.info("  • INSTALL.md (installation instructions)")
    logger.info("")
    logger.info("For tech-savvy users: See INSTALL.md for installation instructions")
