"""
UI Dev Server Module

This module provides the UI dev server functionality for Next.js development.
"""

import os
import sys
import subprocess
from pathlib import Path

from topaz_agent_kit.utils.logger import Logger
from topaz_agent_kit.core.exceptions import ConfigurationError


def main(project_dir: str, log_level: str | None = None) -> None:
    """Start Next.js UI dev server with auto-detected FastAPI port."""
    logger = Logger("ServeUI")
    logger.info("Starting UI dev server")
    
    # Apply log level if specified
    if log_level:
        try:
            Logger.set_global_level_from_string(log_level)
            logger.info("Log level set to: {}", log_level)
        except Exception as e:
            logger.warning("Failed to set log level to {}: {}", log_level, e)
    
    logger.info("Using provided project directory: {}", project_dir)
    
    # Load server config (check common.yml first, then pipelines.yml for backward compatibility)
    # App-only mode: if pipelines.yml doesn't exist but apps.yml does, use common.yml only
    try:
        import yaml
        from urllib.parse import urlparse
        
        config = {}
        
        # Try common.yml first
        common_file = Path(project_dir) / "config" / "common.yml"
        if common_file.exists():
            with open(common_file, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f) or {}
            logger.debug("Loaded server config from common.yml")
        
        # Check if pipelines.yml exists
        pipeline_file = Path(project_dir) / "config" / "pipelines.yml"
        apps_file = Path(project_dir) / "config" / "apps.yml"
        
        if pipeline_file.exists():
            # Load pipelines.yml and merge (pipeline values override common)
            with open(pipeline_file, 'r', encoding='utf-8') as f:
                pipeline_config = yaml.safe_load(f) or {}
            
            # Deep merge: pipeline_config overrides config
            def merge_dicts(base, override):
                result = base.copy()
                for key, value in override.items():
                    if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                        result[key] = merge_dicts(result[key], value)
                    else:
                        result[key] = value
                return result
            
            config = merge_dicts(config, pipeline_config)
        elif apps_file.exists():
            # App-only mode: use common.yml config as-is
            logger.info("App-only mode: using common.yml for server config")
            if not config:
                raise ConfigurationError("App-only mode requires common.yml with server configuration")
        else:
            raise ConfigurationError(
                f"No configuration found. Expected either config/pipelines.yml or config/apps.yml in {project_dir}"
            )
        
        fastapi_url = config["servers"]["fastapi"]["url"]
        parsed_url = urlparse(fastapi_url)
        
        # Extract port from FastAPI URL
        server_host = parsed_url.hostname
        server_port = parsed_url.port
        
        # Validate required parameters
        if not server_host:
            raise ConfigurationError("FastAPI host must be specified in pipelines.yml")
        if not server_port:
            raise ConfigurationError("FastAPI port must be specified in pipelines.yml")
        
        # Determine API base URL for Next.js
        # Convert 0.0.0.0 to 127.0.0.1 for local development
        api_host = "127.0.0.1" if server_host == "0.0.0.0" else server_host
        api_base_url = f"http://{api_host}:{server_port}"
        
        logger.info("Detected FastAPI server on {}:{}", server_host, server_port)
        logger.info("Setting NEXT_PUBLIC_TOPAZ_API_BASE={}", api_base_url)
        
        # Find apps/ui directory
        # Strategy: Look for apps/ui directory by going up from project_dir or from current working directory
        project_path = Path(project_dir).resolve()
        cwd = Path.cwd().resolve()
        
        # Try multiple strategies to find apps/ui
        ui_dir = None
        search_paths = []
        
        # Strategy 1: Assume project is in workspace/projects/xxx, so apps/ui is at workspace/apps/ui
        # Go up 2 levels from project_dir to get workspace root
        workspace_from_project = project_path.parent.parent / "apps" / "ui"
        search_paths.append(workspace_from_project)
        if workspace_from_project.exists():
            ui_dir = workspace_from_project
        
        # Strategy 2: Try from current working directory (if running from workspace root)
        if not ui_dir:
            cwd_ui = cwd / "apps" / "ui"
            search_paths.append(cwd_ui)
            if cwd_ui.exists():
                ui_dir = cwd_ui
        
        # Strategy 3: Walk up from project_dir looking for apps/ui
        if not ui_dir:
            current = project_path
            for _ in range(5):  # Limit search depth
                current = current.parent
                potential_ui = current / "apps" / "ui"
                search_paths.append(potential_ui)
                if potential_ui.exists():
                    ui_dir = potential_ui
                    break
        
        # Strategy 4: Walk up from cwd looking for apps/ui
        if not ui_dir:
            current = cwd
            for _ in range(5):  # Limit search depth
                current = current.parent
                potential_ui = current / "apps" / "ui"
                if potential_ui not in search_paths:
                    search_paths.append(potential_ui)
                if potential_ui.exists():
                    ui_dir = potential_ui
                    break
        
        if not ui_dir:
            search_paths_str = "\n  - ".join(str(p) for p in search_paths[:10])  # Limit display
            raise ConfigurationError(
                f"Could not find apps/ui directory. Searched:\n  - {search_paths_str}\n"
                f"Please ensure apps/ui exists in the workspace."
            )
        
        ui_dir = ui_dir.resolve()
        logger.info("UI directory: {}", ui_dir)
        
        # Check if node_modules exists (npm install required)
        if not (ui_dir / "node_modules").exists():
            logger.warning("node_modules not found. Running npm install...")
            logger.info("Installing dependencies in {}", ui_dir)
            install_result = subprocess.run(
                ["npm", "install"],
                cwd=ui_dir,
                capture_output=False,
            )
            if install_result.returncode != 0:
                raise ConfigurationError("npm install failed. Please install dependencies manually.")
            logger.success("Dependencies installed successfully")
        
        # Set environment variable and run npm run dev
        env = os.environ.copy()
        env["NEXT_PUBLIC_TOPAZ_API_BASE"] = api_base_url
        
        logger.success("✅ Starting Next.js dev server")
        logger.info("  • UI: http://localhost:3000")
        logger.info("  • API: {}", api_base_url)
        logger.info("  • Project: {}", project_dir)
        logger.info("Press Ctrl+C to stop the server.")
        
        # Run npm run dev with the environment variable set
        try:
            subprocess.run(
                ["npm", "run", "dev"],
                cwd=ui_dir,
                env=env,
            )
        except KeyboardInterrupt:
            logger.info("UI dev server: Shutdown signal received, exiting gracefully...")
        except Exception as e:
            logger.error("Failed to start UI dev server: {}", e)
            raise ConfigurationError(f"Failed to start UI dev server: {e}")
        
    except Exception as e:
        logger.error("Failed to load FastAPI configuration: {}", e)
        raise ConfigurationError(f"Failed to load FastAPI configuration: {e}")


if __name__ == "__main__":  # pragma: no cover
    main()
