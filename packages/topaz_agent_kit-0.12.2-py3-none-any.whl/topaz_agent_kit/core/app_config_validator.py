"""
App Config Validator
Validates app manifest YAML configurations against JSON schema
"""

import json
import yaml
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple

try:
    import jsonschema
    from jsonschema import Draft202012Validator, ValidationError
    JSONSCHEMA_AVAILABLE = True
except ImportError:
    JSONSCHEMA_AVAILABLE = False

try:
    import pkg_resources
    PKG_RESOURCES_AVAILABLE = True
except ImportError:
    PKG_RESOURCES_AVAILABLE = False

from topaz_agent_kit.utils.logger import Logger
from topaz_agent_kit.core.env_substitution import substitute_env_vars


class AppConfigValidationError(Exception):
    """Exception raised when app config validation fails"""
    pass


class AppConfigValidator:
    """Validates app manifest YAML against JSON schema"""
    
    def __init__(self, project_dir: Optional[Path] = None):
        """
        Initialize app config validator
        
        Args:
            project_dir: Optional project directory for resolving relative paths
        """
        self.logger = Logger("AppConfigValidator")
        self.project_dir = project_dir or Path(".")
        self.schema = None
        self._load_schema()
    
    def _load_schema(self) -> None:
        """Load app manifest JSON schema"""
        if not JSONSCHEMA_AVAILABLE:
            self.logger.warning("jsonschema not available, validation will be skipped")
            return
        
        try:
            if PKG_RESOURCES_AVAILABLE:
                schema_res = pkg_resources.files("topaz_agent_kit.core.schemas") / "app_manifest.schema.json"
                schema_path = Path(str(schema_res))
            else:
                # Fallback: try relative path
                schema_path = Path(__file__).parent.parent / "core" / "schemas" / "app_manifest.schema.json"
            
            if schema_path.exists():
                with schema_path.open("r", encoding="utf-8") as f:
                    self.schema = json.load(f)
                self.logger.debug("Loaded app manifest schema from: {}", schema_path)
            else:
                self.logger.warning("App manifest schema not found at: {}", schema_path)
        except Exception as e:
            self.logger.warning("Failed to load app manifest schema: {}", e)
    
    def _load_yaml(self, path: Path) -> Dict[str, Any]:
        """Load YAML file with environment variable substitution"""
        try:
            with path.open("r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
            # Apply environment variable substitution
            return substitute_env_vars(data)
        except Exception as e:
            self.logger.error("Failed to load YAML from {}: {}", path, e)
            raise AppConfigValidationError(f"Failed to load YAML: {e}")
    
    def validate_manifest(self, manifest: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """
        Validate app manifest against JSON schema
        
        Args:
            manifest: App manifest dictionary
            
        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        if not self.schema:
            self.logger.warning("Schema not loaded, skipping validation")
            return True, []
        
        if not JSONSCHEMA_AVAILABLE:
            return True, []
        
        errors = []
        try:
            validator = Draft202012Validator(self.schema)
            for error in validator.iter_errors(manifest):
                error_path = ".".join(str(p) for p in error.path)
                error_msg = f"{error_path}: {error.message}" if error_path else error.message
                errors.append(error_msg)
                self.logger.debug("Validation error: {}", error_msg)
            
            if errors:
                self.logger.warning("App manifest validation found {} errors", len(errors))
                return False, errors
            else:
                self.logger.debug("App manifest validation passed")
                return True, []
                
        except Exception as e:
            error_msg = f"Schema validation failed: {e}"
            self.logger.error(error_msg)
            return False, [error_msg]
    
    def validate_file(self, manifest_path: Path) -> Tuple[bool, List[str]]:
        """
        Validate app manifest file
        
        Args:
            manifest_path: Path to app manifest YAML file
            
        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        try:
            manifest = self._load_yaml(manifest_path)
            return self.validate_manifest(manifest)
        except AppConfigValidationError:
            return False, [f"Failed to load manifest from {manifest_path}"]
        except Exception as e:
            return False, [f"Unexpected error validating {manifest_path}: {e}"]
    
    def validate_binding_paths(self, manifest: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """
        Validate that all binding paths reference valid state structure
        
        This is a semantic validation beyond schema validation.
        
        Args:
            manifest: App manifest dictionary
            
        Returns:
            Tuple of (is_valid, list_of_warnings)
        """
        warnings = []
        canvas = manifest.get("canvas", {})
        sections = canvas.get("sections", [])
        default_state = manifest.get("default_state", {})
        
        for section in sections:
            binding = section.get("binding", "")
            if not binding:
                continue
            
            # Check if binding path exists in default_state (if provided)
            if default_state:
                try:
                    self._check_path_exists(default_state, binding)
                except ValueError as e:
                    warnings.append(f"Section '{section.get('id')}': Binding '{binding}' - {e}")
        
        if warnings:
            self.logger.debug("Binding path validation found {} warnings", len(warnings))
            return False, warnings
        
        return True, []
    
    def _check_path_exists(self, state: Dict[str, Any], path: str) -> None:
        """
        Check if a binding path exists in state structure
        
        Supports both dot notation (items.0.name) and bracket notation (items[0].name)
        
        Args:
            state: State dictionary
            path: Binding path string
            
        Raises:
            ValueError: If path doesn't exist or is invalid
        """
        # Normalize path: convert items[0].name to items.0.name
        normalized_path = path.replace("[", ".").replace("]", "")
        keys = normalized_path.split(".")
        
        current = state
        for i, key in enumerate(keys):
            if isinstance(current, dict):
                if key not in current:
                    # Check if it's a numeric key (array index)
                    try:
                        idx = int(key)
                        if isinstance(current, list) and 0 <= idx < len(current):
                            current = current[idx]
                            continue
                    except (ValueError, TypeError):
                        pass
                    
                    # Path doesn't exist
                    path_so_far = ".".join(keys[:i])
                    raise ValueError(f"Path '{path_so_far}.{key}' does not exist in default_state")
                current = current[key]
            elif isinstance(current, list):
                try:
                    idx = int(key)
                    if 0 <= idx < len(current):
                        current = current[idx]
                    else:
                        raise ValueError(f"Array index {idx} out of bounds")
                except (ValueError, TypeError):
                    raise ValueError(f"Cannot access '{key}' on array at path '{'.'.join(keys[:i])}'")
            else:
                path_so_far = ".".join(keys[:i])
                raise ValueError(f"Cannot access '{key}' on non-object at path '{path_so_far}'")
