"""
Canvas Structure Validator

Validates canvas structure updates for agent/hybrid modes:
- Validates bindings against state schema
- Validates widget types against WidgetRegistry
- Validates section specifications
- Enforces structure limits
"""

from typing import Dict, List, Optional, Any, Tuple
from topaz_agent_kit.utils.logger import Logger
from topaz_agent_kit.core.widget_registry import WidgetRegistry


class CanvasStructureValidationError(Exception):
    """Raised when canvas structure validation fails"""
    pass


class CanvasStructureValidator:
    """Validates canvas structure updates"""
    
    def __init__(self):
        self.logger = Logger("CanvasStructureValidator")
    
    def validate_section(
        self,
        section_spec: Dict[str, Any],
        manifest: Dict[str, Any],
        session_state: Optional[Dict[str, Any]] = None,
    ) -> Tuple[bool, List[str]]:
        """
        Validate a canvas section specification.
        
        Args:
            section_spec: Section specification to validate
            manifest: App manifest (for state schema, default state)
            session_state: Current session state (optional, for binding validation)
            
        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        errors = []
        
        # Validate section ID
        section_id = section_spec.get("id")
        if not section_id:
            errors.append("Section must have an 'id' field")
        
        # Validate controls if present
        controls = section_spec.get("controls", [])
        for idx, control in enumerate(controls):
            control_errors = self._validate_control(
                control,
                manifest,
                session_state,
                section_id=section_id,
                control_index=idx
            )
            errors.extend(control_errors)
        
        # Validate sub-sections recursively
        sub_sections = section_spec.get("sections", [])
        for idx, sub_section in enumerate(sub_sections):
            sub_valid, sub_errors = self.validate_section(
                sub_section,
                manifest,
                session_state
            )
            if not sub_valid:
                errors.extend([f"Sub-section {idx}: {err}" for err in sub_errors])
        
        return len(errors) == 0, errors
    
    def _validate_control(
        self,
        control: Dict[str, Any],
        manifest: Dict[str, Any],
        session_state: Optional[Dict[str, Any]],
        section_id: Optional[str] = None,
        control_index: int = 0,
    ) -> List[str]:
        """
        Validate a control specification.
        
        Args:
            control: Control specification to validate
            manifest: App manifest
            session_state: Current session state
            section_id: Parent section ID (for error messages)
            control_index: Control index in section (for error messages)
            
        Returns:
            List of error messages
        """
        errors = []
        
        # Validate widget type
        widget_type = control.get("widget")
        if not widget_type:
            errors.append(
                f"Control at index {control_index} (section: {section_id}): "
                "Control must have a 'widget' field specifying the widget type "
                "(e.g., 'text', 'markdown_editor', 'select', 'divider'). "
                "Check that the widget field is not empty or missing."
            )
        else:
            # Validate widget type exists in registry
            if not WidgetRegistry.is_registered(widget_type):
                errors.append(
                    f"Control at index {control_index} (section: {section_id}): "
                    f"Unknown widget type '{widget_type}'. "
                    f"Available widgets: {', '.join(self._get_widget_list())}"
                )
        
        # Validate binding - required for most widgets, but some don't need bindings
        binding = control.get("binding")
        widget_type = control.get("widget", "")
        
        # Widgets that don't require bindings:
        # - Separator widgets (divider, spacer) - layout only
        # - Action widgets (download) - operates on entire canvas state
        # - Container widgets (accordion, tabs, section) - contain other controls, bindings on child controls
        widgets_without_bindings = ["divider", "spacer", "download", "accordion", "tabs", "section"]
        
        if not binding and widget_type not in widgets_without_bindings:
            errors.append(
                f"Control at index {control_index} (section: {section_id}): "
                f"Widget '{widget_type}' requires a 'binding' field to connect to canvas state. "
                f"Only separator widgets (divider, spacer), action widgets (download), and container widgets (accordion, tabs, section) can omit bindings."
            )
        elif binding:
            # Validate binding if present
            binding_valid, binding_errors = self.validate_binding(
                binding,
                manifest,
                session_state
            )
            if not binding_valid:
                errors.extend([
                    f"Control at index {control_index} (section: {section_id}): "
                    f"Binding '{binding}' - {err}"
                    for err in binding_errors
                ])
        
        # Validate widget-specific requirements
        if widget_type == "select" or widget_type == "multiselect" or widget_type == "checkbox_group" or widget_type == "radio":
            widget_props = control.get("widgetProps", {})
            options = widget_props.get("options")
            if not options or not isinstance(options, list) or len(options) == 0:
                errors.append(
                    f"Control at index {control_index} (section: {section_id}): "
                    f"Widget '{widget_type}' requires 'widgetProps.options' as a non-empty array of "
                    f"{{value: string, label: string}} objects. "
                    f"Example: {{'widgetProps': {{'options': [{{'value': 'tech', 'label': 'Tech'}}, {{'value': 'design', 'label': 'Design'}}]}}}}"
                )
            elif options:
                # Validate options format
                invalid_options = [
                    i for i, opt in enumerate(options)
                    if not isinstance(opt, dict) or "value" not in opt or "label" not in opt
                ]
                if invalid_options:
                    errors.append(
                        f"Control at index {control_index} (section: {section_id}): "
                        f"Widget '{widget_type}' options must be objects with 'value' and 'label' fields. "
                        f"Invalid options at indices: {invalid_options}"
                    )
        
        return errors
    
    def validate_binding(
        self,
        binding: str,
        manifest: Dict[str, Any],
        session_state: Optional[Dict[str, Any]] = None,
    ) -> Tuple[bool, List[str]]:
        """
        Validate a binding path against state schema or current state.
        
        Args:
            binding: Binding path (e.g., "analysis.sales_data")
            manifest: App manifest (for state_schema, default_state)
            session_state: Current session state (optional)
            
        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        errors = []
        
        if not binding:
            return True, []  # Empty binding is valid (no binding)
        
        state_schema = manifest.get("state_schema")
        default_state = manifest.get("default_state", {})
        
        # Strategy: If schema exists, validate against schema
        # Otherwise, check against default_state or current state
        if state_schema:
            # Validate against JSON Schema
            schema_valid, schema_errors = self._validate_binding_against_schema(
                binding,
                state_schema
            )
            if not schema_valid:
                errors.extend(schema_errors)
        elif default_state:
            # Check against default_state structure
            try:
                self._check_path_exists(default_state, binding)
            except ValueError as e:
                # Allow creation of new paths (don't error, just warn)
                # In agent mode, agents can create new state paths
                pass
        elif session_state:
            # Check against current state (allow creation)
            # In agent mode, agents can create new paths
            pass
        else:
            # No schema or state - allow any binding (maximum flexibility)
            pass
        
        return len(errors) == 0, errors
    
    def _validate_binding_against_schema(
        self,
        binding: str,
        state_schema: Dict[str, Any],
    ) -> Tuple[bool, List[str]]:
        """
        Validate binding path against JSON Schema.
        
        Args:
            binding: Binding path
            state_schema: JSON Schema for state
            
        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        errors = []
        
        # Normalize path
        normalized_path = binding.replace("[", ".").replace("]", "")
        path_parts = normalized_path.split(".")
        
        # Navigate schema
        current_schema = state_schema
        for i, part in enumerate(path_parts):
            if not isinstance(current_schema, dict):
                errors.append(
                    f"Binding '{binding}': Path '{'.'.join(path_parts[:i])}' "
                    "does not reference an object in state schema"
                )
                return False, errors
            
            # Check if part exists in schema
            if "properties" in current_schema:
                properties = current_schema["properties"]
                if part not in properties:
                    # Check if it's an array index
                    try:
                        idx = int(part)
                        if "items" in current_schema:
                            current_schema = current_schema["items"]
                            continue
                        else:
                            errors.append(
                                f"Binding '{binding}': Path '{'.'.join(path_parts[:i])}' "
                                "is not an array in state schema"
                            )
                            return False, errors
                    except ValueError:
                        # Not a number, check if property exists
                        errors.append(
                            f"Binding '{binding}': Property '{part}' does not exist "
                            f"in state schema at path '{'.'.join(path_parts[:i])}'"
                        )
                        return False, errors
                else:
                    current_schema = properties[part]
            elif "items" in current_schema:
                # Array schema
                try:
                    idx = int(part)
                    current_schema = current_schema["items"]
                except ValueError:
                    errors.append(
                        f"Binding '{binding}': Expected array index at "
                        f"'{'.'.join(path_parts[:i])}', got '{part}'"
                    )
                    return False, errors
            else:
                # Schema doesn't have properties or items
                # Allow creation (flexible schema)
                pass
        
        return len(errors) == 0, errors
    
    def _check_path_exists(
        self,
        state: Dict[str, Any],
        path: str,
    ) -> None:
        """
        Check if a binding path exists in state structure.
        
        Supports both dot notation (items.0.name) and bracket notation (items[0].name)
        
        Args:
            state: State dictionary
            path: Binding path string
            
        Raises:
            ValueError: If path doesn't exist or is invalid
        """
        # Normalize path: convert items[0].name to items.0.name
        normalized_path = path.replace("[", ".").replace("]", "")
        keys = normalized_path.split(".")
        
        current = state
        for i, key in enumerate(keys):
            if isinstance(current, dict):
                if key not in current:
                    # Check if it's a numeric key (array index)
                    try:
                        idx = int(key)
                        if isinstance(current, list) and 0 <= idx < len(current):
                            current = current[idx]
                            continue
                    except (ValueError, TypeError):
                        pass
                    
                    # Path doesn't exist
                    path_so_far = ".".join(keys[:i])
                    raise ValueError(f"Path '{path_so_far}.{key}' does not exist")
                current = current[key]
            elif isinstance(current, list):
                try:
                    idx = int(key)
                    if 0 <= idx < len(current):
                        current = current[idx]
                    else:
                        raise ValueError(f"Array index {idx} out of bounds")
                except (ValueError, TypeError):
                    raise ValueError(
                        f"Cannot access '{key}' on array at path '{'.'.join(keys[:i])}'"
                    )
            else:
                path_so_far = ".".join(keys[:i])
                raise ValueError(f"Cannot access '{key}' on non-object at path '{path_so_far}'")
    
    def validate_widget_type(
        self,
        widget_type: str,
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate that a widget type exists in the registry.
        
        Args:
            widget_type: Widget type identifier
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        if not widget_type:
            return False, "Widget type cannot be empty"
        
        if not WidgetRegistry.is_registered(widget_type):
            available = ", ".join(self._get_widget_list())
            return False, (
                f"Unknown widget type '{widget_type}'. "
                f"Available widgets: {available}"
            )
        
        return True, None
    
    def _get_widget_list(self) -> List[str]:
        """Get list of all registered widget types"""
        widgets = WidgetRegistry.list_widgets()
        return [w.widget_type for w in widgets]
    
    def validate_canvas_structure(
        self,
        structure: Dict[str, Any],
        manifest: Dict[str, Any],
        session_state: Optional[Dict[str, Any]] = None,
    ) -> Tuple[bool, List[str]]:
        """
        Validate entire canvas structure.
        
        Args:
            structure: Canvas structure with sections, order, metadata
            manifest: App manifest
            session_state: Current session state
            
        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        errors = []
        
        # Validate structure has required fields
        if "sections" not in structure:
            errors.append("Canvas structure must have 'sections' field")
        if "order" not in structure:
            errors.append("Canvas structure must have 'order' field")
        
        if errors:
            return False, errors
        
        sections = structure.get("sections", {})
        order = structure.get("order", [])
        
        # Validate all sections
        for section_id, section_spec in sections.items():
            section_valid, section_errors = self.validate_section(
                section_spec,
                manifest,
                session_state
            )
            if not section_valid:
                errors.extend([
                    f"Section '{section_id}': {err}"
                    for err in section_errors
                ])
        
        # Validate order references exist
        for order_item in order:
            item_id = order_item.get("id")
            if not item_id:
                errors.append("Order item missing 'id' field")
                continue
            
            # Check if section exists
            if item_id not in sections:
                errors.append(
                    f"Order references section '{item_id}' that doesn't exist in sections"
                )
        
        # Enforce structure limits (optional - can be configured)
        max_sections = manifest.get("canvas", {}).get("max_sections", 100)
        if len(sections) > max_sections:
            errors.append(
                f"Canvas structure exceeds maximum sections limit ({max_sections})"
            )
        
        return len(errors) == 0, errors
