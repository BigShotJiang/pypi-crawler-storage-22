"""
Case to App Transformer Module

Transforms case data from pipeline cases into app canvas state format.
Used when launching apps from Operations Center cases.

Uses config-driven transformation mapping defined in app config files.
"""

from pathlib import Path
from typing import Any, Dict, List, Optional
import yaml

from topaz_agent_kit.utils.logger import Logger
from topaz_agent_kit.utils.path_resolver import resolve_config_path


class CaseToAppTransformer:
    """
    Transforms case data structure to app canvas state format.
    
    Maps agent outputs from case_data to app canvas bindings using
    config-driven transformation rules defined in app config.
    """
    
    def __init__(self, project_dir: Optional[str] = None):
        """
        Initialize transformer.
        
        Args:
            project_dir: Project directory path (required for loading app configs)
        """
        self.logger = Logger("CaseToAppTransformer")
        self.project_dir = Path(project_dir) if project_dir else None
    
    def transform_case_to_app_state(
        self,
        case_data: Dict[str, Any],
        app_id: str,
        app_config: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Transform case data to app canvas state format.
        
        Args:
            case_data: Case data dictionary (from CaseManager.get_case())
            app_id: App identifier
            app_config: Optional app config dict (will load if not provided)
            
        Returns:
            App canvas state dictionary
        """
        # Load app config if not provided
        if app_config is None:
            app_config = self._load_app_config(app_id)
            if not app_config:
                self.logger.warning("App config not found for app_id: {}, returning empty state", app_id)
                return {}
        
        # Get transformation mapping from app config
        transformation_config = app_config.get("case_transformation")
        if not transformation_config:
            self.logger.warning(
                "No case_transformation config found for app_id: {}, returning default_state",
                app_id
            )
            # Return default_state if available, otherwise empty dict
            return app_config.get("default_state", {})
        
        # Get default state as base
        default_state = app_config.get("default_state", {})
        
        # Apply transformation
        # Note: case_data from CaseManager.get_case() has structure: {case_id, pipeline_id, status, case_data: {...}}
        # The case_data field contains the agent outputs
        agent_outputs = case_data.get("case_data", {})
        
        # Log for debugging
        case_data_keys = list(case_data.keys()) if isinstance(case_data, dict) else []
        agent_outputs_keys = list(agent_outputs.keys()) if isinstance(agent_outputs, dict) else []
        field_mappings_count = len(transformation_config.get("field_mappings", [])) if transformation_config else 0
        section_mappings_count = len(transformation_config.get("section_mappings", [])) if transformation_config else 0
        
        self.logger.info("Starting transformation - app_id: {}, case_data_keys: {}, has_case_data_field: {}, agent_outputs_keys: {}, field_mappings: {}, section_mappings: {}", 
                        app_id, case_data_keys, "case_data" in case_data if isinstance(case_data, dict) else False, 
                        agent_outputs_keys, field_mappings_count, section_mappings_count)
        
        # Log sample agent output keys/types
        if isinstance(agent_outputs, dict) and agent_outputs:
            sample_keys = list(agent_outputs.keys())[:5]
            sample_types = {k: type(v).__name__ for k, v in list(agent_outputs.items())[:5]}
            self.logger.info("Sample agent outputs - keys: {}, types: {}", sample_keys, sample_types)
            
            # Log structure of key agents for debugging
            for agent_key in ['aegis_invoice_extractor', 'aegis_translator', 'aegis_exception_detector', 'aegis_decision_router']:
                if agent_key in agent_outputs:
                    agent_data = agent_outputs[agent_key]
                    if isinstance(agent_data, dict):
                        agent_subkeys = list(agent_data.keys())[:10]  # First 10 keys
                        self.logger.info("Agent '{}' structure - type: {}, keys: {}", agent_key, type(agent_data).__name__, agent_subkeys)
                    else:
                        self.logger.info("Agent '{}' structure - type: {}, value: {}", agent_key, type(agent_data).__name__, str(agent_data)[:100])
                else:
                    self.logger.info("Agent '{}' NOT found in agent_outputs", agent_key)
        
        transformed_state = self._apply_transformation(
            agent_outputs=agent_outputs,
            transformation_config=transformation_config,
            default_state=default_state,
            case_data=case_data
        )
        
        self.logger.info("Transformed case data to app state for app_id: {}", app_id)
        self.logger.info("Transformation result - keys: {}, has_invoice_review: {}", 
                        list(transformed_state.keys()) if isinstance(transformed_state, dict) else [],
                        "invoice_review" in transformed_state if isinstance(transformed_state, dict) else False)
        
        # Log sample values to see if data is actually populated
        if isinstance(transformed_state, dict) and "invoice_review" in transformed_state:
            invoice_review = transformed_state.get("invoice_review", {})
            if isinstance(invoice_review, dict):
                invoice = invoice_review.get("invoice", {})
                self.logger.info("Sample invoice data - invoice_number: '{}', vendor_name: '{}', total_amount: '{}'",
                               invoice.get("invoice_number", ""),
                               invoice.get("vendor_name", ""),
                               invoice.get("total_amount", ""))
        return transformed_state
    
    def _load_app_config(self, app_id: str) -> Optional[Dict[str, Any]]:
        """
        Load app config from registry.
        
        Args:
            app_id: App identifier
            
        Returns:
            App config dict or None if not found
        """
        if not self.project_dir:
            self.logger.error("project_dir not set, cannot load app config")
            return None
        
        try:
            registry_path = self.project_dir / "config" / "apps.yml"
            if not registry_path.exists():
                # Fallback: try direct path
                default_path = resolve_config_path(None, "apps/{id}.yml", app_id)
                manifest_path = self.project_dir / "config" / default_path
                if manifest_path.exists():
                    with open(manifest_path, "r") as f:
                        return yaml.safe_load(f)
                return None
            
            with open(registry_path, "r") as f:
                registry = yaml.safe_load(f) or {}
            
            # Find app entry in registry
            for app_entry in registry.get("apps", []):
                if app_entry.get("id") == app_id:
                    config_file = app_entry.get("config_file")
                    resolved_config_file = resolve_config_path(config_file, "apps/{id}.yml", app_id)
                    
                    if not resolved_config_file:
                        return None
                    
                    manifest_path = self.project_dir / "config" / resolved_config_file
                    if manifest_path.exists():
                        with open(manifest_path, "r") as f:
                            return yaml.safe_load(f)
                    break
            
            return None
        except Exception as e:
            self.logger.error("Failed to load app config for {}: {}", app_id, e)
            return None
    
    def _apply_transformation(
        self,
        agent_outputs: Dict[str, Any],
        transformation_config: Dict[str, Any],
        default_state: Dict[str, Any],
        case_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Apply transformation mapping to create app state.
        
        Args:
            agent_outputs: Agent outputs from case_data
            transformation_config: Transformation mapping config
            default_state: Default state to use as base
            case_data: Full case data (for context)
            
        Returns:
            Transformed app state
        """
        # Start with deep copy of default state
        import copy
        app_state = copy.deepcopy(default_state)
        
        # Process field mappings
        field_mappings = transformation_config.get("field_mappings", [])
        for mapping in field_mappings:
            self._apply_field_mapping(mapping, agent_outputs, app_state, case_data)
        
        # Process section mappings (for nested structures)
        section_mappings = transformation_config.get("section_mappings", [])
        for mapping in section_mappings:
            self._apply_section_mapping(mapping, agent_outputs, app_state, case_data)
        
        return app_state
    
    def _apply_field_mapping(
        self,
        mapping: Dict[str, Any],
        agent_outputs: Dict[str, Any],
        app_state: Dict[str, Any],
        case_data: Dict[str, Any]
    ) -> None:
        """
        Apply a single field mapping.
        
        Mapping format:
        {
            "target_path": "invoice_review.invoice.invoice_number",
            "source_path": "aegis_translator.translated_data.invoice_data.invoice_number if aegis_translator else aegis_invoice_extractor.extracted_data.invoice_data.invoice_number",
            "default": "",
            "transform": "str"  # optional: str, int, float, etc.
        }
        """
        target_path = mapping.get("target_path")
        source_path = mapping.get("source_path")
        default_value = mapping.get("default")
        transform_type = mapping.get("transform")
        condition = mapping.get("condition")
        
        if not target_path:
            self.logger.warning("Field mapping missing target_path: {}", mapping)
            return
        
        # Evaluate condition if present
        if condition:
            if not self._evaluate_condition(condition, agent_outputs, case_data, app_state):
                return  # Skip this mapping if condition is false
        
        # Get source value
        if source_path:
            # Support expressions (simple if/else)
            value = self._evaluate_source_path(source_path, agent_outputs, case_data)
            # Log source path evaluation result (always log for debugging)
            # Special logging for decision_options to debug resolution actions
            if "decision_options" in target_path:
                self.logger.info("Decision options field mapping - target: {}, source: {}, value: {}, value_type: {}, agent_outputs_keys: {}", 
                               target_path, source_path, value if value is not None else "None",
                               type(value).__name__, list(agent_outputs.keys()) if isinstance(agent_outputs, dict) else [])
                if "aegis_decision_router" in agent_outputs:
                    router_data = agent_outputs.get("aegis_decision_router", {})
                    self.logger.info("Decision router data structure - keys: {}, has_parsed: {}, parsed_keys: {}", 
                                   list(router_data.keys()) if isinstance(router_data, dict) else [],
                                   "parsed" in router_data if isinstance(router_data, dict) else False,
                                   list(router_data.get("parsed", {}).keys()) if isinstance(router_data, dict) and isinstance(router_data.get("parsed"), dict) else [])
            else:
                self.logger.info("Applied field mapping - target: {}, source: {}, value: '{}', using_default: {}", 
                               target_path, source_path, value if value is not None else "None",
                               value is None or (isinstance(value, str) and value == ""))
        else:
            value = default_value
            self.logger.info("Applied field mapping - target: {}, source: None, using default: '{}'", 
                           target_path, default_value)
        
        # Apply transform if specified
        if transform_type and value is not None:
            value = self._apply_transform(value, transform_type)
        
        # Use default if value is None or empty string
        if value is None or (isinstance(value, str) and value == ""):
            value = default_value
        
        # Set value at target path (even if it's the default)
        if value is not None:
            self._set_value_at_path(app_state, target_path, value)
    
    def _apply_section_mapping(
        self,
        mapping: Dict[str, Any],
        agent_outputs: Dict[str, Any],
        app_state: Dict[str, Any],
        case_data: Dict[str, Any]
    ) -> None:
        """
        Apply a section mapping (for nested structures).
        
        Mapping format:
        {
            "target_path": "invoice_review.validation_results",
            "source_agent": "aegis_anomaly_validator",
            "fields": [
                {
                    "target": "anomaly.validation_passed",
                    "source": "validation_result.validation_passed",
                    "default": false
                }
            ],
            "condition": "invoice_type == 'LABOR'"  # optional
        }
        """
        target_path = mapping.get("target_path")
        source_agent = mapping.get("source_agent")
        fields = mapping.get("fields", [])
        condition = mapping.get("condition")
        
        if not target_path:
            self.logger.warning("Section mapping missing target_path: {}", mapping)
            return
        
        # Evaluate condition if present
        # Pass app_state so conditions can reference already-transformed data
        if condition:
            if not self._evaluate_condition(condition, agent_outputs, case_data, app_state):
                self.logger.info("Section mapping condition not met - skipping: {}", condition)
                return
        
        # Get source agent output
        source_data = agent_outputs.get(source_agent, {}) if source_agent else agent_outputs
        
        # Log section mapping attempt
        self.logger.info("Applying section mapping - target_path: {}, source_agent: {}, source_data_type: {}, source_data_keys: {}", 
                        target_path, source_agent, type(source_data).__name__, 
                        list(source_data.keys())[:10] if isinstance(source_data, dict) else [])
        
        # Apply field mappings within section
        for field_mapping in fields:
            target_field = field_mapping.get("target")
            source_field = field_mapping.get("source")
            default_value = field_mapping.get("default")
            
            if not target_field:
                continue
            
            # Get source value
            if source_field:
                value = self._get_nested_value(source_data, source_field, default_value)
                self.logger.info("Section field mapping - target: {}.{}, source: {}.{}, value: {}, using_default: {}", 
                               target_path, target_field, source_agent, source_field, value,
                               value == default_value or value is None)
            else:
                value = default_value
                self.logger.info("Section field mapping - target: {}.{}, using default: {}", 
                               target_path, target_field, default_value)
            
            # Set value at full target path
            full_target_path = f"{target_path}.{target_field}"
            if value is not None:
                self._set_value_at_path(app_state, full_target_path, value)
    
    def _evaluate_condition(
        self,
        condition: str,
        agent_outputs: Dict[str, Any],
        case_data: Dict[str, Any],
        app_state: Dict[str, Any] = None
    ) -> bool:
        """
        Evaluate a condition expression using the standard expression evaluator.
        
        Supports all expression types: comparisons, boolean logic, ternary, etc.
        Conditions can reference both source data (agent_outputs) and transformed app_state.
        """
        try:
            from topaz_agent_kit.utils.expression_evaluator import evaluate_expression
            
            # Build context similar to how base_agent does it
            context = {"upstream": agent_outputs}
            # Add agent outputs directly to context for easy access
            context.update({k: v for k, v in agent_outputs.items() if not k.startswith("_")})
            
            # Also add app_state to context so conditions can reference already-transformed data
            # This allows conditions like "invoice_review.invoice.invoice_type == 'MATERIAL'"
            if app_state:
                # Add app_state at root level for easy access
                # Users can reference paths like "invoice_review.invoice.invoice_type"
                for key, value in app_state.items():
                    if not key.startswith("_"):
                        context[key] = value
            
            # Use expression evaluator for consistent evaluation
            result = bool(evaluate_expression(condition, context))
            self.logger.info("Evaluated condition '{}' - result: {}", condition, result)
            return result
        except ValueError as e:
            # Expression evaluator couldn't parse it - log and default to True
            self.logger.warning("Failed to evaluate condition '{}': {}", condition, e)
            return True  # Default to true on error to avoid blocking transformations
        except Exception as e:
            self.logger.warning("Unexpected error evaluating condition '{}': {}", condition, e)
            return True  # Default to true on error
    
    def _evaluate_source_path(
        self,
        source_path: str,
        agent_outputs: Dict[str, Any],
        case_data: Dict[str, Any]
    ) -> Any:
        """
        Evaluate source path using the standard expression evaluator.
        
        Supports:
        - Simple paths: "aegis_invoice_extractor.extracted_data.invoice_data.invoice_number"
        - Ternary expressions: "aegis_translator.field if aegis_translator else aegis_extractor.field"
        - Complex expressions: Any expression supported by ExpressionEvaluator
        """
        try:
            from topaz_agent_kit.utils.expression_evaluator import evaluate_expression_value
            
            # Build context similar to how base_agent does it
            # The expression evaluator expects variables to be accessible directly or via dot notation
            context = {"upstream": agent_outputs}
            # Add agent outputs directly to context for easy access
            context.update({k: v for k, v in agent_outputs.items() if not k.startswith("_")})
            
            # Use expression evaluator to handle all expression types (ternary, comparisons, etc.)
            result = evaluate_expression_value(source_path, context)
            self.logger.info("Evaluated source path '{}' - result: {}", source_path, result)
            return result
        except ValueError as e:
            # Expression evaluator couldn't parse it - fall back to simple path lookup
            self.logger.debug("Expression evaluator couldn't parse '{}', falling back to simple path lookup: {}", source_path, e)
            return self._get_nested_value(agent_outputs, source_path)
        except Exception as e:
            self.logger.warning("Failed to evaluate source path '{}': {}", source_path, e)
            # Fall back to simple path lookup
            return self._get_nested_value(agent_outputs, source_path)
    
    def _apply_transform(self, value: Any, transform_type: str) -> Any:
        """Apply type transformation to value."""
        try:
            if transform_type == "str":
                return str(value) if value is not None else ""
            elif transform_type == "int":
                return int(value) if value is not None else 0
            elif transform_type == "float":
                return float(value) if value is not None else 0.0
            elif transform_type == "bool":
                return bool(value) if value is not None else False
            elif transform_type == "markdown_table":
                # Convert dict or list to markdown table (generic, no hardcoded structures)
                if isinstance(value, dict):
                    return self._dict_to_markdown_table(value)
                elif isinstance(value, list):
                    return self._list_to_markdown_table(value)
                else:
                    return str(value) if value is not None else ""
            elif transform_type == "file_list":
                # Convert single file path to list format for list_view widget
                if isinstance(value, str) and value:
                    return [{"file_path": value, "type": "Invoice"}]
                elif isinstance(value, list):
                    # Already a list, ensure it has the right format
                    return [
                        {"file_path": item.get("file_path") or item.get("path") or str(item), "type": item.get("type", "Document")}
                        if isinstance(item, dict) else {"file_path": str(item), "type": "Document"}
                        for item in value
                    ]
                else:
                    return []
            else:
                return value
        except (ValueError, TypeError) as e:
            self.logger.warning("Failed to transform value {} to {}: {}", value, transform_type, e)
            return value
    
    def _set_value_at_path(self, obj: Dict[str, Any], path: str, value: Any) -> None:
        """
        Set value at nested path in dictionary.
        
        Args:
            obj: Dictionary to modify
            path: Dot notation path (e.g., "a.b.c")
            value: Value to set
        """
        keys = path.split(".")
        current = obj
        
        # Navigate to parent of target
        for key in keys[:-1]:
            if key not in current:
                current[key] = {}
            current = current[key]
            if not isinstance(current, dict):
                # Path conflict - log warning
                self.logger.warning("Path conflict at '{}' in path '{}'", key, path)
                return
        
        # Set final value
        current[keys[-1]] = value
    
    def _get_nested_value(self, data: Dict[str, Any], path: str, default: Any = None) -> Any:
        """
        Get nested value from dictionary using dot notation path.
        
        Args:
            data: Dictionary to search
            path: Dot notation path (e.g., "a.b.c")
            default: Default value if path not found
            
        Returns:
            Value at path or default
        """
        keys = path.split(".")
        current = data
        
        for key in keys:
            if isinstance(current, dict):
                current = current.get(key)
                if current is None:
                    return default
            else:
                return default
        
        return current if current is not None else default
    
    def _dict_to_markdown_table(self, data: Dict[str, Any], exclude_keys: List[str] = None) -> str:
        """
        Convert a dictionary to a markdown table (generic, no hardcoded structures).
        
        Handles:
        - Simple key-value pairs: Field | Value table
        - Nested dicts: If all values are dicts, creates a multi-column table
        - Lists: Shows count or expands to nested table
        - Complex structures: Converts to JSON or nested tables as appropriate
        
        Args:
            data: Dictionary to convert
            exclude_keys: List of keys to exclude from the table
            
        Returns:
            Markdown table string
        """
        if not isinstance(data, dict) or not data:
            return ""
        
        exclude_keys = exclude_keys or []
        result_lines = []
        
        # Filter out excluded keys and None values
        filtered_items = [
            (k, v) for k, v in data.items()
            if k not in exclude_keys and v is not None
        ]
        
        if not filtered_items:
            return ""
        
        # Check if this is a dict-of-dicts structure (all values are dicts)
        # If so, create a multi-column table where each key becomes a row
        all_values_are_dicts = all(isinstance(v, dict) for _, v in filtered_items)
        
        if all_values_are_dicts and len(filtered_items) > 0:
            # Get all unique keys from nested dicts to create column headers
            all_nested_keys = set()
            for _, nested_dict in filtered_items:
                if isinstance(nested_dict, dict):
                    all_nested_keys.update(nested_dict.keys())
            
            if all_nested_keys:
                # Create table with parent key as first column, then nested keys as columns
                header_keys = sorted(all_nested_keys)
                # Use generic "Item" as first column header, or derive from context if available
                first_col_header = "Item"  # Generic header for parent keys
                header = "| " + " | ".join([first_col_header] + [k.replace('_', ' ').title() for k in header_keys]) + " |"
                separator = "| " + " | ".join(["---"] * (len(header_keys) + 1)) + " |"
                result_lines.append(header)
                result_lines.append(separator)
                
                # Add rows for each parent key
                for parent_key, nested_dict in filtered_items:
                    row_values = [parent_key.replace('_', ' ').title()]
                    for nested_key in header_keys:
                        nested_value = nested_dict.get(nested_key)
                        formatted_value = self._format_value_for_table(nested_value)
                        row_values.append(formatted_value)
                    result_lines.append("| " + " | ".join(row_values) + " |")
                
                return "\n".join(result_lines)
        
        # Default: Field | Value table for simple structures
        lines = ["| Field | Value |", "|-------|-------|"]
        
        for key, value in filtered_items:
            # Handle lists - show as nested table if list of dicts
            if isinstance(value, list):
                if len(value) == 0:
                    formatted_value = "*Empty*"
                elif isinstance(value[0], dict):
                    # List of dicts - show count and note, then nested table
                    formatted_value = f"*{len(value)} items - see details below*"
                    result_lines.extend(lines)
                    result_lines.append("")  # Empty line
                    result_lines.append(f"### {key.replace('_', ' ').title()}")
                    result_lines.append("")
                    # Generate table for list
                    list_table = self._list_to_markdown_table(value)
                    result_lines.append(list_table)
                    result_lines.append("")  # Empty line
                    lines = []  # Reset for remaining items
                    continue
                else:
                    formatted_value = ", ".join(str(v) for v in value)
            else:
                formatted_value = self._format_value_for_table(value)
            
            # Escape pipe characters in markdown
            formatted_value = formatted_value.replace("|", "\\|")
            # Truncate very long values
            if len(formatted_value) > 200:
                formatted_value = formatted_value[:197] + "..."
            
            lines.append(f"| {key.replace('_', ' ').title()} | {formatted_value} |")
        
        if lines:
            result_lines.extend(lines)
        
        return "\n".join(result_lines) if result_lines else ""
    
    def _format_value_for_table(self, value: Any) -> str:
        """
        Format a value for display in a markdown table cell (generic, no hardcoded structures).
        
        Args:
            value: Value to format
            
        Returns:
            Formatted string
        """
        if value is None:
            return "*None*"
        elif isinstance(value, bool):
            return "✓ Yes" if value else "✗ No"
        elif isinstance(value, dict):
            # For nested dicts, convert to JSON or show summary
            if len(value) == 0:
                return "*Empty*"
            elif len(value) <= 3:
                # Small dicts: show key-value pairs inline
                pairs = [f"{k}: {self._format_value_for_table(v)}" for k, v in value.items()]
                return ", ".join(pairs)
            else:
                # Large dicts: show count
                return f"*{len(value)} items*"
        elif isinstance(value, list):
            if len(value) == 0:
                return "*Empty*"
            else:
                return f"*{len(value)} items*"
        else:
            return str(value)
    
    def _list_to_markdown_table(self, data: List[Any], headers: List[str] = None) -> str:
        """
        Convert a list of dictionaries to a markdown table.
        
        Args:
            data: List of dictionaries to convert
            headers: Optional list of header names (if not provided, uses keys from first item)
            
        Returns:
            Markdown table string
        """
        if not isinstance(data, list) or not data:
            return ""
        
        # If first item is not a dict, convert to simple list
        if not isinstance(data[0], dict):
            lines = ["| Value |"]
            for item in data:
                lines.append(f"| {str(item)} |")
            return "\n".join(lines)
        
        # Get headers from first item if not provided
        if headers is None:
            headers = list(data[0].keys())
        
        if not headers:
            return ""
        
        # Build markdown table
        lines = [f"| {' | '.join(headers)} |"]
        lines.append(f"| {' | '.join(['---'] * len(headers))} |")
        
        for item in data:
            if not isinstance(item, dict):
                continue
            
            row = []
            for header in headers:
                value = item.get(header, "")
                # Format value
                if isinstance(value, (list, dict)):
                    import json
                    formatted_value = json.dumps(value, ensure_ascii=False)
                elif isinstance(value, bool):
                    formatted_value = "✓ Yes" if value else "✗ No"
                else:
                    formatted_value = str(value) if value is not None else ""
                
                # Escape pipe characters
                formatted_value = formatted_value.replace("|", "\\|")
                # Truncate very long values
                if len(formatted_value) > 100:
                    formatted_value = formatted_value[:97] + "..."
                
                row.append(formatted_value)
            
            lines.append(f"| {' | '.join(row)} |")
        
        return "\n".join(lines)
