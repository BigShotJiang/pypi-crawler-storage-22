"""
Grouping Aggregator Module

Aggregates field values from sub-cases to build top-level grouped case data.
Supports various aggregation strategies: first, last, list, sum, count, min, max, avg, most_severe.
"""

from typing import Any, Dict, List, Optional

from topaz_agent_kit.utils.logger import Logger


class GroupingAggregator:
    """
    Aggregates field values from sub-cases for top-level grouped case display.
    
    Supports multiple aggregation strategies for different field types.
    """
    
    # Status hierarchy for most_severe aggregation
    STATUS_HIERARCHY = {
        "failed": 4,
        "hitl_pending": 3,
        "processing": 2,
        "completed": 1,
    }
    
    def __init__(self):
        self.logger = Logger("GroupingAggregator")
    
    def aggregate_field(
        self,
        sub_cases: List[Dict[str, Any]],
        field_path: str,
        aggregation_strategy: str,
    ) -> Any:
        """
        Aggregate a field value from sub-cases using the specified strategy.
        
        Args:
            sub_cases: List of sub-case dictionaries (with case_data)
            field_path: Dot-notation path to field (e.g., "agent_id.field")
            aggregation_strategy: Strategy to use (first, last, list, sum, count, min, max, avg, most_severe)
            
        Returns:
            Aggregated value or None
        """
        if not sub_cases:
            return None

        # Special handling for status field (stored on case record, not in case_data)
        if field_path == "status":
            values = [sub_case.get("status") for sub_case in sub_cases if sub_case.get("status") is not None]
        else:
            # Extract values from all sub-cases
            values = []
            for sub_case in sub_cases:
                case_data = sub_case.get("case_data", {})
                value = self._extract_field_value(case_data, field_path)
                if value is not None:
                    values.append(value)
        
        if not values:
            return None
        
        # Apply aggregation strategy
        if aggregation_strategy == "first":
            return values[0]
        elif aggregation_strategy == "last":
            return values[-1]
        elif aggregation_strategy == "list":
            # Return unique values as list
            unique_values = []
            seen = set()
            for value in values:
                # Convert to hashable type for set comparison
                if isinstance(value, (dict, list)):
                    value_str = str(value)
                else:
                    value_str = value
                
                if value_str not in seen:
                    seen.add(value_str)
                    unique_values.append(value)
            return unique_values
        elif aggregation_strategy == "sum":
            numeric_values = [v for v in values if isinstance(v, (int, float))]
            return sum(numeric_values) if numeric_values else None
        elif aggregation_strategy == "count":
            return len(values)
        elif aggregation_strategy == "min":
            numeric_values = [v for v in values if isinstance(v, (int, float))]
            return min(numeric_values) if numeric_values else None
        elif aggregation_strategy == "max":
            numeric_values = [v for v in values if isinstance(v, (int, float))]
            return max(numeric_values) if numeric_values else None
        elif aggregation_strategy == "avg":
            numeric_values = [v for v in values if isinstance(v, (int, float))]
            if numeric_values:
                return sum(numeric_values) / len(numeric_values)
            return None
        elif aggregation_strategy == "most_severe":
            # For status-like fields, return most severe value
            return self._get_most_severe_value(values)
        else:
            self.logger.warning(
                "Unknown aggregation strategy: {}. Using 'first' as fallback.",
                aggregation_strategy
            )
            return values[0] if values else None
    
    def aggregate_status(
        self,
        sub_cases: List[Dict[str, Any]],
    ) -> str:
        """
        Aggregate status from sub-cases using most_severe strategy.
        
        Args:
            sub_cases: List of sub-case dictionaries
            
        Returns:
            Most severe status string
        """
        statuses = [case.get("status") for case in sub_cases if case.get("status")]
        if not statuses:
            return "processing"  # Default
        
        return self._get_most_severe_value(statuses)
    
    def build_top_level_case(
        self,
        grouping_key: str,
        sub_cases: List[Dict[str, Any]],
        grouped_view_config: Dict[str, Any],
        case_config: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Build virtual top-level case from sub-cases and grouped view config.
        
        Args:
            grouping_key: The grouping key
            sub_cases: List of sub-case dictionaries
            grouped_view_config: Grouped view configuration from views.grouped
            case_config: Full case configuration (for accessing centralized fields)
            
        Returns:
            Dictionary representing the top-level case
        """
        # Read from views.grouped structure
        # title is used for both display_id generation and modal header
        title_template = grouped_view_config.get("title", "{{grouping_key}}")
        
        # Build centralized fields registry
        fields_registry: Dict[str, Any] = {}
        if case_config:
            fields_raw = case_config.get("fields", {})
            if isinstance(fields_raw, list):
                for field_def in fields_raw:
                    if isinstance(field_def, dict):
                        key = field_def.get("key")
                        if key:
                            fields_registry[key] = field_def
            elif isinstance(fields_raw, dict):
                fields_registry = fields_raw
        
        # Build display_id from title template by resolving variables from centralized fields
        # Variables are resolved by aggregating values from sub-cases using the field's aggregation strategy
        import re
        display_id = title_template
        
        # Replace {{grouping_key}} first
        display_id = display_id.replace("{{grouping_key}}", grouping_key)
        
        # Find all remaining {{...}} placeholders and resolve from centralized fields
        pattern = r'\{\{([^}]+)\}\}'
        # Collect all matches first (before modifying display_id during iteration)
        matches = list(re.finditer(pattern, display_id))
        
        for match in matches:
            expr = match.group(1)  # The content inside {{ }}
            expr_stripped = expr.strip()
            original_pattern = match.group(0)  # The full {{...}} pattern including spaces
            
            # Skip if already replaced or is grouping_key
            if expr_stripped == "grouping_key":
                continue
            
            # Try to resolve as centralized field key
            if expr_stripped in fields_registry:
                field_config = fields_registry[expr_stripped]
                
                # Evaluate field-level condition if present
                # For grouped cases, check if ANY sub-case matches the condition
                # (e.g., co_version should only appear if at least one sub-case is a change_order)
                field_condition = field_config.get("condition")
                if field_condition:
                    from topaz_agent_kit.utils.expression_evaluator import evaluate_expression
                    
                    condition_met_by_any = False
                    for sub_case in sub_cases:
                        try:
                            case_data = sub_case.get("case_data", {})
                            # Build context for condition evaluation (same pattern as case_data_extractor)
                            condition_context: Dict[str, Any] = {"upstream": case_data}
                            for agent_id, agent_data in case_data.items():
                                if not agent_id.startswith("_"):
                                    if isinstance(agent_data, dict):
                                        parsed = agent_data.get("parsed", agent_data)
                                        condition_context[agent_id] = parsed if parsed else None
                                    else:
                                        condition_context[agent_id] = agent_data
                            
                            condition_result = evaluate_expression(field_condition, condition_context)
                            if condition_result:
                                condition_met_by_any = True
                                break  # At least one sub-case matches
                        except Exception as exc:
                            self.logger.debug(
                                "Condition evaluation failed for field '{}' on sub-case: {}",
                                expr_stripped,
                                exc
                            )
                            continue
                    
                    if not condition_met_by_any:
                        # Condition not met by any sub-case, replace with empty string
                        display_id = display_id.replace(original_pattern, "")
                        self.logger.debug(
                            "Field '{}' condition '{}' not met by any sub-case, replacing with empty",
                            expr_stripped,
                            field_condition
                        )
                        continue
                
                field_path = field_config.get("field") or field_config.get("source")
                aggregation = field_config.get("aggregation", "first")
                
                if field_path:
                    # Aggregate field value from sub-cases
                    aggregated_value = self.aggregate_field(
                        sub_cases=sub_cases,
                        field_path=field_path,
                        aggregation_strategy=aggregation,
                    )
                    
                    if aggregated_value is not None:
                        # Format the value according to field definition
                        replacement = str(aggregated_value)
                        # Apply value_mapping if available
                        if field_config.get("value_mapping") and isinstance(aggregated_value, str):
                            replacement = field_config["value_mapping"].get(aggregated_value, replacement)
                        # Apply text_transform if available
                        if field_config.get("text_transform"):
                            # Simple uppercase/lowercase for now
                            if field_config["text_transform"] == "uppercase":
                                replacement = replacement.upper()
                            elif field_config["text_transform"] == "lowercase":
                                replacement = replacement.lower()
                        
                        # Replace using the original pattern (preserves spaces if any)
                        display_id = display_id.replace(original_pattern, replacement)
                    else:
                        # Value not found, leave placeholder or replace with empty
                        display_id = display_id.replace(original_pattern, "")
                        self.logger.warning(
                            "Field '{}' path '{}' returned None from sub-cases. Replacing with empty string.",
                            expr_stripped,
                            field_path
                        )
                else:
                    # Field has no path, skip
                    display_id = display_id.replace(original_pattern, "")
                    self.logger.warning(
                        "Field '{}' has no field path. Replacing with empty string.",
                        expr_stripped
                    )
            else:
                # Not a centralized field, try to resolve as expression or leave as-is
                # For now, replace with empty string if not found
                self.logger.warning(
                    "Field '{}' not found in centralized fields registry. Available fields: {}. Replacing with empty string.",
                    expr_stripped,
                    list(fields_registry.keys())
                )
                display_id = display_id.replace(original_pattern, "")
        
        # Final generic fallback: if any {{...}} placeholders remain, replace them with grouping_key.
        # This avoids hardcoding label names in the base kit while ensuring title templates
        # still resolve to a meaningful identifier for grouped cases.
        if "{{" in display_id and grouping_key:
            while True:
                start = display_id.find("{{")
                if start == -1:
                    break
                end = display_id.find("}}", start + 2)
                if end == -1:
                    break
                display_id = display_id[:start] + grouping_key + display_id[end + 2:]
        
        # Aggregate status
        aggregated_status = self.aggregate_status(sub_cases)
        
        # Get earliest created_at and latest updated_at
        created_ats = [case.get("created_at") for case in sub_cases if case.get("created_at")]
        updated_ats = [case.get("updated_at") for case in sub_cases if case.get("updated_at")]
        
        top_level: Dict[str, Any] = {
            "grouping_key": grouping_key,
            "display_id": display_id,
            "status": aggregated_status,
            "sub_case_count": len(sub_cases),
            "sub_case_ids": [case.get("case_id") for case in sub_cases],
            # Removed summary object - sections will aggregate directly from centralized fields
            "created_at": min(created_ats) if created_ats else None,
            "updated_at": max(updated_ats) if updated_ats else None,
            "pipeline_id": sub_cases[0].get("pipeline_id") if sub_cases else None,
        }
        
        # Optional: UI configuration for grouped case detail modal
        # title and subtitle are now direct properties of views.grouped (not nested under modal)
        # title is already used for display_id above, so we use the same template for modal header
        resolved_modal: Dict[str, Any] = {}
        # Use title template for modal header (same as display_id)
        if title_template:
            resolved_modal["title"] = display_id  # Use the resolved display_id as modal title
        subtitle = grouped_view_config.get("subtitle")
        if isinstance(subtitle, str):
            resolved_modal["subtitle"] = subtitle
        if resolved_modal:
            top_level["_modal"] = resolved_modal

        # Extract tabs configuration (including custom tabs)
        # Tab order is in views.grouped.tabs.order
        # Tab-specific configs (label, title, sections) are in views.grouped.tabs_config[tab_id]
        tabs_order_config = grouped_view_config.get("tabs") or {}
        tabs_config_dict = grouped_view_config.get("tabs_config", {})
        
        if isinstance(tabs_order_config, dict) or isinstance(tabs_config_dict, dict):
            resolved_tabs: Dict[str, Any] = {}
            order = tabs_order_config.get("order") if isinstance(tabs_order_config, dict) else None
            if isinstance(order, list):
                resolved_tabs["order"] = [str(t) for t in order]
            
            # Extract labels and titles from tabs_config[tab_id] (new structure)
            # Also support backward compatibility with tabs.labels and tabs.titles
            labels: Dict[str, str] = {}
            titles: Dict[str, Any] = {}
            
            # New structure: read from tabs_config[tab_id].label and tabs_config[tab_id].title
            if isinstance(tabs_config_dict, dict):
                for tab_id, tab_config in tabs_config_dict.items():
                    if not isinstance(tab_config, dict):
                        continue
                    
                    # Extract label from tab config
                    tab_label = tab_config.get("label")
                    if tab_label:
                        labels[tab_id] = str(tab_label)
                    
                    # Extract title from tab config
                    tab_title = tab_config.get("title")
                    if tab_title:
                        if isinstance(tab_title, str):
                            # Simple string title
                            titles[tab_id] = {"text": str(tab_title)}
                        elif isinstance(tab_title, dict):
                            # Title with config (text, align, text_transform, font_size, bold, italic, underline, text_color, background_color, background_scope)
                            title_obj: Dict[str, Any] = {}
                            if "text" in tab_title:
                                title_obj["text"] = str(tab_title["text"])
                            if "align" in tab_title and tab_title["align"] in ["left", "center", "right"]:
                                title_obj["align"] = tab_title["align"]
                            if "text_transform" in tab_title:
                                title_obj["text_transform"] = tab_title["text_transform"]
                            if "font_size" in tab_title:
                                title_obj["font_size"] = tab_title["font_size"]
                            if "bold" in tab_title:
                                title_obj["bold"] = bool(tab_title["bold"])
                            if "italic" in tab_title:
                                title_obj["italic"] = bool(tab_title["italic"])
                            if "underline" in tab_title:
                                title_obj["underline"] = bool(tab_title["underline"])
                            if "text_color" in tab_title:
                                title_obj["text_color"] = str(tab_title["text_color"])
                            if "background_color" in tab_title:
                                title_obj["background_color"] = str(tab_title["background_color"])
                            if "background_scope" in tab_title and tab_title["background_scope"] in ["text", "row"]:
                                title_obj["background_scope"] = str(tab_title["background_scope"])
                            if title_obj:
                                titles[tab_id] = title_obj
            
            # Backward compatibility: also check tabs.labels and tabs.titles (old structure)
            if isinstance(tabs_order_config, dict):
                raw_labels = tabs_order_config.get("labels") or {}
                if isinstance(raw_labels, dict):
                    for tab_id, value in raw_labels.items():
                        if tab_id not in labels:  # Only use if not already set from tabs_config
                            labels[tab_id] = str(value)
                
                raw_titles = tabs_order_config.get("titles") or {}
                if isinstance(raw_titles, dict):
                    for tab_id, title_config in raw_titles.items():
                        if tab_id not in titles:  # Only use if not already set from tabs_config
                            if isinstance(title_config, str):
                                titles[tab_id] = {"text": str(title_config)}
                            elif isinstance(title_config, dict):
                                title_obj: Dict[str, Any] = {}
                                if "text" in title_config:
                                    title_obj["text"] = str(title_config["text"])
                                if "align" in title_config and title_config["align"] in ["left", "center", "right"]:
                                    title_obj["align"] = title_config["align"]
                                if "text_transform" in title_config:
                                    title_obj["text_transform"] = title_config["text_transform"]
                                if "font_size" in title_config:
                                    title_obj["font_size"] = title_config["font_size"]
                                if "bold" in title_config:
                                    title_obj["bold"] = bool(title_config["bold"])
                                if "italic" in title_config:
                                    title_obj["italic"] = bool(title_config["italic"])
                                if "underline" in title_config:
                                    title_obj["underline"] = bool(title_config["underline"])
                                if "text_color" in title_config:
                                    title_obj["text_color"] = str(title_config["text_color"])
                                if "background_color" in title_config:
                                    title_obj["background_color"] = str(title_config["background_color"])
                                if "background_scope" in title_config and title_config["background_scope"] in ["text", "row"]:
                                    title_obj["background_scope"] = str(title_config["background_scope"])
                                if title_obj:
                                    titles[tab_id] = title_obj
            
            if labels:
                resolved_tabs["labels"] = labels
            if titles:
                resolved_tabs["titles"] = titles
            
            # Extract custom tabs
            if isinstance(tabs_order_config, dict):
                custom_tabs = tabs_order_config.get("custom_tabs")
                if isinstance(custom_tabs, list):
                    resolved_tabs["custom_tabs"] = custom_tabs
            if resolved_tabs:
                top_level["_tabs"] = resolved_tabs

        return top_level
    
    def _extract_field_value(
        self,
        case_data: Dict[str, Any],
        field_path: str,
    ) -> Any:
        """
        Extract field value from case_data using dot notation.
        
        Handles agent outputs that may be wrapped in "parsed" or "result" keys.
        For paths like "agent_id.field", tries:
        1. case_data["agent_id"]["parsed"]["field"] (parsed wrapper - preferred)
        2. case_data["agent_id"]["field"] (direct access - fallback)
        
        Args:
            case_data: Case data dictionary
            field_path: Dot-notation path (e.g., "agent_id.field" or "status")
            
        Returns:
            Field value or None
        """
        if not field_path or not case_data:
            return None
        
        # Special case for "status" field (not in case_data, but in case record)
        if field_path == "status":
            # This should be handled at a higher level, but return None here
            return None
        
        parts = field_path.split(".")
        if len(parts) < 2:
            # Path must have at least agent_id.field format
            return None
        
        agent_id = parts[0]
        field_path_parts = parts[1:]
        
        # Get agent output from case_data
        agent_output = case_data.get(agent_id)
        if agent_output is None:
            return None
        
        # IMPORTANT: Try "parsed" wrapper FIRST, as it contains the normalized agent output
        # The "result" wrapper contains raw output and should only be used as fallback
        # This ensures we get the correct extracted value (e.g., covenant_document_classifier.contract_id from parsed.contract_id)
        # instead of trying to access it directly from the wrapper structure
        if isinstance(agent_output, dict) and "parsed" in agent_output:
            current = agent_output["parsed"]
            for part in field_path_parts:
                if isinstance(current, dict):
                    current = current.get(part)
                elif isinstance(current, list) and part.isdigit():
                    index = int(part)
                    if 0 <= index < len(current):
                        current = current[index]
                    else:
                        current = None
                else:
                    current = None
                
                if current is None:
                    break
            
            if current is not None:
                return current
        
        # If not found in parsed, try direct path (for backwards compatibility)
        current = agent_output
        for part in field_path_parts:
            if isinstance(current, dict):
                current = current.get(part)
            elif isinstance(current, list) and part.isdigit():
                index = int(part)
                if 0 <= index < len(current):
                    current = current[index]
                else:
                    current = None
            else:
                current = None
            
            if current is None:
                break
        
        return current
    
    def _get_most_severe_value(
        self,
        values: List[Any],
    ) -> Any:
        """
        Get most severe value from list based on status hierarchy.
        
        Args:
            values: List of status values
            
        Returns:
            Most severe value
        """
        if not values:
            return None
        
        # Convert all to strings for comparison
        str_values = [str(v).lower() for v in values]
        
        # Find value with highest hierarchy
        most_severe = None
        highest_priority = -1
        
        for value in str_values:
            priority = self.STATUS_HIERARCHY.get(value, 0)
            if priority > highest_priority:
                highest_priority = priority
                most_severe = value
        
        # Return original value (not lowercased string)
        if most_severe:
            # Find original value that matches
            for v in values:
                if str(v).lower() == most_severe:
                    return v
        
        # Fallback: return first value
        return values[0] if values else None
