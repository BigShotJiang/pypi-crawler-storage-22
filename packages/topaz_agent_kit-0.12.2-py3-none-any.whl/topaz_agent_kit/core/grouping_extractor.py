"""
Grouping Extractor Module

Extracts grouping keys from upstream context and evaluates exclusion rules
for subcase grouping functionality.
"""

import re
from typing import Any, Dict, Optional

from topaz_agent_kit.utils.expression_evaluator import evaluate_expression, evaluate_expression_value
from topaz_agent_kit.utils.logger import Logger


class GroupingExtractor:
    """
    Extracts grouping keys from upstream context and evaluates exclusion rules.
    
    Uses ExpressionEvaluator to extract grouping keys and evaluate exclusion
    expressions, same system as conditional nodes.
    """
    
    def __init__(self):
        self.logger = Logger("GroupingExtractor")
    
    def extract_grouping_key(
        self,
        upstream: Dict[str, Any],
        grouping_key_expression: str,
    ) -> Optional[str]:
        """
        Extract grouping key from upstream context using expression.
        
        Args:
            upstream: The upstream context containing all agent outputs
            grouping_key_expression: Expression to extract grouping key
                (e.g., "covenant_orchestrator.contract_id")
            
        Returns:
            Grouping key string or None if extraction fails
        """
        try:
            context = {"upstream": upstream}
            grouping_key = evaluate_expression_value(grouping_key_expression, context)
            
            if grouping_key is None:
                self.logger.debug(
                    "Grouping key expression '{}' evaluated to None",
                    grouping_key_expression
                )
                return None
            
            # Convert to string and sanitize
            grouping_key_str = str(grouping_key).strip()
            
            if not grouping_key_str:
                self.logger.debug(
                    "Grouping key expression '{}' evaluated to empty string",
                    grouping_key_expression
                )
                return None
            
            # Sanitize for use in case_id (uppercase, replace spaces/special chars)
            sanitized_key = self._sanitize_for_case_id(grouping_key_str)
            
            self.logger.debug(
                "Extracted grouping key: {} (from expression: {})",
                sanitized_key, grouping_key_expression
            )
            
            return sanitized_key
            
        except Exception as e:
            self.logger.warning(
                "Failed to extract grouping key from expression '{}': {}",
                grouping_key_expression, e
            )
            return None
    
    def should_exclude_case(
        self,
        upstream: Dict[str, Any],
        case_status: str,
        exclude_config: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """
        Check if a case should be excluded from grouping based on exclusion rules.
        
        Args:
            upstream: The upstream context containing all agent outputs
            case_status: Current case status
            exclude_config: Exclusion configuration with statuses and expressions
            
        Returns:
            True if case should be excluded, False otherwise
        """
        if not exclude_config:
            return False
        
        # Check status exclusion
        exclude_statuses = exclude_config.get("statuses", [])
        if case_status in exclude_statuses:
            self.logger.debug(
                "Case excluded by status: {} (excluded statuses: {})",
                case_status, exclude_statuses
            )
            return True
        
        # Check expression exclusions
        exclude_expressions = exclude_config.get("expressions", [])
        if exclude_expressions:
            context = {"upstream": upstream}
            
            for expr_config in exclude_expressions:
                expression = expr_config.get("expression")
                if not expression:
                    continue
                
                try:
                    if evaluate_expression(expression, context):
                        description = expr_config.get("description", "No description")
                        self.logger.debug(
                            "Case excluded by expression '{}': {}",
                            expression, description
                        )
                        return True
                except Exception as e:
                    self.logger.warning(
                        "Failed to evaluate exclusion expression '{}': {}",
                        expression, e
                    )
                    # Continue checking other expressions
        
        return False
    
    def _sanitize_for_case_id(self, value: str) -> str:
        """
        Sanitize grouping key for use in case_id.
        
        - Convert to uppercase
        - Replace spaces and special characters with hyphens
        - Remove consecutive hyphens
        - Remove leading/trailing hyphens
        
        Args:
            value: Raw grouping key value
            
        Returns:
            Sanitized grouping key
        """
        # Convert to uppercase
        sanitized = value.upper()
        
        # Replace spaces and special characters (except alphanumeric, hyphens, underscores)
        # with hyphens
        sanitized = re.sub(r'[^A-Z0-9_-]', '-', sanitized)
        
        # Replace underscores with hyphens for consistency
        sanitized = sanitized.replace('_', '-')
        
        # Remove consecutive hyphens
        sanitized = re.sub(r'-+', '-', sanitized)
        
        # Remove leading/trailing hyphens
        sanitized = sanitized.strip('-')
        
        return sanitized
