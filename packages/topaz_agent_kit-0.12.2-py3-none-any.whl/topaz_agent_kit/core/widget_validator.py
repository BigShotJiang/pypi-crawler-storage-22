"""
Widget Validation Framework
Extensible validation system for widget inputs supporting built-in and custom validators
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
from dataclasses import dataclass

from topaz_agent_kit.utils.logger import Logger


@dataclass
class ValidationResult:
    """Result of widget validation"""
    is_valid: bool
    errors: List[str]
    warnings: List[str] = None
    
    def __post_init__(self):
        if self.warnings is None:
            self.warnings = []


class WidgetValidator(ABC):
    """Base class for widget validators"""
    
    @abstractmethod
    def validate(self, value: Any, rules: Dict[str, Any], widget_type: str = None) -> ValidationResult:
        """
        Validate value against rules
        
        Args:
            value: Value to validate
            rules: Validation rules dictionary
            widget_type: Optional widget type for context
            
        Returns:
            ValidationResult with is_valid flag and error messages
        """
        pass


class RequiredValidator(WidgetValidator):
    """Validates required fields"""
    
    def validate(self, value: Any, rules: Dict[str, Any], widget_type: str = None) -> ValidationResult:
        """Check if required field has a value"""
        if rules.get("required", False):
            if value is None or value == "" or (isinstance(value, list) and len(value) == 0):
                return ValidationResult(
                    is_valid=False,
                    errors=["This field is required"]
                )
        return ValidationResult(is_valid=True, errors=[])


class PatternValidator(WidgetValidator):
    """Validates regex patterns"""
    
    def validate(self, value: Any, rules: Dict[str, Any], widget_type: str = None) -> ValidationResult:
        """Validate value against regex pattern"""
        pattern = rules.get("pattern")
        if not pattern:
            return ValidationResult(is_valid=True, errors=[])
        
        if value is None or value == "":
            # Empty values handled by RequiredValidator
            return ValidationResult(is_valid=True, errors=[])
        
        import re
        try:
            if not re.match(pattern, str(value)):
                return ValidationResult(
                    is_valid=False,
                    errors=[f"Value does not match required pattern"]
                )
        except re.error as e:
            return ValidationResult(
                is_valid=False,
                errors=[f"Invalid regex pattern: {e}"]
            )
        
        return ValidationResult(is_valid=True, errors=[])


class RangeValidator(WidgetValidator):
    """Validates min/max ranges for numbers and string lengths"""
    
    def validate(self, value: Any, rules: Dict[str, Any], widget_type: str = None) -> ValidationResult:
        """Validate value against min/max constraints"""
        errors = []
        
        if value is None or value == "":
            # Empty values handled by RequiredValidator
            return ValidationResult(is_valid=True, errors=[])
        
        # Check min constraint
        if "min" in rules:
            min_val = rules["min"]
            if isinstance(value, (int, float)):
                if value < min_val:
                    errors.append(f"Value must be at least {min_val}")
            elif isinstance(value, str):
                if len(value) < min_val:
                    errors.append(f"Value must be at least {min_val} characters")
            elif isinstance(value, list):
                if len(value) < min_val:
                    errors.append(f"Must have at least {min_val} items")
        
        # Check max constraint
        if "max" in rules:
            max_val = rules["max"]
            if isinstance(value, (int, float)):
                if value > max_val:
                    errors.append(f"Value must be at most {max_val}")
            elif isinstance(value, str):
                if len(value) > max_val:
                    errors.append(f"Value must be at most {max_val} characters")
            elif isinstance(value, list):
                if len(value) > max_val:
                    errors.append(f"Must have at most {max_val} items")
        
        return ValidationResult(is_valid=len(errors) == 0, errors=errors)


class TypeValidator(WidgetValidator):
    """Validates value types"""
    
    def validate(self, value: Any, rules: Dict[str, Any], widget_type: str = None) -> ValidationResult:
        """Validate value type matches widget type"""
        if value is None or value == "":
            return ValidationResult(is_valid=True, errors=[])
        
        # Type validation based on widget type
        if widget_type == "number":
            if not isinstance(value, (int, float)):
                try:
                    float(value)
                except (ValueError, TypeError):
                    return ValidationResult(
                        is_valid=False,
                        errors=["Value must be a number"]
                    )
        elif widget_type == "email":
            if "@" not in str(value):
                return ValidationResult(
                    is_valid=False,
                    errors=["Value must be a valid email address"]
                )
        elif widget_type == "url":
            value_str = str(value)
            if not (value_str.startswith("http://") or value_str.startswith("https://")):
                return ValidationResult(
                    is_valid=False,
                    errors=["Value must be a valid URL"]
                )
        
        return ValidationResult(is_valid=True, errors=[])


class WidgetValidationEngine:
    """Orchestrates widget validation"""
    
    def __init__(self):
        self.logger = Logger("WidgetValidationEngine")
        self.validators: Dict[str, WidgetValidator] = {
            "required": RequiredValidator(),
            "pattern": PatternValidator(),
            "min": RangeValidator(),
            "max": RangeValidator(),
            "type": TypeValidator(),
        }
    
    def register_validator(self, name: str, validator: WidgetValidator) -> None:
        """
        Register custom validator
        
        Args:
            name: Validator name (e.g., "custom_email")
            validator: Validator instance
        """
        self.validators[name] = validator
        self.logger.debug("Registered custom validator: {}", name)
    
    def validate_section(
        self,
        section: Dict[str, Any],
        value: Any,
        manifest: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        """
        Validate widget value against section validation rules
        
        Args:
            section: Canvas section configuration
            value: Value to validate
            manifest: Optional app manifest for context
            
        Returns:
            ValidationResult with is_valid flag and error messages
        """
        validation_rules = section.get("validation")
        if not validation_rules:
            return ValidationResult(is_valid=True, errors=[])
        
        widget_type = section.get("widget")
        all_errors = []
        all_warnings = []
        
        # Run all applicable validators
        for rule_name, validator in self.validators.items():
            if rule_name in validation_rules or rule_name == "required":
                # Create rules dict with this validator's rule
                validator_rules = {}
                if rule_name == "required":
                    validator_rules["required"] = validation_rules.get("required", False)
                elif rule_name == "pattern":
                    if "pattern" in validation_rules:
                        validator_rules["pattern"] = validation_rules["pattern"]
                elif rule_name in ["min", "max"]:
                    if rule_name in validation_rules:
                        validator_rules[rule_name] = validation_rules[rule_name]
                elif rule_name == "type":
                    # Type validation uses widget_type
                    validator_rules["widget_type"] = widget_type
                
                if validator_rules:
                    result = validator.validate(value, validator_rules, widget_type)
                    if not result.is_valid:
                        all_errors.extend(result.errors)
                    if result.warnings:
                        all_warnings.extend(result.warnings)
        
        # Check for custom validator
        if "custom" in validation_rules:
            custom_name = validation_rules["custom"]
            if custom_name in self.validators:
                custom_validator = self.validators[custom_name]
                result = custom_validator.validate(value, validation_rules, widget_type)
                if not result.is_valid:
                    all_errors.extend(result.errors)
                if result.warnings:
                    all_warnings.extend(result.warnings)
            else:
                all_warnings.append(f"Custom validator '{custom_name}' not found")
        
        return ValidationResult(
            is_valid=len(all_errors) == 0,
            errors=all_errors,
            warnings=all_warnings
        )
    
    def validate_state_against_schema(
        self,
        state: Dict[str, Any],
        state_schema: Dict[str, Any]
    ) -> ValidationResult:
        """
        Validate entire state against JSON Schema
        
        Args:
            state: State dictionary to validate
            state_schema: JSON Schema for validation
            
        Returns:
            ValidationResult
        """
        try:
            import jsonschema
            from jsonschema import Draft202012Validator
            
            validator = Draft202012Validator(state_schema)
            errors = []
            for error in validator.iter_errors(state):
                error_path = ".".join(str(p) for p in error.path)
                error_msg = f"{error_path}: {error.message}" if error_path else error.message
                errors.append(error_msg)
            
            return ValidationResult(
                is_valid=len(errors) == 0,
                errors=errors
            )
        except ImportError:
            return ValidationResult(
                is_valid=True,
                warnings=["jsonschema not available, schema validation skipped"]
            )
        except Exception as e:
            return ValidationResult(
                is_valid=False,
                errors=[f"Schema validation error: {e}"]
            )
