from typing import Protocol
from fastmcp import FastMCP

from topaz_agent_kit.utils.logger import Logger


class McpToolkit(Protocol):
    def register(self, server: FastMCP) -> None: ...


class McpServerApp:
    def __init__(self, name: str, host: str, port: int):
        self.server = FastMCP(name=name)
        self.host = host
        self.port = port
        self._logger = Logger("MCP.Framework")

    def register_toolkit(self, toolkit: McpToolkit) -> None:
        """
        Register a toolkit with the MCP server.
        
        If toolkit initialization or registration fails (e.g., missing API keys),
        logs a warning and continues without registering the toolkit.
        This allows the server to start even if some toolkits are unavailable.
        """
        toolkit_name = type(toolkit).__name__
        try:
            toolkit.register(self.server)
            self._logger.debug("Successfully registered toolkit: {}", toolkit_name)
        except (ValueError, RuntimeError, Exception) as e:
            # Catch initialization/configuration errors (ValueError, RuntimeError)
            # and any other unexpected errors during registration
            self._logger.warning(
                "Failed to register toolkit '{}': {}. Toolkit will not be available.",
                toolkit_name,
                str(e)
            )
            # Continue execution - don't raise, allow other toolkits to register

    def run(self, transport: str = "streamable-http") -> None:
        self.server.run(transport=transport, host=self.host, port=self.port)

