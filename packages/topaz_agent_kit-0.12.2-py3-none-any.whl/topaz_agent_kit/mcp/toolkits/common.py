import re
from topaz_agent_kit.utils.logger import Logger
from fastmcp import FastMCP
import os
import json
import urllib.parse
import urllib.request
import yaml
import pytesseract
from PIL import Image
import pdfplumber
from amadeus import Client, ResponseError
from dotenv import load_dotenv, find_dotenv
from datetime import datetime

class CommonMCPTools:
    def __init__(self, project_dir=None, **kwargs):
        self._logger = Logger("MCP.Common")
        self._project_dir = project_dir
    
    def _load_amadeus_client(self) -> Client:
        """Load Amadeus client configuration from environment variables"""

        # Load environment variables
        # Try project_dir first if provided, then fall back to find_dotenv()
        env_file = None
        if self._project_dir:
            from pathlib import Path
            project_env = Path(self._project_dir) / ".env"
            if project_env.exists():
                env_file = str(project_env)
                self._logger.debug(f"Loading environment from project directory: {env_file}")
                load_dotenv(env_file)
            else:
                self._logger.debug(f".env file not found at {project_env}, trying find_dotenv()")
        
        if not env_file:
            env_file = find_dotenv()
            if env_file:
                self._logger.debug(f"Loading environment from: {env_file}")
                load_dotenv(env_file)
            else:
                self._logger.debug("No .env file found")
                raise ValueError("No .env file found")

        client_id = os.getenv("AMADEUS_CLIENT_ID")
        client_secret = os.getenv("AMADEUS_CLIENT_SECRET")
        if not client_id or not client_secret:
            self._logger.error("Missing AMADEUS_CLIENT_ID/AMADEUS_CLIENT_SECRET env vars")
            raise RuntimeError("Missing AMADEUS_CLIENT_ID/AMADEUS_CLIENT_SECRET env vars")
        amadeus = Client(client_id=client_id, client_secret=client_secret)
        return amadeus

    def _log_response_error(self, tool_name: str, e: ResponseError) -> None:
        """Helper method to log detailed ResponseError information."""
        error_details = {
            "status_code": getattr(e, "status_code", None),
            "description": getattr(e, "description", None),
            "response": getattr(e, "response", None),
            "code": getattr(e, "code", None),
        }
        # Try to extract response body if available
        response_body = None
        try:
            if hasattr(e, "response") and e.response:
                response_body = getattr(e.response, "body", None)
        except Exception:
            pass
        
        self._logger.error("SDK {} failed: status={} code={} description={} response={} body={}", 
                          tool_name,
                          error_details.get("status_code"), 
                          error_details.get("code"),
                          error_details.get("description"),
                          error_details.get("response"),
                          response_body)

    def register(self, mcp: FastMCP) -> None:
        @mcp.tool(name="common_get_current_datetime")
        def get_current_datetime(timezone: str = "UTC", format: str = "iso") -> dict:
            """Get the current date and time.
            
            This tool provides accurate current date and time information. Use this when:
            - User asks "what date is today", "what's the current date", "what time is it"
            - User mentions relative dates like "yesterday", "today", "tomorrow" and you need to calculate actual dates
            - User provides dates like "6th feb 2026" and you need to verify or convert them
            - You need to calculate date differences or relative dates
            
            Args:
                timezone: Timezone name (default: "UTC"). Examples: "UTC", "America/New_York", "Europe/London"
                format: Output format (default: "iso"). Options: "iso" (ISO 8601), "readable" (human-readable)
            
            Returns:
                dict with:
                    - datetime_iso: ISO 8601 format (e.g., "2026-02-07T12:30:45")
                    - date: Date only (YYYY-MM-DD format)
                    - time: Time only (HH:MM:SS format)
                    - timestamp: Unix timestamp
                    - readable: Human-readable format (e.g., "February 7, 2026, 12:30:45 PM")
                    - timezone: The timezone used
                    - day_of_week: Day name (e.g., "Friday")
                    - day_of_year: Day of year (1-366)
            
            [roles: all]"""
            try:
                from datetime import timezone as dt_timezone
                import pytz
                
                # Get current UTC time
                now_utc = datetime.now(dt_timezone.utc)
                
                # Convert to requested timezone if specified
                if timezone and timezone != "UTC":
                    try:
                        tz = pytz.timezone(timezone)
                        now = now_utc.astimezone(tz)
                    except Exception as e:
                        self._logger.warning("Invalid timezone '{}', using UTC: {}", timezone, e)
                        now = now_utc
                        timezone = "UTC"
                else:
                    now = now_utc
                    timezone = "UTC"
                
                # Format based on requested format
                if format == "readable":
                    readable = now.strftime("%B %d, %Y, %I:%M:%S %p")
                else:
                    readable = now.strftime("%B %d, %Y, %I:%M:%S %p")
                
                result = {
                    "datetime_iso": now.strftime("%Y-%m-%dT%H:%M:%S"),
                    "date": now.strftime("%Y-%m-%d"),
                    "time": now.strftime("%H:%M:%S"),
                    "timestamp": int(now.timestamp()),
                    "readable": readable,
                    "timezone": timezone,
                    "day_of_week": now.strftime("%A"),
                    "day_of_year": now.timetuple().tm_yday,
                }
                
                self._logger.output("get_current_datetime OUTPUT: {}", result)
                return result
            except Exception as e:
                self._logger.error("get_current_datetime failed: {}", e)
                # Fallback to basic datetime
                now = datetime.now()
                return {
                    "datetime_iso": now.strftime("%Y-%m-%dT%H:%M:%S"),
                    "date": now.strftime("%Y-%m-%d"),
                    "time": now.strftime("%H:%M:%S"),
                    "timestamp": int(now.timestamp()),
                    "readable": now.strftime("%B %d, %Y, %I:%M:%S %p"),
                    "timezone": "local",
                    "day_of_week": now.strftime("%A"),
                    "day_of_year": now.timetuple().tm_yday,
                }

        @mcp.tool(name="common_get_current_location")
        def get_current_location() -> dict:
            """Get the current location based on IP address.
            
            This tool provides approximate location information based on the user's IP address.
            Use this when:
            - User asks "where am I", "what's my location", "where is this request coming from"
            - You need to determine user's timezone for date/time operations
            - User asks about their city, country, or region
            - You need location context for providing relevant information
            - You want to customize responses based on user's location (e.g., local time, regional preferences)
            
            Note: This uses IP-based geolocation which provides city/region-level accuracy,
            not precise street-level location. Accuracy may vary with VPNs or proxies.
            
            Returns:
                dict with:
                    - city: City name (e.g., "San Francisco")
                    - region: State/Province/Region (e.g., "California")
                    - country: Country name (e.g., "United States")
                    - country_code: ISO country code (e.g., "US")
                    - timezone: Timezone identifier (e.g., "America/Los_Angeles")
                    - latitude: Approximate latitude (float)
                    - longitude: Approximate longitude (float)
                    - ip: IP address used for geolocation (string)
                    - accuracy: "city" (indicates city-level accuracy)
            
            [roles: all]"""
            self._logger.input("get_current_location INPUT: (no parameters)")
            try:
                # Try to use httpx first (async), fallback to requests if not available
                try:
                    import httpx
                    use_httpx = True
                except ImportError:
                    import requests
                    use_httpx = False
                
                # Use ip-api.com free service (no API key required, rate limit: 45 requests/minute)
                # JSON endpoint: http://ip-api.com/json/
                api_url = "http://ip-api.com/json/"
                
                self._logger.info("Fetching location from IP geolocation service")
                
                if use_httpx:
                    # For sync context, use httpx in sync mode
                    with httpx.Client(timeout=5.0) as client:
                        response = client.get(api_url)
                        response.raise_for_status()
                        data = response.json()
                else:
                    response = requests.get(api_url, timeout=5)
                    response.raise_for_status()
                    data = response.json()
                
                # ip-api.com returns status field - check if successful
                if data.get("status") == "fail":
                    error_msg = data.get("message", "Unknown error")
                    self._logger.warning("IP geolocation failed: {}", error_msg)
                    result = {
                        "city": None,
                        "region": None,
                        "country": None,
                        "country_code": None,
                        "timezone": None,
                        "latitude": None,
                        "longitude": None,
                        "ip": None,
                        "accuracy": "unknown",
                        "error": error_msg,
                    }
                else:
                    # Extract relevant fields from ip-api.com response
                    result = {
                        "city": data.get("city"),
                        "region": data.get("regionName"),
                        "country": data.get("country"),
                        "country_code": data.get("countryCode"),
                        "timezone": data.get("timezone"),
                        "latitude": data.get("lat"),
                        "longitude": data.get("lon"),
                        "ip": data.get("query"),
                        "accuracy": "city",  # IP geolocation is city-level
                    }
                
                self._logger.output("get_current_location OUTPUT: city={}, country={}, timezone={}", 
                                 result.get("city"), result.get("country"), result.get("timezone"))
                return result
                    
            except Exception as e:
                self._logger.error("get_current_location failed: {}", e)
                # Return error result
                result = {
                    "city": None,
                    "region": None,
                    "country": None,
                    "country_code": None,
                    "timezone": None,
                    "latitude": None,
                    "longitude": None,
                    "ip": None,
                    "accuracy": "unknown",
                    "error": str(e),
                }
                return result

        @mcp.tool(name="common_ocr_reader")
        def ocr_reader(file_path: str) -> str:
            """Extract text from PDF or Image file using OCR.
            
            IMPORTANT: This tool only works with real filesystem paths.
            Supports both relative paths (relative to project_dir) and absolute paths.
            For AgentOS memory paths (e.g., /global/..., /shared/..., /memory/...), use agentos_shell instead.
            
            [roles: intake, parser]"""
            from topaz_agent_kit.utils.path_resolver import resolve_to_absolute
            from pathlib import Path
            
            self._logger.input("ocr_reader INPUT: file_path={}", file_path)
            try:
                # Resolve relative paths using project_dir if available
                if self._project_dir:
                    resolved_path = resolve_to_absolute(file_path, Path(self._project_dir))
                    file_path = str(resolved_path)
                
                if file_path.lower().endswith(".pdf"):
                    text = ""
                    with pdfplumber.open(file_path) as pdf:
                        for page in pdf.pages:
                            text += page.extract_text() + "\n"
                    self._logger.output("ocr_reader OUTPUT: {}", text.strip())
                    return text.strip()
                else:
                    image = Image.open(file_path)
                    text = pytesseract.image_to_string(image)
                    result = text.strip()
                    self._logger.output("ocr_reader OUTPUT: {}", result)
                    return result
            except Exception as e:
                self._logger.error("ocr_reader failed: {}", e)
                return ""

        @mcp.tool(name="common_form_parser")
        def form_parser(text: str) -> dict:
            """Extract structured claim fields from raw text. [roles: intake, parser]"""
            self._logger.debug("form_parser INPUT: text_len={}", len(text or ""))
            # Simple regex-based extraction as example
            policy_number_match = re.search(r"Policy\s*Number[:\s]*([A-Z0-9]+)", text, re.I)
            incident_date_match = re.search(r"Date\s*of\s*Incident[:\s]*(\d{4}-\d{2}-\d{2})", text, re.I)
            amount_match = re.search(r"Amount\s*Requested[:\s]*\$?([\d,]+\.?\d*)", text, re.I)
            result = {
                "policyholder_name": "John Doe",  # Could improve with NER
                "policy_number": policy_number_match.group(1) if policy_number_match else "",
                "incident_date": incident_date_match.group(1) if incident_date_match else "",
                "claim_type": "Auto",  # placeholder
                "amount_requested": float(amount_match.group(1).replace(",", "")) if amount_match else 0.0,
                "description": text[:200]  # first 200 chars as summary
            }
            self._logger.output("form_parser OUTPUT: {}", result)
            return result

        @mcp.tool(name="common_entity_normalizer")
        def entity_normalizer(entity_type: str, value: str) -> str:
            """Normalize names, dates, addresses, etc. [roles: intake, cleaner]"""
            self._logger.input("entity_normalizer INPUT: entity_type={}, value={}", entity_type, value)
            if entity_type.lower() == "date":
                # Simple YYYY-MM-DD check
                if re.match(r"\d{4}-\d{2}-\d{2}", value):
                    self._logger.output("entity_normalizer OUTPUT: {}", value)
                    return value
                self._logger.output("entity_normalizer OUTPUT: 1970-01-01")
                return "1970-01-01"
            self._logger.output("entity_normalizer OUTPUT: {}", value.strip().title())
            return value.strip().title()

        @mcp.tool(name="common_read_image")
        def read_image(file_path: str) -> dict:
            """Read image file and return data with metadata.
            
            Supports both relative paths (relative to project_dir) and absolute paths.
            [roles: intake, parser]"""
            from topaz_agent_kit.utils.file_utils import FileUtils
            from topaz_agent_kit.utils.path_resolver import resolve_to_absolute
            from pathlib import Path
            
            self._logger.input("read_image INPUT: file_path={}", file_path)
            try:
                # Resolve relative paths using project_dir if available
                if self._project_dir:
                    resolved_path = resolve_to_absolute(file_path, Path(self._project_dir))
                    file_path = str(resolved_path)
                
                result = FileUtils.read_image_file(file_path)
                # Remove raw bytes field for JSON serialization (keep base64 instead)
                # The 'data' field contains binary bytes which can't be serialized to JSON
                json_safe_result = {
                    "path": result["path"],
                    "name": result["name"],
                    "base64": result.get("base64", ""),  # base64-encoded data for JSON serialization
                    "metadata": result["metadata"]
                }
                self._logger.output("read_image OUTPUT: image={}, size={} bytes", 
                                  json_safe_result["name"], json_safe_result["metadata"]["size_bytes"])
                return json_safe_result
            except Exception as e:
                self._logger.error("read_image failed: {}", e)
                raise

        @mcp.tool(name="common_read_document")
        def read_document(file_path: str) -> dict:
            """Read document file and return text with metadata.
            
            IMPORTANT: This tool only works with real filesystem paths.
            Supports both relative paths (relative to project_dir) and absolute paths.
            For AgentOS memory paths (e.g., /global/..., /shared/..., /memory/...), use agentos_shell instead.
            
            [roles: intake, parser]"""
            from topaz_agent_kit.utils.file_utils import FileUtils
            from topaz_agent_kit.utils.path_resolver import resolve_to_absolute
            from pathlib import Path
            
            self._logger.input("read_document INPUT: file_path={}", file_path)
            try:
                # Resolve relative paths using project_dir if available
                if self._project_dir:
                    resolved_path = resolve_to_absolute(file_path, Path(self._project_dir))
                    file_path = str(resolved_path)
                
                result = FileUtils.read_document_file(file_path)
                # Remove raw bytes field for JSON serialization (keep base64 instead)
                # The 'data' field contains binary bytes which can't be serialized to JSON
                json_safe_result = {
                    "path": result["path"],
                    "name": result["name"],
                    "base64": result.get("base64", ""),  # base64-encoded data for JSON serialization
                    "text": result.get("text", ""),  # extracted text (if available)
                    "metadata": result["metadata"]
                }
                self._logger.output("read_document OUTPUT: document={}, size={} bytes", 
                                  json_safe_result["name"], json_safe_result["metadata"]["size_bytes"])
                return json_safe_result
            except Exception as e:
                self._logger.error("read_document failed: {}", e)
                raise
