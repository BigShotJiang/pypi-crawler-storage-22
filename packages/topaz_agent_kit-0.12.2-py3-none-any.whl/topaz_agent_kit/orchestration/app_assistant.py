"""
App Assistant Module

Specialized assistant for App Session Mode that helps users interact with
a canvas-based artifact through natural language. The assistant can read
and update the canvas state using tools.
"""

import importlib
import json
import sys
from pathlib import Path
from datetime import datetime
from typing import Any, Dict, List, Optional

from agent_framework import ChatAgent, ChatMessage, Role

from topaz_agent_kit.frameworks.framework_config_manager import FrameworkConfigManager


# --- Thread repair: incomplete tool-call sequences ---
# Root cause: After agent.run(), the framework's thread.serialize() can sometimes
# produce a thread where the last message is an assistant message with tool_calls
# but no following tool result messages (e.g. with response_format or certain
# code paths). The chat API then returns 400 on the next request. We never want
# to persist or send that invalid state, so we normalize at save and at load.


def _looks_like_messages(lst: List[Any]) -> bool:
    """True if list looks like a message list (each item has a 'role' key)."""
    if not lst or not isinstance(lst, list):
        return False
    return all(
        isinstance(m, dict) and "role" in m
        for m in lst
    )


def _strip_trailing_incomplete_assistant(messages: List[Any]) -> List[Any]:
    """Remove trailing assistant messages that have tool_calls but no following tool response."""
    out = list(messages)
    while out:
        last = out[-1]
        role = last.get("role") if isinstance(last, dict) else getattr(last, "role", None)
        tool_calls = last.get("tool_calls") if isinstance(last, dict) else getattr(last, "tool_calls", None)
        if role == "assistant" and tool_calls:
            out.pop()
        else:
            break
    return out


def _repair_thread_messages(serialized: Any) -> Any:
    """
    Strip trailing assistant messages that have tool_calls but no following tool
    messages, so the thread is valid for the API. Used at save time (so we never
    persist bad state) and at load time (for existing DB rows).
    """
    if serialized is None:
        return serialized
    if isinstance(serialized, list):
        if _looks_like_messages(serialized):
            return _strip_trailing_incomplete_assistant(serialized)
        return serialized
    if isinstance(serialized, dict):
        result = dict(serialized)
        for k, v in result.items():
            if isinstance(v, list) and _looks_like_messages(v):
                result[k] = _strip_trailing_incomplete_assistant(v)
            elif isinstance(v, (dict, list)):
                result[k] = _repair_thread_messages(v)
        return result
    return serialized


from topaz_agent_kit.frameworks.framework_model_factory import FrameworkModelFactory
from topaz_agent_kit.utils.logger import Logger
from topaz_agent_kit.core.app_session_store import AppSessionStore
from topaz_agent_kit.utils.prompt_loader import PromptLoader
from topaz_agent_kit.utils.json_utils import JSONUtils
from topaz_agent_kit.utils.assistant_config import get_assistant_config, load_ui_manifest
from topaz_agent_kit.orchestration.assistant import AssistantResponse, WidgetAttachment
from topaz_agent_kit.orchestration.widget_collector import (
    WidgetCollector,
    get_widget_collector,
    set_widget_collector,
)
from topaz_agent_kit.orchestration.assistant_tools import AssistantToolsMixin

# Import A2UI converter (required dependency)
from topaz_agent_kit.utils.a2ui_converter import A2UIConverter


class AppAssistant(AssistantToolsMixin):
    """
    App Assistant for canvas-based app sessions.
    
    Provides tools for reading and updating canvas state, enabling
    collaborative editing between user and AI assistant.
    """
    
    def __init__(
        self,
        app_config: Dict[str, Any],
        app_session_id: str,
        project_dir: str,
        app_session_store: AppSessionStore,
    ):
        """
        Initialize App Assistant.
        
        Args:
            app_config: App configuration dictionary (from app manifest)
            app_session_id: Current app session ID
            project_dir: Project directory path
            app_session_store: AppSessionStore instance for state management
        """
        self.logger = Logger("AppAssistant")
        self._app_config = app_config
        self._app_session_id = app_session_id
        self._project_dir = project_dir
        self._app_session_store = app_session_store
        
        # Extract app_id from app_config (used for assistant config resolution)
        self._app_id = app_config.get("app_id") or app_config.get("id")
        
        # Extract assistant config from app config
        self._assistant_config = app_config.get("app_assistant", {})
        assistant_config_file = self._assistant_config.get("config_file")
        
        if assistant_config_file:
            # Load assistant config from referenced file
            self._load_assistant_config(assistant_config_file)
        
        self._agent_id = self._assistant_config.get("id", "app_assistant")
        self._framework_type = self._assistant_config.get("type", "maf")
        self._model_type = self._assistant_config.get("model", "azure_openai")
        self._max_history_messages = self._assistant_config.get("max_history_messages", 20)
        
        self._llm = None
        self._agent = None
        self._thread = None
        
        # Load prompt template
        self._prompt_loader = PromptLoader(self._project_dir)
        self._prompt_spec = self._assistant_config.get("prompt", {})
        self._prompt_spec_instruction = self._prompt_spec.get("instruction", {})
        
        # Get prompt file path or inline content
        if isinstance(self._prompt_spec_instruction, dict):
            # Already a proper spec dict (e.g., {"jinja": "prompts/..."})
            prompt_spec = self._prompt_spec_instruction
        elif isinstance(self._prompt_spec_instruction, str):
            # String path - convert to spec dict
            prompt_spec = {"jinja": self._prompt_spec_instruction}
        else:
            # Default prompt path
            prompt_spec = {"jinja": "prompts/app_assistant.jinja"}
        
        # Load prompt template (raw, not rendered yet)
        self._prompt_template = self._prompt_loader.load_prompt(prompt_spec)
        # Store prompt file path for include support
        self._prompt_file_path = prompt_spec.get("jinja") or prompt_spec.get("file")
        
        # Initialize A2UI converter (required dependency)
        self._a2ui_converter = A2UIConverter()
        
        if not self._prompt_template:
            prompt_path = prompt_spec.get("jinja") or prompt_spec.get("file") or "unknown"
            self.logger.error(
                "Failed to load app assistant prompt: {}",
                prompt_path
            )
            raise ValueError(
                f"App assistant prompt not found: {prompt_path}. "
                "Please ensure the prompt file exists in config/prompts/"
            )
        
        self.logger.success(
            "App Assistant initialized for session: {}", app_session_id
        )
    
    def _load_assistant_config(self, config_file: str) -> None:
        """Load assistant configuration from a YAML file."""
        import yaml
        
        config_path = Path(self._project_dir) / "config" / config_file
        
        if not config_path.exists():
            self.logger.warning(
                "Assistant config file not found: {}", config_path
            )
            return
        
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                loaded_config = yaml.safe_load(f) or {}
            
            # Merge loaded config into assistant config
            self._assistant_config.update(loaded_config)
            self.logger.debug("Loaded assistant config from: {}", config_file)
        except Exception as e:
            self.logger.error("Failed to load assistant config: {}", e)

    def _load_app_tools(self, app_tools_config: Dict[str, Any]) -> List[Any]:
        """Load app-specific tools from a project-local module.

        Config shape: { "module": "config.tools.earth_map_tools", "names": ["geocode_place", ...] }
        Adds project_dir to sys.path, imports the module, and returns a list of callables by name.
        """
        if not isinstance(app_tools_config, dict):
            self.logger.warning("app_tools config must be a dict with 'module' and 'names'")
            return []
        module_path = app_tools_config.get("module")
        names = app_tools_config.get("names")
        if not module_path or not names:
            self.logger.warning("app_tools requires 'module' and 'names'")
            return []
        if not isinstance(names, list):
            names = [names]
        project_dir_resolved = Path(self._project_dir).resolve()
        project_dir_str = str(project_dir_resolved)
        path_added = False
        if project_dir_str not in sys.path:
            sys.path.insert(0, project_dir_str)
            path_added = True
        try:
            mod = importlib.import_module(module_path)
            loaded = []
            for name in names:
                if not isinstance(name, str):
                    continue
                fn = getattr(mod, name, None)
                if callable(fn):
                    loaded.append(fn)
                    self.logger.debug("Loaded app tool: {}", name)
                else:
                    self.logger.warning("App tool '{}' not found or not callable in {}", name, module_path)
            return loaded
        except ImportError as e:
            self.logger.warning("Failed to import app tools module {}: {}", module_path, e)
            return []
        except Exception as e:
            self.logger.error("Error loading app tools from {}: {}", module_path, e)
            return []
        finally:
            if path_added and project_dir_str in sys.path:
                try:
                    sys.path.remove(project_dir_str)
                except ValueError:
                    pass
    
    async def _initialize_llm(self) -> None:
        """Initialize LLM using unified framework-aware factory."""
        try:
            config_manager = FrameworkConfigManager()
            model_config = config_manager.get_model_config(
                model_type=self._model_type,
                framework=self._framework_type,
            )
            
            self._llm = FrameworkModelFactory.get_model(
                model_type=self._model_type,
                framework=self._framework_type,
                **model_config,
            )
            
            self.logger.success(
                "Initialized App Assistant with {} {} model",
                self._framework_type.title(),
                self._model_type,
            )
        except Exception as e:
            self.logger.error("Failed to initialize LLM: {}", e)
            raise
    
    async def _create_agent(self, canvas_state: Dict[str, Any]) -> None:
        """Create app assistant agent with tools."""
        try:
            # Ensure canvas_state is a dict (not a string)
            if isinstance(canvas_state, str):
                import json
                try:
                    canvas_state = json.loads(canvas_state)
                    self.logger.debug("Parsed canvas_state from JSON string")
                except (json.JSONDecodeError, TypeError):
                    self.logger.warning("canvas_state is a string but not valid JSON, using empty dict")
                    canvas_state = {}
            elif not isinstance(canvas_state, dict):
                self.logger.warning("canvas_state is not a dict (type: {}), using empty dict", type(canvas_state).__name__)
                canvas_state = {}
            
            # Load ui_manifest and get assistant config
            ui_manifest = load_ui_manifest(Path(self._project_dir))
            assistant_config = get_assistant_config(ui_manifest, "apps", self._app_id)
            
            # Check if case_id is in state metadata (launched from case)
            case_id = None
            case_data = None
            metadata = canvas_state.get("_metadata", {})
            if metadata:
                case_id = metadata.get("case_id")
            
            # If case_id exists, load case data for context
            if case_id:
                try:
                    from topaz_agent_kit.core.case_manager import CaseManager
                    from topaz_agent_kit.core.chat_database import ChatDatabase
                    from topaz_agent_kit.core.pipeline_loader import PipelineLoader
                    
                    # Get database path from orchestrator config
                    pipeline_loader = PipelineLoader(Path(self._project_dir))
                    pipeline_config, _ = pipeline_loader.load()
                    from topaz_agent_kit.utils.path_resolver import resolve_path_if_relative
                    chatdb_path = pipeline_config.get("chatdb_path", "./data/chat.db")
                    chatdb_path = resolve_path_if_relative(chatdb_path, Path(self._project_dir))
                    
                    database = ChatDatabase(chatdb_path)
                    case_manager = CaseManager(database)
                    case = case_manager.get_case(case_id)
                    if case:
                        case_data = case.get("case_data", {})
                        self.logger.debug("Loaded case data for case_id: {}", case_id)
                except Exception as e:
                    self.logger.warning("Failed to load case data for case_id {}: {}", case_id, e)
            
            # Extract canvas guidance from app config (plain English text)
            canvas_config = self._app_config.get("canvas", {})
            canvas_guidance_text = canvas_config.get("canvas_guidance", "")
            if isinstance(canvas_guidance_text, dict):
                # Handle old structured format - convert to text if needed
                canvas_guidance_text = ""
            
            # Get canvas source mode (agent, declarative, or hybrid)
            canvas_source = canvas_config.get("source", "declarative")
            
            # Render prompt template with canvas state and assistant config
            prompt_variables = {
                "canvas_state": canvas_state,
                "assistant_name": assistant_config["name"],
                "assistant_subtitle": assistant_config["subtitle"],
                "assistant_greeting": assistant_config["greeting"],
                "allow_session_title_updates": self._app_config.get("allow_session_title_updates", True),  # Default to True for backward compatibility
                
                # Canvas guidance (plain English text for agent/hybrid mode)
                "canvas_guidance": canvas_guidance_text,
                
                # Canvas source mode (agent, declarative, hybrid)
                "canvas_source": canvas_source,
            }
            
            # Add case context if available
            if case_id:
                prompt_variables["case_id"] = case_id
            if case_data:
                prompt_variables["case_data"] = case_data
                # Store case_data for use in tools
                self._case_data = case_data
            else:
                self._case_data = None
            
            instruction = self._prompt_loader.render_prompt(
                self._prompt_template,
                variables=prompt_variables,
                template_path=self._prompt_file_path
            )
            
            # Build tools list
            tools = [
                self.get_canvas_state,
                self.update_canvas,
                self.get_state_schema,
                self.initialize_state,
                self.get_canvas_structure,
                self.update_canvas_section,
                self.update_canvas_structure,
                self.update_canvas_with_a2ui,
                self.insert_widget,
                self.send_a2ui_message,
                self.get_current_datetime,
                self.get_current_location,
            ]
            
            # Add case-specific tools if case_id exists
            if case_id:
                tools.extend([
                    self.get_case_context,
                    self.submit_resolution,
                    # Note: get_validation_explanation removed - agent can read directly from case_data in prompt
                ])
                # Store case_id for use in tools
                self._case_id = case_id

            # Add app-specific local tools from template (app_tools in app or agent config)
            app_tools_config = self._assistant_config.get("app_tools") or self._app_config.get("app_tools")
            if app_tools_config:
                app_tools_list = self._load_app_tools(app_tools_config)
                if app_tools_list:
                    tools.extend(app_tools_list)
                    self.logger.info("Loaded {} app-specific tool(s) for app {}", len(app_tools_list), self._app_id)
            
            self._agent = ChatAgent(
                chat_client=self._llm,
                name=self._agent_id,
                description="App Assistant - helps users interact with canvas content",
                instructions=instruction,
                tools=tools,
            )
            
            self.logger.debug("App assistant agent created successfully")
        except Exception as e:
            self.logger.error("Failed to create app assistant agent: {}", e)
            raise
    
    async def _deserialize_thread(self) -> None:
        """Restore thread state from database for conversation memory."""
        try:
            thread_state_json = self._app_session_store.get_thread_state(self._app_session_id)
            
            if thread_state_json:
                self.logger.debug(
                    "Deserializing thread state for session: {}",
                    self._app_session_id,
                )
                try:
                    serialized_thread = json.loads(thread_state_json)
                    if self.logger.isEnabledFor(10):  # DEBUG
                        _shape = "dict_keys({})".format(list(serialized_thread.keys())) if isinstance(serialized_thread, dict) else type(serialized_thread).__name__
                        self.logger.debug("Thread state shape: {}", _shape)
                    serialized_thread = _repair_thread_messages(serialized_thread)
                    self._thread = await self._agent.deserialize_thread(serialized_thread)
                    self.logger.info(
                        "Thread state restored from database for session: {}",
                        self._app_session_id,
                    )
                except json.JSONDecodeError as e:
                    self.logger.warning(
                        "Failed to parse thread state JSON: {}. Creating new thread.",
                        e
                    )
                    self._thread = self._agent.get_new_thread()
                except Exception as e:
                    # Handle incomplete tool call sequences or other thread state corruption
                    # This can happen if a previous interaction was interrupted or failed
                    error_msg = str(e).lower()
                    if "tool_calls" in error_msg or "tool_call_id" in error_msg or "invalid_request_error" in error_msg:
                        self.logger.warning(
                            "Thread state has incomplete tool calls or is corrupted: {}. Creating new thread.",
                            e
                        )
                    else:
                        self.logger.warning(
                            "Error deserializing thread state: {}. Creating new thread.",
                            e
                        )
                    self._thread = self._agent.get_new_thread()
            else:
                self.logger.info(
                    "No thread state in database for session: {}, creating new thread",
                    self._app_session_id,
                )
                self._thread = self._agent.get_new_thread()
        except Exception as e:
            self.logger.error("Error deserializing thread: {}", e)
            self._thread = self._agent.get_new_thread()
    
    async def _serialize_thread(self) -> None:
        """Save thread state to database for conversation memory."""
        if not self._thread:
            self.logger.debug("No thread to serialize")
            return
        
        try:
            self.logger.debug(
                "Serializing thread state for session: {}",
                self._app_session_id,
            )
            serialized_thread = await self._thread.serialize()
            # Never persist incomplete tool-call sequences (see root-cause comment at _repair_thread_messages)
            serialized_thread = _repair_thread_messages(serialized_thread)
            serialized_json = json.dumps(serialized_thread)
            
            success = self._app_session_store.update_thread_state(
                self._app_session_id,
                serialized_json,
            )
            
            if success:
                self.logger.info(
                    "Thread state saved to database for session: {}",
                    self._app_session_id,
                )
            else:
                self.logger.warning(
                    "Failed to save thread state to database for session: {} (no row updated)",
                    self._app_session_id,
                )
        except Exception as e:
            self.logger.error("Error serializing thread: {}", e)
    
    async def initialize(self) -> None:
        """Initialize the app assistant."""
        await self._initialize_llm()
        
        # Get current canvas state
        session = self._app_session_store.get_session(self._app_session_id)
        canvas_state = session.state if session else {}
        
        # Create agent
        await self._create_agent(canvas_state)
        
        # Restore conversation history from database
        await self._deserialize_thread()
    
    async def execute(
        self,
        user_text: str,
    ) -> Dict[str, Any]:
        """
        Execute a user message and return response.
        
        Args:
            user_text: User's message
            
        Returns:
            Dictionary with reply and state (or error and state)
        """
        try:
            # Get current canvas state
            session = self._app_session_store.get_session(self._app_session_id)
            if not session:
                return {
                    "error": f"Session {self._app_session_id} not found",
                    "state": {},
                }
            
            canvas_state = session.state
            
            # Ensure LLM is initialized
            if not self._llm:
                await self._initialize_llm()
            
            # Recreate agent with updated canvas state in prompt
            # (canvas state may have changed since last call)
            await self._create_agent(canvas_state)
            
            # Reload thread from DB every turn so we have latest conversation context (recall
            # after page reload / multi-worker; aligns with main chat in assistant.py)
            await self._deserialize_thread()

            # Save user message IMMEDIATELY before processing
            # This ensures user message persists even if errors occur during agent.run()
            self._app_session_store.add_chat_turn(
                app_session_id=self._app_session_id,
                role="user",
                content=user_text,
            )
            
            # Initialize widget collector for this turn
            widget_collector = None
            try:
                widget_collector = WidgetCollector()
                widget_limit = self._assistant_config.get("widget_limit", 10)
                widget_collector.set_max_widgets(widget_limit)
                set_widget_collector(widget_collector)
            except Exception as e:
                self.logger.warning("Failed to initialize widget collector: {}", e)
                widget_collector = WidgetCollector()  # Fallback
            
            try:
                # Create user message
                message = ChatMessage(role=Role.USER, text=user_text)
                
                # Run the agent with structured response format
                response = await self._agent.run(
                    message,
                    tool_choice="auto",  # Let LLM decide whether to use tools
                    thread=self._thread,
                    response_format=AssistantResponse,  # Enforce structured response
                )
                
                # Save conversation history to database
                await self._serialize_thread()
            except Exception as e:
                # Handle incomplete tool call sequences in conversation history
                # This can happen if a previous interaction was interrupted or failed
                error_msg = str(e).lower()
                if "tool_calls" in error_msg or "tool_call_id" in error_msg or "invalid_request_error" in error_msg:
                    self.logger.warning(
                        "Conversation history has incomplete tool calls: {}. Resetting thread and retrying.",
                        e
                    )
                    # Reset thread to clear corrupted state
                    self._thread = self._agent.get_new_thread()
                    # Clear corrupted thread state from database (pass empty string to clear)
                    self._app_session_store.update_thread_state(self._app_session_id, "")
                    # Retry with fresh thread
                    response = await self._agent.run(
                        message,
                        tool_choice="auto",
                        thread=self._thread,
                        response_format=AssistantResponse,
                    )
                    # Save new thread state
                    await self._serialize_thread()
                else:
                    # Re-raise other errors
                    raise
            finally:
                # Don't clear collector yet - we need to extract widgets first
                pass
            
            # Extract response text, session_title, and widgets
            reply = ""
            session_title = None
            widgets = None
            structured_response = None
            
            # Handle structured AssistantResponse
            if response.value:
                if isinstance(response.value, AssistantResponse):
                    # Already a Pydantic model
                    structured_response = response.value
                    reply = structured_response.assistant_response or ""
                    session_title = structured_response.session_title
                    # Widgets are collected via tool calls, not from structured response
                    widgets = None
                    self.logger.info(
                        "Extracted from AssistantResponse - reply length: {}",
                        len(reply) if reply else 0,
                    )
                elif isinstance(response.value, dict):
                    # Try to parse as AssistantResponse
                    try:
                        structured_response = AssistantResponse(**response.value)
                        reply = structured_response.assistant_response or ""
                        session_title = structured_response.session_title
                        # Widgets are collected via tool calls, not from structured response
                        widgets = None
                        self.logger.info(
                            "Parsed dict to AssistantResponse - reply length: {}",
                            len(reply) if reply else 0,
                        )
                    except Exception as e:
                        # Fallback to dict extraction
                        self.logger.warning("Failed to parse as AssistantResponse: {}", e)
                        reply = response.value.get("assistant_response", str(response.value))
                        session_title = response.value.get("session_title")
                        # Widgets are collected via tool calls, not from structured response
                        widgets = None
                else:
                    # Try to parse as JSON string
                    response_str = str(response.value)
                    self.logger.info("Response.value is string, length: {}, preview: {}", 
                                    len(response_str), response_str[:200])
                    try:
                        parsed = JSONUtils.parse_json_from_text(response_str, expect_json=False)
                        if isinstance(parsed, dict):
                            try:
                                structured_response = AssistantResponse(**parsed)
                                reply = structured_response.assistant_response or ""
                                session_title = structured_response.session_title
                                # Widgets are collected via tool calls, not from structured response
                                widgets = None
                            except Exception:
                                # Fallback to dict extraction
                                reply = parsed.get("assistant_response", response_str)
                                session_title = parsed.get("session_title")
                                # Widgets are collected via tool calls, not from structured response
                                widgets = None
                        else:
                            reply = response_str
                    except Exception as e:
                        self.logger.warning("Failed to parse JSON from response.value: {}", e)
                        reply = response_str
            # Fallback to response.text if available
            elif hasattr(response, 'text') and response.text:
                response_str = str(response.text)
                self.logger.info("Using response.text, length: {}, preview: {}", 
                                len(response_str), response_str[:200])
                try:
                    parsed = JSONUtils.parse_json_from_text(response_str, expect_json=False)
                    if isinstance(parsed, dict):
                        try:
                            structured_response = AssistantResponse(**parsed)
                            reply = structured_response.assistant_response or ""
                            session_title = structured_response.session_title
                            # Widgets are collected via tool calls, not from structured response
                            widgets = None
                        except Exception:
                            reply = parsed.get("assistant_response", response_str)
                            session_title = parsed.get("session_title")
                            # Widgets are collected via tool calls, not from structured response
                            widgets = None
                    else:
                        reply = response_str
                except Exception as e:
                    self.logger.warning("Failed to parse JSON from response.text: {}", e)
                    reply = response_str
            # Final fallback: str(response)
            else:
                reply = str(response)
                self.logger.info("Using str(response) (response.value and response.text empty), length: {}, preview: {}", 
                                len(reply), reply[:200])
            
            # Extract widgets from collector (always check, widgets is None at this point)
            widgets = None
            if widget_collector:
                try:
                    collected_widgets = widget_collector.get_widgets()
                    if collected_widgets:
                        widgets = collected_widgets
                        self.logger.info("Extracted {} widget(s) from collector", len(widgets))
                    else:
                        self.logger.debug("No widgets found in collector")
                except Exception as e:
                    self.logger.warning("Failed to extract widgets from collector: {}", e)
            
            # Ensure reply is a string (not dict or other type)
            if not isinstance(reply, str):
                reply = str(reply)
            
            # Get latest state after any tool calls
            updated_session = self._app_session_store.get_session(self._app_session_id)
            final_state = updated_session.state if updated_session else canvas_state
            
            # Note: User message already saved above (before agent.run()) to ensure persistence on errors
            
            # Convert widgets to dict format for storage
            widgets_data = None
            if widgets:
                try:
                    widgets_data = []
                    for widget in widgets:
                        if isinstance(widget, WidgetAttachment):
                            widgets_data.append(widget.model_dump())
                        elif isinstance(widget, dict):
                            widgets_data.append(widget)
                        else:
                            # Fallback: try to convert to dict
                            self.logger.warning("Unexpected widget type: {}, converting to dict", type(widget))
                            widgets_data.append({
                                "widget_type": getattr(widget, 'widget_type', 'unknown'),
                                "data": getattr(widget, 'data', {}),
                                "props": getattr(widget, 'props', {}),
                                "binding": getattr(widget, 'binding', None),
                            })
                    self.logger.debug("Converted {} widget(s) to dict format", len(widgets_data))
                except Exception as e:
                    self.logger.error("Failed to convert widgets to dict format: {}", e, exc_info=True)
                    widgets_data = None  # Don't fail the whole request if widget serialization fails
            
            self._app_session_store.add_chat_turn(
                app_session_id=self._app_session_id,
                role="assistant",
                content=reply,
                widgets=widgets_data,  # Include widgets
            )
            
            result = {
                "reply": reply,
                "state": final_state,
            }
            # Only include session_title if app allows title updates
            allow_title_updates = self._app_config.get("allow_session_title_updates", True)
            if session_title and allow_title_updates:
                result["session_title"] = session_title
                self.logger.info("Including session_title in result: {}", session_title)
            elif session_title and not allow_title_updates:
                self.logger.debug("Session title updates disabled for app {}, ignoring session_title from assistant", self._app_id)
            if widgets_data:
                # Convert widgets_data (already dicts) to list of dicts for API response
                result["widgets"] = widgets_data
                self.logger.info("Including {} widget(s) in result", len(widgets_data))
            
            # Include suggested_questions from structured response (validated, 2-4 items, 10-60 chars each)
            if structured_response and getattr(structured_response, "suggested_questions", None):
                raw = structured_response.suggested_questions
                validated = [
                    q.strip()[:60] for q in raw[:4]
                    if q and isinstance(q, str) and 10 <= len(q.strip()) <= 60
                ]
                if 2 <= len(validated) <= 4:
                    result["suggested_questions"] = validated
                    self.logger.info("Including {} suggested_questions in result", len(validated))
                elif len(validated) > 4:
                    result["suggested_questions"] = validated[:4]
                    self.logger.info("Including 4 suggested_questions in result (trimmed)")
            
            # Clean up widget collector after extracting widgets
            if widget_collector:
                try:
                    widget_collector.clear()
                    set_widget_collector(None)
                except Exception as e:
                    self.logger.warning("Failed to clean up widget collector: {}", e)
            
            return result
        except Exception as e:
            self.logger.error("Error executing app assistant: {}", e, exc_info=True)
            
            # Clean up widget collector on error
            if widget_collector:
                try:
                    widget_collector.clear()
                    set_widget_collector(None)
                except Exception:
                    pass
            
            # Save error response to database so it persists after refresh
            # User message was already saved above (before agent.run())
            error_message = f"I encountered an error: {str(e)}"
            try:
                self._app_session_store.add_chat_turn(
                    app_session_id=self._app_session_id,
                    role="assistant",
                    content=error_message,
                )
            except Exception as save_error:
                self.logger.warning("Failed to save error response to database: {}", save_error)
            
            # Try to get current state even on error
            try:
                session = self._app_session_store.get_session(self._app_session_id)
                current_state = session.state if session else {}
            except Exception:
                current_state = {}
            
            return {
                "error": str(e),
                "state": current_state,
            }
    
    # === CANVAS TOOLS ===
    
    async def get_canvas_state(
        self,
        path: Optional[str] = None,
    ) -> str:
        """
        Tool: Get current canvas state.
        
        Args:
            path: Optional path to get specific field (e.g., "article.body").
                  If not provided, returns full state.
                  
        Returns:
            JSON string with the state or field value
        """
        try:
            session = self._app_session_store.get_session(self._app_session_id)
            
            if not session:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": f"Session {self._app_session_id} not found",
                })
            
            state = session.state
            
            if path:
                # Get value at specific path
                value = self._get_value_at_path(state, path)
                self.logger.debug("Retrieved canvas state at path '{}': {}", path, value)
                return JSONUtils.normalize_for_ui({
                    "success": True,
                    "path": path,
                    "value": value,
                })
            else:
                # Return full state
                self.logger.debug("Retrieved full canvas state")
                return JSONUtils.normalize_for_ui({
                    "success": True,
                    "state": state,
                })
        except Exception as e:
            self.logger.error("Error getting canvas state: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
            })
    
    async def update_canvas(
        self,
        path: str,
        value: Any,
    ) -> str:
        """
        Tool: Update a field in the canvas state.
        
        In agent mode: updating state alone is not enough for the user to see content.
        You MUST also call update_canvas_structure() in the same turn so the UI has a
        layout to display the data. Without the structure, the canvas stays empty.
        
        Args:
            path: Path to the field to update (e.g., "article.title", "article.body", "map")
            value: New value to set at the path
            
        Returns:
            JSON string with result
        """
        try:
            session = self._app_session_store.get_session(self._app_session_id)
            
            if not session:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": f"Session {self._app_session_id} not found",
                })
            
            # Build patch from path and value
            patch = self._build_patch_from_path(path, value)
            
            # Get manifest for validation (if available)
            manifest = None
            try:
                # Try to get manifest from app config
                if hasattr(self, '_app_config'):
                    manifest = self._app_config
            except Exception:
                pass
            
            # Update state using patch_state (merges with existing)
            # Note: patch_state now returns (success, errors) tuple
            result = self._app_session_store.patch_state(
                app_session_id=self._app_session_id,
                patch=patch,
                manifest=manifest,
                validate=True
            )
            
            if isinstance(result, tuple):
                success, errors = result
            else:
                # Backward compatibility: old signature returns bool
                success = result
                errors = None
            
            if success:
                self.logger.info(
                    "Updated canvas at path '{}' for session {}",
                    path, self._app_session_id
                )
                # Agent mode: if session has no canvas structure yet, the UI would show nothing.
                # Build a default structure from default_state so the canvas can display the updated state.
                session = self._app_session_store.get_session(self._app_session_id)
                canvas_config = (self._app_config or {}).get("canvas") or {}
                if (
                    session
                    and canvas_config.get("source") == "agent"
                    and (not session.canvas_structure or not (session.canvas_structure.get("sections") or {}))
                ):
                    default_structure = self._build_default_canvas_structure_from_state()
                    if default_structure:
                        save_ok = self._app_session_store.update_canvas_structure(
                            self._app_session_id,
                            default_structure,
                        )
                        if save_ok:
                            self.logger.info(
                                "Agent mode: auto-created default canvas structure from state so UI can display content (session {})",
                                self._app_session_id,
                            )
                return JSONUtils.normalize_for_ui({
                    "success": True,
                    "path": path,
                    "message": f"Successfully updated {path}",
                })
            else:
                # Validation failed - include errors so agent can fix them
                error_msg = "Failed to update state"
                if errors:
                    error_msg = f"Validation failed: {'; '.join(errors)}"
                    self.logger.warning(
                        "Canvas update failed at path '{}' for session {}: {}",
                        path, self._app_session_id, error_msg
                    )
                else:
                    self.logger.error(
                        "Canvas update failed at path '{}' for session {}: {}",
                        path, self._app_session_id, error_msg
                    )
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": error_msg,
                    "path": path,
                    "validation_errors": errors if errors else None,
                })
        except Exception as e:
            self.logger.error("Error updating canvas: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
                "path": path,
            })
    
    async def get_state_schema(self) -> str:
        """
        Tool: Get state schema for this app.
        
        Returns:
            JSON string with state schema, default state, and current state
        """
        try:
            session = self._app_session_store.get_session(self._app_session_id)
            manifest = self._app_config
            
            state_schema = manifest.get("state_schema", {})
            default_state = manifest.get("default_state", {})
            current_state = session.state if session else {}
            
            return JSONUtils.normalize_for_ui({
                "success": True,
                "has_schema": bool(state_schema),
                "state_schema": state_schema,
                "default_state": default_state,
                "current_state": current_state,
            })
        except Exception as e:
            self.logger.error("Error getting state schema: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
            })
    
    async def initialize_state(
        self,
        state_structure: Dict[str, Any],
        merge: bool = True,
    ) -> str:
        """
        Tool: Initialize or update state structure.
        
        Args:
            state_structure: State structure to initialize/update
            merge: If True, deep merge with existing state. If False, replace state.
            
        Returns:
            JSON string with result
        """
        try:
            session = self._app_session_store.get_session(self._app_session_id)
            if not session:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": f"Session {self._app_session_id} not found",
                })
            
            if merge:
                # Deep merge with existing state
                new_state = self._deep_merge(session.state, state_structure)
            else:
                # Replace state
                new_state = state_structure
            
            success = self._app_session_store.update_state(
                self._app_session_id,
                new_state
            )
            
            if success:
                self.logger.info(
                    "Initialized state structure for session {} (merge={})",
                    self._app_session_id, merge
                )
                return JSONUtils.normalize_for_ui({
                    "success": True,
                    "message": "State structure initialized successfully",
                })
            else:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": "Failed to initialize state structure",
                })
        except Exception as e:
            self.logger.error("Error initializing state: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
            })
    
    def _deep_merge(self, base: Dict[str, Any], patch: Dict[str, Any]) -> Dict[str, Any]:
        """Deep merge patch into base dictionary."""
        result = dict(base)
        
        for key, value in patch.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._deep_merge(result[key], value)
            else:
                result[key] = value
        
        return result
    
    async def get_canvas_structure(
        self,
        include_placeholders: bool = True,
    ) -> str:
        """
        Tool: Get current canvas structure (YAML + agent-generated).
        
        Args:
            include_placeholders: Whether to include placeholder sections
            
        Returns:
            JSON string with canvas structure
        """
        try:
            session = self._app_session_store.get_session(self._app_session_id)
            manifest = self._app_config
            
            yaml_structure = manifest.get("canvas", {})
            agent_structure = session.canvas_structure if session else None
            
            return JSONUtils.normalize_for_ui({
                "success": True,
                "yaml_structure": yaml_structure,
                "agent_structure": agent_structure,
                "canvas_source": yaml_structure.get("source", "declarative"),
            })
        except Exception as e:
            self.logger.error("Error getting canvas structure: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
            })
    
    async def update_canvas_section(
        self,
        section_id: str,
        section_spec: Dict[str, Any],
        action: str = "create_or_update",
    ) -> str:
        """
        Tool: Create or update a canvas section.
        
        Args:
            section_id: Unique section identifier
            section_spec: Section specification (id, title, controls, etc.)
            action: "create_or_update" or "delete"
            
        Returns:
            JSON string with result
        """
        try:
            self.logger.input("update_canvas_section INPUT: section_id={}, action={}", section_id, action)
            controls_count = len(section_spec.get("controls", [])) if isinstance(section_spec, dict) else 0
            self.logger.debug("update_canvas_section - section_spec has {} controls", controls_count)
            
            session = self._app_session_store.get_session(self._app_session_id)
            if not session:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": f"Session {self._app_session_id} not found",
                })
            
            manifest = self._app_config
            canvas_source = manifest.get("canvas", {}).get("source", "declarative")
            
            # Validate section source restrictions
            yaml_sections = manifest.get("canvas", {}).get("sectionDefinitions", {})
            yaml_section = yaml_sections.get(section_id)
            
            if yaml_section:
                # Check if section is locked
                if yaml_section.get("locked", False):
                    return JSONUtils.normalize_for_ui({
                        "success": False,
                        "error": f"Section {section_id} is locked and cannot be modified",
                    })
                
                # Check source compatibility
                section_source = yaml_section.get("source", "declarative")
                if section_source == "declarative" and canvas_source != "hybrid":
                    return JSONUtils.normalize_for_ui({
                        "success": False,
                        "error": f"Cannot modify declarative section {section_id} in {canvas_source} mode",
                    })
            
            # Get or create canvas structure
            canvas_structure = session.canvas_structure or {
                "sections": {},
                "order": [],
                "metadata": {
                    "last_updated_by": "agent",
                    "last_updated_at": datetime.now().isoformat(),
                    "version": 1,
                },
            }
            
            if action == "delete":
                # Remove section from structure
                if section_id in canvas_structure["sections"]:
                    del canvas_structure["sections"][section_id]
                    # Remove from order
                    canvas_structure["order"] = [
                        item for item in canvas_structure["order"]
                        if item.get("id") != section_id
                    ]
            else:
                # Ensure section has ID
                section_spec["id"] = section_id
                
                # If this is a placeholder section, preserve YAML properties (collapsible, title, showTitle, width, layout, etc.)
                # and merge with agent-provided content (controls, sub-sections)
                if yaml_section and yaml_section.get("placeholder", False):
                    # Preserve YAML metadata properties
                    preserved_properties = {
                        "collapsible": yaml_section.get("collapsible"),
                        "title": yaml_section.get("title"),
                        "showTitle": yaml_section.get("showTitle"),
                        "width": yaml_section.get("width"),
                        "layout": yaml_section.get("layout"),
                        "condition": yaml_section.get("condition"),
                        "colSpan": yaml_section.get("colSpan"),
                    }
                    # Remove None values
                    preserved_properties = {k: v for k, v in preserved_properties.items() if v is not None}
                    # Merge: YAML properties first, then agent spec (agent can override if needed)
                    section_spec = {**preserved_properties, **section_spec}
                    self.logger.debug(
                        "Preserved YAML properties for placeholder section '{}': {}",
                        section_id, list(preserved_properties.keys())
                    )
                
                # Validate section specification
                from topaz_agent_kit.core.canvas_structure_validator import CanvasStructureValidator
                validator = CanvasStructureValidator()
                
                section_valid, validation_errors = validator.validate_section(
                    section_spec,
                    manifest,
                    session.state if session else None
                )
                
                if not section_valid:
                    error_msg = f"Section validation failed: {'; '.join(validation_errors)}"
                    self.logger.warning(
                        "Canvas section update failed for section '{}' in session {}: {}",
                        section_id, self._app_session_id, error_msg
                    )
                    return JSONUtils.normalize_for_ui({
                        "success": False,
                        "error": error_msg,
                        "validation_errors": validation_errors,
                    })
                
                # Add/update section
                canvas_structure["sections"][section_id] = section_spec
                
                # Add to order if not already present
                if not any(item.get("id") == section_id for item in canvas_structure["order"]):
                    canvas_structure["order"].append({
                        "type": "section",
                        "id": section_id,
                    })
            
            # Update metadata
            canvas_structure["metadata"]["last_updated_by"] = "agent"
            canvas_structure["metadata"]["last_updated_at"] = datetime.now().isoformat()
            canvas_structure["metadata"]["version"] = canvas_structure["metadata"].get("version", 0) + 1
            
            # Save to database
            success = self._app_session_store.update_canvas_structure(
                self._app_session_id,
                canvas_structure
            )
            
            if success:
                self.logger.info(
                    "Updated canvas section {} (action: {}) for session {}",
                    section_id, action, self._app_session_id
                )
                return JSONUtils.normalize_for_ui({
                    "success": True,
                    "section_id": section_id,
                    "action": action,
                    "message": f"Successfully {action}d section {section_id}",
                })
            else:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": "Failed to update canvas structure",
                })
        except Exception as e:
            self.logger.error("Error updating canvas section: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
            })
    
    async def update_canvas_structure(
        self,
        structure: Dict[str, Any],
    ) -> str:
        """
        Tool: Update canvas structure (layout, sections, controls).
        
        In agent mode you must call this whenever you update canvas state so the user
        can see the content. Structure format: {"sections": {id: {id, title?, width?, controls: [...]}}, "order": [{id, type: "section"}]}. Every section must have an "id" field.
        
        Args:
            structure: Canvas structure with sections (dict), order (list), optional metadata
            
        Returns:
            JSON string with result
        """
        try:
            session = self._app_session_store.get_session(self._app_session_id)
            if not session:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": f"Session {self._app_session_id} not found",
                })
            
            # Validate structure is a dict
            if not isinstance(structure, dict):
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": f"Canvas structure must be a dictionary, got {type(structure).__name__}",
                })
            
            # Ensure required fields exist
            if "sections" not in structure:
                structure["sections"] = {}
            elif isinstance(structure["sections"], list):
                # Convert list of sections to dict format
                # Agent might pass sections as a list: [{"id": "section1", ...}, ...]
                sections_list = structure["sections"]
                structure["sections"] = {}
                for section in sections_list:
                    if isinstance(section, dict):
                        section_id = section.get("id")
                        if section_id:
                            structure["sections"][section_id] = section
                        else:
                            self.logger.warning("Section in list missing 'id' field, skipping")
                    else:
                        self.logger.warning("Invalid section format in list, expected dict, got {}", type(section).__name__)
            
            if "order" not in structure:
                # Generate order from sections if not provided
                structure["order"] = [
                    {"id": section_id, "type": "section"}
                    for section_id in structure["sections"].keys()
                ]
            elif isinstance(structure["order"], list):
                # Ensure order items have correct format
                normalized_order = []
                for item in structure["order"]:
                    if isinstance(item, dict):
                        normalized_order.append(item)
                    elif isinstance(item, str):
                        # If order is just a list of IDs, convert to proper format
                        normalized_order.append({"id": item, "type": "section"})
                    else:
                        self.logger.warning("Invalid order item format, expected dict or str, got {}", type(item).__name__)
                structure["order"] = normalized_order
            
            # Ensure metadata exists
            if "metadata" not in structure:
                structure["metadata"] = {
                    "last_updated_by": "agent",
                    "last_updated_at": datetime.now().isoformat(),
                    "version": 1,
                }
            else:
                structure["metadata"]["last_updated_by"] = "agent"
                structure["metadata"]["last_updated_at"] = datetime.now().isoformat()
                structure["metadata"]["version"] = structure["metadata"].get("version", 0) + 1
            
            # Log incoming structure from agent
            self.logger.info("update_canvas_structure - Received structure with keys: {}", list(structure.keys()))
            self.logger.info("update_canvas_structure - Structure has {} sections, order length: {}", 
                           len(structure.get("sections", {})), 
                           len(structure.get("order", [])))
            try:
                # Log structure details (limit size for very large structures)
                structure_str = json.dumps(structure, default=str, indent=2)
                if len(structure_str) > 3000:
                    self.logger.debug("update_canvas_structure - Structure (truncated): {}...", structure_str[:3000])
                else:
                    self.logger.debug("update_canvas_structure - Structure: {}", structure_str)
            except Exception as e:
                self.logger.debug("update_canvas_structure - Could not serialize structure for logging: {}", e)
            
            # Auto-fix common issues: infer widget types for controls missing 'widget' field
            self.logger.info("update_canvas_structure - Running auto-fix for missing widget types")
            self._auto_fix_canvas_structure(structure)
            
            # Log structure after auto-fix
            self.logger.info("update_canvas_structure - After auto-fix: {} sections", len(structure.get("sections", {})))
            
            # Validate canvas structure
            from topaz_agent_kit.core.canvas_structure_validator import CanvasStructureValidator
            validator = CanvasStructureValidator()
            
            manifest = self._app_config
            structure_valid, validation_errors = validator.validate_canvas_structure(
                structure,
                manifest,
                session.state if session else None
            )
            
            if not structure_valid:
                error_msg = f"Canvas structure validation failed: {'; '.join(validation_errors)}"
                self.logger.warning(
                    "Canvas structure update failed for session {}: {}",
                    self._app_session_id, error_msg
                )
                
                # Check if errors are about missing bindings
                missing_binding_errors = [e for e in validation_errors if "requires a 'binding' field" in e]
                if missing_binding_errors:
                    hint = (
                        "All controls (widgets) must have a 'binding' field that connects to canvas state "
                        "(e.g., 'binding': 'article.title'). Only separator widgets (divider, spacer), "
                        "action widgets (download), and container widgets (accordion, tabs, section) can omit bindings. "
                        "When updating layout, update existing sections rather than creating new ones. "
                        "Use get_canvas_structure() to see the current structure first."
                    )
                else:
                    hint = (
                        "Each control must have a 'widget' field specifying the widget type "
                        "(e.g., 'text', 'markdown_editor', 'select'). See the prompt for widget type examples."
                    )
                
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": error_msg,
                    "validation_errors": validation_errors,
                    "hint": hint,
                })
            
            # Merge with existing structure to preserve properties like width, layout, etc.
            # that the agent might not include in the update
            existing_structure = session.canvas_structure or {
                "sections": {},
                "order": [],
                "metadata": {
                    "last_updated_by": "agent",
                    "last_updated_at": datetime.now().isoformat(),
                    "version": 1,
                },
            }
            
            # Deep merge sections: preserve existing section properties (like width, layout)
            # but update with new properties from agent
            merged_sections = {}
            existing_sections = existing_structure.get("sections", {})
            new_sections = structure.get("sections", {})
            
            # First, copy all existing sections
            for section_id, existing_section in existing_sections.items():
                merged_sections[section_id] = dict(existing_section)  # Copy to avoid mutation
            
            # Then, merge/update with new sections from agent
            for section_id, new_section in new_sections.items():
                if section_id in merged_sections:
                    # Merge: preserve existing properties, update with new ones
                    existing_section = merged_sections[section_id]
                    self.logger.info("  - Updating existing section '{}'", section_id)
                    # Deep merge: preserve width, layout, title, etc. if not in new section
                    merged_section = dict(existing_section)
                    # Update with new section properties (controls, sub-sections, etc.)
                    for key, value in new_section.items():
                        if key == "controls":
                            # Deep merge controls: preserve widgetProps from existing controls
                            existing_controls = merged_section.get("controls", [])
                            new_controls = value
                            
                            # Create a map of existing controls by id/binding for lookup
                            existing_controls_map = {}
                            for ctrl in existing_controls:
                                ctrl_id = ctrl.get("id") or ctrl.get("binding")
                                if ctrl_id:
                                    existing_controls_map[ctrl_id] = ctrl
                            
                            # Merge new controls with existing ones
                            merged_controls = []
                            for new_ctrl in new_controls:
                                merged_ctrl = dict(new_ctrl)
                                # Try to find matching existing control by id or binding
                                ctrl_id = new_ctrl.get("id") or new_ctrl.get("binding")
                                if ctrl_id and ctrl_id in existing_controls_map:
                                    existing_ctrl = existing_controls_map[ctrl_id]
                                    # Preserve widgetProps from existing control if not provided in new control
                                    if "widgetProps" not in merged_ctrl and "widgetProps" in existing_ctrl:
                                        merged_ctrl["widgetProps"] = dict(existing_ctrl["widgetProps"])
                                    # Deep merge widgetProps if both exist
                                    elif "widgetProps" in merged_ctrl and "widgetProps" in existing_ctrl:
                                        merged_widget_props = dict(existing_ctrl["widgetProps"])
                                        new_widget_props = merged_ctrl["widgetProps"]
                                        
                                        # Special handling for options: preserve existing options if new ones are empty/missing
                                        if "options" in existing_ctrl.get("widgetProps", {}):
                                            existing_options = existing_ctrl["widgetProps"].get("options", [])
                                            new_options = new_widget_props.get("options", [])
                                            # If new options are empty/missing but existing ones exist, preserve existing
                                            if (not new_options or len(new_options) == 0) and existing_options:
                                                merged_widget_props["options"] = existing_options
                                            # Otherwise, use new options if provided
                                            elif new_options and len(new_options) > 0:
                                                merged_widget_props["options"] = new_options
                                        
                                        # Update with other widgetProps from new control
                                        merged_widget_props.update(new_widget_props)
                                        # Restore preserved options if we kept them
                                        if "options" in existing_ctrl.get("widgetProps", {}) and \
                                           (not new_widget_props.get("options") or len(new_widget_props.get("options", [])) == 0) and \
                                           existing_ctrl["widgetProps"].get("options"):
                                            merged_widget_props["options"] = existing_ctrl["widgetProps"]["options"]
                                        merged_ctrl["widgetProps"] = merged_widget_props
                                merged_controls.append(merged_ctrl)
                            
                            merged_section["controls"] = merged_controls
                        elif key == "sections":
                            # Sub-sections: replace entirely
                            merged_section["sections"] = value
                        else:
                            # Other properties: update (agent can override width, layout, etc.)
                            merged_section[key] = value
                    merged_sections[section_id] = merged_section
                else:
                    # New section: add it (but warn if it has controls without bindings)
                    self.logger.info("  - Adding new section '{}'", section_id)
                    new_controls = new_section.get("controls", [])
                    controls_without_bindings = [
                        c.get("id", f"index_{i}") 
                        for i, c in enumerate(new_controls) 
                        if not c.get("binding") and c.get("widget") not in ["divider", "spacer"]
                    ]
                    if controls_without_bindings:
                        self.logger.warning(
                            "New section '{}' has controls without bindings: {}. "
                            "These controls will not connect to canvas state. "
                            "Consider updating existing sections instead of creating new ones.",
                            section_id, controls_without_bindings
                        )
                    merged_sections[section_id] = dict(new_section)
            
            # Use agent's order if provided, otherwise preserve existing order
            merged_order = structure.get("order") if structure.get("order") else existing_structure.get("order", [])
            
            # Create merged structure
            merged_structure = {
                "sections": merged_sections,
                "order": merged_order,
                "metadata": structure.get("metadata", existing_structure.get("metadata", {
                    "last_updated_by": "agent",
                    "last_updated_at": datetime.now().isoformat(),
                    "version": 1,
                })),
            }
            
            # Log final structure before saving
            self.logger.info("update_canvas_structure - Final structure to save:")
            self.logger.info("  - Sections: {}", list(merged_structure.get("sections", {}).keys()))
            self.logger.info("  - Order: {}", [item.get("id") for item in merged_structure.get("order", [])])
            
            # Log detailed section contents
            for section_id, section in merged_structure.get("sections", {}).items():
                controls = section.get("controls", [])
                sub_sections = section.get("sections", [])
                width = section.get("width", "not set")
                self.logger.info("  - Section '{}': {} controls, {} sub-sections, width: {}", 
                               section_id, len(controls), len(sub_sections), width)
                for idx, control in enumerate(controls):
                    self.logger.debug("    Control {}: id={}, widget={}, binding={}", 
                                     idx, 
                                     control.get("id", "unknown"),
                                     control.get("widget", "unknown"),
                                     control.get("binding", "none"))
            
            # Save merged structure to database
            success = self._app_session_store.update_canvas_structure(
                self._app_session_id,
                merged_structure
            )
            
            if success:
                self.logger.info(
                    "Updated canvas structure for session {} - Saved successfully",
                    self._app_session_id
                )
                return JSONUtils.normalize_for_ui({
                    "success": True,
                    "message": "Successfully updated canvas structure",
                })
            else:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": "Failed to update canvas structure",
                })
        except Exception as e:
            self.logger.error("Error updating canvas structure: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
            })
    
    def _build_default_canvas_structure_from_state(self) -> Optional[Dict[str, Any]]:
        """
        Build a minimal canvas structure from the app's default_state so the UI
        has a layout to display state when the agent only called update_canvas()
        and never called update_canvas_structure(). Used only in agent mode when
        session has no canvas structure yet.

        Returns:
            Canvas structure dict (sections + order + metadata) or None if nothing to build
        """
        default_state = (self._app_config or {}).get("default_state") or {}
        if not default_state or not isinstance(default_state, dict):
            return None
        # Widget inference: same field-name -> widget mapping as _auto_fix
        field_to_widget = {
            "body": "markdown_editor",
            "content": "markdown_editor",
            "description": "textarea",
            "summary": "markdown_viewer",
            "title": "text",
            "name": "text",
            "author": "text",
            "category": "select",
            "type": "select",
            "status": "select",
            "tags": "tags_input",
            "date": "date",
            "publish_date": "date",
            "created_at": "date",
            "featured": "toggle",
            "enabled": "toggle",
            "active": "toggle",
        }
        widget_defaults = (self._app_config or {}).get("widget_defaults") or {}
        select_options_defaults = (widget_defaults.get("select_options") or {})
        canvas_config = (self._app_config or {}).get("canvas") or {}
        full_screen_widgets = canvas_config.get("fullScreenWidgets") or []
        if not isinstance(full_screen_widgets, list):
            full_screen_widgets = []
        sections = {}
        order = []
        for section_id, section_state in default_state.items():
            if not isinstance(section_state, dict):
                continue
            controls = []
            # Any section whose id is in fullScreenWidgets gets one control: widget=section_id, binding=section_id
            if section_id in full_screen_widgets:
                widget_props = {}
                if section_id == "map":
                    widget_props = {"height": "100%", "tileLayer": "openstreetmap"}
                elif section_id == "google_map":
                    widget_props = {"height": "100%", "showControls": True}
                controls = [
                    {
                        "id": section_id,
                        "binding": section_id,
                        "widget": section_id,
                        "label": "",
                        "fullScreen": True,
                        "widgetProps": widget_props,
                    }
                ]
            else:
                for field_name, field_value in section_state.items():
                    binding = f"{section_id}.{field_name}"
                    widget = field_to_widget.get(field_name.lower())
                    if not widget:
                        if isinstance(field_value, bool):
                            widget = "toggle"
                        elif isinstance(field_value, list):
                            widget = "tags_input"
                        elif isinstance(field_value, (int, float)):
                            widget = "number"
                        else:
                            widget = "text"
                    control = {
                        "id": field_name,
                        "binding": binding,
                        "widget": widget,
                        "label": field_name.replace("_", " ").title(),
                    }
                    if widget == "select" and select_options_defaults:
                        opts = select_options_defaults.get(field_name) or select_options_defaults.get(field_name.lower())
                        if opts:
                            control["widgetProps"] = {"options": opts}
                    controls.append(control)
            if not controls:
                continue
            is_full_screen_section = section_id in full_screen_widgets
            section_title = "" if is_full_screen_section else section_id.replace("_", " ").title()
            sections[section_id] = {
                "id": section_id,
                "title": section_title,
                "showTitle": not is_full_screen_section,
                "width": "full",
                "layout": {"type": "stack", "gap": 4},
                "controls": controls,
            }
            order.append({"id": section_id, "type": "section"})
        if not sections:
            return None
        structure = {
            "sections": sections,
            "order": order,
            "metadata": {
                "last_updated_by": "agent",
                "last_updated_at": datetime.now().isoformat(),
                "version": 1,
            },
        }
        self._auto_fix_canvas_structure(structure)
        return structure
    
    def _auto_fix_canvas_structure(self, structure: Dict[str, Any]) -> None:
        """
        Auto-fix common issues in canvas structure:
        - Infer widget types for controls missing 'widget' field based on binding path or other hints
        
        Args:
            structure: Canvas structure to fix in-place
        """
        sections = structure.get("sections", {})
        
        # Get widget inference rules from app config, with sensible defaults
        # App can override via app manifest: widget_inference: { "field_name": "widget_type", ... }
        default_inference_rules = {
            # Body/content fields -> markdown_editor
            "body": "markdown_editor",
            "content": "markdown_editor",
            "description": "textarea",
            "summary": "markdown_viewer",  # Usually read-only summary
            # Title/name fields -> text
            "title": "text",
            "name": "text",
            "author": "text",
            # Category/enum fields -> select
            "category": "select",
            "type": "select",
            "status": "select",
            # Tags -> tags_input
            "tags": "tags_input",
            # Date fields -> date
            "date": "date",
            "publish_date": "date",
            "created_at": "date",
            # Boolean fields -> toggle
            "featured": "toggle",
            "enabled": "toggle",
            "active": "toggle",
        }
        
        # Safely get widget inference rules from app config
        app_inference_rules = {}
        if self._app_config and isinstance(self._app_config, dict):
            app_inference_config = self._app_config.get("widget_inference")
            if isinstance(app_inference_config, dict):
                app_inference_rules = app_inference_config
        widget_inference_rules = {**default_inference_rules, **app_inference_rules}
        
        # Get select widget default options from app config
        # App can configure via app manifest: widget_defaults: { select_options: { "binding_pattern": [options], ... } }
        # Example: widget_defaults: { select_options: { "category": [{"value": "tech", "label": "Tech"}, ...] } }
        select_options_defaults = {}
        if self._app_config and isinstance(self._app_config, dict):
            widget_defaults_config = self._app_config.get("widget_defaults")
            if isinstance(widget_defaults_config, dict):
                select_options_config = widget_defaults_config.get("select_options")
                if isinstance(select_options_config, dict):
                    select_options_defaults = select_options_config
        
        def infer_widget_type(control: Dict[str, Any]) -> Optional[str]:
            """Infer widget type from control properties"""
            # Check binding path for hints
            binding = control.get("binding", "")
            if binding:
                # Extract last part of binding path (e.g., "article.body" -> "body")
                binding_parts = binding.split(".")
                if binding_parts:
                    last_part = binding_parts[-1].lower()
                    if last_part in widget_inference_rules:
                        return widget_inference_rules[last_part]
            
            # Check control ID for hints
            control_id = control.get("id", "").lower()
            if control_id:
                for key, widget_type in widget_inference_rules.items():
                    if key in control_id:
                        return widget_type
            
            # Check if control has markdown-related properties
            if control.get("markdown") or "markdown" in str(control.get("type", "")).lower():
                return "markdown_editor"
            
            # Default fallback based on common patterns
            return None
        
        def get_default_select_options(binding: str, control_id: str) -> Optional[List[Dict[str, str]]]:
            """Get default options for select widget from app config"""
            if not select_options_defaults:
                return None
            
            # Try to match by binding path last part (e.g., "article.category" -> "category")
            binding_lower = binding.lower()
            if binding:
                binding_parts = binding.split(".")
                if binding_parts:
                    last_part = binding_parts[-1].lower()
                    if last_part in select_options_defaults:
                        return select_options_defaults[last_part]
            
            # Try to match by control ID
            control_id_lower = control_id.lower()
            if control_id_lower:
                for pattern, options in select_options_defaults.items():
                    if pattern.lower() in control_id_lower:
                        return options
            
            # Try exact binding match
            if binding_lower in select_options_defaults:
                return select_options_defaults[binding_lower]
            
            return None
        
        def fix_section(section: Dict[str, Any]) -> None:
            """Recursively fix controls in a section"""
            controls = section.get("controls", [])
            section_id = section.get("id", "").lower()
            
            for control in controls:
                if isinstance(control, dict):
                    widget_type = control.get("widget", "").strip()
                    control_id = control.get("id", "").lower()
                    control_label = str(control.get("label", "")).lower()
                    binding = control.get("binding", "")
                    
                    # Fix empty widget field (common issue - agent creates control but forgets widget type)
                    if not widget_type:
                        # Check if this should be a download widget
                        # Download widgets: no binding, and ID/label suggests download/export
                        is_download_hint = (
                            not binding and (
                                "download" in control_id or "download" in control_label or
                                "export" in control_id or "export" in control_label
                            )
                        )
                        
                        # Also check if it's in metadata section and has no binding (common pattern)
                        is_metadata_no_binding = (
                            "metadata" in section_id and not binding
                        )
                        
                        if is_download_hint or is_metadata_no_binding:
                            control["widget"] = "download"
                            self.logger.info(
                                "Auto-fixed empty widget field: set to 'download' for control '{}' in section '{}'",
                                control.get("id", "unknown"),
                                section.get("id", "unknown")
                            )
                        else:
                            # Try to infer widget type from other hints
                            inferred_type = infer_widget_type(control)
                            if inferred_type:
                                control["widget"] = inferred_type
                                self.logger.debug(
                                    "Auto-inferred widget type '{}' for control '{}' with binding '{}'",
                                    inferred_type,
                                    control.get("id", "unknown"),
                                    control.get("binding", "none")
                                )
                            else:
                                # Log warning for controls that still have no widget type
                                self.logger.warning(
                                    "Control '{}' in section '{}' has no widget type and could not be inferred. "
                                    "Please specify widget type explicitly (e.g., 'text', 'download', 'divider').",
                                    control.get("id", "unknown"),
                                    section.get("id", "unknown")
                                )
                    
                    # Fix missing options for select widgets using app config
                    widget_type = control.get("widget", "")
                    binding = control.get("binding", "")
                    control_id = control.get("id", "")
                    
                    if widget_type == "select":
                        widget_props = control.setdefault("widgetProps", {})
                        if not widget_props.get("options"):
                            # Try to get default options from app config
                            default_options = get_default_select_options(binding, control_id)
                            if default_options:
                                widget_props["options"] = default_options
                                self.logger.info(
                                    "Auto-added default options from app config for select widget '{}' with binding '{}'",
                                    control_id or "unknown",
                                    binding
                                )
                            else:
                                # Log warning that select widget needs options but none configured
                                self.logger.warning(
                                    "Select widget '{}' with binding '{}' has no options. "
                                    "Configure via app manifest: widget_defaults.select_options",
                                    control_id or "unknown",
                                    binding
                                )
            
            # Fix sub-sections recursively
            sub_sections = section.get("sections", [])
            for sub_section in sub_sections:
                if isinstance(sub_section, dict):
                    fix_section(sub_section)
        
        # Fix all sections
        for section_id, section in sections.items():
            if isinstance(section, dict):
                fix_section(section)
    
    async def update_canvas_with_a2ui(
        self,
        a2ui_spec: Dict[str, Any],
        surface_id: str = "main",
    ) -> str:
        """
        Tool: Update canvas using A2UI protocol specification.
        
        This tool allows agents to generate UI using the A2UI protocol,
        which is then converted to our internal canvas structure format.
        
        Args:
            a2ui_spec: A2UI specification (SurfaceUpdate or updateComponents message)
            surface_id: Surface ID (default: "main")
            
        Returns:
            JSON string with result
        """
        try:
            session = self._app_session_store.get_session(self._app_session_id)
            if not session:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": f"Session {self._app_session_id} not found",
                })
            
            # A2UI converter is required (in main dependencies)
            if self._a2ui_converter is None:
                self.logger.error("A2UI converter not initialized")
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": "A2UI converter not initialized",
                })
            
            # Log incoming A2UI spec from agent
            self.logger.info("update_canvas_with_a2ui - Received A2UI spec with keys: {}", list(a2ui_spec.keys()))
            try:
                # Pretty print A2UI spec for debugging (limit size)
                a2ui_spec_str = json.dumps(a2ui_spec, default=str, indent=2)
                if len(a2ui_spec_str) > 2000:
                    self.logger.debug("update_canvas_with_a2ui - A2UI spec (truncated): {}...", a2ui_spec_str[:2000])
                else:
                    self.logger.debug("update_canvas_with_a2ui - A2UI spec: {}", a2ui_spec_str)
            except Exception as e:
                self.logger.debug("update_canvas_with_a2ui - Could not serialize A2UI spec for logging: {}", e)
            
            # Convert A2UI spec to canvas structure
            self.logger.info("update_canvas_with_a2ui - Converting A2UI spec to canvas structure for surface '{}'", surface_id)
            canvas_structure = self._a2ui_converter.a2ui_to_canvas_structure(
                a2ui_spec,
                surface_id
            )
            
            # Log converted structure
            self.logger.info("update_canvas_with_a2ui - Converted structure: {} sections, order: {}", 
                           len(canvas_structure.get("sections", {})), 
                           canvas_structure.get("order", []))
            
            # Merge with existing structure
            existing_structure = session.canvas_structure or {
                "sections": {},
                "order": [],
                "metadata": {
                    "last_updated_by": "agent",
                    "last_updated_at": datetime.now().isoformat(),
                    "version": 1,
                },
            }
            
            # Merge sections
            merged_sections = {**existing_structure.get("sections", {})}
            merged_sections.update(canvas_structure["sections"])
            
            # Merge order (A2UI order takes precedence for the surface)
            merged_order = [
                item for item in existing_structure.get("order", [])
                if item.get("id") != surface_id
            ] + canvas_structure["order"]
            
            # Update structure
            merged_structure = {
                "sections": merged_sections,
                "order": merged_order,
                "metadata": {
                    "last_updated_by": "agent",
                    "last_updated_at": datetime.now().isoformat(),
                    "version": (existing_structure.get("metadata", {}).get("version", 0) + 1),
                },
            }
            
            # Log merged structure before saving
            self.logger.info("update_canvas_with_a2ui - Merged structure:")
            self.logger.info("  - Sections: {}", list(merged_sections.keys()))
            self.logger.info("  - Order: {}", [item.get("id") for item in merged_order])
            
            # Log detailed merged section contents
            for section_id, section in merged_sections.items():
                controls = section.get("controls", [])
                sub_sections = section.get("sections", [])
                self.logger.info("  - Merged Section '{}': {} controls, {} sub-sections", 
                               section_id, len(controls), len(sub_sections))
                for idx, control in enumerate(controls):
                    self.logger.debug("    Merged Control {}: id={}, widget={}, binding={}", 
                                     idx, 
                                     control.get("id", "unknown"),
                                     control.get("widget", "unknown"),
                                     control.get("binding", "none"))
            
            # Save to database
            success = self._app_session_store.update_canvas_structure(
                self._app_session_id,
                merged_structure
            )
            
            if success:
                self.logger.info(
                    "Updated canvas structure with A2UI spec for session {} - Saved successfully",
                    self._app_session_id
                )
                return JSONUtils.normalize_for_ui({
                    "success": True,
                    "message": "Successfully updated canvas structure with A2UI specification",
                    "surface_id": surface_id,
                })
            else:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": "Failed to update canvas structure",
                })
        except ImportError as e:
            self.logger.error("A2UI support not available: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": "A2UI support requires a2ui-pydantic package. Please install it.",
            })
        except Exception as e:
            self.logger.error("Error updating canvas with A2UI: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
            })
    
    def _parse_path(self, path: str) -> List[str]:
        """
        Parse path string into list of keys, supporting both dot notation and bracket notation.
        
        Examples:
            "article.title" -> ["article", "title"]
            "items[0].name" -> ["items", "0", "name"]
            "items[0][1]" -> ["items", "0", "1"]
        
        Args:
            path: Path string (e.g., "article.title" or "items[0].name")
            
        Returns:
            List of keys (array indices as strings)
        """
        keys = []
        current = ""
        i = 0
        
        while i < len(path):
            char = path[i]
            
            if char == '.':
                if current:
                    keys.append(current)
                    current = ""
            elif char == '[':
                if current:
                    keys.append(current)
                    current = ""
                # Find closing bracket
                i += 1
                bracket_content = ""
                while i < len(path) and path[i] != ']':
                    bracket_content += path[i]
                    i += 1
                if bracket_content:
                    keys.append(bracket_content)
            elif char == ']':
                # Skip closing bracket (already handled)
                pass
            else:
                current += char
            
            i += 1
        
        if current:
            keys.append(current)
        
        return keys
    
    def _get_value_at_path(self, obj: Dict[str, Any], path: str) -> Any:
        """
        Get value from nested dict/array using path notation.
        
        Supports:
        - Dot notation: "article.title"
        - Bracket notation: "items[0].name"
        - Mixed: "items[0].metadata.tags[1]"
        """
        keys = self._parse_path(path)
        current = obj
        
        for key in keys:
            if isinstance(current, dict):
                if key in current:
                    current = current[key]
                else:
                    return None
            elif isinstance(current, list):
                try:
                    idx = int(key)
                    if 0 <= idx < len(current):
                        current = current[idx]
                    else:
                        return None
                except (ValueError, TypeError):
                    return None
            else:
                return None
        
        return current
    
    def _build_patch_from_path(self, path: str, value: Any) -> Dict[str, Any]:
        """
        Build nested dict patch from path and value.
        
        Supports:
        - Dot notation: "article.title"
        - Bracket notation: "items[0].name"
        - Mixed: "items[0].metadata.tags[1]"
        """
        keys = self._parse_path(path)
        patch = {}
        current = patch
        
        # Build nested structure for all keys except the last
        for i, key in enumerate(keys[:-1]):
            # Check if next key is numeric (array index)
            next_key = keys[i + 1]
            try:
                int(next_key)
                # Next is array index, but we're building dict structure
                # Arrays are represented as dicts with numeric string keys
                current[key] = {}
                current = current[key]
            except ValueError:
                # Next is object key
                current[key] = {}
                current = current[key]
        
        # Set the final value
        if keys:
            current[keys[-1]] = value
        
        return patch
    
    # === CASE-SPECIFIC TOOLS ===
    
    async def get_case_context(self) -> str:
        """
        Tool: Get case context (case_id, case status, exception summary).
        
        Returns:
            JSON string with case context information
        """
        try:
            if not hasattr(self, '_case_id') or not self._case_id:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": "No case_id associated with this session",
                })
            
            case_id = self._case_id
            
            # Get case data
            from topaz_agent_kit.core.case_manager import CaseManager
            from topaz_agent_kit.core.chat_database import ChatDatabase
            from topaz_agent_kit.core.pipeline_loader import PipelineLoader
            
            pipeline_loader = PipelineLoader(Path(self._project_dir))
            pipeline_config, _ = pipeline_loader.load()
            from topaz_agent_kit.utils.path_resolver import resolve_path_if_relative
            chatdb_path = pipeline_config.get("chatdb_path", "./data/chat.db")
            chatdb_path = resolve_path_if_relative(chatdb_path, Path(self._project_dir))
            
            database = ChatDatabase(chatdb_path)
            case_manager = CaseManager(database)
            case = case_manager.get_case(case_id)
            
            if not case:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": f"Case {case_id} not found",
                })
            
            # Extract exception summary from case data (generic - no hardcoded agent names)
            case_data = case.get("case_data", {})
            
            # Try to find exception-related data generically
            # Look for common patterns: exception_detector, anomaly_detector, etc.
            exception_info = {}
            for agent_id, agent_output in case_data.items():
                if not agent_id.startswith("_") and isinstance(agent_output, dict):
                    # Check for common exception fields
                    if "has_exceptions" in agent_output or "exception_count" in agent_output:
                        exception_info["has_exceptions"] = agent_output.get("has_exceptions", False)
                        exception_info["exception_count"] = agent_output.get("exception_count", 0)
                        exception_info["exception_types"] = agent_output.get("exception_types", [])
                        break
                    elif "anomaly_detected" in agent_output:
                        exception_info["has_exceptions"] = agent_output.get("anomaly_detected", False)
                        exception_info["exception_count"] = 1 if exception_info["has_exceptions"] else 0
                        exception_info["exception_types"] = [agent_output.get("anomaly_type", "anomaly")] if exception_info["has_exceptions"] else []
                        break
            
            context = {
                "case_id": case_id,
                "status": case.get("status"),
                "pipeline_id": case.get("pipeline_id"),
                "has_exceptions": exception_info.get("has_exceptions", False),
                "exception_count": exception_info.get("exception_count", 0),
                "exception_types": exception_info.get("exception_types", []),
            }
            
            return JSONUtils.normalize_for_ui({
                "success": True,
                "context": context,
            })
        except Exception as e:
            self.logger.error("Error getting case context: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
            })
    
    async def submit_resolution(self, decision: str, notes: Optional[str] = None) -> str:
        """
        Tool: Submit resolution decision for this case.
        
        Args:
            decision: Selected decision value (e.g., "approve_override", "request_evidence", "reject")
            notes: Optional notes/justification
            
        Returns:
            JSON string with result
        """
        try:
            if not hasattr(self, '_case_id') or not self._case_id:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": "No case_id associated with this session",
                })
            
            case_id = self._case_id
            
            # Get current canvas state for audit trail
            session = self._app_session_store.get_session(self._app_session_id)
            canvas_state = session.state if session else {}
            
            # Call resolve-case API endpoint
            import httpx
            
            # Get API base URL from project config
            from topaz_agent_kit.core.pipeline_loader import PipelineLoader
            pipeline_loader = PipelineLoader(Path(self._project_dir))
            pipeline_config, _ = pipeline_loader.load()
            api_url = "http://localhost:8090"  # Default, could be configurable
            
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"{api_url}/api/app/resolve-case",
                    json={
                        "case_id": case_id,
                        "app_session_id": self._app_session_id,
                        "decision": decision,
                        "notes": notes or "",
                        "canvas_state": canvas_state,
                    },
                    timeout=30.0
                )
                
                if response.status_code == 200:
                    result = response.json()
                    # Note: Canvas state update should be done via case_resolution config path
                    # This is a generic tool, so we don't hardcode the path
                    
                    return JSONUtils.normalize_for_ui({
                        "success": True,
                        "message": "Resolution submitted successfully",
                        "decision": decision,
                    })
                else:
                    error_data = response.json() if response.headers.get("content-type", "").startswith("application/json") else {"error": response.text}
                    return JSONUtils.normalize_for_ui({
                        "success": False,
                        "error": error_data.get("error", "Failed to submit resolution"),
                    })
        except Exception as e:
            self.logger.error("Error submitting resolution: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
            })
    