"""
Shared tools for orchestration assistants.

This module provides common tool methods that can be used by Assistant,
OperationsAssistant, and AppAssistant classes to avoid code duplication.
"""

from datetime import datetime
from typing import Any, Dict, Optional, List
from contextvars import ContextVar
import json

from topaz_agent_kit.utils.json_utils import JSONUtils
from topaz_agent_kit.utils.logger import Logger
from topaz_agent_kit.orchestration.widget_collector import (
    WidgetCollector,
    get_widget_collector,
    set_widget_collector,
)

# Import A2UI converter (required dependency)
from topaz_agent_kit.utils.a2ui_converter import A2UIConverter, A2UI_COMPONENT_TO_WIDGET_MAP

# Context variable for client IP (set by FastAPI endpoint, read by tool)
_client_ip: ContextVar[Optional[str]] = ContextVar('client_ip', default=None)

# Context variable for browser location (set by FastAPI endpoint, preferred over IP)
_browser_location: ContextVar[Optional[Dict[str, Any]]] = ContextVar('browser_location', default=None)


class AssistantToolsMixin:
    """
    Mixin class providing shared tools for orchestration assistants.
    
    This mixin provides common tool methods that can be used by Assistant,
    OperationsAssistant, and AppAssistant classes.
    """
    
    async def get_current_datetime(
        self,
        timezone: str = "UTC",
        format: str = "iso",
    ):
        """
        Tool: Get the current date and time.
        
        This tool provides accurate current date and time information. Use this when:
        - User asks "what date is today", "what's the current date", "what time is it"
        - User mentions relative dates like "yesterday", "today", "tomorrow" and you need to calculate actual dates
        - User provides dates like "6th feb 2026" and you need to verify or convert them
        - You need to calculate date differences or relative dates
        
        Args:
            timezone: Timezone name (default: "UTC"). Examples: "UTC", "America/New_York", "Europe/London"
            format: Output format (default: "iso"). Options: "iso" (ISO 8601), "readable" (human-readable)
        
        Returns:
            JSON string with:
                - datetime_iso: ISO 8601 format (e.g., "2026-02-07T12:30:45")
                - date: Date only (YYYY-MM-DD format)
                - time: Time only (HH:MM:SS format)
                - timestamp: Unix timestamp
                - readable: Human-readable format (e.g., "February 7, 2026, 12:30:45 PM")
                - timezone: The timezone used
                - day_of_week: Day name (e.g., "Friday")
                - day_of_year: Day of year (1-366)
        """
        logger = getattr(self, 'logger', None) or getattr(self, '_logger', None)
        if not logger:
            logger = Logger("AssistantTools")
        
        logger.input("get_current_datetime INPUT: timezone={}, format={}", timezone, format)
        
        try:
            from datetime import timezone as dt_timezone
            
            # Get current UTC time
            now_utc = datetime.now(dt_timezone.utc)
            
            # Convert to requested timezone if specified
            if timezone and timezone != "UTC":
                try:
                    import pytz
                    tz = pytz.timezone(timezone)
                    now = now_utc.astimezone(tz)
                except Exception as e:
                    logger.warning("Invalid timezone '{}', using UTC: {}", timezone, e)
                    now = now_utc
                    timezone = "UTC"
            else:
                now = now_utc
                timezone = "UTC"
            
            result = {
                "datetime_iso": now.strftime("%Y-%m-%dT%H:%M:%S"),
                "date": now.strftime("%Y-%m-%d"),
                "time": now.strftime("%H:%M:%S"),
                "timestamp": int(now.timestamp()),
                "readable": now.strftime("%B %d, %Y, %I:%M:%S %p"),
                "timezone": timezone,
                "day_of_week": now.strftime("%A"),
                "day_of_year": now.timetuple().tm_yday,
            }
            
            logger.output("get_current_datetime OUTPUT: {}", result)
            # Return dict for Assistant class, JSON string for others
            # Check if class has _logger (Assistant) vs logger (others)
            if hasattr(self, '_logger'):
                return result  # Assistant returns dict
            else:
                return JSONUtils.normalize_for_ui(result)  # Others return JSON string
        except Exception as e:
            logger.error("get_current_datetime failed: {}", e)
            # Fallback to basic datetime
            now = datetime.now()
            result = {
                "datetime_iso": now.strftime("%Y-%m-%dT%H:%M:%S"),
                "date": now.strftime("%Y-%m-%d"),
                "time": now.strftime("%H:%M:%S"),
                "timestamp": int(now.timestamp()),
                "readable": now.strftime("%B %d, %Y, %I:%M:%S %p"),
                "timezone": "local",
                "day_of_week": now.strftime("%A"),
                "day_of_year": now.timetuple().tm_yday,
            }
            return JSONUtils.normalize_for_ui(result)
    
    async def insert_widget(
        self,
        widget_type: str,
        data: Any,
        props: Optional[Any] = None,
        binding: Optional[str] = None,
    ) -> str:
        """
        Tool: Insert a widget into the chat response.
        
        Use this tool when you want to display structured data, forms, tables,
        images, or other interactive UI components in your response.
        
        Args:
            widget_type: Type of widget to insert. Available types:
                - "table_view": Display tabular data (array of objects)
                - "table_editor": Editable table
                - "form": Interactive form for user input
                - "image_viewer": Display images (URLs or base64)
                - "code_viewer": Display code with syntax highlighting
                - "json_viewer": Display JSON data
                - "markdown_viewer": Display markdown content
                - "cards_grid": Display cards in a grid
                - "list_view": Display list of items
                - Chart widgets: "line_chart", "bar_chart", "pie_chart", "area_chart", etc.
                - See docs/widget_properties_reference.md for full list
            
            data: Widget data. Format depends on widget_type:
                  - Tables: array of objects (e.g., [{"name": "John", "age": 30}])
                  - Forms: form field definitions
                  - Viewers: content to display (string, URL, etc.)
                  - Pie/Donut charts: {"labels": ["A", "B"], "data": [10, 20]} OR {"A": 10, "B": 20}
                    (NOT an array like [{"label": "A", "value": 10}])
                  - Line/Bar/Area charts: {"labels": ["Jan", "Feb"], "datasets": [{"label": "Series", "data": [10, 20]}]}
                  - Gauge: {"value": 75, "min": 0, "max": 100} OR just 75
            
            props: Optional widget-specific properties (e.g., headers for tables,
                   language for code_viewer, columns for cards_grid, title for charts)
            
            binding: Optional state binding path.
                     For app assistant: bind to canvas state (e.g., "article.title").
                     For operations assistant: bind to case state (e.g., "case.notes").
                     Leave empty for isolated widget state.
        
        Returns:
            Confirmation message indicating widget will be included in response
        
        Examples:
            # Display a table
            insert_widget(
                widget_type="table_view",
                data=[{"name": "John", "age": 30}, {"name": "Jane", "age": 25}],
                props={"headers": ["Name", "Age"]}
            )
            
            # Display a pie chart (correct format)
            insert_widget(
                widget_type="pie_chart",
                data={"labels": ["Category A", "Category B", "Category C"], "data": [40, 30, 20]},
                props={"title": "Distribution", "show_percentages": True}
            )
            # OR use key-value format:
            # data={"Category A": 40, "Category B": 30, "Category C": 20}
            
            # Display an image
            insert_widget(
                widget_type="image_viewer",
                data="https://example.com/image.jpg",
                props={"alt": "Example image"}
            )
        """
        logger = getattr(self, 'logger', None) or getattr(self, '_logger', None)
        if not logger:
            logger = Logger("AssistantTools")
        
        # Get assistant config to determine widget limit
        assistant_config = getattr(self, '_assistant_config', {})
        widget_limit = assistant_config.get("widget_limit", 10)
        
        # Log widget creation with detailed data information
        try:
            # Serialize data for logging (limit size to avoid huge logs)
            if isinstance(data, dict):
                data_preview = json.dumps(data, default=str)[:500]  # Limit to 500 chars
                if len(json.dumps(data, default=str)) > 500:
                    data_preview += "... (truncated)"
                logger.input("insert_widget tool called: widget_type={}, data_type=dict, data_keys={}, data_preview={}", 
                            widget_type, list(data.keys()), data_preview)
            elif isinstance(data, list):
                data_preview = json.dumps(data, default=str)[:500]  # Limit to 500 chars
                if len(json.dumps(data, default=str)) > 500:
                    data_preview += "... (truncated)"
                logger.input("insert_widget tool called: widget_type={}, data_type=list, data_length={}, data_preview={}", 
                            widget_type, len(data), data_preview)
            else:
                data_str = str(data)[:500]  # Limit to 500 chars
                if len(str(data)) > 500:
                    data_str += "... (truncated)"
                logger.input("insert_widget tool called: widget_type={}, data_type={}, data_preview={}", 
                            widget_type, type(data).__name__, data_str)
        except Exception as e:
            # Fallback if serialization fails
            logger.input("insert_widget tool called: widget_type={}, data_type={}, serialization_error={}", 
                        widget_type, type(data).__name__, str(e))
        
        # Also log props if provided
        if props:
            try:
                props_preview = json.dumps(props, default=str)[:200]  # Limit to 200 chars
                if len(json.dumps(props, default=str)) > 200:
                    props_preview += "... (truncated)"
                logger.input("insert_widget props: {}", props_preview)
            except Exception:
                logger.input("insert_widget props: {}", str(props)[:200])
        
        # Transform data format for pie_chart if needed
        # PieChartWidget expects: {"labels": [...], "data": [...]} or {"Label": value, ...}
        # But assistants sometimes send: [{"label": "...", "value": ...}]
        transformed_data = data
        if widget_type == "pie_chart" and isinstance(data, list) and len(data) > 0:
            # Check if it's the incorrect array format
            first_item = data[0]
            if isinstance(first_item, dict) and ("label" in first_item or "name" in first_item) and ("value" in first_item or "count" in first_item):
                # Transform array format to correct format
                labels = []
                values = []
                for item in data:
                    label_key = "label" if "label" in item else "name"
                    value_key = "value" if "value" in item else "count"
                    if label_key in item and value_key in item:
                        labels.append(str(item[label_key]))
                        try:
                            values.append(float(item[value_key]))
                        except (ValueError, TypeError):
                            logger.warning("Invalid value in pie_chart data item: {}", item)
                            values.append(0)
                
                transformed_data = {"labels": labels, "data": values}
                logger.info("Transformed pie_chart data from array format to labels/data format: {} items", len(labels))
        
        collector = get_widget_collector()
        if not collector:
            # Create collector if it doesn't exist (shouldn't happen in normal flow)
            logger.warning("WidgetCollector not found in context, creating new one")
            collector = WidgetCollector()
            collector.set_max_widgets(widget_limit)
            set_widget_collector(collector)
        
        try:
            # Add widget to collection
            collector.add_widget(
                widget_type=widget_type,
                data=transformed_data,
                props=props,
                binding=binding,
            )
            
            result = f"Widget '{widget_type}' will be included in the response."
            logger.output("insert_widget OUTPUT: widget_type={}, total_widgets={}, message={}", 
                         widget_type, len(collector.widgets), result)
            return result
        
        except ValueError as e:
            # Widget limit exceeded
            logger.warning("Widget limit exceeded: {}", e)
            error_msg = f"Error: {str(e)}. Widget not added."
            logger.output("insert_widget OUTPUT: widget_type={}, error={}", widget_type, str(e))
            return error_msg
    
    async def send_a2ui_message(
        self,
        a2ui_spec: Dict[str, Any],
    ) -> str:
        """
        Tool: Send an A2UI protocol message for chat rendering.
        
        This tool allows agents to generate UI using the A2UI protocol,
        which is then converted to widgets and rendered in chat.
        
        Use this when you want to generate complex, structured UI layouts
        in chat responses using the A2UI protocol specification.
        
        Args:
            a2ui_spec: A2UI specification (SurfaceUpdate or updateComponents message)
                - Can be a complete A2UI message: {"updateComponents": {...}}
                - Or just the components array: {"components": [...]}
        
        Returns:
            JSON string with result
        
        Examples:
            # Send A2UI message with components
            send_a2ui_message({
                "updateComponents": {
                    "surfaceId": "chat_ui",
                    "components": [
                        {"id": "root", "component": "Column", "children": ["title", "content"]},
                        {"id": "title", "component": "Text", "text": "Hello"},
                        {"id": "content", "component": "Table", "data": [...]}
                    ]
                }
            })
        """
        logger = getattr(self, 'logger', None) or getattr(self, '_logger', None)
        if not logger:
            logger = Logger("AssistantTools")
        
        try:
            logger.input("send_a2ui_message INPUT: a2ui_spec keys={}", list(a2ui_spec.keys()))
            
            # Convert A2UI spec to widgets
            converter = A2UIConverter()
            
            # Extract components from A2UI spec
            if "updateComponents" in a2ui_spec:
                components = a2ui_spec["updateComponents"].get("components", [])
            elif "components" in a2ui_spec:
                components = a2ui_spec["components"]
            else:
                # Try to parse as SurfaceUpdate
                try:
                    from a2ui_pydantic import SurfaceUpdate
                    surface_update = SurfaceUpdate(**a2ui_spec)
                    components = surface_update.components if hasattr(surface_update, 'components') else []
                except Exception:
                    components = []
            
            if not components:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": "No components found in A2UI specification",
                })
            
            # Convert A2UI components to widgets
            widget_collector = get_widget_collector()
            if not widget_collector:
                logger.warning("Widget collector not available")
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": "Widget collector not available",
                })
            
            # Map A2UI components to widgets
            component_map = {comp.get("id", ""): comp for comp in components}
            root_component = None
            
            for comp in components:
                if comp.get("id") == "root":
                    root_component = comp
                    break
            
            if not root_component and components:
                root_component = components[0]
            
            if root_component:
                # Convert root component and its children to widgets
                widgets_added = self._convert_a2ui_to_widgets(
                    root_component,
                    component_map,
                    widget_collector,
                    logger
                )
                
                if widgets_added > 0:
                    result = f"A2UI message processed: {widgets_added} widget(s) added to response."
                    logger.output("send_a2ui_message OUTPUT: widgets_added={}, message={}", widgets_added, result)
                    return JSONUtils.normalize_for_ui({
                        "success": True,
                        "message": result,
                        "widgets_added": widgets_added,
                    })
                else:
                    return JSONUtils.normalize_for_ui({
                        "success": False,
                        "error": "No widgets could be created from A2UI components",
                    })
            else:
                return JSONUtils.normalize_for_ui({
                    "success": False,
                    "error": "No root component found in A2UI specification",
                })
        
        except ImportError as e:
            logger.error("A2UI support not available: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": "A2UI support requires a2ui-pydantic package. Please install it.",
            })
        except Exception as e:
            logger.error("Error sending A2UI message: {}", e)
            return JSONUtils.normalize_for_ui({
                "success": False,
                "error": str(e),
            })
    
    def _convert_a2ui_to_widgets(
        self,
        component: Dict[str, Any],
        component_map: Dict[str, Any],
        widget_collector: WidgetCollector,
        logger: Logger
    ) -> int:
        """Convert A2UI component tree to widgets using insert_widget"""
        widgets_added = 0
        comp_type = component.get("component", "")
        comp_id = component.get("id", "")
        
        # Map A2UI component types to widget types (using shared mapping)
        widget_type = A2UI_COMPONENT_TO_WIDGET_MAP.get(comp_type)
        
        # Handle layout components (Row, Column, Stack) - process children
        if comp_type in ["Row", "Column", "Stack"]:
            children_ids = component.get("children", [])
            for child_id in children_ids:
                child_comp = component_map.get(child_id)
                if child_comp:
                    widgets_added += self._convert_a2ui_to_widgets(
                        child_comp,
                        component_map,
                        widget_collector,
                        logger
                    )
            return widgets_added
        
        # Handle widget components
        if widget_type:
            # Extract data/value
            value = component.get("value") or component.get("text") or component.get("url") or component.get("data")
            
            # Extract props
            props = {}
            if comp_type == "TextField":
                props["variant"] = component.get("variant", "shortText")
            elif comp_type == "ChoicePicker":
                props["options"] = component.get("options", [])
                props["multiple"] = component.get("variant") != "mutuallyExclusive"
            elif comp_type == "Code":
                props["language"] = component.get("language", "text")
            
            # Add widget using collector
            try:
                widget_collector.add_widget(
                    widget_type=widget_type,
                    data=value,
                    props=props if props else None,
                )
                widgets_added += 1
                logger.debug("Converted A2UI component {} to widget {}", comp_id, widget_type)
            except Exception as e:
                logger.warning("Failed to add widget from A2UI component {}: {}", comp_id, e)
        
        return widgets_added
    
    async def get_current_location(self) -> Dict[str, Any]:
        """
        Tool: Get the current location based on browser geolocation or IP address.
        
        This tool provides location information using browser geolocation (preferred) or IP-based geolocation (fallback).
        Use this when:
        - User asks "where am I", "what's my location", "where is this request coming from"
        - You need to determine user's timezone for date/time operations
        - User asks about their city, country, or region
        - You need location context for providing relevant information
        
        Browser geolocation (preferred):
        - Uses GPS, WiFi positioning, or cell tower triangulation
        - Provides meter-level accuracy (typically 10-100 meters)
        - More accurate and consistent than IP geolocation
        - Requires user permission
        
        IP geolocation (fallback):
        - Uses IP address to determine approximate location
        - Provides city/region-level accuracy (typically 1-50 km)
        - Less accurate, affected by VPNs, proxies, or server location
        - No user permission required
        
        Returns:
            Dict with:
                - city: City name (e.g., "San Francisco")
                - region: State/Province/Region (e.g., "California")
                - country: Country name (e.g., "United States")
                - country_code: ISO country code (e.g., "US")
                - timezone: Timezone identifier (e.g., "America/Los_Angeles")
                - latitude: Latitude (float)
                - longitude: Longitude (float)
                - ip: IP address used (if IP geolocation was used, None if browser geolocation)
                - accuracy: "gps" (browser) or "city" (IP-based)
                - accuracy_meters: Accuracy in meters (if browser geolocation)
        """
        logger = getattr(self, 'logger', None) or getattr(self, '_logger', None)
        if not logger:
            logger = Logger("AssistantTools")
        
        logger.input("get_current_location INPUT: checking browser_location and client_ip")
        
        try:
            # Try to use httpx first (async), fallback to requests if not available
            try:
                import httpx
                use_httpx = True
            except ImportError:
                import requests
                use_httpx = False
            
            # Check for browser location first (preferred - more accurate)
            browser_location = _browser_location.get()
            if browser_location:
                latitude = browser_location.get("latitude")
                longitude = browser_location.get("longitude")
                accuracy_meters = browser_location.get("accuracy")
                
                if latitude is not None and longitude is not None:
                    logger.info("Using browser geolocation: lat={}, lon={}, accuracy={}m", 
                               latitude, longitude, accuracy_meters)
                    
                    # Reverse geocode to get city/region/country/timezone
                    # Use Nominatim (OpenStreetMap) for accurate reverse geocoding
                    # Free, no API key required, accurate for coordinates
                    reverse_geo_url = f"https://nominatim.openstreetmap.org/reverse?lat={latitude}&lon={longitude}&format=json&addressdetails=1"
                    
                    try:
                        if use_httpx:
                            async with httpx.AsyncClient(timeout=5.0, headers={"User-Agent": "TopazAgentKit/1.0"}) as client:
                                response = await client.get(reverse_geo_url)
                                response.raise_for_status()
                                geo_data = response.json()
                        else:
                            response = requests.get(reverse_geo_url, timeout=5, headers={"User-Agent": "TopazAgentKit/1.0"})
                            response.raise_for_status()
                            geo_data = response.json()
                        
                        # Extract location data from Nominatim response
                        address = geo_data.get("address", {})
                        city = (
                            address.get("city") or 
                            address.get("town") or 
                            address.get("village") or
                            address.get("municipality") or
                            address.get("suburb")
                        )
                        region = (
                            address.get("state") or 
                            address.get("region") or
                            address.get("county")
                        )
                        country = address.get("country")
                        country_code = address.get("country_code", "").upper() if address.get("country_code") else None
                        
                        # Get timezone from coordinates: use land-only lookup first for correct
                        # political timezones (e.g. America/Phoenix for Arizona, not America/Los_Angeles)
                        timezone = None
                        try:
                            import timezonefinder
                            tf = timezonefinder.TimezoneFinder()
                            timezone = tf.timezone_at_land(lat=latitude, lng=longitude)
                            if not timezone:
                                timezone = tf.timezone_at(lat=latitude, lng=longitude)
                        except (ImportError, Exception):
                            pass
                        if not timezone:
                            try:
                                timezone_url = f"http://ip-api.com/json/?lat={latitude}&lon={longitude}&fields=timezone"
                                if use_httpx:
                                    async with httpx.AsyncClient(timeout=3.0) as client:
                                        tz_response = await client.get(timezone_url)
                                        if tz_response.status_code == 200:
                                            tz_data = tz_response.json()
                                            timezone = tz_data.get("timezone")
                                else:
                                    tz_response = requests.get(timezone_url, timeout=3)
                                    if tz_response.status_code == 200:
                                        tz_data = tz_response.json()
                                        timezone = tz_data.get("timezone")
                            except Exception:
                                pass
                        
                        if city or region or country:
                            result = {
                                "city": city,
                                "region": region,
                                "country": country,
                                "country_code": country_code,
                                "timezone": timezone,
                                "latitude": latitude,
                                "longitude": longitude,
                                "ip": None,  # Browser geolocation doesn't use IP
                                "accuracy": "gps",
                                "accuracy_meters": accuracy_meters,
                            }
                            logger.output("get_current_location OUTPUT (browser): city={}, region={}, country={}, timezone={}, accuracy={}m",
                                        result.get("city"), result.get("region"), result.get("country"), result.get("timezone"), accuracy_meters)
                            
                            if hasattr(self, '_logger'):
                                return result
                            else:
                                return JSONUtils.normalize_for_ui(result)
                        else:
                            logger.warning("Reverse geocoding returned incomplete data, falling back to IP geolocation")
                    except Exception as e:
                        logger.warning("Reverse geocoding failed: {}, falling back to IP geolocation", e)
            
            # Fall back to IP-based geolocation
            # Get client IP from context (set by FastAPI endpoint)
            client_ip = _client_ip.get()
            
            # Use ip-api.com free service (no API key required, rate limit: 45 requests/minute)
            # If client IP is available and not localhost/reserved, use it; otherwise query server's IP
            # Localhost IPs (127.0.0.1, ::1) cannot be geolocated, so fall back to server IP
            if client_ip and client_ip not in ("127.0.0.1", "::1", "localhost"):
                api_url = f"http://ip-api.com/json/{client_ip}"
                logger.info("Fetching location for client IP: {}", client_ip)
            else:
                # Fall back to querying server's public IP (works for localhost connections)
                api_url = "http://ip-api.com/json/"
                if client_ip:
                    logger.info("Client IP is localhost ({}), querying server's public IP instead", client_ip)
                else:
                    logger.warning("No client IP in context, querying server IP")
            
            logger.info("Fetching location from IP geolocation service")
            
            if use_httpx:
                async with httpx.AsyncClient(timeout=5.0) as client:
                    response = await client.get(api_url)
                    response.raise_for_status()
                    data = response.json()
            else:
                response = requests.get(api_url, timeout=5)
                response.raise_for_status()
                data = response.json()
            
            # ip-api.com returns status field - check if successful
            if data.get("status") == "fail":
                error_msg = data.get("message", "Unknown error")
                logger.warning("IP geolocation failed: {}", error_msg)
                result = {
                    "city": None,
                    "region": None,
                    "country": None,
                    "country_code": None,
                    "timezone": None,
                    "latitude": None,
                    "longitude": None,
                    "ip": None,
                    "accuracy": "unknown",
                    "error": error_msg,
                }
            else:
                # Extract relevant fields from ip-api.com response
                result = {
                    "city": data.get("city"),
                    "region": data.get("regionName"),
                    "country": data.get("country"),
                    "country_code": data.get("countryCode"),
                    "timezone": data.get("timezone"),
                    "latitude": data.get("lat"),
                    "longitude": data.get("lon"),
                    "ip": data.get("query"),
                    "accuracy": "city",  # IP geolocation is city-level
                }
                
                # Add warning if we used server IP instead of client IP (localhost access)
                if not client_ip or client_ip in ("127.0.0.1", "::1", "localhost"):
                    result["warning"] = (
                        "Location is based on server's public IP, not your client IP. "
                        "If you're accessing via localhost, this may show the server's location instead of yours. "
                        "For accurate location, access the server via its public IP address or hostname."
                    )
            
            logger.output("get_current_location OUTPUT: city={}, country={}, timezone={}", 
                         result.get("city"), result.get("country"), result.get("timezone"))
            
            # Return dict for Assistant class, JSON string for others
            if hasattr(self, '_logger'):
                return result  # Assistant returns dict
            else:
                return JSONUtils.normalize_for_ui(result)  # Others return JSON string
                
        except Exception as e:
            logger.error("get_current_location failed: {}", e)
            # Return error result
            result = {
                "city": None,
                "region": None,
                "country": None,
                "country_code": None,
                "timezone": None,
                "latitude": None,
                "longitude": None,
                "ip": None,
                "accuracy": "unknown",
                "error": str(e),
            }
            if hasattr(self, '_logger'):
                return result
            else:
                return JSONUtils.normalize_for_ui(result)
    
    async def export_document(
        self,
        format: str = "markdown",
        state_path: Optional[str] = None,
        filename: Optional[str] = None,
    ) -> str:
        """
        Tool: Export document from canvas state to a downloadable file.
        
        This tool generates a file from the current canvas state and makes it available for download.
        Use this when users ask to download, export, or save the current document/article/recipe.
        
        Args:
            format: Export format (default: "markdown"). Supported formats:
                - "markdown": Markdown format (.md)
                - "html": HTML format (.html)
                - "pdf": PDF format (.pdf) - requires additional dependencies
                - "txt": Plain text format (.txt)
            state_path: Optional path to specific state section to export (e.g., "article").
                       If not provided, exports full state.
            filename: Optional custom filename (without extension). If not provided, generates
                     a filename based on document title or current timestamp.
        
        Returns:
            JSON string with:
                - success: Whether export succeeded
                - file_id: File ID for download
                - filename: Generated filename
                - download_url: URL to download the file
                - error: Error message if failed
        """
        logger = getattr(self, 'logger', None) or getattr(self, '_logger', None)
        if not logger:
            logger = Logger("AssistantTools")
        
        logger.input("export_document INPUT: format={}, state_path={}, filename={}", format, state_path, filename)
        
        try:
            # Check if this is AppAssistant (has app_session_store)
            app_session_store = getattr(self, '_app_session_store', None)
            app_session_id = getattr(self, '_app_session_id', None)
            
            if not app_session_store or not app_session_id:
                error_result = {
                    "success": False,
                    "error": "export_document tool is only available in app sessions",
                }
                logger.output("export_document OUTPUT: success=false, error={}", error_result["error"])
                return JSONUtils.normalize_for_ui(error_result)
            
            # Get current canvas state
            session = app_session_store.get_session(app_session_id)
            if not session:
                error_result = {
                    "success": False,
                    "error": f"Session {app_session_id} not found",
                }
                logger.output("export_document OUTPUT: success=false, error={}", error_result["error"])
                return JSONUtils.normalize_for_ui(error_result)
            
            state = session.state
            
            # Extract state at path if specified
            if state_path:
                from topaz_agent_kit.utils.json_utils import JSONUtils as JU
                value = JU.get_value_at_path(state, state_path)
                export_data = value if value is not None else {}
            else:
                export_data = state
            
            # Generate content based on format
            content_bytes = None
            file_extension = ""
            
            if format.lower() == "markdown":
                content = self._generate_markdown(export_data)
                content_bytes = content.encode('utf-8')
                file_extension = "md"
            elif format.lower() == "html":
                content = self._generate_html(export_data)
                content_bytes = content.encode('utf-8')
                file_extension = "html"
            elif format.lower() == "txt":
                content = self._generate_text(export_data)
                content_bytes = content.encode('utf-8')
                file_extension = "txt"
            elif format.lower() == "pdf":
                # Generate PDF from HTML using WeasyPrint
                html_content = self._generate_html(export_data)
                try:
                    import weasyprint
                    pdf_bytes = weasyprint.HTML(string=html_content).write_pdf()
                    content_bytes = pdf_bytes
                    file_extension = "pdf"
                except ImportError:
                    error_result = {
                        "success": False,
                        "error": "PDF export requires weasyprint. Install with: pip install weasyprint",
                    }
                    logger.output("export_document OUTPUT: success=false, error={}", error_result["error"])
                    return JSONUtils.normalize_for_ui(error_result)
                except Exception as e:
                    logger.error("PDF generation failed: {}", e)
                    error_result = {
                        "success": False,
                        "error": f"PDF generation failed: {str(e)}",
                    }
                    logger.output("export_document OUTPUT: success=false, error={}", error_result["error"])
                    return JSONUtils.normalize_for_ui(error_result)
            elif format.lower() == "docx":
                # Generate DOCX using python-docx
                try:
                    from docx import Document
                    from io import BytesIO
                    
                    doc = Document()
                    self._generate_docx(export_data, doc)
                    
                    # Save to bytes
                    doc_io = BytesIO()
                    doc.save(doc_io)
                    content_bytes = doc_io.getvalue()
                    doc_io.close()
                    file_extension = "docx"
                except ImportError:
                    error_result = {
                        "success": False,
                        "error": "DOCX export requires python-docx. Install with: pip install python-docx",
                    }
                    logger.output("export_document OUTPUT: success=false, error={}", error_result["error"])
                    return JSONUtils.normalize_for_ui(error_result)
                except Exception as e:
                    logger.error("DOCX generation failed: {}", e)
                    error_result = {
                        "success": False,
                        "error": f"DOCX generation failed: {str(e)}",
                    }
                    logger.output("export_document OUTPUT: success=false, error={}", error_result["error"])
                    return JSONUtils.normalize_for_ui(error_result)
            elif format.lower() == "pptx":
                # Generate PPTX using python-pptx
                try:
                    from pptx import Presentation
                    from io import BytesIO
                    
                    prs = Presentation()
                    self._generate_pptx(export_data, prs)
                    
                    # Save to bytes
                    prs_io = BytesIO()
                    prs.save(prs_io)
                    content_bytes = prs_io.getvalue()
                    prs_io.close()
                    file_extension = "pptx"
                except ImportError:
                    error_result = {
                        "success": False,
                        "error": "PPTX export requires python-pptx. Install with: pip install python-pptx",
                    }
                    logger.output("export_document OUTPUT: success=false, error={}", error_result["error"])
                    return JSONUtils.normalize_for_ui(error_result)
                except Exception as e:
                    logger.error("PPTX generation failed: {}", e)
                    error_result = {
                        "success": False,
                        "error": f"PPTX generation failed: {str(e)}",
                    }
                    logger.output("export_document OUTPUT: success=false, error={}", error_result["error"])
                    return JSONUtils.normalize_for_ui(error_result)
            elif format.lower() == "xlsx":
                # Generate XLSX using openpyxl
                try:
                    from openpyxl import Workbook
                    from io import BytesIO
                    
                    wb = Workbook()
                    self._generate_xlsx(export_data, wb)
                    
                    # Save to bytes
                    xlsx_io = BytesIO()
                    wb.save(xlsx_io)
                    content_bytes = xlsx_io.getvalue()
                    xlsx_io.close()
                    file_extension = "xlsx"
                except ImportError:
                    error_result = {
                        "success": False,
                        "error": "XLSX export requires openpyxl. Install with: pip install openpyxl",
                    }
                    logger.output("export_document OUTPUT: success=false, error={}", error_result["error"])
                    return JSONUtils.normalize_for_ui(error_result)
                except Exception as e:
                    logger.error("XLSX generation failed: {}", e)
                    error_result = {
                        "success": False,
                        "error": f"XLSX generation failed: {str(e)}",
                    }
                    logger.output("export_document OUTPUT: success=false, error={}", error_result["error"])
                    return JSONUtils.normalize_for_ui(error_result)
            else:
                error_result = {
                    "success": False,
                    "error": f"Unsupported format: {format}. Supported: markdown, html, pdf, docx, pptx, xlsx, txt",
                }
                logger.output("export_document OUTPUT: success=false, error={}", error_result["error"])
                return JSONUtils.normalize_for_ui(error_result)
            
            # Generate filename if not provided
            if not filename:
                # Try to extract title from state
                title = None
                if isinstance(export_data, dict):
                    # Try common title fields
                    for key in ['title', 'name', 'article.title', 'recipe.title']:
                        if '.' in key:
                            parts = key.split('.')
                            val = export_data
                            for part in parts:
                                if isinstance(val, dict) and part in val:
                                    val = val[part]
                                else:
                                    val = None
                                    break
                            if val:
                                title = str(val)
                                break
                        elif key in export_data:
                            title = str(export_data[key])
                            break
                
                if title:
                    # Sanitize title for filename
                    import re
                    filename = re.sub(r'[^\w\s-]', '', title).strip()
                    filename = re.sub(r'[-\s]+', '-', filename)
                    filename = filename[:50]  # Limit length
                else:
                    # Fallback to timestamp
                    from datetime import datetime
                    filename = f"document-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
            
            # Ensure filename has extension
            if not filename.endswith(f".{file_extension}"):
                filename = f"{filename}.{file_extension}"
            
            # Store file using file storage service
            from topaz_agent_kit.core.file_storage import FileStorageService
            from topaz_agent_kit.services.fastapi_app import get_shared_services
            
            # Get file storage from shared services
            file_storage, _, _, _, _, _ = get_shared_services()
            
            # Store file
            storage_info = file_storage.store_file(
                file_content=content_bytes,
                filename=filename,
                file_type=file_extension,
                storage_type="app_session",
                app_session_id=app_session_id,
            )
            
            file_id = storage_info.get("file_id")
            
            # Generate download URL (relative to API base)
            download_url = f"/api/app/sessions/{app_session_id}/files/{file_id}"
            
            result = {
                "success": True,
                "file_id": file_id,
                "filename": filename,
                "download_url": download_url,
                "format": format,
            }
            
            logger.output("export_document OUTPUT: success=true, format={}, filename={}, file_id={}", 
                         format, filename, file_id)
            
            return JSONUtils.normalize_for_ui(result)
            
        except Exception as e:
            logger.error("export_document failed: {}", e, exc_info=True)
            error_result = {
                "success": False,
                "error": str(e),
            }
            logger.output("export_document OUTPUT: success=false, error={}", str(e))
            return JSONUtils.normalize_for_ui(error_result)
    
    def _generate_markdown(self, data: Any) -> str:
        """Generate markdown content from state data"""
        if isinstance(data, dict):
            lines = []
            for key, value in data.items():
                if isinstance(value, dict):
                    lines.append(f"## {key.replace('_', ' ').title()}")
                    lines.append(self._generate_markdown(value))
                elif isinstance(value, list):
                    lines.append(f"### {key.replace('_', ' ').title()}")
                    for item in value:
                        if isinstance(item, dict):
                            lines.append("- " + ", ".join(f"{k}: {v}" for k, v in item.items()))
                        else:
                            lines.append(f"- {item}")
                elif value:
                    # Format key nicely
                    key_formatted = key.replace('_', ' ').title()
                    if isinstance(value, str) and '\n' in value:
                        lines.append(f"### {key_formatted}\n\n{value}\n")
                    else:
                        lines.append(f"**{key_formatted}**: {value}")
            return "\n\n".join(lines)
        elif isinstance(data, list):
            return "\n".join(f"- {item}" for item in data)
        else:
            return str(data)
    
    def _generate_html(self, data: Any) -> str:
        """Generate HTML content from state data"""
        markdown_content = self._generate_markdown(data)
        # Simple HTML wrapper (could use markdown library for better conversion)
        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Exported Document</title>
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 800px; margin: 40px auto; padding: 20px; }}
        h2 {{ color: #333; border-bottom: 2px solid #333; padding-bottom: 10px; }}
        h3 {{ color: #666; margin-top: 20px; }}
        ul {{ line-height: 1.6; }}
        p {{ line-height: 1.6; }}
    </style>
</head>
<body>
{self._markdown_to_html_simple(markdown_content)}
</body>
</html>"""
        return html_content
    
    def _markdown_to_html_simple(self, markdown: str) -> str:
        """Simple markdown to HTML converter"""
        import re
        html = markdown
        # Headers
        html = re.sub(r'^### (.+)$', r'<h3>\1</h3>', html, flags=re.MULTILINE)
        html = re.sub(r'^## (.+)$', r'<h2>\1</h2>', html, flags=re.MULTILINE)
        # Bold
        html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html)
        # Lists
        html = re.sub(r'^- (.+)$', r'<li>\1</li>', html, flags=re.MULTILINE)
        html = re.sub(r'(<li>.*</li>)', r'<ul>\1</ul>', html, flags=re.DOTALL)
        # Paragraphs
        paragraphs = html.split('\n\n')
        html = '\n'.join(f'<p>{p.strip()}</p>' if p.strip() and not p.strip().startswith('<') else p for p in paragraphs)
        return html
    
    def _generate_text(self, data: Any) -> str:
        """Generate plain text content from state data"""
        return self._generate_markdown(data)  # Markdown is already mostly plain text
    
    def _generate_docx(self, data: Any, doc: Any) -> None:
        """Generate DOCX document from state data"""
        from docx.shared import Inches, Pt
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        
        if isinstance(data, dict):
            for key, value in data.items():
                key_formatted = key.replace('_', ' ').title()
                
                if isinstance(value, dict):
                    # Add heading for section
                    heading = doc.add_heading(key_formatted, level=1)
                    self._generate_docx(value, doc)
                elif isinstance(value, list):
                    # Add heading for list section
                    heading = doc.add_heading(key_formatted, level=2)
                    for item in value:
                        if isinstance(item, dict):
                            # Add paragraph with item details
                            item_text = ", ".join(f"{k}: {v}" for k, v in item.items())
                            doc.add_paragraph(item_text, style='List Bullet')
                        else:
                            doc.add_paragraph(str(item), style='List Bullet')
                elif value:
                    if isinstance(value, str) and '\n' in value:
                        # Multi-line content - add heading and paragraph
                        doc.add_heading(key_formatted, level=2)
                        for line in value.split('\n'):
                            if line.strip():
                                doc.add_paragraph(line.strip())
                    else:
                        # Simple key-value
                        p = doc.add_paragraph()
                        run = p.add_run(f"{key_formatted}: ")
                        run.bold = True
                        p.add_run(str(value))
        elif isinstance(data, list):
            for item in data:
                doc.add_paragraph(str(item), style='List Bullet')
    
    def _generate_pptx(self, data: Any, prs: Any) -> None:
        """Generate PPTX presentation from state data"""
        from pptx.util import Inches, Pt
        
        # Create title slide
        title_slide_layout = prs.slide_layouts[0]
        slide = prs.slides.add_slide(title_slide_layout)
        title = slide.shapes.title
        subtitle = slide.placeholders[1]
        
        # Extract title from data
        doc_title = "Exported Document"
        if isinstance(data, dict):
            for key in ['title', 'name']:
                if key in data:
                    doc_title = str(data[key])
                    break
        
        title.text = doc_title
        subtitle.text = "Generated Document"
        
        # Create content slide
        bullet_slide_layout = prs.slide_layouts[1]
        slide = prs.slides.add_slide(bullet_slide_layout)
        shapes = slide.shapes
        title_shape = shapes.title
        body_shape = shapes.placeholders[1]
        
        title_shape.text = "Content"
        tf = body_shape.text_frame
        tf.text = "Document Details"
        
        # Add content as bullet points
        if isinstance(data, dict):
            for key, value in data.items():
                key_formatted = key.replace('_', ' ').title()
                if isinstance(value, dict):
                    p = tf.add_paragraph()
                    p.text = f"{key_formatted}:"
                    p.level = 0
                    for k, v in value.items():
                        p = tf.add_paragraph()
                        p.text = f"  {k}: {v}"
                        p.level = 1
                elif isinstance(value, list):
                    p = tf.add_paragraph()
                    p.text = f"{key_formatted}:"
                    p.level = 0
                    for item in value:
                        p = tf.add_paragraph()
                        p.text = f"  {item}"
                        p.level = 1
                elif value:
                    p = tf.add_paragraph()
                    p.text = f"{key_formatted}: {value}"
                    p.level = 0
    
    def _generate_xlsx(self, data: Any, wb: Any) -> None:
        """Generate XLSX spreadsheet from state data"""
        from openpyxl.styles import Font, Alignment
        
        ws = wb.active
        ws.title = "Document Data"
        
        row = 1
        
        if isinstance(data, dict):
            # Write headers
            ws['A1'] = "Field"
            ws['B1'] = "Value"
            ws['A1'].font = Font(bold=True)
            ws['B1'].font = Font(bold=True)
            row = 2
            
            for key, value in data.items():
                key_formatted = key.replace('_', ' ').title()
                
                if isinstance(value, dict):
                    ws[f'A{row}'] = key_formatted
                    ws[f'A{row}'].font = Font(bold=True)
                    row += 1
                    for k, v in value.items():
                        ws[f'A{row}'] = f"  {k}"
                        ws[f'B{row}'] = str(v)
                        row += 1
                elif isinstance(value, list):
                    ws[f'A{row}'] = key_formatted
                    ws[f'A{row}'].font = Font(bold=True)
                    row += 1
                    for idx, item in enumerate(value, start=1):
                        if isinstance(item, dict):
                            ws[f'A{row}'] = f"  Item {idx}"
                            col = 2
                            for k, v in item.items():
                                ws.cell(row=row, column=col, value=f"{k}: {v}")
                                col += 1
                        else:
                            ws[f'A{row}'] = f"  Item {idx}"
                            ws[f'B{row}'] = str(item)
                        row += 1
                elif value:
                    ws[f'A{row}'] = key_formatted
                    ws[f'B{row}'] = str(value)
                    row += 1
        
        # Auto-adjust column widths
        ws.column_dimensions['A'].width = 30
        ws.column_dimensions['B'].width = 50


def set_client_ip(ip: str) -> None:
    """Set client IP in context for location geolocation."""
    _client_ip.set(ip)


def get_client_ip() -> Optional[str]:
    """Get client IP from context."""
    return _client_ip.get()


def set_browser_location(location: Dict[str, Any]) -> None:
    """Set browser location in context (preferred over IP geolocation)."""
    _browser_location.set(location)


def get_browser_location() -> Optional[Dict[str, Any]]:
    """Get browser location from context."""
    return _browser_location.get()


# Note: export_document is defined inside AssistantToolsMixin class (see above)
    
    def _generate_docx(self, data: Any, doc: Any) -> None:
        """Generate DOCX document from state data"""
        from docx.shared import Inches, Pt
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        
        if isinstance(data, dict):
            for key, value in data.items():
                key_formatted = key.replace('_', ' ').title()
                
                if isinstance(value, dict):
                    # Add heading for section
                    heading = doc.add_heading(key_formatted, level=1)
                    self._generate_docx(value, doc)
                elif isinstance(value, list):
                    # Add heading for list section
                    heading = doc.add_heading(key_formatted, level=2)
                    for item in value:
                        if isinstance(item, dict):
                            # Add paragraph with item details
                            item_text = ", ".join(f"{k}: {v}" for k, v in item.items())
                            doc.add_paragraph(item_text, style='List Bullet')
                        else:
                            doc.add_paragraph(str(item), style='List Bullet')
                elif value:
                    if isinstance(value, str) and '\n' in value:
                        # Multi-line content - add heading and paragraph
                        doc.add_heading(key_formatted, level=2)
                        for line in value.split('\n'):
                            if line.strip():
                                doc.add_paragraph(line.strip())
                    else:
                        # Simple key-value
                        p = doc.add_paragraph()
                        run = p.add_run(f"{key_formatted}: ")
                        run.bold = True
                        p.add_run(str(value))
        elif isinstance(data, list):
            for item in data:
                doc.add_paragraph(str(item), style='List Bullet')
    
    def _generate_pptx(self, data: Any, prs: Any) -> None:
        """Generate PPTX presentation from state data"""
        from pptx.util import Inches, Pt
        
        # Create title slide
        title_slide_layout = prs.slide_layouts[0]
        slide = prs.slides.add_slide(title_slide_layout)
        title = slide.shapes.title
        subtitle = slide.placeholders[1]
        
        # Extract title from data
        doc_title = "Exported Document"
        if isinstance(data, dict):
            for key in ['title', 'name']:
                if key in data:
                    doc_title = str(data[key])
                    break
        
        title.text = doc_title
        subtitle.text = "Generated Document"
        
        # Create content slide
        bullet_slide_layout = prs.slide_layouts[1]
        slide = prs.slides.add_slide(bullet_slide_layout)
        shapes = slide.shapes
        title_shape = shapes.title
        body_shape = shapes.placeholders[1]
        
        title_shape.text = "Content"
        tf = body_shape.text_frame
        tf.text = "Document Details"
        
        # Add content as bullet points
        if isinstance(data, dict):
            for key, value in data.items():
                key_formatted = key.replace('_', ' ').title()
                if isinstance(value, dict):
                    p = tf.add_paragraph()
                    p.text = f"{key_formatted}:"
                    p.level = 0
                    for k, v in value.items():
                        p = tf.add_paragraph()
                        p.text = f"  {k}: {v}"
                        p.level = 1
                elif isinstance(value, list):
                    p = tf.add_paragraph()
                    p.text = f"{key_formatted}:"
                    p.level = 0
                    for item in value:
                        p = tf.add_paragraph()
                        p.text = f"  {item}"
                        p.level = 1
                elif value:
                    p = tf.add_paragraph()
                    p.text = f"{key_formatted}: {value}"
                    p.level = 0
    
    def _generate_xlsx(self, data: Any, wb: Any) -> None:
        """Generate XLSX spreadsheet from state data"""
        from openpyxl.styles import Font, Alignment
        
        ws = wb.active
        ws.title = "Document Data"
        
        row = 1
        
        if isinstance(data, dict):
            # Write headers
            ws['A1'] = "Field"
            ws['B1'] = "Value"
            ws['A1'].font = Font(bold=True)
            ws['B1'].font = Font(bold=True)
            row = 2
            
            for key, value in data.items():
                key_formatted = key.replace('_', ' ').title()
                
                if isinstance(value, dict):
                    ws[f'A{row}'] = key_formatted
                    ws[f'A{row}'].font = Font(bold=True)
                    row += 1
                    for k, v in value.items():
                        ws[f'A{row}'] = f"  {k}"
                        ws[f'B{row}'] = str(v)
                        row += 1
                elif isinstance(value, list):
                    ws[f'A{row}'] = key_formatted
                    ws[f'A{row}'].font = Font(bold=True)
                    row += 1
                    for idx, item in enumerate(value, start=1):
                        if isinstance(item, dict):
                            ws[f'A{row}'] = f"  Item {idx}"
                            col = 2
                            for k, v in item.items():
                                ws.cell(row=row, column=col, value=f"{k}: {v}")
                                col += 1
                        else:
                            ws[f'A{row}'] = f"  Item {idx}"
                            ws[f'B{row}'] = str(item)
                        row += 1
                elif value:
                    ws[f'A{row}'] = key_formatted
                    ws[f'B{row}'] = str(value)
                    row += 1
        
        # Auto-adjust column widths
        ws.column_dimensions['A'].width = 30
        ws.column_dimensions['B'].width = 50
