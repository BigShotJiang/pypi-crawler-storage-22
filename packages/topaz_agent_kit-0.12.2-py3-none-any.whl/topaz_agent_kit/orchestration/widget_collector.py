"""
Widget Collector for Chat Responses

Collects widgets from tool calls during assistant execution and includes
them in the final AssistantResponse.
"""

from typing import List, Optional, Dict, Any, TYPE_CHECKING
from contextvars import ContextVar

if TYPE_CHECKING:
    from topaz_agent_kit.orchestration.assistant import WidgetAttachment
else:
    # Import at runtime to avoid circular dependency
    WidgetAttachment = None

# Context variable for thread-local widget collection
_widget_collector: ContextVar[Optional['WidgetCollector']] = ContextVar(
    'widget_collector', default=None
)


class WidgetCollector:
    """
    Collects widgets during assistant execution.
    
    Thread-safe and context-aware - each assistant execution gets its own collector.
    """
    
    def __init__(self):
        # Import here to avoid circular dependency
        from topaz_agent_kit.orchestration.assistant import WidgetAttachment
        self.widgets: List[WidgetAttachment] = []
        self._max_widgets = 10  # Default limit, can be overridden
    
    def add_widget(
        self,
        widget_type: str,
        data: Any,  # Accept any type (dict, list, string, etc.)
        props: Optional[Any] = None,  # Accept any type
        binding: Optional[str] = None,
    ) -> None:
        """
        Add a widget to the collection.
        
        Args:
            widget_type: Type of widget (e.g., "table_view", "form")
            data: Widget data/binding
            props: Optional widget-specific properties
            binding: Optional state binding path
        """
        # Import here to avoid circular dependency
        from topaz_agent_kit.orchestration.assistant import WidgetAttachment
        
        if len(self.widgets) >= self._max_widgets:
            raise ValueError(
                f"Maximum widget limit ({self._max_widgets}) reached. "
                "Cannot add more widgets to this response."
            )
        
        widget = WidgetAttachment(
            widget_type=widget_type,
            data=data,
            props=props or {},
            binding=binding,
        )
        
        self.widgets.append(widget)
    
    def get_widgets(self) -> List['WidgetAttachment']:
        """Get all collected widgets."""
        return self.widgets.copy()
    
    def clear(self) -> None:
        """Clear all collected widgets."""
        self.widgets = []
    
    def set_max_widgets(self, max_widgets: int) -> None:
        """Set maximum number of widgets allowed."""
        self._max_widgets = max_widgets


def get_widget_collector() -> Optional[WidgetCollector]:
    """Get the current widget collector from context."""
    return _widget_collector.get()


def set_widget_collector(collector: WidgetCollector) -> None:
    """Set the widget collector in context."""
    _widget_collector.set(collector)
