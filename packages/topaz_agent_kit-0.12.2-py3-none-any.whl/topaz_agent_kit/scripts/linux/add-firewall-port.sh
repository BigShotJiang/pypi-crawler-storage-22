#!/bin/bash
# Helper script to add firewall ports for Topaz Agent Kit projects
# Usage: ./add-firewall-port.sh <port> [protocol]
# Example: ./add-firewall-port.sh 8094 tcp

set -e

PORT="${1:-}"
PROTOCOL="${2:-tcp}"

if [ -z "$PORT" ]; then
    echo "Usage: $0 <port> [protocol]"
    echo "Example: $0 8094 tcp"
    echo "Example: $0 8094"
    exit 1
fi

# Detect firewall system
if command -v firewall-cmd &> /dev/null && systemctl is-active --quiet firewalld; then
    echo "Detected firewalld - Adding port ${PORT}/${PROTOCOL}..."
    sudo firewall-cmd --add-port=${PORT}/${PROTOCOL} --permanent
    sudo firewall-cmd --reload
    echo "✅ Port ${PORT}/${PROTOCOL} added successfully"
    echo "Current open ports:"
    sudo firewall-cmd --list-ports
elif command -v ufw &> /dev/null && systemctl is-active --quiet ufw; then
    echo "Detected ufw - Adding port ${PORT}/${PROTOCOL}..."
    sudo ufw allow ${PORT}/${PROTOCOL}
    echo "✅ Port ${PORT}/${PROTOCOL} added successfully"
    echo "Current firewall status:"
    sudo ufw status | grep ${PORT}
elif command -v iptables &> /dev/null; then
    echo "Detected iptables - Adding port ${PORT}/${PROTOCOL}..."
    sudo iptables -A INPUT -p ${PROTOCOL} --dport ${PORT} -j ACCEPT
    sudo iptables-save
    echo "✅ Port ${PORT}/${PROTOCOL} added successfully"
    echo "Note: iptables rules may need to be saved permanently (check your distro's method)"
else
    echo "⚠️  No active firewall detected (firewalld, ufw, or iptables)"
    echo "Port may already be accessible or firewall is disabled"
fi
