#!/bin/bash
# Helper script to add all firewall ports for a Topaz Agent Kit project
# Usage: ./add-project-ports.sh <projects-dir> <project-name>
# Example: ./add-project-ports.sh /home/nkhare/tak-projects pa

set -e

PROJECTS_DIR="${1:-}"
PROJECT_NAME="${2:-}"

if [ -z "$PROJECTS_DIR" ] || [ -z "$PROJECT_NAME" ]; then
    echo "Usage: $0 <projects-dir> <project-name>"
    echo "Example: $0 /home/nkhare/tak-projects pa"
    exit 1
fi

PROJECT_DIR="$PROJECTS_DIR/$PROJECT_NAME"

if [ ! -d "$PROJECT_DIR" ]; then
    echo "Error: Project directory not found: $PROJECT_DIR"
    exit 1
fi

# Find config file (pipelines.yml or common.yml)
CONFIG_FILE=""
if [ -f "$PROJECT_DIR/config/pipelines.yml" ]; then
    CONFIG_FILE="$PROJECT_DIR/config/pipelines.yml"
elif [ -f "$PROJECT_DIR/config/common.yml" ]; then
    CONFIG_FILE="$PROJECT_DIR/config/common.yml"
else
    echo "Error: No config file found (pipelines.yml or common.yml)"
    exit 1
fi

echo "Reading ports from: $CONFIG_FILE"

# Extract FastAPI port
FASTAPI_PORT=$(grep -A 2 "fastapi:" "$CONFIG_FILE" | grep "url:" | grep -oP ':\K[0-9]+' | head -1)
if [ -n "$FASTAPI_PORT" ]; then
    echo "Found FastAPI port: $FASTAPI_PORT"
    "$(dirname "$0")/add-firewall-port.sh" "$FASTAPI_PORT" "tcp"
fi

# Note: MCP port is handled by shared MCP service, not per-project
# Services port is internal-only and doesn't need firewall access

echo ""
echo "✅ FastAPI port for project '$PROJECT_NAME' has been added to firewall"
