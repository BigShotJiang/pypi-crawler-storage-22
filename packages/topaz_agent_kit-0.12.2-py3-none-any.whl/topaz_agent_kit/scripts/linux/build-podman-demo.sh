#!/bin/bash
# Build script for containerized demos (Docker/Podman compatible)
# Usage: ./scripts/build-podman-demo.sh <project_name> [service_mode]
# 
# Works with both Docker and Podman:
# - Auto-detects 'docker' or 'podman' command
# - Or set CONTAINER_CMD=docker or CONTAINER_CMD=podman explicitly

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if project name is provided
if [ -z "$1" ]; then
    echo -e "${RED}Error: Project name is required${NC}"
    echo "Usage: $0 <project_name> [service_mode]"
    echo "Example: $0 pa fastapi"
    echo "Service modes: fastapi (default), mcp, services, cli"
    exit 1
fi

PROJECT_NAME="$1"
SERVICE_MODE="${2:-fastapi}"
PROJECT_DIR="projects/${PROJECT_NAME}"
BASE_IMAGE="topaz-agent-kit"
DEMO_IMAGE="topaz-demo-${PROJECT_NAME}"

# Extract version from pyproject.toml
VERSION=$(grep -E '^version\s*=' pyproject.toml | sed -E "s/.*version\s*=\s*[\"']([^\"']+)[\"'].*/\1/" | head -1)
if [ -z "$VERSION" ]; then
    VERSION="latest"
fi

# Detect container command (docker or podman)
if [ -z "$CONTAINER_CMD" ]; then
    if command -v docker &> /dev/null; then
        CONTAINER_CMD="docker"
    elif command -v podman &> /dev/null; then
        CONTAINER_CMD="podman"
    else
        echo -e "${RED}Error: Neither docker nor podman found. Please install Docker Desktop or Podman.${NC}"
        exit 1
    fi
fi

echo -e "${GREEN}Using container command: ${CONTAINER_CMD}${NC}"

# Validate service mode
if [[ ! "$SERVICE_MODE" =~ ^(fastapi|mcp|services|cli)$ ]]; then
    echo -e "${RED}Error: Invalid service mode: $SERVICE_MODE${NC}"
    echo "Valid modes: fastapi, mcp, services, cli"
    exit 1
fi

# Check if project directory exists
if [ ! -d "$PROJECT_DIR" ]; then
    echo -e "${RED}Error: Project directory not found: $PROJECT_DIR${NC}"
    exit 1
fi

echo -e "${GREEN}Building Podman containers for ${PROJECT_NAME} demo...${NC}"
echo "Project directory: $PROJECT_DIR"
echo "Service mode: $SERVICE_MODE"
echo "Base image: $BASE_IMAGE:$VERSION"
echo "Demo image: $DEMO_IMAGE:$VERSION"
echo ""

# Step 1: Build base image (if not exists)
echo -e "${YELLOW}Step 1: Building base Topaz Agent Kit image...${NC}"
if ${CONTAINER_CMD} images --format "{{.Repository}}:{{.Tag}}" | grep -q "^${BASE_IMAGE}:${VERSION}$"; then
    echo "Base image ${BASE_IMAGE}:${VERSION} already exists, skipping build"
else
    echo "Building base image..."
    # Use Dockerfile if docker, Containerfile if podman
    if [ "$CONTAINER_CMD" = "docker" ]; then
        ${CONTAINER_CMD} build -f Dockerfile -t "${BASE_IMAGE}:${VERSION}" -t "${BASE_IMAGE}:latest" .
    else
        ${CONTAINER_CMD} build -f Containerfile -t "${BASE_IMAGE}:${VERSION}" -t "${BASE_IMAGE}:latest" .
    fi
    echo -e "${GREEN}✓ Base image built successfully${NC}"
fi

# Step 2: Build demo-specific image
echo ""
echo -e "${YELLOW}Step 2: Building demo-specific image...${NC}"

# Create a temporary Containerfile in the project directory
TEMP_CONTAINERFILE="${PROJECT_DIR}/Containerfile.demo.tmp"
cat > "$TEMP_CONTAINERFILE" <<EOF
FROM ${BASE_IMAGE}:${VERSION}

WORKDIR /app

# Copy demo project files
COPY --chown=appuser:appuser config/ ./config/
COPY --chown=appuser:appuser agents/ ./agents/
COPY --chown=appuser:appuser services/ ./services/
COPY --chown=appuser:appuser tools/ ./tools/
COPY --chown=appuser:appuser scripts/ ./scripts/
COPY --chown=appuser:appuser ui/ ./ui/
COPY --chown=appuser:appuser .env.example ./.env.example

# Copy other necessary files
COPY --chown=appuser:appuser *.md ./
COPY --chown=appuser:appuser *.txt ./

# Create data directory
RUN mkdir -p /data && chown appuser:appuser /data

ENV PYTHONUNBUFFERED=1
ENV PYTHONDONTWRITEBYTECODE=1

EXPOSE 8090 8000 8001

# Set command based on service mode
EOF

# Add appropriate CMD based on service mode
case "$SERVICE_MODE" in
    fastapi)
        echo 'CMD ["python", "-m", "topaz_agent_kit.cli.main", "serve", "fastapi", "--project", "/app", "--host", "0.0.0.0", "--port", "8090"]' >> "$TEMP_CONTAINERFILE"
        ;;
    mcp)
        echo 'CMD ["python", "-m", "topaz_agent_kit.cli.main", "serve", "mcp", "--project", "/app"]' >> "$TEMP_CONTAINERFILE"
        ;;
    services)
        echo 'CMD ["python", "-m", "topaz_agent_kit.cli.main", "serve", "services", "--project", "/app"]' >> "$TEMP_CONTAINERFILE"
        ;;
    cli)
        echo 'CMD ["python", "-m", "topaz_agent_kit.cli.main", "serve", "cli", "--project", "/app"]' >> "$TEMP_CONTAINERFILE"
        ;;
esac

# Build the demo image
${CONTAINER_CMD} build -f "$TEMP_CONTAINERFILE" -t "${DEMO_IMAGE}:${VERSION}" -t "${DEMO_IMAGE}:latest" "$PROJECT_DIR"

# Cleanup temporary file
rm -f "$TEMP_CONTAINERFILE"

echo -e "${GREEN}✓ Demo image built successfully${NC}"
echo ""
echo -e "${GREEN}Build complete!${NC}"
echo ""
echo "To run the container:"
echo "  ${CONTAINER_CMD} run -d --name ${DEMO_IMAGE} -p 8090:8090 ${DEMO_IMAGE}:${VERSION}"
echo ""
echo "To run with environment file:"
echo "  ${CONTAINER_CMD} run -d --name ${DEMO_IMAGE} -p 8090:8090 --env-file ${PROJECT_DIR}/.env ${DEMO_IMAGE}:${VERSION}"
echo ""
echo "To view logs:"
echo "  ${CONTAINER_CMD} logs -f ${DEMO_IMAGE}"
echo ""
echo "To stop:"
echo "  ${CONTAINER_CMD} stop ${DEMO_IMAGE}"
echo "  ${CONTAINER_CMD} rm ${DEMO_IMAGE}"
