#!/bin/bash
# Helper script to create all systemd services for a project
# Usage: ./create-all-services.sh <projects-dir> <project-name> [user] [mcp-name]
# Example: ./create-all-services.sh /home/nkhare/tak-projects pa nkhare topaz-mcp
#
# This creates:
# 1. Shared MCP service (if not already exists)
# 2. Per-project FastAPI service
# 3. Per-project Services (A2A) service

set -e

PROJECTS_DIR="${1:-}"
PROJECT_NAME="${2:-}"
SERVICE_USER="${3:-$USER}"
MCP_NAME="${4:-topaz-mcp}"

if [ -z "$PROJECTS_DIR" ] || [ -z "$PROJECT_NAME" ]; then
    echo "Usage: $0 <projects-dir> <project-name> [user] [mcp-name]"
    echo "Example: $0 /home/nkhare/tak-projects pa nkhare topaz-mcp"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "Creating all systemd services for project: $PROJECT_NAME"
echo "Projects directory: $PROJECTS_DIR"
echo ""

# Check if MCP service already exists
MCP_SERVICE_FILE="/etc/systemd/system/topaz-agent-kit-mcp.service"
if [ ! -f "$MCP_SERVICE_FILE" ]; then
    echo "Creating shared MCP service..."
    "$SCRIPT_DIR/create-mcp-service.sh" "$PROJECTS_DIR" "$PROJECT_NAME" "$SERVICE_USER" "$MCP_NAME"
else
    echo "MCP service already exists, skipping..."
fi

echo ""
echo "Creating FastAPI service for project '$PROJECT_NAME'..."
"$SCRIPT_DIR/create-fastapi-service.sh" "$PROJECTS_DIR" "$PROJECT_NAME" "$SERVICE_USER"

echo ""
echo "Creating Services (A2A) service for project '$PROJECT_NAME'..."
"$SCRIPT_DIR/create-services-service.sh" "$PROJECTS_DIR" "$PROJECT_NAME" "$SERVICE_USER"

echo ""
echo "✅ All services created successfully!"
echo ""
echo "Note: If log files are owned by root instead of $SERVICE_USER, run:"
echo "  sudo ./fix-log-ownership.sh $PROJECTS_DIR $PROJECT_NAME $SERVICE_USER"
echo ""
echo "Next steps:"
echo "1. Reload systemd: sudo systemctl daemon-reload"
echo "2. Enable and start services:"
echo "   sudo systemctl enable topaz-agent-kit-mcp"
echo "   sudo systemctl enable topaz-agent-kit-fastapi-${PROJECT_NAME}"
echo "   sudo systemctl enable topaz-agent-kit-services-${PROJECT_NAME}"
echo ""
echo "   sudo systemctl start topaz-agent-kit-mcp"
echo "   sudo systemctl start topaz-agent-kit-fastapi-${PROJECT_NAME}"
echo "   sudo systemctl start topaz-agent-kit-services-${PROJECT_NAME}"
echo ""
echo "3. Check status:"
echo "   sudo systemctl status topaz-agent-kit-mcp"
echo "   sudo systemctl status topaz-agent-kit-fastapi-${PROJECT_NAME}"
echo "   sudo systemctl status topaz-agent-kit-services-${PROJECT_NAME}"
echo ""
