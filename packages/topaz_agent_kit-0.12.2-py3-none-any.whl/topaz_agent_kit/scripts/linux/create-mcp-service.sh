#!/bin/bash
# Helper script to create a shared systemd service for MCP server (all projects)
# Usage: ./create-mcp-service.sh <projects-dir> <project-name> [user] [mcp-name]
# Example: ./create-mcp-service.sh /home/nkhare/tak-projects pa nkhare topaz-mcp
#
# Note: MCP service is shared across all projects. Use any project's config to get MCP settings.

set -e

PROJECTS_DIR="${1:-}"
PROJECT_NAME="${2:-}"
SERVICE_USER="${3:-$USER}"
MCP_NAME="${4:-topaz-mcp}"

if [ -z "$PROJECTS_DIR" ] || [ -z "$PROJECT_NAME" ]; then
    echo "Usage: $0 <projects-dir> <project-name> [user] [mcp-name]"
    echo "Example: $0 /home/nkhare/tak-projects pa nkhare topaz-mcp"
    exit 1
fi

PROJECT_DIR="$PROJECTS_DIR/$PROJECT_NAME"

if [ ! -d "$PROJECT_DIR" ]; then
    echo "Error: Project directory not found: $PROJECT_DIR"
    exit 1
fi

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root (use sudo)"
    exit 1
fi

# Find uv executable
UV_PATH=$(which uv 2>/dev/null || echo "")
if [ -z "$UV_PATH" ]; then
    echo "Error: 'uv' command not found in PATH"
    echo "Please install uv or ensure it's in your PATH"
    exit 1
fi

# Find topaz-agent-kit command
TAK_PATH=$(which topaz-agent-kit 2>/dev/null || echo "")
if [ -z "$TAK_PATH" ]; then
    USE_UV_RUN=true
else
    USE_UV_RUN=false
fi

# Get absolute paths
PROJECTS_DIR=$(realpath "$PROJECTS_DIR")
PROJECT_DIR="$PROJECTS_DIR/$PROJECT_NAME"

# Find config file to get MCP port
CONFIG_FILE=""
if [ -f "$PROJECT_DIR/config/pipelines.yml" ]; then
    CONFIG_FILE="$PROJECT_DIR/config/pipelines.yml"
elif [ -f "$PROJECT_DIR/config/common.yml" ]; then
    CONFIG_FILE="$PROJECT_DIR/config/common.yml"
else
    echo "Error: No config file found (pipelines.yml or common.yml)"
    exit 1
fi

# Extract MCP port from config (use first MCP server)
MCP_PORT=$(grep -A 5 "mcp:" "$CONFIG_FILE" | grep "url:" | grep -oP ':\K[0-9]+' | head -1)
if [ -z "$MCP_PORT" ]; then
    echo "Error: Could not find MCP port in config file"
    exit 1
fi

# Create log directory (shared for MCP)
LOG_DIR="$PROJECTS_DIR/logs"
mkdir -p "$LOG_DIR"
chown -R "$SERVICE_USER:$SERVICE_USER" "$LOG_DIR"
# Ensure log files are owned by service user (fix any root-owned files)
find "$LOG_DIR" -type f -user root -exec chown "$SERVICE_USER:$SERVICE_USER" {} \; 2>/dev/null || true

# Service name (shared MCP service)
SERVICE_NAME="topaz-agent-kit-mcp"

# Create systemd service file
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"

echo "Creating shared MCP systemd service: $SERVICE_NAME"
echo "Projects directory: $PROJECTS_DIR"
echo "Using project '$PROJECT_NAME' for MCP configuration"
echo "MCP name: $MCP_NAME"
echo "MCP port: $MCP_PORT"
echo "User: $SERVICE_USER"
echo ""

# Determine command to use
# MCP service uses first project's config, but can serve all projects
if [ "$USE_UV_RUN" = true ]; then
    EXEC_START="$UV_PATH run topaz-agent-kit serve mcp -p \"$PROJECT_DIR\" --name \"$MCP_NAME\""
else
    EXEC_START="$TAK_PATH serve mcp -p \"$PROJECT_DIR\" --name \"$MCP_NAME\""
fi

# Create service file
cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Topaz Agent Kit - Shared MCP Server (All Projects)
After=network.target

[Service]
Type=simple
User=${SERVICE_USER}
WorkingDirectory=${PROJECTS_DIR}
ExecStart=${EXEC_START}
Restart=always
RestartSec=10
StandardOutput=append:${LOG_DIR}/mcp-service.log
StandardError=append:${LOG_DIR}/mcp-service-error.log

# Environment variables
Environment="PATH=/usr/local/bin:/usr/bin:/bin"
Environment="TOPAZ_PROJECTS_DIR=${PROJECTS_DIR}"
Environment="TOPAZ_LOG_DIR=${LOG_DIR}"

# Resource limits
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF

echo "✅ Service file created: $SERVICE_FILE"
echo ""
echo "Next steps:"
echo "1. Review the service file: sudo cat $SERVICE_FILE"
echo "2. Reload systemd: sudo systemctl daemon-reload"
echo "3. Enable service: sudo systemctl enable $SERVICE_NAME"
echo "4. Start service: sudo systemctl start $SERVICE_NAME"
echo "5. Check status: sudo systemctl status $SERVICE_NAME"
echo "6. View logs: sudo journalctl -u $SERVICE_NAME -f"
echo ""
