#!/bin/bash
# Helper script to fix log file ownership if they're owned by root
# Usage: ./fix-log-ownership.sh <projects-dir> <project-name> [user]
# Example: ./fix-log-ownership.sh /home/nkhare/tak-projects pa nkhare

set -e

PROJECTS_DIR="${1:-}"
PROJECT_NAME="${2:-}"
SERVICE_USER="${3:-$USER}"

if [ -z "$PROJECTS_DIR" ] || [ -z "$PROJECT_NAME" ]; then
    echo "Usage: $0 <projects-dir> <project-name> [user]"
    echo "Example: $0 /home/nkhare/tak-projects pa nkhare"
    exit 1
fi

PROJECT_DIR="$PROJECTS_DIR/$PROJECT_NAME"

if [ ! -d "$PROJECT_DIR" ]; then
    echo "Error: Project directory not found: $PROJECT_DIR"
    exit 1
fi

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root (use sudo)"
    exit 1
fi

# Get absolute paths
PROJECTS_DIR=$(realpath "$PROJECTS_DIR")
PROJECT_DIR="$PROJECTS_DIR/$PROJECT_NAME"

# Fix shared logs directory
SHARED_LOG_DIR="$PROJECTS_DIR/logs"
if [ -d "$SHARED_LOG_DIR" ]; then
    echo "Fixing ownership for shared logs: $SHARED_LOG_DIR"
    chown -R "$SERVICE_USER:$SERVICE_USER" "$SHARED_LOG_DIR"
    echo "✅ Fixed ownership for shared logs"
fi

# Fix per-project logs directory
PROJECT_LOG_DIR="$PROJECT_DIR/logs"
if [ -d "$PROJECT_LOG_DIR" ]; then
    echo "Fixing ownership for project logs: $PROJECT_LOG_DIR"
    chown -R "$SERVICE_USER:$SERVICE_USER" "$PROJECT_LOG_DIR"
    echo "✅ Fixed ownership for project logs"
fi

# Check for any root-owned log files
ROOT_OWNED=$(find "$PROJECTS_DIR" -type f -name "*.log" -o -name "*.log.*" 2>/dev/null | xargs -r ls -l 2>/dev/null | grep " root " | wc -l || echo "0")
if [ "$ROOT_OWNED" -gt 0 ]; then
    echo "Warning: Found $ROOT_OWNED root-owned log files"
    echo "Fixing ownership for all log files..."
    find "$PROJECTS_DIR" -type f \( -name "*.log" -o -name "*.log.*" \) -user root -exec chown "$SERVICE_USER:$SERVICE_USER" {} \; 2>/dev/null || true
    echo "✅ Fixed ownership for all log files"
else
    echo "✅ No root-owned log files found"
fi

echo ""
echo "Ownership fix complete. Log files should now be owned by $SERVICE_USER"
