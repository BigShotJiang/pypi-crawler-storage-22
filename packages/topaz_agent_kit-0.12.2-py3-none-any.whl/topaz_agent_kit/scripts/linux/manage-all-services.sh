#!/bin/bash
# Helper script to manage ALL Topaz Agent Kit services at once
# Usage: ./manage-all-services.sh <action>
# Actions: start, stop, restart, status, list
# Example: ./manage-all-services.sh restart

set -e

ACTION="${1:-}"

if [ -z "$ACTION" ]; then
    echo "Usage: $0 <action>"
    echo "Actions: start, stop, restart, status, list"
    echo "Example: $0 restart"
    echo "Example: $0 status"
    echo "Example: $0 list"
    exit 1
fi

# Find all Topaz Agent Kit services
MCP_SERVICE="topaz-agent-kit-mcp"
FASTAPI_SERVICES=$(systemctl list-unit-files | grep -E "topaz-agent-kit-fastapi-" | awk '{print $1}' || echo "")
SERVICES_SERVICES=$(systemctl list-unit-files | grep -E "topaz-agent-kit-services-" | awk '{print $1}' || echo "")

case "$ACTION" in
    start)
        echo "Starting all Topaz Agent Kit services..."
        
        # Start MCP service first (shared, needed by all)
        if systemctl list-unit-files | grep -q "^${MCP_SERVICE}"; then
            echo "  Starting $MCP_SERVICE..."
            sudo systemctl start "$MCP_SERVICE" || echo "    ⚠️  Failed to start $MCP_SERVICE"
        fi
        
        # Start all FastAPI services
        for service in $FASTAPI_SERVICES; do
            echo "  Starting $service..."
            sudo systemctl start "$service" || echo "    ⚠️  Failed to start $service"
        done
        
        # Start all Services (A2A) services
        for service in $SERVICES_SERVICES; do
            echo "  Starting $service..."
            sudo systemctl start "$service" || echo "    ⚠️  Failed to start $service"
        done
        
        echo "✅ All services started"
        ;;
    stop)
        echo "Stopping all Topaz Agent Kit services..."
        
        # Stop all Services (A2A) services first
        for service in $SERVICES_SERVICES; do
            echo "  Stopping $service..."
            sudo systemctl stop "$service" || echo "    ⚠️  Failed to stop $service"
        done
        
        # Stop all FastAPI services
        for service in $FASTAPI_SERVICES; do
            echo "  Stopping $service..."
            sudo systemctl stop "$service" || echo "    ⚠️  Failed to stop $service"
        done
        
        # Stop MCP service last (shared, affects all projects)
        if systemctl list-unit-files | grep -q "^${MCP_SERVICE}"; then
            echo "  Stopping $MCP_SERVICE (shared - affects all projects)..."
            sudo systemctl stop "$MCP_SERVICE" || echo "    ⚠️  Failed to stop $MCP_SERVICE"
        fi
        
        echo "✅ All services stopped"
        ;;
    restart)
        echo "Restarting all Topaz Agent Kit services..."
        
        # Restart MCP service first (shared, needed by all)
        if systemctl list-unit-files | grep -q "^${MCP_SERVICE}"; then
            echo "  Restarting $MCP_SERVICE..."
            sudo systemctl restart "$MCP_SERVICE" || echo "    ⚠️  Failed to restart $MCP_SERVICE"
        fi
        
        # Restart all FastAPI services
        for service in $FASTAPI_SERVICES; do
            echo "  Restarting $service..."
            sudo systemctl restart "$service" || echo "    ⚠️  Failed to restart $service"
        done
        
        # Restart all Services (A2A) services
        for service in $SERVICES_SERVICES; do
            echo "  Restarting $service..."
            sudo systemctl restart "$service" || echo "    ⚠️  Failed to restart $service"
        done
        
        echo "✅ All services restarted"
        ;;
    status)
        echo "Status of all Topaz Agent Kit services:"
        echo ""
        
        # MCP service status
        if systemctl list-unit-files | grep -q "^${MCP_SERVICE}"; then
            echo "=== MCP Service (Shared) ==="
            sudo systemctl status "$MCP_SERVICE" --no-pager -l || echo "  Not running"
            echo ""
        fi
        
        # FastAPI services status
        if [ -n "$FASTAPI_SERVICES" ]; then
            echo "=== FastAPI Services ==="
            for service in $FASTAPI_SERVICES; do
                echo "--- $service ---"
                sudo systemctl status "$service" --no-pager -l | head -5 || echo "  Not running"
                echo ""
            done
        fi
        
        # Services (A2A) status
        if [ -n "$SERVICES_SERVICES" ]; then
            echo "=== Services (A2A) ==="
            for service in $SERVICES_SERVICES; do
                echo "--- $service ---"
                sudo systemctl status "$service" --no-pager -l | head -5 || echo "  Not running"
                echo ""
            done
        fi
        ;;
    list)
        echo "All Topaz Agent Kit services:"
        echo ""
        
        if systemctl list-unit-files | grep -q "^${MCP_SERVICE}"; then
            echo "MCP Service (Shared):"
            echo "  - $MCP_SERVICE"
            echo ""
        fi
        
        if [ -n "$FASTAPI_SERVICES" ]; then
            echo "FastAPI Services:"
            for service in $FASTAPI_SERVICES; do
                echo "  - $service"
            done
            echo ""
        fi
        
        if [ -n "$SERVICES_SERVICES" ]; then
            echo "Services (A2A):"
            for service in $SERVICES_SERVICES; do
                echo "  - $service"
            done
            echo ""
        fi
        
        if [ -z "$FASTAPI_SERVICES" ] && [ -z "$SERVICES_SERVICES" ] && ! systemctl list-unit-files | grep -q "^${MCP_SERVICE}"; then
            echo "No Topaz Agent Kit services found"
        fi
        ;;
    *)
        echo "Error: Unknown action: $ACTION"
        echo "Valid actions: start, stop, restart, status, list"
        exit 1
        ;;
esac
