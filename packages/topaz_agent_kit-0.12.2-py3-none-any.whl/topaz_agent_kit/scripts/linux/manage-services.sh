#!/bin/bash
# Helper script to manage Topaz Agent Kit services
# Usage: ./manage-services.sh <action> <project-name>
# Actions: start, stop, restart, status, logs
# Example: ./manage-services.sh restart pa

set -e

ACTION="${1:-}"
PROJECT_NAME="${2:-}"

if [ -z "$ACTION" ] || [ -z "$PROJECT_NAME" ]; then
    echo "Usage: $0 <action> <project-name>"
    echo "Actions: start, stop, restart, status, logs"
    echo "Example: $0 restart pa"
    echo "Example: $0 status pa"
    echo "Example: $0 logs pa"
    exit 1
fi

FASTAPI_SERVICE="topaz-agent-kit-fastapi-${PROJECT_NAME}"
SERVICES_SERVICE="topaz-agent-kit-services-${PROJECT_NAME}"
MCP_SERVICE="topaz-agent-kit-mcp"

case "$ACTION" in
    start)
        echo "Starting services for project: $PROJECT_NAME"
        sudo systemctl start "$MCP_SERVICE" || echo "MCP service not running (may be OK)"
        sudo systemctl start "$FASTAPI_SERVICE"
        sudo systemctl start "$SERVICES_SERVICE"
        echo "✅ Services started"
        ;;
    stop)
        echo "Stopping services for project: $PROJECT_NAME"
        sudo systemctl stop "$FASTAPI_SERVICE"
        sudo systemctl stop "$SERVICES_SERVICE"
        echo "✅ Services stopped"
        echo "Note: MCP service is shared - not stopping (affects all projects)"
        ;;
    restart)
        echo "Restarting services for project: $PROJECT_NAME"
        sudo systemctl restart "$FASTAPI_SERVICE"
        sudo systemctl restart "$SERVICES_SERVICE"
        echo "✅ Services restarted"
        echo "Note: MCP service is shared - not restarting (affects all projects)"
        ;;
    status)
        echo "Status of services for project: $PROJECT_NAME"
        echo ""
        echo "=== MCP Service (Shared) ==="
        sudo systemctl status "$MCP_SERVICE" --no-pager || echo "MCP service not found"
        echo ""
        echo "=== FastAPI Service ==="
        sudo systemctl status "$FASTAPI_SERVICE" --no-pager || echo "FastAPI service not found"
        echo ""
        echo "=== Services (A2A) Service ==="
        sudo systemctl status "$SERVICES_SERVICE" --no-pager || echo "Services service not found"
        ;;
    logs)
        echo "Viewing logs for project: $PROJECT_NAME"
        echo "Press Ctrl+C to exit"
        echo ""
        echo "=== FastAPI Logs ==="
        sudo journalctl -u "$FASTAPI_SERVICE" -f
        ;;
    *)
        echo "Error: Unknown action: $ACTION"
        echo "Valid actions: start, stop, restart, status, logs"
        exit 1
        ;;
esac
