#!/bin/bash
# Run script for containerized demos (Docker/Podman compatible)
# Usage: ./scripts/run-podman-demo.sh -p <project_name> [options]
# 
# Works with both Docker and Podman:
# - Auto-detects 'docker' or 'podman' command
# - Or set CONTAINER_CMD=docker or CONTAINER_CMD=podman explicitly

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Default values
PROJECT_NAME=""
SERVICE_MODE="fastapi"
PORT=8090
CONTAINER_NAME=""
ENV_FILE=""
DETACHED=true
NETWORK=""

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -p|--project)
            PROJECT_NAME="$2"
            shift 2
            ;;
        -m|--mode)
            SERVICE_MODE="$2"
            shift 2
            ;;
        --port)
            PORT="$2"
            shift 2
            ;;
        -n|--name)
            CONTAINER_NAME="$2"
            shift 2
            ;;
        -e|--env-file)
            ENV_FILE="$2"
            shift 2
            ;;
        --network)
            NETWORK="$2"
            shift 2
            ;;
        --foreground|-f)
            DETACHED=false
            shift
            ;;
        -h|--help)
            echo "Usage: $0 -p <project_name> [options]"
            echo ""
            echo "Options:"
            echo "  -p, --project <name>    Project name (required)"
            echo "  -m, --mode <mode>      Service mode: fastapi (default), mcp, services, cli"
            echo "  --port <port>          Port to expose (default: 8090)"
            echo "  -n, --name <name>      Container name (default: topaz-demo-<project>)"
            echo "  -e, --env-file <file>  Path to .env file"
            echo "  --network <name>       Podman network name"
            echo "  -f, --foreground       Run in foreground (don't detach)"
            echo "  -h, --help             Show this help message"
            echo ""
            echo "Examples:"
            echo "  $0 -p pa"
            echo "  $0 -p pa -m mcp --port 8000"
            echo "  $0 -p pa -e projects/pa/.env --network mynetwork"
            exit 0
            ;;
        *)
            echo -e "${RED}Unknown option: $1${NC}"
            exit 1
            ;;
    esac
done

# Check if project name is provided
if [ -z "$PROJECT_NAME" ]; then
    echo -e "${RED}Error: Project name is required${NC}"
    echo "Use -p or --project to specify project name"
    echo "Run '$0 --help' for usage information"
    exit 1
fi

# Set default container name if not provided
if [ -z "$CONTAINER_NAME" ]; then
    CONTAINER_NAME="topaz-demo-${PROJECT_NAME}"
fi

DEMO_IMAGE="topaz-demo-${PROJECT_NAME}:latest"
PROJECT_DIR="projects/${PROJECT_NAME}"

# Detect container command (docker or podman)
if [ -z "$CONTAINER_CMD" ]; then
    if command -v docker &> /dev/null; then
        CONTAINER_CMD="docker"
    elif command -v podman &> /dev/null; then
        CONTAINER_CMD="podman"
    else
        echo -e "${RED}Error: Neither docker nor podman found. Please install Docker Desktop or Podman.${NC}"
        exit 1
    fi
fi

echo -e "${GREEN}Using container command: ${CONTAINER_CMD}${NC}"

# Check if image exists
if ! ${CONTAINER_CMD} images --format "{{.Repository}}:{{.Tag}}" | grep -q "^topaz-demo-${PROJECT_NAME}:latest$"; then
    echo -e "${YELLOW}Image ${DEMO_IMAGE} not found. Building it first...${NC}"
    CONTAINER_CMD="$CONTAINER_CMD" ./scripts/build-podman-demo.sh "$PROJECT_NAME" "$SERVICE_MODE"
fi

# Check if container already exists
if ${CONTAINER_CMD} ps -a --format "{{.Names}}" | grep -q "^${CONTAINER_NAME}$"; then
    echo -e "${YELLOW}Container ${CONTAINER_NAME} already exists${NC}"
    read -p "Remove existing container? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        ${CONTAINER_CMD} rm -f "${CONTAINER_NAME}"
    else
        echo "Exiting. Use a different container name with -n option"
        exit 1
    fi
fi

# Build container run command
RUN_CMD="${CONTAINER_CMD} run"

if [ "$DETACHED" = true ]; then
    RUN_CMD="${RUN_CMD} -d"
else
    RUN_CMD="${RUN_CMD} -it"
fi

RUN_CMD="${RUN_CMD} --name ${CONTAINER_NAME}"

# Add port mapping
RUN_CMD="${RUN_CMD} -p ${PORT}:8090"

# Add environment file if provided
if [ -n "$ENV_FILE" ]; then
    if [ -f "$ENV_FILE" ]; then
        RUN_CMD="${RUN_CMD} --env-file ${ENV_FILE}"
    else
        echo -e "${YELLOW}Warning: Environment file not found: ${ENV_FILE}${NC}"
    fi
fi

# Add network if provided
if [ -n "$NETWORK" ]; then
    RUN_CMD="${RUN_CMD} --network ${NETWORK}"
fi

# Add volume for data persistence (optional)
RUN_CMD="${RUN_CMD} -v ${CONTAINER_NAME}-data:/data"

# Add image
RUN_CMD="${RUN_CMD} ${DEMO_IMAGE}"

echo -e "${GREEN}Starting container: ${CONTAINER_NAME}${NC}"
echo "Command: ${RUN_CMD}"
echo ""

# Execute the command
eval "$RUN_CMD"

if [ "$DETACHED" = true ]; then
    echo -e "${GREEN}Container started successfully${NC}"
    echo ""
    echo "Container name: ${CONTAINER_NAME}"
    echo "Access the service at: http://localhost:${PORT}"
    echo ""
    echo "Useful commands:"
    echo "  View logs:    ${CONTAINER_CMD} logs -f ${CONTAINER_NAME}"
    echo "  Stop:          ${CONTAINER_CMD} stop ${CONTAINER_NAME}"
    echo "  Start:         ${CONTAINER_CMD} start ${CONTAINER_NAME}"
    echo "  Remove:        ${CONTAINER_CMD} rm -f ${CONTAINER_NAME}"
    echo "  Shell access:  ${CONTAINER_CMD} exec -it ${CONTAINER_NAME} /bin/bash"
else
    echo -e "${GREEN}Container running in foreground. Press Ctrl+C to stop.${NC}"
fi
