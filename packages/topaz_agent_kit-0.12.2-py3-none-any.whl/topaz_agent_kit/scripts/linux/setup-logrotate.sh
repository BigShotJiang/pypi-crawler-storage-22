#!/bin/bash
# Helper script to set up logrotate for Topaz Agent Kit services
# Usage: ./setup-logrotate.sh <projects-dir> [user]
# Example: ./setup-logrotate.sh /home/nkhare/tak-projects nkhare

set -e

PROJECTS_DIR="${1:-}"
SERVICE_USER="${2:-$USER}"

if [ -z "$PROJECTS_DIR" ]; then
    echo "Usage: $0 <projects-dir> [user]"
    echo "Example: $0 /home/nkhare/tak-projects nkhare"
    exit 1
fi

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root (use sudo)"
    exit 1
fi

# Get absolute path
PROJECTS_DIR=$(realpath "$PROJECTS_DIR")

# Create logrotate config file
LOGROTATE_FILE="/etc/logrotate.d/topaz-agent-kit"

echo "Setting up logrotate for Topaz Agent Kit"
echo "Projects directory: $PROJECTS_DIR"
echo "User: $SERVICE_USER"
echo ""

# Create logrotate configuration
cat > "$LOGROTATE_FILE" <<EOF
# Topaz Agent Kit log rotation configuration
# Rotates logs daily
# Keeps 30 rotated files (30 days)
# Compresses old logs

# Shared MCP service logs
${PROJECTS_DIR}/logs/*.log {
    daily
    rotate 30
    compress
    delaycompress
    missingok
    notifempty
    create 0644 ${SERVICE_USER} ${SERVICE_USER}
    sharedscripts
    postrotate
        # Reload services to reopen log files (optional, services handle this gracefully)
        systemctl reload topaz-agent-kit-mcp 2>/dev/null || true
    endscript
}

# Per-project service logs (FastAPI and Services)
${PROJECTS_DIR}/*/logs/*.log {
    daily
    rotate 30
    compress
    delaycompress
    missingok
    notifempty
    create 0644 ${SERVICE_USER} ${SERVICE_USER}
    sharedscripts
    postrotate
        # Reload services to reopen log files (optional, services handle this gracefully)
        systemctl reload topaz-agent-kit-fastapi-* 2>/dev/null || true
        systemctl reload topaz-agent-kit-services-* 2>/dev/null || true
    endscript
}
EOF

echo "✅ Logrotate configuration created: $LOGROTATE_FILE"
echo ""
echo "Configuration details:"
echo "  - Rotate logs daily"
echo "  - Keep 30 rotated files (30 days of logs)"
echo "  - Compress old logs"
echo "  - Owner: ${SERVICE_USER}:${SERVICE_USER}"
echo ""
echo "Logrotate will run daily via cron. To test manually:"
echo "  sudo logrotate -d $LOGROTATE_FILE  # Dry run (test)"
echo "  sudo logrotate -f $LOGROTATE_FILE   # Force rotation (test)"
echo ""
echo "To verify logrotate is working:"
echo "  sudo logrotate -v $LOGROTATE_FILE"
echo ""
