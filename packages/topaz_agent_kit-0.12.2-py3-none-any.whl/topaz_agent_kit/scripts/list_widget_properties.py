#!/usr/bin/env python3
"""
Script to list all widget properties
Usage: python scripts/list_widget_properties.py [widget_type]
"""

import sys
import json
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from topaz_agent_kit.core.widget_registry import WidgetRegistry


def format_props(props: dict) -> str:
    """Format properties dictionary for display"""
    if not props:
        return "  (none)"
    
    lines = []
    for key, value in props.items():
        value_str = json.dumps(value) if isinstance(value, (dict, list)) else repr(value)
        lines.append(f"  - {key}: {value_str}")
    return "\n".join(lines)


def list_widget(widget_type: str):
    """List properties for a specific widget"""
    metadata = WidgetRegistry.get_metadata(widget_type)
    
    if not metadata:
        print(f"❌ Widget '{widget_type}' not found")
        return
    
    print(f"\n{'='*60}")
    print(f"Widget: {widget_type}")
    print(f"{'='*60}")
    print(f"Category: {metadata.category}")
    print(f"Description: {metadata.description}")
    print(f"Supports Editing: {'✅ Yes' if metadata.supports_editing else '❌ No (read-only)'}")
    print(f"\nDefault Properties:")
    print(format_props(metadata.default_props))
    
    if metadata.validation_schema:
        print(f"\nValidation Schema:")
        print(json.dumps(metadata.validation_schema, indent=2))
    else:
        print(f"\nValidation Schema: (uses common validation)")


def list_all_widgets(category: str = None):
    """List all widgets, optionally filtered by category"""
    widgets = WidgetRegistry.list_widgets(category)
    
    if category:
        print(f"\n{'='*60}")
        print(f"Widgets in category: {category}")
        print(f"{'='*60}")
    else:
        print(f"\n{'='*60}")
        print(f"All Widgets")
        print(f"{'='*60}")
    
    # Group by category
    by_category = {}
    for widget in widgets:
        cat = widget.category
        if cat not in by_category:
            by_category[cat] = []
        by_category[cat].append(widget)
    
    for cat, widget_list in sorted(by_category.items()):
        print(f"\n📁 {cat.upper()}")
        print("-" * 60)
        for widget in sorted(widget_list, key=lambda w: w.widget_type):
            edit_icon = "✏️" if widget.supports_editing else "👁️"
            print(f"  {edit_icon} {widget.widget_type:30} - {widget.description}")
            if widget.default_props:
                props_str = ", ".join(f"{k}={v}" for k, v in widget.default_props.items()[:3])
                if len(widget.default_props) > 3:
                    props_str += "..."
                print(f"      Props: {props_str}")


def main():
    if len(sys.argv) > 1:
        widget_type = sys.argv[1]
        if widget_type == "--help" or widget_type == "-h":
            print("Usage: python scripts/list_widget_properties.py [widget_type] [category]")
            print("\nExamples:")
            print("  python scripts/list_widget_properties.py")
            print("  python scripts/list_widget_properties.py text")
            print("  python scripts/list_widget_properties.py input")
            sys.exit(0)
        
        # Check if it's a category
        categories = ["input", "viewer", "selection", "layout", "array", "rich", "container"]
        if widget_type in categories:
            list_all_widgets(widget_type)
        else:
            list_widget(widget_type)
    else:
        list_all_widgets()


if __name__ == "__main__":
    main()
