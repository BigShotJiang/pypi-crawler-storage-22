#!/usr/bin/env python3
"""Resize logo to match reference logo dimensions.

This script resizes a logo image to match a reference logo's canvas size and visual scale.
It extracts the actual logo content, scales it appropriately, and centers it on a transparent
canvas matching the reference logo's dimensions.

Usage:
    python scripts/resize_logo.py <source_logo> <reference_logo> [--output OUTPUT] [--scale SCALE]
    uv run -m topaz_agent_kit.scripts.resize_logo <source_logo> <reference_logo> [--output OUTPUT] [--scale SCALE]

Examples:
    # Resize mcclatchy-logo.png to match bp-logo.png dimensions
    python scripts/resize_logo.py mcclatchy-logo.png bp-logo.png

    # Resize with custom output path
    python scripts/resize_logo.py logo.png reference.png --output resized_logo.png

    # Resize with custom scale factor (0.5 = 50% of reference size, 1.0 = 100%)
    python scripts/resize_logo.py logo.png reference.png --scale 0.9
"""

import argparse
import sys
from pathlib import Path
from typing import Tuple

try:
    from PIL import Image
    import numpy as np
except ImportError as e:
    print(f"Error: Required dependencies not found. Install with: pip install Pillow numpy")
    print(f"Details: {e}")
    sys.exit(1)


def find_logo_bounds(image: Image.Image) -> Tuple[int, int, int, int]:
    """Find the bounding box of the actual logo content in an image.
    
    Args:
        image: PIL Image object
        
    Returns:
        Tuple of (left, top, right, bottom) bounding box coordinates
    """
    array = np.array(image)
    
    if image.mode == 'RGBA':
        # Find non-transparent, non-black pixels
        alpha = array[:, :, 3] > 0
        non_black = np.any(array[:, :, :3] != [0, 0, 0], axis=2)
        mask = alpha & non_black
    elif image.mode == 'RGB':
        # Find non-black pixels
        mask = np.any(array != [0, 0, 0], axis=2)
    elif image.mode == 'P':
        # Palette mode - convert to RGBA first
        image = image.convert('RGBA')
        array = np.array(image)
        alpha = array[:, :, 3] > 0
        non_black = np.any(array[:, :, :3] != [0, 0, 0], axis=2)
        mask = alpha & non_black
    else:
        # For other modes, try to find non-zero pixels
        if len(array.shape) > 2:
            mask = np.any(array != 0, axis=2)
        else:
            mask = array != 0
    
    rows = np.any(mask, axis=1) if len(mask.shape) > 1 else mask
    cols = np.any(mask, axis=0) if len(mask.shape) > 1 else mask
    
    if np.any(rows) and np.any(cols):
        top = np.where(rows)[0][0]
        bottom = np.where(rows)[0][-1] + 1
        left = np.where(cols)[0][0]
        right = np.where(cols)[0][-1] + 1
        return (left, top, right, bottom)
    else:
        # No content found, return full image bounds
        return (0, 0, image.width, image.height)


def get_logo_size(image: Image.Image) -> Tuple[int, int]:
    """Get the actual logo content size.
    
    Args:
        image: PIL Image object
        
    Returns:
        Tuple of (width, height) of the logo content
    """
    left, top, right, bottom = find_logo_bounds(image)
    return (right - left, bottom - top)


def resize_logo(
    source_path: Path,
    reference_path: Path,
    output_path: Path,
    scale_factor: float = 0.85
) -> None:
    """Resize source logo to match reference logo dimensions.
    
    Args:
        source_path: Path to source logo image
        reference_path: Path to reference logo image
        output_path: Path to save resized logo
        scale_factor: Multiplier for logo size relative to reference (default: 0.85 = 85%)
    """
    # Open images
    try:
        reference_logo = Image.open(reference_path)
        source_logo = Image.open(source_path)
    except Exception as e:
        print(f"Error opening images: {e}")
        sys.exit(1)
    
    # Get reference logo dimensions
    ref_width, ref_height = reference_logo.size
    print(f"Reference logo canvas: {ref_width}x{ref_height}")
    
    # Get actual logo sizes
    ref_logo_size = get_logo_size(reference_logo)
    ref_logo_max = max(ref_logo_size)
    print(f"Reference logo content: {ref_logo_size[0]}x{ref_logo_size[1]} (max: {ref_logo_max}px)")
    
    # Extract source logo content
    left, top, right, bottom = find_logo_bounds(source_logo)
    source_logo_cropped = source_logo.crop((left, top, right, bottom))
    source_logo_size = source_logo_cropped.size
    source_logo_max = max(source_logo_size)
    print(f"Source logo content: {source_logo_size[0]}x{source_logo_size[1]} (max: {source_logo_max}px)")
    
    # Calculate scale to match reference logo size
    scale = (ref_logo_max / source_logo_max) * scale_factor
    print(f"Scale factor: {scale:.2f} (with {scale_factor:.2f} multiplier)")
    
    # Scale up the source logo
    new_width = int(source_logo_size[0] * scale)
    new_height = int(source_logo_size[1] * scale)
    print(f"Scaled logo size: {new_width}x{new_height}")
    
    # Ensure source logo is in RGBA mode for transparency
    if source_logo_cropped.mode != 'RGBA':
        source_logo_cropped = source_logo_cropped.convert('RGBA')
    
    # Resize with high-quality resampling
    source_logo_scaled = source_logo_cropped.resize(
        (new_width, new_height),
        Image.Resampling.LANCZOS
    )
    
    # Create new transparent canvas with reference logo dimensions
    new_image = Image.new('RGBA', (ref_width, ref_height), (0, 0, 0, 0))
    
    # Center the scaled logo
    x_offset = (ref_width - new_width) // 2
    y_offset = (ref_height - new_height) // 2
    print(f"Centering at: ({x_offset}, {y_offset})")
    
    # Paste the scaled logo
    new_image.paste(source_logo_scaled, (x_offset, y_offset), source_logo_scaled)
    
    # Save the result
    output_path.parent.mkdir(parents=True, exist_ok=True)
    new_image.save(output_path, 'PNG')
    print(f"Successfully saved resized logo to: {output_path}")
    print(f"Final image: {new_image.size}, mode: {new_image.mode}")


def main():
    """Main entry point for the script."""
    parser = argparse.ArgumentParser(
        description="Resize logo to match reference logo dimensions and visual scale",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    
    parser.add_argument(
        'source',
        type=Path,
        help='Path to source logo image to resize'
    )
    
    parser.add_argument(
        'reference',
        type=Path,
        help='Path to reference logo image (target dimensions)'
    )
    
    parser.add_argument(
        '--output', '-o',
        type=Path,
        default=None,
        help='Output path for resized logo (default: overwrites source)'
    )
    
    parser.add_argument(
        '--scale',
        type=float,
        default=0.85,
        help='Scale factor multiplier for logo size relative to reference (default: 0.85 = 85%%)'
    )
    
    args = parser.parse_args()
    
    # Validate inputs
    if not args.source.exists():
        print(f"Error: Source logo not found: {args.source}")
        sys.exit(1)
    
    if not args.reference.exists():
        print(f"Error: Reference logo not found: {args.reference}")
        sys.exit(1)
    
    # Determine output path
    output_path = args.output if args.output else args.source
    
    # Resize the logo
    resize_logo(
        source_path=args.source,
        reference_path=args.reference,
        output_path=output_path,
        scale_factor=args.scale
    )


if __name__ == '__main__':
    main()
