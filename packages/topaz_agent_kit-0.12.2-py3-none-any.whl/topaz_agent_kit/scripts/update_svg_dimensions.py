import re
from pathlib import Path


TARGET_DIRS = [
    Path(
        "src/topaz_agent_kit/templates/starters/pa/ui/static/assets"
    ),
    Path(
        "src/topaz_agent_kit/templates/starters/ensemble/ui/static/assets"
    ),
    Path(
        "src/topaz_agent_kit/templates/starters/icp/ui/static/assets"
    ),
]


WIDTH_VALUE = "256"
HEIGHT_VALUE = "256"
STROKE_WIDTH_VALUE = "1.5"


def update_svg_content(content: str) -> str:
    """
    Normalize SVG root width/height to 256 and stroke-width to 1.5.
    Keeps all other attributes untouched.
    """
    # Only operate if there is an <svg ...> tag
    match = re.search(r"<svg[^>]*>", content, flags=re.IGNORECASE)
    if not match:
        return content

    svg_tag = match.group(0)
    updated_tag = svg_tag

    # Ensure width/height
    if 'width="' in updated_tag:
        # Use word boundary to avoid matching stroke-width
        updated_tag = re.sub(r'\bwidth="[^"]*"', f'width="{WIDTH_VALUE}"', updated_tag)
    else:
        # Insert width right after <svg
        updated_tag = updated_tag.replace(
            "<svg", f'<svg width="{WIDTH_VALUE}"', 1
        )

    if 'height="' in updated_tag:
        updated_tag = re.sub(r'\bheight="[^"]*"', f'height="{HEIGHT_VALUE}"', updated_tag)
    else:
        # Place height after width if width was added, or just after <svg if not
        if f'width="{WIDTH_VALUE}"' in updated_tag:
            updated_tag = updated_tag.replace(
                f'width="{WIDTH_VALUE}"',
                f'width="{WIDTH_VALUE}" height="{HEIGHT_VALUE}"',
                1,
            )
        else:
            updated_tag = updated_tag.replace(
                "<svg", f'<svg height="{HEIGHT_VALUE}"', 1
            )

    # Normalize stroke-width on the root <svg> tag
    if 'stroke-width="' in updated_tag:
        updated_tag = re.sub(
            r'stroke-width="[^"]*"',
            f'stroke-width="{STROKE_WIDTH_VALUE}"',
            updated_tag,
        )
    else:
        # Ensure root svg has a stroke-width if none existed at all
        if 'stroke="' in updated_tag:
            updated_tag = re.sub(
                r'(stroke="[^"]*")',
                rf'\1 stroke-width="{STROKE_WIDTH_VALUE}"',
                updated_tag,
                count=1,
            )
        else:
            # Otherwise append before closing >
            updated_tag = updated_tag[:-1] + f' stroke-width="{STROKE_WIDTH_VALUE}">'

    # Replace original svg tag in content with updated one
    start, end = match.span()
    result = content[:start] + updated_tag + content[end:]
    # Clean up any accidental duplicate quote/angle introduced by earlier runs
    result = result.replace('>">', '">')
    result = result.replace('"">', '">')
    return result


def main() -> None:
    for base in TARGET_DIRS:
        for path in base.glob("*.svg"):
            text = path.read_text(encoding="utf-8")
            updated = update_svg_content(text)
            if updated != text:
                path.write_text(updated, encoding="utf-8")


if __name__ == "__main__":
    main()

