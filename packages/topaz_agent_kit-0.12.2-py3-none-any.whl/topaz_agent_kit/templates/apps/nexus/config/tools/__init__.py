# App-specific tools (e.g. earth_map_tools) are loaded by app assistant when app_tools config references this package.
