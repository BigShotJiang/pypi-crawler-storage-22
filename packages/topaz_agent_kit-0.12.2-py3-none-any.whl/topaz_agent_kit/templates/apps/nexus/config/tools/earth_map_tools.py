"""
Earth Map app-specific tools: geocoding, distance, and directions using OSM Nominatim and OSRM.
Loaded by app assistant when app_tools config references this module.
"""

import asyncio
import math
from typing import Any, Dict, List

# Optional: use httpx for async HTTP; fallback to requests in thread
try:
    import httpx
    _USE_HTTPX = True
except ImportError:
    _USE_HTTPX = False

try:
    from topaz_agent_kit.utils.logger import Logger
    _logger = Logger("EarthMapTools")
except ImportError:
    _logger = None

NOMINATIM_BASE = "https://nominatim.openstreetmap.org"
OSRM_BASE = "https://router.project-osrm.org"
USER_AGENT = "TopazAgentKit-EarthMap/1.0"


def _log(msg: str, *args: Any) -> None:
    if _logger:
        _logger.debug(msg, *args)


async def _get_url(url: str, headers: Dict[str, str]) -> Dict[str, Any]:
    if _USE_HTTPX:
        async with httpx.AsyncClient(timeout=10.0, headers=headers) as client:
            resp = await client.get(url)
            resp.raise_for_status()
            return resp.json()
    import requests
    loop = asyncio.get_event_loop()
    def _sync() -> Dict[str, Any]:
        r = requests.get(url, timeout=10, headers=headers)
        r.raise_for_status()
        return r.json()
    return await loop.run_in_executor(None, _sync)


async def geocode_place(place_name: str) -> Dict[str, Any]:
    """
    Geocode a place name to coordinates using OpenStreetMap Nominatim.

    Use this when the user asks to show, go to, or zoom to a place (e.g. "Times Square", "Paris").
    Returns latitude, longitude, and display_name so you can update the map center and optionally add a marker.

    Args:
        place_name: Human-readable place name or address (e.g. "Times Square New York", "Eiffel Tower").

    Returns:
        Dict with latitude, longitude, display_name; or error key on failure.
    """
    if not place_name or not str(place_name).strip():
        return {"error": "place_name is required"}
    import urllib.parse
    q = urllib.parse.quote(str(place_name).strip())
    url = f"{NOMINATIM_BASE}/search?q={q}&format=json&limit=1"
    headers = {"User-Agent": USER_AGENT}
    try:
        data = await _get_url(url, headers)
        if not data or not isinstance(data, list) or len(data) == 0:
            return {"error": f"No results for '{place_name}'"}
        first = data[0]
        lat = float(first.get("lat", 0))
        lon = float(first.get("lon", 0))
        display = first.get("display_name", "")
        return {
            "latitude": lat,
            "longitude": lon,
            "display_name": display,
        }
    except Exception as e:
        _log("geocode_place failed: {}", e)
        return {"error": str(e)}


def _haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    R = 6371
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlam = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlam / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c


async def get_distance_between_places(place_a: str, place_b: str) -> Dict[str, Any]:
    """
    Get straight-line (Haversine) distance between two places in km and miles.

    Use this when the user asks "how far from A to B". Geocodes both places then computes distance.
    Optionally update map.markers for A and B.

    Args:
        place_a: Start place name or address.
        place_b: End place name or address.

    Returns:
        Dict with distance_km, distance_miles, from (lat, lon), to (lat, lon); or error on failure.
    """
    if not place_a or not place_b:
        return {"error": "place_a and place_b are required"}
    a_result = await geocode_place(place_a)
    if "error" in a_result:
        return {"error": f"Could not find '{place_a}': {a_result['error']}"}
    b_result = await geocode_place(place_b)
    if "error" in b_result:
        return {"error": f"Could not find '{place_b}': {b_result['error']}"}
    lat_a = a_result["latitude"]
    lon_a = a_result["longitude"]
    lat_b = b_result["latitude"]
    lon_b = b_result["longitude"]
    km = _haversine_km(lat_a, lon_a, lat_b, lon_b)
    miles = km * 0.621371
    return {
        "distance_km": round(km, 2),
        "distance_miles": round(miles, 2),
        "from": {"latitude": lat_a, "longitude": lon_a, "display_name": a_result.get("display_name", place_a)},
        "to": {"latitude": lat_b, "longitude": lon_b, "display_name": b_result.get("display_name", place_b)},
    }


async def get_directions(place_from: str, place_to: str, profile: str = "driving") -> Dict[str, Any]:
    """
    Get driving, walking, or bicycling route between two places using OSRM (OpenStreetMap data).

    Use this when the user asks for directions or "route from A to B". Returns route geometry
    as a list of [lat, lng] for map.route, plus distance_km and duration_minutes.

    Args:
        place_from: Start place name or address.
        place_to: End place name or address.
        profile: "driving", "walking", or "bicycling" (OSRM uses "car", "foot", "bike").

    Returns:
        Dict with distance_km, duration_minutes, route (list of [lat, lng]), from, to; or error on failure.
    """
    if not place_from or not place_to:
        return {"error": "place_from and place_to are required"}
    from_result = await geocode_place(place_from)
    if "error" in from_result:
        return {"error": f"Could not find '{place_from}': {from_result['error']}"}
    to_result = await geocode_place(place_to)
    if "error" in to_result:
        return {"error": f"Could not find '{place_to}': {to_result['error']}"}
    lat1, lon1 = from_result["latitude"], from_result["longitude"]
    lat2, lon2 = to_result["latitude"], to_result["longitude"]
    profile_map = {"driving": "car", "walking": "foot", "bicycling": "bike", "car": "car", "foot": "foot", "bike": "bike"}
    osrm_profile = profile_map.get(profile, "car")
    coords = f"{lon1},{lat1};{lon2},{lat2}"
    url = f"{OSRM_BASE}/route/v1/{osrm_profile}/{coords}?overview=full&geometries=geojson"
    headers = {"User-Agent": USER_AGENT}
    try:
        data = await _get_url(url, headers)
        if data.get("code") != "Ok":
            return {"error": data.get("message", "OSRM route failed")}
        routes = data.get("routes", [])
        if not routes:
            return {"error": "No route found"}
        route = routes[0]
        distance_m = route.get("distance", 0)
        duration_s = route.get("duration", 0)
        distance_km = round(distance_m / 1000, 2)
        duration_minutes = round(duration_s / 60, 1)
        geometry = route.get("geometry") or {}
        coords_list = geometry.get("coordinates", [])
        route_lat_lng: List[List[float]] = [[c[1], c[0]] for c in coords_list]
        return {
            "distance_km": distance_km,
            "duration_minutes": duration_minutes,
            "route": route_lat_lng,
            "from": {"latitude": lat1, "longitude": lon1, "display_name": from_result.get("display_name", place_from)},
            "to": {"latitude": lat2, "longitude": lon2, "display_name": to_result.get("display_name", place_to)},
        }
    except Exception as e:
        _log("get_directions failed: {}", e)
        return {"error": str(e)}
