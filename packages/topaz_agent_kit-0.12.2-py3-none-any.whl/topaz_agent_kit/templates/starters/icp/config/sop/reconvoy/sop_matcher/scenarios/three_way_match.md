# Scenario: Three-Way Match (Triangular)

## Description

A three-way match involves UK, US, AND FR entities in a triangular settlement. 

**Current Scenario (Scenario 3):**
- **UK sells to US** (UK has receivable from US)
- **US makes payment to FR on behalf of UK** (FR pays UK, US pays FR)
- Flow: UK ← US ← FR

This is the only scenario currently supported. All three-way matches follow this pattern.

## Pattern

```
        UK Entity
           │
           │ Invoice (Receivable)
           │
           ▼
      US Entity ◄──────────────── FR Entity
                  Payment on behalf
```

## Example: Scenario 3 - UK Sells to US, US Pays FR on Behalf (Triangular)

### Initial State

**BlackLine Items (UK):**

| item_id | currency | amount_foreign | amount_local_gbp | reference_description |
|---------|----------|----------------|------------------|-----------------------|
| BL-S3-001 | USD | 625,000.00 | 500,000.00 | INV US_OCT_99/US_SUB |
| BL-S3-002 | EUR | 7,200.00 | 6,048.00 | LOGISTIQUE FR 7 |
| BL-S3-003 | GBP | 493,600.00 | 493,600.00 | WIRE FR US SUB |

**US Books Entries (Document #150000881):**

| entry_id | reference | amount_document_currency | currency |
|----------|-----------|-------------------------|----------|
| US-S3-001 | INV US_OCT_99/US_SUB | 625,000.00 | USD |
| US-S3-002 | LOGISTIQUE FR 7 | 8,000.00 | USD |
| US-S3-003 | WIRE FR US SUB | 617,000.00 | USD |

**FR Books Entries (Document #150000882):**

| entry_id | reference | amount_document_currency | currency |
|----------|-----------|-------------------------|----------|
| FR-S3-001 | LOGISTIQUE FR 7 | 7,500.00 | EUR |
| FR-S3-002 | WIRE FR US SUB | 580,000.00 | EUR |

### Discovery Process

1. **Step 1-2**: Start with BL-S3-001 (USD)
   - Find match in `us_books` → US-S3-001
   - Document #: 150000881
   - Mark as `two_way_match`, `processing`

2. **Step 3**: Discover All Related Items and Matches
   - Tool automatically:
     - Gets all entries with Document #150000881 → US-S3-001, US-S3-002, US-S3-003
     - Finds related BlackLine items by reference:
       - "LOGISTIQUE FR 7" → BL-S3-002 (EUR, mark `need_to_process`)
       - "WIRE FR US SUB" → BL-S3-003 (GBP, mark `processing` - GBP items skip recursive loop)
     - **Automatically runs recursive discovery** for BL-S3-002 (EUR):
       - Checks OTHER foreign book (`fr_books`) for "LOGISTIQUE FR 7"
       - Finds FR-S3-001 → `three_way_match`
       - Gets entries by Document #190000442 → FR-S3-001, FR-S3-002
       - Marks BL-S3-002 as `processing`
   
3. **Case Complete**: 3 BlackLine items, entries from both US and FR books

### FX Calculation

| Item | Currency | Amount (Foreign) | Amount (GBP) | Role |
|------|----------|-----------------|--------------|------|
| BL-S3-001 | USD | 625,000.00 | 500,000.00 | UK receivable from US |
| BL-S3-002 | EUR | 6,400.00 | 6,400.00 | FR logistics invoice |
| BL-S3-003 | GBP | 493,600.00 | 493,600.00 | Bank receipt (what UK actually received) |

**Variance Calculation (Scenario 3 Logic):**
```
Formula: fx_entry = uk_receivable - us_wire - fr_invoice
Which means: variance = uk_receivable - (us_wire + fr_invoice)

total_blackline_gbp = USD receivable amount (what UK expected to receive)
                    = BL-S3-001 amount_local_gbp
                    = £500,000.00

total_matched_gbp = GBP bank receipt + EUR invoice (what UK actually received + paid)
                  = BL-S3-003 amount_local_gbp + BL-S3-002 amount_local_gbp
                  = £493,600.00 + £6,048.00
                  = £499,648.00

variance_gbp = total_blackline_gbp - total_matched_gbp
             = £500,000.00 - £499,648.00
             = £352.00 (FX Loss - UK received less than expected)

variance_percent = (variance_gbp / total_blackline_gbp) * 100
                 = (352 / 500,000) * 100
                 = 0.07%
```

**Note**: The variance calculation compares:
- **What UK expected to receive**: USD receivable converted to GBP (BL-S3-001)
- **What UK actually received + paid**: GBP bank receipt + EUR invoice converted to GBP (BL-S3-003 + BL-S3-002)

The tool `calculate_case_fx_variance` automatically finds the USD receivable, GBP bank receipt, and EUR invoice items and uses them for the calculation.

### Proposed Journals (4-Row Structure)

```json
{
  "proposed_journals": [
    {
      "entry_id": "UK-JE-001",
      "gl_account": "113100",
      "assignment": "Bank Rec 99",
      "reference": "WIRE FR US SUB",
      "header_text": "AI AUTO RECON",
      "amount_local_gbp": 493600.00,
      "trading_partner": "FR01",
      "profit_center": "PC_RETAIL",
      "remarks": "Debit"
    },
    {
      "entry_id": "UK-JE-002",
      "gl_account": "210100",
      "assignment": "20251215",
      "reference": "LOGISTIQUE FR 7",
      "header_text": "AI TRI NET",
      "amount_local_gbp": 6048.00,
      "trading_partner": "FR01",
      "profit_center": "PC_LOGIST",
      "remarks": "Debit"
    },
    {
      "entry_id": "UK-JE-003",
      "gl_account": "650100",
      "assignment": "FX AUTO Calc",
      "reference": "FX VAR US",
      "header_text": "AI FX ADJ",
      "amount_local_gbp": 352.00,
      "trading_partner": null,
      "profit_center": "PC_CORP",
      "cost_center": "CC_FINANCE",
      "remarks": "Debit"
    },
    {
      "entry_id": "UK-JE-004",
      "gl_account": "120100",
      "assignment": "20251001",
      "reference": "INV US OCT 99",
      "header_text": "AI AUTO CLEAR",
      "amount_local_gbp": 500000.00,
      "trading_partner": "US01",
      "profit_center": "PC_RETAIL",
      "remarks": "Credit"
    }
  ],
  "scenario_type": "uk_sells_us_fr_triangular",
  "impact_analysis": "Scenario 3 - Triangular settlement: UK receivable from US (£500,000) cleared by FR payment to UK (£493,600) plus FR logistics charge (£6,048). US pays FR on behalf of UK. FX Loss of £352 balances the journal. Balance: Debit £500,000 = Credit £500,000 ✓"
}
```

### Balance Check

| Debits | Credits |
|--------|---------|
| Bank (from FR): £493,600 | |
| IC Payable FR: £6,048 | |
| FX Loss: £352 | |
| | IC Receivable US: £500,000 |
| **Total: £500,000** | **Total: £500,000** ✓ |

## Key Points

1. Three-way matches involve ALL THREE parties: UK, US, and FR
2. BOTH foreign books are involved
3. At least one item has `three_way_match` status
4. Journal has 4 rows (bank, IC netting, FX adjustment, IC clear)
5. The "AI TRI NET" header text indicates triangular netting

## Detection Criteria

A case is triangular if:
- Multiple BlackLine items are linked via Document #
- Entries exist in BOTH `us_books` AND `fr_books`
- At least one item was discovered via reverse lookup (need_to_process → processing)

## Scenario 3 Pattern

| Scenario | UK Entry | US Entry | FR Entry | Flow |
|----------|----------|----------|----------|------|
| UK sells to US, US pays FR on behalf | Receivable | Payable | Payment | UK ← US ← FR |

**Key Characteristics:**
- UK has a **receivable** from US (UK sold goods/services to US)
- US has a **payable** to UK
- FR makes **payment** to UK (on behalf of US)
- US makes **payment** to FR (settling the triangular transaction)
