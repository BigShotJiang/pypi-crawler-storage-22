# Step 3: Discover All Related Items and Matches

## What You Do

Discover all related BlackLine items from the initial match AND automatically run recursive discovery to find three-way matches. This combines the previous Step 3 and Step 4 into a single deterministic operation.

**Current Scenario (Scenario 3):**
- **UK sells to US** (UK has receivable from US - USD item)
- **US makes payment to FR on behalf of UK** (FR pays UK, US pays FR)
- Flow: UK ← US ← FR

**For Scenario 3:**
- Initial match is typically in `us_books` (USD item)
- This tool will find related items (EUR, GBP) and automatically run recursive discovery
- EUR items will find matches in `fr_books` (the OTHER foreign book)
- GBP items are bank receipts and don't need recursive discovery

## Steps

### 3.1 Call the Combined Discovery Tool

Call the `discover_all_related_items_and_matches` tool to handle everything automatically:

```
reconvoy.discover_all_related_items_and_matches(
  db_file="<database_path>",
  run_id="<run_id>",
  initial_document_number="<document_number_from_step_2>",
  initial_foreign_book_type="<initial_foreign_book_type>"  # From Step 2: "us_books" or "fr_books"
)
```

**What this tool does automatically:**
1. Gets all foreign book entries with the initial document_number
2. Finds related BlackLine items by matching reference texts from those entries
3. Marks items appropriately:
   - **GBP items**: Mark as `"processing"` (already have match, skip recursive loop)
   - **USD/EUR items**: Mark as `"need_to_process"` (will check other book in recursive loop)
4. **Automatically runs recursive discovery** for all `"need_to_process"` items:
   - For each USD/EUR item, finds match in the OTHER foreign book
   - Updates statuses, gets entries, finds more related items
   - Repeats until no more items to process
5. Returns all discovery results together

**Parameters:**
- `db_file`: Database path from your inputs
- `run_id`: Run ID from your inputs
- `initial_document_number`: Document number from Step 2 match
- `initial_foreign_book_type`: The foreign book where the initial match was found in Step 2
  - If Step 2 match was in `us_books` → use `"us_books"`
  - If Step 2 match was in `fr_books` → use `"fr_books"`

**Returns:**
- `initial_related_items`: List of BlackLine items found from initial foreign book entries
- `initial_related_items_mappings`: Dict mapping item_id to initial mapping info
- `item_discovery_results`: List of discovery results from recursive discovery
- `related_items_discovery_results`: List of related items found during recursive discovery
- `items_processed`: Total items processed in recursive discovery
- `iterations`: Number of recursive discovery iterations
- `error`: Error message if any

### 3.2 Use Results

Use the returned results in Step 4 (FX Analysis):
- `initial_related_items` and `initial_related_items_mappings` for initial related items
- `item_discovery_results` and `related_items_discovery_results` for recursive discovery results

**Important:**
- The tool handles all looping, matching, and status updates automatically
- You do NOT need to manually call other tools - this one tool does everything
- The tool ensures all `need_to_process` items are processed completely
- **CRITICAL**: Verify that EUR items found matches in `fr_books` - check `item_discovery_results` for entries with `foreign_book_type: "fr_books"`

## Document in Execution Trace

For this step, record in `execution_trace`:
- **Input**: `initial_document_number` and `initial_foreign_book_type` used (from Step 2)
- **Tool call**: `discover_all_related_items_and_matches` with parameters
- **Output**: Summary of results:
  - Number of initial related items found
  - Number of items processed in recursive discovery
  - Number of iterations
  - Brief summary of matches found (especially FR matches for EUR items)
- **Results**: Use the returned `initial_related_items`, `initial_related_items_mappings`, `item_discovery_results`, and `related_items_discovery_results` in Step 4

## Next

→ Go to Step 4 (FX Analysis) with all discovery results
