#!/usr/bin/env python3
"""Setup script for ReconVoy pipeline - Phase 2 Redesign.

Creates a SQLite database, initializes schema, and generates mock data for
intercompany open-items research and clearance, focused on triangular
UK–US–FR scenarios.

New Design:
- BlackLine unmatched items table (input)
- US and FR books tables (reference only)
- UK journal entries table (output)
- FX rates table (book and spot rates)
- Multiple scenario types with documentation
"""

import argparse
import json
import random
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    from rich.console import Console
    from rich.table import Table as RichTable
    from rich.panel import Panel
    from rich import box

    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False
    RichTable = None
    Console = None
    Panel = None
    box = None

from topaz_agent_kit.utils.logger import Logger
from topaz_agent_kit.utils.path_resolver import detect_project_name, resolve_script_path


logger = Logger("ReconVoySetup")


# ============================================================================
# Helpers
# ============================================================================


def _round2(value: float) -> float:
    """Round a numeric value to 2 decimal places consistently."""
    try:
        return float(f"{float(value):.2f}")
    except (TypeError, ValueError):
        return value


def get_next_document_numbers(conn: sqlite3.Connection) -> Dict[str, int]:
    """Get next available document numbers by querying existing max values.
    
    Returns:
        Dictionary with 'us', 'fr', 'uk' document number bases
    """
    cursor = conn.cursor()
    
    # Base document numbers (starting points)
    base_us = 150000881
    base_fr = 190000442
    base_uk = 100000552
    
    # Query max document numbers from each table
    try:
        cursor.execute("SELECT MAX(CAST(document_number AS INTEGER)) FROM us_books WHERE document_number GLOB '[0-9]*'")
        max_us = cursor.fetchone()[0]
        if max_us is not None and max_us >= base_us:
            base_us = max_us + 1
    except:
        pass
    
    try:
        cursor.execute("SELECT MAX(CAST(document_number AS INTEGER)) FROM fr_books WHERE document_number GLOB '[0-9]*'")
        max_fr = cursor.fetchone()[0]
        if max_fr is not None and max_fr >= base_fr:
            base_fr = max_fr + 1
    except:
        pass
    
    try:
        cursor.execute("SELECT MAX(CAST(document_number AS INTEGER)) FROM blackline_unmatched_items WHERE document_number GLOB '[0-9]*'")
        max_uk = cursor.fetchone()[0]
        if max_uk is not None and max_uk >= base_uk:
            base_uk = max_uk + 1
    except:
        pass
    
    return {
        "us": base_us,
        "fr": base_fr,
        "uk": base_uk,
    }


# ============================================================================
# Schema
# ============================================================================


def create_database_schema(db_path: str) -> None:
    """Create ReconVoy database schema per Phase 2 design."""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # BlackLine unmatched items (input)
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS blackline_unmatched_items (
            item_id TEXT PRIMARY KEY,
            source TEXT NOT NULL,
            system_id TEXT,
            trans_date TEXT NOT NULL,
            document_number TEXT,
            currency TEXT NOT NULL,
            amount_foreign DECIMAL(18, 4) NOT NULL,
            amount_local_gbp DECIMAL(18, 4) NOT NULL,
            reference_description TEXT,
            status TEXT DEFAULT 'UNMATCHED',
            processing_status TEXT,
            run_id TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP
        )
        """
    )

    # US books (reference only)
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS us_books (
            entry_id TEXT PRIMARY KEY,
            company_code TEXT NOT NULL DEFAULT 'US01',
            document_number TEXT NOT NULL,
            gl_account TEXT NOT NULL,
            business_area TEXT,
            assignment TEXT,
            document_type TEXT NOT NULL,
            document_date TEXT NOT NULL,
            posting_date TEXT NOT NULL,
            reference TEXT,
            header_text TEXT,
            posting_key TEXT,
            document_currency TEXT NOT NULL,
            amount_document_currency DECIMAL(18, 4) NOT NULL,
            amount_local_currency DECIMAL(18, 4),
            local_currency TEXT,
            tax_code TEXT,
            profit_center TEXT,
            cost_center TEXT,
            trading_partner TEXT,
            clearing_doc_no TEXT,
            clearing_date TEXT,
            plant TEXT,
            "order" TEXT,
            wbs_element TEXT,
            remarks TEXT,
            scenario_tag TEXT
        )
        """
    )

    # FR books (reference only)
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS fr_books (
            entry_id TEXT PRIMARY KEY,
            company_code TEXT NOT NULL DEFAULT 'FR01',
            document_number TEXT NOT NULL,
            gl_account TEXT NOT NULL,
            business_area TEXT,
            assignment TEXT,
            document_type TEXT NOT NULL,
            document_date TEXT NOT NULL,
            posting_date TEXT NOT NULL,
            reference TEXT,
            header_text TEXT,
            posting_key TEXT,
            document_currency TEXT NOT NULL,
            amount_document_currency DECIMAL(18, 4) NOT NULL,
            amount_local_currency DECIMAL(18, 4),
            local_currency TEXT,
            tax_code TEXT,
            profit_center TEXT,
            cost_center TEXT,
            trading_partner TEXT,
            clearing_doc_no TEXT,
            clearing_date TEXT,
            plant TEXT,
            "order" TEXT,
            wbs_element TEXT,
            remarks TEXT,
            scenario_tag TEXT
        )
        """
    )

    # UK journal entries (output)
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS uk_journal_entries (
            entry_id TEXT PRIMARY KEY,
            company_code TEXT NOT NULL DEFAULT 'UK01',
            scenario TEXT,
            gl_account TEXT NOT NULL,
            business_area TEXT,
            assignment TEXT,
            document_type TEXT NOT NULL,
            document_date TEXT NOT NULL,
            posting_date TEXT NOT NULL,
            reference TEXT,
            header_text TEXT,
            posting_key TEXT,
            document_currency TEXT NOT NULL,
            amount_document_currency DECIMAL(18, 4) NOT NULL,
            amount_local_currency DECIMAL(18, 4),
            local_currency TEXT NOT NULL DEFAULT 'GBP',
            tax_code TEXT,
            profit_center TEXT,
            cost_center TEXT,
            trading_partner TEXT,
            clearing_doc_no TEXT,
            clearing_date TEXT,
            plant TEXT,
            "order" TEXT,
            wbs_element TEXT,
            remarks TEXT,
            case_id TEXT,
            blackline_item_ids TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )

    # FX rates table removed - not needed for variance calculation
    # All amounts are already in GBP (amount_local_gbp), so rates are not required

    # Results table (reuse existing structure)
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS reconvoy_results (
            result_id INTEGER PRIMARY KEY AUTOINCREMENT,
            open_item_id TEXT NOT NULL,
            run_id TEXT,
            route TEXT,
            hitl_required BOOLEAN,
            hitl_decision TEXT,
            fx_summary TEXT,
            error TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )

    # Indexes
    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_blackline_status "
        "ON blackline_unmatched_items(status, processing_status, run_id)"
    )
    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_blackline_source "
        "ON blackline_unmatched_items(source)"
    )
    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_us_books_document "
        "ON us_books(document_number)"
    )
    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_us_books_reference "
        "ON us_books(reference, header_text)"
    )
    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_us_books_scenario "
        "ON us_books(scenario_tag)"
    )
    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_fr_books_document "
        "ON fr_books(document_number)"
    )
    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_fr_books_reference "
        "ON fr_books(reference, header_text)"
    )
    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_fr_books_scenario "
        "ON fr_books(scenario_tag)"
    )
    # FX rates indexes removed - table no longer exists

    conn.commit()
    conn.close()
    logger.info("ReconVoy schema created at {}", db_path)


# ============================================================================
# Scenario Data Generation
# ============================================================================


def _jitter_date(base_date: str, max_days: int) -> str:
    """Jitter a YYYY-MM-DD date string by up to max_days in either direction."""
    if max_days <= 0:
        return base_date
    try:
        base_dt = datetime.strptime(base_date, "%Y-%m-%d")
    except ValueError:
        return base_date
    delta_days = random.randint(-max_days, max_days)
    jittered = base_dt + timedelta(days=delta_days)
    return jittered.strftime("%Y-%m-%d")


def _format_date_for_blackline(date_str: str) -> str:
    """Convert YYYY-MM-DD to DD.MM.YY format for BlackLine."""
    try:
        dt = datetime.strptime(date_str, "%Y-%m-%d")
        return dt.strftime("%d.%m.%y")
    except ValueError:
        return date_str


def generate_scenario_3(
    conn: sqlite3.Connection, 
    index: int, 
    target_variance_gbp: float = 352.0,
    exact_amounts: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """Generate Scenario 3: UK Sells to US, US Pays FR on Behalf.

    Args:
        conn: Database connection
        index: Index for this scenario instance (0-based)
        target_variance_gbp: Target variance in GBP. Use >100 for HITL, <=100 for Straight-through.

    This matches the exact structure from the images:
    - UK receivable from US: £500,000 (USD 625,000)
    - UK payable to FR: €7,200 (£6,048)
    - UK bank wire received: £493,600 (USD 615,000)
    - Variance: Controlled to match target_variance_gbp
    - Expected routing: HITL if |variance| > 100 GBP, Straight-through otherwise
    """
    cursor = conn.cursor()
    
    # Handle exact amounts (for PDF example) vs. generated amounts
    if exact_amounts:
        scenario_tag = exact_amounts.get("scenario_tag", f"scenario3_pdf_example")
        uk_receivable_gbp = exact_amounts.get("uk_receivable_gbp", 500_000.00)
        uk_receivable_usd = exact_amounts.get("uk_receivable_usd", 625_000.00)
        us_wire_usd = exact_amounts.get("us_wire_usd", 615_000.00)
        us_wire_gbp = exact_amounts.get("us_wire_gbp", 493_600.00)
        fr_invoice_eur = exact_amounts.get("fr_invoice_eur", 7_200.00)
        fr_invoice_gbp = exact_amounts.get("fr_invoice_gbp", 6_048.00)
        # Use PDF document numbers only if explicitly provided, otherwise use dynamic generation
        us_document_number = exact_amounts.get("us_document_number")
        fr_document_number = exact_amounts.get("fr_document_number")
        uk_document_number = exact_amounts.get("uk_document_number")
        # If document numbers not provided in exact_amounts, will be set dynamically below
        # Calculate variance from exact amounts
        fx_loss = _round2(us_wire_gbp - (uk_receivable_gbp + fr_invoice_gbp))
        # Skip scaling and adjustment for exact amounts
    else:
        scenario_tag = f"scenario3_{index+1:03d}"
        
        # Use exact dates from the example (year 2026)
        base_date = "2026-01-14"
        posting_date = base_date  # No jitter for canonical scenario
        trans_date_uk_inv = "01.12.25"  # UK invoice date (Dec 1, 2025)
        trans_date_wire = "14.01.26"  # Wire date (Jan 14, 2026)

        # Base amounts from the canonical example (will be scaled per-case)
        base_uk_receivable_gbp = 500_000.00
        base_uk_receivable_usd = 625_000.00
        base_us_wire_usd = 615_000.00
        base_us_wire_gbp = 493_600.00  # Using book rate ~1.245981
        base_fr_invoice_eur = 7_200.00
        base_fr_invoice_gbp = 6_048.00  # Using spot rate 0.84

        # Use realistic scale for all cases (0.5 to 2.0) to generate realistic amounts
        # Both HITL and Straight-through cases should have similar amount ranges
        base_scale = random.uniform(0.5, 2.0)
        
        # Apply base scale to all amounts
        uk_receivable_gbp = _round2(base_uk_receivable_gbp * base_scale)
        uk_receivable_usd = _round2(base_uk_receivable_usd * base_scale)
        us_wire_usd = _round2(base_us_wire_usd * base_scale)
        us_wire_gbp = _round2(base_us_wire_gbp * base_scale)
        fr_invoice_eur = _round2(base_fr_invoice_eur * base_scale)
        fr_invoice_gbp = _round2(base_fr_invoice_gbp * base_scale)
        
        # Calculate current variance with scaled amounts
        current_variance = us_wire_gbp - (uk_receivable_gbp + fr_invoice_gbp)
        
        # Adjust amounts to achieve target variance
        # Note: target_variance_gbp is the FX entry amount (what we want to display)
        # FX entry = IC Receivable US - Bank - IC Payable FR = uk_receivable_gbp - us_wire_gbp - fr_invoice_gbp
        # So: us_wire_gbp = uk_receivable_gbp - fr_invoice_gbp - target_variance_gbp
        # This means: us_wire_gbp_adjusted = uk_receivable_gbp + fr_invoice_gbp - target_variance_gbp
        # Which gives: fx_entry_amount = uk_receivable_gbp - us_wire_gbp - fr_invoice_gbp = target_variance_gbp ✓
        us_wire_gbp_adjusted = (uk_receivable_gbp + fr_invoice_gbp) - target_variance_gbp
        
        # Only adjust if the adjusted amount is positive and reasonable
        if us_wire_gbp_adjusted > 0:
            # Recalculate USD wire amount to maintain FX rate consistency
            if us_wire_gbp != 0:
                us_wire_usd = _round2(us_wire_usd * (us_wire_gbp_adjusted / us_wire_gbp))
            us_wire_gbp = _round2(us_wire_gbp_adjusted)
        
        # Variance calculation aligned with tool logic (Scenario 3):
        # total_blackline_gbp = GBP item (what UK actually received - bank receipt)
        # total_matched_gbp = USD item + EUR item (what UK should have received)
        # variance_gbp = total_blackline_gbp - total_matched_gbp
        fx_loss = _round2(us_wire_gbp - (uk_receivable_gbp + fr_invoice_gbp))
    
    # Use exact dates from the example (year 2026)
    base_date = "2026-01-14"
    posting_date = base_date  # No jitter for canonical scenario
    trans_date_uk_inv = "01.12.25"  # UK invoice date (Dec 1, 2025)
    trans_date_wire = "14.01.26"  # Wire date (Jan 14, 2026)

    # ------------------------------------------------------------------------
    # Reference construction (amount-aware + case-unique)
    # ------------------------------------------------------------------------
    case_suffix = f"_{scenario_tag}"

    # Use integer EUR amount for FR logistics references (e.g., 7200 → 4680)
    fr_amount_eur_int = int(round(fr_invoice_eur))
    fr_amount_token = f"{fr_amount_eur_int}"

    # Use GBP wire amount in thousands for wire references (e.g., 493600 → 494K)
    wire_amount_k_int = int(round(us_wire_gbp / 1000))
    wire_amount_token = f"{wire_amount_k_int}K"

    bl_inv_ref = f"INV_US_OCT_99/US_SUB{case_suffix}"
    bl_log_ref = f"LOGISTIQUE_FR_{fr_amount_token}{case_suffix}"
    bl_wire_ref = f"WIRE_FR_US_SUB_REF_{wire_amount_token}{case_suffix}"

    us_inv_ref = bl_inv_ref
    us_inv_header = f"UK_INV_OCT_99{case_suffix}"

    us_wire_assignment = f"WIRE_{wire_amount_token}{case_suffix}"
    us_wire_ref = bl_wire_ref
    us_wire_header = f"Wire Ref {wire_amount_token}{case_suffix}"

    us_fr_ref = bl_log_ref
    us_fr_inv_ref = f"FR_INV_{fr_amount_token}{case_suffix}"

    fr_settle_ref = f"US_SETTLE_FR{case_suffix}"
    fr_clear_ref = f"UK_CLEAR_INV{case_suffix}"

    # FX rates (recalculate after any adjustments)
    usd_gbp_book_rate = _round2(us_wire_usd / us_wire_gbp) if us_wire_gbp != 0 else 1.25  # ~1.245981
    eur_gbp_spot_rate = _round2(fr_invoice_gbp / fr_invoice_eur) if fr_invoice_eur != 0 else 0.84  # 0.84
    
    # Calculate USD payment to FR dynamically to ensure document balance
    # For Scenario 3: uk_receivable_usd = us_wire_usd + us_fr_payment_usd
    # So: us_fr_payment_usd = uk_receivable_usd - us_wire_usd
    # This ensures the US document balances: Debits (PK 50) = Credits (PK 40)
    us_fr_payment_usd = _round2(uk_receivable_usd - us_wire_usd)

    # Document numbers - query database for next available numbers
    # Use dynamic generation if exact_amounts not provided OR if document numbers not in exact_amounts
    if not exact_amounts or (exact_amounts and us_document_number is None):
        doc_numbers = get_next_document_numbers(conn)
        us_document_number = str(doc_numbers["us"] + index)
        fr_document_number = str(doc_numbers["fr"] + index)
        uk_document_number = str(doc_numbers["uk"] + index)

    # ========================================================================
    # BlackLine Items
    # ========================================================================

    # Item 1: UK receivable from US (GL SAP)
    cursor.execute(
        """
        INSERT OR REPLACE INTO blackline_unmatched_items (
            item_id, source, system_id, trans_date, document_number,
            currency, amount_foreign, amount_local_gbp, reference_description,
            status, processing_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            f"BL-S3-001-{index+1:03d}",
            "GL (SAP)",
            "SAP_UK_1001",
            trans_date_uk_inv,
            uk_document_number,
            "USD",
            uk_receivable_usd,
            uk_receivable_gbp,
            bl_inv_ref,
            "UNMATCHED",
            None,
        ),
    )

    # Item 2: UK payable to FR (GL SAP)
    cursor.execute(
        """
        INSERT OR REPLACE INTO blackline_unmatched_items (
            item_id, source, system_id, trans_date, document_number,
            currency, amount_foreign, amount_local_gbp, reference_description,
            status, processing_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            f"BL-S3-002-{index+1:03d}",
            "GL (SAP)",
            "SAP_UK_2002",
            trans_date_wire,
            uk_document_number,
            "EUR",
            fr_invoice_eur,
            fr_invoice_gbp,
            bl_log_ref,
            "UNMATCHED",
            None,
        ),
    )

    # Item 3: UK bank wire received (Bank)
    cursor.execute(
        """
        INSERT OR REPLACE INTO blackline_unmatched_items (
            item_id, source, system_id, trans_date, document_number,
            currency, amount_foreign, amount_local_gbp, reference_description,
            status, processing_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            f"BL-S3-003-{index+1:03d}",
            "Bank",
            "BNK_LON_SS",
            trans_date_wire,
            None,  # Bank items may not have document number
            "GBP",
            us_wire_gbp,
            us_wire_gbp,
            bl_wire_ref,
            "UNMATCHED",
            None,
        ),
    )

    # ========================================================================
    # US Books Entries (Document # 150000881)
    # ========================================================================

    # US Entry 1: AP clearing UK invoice (Debit)
    cursor.execute(
        """
        INSERT OR REPLACE INTO us_books (
            entry_id, company_code, document_number, gl_account, assignment,
            document_type, document_date, posting_date, reference, header_text,
            posting_key, document_currency, amount_document_currency,
            amount_local_currency, local_currency, profit_center, cost_center,
            trading_partner, remarks, scenario_tag
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            f"US-S3-001-{index+1:03d}",
            "US01",
            us_document_number,
            "210000",
            "CLR INV OCT 99",
            "ZP",
            "14.01.26",
            "14.01.26",
            us_inv_ref,
            us_inv_header,
            "50",
            "USD",
            uk_receivable_usd,
            uk_receivable_usd,
            "USD",
            "PC_US_CORP",
            None,
            "UK01",
            "Debit",
            scenario_tag,
        ),
    )

    # US Entry 2: Bank wire to UK (Credit)
    cursor.execute(
        """
        INSERT OR REPLACE INTO us_books (
            entry_id, company_code, document_number, gl_account, assignment,
            document_type, document_date, posting_date, reference, header_text,
            posting_key, document_currency, amount_document_currency,
            amount_local_currency, local_currency, profit_center, cost_center,
            trading_partner, remarks, scenario_tag
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            f"US-S3-002-{index+1:03d}",
            "US01",
            us_document_number,
            "100001",
            us_wire_assignment,
            "ZP",
            "14.01.26",
            "14.01.26",
            us_wire_ref,
            us_wire_header,
            "40",
            "USD",
            us_wire_usd,
            us_wire_usd,
            "USD",
            "PC_US_CORP",
            None,
            None,
            "Credit",
            scenario_tag,
        ),
    )

    # US Entry 3: Payment to FR on behalf of UK (Credit)
    cursor.execute(
        """
        INSERT OR REPLACE INTO us_books (
            entry_id, company_code, document_number, gl_account, assignment,
            document_type, document_date, posting_date, reference, header_text,
            posting_key, document_currency, amount_document_currency,
            amount_local_currency, local_currency, profit_center, cost_center,
            trading_partner, remarks, scenario_tag
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            f"US-S3-003-{index+1:03d}",
            "US01",
            us_document_number,
            "210000",
            "NET_FR_LOG",
            "ZP",
            "14.01.26",
            "14.01.26",
            us_fr_ref,
            "Pay on behalf of UK",
            "40",
            "USD",
            us_fr_payment_usd,
            us_fr_payment_usd,
            "USD",
            "PC_US_LOG",
            "CC_LOG_01",
            "FR01",
            "Credit",
            scenario_tag,
        ),
    )

    # ========================================================================
    # FR Books Entries (Document # 190000442)
    # ========================================================================

    # FR Entry 1: IC Clearing (Debit) - US paid
    cursor.execute(
        """
        INSERT OR REPLACE INTO fr_books (
            entry_id, company_code, document_number, gl_account, assignment,
            document_type, document_date, posting_date, reference, header_text,
            posting_key, document_currency, amount_document_currency,
            amount_local_currency, local_currency, profit_center, cost_center,
            trading_partner, remarks, scenario_tag
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            f"FR-S3-001-{index+1:03d}",
            "FR01",
            fr_document_number,
            "120500",
            "US PAID UK",
            "AB",
            "14.01.26",
            "14.01.26",
            fr_settle_ref,
            bl_log_ref,
            "50",
            "EUR",
            fr_invoice_eur,
            fr_invoice_eur,
            "EUR",
            "PC_LOGIST",
            None,
            "US01",
            "Debit",
            scenario_tag,
        ),
    )

    # FR Entry 2: IC Receivable from UK (Credit)
    cursor.execute(
        """
        INSERT OR REPLACE INTO fr_books (
            entry_id, company_code, document_number, gl_account, assignment,
            document_type, document_date, posting_date, reference, header_text,
            posting_key, document_currency, amount_document_currency,
            amount_local_currency, local_currency, profit_center, cost_center,
            trading_partner, remarks, scenario_tag
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            f"FR-S3-002-{index+1:03d}",
            "FR01",
            fr_document_number,
            "120100",
            "INV_UK_OCT_99",
            "AB",
            "14.01.26",
            "14.01.26",
            fr_clear_ref,
            bl_log_ref,
            "40",
            "EUR",
            fr_invoice_eur,
            fr_invoice_eur,
            "EUR",
            "PC_LOGIST",
            None,
            "UK01",
            "Credit",
            scenario_tag,
        ),
    )

    # ========================================================================
    # FX Rates (removed - not needed for variance calculation)
    # ========================================================================
    # FX rates are calculated for mock data generation but not stored in database
    # All amounts are already in GBP (amount_local_gbp), so rates are not required
    # Rates are still included in fx_calculations dict for documentation purposes

    # ========================================================================
    # Scenario Documentation
    # ========================================================================
    
    # Calculate journal amounts to ensure balance
    # Accounting equation: Debits = Credits
    # Journal balancing logic:
    # Row 4 (IC Receivable US) should ALWAYS be the USD invoice amount in GBP (uk_receivable_gbp)
    # This clears the USD receivable item.
    # 
    # The FX entry balances the journal:
    # Bank (Debit) + IC Payable FR (Debit) + FX (Debit if loss, Credit if gain) = IC Receivable US (Credit)
    # 
    # So: FX = IC Receivable US - Bank - IC Payable FR
    #     FX = uk_receivable_gbp - us_wire_gbp - fr_invoice_gbp
    #     FX = -(us_wire_gbp - uk_receivable_gbp - fr_invoice_gbp)
    #     FX = -variance (since variance = us_wire_gbp - (uk_receivable_gbp + fr_invoice_gbp))
    #
    # IC Receivable US is always uk_receivable_gbp (the invoice amount)
    ic_receivable_amount = uk_receivable_gbp  # Always the USD invoice amount in GBP
    
    # Calculate FX entry amount using the correct formula: uk_receivable - us_wire - fr_invoice
    # This is the variance: what UK expected to receive minus what UK actually received + paid
    # Formula: fx_entry = uk_receivable - (us_wire + fr_invoice)
    # Variance sign: positive = FX Loss, negative = FX Gain
    fx_entry_amount = _round2(uk_receivable_gbp - us_wire_gbp - fr_invoice_gbp)
    
    # Legacy variance calculation (kept for reference, but fx_entry_amount is the correct value)
    # Old formula: variance_gbp = us_wire_gbp - (uk_receivable_gbp + fr_invoice_gbp)
    # This gives opposite sign, so we use fx_entry_amount instead
    variance_gbp = fx_entry_amount  # Use fx_entry_amount as the variance
    # fx_entry_amount will be negative for FX Gain, positive for FX Loss

    doc = {
        "scenario_tag": scenario_tag,
        "scenario_type": "UK Sells to US, US Pays FR on Behalf",
        "description": (
            "UK sells inventory to US, FR provides logistics. "
            "US pays UK (reduced by FR amount) and pays FR directly."
        ),
        "blackline_items": [
            {
                "item_id": f"BL-S3-001-{index+1:03d}",
                "description": "UK receivable from US",
                "currency": "USD",
                "amount_foreign": uk_receivable_usd,
                "amount_local_gbp": uk_receivable_gbp,
                "reference": bl_inv_ref,
            },
            {
                "item_id": f"BL-S3-002-{index+1:03d}",
                "description": "UK payable to FR",
                "currency": "EUR",
                "amount_foreign": fr_invoice_eur,
                "amount_local_gbp": fr_invoice_gbp,
                "reference": bl_log_ref,
            },
            {
                "item_id": f"BL-S3-003-{index+1:03d}",
                "description": "UK bank wire received",
                "currency": "GBP",
                "amount_foreign": us_wire_gbp,
                "amount_local_gbp": us_wire_gbp,
                "reference": bl_wire_ref,
            },
        ],
        "us_books_entries": [
            {
                "entry_id": f"US-S3-001-{index+1:03d}",
                "document_number": us_document_number,
                "description": us_inv_ref,  # Matches PDF format: "UK_PAY_01" or "UK_INV_OCT_99"
                "reference": us_inv_ref,
                "amount_document_currency": uk_receivable_usd,
                "document_currency": "USD",
                "amount_local_gbp": uk_receivable_gbp,
            },
            {
                "entry_id": f"US-S3-002-{index+1:03d}",
                "document_number": us_document_number,
                "description": us_wire_ref,  # Matches PDF format: "WIRE_615K"
                "reference": us_wire_ref,
                "amount_document_currency": us_wire_usd,
                "document_currency": "USD",
                "amount_local_gbp": us_wire_gbp,
            },
            {
                "entry_id": f"US-S3-003-{index+1:03d}",
                "document_number": us_document_number,
                "description": us_fr_inv_ref,  # Matches PDF format: "FR_INV_7200"
                "reference": us_fr_inv_ref,
                "amount_document_currency": us_fr_payment_usd,
                "document_currency": "USD",
                "amount_local_gbp": _round2(us_fr_payment_usd / usd_gbp_book_rate) if usd_gbp_book_rate != 0 else 0.0,
            },
        ],
        "fr_books_entries": [
            {
                "entry_id": f"FR-S3-001-{index+1:03d}",
                "document_number": fr_document_number,
                "description": fr_settle_ref,  # Matches PDF format: "US_SETTLE_FR"
                "reference": fr_settle_ref,
                "amount_document_currency": fr_invoice_eur,
                "document_currency": "EUR",
                "amount_local_gbp": fr_invoice_gbp,
            },
            {
                "entry_id": f"FR-S3-002-{index+1:03d}",
                "document_number": fr_document_number,
                "description": fr_clear_ref,  # Matches PDF format: "UK_CLEAR_INV"
                "reference": fr_clear_ref,
                "amount_document_currency": fr_invoice_eur,
                "document_currency": "EUR",
                "amount_local_gbp": fr_invoice_gbp,
            },
        ],
        "correlations": {
            "blackline_to_us": {
                f"BL-S3-001-{index+1:03d}": [
                    f"US-S3-001-{index+1:03d}"
                ],  # UK receivable matches US AP entry
            },
            "blackline_to_fr": {
                f"BL-S3-002-{index+1:03d}": [
                    f"FR-S3-001-{index+1:03d}",
                    f"FR-S3-002-{index+1:03d}",
                ],  # UK payable matches FR entries
            },
            "blackline_to_bank": {
                f"BL-S3-003-{index+1:03d}": [
                    f"US-S3-002-{index+1:03d}"
                ],  # UK bank wire matches US bank entry
            },
        },
        "expected_uk_journals": [
            {
                "gl_account": "113100",
                "description": "Bank Rec",
                "amount_gbp": us_wire_gbp,
                "header_text": "AI AUTO RECON",
                "remarks": "Debit",
            },
            {
                "gl_account": "210100",
                "description": "IC Payable FR",
                "amount_gbp": fr_invoice_gbp,
                "header_text": "AI TRI NET",
                "remarks": "Debit",
            },
            {
                "gl_account": "750100" if fx_entry_amount < 0 else "650100",  # FX Gain if negative, FX Loss if positive
                "description": "FX Gain" if fx_entry_amount < 0 else "FX Loss",
                "amount_gbp": abs(fx_entry_amount),  # Always positive amount
                "header_text": "AI FX ADJ",
                "remarks": "Credit" if fx_entry_amount < 0 else "Debit",  # Credit for gain, Debit for loss
            },
            {
                "gl_account": "120100",
                "description": "US_CLEAR_INV",  # Reference from PDF - clears US invoice receivable
                "amount_gbp": ic_receivable_amount,  # Always the USD invoice amount in GBP (uk_receivable_gbp)
                "header_text": "AI AUTO CLEAR",
                "remarks": "Credit",
            },
        ],
        "fx_calculations": {
            "us_wire_usd_to_gbp": {
                "amount_usd": us_wire_usd,
                "rate": usd_gbp_book_rate,
                "rate_type": "book",
                "amount_gbp": us_wire_gbp,
            },
            "fr_invoice_eur_to_gbp": {
                "amount_eur": fr_invoice_eur,
                "rate": eur_gbp_spot_rate,
                "rate_type": "spot",
                "amount_gbp": fr_invoice_gbp,
            },
        },
        # NOTE: Variance calculation aligned with tool logic (Scenario 3):
        # Formula: fx_entry = uk_receivable - us_wire - fr_invoice
        # Which means: variance = uk_receivable - (us_wire + fr_invoice)
        # Where:
        #   - uk_receivable = USD receivable converted to GBP (what UK expected to receive)
        #   - us_wire = GBP bank receipt (what UK actually received)
        #   - fr_invoice = EUR invoice converted to GBP (what UK paid to FR)
        # total_blackline_gbp = USD receivable converted to GBP (what UK expected to receive)
        # total_matched_gbp = GBP bank receipt + EUR invoice (what UK actually received + paid)
        # variance_gbp = total_blackline_gbp - total_matched_gbp
        # Variance sign: positive = FX Loss, negative = FX Gain
        "variance_calculation": {
            "total_blackline_gbp": uk_receivable_gbp,  # USD receivable (BL-S3-001) - what UK expected to receive
            "total_matched_gbp": us_wire_gbp + fr_invoice_gbp,  # GBP bank receipt (BL-S3-003) + EUR invoice (BL-S3-002) - what UK actually received + paid
            "variance_gbp": fx_entry_amount,  # uk_receivable_gbp - (us_wire_gbp + fr_invoice_gbp)
            "variance_percent": (fx_entry_amount / uk_receivable_gbp) * 100 if uk_receivable_gbp != 0 else 0,
        },
        "expected_routing": "HITL" if abs(fx_entry_amount) > 100 else "StraightThrough",
    }

    logger.info(
        "Generated Scenario 3 (scenario_tag={}) variance_gbp={:.2f} expected_routing={}",
        scenario_tag,
        fx_entry_amount,
        doc["expected_routing"],
    )

    return doc


def validate_scenario_data(
    conn: sqlite3.Connection, scenario: Dict[str, Any]
) -> Dict[str, Any]:
    """Validate scenario data for quality issues.
    
    Checks:
    - Reference matching between BlackLine items and foreign book entries
    - Date format consistency
    - FX rate availability
    - Document number consistency
    - Amount consistency
    
    Returns:
        Dictionary with validation results including issues found
    """
    cursor = conn.cursor()
    issues = []
    warnings = []
    
    scenario_tag = scenario.get("scenario_tag", "unknown")
    blackline_items = scenario.get("blackline_items", [])
    us_entries = scenario.get("us_books_entries", [])
    fr_entries = scenario.get("fr_books_entries", [])
    
    # Helper to convert date format
    def convert_date_to_iso(date_str: str) -> str:
        """Convert DD.MM.YY to YYYY-MM-DD"""
        try:
            parts = date_str.split(".")
            if len(parts) == 3:
                day, month, year = parts
                # Assume YY >= 00 means 2000-2099
                full_year = f"20{year}" if len(year) == 2 else year
                return f"{full_year}-{month.zfill(2)}-{day.zfill(2)}"
        except:
            pass
        return date_str
    
    # 1. Check reference matching for BlackLine items
    for bl_item in blackline_items:
        item_id = bl_item.get("item_id", "unknown")
        currency = bl_item.get("currency", "")
        reference = bl_item.get("reference", "")
        amount_foreign = bl_item.get("amount_foreign", 0)
        
        # Check if this BlackLine item should match a foreign book entry
        if currency in ["USD", "EUR"]:
            # Query actual database entries to verify match
            if currency == "USD":
                cursor.execute(
                    """
                    SELECT entry_id, reference, header_text, amount_document_currency
                    FROM us_books
                    WHERE (reference = ? OR header_text = ?)
                      AND ABS(amount_document_currency - ?) < 0.01
                    LIMIT 1
                    """,
                    (reference, reference, amount_foreign),
                )
            else:  # EUR
                cursor.execute(
                    """
                    SELECT entry_id, reference, header_text, amount_document_currency
                    FROM fr_books
                    WHERE (reference = ? OR header_text = ?)
                      AND ABS(amount_document_currency - ?) < 0.01
                    LIMIT 1
                    """,
                    (reference, reference, amount_foreign),
                )
            
            match = cursor.fetchone()
            if not match:
                issues.append({
                    "type": "reference_mismatch",
                    "severity": "error",
                    "item": item_id,
                    "message": f"BlackLine item '{item_id}' reference '{reference}' (currency: {currency}, amount: {amount_foreign}) does not match any foreign book entry",
                })
    
    # 2. Check FX rate availability for dates used
    # FX rates validation removed - not needed
    # FX rates are not stored in database anymore since all amounts are already in GBP
    # Rates are still included in fx_calculations dict for documentation purposes only
    fx_calculations = scenario.get("fx_calculations", {})
    # No validation needed - rates are just documentation
    
    # 3. Check document number consistency
    us_doc_numbers = {entry.get("document_number") for entry in us_entries}
    fr_doc_numbers = {entry.get("document_number") for entry in fr_entries}
    
    # All US entries in a scenario should share the same document number
    if len(us_doc_numbers) > 1:
        warnings.append({
            "type": "document_number_inconsistency",
            "severity": "warning",
            "scenario": scenario_tag,
            "message": f"Multiple US document numbers found: {us_doc_numbers}",
        })
    
    if len(fr_doc_numbers) > 1:
        warnings.append({
            "type": "document_number_inconsistency",
            "severity": "warning",
            "scenario": scenario_tag,
            "message": f"Multiple FR document numbers found: {fr_doc_numbers}",
        })
    
    # 4. Check date format consistency
    # This is more of a warning since dates might be in different formats intentionally
    # Dates are stored in the database, we'd need to query them
    # For now, we'll skip this check or make it a warning
    
    # 5. Check amount consistency in correlations
    correlations = scenario.get("correlations", {})
    if "blackline_to_us" in correlations:
        for bl_id, us_ids in correlations["blackline_to_us"].items():
            bl_item = next((item for item in blackline_items if item["item_id"] == bl_id), None)
            if bl_item:
                bl_amount = bl_item.get("amount_foreign", 0)
                # Check if US entries match the amount
                for us_id in us_ids:
                    us_entry = next((entry for entry in us_entries if entry["entry_id"] == us_id), None)
                    if us_entry:
                        # Amount matching is already checked in reference matching above
                        pass
    
    return {
        "scenario_tag": scenario_tag,
        "valid": len(issues) == 0,
        "issues": issues,
        "warnings": warnings,
        "issue_count": len(issues),
        "warning_count": len(warnings),
    }


def generate_scenario_documentation(
    db_path: str, scenarios: List[Dict[str, Any]]
) -> None:
    """Generate markdown documentation for all scenarios."""
    doc_path = Path(db_path).parent / "scenario_documentation.md"
    with open(doc_path, "w", encoding="utf-8") as f:
        f.write("# ReconVoy Scenario Documentation\n\n")
        f.write(
            "This document describes the mock data scenarios generated for the ReconVoy pipeline.\n\n"
        )

        for scenario in scenarios:
            f.write(f"## {scenario['scenario_tag']}: {scenario['scenario_type']}\n\n")
            f.write(f"**Description:** {scenario['description']}\n\n")

            f.write("### BlackLine Items\n\n")
            f.write("| Item ID | Description | Currency | Foreign Amount | GBP Amount | Reference |\n")
            f.write("|---------|-------------|----------|---------------|------------|----------|\n")
            for item in scenario.get("blackline_items", []):
                f.write(
                    f"| {item['item_id']} | {item['description']} | {item['currency']} | "
                    f"{item['amount_foreign']:,.2f} | {item['amount_local_gbp']:,.2f} | "
                    f"{item['reference']} |\n"
                )

            if "us_books_entries" in scenario:
                f.write("\n### US Books Entries\n\n")
                f.write("| Entry ID | Document # | Description | Amount (USD) | Amount (GBP) | Reference |\n")
                f.write("|----------|------------|-------------|--------------|--------------|----------|\n")
                for entry in scenario["us_books_entries"]:
                    amount_usd = entry.get("amount_document_currency", 0.0)
                    amount_gbp = entry.get("amount_local_gbp", 0.0)
                    f.write(
                        f"| {entry['entry_id']} | {entry['document_number']} | "
                        f"{entry['description']} | {amount_usd:,.2f} | {amount_gbp:,.2f} | {entry['reference']} |\n"
                    )

            if "fr_books_entries" in scenario:
                f.write("\n### FR Books Entries\n\n")
                f.write("| Entry ID | Document # | Description | Amount (EUR) | Amount (GBP) | Reference |\n")
                f.write("|----------|------------|-------------|--------------|--------------|----------|\n")
                for entry in scenario["fr_books_entries"]:
                    amount_eur = entry.get("amount_document_currency", 0.0)
                    amount_gbp = entry.get("amount_local_gbp", 0.0)
                    f.write(
                        f"| {entry['entry_id']} | {entry['document_number']} | "
                        f"{entry['description']} | {amount_eur:,.2f} | {amount_gbp:,.2f} | {entry['reference']} |\n"
                    )

            if "correlations" in scenario:
                f.write("\n### Row Correlations\n\n")
                f.write(
                    "**BlackLine to US Books:**\n"
                )
                for bl_id, us_ids in scenario["correlations"].get(
                    "blackline_to_us", {}
                ).items():
                    f.write(f"- {bl_id} → {', '.join(us_ids)}\n")
                f.write("\n**BlackLine to FR Books:**\n")
                for bl_id, fr_ids in scenario["correlations"].get(
                    "blackline_to_fr", {}
                ).items():
                    f.write(f"- {bl_id} → {', '.join(fr_ids)}\n")

            if "expected_uk_journals" in scenario:
                f.write("\n### Expected UK Journal Entries\n\n")
                f.write(
                    "| GL Account | Description | Amount (GBP) | Header Text | Remarks |\n"
                )
                f.write("|------------|-------------|--------------|-------------|---------|\n")
                for journal in scenario["expected_uk_journals"]:
                    f.write(
                        f"| {journal['gl_account']} | {journal['description']} | "
                        f"{journal['amount_gbp']:,.2f} | {journal['header_text']} | "
                        f"{journal['remarks']} |\n"
                    )

            if "variance_calculation" in scenario:
                f.write("\n### Variance Calculation\n\n")
                var = scenario["variance_calculation"]
                f.write(f"- Total BlackLine GBP: {var['total_blackline_gbp']:,.2f}\n")
                f.write(f"- Total Matched GBP: {var['total_matched_gbp']:,.2f}\n")
                f.write(f"- Variance GBP: {var['variance_gbp']:,.2f}\n")
                f.write(f"- Variance %: {var['variance_percent']:.4f}%\n")

            f.write(f"\n### Expected Routing\n\n")
            f.write(f"**{scenario.get('expected_routing', 'Unknown')}**\n\n")
            
            # Validation Results
            validation = scenario.get("validation", {})
            if validation:
                f.write("### Data Validation\n\n")
                if validation.get("valid"):
                    f.write("✅ **Validation Status:** PASSED\n\n")
                else:
                    f.write("❌ **Validation Status:** FAILED\n\n")
                
                issues = validation.get("issues", [])
                warnings = validation.get("warnings", [])
                
                if issues:
                    f.write("#### Issues Found\n\n")
                    for issue in issues:
                        f.write(f"- **{issue.get('type', 'unknown')}**: {issue.get('message', '')}\n")
                    f.write("\n")
                
                if warnings:
                    f.write("#### Warnings\n\n")
                    for warning in warnings:
                        f.write(f"- **{warning.get('type', 'unknown')}**: {warning.get('message', '')}\n")
                    f.write("\n")
            
            f.write("---\n\n")

    logger.info("Generated scenario documentation at {}", doc_path)


def generate_rich_report(scenarios: List[Dict[str, Any]]) -> None:
    """Generate a comprehensive rich console report for all scenarios."""
    if not RICH_AVAILABLE:
        return

    console = Console()

    # Overall summary
    total_scenarios = len(scenarios)
    hitl_count = sum(1 for s in scenarios if s.get("expected_routing") == "HITL")
    st_count = sum(1 for s in scenarios if s.get("expected_routing") == "StraightThrough")
    total_blackline_items = sum(len(s.get("blackline_items", [])) for s in scenarios)
    
    # Validation summary
    total_issues = sum(len(s.get("validation", {}).get("issues", [])) for s in scenarios)
    total_warnings = sum(len(s.get("validation", {}).get("warnings", [])) for s in scenarios)
    passed_scenarios = sum(1 for s in scenarios if s.get("validation", {}).get("valid", False))
    failed_scenarios = total_scenarios - passed_scenarios

    console.print()
    summary_content = (
        f"[bold]Total Scenarios:[/bold] {total_scenarios} | "
        f"[bold]HITL Cases:[/bold] {hitl_count} | "
        f"[bold]Straight-Through Cases:[/bold] {st_count} | "
        f"[bold]Total BlackLine Items:[/bold] {total_blackline_items}"
    )
    
    if total_issues > 0 or total_warnings > 0:
        summary_content += (
            f"\n\n[bold]Validation:[/bold] "
            f"[green]✅ {passed_scenarios} passed[/green] | "
            f"[red]❌ {failed_scenarios} failed[/red] | "
            f"[red]{total_issues} issues[/red] | "
            f"[yellow]{total_warnings} warnings[/yellow]"
        )
    
    console.print(
        Panel.fit(
            summary_content,
            title="[bold blue]ReconVoy Mock Data Generation Summary[/bold blue]",
            border_style="blue",
        )
    )
    console.print()

    # Detailed report for each scenario
    for idx, scenario in enumerate(scenarios, 1):
        scenario_tag = scenario.get("scenario_tag", "Unknown")
        scenario_type = scenario.get("scenario_type", "Unknown")
        description = scenario.get("description", "")
        expected_routing = scenario.get("expected_routing", "Unknown")
        routing_color = "red" if expected_routing == "HITL" else "green"

        # Scenario header
        console.print(
            Panel.fit(
                f"[bold]{scenario_type}[/bold]\n\n{description}",
                title=f"[bold cyan]Scenario {idx}: {scenario_tag}[/bold cyan]",
                border_style="cyan",
            )
        )
        console.print()

        # BlackLine Items Table
        blackline_items = scenario.get("blackline_items", [])
        if blackline_items:
            bl_table = RichTable(
                title="[bold]BlackLine Unmatched Items[/bold]",
                show_header=True,
                header_style="bold magenta",
                border_style="blue",
                box=box.ROUNDED,
                show_lines=True,
            )
            bl_table.add_column("Item ID", style="cyan", no_wrap=True, width=20)
            bl_table.add_column("Description", style="white", width=30)
            bl_table.add_column("Currency", style="yellow", width=10)
            bl_table.add_column("Foreign Amount", style="green", justify="right", width=16)
            bl_table.add_column("GBP Amount", style="green", justify="right", width=14)
            bl_table.add_column("Reference", style="bright_cyan", width=25)

            for item in blackline_items:
                bl_table.add_row(
                    item["item_id"],
                    item["description"],
                    item["currency"],
                    f"{item['amount_foreign']:,.2f}",
                    f"{item['amount_local_gbp']:,.2f}",
                    item["reference"],
                )
            console.print(bl_table)
            console.print()

        # Foreign Books Entries
        us_entries = scenario.get("us_books_entries", [])
        fr_entries = scenario.get("fr_books_entries", [])

        if us_entries:
            us_table = RichTable(
                title="[bold]US Books Entries[/bold]",
                show_header=True,
                header_style="bold magenta",
                border_style="blue",
                box=box.ROUNDED,
                show_lines=True,
            )
            us_table.add_column("Entry ID", style="cyan", no_wrap=True, width=20)
            us_table.add_column("Document #", style="yellow", width=15)
            us_table.add_column("Description", style="white", width=35)
            us_table.add_column("Amount (USD)", style="green", justify="right", width=16)
            us_table.add_column("Amount (GBP)", style="green", justify="right", width=16)
            us_table.add_column("Reference", style="bright_cyan", width=25)

            for entry in us_entries:
                amount_usd = entry.get("amount_document_currency", 0.0)
                amount_gbp = entry.get("amount_local_gbp", 0.0)
                us_table.add_row(
                    entry["entry_id"],
                    entry["document_number"],
                    entry["description"],
                    f"{amount_usd:,.2f}",
                    f"{amount_gbp:,.2f}",
                    entry["reference"],
                )
            console.print(us_table)
            console.print()

        if fr_entries:
            fr_table = RichTable(
                title="[bold]FR Books Entries[/bold]",
                show_header=True,
                header_style="bold magenta",
                border_style="blue",
                box=box.ROUNDED,
                show_lines=True,
            )
            fr_table.add_column("Entry ID", style="cyan", no_wrap=True, width=20)
            fr_table.add_column("Document #", style="yellow", width=15)
            fr_table.add_column("Description", style="white", width=35)
            fr_table.add_column("Amount (EUR)", style="green", justify="right", width=16)
            fr_table.add_column("Amount (GBP)", style="green", justify="right", width=16)
            fr_table.add_column("Reference", style="bright_cyan", width=25)

            for entry in fr_entries:
                amount_eur = entry.get("amount_document_currency", 0.0)
                amount_gbp = entry.get("amount_local_gbp", 0.0)
                fr_table.add_row(
                    entry["entry_id"],
                    entry["document_number"],
                    entry["description"],
                    f"{amount_eur:,.2f}",
                    f"{amount_gbp:,.2f}",
                    entry["reference"],
                )
            console.print(fr_table)
            console.print()

        # Row Correlations
        correlations = scenario.get("correlations", {})
        if correlations:
            console.print("[bold]Row Correlations:[/bold]")
            if "blackline_to_us" in correlations:
                console.print("  [cyan]BlackLine → US Books:[/cyan]")
                for bl_id, us_ids in correlations["blackline_to_us"].items():
                    console.print(f"    {bl_id} → {', '.join(us_ids)}")
            if "blackline_to_fr" in correlations:
                console.print("  [cyan]BlackLine → FR Books:[/cyan]")
                for bl_id, fr_ids in correlations["blackline_to_fr"].items():
                    console.print(f"    {bl_id} → {', '.join(fr_ids)}")
            if "blackline_to_bank" in correlations:
                console.print("  [cyan]BlackLine → Bank Entries:[/cyan]")
                for bl_id, bank_ids in correlations["blackline_to_bank"].items():
                    console.print(f"    {bl_id} → {', '.join(bank_ids)}")
            console.print()

        # Expected UK Journal Entries
        uk_journals = scenario.get("expected_uk_journals", [])
        if uk_journals:
            journal_table = RichTable(
                title="[bold]Expected UK Journal Entries (Output)[/bold]",
                show_header=True,
                header_style="bold magenta",
                border_style="green",
                box=box.ROUNDED,
                show_lines=True,
            )
            journal_table.add_column("GL Account", style="cyan", width=12)
            journal_table.add_column("Description", style="white", width=25)
            journal_table.add_column("Amount (GBP)", style="green", justify="right", width=16)
            journal_table.add_column("Header Text", style="bright_cyan", width=18)
            journal_table.add_column("Remarks", style="yellow", width=10)

            for journal in uk_journals:
                journal_table.add_row(
                    journal["gl_account"],
                    journal["description"],
                    f"{journal['amount_gbp']:,.2f}",
                    journal["header_text"],
                    journal["remarks"],
                )
            console.print(journal_table)
            console.print()

        # Variance Calculation
        variance_calc = scenario.get("variance_calculation", {})
        if variance_calc:
            variance_gbp = variance_calc.get("variance_gbp", 0)
            variance_percent = variance_calc.get("variance_percent", 0)
            total_blackline = variance_calc.get("total_blackline_gbp", 0)
            total_matched = variance_calc.get("total_matched_gbp", 0)

            variance_color = "red" if abs(variance_gbp) > 100 else "green"
            variance_sign = "+" if variance_gbp >= 0 else ""

            console.print(
                Panel(
                    f"[bold]Total BlackLine GBP:[/bold] {total_blackline:,.2f}\n"
                    f"[bold]Total Matched GBP:[/bold] {total_matched:,.2f}\n"
                    f"[bold]Variance GBP:[/bold] [{variance_color}]{variance_sign}{variance_gbp:,.2f}[/{variance_color}]\n"
                    f"[bold]Variance %:[/bold] [{variance_color}]{variance_sign}{variance_percent:.4f}%[/{variance_color}]",
                    title="[bold]FX Variance Calculation[/bold]",
                    border_style="yellow",
                )
            )
            console.print()

        # Expected Routing
        console.print(
            Panel.fit(
                f"[bold {routing_color}]{expected_routing}[/bold {routing_color}]",
                title="[bold]Expected Routing[/bold]",
                border_style=routing_color,
            )
        )
        console.print()
        
        # Validation Results
        validation = scenario.get("validation", {})
        if validation:
            valid = validation.get("valid", False)
            issues = validation.get("issues", [])
            warnings = validation.get("warnings", [])
            
            if valid and not warnings:
                validation_status = "[bold green]✅ VALIDATION PASSED[/bold green]"
                border_color = "green"
            elif issues:
                validation_status = f"[bold red]❌ VALIDATION FAILED ({len(issues)} issues)[/bold red]"
                border_color = "red"
            else:
                validation_status = f"[bold yellow]⚠️  VALIDATION PASSED WITH WARNINGS ({len(warnings)} warnings)[/bold yellow]"
                border_color = "yellow"
            
            validation_panel_content = validation_status
            
            if issues:
                validation_panel_content += "\n\n[bold red]Issues:[/bold red]"
                for issue in issues[:5]:  # Show first 5 issues
                    validation_panel_content += f"\n  • {issue.get('message', '')}"
                if len(issues) > 5:
                    validation_panel_content += f"\n  ... and {len(issues) - 5} more"
            
            if warnings:
                validation_panel_content += "\n\n[bold yellow]Warnings:[/bold yellow]"
                for warning in warnings[:3]:  # Show first 3 warnings
                    validation_panel_content += f"\n  • {warning.get('message', '')}"
                if len(warnings) > 3:
                    validation_panel_content += f"\n  ... and {len(warnings) - 3} more"
            
            console.print(
                Panel(
                    validation_panel_content,
                    title="[bold]Data Validation[/bold]",
                    border_style=border_color,
                )
            )
            console.print()

        # Separator between scenarios
        if idx < len(scenarios):
            console.print()
            console.print("[dim]" + "─" * 80 + "[/dim]")
            console.print()


def generate_pdf_example_scenario_3(
    conn: sqlite3.Connection, index: int
) -> Dict[str, Any]:
    """Generate the exact PDF example case (Scenario 3) with no scaling.
    
    This is the canonical example from the PDF:
    - UK receivable from US: £500,000 (USD 625,000)
    - UK payable to FR: £6,048 (EUR 7,200)
    - UK bank wire received: £493,600 (GBP)
    
    Variance calculation:
    - variance = GBP_item - (USD_item + EUR_item)
    - variance = £493,600 - (£500,000 + £6,048) = -£12,448 (FX Gain)
    
    Journal structure (from PDF):
    - Row 1: Bank Debit = £493,600 (GBP item)
    - Row 2: IC Payable FR Debit = £6,048 (EUR item)
    - Row 3: FX Loss Debit = £352 (balances journal)
    - Row 4: IC Receivable US Credit = £500,000 (USD invoice amount - ALWAYS)
    
    Note: The FX entry (£352) balances the journal:
    - FX = IC Receivable US - Bank - IC Payable FR
    - FX = £500,000 - £493,600 - £6,048 = £352 (FX Loss)
    """
    # Exact amounts from PDF (no scaling)
    uk_receivable_gbp = 500_000.00
    uk_receivable_usd = 625_000.00
    fr_invoice_eur = 7_200.00
    fr_invoice_gbp = 6_048.00
    us_wire_gbp = 493_600.00  # Exact from PDF
    us_wire_usd = 615_000.00  # Exact from PDF
    
    # Calculate variance (for routing decision)
    variance_gbp = us_wire_gbp - (uk_receivable_gbp + fr_invoice_gbp)  # -£12,448 (FX Gain)
    
    return generate_scenario_3(
        conn, 
        index=0,  # Use index 0 for PDF example (will be shown as first case)
        target_variance_gbp=variance_gbp,
        exact_amounts={
            "uk_receivable_gbp": uk_receivable_gbp,
            "uk_receivable_usd": uk_receivable_usd,
            "us_wire_usd": us_wire_usd,
            "us_wire_gbp": us_wire_gbp,
            "fr_invoice_eur": fr_invoice_eur,
            "fr_invoice_gbp": fr_invoice_gbp,
            "scenario_tag": "scenario3_pdf_example",
            "us_document_number": "150000881",  # From PDF
            "fr_document_number": "190000442",  # From PDF
            "uk_document_number": "UK_INV_001",
        }
    )


def get_deterministic_scenarios() -> List[Dict[str, Any]]:
    """Return a deterministic set of scenario configurations with fixed amounts.
    
    Returns 10 scenarios total:
    - 1 PDF Example (canonical case from PDF)
    - 4 HITL cases (2 FX Gain, 2 FX Loss)
    - 4 Straight-through cases (2 FX Gain, 2 FX Loss)
    - 1 Additional HITL case for variety
    
    Each scenario has:
    - Fixed amounts (no random scaling)
    - Known variance (FX Gain/Loss)
    - Known routing (HITL/Straight-Through)
    """
    return [
        # PDF Example (index 999, will be shown as first case)
        # Using index 999 to ensure unique item IDs (avoids conflicts with deterministic scenarios 0-9)
        {
            "index": 999,
            "scenario_tag": "scenario3_pdf_example",
            "uk_receivable_gbp": 500_000.00,
            "uk_receivable_usd": 625_000.00,
            "fr_invoice_eur": 7_200.00,
            "fr_invoice_gbp": 6_048.00,
            "us_wire_gbp": 493_600.00,
            "us_wire_usd": 615_000.00,
            "expected_fx_entry": 352.00,  # FX Loss
            "expected_routing": "HITL",
            "us_document_number": "150000881",
            "fr_document_number": "190000442",
            "uk_document_number": "UK_INV_001",
        },
        # HITL FX Gain -250
        # Base: 750K invoice, 10.8K FR invoice
        # Formula: fx_entry = uk_receivable - us_wire - fr_invoice
        # So: us_wire = uk_receivable - fr_invoice - fx_entry
        # us_wire = 750_000 - 9_072 - (-250) = 741_178
        # USD wire: using rate ~1.25 (625K/500K from PDF)
        {
            "index": 0,
            "scenario_tag": "scenario3_001",
            "uk_receivable_gbp": 750_000.00,
            "uk_receivable_usd": 937_500.00,  # 750K * 1.25
            "fr_invoice_eur": 10_800.00,
            "fr_invoice_gbp": 9_072.00,  # 10.8K * 0.84 EUR/GBP rate
            "us_wire_gbp": 741_178.00,  # 750_000 - 9_072 - (-250)
            "us_wire_usd": round(741_178.00 * 1.25, 2),  # ~926,472.50
            "expected_fx_entry": -250.00,  # FX Gain
            "expected_routing": "HITL",
        },
        # HITL FX Loss +250
        # Base: 600K invoice, 8.64K FR invoice
        # us_wire = 600_000 - 7_257.60 - 250 = 592_492.40
        {
            "index": 1,
            "scenario_tag": "scenario3_002",
            "uk_receivable_gbp": 600_000.00,
            "uk_receivable_usd": 750_000.00,  # 600K * 1.25
            "fr_invoice_eur": 8_640.00,
            "fr_invoice_gbp": 7_257.60,  # 8.64K * 0.84
            "us_wire_gbp": 592_492.40,  # 600_000 - 7_257.60 - 250
            "us_wire_usd": round(592_492.40 * 1.25, 2),  # ~740,615.50
            "expected_fx_entry": 250.00,  # FX Loss
            "expected_routing": "HITL",
        },
        # Straight-through FX Gain -50
        # Base: 400K invoice, 5.76K FR invoice
        # us_wire = 400_000 - 4_838.40 - (-50) = 395_211.60
        {
            "index": 2,
            "scenario_tag": "scenario3_003",
            "uk_receivable_gbp": 400_000.00,
            "uk_receivable_usd": 500_000.00,  # 400K * 1.25
            "fr_invoice_eur": 5_760.00,
            "fr_invoice_gbp": 4_838.40,  # 5.76K * 0.84
            "us_wire_gbp": 395_211.60,  # 400_000 - 4_838.40 - (-50)
            "us_wire_usd": round(395_211.60 * 1.25, 2),  # ~494,014.50
            "expected_fx_entry": -50.00,  # FX Gain
            "expected_routing": "StraightThrough",
        },
        # Straight-through FX Loss +50
        # Base: 350K invoice, 5.04K FR invoice
        # us_wire = 350_000 - 4_233.60 - 50 = 345_716.40
        {
            "index": 3,
            "scenario_tag": "scenario3_004",
            "uk_receivable_gbp": 350_000.00,
            "uk_receivable_usd": 437_500.00,  # 350K * 1.25
            "fr_invoice_eur": 5_040.00,
            "fr_invoice_gbp": 4_233.60,  # 5.04K * 0.84
            "us_wire_gbp": 345_716.40,  # 350_000 - 4_233.60 - 50
            "us_wire_usd": round(345_716.40 * 1.25, 2),  # ~432,145.50
            "expected_fx_entry": 50.00,  # FX Loss
            "expected_routing": "StraightThrough",
        },
        # Additional scenarios for variety (can be used if scenario3_count > 4)
        # HITL FX Gain -200
        # Base: 850K invoice, 12.24K FR invoice
        # us_wire = 850_000 - 10_281.60 - (-200) = 839_918.40
        {
            "index": 4,
            "scenario_tag": "scenario3_005",
            "uk_receivable_gbp": 850_000.00,
            "uk_receivable_usd": 1_062_500.00,  # 850K * 1.25
            "fr_invoice_eur": 12_240.00,
            "fr_invoice_gbp": 10_281.60,  # 12.24K * 0.84
            "us_wire_gbp": 839_918.40,  # 850_000 - 10_281.60 - (-200)
            "us_wire_usd": round(839_918.40 * 1.25, 2),  # ~1,049,898.00
            "expected_fx_entry": -200.00,  # FX Gain
            "expected_routing": "HITL",
        },
        # HITL FX Loss +200
        # Base: 450K invoice, 6.48K FR invoice
        # us_wire = 450_000 - 5_443.20 - 200 = 444_356.80
        {
            "index": 5,
            "scenario_tag": "scenario3_006",
            "uk_receivable_gbp": 450_000.00,
            "uk_receivable_usd": 562_500.00,  # 450K * 1.25
            "fr_invoice_eur": 6_480.00,
            "fr_invoice_gbp": 5_443.20,  # 6.48K * 0.84
            "us_wire_gbp": 444_356.80,  # 450_000 - 5_443.20 - 200
            "us_wire_usd": round(444_356.80 * 1.25, 2),  # ~555,446.00
            "expected_fx_entry": 200.00,  # FX Loss
            "expected_routing": "HITL",
        },
        # Straight-through FX Gain -30
        # Base: 300K invoice, 4.32K FR invoice
        # us_wire = 300_000 - 3_628.80 - (-30) = 296_401.20
        {
            "index": 6,
            "scenario_tag": "scenario3_007",
            "uk_receivable_gbp": 300_000.00,
            "uk_receivable_usd": 375_000.00,  # 300K * 1.25
            "fr_invoice_eur": 4_320.00,
            "fr_invoice_gbp": 3_628.80,  # 4.32K * 0.84
            "us_wire_gbp": 296_401.20,  # 300_000 - 3_628.80 - (-30)
            "us_wire_usd": round(296_401.20 * 1.25, 2),  # ~370,501.50
            "expected_fx_entry": -30.00,  # FX Gain
            "expected_routing": "StraightThrough",
        },
        # Straight-through FX Loss +30
        # Base: 250K invoice, 3.6K FR invoice
        # us_wire = 250_000 - 3_024.00 - 30 = 246_946.00
        {
            "index": 7,
            "scenario_tag": "scenario3_008",
            "uk_receivable_gbp": 250_000.00,
            "uk_receivable_usd": 312_500.00,  # 250K * 1.25
            "fr_invoice_eur": 3_600.00,
            "fr_invoice_gbp": 3_024.00,  # 3.6K * 0.84
            "us_wire_gbp": 246_946.00,  # 250_000 - 3_024.00 - 30
            "us_wire_usd": round(246_946.00 * 1.25, 2),  # ~308,682.50
            "expected_fx_entry": 30.00,  # FX Loss
            "expected_routing": "StraightThrough",
        },
        # HITL FX Gain -150
        # Base: 800K invoice, 11.52K FR invoice
        # us_wire = 800_000 - 9_676.80 - (-150) = 790_473.20
        {
            "index": 8,
            "scenario_tag": "scenario3_009",
            "uk_receivable_gbp": 800_000.00,
            "uk_receivable_usd": 1_000_000.00,  # 800K * 1.25
            "fr_invoice_eur": 11_520.00,
            "fr_invoice_gbp": 9_676.80,  # 11.52K * 0.84
            "us_wire_gbp": 790_473.20,  # 800_000 - 9_676.80 - (-150)
            "us_wire_usd": round(790_473.20 * 1.25, 2),  # ~988,091.50
            "expected_fx_entry": -150.00,  # FX Gain
            "expected_routing": "HITL",
        },
        # HITL FX Loss +150
        # Base: 550K invoice, 7.92K FR invoice
        # us_wire = 550_000 - 6_652.80 - 150 = 543_197.20
        {
            "index": 9,
            "scenario_tag": "scenario3_010",
            "uk_receivable_gbp": 550_000.00,
            "uk_receivable_usd": 687_500.00,  # 550K * 1.25
            "fr_invoice_eur": 7_920.00,
            "fr_invoice_gbp": 6_652.80,  # 7.92K * 0.84
            "us_wire_gbp": 543_197.20,  # 550_000 - 6_652.80 - 150
            "us_wire_usd": round(543_197.20 * 1.25, 2),  # ~678,996.50
            "expected_fx_entry": 150.00,  # FX Loss
            "expected_routing": "HITL",
        },
    ]


def generate_mock_data(
    db_path: str,
    scenario3_count: int = 4,
) -> None:
    """Create schema and insert mock scenarios.
    
    Generates Scenario 3 cases: UK Sells to US, US Pays FR on Behalf.
    By default generates 5 cases:
    - 1 PDF Example (canonical case from PDF)
    - 2 HITL: 1 FX Gain (negative variance), 1 FX Loss (positive variance)
    - 2 Straight-through: 1 FX Gain (negative variance), 1 FX Loss (positive variance)
    
    Uses deterministic scenarios with fixed amounts for predictable testing.
    All scenarios have known FX variance amounts and routing outcomes.
    """
    create_database_schema(db_path)
    conn = sqlite3.connect(db_path)
    scenarios = []

    try:
        # Get deterministic scenario configurations
        deterministic_scenarios = get_deterministic_scenarios()
        
        # First, generate the PDF example case (index 999, will be shown as first case)
        logger.info("Generating PDF example case (canonical scenario from PDF)...")
        pdf_scenario = deterministic_scenarios[0]  # PDF example is first
        pdf_doc = generate_scenario_3(
            conn,
            index=pdf_scenario["index"],
            target_variance_gbp=pdf_scenario["expected_fx_entry"],
            exact_amounts={
                "uk_receivable_gbp": pdf_scenario["uk_receivable_gbp"],
                "uk_receivable_usd": pdf_scenario["uk_receivable_usd"],
                "us_wire_usd": pdf_scenario["us_wire_usd"],
                "us_wire_gbp": pdf_scenario["us_wire_gbp"],
                "fr_invoice_eur": pdf_scenario["fr_invoice_eur"],
                "fr_invoice_gbp": pdf_scenario["fr_invoice_gbp"],
                "scenario_tag": pdf_scenario["scenario_tag"],
                "us_document_number": pdf_scenario.get("us_document_number", "150000881"),
                "fr_document_number": pdf_scenario.get("fr_document_number", "190000442"),
                "uk_document_number": pdf_scenario.get("uk_document_number", "UK_INV_001"),
            }
        )
        scenarios.append(pdf_doc)
        
        # Generate Scenario 3 cases using deterministic scenarios (skip PDF example, start from index 1)
        # By default, use first 4 deterministic scenarios (indices 1-4)
        # This gives us: 2 HITL (1 Gain, 1 Loss) + 2 Straight-through (1 Gain, 1 Loss)
        for i in range(scenario3_count):
            scenario_config = deterministic_scenarios[i + 1]  # Skip PDF example (index 999)
            
            doc = generate_scenario_3(
                conn,
                index=scenario_config["index"],
                target_variance_gbp=scenario_config["expected_fx_entry"],
                exact_amounts={
                    "uk_receivable_gbp": scenario_config["uk_receivable_gbp"],
                    "uk_receivable_usd": scenario_config["uk_receivable_usd"],
                    "us_wire_usd": scenario_config["us_wire_usd"],
                    "us_wire_gbp": scenario_config["us_wire_gbp"],
                    "fr_invoice_eur": scenario_config["fr_invoice_eur"],
                    "fr_invoice_gbp": scenario_config["fr_invoice_gbp"],
                    "scenario_tag": scenario_config["scenario_tag"],
                }
            )
            scenarios.append(doc)

        conn.commit()

        # Validate all scenarios
        logger.info("Validating generated scenarios...")
        for scenario in scenarios:
            validation_result = validate_scenario_data(conn, scenario)
            scenario["validation"] = validation_result
            if not validation_result["valid"]:
                logger.warning(
                    "Scenario {} validation failed: {} issues, {} warnings",
                    validation_result["scenario_tag"],
                    validation_result["issue_count"],
                    validation_result["warning_count"],
                )
            elif validation_result["warning_count"] > 0:
                logger.info(
                    "Scenario {} validation passed with {} warnings",
                    validation_result["scenario_tag"],
                    validation_result["warning_count"],
                )
            else:
                logger.info("Scenario {} validation passed", validation_result["scenario_tag"])

        # Generate documentation
        generate_scenario_documentation(db_path, scenarios)

        # Generate rich console report
        if RICH_AVAILABLE:
            generate_rich_report(scenarios)
        else:
            # Fallback to simple logging
            logger.info("BlackLine unmatched items summary:")
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT item_id, source, currency, amount_local_gbp, status
                FROM blackline_unmatched_items
                ORDER BY item_id
                """
            )
            rows = cursor.fetchall()
            for item_id, source, currency, amount, status in rows:
                logger.info(
                    "  item_id={} source={} amount={} {} status={}",
                    item_id,
                    source,
                    amount,
                    currency,
                    status,
                )

    finally:
        conn.close()
    logger.info("ReconVoy mock data generation complete at {}", db_path)


# ============================================================================
# CLI
# ============================================================================


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Setup ReconVoy database and mock data (Phase 2 Redesign)"
    )
    parser.add_argument(
        "--db-path",
        default="projects/icp/data/reconvoy/reconvoy_database.db",
        help="Path to SQLite database file",
    )
    parser.add_argument(
        "--reset",
        action="store_true",
        default=False,
        help="Reset database (delete existing and recreate) (default: False)",
    )
    parser.add_argument(
        "--no-reset",
        dest="reset",
        action="store_false",
        help="Do not reset database (keep existing data) (default: False)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Random seed for reproducibility (default: None = use current time)",
    )
    parser.add_argument(
        "--scenario3-count",
        type=int,
        default=4,
        help="Number of Scenario 3 cases to generate (excluding PDF example). Default: 4 (2 HITL + 2 Straight-through, with FX Gain/Loss mix). PDF example is always generated as the 5th case.",
    )

    args = parser.parse_args(argv)

    # Seed RNG
    if args.seed is not None:
        random.seed(args.seed)
    else:
        import time

        random.seed(int(time.time()))

    project_name = detect_project_name(Path.cwd())
    db_path = resolve_script_path(args.db_path, project_name=project_name)

    if args.reset and db_path.exists():
        db_path.unlink()
        logger.info("Removed existing ReconVoy database at {}", db_path)

    db_path.parent.mkdir(parents=True, exist_ok=True)

    logger.info(
        "ReconVoy Database Setup (Phase 2)\nDatabase: {}\nReset: {}\nSeed: {}",
        db_path,
        args.reset,
        args.seed,
    )

    logger.info(
        "Generating ReconVoy mock data: scenario3_count={} (plus 1 PDF example = {} total cases)",
        args.scenario3_count,
        args.scenario3_count + 1,
    )

    generate_mock_data(
        str(db_path),
        scenario3_count=max(args.scenario3_count, 0),
    )
    logger.info("ReconVoy database setup complete at {}", db_path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
