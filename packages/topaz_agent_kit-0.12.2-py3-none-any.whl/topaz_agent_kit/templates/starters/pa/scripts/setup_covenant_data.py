#!/usr/bin/env python3
"""Setup Covenant pipeline data.

Creates realistic contract lifecycle data:
- Detailed signed contracts (multi-page, comprehensive)
- Simple change orders (1-2 pages)
- Database setup with schema

When run multiple times, detects existing contracts and creates new change orders for them.

Usage:
    python scripts/setup_covenant_data.py
    uv run -m scripts.setup_covenant_data
"""

import argparse
import json
import random
import re
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any

# Add project root to path
project_root = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, str(project_root))

from topaz_agent_kit.utils.path_resolver import resolve_script_path, detect_project_name

try:
    from reportlab.lib.pagesizes import letter, A4  # type: ignore[reportMissingModuleSource]
    from reportlab.lib import colors  # type: ignore[reportMissingModuleSource]
    from reportlab.lib.units import inch  # type: ignore[reportMissingModuleSource]
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak  # type: ignore[reportMissingModuleSource]
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle  # type: ignore[reportMissingModuleSource]
    from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT, TA_JUSTIFY  # type: ignore[reportMissingModuleSource]
    REPORTLAB_AVAILABLE = True
except ImportError as e:
    REPORTLAB_AVAILABLE = False
    # Only print warning if we're actually going to need PDF generation
    # (This avoids noise when reportlab is optional)
    import sys
    if '--help' not in sys.argv and 'generate' in ' '.join(sys.argv):
        print(f"Warning: reportlab not available ({e}). PDF generation will be skipped.")
        print("Install with: pip install reportlab")

try:
    import pypdf  # type: ignore[reportMissingModuleSource]
    PYPDF_AVAILABLE = True
except ImportError:
    PYPDF_AVAILABLE = False
    print("Warning: pypdf not available. PDF reading will be limited.")
    print("Install with: pip install pypdf")


# ============================================================================
# Constants
# ============================================================================

SOW_ID_PREFIX = f"SOW-{datetime.now().year}"
PO_ID_PREFIX = f"PO-{datetime.now().year}"
BASE_DIR = "data/covenant"

# Service Provider Names (for randomization)
SERVICE_PROVIDERS = [
    "Aker Solutions UK Limited",
    "Wood Group Engineering Limited",
    "Petrofac Facilities Management Limited",
    "TechnipFMC UK Limited",
    "Saipem UK Limited",
    "Subsea 7 UK Limited",
    "McDermott International (UK) Limited",
    "Fluor Limited",
    "KBR UK Limited",
    "AMEC Foster Wheeler Energy Limited",
    "Babcock International Group PLC",
    "Siemens Energy Limited",
    "ABB Limited",
    "Schlumberger UK Limited",
    "Halliburton Energy Services UK Limited"
]

# Oil & Gas Project Types for Purpose & Scope (10-12 different project types)
PROJECT_SCOPES = [
    {
        "type": "Upstream Development - Wells & Infrastructure",
        "description": [
            "This Agreement governs the outsourcing of capital project execution services for upstream oil and gas development.",
            "Scope includes: (i) {num_wells} horizontal development wells with completion and flowlines; "
            "(ii) well pad construction and access roads; (iii) production facilities including separators, compressors, and storage tanks; "
            "and (iv) gathering system with {pipeline_km} km of flowlines.",
            "Scope includes materials (casing, tubing, wellheads, valves, pumps, compressors, separators) "
            "and labor (drilling crews, completion teams, construction crews, facilities engineers).",
            "All work shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Refinery Upgrade - CDU & HDS Units",
        "description": [
            "This Agreement governs the outsourcing of capital project execution services for refinery infrastructure upgrades.",
            "Scope includes: (i) Crude Distillation Unit (CDU) upgrade with new fractionation columns and heat exchangers; "
            "(ii) Hydrodesulfurization (HDS) unit installation with reactors, compressors, and catalyst systems; "
            "(iii) utilities and offsites including steam generation, cooling water systems, and power distribution; "
            "and (iv) environmental systems including sulfur recovery and wastewater treatment.",
            "Scope includes materials (columns, heat exchangers, reactors, compressors, catalysts, pumps, valves, instrumentation) "
            "and labor (refinery operators, process engineers, construction crews, commissioning teams).",
            "All work shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Pipeline Infrastructure - Transmission & Distribution",
        "description": [
            "This Agreement governs the outsourcing of capital project execution services for pipeline infrastructure development.",
            "Scope includes: (i) {pipeline_km} km, 24-inch crude oil transmission pipeline with pump stations; "
            "(ii) terminal facilities including tankage, metering stations, and loading facilities; "
            "(iii) pipeline integrity systems including cathodic protection and leak detection; "
            "and (iv) access roads and right-of-way maintenance.",
            "Scope includes materials (pipe, valves, pumps, tanks, metering equipment, instrumentation, cathodic protection systems) "
            "and labor (pipeline technicians, construction crews, instrumentation engineers, maintenance teams).",
            "All work shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Gas Processing Plant - LNG & NGL Facilities",
        "description": [
            "This Agreement governs the outsourcing of capital project execution services for natural gas processing facilities.",
            "Scope includes: (i) gas processing plant with dehydration, sweetening, and NGL extraction units; "
            "(ii) LNG liquefaction train with compressors, heat exchangers, and storage tanks; "
            "(iii) utilities including power generation, water treatment, and flare systems; "
            "and (iv) export facilities including loading jetties and marine infrastructure.",
            "Scope includes materials (process units, compressors, heat exchangers, storage tanks, cryogenic equipment, instrumentation) "
            "and labor (process engineers, operators, construction crews, marine engineers).",
            "All work shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Offshore Platform - Drilling & Production",
        "description": [
            "This Agreement governs the outsourcing of capital project execution services for offshore platform development.",
            "Scope includes: (i) fixed platform design and installation with {num_wells} well slots; "
            "(ii) topsides facilities including production separators, gas compression, and water injection systems; "
            "(iii) subsea infrastructure including flowlines, manifolds, and umbilicals; "
            "and (iv) export pipeline to onshore terminal.",
            "Scope includes materials (platform structure, topsides modules, subsea equipment, pipelines, umbilicals) "
            "and labor (offshore construction crews, marine engineers, subsea specialists, commissioning teams).",
            "All work shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Chemical Plant - Petrochemicals & Derivatives",
        "description": [
            "This Agreement governs the outsourcing of capital project execution services for petrochemical plant construction.",
            "Scope includes: (i) ethylene cracker unit with furnaces, compressors, and separation columns; "
            "(ii) polyethylene/polypropylene production units with reactors and extrusion systems; "
            "(iii) utilities including steam, cooling water, and nitrogen generation; "
            "and (iv) storage and logistics facilities including warehouses and rail loading.",
            "Scope includes materials (reactors, furnaces, compressors, columns, extruders, storage tanks, instrumentation) "
            "and labor (process engineers, operators, construction crews, maintenance teams).",
            "All work shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Power Generation - Combined Heat & Power",
        "description": [
            "This Agreement governs the outsourcing of capital project execution services for power generation facilities.",
            "Scope includes: (i) combined cycle gas turbine (CCGT) power plant with {num_wells} gas turbines; "
            "(ii) heat recovery steam generators (HRSG) and steam turbines; "
            "(iii) electrical infrastructure including transformers, switchgear, and grid connection; "
            "and (iv) fuel gas supply system with compression and metering.",
            "Scope includes materials (gas turbines, steam turbines, HRSGs, generators, transformers, switchgear, instrumentation) "
            "and labor (power engineers, operators, electrical technicians, maintenance crews).",
            "All work shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Carbon Capture & Storage (CCS) Facility",
        "description": [
            "This Agreement governs the outsourcing of capital project execution services for carbon capture and storage infrastructure.",
            "Scope includes: (i) CO2 capture plant with amine units, compressors, and dehydration systems; "
            "(ii) {pipeline_km} km CO2 transmission pipeline to storage site; "
            "(iii) injection wells and monitoring systems for geological storage; "
            "and (iv) utilities and support facilities.",
            "Scope includes materials (capture units, compressors, pipelines, injection equipment, monitoring systems, instrumentation) "
            "and labor (process engineers, pipeline technicians, geologists, monitoring specialists).",
            "All work shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Terminal & Storage - Crude & Products",
        "description": [
            "This Agreement governs the outsourcing of capital project execution services for terminal and storage facilities.",
            "Scope includes: (i) crude oil storage terminal with {num_wells} storage tanks (total capacity {pipeline_km} million barrels); "
            "(ii) product storage and blending facilities; (iii) marine loading facilities including jetties and berths; "
            "and (iv) pipeline connections and metering systems.",
            "Scope includes materials (storage tanks, pumps, valves, loading arms, metering systems, fire protection, instrumentation) "
            "and labor (terminal operators, marine engineers, construction crews, maintenance teams).",
            "All work shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Water Treatment - Produced Water & Wastewater",
        "description": [
            "This Agreement governs the outsourcing of capital project execution services for water treatment facilities.",
            "Scope includes: (i) produced water treatment plant with separation, filtration, and desalination units; "
            "(ii) wastewater treatment facility with biological treatment and tertiary filtration; "
            "(iii) water injection system with {pipeline_km} km pipeline and injection wells; "
            "and (iv) sludge handling and disposal facilities.",
            "Scope includes materials (treatment units, filters, pumps, pipelines, injection equipment, instrumentation) "
            "and labor (water treatment engineers, operators, pipeline technicians, environmental specialists).",
            "All work shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Renewable Energy - Wind & Solar Integration",
        "description": [
            "This Agreement governs the outsourcing of capital project execution services for renewable energy integration.",
            "Scope includes: (i) offshore wind farm with {num_wells} wind turbines and subsea export cables; "
            "(ii) onshore solar PV facility with inverters and grid connection; "
            "(iii) energy storage system with battery banks and power conversion; "
            "and (iv) grid integration infrastructure including substations and transmission lines.",
            "Scope includes materials (wind turbines, solar panels, inverters, batteries, cables, substations, instrumentation) "
            "and labor (renewable energy engineers, electrical technicians, marine crews, grid specialists).",
            "All work shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Digital Infrastructure - Automation & Control Systems",
        "description": [
            "This Agreement governs the outsourcing of capital project execution services for digital infrastructure and automation.",
            "Scope includes: (i) distributed control system (DCS) installation across {num_wells} facilities; "
            "(ii) safety instrumented systems (SIS) and emergency shutdown systems; "
            "(iii) data infrastructure including SCADA, historians, and analytics platforms; "
            "and (iv) cybersecurity systems and network infrastructure.",
            "Scope includes materials (control systems, instrumentation, network equipment, servers, software licenses, cybersecurity tools) "
            "and labor (automation engineers, control systems specialists, IT engineers, cybersecurity experts).",
            "All work shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Maintenance & Turnaround Services",
        "description": [
            "This Agreement governs the outsourcing of capital project execution services for maintenance and turnaround operations.",
            "Scope includes: (i) planned maintenance services for {num_wells} production facilities; "
            "(ii) major turnaround execution including equipment replacement and upgrades; "
            "(iii) emergency repair and restoration services; "
            "and (iv) spare parts management and inventory control.",
            "Scope includes materials (replacement equipment, spare parts, consumables, tools, instrumentation) "
            "and labor (maintenance technicians, turnaround crews, planners, supervisors, specialists).",
            "All work shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    }
]

# LABOR-focused project scopes (service-oriented, expertise-based)
LABOR_PROJECT_SCOPES = [
    {
        "type": "Engineering Consulting Services",
        "description": [
            "This Agreement governs the provision of professional engineering consulting services for capital project execution.",
            "Scope includes: (i) project management and engineering oversight services; "
            "(ii) technical consulting and design review services; "
            "(iii) quality assurance and quality control services; "
            "and (iv) commissioning and start-up support services.",
            "Services shall be provided by qualified personnel including project managers, senior engineers, engineers, "
            "and technical specialists as detailed in the Rate Card set forth in the Rate Card section.",
            "All services shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Maintenance & Operations Services",
        "description": [
            "This Agreement governs the provision of maintenance and operations services for production facilities.",
            "Scope includes: (i) planned maintenance services including preventive and predictive maintenance; "
            "(ii) operations support services including facility operations and monitoring; "
            "(iii) emergency response and repair services; "
            "and (iv) technical support and troubleshooting services.",
            "Services shall be provided by qualified personnel including maintenance technicians, operations specialists, "
            "supervisors, and technical experts as detailed in the Rate Card set forth in Section 36.",
            "All services shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Turnaround & Shutdown Services",
        "description": [
            "This Agreement governs the provision of turnaround and shutdown execution services.",
            "Scope includes: (i) turnaround planning and coordination services; "
            "(ii) shutdown execution services including equipment isolation and preparation; "
            "(iii) maintenance and repair services during turnaround; "
            "and (iv) restart and commissioning services.",
            "Services shall be provided by qualified personnel including turnaround planners, supervisors, "
            "maintenance crews, and commissioning specialists as detailed in the Rate Card set forth in Section 36.",
            "All services shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Process Engineering & Optimization Services",
        "description": [
            "This Agreement governs the provision of process engineering and optimization services.",
            "Scope includes: (i) process design and optimization services; "
            "(ii) performance analysis and improvement services; "
            "(iii) troubleshooting and problem-solving services; "
            "and (iv) technical training and knowledge transfer services.",
            "Services shall be provided by qualified personnel including process engineers, senior engineers, "
            "and technical specialists as detailed in the Rate Card set forth in Section 36.",
            "All services shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Safety & Compliance Services",
        "description": [
            "This Agreement governs the provision of safety and compliance services.",
            "Scope includes: (i) HSSE management and oversight services; "
            "(ii) compliance auditing and assessment services; "
            "(iii) safety training and competency development services; "
            "and (iv) incident investigation and root cause analysis services.",
            "Services shall be provided by qualified personnel including HSSE specialists, compliance auditors, "
            "and safety trainers as detailed in the Rate Card set forth in Section 36.",
            "All services shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Digital & Automation Services",
        "description": [
            "This Agreement governs the provision of digital infrastructure and automation services.",
            "Scope includes: (i) control systems design and implementation services; "
            "(ii) automation engineering and programming services; "
            "(iii) cybersecurity and network services; "
            "and (iv) system integration and testing services.",
            "Services shall be provided by qualified personnel including automation engineers, control systems specialists, "
            "IT engineers, and cybersecurity experts as detailed in the Rate Card set forth in Section 36.",
            "All services shall be performed in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    }
]

# MATERIAL-focused project scopes (procurement, supply, delivery)
MATERIAL_PROJECT_SCOPES = [
    {
        "type": "Equipment Supply & Delivery",
        "description": [
            "This Agreement governs the procurement and supply of capital equipment for project execution.",
            "Scope includes: (i) procurement of major equipment including compressors, pumps, and turbines; "
            "(ii) supply and delivery of process equipment including vessels, columns, and heat exchangers; "
            "(iii) delivery of electrical equipment including transformers, switchgear, and motors; "
            "and (iv) supply of instrumentation and control equipment.",
            "All materials and equipment shall be procured, supplied, and delivered in accordance with specifications "
            "set forth in Schedule 1 and milestone schedule set forth in Section 8.",
            "All materials and equipment shall be delivered in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Pipeline Materials & Components Supply",
        "description": [
            "This Agreement governs the procurement and supply of pipeline materials and components.",
            "Scope includes: (i) supply of pipeline pipe and fittings; "
            "(ii) procurement of valves, flanges, and gaskets; "
            "(iii) supply of pipeline protection materials including coatings and cathodic protection systems; "
            "and (iv) delivery of metering and instrumentation equipment.",
            "All materials and components shall be procured, supplied, and delivered in accordance with specifications "
            "set forth in Schedule 1 and milestone schedule set forth in Section 8.",
            "All materials and components shall be delivered in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Structural Steel & Fabrication Supply",
        "description": [
            "This Agreement governs the procurement and supply of structural steel and fabricated components.",
            "Scope includes: (i) supply of structural steel including beams, columns, and plates; "
            "(ii) procurement of fabricated steel structures including platforms, walkways, and supports; "
            "(iii) supply of piping spools and prefabricated assemblies; "
            "and (iv) delivery of steel components with required certifications and documentation.",
            "All materials and fabricated components shall be procured, supplied, and delivered in accordance with specifications "
            "set forth in Schedule 1 and milestone schedule set forth in Section 8.",
            "All materials and components shall be delivered in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Instrumentation & Control Equipment Supply",
        "description": [
            "This Agreement governs the procurement and supply of instrumentation and control equipment.",
            "Scope includes: (i) supply of field instrumentation including transmitters, sensors, and actuators; "
            "(ii) procurement of control systems hardware including controllers, I/O modules, and communication equipment; "
            "(iii) supply of safety instrumented systems (SIS) equipment; "
            "and (iv) delivery of instrumentation with required calibration and documentation.",
            "All equipment shall be procured, supplied, and delivered in accordance with specifications "
            "set forth in Schedule 1 and milestone schedule set forth in Section 8.",
            "All equipment shall be delivered in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Electrical Equipment & Components Supply",
        "description": [
            "This Agreement governs the procurement and supply of electrical equipment and components.",
            "Scope includes: (i) supply of power generation equipment including generators and turbines; "
            "(ii) procurement of electrical distribution equipment including transformers, switchgear, and panels; "
            "(iii) supply of motors, drives, and variable frequency drives; "
            "and (iv) delivery of electrical cables, conduits, and accessories.",
            "All equipment and components shall be procured, supplied, and delivered in accordance with specifications "
            "set forth in Schedule 1 and milestone schedule set forth in Section 8.",
            "All equipment and components shall be delivered in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    },
    {
        "type": "Spare Parts & Consumables Supply",
        "description": [
            "This Agreement governs the procurement and supply of spare parts and consumables.",
            "Scope includes: (i) supply of critical spare parts for major equipment; "
            "(ii) procurement of maintenance consumables including lubricants, filters, and seals; "
            "(iii) supply of operational consumables including chemicals and catalysts; "
            "and (iv) delivery of spare parts with required documentation and warranties.",
            "All spare parts and consumables shall be procured, supplied, and delivered in accordance with specifications "
            "set forth in Schedule 1 and milestone schedule set forth in Section 8.",
            "All materials shall be delivered in accordance with the detailed Scope of Work set forth in Schedule 1."
        ]
    }
]

# Rate card roles for LABOR contracts
RATE_CARD_ROLES = [
    "Project Manager",
    "Senior Engineer",
    "Engineer",
    "Junior Engineer",
    "Senior Technician",
    "Technician",
    "Specialist",
    "Senior Specialist",
    "Supervisor",
    "Lead Supervisor",
    "Consultant",
    "Senior Consultant"
]

# Contract templates - Comprehensive 35-section structure matching real-world contracts
CONTRACT_SECTIONS = [
    {
        "title": "1. PURPOSE & SCOPE",
        "content": None  # Will be populated dynamically from PROJECT_SCOPES
    },
    {
        "title": "2. DEFINITIONS",
        "content": [
            "For purposes of this Agreement, the following terms shall have the meanings set forth below:",
            "'Agreement' means this Project Outsourcing Agreement, including all Schedules and amendments.",
            "'Company' means the contracting party identified in the preamble.",
            "'Service Provider' means the contractor identified in the preamble.",
            "'Contract Price' means the total price payable for the Services as set forth in Section 4.",
            "'Effective Date' means {effective_date}.",
            "'Final Acceptance' means acceptance by Company of all Deliverables in accordance with Section 15.",
            "'Deliverables' means all items, documents, and services to be delivered by Service Provider under this Agreement.",
            "Additional definitions are set forth in Schedule 2."
        ]
    },
    {
        "title": "3. PARTIES",
        "content": [
            "This Agreement is between Company (the 'Company') and Service Provider (the 'Service Provider').",
            "Company Address: [Company Address], United Kingdom",
            "Service Provider Address: [Service Provider Address], United Kingdom",
            "Each party represents that it has full power and authority to enter into and perform this Agreement."
        ]
    },
    {
        "title": "4. TERM & EFFECTIVE DATE",
        "content": [
            "This Agreement shall commence on the Effective Date and continue until completion of all deliverables "
            "or termination in accordance with the terms herein.",
            "Effective Date: {effective_date}",
            "Expected Completion Date: {completion_date}",
            "The term may be extended by mutual written agreement or as provided in Change Orders."
        ]
    },
    {
        "title": "5. TRANSITION & KNOWLEDGE TRANSFER",
        "content": [
            "Service Provider shall develop and implement a comprehensive transition plan within 30 days of Effective Date.",
            "Knowledge transfer sessions shall be conducted to ensure continuity of operations.",
            "All transition activities shall be documented and provided to Company upon request.",
            "Service Provider shall maintain all existing systems and processes during transition period."
        ]
    },
    {
        "title": "6. GOVERNANCE & ROLES",
        "content": [
            "A Steering Committee shall be established as set forth in Schedule 3.",
            "Steering Committee shall meet quarterly or as required to review progress and resolve issues.",
            "RACI Matrix defining roles and responsibilities is set forth in Schedule 4.",
            "Project Manager shall be designated by each party and serve as primary point of contact.",
            "Regular status reports shall be provided as specified in Section 32."
        ]
    },
    {
        "title": "7. PRICING, FUNDING & PAYMENT",
        "content": [
            "Contract Price: {contract_value}",
            "Payment Schedule: Milestone-based payments as detailed in Section 8 and Schedule 5.",
            "Retention: {retention_percent}% until Final Acceptance; release conditions defined in Section 9.",
            "Payment Terms: Net {payment_days} days from invoice date.",
            "Indexation: UK CPI/WPI ±{indexation_rate}% annually, applied quarterly as set forth in Schedule 6.",
            "All payments shall be made in GBP unless otherwise specified.",
            "Detailed pricing breakdown is set forth in Schedule 6."
        ]
    },
    {
        "title": "8. MILESTONES & DELIVERABLES",
        "content": [
            "Milestone 1: Site Preparation Complete - Due: {milestone1_date} - Billing: £{milestone1_amount}",
            "Milestone 2: Wells Drilled and Completed - Due: {milestone2_date} - Billing: £{milestone2_amount}",
            "Milestone 3: CDU Upgrade Complete - Due: {milestone3_date} - Billing: £{milestone3_amount}",
            "Milestone 4: HDS Unit Installed - Due: {milestone4_date} - Billing: £{milestone4_amount}",
            "Milestone 5: Pipeline Complete - Due: {milestone5_date} - Billing: £{milestone5_amount}",
            "Final Acceptance: All deliverables completed and accepted - Billing: Remaining balance",
            "Detailed milestone schedule and LD triggers are set forth in Schedule 5."
        ]
    },
    {
        "title": "9. RETENTION & RELEASE",
        "content": [
            "Retention Percentage: {retention_percent}% of each milestone payment shall be retained by Company.",
            "Retention Release: Upon Final Acceptance of all deliverables, retention shall be released.",
            "Retention shall be released within 30 days of Final Acceptance.",
            "Partial release of retention may be permitted for completed and accepted portions of work."
        ]
    },
    {
        "title": "10. UK COMPLIANCE & ETHICS",
        "content": [
            "Service Provider shall comply with all applicable UK laws, regulations, and industry standards.",
            "Service Provider shall maintain high ethical standards and comply with Company's Code of Conduct.",
            "Anti-bribery and corruption policies shall be strictly adhered to.",
            "Service Provider shall promptly report any compliance concerns or violations to Company."
        ]
    },
    {
        "title": "11. DATA PROTECTION (UK GDPR)",
        "content": [
            "Service Provider shall comply with UK GDPR and Data Protection Act 2018.",
            "Personal data processing shall be limited to that necessary for performance of this Agreement.",
            "Service Provider shall implement appropriate technical and organizational measures to protect personal data.",
            "Data Processing Agreement shall be executed separately if required.",
            "Service Provider shall notify Company immediately of any data breach."
        ]
    },
    {
        "title": "12. HSSE — UK REGIME",
        "content": [
            "Service Provider shall comply with all applicable UK HSE standards and regulations including HSWA 1974, COMAH 2015, and CDM 2015.",
            "Environmental impact assessments required for all major activities.",
            "Service Provider shall maintain comprehensive HSSE management systems.",
            "Regular HSSE audits and inspections shall be conducted.",
            "Incident reporting and investigation procedures shall be established."
        ]
    },
    {
        "title": "13. STANDARDS, SPECIFICATIONS & QUALITY",
        "content": [
            "All work shall comply with standards and specifications set forth in Schedule 9.",
            "Applicable standards include API, ASME, IEC, and UK national standards.",
            "Service Provider shall maintain quality management systems certified to ISO 9001.",
            "Quality assurance and quality control procedures shall be implemented throughout.",
            "Non-conforming work shall be corrected at Service Provider's expense."
        ]
    },
    {
        "title": "14. SITE ACCESS, LOGISTICS & SECURITY",
        "content": [
            "Company shall provide reasonable site access in accordance with agreed schedule.",
            "Service Provider shall comply with all site security requirements and procedures.",
            "Logistics and material handling shall be coordinated with Company's operations.",
            "Service Provider shall be responsible for safe transport and storage of materials.",
            "Site access permits and security clearances shall be obtained as required."
        ]
    },
    {
        "title": "15. COMMISSIONING, TESTING & ACCEPTANCE",
        "content": [
            "Service Provider shall conduct commissioning and testing in accordance with agreed procedures.",
            "Performance tests shall be conducted as set forth in Schedule 11.",
            "Company shall have right to witness all testing and commissioning activities.",
            "Acceptance criteria are defined in Schedule 1 and Schedule 11.",
            "Final Acceptance shall be granted upon successful completion of all acceptance tests."
        ]
    },
    {
        "title": "16. SERVICE LEVELS, STEP-IN & REMEDIES",
        "content": [
            "Service Provider shall achieve service levels and KPIs as set forth in Schedule 11.",
            "Company reserves right to step in and perform services if Service Provider fails to meet service levels.",
            "Step-in costs shall be recoverable from Service Provider.",
            "Remedial action plans shall be developed and implemented for service level failures.",
            "Persistent failures may result in termination as provided in Section 27."
        ]
    },
    {
        "title": "17. LIQUIDATED DAMAGES & SERVICE CREDITS",
        "content": [
            "Delay LDs: £{delay_ld_per_week:,} per week of delay, capped at 10% of Contract Price.",
            "Performance LDs: £{performance_ld_per_pct:,} per percentage point shortfall in performance KPIs, capped at 5% of Contract Price.",
            "Earnbacks: Service credits reversible if KPI ≥{kpi_threshold}% sustained for 3 consecutive months.",
            "LD calculations and triggers are detailed in Schedule 5.",
            "LDs are intended as genuine pre-estimate of loss and not as penalty."
        ]
    },
    {
        "title": "18. CHANGE ORDERS",
        "content": [
            "Change Order Approval Thresholds:",
            "- Up to £{co_threshold_1:,}: Project Manager approval",
            "- £{co_threshold_1:,} to £{co_threshold_2:,}: Steering Committee approval",
            "- Above £{co_threshold_2:,}: CFO approval required",
            "Change order procedure is set forth in Schedule 8.",
            "All change orders must be in writing and signed by authorized representatives."
        ]
    },
    {
        "title": "19. IP & DATA",
        "content": [
            "Background IP remains property of respective parties.",
            "Foreground IP developed under this Agreement shall be owned by Company.",
            "Service Provider grants Company license to use Service Provider's Background IP for purposes of this Agreement.",
            "Confidential information shall be protected in accordance with separate confidentiality agreement.",
            "Data generated under this Agreement shall be provided to Company upon request."
        ]
    },
    {
        "title": "20. INSURANCE & BONDS",
        "content": [
            "Service Provider shall maintain comprehensive insurance coverage including public liability, professional indemnity, and employer's liability.",
            "Minimum coverage amounts: Public Liability £{public_liability:,}, Professional Indemnity £{professional_indemnity:,}.",
            "Performance bond of 10% of Contract Price shall be provided.",
            "Insurance certificates and bond shall be provided to Company within 30 days of Effective Date.",
            "Service Provider shall maintain insurance throughout the term of this Agreement."
        ]
    },
    {
        "title": "21. WARRANTIES",
        "content": [
            "Service Provider warrants that all work shall be performed in professional manner and in accordance with this Agreement.",
            "Materials and equipment shall be new, of good quality, and fit for intended purpose.",
            "Workmanship warranty period: {warranty_months} months from Final Acceptance.",
            "Service Provider shall remedy any defects at no cost to Company during warranty period.",
            "Warranties are in addition to any statutory warranties."
        ]
    },
    {
        "title": "22. FORCE MAJEURE",
        "content": [
            "Neither party shall be liable for failure to perform due to force majeure events.",
            "Force majeure events include acts of God, war, terrorism, natural disasters, and government actions.",
            "Affected party shall notify other party promptly and take reasonable steps to mitigate impact.",
            "If force majeure continues for more than 90 days, either party may terminate this Agreement.",
            "Payment obligations shall continue during force majeure period."
        ]
    },
    {
        "title": "23. LIMITATION OF LIABILITY",
        "content": [
            "Service Provider's total liability shall not exceed 100% of Contract Price.",
            "Neither party shall be liable for indirect, consequential, or special damages.",
            "Liability exclusions do not apply to: (i) death or personal injury, (ii) fraud, (iii) breach of confidentiality, (iv) IP infringement.",
            "Liability caps and exclusions are reasonable and reflect commercial risk allocation."
        ]
    },
    {
        "title": "24. INDEMNITIES",
        "content": [
            "Service Provider shall indemnify Company against losses arising from: (i) breach of this Agreement, (ii) negligence, (iii) IP infringement, (iv) third party claims.",
            "Company shall indemnify Service Provider against losses arising from Company's breach or negligence.",
            "Indemnities are subject to limitation of liability provisions in Section 23.",
            "Indemnifying party shall have right to control defense of claims."
        ]
    },
    {
        "title": "25. DISPUTE RESOLUTION",
        "content": [
            "Disputes shall first be escalated to Steering Committee for resolution.",
            "If unresolved within 30 days, disputes shall be referred to senior management of both parties.",
            "If still unresolved, disputes shall be resolved through arbitration in accordance with UK arbitration rules.",
            "Arbitration shall be conducted in London, England, in English language.",
            "Arbitration award shall be final and binding on both parties."
        ]
    },
    {
        "title": "26. AUDIT RIGHTS & RECORDS",
        "content": [
            "Company shall have right to audit Service Provider's records relating to this Agreement.",
            "Audits may be conducted during normal business hours with reasonable notice.",
            "Service Provider shall maintain accurate records for 7 years after completion.",
            "Audit findings shall be discussed and any overpayments shall be refunded.",
            "Service Provider shall cooperate fully with audit activities."
        ]
    },
    {
        "title": "27. SUSPENSION & TERMINATION",
        "content": [
            "Company may suspend work for convenience with 30 days written notice.",
            "Either party may terminate for material breach with 30 days written notice to cure.",
            "Company may terminate for convenience with 60 days written notice.",
            "Termination provisions and compensation are detailed in termination clause.",
            "Upon termination, Service Provider shall deliver all work in progress and return Company property."
        ]
    },
    {
        "title": "28. ASSIGNMENT & NOVATION",
        "content": [
            "Service Provider may not assign this Agreement without Company's prior written consent.",
            "Company may assign this Agreement to affiliate or successor entity.",
            "Novation may be permitted with consent of all parties.",
            "Subcontracting of material portions requires Company approval.",
            "Service Provider remains responsible for performance of subcontractors."
        ]
    },
    {
        "title": "29. PUBLICITY",
        "content": [
            "Service Provider shall not issue press releases or public statements regarding this Agreement without Company's prior written consent.",
            "Company may issue press releases and public statements as it deems appropriate.",
            "Confidentiality obligations continue to apply to all public communications.",
            "Service Provider may use Company name in marketing materials only with written consent."
        ]
    },
    {
        "title": "30. NOTICES",
        "content": [
            "All notices shall be in writing and delivered to addresses specified in Section 3.",
            "Notices may be delivered by hand, registered mail, or email with read receipt.",
            "Notices shall be deemed received: (i) if by hand, on delivery, (ii) if by mail, 3 business days after posting, (iii) if by email, on receipt confirmation.",
            "Either party may change notice address by written notice to other party."
        ]
    },
    {
        "title": "31. GOVERNING LAW",
        "content": [
            "This Agreement shall be governed by and construed in accordance with the laws of England & Wales.",
            "Courts of England & Wales shall have exclusive jurisdiction for matters not subject to arbitration.",
            "Service of process may be made at addresses specified in Section 3."
        ]
    },
    {
        "title": "32. REPORTING & CONTROLS",
        "content": [
            "Monthly progress reports required by 5th of each month.",
            "Reports shall include: progress against milestones, issues and risks, financial status, HSSE performance.",
            "Steering Committee meetings quarterly or as required.",
            "Issue escalation process defined in governance framework.",
            "Additional reporting requirements are set forth in Schedule 10."
        ]
    },
    {
        "title": "33. ACCOUNTING, COST RECOGNITION & CAPITALIZATION (UK)",
        "content": [
            "Cost recognition and capitalization shall be in accordance with UK GAAP, IFRS, and Company accounting policies.",
            "IAS 16 (Property, Plant and Equipment) applies to capitalizable costs.",
            "IAS 23 (Borrowing Costs) applies to interest capitalization.",
            "IAS 37 (Provisions) applies to asset retirement obligations (ARO).",
            "Componentization and AFIU (Assets Under Construction) treatment shall be as agreed with Company finance team.",
            "Detailed accounting positions are set forth in Schedule 12."
        ]
    },
    {
        "title": "34. PERFORMANCE OBLIGATIONS, BILLING & REVENUE RECOGNITION (IFRS 15)",
        "content": [
            "Performance obligations are identified in Schedule 1 and correspond to milestones in Schedule 5.",
            "Revenue recognition shall be in accordance with IFRS 15 (Revenue from Contracts with Customers).",
            "Billing shall occur upon achievement of milestones as set forth in Section 8.",
            "Invoices must include: Contract reference (SOW Number), WBS/Asset IDs, PO number, Milestone achieved, AFIU status, Retention amount, Tax details.",
            "Supporting documentation (timesheets, completion certificates, GRN/MRS) shall be provided with invoices.",
            "{ses_grn_clause}",
            "Detailed billing procedures are set forth in Schedule 7."
        ]
    },
    {
        "title": "35. ESG & SUSTAINABILITY",
        "content": [
            "Service Provider shall comply with Company's ESG and sustainability policies.",
            "Carbon footprint reduction targets shall be established and monitored.",
            "Sustainable materials and practices shall be prioritized where feasible.",
            "ESG reporting shall be included in monthly progress reports.",
            "Service Provider shall support Company's net-zero commitments."
        ]
    },
    {
        "title": "36. RATE CARD",
        "content": None  # Will be populated dynamically for LABOR contracts only
    }
]

CHANGE_ORDER_TEMPLATES = [
    {
        "reason": "Scope expansion - additional pipeline segment",
        "changes": [
            "Pipeline scope expanded by 10 km (from 50 km to 60 km)",
            "Additional terminal tankage capacity added",
            "Contract value increased by £50,000,000"
        ]
    },
    {
        "reason": "Timeline adjustment - milestone extensions",
        "changes": [
            "Pipeline completion milestone extended by 3 months",
            "HDS unit installation milestone extended by 2 months",
            "Payment terms adjusted to align with new timeline"
        ]
    },
    {
        "reason": "Payment terms modification",
        "changes": [
            "Payment terms extended from Net 30 days to Net 45 days",
            "Retention release terms clarified",
            "Milestone payment schedule adjusted"
        ]
    },
    {
        "reason": "Performance KPI adjustments",
        "changes": [
            "KPI thresholds adjusted for earnback eligibility",
            "Performance LD calculation method clarified",
            "Reporting frequency increased to bi-weekly"
        ]
    },
    {
        "reason": "Material specification changes",
        "changes": [
            "Valve specifications updated to meet new standards",
            "Catalyst requirements modified",
            "Equipment delivery schedule adjusted"
        ]
    }
]


# ============================================================================
# Database Setup
# ============================================================================

def drop_database_tables(db_path: Path) -> None:
    """Drop all database tables."""
    if not db_path.exists():
        return
    
    try:
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        # Drop tables in reverse order of dependencies
        cursor.execute("DROP TABLE IF EXISTS term_history")
        cursor.execute("DROP TABLE IF EXISTS change_orders")
        cursor.execute("DROP TABLE IF EXISTS contract_terms")
        cursor.execute("DROP TABLE IF EXISTS contracts")
        
        conn.commit()
        conn.close()
        print(f"✓ Dropped all database tables: {db_path}")
    
    except Exception as e:
        print(f"⚠ Failed to drop database tables: {e}")


def clear_data_folders(base_dir: Path) -> None:
    """Clear all data in covenant folder by deleting the entire folder."""
    if not base_dir.exists():
        print(f"✓ Covenant data folder does not exist: {base_dir}")
        return
    
    try:
        import shutil
        # Delete entire covenant data folder
        shutil.rmtree(base_dir)
        print(f"✓ Deleted entire covenant data folder: {base_dir}")
    except Exception as e:
        print(f"⚠ Failed to delete covenant data folder: {e}")


def create_database_schema(db_path: Path) -> None:
    """Create covenant database schema."""
    # Ensure parent directory exists
    db_path.parent.mkdir(parents=True, exist_ok=True)
    
    conn = sqlite3.connect(str(db_path))
    cursor = conn.cursor()
    
    # Contracts table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS contracts (
            contract_id TEXT PRIMARY KEY,
            sow_number TEXT UNIQUE NOT NULL,
            vendor_id TEXT,
            project_id TEXT,
            contract_file_path TEXT NOT NULL,
            contract_date TEXT,
            effective_date TEXT,
            status TEXT DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Add new columns if they don't exist (migration)
    try:
        cursor.execute("ALTER TABLE contracts ADD COLUMN contract_type TEXT")
    except sqlite3.OperationalError:
        pass  # Column already exists
    
    try:
        cursor.execute("ALTER TABLE contracts ADD COLUMN po_number TEXT")
    except sqlite3.OperationalError:
        pass  # Column already exists
    
    try:
        cursor.execute("ALTER TABLE contracts ADD COLUMN run_id TEXT")
    except sqlite3.OperationalError:
        pass  # Column already exists
    
    # Contract terms table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS contract_terms (
            term_id TEXT PRIMARY KEY,
            contract_id TEXT NOT NULL,
            clause_identifier TEXT,
            clause_number TEXT,
            section_name TEXT,
            term_category TEXT,
            term_text TEXT,
            term_value TEXT,
            effective_date TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (contract_id) REFERENCES contracts(contract_id)
        )
    """)
    
    # Change orders table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS change_orders (
            change_order_id TEXT PRIMARY KEY,
            contract_id TEXT NOT NULL,
            change_order_version TEXT NOT NULL,
            change_order_file_path TEXT NOT NULL,
            change_order_date TEXT,
            effective_date TEXT,
            status TEXT DEFAULT 'approved',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (contract_id) REFERENCES contracts(contract_id),
            UNIQUE(contract_id, change_order_version)
        )
    """)
    
    # Add run_id column to change_orders table (migration)
    try:
        cursor.execute("ALTER TABLE change_orders ADD COLUMN run_id TEXT")
    except sqlite3.OperationalError:
        pass  # Column already exists
    
    # Term history table (audit trail)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS term_history (
            history_id INTEGER PRIMARY KEY AUTOINCREMENT,
            term_id TEXT NOT NULL,
            change_order_id TEXT,
            change_order_version TEXT,
            action TEXT NOT NULL,
            clause_identifier TEXT,
            old_value TEXT,
            new_value TEXT,
            old_text TEXT,
            new_text TEXT,
            change_description TEXT,
            category TEXT,
            changed_by TEXT,
            changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (term_id) REFERENCES contract_terms(term_id),
            FOREIGN KEY (change_order_id) REFERENCES change_orders(change_order_id)
        )
    """)
    
    # Create indexes
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_contracts_sow_number ON contracts(sow_number)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_contracts_run_id ON contracts(run_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_contract_terms_contract_id ON contract_terms(contract_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_change_orders_contract_id ON change_orders(contract_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_change_orders_run_id ON change_orders(run_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_term_history_term_id ON term_history(term_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_term_history_change_order_id ON term_history(change_order_id)")
    
    conn.commit()
    conn.close()
    print(f"✓ Database schema created: {db_path}")


# ============================================================================
# Term Extraction (Database & PDF)
# ============================================================================

def get_contract_terms_from_db(
    db_path: Path,
    sow_number: str
) -> Optional[Dict[str, Any]]:
    """Get current contract terms from database."""
    if not db_path.exists():
        return None
    
    try:
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Get contract terms
        cursor.execute("""
            SELECT clause_identifier, clause_number, section_name, term_category,
                   term_text, term_value, effective_date
            FROM contract_terms
            WHERE contract_id = ?
            ORDER BY clause_number, clause_identifier
        """, (sow_number,))
        
        terms = []
        for row in cursor.fetchall():
            term_value = json.loads(row["term_value"]) if row["term_value"] else None
            terms.append({
                "clause_identifier": row["clause_identifier"],
                "clause_number": row["clause_number"],
                "section_name": row["section_name"],
                "term_category": row["term_category"],
                "term_text": row["term_text"],
                "term_value": term_value
            })
        
        # Get contract info
        cursor.execute("""
            SELECT contract_file_path, contract_date, effective_date
            FROM contracts
            WHERE sow_number = ?
        """, (sow_number,))
        
        contract_row = cursor.fetchone()
        contract_info = None
        if contract_row:
            contract_info = {
                "contract_file_path": contract_row["contract_file_path"],
                "contract_date": contract_row["contract_date"],
                "effective_date": contract_row["effective_date"]
            }
        
        conn.close()
        
        if terms:
            return {
                "source": "database",
                "contract_info": contract_info,
                "terms": terms
            }
        return None
    
    except Exception as e:
        print(f"⚠ Database query failed: {e}")
        return None


def extract_terms_from_pdf(pdf_path: Path) -> Optional[Dict[str, Any]]:
    """Extract terms from contract PDF."""
    if not PYPDF_AVAILABLE or not pdf_path.exists():
        return None
    
    try:
        with open(pdf_path, 'rb') as file:
            pdf_reader = pypdf.PdfReader(file)
            full_text = ""
            
            for page in pdf_reader.pages:
                full_text += page.extract_text() + "\n"
        
        # Extract key terms using simple pattern matching
        terms = {}
        
        # Payment terms
        payment_match = None
        if "Payment Terms:" in full_text or "Payment terms:" in full_text:
            payment_pattern = r"Payment\s+[Tt]erms?:\s*(Net\s+\d+\s+days?|Net\s+\d+)"
            match = re.search(payment_pattern, full_text)
            if match:
                payment_match = match.group(1)
        
        # Pipeline scope
        pipeline_match = None
        pipeline_pattern = r"(\d+)\s*km.*pipeline"
        match = re.search(pipeline_pattern, full_text, re.IGNORECASE)
        if match:
            pipeline_match = match.group(1)
        
        # Contract value
        value_match = None
        value_pattern = r"Contract\s+Price:\s*£?([\d,]+)"
        match = re.search(value_pattern, full_text, re.IGNORECASE)
        if match:
            value_match = match.group(1).replace(",", "")
        
        # Retention
        retention_match = None
        retention_pattern = r"Retention[:\s]+(\d+)%"
        match = re.search(retention_pattern, full_text, re.IGNORECASE)
        if match:
            retention_match = match.group(1)
        
        # Indexation
        indexation_match = None
        indexation_pattern = r"Indexation[:\s]+([^\.]+)"
        match = re.search(indexation_pattern, full_text, re.IGNORECASE)
        if match:
            indexation_match = match.group(1).strip()
        
        # Delay LD
        delay_ld_match = None
        delay_ld_pattern = r"Delay\s+LDs?[:\s]+£([\d,]+)"
        match = re.search(delay_ld_pattern, full_text, re.IGNORECASE)
        if match:
            delay_ld_match = match.group(1).replace(",", "")
        
        # Performance LD
        perf_ld_match = None
        perf_ld_pattern = r"Performance\s+LDs?[:\s]+£([\d,]+)"
        match = re.search(perf_ld_pattern, full_text, re.IGNORECASE)
        if match:
            perf_ld_match = match.group(1).replace(",", "")
        
        # KPI threshold
        kpi_match = None
        kpi_pattern = r"KPI\s+≥(\d+)%"
        match = re.search(kpi_pattern, full_text, re.IGNORECASE)
        if match:
            kpi_match = match.group(1)
        
        # Warranty period
        warranty_match = None
        warranty_pattern = r"warranty\s+period[:\s]+(\d+)\s*months?"
        match = re.search(warranty_pattern, full_text, re.IGNORECASE)
        if match:
            warranty_match = match.group(1)
        
        # Number of wells
        wells_match = None
        wells_pattern = r"(\d+)\s*(?:horizontal\s+)?development\s+wells?"
        match = re.search(wells_pattern, full_text, re.IGNORECASE)
        if match:
            wells_match = match.group(1)
        
        terms = {
            "payment_terms": payment_match,
            "pipeline_km": pipeline_match,
            "contract_value": value_match,
            "retention_percent": retention_match,
            "indexation": indexation_match,
            "delay_ld": delay_ld_match,
            "performance_ld": perf_ld_match,
            "kpi_threshold": kpi_match,
            "warranty_months": warranty_match,
            "num_wells": wells_match
        }
        
        return {
            "source": "pdf",
            "terms": terms,
            "full_text": full_text[:1000]  # First 1000 chars for reference
        }
    
    except Exception as e:
        print(f"⚠ PDF extraction failed: {e}")
        return None


def get_contract_terms(
    base_dir: Path,
    sow_number: str
) -> Optional[Dict[str, Any]]:
    """Get contract terms - try database first, then PDF."""
    # Try database first
    db_path = base_dir / "covenant.db"
    db_result = get_contract_terms_from_db(db_path, sow_number)
    if db_result:
        print(f"  ✓ Found terms in database for {sow_number}")
        return db_result
    
    # Try PDF extraction
    # Look for contract PDF in pending or processed folders
    for folder in ["pending", "processed", "signed_contracts"]:
        folder_path = base_dir / folder
        if folder_path.exists():
            pdf_path = folder_path / f"{sow_number}_signed.pdf"
            if pdf_path.exists():
                pdf_result = extract_terms_from_pdf(pdf_path)
                if pdf_result:
                    print(f"  ✓ Extracted terms from PDF for {sow_number}")
                    return pdf_result
    
    print(f"  ⚠ Could not find terms for {sow_number} (database or PDF)")
    return None


def get_modified_terms_from_history(
    db_path: Path,
    sow_number: str
) -> Dict[str, List[str]]:
    """Get list of terms that were already modified by previous change orders."""
    modified_terms = {}
    
    if not db_path.exists():
        return modified_terms
    
    try:
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Get all change orders for this contract
        cursor.execute("""
            SELECT change_order_version, change_order_id
            FROM change_orders
            WHERE contract_id = ?
            ORDER BY change_order_version
        """, (sow_number,))
        
        change_orders = cursor.fetchall()
        
        # For each change order, get modified terms
        for co_row in change_orders:
            co_version = co_row["change_order_version"]
            co_id = co_row["change_order_id"]
            
            cursor.execute("""
                SELECT DISTINCT clause_identifier, term_category
                FROM term_history
                WHERE change_order_id = ? AND action = 'modified'
            """, (co_id,))
            
            for hist_row in cursor.fetchall():
                clause_id = hist_row["clause_identifier"]
                category = hist_row["term_category"]
                if clause_id not in modified_terms:
                    modified_terms[clause_id] = []
                modified_terms[clause_id].append(co_version)
        
        conn.close()
        return modified_terms
    
    except Exception as e:
        print(f"⚠ Failed to get modification history: {e}")
        return {}


def generate_intelligent_change_order(
    sow_number: str,
    base_dir: Path,
    version: str,
    current_terms: Optional[Dict[str, Any]],
    modified_terms: Dict[str, List[str]],
    seed: Optional[int] = None
) -> List[str]:
    """Generate change order modifications based on actual current terms."""
    if seed:
        random.seed(seed)
    
    changes = []
    
    if not current_terms:
        # Fallback to template if no terms available
        template = random.choice(CHANGE_ORDER_TEMPLATES)
        return template['changes']
    
    # Determine which terms to modify (avoid recently modified ones)
    available_modifications = []
    
    if current_terms.get("source") == "database":
        terms = current_terms.get("terms", [])
        
        # Find modifiable terms
        for term in terms:
            clause_id = term.get("clause_identifier", "")
            category = term.get("term_category", "")
            text = term.get("term_text", "")
            
            # Skip if recently modified (in last 2 change orders)
            if clause_id in modified_terms:
                recent_mods = modified_terms[clause_id][-2:]  # Last 2 modifications
                if len(recent_mods) >= 2:
                    continue  # Skip if modified in last 2 change orders
            
            # Payment terms modification
            if "payment" in category.lower() and "Net" in text:
                # Extract current value
                match = re.search(r"Net\s+(\d+)", text)
                if match:
                    current_days = int(match.group(1))
                    new_days = current_days + random.choice([15, 30])
                    available_modifications.append({
                        "type": "payment_terms",
                        "current": f"Net {current_days} days",
                        "new": f"Net {new_days} days",
                        "description": f"Payment terms extended from Net {current_days} days to Net {new_days} days"
                    })
            
            # Scope modifications - handle different project types
            if "scope" in category.lower():
                # Pipeline scope (km)
                match = re.search(r"(\d+)\s*km", text)
                if match:
                    current_km = int(match.group(1))
                    new_km = current_km + random.choice([5, 10, 15])
                    available_modifications.append({
                        "type": "scope_pipeline",
                        "current": f"{current_km} km",
                        "new": f"{new_km} km",
                        "description": f"Pipeline/infrastructure scope expanded by {new_km - current_km} km (from {current_km} km to {new_km} km)"
                    })
                
                # Well count modifications
                match = re.search(r"(\d+)\s*(?:horizontal\s+)?development\s+wells?", text, re.IGNORECASE)
                if match:
                    current_wells = int(match.group(1))
                    new_wells = current_wells + random.choice([-2, 2, 5])
                    if new_wells > 0:
                        available_modifications.append({
                            "type": "scope_wells",
                            "current": f"{current_wells} wells",
                            "new": f"{new_wells} wells",
                            "description": f"Number of development wells adjusted from {current_wells} to {new_wells}"
                        })
                
                # Storage capacity (for terminal projects)
                match = re.search(r"(\d+)\s*million\s*barrels?", text, re.IGNORECASE)
                if match:
                    current_capacity = int(match.group(1))
                    new_capacity = current_capacity + random.choice([5, 10, 15])
                    available_modifications.append({
                        "type": "scope_capacity",
                        "current": f"{current_capacity} million barrels",
                        "new": f"{new_capacity} million barrels",
                        "description": f"Storage capacity increased from {current_capacity} to {new_capacity} million barrels"
                    })
                
                # Turbine/unit count (for power generation)
                match = re.search(r"(\d+)\s*gas\s*turbines?", text, re.IGNORECASE)
                if match:
                    current_units = int(match.group(1))
                    new_units = current_units + random.choice([-1, 1])
                    if new_units > 0:
                        available_modifications.append({
                            "type": "scope_units",
                            "current": f"{current_units} turbines",
                            "new": f"{new_units} turbines",
                            "description": f"Number of gas turbines adjusted from {current_units} to {new_units}"
                        })
                
                # Facility count (for maintenance/digital projects)
                match = re.search(r"(\d+)\s*facilities?", text, re.IGNORECASE)
                if match:
                    current_facilities = int(match.group(1))
                    new_facilities = current_facilities + random.choice([-1, 1, 2])
                    if new_facilities > 0:
                        available_modifications.append({
                            "type": "scope_facilities",
                            "current": f"{current_facilities} facilities",
                            "new": f"{new_facilities} facilities",
                            "description": f"Number of facilities in scope adjusted from {current_facilities} to {new_facilities}"
                        })
            
            # Retention percentage modification
            if "retention" in category.lower() or "retention" in text.lower():
                match = re.search(r"(\d+)%", text)
                if match:
                    current_retention = int(match.group(1))
                    new_retention = current_retention + random.choice([-2, 0, 2, 5])
                    if new_retention > 0 and new_retention <= 20:
                        available_modifications.append({
                            "type": "retention",
                            "current": f"{current_retention}%",
                            "new": f"{new_retention}%",
                            "description": f"Retention percentage changed from {current_retention}% to {new_retention}%"
                        })
            
            # Indexation rate modification
            if "indexation" in category.lower() or "indexation" in text.lower():
                match = re.search(r"±(\d+\.?\d*)%", text)
                if match:
                    current_rate = float(match.group(1))
                    new_rate = current_rate + random.choice([-0.5, 0.5, 1.0])
                    if new_rate > 0:
                        available_modifications.append({
                            "type": "indexation",
                            "current": f"±{current_rate}%",
                            "new": f"±{new_rate}%",
                            "description": f"Indexation rate adjusted from ±{current_rate}% to ±{new_rate}% annually"
                        })
            
            # Delay LD modification
            if "delay" in category.lower() and "ld" in text.lower():
                match = re.search(r"£([\d,]+)", text)
                if match:
                    current_ld = int(match.group(1).replace(",", ""))
                    new_ld = current_ld + random.choice([-5000, 5000, 10000])
                    if new_ld > 0:
                        available_modifications.append({
                            "type": "delay_ld",
                            "current": f"£{current_ld:,}",
                            "new": f"£{new_ld:,}",
                            "description": f"Delay LD rate adjusted from £{current_ld:,} to £{new_ld:,} per week"
                        })
            
            # Performance LD modification
            if "performance" in category.lower() and "ld" in text.lower():
                match = re.search(r"£([\d,]+)", text)
                if match:
                    current_ld = int(match.group(1).replace(",", ""))
                    new_ld = current_ld + random.choice([-2000, 2000, 5000])
                    if new_ld > 0:
                        available_modifications.append({
                            "type": "performance_ld",
                            "current": f"£{current_ld:,}",
                            "new": f"£{new_ld:,}",
                            "description": f"Performance LD rate adjusted from £{current_ld:,} to £{new_ld:,} per percentage point"
                        })
            
            # KPI threshold modification
            if "kpi" in category.lower() or "earnback" in text.lower():
                match = re.search(r"≥(\d+)%", text)
                if match:
                    current_kpi = int(match.group(1))
                    new_kpi = current_kpi + random.choice([-5, 5, 10])
                    if new_kpi > 0:
                        available_modifications.append({
                            "type": "kpi_threshold",
                            "current": f"{current_kpi}%",
                            "new": f"{new_kpi}%",
                            "description": f"KPI threshold for earnbacks adjusted from ≥{current_kpi}% to ≥{new_kpi}%"
                        })
            
            # Change order threshold modification
            if "change order" in category.lower() or "approval threshold" in text.lower():
                match = re.search(r"£([\d,]+)", text)
                if match:
                    current_threshold = int(match.group(1).replace(",", ""))
                    new_threshold = current_threshold + random.choice([-500000, 500000, 1000000])
                    if new_threshold > 0:
                        available_modifications.append({
                            "type": "co_threshold",
                            "current": f"£{current_threshold:,}",
                            "new": f"£{new_threshold:,}",
                            "description": f"Change order approval threshold adjusted from £{current_threshold:,} to £{new_threshold:,}"
                        })
            
            # Warranty period modification
            if "warranty" in category.lower() or "warranty" in text.lower():
                match = re.search(r"(\d+)\s*months?", text)
                if match:
                    current_months = int(match.group(1))
                    new_months = current_months + random.choice([-6, 6, 12])
                    if new_months > 0:
                        available_modifications.append({
                            "type": "warranty",
                            "current": f"{current_months} months",
                            "new": f"{new_months} months",
                            "description": f"Warranty period extended from {current_months} months to {new_months} months"
                        })
            
            # Number of wells modification
            if "wells" in category.lower() or "wells" in text.lower():
                match = re.search(r"(\d+)\s*(?:horizontal\s+)?development\s+wells?", text, re.IGNORECASE)
                if match:
                    current_wells = int(match.group(1))
                    new_wells = current_wells + random.choice([-2, 2, 5])
                    if new_wells > 0:
                        available_modifications.append({
                            "type": "wells",
                            "current": f"{current_wells} wells",
                            "new": f"{new_wells} wells",
                            "description": f"Number of development wells adjusted from {current_wells} to {new_wells}"
                        })
    
    elif current_terms.get("source") == "pdf":
        pdf_terms = current_terms.get("terms", {})
        
        # Payment terms
        if pdf_terms.get("payment_terms"):
            current = pdf_terms["payment_terms"]
            match = re.search(r"(\d+)", current)
            if match:
                current_days = int(match.group(1))
                new_days = current_days + random.choice([15, 30])
                available_modifications.append({
                    "type": "payment_terms",
                    "current": current,
                    "new": f"Net {new_days} days",
                    "description": f"Payment terms extended from {current} to Net {new_days} days"
                })
        
        # Pipeline scope
        if pdf_terms.get("pipeline_km"):
            current_km = int(pdf_terms["pipeline_km"])
            new_km = current_km + random.choice([5, 10, 15])
            available_modifications.append({
                "type": "scope",
                "current": f"{current_km} km",
                "new": f"{new_km} km",
                "description": f"Pipeline scope expanded by {new_km - current_km} km (from {current_km} km to {new_km} km)"
            })
        
        # Retention
        if pdf_terms.get("retention_percent"):
            current_retention = int(pdf_terms["retention_percent"])
            new_retention = current_retention + random.choice([-2, 0, 2, 5])
            if new_retention > 0 and new_retention <= 20:
                available_modifications.append({
                    "type": "retention",
                    "current": f"{current_retention}%",
                    "new": f"{new_retention}%",
                    "description": f"Retention percentage changed from {current_retention}% to {new_retention}%"
                })
        
        # Indexation
        if pdf_terms.get("indexation"):
            indexation_text = pdf_terms["indexation"]
            match = re.search(r"±(\d+\.?\d*)%", indexation_text)
            if match:
                current_rate = float(match.group(1))
                new_rate = current_rate + random.choice([-0.5, 0.5, 1.0])
                if new_rate > 0:
                    available_modifications.append({
                        "type": "indexation",
                        "current": f"±{current_rate}%",
                        "new": f"±{new_rate}%",
                        "description": f"Indexation rate adjusted from ±{current_rate}% to ±{new_rate}% annually"
                    })
        
        # Delay LD
        if pdf_terms.get("delay_ld"):
            current_ld = int(pdf_terms["delay_ld"])
            new_ld = current_ld + random.choice([-5000, 5000, 10000])
            if new_ld > 0:
                available_modifications.append({
                    "type": "delay_ld",
                    "current": f"£{current_ld:,}",
                    "new": f"£{new_ld:,}",
                    "description": f"Delay LD rate adjusted from £{current_ld:,} to £{new_ld:,} per week"
                })
        
        # Performance LD
        if pdf_terms.get("performance_ld"):
            current_ld = int(pdf_terms["performance_ld"])
            new_ld = current_ld + random.choice([-2000, 2000, 5000])
            if new_ld > 0:
                available_modifications.append({
                    "type": "performance_ld",
                    "current": f"£{current_ld:,}",
                    "new": f"£{new_ld:,}",
                    "description": f"Performance LD rate adjusted from £{current_ld:,} to £{new_ld:,} per percentage point"
                })
        
        # KPI threshold
        if pdf_terms.get("kpi_threshold"):
            current_kpi = int(pdf_terms["kpi_threshold"])
            new_kpi = current_kpi + random.choice([-5, 5, 10])
            if new_kpi > 0:
                available_modifications.append({
                    "type": "kpi_threshold",
                    "current": f"{current_kpi}%",
                    "new": f"{new_kpi}%",
                    "description": f"KPI threshold for earnbacks adjusted from ≥{current_kpi}% to ≥{new_kpi}%"
                })
        
        # Warranty period
        if pdf_terms.get("warranty_months"):
            current_months = int(pdf_terms["warranty_months"])
            new_months = current_months + random.choice([-6, 6, 12])
            if new_months > 0:
                available_modifications.append({
                    "type": "warranty",
                    "current": f"{current_months} months",
                    "new": f"{new_months} months",
                    "description": f"Warranty period extended from {current_months} months to {new_months} months"
                })
        
        # Number of wells
        if pdf_terms.get("num_wells"):
            current_wells = int(pdf_terms["num_wells"])
            new_wells = current_wells + random.choice([-2, 2, 5])
            if new_wells > 0:
                available_modifications.append({
                    "type": "wells",
                    "current": f"{current_wells} wells",
                    "new": f"{new_wells} wells",
                    "description": f"Number of development wells adjusted from {current_wells} to {new_wells}"
                })
    
    # Select 1-3 modifications
    if available_modifications:
        num_changes = min(random.randint(1, 3), len(available_modifications))
        selected = random.sample(available_modifications, num_changes)
        changes = [mod["description"] for mod in selected]
    else:
        # Fallback to template
        template = random.choice(CHANGE_ORDER_TEMPLATES)
        changes = template['changes']
    
    return changes


# ============================================================================
# Contract Parameters Generation
# ============================================================================

def generate_contract_parameters(
    contract_value: int,
    effective_date: datetime,
    seed: Optional[int] = None
) -> Dict[str, Any]:
    """Generate randomized contract parameters for sections."""
    if seed:
        random.seed(seed)
    
    # Randomize key contract terms
    retention_percent = random.choice([10, 12, 15])
    payment_days = random.choice([30, 45, 60])
    indexation_rate = random.choice([2.0, 2.5, 3.0])
    delay_ld_per_week = random.choice([40000, 45000, 50000])
    performance_ld_per_pct = random.choice([18000, 20000, 25000])
    kpi_threshold = random.choice([105, 110, 115])
    
    # Change order thresholds
    co_threshold_1 = random.choice([1500000, 2000000, 2500000])
    co_threshold_2 = random.choice([4000000, 5000000, 6000000])
    
    # Insurance amounts
    public_liability = random.choice([8000000, 10000000, 12000000])
    professional_indemnity = random.choice([4000000, 5000000, 6000000])
    
    # Warranty period (months)
    warranty_months = random.choice([12, 18, 24])
    
    # Pipeline length (km) - will be used in scope
    pipeline_km = random.choice([45, 50, 55, 60])
    
    # Number of wells
    num_wells = random.choice([10, 12, 15])
    
    return {
        "retention_percent": retention_percent,
        "payment_days": payment_days,
        "indexation_rate": indexation_rate,
        "delay_ld_per_week": delay_ld_per_week,
        "performance_ld_per_pct": performance_ld_per_pct,
        "kpi_threshold": kpi_threshold,
        "co_threshold_1": co_threshold_1,
        "co_threshold_2": co_threshold_2,
        "public_liability": public_liability,
        "professional_indemnity": professional_indemnity,
        "warranty_months": warranty_months,
        "pipeline_km": pipeline_km,
        "num_wells": num_wells,
        "contract_value": contract_value,
        "effective_date": effective_date
    }


# ============================================================================
# Rate Card & Milestone Generation
# ============================================================================

def generate_rate_card(contract_value: int, seed: Optional[int] = None) -> List[Dict[str, Any]]:
    """Generate rate card with roles, hourly rates, and allowed hours.
    
    Total of all rate card items should approximately match contract_value.
    """
    if seed:
        random.seed(seed)
    
    # Select 4-8 roles from available roles
    num_roles = random.randint(4, 8)
    selected_roles = random.sample(RATE_CARD_ROLES, num_roles)
    
    rate_card = []
    total_allocated = 0
    
    # Distribute contract value across roles
    role_percentages = []
    for i in range(num_roles):
        if i == num_roles - 1:
            # Last role gets remaining percentage
            role_percentages.append(1.0 - sum(role_percentages))
        else:
            # Distribute 8-20% per role
            pct = random.uniform(0.08, 0.20)
            role_percentages.append(pct)
    
    # Normalize to ensure they sum to 1.0
    total_pct = sum(role_percentages)
    role_percentages = [p / total_pct for p in role_percentages]
    
    for i, role in enumerate(selected_roles):
        # Generate realistic hourly rates based on role level
        if "Senior" in role or "Lead" in role or "Manager" in role:
            hourly_rate = random.randint(120, 200)
            # Managers/supervisors get fewer hours (100-500)
            base_hours_range = (100, 500)
        elif "Engineer" in role or "Specialist" in role or "Consultant" in role:
            hourly_rate = random.randint(80, 150)
            # Engineers/Consultants get more hours (500-2000)
            base_hours_range = (500, 2000)
        else:
            hourly_rate = random.randint(50, 100)
            # Technicians get moderate hours (200-800)
            base_hours_range = (200, 800)
        
        # Calculate target amount for this role
        target_amount = int(contract_value * role_percentages[i])
        
        # Calculate allowed hours - use role-appropriate range, but ensure it matches target amount
        target_hours = target_amount // hourly_rate
        # Clamp to role-appropriate range, but allow flexibility for amount matching
        min_hours = base_hours_range[0]
        max_hours = base_hours_range[1]
        
        # If target hours is outside range, use target but ensure minimum
        if target_hours < min_hours:
            allowed_hours = min_hours
        elif target_hours > max_hours:
            # For engineers/consultants, allow more hours if needed to match contract value
            if "Engineer" in role or "Consultant" in role or "Specialist" in role:
                allowed_hours = target_hours  # Allow more hours for engineers
            else:
                allowed_hours = max_hours
        else:
            allowed_hours = target_hours
        
        # Recalculate actual amount
        actual_amount = hourly_rate * allowed_hours
        total_allocated += actual_amount
        
        rate_card.append({
            "role": role,
            "hourly_rate": hourly_rate,
            "allowed_hours": allowed_hours,
            "total_amount": actual_amount
        })
    
    # Adjust to ensure total exactly matches contract value
    # Prefer adjusting the role with most hours (usually an Engineer/Consultant)
    if rate_card:
        final_total = sum(r["total_amount"] for r in rate_card)
        difference = contract_value - final_total
        
        if abs(difference) > 0:
            # Find the role with most hours (likely an Engineer/Consultant) to adjust
            max_hours_role_idx = max(range(len(rate_card)), key=lambda i: rate_card[i]["allowed_hours"])
            role_to_adjust = rate_card[max_hours_role_idx]
            
            # Adjust hours to account for difference
            hours_adjustment = difference // role_to_adjust["hourly_rate"]
            new_hours = role_to_adjust["allowed_hours"] + hours_adjustment
            
            # Ensure minimum hours based on role type
            if "Engineer" in role_to_adjust["role"] or "Consultant" in role_to_adjust["role"] or "Specialist" in role_to_adjust["role"]:
                new_hours = max(500, new_hours)  # Engineers minimum 500 hours
            elif "Manager" in role_to_adjust["role"] or "Lead" in role_to_adjust["role"] or "Supervisor" in role_to_adjust["role"]:
                new_hours = max(100, new_hours)  # Managers minimum 100 hours
            else:
                new_hours = max(200, new_hours)  # Others minimum 200 hours
            
            new_total = role_to_adjust["hourly_rate"] * new_hours
            remaining_diff = contract_value - (final_total - role_to_adjust["total_amount"] + new_total)
            
            # If still not exact, make small adjustment to total
            if abs(remaining_diff) > 0:
                new_total += remaining_diff
                # Recalculate hours
                new_hours = new_total // role_to_adjust["hourly_rate"]
                if new_hours < 100:
                    new_hours = 100
                    new_total = role_to_adjust["hourly_rate"] * new_hours
            
            rate_card[max_hours_role_idx]["allowed_hours"] = new_hours
            rate_card[max_hours_role_idx]["total_amount"] = new_total
    
    # Final verification - ensure total matches exactly
    final_total = sum(r["total_amount"] for r in rate_card)
    if final_total != contract_value and rate_card:
        # Make final small adjustment to the role with most hours
        diff = contract_value - final_total
        max_hours_role_idx = max(range(len(rate_card)), key=lambda i: rate_card[i]["allowed_hours"])
        rate_card[max_hours_role_idx]["total_amount"] += diff
        # Recalculate hours
        adjusted_role = rate_card[max_hours_role_idx]
        adjusted_role["allowed_hours"] = adjusted_role["total_amount"] // adjusted_role["hourly_rate"]
        if adjusted_role["allowed_hours"] < 100:
            adjusted_role["allowed_hours"] = 100
            adjusted_role["total_amount"] = adjusted_role["hourly_rate"] * adjusted_role["allowed_hours"]
    
    return rate_card


def generate_milestones(
    contract_value: int,
    effective_date: datetime,
    completion_date: datetime,
    seed: Optional[int] = None
) -> List[Dict[str, Any]]:
    """Generate milestones with names, dates, and amounts for MATERIAL contracts.
    
    Milestones are distributed evenly across the contract period from effective_date to completion_date.
    """
    if seed:
        random.seed(seed)
    
    milestone_names = [
        "Site Preparation Complete",
        "Equipment Procurement Complete",
        "Materials Delivery Complete",
        "Equipment Installation Complete",
        "Commissioning Complete",
        "Final Acceptance"
    ]
    
    # Generate 4-6 milestones
    num_milestones = random.randint(4, 6)
    selected_milestones = random.sample(milestone_names[:num_milestones], num_milestones)
    
    # Calculate total days in contract period
    total_days = (completion_date - effective_date).days
    if total_days <= 0:
        total_days = 365  # Default to 1 year if invalid
    
    milestones = []
    total_allocated = 0
    
    # Distribute amounts across milestones (ensure they sum to contract_value)
    milestone_percentages = []
    for i in range(num_milestones):
        if i == num_milestones - 1:
            # Last milestone gets remaining percentage
            milestone_percentages.append(1.0 - sum(milestone_percentages))
        else:
            # Distribute 15-25% per milestone
            pct = random.uniform(0.15, 0.25)
            milestone_percentages.append(pct)
    
    # Normalize to ensure they sum to 1.0
    total_pct = sum(milestone_percentages)
    milestone_percentages = [p / total_pct for p in milestone_percentages]
    
    # Distribute dates evenly across contract period
    date_increments = total_days / (num_milestones + 1)  # +1 to space them out
    
    for i, name in enumerate(selected_milestones):
        # Calculate amount
        amount = int(contract_value * milestone_percentages[i])
        total_allocated += amount
        
        # Adjust last milestone to ensure exact match
        if i == num_milestones - 1:
            amount = contract_value - (total_allocated - amount)
        
        # Calculate date (distribute evenly across contract period)
        days_from_start = int((i + 1) * date_increments)
        milestone_date = effective_date + timedelta(days=days_from_start)
        
        # Ensure milestone date doesn't exceed completion date
        if milestone_date > completion_date:
            milestone_date = completion_date - timedelta(days=1)
        
        milestones.append({
            "name": name,
            "date": milestone_date,
            "amount": amount
        })
    
    return milestones


# ============================================================================
# PDF Generation
# ============================================================================

def generate_signed_contract_pdf(
    sow_number: str,
    base_dir: Path,
    contract_value: int = 50000000,  # Default 50M (within 10M-100M range)
    contract_type: str = "LABOR",
    seed: Optional[int] = None
) -> tuple[Path, Dict[str, Any]]:
    """Generate detailed signed contract PDF (multi-page, comprehensive).
    
    Returns:
        Tuple of (filepath, metadata) where metadata contains rate_card (LABOR) or milestones (MATERIAL)
    """
    if not REPORTLAB_AVAILABLE:
        raise RuntimeError(
            "reportlab is required for PDF generation. "
            "Install with: uv sync --group scripts (or: pip install reportlab)"
        )
    
    if seed:
        random.seed(seed)
    
    # Select appropriate project scope based on contract type
    if contract_type == "LABOR":
        selected_scope = random.choice(LABOR_PROJECT_SCOPES)
        ses_grn_clause = "Service Entry Sheet (SES) submission is mandatory with all invoices. Invoices submitted without SES will be rejected."
        rate_card_data = None  # Will be generated after contract_value is determined
        milestones_data = None
    else:  # MATERIAL
        selected_scope = random.choice(MATERIAL_PROJECT_SCOPES)
        ses_grn_clause = "Goods Receipt Note (GRN) is mandatory to be included along with all invoices. Invoices submitted without GRN will be rejected."
        rate_card_data = None
        milestones_data = None  # Will be generated after effective_date and completion_date are determined
    
    signed_dir = base_dir / "pending"
    signed_dir.mkdir(parents=True, exist_ok=True)
    
    filepath = signed_dir / f"{sow_number}_signed.pdf"
    
    # Create custom page template for header, page numbers and footer
    def add_page_header_footer(canvas_obj, doc):
        """Add header, page numbers and confidential footer to each page."""
        page_num = canvas_obj.getPageNumber()
        width, height = letter
        
        canvas_obj.saveState()
        
        # ========================================================================
        # HEADER
        # ========================================================================
        canvas_obj.setFont("Helvetica-Bold", 12)
        canvas_obj.setFillColor(colors.HexColor('#003366'))
        
        # Company name (left side)
        company_text = "BP p.l.c."
        canvas_obj.drawString(72, height - 50, company_text)
        
        # Document title (right side)
        canvas_obj.setFont("Helvetica", 10)
        canvas_obj.setFillColor(colors.HexColor('#666666'))
        doc_title = "PROJECT OUTSOURCING AGREEMENT"
        title_width = canvas_obj.stringWidth(doc_title, "Helvetica", 10)
        canvas_obj.drawString(width - 72 - title_width, height - 50, doc_title)
        
        # SOW number (right side, below title)
        canvas_obj.setFont("Helvetica", 9)
        sow_text = f"SOW: {sow_number}"
        sow_width = canvas_obj.stringWidth(sow_text, "Helvetica", 9)
        canvas_obj.drawString(width - 72 - sow_width, height - 65, sow_text)
        
        # Header line separator
        canvas_obj.setStrokeColor(colors.HexColor('#CCCCCC'))
        canvas_obj.setLineWidth(0.5)
        canvas_obj.line(72, height - 75, width - 72, height - 75)
        
        # ========================================================================
        # FOOTER
        # ========================================================================
        canvas_obj.setFont("Helvetica", 9)
        canvas_obj.setFillColor(colors.HexColor('#666666'))
        
        # Confidential text (centered, bottom)
        confidential_text = "CONFIDENTIAL - This document contains proprietary and confidential information"
        text_width = canvas_obj.stringWidth(confidential_text, "Helvetica", 9)
        canvas_obj.drawString((width - text_width) / 2, 30, confidential_text)
        
        # Page number (bottom right)
        page_text = f"Page {page_num}"
        page_width = canvas_obj.stringWidth(page_text, "Helvetica", 9)
        canvas_obj.drawString(width - page_width - 50, 30, page_text)
        
        canvas_obj.restoreState()
    
    doc = SimpleDocTemplate(
        str(filepath),
        pagesize=letter,
        rightMargin=72,
        leftMargin=72,
        topMargin=100,  # Increased to accommodate header
        bottomMargin=72,
        onFirstPage=add_page_header_footer,
        onLaterPages=add_page_header_footer
    )
    story = []
    styles = getSampleStyleSheet()
    
    # Custom styles
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Title'],
        fontSize=20,
        textColor=colors.HexColor('#003366'),
        spaceAfter=30,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=14,
        textColor=colors.HexColor('#003366'),
        spaceAfter=12,
        spaceBefore=12,
        fontName='Helvetica-Bold'
    )
    
    subheading_style = ParagraphStyle(
        'CustomSubHeading',
        parent=styles['Heading3'],
        fontSize=12,
        textColor=colors.HexColor('#0066CC'),
        spaceAfter=8,
        spaceBefore=8,
        fontName='Helvetica-Bold'
    )
    
    toc_style = ParagraphStyle(
        'TOC',
        parent=styles['Normal'],
        fontSize=11,
        leftIndent=0,
        rightIndent=0,
        spaceAfter=6,
        fontName='Helvetica'
    )
    
    toc_title_style = ParagraphStyle(
        'TOCTitle',
        parent=styles['Heading1'],
        fontSize=16,
        textColor=colors.HexColor('#003366'),
        spaceAfter=20,
        spaceBefore=20,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    )
    
    # Generate dates and parameters
    effective_date = datetime.now() - timedelta(days=random.randint(30, 180))
    completion_date = effective_date + timedelta(days=random.randint(365, 730))
    
    # Generate rate card for LABOR contracts (after contract_value is determined)
    if contract_type == "LABOR" and rate_card_data is None:
        rate_card_data = generate_rate_card(contract_value, seed)
    
    # Generate milestones for MATERIAL contracts (after completion_date is determined)
    if contract_type == "MATERIAL" and milestones_data is None:
        milestones_data = generate_milestones(contract_value, effective_date, completion_date, seed)
    
    # Generate contract parameters
    params = generate_contract_parameters(contract_value, effective_date, seed)
    
    # Service provider
    service_provider = random.choice(SERVICE_PROVIDERS)
    
    # ============================================================================
    # TITLE PAGE
    # ============================================================================
    story.append(Spacer(1, 2.0 * inch))  # Reduced from 2.5 to 2.0 to move title up
    story.append(Paragraph("PROJECT OUTSOURCING AGREEMENT", title_style))
    story.append(Spacer(1, 0.6 * inch))  # Reduced from 0.8 to 0.6
    
    # Parties section
    parties_style = ParagraphStyle(
        'Parties',
        parent=styles['Normal'],
        fontSize=12,
        alignment=TA_CENTER,
        spaceAfter=15,
        fontName='Helvetica'
    )
    
    story.append(Paragraph("BETWEEN", parties_style))
    story.append(Spacer(1, 0.2 * inch))
    
    company_style = ParagraphStyle(
        'Company',
        parent=styles['Normal'],
        fontSize=14,
        alignment=TA_CENTER,
        spaceAfter=10,
        fontName='Helvetica-Bold'
    )
    
    story.append(Paragraph("BP p.l.c.", company_style))
    
    # Center-aligned address
    address_style = ParagraphStyle(
        'Address',
        parent=styles['Normal'],
        fontSize=11,
        alignment=TA_CENTER,
        spaceAfter=5,
        fontName='Helvetica'
    )
    story.append(Paragraph("1 St James's Square, London SW1Y 4PD", address_style))
    story.append(Paragraph("United Kingdom", address_style))
    story.append(Spacer(1, 0.3 * inch))
    
    story.append(Paragraph("(the 'Company')", parties_style))
    story.append(Spacer(1, 0.3 * inch))  # Reduced from 0.4 to 0.3
    
    story.append(Paragraph("AND", parties_style))
    story.append(Spacer(1, 0.15 * inch))  # Reduced from 0.2 to 0.15
    
    story.append(Paragraph(service_provider, company_style))
    story.append(Paragraph("(the 'Service Provider')", parties_style))
    story.append(Spacer(1, 0.4 * inch))  # Reduced from 0.5 to 0.4
    
    # Contract details (on page 1)
    details_style = ParagraphStyle(
        'Details',
        parent=styles['Normal'],
        fontSize=11,
        alignment=TA_CENTER,
        spaceAfter=8,
        fontName='Helvetica'
    )
    
    story.append(Paragraph(f"Statement of Work: {sow_number}", details_style))
    story.append(Paragraph(f"Effective Date: {effective_date.strftime('%d %B %Y')}", details_style))
    story.append(Paragraph(f"Governing Law: England & Wales", details_style))
    story.append(PageBreak())
    
    # ============================================================================
    # TABLE OF CONTENTS
    # ============================================================================
    story.append(Paragraph("TABLE OF CONTENTS", toc_title_style))
    story.append(Spacer(1, 0.3 * inch))
    
    # Build TOC from contract sections
    # Estimate page numbers: Title page = 1, TOC = 2, Sections start at 3
    # We'll estimate based on content length - most sections are 0.2-0.4 pages
    # Total document is typically 10-15 pages for 35 sections
    current_page = 3.0  # Start after title (1) and TOC (2) pages
    toc_section_counter = 0
    
    for i, section in enumerate(CONTRACT_SECTIONS):
        section_title = section["title"]
        
        # Skip milestones section for LABOR contracts in TOC
        if section["title"] == "8. MILESTONES & DELIVERABLES" and contract_type == "LABOR":
            continue
        
        # Skip rate card section for MATERIAL contracts in TOC
        if section["title"] == "36. RATE CARD" and contract_type != "LABOR":
            continue
        
        # Renumber section title for TOC
        toc_section_counter += 1
        if section_title and section_title[0].isdigit():
            match = re.match(r'^(\d+)\.', section_title)
            if match:
                original_num = match.group(1)
                section_title = section_title.replace(f"{original_num}.", f"{toc_section_counter}.", 1)
        
        # Get content length to estimate pages
        if section["title"] == "1. PURPOSE & SCOPE":
            content_list = selected_scope["description"]
        elif section["title"] == "36. RATE CARD":
            # Rate card section - estimate for LABOR
            if contract_type == "LABOR":
                content_list = ["Rate card table with roles, rates, and hours"]
            else:
                continue  # Should not reach here due to skip above
        else:
            content_list = section["content"]
        
        # Skip if content_list is None
        if content_list is None:
            continue
        
        # Estimate pages based on content length
        content_length = sum(len(str(c)) for c in content_list)
        # Rough estimate: ~2000 chars per page, but sections vary
        if content_length > 800:
            pages_per_section = 0.4  # Longer sections
        elif content_length > 400:
            pages_per_section = 0.3  # Medium sections
        else:
            pages_per_section = 0.2  # Shorter sections
        
        # Round to nearest integer for page number
        page_num = int(round(current_page))
        toc_entry = f"{section_title} ................................................ {page_num}"
        story.append(Paragraph(toc_entry, toc_style))
        current_page += pages_per_section
    
    # Signatures page (estimate based on total sections)
    # Typically around page 10-12 for 35 sections
    signatures_page = int(round(current_page))
    story.append(Spacer(1, 0.3 * inch))
    story.append(Paragraph(f"SIGNATURES ................................................ {signatures_page}", toc_style))
    story.append(PageBreak())
    
    # Contract sections
    # For MATERIAL contracts, use generated milestones; for LABOR, use default structure
    if contract_type == "MATERIAL" and milestones_data:
        milestone_dates = [m["date"] for m in milestones_data]
        milestone_amounts = [m["amount"] for m in milestones_data]
        milestone_names = [m["name"] for m in milestones_data]
        # Pad to 5 milestones if needed
        while len(milestone_dates) < 5:
            milestone_dates.append(milestone_dates[-1] + timedelta(days=90))
            milestone_amounts.append(int(contract_value * 0.20))
            milestone_names.append("Additional Milestone")
    else:
        milestone_dates = [
            effective_date + timedelta(days=90),
            effective_date + timedelta(days=180),
            effective_date + timedelta(days=270),
            effective_date + timedelta(days=360),
            effective_date + timedelta(days=450)
        ]
        milestone_amounts = [
            int(contract_value * 0.15),
            int(contract_value * 0.25),
            int(contract_value * 0.20),
            int(contract_value * 0.20),
            int(contract_value * 0.20)
        ]
        milestone_names = [
            "Site Preparation Complete",
            "Wells Drilled and Completed",
            "CDU Upgrade Complete",
            "HDS Unit Installed",
            "Pipeline Complete"
        ]
    
    # Calculate rate card section number for LABOR contracts (needed for Purpose & Scope reference)
    # If Section 8 is skipped, Section 36 becomes Section 35
    rate_card_section_num = 35 if contract_type == "LABOR" else None
    
    # Track section number for renumbering when sections are skipped
    section_counter = 0
    
    for section in CONTRACT_SECTIONS:
        # Skip milestones section for LABOR contracts (T&M invoices, not milestone-based)
        if section["title"] == "8. MILESTONES & DELIVERABLES" and contract_type == "LABOR":
            continue
        
        # Skip rate card section for MATERIAL contracts
        if section["title"] == "36. RATE CARD" and contract_type != "LABOR":
            continue
        
        # Renumber section title to maintain continuous numbering
        section_counter += 1
        section_title = section["title"]
        
        # Extract section number and renumber
        if section_title and section_title[0].isdigit():
            # Find the section number (e.g., "8. MILESTONES" -> "8")
            match = re.match(r'^(\d+)\.', section_title)
            if match:
                original_num = match.group(1)
                # Replace with new number
                section_title = section_title.replace(f"{original_num}.", f"{section_counter}.", 1)
        
        story.append(Paragraph(section_title, heading_style))
        
        # Use selected project scope for PURPOSE & SCOPE section
        if section["title"] == "1. PURPOSE & SCOPE":
            # Replace "Rate Card section" or "Section 36" reference with actual section number
            content_list = []
            for desc in selected_scope["description"]:
                if rate_card_section_num and ("Rate Card" in desc or "Section 36" in desc):
                    desc = desc.replace("Rate Card section", f"Section {rate_card_section_num}")
                    desc = desc.replace("Section 36", f"Section {rate_card_section_num}")
                content_list.append(desc)
        elif section["title"] == "8. MILESTONES & DELIVERABLES" and contract_type == "MATERIAL" and milestones_data:
            # Use generated milestones for MATERIAL contracts
            content_list = [
                "The following milestones apply to this Agreement:",
                ""
            ]
            # Milestones table will be added below
        elif section["title"] == "36. RATE CARD" and contract_type == "LABOR" and rate_card_data:
            # Generate rate card table
            content_list = [
                "The following rate card applies to all services provided under this Agreement:",
                ""
            ]
            # Rate card will be added as a table below
        else:
            content_list = section["content"]
        
        if content_list:
            for content in content_list:
                if content is None:
                    continue
                # Replace placeholders with parameters
                try:
                    formatted_content = content.format(
                        effective_date=effective_date.strftime('%d-%b-%Y'),
                        completion_date=completion_date.strftime('%d-%b-%Y'),
                        contract_value=f"£{contract_value:,}",
                        milestone1_date=milestone_dates[0].strftime('%d-%b-%Y'),
                        milestone1_amount=milestone_amounts[0],
                        milestone2_date=milestone_dates[1].strftime('%d-%b-%Y'),
                        milestone2_amount=milestone_amounts[1],
                        milestone3_date=milestone_dates[2].strftime('%d-%b-%Y'),
                        milestone3_amount=milestone_amounts[2],
                        milestone4_date=milestone_dates[3].strftime('%d-%b-%Y'),
                        milestone4_amount=milestone_amounts[3],
                        milestone5_date=milestone_dates[4].strftime('%d-%b-%Y'),
                        milestone5_amount=milestone_amounts[4],
                        # Parameterized values
                        retention_percent=params["retention_percent"],
                        payment_days=params["payment_days"],
                        indexation_rate=params["indexation_rate"],
                        delay_ld_per_week=params["delay_ld_per_week"],
                        performance_ld_per_pct=params["performance_ld_per_pct"],
                        kpi_threshold=params["kpi_threshold"],
                        co_threshold_1=params["co_threshold_1"],
                        co_threshold_2=params["co_threshold_2"],
                        public_liability=params["public_liability"],
                        professional_indemnity=params["professional_indemnity"],
                        warranty_months=params["warranty_months"],
                        pipeline_km=params["pipeline_km"],
                        num_wells=params["num_wells"],
                        ses_grn_clause=ses_grn_clause
                    )
                    story.append(Paragraph(formatted_content, styles['Normal']))
                except KeyError:
                    # If placeholder not found, use content as-is
                    story.append(Paragraph(content, styles['Normal']))
        
        # Add rate card table for LABOR contracts
        if section["title"] == "36. RATE CARD" and contract_type == "LABOR" and rate_card_data:
            story.append(Spacer(1, 0.2 * inch))
            # Create rate card table
            table_data = [["Role", "Hourly Rate (£)", "Allowed Hours", "Total Amount (£)"]]
            total_rate_card_value = 0
            for role_data in rate_card_data:
                table_data.append([
                    role_data["role"],
                    f"{role_data['hourly_rate']:,}",
                    f"{role_data['allowed_hours']:,}",
                    f"{role_data['total_amount']:,}"
                ])
                total_rate_card_value += role_data['total_amount']
            
            # Add total row
            table_data.append([
                "TOTAL", "", "", f"{total_rate_card_value:,}"
            ])
            
            rate_card_table = Table(table_data, colWidths=[2.5*inch, 1.5*inch, 1.5*inch, 1.5*inch])
            rate_card_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#003366')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (0, -1), 'LEFT'),  # Role column left-aligned
                ('ALIGN', (1, 1), (3, -1), 'RIGHT'),  # Rate, Hours, Amount columns right-aligned
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -2), colors.beige),
                ('BACKGROUND', (0, -1), (-1, -1), colors.lightgrey),
                ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('FONTSIZE', (0, 1), (-1, -1), 9),
            ]))
            story.append(rate_card_table)
        
        # Add milestones table for MATERIAL contracts (in Section 8)
        if section["title"] == "8. MILESTONES & DELIVERABLES" and contract_type == "MATERIAL" and milestones_data:
            story.append(Spacer(1, 0.2 * inch))
            # Create milestones table
            table_data = [["Milestone", "Due Date", "Amount (£)"]]
            total_milestones_value = 0
            for milestone in milestones_data:
                milestone_date = milestone.get("date")
                if isinstance(milestone_date, str):
                    try:
                        milestone_date = datetime.strptime(milestone_date, '%Y-%m-%d')
                    except ValueError:
                        milestone_date = datetime.now()
                elif not isinstance(milestone_date, datetime):
                    milestone_date = datetime.now()
                
                table_data.append([
                    milestone["name"],
                    milestone_date.strftime('%d-%b-%Y'),
                    f"{milestone['amount']:,}"
                ])
                total_milestones_value += milestone['amount']
            
            # Add total row
            table_data.append([
                "TOTAL", "", f"{total_milestones_value:,}"
            ])
            
            milestones_table = Table(table_data, colWidths=[3.5*inch, 1.5*inch, 1.5*inch])
            milestones_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#003366')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('ALIGN', (2, 1), (-1, -1), 'RIGHT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -2), colors.beige),
                ('BACKGROUND', (0, -1), (-1, -1), colors.lightgrey),
                ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('FONTSIZE', (0, 1), (-1, -1), 9),
            ]))
            story.append(milestones_table)
            story.append(Spacer(1, 0.2 * inch))
            story.append(Paragraph("Final Acceptance: All deliverables completed and accepted - Billing: Remaining balance", styles['Normal']))
            story.append(Paragraph("Detailed milestone schedule and LD triggers are set forth in Schedule 5.", styles['Normal']))
        
    story.append(Spacer(1, 0.2 * inch))
    
    # Signatures page
    story.append(PageBreak())
    story.append(Paragraph("SIGNATURES", heading_style))
    story.append(Spacer(1, 0.5 * inch))
    
    story.append(Paragraph("Company:", subheading_style))
    story.append(Paragraph("BP p.l.c.", styles['Normal']))
    story.append(Spacer(1, 0.3 * inch))
    story.append(Paragraph("_________________________", styles['Normal']))
    story.append(Paragraph("Authorized Signatory", styles['Normal']))
    story.append(Paragraph(f"Date: {effective_date.strftime('%d %B %Y')}", styles['Normal']))
    story.append(Spacer(1, 0.5 * inch))
    
    story.append(Paragraph("Service Provider:", subheading_style))
    story.append(Paragraph(service_provider, styles['Normal']))
    story.append(Spacer(1, 0.3 * inch))
    story.append(Paragraph("_________________________", styles['Normal']))
    story.append(Paragraph("Authorized Signatory", styles['Normal']))
    story.append(Paragraph(f"Date: {effective_date.strftime('%d %B %Y')}", styles['Normal']))
    
    doc.build(story)
    print(f"✓ Generated signed contract: {filepath.name}")
    
    # Prepare metadata
    metadata = {
        "contract_type": contract_type,
        "sow_number": sow_number,
        "contract_value": contract_value,
        "effective_date": effective_date.strftime('%Y-%m-%d'),
        "service_provider": service_provider
    }
    
    if contract_type == "LABOR" and rate_card_data:
        metadata["rate_card"] = rate_card_data
    elif contract_type == "MATERIAL" and milestones_data:
        metadata["milestones"] = [
            {
                "name": m["name"],
                "date": m["date"].strftime('%Y-%m-%d'),
                "amount": m["amount"]
            }
            for m in milestones_data
        ]
    
    return filepath, metadata


def generate_po_pdf(
    sow_number: str,
    po_number: str,
    base_dir: Path,
    contract_type: str,
    rate_card_data: Optional[List[Dict[str, Any]]] = None,
    milestones_data: Optional[List[Dict[str, Any]]] = None,
    service_provider: Optional[str] = None,
    seed: Optional[int] = None
) -> Path:
    """Generate Purchase Order PDF.
    
    Args:
        sow_number: SOW number this PO is for
        po_number: PO number (e.g., PO-2025-2001)
        base_dir: Base directory for covenant data
        contract_type: LABOR or MATERIAL
        rate_card_data: Rate card data for LABOR contracts
        milestones_data: Milestone data for MATERIAL contracts
        service_provider: Service provider name
        seed: Random seed
    
    Returns:
        Path to generated PO PDF
    """
    if not REPORTLAB_AVAILABLE:
        raise RuntimeError(
            "reportlab is required for PDF generation. "
            "Install with: uv sync --group scripts (or: pip install reportlab)"
        )
    
    if seed:
        random.seed(seed)
    
    # Create pos folder
    pos_dir = base_dir / "pos"
    pos_dir.mkdir(parents=True, exist_ok=True)
    
    filepath = pos_dir / f"{sow_number}_po_{po_number}.pdf"
    
    if service_provider is None:
        service_provider = random.choice(SERVICE_PROVIDERS)
    
    po_date = datetime.now() - timedelta(days=random.randint(1, 30))
    
    # Create custom page template
    def add_page_header_footer(canvas_obj, doc):
        """Add header, page numbers and confidential footer to each page."""
        page_num = canvas_obj.getPageNumber()
        width, height = letter
        
        canvas_obj.saveState()
        
        # Header
        canvas_obj.setFont("Helvetica-Bold", 12)
        canvas_obj.setFillColor(colors.HexColor('#003366'))
        company_text = "BP p.l.c."
        canvas_obj.drawString(72, height - 50, company_text)
        
        canvas_obj.setFont("Helvetica", 10)
        canvas_obj.setFillColor(colors.HexColor('#666666'))
        doc_title = "PURCHASE ORDER"
        title_width = canvas_obj.stringWidth(doc_title, "Helvetica", 10)
        canvas_obj.drawString(width - 72 - title_width, height - 50, doc_title)
        
        canvas_obj.setFont("Helvetica", 9)
        po_text = f"PO: {po_number} | SOW: {sow_number}"
        po_width = canvas_obj.stringWidth(po_text, "Helvetica", 9)
        canvas_obj.drawString(width - 72 - po_width, height - 65, po_text)
        
        canvas_obj.setStrokeColor(colors.HexColor('#CCCCCC'))
        canvas_obj.setLineWidth(0.5)
        canvas_obj.line(72, height - 75, width - 72, height - 75)
        
        # Footer
        canvas_obj.setFont("Helvetica", 9)
        canvas_obj.setFillColor(colors.HexColor('#666666'))
        confidential_text = "CONFIDENTIAL - This document contains proprietary and confidential information"
        text_width = canvas_obj.stringWidth(confidential_text, "Helvetica", 9)
        canvas_obj.drawString((width - text_width) / 2, 30, confidential_text)
        
        page_text = f"Page {page_num}"
        page_width = canvas_obj.stringWidth(page_text, "Helvetica", 9)
        canvas_obj.drawString(width - page_width - 50, 30, page_text)
        
        canvas_obj.restoreState()
    
    doc = SimpleDocTemplate(
        str(filepath),
        pagesize=letter,
        rightMargin=72,
        leftMargin=72,
        topMargin=100,
        bottomMargin=72,
        onFirstPage=add_page_header_footer,
        onLaterPages=add_page_header_footer
    )
    story = []
    styles = getSampleStyleSheet()
    
    # Custom styles
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Title'],
        fontSize=20,
        textColor=colors.HexColor('#003366'),
        spaceAfter=30,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=14,
        textColor=colors.HexColor('#003366'),
        spaceAfter=12,
        spaceBefore=12,
        fontName='Helvetica-Bold'
    )
    
    # Title
    story.append(Paragraph("PURCHASE ORDER", title_style))
    story.append(Spacer(1, 0.3 * inch))
    
    # PO Information
    story.append(Paragraph("Purchase Order Information", heading_style))
    story.append(Paragraph(f"Purchase Order Number: {po_number}", styles['Normal']))
    story.append(Paragraph(f"Statement of Work: {sow_number}", styles['Normal']))
    story.append(Paragraph(f"Date: {po_date.strftime('%d-%b-%Y')}", styles['Normal']))
    story.append(Paragraph(f"Vendor: {service_provider}", styles['Normal']))
    story.append(Spacer(1, 0.3 * inch))
    
    # Line Items
    story.append(Paragraph("Line Items", heading_style))
    
    if contract_type == "LABOR" and rate_card_data:
        # LABOR PO: Rate card table
        table_data = [["Line", "Role", "Hourly Rate (£)", "Allowed Hours", "Total Amount (£)"]]
        total_po_value = 0
        for line_num, role_data in enumerate(rate_card_data, 1):
            table_data.append([
                str(line_num),
                role_data["role"],
                f"{role_data['hourly_rate']:,}",
                f"{role_data['allowed_hours']:,}",
                f"{role_data['total_amount']:,}"
            ])
            total_po_value += role_data['total_amount']
        
        # Add total row
        table_data.append([
            "", "TOTAL", "", "", f"{total_po_value:,}"
        ])
        
        po_table = Table(table_data, colWidths=[0.5*inch, 2.0*inch, 1.2*inch, 1.2*inch, 1.5*inch])
        po_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#003366')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (1, -1), 'LEFT'),  # Line and Role columns left-aligned
            ('ALIGN', (2, 1), (-1, -1), 'RIGHT'),  # Rate, Hours, Amount columns right-aligned
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -2), colors.beige),
            ('BACKGROUND', (0, -1), (-1, -1), colors.lightgrey),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('FONTSIZE', (0, 1), (-1, -1), 9),
        ]))
        story.append(po_table)
        
    elif contract_type == "MATERIAL" and milestones_data:
        # MATERIAL PO: Milestones table
        table_data = [["Line", "Milestone Name", "Due Date", "Amount (£)"]]
        total_po_value = 0
        for line_num, milestone in enumerate(milestones_data, 1):
            # Ensure amount is positive
            amount = max(0, milestone.get('amount', 0))
            # Handle date - could be string or datetime
            milestone_date = milestone.get('date')
            if isinstance(milestone_date, str):
                try:
                    milestone_date = datetime.strptime(milestone_date, '%Y-%m-%d')
                except ValueError:
                    milestone_date = datetime.now()
            elif not isinstance(milestone_date, datetime):
                milestone_date = datetime.now()
            
            table_data.append([
                str(line_num),
                milestone.get("name", f"Milestone {line_num}"),
                milestone_date.strftime('%d-%b-%Y'),
                f"{amount:,}"
            ])
            total_po_value += amount
        
        # Ensure total is positive
        total_po_value = max(0, total_po_value)
        
        # Add total row
        table_data.append([
            "", "TOTAL", "", f"{total_po_value:,}"
        ])
        
        po_table = Table(table_data, colWidths=[0.5*inch, 3.0*inch, 1.5*inch, 1.5*inch])
        po_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#003366')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('ALIGN', (3, 1), (-1, -1), 'RIGHT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -2), colors.beige),
            ('BACKGROUND', (0, -1), (-1, -1), colors.lightgrey),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('FONTSIZE', (0, 1), (-1, -1), 9),
        ]))
        story.append(po_table)
    
    story.append(Spacer(1, 0.3 * inch))
    
    # Approval
    story.append(Paragraph("Approval", heading_style))
    story.append(Paragraph("This purchase order is approved by:", styles['Normal']))
    story.append(Spacer(1, 0.2 * inch))
    story.append(Paragraph("_________________________", styles['Normal']))
    story.append(Paragraph("Authorized Signatory", styles['Normal']))
    story.append(Paragraph(f"Date: {po_date.strftime('%d-%b-%Y')}", styles['Normal']))
    
    doc.build(story)
    print(f"✓ Generated PO: {filepath.name}")
    return filepath


def generate_change_order_pdf(
    sow_number: str,
    base_dir: Path,
    version: str,
    current_terms: Optional[Dict[str, Any]] = None,
    modified_terms: Optional[Dict[str, List[str]]] = None,
    seed: Optional[int] = None
) -> Path:
    """Generate intelligent change order PDF based on actual contract terms."""
    if not REPORTLAB_AVAILABLE:
        raise RuntimeError(
            "reportlab is required for PDF generation. "
            "Install with: uv sync --group scripts (or: pip install reportlab)"
        )
    
    if seed:
        random.seed(seed)
    
    pending_dir = base_dir / "pending"
    pending_dir.mkdir(parents=True, exist_ok=True)
    
    filepath = pending_dir / f"{sow_number}_change_order_{version}.pdf"
    
    # Create custom page template for header, page numbers and footer
    def add_page_header_footer(canvas_obj, doc):
        """Add header, page numbers and confidential footer to each page."""
        page_num = canvas_obj.getPageNumber()
        width, height = letter
        
        canvas_obj.saveState()
        
        # ========================================================================
        # HEADER
        # ========================================================================
        canvas_obj.setFont("Helvetica-Bold", 12)
        canvas_obj.setFillColor(colors.HexColor('#003366'))
        
        # Company name (left side)
        company_text = "BP p.l.c."
        canvas_obj.drawString(72, height - 50, company_text)
        
        # Document title (right side)
        canvas_obj.setFont("Helvetica", 10)
        canvas_obj.setFillColor(colors.HexColor('#666666'))
        doc_title = "CHANGE ORDER"
        title_width = canvas_obj.stringWidth(doc_title, "Helvetica", 10)
        canvas_obj.drawString(width - 72 - title_width, height - 50, doc_title)
        
        # SOW number (right side, below title)
        canvas_obj.setFont("Helvetica", 9)
        sow_text = f"SOW: {sow_number} | {version}"
        sow_width = canvas_obj.stringWidth(sow_text, "Helvetica", 9)
        canvas_obj.drawString(width - 72 - sow_width, height - 65, sow_text)
        
        # Header line separator
        canvas_obj.setStrokeColor(colors.HexColor('#CCCCCC'))
        canvas_obj.setLineWidth(0.5)
        canvas_obj.line(72, height - 75, width - 72, height - 75)
        
        # ========================================================================
        # FOOTER
        # ========================================================================
        canvas_obj.setFont("Helvetica", 9)
        canvas_obj.setFillColor(colors.HexColor('#666666'))
        
        # Confidential text (centered, bottom)
        confidential_text = "CONFIDENTIAL - This document contains proprietary and confidential information"
        text_width = canvas_obj.stringWidth(confidential_text, "Helvetica", 9)
        canvas_obj.drawString((width - text_width) / 2, 30, confidential_text)
        
        # Page number (bottom right)
        page_text = f"Page {page_num}"
        page_width = canvas_obj.stringWidth(page_text, "Helvetica", 9)
        canvas_obj.drawString(width - page_width - 50, 30, page_text)
        
        canvas_obj.restoreState()
    
    doc = SimpleDocTemplate(
        str(filepath),
        pagesize=letter,
        rightMargin=72,
        leftMargin=72,
        topMargin=100,  # Increased to accommodate header
        bottomMargin=72,
        onFirstPage=add_page_header_footer,
        onLaterPages=add_page_header_footer
    )
    story = []
    styles = getSampleStyleSheet()
    
    # Custom styles
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Title'],
        fontSize=18,
        textColor=colors.HexColor('#cc6600'),
        spaceAfter=30,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=14,
        textColor=colors.HexColor('#cc6600'),
        spaceAfter=12,
        spaceBefore=12,
        fontName='Helvetica-Bold'
    )
    
    # Title
    story.append(Paragraph("CHANGE ORDER", title_style))
    story.append(Paragraph(f"Project: {sow_number}", heading_style))
    story.append(Paragraph(f"Change Order {version}", heading_style))
    story.append(Spacer(1, 0.3 * inch))
    
    # Change order information
    change_order_date = datetime.now() - timedelta(days=random.randint(1, 60))
    
    # Generate intelligent changes based on actual terms
    if current_terms and modified_terms is not None:
        changes = generate_intelligent_change_order(
            sow_number, base_dir, version, current_terms, modified_terms, seed
        )
        # Determine reason from changes
        if any("payment" in c.lower() for c in changes):
            reason = "Payment terms modification"
        elif any("scope" in c.lower() or "pipeline" in c.lower() for c in changes):
            reason = "Scope expansion - additional pipeline segment"
        elif any("milestone" in c.lower() for c in changes):
            reason = "Timeline adjustment - milestone extensions"
        else:
            reason = "Contract terms modification"
    else:
        # Fallback to template
        template = random.choice(CHANGE_ORDER_TEMPLATES)
        changes = template['changes']
        reason = template['reason']
    
    story.append(Paragraph("Change Order Information", heading_style))
    story.append(Paragraph(f"Change Order Number: {version}", styles['Normal']))
    story.append(Paragraph(f"Date: {change_order_date.strftime('%d-%b-%Y')}", styles['Normal']))
    story.append(Paragraph(f"Reason: {reason}", styles['Normal']))
    story.append(Spacer(1, 0.2 * inch))
    
    # Changes
    story.append(Paragraph("Changes", heading_style))
    for i, change in enumerate(changes, 1):
        story.append(Paragraph(f"{i}. {change}", styles['Normal']))
    story.append(Spacer(1, 0.2 * inch))
    
    # Approval
    story.append(Paragraph("Approval", heading_style))
    story.append(Paragraph("This change order is approved by:", styles['Normal']))
    story.append(Spacer(1, 0.2 * inch))
    story.append(Paragraph("_________________________", styles['Normal']))
    story.append(Paragraph("Authorized Signatory", styles['Normal']))
    story.append(Paragraph(f"Date: {change_order_date.strftime('%d-%b-%Y')}", styles['Normal']))
    
    doc.build(story)
    print(f"✓ Generated change order: {filepath.name}")
    return filepath


# ============================================================================
# Main Functions
# ============================================================================

def find_existing_contracts(base_dir: Path) -> List[str]:
    """Find existing signed contracts by scanning processed folder only.
    
    Note: Only checks processed folder, not pending folder, to exclude
    newly generated contracts that haven't been processed yet.
    """
    contracts = set()
    
    # Check processed folder only (exclude pending to avoid newly generated contracts)
    processed_dir = base_dir / "processed"
    if processed_dir.exists():
        for file in processed_dir.glob("*_signed.pdf"):
            sow_number = file.stem.replace("_signed", "")
            contracts.add(sow_number)
    
    return sorted(list(contracts))


def get_next_change_order_version(base_dir: Path, sow_number: str) -> str:
    """Get next change order version for a contract."""
    versions = []
    
    # Check pending folder
    pending_dir = base_dir / "pending"
    if pending_dir.exists():
        for file in pending_dir.glob(f"{sow_number}_change_order_*.pdf"):
            version = file.stem.split("_change_order_")[-1]
            versions.append(version)
    
    # Check processed folder
    processed_dir = base_dir / "processed"
    if processed_dir.exists():
        for file in processed_dir.glob(f"{sow_number}_change_order_*.pdf"):
            version = file.stem.split("_change_order_")[-1]
            versions.append(version)
    
    if not versions:
        return "v1"
    
    # Extract version numbers and find max
    max_version = 0
    for v in versions:
        try:
            num = int(v.replace("v", ""))
            max_version = max(max_version, num)
        except ValueError:
            continue
    
    return f"v{max_version + 1}"


def get_next_po_number(base_dir: Path, seed: Optional[int] = None) -> str:
    """Get next available PO number."""
    if seed:
        random.seed(seed)
    
    # Check existing POs in pos folder
    pos_dir = base_dir / "pos"
    existing_pos = set()
    
    if pos_dir.exists():
        for file in pos_dir.glob("*_po_*.pdf"):
            # Extract PO number from filename like SOW-2025-2001_po_PO-2025-2001.pdf
            parts = file.stem.split("_po_")
            if len(parts) == 2:
                existing_pos.add(parts[1])
    
    # Generate new PO number
    while True:
        po_num = random.randint(2000, 2999)
        po_number = f"{PO_ID_PREFIX}-{po_num}"
        if po_number not in existing_pos:
            return po_number


def generate_new_contracts(
    base_dir: Path,
    count: int = 2,
    labor_ratio: float = 0.5,
    seed: Optional[int] = None
) -> None:
    """Generate new signed contracts with associated POs.
    
    Args:
        base_dir: Base directory for covenant data
        count: Number of contracts to generate
        labor_ratio: Ratio of LABOR contracts (0.0-1.0, default 0.5 = 50%)
        seed: Random seed
    """
    print(f"\n{'='*70}")
    print(f"Generating {count} new signed contracts...")
    print(f"Labor ratio: {labor_ratio:.0%} LABOR, {1-labor_ratio:.0%} MATERIAL")
    print(f"{'='*70}\n")
    
    if seed:
        random.seed(seed)
    
    db_path = base_dir / "covenant.db"
    
    for i in range(count):
        sow_number = f"{SOW_ID_PREFIX}-{random.randint(2000, 2999)}"
        contract_value = random.randint(10_000_000, 100_000_000)  # 10M - 100M
        
        # Determine contract type based on ratio
        # Use simple alternating pattern for 50/50, cycle-based for other ratios
        if abs(labor_ratio - 0.5) < 0.01:  # Close to 50/50
            # Simple alternation: contract 0=LABOR, 1=MATERIAL, 2=LABOR, 3=MATERIAL...
            contract_type = "LABOR" if i % 2 == 0 else "MATERIAL"
        else:
            # For other ratios, use cycle-based approach with cycle of 10
            cycle_size = 10
            labor_in_cycle = round(labor_ratio * cycle_size)
            position_in_cycle = i % cycle_size
            contract_type = "LABOR" if position_in_cycle < labor_in_cycle else "MATERIAL"
        
        # Generate contract
        contract_path, metadata = generate_signed_contract_pdf(
            sow_number=sow_number,
            base_dir=base_dir,
            contract_value=contract_value,
            contract_type=contract_type,
            seed=seed + i if seed else None
        )
        
        # Generate PO
        po_number = get_next_po_number(base_dir, seed + i if seed else None)
        
        # Convert milestone dates back to datetime for PO generation
        milestones_for_po = None
        if metadata.get("milestones"):
            milestones_for_po = []
            for m in metadata["milestones"]:
                milestone_copy = m.copy()
                if isinstance(milestone_copy["date"], str):
                    milestone_copy["date"] = datetime.strptime(milestone_copy["date"], '%Y-%m-%d')
                milestones_for_po.append(milestone_copy)
        
        po_path = generate_po_pdf(
            sow_number=sow_number,
            po_number=po_number,
            base_dir=base_dir,
            contract_type=contract_type,
            rate_card_data=metadata.get("rate_card"),
            milestones_data=milestones_for_po,
            service_provider=metadata.get("service_provider"),
            seed=seed + i if seed else None
        )
        
        # NOTE: The mock data script only generates PDFs. The pipeline agents will extract
        # contract information from the PDFs and populate the database. This ensures the
        # pipeline is the authoritative source for all contract data in the database.


def get_rate_card_from_db(db_path: Path, sow_number: str) -> Optional[List[Dict[str, Any]]]:
    """Get rate card data from database for a given SOW."""
    if not db_path.exists():
        return None
    
    try:
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT term_value
            FROM contract_terms
            WHERE contract_id = ? AND term_category = 'rate_card'
            ORDER BY clause_identifier
        """, (sow_number,))
        
        rate_card = []
        for row in cursor.fetchall():
            if row["term_value"]:
                role_data = json.loads(row["term_value"])
                rate_card.append(role_data)
        
        conn.close()
        return rate_card if rate_card else None
    
    except Exception as e:
        print(f"⚠ Failed to get rate card from database: {e}")
        return None


def get_milestones_from_db(db_path: Path, sow_number: str) -> Optional[List[Dict[str, Any]]]:
    """Get milestone data from database for a given SOW."""
    if not db_path.exists():
        return None
    
    try:
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT term_value
            FROM contract_terms
            WHERE contract_id = ? AND term_category = 'milestone'
            ORDER BY clause_identifier
        """, (sow_number,))
        
        milestones = []
        for row in cursor.fetchall():
            if row["term_value"]:
                milestone = json.loads(row["term_value"])
                # Convert date string back to datetime if needed
                if isinstance(milestone.get("date"), str):
                    milestone["date"] = datetime.strptime(milestone["date"], '%Y-%m-%d')
                milestones.append(milestone)
        
        conn.close()
        return milestones if milestones else None
    
    except Exception as e:
        print(f"⚠ Failed to get milestones from database: {e}")
        return None


def get_contract_type_from_db(db_path: Path, sow_number: str) -> Optional[str]:
    """Get contract type from database for a given SOW."""
    if not db_path.exists():
        return None
    
    try:
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT contract_type
            FROM contracts
            WHERE sow_number = ?
        """, (sow_number,))
        
        row = cursor.fetchone()
        conn.close()
        
        return row[0] if row and row[0] else None
    
    except Exception as e:
        print(f"⚠ Failed to get contract type from database: {e}")
        return None


def generate_change_orders_for_existing(
    base_dir: Path,
    count_per_contract: int = 1,
    seed: Optional[int] = None
) -> None:
    """Generate change orders for existing contracts.
    
    Only generates change orders for contracts found in database or processed folder.
    Generates PO if change order modifies rate card (LABOR) or milestones (MATERIAL).
    """
    existing_contracts = find_existing_contracts(base_dir)
    
    # Also check database for contracts
    db_path = base_dir / "covenant.db"
    if db_path.exists():
        try:
            conn = sqlite3.connect(str(db_path))
            cursor = conn.cursor()
            cursor.execute("SELECT sow_number FROM contracts")
            db_contracts = {row[0] for row in cursor.fetchall()}
            existing_contracts = sorted(list(set(existing_contracts) | db_contracts))
            conn.close()
        except Exception as e:
            print(f"⚠ Failed to query database for contracts: {e}")
    
    if not existing_contracts:
        print("\n⚠ No existing contracts found in database or processed folder. Generate signed contracts first.")
        return
    
    print(f"\n{'='*70}")
    print(f"Found {len(existing_contracts)} existing contract(s)")
    print(f"Generating {count_per_contract} change order(s) per contract...")
    print(f"{'='*70}\n")
    
    if seed:
        random.seed(seed)
    
    for sow_number in existing_contracts:
        # Get contract type from database
        contract_type = get_contract_type_from_db(db_path, sow_number)
        
        # Get current terms (database first, then PDF)
        current_terms = get_contract_terms(base_dir, sow_number)
        
        # Get modification history
        modified_terms = get_modified_terms_from_history(db_path, sow_number) if db_path.exists() else {}
        
        # Get rate card or milestones from database
        rate_card_data = None
        milestones_data = None
        if contract_type == "LABOR":
            rate_card_data = get_rate_card_from_db(db_path, sow_number)
        elif contract_type == "MATERIAL":
            milestones_data = get_milestones_from_db(db_path, sow_number)
        
        for i in range(count_per_contract):
            version = get_next_change_order_version(base_dir, sow_number)
            
            # Generate change order
            change_order_path = generate_change_order_pdf(
                sow_number=sow_number,
                base_dir=base_dir,
                version=version,
                current_terms=current_terms,
                modified_terms=modified_terms,
                seed=seed + hash(sow_number) + i if seed else None
            )
            
            # Check if change order modifies rate card or milestones
            # For now, we'll generate PO for a percentage of change orders (30%)
            # In a real implementation, this would analyze the change order content
            needs_po = False
            if contract_type == "LABOR" and rate_card_data:
                # Check if change order mentions rate card modifications
                # Simplified: generate PO for 30% of change orders
                needs_po = random.random() < 0.3
            elif contract_type == "MATERIAL" and milestones_data:
                # Check if change order mentions milestone modifications
                # Simplified: generate PO for 30% of change orders
                needs_po = random.random() < 0.3
            
            if needs_po:
                # Generate PO for change order
                po_number = get_next_po_number(base_dir, seed + hash(sow_number) + i if seed else None)
                
                # Get service provider from database or use default
                service_provider = None
                if db_path.exists():
                    try:
                        conn = sqlite3.connect(str(db_path))
                        cursor = conn.cursor()
                        cursor.execute("SELECT vendor_id FROM contracts WHERE sow_number = ?", (sow_number,))
                        row = cursor.fetchone()
                        if row and row[0]:
                            service_provider = row[0]
                        conn.close()
                    except Exception:
                        pass
                
                # Generate PO with updated data (for now, use existing data)
                # In a real implementation, this would apply modifications from change order
                po_path = generate_po_pdf(
                    sow_number=sow_number,
                    po_number=po_number,
                    base_dir=base_dir,
                    contract_type=contract_type or "LABOR",
                    rate_card_data=rate_card_data,
                    milestones_data=milestones_data,
                    service_provider=service_provider,
                    seed=seed + hash(sow_number) + i if seed else None
                )
                
                # Rename PO to include change order version
                new_po_path = base_dir / "pos" / f"{sow_number}_change_order_{version}_po_{po_number}.pdf"
                if po_path.exists():
                    po_path.rename(new_po_path)
                    print(f"✓ Generated change order PO: {new_po_path.name}")


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Setup Covenant pipeline data"
    )
    parser.add_argument(
        "--project-dir",
        type=str,
        default="projects/pa",
        help="Project directory path (default: projects/pa)"
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default=None,
        help="Base directory for generated files (default: {project_dir}/data/covenant)"
    )
    parser.add_argument(
        "--contracts",
        type=int,
        default=2,
        help="Number of new signed contracts to generate (default: 2)"
    )
    parser.add_argument(
        "--labor-ratio",
        type=float,
        default=0.5,
        help="Ratio of LABOR contracts (0.0-1.0, default: 0.5 = 50%% LABOR, 50%% MATERIAL)"
    )
    parser.add_argument(
        "--change-orders",
        type=int,
        default=1,
        help="Number of change orders per existing contract (default: 1)"
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Random seed for reproducible generation"
    )
    parser.add_argument(
        "--skip-db",
        action="store_true",
        help="Skip database setup"
    )
    parser.add_argument(
        "--reset",
        action="store_true",
        default=False,
        help="Delete entire data/covenant folder to start fresh (default: False)"
    )
    
    args = parser.parse_args()
    
    # Detect project name and resolve paths
    project_name = detect_project_name(Path.cwd())
    
    # Determine output directory
    if args.output_dir and args.output_dir.strip():
        base_dir = resolve_script_path(args.output_dir, project_name=project_name)
    else:
        project_dir = resolve_script_path(args.project_dir, project_name=project_name)
        base_dir = project_dir / BASE_DIR
    
    # Ensure base directory exists
    base_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"\n{'='*70}")
    print("Covenant Data Setup")
    print(f"{'='*70}")
    print(f"Output directory: {base_dir}")
    print(f"{'='*70}\n")
    
    # Reset if requested
    if args.reset:
        print(f"\n{'='*70}")
        print("RESET MODE: Deleting entire covenant data folder...")
        print(f"{'='*70}\n")
        
        clear_data_folders(base_dir)
        print()
        # Database will be recreated when schema is created below
    
    # Setup database
    if not args.skip_db:
        db_path = base_dir / "covenant.db"
        create_database_schema(db_path)
    
    # Generate new contracts
    if args.contracts > 0:
        generate_new_contracts(
            base_dir,
            count=args.contracts,
            labor_ratio=args.labor_ratio,
            seed=args.seed
        )
    
    # Generate change orders for existing contracts
    if args.change_orders > 0:
        generate_change_orders_for_existing(
            base_dir,
            count_per_contract=args.change_orders,
            seed=args.seed
        )
    
    print(f"\n{'='*70}")
    print("✓ Setup Complete!")
    print(f"{'='*70}")
    print(f"\nGenerated files are in: {base_dir / 'pending'}")
    print(f"Run the pipeline to process these documents.\n")


if __name__ == "__main__":
    main()
