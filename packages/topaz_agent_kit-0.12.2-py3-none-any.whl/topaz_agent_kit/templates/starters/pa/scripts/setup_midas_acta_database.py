#!/usr/bin/env python3
"""
Setup script for Midas + Acta mock database.

Creates a small SQLite database with three tables:
- capex_items   (source items + Midas + Acta state; midas/acta/hitl fields left empty for pipelines)
- midas_rules   (capitalization rules)
- journal_entries (created if not exists; populated by Acta pipeline, not by this script)

WBS, WBS Desc, and Description are randomized from pools for variety; all items are inserted
with midas_status='pending' and no midas/acta/hitl values so Midas and Acta pipelines update them.

Usage (from project root):
    python src/topaz_agent_kit/scripts/setup_midas_acta_database.py
    uv run -m src.topaz_agent_kit.scripts.setup_midas_acta_database
"""

from __future__ import annotations

import argparse
import csv
import os
import random
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional
from uuid import uuid4

from topaz_agent_kit.utils.path_resolver import resolve_script_path, detect_project_name


def _utc_iso() -> str:
    """Return current UTC timestamp in ISO format without microseconds."""
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _clean_amount(value: str) -> float:
    """Normalize amount strings like ' 780,000 ' to float 780000.0."""
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip().replace(",", "").replace('"', "").replace(" ", "")
    if not text:
        return 0.0
    try:
        return float(text)
    except ValueError:
        # Fallback: try to keep digits and dot only
        filtered = "".join(ch for ch in text if ch.isdigit() or ch == ".")
        return float(filtered) if filtered else 0.0


# -------------------------------------------------------------------------
# WBS / WBS Desc pools (varied for pipeline mix)
# -------------------------------------------------------------------------

_WBS_CODES: List[str] = [
    "WBS-OFW-2001-01",
    "WBS-OFW-2001-02",
    "WBS-OFW-2001-03",
    "WBS-PPL-4410-01",
    "WBS-PPL-4410-02",
    "WBS-PPL-4410-03",
    "WBS-PPL-4410-04",
    "WBS-HDS-3105-02",
    "WBS-HDS-3105-90",
    "WBS-HDS-3105-15",
    "WBS-REF-2200-01",
    "WBS-REF-2200-02",
    "WBS-MAR-5501-01",
    "WBS-MAR-5501-02",
]

_WBS_DESCRIPTIONS_ALLOWED: List[str] = [
    "Wellhead & Hook-up",
    "Drilling & Completion",
    "Subsea Tie-in",
    "Valve Station VS-12",
    "Pipeline Section P2",
    "Hydrotesting & Commissioning",
    "Equipment Installation",
    "Pre-commissioning",
    "Decommissioning Phase 1",
    "Refinery Unit Revamp",
    "Marine Works – Jetty",
    "Cabling & Instrumentation",
    "Civil & Structural",
]

_WBS_DESCRIPTIONS_NOT_ALLOWED: List[str] = [
    "Shutdown Opex",
    "Maintenance Operations",
    "Repair & Service",
    "Training Facilities",
    "Administrative Support",
]

_WBS_DESCRIPTIONS_HITL: List[str] = [
    "Wellhead & Hook-up",
    "Drilling & Completion",
    "Subsea Tie-in",
    "Shutdown Opex",
    "Pre-commissioning",
    "Maintenance Operations",
]

# -------------------------------------------------------------------------
# Description pools by category (matching Midas rules)
# -------------------------------------------------------------------------

# Allowed: descriptions matching rules with capitalization_allowed=1
# Use ONLY descriptions with keywords that LLM clearly recognizes as capitalizable.
# Based on prompt: Installation / testing / direct project supervision / project management / engineering / temporary construction
# Based on actual pipeline results, these keywords work reliably:
_DESCRIPTIONS_ALLOWED: List[str] = [
    # Installation - proven to work
    "Installation & assembly – subsea Christmas tree",
    "Installation & assembly – equipment setup",
    "Installation & assembly – new equipment",
    "Installation & assembly – pipeline equipment",
    "Compressor installation – HDS unit",
    "Equipment installation – new facility",
    # Testing - proven to work
    "Testing costs – FAT and site acceptance",
    "Testing costs – system validation",
    "Testing costs – equipment validation",
    "Testing costs – factory acceptance testing",
    # Direct supervision / project management - proven to work
    "Direct supervision & project mgmt – OFW Phase 2",
    "Direct supervision – pipeline section P2",
    "Direct supervision – construction oversight",
    "Direct supervision – project construction",
    "Project management consultants – PMC support",
    "Project management consultants – construction oversight",
    # Engineering - proven to work
    "Engineering consultants – FEED study",
    "Engineering consultants – design and engineering",
    # Temporary construction - proven to work
    "Temporary construction facilities – site offices",
    "Temporary construction facilities – project site",
    # Commissioning - proven to work
    "Commissioning contractor – hydrotest and leak test",
]

# Not Allowed: descriptions matching rules with capitalization_allowed=0
# Based on prompt: Maintenance / repairs / scrap / rework / travel / admin overhead
# Based on actual pipeline results, these keywords work reliably:
_DESCRIPTIONS_NOT_ALLOWED: List[str] = [
    # Maintenance & repairs - proven to work
    "Maintenance & repairs – valve station VS-12",
    "Repairs and maintenance – equipment servicing",
    # Travel - proven to work
    "Travel related – site visits and client meetings",
    "Travel expenses – business trips",
    # Admin overhead - proven to work
    "General admin overhead – project support",
    "Legal & admin costs – contract variation",
    # Training - proven to work
    "Operator training – wellhead controls",
    "Operator training – compressor operations",
    "Safety induction – contractor onboarding",
    # Scrap / rework - proven to work
    "Scrap clearing cost – demolition and disposal",
    "Scrap due to rework – mud chemicals batch",
    "Rework costs – weld repairs post NDT",
    # Other operational expenses - proven to work
    "Termination fees – early contract exit",
    "Site Security & guarding – 24/7 coverage Q1",
    "Pre-engineering – feasibility and concept",
]

# HITL: ambiguous/conflicting descriptions or blank
# Use descriptions that create true uncertainty/conflict between signals
# Key: descriptions that could be interpreted either way OR create conflicting signals
_DESCRIPTIONS_HITL: List[str] = [
    "",  # Blank description - always triggers uncertainty
    "Mixed project support – various activities",
    "Borderline case – requires review",
    "Unclear classification – needs assessment",
    "Project support – mixed capex/opex",
    "Support services – classification pending",
    "Operational support – mixed nature",
    "Maintenance work on new installation",  # Conflicting: maintenance (not_allowed) but new installation (allowed)
    "Training for new equipment operation",  # Conflicting: training (not_allowed) but new equipment (allowed)
    "Repair of newly installed equipment",  # Conflicting: repair (not_allowed) but newly installed (allowed)
    "Inspection during construction phase",  # Could be capitalizable inspection or operational
    "Consultant services – project review",  # Ambiguous: consultant could be engineering (allowed) or admin (not_allowed)
    "Equipment services – installation support",  # Ambiguous: services could be operational or capitalizable
]


def _get_wbs_and_description_for_category(category: str) -> Tuple[str, str, str]:
    """Return (wbs, wbs_desc, description) appropriate for the category.
    
    category: 'allowed', 'not_allowed', or 'hitl'
    
    For HITL items, we create conflicting signals by mixing allowed/not_allowed
    WBS descriptions with ambiguous descriptions to trigger uncertainty.
    """
    wbs = random.choice(_WBS_CODES)
    
    if category == "allowed":
        # Use WBS descriptions that reinforce capitalizable work
        wbs_desc = random.choice(_WBS_DESCRIPTIONS_ALLOWED)
        description = random.choice(_DESCRIPTIONS_ALLOWED)
    elif category == "not_allowed":
        # Use WBS descriptions that reinforce operational/expense work
        wbs_desc = random.choice(_WBS_DESCRIPTIONS_NOT_ALLOWED)
        description = random.choice(_DESCRIPTIONS_NOT_ALLOWED)
    else:  # hitl
        # Create conflicting signals: mix WBS from different categories with ambiguous descriptions
        # This creates uncertainty that should trigger HITL
        if random.random() < 0.5:
            # Mix: allowed WBS with ambiguous description
            wbs_desc = random.choice(_WBS_DESCRIPTIONS_ALLOWED)
        else:
            # Mix: not_allowed WBS with ambiguous description
            wbs_desc = random.choice(_WBS_DESCRIPTIONS_NOT_ALLOWED)
        description = random.choice(_DESCRIPTIONS_HITL)
    
    return (wbs, wbs_desc, description)


def create_database_schema(db_path: str) -> None:
    """Create the Midas + Acta database schema (3 tables)."""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # ------------------------------------------------------------------
    # capex_items - source items + Midas + Acta state
    # ------------------------------------------------------------------
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS capex_items (
            item_id TEXT PRIMARY KEY,
            posting_date TEXT NOT NULL,
            company_code TEXT NOT NULL,
            doc_no TEXT NOT NULL,
            doc_item TEXT NOT NULL,
            qty REAL,
            vendor TEXT,
            po TEXT,
            source TEXT,
            wbs TEXT,
            wbs_desc TEXT,
            gl TEXT,
            gl_desc TEXT,
            amount REAL NOT NULL,
            currency TEXT NOT NULL,
            cost_center TEXT,
            profit_center TEXT,
            description TEXT,

            midas_status TEXT NOT NULL DEFAULT 'pending',
            midas_rule_bucket TEXT,
            midas_cap_allowed INTEGER,
            midas_confidence REAL,
            midas_rationale TEXT,

            hitl_required INTEGER NOT NULL DEFAULT 0,
            hitl_status TEXT,
            hitl_case_id TEXT,
            hitl_resolution TEXT,

            acta_required INTEGER NOT NULL DEFAULT 0,
            acta_status TEXT,
            acta_journal_batch_id TEXT,
            acta_error TEXT,

            ingestion_batch_id TEXT,
            source_filename TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )

    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_capex_items_midas_status "
        "ON capex_items(midas_status)"
    )
    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_capex_items_acta_required_status "
        "ON capex_items(acta_required, acta_status)"
    )
    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_capex_items_wbs ON capex_items(wbs)"
    )

    # ------------------------------------------------------------------
    # midas_rules - capitalization rules
    # ------------------------------------------------------------------
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS midas_rules (
            rule_id TEXT PRIMARY KEY,
            expense_type TEXT NOT NULL UNIQUE,
            capitalization_allowed INTEGER NOT NULL,
            notes TEXT,
            created_at TEXT NOT NULL
        )
        """
    )

    # ------------------------------------------------------------------
    # journal_entries - Acta journal postings (created here; populated by Acta pipeline)
    # ------------------------------------------------------------------
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS journal_entries (
            journal_id TEXT PRIMARY KEY,
            batch_id TEXT NOT NULL,
            company_code TEXT NOT NULL,
            document_date TEXT NOT NULL,
            posting_date TEXT NOT NULL,
            line INTEGER NOT NULL,
            posting_key TEXT,
            gl TEXT NOT NULL,
            gl_desc TEXT,
            currency TEXT NOT NULL,
            amount REAL NOT NULL,
            dr_cr TEXT NOT NULL,
            wbs TEXT,
            cost_center TEXT,
            text TEXT,
            item_id TEXT,
            FOREIGN KEY (item_id) REFERENCES capex_items(item_id)
        )
        """
    )

    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_journal_batch_line "
        "ON journal_entries(batch_id, line)"
    )
    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_journal_item ON journal_entries(item_id)"
    )

    conn.commit()
    conn.close()


def seed_midas_rules(conn: sqlite3.Connection) -> None:
    """Insert rules from the Midas rules table (if not already present).

    The rules are embedded here to avoid parsing PDF at runtime.
    """
    rules: List[Tuple[str, int, str]] = [
        ("Repairs and Maintenance", 0, ""),
        ("Travel related expenses", 0, ""),
        ("General admin overhead", 0, ""),
        ("Training costs", 0, ""),
        ("Safety induction", 0, ""),
        ("Pre-engineering", 0, ""),
        ("Maintenance & repairs", 0, ""),
        ("Termination fees", 0, ""),
        ("Site Security & guarding", 0, ""),
        ("Legal & admin costs", 0, ""),
        ("Scrap clearing cost", 0, ""),
        ("Rework costs", 0, ""),
        ("Installation & assembly", 1, ""),
        ("Testing costs", 1, ""),
        ("Direct supervision & project mgmt", 1, ""),
        ("Asset relocation costs", 1, ""),
        ("Major inspections", 1, ""),
        ("Decommissioning provision initial estimate", 1, ""),
        ("Project management consultants cost", 1, ""),
        ("Engineering consultants cot", 1, ""),
        ("Temporary construction facilities", 1, ""),
    ]

    cursor = conn.cursor()
    existing = {
        row[0]
        for row in cursor.execute("SELECT expense_type FROM midas_rules").fetchall()
    }

    now = _utc_iso()
    for expense_type, cap_allowed, notes in rules:
        if expense_type in existing:
            continue
        cursor.execute(
            """
            INSERT INTO midas_rules (
                rule_id, expense_type, capitalization_allowed, notes, created_at
            )
            VALUES (?, ?, ?, ?, ?)
            """,
            (str(uuid4()), expense_type, cap_allowed, notes, now),
        )

    conn.commit()


def load_capex_items_from_csv(
    conn: sqlite3.Connection,
    csv_path: Path,
    ingestion_batch_id: str,
    total_items: int,
    allowed_pct: float = 0.5,
    not_allowed_pct: float = 0.4,
    hitl_pct: float = 0.1,
) -> Tuple[List[str], Dict[str, List[str]]]:
    """Load items from sample_input CSV and return list of new item_ids and category tracking.

    Uses CSV for posting_date, company_code, doc_no, amounts, vendor, GL, etc.
    Creates raw input data with descriptions/WBS that will naturally result in
    the desired distribution when processed by the Midas pipeline:
    - allowed_pct: items with descriptions matching allowed rules (e.g., "Installation & assembly")
    - not_allowed_pct: items with descriptions matching not_allowed rules (e.g., "Maintenance & repairs")
    - hitl_pct: items with ambiguous/conflicting descriptions (or blank) that trigger HITL
    All items start with midas_status='pending' and all midas fields NULL.
    If total_items > number of CSV rows, rows are cycled.
    
    Returns:
        Tuple of (list of item_ids, dict mapping category to list of item_ids)
    """
    cursor = conn.cursor()

    if not csv_path.exists():
        raise FileNotFoundError(f"Capex items CSV not found: {csv_path}")

    with csv_path.open(newline="", encoding="utf-8") as f:
        reader = list(csv.DictReader(f))

    if not reader:
        return []

    # Normalize percentages to ensure they sum to 1.0
    total_pct = allowed_pct + not_allowed_pct + hitl_pct
    if total_pct > 0:
        allowed_pct = allowed_pct / total_pct
        not_allowed_pct = not_allowed_pct / total_pct
        hitl_pct = hitl_pct / total_pct
    else:
        # Default distribution if all are 0
        allowed_pct = 0.5
        not_allowed_pct = 0.4
        hitl_pct = 0.1

    # Create list of categories based on distribution
    categories = []
    allowed_count = max(1, round(total_items * allowed_pct))
    not_allowed_count = max(1, round(total_items * not_allowed_pct))
    hitl_count = max(0, total_items - allowed_count - not_allowed_count)
    
    # Generate category list
    categories.extend(["allowed"] * allowed_count)
    categories.extend(["not_allowed"] * not_allowed_count)
    categories.extend(["hitl"] * hitl_count)
    
    # Shuffle to randomize order
    random.shuffle(categories)

    created_ids: List[str] = []
    category_tracking: Dict[str, List[str]] = {"allowed": [], "not_allowed": [], "hitl": []}
    now = _utc_iso()
    source_filename = os.path.basename(str(csv_path))

    # Cycle through CSV rows until total_items reached
    index = 0
    for category in categories:
        row = reader[index % len(reader)]
        index += 1

        item_id = str(uuid4())
        created_ids.append(item_id)
        category_tracking[category].append(item_id)

        # Get posting_date from CSV, or generate a default date if missing/empty
        posting_date = row.get("Posting Date") or row.get("PostingDate") or ""
        if not posting_date:
            # Generate a random date within the last 90 days if not in CSV
            days_ago = random.randint(0, 90)
            default_date = (datetime.now(timezone.utc) - timedelta(days=days_ago)).date()
            posting_date = default_date.isoformat()
        
        company_code = row.get("Company Code") or ""
        doc_no = row.get("Doc No") or row.get("Document Number") or ""
        doc_item = row.get("Item") or ""
        qty_str = row.get("Qty") or ""
        vendor = row.get("Vendor") or ""
        po = row.get("PO") or ""
        source = row.get("Source") or ""
        gl = row.get("GL") or ""
        gl_desc = row.get("GL Desc") or ""
        amount_str = row.get("Amount") or ""
        currency = row.get("Currency") or ""
        cost_center = row.get("Cost Center") or ""
        profit_center = row.get("Profit Center") or ""

        # Get WBS and description appropriate for the category
        # This ensures the data will naturally result in the desired distribution
        wbs, wbs_desc, description = _get_wbs_and_description_for_category(category)

        qty = _clean_amount(qty_str) if qty_str else None
        amount = _clean_amount(amount_str)

        # All items start as raw input data - no midas fields populated
        # The Midas pipeline will process these and determine the status

        cursor.execute(
            """
            INSERT INTO capex_items (
                item_id,
                posting_date,
                company_code,
                doc_no,
                doc_item,
                qty,
                vendor,
                po,
                source,
                wbs,
                wbs_desc,
                gl,
                gl_desc,
                amount,
                currency,
                cost_center,
                profit_center,
                description,
                midas_status,
                midas_rule_bucket,
                midas_cap_allowed,
                midas_confidence,
                midas_rationale,
                hitl_required,
                hitl_status,
                hitl_case_id,
                hitl_resolution,
                acta_required,
                acta_status,
                acta_journal_batch_id,
                acta_error,
                ingestion_batch_id,
                source_filename,
                created_at,
                updated_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending',
                    NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL,
                    ?, ?, ?, ?)
            """,
            (
                item_id,
                posting_date,
                company_code,
                doc_no,
                doc_item,
                qty,
                vendor,
                po,
                source,
                wbs,
                wbs_desc,
                gl,
                gl_desc,
                amount,
                currency,
                cost_center,
                profit_center,
                description,
                ingestion_batch_id,
                source_filename,
                now,
                now,
            ),
        )

    conn.commit()
    return created_ids, category_tracking


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Setup Midas + Acta SQLite database and mock data"
    )
    parser.add_argument(
        "--db-path",
        default="projects/pa/data/midas_acta/midas_acta.db",
        help="Path to SQLite database file (relative to project root)",
    )
    parser.add_argument(
        "--input-csv",
        default="docs/samples/midas/sample_input.csv",
        help="Path to CapEx items CSV (relative to project root)",
    )
    parser.add_argument(
        "--reset",
        action="store_true",
        default=False,
        help="Reset database (delete existing file before recreating)",
    )
    parser.add_argument(
        "--total-items",
        type=int,
        default=10,
        help="Total number of capex_items to create (default: 10)",
    )
    parser.add_argument(
        "--allowed-pct",
        type=float,
        default=0.5,
        help="Percentage of items to mark as allowed (default: 0.5)",
    )
    parser.add_argument(
        "--not-allowed-pct",
        type=float,
        default=0.4,
        help="Percentage of items to mark as not_allowed (default: 0.4)",
    )
    parser.add_argument(
        "--hitl-pct",
        type=float,
        default=0.1,
        help="Percentage of items to mark as HITL (default: 0.1)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Random seed for reproducibility (default: None = use current time)",
    )

    args = parser.parse_args()

    # Seed RNG
    if args.seed is not None:
        random.seed(args.seed)
    else:
        import time

        random.seed(int(time.time()))

    # Resolve paths relative to project root
    project_name = detect_project_name(Path.cwd())
    db_path = resolve_script_path(args.db_path, project_name=project_name)
    input_csv_path = resolve_script_path(args.input_csv, project_name=project_name)

    if args.reset and db_path.exists():
        db_path.unlink()
        print(f"✓ Removed existing database: {db_path}")

    db_path.parent.mkdir(parents=True, exist_ok=True)

    print("\n" + "=" * 70)
    print("Midas + Acta Database Setup")
    print("=" * 70)
    print(f"\nDatabase: {db_path}")
    print(f"Input CSV: {input_csv_path}")
    print(f"Reset mode: {args.reset}")
    print(f"Total items: {args.total_items}")
    print(f"Random seed: {args.seed}")
    print()

    # Create schema
    print("1. Creating database schema...")
    create_database_schema(str(db_path))

    # Connect
    conn = sqlite3.connect(str(db_path))

    # Seed rules
    print("2. Seeding Midas rules...")
    seed_midas_rules(conn)

    # Load capex items with input data designed to result in desired distribution
    print("3. Loading capex_items from CSV with input data distribution...")
    print(f"   Target distribution: {args.allowed_pct*100:.0f}% allowed, {args.not_allowed_pct*100:.0f}% not_allowed, {args.hitl_pct*100:.0f}% HITL")
    ingestion_batch_id = f"batch-{_utc_iso()}"
    item_ids, category_tracking = load_capex_items_from_csv(
        conn=conn,
        csv_path=input_csv_path,
        ingestion_batch_id=ingestion_batch_id,
        total_items=args.total_items,
        allowed_pct=args.allowed_pct,
        not_allowed_pct=args.not_allowed_pct,
        hitl_pct=args.hitl_pct,
    )
    print(f"   → Created {len(item_ids)} items in ingestion batch {ingestion_batch_id}")
    
    # Generate detailed report
    print("\n" + "=" * 70)
    print("GENERATION REPORT")
    print("=" * 70)
    
    cursor = conn.cursor()
    
    # Report by category
    print("\n📊 Items Created by Category:")
    print("-" * 70)
    for category in ["allowed", "not_allowed", "hitl"]:
        count = len(category_tracking[category])
        pct = (count / len(item_ids) * 100) if item_ids else 0
        print(f"  {category.upper():15s}: {count:3d} items ({pct:5.1f}%)")
    
    # Sample descriptions for each category
    print("\n📝 Sample Descriptions by Category:")
    print("-" * 70)
    for category in ["allowed", "not_allowed", "hitl"]:
        if category_tracking[category]:
            # Get sample items from this category
            sample_ids = category_tracking[category][:3]  # Get up to 3 samples
            placeholders = ",".join("?" * len(sample_ids))
            samples = cursor.execute(
                f"""
                SELECT description, wbs_desc 
                FROM capex_items 
                WHERE item_id IN ({placeholders})
                LIMIT 3
                """,
                sample_ids
            ).fetchall()
            
            print(f"\n  {category.upper().replace('_', ' ')} ({len(category_tracking[category])} items):")
            for desc, wbs_desc in samples:
                if desc:
                    print(f"    • {desc[:60]}")
                    if len(desc) > 60:
                        print(f"      (WBS: {wbs_desc})")
                else:
                    print(f"    • [BLANK DESCRIPTION] (WBS: {wbs_desc})")
    
    # Expected outcomes
    print("\n🎯 Expected Outcomes When Midas Pipeline Runs:")
    print("-" * 70)
    print("  ALLOWED items:")
    print("    → Will match rules like 'Installation & assembly', 'Testing costs',")
    print("      'Direct supervision & project mgmt', etc.")
    print("    → Expected result: midas_status='completed', midas_cap_allowed=1")
    print("    → Will NOT require HITL")
    print("    → Will NOT require Acta (capitalization allowed)")
    
    print("\n  NOT ALLOWED items:")
    print("    → Will match rules like 'Maintenance & repairs', 'Travel related',")
    print("      'General admin overhead', 'Training costs', etc.")
    print("    → Expected result: midas_status='completed', midas_cap_allowed=0")
    print("    → Will NOT require HITL")
    print("    → WILL require Acta (operating expense journal entry)")
    
    print("\n  HITL items:")
    print("    → Have ambiguous/conflicting descriptions or blank descriptions")
    print("    → Expected result: midas_status='hitl_pending', hitl_required=1")
    print("    → Will be sent to HITL for human review")
    print("    → After HITL decision, will follow allowed/not_allowed path")
    
    # Next steps
    print("\n🚀 Next Steps:")
    print("-" * 70)
    print("  1. All items are created with midas_status='pending' (raw input data)")
    print("  2. Run the Midas pipeline to process these items:")
    print("     → Items will be assessed and categorized as allowed/not_allowed/HITL")
    print("  3. Review HITL cases in the UI and make decisions")
    print("  4. Run the Acta pipeline to create journal entries for not_allowed items")
    
    print("\n" + "=" * 70)

    conn.close()
    print("\nSetup complete.")


if __name__ == "__main__":
    main()

