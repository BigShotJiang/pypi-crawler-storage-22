"""
Midas + Acta - Pipeline-specific local tools.

This toolkit is intentionally opinionated and schema-aware for the shared
SQLite database created by:
  src/topaz_agent_kit/scripts/setup_midas_acta_database.py

Goals:
- Agents should NOT directly use sqlite_query/sqlite_execute or python_execute.
- All DB reads/writes for Midas + Acta should go through these tools.
"""

from __future__ import annotations

import os
import sqlite3
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from topaz_agent_kit.local_tools.registry import pipeline_tool
from topaz_agent_kit.utils.logger import Logger

_logger = Logger("MidasActaTools")


def _validate_db_file(db_file: str) -> None:
    """Validate database file path."""
    if not db_file:
        raise ValueError("db_file is required")
    if not os.path.exists(db_file):
        raise FileNotFoundError(f"Database file not found: {db_file}")
    if not os.path.isfile(db_file):
        raise ValueError(f"db_file is not a file: {db_file}")


def _connect(db_file: str) -> sqlite3.Connection:
    """Connect to SQLite database with row factory."""
    _validate_db_file(db_file)
    conn = sqlite3.connect(db_file)
    conn.row_factory = sqlite3.Row
    return conn


def _utc_iso() -> str:
    """Get current UTC timestamp in ISO format."""
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


# ---------------------------------------------------------------------------
# Midas: read pending items
# ---------------------------------------------------------------------------


@pipeline_tool(toolkit="midas_acta", name="get_pending_capex_items_for_midas")
def get_pending_capex_items_for_midas(
    db_file: str,
    limit: int = 100,
) -> Dict[str, Any]:
    """Return capex_items that are ready for Midas assessment.

    **Requirements:**
    - db_file must be a relative path to the Midas/Acta database file (relative to project_dir)
    - limit controls the maximum number of items to return (default: 100)
    
    **Selection criteria:**
    - midas_status = 'pending'
    - acta_status IS NULL (not yet routed to Acta)
    
    **Returns items ordered by:**
    - posting_date (ascending)
    - doc_no (ascending)
    - doc_item (ascending)
    
    **Example call:**
    get_pending_capex_items_for_midas(
        db_file="data/midas_acta/midas_acta.db",
        limit=100
    )
    
    Args:
        db_file: Relative path to the Midas/Acta database file (relative to project_dir, REQUIRED: use actual database path from inputs)
        limit: Maximum number of items to return (default: 100)
    
    Returns:
        Dictionary with:
        - capex_items: List of capex item dictionaries, each containing:
            - item_id: Item identifier
            - posting_date: Posting date
            - company_code: Company code
            - doc_no: Document number
            - doc_item: Document item number
            - qty: Quantity
            - vendor: Vendor name
            - po: Purchase order number
            - source: Source system
            - wbs: WBS code
            - wbs_desc: WBS description
            - gl: GL account code
            - gl_desc: GL account description
            - amount: Item amount
            - currency: Currency code
            - cost_center: Cost center
            - profit_center: Profit center
            - description: Item description
            - midas_status: Midas status ("pending")
            - acta_required: Whether Acta is required (0 or 1)
            - acta_status: Acta status (NULL for pending items)
        - count: Total count of pending items (before LIMIT)
        - error: Error message if any
    """
    try:
        conn = _connect(db_file)
        cursor = conn.cursor()

        # First, get the total count of pending items (before LIMIT)
        cursor.execute(
            """
            SELECT COUNT(*) as total_count
            FROM capex_items
            WHERE midas_status = 'pending'
              AND acta_status IS NULL
            """,
        )
        total_count_result = cursor.fetchone()
        total_count = total_count_result["total_count"] if total_count_result else 0
        
        _logger.info(
            "get_pending_capex_items_for_midas: total_pending={}, requested_limit={}",
            total_count, limit
        )

        # Then, get the items (with LIMIT)
        # Only select columns needed for scanner output (pending items don't have Midas/Acta/HITL results yet)
        cursor.execute(
            """
            SELECT
                item_id,
                posting_date,
                company_code,
                doc_no,
                doc_item,
                qty,
                vendor,
                po,
                source,
                wbs,
                wbs_desc,
                gl,
                gl_desc,
                amount,
                currency,
                cost_center,
                profit_center,
                description,
                midas_status,
                acta_required,
                acta_status
            FROM capex_items
            WHERE midas_status = 'pending'
              AND acta_status IS NULL
            ORDER BY posting_date, doc_no, doc_item
            LIMIT ?
            """,
            (limit,),
        )

        items: List[Dict[str, Any]] = []
        for row in cursor.fetchall():
            items.append({k: row[k] for k in row.keys()})

        conn.close()
        
        _logger.info(
            "get_pending_capex_items_for_midas: returned {} items (total_pending={}, limit={})",
            len(items), total_count, limit
        )

        return {
            "capex_items": items,
            "count": total_count,  # Total count of pending items (before LIMIT)
            "error": "",
        }
    except Exception as exc:  # pragma: no cover - defensive
        _logger.error("Error getting pending capex_items for Midas: {}", exc)
        return {
            "capex_items": [],
            "count": 0,
            "error": str(exc),
        }


# ---------------------------------------------------------------------------
# Midas: write automated assessor decision
# ---------------------------------------------------------------------------


@pipeline_tool(toolkit="midas_acta", name="record_midas_assessor_decision")
def record_midas_assessor_decision(
    db_file: str,
    item_id: str,
    decision: str,
    rationale: str,
    expense_type: Optional[str] = None,
    confidence: Optional[float] = None,
) -> Dict[str, Any]:
    """Record Midas assessor decision for an item (before HITL).

    **CRITICAL REQUIREMENTS:**
    - db_file must be a relative path to the Midas/Acta database file (relative to project_dir)
    - decision must be one of: "allowed", "not_allowed", "uncertain"
    - item_id must exist in capex_items table
    
    **Decision rules:**
    - **allowed:**
        - midas_cap_allowed = 1
        - midas_status = 'completed'
        - acta_required = 0
        - acta_status = NULL
        - Item is approved for capitalization, no Acta posting needed
    - **not_allowed:**
        - midas_cap_allowed = 0
        - midas_status = 'completed'
        - acta_required = 1
        - acta_status = 'queued'
        - Item is NOT approved for capitalization, routed to Acta for reclassification
    - **uncertain:**
        - midas_cap_allowed = NULL
        - midas_status = 'hitl_pending'
        - hitl_required = 1
        - hitl_status = 'queued'
        - Item requires human review, Acta intent will be decided after HITL
    
    **Example call:**
    record_midas_assessor_decision(
        db_file="data/midas_acta/midas_acta.db",
        item_id="ITEM-001",
        decision="not_allowed",
        rationale="Item is maintenance expense, not capital expenditure",
        expense_type="maintenance",
        confidence=0.95
    )
    
    Args:
        db_file: Relative path to the Midas/Acta database file (relative to project_dir, REQUIRED: use actual database path from inputs)
        item_id: Capex item identifier (e.g., "ITEM-001")
        decision: Decision value - must be "allowed", "not_allowed", or "uncertain"
        rationale: Human-readable rationale for the decision
        expense_type: Expense type/rule bucket (e.g., "maintenance", "repairs") (optional)
        confidence: Confidence score (0.0 to 1.0) (optional)
    
    Returns:
        Dictionary with:
        - records_updated: Number of records updated (should be 1)
        - error: Error message if update failed
    """
    conn: Optional[sqlite3.Connection] = None
    try:
        decision_normalized = (decision or "").strip().lower()
        if decision_normalized not in {"allowed", "not_allowed", "uncertain"}:
            raise ValueError(
                f"Invalid decision '{decision}'. Expected 'allowed', 'not_allowed', or 'uncertain'."
            )

        conn = _connect(db_file)
        cursor = conn.cursor()
        now = _utc_iso()

        # Base fields
        fields: Dict[str, Any] = {
            "midas_rule_bucket": expense_type,
            "midas_confidence": confidence,
            "midas_rationale": rationale,
            "updated_at": now,
        }

        if decision_normalized == "allowed":
            fields.update(
                {
                    "midas_cap_allowed": 1,
                    "midas_status": "completed",
                    "hitl_required": 0,
                    "hitl_status": None,
                    "acta_required": 0,
                    "acta_status": None,
                }
            )
        elif decision_normalized == "not_allowed":
            fields.update(
                {
                    "midas_cap_allowed": 0,
                    "midas_status": "completed",
                    "hitl_required": 0,
                    "hitl_status": None,
                    "acta_required": 1,
                    "acta_status": "queued",
                }
            )
        else:  # uncertain
            fields.update(
                {
                    "midas_cap_allowed": None,
                    "midas_status": "hitl_pending",
                    "hitl_required": 1,
                    "hitl_status": "queued",
                    # Acta intent will be finalized after HITL
                }
            )

        set_clause = ", ".join(f"{col} = ?" for col in fields.keys())
        params = list(fields.values()) + [item_id]

        cursor.execute(
            f"""
            UPDATE capex_items
            SET {set_clause}
            WHERE item_id = ?
            """,
            params,
        )
        updated = cursor.rowcount
        conn.commit()
        conn.close()

        return {
            "records_updated": int(updated),
            "error": "",
        }
    except Exception as exc:  # pragma: no cover - defensive
        _logger.error("Error recording Midas assessor decision: {}", exc)
        if conn is not None:
            conn.rollback()
            conn.close()
        return {
            "records_updated": 0,
            "error": str(exc),
        }


# ---------------------------------------------------------------------------
# Midas: apply HITL decision
# ---------------------------------------------------------------------------


@pipeline_tool(toolkit="midas_acta", name="apply_midas_hitl_decision")
def apply_midas_hitl_decision(
    db_file: str,
    item_id: str,
    final_decision: str,
    final_rationale: str,
    expense_type: Optional[str] = None,
) -> Dict[str, Any]:
    """Apply final human decision from HITL back into capex_items.

    **CRITICAL REQUIREMENTS:**
    - db_file must be a relative path to the Midas/Acta database file (relative to project_dir)
    - final_decision must be one of: "allowed", "not_allowed"
    - item_id must exist in capex_items table with hitl_status='queued'
    
    **This tool is called after HITL to apply the human decision:**
    - Updates midas_status to 'completed'
    - Sets hitl_status to 'resolved'
    - Sets hitl_required to 0
    - Based on final_decision, sets midas_cap_allowed and routes to Acta if needed
    
    **Decision rules:**
    - **allowed:**
        - midas_cap_allowed = 1
        - acta_required = 0
        - acta_status = NULL
        - Item is approved for capitalization
    - **not_allowed:**
        - midas_cap_allowed = 0
        - acta_required = 1
        - acta_status = 'queued'
        - Item is NOT approved, routed to Acta for reclassification
    
    **Example call:**
    apply_midas_hitl_decision(
        db_file="data/midas_acta/midas_acta.db",
        item_id="ITEM-001",
        final_decision="not_allowed",
        final_rationale="Human review confirms this is maintenance expense",
        expense_type="maintenance"
    )
    
    Args:
        db_file: Relative path to the Midas/Acta database file (relative to project_dir, REQUIRED: use actual database path from inputs)
        item_id: Capex item identifier (e.g., "ITEM-001")
        final_decision: Final human decision - must be "allowed" or "not_allowed"
        final_rationale: Human-readable rationale for the final decision
        expense_type: Expense type/rule bucket (e.g., "maintenance", "repairs") (optional)
    
    Returns:
        Dictionary with:
        - records_updated: Number of records updated (should be 1)
        - error: Error message if update failed
    """
    conn: Optional[sqlite3.Connection] = None
    try:
        decision_normalized = (final_decision or "").strip().lower()
        if decision_normalized not in {"allowed", "not_allowed"}:
            raise ValueError(
                f"Invalid final_decision '{final_decision}'. Expected 'allowed' or 'not_allowed'."
            )

        conn = _connect(db_file)
        cursor = conn.cursor()
        now = _utc_iso()

        fields: Dict[str, Any] = {
            "midas_rule_bucket": expense_type,
            "midas_rationale": final_rationale,
            "hitl_status": "resolved",
            "hitl_required": 0,
            "midas_status": "completed",
            "updated_at": now,
        }

        if decision_normalized == "allowed":
            fields.update(
                {
                    "midas_cap_allowed": 1,
                    "acta_required": 0,
                    "acta_status": None,
                }
            )
        else:
            fields.update(
                {
                    "midas_cap_allowed": 0,
                    "acta_required": 1,
                    "acta_status": "queued",
                }
            )

        set_clause = ", ".join(f"{col} = ?" for col in fields.keys())
        params = list(fields.values()) + [item_id]

        cursor.execute(
            f"""
            UPDATE capex_items
            SET {set_clause}
            WHERE item_id = ?
            """,
            params,
        )
        updated = cursor.rowcount
        conn.commit()
        conn.close()

        return {
            "records_updated": int(updated),
            "error": "",
        }
    except Exception as exc:  # pragma: no cover - defensive
        _logger.error("Error applying Midas HITL decision: {}", exc)
        if conn is not None:
            conn.rollback()
            conn.close()
        return {
            "records_updated": 0,
            "error": str(exc),
        }


# ---------------------------------------------------------------------------
# Acta: read queued items
# ---------------------------------------------------------------------------


@pipeline_tool(toolkit="midas_acta", name="get_items_for_acta")
def get_items_for_acta(
    db_file: str,
    limit: int = 100,
) -> Dict[str, Any]:
    """Return items that are queued for Acta posting.

    Selection criteria:
    - acta_required = 1
    - acta_status = 'queued'
    """
    try:
        conn = _connect(db_file)
        cursor = conn.cursor()

        # First, get the total count of queued items (before LIMIT)
        cursor.execute(
            """
            SELECT COUNT(*) as total_count
            FROM capex_items
            WHERE acta_required = 1
              AND acta_status = 'queued'
            """,
        )
        total_count_result = cursor.fetchone()
        total_count = total_count_result["total_count"] if total_count_result else 0
        
        _logger.info(
            "get_items_for_acta: total_queued={}, requested_limit={}",
            total_count, limit
        )

        # Then, get the items (with LIMIT)
        # Include Midas assessment results (confidence, rationale, decision) since
        # Acta processes items that have already been assessed by Midas
        cursor.execute(
            """
            SELECT
                item_id,
                posting_date,
                company_code,
                doc_no,
                doc_item,
                qty,
                vendor,
                po,
                source,
                wbs,
                wbs_desc,
                gl,
                gl_desc,
                amount,
                currency,
                cost_center,
                profit_center,
                description,
                midas_status,
                midas_rule_bucket,
                midas_cap_allowed,
                midas_confidence,
                midas_rationale,
                acta_required,
                acta_status
            FROM capex_items
            WHERE acta_required = 1
              AND acta_status = 'queued'
            ORDER BY posting_date, doc_no, doc_item
            LIMIT ?
            """,
            (limit,),
        )

        items: List[Dict[str, Any]] = []
        for row in cursor.fetchall():
            items.append({k: row[k] for k in row.keys()})

        conn.close()
        
        _logger.info(
            "get_items_for_acta: returned {} items (total_queued={}, limit={})",
            len(items), total_count, limit
        )

        return {
            "capex_items": items,
            "count": total_count,  # Total count of queued items (before LIMIT)
            "error": "",
        }
    except Exception as exc:  # pragma: no cover - defensive
        _logger.error("Error getting items for Acta: {}", exc)
        return {
            "capex_items": [],
            "count": 0,
            "error": str(exc),
        }


# ---------------------------------------------------------------------------
# Acta: post 2-line journal entry
# ---------------------------------------------------------------------------


@pipeline_tool(toolkit="midas_acta", name="post_acta_journal_for_item")
def post_acta_journal_for_item(
    db_file: str,
    item_id: str,
    debit_gl: str = "158000",
    credit_gl: str = "610520",
    batch_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Create a 2-line journal entry for a not-allowed capex item and mark it posted.

    **CRITICAL REQUIREMENTS:**
    - db_file must be a relative path to the Midas/Acta database file (relative to project_dir)
    - item_id must exist in capex_items table with acta_status='queued'
    - Item must have acta_required=1 (not-allowed items)
    
    **Journal entry pattern:**
    - Debit: 158000 (default, can be overridden with debit_gl parameter)
    - Credit: 610520 (default, can be overridden with credit_gl parameter)
    
    **This tool:**
    1. Creates a 2-line journal entry (debit and credit)
    2. Links journal entries to the capex item via item_id
    3. Updates capex_items.acta_status to 'posted'
    4. Sets acta_journal_batch_id on the capex item
    
    **Example call:**
    post_acta_journal_for_item(
        db_file="data/midas_acta/midas_acta.db",
        item_id="ITEM-001",
        debit_gl="158000",
        credit_gl="610520",
        batch_id="acta-batch-2025-01-15"  # Optional, auto-generated if not provided
    )
    
    Args:
        db_file: Relative path to the Midas/Acta database file (relative to project_dir, REQUIRED: use actual database path from inputs)
        item_id: Capex item identifier (e.g., "ITEM-001")
        debit_gl: Debit GL account code (default: "158000")
        credit_gl: Credit GL account code (default: "610520")
        batch_id: Journal batch ID (optional, auto-generated if not provided)
    
    Returns:
        Dictionary with:
        - status: "success" or "error"
        - batch_id: Journal batch ID used
        - lines_inserted: Number of journal lines inserted (should be 2)
        - error: Error message if posting failed
    """
    conn: Optional[sqlite3.Connection] = None
    try:
        conn = _connect(db_file)
        cursor = conn.cursor()
        now = _utc_iso()

        # Load item
        cursor.execute(
            """
            SELECT
                item_id,
                posting_date,
                company_code,
                amount,
                currency,
                wbs,
                cost_center,
                description
            FROM capex_items
            WHERE item_id = ?
            """,
            (item_id,),
        )
        row = cursor.fetchone()
        if not row:
            conn.close()
            return {
                "status": "error",
                "error": f"capex_items row not found for item_id={item_id}",
            }

        amount = float(row["amount"])
        company_code = row["company_code"]
        posting_date = row["posting_date"]
        currency = row["currency"]
        wbs = row["wbs"]
        cost_center = row["cost_center"]
        text = row["description"] or "Reclassification of capex to opex"

        if not batch_id:
            batch_id = f"acta-batch-{now}"

        # Determine next line numbers within batch
        cursor.execute(
            """
            SELECT COALESCE(MAX(line), 0) as max_line
            FROM journal_entries
            WHERE batch_id = ?
            """,
            (batch_id,),
        )
        max_line_row = cursor.fetchone()
        next_line = int(max_line_row["max_line"] or 0) + 1

        # Insert debit line
        cursor.execute(
            """
            INSERT INTO journal_entries (
                journal_id,
                batch_id,
                company_code,
                document_date,
                posting_date,
                line,
                posting_key,
                gl,
                gl_desc,
                currency,
                amount,
                dr_cr,
                wbs,
                cost_center,
                text,
                item_id
            )
            VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
            )
            """,
            (
                f"{batch_id}-L{next_line}",
                batch_id,
                company_code,
                posting_date,
                posting_date,
                next_line,
                "40",  # debit
                debit_gl,
                None,
                currency,
                amount,
                "DR",
                wbs,
                cost_center,
                text,
                item_id,
            ),
        )

        # Insert credit line
        cursor.execute(
            """
            INSERT INTO journal_entries (
                journal_id,
                batch_id,
                company_code,
                document_date,
                posting_date,
                line,
                posting_key,
                gl,
                gl_desc,
                currency,
                amount,
                dr_cr,
                wbs,
                cost_center,
                text,
                item_id
            )
            VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
            )
            """,
            (
                f"{batch_id}-L{next_line + 1}",
                batch_id,
                company_code,
                posting_date,
                posting_date,
                next_line + 1,
                "50",  # credit
                credit_gl,
                None,
                currency,
                amount,
                "CR",
                wbs,
                cost_center,
                text,
                item_id,
            ),
        )

        # Update capex_items Acta state
        cursor.execute(
            """
            UPDATE capex_items
            SET acta_status = 'posted',
                acta_journal_batch_id = ?,
                acta_error = NULL,
                updated_at = ?
            WHERE item_id = ?
            """,
            (batch_id, now, item_id),
        )

        conn.commit()
        conn.close()

        return {
            "status": "success",
            "batch_id": batch_id,
            "lines_inserted": 2,
            "error": "",
        }
    except Exception as exc:  # pragma: no cover - defensive
        _logger.error("Error posting Acta journal for item {}: {}", item_id, exc)
        if conn is not None:
            conn.rollback()
            conn.close()
        return {
            "status": "error",
            "batch_id": batch_id,
            "lines_inserted": 0,
            "error": str(exc),
        }

