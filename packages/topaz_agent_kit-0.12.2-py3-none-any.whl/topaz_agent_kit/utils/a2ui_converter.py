"""
A2UI to Canvas Structure Converter

Converts A2UI protocol specifications to Topaz Agent Kit canvas structure format.
This enables agents to generate UI using the A2UI protocol, which is then
converted to our internal canvas structure format.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional
import json
from topaz_agent_kit.utils.logger import Logger

# Import A2UI pydantic models (required dependency)
from a2ui_pydantic import SurfaceUpdate, Component

# Shared mapping of A2UI component types to Topaz widget types
# This is used by both canvas structure conversion and chat widget conversion
A2UI_COMPONENT_TO_WIDGET_MAP: Dict[str, str] = {
    "Text": "text",
    "TextField": "text",
    "TextInput": "text",  # Alias for TextField
    "TextArea": "textarea",
    "Number": "number",
    "Email": "email",
    "Url": "url",
    "Password": "password",
    "CheckBox": "checkbox",
    "ChoicePicker": "select",
    "Select": "select",  # Alias for ChoicePicker
    "Button": "button",  # Will need ButtonWidget
    "Image": "image_viewer",
    "Video": "video_viewer",
    "AudioPlayer": "audio_viewer",
    "Map": "map",
    "Table": "table_view",
    "List": "list_view",
    "Markdown": "markdown_viewer",
    "MarkdownEditor": "markdown_editor",  # Markdown editor widget
    "Code": "code_viewer",
    "Json": "json_viewer",
    "TagsInput": "tags_input",  # Tags input widget
}


class A2UIConverter:
    """Converts A2UI protocol specifications to Topaz canvas structure"""
    
    def __init__(self):
        self.logger = Logger("A2UIConverter")
    
    def a2ui_to_canvas_structure(
        self,
        a2ui_spec: Dict[str, Any],
        surface_id: str = "main"
    ) -> Dict[str, Any]:
        """
        Convert A2UI specification to canvas structure format.
        
        Args:
            a2ui_spec: A2UI specification (SurfaceUpdate or updateComponents message)
            surface_id: Surface ID (default: "main")
            
        Returns:
            Canvas structure dictionary compatible with our format
        """
        try:
            # Log incoming A2UI spec
            self.logger.info("A2UI to Canvas Conversion - Input A2UI spec keys: {}", list(a2ui_spec.keys()))
            if "updateComponents" in a2ui_spec:
                self.logger.debug("A2UI spec has 'updateComponents' wrapper")
                update_msg = a2ui_spec["updateComponents"]
                components = update_msg.get("components", [])
                self.logger.info("A2UI Conversion - Found {} components in updateComponents", len(components))
            elif "components" in a2ui_spec:
                # Direct components array
                self.logger.debug("A2UI spec has direct 'components' array")
                components = a2ui_spec["components"]
                self.logger.info("A2UI Conversion - Found {} components in direct components array", len(components))
            else:
                # Try to parse as SurfaceUpdate
                self.logger.debug("A2UI spec - trying to parse as SurfaceUpdate")
                try:
                    surface_update = SurfaceUpdate(**a2ui_spec)
                    components = surface_update.components if hasattr(surface_update, 'components') else []
                    self.logger.info("A2UI Conversion - Parsed as SurfaceUpdate, found {} components", len(components))
                except Exception as e:
                    self.logger.warning("A2UI Conversion - Failed to parse as SurfaceUpdate: {}", e)
                    components = []
            
            # Log component details
            if components:
                self.logger.info("A2UI Conversion - Component IDs: {}", [comp.get("id") or comp.get("componentId", f"unnamed_{i}") for i, comp in enumerate(components)])
                for i, comp in enumerate(components):
                    comp_id = comp.get("id") or comp.get("componentId", f"unnamed_{i}")
                    comp_type = comp.get("component", "unknown")
                    self.logger.debug("A2UI Component {}: id={}, type={}, keys={}", i, comp_id, comp_type, list(comp.keys()))
            else:
                self.logger.warning("A2UI Conversion - No components found in spec")
            
            # Convert components to canvas structure
            sections = {}
            order = []
            
            # Find root component
            root_component = None
            component_map = {}
            
            for comp in components:
                comp_id = comp.get("id") or comp.get("componentId", "")
                component_map[comp_id] = comp
                if comp_id == "root":
                    root_component = comp
            
            if not root_component:
                self.logger.warning("No root component found in A2UI spec")
                # Use first component as root if available
                if components:
                    root_component = components[0]
                    root_component["id"] = "root"
                    self.logger.info("A2UI Conversion - Using first component as root: {}", root_component.get("component", "unknown"))
            
            if root_component:
                # Convert root component to a section
                self.logger.info("A2UI Conversion - Converting root component to section '{}'", surface_id)
                section = self._component_to_section(
                    root_component,
                    component_map,
                    surface_id
                )
                sections[surface_id] = section
                order.append({"id": surface_id, "type": "section"})
                
                # Log converted section structure
                self.logger.info("A2UI Conversion - Created section '{}' with {} controls and {} sub-sections", 
                               surface_id, 
                               len(section.get("controls", [])), 
                               len(section.get("sections", [])))
                if section.get("controls"):
                    for idx, control in enumerate(section.get("controls", [])):
                        self.logger.debug("A2UI Conversion - Control {}: id={}, widget={}, binding={}", 
                                         idx, 
                                         control.get("id", "unknown"),
                                         control.get("widget", "unknown"),
                                         control.get("binding", "none"))
            else:
                self.logger.warning("A2UI Conversion - No root component available, returning empty structure")
            
            result = {
                "sections": sections,
                "order": order,
                "metadata": {
                    "last_updated_by": "agent",
                    "last_updated_at": self._get_timestamp(),
                    "version": 1,
                }
            }
            
            self.logger.info("A2UI Conversion - Final canvas structure: {} sections, order length: {}", 
                           len(sections), len(order))
            self.logger.debug("A2UI Conversion - Final structure: {}", json.dumps(result, default=str, indent=2))
            
            return result
        except Exception as e:
            self.logger.error("Error converting A2UI to canvas structure: {}", e)
            raise
    
    def _component_to_section(
        self,
        component: Dict[str, Any],
        component_map: Dict[str, Any],
        section_id: str
    ) -> Dict[str, Any]:
        """Convert an A2UI component to a canvas section"""
        comp_type = component.get("component", "")
        children_ids = component.get("children", [])
        
        self.logger.debug("A2UI Conversion - Converting component to section: id={}, type={}, children={}", 
                         section_id, comp_type, children_ids)
        
        # Handle different component types
        if comp_type in ["Column", "Row", "Stack"]:
            # Layout component - convert to section
            controls = []
            sub_sections = []
            
            self.logger.debug("A2UI Conversion - Processing {} children for layout component '{}'", len(children_ids), comp_type)
            
            for child_id in children_ids:
                child_comp = component_map.get(child_id)
                if child_comp:
                    child_type = child_comp.get("component", "")
                    
                    if child_type in ["Column", "Row", "Stack", "Card"]:
                        # Nested section
                        self.logger.debug("A2UI Conversion - Child '{}' is nested section (type: {})", child_id, child_type)
                        sub_section = self._component_to_section(
                            child_comp,
                            component_map,
                            f"{section_id}_{child_id}"
                        )
                        sub_sections.append(sub_section)
                    else:
                        # Control/widget
                        self.logger.debug("A2UI Conversion - Child '{}' is control/widget (type: {})", child_id, child_type)
                        control = self._component_to_control(child_comp, component_map)
                        if control:
                            controls.append(control)
                            self.logger.debug("A2UI Conversion - Added control: id={}, widget={}", 
                                           control.get("id"), control.get("widget"))
                        else:
                            self.logger.warning("A2UI Conversion - Failed to convert child '{}' to control", child_id)
                else:
                    self.logger.warning("A2UI Conversion - Child component '{}' not found in component_map", child_id)
            
            result = {
                "id": section_id,
                "title": component.get("title", ""),
                "source": "agent",
                "controls": controls,
                "sections": sub_sections,
                "layout": self._get_layout_from_component(comp_type, component),
            }
            
            self.logger.debug("A2UI Conversion - Created section '{}': {} controls, {} sub-sections", 
                             section_id, len(controls), len(sub_sections))
            
            return result
        elif comp_type == "Card":
            # Card component - convert to section
            child_id = component.get("child") or (children_ids[0] if children_ids else None)
            if child_id:
                child_comp = component_map.get(child_id)
                if child_comp:
                    return self._component_to_section(
                        child_comp,
                        component_map,
                        section_id
                    )
            
            return {
                "id": section_id,
                "title": component.get("title", ""),
                "source": "agent",
                "controls": [],
                "sections": [],
            }
        else:
            # Single widget - create section with one control
            control = self._component_to_control(component, component_map)
            return {
                "id": section_id,
                "title": "",
                "source": "agent",
                "controls": [control] if control else [],
                "sections": [],
            }
    
    def _component_to_control(
        self,
        component: Dict[str, Any],
        component_map: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """Convert an A2UI component to a canvas control"""
        comp_type = component.get("component", "")
        comp_id = component.get("id", "")
        
        self.logger.debug("A2UI Conversion - Converting component: id={}, type={}", comp_id, comp_type)
        
        # Map A2UI component types to our widget types (using shared mapping)
        widget_type = A2UI_COMPONENT_TO_WIDGET_MAP.get(comp_type)
        if not widget_type:
            self.logger.warning("Unknown A2UI component type: {} (component id: {})", comp_type, comp_id)
            return None
        
        self.logger.debug("A2UI Conversion - Mapped component type '{}' to widget type '{}'", comp_type, widget_type)
        
        # Extract binding from value/path
        binding = None
        value_prop = component.get("value") or component.get("text") or component.get("url")
        if isinstance(value_prop, dict) and "path" in value_prop:
            binding = value_prop["path"]
        elif isinstance(value_prop, str) and value_prop.startswith("/"):
            binding = value_prop
        
        control = {
            "id": comp_id,
            "widget": widget_type,
            "binding": binding,
            "label": component.get("label", ""),
            "placeholder": component.get("placeholder", ""),
        }
        
        # Add widget-specific properties
        if comp_type == "TextField":
            control["widgetProps"] = {
                "variant": component.get("variant", "shortText"),
            }
        elif comp_type == "ChoicePicker":
            control["widgetProps"] = {
                "options": component.get("options", []),
                "multiple": component.get("variant") != "mutuallyExclusive",
            }
        
        return control
    
    def _get_layout_from_component(
        self,
        comp_type: str,
        component: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Extract layout configuration from A2UI component"""
        if comp_type == "Row":
            return {
                "type": "flex",
                "direction": "row",
                "gap": component.get("gap", 4),
                "justifyContent": component.get("justify", "start"),
                "alignItems": component.get("align", "center"),
            }
        elif comp_type == "Column":
            return {
                "type": "stack",
                "gap": component.get("gap", 4),
            }
        elif comp_type == "Stack":
            return {
                "type": "stack",
                "gap": component.get("gap", 4),
            }
        else:
            return {
                "type": "stack",
                "gap": 4,
            }
    
    def _get_timestamp(self) -> str:
        """Get current timestamp in ISO format"""
        return datetime.now().isoformat()
