"""
Utility functions for resolving assistant configuration from ui_manifest.yml

Provides hierarchical resolution of assistant names, subtitles, placeholders, and greetings
with support for defaults, type-specific overrides, and per-app overrides.
"""

from typing import Dict, Optional, Any
from pathlib import Path
import yaml
from topaz_agent_kit.utils.logger import Logger


def get_assistant_config(
    ui_manifest: Dict[str, Any],
    assistant_type: str,
    app_id: Optional[str] = None,
) -> Dict[str, str]:
    """
    Resolve assistant configuration from ui_manifest with fallback hierarchy.
    
    Hierarchy (highest to lowest priority):
    1. Per-app override (if app_id provided and assistant_type is "apps")
    2. Type-specific override (main_chat, operations, apps)
    3. Default values
    
    Args:
        ui_manifest: UI manifest dictionary loaded from ui_manifest.yml
        assistant_type: Type of assistant ("main_chat", "operations", or "apps")
        app_id: Optional app ID for per-app overrides (only used when assistant_type is "apps")
        
    Returns:
        Dictionary with keys: name, subtitle, placeholder, greeting
    """
    logger = Logger("AssistantConfig")
    
    # Get assistant section from ui_manifest
    assistant_config = ui_manifest.get("assistant", {})
    
    # Default values
    defaults = {
        "name": assistant_config.get("name", "Jarvis"),
        "subtitle": assistant_config.get("subtitle", "AI Assistant"),
        "placeholder": assistant_config.get("placeholder", "Ask me anything..."),
        "greeting": assistant_config.get("greeting", ""),
    }
    
    # Get type-specific override
    type_config = assistant_config.get(assistant_type, {})
    
    # Get per-app override (if app_id provided and assistant_type is "apps")
    app_config = {}
    if assistant_type == "apps" and app_id:
        apps_config = assistant_config.get("apps", {})
        app_config = apps_config.get(app_id, {})
        logger.debug("Resolved app-specific config for {}: {}", app_id, app_config)
    
    # Merge with priority: app > type > default
    result = {
        "name": app_config.get("name") or type_config.get("name") or defaults["name"],
        "subtitle": app_config.get("subtitle") or type_config.get("subtitle") or defaults["subtitle"],
        "placeholder": app_config.get("placeholder") or type_config.get("placeholder") or defaults["placeholder"],
        "greeting": app_config.get("greeting") or type_config.get("greeting") or defaults["greeting"],
    }
    
    logger.debug(
        "Resolved assistant config for type={}, app_id={}: name={}, subtitle={}",
        assistant_type,
        app_id,
        result["name"],
        result["subtitle"],
    )
    
    return result


def load_ui_manifest(project_dir: Path) -> Dict[str, Any]:
    """
    Load ui_manifest.yml from project directory.
    
    Args:
        project_dir: Project root directory
        
    Returns:
        UI manifest dictionary (empty dict if not found)
    """
    logger = Logger("AssistantConfig")
    
    ui_yml = project_dir / "config" / "ui_manifest.yml"
    ui_yaml = project_dir / "config" / "ui_manifest.yaml"
    
    if ui_yml.exists():
        try:
            with open(ui_yml, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f) or {}
        except Exception as e:
            logger.warning("Failed to load ui_manifest.yml: {}", e)
            return {}
    elif ui_yaml.exists():
        try:
            with open(ui_yaml, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f) or {}
        except Exception as e:
            logger.warning("Failed to load ui_manifest.yaml: {}", e)
            return {}
    
    logger.debug("No ui_manifest.yml found in {}", project_dir)
    return {}
