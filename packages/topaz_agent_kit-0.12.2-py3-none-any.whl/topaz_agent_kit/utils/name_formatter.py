"""
Utility functions for formatting names from IDs.

Provides functions to convert snake_case IDs to Title Case display names,
similar to how gate IDs are displayed.
"""


def format_pattern_name(pattern_id: str) -> str:
    """Convert snake_case pattern ID to Title Case display name.
    
    Args:
        pattern_id: Pattern ID in snake_case (e.g., "invoice_processing_loop")
        
    Returns:
        Formatted display name (e.g., "Invoice Processing Loop")
        
    Examples:
        >>> format_pattern_name("aegis_processing_flow")
        "Aegis Processing Flow"
        >>> format_pattern_name("invoice_processing_loop")
        "Invoice Processing Loop"
        >>> format_pattern_name("single_invoice_workflow")
        "Single Invoice Workflow"
        >>> format_pattern_name("capex_item_assessment")
        "Capex Item Assessment"
    """
    if not pattern_id:
        return None
    
    # Split by underscore and capitalize each word
    words = pattern_id.split('_')
    formatted = ' '.join(word.capitalize() for word in words)
    
    return formatted
