"""
Path Resolver Utility

Provides default-based path resolution for configuration files.
Applies consistent defaults across all registries (pipelines, apps, agents, operations, gates, prompts, patterns).

Also provides path normalization utilities for converting between absolute and relative paths
relative to project_dir for cross-machine compatibility.
"""

import re
from pathlib import Path
from typing import Optional

from topaz_agent_kit.utils.logger import Logger

logger = Logger("PathResolver")


def should_apply_default(value: Optional[str]) -> bool:
    """
    Determine if we should apply default path based on value.
    
    Returns True if value looks like a simple ID (not a path or inline template).
    
    Args:
        value: The value to check
        
    Returns:
        True if default should be applied, False otherwise
    """
    if not value or not isinstance(value, str):
        return False
    
    # Don't default if it contains path separators
    if '/' in value or '\\' in value:
        return False
    
    # Don't default if it contains file extension (likely explicit path)
    if '.' in value and any(ext in value for ext in ['.jinja', '.txt', '.md', '.yml', '.yaml', '.json']):
        return False
    
    # Don't default if it looks like inline template (contains template syntax)
    if '{{' in value or '{%' in value:
        return False
    
    # Don't default if it's multi-line (likely inline content)
    if '\n' in value:
        return False
    
    # Simple ID - apply default
    return True


def resolve_config_path(value: Optional[str], default_pattern: str, id_value: str) -> str:
    """
    Resolve config path with defaults.
    
    If value is missing or is a simple ID, applies default pattern.
    Otherwise, returns value as-is (explicit path or inline content).
    
    Args:
        value: The config path value (may be None, simple ID, or explicit path)
        default_pattern: Default pattern string with {id} placeholder
        id_value: The ID to use in default pattern
        
    Returns:
        Resolved path string
    """
    if not value:
        return default_pattern.format(id=id_value)
    
    if should_apply_default(value):
        # Use value as the ID (it's a simple ID, not a path)
        return default_pattern.format(id=value)
    
    # Explicit path or inline content - return as-is
    return value


def find_repository_root(start: Path, max_levels: int = 10) -> Path:
    """
    Find repository root by looking for pyproject.toml starting from a given path.
    
    Args:
        start: Starting path to search from
        max_levels: Maximum number of parent directories to search
        
    Returns:
        Path to the repository root directory containing pyproject.toml
        
    Raises:
        FileNotFoundError: If no repository root is found within max_levels
    """
    current = Path(start).resolve()
    
    for level in range(max_levels):
        pyproject_file = current / "pyproject.toml"
        
        if pyproject_file.exists():
            return current
        
        if current == current.parent:  # Reached root directory
            break
            
        current = current.parent
    
    # No repository root found - fail fast
    error_msg = f"No repository root found (no pyproject.toml) starting from {start} within {max_levels} levels"
    raise FileNotFoundError(error_msg)


def detect_project_name(project_dir: Path) -> Optional[str]:
    """
    Detect project name from project directory path.
    
    Args:
        project_dir: Path to project directory
        
    Returns:
        Project name if found (e.g., "ensemble"), None otherwise
        
    Examples:
        >>> detect_project_name(Path("projects/ensemble"))
        "ensemble"
        
        >>> detect_project_name(Path("/some/other/path"))
        None
    """
    project_dir = project_dir.resolve()
    
    # Check if path contains "projects/"
    if "projects" in project_dir.parts:
        projects_idx = project_dir.parts.index("projects")
        if projects_idx + 1 < len(project_dir.parts):
            return project_dir.parts[projects_idx + 1]
    
    return None


def resolve_script_path(
    path_str: str,
    project_name: Optional[str] = None,
    cwd: Optional[Path] = None
) -> Path:
    """
    Resolve a script path intelligently based on execution context.
    
    Handles paths that may be:
    - Absolute paths (returned as-is)
    - Relative to repository root (e.g., "projects/ensemble/data/...")
    - Relative to project directory (e.g., "data/...")
    
    If path starts with "projects/" and execution is from project_dir,
    automatically strips the "projects/{name}/" prefix.
    
    Args:
        path_str: Path string to resolve (may be relative or absolute)
        project_name: Optional project name (e.g., "ensemble") for path adjustment
        cwd: Optional current working directory (defaults to Path.cwd())
        
    Returns:
        Resolved absolute Path
        
    Examples:
        >>> # From repository root
        >>> resolve_script_path("projects/ensemble/data/db.db")
        Path("/repo/projects/ensemble/data/db.db")
        
        >>> # From project directory
        >>> resolve_script_path("projects/ensemble/data/db.db", project_name="ensemble")
        Path("/repo/projects/ensemble/data/db.db")  # Strips prefix if in project_dir
        
        >>> # Absolute path
        >>> resolve_script_path("/absolute/path/db.db")
        Path("/absolute/path/db.db")
    """
    path = Path(path_str)
    
    # If already absolute, return as-is
    if path.is_absolute():
        return path
    
    # Use provided cwd or current working directory
    if cwd is None:
        cwd = Path.cwd()
    else:
        cwd = Path(cwd).resolve()
    
    # Detect if we're in a project directory (has config/pipeline.yml)
    is_project_dir = (cwd / "config" / "pipeline.yml").exists()
    
    # If path starts with "projects/" and we're in project_dir
    if path.parts and path.parts[0] == "projects" and is_project_dir:
        # Try to detect project name from cwd if not provided
        if project_name is None and "projects" in cwd.parts:
            projects_idx = cwd.parts.index("projects")
            if projects_idx + 1 < len(cwd.parts):
                project_name = cwd.parts[projects_idx + 1]
        
        # If we have a project name and path matches, strip prefix
        if project_name and len(path.parts) >= 2 and path.parts[1] == project_name:
            # Strip "projects/{name}/" prefix and resolve from project_dir
            return cwd / Path(*path.parts[2:])
    
    # Default: resolve from current working directory
    return cwd / path


def normalize_to_project_relative(file_path: str, project_dir: Path) -> str:
    """
    Normalize absolute file path to be relative to project_dir.
    
    Handles:
    - Absolute paths matching /.../projects/{project_name}/... → extract relative portion
    - Already relative paths → return as-is
    - URLs → return as-is
    - Paths outside project_dir → log warning, return as-is (fallback)
    
    Args:
        file_path: File path (absolute or relative)
        project_dir: Project root directory (absolute Path)
    
    Returns:
        Relative path (relative to project_dir) or original if can't normalize
    
    Examples:
        >>> normalize_to_project_relative(
        ...     "/Users/.../projects/pa/data/file.pdf",
        ...     Path("/Users/.../projects/pa")
        ... )
        "data/file.pdf"
        
        >>> normalize_to_project_relative(
        ...     "data/file.pdf",
        ...     Path("/Users/.../projects/pa")
        ... )
        "data/file.pdf"
        
        >>> normalize_to_project_relative(
        ...     "http://example.com/file.pdf",
        ...     Path("/Users/.../projects/pa")
        ... )
        "http://example.com/file.pdf"
    """
    if not file_path:
        return file_path
    
    # URLs unchanged
    if file_path.startswith("http://") or file_path.startswith("https://"):
        return file_path
    
    # Convert to Path object for OS-agnostic handling
    path_obj = Path(file_path)
    project_dir_resolved = Path(project_dir).resolve()
    
    # Already relative (not absolute)
    if not path_obj.is_absolute():
        # Return as normalized string (forward slashes for consistency)
        return str(path_obj).replace('\\', '/')
    
    # Absolute path - try to extract relative portion
    try:
        # Try to get relative path from project_dir
        # Path.resolve() handles OS-specific path resolution
        resolved_path = path_obj.resolve()
        relative_path = resolved_path.relative_to(project_dir_resolved)
        logger.debug("Normalized absolute path {} to relative {}", file_path, relative_path)
        # Return as normalized string (forward slashes for consistency)
        return str(relative_path).replace('\\', '/')
    except ValueError:
        # Path is outside project_dir - try pattern matching as fallback
        # Handle both Unix (/path/to/projects/...) and Windows (C:\path\to\projects\...)
        # Normalize to forward slashes for pattern matching
        normalized_path = str(path_obj).replace('\\', '/')
        
        # Pattern: .../projects/{project_name}/...
        # Works for both Unix and Windows (after normalization)
        match = re.search(r'/projects/([^/]+)/(.+)$', normalized_path)
        if match:
            relative_path = match.group(2)
            logger.debug("Extracted relative path from pattern: {} -> {}", file_path, relative_path)
            return relative_path
        
        # Can't normalize - log warning and return as-is (fallback)
        logger.warning("Could not normalize path {} relative to project_dir {}", file_path, project_dir)
        # Return normalized (forward slashes) for consistency
        return normalized_path


def resolve_to_absolute(file_path: str, project_dir: Path) -> Path:
    """
    Resolve relative file path to absolute path relative to project_dir.
    
    OS-agnostic: Handles both Unix and Windows paths correctly.
    - Accepts forward slashes (/) or backslashes (\\) in input
    - Returns Path object which handles OS-specific path operations
    - Validates paths are within project_dir for security
    
    Args:
        file_path: Relative file path (may contain / or \\ separators)
        project_dir: Project root directory (absolute Path)
    
    Returns:
        Absolute Path object (OS-specific)
    
    Raises:
        ValueError: If resolved path is outside project_dir
    """
    if not file_path:
        raise ValueError("file_path cannot be empty")
    
    # Normalize path separators - Path handles both / and \ correctly
    # Convert to Path object for OS-agnostic handling
    path_obj = Path(file_path)
    project_dir_resolved = Path(project_dir).resolve()
    
    # If already absolute, validate it's within project_dir
    if path_obj.is_absolute():
        resolved = path_obj.resolve()
        try:
            # Use relative_to() which works correctly on all OSes
            resolved.relative_to(project_dir_resolved)
            return resolved
        except ValueError:
            raise ValueError(f"Absolute path must be within project_dir: {file_path}")
    
    # Relative path - resolve relative to project_dir
    # Path.join() handles OS-specific separators automatically
    resolved = (project_dir_resolved / path_obj).resolve()
    
    # Security: Ensure resolved path is still within project_dir
    # This prevents path traversal attacks (e.g., "../../etc/passwd")
    try:
        resolved.relative_to(project_dir_resolved)
    except ValueError:
        raise ValueError(f"Resolved path outside project_dir: {resolved}")
    
    return resolved


def resolve_path_if_relative(path_str: str, base_dir: Path) -> str:
    """
    Resolve a path relative to base_dir if it's not already absolute.
    
    Common pattern: Check if path is absolute, if not, resolve relative to base_dir.
    This is a convenience function for the common pattern:
        if not Path(path).is_absolute():
            path = str(Path(base_dir) / path)
    
    OS-agnostic: Handles both Unix and Windows paths correctly.
    
    Args:
        path_str: Path string (may be absolute or relative)
        base_dir: Base directory to resolve relative paths against
    
    Returns:
        Absolute path as string (OS-specific format)
    
    Examples:
        >>> resolve_path_if_relative("data/file.db", Path("/projects/pa"))
        "/projects/pa/data/file.db"
        
        >>> resolve_path_if_relative("/absolute/path/file.db", Path("/projects/pa"))
        "/absolute/path/file.db"
        
        >>> resolve_path_if_relative("data\\file.db", Path("C:\\projects\\pa"))
        "C:\\projects\\pa\\data\\file.db"
    """
    path_obj = Path(path_str)
    
    # If already absolute, return as-is
    if path_obj.is_absolute():
        return str(path_obj)
    
    # Resolve relative to base_dir
    resolved = (Path(base_dir) / path_obj).resolve()
    return str(resolved)
