import json
from pathlib import Path
from typing import Any, Dict, Optional

from topaz_agent_kit.utils.logger import Logger
from topaz_agent_kit.utils.path_resolver import resolve_config_path


def normalize_path_for_prompt(path_value: Any) -> Any:
    """
    Normalize path values for inclusion in prompts.
    
    Converts Windows backslashes to forward slashes to prevent Azure OpenAI
    content filter violations. This is safe because:
    - Python's pathlib handles both separators correctly
    - Forward slashes work on Windows for file operations
    - Prevents content filter false positives from backslash characters
    
    Args:
        path_value: Path value (Path object, string, or other type)
        
    Returns:
        Normalized path string if it's a path, otherwise original value
    """
    if path_value is None:
        return None
    
    # Convert Path objects to strings
    if isinstance(path_value, Path):
        path_str = str(path_value)
    elif isinstance(path_value, str):
        path_str = path_value
    else:
        # Not a path-like value, return as-is
        return path_value
    
    # Normalize backslashes to forward slashes
    # This prevents Azure content filter issues on Windows
    normalized = path_str.replace('\\', '/')
    
    return normalized


class PromptLoader:
    """A class for loading and rendering prompt templates with clear separation of concerns."""
    
    def __init__(self, project_dir: Path):
        """Initialize the PromptLoader with a project directory.
        
        Args:
            project_dir: Project root directory for resolving relative paths
        """
        self.project_dir = project_dir
        self.logger = Logger("PromptLoader")
    
    def load_prompt(self, spec: Dict[str, Any] | None, agent_id: Optional[str] = None) -> str:
        """Load a prompt template from a spec WITHOUT rendering variables.
        
        This method only loads the template content, it does not render any variables.
        Use this when you need the raw template to render variables separately.
        
        Args:
            spec: Prompt specification containing inline, file, or jinja definitions
            agent_id: Optional agent ID for default path resolution (defaults to prompts/{agent_id}.jinja)
            
        Returns:
            Raw prompt template string
            
        spec:
          - inline: str (used verbatim)
          - file: str (path relative to project_dir)
          - jinja: str (either a file path or inline template content)
          
        Default behavior:
          - If no inline, file, or jinja provided and agent_id is available:
            defaults to "prompts/{agent_id}.jinja"
          - If jinja is a simple ID (no path separators, no extension) and agent_id is available:
            resolves to "prompts/{jinja}.jinja"
        """
        if not spec:
            # Apply default if agent_id is provided
            if agent_id:
                default_path = resolve_config_path(None, "prompts/{id}.jinja", agent_id)
                self.logger.debug("No prompt spec provided, using default: {}", default_path)
                config_path = Path(self.project_dir) / "config" / default_path
                if config_path.exists():
                    return self._read_text(str(config_path))
                else:
                    self.logger.warning("Default prompt file not found: {}", config_path)
            return ""
        
        # Handle nested description structure (e.g., {'description': {'jinja': 'file.jinja'}})
        if "description" in spec and isinstance(spec["description"], dict):
            self.logger.debug("Found nested description structure, using it as spec")
            spec = spec["description"]
        
        inline = spec.get("inline")
        file_path = spec.get("file")
        jinja_def = spec.get("jinja")
        
        self.logger.debug("Prompt spec: inline={}, file={}, jinja={}", 
                        bool(inline), bool(file_path), bool(jinja_def))

        # Resolve source
        source: str = ""
        if isinstance(inline, str) and inline.strip():
            self.logger.debug("Using inline prompt ({} chars)", len(inline))
            source = inline
        elif isinstance(file_path, str) and file_path.strip():
            self.logger.debug("Loading prompt from file: {}", file_path)
            source = self._read_text(file_path)
        elif isinstance(jinja_def, str) and jinja_def.strip():
            # Apply default path resolution if jinja_def is a simple ID
            if agent_id:
                resolved_jinja = resolve_config_path(jinja_def, "prompts/{id}.jinja", agent_id)
            else:
                resolved_jinja = jinja_def
            
            # If it looks like a file and exists, read it; else treat as inline template
            jp = Path(resolved_jinja)
            if jp.is_absolute():
                # Absolute path - use as is
                if jp.exists():
                    self.logger.debug("Loading Jinja template from absolute file: {}", resolved_jinja)
                    source = self._read_text(resolved_jinja)
                else:
                    self.logger.debug("Using Jinja template as inline content ({} chars)", len(jinja_def))
                    source = jinja_def
            else:
                # Relative path - resolve relative to config/ directory
                config_path = Path(self.project_dir) / "config" / jp
                
                if config_path.exists():
                    self.logger.debug("Loading Jinja template from config/: {}", resolved_jinja)
                    source = self._read_text(str(config_path))
                else:
                    # If default was applied but file doesn't exist, try original jinja_def as inline
                    if resolved_jinja != jinja_def:
                        self.logger.warning("Default prompt file not found: {}, trying original as inline", config_path)
                        source = jinja_def
                    else:
                        self.logger.error("Prompt file not found in config/: {}", config_path)
                        return ""
        else:
            # No inline, file, or jinja - apply default if agent_id is available
            if agent_id:
                default_path = resolve_config_path(None, "prompts/{id}.jinja", agent_id)
                self.logger.debug("No prompt source found, using default: {}", default_path)
                config_path = Path(self.project_dir) / "config" / default_path
                if config_path.exists():
                    return self._read_text(str(config_path))
                else:
                    self.logger.warning("Default prompt file not found: {}", config_path)
            return ""

        self.logger.debug("Loaded prompt template ({} chars)", len(source))
        return source

    def render_prompt(self, template: str, *, variables: Dict[str, Any], template_path: Optional[str] = None) -> str:
        """Render a prompt template with variables using Jinja2.
        
        This method only renders variables in an already-loaded template.
        Use this when you have a template string and want to substitute variables.
        
        Args:
            template: The prompt template string (may contain {{ variable }} placeholders)
            variables: Dictionary of variables to substitute in the template
            template_path: Optional path to the template file (relative to config/prompts or absolute).
                          Required if template contains {% include %} or {% extends %} statements.
            
        Returns:
            Rendered prompt string with variables substituted
        """
        self.logger.debug("Rendering template ({} chars) with {} variables", len(template), len(variables))
        
        if not template.strip():
            self.logger.warning("Empty template provided, returning empty string")
            return ""
        
        # Use Jinja2 template rendering
        return self._render_jinja(template, variables, template_path=template_path)

    def load_and_render_prompt(self, spec: Dict[str, Any] | None, *, data: Dict[str, Any], context: Dict[str, Any]) -> str:
        """Load a prompt template from a spec AND render variables in one step.
        
        This is a convenience method that combines load_prompt() and render_prompt().
        Use this when you want to load and render in a single operation.
        
        Args:
            spec: Prompt specification containing inline, file, or jinja definitions
            data: Variables to pass into the template environment
            context: Additional context variables
            
        Returns:
            Fully rendered prompt string with variables substituted
            
        spec:
          - inline: str (used verbatim)
          - file: str (path relative to project_dir)
          - jinja: str (either a file path or inline template content)
          - vars: mapping to pass into the template environment
          - description: dict containing nested prompt definitions
        """
        # Step 1: Load the template using load_prompt()
        template = self.load_prompt(spec)
        
        if not template.strip():
            self.logger.debug("No template loaded, returning empty string")
            return ""
        
        # Step 2: Prepare variables for rendering
        variables = {"data": data, "context": context}
        # Convenience: also expose data/context at top-level for {{ user_text }} style access
        try:
            if isinstance(data, dict):
                variables.update(data)
            if isinstance(context, dict):
                variables.update(context)
        except Exception:
            pass
        self.logger.debug("Prompt variables: {} data keys, {} context keys", len(data), len(context))

        # Step 3: Render the template using render_prompt()
        return self.render_prompt(template, variables=variables)

    def _read_text(self, file_path: str | Path) -> str:
        """Read text content from a file path."""
        p = Path(file_path)
        self.logger.info("_read_text called with: {} (is_absolute: {})", file_path, p.is_absolute())
        if not p.is_absolute():
            # Resolve relative to config/ directory
            config_path = Path(self.project_dir) / "config" / p
            self.logger.info("Checking config path: {} (exists: {})", config_path, config_path.exists())
            if config_path.exists():
                self.logger.debug("Reading prompt file from config/: {}", config_path)
                p = config_path
            else:
                self.logger.error("Prompt file not found in config/: {}", config_path)
                raise FileNotFoundError(f"Prompt file not found: {config_path}")
        else:
            self.logger.debug("Reading prompt file from absolute path: {}", p)
        try:
            content = p.read_text(encoding="utf-8")
            self.logger.debug("Successfully read prompt file: {} ({} chars)", p, len(content))
            return content
        except Exception as e:
            self.logger.error("Failed to read prompt file '{}': {}", p, e)
            return f"Error reading prompt file '{p}': {e}"

    def _render_jinja(self, template_str: str, variables: Dict[str, Any], template_path: Optional[str] = None) -> str:
        """Render Jinja2 template with variables."""
        self.logger.debug("Rendering Jinja template ({} chars) with {} variables", len(template_str), len(variables))
        try:
            from jinja2 import Environment, Undefined, FileSystemLoader
            from topaz_agent_kit.utils.jinja2_filters import register_jinja2_filters
            import os
            import re
            
            # Check if template contains includes or extends (requires FileSystemLoader)
            has_includes = "{% include" in template_str or "{% extends" in template_str
            
            if has_includes and template_path:
                # Use FileSystemLoader to support includes
                # Set up search paths: project config/prompts and base kit prompts
                base_kit_prompts_dir = Path(__file__).parent.parent / "prompts"
                project_prompts_dir = Path(self.project_dir) / "config" / "prompts"
                
                search_paths = []
                if project_prompts_dir.exists():
                    search_paths.append(str(project_prompts_dir))
                if base_kit_prompts_dir.exists():
                    search_paths.append(str(base_kit_prompts_dir))
                
                if search_paths:
                    self.logger.debug("Using FileSystemLoader with search paths: {}", search_paths)
                    env = Environment(
                        loader=FileSystemLoader(search_paths),
                        undefined=Undefined,
                        autoescape=False
                    )
                    register_jinja2_filters(env)
                    
                    # Resolve template path relative to search paths
                    # FileSystemLoader expects paths relative to search paths, not including the search path prefix
                    # If template_path includes "prompts/" or "config/prompts/", strip it since search paths already point to prompts directories
                    # Use Path objects for OS-agnostic path handling (handles both / and \ automatically)
                    self.logger.debug("Resolving template_path '{}' for FileSystemLoader (search paths: {})", template_path, search_paths)
                    template_name = template_path
                    if template_path and not os.path.isabs(template_path):
                        # Convert to Path object for OS-agnostic path manipulation
                        template_path_obj = Path(template_path)
                        original_path = template_path
                        parts = template_path_obj.parts
                        
                        # Strip "config/prompts/" or "prompts/" prefix if present (OS-agnostic using Path.parts)
                        if len(parts) >= 3 and parts[0] == "config" and parts[1] == "prompts":
                            # Remove "config" and "prompts" from the beginning
                            template_name = str(Path(*parts[2:])).replace("\\", "/")  # Normalize to forward slashes for Jinja2
                            self.logger.debug("Stripped 'config/prompts/' prefix: '{}' -> '{}'", original_path, template_name)
                        elif len(parts) >= 2 and parts[0] == "prompts":
                            # Remove "prompts" from the beginning
                            template_name = str(Path(*parts[1:])).replace("\\", "/")  # Normalize to forward slashes for Jinja2
                            self.logger.debug("Stripped 'prompts/' prefix: '{}' -> '{}'", original_path, template_name)
                        
                        # Verify the template exists in one of the search paths (OS-agnostic using Path)
                        found = False
                        for search_path in search_paths:
                            # Use Path operations which handle OS-specific separators correctly
                            test_path = Path(search_path) / template_name
                            if test_path.exists():
                                found = True
                                self.logger.debug("Found template '{}' in search path: {}", template_name, search_path)
                                break
                        
                        if not found:
                            # Log warning and try with original path (might be a subdirectory structure)
                            self.logger.debug("Template '{}' not found in search paths, trying original path: {}", template_name, template_path)
                            template_name = template_path
                    
                    try:
                        # Normalize variables for FileSystemLoader path too
                        # (simplified normalization - full normalization happens in fallback path)
                        normalized_vars = {}
                        for key, value in variables.items():
                            if isinstance(value, Path):
                                # normalize_path_for_prompt is defined in this module, use it directly
                                normalized_vars[key] = normalize_path_for_prompt(value)
                            else:
                                normalized_vars[key] = value
                        
                        self.logger.debug("Attempting to load template '{}' using FileSystemLoader (search paths: {})", template_name, search_paths)
                        tmpl = env.get_template(template_name)
                        result = tmpl.render(**normalized_vars)
                        self.logger.debug("Successfully rendered Jinja template with includes ({} chars)", len(result))
                        return result
                    except Exception as e:
                        self.logger.warning("Failed to render template '{}' with FileSystemLoader (search paths: {}), falling back to from_string: {}", template_name, search_paths, e)
                        # Fall through to from_string approach

            # First, scan the template to find which variables are actually used
            # This prevents us from trying to serialize variables that aren't referenced
            import re
            # Find all variable references in the template: {{ var }}, {{ var.field }}, {{ var | filter }}, etc.
            # Pattern matches: {{ variable }}, {{ variable.field }}, {{ variable.field.subfield }}, etc.
            var_pattern = r'\{\{([^}|]+)'
            used_vars = set()
            for match in re.finditer(var_pattern, template_str):
                expr = match.group(1).strip()
                # Extract the base variable name (before any dots, filters, or operators)
                # Handle: var, var.field, var.field.subfield, var|filter, var if condition else default
                base_var = expr.split('.')[0].split('|')[0].split(' if ')[0].split(' else ')[0].strip()
                if base_var:
                    used_vars.add(base_var)
            
            self.logger.debug("Template uses {} variables: {}", len(used_vars), sorted(used_vars))
            
            # Normalize variables to prevent Azure content filter issues
            # 1. Normalize path variables (Windows backslashes -> forward slashes)
            # 2. Recursively serialize nested complex objects as JSON strings
            #    (prevents platform-specific repr() differences while preserving top-level dict structure for Jinja2 dot notation)
            # IMPORTANT: Only normalize variables that are actually used in the template
            
            def clean_for_json(obj: Any) -> Any:
                """
                Recursively clean an object to make it JSON-serializable.
                Removes functions, non-serializable objects, and converts them to safe representations.
                
                Args:
                    obj: Object to clean
                
                Returns:
                    JSON-serializable version of the object
                """
                # Handle None
                if obj is None:
                    return None
                
                # Handle primitives (already JSON-serializable)
                if isinstance(obj, (str, int, float, bool)):
                    return obj
                
                # Handle Path objects - convert to string and normalize
                if isinstance(obj, Path):
                    return normalize_path_for_prompt(obj)
                
                # Handle dicts - recursively clean values, skip functions
                if isinstance(obj, dict):
                    cleaned = {}
                    for k, v in obj.items():
                        # Skip function keys/values and non-string keys
                        if callable(k) or callable(v):
                            continue
                        if not isinstance(k, (str, int, float, bool)):
                            continue
                        try:
                            cleaned[k] = clean_for_json(v)
                        except Exception:
                            # Skip entries that can't be cleaned
                            continue
                    return cleaned
                
                # Handle lists - recursively clean items, skip functions
                if isinstance(obj, list):
                    cleaned = []
                    for item in obj:
                        # Skip functions and non-serializable items
                        if callable(item):
                            continue
                        try:
                            cleaned_item = clean_for_json(item)
                            cleaned.append(cleaned_item)
                        except Exception:
                            # Skip items that can't be cleaned
                            continue
                    return cleaned
                
                # Handle custom objects - try to extract serializable attributes
                if hasattr(obj, '__dict__'):
                    try:
                        # Try to get a dict representation
                        obj_dict = {}
                        for k, v in obj.__dict__.items():
                            if not callable(v) and not k.startswith('_'):
                                try:
                                    obj_dict[k] = clean_for_json(v)
                                except Exception:
                                    continue
                        return obj_dict if obj_dict else None
                    except Exception:
                        pass
                
                # For other types, return None (safer than str() which can trigger filters)
                return None
            
            def normalize_value(value: Any, is_top_level: bool = False, preserved_paths: set = None, current_path: str = "") -> Any:
                """
                Recursively normalize a value for prompt rendering.
                
                Args:
                    value: Value to normalize
                    is_top_level: True if this is a top-level variable (preserve dict structure for dot notation)
                    preserved_paths: Set of dot notation paths that should be preserved as dicts (e.g., {"invoice_review", "invoice_review.invoice"})
                    current_path: Current path in the nested structure (e.g., "invoice_review.invoice")
                
                Returns:
                    Normalized value
                """
                if preserved_paths is None:
                    preserved_paths = set()
                
                # Handle None
                if value is None:
                    return None
                
                # Handle Path objects
                if isinstance(value, Path):
                    return normalize_path_for_prompt(value)
                
                # Handle strings - check if it's a path
                if isinstance(value, str):
                    has_backslash = '\\' in value
                    has_drive_letter = len(value) >= 2 and value[1] == ':' and value[0].isalpha()
                    if has_backslash or (has_drive_letter and ('/' in value or '\\' in value)):
                        return normalize_path_for_prompt(value)
                    return value
                
                # Handle dicts
                if isinstance(value, dict):
                    # For top-level dicts, we need to preserve structure for Jinja2 dot notation
                    # (e.g., argus_journal_extractor.extracted_entry), but also serialize nested dicts
                    if is_top_level:
                        # Recursively normalize nested values but keep as dict
                        # Preserve nested dicts that are part of dot notation paths
                        normalized_dict = {}
                        for k, v in value.items():
                            # Build the path for this nested key
                            nested_path = f"{current_path}.{k}" if current_path else k
                            # Check if this path should be preserved (is part of a dot notation path)
                            # A path should be preserved if:
                            # 1. It's exactly in preserved_paths, OR
                            # 2. It's a prefix of any preserved path (e.g., "invoice_review" is prefix of "invoice_review.invoice")
                            should_preserve = nested_path in preserved_paths or any(
                                p.startswith(nested_path + ".") or p == nested_path for p in preserved_paths
                            )
                            
                            if isinstance(v, dict) and should_preserve:
                                # This nested dict is part of a dot notation path - preserve it as a dict
                                normalized_dict[k] = normalize_value(
                                    v, 
                                    is_top_level=False, 
                                    preserved_paths=preserved_paths, 
                                    current_path=nested_path
                                )
                            else:
                                # Normal nested value - serialize nested dicts/lists as JSON strings
                                normalized_dict[k] = normalize_value(
                                    v, 
                                    is_top_level=False, 
                                    preserved_paths=preserved_paths, 
                                    current_path=nested_path
                                )
                        return normalized_dict
                    else:
                        # For nested dicts, check if this path should be preserved
                        # A path should be preserved if:
                        # 1. It's exactly in preserved_paths, OR
                        # 2. It's a prefix of any preserved path (e.g., "invoice_review" is prefix of "invoice_review.invoice")
                        should_preserve = current_path in preserved_paths or any(
                            p.startswith(current_path + ".") or p == current_path for p in preserved_paths
                        )
                        
                        if should_preserve:
                            # This nested dict is part of a dot notation path - preserve it as a dict
                            normalized_dict = {}
                            for k, v in value.items():
                                nested_path = f"{current_path}.{k}" if current_path else k
                                normalized_dict[k] = normalize_value(
                                    v, 
                                    is_top_level=False, 
                                    preserved_paths=preserved_paths, 
                                    current_path=nested_path
                                )
                            return normalized_dict
                        else:
                            # For nested dicts not in preserved paths, serialize as JSON string
                            # This ensures consistent formatting and prevents content filter violations
                            try:
                                return json.dumps(value, ensure_ascii=False, separators=(',', ':'))
                            except (TypeError, ValueError) as e:
                                self.logger.warning("Failed to serialize nested dict as JSON, using str(): {}", e)
                                return str(value)
                
                # Handle lists
                if isinstance(value, list):
                    # For top-level lists, preserve structure but normalize items
                    if is_top_level:
                        return [normalize_value(item, is_top_level=False, preserved_paths=preserved_paths, current_path=current_path) for item in value]
                    else:
                        # For nested lists, serialize as JSON string
                        try:
                            return json.dumps(value, ensure_ascii=False, separators=(',', ':'))
                        except (TypeError, ValueError) as e:
                            self.logger.warning("Failed to serialize nested list as JSON, using str(): {}", e)
                            return str(value)
                
                # For other types (primitives), return as-is
                return value
            
            # Scan template to detect which variables are used with dot notation
            # Variables used with dot notation (e.g., {{agent_id.field}}) must remain as dicts
            # Variables used directly (e.g., {{variable}}) can be serialized as JSON
            # Pattern matches: {{var.field}}, {{ var.field }}, {{var.field.subfield}}, etc.
            # Allow whitespace around the variable name and field
            dot_notation_pattern = r'\{\{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*\.[^}]+\}\}'
            variables_with_dot_notation = set(re.findall(dot_notation_pattern, template_str))
            self.logger.debug("Variables used with dot notation: {}", variables_with_dot_notation)
            
            # Extract all dot notation paths for each variable (e.g., canvas_state.invoice_review.invoice)
            # This helps us preserve nested dicts that are part of dot notation paths
            dot_notation_paths_by_var = {}
            for var_name in variables_with_dot_notation:
                # Find all paths that start with this variable name
                # Pattern: {{var_name.path.to.field}} or {{ ... var_name.path.to.field ... }} -> extract "path.to.field"
                # Need to handle cases where the variable is part of a larger expression
                escaped_var = re.escape(var_name)
                # Match variable references that may be part of larger expressions
                # Pattern matches: {{var.path}}, {{ var.path }}, {{expr if var.path.field else default}}
                # Extract the dot-notation path part, stopping at operators (|, if, else, or, and), filters, or whitespace
                # Use a more precise pattern that captures the path up to the first non-path character
                path_pattern = r'\{\{[^}]*' + escaped_var + r'\.([a-zA-Z0-9_]+(?:\.[a-zA-Z0-9_]+)*)'
                paths = set()
                for match in re.finditer(path_pattern, template_str):
                    # Extract the path part (e.g., "invoice_review.validation_results.anomaly.validation_passed")
                    full_path = match.group(1).strip()
                    # Extract all prefix paths (e.g., "invoice_review.validation_results.anomaly.validation_passed" -> 
                    # ["invoice_review", "invoice_review.validation_results", "invoice_review.validation_results.anomaly"])
                    path_parts = full_path.split('.')
                    for i in range(1, len(path_parts)):
                        prefix_path = '.'.join(path_parts[:i])
                        paths.add(prefix_path)
                dot_notation_paths_by_var[var_name] = paths
                if paths:
                    self.logger.debug("Variable '{}' uses dot notation paths: {}", var_name, sorted(paths))
            
            normalized_variables = {}
            path_keywords = ['path', 'dir', 'file', 'database']
            
            for key, value in variables.items():
                # Skip variables that aren't used in the template - no need to normalize them
                # This prevents serialization errors for unused variables like 'context', 'options', 'chat_turns', etc.
                if key not in used_vars:
                    # Still add to normalized_variables so Jinja2 can access it if needed (but don't normalize)
                    # This is safe because Jinja2 won't try to serialize it if it's not referenced
                    normalized_variables[key] = value
                    continue
                # Check if this looks like a path variable by name
                is_path_by_name = any(keyword in key.lower() for keyword in path_keywords)
                
                if is_path_by_name and isinstance(value, (str, Path)):
                    # Path variable - normalize paths
                    normalized_variables[key] = normalize_path_for_prompt(value)
                    self.logger.debug("Normalized path variable '{}'", key)
                elif isinstance(value, dict) and key not in variables_with_dot_notation:
                    # Top-level dict that's NOT used with dot notation - serialize as JSON
                    # This prevents Python's str() representation which can trigger content filters
                    try:
                        normalized_variables[key] = json.dumps(value, ensure_ascii=False, separators=(',', ':'))
                        self.logger.debug("Serialized top-level dict '{}' as JSON (not used with dot notation)", key)
                    except (TypeError, ValueError) as e:
                        self.logger.warning("Failed to serialize top-level dict '{}' as JSON, preserving structure: {}", key, e)
                        # Fallback: preserve structure but normalize nested values
                        preserved_paths = dot_notation_paths_by_var.get(key, set())
                        normalized_variables[key] = normalize_value(value, is_top_level=True, preserved_paths=preserved_paths, current_path="")
                else:
                    # Normalize value (preserve top-level dict structure for Jinja2 dot notation)
                    # Pass the dot notation paths so nested dicts in those paths are preserved
                    preserved_paths = dot_notation_paths_by_var.get(key, set())
                    normalized_variables[key] = normalize_value(value, is_top_level=True, preserved_paths=preserved_paths, current_path="")
                    if isinstance(value, dict) and not is_path_by_name:
                        self.logger.debug("Normalized dict variable '{}' (preserved structure for dot notation)", key)

            # Use permissive Undefined so missing variables render as empty strings
            # (Only if we didn't already use FileSystemLoader above)
            if not (has_includes and template_path):
                env = Environment(undefined=Undefined, autoescape=False)
                register_jinja2_filters(env)
                
                tmpl = env.from_string(template_str)
                result = tmpl.render(**normalized_variables)
                self.logger.debug("Successfully rendered Jinja template ({} chars)", len(result))
                return result
        except Exception as e:
            self.logger.error("Jinja render error: {}", e)
            # Fallback: return raw template with note
            return f"[Jinja render error: {e}]\n{template_str}"
