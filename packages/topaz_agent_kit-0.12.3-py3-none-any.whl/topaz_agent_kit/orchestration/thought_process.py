"""
Orchestration-level thought process extraction.

Shared helper for building thought process (reasoning steps) from a serialized
agent thread and optional response-level reasoning. Used by app assistant, ops
assistant, and (when added) main chat assistant.
"""

import json
from typing import Any, Dict, List, Optional


# --- Thread repair: incomplete tool-call sequences ---
# After agent.run(), the framework's thread.serialize() can sometimes produce
# a thread where the last message is an assistant message with tool_calls but
# no following tool result messages. We normalize at extract time so extraction
# and persistence both see valid state.


def _looks_like_messages(lst: List[Any]) -> bool:
    """True if list looks like a message list (each item has a 'role' key)."""
    if not lst or not isinstance(lst, list):
        return False
    return all(
        isinstance(m, dict) and "role" in m
        for m in lst
    )


def _strip_trailing_incomplete_assistant(messages: List[Any]) -> List[Any]:
    """Remove trailing assistant messages that have tool_calls but no following tool response."""
    out = list(messages)
    while out:
        last = out[-1]
        role = last.get("role") if isinstance(last, dict) else getattr(last, "role", None)
        tool_calls = last.get("tool_calls") if isinstance(last, dict) else getattr(last, "tool_calls", None)
        if role == "assistant" and tool_calls:
            out.pop()
        else:
            break
    return out


def repair_thread_messages(serialized: Any) -> Any:
    """
    Strip trailing assistant messages that have tool_calls but no following tool
    messages, so the thread is valid for the API. Used at save time and for extraction.
    """
    if serialized is None:
        return serialized
    if isinstance(serialized, list):
        if _looks_like_messages(serialized):
            return _strip_trailing_incomplete_assistant(serialized)
        return serialized
    if isinstance(serialized, dict):
        result = dict(serialized)
        for k, v in result.items():
            if isinstance(v, list) and _looks_like_messages(v):
                result[k] = _strip_trailing_incomplete_assistant(v)
            elif isinstance(v, (dict, list)):
                result[k] = repair_thread_messages(v)
        return result
    return serialized


def _get_messages_list(serialized: Any) -> Optional[List[Any]]:
    """Get the list of messages from serialized thread (list or dict with messages key)."""
    if serialized is None:
        return None
    if isinstance(serialized, list) and _looks_like_messages(serialized):
        return serialized
    if isinstance(serialized, dict):
        if "messages" in serialized and isinstance(serialized["messages"], list):
            return serialized["messages"]
        for v in serialized.values():
            if isinstance(v, list) and _looks_like_messages(v):
                return v
        if "chat_message_store_state" in serialized:
            nested = _get_messages_list(serialized["chat_message_store_state"])
            if nested:
                return nested
    return None


def _normalize_role(role: Any) -> str:
    """Extract role string; agent_framework may use dict e.g. {'type': 'role', 'value': 'assistant'}."""
    if role is None:
        return ""
    if isinstance(role, dict):
        return str(role.get("value", "")).strip()
    return str(role).strip()


def _reasoning_is_final_reply(reasoning_text: str, reply: str) -> bool:
    """True if this reasoning step is the same as the assistant's final reply (should not be shown as reasoning)."""
    if not reply or not reasoning_text:
        return False
    r = reasoning_text.strip()
    p = reply.strip()
    if r == p:
        return True
    if len(r) >= len(p) * 0.9 and (p in r or r in p):
        return True
    if len(r) >= 100 and r == p[: len(r)]:
        return True
    return False


def _input_summary(obj: Any, max_len: int = 120) -> str:
    """Short one-line summary of tool input."""
    if obj is None:
        return ""
    try:
        s = json.dumps(obj) if not isinstance(obj, str) else obj
        s = s.replace("\n", " ").strip()
        return s[:max_len] + ("..." if len(s) > max_len else "")
    except Exception:
        return str(obj)[:max_len]


def _content_item_type(item: Dict[str, Any]) -> str:
    """Resolve content item type; agent_framework may use dict e.g. {'type': 'type', 'value': 'tool_use'}."""
    raw = item.get("type")
    if isinstance(raw, dict):
        return str(raw.get("value", "")).strip().lower()
    return str(raw or "").strip().lower()


def _content_item_payload(item: Dict[str, Any], for_tool: bool = False) -> Dict[str, Any]:
    """Resolve payload from content item; agent_framework may nest under 'value'."""
    if for_tool and isinstance(item.get("value"), dict):
        return item["value"]
    return item


def _dict_get_any_key(d: Any, key: str, default: Any = None) -> Any:
    """Get value from dict by key; match by string key or case-insensitive key."""
    if not isinstance(d, dict):
        return default
    if key in d:
        return d[key]
    key_lower = str(key).strip().lower()
    for k, v in d.items():
        if str(k).strip().lower() == key_lower:
            return v
    return default


def _normalize_value(val: Any) -> Any:
    """If val is a dict with 'value' key, return value; else return val."""
    if isinstance(val, dict) and "value" in val:
        return val["value"]
    return val


def _to_dict(obj: Any) -> Dict[str, Any]:
    """Convert to a plain dict. Prefer to_dict(); fallback to JSON round-trip."""
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return obj
    if hasattr(obj, "to_dict") and callable(getattr(obj, "to_dict")):
        try:
            d = obj.to_dict()
            return d if isinstance(d, dict) else {}
        except Exception:
            pass
    try:
        d = json.loads(json.dumps(obj, default=str))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _deep_to_plain(obj: Any) -> Any:
    """Recursively convert to plain dicts/lists/str. Uses to_dict() when present."""
    if obj is None:
        return None
    if isinstance(obj, dict):
        return {str(k): _deep_to_plain(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_deep_to_plain(v) for v in obj]
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if hasattr(obj, "to_dict") and callable(getattr(obj, "to_dict")):
        try:
            d = obj.to_dict()
            return _deep_to_plain(d) if d is not None else obj
        except Exception:
            pass
    try:
        d = json.loads(json.dumps(obj, default=str))
        return _deep_to_plain(d) if isinstance(d, (dict, list)) else d
    except Exception:
        return obj


def _extract_thought_process_from_turn(serialized_thread: Any) -> List[Dict[str, Any]]:
    """
    Extract thought process (reasoning + tool calls) for the current turn only.
    Returns list of steps: { "type": "reasoning"|"tool_call", "text"?: str, "name"?: str, "input_summary"?: str }.
    """
    steps: List[Dict[str, Any]] = []
    try:
        messages = _get_messages_list(serialized_thread)
        if not messages:
            return steps
        messages = _deep_to_plain(messages)
        if not isinstance(messages, list):
            return steps
        last_user_idx = -1
        for i in range(len(messages) - 1, -1, -1):
            m = messages[i]
            if not isinstance(m, dict):
                continue
            raw_role = m.get("role")
            if _normalize_role(raw_role).lower() == "user":
                last_user_idx = i
                break
        for m in messages[last_user_idx + 1 :]:
            if not isinstance(m, dict):
                continue
            if _normalize_role(m.get("role")).lower() != "assistant":
                continue
            content = m.get("contents") or m.get("content")
            content_tool_steps = 0
            if isinstance(content, list):
                for raw_item in content:
                    item = _to_dict(raw_item)
                    if not item:
                        continue
                    itype = _content_item_type(item)
                    if itype in ("tool_use", "tool_call", "function_call"):
                        payload = _content_item_payload(item, for_tool=True)
                        if isinstance(payload, dict):
                            payload = {str(k): payload[k] for k in payload}
                        else:
                            payload = _to_dict(payload) or {}
                        raw_name = payload.get("name") or _dict_get_any_key(_to_dict(payload.get("function") or {}), "name")
                        name = str(_normalize_value(raw_name) or "").strip() if raw_name is not None else ""
                        raw_inp = payload.get("input") or payload.get("arguments") or _dict_get_any_key(_to_dict(payload.get("function") or {}), "arguments")
                        inp = _normalize_value(raw_inp) if raw_inp is not None else None
                        if isinstance(inp, str):
                            try:
                                inp = json.loads(inp) if inp.strip() else {}
                            except Exception:
                                pass
                        steps.append({
                            "type": "tool_call",
                            "name": name or "tool",
                            "input_summary": _input_summary(inp),
                        })
                        content_tool_steps += 1
                    elif itype == "text" or itype in ("message", "output") or item.get("text") or item.get("content"):
                        text = item.get("text") or item.get("content", "")
                        if text and isinstance(text, str):
                            if text.strip().startswith("{"):
                                try:
                                    parsed = json.loads(text)
                                    # Final structured response JSON: use "reasoning" from the message if present
                                    # and distinct from the reply (so Thought shows even when result.reasoning
                                    # is missing or lost). Do not use assistant_response as the step text.
                                    if isinstance(parsed, dict) and "assistant_response" in parsed:
                                        reply_text = (parsed.get("assistant_response") or "").strip()
                                        reason_text = (parsed.get("reasoning") or "").strip()
                                        if reason_text and not _reasoning_is_final_reply(reason_text, reply_text):
                                            steps.append({
                                                "type": "reasoning",
                                                "text": reason_text[:500] + ("..." if len(reason_text) > 500 else ""),
                                            })
                                        continue
                                    else:
                                        text = text[:500] + ("..." if len(text) > 500 else "")
                                except Exception:
                                    text = text[:500] + ("..." if len(text) > 500 else "")
                            steps.append({"type": "reasoning", "text": text})
            if content_tool_steps == 0:
                tool_calls = m.get("tool_calls") or (m.get("additional_properties") or {}).get("tool_calls")
                if isinstance(tool_calls, list):
                    for raw_tc in tool_calls:
                        tc = _to_dict(raw_tc)
                        if not tc:
                            continue
                        fn = _to_dict(_dict_get_any_key(tc, "function"))
                        raw_name = _dict_get_any_key(fn, "name") or _dict_get_any_key(tc, "name")
                        name = str(_normalize_value(raw_name) or "").strip() if raw_name is not None else ""
                        args = _dict_get_any_key(fn, "arguments") or _dict_get_any_key(tc, "input") or _dict_get_any_key(tc, "arguments")
                        args = _normalize_value(args) if args is not None else None
                        if isinstance(args, str):
                            try:
                                args = json.loads(args) if args.strip() else {}
                            except Exception:
                                pass
                        steps.append({
                            "type": "tool_call",
                            "name": name or "tool",
                            "input_summary": _input_summary(args),
                        })
            if not content and m.get("text"):
                steps.append({"type": "reasoning", "text": str(m.get("text", ""))})
    except Exception:
        pass
    return steps


def build_thought_process(
    serialized_thread: Any,
    reply_preview: str = "",
    response_reasoning: Optional[str] = None,
    reasoning_only: bool = True,
) -> List[Dict[str, Any]]:
    """
    Build thought process steps for the current turn.

    Args:
        serialized_thread: Serialized agent thread (list or dict). Repaired internally.
        reply_preview: Final reply text; used to exclude reasoning steps that duplicate the reply.
        response_reasoning: Optional reasoning from structured response (e.g. AssistantResponse.reasoning).
        reasoning_only: If True, return only reasoning steps (drop tool_call steps). Default True for UI that shows only reasoning.

    Returns:
        List of steps, each {"type": "reasoning", "text": str} (and optionally "name"/"input_summary" if reasoning_only=False).
    """
    repaired = repair_thread_messages(serialized_thread)
    all_steps = _extract_thought_process_from_turn(repaired)
    if reasoning_only:
        steps = [
            s for s in all_steps
            if s.get("type") == "reasoning"
            and not _reasoning_is_final_reply(s.get("text") or "", reply_preview)
        ]
    else:
        steps = [
            s for s in all_steps
            if s.get("type") != "reasoning"
            or not _reasoning_is_final_reply(s.get("text") or "", reply_preview)
        ]
    reason = (response_reasoning or "").strip()
    if reason and not _reasoning_is_final_reply(reason, reply_preview):
        # Avoid duplicate if we already got the same reasoning from the thread (final JSON)
        if not steps or (steps[-1].get("text") or "").strip() != reason:
            steps.append({"type": "reasoning", "text": reason})
    return steps
