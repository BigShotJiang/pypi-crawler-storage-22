# TOPSIS Python Package

## Installation
```bash
pip install Topsis-Abhishek-102316027
