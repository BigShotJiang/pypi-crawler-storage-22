from setuptools import setup, find_packages

setup(
    name="Topsis-Abhishek-102316027",
    version="1.0.0",
    author="Abhishek Gupta",
    author_email="agupta2_be23@thapar.edu",
    description="A Python package for TOPSIS multi-criteria decision making",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=["pandas", "numpy"],
    entry_points={
    'console_scripts': [
        'topsis=topsis_abhishek_102316027.topsis:main'
    ]
    },
)
