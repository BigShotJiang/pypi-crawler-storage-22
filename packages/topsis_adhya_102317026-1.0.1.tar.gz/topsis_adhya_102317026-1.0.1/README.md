# Topsis-Adhya-102317026

A Python implementation of TOPSIS (Technique for Order Preference by Similarity to Ideal Solution) for multi-criteria decision making.

---

## TOPSIS

TOPSIS is a multi-criteria decision analysis method which ranks alternatives based on their distance from:

- Ideal Best Solution
- Ideal Worst Solution

The best alternative should have the shortest distance from the ideal best and the farthest from the ideal worst.

---

## Installation

```bash
pip install Topsis-Adhya-102317026

topsis <InputDataFile> <Weights> <Impacts> <OutputResultFileName>

