from setuptools import setup, find_packages

setup(
    name='Topsis-Adhya-102317026',
    version='1.0.1',
    author='Adhya Koul',
    description='TOPSIS implementation for multi-criteria decision making',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    packages=find_packages(),
    install_requires=[
        'pandas',
        'numpy'
    ],
    entry_points={
        'console_scripts': [
            'topsis=topsis.topsis:main'
        ]
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)

