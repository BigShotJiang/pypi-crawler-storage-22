import sys
import pandas as pd
import numpy as np


def topsis(input_file, weights, impacts, output_file):

    
    try:
        data = pd.read_csv(input_file)
    except FileNotFoundError:
        print("Error: File not found.")
        sys.exit()


    if data.shape[1] < 3:
        print("Error: Input file must contain three or more columns.")
        sys.exit()

    
    decision_matrix = data.iloc[:, 1:]
    try:
        decision_matrix = decision_matrix.astype(float)
    except:
        print("Error: From 2nd to last columns must contain numeric values only.")
        sys.exit()

  
    weights = weights.split(',')
    impacts = impacts.split(',')


    if len(weights) != len(impacts) or len(weights) != decision_matrix.shape[1]:
        print("Error: Number of weights, impacts and columns must be same.")
        sys.exit()


    for impact in impacts:
        if impact not in ['+', '-']:
            print("Error: Impacts must be either '+' or '-'.")
            sys.exit()

    weights = np.array(weights, dtype=float)
    norm = decision_matrix / np.sqrt((decision_matrix**2).sum())

    weighted = norm * weights

    
    ideal_best = []
    ideal_worst = []

    for i in range(len(impacts)):
        if impacts[i] == '+':
            ideal_best.append(weighted.iloc[:, i].max())
            ideal_worst.append(weighted.iloc[:, i].min())
        else:
            ideal_best.append(weighted.iloc[:, i].min())
            ideal_worst.append(weighted.iloc[:, i].max())

    ideal_best = np.array(ideal_best)
    ideal_worst = np.array(ideal_worst)

    # Step 4: Separation Measures
    s_best = np.sqrt(((weighted - ideal_best)**2).sum(axis=1))
    s_worst = np.sqrt(((weighted - ideal_worst)**2).sum(axis=1))

    
    score = s_worst / (s_best + s_worst)

    data['Topsis Score'] = score
    data['Rank'] = score.rank(method='max', ascending=False).astype(int)

    
    data.to_csv(output_file, index=False)

    print("Success: Result saved to", output_file)


def main():
    if len(sys.argv) != 5:
        print("Usage: python <program.py> <InputDataFile> <Weights> <Impacts> <OutputResultFileName>")
        sys.exit()

    input_file = sys.argv[1]
    weights = sys.argv[2]
    impacts = sys.argv[3]
    output_file = sys.argv[4]

    topsis(input_file, weights, impacts, output_file)


if __name__ == "__main__":
    main()

