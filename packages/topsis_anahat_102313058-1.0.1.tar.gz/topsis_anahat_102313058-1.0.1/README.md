# TOPSIS Package

## Installation
pip install Topsis-Anahat-102313058

## Usage
topsis <input_file> <weights> <impacts> <output_file>

## Example
topsis data.csv "1,1,1,2" "+,+,-,+" result.csv
