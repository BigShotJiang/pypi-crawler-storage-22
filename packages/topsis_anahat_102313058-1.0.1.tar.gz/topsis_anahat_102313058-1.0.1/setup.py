from setuptools import setup, find_packages

setup(
    name="Topsis-Anahat-102313058",
    version="1.0.1",
    author="Anahat",
    description="TOPSIS implementation using Python",
    packages=find_packages(),
    install_requires=["pandas", "numpy"],
    entry_points={
        'console_scripts': [
            'topsis=topsis_anahat_102313058.topsis:topsis'
        ]
    }
)
