import sys
import pandas as pd
import numpy as np

def error(msg):
    print(f"Error: {msg}")
    sys.exit(1)

def main():
    # Correct number of parameters
    if len(sys.argv) != 5:
        error("Incorrect number of parameters.\nUsage: python topsis.py <InputFile> <Weights> <Impacts> <OutputFile>")

    input_file = sys.argv[1]
    weights = sys.argv[2]
    impacts = sys.argv[3]
    output_file = sys.argv[4]
    
    #Message for wrong inputs
    #File Handling
    try:
        data = pd.read_csv(input_file)
    except FileNotFoundError:
        error("Input file not found.")

    if data.shape[1] < 3:
        error("Input file must contain three or more columns.")

    #Numeric Validation
    try:
        matrix = data.iloc[:, 1:].astype(float)
    except ValueError:
        error("From 2nd to last columns must contain numeric values only.")

    #Weights & Impacts
    try:
        weights = list(map(float, weights.split(',')))
    except:
        error("Weights must be numeric and separated by commas.")

    impacts = impacts.split(',')

    if len(weights) != matrix.shape[1] or len(impacts) != matrix.shape[1]:
        error("Number of weights, impacts, and criteria columns must be equal.")

    for i in impacts:
        if i not in ['+', '-']:
            error("Impacts must be either '+' or '-'.")

    # TOPSIS Steps
    # Step 1: Normalize
    norm = matrix / np.sqrt((matrix ** 2).sum())

    # Step 2: Weighting
    weighted = norm * weights

    # Step 3: Ideal best & worst
    ideal_best = []
    ideal_worst = []

    for i in range(len(impacts)):
        if impacts[i] == '+':
            ideal_best.append(weighted.iloc[:, i].max())
            ideal_worst.append(weighted.iloc[:, i].min())
        else:
            ideal_best.append(weighted.iloc[:, i].min())
            ideal_worst.append(weighted.iloc[:, i].max())

    ideal_best = np.array(ideal_best)
    ideal_worst = np.array(ideal_worst)

    # Step 4: Distance
    dist_best = np.sqrt(((weighted - ideal_best) ** 2).sum(axis=1))
    dist_worst = np.sqrt(((weighted - ideal_worst) ** 2).sum(axis=1))

    # Step 5: Score
    score = dist_worst / (dist_best + dist_worst)

    # Step 6: Rank
    data['Topsis Score'] = score
    data['Rank'] = data['Topsis Score'].rank(ascending=False, method='dense').astype(int)

    # Output
    data.to_csv(output_file, index=False)
    print(f"TOPSIS result saved to {output_file}")

if __name__ == "__main__":
    main()
