# Topsis-Anoushka-102303955

[![PyPI Version](https://img.shields.io/pypi/v/topsis-anoushka-102303955.svg)](https://pypi.org/project/topsis-anoushka-102303955/)

This package implements the TOPSIS method.

## Installation
```bash
pip install Topsis-Anoushka-102303955
