# Topsis-Anshul-102303930

[![PyPI version](https://badge.fury.io/py/Topsis-Anshul-102303930.svg)](https://badge.fury.io/py/Topsis-Anshul-102303930)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## 📌 Description

This package implements the **TOPSIS (Technique for Order Preference by Similarity to Ideal Solution)** method, a multi-criteria decision-making (MCDM) approach used to rank alternatives based on their distance from an ideal best and an ideal worst solution.

TOPSIS is widely used in various domains including:
- Product selection and comparison
- Supplier evaluation
- Project prioritization
- Performance assessment
- Resource allocation

## ⚙️ Installation

Install the package using pip:

```bash
pip install Topsis-Anshul-102303930
```

## 🚀 Usage

After installation, the `topsis` command becomes available in your terminal.

### Basic Syntax

```bash
topsis <input_csv> <weights> <impacts> <output_csv>
```

### Parameters

| Parameter | Description |
|-----------|-------------|
| `input_csv` | Path to the CSV file containing the decision matrix |
| `weights` | Comma-separated numerical weights for each criterion |
| `impacts` | Comma-separated impacts (`+` for benefit, `-` for cost) |
| `output_csv` | Path where the output CSV file will be saved |

### Example Commands

With quotes:
```bash
topsis sample.csv "1,1,1,1" "+,-,+,+" output.csv
```

Without quotes:
```bash
topsis sample.csv 1,1,1,1 +,-,+,+ output.csv
```

## 📊 Example

### Input File (`sample.csv`)

A CSV file showing data for different mobile handsets with varying features:

```csv
Model,Storage space(in gb),Camera(in MP),Price(in $),Looks(out of 5)
M1,16,12,250,5
M2,16,8,200,3
M3,32,16,300,4
M4,32,8,275,4
M5,16,16,225,2
```

### Decision Criteria

**Weights Vector:** `[0.25, 0.25, 0.25, 0.25]`

**Impacts Vector:** `[+, +, -, +]`
- Storage space: + (more is better)
- Camera: + (more is better)
- Price: - (less is better)
- Looks: + (more is better)

### Command

```bash
topsis sample.csv "0.25,0.25,0.25,0.25" "+,+,-,+" output.csv
```

### Output

The output file will contain the original data with two additional columns:

```
TOPSIS RESULTS
-----------------------------
Model  Storage space(in gb)  Camera(in MP)  Price(in $)  Looks(out of 5)  P-Score    Rank
M1     16                    12             250          5                0.534277   3
M2     16                    8              200          3                0.308368   5
M3     32                    16             300          4                0.691632   1
M4     32                    8              275          4                0.534737   2
M5     16                    16             225          2                0.401046   4
```

**Interpretation:** M3 ranks highest (Rank 1) with the best TOPSIS score of 0.691632, making it the optimal choice among the alternatives.

## 📋 Input File Requirements

1. **CSV Format:** The input file must be in CSV format
2. **First Column:** Should contain the names/identifiers of alternatives
3. **Remaining Columns:** Should contain numerical values for each criterion
4. **No Missing Values:** All cells must have valid numerical data (except the first column)
5. **Minimum Criteria:** At least 2 criteria columns are required

## ⚠️ Important Notes

- The number of weights must match the number of criteria columns
- The number of impacts must match the number of criteria columns
- Weights should be positive numbers
- Impacts should be either `+` (benefit) or `-` (cost)
- All criterion values must be numeric

## 🔧 How TOPSIS Works

1. **Normalize** the decision matrix
2. **Apply weights** to the normalized matrix
3. **Identify** ideal best and ideal worst solutions
4. **Calculate** the distance of each alternative from ideal best and ideal worst
5. **Compute** the performance score (closeness coefficient)
6. **Rank** alternatives based on performance scores

## 📝 License

This project is licensed under the MIT License.

## 👤 Author

**Anshul**  
Roll Number: 102303930

## 🤝 Contributing

Contributions, issues, and feature requests are welcome!

## 📧 Contact

For any queries or suggestions, please feel free to reach out.

---

**Note:** This package was created as part of an academic project for UCS654 - Prescriptive Analytics.
