from setuptools import setup, find_packages

setup(
    name="topsis-anshul-102303930",
    version="1.0.2",
    author="Anshul Kaushal",
    author_email="anshulkaushal27@gmail.com",
    description="A Python package for TOPSIS multi-criteria decision making",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "pandas",
        "numpy"
    ],
    entry_points={
        "console_scripts": [
            "topsis=topsis_anshul.topsis:main"
        ]
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
