# Topsis-Arush-102303889

This package implements the TOPSIS method.

## Installation
```bash
pip install Topsis-Arush-102303889
