\# TOPSIS Python Package



\## Installation

pip install Topsis-Chahat-102303831



\## Usage

topsis data.xlsx "1,1,1,1,1" "+,+,+,+,+" output.csv



\## Description

This package implements the TOPSIS method for multi-criteria decision making.



