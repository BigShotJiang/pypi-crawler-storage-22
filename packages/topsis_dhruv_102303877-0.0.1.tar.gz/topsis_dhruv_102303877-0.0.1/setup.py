from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="TOPSIS-Dhruv-102303877",
    version="0.0.1",
    author="Dhruv Gupta",
    author_email="dhruv@example.com",
    description="TOPSIS implementation using Python",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=["pandas", "numpy"],
    entry_points={
        "console_scripts": [
            "topsis=topsis_dhruv_102303877.topsis:main"
        ]
    },
)