# TOPSIS Package

This is a Python package for implementing TOPSIS.

## Installation

```bash
pip install Topsis-Gaurang-102303907