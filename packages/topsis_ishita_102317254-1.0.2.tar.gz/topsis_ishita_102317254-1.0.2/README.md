# Topsis-Ishita-102317254

A Python package that implements the **Technique for Order Preference by Similarity to Ideal Solution (TOPSIS)** for **Multi-Criteria Decision Making (MCDM)** problems.

This package works as:
- A **Command Line Interface (CLI)** tool
- A **reusable Python module**

It generates an output CSV file containing the **TOPSIS Score** and **Rank** for each alternative.

---

## Installation

Install the package directly from PyPI:

```bash
pip install Topsis-Ishita-102317254

```

## Quick Start

### Command Syntax

After installation, use the topsis command from the terminal:

```bash
topsis <InputDataFile> <Weights> <Impacts> <ResultFileName>
```

### Parameters

The command accepts exactly 4 parameters:
| Parameter | Format | Example | Description |
|------------|-------------------------|--------------|---------------------------------|
| Input file | Path string | `"data.csv"` | Path to your CSV file |
| Weights | Comma-separated string | `"1,1,1,1,2"` | Weight for each criterion |
| Impacts | Comma-separated string | `"+,+,+,-,+"` | `+` for benefit, `-` for cost |
| Output file| Path string | `"result.csv"` | Where to save results |

### Example Execution

Grab an input csv or excel file strictly adheres to the following structure:

1. The file must have at least 3 columns- Candidate Identifier column followed by min. 2 criteria.
2. The first column must contain the names/IDs of the alternatives.
3. Criteria columns must contain only numeric values.

A sample dataset file (`data.csv`) is shown below:

| Fund Name | P1   | P2   | P3  | P4   | P5    |
| --------- | ---- | ---- | --- | ---- | ----- |
| M1        | 0.94 | 0.88 | 6.5 | 38.8 | 11.78 |
| M2        | 0.69 | 0.48 | 4.4 | 59.8 | 16.34 |
| M3        | 0.62 | 0.38 | 3.8 | 41.3 | 11.53 |
| M4        | 0.63 | 0.40 | 6.1 | 50.5 | 14.41 |
| M5        | 0.78 | 0.61 | 5.2 | 67.8 | 18.60 |
| M6        | 0.61 | 0.37 | 5.6 | 34.6 | 10.30 |
| M7        | 0.69 | 0.48 | 4.8 | 57.8 | 15.94 |
| M8        | 0.75 | 0.56 | 6.1 | 62.4 | 17.45 |

Run the following command through the terminal.

```bash
topsis data.csv "1,1,1,1,2" "+,+,+,-,+" result.csv
```

The output file (`result.csv`) generated will look like this:
| Fund Name | P1 | P2 | P3 | P4 | P5 | Topsis Score | Rank |
| --------- | ---- | ---- | --- | ---- | ----- | ------------ | ---- |
| M1 | 0.94 | 0.88 | 6.5 | 38.8 | 11.78 | 0.5840384375 | 2 |
| M2 | 0.69 | 0.48 | 4.4 | 59.8 | 16.34 | 0.4489649725 | 4 |
| M3 | 0.62 | 0.38 | 3.8 | 41.3 | 11.53 | 0.2617528226 | 8 |
| M4 | 0.63 | 0.40 | 6.1 | 50.5 | 14.41 | 0.3974983163 | 6 |
| M5 | 0.78 | 0.61 | 5.2 | 67.8 | 18.60 | 0.5917499869 | 1 |
| M6 | 0.61 | 0.37 | 5.6 | 34.6 | 10.30 | 0.3159064238 | 7 |
| M7 | 0.69 | 0.48 | 4.8 | 57.8 | 15.94 | 0.4461587287 | 5 |
| M8 | 0.75 | 0.56 | 6.1 | 62.4 | 17.45 | 0.5714234615 | 3 |

Sample input file is available in the `sample_data/` folder.
Sample output file is available in the `results/` folder.

## Validations Implemented

- Input file existence check
- Minimum column requirement
- Numeric validation for criteria columns
- Matching count of weights and impacts
- Impact validation (+ or - only)
- Proper command-line argument count

## License

This project is licensed under the MIT License.
See the license text at:
https://opensource.org/licenses/MIT

## Author

Ishita Goyal<br>
Penultimate-Year Student, BE-CSE<br>
Thapar Institute of Engineering and Technology, Patiala

#### Let's Connect: **<a href="https://github.com/Ishita-01"> GitHub | <a href="www.linkedin.com/in/ishita-goyall"> LinkedIn | [Email](mailto:igoyal1_be23@thapar.edu)**

<br>

_If you find this package useful, please ⭐ star it on GitHub!_