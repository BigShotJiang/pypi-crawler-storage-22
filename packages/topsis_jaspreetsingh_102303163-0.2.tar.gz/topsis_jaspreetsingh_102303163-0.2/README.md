# Topsis-JaspreetSingh-102303163

TOPSIS implementation using command line.

## Installation

pip install Topsis-JaspreetSingh-102303163

## Usage

topsis data.csv "1,1,1,2" "+,+,-,+" result.csv
