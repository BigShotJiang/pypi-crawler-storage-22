from setuptools import setup, find_packages

setup(
    name='Topsis-JaspreetSingh-102303163',
    version='0.2',
    author='Jaspreet Singh',
    author_email='jaspreetsinghupkar@gmail.com',
    description='TOPSIS implementation using command line',
    packages=find_packages(),
    install_requires=['pandas', 'numpy'],
    entry_points={
        'console_scripts': [
            'topsis=topsis_jaspreet_102303163.topsis:main',
        ],
    },
)
