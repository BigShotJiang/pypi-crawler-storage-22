# Topsis-Kanishka-102317165

A Python package to implement TOPSIS (Technique for Order Preference by Similarity to Ideal Solution).

## Installation

```bash
pip install Topsis-Kanishka-102317165
```
