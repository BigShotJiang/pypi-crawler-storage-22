# TOPSIS Package

## Installation

pip install Topsis-Kritika-ROLL

## Usage

topsis data.csv "1,1,1,2,1" "+,+,-,+,+" result.csv

## Description

This package implements TOPSIS using command line arguments.
