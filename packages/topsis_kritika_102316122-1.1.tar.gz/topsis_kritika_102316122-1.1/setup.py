from setuptools import setup, find_packages

setup(
    name="Topsis-Kritika-102316122",
    version="1.1",
    packages=find_packages(),
    install_requires=["pandas","numpy"],
    entry_points={
        "console_scripts": [
            "topsis=topsis_kritika.topsis:main"
        ]
    },
    author="Kritika",
    description="TOPSIS command line package",
)
