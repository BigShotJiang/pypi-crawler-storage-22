from setuptools import setup, find_packages

setup(
    name="Topsis-Laksh-102317172",
    version="1.0.1",
    author="Laksh Gupta",
    description="TOPSIS implementation in Python",
    packages=find_packages(),
    install_requires=["pandas", "numpy"],
    entry_points={
        'console_scripts': [
            'topsis=topsis.topsis:main'
        ]
    },
)
