import sys
import pandas as pd
import numpy as np

def error(msg):
    print("Error:", msg)
    sys.exit()

def main():
    if len(sys.argv) != 5:
        error("Usage: topsis input.csv \"1,1,1\" \"+,+,+\" output.csv")

    input_file = sys.argv[1]
    weights_input = sys.argv[2]
    impacts_input = sys.argv[3]
    output_file = sys.argv[4]

    try:
        df = pd.read_csv(input_file)
    except FileNotFoundError:
        error("File not found")

    if df.shape[1] < 3:
        error("File must contain at least 3 columns")

    try:
        data = df.iloc[:, 1:].astype(float)
    except:
        error("Non numeric values found")

    weights = weights_input.split(',')
    impacts = impacts_input.split(',')

    if len(weights) != data.shape[1] or len(impacts) != data.shape[1]:
        error("Weights and impacts must match columns")

    weights = np.array(weights, dtype=float)

    for i in impacts:
        if i not in ['+', '-']:
            error("Impacts must be + or -")

    norm = data / np.sqrt((data**2).sum(axis=0))
    weighted = norm * weights

    ideal_best = []
    ideal_worst = []

    for i in range(len(impacts)):
        if impacts[i] == '+':
            ideal_best.append(weighted.iloc[:, i].max())
            ideal_worst.append(weighted.iloc[:, i].min())
        else:
            ideal_best.append(weighted.iloc[:, i].min())
            ideal_worst.append(weighted.iloc[:, i].max())

    ideal_best = np.array(ideal_best)
    ideal_worst = np.array(ideal_worst)

    dist_best = np.sqrt(((weighted - ideal_best) ** 2).sum(axis=1))
    dist_worst = np.sqrt(((weighted - ideal_worst) ** 2).sum(axis=1))

    score = dist_worst / (dist_best + dist_worst)

    df['Topsis Score'] = score
    df['Rank'] = df['Topsis Score'].rank(method='max', ascending=False)

    df.to_csv(output_file, index=False)
    print("Result saved to", output_file)
