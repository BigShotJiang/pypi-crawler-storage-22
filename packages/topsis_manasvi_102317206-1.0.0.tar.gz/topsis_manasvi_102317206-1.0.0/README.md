TOPSIS command line tool.



Usage:

topsis <inputfile> <weights> <impacts> <outputfile>



