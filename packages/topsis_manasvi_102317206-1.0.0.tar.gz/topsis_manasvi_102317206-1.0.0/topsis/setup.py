from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setup(
    name="topsis-manasvi-102317206",
    version="1.0.0",
    author="Manasvi",
    author_email="yourmail@example.com",
    description="TOPSIS command line tool",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=["pandas", "numpy"],
    entry_points={
        "console_scripts": [
            "topsis=topsis.topsis:main",
        ],
    },
)
