import sys
import pandas as pd
import numpy as np


def run_topsis(input_file, weights, impacts, output_file):

    weights = weights.split(',')
    impacts = impacts.split(',')

    try:
        data = pd.read_csv(input_file, encoding="latin1", on_bad_lines="skip")
    except FileNotFoundError:
        print("File not found.")
        return

    for col in data.columns[1:]:
        if not pd.api.types.is_numeric_dtype(data[col]):
            print("All columns from 2nd onwards must be numeric.")
            return

    if len(weights) != len(impacts) or len(weights) != (data.shape[1] - 1):
        print("Number of weights, impacts and numeric columns must match.")
        return

    for i in impacts:
        if i not in ['+', '-']:
            print("Impacts must be either + or -.")
            return

    try:
        weights = np.array([float(i) for i in weights])
    except:
        print("Weights must be numeric.")
        return

    matrix = data.iloc[:, 1:].values.astype(float)

    norm = np.sqrt((matrix ** 2).sum(axis=0))
    normalized = matrix / norm

    weighted = normalized * weights

    best = []
    worst = []

    for i in range(len(impacts)):
        if impacts[i] == '+':
            best.append(weighted[:, i].max())
            worst.append(weighted[:, i].min())
        else:
            best.append(weighted[:, i].min())
            worst.append(weighted[:, i].max())

    best = np.array(best)
    worst = np.array(worst)

    dist_best = np.sqrt(((weighted - best) ** 2).sum(axis=1))
    dist_worst = np.sqrt(((weighted - worst) ** 2).sum(axis=1))

    score = dist_worst / (dist_best + dist_worst)
    rank = score.argsort()[::-1] + 1

    data["Topsis Score"] = score
    data["Rank"] = rank

    data.to_csv(output_file, index=False)


def main():
    if len(sys.argv) != 5:
        print("Usage: python topsis.py <InputDataFile> <Weights> <Impacts> <OutputFile>")
        sys.exit(1)

    run_topsis(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])


if __name__ == "__main__":
    main()
