from setuptools import setup,find_packages

setup(
    name="Topsis-Naman-102317229",
    version="1.0",
    packages=find_packages(),
    install_requires=["pandas","numpy","openpyxl"],
    entry_points={
        "console_scripts":[
            "topsis=topsis.topsis:main"
        ]
    }
)
