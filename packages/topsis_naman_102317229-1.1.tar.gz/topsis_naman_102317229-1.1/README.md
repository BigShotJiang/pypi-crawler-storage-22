
# TOPSIS Decision Support System

A Python implementation of the **Technique for Order Preference by Similarity to Ideal Solution (TOPSIS)** used for multi-criteria decision making.  
This project provides both a **PyPI package** and a **Flask-based web application** that allows users to upload datasets, assign weights and impacts, and receive ranked results via email.

---

## 🚀 Features

- Implements the TOPSIS algorithm from scratch
- Accepts CSV/XLSX datasets
- Supports customizable weights and impacts
- Generates TOPSIS score and rank automatically
- Published as an installable PyPI package
- Integrated with a simple and user-friendly Flask web interface
- Automated result delivery through email
- Input validation for weights, impacts, and email format

---

## 📦 PyPI Package

Install directly using:

```bash
pip install Topsis-Naman-102317229
```

PyPI Link:  
https://pypi.org/project/Topsis-Naman-102317229/

---

## 💻 Local Usage

After installing the package:

```python
from topsis.topsis import main

main()
```

Or via command line:

```bash
topsis <inputfile> <weights> <impacts> <outputfile>
```

Example:

```bash
topsis data.csv "1,1,1,1" "+,+,-,+" result.csv
```

---

## 🌐 Live Web Application

Access the deployed web app here:

👉 https://naman25.pythonanywhere.com

### Web App Workflow:
1. Upload the dataset  
2. Enter weights (comma separated)  
3. Enter impacts (+ or -)  
4. Provide your email address  
5. Receive the ranked result file via email  

---

## 📊 Input File Requirements

- First column: Alternative names (non-numeric)
- Remaining columns: Numeric criteria values
- Minimum 3 columns required
- Number of weights must equal number of impacts
- Impacts must be either **+** (benefit) or **-** (cost)

---

## 🛠 Tech Stack

- Python  
- Pandas & NumPy  
- Flask  
- SMTP (Email Automation)  
- PyPI Packaging  

---

## 📁 Project Structure

```
topsis-project/
│
├── topsis/                # PyPI package
├── templates/             # HTML templates
├── uploads/               # Temporary files
├── app.py                 # Flask application
├── setup.py               # Packaging configuration
├── requirements.txt
└── README.md
```

---

## 👨‍💻 Author

**Naman Kumar**  
Thapar Institute of Engineering & Technology  

---

## 📜 License

This project is licensed under the **MIT License**.

---

⭐ If you find this project useful, consider giving it a star on GitHub!
