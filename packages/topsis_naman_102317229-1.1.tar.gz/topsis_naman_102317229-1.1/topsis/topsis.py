import sys
import pandas as pd
import numpy as np
import os


def calc(f,w,i,o):

    if not os.path.exists(f):
        raise Exception("file not found")

    if f.endswith('.csv'):
        df=pd.read_csv(f)
    elif f.endswith('.xlsx'):
        df=pd.read_excel(f)
    else:
        raise Exception("invalid file format")

    if df.shape[1]<3:
        raise Exception("minimum 3 columns required")

    x=df.iloc[:,1:]

    try:
        x=x.astype(float)
    except:
        raise Exception("non numeric data found")

    w=w.split(',')
    i=i.split(',')

    if len(w)!=x.shape[1] or len(i)!=x.shape[1]:
        raise Exception("weights/impacts mismatch")

    try:
        w=np.array(w,dtype=float)
    except:
        raise Exception("weights must be numeric")

    for k in i:
        if k not in ['+','-']:
            raise Exception("impacts must be + or -")

    n=np.sqrt((x**2).sum())
    x=x/n

    x=x*w

    pb=[]
    nb=[]

    for j in range(len(i)):
        if i[j]=='+':
            pb.append(x.iloc[:,j].max())
            nb.append(x.iloc[:,j].min())
        else:
            pb.append(x.iloc[:,j].min())
            nb.append(x.iloc[:,j].max())

    pb=np.array(pb)
    nb=np.array(nb)

    dp=np.sqrt(((x-pb)**2).sum(axis=1))
    dn=np.sqrt(((x-nb)**2).sum(axis=1))

    sc=dn/(dp+dn)

    df['Topsis Score']=sc
    df['Rank']=sc.rank(ascending=False,method='max').astype(int)

    df.to_csv(o,index=False)


def main():

    if len(sys.argv)!=5:
        print("usage: python <file> <input> <weights> <impacts> <output>")
        sys.exit(1)

    f=sys.argv[1]
    w=sys.argv[2]
    i=sys.argv[3]
    o=sys.argv[4]

    try:
        calc(f,w,i,o)
        print("done")
    except Exception as e:
        print("error:",e)
        sys.exit(1)


if __name__=="__main__":
    main()
