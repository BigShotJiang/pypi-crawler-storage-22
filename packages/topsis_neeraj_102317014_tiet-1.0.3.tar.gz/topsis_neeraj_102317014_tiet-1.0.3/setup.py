from setuptools import setup, find_packages

setup(
    name="topsis-neeraj-102317014-tiet",
    version="1.0.3",
    author="neeraj",
    author_email="thisis.neerajbhardwaj@gmail.com",
    description="A Python package for TOPSIS calculation",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=['pandas','numpy'],
    entry_points={
        'console_scripts': [
            'topsis=topsis_neeraj_102317014.topsis:main',
        ],
    },
)