import pandas as pd
import sys
import os
import numpy as np

def main():
    if len(sys.argv) != 5:
        print("Error: Invalid number of arguments.")
        print("Usage: python topsis.py <InputDataFile> <Weights> <Impacts> <ResultFileName>")
        return

    input_file  = sys.argv[1]
    weights_str = sys.argv[2]
    impacts_str = sys.argv[3]
    result_file = sys.argv[4]

    if not os.path.isfile(input_file):
        print(f"Error: File '{input_file}' not found.")
        return

    try:
        data = pd.read_excel(input_file)
        if len(data.columns) < 3:
            print("Error: Input file must contain at least 3 columns.")
            return

        numeric_data = data.iloc[:,1:].values
        if not np.issubdtype(numeric_data.dtype, np.number):
            print("Error: Columns from 2nd to last must contain numeric values only.")
            return

        weights = [float(w) for w in weights_str.split(',')]
        impacts = impacts_str.split(',')

        if len(weights) != numeric_data.shape[1] or len(impacts) != numeric_data.shape[1]:
            print("Error: Number of weights/impacts must match the number of numeric columns.")
            return

        for imp in impacts:
            if imp not in ['+', '-']:
                print("Error: Impacts must be either '+' or '-'.")
                return

        # --- TOPSIS ALGORITHM ---
        norm_data = numeric_data / np.sqrt((numeric_data**2).sum(axis=0))
        weighted_data = norm_data * weights

        ideal_best = []
        ideal_worst = []
        
        for i in range(len(impacts)):
            if impacts[i] == '+':
                ideal_best.append(max(weighted_data[:,i]))
                ideal_worst.append(min(weighted_data[:,i]))
            else:
                ideal_best.append(min(weighted_data[:,i]))
                ideal_worst.append(max(weighted_data[:,i]))

        dist_best = np.sqrt(((weighted_data - ideal_best)**2).sum(axis=1))
        dist_worst = np.sqrt(((weighted_data - ideal_worst)**2).sum(axis=1))

        scores = dist_worst / (dist_best + dist_worst)
        data['Topsis Score'] = scores
        data['Rank'] = data['Topsis Score'].rank(ascending=False).astype(int)

        data.to_excel(result_file, index=False)
        print(f"Success: Results saved to {result_file}")

    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()