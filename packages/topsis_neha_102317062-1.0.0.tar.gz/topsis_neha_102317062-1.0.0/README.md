# Topsis-Neha-102317062

## Installation
pip install Topsis-Neha-102317062

## Usage
topsis input.csv "1,1,1,1,1" "+,+,+,-,+" output.csv

## Description
This package implements TOPSIS method to rank alternatives.
