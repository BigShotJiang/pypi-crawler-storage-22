from setuptools import setup, find_packages

setup(
    name="Topsis-Neha-102317062",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "pandas",
        "numpy"
    ],
    entry_points={
        'console_scripts': [
            'topsis=topsis.topsis:main',
        ],
    },
    author="Neha",
    description="TOPSIS implementation using Python",
)
