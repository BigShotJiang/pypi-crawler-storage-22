# TOPSIS Python Package

## Installation
```bash
pip install Topsis-Nidhi-102316094
