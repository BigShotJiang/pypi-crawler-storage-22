from setuptools import setup, find_packages

setup(
    name="topsis_nidhi_102316094",
    version="1.0.6",
    author="Nidhi Mittal",
    author_email="nidhimittal627@gmail.com",
    description="A Python package for TOPSIS multi-criteria decision making",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=["pandas", "numpy"],
    entry_points={
    'console_scripts': [
        'topsis=topsis_nidhi_102316094.topsis:main'
    ]
    },
)
