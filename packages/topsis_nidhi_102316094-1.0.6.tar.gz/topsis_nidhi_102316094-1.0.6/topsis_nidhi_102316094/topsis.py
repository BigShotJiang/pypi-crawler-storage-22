import sys
import pandas as pd
import numpy as np

def error(msg):
    print("Error:", msg)
    sys.exit(1)

def topsis(input_file, weights, impacts, output_file):
    # Read input file
    try:
        df = pd.read_csv(input_file)
    except FileNotFoundError:
        error("Input file not found")

    if df.shape[1] < 3:
        error("Input file must contain at least three columns")

    data = df.iloc[:, 1:]

    # Check numeric values
    try:
        data = data.astype(float)
    except:
        error("Columns from 2nd to last must contain numeric values only")

    weights = weights.split(',')
    impacts = impacts.split(',')

    if len(weights) != data.shape[1]:
        error("Number of weights must match number of criteria")

    if len(impacts) != data.shape[1]:
        error("Number of impacts must match number of criteria")

    weights = np.array(weights, dtype=float)

    for i in impacts:
        if i not in ['+', '-']:
            error("Impacts must be either + or -")

    # Step-1: Normalize the matrix
    norm = np.sqrt((data ** 2).sum())
    normalized = data / norm

    # Step-2: Weighted normalized matrix
    weighted = normalized * weights

    # Step-3: Ideal best & worst
    ideal_best = []
    ideal_worst = []

    for i in range(len(impacts)):
        if impacts[i] == '+':
            ideal_best.append(weighted.iloc[:, i].max())
            ideal_worst.append(weighted.iloc[:, i].min())
        else:
            ideal_best.append(weighted.iloc[:, i].min())
            ideal_worst.append(weighted.iloc[:, i].max())

    ideal_best = np.array(ideal_best)
    ideal_worst = np.array(ideal_worst)

    # Step-4: Distance measures
    dist_best = np.sqrt(((weighted - ideal_best) ** 2).sum(axis=1))
    dist_worst = np.sqrt(((weighted - ideal_worst) ** 2).sum(axis=1))

    # Step-5: Topsis score
    score = dist_worst / (dist_best + dist_worst)

    df["Topsis Score"] = score
    df["Rank"] = df["Topsis Score"].rank(ascending=False).astype(int)

    df.to_csv(output_file, index=False)
    print("TOPSIS Result saved to", output_file)

def main():
    if len(sys.argv) != 5:
        error("Usage: topsis <InputFile> <Weights> <Impacts> <OutputFile>")
    topsis(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])

