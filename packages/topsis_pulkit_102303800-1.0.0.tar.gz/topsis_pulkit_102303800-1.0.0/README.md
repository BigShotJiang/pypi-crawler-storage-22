# Topsis-Pulkit-102303800

A Python CLI tool implementing the TOPSIS method.

## Usage

topsis <inputfile> <weights> <impacts> <outputfile>

Example:

topsis data.csv "1,1,1,2" "+,+,-,+" result.csv

## Input Rules
- File must be .csv or .xlsx
- Minimum 3 columns
- First column is label
- Remaining columns numeric
