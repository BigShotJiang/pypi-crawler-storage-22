from setuptools import setup, find_packages

setup(
    name="Topsis-Pulkit-102303800",
    version="1.0.0",
    author="Pulkit Goyal",
    description="CLI-based TOPSIS implementation",
    packages=find_packages(),
    install_requires=["pandas", "numpy", "openpyxl"],
    entry_points={
        'console_scripts': [
            'topsis=topsis_pulkit_102303800.topsis:main',
        ],
    },
    python_requires='>=3.6',
)
