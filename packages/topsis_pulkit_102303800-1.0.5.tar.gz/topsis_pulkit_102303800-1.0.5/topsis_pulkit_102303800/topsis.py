import os
import sys
import pandas as pd
import numpy as np
import argparse


def topsis(input_file, weights, impacts, output_file):
    if not os.path.exists(input_file):
        sys.exit("Error: File not found")

    if not (input_file.endswith('.csv') or input_file.endswith('.xlsx')):
        sys.exit("Error: Only CSV and XLSX files allowed")

    df = pd.read_csv(input_file) if input_file.endswith('.csv') else pd.read_excel(input_file)

    if df.shape[1] < 3:
        sys.exit("Error: File must have 3+ columns")

    data = df.iloc[:, 1:].values

    try:
        data = data.astype(float)
    except:
        sys.exit("Error: Data columns must be numeric")

    weights = list(map(float, weights.split(',')))
    impacts = impacts.split(',')

    if len(weights) != data.shape[1] or len(impacts) != data.shape[1]:
        sys.exit("Error: Number of weights and impacts must equal number of columns")

    if any(i not in ['+', '-'] for i in impacts):
        sys.exit("Error: Impacts must be + or -")

    norm = data / np.sqrt((data**2).sum(axis=0))
    weighted = norm * weights

    ideal_best = np.max(weighted, axis=0)
    ideal_worst = np.min(weighted, axis=0)

    for i, imp in enumerate(impacts):
        if imp == '-':
            ideal_best[i], ideal_worst[i] = ideal_worst[i], ideal_best[i]

    dist_best = np.sqrt(((weighted - ideal_best)**2).sum(axis=1))
    dist_worst = np.sqrt(((weighted - ideal_worst)**2).sum(axis=1))

    score = dist_worst / (dist_best + dist_worst)

    df["Topsis Score"] = score
    df["Rank"] = score.argsort()[::-1] + 1

    df.to_csv(output_file, index=False)
    print("TOPSIS calculation complete. Output saved.")


def main():
    parser = argparse.ArgumentParser(description="TOPSIS Decision Making Tool")
    parser.add_argument("input_file")
    parser.add_argument("weights")
    parser.add_argument("impacts")
    parser.add_argument("output_file")
    args = parser.parse_args()

    topsis(args.input_file, args.weights, args.impacts, args.output_file)
