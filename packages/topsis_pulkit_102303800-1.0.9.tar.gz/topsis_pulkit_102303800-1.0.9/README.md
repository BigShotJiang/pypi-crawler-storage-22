# Topsis-Pulkit-102303800

A command-line Python implementation of the **TOPSIS (Technique for Order Preference by Similarity to Ideal Solution)** algorithm used in **Multi-Criteria Decision Making (MCDM)**.

![Python](https://img.shields.io/badge/Python-3.6+-blue.svg)
![License](https://img.shields.io/badge/License-MIT-green.svg)
![PyPI](https://img.shields.io/pypi/v/Topsis-Pulkit-102303800)

---

## 📌 Features

- Supports **CSV** and **Excel (.xlsx)** input files  
- Implements full TOPSIS ranking method  
- Validates user input and handles common errors  
- Produces decision scores and ranks  
- Lightweight and easy-to-use CLI tool  

---

## 🧮 About TOPSIS

TOPSIS ranks alternatives based on their distance from the **ideal best** and **ideal worst** solutions.

---

## usage

topsis <inputfile> <weights> <impacts> <outputfile>


---

## 🚀 Installation

```bash
pip install Topsis-Pulkit-102303800

---

##Author

Pulkit Goyal


