from setuptools import setup, find_packages

setup(
    name="Topsis-Pulkit-102303800",
    version="1.0.9",
    author="Pulkit Goyal",
    description="TOPSIS CLI tool for Multi-Criteria Decision Making (MCDM) with CSV and Excel support",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",

    url="https://github.com/Pulkitgoyal10/Topsis-Pulkit-102303800",
    project_urls={
        "Source Code": "https://github.com/Pulkitgoyal10/Topsis-Pulkit-102303800",
        "Bug Tracker": "https://github.com/Pulkitgoyal10/Topsis-Pulkit-102303800/issues",
    },

    packages=find_packages(),
    install_requires=["pandas", "numpy", "openpyxl"],
    entry_points={
        'console_scripts': [
            'topsis=topsis_pulkit_102303800.topsis:main',
        ],
    },
    python_requires='>=3.6',
)
