# Topsis-Rakshita-102303498

A Python package implementing the TOPSIS method for Multiple Criteria Decision Making (MCDM).

## Installation
pip install Topsis-Rakshita-102303498

## Usage
topsis input.csv "1,1,1,1" "+,+,-,+" output.csv
