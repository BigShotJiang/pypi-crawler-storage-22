from setuptools import setup, find_packages

setup(
    name="Topsis-Rakshita-102303498",
    version="1.0.1",
    packages=find_packages(),
    install_requires=["numpy", "pandas"],
    entry_points={
        "console_scripts": [
            "topsis=topsis.topsis:main"
        ]
    },
    author="Rakshita Garg",
    description="TOPSIS implementation for MCDM problems",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
)
