import pandas as pd
import numpy as np
import sys


def topsis(input_file, weights, impacts, output_file):
    data = pd.read_csv(input_file)

    if len(weights) != len(impacts) or len(weights) != data.shape[1] - 1:
        raise ValueError("Number of weights, impacts and criteria must match")

    matrix = data.iloc[:, 1:].values.astype(float)

    # Step 1: Normalize
    norm = np.sqrt((matrix ** 2).sum(axis=0))
    matrix = matrix / norm

    # Step 2: Apply weights
    matrix = matrix * weights

    # Step 3: Ideal best and worst
    ideal_best = []
    ideal_worst = []

    for i in range(len(impacts)):
        if impacts[i] == '+':
            ideal_best.append(matrix[:, i].max())
            ideal_worst.append(matrix[:, i].min())
        else:
            ideal_best.append(matrix[:, i].min())
            ideal_worst.append(matrix[:, i].max())

    ideal_best = np.array(ideal_best)
    ideal_worst = np.array(ideal_worst)

    # Step 4: Distances
    dist_best = np.sqrt(((matrix - ideal_best) ** 2).sum(axis=1))
    dist_worst = np.sqrt(((matrix - ideal_worst) ** 2).sum(axis=1))

    # Step 5: Score
    

    score = dist_worst / (dist_best + dist_worst)

    data["Topsis Score"] = score
    data["Rank"] = pd.Series(score).rank(ascending=False).astype(int)

    data.to_csv(output_file, index=False)
    print("Output file created:", output_file)




def main():
    if len(sys.argv) != 5:
        print("Usage: topsis <input_file> <weights> <impacts> <output_file>")
        sys.exit(1)

    input_file = sys.argv[1]
    weights = list(map(float, sys.argv[2].split(",")))
    impacts = sys.argv[3].split(",")
    output_file = sys.argv[4]

    topsis(input_file, weights, impacts, output_file)


if __name__ == "__main__":
    main()
