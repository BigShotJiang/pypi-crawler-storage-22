from setuptools import setup, find_packages

setup(
    name="Topsis-Samairaa-102317219",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        "pandas",
        "numpy"
    ],
    entry_points={
        "console_scripts": [
            "topsis=topsis_package.topsis:main"
        ]
    },
    author="Samairaa",
    description="TOPSIS Implementation in Python"
)
