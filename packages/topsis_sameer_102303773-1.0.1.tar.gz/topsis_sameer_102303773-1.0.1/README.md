# 🚀 TOPSIS Python Package

This package implements **TOPSIS** (Technique for Order Preference by Similarity to Ideal Solution),  
a 📊 multi-criteria decision-making technique used to rank alternatives based on their distance from ideal best and worst solutions.

---

## 📦 Installation

Install the package using `pip`:

```bash
pip install Topsis-Sameer-102303773
```
