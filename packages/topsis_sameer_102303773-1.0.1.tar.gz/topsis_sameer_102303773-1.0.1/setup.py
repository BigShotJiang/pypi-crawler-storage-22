from setuptools import setup, find_packages
from pathlib import Path
from setuptools import setup

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()
setup(
    name="Topsis-Sameer-102303773",
    version="1.0.1",
    author="Sameer Rai",
    author_email="your_email@gmail.com",
    description="A Python package implementing the TOPSIS method",
    packages=find_packages(),
    install_requires=[
        "pandas",
        "numpy"
    ],
    entry_points={
        "console_scripts": [
            "topsis=topsis.topsis:main"
        ]
    },
)
