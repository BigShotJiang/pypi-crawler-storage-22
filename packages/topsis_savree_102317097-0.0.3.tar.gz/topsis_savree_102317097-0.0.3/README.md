# Topsis-Savree-102317097

A Python package implementing the **TOPSIS (Technique for Order Preference by Similarity to Ideal Solution)** method for multi-criteria decision making.

---

## 📌 About TOPSIS

TOPSIS is a ranking technique used to evaluate multiple alternatives based on several criteria.  
The best alternative is the one:

- Closest to the ideal best solution  
- Farthest from the ideal worst solution  

This package allows users to perform TOPSIS analysis easily via command line.

---

## ⚙️ Installation

Install directly from PyPI:

```bash
pip install Topsis-Savree-102317097
```

---

## 🚀 Usage (Command Line)

```bash
topsis-s102317097 <InputDataFile> <Weights> <Impacts> <ResultFileName>
```

### Example:

```bash
topsis-s102317097 input.csv "1,1,1" "+,+,-" result.csv
```

---

## 📂 Input File Requirements

- CSV file with **at least three columns**
- First column → Alternative names
- Remaining columns → Numeric criteria values only

### Example Input (input.csv)

| Option | Cost | Quality | Durability |
|--------|------|---------|------------|
| A1     | 250  | 7       | 8          |
| A2     | 200  | 6       | 9          |
| A3     | 300  | 8       | 7          |

---

## 📊 Parameters

### Weights
Comma-separated numeric values  
Example: `"1,1,1"`

### Impacts
Comma-separated signs  

- `+` → Benefit criterion (higher is better)  
- `-` → Cost criterion (lower is better)  

Example: `"+,+,-"`

---

## 📈 Output

The result CSV file will include:

- Original data  
- **Topsis Score**  
- **Rank**

Higher score → Better alternative.

---

## 🛠 Error Handling

The package validates:

- Incorrect number of weights  
- Incorrect number of impacts  
- Non-numeric data in criteria columns  
- Invalid impact symbols  
- Missing input file  

---

## 👤 Author

Savree Dohar  
Roll Number: 102317097  

---
