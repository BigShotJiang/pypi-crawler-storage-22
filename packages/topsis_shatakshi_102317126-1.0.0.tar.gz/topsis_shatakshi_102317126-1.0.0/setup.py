from setuptools import setup, find_packages

setup(
    name="topsis-Shatakshi-102317126",  
    version="1.0.0",
    description="TOPSIS Implementation in Python",
    author="Shatakshi Tripathi",
    packages=find_packages(),
    install_requires=[
        "pandas",
        "numpy"
    ],
    entry_points={
        'console_scripts': [
            'topsis=run_topsis:main'
        ]
    },
)
