import pandas as pd
import numpy as np


def validate_dataframe(df, weights, impacts):
    if df.shape[1] < 3:
        raise ValueError("Input file must contain at least three columns.")

    try:
        df.iloc[:, 1:] = df.iloc[:, 1:].apply(pd.to_numeric)
    except Exception:
        raise ValueError("Columns from 2nd onward must be numeric.")

    weights = weights.split(',')
    impacts = impacts.split(',')

    if len(weights) != df.shape[1] - 1 or len(impacts) != df.shape[1] - 1:
        raise ValueError("Weights and impacts count mismatch.")

    if any(i not in ['+', '-'] for i in impacts):
        raise ValueError("Impacts must be '+' or '-'.")

    return np.array(weights, dtype=float), impacts


def calculate_topsis(input, weights, impacts, output_file):
    df = pd.read_csv(input)

    weights, impacts = validate_dataframe(df, weights, impacts)

    data = df.iloc[:, 1:].values.astype(float)

    norm = data / np.sqrt((data ** 2).sum(axis=0))
    weighted = norm * weights

    ideal_best = []
    ideal_worst = []

    for i in range(weighted.shape[1]):
        if impacts[i] == '+':
            ideal_best.append(weighted[:, i].max())
            ideal_worst.append(weighted[:, i].min())
        else:
            ideal_best.append(weighted[:, i].min())
            ideal_worst.append(weighted[:, i].max())

    ideal_best = np.array(ideal_best)
    ideal_worst = np.array(ideal_worst)

    dist_best = np.sqrt(((weighted - ideal_best) ** 2).sum(axis=1))
    dist_worst = np.sqrt(((weighted - ideal_worst) ** 2).sum(axis=1))

    score = dist_worst / (dist_best + dist_worst)
    rank = score.argsort()[::-1] + 1

    df['Topsis Score'] = score
    df['Rank'] = rank

    df.to_csv(output_file, index=False)
