## Topsis-Smarth-102497023

A Python package implementing the Technique for Order of Preference by Similarity to Ideal Solution (TOPSIS) for Multi-Criteria Decision Making (MCDM).
This package works as a **Command Line Tool** and generates an output CSV file containing the **TOPSIS Score** and **Rank**.

## Installation

Install the package from PyPI using:

```bash
pip install Topsis-Smarth-102497023
```

## Quick Start

### Command Syntax
Once installed, you can use the `topsis` command directly from your terminal, following the syntax given below.

```bash
topsis <InputDataFile> <Weights> <Impacts> <ResultFileName>
```
### Parameters
The command accepts exactly 4 parameters:
| Parameter   | Format                 | Example       | Description                     |
|------------|-------------------------|--------------|---------------------------------|
| Input file | Path string             | `"data.csv"` | Path to your CSV file           |
| Weights    | Comma-separated string  | `"1,1,1,1"`  | Weight for each criterion       |
| Impacts    | Comma-separated string  | `"+,+,-,+"`  | `+` for benefit, `-` for cost   |
| Output file| Path string             | `"result.csv"` | Where to save results         |

### Example Execution
Grab an input csv or excel file strictly adheres to the following structure:
1. The file must have at least 3 columns- Candidate Identifier column followed by min. 2 criteria.
2. The first column must contain the names/IDs of the alternatives.
3. Criteria columns must contain only numeric values.

A sample dataset file (`data1.csv`) is shown below:

| Model | Corr | Rseq | RMSE | Accuracy |
|------|------|------|------|----------|
| M1 | 0.79 | 0.62 | 1.25 | 60.89 |
| M2 | 0.66 | 0.44 | 2.89 | 63.07 |
| M3 | 0.56 | 0.31 | 1.57 | 62.87 |
| M4 | 0.82 | 0.67 | 2.68 | 70.19 |
| M5 | 0.75 | 0.56 | 1.30 | 80.39 |

Run the following command through the terminal.
```bash
topsis data1.csv "1,1,1,1" "+,+,-,+" output_data1.csv
```

The output file (`output_data1.csv`) generated will look like this:
| Model | Corr | Rseq | RMSE | Accuracy | Topsis Score | Rank |
| ----- | ---- | ---- | ---- | -------- | ------------ | ---- |
| M1    | 0.79 | 0.62 | 1.25 | 60.89    | 0.7722       | 2    |
| M2    | 0.66 | 0.44 | 2.89 | 63.07    | 0.2256       | 5    |
| M3    | 0.56 | 0.31 | 1.57 | 62.87    | 0.4389       | 4    |
| M4    | 0.82 | 0.67 | 2.68 | 70.19    | 0.5239       | 3    |
| M5    | 0.75 | 0.56 | 1.30 | 80.39    | 0.8114       | 1    |

Sample input and output files are available in the `sample_data/` folder.

## Important Notes

- The command accepts exactly four parameters.
- Number of weights and impacts must match number of criteria columns.
- Impacts must be only `+` or `-`.
- Make sure the criteria columns must be numeric as mentioned earlier.
- No cell should be empty.

## License

This project is licensed under the **MIT License**. See [LICENSE](https://opensource.org/license/MIT) for more information.

## Author

Smarth Kaushal<br>
Penultimate-Year Student, BE-CSE<br>
Thapar Institute of Engineering and Technology, Patiala

#### Let's Connect: **<a href="https://github.com/Smarth2005"> GitHub | <a href="http://www.linkedin.com/in/smarth-kaushal-02a1092b2"> LinkedIn | [Email](mailto:skaushal1_be23@thapar.edu)**

<br>

*If you find this package useful, please ⭐ star it on GitHub!*


