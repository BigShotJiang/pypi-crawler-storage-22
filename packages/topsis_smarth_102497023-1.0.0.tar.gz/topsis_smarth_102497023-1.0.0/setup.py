from setuptools import setup, find_packages
import os

# Function to read the README file for the long description
def read(fname):
    return open(os.path.join(os.path.dirname(__file__), fname), encoding="utf-8").read()

setup(
    name="Topsis-Smarth-102497023", 
    version="1.0.0",
    author="Smarth Kaushal",
    author_email="skaushal1007@gmail.com",
    description="A command-line Python package to implement the TOPSIS method.",
    long_description=read('README.md'),
    long_description_content_type="text/markdown",
    license="MIT",
    url="https://github.com/Smarth2005/A1-Topsis",
    
    # Since setup.py is in the same folder as the package folder, use find_packages()
    packages=find_packages(), 
    
    install_requires=[
        'pandas',
        'numpy',
        'openpyxl', 
    ],
    
    entry_points={
        'console_scripts': [
            # command=folder_name.file_name:function_name
            'topsis=topsis_smarth_102497023.topsis:main',
        ],
    },
    
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Education",
    ],
    python_requires='>=3.6',
)