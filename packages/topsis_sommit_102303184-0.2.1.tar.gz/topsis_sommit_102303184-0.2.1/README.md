# Topsis-Sommit-102303184

A Python package to perform TOPSIS (Technique for Order Preference by Similarity to Ideal Solution) for multi-criteria decision making using the command line.

## Installation

Install the package from PyPI:

```bash
pip install Topsis-Sommit-102303184
```

## Usage

Run TOPSIS from the command line as follows:

```bash
topsis <InputDataFile> <Weights> <Impacts> <ResultFileName>
```

### Example

```bash
topsis data.csv "1,1,1,2" "+,+,-,+" result.csv
```

## Input File Format

- Input file must be a CSV file
- First column contains alternatives (names)
- Remaining columns contain numerical criteria values

### Sample Input (`data.csv`)

```
Model,P1,P2,P3,P4
M1,250,16,12,5
M2,200,18,8,4
M3,300,14,10,6
```

## Parameters

- **InputDataFile**: Path to input CSV file  
- **Weights**: Comma-separated numerical weights  
- **Impacts**: Comma-separated impacts (`+` for benefit, `-` for cost)  
- **ResultFileName**: Name of output CSV file  

## Output

The output CSV file will contain:
- **Topsis Score**
- **Rank** (1 indicates the best alternative)

## Author

Sommit  
Roll No: 102303184

## License

MIT License
