from setuptools import setup, find_packages

setup(
    name="Topsis-Sommit-102303184",
    version="0.2.1",
    author="Sommit",
    author_email="sommit312@gmail.com",
    description="TOPSIS implementation using Python",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),  # this will include 'topsis' folder
    include_package_data=True,
    install_requires=[
        "pandas",
        "numpy"
    ],
    entry_points={
        "console_scripts": [
            "topsis=topsis.topsis:main"
        ]
    },
    keywords=["topsis", "mcdm", "decision making", "ranking"],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Education",
        "Programming Language :: Python :: 3",
        "Operating System :: Microsoft :: Windows",
        "Operating System :: Unix",
        "Operating System :: MacOS",
    ],
    python_requires=">=3.7",
)
