# Topsis-Sparsh_Gupta-102317228

A Python implementation of the **TOPSIS (Technique for Order Preference by Similarity to Ideal Solution)** method for multi-criteria decision making.

---

# 📌 What is TOPSIS?

TOPSIS is a Multi-Criteria Decision Making (MCDM) technique used to rank alternatives based on:

- Distance from the Ideal Best solution
- Distance from the Ideal Worst solution

The best alternative is:
- Closest to the Ideal Best
- Farthest from the Ideal Worst

---

# ⚙️ Mathematical Steps

1. Normalize the decision matrix
2. Multiply by weights
3. Determine Ideal Best and Ideal Worst
4. Compute Euclidean distances
5. Calculate relative closeness score
6. Rank alternatives

---

# 📊 Algorithm Flow (Mermaid Diagram)

```mermaid
flowchart TD
    A[Start] --> B[Read Input File]
    B --> C[Validate Data]
    C --> D[Normalize Matrix]
    D --> E[Apply Weights]
    E --> F[Find Ideal Best & Worst]
    F --> G[Compute Distances]
    G --> H[Calculate TOPSIS Score]
    H --> I[Rank Alternatives]
    I --> J[Save Output File]
    J --> K[End]
```



# 📥 Installation

Install from PyPI:

```bash
pip install Topsis-Sparsh Gupta-102317228
```

Or install locally:

```bash
pip install .
```

---

# 🚀 Usage (Command Line)

```bash
topsis <InputFile> <Weights> <Impacts> <OutputFile>
```

### Example

```bash
topsis data.xlsx "1,1,1,2" "+,+,-,+" result.csv
```

---

# 📄 Input Format

The input file must:

- Contain at least 3 columns
- First column: Identifier (Name/ID)
- Remaining columns: Numeric values only
- Weights must be comma-separated
- Impacts must be '+' or '-'

### Example Input

| Fund | P1 | P2 | P3 | P4 |
|------|----|----|----|----|
| M1 | 0.67 | 0.45 | 5.6 | 12.56 |
| M2 | 0.6 | 0.36 | 3.5 | 14.47 |

---

# 📤 Output Format

The output file contains:

- Original data
- Topsis Score column
- Rank column

Higher score = Better rank

---

# 🧮 Mathematical Formula

### Normalization

\[
R_{ij} = \frac{x_{ij}}{\sqrt{\sum x_{ij}^2}}
\]

### Weighted Matrix

\[
V_{ij} = w_j \cdot R_{ij}
\]

### Distance Measures

\[
S_i^+ = \sqrt{\sum (V_{ij} - A_j^+)^2}
\]

\[
S_i^- = \sqrt{\sum (V_{ij} - A_j^-)^2}
\]

### Topsis Score

\[
C_i = \frac{S_i^-}{S_i^+ + S_i^-}
\]

---

# 🛑 Error Handling

The program checks for:

- File not found
- Incorrect number of parameters
- Less than 3 columns
- Non-numeric values
- Mismatch in weights and impacts
- Invalid impacts

---

# 🧠 Requirements

- Python 3.7+
- numpy
- pandas
- openpyxl

---

# 👤 Author

Sparsh Gupta  
102317228 

---

# 📜 License

MIT License
