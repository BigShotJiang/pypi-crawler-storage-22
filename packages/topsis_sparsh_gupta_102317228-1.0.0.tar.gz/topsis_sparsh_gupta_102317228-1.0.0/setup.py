from setuptools import setup, find_packages

setup(
    name="Topsis-Sparsh_Gupta-102317228",   
    version="1.0.0",
    author="Sparsh_Gupta",
    author_email="gupta.sparsh004@gmail.com",
    description="A Python implementation of the TOPSIS (Technique for Order Preference by Similarity to Ideal Solution) method.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "pandas",
        "openpyxl"
    ],
    entry_points={
        "console_scripts": [
            "topsis=topsis.topsis:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)
