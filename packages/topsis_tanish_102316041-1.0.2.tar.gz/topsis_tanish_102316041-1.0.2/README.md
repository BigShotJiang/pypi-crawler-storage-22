# TOPSIS Python Package

## Installation
```bash
pip install Topsis-Tanish-10123456
