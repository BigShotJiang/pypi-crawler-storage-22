from setuptools import setup, find_packages

setup(
    name="Topsis-Tanish-102316041",
    version="1.0.2",
    author="Tanish Gupta",
    author_email="tgupta_be23@thapar.edu",
    description="A Python package for TOPSIS multi-criteria decision making",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=["pandas", "numpy"],
    entry_points={
    'console_scripts': [
        'topsis=topsis_tanish_102316041.topsis:main'
    ]
    },
)
