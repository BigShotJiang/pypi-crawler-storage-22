from setuptools import setup, find_packages

setup(
    name="Topsis-Tnisha-10230951",
    version="1.0.1",
    packages=find_packages(),
    install_requires=["pandas", "numpy"],
    entry_points={
        'console_scripts': [
            'topsis=topsis_tnisha_102303951.topsis:main',
        ],
    },
    author="Tnisha",
    description="A Python package for TOPSIS decision making",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
)
