# Topsis-Vansh-102303806

This package provides an implementation of the TOPSIS (Technique for Order Preference by Similarity to Ideal Solution) method using Python.

## What is TOPSIS?
TOPSIS is a multi-criteria decision-making technique that ranks alternatives based on their closeness to the ideal best solution and distance from the ideal worst solution.

## Installation
```bash
pip install Topsis-Vansh-102303806
