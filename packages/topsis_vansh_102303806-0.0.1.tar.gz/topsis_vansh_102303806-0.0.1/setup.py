from setuptools import setup, find_packages

setup(
    name="Topsis-Vansh-102303806",
    version="0.0.1",
    author="Vansh",
    author_email="vsingla1_be23@thapar.edu",
    description="TOPSIS implementation as a Python package",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=["pandas", "numpy"],
    entry_points={
        "console_scripts": [
            "topsis=topsis_vansh_102303806.topsis:main"
        ]
    },
    python_requires=">=3.7",
)