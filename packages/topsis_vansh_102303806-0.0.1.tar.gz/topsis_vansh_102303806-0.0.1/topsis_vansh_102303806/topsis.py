import sys
import pandas as pd
import numpy as np


def topsis(input_file, weights, impacts, output_file):
    # File not found handling
    try:
        data = pd.read_csv(input_file)
    except FileNotFoundError:
        print("Error: Input file not found")
        sys.exit(1)

    # Minimum columns check
    if data.shape[1] < 3:
        print("Error: Input file must contain at least three columns")
        sys.exit(1)

    # Extract criteria columns (2nd to last)
    criteria = data.iloc[:, 1:]

    # Numeric check
    try:
        criteria = criteria.apply(pd.to_numeric)
    except Exception:
        print("Error: Criteria columns must contain numeric values only")
        sys.exit(1)

    # Parse weights and impacts
    weights = weights.split(',')
    impacts = impacts.split(',')

    # Length consistency check
    if len(weights) != len(impacts) or len(weights) != criteria.shape[1]:
        print("Error: Number of weights, impacts, and criteria columns must be equal")
        sys.exit(1)

    # Impact validation
    for impact in impacts:
        if impact not in ['+', '-']:
            print("Error: Impacts must be either '+' or '-'")
            sys.exit(1)

    weights = np.array(weights, dtype=float)

    # Step 1: Normalization
    norm_matrix = criteria / np.sqrt((criteria ** 2).sum())

    # Step 2: Weighted normalization
    weighted_matrix = norm_matrix * weights

    # Step 3: Ideal best and worst
    ideal_best = []
    ideal_worst = []

    for i in range(len(impacts)):
        if impacts[i] == '+':
            ideal_best.append(weighted_matrix.iloc[:, i].max())
            ideal_worst.append(weighted_matrix.iloc[:, i].min())
        else:
            ideal_best.append(weighted_matrix.iloc[:, i].min())
            ideal_worst.append(weighted_matrix.iloc[:, i].max())

    ideal_best = np.array(ideal_best)
    ideal_worst = np.array(ideal_worst)

    # Step 4: Distance measures
    distance_best = np.sqrt(((weighted_matrix - ideal_best) ** 2).sum(axis=1))
    distance_worst = np.sqrt(((weighted_matrix - ideal_worst) ** 2).sum(axis=1))

    # Step 5: TOPSIS score
    topsis_score = distance_worst / (distance_best + distance_worst)

    # Append results
    data["Topsis Score"] = topsis_score
    data["Rank"] = data["Topsis Score"].rank(ascending=False).astype(int)

    # Output file
    data.to_csv(output_file, index=False)
    print("TOPSIS analysis completed successfully")


def main():
    if len(sys.argv) != 5:
        print("Usage: topsis <input_file> <weights> <impacts> <output_file>")
        sys.exit(1)

    _, input_file, weights, impacts, output_file = sys.argv
    topsis(input_file, weights, impacts, output_file)


if __name__ == "__main__":
    main()
