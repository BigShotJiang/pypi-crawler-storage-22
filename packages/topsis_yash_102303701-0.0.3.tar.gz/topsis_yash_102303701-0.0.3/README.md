## TOPSIS-Yash-102303701

TOPSIS-Yash-102303701 is a Python package that implements the **TOPSIS (Technique for Order of Preference by Similarity to Ideal Solution)** method for multi-criteria decision-making (MCDM).

TOPSIS is widely used in decision analysis to rank alternatives based on their distance from an ideal best solution and an ideal worst solution. This package allows users to apply TOPSIS easily on tabular data stored in CSV files through a simple command-line interface.

The package validates inputs, handles common user errors, and generates a ranked output with TOPSIS scores, making it suitable for academic assignments as well as real-world decision analysis problems.

---

## Features
- Command-line implementation of TOPSIS
- Supports multiple decision criteria
- Handles both beneficial (+) and non-beneficial (-) attributes
- Input validation for files, weights, and impacts
- Outputs TOPSIS score and rank for each alternative

---

## Installation

Install the package directly from PyPI:

pip install TOPSIS-Yash-102303701

---

## Usage

Run the TOPSIS analysis from the command line:

topsis input.csv "1,1,1,2,1" "+,+,-,+,+" output.csv

---

## Input File Format
- The input file must be a CSV file
- The first column should contain the names of alternatives
- All remaining columns must contain numeric values only
- The number of weights and impacts must match the number of criteria columns

---

## Output File
The output CSV file contains:
- All original input columns
- A new column named **Topsis Score**
- A new column named **Rank**, where rank 1 indicates the best alternative

---

## Author
Yash Sharma  
Roll No: 102303701  

---

## License
This project is developed for academic and educational purposes.
