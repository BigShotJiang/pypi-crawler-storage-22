# torch-kindling
A library of pytorch modules to accelerate research and code recycling
