# Alias for torch_log_wmse_audio_quality
from torch_log_wmse import *