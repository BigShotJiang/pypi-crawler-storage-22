from electrodes.electrodes_define import find_electrodes

find_electrodes(outputBasename="./biv_ecg/fiberfolder/mesh",
                basenameLVmesh="./biv_ecg/fiberfolder/mesh_LV",
                basenameLVuvc="./biv_ecg/UVC_i",
                outfolder="./biv_ecg/fiberfolder/output")