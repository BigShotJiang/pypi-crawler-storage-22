# Copyright (c) TorchGeo Contributors. All rights reserved.
# Licensed under the MIT License.

"""TorchGeo: datasets, samplers, transforms, and pre-trained models for geospatial data.

This library is part of the `PyTorch <https://pytorch.org/>`_ project. PyTorch is an
open source machine learning framework.

The :mod:`torchgeo` package consists of popular datasets, model architectures, and
common image transformations for geospatial data.
"""

__author__ = 'Adam J. Stewart'
__version__ = '0.9.0'
