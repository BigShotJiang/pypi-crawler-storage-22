# Copyright (c) TorchGeo Contributors. All rights reserved.
# Licensed under the MIT License.

"""Potsdam dataset."""

import os
from collections.abc import Callable
from typing import ClassVar

import matplotlib.pyplot as plt
import numpy as np
import rasterio
import torch
from matplotlib.figure import Figure
from PIL import Image
from torch import Tensor

from .errors import DatasetNotFoundError
from .geo import NonGeoDataset
from .utils import (
    Path,
    Sample,
    check_integrity,
    draw_semantic_segmentation_masks,
    extract_archive,
    rgb_to_mask,
)


class Potsdam2D(NonGeoDataset):
    """Potsdam 2D Semantic Segmentation dataset.

    The `Potsdam <https://www.isprs.org/resources/datasets/benchmarks/UrbanSemLab/2d-sem-label-potsdam.aspx>`__
    dataset is a dataset for urban semantic segmentation used in the 2D Semantic Labeling
    Contest - Potsdam. This dataset uses the "4_Ortho_RGBIR.zip" and "5_Labels_all.zip"
    files to create the train/test sets used in the challenge. The dataset can be
    requested at the challenge homepage. Note, the server contains additional data
    for 3D Semantic Labeling which are currently not supported.

    Dataset format:

    * images are 4-channel geotiffs
    * masks are 3-channel geotiffs with unique RGB values representing the class

    Dataset classes:

    0. Clutter/background
    1. Impervious surfaces
    2. Building
    3. Low Vegetation
    4. Tree
    5. Car

    If you use this dataset in your research, please cite the following paper:

    * https://doi.org/10.5194/isprsannals-I-3-293-2012

    .. versionadded:: 0.2
    """

    filenames = ('4_Ortho_RGBIR.zip', '5_Labels_all.zip')
    md5s = ('c4a8f7d8c7196dd4eba4addd0aae10c1', 'cf7403c1a97c0d279414db')
    image_root = '4_Ortho_RGBIR'
    splits: ClassVar[dict[str, list[str]]] = {
        'train': [
            'top_potsdam_2_10',
            'top_potsdam_2_11',
            'top_potsdam_2_12',
            'top_potsdam_3_10',
            'top_potsdam_3_11',
            'top_potsdam_3_12',
            'top_potsdam_4_10',
            'top_potsdam_4_11',
            'top_potsdam_4_12',
            'top_potsdam_5_10',
            'top_potsdam_5_11',
            'top_potsdam_5_12',
            'top_potsdam_6_10',
            'top_potsdam_6_11',
            'top_potsdam_6_12',
            'top_potsdam_6_7',
            'top_potsdam_6_8',
            'top_potsdam_6_9',
            'top_potsdam_7_10',
            'top_potsdam_7_11',
            'top_potsdam_7_12',
            'top_potsdam_7_7',
            'top_potsdam_7_8',
            'top_potsdam_7_9',
        ],
        'test': [
            'top_potsdam_5_15',
            'top_potsdam_6_15',
            'top_potsdam_6_13',
            'top_potsdam_3_13',
            'top_potsdam_4_14',
            'top_potsdam_6_14',
            'top_potsdam_5_14',
            'top_potsdam_2_13',
            'top_potsdam_4_15',
            'top_potsdam_2_14',
            'top_potsdam_5_13',
            'top_potsdam_4_13',
            'top_potsdam_3_14',
            'top_potsdam_7_13',
        ],
    }
    classes = (
        'Clutter/background',
        'Impervious surfaces',
        'Building',
        'Low Vegetation',
        'Tree',
        'Car',
    )
    colormap = (
        (255, 0, 0),
        (255, 255, 255),
        (0, 0, 255),
        (0, 255, 255),
        (0, 255, 0),
        (255, 255, 0),
    )

    def __init__(
        self,
        root: Path = 'data',
        split: str = 'train',
        transforms: Callable[[Sample], Sample] | None = None,
        checksum: bool = False,
    ) -> None:
        """Initialize a new Potsdam dataset instance.

        Args:
            root: root directory where dataset can be found
            split: one of "train" or "test"
            transforms: a function/transform that takes input sample and its target as
                entry and returns a transformed version
            checksum: if True, check the MD5 of the downloaded files (may be slow)

        Raises:
            AssertionError: If *split* is invalid.
            DatasetNotFoundError: If dataset is not found.
        """
        assert split in self.splits
        self.root = root
        self.split = split
        self.transforms = transforms
        self.checksum = checksum

        self._verify()

        self.files = []
        for name in self.splits[split]:
            image = os.path.join(root, self.image_root, name) + '_RGBIR.tif'
            mask = os.path.join(root, name) + '_label.tif'
            if os.path.exists(image) and os.path.exists(mask):
                self.files.append(dict(image=image, mask=mask))

    def __getitem__(self, index: int) -> Sample:
        """Return an index within the dataset.

        Args:
            index: index to return

        Returns:
            data and label at that index
        """
        image = self._load_image(index)
        mask = self._load_target(index)
        sample = {'image': image, 'mask': mask}

        if self.transforms is not None:
            sample = self.transforms(sample)

        return sample

    def __len__(self) -> int:
        """Return the number of data points in the dataset.

        Returns:
            length of the dataset
        """
        return len(self.files)

    def _load_image(self, index: int) -> Tensor:
        """Load a single image.

        Args:
            index: index to return

        Returns:
            the image
        """
        path = self.files[index]['image']
        with rasterio.open(path) as f:
            array = f.read()
            tensor = torch.from_numpy(array).float()
            return tensor

    def _load_target(self, index: int) -> Tensor:
        """Load the target mask for a single image.

        Args:
            index: index to return

        Returns:
            the target mask
        """
        path = self.files[index]['mask']
        with Image.open(path) as img:
            array: np.typing.NDArray[np.uint8] = np.array(img.convert('RGB'))
            array = rgb_to_mask(array, self.colormap)
            tensor = torch.from_numpy(array)
            # Convert from HxWxC to CxHxW
            tensor = tensor.to(torch.long)
        return tensor

    def _verify(self) -> None:
        """Verify the integrity of the dataset."""
        # Check if the files already exist
        if os.path.exists(os.path.join(self.root, self.image_root)):
            return

        # Check if .zip files already exists (if so extract)
        exists = []
        for filename, md5 in zip(self.filenames, self.md5s):
            filepath = os.path.join(self.root, filename)
            if os.path.isfile(filepath):
                if self.checksum and not check_integrity(filepath, md5):
                    raise RuntimeError('Dataset found, but corrupted.')
                exists.append(True)
                extract_archive(filepath)
            else:
                exists.append(False)

        if all(exists):
            return

        raise DatasetNotFoundError(self)

    def plot(
        self,
        sample: Sample,
        show_titles: bool = True,
        suptitle: str | None = None,
        alpha: float = 0.5,
    ) -> Figure:
        """Plot a sample from the dataset.

        Args:
            sample: a sample returned by :meth:`__getitem__`
            show_titles: flag indicating whether to show titles above each panel
            suptitle: optional string to use as a suptitle
            alpha: opacity with which to render predictions on top of the imagery

        Returns:
            a matplotlib Figure with the rendered sample
        """
        ncols = 1
        image1 = draw_semantic_segmentation_masks(
            sample['image'][:3], sample['mask'], alpha=alpha, colors=list(self.colormap)
        )
        if 'prediction' in sample:
            ncols += 1
            image2 = draw_semantic_segmentation_masks(
                sample['image'][:3],
                sample['prediction'],
                alpha=alpha,
                colors=list(self.colormap),
            )

        fig, axs = plt.subplots(ncols=ncols, figsize=(ncols * 10, 10))
        if ncols > 1:
            (ax0, ax1) = axs
        else:
            ax0 = axs

        ax0.imshow(image1)
        ax0.axis('off')
        if ncols > 1:
            ax1.imshow(image2)
            ax1.axis('off')

        if show_titles:
            ax0.set_title('Ground Truth')
            if ncols > 1:
                ax1.set_title('Predictions')

        if suptitle is not None:
            plt.suptitle(suptitle)

        return fig
