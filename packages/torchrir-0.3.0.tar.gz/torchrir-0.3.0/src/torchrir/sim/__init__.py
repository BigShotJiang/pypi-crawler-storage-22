"""Simulation engines and configuration for RIR generation.

Includes the ISM implementation (in ``torchrir.sim.ism``), directivity helpers,
and simulator interfaces for ISM plus placeholder ray-tracing/FDTD backends.
"""

from .config import SimulationConfig, default_config
from .ism import simulate_dynamic_rir, simulate_rir
from .directivity import directivity_gain, split_directivity
from .simulators import FDTDSimulator, ISMSimulator, RIRSimulator, RayTracingSimulator

__all__ = [
    "FDTDSimulator",
    "ISMSimulator",
    "RIRSimulator",
    "RayTracingSimulator",
    "SimulationConfig",
    "default_config",
    "directivity_gain",
    "simulate_dynamic_rir",
    "simulate_rir",
    "split_directivity",
]
