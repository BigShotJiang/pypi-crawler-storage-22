"""Visualization helpers for scenes and trajectories.

Provides static/dynamic plotting plus GIF animation utilities.
"""

from .animation import animate_scene_gif
from .io import plot_scene_and_save
from .scene import plot_scene_dynamic, plot_scene_static

__all__ = [
    "animate_scene_gif",
    "plot_scene_dynamic",
    "plot_scene_static",
    "plot_scene_and_save",
]
