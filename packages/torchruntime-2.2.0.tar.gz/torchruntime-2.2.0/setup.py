import setuptools

setuptools.setup(
    install_requires=["packaging"],
)
