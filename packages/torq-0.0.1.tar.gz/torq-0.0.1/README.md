# Torq

High-performance task queue for GPU workloads.

**Status: Coming Soon**

This package is under active development. Stay tuned!

## Features (planned)
- Lightweight task queue optimized for GPU jobs
- Redis-backed job persistence
- Worker auto-scaling
- Built-in monitoring and metrics
- Simple SDK for job submission

## Links
- GitHub: https://github.com/muid-io/torq
- Documentation: Coming soon
