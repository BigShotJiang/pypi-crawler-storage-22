"""Torq - High-performance task queue for GPU workloads."""
__version__ = "0.0.1"
