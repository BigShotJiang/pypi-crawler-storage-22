# Torq Client SDK

Python SDK for submitting jobs to Torq distributed GPU queue.

**Status: Coming Soon**

## Overview
Simple SDK to submit LLM inference jobs to Torq and retrieve results.

## Features (planned)
- Async/sync job submission
- Batch job support
- Priority queuing
- Result polling and callbacks
- Automatic retries

## Quick Start
```python
from torq_client import TorqClient

client = TorqClient("https://torq.muid.io")
job = client.submit(model="llama3", prompt="Hello!")
result = job.wait()
```

## Installation
```bash
pip install torq-client-sdk
```

## Links
- Main site: https://torq.muid.io
- Documentation: https://torq.muid.io/docs
