# Torq Worker

GPU worker component for Torq distributed job queue.

**Status: Coming Soon**

## Overview
Torq Worker runs on GPU machines and processes jobs from the Torq broker.

## Features (planned)
- Multiple LLM backend support (vLLM, SGLang, TGI)
- Auto-registration with broker
- Health monitoring and heartbeats
- Graceful shutdown and job recovery

## Installation
```bash
pip install torq-worker
```

## Links
- Main site: https://torq.muid.io
- Documentation: https://torq.muid.io/docs
