"""Torq Worker - GPU worker for distributed job queue."""
__version__ = "0.0.1"
