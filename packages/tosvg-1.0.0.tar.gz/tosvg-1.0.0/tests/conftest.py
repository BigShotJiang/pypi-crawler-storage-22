"""Shared test fixtures for the ToSVG SDK test suite."""

from __future__ import annotations

import pytest
import respx

from tosvg import AsyncToSVG, ToSVG

API_KEY = "tosvg_test_abcdefghijklmnopqrstuvwxyz1234"
BASE_URL = "https://tosvg.com/api/v1"

# Tiny 1×1 red PNG (67 bytes)
SAMPLE_IMAGE_BYTES = (
    b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01"
    b"\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde\x00"
    b"\x00\x00\x0cIDATx\x9cc\xf8\x0f\x00\x00\x01\x01\x00"
    b"\x05\x18\xd8N\x00\x00\x00\x00IEND\xaeB`\x82"
)

RATE_LIMIT_HEADERS = {
    "X-RateLimit-Limit": "1000",
    "X-RateLimit-Remaining": "999",
    "X-RateLimit-Reset": "1706860800",
}


@pytest.fixture()
def api_key() -> str:
    return API_KEY


@pytest.fixture()
def sample_image() -> bytes:
    return SAMPLE_IMAGE_BYTES


@pytest.fixture()
def client() -> ToSVG:
    """Create a sync ToSVG client with no retries for fast tests."""
    return ToSVG(
        api_key=API_KEY,
        base_url=BASE_URL,
        timeout=5,
        retry_on_rate_limit=False,
        max_retries=0,
    )


@pytest.fixture()
def async_client() -> AsyncToSVG:
    """Create an async ToSVG client with no retries for fast tests."""
    return AsyncToSVG(
        api_key=API_KEY,
        base_url=BASE_URL,
        timeout=5,
        retry_on_rate_limit=False,
        max_retries=0,
    )


@pytest.fixture()
def mock_api():
    """Activate ``respx`` mocking for all tests that need it."""
    with respx.mock(assert_all_called=False) as rsps:
        yield rsps
