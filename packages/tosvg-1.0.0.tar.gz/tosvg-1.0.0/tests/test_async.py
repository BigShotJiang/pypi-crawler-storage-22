"""Tests for the async client (AsyncToSVG)."""

from __future__ import annotations

import httpx
import pytest
import respx

from tests.conftest import BASE_URL, RATE_LIMIT_HEADERS, SAMPLE_IMAGE_BYTES
from tosvg import AsyncToSVG
from tosvg.enums import ColorMode
from tosvg.exceptions import AuthenticationError, ServerError
from tosvg.models.background import RemoveBackgroundResult
from tosvg.models.convert import ImageToSvgResult
from tosvg.models.info import HealthCheckResult
from tosvg.models.resize import ResizeImageResult


pytestmark = pytest.mark.asyncio


class TestAsyncConvert:
    """Async image-to-SVG conversion."""

    @respx.mock
    async def test_async_image_to_svg(self, async_client: AsyncToSVG) -> None:
        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "svg": "<svg/>",
                        "file_size": 50,
                        "conversion_time": 0.3,
                    },
                },
                headers=RATE_LIMIT_HEADERS,
            )
        )

        result = await async_client.convert.image_to_svg(SAMPLE_IMAGE_BYTES, color_mode=ColorMode.BW)

        assert isinstance(result, ImageToSvgResult)
        assert result.svg == "<svg/>"

    @respx.mock
    async def test_async_supported_formats(self, async_client: AsyncToSVG) -> None:
        respx.get(f"{BASE_URL}/convert/supported-formats").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "formats": {
                            "png": {"max_size": "10MB", "description": "PNG"},
                        },
                        "max_dimensions": "4096x4096",
                        "max_file_size": "10MB",
                    },
                },
            )
        )

        result = await async_client.convert.supported_formats()
        assert "png" in result.formats


class TestAsyncBackground:
    """Async background removal."""

    @respx.mock
    async def test_async_remove_background(self, async_client: AsyncToSVG) -> None:
        respx.post(f"{BASE_URL}/background/remove").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "filename": "abc.png",
                        "path": "removed-background/abc.png",
                        "file_size": 1000,
                        "processing_time": 0.5,
                        "provider": "rembg",
                    },
                },
            )
        )

        result = await async_client.background.remove(SAMPLE_IMAGE_BYTES)
        assert isinstance(result, RemoveBackgroundResult)
        assert result.provider == "rembg"


class TestAsyncResize:
    """Async image resize."""

    @respx.mock
    async def test_async_resize_image(self, async_client: AsyncToSVG) -> None:
        respx.post(f"{BASE_URL}/resize/image").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "path": "resized/x.png",
                        "size": 2000,
                        "dimensions": {"width": 400, "height": 300},
                        "quality": 90,
                        "format": "png",
                        "processing_time": 0.2,
                    },
                },
            )
        )

        result = await async_client.resize.image(SAMPLE_IMAGE_BYTES, width=400, height=300)
        assert isinstance(result, ResizeImageResult)
        assert result.dimensions.width == 400


class TestAsyncHealthCheck:
    """Async health check (no data wrapper)."""

    @respx.mock
    async def test_async_health_check(self, async_client: AsyncToSVG) -> None:
        respx.get(f"{BASE_URL}/health").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "status": "healthy",
                    "timestamp": "2026-02-06T12:00:00.000000Z",
                    "services": {"image_conversion": "operational"},
                },
            )
        )

        result = await async_client.health_check()
        assert isinstance(result, HealthCheckResult)
        assert result.status == "healthy"


class TestAsyncErrors:
    """Error handling in async mode."""

    @respx.mock
    async def test_async_auth_error(self, async_client: AsyncToSVG) -> None:
        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(
                401,
                json={
                    "success": False,
                    "error_code": "INVALID_API_KEY",
                    "message": "The provided API key is invalid",
                },
            )
        )

        with pytest.raises(AuthenticationError):
            await async_client.convert.image_to_svg(SAMPLE_IMAGE_BYTES)

    @respx.mock
    async def test_async_server_error_non_json(self, async_client: AsyncToSVG) -> None:
        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(502, content=b"Bad Gateway")
        )

        with pytest.raises(ServerError) as exc_info:
            await async_client.convert.image_to_svg(SAMPLE_IMAGE_BYTES)

        assert exc_info.value.status_code == 502
        assert exc_info.value.body is None


class TestAsyncContextManager:
    """Async context manager support."""

    @respx.mock
    async def test_async_context_manager(self) -> None:
        respx.get(f"{BASE_URL}/health").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "status": "healthy",
                    "timestamp": "2026-02-06T12:00:00.000000Z",
                    "services": {},
                },
            )
        )

        async with AsyncToSVG(
            api_key="tosvg_test_ctxmgr_placeholder_key___",
            base_url=BASE_URL,
            max_retries=0,
        ) as client:
            result = await client.health_check()
            assert result.status == "healthy"
