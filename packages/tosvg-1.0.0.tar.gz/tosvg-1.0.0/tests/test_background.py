"""Tests for the background removal resource."""

from __future__ import annotations

import httpx
import pytest
import respx

from tests.conftest import BASE_URL, RATE_LIMIT_HEADERS, SAMPLE_IMAGE_BYTES
from tosvg import ToSVG
from tosvg.enums import BackgroundModel, BackgroundProvider, ImageFormat
from tosvg.models.background import BackgroundModelsResult, RemoveBackgroundResult


class TestRemoveBackground:
    """POST /background/remove"""

    @respx.mock
    def test_remove_returns_path(self, client: ToSVG, sample_image: bytes) -> None:
        respx.post(f"{BASE_URL}/background/remove").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "filename": "abc123.png",
                        "path": "removed-background/abc123.png",
                        "file_size": 56780,
                        "processing_time": 1.23,
                        "provider": "rembg",
                    },
                },
                headers=RATE_LIMIT_HEADERS,
            )
        )

        result = client.background.remove(sample_image)

        assert isinstance(result, RemoveBackgroundResult)
        assert result.filename == "abc123.png"
        assert result.path == "removed-background/abc123.png"
        assert result.image is None
        assert result.file_size == 56780
        assert result.processing_time == 1.23
        assert result.provider == "rembg"

    @respx.mock
    def test_remove_returns_base64(self, client: ToSVG, sample_image: bytes) -> None:
        respx.post(f"{BASE_URL}/background/remove").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "image": "iVBORw0KGgoAAAANSUhEUgAA",
                        "format": "png",
                        "file_size": 56780,
                        "processing_time": 1.23,
                        "provider": "rembg",
                    },
                },
                headers=RATE_LIMIT_HEADERS,
            )
        )

        result = client.background.remove(
            sample_image,
            return_base64=True,
        )

        assert isinstance(result, RemoveBackgroundResult)
        assert result.image == "iVBORw0KGgoAAAANSUhEUgAA"
        assert result.format == "png"
        assert result.filename is None
        assert result.path is None

    @respx.mock
    def test_remove_with_options(self, client: ToSVG, sample_image: bytes) -> None:
        route = respx.post(f"{BASE_URL}/background/remove").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "filename": "x.png",
                        "path": "removed-background/x.png",
                        "file_size": 100,
                        "processing_time": 0.5,
                        "provider": "withoutbg",
                    },
                },
            )
        )

        client.background.remove(
            sample_image,
            provider=BackgroundProvider.WITHOUTBG,
            model=BackgroundModel.SILUETA,
            format=ImageFormat.JPG,
        )

        request = route.calls.last.request
        body = request.content.decode("utf-8", errors="replace")
        assert "withoutbg" in body
        assert "silueta" in body


class TestBackgroundModels:
    """GET /background/models"""

    @respx.mock
    def test_get_models(self, client: ToSVG) -> None:
        respx.get(f"{BASE_URL}/background/models").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "provider": "rembg",
                        "models": ["u2net", "silueta", "u2net_human_seg", "isnet-general-use"],
                        "available_providers": ["rembg", "withoutbg"],
                        "default_provider": "rembg",
                        "supported_formats": ["png", "jpg", "jpeg"],
                    },
                },
                headers=RATE_LIMIT_HEADERS,
            )
        )

        result = client.background.models()

        assert isinstance(result, BackgroundModelsResult)
        assert result.provider == "rembg"
        assert "u2net" in result.models
        assert len(result.models) == 4

    @respx.mock
    def test_get_models_with_provider_filter(self, client: ToSVG) -> None:
        route = respx.get(f"{BASE_URL}/background/models").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "provider": "withoutbg",
                        "models": [],
                        "available_providers": ["rembg", "withoutbg"],
                        "default_provider": "rembg",
                        "supported_formats": ["png", "jpg", "jpeg"],
                    },
                },
            )
        )

        client.background.models(provider=BackgroundProvider.WITHOUTBG)

        request = route.calls.last.request
        assert "provider=withoutbg" in str(request.url)
