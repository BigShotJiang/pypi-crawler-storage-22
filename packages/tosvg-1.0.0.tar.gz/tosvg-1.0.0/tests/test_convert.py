"""Tests for the image-to-SVG conversion resource."""

from __future__ import annotations

import httpx
import pytest
import respx

from tests.conftest import BASE_URL, RATE_LIMIT_HEADERS, SAMPLE_IMAGE_BYTES
from tosvg import ToSVG
from tosvg.enums import ColorMode, ConversionMode
from tosvg.models.convert import ImageToSvgResult
from tosvg.models.info import SupportedFormatsResult


class TestImageToSvg:
    """POST /convert/image-to-svg"""

    @respx.mock
    def test_basic_conversion(self, client: ToSVG, sample_image: bytes) -> None:
        route = respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "svg": '<svg xmlns="http://www.w3.org/2000/svg"><rect/></svg>',
                        "file_size": 1234,
                        "conversion_time": 0.42,
                    },
                },
                headers=RATE_LIMIT_HEADERS,
            )
        )

        result = client.convert.image_to_svg(sample_image)

        assert isinstance(result, ImageToSvgResult)
        assert "<svg" in result.svg
        assert result.file_size == 1234
        assert result.conversion_time == 0.42
        assert route.called

    @respx.mock
    def test_with_all_options(self, client: ToSVG, sample_image: bytes) -> None:
        route = respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "svg": "<svg/>",
                        "file_size": 100,
                        "conversion_time": 0.1,
                    },
                },
                headers=RATE_LIMIT_HEADERS,
            )
        )

        result = client.convert.image_to_svg(
            sample_image,
            color_mode=ColorMode.BW,
            mode=ConversionMode.SPLINE,
            filter_speckle=4,
            corner_threshold=60,
            color_precision=8,
        )

        assert isinstance(result, ImageToSvgResult)
        assert route.called

        # Verify the form data sent in the request
        request = route.calls.last.request
        body = request.content.decode("utf-8", errors="replace")
        assert "options[color_mode]" in body
        assert "options[mode]" in body
        assert "options[filter_speckle]" in body

    @respx.mock
    def test_with_string_enum_values(self, client: ToSVG, sample_image: bytes) -> None:
        """Enum values can also be passed as plain strings."""
        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "svg": "<svg/>",
                        "file_size": 100,
                        "conversion_time": 0.1,
                    },
                },
            )
        )

        result = client.convert.image_to_svg(
            sample_image,
            color_mode="bw",
            mode="spline",
        )

        assert isinstance(result, ImageToSvgResult)


class TestSupportedFormats:
    """GET /convert/supported-formats"""

    @respx.mock
    def test_get_supported_formats(self, client: ToSVG) -> None:
        respx.get(f"{BASE_URL}/convert/supported-formats").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "formats": {
                            "png": {"max_size": "10MB", "description": "PNG image format"},
                            "jpg": {"max_size": "10MB", "description": "JPEG image format"},
                        },
                        "max_dimensions": "4096x4096 pixels",
                        "max_file_size": "10MB",
                    },
                },
                headers=RATE_LIMIT_HEADERS,
            )
        )

        result = client.convert.supported_formats()

        assert isinstance(result, SupportedFormatsResult)
        assert "png" in result.formats
        assert result.formats["png"].max_size == "10MB"
        assert result.max_file_size == "10MB"
