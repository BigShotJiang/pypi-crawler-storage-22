"""Tests for exception mapping, error handling, and edge cases."""

from __future__ import annotations

import httpx
import pytest
import respx

from tests.conftest import BASE_URL, SAMPLE_IMAGE_BYTES
from tosvg import ToSVG
from tosvg.exceptions import (
    AuthenticationError,
    BadRequestError,
    ForbiddenError,
    NetworkError,
    RateLimitError,
    ServerError,
    ToSVGError,
    ValidationError,
)


class TestAuthenticationErrors:
    """401 responses → AuthenticationError"""

    @respx.mock
    def test_missing_api_key(self, client: ToSVG, sample_image: bytes) -> None:
        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(
                401,
                json={
                    "success": False,
                    "error_code": "MISSING_API_KEY",
                    "message": "API key is required",
                },
            )
        )

        with pytest.raises(AuthenticationError) as exc_info:
            client.convert.image_to_svg(sample_image)

        err = exc_info.value
        assert err.status_code == 401
        assert err.error_code == "MISSING_API_KEY"
        assert "API key is required" in err.message

    @respx.mock
    def test_invalid_api_key(self, client: ToSVG, sample_image: bytes) -> None:
        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(
                401,
                json={
                    "success": False,
                    "error_code": "INVALID_API_KEY",
                    "message": "The provided API key is invalid",
                },
            )
        )

        with pytest.raises(AuthenticationError) as exc_info:
            client.convert.image_to_svg(sample_image)

        assert exc_info.value.error_code == "INVALID_API_KEY"


class TestForbiddenErrors:
    """403 responses → ForbiddenError"""

    @respx.mock
    def test_ip_restricted(self, client: ToSVG, sample_image: bytes) -> None:
        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(
                403,
                json={
                    "success": False,
                    "error_code": "IP_RESTRICTED",
                    "message": "Your IP address is not allowed",
                },
            )
        )

        with pytest.raises(ForbiddenError) as exc_info:
            client.convert.image_to_svg(sample_image)

        assert exc_info.value.error_code == "IP_RESTRICTED"


class TestValidationErrors:
    """422 responses → ValidationError with per-field errors dict"""

    @respx.mock
    def test_validation_error_with_field_errors(self, client: ToSVG, sample_image: bytes) -> None:
        respx.post(f"{BASE_URL}/resize/image").mock(
            return_value=httpx.Response(
                422,
                json={
                    "success": False,
                    "message": "Validation failed",
                    "errors": {
                        "width": ["The width must be between 1 and 4096."],
                        "image": ["The image field is required."],
                    },
                },
            )
        )

        with pytest.raises(ValidationError) as exc_info:
            client.resize.image(sample_image, width=0, height=0)

        err = exc_info.value
        assert err.status_code == 422
        assert "width" in err.errors
        assert "The width must be between 1 and 4096." in err.errors["width"]


class TestBadRequestErrors:
    """400 responses → BadRequestError"""

    @respx.mock
    def test_unsupported_format(self, client: ToSVG, sample_image: bytes) -> None:
        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(
                400,
                json={
                    "success": False,
                    "error_code": "UNSUPPORTED_FORMAT",
                    "message": "File format not supported",
                },
            )
        )

        with pytest.raises(BadRequestError) as exc_info:
            client.convert.image_to_svg(sample_image)

        assert exc_info.value.error_code == "UNSUPPORTED_FORMAT"


class TestRateLimitErrors:
    """429 responses → RateLimitError"""

    @respx.mock
    def test_rate_limit_with_body_retry_after(self, client: ToSVG, sample_image: bytes) -> None:
        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(
                429,
                json={
                    "success": False,
                    "error_code": "RATE_LIMIT_EXCEEDED",
                    "message": "Rate limit exceeded. Please try again later.",
                    "retry_after": 3600,
                },
                headers={"Retry-After": "7200"},
            )
        )

        with pytest.raises(RateLimitError) as exc_info:
            client.convert.image_to_svg(sample_image)

        err = exc_info.value
        assert err.status_code == 429
        # Body retry_after takes priority over header
        assert err.retry_after == 3600

    @respx.mock
    def test_rate_limit_header_fallback(self, client: ToSVG, sample_image: bytes) -> None:
        """When body has no retry_after, fall back to Retry-After header."""
        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(
                429,
                json={
                    "success": False,
                    "error_code": "RATE_LIMIT_EXCEEDED",
                    "message": "Rate limit exceeded.",
                },
                headers={"Retry-After": "120"},
            )
        )

        with pytest.raises(RateLimitError) as exc_info:
            client.convert.image_to_svg(sample_image)

        assert exc_info.value.retry_after == 120

    @respx.mock
    def test_rate_limit_default_fallback(self, client: ToSVG, sample_image: bytes) -> None:
        """When neither body nor header has retry_after, fall back to 60s."""
        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(
                429,
                json={
                    "success": False,
                    "message": "Rate limit exceeded.",
                },
            )
        )

        with pytest.raises(RateLimitError) as exc_info:
            client.convert.image_to_svg(sample_image)

        assert exc_info.value.retry_after == 60.0


class TestServerErrors:
    """500/502/503/504 responses → ServerError"""

    @respx.mock
    def test_500_json_body(self, client: ToSVG, sample_image: bytes) -> None:
        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(
                500,
                json={
                    "success": False,
                    "error_code": "INTERNAL_ERROR",
                    "message": "An unexpected error occurred",
                },
            )
        )

        with pytest.raises(ServerError) as exc_info:
            client.convert.image_to_svg(sample_image)

        assert exc_info.value.status_code == 500
        assert exc_info.value.error_code == "INTERNAL_ERROR"

    @respx.mock
    def test_502_non_json_body(self, client: ToSVG, sample_image: bytes) -> None:
        """502 from reverse proxy — body is HTML, not JSON."""
        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(
                502,
                content=b"<html><body>Bad Gateway</body></html>",
                headers={"Content-Type": "text/html"},
            )
        )

        with pytest.raises(ServerError) as exc_info:
            client.convert.image_to_svg(sample_image)

        err = exc_info.value
        assert err.status_code == 502
        assert err.body is None  # JSON parsing failed gracefully
        assert err.error_code is None

    @respx.mock
    def test_503_non_json_body(self, client: ToSVG, sample_image: bytes) -> None:
        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(503, content=b"Service Unavailable")
        )

        with pytest.raises(ServerError) as exc_info:
            client.convert.image_to_svg(sample_image)

        assert exc_info.value.status_code == 503

    @respx.mock
    def test_504_non_json_body(self, client: ToSVG, sample_image: bytes) -> None:
        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(504, content=b"Gateway Timeout")
        )

        with pytest.raises(ServerError) as exc_info:
            client.convert.image_to_svg(sample_image)

        assert exc_info.value.status_code == 504


class TestErrorCodeNoneSafe:
    """error_code may be missing from some error responses."""

    @respx.mock
    def test_missing_error_code(self, client: ToSVG, sample_image: bytes) -> None:
        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(
                401,
                json={
                    "success": False,
                    "message": "Unauthorized",
                    # no error_code field
                },
            )
        )

        with pytest.raises(AuthenticationError) as exc_info:
            client.convert.image_to_svg(sample_image)

        assert exc_info.value.error_code is None
        assert exc_info.value.message == "Unauthorized"


class TestExceptionHierarchy:
    """All SDK exceptions inherit from ToSVGError."""

    def test_all_exceptions_are_tosvg_errors(self) -> None:
        assert issubclass(AuthenticationError, ToSVGError)
        assert issubclass(ForbiddenError, ToSVGError)
        assert issubclass(BadRequestError, ToSVGError)
        assert issubclass(ValidationError, ToSVGError)
        assert issubclass(RateLimitError, ToSVGError)
        assert issubclass(ServerError, ToSVGError)
        assert issubclass(NetworkError, ToSVGError)


class TestClientConstruction:
    """Client instantiation validation."""

    def test_empty_api_key_raises(self) -> None:
        with pytest.raises(ValueError, match="api_key"):
            ToSVG(api_key="")
