"""Tests for HTTP transport layer: retry logic, rate-limit parsing, file input normalisation."""

from __future__ import annotations

import tempfile
from io import BytesIO
from pathlib import Path
from unittest.mock import patch

import httpx
import pytest
import respx

from tests.conftest import BASE_URL, RATE_LIMIT_HEADERS, SAMPLE_IMAGE_BYTES
from tosvg import ToSVG
from tosvg._utils import prepare_file
from tosvg.exceptions import NetworkError, RateLimitError, ServerError


class TestFileInputNormalisation:
    """prepare_file() must handle str, Path, bytes, BytesIO, and IO[bytes]."""

    def test_from_bytes(self) -> None:
        filename, data, ct = prepare_file(b"\x89PNG fake")
        assert filename == "image"
        assert data == b"\x89PNG fake"

    def test_from_bytesio(self) -> None:
        bio = BytesIO(b"hello")
        bio.name = "photo.png"
        filename, data, ct = prepare_file(bio)
        assert filename == "photo.png"
        assert data == b"hello"
        assert "png" in ct

    def test_from_file_path_str(self, tmp_path: Path) -> None:
        img = tmp_path / "test.jpg"
        img.write_bytes(SAMPLE_IMAGE_BYTES)

        filename, data, ct = prepare_file(str(img))
        assert filename == "test.jpg"
        assert data == SAMPLE_IMAGE_BYTES
        assert "jpeg" in ct

    def test_from_pathlib_path(self, tmp_path: Path) -> None:
        img = tmp_path / "test.png"
        img.write_bytes(SAMPLE_IMAGE_BYTES)

        filename, data, ct = prepare_file(img)
        assert filename == "test.png"
        assert data == SAMPLE_IMAGE_BYTES

    def test_file_not_found_raises(self) -> None:
        with pytest.raises(FileNotFoundError):
            prepare_file("/nonexistent/image.png")

    def test_from_generic_io(self, tmp_path: Path) -> None:
        img = tmp_path / "test.bmp"
        img.write_bytes(b"BM fake bmp")

        with open(img, "rb") as f:
            filename, data, ct = prepare_file(f)

        assert "test.bmp" in filename
        assert data == b"BM fake bmp"


class TestRetryLogic:
    """Verify automatic retry on 429 and 5xx."""

    @respx.mock
    def test_retry_on_429_with_auto_retry(self, sample_image: bytes) -> None:
        """Client with retry_on_rate_limit=True should retry after a 429."""
        client = ToSVG(
            api_key="tosvg_test_retrytest_placeholder_key_",
            base_url=BASE_URL,
            retry_on_rate_limit=True,
            max_retries=1,
            timeout=5,
        )

        route = respx.post(f"{BASE_URL}/convert/image-to-svg")
        route.side_effect = [
            httpx.Response(
                429,
                json={
                    "success": False,
                    "message": "Rate limit exceeded.",
                    "retry_after": 0,  # 0 so the test doesn't actually sleep
                },
            ),
            httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "svg": "<svg/>",
                        "file_size": 10,
                        "conversion_time": 0.1,
                    },
                },
                headers=RATE_LIMIT_HEADERS,
            ),
        ]

        with patch("time.sleep"):
            result = client.convert.image_to_svg(sample_image)

        assert result.svg == "<svg/>"
        assert route.call_count == 2

    @respx.mock
    def test_retry_on_502(self, sample_image: bytes) -> None:
        """5xx errors should be retried with exponential back-off."""
        client = ToSVG(
            api_key="tosvg_test_retrytest_placeholder_key_",
            base_url=BASE_URL,
            retry_on_rate_limit=True,
            max_retries=1,
            timeout=5,
        )

        route = respx.post(f"{BASE_URL}/convert/image-to-svg")
        route.side_effect = [
            httpx.Response(502, content=b"Bad Gateway"),
            httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "svg": "<svg/>",
                        "file_size": 10,
                        "conversion_time": 0.1,
                    },
                },
            ),
        ]

        with patch("time.sleep"):
            result = client.convert.image_to_svg(sample_image)

        assert result.svg == "<svg/>"
        assert route.call_count == 2

    @respx.mock
    def test_max_retries_exhausted(self, sample_image: bytes) -> None:
        """After max_retries, the last error should be raised."""
        client = ToSVG(
            api_key="tosvg_test_retrytest_placeholder_key_",
            base_url=BASE_URL,
            retry_on_rate_limit=True,
            max_retries=2,
            timeout=5,
        )

        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            return_value=httpx.Response(502, content=b"Bad Gateway"),
        )

        with patch("time.sleep"):
            with pytest.raises(ServerError) as exc_info:
                client.convert.image_to_svg(sample_image)

        assert exc_info.value.status_code == 502


class TestNetworkError:
    """Connection and timeout errors → NetworkError."""

    @respx.mock
    def test_timeout_raises_network_error(self, client: ToSVG, sample_image: bytes) -> None:
        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            side_effect=httpx.ReadTimeout("timed out")
        )

        with pytest.raises(NetworkError, match="timed out"):
            client.convert.image_to_svg(sample_image)

    @respx.mock
    def test_connection_error_raises_network_error(self, client: ToSVG, sample_image: bytes) -> None:
        respx.post(f"{BASE_URL}/convert/image-to-svg").mock(
            side_effect=httpx.ConnectError("connection refused")
        )

        with pytest.raises(NetworkError, match="connection refused"):
            client.convert.image_to_svg(sample_image)
