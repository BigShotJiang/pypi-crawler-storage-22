"""Tests for informational endpoints (health, formats, models, limits)."""

from __future__ import annotations

import httpx
import pytest
import respx

from tests.conftest import BASE_URL, RATE_LIMIT_HEADERS
from tosvg import ToSVG
from tosvg.models.info import HealthCheckResult


class TestHealthCheck:
    """GET /health — special response format (no ``data`` wrapper)."""

    @respx.mock
    def test_health_check_no_data_wrapper(self, client: ToSVG) -> None:
        """The /health endpoint returns fields at top level, not inside ``data``."""
        respx.get(f"{BASE_URL}/health").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "status": "healthy",
                    "timestamp": "2026-02-06T12:00:00.000000Z",
                    "services": {
                        "image_conversion": "operational",
                        "background_removal": "operational",
                        "image_resize": "operational",
                    },
                },
            )
        )

        result = client.health_check()

        assert isinstance(result, HealthCheckResult)
        assert result.status == "healthy"
        assert result.timestamp == "2026-02-06T12:00:00.000000Z"
        assert result.services["image_conversion"] == "operational"
        assert result.services["background_removal"] == "operational"
        assert result.services["image_resize"] == "operational"

    @respx.mock
    def test_health_check_does_not_require_auth(self) -> None:
        """Health check should work even without a valid API key
        (the server doesn't require auth for this endpoint)."""
        client = ToSVG(api_key="tosvg_test_dummykey_for_health_check_", max_retries=0)

        respx.get(f"{BASE_URL}/health").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "status": "healthy",
                    "timestamp": "2026-02-06T12:00:00.000000Z",
                    "services": {},
                },
            )
        )

        result = client.health_check()
        assert result.status == "healthy"


class TestRateLimitInfoParsing:
    """Verify that rate-limit headers are parsed and exposed."""

    @respx.mock
    def test_rate_limit_info_after_request(self, client: ToSVG) -> None:
        respx.get(f"{BASE_URL}/health").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "status": "healthy",
                    "timestamp": "2026-02-06T12:00:00.000000Z",
                    "services": {},
                },
                headers=RATE_LIMIT_HEADERS,
            )
        )

        # Before any request, rate limit info is None
        assert client.get_rate_limit_info() is None

        client.health_check()

        info = client.get_rate_limit_info()
        assert info is not None
        assert info.limit == 1000
        assert info.remaining == 999
        assert info.reset_at == 1706860800
