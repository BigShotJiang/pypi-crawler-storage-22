"""Tests for the image resize resource."""

from __future__ import annotations

import httpx
import pytest
import respx

from tests.conftest import BASE_URL, RATE_LIMIT_HEADERS, SAMPLE_IMAGE_BYTES
from tosvg import ToSVG
from tosvg.enums import ResizeFormat
from tosvg.models.resize import ResizeImageResult, ResizeLimitsResult


class TestResizeImage:
    """POST /resize/image"""

    @respx.mock
    def test_basic_resize(self, client: ToSVG, sample_image: bytes) -> None:
        respx.post(f"{BASE_URL}/resize/image").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "path": "resized/abc123.png",
                        "size": 45200,
                        "dimensions": {"width": 800, "height": 600},
                        "quality": 90,
                        "format": "png",
                        "processing_time": 0.45,
                    },
                },
                headers=RATE_LIMIT_HEADERS,
            )
        )

        result = client.resize.image(sample_image, width=800, height=600)

        assert isinstance(result, ResizeImageResult)
        assert result.path == "resized/abc123.png"
        assert result.size == 45200
        assert result.dimensions.width == 800
        assert result.dimensions.height == 600
        assert result.quality == 90
        assert result.format == "png"
        assert result.processing_time == 0.45

    @respx.mock
    def test_resize_with_all_options(self, client: ToSVG, sample_image: bytes) -> None:
        route = respx.post(f"{BASE_URL}/resize/image").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "path": "resized/abc.webp",
                        "size": 3000,
                        "dimensions": {"width": 200, "height": 200},
                        "quality": 75,
                        "format": "webp",
                        "processing_time": 0.2,
                    },
                },
            )
        )

        result = client.resize.image(
            sample_image,
            width=200,
            height=200,
            quality=75,
            format=ResizeFormat.WEBP,
            maintain_aspect_ratio=False,
        )

        assert result.format == "webp"
        assert result.quality == 75

        request = route.calls.last.request
        body = request.content.decode("utf-8", errors="replace")
        assert "200" in body
        assert "webp" in body


class TestResizeLimits:
    """GET /resize/limits"""

    @respx.mock
    def test_get_limits(self, client: ToSVG) -> None:
        respx.get(f"{BASE_URL}/resize/limits").mock(
            return_value=httpx.Response(
                200,
                json={
                    "success": True,
                    "data": {
                        "max_dimensions": {"width": 4096, "height": 4096},
                        "min_dimensions": {"width": 1, "height": 1},
                        "max_file_size": "10MB",
                        "supported_formats": ["png", "jpg", "jpeg", "webp"],
                        "quality_range": {"min": 1, "max": 100, "default": 90},
                    },
                },
                headers=RATE_LIMIT_HEADERS,
            )
        )

        result = client.resize.limits()

        assert isinstance(result, ResizeLimitsResult)
        assert result.max_width == 4096
        assert result.min_width == 1
        assert result.max_file_size == "10MB"
        assert result.quality_default == 90
        assert "webp" in result.supported_formats
