"""ToSVG — Official Python SDK for the ToSVG API.

Quick start::

    from tosvg import ToSVG

    client = ToSVG(api_key="tosvg_live_xxx")
    result = client.convert.image_to_svg("photo.png")
    print(result.svg[:80])

Async usage::

    from tosvg import AsyncToSVG

    async with AsyncToSVG(api_key="tosvg_live_xxx") as client:
        result = await client.convert.image_to_svg("photo.png")
"""

from tosvg._version import __version__
from tosvg.async_client import AsyncToSVG
from tosvg.client import ToSVG
from tosvg.enums import (
    BackgroundModel,
    BackgroundProvider,
    ColorMode,
    ConversionMode,
    ImageFormat,
    ResizeFormat,
)
from tosvg.exceptions import (
    APIStatusError,
    AuthenticationError,
    BadRequestError,
    ForbiddenError,
    NetworkError,
    RateLimitError,
    ServerError,
    ToSVGError,
    ValidationError,
)
from tosvg.models import (
    BackgroundModelsResult,
    Dimensions,
    FormatInfo,
    HealthCheckResult,
    ImageToSvgOptions,
    ImageToSvgResult,
    RateLimitInfo,
    RemoveBackgroundOptions,
    RemoveBackgroundResult,
    ResizeImageOptions,
    ResizeImageResult,
    ResizeLimitsResult,
    SupportedFormatsResult,
)

__all__ = [
    # version
    "__version__",
    # clients
    "ToSVG",
    "AsyncToSVG",
    # enums
    "ColorMode",
    "ConversionMode",
    "BackgroundProvider",
    "BackgroundModel",
    "ImageFormat",
    "ResizeFormat",
    # models
    "ImageToSvgOptions",
    "ImageToSvgResult",
    "RemoveBackgroundOptions",
    "RemoveBackgroundResult",
    "BackgroundModelsResult",
    "ResizeImageOptions",
    "ResizeImageResult",
    "ResizeLimitsResult",
    "Dimensions",
    "HealthCheckResult",
    "SupportedFormatsResult",
    "FormatInfo",
    "RateLimitInfo",
    # exceptions
    "ToSVGError",
    "APIStatusError",
    "AuthenticationError",
    "ForbiddenError",
    "BadRequestError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
    "NetworkError",
]
