"""Low-level HTTP transport: base client, sync/async API clients, and resource base classes.

This module implements the shared logic (header building, error mapping, retry
strategy, rate-limit parsing) in ``BaseClient`` and provides concrete
``SyncAPIClient`` / ``AsyncAPIClient`` sub-classes that use ``httpx``.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Optional

import httpx

from tosvg._version import __version__
from tosvg.exceptions import (
    APIStatusError,
    AuthenticationError,
    BadRequestError,
    ForbiddenError,
    NetworkError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from tosvg.models.info import RateLimitInfo

DEFAULT_BASE_URL = "https://tosvg.com/api/v1"
DEFAULT_TIMEOUT = 30  # seconds
DEFAULT_MAX_RETRIES = 3


# ---------------------------------------------------------------------------
# Base client (shared logic)
# ---------------------------------------------------------------------------


class BaseClient:
    """Shared logic for both sync and async clients."""

    api_key: str
    base_url: str
    timeout: float
    retry_on_rate_limit: bool
    max_retries: int
    _rate_limit_info: Optional[RateLimitInfo]

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        retry_on_rate_limit: bool = True,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        if not api_key:
            raise ValueError("api_key must be a non-empty string")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.retry_on_rate_limit = retry_on_rate_limit
        self.max_retries = max_retries
        self._rate_limit_info = None

    # -- headers -----------------------------------------------------------

    def _build_headers(self) -> dict[str, str]:
        return {
            "X-API-Key": self.api_key,
            "User-Agent": f"tosvg-python/{__version__}",
            "Accept": "application/json",
        }

    # -- URL ---------------------------------------------------------------

    def _build_url(self, path: str) -> str:
        if path.startswith("/"):
            return f"{self.base_url}{path}"
        return f"{self.base_url}/{path}"

    # -- rate-limit header parsing -----------------------------------------

    def _parse_rate_limit_headers(self, headers: httpx.Headers) -> None:
        try:
            limit = int(headers.get("X-RateLimit-Limit", "0"))
            remaining = int(headers.get("X-RateLimit-Remaining", "0"))
            reset_at = int(headers.get("X-RateLimit-Reset", "0"))
            if limit:
                self._rate_limit_info = RateLimitInfo(
                    limit=limit,
                    remaining=remaining,
                    reset_at=reset_at,
                )
        except (ValueError, TypeError):
            pass

    def get_rate_limit_info(self) -> Optional[RateLimitInfo]:
        """Return the most recently observed rate-limit information, or ``None``."""
        return self._rate_limit_info

    # -- retry helpers -----------------------------------------------------

    def _should_retry(self, status_code: int, attempt: int) -> bool:
        if attempt >= self.max_retries:
            return False
        if status_code == 429 and self.retry_on_rate_limit:
            return True
        if status_code in (502, 503, 504):
            return True
        return False

    def _calculate_retry_delay(
        self,
        response: httpx.Response,
        body: Optional[dict[str, Any]],
        attempt: int,
    ) -> float:
        """Determine how many seconds to wait before the next retry.

        Priority: response body ``retry_after`` → ``Retry-After`` header → fallback 60 s.
        For 5xx errors exponential back-off (1, 2, 4, …) is used instead.
        """
        if response.status_code == 429:
            # 1. body
            if body and "retry_after" in body:
                return float(body["retry_after"])
            # 2. header
            retry_header = response.headers.get("Retry-After")
            if retry_header:
                try:
                    return float(retry_header)
                except (ValueError, TypeError):
                    pass
            # 3. fallback
            return 60.0
        # 5xx exponential back-off
        return min(2**attempt, 30)

    # -- error mapping -----------------------------------------------------

    def _make_error(
        self,
        response: httpx.Response,
        body: Optional[dict[str, Any]],
    ) -> APIStatusError:
        """Build the appropriate exception for a non-2xx *response*."""
        status = response.status_code
        message = (body or {}).get("message", response.reason_phrase or "Unknown error")
        error_code = (body or {}).get("error_code")

        common = dict(
            status_code=status,
            error_code=error_code,
            body=body,
        )

        if status == 401:
            return AuthenticationError(message, **common)
        if status == 403:
            return ForbiddenError(message, **common)
        if status == 400:
            return BadRequestError(message, **common)
        if status == 422:
            errors = (body or {}).get("errors", {})
            return ValidationError(message, errors=errors, **common)
        if status == 429:
            retry_after = self._calculate_retry_delay(response, body, 0)
            return RateLimitError(message, retry_after=retry_after, **common)
        # 500 / 502 / 503 / 504 and anything else
        return ServerError(message, **common)

    def _try_parse_json(self, response: httpx.Response) -> Optional[dict[str, Any]]:
        """Attempt to decode the response body as JSON.

        Returns ``None`` when the body is empty or not valid JSON
        (common for 502/503/504 from reverse-proxies).
        """
        try:
            return response.json()  # type: ignore[no-any-return]
        except Exception:
            return None


# ---------------------------------------------------------------------------
# Sync API Client
# ---------------------------------------------------------------------------


class SyncAPIClient(BaseClient):
    """Synchronous HTTP transport backed by :class:`httpx.Client`."""

    _http: httpx.Client

    def __init__(self, api_key: str, **kwargs: Any) -> None:
        super().__init__(api_key, **kwargs)
        self._http = httpx.Client(
            base_url=self.base_url,
            headers=self._build_headers(),
            timeout=self.timeout,
        )

    # -- lifecycle ---------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._http.close()

    def __enter__(self) -> SyncAPIClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # -- request dispatch --------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        *,
        data: Optional[dict[str, str]] = None,
        files: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, str]] = None,
    ) -> dict[str, Any]:
        url = self._build_url(path)

        last_exc: Optional[Exception] = None
        for attempt in range(self.max_retries + 1):
            try:
                response = self._http.request(
                    method,
                    url,
                    data=data,
                    files=files,
                    params=params,
                )
            except httpx.TimeoutException as exc:
                raise NetworkError(f"Request timed out: {exc}") from exc
            except httpx.ConnectError as exc:
                raise NetworkError(f"Connection error: {exc}") from exc
            except httpx.HTTPError as exc:
                raise NetworkError(str(exc)) from exc

            self._parse_rate_limit_headers(response.headers)
            body = self._try_parse_json(response)

            if response.is_success:
                return body or {}

            if self._should_retry(response.status_code, attempt):
                delay = self._calculate_retry_delay(response, body, attempt)
                time.sleep(delay)
                continue

            raise self._make_error(response, body)

        # Should not be reached, but just in case
        raise NetworkError("Max retries exceeded")

    def _get(
        self,
        path: str,
        *,
        params: Optional[dict[str, str]] = None,
    ) -> dict[str, Any]:
        return self._request("GET", path, params=params)

    def _post(
        self,
        path: str,
        *,
        data: Optional[dict[str, str]] = None,
        files: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        return self._request("POST", path, data=data, files=files)


# ---------------------------------------------------------------------------
# Async API Client
# ---------------------------------------------------------------------------


class AsyncAPIClient(BaseClient):
    """Asynchronous HTTP transport backed by :class:`httpx.AsyncClient`."""

    _http: httpx.AsyncClient

    def __init__(self, api_key: str, **kwargs: Any) -> None:
        super().__init__(api_key, **kwargs)
        self._http = httpx.AsyncClient(
            base_url=self.base_url,
            headers=self._build_headers(),
            timeout=self.timeout,
        )

    # -- lifecycle ---------------------------------------------------------

    async def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        await self._http.aclose()

    async def __aenter__(self) -> AsyncAPIClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    # -- request dispatch --------------------------------------------------

    async def _request(
        self,
        method: str,
        path: str,
        *,
        data: Optional[dict[str, str]] = None,
        files: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, str]] = None,
    ) -> dict[str, Any]:
        url = self._build_url(path)

        for attempt in range(self.max_retries + 1):
            try:
                response = await self._http.request(
                    method,
                    url,
                    data=data,
                    files=files,
                    params=params,
                )
            except httpx.TimeoutException as exc:
                raise NetworkError(f"Request timed out: {exc}") from exc
            except httpx.ConnectError as exc:
                raise NetworkError(f"Connection error: {exc}") from exc
            except httpx.HTTPError as exc:
                raise NetworkError(str(exc)) from exc

            self._parse_rate_limit_headers(response.headers)
            body = self._try_parse_json(response)

            if response.is_success:
                return body or {}

            if self._should_retry(response.status_code, attempt):
                delay = self._calculate_retry_delay(response, body, attempt)
                await asyncio.sleep(delay)
                continue

            raise self._make_error(response, body)

        raise NetworkError("Max retries exceeded")

    async def _get(
        self,
        path: str,
        *,
        params: Optional[dict[str, str]] = None,
    ) -> dict[str, Any]:
        return await self._request("GET", path, params=params)

    async def _post(
        self,
        path: str,
        *,
        data: Optional[dict[str, str]] = None,
        files: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        return await self._request("POST", path, data=data, files=files)


# ---------------------------------------------------------------------------
# Resource base classes
# ---------------------------------------------------------------------------


class SyncAPIResource:
    """Base class for synchronous resource namespaces."""

    _client: SyncAPIClient

    def __init__(self, client: SyncAPIClient) -> None:
        self._client = client


class AsyncAPIResource:
    """Base class for asynchronous resource namespaces."""

    _client: AsyncAPIClient

    def __init__(self, client: AsyncAPIClient) -> None:
        self._client = client
