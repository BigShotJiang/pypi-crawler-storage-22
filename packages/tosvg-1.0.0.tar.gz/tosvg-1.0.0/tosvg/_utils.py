"""File-input normalisation and misc helpers."""

from __future__ import annotations

import mimetypes
import os
from io import BytesIO
from pathlib import Path
from typing import IO, Any, Optional, Tuple, Union

# Accepted image input types for SDK public methods.
FileInput = Union[str, Path, bytes, BytesIO, IO[bytes]]

# Tuple returned by ``prepare_file``: (filename, file_bytes, content_type)
FileTuple = Tuple[str, bytes, str]


def prepare_file(
    image: FileInput,
    *,
    field_name: str = "image",
) -> FileTuple:
    """Normalise any supported file input into an ``(filename, bytes, content_type)`` tuple.

    Supported inputs:

    * ``str`` or :class:`pathlib.Path` — read the file from disk; filename is
      derived from the path.
    * ``bytes`` — used directly; filename defaults to ``"image"``.
    * :class:`io.BytesIO` or any readable binary IO — ``.read()`` the content;
      filename is derived from the ``name`` attribute when available.
    """
    if isinstance(image, (str, Path)):
        path = Path(image)
        if not path.is_file():
            raise FileNotFoundError(f"Image file not found: {path}")
        filename = path.name
        file_bytes = path.read_bytes()
    elif isinstance(image, bytes):
        filename = field_name
        file_bytes = image
    elif isinstance(image, BytesIO):
        filename = getattr(image, "name", field_name)
        image.seek(0)
        file_bytes = image.read()
    else:
        # Generic IO[bytes]
        filename = getattr(image, "name", field_name)
        file_bytes = image.read()  # type: ignore[union-attr]

    content_type = _guess_content_type(filename)
    return filename, file_bytes, content_type


def _guess_content_type(filename: str) -> str:
    """Return MIME type for *filename*, falling back to ``application/octet-stream``."""
    ct, _ = mimetypes.guess_type(filename)
    return ct or "application/octet-stream"
