"""Synchronous ToSVG client."""

from __future__ import annotations

from functools import cached_property
from typing import Any, Optional

from tosvg._base_client import SyncAPIClient
from tosvg.models.info import HealthCheckResult, RateLimitInfo
from tosvg.resources.background import BackgroundResource
from tosvg.resources.convert import ConvertResource
from tosvg.resources.resize import ResizeResource


class ToSVG(SyncAPIClient):
    """Synchronous client for the ToSVG API.

    Example::

        from tosvg import ToSVG

        client = ToSVG(api_key="tosvg_live_xxx")
        result = client.convert.image_to_svg("photo.png")
        print(result.svg[:100])
        client.close()

    Or as a context manager::

        with ToSVG(api_key="tosvg_live_xxx") as client:
            result = client.convert.image_to_svg("photo.png")

    Args:
        api_key: Your ToSVG API key (``tosvg_live_…`` or ``tosvg_test_…``).
        base_url: Override the default base URL.
        timeout: Request timeout in seconds (default 30).
        retry_on_rate_limit: Automatically retry on 429 responses (default ``True``).
        max_retries: Maximum number of retry attempts (default 3).
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://tosvg.com/api/v1",
        timeout: float = 30,
        retry_on_rate_limit: bool = True,
        max_retries: int = 3,
    ) -> None:
        super().__init__(
            api_key,
            base_url=base_url,
            timeout=timeout,
            retry_on_rate_limit=retry_on_rate_limit,
            max_retries=max_retries,
        )

    # -- resource namespaces -----------------------------------------------

    @cached_property
    def convert(self) -> ConvertResource:
        """Image-to-SVG conversion operations."""
        return ConvertResource(self)

    @cached_property
    def background(self) -> BackgroundResource:
        """Background removal operations."""
        return BackgroundResource(self)

    @cached_property
    def resize(self) -> ResizeResource:
        """Image resize operations."""
        return ResizeResource(self)

    # -- top-level methods -------------------------------------------------

    def health_check(self) -> HealthCheckResult:
        """Check API health status.

        .. note::
            This endpoint does **not** require authentication and returns its
            payload **without** a ``data`` wrapper (unlike all other endpoints).

        Returns:
            A :class:`HealthCheckResult` with the service status, timestamp,
            and per-service statuses.
        """
        resp = self._get("/health")
        # Special case: health response has no "data" wrapper
        return HealthCheckResult.from_dict(resp)
