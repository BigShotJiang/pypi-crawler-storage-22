"""Enumerations for the ToSVG SDK."""

from __future__ import annotations

from enum import Enum


class ColorMode(str, Enum):
    """Color mode for image-to-SVG conversion."""

    COLOR = "color"
    """Produces a full-color SVG output."""

    BW = "bw"
    """Produces a black-and-white SVG output."""


class ConversionMode(str, Enum):
    """Conversion algorithm for image-to-SVG conversion."""

    POLYGON = "polygon"
    """Sharp-edged polygon-based tracing."""

    SPLINE = "spline"
    """Smooth curve spline-based tracing."""


class BackgroundProvider(str, Enum):
    """Background removal AI provider."""

    REMBG = "rembg"
    """Default provider with model selection support."""

    WITHOUTBG = "withoutbg"
    """Alternative background removal provider."""


class BackgroundModel(str, Enum):
    """AI model for background removal (only with ``rembg`` provider)."""

    U2NET = "u2net"
    """General-purpose model (default)."""

    SILUETA = "silueta"
    """Fast, lightweight model."""

    U2NET_HUMAN_SEG = "u2net_human_seg"
    """Optimized for human segmentation."""

    ISNET_GENERAL_USE = "isnet-general-use"
    """General-purpose with higher accuracy."""


class ImageFormat(str, Enum):
    """Output image format for background removal."""

    PNG = "png"
    JPG = "jpg"
    JPEG = "jpeg"


class ResizeFormat(str, Enum):
    """Output image format for image resize."""

    PNG = "png"
    JPG = "jpg"
    JPEG = "jpeg"
    WEBP = "webp"
