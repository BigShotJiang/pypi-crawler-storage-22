"""Exception classes for the ToSVG SDK.

The hierarchy is::

    ToSVGError
    ├── APIStatusError
    │   ├── AuthenticationError   (401)
    │   ├── ForbiddenError        (403)
    │   ├── BadRequestError       (400)
    │   ├── ValidationError       (422)
    │   ├── RateLimitError        (429)
    │   └── ServerError           (500 / 502 / 503 / 504)
    └── NetworkError              (connection / timeout)
"""

from __future__ import annotations

from typing import Any, Optional


class ToSVGError(Exception):
    """Base exception for all ToSVG SDK errors."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class APIStatusError(ToSVGError):
    """An API response with a non-2xx status code.

    Attributes:
        status_code: HTTP status code.
        error_code: Machine-readable error code from the API (may be ``None``).
        message: Human-readable error message.
        body: The raw parsed response body (dict), or ``None`` if the body
            could not be parsed as JSON.
    """

    status_code: int
    error_code: Optional[str]
    body: Optional[dict[str, Any]]

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        error_code: Optional[str] = None,
        body: Optional[dict[str, Any]] = None,
    ) -> None:
        self.status_code = status_code
        self.error_code = error_code
        self.body = body
        super().__init__(message)


class AuthenticationError(APIStatusError):
    """401 — Missing, invalid, expired, or deactivated API key.

    Possible ``error_code`` values:
    ``MISSING_API_KEY``, ``INVALID_API_KEY``, ``EXPIRED_API_KEY``, ``INACTIVE_API_KEY``.
    """


class ForbiddenError(APIStatusError):
    """403 — IP restriction or subscription requirement.

    Possible ``error_code`` values:
    ``IP_RESTRICTED``, ``SUBSCRIPTION_REQUIRED``.
    """


class BadRequestError(APIStatusError):
    """400 — Malformed request, unsupported format, or file too large.

    Possible ``error_code`` values:
    ``VALIDATION_ERROR``, ``UNSUPPORTED_FORMAT``, ``FILE_TOO_LARGE``.
    """


class ValidationError(APIStatusError):
    """422 — Request parameter validation failure.

    Attributes:
        errors: Per-field validation error messages
            (e.g. ``{"image": ["The image field is required."]}``).
    """

    errors: dict[str, list[str]]

    def __init__(
        self,
        message: str,
        *,
        status_code: int = 422,
        error_code: Optional[str] = None,
        body: Optional[dict[str, Any]] = None,
        errors: Optional[dict[str, list[str]]] = None,
    ) -> None:
        self.errors = errors or {}
        super().__init__(
            message,
            status_code=status_code,
            error_code=error_code,
            body=body,
        )


class RateLimitError(APIStatusError):
    """429 — Rate limit exceeded.

    Attributes:
        retry_after: Seconds to wait before retrying.
    """

    retry_after: float

    def __init__(
        self,
        message: str,
        *,
        status_code: int = 429,
        error_code: Optional[str] = None,
        body: Optional[dict[str, Any]] = None,
        retry_after: float = 60.0,
    ) -> None:
        self.retry_after = retry_after
        super().__init__(
            message,
            status_code=status_code,
            error_code=error_code,
            body=body,
        )


class ServerError(APIStatusError):
    """500 / 502 / 503 / 504 — Internal server or gateway error.

    .. note::
        The response body may **not** be valid JSON for 502/503/504 responses
        coming from a reverse proxy.  In that case ``body`` will be ``None``.
    """


class NetworkError(ToSVGError):
    """Connection failure or request timeout (no HTTP response received)."""
