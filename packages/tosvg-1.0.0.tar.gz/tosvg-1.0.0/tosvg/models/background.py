"""Data models for background removal."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional, Union

from tosvg.enums import BackgroundModel, BackgroundProvider, ImageFormat


@dataclass
class RemoveBackgroundOptions:
    """Options for background removal.

    Attributes:
        provider: AI provider. Defaults to ``BackgroundProvider.REMBG``.
        model: AI model (only with ``rembg`` provider). Defaults to ``BackgroundModel.U2NET``.
        format: Output image format. Defaults to ``ImageFormat.PNG``.
        return_base64: If ``True``, return the image as a base64-encoded string.
    """

    provider: Optional[Union[BackgroundProvider, str]] = None
    model: Optional[Union[BackgroundModel, str]] = None
    format: Optional[Union[ImageFormat, str]] = None
    return_base64: Optional[bool] = None

    def to_form_data(self) -> dict[str, str]:
        """Convert options to flat form-data fields."""
        data: dict[str, str] = {}
        if self.provider is not None:
            data["provider"] = str(self.provider.value if isinstance(self.provider, BackgroundProvider) else self.provider)
        if self.model is not None:
            data["model"] = str(self.model.value if isinstance(self.model, BackgroundModel) else self.model)
        if self.format is not None:
            data["format"] = str(self.format.value if isinstance(self.format, ImageFormat) else self.format)
        if self.return_base64 is not None:
            data["return_base64"] = "true" if self.return_base64 else "false"
        return data


@dataclass
class RemoveBackgroundResult:
    """Result of background removal.

    When ``return_base64=False``: ``filename`` and ``path`` are populated.
    When ``return_base64=True``: ``image`` and ``format`` are populated.
    ``file_size``, ``processing_time``, and ``provider`` are always present.
    """

    file_size: int
    processing_time: float
    provider: str
    filename: Optional[str] = None
    path: Optional[str] = None
    image: Optional[str] = None
    format: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RemoveBackgroundResult:
        return cls(
            file_size=data["file_size"],
            processing_time=data["processing_time"],
            provider=data["provider"],
            filename=data.get("filename"),
            path=data.get("path"),
            image=data.get("image"),
            format=data.get("format"),
        )


@dataclass
class BackgroundModelsResult:
    """Available background removal models.

    Attributes:
        provider: The queried provider name.
        models: List of available model identifiers.
        available_providers: All supported providers.
        default_provider: The server-side default provider.
        supported_formats: Supported output image formats.
    """

    provider: str
    models: list[str]
    available_providers: list[str]
    default_provider: str
    supported_formats: list[str]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BackgroundModelsResult:
        return cls(
            provider=data["provider"],
            models=data["models"],
            available_providers=data["available_providers"],
            default_provider=data["default_provider"],
            supported_formats=data["supported_formats"],
        )
