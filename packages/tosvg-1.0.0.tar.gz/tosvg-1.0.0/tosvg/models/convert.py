"""Data models for image-to-SVG conversion."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Union

from tosvg.enums import ColorMode, ConversionMode


@dataclass
class ImageToSvgOptions:
    """Options for image-to-SVG conversion.

    Attributes:
        color_mode: Color output mode. Defaults to ``ColorMode.COLOR``.
        mode: Tracing algorithm. Defaults to ``ConversionMode.POLYGON``.
        filter_speckle: Noise filter size (0–20). Defaults to 8.
        corner_threshold: Corner threshold angle in degrees (0–180). Defaults to 30.
        color_precision: Color precision level (1–10). Defaults to 4.
    """

    color_mode: Optional[Union[ColorMode, str]] = None
    mode: Optional[Union[ConversionMode, str]] = None
    filter_speckle: Optional[int] = None
    corner_threshold: Optional[int] = None
    color_precision: Optional[int] = None

    def to_form_data(self) -> dict[str, str]:
        """Convert options to ``options[key]`` bracket-notation form fields."""
        data: dict[str, str] = {}
        if self.color_mode is not None:
            data["options[color_mode]"] = str(self.color_mode.value if isinstance(self.color_mode, ColorMode) else self.color_mode)
        if self.mode is not None:
            data["options[mode]"] = str(self.mode.value if isinstance(self.mode, ConversionMode) else self.mode)
        if self.filter_speckle is not None:
            data["options[filter_speckle]"] = str(self.filter_speckle)
        if self.corner_threshold is not None:
            data["options[corner_threshold]"] = str(self.corner_threshold)
        if self.color_precision is not None:
            data["options[color_precision]"] = str(self.color_precision)
        return data


@dataclass
class ImageToSvgResult:
    """Result of an image-to-SVG conversion.

    Attributes:
        svg: The SVG content as a raw XML string.
        file_size: SVG file size in bytes.
        conversion_time: Conversion duration in seconds.
    """

    svg: str
    file_size: int
    conversion_time: float

    @classmethod
    def from_dict(cls, data: dict) -> ImageToSvgResult:
        return cls(
            svg=data["svg"],
            file_size=data["file_size"],
            conversion_time=data["conversion_time"],
        )
