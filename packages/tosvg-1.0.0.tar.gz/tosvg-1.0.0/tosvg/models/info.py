"""Data models for informational endpoints."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class HealthCheckResult:
    """Result of the health-check endpoint.

    .. note::
        The ``/health`` endpoint does **not** wrap its payload in a ``data``
        key — the fields sit at the top level of the JSON response.

    Attributes:
        status: Overall system status (e.g. ``"healthy"``).
        timestamp: ISO-8601 timestamp of the check.
        services: Per-service operational status mapping.
    """

    status: str
    timestamp: str
    services: dict[str, str]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HealthCheckResult:
        return cls(
            status=data["status"],
            timestamp=data["timestamp"],
            services=data["services"],
        )


@dataclass
class FormatInfo:
    """Metadata for a single supported image format."""

    max_size: str
    description: str


@dataclass
class SupportedFormatsResult:
    """Supported input formats for image-to-SVG conversion.

    Attributes:
        formats: Mapping of format extension to its metadata.
        max_dimensions: Human-readable max dimensions string.
        max_file_size: Human-readable max file size string.
    """

    formats: dict[str, FormatInfo]
    max_dimensions: str
    max_file_size: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SupportedFormatsResult:
        formats = {
            key: FormatInfo(max_size=val["max_size"], description=val["description"])
            for key, val in data["formats"].items()
        }
        return cls(
            formats=formats,
            max_dimensions=data["max_dimensions"],
            max_file_size=data["max_file_size"],
        )


@dataclass
class RateLimitInfo:
    """Rate-limit information parsed from response headers.

    Attributes:
        limit: Maximum daily requests for the current plan.
        remaining: Requests remaining in the current period.
        reset_at: Unix timestamp when the limit resets.
    """

    limit: int
    remaining: int
    reset_at: int
