"""Data models for image resize."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional, Union

from tosvg.enums import ResizeFormat


@dataclass
class ResizeImageOptions:
    """Options for image resize.

    Attributes:
        width: Target width in pixels (1–4096). **Required.**
        height: Target height in pixels (1–4096). **Required.**
        quality: Output quality (1–100). Defaults to 90.
        format: Output image format. Defaults to ``ResizeFormat.PNG``.
        maintain_aspect_ratio: Preserve aspect ratio. Defaults to ``True``.
    """

    width: int
    height: int
    quality: Optional[int] = None
    format: Optional[Union[ResizeFormat, str]] = None
    maintain_aspect_ratio: Optional[bool] = None

    def to_form_data(self) -> dict[str, str]:
        """Convert options to flat form-data fields."""
        data: dict[str, str] = {
            "width": str(self.width),
            "height": str(self.height),
        }
        if self.quality is not None:
            data["quality"] = str(self.quality)
        if self.format is not None:
            data["format"] = str(self.format.value if isinstance(self.format, ResizeFormat) else self.format)
        if self.maintain_aspect_ratio is not None:
            data["maintain_aspect_ratio"] = "true" if self.maintain_aspect_ratio else "false"
        return data


@dataclass
class Dimensions:
    """Image dimensions in pixels."""

    width: int
    height: int


@dataclass
class ResizeImageResult:
    """Result of an image resize operation.

    Attributes:
        path: Path of the generated file on the server.
        size: File size in bytes.
        dimensions: Output width and height in pixels.
        quality: Quality value used.
        format: Output image format.
        processing_time: Processing duration in seconds.
    """

    path: str
    size: int
    dimensions: Dimensions
    quality: int
    format: str
    processing_time: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ResizeImageResult:
        return cls(
            path=data["path"],
            size=data["size"],
            dimensions=Dimensions(
                width=data["dimensions"]["width"],
                height=data["dimensions"]["height"],
            ),
            quality=data["quality"],
            format=data["format"],
            processing_time=data["processing_time"],
        )


@dataclass
class ResizeLimitsResult:
    """Server-reported resize limits.

    Attributes:
        max_width: Maximum allowed width.
        max_height: Maximum allowed height.
        min_width: Minimum allowed width.
        min_height: Minimum allowed height.
        max_file_size: Maximum upload file size (e.g. ``"10MB"``).
        supported_formats: Supported output formats.
        quality_min: Minimum quality value.
        quality_max: Maximum quality value.
        quality_default: Default quality value.
    """

    max_width: int
    max_height: int
    min_width: int
    min_height: int
    max_file_size: str
    supported_formats: list[str]
    quality_min: int
    quality_max: int
    quality_default: int

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ResizeLimitsResult:
        return cls(
            max_width=data["max_dimensions"]["width"],
            max_height=data["max_dimensions"]["height"],
            min_width=data["min_dimensions"]["width"],
            min_height=data["min_dimensions"]["height"],
            max_file_size=data["max_file_size"],
            supported_formats=data["supported_formats"],
            quality_min=data["quality_range"]["min"],
            quality_max=data["quality_range"]["max"],
            quality_default=data["quality_range"]["default"],
        )
