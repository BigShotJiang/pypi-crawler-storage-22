"""ToSVG resource sub-packages."""
