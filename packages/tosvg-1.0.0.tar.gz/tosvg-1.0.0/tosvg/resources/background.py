"""Background removal resource."""

from __future__ import annotations

from typing import Any, Optional, Union

from tosvg._base_client import AsyncAPIResource, SyncAPIResource
from tosvg._utils import FileInput, prepare_file
from tosvg.enums import BackgroundModel, BackgroundProvider, ImageFormat
from tosvg.models.background import (
    BackgroundModelsResult,
    RemoveBackgroundOptions,
    RemoveBackgroundResult,
)


class BackgroundResource(SyncAPIResource):
    """Synchronous helpers for ``/background/*`` endpoints."""

    def remove(
        self,
        image: FileInput,
        *,
        provider: Optional[Union[BackgroundProvider, str]] = None,
        model: Optional[Union[BackgroundModel, str]] = None,
        format: Optional[Union[ImageFormat, str]] = None,
        return_base64: Optional[bool] = None,
    ) -> RemoveBackgroundResult:
        """Remove the background from an image.

        Args:
            image: Image file — accepts a file path (``str`` / ``Path``),
                raw ``bytes``, ``BytesIO``, or any binary file-like object.
            provider: AI provider (``"rembg"`` or ``"withoutbg"``).
            model: AI model — only used when *provider* is ``"rembg"``.
            format: Output image format.
            return_base64: When ``True``, the result contains a base64-encoded
                image string instead of a server-side file path.

        Returns:
            A :class:`RemoveBackgroundResult`.
        """
        options = RemoveBackgroundOptions(
            provider=provider,
            model=model,
            format=format,
            return_base64=return_base64,
        )

        filename, file_bytes, content_type = prepare_file(image)
        data = options.to_form_data()
        files = {"image": (filename, file_bytes, content_type)}

        resp = self._client._post("/background/remove", data=data, files=files)
        return RemoveBackgroundResult.from_dict(resp["data"])

    def models(
        self,
        *,
        provider: Optional[Union[BackgroundProvider, str]] = None,
    ) -> BackgroundModelsResult:
        """List available background-removal models.

        Args:
            provider: Optional provider filter.

        Returns:
            A :class:`BackgroundModelsResult` with model and provider info.
        """
        params: dict[str, str] = {}
        if provider is not None:
            params["provider"] = str(
                provider.value if isinstance(provider, BackgroundProvider) else provider
            )
        resp = self._client._get("/background/models", params=params or None)
        return BackgroundModelsResult.from_dict(resp["data"])


class AsyncBackgroundResource(AsyncAPIResource):
    """Asynchronous helpers for ``/background/*`` endpoints."""

    async def remove(
        self,
        image: FileInput,
        *,
        provider: Optional[Union[BackgroundProvider, str]] = None,
        model: Optional[Union[BackgroundModel, str]] = None,
        format: Optional[Union[ImageFormat, str]] = None,
        return_base64: Optional[bool] = None,
    ) -> RemoveBackgroundResult:
        """Remove the background from an image (async).

        See :meth:`BackgroundResource.remove` for parameter details.
        """
        options = RemoveBackgroundOptions(
            provider=provider,
            model=model,
            format=format,
            return_base64=return_base64,
        )

        filename, file_bytes, content_type = prepare_file(image)
        data = options.to_form_data()
        files = {"image": (filename, file_bytes, content_type)}

        resp = await self._client._post("/background/remove", data=data, files=files)
        return RemoveBackgroundResult.from_dict(resp["data"])

    async def models(
        self,
        *,
        provider: Optional[Union[BackgroundProvider, str]] = None,
    ) -> BackgroundModelsResult:
        """List available background-removal models (async).

        See :meth:`BackgroundResource.models` for details.
        """
        params: dict[str, str] = {}
        if provider is not None:
            params["provider"] = str(
                provider.value if isinstance(provider, BackgroundProvider) else provider
            )
        resp = await self._client._get("/background/models", params=params or None)
        return BackgroundModelsResult.from_dict(resp["data"])
