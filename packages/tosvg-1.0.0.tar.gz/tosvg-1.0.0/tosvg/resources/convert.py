"""Image-to-SVG conversion resource."""

from __future__ import annotations

from typing import Any, Optional, Union

from tosvg._base_client import AsyncAPIResource, SyncAPIResource
from tosvg._utils import FileInput, prepare_file
from tosvg.enums import ColorMode, ConversionMode
from tosvg.models.convert import ImageToSvgOptions, ImageToSvgResult
from tosvg.models.info import SupportedFormatsResult


class ConvertResource(SyncAPIResource):
    """Synchronous helpers for ``/convert/*`` endpoints."""

    def image_to_svg(
        self,
        image: FileInput,
        *,
        color_mode: Optional[Union[ColorMode, str]] = None,
        mode: Optional[Union[ConversionMode, str]] = None,
        filter_speckle: Optional[int] = None,
        corner_threshold: Optional[int] = None,
        color_precision: Optional[int] = None,
    ) -> ImageToSvgResult:
        """Convert a raster image to SVG.

        Args:
            image: Image file — accepts a file path (``str`` / ``Path``),
                raw ``bytes``, ``BytesIO``, or any binary file-like object.
            color_mode: Color output mode (``"color"`` or ``"bw"``).
            mode: Tracing algorithm (``"polygon"`` or ``"spline"``).
            filter_speckle: Noise filter size (0–20).
            corner_threshold: Corner threshold angle in degrees (0–180).
            color_precision: Color precision level (1–10).

        Returns:
            An :class:`ImageToSvgResult` with the SVG content, file size, and
            conversion time.
        """
        options = ImageToSvgOptions(
            color_mode=color_mode,
            mode=mode,
            filter_speckle=filter_speckle,
            corner_threshold=corner_threshold,
            color_precision=color_precision,
        )

        filename, file_bytes, content_type = prepare_file(image)
        data = options.to_form_data()
        files = {"image": (filename, file_bytes, content_type)}

        resp = self._client._post("/convert/image-to-svg", data=data, files=files)
        return ImageToSvgResult.from_dict(resp["data"])

    def supported_formats(self) -> SupportedFormatsResult:
        """Retrieve the list of supported input image formats.

        Returns:
            A :class:`SupportedFormatsResult` with format details and limits.
        """
        resp = self._client._get("/convert/supported-formats")
        return SupportedFormatsResult.from_dict(resp["data"])


class AsyncConvertResource(AsyncAPIResource):
    """Asynchronous helpers for ``/convert/*`` endpoints."""

    async def image_to_svg(
        self,
        image: FileInput,
        *,
        color_mode: Optional[Union[ColorMode, str]] = None,
        mode: Optional[Union[ConversionMode, str]] = None,
        filter_speckle: Optional[int] = None,
        corner_threshold: Optional[int] = None,
        color_precision: Optional[int] = None,
    ) -> ImageToSvgResult:
        """Convert a raster image to SVG (async).

        See :meth:`ConvertResource.image_to_svg` for parameter details.
        """
        options = ImageToSvgOptions(
            color_mode=color_mode,
            mode=mode,
            filter_speckle=filter_speckle,
            corner_threshold=corner_threshold,
            color_precision=color_precision,
        )

        filename, file_bytes, content_type = prepare_file(image)
        data = options.to_form_data()
        files = {"image": (filename, file_bytes, content_type)}

        resp = await self._client._post("/convert/image-to-svg", data=data, files=files)
        return ImageToSvgResult.from_dict(resp["data"])

    async def supported_formats(self) -> SupportedFormatsResult:
        """Retrieve the list of supported input image formats (async).

        See :meth:`ConvertResource.supported_formats` for details.
        """
        resp = await self._client._get("/convert/supported-formats")
        return SupportedFormatsResult.from_dict(resp["data"])
