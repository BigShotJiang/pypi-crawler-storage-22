"""Image resize resource."""

from __future__ import annotations

from typing import Any, Optional, Union

from tosvg._base_client import AsyncAPIResource, SyncAPIResource
from tosvg._utils import FileInput, prepare_file
from tosvg.enums import ResizeFormat
from tosvg.models.resize import ResizeImageOptions, ResizeImageResult, ResizeLimitsResult


class ResizeResource(SyncAPIResource):
    """Synchronous helpers for ``/resize/*`` endpoints."""

    def image(
        self,
        image: FileInput,
        *,
        width: int,
        height: int,
        quality: Optional[int] = None,
        format: Optional[Union[ResizeFormat, str]] = None,
        maintain_aspect_ratio: Optional[bool] = None,
    ) -> ResizeImageResult:
        """Resize an image to the given dimensions.

        Args:
            image: Image file — accepts a file path (``str`` / ``Path``),
                raw ``bytes``, ``BytesIO``, or any binary file-like object.
            width: Target width in pixels (1–4096). **Required.**
            height: Target height in pixels (1–4096). **Required.**
            quality: Output quality (1–100). Defaults to 90.
            format: Output format (``"png"``, ``"jpg"``, ``"jpeg"``, ``"webp"``).
            maintain_aspect_ratio: Preserve aspect ratio. Defaults to ``True``.

        Returns:
            A :class:`ResizeImageResult` with the output path, dimensions, and
            processing time.
        """
        options = ResizeImageOptions(
            width=width,
            height=height,
            quality=quality,
            format=format,
            maintain_aspect_ratio=maintain_aspect_ratio,
        )

        filename, file_bytes, content_type = prepare_file(image)
        data = options.to_form_data()
        files = {"image": (filename, file_bytes, content_type)}

        resp = self._client._post("/resize/image", data=data, files=files)
        return ResizeImageResult.from_dict(resp["data"])

    def limits(self) -> ResizeLimitsResult:
        """Retrieve server-reported resize limits.

        Returns:
            A :class:`ResizeLimitsResult`.
        """
        resp = self._client._get("/resize/limits")
        return ResizeLimitsResult.from_dict(resp["data"])


class AsyncResizeResource(AsyncAPIResource):
    """Asynchronous helpers for ``/resize/*`` endpoints."""

    async def image(
        self,
        image: FileInput,
        *,
        width: int,
        height: int,
        quality: Optional[int] = None,
        format: Optional[Union[ResizeFormat, str]] = None,
        maintain_aspect_ratio: Optional[bool] = None,
    ) -> ResizeImageResult:
        """Resize an image to the given dimensions (async).

        See :meth:`ResizeResource.image` for parameter details.
        """
        options = ResizeImageOptions(
            width=width,
            height=height,
            quality=quality,
            format=format,
            maintain_aspect_ratio=maintain_aspect_ratio,
        )

        filename, file_bytes, content_type = prepare_file(image)
        data = options.to_form_data()
        files = {"image": (filename, file_bytes, content_type)}

        resp = await self._client._post("/resize/image", data=data, files=files)
        return ResizeImageResult.from_dict(resp["data"])

    async def limits(self) -> ResizeLimitsResult:
        """Retrieve server-reported resize limits (async).

        See :meth:`ResizeResource.limits` for details.
        """
        resp = await self._client._get("/resize/limits")
        return ResizeLimitsResult.from_dict(resp["data"])
