"""
Code Review Council - A council of 3 AI critics that reach consensus on code quality.
"""

__version__ = "1.0.0"
__author__ = "Code Review Council"

from .models import (
    CouncilConfig,
    CriticConfig,
    ReviewResult,
    ConsensusResult,
    CONSTANTS
)

from .exceptions import (
    CouncilError,
    ConfigError,
    APIError,
    FileError,
    ReviewError
)

__all__ = [
    'CouncilConfig',
    'CriticConfig', 
    'ReviewResult',
    'ConsensusResult',
    'CONSTANTS',
    'CouncilError',
    'ConfigError',
    'APIError',
    'FileError',
    'ReviewError'
]