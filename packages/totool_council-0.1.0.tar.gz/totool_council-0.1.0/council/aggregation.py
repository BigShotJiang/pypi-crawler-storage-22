"""Aggregate and deduplicate findings from multiple reviews."""
from typing import List, Dict, Set
from collections import Counter, defaultdict

from council.models import StructuredFindings, AggregatedFindings, Issue


class FindingsAggregator:
    """Aggregate and deduplicate findings from multiple reviews."""

    @staticmethod
    def aggregate(findings_list: List[StructuredFindings]) -> AggregatedFindings:
        """Aggregate all findings, deduplicate, build frequency map."""
        # Collect all unique issues
        seen_issues: Set[Issue] = set()
        all_issues: List[Issue] = []
        issue_counter: Counter = Counter()
        all_patterns: List[str] = []
        all_files: Set[str] = set()

        for findings in findings_list:
            # Track patterns
            all_patterns.extend(findings.patterns_found)
            all_files.update(findings.files_reviewed)

            # Process issues by severity
            for severity, issues in findings.findings.items():
                for issue in issues:
                    # Deduplicate by using the Issue.__hash__ and __eq__
                    if issue not in seen_issues:
                        seen_issues.add(issue)
                        all_issues.append(issue)

                    # Count occurrences for prioritization
                    key = f"{issue.severity}:{issue.type}:{issue.file}:{issue.line}"
                    issue_counter[key] += 1

        # Group by severity
        by_severity = defaultdict(list)
        for issue in all_issues:
            by_severity[issue.severity].append(issue)

        # Group by type
        by_type = defaultdict(list)
        for issue in all_issues:
            by_type[issue.type].append(issue)

        # Group by file
        by_file = defaultdict(list)
        for issue in all_issues:
            by_file[issue.file].append(issue)

        # Get total chunks from first finding (or 0 if empty)
        total_chunks = findings_list[0].total_chunks if findings_list else 0

        return AggregatedFindings(
            by_severity=dict(by_severity),
            by_type=dict(by_type),
            by_file=dict(by_file),
            issue_frequency=dict(issue_counter),
            all_patterns=list(set(all_patterns)),
            total_files=len(all_files),
            total_chunks=total_chunks
        )
