"""
API client and related functionality for Code Review Council.

SECURITY: Explicit SSL certificate validation is enforced to prevent MITM attacks.
SECURITY: Connection-time DNS validation is performed to prevent DNS rebinding attacks.
"""
import json
import ssl
from typing import Dict, Any, Optional
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from .models import CriticConfig, CONSTANTS, APIUsageStats
from .exceptions import APIError
from .utils import SyncRateLimiter
from .base_api_client import BaseAPIClient
from .security import SecurityValidator


def _create_ssl_context() -> ssl.SSLContext:
    """
    Create a secure SSL context for HTTPS connections.

    SECURITY CRITICAL: This creates an SSL context with explicit certificate
    verification to prevent Man-in-the-Middle (MITM) attacks. The default
    ssl.create_default_context() enables:
    - Certificate verification against system CA store
    - Hostname verification
    - Protection against protocol downgrade attacks

    Returns:
        SSLContext with secure defaults for certificate validation
    """
    return ssl.create_default_context()


class APIClient(BaseAPIClient):
    """Handles synchronous API calls with dependency injection support."""

    def __init__(self, api_key: str, base_url: str | None, model: str | None,
                 endpoint: str = "/v1/chat/completions", max_requests_per_second: float = 10.0,
                 rate_limiter: SyncRateLimiter | None = None):
        """
        Initialize the synchronous API client.

        Args:
            api_key: API key for authentication
            base_url: Base URL for the API endpoint
            model: Model name to use
            endpoint: API endpoint path
            max_requests_per_second: Maximum requests per second for rate limiting
            rate_limiter: Optional rate limiter instance
        """
        super().__init__(api_key, base_url, model, endpoint, max_requests_per_second)
        self.rate_limiter = rate_limiter or SyncRateLimiter(max_requests_per_second=max_requests_per_second)
        self._stats = APIUsageStats()

    def get_stats(self) -> APIUsageStats:
        """Get the current API usage statistics."""
        return self._stats

    def reset_stats(self) -> None:
        """Reset the API usage statistics."""
        self._stats = APIUsageStats()

    def get_review(self, critic_config: CriticConfig, code: str,
                   is_multi_file: bool = False, timeout: int = 90) -> Dict[str, Any]:
        """
        Get review from the API synchronously.

        Args:
            critic_config: Configuration for the critic
            code: The code to review
            is_multi_file: Whether this is a multi-file review
            timeout: Request timeout in seconds

        Returns:
            Dictionary containing the API response
        """
        # SECURITY: Connection-time DNS validation (prevents DNS rebinding)
        if self.base_url:
            SecurityValidator.validate_connection_target(self.base_url)

        url = self._build_url()
        data = self._build_request_data(critic_config, is_multi_file, code)
        headers = self._build_headers()

        # Estimate input tokens before making the request
        estimated_input_tokens = self._estimate_input_tokens(critic_config, code, is_multi_file)

        req = Request(url, data=json.dumps(data).encode('utf-8'), headers=headers)
        self.rate_limiter.acquire()

        # SECURITY: Create SSL context with certificate verification
        ssl_context = _create_ssl_context()

        try:
            with urlopen(req, timeout=timeout, context=ssl_context) as response:
                result = json.loads(response.read().decode('utf-8'))

                # Track API call and token usage
                self._stats.api_calls += 1
                input_tokens, output_tokens = self._extract_usage_from_response(result)
                # Use actual tokens from API if available, otherwise use estimate
                self._stats.input_tokens += input_tokens if input_tokens > 0 else estimated_input_tokens
                self._stats.output_tokens += output_tokens if output_tokens > 0 else self._estimate_tokens(
                    result.get('choices', [{}])[0].get('message', {}).get('content', '')
                )

                return result
        except HTTPError as e:
            error_body = e.read().decode('utf-8')
            sanitized_error = self._sanitize_error_message(f"API Error ({e.code}): {error_body}")
            raise APIError(sanitized_error)
        except URLError as e:
            sanitized_error = self._sanitize_error_message(f"Network Error: {e.reason}")
            raise APIError(sanitized_error)