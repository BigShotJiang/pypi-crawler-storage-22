"""
Async API client for Code Review Council using aiohttp.
Provides non-blocking API calls for better performance.

SECURITY: Explicit SSL certificate verification is enforced to prevent MITM attacks.
SECURITY: Connection-time DNS validation is performed to prevent DNS rebinding attacks.
"""
import asyncio
import json
from typing import Dict, Any, Optional, TYPE_CHECKING
from .models import CriticConfig, CONSTANTS, APIUsageStats
from .exceptions import APIError
from .utils import AsyncRateLimiter
from .base_api_client import BaseAPIClient
from .security import SecurityValidator

# Optional import - will be checked at runtime
if TYPE_CHECKING:
    import aiohttp


class AsyncAPIClient(BaseAPIClient):
    """Async HTTP client for API calls with connection pooling.

    Supports two usage patterns:
    1. Explicit context manager: async with client: ...
    2. Explicit initialization: await client.initialize() then client.get_review(...)

    CODE QUALITY: Lifecycle is now explicit - initialize() must be called before get_review().

    FIX-005: Thread-safe initialization using asyncio.Lock with double-check pattern.
    """

    def __init__(self, api_key: str, base_url: str | None, model: str | None,
                 endpoint: str = "/v1/chat/completions", limit_connections: bool = False,
                 max_requests_per_second: float = 10.0, rate_limiter: Optional[AsyncRateLimiter] = None):
        """
        Initialize the async API client.

        Args:
            api_key: API key for authentication
            base_url: Base URL for the API endpoint
            model: Model name to use
            endpoint: API endpoint path
            limit_connections: Whether to limit connections per host
            max_requests_per_second: Maximum requests per second for rate limiting
            rate_limiter: Optional rate limiter instance
        """
        super().__init__(api_key, base_url, model, endpoint, max_requests_per_second)
        self.limit_connections = limit_connections
        self._session = None
        self._owner = True  # Track if we own the session for cleanup
        self._initialized = False  # Track initialization state
        # FIX-005: Lock for thread-safe initialization
        self._init_lock = asyncio.Lock()
        self.rate_limiter = rate_limiter or AsyncRateLimiter(max_requests_per_second=max_requests_per_second)
        self._stats = APIUsageStats()

    def get_stats(self) -> APIUsageStats:
        """Get the current API usage statistics."""
        return self._stats

    def reset_stats(self) -> None:
        """Reset the API usage statistics."""
        self._stats = APIUsageStats()

    async def initialize(self):
        """
        Explicit initialization - must be called before get_review().

        CODE QUALITY: Replaces lazy initialization with explicit lifecycle.
        Callers must now await this method before using get_review().

        FIX-005: Thread-safe initialization using double-check locking pattern.
        Multiple coroutines could call this simultaneously, causing race conditions.

        Raises:
            ImportError: If aiohttp is not installed
        """
        # Fast path: already initialized (no lock needed)
        if self._initialized:
            return

        # Slow path: acquire lock and initialize
        async with self._init_lock:
            # Double-check after acquiring lock
            if self._initialized:
                return

            await self._initialize_session_if_needed()
            self._initialized = True

    async def _initialize_session_if_needed(self):
        """
        Initialize session if not already created (lazy initialization).

        SECURITY CRITICAL: Creates aiohttp session with SSL certificate verification
        enabled by default. This prevents Man-in-the-Middle (MITM) attacks.

        PERFORMANCE: Connection pooling is configured for efficient network usage:
        - limit=10: Maximum 10 concurrent connections
        - limit_per_host=5: Maximum 5 connections per host (prevents overwhelming APIs)
        - ttl_dns_cache=300: Cache DNS for 5 minutes
        """
        if self._session is None:
            try:
                import aiohttp
                # SECURITY: Explicitly verify SSL certificates (default behavior, but documented here)
                # PERFORMANCE: Configure connection pooling for better throughput
                if self.limit_connections:
                    # Limit to 1 connection per host for APIs with strict rate limits
                    connector = aiohttp.TCPConnector(
                        limit_per_host=1,
                        ssl=True,
                        ttl_dns_cache=300  # Cache DNS for 5 minutes
                    )
                    self._session = aiohttp.ClientSession(connector=connector)
                else:
                    # PERFORMANCE: Connection pooling with sensible defaults
                    # - limit=10: Total connection limit across all hosts
                    # - limit_per_host=5: Prevents overwhelming any single API endpoint
                    connector = aiohttp.TCPConnector(
                        limit=10,
                        limit_per_host=5,
                        ssl=True,
                        ttl_dns_cache=300  # Cache DNS for 5 minutes
                    )
                    self._session = aiohttp.ClientSession(connector=connector)
                self._owner = True
            except ImportError:
                raise ImportError(
                    "aiohttp is required for async operations. "
                    "Install with: pip install aiohttp"
                )

    async def __aenter__(self):
        """Async context manager entry - calls initialize() automatically."""
        await self.initialize()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        if self._session and self._owner:
            await self._session.close()
            self._session = None

    async def close(self):
        """Explicitly close the session."""
        if self._session and self._owner:
            await self._session.close()
            self._session = None

    async def get_review(self, critic_config: CriticConfig, code: str,
                        is_multi_file: bool = False, timeout: int = 90) -> Dict[str, Any]:
        """
        Get review from the API asynchronously.

        CODE QUALITY: Requires explicit initialization via initialize() before use.
        Call 'await client.initialize()' before using get_review().

        FIX-005: For concurrent safety, acquires lock to ensure initialization
        before proceeding. If not initialized, will initialize automatically.

        Args:
            critic_config: Configuration for the critic
            code: The code to review
            is_multi_file: Whether this is a multi-file review
            timeout: Request timeout in seconds

        Returns:
            Dictionary containing the API response

        Raises:
            RuntimeError: If initialization fails
        """
        # FIX-005: Ensure initialization with lock protection
        async with self._init_lock:
            if not self._initialized:
                await self._initialize_session_if_needed()
                self._initialized = True

        # SECURITY: Connection-time DNS validation (prevents DNS rebinding)
        if self.base_url:
            SecurityValidator.validate_connection_target(self.base_url)

        await self.rate_limiter.acquire()

        url = self._build_url()
        data = self._build_request_data(critic_config, is_multi_file, code)
        headers = self._build_headers()

        # Estimate input tokens before making the request
        estimated_input_tokens = self._estimate_input_tokens(critic_config, code, is_multi_file)

        try:
            import aiohttp
            # FIX: Explicitly set all timeout parameters to ensure consistent behavior
            # sock_connect and sock_read are explicitly set to prevent default timeouts
            # from interfering with the configured total timeout
            timeout_obj = aiohttp.ClientTimeout(
                total=timeout,
                sock_connect=timeout,
                sock_read=timeout
            )
            async with self._session.post(
                url,
                json=data,
                headers=headers,
                timeout=timeout_obj
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    sanitized_error = self._sanitize_error_message(f"API Error ({response.status}): {error_text}")
                    raise APIError(sanitized_error)

                result = await response.json()

                # Track API call and token usage
                self._stats.api_calls += 1
                input_tokens, output_tokens = self._extract_usage_from_response(result)
                # Use actual tokens from API if available, otherwise use estimate
                self._stats.input_tokens += input_tokens if input_tokens > 0 else estimated_input_tokens
                self._stats.output_tokens += output_tokens if output_tokens > 0 else self._estimate_tokens(
                    result.get('choices', [{}])[0].get('message', {}).get('content', '')
                )

                return result

        except APIError:
            # Re-raise APIError as-is (already sanitized)
            raise
        except (TimeoutError, asyncio.TimeoutError) as e:
            sanitized_error = self._sanitize_error_message(f"Request timeout after {timeout} seconds")
            raise APIError(sanitized_error)
        except Exception as e:
            # Try to import aiohttp exceptions for isinstance checks
            try:
                import aiohttp
                if isinstance(e, (aiohttp.ClientError, aiohttp.ClientConnectorError,
                                 aiohttp.ServerTimeoutError)):
                    sanitized_error = self._sanitize_error_message(f"Network Error: {e}")
                    raise APIError(sanitized_error)
            except ImportError:
                pass
            # Fall through for other exceptions
            sanitized_error = self._sanitize_error_message(f"Unexpected error: {e}")
            raise APIError(sanitized_error)
    
    async def get_reviews_concurrent(self, critic_configs: list[CriticConfig],
                                   code: str, is_multi_file: bool = False, timeout: int = 90) -> list[Dict[str, Any]]:
        """Get reviews from multiple critics concurrently."""
        tasks = [
            self.get_review(config, code, is_multi_file, timeout=timeout)
            for config in critic_configs
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Filter out exceptions, return only successful results
        successful_results = []
        for result in results:
            if not isinstance(result, Exception):
                successful_results.append(result)
        
        return successful_results


class AsyncAPIClientFactory:
    """Factory for creating async API clients with optional fallback."""

    @staticmethod
    def create_client(api_key: str, base_url: str | None, model: str | None,
                     endpoint: str = "/v1/chat/completions", use_async: bool = True, limit_connections: bool = False,
                     max_requests_per_second: float = 10.0, rate_limiter = None) -> Any:
        """Create appropriate API client based on availability and preference."""
        if not use_async:
            from .api import APIClient
            return APIClient(api_key, base_url, model, endpoint, max_requests_per_second=max_requests_per_second, rate_limiter=rate_limiter)

        try:
            import aiohttp
            # aiohttp is available, return async client
            return AsyncAPIClient(api_key, base_url, model, endpoint, limit_connections=limit_connections, max_requests_per_second=max_requests_per_second, rate_limiter=rate_limiter)
        except ImportError:
            # Fall back to synchronous client
            from .api import APIClient
            return APIClient(api_key, base_url, model, endpoint, max_requests_per_second=max_requests_per_second, rate_limiter=rate_limiter)
    
    @staticmethod
    def is_async_available() -> bool:
        """Check if async dependencies are available."""
        try:
            import aiohttp
            return True
        except ImportError:
            return False