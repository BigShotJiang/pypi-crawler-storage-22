"""
Async file operations for Code Review Council using aiofiles.
Provides non-blocking file I/O for better performance.

This module has been refactored to use the shared components
(PatternMatcher, FileValidator, FileReader, ChunkStrategy) to reduce
code duplication with the sync FileCollector.

PHASE 4: Integrates ProgressCallback for tracking long operations.
"""
import atexit
import asyncio
import os
import weakref
import logging
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from concurrent.futures import ThreadPoolExecutor

from council.models import CONSTANTS
from council.exceptions import FileError
from council.secret_scanner import SecretScanner
from council.output import sanitize_path_for_display
from council.security import SecurityValidator
from council.base_file_collector import BaseFileCollector
from council.pattern_matcher import PatternMatcher
from council.file_validator import FileValidator
from council.file_reader import FileReader
from council.chunk_strategy import ChunkStrategy
from council.progress import ProgressCallback, NULL_PROGRESS, ProgressStage


logger = logging.getLogger(__name__)


class AsyncFileCollector(BaseFileCollector):
    """
    Async file collector with non-blocking I/O.

    This class now inherits from BaseFileCollector and uses the extracted
    components for pattern matching, validation, reading, and chunking.
    Only the async I/O operations are implemented in this class.

    PHASE 4: Supports progress callbacks for tracking async file collection.
    """

    # Check aiofiles availability once at class level
    _aiofiles_available = None
    # Shared thread pool executor for all instances to avoid creating too many threads
    _executor: ThreadPoolExecutor = None
    # Track whether cleanup has been registered
    _cleanup_registered = False
    # Track cleanup warning flag
    _cleanup_warned = False
    # Store instance for weakref finalizer
    _finalizer_ref = None

    @classmethod
    def _check_aiofiles_availability(cls) -> bool:
        """Check if aiofiles is available (cached at class level)."""
        if cls._aiofiles_available is None:
            try:
                import aiofiles
                cls._aiofiles_available = True
            except ImportError:
                cls._aiofiles_available = False
        return cls._aiofiles_available

    @classmethod
    def _cleanup_executor(cls):
        """
        Clean up the shared thread pool executor.

        Ensures threads are properly terminated when the process exits.
        This is registered with atexit to prevent resource leaks.
        """
        if cls._executor is not None:
            try:
                cls._executor.shutdown(wait=True)
                cls._executor = None
            except Exception:
                pass  # Best effort cleanup during shutdown

    @classmethod
    def shutdown(cls, warn_if_unclean: bool = True):
        """
        Explicitly clean up the shared thread pool executor.

        Args:
            warn_if_unclean: If True, log a warning if executor was active

        Example:
            collector = AsyncFileCollector(...)
            try:
                files, metadata = await collector.collect_project_files_async(path)
            finally:
                AsyncFileCollector.shutdown()
        """
        was_active = cls._executor is not None
        if was_active and warn_if_unclean and not cls._cleanup_warned:
            logger.warning(
                "AsyncFileCollector.shutdown() was called with active executor. "
                "Consider using context manager (async with) for automatic cleanup, "
                "or call shutdown() after all async operations complete."
            )
            cls._cleanup_warned = True

        cls._cleanup_executor()
        cls._cleanup_registered = False

    @classmethod
    def _get_executor(cls) -> ThreadPoolExecutor:
        """
        Get or create the shared thread pool executor.

        FIX-008: Thread pool size is configurable via TTC_MAX_FILE_WORKERS
        environment variable. Defaults to min(8, (cpu_count * 2)).

        Registers atexit handler on first creation to ensure
        proper cleanup on process exit, preventing resource leaks.
        """
        if cls._executor is None:
            # FIX-008: Configurable max workers via environment variable
            default = min(8, (os.cpu_count() or 2) * 2)
            env_value = os.environ.get('TTC_MAX_FILE_WORKERS')
            if env_value:
                try:
                    max_workers = min(int(env_value), default * 2)
                except ValueError:
                    max_workers = default
            else:
                max_workers = default

            cls._executor = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="async_file_io")

            # Register cleanup on process exit (only once)
            if not cls._cleanup_registered:
                atexit.register(cls._cleanup_executor)
                cls._cleanup_registered = True

                # Also register weakref finalizer as backup
                def finalizer_cleanup():
                    if cls._executor is not None:
                        logger.debug("AsyncFileCollector: weakref finalizer cleaning up executor")
                        cls._cleanup_executor()

                cls._finalizer_ref = weakref.finalize(cls, finalizer_cleanup)

        return cls._executor

    @classmethod
    def _check_executor_size(cls):
        """
        Check if executor thread count has grown unexpectedly.

        Logs warning if executor size exceeds expected maximum.
        """
        if cls._executor is not None:
            # ThreadPoolExecutor doesn't expose active thread count directly,
            # but we can warn if the executor exists and wasn't properly cleaned
            if not cls._cleanup_warned:
                logger.debug(
                    f"AsyncFileCollector: Executor active with max_workers={cls._executor._max_workers}. "
                    "Call AsyncFileCollector.shutdown() for cleanup when done."
                )

    def __init__(
        self,
        ignore_patterns: List[str],
        output_formatter,
        progress_callback: ProgressCallback = NULL_PROGRESS
    ):
        """
        Initialize the async file collector.

        Args:
            ignore_patterns: List of ignore patterns
            output_formatter: Output formatter for display
            progress_callback: Optional progress callback for long operations
        """
        # Initialize base class with extracted components
        super().__init__(ignore_patterns, output_formatter)

        # Async-specific state
        self._lock = asyncio.Lock()
        self._project_root: Optional[str] = None

        # Initialize aiofiles availability check
        self._check_aiofiles_availability()

        # Counter dict for async operations
        self._size_counter = {'total_size_bytes': 0, 'file_count': 0}

        # Progress callback
        self._progress_callback = progress_callback

    async def __aenter__(self):
        """Context manager entry for automatic cleanup."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """
        Context manager exit with automatic cleanup.

        Note: We don't call class-level shutdown here because there might
        be other instances using the shared executor.
        """
        return False

    def _validate_file_within_project(self, filepath: str) -> None:
        """
        Validate that a file path is within the project directory.

        Security: Prevents path traversal attacks where attacker could read
        files outside the project directory.

        Args:
            filepath: Absolute path to the file to validate

        Raises:
            ValueError: If filepath is outside the project directory
        """
        if self._project_root is None:
            return  # No project root set, skip validation

        # Use FileValidator for validation
        try:
            self.file_validator.validate_within_project(filepath)
        except ValueError as e:
            raise ValueError(
                f"Security: File '{filepath}' is not accessible from project '{self._project_root}'."
            )
    
    def collect_project_files(self, path: str) -> Tuple[Dict[str, str], Dict[str, Tuple[int, float]]]:
        """Sync version for compatibility - runs async version in thread."""
        import asyncio
        return asyncio.run(self.collect_project_files_async(path))

    async def collect_project_files_async(
        self,
        path: str,
        progress_callback: Optional[ProgressCallback] = None
    ) -> Tuple[Dict[str, str], Dict[str, Tuple[int, float]]]:
        """
        Collect all code files from a project directory asynchronously.

        PHASE 4: Supports progress callbacks for tracking async collection progress.

        Args:
            path: Path to the project directory or single file
            progress_callback: Optional progress callback (overrides instance callback)

        Returns:
            Tuple of (files_content, files_metadata)
        """
        # Use provided callback or fall back to instance callback
        callback = progress_callback if progress_callback is not None else self._progress_callback

        files_content = {}
        self.files_metadata = {}
        self._size_counter = {'total_size_bytes': 0, 'file_count': 0}

        # Security: Store project root for path validation
        self.set_project_root(path)
        self._project_root = os.path.abspath(path)

        # Single file
        if os.path.isfile(path):
            callback(0, 1, f"Reading {sanitize_path_for_display(path)}", ProgressStage.LOADING)
            if not self.should_ignore_file(path) and self.is_text_file(path):
                try:
                    result = await self._read_file_with_size_check_async(path)
                    if result is not None:
                        content, file_size, file_mtime = result
                        files_content[path] = content
                        self.files_metadata[path] = (file_size, file_mtime)
                        print(f"  {self.output_formatter.color_class.GREEN}✓{self.output_formatter.color_class.RESET} {sanitize_path_for_display(path)}")
                except Exception as e:
                    self.output_formatter.print_warning(f"Could not read {sanitize_path_for_display(path)}: {e}")
            callback(1, 1, "Done", ProgressStage.LOADING)
            return files_content, self.files_metadata

        # Directory
        if not os.path.isdir(path):
            raise FileError(f"Path does not exist: {path}")

        self.output_formatter.print_warning(f"📂 Scanning project directory (async): {path}")

        # Collect all file paths first using run_in_executor to avoid blocking
        loop = asyncio.get_event_loop()
        executor = self._get_executor()
        all_filepaths = await loop.run_in_executor(executor, self._collect_filepaths, path)

        if not all_filepaths:
            return files_content, self.files_metadata

        total_files = len(all_filepaths)
        callback(0, total_files, f"Loading {total_files} files...", ProgressStage.LOADING)

        # Process files concurrently
        tasks = []
        for relative_path, filepath in all_filepaths:
            task = self._process_file_async(filepath, relative_path)
            tasks.append(task)

        # Gather results
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Process results
        completed_count = 0
        for (relative_path, filepath), result in zip(all_filepaths, results):
            if isinstance(result, Exception):
                self.output_formatter.print_warning(f"⚠ {relative_path} (error: {result})")
            elif result is not None:
                content, file_size, file_mtime = result
                files_content[relative_path] = content
                self.files_metadata[relative_path] = (file_size, file_mtime)
                print(f"  {self.output_formatter.color_class.GREEN}✓{self.output_formatter.color_class.RESET} {relative_path}")

            completed_count += 1
            if completed_count % 10 == 0 or completed_count == total_files:
                callback(completed_count, total_files, f"Loaded {completed_count}/{total_files} files", ProgressStage.LOADING)

        callback(total_files, total_files, "Done", ProgressStage.LOADING)
        return files_content, self.files_metadata
    
    async def _process_file_async(self, filepath: str, relative_path: str) -> Optional[Tuple[str, int, float]]:
        """Process a single file asynchronously."""
        try:
            result = await self._read_file_with_size_check_async(filepath)
            return result
        except OSError as e:
            raise FileError(f"Could not read {sanitize_path_for_display(filepath)}: {e}")

    async def _read_file_with_size_check_async(self, filepath: str) -> Optional[Tuple[str, int, float]]:
        """
        Read file with size checking asynchronously.

        This method has been refactored to reduce deep nesting using early returns.

        Args:
            filepath: Path to the file to read

        Returns:
            Tuple of (content, file_size, file_mtime) or None if file should be skipped
        """
        try:
            # Security: Validate file is within project directory (prevents path traversal)
            self._validate_file_within_project(filepath)

            # Validate project path before file operations (security improvement)
            SecurityValidator.validate_project_path(filepath, allow_system_paths=False)

            # Scan filename for sensitive patterns BEFORE reading
            SecretScanner.scan_filename(filepath)

            # Check file size and mtime using run_in_executor to avoid blocking the event loop
            loop = asyncio.get_event_loop()
            executor = self._get_executor()
            stat = await loop.run_in_executor(executor, os.stat, filepath)
            file_size = stat.st_size
            file_mtime = stat.st_mtime

            # Early return: Check individual file size
            if not self.file_validator.check_individual_file_size(file_size):
                return None

            # Early return: Check total size limit
            current_total = self._size_counter.get('total_size_bytes', 0)
            if not self.file_validator.check_total_size(current_total, file_size):
                return None

            # Early return: Check file count limit
            current_count = self._size_counter.get('file_count', 0)
            if not self.file_validator.check_file_count(current_count):
                return None

            # Read file content
            content = await self._read_file_content_async(filepath, loop, executor)
            if content is None or not content.strip():
                return None

            # Process content (redact secrets)
            processed_content = await self._process_content_async(content, filepath)

            # Update counters
            self.file_reader.update_counters(self._size_counter, file_size)

            return processed_content, file_size, file_mtime

        except OSError as e:
            raise FileError(f"Could not read {sanitize_path_for_display(filepath)}: {e}")

    async def _read_file_content_async(
        self,
        filepath: str,
        loop: asyncio.AbstractEventLoop,
        executor: ThreadPoolExecutor
    ) -> Optional[str]:
        """
        Read file content asynchronously or with fallback.

        SECURITY FIX: Uses os.O_NOFOLLOW to prevent symlink attacks. Symlinks
        are rejected at the OS level before any content is read, preventing
        an attacker from exfiltrating sensitive files via symlinked paths.

        Args:
            filepath: Path to the file to read
            loop: Event loop
            executor: Thread pool executor

        Returns:
            File content or None if read failed
        """
        # SECURITY FIX: Check for symlinks before reading
        if os.path.islink(filepath):
            from council.exceptions import FileError
            raise FileError(
                f"Security: File '{sanitize_path_for_display(filepath)}' is a symlink. "
                f"Symlinks are not allowed to prevent path traversal attacks."
            )

        if self._check_aiofiles_availability():
            # Use async I/O
            import aiofiles
            async with aiofiles.open(filepath, 'r', encoding='utf-8') as f:
                return await f.read()
        else:
            # Fall back to synchronous reading BUT avoid blocking event loop
            # SECURITY FIX: Use O_NOFOLLOW to prevent symlink attacks
            def read_sync():
                fd = None
                try:
                    fd = os.open(filepath, os.O_RDONLY | os.O_NOFOLLOW)
                    with open(fd, 'r', encoding='utf-8') as f:
                        return f.read()
                except OSError as e:
                    if os.path.islink(filepath):
                        from council.exceptions import FileError
                        raise FileError(
                            f"Security: File '{sanitize_path_for_display(filepath)}' is a symlink. "
                            f"Symlinks are not allowed to prevent path traversal attacks."
                        )
                    raise
                finally:
                    if fd is not None:
                        try:
                            os.close(fd)
                        except OSError:
                            pass

            return await loop.run_in_executor(executor, read_sync)

    async def _process_content_async(self, content: str, filepath: str) -> str:
        """
        Process file content after reading (redact secrets).

        Args:
            content: Raw file content
            filepath: Path to the file

        Returns:
            Processed content with secrets redacted
        """
        # CRITICAL SECURITY FIX: Redact secrets BEFORE storing content
        # PERFORMANCE FIX: Use async version to avoid blocking event loop
        redacted_content, secrets = await SecretScanner.redact_secrets_async(content, filepath)

        if secrets:
            # Log what was redacted
            self.output_formatter.print_warning(
                f"  {self.output_formatter.color_class.YELLOW}⚠{self.output_formatter.color_class.RESET} "
                f"Redacted {len(secrets)} secret(s) from {sanitize_path_for_display(filepath)}"
            )

        return redacted_content if secrets else content

    # Note: should_ignore_file and is_text_file are now inherited from BaseFileCollector
    # Note: should_chunk and chunk_files are now inherited from BaseFileCollector


    def estimate_project_size(self, path: str) -> Tuple[int, int, int]:
        """
        Estimate project size without loading file contents (sync wrapper).

        Args:
            path: Path to the project directory or single file

        Returns:
            Tuple of (total_files, total_size_bytes, eligible_files)
        """
        self.set_project_root(path)
        return self._estimate_project_size_sync(path)

    def collect_filepaths_and_metadata(self, path: str) -> Tuple[List[str], Dict[str, Tuple[int, float]]]:
        """
        Collect file paths and metadata WITHOUT loading file contents.

        This is critical for cache checking: we need to generate a cache key
        BEFORE loading all files into memory. For a 10MB project on cache hit,
        this saves 0.5-2s of wasted I/O and memory allocation.

        Args:
            path: Path to the project directory or single file

        Returns:
            Tuple of (filepaths, files_metadata) where:
            - filepaths: List of file paths (relative to project root)
            - files_metadata: Dict mapping filepath to (size, mtime) tuple
        """
        self.set_project_root(path)
        return self._collect_filepaths_and_metadata_sync(path)

    def _collect_filepaths(self, path: str) -> List[Tuple[str, str]]:
        """
        Collect all file paths synchronously (blocking, should be run in executor).

        Args:
            path: Path to the project directory

        Returns:
            List of tuples (relative_path, absolute_path)
        """
        return self._collect_filepaths_sync(path)

    async def collect_project_files_streaming_async(
        self,
        path: str,
        progress_callback: Optional[ProgressCallback] = None
    ) -> Tuple[Dict[str, str], Dict[str, Tuple[int, float]]]:
        """
        Collect project files using async streaming mode.

        This method processes files in batches to reduce memory usage for large projects.
        Unlike collect_project_files_async which loads all files at once, this method
        yields files as they are processed and maintains constant memory usage.

        PHASE 4: Supports progress callbacks for tracking streaming progress.

        Args:
            path: Path to the project directory or single file
            progress_callback: Optional progress callback (overrides instance callback)

        Returns:
            Tuple of (files_content, files_metadata)
        """
        from typing import Generator

        # Use provided callback or fall back to instance callback
        callback = progress_callback if progress_callback is not None else self._progress_callback

        self.files_metadata = {}
        self._size_counter = {'total_size_bytes': 0, 'file_count': 0}

        # Set project root for security validation
        self.set_project_root(path)

        # Single file
        if os.path.isfile(path):
            callback(0, 1, f"Reading {sanitize_path_for_display(path)}", ProgressStage.LOADING)
            if not self.should_ignore_file(path) and self.is_text_file(path):
                try:
                    result = await self._read_file_with_size_check_async(path)
                    if result is not None:
                        content, file_size, file_mtime = result
                        self.files_metadata[path] = (file_size, file_mtime)
                        print(f"  {self.output_formatter.color_class.GREEN}✓{self.output_formatter.color_class.RESET} {sanitize_path_for_display(path)}")
                        callback(1, 1, "Done", ProgressStage.LOADING)
                        return {path: content}, self.files_metadata
                except Exception as e:
                    self.output_formatter.print_warning(f"Could not read {sanitize_path_for_display(path)}: {e}")
            return {}, self.files_metadata

        # Directory
        if not os.path.isdir(path):
            raise FileError(f"Path does not exist: {path}")

        self.output_formatter.print_warning(f"📂 Scanning project directory (streaming mode): {path}")

        # Collect all filepaths first (lightweight operation)
        loop = asyncio.get_event_loop()
        executor = self._get_executor()
        all_filepaths = await loop.run_in_executor(executor, self._collect_filepaths, path)

        if not all_filepaths:
            return {}, self.files_metadata

        total_files = len(all_filepaths)
        callback(0, total_files, f"Streaming {total_files} files...", ProgressStage.LOADING)

        # Process files in batches to limit memory usage
        BATCH_SIZE = 20  # Process 20 files at a time
        files_content = {}
        completed_count = 0

        for i in range(0, len(all_filepaths), BATCH_SIZE):
            batch = all_filepaths[i:i + BATCH_SIZE]
            tasks = []

            for relative_path, filepath in batch:
                task = self._process_file_async(filepath, relative_path)
                tasks.append(task)

            # Gather results for this batch
            results = await asyncio.gather(*tasks, return_exceptions=True)

            # Process results for this batch
            for (relative_path, filepath), result in zip(batch, results):
                if isinstance(result, Exception):
                    self.output_formatter.print_warning(f"⚠ {relative_path} (error: {result})")
                elif result is not None:
                    content, file_size, file_mtime = result
                    files_content[relative_path] = content
                    self.files_metadata[relative_path] = (file_size, file_mtime)
                    print(f"  {self.output_formatter.color_class.GREEN}✓{self.output_formatter.color_class.RESET} {relative_path}")

            completed_count += len(batch)
            if completed_count % 10 == 0 or completed_count >= total_files:
                callback(min(completed_count, total_files), total_files, f"Loaded {min(completed_count, total_files)}/{total_files} files", ProgressStage.LOADING)

        callback(total_files, total_files, "Done", ProgressStage.LOADING)
        return files_content, self.files_metadata


class AsyncFileCollectorFactory:
    """
    Factory for creating async file collectors with fallback.

    PHASE 4: Supports progress callback injection.
    """

    @staticmethod
    def create_collector(
        ignore_patterns: List[str],
        output_formatter,
        use_async: bool = True,
        progress_callback: ProgressCallback = NULL_PROGRESS
    ):
        """
        Create appropriate file collector based on availability.

        PHASE 4: Passes progress callback to created collectors.

        Args:
            ignore_patterns: List of ignore patterns
            output_formatter: Output formatter for display
            use_async: Whether to use async file operations
            progress_callback: Optional progress callback for long operations

        Returns:
            FileCollector instance (sync or async based on availability)
        """
        if not use_async:
            from .files import FileCollector
            return FileCollector(ignore_patterns, output_formatter, progress_callback)

        if AsyncFileCollector._check_aiofiles_availability():
            # aiofiles is available, return async collector
            return AsyncFileCollector(ignore_patterns, output_formatter, progress_callback)
        else:
            # Fall back to synchronous collector
            from .files import FileCollector
            return FileCollector(ignore_patterns, output_formatter, progress_callback)

    @staticmethod
    def is_async_available() -> bool:
        """Check if async file operations are available."""
        return AsyncFileCollector._check_aiofiles_availability()