"""
Async review runner for Code Review Council.
Runs all 3 critic reviews concurrently for better performance.
"""
import asyncio
import time
from typing import List, Dict, Any
from .models import CriticConfig, ReviewResult, APIUsageStats
from .exceptions import APIError
from .review import ReviewParser
from .formatters import ReviewFormatter


class AsyncReviewRunner:
    """Runs reviews for all critics concurrently or sequentially."""

    def __init__(self, api_client, output_formatter, color_class=None, timeout: int = 90, sequential: bool = False):
        self.api_client = api_client
        self.output_formatter = output_formatter
        self.color_class = color_class
        self.timeout = timeout
        self.sequential = sequential

    def get_stats(self) -> APIUsageStats:
        """Get API usage statistics from the client."""
        if hasattr(self.api_client, 'get_stats'):
            return self.api_client.get_stats()
        return APIUsageStats()
    
    # Add sync methods for compatibility
    def run_reviews(self, critics: List, project_content: str, 
                   is_multi_file: bool, verbose: bool = False):
        """Sync version - runs async version."""
        import asyncio
        return asyncio.run(self.run_reviews_async(critics, project_content, is_multi_file, verbose))
    
    def run_chunked_reviews(self, critics: List, chunks: List[Dict[str, str]], 
                          context_files: Dict[str, str], details: str, verbose: bool = False):
        """Sync version - runs async version."""
        import asyncio
        return asyncio.run(self.run_chunked_reviews_async(critics, chunks, context_files, details, verbose))
    
    async def run_reviews_async(self, critics: List, project_content: str,
                              is_multi_file: bool, verbose: bool = False) -> List[ReviewResult]:
        """Run reviews for all critics concurrently or sequentially."""
        results = []

        if self.sequential:
            # Run reviews one at a time
            for critic in critics:
                print(f"\n{critic.icon} {critic.name} is reviewing...", end='', flush=True)
                try:
                    result = await self._review_critic_async(critic, project_content, is_multi_file, verbose)
                    results.append(result)
                    print(f"\r{critic.icon} {critic.name} review complete ✓")
                except Exception as e:
                    print(f"\r{critic.icon} {critic.name} review failed ✗")
                    raise APIError(f"Review failed for {critic.name}: {e}")
        else:
            # Run all reviews concurrently
            print(f"\n🔍 All {len(critics)} critics reviewing concurrently...")

            # Start all reviews concurrently
            tasks = []
            for critic in critics:
                task = self._review_critic_async(critic, project_content, is_multi_file, verbose)
                tasks.append(task)

            # Wait for all reviews to complete
            critic_results = await asyncio.gather(*tasks, return_exceptions=True)

            # Process results
            for critic, result in zip(critics, critic_results):
                if isinstance(result, Exception):
                    print(f"\r{critic.icon} {critic.name} review failed ✗")
                    raise APIError(f"Review failed for {critic.name}: {result}")
                else:
                    results.append(result)
                    print(f"\r{critic.icon} {critic.name} review complete ✓")

        return results
    
    async def run_reviews_async(self, critics: List, project_content: str,
                              is_multi_file: bool, verbose: bool = False) -> List[ReviewResult]:
        """
        Run reviews for all critics concurrently or sequentially.

        CODE QUALITY: Explicitly calls initialize() on AsyncAPIClient before use.
        """
        # Initialize client if needed (for AsyncAPIClient)
        if hasattr(self.api_client, 'initialize'):
            await self.api_client.initialize()

        results = []

        if self.sequential:
            # Run reviews one at a time
            for critic in critics:
                print(f"\n{critic.icon} {critic.name} is reviewing...", end='', flush=True)
                try:
                    result = await self._review_critic_async(critic, project_content, is_multi_file, verbose)
                    results.append(result)
                    print(f"\r{critic.icon} {critic.name} review complete ✓")
                except Exception as e:
                    print(f"\r{critic.icon} {critic.name} review failed ✗")
                    raise APIError(f"Review failed for {critic.name}: {e}")
        else:
            # Run all reviews concurrently
            print(f"\n🔍 All {len(critics)} critics reviewing concurrently...")

            # Start all reviews concurrently
            tasks = []
            for critic in critics:
                task = self._review_critic_async(critic, project_content, is_multi_file, verbose)
                tasks.append(task)

            # Wait for all reviews to complete
            critic_results = await asyncio.gather(*tasks, return_exceptions=True)

            # Process results
            for critic, result in zip(critics, critic_results):
                if isinstance(result, Exception):
                    print(f"\r{critic.icon} {critic.name} review failed ✗")
                    raise APIError(f"Review failed for {critic.name}: {result}")
                else:
                    results.append(result)
                    print(f"\r{critic.icon} {critic.name} review complete ✓")

        return results

    async def _review_critic_async(self, critic, project_content: str,
                                 is_multi_file: bool, verbose: bool) -> ReviewResult:
        """Review a single critic asynchronously."""
        try:
            # Make API call with timeout
            response = await self.api_client.get_review(
                critic.config, project_content, is_multi_file, timeout=self.timeout
            )
            review_text = response.get('choices', [{}])[0].get('message', {}).get('content', '')

            if not review_text:
                raise APIError("No response from API")

            critic.set_review(review_text)

            if verbose:
                print(f"\n{critic.review}\n")

            return critic.to_result()

        except APIError:
            # Don't wrap APIError again - just re-raise it
            raise
        except Exception as e:
            # Wrap other exceptions as APIError
            raise APIError(f"Review failed for {critic.name}: {e}")
    
    async def run_chunked_reviews_async(self, critics: List, chunks: List[Dict[str, str]], 
                                      context_files: Dict[str, str], details: str, 
                                      verbose: bool = False) -> List[ReviewResult]:
        """Run reviews for chunks of files with async processing."""
        results = []
        total_chunks = len(chunks)
        
        for chunk_idx, chunk in enumerate(chunks, 1):
            self.output_formatter.print_warning(f"Processing chunk {chunk_idx}/{total_chunks} ({len(chunk)} files)")

            # Use centralized review formatter for consistency
            chunk_content = ReviewFormatter.format_chunk_content(
                chunk=chunk,
                chunk_idx=chunk_idx,
                total_chunks=total_chunks,
                context_files=context_files if chunk_idx == 1 else None,
                details=details
            )
            
            is_multi_file = len(chunk) > 1
            
            # Run reviews for this chunk concurrently
            chunk_results = await self.run_reviews_async(critics, chunk_content, is_multi_file, verbose)
            results.extend(chunk_results)
        
        return results


class AsyncReviewRunnerFactory:
    """Factory for creating async review runners with fallback."""

    @staticmethod
    def create_runner(api_client, output_formatter, color_class=None, use_async: bool = True, timeout: int = 90, sequential: bool = False):
        """Create appropriate review runner based on availability."""
        if not use_async:
            from .review import ReviewRunner
            return ReviewRunner(api_client, output_formatter, color_class, timeout=timeout)

        # Check if we have an async API client
        from .async_api import AsyncAPIClient
        if isinstance(api_client, AsyncAPIClient):
            return AsyncReviewRunner(api_client, output_formatter, color_class, timeout=timeout, sequential=sequential)
        else:
            # Fall back to synchronous runner
            from .review import ReviewRunner
            return ReviewRunner(api_client, output_formatter, color_class, timeout=timeout)