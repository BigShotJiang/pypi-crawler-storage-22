"""
Base file collector with shared functionality for sync and async implementations.

This module provides the abstract interface and common base class for file collectors,
reducing code duplication between sync and async implementations.
"""
import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Generator

from council.models import CONSTANTS
from council.exceptions import FileError
from council.output import OutputFormatter, sanitize_path_for_display
from council.security import SecurityValidator
from council.pattern_matcher import PatternMatcher
from council.file_validator import FileValidator
from council.file_reader import FileReader
from council.chunk_strategy import ChunkStrategy


class FileCollectorInterface(ABC):
    """
    Abstract interface for file collectors.

    This interface defines the contract that both sync and async file collectors
    must implement, ensuring consistent behavior across implementations.
    """

    @abstractmethod
    def collect_project_files(self, path: str) -> Tuple[Dict[str, str], Dict[str, Tuple[int, float]]]:
        """
        Collect all code files from a project directory.

        Args:
            path: Path to the project directory or single file

        Returns:
            Tuple of (files_content, files_metadata) where:
            - files_content: Dict mapping filepath to file content
            - files_metadata: Dict mapping filepath to (size, mtime) tuple
        """
        pass

    @abstractmethod
    def collect_filepaths_and_metadata(self, path: str) -> Tuple[List[str], Dict[str, Tuple[int, float]]]:
        """
        Collect file paths and metadata WITHOUT loading file contents.

        This is critical for cache checking: we need to generate a cache key
        BEFORE loading all files into memory.

        Args:
            path: Path to the project directory or single file

        Returns:
            Tuple of (filepaths, files_metadata) where:
            - filepaths: List of file paths (relative to project root)
            - files_metadata: Dict mapping filepath to (size, mtime) tuple
        """
        pass

    @abstractmethod
    def should_chunk(self, files_content: Dict[str, str]) -> bool:
        """
        Determine if files should be chunked based on limits.

        Args:
            files_content: Dict mapping filepath to file content

        Returns:
            True if chunking is recommended, False otherwise
        """
        pass

    @abstractmethod
    def chunk_files(self, files_content: Dict[str, str], strategy: str, user_chunk_size: int = None) -> List[Dict[str, str]]:
        """
        Chunk files using specified strategy.

        Args:
            files_content: Dict mapping filepath to file content
            strategy: Chunking strategy ("size", "directory", or "type")
            user_chunk_size: User-provided chunk size (None = auto-calculate optimal)

        Returns:
            List of chunks, each chunk is a dict mapping filepath to content
        """
        pass

    @abstractmethod
    def estimate_project_size(self, path: str) -> Tuple[int, int, int]:
        """
        Estimate project size without loading file contents.

        Args:
            path: Path to the project directory or single file

        Returns:
            Tuple of (total_files, total_size_bytes, eligible_files)
        """
        pass


class BaseFileCollector(FileCollectorInterface):
    """
    Base class for file collectors with common functionality.

    This class provides shared implementation for pattern matching,
    file validation, and chunking that is used by both sync and async
    implementations.
    """

    def __init__(self, ignore_patterns: List[str], output_formatter: OutputFormatter):
        """
        Initialize the base file collector.

        Args:
            ignore_patterns: List of ignore patterns
            output_formatter: Output formatter for display
        """
        self.ignore_patterns = ignore_patterns
        self.output_formatter = output_formatter

        # Use extracted components
        self.pattern_matcher = PatternMatcher(ignore_patterns)
        self.file_validator = FileValidator()
        self.file_reader = FileReader(output_formatter, self.file_validator)
        self.chunk_strategy = ChunkStrategy(output_formatter)

        # State tracking
        self.total_size_bytes = 0
        self.file_count = 0
        self.files_metadata: Dict[str, Tuple[int, float]] = {}

    def set_project_root(self, path: str) -> None:
        """
        Set the project root for security validation.

        Args:
            path: Path to the project directory
        """
        self.file_validator.set_project_root(os.path.abspath(path))

    def should_ignore_file(self, filepath: str) -> bool:
        """
        Check if file should be ignored based on patterns.

        Args:
            filepath: Path to the file to check

        Returns:
            True if file should be ignored, False otherwise
        """
        return self.pattern_matcher.should_ignore_file(filepath)

    def is_text_file(self, filepath: str) -> bool:
        """
        Check if file is likely a text/code file.

        Args:
            filepath: Path to the file to check

        Returns:
            True if file appears to be a text file, False otherwise
        """
        return self.file_validator.is_text_file(filepath)

    def should_chunk(self, files_content: Dict[str, str]) -> bool:
        """Delegate to ChunkStrategy."""
        return self.chunk_strategy.should_chunk(files_content)

    def chunk_files(self, files_content: Dict[str, str], strategy: str = "size", user_chunk_size: int = None) -> List[Dict[str, str]]:
        """Delegate to ChunkStrategy."""
        return self.chunk_strategy.chunk_files(files_content, strategy, user_chunk_size)

    def _collect_filepaths_sync(self, path: str) -> List[Tuple[str, str]]:
        """
        Collect all file paths synchronously (internal helper).

        Args:
            path: Path to the project directory

        Returns:
            List of tuples (relative_path, absolute_path)
        """
        all_filepaths = []

        for root, dirs, files in os.walk(path):
            # Filter out ignored directories
            dirs[:] = [d for d in dirs if not self.should_ignore_file(os.path.join(root, d))]

            for file in files:
                filepath = os.path.join(root, file)
                relative_path = os.path.relpath(filepath, path)

                if self.should_ignore_file(filepath):
                    continue

                if not self.is_text_file(filepath):
                    continue

                all_filepaths.append((relative_path, filepath))

        return all_filepaths

    def _collect_filepaths_and_metadata_sync(self, path: str) -> Tuple[List[str], Dict[str, Tuple[int, float]]]:
        """
        Collect file paths and metadata WITHOUT loading file contents (sync).

        Args:
            path: Path to the project directory or single file

        Returns:
            Tuple of (filepaths, files_metadata)
        """
        filepaths = []
        files_metadata = {}

        # Single file
        if os.path.isfile(path):
            if not self.should_ignore_file(path) and self.is_text_file(path):
                try:
                    stat = os.stat(path)
                    filepaths.append(path)
                    files_metadata[path] = (stat.st_size, stat.st_mtime)
                except Exception:
                    pass
            return filepaths, files_metadata

        # Directory
        if not os.path.isdir(path):
            raise FileError(f"Path does not exist: {path}")

        for root, dirs, files in os.walk(path):
            # Filter out ignored directories
            dirs[:] = [d for d in dirs if not self.should_ignore_file(os.path.join(root, d))]

            for file in files:
                filepath = os.path.join(root, file)
                relative_path = os.path.relpath(filepath, path)

                if self.should_ignore_file(filepath):
                    continue

                if not self.is_text_file(filepath):
                    continue

                try:
                    stat = os.stat(filepath)
                    filepaths.append(relative_path)
                    files_metadata[relative_path] = (stat.st_size, stat.st_mtime)
                except Exception:
                    pass

        return filepaths, files_metadata

    def _estimate_project_size_sync(self, path: str) -> Tuple[int, int, int]:
        """
        Estimate project size without loading file contents (sync).

        Args:
            path: Path to the project directory or single file

        Returns:
            Tuple of (total_files, total_size_bytes, eligible_files)
        """
        total_files = 0
        total_size_bytes = 0
        eligible_files = 0

        # Single file
        if os.path.isfile(path):
            if not self.should_ignore_file(path) and self.is_text_file(path):
                stat = os.stat(path)
                return 1, stat.st_size, 1
            return 0, 0, 0

        # Directory
        if not os.path.isdir(path):
            raise FileError(f"Path does not exist: {path}")

        for root, dirs, files in os.walk(path):
            # Filter out ignored directories
            dirs[:] = [d for d in dirs if not self.should_ignore_file(os.path.join(root, d))]

            for file in files:
                filepath = os.path.join(root, file)
                total_files += 1

                if self.should_ignore_file(filepath):
                    continue

                if not self.is_text_file(filepath):
                    continue

                try:
                    stat = os.stat(filepath)
                    file_size = stat.st_size
                    total_size_bytes += file_size
                    eligible_files += 1
                except Exception:
                    pass

        return total_files, total_size_bytes, eligible_files
