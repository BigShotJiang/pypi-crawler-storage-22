"""
Caching layer for Code Review Council.
Cache file metadata and previous reviews to improve performance.

CODE QUALITY IMPROVEMENT: Refactored to use focused components:
- CacheStorage: disk I/O (no security logic)
- CacheIntegrity: HMAC signing/verification (security-critical)
- CacheMetadata: keys, expiration, stats (performance-critical)

This class now acts as a facade over the specialized components, maintaining
backward compatibility with the existing public API.
"""
import os
import json
import time
import stat
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple

from council.cache_storage import CacheStorage
from council.cache_integrity import CacheIntegrity
from council.cache_metadata import CacheMetadata


class ReviewCache:
    """
    Cache facade over focused components.

    CRITICAL SECURITY (Phase 1): The _ensure_cache_dir() method is preserved
    exactly as-is to maintain the TOCTOU race condition fix using atomic
    mkdir with mode=0o700.

    CRITICAL PERFORMANCE (Phase 2): The get_cache_key() method delegates to
    CacheMetadata which uses file metadata (size + mtime) instead of content
    hashing for O(n) performance instead of O(content).

    Public API unchanged for backward compatibility.
    Internal implementation delegates to specialized components.

    FIX-009: Implements size-based cache eviction to prevent unbounded growth.

    FIX-013: Error handling follows the decision matrix documented in exceptions.py:
    - Cache miss: return None (expected behavior, not an error)
    - Invalid cache data: print warning + return None (non-critical)
    - Security violations (bad signature): print warning + delete + return None
    - Disk I/O failures: return None (graceful degradation)
    - Critical security issues: raise RuntimeError (e.g., wrong permissions)
    """

    SIGNATURE_PREFIX = CacheStorage.SIGNATURE_PREFIX

    # FIX-009: Maximum cache size in MB (configurable via TTC_MAX_CACHE_MB)
    MAX_CACHE_SIZE_MB = int(os.environ.get('TTC_MAX_CACHE_MB', 500))

    def __init__(self, cache_dir: str = "~/.ttc/.councilcache", ttl_hours: int = 24):
        self.cache_dir = Path(cache_dir).expanduser()
        self.ttl_hours = ttl_hours

        # CRITICAL: Keep Phase 1 TOCTOU fix - this must run before any other operations
        self._ensure_cache_dir()
        self.integrity = CacheIntegrity(self.cache_dir)
        self.storage = CacheStorage(self.cache_dir)
        self.metadata = CacheMetadata(self.cache_dir, ttl_hours)
        self.metadata.set_signing_key(self.integrity._signing_key)

        # FIX-009: Update max cache size from environment if set
        ReviewCache.MAX_CACHE_SIZE_MB = int(os.environ.get('TTC_MAX_CACHE_MB', 500))

    def _ensure_cache_dir(self):
        """
        Ensure cache directory exists with secure permissions atomically.

        CRITICAL SECURITY FIX (Phase 1): KEEP THIS METHOD UNCHANGED.
        Uses atomic mkdir with mode=0o700 to prevent TOCTOU race condition.
        The old approach of mkdir() + chmod() allows a window where directory
        exists with wrong permissions.

        If directory already exists, verify ownership and permissions before using.
        Fail fast if permissions are incorrect (don't silently fix).
        """
        if self.cache_dir.exists():
            # CRITICAL: Verify existing directory has correct permissions
            # Don't silently use directories with insecure permissions
            stat_info = self.cache_dir.stat()
            mode = stat_info.st_mode & 0o777

            if mode != 0o700:
                raise RuntimeError(
                    f"Security: Cache directory has insecure permissions: {oct(mode)}. "
                    f"Expected 0o700. Please fix manually: chmod 0700 {self.cache_dir}"
                )

            # Verify we own the directory (not a symlink attack)
            if stat_info.st_uid != os.getuid():
                raise RuntimeError(
                    f"Security: Cache directory is owned by a different user. "
                    f"This may indicate a symlink attack. Please remove: {self.cache_dir}"
                )

            return

        try:
            self.cache_dir.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        except OSError:
            pass

        # SECURITY FIX: Use umask to ensure atomic creation with correct permissions
        # This prevents TOCTOU race condition where directory briefly exists with wrong permissions
        original_umask = os.umask(0o077)
        try:
            self.cache_dir.mkdir(mode=0o700, exist_ok=False)
        except FileExistsError:
            stat_info = self.cache_dir.stat()
            mode = stat_info.st_mode & 0o777
            if mode != 0o700:
                raise RuntimeError(
                    f"Security: Cache directory created by another process has insecure permissions: {oct(mode)}. "
                    f"Expected 0o700. This is a security risk."
                )
        finally:
            os.umask(original_umask)

    def get_cache_key(self, project_path: str, filepaths: List[str],
                     context_files: Optional[Dict[str, str]] = None, details: str = "",
                     chunk_strategy: str = "size", chunk_size: int = 2000,
                     files_metadata: Optional[Dict[str, Tuple[int, float]]] = None) -> str:
        """
        Generate cache key based on file metadata instead of content.

        PERFORMANCE FIX (Phase 2): Delegates to CacheMetadata which uses metadata
        (size + mtime) for O(n) key generation instead of O(content).

        For a 100MB project:
        - Old: ~2-5 seconds (hashes 100MB of data)
        - New: ~0.01 seconds (hashes ~100 metadata entries)

        CRITICAL: Accepts file paths instead of contents to enable cache check
        BEFORE loading files. Loading files before checking cache wastes 0.5-2s
        on cache hits.
        """
        return self.metadata.get_cache_key(
            project_path, filepaths, context_files, details,
            chunk_strategy, chunk_size, files_metadata
        )

    def get_file_metadata_key(self, filepath: str) -> str:
        """Generate cache key for file metadata."""
        return self.metadata.get_file_metadata_key(filepath)

    def save_review(self, cache_key: str, review_results: List[Dict[str, Any]],
                   consensus: Dict[str, Any]) -> bool:
        """
        Save review results to cache with HMAC signature.

        FIX-009: Triggers cache eviction if size limit exceeded after saving.
        """
        try:
            cache_data = {
                'timestamp': time.time(),
                'review_results': review_results,
                'consensus': consensus,
                'ttl_hours': self.ttl_hours
            }

            json_data = json.dumps(cache_data, indent=2)
            signature = self.integrity.sign_data(json_data)
            content = f"{CacheStorage.SIGNATURE_PREFIX}{signature}\n{json_data}"
            result = self.storage.write_cache_file(cache_key, content)

            # FIX-009: Check if cache exceeds size limit and evict if needed
            if result:
                self.maybe_evict()

            return result
        except Exception as e:
            print(f"Warning: Could not save to cache: {e}")
            return False

    def load_review(self, cache_key: str) -> Optional[Dict[str, Any]]:
        """
        Load review results from cache if not expired and signature is valid.

        FIX-013: Uses print() for cache warnings (expected behavior).
        Cache warnings are informational; actual cache misses return None.
        This follows the error handling decision matrix:
        - Cache miss = return None (expected, not an error)
        - Invalid cache = print warning (non-critical issue)
        """
        content = self.storage.read_cache_file(cache_key)
        if not content:
            return None

        lines = content.split('\n', 1)
        if len(lines) < 2:
            print(f"Warning: Cache file {cache_key} is empty or invalid")
            self.storage.delete_cache_file(cache_key)
            return None

        first_line, json_data = lines[0], lines[1]

        # Check for signature
        if first_line.startswith(CacheStorage.SIGNATURE_PREFIX):
            signature = first_line[len(CacheStorage.SIGNATURE_PREFIX):].strip()
            if not self.integrity.verify_signature(json_data, signature):
                print(f"Warning: Cache file {cache_key} has invalid signature (possible tampering)")
                self.storage.delete_cache_file(cache_key)
                return None
        else:
            # Legacy cache file without signature - clear it on first run
            print(f"Warning: Cache file {cache_key} has no signature (legacy format), clearing")
            self.storage.delete_cache_file(cache_key)
            return None

        try:
            cache_data = json.loads(json_data)
        except json.JSONDecodeError:
            print(f"Warning: Cache file {cache_key} has invalid JSON")
            self.storage.delete_cache_file(cache_key)
            return None

        if self.metadata.is_expired(cache_data):
            self.storage.delete_cache_file(cache_key)
            return None

        return cache_data

    def save_file_metadata(self, filepath: str, metadata: Dict[str, Any]) -> bool:
        """Save file metadata to cache with HMAC signature."""
        try:
            cache_key = self.metadata.get_file_metadata_key(filepath)
            cache_data = {
                'timestamp': time.time(),
                'filepath': filepath,
                'metadata': metadata,
                'ttl_hours': self.ttl_hours
            }

            json_data = json.dumps(cache_data, indent=2)
            signature = self.integrity.sign_data(json_data)
            content = f"{CacheStorage.SIGNATURE_PREFIX}{signature}\n{json_data}"
            return self.storage.write_cache_file(cache_key, content)
        except Exception as e:
            print(f"Warning: Could not save file metadata to cache: {e}")
            return False

    def load_file_metadata(self, filepath: str) -> Optional[Dict[str, Any]]:
        """
        Load file metadata from cache if not expired and signature is valid.

        FIX-013: Uses print() for cache warnings (expected behavior).
        Cache warnings are informational; actual cache misses return None.
        This follows the error handling decision matrix:
        - Cache miss = return None (expected, not an error)
        - Invalid cache = print warning (non-critical issue)
        """
        cache_key = self.metadata.get_file_metadata_key(filepath)

        content = self.storage.read_cache_file(cache_key)
        if not content:
            return None

        lines = content.split('\n', 1)
        if len(lines) < 2:
            self.storage.delete_cache_file(cache_key)
            return None

        first_line, json_data = lines[0], lines[1]

        if first_line.startswith(CacheStorage.SIGNATURE_PREFIX):
            signature = first_line[len(CacheStorage.SIGNATURE_PREFIX):].strip()
            if not self.integrity.verify_signature(json_data, signature):
                print(f"Warning: Cache file {cache_key} has invalid signature")
                self.storage.delete_cache_file(cache_key)
                return None
        else:
            # Legacy cache without signature
            self.storage.delete_cache_file(cache_key)
            return None

        try:
            cache_data = json.loads(json_data)
        except json.JSONDecodeError:
            self.storage.delete_cache_file(cache_key)
            return None

        if self.metadata.is_expired(cache_data):
            self.storage.delete_cache_file(cache_key)
            return None

        return cache_data.get('metadata')

    def save_directory_structure(self, path: str, structure: Dict[str, Any]) -> bool:
        """Save directory structure to cache with HMAC signature."""
        try:
            cache_key = self.metadata.get_directory_key(path)
            cache_data = {
                'timestamp': time.time(),
                'path': path,
                'structure': structure,
                'ttl_hours': self.ttl_hours
            }

            json_data = json.dumps(cache_data, indent=2)
            signature = self.integrity.sign_data(json_data)
            content = f"{CacheStorage.SIGNATURE_PREFIX}{signature}\n{json_data}"
            return self.storage.write_cache_file(cache_key, content)
        except Exception as e:
            print(f"Warning: Could not save directory structure to cache: {e}")
            return False

    def load_directory_structure(self, path: str) -> Optional[Dict[str, Any]]:
        """
        Load directory structure from cache if not expired and signature is valid.

        FIX-013: Uses print() for cache warnings (expected behavior).
        Cache warnings are informational; actual cache misses return None.
        This follows the error handling decision matrix:
        - Cache miss = return None (expected, not an error)
        - Invalid cache = print warning (non-critical issue)
        """
        cache_key = self.metadata.get_directory_key(path)

        content = self.storage.read_cache_file(cache_key)
        if not content:
            return None

        lines = content.split('\n', 1)
        if len(lines) < 2:
            self.storage.delete_cache_file(cache_key)
            return None

        first_line, json_data = lines[0], lines[1]

        if first_line.startswith(CacheStorage.SIGNATURE_PREFIX):
            signature = first_line[len(CacheStorage.SIGNATURE_PREFIX):].strip()
            if not self.integrity.verify_signature(json_data, signature):
                print(f"Warning: Cache file {cache_key} has invalid signature")
                self.storage.delete_cache_file(cache_key)
                return None
        else:
            # Legacy cache without signature
            self.storage.delete_cache_file(cache_key)
            return None

        try:
            cache_data = json.loads(json_data)
        except json.JSONDecodeError:
            self.storage.delete_cache_file(cache_key)
            return None

        if self.metadata.is_expired(cache_data):
            self.storage.delete_cache_file(cache_key)
            return None

        return cache_data.get('structure')

    def clear_expired(self) -> int:
        """
        Clear expired cache entries and return count cleared.

        Performance optimization: Uses file mtime as a hint to avoid reading
        every cache file.
        """
        cleared = 0
        current_time = time.time()
        ttl_seconds = self.ttl_hours * 3600
        grace_period = 60  # 60 second grace period for edge cases

        for cache_file in self.storage.list_cache_files():
            try:
                file_mtime = cache_file.stat().st_mtime
                file_age_seconds = current_time - file_mtime

                # Fast path: files clearly older than TTL + grace period can be deleted immediately
                if file_age_seconds > ttl_seconds + grace_period:
                    cache_file.unlink()
                    cleared += 1
                # Gray zone: older than TTL but within grace period, verify by reading
                elif file_age_seconds > ttl_seconds:
                    content = self.storage.read_cache_file(cache_file.stem)

                    if not content:
                        continue

                    lines = content.split('\n', 1)
                    if len(lines) < 2:
                        cache_file.unlink()
                        cleared += 1
                        continue

                    json_data = lines[1] if lines[0].startswith(CacheStorage.SIGNATURE_PREFIX) else content

                    try:
                        cache_data = json.loads(json_data)
                        cache_time = cache_data.get('timestamp', 0)
                        ttl_hours = cache_data.get('ttl_hours', self.ttl_hours)

                        if current_time - cache_time > ttl_hours * 3600:
                            cache_file.unlink()
                            cleared += 1
                    except json.JSONDecodeError:
                        cache_file.unlink()
                        cleared += 1
            except Exception as e:
                print(f"Warning: Error reading cache file {cache_file.name}: {e}, removing it")
                try:
                    cache_file.unlink(missing_ok=True)
                    cleared += 1
                except:
                    pass

        return cleared

    def clear_all(self) -> int:
        """Clear all cache entries and return count cleared."""
        cleared = 0

        for cache_file in self.storage.list_cache_files():
            try:
                cache_file.unlink()
                cleared += 1
            except Exception:
                pass

        return cleared

    # FIX-009: Cache eviction methods to prevent unbounded growth

    def maybe_evict(self) -> int:
        """
        Evict oldest entries if cache exceeds size limit.

        FIX-009: Called after saving to cache to prevent unbounded growth.
        Uses LRU-style eviction based on file modification time.

        Returns:
            Number of entries evicted
        """
        current_size = self._get_cache_size()
        max_size_bytes = self.MAX_CACHE_SIZE_MB * 1024 * 1024

        if current_size <= max_size_bytes:
            return 0

        return self._evict_oldest_entries()

    def _get_cache_size(self) -> int:
        """
        Calculate total cache size in bytes.

        FIX-009: Sums up all cache file sizes to check against limit.

        Returns:
            Total size in bytes
        """
        total = 0
        try:
            for entry in self.cache_dir.iterdir():
                if entry.is_file():
                    total += entry.stat().st_size
        except Exception:
            pass
        return total

    def _evict_oldest_entries(self) -> int:
        """
        Remove oldest entries until under size limit.

        FIX-009: Evicts to 80% of max size to avoid frequent eviction.
        Uses modification time as proxy for LRU ordering.

        Returns:
            Number of entries evicted
        """
        entries = []
        try:
            for entry in self.cache_dir.iterdir():
                if entry.is_file():
                    entries.append((entry, entry.stat().st_mtime))
        except Exception:
            return 0

        # Sort by modification time (oldest first)
        entries.sort(key=lambda x: x[1])

        current_size = self._get_cache_size()
        target_size = self.MAX_CACHE_SIZE_MB * 1024 * 1024 * 0.8  # Evict to 80%

        evicted = 0
        for entry_path, _ in entries:
            if current_size <= target_size:
                break
            try:
                size = entry_path.stat().st_size
                entry_path.unlink()
                current_size -= size
                evicted += 1
            except Exception:
                pass

        return evicted

    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        cache_files = list(self.storage.list_cache_files())

        stats = {
            'total_entries': len(cache_files),
            'cache_dir': str(self.cache_dir),
            'ttl_hours': self.ttl_hours
        }

        type_counts = {}
        total_size = 0

        for cache_file in cache_files:
            try:
                filename = cache_file.stem
                if filename.startswith('dir_'):
                    cache_type = 'directory_structure'
                elif filename.startswith('metadata_'):
                    cache_type = 'file_metadata'
                else:
                    cache_type = 'review_results'

                type_counts[cache_type] = type_counts.get(cache_type, 0) + 1
                total_size += cache_file.stat().st_size
            except:
                pass

        stats['type_counts'] = type_counts
        stats['total_size_bytes'] = total_size
        stats['total_size_mb'] = total_size / (1024 * 1024)

        return stats


class IncrementalReviewCache(ReviewCache):
    """Extended cache for incremental reviews."""

    def get_changed_files(self, project_path: str, current_files: Dict[str, str]) -> Dict[str, str]:
        """Identify files that have changed since last review."""
        cache_key = self.get_cache_key(project_path, [])
        cache_data = self.load_review(cache_key)

        if not cache_data:
            return current_files

        previous_hashes = cache_data.get('file_hashes', {})
        changed_files = {}

        for filepath, content in current_files.items():
            import hashlib
            current_hash = hashlib.sha256(content.encode('utf-8')).hexdigest()
            previous_hash = previous_hashes.get(filepath)

            if previous_hash != current_hash:
                changed_files[filepath] = content

        return changed_files

    def save_file_hashes(self, cache_key: str, files_content: Dict[str, str]) -> bool:
        """Save file hashes for future incremental reviews."""
        try:
            import hashlib
            cache_file = self.cache_dir / f"{cache_key}.json"
            cache_data = {}

            if cache_file.exists():
                with open(cache_file, 'r', encoding='utf-8') as f:
                    cache_data = json.load(f)

            file_hashes = {}
            for filepath, content in files_content.items():
                file_hashes[filepath] = hashlib.sha256(content.encode('utf-8')).hexdigest()

            cache_data['file_hashes'] = file_hashes
            cache_data['timestamp'] = time.time()
            cache_data['ttl_hours'] = self.ttl_hours

            json_data = json.dumps(cache_data, indent=2)
            signature = self.integrity.sign_data(json_data)
            content = f"{CacheStorage.SIGNATURE_PREFIX}{signature}\n{json_data}"

            with open(cache_file, 'w', encoding='utf-8') as f:
                f.write(content)

            return True
        except Exception as e:
            print(f"Warning: Could not save file hashes to cache: {e}")
            return False
