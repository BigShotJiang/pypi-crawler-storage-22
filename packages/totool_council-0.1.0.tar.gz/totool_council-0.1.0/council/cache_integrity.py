"""
Cache integrity layer for Code Review Council.

This module handles HMAC signing and verification for cache files.
"""
import hmac
import hashlib
import secrets
import os
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


class CacheIntegrity:
    """Handles HMAC signing/verification."""

    def __init__(self, cache_dir: Path):
        """
        Initialize cache integrity module.

        Args:
            cache_dir: Path to the cache directory
        """
        self.cache_dir = Path(cache_dir)
        self._signing_key = self._derive_signing_key()

    def _derive_signing_key(self) -> bytes:
        """
        Derive or load a cryptographically secure signing key.

        Returns:
            Bytes suitable for HMAC signing (256 bits = 32 bytes)

        Raises:
            OSError: If TTC_CACHE_STRICT_MODE is enabled and key storage fails
        """
        key_file = self.cache_dir / ".signing_key"
        strict_mode = os.environ.get('TTC_CACHE_STRICT_MODE', '').lower() in ('1', 'true', 'yes')

        # Try to load existing key
        if key_file.exists():
            try:
                key_data = key_file.read_bytes()
                if len(key_data) == 32:  # 256 bits = 32 bytes
                    # Verify permissions are secure
                    current_mode = key_file.stat().st_mode & 0o777
                    if current_mode != 0o600:
                        logger.warning(
                            f"Signing key file has insecure permissions: {oct(current_mode)}. "
                            f"Resetting to 0o600."
                        )
                        key_file.chmod(0o600)
                    return key_data
                else:
                    logger.warning(f"Existing signing key has invalid length: {len(key_data)} bytes")
            except (OSError, IOError) as e:
                logger.warning(f"Failed to read existing signing key: {e}. Generating new key.")

        # Ensure parent directory exists with secure permissions
        try:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            # Restrict directory permissions to owner only
            self.cache_dir.chmod(0o700)
        except (OSError, IOError) as e:
            error_msg = (
                f"Failed to create cache directory {self.cache_dir}: {e}. "
                f"Check filesystem permissions and ownership."
            )
            if strict_mode:
                raise OSError(error_msg) from e
            logger.error(error_msg)

        # Generate new cryptographically secure key
        try:
            new_key = secrets.token_bytes(32)

            # Write atomically to avoid partial writes
            temp_file = key_file.with_suffix('.tmp')
            temp_file.write_bytes(new_key)
            temp_file.chmod(0o600)
            temp_file.replace(key_file)

            return new_key

        except PermissionError as e:
            error_msg = (
                f"Permission denied writing cache signing key to {key_file}. "
                f"Directory owner: {self._get_dir_owner()}. "
                f"Process UID: {os.getuid()}. "
                f"Check that the process has write access to {self.cache_dir}."
            )
            if strict_mode:
                raise OSError(error_msg) from e
            logger.error(error_msg + " Using ephemeral key.")
            return secrets.token_bytes(32)

        except (OSError, IOError) as e:
            error_msg = (
                f"Failed to write cache signing key to {key_file}: {e}. "
                f"Check disk space, filesystem permissions, and directory existence."
            )
            if strict_mode:
                raise OSError(error_msg) from e
            logger.error(error_msg + " Using ephemeral key.")
            return secrets.token_bytes(32)

    def _get_dir_owner(self) -> str:
        """Get the owner of the cache directory for debugging purposes."""
        try:
            import pwd
            stat_info = self.cache_dir.stat() if self.cache_dir.exists() else self.cache_dir.parent.stat()
            uid = stat_info.st_uid
            return pwd.getpwuid(uid).pw_name
        except (ImportError, KeyError, OSError):
            return f"uid:{self.cache_dir.stat().st_uid if self.cache_dir.exists() else 'unknown'}"

    def sign_data(self, data: str) -> str:
        """
        Sign data with HMAC-SHA256.

        Args:
            data: String data to sign

        Returns:
            Hexadecimal signature string
        """
        signature = hmac.new(
            self._signing_key,
            data.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        return signature

    def verify_signature(self, data: str, signature: str) -> bool:
        """
        Verify data signature using HMAC-SHA256.

        Uses constant-time comparison to prevent timing attacks.

        Args:
            data: String data to verify
            signature: Signature to check against

        Returns:
            True if signature is valid, False otherwise
        """
        expected_signature = self.sign_data(data)
        return hmac.compare_digest(expected_signature, signature)
