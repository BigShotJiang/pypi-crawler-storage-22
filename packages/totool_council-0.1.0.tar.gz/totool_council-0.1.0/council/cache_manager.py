"""
Cache management for Code Review Council.

This module handles cache operations including initialization, checking,
and saving of review results.
"""
from typing import Dict, List, Tuple, Optional

from council.cache import ReviewCache
from council.output import OutputFormatter
from council.models import ReviewResult, ConsensusResult


class CacheManager:
    """
    Manages cache operations for review results.

    Responsibilities:
    - Cache initialization and expiration
    - Cache key generation
    - Loading cached results
    - Saving review results to cache
    """

    def __init__(self, output_formatter: OutputFormatter):
        """
        Initialize the cache manager.

        Args:
            output_formatter: Output formatter for display
        """
        self.output_formatter = output_formatter
        self.cache: Optional[ReviewCache] = None

    def initialize_cache(self, cache_dir: str, no_cache: bool) -> Optional[ReviewCache]:
        """
        Initialize cache if enabled.

        Args:
            cache_dir: Cache directory path
            no_cache: If True, disable caching

        Returns:
            ReviewCache instance or None
        """
        if no_cache:
            return None

        cache = ReviewCache(cache_dir)
        cleared = cache.clear_expired()
        if cleared > 0:
            self.output_formatter.print_warning(f"Cleared {cleared} expired cache entries")

        self.cache = cache
        return cache

    def get_cache_key(
        self,
        project_path: str,
        filepaths: List[str],
        context_files: Dict[str, str],
        details: str,
        chunk_strategy: str,
        chunk_size: int,
        files_metadata: Dict[str, Tuple[int, int]]
    ) -> Optional[str]:
        """
        Generate a cache key for the current review configuration.

        Args:
            project_path: Path to the project being reviewed
            filepaths: List of file paths being reviewed
            context_files: Context files for the review
            details: Additional review details
            chunk_strategy: Chunking strategy used
            chunk_size: Chunk size used
            files_metadata: File metadata for integrity

        Returns:
            Cache key string or None if cache is not available
        """
        if not self.cache:
            return None

        return self.cache.get_cache_key(
            project_path,
            filepaths,
            context_files,
            details,
            chunk_strategy,
            chunk_size,
            files_metadata
        )

    def check_cache(
        self,
        project_path: str,
        filepaths: List[str],
        context_files: Dict[str, str],
        details: str,
        chunk_strategy: str,
        chunk_size: int,
        files_metadata: Dict[str, Tuple[int, int]]
    ) -> Optional[Tuple[List[ReviewResult], ConsensusResult]]:
        """
        Check cache for previous review results.

        Args:
            project_path: Path to the project being reviewed
            filepaths: List of file paths being reviewed
            context_files: Context files for the review
            details: Additional review details
            chunk_strategy: Chunking strategy used
            chunk_size: Chunk size used
            files_metadata: File metadata for integrity

        Returns:
            Tuple of (reviews, consensus) if cache hit, None otherwise
        """
        if not self.cache:
            return None

        cache_key = self.get_cache_key(
            project_path,
            filepaths,
            context_files,
            details,
            chunk_strategy,
            chunk_size,
            files_metadata
        )

        if not cache_key:
            return None

        cached_review = self.cache.load_review(cache_key)
        if not cached_review:
            return None

        self.output_formatter.print_warning("Using cached review results")

        # Convert cached results to ReviewResult objects
        reviews = []
        for cached_result in cached_review['review_results']:
            reviews.append(ReviewResult(**cached_result))

        consensus_data = cached_review['consensus']
        consensus = ConsensusResult(**consensus_data)

        return reviews, consensus

    def save_to_cache(
        self,
        cache_key: str,
        reviews: List[ReviewResult],
        consensus: ConsensusResult
    ) -> None:
        """
        Save review results to cache.

        Args:
            cache_key: Cache key for storing results
            reviews: Review results to cache
            consensus: Consensus result to cache
        """
        if not self.cache or not cache_key:
            return

        # Convert reviews to dict for caching
        review_dicts = []
        for review in reviews:
            review_dicts.append({
                'critic_name': review.critic_name,
                'critic_role': review.critic_role,
                'verdict': review.verdict,
                'confidence': review.confidence,
                'review_text': review.review_text,
                'icon': review.icon,
                'color': review.color
            })

        consensus_dict = {
            'decision': consensus.decision,
            'votes': consensus.votes,
            'unanimous': consensus.unanimous,
            'majority': consensus.majority
        }

        self.cache.save_review(cache_key, review_dicts, consensus_dict)

    def is_enabled(self) -> bool:
        """Check if caching is enabled."""
        return self.cache is not None
