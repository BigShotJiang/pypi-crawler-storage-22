"""
Cache metadata layer for Code Review Council.

This module handles cache key generation, expiration, and statistics.

PERFORMANCE FIX (Phase 2): Uses metadata (size + mtime) instead of
content hashing for O(n) key generation instead of O(content).

CODE QUALITY: Extracted from cache.py to follow Single Responsibility Principle.
"""
import hashlib
import os
import time
from typing import Dict, List, Tuple, Optional
from pathlib import Path


class CacheMetadata:
    """
    Handles cache key generation, expiration, statistics.

    PERFORMANCE FIX (Phase 2): Uses file metadata (size + mtime) for cache key
    generation instead of content hashing. This reduces cache key computation from
    O(total_file_size) to O(n) where n = number of files.

    For a 100MB project:
    - Old: ~2-5 seconds (hashes 100MB of data)
    - New: ~0.01 seconds (hashes ~100 metadata entries)
    """

    def __init__(self, cache_dir: Path, ttl_hours: int = 24):
        """
        Initialize cache metadata handler.

        Args:
            cache_dir: Path to the cache directory
            ttl_hours: Default time-to-live in hours
        """
        self.cache_dir = Path(cache_dir)
        self.ttl_hours = ttl_hours
        self._signing_key = None

    def set_signing_key(self, signing_key: bytes):
        """
        Set signing key for cache key salting.

        Args:
            signing_key: Bytes of the signing key from CacheIntegrity
        """
        self._signing_key = signing_key

    def get_cache_key(
        self,
        project_path: str,
        filepaths: List[str],
        context_files: Optional[Dict[str, str]] = None,
        details: str = "",
        chunk_strategy: str = "size",
        chunk_size: int = 2000,
        files_metadata: Optional[Dict[str, Tuple[int, float]]] = None
    ) -> str:
        """
        Generate cache key from file metadata (O(n), not O(content)).

        PERFORMANCE FIX: Accepts file paths and optional metadata dict to enable
        cache check BEFORE loading files. Loading files before checking cache
        wastes 0.5-2s on cache hits.

        Args:
            project_path: Path to the project
            filepaths: List of file paths (relative to project_path)
            context_files: Optional dict of context files
            details: Additional review details
            chunk_strategy: Chunking strategy used
            chunk_size: Chunk size used
            files_metadata: Optional dict of filepath -> (size, mtime) to avoid re-stating

        Returns:
            SHA256 hash as hex string
        """
        if context_files is None:
            context_files = {}
        if files_metadata is None:
            files_metadata = {}

        # Use list for efficient string concatenation
        hash_parts = [project_path]

        # Include file metadata (size + mtime) instead of content
        # Sort for consistent ordering
        for filepath in sorted(filepaths):
            if filepath in files_metadata:
                size, mtime = files_metadata[filepath]
            else:
                size, mtime = self._get_file_metadata(project_path, filepath)
            hash_parts.append(f"{filepath}:{size}:{mtime:.6f}")

        # Include context files metadata
        if context_files:
            for filepath in sorted(context_files.keys()):
                if filepath in files_metadata:
                    size, mtime = files_metadata[filepath]
                else:
                    size, mtime = self._get_file_metadata(project_path, filepath)
                hash_parts.append(f"ctx:{filepath}:{size}:{mtime:.6f}")

        # Include review details and configuration
        hash_parts.append(f"details:{details}")
        hash_parts.append(f"strategy:{chunk_strategy}")
        hash_parts.append(f"chunk_size:{chunk_size}")

        # Add signing key as salt to make cache keys unpredictable to attackers
        # who may know file metadata but not the secret signing key
        if self._signing_key:
            hash_parts.append(f"salt:{self._signing_key.hex()}")

        hash_input = ''.join(hash_parts)
        return hashlib.sha256(hash_input.encode('utf-8')).hexdigest()

    def _get_file_metadata(self, project_path: str, filepath: str) -> Tuple[int, float]:
        """
        Get file metadata (size, mtime) for cache key generation.

        Args:
            project_path: Base path to the project
            filepath: Relative path to the file

        Returns:
            Tuple of (file_size, modification_time)
        """
        full_path = os.path.join(project_path, filepath)
        try:
            stat = os.stat(full_path)
            return stat.st_size, stat.st_mtime
        except OSError:
            return 0, 0.0

    def is_expired(self, cache_data: dict) -> bool:
        """
        Check if cache entry is expired.

        Args:
            cache_data: Cache data dictionary containing 'timestamp' and optionally 'ttl_hours'

        Returns:
            True if expired, False otherwise
        """
        cache_time = cache_data.get('timestamp', 0)
        ttl_hours = cache_data.get('ttl_hours', self.ttl_hours)
        return time.time() - cache_time > ttl_hours * 3600

    def get_file_metadata_key(self, filepath: str) -> str:
        """
        Generate cache key for file metadata.

        Args:
            filepath: Path to the file

        Returns:
            Cache key for file metadata
        """
        return f"metadata_{hashlib.sha256(filepath.encode('utf-8')).hexdigest()}"

    def get_directory_key(self, path: str) -> str:
        """
        Generate cache key for directory structure.

        Args:
            path: Path to the directory

        Returns:
            Cache key for directory structure
        """
        return f"dir_{hashlib.sha256(path.encode('utf-8')).hexdigest()}"
