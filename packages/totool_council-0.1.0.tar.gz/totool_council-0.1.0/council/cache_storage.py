"""
Cache storage layer for Code Review Council.

This module handles raw disk I/O for cache files without any security logic.
Security is handled by CacheIntegrity and metadata is handled by CacheMetadata.

CODE QUALITY: Extracted from cache.py to follow Single Responsibility Principle.
"""
from pathlib import Path
from typing import Optional


class CacheStorage:
    """
    Handles disk I/O for cache (no security logic).

    CRITICAL: This class does NOT handle:
    - HMAC signing/verification (see CacheIntegrity)
    - Cache key generation (see CacheMetadata)
    - Expiration checking (see CacheMetadata)

    This class only handles:
    - Reading raw cache file contents
    - Writing raw cache file contents
    - Deleting cache files
    - Listing cache files
    """

    SIGNATURE_PREFIX = "# CACHE_SIGNATURE: "

    def __init__(self, cache_dir: Path):
        """
        Initialize cache storage.

        Args:
            cache_dir: Path to the cache directory
        """
        self.cache_dir = Path(cache_dir)

    def read_cache_file(self, cache_key: str) -> Optional[str]:
        """
        Read raw cache file content.

        Args:
            cache_key: Cache key (filename without extension)

        Returns:
            Raw file content as string, or None if file doesn't exist
        """
        cache_file = self.cache_dir / f"{cache_key}.json"
        if not cache_file.exists():
            return None
        try:
            with open(cache_file, 'r', encoding='utf-8') as f:
                return f.read()
        except (OSError, IOError):
            return None

    def write_cache_file(self, cache_key: str, content: str) -> bool:
        """
        Write content to cache file.

        Args:
            cache_key: Cache key (filename without extension)
            content: Raw content to write

        Returns:
            True if successful, False otherwise
        """
        cache_file = self.cache_dir / f"{cache_key}.json"
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        except (OSError, IOError):
            return False

    def delete_cache_file(self, cache_key: str) -> bool:
        """
        Delete cache file.

        Args:
            cache_key: Cache key (filename without extension)

        Returns:
            True if successful, False otherwise
        """
        cache_file = self.cache_dir / f"{cache_key}.json"
        try:
            cache_file.unlink(missing_ok=True)
            return True
        except (OSError, IOError):
            return False

    def list_cache_files(self):
        """
        List all cache files.

        Returns:
            Iterator of Path objects for cache files
        """
        return self.cache_dir.glob("*.json")
