"""
Chunk review orchestration using pluggable strategies.

This module provides the ChunkReviewOrchestrator which selects the appropriate
review strategy based on command-line arguments.

CODE QUALITY: Simplifies session.py by extracting strategy selection logic.
"""
from typing import List, Dict, Any

from council.models import ReviewResult


class ChunkReviewOrchestrator:
    """
    Orchestrates chunked reviews using pluggable strategies.

    This class reduces nesting in session.py by encapsulating the logic for
    selecting and executing the appropriate review strategy (standard, parallel,
    or hierarchical) based on runtime arguments.
    """

    def __init__(self, review_runner, output_formatter):
        """
        Initialize the orchestrator.

        Args:
            review_runner: The base review runner
            output_formatter: Output formatter for display
        """
        self.review_runner = review_runner
        self.output_formatter = output_formatter
        self._strategies = {}

    def get_strategy(self, args, chunks: List[Dict[str, str]]) -> Any:
        """
        Select strategy based on arguments and chunk count.

        Strategy selection logic:
        - If --hierarchical flag is set: use HierarchicalStrategy
        - If --parallel N > 1: use ParallelStrategy
        - If multiple chunks: use MapReduceStrategy (produces single cohesive review)
        - Otherwise (single chunk): use StandardStrategy

        Args:
            args: Command-line arguments (must have hierarchical, parallel attributes)
            chunks: List of file chunks to review

        Returns:
            A ChunkReviewStrategy instance

        Note: The strategy is cached after creation for efficiency.
        """
        # Explicit flags take priority
        if hasattr(args, 'hierarchical') and args.hierarchical:
            key = 'hierarchical'
        elif hasattr(args, 'parallel') and args.parallel > 1:
            key = 'parallel'
        # Auto: use map-reduce for multi-chunk reviews (cleaner output)
        elif len(chunks) > 1:
            key = 'map_reduce'
        else:
            key = 'standard'

        # Create strategy if not already cached
        if key not in self._strategies:
            if key == 'map_reduce':
                from council.review_strategies import MapReduceStrategy
                self._strategies[key] = MapReduceStrategy(
                    self.review_runner, self.output_formatter
                )
            elif key == 'hierarchical':
                from council.review_strategies import HierarchicalStrategy
                self._strategies[key] = HierarchicalStrategy(
                    self.review_runner, self.output_formatter
                )
            elif key == 'parallel':
                from council.review_strategies import ParallelStrategy
                self._strategies[key] = ParallelStrategy(
                    self.review_runner, self.output_formatter, args.parallel
                )
            else:  # standard
                from council.review_strategies import StandardStrategy
                self._strategies[key] = StandardStrategy(self.review_runner)

        return self._strategies[key]

    def clear_cache(self):
        """Clear cached strategies (useful for testing)."""
        self._strategies = {}
