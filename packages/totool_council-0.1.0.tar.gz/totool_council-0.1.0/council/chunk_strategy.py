"""
Chunking strategies for splitting large projects into manageable pieces.

This module provides different strategies for chunking file collections
for review based on size, directory structure, or file type.
"""
import os
import math
from collections import defaultdict
from typing import Dict, List, Tuple, Optional

from council.models import CONSTANTS
from council.output import OutputFormatter


class ChunkStrategy:
    """
    Handles chunking of file collections for review.

    Supports multiple strategies:
    - size: Split based on approximate token count
    - directory: Group files by directory structure
    - type: Group files by file extension
    """

    # Safety margin for context window (use 80% to leave room for prompts)
    SAFETY_MARGIN = 0.8

    def __init__(self, output_formatter: OutputFormatter = None):
        """
        Initialize the chunk strategy.

        Args:
            output_formatter: Output formatter for warnings
        """
        self.output_formatter = output_formatter

    def calculate_optimal_chunk_size(self, files_content: Dict[str, str], user_chunk_size: Optional[int] = None) -> int:
        """
        Calculate optimal chunk size based on estimated tokens and context window.

        Args:
            files_content: Dict mapping filepath to file content
            user_chunk_size: User-provided chunk size (if any)

        Returns:
            Optimal chunk size in tokens
        """
        # If user explicitly provided a chunk size, use it
        if user_chunk_size:
            return user_chunk_size

        total_size = sum(len(content) for content in files_content.values())
        estimated_tokens = total_size // 4

        # If within context window (with safety margin), no chunking needed
        effective_context = int(CONSTANTS.MAX_CONTEXT_TOKENS * self.SAFETY_MARGIN)
        if estimated_tokens <= effective_context:
            return CONSTANTS.MAX_CONTEXT_TOKENS  # No chunking needed

        # Calculate optimal chunk size: aim for 2-3 chunks max
        # This minimizes API calls while staying within context limits
        min_chunks = 2
        max_chunks = 3

        # Calculate chunks needed based on effective context window
        chunks_needed = math.ceil(estimated_tokens / effective_context)

        # Clamp to reasonable range (2-3 chunks)
        chunks_needed = max(min_chunks, min(max_chunks, chunks_needed))

        # Calculate optimal chunk size
        optimal_chunk_size = math.ceil(estimated_tokens / chunks_needed)

        return optimal_chunk_size

    def should_chunk(self, files_content: Dict[str, str]) -> bool:
        """
        Determine if files should be chunked based on limits.

        Args:
            files_content: Dict mapping filepath to file content

        Returns:
            True if chunking is recommended, False otherwise
        """
        if not files_content:
            return False

        max_file_count = CONSTANTS.get_max_file_count()
        if len(files_content) > max_file_count:
            if self.output_formatter:
                self.output_formatter.print_warning(
                    f"File count ({len(files_content)}) exceeds maximum ({max_file_count}), enabling chunking"
                )
            return True

        total_size = sum(len(content) for content in files_content.values())
        if total_size > CONSTANTS.MAX_TOTAL_SIZE_MB * 1024 * 1024:
            if self.output_formatter:
                self.output_formatter.print_warning(
                    f"Total size ({total_size/(1024*1024):.1f}MB) exceeds maximum ({CONSTANTS.MAX_TOTAL_SIZE_MB}MB), enabling chunking"
                )
            return True

        estimated_tokens = total_size // 4
        if estimated_tokens > CONSTANTS.MAX_CONTEXT_TOKENS:
            if self.output_formatter:
                self.output_formatter.print_warning(
                    f"Estimated tokens ({estimated_tokens}) exceed context window ({CONSTANTS.MAX_CONTEXT_TOKENS}), enabling chunking"
                )
            return True

        return False

    def chunk_files(
        self,
        files_content: Dict[str, str],
        strategy: str = "size",
        user_chunk_size: Optional[int] = None
    ) -> List[Dict[str, str]]:
        """
        Chunk files using specified strategy.

        Args:
            files_content: Dict mapping filepath to file content
            strategy: Chunking strategy ("size", "directory", or "type")
            user_chunk_size: User-provided chunk size (None = auto-calculate optimal)

        Returns:
            List of chunks, each chunk is a dict mapping filepath to content
        """
        # Calculate optimal chunk size if not provided by user
        max_tokens = self.calculate_optimal_chunk_size(files_content, user_chunk_size)

        if strategy == "directory":
            return self.chunk_by_directory(files_content, max_tokens)
        elif strategy == "type":
            return self.chunk_by_type(files_content, max_tokens)
        else:
            return self.chunk_by_size(files_content, max_tokens)

    def chunk_by_size(
        self,
        files_content: Dict[str, str],
        max_tokens: int = 2000
    ) -> List[Dict[str, str]]:
        """
        Split files into chunks based on approximate token count.

        Args:
            files_content: Dict mapping filepath to file content
            max_tokens: Maximum tokens per chunk

        Returns:
            List of chunks
        """
        if not files_content:
            return []

        chunks = []
        current_chunk = {}
        current_tokens = 0

        for filepath, content in files_content.items():
            content_tokens = len(content) // 4

            if content_tokens > max_tokens:
                if current_chunk:
                    chunks.append(current_chunk)
                    current_chunk = {}
                    current_tokens = 0
                chunks.append({filepath: content})
                continue

            if current_tokens + content_tokens <= max_tokens:
                current_chunk[filepath] = content
                current_tokens += content_tokens
            else:
                if current_chunk:
                    chunks.append(current_chunk)
                current_chunk = {filepath: content}
                current_tokens = content_tokens

        if current_chunk:
            chunks.append(current_chunk)

        return chunks

    def chunk_by_directory(
        self,
        files_content: Dict[str, str],
        max_tokens: int = 2000
    ) -> List[Dict[str, str]]:
        """
        Group files by directory structure.

        Args:
            files_content: Dict mapping filepath to file content
            max_tokens: Maximum tokens per chunk

        Returns:
            List of chunks
        """
        if not files_content:
            return []

        # PERFORMANCE FIX: Use defaultdict to avoid repeated key checks
        dir_groups: Dict[str, Dict[str, str]] = defaultdict(dict)
        for filepath, content in files_content.items():
            dir_path = os.path.dirname(filepath) or "."
            dir_groups[dir_path][filepath] = content

        chunks = []
        for dir_path, dir_files in dir_groups.items():
            dir_tokens = sum(len(content) // 4 for content in dir_files.values())

            if dir_tokens <= max_tokens:
                chunks.append(dir_files)
            else:
                size_chunks = self.chunk_by_size(dir_files, max_tokens)
                chunks.extend(size_chunks)

        return chunks

    def chunk_by_type(
        self,
        files_content: Dict[str, str],
        max_tokens: int = 2000
    ) -> List[Dict[str, str]]:
        """
        Group files by file type/extension.

        Args:
            files_content: Dict mapping filepath to file content
            max_tokens: Maximum tokens per chunk

        Returns:
            List of chunks
        """
        if not files_content:
            return []

        # PERFORMANCE FIX: Use defaultdict to avoid repeated key checks
        type_groups: Dict[str, Dict[str, str]] = defaultdict(dict)
        for filepath, content in files_content.items():
            ext = os.path.splitext(filepath)[1].lower() or "no_extension"
            type_groups[ext][filepath] = content

        chunks = []
        for ext, type_files in type_groups.items():
            type_tokens = sum(len(content) // 4 for content in type_files.values())

            if type_tokens <= max_tokens:
                chunks.append(type_files)
            else:
                size_chunks = self.chunk_by_size(type_files, max_tokens)
                chunks.extend(size_chunks)

        return chunks
