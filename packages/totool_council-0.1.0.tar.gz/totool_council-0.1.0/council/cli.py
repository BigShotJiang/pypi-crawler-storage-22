"""
Command line interface for Code Review Council.
"""
import argparse
import os
from pathlib import Path
from typing import List, Dict, Any
from .models import CouncilConfig
from .exceptions import ConfigError
from .output import Colors, NoColors
from .security import SecurityValidator
from .cli_config import (
    ARGUMENT_DEFINITIONS,
    CLI_DESCRIPTION,
    CLI_EPILOG,
    SUBPARSER_HELP,
    INIT_COMMAND_HELP,
    REVIEW_COMMAND_HELP
)


class ArgumentParser:
    """Handles command line argument parsing."""

    @staticmethod
    def parse_arguments() -> tuple[argparse.ArgumentParser, argparse.Namespace]:
        """Parse command line arguments. Returns (parser, args)."""
        parser = argparse.ArgumentParser(
            description=CLI_DESCRIPTION,
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog=CLI_EPILOG
        )

        subparsers = parser.add_subparsers(dest='command', help=SUBPARSER_HELP, required=False)

        # Init command
        init_parser = subparsers.add_parser('init', help=INIT_COMMAND_HELP)

        # Review command (default)
        review_parser = subparsers.add_parser('review', help=REVIEW_COMMAND_HELP)
        for name, config in ARGUMENT_DEFINITIONS.items():
            if config.get('positional'):
                review_parser.add_argument(
                    config['flags'][0],
                    help=config['help']
                )
            else:
                add_kwargs = {'help': config['help']}
                flags = config['flags']
                for key in ['nargs', 'default', 'type', 'choices', 'action', 'metavar']:
                    if key in config:
                        add_kwargs[key] = config[key]
                review_parser.add_argument(*flags, **add_kwargs)

        # First pass: check if we need to inject 'review' subcommand
        import sys
        needs_review_injection = False
        if len(sys.argv) > 1:
            first_arg = sys.argv[1]
            # If first arg is not a known subcommand and not a flag, it's likely a path
            if first_arg not in ('init', 'review', '-h', '--help') and not first_arg.startswith('-'):
                needs_review_injection = True

        if needs_review_injection:
            sys.argv.insert(1, 'review')

        args = parser.parse_args()

        # If still no command, show help
        if args.command is None:
            parser.print_help()
            sys.exit(0)

        return parser, args


def cmd_init() -> int:
    """Initialize TTC project. Creates .ttc/ directory and updates .gitignore."""
    from pathlib import Path

    ttc_dir = Path(".ttc")
    ttc_home = Path.home() / ".ttc"
    gitignore_path = Path(".gitignore")

    # Create project .ttc directory
    if ttc_dir.exists():
        print(f"Directory '{ttc_dir}' already exists.")
    else:
        ttc_dir.mkdir()
        print(f"Created directory: {ttc_dir}/")

    # Create home .ttc directory (for global cache)
    if ttc_home.exists():
        print(f"Directory '{ttc_home}' already exists.")
    else:
        ttc_home.mkdir()
        print(f"Created directory: {ttc_home}/")

    # Create project subdirectories
    for subdir in ["critics", "review_results"]:
        subpath = ttc_dir / subdir
        if not subpath.exists():
            subpath.mkdir()
            print(f"Created directory: {subpath}/")

    # Create home subdirectories (for global cache) with secure permissions
    cache_dir = ttc_home / ".councilcache"
    if not cache_dir.exists():
        cache_dir.mkdir(mode=0o700)
        print(f"Created directory: {cache_dir}/")

    # Create default config.json in .ttc/ by copying from config.example.json
    config_path = ttc_dir / "config.json"
    example_config_path = Path(__file__).parent.parent / "config.example.json"

    if not config_path.exists():
        if example_config_path.exists():
            config_path.write_text(example_config_path.read_text())
            print(f"Created file: {config_path}")
            print(f"  -> Edit this file to add your API keys")
        else:
            print(f"Warning: {example_config_path} not found, skipping config.json creation")
    else:
        print(f"File '{config_path}' already exists.")

    # Update .gitignore
    gitignore_entry = ".ttc/"
    gitignore_updated = False

    if gitignore_path.exists():
        with open(gitignore_path, "r") as f:
            content = f.read()

        if gitignore_entry in content:
            print(f".gitignore already contains '{gitignore_entry}'")
        else:
            with open(gitignore_path, "a") as f:
                f.write(f"\n{gitignore_entry}\n")
            print(f"Added '{gitignore_entry}' to .gitignore")
            gitignore_updated = True
    else:
        with open(gitignore_path, "w") as f:
            f.write(f"{gitignore_entry}\n")
        print(f"Created .gitignore with '{gitignore_entry}'")
        gitignore_updated = True

    print("\nTTC project initialized!")
    return 0


class ConfigurationManager:
    """Manages configuration loading and validation."""

    def __init__(self):
        # No state needed - use stateless functions from config module
        pass

    def load_configuration(self, args: argparse.Namespace) -> CouncilConfig:
        """
        Load and validate configuration from arguments and environment.
        """
        from .config import (
            load_json_config,
            parse_gitignore,
            resolve_config_path,
            resolve_critics_dir,
            get_provider_config
        )

        # Resolve config path using new resolution logic
        resolved_config_path = resolve_config_path(args.config_file)

        # Load full config from JSON
        config_vars = load_json_config(resolved_config_path)

        # Get active provider config from config file
        provider_config = get_provider_config(config_vars)

        # Load ignore patterns from file using stateless function
        file_ignore_patterns = parse_gitignore(args.ignore_file)

        # Combine file patterns with command-line patterns
        all_ignore_patterns = (file_ignore_patterns or []) + (args.ignore or [])

        # Validate project path for security (path traversal protection)
        allow_system_paths = getattr(args, 'allow_system_paths', False)
        SecurityValidator.validate_project_path(args.path, allow_system_paths=allow_system_paths)

        # Get API key: config file > environment variable
        provider_name = provider_config['name']
        env_key = f"{provider_name.upper()}_API_KEY"

        api_key = (
            provider_config['api_key'] or
            os.getenv(env_key)
        )

        if not api_key:
            raise ConfigError(
                f"No API key provided. Set api_key for '{provider_name}' "
                f"in {resolved_config_path} or set {env_key} environment variable"
            )

        # Determine async mode
        use_async = True
        if args.no_async_io:
            use_async = False
        elif args.async_io is not None:
            use_async = args.async_io

        # Resolve critics directory
        resolved_critics_dir = resolve_critics_dir(args.critics_dir)

        return CouncilConfig(
            api_key=api_key,
            ignore_patterns=all_ignore_patterns,
            critics_dir=resolved_critics_dir,
            no_color=args.no_color,
            verbose=args.verbose,
            context_files={},  # Will be loaded separately
            project_path=args.path,
            details=args.details or "",
            provider=provider_config['name'],
            model=provider_config['model'],
            base_url=provider_config['base_url'],
            use_async=use_async,
            sequential=args.sequential,
            max_concurrent=args.max_concurrent,
            timeout=args.timeout
        )


class ProjectFormatter:
    """Handles project content formatting."""

    @staticmethod
    def format_project_for_review(files_content: dict[str, str], context_files: dict[str, str] | None = None) -> str:
        """Format multiple files into a single review string, including context files."""
        if not files_content:
            raise ConfigError("No files to review")

        # Use list join pattern for O(n) performance instead of O(n²) string concatenation
        lines = []

        # Add context files first if provided
        if context_files:
            lines.append('=' * 70)
            lines.append(f"ADDITIONAL CONTEXT ({len(context_files)} file(s))")
            lines.append('=' * 70)
            lines.append('')
            lines.append("The following files provide additional context about the project:")
            lines.append('')

            for filepath, content in context_files.items():
                lines.append(f"--- {filepath} ---")
                lines.append(content)
                lines.append('')

            lines.append('=' * 70)
            lines.append(f"CODE TO REVIEW ({len(files_content)} file(s))")
            lines.append('=' * 70)
            lines.append('')
        else:
            lines.append(f"Project contains {len(files_content)} file(s):")
            lines.append('')

        for filepath, content in files_content.items():
            lines.append('=' * 70)
            lines.append(f"FILE: {filepath}")
            lines.append('=' * 70)
            lines.append(content)
            lines.append('')

        return '\n'.join(lines)
    
    @staticmethod
    def add_additional_details(project_content: str, details: str) -> str:
        """Add additional review instructions to project content."""
        if not details:
            return project_content
        
        return f"""
ADDITIONAL REVIEW INSTRUCTIONS:
{details}

{'='*70}

{project_content}
"""