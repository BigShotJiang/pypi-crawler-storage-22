"""
CLI argument definitions and configuration.
"""
from typing import Dict, Any


ARGUMENT_DEFINITIONS: Dict[str, Dict[str, Any]] = {
    'path': {
        'flags': ('path',),
        'positional': True,
        'help': 'File or directory path to review',
    },
    # Context and details options
    'context': {
        'flags': ('--context', '-c'),
        'nargs': '+',
        'default': [],
        'metavar': 'FILE',
        'help': 'Context files to provide additional information',
    },
    'details': {
        'flags': ('--details', '-d'),
        'help': 'Additional details or instructions for the reviewers',
    },
    # Chunking options
    'chunk_size': {
        'flags': ('--chunk-size',),
        'type': int,
        'default': None,
        'help': 'Target tokens per chunk (default: auto-calculated based on context window)',
    },
    'no_chunking': {
        'flags': ('--no-chunking',),
        'action': 'store_true',
        'help': 'Disable automatic chunking',
    },
    'chunk_strategy': {
        'flags': ('--chunk-strategy',),
        'choices': ['size', 'directory', 'type'],
        'default': 'size',
        'help': 'Chunking strategy: size, directory, or type (default: size)',
    },
    # Performance options
    'parallel': {
        'flags': ('--parallel',),
        'type': int,
        'default': 0,
        'help': 'Number of parallel workers (0 = auto, 1 = sequential)',
    },
    'sequential': {
        'flags': ('--sequential',),
        'action': 'store_true',
        'help': 'Run critics sequentially instead of in parallel (useful for APIs with rate limits)',
    },
    'async_io': {
        'flags': ('--async-io',),
        'action': 'store_true',
        'default': None,
        'help': 'Enable async I/O operations (default: auto-detect)',
    },
    'no_async_io': {
        'flags': ('--no-async-io',),
        'action': 'store_true',
        'help': 'Disable async I/O operations',
    },
    'max_concurrent': {
        'flags': ('--max-concurrent',),
        'type': int,
        'default': 10,
        'help': 'Maximum concurrent API calls (default: 10)',
    },
    'timeout': {
        'flags': ('--timeout',),
        'type': int,
        'default': 90,
        'help': 'API timeout in seconds (default: 90)',
    },
    'cache_dir': {
        'flags': ('--cache-dir',),
        'default': '~/.ttc/.councilcache',
        'help': 'Cache directory (default: ~/.ttc/.councilcache)',
    },
    'no_cache': {
        'flags': ('--no-cache',),
        'action': 'store_true',
        'help': 'Disable caching',
    },
    # Memory and performance tuning options
    'streaming': {
        'flags': ('--streaming',),
        'action': 'store_true',
        'default': None,
        'help': 'Enable streaming mode for large projects (auto-enabled for projects >50MB)',
    },
    'no_streaming': {
        'flags': ('--no-streaming',),
        'action': 'store_true',
        'help': 'Disable streaming mode even for large projects',
    },
    'max_files': {
        'flags': ('--max-files',),
        'type': int,
        'default': None,
        'help': 'Maximum number of files to process (default: 100, override with COUNCIL_MAX_FILES env var)',
    },
    'dedup_max_size': {
        'flags': ('--dedup-max-size',),
        'type': int,
        'default': None,
        'help': 'Maximum project size in MB for deduplication (default: 500, override with COUNCIL_DEDUP_MAX_SIZE_MB env var)',
    },
    # Advanced features
    'hierarchical': {
        'flags': ('--hierarchical',),
        'action': 'store_true',
        'help': 'Use hierarchical review strategy for chunks',
    },
    'deduplicate': {
        'flags': ('--deduplicate',),
        'action': 'store_true',
        'help': 'Enable content deduplication',
    },
    'show_memory': {
        'flags': ('--show-memory',),
        'action': 'store_true',
        'help': 'Show memory usage during processing',
    },
    # Ignore patterns
    'ignore': {
        'flags': ('--ignore',),
        'nargs': '*',
        'default': [],
        'help': 'Additional patterns to ignore',
    },
    'ignore_file': {
        'flags': ('--ignore-file',),
        'default': '.gitignore',
        'help': 'Path to ignore file (default: .gitignore)',
    },
    # API configuration
    'config_file': {
        'flags': ('--config-file',),
        'default': None,
        'help': 'Path to JSON config file (default: .ttc/config.json or ~/.ttc/config.json)',
    },
    # Security options
    'allow_system_paths': {
        'flags': ('--allow-system-paths',),
        'action': 'store_true',
        'help': 'Allow access to system directories (NOT RECOMMENDED)',
    },
    'yes_i_understand': {
        'flags': ('--yes-i-understand-the-risks',),
        'action': 'store_true',
        'help': 'Skip the security warning about third-party code transmission',
    },
    # Critics configuration
    'critics_dir': {
        'flags': ('--critics-dir',),
        'default': None,
        'help': 'Directory containing critic prompt files (default: .ttc/critics/, ./critics/, or bundled)',
    },
    # Output options
    'no_color': {
        'flags': ('--no-color',),
        'action': 'store_true',
        'help': 'Disable colored output',
    },
    'verbose': {
        'flags': ('--verbose', '-v'),
        'action': 'store_true',
        'help': 'Show verbose output',
    },
}


# CLI description and help text
CLI_DESCRIPTION = 'Code Review Council - Review entire projects or single files'

CLI_EPILOG = """
Examples:
  # Initialize project
  ttc init

  # Review a single file
  ttc review mycode.py

  # Review entire project directory
  ttc review ./my-project

  # Review with context files (roadmap, todos, docs)
  ttc review . --context roadmap.md todo.md ARCHITECTURE.md

  # Review with specific details
  ttc review ./src --context README.md --details "Focus on API endpoints"

  # Use custom ignore file (preferred over --ignore flag)
  ttc review . --ignore-file .myignore

  # Use sequential mode (for APIs with rate limits)
  ttc review . --sequential --timeout 360

  # Comprehensive review with all options
  ttc review . --context roadmap.md todo.md --details "Check against roadmap goals" --verbose

Note:
  - Uses .gitignore file by default to specify patterns to ignore
  - Config is searched in: .ttc/config.json, then ~/.ttc/config.json
  - Set provider, model, and base_url in config.json
            """

SUBPARSER_HELP = 'Available commands'

INIT_COMMAND_HELP = 'Initialize TTC project (creates .ttc/ directory and updates .gitignore)'

REVIEW_COMMAND_HELP = 'Review code (default command)'
