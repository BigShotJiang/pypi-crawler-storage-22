"""
Entry point for the tcc CLI command.

This file is executed when the user runs the 'tcc' command
after installing the package via pip.
"""

import sys
import importlib.util
from pathlib import Path


def main():
    """Main entry point for setuptools console script."""
    # Load the root council.py module directly to avoid naming conflict
    project_root = Path(__file__).parent.parent
    council_py_path = project_root / "council.py"

    spec = importlib.util.spec_from_file_location("_council_cli", council_py_path)
    council_module = importlib.util.module_from_spec(spec)
    sys.modules["_council_cli"] = council_module
    spec.loader.exec_module(council_module)

    council_module.main()


if __name__ == '__main__':
    main()
