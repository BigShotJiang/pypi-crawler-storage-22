"""
Compatibility layer for Code Review Council.
Provides seamless switching between async and sync operations.
"""
import asyncio
import os
import logging
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class AsyncCompat:
    """Provides compatibility between async and sync operations."""

    @staticmethod
    def is_async_available() -> bool:
        """Check if async dependencies are available."""
        try:
            import aiohttp
            import aiofiles
            return True
        except ImportError:
            return False

    @staticmethod
    def run_async(coro):
        """Run async coroutine from sync context."""
        try:
            return asyncio.run(coro)
        except RuntimeError:
            # Already in event loop, use nested approach
            loop = asyncio.get_event_loop()
            return loop.run_until_complete(coro)

    @staticmethod
    async def run_sync_in_thread(func, *args, **kwargs):
        """Run sync function in thread pool from async context."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: func(*args, **kwargs))


class ClientFactory:
    """
    Factory for creating API clients, file collectors, and review runners.

    This factory provides seamless switching between async and sync modes
    and manages the lifecycle of async resources.
    """

    def __init__(self, use_async: bool = True, timeout: int = 90, max_concurrent: int = 10, max_requests_per_second: float = 10.0):
        self.use_async = use_async and AsyncCompat.is_async_available()
        self.timeout = timeout
        self.max_concurrent = max_concurrent
        self.max_requests_per_second = max_requests_per_second
        self._async_client = None
        self._sync_client = None
        self._async_file_collector = None
        self._sync_file_collector = None
        self._async_review_runner = None
        self._sync_review_runner = None
        self._owned_client = False  # Track if we own the client for cleanup

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit - cleanup async resources."""
        await self._cleanup_async_client()

    async def close(self):
        """Explicitly close the session and cleanup resources."""
        await self._cleanup_async_client()

    async def _cleanup_async_client(self):
        """
        Internal method for async client cleanup with multi-stage shutdown.
        """
        if not (self._async_client and self._owned_client):
            return

        graceful_timeout = float(os.environ.get('TTC_ASYNC_CLEANUP_TIMEOUT', '30'))
        cleanup_successful = await self._attempt_graceful_shutdown(graceful_timeout)

        if not cleanup_successful:
            await self._force_close_async_client()

        self._async_client = None

    async def _attempt_graceful_shutdown(self, timeout: float) -> bool:
        """
        Attempt graceful shutdown of async client.

        Args:
            timeout: Maximum time to wait for graceful shutdown

        Returns:
            True if shutdown succeeded, False otherwise
        """
        try:
            if hasattr(self._async_client, 'close'):
                await asyncio.wait_for(self._async_client.close(), timeout=timeout)
            elif hasattr(self._async_client, '__aexit__'):
                await asyncio.wait_for(self._async_client.__aexit__(None, None, None), timeout=timeout)
            logger.debug("Async client cleanup completed successfully")
            return True
        except asyncio.TimeoutError:
            logger.warning(f"Graceful async client cleanup timed out after {timeout}s. Attempting force close...")
            return False
        except Exception as e:
            logger.warning(f"Error during graceful async client cleanup: {e}. Attempting force close...")
            return False

    async def _force_close_async_client(self) -> None:
        """
        Force close the async client by closing the underlying connector.

        This is a fallback when graceful shutdown fails.
        """
        force_timeout = 5.0
        try:
            session = getattr(self._async_client, '_session', None)
            if session is not None:
                connector = getattr(session, '_connector', None)
                if connector is not None:
                    await asyncio.wait_for(connector.close(), timeout=force_timeout)
                logger.warning("Async client force-closed due to timeout/error")
        except asyncio.TimeoutError:
            logger.error(f"Force close also timed out after {force_timeout}s. Resources may leak.")
        except Exception as e:
            logger.error(f"Error during force close: {e}. Resources may leak.")

    def _resolve_rate_limit(self, max_requests_per_second: float | None) -> float:
        """Resolve the rate limit to use."""
        return max_requests_per_second if max_requests_per_second is not None else self.max_requests_per_second

    def _normalize_api_params(self, base_url: str | None, model: str | None) -> Tuple[str, str]:
        """Normalize API parameters, ensuring strings not None."""
        return (base_url or ""), (model or "")

    def _create_async_api_client(
        self,
        api_key: str,
        base_url: str,
        model: str,
        endpoint: str,
        sequential: bool,
        rate_limit: float
    ):
        """Create async API client."""
        from .async_api import AsyncAPIClientFactory
        return AsyncAPIClientFactory.create_client(
            api_key, base_url, model, endpoint,
            use_async=True, limit_connections=sequential,
            max_requests_per_second=rate_limit
        )

    def _create_sync_api_client(
        self,
        api_key: str,
        base_url: str,
        model: str,
        endpoint: str,
        rate_limit: float
    ):
        """Create sync API client."""
        from .api import APIClient
        return APIClient(api_key, base_url, model, endpoint, max_requests_per_second=rate_limit)

    def get_api_client(
        self,
        api_key: str,
        base_url: str | None,
        model: str | None,
        endpoint: str = "/v1/chat/completions",
        sequential: bool = False,
        max_requests_per_second: float | None = None
    ):
        """Get appropriate API client based on mode."""
        base_url_str, model_str = self._normalize_api_params(base_url, model)
        rate_limit = self._resolve_rate_limit(max_requests_per_second)

        if self.use_async:
            client = self._create_async_api_client(
                api_key, base_url_str, model_str, endpoint, sequential, rate_limit
            )
            self._async_client = client
            self._owned_client = True
            return client
        else:
            self._sync_client = self._create_sync_api_client(
                api_key, base_url_str, model_str, endpoint, rate_limit
            )
            return self._sync_client

    def _create_async_file_collector(self, ignore_patterns: List[str], output_formatter):
        """Create async file collector."""
        from .async_files import AsyncFileCollectorFactory
        return AsyncFileCollectorFactory.create_collector(
            ignore_patterns, output_formatter, use_async=True
        )

    def _create_sync_file_collector(self, ignore_patterns: List[str], output_formatter):
        """Create sync file collector."""
        from .files import FileCollector
        return FileCollector(ignore_patterns, output_formatter)

    def get_file_collector(self, ignore_patterns: List[str], output_formatter):
        """Get appropriate file collector based on mode."""
        if self.use_async:
            return self._create_async_file_collector(ignore_patterns, output_formatter)
        else:
            return self._create_sync_file_collector(ignore_patterns, output_formatter)

    def _create_async_review_runner(self, api_client, output_formatter, color_class, sequential: bool):
        """Create async review runner."""
        from .async_review import AsyncReviewRunnerFactory
        return AsyncReviewRunnerFactory.create_runner(
            api_client, output_formatter, color_class,
            use_async=True, timeout=self.timeout, sequential=sequential
        )

    def _create_sync_review_runner(self, api_client, output_formatter, color_class):
        """Create sync review runner."""
        from .review import ReviewRunner
        return ReviewRunner(api_client, output_formatter, color_class, timeout=self.timeout)

    def get_review_runner(self, api_client, output_formatter, color_class=None, sequential: bool = False):
        """Get appropriate review runner based on mode."""
        if self.use_async:
            return self._create_async_review_runner(api_client, output_formatter, color_class, sequential)
        else:
            return self._create_sync_review_runner(api_client, output_formatter, color_class)

    async def collect_files_async(self, file_collector, path: str) -> Tuple[Dict[str, str], Dict[str, Tuple[int, float]]]:
        """
        Collect files using appropriate method.

        Returns:
            Tuple of (files_content, files_metadata)
        """
        if self._is_async_file_collector(file_collector):
            return await file_collector.collect_project_files_async(path)
        else:
            return await AsyncCompat.run_sync_in_thread(
                file_collector.collect_project_files, path
            )

    def _is_async_file_collector(self, file_collector) -> bool:
        """Check if file collector supports async operations."""
        return hasattr(file_collector, 'collect_project_files_async')

    async def run_reviews_async(
        self,
        review_runner,
        critics: List,
        project_content: str,
        is_multi_file: bool,
        verbose: bool = False
    ):
        """Run reviews using appropriate method."""
        if self._is_async_review_runner(review_runner):
            return await review_runner.run_reviews_async(
                critics, project_content, is_multi_file, verbose
            )
        else:
            return await AsyncCompat.run_sync_in_thread(
                review_runner.run_reviews, critics, project_content, is_multi_file, verbose
            )

    def _is_async_review_runner(self, review_runner) -> bool:
        """Check if review runner supports async operations."""
        return hasattr(review_runner, 'run_reviews_async')

    async def run_chunked_reviews_async(
        self,
        review_runner,
        critics: List,
        chunks: List[Dict[str, str]],
        context_files: Dict[str, str],
        details: str,
        verbose: bool = False
    ):
        """Run chunked reviews using appropriate method."""
        if self._supports_chunked_async(review_runner):
            return await review_runner.run_chunked_reviews_async(
                critics, chunks, context_files, details, verbose
            )
        else:
            return await AsyncCompat.run_sync_in_thread(
                review_runner.run_chunked_reviews, critics, chunks, context_files, details, verbose
            )

    def _supports_chunked_async(self, review_runner) -> bool:
        """Check if review runner supports async chunked reviews."""
        return hasattr(review_runner, 'run_chunked_reviews_async')


def create_client_factory(use_async: bool = True, timeout: int = 90, max_concurrent: int = 10, max_requests_per_second: float = 10.0) -> ClientFactory:
    """Create a client factory with appropriate mode."""
    return ClientFactory(use_async=use_async, timeout=timeout, max_concurrent=max_concurrent, max_requests_per_second=max_requests_per_second)

# Backward compatibility alias
def create_session(use_async: bool = True, timeout: int = 90, max_concurrent: int = 10, max_requests_per_second: float = 10.0) -> ClientFactory:
    """Create a client factory with appropriate mode (deprecated alias, use create_client_factory)."""
    return create_client_factory(use_async=use_async, timeout=timeout, max_concurrent=max_concurrent, max_requests_per_second=max_requests_per_second)