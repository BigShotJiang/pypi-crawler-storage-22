"""
Configuration utilities for Code Review Council.

This module provides stateless loader functions for configuration data,
replacing class-based loaders where appropriate.

CODE QUALITY: Extracted from various modules to follow Single Responsibility Principle.
Stateless functions are simpler and more maintainable than class-based loaders.
"""
import os
import re
from pathlib import Path
from typing import Dict, List, Optional


CONFIG_DIR = ".ttc"
CONFIG_FILENAME = "config.json"


def resolve_config_path(config_path: Optional[str] = None) -> str:
    """
    Resolve the config file path.

    Search order (first found is used):
    1. Explicitly provided config_path
    2. <project_root>/.ttc/config.json
    3. ~/.ttc/config.json

    Args:
        config_path: Explicit config path provided by user

    Returns:
        Path to the config file to use
    """
    # If user provided explicit path, use it
    if config_path:
        return config_path

    # Check project-local .ttc/config.json
    project_config = Path.cwd() / CONFIG_DIR / CONFIG_FILENAME
    if project_config.exists():
        return str(project_config)

    # Fall back to user home .ttc/config.json
    home_config = Path.home() / CONFIG_DIR / CONFIG_FILENAME
    return str(home_config)


def ensure_config_dir(config_path: str) -> Path:
    """
    Ensure the config directory exists, return the directory path.

    Args:
        config_path: Path to config file

    Returns:
        Path object for the config directory
    """
    config_dir = Path(config_path).parent
    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir


def resolve_critics_dir(critics_dir: Optional[str] = None) -> Path:
    """
    Resolve the critics directory path.

    Search order (first found is used):
    1. Explicitly provided critics_dir
    2. <project_root>/.ttc/critics/
    3. ./critics/
    4. Bundled package critics (fallback)

    Args:
        critics_dir: Explicit critics dir provided by user

    Returns:
        Path to the critics directory to use
    """
    # If user provided explicit path, use it
    if critics_dir:
        return Path(critics_dir)

    # Check project-local .ttc/critics/
    project_critics = Path.cwd() / CONFIG_DIR / "critics"
    if project_critics.exists() and any(project_critics.glob("*.md")):
        return project_critics

    # Check ./critics/
    local_critics = Path.cwd() / "critics"
    if local_critics.exists() and any(local_critics.glob("*.md")):
        return local_critics

    # Fall back to bundled package critics
    import council
    package_dir = Path(council.__file__).parent
    bundled_critics = package_dir / "critics"
    return bundled_critics


def load_json_config(config_path: str) -> Dict[str, Any]:
    """
    Load JSON config file into dictionary.

    Stateless function - loads full config from JSON including provider,
    model, base_url, and api_keys sections.

    Args:
        config_path: Path to the JSON config file

    Returns:
        Full configuration dictionary with all sections
    """
    import json

    if not os.path.exists(config_path):
        return {}

    with open(config_path, 'r') as f:
        return json.load(f) or {}


def get_provider_config(config_vars: Dict[str, Any]) -> Dict[str, str]:
    """
    Extract active provider config from the providers array.

    Args:
        config_vars: Full config dictionary from load_json_config()

    Returns:
        Dictionary with 'name', 'model', 'base_url', and 'api_key' keys

    Raises:
        ValueError: If active_provider is not found in providers array
    """
    active_provider_name = config_vars.get('active_provider', 'deepseek')
    providers = config_vars.get('providers', [])

    # Find the active provider by name
    active_provider = None
    for provider in providers:
        if provider.get('name') == active_provider_name:
            active_provider = provider
            break

    if not active_provider:
        raise ValueError(
            f"Provider '{active_provider_name}' not found in config. "
            f"Available providers: {[p.get('name') for p in providers]}"
        )

    # Validate required fields
    missing_fields = []
    if not active_provider.get('model'):
        missing_fields.append('model')
    if not active_provider.get('base_url'):
        missing_fields.append('base_url')

    if missing_fields:
        raise ValueError(
            f"Provider '{active_provider_name}' is missing required fields: {', '.join(missing_fields)}"
        )

    return {
        'name': active_provider['name'],
        'model': active_provider['model'],
        'base_url': active_provider['base_url'],
        'api_key': active_provider.get('api_key', '')
    }


def load_yaml_config(config_path: str) -> Dict[str, Any]:
    """
    Load YAML configuration file into dictionary.

    Args:
        config_path: Path to the YAML file

    Returns:
        Dictionary containing parsed YAML data

    Raises:
        FileNotFoundError: If config file doesn't exist
        ImportError: If PyYAML is not installed
    """
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Config file not found: {config_path}")

    try:
        import yaml
        with open(config_path, 'r') as f:
            return yaml.safe_load(f) or {}
    except ImportError:
        raise ImportError(
            "PyYAML is required for YAML config files. "
            "Install with: pip install pyyaml"
        )


def parse_gitignore(gitignore_path: str) -> List[str]:
    """
    Parse .gitignore file and return list of patterns.

    Args:
        gitignore_path: Path to the .gitignore file

    Returns:
        List of gitignore patterns (supports # comments and ! negations)
    """
    patterns = []
    if not os.path.exists(gitignore_path):
        return patterns

    with open(gitignore_path, 'r') as f:
        for line in f:
            line = line.strip()
            # Skip empty lines and comments
            if not line or line.startswith('#'):
                continue
            patterns.append(line)

    return patterns


def validate_api_key(api_key: str) -> bool:
    """
    Validate API key format (basic validation only).

    Args:
        api_key: The API key to validate

    Returns:
        True if API key appears valid, False otherwise
    """
    if not api_key or not isinstance(api_key, str):
        return False

    # Basic length check (most API keys are at least 20 chars)
    if len(api_key) < 20:
        return False

    # Check for common API key patterns
    # This is not exhaustive but catches obvious invalid keys
    if api_key.startswith('sk-') or api_key.startswith('ghp_') or api_key.startswith('AKIA'):
        return True

    # Generic check: has some reasonable length and contains alphanumeric
    if len(api_key) >= 20 and any(c.isalnum() for c in api_key):
        return True

    return False


