# Critics Configuration

This directory contains the system prompts for each of the three code review council members. You can customize their personalities, focus areas, and review styles by editing these files.

## Files

- `security_specialist.md` - Paranoid security expert
- `performance_engineer.md` - Ruthless performance optimizer  
- `clean_code_advocate.md` - Merciless code quality enforcer

## How It Works

When you run `council.py`, it loads these files to configure each critic's behavior. If the files don't exist, it uses built-in default prompts.

## Customization

### Basic Usage
Just edit the `.md` files to change how each critic behaves:

```bash
# Edit the security specialist to focus on your specific threats
vim critics/security_specialist.md

# Run review (automatically uses your custom prompts)
python council.py .
```

### Custom Critics Directory
You can use a different directory:

```bash
# Create custom critics
mkdir my-custom-critics/
cp critics/*.md my-custom-critics/
# Edit your custom files...

# Use custom directory
python council.py . --critics-dir my-custom-critics/
```

### Per-Project Critics
Create project-specific critics:

```bash
# In your project root
mkdir critics/
cp /path/to/default/critics/*.md ./critics/

# Customize for your project
# e.g., add "Check against our API security standard" to security_specialist.md

# Run (uses ./critics by default)
python council.py .
```

## Customization Tips

### Make Them More Brutal
Add phrases like:
- "Be ruthlessly critical"
- "Call out EVERY issue, no matter how small"
- "Assume the worst-case scenario"
- "Don't accept any excuses"

### Make Them More Lenient
Add phrases like:
- "Consider the context and constraints"
- "Distinguish between critical issues and nice-to-haves"
- "Acknowledge when quick-and-dirty is acceptable"

### Focus on Specific Technologies
```markdown
# In performance_engineer.md, add:

## Technology-Specific Rules:
- **Python**: Watch for GIL contention, use async/await properly
- **JavaScript**: Check for memory leaks in closures and event listeners
- **SQL**: Every query must have EXPLAIN plan analysis
- **React**: Watch for unnecessary re-renders, use React.memo
```

### Add Project-Specific Standards
```markdown
# In clean_code_advocate.md, add:

## Our Company Standards:
- All functions must have type hints (Python)
- Max function length: 20 lines (we're strict!)
- All public APIs must have docstrings with examples
- Use our custom error handling patterns (see docs/errors.md)
```

### Domain-Specific Focus
```markdown
# In security_specialist.md, add:

## Healthcare Compliance (HIPAA):
- Check for PHI data encryption at rest and in transit
- Verify audit logging for all PHI access
- Ensure proper access controls and authentication
- Check data retention and deletion policies
```

## Example: Making Them SUPER Brutal

### Current (Already Brutal):
```markdown
You are a paranoid security expert. Trust nothing.
```

### ULTRA BRUTAL:
```markdown
You are a former black-hat hacker turned security auditor. You've exploited thousands 
of systems and you see vulnerabilities everywhere. You assume every developer is 
incompetent until proven otherwise. You have ZERO chill. If code can be exploited, 
you WILL find it and you WILL explain exactly how an attacker would pwn this system.

Your reviews should make developers sweat. Don't hold back.

REJECT AGGRESSIVELY. If there's even a HINT of a security issue, call it out.
```

## Example: Tech-Stack Specific

### For Node.js Projects:
```markdown
# performance_engineer.md

You are a Node.js performance specialist who has optimized countless production systems.

## Node.js Specific Focus:
- Event loop blocking (ANY synchronous operation >10ms is a problem)
- Memory leaks in streams and event emitters
- Callback hell and promise chains (should use async/await)
- N+1 queries in ORMs like Sequelize or TypeORM
- Missing connection pooling
- Improper use of clusters/workers
- Unbounded arrays and memory growth
- Missing backpressure handling in streams
```

## Example: Startup vs Enterprise

### Startup Mode (Move Fast):
```markdown
Be critical but pragmatic. Understand that startups need to ship quickly.

- REJECT only for critical security issues or obvious scalability killers
- NEEDS_WORK for code quality issues that will cause problems at scale
- APPROVE if it works and can be refactored later
- Focus on: security, major performance issues, unscalable patterns
- Less focus on: perfect code style, minor optimizations
```

### Enterprise Mode (Quality First):
```markdown
Be extremely thorough. This code will be maintained for 10+ years by dozens of developers.

- REJECT for any code quality issues that hinder maintainability
- NEEDS_WORK for anything that doesn't meet enterprise standards
- APPROVE only for exceptional code
- Focus on: maintainability, documentation, testing, patterns, standards
- Zero tolerance for: code duplication, unclear naming, missing tests
```

## Sharing Configurations

### Export Your Setup
```bash
# Package your critics
tar -czf my-critics-config.tar.gz critics/

# Share with team
scp my-critics-config.tar.gz teammate@server:~/
```

### Team Consistency
```bash
# Keep critics in version control
git add critics/*.md
git commit -m "Add team code review standards"

# Everyone on team uses same standards
git pull
python council.py .
```

## Testing Your Changes

After modifying critic prompts, test them:

```bash
# Test on a known-bad file to see if they catch issues
python council.py bad_code_example.py --verbose

# Test on a known-good file to see if they're too harsh
python council.py good_code_example.py --verbose
```

## Defaults

If you delete a critic file, `council.py` will use sensible brutal defaults. To reset to defaults:

```bash
rm critics/*.md
# On next run, uses built-in defaults
```

## Need Ideas?

Look at:
- Your team's style guide
- Your company's security policies  
- OWASP Top 10 (for security)
- Your tech stack's best practices
- Your pain points from past code reviews

Then encode them into the critic prompts!