"""
Custom exceptions for the Code Review Council.

## Error Handling Guidelines

### When to Raise Exceptions vs Return None vs Print Warnings

**RAISE exceptions for:**
- Critical failures that prevent operation completion
- Invalid input (e.g., invalid path, missing API key)
- Configuration errors
- Security violations
- Network/API failures

**RETURN None for:**
- Cache misses (expected behavior)
- Optional lookups with no result (e.g., "get value if exists")
- Files that are intentionally skipped (not errors)

**PRINT warnings for:**
- Non-critical issues that don't stop execution
- Performance-related information (e.g., "large file, may take longer")
- Deprecation notices
- Informational messages

### Exception Usage Examples

```python
# File operations - always raise on error
raise FileError(f"Path does not exist: {path}")

# API errors - always raise
raise APIError(f"API request failed: {error}")

# Security validation - always raise
raise ValueError(f"Security: Path traversal detected: {path}")

# Cache miss - return None (expected)
return None  # No cached result found

# Large file - print warning (non-critical)
self.output_formatter.print_warning(f"File is large ({size}MB)")
```
"""


class CouncilError(Exception):
    """Base exception for the Code Review Council."""
    pass


class ConfigError(CouncilError):
    """Configuration-related errors."""
    pass


class APIError(CouncilError):
    """API-related errors."""
    pass


class FileError(CouncilError):
    """File operation errors."""
    pass


class ReviewError(CouncilError):
    """Review processing errors."""
    pass


class ValidationError(CouncilError):
    """Input validation errors."""
    pass


class SecurityValidationError(CouncilError):
    """Security validation errors (path traversal, SSRF, etc.)."""
    pass