"""
File preprocessing for Code Review Council.

This module handles file collection, deduplication, and preparation
before review.
"""
from typing import Dict, List, Tuple

from council.output import OutputFormatter
from council.deduplication import ContentDeduplicator
from council.models import CONSTANTS


class FilePreprocessor:
    """
    Handles file preprocessing operations.

    Responsibilities:
    - Determining deduplication usage based on project size
    - Collecting file metadata (without content)
    - Loading file contents
    - Applying deduplication
    """

    # PERFORMANCE FIX: Increased from 100MB to 500MB for modern systems
    # The previous threshold was too conservative and disabled deduplication
    # on moderately sized projects that could easily handle it
    MAX_SAFE_MEMORY_MB = 500  # Threshold for deduplication memory safety

    @classmethod
    def get_max_memory_mb(cls) -> int:
        """Get max memory threshold from environment or default."""
        import os
        env_value = os.environ.get('COUNCIL_DEDUP_MAX_SIZE_MB')
        if env_value:
            try:
                return int(env_value)
            except ValueError:
                pass
        return cls.MAX_SAFE_MEMORY_MB

    def __init__(self, output_formatter: OutputFormatter):
        """
        Initialize the file preprocessor.

        Args:
            output_formatter: Output formatter for display
        """
        self.output_formatter = output_formatter

    def determine_deduplication_usage(
        self,
        file_collector,
        deduplicate_enabled: bool,
        project_path: str
    ) -> Tuple[bool, int, int, int]:
        """
        Determine if deduplication should be used based on project size.

        Args:
            file_collector: File collector instance
            deduplicate_enabled: Whether deduplication is enabled by user
            project_path: Path to the project

        Returns:
            Tuple of (use_deduplication, total_files, total_size_bytes, eligible_files)
        """
        total_files, total_size_bytes, eligible_files = file_collector.estimate_project_size(
            project_path
        )

        max_memory_mb = self.get_max_memory_mb()
        use_deduplication = deduplicate_enabled
        if total_size_bytes > max_memory_mb * 1024 * 1024:
            size_mb = total_size_bytes / (1024 * 1024)
            self.output_formatter.print_warning(
                f"Project size estimated at {size_mb:.1f}MB ({eligible_files} files). "
                f"Deduplication disabled for memory safety (threshold: {max_memory_mb}MB). "
                f"Chunking will be used instead. "
                f"Override with COUNCIL_DEDUP_MAX_SIZE_MB environment variable."
            )
            use_deduplication = False

        return use_deduplication, total_files, total_size_bytes, eligible_files

    async def collect_file_metadata(
        self,
        file_collector
    ) -> Tuple[List[str], Dict[str, Tuple[int, int]]]:
        """
        Collect file paths and metadata (NOT content) for cache checking.

        Args:
            file_collector: File collector instance

        Returns:
            Tuple of (filepaths, files_metadata)
        """
        return file_collector.collect_filepaths_and_metadata(file_collector._project_root or ".")

    async def load_files(
        self,
        file_collector,
        project_path: str,
        use_async: bool = False,
        parallel_workers: int = 1,
        force_streaming: bool = None,
        disable_streaming: bool = False
    ) -> Tuple[Dict[str, str], Dict[str, Tuple[int, int]]]:
        """
        Load file contents into memory.

        PERFORMANCE FIX: Automatically enables streaming for large projects (>50MB)
        to prevent out-of-memory errors. Streaming can be controlled via CLI flags:
        - --streaming: Force streaming mode
        - --no-streaming: Disable auto-streaming

        Args:
            file_collector: File collector instance
            project_path: Path to the project
            use_async: Whether to use async operations
            parallel_workers: Number of parallel workers
            force_streaming: Force streaming mode regardless of project size
            disable_streaming: Disable auto-streaming even for large projects

        Returns:
            Tuple of (files_content, files_metadata)
        """
        if parallel_workers > 1 and not use_async:
            files_content = file_collector.collect_project_files_parallel(project_path)[0]
            return files_content, {}

        should_stream = False
        if force_streaming:
            should_stream = True
        elif not disable_streaming:
            total_files, total_size_bytes, eligible_files = file_collector.estimate_project_size(project_path)
            size_mb = total_size_bytes / (1024 * 1024)
            streaming_threshold = CONSTANTS.get_streaming_threshold_mb()
            should_stream = size_mb > streaming_threshold

            if should_stream:
                self.output_formatter.print_warning(
                    f"Project size is {size_mb:.1f}MB. Using streaming mode for memory efficiency."
                )

        if should_stream:
            return await self.load_files_streaming(file_collector, project_path, use_async)

        if use_async:
            return await file_collector.collect_project_files_async(project_path)
        else:
            return file_collector.collect_project_files(project_path)

    def apply_deduplication(
        self,
        files_content: Dict[str, str],
        use_deduplication: bool
    ) -> Dict[str, str]:
        """
        Apply deduplication if enabled.

        Args:
            files_content: Files content dict
            use_deduplication: Whether to use deduplication

        Returns:
            Deduplicated files content dict
        """
        if not use_deduplication:
            return files_content

        deduplicator = ContentDeduplicator()
        unique_files, duplicate_mapping = deduplicator.deduplicate_files(files_content)
        reduction = len(files_content) - len(unique_files)

        if reduction > 0:
            self.output_formatter.print_warning(
                f"Deduplication reduced {len(files_content)} files to {len(unique_files)} files "
                f"({reduction} duplicates removed)"
            )
            return unique_files

        return files_content

    async def load_files_streaming(
        self,
        file_collector,
        project_path: str,
        use_async: bool = False,
    ) -> Tuple[Dict[str, str], Dict[str, Tuple[int, int]]]:
        """
        Load file contents using streaming mode for memory efficiency.

        This method processes files in batches to reduce memory usage for large projects.
        It automatically detects project size and enables streaming for projects > 100MB.

        Args:
            file_collector: File collector instance
            project_path: Path to the project
            use_async: Whether to use async operations

        Returns:
            Tuple of (files_content, files_metadata)
        """
        total_files, total_size_bytes, eligible_files = file_collector.estimate_project_size(
            project_path
        )

        size_mb = total_size_bytes / (1024 * 1024)
        streaming_threshold = CONSTANTS.get_streaming_threshold_mb()
        should_stream = size_mb > streaming_threshold

        if should_stream:
            self.output_formatter.print_warning(
                f"Project size is {size_mb:.1f}MB. Using streaming mode for memory efficiency."
            )

        if use_async and hasattr(file_collector, 'collect_project_files_streaming_async'):
            return await file_collector.collect_project_files_streaming_async(project_path)
        elif hasattr(file_collector, 'collect_project_files_streaming'):
            files_content = {}
            files_metadata = {}
            for relative_path, content, file_size, file_mtime in file_collector.collect_project_files_streaming(project_path):
                files_content[relative_path] = content
                files_metadata[relative_path] = (file_size, file_mtime)
            return files_content, files_metadata
        else:
            return self.load_files(file_collector, project_path, use_async)
