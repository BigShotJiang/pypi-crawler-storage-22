"""
File reading utilities with security and size checks.

This module handles file reading operations including size limits,
secret scanning, and content processing.
"""
import os
from typing import Optional, Tuple, Dict, Any

from council.models import CONSTANTS
from council.secret_scanner import SecretScanner
from council.output import sanitize_path_for_display
from council.security import SecurityValidator


class FileReader:
    """
    Handles file reading with security checks and content processing.

    Responsibilities:
    - File reading with encoding handling
    - Size limit enforcement
    - Secret scanning and redaction
    - Content validation
    """

    def __init__(self, output_formatter=None, file_validator=None):
        """
        Initialize the file reader.

        Args:
            output_formatter: Output formatter for warnings
            file_validator: FileValidator instance for validation
        """
        self.output_formatter = output_formatter
        self.file_validator = file_validator

    def read_file_with_checks(
        self,
        filepath: str,
        total_size_counter: Optional[Dict[str, Any]] = None
    ) -> Optional[Tuple[str, int, float]]:
        """
        Read file with size checking and security validation.

        FIX-013: Error handling follows the decision matrix:
        - Security violations: raise FileError immediately (scan_filename)
        - Size/count limits: print warning + return None (non-critical)
        - Empty files: return None (intentionally skipped)
        - Read errors: raise FileError (critical failure)

        Args:
            filepath: Path to the file to read
            total_size_counter: Optional dict tracking total size and count
                Keys: 'total_size_bytes', 'file_count'

        Returns:
            Tuple of (content, file_size, file_mtime) or None if file should be skipped

        Raises:
            OSError: If file cannot be read
            FileError: If security validation fails
        """
        try:
            # Scan filename for sensitive patterns BEFORE reading
            SecretScanner.scan_filename(filepath)

            # Get file metadata
            stat = os.stat(filepath)
            file_size = stat.st_size
            file_mtime = stat.st_mtime

            # Check individual file size
            if self.file_validator and not self.file_validator.check_individual_file_size(file_size):
                max_size = self.file_validator.get_max_file_size_mb() if self.file_validator else CONSTANTS.MAX_FILE_SIZE_MB
                if self.output_formatter:
                    self.output_formatter.print_warning(
                        f"File {sanitize_path_for_display(filepath)} ({file_size/(1024*1024):.1f}MB) "
                        f"exceeds maximum file size of {max_size}MB"
                    )
                return None

            # Check total size limit
            if total_size_counter:
                current_total = total_size_counter.get('total_size_bytes', 0)
                if self.file_validator and not self.file_validator.check_total_size(current_total, file_size):
                    max_total = self.file_validator.get_max_total_size_mb() if self.file_validator else CONSTANTS.MAX_TOTAL_SIZE_MB
                    if self.output_formatter:
                        self.output_formatter.print_warning(
                            f"Total size limit ({max_total}MB) would be exceeded by {sanitize_path_for_display(filepath)}"
                        )
                    return None

                # Check file count limit
                current_count = total_size_counter.get('file_count', 0)
                if self.file_validator and not self.file_validator.check_file_count(current_count):
                    max_count = self.file_validator.get_max_file_count() if self.file_validator else CONSTANTS.MAX_FILE_COUNT
                    if self.output_formatter:
                        self.output_formatter.print_warning(
                            f"File count limit ({max_count}) reached"
                        )
                    return None

            # SECURITY FIX: Use O_NOFOLLOW to prevent symlink attacks
            # This ensures we don't follow symlinks when opening files, preventing
            # an attacker from creating a symlink inside the project pointing to
            # sensitive files outside the project (e.g., /root/.ssh/id_rsa)
            fd = None
            try:
                fd = os.open(filepath, os.O_RDONLY | os.O_NOFOLLOW)
                with open(fd, 'r', encoding='utf-8') as f:
                    content = f.read()
            except OSError as e:
                # If it's a symlink, provide clear error message
                if os.path.islink(filepath):
                    from council.exceptions import FileError
                    raise FileError(
                        f"Security: File '{sanitize_path_for_display(filepath)}' is a symlink. "
                        f"Symlinks are not allowed to prevent path traversal attacks."
                    )
                raise
            finally:
                if fd is not None:
                    try:
                        os.close(fd)
                    except OSError:
                        pass

            # Only include non-empty files
            if not content.strip():
                return None

            # CRITICAL SECURITY FIX: Redact secrets BEFORE storing content
            # This prevents secrets from being sent to third-party AI APIs
            redacted_content, secrets = SecretScanner.redact_secrets(content, filepath)

            if secrets and self.output_formatter:
                # Log summary of what was redacted (one line per file)
                self.output_formatter.print_warning(
                    f"⚠ Redacted {len(secrets)} secret(s) from {sanitize_path_for_display(filepath)}"
                )

            # Use redacted content (or original if no secrets found)
            final_content = redacted_content if secrets else content

            # Update counters
            if total_size_counter:
                total_size_counter['total_size_bytes'] = total_size_counter.get('total_size_bytes', 0) + file_size
                total_size_counter['file_count'] = total_size_counter.get('file_count', 0) + 1

            return final_content, file_size, file_mtime

        except OSError as e:
            from council.exceptions import FileError
            raise FileError(f"Could not read {filepath}: {e}")

    def process_content(
        self,
        content: str,
        filepath: str,
        file_size: int,
        file_mtime: float
    ) -> Tuple[str, int, float]:
        """
        Process file content after reading.

        Args:
            content: Raw file content
            filepath: Path to the file
            file_size: Size of the file
            file_mtime: Modification time

        Returns:
            Tuple of (processed_content, file_size, file_mtime)
        """
        # Check if content is non-empty
        if not content.strip():
            raise ValueError("File content is empty")

        # Redact secrets
        redacted_content, secrets = SecretScanner.redact_secrets(content, filepath)

        if secrets and self.output_formatter:
            self.output_formatter.print_warning(
                f"⚠ Redacted {len(secrets)} secret(s) from {sanitize_path_for_display(filepath)}"
            )

        # Return redacted content (or original if no secrets)
        return (redacted_content if secrets else content), file_size, file_mtime

    def update_counters(
        self,
        total_size_counter: Dict[str, Any],
        file_size: int
    ) -> None:
        """
        Update size and count counters.

        Args:
            total_size_counter: Dict with 'total_size_bytes' and 'file_count' keys
            file_size: Size to add
        """
        total_size_counter['total_size_bytes'] = total_size_counter.get('total_size_bytes', 0) + file_size
        total_size_counter['file_count'] = total_size_counter.get('file_count', 0) + 1
