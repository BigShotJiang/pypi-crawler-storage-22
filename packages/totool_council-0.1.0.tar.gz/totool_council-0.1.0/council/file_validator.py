"""
File validation utilities for security and filtering.

This module handles file validation including path traversal protection,
file type checking, and size limits.
"""
import os
from pathlib import Path
from typing import Optional

from council.models import CONSTANTS
from council.security import SecurityValidator


class FileValidator:
    """
    Handles file validation for security and filtering.

    Responsibilities:
    - Path traversal protection
    - File type checking (text vs binary)
    - Project boundary validation
    - Size limit enforcement
    """

    def __init__(self, project_root: Optional[str] = None):
        """
        Initialize the file validator.

        Args:
            project_root: Root directory of the project for path validation
        """
        self._project_root = project_root

    def set_project_root(self, project_root: str) -> None:
        """
        Set the project root for path validation.

        Args:
            project_root: Root directory of the project
        """
        self._project_root = os.path.abspath(project_root)

    def validate_within_project(self, filepath: str) -> bool:
        """
        Validate that a file path is within the project directory.

        Security: Prevents path traversal attacks where attacker could read
        files outside the project directory.

        Args:
            filepath: Absolute path to the file to validate

        Returns:
            True if file is within project, False otherwise

        Raises:
            ValueError: If filepath is outside the project directory
        """
        if self._project_root is None:
            return True  # No project root set, skip validation (backward compatibility)

        try:
            # Get absolute paths
            abs_filepath = os.path.abspath(filepath)
            abs_project_root = os.path.abspath(self._project_root)

            # Use commonpath to check if file is within project
            common_path = os.path.commonpath([abs_filepath, abs_project_root])

            if common_path != abs_project_root:
                raise ValueError(
                    f"Security: File '{filepath}' is outside project directory '{self._project_root}'. "
                    f"This prevents path traversal attacks."
                )
            return True
        except ValueError as e:
            # Paths on different drives (Windows) or other error
            raise ValueError(
                f"Security: File '{filepath}' is not accessible from project '{self._project_root}'."
            )

    def is_text_file(self, filepath: str) -> bool:
        """
        Check if file is likely a text/code file.

        Args:
            filepath: Path to the file to check

        Returns:
            True if file appears to be a text file, False otherwise
        """
        ext = Path(filepath).suffix.lower()
        return ext in (CONSTANTS.TEXT_EXTENSIONS or [])

    def validate_project_path(self, filepath: str, allow_system_paths: bool = False) -> None:
        """
        Validate project path before file operations.

        Args:
            filepath: Path to validate
            allow_system_paths: Whether to allow system paths

        Raises:
            ValueError: If path validation fails
        """
        SecurityValidator.validate_project_path(filepath, allow_system_paths)

    def check_individual_file_size(self, file_size: int) -> bool:
        """
        Check if individual file size is within limits.

        Args:
            file_size: Size of the file in bytes

        Returns:
            True if file size is acceptable, False otherwise
        """
        max_file_size_mb = CONSTANTS.MAX_FILE_SIZE_MB
        return file_size <= max_file_size_mb * 1024 * 1024

    def check_total_size(self, current_total: int, additional_size: int) -> bool:
        """
        Check if adding a file would exceed total size limit.

        Args:
            current_total: Current total size in bytes
            additional_size: Size of file to add in bytes

        Returns:
            True if within limits, False otherwise
        """
        max_total_size_mb = CONSTANTS.MAX_TOTAL_SIZE_MB
        return current_total + additional_size <= max_total_size_mb * 1024 * 1024

    def check_file_count(self, current_count: int) -> bool:
        """
        Check if file count is within limits.

        Args:
            current_count: Current number of files collected

        Returns:
            True if within limits, False otherwise
        """
        max_file_count = CONSTANTS.get_max_file_count()
        return current_count < max_file_count

    def get_max_file_size_mb(self) -> int:
        """Get maximum individual file size in MB."""
        return CONSTANTS.MAX_FILE_SIZE_MB

    def get_max_total_size_mb(self) -> int:
        """Get maximum total size in MB."""
        return CONSTANTS.MAX_TOTAL_SIZE_MB

    def get_max_file_count(self) -> int:
        """Get maximum file count."""
        return CONSTANTS.get_max_file_count()
