"""
File operations and handling for Code Review Council.

This module provides synchronous file collection operations using the
refactored components (PatternMatcher, FileValidator, FileReader, ChunkStrategy).

PERFORMANCE FIX: Uses ThreadPoolExecutor for parallel file reads, reducing
I/O wait time for projects with many files.

PHASE 4: Integrates ProgressCallback for tracking long operations.
"""
import os
from pathlib import Path
from typing import Dict, List, Generator, Tuple, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

from council.models import CONSTANTS
from council.exceptions import FileError
from council.output import OutputFormatter, sanitize_path_for_display
from council.secret_scanner import SecretScanner
from council.security import SecurityValidator
from council.base_file_collector import BaseFileCollector
from council.pattern_matcher import PatternMatcher
from council.file_validator import FileValidator
from council.file_reader import FileReader
from council.chunk_strategy import ChunkStrategy
from council.progress import ProgressCallback, NULL_PROGRESS, ProgressStage


class FileCollector(BaseFileCollector):
    """
    Handles file collection and filtering operations (synchronous).

    This class now inherits from BaseFileCollector and uses the extracted
    components for pattern matching, validation, reading, and chunking.

    PERFORMANCE FIX: Uses ThreadPoolExecutor for parallel file reads,
    reducing I/O wait time for projects with many files.

    PHASE 4: Supports progress callbacks for tracking file collection progress.

    FIX-008: Thread pool size is configurable via TTC_MAX_FILE_WORKERS
    environment variable for different system capabilities.
    """

    @property
    def _MAX_WORKERS(self) -> int:
        """
        Get maximum worker threads from environment or default.

        FIX-008: Makes thread pool size configurable via TTC_MAX_FILE_WORKERS
        environment variable. Defaults to min(8, (cpu_count * 2)).

        Returns:
            Maximum number of worker threads for parallel file operations
        """
        default = min(8, (os.cpu_count() or 2) * 2)
        env_value = os.environ.get('TTC_MAX_FILE_WORKERS')
        if env_value:
            try:
                # Cap at 2x default to prevent excessive resource usage
                return min(int(env_value), default * 2)
            except ValueError:
                return default
        return default

    def __init__(
        self,
        ignore_patterns: List[str],
        output_formatter: OutputFormatter,
        progress_callback: ProgressCallback = NULL_PROGRESS
    ):
        """
        Initialize the file collector.

        Args:
            ignore_patterns: List of ignore patterns
            output_formatter: Output formatter for display
            progress_callback: Optional progress callback for long operations
        """
        # Initialize base class with extracted components
        super().__init__(ignore_patterns, output_formatter)

        # Counter dict for FileReader
        self._size_counter = {'total_size_bytes': 0, 'file_count': 0}
        self._progress_callback = progress_callback

    def _collect_eligible_filepaths(self, path: str) -> List[Tuple[str, str]]:
        """
        Collect all eligible file paths for parallel processing.

        PERFORMANCE FIX: Collects file paths first, then reads them in parallel
        using ThreadPoolExecutor to reduce I/O wait time.

        Args:
            path: Path to the project directory or single file

        Returns:
            List of tuples (relative_path, absolute_path) for eligible files
        """
        eligible_files = []

        if os.path.isfile(path):
            if not self.should_ignore_file(path) and self.is_text_file(path):
                eligible_files.append((path, path))
            return eligible_files

        # Directory
        for root, dirs, files in os.walk(path):
            # Filter out ignored directories
            dirs[:] = [d for d in dirs if not self.should_ignore_file(os.path.join(root, d))]

            for file in files:
                filepath = os.path.join(root, file)
                relative_path = os.path.relpath(filepath, path)

                if self.should_ignore_file(filepath):
                    continue

                if not self.is_text_file(filepath):
                    continue

                eligible_files.append((relative_path, filepath))

        return eligible_files

    def _read_file_task(self, relative_path: str, filepath: str) -> Optional[Tuple[str, str, int, float]]:
        """
        Task function for parallel file reading.

        Args:
            relative_path: Relative path for output
            filepath: Absolute path to read

        Returns:
            Tuple of (relative_path, content, file_size, file_mtime) or None
        """
        try:
            result = self._read_file_with_size_check(filepath)
            if result is not None:
                content, file_size, file_mtime = result
                return (relative_path, content, file_size, file_mtime)
        except Exception as e:
            # Error will be handled by the caller
            pass
        return None

    def collect_project_files(
        self,
        path: str,
        progress_callback: Optional[ProgressCallback] = None
    ) -> Tuple[Dict[str, str], Dict[str, Tuple[int, float]]]:
        """
        Collect all code files from a project directory or single file.

        PERFORMANCE FIX: Uses ThreadPoolExecutor to read files in parallel,
        significantly reducing I/O wait time for projects with many files.

        PHASE 4: Supports progress callbacks for tracking collection progress.

        Args:
            path: Path to the project directory or single file
            progress_callback: Optional progress callback (overrides instance callback)

        Returns:
            Tuple of (files_content, files_metadata) where:
            - files_content: Dict mapping filepath to file content
            - files_metadata: Dict mapping filepath to (size, mtime) tuple
        """
        # Use provided callback or fall back to instance callback
        callback = progress_callback if progress_callback is not None else self._progress_callback

        files_content = {}
        self.files_metadata = {}
        self._size_counter = {'total_size_bytes': 0, 'file_count': 0}

        self.set_project_root(path)

        if os.path.isfile(path):
            if not self.should_ignore_file(path) and self.is_text_file(path):
                callback(0, 1, f"Reading {sanitize_path_for_display(path)}", ProgressStage.LOADING)
                try:
                    result = self._read_file_with_size_check(path)
                    if result is not None:
                        content, file_size, file_mtime = result
                        files_content[path] = content
                        self.files_metadata[path] = (file_size, file_mtime)
                        print(f"  {self.output_formatter.color_class.GREEN}✓{self.output_formatter.color_class.RESET} {sanitize_path_for_display(path)}")
                except Exception as e:
                    self.output_formatter.print_warning(f"Could not read {sanitize_path_for_display(path)}: {e}")
                callback(1, 1, "Done", ProgressStage.LOADING)
            return files_content, self.files_metadata

        # Directory must exist
        if not os.path.isdir(path):
            raise FileError(f"Path does not exist: {path}")

        self.output_formatter.print_warning(f"📂 Scanning project directory: {path}")

        # PERFORMANCE FIX: Collect eligible files first, then read in parallel
        eligible_files = self._collect_eligible_filepaths(path)

        if not eligible_files:
            return files_content, self.files_metadata

        total_files = len(eligible_files)
        callback(0, total_files, f"Loading {total_files} files...", ProgressStage.LOADING)

        # Use ThreadPoolExecutor for parallel file reading
        completed_count = 0
        with ThreadPoolExecutor(max_workers=self._MAX_WORKERS, thread_name_prefix="file_reader") as executor:
            # Submit all file reading tasks
            future_to_file = {
                executor.submit(self._read_file_task, rel_path, abs_path): (rel_path, abs_path)
                for rel_path, abs_path in eligible_files
            }

            # Process completed tasks
            for future in as_completed(future_to_file):
                rel_path, abs_path = future_to_file[future]
                try:
                    result = future.result()
                    if result is not None:
                        rel_path, content, file_size, file_mtime = result
                        files_content[rel_path] = content
                        self.files_metadata[rel_path] = (file_size, file_mtime)
                        print(f"  {self.output_formatter.color_class.GREEN}✓{self.output_formatter.color_class.RESET} {sanitize_path_for_display(rel_path)}")

                        completed_count += 1
                        if completed_count % 10 == 0 or completed_count == total_files:
                            callback(completed_count, total_files, f"Loaded {completed_count}/{total_files} files", ProgressStage.LOADING)
                except Exception as e:
                    self.output_formatter.print_warning(f"⚠ {sanitize_path_for_display(rel_path)} (could not read: {e})")

        callback(total_files, total_files, "Done", ProgressStage.LOADING)
        return files_content, self.files_metadata
    
    def collect_project_files_streaming(
        self,
        path: str,
        progress_callback: Optional[ProgressCallback] = None
    ) -> Generator[Tuple[str, str, int, float], None, None]:
        """
        Stream files one at a time instead of loading all at once.

        PHASE 4: Supports progress callbacks for tracking streaming progress.

        Args:
            path: Path to the project directory or single file
            progress_callback: Optional progress callback (overrides instance callback)

        Yields:
            Tuples of (relative_path, content, file_size, file_mtime)
        """
        # Use provided callback or fall back to instance callback
        callback = progress_callback if progress_callback is not None else self._progress_callback

        self.files_metadata = {}
        self._size_counter = {'total_size_bytes': 0, 'file_count': 0}

        # Set project root for security validation
        self.set_project_root(path)

        if os.path.isfile(path):
            callback(0, 1, f"Reading {sanitize_path_for_display(path)}", ProgressStage.LOADING)
            if not self.should_ignore_file(path) and self.is_text_file(path):
                try:
                    result = self._read_file_with_size_check(path)
                    if result is not None:
                        content, file_size, file_mtime = result
                        self.files_metadata[path] = (file_size, file_mtime)
                        yield path, content, file_size, file_mtime
                        print(f"  {self.output_formatter.color_class.GREEN}✓{self.output_formatter.color_class.RESET} {sanitize_path_for_display(path)}")
                except Exception as e:
                    self.output_formatter.print_warning(f"Could not read {sanitize_path_for_display(path)}: {e}")
            callback(1, 1, "Done", ProgressStage.LOADING)
            return

        # Directory
        if not os.path.isdir(path):
            raise FileError(f"Path does not exist: {path}")

        self.output_formatter.print_warning(f"📂 Scanning project directory: {path}")

        # FIX-007: Single-pass directory walk - no pre-counting
        # Previously walked twice (once to count, once to yield), doubling I/O.
        # Now uses approximate progress with None as total until complete.
        callback(0, None, "Streaming files...", ProgressStage.LOADING)

        file_count = 0
        for root, dirs, files in os.walk(path):
            # Filter out ignored directories
            dirs[:] = [d for d in dirs if not self.should_ignore_file(os.path.join(root, d))]

            for file in files:
                filepath = os.path.join(root, file)
                relative_path = os.path.relpath(filepath, path)

                if self.should_ignore_file(filepath):
                    continue

                if not self.is_text_file(filepath):
                    continue

                try:
                    result = self._read_file_with_size_check(filepath)
                    if result is not None:
                        content, file_size, file_mtime = result
                        self.files_metadata[relative_path] = (file_size, file_mtime)
                        file_count += 1
                        # Update progress periodically (approximate - total is None)
                        if file_count % 10 == 0:
                            callback(file_count, None, f"Streaming... ({file_count} files)", ProgressStage.LOADING)
                        yield relative_path, content, file_size, file_mtime
                        print(f"  {self.output_formatter.color_class.GREEN}✓{self.output_formatter.color_class.RESET} {relative_path}")
                except Exception as e:
                    self.output_formatter.print_warning(f"⚠ {sanitize_path_for_display(relative_path)} (could not read)")

        callback(file_count, file_count, "Done", ProgressStage.LOADING)

    def collect_filepaths_and_metadata(self, path: str) -> Tuple[List[str], Dict[str, Tuple[int, float]]]:
        """
        Collect file paths and metadata WITHOUT loading file contents.

        This is critical for cache checking: we need to generate a cache key
        BEFORE loading all files into memory. For a 10MB project on cache hit,
        this saves 0.5-2s of wasted I/O and memory allocation.

        Args:
            path: Path to the project directory or single file

        Returns:
            Tuple of (filepaths, files_metadata) where:
            - filepaths: List of file paths (relative to project root)
            - files_metadata: Dict mapping filepath to (size, mtime) tuple
        """
        self.set_project_root(path)
        return self._collect_filepaths_and_metadata_sync(path)

    # Note: should_ignore_file, is_text_file, should_chunk, and chunk_files
    # are now inherited from BaseFileCollector
    
    def _read_file_with_size_check(self, filepath: str) -> Optional[Tuple[str, int, float]]:
        """
        Read file with size checking and warnings.

        Uses the FileReader component for the actual reading logic.

        SECURITY: Checks for symlink immediately before reading to prevent
        TOCTOU (Time-Of-Check-Time-Of-Use) attacks. Between path validation
        and file reading, an attacker could replace the file with a symlink to
        a sensitive file. This check prevents that attack vector.

        Args:
            filepath: Path to the file to read

        Returns:
            Tuple of (content, file_size, file_mtime) or None if file should be skipped

        Raises:
            FileError: If the file is a symlink (security protection)
        """
        # Validate project path before file operations (security)
        SecurityValidator.validate_project_path(filepath, allow_system_paths=False)

        # FIX-004: CRITICAL - Verify file is not a symlink immediately before reading
        # This prevents TOCTOU attacks where an attacker replaces a valid file
        # with a symlink between validation and reading
        if os.path.islink(filepath):
            raise FileError(
                f"Security: File is a symlink (rejected): {sanitize_path_for_display(filepath)}. "
                f"This prevents symlink attacks where sensitive files could be accessed."
            )

        # Use FileReader component
        return self.file_reader.read_file_with_checks(filepath, self._size_counter)

    # Note: chunk_files is now inherited from BaseFileCollector (delegates to ChunkStrategy)


    def estimate_project_size(self, path: str) -> Tuple[int, int, int]:
        """
        Estimate project size without loading file contents.

        Args:
            path: Path to the project directory or single file

        Returns:
            Tuple of (total_files, total_size_bytes, eligible_files)
        """
        self.set_project_root(path)
        return self._estimate_project_size_sync(path)

    # Note: should_chunk is now inherited from BaseFileCollector (delegates to ChunkStrategy)



class ContextLoader:
    """Handles loading context files."""

    def __init__(self, output_formatter: OutputFormatter, project_path: str | None = None):
        self.output_formatter = output_formatter
        self.project_path = project_path
    
    def load_context_files(self, context_paths: List[str], project_path: str | None = None) -> Dict[str, str]:
        """Load context files to provide additional information."""
        context = {}

        if not context_paths:
            return context

        # Use provided project_path or fall back to instance variable
        base_project_path = project_path or self.project_path or '.'

        self.output_formatter.print_warning(f"📖 Loading context files...")

        for path in context_paths:
            try:
                # Security validation: ensure context file is within project directory
                if base_project_path:
                    SecurityValidator.validate_context_file(path, base_project_path)
            except ValueError as e:
                self.output_formatter.print_warning(f"⚠ {sanitize_path_for_display(path)} ({e})")
                continue

            if not os.path.exists(path):
                self.output_formatter.print_warning(f"⚠ {sanitize_path_for_display(path)} (not found)")
                continue

            if not os.path.isfile(path):
                self.output_formatter.print_warning(f"⚠ {sanitize_path_for_display(path)} (not a file)")
                continue

            try:
                # SECURITY FIX: Use O_NOFOLLOW to prevent symlink attacks
                # Context files could be symlinked to sensitive files outside the project
                fd = None
                try:
                    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
                    with open(fd, 'r', encoding='utf-8') as f:
                        content = f.read()
                        if content.strip():
                            context[path] = content
                            print(f"  {self.output_formatter.color_class.GREEN}✓{self.output_formatter.color_class.RESET} {sanitize_path_for_display(path)}")
                        else:
                            self.output_formatter.print_warning(f"⚠ {path} (empty)")
                except OSError as e:
                    # If it's a symlink, provide clear error message
                    if os.path.islink(path):
                        self.output_formatter.print_warning(
                            f"⚠ {sanitize_path_for_display(path)} (symlink rejected for security)"
                        )
                        continue
                    raise
                finally:
                    if fd is not None:
                        try:
                            os.close(fd)
                        except OSError:
                            pass
            except Exception as e:
                self.output_formatter.print_warning(f"⚠ {sanitize_path_for_display(path)} (error: {e})")

        return context


class EnvironmentLoader:
    """Handles loading environment variables from .env files."""
    
    def load_env_file(self, filepath: str = '.env') -> Dict[str, str]:
        """Load environment variables from .env file."""
        env_vars = {}
        
        if not os.path.exists(filepath):
            return env_vars
        
        try:
            with open(filepath, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    
                    if '=' in line:
                        key, value = line.split('=', 1)
                        key = key.strip()
                        value = value.strip()
                        
                        # Remove quotes if present
                        if value.startswith('"') and value.endswith('"'):
                            value = value[1:-1]
                        elif value.startswith("'") and value.endswith("'"):
                            value = value[1:-1]
                        
                        env_vars[key] = value
        except Exception as e:
            print(f"Warning: Could not read .env file: {e}")
        
        return env_vars


class IgnorePatternLoader:
    """Handles loading ignore patterns from .gitignore files."""
    
    def __init__(self, output_formatter: OutputFormatter):
        self.output_formatter = output_formatter
    
    def load_ignore_file(self, filepath: str = '.gitignore') -> List[str]:
        """Load ignore patterns from .gitignore file."""
        patterns = []
        
        if not os.path.exists(filepath):
            return patterns
        
        try:
            with open(filepath, 'r') as f:
                for line in f:
                    line = line.strip()
                    # Skip empty lines and comments
                    if not line or line.startswith('#'):
                        continue
                    
                    # Remove trailing slashes for consistency
                    pattern = line.rstrip('/')
                    patterns.append(pattern)
            
            if patterns:
                print(f"{self.output_formatter.color_class.CYAN}📋 Loaded {len(patterns)} ignore pattern(s) from {sanitize_path_for_display(filepath)}{self.output_formatter.color_class.RESET}")
        except Exception as e:
            self.output_formatter.print_warning(f"Could not read {filepath}: {e}")
        
        return patterns