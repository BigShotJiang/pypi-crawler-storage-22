"""
Shared formatting utilities for Code Review Council.
Provides centralized chunk formatting logic to reduce code duplication.
"""
from typing import Dict, List, Optional


class ReviewFormatter:
    """
    Centralized review formatting for code reviews.

    This class provides methods to format code reviews consistently
    across different review modes (single, multi-file, chunked, hierarchical, parallel).

    It handles formatting of:
    - Individual file chunks
    - Multi-file content
    - Overall assessments for hierarchical reviews
    """

    @staticmethod
    def format_chunk_content(
        chunk: Dict[str, str],
        chunk_idx: int,
        total_chunks: int,
        context_files: Optional[Dict[str, str]] = None,
        details: str = ""
    ) -> str:
        """
        Format a chunk of files for code review.

        Args:
            chunk: Dictionary mapping file paths to file contents
            chunk_idx: Current chunk index (1-based)
            total_chunks: Total number of chunks
            context_files: Optional context files to include (only in first chunk)
            details: Additional review instructions

        Returns:
            Formatted chunk content as a string
        """
        # Use list join for better performance than string concatenation
        lines = []

        # Include context files in first chunk only
        if context_files and chunk_idx == 1:
            lines.append('=' * 70)
            lines.append(f"ADDITIONAL CONTEXT ({len(context_files)} file(s))")
            lines.append('=' * 70)
            lines.append('')
            lines.append("The following files provide additional context about the project:")
            lines.append('')

            for filepath, content in context_files.items():
                lines.append(f"--- {filepath} ---")
                lines.append(content)
                lines.append('')

        # Add chunk header
        lines.append('=' * 70)
        lines.append(f"CHUNK {chunk_idx}/{total_chunks} ({len(chunk)} file(s))")
        lines.append('=' * 70)
        lines.append('')

        # Add files in chunk
        for filepath, content in chunk.items():
            lines.append('=' * 70)
            lines.append(f"FILE: {filepath}")
            lines.append('=' * 70)
            lines.append(content)
            lines.append('')

        chunk_content = '\n'.join(lines)

        # Add details if provided
        if details:
            details_lines = [
                "ADDITIONAL REVIEW INSTRUCTIONS:",
                details,
                "",
                "=" * 70,
                "",
                chunk_content
            ]
            chunk_content = '\n'.join(details_lines)

        return chunk_content

    @staticmethod
    def format_overall_assessment(
        chunk_summaries: List[str],
        total_chunks: int
    ) -> str:
        """
        Format overall assessment for hierarchical review.

        Args:
            chunk_summaries: List of chunk summaries
            total_chunks: Total number of chunks reviewed

        Returns:
            Formatted overall assessment as a string
        """
        lines = []
        lines.append('=' * 70)
        lines.append("OVERALL ASSESSMENT")
        lines.append('=' * 70)
        lines.append('')
        lines.append(f"The following codebase was reviewed in {total_chunks} chunk(s).")
        lines.append('')
        lines.append("Below are summaries of each chunk:")
        lines.append('')

        for idx, summary in enumerate(chunk_summaries, 1):
            lines.append('=' * 70)
            lines.append(f"CHUNK {idx}/{total_chunks} SUMMARY")
            lines.append('=' * 70)
            lines.append('')
            lines.append(summary)
            lines.append('')

        lines.append('=' * 70)
        lines.append("Please provide an overall assessment of the entire codebase")
        lines.append("based on the chunk summaries above.")
        lines.append('=' * 70)

        return '\n'.join(lines)

    @staticmethod
    def format_multi_file_content(
        files_content: Dict[str, str],
        context_files: Optional[Dict[str, str]] = None,
        details: str = ""
    ) -> str:
        """
        Format multiple files for code review (non-chunked).

        Args:
            files_content: Dictionary mapping file paths to file contents
            context_files: Optional context files
            details: Additional review instructions

        Returns:
            Formatted content as a string
        """
        # Use review formatter with single chunk
        return ReviewFormatter.format_chunk_content(
            chunk=files_content,
            chunk_idx=1,
            total_chunks=1,
            context_files=context_files,
            details=details
        )
