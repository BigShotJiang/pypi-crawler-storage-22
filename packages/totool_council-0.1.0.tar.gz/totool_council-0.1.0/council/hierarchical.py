"""
Hierarchical review strategy for large codebases.
Review chunks independently, then provide overall assessment.
"""
from typing import List, Dict, Any
from .models import ReviewResult, ConsensusResult
from .review import ReviewRunner
from .output import OutputFormatter
from .formatters import ReviewFormatter


class HierarchicalReviewRunner:
    """Run hierarchical reviews for large codebases."""
    
    def __init__(self, review_runner: ReviewRunner, output_formatter: OutputFormatter):
        self.review_runner = review_runner
        self.output_formatter = output_formatter
    
    def run_hierarchical_reviews(self, critics: List[Any], chunks: List[Dict[str, str]],
                               context_files: Dict[str, str], details: str,
                               verbose: bool = False) -> List[ReviewResult]:
        """Run hierarchical reviews with chunk summaries and overall assessment."""
        all_results = []
        chunk_summaries = []
        total_chunks = len(chunks)

        # Step 1: Review each chunk independently
        for chunk_idx, chunk in enumerate(chunks, 1):
            # Use centralized review formatter
            chunk_content = ReviewFormatter.format_chunk_content(
                chunk=chunk,
                chunk_idx=chunk_idx,
                total_chunks=total_chunks,
                context_files=context_files if chunk_idx == 1 else None,
                details=details
            )

            # Run reviews for this chunk
            is_multi_file = len(chunk) > 1
            chunk_results = self.review_runner.run_reviews(critics, chunk_content, is_multi_file, verbose)
            all_results.extend(chunk_results)

            # Create chunk summary
            chunk_summary = self._create_chunk_summary(chunk_results, chunk_idx, chunk)
            chunk_summaries.append(chunk_summary)

        # Step 2: Create overall assessment from chunk summaries
        if total_chunks > 1:
            overall_assessment = self._create_overall_assessment(chunk_summaries, total_chunks)

            # Run overall assessment review
            overall_results = self.review_runner.run_reviews(critics, overall_assessment,
                                                           is_multi_file=True, verbose=verbose)
            all_results.extend(overall_results)

        return all_results

    def _create_chunk_summary(self, chunk_results: List[ReviewResult], chunk_idx: int,
                            chunk: Dict[str, str]) -> Dict[str, Any]:
        """Create summary of a chunk's review results."""
        # Count verdicts
        verdict_counts = {'APPROVE': 0, 'REJECT': 0, 'NEEDS_WORK': 0}
        for result in chunk_results:
            verdict_counts[result.verdict] += 1
        
        # Determine chunk decision
        max_votes = max(verdict_counts.values())
        chunk_decision = [k for k, v in verdict_counts.items() if v == max_votes][0]
        
        # Calculate average confidence
        total_confidence = sum(r.confidence for r in chunk_results)
        avg_confidence = total_confidence / len(chunk_results) if chunk_results else 0
        
        return {
            'chunk_idx': chunk_idx,
            'file_count': len(chunk),
            'files': list(chunk.keys()),
            'verdict_counts': verdict_counts,
            'decision': chunk_decision,
            'avg_confidence': avg_confidence,
            'results': chunk_results
        }
    
    def _create_overall_assessment(self, chunk_summaries: List[Dict[str, Any]],
                                 total_chunks: int) -> str:
        """
        Create overall assessment content from chunk summaries.
        """
        lines = [
            f"{'='*70}\n",
            f"OVERALL ASSESSMENT - {total_chunks} CHUNKS REVIEWED\n",
            f"{'='*70}\n\n",
            "Based on the individual chunk reviews, please provide an overall assessment\n",
            "of the entire codebase, considering:\n\n",
            "1. Consistency across chunks\n",
            "2. Overall code quality trends\n",
            "3. Cross-cutting concerns\n",
            "4. Final recommendation for the entire project\n\n",
            f"{'='*70}\n",
            "CHUNK REVIEW SUMMARIES\n",
            f"{'='*70}\n\n",
        ]

        for summary in chunk_summaries:
            files_str = ', '.join(summary['files'][:3])
            if len(summary['files']) > 3:
                files_str += f" ... and {len(summary['files']) - 3} more"

            lines.extend([
                f"CHUNK {summary['chunk_idx']} ({summary['file_count']} files):\n",
                f"  Files: {files_str}\n",
                f"  Decision: {summary['decision']} (Avg confidence: {summary['avg_confidence']:.1f}/10)\n",
                f"  Votes: {summary['verdict_counts']}\n\n",
            ])

        lines.extend([
            f"{'='*70}\n",
            "OVERALL ASSESSMENT REQUESTED\n",
            f"{'='*70}\n\n",
            "Please provide your overall assessment considering all chunks above.\n",
            "Include VERDICT: and CONFIDENCE: lines as usual.\n",
        ])

        return ''.join(lines)