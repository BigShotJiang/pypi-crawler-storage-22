"""Parse JSON-structured reviews from critics in map-reduce mode."""
import json
import re
from typing import Optional, List, Dict

from council.models import StructuredFindings, Issue


class JSONReviewParser:
    """Parse JSON-structured reviews from critics."""

    # Regex to find JSON block between triple backticks
    JSON_PATTERN = re.compile(r'```json\s*(.*?)\s*```', re.DOTALL)
    # Fallback: find any JSON-like object with findings key
    JSON_FALLBACK = re.compile(r'\{[^{]*?"findings".*?\}', re.DOTALL)

    @staticmethod
    def extract_json_block(text: str) -> Optional[str]:
        """Extract JSON block from review text."""
        # Try to find ```json...``` block first
        match = JSONReviewParser.JSON_PATTERN.search(text)
        if match:
            return match.group(1)

        # Fallback: find any JSON-like object
        match = JSONReviewParser.JSON_FALLBACK.search(text)
        if match:
            return match.group(0)

        return None

    @staticmethod
    def parse_issue(issue_dict: Dict) -> Issue:
        """Parse a single issue from dict to Issue dataclass."""
        return Issue(
            severity=issue_dict.get('severity', 'medium'),
            type=issue_dict.get('type', 'code_quality'),
            file=issue_dict.get('file', 'unknown'),
            line=issue_dict.get('line'),
            function=issue_dict.get('function'),
            description=issue_dict.get('description', ''),
            cwe=issue_dict.get('cwe'),
            recommendation=issue_dict.get('recommendation', '')
        )

    @classmethod
    def parse_review(
        cls,
        review_text: str,
        critic_name: str,
        critic_role: str,
        chunk_idx: int,
        total_chunks: int,
        files_reviewed: List[str]
    ) -> Optional[StructuredFindings]:
        """Extract JSON from review text and parse into StructuredFindings."""
        json_str = cls.extract_json_block(review_text)
        if not json_str:
            return None

        try:
            data = json.loads(json_str)
        except json.JSONDecodeError:
            return None

        # Parse findings by severity
        findings = {}
        for severity in ['critical', 'high', 'medium', 'low']:
            severity_issues = data.get('findings', {}).get(severity, [])
            findings[severity] = [
                cls.parse_issue(issue) for issue in severity_issues
            ]

        return StructuredFindings(
            critic_name=critic_name,
            critic_role=critic_role,
            chunk_idx=chunk_idx,
            total_chunks=total_chunks,
            files_reviewed=files_reviewed,
            findings=findings,
            patterns_found=data.get('patterns_found', []),
            summary=data.get('summary', ''),
            verdict=data.get('verdict', 'NEEDS_WORK'),
            confidence=data.get('confidence', 5)
        )
