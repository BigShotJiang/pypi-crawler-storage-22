"""
Logger interface for Code Review Council.

This module provides a Logger protocol for dependency injection, separating
logging concerns from UI display concerns.

CODE QUALITY: Extracted from output.py to reduce coupling and improve testability.
"""
from typing import Protocol
from council.output import Colors


class Logger(Protocol):
    """Logger protocol for dependency injection."""

    def info(self, msg: str) -> None:
        """Log an informational message."""
        ...

    def warning(self, msg: str) -> None:
        """Log a warning message."""
        ...

    def error(self, msg: str) -> None:
        """Log an error message."""
        ...

    def debug(self, msg: str) -> None:
        """Log a debug message (only when verbose)."""
        ...


class ConsoleLogger:
    """Console-based logger implementation."""

    def __init__(self, verbose: bool = False, color_class=Colors):
        """
        Initialize console logger.

        Args:
            verbose: Whether to print debug messages
            color_class: Color class for terminal output
        """
        self.verbose = verbose
        self.color_class = color_class

    def info(self, msg: str) -> None:
        """Log an informational message."""
        print(f"{self.color_class.CYAN}INFO: {msg}{self.color_class.RESET}")

    def warning(self, msg: str) -> None:
        """Log a warning message."""
        print(f"{self.color_class.YELLOW}Warning: {msg}{self.color_class.RESET}")

    def error(self, msg: str) -> None:
        """Log an error message."""
        print(f"{self.color_class.RED}Error: {msg}{self.color_class.RESET}")

    def debug(self, msg: str) -> None:
        """Log a debug message (only when verbose is enabled)."""
        if self.verbose:
            print(f"DEBUG: {msg}")

    def get_memory_usage(self) -> float:
        """
        Get current memory usage in MB.

        Needed by Session for memory monitoring. This is kept in the logger
        because it's a diagnostic/debugging utility.

        Returns:
            Memory usage in MB, or 0.0 if psutil is not available
        """
        try:
            import psutil
            process = psutil.Process()
            return process.memory_info().rss / (1024 * 1024)
        except Exception:
            return 0.0


class NullLogger:
    """No-op logger for testing and silent operation."""

    def info(self, msg: str) -> None:
        """No-op info log."""
        pass

    def warning(self, msg: str) -> None:
        """No-op warning log."""
        pass

    def error(self, msg: str) -> None:
        """No-op error log."""
        pass

    def debug(self, msg: str) -> None:
        """No-op debug log."""
        pass

    def get_memory_usage(self) -> float:
        """Return 0.0 for null logger."""
        return 0.0
