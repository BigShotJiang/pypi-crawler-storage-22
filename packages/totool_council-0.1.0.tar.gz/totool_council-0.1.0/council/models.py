"""
Data models and configuration for the Code Review Council.
"""
import os
from dataclasses import dataclass
from typing import List, Dict, Any
from pathlib import Path


@dataclass(frozen=True)
class Constants:
    """Application-wide constants.

    Magic number documentation:
    - DEFAULT_MAX_TOKENS (32000): Efficient for 128K context models (DeepSeek, etc.). Use 8000 for 8K models.
    - MAX_FILE_SIZE_MB (1): Prevents loading huge files that could crash the process.
      At 1MB, a file could have ~250K tokens (4 chars/token), well beyond context limits.
    - MAX_TOTAL_SIZE_MB (10): Total memory budget for all files. 10MB is ~2.5M tokens,
      enough for most projects while preventing OOM on systems with <4GB RAM.
    - MAX_FILE_COUNT (100): Prevents timeout on projects with many small files.
      100 files * 1MB = 100MB worst case, well within limits.
      Can be overridden via COUNCIL_MAX_FILES environment variable.
    - STREAMING_THRESHOLD_MB (50): Auto-enable streaming mode for projects > 50MB.
      Can be overridden via COUNCIL_STREAMING_THRESHOLD_MB environment variable.
    - MAX_CONTEXT_TOKENS (128000): Max context window for modern LLMs.
      DeepSeek: 128K, Mistral: 128K, etc.
    - CONFIDENCE_MIN/MAX (1-10): Standard 10-point scale for review confidence.
    - LOADING_DELAY (0.1): 100ms between spinner frames for smooth animation.
    """
    DEFAULT_MAX_TOKENS: int = 32000
    MAX_FILE_SIZE_MB: int = 1  # Individual file size limit
    MAX_TOTAL_SIZE_MB: int = 10  # Total project size limit
    MAX_FILE_COUNT: int = 100    # Maximum number of files (configurable via env)
    STREAMING_THRESHOLD_MB: int = 50  # Auto-enable streaming (configurable via env)
    MAX_CONTEXT_TOKENS: int = 128000
    CONFIDENCE_MIN: int = 1
    CONFIDENCE_MAX: int = 10
    LOADING_DELAY: float = 0.1  # seconds for loading animation

    TEXT_EXTENSIONS: List[str] | None = None
    DEFAULT_IGNORE_PATTERNS: List[str] | None = None

    @classmethod
    def get_max_file_count(cls) -> int:
        """Get max file count from environment or default."""
        value = os.environ.get('COUNCIL_MAX_FILES')
        if value:
            try:
                return int(value)
            except ValueError:
                pass
        return 100

    @classmethod
    def get_streaming_threshold_mb(cls) -> int:
        """Get streaming threshold from environment or default."""
        value = os.environ.get('COUNCIL_STREAMING_THRESHOLD_MB')
        if value:
            try:
                return int(value)
            except ValueError:
                pass
        return 50
    
    def __post_init__(self):
        if self.TEXT_EXTENSIONS is None:
            object.__setattr__(self, 'TEXT_EXTENSIONS', [
                '.py', '.js', '.jsx', '.ts', '.tsx', '.java', '.cpp', '.c', '.h',
                '.hpp', '.cs', '.go', '.rs', '.rb', '.php', '.swift', '.kt',
                '.scala', '.sh', '.bash', '.zsh', '.sql', '.html', '.css',
                '.scss', '.sass', '.xml', '.json', '.yaml', '.yml', '.toml',
                '.md', '.txt', '.conf', '.cfg', '.ini', '.json'
            ])
        
        if self.DEFAULT_IGNORE_PATTERNS is None:
            object.__setattr__(self, 'DEFAULT_IGNORE_PATTERNS', [
                '__pycache__', '.git', 'config.json', 'node_modules', '.venv', 'venv',
                '.pytest_cache', '.mypy_cache', 'dist', 'build', '.egg-info',
                '.pyc', '.pyo', '.so', '.dylib', '.dll', '.class', '.jar',
                '.min.js', '.min.css', 'package-lock.json', 'yarn.lock',
                '.DS_Store', 'Thumbs.db', '.idea', '.vscode'
            ])


@dataclass
class CriticConfig:
    """Configuration for a code reviewer."""
    name: str
    role: str
    system_prompt: str
    icon: str
    color: str


@dataclass
class CouncilConfig:
    """Configuration for the Code Review Council."""
    api_key: str
    ignore_patterns: List[str]
    critics_dir: Path
    no_color: bool
    verbose: bool
    context_files: Dict[str, str]
    project_path: str
    details: str
    provider: str = "deepseek"
    base_url: str | None = None
    model: str | None = None
    endpoint: str = "/v1/chat/completions"
    use_async: bool = True
    sequential: bool = False
    max_concurrent: int = 10
    timeout: int = 90

    def __post_init__(self):
        """Validate configuration after initialization."""
        if not self.api_key:
            raise ValueError("API key is required")
        if self.critics_dir and not isinstance(self.critics_dir, Path):
            object.__setattr__(self, 'critics_dir', Path(self.critics_dir))

        # base_url is required - should be set by get_provider_config()
        if not self.base_url:
            raise ValueError(
                "base_url is required. Set it in config.json or ensure "
                "get_provider_config() is called to set the default."
            )

        # Provider and model should be set by get_provider_config()
        if not self.model:
            raise ValueError(
                "model is required. Set it in config.json or ensure "
                "get_provider_config() is called to set the default."
            )

        # zai uses a different endpoint path
        if self.provider == "zai":
            object.__setattr__(self, 'endpoint', "/chat/completions")


@dataclass
class CodeRating:
    """Code quality rating from a critic's perspective."""
    score: int  # 1-10 overall rating
    strengths: List[str]  # What the code does well
    weaknesses: List[str]  # What needs improvement
    recommendations: List[str]  # Specific actionable suggestions


@dataclass
class ReviewResult:
    """Result of a single critic's review."""
    critic_name: str
    critic_role: str
    verdict: str
    confidence: int
    review_text: str
    icon: str
    color: str
    rating: CodeRating | None = None  # Detailed code rating


@dataclass
class ConsensusResult:
    """Result of the council's consensus calculation."""
    decision: str
    votes: Dict[str, int]
    unanimous: bool
    majority: bool


@dataclass
class Issue:
    """A single code issue found by a critic.

    Used in map-reduce mode to structure findings for aggregation.
    """
    severity: str  # critical, high, medium, low
    type: str  # security, performance, code_quality, etc.
    file: str
    line: int | None
    function: str | None
    description: str
    cwe: str | None  # For security issues (e.g., "CWE-22")
    recommendation: str

    def __hash__(self) -> int:
        # For deduplication: hash by (severity, type, file, line, description)
        return hash((self.severity, self.type, self.file, self.line, self.description))

    def __eq__(self, other) -> bool:
        if not isinstance(other, Issue):
            return False
        return (self.severity == other.severity and
                self.type == other.type and
                self.file == other.file and
                self.line == other.line and
                self.description == other.description)


@dataclass
class StructuredFindings:
    """Structured findings from a single critic's review of a chunk.

    Produced by parsing JSON output from critics in map-reduce mode.
    """
    critic_name: str
    critic_role: str
    chunk_idx: int
    total_chunks: int
    files_reviewed: List[str]
    findings: Dict[str, List[Issue]]  # {critical: [...], high: [...], ...}
    patterns_found: List[str]
    summary: str
    verdict: str  # APPROVE/REJECT/NEEDS_WORK
    confidence: int


@dataclass
class AggregatedFindings:
    """Deduplicated and grouped findings from all reviews.

    Produced by the aggregation phase of map-reduce.
    """
    by_severity: Dict[str, List[Issue]]
    by_type: Dict[str, List[Issue]]
    by_file: Dict[str, List[Issue]]
    issue_frequency: Dict[str, int]  # For prioritization
    all_patterns: List[str]
    total_files: int
    total_chunks: int


@dataclass
class APIUsageStats:
    """Tracks API usage statistics for a review session."""
    api_calls: int = 0
    input_tokens: int = 0
    output_tokens: int = 0

    @property
    def total_tokens(self) -> int:
        """Total tokens used (input + output)."""
        return self.input_tokens + self.output_tokens

    def add(self, other: 'APIUsageStats') -> None:
        """Add another APIUsageStats to this one."""
        self.api_calls += other.api_calls
        self.input_tokens += other.input_tokens
        self.output_tokens += other.output_tokens


# Global constants instance
CONSTANTS = Constants()