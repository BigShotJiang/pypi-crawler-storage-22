"""
Output formatting, color handling, and display utilities for the Code Review Council.
"""
import time
import threading
import sys
import re
from typing import Any
from .models import ReviewResult, ConsensusResult, APIUsageStats

HAS_PSUTIL = False
try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    pass


class Colors:
    """ANSI color codes for terminal output."""
    RESET = '\033[0m'
    BOLD = '\033[1m'
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'


class NoColors:
    """Color codes disabled (all empty strings)."""
    RESET = ''
    BOLD = ''
    RED = ''
    GREEN = ''
    YELLOW = ''
    BLUE = ''
    MAGENTA = ''
    CYAN = ''
    WHITE = ''


class LoadingAnimator:
    """Handles loading animations for reviews."""
    
    def __init__(self, critic_name: str, icon: str, color_class):
        self.critic_name = critic_name
        self.icon = icon
        self.color_class = color_class
        self.stop_event = threading.Event()
        self.thread = None
    
    def start(self):
        """Start the loading animation."""
        self.thread = threading.Thread(target=self._animate)
        self.thread.start()
    
    def stop(self):
        """Stop the loading animation."""
        self.stop_event.set()
        if self.thread:
            self.thread.join()
    
    def _animate(self):
        """Run the loading animation."""
        spinner = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
        idx = 0
        
        while not self.stop_event.is_set():
            spinner_char = spinner[idx % len(spinner)]
            print(f"\r[{self.icon} {self.critic_name} is reviewing... {spinner_char}]", end='', flush=True)
            idx += 1
            time.sleep(0.1)
        
        print(f"\r[{self.icon} {self.critic_name} is reviewing... ", end='', flush=True)


class OutputFormatter:
    """Handles all output formatting and display."""
    
    def __init__(self, color_class=None):
        self.color_class = color_class or Colors
    
    def print_header(self):
        """Print the application header."""
        print(f"\n{self.color_class.BOLD}{self.color_class.CYAN}{'='*70}{self.color_class.RESET}")
        print(f"{self.color_class.BOLD}{self.color_class.CYAN}           🏛️  CODE REVIEW COUNCIL 🏛️{self.color_class.RESET}")
        print(f"{self.color_class.BOLD}{self.color_class.CYAN}{'='*70}{self.color_class.RESET}\n")
    
    def print_critic_intro(self, critics):
        """Print introduction of all critics."""
        print(f"{self.color_class.BOLD}👥 The Council Members:{self.color_class.RESET}\n")
        for critic in critics:
            print(f"  {critic.icon} {self.color_class.BOLD}{critic.name}{self.color_class.RESET} - {critic.role}")
        print()
    
    def print_review(self, review: ReviewResult):
        """Print a single critic's review."""
        print(f"\n{review.color}{'─'*70}{review.color}")
        print(f"{review.color}{review.icon} {self.color_class.BOLD}{review.critic_name}{self.color_class.RESET}")
        print(f"{review.color}{'─'*70}{review.color}")

        # Display rating if available
        if review.rating:
            rating_color = self._get_rating_color(review.rating.score)
            print(f"\n{self.color_class.BOLD}Code Rating: {rating_color}{review.rating.score}/10{self.color_class.RESET}")

            if review.rating.strengths:
                print(f"\n{self.color_class.GREEN}✓ Strengths:{self.color_class.RESET}")
                for strength in review.rating.strengths:
                    print(f"  • {strength}")

            if review.rating.weaknesses:
                print(f"\n{self.color_class.RED}✗ Weaknesses:{self.color_class.RESET}")
                for weakness in review.rating.weaknesses:
                    print(f"  • {weakness}")

            if review.rating.recommendations:
                print(f"\n{self.color_class.CYAN}→ Recommendations:{self.color_class.RESET}")
                for rec in review.rating.recommendations:
                    print(f"  • {rec}")

        print(f"\n{review.review_text}")
        print()

    def _get_rating_color(self, score: int):
        """Get color for rating score display."""
        return (self.color_class.GREEN if score >= 8 else
                self.color_class.YELLOW if score >= 6 else
                self.color_class.RED)
    
    def print_consensus(self, consensus: ConsensusResult, reviews: list[ReviewResult]):
        """Print the final consensus decision."""
        print(f"\n{self.color_class.BOLD}{'='*70}{self.color_class.RESET}")
        print(f"{self.color_class.BOLD}⚖️  COUNCIL DECISION ⚖️{self.color_class.RESET}")
        print(f"{self.color_class.BOLD}{'='*70}{self.color_class.RESET}\n")

        print(f"{self.color_class.BOLD}Individual Votes:{self.color_class.RESET}")
        for review in reviews:
            verdict_color = self._get_verdict_color(review.verdict)
            rating_str = f" | Rating: {self._get_rating_display(review)}" if review.rating else ""
            print(f"  {review.icon} {review.critic_name}: {verdict_color}{review.verdict}{self.color_class.RESET} "
                  f"({review.confidence}/10){rating_str}")

        print()
        self._print_decision_summary(consensus)

        # Print overall ratings summary
        self._print_ratings_summary(reviews)
        print()

    def print_consensus_minimal(self, consensus: ConsensusResult, reviews: list[ReviewResult]):
        """Print minimal consensus - just the final decision."""
        print(f"\n{self.color_class.BOLD}{'='*70}{self.color_class.RESET}")
        print(f"{self.color_class.BOLD}⚖️  COUNCIL DECISION ⚖️{self.color_class.RESET}")
        print(f"{self.color_class.BOLD}{'='*70}{self.color_class.RESET}\n")

        self._print_decision_summary(consensus)
        print()

    def _get_rating_display(self, review: ReviewResult) -> str:
        """Get formatted rating display string."""
        if not review.rating:
            return ""
        color = self._get_rating_color(review.rating.score)
        return f"{color}{review.rating.score}/10{self.color_class.RESET}"

    def _print_ratings_summary(self, reviews: list[ReviewResult]):
        """Print summary of all ratings."""
        reviews_with_ratings = [r for r in reviews if r.rating]
        if not reviews_with_ratings:
            return

        print(f"\n{self.color_class.BOLD}📊 Code Ratings Summary:{self.color_class.RESET}")
        for review in reviews_with_ratings:
            rating_color = self._get_rating_color(review.rating.score)
            print(f"  {review.icon} {review.critic_name}: {rating_color}{review.rating.score}/10{self.color_class.RESET}")
    
    def _get_verdict_color(self, verdict: str):
        """Get color for verdict display."""
        return (self.color_class.GREEN if verdict == 'APPROVE' else
                self.color_class.RED if verdict == 'REJECT' else
                self.color_class.YELLOW)
    
    def _print_decision_summary(self, consensus: ConsensusResult):
        """Print the decision summary based on consensus."""
        decision = consensus.decision
        color = self._get_verdict_color(decision.replace('ED', '').replace('JECT', '').replace('PROV', '').replace('NEEDS_', ''))
        
        if consensus.unanimous:
            status = "UNANIMOUS"
        elif consensus.majority:
            status = "MAJORITY"
        else:
            status = "NO CONSENSUS"
            color = self.color_class.MAGENTA
        
        print(f"{self.color_class.BOLD}{color}{'='*70}{self.color_class.RESET}")
        print(f"{self.color_class.BOLD}{color}⚖️  {status} {decision} ⚖️{self.color_class.RESET}")
        
        # Print description
        if consensus.unanimous:
            descriptions = {
                'APPROVED': "All three critics agree: Code is ready for production!",
                'REJECTED': "All three critics agree: Critical issues must be fixed!",
                'NEEDS_WORK': "All three critics agree: Significant improvements needed!"
            }
        elif consensus.majority:
            descriptions = {
                'APPROVED': "Council approves with some reservations.",
                'REJECTED': "Council rejects with strong concerns.",
                'NEEDS_WORK': "Council agrees improvements are needed."
            }
        else:
            descriptions = {'ALL': "The council is split. Further discussion needed."}
        
        if consensus.unanimous or consensus.majority:
            desc = descriptions.get(decision, "Unknown decision.")
        else:
            desc = descriptions['ALL']
        
        print(f"{color}{desc}{self.color_class.RESET}")
        print(f"{self.color_class.BOLD}{color}{'='*70}{self.color_class.RESET}")
    
    def print_success(self, files_count: int, context_count: int = 0):
        """Print success message for file collection."""
        print(f"\n{self.color_class.GREEN}✓ Found {files_count} file(s) to review{self.color_class.RESET}")
        if context_count > 0:
            print(f"{self.color_class.GREEN}✓ Loaded {context_count} context file(s){self.color_class.RESET}")
        print()
    
    def print_progress(self, current: int, total: int, message: str = "Processing"):
        """Print progress indicator."""
        percent = (current / total) * 100 if total > 0 else 0
        bar_length = 30
        filled_length = int(bar_length * current // total)
        bar = '█' * filled_length + '░' * (bar_length - filled_length)
        
        sys.stdout.write(f"\r{self.color_class.CYAN}[{bar}] {percent:.1f}% - {message} ({current}/{total}){self.color_class.RESET}")
        sys.stdout.flush()
        
        if current == total:
            print()
    
    def print_memory_warning(self, memory_usage_mb: float, threshold_mb: float = 500):
        """Print memory usage warning."""
        if memory_usage_mb > threshold_mb:
            print(f"{self.color_class.YELLOW}⚠ Memory usage: {memory_usage_mb:.1f}MB (consider using --chunk-size or --no-chunking){self.color_class.RESET}")
    
    def get_memory_usage(self) -> float:
        """Get current memory usage in MB."""
        if not HAS_PSUTIL:
            return 0.0
        try:
            import psutil
            process = psutil.Process()
            memory_info = process.memory_info()
            return memory_info.rss / (1024 * 1024)  # Convert to MB
        except:
            return 0.0
    
    def print_context_info(self, context_files: dict, details: str):
        """Print context information."""
        if context_files:
            print(f"{self.color_class.CYAN}📖 Reviewers will consider the provided context files{self.color_class.RESET}")
        if details:
            print(f"{self.color_class.CYAN}💡 Special instructions: {details}{self.color_class.RESET}")
    
    def print_deliberating(self):
        """Print deliberation message with loading animation."""
        print(f"\n{self.color_class.BOLD}🔄 Council is deliberating...{self.color_class.RESET}")
        self._show_loading_animation("Preparing reviews")
        print()
    
    def _show_loading_animation(self, message: str, duration: float = 1.5):
        """Show a simple loading animation."""
        spinner = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
        end_time = time.time() + duration
        idx = 0
        
        while time.time() < end_time:
            spinner_char = spinner[idx % len(spinner)]
            print(f"\r{spinner_char} {message}...", end='', flush=True)
            idx += 1
            time.sleep(0.1)
        
        print(f"\r✓ {message} complete      ", end='')
        time.sleep(0.2)
    
    def print_reviews_header(self):
        """Print header for individual reviews."""
        print(f"\n{self.color_class.BOLD}📋 Individual Reviews:{self.color_class.RESET}")
    
    def print_save_success(self, session_dir, reviews_count: int = 0):
        """Print success message for saving results."""
        total_files = reviews_count + 1  # reviews + consensus.md
        print(f"\n{self.color_class.CYAN}💾 Results saved to {session_dir}/\n")
        print(f"   📄 Individual reviews: {reviews_count} files")
        print(f"   📊 Consensus summary: consensus.md")
        print(f"   📁 Total files: {total_files} in session folder{self.color_class.RESET}")
    
    def print_error(self, error_type: str, message: str):
        """Print error message."""
        color_map = {
            'Configuration': self.color_class.RED,
            'API': self.color_class.RED,
            'File': self.color_class.RED,
            'Unexpected': self.color_class.RED,
            'Warning': self.color_class.YELLOW
        }
        color = color_map.get(error_type, self.color_class.RED)
        print(f"{color}{error_type} Error: {message}{self.color_class.RESET}")
    
    def print_warning(self, message: str):
        """Print warning message."""
        print(f"{self.color_class.YELLOW}Warning: {message}{self.color_class.RESET}")

    def print_info(self, message: str):
        """Print info message."""
        print(f"{self.color_class.CYAN}{message}{self.color_class.RESET}")

    def print_api_usage_summary(self, stats: APIUsageStats):
        """Print API usage summary with calls and token counts."""
        print(f"\n{self.color_class.BOLD}{self.color_class.CYAN}{'='*70}{self.color_class.RESET}")
        print(f"{self.color_class.BOLD}{self.color_class.CYAN}📊 API Usage Summary{self.color_class.RESET}")
        print(f"{self.color_class.BOLD}{self.color_class.CYAN}{'='*70}{self.color_class.RESET}\n")

        print(f"{self.color_class.BOLD}📞 API Calls Made:{self.color_class.RESET} {stats.api_calls}")
        print(f"{self.color_class.BOLD}📥 Input Tokens:{self.color_class.RESET} {stats.input_tokens:,}")
        print(f"{self.color_class.BOLD}📤 Output Tokens:{self.color_class.RESET} {stats.output_tokens:,}")
        print(f"{self.color_class.BOLD}{self.color_class.CYAN}🔄 Total Tokens:{self.color_class.RESET} {stats.total_tokens:,}\n")


# ANSI escape sequence pattern for terminal injection prevention
# Matches: \x1B followed by any escape sequence
# Examples: \x1B[31m (red), \x1B[2J (clear screen), \x1B[0K (clear line)
ANSI_ESCAPE_PATTERN = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')


def sanitize_path_for_display(filepath: str) -> str:
    """
    Sanitize a file path for safe terminal display.

    Prevents terminal injection attacks by removing ANSI escape codes
    and control characters that could manipulate terminal output.

    Args:
        filepath: The file path to sanitize

    Returns:
        Sanitized path safe for terminal display

    Examples:
        >>> sanitize_path_for_display("test.py")
        'test.py'
        >>> sanitize_path_for_display("\x1B[31mmalicious\x1B[0m.py")
        'malicious.py'
        >>> sanitize_path_for_display("file\x1B[2J.py")
        'file.py'
    """
    # Remove ANSI escape sequences
    sanitized = ANSI_ESCAPE_PATTERN.sub('', filepath)

    # Remove control characters except newline, tab, and common whitespace
    # Keep: \t (0x09), \n (0x0A), \r (0x0D)
    # Remove: All other control characters (0x00-0x08, 0x0B-0x0C, 0x0E-0x1F)
    sanitized = ''.join(
        char for char in sanitized
        if char == '\t' or char == '\n' or char == '\r' or
        (ord(char) >= 32 and ord(char) != 127)  # Printable ASCII + DEL removal
    )

    return sanitized
