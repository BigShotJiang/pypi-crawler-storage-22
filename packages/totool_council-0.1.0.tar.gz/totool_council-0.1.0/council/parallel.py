"""
Parallel processing utilities for Code Review Council.
"""
import concurrent.futures
import os
import threading
from typing import Dict, List, Any, Callable, Generator, Tuple, Optional
from pathlib import Path
from .files import FileCollector
from .output import OutputFormatter, sanitize_path_for_display
from .secret_scanner import SecretScanner
from .formatters import ReviewFormatter
from .exceptions import FileError


class ThreadSafeCounter:
    """Lock-free counter using atomic operations for thread-safe increments."""

    def __init__(self, initial_value: int = 0):
        self._value = initial_value
        self._lock = threading.Lock()

    def increment(self, delta: int = 1) -> int:
        """Increment and return new value (uses lock but only for brief moment)."""
        with self._lock:
            self._value += delta
            return self._value

    def get(self) -> int:
        """Get current value."""
        return self._value

    def would_exceed(self, addition: int, limit: int) -> bool:
        """Check if adding would exceed limit (atomic check)."""
        with self._lock:
            return self._value + addition > limit

    def try_increment(self, addition: int, limit: int) -> bool:
        """
        Atomically check if increment would exceed limit, and increment if it won't.

        Returns:
            True if increment was successful (within limit), False otherwise

        This prevents TOCTOU (Time-Of-Check-Time-Of-Use) race conditions by
        making the check-and-act operation atomic.
        """
        with self._lock:
            if self._value + addition > limit:
                return False
            self._value += addition
            return True


class ParallelFileCollector(FileCollector):
    """File collector with parallel processing capabilities."""

    def __init__(self, ignore_patterns: List[str], output_formatter: OutputFormatter,
                 max_workers: int = 4):
        super().__init__(ignore_patterns, output_formatter)
        self.max_workers = max_workers
        # Shared counters with minimal locking
        self._total_size_counter = ThreadSafeCounter(0)
        self._file_count_counter = ThreadSafeCounter(0)
        # Thread-safe storage for metadata
        self._metadata_lock = threading.Lock()
        self._files_metadata: Dict[str, Tuple[int, float]] = {}

    def collect_project_files_parallel(self, path: str) -> Tuple[Dict[str, str], Dict[str, Tuple[int, float]]]:
        """
        Collect files in parallel using thread pool.

        Returns:
            Tuple of (files_content, files_metadata)
        """
        files_content = {}
        self._files_metadata = {}
        # Reset counters
        self._total_size_counter = ThreadSafeCounter(0)
        self._file_count_counter = ThreadSafeCounter(0)

        # Single file
        if os.path.isfile(path):
            return super().collect_project_files(path)

        # Directory
        if not os.path.isdir(path):
            raise FileError(f"Path does not exist: {path}")

        # Collect all file paths first
        all_filepaths = []
        for root, dirs, files in os.walk(path):
            # Filter out ignored directories
            dirs[:] = [d for d in dirs if not self._should_ignore_file(os.path.join(root, d))]

            for file in files:
                filepath = os.path.join(root, file)
                relative_path = os.path.relpath(filepath, path)

                if self._should_ignore_file(filepath):
                    continue

                if not self._is_text_file(filepath):
                    continue

                all_filepaths.append((relative_path, filepath))

        # Process files in parallel
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit all tasks
            future_to_path = {}
            for relative_path, filepath in all_filepaths:
                future = executor.submit(self._read_file_parallel, filepath, relative_path)
                future_to_path[future] = (relative_path, filepath)

            # Process results as they complete
            completed = 0
            total = len(all_filepaths)

            for future in concurrent.futures.as_completed(future_to_path):
                relative_path, filepath = future_to_path[future]
                completed += 1

                try:
                    result = future.result()
                    if result is not None:
                        content, file_size, file_mtime = result
                        files_content[relative_path] = content
                        with self._metadata_lock:
                            self._files_metadata[relative_path] = (file_size, file_mtime)
                except Exception as e:
                    self.output_formatter.print_warning(f"⚠ {sanitize_path_for_display(relative_path)} (error: {e})")

        return files_content, self._files_metadata
    
    def process_files_streaming(self, path: str) -> Generator[Tuple[str, str, int, float], None, None]:
        """
        Process files using streaming to avoid loading all files into memory.
        
        Yields:
            Tuples of (relative_path, content, file_size, file_mtime)
        """
        # Single file
        if os.path.isfile(path):
            if not self._should_ignore_file(path) and self._is_text_file(path):
                try:
                    result = self._read_file_with_size_check(path)
                    if result is not None:
                        content, file_size, file_mtime = result
                        yield path, content, file_size, file_mtime
                except Exception as e:
                    self.output_formatter.print_warning(f"Could not read {sanitize_path_for_display(path)}: {e}")
            return
        
        # Directory
        if not os.path.isdir(path):
            raise FileError(f"Path does not exist: {path}")

        # Use the parent class's streaming method
        for relative_path, content, file_size, file_mtime in super().collect_project_files_streaming(path):
            yield relative_path, content, file_size, file_mtime
    
    def _read_file_parallel(self, filepath: str, relative_path: str) -> Optional[Tuple[str, int, float]]:
        """
        Read file with thread-safe size checking.

        Uses atomic counter operations instead of global lock,
        allowing true parallelism.

        Returns:
            Tuple of (content, file_size, file_mtime) or None if file should be skipped
        """
        try:
            # Scan filename for sensitive patterns BEFORE reading
            SecretScanner.scan_filename(filepath)

            # Check file size and mtime in one stat call
            stat = os.stat(filepath)
            file_size = stat.st_size
            file_mtime = stat.st_mtime
            from .models import CONSTANTS
            max_file_size_mb = CONSTANTS.MAX_FILE_SIZE_MB
            max_total_size_mb = CONSTANTS.MAX_TOTAL_SIZE_MB
            max_file_count = CONSTANTS.MAX_FILE_COUNT

            # Check individual file size (no lock needed)
            if file_size > max_file_size_mb * 1024 * 1024:
                return None

            # Check file count (atomic check)
            if self._file_count_counter.get() >= max_file_count:
                return None

            # Atomically check and increment total size to prevent race condition
            if not self._total_size_counter.try_increment(file_size, max_total_size_mb * 1024 * 1024):
                return None

            # Read file (I/O bound - parallelizable)
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
                if content.strip():  # Only include non-empty files
                    # Scan content for secrets AFTER reading
                    SecretScanner.scan_file_content(filepath, content)

                    # Increment file count atomically
                    self._file_count_counter.increment(1)
                    return content, file_size, file_mtime
                else:
                    # Rollback the size increment since file is empty
                    self._total_size_counter.increment(-file_size)
                    return None

        except Exception as read_error:
            # CRITICAL: Rollback size increment if read fails
            # This prevents counter leak when exceptions occur after try_increment
            try:
                stat = os.stat(filepath)
                file_size = stat.st_size
                self._total_size_counter.increment(-file_size)
            except:
                pass  # Ignore errors during rollback
            raise read_error


class ParallelReviewRunner:
    """Run reviews in parallel for different chunks."""
    
    def __init__(self, review_runner, output_formatter: OutputFormatter, max_workers: int = 3):
        self.review_runner = review_runner
        self.output_formatter = output_formatter
        self.max_workers = max_workers
    
    def run_parallel_reviews(self, critics: List[Any], chunks: List[Dict[str, str]],
                           context_files: Dict[str, str], details: str,
                           verbose: bool = False) -> List[Any]:
        """Run reviews for chunks in parallel."""
        if len(chunks) <= 1:
            # No benefit to parallelization for single chunk
            return self.review_runner.run_chunked_reviews(
                critics, chunks, context_files, details, verbose
            )

        all_results = []

        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit all chunk reviews
            future_to_chunk = {}
            for chunk_idx, chunk in enumerate(chunks, 1):
                future = executor.submit(
                    self._review_chunk_parallel,
                    critics, chunk, chunk_idx, len(chunks),
                    context_files if chunk_idx == 1 else {}, details, verbose
                )
                future_to_chunk[future] = chunk_idx

            # Process results as they complete
            for future in concurrent.futures.as_completed(future_to_chunk):
                try:
                    chunk_results = future.result()
                    all_results.extend(chunk_results)
                except Exception as e:
                    self.output_formatter.print_warning(f"Chunk failed: {e}")

        return all_results
    
    def _review_chunk_parallel(self, critics: List[Any], chunk: Dict[str, str],
                             chunk_idx: int, total_chunks: int,
                             context_files: Dict[str, str], details: str,
                             verbose: bool) -> List[Any]:
        """Review a single chunk (to be run in parallel)."""
        # Use centralized review formatter
        chunk_content = ReviewFormatter.format_chunk_content(
            chunk=chunk,
            chunk_idx=chunk_idx,
            total_chunks=total_chunks,
            context_files=context_files if chunk_idx == 1 else None,
            details=details
        )

        is_multi_file = len(chunk) > 1
        return self.review_runner.run_reviews(critics, chunk_content, is_multi_file, verbose)


class ParallelProcessor:
    """Generic parallel processor for various tasks."""
    
    @staticmethod
    def process_in_parallel(items: List[Any], process_func: Callable, 
                          max_workers: int = 4, description: str = "Processing") -> List[Any]:
        """Process items in parallel using a processing function."""
        results = []
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all tasks
            future_to_item = {executor.submit(process_func, item): item for item in items}
            
            # Process results
            completed = 0
            total = len(items)
            
            for future in concurrent.futures.as_completed(future_to_item):
                item = future_to_item[future]
                completed += 1
                
                try:
                    result = future.result()
                    results.append(result)
                except Exception as e:
                    print(f"Error processing item {item}: {e}")
                
                # Show progress
                if total > 5:
                    percent = (completed / total) * 100
                    print(f"\r{description}: {percent:.1f}% ({completed}/{total})", end='')
            
            if total > 5:
                print()  # New line after progress
        
        return results