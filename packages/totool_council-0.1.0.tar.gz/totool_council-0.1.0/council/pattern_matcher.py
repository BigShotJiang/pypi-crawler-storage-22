"""
Pattern matching utilities for file ignore patterns.

This module handles efficient pattern matching for ignore patterns,
including pre-compiled regex, caching, and multiple pattern types.
"""
import fnmatch
import os
import re
from pathlib import Path
from typing import List, Set, Tuple, Optional

from council.models import CONSTANTS


class PatternMatcher:
    """
    Handles efficient pattern matching for file ignore patterns.

    Uses pre-compiled regex patterns for performance and supports:
    - O(1) set lookups for exact and directory patterns
    - O(m) regex matching for wildcard patterns (m = number of wildcards)
    - Instance-level caching to avoid re-checking the same files
    """

    # Cache size limit to prevent unbounded growth
    _MAX_CACHE_SIZE = 10000

    def __init__(self, ignore_patterns: Optional[List[str]] = None):
        """
        Initialize the pattern matcher.

        Args:
            ignore_patterns: Additional ignore patterns beyond defaults
        """
        self.ignore_patterns = ignore_patterns or []

        self._exact_patterns: Set[str] = set()
        self._wildcard_patterns: List[Tuple[str, Optional[re.Pattern]]] = []
        self._directory_patterns: Set[str] = set()

        # Instance-level cache for ignore results
        self._ignore_cache: dict = {}

        # Initialize patterns
        self._initialize_patterns()

    def _compile_single_pattern(self, pattern: str) -> Optional[re.Pattern]:
        """
        Compile a single fnmatch pattern to regex.

        Args:
            pattern: The pattern to compile

        Returns:
            Compiled regex pattern or None if compilation fails
        """
        try:
            regex_pattern = fnmatch.translate(pattern.lower())
            return re.compile(regex_pattern)
        except re.error:
            return None

    def _initialize_patterns(self) -> None:
        """Initialize and categorize all patterns."""
        all_patterns = (CONSTANTS.DEFAULT_IGNORE_PATTERNS or []) + self.ignore_patterns

        for pattern in all_patterns:
            pattern_lower = pattern.lower()

            if '*' in pattern:
                # Wildcard pattern - compile to regex
                self._wildcard_patterns.append(
                    (pattern_lower, self._compile_single_pattern(pattern_lower))
                )
            elif pattern_lower.endswith('/'):
                # Directory pattern
                self._directory_patterns.add(pattern_lower.rstrip('/'))
            else:
                # Exact match pattern
                self._exact_patterns.add(pattern_lower)

    def should_ignore_file(self, filepath: str) -> bool:
        """
        Check if file should be ignored based on patterns.

        Args:
            filepath: Absolute or relative path to the file

        Returns:
            True if file should be ignored, False otherwise
        """
        # Check cache first
        if filepath in self._ignore_cache:
            return self._ignore_cache[filepath]

        filepath_lower = filepath.lower()
        path_parts = Path(filepath).parts
        filename_lower = os.path.basename(filepath).lower()

        # Check exact patterns first (fastest - O(1) lookup)
        if filename_lower in self._exact_patterns:
            self._cache_ignore_result(filepath, True)
            return True

        # Check directory patterns AND exact patterns against path components
        # This ensures patterns like ".git" match ".git/config" (not just "config")
        for component in path_parts:
            component_lower = component.lower()
            if component_lower in self._directory_patterns or component_lower in self._exact_patterns:
                self._cache_ignore_result(filepath, True)
                return True

        # Check wildcard patterns (slower - requires regex matching)
        for pattern_lower, compiled in self._wildcard_patterns:
            if compiled is not None:
                if compiled.match(filepath_lower) or compiled.match(filename_lower):
                    self._cache_ignore_result(filepath, True)
                    return True

        self._cache_ignore_result(filepath, False)
        return False

    def _cache_ignore_result(self, filepath: str, should_ignore: bool) -> None:
        """
        Cache the ignore result for a file path.

        Args:
            filepath: The file path to cache
            should_ignore: Whether the file should be ignored
        """
        # Limit cache size to prevent unbounded growth
        if len(self._ignore_cache) >= self._MAX_CACHE_SIZE:
            self._ignore_cache = {}
        self._ignore_cache[filepath] = should_ignore

    def _matches_exact_component(
        self,
        path_parts: tuple,
        pattern: str
    ) -> bool:
        """
        Check if any path component exactly matches the pattern.

        Component-wise matching prevents substring matching vulnerabilities
        (e.g., pattern ".git" matches ".git/config" but not "mygitfile").

        Args:
            path_parts: Tuple of path components
            pattern: The pattern to match against (non-wildcard)

        Returns:
            True if any component matches exactly, False otherwise
        """
        if '*' in pattern:
            return False

        pattern_lower = pattern.lower().rstrip('/')
        return any(
            component.lower() == pattern_lower
            for component in path_parts
        )

    def _matches_wildcard_pattern(
        self,
        filepath_lower: str,
        filename: str,
        pattern: str,
        compiled: Optional[re.Pattern]
    ) -> bool:
        """
        Check if file matches a wildcard pattern using pre-compiled regex.

        Args:
            filepath_lower: Lowercase filepath
            filename: Filename to check
            pattern: The wildcard pattern
            compiled: Pre-compiled regex pattern

        Returns:
            True if file matches the wildcard pattern, False otherwise
        """
        if not pattern or '*' not in pattern or compiled is None:
            return False

        return (
            compiled.match(filepath_lower) is not None or
            compiled.match(filename.lower()) is not None
        )

    def _matches_exact_filename(
        self,
        filename: str,
        pattern: str
    ) -> bool:
        """
        Check if filename exactly matches the pattern.

        Args:
            filename: Filename to check
            pattern: The pattern to match against

        Returns:
            True if filename matches exactly, False otherwise
        """
        return pattern.lower() == filename.lower()

    def matches_pattern(
        self,
        filepath_lower: str,
        filename: str,
        path_parts: tuple,
        pattern: str,
        compiled: Optional[re.Pattern]
    ) -> bool:
        """
        Check if a file matches a specific ignore pattern.

        Args:
            filepath_lower: Lowercase filepath
            filename: Filename to check
            path_parts: Tuple of path components
            pattern: The pattern to match against
            compiled: Pre-compiled regex pattern (if wildcard)

        Returns:
            True if file matches the pattern, False otherwise
        """
        if self._matches_exact_component(path_parts, pattern):
            return True

        if self._matches_wildcard_pattern(filepath_lower, filename, pattern, compiled):
            return True

        if self._matches_exact_filename(filename, pattern):
            return True

        return False

    def clear_cache(self) -> None:
        """Clear the ignore result cache."""
        self._ignore_cache = {}
