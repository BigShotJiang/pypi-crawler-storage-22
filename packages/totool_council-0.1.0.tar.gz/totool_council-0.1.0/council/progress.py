"""
Progress tracking for long-running operations.

This module provides a progress callback protocol for tracking progress
during file collection, chunking, and review operations.

PHASE 4 (Low Priority): Add Progress Callback for Long Operations

Large projects show no progress for minutes. This module solves that by:
1. Defining a ProgressCallback protocol for progress reporting
2. Providing ConsoleProgressReporter for terminal output
3. Integrating callbacks into the file collection pipeline

Usage:
    # Create a progress reporter
    reporter = ConsoleProgressReporter(verbose=True)

    # Use in file collection
    def collect_files(path, progress=None):
        if progress:
            progress(0, 100, "Scanning files...")
        # ... collection logic
        if progress:
            progress(100, 100, "Done")
"""
from typing import Protocol, Optional, Callable
from enum import Enum


class ProgressStage(Enum):
    """Stages of the review process for progress tracking."""
    SCANNING = "Scanning"
    LOADING = "Loading"
    DEDUPLICATING = "Deduplicating"
    CHUNKING = "Chunking"
    REVIEWING = "Reviewing"
    SAVING = "Saving"
    COMPLETE = "Complete"


class ProgressCallback(Protocol):
    """
    Protocol for progress callbacks during long operations.

    This allows the UI to show progress to users during operations that
    may take minutes on large projects.

    The callback receives:
    - current: Current progress value (items processed, bytes loaded, etc.)
    - total: Total expected value (None if unknown)
    - message: Human-readable status message

    Example implementations:
    - ConsoleProgressReporter: Prints to terminal with percentage
    - TQDMProgressReporter: Uses tqdm progress bars
    - NullProgressCallback: No-op for testing/silent mode
    """

    def __call__(self, current: int, total: Optional[int], message: str, stage: ProgressStage = ProgressStage.LOADING) -> None:
        """
        Report progress.

        Args:
            current: Current progress value (e.g., files processed, bytes loaded)
            total: Total expected value, or None if unknown
            message: Human-readable status message
            stage: Current stage of operation
        """
        ...


class ConsoleProgressReporter:
    """
    Console-based progress reporter.

    Shows progress as: "[STAGE] Message: 50/100 (50%)"
    """

    def __init__(self, verbose: bool = True, show_percentage: bool = True):
        """
        Initialize console progress reporter.

        Args:
            verbose: Whether to print progress messages
            show_percentage: Whether to show percentage (only if total is known)
        """
        self.verbose = verbose
        self.show_percentage = show_percentage
        self._last_line = ""

    def __call__(self, current: int, total: Optional[int], message: str, stage: ProgressStage = ProgressStage.LOADING) -> None:
        """
        Report progress to console.

        Args:
            current: Current progress value
            total: Total expected value, or None if unknown
            message: Human-readable status message
            stage: Current stage of operation
        """
        if not self.verbose:
            return

        # Build progress string
        if total is not None and total > 0:
            percentage = (current / total) * 100
            if self.show_percentage:
                progress_str = f"{current}/{total} ({percentage:.1f}%)"
            else:
                progress_str = f"{current}/{total}"
        else:
            progress_str = f"{current} files"

        line = f"[{stage.value}] {message}: {progress_str}"

        # Only print if line changed (reduce flicker)
        if line != self._last_line:
            # Clear previous line by overwriting with spaces
            if self._last_line:
                print(f"\r{' ' * len(self._last_line)}\r", end="", flush=True)
            print(f"\r{line}", end="", flush=True)
            self._last_line = line

    def finish(self, message: str = "Done") -> None:
        """Print final message and move to next line."""
        if self.verbose and self._last_line:
            print(f"\r{self._last_line} - {message}")
            self._last_line = ""


class NullProgressCallback:
    """
    No-op progress callback for testing and silent operation.

    This is useful when you want to disable progress reporting entirely.
    """

    def __call__(self, current: int, total: Optional[int], message: str, stage: ProgressStage = ProgressStage.LOADING) -> None:
        """No-op callback."""
        pass


# Global default null callback for when no progress reporting is desired
NULL_PROGRESS: ProgressCallback = NullProgressCallback()


class ProgressTracker:
    """
    Helper class for tracking progress with automatic reporting.

    Wraps a ProgressCallback and provides convenient methods for
    incrementing progress and updating messages.
    """

    def __init__(self, callback: ProgressCallback = NULL_PROGRESS):
        """
        Initialize progress tracker.

        Args:
            callback: Progress callback to use for reporting
        """
        self.callback = callback
        self._current = 0
        self._total = None
        self._stage = ProgressStage.LOADING

    def set_total(self, total: int) -> None:
        """Set total expected value."""
        self._total = total
        self._current = 0

    def set_stage(self, stage: ProgressStage) -> None:
        """Set current stage."""
        self._stage = stage

    def update(self, message: str, increment: int = 1) -> None:
        """
        Increment progress and report.

        Args:
            message: Status message
            increment: Amount to increment by (default: 1)
        """
        self._current += increment
        self.callback(self._current, self._total, message, self._stage)

    def set_current(self, current: int, message: str) -> None:
        """
        Set current progress value and report.

        Args:
            current: New current value
            message: Status message
        """
        self._current = current
        self.callback(self._current, self._total, message, self._stage)

    def finish(self, message: str = "Done") -> None:
        """
        Finish progress tracking.

        Args:
            message: Final status message
        """
        self._current = self._total or self._current
        self.callback(self._current, self._total, message, ProgressStage.COMPLETE)
        if isinstance(self.callback, ConsoleProgressReporter):
            self.callback.finish(message)


def make_progress_callback(
    verbose: bool = True,
    show_percentage: bool = True,
    custom_callback: Optional[ProgressCallback] = None
) -> ProgressCallback:
    """
    Factory function for creating progress callbacks.

    Args:
        verbose: Whether to print progress messages (ignored if custom_callback provided)
        show_percentage: Whether to show percentage (ignored if custom_callback provided)
        custom_callback: Optional custom callback to use instead of ConsoleProgressReporter

    Returns:
        A progress callback instance
    """
    if custom_callback is not None:
        return custom_callback

    if verbose:
        return ConsoleProgressReporter(verbose=verbose, show_percentage=show_percentage)

    return NULL_PROGRESS
