"""
Review processing and consensus calculation for Code Review Council.
"""
import os
import re
import time
import threading
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from .models import CriticConfig, ReviewResult, ConsensusResult, CONSTANTS, CodeRating, APIUsageStats
from .exceptions import FileError, APIError
from .output import Colors, NoColors, LoadingAnimator
from .formatters import ReviewFormatter
from .security import SecurityValidator


class ReviewParser:
    """Handles parsing of review text to extract verdict, confidence, and rating."""

    # FIX-010: More flexible pattern accepting common verdict variations.
    # Handles typos and alternative phrasings like "APPROVED", "REJECTED", "NEEDS IMPROVEMENT".
    # Uses case-insensitive matching and normalizes to canonical form via _VERDICT_NORMALIZATION.
    _verdict_pattern = re.compile(
        r'VERDICT:\s*'
        r'(APPROVE(?:D|ED)?|REJECT(?:ED)?|NEEDS_WORK|NEEDS\s+(?:IMPROVEMENT|WORK))',
        re.IGNORECASE
    )

    # FIX-010: Normalize verdict variations to canonical forms (present tense).
    # This allows the parser to handle common typos and variations in AI responses.
    _VERDICT_NORMALIZATION = {
        'APPROVED': 'APPROVE',
        'APPROVEDED': 'APPROVE',  # Handle typo
        'REJECTED': 'REJECT',
        'NEEDS IMPROVEMENT': 'NEEDS_WORK',
        'NEEDS WORK': 'NEEDS_WORK',
    }

    # Pre-compile regex patterns for performance (O(1) lookup vs O(n) scan)
    _confidence_pattern = re.compile(r'CONFIDENCE:\s*(\d+)', re.IGNORECASE)
    _rating_score_pattern = re.compile(r'RATING:\s*(\d+)', re.IGNORECASE)
    _strengths_pattern = re.compile(r'STRENGTHS:\s*(.*?)(?=\n\s*\n|\nWEAKNESSES:|\nRECOMMENDATIONS:|\Z)', re.IGNORECASE | re.DOTALL)
    _weaknesses_pattern = re.compile(r'WEAKNESSES:\s*(.*?)(?=\n\s*\n|\nRECOMMENDATIONS:|\nSTRENGTHS:|\Z)', re.IGNORECASE | re.DOTALL)
    _recommendations_pattern = re.compile(r'RECOMMENDATIONS:\s*(.*?)(?=\n\s*\n|\nSTRENGTHS:|\nWEAKNESSES:|\Z)', re.IGNORECASE | re.DOTALL)

    @staticmethod
    def parse_review(review_text: str) -> tuple[str, int, Optional[CodeRating]]:
        """Parse the review text to extract verdict, confidence, and rating."""
        verdict = "NEEDS_WORK"
        confidence = 5

        # Use regex to find verdict (single pass, no line iteration)
        verdict_match = ReviewParser._verdict_pattern.search(review_text)
        if verdict_match:
            raw_verdict = verdict_match.group(1).upper()
            # FIX-010: Normalize to canonical form using the normalization mapping
            verdict = ReviewParser._VERDICT_NORMALIZATION.get(raw_verdict, raw_verdict)

        # Use regex to find confidence
        confidence_match = ReviewParser._confidence_pattern.search(review_text)
        if confidence_match:
            try:
                from .utils import clamp_value
                extracted_confidence = int(confidence_match.group(1))
                confidence = clamp_value(extracted_confidence, CONSTANTS.CONFIDENCE_MIN, CONSTANTS.CONFIDENCE_MAX)
            except (ValueError, IndexError):
                confidence = 5

        # Parse rating
        rating = ReviewParser._parse_rating(review_text)

        return verdict, confidence, rating

    @staticmethod
    def _parse_rating(review_text: str) -> Optional[CodeRating]:
        """Parse rating information from review text."""
        try:
            from .utils import clamp_value

            # Extract rating score
            score = 5  # default
            score_match = ReviewParser._rating_score_pattern.search(review_text)
            if score_match:
                score = clamp_value(int(score_match.group(1)), CONSTANTS.CONFIDENCE_MIN, CONSTANTS.CONFIDENCE_MAX)
            else:
                # If no explicit rating, return None
                return None

            # Extract strengths
            strengths = []
            strengths_match = ReviewParser._strengths_pattern.search(review_text)
            if strengths_match:
                strengths_text = strengths_match.group(1).strip()
                # Parse as bulleted list or numbered list
                strengths = ReviewParser._parse_list_items(strengths_text)

            # Extract weaknesses
            weaknesses = []
            weaknesses_match = ReviewParser._weaknesses_pattern.search(review_text)
            if weaknesses_match:
                weaknesses_text = weaknesses_match.group(1).strip()
                weaknesses = ReviewParser._parse_list_items(weaknesses_text)

            # Extract recommendations
            recommendations = []
            recommendations_match = ReviewParser._recommendations_pattern.search(review_text)
            if recommendations_match:
                recommendations_text = recommendations_match.group(1).strip()
                recommendations = ReviewParser._parse_list_items(recommendations_text)

            return CodeRating(
                score=score,
                strengths=strengths,
                weaknesses=weaknesses,
                recommendations=recommendations
            )
        except Exception:
            return None

    @staticmethod
    def _parse_list_items(text: str) -> List[str]:
        """
        Parse bulleted or numbered list items from text.

        FIX-006: Uses list accumulation to avoid O(n²) string concatenation.
        Previously used `items[-1] += ' ' + line` which creates a new string
        each time, resulting in quadratic complexity for long lists.
        """
        items = []
        current_item_parts = []  # Use list for O(1) append

        lines = text.strip().split('\n')
        for line in lines:
            line = line.strip()
            # Match bullet points: -, *, •, or numbered: 1., 2., etc.
            if re.match(r'^[\-\*\•]\s+', line) or re.match(r'^\d+\.\s+', line):
                # Save previous item if exists
                if current_item_parts:
                    items.append(' '.join(current_item_parts))
                # Start new item
                item = re.sub(r'^[\-\*\•]\s+|^\d+\.\s+', '', line).strip()
                current_item_parts = [item] if item else []
            elif line and current_item_parts:
                # Continuation of previous item - append to parts list
                current_item_parts.append(line)

        # Don't forget the last item
        if current_item_parts:
            items.append(' '.join(current_item_parts))

        return items


class Critic:
    """Represents one of the three code reviewers."""

    def __init__(self, config: CriticConfig):
        self.config = config
        self.name = config.name
        self.role = config.role
        self.system_prompt = config.system_prompt
        self.icon = config.icon
        self.color = config.color
        self.review = ""
        self.verdict = "NEEDS_WORK"
        self.confidence = 0
        self.rating = None

    def set_review(self, review_text: str) -> None:
        """Set review and parse verdict/confidence/rating."""
        self.review = review_text
        self.verdict, self.confidence, self.rating = ReviewParser.parse_review(review_text)

    def to_result(self) -> ReviewResult:
        """Convert to ReviewResult."""
        return ReviewResult(
            critic_name=self.name,
            critic_role=self.role,
            verdict=self.verdict,
            confidence=self.confidence,
            review_text=self.review,
            icon=self.icon,
            color=self.color,
            rating=self.rating
        )


class CriticManager:
    """Manages critic setup and operations."""
    
    @staticmethod
    def setup_critics(critics_dir: Path) -> List[Critic]:
        """Load critic configurations and create critic instances."""
        try:
            security_prompt = CriticManager._load_critic_prompt(
                os.path.join(critics_dir, 'security_specialist.md')
            )
            performance_prompt = CriticManager._load_critic_prompt(
                os.path.join(critics_dir, 'performance_engineer.md')
            )
            cleancode_prompt = CriticManager._load_critic_prompt(
                os.path.join(critics_dir, 'clean_code_advocate.md')
            )
        except Exception as e:
            raise FileError(f"Failed to load critic prompts: {e}")
        
        critic_configs = [
            CriticConfig(
                name="Security Specialist",
                role="Paranoid security expert - trusts nothing",
                system_prompt=security_prompt,
                icon="🔒",
                color="\033[91m"  # RED
            ),
            CriticConfig(
                name="Performance Engineer", 
                role="Ruthless performance optimizer - hates inefficiency",
                system_prompt=performance_prompt,
                icon="⚡",
                color="\033[94m"  # BLUE
            ),
            CriticConfig(
                name="Clean Code Advocate",
                role="Merciless code quality enforcer - demands excellence",
                system_prompt=cleancode_prompt,
                icon="✨",
                color="\033[92m"  # GREEN
            )
        ]
        
        return [Critic(config) for config in critic_configs]
    
    @staticmethod
    def _load_critic_prompt(filepath: str) -> str:
        """Load critic system prompt from file."""
        if not os.path.exists(filepath):
            raise FileError(f"Critic prompt file not found: {filepath}")
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read().strip()
                if not content:
                    raise FileError(f"Critic prompt file is empty: {filepath}")
                return content
        except Exception as e:
            raise FileError(f"Could not load {filepath}: {e}")


class ReviewRunner:
    """Runs reviews for all critics."""

    def __init__(self, api_client, output_formatter, color_class=None, timeout: int = 90):
        self.api_client = api_client
        self.output_formatter = output_formatter
        self.color_class = color_class or Colors
        self.timeout = timeout

    def get_stats(self) -> APIUsageStats:
        """Get API usage statistics from the client."""
        if hasattr(self.api_client, 'get_stats'):
            return self.api_client.get_stats()
        return APIUsageStats()

    def run_reviews(self, critics: List[Critic], project_content: str,
                    is_multi_file: bool, verbose: bool = False) -> List[ReviewResult]:
        """Run reviews for all critics."""
        results = []

        for critic in critics:
            try:
                # Make API call
                response = self.api_client.get_review(critic.config, project_content, is_multi_file, timeout=self.timeout)
                review_text = response.get('choices', [{}])[0].get('message', {}).get('content', '')

                if not review_text:
                    raise APIError("No response from API")

                critic.set_review(review_text)
                results.append(critic.to_result())

            except Exception as e:
                raise APIError(f"Review failed for {critic.name}: {e}")

        return results
    
    def run_chunked_reviews(self, critics: List[Critic], chunks: List[Dict[str, str]],
                           context_files: Dict[str, str], details: str, verbose: bool = False) -> List[ReviewResult]:
        """Run reviews for chunks of files."""
        results = []
        total_chunks = len(chunks)

        for chunk_idx, chunk in enumerate(chunks, 1):
            # Use centralized review formatter
            chunk_content = ReviewFormatter.format_chunk_content(
                chunk=chunk,
                chunk_idx=chunk_idx,
                total_chunks=total_chunks,
                context_files=context_files if chunk_idx == 1 else None,
                details=details
            )

            is_multi_file = len(chunk) > 1

            # Run reviews for this chunk
            chunk_results = self.run_reviews(critics, chunk_content, is_multi_file, verbose)
            results.extend(chunk_results)

        return results
    
    def _start_loading_animation(self, critic):
        """
        Start a loading animation for a critic.

        FIX-014: Uses LoadingAnimator from output.py instead of duplicating
        the animation logic here. This consolidates the loading animation
        implementation to a single location, improving maintainability.
        """
        animator = LoadingAnimator(critic.name, critic.icon, self.color_class)
        animator.start()
        return animator


class ConsensusCalculator:
    """
    Calculates consensus decisions from multiple reviews.

    FIX-001: Implements deterministic tie-breaking to prevent non-deterministic
    behavior when critic votes are tied. The tie-breaking order prefers safe outcomes:
    REJECT > NEEDS_WORK > APPROVE.
    """

    # Tie-breaking order: prefer safe outcomes
    # REJECT is preferred to avoid accepting problematic code
    # NEEDS_WORK is next to require further review
    # APPROVE is last (only if no concerns raised)
    TIEBREAKER_ORDER = ['REJECT', 'NEEDS_WORK', 'APPROVE']

    @staticmethod
    def calculate_consensus(reviews: List[ReviewResult]) -> ConsensusResult:
        """
        Calculate the council's consensus decision.

        FIX-001: Uses explicit tie-breaking order to ensure deterministic results
        when multiple verdicts have the same vote count.

        Args:
            reviews: List of ReviewResult objects from each critic

        Returns:
            ConsensusResult with the final decision and vote breakdown
        """
        votes = {
            'APPROVE': 0,
            'REJECT': 0,
            'NEEDS_WORK': 0
        }

        for review in reviews:
            votes[review.verdict] += 1

        max_votes = max(votes.values())
        tied_decisions = [k for k, v in votes.items() if v == max_votes]

        # Apply tie-breaking if there's a tie (FIX-001)
        if len(tied_decisions) > 1:
            # Use explicit tie-breaking order for deterministic results
            for decision in ConsensusCalculator.TIEBREAKER_ORDER:
                if decision in tied_decisions:
                    final_decision = decision
                    break
        else:
            final_decision = tied_decisions[0]

        # Map internal votes to output decisions
        decision_map = {
            'APPROVE': 'APPROVED',
            'REJECT': 'REJECTED',
            'NEEDS_WORK': 'NEEDS_WORK'
        }

        return ConsensusResult(
            decision=decision_map[final_decision],
            votes=votes,
            unanimous=max_votes == 3,
            majority=max_votes >= 2
        )


class ResultSaver:
    """Handles saving review results to files."""

    def save_results(self, reviews: List[ReviewResult], consensus: ConsensusResult) -> Path:
        """
        Save review results to a datetime-named folder with 4 files.

        Uses atomic file writes to prevent TOCTOU race conditions and symlink attacks.
        """
        try:
            # Security: Ensure results directory exists and is safe (not a symlink)
            results_dir = SecurityValidator.ensure_directory_safe(".ttc/review_results")

            timestamp = time.strftime("%Y%m%d_%H%M%S")

            # Create a folder for this review session (with symlink protection)
            session_dir = results_dir / timestamp
            SecurityValidator.ensure_directory_safe(session_dir)

            # Save individual reviews using atomic writes
            for review in reviews:
                filename = f"{review.critic_name.lower().replace(' ', '_')}.md"
                filepath = session_dir / filename

                # Build content with rating
                content = self._build_review_content(review)

                # Atomic write with symlink protection
                SecurityValidator.write_file_atomic(filepath, content)

            # Save consensus summary using atomic write
            consensus_filepath = session_dir / "consensus.md"
            consensus_content = self._build_consensus_content(reviews, consensus)

            # Atomic write with symlink protection
            SecurityValidator.write_file_atomic(consensus_filepath, consensus_content)

            return session_dir

        except Exception as e:
            raise FileError(f"Could not save results to files: {e}")

    def _build_review_content(self, review: ReviewResult) -> str:
        """Build content for a single review file."""
        content = [
            f"# {review.critic_name} Review\n\n",
            f"**Role:** {review.critic_role}\n",
            f"**Verdict:** {review.verdict}\n",
            f"**Confidence:** {review.confidence}/10\n",
        ]

        # Add rating if available
        if review.rating:
            content.append(f"**Code Rating:** {review.rating.score}/10\n")

            if review.rating.strengths:
                content.append("\n**Strengths:**\n")
                for strength in review.rating.strengths:
                    content.append(f"- {strength}\n")

            if review.rating.weaknesses:
                content.append("\n**Weaknesses:**\n")
                for weakness in review.rating.weaknesses:
                    content.append(f"- {weakness}\n")

            if review.rating.recommendations:
                content.append("\n**Recommendations:**\n")
                for rec in review.rating.recommendations:
                    content.append(f"- {rec}\n")

        content.extend([
            "\n---\n\n",
            f"{review.review_text}"
        ])

        return "".join(content)

    def _build_consensus_content(self, reviews: List[ReviewResult], consensus: ConsensusResult) -> str:
        """Build content for the consensus file."""
        content_lines = [
            "# Code Review Council Consensus\n\n",
            f"**Timestamp:** {time.strftime('%Y-%m-%d %H:%M:%S')}\n",
            f"**Decision:** {consensus.decision}\n",
            f"**Unanimous:** {consensus.unanimous}\n",
            f"**Majority:** {consensus.majority}\n\n",
            "## Vote Breakdown\n\n",
        ]

        for verdict, count in consensus.votes.items():
            content_lines.append(f"- **{verdict}:** {count} vote(s)\n")

        # Add overall ratings summary
        content_lines.append("\n## Code Ratings Summary\n\n")
        for review in reviews:
            if review.rating:
                content_lines.append(f"### {review.critic_name}: {review.rating.score}/10\n")
                if review.rating.strengths:
                    content_lines.append("**Strengths:**\n")
                    for s in review.rating.strengths[:3]:  # Show top 3
                        content_lines.append(f"- {s}\n")
                if review.rating.weaknesses:
                    content_lines.append("**Weaknesses:**\n")
                    for w in review.rating.weaknesses[:3]:  # Show top 3
                        content_lines.append(f"- {w}\n")
                content_lines.append("\n")

        return "".join(content_lines)