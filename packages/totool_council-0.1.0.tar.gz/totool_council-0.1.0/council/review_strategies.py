"""
Review strategies for chunked code review.

This module implements the Strategy pattern for different chunked review approaches:
- StandardStrategy: Basic chunked review
- ParallelStrategy: Parallel chunked review
- HierarchicalStrategy: Hierarchical chunked review with overall assessment

CODE QUALITY: Extracted from session.py to reduce nesting and improve maintainability.
"""
from abc import ABC, abstractmethod
from typing import List, Dict, Any

from council.models import ReviewResult


class ChunkReviewStrategy(ABC):
    """Base class for chunk review strategies."""

    @abstractmethod
    async def execute(
        self,
        critics: List[Any],
        chunks: List[Dict[str, str]],
        context_files: Dict[str, str],
        details: str,
        verbose: bool
    ) -> List[ReviewResult]:
        """
        Execute review strategy.

        Args:
            critics: List of critic configurations
            chunks: List of file chunks to review
            context_files: Context files to consider
            details: Additional review details
            verbose: Whether to print verbose output

        Returns:
            List of review results
        """
        pass


class StandardStrategy(ChunkReviewStrategy):
    """Standard chunked review (sequential processing)."""

    def __init__(self, review_runner):
        self.review_runner = review_runner

    async def execute(
        self,
        critics: List[Any],
        chunks: List[Dict[str, str]],
        context_files: Dict[str, str],
        details: str,
        verbose: bool
    ) -> List[ReviewResult]:
        """Execute standard chunked review."""
        return self.review_runner.run_chunked_reviews(
            critics, chunks, context_files, details, verbose
        )


class HierarchicalStrategy(ChunkReviewStrategy):
    """Hierarchical chunked review with overall assessment."""

    def __init__(self, review_runner, output_formatter):
        from council.hierarchical import HierarchicalReviewRunner
        self.wrapper = HierarchicalReviewRunner(review_runner, output_formatter)

    async def execute(
        self,
        critics: List[Any],
        chunks: List[Dict[str, str]],
        context_files: Dict[str, str],
        details: str,
        verbose: bool
    ) -> List[ReviewResult]:
        """Execute hierarchical chunked review."""
        return self.wrapper.run_hierarchical_reviews(
            critics, chunks, context_files, details, verbose
        )


class ParallelStrategy(ChunkReviewStrategy):
    """Parallel chunked review using thread pool."""

    def __init__(self, review_runner, output_formatter, workers: int):
        from council.parallel import ParallelReviewRunner
        self.wrapper = ParallelReviewRunner(review_runner, output_formatter, workers)

    async def execute(
        self,
        critics: List[Any],
        chunks: List[Dict[str, str]],
        context_files: Dict[str, str],
        details: str,
        verbose: bool
    ) -> List[ReviewResult]:
        """Execute parallel chunked review."""
        return self.wrapper.run_parallel_reviews(
            critics, chunks, context_files, details, verbose
        )


class MapReduceStrategy(ChunkReviewStrategy):
    """Map-Reduce strategy with structured findings and synthesis.

    This strategy implements a three-phase approach:
    1. MAP: Collect structured JSON findings from each chunk/critic
    2. AGGREGATE: Deduplicate and group findings
    3. REDUCE: Create one cohesive synthesis review
    """

    def __init__(self, review_runner, output_formatter):
        self.review_runner = review_runner
        self.output_formatter = output_formatter
        from council.synthesis import SynthesisEngine
        from council.aggregation import FindingsAggregator
        from council.json_parser import JSONReviewParser

        self.synthesis_engine = SynthesisEngine(
            review_runner.api_client, output_formatter
        )
        self.aggregator = FindingsAggregator()
        self.json_parser = JSONReviewParser()

    async def execute(
        self,
        critics: List[Any],
        chunks: List[Dict[str, str]],
        context_files: Dict[str, str],
        details: str,
        verbose: bool
    ) -> List[ReviewResult]:
        """Execute map-reduce review."""
        all_findings = []

        # PHASE 1: MAP - Get structured JSON from each chunk/critic
        for chunk_idx, chunk in enumerate(chunks, 1):
            # Get list of files in this chunk
            files_in_chunk = list(chunk.keys())

            # Run reviews for this chunk
            chunk_reviews = self.review_runner.run_chunked_reviews(
                critics, [chunk], context_files, details, verbose
            )

            # Parse JSON from each review
            for review in chunk_reviews:
                structured = self.json_parser.parse_review(
                    review_text=review.review_text,
                    critic_name=review.critic_name,
                    critic_role=review.critic_role,
                    chunk_idx=chunk_idx,
                    total_chunks=len(chunks),
                    files_reviewed=files_in_chunk
                )
                if structured:
                    all_findings.append(structured)

        # PHASE 2: AGGREGATE - Deduplicate and group
        aggregated = self.aggregator.aggregate(all_findings)

        # PHASE 3: REDUCE - Create synthesis
        synthesis_text = self.synthesis_engine.create_synthesis(aggregated)

        # Create a single ReviewResult from the synthesis
        synthesis_result = ReviewResult(
            critic_name="Synthesis Council",
            critic_role="Aggregated Review",
            verdict="NEEDS_WORK",  # Will be parsed from synthesis
            confidence=8,
            review_text=synthesis_text,
            icon="📋",
            color="cyan"
        )

        return [synthesis_result]
