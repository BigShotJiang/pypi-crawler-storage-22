"""
Secret detection and scanning for Code Review Council.
Scans file content and filenames for sensitive information to prevent exfiltration.
"""
import asyncio
import re
import os
import logging
import threading
from pathlib import Path
from typing import List, Optional, Tuple, Dict
from dataclasses import dataclass
from .exceptions import FileError


logger = logging.getLogger(__name__)

# Hardcoded fallback patterns (used if YAML is not available)
_HARDCODED_PATTERNS = [
    # AWS Access Key ID
    re.compile(r'(?<![A-Z0-9])(AKIA[0-9A-Z]{16})(?![A-Z0-9])'),
    # AWS Secret Access Key (context-aware)
    re.compile(r'(?i)aws[_\s]?secret[_\s]?access[_\s]?key["\']?\s*[:=]\s*["\']?([A-Za-z0-9/+=]{40})'),
    # AWS Session Token
    re.compile(r'(?i)aws[_\s]?session[_\s]?token["\']?\s*[:=]\s*["\']?(Fwo[a-zA-Z0-9+/]{100,})'),
    # Google Cloud API Key
    re.compile(r'(?<![A-Za-z0-9])(AIza[0-9A-Za-z\-_]{35})(?![A-Za-z0-9])'),
    # Google Cloud OAuth Access Token
    re.compile(r'ya29\.[A-Za-z0-9\-_]{100,}'),
    # Generic API Key patterns
    re.compile(r'(?i)api[_\s]?key["\']?\s*[:=]\s*["\']?([A-Za-z0-9\-_]{20,})'),
    re.compile(r'(?i)apikey["\']?\s*[:=]\s*["\']?([A-Za-z0-9\-_]{20,})'),
    re.compile(r'(?i)api[_\s]?secret["\']?\s*[:=]\s*["\']?([A-Za-z0-9\-_]{20,})'),
    # JWT tokens
    re.compile(r'(eyJ[A-Za-z0-9\-_]+\.(eyJ[A-Za-z0-9\-_]+\.)?[A-Za-z0-9\-_]+)'),
    # Bearer tokens
    re.compile(r'(?i)bearer["\']?\s*:\s*["\']?([A-Za-z0-9\-_\.]{20,})'),
    # Private key headers
    re.compile(r'-----BEGIN[A-Z\s]+PRIVATE KEY-----'),
    re.compile(r'-----BEGIN RSA PRIVATE KEY-----'),
    re.compile(r'-----BEGIN EC PRIVATE KEY-----'),
    re.compile(r'-----BEGIN OPENSSH PRIVATE KEY-----'),
    # Certificate headers
    re.compile(r'-----BEGIN CERTIFICATE-----'),
    # Database URLs
    re.compile(r'(?i)(postgresql|mysql|mongodb|redis)://[^:\s]+:[^@\s]+@'),
    re.compile(r'(?i)mongodb\+srv://[^:\s]+:[^@\s]+@'),
    # Password in connection strings
    re.compile(r'(?i)password["\']?\s*[:=]\s*["\']?([^\s"\']{8,})["\']?'),
    # Slack tokens
    re.compile(r'xox[baprs]-[0-9]{12}-[0-9]{12}-[0-9]{12}-[a-z0-9]{32}'),
    re.compile(r'xox[baprs]-[0-9]{12}-[0-9]{12}-[a-z0-9]{32}'),
    # GitHub tokens
    re.compile(r'ghp_[A-Za-z0-9]{36}'),
    re.compile(r'gho_[A-Za-z0-9]{36}'),
    re.compile(r'ghu_[A-Za-z0-9]{36}'),
    re.compile(r'ghs_[A-Za-z0-9]{36}'),
    re.compile(r'ghr_[A-Za-z0-9]{36}'),
    re.compile(r'github_pat_[A-Za-z0-9_]{82}'),
    # Stripe keys
    re.compile(r'(?i)pk_live_[A-Za-z0-9]{32,}'),
    re.compile(r'(?i)sk_live_[A-Za-z0-9]{32,}'),
    re.compile(r'(?i)pk_test_[A-Za-z0-9]{32,}'),
    re.compile(r'(?i)sk_test_[A-Za-z0-9]{32,}'),
    # Stripe publishable key (less strict pattern to catch variations)
    re.compile(r'(?i)pk_(live|test)_[A-Za-z0-9]{24,}'),
    re.compile(r'(?i)sk_(live|test)_[A-Za-z0-9]{24,}'),
    # Stripe restricted key
    re.compile(r'(?i)sk_live_[A-Za-z0-9]{24,}_[A-Za-z0-9]{10,}'),
    # Datadog keys
    re.compile(r'(?i)datadog[_\s]?api[_\s]?key["\']?\s*[:=]\s*["\']?[a-f0-9]{32}'),
    re.compile(r'[a-f0-9]{32}\.pub[a-f0-9]{32}'),  # Public key format
    # Datadog application keys
    re.compile(r'(?i)datadog[_\s]?app[_\s]?key["\']?\s*[:=]\s*["\']?[a-f0-9]{40}'),
    # Authorization headers
    re.compile(r'(?i)authorization["\']?\s*:\s*["\']?(basic|bearer)\s+[A-Za-z0-9\-_\.={20,}]'),
    # OpenAI API keys
    re.compile(r'sk-[a-zA-Z0-9]{48}'),
    re.compile(r'sk-proj-[a-zA-Z0-9\-_]{100,}'),
    # Anthropic API keys
    re.compile(r'sk-ant-api03-[A-Za-z0-9\-_]{95,}'),
    # Azure keys
    re.compile(r'[a-zA-Z0-9]{86}'),  # Azure Storage Account Key
    # Shopify tokens
    re.compile(r'shpat_[a-fA-F0-9]{32}'),
    re.compile(r'shopify_[a-fA-F0-9]{32}'),
    # Twilio keys
    re.compile(r'AC[a-z0-9]{32}'),
    # SendGrid keys
    re.compile(r'SG\.[A-Za-z0-9\-_]{64}\.[A-Za-z0-9\-_]{64}'),
    # PagerDuty tokens
    re.compile(r'R[0-9]{19}'),  # PagerDuty API token
    # npm tokens
    re.compile(r'npm_[A-Za-z0-9\-_]{36}'),
    # PyPI tokens
    re.compile(r'pypi-[A-Za-z0-9\-_]{30,}'),
    # Linear API keys
    re.compile(r'lin_api_[A-Za-z0-9]{40}'),
    # Square OAuth tokens
    re.compile(r'sq0atp-[A-Za-z0-9\-_]{22}'),
    re.compile(r'sq0csp-[A-Za-z0-9\-_]{43}'),
    # Zoom JWT tokens
    re.compile(r'(eyJ[A-Za-z0-9\-_]+\.(eyJ[A-Za-z0-9\-_]+\.)?[A-Za-z0-9\-_]+).*(zoom\.us|api\.zoom\.us)'),
]

_HARDCODED_SENSITIVE_FILENAME_PATTERNS = [
    re.compile(r'^\.env$'),
    re.compile(r'\.env\.(local|development|production|test)$'),
    re.compile(r'\.pem$'),
    re.compile(r'\.key$'),
    re.compile(r'\.crt$'),
    re.compile(r'\.cer$'),
    re.compile(r'\.der$'),
    re.compile(r'\.p12$'),
    re.compile(r'\.pfx$'),
    re.compile(r'^credentials\.', re.IGNORECASE),
    re.compile(r'^secrets\.', re.IGNORECASE),
    re.compile(r'^id_rsa$'),
    re.compile(r'^id_ed25519$'),
    re.compile(r'^id_ecdsa$'),
    re.compile(r'^id_dsa$'),
    re.compile(r'known_hosts$'),
    re.compile(r'^\.aws/credentials$'),
    re.compile(r'^\.aws/config$'),
    re.compile(r'^\.ssh/config$'),
    re.compile(r'^\.netrc$'),
    re.compile(r'^_netrc$'),
    re.compile(r'^\.htpasswd$'),
    re.compile(r'^keystore\.jks$'),
    re.compile(r'^truststore\.jks$'),
]

_HARDCODED_FALSE_POSITIVE_PATTERNS = [
    # UUIDs
    re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', re.IGNORECASE),
    # Placeholder values
    re.compile(r'(?i)your[_\s]?api[_\s]?key[_\s]?here'),
    re.compile(r'(?i)<your[_\s]?key[_\s]?here>'),
    re.compile(r'(?i)xxx+'),
    re.compile(r'(?i)placeholder'),
    re.compile(r'(?i)example[_\s]?key'),
    re.compile(r'(?i)test[_\s]?key'),
    # Short numeric IDs
    re.compile(r'^\d{8,20}$'),
]


@dataclass
class SecretMatch:
    """Represents a detected secret."""
    secret_type: str
    line_number: int
    content: str
    context: str


class SecretScanner:
    """
    Scans files for potential secrets and sensitive information.

    Prevents secret exfiltration by detecting:
    - API keys (AWS, Google Cloud, Azure, etc.)
    - Passwords and credentials
    - JWT tokens and bearer tokens
    - Private keys and certificates
    - Database URLs and connection strings
    - Sensitive filenames (.env, .pem, .key, etc.)

    FIX-002: Thread-safe pattern initialization using double-check locking pattern.
    """

    # Get default path to secrets.yaml
    _DEFAULT_YAML_PATH = Path(__file__).parent / 'data' / 'secrets.yaml'

    # FIX-002: Class-level lock for thread-safe pattern initialization
    _patterns_lock = threading.Lock()

    # Class variables that will be initialized from YAML or hardcoded patterns
    PATTERNS: List[re.Pattern] = []
    SENSITIVE_FILENAME_PATTERNS: List[re.Pattern] = []
    FALSE_POSITIVE_PATTERNS: List[re.Pattern] = []

    @classmethod
    def _load_patterns_from_yaml(cls, yaml_path: Optional[Path] = None) -> bool:
        """
        Load secret patterns from external YAML file.

        Args:
            yaml_path: Path to secrets.yaml file. Defaults to council/data/secrets.yaml

        Returns:
            True if patterns were loaded successfully, False if using hardcoded fallback
        """
        if yaml_path is None:
            yaml_path = cls._DEFAULT_YAML_PATH

        if not yaml_path.exists():
            logger.warning(f"Secret patterns YAML not found at {yaml_path}. Using hardcoded patterns.")
            return False

        try:
            import yaml
        except ImportError:
            logger.warning("PyYAML not installed. Using hardcoded patterns. Install with: pip install pyyaml")
            return False

        try:
            with open(yaml_path, 'r') as f:
                data = yaml.safe_load(f)

            # Load secret patterns
            cls.PATTERNS = []
            for pattern_def in data.get('patterns', []):
                regex = pattern_def['regex']
                flags_str = pattern_def.get('flags', '')
                flags = 0
                if 'i' in flags_str:
                    flags |= re.IGNORECASE
                cls.PATTERNS.append(re.compile(regex, flags))

            # Load sensitive filename patterns
            cls.SENSITIVE_FILENAME_PATTERNS = []
            for pattern_def in data.get('sensitive_filenames', []):
                regex = pattern_def['regex']
                flags_str = pattern_def.get('flags', '')
                flags = 0
                if 'i' in flags_str:
                    flags |= re.IGNORECASE
                cls.SENSITIVE_FILENAME_PATTERNS.append(re.compile(regex, flags))

            # Load false positive patterns
            cls.FALSE_POSITIVE_PATTERNS = []
            for pattern_def in data.get('false_positives', []):
                regex = pattern_def['regex']
                flags_str = pattern_def.get('flags', '')
                flags = 0
                if 'i' in flags_str:
                    flags |= re.IGNORECASE
                cls.FALSE_POSITIVE_PATTERNS.append(re.compile(regex, flags))

            logger.info(f"Loaded {len(cls.PATTERNS)} secret patterns from {yaml_path}")
            return True

        except Exception as e:
            logger.error(f"Error loading secrets from YAML: {e}. Using hardcoded patterns.")
            return False

    @classmethod
    def _ensure_patterns_loaded(cls):
        """
        Ensure patterns are loaded (from YAML or hardcoded) - thread-safe.

        FIX-002: Uses double-check locking pattern to prevent race conditions
        when multiple threads simultaneously call this method. Multiple threads
        could see PATTERNS as empty and try to initialize it simultaneously,
        causing duplicate patterns or other issues.

        The double-check pattern:
        1. Fast path: Check if already loaded without lock
        2. Slow path: Acquire lock and check again
        3. Initialize if still needed
        """
        # Fast path: already loaded (no lock needed)
        if cls.PATTERNS:
            return

        # Slow path: acquire lock and initialize
        with cls._patterns_lock:
            # Double-check after acquiring lock
            if cls.PATTERNS:
                return

            # Try YAML first, fall back to hardcoded
            if not cls._load_patterns_from_yaml():
                cls.PATTERNS = _HARDCODED_PATTERNS.copy()
                cls.SENSITIVE_FILENAME_PATTERNS = _HARDCODED_SENSITIVE_FILENAME_PATTERNS.copy()
                cls.FALSE_POSITIVE_PATTERNS = _HARDCODED_FALSE_POSITIVE_PATTERNS.copy()

    @classmethod
    def scan_file_content(cls, filepath: str, content: str) -> Optional[str]:
        """
        Scan file content for potential secrets.

        Args:
            filepath: Path to the file being scanned
            content: File content to scan

        Returns:
            Error message if secrets detected, None otherwise

        Raises:
            FileError: If secrets are detected (with HALT severity)
        """
        cls._ensure_patterns_loaded()

        lines = content.split('\n')

        for line_num, line in enumerate(lines, 1):
            if not line.strip():
                continue

            for pattern in cls.PATTERNS:
                match = pattern.search(line)

                if match:
                    if cls._is_false_positive(match.group(0), line):
                        continue

                    secret_type = cls._get_secret_type(pattern)
                    raise FileError(
                        f"HALT: Potential {secret_type} detected in {filepath}:{line_num}\n"
                        f"Line {line_num}: {line[:100]}...\n"
                        f"Match: {match.group(0)[:50]}...\n"
                        f"Security: File review blocked to prevent secret exfiltration.\n"
                        f"Action: Remove the secret from the file before reviewing."
                    )

        return None

    @classmethod
    def scan_filename(cls, filepath: str) -> Optional[str]:
        """
        Scan filename for sensitive patterns.

        Args:
            filepath: Path to the file to check

        Returns:
            Error message if filename is sensitive, None otherwise

        Raises:
            FileError: If filename is sensitive (with HALT severity)
        """
        cls._ensure_patterns_loaded()

        filename = os.path.basename(filepath)

        for pattern in cls.SENSITIVE_FILENAME_PATTERNS:
            if pattern.search(filename):
                raise FileError(
                    f"HALT: Sensitive filename detected: {filepath}\n"
                    f"Security: File appears to contain credentials or secrets based on its name.\n"
                    f"Action: Exclude this file from review using ignore patterns."
                )

        return None

    @classmethod
    def _is_false_positive(cls, match: str, line: str) -> bool:
        """
        Check if a match is likely a false positive.

        Args:
            match: The matched string
            line: The full line containing the match

        Returns:
            True if likely false positive, False otherwise
        """
        cls._ensure_patterns_loaded()

        for pattern in cls.FALSE_POSITIVE_PATTERNS:
            if pattern.search(match) or pattern.search(line.strip()):
                return True

        line_lower = line.lower()
        if any(keyword in line_lower for keyword in ['example', 'placeholder', 'xxx', 'your_', 'test_', 'dummy']):
            return True

        return False

    @classmethod
    def _get_secret_type(cls, pattern: re.Pattern) -> str:
        """
        Get a human-readable description of the secret type.

        Args:
            pattern: The regex pattern that matched

        Returns:
            String description of the secret type
        """
        pattern_str = pattern.pattern

        # AWS
        if 'AKIA' in pattern_str:
            return "AWS Access Key ID"
        elif 'aws[_\\s]?secret' in pattern_str.lower():
            return "AWS Secret Access Key"
        elif 'aws[_\\s]?session' in pattern_str.lower():
            return "AWS Session Token"

        # Google Cloud
        elif 'AIza' in pattern_str:
            return "Google Cloud API Key"
        elif 'ya29\\.' in pattern_str:
            return "Google OAuth Token"

        # Generic
        elif 'jwt' in pattern_str.lower() or ('eyJ' in pattern_str and 'zoom' not in pattern_str.lower()):
            return "JWT Token"
        elif 'bearer' in pattern_str.lower():
            return "Bearer Token"
        elif 'PRIVATE KEY' in pattern_str:
            return "Private Key"
        elif 'CERTIFICATE' in pattern_str:
            return "Digital Certificate"
        elif 'api[_\\s]?key' in pattern_str.lower() or 'apikey' in pattern_str.lower():
            return "API Key"

        # Database
        elif 'postgresql' in pattern_str.lower() or 'mysql' in pattern_str.lower():
            return "Database Connection String"
        elif 'mongodb' in pattern_str.lower():
            return "MongoDB Connection String"
        elif 'password' in pattern_str.lower():
            return "Password"

        # SaaS providers
        elif 'xox' in pattern_str:
            return "Slack Token"
        elif 'ghp_' in pattern_str or 'gho_' in pattern_str or 'github_pat_' in pattern_str:
            return "GitHub Token"
        elif 'stripe' in pattern_str.lower() or 'pk_live' in pattern_str or 'sk_live' in pattern_str or 'pk_test' in pattern_str or 'sk_test' in pattern_str:
            return "Stripe API Key"
        elif 'datadog' in pattern_str.lower():
            return "Datadog API Key"
        elif 'sk-' in pattern_str and 'ant' in pattern_str:
            return "Anthropic API Key"
        elif 'sk-proj-' in pattern_str or 'sk-[^-]{48}' in pattern_str:
            return "OpenAI API Key"
        elif 'shopify' in pattern_str.lower() or 'shpat_' in pattern_str:
            return "Shopify Token"
        elif 'AC[a-z0-9]{32}' in pattern_str:
            return "Twilio Account SID"
        elif 'SG\\.' in pattern_str:
            return "SendGrid API Key"
        elif 'R[0-9]{19}' in pattern_str:
            return "PagerDuty API Token"
        elif 'npm_' in pattern_str:
            return "npm Token"
        elif 'pypi-' in pattern_str:
            return "PyPI Token"
        elif 'lin_api_' in pattern_str:
            return "Linear API Key"
        elif 'sq0atp-' in pattern_str or 'sq0csp-' in pattern_str:
            return "Square OAuth Token"
        elif 'zoom' in pattern_str.lower():
            return "Zoom JWT Token"
        elif 'authorization' in pattern_str.lower():
            return "Authorization Header"
        else:
            return "Secret"

    @classmethod
    def is_safe_to_review(cls, filepath: str, content: str) -> bool:
        """
        Check if a file is safe to review (contains no secrets).

        Args:
            filepath: Path to the file
            content: File content

        Returns:
            True if safe, False if secrets detected

        Raises:
            FileError: If secrets are detected
        """
        cls.scan_filename(filepath)
        cls.scan_file_content(filepath, content)

        return True

    _COMBINED_PATTERN = None

    @classmethod
    def _get_combined_pattern(cls):
        """
        Get or create combined regex pattern for single-pass matching.

        FIX-015: Optimized pattern building - normalization happens only once
        during first construction, then the compiled pattern is cached for
        the lifetime of the process. Subsequent calls return the cached
        pattern immediately with O(1) complexity.

        NOTE: Inline flags like (?i) are moved to the start of each sub-pattern
        to avoid "global flags not at the start" errors when combining patterns.

        Performance:
        - First call: O(n) where n is the number of patterns (normalization + compile)
        - Subsequent calls: O(1) (returns cached compiled pattern)
        """
        cls._ensure_patterns_loaded()

        if cls._COMBINED_PATTERN is None:
            combined_patterns = []
            for p in cls.PATTERNS:
                pattern_str = p.pattern
                # Normalize inline flags (one-time operation)
                if pattern_str.startswith('(?i)'):
                    pattern_str = f'(?i:{pattern_str[4:]})'
                elif pattern_str.startswith('(?-i:'):
                    pass
                combined_patterns.append(f'({pattern_str})')

            combined = '|'.join(combined_patterns)
            cls._COMBINED_PATTERN = re.compile(combined)
        return cls._COMBINED_PATTERN

    @classmethod
    def redact_secrets(
        cls,
        content: str,
        filepath: str = None
    ) -> Tuple[str, List[SecretMatch]]:
        """
        Redact secrets from content to prevent sending them to third-party APIs.

        Args:
            content: Content to redact
            filepath: Optional filepath for logging

        Returns:
            Tuple of (redacted_content, list_of_secrets_found)
        """
        cls._ensure_patterns_loaded()
        secrets = []
        lines = content.split('\n')

        line_offsets = [0]
        for line in lines:
            line_offsets.append(line_offsets[-1] + len(line) + 1)

        for line_num, line in enumerate(lines, 1):
            if not line.strip():
                continue

            for pattern_idx, pattern in enumerate(cls.PATTERNS):
                matches = pattern.finditer(line)
                for match in matches:
                    secret_value = match.group()

                    if cls._is_false_positive(secret_value, line):
                        continue

                    secret_type = cls._get_secret_type(pattern)

                    secret_match = SecretMatch(
                        secret_type=secret_type,
                        line_number=line_num,
                        content=secret_value[:50] + ('...' if len(secret_value) > 50 else ''),
                        context=line.strip()[:100]
                    )
                    secrets.append(secret_match)

        # Single-pass redaction using combined pattern
        combined_pattern = cls._get_combined_pattern()

        def replace_match(match):
            """Replacement function that redacts matched secrets."""
            for i, pattern in enumerate(cls.PATTERNS):
                if match.group(i + 1) is not None:
                    secret_type = cls._get_secret_type(pattern)
                    return f"[REDACTED_{secret_type.upper().replace(' ', '_')}]"
            return match.group(0)  # Fallback: return original if no pattern matched

        redacted_content = combined_pattern.sub(replace_match, content)

        # Verbose logging removed - cleaner summaries are printed by file_reader.py and async_files.py

        return redacted_content, secrets

    @classmethod
    async def redact_secrets_async(
        cls,
        content: str,
        filepath: str = None
    ) -> Tuple[str, List['SecretMatch']]:
        """
        Async version of redact_secrets() that doesn't block the event loop.

        Args:
            content: Content to redact
            filepath: Optional filepath for logging

        Returns:
            Tuple of (redacted_content, list_of_secrets_found)
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: cls.redact_secrets(content, filepath)
        )

    @classmethod
    def scan_file_content_with_matches(
        cls,
        filepath: str,
        content: str
    ) -> List[SecretMatch]:
        """
        Scan file content for secrets and return list of matches without raising errors.

        This is useful for reporting all secrets found rather than failing on first one.

        Args:
            filepath: Path to the file being scanned
            content: File content to scan

        Returns:
            List of SecretMatch objects (empty if no secrets found)
        """
        cls._ensure_patterns_loaded()
        secrets = []
        lines = content.split('\n')

        for line_num, line in enumerate(lines, 1):
            if not line.strip():
                continue

            for pattern in cls.PATTERNS:
                matches = pattern.finditer(line)
                for match in matches:
                    secret_value = match.group()

                    if cls._is_false_positive(secret_value, line):
                        continue

                    secret_type = cls._get_secret_type(pattern)

                    secrets.append(SecretMatch(
                        secret_type=secret_type,
                        line_number=line_num,
                        content=secret_value[:50] + ('...' if len(secret_value) > 50 else ''),
                        context=line.strip()[:100]
                    ))

        return secrets
