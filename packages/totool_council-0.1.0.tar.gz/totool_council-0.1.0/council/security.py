"""
Security utilities for Code Review Council.
Provides URL validation, path validation, and other security checks.

## DNS Rebinding Protection

### Threat Model
DNS rebinding attacks allow an attacker to bypass hostname-based security checks by:
1. Initially resolving a hostname to an approved IP address (e.g., api.deepseek.com)
2. After validation, changing DNS to resolve to a private/internal IP (e.g., 127.0.0.1)
3. Using the approved hostname to access internal resources

### Mitigation Strategy
1. **Configuration-time validation**: Initial check when hostname is configured (current implementation)
2. **Connection-time validation**: Re-validate IP before each connection (enhanced implementation)
3. **DNS caching**: Short TTL to minimize window for DNS changes
4. **SSL/TLS**: Certificate validation provides additional MITM protection

### Risk Assessment
- **Current Risk**: LOW - The tool is a short-lived CLI, not a long-running server
- **Attack Window**: Seconds between validation and connection
- **Additional Protections**: SSL certificate validation, trusted API provider whitelist
"""
import errno
import re
import os
import socket
import ipaddress
from pathlib import Path
from typing import Optional, Tuple
from urllib.parse import urlparse


class SecurityValidator:
    """
    Security validation utilities for protecting against SSRF, path traversal,
    and other security vulnerabilities.
    """

    # Whitelist of allowed API base URLs (prevent SSRF attacks)
    ALLOWED_BASE_URLS = [
        'api.deepseek.com',
        'api.mistral.ai',
        'api.z.ai',
    ]

    # Patterns that should NEVER appear in URLs (prevent SSRF to internal services)
    BLOCKED_URL_PATTERNS = [
        'localhost',
        '127.0.0.1',
        '0.0.0.0',
        '::1',
        'file://',
        'ftp://',
        '192.168.',
        '10.',
        '172.16.',
        '172.17.',
        '172.18.',
        '172.19.',
        '172.20.',
        '172.21.',
        '172.22.',
        '172.23.',
        '172.24.',
        '172.25.',
        '172.26.',
        '172.27.',
        '172.28.',
        '172.29.',
        '172.30.',
        '172.31.',
    ]

    # Sensitive system directories that should never be accessed (prevent path traversal)
    SENSITIVE_DIRECTORIES = [
        '/etc',
        '/root',
        '/boot',
        '/sys',
        '/proc',
        '/dev',
        '/run',
        '/var/run',
        '/var/log',
    ]

    # Sensitive home directory patterns
    SENSITIVE_HOME_PATTERNS = [
        '/.ssh',
        '/.aws',
        '/.gnupg',
        '/.config',
        '/.local',
        '/.cache',
        '/.npm',
        '/.gem',
        '/.ssh/id_rsa',
        '/.ssh/id_ed25519',
        '/.ssh/id_ecdsa',
        '/.ssh/id_dsa',
        '/.ssh/known_hosts',
    ]

    # Only exact hostname matches - NO subdomain wildcards (prevents SSRF)
    EXACTLY_ALLOWED_HOSTNAMES = {
        'api.deepseek.com',
        'api.mistral.ai',
        'api.z.ai',
        'openai.api.openai.com',
        'api.anthropic.com',
    }

    @classmethod
    def _resolve_and_validate_ip(cls, hostname: str) -> Tuple[str, ipaddress.IPv4Address | ipaddress.IPv6Address]:
        """
        Resolve hostname to IP and validate it's not a private/internal address.

        Args:
            hostname: The hostname to resolve

        Returns:
            Tuple of (ip_string, ip_address_object)

        Raises:
            ValueError: If IP is private, loopback, or link-local
        """
        try:
            ip_string = socket.gethostbyname(hostname)
            ip = ipaddress.ip_address(ip_string)

            if ip.is_private or ip.is_loopback or ip.is_link_local:
                raise ValueError(
                    f"Security: Hostname '{hostname}' resolves to private IP {ip_string}. "
                    f"This prevents DNS rebinding attacks."
                )

            return ip_string, ip
        except socket.gaierror as e:
            raise ValueError(f"Security: DNS resolution failed for '{hostname}': {e}")

    @classmethod
    def validate_base_url(cls, base_url: str) -> Optional[str]:
        """
        Validate that a base URL is safe to use (SSRF protection).

        CRITICAL SECURITY FIX: Uses EXACT hostname matching only - no subdomain wildcards.
        This prevents SSRF attacks where an attacker could use:
        - attacker-controlled.deepseek.com
        - api.deepseek.com.evil.com

        Args:
            base_url: The base URL to validate

        Returns:
            None if valid, error message if invalid

        Raises:
            ValueError: If base_url is blocked or not in whitelist
        """
        if not base_url:
            return None  # Will use default

        # Parse URL
        try:
            parsed = urlparse(base_url)
            hostname = parsed.hostname or parsed.netloc.split(':')[0]

            if not hostname:
                raise ValueError(
                    f"Security: Invalid base URL '{base_url}': no hostname"
                )

            # Check for blocked patterns (prevent internal network access)
            for blocked in cls.BLOCKED_URL_PATTERNS:
                if blocked in base_url.lower() or (hostname and blocked in hostname.lower()):
                    raise ValueError(
                        f"Security: Blocked base URL contains '{blocked}'. "
                        f"This prevents SSRF attacks to internal services."
                    )

            # CRITICAL: EXACT hostname match only - NO subdomain wildcards
            hostname_lower = hostname.lower()
            if hostname_lower not in cls.EXACTLY_ALLOWED_HOSTNAMES:
                allowed_list = ', '.join(sorted(cls.EXACTLY_ALLOWED_HOSTNAMES))
                raise ValueError(
                    f"Security: Base URL hostname '{hostname_lower}' is not in the allowed list. "
                    f"Allowed hostnames (exact match only): {allowed_list}"
                )

            # Ensure URL scheme is HTTPS
            if parsed.scheme and parsed.scheme != 'https':
                raise ValueError(
                    f"Security: Base URL must use HTTPS, not '{parsed.scheme}'"
                )

            # DNS rebinding protection: Verify hostname doesn't resolve to private IP
            try:
                cls._resolve_and_validate_ip(hostname)
            except (socket.gaierror, ValueError) as e:
                if isinstance(e, socket.gaierror):
                    # DNS resolution failed - allow it but could be a sign of issues
                    pass
                elif "DNS resolution failed" in str(e):
                    # DNS resolution failed - allow it but could be a sign of issues
                    pass
                else:
                    raise

        except ValueError as e:
            raise e
        except Exception as e:
            raise ValueError(f"Security: Invalid base URL '{base_url}': {e}")

        return None

    @classmethod
    def validate_project_path(cls, path: str, allow_system_paths: bool = False) -> Optional[str]:
        """
        Validate that a project path is safe to access (path traversal protection).

        SECURITY FIX: Uses os.path.realpath() instead of os.path.abspath() to resolve
        symlinks and prevent symlink attacks. An attacker could create a symlink inside
        the project directory pointing to sensitive system files (/root/.ssh/id_rsa).

        Args:
            path: The path to validate
            allow_system_paths: If True, allow access to system directories

        Returns:
            None if valid, error message if invalid

        Raises:
            ValueError: If path is blocked
        """
        if not path:
            raise ValueError("Path cannot be empty")

        # SECURITY FIX: Use realpath to resolve symlinks (prevents symlink attacks)
        # abspath() does NOT resolve symlinks, allowing path traversal via symlinks
        try:
            real_path = os.path.realpath(path)
            normalized_path = os.path.normpath(real_path)
        except Exception as e:
            raise ValueError(f"Invalid path '{path}': {e}")

        # Check if path is a sensitive system directory (unless explicitly allowed)
        if not allow_system_paths:
            for sensitive_dir in cls.SENSITIVE_DIRECTORIES:
                # Check if path is exactly the sensitive directory or starts with it
                if normalized_path == sensitive_dir or normalized_path.startswith(sensitive_dir + '/'):
                    raise ValueError(
                        f"Security: Access to system directory '{sensitive_dir}' is blocked. "
                        f"Use --allow-system-paths to enable (not recommended)."
                    )

            # Check home directory patterns
            home_dir = os.path.expanduser('~')
            for sensitive_pattern in cls.SENSITIVE_HOME_PATTERNS:
                # Check if path contains sensitive home directory patterns
                sensitive_path = os.path.join(home_dir, sensitive_pattern.lstrip('/'))
                if normalized_path == sensitive_path or normalized_path.startswith(sensitive_path + '/'):
                    raise ValueError(
                        f"Security: Access to sensitive directory '{sensitive_pattern}' is blocked."
                    )

        # Verify path exists and is accessible
        if not os.path.exists(normalized_path):
            raise ValueError(f"Path does not exist: {path}")

        return None

    @classmethod
    def validate_context_file(cls, filepath: str, project_path: str) -> Optional[str]:
        """
        Validate that a context file is safe to load (prevent exfiltration via context).

        SECURITY FIX: Uses os.path.realpath() to resolve symlinks and prevent
        symlink attacks. An attacker could create a symlink inside the project
        pointing to sensitive files outside the project.

        Args:
            filepath: The context file path to validate
            project_path: The project directory path

        Returns:
            None if valid, error message if invalid

        Raises:
            ValueError: If context file is unsafe
        """
        if not filepath:
            raise ValueError("Context file path cannot be empty")

        # SECURITY FIX: Use realpath to resolve symlinks (prevents symlink attacks)
        # abspath() does NOT resolve symlinks, allowing path traversal via symlinks
        try:
            real_filepath = os.path.realpath(filepath)
            real_project = os.path.realpath(project_path)

            # Additional check: verify filepath itself is not a symlink
            if os.path.islink(filepath):
                raise ValueError(
                    f"Security: Context file '{filepath}' is a symlink. "
                    f"This prevents symlink attacks. Use the actual file path."
                )
        except Exception as e:
            raise ValueError(f"Invalid context file path '{filepath}': {e}")

        # Security fix: Use commonpath to prevent path traversal attacks
        # This is more robust than relpath() which can be bypassed with edge cases
        try:
            common_path = os.path.commonpath([real_filepath, real_project])
            # Ensure the common path is the project path itself (not a parent)
            if common_path != real_project:
                raise ValueError(
                    f"Security: Context file '{filepath}' is outside project directory. "
                    f"Context files must be within the project being reviewed."
                )
        except ValueError:
            # Paths on different drives on Windows, or no common path
            raise ValueError(
                f"Security: Context file '{filepath}' is on a different drive from the project."
            )

        # Validate as a project path (reuse existing validation)
        try:
            cls.validate_project_path(real_filepath, allow_system_paths=False)
        except ValueError as e:
            raise ValueError(
                f"Security: Context file '{filepath}' failed validation: {e}"
            )

        # Ensure it's a file, not a directory
        if not os.path.isfile(real_filepath):
            raise ValueError(f"Context file must be a file, not a directory: {filepath}")

        return None

    @classmethod
    def validate_connection_target(cls, base_url: str) -> Tuple[str, str]:
        """
        Validate connection target at connection time (DNS rebinding protection).

        This should be called immediately before establishing a connection to
        ensure the hostname hasn't been re-bound to a private IP since initial
        configuration validation.

        Args:
            base_url: The base URL to validate

        Returns:
            Tuple of (hostname, validated_ip)

        Raises:
            ValueError: If hostname resolves to private IP or validation fails

        Usage:
            hostname, validated_ip = SecurityValidator.validate_connection_target(base_url)
            # Use validated_ip for additional checks if needed
        """
        if not base_url:
            raise ValueError("Base URL cannot be empty")

        parsed = urlparse(base_url)
        hostname = parsed.hostname or parsed.netloc.split(':')[0]

        if not hostname:
            raise ValueError(f"Security: Invalid base URL '{base_url}': no hostname")

        # Verify hostname is still in allowed list
        hostname_lower = hostname.lower()
        if hostname_lower not in cls.EXACTLY_ALLOWED_HOSTNAMES:
            allowed_list = ', '.join(sorted(cls.EXACTLY_ALLOWED_HOSTNAMES))
            raise ValueError(
                f"Security: Base URL hostname '{hostname_lower}' is not in the allowed list. "
                f"Allowed hostnames (exact match only): {allowed_list}"
            )

        # Connection-time DNS validation (prevents DNS rebinding)
        ip_string, ip = cls._resolve_and_validate_ip(hostname)

        return hostname, ip_string

    @classmethod
    def validate_directory_not_symlink(cls, dirpath: str) -> Optional[str]:
        """
        Validate that a directory is not a symlink (prevent symlink attacks).

        Security improvement: Uses atomic symlink detection with O_NOFOLLOW
        to prevent TOCTOU race conditions.

        Args:
            dirpath: The directory path to validate

        Returns:
            None if valid, error message if invalid

        Raises:
            ValueError: If directory is a symlink (anywhere in the chain)
        """
        if not dirpath:
            return None

        try:
            # Atomic symlink detection using os.open() with O_NOFOLLOW
            # This prevents TOCTOU race conditions where directory could be
            # replaced with symlink after validation but before file writes
            try:
                fd = os.open(dirpath, os.O_RDONLY | os.O_NOFOLLOW)
                os.close(fd)
            except OSError as e:
                if e.errno == errno.ELOOP:
                    raise ValueError(
                        f"Security: Directory '{dirpath}' is a symlink. "
                        f"This prevents symlink attacks. Use the actual directory path."
                    )
                # If directory doesn't exist yet, that's okay (we might be creating it)
                # ENOENT = No such file or directory
                if e.errno != errno.ENOENT:
                    raise ValueError(
                        f"Security: Unable to verify directory '{dirpath}' is not a symlink. "
                        f"Use the actual directory path."
                    )

            # Additional check for symlink chains using realpath
            try:
                real_path = os.path.realpath(dirpath)
                if real_path != os.path.abspath(dirpath):
                    # The path resolves to something different, meaning there's a symlink somewhere
                    raise ValueError(
                        f"Security: Directory '{dirpath}' contains symlinks in its path. "
                        f"This prevents symlink chain attacks. Use the actual directory path."
                    )
            except (OSError, ValueError):
                # If we can't resolve the path, be conservative and reject it
                raise ValueError(
                    f"Security: Unable to verify directory '{dirpath}' is not a symlink chain. "
                    f"Use the actual directory path."
                )
        except Exception as e:
            if isinstance(e, ValueError):
                raise
            # If path doesn't exist yet, that's okay (we might be creating it)
            pass

        return None

    @classmethod
    def write_file_atomic(cls, filepath: str | Path, content: str) -> None:
        """
        Write to file atomically with symlink protection.

        Uses temp-file-then-rename pattern to prevent TOCTOU race conditions.
        This ensures that writes are atomic and the file is either fully written
        or not written at all, with no intermediate state vulnerable to symlink attacks.

        Args:
            filepath: Path to the file to write
            content: Content to write to the file

        Raises:
            ValueError: If parent directory is a symlink or write fails
        """
        filepath = Path(filepath)

        # CRITICAL: Validate parent directory is not a symlink before writing
        if filepath.parent.exists():
            cls.validate_directory_not_symlink(str(filepath.parent))

        # Write to temp file in same directory (ensures same filesystem for atomic rename)
        temp_path = filepath.parent / f".tmp_{filepath.name}_{os.getpid()}_{os.urandom(4).hex()}"

        try:
            # Write to temp file
            with open(temp_path, 'w', encoding='utf-8') as f:
                f.write(content)

            # Atomic rename (overwrites if exists, atomic on same filesystem)
            temp_path.replace(filepath)

        finally:
            # Clean up temp file if it still exists (write failed before rename)
            if temp_path.exists():
                try:
                    temp_path.unlink()
                except OSError:
                    pass  # Best effort cleanup

    @classmethod
    def ensure_directory_safe(cls, dirpath: str | Path) -> Path:
        """
        Ensure a directory exists and is safe (not a symlink).

        Creates the directory if it doesn't exist, validating it's not a symlink.

        Args:
            dirpath: Path to the directory

        Returns:
            Path object for the directory

        Raises:
            ValueError: If directory is a symlink or cannot be created
        """
        dirpath = Path(dirpath)

        if dirpath.exists():
            # Validate existing directory is not a symlink
            cls.validate_directory_not_symlink(str(dirpath))
        else:
            # Create directory (mkdir doesn't follow symlinks)
            dirpath.mkdir(parents=True, exist_ok=True)

            # Validate it wasn't replaced by symlink during creation
            cls.validate_directory_not_symlink(str(dirpath))

        return dirpath
