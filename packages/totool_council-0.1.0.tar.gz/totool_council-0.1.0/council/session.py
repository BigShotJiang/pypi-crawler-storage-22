"""
Review session management for Code Review Council.

This module encapsulates the main review workflow, breaking down the
main_async function into smaller, focused functions following the
Single Responsibility Principle.

This module has been refactored to use the extracted CacheManager and
FilePreprocessor components to reduce the responsibilities of ReviewSession.
"""
from typing import Dict, List, Tuple, Optional

from council.cache import ReviewCache
from council.files import FileCollector
from council.review import CriticManager, ConsensusCalculator
from council.hierarchical import HierarchicalReviewRunner
from council.parallel import ParallelFileCollector, ParallelReviewRunner
from council.output import OutputFormatter
from council.models import CouncilConfig, ReviewResult, ConsensusResult, CONSTANTS, APIUsageStats
from council.exceptions import FileError
from council.cache_manager import CacheManager
from council.file_preprocessor import FilePreprocessor
from council.chunk_orchestrator import ChunkReviewOrchestrator


class ReviewSession:
    """
    Manages a single code review session from start to finish.

    This class has been refactored to delegate responsibilities to:
    - CacheManager: Cache operations
    - FilePreprocessor: File collection and preprocessing
    - ChunkReviewOrchestrator: Strategy selection for chunked reviews

    The remaining responsibilities are:
    - Session initialization
    - Configuration loading
    - Review orchestration
    - Result saving
    """

    def __init__(self, config: CouncilConfig, output_formatter: OutputFormatter, session):
        """
        Initialize a review session.

        Args:
            config: Council configuration
            output_formatter: Output formatter for display
            session: Async/sync session from compatibility layer
        """
        self.config = config
        self.output_formatter = output_formatter
        self.session = session

        # Use extracted components
        self.cache_manager = CacheManager(output_formatter)
        self.file_preprocessor = FilePreprocessor(output_formatter)

        # Track API client for stats
        self._api_client = None

    def get_api_stats(self) -> APIUsageStats:
        """Get API usage statistics from the API client."""
        if self._api_client and hasattr(self._api_client, 'get_stats'):
            return self._api_client.get_stats()
        return APIUsageStats()

    def prepare_file_collector(self, use_async: bool, parallel_workers: int) -> FileCollector:
        """
        Get appropriate file collector based on configuration.

        Args:
            use_async: Whether to use async operations
            parallel_workers: Number of parallel workers

        Returns:
            FileCollector instance
        """
        if parallel_workers > 1 and not use_async:
            # Use parallel collector only if not using async
            return ParallelFileCollector(
                self.config.ignore_patterns,
                self.output_formatter,
                parallel_workers
            )
        else:
            # Use session's file collector (could be async or sync)
            return self.session.get_file_collector(
                self.config.ignore_patterns,
                self.output_formatter
            )

    # Note: Cache operations now delegated to CacheManager
    def initialize_cache(self, cache_dir: str, no_cache: bool) -> Optional[ReviewCache]:
        """Initialize cache using CacheManager."""
        return self.cache_manager.initialize_cache(cache_dir, no_cache)

    def check_cache(
        self,
        filepaths: List[str],
        files_metadata: Dict[str, Tuple[int, int]],
        context_files: Dict[str, str],
        chunk_strategy: str = "size",
        chunk_size: int = 32000
    ) -> Optional[Tuple[List[ReviewResult], ConsensusResult]]:
        """Check cache using CacheManager."""
        return self.cache_manager.check_cache(
            self.config.project_path,
            filepaths,
            context_files,
            self.config.details,
            chunk_strategy,
            chunk_size,
            files_metadata
        )

    def save_to_cache(
        self,
        cache_key: str,
        reviews: List[ReviewResult],
        consensus: ConsensusResult
    ) -> None:
        """Save to cache using CacheManager."""
        self.cache_manager.save_to_cache(cache_key, reviews, consensus)

    def get_cache_key(
        self,
        filepaths: List[str],
        files_metadata: Dict[str, Tuple[int, int]],
        context_files: Dict[str, str],
        chunk_strategy: str = "size",
        chunk_size: int = 32000
    ) -> Optional[str]:
        """Get cache key using CacheManager."""
        return self.cache_manager.get_cache_key(
            self.config.project_path,
            filepaths,
            context_files,
            self.config.details,
            chunk_strategy,
            chunk_size,
            files_metadata
        )

    # Note: File preprocessing now delegated to FilePreprocessor
    def determine_deduplication_usage(
        self,
        file_collector: FileCollector,
        deduplicate_enabled: bool
    ) -> Tuple[bool, int, int, int]:
        """Determine deduplication usage using FilePreprocessor."""
        return self.file_preprocessor.determine_deduplication_usage(
            file_collector,
            deduplicate_enabled,
            self.config.project_path
        )

    async def collect_file_metadata(
        self,
        file_collector: FileCollector
    ) -> Tuple[List[str], Dict[str, Tuple[int, int]]]:
        """Collect file metadata using FilePreprocessor."""
        return await self.file_preprocessor.collect_file_metadata(file_collector)

    async def load_files(
        self,
        file_collector: FileCollector,
        use_async: bool,
        parallel_workers: int,
        force_streaming: bool = None,
        disable_streaming: bool = False
    ) -> Tuple[Dict[str, str], Dict[str, Tuple[int, int]]]:
        """Load files using FilePreprocessor."""
        return await self.file_preprocessor.load_files(
            file_collector,
            self.config.project_path,
            use_async,
            parallel_workers,
            force_streaming,
            disable_streaming
        )

    def apply_deduplication(
        self,
        files_content: Dict[str, str],
        use_deduplication: bool
    ) -> Dict[str, str]:
        """Apply deduplication using FilePreprocessor."""
        return self.file_preprocessor.apply_deduplication(files_content, use_deduplication)

    async def run_review(
        self,
        files_content: Dict[str, str],
        context_files: Dict[str, str],
        use_async: bool
    ) -> Tuple[List[ReviewResult], ConsensusResult]:
        """
        Execute the review process.

        Args:
            files_content: Files content to review
            context_files: Context files
            use_async: Whether to use async operations

        Returns:
            Tuple of (reviews, consensus)
        """
        # Setup reviewers
        critics = CriticManager.setup_critics(self.config.critics_dir)

        # Get API client from session
        api_client = self.session.get_api_client(
            self.config.api_key,
            self.config.base_url,
            self.config.model,
            self.config.endpoint,
            self.config.sequential,
            max_requests_per_second=self.session.max_requests_per_second
        )

        # Get review runner from session
        review_runner = self.session.get_review_runner(
            api_client,
            self.output_formatter,
            None,  # color_class
            self.config.sequential
        )

        # Run reviews (simplified - no chunking in this example)
        from council.cli import ProjectFormatter
        project_content = ProjectFormatter.format_project_for_review(files_content, context_files)
        project_content = ProjectFormatter.add_additional_details(project_content, self.config.details)

        if use_async:
            reviews = await self.session.run_reviews_async(
                review_runner,
                critics,
                project_content,
                len(files_content) > 1,
                self.config.verbose
            )
        else:
            reviews = review_runner.run_reviews(
                critics,
                project_content,
                len(files_content) > 1,
                self.config.verbose
            )

        # Calculate consensus
        consensus_calculator = ConsensusCalculator()
        consensus = consensus_calculator.calculate_consensus(reviews)

        return reviews, consensus


    async def run(
        self,
        args,
        use_async: bool
    ) -> Tuple[List[ReviewResult], ConsensusResult, List[str], Dict[str, str]]:
        """
        Run the complete review workflow.

        This is the main orchestration method that has been simplified
        to use the extracted CacheManager and FilePreprocessor components.

        Args:
            args: Command-line arguments
            use_async: Whether to use async operations

        Returns:
            Tuple of (reviews, consensus, filepaths, context_files)
        """
        from council.cli import ProjectFormatter

        cache = self.initialize_cache(args.cache_dir, args.no_cache)
        file_collector = self.prepare_file_collector(use_async, args.parallel)

        use_deduplication, total_files, total_size_bytes, eligible_files = \
            self.determine_deduplication_usage(file_collector, args.deduplicate)

        filepaths, files_metadata = await self.collect_file_metadata(file_collector)

        if not filepaths:
            raise FileError("No code files found to review")

        cache_key = None
        cached_result = None

        if cache:
            cache_key = self.get_cache_key(
                filepaths,
                files_metadata,
                self.config.context_files,
                args.chunk_strategy,
                args.chunk_size
            )
            cached_result = self.check_cache(
                filepaths,
                files_metadata,
                self.config.context_files,
                args.chunk_strategy,
                args.chunk_size
            )

        if cached_result:
            return cached_result[0], cached_result[1], filepaths, self.config.context_files

        # FIX-003: Decide chunking strategy BEFORE loading all file content
        # This prevents loading large projects into memory only to discover
        # that chunking is needed. We use metadata (file sizes) to decide.
        total_size_bytes = sum(meta[0] for meta in files_metadata.values())
        max_size_bytes = CONSTANTS.MAX_TOTAL_SIZE_MB * 1024 * 1024
        should_chunk = (
            total_size_bytes > max_size_bytes
            or len(filepaths) > CONSTANTS.get_max_file_count()
        ) and not args.no_chunking

        if should_chunk:
            self.output_formatter.print_info(
                f"Project size: {total_size_bytes / (1024 * 1024):.1f}MB "
                f"({len(filepaths)} files). Using chunking strategy."
            )

        # Determine streaming mode from CLI flags
        # --streaming: force streaming, --no-streaming: disable auto-streaming
        force_streaming = getattr(args, 'streaming', False)
        disable_streaming = getattr(args, 'no_streaming', False)

        # Load files - for chunked mode, this will be done per-chunk later
        files_content, files_metadata = await self.load_files(
            file_collector,
            use_async,
            args.parallel,
            force_streaming,
            disable_streaming
        )

        if not files_content:
            raise FileError("No code files found to review")

        files_content = self.apply_deduplication(files_content, use_deduplication)

        reviews, consensus = await self._run_review_with_chunking(
            files_content,
            file_collector,
            use_async,
            should_chunk,
            args
        )

        if cache and cache_key:
            self.save_to_cache(cache_key, reviews, consensus)

        return reviews, consensus, filepaths, self.config.context_files

    async def _run_review_with_chunking(
        self,
        files_content: Dict[str, str],
        file_collector,
        use_async: bool,
        should_chunk: bool,
        args
    ) -> Tuple[List[ReviewResult], ConsensusResult]:
        """
        Run review with optional chunking support.

        Args:
            files_content: Files content to review
            file_collector: File collector instance
            use_async: Whether to use async operations
            should_chunk: Whether chunking is needed
            args: Command-line arguments

        Returns:
            Tuple of (reviews, consensus)
        """
        from council.cli import ProjectFormatter
        from council.review import CriticManager, ConsensusCalculator

        # Setup reviewers
        critics = CriticManager.setup_critics(self.config.critics_dir)

        # Get API client from session (store for stats access)
        api_client = self.session.get_api_client(
            self.config.api_key,
            self.config.base_url,
            self.config.model,
            self.config.endpoint,
            self.config.sequential,
            max_requests_per_second=self.session.max_requests_per_second
        )
        self._api_client = api_client  # Store for stats access

        # Get review runner from session
        review_runner = self.session.get_review_runner(
            api_client,
            self.output_formatter,
            None,  # color_class
            self.config.sequential
        )

        # Run reviews with or without chunking
        if should_chunk:
            return await self._run_chunked_review(
                critics,
                review_runner,
                file_collector,
                files_content,
                use_async,
                args
            )
        else:
            # Format project content normally
            project_content = ProjectFormatter.format_project_for_review(
                files_content, self.config.context_files
            )
            project_content = ProjectFormatter.add_additional_details(
                project_content, self.config.details
            )

            # Run reviews
            if use_async:
                reviews = await self.session.run_reviews_async(
                    review_runner,
                    critics,
                    project_content,
                    len(files_content) > 1,
                    self.config.verbose
                )
            else:
                reviews = review_runner.run_reviews(
                    critics,
                    project_content,
                    len(files_content) > 1,
                    self.config.verbose
                )

            # Calculate consensus
            consensus_calculator = ConsensusCalculator()
            consensus = consensus_calculator.calculate_consensus(reviews)

            return reviews, consensus

    async def _run_chunked_review(
        self,
        critics,
        review_runner,
        file_collector,
        files_content: Dict[str, str],
        use_async: bool,
        args
    ) -> Tuple[List[ReviewResult], ConsensusResult]:
        """
        Run chunked review with optional hierarchical or parallel strategies.

        Args:
            critics: List of critics
            review_runner: Review runner instance
            file_collector: File collector instance
            files_content: Files content to review
            use_async: Whether to use async operations
            args: Command-line arguments

        Returns:
            Tuple of (reviews, consensus)
        """
        from council.review import ConsensusCalculator
        from council.chunk_strategy import ChunkStrategy
        from council.chunk_orchestrator import ChunkReviewOrchestrator

        # Prepare chunks for review
        chunks = self._prepare_chunks_for_review(
            file_collector, files_content, args
        )

        # Execute reviews using appropriate strategy
        reviews = await self._execute_chunked_reviews(
            review_runner, critics, chunks, use_async, args
        )

        # Calculate and return consensus
        consensus_calculator = ConsensusCalculator()
        consensus = consensus_calculator.calculate_consensus(reviews)

        return reviews, consensus

    def _prepare_chunks_for_review(
        self,
        file_collector,
        files_content: Dict[str, str],
        args
    ) -> List[Dict[str, str]]:
        """
        Prepare file chunks for review.

        Args:
            file_collector: File collector instance
            files_content: Files content to review
            args: Command-line arguments

        Returns:
            List of file chunks
        """
        from council.chunk_strategy import ChunkStrategy

        chunk_strategy = ChunkStrategy(self.output_formatter)
        calculated_chunk_size = chunk_strategy.calculate_optimal_chunk_size(
            files_content, args.chunk_size
        )

        # Show chunk size info
        if args.chunk_size:
            self.output_formatter.print_warning(
                f"Using user-provided chunk size: {args.chunk_size} tokens"
            )
        else:
            self.output_formatter.print_warning(
                f"Auto-calculated chunk size: {calculated_chunk_size} tokens (aiming for 2-3 chunks)"
            )

        # Chunk files using selected strategy
        chunks = file_collector.chunk_files(
            files_content, args.chunk_strategy, args.chunk_size
        )
        self.output_formatter.print_warning(
            f"Project split into {len(chunks)} chunks using {args.chunk_strategy} strategy"
        )

        # Show memory usage if requested
        if args.show_memory:
            memory_usage = self.output_formatter.get_memory_usage()
            self.output_formatter.print_memory_warning(memory_usage)

        return chunks

    async def _execute_chunked_reviews(
        self,
        review_runner,
        critics,
        chunks: List[Dict[str, str]],
        use_async: bool,
        args
    ) -> List[ReviewResult]:
        """
        Execute chunked reviews using appropriate strategy.

        Args:
            review_runner: Review runner instance
            critics: List of critics
            chunks: File chunks to review
            use_async: Whether to use async operations
            args: Command-line arguments

        Returns:
            List of review results
        """
        from council.chunk_orchestrator import ChunkReviewOrchestrator

        orchestrator = ChunkReviewOrchestrator(review_runner, self.output_formatter)

        if use_async:
            return await self._execute_async_chunked_reviews(
                review_runner, orchestrator, critics, chunks, args
            )
        else:
            return await self._execute_sync_chunked_reviews(
                orchestrator, critics, chunks, args
            )

    async def _execute_async_chunked_reviews(
        self,
        review_runner,
        orchestrator,
        critics,
        chunks: List[Dict[str, str]],
        args
    ) -> List[ReviewResult]:
        """
        Execute chunked reviews in async mode.

        Args:
            review_runner: Review runner instance
            orchestrator: Chunk review orchestrator
            critics: List of critics
            chunks: File chunks to review
            args: Command-line arguments

        Returns:
            List of review results
        """
        strategy = orchestrator.get_strategy(args, chunks)

        if hasattr(strategy, 'wrapper'):
            # Hierarchical and Parallel strategies have a wrapper
            return await self.session.run_chunked_reviews_async(
                strategy.wrapper, critics, chunks,
                self.config.context_files, self.config.details, self.config.verbose
            )
        else:
            # Standard strategy - use review_runner directly
            return await self.session.run_chunked_reviews_async(
                review_runner, critics, chunks,
                self.config.context_files, self.config.details, self.config.verbose
            )

    async def _execute_sync_chunked_reviews(
        self,
        orchestrator,
        critics,
        chunks: List[Dict[str, str]],
        args
    ) -> List[ReviewResult]:
        """
        Execute chunked reviews in sync mode.

        Args:
            orchestrator: Chunk review orchestrator
            critics: List of critics
            chunks: File chunks to review
            args: Command-line arguments

        Returns:
            List of review results
        """
        strategy = orchestrator.get_strategy(args, chunks)
        return await strategy.execute(
            critics, chunks, self.config.context_files, self.config.details, self.config.verbose
        )
