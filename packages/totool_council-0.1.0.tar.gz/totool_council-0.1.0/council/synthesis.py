"""Synthesize final review from aggregated findings."""
from council.models import AggregatedFindings, CriticConfig


class SynthesisEngine:
    """Create final cohesive review from aggregated findings."""

    SYNTHESIS_SYSTEM_PROMPT = """You are an expert code reviewer synthesizing findings from multiple specialists.
Your job is to create ONE cohesive, well-organized review that combines all findings."""

    SYNTHESIS_USER_PROMPT = """You are synthesizing a comprehensive code review from multiple expert critics who reviewed a project in chunks.

## Aggregated Findings

### Summary
- Total chunks reviewed: {total_chunks}
- Total files analyzed: {total_files}
- Critical issues: {critical_count}
- High issues: {high_count}
- Medium issues: {medium_count}
- Low issues: {low_count}

### Issues by Severity

#### Critical Issues ({critical_count})
{critical_issues}

#### High Issues ({high_count})
{high_issues}

#### Medium Issues ({medium_count}) (showing top 10)
{medium_issues}

#### Low Issues ({low_count}) (showing top 5)
{low_issues}

### Patterns Found
{patterns}

## Your Task
Create ONE cohesive, well-organized review that:
1. Synthesizes all findings into a coherent narrative
2. Prioritizes issues by severity and frequency
3. Highlights the most critical problems that need immediate attention
4. Groups related issues together (e.g., all security issues, all performance issues)
5. Provides actionable recommendations
6. Gives an overall verdict (APPROVE/REJECT/NEEDS_WORK)
7. States your confidence (1-10)

Format your output with clear sections using markdown. Be concise but thorough.

IMPORTANT: End your review with:
VERDICT: [APPROVE/REJECT/NEEDS_WORK]
CONFIDENCE: [1-10]
"""

    def __init__(self, api_client, output_formatter):
        self.api_client = api_client
        self.output_formatter = output_formatter

    def _format_issue(self, issue) -> str:
        """Format an issue for display in the synthesis prompt."""
        parts = [f"- **{issue.type}** in `{issue.file}`"]
        if issue.line:
            parts.append(f" (line {issue.line})")
        if issue.function:
            parts.append(f" in `{issue.function}()`")
        parts.append(f"\n  {issue.description}")
        if issue.recommendation:
            parts.append(f"\n  *Fix: {issue.recommendation}*")
        return ''.join(parts)

    def _build_synthesis_prompt(self, aggregated: AggregatedFindings) -> str:
        """Build the synthesis prompt from aggregated findings."""

        # Format issues by severity (limit medium/low for token efficiency)
        critical_issues = '\n'.join([
            self._format_issue(i)
            for i in aggregated.by_severity.get('critical', [])
        ])

        high_issues = '\n'.join([
            self._format_issue(i)
            for i in aggregated.by_severity.get('high', [])
        ])

        medium_issues = '\n'.join([
            self._format_issue(i)
            for i in aggregated.by_severity.get('medium', [])[:10]
        ])

        low_issues = '\n'.join([
            self._format_issue(i)
            for i in aggregated.by_severity.get('low', [])[:5]
        ])

        patterns = ', '.join(aggregated.all_patterns) if aggregated.all_patterns else 'None'

        return self.SYNTHESIS_USER_PROMPT.format(
            total_chunks=aggregated.total_chunks,
            total_files=aggregated.total_files,
            critical_count=len(aggregated.by_severity.get('critical', [])),
            high_count=len(aggregated.by_severity.get('high', [])),
            medium_count=len(aggregated.by_severity.get('medium', [])),
            low_count=len(aggregated.by_severity.get('low', [])),
            critical_issues=critical_issues or 'None',
            high_issues=high_issues or 'None',
            medium_issues=medium_issues or 'None',
            low_issues=low_issues or 'None',
            patterns=patterns
        )

    def create_synthesis(self, aggregated: AggregatedFindings, timeout: int = 90) -> str:
        """Create ONE cohesive review from all findings."""
        prompt = self._build_synthesis_prompt(aggregated)

        # Create a temporary CriticConfig for the synthesis
        synthesis_config = CriticConfig(
            name="Synthesis",
            role="Aggregated Review",
            system_prompt=self.SYNTHESIS_SYSTEM_PROMPT,
            icon="📋",
            color="cyan"
        )

        # Make the API call using the existing interface
        response = self.api_client.get_review(
            critic_config=synthesis_config,
            code=prompt,
            is_multi_file=False,
            timeout=timeout
        )

        # Extract the review text from the response
        review_text = response.get('choices', [{}])[0].get('message', {}).get('content', '')

        return review_text
