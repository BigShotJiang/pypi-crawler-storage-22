"""
Utility functions for Code Review Council.
Contains helper functions that don't belong in other modules.
"""
import asyncio
import re
import time
from typing import Optional


def sanitize_api_key(message: str, api_key: str | None = None) -> str:
    """
    Remove API keys from error messages and logs to prevent exposure.

    Uses pattern-based redaction for various API key formats:
    - OpenAI: sk-...
    - Anthropic: sk-ant-...
    - Generic hex strings (likely keys)
    - Bearer tokens

    Args:
        message: Original message that may contain API key
        api_key: The specific API key to redact (optional, for exact matching)

    Returns:
        Sanitized message with API key redacted
    """
    if not message:
        return message

    # If we have the API key, redact exact matches first
    if api_key and len(api_key) > 8 and api_key in message:
        # Show first 8 and last 4 chars for debugging
        redacted = f"{api_key[:8]}...{api_key[-4:]}" if len(api_key) > 12 else "***REDACTED***"
        message = message.replace(api_key, redacted)

    # Pattern-based redaction for common API key formats
    # OpenAI format: sk-... (at least 10 chars for shorter keys in dev/test)
    message = re.sub(
        r'sk-[a-zA-Z0-9]{10,}',
        'sk-***REDACTED***',
        message
    )

    # Anthropic format: sk-ant-... (at least 10 chars after prefix)
    message = re.sub(
        r'sk-ant-[a-zA-Z0-9_-]{10,}',
        'sk-ant-***REDACTED***',
        message
    )

    # Generic Bearer tokens (long alphanumeric strings after "Bearer")
    message = re.sub(
        r'Bearer\s+[a-zA-Z0-9_-]{10,}',
        'Bearer ***REDACTED***',
        message
    )

    # Generic hex-like strings that look like keys (32+ chars)
    # This catches things like 64-character hex strings
    message = re.sub(
        r'\b[a-fA-F0-9]{32,}\b',
        '***REDACTED_KEY***',
        message
    )

    # DeepSeek-style keys (if they follow specific patterns)
    message = re.sub(
        r'\b[a-zA-Z0-9]{40,}\b',  # Very long alphanumeric strings
        '***REDACTED***',
        message
    )

    return message


class RateLimiter:
    """Base token bucket rate limiter for API calls."""

    def __init__(self, max_requests_per_second: float = 10.0, bucket_capacity_multiplier: float = 2.0):
        """
        Initialize the rate limiter with burst protection.

        Args:
            max_requests_per_second: Rate at which tokens are added
            bucket_capacity_multiplier: Maximum tokens as multiplier of rate
        """
        self.max_requests_per_second = max_requests_per_second
        self.bucket_capacity = max_requests_per_second * bucket_capacity_multiplier
        self.tokens_per_request = 1.0
        self.tokens = self.bucket_capacity
        self.last_update = time.monotonic()


class AsyncRateLimiter(RateLimiter):
    """Async-compatible rate limiter."""

    def __init__(self, max_requests_per_second: float = 10.0, bucket_capacity_multiplier: float = 2.0):
        super().__init__(max_requests_per_second, bucket_capacity_multiplier)
        self._lock = asyncio.Lock()

    async def acquire(self):
        """Acquire a token, sleeping if necessary."""
        async with self._lock:
            now = time.monotonic()
            elapsed = now - self.last_update
            self.tokens = min(self.bucket_capacity,
                            self.tokens + elapsed * self.max_requests_per_second)
            self.last_update = now

            if self.tokens >= self.tokens_per_request:
                self.tokens -= self.tokens_per_request
                return

            deficit = self.tokens_per_request - self.tokens
            sleep_time = deficit / self.max_requests_per_second
            await asyncio.sleep(sleep_time)
            self.tokens = 0.0
            self.last_update = time.monotonic()


class SyncRateLimiter(RateLimiter):
    """Synchronous rate limiter using threading.Lock."""

    def __init__(self, max_requests_per_second: float = 10.0, bucket_capacity_multiplier: float = 2.0):
        super().__init__(max_requests_per_second, bucket_capacity_multiplier)
        import threading
        self._lock = threading.Lock()

    def acquire(self):
        """
        Acquire a token, sleeping if necessary.

        SECURITY: Burst protection is enforced by limiting token accumulation
        to bucket_capacity, preventing unlimited token buildup attacks.
        """
        with self._lock:
            now = time.monotonic()
            elapsed = now - self.last_update
            # Add tokens based on elapsed time, capped at bucket_capacity
            self.tokens = min(self.bucket_capacity,
                            self.tokens + elapsed * self.max_requests_per_second)
            self.last_update = now

            if self.tokens >= self.tokens_per_request:
                self.tokens -= self.tokens_per_request
                return

            # Not enough tokens, need to sleep
            deficit = self.tokens_per_request - self.tokens
            sleep_time = deficit / self.max_requests_per_second
            time.sleep(sleep_time)
            self.tokens = 0.0
            self.last_update = time.monotonic()


def get_recommended_chunk_size(model: str | None = None, provider: str = "deepseek") -> int:
    """
    Get recommended chunk size based on model and provider.

    Args:
        model: The model name (optional)
        provider: The API provider (default: "deepseek")

    Returns:
        Recommended chunk size in tokens

    This function provides business logic for determining optimal chunk sizes
    based on the model's context window and API limitations.
    """
    if not model:
        model = ""

    model_lower = model.lower()

    # DeepSeek models
    if provider == "deepseek":
        if "v3" in model_lower:
            return 8000  # Conservative for API limits
        elif "coder" in model_lower:
            return 8000  # Conservative for API limits
        else:
            return 8000  # Default safe size

    # Mistral models
    elif provider == "mistral":
        if "large" in model_lower:
            return 8000  # Conservative for API limits
        elif "codestral" in model_lower:
            return 8000  # Conservative for API limits
        else:
            return 8000  # Default safe size

    # ZAI models
    elif provider == "zai":
        if "glm-4" in model_lower:
            return 8000  # Conservative for API limits
        else:
            return 8000  # Default safe size

    # Default fallback
    return 8000


def clamp_value(value: int, min_val: int, max_val: int) -> int:
    """
    Clamp a value between min and max bounds.

    Args:
        value: The value to clamp
        min_val: Minimum allowed value
        max_val: Maximum allowed value

    Returns:
        The clamped value, guaranteed to be within [min_val, max_val]
    """
    return max(min_val, min(value, max_val))
