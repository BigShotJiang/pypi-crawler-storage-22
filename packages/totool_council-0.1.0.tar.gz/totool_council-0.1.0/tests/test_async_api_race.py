"""
Tests for async API client initialization race conditions.

T-003: Tests for FIX-005 - Async client initialization race condition.

These tests verify that the AsyncAPIClient correctly handles concurrent
initialization without race conditions or AttributeError.
"""
import unittest
import asyncio
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from council.async_api import AsyncAPIClient
from council.models import CriticConfig


class TestAsyncInitialization(unittest.TestCase):
    """Test async client initialization under concurrent load (FIX-005)."""

    def setUp(self):
        """Set up test fixtures."""
        # Skip if aiohttp not available
        try:
            import aiohttp
        except ImportError:
            self.skipTest("aiohttp not installed")

    def test_concurrent_init_no_errors(self):
        """
        T-003.1: Multiple tasks should safely initialize client.

        Verify that concurrent calls to initialize() do not cause errors.
        """
        async def run_test():
            client = AsyncAPIClient(
                api_key="test-key",
                base_url="https://api.example.com",
                model="test-model"
            )

            tasks = [
                client.initialize() for _ in range(10)
            ]

            # Should complete without errors
            results = await asyncio.gather(*tasks, return_exceptions=True)

            # Check no exceptions
            for r in results:
                self.assertNotIsInstance(r, Exception,
                                       f"Initialization should not raise: {r}")

            # Client should be initialized
            self.assertTrue(client._initialized)

            await client.close()

        asyncio.run(run_test())

    def test_concurrent_get_review_auto_init(self):
        """
        T-003.2: Concurrent get_review calls should auto-initialize safely.

        FIX-005: get_review should acquire lock and initialize if needed.
        """
        async def run_test():
            client = AsyncAPIClient(
                api_key="test-key",
                base_url="https://api.example.com",
                model="test-model"
            )

            # Don't explicitly initialize - let get_review do it
            critic_config = CriticConfig(
                name="Test Critic",
                role="Tester",
                system_prompt="Test instructions",
                icon="",
                color=""
            )

            # Note: This will fail due to network/API issues, but we're testing
            # that initialization happens safely, not that the API call succeeds
            tasks = []

            async def try_get_review():
                try:
                    # The important part is that initialization doesn't race
                    await client.get_review(critic_config, "code")
                except Exception as e:
                    # We expect API/network errors, just not initialization races
                    if "initialize" in str(e).lower() or "lock" in str(e).lower():
                        raise

            for _ in range(3):
                tasks.append(try_get_review())

            # Should not raise initialization-related errors
            results = await asyncio.gather(*tasks, return_exceptions=True)

            # Filter out expected API errors, check for init errors
            init_errors = [
                r for r in results
                if isinstance(r, Exception) and (
                    "initialize" in str(r).lower() or
                    "lock" in str(r).lower() or
                    isinstance(r, RuntimeError)
                )
            ]

            self.assertEqual(len(init_errors), 0,
                           f"Should have no initialization errors: {init_errors}")

            await client.close()

        asyncio.run(run_test())

    def test_double_check_pattern_efficiency(self):
        """
        T-003.3: Verify double-check pattern prevents unnecessary locking.

        Once initialized, get_review should not wait on lock unnecessarily.
        """
        async def run_test():
            client = AsyncAPIClient(
                api_key="test-key",
                base_url="https://api.example.com",
                model="test-model"
            )

            # Initialize once
            await client.initialize()

            # Check initialized flag is set
            self.assertTrue(client._initialized)

            # Call initialize many more times - should return quickly
            import time
            start = time.time()
            for _ in range(100):
                await client.initialize()
            elapsed = time.time() - start

            # Should be very fast (fast path)
            self.assertLess(elapsed, 0.1,
                           f"Fast path should be efficient, took {elapsed:.3f}s")

            await client.close()

        asyncio.run(run_test())

    def test_init_after_close(self):
        """
        T-003.4: Client close should work correctly after initialization.

        Edge case: client is initialized then closed.
        """
        async def run_test():
            client = AsyncAPIClient(
                api_key="test-key",
                base_url="https://api.example.com",
                model="test-model"
            )

            # First initialization
            await client.initialize()
            self.assertTrue(client._initialized)
            self.assertIsNotNone(client._session)

            # Close the client
            await client.close()
            self.assertIsNone(client._session)

            # Note: _initialized flag stays True after close
            # This is expected behavior - a closed client cannot be reused

        asyncio.run(run_test())

    def test_context_manager_concurrent(self):
        """
        T-003.5: Context manager should handle concurrent entry safely.

        """
        async def run_test():
            async def use_client():
                async with AsyncAPIClient(
                    api_key="test-key",
                    base_url="https://api.example.com",
                    model="test-model"
                ) as client:
                    # Should be initialized
                    self.assertTrue(client._initialized)
                    await asyncio.sleep(0.01)  # Simulate some work

            # Run multiple context managers concurrently
            tasks = [use_client() for _ in range(5)]
            await asyncio.gather(*tasks)

        asyncio.run(run_test())

    def test_explicit_then_context_manager(self):
        """
        T-003.6: Explicit init followed by context manager should work.
        """
        async def run_test():
            client = AsyncAPIClient(
                api_key="test-key",
                base_url="https://api.example.com",
                model="test-model"
            )

            # Explicit init
            await client.initialize()
            self.assertTrue(client._initialized)

            # Using as context manager again should be safe
            async with client:
                self.assertTrue(client._initialized)

        asyncio.run(run_test())

    def test_lock_prevents_double_session_creation(self):
        """
        T-003.7: Lock should prevent multiple session creation attempts.

        Verify that under heavy concurrent load, only one session is created.
        """
        async def run_test():
            client = AsyncAPIClient(
                api_key="test-key",
                base_url="https://api.example.com",
                model="test-model"
            )

            session_creation_count = [0]
            original_init = client._initialize_session_if_needed

            async def counting_init():
                session_creation_count[0] += 1
                await original_init()

            client._initialize_session_if_needed = counting_init

            # Launch concurrent initializations
            tasks = [client.initialize() for _ in range(20)]
            await asyncio.gather(*tasks)

            # Should only create session once
            self.assertEqual(session_creation_count[0], 1,
                           "Session should only be created once despite concurrent init")

            await client.close()

        asyncio.run(run_test())

    def test_rate_limiter_preserved(self):
        """
        T-003.8: Rate limiter should be preserved during initialization.
        """
        async def run_test():
            from council.utils import AsyncRateLimiter

            rate_limiter = AsyncRateLimiter(max_requests_per_second=5.0)
            client = AsyncAPIClient(
                api_key="test-key",
                base_url="https://api.example.com",
                model="test-model",
                rate_limiter=rate_limiter
            )

            # Initialize
            await client.initialize()

            # Rate limiter should be the same instance
            self.assertIs(client.rate_limiter, rate_limiter,
                         "Rate limiter should be preserved")

            await client.close()

        asyncio.run(run_test())

    def test_initialized_flag_thread_safety(self):
        """
        T-003.9: _initialized flag should be set correctly under concurrent access.

        """
        async def run_test():
            client = AsyncAPIClient(
                api_key="test-key",
                base_url="https://api.example.com",
                model="test-model"
            )

            # Many concurrent initialize calls
            tasks = [
                client.initialize() for _ in range(50)
            ]

            await asyncio.gather(*tasks)

            # Flag should definitely be true
            self.assertTrue(client._initialized)

            await client.close()

        asyncio.run(run_test())


if __name__ == '__main__':
    unittest.main()
