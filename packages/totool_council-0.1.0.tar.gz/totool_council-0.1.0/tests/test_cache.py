"""
Tests for cache module.

Tests cache integrity, HMAC verification, and expiration.
"""
import unittest
import tempfile
import shutil
import time
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from council.cache import ReviewCache
from council.models import ReviewResult, ConsensusResult


class TestReviewCache(unittest.TestCase):
    """Test review cache functionality."""

    def setUp(self):
        """Set up test fixtures with temporary cache directory."""
        self.test_dir = tempfile.mkdtemp()
        self.cache = ReviewCache(cache_dir=self.test_dir, ttl_hours=1)

    def tearDown(self):
        """Clean up temporary cache directory."""
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_cache_directory_creation(self):
        """Test that cache directory is created."""
        self.assertTrue(os.path.exists(self.test_dir))

    def test_save_and_load_review(self):
        """Test saving and loading review results."""
        # Create test review data
        review_results = [
            {
                'critic_name': 'Security Specialist',
                'critic_role': 'Security expert',
                'verdict': 'APPROVE',
                'confidence': 8,
                'review_text': 'Code looks good',
                'icon': '🔒',
                'color': 'red'
            }
        ]

        consensus = {
            'decision': 'APPROVED',
            'votes': {'APPROVE': 1, 'REJECT': 0, 'NEEDS_WORK': 0},
            'unanimous': True,
            'majority': True
        }

        # Get cache key
        cache_key = self.cache.get_cache_key(
            project_path='/test/project',
            filepaths=['file1.py', 'file2.py'],
            context_files={'README.md': 'test'},
            details='test details',
            chunk_strategy='size',
            chunk_size=2000
        )

        # Save review
        success = self.cache.save_review(cache_key, review_results, consensus)
        self.assertTrue(success)

        # Load review
        loaded = self.cache.load_review(cache_key)
        self.assertIsNotNone(loaded)
        self.assertEqual(loaded['consensus']['decision'], 'APPROVED')
        self.assertEqual(len(loaded['review_results']), 1)

    def test_cache_key_generation(self):
        """Test cache key generation."""
        key1 = self.cache.get_cache_key(
            project_path='/test/project',
            filepaths=['file1.py', 'file2.py'],
            context_files={},
            details='test',
            chunk_strategy='size',
            chunk_size=2000
        )

        key2 = self.cache.get_cache_key(
            project_path='/test/project',
            filepaths=['file1.py', 'file2.py'],
            context_files={},
            details='test',
            chunk_strategy='size',
            chunk_size=2000
        )

        # Same inputs should produce same key
        self.assertEqual(key1, key2)

    def test_cache_key_different_inputs(self):
        """Test that different inputs produce different keys."""
        key1 = self.cache.get_cache_key(
            project_path='/test/project',
            filepaths=['file1.py'],
            context_files={},
            details='test',
            chunk_strategy='size',
            chunk_size=2000
        )

        key2 = self.cache.get_cache_key(
            project_path='/test/project',
            filepaths=['file2.py'],  # Different file
            context_files={},
            details='test',
            chunk_strategy='size',
            chunk_size=2000
        )

        # Different inputs should produce different keys
        self.assertNotEqual(key1, key2)

    def test_cache_expiration(self):
        """Test cache expiration."""
        review_results = [{'critic_name': 'Test', 'critic_role': 'Test', 'verdict': 'APPROVE',
                          'confidence': 5, 'review_text': 'Test', 'icon': 'T', 'color': 'red'}]
        consensus = {'decision': 'APPROVED', 'votes': {'APPROVE': 1}, 'unanimous': True, 'majority': True}

        cache_key = 'test_key'
        self.cache.save_review(cache_key, review_results, consensus)

        # Should load immediately
        loaded = self.cache.load_review(cache_key)
        self.assertIsNotNone(loaded)

        # Manually expire the cache by setting old timestamp
        cache_file = os.path.join(self.test_dir, f"{cache_key}.json")
        self.cache.save_review(cache_key, review_results, consensus)

        # Wait a moment
        time.sleep(0.1)

    def test_clear_expired(self):
        """Test clearing expired cache entries."""
        # Create cache with very short TTL
        short_lived_cache = ReviewCache(cache_dir=self.test_dir, ttl_hours=0)

        review_results = [{'critic_name': 'Test', 'critic_role': 'Test', 'verdict': 'APPROVE',
                          'confidence': 5, 'review_text': 'Test', 'icon': 'T', 'color': 'red'}]
        consensus = {'decision': 'APPROVED', 'votes': {'APPROVE': 1}, 'unanimous': True, 'majority': True}

        # Save multiple entries
        for i in range(3):
            cache_key = f'test_key_{i}'
            short_lived_cache.save_review(cache_key, review_results, consensus)

        # Wait for expiration
        time.sleep(0.1)

        # Clear expired
        cleared = short_lived_cache.clear_expired()
        self.assertGreaterEqual(cleared, 0)

    def test_clear_all(self):
        """Test clearing all cache entries."""
        review_results = [{'critic_name': 'Test', 'critic_role': 'Test', 'verdict': 'APPROVE',
                          'confidence': 5, 'review_text': 'Test', 'icon': 'T', 'color': 'red'}]
        consensus = {'decision': 'APPROVED', 'votes': {'APPROVE': 1}, 'unanimous': True, 'majority': True}

        # Save multiple entries
        for i in range(3):
            cache_key = f'test_key_{i}'
            self.cache.save_review(cache_key, review_results, consensus)

        # Clear all
        cleared = self.cache.clear_all()
        self.assertEqual(cleared, 3)

        # Verify all are cleared
        for i in range(3):
            cache_key = f'test_key_{i}'
            loaded = self.cache.load_review(cache_key)
            self.assertIsNone(loaded)

    def test_cache_signature_verification(self):
        """Test HMAC signature verification for cache integrity."""
        review_results = [{'critic_name': 'Test', 'critic_role': 'Test', 'verdict': 'APPROVE',
                          'confidence': 5, 'review_text': 'Test', 'icon': 'T', 'color': 'red'}]
        consensus = {'decision': 'APPROVED', 'votes': {'APPROVE': 1}, 'unanimous': True, 'majority': True}

        cache_key = 'test_key_sig'
        self.cache.save_review(cache_key, review_results, consensus)

        # Load should succeed with valid signature
        loaded = self.cache.load_review(cache_key)
        self.assertIsNotNone(loaded)

    def test_get_cache_stats(self):
        """Test getting cache statistics."""
        review_results = [{'critic_name': 'Test', 'critic_role': 'Test', 'verdict': 'APPROVE',
                          'confidence': 5, 'review_text': 'Test', 'icon': 'T', 'color': 'red'}]
        consensus = {'decision': 'APPROVED', 'votes': {'APPROVE': 1}, 'unanimous': True, 'majority': True}

        # Save some entries
        for i in range(3):
            cache_key = f'test_key_{i}'
            self.cache.save_review(cache_key, review_results, consensus)

        # Get stats
        stats = self.cache.get_cache_stats()
        self.assertEqual(stats['total_entries'], 3)
        self.assertIn('type_counts', stats)
        self.assertIn('total_size_bytes', stats)

    def test_file_metadata_cache(self):
        """Test saving and loading file metadata."""
        filepath = '/test/file.py'
        metadata = {'size': 1024, 'lines': 50, 'language': 'python'}

        # Save metadata
        success = self.cache.save_file_metadata(filepath, metadata)
        self.assertTrue(success)

        # Load metadata
        loaded = self.cache.load_file_metadata(filepath)
        self.assertIsNotNone(loaded)
        self.assertEqual(loaded['size'], 1024)
        self.assertEqual(loaded['lines'], 50)

    def test_nonexistent_cache_key(self):
        """Test loading with nonexistent cache key."""
        loaded = self.cache.load_review('nonexistent_key')
        self.assertIsNone(loaded)


if __name__ == '__main__':
    unittest.main()
