"""
Tests for consensus calculation edge cases.

T-001: Tests for FIX-001 - Non-deterministic consensus tie-breaking.

These tests verify that the ConsensusCalculator correctly handles all
tie scenarios with deterministic behavior using the explicit tie-breaking
order: REJECT > NEEDS_WORK > APPROVE.
"""
import unittest
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from council.review import ConsensusCalculator
from council.models import ReviewResult, CodeRating


class TestConsensusTies(unittest.TestCase):
    """Test consensus calculation with tie scenarios (FIX-001)."""

    def test_three_way_tie_1_1_1(self):
        """
        T-001.1: 1-1-1 tie should use tiebreaker (REJECT).

        When each critic votes differently, the tie-breaking order should
        select REJECT as the safest outcome.
        """
        reviews = [
            ReviewResult(
                critic_name="Security Specialist",
                critic_role="Security expert",
                verdict='APPROVE',
                confidence=8,
                review_text="Looks good",
                icon="",
                color="",
                rating=None
            ),
            ReviewResult(
                critic_name="Performance Engineer",
                critic_role="Performance expert",
                verdict='REJECT',
                confidence=7,
                review_text="Too slow",
                icon="",
                color="",
                rating=None
            ),
            ReviewResult(
                critic_name="Clean Code Advocate",
                critic_role="Code quality expert",
                verdict='NEEDS_WORK',
                confidence=6,
                review_text="Needs refactoring",
                icon="",
                color="",
                rating=None
            ),
        ]
        consensus = ConsensusCalculator.calculate_consensus(reviews)

        # Should use tiebreaker: REJECT > NEEDS_WORK > APPROVE
        self.assertEqual(consensus.decision, 'REJECTED',
                        "Three-way tie should resolve to REJECTED")
        self.assertFalse(consensus.unanimous,
                        "Three-way tie is not unanimous")
        self.assertFalse(consensus.majority,
                        "Three-way tie has no majority")

    def test_two_way_tie_approve_needs_work(self):
        """
        T-001.2: 1-1-0 tie between APPROVE and NEEDS_WORK.

        Two critics voted, one APPROVE and one NEEDS_WORK.
        Tie-breaking should prefer NEEDS_WORK over APPROVE.
        """
        reviews = [
            ReviewResult(
                critic_name="Security Specialist",
                critic_role="Security expert",
                verdict='APPROVE',
                confidence=8,
                review_text="Looks good",
                icon="",
                color="",
                rating=None
            ),
            ReviewResult(
                critic_name="Performance Engineer",
                critic_role="Performance expert",
                verdict='NEEDS_WORK',
                confidence=7,
                review_text="Needs improvement",
                icon="",
                color="",
                rating=None
            ),
        ]
        consensus = ConsensusCalculator.calculate_consensus(reviews)

        # Tiebreaker: NEEDS_WORK > APPROVE
        self.assertEqual(consensus.decision, 'NEEDS_WORK',
                        "APPROVE/NEEDS_WORK tie should resolve to NEEDS_WORK")
        self.assertFalse(consensus.unanimous,
                        "Two-way tie is not unanimous")

    def test_two_way_tie_reject_approve(self):
        """
        T-001.3: 1-1-0 tie between REJECT and APPROVE.

        Tie-breaking should prefer REJECT over APPROVE.
        """
        reviews = [
            ReviewResult(
                critic_name="Security Specialist",
                critic_role="Security expert",
                verdict='REJECT',
                confidence=8,
                review_text="Security issue",
                icon="",
                color="",
                rating=None
            ),
            ReviewResult(
                critic_name="Performance Engineer",
                critic_role="Performance expert",
                verdict='APPROVE',
                confidence=7,
                review_text="Looks good",
                icon="",
                color="",
                rating=None
            ),
        ]
        consensus = ConsensusCalculator.calculate_consensus(reviews)

        # Tiebreaker: REJECT > APPROVE
        self.assertEqual(consensus.decision, 'REJECTED',
                        "REJECT/APPROVE tie should resolve to REJECTED")

    def test_two_way_tie_reject_needs_work(self):
        """
        T-001.4: 1-1-0 tie between REJECT and NEEDS_WORK.

        Tie-breaking should prefer REJECT over NEEDS_WORK.
        """
        reviews = [
            ReviewResult(
                critic_name="Security Specialist",
                critic_role="Security expert",
                verdict='REJECT',
                confidence=8,
                review_text="Security issue",
                icon="",
                color="",
                rating=None
            ),
            ReviewResult(
                critic_name="Performance Engineer",
                critic_role="Performance expert",
                verdict='NEEDS_WORK',
                confidence=7,
                review_text="Needs improvement",
                icon="",
                color="",
                rating=None
            ),
        ]
        consensus = ConsensusCalculator.calculate_consensus(reviews)

        # Tiebreaker: REJECT > NEEDS_WORK
        self.assertEqual(consensus.decision, 'REJECTED',
                        "REJECT/NEEDS_WORK tie should resolve to REJECTED")

    def test_unanimous_approve(self):
        """
        T-001.5: 3-0-0 unanimous APPROVE.

        All critics agree to approve - no tie-breaking needed.
        """
        reviews = [
            ReviewResult(
                critic_name="Security Specialist",
                critic_role="Security expert",
                verdict='APPROVE',
                confidence=8,
                review_text="Looks good",
                icon="",
                color="",
                rating=None
            ),
            ReviewResult(
                critic_name="Performance Engineer",
                critic_role="Performance expert",
                verdict='APPROVE',
                confidence=9,
                review_text="Efficient",
                icon="",
                color="",
                rating=None
            ),
            ReviewResult(
                critic_name="Clean Code Advocate",
                critic_role="Code quality expert",
                verdict='APPROVE',
                confidence=8,
                review_text="Clean code",
                icon="",
                color="",
                rating=None
            ),
        ]
        consensus = ConsensusCalculator.calculate_consensus(reviews)

        self.assertEqual(consensus.decision, 'APPROVED')
        self.assertTrue(consensus.unanimous,
                       "All approve should be unanimous")
        self.assertTrue(consensus.majority,
                      "All approve is also a majority")

    def test_unanimous_reject(self):
        """
        T-001.6: 0-3-0 unanimous REJECT.

        All critics agree to reject - no tie-breaking needed.
        """
        reviews = [
            ReviewResult(
                critic_name="Security Specialist",
                critic_role="Security expert",
                verdict='REJECT',
                confidence=8,
                review_text="Security issue",
                icon="",
                color="",
                rating=None
            ),
            ReviewResult(
                critic_name="Performance Engineer",
                critic_role="Performance expert",
                verdict='REJECT',
                confidence=9,
                review_text="Too slow",
                icon="",
                color="",
                rating=None
            ),
            ReviewResult(
                critic_name="Clean Code Advocate",
                critic_role="Code quality expert",
                verdict='REJECT',
                confidence=8,
                review_text="Poor quality",
                icon="",
                color="",
                rating=None
            ),
        ]
        consensus = ConsensusCalculator.calculate_consensus(reviews)

        self.assertEqual(consensus.decision, 'REJECTED')
        self.assertTrue(consensus.unanimous,
                       "All reject should be unanimous")

    def test_majority_two_approve_one_reject(self):
        """
        T-001.7: 2-1-0 majority APPROVE.

        Two critics approve, one rejects - majority wins.
        """
        reviews = [
            ReviewResult(
                critic_name="Security Specialist",
                critic_role="Security expert",
                verdict='APPROVE',
                confidence=8,
                review_text="Looks good",
                icon="",
                color="",
                rating=None
            ),
            ReviewResult(
                critic_name="Performance Engineer",
                critic_role="Performance expert",
                verdict='APPROVE',
                confidence=9,
                review_text="Efficient",
                icon="",
                color="",
                rating=None
            ),
            ReviewResult(
                critic_name="Clean Code Advocate",
                critic_role="Code quality expert",
                verdict='REJECT',
                confidence=5,
                review_text="Has issues",
                icon="",
                color="",
                rating=None
            ),
        ]
        consensus = ConsensusCalculator.calculate_consensus(reviews)

        self.assertEqual(consensus.decision, 'APPROVED')
        self.assertFalse(consensus.unanimous,
                        "2-1 split is not unanimous")
        self.assertTrue(consensus.majority,
                      "2-1 split has a majority")

    def test_majority_two_reject_one_approve(self):
        """
        T-001.8: 1-2-0 majority REJECT.

        Two critics reject, one approves - majority wins.
        """
        reviews = [
            ReviewResult(
                critic_name="Security Specialist",
                critic_role="Security expert",
                verdict='APPROVE',
                confidence=5,
                review_text="Looks okay",
                icon="",
                color="",
                rating=None
            ),
            ReviewResult(
                critic_name="Performance Engineer",
                critic_role="Performance expert",
                verdict='REJECT',
                confidence=9,
                review_text="Critical issues",
                icon="",
                color="",
                rating=None
            ),
            ReviewResult(
                critic_name="Clean Code Advocate",
                critic_role="Code quality expert",
                verdict='REJECT',
                confidence=8,
                review_text="Poor quality",
                icon="",
                color="",
                rating=None
            ),
        ]
        consensus = ConsensusCalculator.calculate_consensus(reviews)

        self.assertEqual(consensus.decision, 'REJECTED')
        self.assertFalse(consensus.unanimous)
        self.assertTrue(consensus.majority)

    def test_deterministic_behavior_same_reviews(self):
        """
        T-001.9: Same input should always produce same output.

        Run consensus calculation multiple times with same input
        to verify deterministic behavior.
        """
        reviews = [
            ReviewResult(
                critic_name="Security Specialist",
                critic_role="Security expert",
                verdict='APPROVE',
                confidence=8,
                review_text="Looks good",
                icon="",
                color="",
                rating=None
            ),
            ReviewResult(
                critic_name="Performance Engineer",
                critic_role="Performance expert",
                verdict='REJECT',
                confidence=7,
                review_text="Issues found",
                icon="",
                color="",
                rating=None
            ),
            ReviewResult(
                critic_name="Clean Code Advocate",
                critic_role="Code quality expert",
                verdict='NEEDS_WORK',
                confidence=6,
                review_text="Needs work",
                icon="",
                color="",
                rating=None
            ),
        ]

        # Run multiple times and verify same result
        results = []
        for _ in range(10):
            consensus = ConsensusCalculator.calculate_consensus(reviews)
            results.append(consensus.decision)

        # All results should be identical
        self.assertEqual(len(set(results)), 1,
                        "All consensus calculations should produce identical result")
        self.assertEqual(results[0], 'REJECTED',
                        "Should deterministically resolve to REJECTED")

    def test_vote_counts_correct(self):
        """
        T-001.10: Verify vote counts are accurately tracked.

        """
        reviews = [
            ReviewResult(
                critic_name="Security Specialist",
                critic_role="Security expert",
                verdict='APPROVE',
                confidence=8,
                review_text="Looks good",
                icon="",
                color="",
                rating=None
            ),
            ReviewResult(
                critic_name="Performance Engineer",
                critic_role="Performance expert",
                verdict='APPROVE',
                confidence=9,
                review_text="Efficient",
                icon="",
                color="",
                rating=None
            ),
            ReviewResult(
                critic_name="Clean Code Advocate",
                critic_role="Code quality expert",
                verdict='NEEDS_WORK',
                confidence=7,
                review_text="Minor issues",
                icon="",
                color="",
                rating=None
            ),
        ]
        consensus = ConsensusCalculator.calculate_consensus(reviews)

        # Check vote counts
        self.assertEqual(consensus.votes['APPROVE'], 2)
        self.assertEqual(consensus.votes['REJECT'], 0)
        self.assertEqual(consensus.votes['NEEDS_WORK'], 1)
        self.assertEqual(consensus.decision, 'APPROVED')

    def test_single_critic_scenario(self):
        """
        T-001.11: Edge case with only one critic.

        """
        reviews = [
            ReviewResult(
                critic_name="Security Specialist",
                critic_role="Security expert",
                verdict='APPROVE',
                confidence=8,
                review_text="Looks good",
                icon="",
                color="",
                rating=None
            ),
        ]
        consensus = ConsensusCalculator.calculate_consensus(reviews)

        self.assertEqual(consensus.decision, 'APPROVED')
        self.assertEqual(consensus.votes['APPROVE'], 1)
        self.assertEqual(consensus.votes['REJECT'], 0)
        self.assertEqual(consensus.votes['NEEDS_WORK'], 0)


if __name__ == '__main__':
    unittest.main()
