"""
Tests for content deduplication module.

Tests MinHash, LSH, and ContentDeduplicator functionality.
"""
import unittest
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from council.deduplication import MinHashGenerator, LSHIndex, ContentDeduplicator


class TestMinHashGenerator(unittest.TestCase):
    """Test MinHash signature generation."""

    def setUp(self):
        """Set up test fixtures."""
        self.minhash = MinHashGenerator(num_permutations=128, seed=42)

    def test_signature_generation(self):
        """Test that signatures are generated correctly."""
        content = "Hello world this is a test"
        signature = self.minhash.generate_signature(content)

        # Signature should be a list of integers
        self.assertIsInstance(signature, list)
        self.assertEqual(len(signature), 128)
        self.assertTrue(all(isinstance(x, int) for x in signature))

    def test_signature_deterministic(self):
        """Test that same content produces same signature."""
        content = "Hello world this is a test"
        sig1 = self.minhash.generate_signature(content)
        sig2 = self.minhash.generate_signature(content)

        self.assertEqual(sig1, sig2)

    def test_signature_different_content(self):
        """Test that different content produces different signatures."""
        content1 = "Hello world this is a test"
        content2 = "This is completely different content"
        sig1 = self.minhash.generate_signature(content1)
        sig2 = self.minhash.generate_signature(content2)

        # Signatures should be different (with high probability)
        different_count = sum(1 for a, b in zip(sig1, sig2) if a != b)
        self.assertGreater(different_count, 50)  # At least 50% different

    def test_jaccard_similarity_identical(self):
        """Test Jaccard similarity for identical content."""
        content = "Hello world this is a test"
        sig1 = self.minhash.generate_signature(content)
        sig2 = self.minhash.generate_signature(content)

        similarity = self.minhash.jaccard_similarity(sig1, sig2)
        self.assertEqual(similarity, 1.0)

    def test_jaccard_similarity_different(self):
        """Test Jaccard similarity for different content."""
        content1 = "Hello world this is a test"
        content2 = "Completely different text with no overlap"
        sig1 = self.minhash.generate_signature(content1)
        sig2 = self.minhash.generate_signature(content2)

        similarity = self.minhash.jaccard_similarity(sig1, sig2)
        self.assertLess(similarity, 0.5)

    def test_jaccard_similarity_similar(self):
        """Test Jaccard similarity for similar content."""
        content1 = "Hello world this is a test of the system"
        content2 = "Hello world this is a test of the code"
        sig1 = self.minhash.generate_signature(content1)
        sig2 = self.minhash.generate_signature(content2)

        similarity = self.minhash.jaccard_similarity(sig1, sig2)
        self.assertGreater(similarity, 0.5)

    def test_shingle_document_short(self):
        """Test shingling with short document."""
        # Use a string with at least 3 characters for k=3 shingling
        content = "Hello"
        shingles = self.minhash._shingle_document(content, k=3)

        # Should fall back to character shingles for very short documents
        self.assertIsInstance(shingles, set)
        self.assertGreater(len(shingles), 0)

    def test_shingle_document_normal(self):
        """Test shingling with normal document."""
        content = "Hello world this is a test of the system"
        shingles = self.minhash._shingle_document(content, k=3)

        # Should create word-based shingles
        self.assertIsInstance(shingles, set)
        self.assertGreater(len(shingles), 0)


class TestLSHIndex(unittest.TestCase):
    """Test Locality-Sensitive Hashing index."""

    def setUp(self):
        """Set up test fixtures."""
        self.lsh = LSHIndex(num_bands=16, rows_per_band=8)
        self.minhash = MinHashGenerator(num_permutations=128, seed=42)

    def test_add_and_find_candidates(self):
        """Test adding documents and finding candidates."""
        # Create signatures for similar documents
        content1 = "Hello world this is a test of the system"
        content2 = "Hello world this is a test of the code"
        content3 = "Completely different text with no overlap"

        sig1 = self.minhash.generate_signature(content1)
        sig2 = self.minhash.generate_signature(content2)
        sig3 = self.minhash.generate_signature(content3)

        # Add to LSH index
        self.lsh.add("file1.py", sig1)
        self.lsh.add("file2.py", sig2)
        self.lsh.add("file3.py", sig3)

        # Find candidates for file1 (should find file2 due to similarity)
        candidates = self.lsh.find_candidates(sig1)
        self.assertIn("file1.py", candidates)
        self.assertIn("file2.py", candidates)  # Similar content

        # Find candidates for file3 (should only find itself)
        candidates = self.lsh.find_candidates(sig3)
        self.assertIn("file3.py", candidates)

    def test_lsh_consistency(self):
        """Test that LSH produces consistent results."""
        content = "Hello world this is a test"
        sig = self.minhash.generate_signature(content)

        # Add multiple times
        self.lsh.add("file1.py", sig)
        self.lsh.add("file2.py", sig)

        # Should find both
        candidates = self.lsh.find_candidates(sig)
        self.assertIn("file1.py", candidates)
        self.assertIn("file2.py", candidates)


class TestContentDeduplicator(unittest.TestCase):
    """Test content deduplication functionality."""

    def setUp(self):
        """Set up test fixtures."""
        self.deduplicator = ContentDeduplicator(similarity_threshold=0.9)

    def test_find_exact_duplicates(self):
        """Test finding exact duplicate files."""
        files_content = {
            "file1.py": "def hello():\n    print('world')",
            "file2.py": "def hello():\n    print('world')",  # Exact duplicate
            "file3.py": "def goodbye():\n    print('world')",
        }

        duplicates, file_hashes = self.deduplicator.find_duplicates(files_content)

        # Should find one duplicate group
        self.assertEqual(len(duplicates), 1)
        duplicate_group = list(duplicates.values())[0]
        self.assertEqual(len(duplicate_group), 2)
        self.assertIn("file1.py", duplicate_group)
        self.assertIn("file2.py", duplicate_group)

    def test_find_no_duplicates(self):
        """Test when there are no duplicates."""
        files_content = {
            "file1.py": "def hello():\n    print('world')",
            "file2.py": "def goodbye():\n    print('world')",
            "file3.py": "def foo():\n    print('bar')",
        }

        duplicates, _ = self.deduplicator.find_duplicates(files_content)

        # Should find no duplicates
        self.assertEqual(len(duplicates), 0)

    def test_deduplicate_files(self):
        """Test file deduplication."""
        files_content = {
            "file1.py": "def hello():\n    print('world')",
            "file2.py": "def hello():\n    print('world')",  # Duplicate
            "file3.py": "def goodbye():\n    print('world')",
        }

        unique_files, duplicate_mapping = self.deduplicator.deduplicate_files(files_content)

        # Should have 2 unique files (one duplicate removed)
        self.assertEqual(len(unique_files), 2)

        # Should have mapping for the duplicate group
        self.assertEqual(len(duplicate_mapping), 1)

    def test_find_similar_files(self):
        """Test finding similar files."""
        # Use larger, more similar files to ensure detection with 32 permutations
        base_content = """# Sample Python module
def hello_world_function():
    '''A hello world function.'''
    print('hello world')
    return True

def another_function():
    '''Another function.'''
    pass

# More code here
# And even more code
# Keep going with the code
# Almost there
# """
        files_content = {
            "file1.py": base_content + "# Final line",
            "file2.py": base_content + "# Final line two",  # Very similar (only difference is last word)
            "file3.py": "def completely_different():\n    pass\n# Totally different\n# Not similar at all",
        }

        similar_pairs = self.deduplicator.find_similar_files(files_content)

        # Should find file1 and file2 as similar (with high similarity)
        self.assertGreater(len(similar_pairs), 0)

        # Check that the pair was found
        pair_found = any(
            (f1 == "file1.py" and f2 == "file2.py") or (f1 == "file2.py" and f2 == "file1.py")
            for f1, f2, _ in similar_pairs
        )
        self.assertTrue(pair_found)

    def test_identify_boilerplate(self):
        """Test identifying boilerplate files."""
        files_content = {
            "file1.py": "# Generated by tool\n# DO NOT EDIT\ndef foo(): pass",
            "file2.py": "# Copyright 2024\n# All rights reserved\ndef bar(): pass",
            "file3.py": "def normal(): pass",
        }

        boilerplate = self.deduplicator.identify_boilerplate(files_content)

        # Should identify file1 and file2 as boilerplate
        self.assertIn("file1.py", boilerplate)
        self.assertIn("file2.py", boilerplate)
        self.assertNotIn("file3.py", boilerplate)

    def test_empty_files(self):
        """Test handling empty file dictionary."""
        files_content = {}

        duplicates, file_hashes = self.deduplicator.find_duplicates(files_content)
        self.assertEqual(len(duplicates), 0)
        self.assertEqual(len(file_hashes), 0)

        similar_pairs = self.deduplicator.find_similar_files(files_content)
        self.assertEqual(len(similar_pairs), 0)


if __name__ == '__main__':
    unittest.main()
