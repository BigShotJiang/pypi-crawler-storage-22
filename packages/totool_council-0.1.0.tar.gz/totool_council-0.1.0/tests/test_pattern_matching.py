"""
Tests for file pattern matching functionality.

Tests ignore patterns, file extension filtering, and file collection.
"""
import unittest
import tempfile
import os
import sys

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from council.files import FileCollector
from council.output import OutputFormatter, NoColors


class TestFileCollector(unittest.TestCase):
    """Test file collection and filtering functionality."""

    def setUp(self):
        """Set up test fixtures."""
        self.test_dir = tempfile.mkdtemp()
        self.output_formatter = OutputFormatter(NoColors)

        # Create test file structure
        self.create_test_structure()

    def tearDown(self):
        """Clean up test directory."""
        import shutil
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def create_test_structure(self):
        """Create a test directory structure with various files."""
        # Create directories
        os.makedirs(os.path.join(self.test_dir, 'src'))
        os.makedirs(os.path.join(self.test_dir, 'tests'))
        os.makedirs(os.path.join(self.test_dir, '.git'))

        # Create Python files
        with open(os.path.join(self.test_dir, 'main.py'), 'w') as f:
            f.write('print("hello")')

        with open(os.path.join(self.test_dir, 'src', 'module.py'), 'w') as f:
            f.write('def test(): pass')

        # Create test file
        with open(os.path.join(self.test_dir, 'tests', 'test_main.py'), 'w') as f:
            f.write('def test(): pass')

        # Create files to ignore
        with open(os.path.join(self.test_dir, '.git', 'config'), 'w') as f:
            f.write('[core]')

        # Create node_modules directory first, then the file
        os.makedirs(os.path.join(self.test_dir, 'node_modules'), exist_ok=True)
        with open(os.path.join(self.test_dir, 'node_modules', 'package.json'), 'w') as f:
            f.write('{}')

        # Create different file types
        with open(os.path.join(self.test_dir, 'README.md'), 'w') as f:
            f.write('# README')

        with open(os.path.join(self.test_dir, 'config.json'), 'w') as f:
            f.write('{}')

        with open(os.path.join(self.test_dir, 'script.sh'), 'w') as f:
            f.write('#!/bin/bash')

    def test_collect_python_files(self):
        """Test collecting Python files."""
        collector = FileCollector([], self.output_formatter)
        files_content, files_metadata = collector.collect_project_files(self.test_dir)

        # Should collect .py files
        py_files = [f for f in files_content.keys() if f.endswith('.py')]
        self.assertGreater(len(py_files), 0)

    def test_collect_with_ignore_patterns(self):
        """Test file collection with ignore patterns."""
        ignore_patterns = ['tests/', 'node_modules/']
        collector = FileCollector(ignore_patterns, self.output_formatter)
        files_content, files_metadata = collector.collect_project_files(self.test_dir)

        # Should not collect files from ignored directories
        for filepath in files_content.keys():
            self.assertFalse('tests/' in filepath or 'node_modules/' in filepath)

    def test_collect_text_files_only(self):
        """Test that only text files are collected."""
        collector = FileCollector([], self.output_formatter)
        files_content, files_metadata = collector.collect_project_files(self.test_dir)

        # All collected files should have text extensions
        text_extensions = {'.py', '.md', '.json', '.sh', '.yaml', '.yml', '.txt'}
        for filepath in files_content.keys():
            ext = os.path.splitext(filepath)[1]
            self.assertIn(ext, text_extensions)

    def test_ignore_git_directory(self):
        """Test that .git directory is ignored by default."""
        collector = FileCollector([], self.output_formatter)
        files_content, files_metadata = collector.collect_project_files(self.test_dir)

        # Should not collect files from .git
        for filepath in files_content.keys():
            self.assertNotIn('.git', filepath)

    def test_collect_filepaths_and_metadata(self):
        """Test collecting file paths without loading content."""
        collector = FileCollector([], self.output_formatter)
        filepaths, files_metadata = collector.collect_filepaths_and_metadata(self.test_dir)

        # Should return paths and metadata
        self.assertGreater(len(filepaths), 0)
        self.assertEqual(len(filepaths), len(files_metadata))

        # Metadata should contain size and mtime
        for filepath, metadata in files_metadata.items():
            self.assertEqual(len(metadata), 2)  # (size, mtime)
            size, mtime = metadata
            self.assertGreater(size, 0)
            self.assertGreater(mtime, 0)

    def test_estimate_project_size(self):
        """Test project size estimation."""
        collector = FileCollector([], self.output_formatter)
        total_files, total_size_bytes, eligible_files = collector.estimate_project_size(self.test_dir)

        # Should return valid estimates
        self.assertGreater(total_files, 0)
        self.assertGreater(total_size_bytes, 0)
        self.assertGreater(eligible_files, 0)

    def test_should_ignore_file_pattern(self):
        """Test pattern matching for ignore rules."""
        collector = FileCollector(['*.pyc', '__pycache__'], self.output_formatter)

        # Should ignore .pyc files
        self.assertTrue(collector.should_ignore_file('test.pyc'))
        self.assertTrue(collector.should_ignore_file('__pycache__'))

        # Should not ignore regular files
        self.assertFalse(collector.should_ignore_file('test.py'))
        self.assertFalse(collector.should_ignore_file('README.md'))

    def test_is_text_file(self):
        """Test text file detection."""
        collector = FileCollector([], self.output_formatter)

        # Should recognize text files
        self.assertTrue(collector.is_text_file('test.py'))
        self.assertTrue(collector.is_text_file('test.md'))
        self.assertTrue(collector.is_text_file('test.json'))

        # Should not recognize binary files
        self.assertFalse(collector.is_text_file('test.png'))
        self.assertFalse(collector.is_text_file('test.jpg'))
        self.assertFalse(collector.is_text_file('test.zip'))

    def test_chunk_files_by_size(self):
        """Test chunking files by size."""
        files_content = {
            'file1.py': 'x' * 4000,  # ~1000 tokens
            'file2.py': 'y' * 4000,
            'file3.py': 'z' * 4000,
        }

        collector = FileCollector([], self.output_formatter)
        chunks = collector.chunk_files(files_content, strategy="size", user_chunk_size=2000)

        # Should create multiple chunks
        self.assertGreater(len(chunks), 1)

    def test_chunk_files_by_directory(self):
        """Test chunking files by directory."""
        files_content = {
            'src/module1.py': 'content1',
            'src/module2.py': 'content2',
            'tests/test.py': 'content3',
        }

        collector = FileCollector([], self.output_formatter)
        chunks = collector.chunk_files(files_content, strategy="directory", user_chunk_size=10000)

        # Should group by directory
        self.assertGreater(len(chunks), 0)

    def test_chunk_files_by_type(self):
        """Test chunking files by type."""
        files_content = {
            'file1.py': 'content1',
            'file2.py': 'content2',
            'README.md': 'content3',
        }

        collector = FileCollector([], self.output_formatter)
        chunks = collector.chunk_files(files_content, strategy="type", user_chunk_size=10000)

        # Should group by file type
        self.assertGreater(len(chunks), 0)

    def test_should_chunk(self):
        """Test chunking decision logic."""
        # Create a large file collection that exceeds the token threshold
        # MAX_CONTEXT_TOKENS is 128000, so we need > 512000 chars
        files_content = {f'file{i}.py': 'x' * 11000 for i in range(50)}

        collector = FileCollector([], self.output_formatter)
        should_chunk = collector.should_chunk(files_content)

        # Should decide to chunk large collections
        self.assertTrue(should_chunk)

    def test_collect_single_file(self):
        """Test collecting a single file."""
        test_file = os.path.join(self.test_dir, 'single.py')
        with open(test_file, 'w') as f:
            f.write('print("single file")')

        collector = FileCollector([], self.output_formatter)
        files_content, files_metadata = collector.collect_project_files(test_file)

        # Should collect the single file
        self.assertEqual(len(files_content), 1)
        self.assertIn(test_file, files_content)


class TestPatternMatching(unittest.TestCase):
    """Test specific pattern matching scenarios."""

    def setUp(self):
        """Set up test fixtures."""
        self.test_dir = tempfile.mkdtemp()
        self.output_formatter = OutputFormatter(NoColors)

    def tearDown(self):
        """Clean up test directory."""
        import shutil
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_wildcard_pattern(self):
        """Test wildcard pattern matching."""
        collector = FileCollector(['*.pyc'], self.output_formatter)

        # Should match any .pyc file
        self.assertTrue(collector.should_ignore_file('test.pyc'))
        self.assertTrue(collector.should_ignore_file('module.pyc'))
        self.assertFalse(collector.should_ignore_file('test.py'))

    def test_directory_pattern(self):
        """Test directory pattern matching."""
        collector = FileCollector(['node_modules'], self.output_formatter)

        # Should match node_modules directory
        self.assertTrue(collector.should_ignore_file('node_modules/package.json'))
        self.assertTrue(collector.should_ignore_file('path/to/node_modules/file.js'))
        self.assertFalse(collector.should_ignore_file('package.json'))

    def test_path_seperator_pattern(self):
        """Test patterns with path separators."""
        collector = FileCollector(['build/'], self.output_formatter)

        # Should match build directory (component-wise matching)
        self.assertTrue(collector.should_ignore_file('build/output.txt'))
        # With component-wise matching, build_backup should NOT match
        # because only 'build' component matches the pattern, not 'build_backup'
        self.assertFalse(collector.should_ignore_file('build_backup/output.txt'))

        # Test with a pattern that won't match build_backup
        collector2 = FileCollector(['/build/'], self.output_formatter)
        self.assertTrue(collector2.should_ignore_file('build/output.txt'))
        # With leading slash, it's more specific but still uses component-wise matching
        self.assertTrue(collector2.should_ignore_file('build/output.txt'))

    def test_case_insensitive_matching(self):
        """Test that matching is case-insensitive."""
        collector = FileCollector(['NODE_MODULES'], self.output_formatter)

        # Should match regardless of case
        self.assertTrue(collector.should_ignore_file('node_modules/package.json'))
        self.assertTrue(collector.should_ignore_file('Node_Modules/package.json'))


if __name__ == '__main__':
    unittest.main()
