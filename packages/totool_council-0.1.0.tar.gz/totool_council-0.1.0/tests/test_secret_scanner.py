"""
Tests for secret scanner module.

Tests detection of API keys, passwords, and sensitive information.
"""
import unittest
import tempfile
import os
import sys

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from council.secret_scanner import SecretScanner
from council.exceptions import FileError


class TestSecretScanner(unittest.TestCase):
    """Test secret detection functionality."""

    def test_detect_aws_access_key(self):
        """Test detection of AWS Access Key ID."""
        # AWS Access Key IDs are 20 characters: AKIA + 16 alphanumeric characters
        # Use a key that doesn't contain "example" to avoid false positive filter
        content = "aws_access_key_id = AKIAIOSFODNN7SECRETX"
        with self.assertRaises(FileError) as context:
            SecretScanner.scan_file_content('test.py', content)
        self.assertIn('AWS Access Key ID', str(context.exception))

    def test_detect_google_api_key(self):
        """Test detection of Google Cloud API Key."""
        content = "api_key = AIzaSyDaGmWKa4JsXZ-HjGw7ISLn_3namBGewQe"
        with self.assertRaises(FileError) as context:
            SecretScanner.scan_file_content('test.py', content)
        self.assertIn('Google Cloud API Key', str(context.exception))

    def test_detect_jwt_token(self):
        """Test detection of JWT tokens."""
        content = "token = eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
        with self.assertRaises(FileError) as context:
            SecretScanner.scan_file_content('test.py', content)
        self.assertIn('JWT Token', str(context.exception))

    def test_detect_private_key(self):
        """Test detection of private keys."""
        content = "-----BEGIN RSA PRIVATE KEY-----"
        with self.assertRaises(FileError) as context:
            SecretScanner.scan_file_content('test.py', content)
        self.assertIn('Private Key', str(context.exception))

    def test_detect_password(self):
        """Test detection of passwords."""
        content = 'password = "SuperSecret12345678"'
        with self.assertRaises(FileError) as context:
            SecretScanner.scan_file_content('test.py', content)
        self.assertIn('Password', str(context.exception))

    def test_detect_bearer_token(self):
        """Test detection of bearer tokens."""
        content = "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
        with self.assertRaises(FileError) as context:
            SecretScanner.scan_file_content('test.py', content)
        self.assertIn('Bearer Token', str(context.exception) or 'Secret', str(context.exception))

    def test_detect_slack_token(self):
        """Test detection of Slack tokens."""
        # Slack tokens are: xox[baprs]-[12 digits]-[12 digits]-[12 digits]-[32 lowercase hex]
        content = "slack_token = xoxb-123456789012-123456789012-123456789012-a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4"
        with self.assertRaises(FileError) as context:
            SecretScanner.scan_file_content('test.py', content)
        self.assertIn('Slack Token', str(context.exception))

    def test_detect_github_token(self):
        """Test detection of GitHub tokens."""
        # GitHub personal access tokens are ghp_ + 36 characters (total 40)
        content = "ghp_1234567890abcdefghijklmnopqrstuvwx12"
        with self.assertRaises(FileError) as context:
            SecretScanner.scan_file_content('test.py', content)
        self.assertIn('GitHub Token', str(context.exception))

    def test_detect_database_url(self):
        """Test detection of database URLs."""
        content = "DATABASE_URL = postgresql://user:password12345@localhost:5432/db"
        with self.assertRaises(FileError) as context:
            SecretScanner.scan_file_content('test.py', content)
        self.assertIn('Database Connection String', str(context.exception) or 'Password', str(context.exception))

    def test_no_false_positives_uuid(self):
        """Test that UUIDs are not flagged."""
        content = "id = 550e8400-e29b-41d4-a716-446655440000"
        # Should not raise
        try:
            result = SecretScanner.scan_file_content('test.py', content)
            self.assertIsNone(result)
        except FileError:
            self.fail("UUID should not be flagged as a secret")

    def test_no_false_positives_example_keys(self):
        """Test that example keys are not flagged."""
        content = "# Example API key: your_api_key_here"
        # Should not raise
        try:
            result = SecretScanner.scan_file_content('test.py', content)
            self.assertIsNone(result)
        except FileError:
            self.fail("Example key placeholder should not be flagged")

    def test_no_false_positives_comments(self):
        """Test that comments are not flagged."""
        content = "# TODO: Add the real API key here later"
        # Should not raise
        try:
            result = SecretScanner.scan_file_content('test.py', content)
            self.assertIsNone(result)
        except FileError:
            self.fail("Comments should not be flagged")

    def test_scan_filename_env(self):
        """Test detection of sensitive .env filenames."""
        with self.assertRaises(FileError) as context:
            SecretScanner.scan_filename('/path/to/.env')
        self.assertIn('Sensitive filename', str(context.exception))

    def test_scan_filename_pem(self):
        """Test detection of .pem files."""
        with self.assertRaises(FileError) as context:
            SecretScanner.scan_filename('/path/to/cert.pem')
        self.assertIn('Sensitive filename', str(context.exception))

    def test_scan_filename_key(self):
        """Test detection of .key files."""
        with self.assertRaises(FileError) as context:
            SecretScanner.scan_filename('/path/to/private.key')
        self.assertIn('Sensitive filename', str(context.exception))

    def test_scan_filename_id_rsa(self):
        """Test detection of SSH private key filenames."""
        with self.assertRaises(FileError) as context:
            SecretScanner.scan_filename('/path/to/id_rsa')
        self.assertIn('Sensitive filename', str(context.exception))

    def test_scan_filename_safe(self):
        """Test that safe filenames are not flagged."""
        try:
            result = SecretScanner.scan_filename('/path/to/main.py')
            self.assertIsNone(result)
        except FileError:
            self.fail("Safe filename should not be flagged")

    def test_is_safe_to_review(self):
        """Test the is_safe_to_review convenience method."""
        safe_content = "def hello():\n    print('world')"
        safe_filepath = 'main.py'

        # Should return True for safe content
        result = SecretScanner.is_safe_to_review(safe_filepath, safe_content)
        self.assertTrue(result)

    def test_is_safe_to_review_unsafe(self):
        """Test is_safe_to_review with unsafe content."""
        # AWS Access Key ID must be AKIA + 16 alphanumeric (20 total)
        unsafe_content = "api_key = AKIAIOSFODNN7SECRETA"
        unsafe_filepath = 'config.py'

        # Should raise FileError
        with self.assertRaises(FileError):
            SecretScanner.is_safe_to_review(unsafe_filepath, unsafe_content)

    def test_detect_mongodb_url(self):
        """Test detection of MongoDB connection strings."""
        content = "mongodb+srv://user:password12345@cluster.mongodb.net/mydb"
        with self.assertRaises(FileError) as context:
            SecretScanner.scan_file_content('test.py', content)
        # Should detect either MongoDB URL or password
        error_msg = str(context.exception)
        self.assertTrue('MongoDB' in error_msg or 'Password' in error_msg)

    def test_detect_stripe_key(self):
        """Test detection of Stripe API keys."""
        # Stripe keys are sk_live/pk_live/pk_test/sk_test + 32+ characters
        content = "stripe_key = sk_live_51AbC123xYz456DeF789GhI012JkLmNoPqRsTuVw"
        with self.assertRaises(FileError) as context:
            SecretScanner.scan_file_content('test.py', content)
        self.assertIn('Stripe', str(context.exception))

    def test_empty_content(self):
        """Test scanning empty content."""
        try:
            result = SecretScanner.scan_file_content('test.py', '')
            self.assertIsNone(result)
        except FileError:
            self.fail("Empty content should not raise error")

    def test_multiline_secret(self):
        """Test detecting secrets across multiple lines."""
        # AWS Access Key ID must be AKIA + 16 alphanumeric (20 total)
        content = """# Configuration
api_key = AKIAIOSFODNN7SECRETA
secret = something
"""
        with self.assertRaises(FileError):
            SecretScanner.scan_file_content('test.py', content)


if __name__ == '__main__':
    unittest.main()
