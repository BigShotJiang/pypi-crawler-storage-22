"""
Tests for concurrent pattern loading in SecretScanner.

T-002: Tests for FIX-002 - Thread-safe pattern initialization.

These tests verify that the SecretScanner correctly handles concurrent
pattern initialization without race conditions or duplicate patterns.
"""
import unittest
import threading
import time
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from council.secret_scanner import SecretScanner


class TestConcurrentPatternLoading(unittest.TestCase):
    """Test thread-safe pattern initialization (FIX-002)."""

    def setUp(self):
        """Set up test fixtures."""
        # Reset patterns to ensure clean state for each test
        SecretScanner.PATTERNS = []
        SecretScanner.SENSITIVE_FILENAME_PATTERNS = []
        SecretScanner.FALSE_POSITIVE_PATTERNS = []

    def test_concurrent_init_no_errors(self):
        """
        T-002.1: Multiple threads should safely initialize patterns.

        Verify that concurrent calls to _ensure_patterns_loaded do not
        cause errors, crashes, or data corruption.
        """
        errors = []
        results = []

        def try_load():
            """Try to load patterns in a thread."""
            try:
                SecretScanner._ensure_patterns_loaded()
                results.append(len(SecretScanner.PATTERNS))
            except Exception as e:
                errors.append(e)

        # Launch multiple threads simultaneously
        threads = [
            threading.Thread(target=try_load) for _ in range(10)
        ]

        # Start all threads at nearly the same time
        for t in threads:
            t.start()

        # Wait for completion
        for t in threads:
            t.join()

        # Should have no errors
        self.assertEqual(len(errors), 0,
                        f"No errors should occur during concurrent init: {errors}")

        # All threads should see the same number of patterns
        self.assertTrue(all(r == results[0] for r in results),
                       "All threads should see same pattern count")

    def test_no_duplicate_patterns(self):
        """
        T-002.2: Concurrent initialization should not create duplicate patterns.

        Even if multiple threads race to initialize, the final pattern list
        should not contain duplicates.
        """
        # Reset and initialize from multiple threads
        SecretScanner.PATTERNS = []

        def try_load():
            SecretScanner._ensure_patterns_loaded()

        threads = [
            threading.Thread(target=try_load) for _ in range(20)
        ]

        for t in threads:
            t.start()

        for t in threads:
            t.join()

        # Check for duplicates by comparing length with unique count
        # Each pattern is a compiled regex, so compare by pattern string
        pattern_strings = [p.pattern for p in SecretScanner.PATTERNS]
        unique_patterns = set(pattern_strings)

        self.assertEqual(
            len(pattern_strings),
            len(unique_patterns),
            f"Pattern list should not contain duplicates. "
            f"Total: {len(pattern_strings)}, Unique: {len(unique_patterns)}"
        )

    def test_idempotent_initialization(self):
        """
        T-002.3: Multiple initialization calls should be safe and idempotent.

        Calling _ensure_patterns_loaded multiple times from same or different
        threads should always result in the same state.
        """
        # Get initial pattern count
        SecretScanner._ensure_patterns_loaded()
        initial_count = len(SecretScanner.PATTERNS)

        # Call many more times
        for _ in range(100):
            SecretScanner._ensure_patterns_loaded()

        # Count should remain the same
        self.assertEqual(
            len(SecretScanner.PATTERNS),
            initial_count,
            "Pattern count should not change after multiple initializations"
        )

    def test_concurrent_scan_file_content(self):
        """
        T-002.4: Concurrent file scanning should work correctly.

        Multiple threads scanning files simultaneously should trigger
        concurrent pattern loading without errors.

        Note: The test content contains secrets, so FileError is expected.
        The important thing is that pattern loading is thread-safe.
        """
        # Create some test content WITHOUT secrets to avoid FileError
        test_content = """
        import os
        # This is a normal file
        def hello():
            print("Hello, world!")
            return True
        """

        results = []
        errors = []

        def scan_file():
            """Scan file in a thread."""
            try:
                result = SecretScanner.scan_file_content(
                    "test.py",
                    test_content
                )
                results.append(result)
            except Exception as e:
                errors.append(e)

        threads = [
            threading.Thread(target=scan_file) for _ in range(5)
        ]

        for t in threads:
            t.start()

        for t in threads:
            t.join()

        # Should have no errors (content has no secrets)
        self.assertEqual(len(errors), 0,
                        f"Concurrent scanning should not cause errors: {errors}")

        # All scans should complete
        self.assertEqual(len(results), 5,
                        "All scans should complete")

    def test_lock_prevents_data_corruption(self):
        """
        T-002.5: Lock should prevent data corruption during initialization.

        Stress test with rapid concurrent calls to verify lock is working.
        """
        # Reset patterns
        SecretScanner.PATTERNS = []
        SecretScanner.SENSITIVE_FILENAME_PATTERNS = []
        SecretScanner.FALSE_POSITIVE_PATTERNS = []

        completed_count = [0]
        lock = threading.Lock()

        def rapid_init():
            """Rapidly call initialization."""
            for _ in range(50):
                SecretScanner._ensure_patterns_loaded()
                with lock:
                    completed_count[0] += 1

        # Use many threads to stress test
        threads = [
            threading.Thread(target=rapid_init) for _ in range(10)
        ]

        for t in threads:
            t.start()

        for t in threads:
            t.join()

        # All operations should complete
        self.assertEqual(completed_count[0], 500,
                        "All initialization operations should complete")

        # Patterns should be loaded
        self.assertGreater(len(SecretScanner.PATTERNS), 0,
                          "Patterns should be loaded after concurrent init")

    def test_double_check_pattern_efficiency(self):
        """
        T-002.6: Verify double-check pattern provides fast path.

        Once patterns are loaded, subsequent calls should not
        acquire the lock (fast path).
        """
        # Initialize first
        SecretScanner._ensure_patterns_loaded()

        # Many calls should be fast (not acquiring lock each time)
        start = time.time()
        for _ in range(1000):
            SecretScanner._ensure_patterns_loaded()
        elapsed = time.time() - start

        # Should be very fast (< 0.1 seconds for 1000 calls)
        # If lock was always acquired, this would be much slower
        self.assertLess(elapsed, 0.1,
                       f"Fast path should be efficient, took {elapsed:.3f}s")

    def test_sensitive_filename_patterns_initialized(self):
        """
        T-002.7: Sensitive filename patterns should also be thread-safe.

        Verify that all three pattern collections are safely initialized.
        """
        # Reset all patterns
        SecretScanner.PATTERNS = []
        SecretScanner.SENSITIVE_FILENAME_PATTERNS = []
        SecretScanner.FALSE_POSITIVE_PATTERNS = []

        def load_all():
            SecretScanner._ensure_patterns_loaded()

        threads = [
            threading.Thread(target=load_all) for _ in range(10)
        ]

        for t in threads:
            t.start()

        for t in threads:
            t.join()

        # All pattern types should be loaded
        self.assertGreater(len(SecretScanner.PATTERNS), 0)
        self.assertGreater(len(SecretScanner.SENSITIVE_FILENAME_PATTERNS), 0)
        self.assertGreater(len(SecretScanner.FALSE_POSITIVE_PATTERNS), 0)

    def test_scan_filename_concurrent(self):
        """
        T-002.8: Concurrent filename scanning should work correctly.

        Note: Uses a safe filename (.env IS sensitive, so FileError is expected).
        The important thing is thread-safe pattern loading.
        """
        results = []
        errors = []

        def scan_filename():
            try:
                # Use a safe filename (not in sensitive patterns)
                result = SecretScanner.scan_filename("main.py")
                results.append(result)
            except Exception as e:
                errors.append(e)

        threads = [
            threading.Thread(target=scan_filename) for _ in range(5)
        ]

        for t in threads:
            t.start()

        for t in threads:
            t.join()

        # Should have no errors with safe filename
        self.assertEqual(len(errors), 0,
                        f"Concurrent filename scan should not cause errors: {errors}")
        self.assertEqual(len(results), 5)


if __name__ == '__main__':
    unittest.main()
