"""
Tests for security validation module.

Tests URL validation, path validation, and other security checks.
"""
import unittest
import tempfile
import os
import sys

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from council.security import SecurityValidator
from council.exceptions import ConfigError
from council.output import OutputFormatter
from council.files import FileCollector


class TestSecurityValidator(unittest.TestCase):
    """Test security validation functionality."""

    def test_validate_base_url_allowed(self):
        """Test validation of allowed base URLs."""
        # Should not raise for allowed URLs
        try:
            SecurityValidator.validate_base_url('https://api.deepseek.com')
            SecurityValidator.validate_base_url('https://api.mistral.ai')
            SecurityValidator.validate_base_url('https://api.z.ai')
        except ValueError:
            self.fail("Allowed base URL should not raise ValueError")

    def test_validate_base_url_subdomain(self):
        """Test validation of subdomains of allowed URLs."""
        # Subdomains should NOT be allowed (SSRF protection)
        # Only exact hostname matches are permitted
        with self.assertRaises(ValueError) as context:
            SecurityValidator.validate_base_url('https://custom.api.deepseek.com')
        self.assertIn('not in the allowed list', str(context.exception).lower())

    def test_validate_base_url_blocked_localhost(self):
        """Test that localhost is blocked."""
        with self.assertRaises(ValueError) as context:
            SecurityValidator.validate_base_url('http://localhost:8080')
        self.assertIn('localhost', str(context.exception))

    def test_validate_base_url_blocked_private_ip(self):
        """Test that private IP addresses are blocked."""
        with self.assertRaises(ValueError) as context:
            SecurityValidator.validate_base_url('http://192.168.1.1/api')
        self.assertIn('blocked', str(context.exception).lower())

    def test_validate_base_url_blocked_file_scheme(self):
        """Test that file:// URLs are blocked."""
        with self.assertRaises(ValueError) as context:
            SecurityValidator.validate_base_url('file:///etc/passwd')
        self.assertIn('file://', str(context.exception))

    def test_validate_base_url_http_only(self):
        """Test that non-HTTPS URLs are blocked."""
        with self.assertRaises(ValueError) as context:
            SecurityValidator.validate_base_url('http://api.deepseek.com')
        self.assertIn('HTTPS', str(context.exception))

    def test_validate_base_url_none(self):
        """Test that None base_url is handled."""
        try:
            result = SecurityValidator.validate_base_url('')
            self.assertIsNone(result)
        except ValueError:
            self.fail("Empty base URL should not raise error")

    def test_validate_project_path_safe(self):
        """Test validation of safe project paths."""
        with tempfile.TemporaryDirectory() as tmpdir:
            try:
                SecurityValidator.validate_project_path(tmpdir, allow_system_paths=False)
            except ValueError:
                self.fail("Safe project path should not raise ValueError")

    def test_validate_project_path_sensitive_directory(self):
        """Test that sensitive system directories are blocked."""
        with self.assertRaises(ValueError) as context:
            SecurityValidator.validate_project_path('/etc', allow_system_paths=False)
        self.assertIn('system directory', str(context.exception))

    def test_validate_project_path_root(self):
        """Test that /root is blocked."""
        with self.assertRaises(ValueError) as context:
            SecurityValidator.validate_project_path('/root', allow_system_paths=False)
        self.assertIn('blocked', str(context.exception).lower())

    def test_validate_project_path_ssh_directory(self):
        """Test that .ssh directory is blocked."""
        home = os.path.expanduser('~')
        ssh_dir = os.path.join(home, '.ssh')

        if os.path.exists(ssh_dir):
            with self.assertRaises(ValueError) as context:
                SecurityValidator.validate_project_path(ssh_dir, allow_system_paths=False)
            self.assertIn('blocked', str(context.exception).lower())

    def test_validate_project_path_nonexistent(self):
        """Test that nonexistent paths raise error."""
        with self.assertRaises(ValueError) as context:
            SecurityValidator.validate_project_path('/nonexistent/path/that/does/not/exist', allow_system_paths=False)
        self.assertIn('does not exist', str(context.exception))

    def test_validate_project_path_allow_system(self):
        """Test that system paths are allowed with flag."""
        # This test may fail if /etc doesn't exist on the system
        if os.path.exists('/etc'):
            try:
                SecurityValidator.validate_project_path('/etc', allow_system_paths=True)
            except ValueError:
                self.fail("System path should be allowed with allow_system_paths=True")

    def test_validate_context_file_safe(self):
        """Test validation of safe context files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a test file
            test_file = os.path.join(tmpdir, 'test.md')
            with open(test_file, 'w') as f:
                f.write('test content')

            try:
                SecurityValidator.validate_context_file(test_file, tmpdir)
            except ValueError:
                self.fail("Safe context file should not raise ValueError")

    def test_validate_context_file_outside_project(self):
        """Test that files outside project directory are blocked."""
        with tempfile.TemporaryDirectory() as tmpdir1:
            with tempfile.TemporaryDirectory() as tmpdir2:
                # Create a file in tmpdir2
                test_file = os.path.join(tmpdir2, 'secret.md')
                with open(test_file, 'w') as f:
                    f.write('secret content')

                # Try to validate it as a context file for tmpdir1
                with self.assertRaises(ValueError) as context:
                    SecurityValidator.validate_context_file(test_file, tmpdir1)
                # On Windows it says "different drive", on Linux it says "outside project"
                error_msg = str(context.exception).lower()
                self.assertTrue('outside' in error_msg or 'different' in error_msg)

    def test_validate_context_file_absolute_path(self):
        """Test that absolute paths outside project are blocked."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Use /etc as an example of a path outside tmpdir
            if os.path.exists('/etc/passwd'):
                with self.assertRaises(ValueError) as context:
                    SecurityValidator.validate_context_file('/etc/passwd', tmpdir)
                # Error message differs by OS - check for key indicators
                error_msg = str(context.exception).lower()
                self.assertTrue('outside' in error_msg or 'different' in error_msg)

    def test_validate_context_file_directory(self):
        """Test that directories are rejected as context files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with self.assertRaises(ValueError) as context:
                SecurityValidator.validate_context_file(tmpdir, tmpdir)
            self.assertIn('file, not a directory', str(context.exception))

    def test_validate_directory_not_symlink_normal(self):
        """Test that normal directories pass symlink check."""
        with tempfile.TemporaryDirectory() as tmpdir:
            try:
                SecurityValidator.validate_directory_not_symlink(tmpdir)
            except ValueError:
                self.fail("Normal directory should not raise ValueError")

    def test_validate_directory_not_symlink_symlink(self):
        """Test that symlinks are detected."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a symlink
            symlink_path = os.path.join(tmpdir, 'test_symlink')
            target = tempfile.mkdtemp()
            os.symlink(target, symlink_path)

            with self.assertRaises(ValueError) as context:
                SecurityValidator.validate_directory_not_symlink(symlink_path)
            self.assertIn('symlink', str(context.exception))

            # Clean up
            os.unlink(symlink_path)
            os.rmdir(target)

    def test_validate_directory_not_symlink_nonexistent(self):
        """Test that nonexistent directories don't raise error."""
        try:
            result = SecurityValidator.validate_directory_not_symlink('/nonexistent/directory')
            self.assertIsNone(result)
        except ValueError:
            self.fail("Nonexistent directory should not raise error for symlink check")

    def test_validate_base_url_custom_subdomain(self):
        """Test that custom subdomains of allowed domains are blocked (SSRF protection)."""
        # Custom subdomains should NOT be allowed - only exact hostname matches
        with self.assertRaises(ValueError) as context:
            SecurityValidator.validate_base_url('https://myapp.api.deepseek.com')
        self.assertIn('not in the allowed list', str(context.exception).lower())

    def test_validate_base_url_exact_match_only(self):
        """Test that only exact hostname matches are allowed."""
        # These exact hostnames should work
        try:
            SecurityValidator.validate_base_url('https://api.deepseek.com')
            SecurityValidator.validate_base_url('https://api.mistral.ai')
            SecurityValidator.validate_base_url('https://api.z.ai')
        except ValueError:
            self.fail("Exact hostname matches should be permitted")

    def test_validate_base_url_subdomain_attacker(self):
        """Test that attacker-controlled subdomains are blocked."""
        # Attacker tries to use subdomain phishing
        with self.assertRaises(ValueError) as context:
            SecurityValidator.validate_base_url('https://attacker-controlled.deepseek.com')
        self.assertIn('not in the allowed list', str(context.exception).lower())

    def test_validate_base_url_evil_tld(self):
        """Test that evil.com TLD tricks are blocked."""
        # Attacker tries api.deepseek.com.evil.com
        with self.assertRaises(ValueError) as context:
            SecurityValidator.validate_base_url('https://api.deepseek.com.evil.com')
        self.assertIn('not in the allowed list', str(context.exception).lower())


class TestPathTraversalProtection(unittest.TestCase):
    """Test path traversal attack protection via pattern matching."""

    def setUp(self):
        """Set up test fixtures."""
        from council.output import OutputFormatter
        from council.files import FileCollector
        self.formatter = OutputFormatter()
        # Pattern "build/" should only ignore "build" directory, not "build_backup"
        self.collector = FileCollector(['build/'], self.formatter)

    def test_exact_directory_match_ignored(self):
        """Test that exact directory matches are ignored."""
        # Should be ignored
        self.assertTrue(self.collector.should_ignore_file('src/build/main.py'))
        self.assertTrue(self.collector.should_ignore_file('build/config.json'))
        self.assertTrue(self.collector.should_ignore_file('/project/build/test.py'))

    def test_similar_directory_not_ignored(self):
        """Test that similarly named directories are NOT ignored (prevents path traversal)."""
        # CRITICAL: These should NOT be ignored (prevents "build/" from matching "build_backup/")
        # Note: Using non-default-ignore filenames (config.json is in default patterns)
        self.assertFalse(self.collector.should_ignore_file('build_backup/module.py'))
        self.assertFalse(self.collector.should_ignore_file('mybuild/file.py'))
        self.assertFalse(self.collector.should_ignore_file('src/build_backup/test.py'))
        self.assertFalse(self.collector.should_ignore_file('backup_build/file.py'))

    def test_exact_pattern_component_matching(self):
        """Test that pattern matching uses exact component matching, not substring."""
        # Test with various patterns that could be confused
        collector2 = FileCollector(['test', '.git'], self.formatter)

        # Should ignore exact matches
        self.assertTrue(collector2.should_ignore_file('test'))
        self.assertTrue(collector2.should_ignore_file('src/test'))
        self.assertTrue(collector2.should_ignore_file('.git/config'))

        # Should NOT ignore similar names
        self.assertFalse(collector2.should_ignore_file('mytest'))
        self.assertFalse(collector2.should_ignore_file('test_backup'))
        self.assertFalse(collector2.should_ignore_file('.git_backup'))

    def test_wildcard_patterns_still_work(self):
        """Test that wildcard patterns still function correctly."""
        collector3 = FileCollector(['*.pyc', '*.log'], self.formatter)

        # Should ignore matching patterns
        self.assertTrue(collector3.should_ignore_file('test.pyc'))
        self.assertTrue(collector3.should_ignore_file('debug.log'))
        self.assertTrue(collector3.should_ignore_file('src/test.pyc'))

        # Should NOT ignore non-matching files
        self.assertFalse(collector3.should_ignore_file('test.py'))
        self.assertFalse(collector3.should_ignore_file('debug.log.txt'))

    def test_complex_path_traversal_scenario(self):
        """Test a complex path traversal attack scenario."""
        # Attacker tries various bypass techniques
        self.assertFalse(self.collector.should_ignore_file('build_backup/secrets.txt'))
        self.assertFalse(self.collector.should_ignore_file('buildbackup/config.yaml'))
        self.assertFalse(self.collector.should_ignore_file('prefix_build/sensitive.json'))
        self.assertFalse(self.collector.should_ignore_file('xbuild/file.py'))


class TestAsyncPathTraversalProtection(unittest.TestCase):
    """Test path traversal protection in async file collector."""

    def setUp(self):
        """Set up test fixtures."""
        from council.output import OutputFormatter
        from council.async_files import AsyncFileCollector
        self.formatter = OutputFormatter()
        self.collector = AsyncFileCollector(['build/'], self.formatter)

    def test_async_exact_directory_match_ignored(self):
        """Test that exact directory matches are ignored in async collector."""
        self.assertTrue(self.collector.should_ignore_file('src/build/main.py'))
        self.assertTrue(self.collector.should_ignore_file('build/config.json'))

    def test_async_similar_directory_not_ignored(self):
        """Test that similarly named directories are NOT ignored in async collector."""
        # CRITICAL: Prevent path traversal via similar directory names
        # Note: Using non-default-ignore filenames (config.json is in default patterns)
        self.assertFalse(self.collector.should_ignore_file('build_backup/module.py'))
        self.assertFalse(self.collector.should_ignore_file('mybuild/file.py'))


class TestAtomicFileWrites(unittest.TestCase):
    """Test atomic file write functionality for TOCTOU protection."""

    def test_write_file_atomic_creates_file(self):
        """Test that atomic write creates the file with correct content."""
        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = os.path.join(tmpdir, 'test.txt')
            content = 'Hello, World!'

            SecurityValidator.write_file_atomic(filepath, content)

            # Verify file was created with correct content
            self.assertTrue(os.path.exists(filepath))
            with open(filepath, 'r') as f:
                self.assertEqual(f.read(), content)

    def test_write_file_atomic_overwrites_existing(self):
        """Test that atomic write overwrites existing files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = os.path.join(tmpdir, 'test.txt')

            # Write initial content
            SecurityValidator.write_file_atomic(filepath, 'old content')

            # Overwrite with new content
            SecurityValidator.write_file_atomic(filepath, 'new content')

            # Verify file was overwritten
            with open(filepath, 'r') as f:
                self.assertEqual(f.read(), 'new content')

    def test_write_file_atomic_rejects_symlink_parent(self):
        """Test that atomic write rejects symlinked parent directories."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a legitimate directory
            real_dir = os.path.join(tmpdir, 'real_dir')
            os.makedirs(real_dir)

            # Create a symlink to it
            symlink_dir = os.path.join(tmpdir, 'symlink_dir')
            os.symlink(real_dir, symlink_dir)

            # Try to write to symlinked directory
            filepath = os.path.join(symlink_dir, 'test.txt')

            with self.assertRaises(ValueError) as context:
                SecurityValidator.write_file_atomic(filepath, 'content')

            self.assertIn('symlink', str(context.exception).lower())

    def test_write_file_atomic_cleans_up_temp_files(self):
        """Test that atomic write cleans up temporary files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = os.path.join(tmpdir, 'test.txt')

            SecurityValidator.write_file_atomic(filepath, 'content')

            # Check for leftover .tmp_ files
            tmp_files = [f for f in os.listdir(tmpdir) if f.startswith('.tmp_')]
            self.assertEqual(len(tmp_files), 0, "Temporary files should be cleaned up")

    def test_ensure_directory_safe_creates_directory(self):
        """Test that ensure_directory_safe creates directories."""
        with tempfile.TemporaryDirectory() as tmpdir:
            new_dir = os.path.join(tmpdir, 'new_dir', 'nested_dir')

            result = SecurityValidator.ensure_directory_safe(new_dir)

            self.assertTrue(result.exists())
            self.assertTrue(result.is_dir())

    def test_ensure_directory_safe_rejects_symlink(self):
        """Test that ensure_directory_safe rejects symlinked directories."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a real directory
            real_dir = os.path.join(tmpdir, 'real')
            os.makedirs(real_dir)

            # Create a symlink to it
            symlink_dir = os.path.join(tmpdir, 'symlink')
            os.symlink(real_dir, symlink_dir)

            with self.assertRaises(ValueError) as context:
                SecurityValidator.ensure_directory_safe(symlink_dir)

            self.assertIn('symlink', str(context.exception).lower())


class TestSHA256Usage(unittest.TestCase):
    """Test that SHA256 is used instead of MD5 for cryptographic operations."""

    def test_cache_uses_sha256_not_md5(self):
        """Test that ReviewCache uses SHA256 for cache keys."""
        import hashlib
        from council.cache import ReviewCache

        with tempfile.TemporaryDirectory() as tmpdir:
            cache = ReviewCache(cache_dir=tmpdir)

            # Get a cache key
            key = cache.get_cache_key(
                project_path='/test/project',
                filepaths=['test.py'],
                context_files=None
            )

            # SHA256 produces 64 hex characters, MD5 produces 32
            self.assertEqual(len(key), 64, "Cache key should be 64 chars (SHA256), not 32 (MD5)")

            # Verify it's a valid hex string
            int(key, 16)  # Will raise if not valid hex

    def test_cache_signature_uses_hmac_sha256(self):
        """Test that cache signatures use HMAC-SHA256."""
        from council.cache import ReviewCache

        with tempfile.TemporaryDirectory() as tmpdir:
            cache = ReviewCache(cache_dir=tmpdir)

            # Test signature generation using the integrity module
            data = "test data"
            signature = cache.integrity.sign_data(data)

            # HMAC-SHA256 produces 64 hex characters
            self.assertEqual(len(signature), 64, "HMAC-SHA256 signature should be 64 chars")

            # Verify signature verification works
            self.assertTrue(cache.integrity.verify_signature(data, signature))


class TestAPIKeySanitization(unittest.TestCase):
    """Test API key sanitization to prevent exposure in logs/errors."""

    def test_sanitize_openai_key(self):
        """Test that OpenAI-style API keys are redacted."""
        from council.utils import sanitize_api_key

        message = "Error: Invalid API key sk-abc123def456ghi789jkl012mno345pq"
        sanitized = sanitize_api_key(message)

        self.assertNotIn("sk-abc123def456ghi789jkl012mno345pq", sanitized)
        self.assertIn("sk-***REDACTED***", sanitized)

    def test_sanitize_anthropic_key(self):
        """Test that Anthropic-style API keys are redacted."""
        from council.utils import sanitize_api_key

        message = "Error with key sk-ant-api123-456789-abcdefgh"
        sanitized = sanitize_api_key(message)

        self.assertNotIn("sk-ant-api123", sanitized)
        self.assertIn("sk-ant-***REDACTED***", sanitized)

    def test_sanitize_bearer_token(self):
        """Test that Bearer tokens are redacted."""
        from council.utils import sanitize_api_key

        message = "Authorization: Bearer abcdefghijklmnopqrstuvwxyz1234567890"
        sanitized = sanitize_api_key(message)

        self.assertNotIn("Bearer abcdefghijklmnopqrstuvwxyz1234567890", sanitized)
        self.assertIn("Bearer ***REDACTED***", sanitized)

    def test_sanitize_hex_string(self):
        """Test that long hex strings (likely keys) are redacted."""
        from council.utils import sanitize_api_key

        message = "Key: a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6"
        sanitized = sanitize_api_key(message)

        self.assertNotIn("a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6", sanitized)
        # Very long alphanumeric strings get redacted
        self.assertIn("***REDACTED***", sanitized)

    def test_sanitize_specific_api_key(self):
        """Test that specific API key is redacted with partial visible."""
        from council.utils import sanitize_api_key

        api_key = "my-secret-api-key-12345678"
        message = f"Error with key {api_key}"

        sanitized = sanitize_api_key(message, api_key)

        # Should not contain the full key
        self.assertNotIn(api_key, sanitized)
        # Should show first 8 and last 4 chars for debugging
        self.assertIn("my-secre...5678", sanitized)

    def test_sanitize_multiple_keys(self):
        """Test that multiple API keys in one message are all redacted."""
        from council.utils import sanitize_api_key

        message = "Keys: sk-key1abc123 and sk-key2def456 both failed"
        sanitized = sanitize_api_key(message)

        # Both keys should be redacted
        self.assertNotIn("sk-key1abc123", sanitized)
        self.assertNotIn("sk-key2def456", sanitized)
        # Both replaced with redacted version
        self.assertEqual(sanitized.count("***REDACTED***"), 2)


class TestAsyncPathValidation(unittest.TestCase):
    """Test path validation in async file operations."""

    def test_validate_file_within_project_allows_valid_paths(self):
        """Test that files within project directory are allowed."""
        from council.output import OutputFormatter
        from council.async_files import AsyncFileCollector
        import asyncio

        formatter = OutputFormatter()
        collector = AsyncFileCollector([], formatter)
        # Properly set project root so it propagates to file_validator
        collector.set_project_root("/tmp/project")
        # Also set the collector's _project_root for _validate_file_within_project check
        collector._project_root = "/tmp/project"

        # Files within project should be allowed
        try:
            collector._validate_file_within_project("/tmp/project/file.py")
            collector._validate_file_within_project("/tmp/project/src/main.py")
            collector._validate_file_within_project("/tmp/project/src/utils/helper.py")
        except ValueError:
            self.fail("Valid project files should not raise ValueError")

    def test_validate_file_within_project_blocks_path_traversal(self):
        """Test that files outside project directory are blocked."""
        from council.output import OutputFormatter
        from council.async_files import AsyncFileCollector

        formatter = OutputFormatter()
        collector = AsyncFileCollector([], formatter)
        # Properly set project root so it propagates to file_validator
        collector.set_project_root("/tmp/project")
        # Also set the collector's _project_root for _validate_file_within_project check
        collector._project_root = "/tmp/project"

        # Files outside project should be rejected
        with self.assertRaises(ValueError) as context:
            collector._validate_file_within_project("/etc/passwd")

        self.assertIn("not accessible from project", str(context.exception).lower())

        with self.assertRaises(ValueError) as context:
            collector._validate_file_within_project("/tmp/other_project/file.py")

        self.assertIn("not accessible from project", str(context.exception).lower())

    def test_validate_file_within_project_blocks_parent_traversal(self):
        """Test that parent directory traversal (..) is blocked."""
        from council.output import OutputFormatter
        from council.async_files import AsyncFileCollector

        formatter = OutputFormatter()
        collector = AsyncFileCollector([], formatter)
        # Properly set project root so it propagates to file_validator
        collector.set_project_root("/tmp/project")
        # Also set the collector's _project_root for _validate_file_within_project check
        collector._project_root = "/tmp/project"

        # Paths using .. to escape project should be rejected
        with self.assertRaises(ValueError) as context:
            collector._validate_file_within_project("/tmp/project/../etc/passwd")

        self.assertIn("not accessible from project", str(context.exception).lower())


class TestSymlinkAttackProtection(unittest.TestCase):
    """
    Test symlink attack protection in file reading operations.

    Phase 1.1 Implementation: Tests that symlinks are rejected at the OS level
    using O_NOFOLLOW, preventing path traversal attacks via symlinks.
    """

    def test_file_reader_rejects_symlink_to_sensitive_file(self):
        """Test that FileReader rejects symlinks pointing to sensitive files."""
        from council.file_reader import FileReader
        from council.output import OutputFormatter
        from council.file_validator import FileValidator

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a "safe" file that will be the symlink target
            # (simulating a sensitive file outside the project)
            sensitive_dir = os.path.join(tmpdir, 'sensitive')
            os.makedirs(sensitive_dir)
            sensitive_file = os.path.join(sensitive_dir, 'secret.txt')
            with open(sensitive_file, 'w') as f:
                f.write('AKIAIOSFODNN7EXAMPLE')  # Fake AWS key

            # Create a project directory
            project_dir = os.path.join(tmpdir, 'project')
            os.makedirs(project_dir)

            # Create a symlink inside the project pointing to the sensitive file
            symlink_path = os.path.join(project_dir, 'backdoor')
            os.symlink(sensitive_file, symlink_path)

            # Try to read the symlink - should be rejected
            formatter = OutputFormatter()
            file_validator = FileValidator(formatter)
            reader = FileReader(formatter, file_validator)

            with self.assertRaises(Exception) as context:
                reader.read_file_with_checks(symlink_path, {})

            self.assertIn('symlink', str(context.exception).lower())

    def test_file_reader_allows_normal_file(self):
        """Test that FileReader allows normal files (not symlinks)."""
        from council.file_reader import FileReader
        from council.output import OutputFormatter
        from council.file_validator import FileValidator

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a normal file
            normal_file = os.path.join(tmpdir, 'normal.py')
            with open(normal_file, 'w') as f:
                f.write('print("hello")')

            # Should read successfully
            formatter = OutputFormatter()
            file_validator = FileValidator(formatter)
            reader = FileReader(formatter, file_validator)

            result = reader.read_file_with_checks(normal_file, {})
            self.assertIsNotNone(result)
            content, size, mtime = result
            self.assertEqual(content, 'print("hello")')

    def test_context_loader_rejects_symlink(self):
        """Test that ContextLoader rejects symlinked context files."""
        from council.files import ContextLoader
        from council.output import OutputFormatter

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a sensitive file outside the project
            sensitive_file = os.path.join(tmpdir, 'secret.md')
            with open(sensitive_file, 'w') as f:
                f.write('SECRET_KEY=abc123')

            # Create project directory
            project_dir = os.path.join(tmpdir, 'project')
            os.makedirs(project_dir)

            # Create symlink inside project pointing to sensitive file
            symlink_path = os.path.join(project_dir, 'context.md')
            os.symlink(sensitive_file, symlink_path)

            # Try to load the symlink as context - should be rejected
            formatter = OutputFormatter()
            loader = ContextLoader(formatter, project_dir)

            context = loader.load_context_files([symlink_path])

            # Symlink should be rejected (not in context dict)
            self.assertNotIn(symlink_path, context)

    def test_symlink_to_directory_is_rejected(self):
        """Test that symlinks to directories are rejected."""
        from council.file_reader import FileReader
        from council.output import OutputFormatter
        from council.file_validator import FileValidator

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a directory outside the project
            outside_dir = os.path.join(tmpdir, 'outside')
            os.makedirs(outside_dir)

            # Create project directory
            project_dir = os.path.join(tmpdir, 'project')
            os.makedirs(project_dir)

            # Create symlink to directory
            symlink_path = os.path.join(project_dir, 'link_to_dir')
            os.symlink(outside_dir, symlink_path)

            # Verify it's a symlink
            self.assertTrue(os.path.islink(symlink_path))

            # Note: This test documents expected behavior.
            # The actual rejection happens when trying to open as a file.

    def test_circular_symlink_does_not_cause_infinite_loop(self):
        """Test that circular symlinks are handled gracefully."""
        from council.file_reader import FileReader
        from council.output import OutputFormatter
        from council.file_validator import FileValidator

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create two symlinks that point to each other
            link1 = os.path.join(tmpdir, 'link1')
            link2 = os.path.join(tmpdir, 'link2')

            os.symlink(link2, link1)
            os.symlink(link1, link2)

            # Try to read - should fail with symlink error, not infinite loop
            formatter = OutputFormatter()
            file_validator = FileValidator(formatter)
            reader = FileReader(formatter, file_validator)

            # Should raise an error about symlink, not hang forever
            with self.assertRaises(Exception) as context:
                reader.read_file_with_checks(link1, {})

            # Should be a symlink-related error or file not found
            error_msg = str(context.exception).lower()
            self.assertTrue('symlink' in error_msg or 'not found' in error_msg or 'could not read' in error_msg)

    def test_validate_project_path_resolves_symlinks(self):
        """Test that validate_project_path uses realpath to resolve symlinks."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a sensitive directory
            sensitive_dir = os.path.join(tmpdir, 'sensitive')
            os.makedirs(sensitive_dir)

            # Create project directory
            project_dir = os.path.join(tmpdir, 'project')
            os.makedirs(project_dir)

            # Create symlink inside project pointing to sensitive directory
            symlink_path = os.path.join(project_dir, 'backdoor_dir')
            os.symlink(sensitive_dir, symlink_path)

            # Validate the symlink - should resolve and reject
            # because it's not a "safe" project path (it's in tmpdir which is safe,
            # but the realpath check ensures symlinks are resolved)
            try:
                # The realpath should resolve to the actual sensitive_dir path
                real_path = os.path.realpath(symlink_path)
                self.assertEqual(real_path, sensitive_dir)
            except Exception:
                self.fail("realpath resolution should work")


class TestSecretScannerCommentExemptionRemoved(unittest.TestCase):
    """
    Test that the comment exemption has been removed from secret scanner.

    Phase 1.2 Implementation: Secrets in comments are still secrets and should
    be detected/redacted because they get sent to third-party APIs.
    """

    def test_commented_secrets_are_detected(self):
        """Test that secrets in comments are still detected."""
        from council.secret_scanner import SecretScanner

        # AWS key in a comment - using realistic key format (not containing "example")
        # Note: Using a fake AWS key in standard format AKIA + 16 alphanumeric chars
        commented_line = "# I forgot to remove this key: AKIAIOSFODNN7AAAAAA"

        # Should NOT be a false positive (comment exemption removed)
        result = SecretScanner._is_false_positive('AKIAIOSFODNN7AAAAAA', commented_line)
        self.assertFalse(result, "Commented secrets should NOT be false positives")

    def test_double_slash_comment_secrets_detected(self):
        """Test that secrets in // comments are still detected."""
        from council.secret_scanner import SecretScanner

        # API key in a double-slash comment
        commented_line = "// TODO: remove this api_key=sk-1234567890abcdef"

        result = SecretScanner._is_false_positive('sk-1234567890abcdef', commented_line)
        self.assertFalse(result, "// commented secrets should NOT be false positives")

    def test_placeholder_patterns_still_false_positives(self):
        """Test that actual placeholder patterns are still false positives."""
        from council.secret_scanner import SecretScanner

        # These should still be false positives
        placeholder_lines = [
            "your_api_key_here",
            "<your_key_here>",
            "example_key_12345",
            "test_key_abcdef",
            "placeholder_value_xyz",
        ]

        for line in placeholder_lines:
            result = SecretScanner._is_false_positive(line, line)
            self.assertTrue(result, f"Placeholder '{line}' should be a false positive")

    def test_redact_secrets_in_comments(self):
        """Test that secrets in comments are redacted."""
        from council.secret_scanner import SecretScanner

        # Content with secret in comment - using a realistic API key
        # Using a 40-char hex string which matches several patterns
        api_key = 'sk' + '1a2b3c4d5e6f7890' * 2  # 40 hex chars
        content = f'''# Configuration
# API_KEY = {api_key}  # Remove this!
DATABASE_URL=postgresql://localhost/db
'''

        redacted, secrets = SecretScanner.redact_secrets(content, 'test.py')

        # Secret should be detected and redacted
        self.assertGreater(len(secrets), 0, "Commented secret should be detected")
        self.assertIn('[REDACTED', redacted)


if __name__ == '__main__':
    unittest.main()
