"""
Tests for TOCTOU (Time-Of-Check-Time-Of-Use) protection.

T-004: Tests for FIX-004 - TOCTOU vulnerability in file reading.

These tests verify that symlink attacks are prevented by checking for
symlinks immediately before reading files, not just during validation.
"""
import unittest
import tempfile
import os
import sys
import shutil

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from council.files import FileCollector
from council.exceptions import FileError
from council.output import OutputFormatter, NoColors


class TestTOCTOUProtection(unittest.TestCase):
    """Test time-of-check-time-of-use protection (FIX-004)."""

    def setUp(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()
        self.output_formatter = OutputFormatter(NoColors())
        self.file_collector = FileCollector(
            ignore_patterns=[],
            output_formatter=self.output_formatter
        )

    def tearDown(self):
        """Clean up test fixtures."""
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)

    def test_symlink_rejection_absolute_path(self):
        """
        T-004.1: Symlink to system file should be rejected.

        Attempting to read a symlink to /etc/passwd should raise an error.
        The rejection happens at the path validation stage (using realpath to
        resolve the symlink target), before the explicit symlink check.
        """
        # Create a symlink to a system file
        symlink_path = os.path.join(self.temp_dir, "safe_name.txt")
        try:
            os.symlink('/etc/passwd', symlink_path)
        except (OSError, PermissionError):
            # Skip test if symlinks are not supported or we lack permissions
            self.skipTest("Symlink creation not supported or permission denied")

        # Attempt to read the symlink - should raise an error
        # (The error comes from validate_project_path detecting system path access)
        with self.assertRaises((FileError, ValueError)) as context:
            self.file_collector._read_file_with_size_check(symlink_path)

        # Either symlink rejection or system path rejection is acceptable
        error_msg = str(context.exception).lower()
        self.assertTrue(
            'symlink' in error_msg or 'system' in error_msg or 'security' in error_msg or '/etc' in error_msg,
            f"Expected security-related error, got: {context.exception}"
        )

    def test_symlink_rejection_relative_path(self):
        """
        T-004.2: Symlink with relative path should be rejected.

        """
        # Create a temporary file first
        temp_file = os.path.join(self.temp_dir, "target.txt")
        with open(temp_file, 'w') as f:
            f.write("secret content")

        # Create a symlink to it
        symlink_path = os.path.join(self.temp_dir, "link.txt")
        try:
            os.symlink(temp_file, symlink_path)
        except (OSError, PermissionError):
            self.skipTest("Symlink creation not supported")

        # Even symlink to file within project should be rejected
        # (conservative security posture)
        with self.assertRaises(FileError) as context:
            self.file_collector._read_file_with_size_check(symlink_path)

        self.assertIn('symlink', str(context.exception).lower())

    def test_symlink_rejection_broken_symlink(self):
        """
        T-004.3: Broken symlink should also be rejected.

        Even if the symlink target doesn't exist, the symlink should
        be rejected. The rejection happens at path validation since
        realpath on a broken symlink may not resolve properly.
        """
        # Create a symlink to non-existent file
        symlink_path = os.path.join(self.temp_dir, "broken_link.txt")
        try:
            os.symlink('/non/existent/path/file.txt', symlink_path)
        except (OSError, PermissionError):
            self.skipTest("Symlink creation not supported")

        # Should raise an error (either symlink rejection or path not found)
        # This is acceptable security behavior
        with self.assertRaises((FileError, ValueError)) as context:
            self.file_collector._read_file_with_size_check(symlink_path)

        error_msg = str(context.exception).lower()
        self.assertTrue(
            'symlink' in error_msg or 'does not exist' in error_msg,
            f"Expected symlink or not found error, got: {context.exception}"
        )

    def test_normal_file_reading_works(self):
        """
        T-004.4: Normal file reading should still work.

        Verify that the symlink check doesn't break normal file operations.
        """
        # Create a normal file
        normal_file = os.path.join(self.temp_dir, "normal.txt")
        content = "This is a normal file"
        with open(normal_file, 'w') as f:
            f.write(content)

        # Should read successfully
        result = self.file_collector._read_file_with_size_check(normal_file)

        self.assertIsNotNone(result, "Normal file should be readable")
        file_content, file_size, file_mtime = result
        self.assertEqual(file_content, content)
        self.assertGreater(file_size, 0)

    def test_symlink_chain_rejection(self):
        """
        T-004.5: Chain of symlinks should be rejected.

        Even if the ultimate target is valid, any symlink in the chain
        should cause rejection.
        """
        # Create a normal file
        target_file = os.path.join(self.temp_dir, "target.txt")
        with open(target_file, 'w') as f:
            f.write("content")

        # Create first symlink
        link1 = os.path.join(self.temp_dir, "link1.txt")
        try:
            os.symlink(target_file, link1)
        except (OSError, PermissionError):
            self.skipTest("Symlink creation not supported")

        # Create second symlink pointing to first symlink
        link2 = os.path.join(self.temp_dir, "link2.txt")
        try:
            os.symlink(link1, link2)
        except (OSError, PermissionError):
            self.skipTest("Symlink creation not supported")

        # The second link should be rejected
        with self.assertRaises(FileError) as context:
            self.file_collector._read_file_with_size_check(link2)

        self.assertIn('symlink', str(context.exception).lower())

    def test_symlink_to_directory_rejection(self):
        """
        T-004.6: Symlink to directory should be rejected.

        """
        # Create a subdirectory
        subdir = os.path.join(self.temp_dir, "subdir")
        os.mkdir(subdir)

        # Create symlink to directory
        link_path = os.path.join(self.temp_dir, "dirlink")
        try:
            os.symlink(subdir, link_path)
        except (OSError, PermissionError):
            self.skipTest("Symlink creation not supported")

        # Symlink to directory should be rejected
        with self.assertRaises(FileError) as context:
            self.file_collector._read_file_with_size_check(link_path)

        self.assertIn('symlink', str(context.exception).lower())

    def test_project_root_set_for_symlink_check(self):
        """
        T-004.7: Verify project root is set before symlink check.

        The security check requires the project root to be set.
        """
        # Create a normal file
        test_file = os.path.join(self.temp_dir, "test.txt")
        with open(test_file, 'w') as f:
            f.write("content")

        # Set project root
        self.file_collector.set_project_root(self.temp_dir)

        # Should read successfully
        result = self.file_collector._read_file_with_size_check(test_file)
        self.assertIsNotNone(result)

    def test_symlink_creation_detection_race_condition(self):
        """
        T-004.8: Test that symlink detection happens at read time.

        This test verifies that the symlink check occurs immediately
        before reading, preventing a TOCTOU race condition.
        """
        # Create a normal file
        normal_file = os.path.join(self.temp_dir, "file.txt")
        with open(normal_file, 'w') as f:
            f.write("original content")

        # Verify we can read it
        result1 = self.file_collector._read_file_with_size_check(normal_file)
        self.assertIsNotNone(result1)

        # Replace it with a symlink (simulating an attack)
        target_file = os.path.join(self.temp_dir, "secret.txt")
        with open(target_file, 'w') as f:
            f.write("secret content")

        try:
            os.remove(normal_file)
            os.symlink(target_file, normal_file)
        except (OSError, PermissionError):
            self.skipTest("Symlink creation not supported")

        # Next read should fail because it's now a symlink
        with self.assertRaises(FileError) as context:
            self.file_collector._read_file_with_size_check(normal_file)

        self.assertIn('symlink', str(context.exception).lower())

    def test_empty_file_not_symlink(self):
        """
        T-004.9: Empty regular file handling.

        Note: The FileReader returns None for empty files (existing behavior).
        This test verifies that empty files don't cause symlink-related errors.
        """
        # Create an empty file
        empty_file = os.path.join(self.temp_dir, "empty.txt")
        with open(empty_file, 'w') as f:
            pass  # Create empty file

        # Empty files are skipped (returns None) - this is existing behavior
        # The important thing is that it doesn't raise a symlink error
        result = self.file_collector._read_file_with_size_check(empty_file)
        self.assertIsNone(result, "Empty files are skipped by FileReader (existing behavior)")

    def test_collect_project_files_with_symlink(self):
        """
        T-004.10: Full collection workflow should reject symlinks.

        Test the complete collect_project_files method with symlinks.
        """
        # Create some normal files
        for i in range(3):
            with open(os.path.join(self.temp_dir, f"file{i}.txt"), 'w') as f:
                f.write(f"content {i}")

        # Create a symlink
        symlink_path = os.path.join(self.temp_dir, "symlink.txt")
        try:
            os.symlink('/etc/passwd', symlink_path)
        except (OSError, PermissionError):
            self.skipTest("Symlink creation not supported")

        # Collect files - symlink should be rejected but others should work
        files_content, files_metadata = self.file_collector.collect_project_files(self.temp_dir)

        # Should have 3 files (not 4), symlink excluded
        self.assertEqual(len(files_content), 3,
                        "Symlink should be excluded from collection")
        self.assertEqual(len(files_metadata), 3)


if __name__ == '__main__':
    unittest.main()
