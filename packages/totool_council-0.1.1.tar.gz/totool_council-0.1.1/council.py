#!/usr/bin/env python3
"""
Code Review Council - CLI Tool
A council of 3 AI critics that must reach consensus on code quality decisions.
Supports reviewing entire projects/directories with optional context files.
"""

import sys
import asyncio
from pathlib import Path
from typing import Tuple, List

# Import the new modular components
from council.cli import ArgumentParser, ConfigurationManager, ProjectFormatter
from council.output import OutputFormatter, Colors, NoColors
from council.review import ResultSaver
from council.exceptions import CouncilError, ConfigError, APIError, FileError
from council.compatibility import create_client_factory, create_session, AsyncCompat
from council.models import ConsensusResult, APIUsageStats


# FIX-011: Exit code mapping from consensus decision to system exit code
#
# IMPORTANT: Consensus decisions use past tense (APPROVED, REJECTED) while
# raw critic verdicts use present tense (APPROVE, REJECT). This transformation
# in ConsensusCalculator is intentional to indicate the finality of the
# council's decision.
#
# Exit code rationale:
#   0: Approved (success) - Code passed review, can proceed
#   1: Needs work (warning) - Code has issues but not blocking
#   2: Rejected (error) - Code has critical issues that block progress
#
CONSENSUS_EXIT_CODES = {
    'APPROVED': 0,
    'NEEDS_WORK': 1,
    'REJECTED': 2
}


def get_exit_code(consensus: ConsensusResult) -> int:
    """
    Get system exit code from consensus decision.

    FIX-011: Provides a clear, documented mapping from consensus decisions
    to system exit codes. This centralizes the mapping logic and makes
    the relationship between decisions and exit codes explicit.

    Args:
        consensus: The ConsensusResult containing the council's decision

    Returns:
        int: System exit code (0=success, 1=warning, 2=error)

    Examples:
        >>> consensus = ConsensusResult(decision='APPROVED', votes={}, unanimous=True, majority=True)
        >>> get_exit_code(consensus)
        0
        >>> consensus = ConsensusResult(decision='REJECTED', votes={}, unanimous=True, majority=True)
        >>> get_exit_code(consensus)
        2
    """
    return CONSENSUS_EXIT_CODES.get(consensus.decision, 1)


def handle_security_consent(args, output_formatter: OutputFormatter) -> None:
    """
    Handle security warning and user consent.

    CRITICAL: Explicit user consent before sending code to third-party AI services.

    Args:
        args: Parsed command-line arguments
        output_formatter: Output formatter for displaying messages

    Exits:
        If user does not consent to the security warning
    """
    if args.yes_i_understand_the_risks:
        return

    output_formatter.print_warning("=" * 70)
    output_formatter.print_warning("SECURITY WARNING: Third-Party Code Transmission")
    output_formatter.print_warning("=" * 70)
    output_formatter.print_warning("")
    output_formatter.print_warning("This tool will send your code to third-party AI services:")
    output_formatter.print_warning("  - DeepSeek (deepseek.com)")
    output_formatter.print_warning("  - Mistral (mistral.ai)")
    output_formatter.print_warning("  - ZAI (zai.ai)")
    output_formatter.print_warning("")
    output_formatter.print_warning("RISKS:")
    output_formatter.print_warning("  - File paths and directory structure reveal project architecture")
    output_formatter.print_warning("  - Code patterns and algorithms expose intellectual property")
    output_formatter.print_warning("  - Business logic is transmitted to external services")
    output_formatter.print_warning("")
    output_formatter.print_warning("While secrets are redacted, your code may still contain:")
    output_formatter.print_warning("  - Proprietary algorithms")
    output_formatter.print_warning("  - Business logic")
    output_formatter.print_warning("  - Trade secrets")
    output_formatter.print_warning("")
    output_formatter.print_warning("For open source projects: Risks are generally acceptable")
    output_formatter.print_warning("For proprietary/commercial code: Consider using local AI models instead")
    output_formatter.print_warning("")
    output_formatter.print_warning("=" * 70)
    response = input("Do you want to continue? (y/N or --yes-i-understand-the-risks to skip): ")
    if response.lower() != 'y':
        output_formatter.print_warning("Review cancelled.")
        sys.exit(0)


def determine_async_mode(args, output_formatter: OutputFormatter) -> bool:
    """
    Determine whether to use async mode based on args and availability.

    Args:
        args: Parsed command-line arguments
        output_formatter: Output formatter for displaying messages

    Returns:
        True if async mode should be used, False otherwise
    """
    if args.no_async_io:
        return False
    elif args.async_io:
        return True
    else:
        # Auto-detect if neither flag specified
        use_async = AsyncCompat.is_async_available()
        if use_async:
            output_formatter.print_warning("Using async operations for better performance")
        return use_async


async def load_configuration_and_context(args, output_formatter: OutputFormatter) -> Tuple:
    """
    Load configuration and context files.

    Args:
        args: Parsed command-line arguments
        output_formatter: Output formatter for displaying messages

    Returns:
        Tuple of (config, context_files)
    """
    from council.cli import ConfigurationManager
    from council.files import ContextLoader

    # Load configuration (ConfigurationManager now uses stateless functions internally)
    config_manager = ConfigurationManager()
    config = config_manager.load_configuration(args)

    # Load context files (pass project path for security validation)
    context_loader = ContextLoader(output_formatter, config.project_path)
    context_files = context_loader.load_context_files(args.context, config.project_path)
    config.context_files = context_files  # Attach to config for ReviewSession

    return config, context_files


def _create_simple_critic(review):
    """Create a simple critic object from a review for display purposes."""
    class SimpleCritic:
        def __init__(self, review):
            self.name = review.critic_name
            self.role = review.critic_role
            self.icon = review.icon
    return SimpleCritic(review)


def display_results(
    reviews: List,
    consensus: ConsensusResult,
    filepaths: List[str],
    context_files: dict,
    config,
    output_formatter: OutputFormatter
) -> None:
    """
    Display review results to the user.

    Args:
        reviews: List of review results
        consensus: ConsensusResult decision
        filepaths: List of file paths reviewed
        context_files: Context files used
        config: Configuration object
        output_formatter: Output formatter for displaying messages
    """
    # Print summary
    output_formatter.print_success(len(filepaths), len(context_files))
    output_formatter.print_header()

    # Print critic intro if we have critics
    if reviews and len(reviews) > 0 and hasattr(reviews[0], 'critic_name'):
        critics_for_intro = [
            _create_simple_critic(review)
            for review in reviews[:3]  # First 3 reviews
        ]
        output_formatter.print_critic_intro(critics_for_intro)

    output_formatter.print_context_info(context_files, config.details)

    # Print minimal consensus only
    output_formatter.print_consensus_minimal(consensus, reviews)


async def save_and_display_results(
    reviews: List,
    consensus: ConsensusResult,
    filepaths: List[str],
    context_files: dict,
    config,
    output_formatter: OutputFormatter,
    api_stats: APIUsageStats = None
) -> ConsensusResult:
    """
    Display and save review results.

    Args:
        reviews: List of review results
        consensus: ConsensusResult decision
        filepaths: List of file paths reviewed
        context_files: Context files used
        config: Configuration object
        output_formatter: Output formatter for displaying messages
        api_stats: Optional API usage statistics

    Returns:
        The consensus object
    """
    # Display results
    display_results(reviews, consensus, filepaths, context_files, config, output_formatter)

    # Save results
    result_saver = ResultSaver()
    session_dir = result_saver.save_results(reviews, consensus)
    output_formatter.print_save_success(session_dir, len(reviews))

    # Display API usage summary if available
    if api_stats and (api_stats.api_calls > 0 or api_stats.total_tokens > 0):
        output_formatter.print_api_usage_summary(api_stats)

    return consensus


async def main_async(args, output_formatter: OutputFormatter, color_class) -> ConsensusResult:
    """
    Async main logic - refactored into smaller, focused functions.

    This function orchestrates the review workflow by delegating to
    specialized helper functions:
    - handle_security_consent(): Security warning and user consent
    - determine_async_mode(): Async/sync mode detection
    - load_configuration_and_context(): Configuration loading
    - ReviewSession.run(): The review workflow
    - save_and_display_results(): Result display and saving

    Args:
        args: Parsed command-line arguments
        output_formatter: Output formatter for displaying messages
        color_class: Color class for terminal output

    Returns:
        ConsensusResult object with the review decision
    """
    from council.session import ReviewSession

    # Handle security consent
    handle_security_consent(args, output_formatter)

    # Determine async mode
    use_async = determine_async_mode(args, output_formatter)

    # Load configuration and context
    config, context_files = await load_configuration_and_context(args, output_formatter)

    # Run review workflow
    async with create_client_factory(use_async=use_async, timeout=args.timeout, max_concurrent=args.max_concurrent) as session:
        review_session = ReviewSession(config, output_formatter, session)
        reviews, consensus, filepaths, context_files = await review_session.run(args, use_async)

        # Get API stats from the review session
        api_stats = review_session.get_api_stats()

        # Display and save results
        return await save_and_display_results(
            reviews, consensus, filepaths, context_files, config, output_formatter, api_stats
        )


def main() -> None:
    """
    Main application entry point.

    Orchestrates argument parsing, color setup, and error handling.
    Delegates the actual review workflow to main_async().
    """
    # Parse arguments
    from council.cli import cmd_init
    parser, args = ArgumentParser.parse_arguments()

    # Handle init command
    if args.command == 'init':
        sys.exit(cmd_init())

    # Setup color handling
    color_class = NoColors if args.no_color else Colors
    output_formatter = OutputFormatter(color_class)

    try:
        # Run async main logic
        consensus = asyncio.run(main_async(args, output_formatter, color_class))

        # FIX-011: Use documented exit code mapping
        sys.exit(get_exit_code(consensus))

    except ConfigError as e:
        output_formatter.print_error("Configuration", str(e))
        sys.exit(1)
    except APIError as e:
        output_formatter.print_error("API", str(e))
        sys.exit(1)
    except FileError as e:
        output_formatter.print_error("File", str(e))
        sys.exit(1)
    except CouncilError as e:
        output_formatter.print_error("Council", str(e))
        sys.exit(1)
    except Exception as e:
        OutputFormatter().print_error("Unexpected", str(e))
        sys.exit(1)


if __name__ == '__main__':
    main()