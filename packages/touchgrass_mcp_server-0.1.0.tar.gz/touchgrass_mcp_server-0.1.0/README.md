# touchgrass

Emotional memory and behavioral intelligence for AI agents. Detects mood from text, tracks Bayesian beliefs with subjective logic, identifies misalignment between stated goals and actual behavior (dual-engine gap analysis), gates high-intensity memories for human review, and assembles voice-adaptive briefings.

MCP server for Claude Code. 21 tools, SQLite persistence, zero external dependencies at runtime.

## Current status

| Feature | Status | Requires setup | Automated |
|---------|--------|---------------|-----------|
| Mood detection | Working | None | Yes — call `detect_mood` per message |
| Belief tracking | Working | None | Yes — Bayesian updates accumulate |
| Gap analysis | Working | Repeated use | Yes — needs 3+ observations per topic |
| Governed memory | Working | None | Yes — encoding weight + conflict gating |
| Briefing assembly | Working | Pending items in DB | Yes — assembles from available data |
| Patterns | Data model only | Manual insert | No — auto-detection not implemented |
| Email ingestion | Code present | Gmail API credentials | No — returns empty without credentials |
| Calendar ingestion | Code present | Google Calendar credentials | No — returns empty without credentials |
| Weather context | Code present | Weather API key | No — returns empty without credentials |
| Voice adaptation | Code present | Manual calibration samples | No — requires labeled audio input |
| Scheduler | Code present | Not wired to MCP | No — exists as library, not triggered |

**Bottom line:** Mood, beliefs, gap analysis, governed memory, and briefings work out of the box. Ingestion (email/calendar/weather), voice, and patterns require manual setup or are not yet automated.

## When to use this

- Your agent needs to **remember emotional context** across sessions, not just facts
- You want to **detect when stated priorities don't match actual behavior** (says marketing is #1, spends all time coding)
- You need **governance gating** on memory writes: high-intensity or high-conflict memories held for human review before storage
- You want **Bayesian belief tracking** with formal uncertainty quantification (Josang subjective logic)
- Your agent should **adapt its communication style** based on the user's detected emotional state

## Use cases

1. **Coaching agent** — Track what a user says they want to focus on vs what they actually engage with. Surface the gap: "You've mentioned shipping the proposal 4 times but spent 80% of your messages on side projects."
2. **Session continuity** — Store emotionally significant events with governance. Next session, recall: "Last time you were frustrated about the budget review. That memory was held and approved."
3. **Adaptive briefing** — Detect stressed voice/mood, deliver compressed essentials-only briefing instead of full analysis.
4. **Belief auditing** — Track confidence in claims over time with formal uncertainty. "Your belief in 'Q2 launch is feasible' has decayed from 0.85 to 0.42 over 6 sessions."
5. **Authority-weighted reasoning** — Weight opinions differently based on source trust. Your manager's input on work priorities counts more than a casual comment.

## Typical session flow

```
User message
  → detect_mood (text analysis → valence, arousal, quadrant)
  → update_belief (if evidence for/against a tracked claim)
  → get_gap_analysis (persona engine vs reward model on active topics)
  → store_emotional_memory (governance gate: allow or hold)
  → get_pending_briefing (assemble NOW / SINCE LAST / NEXT)
```

Not every tool fires every message. `detect_mood` is the only one expected on every interaction. The others trigger based on content: beliefs update when evidence appears, gap analysis runs when topics are active, memories store when something emotionally significant happens.

## Example output

**Gap analysis** after 5+ sessions where user says "health is my priority" but talks exclusively about work:

```json
{
  "topic_gaps": [{
    "topic": "health",
    "persona_opinion": 0.82,
    "reward_opinion": 0.31,
    "gap_magnitude": 0.51,
    "gap_direction": "persona_leads",
    "conflict_severity": "high",
    "observations": 7
  }],
  "overall_divergence": 0.51,
  "dominant_engine": "persona"
}
```

Translation: the user's stated values (persona = 0.82) strongly favor health, but their actual engagement pattern (reward = 0.31) doesn't match. Gap magnitude 0.51 exceeds the significance threshold (0.3) with 7 observations.

**Governance hold** when a high-intensity memory is submitted:

```json
{
  "status": "held",
  "reason": "encoding_weight 1.47 >= 1.3 threshold",
  "hold_id": "h_abc123",
  "action_required": "Call resolve_hold with hold_id and decision (approve/reject)"
}
```

## Quick start

### 1. Clone and set up

```bash
git clone https://github.com/chrbailey/touchgrass.git
cd touchgrass
python3 -m venv .venv
source .venv/bin/activate
pip install pytest  # only dev dependency
```

### 2. Configure for Claude Code

Add to your `.mcp.json` (use absolute paths):

```json
{
  "mcpServers": {
    "touchgrass": {
      "command": "/absolute/path/to/touchgrass/.venv/bin/python3",
      "args": ["-u", "/absolute/path/to/touchgrass/server.py"]
    }
  }
}
```

The `-u` flag is required for unbuffered stdout (MCP Content-Length framing fails without it).

### 3. Verify

```bash
python -m pytest tests/ -v   # 220 tests
```

## Tools

### Mood and emotional state

| Tool | When to call it | Required params |
|------|----------------|-----------------|
| `detect_mood` | Every user message to track emotional trajectory | `text` |
| `get_voice_state` | Before assembling a briefing to adapt tone (requires prior calibration) | none |
| `get_calibration_status` | Check if voice model has enough personal data | none |
| `run_calibration_session` | Store a labeled voice sample for personalization | `label` |

### Belief tracking

| Tool | When to call it | Required params |
|------|----------------|-----------------|
| `query_beliefs` | Look up current probability and uncertainty for a belief | `belief_id` |
| `update_belief` | New evidence confirms, rejects, or weakens a belief | `belief_id`, `action` |

Beliefs use **Josang subjective logic**: each belief is a `(belief, disbelief, uncertainty)` triple that sums to 1.0. Multiple opinions fuse via cumulative fusion. Trust-discounted sources shift toward maximum uncertainty.

### Gap analysis (dual-engine)

| Tool | When to call it | Required params |
|------|----------------|-----------------|
| `get_gap_analysis` | Detect misalignment between goals and behavior on specific topics | `text`, `topics` |
| `explain_behavior` | User asks "why do I keep doing X when I say Y matters?" | `behavior`, `topics` |
| `get_pushback` | Get active misalignments exceeding significance threshold | none |
| `get_patterns` | Get manually inserted behavioral correlations (auto-detection not implemented) | none |
| `get_influence_analysis` | See authority sources, compliance tendency, reward profile | none |
| `manage_authority` | Add or update a trust-weighted authority source | `source_id`, `name`, `tier` |

The **dual-engine model** implements Higgins' Self-Discrepancy Theory:
- **Persona engine (should-self):** What the user says they should do, weighted by authority trust and compliance
- **Reward model (want-self):** What the user actually gravitates toward, tracked via approach/avoidance signals

Gap magnitude = `|persona.expected_value - reward.expected_value|`. Gaps are significant when magnitude > 0.3 with 3+ observations.

### Memory (governed)

| Tool | When to call it | Required params |
|------|----------------|-----------------|
| `store_emotional_memory` | Capture an emotionally significant event or insight | `content` |
| `search_memories` | Recall past emotional context by keyword (FTS5, default limit 10) | `query` |
| `list_holds` | Check governance queue for memories awaiting human review | none |
| `resolve_hold` | Approve or reject a held memory | `hold_id`, `decision` |

**Governance gating:** `store_emotional_memory` computes encoding weight from mood intensity and context. Memories with `encoding_weight >= 1.3` or `conflict_score > 0.5` are held for human review instead of stored directly.

### Briefing and context

| Tool | When to call it | Required params |
|------|----------------|-----------------|
| `get_pending_briefing` | Start of session: what needs attention? | none |
| `mark_briefed` | After delivering briefing items to user | `item_ids` |
| `get_email_summary` | Prioritized inbox (requires Gmail credentials) | none |
| `get_calendar_context` | Today's schedule (requires Google Calendar credentials) | none |
| `get_ambient_context` | Weather and time patterns (requires weather API key) | none |

Briefings adapt to emotional state:
- **Frustrated/Reflective:** Minimal format, essentials only
- **Pressured:** Compressed, action-focused
- **Excited:** Full analysis with pushback on overcommitment
- **Calm/Neutral:** Standard NOW / SINCE LAST / NEXT format

**Note:** `get_email_summary`, `get_calendar_context`, and `get_ambient_context` return empty results unless their respective API credentials are configured. The briefing engine assembles from whatever data sources are available.

## Data and privacy

- **Database location:** `~/.claude/plugins/touchgrass/data/touchgrass.db` (auto-created on first run)
- **Persistence:** All data (moods, beliefs, memories, gap history, audit log) persists across sessions automatically
- **No cloud dependencies:** Everything runs locally in SQLite. No data leaves the machine unless you configure external ingestion (Gmail, Calendar, Weather APIs)
- **Audio:** Raw audio is never stored. Voice calibration stores only extracted features (pitch, pace, volume, spectral centroid) as numeric values
- **Audit trail:** Every governance action (hold created, hold resolved, memory stored) is logged with timestamps and session IDs. The audit log is append-only
- **Schema:** 22 tables, WAL mode, foreign key enforcement. See [ARCHITECTURE.md](ARCHITECTURE.md) for full schema and data model details

## Architecture

```
server.py              MCP entry point: 21 tool definitions, JSON-RPC 2.0 dispatch
lib/
  db.py                SQLite persistence (WAL mode, FTS5, FK enforcement)
  init_db.py           Schema: 22 tables, auto-created on first run
  engines/
    models.py          14 dataclasses: MoodState, EngineOpinion, GapAnalysis, etc.
    belief.py          Subjective logic: Uncertainty triples, cumulative fusion,
                       trust discount, Beta decomposition
    engines.py         Stateless: MoodDetector (regex), BeliefExtractor, Introspective
    engines_db.py      DB-backed: Authority, Compliance, Reward, Gap, Persona, Governance
  voice/               Manual calibration pipeline (not always-on)
  ingest/              Email/calendar/weather (requires external credentials)
  briefing/            NOW / SINCE LAST / NEXT assembly, voice-adaptive output
```

For detailed architecture including engine math, belief formulas, data model diagrams, known issues, and theoretical references, see [ARCHITECTURE.md](ARCHITECTURE.md).

## Key design decisions

**Why SQLite, not a vector DB?** Emotional memory search uses FTS5 full-text indexing, not embedding similarity. The queries are keyword-based ("find memories about confrontation"), not semantic. SQLite with WAL mode handles concurrent reads from the same process without coordination overhead.

**Why dual engines instead of a single sentiment score?** A single score can't distinguish "says X but does Y." The persona engine captures what the user articulates as important; the reward model tracks what they actually engage with. The gap between these two is the actionable signal.

**Why governance gating?** High-intensity emotional memories (arguments, confrontations, euphoric wins) are exactly the ones most likely to be recorded inaccurately. Holding them for human review before permanent storage prevents the agent from building a distorted emotional model.

**Why regex-based mood detection?** It's fast, deterministic, and transparent. No LLM call needed, no latency, no cost. The patterns are tuned for the specific signals that matter (frustration, excitement, worry, compliance) rather than general sentiment. The tradeoff: it misses nuance that an LLM would catch. That's acceptable for a signal that gets refined by the dual-engine pipeline.

## MCP protocol

- **Input:** `sys.stdin.readline()` accepts both line-delimited JSON and Content-Length framing
- **Output:** Content-Length framing via `sys.stdout.buffer.write()` with byte-length calculation
- **Singleton state:** One `TouchgrassDB` instance and one `session_id` per server lifetime
- **Error handling:** Unknown tools return JSON-RPC error code `-32601`; malformed JSON is silently skipped

## Testing

```bash
python -m pytest tests/ -v                   # All 220 tests
python -m pytest tests/test_touchgrass.py    # 58 unit tests
python -m pytest tests/test_enterprise.py    # 97 enterprise/boundary tests
python -m pytest tests/test_comprehensive.py # 65 integration tests (real user data)
python tests/smoke_test_live.py              # 10 live MCP tests over stdio
```

## License

MIT
