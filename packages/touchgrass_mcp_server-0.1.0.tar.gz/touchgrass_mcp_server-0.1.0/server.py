"""touchgrass MCP server — 20 tools for the AI Chief of Staff."""
from __future__ import annotations

import json
import sys
import uuid
from typing import Any, Dict, List, Optional

# MCP protocol via stdin/stdout (JSON-RPC 2.0)
# This server implements the MCP specification for local tool serving.

from touchgrass_lib.db import TouchgrassDB
from touchgrass_lib.engines.engines import MoodDetector, BeliefExtractor, compute_encoding_weight, IntrospectiveLayer
from touchgrass_lib.engines.engines_db import (
    AuthorityGraphDB, ComplianceDetectorDB, RewardModelDB,
    ApproachAvoidanceDetectorDB, GapAnalyzerDB, TruthLayerDB,
    PersonaEngineDB, GovernanceLayerDB,
)
from touchgrass_lib.engines.models import (
    AuthorityTier, EmotionalQuadrant, EngineOpinion, RewardType,
)


# =============================================================================
# SINGLETON STATE
# =============================================================================

_db: Optional[TouchgrassDB] = None
_session_id: str = ""
_last_mood: Optional[Dict[str, Any]] = None  # cached from last detect_mood call
_last_gap: Optional[Dict[str, Any]] = None   # cached from last get_gap_analysis call


def get_db() -> TouchgrassDB:
    global _db
    if _db is None:
        _db = TouchgrassDB()
    return _db


def get_session() -> str:
    global _session_id
    if not _session_id:
        _session_id = f"s_{uuid.uuid4().hex[:8]}"
        get_db().start_session(_session_id)
    return _session_id


# =============================================================================
# TOOL DEFINITIONS
# =============================================================================

TOOLS = [
    # --- Ported from mypersona ---
    {
        "name": "detect_mood",
        "description": "Analyze text for emotional valence and arousal. Returns quadrant (excited/calm/stressed/low/neutral), intensity, and confidence.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "The text to analyze for mood signals"}
            },
            "required": ["text"],
        },
    },
    {
        "name": "query_beliefs",
        "description": "Query the Bayesian belief network. Returns probability, variance, and epistemic/aleatoric decomposition for a belief.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "belief_id": {"type": "string", "description": "The belief identifier to query"},
            },
            "required": ["belief_id"],
        },
    },
    {
        "name": "update_belief",
        "description": "Update a belief with new evidence. Actions: confirm, reject, weaken.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "belief_id": {"type": "string", "description": "The belief to update"},
                "action": {"type": "string", "enum": ["confirm", "reject", "weaken"], "description": "How to update"},
                "strength": {"type": "number", "description": "Evidence strength (default 5.0)"},
            },
            "required": ["belief_id", "action"],
        },
    },
    {
        "name": "get_gap_analysis",
        "description": "Get dual-engine divergence analysis. Shows where persona (should-self) and reward (want-self) disagree, with trend and severity.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Current message for context"},
                "topics": {"type": "array", "items": {"type": "string"}, "description": "Topics to analyze"},
            },
            "required": ["text", "topics"],
        },
    },
    {
        "name": "explain_behavior",
        "description": "Explain why behavior doesn't match stated goals using gap analysis.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "behavior": {"type": "string", "description": "The behavior to explain"},
                "topics": {"type": "array", "items": {"type": "string"}, "description": "Related topics"},
            },
            "required": ["behavior", "topics"],
        },
    },
    {
        "name": "get_influence_analysis",
        "description": "Get authority sources, compliance tendency, and reward profile.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "manage_authority",
        "description": "Add or update a trust-discounted authority source.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "source_id": {"type": "string"},
                "name": {"type": "string"},
                "tier": {"type": "string", "enum": ["formal", "institutional", "personal", "peer", "ambient"]},
                "trust_weight": {"type": "number", "description": "0.0 to 1.0"},
                "influence_topics": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["source_id", "name", "tier"],
        },
    },
    {
        "name": "store_emotional_memory",
        "description": "Store an emotional memory with governance gating. High-intensity or high-conflict memories are held for review.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "The memory content"},
                "topic_tags": {"type": "array", "items": {"type": "string"}},
                "encoding_weight": {"type": "number", "description": "Override encoding weight (auto-computed if omitted)"},
            },
            "required": ["content"],
        },
    },
    {
        "name": "search_memories",
        "description": "Full-text search over emotional memory store.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "limit": {"type": "integer", "description": "Max results (default 5)"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "list_holds",
        "description": "List governance holds awaiting human approval.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "include_resolved": {"type": "boolean", "description": "Include resolved holds"},
            },
        },
    },
    {
        "name": "resolve_hold",
        "description": "Approve or reject a governance hold.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "hold_id": {"type": "string"},
                "decision": {"type": "string", "enum": ["approve", "reject"]},
                "reason": {"type": "string"},
            },
            "required": ["hold_id", "decision"],
        },
    },
    # --- New for touchgrass ---
    {
        "name": "get_voice_state",
        "description": "Get current voice analysis: detected emotional state, confidence, and features.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_calibration_status",
        "description": "Check how much personal voice calibration data exists.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "run_calibration_session",
        "description": "Store a calibration data point from the audition.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "label": {"type": "string", "description": "State label: calm, excited, frustrated, pressured, reflective, etc."},
                "pitch_mean": {"type": "number"},
                "pitch_std": {"type": "number"},
                "pace_wpm": {"type": "number"},
                "volume_db": {"type": "number"},
                "pause_ratio": {"type": "number"},
                "spectral_centroid": {"type": "number"},
            },
            "required": ["label"],
        },
    },
    {
        "name": "get_pending_briefing",
        "description": "Get items needing attention since last sync. Returns prioritized list for NOW / SINCE LAST / NEXT format.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "mark_briefed",
        "description": "Mark pending items as delivered to principal.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "item_ids": {"type": "array", "items": {"type": "integer"}, "description": "IDs of items to mark as briefed"},
            },
            "required": ["item_ids"],
        },
    },
    {
        "name": "get_email_summary",
        "description": "Get prioritized inbox: urgent / needs-reply / FYI / noise.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_calendar_context",
        "description": "Get today's schedule, prep needs, and conflicts.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "hours_ahead": {"type": "integer", "description": "Hours to look ahead (default 24)"},
            },
        },
    },
    {
        "name": "get_ambient_context",
        "description": "Get weather, time patterns, and energy predictions.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_patterns",
        "description": "Get learned correlations: people patterns, time patterns, topic patterns.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "min_observations": {"type": "integer", "description": "Minimum observations to include (default 3)"},
            },
        },
    },
    {
        "name": "get_pushback",
        "description": "Get active misalignments between stated goals and actual behavior for priority challenge.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Current context for analysis"},
            },
        },
    },
    {
        "name": "get_status",
        "description": "Healthcheck: data depth per subsystem, gap history per topic, and guidance on what to do next to get value.",
        "inputSchema": {"type": "object", "properties": {}},
    },
]


# =============================================================================
# TOOL HANDLERS
# =============================================================================

def handle_detect_mood(args: dict) -> dict:
    global _last_mood
    detector = MoodDetector()
    mood = detector.detect(args["text"])
    db = get_db()
    db.record_mood(
        get_session(), mood.valence, mood.arousal,
        mood.quadrant.value, mood.intensity, mood.confidence, mood.signals,
    )
    _last_mood = {
        "valence": mood.valence, "arousal": mood.arousal,
        "quadrant": mood.quadrant.value, "intensity": mood.intensity,
    }
    return mood.to_dict()


def handle_query_beliefs(args: dict) -> dict:
    db = get_db()
    truth = TruthLayerDB(db)
    belief = truth.get_belief(args["belief_id"])
    if not belief:
        return {"error": f"Belief '{args['belief_id']}' not found"}
    from touchgrass_lib.engines.belief import decompose_from_beta
    decomp = decompose_from_beta(belief.alpha, belief.beta)
    return {
        "belief_id": args["belief_id"],
        "text": belief.text,
        "probability": round(belief.probability, 3),
        "variance": round(belief.variance, 5),
        "alpha": belief.alpha,
        "beta": belief.beta,
        "decomposition": {
            "mean": round(decomp.mean, 3),
            "epistemic_variance": round(decomp.epistemic_variance, 5),
            "aleatoric_variance": round(decomp.aleatoric_variance, 5),
            "confidence": round(decomp.confidence, 3),
        },
    }


def handle_update_belief(args: dict) -> dict:
    db = get_db()
    truth = TruthLayerDB(db)
    cid = args["belief_id"]
    action = args["action"]
    strength = args.get("strength", 5.0)
    evidence = args.get("evidence", "")
    # Auto-create belief if it doesn't exist
    if not truth.get_belief(cid):
        truth.add_claim(cid, evidence or cid, "general")
    supports = action == "confirm"
    if action == "weaken":
        supports = False
        strength *= 0.5
    truth.update_belief(cid, supports, strength, get_session())
    belief = truth.get_belief(cid)
    if not belief:
        return {"error": f"Belief '{cid}' not found"}
    return {
        "belief_id": cid, "action": action,
        "new_probability": round(belief.probability, 3),
    }


def handle_get_gap_analysis(args: dict) -> dict:
    db = get_db()
    text = args.get("text", "")
    topics = args.get("topics", [])

    mood_detector = MoodDetector()
    mood = mood_detector.detect(text)

    authority = AuthorityGraphDB(db)
    compliance = ComplianceDetectorDB(db)
    truth = TruthLayerDB(db)
    persona_engine = PersonaEngineDB(truth, authority, compliance)
    reward_model = RewardModelDB(db)
    aa_detector = ApproachAvoidanceDetectorDB(db)
    gap_analyzer = GapAnalyzerDB(db)

    persona_opinions = persona_engine.process(text, mood, topics, get_session())

    # Build reward opinions from approach/avoidance data
    from touchgrass_lib.engines.engines import TOPIC_TO_REWARD_MAP
    reward_opinions = {}
    for topic in topics:
        aa = aa_detector.analyze(text, topic, mood)
        topic_cat = TOPIC_TO_REWARD_MAP.get(topic, topic)
        reward_model.observe(topic_cat, mood.valence)

        ratio = aa.approach_ratio
        u_val = max(0.05, 0.5 / max(1, aa.observations))
        b_val = ratio * (1.0 - u_val)
        d_val = max(0.0, 1.0 - b_val - u_val)
        reward_opinions[topic] = EngineOpinion(
            topic=topic, belief=round(b_val, 3),
            disbelief=round(d_val, 3), uncertainty=round(u_val, 3),
            source_signals=[f"approach_ratio:{ratio:.2f}", f"observations:{aa.observations}"],
        )

    analysis = gap_analyzer.analyze(persona_opinions, reward_opinions, get_session())

    # Cache latest gap state for store_emotional_memory
    global _last_gap
    gaps = analysis.topic_gaps
    if gaps:
        top = max(gaps, key=lambda g: g.gap_magnitude)
        _last_gap = {
            "conflict_score": top.gap_magnitude,
            "persona_opinion": top.persona_opinion,
            "reward_opinion": top.reward_opinion,
            "gap_magnitude": top.gap_magnitude,
            "gap_direction": top.gap_direction,
        }

    return analysis.to_dict()


def handle_explain_behavior(args: dict) -> dict:
    db = get_db()
    gap_analyzer = GapAnalyzerDB(db)

    # Get latest gap analysis from history
    topics = args.get("topics", [])
    text = args.get("behavior", "")

    # Reconstruct a minimal gap analysis from stored data
    from touchgrass_lib.engines.models import TopicGap, GapAnalysis
    gaps = []
    for topic in topics:
        history = db.get_gap_history(topic, limit=1)
        if history:
            h = history[0]
            gaps.append(TopicGap(
                topic=topic,
                persona_opinion=h["persona_val"],
                reward_opinion=h["reward_val"],
                gap_magnitude=h["gap_magnitude"],
                gap_direction=h["gap_direction"],
                conflict_severity=h["severity"],
                explanation="",
                observations=len(db.get_gap_history(topic)),
            ))

    analysis = GapAnalysis(topic_gaps=gaps)
    explanation = gap_analyzer.explain_behavior(text, analysis)
    return {"explanation": explanation}


def handle_get_influence_analysis(args: dict) -> dict:
    db = get_db()
    authority = AuthorityGraphDB(db)
    compliance = ComplianceDetectorDB(db)
    reward = RewardModelDB(db)

    return {
        "authority_sources": authority.to_dict(),
        "compliance": {
            "score": round(compliance.profile.compliance_score, 3),
            "alpha": compliance.profile.alpha,
            "beta": compliance.profile.beta,
        },
        "reward_profile": reward.get_scores(),
    }


def handle_manage_authority(args: dict) -> dict:
    db = get_db()
    authority = AuthorityGraphDB(db)
    tier = AuthorityTier(args["tier"])
    source = authority.add_source(
        args["source_id"], args["name"], tier,
        args.get("trust_weight", 0.5),
        args.get("influence_topics"),
    )
    return {
        "source_id": source.source_id, "name": source.name,
        "tier": source.tier.value, "trust_weight": source.trust_weight,
    }


def handle_store_emotional_memory(args: dict) -> dict:
    db = get_db()
    governance = GovernanceLayerDB(db)

    content = args["content"]
    topic_tags = args.get("topic_tags", [])
    ew = args.get("encoding_weight", 0.5)
    memory_id = f"m_{uuid.uuid4().hex[:8]}"

    # Pull emotional context from session cache
    mood = _last_mood or {}
    gap = _last_gap or {}
    valence = mood.get("valence", 0.0)
    arousal = mood.get("arousal", 0.0)
    quadrant = mood.get("quadrant", "neutral")
    conflict_score = gap.get("conflict_score", 0.0)
    persona_opinion = gap.get("persona_opinion", 0.5)
    reward_opinion = gap.get("reward_opinion", 0.5)
    gap_magnitude = gap.get("gap_magnitude", 0.0)
    gap_direction = gap.get("gap_direction", "")

    # Corroboration: count how many existing memories match this content
    corroboration = 0
    if topic_tags:
        for tag in topic_tags:
            try:
                hits = db.search_memories(tag, limit=3)
                corroboration += len(hits)
            except Exception:
                pass

    gate = governance.gate_memory_write(
        memory_id, ew, conflict_score, "unverified", corroboration, get_session(),
    )

    if gate == "allowed":
        db.store_memory(
            memory_id, content, get_session(),
            encoding_weight=ew, topic_tags=topic_tags,
            conflict_score=conflict_score, persona_opinion=persona_opinion,
            reward_opinion=reward_opinion, gap_magnitude=gap_magnitude,
            gap_direction=gap_direction, valence=valence, arousal=arousal,
            quadrant=quadrant,
        )
        return {"memory_id": memory_id, "status": "stored", "gate": "allowed",
                "emotional_context": {"valence": valence, "quadrant": quadrant,
                                      "conflict_score": conflict_score}}
    else:
        return {"memory_id": memory_id, "status": "held", "gate": "held",
                "message": "Memory held for governance review. Use list_holds to see pending holds."}


def handle_search_memories(args: dict) -> dict:
    db = get_db()
    results = db.search_memories(args["query"], args.get("limit", 5))
    return {"results": results, "count": len(results)}


def handle_list_holds(args: dict) -> dict:
    db = get_db()
    include_resolved = args.get("include_resolved", False)
    holds = db.get_all_holds(include_resolved)
    return {"holds": holds, "count": len(holds)}


def handle_resolve_hold(args: dict) -> dict:
    db = get_db()
    governance = GovernanceLayerDB(db)
    success = governance.resolve_hold(
        args["hold_id"], args["decision"],
        args.get("reason", ""), get_session(),
    )
    return {"success": success, "hold_id": args["hold_id"], "decision": args["decision"]}


def handle_get_voice_state(args: dict) -> dict:
    db = get_db()
    state = db.get_latest_voice_state(get_session())
    if not state:
        return {"status": "no_data", "message": "No voice state detected. Run /calibrate to set up voice analysis."}
    return state


def handle_get_calibration_status(args: dict) -> dict:
    db = get_db()
    calibration = db.get_calibration()
    labels = [c["label"] for c in calibration]
    return {
        "calibration_points": len(calibration),
        "labels": labels,
        "sufficient": len(calibration) >= 5,
        "recommended": 8,
        "message": (
            f"{len(calibration)} calibration points recorded. "
            f"{'Ready for voice analysis.' if len(calibration) >= 5 else f'Need {5 - len(calibration)} more for minimum baseline.'}"
        ),
    }


def handle_run_calibration_session(args: dict) -> dict:
    db = get_db()
    cal_id = db.store_calibration(
        label=args["label"],
        pitch_mean=args.get("pitch_mean", 0.0),
        pitch_std=args.get("pitch_std", 0.0),
        pace_wpm=args.get("pace_wpm", 0.0),
        volume_db=args.get("volume_db", 0.0),
        pause_ratio=args.get("pause_ratio", 0.0),
        spectral_centroid=args.get("spectral_centroid", 0.0),
    )
    total = len(db.get_calibration())
    return {
        "calibration_id": cal_id,
        "label": args["label"],
        "total_points": total,
        "sufficient": total >= 5,
    }


def handle_get_pending_briefing(args: dict) -> dict:
    db = get_db()
    pending = db.get_pending_items()
    emails = db.get_unbriefed_emails()
    events = db.get_upcoming_events(24)
    weather = db.get_latest_weather()

    if not pending and not emails and not events and not weather:
        return {"status": "not_configured",
                "setup_required": "No briefing data. Wire email/calendar/weather ingestion or add pending items manually."}

    now_item = None
    since_last = []
    next_actions = []

    if pending:
        now_item = pending[0]
        since_last = pending[1:4]

    for event in events[:3]:
        next_actions.append({
            "type": "calendar",
            "title": event.get("title", ""),
            "start_time": event.get("start_time", ""),
        })

    return {
        "now": now_item,
        "since_last": since_last,
        "next": next_actions,
        "unbriefed_emails": len(emails),
        "upcoming_events": len(events),
        "weather": weather,
    }


def handle_mark_briefed(args: dict) -> dict:
    db = get_db()
    pending = db.get_pending_items()
    if not pending:
        return {"status": "not_configured",
                "setup_required": "No pending items to mark. Wire ingestion pipeline first."}
    db.mark_briefed(args["item_ids"])
    return {"marked": len(args["item_ids"])}


def handle_get_email_summary(args: dict) -> dict:
    db = get_db()
    emails = db.get_unbriefed_emails()
    if not emails:
        return {"status": "not_configured",
                "setup_required": "No emails ingested. Set up Gmail API credentials and run the email ingestion pipeline."}
    urgent = [e for e in emails if e.get("priority") == "urgent"]
    needs_reply = [e for e in emails if e.get("priority") == "needs_reply"]
    fyi = [e for e in emails if e.get("priority") == "fyi"]
    noise = [e for e in emails if e.get("priority") == "noise"]
    return {
        "total": len(emails),
        "urgent": urgent,
        "needs_reply": needs_reply,
        "fyi": fyi[:5],
        "noise_count": len(noise),
    }


def handle_get_calendar_context(args: dict) -> dict:
    db = get_db()
    hours = args.get("hours_ahead", 24)
    events = db.get_upcoming_events(hours)
    if not events:
        return {"status": "not_configured",
                "setup_required": "No calendar events. Set up Google Calendar API credentials and run calendar ingestion."}
    return {"events": events, "count": len(events)}


def handle_get_ambient_context(args: dict) -> dict:
    db = get_db()
    weather = db.get_latest_weather()
    moods = db.get_mood_history(10)

    if not weather and not moods:
        return {"status": "not_configured",
                "setup_required": "No ambient data. Set up weather API and/or call detect_mood to build mood history."}

    avg_valence = 0.0
    if moods:
        avg_valence = sum(m.get("valence", 0) for m in moods) / len(moods)

    return {
        "weather": weather,
        "recent_mood_trend": {
            "avg_valence": round(avg_valence, 3),
            "readings": len(moods),
        },
        "time_context": {
            "note": "Pattern-based energy predictions will improve with more data.",
        },
    }


def handle_get_patterns(args: dict) -> dict:
    db = get_db()
    min_obs = args.get("min_observations", 3)
    patterns = db.get_active_patterns(min_obs)

    if not patterns:
        return {"status": "not_configured",
                "setup_required": "No patterns detected yet. Patterns emerge from repeated mood/gap/authority observations over multiple sessions."}

    people = [p for p in patterns if p.get("pattern_type") == "people"]
    time = [p for p in patterns if p.get("pattern_type") == "time"]
    topic = [p for p in patterns if p.get("pattern_type") == "topic"]

    return {
        "people_patterns": people,
        "time_patterns": time,
        "topic_patterns": topic,
        "total": len(patterns),
    }


def handle_get_pushback(args: dict) -> dict:
    db = get_db()
    # Get all topics with gap history
    topics = db.get_all_gap_topics()

    misalignments = []
    for topic in topics:
        history = db.get_gap_history(topic, limit=5)
        if len(history) < 3:
            continue
        latest = history[0]  # most recent
        if latest["gap_magnitude"] > 0.3:
            misalignments.append({
                "topic": topic,
                "gap_magnitude": latest["gap_magnitude"],
                "gap_direction": latest["gap_direction"],
                "severity": latest["severity"],
                "persona_val": latest["persona_val"],
                "reward_val": latest["reward_val"],
                "observations": len(history),
            })

    misalignments.sort(key=lambda x: x["gap_magnitude"], reverse=True)
    return {
        "misalignments": misalignments,
        "count": len(misalignments),
        "message": (
            "No significant misalignments detected yet."
            if not misalignments
            else f"{len(misalignments)} active misalignment(s) between stated goals and behavior."
        ),
    }


def handle_get_status(args: dict) -> dict:
    db = get_db()
    counts = db.get_status_counts()

    # Gap history per topic
    gap_topics = db.get_all_gap_topics()
    gap_summary = {}
    for topic in gap_topics:
        history = db.get_gap_history(topic, limit=1)
        if history:
            gap_summary[topic] = {
                "latest_magnitude": history[0]["gap_magnitude"],
                "direction": history[0]["gap_direction"],
                "total_readings": len(db.get_gap_history(topic)),
            }

    # Guidance — what to do next
    guidance = []
    if counts["mood_readings"] == 0:
        guidance.append("Call detect_mood with a text sample to start building emotional baseline.")
    if counts["beliefs"] == 0:
        guidance.append("Call update_belief to seed your belief network with a starting claim.")
    if counts["authorities"] == 0:
        guidance.append("Call manage_authority to add a trust source (boss, mentor, etc.).")
    if counts["gap_entries"] < 3:
        guidance.append("Call get_gap_analysis 3+ times on topics you care about to build trend data.")
    if counts["memories"] == 0:
        guidance.append("Call store_emotional_memory to begin your governed memory archive.")
    if counts["calibration_points"] < 5:
        guidance.append(f"Voice calibration: {counts['calibration_points']}/5 minimum points. Run /calibrate.")
    if not guidance:
        guidance.append("All subsystems active. Keep conversing to deepen the model.")

    return {
        "counts": counts,
        "gap_topics": gap_summary,
        "guidance": guidance,
        "session_id": get_session(),
    }


# =============================================================================
# TOOL DISPATCH
# =============================================================================

HANDLERS = {
    "detect_mood": handle_detect_mood,
    "query_beliefs": handle_query_beliefs,
    "update_belief": handle_update_belief,
    "get_gap_analysis": handle_get_gap_analysis,
    "explain_behavior": handle_explain_behavior,
    "get_influence_analysis": handle_get_influence_analysis,
    "manage_authority": handle_manage_authority,
    "store_emotional_memory": handle_store_emotional_memory,
    "search_memories": handle_search_memories,
    "list_holds": handle_list_holds,
    "resolve_hold": handle_resolve_hold,
    "get_voice_state": handle_get_voice_state,
    "get_calibration_status": handle_get_calibration_status,
    "run_calibration_session": handle_run_calibration_session,
    "get_pending_briefing": handle_get_pending_briefing,
    "mark_briefed": handle_mark_briefed,
    "get_email_summary": handle_get_email_summary,
    "get_calendar_context": handle_get_calendar_context,
    "get_ambient_context": handle_get_ambient_context,
    "get_patterns": handle_get_patterns,
    "get_pushback": handle_get_pushback,
    "get_status": handle_get_status,
}


# =============================================================================
# MCP PROTOCOL (JSON-RPC 2.0 over stdin/stdout)
# =============================================================================

def handle_request(request: dict) -> dict:
    method = request.get("method", "")
    req_id = request.get("id")
    params = request.get("params", {})

    if method == "initialize":
        # Echo back the client's protocol version for compatibility
        client_version = params.get("protocolVersion", "2024-11-05")
        return {
            "jsonrpc": "2.0", "id": req_id,
            "result": {
                "protocolVersion": client_version,
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": "touchgrass", "version": "0.1.0"},
            },
        }

    if method == "notifications/initialized":
        return None  # No response for notifications

    if method == "tools/list":
        return {
            "jsonrpc": "2.0", "id": req_id,
            "result": {"tools": TOOLS},
        }

    if method == "tools/call":
        tool_name = params.get("name", "")
        tool_args = params.get("arguments", {})
        handler = HANDLERS.get(tool_name)
        if not handler:
            return {
                "jsonrpc": "2.0", "id": req_id,
                "error": {"code": -32601, "message": f"Unknown tool: {tool_name}"},
            }
        try:
            result = handler(tool_args)
            return {
                "jsonrpc": "2.0", "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": json.dumps(result, indent=2, default=str)}],
                },
            }
        except Exception as e:
            return {
                "jsonrpc": "2.0", "id": req_id,
                "error": {"code": -32603, "message": str(e)},
            }

    return {
        "jsonrpc": "2.0", "id": req_id,
        "error": {"code": -32601, "message": f"Method not found: {method}"},
    }


def _read_message() -> Optional[dict]:
    """Read one MCP message from stdin using binary I/O for correct Content-Length handling."""
    global _use_content_length

    # Read header line (binary mode for exact byte handling)
    header_line = sys.stdin.buffer.readline()
    if not header_line:
        return None

    header_str = header_line.decode("utf-8", errors="replace").strip()
    if not header_str:
        return None

    # Content-Length framing (MCP SDK transport / Claude Code)
    if header_str.startswith("Content-Length:"):
        _use_content_length = True
        content_length = int(header_str.split(":", 1)[1].strip())
        # Read remaining headers until blank line
        while True:
            next_line = sys.stdin.buffer.readline()
            if not next_line or next_line.strip() == b"":
                break
        # Read exact byte count for body
        body = sys.stdin.buffer.read(content_length)
        return json.loads(body.decode("utf-8"))

    # Line-delimited JSON (mcporter / simple clients)
    return json.loads(header_str)


_use_content_length = False  # Set True if client sends Content-Length framing


def _write_message(response: dict) -> None:
    """Write one MCP message to stdout, matching client's framing style."""
    body = json.dumps(response).encode("utf-8")
    if _use_content_length:
        header = f"Content-Length: {len(body)}\r\n\r\n".encode("utf-8")
        sys.stdout.buffer.write(header + body)
    else:
        # Line-delimited JSON (mcporter / simple clients)
        sys.stdout.buffer.write(body + b"\n")
    sys.stdout.buffer.flush()


def main():
    """Run the MCP server on stdin/stdout (Content-Length framing + line-delimited fallback)."""
    while True:
        try:
            request = _read_message()
            if request is None:
                break

            response = handle_request(request)
            if response is not None:
                _write_message(response)

        except json.JSONDecodeError:
            continue
        except Exception as e:
            sys.stderr.write(f"touchgrass server error: {e}\n")
            sys.stderr.flush()


if __name__ == "__main__":
    main()
