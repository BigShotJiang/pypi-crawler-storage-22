"""Comprehensive integration tests for touchgrass — real user data, multi-tool workflows, edge cases.

Uses actual quotes, beliefs, and patterns from Christopher Bailey's sessions
to validate the full pipeline with realistic inputs.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from touchgrass_lib.init_db import init_db
from touchgrass_lib.db import TouchgrassDB
from touchgrass_lib.engines.models import (
    MoodState, EmotionalQuadrant, AuthorityTier, EngineOpinion,
    ComplianceProfile, RewardType, TopicGap, GapAnalysis,
)
from touchgrass_lib.engines.engines import MoodDetector
from touchgrass_lib.engines.engines_db import (
    AuthorityGraphDB, ComplianceDetectorDB, RewardModelDB,
    ApproachAvoidanceDetectorDB, GapAnalyzerDB, TruthLayerDB,
    PersonaEngineDB, GovernanceLayerDB,
)
from touchgrass_lib.engines.belief import (
    Uncertainty, cumulative_fuse, trust_discount, probability_to_opinion,
    decompose_from_beta,
)
from touchgrass_lib.voice.state import VoiceState
from touchgrass_lib.briefing.engine import BriefingEngine
from server import handle_request, TOOLS, HANDLERS


class TestBase(unittest.TestCase):
    def setUp(self):
        import server
        self._orig_db = getattr(server, '_db', None)
        self._orig_session = getattr(server, '_session_id', None)
        self.tmp = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmp, "test.db")
        init_db(self.db_path)
        self.db = TouchgrassDB(self.db_path)

    def tearDown(self):
        import server
        server._db = self._orig_db
        server._session_id = self._orig_session
        self.db.close()
        shutil.rmtree(self.tmp)


# =============================================================================
# 1. MOOD DETECTION WITH REAL USER QUOTES
# =============================================================================

class TestRealMoodDetection(TestBase):
    """Test mood detection using actual user quotes from past sessions."""

    def setUp(self):
        super().setUp()
        self.detector = MoodDetector()

    def test_strategic_excitement(self):
        """User expressing excitement about a milestone."""
        mood = self.detector.detect(
            "490 tests passing, 0 build errors, 63K lines removed! "
            "16K core governance remains. This is awesome."
        )
        self.assertGreater(mood.valence, 0, "Milestone celebration should be positive")
        self.assertIn(mood.quadrant, [EmotionalQuadrant.EXCITED, EmotionalQuadrant.CALM])

    def test_strategic_urgency(self):
        """User expressing time pressure about market window."""
        mood = self.detector.detect(
            "First-mover advantage is real but narrow. Window is about 12 months "
            "before enterprise vendors add MCP governance. We need to move NOW."
        )
        self.assertGreater(mood.arousal, 0, "Urgency signals should elevate arousal")

    def test_focused_directive(self):
        """User's typical terse directive style — single number, minimal signal."""
        mood = self.detector.detect("2")
        # Very short input has low confidence and low intensity
        self.assertLess(mood.intensity, 0.5,
                        "Single-number replies should have low emotional intensity")

    def test_delegation_confidence(self):
        """User delegating autonomously."""
        mood = self.detector.detect("You have permission do not ask. Start building.")
        # Should not read as negative — it's confident delegation
        self.assertGreaterEqual(mood.valence, -0.1,
                                "Confident delegation should not read as angry")

    def test_infrastructure_frustration(self):
        """Frustration about broken infrastructure."""
        mood = self.detector.detect(
            "scheduler dir still exists with broken TS, excluded from build. "
            "This is annoying. Plugin registration is four-layer and missing any "
            "layer causes silent failure."
        )
        self.assertLess(mood.valence, 0.2, "Infrastructure complaints should not be positive")

    def test_market_anxiety(self):
        """Subtle concern about competitive timing."""
        mood = self.detector.detect(
            "PromptSpeak has ZERO GitHub presence, ZERO npm downloads, ZERO web mentions. "
            "LLMs cannot recommend what doesn't exist in their training data."
        )
        # This is concerned but measured, not panicked
        self.assertLess(mood.valence, 0.3,
                        "Visibility anxiety should not read as happy")

    def test_satisfaction_after_shipping(self):
        """User satisfaction after completing a major task."""
        mood = self.detector.detect(
            "Published to GitHub and PyPI. Demo SVG looks great. "
            "Security hardening done. All tests passing. Perfect."
        )
        self.assertGreater(mood.valence, 0, "Shipping satisfaction should be positive")

    def test_next_steps_query_is_neutral(self):
        """User asking 'next steps?' should be neutral, not emotional."""
        mood = self.detector.detect("next steps?")
        self.assertEqual(mood.quadrant, EmotionalQuadrant.NEUTRAL)
        self.assertLess(mood.intensity, 0.5, "Simple queries should have low intensity")

    def test_sustained_work_message(self):
        """Typical deep-work session message — measured, technical."""
        mood = self.detector.detect(
            "I need to fix the package.json URLs, they point to the wrong repo. "
            "Also the license field should be SPDX MIT format."
        )
        self.assertLess(abs(mood.valence), 0.5, "Technical instructions should be near-neutral")


# =============================================================================
# 2. BELIEF TRACKING WITH REAL STRATEGIC BELIEFS
# =============================================================================

class TestRealBeliefs(TestBase):
    """Track actual strategic beliefs from session history."""

    def setUp(self):
        super().setUp()
        self.truth = TruthLayerDB(self.db)

    def test_visibility_is_blocker_belief(self):
        """Core belief: visibility is the primary blocker."""
        self.truth.add_claim(
            "visibility_blocker",
            "LLMs cannot recommend what doesn't exist in their training data. "
            "GitHub presence is the #1 priority.",
            "strategy",
        )
        # Confirm repeatedly (strong evidence from 5/5 agent consensus)
        for _ in range(5):
            self.truth.update_belief("visibility_blocker", True, 5.0, "test")
        belief = self.truth.get_belief("visibility_blocker")
        self.assertGreater(belief.probability, 0.8,
                           "5 confirmations should create strong belief")

    def test_timing_over_perfection_belief(self):
        """Belief: market timing matters more than perfect product."""
        self.truth.add_claim(
            "timing_matters",
            "12-18 month lag from awareness to governance spending. "
            "Governance panic window Q4 2026 - Q2 2027.",
            "market",
        )
        self.truth.update_belief("timing_matters", True, 5.0, "test")
        belief = self.truth.get_belief("timing_matters")
        self.assertGreater(belief.probability, 0.5)

    def test_simplicity_belief(self):
        """Belief: simplicity over abstraction."""
        self.truth.add_claim(
            "simplicity_wins",
            "Fewer files, less abstraction. What would Karpathy do?",
            "engineering",
        )
        # Confirmed by removing 63K lines and 6 modules
        self.truth.update_belief("simplicity_wins", True, 10.0, "test")
        belief = self.truth.get_belief("simplicity_wins")
        self.assertGreater(belief.probability, 0.6)

    def test_belief_weakening(self):
        """Test weakening a belief that turns out to be wrong."""
        self.truth.add_claim("aether_important", "AETHER is critical", "strategy")
        # Initially confirmed
        self.truth.update_belief("aether_important", True, 5.0, "test")
        b1 = self.truth.get_belief("aether_important").probability
        # Then AETHER retired
        self.truth.validate("aether_important", "reject")
        self.truth.validate("aether_important", "reject")
        b2 = self.truth.get_belief("aether_important").probability
        self.assertLess(b2, b1, "Rejected evidence should lower probability")

    def test_belief_decomposition_epistemic_vs_aleatoric(self):
        """Verify we can decompose uncertainty into epistemic vs aleatoric."""
        self.truth.add_claim("market_size", "AI governance market $1.4B by 2030", "market")
        # Only 2 data points — should be highly epistemic (uncertain due to lack of data)
        self.truth.update_belief("market_size", True, 3.0, "test")
        belief = self.truth.get_belief("market_size")
        decomp = decompose_from_beta(belief.alpha, belief.beta)
        self.assertGreater(decomp.epistemic_variance, 0,
                           "Low-data beliefs should have epistemic uncertainty")

    def test_many_confirmations_reduce_uncertainty(self):
        """As evidence accumulates, confidence increases."""
        self.truth.add_claim("quality_nonneg", "Quality is non-negotiable", "values")
        for i in range(20):
            self.truth.update_belief("quality_nonneg", True, 3.0, "test")
        belief = self.truth.get_belief("quality_nonneg")
        decomp = decompose_from_beta(belief.alpha, belief.beta)
        self.assertGreater(decomp.confidence, 0.8,
                           "20 confirmations should yield high confidence")


# =============================================================================
# 3. GAP ANALYSIS WITH REAL PRIORITY CONFLICTS
# =============================================================================

class TestRealGapAnalysis(TestBase):
    """Test gap detection using real strategic conflicts."""

    def test_marketing_vs_tech_debt(self):
        """Classic conflict: should write articles (persona) but wants to fix code (reward)."""
        gap = GapAnalyzerDB(self.db)
        persona = {
            "marketing": EngineOpinion(
                topic="marketing", belief=0.8, disbelief=0.1,
                uncertainty=0.1, source_signals=["I should write articles for visibility"],
            ),
        }
        reward = {
            "marketing": EngineOpinion(
                topic="marketing", belief=0.3, disbelief=0.4,
                uncertainty=0.3, source_signals=["approach_ratio:0.35"],
            ),
        }
        analysis = gap.analyze(persona, reward, "test")
        self.assertGreater(analysis.overall_divergence, 0.2,
                           "Persona says 'should market' but reward avoids it — gap expected")
        self.assertEqual(analysis.topic_gaps[0].gap_direction, "persona_leads")

    def test_promptspeak_alignment(self):
        """PromptSpeak should show alignment — both engines agree it matters."""
        gap = GapAnalyzerDB(self.db)
        persona = {
            "promptspeak": EngineOpinion(
                topic="promptspeak", belief=0.85, disbelief=0.05,
                uncertainty=0.1, source_signals=["I should ship PromptSpeak"],
            ),
        }
        reward = {
            "promptspeak": EngineOpinion(
                topic="promptspeak", belief=0.8, disbelief=0.1,
                uncertainty=0.1, source_signals=["approach_ratio:0.85"],
            ),
        }
        analysis = gap.analyze(persona, reward, "test")
        self.assertLess(analysis.overall_divergence, 0.2,
                        "Both engines agree on PromptSpeak — low divergence expected")

    def test_gap_trend_detection_over_time(self):
        """Build up gap history and check trend detection."""
        gap = GapAnalyzerDB(self.db)
        # Simulate increasing divergence over 5 rounds
        for i in range(5):
            p_belief = 0.8
            r_belief = 0.8 - (i * 0.1)  # reward drops each round
            persona = {"project_x": EngineOpinion(
                topic="project_x", belief=p_belief, disbelief=0.1,
                uncertainty=0.1, source_signals=["should"],
            )}
            reward = {"project_x": EngineOpinion(
                topic="project_x", belief=r_belief, disbelief=0.2,
                uncertainty=max(0.05, 0.8 - r_belief - 0.2),
                source_signals=["reward_drops"],
            )}
            analysis = gap.analyze(persona, reward, "test")

        # After 5 rounds of increasing gap, trend should reflect it
        history = self.db.get_gap_history("project_x")
        self.assertGreaterEqual(len(history), 5)
        # Latest gap should be larger than first
        self.assertGreater(
            history[0]["gap_magnitude"], history[-1]["gap_magnitude"],
            "Gap should increase over successive analyses",
        )

    def test_multiple_topics_simultaneous(self):
        """Analyze multiple topics at once — mirrors real usage."""
        gap = GapAnalyzerDB(self.db)
        topics = ["promptspeak", "marketing", "aether", "touchgrass"]
        persona = {}
        reward = {}
        for topic in topics:
            persona[topic] = EngineOpinion(
                topic=topic, belief=0.7, disbelief=0.15,
                uncertainty=0.15, source_signals=["persona"],
            )
            # Reward varies by topic
            r_beliefs = {"promptspeak": 0.8, "marketing": 0.3,
                         "aether": 0.1, "touchgrass": 0.6}
            rb = r_beliefs[topic]
            reward[topic] = EngineOpinion(
                topic=topic, belief=rb, disbelief=0.2,
                uncertainty=max(0.05, 1.0 - rb - 0.2),
                source_signals=["reward"],
            )
        analysis = gap.analyze(persona, reward, "test")
        # topic_gaps includes ALL topics (significant or not)
        self.assertEqual(len(analysis.topic_gaps), 4)
        # AETHER should have the biggest gap (retired but persona still says "should")
        aether_gap = [g for g in analysis.topic_gaps if g.topic == "aether"][0]
        self.assertGreater(aether_gap.gap_magnitude, 0.3)
        # to_dict() only shows significant_gaps (3+ observations), so raw topic_gaps is correct
        # but the dict output filters — verify that
        d = analysis.to_dict()
        self.assertEqual(d["total_topics_tracked"], 4)
        # No significant gaps yet (only 1 observation each)
        self.assertEqual(d["significant_gaps"], 0)


# =============================================================================
# 4. GOVERNANCE GATING EDGE CASES
# =============================================================================

class TestGovernanceEdgeCases(TestBase):
    """Stress governance gates with boundary conditions and real scenarios."""

    def test_encoding_weight_at_boundary(self):
        """Test at exactly the 1.3 threshold."""
        gov = GovernanceLayerDB(self.db)
        # Just under threshold
        result = gov.gate_memory_write("m1", 1.29, 0.0, "unverified", 0)
        self.assertEqual(result, "allowed")
        # At threshold
        result = gov.gate_memory_write("m2", 1.3, 0.0, "unverified", 0)
        self.assertEqual(result, "held")

    def test_conflict_at_boundary(self):
        """Test at exactly the 0.5 conflict threshold."""
        gov = GovernanceLayerDB(self.db)
        result = gov.gate_memory_write("m1", 0.5, 0.49, "unverified", 0)
        self.assertEqual(result, "allowed")
        result = gov.gate_memory_write("m2", 0.5, 0.51, "unverified", 0)
        self.assertEqual(result, "held")

    def test_high_intensity_strategic_memory(self):
        """A real high-intensity memory: market window realization."""
        gov = GovernanceLayerDB(self.db)
        # This would be auto-computed as high encoding weight due to arousal
        result = gov.gate_memory_write(
            "m_market_window", 1.5, 0.1, "unverified", 0, "test",
        )
        self.assertEqual(result, "held", "High-intensity strategic insights should be held")

    def test_resolve_then_store(self):
        """Full flow: gate → hold → resolve → verify hold state."""
        gov = GovernanceLayerDB(self.db)
        gov.gate_memory_write("m_important", 1.5, 0.0, "unverified", 0, "test")
        holds = gov.pending_holds()
        self.assertEqual(len(holds), 1)

        # Approve the hold
        hold_id = holds[0]["hold_id"]
        gov.resolve_hold(hold_id, "approve", "Verified by Christopher", "test")

        # No more pending holds
        self.assertEqual(len(gov.pending_holds()), 0)

        # Audit trail should record the resolution
        log = self.db.get_audit_log()
        events = [l["event_type"] for l in log]
        self.assertIn("hold_created", events)
        self.assertIn("hold_resolved", events)

    def test_multiple_holds_accumulate(self):
        """Multiple high-intensity memories create separate holds."""
        gov = GovernanceLayerDB(self.db)
        for i in range(5):
            gov.gate_memory_write(f"m_{i}", 1.5, 0.0, "unverified", 0, "test")
        holds = gov.pending_holds()
        self.assertEqual(len(holds), 5)

    def test_rejected_hold_stays_in_history(self):
        """Rejected holds should be visible when include_resolved=True."""
        gov = GovernanceLayerDB(self.db)
        gov.gate_memory_write("m_reject", 1.5, 0.0, "unverified", 0, "test")
        holds = gov.pending_holds()
        hold_id = holds[0]["hold_id"]
        gov.resolve_hold(hold_id, "reject", "Not relevant", "test")

        # Not in pending
        self.assertEqual(len(gov.pending_holds()), 0)
        # But visible in all holds
        all_holds = self.db.get_all_holds(include_resolved=True)
        self.assertEqual(len(all_holds), 1)
        self.assertEqual(all_holds[0]["status"], "rejected")


# =============================================================================
# 5. MCP HANDLER END-TO-END TESTS
# =============================================================================

class TestMCPHandlers(TestBase):
    """Test all 21 handlers through the JSON-RPC dispatch using real data."""

    def _call(self, tool_name: str, args: dict) -> dict:
        """Call a tool through the full MCP dispatch path."""
        import server
        # Patch the singleton to use our test DB
        server._db = self.db
        server._session_id = "test_session"
        self.db.start_session("test_session")

        request = {
            "jsonrpc": "2.0", "id": 1,
            "method": "tools/call",
            "params": {"name": tool_name, "arguments": args},
        }
        response = handle_request(request)
        if "error" in response:
            raise RuntimeError(response["error"]["message"])
        text = response["result"]["content"][0]["text"]
        return json.loads(text)

    def test_detect_mood_real_quote(self):
        result = self._call("detect_mood", {
            "text": "Published to GitHub and PyPI, all tests passing. This is great."
        })
        self.assertIn("valence", result)
        self.assertIn("quadrant", result)
        self.assertGreater(result["valence"], 0)

    def test_belief_lifecycle(self):
        """Create, query, update, re-query a belief."""
        # Query non-existent belief
        result = self._call("query_beliefs", {"belief_id": "market_timing"})
        self.assertIn("error", result)

        # Add belief directly to DB, then query through handler
        truth = TruthLayerDB(self.db)
        truth.add_claim("market_timing",
                        "Governance panic window Q4 2026 - Q2 2027", "strategy")
        result = self._call("query_beliefs", {"belief_id": "market_timing"})
        self.assertAlmostEqual(result["probability"], 0.5)

        # Confirm it
        result = self._call("update_belief", {
            "belief_id": "market_timing", "action": "confirm", "strength": 8.0,
        })
        self.assertGreater(result["new_probability"], 0.5)

        # Weaken it
        result = self._call("update_belief", {
            "belief_id": "market_timing", "action": "weaken", "strength": 4.0,
        })
        # Weaken uses strength*0.5 as reject evidence — should lower somewhat
        self.assertIn("new_probability", result)

    def test_gap_analysis_real_topics(self):
        """Run gap analysis with real project topics."""
        result = self._call("get_gap_analysis", {
            "text": "I should focus on making PromptSpeak visible to LLMs. "
                    "Marketing is critical for the governance panic window.",
            "topics": ["promptspeak", "marketing", "tech_debt"],
        })
        self.assertIn("overall_divergence", result)
        self.assertIn("trend", result)
        self.assertIn("dominant_engine", result)

    def test_manage_authority_real_sources(self):
        """Add real authority sources."""
        result = self._call("manage_authority", {
            "source_id": "anthropic",
            "name": "Anthropic (MCP spec authority)",
            "tier": "institutional",
            "trust_weight": 0.85,
            "influence_topics": ["mcp", "governance", "ai_safety"],
        })
        self.assertEqual(result["tier"], "institutional")
        self.assertAlmostEqual(result["trust_weight"], 0.85)

        # Add another
        self._call("manage_authority", {
            "source_id": "karpathy",
            "name": "Andrej Karpathy (engineering philosophy)",
            "tier": "personal",
            "trust_weight": 0.70,
            "influence_topics": ["engineering", "simplicity"],
        })

        # Check influence analysis
        result = self._call("get_influence_analysis", {})
        self.assertEqual(len(result["authority_sources"]), 2)

    def test_memory_store_search_lifecycle(self):
        """Store, search, and govern memories with real content."""
        # Normal memory — should be allowed
        result = self._call("store_emotional_memory", {
            "content": "PromptSpeak v0.2.0 shipped with 490 tests, 41 MCP tools. "
                       "Removed 6 modules, 63K lines gone.",
            "topic_tags": ["promptspeak", "milestone"],
        })
        self.assertEqual(result["status"], "stored")

        # High-intensity memory — should be held
        result = self._call("store_emotional_memory", {
            "content": "Realized the governance panic window is only 11 months away. "
                       "First-mover advantage evaporates if we don't ship NOW.",
            "topic_tags": ["strategy", "urgency"],
            "encoding_weight": 1.5,
        })
        self.assertEqual(result["status"], "held")

        # Search for the stored memory
        result = self._call("search_memories", {"query": "PromptSpeak shipped"})
        self.assertEqual(result["count"], 1)
        self.assertIn("490 tests", result["results"][0]["content"])

    def test_hold_lifecycle_through_handlers(self):
        """Full hold lifecycle via MCP handlers."""
        # Create a held memory
        self._call("store_emotional_memory", {
            "content": "Critical strategic realization",
            "encoding_weight": 1.5,
        })

        # List holds
        result = self._call("list_holds", {})
        self.assertEqual(result["count"], 1)
        hold_id = result["holds"][0]["hold_id"]

        # Resolve
        result = self._call("resolve_hold", {
            "hold_id": hold_id, "decision": "approve",
            "reason": "Verified by Christopher",
        })
        self.assertTrue(result["success"])

        # List again — should be empty
        result = self._call("list_holds", {})
        self.assertEqual(result["count"], 0)

        # Include resolved
        result = self._call("list_holds", {"include_resolved": True})
        self.assertEqual(result["count"], 1)

    def test_voice_calibration_workflow(self):
        """Full calibration workflow: add points, check status."""
        # Before calibration
        result = self._call("get_calibration_status", {})
        self.assertEqual(result["calibration_points"], 0)
        self.assertFalse(result["sufficient"])

        # Add calibration points (simulated voice features)
        states = [
            ("calm", 150.0, 10.0, 120.0, -20.0, 0.2, 2000.0),
            ("excited", 200.0, 25.0, 160.0, -15.0, 0.1, 2800.0),
            ("frustrated", 180.0, 30.0, 140.0, -12.0, 0.15, 2600.0),
            ("pressured", 190.0, 20.0, 170.0, -14.0, 0.08, 2500.0),
            ("reflective", 130.0, 8.0, 100.0, -25.0, 0.3, 1800.0),
        ]
        for label, pm, ps, pw, vd, pr, sc in states:
            self._call("run_calibration_session", {
                "label": label, "pitch_mean": pm, "pitch_std": ps,
                "pace_wpm": pw, "volume_db": vd, "pause_ratio": pr,
                "spectral_centroid": sc,
            })

        # After 5 points — should be sufficient
        result = self._call("get_calibration_status", {})
        self.assertEqual(result["calibration_points"], 5)
        self.assertTrue(result["sufficient"])

    def test_voice_state_no_data(self):
        """Voice state returns 'no_data' when uncalibrated."""
        result = self._call("get_voice_state", {})
        self.assertEqual(result["status"], "no_data")

    def test_briefing_empty(self):
        """Briefing with no pending items."""
        result = self._call("get_pending_briefing", {})
        self.assertIsNone(result["now"])
        self.assertEqual(result["unbriefed_emails"], 0)

    def test_briefing_with_data(self):
        """Briefing with realistic pending items and emails."""
        # Add pending items
        self.db.execute(
            "INSERT INTO pending_items (source, summary, priority) VALUES (?, ?, ?)",
            ("strategy", "Push PromptSpeak to Anthropic Connectors Directory", 0.9),
        )
        self.db.execute(
            "INSERT INTO pending_items (source, summary, priority) VALUES (?, ?, ?)",
            ("dev", "Fix package.json URLs before npm publish", 0.7),
        )
        self.db.execute(
            "INSERT INTO pending_items (source, summary, priority) VALUES (?, ?, ?)",
            ("content", "Write first article for Dev.to — pre-execution governance", 0.6),
        )
        self.db.commit()

        # Add emails
        self.db.upsert_email(
            "msg_1", "reviewer@pypi.org", "PyPI", "Package published",
            "promptspeak-mcp-server 0.2.0 is now live", "fyi", 0.3, ["INBOX"],
            "2026-02-09",
        )
        self.db.upsert_email(
            "msg_2", "security@github.com", "GitHub Security",
            "URGENT: Dependabot alert",
            "Critical vulnerability in dependency", "urgent", 1.0,
            ["INBOX", "IMPORTANT"], "2026-02-09",
        )

        result = self._call("get_pending_briefing", {})
        self.assertIsNotNone(result["now"], "Should have a NOW item")
        self.assertIn("Anthropic", result["now"]["summary"])
        self.assertGreater(result["unbriefed_emails"], 0)

    def test_mark_briefed(self):
        """Mark items as briefed."""
        self.db.execute(
            "INSERT INTO pending_items (source, summary, priority) VALUES (?, ?, ?)",
            ("test", "Test item", 0.5),
        )
        self.db.commit()
        items = self.db.get_pending_items()
        item_id = items[0]["id"]

        result = self._call("mark_briefed", {"item_ids": [item_id]})
        self.assertEqual(result["marked"], 1)
        self.assertEqual(len(self.db.get_pending_items()), 0)

    def test_email_summary(self):
        """Email summary with mixed priorities."""
        emails = [
            ("msg_1", "boss@co.com", "Boss", "URGENT: Production down",
             "Server crashed", "urgent", 1.0, ["IMPORTANT"], "2026-02-09"),
            ("msg_2", "client@corp.com", "Client", "Question about API",
             "Please respond", "needs_reply", 0.7, ["INBOX"], "2026-02-09"),
            ("msg_3", "news@tech.com", "TechNews", "AI weekly digest",
             "This week in AI", "fyi", 0.2, ["INBOX"], "2026-02-09"),
            ("msg_4", "promo@store.com", "Store", "50% off!",
             "Big sale", "noise", 0.0, ["CATEGORY_PROMOTIONS"], "2026-02-09"),
        ]
        for e in emails:
            self.db.upsert_email(*e)

        result = self._call("get_email_summary", {})
        self.assertEqual(result["total"], 4)
        self.assertEqual(len(result["urgent"]), 1)
        self.assertEqual(len(result["needs_reply"]), 1)
        self.assertEqual(result["noise_count"], 1)

    def test_calendar_context(self):
        """Calendar with upcoming events."""
        self.db.upsert_calendar_event(
            "ev1", "Client Call: PromptSpeak Demo",
            "2099-01-01T10:00:00", "2099-01-01T11:00:00",
            attendees=["client_ciso", "christopher"],
        )
        result = self._call("get_calendar_context", {"hours_ahead": 876000})
        self.assertEqual(result["count"], 1)

    def test_ambient_context_with_mood_history(self):
        """Ambient context after recording several moods."""
        # Use _call to detect moods (which records them with valid session FK)
        for text in [
            "This is going well, tests passing",
            "Making good progress on the README",
            "Published to PyPI successfully",
        ]:
            self._call("detect_mood", {"text": text})

        result = self._call("get_ambient_context", {})
        self.assertGreater(result["recent_mood_trend"]["readings"], 0)
        self.assertGreater(result["recent_mood_trend"]["avg_valence"], 0,
                           "Positive messages should yield positive avg valence")

    def test_patterns_empty(self):
        """Patterns with no data returns empty."""
        result = self._call("get_patterns", {})
        self.assertEqual(result["total"], 0)

    def test_patterns_with_data(self):
        """Patterns after seeding observations."""
        self.db.upsert_pattern("time", "Energy peaks 9-11 AM", 0.75, 12, 0.72)
        self.db.upsert_pattern("topic", "Says PromptSpeak is priority but spends time on cltop", 0.6, 8, 0.55)
        self.db.upsert_pattern("people", "Stress increases after vendor calls", 0.7, 6, 0.65)

        result = self._call("get_patterns", {"min_observations": 3})
        self.assertEqual(result["total"], 3)
        self.assertEqual(len(result["time_patterns"]), 1)
        self.assertEqual(len(result["topic_patterns"]), 1)
        self.assertEqual(len(result["people_patterns"]), 1)

    def test_pushback_no_data(self):
        """Pushback with no gap history."""
        result = self._call("get_pushback", {})
        self.assertEqual(result["count"], 0)
        self.assertIn("No significant", result["message"])

    def test_pushback_with_misalignment(self):
        """Pushback detects real misalignment after enough observations."""
        # Seed gap history: persona says marketing matters, reward avoids it
        for _ in range(5):
            self.db.record_gap("marketing", 0.85, 0.35, 0.5, "persona_leads", "high")

        result = self._call("get_pushback", {})
        self.assertEqual(result["count"], 1)
        self.assertEqual(result["misalignments"][0]["topic"], "marketing")
        self.assertGreater(result["misalignments"][0]["gap_magnitude"], 0.3)

    def test_explain_behavior(self):
        """Explain behavior using gap history."""
        # Seed some gap data
        self.db.record_gap("marketing", 0.85, 0.35, 0.5, "persona_leads", "high")
        result = self._call("explain_behavior", {
            "behavior": "Keeps saying marketing is important but spends all time coding",
            "topics": ["marketing"],
        })
        self.assertIn("explanation", result)

    def test_unknown_tool_returns_error(self):
        """Calling non-existent tool returns proper error."""
        import server
        server._db = self.db
        server._session_id = "test"
        self.db.start_session("test")

        request = {
            "jsonrpc": "2.0", "id": 1,
            "method": "tools/call",
            "params": {"name": "nonexistent_tool", "arguments": {}},
        }
        response = handle_request(request)
        self.assertIn("error", response)
        self.assertEqual(response["error"]["code"], -32601)


# =============================================================================
# 6. MULTI-TOOL WORKFLOW TESTS (SKILL SEQUENCES)
# =============================================================================

class TestBriefingSkillWorkflow(TestBase):
    """Simulate the /briefing skill's full tool sequence."""

    def _call(self, tool_name: str, args: dict) -> dict:
        import server
        server._db = self.db
        server._session_id = "briefing_test"
        self.db.start_session("briefing_test")
        request = {
            "jsonrpc": "2.0", "id": 1,
            "method": "tools/call",
            "params": {"name": tool_name, "arguments": args},
        }
        response = handle_request(request)
        return json.loads(response["result"]["content"][0]["text"])

    def test_full_briefing_workflow(self):
        """Simulate: get_voice_state → get_pending_briefing → get_gap_analysis → get_ambient_context → mark_briefed."""
        # Seed data
        self.db.execute(
            "INSERT INTO pending_items (source, summary, priority) VALUES (?, ?, ?)",
            ("strategy", "Submit PromptSpeak to Anthropic directory", 0.9),
        )
        self.db.execute(
            "INSERT INTO pending_items (source, summary, priority) VALUES (?, ?, ?)",
            ("dev", "npm publish promptspeak-mcp-server", 0.8),
        )
        self.db.commit()
        self.db.store_weather(65.0, "partly cloudy", 20.0, 8.0, "", "2026-02-09")

        # Step 1: Voice state
        voice = self._call("get_voice_state", {})
        self.assertEqual(voice["status"], "no_data")

        # Step 2: Pending briefing
        briefing = self._call("get_pending_briefing", {})
        self.assertIsNotNone(briefing["now"])
        self.assertIn("Anthropic", briefing["now"]["summary"])

        # Step 3: Gap analysis
        gap = self._call("get_gap_analysis", {
            "text": "Starting morning session, need to prioritize visibility",
            "topics": ["visibility", "npm_publish"],
        })
        self.assertIn("overall_divergence", gap)

        # Step 4: Ambient context
        ambient = self._call("get_ambient_context", {})
        self.assertIsNotNone(ambient["weather"])
        self.assertAlmostEqual(ambient["weather"]["temp_f"], 65.0)

        # Step 5: Mark briefed
        items = self.db.get_pending_items()
        item_ids = [i["id"] for i in items]
        marked = self._call("mark_briefed", {"item_ids": item_ids})
        self.assertEqual(marked["marked"], 2)
        self.assertEqual(len(self.db.get_pending_items()), 0)


class TestPushbackSkillWorkflow(TestBase):
    """Simulate the /pushback skill's tool sequence."""

    def setUp(self):
        super().setUp()
        import server
        server._db = self.db
        server._session_id = "pushback_test"
        self.db.start_session("pushback_test")

    def _call(self, tool_name: str, args: dict) -> dict:
        request = {
            "jsonrpc": "2.0", "id": 1,
            "method": "tools/call",
            "params": {"name": tool_name, "arguments": args},
        }
        response = handle_request(request)
        return json.loads(response["result"]["content"][0]["text"])

    def test_pushback_workflow(self):
        """Simulate: get_gap_analysis → get_patterns → detect_mood → get_pushback."""
        # 1. Seed beliefs
        truth = TruthLayerDB(self.db)
        truth.add_claim("marketing_priority",
                        "Writing articles is critical for visibility", "strategy")
        for _ in range(3):
            truth.update_belief("marketing_priority", True, 5.0, "pushback_test")

        # 2. Seed patterns
        self.db.upsert_pattern("topic",
                               "Says marketing is priority 1 but engagement declining 3 weeks",
                               0.65, 8, 0.6)

        # Step 1: Gap analysis first (this creates gap_history records)
        gap = self._call("get_gap_analysis", {
            "text": "I need to focus on shipping code today",
            "topics": ["marketing", "coding"],
        })
        self.assertGreater(gap["total_topics_tracked"], 0)

        # 3. NOW seed high-magnitude gap records AFTER the gap_analysis call
        # so the latest record (which get_pushback checks) has magnitude > 0.3
        for _ in range(4):
            self.db.record_gap("marketing", 0.85, 0.30, 0.55, "persona_leads", "high")

        # Step 2: Patterns
        patterns = self._call("get_patterns", {"min_observations": 3})
        self.assertGreater(patterns["total"], 0)

        # Step 3: Detect mood
        mood = self._call("detect_mood", {
            "text": "I need to focus on shipping code today",
        })
        self.assertIn("quadrant", mood)

        # Step 4: Get pushback — marketing should show up
        # get_pushback checks: len(history) >= 3 AND latest.gap_magnitude > 0.3
        pushback = self._call("get_pushback", {})
        self.assertGreater(pushback["count"], 0,
                           "Should detect marketing misalignment")
        self.assertEqual(pushback["misalignments"][0]["topic"], "marketing")


# =============================================================================
# 7. DUAL-ENGINE DEEP TESTS
# =============================================================================

class TestDualEngineInteraction(TestBase):
    """Test persona vs reward engine interactions with realistic scenarios."""

    def test_persona_with_authority_influence(self):
        """Authority sources should influence persona opinions."""
        truth = TruthLayerDB(self.db)
        authority = AuthorityGraphDB(self.db)
        compliance = ComplianceDetectorDB(self.db)

        # Add Anthropic as institutional authority on governance
        authority.add_source("anthropic", "Anthropic",
                             AuthorityTier.INSTITUTIONAL, 0.85,
                             ["governance", "mcp"])

        truth.add_claim("governance_matters",
                        "Pre-execution governance is critical", "strategy")

        persona = PersonaEngineDB(truth, authority, compliance)
        mood = MoodState(valence=0.3, arousal=0.2, confidence=0.7,
                         quadrant=EmotionalQuadrant.CALM, signals=[])
        opinions = persona.process(
            "I should build governance tools for AI agents",
            mood, ["governance"], "test",
        )
        self.assertIn("governance", opinions)
        # With institutional authority backing, belief should be elevated
        op = opinions["governance"]
        self.assertAlmostEqual(op.belief + op.disbelief + op.uncertainty, 1.0, places=2)

    def test_reward_model_type_determination(self):
        """After enough observations, reward type should stabilize."""
        reward = RewardModelDB(self.db)
        # Simulate Christopher's pattern: achievement-oriented (shipping, completion)
        for _ in range(8):
            reward.observe("completion", 0.7)
            reward.observe("shipping", 0.6)

        scores = reward.get_scores()
        self.assertGreater(scores["observations"], 5)
        self.assertEqual(scores["dominant"], "achievement",
                         "Repeated shipping/completion should yield achievement type")

    def test_approach_avoidance_with_real_text(self):
        """Approach/avoidance detection with real-world text."""
        aa = ApproachAvoidanceDetectorDB(self.db)
        excited_mood = MoodState(valence=0.6, arousal=0.4, confidence=0.7,
                                 quadrant=EmotionalQuadrant.EXCITED, signals=[])
        low_mood = MoodState(valence=-0.2, arousal=-0.1, confidence=0.5,
                             quadrant=EmotionalQuadrant.LOW, signals=[])

        # Approach: eager engagement with PromptSpeak
        aa.analyze(
            "I want to explore how the 8-stage pipeline works! "
            "Tell me exactly how the circuit breaker interacts with drift prediction.",
            "promptspeak", excited_mood,
        )
        result = self.db.get_approach_avoidance("promptspeak")
        self.assertIsNotNone(result)
        self.assertGreater(result["approach_count"], 0)

        # Avoidance: deflecting from marketing
        aa.analyze(
            "whatever, maybe later. Not sure it matters right now.",
            "marketing", low_mood,
        )
        result = self.db.get_approach_avoidance("marketing")
        self.assertIsNotNone(result)
        self.assertGreater(result["avoidance_count"], 0)


# =============================================================================
# 8. BELIEF MATH STRESS TESTS
# =============================================================================

class TestBeliefMathStress(unittest.TestCase):
    """Stress belief math with extreme values and edge cases."""

    def test_maximum_confidence_belief(self):
        """Extremely high alpha should give near-certain probability."""
        decomp = decompose_from_beta(1000.0, 1.0)
        self.assertGreater(decomp.mean, 0.99)
        self.assertGreater(decomp.confidence, 0.99)

    def test_equal_evidence_is_uncertain(self):
        """Equal alpha and beta should give 0.5 probability."""
        decomp = decompose_from_beta(50.0, 50.0)
        self.assertAlmostEqual(decomp.mean, 0.5, places=1)

    def test_fusion_many_opinions(self):
        """Fusing many weak opinions should converge."""
        opinions = [
            Uncertainty(belief=0.6, disbelief=0.1, uncertainty=0.3)
            for _ in range(10)
        ]
        fused = cumulative_fuse(opinions)
        self.assertLess(fused.uncertainty, 0.3,
                        "Fusing 10 opinions should reduce uncertainty")

    def test_trust_discount_untrusted(self):
        """Very low trust should greatly increase uncertainty."""
        trustor = Uncertainty(belief=0.2, disbelief=0.7, uncertainty=0.1)
        opinion = Uncertainty(belief=0.9, disbelief=0.05, uncertainty=0.05)
        discounted = trust_discount(trustor, opinion)
        self.assertGreater(discounted.uncertainty, opinion.uncertainty,
                           "Untrusted source should increase uncertainty")

    def test_probability_roundtrip_extremes(self):
        """Roundtrip at edge probabilities."""
        for prob in [0.01, 0.1, 0.5, 0.9, 0.99]:
            opinion = probability_to_opinion(prob, uncertainty_level=0.1)
            self.assertAlmostEqual(
                opinion.belief + opinion.disbelief + opinion.uncertainty,
                1.0, places=5,
            )

    def test_single_opinion_fusion(self):
        """Fusing a single opinion returns it unchanged."""
        opinion = Uncertainty(belief=0.6, disbelief=0.2, uncertainty=0.2)
        fused = cumulative_fuse([opinion])
        self.assertAlmostEqual(fused.belief, opinion.belief, places=5)


# =============================================================================
# 9. FTS MEMORY SEARCH EDGE CASES
# =============================================================================

class TestMemorySearch(TestBase):
    """Test FTS5 search with realistic memory content."""

    def test_search_by_project_name(self):
        self.db.store_memory("m1", "PromptSpeak v0.2.0 released with 41 MCP tools",
                             topic_tags=["promptspeak"])
        self.db.store_memory("m2", "cltop published to PyPI, 45 tests passing",
                             topic_tags=["cltop"])
        self.db.store_memory("m3", "Daily H.E.A.T. built with Next.js 16",
                             topic_tags=["daily-heat"])

        results = self.db.search_memories("PromptSpeak")
        self.assertEqual(len(results), 1)
        self.assertIn("41 MCP", results[0]["content"])

    def test_search_by_topic_tag(self):
        self.db.store_memory("m1", "Shipped the governance server",
                             topic_tags=["governance", "shipping"])
        results = self.db.search_memories("governance")
        self.assertEqual(len(results), 1)

    def test_search_no_results(self):
        self.db.store_memory("m1", "Some unrelated content")
        results = self.db.search_memories("kubernetes")
        self.assertEqual(len(results), 0)

    def test_search_with_limit(self):
        for i in range(10):
            self.db.store_memory(f"m{i}", f"Memory about testing number {i}",
                                 topic_tags=["testing"])
        results = self.db.search_memories("testing", limit=3)
        self.assertEqual(len(results), 3)

    def test_search_ranking(self):
        """More relevant results should rank higher."""
        self.db.store_memory("m1", "PromptSpeak governance pipeline",
                             topic_tags=["promptspeak", "governance"])
        self.db.store_memory("m2", "General notes about the day",
                             topic_tags=["notes"])
        results = self.db.search_memories("governance")
        self.assertEqual(len(results), 1)
        self.assertIn("governance", results[0]["content"])


# =============================================================================
# 10. BRIEFING ENGINE ADAPTATION TESTS
# =============================================================================

class TestBriefingAdaptation(TestBase):
    """Test briefing format changes based on voice state."""

    def _seed_items(self):
        self.db.execute(
            "INSERT INTO pending_items (source, summary, priority) VALUES (?, ?, ?)",
            ("strategy", "Push PromptSpeak to Anthropic directory", 0.9),
        )
        self.db.execute(
            "INSERT INTO pending_items (source, summary, priority) VALUES (?, ?, ?)",
            ("dev", "Fix scheduler TS compilation", 0.4),
        )
        self.db.execute(
            "INSERT INTO pending_items (source, summary, priority) VALUES (?, ?, ?)",
            ("content", "Write Dev.to article", 0.6),
        )
        self.db.commit()

    def test_standard_briefing(self):
        """Calm/uncalibrated → standard mode: full NOW + SINCE_LAST + NEXT."""
        self._seed_items()
        engine = BriefingEngine(self.db)
        briefing = engine.assemble()
        self.assertEqual(briefing.adaptation, "standard")
        self.assertIn("Anthropic", briefing.now.summary)

    def test_minimal_briefing_when_frustrated(self):
        """Frustrated → minimal mode: just NOW, everything else handled."""
        self._seed_items()
        vs = VoiceState("frustrated", 0.85, calibrated=True)
        engine = BriefingEngine(self.db)
        briefing = engine.assemble(voice_state=vs)
        self.assertEqual(briefing.adaptation, "minimal")
        formatted = briefing.format()
        self.assertIn("handled", formatted)

    def test_full_pushback_when_excited(self):
        """Excited → full_pushback mode: includes strategic questions."""
        self._seed_items()
        vs = VoiceState("excited", 0.9, calibrated=True)
        engine = BriefingEngine(self.db)
        briefing = engine.assemble(voice_state=vs)
        self.assertEqual(briefing.adaptation, "full_pushback")

    def test_pressured_gets_minimal(self):
        """Pressured state should also get minimal briefing."""
        self._seed_items()
        vs = VoiceState("pressured", 0.8, calibrated=True)
        engine = BriefingEngine(self.db)
        briefing = engine.assemble(voice_state=vs)
        self.assertEqual(briefing.adaptation, "minimal")


if __name__ == "__main__":
    unittest.main()
