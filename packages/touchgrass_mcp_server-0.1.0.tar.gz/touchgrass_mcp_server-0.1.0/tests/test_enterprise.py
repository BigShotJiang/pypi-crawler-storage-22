"""
Enterprise validation suite for touchgrass.

Covers: MCP protocol compliance (subprocess), numerical stability, boundary
conditions, data integrity, concurrent access, error handling, governance
edge cases, belief math invariants, full integration pipelines.

Run: python -m pytest tests/test_enterprise.py -v
"""
from __future__ import annotations

import json
import math
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from touchgrass_lib.init_db import init_db, is_initialized, SCHEMA
from touchgrass_lib.db import TouchgrassDB
from touchgrass_lib.engines.models import (
    MoodState, EmotionalQuadrant, AuthorityTier, EngineOpinion,
    ComplianceProfile, RewardProfile, RewardType, EncodingWeight,
    TopicGap, GapAnalysis, HoldRequest, EmotionalMemory,
    ApproachAvoidanceData, IntrospectiveNarration,
)
from touchgrass_lib.engines.engines import (
    MoodDetector, compute_encoding_weight, classify_severity,
)
from touchgrass_lib.engines.engines_db import (
    AuthorityGraphDB, ComplianceDetectorDB, RewardModelDB,
    ApproachAvoidanceDetectorDB, GapAnalyzerDB, TruthLayerDB,
    PersonaEngineDB, GovernanceLayerDB,
)
from touchgrass_lib.engines.belief import (
    Uncertainty, cumulative_fuse, averaging_fuse, trust_discount,
    trust_chain, probability_to_opinion, opinion_to_probability,
    blend_uncertainty, decompose_from_beta, decompose_from_opinion,
    DecomposedUncertainty, Belief, BayesianNetwork, TruthLayer,
)
from touchgrass_lib.voice.analyzer import VoiceFeatures
from touchgrass_lib.voice.calibrator import VoiceCalibrator
from touchgrass_lib.voice.state import VoiceState, VoiceStateDetector
from touchgrass_lib.briefing.engine import BriefingEngine, Briefing
from touchgrass_lib.ingest.email import classify_priority
from touchgrass_lib.ingest.scheduler import should_ingest


class TestBase(unittest.TestCase):
    """Base with temp DB setup/teardown."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmp, "test.db")
        init_db(self.db_path)
        self.db = TouchgrassDB(self.db_path)

    def tearDown(self):
        self.db.close()
        shutil.rmtree(self.tmp)


# =============================================================================
# MCP PROTOCOL COMPLIANCE (subprocess tests)
# =============================================================================

class TestMCPProtocolCompliance(unittest.TestCase):
    """Test the MCP server as a subprocess — real stdin/stdout communication."""

    SERVER_PATH = str(Path(__file__).parent.parent / "server.py")
    VENV_PYTHON = str(Path(__file__).parent.parent / ".venv" / "bin" / "python3")

    def _get_python(self):
        if os.path.exists(self.VENV_PYTHON):
            return self.VENV_PYTHON
        return sys.executable

    def _start_server(self):
        return subprocess.Popen(
            [self._get_python(), "-u", self.SERVER_PATH],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )

    def _send(self, proc, msg_dict):
        body = json.dumps(msg_dict)
        frame = f"Content-Length: {len(body.encode())}\r\n\r\n{body}"
        proc.stdin.write(frame.encode())
        proc.stdin.flush()

    def _recv(self, proc, timeout=5):
        """Read a Content-Length framed response."""
        header = b""
        start = time.time()
        while time.time() - start < timeout:
            b = proc.stdout.read(1)
            if not b:
                return None
            header += b
            if header.endswith(b"\r\n\r\n"):
                break
        else:
            return None

        length_str = header.split(b":")[1].strip().split(b"\r")[0]
        length = int(length_str)
        body = proc.stdout.read(length)
        return json.loads(body)

    def test_initialize_response_format(self):
        """Server returns valid JSON-RPC 2.0 initialize response."""
        proc = self._start_server()
        try:
            self._send(proc, {
                "jsonrpc": "2.0", "id": 1, "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "test", "version": "0.1"},
                },
            })
            resp = self._recv(proc)
            self.assertIsNotNone(resp)
            self.assertEqual(resp["jsonrpc"], "2.0")
            self.assertEqual(resp["id"], 1)
            self.assertIn("result", resp)
            self.assertEqual(resp["result"]["protocolVersion"], "2024-11-05")
            self.assertEqual(resp["result"]["serverInfo"]["name"], "touchgrass")
        finally:
            proc.stdin.close()
            proc.kill()
            proc.wait()

    def test_content_length_byte_accuracy(self):
        """Content-Length header matches actual body byte count."""
        proc = self._start_server()
        try:
            self._send(proc, {
                "jsonrpc": "2.0", "id": 1, "method": "initialize",
                "params": {"protocolVersion": "2024-11-05", "capabilities": {},
                           "clientInfo": {"name": "test", "version": "0.1"}},
            })
            # Read raw header
            header = b""
            while not header.endswith(b"\r\n\r\n"):
                header += proc.stdout.read(1)

            length = int(header.split(b":")[1].strip().split(b"\r")[0])
            body = proc.stdout.read(length)

            # Body must be exactly the declared length
            self.assertEqual(len(body), length)
            # Body must be valid JSON
            parsed = json.loads(body)
            self.assertIn("result", parsed)
        finally:
            proc.stdin.close()
            proc.kill()
            proc.wait()

    def test_crlf_compliance(self):
        """Response uses CRLF (\\r\\n) not just LF (\\n)."""
        proc = self._start_server()
        try:
            self._send(proc, {
                "jsonrpc": "2.0", "id": 1, "method": "initialize",
                "params": {"protocolVersion": "2024-11-05", "capabilities": {},
                           "clientInfo": {"name": "test", "version": "0.1"}},
            })
            raw = b""
            while not raw.endswith(b"\r\n\r\n"):
                raw += proc.stdout.read(1)

            self.assertIn(b"\r\n", raw)
            self.assertTrue(raw.startswith(b"Content-Length:"))
        finally:
            proc.stdin.close()
            proc.kill()
            proc.wait()

    def test_tools_list_returns_21(self):
        """tools/list returns exactly 21 tools."""
        proc = self._start_server()
        try:
            # Initialize
            self._send(proc, {
                "jsonrpc": "2.0", "id": 1, "method": "initialize",
                "params": {"protocolVersion": "2024-11-05", "capabilities": {},
                           "clientInfo": {"name": "test", "version": "0.1"}},
            })
            self._recv(proc)

            # Notify
            self._send(proc, {
                "jsonrpc": "2.0", "method": "notifications/initialized",
            })

            # List tools
            self._send(proc, {
                "jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {},
            })
            resp = self._recv(proc)
            self.assertIsNotNone(resp)
            tools = resp["result"]["tools"]
            self.assertEqual(len(tools), 21)

            # Every tool has required fields
            for tool in tools:
                self.assertIn("name", tool)
                self.assertIn("description", tool)
                self.assertIn("inputSchema", tool)
                self.assertEqual(tool["inputSchema"]["type"], "object")
        finally:
            proc.stdin.close()
            proc.kill()
            proc.wait()

    def test_tool_call_detect_mood(self):
        """End-to-end tool call via subprocess."""
        proc = self._start_server()
        try:
            self._send(proc, {
                "jsonrpc": "2.0", "id": 1, "method": "initialize",
                "params": {"protocolVersion": "2024-11-05", "capabilities": {},
                           "clientInfo": {"name": "test", "version": "0.1"}},
            })
            self._recv(proc)

            self._send(proc, {
                "jsonrpc": "2.0", "id": 2, "method": "tools/call",
                "params": {"name": "detect_mood",
                           "arguments": {"text": "I am absolutely thrilled!"}},
            })
            resp = self._recv(proc)
            self.assertIsNotNone(resp)
            self.assertIn("result", resp)
            content = resp["result"]["content"]
            self.assertEqual(len(content), 1)
            self.assertEqual(content[0]["type"], "text")

            data = json.loads(content[0]["text"])
            self.assertIn("valence", data)
            self.assertIn("quadrant", data)
            self.assertGreater(data["valence"], 0)
        finally:
            proc.stdin.close()
            proc.kill()
            proc.wait()

    def test_unknown_method_returns_error(self):
        """Unknown method returns JSON-RPC error -32601."""
        proc = self._start_server()
        try:
            self._send(proc, {
                "jsonrpc": "2.0", "id": 1, "method": "nonexistent/method",
                "params": {},
            })
            resp = self._recv(proc)
            self.assertIsNotNone(resp)
            self.assertIn("error", resp)
            self.assertEqual(resp["error"]["code"], -32601)
        finally:
            proc.stdin.close()
            proc.kill()
            proc.wait()

    def test_unknown_tool_returns_error(self):
        """Unknown tool returns JSON-RPC error -32601."""
        proc = self._start_server()
        try:
            self._send(proc, {
                "jsonrpc": "2.0", "id": 1, "method": "tools/call",
                "params": {"name": "nonexistent_tool", "arguments": {}},
            })
            resp = self._recv(proc)
            self.assertIsNotNone(resp)
            self.assertIn("error", resp)
            self.assertEqual(resp["error"]["code"], -32601)
        finally:
            proc.stdin.close()
            proc.kill()
            proc.wait()

    def test_notification_produces_no_response(self):
        """notifications/initialized should not produce a response."""
        proc = self._start_server()
        try:
            # Initialize first
            self._send(proc, {
                "jsonrpc": "2.0", "id": 1, "method": "initialize",
                "params": {"protocolVersion": "2024-11-05", "capabilities": {},
                           "clientInfo": {"name": "test", "version": "0.1"}},
            })
            self._recv(proc)

            # Send notification
            self._send(proc, {
                "jsonrpc": "2.0", "method": "notifications/initialized",
            })

            # Send a real request — if notification produced output, this will be misaligned
            self._send(proc, {
                "jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {},
            })
            resp = self._recv(proc)
            self.assertIsNotNone(resp)
            self.assertEqual(resp["id"], 2)  # Must be our tools/list, not leaked notification
        finally:
            proc.stdin.close()
            proc.kill()
            proc.wait()


# =============================================================================
# BELIEF MATH: NUMERICAL STABILITY & INVARIANTS
# =============================================================================

class TestBeliefMathInvariants(unittest.TestCase):
    """Verify mathematical invariants hold under edge conditions."""

    def test_opinion_triple_always_sums_to_one(self):
        """b + d + u = 1.0 for all factory methods."""
        cases = [
            Uncertainty(0.5, 0.3, 0.2),
            Uncertainty(0.0, 0.0, 1.0),
            Uncertainty(1.0, 0.0, 0.0),
            Uncertainty(0.0, 1.0, 0.0),
            Uncertainty.uniform(),
            Uncertainty.from_confidence(0.0),
            Uncertainty.from_confidence(0.5),
            Uncertainty.from_confidence(1.0),
            Uncertainty.from_beta(1.0, 1.0),
            Uncertainty.from_beta(100.0, 1.0),
            Uncertainty.from_beta(1.0, 100.0),
        ]
        for u in cases:
            self.assertAlmostEqual(u.belief + u.disbelief + u.uncertainty, 1.0,
                                   places=10, msg=f"Failed for {u}")

    def test_fusion_preserves_sum(self):
        """Fused opinion still sums to 1.0."""
        pairs = [
            (Uncertainty(0.7, 0.1, 0.2), Uncertainty(0.6, 0.2, 0.2)),
            (Uncertainty(0.0, 0.0, 1.0), Uncertainty(0.9, 0.05, 0.05)),
            (Uncertainty(0.5, 0.5, 0.0), Uncertainty(0.5, 0.5, 0.0)),
            (Uncertainty(0.001, 0.001, 0.998), Uncertainty(0.998, 0.001, 0.001)),
        ]
        for a, b in pairs:
            fused = cumulative_fuse([a, b])
            self.assertAlmostEqual(
                fused.belief + fused.disbelief + fused.uncertainty, 1.0,
                places=6, msg=f"Fusion failed for {a}, {b} → {fused}",
            )

    def test_fusion_reduces_uncertainty(self):
        """Fusing two opinions reduces uncertainty (more evidence → less ignorance)."""
        a = Uncertainty(0.4, 0.2, 0.4)
        b = Uncertainty(0.3, 0.3, 0.4)
        fused = cumulative_fuse([a, b])
        self.assertLess(fused.uncertainty, max(a.uncertainty, b.uncertainty))

    def test_fusion_of_agreeing_opinions_increases_belief(self):
        """Two opinions that agree on belief should produce higher combined belief."""
        a = Uncertainty(0.7, 0.1, 0.2)
        b = Uncertainty(0.6, 0.1, 0.3)
        fused = cumulative_fuse([a, b])
        self.assertGreater(fused.belief, min(a.belief, b.belief))

    def test_trust_discount_never_increases_belief(self):
        """Discounting through trust can only decrease or maintain belief."""
        trustor = Uncertainty(0.8, 0.1, 0.1)
        opinion = Uncertainty(0.9, 0.05, 0.05)
        discounted = trust_discount(trustor, opinion)
        self.assertLessEqual(discounted.belief, opinion.belief + 1e-10)

    def test_trust_discount_preserves_sum(self):
        """Discounted opinion sums to 1.0."""
        trustor = Uncertainty(0.5, 0.3, 0.2)
        opinion = Uncertainty(0.7, 0.1, 0.2)
        discounted = trust_discount(trustor, opinion)
        self.assertAlmostEqual(
            discounted.belief + discounted.disbelief + discounted.uncertainty,
            1.0, places=6,
        )

    def test_zero_trust_yields_full_uncertainty(self):
        """If trustor has zero belief, discounted opinion is fully uncertain."""
        trustor = Uncertainty(0.0, 0.0, 1.0)
        opinion = Uncertainty(0.9, 0.05, 0.05)
        discounted = trust_discount(trustor, opinion)
        self.assertAlmostEqual(discounted.uncertainty, 1.0, places=6)

    def test_probability_roundtrip(self):
        """probability → opinion → probability preserves value in interior range.

        Extremes (0.0, 1.0) are excluded: when uncertainty > 0, clamping in
        probability_to_opinion destroys information at the boundaries, making
        the roundtrip lossy by design.
        """
        for p in [0.1, 0.25, 0.5, 0.75, 0.9]:
            opinion = probability_to_opinion(p, uncertainty_level=0.2)
            recovered = opinion_to_probability(opinion, base_rate=0.5)
            self.assertAlmostEqual(p, recovered, places=2,
                                   msg=f"Roundtrip failed for p={p}")

    def test_from_beta_extreme_values(self):
        """from_beta handles extreme alpha/beta ratios."""
        # Very high confidence in True
        u = Uncertainty.from_beta(1000.0, 1.0)
        self.assertGreater(u.belief, 0.99)
        self.assertLess(u.uncertainty, 0.01)

        # Very high confidence in False
        u = Uncertainty.from_beta(1.0, 1000.0)
        self.assertGreater(u.disbelief, 0.99)

        # Uniform prior — from_beta(1,1) returns uniform() which is (1/3, 1/3, 1/3)
        u = Uncertainty.from_beta(1.0, 1.0)
        self.assertAlmostEqual(u.belief, 1.0 / 3.0, places=2)
        self.assertAlmostEqual(u.disbelief, 1.0 / 3.0, places=2)
        self.assertAlmostEqual(u.uncertainty, 1.0 / 3.0, places=2)

    def test_expected_value_bounded(self):
        """Expected value is always in [0, 1]."""
        cases = [
            Uncertainty(0.0, 0.0, 1.0),
            Uncertainty(1.0, 0.0, 0.0),
            Uncertainty(0.0, 1.0, 0.0),
            Uncertainty(0.5, 0.5, 0.0),
            Uncertainty.uniform(),
        ]
        for u in cases:
            self.assertGreaterEqual(u.expected_value, 0.0)
            self.assertLessEqual(u.expected_value, 1.0)

    def test_credible_interval_contains_expected_value(self):
        """90% credible interval contains the expected value."""
        u = Uncertainty(0.6, 0.2, 0.2, sample_size=20.0)
        lower, upper = u.credible_interval(0.9)
        self.assertLessEqual(lower, u.expected_value)
        self.assertGreaterEqual(upper, u.expected_value)

    def test_decomposition_variances_non_negative(self):
        """Epistemic and aleatoric variance are never negative."""
        for alpha, beta in [(1.0, 1.0), (10.0, 3.0), (1.0, 50.0), (100.0, 100.0)]:
            d = decompose_from_beta(alpha, beta)
            self.assertGreaterEqual(d.epistemic_variance, 0.0,
                                    msg=f"Negative epistemic for a={alpha}, b={beta}")
            self.assertGreaterEqual(d.aleatoric_variance, 0.0,
                                    msg=f"Negative aleatoric for a={alpha}, b={beta}")

    def test_decomposition_sums_to_total(self):
        """epistemic + aleatoric ≈ total variance."""
        for alpha, beta in [(5.0, 5.0), (20.0, 3.0), (2.0, 15.0)]:
            d = decompose_from_beta(alpha, beta)
            self.assertAlmostEqual(
                d.epistemic_variance + d.aleatoric_variance, d.total_variance,
                places=10,
            )

    def test_blend_preserves_sum(self):
        """Blended opinion sums to 1.0."""
        a = Uncertainty(0.7, 0.2, 0.1)
        b = Uncertainty(0.3, 0.5, 0.2)
        for influence in [0.0, 0.1, 0.5, 0.9, 1.0]:
            blended = blend_uncertainty(a, b, influence)
            self.assertAlmostEqual(
                blended.belief + blended.disbelief + blended.uncertainty, 1.0,
                places=6,
            )

    def test_multi_opinion_fusion(self):
        """Fusing 10 opinions preserves the sum-to-one invariant."""
        opinions = [
            Uncertainty(0.3 + i * 0.05, 0.2, 0.5 - i * 0.05)
            for i in range(10)
        ]
        fused = cumulative_fuse(opinions)
        self.assertAlmostEqual(
            fused.belief + fused.disbelief + fused.uncertainty, 1.0, places=6,
        )
        self.assertLess(fused.uncertainty, opinions[0].uncertainty)


# =============================================================================
# BELIEF MATH: VALIDATION & ERROR HANDLING
# =============================================================================

class TestBeliefMathValidation(unittest.TestCase):
    """Verify input validation catches bad data."""

    def test_negative_belief_rejected(self):
        with self.assertRaises(ValueError):
            Uncertainty(-0.1, 0.5, 0.6)

    def test_sum_not_one_rejected(self):
        with self.assertRaises(ValueError):
            Uncertainty(0.5, 0.5, 0.5)

    def test_zero_sample_size_rejected(self):
        with self.assertRaises(ValueError):
            Uncertainty(0.5, 0.3, 0.2, sample_size=0.0)

    def test_probability_out_of_range_rejected(self):
        with self.assertRaises(ValueError):
            probability_to_opinion(1.5)
        with self.assertRaises(ValueError):
            probability_to_opinion(-0.1)

    def test_from_beta_below_one_rejected(self):
        with self.assertRaises(ValueError):
            Uncertainty.from_beta(0.5, 1.0)

    def test_empty_fusion_rejected(self):
        with self.assertRaises(ValueError):
            cumulative_fuse([])

    def test_decomposition_mean_bounded(self):
        with self.assertRaises(ValueError):
            DecomposedUncertainty(mean=1.5, epistemic_variance=0.1, aleatoric_variance=0.1)

    def test_negative_variance_rejected(self):
        with self.assertRaises(ValueError):
            DecomposedUncertainty(mean=0.5, epistemic_variance=-0.1, aleatoric_variance=0.1)


# =============================================================================
# BAYESIAN NETWORK
# =============================================================================

class TestBayesianNetwork(unittest.TestCase):
    """Test the graph-based belief propagation."""

    def test_add_node_and_update(self):
        net = BayesianNetwork()
        net.add_node("c1", "Test claim")
        net.update_belief("c1", True, 10.0)
        self.assertGreater(net.beliefs["c1"].probability, 0.5)

    def test_propagation_affects_children(self):
        net = BayesianNetwork()
        net.add_node("parent", "Parent is true")
        net.add_node("child", "Child depends on parent")
        net.add_edge("parent", "child", 1.0)
        net.update_belief("parent", True, 50.0)
        net.propagate(steps=20)
        # Child should shift toward parent
        self.assertGreater(net.beliefs["child"].probability, 0.5)

    def test_anchored_nodes_resist_propagation(self):
        net = BayesianNetwork()
        net.add_node("parent", "Parent")
        net.add_node("child", "Anchored child")
        net.add_edge("parent", "child", 1.0)
        net.update_belief("child", False, 50.0)  # Anchor child to False
        net.update_belief("parent", True, 50.0)
        net.propagate(steps=20)
        # Child is anchored — should stay below 0.5
        self.assertLess(net.beliefs["child"].probability, 0.5)


# =============================================================================
# DATABASE INTEGRITY
# =============================================================================

class TestDatabaseIntegrity(TestBase):
    """Test schema, constraints, and data integrity."""

    def test_schema_creates_22_tables(self):
        cursor = self.db.fetchall(
            "SELECT name FROM sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'memories_fts_%'"
        )
        table_names = [r["name"] for r in cursor]
        self.assertGreaterEqual(len(table_names), 20)

    def test_wal_mode_enabled(self):
        row = self.db.fetchone("PRAGMA journal_mode")
        self.assertEqual(row["journal_mode"], "wal")

    def test_foreign_keys_enabled(self):
        row = self.db.fetchone("PRAGMA foreign_keys")
        self.assertEqual(row["foreign_keys"], 1)

    def test_compliance_profile_singleton(self):
        """compliance_profile enforces id=1 (singleton)."""
        with self.assertRaises(Exception):
            self.db.execute(
                "INSERT INTO compliance_profile (id, alpha, beta) VALUES (2, 1.0, 1.0)"
            )
            self.db.commit()

    def test_reward_profile_singleton(self):
        """reward_profile enforces id=1 (singleton)."""
        with self.assertRaises(Exception):
            self.db.execute(
                "INSERT INTO reward_profile (id) VALUES (2)"
            )
            self.db.commit()

    def test_fts5_search_empty_query(self):
        """FTS5 rejects empty query with OperationalError.

        Empty string is not valid FTS5 syntax. The DB layer does not wrap this
        — callers are expected to validate input before searching.
        """
        with self.assertRaises(sqlite3.OperationalError):
            self.db.search_memories("")

    def test_fts5_special_characters(self):
        """FTS5 handles special characters without crashing."""
        self.db.store_memory("m1", "Hello world! @#$%^&*()")
        # Should not crash
        results = self.db.search_memories("Hello")
        self.assertEqual(len(results), 1)

    def test_fts5_porter_stemming(self):
        """FTS5 Porter stemming matches word variants."""
        self.db.store_memory("m1", "The runner is running quickly")
        results = self.db.search_memories("run")
        self.assertEqual(len(results), 1)

    def test_idempotent_initialization(self):
        """init_db can be called multiple times without error."""
        init_db(self.db_path)
        init_db(self.db_path)
        self.assertTrue(is_initialized(self.db_path))

    def test_email_upsert_deduplicates(self):
        """email_items UNIQUE constraint on message_id deduplicates."""
        self.db.upsert_email("msg1", "a@b.com", "A", "Subj", "Snip",
                             "fyi", 0.5, [], "2026-01-01")
        self.db.upsert_email("msg1", "a@b.com", "A", "Updated Subj", "Snip",
                             "urgent", 1.0, [], "2026-01-01")
        emails = self.db.get_unbriefed_emails()
        self.assertEqual(len(emails), 1)

    def test_calendar_event_deduplicates(self):
        """calendar_events UNIQUE constraint on event_id deduplicates."""
        self.db.upsert_calendar_event("ev1", "Standup", "2099-01-01T09:00:00",
                                       "2099-01-01T09:30:00")
        self.db.upsert_calendar_event("ev1", "Updated Standup", "2099-01-01T09:00:00",
                                       "2099-01-01T09:30:00")
        events = self.db.get_upcoming_events(876000)
        self.assertEqual(len(events), 1)

    def test_large_memory_store(self):
        """Store 100 memories and search with explicit limit."""
        for i in range(100):
            self.db.store_memory(f"m{i}", f"Memory number {i} about topic alpha")
        # Default limit is 10 — pass explicit limit to retrieve all
        results = self.db.search_memories("topic alpha", limit=200)
        self.assertEqual(len(results), 100)

    def test_audit_log_immutable_pattern(self):
        """Audit log only grows — verify no DELETE/UPDATE is needed."""
        self.db.audit("event1", "t1", {"k": "v"}, "s1")
        self.db.audit("event2", "t2", {"k": "v"}, "s1")
        log = self.db.get_audit_log(100)
        self.assertEqual(len(log), 2)


# =============================================================================
# GOVERNANCE EDGE CASES
# =============================================================================

class TestGovernanceBoundaryConditions(TestBase):
    """Test governance at exact thresholds."""

    def test_encoding_weight_exactly_at_threshold(self):
        """encoding_weight == 1.3 should be held (>= threshold)."""
        gov = GovernanceLayerDB(self.db)
        result = gov.gate_memory_write("m1", 1.3, 0.0, "unverified", 0)
        self.assertEqual(result, "held")

    def test_encoding_weight_just_below_threshold(self):
        """encoding_weight == 1.29 should be allowed."""
        gov = GovernanceLayerDB(self.db)
        result = gov.gate_memory_write("m1", 1.29, 0.0, "unverified", 0)
        self.assertEqual(result, "allowed")

    def test_conflict_score_exactly_at_threshold(self):
        """conflict_score == 0.5 should be allowed (threshold is > 0.5, not >=)."""
        gov = GovernanceLayerDB(self.db)
        result = gov.gate_memory_write("m1", 0.5, 0.5, "unverified", 0)
        self.assertEqual(result, "allowed")

    def test_conflict_score_just_above_threshold(self):
        """conflict_score == 0.51 should be held."""
        gov = GovernanceLayerDB(self.db)
        result = gov.gate_memory_write("m1", 0.5, 0.51, "unverified", 0)
        self.assertEqual(result, "held")

    def test_both_thresholds_exceeded(self):
        """Both high encoding weight and high conflict still creates only one hold."""
        gov = GovernanceLayerDB(self.db)
        result = gov.gate_memory_write("m1", 2.0, 0.8, "unverified", 0)
        self.assertEqual(result, "held")
        holds = gov.pending_holds()
        self.assertEqual(len(holds), 1)  # Only one hold, not two

    def test_promoted_memory_deletion_requires_hold(self):
        """Deleting a promoted memory requires governance approval."""
        gov = GovernanceLayerDB(self.db)
        result = gov.gate_memory_delete("m1", "promoted")
        self.assertEqual(result, "held")

    def test_unverified_memory_deletion_allowed(self):
        """Deleting an unverified memory is allowed immediately."""
        gov = GovernanceLayerDB(self.db)
        result = gov.gate_memory_delete("m1", "unverified")
        self.assertEqual(result, "allowed")

    def test_resolve_nonexistent_hold_returns_false(self):
        """Resolving a hold that doesn't exist returns False."""
        gov = GovernanceLayerDB(self.db)
        result = gov.resolve_hold("nonexistent", "approve")
        self.assertFalse(result)

    def test_audit_trail_for_held_memory(self):
        """Held memory creates audit entry with correct details."""
        gov = GovernanceLayerDB(self.db)
        gov.gate_memory_write("m1", 1.5, 0.0, "unverified", 0, "s1")
        log = self.db.get_audit_log(10)
        self.assertGreater(len(log), 0)
        entry = log[0]
        self.assertEqual(entry["event_type"], "hold_created")
        details = json.loads(entry["details"])
        self.assertAlmostEqual(details["encoding_weight"], 1.5)

    def test_corroboration_exactly_at_promotion_threshold(self):
        """Corroboration count == PROMOTION_THRESHOLD should be allowed."""
        gov = GovernanceLayerDB(self.db)
        result = gov.gate_memory_write("m1", 0.5, 0.0, "verified", 3)
        self.assertEqual(result, "allowed")

    def test_corroboration_below_promotion_threshold(self):
        """Corroboration count < PROMOTION_THRESHOLD on non-unverified memory is held."""
        gov = GovernanceLayerDB(self.db)
        result = gov.gate_memory_write("m1", 0.5, 0.0, "verified", 2)
        self.assertEqual(result, "held")


# =============================================================================
# GAP ANALYSIS: MULTI-TOPIC & TRENDS
# =============================================================================

class TestGapAnalysisAdvanced(TestBase):
    """Test gap analysis with multiple topics, trends, and dominance."""

    def test_multiple_topics(self):
        """Gap analysis handles 5 topics simultaneously."""
        gap = GapAnalyzerDB(self.db)
        persona = {}
        reward = {}
        for i, topic in enumerate(["work", "health", "family", "finance", "hobby"]):
            persona[topic] = EngineOpinion(
                topic=topic, belief=0.7 - i * 0.05,
                disbelief=0.1, uncertainty=0.2 + i * 0.05,
                source_signals=["auth"],
            )
            reward[topic] = EngineOpinion(
                topic=topic, belief=0.3 + i * 0.1,
                disbelief=0.2, uncertainty=0.5 - i * 0.1,
                source_signals=["reward"],
            )

        analysis = gap.analyze(persona, reward, "s1")
        self.assertEqual(len(analysis.topic_gaps), 5)

    def test_trend_detection_increasing(self):
        """Increasing gap trend is detected from 3+ data points."""
        gap = GapAnalyzerDB(self.db)

        # Simulate 3 rounds with increasing gap
        for i in range(3):
            persona = {"work": EngineOpinion(
                topic="work", belief=0.8, disbelief=0.1, uncertainty=0.1,
                source_signals=["auth"],
            )}
            reward = {"work": EngineOpinion(
                topic="work", belief=0.5 - i * 0.1, disbelief=0.2,
                uncertainty=0.3 + i * 0.1, source_signals=["reward"],
            )}
            gap.analyze(persona, reward, f"s{i}")

        # Last analysis should show trend
        history = self.db.get_gap_history("work", limit=3)
        self.assertEqual(len(history), 3)
        magnitudes = [h["gap_magnitude"] for h in reversed(history)]
        self.assertGreater(magnitudes[-1], magnitudes[0])

    def test_severity_classification(self):
        """classify_severity returns correct labels for all ranges.

        Thresholds: <0.1 none, <0.25 low, <0.45 moderate, <0.65 high, else critical.
        """
        self.assertEqual(classify_severity(0.0), "none")
        self.assertEqual(classify_severity(0.09), "none")
        self.assertEqual(classify_severity(0.1), "low")
        self.assertEqual(classify_severity(0.24), "low")
        self.assertEqual(classify_severity(0.25), "moderate")
        self.assertEqual(classify_severity(0.44), "moderate")
        self.assertEqual(classify_severity(0.45), "high")
        self.assertEqual(classify_severity(0.64), "high")
        self.assertEqual(classify_severity(0.65), "critical")
        self.assertEqual(classify_severity(1.0), "critical")

    def test_dominant_engine_calculation(self):
        """Dominant engine is correctly identified from gap directions."""
        gap = GapAnalyzerDB(self.db)

        # Persona leads on 3 topics, reward on 1
        persona_topics = {}
        reward_topics = {}
        for t in ["a", "b", "c"]:
            persona_topics[t] = EngineOpinion(
                topic=t, belief=0.8, disbelief=0.1, uncertainty=0.1,
                source_signals=[],
            )
            reward_topics[t] = EngineOpinion(
                topic=t, belief=0.3, disbelief=0.3, uncertainty=0.4,
                source_signals=[],
            )
        # One where reward leads
        persona_topics["d"] = EngineOpinion(
            topic="d", belief=0.2, disbelief=0.3, uncertainty=0.5, source_signals=[],
        )
        reward_topics["d"] = EngineOpinion(
            topic="d", belief=0.8, disbelief=0.1, uncertainty=0.1, source_signals=[],
        )

        analysis = gap.analyze(persona_topics, reward_topics, "s1")
        self.assertEqual(analysis.dominant_engine, "persona")

    def test_gap_analysis_with_empty_topics(self):
        """Gap analysis with no topics returns empty result."""
        gap = GapAnalyzerDB(self.db)
        analysis = gap.analyze({}, {}, "s1")
        self.assertEqual(len(analysis.topic_gaps), 0)
        self.assertAlmostEqual(analysis.overall_divergence, 0.0)

    def test_explain_behavior_insufficient_data(self):
        """explain_behavior with no significant gaps returns honest message."""
        gap = GapAnalyzerDB(self.db)
        empty = GapAnalysis()
        result = gap.explain_behavior("I keep procrastinating", empty)
        self.assertIn("Not enough divergence data", result)


# =============================================================================
# ENGINE INTEGRATION: PERSONA + REWARD → GAP
# =============================================================================

class TestDualEnginePipeline(TestBase):
    """End-to-end dual-engine pipeline tests."""

    def _setup_engines(self):
        truth = TruthLayerDB(self.db)
        authority = AuthorityGraphDB(self.db)
        compliance = ComplianceDetectorDB(self.db)
        persona = PersonaEngineDB(truth, authority, compliance)
        reward = RewardModelDB(self.db)
        aa = ApproachAvoidanceDetectorDB(self.db)
        gap = GapAnalyzerDB(self.db)
        return persona, reward, aa, gap, truth, authority

    def test_full_dual_engine_pipeline(self):
        """Persona → Reward → Gap → Analysis: complete pipeline."""
        persona_eng, reward_eng, aa_eng, gap_eng, truth, auth = self._setup_engines()
        self.db.start_session("s1")

        # Setup authority
        auth.add_source("boss", "My Boss", AuthorityTier.INSTITUTIONAL, 0.8, ["work"])

        # Setup belief
        truth.add_claim("work", "Work is important")
        truth.update_belief("work", True, 10.0, "s1")

        # Detect mood
        detector = MoodDetector()
        mood = detector.detect("I should focus on work but I just want to relax")

        # Run persona engine
        persona_opinions = persona_eng.process(
            "I should focus on work but I just want to relax",
            mood, ["work"], "s1",
        )
        self.assertIn("work", persona_opinions)

        # Build reward opinions
        aa_data = aa_eng.analyze(
            "I should focus on work but I just want to relax", "work", mood,
        )
        reward_eng.observe("autonomy", mood.valence)

        reward_opinions = {
            "work": EngineOpinion(
                topic="work",
                belief=max(0, aa_data.approach_ratio * 0.8),
                disbelief=max(0, (1 - aa_data.approach_ratio) * 0.8),
                uncertainty=0.2,
                source_signals=[f"approach_ratio:{aa_data.approach_ratio:.2f}"],
            ),
        }

        # Gap analysis
        analysis = gap_eng.analyze(persona_opinions, reward_opinions, "s1")
        self.assertIsNotNone(analysis)
        self.assertEqual(len(analysis.topic_gaps), 1)

        # Verify the gap captures the should-vs-want tension
        gap_topic = analysis.topic_gaps[0]
        self.assertEqual(gap_topic.topic, "work")
        self.assertGreater(gap_topic.gap_magnitude, 0)

    def test_compliance_shifts_persona(self):
        """High compliance text should boost persona belief."""
        persona_eng, _, _, _, truth, _ = self._setup_engines()
        self.db.start_session("s1")

        mood = MoodState(
            valence=0.0, arousal=0.0, confidence=0.5,
            quadrant=EmotionalQuadrant.NEUTRAL, signals=[],
        )

        # Compliant text
        opinions_compliant = persona_eng.process(
            "I should do this right away, understood, will do!",
            mood, ["task"], "s1",
        )

        # Non-compliant text
        opinions_defiant = persona_eng.process(
            "whatever, pointless waste of time, screw that",
            mood, ["task"], "s1",
        )

        # Compliance should have boosted persona belief for compliant text
        # (via espoused values and compliance signals)
        self.assertGreater(
            opinions_compliant["task"].belief,
            opinions_defiant["task"].belief - 0.5,  # Allow for noise
        )

    def test_approach_avoidance_accumulates(self):
        """Multiple analyze() calls accumulate approach/avoidance counts."""
        aa = ApproachAvoidanceDetectorDB(self.db)
        mood = MoodState(
            valence=0.5, arousal=0.3, confidence=0.7,
            quadrant=EmotionalQuadrant.EXCITED, signals=[],
        )

        # 5 approach signals
        for i in range(5):
            aa.analyze(f"I want to explore this more! Tell me how exactly! #{i}",
                       "project", mood)

        data = aa.get_tracker("project")
        self.assertGreater(data.approach_count, 0)
        self.assertEqual(data.observations, 5)

    def test_reward_model_learns_dominant_type(self):
        """Reward model identifies dominant type after 5+ observations."""
        reward = RewardModelDB(self.db)
        for _ in range(6):
            reward.observe("completion", 0.8)
            reward.observe("shipping", 0.7)

        scores = reward.get_scores()
        self.assertEqual(scores["dominant"], "achievement")
        self.assertGreater(scores["achievement"], scores["social_approval"])


# =============================================================================
# MOOD DETECTOR: EDGE CASES
# =============================================================================

class TestMoodDetectorEdgeCases(unittest.TestCase):
    """Test mood detection boundary conditions."""

    def setUp(self):
        self.detector = MoodDetector()

    def test_empty_string(self):
        """Empty string returns neutral."""
        mood = self.detector.detect("")
        self.assertEqual(mood.quadrant, EmotionalQuadrant.NEUTRAL)

    def test_very_long_text(self):
        """Very long text doesn't crash."""
        text = "I am happy! " * 10000
        mood = self.detector.detect(text)
        self.assertIsNotNone(mood.quadrant)

    def test_unicode_text(self):
        """Unicode characters don't crash the detector."""
        mood = self.detector.detect("I'm feeling great! 🎉 很好 素晴らしい")
        self.assertIsNotNone(mood.quadrant)

    def test_only_punctuation(self):
        """Only punctuation returns neutral."""
        mood = self.detector.detect("... --- !!!")
        # May detect arousal from !!! but should not crash
        self.assertIsNotNone(mood.quadrant)

    def test_mixed_signals(self):
        """Mixed positive and negative returns a result without crashing."""
        mood = self.detector.detect("I love this but I'm also terrified")
        self.assertIsNotNone(mood.quadrant)
        # Should have both positive and negative signals
        self.assertGreater(len(mood.signals), 0)

    def test_all_caps(self):
        """All caps increases arousal."""
        normal = self.detector.detect("this is urgent")
        caps = self.detector.detect("THIS IS URGENT")
        self.assertGreaterEqual(caps.arousal, normal.arousal)


# =============================================================================
# VOICE PIPELINE: CALIBRATION & STATE
# =============================================================================

class TestVoicePipelineAdvanced(TestBase):
    """Extended voice pipeline tests."""

    def _calibrate(self):
        cal = VoiceCalibrator(self.db)
        states = {
            "calm": VoiceFeatures(150, 10, 120, -20, 0.2, 2000),
            "excited": VoiceFeatures(200, 25, 160, -15, 0.1, 2800),
            "frustrated": VoiceFeatures(180, 30, 140, -12, 0.15, 2600),
            "pressured": VoiceFeatures(190, 20, 170, -14, 0.08, 2500),
            "reflective": VoiceFeatures(130, 8, 100, -25, 0.3, 1800),
        }
        for label, features in states.items():
            cal.add_calibration_point(label, features)
        return cal

    def test_equidistant_input_returns_something(self):
        """Input exactly between two calibration points returns a result."""
        cal = self._calibrate()
        # Midpoint between calm and excited
        mid = VoiceFeatures(175, 17.5, 140, -17.5, 0.15, 2400)
        label, conf = cal.classify_state(mid)
        self.assertIn(label, ["calm", "excited", "frustrated", "pressured", "reflective"])
        self.assertGreater(conf, 0.0)

    def test_extreme_outlier(self):
        """Input far from any calibration point has low confidence."""
        cal = self._calibrate()
        outlier = VoiceFeatures(500, 100, 500, 0, 0.0, 10000)
        label, conf = cal.classify_state(outlier)
        # Should still return a result, but confidence should be lower
        self.assertIsNotNone(label)

    def test_voice_state_briefing_modes(self):
        """Each voice state maps to correct briefing mode.

        "reflective" with confidence > 0.5 triggers is_fatigued → minimal.
        """
        test_cases = [
            ("frustrated", True, "minimal"),
            ("pressured", True, "minimal"),
            ("calm", True, "standard"),
            ("reflective", True, "minimal"),  # is_fatigued when confidence > 0.5
            ("excited", True, "full_pushback"),
            ("problem_solving", True, "full_pushback"),
            ("anything", False, "standard"),  # Uncalibrated
        ]
        for state, calibrated, expected_mode in test_cases:
            vs = VoiceState(state, 0.8, calibrated=calibrated)
            self.assertEqual(vs.briefing_mode, expected_mode,
                             msg=f"{state} (cal={calibrated}) → {vs.briefing_mode}")


# =============================================================================
# BRIEFING ENGINE: PRIORITIZATION
# =============================================================================

class TestBriefingPrioritization(TestBase):
    """Test briefing engine item selection and adaptation."""

    def test_highest_priority_is_now(self):
        """Highest priority pending item becomes NOW."""
        for p, summary in [(0.5, "Low priority"), (1.0, "High priority"), (0.8, "Medium")]:
            self.db.execute(
                "INSERT INTO pending_items (source, summary, priority) VALUES (?, ?, ?)",
                ("test", summary, p),
            )
        self.db.commit()

        engine = BriefingEngine(self.db)
        briefing = engine.assemble()
        self.assertEqual(briefing.now.summary, "High priority")

    def test_calendar_events_in_next(self):
        """Calendar events appear in NEXT section.

        get_upcoming_events(12) queries the next 12 hours from now —
        events must be within that window to appear.
        """
        from datetime import datetime, timedelta
        soon = datetime.utcnow() + timedelta(hours=2)
        soon_end = soon + timedelta(minutes=30)
        # SQLite datetime('now') uses space separator, not 'T' — must match
        self.db.upsert_calendar_event("ev1", "Team Standup",
                                       soon.strftime("%Y-%m-%d %H:%M:%S"),
                                       soon_end.strftime("%Y-%m-%d %H:%M:%S"))
        self.db.execute(
            "INSERT INTO pending_items (source, summary, priority) VALUES (?, ?, ?)",
            ("test", "Something important", 1.0),
        )
        self.db.commit()

        engine = BriefingEngine(self.db)
        briefing = engine.assemble()
        self.assertGreater(len(briefing.next_actions), 0)

    def test_frustrated_voice_gets_minimal(self):
        """Frustrated voice state → minimal briefing."""
        self.db.execute(
            "INSERT INTO pending_items (source, summary, priority) VALUES (?, ?, ?)",
            ("test", "Budget review needed", 0.7),
        )
        self.db.commit()

        vs = VoiceState("frustrated", 0.8, calibrated=True)
        engine = BriefingEngine(self.db)
        briefing = engine.assemble(voice_state=vs)
        self.assertEqual(briefing.adaptation, "minimal")


# =============================================================================
# EMAIL CLASSIFICATION: EDGE CASES
# =============================================================================

class TestEmailClassificationEdgeCases(unittest.TestCase):
    """Test email priority classification edge cases."""

    def test_empty_inputs(self):
        """Empty subject and snippet default to fyi."""
        priority, score = classify_priority("", "", [])
        self.assertEqual(priority, "fyi")

    def test_urgent_in_labels(self):
        """IMPORTANT label triggers urgent."""
        priority, _ = classify_priority("Normal subject", "Normal text", ["IMPORTANT"])
        self.assertEqual(priority, "urgent")

    def test_promotional_label(self):
        """CATEGORY_PROMOTIONS label triggers noise."""
        priority, _ = classify_priority("Great offer", "Buy now", ["CATEGORY_PROMOTIONS"])
        self.assertEqual(priority, "noise")

    def test_reply_request_detection(self):
        """Phrases requesting a reply trigger needs_reply."""
        priority, _ = classify_priority("Question for you", "Please respond by EOD", [])
        self.assertEqual(priority, "needs_reply")


# =============================================================================
# DATA MODEL INVARIANTS
# =============================================================================

class TestDataModelInvariants(unittest.TestCase):
    """Test dataclass properties and invariants."""

    def test_mood_intensity_is_euclidean(self):
        """MoodState.intensity = sqrt(valence² + arousal²)."""
        mood = MoodState(
            valence=0.3, arousal=0.4, confidence=0.7,
            quadrant=EmotionalQuadrant.EXCITED, signals=[],
        )
        expected = math.sqrt(0.3 ** 2 + 0.4 ** 2)
        self.assertAlmostEqual(mood.intensity, expected, places=6)

    def test_approach_ratio_with_no_data(self):
        """ApproachAvoidanceData defaults to 0.5 approach ratio."""
        aa = ApproachAvoidanceData(topic="test")
        self.assertAlmostEqual(aa.approach_ratio, 0.5)

    def test_gap_significance_threshold(self):
        """TopicGap.is_significant requires magnitude > 0.3 AND observations >= 3."""
        # Below magnitude threshold
        g1 = TopicGap(topic="a", persona_opinion=0.5, reward_opinion=0.4,
                       gap_magnitude=0.1, gap_direction="persona_leads",
                       conflict_severity="none", explanation="", observations=5)
        self.assertFalse(g1.is_significant)

        # Below observation threshold
        g2 = TopicGap(topic="b", persona_opinion=0.8, reward_opinion=0.2,
                       gap_magnitude=0.6, gap_direction="persona_leads",
                       conflict_severity="high", explanation="", observations=2)
        self.assertFalse(g2.is_significant)

        # Both met
        g3 = TopicGap(topic="c", persona_opinion=0.8, reward_opinion=0.2,
                       gap_magnitude=0.6, gap_direction="persona_leads",
                       conflict_severity="high", explanation="", observations=3)
        self.assertTrue(g3.is_significant)

    def test_encoding_weight_capped(self):
        """EncodingWeight.total_weight is capped at 2.0."""
        ew = EncodingWeight(flashbulb=2.0, authority_relevance=2.0,
                             reward_alignment=2.0, conflict_score=5.0)
        self.assertLessEqual(ew.total_weight, 2.0)

    def test_gap_analysis_theatre_score_bounded(self):
        """GapAnalysis.theatre_score is bounded [0, 1]."""
        ga = GapAnalysis(overall_divergence=0.0)
        self.assertAlmostEqual(ga.theatre_score, 0.0)

        ga2 = GapAnalysis(
            overall_divergence=5.0,
            topic_gaps=[TopicGap(
                topic="x", persona_opinion=1, reward_opinion=0,
                gap_magnitude=1, gap_direction="persona_leads",
                conflict_severity="critical", explanation="",
            )],
        )
        self.assertLessEqual(ga2.theatre_score, 1.0)

    def test_engine_opinion_expected_value(self):
        """EngineOpinion.expected_value = belief + uncertainty * 0.5."""
        eo = EngineOpinion(topic="t", belief=0.6, disbelief=0.2,
                            uncertainty=0.2, source_signals=[])
        expected = 0.6 + 0.2 * 0.5
        self.assertAlmostEqual(eo.expected_value, expected)

    def test_introspective_narration_defaults(self):
        """IntrospectiveNarration has sensible defaults."""
        intro = IntrospectiveNarration()
        self.assertAlmostEqual(intro.overall_confidence, 0.0)
        self.assertEqual(intro.reasoning_depth, "routine")
        narrative = intro.narrative()
        self.assertIn("guessing", narrative)


# =============================================================================
# HANDLER DISPATCH VALIDATION
# =============================================================================

class TestHandlerDispatch(TestBase):
    """Verify every tool handler works without crashing."""

    def test_all_handlers_callable(self):
        """Every handler in HANDLERS dict is callable and doesn't crash with minimal args."""
        from server import HANDLERS, TOOLS

        # Map tool name to a minimal valid args dict
        minimal_args = {
            "detect_mood": {"text": "hello"},
            "query_beliefs": {"belief_id": "nonexistent"},
            "update_belief": {"belief_id": "nonexistent", "action": "confirm"},
            "get_gap_analysis": {"text": "test", "topics": ["test"]},
            "explain_behavior": {"behavior": "test", "topics": []},
            "get_influence_analysis": {},
            "manage_authority": {"source_id": "s1", "name": "Test", "tier": "peer"},
            "store_emotional_memory": {"content": "test memory"},
            "search_memories": {"query": "test"},
            "list_holds": {},
            "resolve_hold": {"hold_id": "nonexistent", "decision": "approve"},
            "get_voice_state": {},
            "get_calibration_status": {},
            "run_calibration_session": {"label": "calm"},
            "get_pending_briefing": {},
            "mark_briefed": {"item_ids": []},
            "get_email_summary": {},
            "get_calendar_context": {},
            "get_ambient_context": {},
            "get_patterns": {},
            "get_pushback": {},
        }

        for tool in TOOLS:
            name = tool["name"]
            self.assertIn(name, HANDLERS, f"No handler for tool: {name}")
            handler = HANDLERS[name]
            args = minimal_args.get(name, {})
            # Should not raise
            try:
                result = handler(args)
                self.assertIsInstance(result, dict, f"{name} didn't return dict")
            except Exception as e:
                self.fail(f"Handler '{name}' crashed with args {args}: {e}")

    def test_handler_results_are_json_serializable(self):
        """Every handler result can be JSON-serialized."""
        from server import HANDLERS

        test_cases = {
            "detect_mood": {"text": "I'm feeling okay today"},
            "get_influence_analysis": {},
            "search_memories": {"query": "nothing"},
            "list_holds": {},
            "get_calibration_status": {},
            "get_pending_briefing": {},
            "get_email_summary": {},
            "get_ambient_context": {},
            "get_patterns": {},
            "get_pushback": {},
        }

        for name, args in test_cases.items():
            result = HANDLERS[name](args)
            try:
                json.dumps(result, default=str)
            except (TypeError, ValueError) as e:
                self.fail(f"Handler '{name}' result not JSON serializable: {e}")


# =============================================================================
# CONCURRENT ACCESS
# =============================================================================

class TestConcurrentAccess(TestBase):
    """Test SQLite WAL mode handles concurrent reads."""

    def test_concurrent_reads(self):
        """Multiple threads can read simultaneously without deadlock."""
        self.db.start_session("s1")
        self.db.store_memory("m1", "Test memory for concurrency")

        errors = []

        def reader():
            try:
                db2 = TouchgrassDB(self.db_path)
                for _ in range(10):
                    db2.search_memories("memory")
                    db2.get_audit_log(5)
                db2.close()
            except Exception as e:
                errors.append(str(e))

        threads = [threading.Thread(target=reader) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10)

        self.assertEqual(len(errors), 0, f"Concurrent read errors: {errors}")


# =============================================================================
# TRUST LAYER DB
# =============================================================================

class TestTruthLayerDBAdvanced(TestBase):
    """Extended truth layer tests."""

    def test_multiple_evidence_accumulates(self):
        """Multiple confirm/reject calls accumulate correctly."""
        truth = TruthLayerDB(self.db)
        truth.add_claim("c1", "Test claim")

        # 5 confirmations
        for _ in range(5):
            truth.update_belief("c1", True, 5.0, "s1")

        belief = truth.get_belief("c1")
        # alpha should be 1.0 (initial) + 25.0 (5 * 5.0)
        self.assertAlmostEqual(belief.alpha, 26.0)
        self.assertGreater(belief.probability, 0.9)

    def test_conflicting_evidence_stays_uncertain(self):
        """Equal confirm and reject evidence keeps probability near 0.5."""
        truth = TruthLayerDB(self.db)
        truth.add_claim("c1", "Controversial claim")

        for _ in range(10):
            truth.update_belief("c1", True, 5.0)
            truth.update_belief("c1", False, 5.0)

        belief = truth.get_belief("c1")
        self.assertAlmostEqual(belief.probability, 0.5, places=1)

    def test_truth_context_output(self):
        """get_truth_context returns a formatted string."""
        truth = TruthLayerDB(self.db)
        truth.add_claim("c1", "High confidence claim")
        truth.update_belief("c1", True, 100.0)
        truth.add_claim("c2", "Low confidence claim")
        truth.update_belief("c2", False, 100.0)

        context = truth.get_truth_context()
        self.assertIn("TRUTH LAYER", context)
        self.assertIn("High confidence claim", context)
        self.assertIn("Low confidence claim", context)


if __name__ == "__main__":
    unittest.main()
