"""Comprehensive tests for touchgrass plugin — all layers."""
from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

# Ensure touchgrass_lib is importable
sys.path.insert(0, str(Path(__file__).parent.parent))

from touchgrass_lib.init_db import init_db, is_initialized
from touchgrass_lib.db import TouchgrassDB
from touchgrass_lib.engines.models import (
    MoodState, EmotionalQuadrant, AuthorityTier, EngineOpinion,
    ComplianceProfile, RewardProfile, RewardType, EncodingWeight,
    TopicGap, GapAnalysis, HoldRequest, EmotionalMemory,
)
from touchgrass_lib.engines.engines import MoodDetector, BeliefExtractor, compute_encoding_weight
from touchgrass_lib.engines.engines_db import (
    AuthorityGraphDB, ComplianceDetectorDB, RewardModelDB,
    ApproachAvoidanceDetectorDB, GapAnalyzerDB, TruthLayerDB,
    PersonaEngineDB, GovernanceLayerDB,
)
from touchgrass_lib.engines.belief import (
    Uncertainty, cumulative_fuse, trust_discount, probability_to_opinion,
    decompose_from_beta, TruthLayer, Belief,
)
from touchgrass_lib.voice.analyzer import VoiceFeatures
from touchgrass_lib.voice.calibrator import VoiceCalibrator, CALIBRATION_STATES
from touchgrass_lib.voice.state import VoiceState, VoiceStateDetector
from touchgrass_lib.briefing.engine import BriefingEngine, Briefing, BriefingItem
from touchgrass_lib.ingest.email import classify_priority
from touchgrass_lib.ingest.scheduler import should_ingest


class TestBase(unittest.TestCase):
    """Base with temp DB setup/teardown."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmp, "test.db")
        init_db(self.db_path)
        self.db = TouchgrassDB(self.db_path)

    def tearDown(self):
        self.db.close()
        shutil.rmtree(self.tmp)


# =============================================================================
# DATABASE TESTS
# =============================================================================

class TestDatabase(TestBase):
    def test_init_creates_tables(self):
        self.assertTrue(is_initialized(self.db_path))

    def test_session_lifecycle(self):
        self.db.start_session("s1")
        self.db.increment_interaction("s1")
        self.db.increment_interaction("s1")
        self.db.end_session("s1")
        row = self.db.fetchone("SELECT * FROM sessions WHERE session_id = 's1'")
        self.assertEqual(row["interaction_count"], 2)
        self.assertIsNotNone(row["ended_at"])

    def test_mood_recording(self):
        self.db.start_session("s1")
        mid = self.db.record_mood("s1", 0.5, 0.3, "excited", 0.58, 0.7, ["v_excitement"])
        self.assertIsNotNone(mid)
        history = self.db.get_mood_history(5)
        self.assertEqual(len(history), 1)
        self.assertEqual(history[0]["quadrant"], "excited")

    def test_memory_store_and_search(self):
        self.db.store_memory("m1", "Project deadline moved to Friday",
                             topic_tags=["project", "deadline"])
        self.db.store_memory("m2", "Had a great lunch with the team",
                             topic_tags=["social"])
        results = self.db.search_memories("deadline")
        self.assertEqual(len(results), 1)
        self.assertIn("Friday", results[0]["content"])

    def test_hold_lifecycle(self):
        self.db.create_hold("h1", "store_memory", "m1", "High encoding weight")
        holds = self.db.get_pending_holds()
        self.assertEqual(len(holds), 1)
        self.db.resolve_hold("h1", "approved", "Verified by user")
        holds = self.db.get_pending_holds()
        self.assertEqual(len(holds), 0)

    def test_audit_log(self):
        self.db.audit("test_event", "target1", {"key": "value"}, "s1")
        log = self.db.get_audit_log(10)
        self.assertEqual(len(log), 1)
        self.assertEqual(log[0]["event_type"], "test_event")

    def test_pattern_upsert(self):
        self.db.upsert_pattern("time", "Energy drops after 3PM", 0.7, 5, 0.65)
        self.db.upsert_pattern("time", "Energy drops after 3PM", 0.75, 8, 0.72)
        patterns = self.db.get_active_patterns(3)
        self.assertEqual(len(patterns), 1)
        self.assertEqual(patterns[0]["observations"], 8)

    def test_email_upsert(self):
        self.db.upsert_email("msg1", "boss@co.com", "Boss", "URGENT: Review",
                             "Please review ASAP", "urgent", 1.0, ["INBOX"], "2026-02-09")
        emails = self.db.get_unbriefed_emails()
        self.assertEqual(len(emails), 1)
        self.assertEqual(emails[0]["priority"], "urgent")

    def test_calendar_events(self):
        self.db.upsert_calendar_event("ev1", "Team Standup",
                                       "2099-01-01T09:00:00", "2099-01-01T09:30:00",
                                       attendees=["alice", "bob"])
        events = self.db.get_upcoming_events(876000)  # far future
        self.assertEqual(len(events), 1)

    def test_weather_snapshot(self):
        self.db.store_weather(72.5, "partly cloudy", 10.0, 5.0, "", "2026-02-09")
        w = self.db.get_latest_weather()
        self.assertAlmostEqual(w["temp_f"], 72.5)

    def test_voice_calibration(self):
        cal_id = self.db.store_calibration("calm", 150.0, 10.0, 120.0, -20.0, 0.2, 2000.0)
        cals = self.db.get_calibration()
        self.assertEqual(len(cals), 1)
        self.assertEqual(cals[0]["label"], "calm")

    def test_voice_state_storage(self):
        self.db.start_session("s1")
        vs_id = self.db.store_voice_state("s1", 150.0, 10.0, 120.0, -20.0,
                                           0.2, 2000.0, "calm", 0.85, "hello")
        latest = self.db.get_latest_voice_state("s1")
        self.assertEqual(latest["detected_state"], "calm")


# =============================================================================
# MOOD DETECTOR TESTS
# =============================================================================

class TestMoodDetector(TestBase):
    def setUp(self):
        super().setUp()
        self.detector = MoodDetector()

    def test_positive_mood(self):
        mood = self.detector.detect("This is awesome! I love it!")
        self.assertGreater(mood.valence, 0)
        self.assertEqual(mood.quadrant, EmotionalQuadrant.EXCITED)

    def test_negative_mood(self):
        mood = self.detector.detect("I'm so frustrated with this shit")
        self.assertLess(mood.valence, 0)

    def test_neutral_mood(self):
        mood = self.detector.detect("Please send the report")
        self.assertEqual(mood.quadrant, EmotionalQuadrant.NEUTRAL)

    def test_stressed_mood(self):
        mood = self.detector.detect("URGENT!! Everything is on fire HELP")
        self.assertGreater(mood.arousal, 0)
        self.assertIn(mood.quadrant, [EmotionalQuadrant.STRESSED, EmotionalQuadrant.EXCITED])


# =============================================================================
# BELIEF MATH TESTS
# =============================================================================

class TestBeliefMath(unittest.TestCase):
    def test_uncertainty_creation(self):
        u = Uncertainty(belief=0.6, disbelief=0.2, uncertainty=0.2)
        self.assertAlmostEqual(u.belief + u.disbelief + u.uncertainty, 1.0)

    def test_uncertainty_validation(self):
        with self.assertRaises(ValueError):
            Uncertainty(belief=0.5, disbelief=0.5, uncertainty=0.5)

    def test_cumulative_fusion(self):
        o1 = Uncertainty(belief=0.7, disbelief=0.1, uncertainty=0.2)
        o2 = Uncertainty(belief=0.6, disbelief=0.2, uncertainty=0.2)
        fused = cumulative_fuse([o1, o2])
        self.assertLess(fused.uncertainty, max(o1.uncertainty, o2.uncertainty))

    def test_trust_discount(self):
        trustor = Uncertainty(belief=0.8, disbelief=0.1, uncertainty=0.1)
        opinion = Uncertainty(belief=0.9, disbelief=0.05, uncertainty=0.05)
        discounted = trust_discount(trustor, opinion)
        self.assertLessEqual(discounted.belief, opinion.belief)

    def test_probability_roundtrip(self):
        original = 0.75
        opinion = probability_to_opinion(original, uncertainty_level=0.2)
        self.assertAlmostEqual(opinion.belief + opinion.disbelief + opinion.uncertainty, 1.0)

    def test_decomposition(self):
        decomp = decompose_from_beta(10.0, 3.0)
        self.assertGreater(decomp.mean, 0.5)
        self.assertGreater(decomp.total_variance, 0)


# =============================================================================
# SQLITE-BACKED ENGINE TESTS
# =============================================================================

class TestAuthorityGraphDB(TestBase):
    def test_add_and_get(self):
        auth = AuthorityGraphDB(self.db)
        auth.add_source("boss", "My Boss", AuthorityTier.INSTITUTIONAL, 0.8, ["work"])
        source = auth.get_source("boss")
        self.assertEqual(source.name, "My Boss")
        self.assertAlmostEqual(source.trust_weight, 0.8)

    def test_relevant_sources(self):
        auth = AuthorityGraphDB(self.db)
        auth.add_source("boss", "Boss", AuthorityTier.INSTITUTIONAL, 0.8, ["work"])
        auth.add_source("mentor", "Mentor", AuthorityTier.PERSONAL, 0.7, [])
        relevant = auth.get_relevant_sources("work")
        names = [s.name for s in relevant]
        self.assertIn("Boss", names)
        self.assertIn("Mentor", names)  # empty topics = relevant to all

    def test_discount_opinion(self):
        auth = AuthorityGraphDB(self.db)
        auth.add_source("boss", "Boss", AuthorityTier.INSTITUTIONAL, 0.8)
        result = auth.discount_opinion("boss")
        self.assertIsNotNone(result)
        self.assertLessEqual(result.belief, 1.0)


class TestComplianceDetectorDB(TestBase):
    def test_compliance_signals(self):
        comp = ComplianceDetectorDB(self.db)
        profile = comp.analyze("I should do this right away, understood!")
        self.assertGreater(profile.compliance_score, 0.5)

    def test_defiance_signals(self):
        comp = ComplianceDetectorDB(self.db)
        comp.analyze("whatever, I'll do it my way, pointless bureaucracy")
        self.assertLess(comp.profile.compliance_score, 0.7)


class TestRewardModelDB(TestBase):
    def test_observe_and_scores(self):
        reward = RewardModelDB(self.db)
        for _ in range(6):
            reward.observe("completion", 0.5)
        scores = reward.get_scores()
        self.assertGreater(scores["achievement"], 0)
        self.assertEqual(scores["observations"], 6)


class TestApproachAvoidanceDB(TestBase):
    def test_approach_detection(self):
        aa = ApproachAvoidanceDetectorDB(self.db)
        mood = MoodState(valence=0.5, arousal=0.3, confidence=0.7,
                         quadrant=EmotionalQuadrant.EXCITED, signals=[])
        result = aa.analyze("I want to explore this more! Tell me how exactly it works!", "project", mood)
        self.assertGreater(result.approach_count, 0)

    def test_avoidance_detection(self):
        aa = ApproachAvoidanceDetectorDB(self.db)
        mood = MoodState(valence=-0.2, arousal=-0.1, confidence=0.5,
                         quadrant=EmotionalQuadrant.LOW, signals=[])
        result = aa.analyze("whatever, maybe later", "chore", mood)
        self.assertGreater(result.avoidance_count, 0)


class TestGapAnalyzerDB(TestBase):
    def test_gap_detection(self):
        gap = GapAnalyzerDB(self.db)
        persona = {"work": EngineOpinion(topic="work", belief=0.8, disbelief=0.1,
                                          uncertainty=0.1, source_signals=["auth"])}
        reward = {"work": EngineOpinion(topic="work", belief=0.3, disbelief=0.3,
                                         uncertainty=0.4, source_signals=["reward"])}
        analysis = gap.analyze(persona, reward, "test")
        self.assertGreater(analysis.overall_divergence, 0)
        self.assertEqual(len(analysis.topic_gaps), 1)


class TestTruthLayerDB(TestBase):
    def test_add_and_query(self):
        truth = TruthLayerDB(self.db)
        truth.add_claim("test_claim", "Testing is important", "general")
        belief = truth.get_belief("test_claim")
        self.assertIsNotNone(belief)
        self.assertAlmostEqual(belief.probability, 0.5)

    def test_confirm_increases_probability(self):
        truth = TruthLayerDB(self.db)
        truth.add_claim("test_claim", "Testing is important")
        truth.validate("test_claim", "confirm")
        belief = truth.get_belief("test_claim")
        self.assertGreater(belief.probability, 0.5)

    def test_reject_decreases_probability(self):
        truth = TruthLayerDB(self.db)
        truth.add_claim("test_claim", "Bad assumption")
        truth.validate("test_claim", "reject")
        belief = truth.get_belief("test_claim")
        self.assertLess(belief.probability, 0.5)


class TestGovernanceDB(TestBase):
    def test_high_encoding_held(self):
        gov = GovernanceLayerDB(self.db)
        result = gov.gate_memory_write("m1", 1.5, 0.2, "unverified", 0)
        self.assertEqual(result, "held")
        holds = gov.pending_holds()
        self.assertEqual(len(holds), 1)

    def test_normal_memory_allowed(self):
        gov = GovernanceLayerDB(self.db)
        result = gov.gate_memory_write("m2", 0.5, 0.2, "unverified", 0)
        self.assertEqual(result, "allowed")

    def test_high_conflict_held(self):
        gov = GovernanceLayerDB(self.db)
        result = gov.gate_memory_write("m3", 0.5, 0.7, "unverified", 0)
        self.assertEqual(result, "held")

    def test_resolve_hold(self):
        gov = GovernanceLayerDB(self.db)
        gov.gate_memory_write("m1", 1.5, 0.2, "unverified", 0)
        holds = gov.pending_holds()
        hold_id = holds[0]["hold_id"]
        success = gov.resolve_hold(hold_id, "approve", "Looks good")
        self.assertTrue(success)
        self.assertEqual(len(gov.pending_holds()), 0)


class TestPersonaEngineDB(TestBase):
    def test_process_returns_opinions(self):
        truth = TruthLayerDB(self.db)
        authority = AuthorityGraphDB(self.db)
        compliance = ComplianceDetectorDB(self.db)
        persona = PersonaEngineDB(truth, authority, compliance)

        mood = MoodState(valence=0.3, arousal=0.2, confidence=0.6,
                         quadrant=EmotionalQuadrant.CALM, signals=[])
        opinions = persona.process("I should focus on the project", mood, ["project"])
        self.assertIn("project", opinions)
        self.assertAlmostEqual(
            opinions["project"].belief + opinions["project"].disbelief + opinions["project"].uncertainty,
            1.0, places=2,
        )


# =============================================================================
# VOICE PIPELINE TESTS
# =============================================================================

class TestVoiceCalibrator(TestBase):
    def _add_calibration(self):
        cal = VoiceCalibrator(self.db)
        states = {
            "calm": VoiceFeatures(150, 10, 120, -20, 0.2, 2000),
            "excited": VoiceFeatures(200, 25, 160, -15, 0.1, 2800),
            "frustrated": VoiceFeatures(180, 30, 140, -12, 0.15, 2600),
            "pressured": VoiceFeatures(190, 20, 170, -14, 0.08, 2500),
            "reflective": VoiceFeatures(130, 8, 100, -25, 0.3, 1800),
        }
        for label, features in states.items():
            cal.add_calibration_point(label, features)
        return cal

    def test_sufficient_calibration(self):
        cal = self._add_calibration()
        profile = cal.get_profile()
        self.assertTrue(profile.is_sufficient)
        self.assertEqual(profile.calibration_points, 5)

    def test_classify_calm(self):
        cal = self._add_calibration()
        label, conf = cal.classify_state(
            VoiceFeatures(148, 11, 118, -21, 0.22, 2050),
        )
        self.assertEqual(label, "calm")
        self.assertGreater(conf, 0.8)

    def test_classify_excited(self):
        cal = self._add_calibration()
        label, conf = cal.classify_state(
            VoiceFeatures(198, 24, 158, -16, 0.11, 2780),
        )
        self.assertEqual(label, "excited")

    def test_missing_states(self):
        cal = self._add_calibration()
        missing = cal.get_missing_states()
        self.assertIn("problem_solving", missing)
        self.assertNotIn("calm", missing)


class TestVoiceState(unittest.TestCase):
    def test_briefing_mode_stressed(self):
        vs = VoiceState("frustrated", 0.8, calibrated=True)
        self.assertEqual(vs.briefing_mode, "minimal")

    def test_briefing_mode_energized(self):
        vs = VoiceState("excited", 0.8, calibrated=True)
        self.assertEqual(vs.briefing_mode, "full_pushback")

    def test_briefing_mode_uncalibrated(self):
        vs = VoiceState("calm", 0.8, calibrated=False)
        self.assertEqual(vs.briefing_mode, "standard")


# =============================================================================
# BRIEFING ENGINE TESTS
# =============================================================================

class TestBriefingEngine(TestBase):
    def test_empty_briefing(self):
        engine = BriefingEngine(self.db)
        briefing = engine.assemble()
        self.assertTrue(briefing.nothing_urgent)
        self.assertIn("Go touch grass", briefing.format())

    def test_briefing_with_items(self):
        # Add a pending item
        self.db.execute(
            "INSERT INTO pending_items (source, summary, priority) VALUES (?, ?, ?)",
            ("email", "URGENT: Server down", 1.0),
        )
        self.db.commit()
        engine = BriefingEngine(self.db)
        briefing = engine.assemble()
        self.assertFalse(briefing.nothing_urgent)
        self.assertIn("Server down", briefing.now.summary)

    def test_minimal_adaptation(self):
        self.db.execute(
            "INSERT INTO pending_items (source, summary, priority) VALUES (?, ?, ?)",
            ("email", "Budget review needed", 0.7),
        )
        self.db.commit()
        vs = VoiceState("frustrated", 0.8, calibrated=True)
        engine = BriefingEngine(self.db)
        briefing = engine.assemble(voice_state=vs)
        self.assertEqual(briefing.adaptation, "minimal")
        self.assertIn("handled", briefing.format())


# =============================================================================
# INGESTION TESTS
# =============================================================================

class TestEmailClassification(unittest.TestCase):
    def test_urgent(self):
        priority, score = classify_priority("URGENT: Fix now", "Server crash", ["IMPORTANT"])
        self.assertEqual(priority, "urgent")
        self.assertEqual(score, 1.0)

    def test_needs_reply(self):
        priority, _ = classify_priority("Question", "Please respond by EOD", [])
        self.assertEqual(priority, "needs_reply")

    def test_noise(self):
        priority, _ = classify_priority("Sale!", "50% off", ["CATEGORY_PROMOTIONS"])
        self.assertEqual(priority, "noise")

    def test_fyi(self):
        priority, _ = classify_priority("Meeting notes", "Here are the notes", [])
        self.assertEqual(priority, "fyi")


class TestScheduler(unittest.TestCase):
    def test_first_ingest_always_runs(self):
        self.assertTrue(should_ingest("email"))
        self.assertTrue(should_ingest("calendar"))
        self.assertTrue(should_ingest("weather"))


# =============================================================================
# MCP SERVER TESTS
# =============================================================================

class TestMCPServer(TestBase):
    def test_tool_definitions(self):
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from server import TOOLS, HANDLERS
        self.assertEqual(len(TOOLS), 22)
        self.assertEqual(len(HANDLERS), 22)
        # Every tool has a handler
        for tool in TOOLS:
            self.assertIn(tool["name"], HANDLERS, f"Missing handler for {tool['name']}")

    def test_initialize(self):
        from server import handle_request
        resp = handle_request({"jsonrpc": "2.0", "id": 1, "method": "initialize"})
        self.assertEqual(resp["result"]["serverInfo"]["name"], "touchgrass")

    def test_tools_list(self):
        from server import handle_request
        resp = handle_request({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
        self.assertEqual(len(resp["result"]["tools"]), 22)


# =============================================================================
# INTEGRATION TESTS
# =============================================================================

class TestIntegration(TestBase):
    def test_full_analysis_pipeline(self):
        """Test the full pipeline: mood -> persona -> reward -> gap -> governance."""
        self.db.start_session("s1")
        # 1. Detect mood
        detector = MoodDetector()
        mood = detector.detect("I'm really excited about shipping this project!")
        self.assertGreater(mood.valence, 0)

        # 2. Record mood
        self.db.record_mood("s1", mood.valence, mood.arousal,
                           mood.quadrant.value, mood.intensity, mood.confidence, mood.signals)

        # 3. Run persona engine
        truth = TruthLayerDB(self.db)
        authority = AuthorityGraphDB(self.db)
        compliance = ComplianceDetectorDB(self.db)
        persona = PersonaEngineDB(truth, authority, compliance)
        persona_opinions = persona.process(
            "I should ship the project", mood, ["project"], "s1",
        )

        # 4. Build reward opinions
        aa = ApproachAvoidanceDetectorDB(self.db)
        reward = RewardModelDB(self.db)
        aa_data = aa.analyze("I'm excited about shipping!", "project", mood)
        reward.observe("completion", mood.valence)

        reward_opinions = {
            "project": EngineOpinion(
                topic="project", belief=0.5, disbelief=0.2,
                uncertainty=0.3, source_signals=["approach"],
            ),
        }

        # 5. Gap analysis
        gap = GapAnalyzerDB(self.db)
        analysis = gap.analyze(persona_opinions, reward_opinions, "s1")
        self.assertIsNotNone(analysis)

        # 6. Store memory with governance
        gov = GovernanceLayerDB(self.db)
        gate = gov.gate_memory_write("m1", 0.6, 0.1, "unverified", 0, "s1")
        self.assertEqual(gate, "allowed")
        self.db.store_memory("m1", "Excited about shipping the project",
                             "s1", topic_tags=["project"])

        # 7. Search memory
        results = self.db.search_memories("shipping")
        self.assertEqual(len(results), 1)

        # 8. Check audit trail
        log = self.db.get_audit_log()
        self.assertGreater(len(log), 0)


# =============================================================================
# NEW TESTS — Fix validation
# =============================================================================

class TestFTS5Sanitization(TestBase):
    def test_empty_query_returns_empty(self):
        self.db.store_memory("m1", "Hello world", topic_tags=["test"])
        results = self.db.search_memories("")
        self.assertEqual(results, [])

    def test_whitespace_query_returns_empty(self):
        self.db.store_memory("m1", "Hello world", topic_tags=["test"])
        results = self.db.search_memories("   ")
        self.assertEqual(results, [])

    def test_special_chars_query(self):
        self.db.store_memory("m1", "Project deadline Friday", topic_tags=["work"])
        # These should not crash — FTS5 operators stripped
        results = self.db.search_memories('"deadline"')
        self.assertGreaterEqual(len(results), 0)  # may or may not match after stripping
        results = self.db.search_memories("deadline AND Friday")
        self.assertGreaterEqual(len(results), 0)
        results = self.db.search_memories("(test*)")
        self.assertGreaterEqual(len(results), 0)

    def test_normal_query_still_works(self):
        self.db.store_memory("m1", "Project deadline Friday", topic_tags=["work"])
        results = self.db.search_memories("deadline")
        self.assertEqual(len(results), 1)


class TestGetStatusTool(TestBase):
    def test_empty_db_returns_counts(self):
        from server import handle_get_status
        import server
        old_db = server._db
        server._db = self.db
        server._session_id = "test_s"
        self.db.start_session("test_s")
        try:
            result = handle_get_status({})
            self.assertIn("counts", result)
            self.assertIn("guidance", result)
            self.assertEqual(result["counts"]["memories"], 0)
            self.assertGreater(len(result["guidance"]), 0)
        finally:
            server._db = old_db
            server._session_id = ""

    def test_populated_db_returns_counts(self):
        from server import handle_get_status
        import server
        old_db = server._db
        server._db = self.db
        server._session_id = "test_s"
        self.db.start_session("test_s")
        self.db.store_memory("m1", "Test memory", "test_s", topic_tags=["work"])
        self.db.upsert_belief("b1", "Testing matters", "general", 5.0, 2.0)
        try:
            result = handle_get_status({})
            self.assertEqual(result["counts"]["memories"], 1)
            self.assertEqual(result["counts"]["beliefs"], 1)
        finally:
            server._db = old_db
            server._session_id = ""


class TestStoreMemoryMoodWiring(TestBase):
    def test_store_memory_captures_mood_state(self):
        import server
        old_db, old_session = server._db, server._session_id
        old_mood, old_gap = server._last_mood, server._last_gap
        server._db = self.db
        server._session_id = "test_s"
        self.db.start_session("test_s")
        server._last_mood = {"valence": 0.7, "arousal": 0.5, "quadrant": "excited", "intensity": 0.86}
        server._last_gap = {"conflict_score": 0.2, "persona_opinion": 0.8,
                            "reward_opinion": 0.6, "gap_magnitude": 0.2, "gap_direction": "persona_leads"}
        try:
            from server import handle_store_emotional_memory
            result = handle_store_emotional_memory({"content": "Shipped the feature today!"})
            self.assertEqual(result["status"], "stored")
            memory = self.db.get_memory(result["memory_id"])
            self.assertAlmostEqual(memory["valence"], 0.7)
            self.assertAlmostEqual(memory["arousal"], 0.5)
            self.assertEqual(memory["quadrant"], "excited")
            self.assertAlmostEqual(memory["conflict_score"], 0.2)
            self.assertAlmostEqual(memory["persona_opinion"], 0.8)
        finally:
            server._db = old_db
            server._session_id = old_session
            server._last_mood = old_mood
            server._last_gap = old_gap


class TestGovernanceGateConflict(TestBase):
    def test_high_conflict_from_gap_triggers_hold(self):
        """Verify governance gate fires on actual conflict_score from gap cache."""
        import server
        old_db, old_session = server._db, server._session_id
        old_mood, old_gap = server._last_mood, server._last_gap
        server._db = self.db
        server._session_id = "test_s"
        self.db.start_session("test_s")
        # Simulate a high-conflict gap state
        server._last_mood = {"valence": -0.5, "arousal": 0.6, "quadrant": "stressed", "intensity": 0.78}
        server._last_gap = {"conflict_score": 0.8, "persona_opinion": 0.9,
                            "reward_opinion": 0.1, "gap_magnitude": 0.8, "gap_direction": "persona_leads"}
        try:
            from server import handle_store_emotional_memory
            result = handle_store_emotional_memory({"content": "Conflicted about this decision"})
            self.assertEqual(result["status"], "held")
            self.assertEqual(result["gate"], "held")
        finally:
            server._db = old_db
            server._session_id = old_session
            server._last_mood = old_mood
            server._last_gap = old_gap


class TestFacadeToolsNotConfigured(TestBase):
    def test_email_summary_not_configured(self):
        from server import handle_get_email_summary
        import server
        old_db = server._db
        server._db = self.db
        try:
            result = handle_get_email_summary({})
            self.assertEqual(result["status"], "not_configured")
        finally:
            server._db = old_db

    def test_calendar_not_configured(self):
        from server import handle_get_calendar_context
        import server
        old_db = server._db
        server._db = self.db
        try:
            result = handle_get_calendar_context({})
            self.assertEqual(result["status"], "not_configured")
        finally:
            server._db = old_db

    def test_ambient_not_configured(self):
        from server import handle_get_ambient_context
        import server
        old_db = server._db
        server._db = self.db
        try:
            result = handle_get_ambient_context({})
            self.assertEqual(result["status"], "not_configured")
        finally:
            server._db = old_db

    def test_patterns_not_configured(self):
        from server import handle_get_patterns
        import server
        old_db = server._db
        server._db = self.db
        try:
            result = handle_get_patterns({})
            self.assertEqual(result["status"], "not_configured")
        finally:
            server._db = old_db

    def test_pending_briefing_not_configured(self):
        from server import handle_get_pending_briefing
        import server
        old_db = server._db
        server._db = self.db
        try:
            result = handle_get_pending_briefing({})
            self.assertEqual(result["status"], "not_configured")
        finally:
            server._db = old_db

    def test_mark_briefed_not_configured(self):
        from server import handle_mark_briefed
        import server
        old_db = server._db
        server._db = self.db
        try:
            result = handle_mark_briefed({"item_ids": [1, 2]})
            self.assertEqual(result["status"], "not_configured")
        finally:
            server._db = old_db


if __name__ == "__main__":
    unittest.main()
