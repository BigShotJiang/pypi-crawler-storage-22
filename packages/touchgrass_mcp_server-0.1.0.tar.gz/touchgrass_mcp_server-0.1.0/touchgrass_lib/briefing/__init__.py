"""Briefing engine: NOW / SINCE LAST / NEXT assembly with voice adaptation."""
from .engine import BriefingEngine, Briefing, BriefingItem
