"""Briefing engine — assembles NOW / SINCE LAST / NEXT, adapted by voice state."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from ..db import TouchgrassDB
from ..voice.state import VoiceState


@dataclass
class BriefingItem:
    source: str  # email, calendar, weather, pattern, gap
    summary: str
    priority: float = 0.0
    item_id: Optional[int] = None


@dataclass
class Briefing:
    now: Optional[BriefingItem] = None
    since_last: List[BriefingItem] = field(default_factory=list)
    next_actions: List[BriefingItem] = field(default_factory=list)
    voice_state: str = "unknown"
    adaptation: str = "standard"
    nothing_urgent: bool = False

    def format(self) -> str:
        """Format briefing for delivery."""
        parts = []

        if self.nothing_urgent:
            return "Nothing needs you right now. Go touch grass."

        if self.now:
            parts.append(f"**NOW** — {self.now.summary}")

        if self.adaptation != "minimal" and self.since_last:
            parts.append("\n**SINCE LAST**")
            for item in self.since_last[:3]:
                parts.append(f"- {item.summary}")

        if self.adaptation != "minimal" and self.next_actions:
            parts.append("\n**NEXT**")
            for item in self.next_actions[:3]:
                parts.append(f"- {item.summary}")

        if self.adaptation == "minimal":
            parts.append("\nEverything else is handled.")

        return "\n".join(parts)

    def to_dict(self) -> dict:
        return {
            "now": {"source": self.now.source, "summary": self.now.summary} if self.now else None,
            "since_last": [{"source": i.source, "summary": i.summary} for i in self.since_last],
            "next_actions": [{"source": i.source, "summary": i.summary} for i in self.next_actions],
            "voice_state": self.voice_state,
            "adaptation": self.adaptation,
            "nothing_urgent": self.nothing_urgent,
        }


class BriefingEngine:
    """Assembles briefings from pending items, emails, calendar, and context."""

    def __init__(self, db: TouchgrassDB):
        self.db = db

    def assemble(self, voice_state: Optional[VoiceState] = None,
                 session_id: str = "") -> Briefing:
        """Assemble a briefing adapted to voice state."""
        # Determine adaptation mode
        if voice_state and voice_state.calibrated:
            adaptation = voice_state.briefing_mode
            state_label = voice_state.detected_state
        else:
            adaptation = "standard"
            state_label = "unknown"

        briefing = Briefing(voice_state=state_label, adaptation=adaptation)

        # Collect items from all sources
        items = []

        # Pending items
        pending = self.db.get_pending_items()
        for p in pending:
            items.append(BriefingItem(
                source=p.get("source", "unknown"),
                summary=p.get("summary", ""),
                priority=p.get("priority", 0),
                item_id=p.get("id"),
            ))

        # Unbriefed emails
        emails = self.db.get_unbriefed_emails()
        for e in emails:
            items.append(BriefingItem(
                source="email",
                summary=f"{e.get('sender_name', 'Unknown')}: {e.get('subject', 'No subject')}",
                priority=e.get("priority_score", 0),
            ))

        # Upcoming events
        events = self.db.get_upcoming_events(12)  # next 12 hours
        for ev in events:
            items.append(BriefingItem(
                source="calendar",
                summary=f"{ev.get('title', 'Event')} at {ev.get('start_time', '')}",
                priority=0.5,
            ))

        # Sort by priority
        items.sort(key=lambda x: x.priority, reverse=True)

        if not items:
            briefing.nothing_urgent = True
            return briefing

        # NOW = highest priority
        briefing.now = items[0]

        # SINCE LAST = next items (not calendar)
        briefing.since_last = [i for i in items[1:4] if i.source != "calendar"]

        # NEXT = calendar items + lower priority
        briefing.next_actions = [i for i in items if i.source == "calendar"][:3]

        # Store briefing record
        self.db.record_briefing(
            session_id=session_id,
            now_item=briefing.now.summary if briefing.now else "",
            since_last="; ".join(i.summary for i in briefing.since_last),
            next_actions="; ".join(i.summary for i in briefing.next_actions),
            voice_state=state_label,
            adaptation=adaptation,
        )

        return briefing
