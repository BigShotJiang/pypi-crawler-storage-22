"""touchgrass database access layer — thin wrapper over SQLite."""
from __future__ import annotations

import json
import re
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from .init_db import get_db_path, init_db


class TouchgrassDB:
    """Single connection wrapper. All engine classes share one instance."""

    def __init__(self, db_path: Union[str, Path, None] = None):
        if db_path is None:
            db_path = get_db_path()
        self._path = Path(db_path)
        self._conn: Optional[sqlite3.Connection] = None

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            if not self._path.exists():
                self._conn = init_db(self._path)
            else:
                self._conn = sqlite3.connect(str(self._path))
                self._conn.execute("PRAGMA journal_mode=WAL")
                self._conn.execute("PRAGMA foreign_keys=ON")
            self._conn.row_factory = sqlite3.Row
        return self._conn

    def execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        return self.conn.execute(sql, params)

    def executemany(self, sql: str, params_list: list) -> sqlite3.Cursor:
        return self.conn.executemany(sql, params_list)

    def commit(self) -> None:
        self.conn.commit()

    def fetchone(self, sql: str, params: tuple = ()) -> Optional[sqlite3.Row]:
        return self.conn.execute(sql, params).fetchone()

    def fetchall(self, sql: str, params: tuple = ()) -> List[sqlite3.Row]:
        return self.conn.execute(sql, params).fetchall()

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    # -- Session helpers --

    def start_session(self, session_id: str) -> None:
        self.execute(
            "INSERT OR IGNORE INTO sessions (session_id) VALUES (?)",
            (session_id,),
        )
        self.commit()

    def end_session(self, session_id: str) -> None:
        self.execute(
            "UPDATE sessions SET ended_at = datetime('now') WHERE session_id = ?",
            (session_id,),
        )
        self.commit()

    def increment_interaction(self, session_id: str) -> None:
        self.execute(
            "UPDATE sessions SET interaction_count = interaction_count + 1 WHERE session_id = ?",
            (session_id,),
        )
        self.commit()

    # -- Mood helpers --

    def record_mood(self, session_id: str, valence: float, arousal: float,
                    quadrant: str, intensity: float, confidence: float,
                    signals: List[str], voice_state_id: Optional[int] = None) -> int:
        cursor = self.execute(
            """INSERT INTO mood_readings
               (session_id, valence, arousal, quadrant, intensity, confidence, signals, voice_state_id)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (session_id, valence, arousal, quadrant, intensity, confidence,
             json.dumps(signals), voice_state_id),
        )
        self.commit()
        return cursor.lastrowid

    def get_mood_history(self, limit: int = 20) -> List[dict]:
        rows = self.fetchall(
            "SELECT * FROM mood_readings ORDER BY created_at DESC LIMIT ?",
            (limit,),
        )
        return [dict(r) for r in rows]

    # -- Authority helpers --

    def upsert_authority(self, source_id: str, name: str, tier: str,
                         trust_weight: float, influence_topics: List[str]) -> None:
        self.execute(
            """INSERT INTO authority_sources (source_id, name, tier, trust_weight, influence_topics)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(source_id) DO UPDATE SET
                 name=excluded.name, tier=excluded.tier,
                 trust_weight=excluded.trust_weight,
                 influence_topics=excluded.influence_topics""",
            (source_id, name, tier, trust_weight, json.dumps(influence_topics)),
        )
        self.commit()

    def get_authority(self, source_id: str) -> Optional[dict]:
        row = self.fetchone(
            "SELECT * FROM authority_sources WHERE source_id = ?", (source_id,),
        )
        return dict(row) if row else None

    def get_all_authorities(self) -> List[dict]:
        rows = self.fetchall("SELECT * FROM authority_sources")
        return [dict(r) for r in rows]

    def reference_authority(self, source_id: str) -> None:
        self.execute(
            """UPDATE authority_sources
               SET reference_count = reference_count + 1,
                   last_referenced = datetime('now')
               WHERE source_id = ?""",
            (source_id,),
        )
        self.commit()

    # -- Compliance helpers --

    def log_compliance_signal(self, signal: str, session_id: str = "") -> None:
        self.execute(
            "INSERT INTO compliance_log (signal, session_id) VALUES (?, ?)",
            (signal, session_id),
        )
        self.commit()

    def get_compliance_profile(self) -> dict:
        row = self.fetchone("SELECT * FROM compliance_profile WHERE id = 1")
        return dict(row) if row else {"id": 1, "alpha": 3.0, "beta": 2.0}

    def update_compliance_profile(self, alpha: float, beta: float) -> None:
        self.execute(
            "UPDATE compliance_profile SET alpha = ?, beta = ? WHERE id = 1",
            (alpha, beta),
        )
        self.commit()

    # -- Reward helpers --

    def get_reward_profile(self) -> dict:
        row = self.fetchone("SELECT * FROM reward_profile WHERE id = 1")
        return dict(row) if row else {
            "id": 1, "social_score": 0.0, "achievement_score": 0.0,
            "autonomy_score": 0.0, "security_score": 0.0,
            "dominant_type": "unknown", "observations": 0,
        }

    def update_reward_profile(self, social: float, achievement: float,
                               autonomy: float, security: float,
                               dominant_type: str, observations: int) -> None:
        self.execute(
            """UPDATE reward_profile SET
               social_score=?, achievement_score=?, autonomy_score=?,
               security_score=?, dominant_type=?, observations=?
               WHERE id = 1""",
            (social, achievement, autonomy, security, dominant_type, observations),
        )
        self.commit()

    # -- Approach/Avoidance helpers --

    def upsert_approach_avoidance(self, topic: str, approach_count: int,
                                   avoidance_count: int, total_valence: float,
                                   total_arousal: float, observations: int) -> None:
        self.execute(
            """INSERT INTO approach_avoidance
               (topic, approach_count, avoidance_count, total_valence, total_arousal, observations)
               VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(topic) DO UPDATE SET
                 approach_count=excluded.approach_count,
                 avoidance_count=excluded.avoidance_count,
                 total_valence=excluded.total_valence,
                 total_arousal=excluded.total_arousal,
                 observations=excluded.observations""",
            (topic, approach_count, avoidance_count, total_valence, total_arousal, observations),
        )
        self.commit()

    def get_approach_avoidance(self, topic: str) -> Optional[dict]:
        row = self.fetchone(
            "SELECT * FROM approach_avoidance WHERE topic = ?", (topic,),
        )
        return dict(row) if row else None

    def get_all_approach_avoidance(self) -> List[dict]:
        rows = self.fetchall("SELECT * FROM approach_avoidance")
        return [dict(r) for r in rows]

    # -- Engine opinions + gap history --

    def record_opinion(self, session_id: str, topic: str, engine: str,
                       belief: float, disbelief: float, uncertainty: float,
                       signals: List[str]) -> None:
        self.execute(
            """INSERT INTO engine_opinions
               (session_id, topic, engine, belief, disbelief, uncertainty, signals)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (session_id, topic, engine, belief, disbelief, uncertainty, json.dumps(signals)),
        )
        self.commit()

    def record_gap(self, topic: str, persona_val: float, reward_val: float,
                   gap_magnitude: float, gap_direction: str, severity: str) -> None:
        self.execute(
            """INSERT INTO gap_history
               (topic, persona_val, reward_val, gap_magnitude, gap_direction, severity)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (topic, persona_val, reward_val, gap_magnitude, gap_direction, severity),
        )
        self.commit()

    def get_gap_history(self, topic: str, limit: int = 50) -> List[dict]:
        rows = self.fetchall(
            """SELECT * FROM gap_history WHERE topic = ?
               ORDER BY created_at DESC LIMIT ?""",
            (topic, limit),
        )
        return [dict(r) for r in rows]

    def get_all_gap_topics(self) -> List[str]:
        rows = self.fetchall("SELECT DISTINCT topic FROM gap_history")
        return [r["topic"] for r in rows]

    # -- Beliefs (TruthLayer) --

    def upsert_belief(self, belief_id: str, text: str, category: str,
                      alpha: float, beta: float, anchored: bool = False) -> None:
        self.execute(
            """INSERT INTO beliefs (belief_id, text, category, alpha, beta, anchored)
               VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(belief_id) DO UPDATE SET
                 text=excluded.text, category=excluded.category,
                 alpha=excluded.alpha, beta=excluded.beta,
                 anchored=excluded.anchored,
                 last_updated=datetime('now')""",
            (belief_id, text, category, alpha, beta, int(anchored)),
        )
        self.commit()

    def get_belief(self, belief_id: str) -> Optional[dict]:
        row = self.fetchone("SELECT * FROM beliefs WHERE belief_id = ?", (belief_id,))
        return dict(row) if row else None

    def get_all_beliefs(self) -> List[dict]:
        rows = self.fetchall("SELECT * FROM beliefs ORDER BY last_updated DESC")
        return [dict(r) for r in rows]

    def add_belief_evidence(self, belief_id: str, action: str, strength: float,
                            source: str = "", session_id: str = "") -> None:
        self.execute(
            """INSERT INTO belief_evidence (belief_id, action, strength, source, session_id)
               VALUES (?, ?, ?, ?, ?)""",
            (belief_id, action, strength, source, session_id),
        )
        self.commit()

    # -- Emotional memories (local FTS5) --

    def store_memory(self, memory_id: str, content: str, session_id: str = "",
                     trust_zone: str = "unverified", encoding_weight: float = 0.5,
                     conflict_score: float = 0.0, persona_opinion: float = 0.5,
                     reward_opinion: float = 0.5, gap_magnitude: float = 0.0,
                     gap_direction: str = "", valence: float = 0.0,
                     arousal: float = 0.0, quadrant: str = "neutral",
                     authority_source: str = "", topic_tags: List[str] = None,
                     related_ids: List[str] = None) -> None:
        tags = json.dumps(topic_tags or [])
        rels = json.dumps(related_ids or [])
        self.execute(
            """INSERT INTO emotional_memories
               (memory_id, content, session_id, trust_zone, encoding_weight,
                conflict_score, persona_opinion, reward_opinion, gap_magnitude,
                gap_direction, valence, arousal, quadrant, authority_source,
                topic_tags, related_ids)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (memory_id, content, session_id, trust_zone, encoding_weight,
             conflict_score, persona_opinion, reward_opinion, gap_magnitude,
             gap_direction, valence, arousal, quadrant, authority_source,
             tags, rels),
        )
        # Also insert into FTS5 index
        self.execute(
            "INSERT INTO memories_fts (content, topic_tags) VALUES (?, ?)",
            (content, " ".join(topic_tags or [])),
        )
        self.commit()

    @staticmethod
    def _sanitize_fts_query(query: str) -> str:
        """Strip FTS5 operators and special chars to prevent query syntax errors."""
        if not query or not query.strip():
            return ""
        # Remove FTS5 special characters
        sanitized = re.sub(r'["\(\)\*\^\{\}]', " ", query)
        # Remove FTS5 boolean operators as standalone words
        sanitized = re.sub(r'\b(AND|OR|NOT|NEAR)\b', " ", sanitized)
        # Collapse whitespace and strip
        sanitized = re.sub(r'\s+', " ", sanitized).strip()
        return sanitized

    def search_memories(self, query: str, limit: int = 10) -> List[dict]:
        sanitized = self._sanitize_fts_query(query)
        if not sanitized:
            return []
        rows = self.fetchall(
            """SELECT em.*, mf.rank
               FROM memories_fts mf
               JOIN emotional_memories em ON em.rowid = mf.rowid
               WHERE memories_fts MATCH ?
               ORDER BY mf.rank
               LIMIT ?""",
            (sanitized, limit),
        )
        return [dict(r) for r in rows]

    def get_memory(self, memory_id: str) -> Optional[dict]:
        row = self.fetchone(
            "SELECT * FROM emotional_memories WHERE memory_id = ?", (memory_id,),
        )
        return dict(row) if row else None

    def update_memory_trust(self, memory_id: str, trust_zone: str,
                            corroboration_count: int) -> None:
        self.execute(
            """UPDATE emotional_memories
               SET trust_zone = ?, corroboration_count = ?
               WHERE memory_id = ?""",
            (trust_zone, corroboration_count, memory_id),
        )
        self.commit()

    # -- Holds & Governance --

    def create_hold(self, hold_id: str, action: str, target_id: str,
                    reason: str) -> None:
        self.execute(
            """INSERT INTO holds (hold_id, action, target_id, reason)
               VALUES (?, ?, ?, ?)""",
            (hold_id, action, target_id, reason),
        )
        self.commit()

    def resolve_hold(self, hold_id: str, status: str, resolution_reason: str = "") -> None:
        self.execute(
            """UPDATE holds SET status = ?, resolution_reason = ?,
               resolved_at = datetime('now')
               WHERE hold_id = ?""",
            (status, resolution_reason, hold_id),
        )
        self.commit()

    def get_pending_holds(self) -> List[dict]:
        rows = self.fetchall(
            "SELECT * FROM holds WHERE status = 'pending' ORDER BY requested_at",
        )
        return [dict(r) for r in rows]

    def get_all_holds(self, include_resolved: bool = False) -> List[dict]:
        if include_resolved:
            rows = self.fetchall("SELECT * FROM holds ORDER BY requested_at DESC")
        else:
            rows = self.fetchall(
                "SELECT * FROM holds WHERE status = 'pending' ORDER BY requested_at",
            )
        return [dict(r) for r in rows]

    # -- Audit log --

    def audit(self, event_type: str, target_id: str, details: dict,
              session_id: str = "") -> None:
        self.execute(
            """INSERT INTO audit_log (event_type, target_id, details, session_id)
               VALUES (?, ?, ?, ?)""",
            (event_type, target_id, json.dumps(details), session_id),
        )
        self.commit()

    def get_audit_log(self, limit: int = 100) -> List[dict]:
        rows = self.fetchall(
            "SELECT * FROM audit_log ORDER BY created_at DESC LIMIT ?",
            (limit,),
        )
        return [dict(r) for r in rows]

    # -- Patterns --

    def upsert_pattern(self, pattern_type: str, description: str,
                       correlation: float, observations: int,
                       confidence: float) -> None:
        # Check if exists
        existing = self.fetchone(
            "SELECT id FROM patterns WHERE pattern_type = ? AND description = ?",
            (pattern_type, description),
        )
        if existing:
            self.execute(
                """UPDATE patterns SET correlation=?, observations=?,
                   confidence=?, last_seen=datetime('now')
                   WHERE id = ?""",
                (correlation, observations, confidence, existing["id"]),
            )
        else:
            self.execute(
                """INSERT INTO patterns
                   (pattern_type, description, correlation, observations, confidence)
                   VALUES (?, ?, ?, ?, ?)""",
                (pattern_type, description, correlation, observations, confidence),
            )
        self.commit()

    def get_active_patterns(self, min_observations: int = 3) -> List[dict]:
        rows = self.fetchall(
            """SELECT * FROM patterns
               WHERE active = 1 AND observations >= ?
               ORDER BY confidence DESC""",
            (min_observations,),
        )
        return [dict(r) for r in rows]

    # -- Briefing --

    def get_pending_items(self) -> List[dict]:
        rows = self.fetchall(
            "SELECT * FROM pending_items WHERE briefed = 0 ORDER BY priority DESC",
        )
        return [dict(r) for r in rows]

    def mark_briefed(self, item_ids: List[int]) -> None:
        if not item_ids:
            return
        placeholders = ",".join("?" * len(item_ids))
        self.execute(
            f"UPDATE pending_items SET briefed = 1, briefed_at = datetime('now') WHERE id IN ({placeholders})",
            tuple(item_ids),
        )
        self.commit()

    def record_briefing(self, session_id: str, now_item: str,
                        since_last: str, next_actions: str,
                        voice_state: str = "", adaptation: str = "") -> None:
        self.execute(
            """INSERT INTO briefing_history
               (session_id, now_item, since_last, next_actions, voice_state, adaptation)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (session_id, now_item, since_last, next_actions, voice_state, adaptation),
        )
        self.commit()

    # -- Voice --

    def store_calibration(self, label: str, pitch_mean: float, pitch_std: float,
                          pace_wpm: float, volume_db: float, pause_ratio: float,
                          spectral_centroid: float) -> int:
        cursor = self.execute(
            """INSERT INTO voice_calibration
               (label, pitch_mean, pitch_std, pace_wpm, volume_db, pause_ratio, spectral_centroid)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (label, pitch_mean, pitch_std, pace_wpm, volume_db, pause_ratio, spectral_centroid),
        )
        self.commit()
        return cursor.lastrowid

    def get_calibration(self) -> List[dict]:
        rows = self.fetchall(
            "SELECT * FROM voice_calibration ORDER BY created_at",
        )
        return [dict(r) for r in rows]

    def store_voice_state(self, session_id: str, pitch_mean: float,
                          pitch_std: float, pace_wpm: float, volume_db: float,
                          pause_ratio: float, spectral_centroid: float,
                          detected_state: str, confidence: float,
                          transcript: str = "") -> int:
        cursor = self.execute(
            """INSERT INTO voice_states
               (session_id, pitch_mean, pitch_std, pace_wpm, volume_db,
                pause_ratio, spectral_centroid, detected_state, confidence, transcript)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (session_id, pitch_mean, pitch_std, pace_wpm, volume_db,
             pause_ratio, spectral_centroid, detected_state, confidence, transcript),
        )
        self.commit()
        return cursor.lastrowid

    def get_latest_voice_state(self, session_id: str = "") -> Optional[dict]:
        if session_id:
            row = self.fetchone(
                "SELECT * FROM voice_states WHERE session_id = ? ORDER BY created_at DESC LIMIT 1",
                (session_id,),
            )
        else:
            row = self.fetchone(
                "SELECT * FROM voice_states ORDER BY created_at DESC LIMIT 1",
            )
        return dict(row) if row else None

    # -- Ingestion helpers --

    def upsert_email(self, message_id: str, sender: str, sender_name: str,
                     subject: str, snippet: str, priority: str,
                     priority_score: float, labels: List[str],
                     received_at: str) -> None:
        self.execute(
            """INSERT INTO email_items
               (message_id, sender, sender_name, subject, snippet,
                priority, priority_score, labels, received_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(message_id) DO UPDATE SET
                 priority=excluded.priority, priority_score=excluded.priority_score""",
            (message_id, sender, sender_name, subject, snippet,
             priority, priority_score, json.dumps(labels), received_at),
        )
        self.commit()

    def get_unbriefed_emails(self) -> List[dict]:
        rows = self.fetchall(
            "SELECT * FROM email_items WHERE briefed = 0 ORDER BY priority_score DESC",
        )
        return [dict(r) for r in rows]

    def upsert_calendar_event(self, event_id: str, title: str, start_time: str,
                               end_time: str, location: str = "",
                               attendees: List[str] = None,
                               prep_notes: str = "") -> None:
        self.execute(
            """INSERT INTO calendar_events
               (event_id, title, start_time, end_time, location, attendees, prep_notes)
               VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(event_id) DO UPDATE SET
                 title=excluded.title, start_time=excluded.start_time,
                 end_time=excluded.end_time, location=excluded.location""",
            (event_id, title, start_time, end_time, location,
             json.dumps(attendees or []), prep_notes),
        )
        self.commit()

    def get_upcoming_events(self, hours_ahead: int = 24) -> List[dict]:
        rows = self.fetchall(
            """SELECT * FROM calendar_events
               WHERE start_time >= datetime('now')
                 AND start_time <= datetime('now', ? || ' hours')
               ORDER BY start_time""",
            (str(hours_ahead),),
        )
        return [dict(r) for r in rows]

    def store_weather(self, temp_f: float, condition: str,
                      precipitation_pct: float, wind_mph: float,
                      advisory: str = "", forecast_date: str = "") -> None:
        self.execute(
            """INSERT INTO weather_snapshots
               (temp_f, condition, precipitation_pct, wind_mph, advisory, forecast_date)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (temp_f, condition, precipitation_pct, wind_mph, advisory, forecast_date),
        )
        self.commit()

    def get_latest_weather(self) -> Optional[dict]:
        row = self.fetchone(
            "SELECT * FROM weather_snapshots ORDER BY captured_at DESC LIMIT 1",
        )
        return dict(row) if row else None

    def get_status_counts(self) -> Dict[str, int]:
        """Get counts of key entities for the healthcheck tool."""
        tables = {
            "sessions": "sessions",
            "memories": "emotional_memories",
            "beliefs": "beliefs",
            "authorities": "authority_sources",
            "mood_readings": "mood_readings",
            "gap_entries": "gap_history",
            "holds": "holds",
            "calibration_points": "voice_calibration",
        }
        counts = {}  # type: Dict[str, int]
        for key, table in tables.items():
            row = self.fetchone(f"SELECT COUNT(*) as cnt FROM {table}")
            counts[key] = row["cnt"] if row else 0
        return counts
