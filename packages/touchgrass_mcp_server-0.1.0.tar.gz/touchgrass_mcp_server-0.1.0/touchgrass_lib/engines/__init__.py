"""touchgrass engine components — both original (JSON) and SQLite-backed."""
from .models import (
    MoodState, EmotionalQuadrant, AuthoritySource, AuthorityTier,
    ComplianceProfile, RewardProfile, RewardType, EncodingWeight,
    EngineOpinion, TopicGap, GapAnalysis, ApproachAvoidanceData,
    IntrospectiveNarration, EmotionalMemory, HoldRequest,
)
from .engines import (
    MoodDetector, BeliefExtractor, compute_encoding_weight,
    IntrospectiveLayer, TOPIC_TO_REWARD_MAP,
)
from .engines_db import (
    AuthorityGraphDB, ComplianceDetectorDB, RewardModelDB,
    ApproachAvoidanceDetectorDB, GapAnalyzerDB, TruthLayerDB,
    PersonaEngineDB, GovernanceLayerDB,
)
from .belief import (
    Uncertainty, TruthLayer, trust_discount, probability_to_opinion,
    cumulative_fuse, averaging_fuse, DecomposedUncertainty,
    decompose_from_beta, decompose_from_opinion,
)
