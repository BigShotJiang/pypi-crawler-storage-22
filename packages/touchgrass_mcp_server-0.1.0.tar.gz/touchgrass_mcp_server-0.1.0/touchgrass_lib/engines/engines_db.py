"""
SQLite-backed signal detection engines.
Same API as engines.py but persists to touchgrass.db instead of JSON files.
"""
from __future__ import annotations

import json
import re
from collections import Counter
from datetime import datetime
from typing import Dict, List, Optional

from .models import (
    MoodState, EmotionalQuadrant, AuthoritySource, AuthorityTier,
    ComplianceProfile, RewardProfile, RewardType, EncodingWeight,
    EngineOpinion, TopicGap, GapAnalysis, ApproachAvoidanceData,
    IntrospectiveNarration,
)
from .belief import (
    Uncertainty, TruthLayer, trust_discount, probability_to_opinion,
)
from ..db import TouchgrassDB

# Import patterns from original engines (no need to duplicate)
from .engines import (
    TOPIC_TO_REWARD_MAP, MoodDetector, BeliefExtractor,
    AUTHORITY_INDICATORS, BeliefDelta, AuthorityRef,
    compute_encoding_weight, classify_severity,
)


# =============================================================================
# AUTHORITY GRAPH (SQLite-backed)
# =============================================================================

class AuthorityGraphDB:
    """AuthorityGraph persisted to SQLite authority_sources table."""

    def __init__(self, db: TouchgrassDB):
        self.db = db

    def add_source(self, source_id: str, name: str, tier: AuthorityTier,
                   trust_weight: float = 0.5,
                   influence_topics: Optional[List[str]] = None) -> AuthoritySource:
        tw = max(0.0, min(1.0, trust_weight))
        topics = influence_topics or []
        self.db.upsert_authority(source_id, name, tier.value, tw, topics)
        return AuthoritySource(
            source_id=source_id, name=name, tier=tier,
            trust_weight=tw, influence_topics=topics,
        )

    def get_source(self, source_id: str) -> Optional[AuthoritySource]:
        row = self.db.get_authority(source_id)
        if not row:
            return None
        return self._row_to_source(row)

    def reference(self, source_id: str) -> None:
        self.db.reference_authority(source_id)

    def discount_opinion(self, source_id: str, opinion_strength: float = 0.9) -> Optional[Uncertainty]:
        source = self.get_source(source_id)
        if not source:
            return None
        authority_opinion = probability_to_opinion(opinion_strength, uncertainty_level=0.1)
        user_trust = probability_to_opinion(
            source.trust_weight,
            uncertainty_level=max(0.05, 1.0 - source.trust_weight),
        )
        return trust_discount(user_trust, authority_opinion)

    def get_relevant_sources(self, topic: str) -> List[AuthoritySource]:
        all_sources = self.db.get_all_authorities()
        result = []
        for row in all_sources:
            topics = json.loads(row.get("influence_topics", "[]"))
            if topic in topics or not topics:
                result.append(self._row_to_source(row))
        return result

    def get_tier_defaults(self) -> Dict[str, float]:
        return {
            AuthorityTier.FORMAL.value: 0.95,
            AuthorityTier.INSTITUTIONAL.value: 0.75,
            AuthorityTier.PERSONAL.value: 0.70,
            AuthorityTier.PEER.value: 0.50,
            AuthorityTier.AMBIENT.value: 0.25,
        }

    def to_dict(self) -> dict:
        result = {}
        for row in self.db.get_all_authorities():
            sid = row["source_id"]
            result[sid] = {
                "name": row["name"], "tier": row["tier"],
                "trust_weight": row["trust_weight"],
                "influence_topics": json.loads(row.get("influence_topics", "[]")),
                "reference_count": row.get("reference_count", 0),
            }
        return result

    @staticmethod
    def _row_to_source(row: dict) -> AuthoritySource:
        return AuthoritySource(
            source_id=row["source_id"], name=row["name"],
            tier=AuthorityTier(row["tier"]),
            trust_weight=row.get("trust_weight", 0.5),
            influence_topics=json.loads(row.get("influence_topics", "[]")),
            reference_count=row.get("reference_count", 0),
        )


# =============================================================================
# COMPLIANCE DETECTOR (SQLite-backed)
# =============================================================================

class ComplianceDetectorDB:
    COMPLIANCE_PATTERNS = {
        "should_do":    r'\b(I should|I need to|I have to|I must|I ought to)\b',
        "obligation":   r'\b(required|mandatory|obligated|expected to|supposed to)\b',
        "deference":    r'\b(yes sir|understood|will do|right away|of course)\b',
        "rule_citing":  r'\b(the policy|the rule|the guidelines?|the process|per the)\b',
        "apologetic":   r"\b(sorry|apologize|my fault|my mistake|I'll fix it)\b",
    }
    DEFIANCE_PATTERNS = {
        "but_hedge":      r'\b(I know I should but|I know but|yeah but)\b',
        "dismissal":      r"\b(whatever|who cares|doesn't matter|screw that|forget that)\b",
        "workaround":     r'\b(work around|shortcut|skip|bypass|hack it)\b',
        "resistance":     r"\b(don't see why|pointless|waste of time|bureaucracy)\b",
        "autonomy_pref":  r"\b(I prefer|my way|let me decide|I'll figure it out)\b",
    }

    def __init__(self, db: TouchgrassDB):
        self.db = db
        self.profile = self._load()

    def analyze(self, text: str, session_id: str = "") -> ComplianceProfile:
        for name, pattern in self.COMPLIANCE_PATTERNS.items():
            if re.search(pattern, text, re.IGNORECASE):
                self.profile.observe_compliance(name)
                self.db.log_compliance_signal(f"+{name}", session_id)
        for name, pattern in self.DEFIANCE_PATTERNS.items():
            if re.search(pattern, text, re.IGNORECASE):
                self.profile.observe_defiance(name)
                self.db.log_compliance_signal(f"-{name}", session_id)
        self.db.update_compliance_profile(self.profile.alpha, self.profile.beta)
        return self.profile

    def _load(self) -> ComplianceProfile:
        row = self.db.get_compliance_profile()
        return ComplianceProfile(
            alpha=row.get("alpha", 3.0),
            beta=row.get("beta", 2.0),
        )


# =============================================================================
# REWARD MODEL (SQLite-backed)
# =============================================================================

class RewardModelDB:
    def __init__(self, db: TouchgrassDB):
        self.db = db
        self.profile = self._load()

    def observe(self, topic_category: str, valence: float) -> None:
        self.profile.observe(topic_category, valence)
        self._save()

    @property
    def reward_type(self) -> RewardType:
        return self.profile.reward_type

    @property
    def dominant_reward(self) -> str:
        return self.profile.dominant_reward

    def get_scores(self) -> dict:
        return {
            "social_approval": self.profile.social_score,
            "achievement": self.profile.achievement_score,
            "autonomy": self.profile.autonomy_score,
            "security": self.profile.security_score,
            "dominant": self.profile.dominant_reward,
            "observations": self.profile.observations,
        }

    def _save(self) -> None:
        p = self.profile
        self.db.update_reward_profile(
            p.social_score, p.achievement_score, p.autonomy_score,
            p.security_score, p.reward_type.value, p.observations,
        )

    def _load(self) -> RewardProfile:
        row = self.db.get_reward_profile()
        return RewardProfile(
            reward_type=RewardType(row.get("dominant_type", "unknown")),
            social_score=row.get("social_score", 0.0),
            achievement_score=row.get("achievement_score", 0.0),
            autonomy_score=row.get("autonomy_score", 0.0),
            security_score=row.get("security_score", 0.0),
            observations=row.get("observations", 0),
        )


# =============================================================================
# APPROACH/AVOIDANCE DETECTOR (SQLite-backed)
# =============================================================================

class ApproachAvoidanceDetectorDB:
    APPROACH_PATTERNS = {
        "elaboration":    r'\b(and also|furthermore|another thing|plus|let me add)\b',
        "follow_up":      r'\b(what if|how about|could we|I was thinking)\b',
        "enthusiasm":     r'!{1,}',
        "ownership":      r"\b(I want to|I'd love to|I'm excited|let me|my idea)\b",
        "detail_seeking": r'\b(tell me more|how exactly|specifically|what does)\b',
    }
    AVOIDANCE_PATTERNS = {
        "deflection":      r"\b(anyway|moving on|let's talk about|different topic)\b",
        "deferral":        r'\b(later|eventually|someday|when I get to it|at some point)\b',
        "hedge":           r"\b(I guess|I suppose|maybe|not sure if|probably should)\b",
        "compliance_only": r'\b(fine|okay|sure|will do|understood)\b',
    }

    def __init__(self, db: TouchgrassDB):
        self.db = db

    def analyze(self, text: str, topic: str, mood: MoodState) -> ApproachAvoidanceData:
        row = self.db.get_approach_avoidance(topic)
        if row:
            aa = ApproachAvoidanceData(
                topic=topic,
                approach_count=row["approach_count"],
                avoidance_count=row["avoidance_count"],
                total_valence=row["total_valence"],
                total_arousal=row["total_arousal"],
                observations=row["observations"],
            )
        else:
            aa = ApproachAvoidanceData(topic=topic)

        aa.observations += 1
        aa.total_valence += mood.valence
        aa.total_arousal += mood.arousal

        approach_hits = sum(1 for _, p in self.APPROACH_PATTERNS.items()
                           if re.search(p, text, re.IGNORECASE))
        avoidance_hits = sum(1 for _, p in self.AVOIDANCE_PATTERNS.items()
                            if re.search(p, text, re.IGNORECASE))
        if len(text.split()) > 40:
            approach_hits += 1

        if approach_hits > avoidance_hits:
            aa.approach_count += 1
        elif avoidance_hits > approach_hits:
            aa.avoidance_count += 1

        self.db.upsert_approach_avoidance(
            topic, aa.approach_count, aa.avoidance_count,
            aa.total_valence, aa.total_arousal, aa.observations,
        )
        return aa

    def get_tracker(self, topic: str) -> ApproachAvoidanceData:
        row = self.db.get_approach_avoidance(topic)
        if row:
            return ApproachAvoidanceData(
                topic=topic,
                approach_count=row["approach_count"],
                avoidance_count=row["avoidance_count"],
                total_valence=row["total_valence"],
                total_arousal=row["total_arousal"],
                observations=row["observations"],
            )
        return ApproachAvoidanceData(topic=topic)


# =============================================================================
# GAP ANALYZER (SQLite-backed)
# =============================================================================

class GapAnalyzerDB:
    def __init__(self, db: TouchgrassDB):
        self.db = db

    def analyze(self, persona_opinions: Dict[str, EngineOpinion],
                reward_opinions: Dict[str, EngineOpinion],
                session_id: str = "") -> GapAnalysis:
        all_topics = set(persona_opinions.keys()) | set(reward_opinions.keys())
        gaps = []

        for topic in all_topics:
            e1 = persona_opinions.get(topic)
            e2 = reward_opinions.get(topic)

            # Store opinions
            if e1:
                self.db.record_opinion(
                    session_id, topic, "persona",
                    e1.belief, e1.disbelief, e1.uncertainty, e1.source_signals,
                )
            if e2:
                self.db.record_opinion(
                    session_id, topic, "reward",
                    e2.belief, e2.disbelief, e2.uncertainty, e2.source_signals,
                )

            if e1 and e2:
                e1_val = e1.expected_value
                e2_val = e2.expected_value
                gap_mag = abs(e1_val - e2_val)
                direction = "persona_leads" if e1_val > e2_val else "reward_leads"
                severity = classify_severity(gap_mag)

                self.db.record_gap(topic, e1_val, e2_val, gap_mag, direction, severity)

                # Get observation count from history
                history = self.db.get_gap_history(topic)
                obs = len(history)

                gaps.append(TopicGap(
                    topic=topic, persona_opinion=e1_val, reward_opinion=e2_val,
                    gap_magnitude=gap_mag, gap_direction=direction,
                    conflict_severity=severity,
                    explanation=self._explain(topic, e1, e2, gap_mag, direction),
                    observations=obs,
                ))

        if gaps:
            overall = sum(g.gap_magnitude for g in gaps) / len(gaps)
            trend = self._compute_trend(gaps)
            dominant = self._compute_dominant(gaps)
        else:
            overall, trend, dominant = 0.0, "stable", "balanced"

        return GapAnalysis(
            topic_gaps=gaps, overall_divergence=overall,
            divergence_trend=trend, dominant_engine=dominant,
        )

    def explain_behavior(self, behavior: str, analysis: GapAnalysis) -> str:
        significant = analysis.significant_gaps
        if not significant:
            return ("Not enough divergence data yet to explain this behavior. "
                    "I need more conversations to separate your persona beliefs "
                    "from your reward patterns.")

        top_gap = max(significant, key=lambda g: g.gap_magnitude)
        if top_gap.gap_direction == "reward_leads":
            return (f"Your Persona Engine says '{top_gap.topic}' matters "
                    f"(confidence {top_gap.persona_opinion:.0%}), but your "
                    f"Reward Engine is pulling harder toward what energizes you "
                    f"(confidence {top_gap.reward_opinion:.0%}). "
                    f"The gap ({top_gap.gap_magnitude:.0%}) predicts that your "
                    f"actual behavior follows Engine 2 — your want-self wins "
                    f"at the moment of decision.")
        else:
            return (f"Your Persona Engine holds '{top_gap.topic}' strongly "
                    f"(confidence {top_gap.persona_opinion:.0%}), and it's "
                    f"currently overriding your reward center "
                    f"({top_gap.reward_opinion:.0%}). Watch for burnout — "
                    f"sustained persona-over-reward creates stress. "
                    f"The gap ({top_gap.gap_magnitude:.0%}) is "
                    f"{top_gap.conflict_severity}.")

    def _explain(self, topic: str, e1: EngineOpinion, e2: EngineOpinion,
                 gap: float, direction: str) -> str:
        if gap < 0.15:
            return f"Aligned on '{topic}' — both engines agree."
        elif direction == "reward_leads":
            return (f"'{topic}': You say it matters ({e1.expected_value:.0%}) "
                    f"but your energy goes elsewhere ({e2.expected_value:.0%}).")
        else:
            return (f"'{topic}': Authority pushes this ({e1.expected_value:.0%}) "
                    f"harder than your reward center buys in ({e2.expected_value:.0%}).")

    def _compute_trend(self, gaps: List[TopicGap]) -> str:
        trends = []
        for gap in gaps:
            hist = self.db.get_gap_history(gap.topic, limit=3)
            if len(hist) >= 3:
                # hist is ordered DESC, reverse for chronological
                recent = [h["gap_magnitude"] for h in reversed(hist)]
                if recent[-1] > recent[0] * 1.1:
                    trends.append("increasing")
                elif recent[-1] < recent[0] * 0.9:
                    trends.append("decreasing")
                else:
                    trends.append("stable")
        if not trends:
            return "stable"
        return Counter(trends).most_common(1)[0][0]

    def _compute_dominant(self, gaps: List[TopicGap]) -> str:
        persona_leads = sum(1 for g in gaps if g.gap_direction == "persona_leads")
        reward_leads = len(gaps) - persona_leads
        if abs(persona_leads - reward_leads) <= 1:
            return "balanced"
        return "persona" if persona_leads > reward_leads else "reward"


# =============================================================================
# TRUTH LAYER (SQLite-backed)
# =============================================================================

class TruthLayerDB:
    """Bayesian belief network backed by SQLite beliefs + belief_evidence tables."""

    def __init__(self, db: TouchgrassDB):
        self.db = db

    def add_claim(self, cid: str, text: str, category: str = "general") -> None:
        existing = self.db.get_belief(cid)
        if not existing:
            self.db.upsert_belief(cid, text, category, 1.0, 1.0)

    def validate(self, cid: str, response: str, correction: str = "",
                 session_id: str = "") -> None:
        existing = self.db.get_belief(cid)
        if not existing:
            return
        alpha = existing["alpha"]
        beta = existing["beta"]

        if response == "confirm":
            alpha += 25.0
            self.db.add_belief_evidence(cid, "confirm", 25.0, "", session_id)
        elif response == "reject":
            beta += 25.0
            self.db.add_belief_evidence(cid, "reject", 25.0, "", session_id)
        elif response == "modify":
            alpha += 6.0
            self.db.add_belief_evidence(cid, "modify", 6.0, "", session_id)

        text = correction if correction else existing["text"]
        self.db.upsert_belief(
            cid, text, existing["category"], alpha, beta,
            bool(existing.get("anchored", 0)),
        )

    def update_belief(self, cid: str, supports: bool, strength: float = 1.0,
                      session_id: str = "") -> None:
        existing = self.db.get_belief(cid)
        if not existing:
            return
        alpha = existing["alpha"]
        beta = existing["beta"]
        if supports:
            alpha += strength
        else:
            beta += strength
        self.db.upsert_belief(
            cid, existing["text"], existing["category"], alpha, beta, True,
        )
        action = "confirm" if supports else "reject"
        self.db.add_belief_evidence(cid, action, strength, "", session_id)

    def get_belief(self, cid: str) -> Optional[object]:
        row = self.db.get_belief(cid)
        if not row:
            return None
        # Return a simple object with .probability and .variance
        from .belief import Belief
        return Belief(
            alpha=row["alpha"], beta=row["beta"],
            text=row["text"], category=row["category"],
        )

    def get_probability(self, cid: str) -> float:
        b = self.get_belief(cid)
        return b.probability if b else 0.5

    def get_truth_context(self) -> str:
        all_beliefs = self.db.get_all_beliefs()
        items = []
        for row in all_beliefs:
            alpha = row["alpha"]
            beta = row["beta"]
            prob = alpha / (alpha + beta)
            items.append((row["belief_id"], row["text"], prob))

        items.sort(key=lambda x: x[2], reverse=True)

        blocks = ["=== TRUTH LAYER (Bayesian Knowledge Base) ===\n", "VERIFIED TRUE (>90%):"]
        for _, text, prob in items:
            if prob > 0.90:
                blocks.append(f"  {text}")
        blocks.append("\nLIKELY TRUE (70-90%):")
        for _, text, prob in items:
            if 0.70 < prob <= 0.90:
                blocks.append(f"  {text} ({prob:.0%})")
        blocks.append("\nUNCERTAIN (30-70%):")
        for _, text, prob in items:
            if 0.30 <= prob <= 0.70:
                blocks.append(f"  {text} ({prob:.0%})")
        blocks.append("\nLIKELY FALSE (<30%):")
        for _, text, prob in items:
            if prob < 0.30:
                blocks.append(f"  {text} ({prob:.0%})")
        blocks.append("\n=== END TRUTH LAYER ===")
        return "\n".join(blocks)

    def stats(self) -> dict:
        all_beliefs = self.db.get_all_beliefs()
        return {
            "total_claims": len(all_beliefs),
            "anchored": sum(1 for b in all_beliefs if b.get("anchored")),
            "high_confidence": sum(
                1 for b in all_beliefs
                if b["alpha"] / (b["alpha"] + b["beta"]) > 0.9
                or b["alpha"] / (b["alpha"] + b["beta"]) < 0.1
            ),
        }


# =============================================================================
# PERSONA ENGINE (same logic, uses DB-backed components)
# =============================================================================

class PersonaEngineDB:
    def __init__(self, truth_layer: TruthLayerDB, authority_graph: AuthorityGraphDB,
                 compliance_detector: ComplianceDetectorDB):
        self.truth_layer = truth_layer
        self.authority = authority_graph
        self.compliance = compliance_detector

    def process(self, text: str, mood: MoodState, topics: List[str],
                session_id: str = "",
                authority_refs: Optional[List[dict]] = None) -> Dict[str, EngineOpinion]:
        self.compliance.analyze(text, session_id)
        opinions = {}

        for topic in topics:
            signals = []
            belief = self.truth_layer.get_belief(topic)

            if belief:
                b_val = belief.probability
                u_val = max(0.05, min(0.5, belief.variance * 10))
            else:
                b_val = 0.5
                u_val = 0.4

            relevant = self.authority.get_relevant_sources(topic)
            for source in relevant:
                discounted = self.authority.discount_opinion(source.source_id)
                if discounted:
                    b_val = min(0.95, b_val * 0.6 + discounted.expected_value * 0.4)
                    u_val = max(0.05, u_val * 0.7)
                    signals.append(f"authority:{source.source_id}")

            compliance_score = self.compliance.profile.compliance_score
            if compliance_score > 0.6:
                signals.append("compliance:rule_follower")
            elif compliance_score < 0.4:
                signals.append("compliance:rule_bender")
                u_val = min(0.5, u_val * 1.2)

            espoused_patterns = ["I should", "I need to", "I believe", "I think", "it's important"]
            for p in espoused_patterns:
                if p.lower() in text.lower():
                    b_val = min(0.95, b_val + 0.05)
                    signals.append(f"espoused:{p.replace(' ', '_')}")

            d_val = max(0.0, 1.0 - b_val - u_val)
            total = b_val + d_val + u_val
            if abs(total - 1.0) > 1e-6:
                b_val /= total
                d_val /= total
                u_val /= total

            opinions[topic] = EngineOpinion(
                topic=topic, belief=round(b_val, 3),
                disbelief=round(d_val, 3), uncertainty=round(u_val, 3),
                source_signals=signals,
            )

        return opinions


# =============================================================================
# GOVERNANCE LAYER (SQLite-backed)
# =============================================================================

class GovernanceLayerDB:
    PROMOTION_THRESHOLD = 3
    ENCODING_WEIGHT_HOLD_THRESHOLD = 1.3

    def __init__(self, db: TouchgrassDB):
        self.db = db

    def gate_memory_write(self, memory_id: str, encoding_weight: float,
                          conflict_score: float, trust_zone: str,
                          corroboration_count: int, session_id: str = "") -> str:
        import uuid

        if encoding_weight >= self.ENCODING_WEIGHT_HOLD_THRESHOLD:
            hold_id = f"hold_{uuid.uuid4().hex[:8]}"
            self.db.create_hold(
                hold_id, "store_memory", memory_id,
                f"High encoding weight ({encoding_weight:.2f}) — flashbulb-level",
            )
            self.db.audit("hold_created", hold_id,
                         {"target": memory_id, "encoding_weight": encoding_weight},
                         session_id)
            return "held"

        if conflict_score > 0.5:
            hold_id = f"hold_{uuid.uuid4().hex[:8]}"
            self.db.create_hold(
                hold_id, "store_memory", memory_id,
                f"High persona-reward conflict ({conflict_score:.2f})",
            )
            self.db.audit("hold_created", hold_id,
                         {"target": memory_id, "conflict": conflict_score},
                         session_id)
            return "held"

        if trust_zone == "unverified":
            self.db.audit("memory_write", memory_id,
                         {"zone": "unverified", "encoding_weight": encoding_weight},
                         session_id)
            return "allowed"

        if corroboration_count >= self.PROMOTION_THRESHOLD:
            self.db.audit("memory_promote", memory_id,
                         {"corroboration": corroboration_count},
                         session_id)
            return "allowed"

        hold_id = f"hold_{uuid.uuid4().hex[:8]}"
        self.db.create_hold(
            hold_id, "promote_memory", memory_id,
            f"Corroboration {corroboration_count}/{self.PROMOTION_THRESHOLD}",
        )
        self.db.audit("hold_created", hold_id, {"target": memory_id}, session_id)
        return "held"

    def gate_memory_delete(self, memory_id: str, trust_zone: str,
                           session_id: str = "") -> str:
        import uuid
        if trust_zone == "promoted":
            hold_id = f"hold_{uuid.uuid4().hex[:8]}"
            self.db.create_hold(
                hold_id, "delete_memory", memory_id,
                "Deletion of promoted memory requires human approval",
            )
            self.db.audit("hold_created", hold_id,
                         {"action": "delete", "target": memory_id}, session_id)
            return "held"
        return "allowed"

    def resolve_hold(self, hold_id: str, decision: str,
                     reason: str = "", session_id: str = "") -> bool:
        holds = self.db.get_pending_holds()
        for hold in holds:
            if hold["hold_id"] == hold_id:
                status = "approved" if decision == "approve" else "rejected"
                self.db.resolve_hold(hold_id, status, reason)
                self.db.audit("hold_resolved", hold_id,
                             {"decision": decision, "reason": reason}, session_id)
                return True
        return False

    def pending_holds(self) -> List[dict]:
        return self.db.get_pending_holds()


# =============================================================================
# INTROSPECTIVE LAYER (no persistence needed — computed each turn)
# =============================================================================
# Reuse directly from engines.py
from .engines import IntrospectiveLayer  # noqa: E402
