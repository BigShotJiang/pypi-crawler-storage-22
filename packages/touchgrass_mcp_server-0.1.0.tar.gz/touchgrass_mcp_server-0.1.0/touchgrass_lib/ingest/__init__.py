"""Ingestion connectors: email, calendar, weather, scheduler."""
from .scheduler import run_ingest, should_ingest
