"""Google Calendar ingestion — pull events, detect conflicts, generate prep notes."""
from __future__ import annotations

import json
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import List

from ..db import TouchgrassDB


def fetch_calendar(db: TouchgrassDB, hours_ahead: int = 48) -> int:
    """Fetch upcoming calendar events. Returns count of events ingested."""
    creds_path = os.getenv("GCAL_CREDENTIALS_PATH", "")
    token_path = os.getenv("GCAL_TOKEN_PATH", "")

    if not creds_path or not Path(creds_path).exists():
        return 0

    try:
        from google.oauth2.credentials import Credentials
        from google_auth_oauthlib.flow import InstalledAppFlow
        from google.auth.transport.requests import Request
        from googleapiclient.discovery import build
    except ImportError:
        return 0

    creds = None
    token = Path(token_path) if token_path else None

    if token and token.exists():
        creds = Credentials.from_authorized_user_file(str(token))

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                creds_path, ["https://www.googleapis.com/auth/calendar.readonly"],
            )
            creds = flow.run_local_server(port=0)
        if token:
            token.write_text(creds.to_json())

    service = build("calendar", "v3", credentials=creds)

    now = datetime.utcnow()
    time_min = now.isoformat() + "Z"
    time_max = (now + timedelta(hours=hours_ahead)).isoformat() + "Z"

    results = service.events().list(
        calendarId="primary", timeMin=time_min, timeMax=time_max,
        singleEvents=True, orderBy="startTime",
    ).execute()

    events = results.get("items", [])
    count = 0

    for event in events:
        event_id = event["id"]
        title = event.get("summary", "No title")
        start = event["start"].get("dateTime", event["start"].get("date", ""))
        end = event["end"].get("dateTime", event["end"].get("date", ""))
        location = event.get("location", "")
        attendees = [
            a.get("email", "") for a in event.get("attendees", [])
            if a.get("email")
        ]

        db.upsert_calendar_event(
            event_id=event_id, title=title, start_time=start,
            end_time=end, location=location, attendees=attendees,
        )
        count += 1

    return count


def detect_conflicts(db: TouchgrassDB) -> List[dict]:
    """Find overlapping events in the next 24 hours."""
    events = db.get_upcoming_events(24)
    conflicts = []

    for i, e1 in enumerate(events):
        for e2 in events[i + 1:]:
            if e1["end_time"] > e2["start_time"]:
                conflicts.append({
                    "event_1": e1["title"],
                    "event_2": e2["title"],
                    "overlap_start": e2["start_time"],
                    "overlap_end": min(e1["end_time"], e2["end_time"]),
                })

    return conflicts
