"""Gmail ingestion — OAuth2, pull, classify, prioritize.

Requires Gmail API credentials (OAuth). User provides their own via .env.
"""
from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from ..db import TouchgrassDB

# Priority classification keywords
URGENT_KEYWORDS = ["urgent", "asap", "emergency", "critical", "immediate", "deadline today"]
NEEDS_REPLY_KEYWORDS = ["please respond", "please reply", "action required", "need your", "waiting for"]


def classify_priority(subject: str, snippet: str, labels: List[str]) -> tuple:
    """Classify email priority. Returns (priority_label, score)."""
    text = f"{subject} {snippet}".lower()

    if any(kw in text for kw in URGENT_KEYWORDS) or "IMPORTANT" in labels:
        return ("urgent", 1.0)

    if any(kw in text for kw in NEEDS_REPLY_KEYWORDS):
        return ("needs_reply", 0.7)

    if "CATEGORY_UPDATES" in labels or "CATEGORY_PROMOTIONS" in labels:
        return ("noise", 0.1)

    return ("fyi", 0.3)


def fetch_gmail(db: TouchgrassDB, max_results: int = 20) -> int:
    """Fetch recent emails from Gmail API. Returns count of new emails ingested."""
    creds_path = os.getenv("GMAIL_CREDENTIALS_PATH", "")
    token_path = os.getenv("GMAIL_TOKEN_PATH", "")

    if not creds_path or not Path(creds_path).exists():
        return 0

    try:
        from google.oauth2.credentials import Credentials
        from google_auth_oauthlib.flow import InstalledAppFlow
        from google.auth.transport.requests import Request
        from googleapiclient.discovery import build
    except ImportError:
        return 0

    creds = None
    token = Path(token_path) if token_path else None

    if token and token.exists():
        creds = Credentials.from_authorized_user_file(str(token))

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                creds_path, ["https://www.googleapis.com/auth/gmail.readonly"],
            )
            creds = flow.run_local_server(port=0)
        if token:
            token.write_text(creds.to_json())

    service = build("gmail", "v1", credentials=creds)
    results = service.users().messages().list(
        userId="me", maxResults=max_results, labelIds=["INBOX"],
    ).execute()

    messages = results.get("messages", [])
    count = 0

    for msg in messages:
        detail = service.users().messages().get(
            userId="me", id=msg["id"], format="metadata",
            metadataHeaders=["From", "Subject"],
        ).execute()

        msg_id = detail["id"]
        headers = {h["name"]: h["value"] for h in detail.get("payload", {}).get("headers", [])}
        sender = headers.get("From", "")
        subject = headers.get("Subject", "")
        snippet = detail.get("snippet", "")
        labels = detail.get("labelIds", [])
        received_at = datetime.fromtimestamp(
            int(detail.get("internalDate", "0")) / 1000
        ).isoformat()

        # Parse sender name
        sender_name = sender.split("<")[0].strip().strip('"') if "<" in sender else sender

        priority, score = classify_priority(subject, snippet, labels)

        db.upsert_email(
            message_id=msg_id, sender=sender, sender_name=sender_name,
            subject=subject, snippet=snippet, priority=priority,
            priority_score=score, labels=labels, received_at=received_at,
        )
        count += 1

    return count
