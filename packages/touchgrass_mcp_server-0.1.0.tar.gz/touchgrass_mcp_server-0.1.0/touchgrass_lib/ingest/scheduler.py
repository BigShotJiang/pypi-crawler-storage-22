"""Ingestion scheduler — checks if ingestion is needed based on elapsed time."""
from __future__ import annotations

from datetime import datetime
from typing import Dict, Optional

from ..db import TouchgrassDB
from .email import fetch_gmail
from .calendar import fetch_calendar
from .weather import fetch_weather


# Default intervals (minutes)
DEFAULT_INTERVALS = {
    "email": 15,
    "calendar": 30,
    "weather": 60,
}

# Track last ingest times in memory (reset on server restart)
_last_ingest: Dict[str, Optional[datetime]] = {
    "email": None,
    "calendar": None,
    "weather": None,
}


def should_ingest(source: str, interval_minutes: int = None) -> bool:
    """Check if enough time has passed to re-ingest a source."""
    if interval_minutes is None:
        interval_minutes = DEFAULT_INTERVALS.get(source, 15)

    last = _last_ingest.get(source)
    if last is None:
        return True

    elapsed = (datetime.utcnow() - last).total_seconds() / 60
    return elapsed >= interval_minutes


def run_ingest(db: TouchgrassDB, force: bool = False) -> Dict[str, int]:
    """Run ingestion for all due sources. Returns {source: count_ingested}."""
    results = {}

    if force or should_ingest("email"):
        count = fetch_gmail(db)
        _last_ingest["email"] = datetime.utcnow()
        results["email"] = count

    if force or should_ingest("calendar"):
        count = fetch_calendar(db)
        _last_ingest["calendar"] = datetime.utcnow()
        results["calendar"] = count

    if force or should_ingest("weather"):
        weather = fetch_weather(db)
        _last_ingest["weather"] = datetime.utcnow()
        results["weather"] = 1 if weather else 0

    return results
