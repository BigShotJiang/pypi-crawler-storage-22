"""Weather ingestion — OpenWeatherMap free tier."""
from __future__ import annotations

import json
import os
from datetime import datetime
from typing import Optional
from urllib.request import urlopen, Request
from urllib.error import URLError

from ..db import TouchgrassDB


def fetch_weather(db: TouchgrassDB) -> Optional[dict]:
    """Fetch current weather from OpenWeatherMap. Returns weather dict or None."""
    api_key = os.getenv("OPENWEATHERMAP_API_KEY", "")
    lat = os.getenv("WEATHER_LAT", "")
    lon = os.getenv("WEATHER_LON", "")

    if not api_key or not lat or not lon:
        return None

    try:
        url = (
            f"https://api.openweathermap.org/data/2.5/weather"
            f"?lat={lat}&lon={lon}&appid={api_key}&units=imperial"
        )
        req = Request(url, headers={"User-Agent": "touchgrass/0.1"})
        resp = urlopen(req, timeout=10)
        data = json.loads(resp.read().decode())

        temp_f = data["main"]["temp"]
        condition = data["weather"][0]["description"] if data.get("weather") else "unknown"
        wind_mph = data["wind"]["speed"] if "wind" in data else 0
        # Rain probability from hourly if available
        rain_pct = 0.0
        if "rain" in data:
            rain_pct = 100.0  # it's currently raining

        # Check for advisories
        advisory = ""
        if temp_f > 100:
            advisory = "Extreme heat advisory"
        elif temp_f < 20:
            advisory = "Extreme cold advisory"
        elif wind_mph > 30:
            advisory = "High wind advisory"

        weather = {
            "temp_f": temp_f,
            "condition": condition,
            "precipitation_pct": rain_pct,
            "wind_mph": wind_mph,
            "advisory": advisory,
            "forecast_date": datetime.utcnow().strftime("%Y-%m-%d"),
        }

        db.store_weather(
            temp_f=temp_f, condition=condition,
            precipitation_pct=rain_pct, wind_mph=wind_mph,
            advisory=advisory,
            forecast_date=datetime.utcnow().strftime("%Y-%m-%d"),
        )

        return weather

    except (URLError, KeyError, json.JSONDecodeError):
        return None
