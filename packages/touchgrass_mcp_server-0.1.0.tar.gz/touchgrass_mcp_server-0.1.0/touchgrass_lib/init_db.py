"""touchgrass database initialization — 22 tables, zero external dependencies."""
from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from typing import Optional, Union

SCHEMA = """
-- Sessions & Identity
CREATE TABLE IF NOT EXISTS sessions (
    session_id    TEXT PRIMARY KEY,
    started_at    TEXT NOT NULL DEFAULT (datetime('now')),
    ended_at      TEXT,
    interaction_count INTEGER DEFAULT 0
);

-- Voice Layer
CREATE TABLE IF NOT EXISTS voice_calibration (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    label         TEXT NOT NULL,
    pitch_mean    REAL,
    pitch_std     REAL,
    pace_wpm      REAL,
    volume_db     REAL,
    pause_ratio   REAL,
    spectral_centroid REAL,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS voice_states (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id    TEXT REFERENCES sessions(session_id),
    pitch_mean    REAL,
    pitch_std     REAL,
    pace_wpm      REAL,
    volume_db     REAL,
    pause_ratio   REAL,
    spectral_centroid REAL,
    detected_state TEXT,
    confidence    REAL,
    transcript    TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_voice_states_time ON voice_states(created_at);

-- Mood & Emotional State
CREATE TABLE IF NOT EXISTS mood_readings (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id    TEXT REFERENCES sessions(session_id),
    valence       REAL NOT NULL,
    arousal       REAL NOT NULL,
    quadrant      TEXT NOT NULL,
    intensity     REAL,
    confidence    REAL,
    signals       TEXT,
    voice_state_id INTEGER REFERENCES voice_states(id),
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_mood_time ON mood_readings(created_at);

-- Belief Network
CREATE TABLE IF NOT EXISTS beliefs (
    belief_id     TEXT PRIMARY KEY,
    text          TEXT NOT NULL,
    category      TEXT DEFAULT 'general',
    alpha         REAL DEFAULT 1.0,
    beta          REAL DEFAULT 1.0,
    anchored      INTEGER DEFAULT 0,
    first_seen    TEXT NOT NULL DEFAULT (datetime('now')),
    last_updated  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS belief_evidence (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    belief_id     TEXT REFERENCES beliefs(belief_id),
    action        TEXT NOT NULL,
    strength      REAL DEFAULT 5.0,
    source        TEXT,
    session_id    TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Authority & Compliance (Engine 1 inputs)
CREATE TABLE IF NOT EXISTS authority_sources (
    source_id     TEXT PRIMARY KEY,
    name          TEXT NOT NULL,
    tier          TEXT NOT NULL,
    trust_weight  REAL DEFAULT 0.5,
    influence_topics TEXT DEFAULT '[]',
    reference_count INTEGER DEFAULT 0,
    last_referenced TEXT
);

CREATE TABLE IF NOT EXISTS compliance_log (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    signal        TEXT NOT NULL,
    session_id    TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS compliance_profile (
    id            INTEGER PRIMARY KEY CHECK (id = 1),
    alpha         REAL DEFAULT 3.0,
    beta          REAL DEFAULT 2.0
);

-- Reward & Approach/Avoidance (Engine 2 inputs)
CREATE TABLE IF NOT EXISTS reward_profile (
    id            INTEGER PRIMARY KEY CHECK (id = 1),
    social_score      REAL DEFAULT 0.0,
    achievement_score REAL DEFAULT 0.0,
    autonomy_score    REAL DEFAULT 0.0,
    security_score    REAL DEFAULT 0.0,
    dominant_type     TEXT DEFAULT 'unknown',
    observations      INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS approach_avoidance (
    topic         TEXT PRIMARY KEY,
    approach_count    INTEGER DEFAULT 0,
    avoidance_count   INTEGER DEFAULT 0,
    total_valence     REAL DEFAULT 0.0,
    total_arousal     REAL DEFAULT 0.0,
    observations      INTEGER DEFAULT 0
);

-- Dual-Engine Opinions & Gap History
CREATE TABLE IF NOT EXISTS engine_opinions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id    TEXT,
    topic         TEXT NOT NULL,
    engine        TEXT NOT NULL,
    belief        REAL,
    disbelief     REAL,
    uncertainty   REAL,
    signals       TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_opinions_topic ON engine_opinions(topic, engine);

CREATE TABLE IF NOT EXISTS gap_history (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    topic         TEXT NOT NULL,
    persona_val   REAL,
    reward_val    REAL,
    gap_magnitude REAL,
    gap_direction TEXT,
    severity      TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_gap_topic_time ON gap_history(topic, created_at);

-- Emotional Memories (FTS5 for local search — no Pinecone dependency)
CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
    content,
    topic_tags,
    tokenize='porter'
);

CREATE TABLE IF NOT EXISTS emotional_memories (
    memory_id     TEXT PRIMARY KEY,
    content       TEXT NOT NULL,
    session_id    TEXT,
    trust_zone    TEXT DEFAULT 'unverified',
    corroboration_count INTEGER DEFAULT 0,
    encoding_weight   REAL DEFAULT 0.5,
    conflict_score    REAL DEFAULT 0.0,
    persona_opinion   REAL DEFAULT 0.5,
    reward_opinion    REAL DEFAULT 0.5,
    gap_magnitude     REAL DEFAULT 0.0,
    gap_direction     TEXT DEFAULT '',
    valence       REAL DEFAULT 0.0,
    arousal       REAL DEFAULT 0.0,
    quadrant      TEXT DEFAULT 'neutral',
    authority_source TEXT DEFAULT '',
    topic_tags    TEXT DEFAULT '[]',
    related_ids   TEXT DEFAULT '[]',
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Ingested Data
CREATE TABLE IF NOT EXISTS email_items (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id    TEXT UNIQUE,
    sender        TEXT,
    sender_name   TEXT,
    subject       TEXT,
    snippet       TEXT,
    priority      TEXT DEFAULT 'fyi',
    priority_score REAL DEFAULT 0.0,
    labels        TEXT DEFAULT '[]',
    received_at   TEXT,
    ingested_at   TEXT NOT NULL DEFAULT (datetime('now')),
    briefed       INTEGER DEFAULT 0,
    briefed_at    TEXT
);

CREATE INDEX IF NOT EXISTS idx_email_priority ON email_items(priority, briefed);

CREATE TABLE IF NOT EXISTS calendar_events (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id      TEXT UNIQUE,
    title         TEXT,
    start_time    TEXT,
    end_time      TEXT,
    location      TEXT,
    attendees     TEXT DEFAULT '[]',
    prep_notes    TEXT,
    ingested_at   TEXT NOT NULL DEFAULT (datetime('now')),
    briefed       INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS weather_snapshots (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    temp_f        REAL,
    condition     TEXT,
    precipitation_pct REAL,
    wind_mph      REAL,
    advisory      TEXT,
    forecast_date TEXT,
    captured_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Briefing State
CREATE TABLE IF NOT EXISTS briefing_history (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id    TEXT,
    now_item      TEXT,
    since_last    TEXT,
    next_actions  TEXT,
    voice_state   TEXT,
    adaptation    TEXT,
    delivered_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS pending_items (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    source        TEXT NOT NULL,
    source_id     TEXT,
    priority      REAL DEFAULT 0.0,
    summary       TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now')),
    briefed       INTEGER DEFAULT 0,
    briefed_at    TEXT
);

-- Pattern Learning
CREATE TABLE IF NOT EXISTS patterns (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    pattern_type  TEXT NOT NULL,
    description   TEXT NOT NULL,
    correlation   REAL,
    observations  INTEGER DEFAULT 1,
    confidence    REAL DEFAULT 0.0,
    first_seen    TEXT NOT NULL DEFAULT (datetime('now')),
    last_seen     TEXT NOT NULL DEFAULT (datetime('now')),
    active        INTEGER DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_patterns_type ON patterns(pattern_type, active);

-- Governance
CREATE TABLE IF NOT EXISTS holds (
    hold_id       TEXT PRIMARY KEY,
    action        TEXT NOT NULL,
    target_id     TEXT,
    reason        TEXT,
    status        TEXT DEFAULT 'pending',
    resolution_reason TEXT DEFAULT '',
    requested_at  TEXT NOT NULL DEFAULT (datetime('now')),
    resolved_at   TEXT
);

CREATE TABLE IF NOT EXISTS audit_log (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type    TEXT NOT NULL,
    target_id     TEXT,
    details       TEXT,
    session_id    TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_log(created_at);

-- Initialize singleton rows
INSERT OR IGNORE INTO compliance_profile (id, alpha, beta) VALUES (1, 3.0, 2.0);
INSERT OR IGNORE INTO reward_profile (id, social_score, achievement_score, autonomy_score, security_score, dominant_type, observations)
    VALUES (1, 0.0, 0.0, 0.0, 0.0, 'unknown', 0);
"""


def get_db_path(data_dir: Optional[str] = None) -> Path:
    if data_dir:
        return Path(data_dir) / "touchgrass.db"
    env_path = os.environ.get("TOUCHGRASS_DB")
    if env_path:
        return Path(env_path)
    return Path.home() / ".claude" / "plugins" / "touchgrass" / "data" / "touchgrass.db"


def init_db(db_path: Union[str, Path] = None) -> sqlite3.Connection:
    """Initialize the touchgrass database. Idempotent."""
    if db_path is None:
        db_path = get_db_path()
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript(SCHEMA)
    conn.commit()
    return conn


def get_connection(db_path: Union[str, Path] = None) -> sqlite3.Connection:
    """Get a connection to an existing DB (initializes if needed)."""
    if db_path is None:
        db_path = get_db_path()
    db_path = Path(db_path)
    if not db_path.exists():
        return init_db(db_path)
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.row_factory = sqlite3.Row
    return conn


def is_initialized(db_path: Union[str, Path] = None) -> bool:
    if db_path is None:
        db_path = get_db_path()
    db_path = Path(db_path)
    if not db_path.exists():
        return False
    try:
        conn = sqlite3.connect(str(db_path))
        cursor = conn.execute("SELECT count(*) FROM sqlite_master WHERE type='table'")
        count = cursor.fetchone()[0]
        conn.close()
        return count >= 20
    except Exception:
        return False


if __name__ == "__main__":
    import sys
    path = sys.argv[1] if len(sys.argv) > 1 else None
    db_path = Path(path) if path else get_db_path()
    conn = init_db(db_path)

    cursor = conn.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
    tables = [row[0] for row in cursor.fetchall() if not row[0].startswith('memories_fts_')]
    print(f"touchgrass database initialized: {db_path}")
    print(f"Tables created: {len(tables)}")
    for t in tables:
        print(f"  - {t}")
    conn.close()
