"""Voice feature extraction via librosa. Raw audio in, features out, audio discarded."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np


@dataclass
class VoiceFeatures:
    """Extracted voice features — no raw audio retained."""
    pitch_mean: float = 0.0
    pitch_std: float = 0.0
    pace_wpm: float = 0.0
    volume_db: float = 0.0
    pause_ratio: float = 0.0
    spectral_centroid: float = 0.0
    duration_seconds: float = 0.0

    def to_dict(self) -> dict:
        return {
            "pitch_mean": round(self.pitch_mean, 2),
            "pitch_std": round(self.pitch_std, 2),
            "pace_wpm": round(self.pace_wpm, 1),
            "volume_db": round(self.volume_db, 2),
            "pause_ratio": round(self.pause_ratio, 3),
            "spectral_centroid": round(self.spectral_centroid, 2),
            "duration_seconds": round(self.duration_seconds, 2),
        }


def extract_features(audio: np.ndarray, sr: int = 22050) -> VoiceFeatures:
    """Extract voice features from audio array. Audio is NOT stored."""
    try:
        import librosa
    except ImportError:
        raise RuntimeError(
            "librosa required for voice analysis. "
            "Install: pip install librosa"
        )

    features = VoiceFeatures()
    features.duration_seconds = len(audio) / sr

    if len(audio) < sr * 0.5:  # less than 0.5 seconds
        return features

    # Pitch (F0) via pyin
    f0, voiced_flag, _ = librosa.pyin(
        audio, fmin=librosa.note_to_hz("C2"),
        fmax=librosa.note_to_hz("C7"), sr=sr,
    )
    voiced_f0 = f0[voiced_flag] if voiced_flag is not None else f0[~np.isnan(f0)]
    if len(voiced_f0) > 0:
        features.pitch_mean = float(np.nanmean(voiced_f0))
        features.pitch_std = float(np.nanstd(voiced_f0))

    # Volume (RMS in dB)
    rms = librosa.feature.rms(y=audio)[0]
    if len(rms) > 0:
        mean_rms = float(np.mean(rms))
        if mean_rms > 0:
            features.volume_db = float(20 * np.log10(mean_rms + 1e-10))

    # Pause ratio (fraction of frames below energy threshold)
    threshold = np.percentile(rms, 20) if len(rms) > 0 else 0.01
    silence_frames = np.sum(rms < threshold)
    features.pause_ratio = float(silence_frames / max(1, len(rms)))

    # Spectral centroid (brightness)
    centroid = librosa.feature.spectral_centroid(y=audio, sr=sr)[0]
    if len(centroid) > 0:
        features.spectral_centroid = float(np.mean(centroid))

    # Pace (WPM estimate from speech rate)
    # Use onset detection as proxy for syllable rate
    onset_env = librosa.onset.onset_strength(y=audio, sr=sr)
    onsets = librosa.onset.onset_detect(
        onset_envelope=onset_env, sr=sr, units="time",
    )
    if features.duration_seconds > 1.0 and len(onsets) > 1:
        syllable_rate = len(onsets) / features.duration_seconds
        # Average English: ~4.5 syllables per word at normal speech
        features.pace_wpm = syllable_rate * 60 / 4.5

    return features


def extract_features_from_file(path: str, sr: int = 22050) -> VoiceFeatures:
    """Extract features from an audio file. File is read then features returned."""
    try:
        import librosa
    except ImportError:
        raise RuntimeError("librosa required. Install: pip install librosa")

    audio, sr = librosa.load(path, sr=sr)
    return extract_features(audio, sr)
