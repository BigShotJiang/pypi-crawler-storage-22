"""Voice calibrator — "The Audition" — builds personal voice embedding space."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np

from ..db import TouchgrassDB
from .analyzer import VoiceFeatures


# Standard emotional states for calibration
CALIBRATION_STATES = [
    "calm",       # baseline: morning routine talk
    "excited",    # engaged: project excitement
    "frustrated", # frustrated: annoyance discussion
    "pressured",  # under pressure: timed explanation
    "reflective", # tired/thoughtful: real talk
    "problem_solving",  # optional: decision discussion
    "relaxed",    # optional: fun/social
    "peak_stress", # optional: biggest worry
]


@dataclass
class PersonalBaseline:
    """Per-state baseline from calibration."""
    label: str
    pitch_mean: float = 0.0
    pitch_std: float = 0.0
    pace_wpm: float = 0.0
    volume_db: float = 0.0
    pause_ratio: float = 0.0
    spectral_centroid: float = 0.0


@dataclass
class CalibrationProfile:
    """Complete calibration: baselines per state + global stats."""
    baselines: Dict[str, PersonalBaseline] = field(default_factory=dict)
    global_pitch_mean: float = 0.0
    global_pitch_std: float = 0.0
    global_pace_mean: float = 0.0
    global_volume_mean: float = 0.0

    @property
    def is_sufficient(self) -> bool:
        return len(self.baselines) >= 5

    @property
    def calibration_points(self) -> int:
        return len(self.baselines)


class VoiceCalibrator:
    """Manages personal voice calibration data."""

    def __init__(self, db: TouchgrassDB):
        self.db = db

    def add_calibration_point(self, label: str, features: VoiceFeatures) -> int:
        """Store a calibration reading."""
        return self.db.store_calibration(
            label=label,
            pitch_mean=features.pitch_mean,
            pitch_std=features.pitch_std,
            pace_wpm=features.pace_wpm,
            volume_db=features.volume_db,
            pause_ratio=features.pause_ratio,
            spectral_centroid=features.spectral_centroid,
        )

    def get_profile(self) -> CalibrationProfile:
        """Build calibration profile from stored data."""
        rows = self.db.get_calibration()
        profile = CalibrationProfile()

        if not rows:
            return profile

        all_pitch = []
        all_pace = []
        all_volume = []

        for row in rows:
            baseline = PersonalBaseline(
                label=row["label"],
                pitch_mean=row["pitch_mean"],
                pitch_std=row["pitch_std"],
                pace_wpm=row["pace_wpm"],
                volume_db=row["volume_db"],
                pause_ratio=row["pause_ratio"],
                spectral_centroid=row["spectral_centroid"],
            )
            profile.baselines[row["label"]] = baseline
            all_pitch.append(row["pitch_mean"])
            all_pace.append(row["pace_wpm"])
            all_volume.append(row["volume_db"])

        if all_pitch:
            profile.global_pitch_mean = float(np.mean(all_pitch))
            profile.global_pitch_std = float(np.std(all_pitch))
        if all_pace:
            profile.global_pace_mean = float(np.mean(all_pace))
        if all_volume:
            profile.global_volume_mean = float(np.mean(all_volume))

        return profile

    def get_missing_states(self) -> List[str]:
        """Return calibration states not yet recorded."""
        profile = self.get_profile()
        return [s for s in CALIBRATION_STATES if s not in profile.baselines]

    def compare_to_baseline(self, features: VoiceFeatures,
                            profile: CalibrationProfile) -> Dict[str, float]:
        """Compare current features to each calibration baseline.
        Returns dict of {state_label: distance} — lower = closer match.
        """
        if not profile.baselines:
            return {}

        distances = {}
        for label, baseline in profile.baselines.items():
            # Normalized Euclidean distance across features
            diffs = [
                (features.pitch_mean - baseline.pitch_mean) / max(1, profile.global_pitch_std) if profile.global_pitch_std > 0 else 0,
                (features.pace_wpm - baseline.pace_wpm) / max(1, profile.global_pace_mean * 0.3) if profile.global_pace_mean > 0 else 0,
                (features.volume_db - baseline.volume_db) / 10.0,
                (features.pause_ratio - baseline.pause_ratio) / 0.2,
                (features.spectral_centroid - baseline.spectral_centroid) / max(1, baseline.spectral_centroid * 0.3) if baseline.spectral_centroid > 0 else 0,
            ]
            dist = float(np.sqrt(np.mean(np.array(diffs) ** 2)))
            distances[label] = round(dist, 3)

        return distances

    def classify_state(self, features: VoiceFeatures) -> Tuple[str, float]:
        """Classify current voice features against personal calibration.
        Returns (state_label, confidence).
        """
        profile = self.get_profile()
        if not profile.is_sufficient:
            return ("unknown", 0.0)

        distances = self.compare_to_baseline(features, profile)
        if not distances:
            return ("unknown", 0.0)

        # Closest match
        closest_label = min(distances, key=distances.get)
        closest_dist = distances[closest_label]

        # Confidence: inverse of distance, normalized
        # dist < 0.5 = high confidence, dist > 2.0 = low confidence
        confidence = max(0.0, min(1.0, 1.0 - closest_dist / 3.0))

        return (closest_label, round(confidence, 3))
