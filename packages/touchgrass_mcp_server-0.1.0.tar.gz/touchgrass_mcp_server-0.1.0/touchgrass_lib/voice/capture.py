"""Voice capture — microphone input with VAD, outputs features only.

Raw audio is NEVER stored. Features are extracted then audio is discarded.

Usage:
    python capture.py --db path/to/touchgrass.db --session session_id
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Optional

import numpy as np


def capture_audio(duration: float = 3.0, sr: int = 22050) -> Optional[np.ndarray]:
    """Capture audio from default microphone. Returns numpy array or None."""
    try:
        import sounddevice as sd
    except ImportError:
        print("sounddevice required. Install: pip install sounddevice", file=sys.stderr)
        return None

    try:
        audio = sd.rec(int(duration * sr), samplerate=sr, channels=1, dtype="float32")
        sd.wait()
        return audio.flatten()
    except Exception as e:
        print(f"Audio capture failed: {e}", file=sys.stderr)
        return None


def capture_with_vad(max_duration: float = 10.0, sr: int = 22050,
                     silence_threshold: float = 0.01,
                     silence_duration: float = 1.5) -> Optional[np.ndarray]:
    """Capture with voice activity detection — stops after silence."""
    try:
        import sounddevice as sd
    except ImportError:
        return None

    try:
        chunks = []
        chunk_size = int(sr * 0.1)  # 100ms chunks
        silence_chunks = 0
        max_silence = int(silence_duration / 0.1)
        max_chunks = int(max_duration / 0.1)
        speech_started = False

        stream = sd.InputStream(samplerate=sr, channels=1, dtype="float32")
        stream.start()

        for _ in range(max_chunks):
            chunk, _ = stream.read(chunk_size)
            chunk = chunk.flatten()
            rms = float(np.sqrt(np.mean(chunk ** 2)))

            if rms > silence_threshold:
                speech_started = True
                silence_chunks = 0
                chunks.append(chunk)
            elif speech_started:
                silence_chunks += 1
                chunks.append(chunk)
                if silence_chunks >= max_silence:
                    break
            # Ignore silence before speech starts

        stream.stop()
        stream.close()

        if not chunks:
            return None
        return np.concatenate(chunks)
    except Exception as e:
        print(f"VAD capture failed: {e}", file=sys.stderr)
        return None


def main():
    parser = argparse.ArgumentParser(description="Capture and analyze voice")
    parser.add_argument("--db", required=True, help="Path to touchgrass.db")
    parser.add_argument("--session", default="", help="Session ID")
    parser.add_argument("--duration", type=float, default=3.0, help="Capture duration (seconds)")
    parser.add_argument("--vad", action="store_true", help="Use VAD (stop on silence)")
    args = parser.parse_args()

    # Capture
    if args.vad:
        audio = capture_with_vad()
    else:
        audio = capture_audio(args.duration)

    if audio is None or len(audio) < 11025:  # < 0.5 seconds
        sys.exit(0)

    # Extract features (audio discarded after this)
    from analyzer import VoiceFeatures, extract_features
    features = extract_features(audio)
    del audio  # Explicitly discard raw audio

    # Store to DB
    sys.path.insert(0, str(Path(__file__).parent.parent.parent))
    from touchgrass_lib.db import TouchgrassDB
    from touchgrass_lib.voice.state import VoiceStateDetector

    db = TouchgrassDB(args.db)
    detector = VoiceStateDetector(db)
    state = detector.detect(features, args.session)

    print(f"State: {state.detected_state} (confidence: {state.confidence})")
    db.close()


if __name__ == "__main__":
    main()
