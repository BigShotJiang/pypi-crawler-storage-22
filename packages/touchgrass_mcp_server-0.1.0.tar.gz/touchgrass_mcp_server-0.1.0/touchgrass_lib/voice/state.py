"""Voice state detection — maps features to emotional state using personal calibration."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from ..db import TouchgrassDB
from .analyzer import VoiceFeatures
from .calibrator import VoiceCalibrator


@dataclass
class VoiceState:
    """Detected voice state with confidence."""
    detected_state: str = "unknown"  # calm, excited, frustrated, pressured, reflective, etc.
    confidence: float = 0.0
    features: Optional[VoiceFeatures] = None
    calibrated: bool = False

    @property
    def is_stressed(self) -> bool:
        return self.detected_state in ("frustrated", "pressured", "peak_stress")

    @property
    def is_energized(self) -> bool:
        return self.detected_state in ("excited", "problem_solving")

    @property
    def is_fatigued(self) -> bool:
        return self.detected_state in ("reflective",) and self.confidence > 0.5

    @property
    def briefing_mode(self) -> str:
        """Determine briefing adaptation based on voice state."""
        if not self.calibrated or self.confidence < 0.3:
            return "standard"
        if self.is_stressed or self.is_fatigued:
            return "minimal"
        if self.is_energized:
            return "full_pushback"
        return "standard"

    def to_dict(self) -> dict:
        result = {
            "detected_state": self.detected_state,
            "confidence": self.confidence,
            "calibrated": self.calibrated,
            "briefing_mode": self.briefing_mode,
        }
        if self.features:
            result["features"] = self.features.to_dict()
        return result


class VoiceStateDetector:
    """Detects emotional state from voice features using personal calibration."""

    def __init__(self, db: TouchgrassDB):
        self.db = db
        self.calibrator = VoiceCalibrator(db)

    def detect(self, features: VoiceFeatures, session_id: str = "") -> VoiceState:
        """Detect voice state from features."""
        state_label, confidence = self.calibrator.classify_state(features)

        state = VoiceState(
            detected_state=state_label,
            confidence=confidence,
            features=features,
            calibrated=self.calibrator.get_profile().is_sufficient,
        )

        # Store to DB
        if features.duration_seconds > 0.5:
            self.db.store_voice_state(
                session_id=session_id,
                pitch_mean=features.pitch_mean,
                pitch_std=features.pitch_std,
                pace_wpm=features.pace_wpm,
                volume_db=features.volume_db,
                pause_ratio=features.pause_ratio,
                spectral_centroid=features.spectral_centroid,
                detected_state=state_label,
                confidence=confidence,
            )

        return state

    def get_latest(self, session_id: str = "") -> VoiceState:
        """Get most recent voice state from DB."""
        row = self.db.get_latest_voice_state(session_id)
        if not row:
            return VoiceState()

        features = VoiceFeatures(
            pitch_mean=row.get("pitch_mean", 0),
            pitch_std=row.get("pitch_std", 0),
            pace_wpm=row.get("pace_wpm", 0),
            volume_db=row.get("volume_db", 0),
            pause_ratio=row.get("pause_ratio", 0),
            spectral_centroid=row.get("spectral_centroid", 0),
        )

        return VoiceState(
            detected_state=row.get("detected_state", "unknown"),
            confidence=row.get("confidence", 0),
            features=features,
            calibrated=self.calibrator.get_profile().is_sufficient,
        )
