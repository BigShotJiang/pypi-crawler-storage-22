import os
import tough_classes as ta
import pandas as pd
import matplotlib.pyplot as plt

dir_name = "unresolved" 
#dir_name = "test_cases"
#case_name = "PetraSim_2D_Conceptual"
#case_name = "cp950_problem"
case_name = "3D five spot MINC"
test_case_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), dir_name) 

case_dir = os.path.join(test_case_dir, case_name)
case_dir = r"D:\Projects\202601\ITRI"
reader = ta.vis_reader(case_dir)
#reader.write_eleme_conne()
#reader.write_geometry()
#reader.write_incon()
#reader.write_result()
reader.write_all()


