# toykkyo-oauth-sample\nA dummy Python package version of toykkyo-oauth-sample.
