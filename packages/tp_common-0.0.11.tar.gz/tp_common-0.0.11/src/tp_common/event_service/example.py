import asyncio
import random
from datetime import datetime
from enum import Enum
from typing import cast

from pydantic import BaseModel

from tp_common.event_service.schemas import BaseEventMessage, RawEventPayload
from tp_common.event_service.service import BaseEvent
from tp_common.kafka.connector import KafkaConnector
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger

log_factory = TpLogger(env=EnvironmentType.LOCAL)


def get_kafka() -> KafkaConnector:
    return KafkaConnector("sasl_plaintext://user:user1122@@192.168.81.61:9094")


class EventGroup(str, Enum):
    USERS = "users"


class UserEvent(str, Enum):
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"

    CHANGE_NAME = "change_name"


class User(BaseModel):
    id: int
    name: str
    description: str | None = None
    is_active: bool
    created_at: datetime
    updated_at: datetime | None = None


class UserEventMessage(BaseEventMessage[User, UserEvent]):
    """Сообщение события пользователя:."""


class UserEventService(BaseEvent[UserEventMessage, UserEvent]):
    """Дескриптор события пользователей."""

    SERVICE_NAME = "postgres"
    EVENT_GROUP = EventGroup.USERS
    MESSAGE_CLASS = UserEventMessage
    EVENT_TYPE_CLASS = UserEvent

    def _build_message(self, raw: RawEventPayload | dict) -> UserEventMessage:
        """Ручная сборка: RawEventPayload (before, after, event) → UserEventMessage."""
        from tp_common.event_service.service import event_type_mapping_for

        if isinstance(raw, RawEventPayload):
            before, after, event_str = (
                raw.before,
                raw.after,
                (raw.event or "").strip().lower(),
            )
        else:
            before = raw.get("before")
            after = raw.get("after")
            event_str = (raw.get("event") or "").strip().lower()
        mapping = event_type_mapping_for(self.EVENT_TYPE_CLASS)
        canonical = mapping.get(event_str, event_str or "create")
        event = cast(UserEvent, self.EVENT_TYPE_CLASS(canonical))

        return UserEventMessage(
            before=User.model_validate(before) if before else None,
            after=User.model_validate(after) if after else None,
            event=event,
        )


logger = log_factory.get_logger("api_service")

event = UserEventService(
    connector=get_kafka(), consumer_group="worker_format_C", logger=logger
)


async def main() -> None:
    # Один consumer на всё время работы; цикл чтения — внутри контекста.
    # (Если бы with event.sub() был внутри while True, на каждой итерации был бы новый
    # join/leave группы → таймауты REQTMOUT LeaveGroup/JoinGroup.)
    while True:
        message = await event.pop_forever()

        # Случайная задержка обработки 0.05–0.5 сек
        await asyncio.sleep(random.uniform(0.05, 0.5))

        logger.debug(f"Event: {message.event}")
        logger.debug(f"Before: {message.before}")
        logger.debug(f"After: {message.after}")

        if random.random() < 0.3:
            event.commit()

        # С вероятностью 15% перепубликовать с CHANGE_NAME
        if random.random() < 0.15:
            message.event = UserEvent.CHANGE_NAME
            event.publish(message)


if __name__ == "__main__":
    asyncio.run(main())
