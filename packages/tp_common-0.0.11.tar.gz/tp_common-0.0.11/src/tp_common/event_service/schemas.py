from __future__ import annotations

from enum import Enum
from typing import Any, TypeVar

from pydantic import BaseModel, ConfigDict, Field

PayloadT = TypeVar("PayloadT", bound=BaseModel)
EventT = TypeVar("EventT", bound=Enum)


class RawEventPayload(BaseModel):
    """
    Схема сырого payload из Kafka (bytes → JSON).
    Поля before, after, event — как приходят из Debezium/топика.
    """

    before: dict[str, Any] | None = Field(
        None, description="Данные до изменений (сырой dict)"
    )
    after: dict[str, Any] | None = Field(
        None, description="Данные после изменений (сырой dict)"
    )
    event: str = Field(
        ..., description="Тип события: c/u/d/r или create/update/delete/snapshot"
    )

    model_config = ConfigDict(extra="allow")


class BaseEventMessage[PayloadT: BaseModel, EventT: Enum](BaseModel):

    before: PayloadT | None = Field(None, description="Схема до изменений")
    after: PayloadT | None = Field(None, description="Схема после изменений")
    event: EventT = Field(..., description="Тип события")

    model_config = ConfigDict(extra="allow", populate_by_name=True)
