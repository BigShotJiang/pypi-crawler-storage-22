import enum
import json
import logging
from typing import Any, ClassVar, TypeVar

from confluent_kafka import Consumer, KafkaError, KafkaException, Message, Producer
from pydantic import ValidationError

from tp_common.decorators.decorator_retry_forever import retry_forever
from tp_common.event_service.schemas import BaseEventMessage, RawEventPayload
from tp_common.kafka.connector import KafkaConnector

logger = logging.getLogger(__name__)

MessageT = TypeVar("MessageT", bound=BaseEventMessage)
EventEnumT = TypeVar("EventEnumT", bound=enum.Enum)


BASE_EVENT_TYPE_MAPPING: dict[str, str] = {
    "c": "create",
    "u": "update",
    "d": "delete",
    "r": "snapshot",
    "create": "create",
    "update": "update",
    "delete": "delete",
    "snapshot": "snapshot",
}


def event_type_mapping_for(enum_cls: type[enum.Enum]) -> dict[str, str]:
    """
    Маппинг для преобразования строки в член enum в сервисе.
    Базовые ключи (c, u, d, r, create, ...) + все значения enum_cls (для своих типов вроде change_name).
    """
    mapping = dict(BASE_EVENT_TYPE_MAPPING)
    for member in enum_cls:
        v = member.value if isinstance(member.value, str) else str(member.value)
        mapping[v.lower()] = v
    return mapping


class BaseEvent[MessageT: BaseEventMessage, EventEnumT: enum.Enum]:
    SERVICE_NAME: ClassVar[str]
    EVENT_GROUP: ClassVar[enum.Enum]
    EVENT_TYPE_CLASS: ClassVar[type[enum.Enum]]

    _REQUIRED_EVENT_TYPES: ClassVar[dict[str, str]] = {
        "CREATE": "create",
        "UPDATE": "update",
        "DELETE": "delete",
    }

    def __init__(
        self,
        connector: KafkaConnector,
        consumer_group: str | None = None,
        subscribe_to: list[str] | None = None,
        logger: logging.Logger | None = None,
    ) -> None:
        self.connector = connector
        self.consumer_group = consumer_group
        self.subscribe_to = subscribe_to
        self._consumer: Consumer | None = None
        self._auto_commit: bool = False
        self._last_message: Any | None = None
        self._sub: bool = False

        self.logger: logging.Logger = (
            logger if logger is not None else logging.getLogger(__name__)
        )

    def set_auto_commit(self) -> None:
        self._auto_commit = True

    def _topic(self) -> str:
        return f"events.{self.SERVICE_NAME}.public.{self.EVENT_GROUP.value}"

    def _get_consumer(self) -> Consumer:

        if self.connector is None:
            raise ValueError("connector не задан, невозможно создать consumer")

        if not self.consumer_group or not str(self.consumer_group).strip():
            raise ValueError(
                "consumer_group должен быть непустой строкой для создания consumer"
            )

        if self._consumer is None:
            self._consumer = self.connector.get_consumer(group_id=self.consumer_group)
        return self._consumer

    def sub(self) -> None:
        if not self._sub:
            self._get_consumer().subscribe([self._topic()])
            self._sub = True

    def commit(self) -> None:
        if self._last_message:
            self._get_consumer().commit(self._last_message)

    def pop(self, timeout: float = 60) -> MessageT | None:
        """
        Читает одно сообщение из Kafka consumer (должен быть активен внутри контекста sub()).

        timeout: Таймаут ожидания сообщения в секундах.
        Возвращает распарсенное сообщение (MessageT) или None, если сообщений нет или ошибка парсинга.
        """
        self.sub()

        msg = self._get_consumer().poll(timeout=timeout)
        if msg is None:
            self._sub = False
            return None

        if msg.error():
            self.logger.warning("Ошибка Kafka при чтении: %s", msg.error())
            return None

        self._last_message = msg

        value = msg.value()
        if value is None:
            self.logger.debug("Получено сообщение с пустым value")
            return None

        if self._auto_commit:
            self.commit()

        return self.message_from_value(value)

    @retry_forever(
        start_message="Ожидание сообщения из Kafka (timeout={timeout} сек)",
        error_message="Нет сообщения за {timeout} сек, повтор #{retry_count}: {e}",
    )
    async def pop_forever(self, timeout: float = 60) -> MessageT:
        while True:
            msg = self.pop(timeout=timeout)
            if msg is None:
                continue
            break
        return msg

    @retry_forever(
        start_message="Отправка сообщения в Kafka",
        error_message="Ошибка доставки в Kafka, повтор #{retry_count}: {e}",
    )
    async def publish_retry(
        self,
        message: MessageT,
        flush_timeout: float = 10.0,
    ) -> None:
        return self.publish(message=message, flush_timeout=flush_timeout)

    def publish(
        self,
        message: MessageT,
        flush_timeout: float = 10.0,
    ) -> None:
        """
        Отправить сообщение в топик.

        После produce() вызывается flush(timeout=flush_timeout), чтобы очередь
        успела опустошиться до завершения процесса (избегаем TERMINATE с
        "message still in queue"). Для fire-and-forget передай flush_timeout=0.
        """
        producer = self._fabrica_producer()
        value = message.model_dump_json().encode("utf-8")
        producer.produce(self._topic(), value=value, on_delivery=self._on_delivery)
        if flush_timeout > 0:
            producer.flush(timeout=flush_timeout)

    @staticmethod
    def _on_delivery(err: KafkaError | None, msg: Message) -> None:
        if err:
            logger.error("Kafka delivery error: %s", err)
            raise KafkaException(err)

        logger.debug(
            "Kafka delivered: topic=%s partition=%s offset=%s",
            msg.topic(),
            msg.partition(),
            msg.offset(),
        )

    def _value_to_raw_payload(
        self, value: bytes | str | dict[str, Any]
    ) -> RawEventPayload | None:
        """
        Парсит сырое значение из Kafka: bytes/str → JSON → RawEventPayload (before, after, event).
        Если передан уже словарь — валидирует в RawEventPayload.
        """
        data = self._value_to_dict(value)
        if data is None:
            return None
        try:
            return RawEventPayload.model_validate(data)
        except ValidationError as e:
            self.logger.warning(
                "Сырой payload не соответствует схеме (before, after, event): %s",
                e,
            )
            return None

    def _build_message(self, raw: RawEventPayload | dict[str, Any]) -> MessageT:
        """
        Собирает сообщение из RawEventPayload или словаря. Переопредели в наследнике,
        если имена/структура полей отличаются от MESSAGE_CLASS (before, after, event).
        По умолчанию: model_validate(raw).
        """
        msg_cls = getattr(self.__class__, "MESSAGE_CLASS", None)
        if msg_cls is None:
            raise TypeError(f"MESSAGE_CLASS не задан у {self.__class__.__name__}")
        data = raw.model_dump() if isinstance(raw, RawEventPayload) else raw
        return msg_cls.model_validate(data)

    def validation_message(
        self, data: RawEventPayload | dict[str, Any]
    ) -> MessageT | None:
        """
        Собирает сообщение из RawEventPayload/словаря через _build_message (ручная сборка в наследнике).
        При ошибке логирует и возвращает None.
        """
        try:
            return self._build_message(data)
        except (ValidationError, TypeError) as e:
            self.logger.warning(
                "Ошибка сборки сообщения у %s: %s",
                self.__class__.__name__,
                e,
                exc_info=True,
            )
            return None

    def message_from_value(
        self, value: bytes | str | dict[str, Any]
    ) -> MessageT | None:
        """
        Парсит сырое значение из Kafka: bytes/str → JSON → RawEventPayload (before, after, event) → message.
        """
        raw = self._value_to_raw_payload(value)
        if raw is None:
            return None
        return self.validation_message(raw)

    def _value_to_dict(
        self, value: bytes | str | dict[str, Any]
    ) -> dict[str, Any] | None:
        """Только парсинг: bytes/str → JSON → dict. Без валидации в RawEventPayload."""
        if isinstance(value, dict):
            return value
        if isinstance(value, bytes):
            try:
                data = json.loads(value.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError) as e:
                self.logger.warning("Не удалось распарсить value (bytes): %s", e)
                return None
        elif isinstance(value, str):
            try:
                data = json.loads(value)
            except json.JSONDecodeError as e:
                self.logger.warning("Не удалось распарсить value (str): %s", e)
                return None
        else:
            self.logger.warning("Неподдерживаемый тип value: %s", type(value).__name__)
            return None
        if not isinstance(data, dict):
            self.logger.warning("JSON не является объектом: %s", type(data).__name__)
            return None
        return data

    def _fabrica_producer(self) -> Producer:
        self._producer = self.connector.get_producer()
        return self._producer

    def _should_process_event(
        self,
        event: EventEnumT | None,
        subscribe_to: list[EventEnumT] | None = None,
    ) -> bool:
        active_filter = subscribe_to if subscribe_to is not None else self.subscribe_to
        if active_filter is None:
            return True
        if event is None:
            return False
        return event in active_filter

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """
        Валидация при создании наследника.
        Проверяет, что SERVICE_NAME, EVENT_GROUP, MESSAGE_CLASS и EVENT_TYPE_CLASS заданы,
        EVENT_TYPE_CLASS содержит обязательные поля CREATE, UPDATE, DELETE.
        """
        super().__init_subclass__(**kwargs)

        # Проверка наличия обязательных атрибутов
        if not hasattr(cls, "SERVICE_NAME") or not isinstance(
            getattr(cls, "SERVICE_NAME", None), str
        ):
            raise TypeError(
                f"{cls.__name__} должен определить SERVICE_NAME (непустая строка)"
            )

        service_name = cls.SERVICE_NAME
        if not service_name or not service_name.strip():
            raise TypeError(
                f"{cls.__name__}.SERVICE_NAME не должен быть пустой строкой"
            )

        if not hasattr(cls, "EVENT_GROUP"):
            raise TypeError(f"{cls.__name__} должен определить EVENT_GROUP")

        if not hasattr(cls, "MESSAGE_CLASS"):
            raise TypeError(f"{cls.__name__} должен определить MESSAGE_CLASS")

        if not hasattr(cls, "EVENT_TYPE_CLASS"):
            raise TypeError(f"{cls.__name__} должен определить EVENT_TYPE_CLASS")

        # Проверка, что EVENT_TYPE_CLASS содержит обязательные поля create/update/delete
        event_type_cls = cls.EVENT_TYPE_CLASS
        if not isinstance(event_type_cls, type) or not issubclass(
            event_type_cls, enum.Enum
        ):
            raise TypeError(
                f"{cls.__name__}.EVENT_TYPE_CLASS должен быть подклассом enum.Enum"
            )
        for name, expected_value in BaseEvent._REQUIRED_EVENT_TYPES.items():
            if not hasattr(event_type_cls, name):
                raise TypeError(
                    f"{cls.__name__}.EVENT_TYPE_CLASS должен содержать поле {name}"
                )
            member = getattr(event_type_cls, name)
            actual_value = member.value if hasattr(member, "value") else member
            if actual_value != expected_value:
                raise TypeError(
                    f"{cls.__name__}.EVENT_TYPE_CLASS.{name} должен быть равен "
                    f"{expected_value!r}, получено {actual_value!r}"
                )
