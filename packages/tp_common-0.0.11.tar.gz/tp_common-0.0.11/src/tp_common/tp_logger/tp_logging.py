"""
Централизованный модуль для получения логгеров в проекте.

Единая точка входа — класс LoggerFactory(env).get_logger(name, job=...).
Все настройки форматирования и обработки логов находятся здесь.
Очередь и поток для асинхронного логирования общие для всех экземпляров (синглтоны).
"""

from __future__ import annotations

import logging
import queue
import sys
import threading
import traceback
import uuid
from typing import Any

from pythonjsonlogger import json

from tp_common.tp_logger.schemas import EnvironmentType

# ============================================================================
# ЕДИНАЯ КОНФИГУРАЦИЯ ФОРМАТТЕРА
# ============================================================================
# Все изменения формата логов должны производиться здесь


def _create_formatter(
    env: EnvironmentType, job: str | int | uuid.UUID | None = None
) -> json.JsonFormatter:
    """
    Создаёт JSON-форматтер для логов.

    Единая точка настройки формата логов для всего проекта.

    Args:
        env: Окружение (для статического поля в логах).
        job: Идентификатор задачи (для статических полей, опционально).

    Returns:
        Настроенный JSON форматтер.
    """
    static_fields: dict[Any, Any] = {"env": env.value}
    if job is not None:
        static_fields["job"] = str(job)

    return json.JsonFormatter(
        "{asctime}{levelname}{message}{env}",
        style="{",
        json_ensure_ascii=False,
        rename_fields={
            "asctime": "timestamp",
            "levelname": "level",
            "message": "msg",
        },
        static_fields=static_fields,
    )


# ============================================================================
# ФИЛЬТР ДЛЯ ОБРАБОТКИ ИСКЛЮЧЕНИЙ
# ============================================================================


class ExceptionFormatterFilter(logging.Filter):
    """Filter that formats exceptions into JSON structure and adds to extra."""

    def filter(self, record: logging.LogRecord) -> bool:
        """Format exception info into structured JSON if present."""
        if record.exc_info and record.exc_info[0] is not None:
            e_type, e, exc_traceback = record.exc_info

            if exc_traceback:
                tb = traceback.extract_tb(exc_traceback)
                if tb:
                    last = tb[-1]
                    record.last_tb_line = (
                        f"{last.filename}:{last.lineno} — {last.name} → {last.line}"
                    )

            record.error = e_type if e_type else ""
            record.error_message = str(e) if e else ""

        return True


# ============================================================================
# АСИНХРОННАЯ ОБРАБОТКА ЛОГОВ
# ============================================================================


class QueueHandler(logging.Handler):
    """Handler that sends log records to a queue for async processing."""

    def __init__(self, log_queue: queue.Queue[logging.LogRecord | None]) -> None:
        super().__init__()
        self.queue = log_queue

    def emit(self, record: logging.LogRecord) -> None:
        """Put the record into the queue."""
        try:
            self.queue.put_nowait(record)
        except queue.Full:
            self.handleError(record)
        except Exception:
            self.handleError(record)


def _log_listener_thread(
    log_queue: queue.Queue[logging.LogRecord | None],
    env: EnvironmentType,
) -> None:
    """Поток для обработки логов из очереди."""

    formatter = _create_formatter(env)
    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setFormatter(formatter)

    while True:
        try:
            record = log_queue.get()
            if record is None:  # Сигнал для завершения
                break
            stdout_handler.emit(record)
        except (KeyboardInterrupt, SystemExit):
            break
        except Exception:
            import traceback

            traceback.print_exc(file=sys.stderr)


# -----------------------------------------------------------------------------
# Общая очередь и поток (синглтоны)
# -----------------------------------------------------------------------------
# Все экземпляры LoggerFactory с use_queue=True используют одну очередь и один поток.
# Это стандартная практика для асинхронного логирования: один listener на всё
# приложение — меньше памяти и контекстных переключений, единый формат вывода.

_log_queue: queue.Queue[logging.LogRecord | None] | None = None
_log_thread: threading.Thread | None = None
_log_lock = threading.Lock()


def _get_log_queue(env: EnvironmentType) -> queue.Queue[logging.LogRecord | None]:
    """Получает или создаёт глобальную очередь для логов (один раз на приложение)."""
    global _log_queue, _log_thread

    if _log_queue is None:
        with _log_lock:
            if _log_queue is None:
                _log_queue = queue.Queue(-1)  # -1 = без ограничения размера
                _log_thread = threading.Thread(
                    target=_log_listener_thread,
                    args=(_log_queue, env),
                    daemon=True,
                    name="LogListenerThread",
                )
                _log_thread.start()

    return _log_queue


# ============================================================================
# ФАБРИКА ЛОГГЕРОВ
# ============================================================================


class TpLogger:
    """
    Фабрика логгеров с фиксированной средой (env) и общей очередью.

    Создаётся один раз на уровне приложения с нужной средой (DEV/PROD/...).
    В разных местах из неё получают логгеры через get_logger(name, job=...).
    job передаётся в get_logger, а не в конструктор — у каждого логгера свой job.

    Все экземпляры LoggerFactory с use_queue=True пишут в одну общую очередь и один
    фоновый поток (синглтоны на уровне модуля).

    Использование:
        from src.logging import LoggerFactory
        from tp_helper.types.environment_type import EnvironmentType

        log_factory = LoggerFactory(EnvironmentType.DEV)
        logger = log_factory.get_logger("api_service")
        worker_logger = log_factory.get_logger("task_worker", job="task_123")

        # Настройка uvicorn/fastapi при старте
        LoggerFactory.setup_standard_loggers(EnvironmentType.DEV)
    """

    def __init__(self, env: EnvironmentType) -> None:
        """
        Args:
            env: Окружение (local/dev/staging/prod) для поля в логах.
        """
        self._env = env

    def get_logger(
        self,
        name: str | int,
        job: str | uuid.UUID | int | None = None,
        # loki_handler: LokiHandler | None = None,
        use_queue: bool = True,
    ) -> logging.Logger:
        """
        Возвращает логгер с именем name и опциональным job.

        Args:
            name: Имя логгера (идентификация в логах).
            job: Идентификатор задачи (опционально), попадает в статические поля.
            use_queue: True — асинхронная запись через общую очередь (по умолчанию).

        Returns:
            logging.Logger.
        """
        log_queue = _get_log_queue(self._env) if use_queue else None

        logger = logging.getLogger(f"app_logger_{name}")
        logger.setLevel(logging.DEBUG)
        logger.propagate = False
        logger.addFilter(ExceptionFormatterFilter())

        if use_queue and log_queue:
            logger.addHandler(QueueHandler(log_queue))
        else:
            formatter = _create_formatter(self._env, job)
            stdout_handler = logging.StreamHandler(sys.stdout)
            stdout_handler.setFormatter(formatter)
            logger.addHandler(stdout_handler)

        return logger

    @staticmethod
    def setup_standard_loggers(env: EnvironmentType) -> None:
        """
        Настраивает логирование для uvicorn и fastapi (единый JSON-формат).

        Вызывать при инициализации API-приложения.
        """
        json_formatter = _create_formatter(env)
        standard_handler = logging.StreamHandler(sys.stdout)
        standard_handler.setFormatter(json_formatter)

        uvicorn_logger = logging.getLogger("uvicorn")
        uvicorn_logger.setLevel(logging.INFO)
        uvicorn_logger.handlers = [standard_handler]
        uvicorn_logger.propagate = False

        uvicorn_access_logger = logging.getLogger("uvicorn.access")
        uvicorn_access_logger.setLevel(logging.WARNING)
        uvicorn_access_logger.propagate = False

        fastapi_logger = logging.getLogger("fastapi")
        fastapi_logger.setLevel(logging.INFO)
        fastapi_logger.handlers = [standard_handler]
        fastapi_logger.propagate = False

        logging.getLogger("src.infrastructure.clients").setLevel(logging.INFO)
