class BaseInfrastructureException(Exception):
    pass
