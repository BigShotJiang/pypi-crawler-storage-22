"""Исключения для базового HTTP клиента."""


class BaseClientException(Exception):
    """Базовое исключение для всех ошибок клиента."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
        status_code: int | None = None,
        response_body: str | None = None,
    ) -> None:
        super().__init__(message)
        self.url = url
        self.status_code = status_code
        self.response_body = response_body


class ClientResponseErrorException(BaseClientException):
    """Исключение при неуспешном HTTP статусе (>=400)."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
        status_code: int | None = None,
        response_body: str | None = None,
    ) -> None:
        super().__init__(message, url, status_code, response_body)


class ClientTimeoutException(BaseClientException):
    """Исключение при таймауте соединения."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
    ) -> None:
        super().__init__(message, url)


class ClientProxyException(BaseClientException):
    """Исключение при ошибке прокси."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
        proxy: str | None = None,
    ) -> None:
        super().__init__(message, url)
        self.proxy = proxy


class ClientConnectionException(BaseClientException):
    """Исключение при ошибке соединения (не удалось установить соединение)."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
    ) -> None:
        super().__init__(message, url)


class ClientDNSException(BaseClientException):
    """Исключение при ошибке DNS (не удалось разрешить доменное имя)."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
    ) -> None:
        super().__init__(message, url)
