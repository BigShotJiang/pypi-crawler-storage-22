"""Доменные исключения для обработки ошибок в воркерах."""

from tp_common.base.base_client.client_exceptions import BaseClientException


class BaseBusinessErrorException(BaseClientException):
    """Базовое исключение для бизнес-ошибок (400, 401, 403, 404, 422)."""

    pass


class BaseServerErrorException(BaseClientException):
    """Базовое исключение для ошибок сервера (500, 502, 503, 504)."""

    pass


class BaseNetworkErrorException(BaseClientException):
    """Базовое исключение для сетевых ошибок (таймауты, соединение, DNS)."""

    pass


class BaseProxyErrorException(BaseClientException):
    """Базовое исключение для ошибок прокси."""

    pass


class AuthorizationException(BaseBusinessErrorException):
    """Исключение при ошибке авторизации (401, 403)."""

    pass


class ValidationException(BaseBusinessErrorException):
    """Исключение при ошибке валидации данных (400, 422)."""

    pass


class ResourceNotFoundException(BaseBusinessErrorException):
    """Исключение при отсутствии ресурса (404)."""

    pass


class ServerException(BaseServerErrorException):
    """Исключение при ошибке сервера (500, 502, 503, 504)."""

    pass


class TooManyRequestsException(BaseProxyErrorException):
    """Исключение при превышении лимита запросов (429)."""

    pass


class ServiceUnavailableException(BaseServerErrorException):
    """Исключение при недоступности сервиса (502, 503, 504)."""

    pass
