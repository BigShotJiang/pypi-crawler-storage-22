"""
Централизованный модуль для получения логгеров в проекте.

Единая точка входа — класс Logger(env, job=...).get_logger(name).
Все настройки форматирования и обработки логов находятся здесь.
Очередь и поток для асинхронного логирования общие для всех экземпляров (синглтоны).
"""

from __future__ import annotations

import logging
import queue
import sys
import threading
import traceback
import uuid
from typing import Any

# from logging_loki import LokiHandler
from pythonjsonlogger import json
from tp_helper.types.environment_type import EnvironmentType

# ============================================================================
# ЕДИНАЯ КОНФИГУРАЦИЯ ФОРМАТТЕРА
# ============================================================================
# Все изменения формата логов должны производиться здесь


def _create_formatter(
    env: EnvironmentType, job: str | int | uuid.UUID | None = None
) -> json.JsonFormatter:
    """
    Создаёт JSON-форматтер для логов.

    Единая точка настройки формата логов для всего проекта.

    Args:
        env: Окружение (для статического поля в логах).
        job: Идентификатор задачи (для статических полей, опционально).

    Returns:
        Настроенный JSON форматтер.
    """
    static_fields = {"env": env.value}
    if job is not None:
        static_fields["job"] = str(job)

    return json.JsonFormatter(
        "{asctime}{levelname}{message}{env}{trace_id}",
        style="{",
        json_ensure_ascii=False,
        rename_fields={
            "asctime": "timestamp",
            "levelname": "level",
            "message": "msg",
        },
        static_fields=static_fields,
    )


# ============================================================================
# ФИЛЬТР ДЛЯ ОБРАБОТКИ ИСКЛЮЧЕНИЙ
# ============================================================================


class ExceptionFormatterFilter(logging.Filter):
    """Filter that formats exceptions into JSON structure and adds to extra."""

    def filter(self, record: logging.LogRecord) -> bool:
        """Format exception info into structured JSON if present."""
        if record.exc_info and record.exc_info[0] is not None:
            e_type, e, exc_traceback = record.exc_info

            if exc_traceback:
                tb = traceback.extract_tb(exc_traceback)
                if tb:
                    last = tb[-1]
                    record.last_tb_line = (
                        f"{last.filename}:{last.lineno} — {last.name} → {last.line}"
                    )

            record.error = e_type if e_type else ""
            record.error_message = str(e) if e else ""

        return True


# ============================================================================
# АСИНХРОННАЯ ОБРАБОТКА ЛОГОВ
# ============================================================================


class QueueHandler(logging.Handler):
    """Handler that sends log records to a queue for async processing."""

    def __init__(self, log_queue: queue.Queue[logging.LogRecord | None]) -> None:
        super().__init__()
        self.queue = log_queue

    def emit(self, record: logging.LogRecord) -> None:
        """Put the record into the queue."""
        try:
            self.queue.put_nowait(record)
        except queue.Full:
            self.handleError(record)
        except Exception:
            self.handleError(record)


def _log_listener_thread(
    log_queue: queue.Queue[logging.LogRecord | None],
    env: EnvironmentType,
) -> None:
    """Поток для обработки логов из очереди."""

    formatter = _create_formatter(env)
    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setFormatter(formatter)

    while True:
        try:
            record = log_queue.get()
            if record is None:  # Сигнал для завершения
                break
            stdout_handler.emit(record)
        except (KeyboardInterrupt, SystemExit):
            break
        except Exception:
            import traceback

            traceback.print_exc(file=sys.stderr)


# -----------------------------------------------------------------------------
# Общая очередь и поток (синглтоны)
# -----------------------------------------------------------------------------
# Все экземпляры Logger с use_queue=True используют одну очередь и один поток.
# Это стандартная практика для асинхронного логирования: один listener на всё
# приложение — меньше памяти и контекстных переключений, единый формат вывода.

_log_queue: queue.Queue[logging.LogRecord | None] | None = None
_log_thread: threading.Thread | None = None
_log_lock = threading.Lock()


def _get_log_queue(env: EnvironmentType) -> queue.Queue[logging.LogRecord | None]:
    """Получает или создаёт глобальную очередь для логов (один раз на приложение)."""
    global _log_queue, _log_thread

    if _log_queue is None:
        with _log_lock:
            if _log_queue is None:
                _log_queue = queue.Queue(-1)  # -1 = без ограничения размера
                _log_thread = threading.Thread(
                    target=_log_listener_thread,
                    args=(_log_queue, env),
                    daemon=True,
                    name="LogListenerThread",
                )
                _log_thread.start()

    return _log_queue


# ============================================================================
# ОБЁРТКА ЛОГГЕРА С TRACE_ID
# ============================================================================


class TracingLogger:
    """
    Обёртка над logging.Logger с методами set_trace_id / clear_trace_id.

    trace_id хранится в экземпляре: простой вариант, не зависит от contextvars.
    Передавайте этот логгер по цепочке вызовов — везде будет один и тот же trace_id.

    Ограничение: один экземпляр логгера не должен использоваться из нескольких
    параллельных asyncio-задач с разными trace_id (будут перезаписывать друг друга).
    Для цикла «одна задача за раз» — подходит идеально.
    """

    def __init__(self, logger: logging.Logger) -> None:
        self._logger = logger
        self._trace_id: str | uuid.UUID | None = None

    def set_trace_id(self, value: str | uuid.UUID | None) -> None:
        """Устанавливает trace_id для этого экземпляра логгера."""
        self._trace_id = value

    def clear_trace_id(self) -> None:
        """Сбрасывает trace_id."""
        self._trace_id = None

    def _merge_extra(self, kwargs: dict) -> dict:
        extra = dict(kwargs.get("extra") or {})
        if self._trace_id is not None:
            extra["trace_id"] = str(self._trace_id)
        return {**kwargs, "extra": extra}

    def debug(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._logger.debug(msg, *args, **self._merge_extra(kwargs))

    def info(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._logger.info(msg, *args, **self._merge_extra(kwargs))

    def warning(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._logger.warning(msg, *args, **self._merge_extra(kwargs))

    def error(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._logger.error(msg, *args, **self._merge_extra(kwargs))

    def exception(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._logger.exception(msg, *args, **self._merge_extra(kwargs))

    def critical(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._logger.critical(msg, *args, **self._merge_extra(kwargs))

    def log(self, level: int, msg: str, *args: Any, **kwargs: Any) -> None:
        self._logger.log(level, msg, *args, **self._merge_extra(kwargs))

    @property
    def logger(self) -> logging.Logger:
        """Доступ к исходному logging.Logger при необходимости."""
        return self._logger


# ============================================================================
# КЛАСС LOGGER — ЕДИНАЯ ТОЧКА ВХОДА ДЛЯ ЛОГГЕРОВ
# ============================================================================


class Logger:
    """
    Фабрика логгеров с фиксированной средой (env) и общей очередью.

    Создаётся один раз на уровне приложения с нужной средой (DEV/PROD/...).
    В разных местах из неё получают логгеры через get_logger(name, job=...).
    job передаётся в get_logger, а не в конструктор — у каждого логгера свой job.

    Все экземпляры Logger с use_queue=True пишут в одну общую очередь и один
    фоновый поток (синглтоны на уровне модуля).

    Использование:
        from tp_helper.logging import Logger
        from tp_helper.types.environment_type import EnvironmentType

        # Один раз на уровне приложения — фабрика с желаемой средой
        log_factory = Logger(EnvironmentType.DEV)

        # В разных местах получаем логгеры (job — при необходимости)
        logger = log_factory.get_logger("api_service")
        worker_logger = log_factory.get_logger("task_worker", job="task_123")

        # trace_id для сквозной трассировки (например, в воркере по одной задаче)
        # logger.set_trace_id(uuid.uuid4())
        # logger.debug("Получена задача", extra=task)  # в логе будет trace_id

        # Настройка uvicorn/fastapi при старте
        Logger.setup_standard_loggers(EnvironmentType.DEV)
    """

    def __init__(self, env: EnvironmentType) -> None:
        """
        Args:
            env: Окружение (local/dev/staging/prod) для поля в логах.
        """
        self._env = env

    def get_logger(
        self,
        name: str | int,
        job: str | uuid.UUID | int | None = None,
        # loki_handler: LokiHandler | None = None,
        use_queue: bool = True,
    ) -> TracingLogger:
        """
        Возвращает логгер с именем name и опциональным job.

        Возвращаемый объект — TracingLogger (обёртка с set_trace_id/clear_trace_id).
        trace_id хранится в экземпляре и попадает во все записи лога; можно
        передавать логгер по цепочке вызовов.

        Args:
            name: Имя логгера (идентификация в логах).
            job: Идентификатор задачи (опционально), попадает в статические поля.
            loki_handler: Опциональный handler для отправки в Loki.
            use_queue: True — асинхронная запись через общую очередь (по умолчанию).

        Returns:
            TracingLogger с методами set_trace_id/clear_trace_id.
        """
        log_queue = _get_log_queue(self._env) if use_queue else None

        logger = logging.getLogger(f"app_logger_{name}")
        logger.setLevel(logging.DEBUG)
        logger.propagate = False
        logger.addFilter(ExceptionFormatterFilter())

        if use_queue and log_queue:
            logger.addHandler(QueueHandler(log_queue))
        else:
            formatter = _create_formatter(self._env, job)
            stdout_handler = logging.StreamHandler(sys.stdout)
            stdout_handler.setFormatter(formatter)
            logger.addHandler(stdout_handler)

        # if loki_handler:
        #     formatter = _create_formatter(self._env, job)
        #     loki_handler.setFormatter(formatter)
        #     logger.addHandler(loki_handler)

        return TracingLogger(logger)

    @staticmethod
    def setup_standard_loggers(env: EnvironmentType) -> None:
        """
        Настраивает логирование для uvicorn и fastapi (единый JSON-формат).

        Вызывать при инициализации API-приложения.
        """
        json_formatter = _create_formatter(env)
        standard_handler = logging.StreamHandler(sys.stdout)
        standard_handler.setFormatter(json_formatter)

        uvicorn_logger = logging.getLogger("uvicorn")
        uvicorn_logger.setLevel(logging.INFO)
        uvicorn_logger.handlers = [standard_handler]
        uvicorn_logger.propagate = False

        uvicorn_access_logger = logging.getLogger("uvicorn.access")
        uvicorn_access_logger.setLevel(logging.WARNING)
        uvicorn_access_logger.propagate = False

        fastapi_logger = logging.getLogger("fastapi")
        fastapi_logger.setLevel(logging.INFO)
        fastapi_logger.handlers = [standard_handler]
        fastapi_logger.propagate = False

        logging.getLogger("src.infrastructure.clients").setLevel(logging.INFO)
