poetry run alembic revision --autogenerate -m "НОМЕР_ВЕРСИИ"
poetry run alembic upgrade head
