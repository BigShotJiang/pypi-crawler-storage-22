"""Преобразование сырого сообщения из Kafka в типизированное сообщение события."""

import enum
import json
import logging
from typing import Any, TypeVar, get_args, get_origin

from pydantic import BaseModel

from tp_common.event_service.exceptions import EventMessageParseError
from tp_common.event_service.schemas import BaseEventMessage, RawEventPayload

MessageT = TypeVar("MessageT", bound=BaseEventMessage)
EventEnumT = TypeVar("EventEnumT", bound=enum.Enum)


def _get_enum_class(annotation: Any) -> type[enum.Enum] | None:
    """Извлекает класс enum из аннотации (Enum, Optional[Enum], list[Enum])."""
    origin = get_origin(annotation)
    if origin is not None:
        for arg in get_args(annotation):
            if (
                arg is not type(None)
                and isinstance(arg, type)
                and issubclass(arg, enum.Enum)
            ):
                return arg
        return None
    if isinstance(annotation, type) and issubclass(annotation, enum.Enum):
        return annotation
    return None


def _get_nested_model_class(annotation: Any) -> type[BaseModel] | None:
    """Извлекает класс Pydantic-модели из аннотации (для вложенных payload, в т.ч. list[Model])."""
    origin = get_origin(annotation)
    if origin is not None:
        for arg in get_args(annotation):
            if (
                arg is not type(None)
                and isinstance(arg, type)
                and issubclass(arg, BaseModel)
            ):
                return arg
        return None
    if isinstance(annotation, type) and issubclass(annotation, BaseModel):
        return annotation
    return None


def _resolve_enum_from_string(s: str, enum_cls: type[enum.Enum]) -> Any:
    """Сопоставляет строку с enum: сначала по имени члена (key), затем по value.
    SQLAlchemy в БД хранит enum по имени (key), поэтому приоритет — поиск по name.
    """
    if not isinstance(s, str):
        return s
    s_upper = s.upper().replace("-", "_")
    for member in enum_cls:
        if member.name.upper().replace("-", "_") == s_upper:
            return member.value
        if str(member.value).upper().replace("-", "_") == s_upper:
            return member.value
    return s


def _normalize_payload_enums_by_schema(
    data: dict[str, Any],
    model_cls: type[BaseModel],
) -> dict[str, Any]:
    """Рекурсивно приводит поля payload к value enum по схеме модели.
    Строки, пришедшие как имена enum (как хранит SQLAlchemy), заменяются на value для Pydantic.
    """
    if not isinstance(data, dict):
        return data
    result: dict[str, Any] = {}
    for key, value in data.items():
        if key not in model_cls.model_fields:
            result[key] = value
            continue
        field_info = model_cls.model_fields[key]
        ann = field_info.annotation
        enum_cls = _get_enum_class(ann)
        nested_cls = _get_nested_model_class(ann) if enum_cls is None else None
        if enum_cls is not None:
            if isinstance(value, str):
                result[key] = _resolve_enum_from_string(value, enum_cls)
            elif isinstance(value, list):
                result[key] = [
                    (
                        _resolve_enum_from_string(item, enum_cls)
                        if isinstance(item, str)
                        else item
                    )
                    for item in value
                ]
            else:
                result[key] = value
        elif nested_cls is not None and isinstance(value, dict):
            result[key] = _normalize_payload_enums_by_schema(value, nested_cls)
        elif nested_cls is not None and isinstance(value, list):
            result[key] = [
                (
                    _normalize_payload_enums_by_schema(item, nested_cls)
                    if isinstance(item, dict)
                    else item
                )
                for item in value
            ]
        else:
            result[key] = value
    return result


# Маппинг типов событий (c/u/d/r и т.д.) — дублируем для независимости модуля
_BASE_EVENT_TYPE_MAPPING: dict[str, str] = {
    "c": "create",
    "u": "update",
    "d": "delete",
    "r": "snapshot",
    "create": "create",
    "update": "update",
    "delete": "delete",
    "snapshot": "snapshot",
}


def _event_type_mapping_for(enum_cls: type[enum.Enum]) -> dict[str, str]:
    mapping = dict(_BASE_EVENT_TYPE_MAPPING)
    for member in enum_cls:
        v = member.value if isinstance(member.value, str) else str(member.value)
        mapping[v.lower()] = v
    return mapping


def _get_payload_class(msg_cls: type[BaseEventMessage]) -> type[BaseModel]:
    """Извлекает класс payload (PayloadT) из MESSAGE_CLASS через аннотации полей."""
    hints = msg_cls.model_fields
    for field_name in ("before", "after"):
        if field_name in hints:
            annotation = hints[field_name].annotation
            origin = get_origin(annotation)
            if origin is not None:
                args = get_args(annotation)
                for arg in args:
                    if arg is not type(None) and isinstance(arg, type):
                        return arg
            elif isinstance(annotation, type):
                return annotation
    raise TypeError(f"Не удалось извлечь PayloadT из {msg_cls.__name__}.before/after")


class EventMessageTransformer[MessageT: BaseEventMessage, EventEnumT: enum.Enum]:
    """
    Преобразует сырое значение из Kafka (bytes/str/dict) в типизированное сообщение
    события (MessageT). При ошибке валидации схемы логирует Critical и пробрасывает
    исключение (strict).
    """

    def __init__(
        self,
        message_class: type[MessageT],
        event_type_class: type[EventEnumT],
        logger: logging.Logger,
        service_name: str = "",
    ) -> None:
        self._message_class = message_class
        self._event_type_class = event_type_class
        self._logger = logger
        self._service_name = service_name or message_class.__name__

    def value_to_dict(self, value: bytes | str | dict[str, Any]) -> dict[str, Any]:
        """Парсит value (bytes/str/dict) в словарь без валидации схемы. При любой ошибке — EventMessageParseError."""
        if isinstance(value, dict):
            return value
        if isinstance(value, bytes):
            try:
                data = json.loads(value.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError) as e:
                raise EventMessageParseError(
                    f"Не удалось распарсить value (bytes): {e}"
                ) from e
        elif isinstance(value, str):
            try:
                data = json.loads(value)
            except json.JSONDecodeError as e:
                raise EventMessageParseError(
                    f"Не удалось распарсить value (str): {e}"
                ) from e
        else:
            raise EventMessageParseError(
                f"Неподдерживаемый тип value: {type(value).__name__}"
            )
        if not isinstance(data, dict):
            raise EventMessageParseError(
                f"JSON не является объектом: {type(data).__name__}"
            )
        return data

    def value_to_raw_payload(
        self, value: bytes | str | dict[str, Any]
    ) -> RawEventPayload:
        """Парсит value в RawEventPayload;"""
        data = self.value_to_dict(value)
        return RawEventPayload.model_validate(data)

    def build_message(self, raw: RawEventPayload | dict[str, Any]) -> MessageT:
        """Собирает MessageT из RawEventPayload/словаря: маппит event и валидирует before/after."""
        if isinstance(raw, RawEventPayload):
            before_raw = raw.before
            after_raw = raw.after
            event_str = (raw.event or "").strip().lower()
        else:
            before_raw = raw.get("before")
            after_raw = raw.get("after")
            event_str = (raw.get("event") or "").strip().lower()

        mapping = _event_type_mapping_for(self._event_type_class)
        canonical = mapping.get(event_str, event_str or "create")
        event = self._event_type_class(canonical)

        payload_cls = _get_payload_class(self._message_class)
        # SQLAlchemy в БД хранит enum по имени (key); приводим к value по схеме payload
        before_normalized = (
            _normalize_payload_enums_by_schema(before_raw, payload_cls)
            if before_raw
            else None
        )
        after_normalized = (
            _normalize_payload_enums_by_schema(after_raw, payload_cls)
            if after_raw
            else None
        )
        before = (
            payload_cls.model_validate(before_normalized) if before_normalized else None
        )
        after = (
            payload_cls.model_validate(after_normalized) if after_normalized else None
        )

        return self._message_class(before=before, after=after, event=event)

    def raw_to_message(self, data: RawEventPayload | dict[str, Any]) -> MessageT:
        """Собирает сообщение через build_message;"""
        return self.build_message(data)

    def message_from_value(self, value: bytes | str | dict[str, Any]) -> MessageT:
        """Полный пайплайн: value → RawEventPayload → MessageT; при любой ошибке парсинга — исключение."""
        raw = self.value_to_raw_payload(value)
        return self.raw_to_message(raw)
