from logging import Logger

from tp_helper.base_items.base_discord import BaseDiscord
from tp_helper.base_items.base_logging_service import BaseLoggingService
from tp_helper.discord_helper import DiscordHelper

from src import TpLogger


class BaseWorker(BaseLoggingService, BaseDiscord):
    def __init__(self, logger: Logger | TpLogger, discord: DiscordHelper):
        BaseLoggingService.__init__(self, logger)
        BaseDiscord.__init__(self, discord)
