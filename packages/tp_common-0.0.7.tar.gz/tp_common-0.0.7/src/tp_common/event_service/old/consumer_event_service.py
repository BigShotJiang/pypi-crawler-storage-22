import typing
from enum import Enum
from logging import Logger
from typing import cast

from confluent_kafka import Message
from pydantic import BaseModel, ValidationError

from src import TpLogger
from tp_common.event_service.old.base_event_service import ConsumerBaseEventService
from tp_common.event_service.old.schemas import BaseEventType, TypedEventPayload


class ConsumeEventService[EventEnumT: Enum, ModelT: BaseModel](
    ConsumerBaseEventService[EventEnumT]
):
    def __init__(
        self,
        group_id: str,
        group_name: str,
        logger: Logger | TpLogger,
        payload_schema: type[ModelT],
        poll_timeout: float = 1.0,
        event_enum: type[EventEnumT] = cast(type[EventEnumT], BaseEventType),
        subscribe_to: list[EventEnumT] | None = None,
        auto_ack_ignored: bool = True,
    ) -> None:
        super().__init__(
            group_id=group_id,
            group_name=group_name,
            logger=logger,
            poll_timeout=poll_timeout,
            event_enum=event_enum,
            subscribe_to=subscribe_to,
            auto_ack_ignored=auto_ack_ignored,
        )
        self.payload_schema = payload_schema

    def parse_payload(self, msg: Message) -> TypedEventPayload[ModelT]:  # type: ignore[override]
        base_payload = super().parse_payload(msg)
        before = self._parse_model_part(base_payload.before)
        after = self._parse_model_part(base_payload.after)
        normalized_event = self._normalize_event(base_payload.event)
        return TypedEventPayload[ModelT](
            before=before,
            after=after,
            event=normalized_event,
        )

    def consume_filtered(  # type: ignore[override]
        self,
        event_types: list[EventEnumT] | None = None,
    ) -> tuple[Message, TypedEventPayload[ModelT]] | None:
        msg = self._poll_message()
        if msg is None:
            return None
        try:
            payload = self.parse_payload(msg)
            snapshot_value = getattr(self.event_enum, "SNAPSHOT", None)
            if snapshot_value is not None and payload.event == snapshot_value:
                self._log_snapshot_message(msg)
                self.commit(msg)
                return None
            if not self._should_process_event(
                typing.cast(EventEnumT | None, payload.event),
                event_types=event_types,
            ):
                self._handle_ignored_message(msg)
                return None
            return msg, payload
        except ValidationError:
            self._log_skipped_message(msg)
            self.commit(msg)
            return None
        except Exception:
            self.logger.exception(
                "Failed to process message (topic=%s, partition=%s, offset=%s) — offset NOT committed",
                msg.topic(),
                msg.partition(),
                msg.offset(),
            )
            return None

    def _parse_model_part(self, data: dict | BaseModel | None) -> ModelT | None:
        if data is None:
            return None
        if isinstance(data, self.payload_schema):
            return typing.cast(ModelT, data)
        return typing.cast(ModelT, self.payload_schema.model_validate(data))
