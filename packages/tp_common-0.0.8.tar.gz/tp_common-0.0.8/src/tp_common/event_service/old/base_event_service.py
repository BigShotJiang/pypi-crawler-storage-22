import json
from collections.abc import Sequence
from enum import Enum
from logging import Logger
from typing import TypeVar, cast

from confluent_kafka import Consumer, KafkaError, KafkaException, Message, Producer
from pydantic import ValidationError

from tp_common.event_service.old.event_config import (
    KAFKA_STREAM_PREFIX,
    create_consumer,
    create_producer,
)
from tp_common.event_service.old.schemas import BaseEventPayload, BaseEventType

EventEnumT = TypeVar("EventEnumT", bound=Enum)


class BaseEventService:
    def __init__(self, logger: Logger) -> None:
        self.logger = logger


class ConsumerBaseEventService[EventEnumT: Enum](BaseEventService):
    def __init__(
        self,
        group_id: str,
        group_name: str,
        logger: Logger,
        poll_timeout: float = 1.0,
        event_enum: type[EventEnumT] = cast(type[EventEnumT], BaseEventType),
        subscribe_to: Sequence[EventEnumT] | None = None,
        auto_ack_ignored: bool = True,
    ) -> None:
        super().__init__(logger=logger)
        self.consumer: Consumer = create_consumer(group_id=group_id)
        self.group_name: str = group_name
        self.poll_timeout: float = poll_timeout
        self.event_enum = event_enum
        self.subscribe_to = subscribe_to
        self.auto_ack_ignored = auto_ack_ignored

    def subscribe(self) -> None:
        """
        Подписываемся на очередь по group_name.
        """
        self.consumer.subscribe([f"{KAFKA_STREAM_PREFIX}.{self.group_name}"])

    def consume_filtered(
        self,
        event_types: list[EventEnumT] | None = None,
    ) -> tuple[Message, BaseEventPayload] | None:
        """
        Возвращает сообщение и payload для внешней обработки и commit'а.
        """
        msg = self._poll_message()
        if msg is None:
            return None

        try:
            payload = self.parse_payload(msg)
            normalized_event = self._normalize_event(payload.event)
            snapshot_value = getattr(self.event_enum, "SNAPSHOT", None)
            if snapshot_value is not None and normalized_event == snapshot_value:
                # Если это SNAPSHOT(начальная “полная выгрузка” данных из таблицы при старте Debezium‑коннектора)
                self._log_snapshot_message(msg)
                self.commit(msg)
                return None
            if not self._should_process_event(
                normalized_event, event_types=event_types
            ):
                # Если не проходит по фильтру
                self._handle_ignored_message(msg)
                return None
            # Если проходит по фильтру
            return msg, payload
        except ValidationError:
            # Если в WAL служебные или иные сообщения
            self._log_skipped_message(msg)
            self.commit(msg)
            return None
        except Exception:
            # Если иные ошибки
            self.logger.exception(
                "Failed to process message (topic=%s, partition=%s, offset=%s) — offset NOT committed",
                msg.topic(),
                msg.partition(),
                msg.offset(),
            )
            return None

    def commit(self, msg: Message) -> None:
        """
        Записываем изменения.
        """
        self.consumer.commit(message=msg, asynchronous=False)

    def close(self) -> None:
        """
        Закрытие подключения к очереди.
        """
        self.consumer.close()

    def _poll_message(self) -> Message | None:
        msg = self.consumer.poll(self.poll_timeout)
        if msg is None:
            return None

        if msg.error():
            err = msg.error()
            eof_code = getattr(KafkaError, "_PARTITION_EOF", 1)
            if err is not None and err.code() == eof_code:
                self.logger.debug(
                    "Partition EOF (topic=%s, partition=%s, offset=%s)",
                    msg.topic(),
                    msg.partition(),
                    msg.offset(),
                )
                return None
            raise KafkaException(err)

        return msg

    def _handle_ignored_message(self, msg: Message) -> None:
        if not self.auto_ack_ignored:
            return
        self.logger.debug(
            "Ignored message by filter (topic=%s, partition=%s, offset=%s) — committed",
            msg.topic(),
            msg.partition(),
            msg.offset(),
        )
        self.commit(msg)

    def _log_skipped_message(self, msg: Message) -> None:
        # Не Debezium-payload (тестовые/служебные сообщения) — пропускаем и коммитим.
        self.logger.warning(
            "Skipped non-Debezium message (topic=%s, partition=%s, offset=%s) — committed anyway",
            msg.topic(),
            msg.partition(),
            msg.offset(),
            exc_info=True,
        )

    def _log_snapshot_message(self, msg: Message) -> None:
        self.logger.debug(
            "Skipped snapshot message (topic=%s, partition=%s, offset=%s)",
            msg.topic(),
            msg.partition(),
            msg.offset(),
        )

    def _should_process_event(
        self,
        event: EventEnumT | None,
        event_types: Sequence[EventEnumT] | None = None,
    ) -> bool:
        active_filter = event_types if event_types is not None else self.subscribe_to
        if active_filter is None:
            return True
        if event is None:
            return False
        return event in list(active_filter)

    def _normalize_event(self, value: object) -> EventEnumT | None:
        if value is None:
            return None
        if isinstance(value, self.event_enum):
            return value
        try:
            return self.event_enum(value)
        except Exception:
            return None

    def parse_payload(self, msg: Message) -> BaseEventPayload:
        raw = msg.value()
        if raw is None:
            raise ValueError("Message value is None")
        event_dict = json.loads(raw)
        return BaseEventPayload.model_validate(event_dict)


class ProducerBaseEventService(BaseEventService):
    def __init__(self, logger: Logger) -> None:
        super().__init__(logger=logger)
        self.producer: Producer = create_producer()

    def publish_payload(
        self,
        payload: BaseEventPayload,
        *,
        topic: str,
        key: str | None = None,
    ) -> None:
        data = json.dumps(payload.model_dump(mode="json"), ensure_ascii=False).encode(
            "utf-8"
        )
        key_bytes = key.encode("utf-8") if key is not None else None
        self.producer.produce(
            topic=topic,
            value=data,
            key=key_bytes,
        )
        self.producer.poll(0)

    def flush(self, timeout: float = 10.0) -> None:
        self.producer.flush(timeout)

    def close(self, timeout: float = 10.0) -> None:
        self.flush(timeout)

    def _on_delivery(self, err: KafkaError | None, msg: Message) -> None:
        if err:
            self.logger.error("Kafka delivery error: %s", err)
            return
        self.logger.debug(
            "Kafka delivered: topic=%s partition=%s offset=%s",
            msg.topic(),
            msg.partition(),
            msg.offset(),
        )
