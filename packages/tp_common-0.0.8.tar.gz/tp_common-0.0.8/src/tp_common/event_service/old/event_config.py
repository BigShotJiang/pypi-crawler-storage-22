import os

from confluent_kafka import Consumer, Producer

KAFKA_BOOTSTRAP_SERVERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "192.168.81.61:9094")
KAFKA_STREAM_PREFIX = os.getenv("KAFKA_STREAM_PREFIX", "events.public")
DEFAULT_GROUP_ID = os.getenv("DEFAULT_GROUP_ID", "domain-tpc-consumer")

SASL_USERNAME = os.getenv("KAFKA_SASL_USERNAME", "user")
SASL_PASSWORD = os.getenv("KAFKA_SASL_PASSWORD", "user1122@")

SASL_MECHANISM = os.getenv("KAFKA_SASL_MECHANISM", "SCRAM-SHA-256")
SECURITY_PROTOCOL = os.getenv("KAFKA_SECURITY_PROTOCOL", "SASL_PLAINTEXT")


def create_consumer(group_id: str = DEFAULT_GROUP_ID) -> Consumer:
    return Consumer(
        {
            "bootstrap.servers": KAFKA_BOOTSTRAP_SERVERS,
            "group.id": group_id,
            "auto.offset.reset": "earliest",
            "enable.auto.commit": False,
            "session.timeout.ms": 30000,
            "max.poll.interval.ms": 300000,
            # SASL
            "security.protocol": SECURITY_PROTOCOL,
            "sasl.mechanism": SASL_MECHANISM,
            "sasl.username": SASL_USERNAME,
            "sasl.password": SASL_PASSWORD,
        }
    )


def create_producer() -> Producer:
    return Producer(
        {
            "bootstrap.servers": KAFKA_BOOTSTRAP_SERVERS,
            "acks": "all",
            "retries": 3,
            "retry.backoff.ms": 100,
            # SASL
            "security.protocol": SECURITY_PROTOCOL,
            "sasl.mechanism": SASL_MECHANISM,
            "sasl.username": SASL_USERNAME,
            "sasl.password": SASL_PASSWORD,
        }
    )
