import json
from enum import Enum
from logging import Logger
from typing import TypeVar

from pydantic import BaseModel

from tp_common.event_service.old.base_event_service import ProducerBaseEventService
from tp_common.event_service.old.event_config import KAFKA_STREAM_PREFIX
from tp_common.event_service.old.schemas import BaseEventPayload, TypedEventPayload

ModelT = TypeVar("ModelT", bound=BaseModel)


class ProducerEventService(ProducerBaseEventService):
    def __init__(
        self,
        logger: Logger,
        group_name: str,
        payload_schema: type[ModelT] | None = None,
    ) -> None:
        super().__init__(logger=logger)
        self.topic_name = f"{KAFKA_STREAM_PREFIX}.{group_name}"
        self.payload_schema = payload_schema

    def publish(
        self,
        payload: BaseEventPayload | TypedEventPayload[ModelT],
    ) -> None:
        normalized_payload = self._normalize_payload(payload)
        data = json.dumps(
            normalized_payload.model_dump(mode="json"),
            ensure_ascii=False,
        ).encode("utf-8")
        self.producer.produce(
            topic=self.topic_name,
            value=data,
            on_delivery=self._on_delivery,
        )

        self.producer.poll(0)

    def publish_to_group(
        self,
        payload: BaseEventPayload | TypedEventPayload[ModelT],
    ) -> None:
        self.publish(payload)

    def _normalize_payload(
        self,
        payload: BaseEventPayload | TypedEventPayload[ModelT],
    ) -> BaseEventPayload:
        if isinstance(payload, BaseEventPayload):
            return self._normalize_base_payload(payload)
        before = self._normalize_model_part(payload.before)
        after = self._normalize_model_part(payload.after)
        event = self._normalize_event_value(payload.event)
        return BaseEventPayload(
            before=before,
            after=after,
            event=event,
        )

    def _normalize_base_payload(self, payload: BaseEventPayload) -> BaseEventPayload:
        before = self._normalize_model_part(payload.before)
        after = self._normalize_model_part(payload.after)
        event = self._normalize_event_value(payload.event)
        if (
            before is payload.before
            and after is payload.after
            and event == payload.event
        ):
            return payload
        return BaseEventPayload(
            before=before,
            after=after,
            event=event,
        )

    def _normalize_model_part(self, data: dict | BaseModel | None) -> dict | None:
        if data is None:
            return None
        if isinstance(data, BaseModel):
            return data.model_dump(mode="json")
        if self.payload_schema is None:
            return data
        if isinstance(data, self.payload_schema):
            return data.model_dump(mode="json")
        return self.payload_schema.model_validate(data).model_dump(mode="json")

    @staticmethod
    def _normalize_event_value(value: object) -> str | None:
        if value is None:
            return None
        if isinstance(value, Enum):
            return str(value.value)
        return str(value)
