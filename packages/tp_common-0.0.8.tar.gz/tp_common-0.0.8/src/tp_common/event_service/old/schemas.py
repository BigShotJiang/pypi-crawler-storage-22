from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, TypeVar

from pydantic import AliasChoices, BaseModel, ConfigDict, Field


class BaseEventType(str, Enum):
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"
    SNAPSHOT = "snapshot"

    @classmethod
    def _missing_(cls, value: object) -> BaseEventType | None:
        if not isinstance(value, str):
            return None
        mapping = {
            "c": cls.CREATE,
            "u": cls.UPDATE,
            "d": cls.DELETE,
            "r": cls.SNAPSHOT,
        }
        return mapping.get(value.lower())


class BaseEventPayload(BaseModel):
    before: dict[str, Any] | None = Field(None, description="Схема до изменений")
    after: dict[str, Any] | None = Field(None, description="Схема после изменений")
    event: str | None = Field(
        default=None,
        validation_alias=AliasChoices("event"),
        serialization_alias="event",
    )

    model_config = ConfigDict(extra="allow", populate_by_name=True)


ModelT = TypeVar("ModelT", bound=BaseModel)


class TypedEventPayload[ModelT: BaseModel](BaseModel):
    before: ModelT | None = None
    after: ModelT | None = None
    event: Enum | None = None

    model_config = ConfigDict(extra="allow")


# Для примера
class UserPayload(BaseModel):
    id: int
    name: str
    description: str | None = None
    is_active: bool
    created_at: datetime
    updated_at: datetime | None = None
