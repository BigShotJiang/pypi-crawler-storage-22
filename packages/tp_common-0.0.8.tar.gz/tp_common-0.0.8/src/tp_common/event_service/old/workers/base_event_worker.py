from __future__ import annotations

from enum import Enum
from logging import Logger
from typing import TypeVar, cast

from pydantic import BaseModel

from tp_common.event_service.old.consumer_event_service import ConsumeEventService
from tp_common.event_service.old.producer_event_service import ProducerEventService
from tp_common.event_service.old.schemas import (
    BaseEventPayload,
    BaseEventType,
    TypedEventPayload,
)

ModelT = TypeVar("ModelT", bound=BaseModel)
EventEnumT = TypeVar("EventEnumT", bound=Enum)


class BaseEventWorker[ModelT: BaseModel, EventEnumT: Enum]:
    def __init__(
        self,
        logger: Logger,
        group_id: str,
        group_name: str,
        producer_group_name: str,
        payload_schema: type[ModelT],
        event_enum: type[EventEnumT] = cast(type[EventEnumT], BaseEventType),
        subscribe_to: list[EventEnumT] | None = None,
    ) -> None:
        self.consumer_service = ConsumeEventService(
            group_id=group_id,
            group_name=group_name,
            logger=logger,
            payload_schema=payload_schema,
            event_enum=event_enum,
            subscribe_to=subscribe_to,
        )
        self.producer_service = ProducerEventService(
            logger=logger,
            group_name=producer_group_name,
            payload_schema=payload_schema,
        )

    def start(self) -> None:
        self.subscribe_to_queue()
        while True:
            print("PROCESS")
            self.process()

    def subscribe_to_queue(self) -> None:
        self.consumer_service.subscribe()

    def process(self) -> None:
        result = self.consumer_service.consume_filtered()
        if result is None:
            return
        msg, payload = result
        print(msg, payload)
        self.handle_update(payload)
        self.consumer_service.commit(msg)

    def handle_update(self, payload: TypedEventPayload[ModelT]) -> None:
        before = payload.before
        after = payload.after
        if not before or not after:
            return

        events = self.get_event_types(before, after)
        for event_type in events:
            out_payload = TypedEventPayload[ModelT](
                before=before,
                after=after,
                event=event_type,
            )
            self.produce(out_payload)

    def get_event_types(self, before: ModelT, after: ModelT) -> list[Enum]:
        raise NotImplementedError("get_event_types must be implemented in subclass")

    def produce(self, payload: BaseEventPayload | TypedEventPayload[ModelT]) -> None:
        self.producer_service.publish(payload)
