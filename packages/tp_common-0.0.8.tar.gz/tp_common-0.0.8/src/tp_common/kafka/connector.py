# подключения к кафке


class KafkaConnector:
    def __init__(self, url, group_id=None):
        # self.kafka_broker = kafka_broker
        ...

    def get_consumer(self):
        # return Co...
        ...

    def get_producer(self):
        # return Pro...
        ...


kafka_connector = KafkaConnector()
