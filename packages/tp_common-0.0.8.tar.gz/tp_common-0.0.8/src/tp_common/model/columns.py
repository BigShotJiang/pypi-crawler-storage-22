import uuid

from sqlalchemy import UUID
from sqlalchemy.orm import Mapped, mapped_column


def uuid_column(
    primary_key: bool = True,
    default: bool = True,
    nullable: bool = False,
) -> Mapped[uuid.UUID]:
    """
    Возвращает колонку UUID с поддержкой primary key и генерации по умолчанию.

    :param primary_key: Является ли колонка первичным ключом.
    :param default: Добавить ли default=uuid4.
    :param nullable: Разрешено ли NULL-значение.
    :return: Mapped колонка UUID(as_uuid=True)

    Пример:
        user_id: Mapped[uuid.UUID] = uuid_column(primary_key=True)
    """
    column = mapped_column(
        UUID(as_uuid=True),
        primary_key=primary_key,
        default=uuid.uuid4 if default else None,
        nullable=nullable,
    )

    return column
