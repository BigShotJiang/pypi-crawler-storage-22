# from __future__ import annotations
#
# from enum import Enum
# from typing import Any, TypeVar
#
# from pydantic import AliasChoices, BaseModel, ConfigDict, Field
#
#
# class BaseEventType(str, Enum):
#     CREATE = "create"
#     UPDATE = "update"
#     DELETE = "delete"
#     SNAPSHOT = "snapshot"
#
#     @classmethod
#     def _missing_(cls, value: object) -> BaseEventType | None:
#         if not isinstance(value, str):
#             return None
#         v = value.strip().lower()
#         mapping = {
#             "c": cls.CREATE,
#             "u": cls.UPDATE,
#             "d": cls.DELETE,
#             "r": cls.SNAPSHOT,
#             "create": cls.CREATE,
#             "update": cls.UPDATE,
#             "delete": cls.DELETE,
#             "snapshot": cls.SNAPSHOT,
#         }
#         return mapping.get(v)
#
#
# class BaseEventPayload(BaseModel):
#     before: dict[str, Any] | None = Field(None, description="Схема до изменений")
#     after: dict[str, Any] | None = Field(None, description="Схема после изменений")
#     event: str | None = Field(
#         default=None,
#         validation_alias=AliasChoices("event", "op"),
#         serialization_alias="event",
#     )
#
#     model_config = ConfigDict(extra="allow", populate_by_name=True)
#
#
# ModelT = TypeVar("ModelT", bound=BaseModel)
# EventT = TypeVar("EventT", bound=Enum)
#
#
# class TypedEventPayload[ModelT: BaseModel, EventT: Enum](BaseModel):
#     before: ModelT | None = None
#     after: ModelT | None = None
#     event: EventT | None = None
#
#     model_config = ConfigDict(extra="allow")
