from datetime import datetime
from enum import Enum

from pydantic import BaseModel

from tp_common.kafka.new.connector import KafkaConnector
from tp_common.kafka.new.event.schemas import BaseEventMessage
from tp_common.kafka.new.event.service import BaseEvent


def get_kafka() -> KafkaConnector:
    return KafkaConnector("plaintext://user:user@192.168.81.61:9094", "events")


class EventGroup(str, Enum):
    USERS = "users"


class UserEvent(str, Enum):
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"

    CHANGE_NAME = "change_name"


class User(BaseModel):
    id: int
    name: str
    description: str | None = None
    is_active: bool
    created_at: datetime
    updated_at: datetime | None = None


class UserEventMessage(BaseEventMessage[User, UserEvent]):
    """Сообщение события пользователя:."""


class UserEventService(BaseEvent[UserEventMessage, UserEvent]):
    """Дескриптор события пользователей."""

    SERVICE_NAME = "public"
    EVENT_GROUP = EventGroup.USERS
    EVENT_TYPE_CLASS = UserEvent
    # Топик events.{db}.{schema}.{table} — db берётся из source.db в Debezium
    TOPIC_DB = "postgres"
    SCHEMA_NAME = "public"
    TABLE_NAME = "users"


event = UserEventService(
    connector=get_kafka(),
    consumer_group="users",
)

if __name__ == "__main__":

    # чтение базы
    # чтение уникальных событий

    #
    with event.sub():
        # полезная работа: читаем и обрабатываем сообщения
        # при выходе из with без исключения — offset сам коммитится
        while True:
            ...
            # msg = event.pop()
            # if msg is None:
            #    break
            ## обработка msg (UserEventMessage)
            # print(msg)
