from __future__ import annotations

from enum import Enum
from typing import TypeVar

from pydantic import BaseModel, ConfigDict, Field

PayloadT = TypeVar("PayloadT", bound=BaseModel)
EventT = TypeVar("EventT", bound=Enum)


class BaseEventMessage[PayloadT: BaseModel, EventT: Enum](BaseModel):

    before: PayloadT | None = Field(None, description="Схема до изменений")
    after: PayloadT | None = Field(None, description="Схема после изменений")
    event: EventT = Field(..., description="Тип события")

    model_config = ConfigDict(extra="allow", populate_by_name=True)
