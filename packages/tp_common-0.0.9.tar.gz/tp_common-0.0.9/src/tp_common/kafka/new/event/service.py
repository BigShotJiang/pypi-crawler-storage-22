import enum
from collections.abc import Generator
from contextlib import contextmanager
from typing import Any, ClassVar, TypeVar

from confluent_kafka import Consumer

from tp_common.kafka.new.connector import KafkaConnector
from tp_common.kafka.new.event.schemas import BaseEventMessage

MessageT = TypeVar("MessageT", bound=BaseEventMessage)
EventEnumT = TypeVar("EventEnumT", bound=enum.Enum)

# Маппинг для преобразования в сервисе: короткие/альтернативные строки → каноническое значение.
# Используйте: canonical = mapping.get(raw.strip().lower()); enum_cls(canonical).
BASE_EVENT_TYPE_MAPPING: dict[str, str] = {
    "c": "create",
    "u": "update",
    "d": "delete",
    "r": "snapshot",
    "create": "create",
    "update": "update",
    "delete": "delete",
    "snapshot": "snapshot",
}


def event_type_mapping_for(enum_cls: type[enum.Enum]) -> dict[str, str]:
    """
    Маппинг для преобразования строки в член enum в сервисе.
    Базовые ключи (c, u, d, r, create, ...) + все значения enum_cls (для своих типов вроде change_name).
    """
    mapping = dict(BASE_EVENT_TYPE_MAPPING)
    for member in enum_cls:
        v = member.value if isinstance(member.value, str) else str(member.value)
        mapping[v.lower()] = v
    return mapping


class BaseEvent[MessageT: BaseEventMessage, EventEnumT: enum.Enum]:
    SERVICE_NAME: ClassVar[str]
    EVENT_GROUP: ClassVar[enum.Enum]
    EVENT_TYPE_CLASS: ClassVar[type[enum.Enum]]
    # Опционально: для топика вида {prefix}.{db}.{schema}.{table} (Debezium с source.db в имени)
    TOPIC_DB: ClassVar[str | None] = None
    SCHEMA_NAME: ClassVar[str | None] = None
    TABLE_NAME: ClassVar[str | None] = None

    _REQUIRED_EVENT_TYPES: ClassVar[dict[str, str]] = {
        "CREATE": "create",
        "UPDATE": "update",
        "DELETE": "delete",
    }

    def __init__(
        self,
        connector: KafkaConnector,
        consumer_group: str | None = None,
        subscribe_to: list[str] | None = None,
    ) -> None:
        self.connector = connector
        self.consumer_group = consumer_group
        self.subscribe_to = subscribe_to
        self._consumer: Consumer | None = None

    def _topic(self) -> str:
        """
        Имя топика для подписки.
        Если заданы TOPIC_DB, SCHEMA_NAME, TABLE_NAME — возвращает
        {topic_prefix}.{TOPIC_DB}.{SCHEMA_NAME}.{TABLE_NAME} (формат Debezium с source.db).
        Иначе — {topic_prefix}.{SERVICE_NAME}.
        """
        if (
            self.TOPIC_DB is not None
            and self.SCHEMA_NAME is not None
            and self.TABLE_NAME is not None
        ):
            return (
                f"{self.connector.topic_prefix}.{self.TOPIC_DB}."
                f"{self.SCHEMA_NAME}.{self.TABLE_NAME}"
            )
        return f"{self.connector.topic_prefix}.{self.SERVICE_NAME}"

    @contextmanager
    def sub(self) -> Generator["BaseEvent[MessageT, EventEnumT]"]:
        """
        Контекстный менеджер подписки на топик.
        При выходе из контекста без исключения — коммит offset.
        При исключении — коммит не выполняется.
        """
        consumer = self.get_consumer()
        topic = self._topic()
        consumer.subscribe([topic])
        self._consumer = consumer
        try:
            yield self
        except Exception:
            raise
        else:
            consumer.commit()
        finally:
            self._consumer = None
            consumer.close()

    def get_consumer(self) -> Consumer:
        if self.connector is None:
            raise ValueError("connector не задан, невозможно создать consumer")

        if not self.consumer_group or not str(self.consumer_group).strip():
            raise ValueError(
                "consumer_group должен быть непустой строкой для создания consumer"
            )
        return self.connector.get_consumer(self.consumer_group)

    def _should_process_event(
        self,
        event: EventEnumT | None,
        subscribe_to: list[EventEnumT] | None = None,
    ) -> bool:
        active_filter = subscribe_to if subscribe_to is not None else self.subscribe_to
        if active_filter is None:
            return True
        if event is None:
            return False
        return event in active_filter

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """
        Валидация при создании наследника.
        Проверяет, что SERVICE_NAME, EVENT_GROUP, MESSAGE_CLASS и EVENT_TYPE_CLASS заданы,
        EVENT_TYPE_CLASS содержит обязательные поля CREATE, UPDATE, DELETE.
        """
        super().__init_subclass__(**kwargs)

        # Проверка наличия обязательных атрибутов
        if not hasattr(cls, "SERVICE_NAME") or not isinstance(
            getattr(cls, "SERVICE_NAME", None), str
        ):
            raise TypeError(
                f"{cls.__name__} должен определить SERVICE_NAME (непустая строка)"
            )

        service_name = cls.SERVICE_NAME
        if not service_name or not service_name.strip():
            raise TypeError(
                f"{cls.__name__}.SERVICE_NAME не должен быть пустой строкой"
            )

        if not hasattr(cls, "EVENT_GROUP"):
            raise TypeError(f"{cls.__name__} должен определить EVENT_GROUP")

        if not hasattr(cls, "MESSAGE_CLASS"):
            raise TypeError(f"{cls.__name__} должен определить MESSAGE_CLASS")

        if not hasattr(cls, "EVENT_TYPE_CLASS"):
            raise TypeError(f"{cls.__name__} должен определить EVENT_TYPE_CLASS")

        # Проверка, что EVENT_TYPE_CLASS содержит обязательные поля create/update/delete
        event_type_cls = cls.EVENT_TYPE_CLASS
        if not isinstance(event_type_cls, type) or not issubclass(
            event_type_cls, enum.Enum
        ):
            raise TypeError(
                f"{cls.__name__}.EVENT_TYPE_CLASS должен быть подклассом enum.Enum"
            )
        for name, expected_value in BaseEvent._REQUIRED_EVENT_TYPES.items():
            if not hasattr(event_type_cls, name):
                raise TypeError(
                    f"{cls.__name__}.EVENT_TYPE_CLASS должен содержать поле {name}"
                )
            member = getattr(event_type_cls, name)
            actual_value = member.value if hasattr(member, "value") else member
            if actual_value != expected_value:
                raise TypeError(
                    f"{cls.__name__}.EVENT_TYPE_CLASS.{name} должен быть равен "
                    f"{expected_value!r}, получено {actual_value!r}"
                )
