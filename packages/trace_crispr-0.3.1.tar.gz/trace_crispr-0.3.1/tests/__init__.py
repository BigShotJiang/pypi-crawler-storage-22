"""Tests for CRISPRo."""
