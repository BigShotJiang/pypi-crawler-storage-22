from typing import Any, Callable, Dict, Optional

from rich.console import Console
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.text import Text

from traceml.loggers.error_log import get_error_logger
from traceml.renderers.display.layout import (
    LAYER_COMBINED_MEMORY_LAYOUT,
    LAYER_COMBINED_TIMER_LAYOUT,
    MODEL_COMBINED_LAYOUT,
    PROCESS_LAYOUT,
    ROOT_LAYOUT,
    STDOUT_STDERR_LAYOUT,
    SYSTEM_LAYOUT,
    MODEL_MEMORY_LAYOUT,
)
from traceml.runtime.stdout_stderr_capture import StreamCapture


class CLIDisplayManager:
    """
    Manages a single shared Rich Live display and a dynamic Layout for all stdout loggers.
    """

    _console: Console = Console()
    _live_display: Optional[Live] = None
    _layout: Layout = Layout(name=ROOT_LAYOUT)

    # Key: layout_panel_name (e.g., "live_metrics")
    # Value: Callable[[], Renderable] - a function that returns the latest renderable panel
    _layout_content_fns: Dict[str, Callable[[], Any]] = {}
    _active_logger_count: int = 0

    logger = get_error_logger("CLIDisplayManager")

    @classmethod
    def _create_layout(cls):
        cls._layout.split_column(
            Layout(name="dashboard", ratio=3),
            Layout(name=STDOUT_STDERR_LAYOUT, ratio=1),
        )
        dashboard = cls._layout["dashboard"]
        dashboard.split_column(
            Layout(name="upper_row", ratio=3),
            Layout(name="middle_row", ratio=6),
            Layout(name="layer_row", ratio=5),
        )
        dashboard["upper_row"].split_row(
            Layout(name=SYSTEM_LAYOUT, ratio=4),
            Layout(name=PROCESS_LAYOUT, ratio=5),
        )
        dashboard["layer_row"].split_row(
            Layout(name=LAYER_COMBINED_MEMORY_LAYOUT, ratio=8),
            Layout(name=LAYER_COMBINED_TIMER_LAYOUT, ratio=7),
        )
        dashboard["middle_row"].split_row(
            Layout(name=MODEL_COMBINED_LAYOUT, ratio=3),
            Layout(name=MODEL_MEMORY_LAYOUT, ratio=2),
        )
        return dashboard

    @classmethod
    def _create_initial_layout(cls):
        """
        Defines the improved structure of the Rich Layout with flexible ratios.
        """
        dashboard = cls._create_layout()

        # Initialize panels with placeholder text
        dashboard[SYSTEM_LAYOUT].update(
            Panel(Text("Waiting for System Metrics...", justify="center"))
        )
        dashboard[PROCESS_LAYOUT].update(
            Panel(Text("Waiting for Process Metrics...", justify="center"))
        )
        dashboard[LAYER_COMBINED_MEMORY_LAYOUT].update(
            Panel(Text("Waiting for Layer Memory...", justify="center"))
        )
        dashboard[LAYER_COMBINED_TIMER_LAYOUT].update(
            Panel(Text("Waiting for Layer Timing...", justify="center"))
        )
        dashboard[MODEL_MEMORY_LAYOUT].update(
            Panel(Text("Waiting for Step Memory...", justify="center"))
        )
        cls._layout[STDOUT_STDERR_LAYOUT].update(
            Panel(
                Text("Waiting for Stdout/Stderr...", justify="center"),
                title="Logs",
                border_style="cyan",
            )
        )

    @classmethod
    def start_display(cls):
        """Starts the shared display if not already running."""
        if cls._active_logger_count == 0:
            cls._create_initial_layout()
            cls._live_display = Live(
                cls._layout,
                console=cls._console,
                auto_refresh=False,
                transient=False,
                screen=True,
            )
            try:
                cls._live_display.start()
            except Exception as e:
                cls.logger.error(
                    f"[TraceML] Failed to start shared live display: {e}"
                )
                cls._live_display = None

        cls._active_logger_count += 1

    @classmethod
    def stop_display(cls):
        """Stops the shared Rich Live display."""
        if cls._live_display:
            try:
                cls._live_display.stop()
                StreamCapture.redirect_to_original()
            except Exception as e:
                cls.logger.error(f"[TraceML] Error stopping live display: {e}")
            finally:
                cls._live_display = None
                cls._layout_content_fns.clear()

    @classmethod
    def release_display(cls):
        """Decrements active logger count and stops display if none remain."""
        cls._active_logger_count = max(cls._active_logger_count - 1, 0)
        if cls._active_logger_count == 0:
            cls.stop_display()

    @classmethod
    def register_layout_content(
        cls, layout_section: str, content_fn: Callable[[], Any]
    ):
        """
        Registers a function that provides content for a specific layout panel.
        """
        if cls._layout.get(layout_section) is None:
            cls.logger.error(
                f"[TraceML] WARNING: Layout panel '{layout_section}' not found. Cannot register content."
            )
            return
        cls._layout_content_fns.setdefault(layout_section, content_fn)

    @classmethod
    def update_display(cls):
        """
        Triggers an update of the entire live display by calling all registered
        content functions and updating the layout.
        """
        pass
        if cls._live_display is None:
            return

        try:
            for section_name, content_fn in cls._layout_content_fns.items():
                try:
                    renderable = content_fn()
                    if renderable is not None:
                        cls._layout[section_name].update(renderable)
                except Exception as e:
                    error_panel = Panel(
                        f"[red]Error rendering {section_name}: {e}[/red]",
                        title=f"[bold red]Render Error: {section_name}[/bold red]",
                        border_style="red",
                    )
                    cls._layout[section_name].update(error_panel)
                    cls.logger.error(
                        f"[TraceML] Error in rendering content for panel {section_name}: {e}"
                    )

            StreamCapture.redirect_to_original()
            cls._live_display.refresh()
            StreamCapture.redirect_to_capture()
        except Exception as e:
            cls.logger.error(f"[TraceML] Error updating live display: {e}")
