"""
Patch-level Tractor runner for tract7dt.
"""

from __future__ import annotations

import argparse
import gzip
import json
import logging
import math
import os
import pickle
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import numpy as np
import pandas as pd

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.cm import ScalarMappable
from matplotlib.colors import Normalize

import sep
from astropy.io import fits

from tractor import ConstantSky, Fluxes, FluxesPhotoCal, Image, NullWCS, PixPos, PointSource, Tractor
from tractor.constrained_optimizer import ConstrainedOptimizer
from tractor.ellipses import EllipseESoft
from tractor.galaxy import DevGalaxy, ExpGalaxy
from tractor.psf import HybridPixelizedPSF, PixelizedPSF
from tractor.sersic import SersicGalaxy, SersicIndex

import importlib.util

from .moffat_psf import MoffatPSF as _DefaultMoffatPSF


sep.set_sub_object_limit(200000)
sep.set_extract_pixstack(1000000)

_MOFFAT_CLASS = _DefaultMoffatPSF


def _load_moffat_psf_class(module_path: str | None):
    global _MOFFAT_CLASS
    if module_path is None:
        _MOFFAT_CLASS = _DefaultMoffatPSF
        return
    p = Path(module_path)
    if not p.exists():
        raise RuntimeError(f"Moffat PSF module not found: {p}")
    spec = importlib.util.spec_from_file_location("moffat_psf_ext", str(p))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Failed to load Moffat PSF module: {p}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # type: ignore[assignment]
    if not hasattr(mod, "MoffatPSF"):
        raise RuntimeError(f"Moffat PSF module missing MoffatPSF: {p}")
    _MOFFAT_CLASS = getattr(mod, "MoffatPSF")


@dataclass
class PatchRunConfig:
    # Optimization
    n_opt_iters: int = 200
    dlnp_stop: float = 1e-6
    # Flag "non-converged" if we effectively hit max iters.
    # If not converged and niters >= (n_opt_iters - margin), set opt_hit_max_iters=True.
    flag_maxiter_margin: int = 5

    # Catalog init
    r_ap: float = 5.0
    eps_flux: float = 1e-4
    gal_model: str = "dev"  # dev|exp|sersic
    sersic_n_init: float = 3.0
    re_fallback_pix: float = 3.0

    # Output cutouts
    save_cutouts: bool = True
    cutout_size_pix: int = 100
    cutout_max_sources: Optional[int] = None
    cutout_start: int = 0
    cutout_data_p_lo: float = 1
    cutout_data_p_hi: float = 99
    cutout_model_p_lo: float = 1
    cutout_model_p_hi: float = 99
    cutout_resid_p_abs: float = 99

    # Per-patch overview
    save_patch_overview: bool = True

    # PSF fallback
    hybrid_psf_n: int = 4
    moffat_beta: float = 3.5
    moffat_radius_pix: float = 25.0
    moffat_default_fwhm_pix: float = 4.0


def _ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def _make_logger(outdir: Path, tag: str) -> logging.Logger:
    _ensure_dir(outdir)
    log = logging.getLogger(f"tractor_patch.{tag}")
    log.setLevel(logging.INFO)
    log.propagate = False
    if not log.handlers:
        fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
        fh = logging.FileHandler(outdir / f"{tag}.log", mode="w")
        fh.setFormatter(fmt)
        fh.setLevel(logging.INFO)
        log.addHandler(fh)
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        sh.setLevel(logging.INFO)
        log.addHandler(sh)
    return log


def _patch_tag_from_meta(meta: dict | None) -> str:
    if not meta:
        return "patch"
    t = meta.get("patch_tag", None)
    if isinstance(t, str) and t.strip():
        return t.strip()
    return "patch"


def _roi_bbox_from_meta(meta: dict) -> tuple[int, int, int, int]:
    if "roi_bbox" in meta:
        b = meta["roi_bbox"]
        if isinstance(b, (list, tuple)) and len(b) == 4:
            return (int(b[0]), int(b[1]), int(b[2]), int(b[3]))
    keys = ("x0_roi", "x1_roi", "y0_roi", "y1_roi")
    if all(k in meta for k in keys):
        return (int(meta["x0_roi"]), int(meta["x1_roi"]), int(meta["y0_roi"]), int(meta["y1_roi"]))
    raise ValueError("meta must contain roi_bbox or (x0_roi,x1_roi,y0_roi,y1_roi)")


def load_patch_inputs(pkl_gz_path: str | Path) -> dict:
    p = Path(pkl_gz_path)
    with gzip.open(p, "rb") as f:
        payload = pickle.load(f)
    if not isinstance(payload, dict):
        raise ValueError("Patch input payload must be a dict")
    return payload


def _fallback_moffat_psf_from_header(fp: str, *, beta: float, radius_pix: float, default_fwhm_pix: float):
    fwhm_pix = float(default_fwhm_pix)
    try:
        with fits.open(fp, memmap=True) as hdul:
            hdr = hdul[0].header
        v = hdr.get("PEEING", None)
        if v is not None and np.isfinite(v) and v > 0:
            fwhm_pix = float(v)
    except Exception:
        pass
    fwhm_pix = max(float(fwhm_pix), 1.0)
    return _MOFFAT_CLASS(fwhm_pix=fwhm_pix, beta=float(beta), radius_pix=float(radius_pix))


def build_psf_by_band_for_patch(
    *,
    per_filter_patch: dict,
    epsf_root: Path,
    epsf_tag: str,
    cfg: PatchRunConfig,
    log: logging.Logger,
) -> dict[str, Any]:
    psf_by_band: dict[str, Any] = {}
    for band, d in per_filter_patch.items():
        band = str(band)
        epsf_path = epsf_root / band / str(epsf_tag) / "epsf.npy"
        if epsf_path.exists():
            epsf_arr = np.load(epsf_path)
            epsf_arr = np.asarray(epsf_arr, dtype=np.float32)
            epsf_arr = np.nan_to_num(epsf_arr, nan=0.0, posinf=0.0, neginf=0.0)
            s = float(np.sum(epsf_arr))
            if s > 0:
                epsf_arr = epsf_arr / s
            pixpsf = PixelizedPSF(epsf_arr)
            psf_by_band[band] = HybridPixelizedPSF(pixpsf, gauss=None, N=int(cfg.hybrid_psf_n), cx=0.0, cy=0.0)
        else:
            fp = d.get("fp", None)
            if fp:
                psf_by_band[band] = _fallback_moffat_psf_from_header(
                    str(fp),
                    beta=cfg.moffat_beta,
                    radius_pix=cfg.moffat_radius_pix,
                    default_fwhm_pix=cfg.moffat_default_fwhm_pix,
                )
            else:
                psf_by_band[band] = _MOFFAT_CLASS(
                    fwhm_pix=cfg.moffat_default_fwhm_pix,
                    beta=float(cfg.moffat_beta),
                    radius_pix=float(cfg.moffat_radius_pix),
                )
            log.info("[PSF] %s: missing ePSF at %s -> fallback %s", band, str(epsf_path), str(psf_by_band[band]))
    return psf_by_band


def build_tractor_images_from_per_filter_patch(
    *,
    per_filter_patch: dict,
    psf_by_filt: dict[str, Any],
    use_sky_sigma: bool = True,
) -> tuple[list[Image], list[dict[str, Any]]]:
    tractor_images: list[Image] = []
    image_data: list[dict[str, Any]] = []
    for filt, d in per_filter_patch.items():
        filt = str(filt)
        img = np.ascontiguousarray(d["img_scaled"], dtype=np.float32)
        sig = d["sigma_sky_scaled"] if use_sky_sigma else d["sigma_total_scaled"]
        sig = np.ascontiguousarray(sig, dtype=np.float32)
        bad = np.asarray(d.get("bad", ~np.isfinite(img)), dtype=bool)
        bad |= ~np.isfinite(img) | ~np.isfinite(sig) | (sig <= 0)

        invvar = np.zeros_like(img, dtype=np.float32)
        good = ~bad
        invvar[good] = 1.0 / np.maximum(sig[good] * sig[good], 1e-12)

        tim = Image(
            data=img,
            invvar=invvar,
            psf=psf_by_filt.get(filt, None),
            wcs=NullWCS(),
            sky=ConstantSky(0.0),
            photocal=FluxesPhotoCal(str(filt)),
            name=str(filt),
        )
        tractor_images.append(tim)
        image_data.append(
            dict(
                filter=str(filt),
                fp=d.get("fp", None),
                scale=float(d.get("scale", np.nan)) if d.get("scale", None) is not None else np.nan,
                data=img,
                invvar=invvar,
                sigma_used=sig,
                bad=bad,
            )
        )
    return tractor_images, image_data


def build_catalog_from_cat_patch(cat_patch: pd.DataFrame, tractor_images: list[Image], cfg: PatchRunConfig) -> list[Any]:
    if "x_pix_patch" not in cat_patch.columns or "y_pix_patch" not in cat_patch.columns:
        raise ValueError("cat_patch must contain columns: x_pix_patch, y_pix_patch")
    xs = np.asarray(cat_patch["x_pix_patch"], dtype=np.float32)
    ys = np.asarray(cat_patch["y_pix_patch"], dtype=np.float32)

    bandnames = [str(getattr(tim, "name", f"band{i}")) for i, tim in enumerate(tractor_images)]
    init_fluxes = [dict((bn, float(cfg.eps_flux)) for bn in bandnames) for _ in range(len(cat_patch))]

    for tim, bn in zip(tractor_images, bandnames):
        img = np.ascontiguousarray(tim.getImage(), dtype=np.float32)
        inv = np.ascontiguousarray(tim.getInvvar(), dtype=np.float32)
        good = np.isfinite(img) & np.isfinite(inv) & (inv > 0)
        err = np.full_like(img, np.inf, dtype=np.float32)
        err[good] = (1.0 / np.sqrt(inv[good])).astype(np.float32)
        mask = ~good
        f, _ferr, _flag = sep.sum_circle(img, xs, ys, r=float(cfg.r_ap), err=err, mask=mask)
        f = np.asarray(f, dtype=np.float32)
        f = np.where(np.isfinite(f), f, 0.0)
        f = np.maximum(f, float(cfg.eps_flux))
        for i in range(len(cat_patch)):
            init_fluxes[i][bn] = float(f[i])

    if "TYPE" in cat_patch.columns:
        t = cat_patch["TYPE"].astype(str).str.upper().to_numpy()
    else:
        t = np.full(len(cat_patch), str(cfg.gal_model).upper(), dtype=object)

    if "ELL" in cat_patch.columns:
        ell = pd.to_numeric(cat_patch["ELL"], errors="coerce").to_numpy(dtype=float)
        ab = np.clip(1.0 - np.nan_to_num(ell, nan=0.0), 0.1, 1.0)
    else:
        ab = np.full(len(cat_patch), 0.8, dtype=float)

    if "THETA" in cat_patch.columns:
        phi = pd.to_numeric(cat_patch["THETA"], errors="coerce").to_numpy(dtype=float)
        phi = np.nan_to_num(phi, nan=0.0)
        phi = -np.where(phi >= 0, 90 - phi, -90 - phi)
    else:
        phi = np.zeros(len(cat_patch), dtype=float)

    if "Re" in cat_patch.columns:
        re_ = pd.to_numeric(cat_patch["Re"], errors="coerce").to_numpy(dtype=float)
        re_ = np.where(np.isfinite(re_), re_, float(cfg.re_fallback_pix))
        re_ = np.clip(re_, 0.3, 100.0)
    else:
        re_ = np.full(len(cat_patch), float(cfg.re_fallback_pix), dtype=float)

    catalog: list[Any] = []
    for i in range(len(cat_patch)):
        pos = PixPos(float(xs[i]), float(ys[i]))
        bright = Fluxes(**init_fluxes[i])
        ti = str(t[i]).upper()
        if ti == "STAR":
            src = PointSource(pos, bright)
        else:
            RE_MIN = 0.1
            RE_MAX = 1000.0
            EE_MAX = 100.0
            shape = EllipseESoft.fromRAbPhi(float(re_[i]), float(ab[i]), float(phi[i]))
            shape.lowers = [float(np.log(RE_MIN)), -float(EE_MAX), -float(EE_MAX)]
            shape.uppers = [float(np.log(RE_MAX)), float(EE_MAX), float(EE_MAX)]

            if ti == "SERSIC":
                src = SersicGalaxy(pos, bright, shape, SersicIndex(float(cfg.sersic_n_init)))
            elif ti == "DEV":
                src = DevGalaxy(pos, bright, shape)
            elif ti == "EXP":
                src = ExpGalaxy(pos, bright, shape)
            else:
                gm = str(cfg.gal_model).lower()
                if gm == "sersic":
                    src = SersicGalaxy(pos, bright, shape, SersicIndex(float(cfg.sersic_n_init)))
                elif gm == "dev":
                    src = DevGalaxy(pos, bright, shape)
                else:
                    src = ExpGalaxy(pos, bright, shape)
        catalog.append(src)
    return catalog


def _robust_limits_percentile(arr: np.ndarray, p_lo: float, p_hi: float, min_span: float = 1e-6):
    a = np.asarray(arr, dtype=float)
    a = a[np.isfinite(a)]
    if a.size == 0:
        return None, None
    vmin, vmax = np.percentile(a, [p_lo, p_hi])
    vmin, vmax = float(vmin), float(vmax)
    if not (np.isfinite(vmin) and np.isfinite(vmax)):
        return None, None
    if (vmax - vmin) < min_span:
        vmin = float(np.min(a))
        vmax = float(np.max(a))
        if (vmax - vmin) < min_span:
            vmin -= 0.5
            vmax += 0.5
    return vmin, vmax


def _robust_resid_limits_percentile(resid: np.ndarray, p_abs: float = 99, min_span: float = 1e-6):
    r = np.asarray(resid, dtype=float)
    r = r[np.isfinite(r)]
    if r.size == 0:
        return None, None
    a = np.nanpercentile(np.abs(r), p_abs)
    if not np.isfinite(a) or a < min_span:
        a = np.nanmax(np.abs(r))
        if not np.isfinite(a) or a < min_span:
            a = 1.0
    return float(-a), float(+a)


def _true_minmax(arr: np.ndarray):
    a = np.asarray(arr, dtype=float)
    a = a[np.isfinite(a)]
    if a.size == 0:
        return None, None
    return float(a.min()), float(a.max())


def _white_from_images(*, images: list[Image], model: bool, tr: Optional[Tractor] = None) -> np.ndarray:
    num = None
    den = None
    for i, tim in enumerate(images):
        img = np.asarray(tim.getImage(), dtype=np.float32)
        inv = np.asarray(tim.getInvvar(), dtype=np.float32)
        good = np.isfinite(img) & np.isfinite(inv) & (inv > 0)
        w = np.where(good, inv, 0.0).astype(np.float32, copy=False)
        if model:
            if tr is None:
                raise ValueError("tr is required when model=True")
            m = np.asarray(tr.getModelImage(i), dtype=np.float32)
            sky = float(getattr(getattr(tim, "sky", None), "getValue", lambda: 0.0)())
            img_use = m + sky
        else:
            img_use = img
        if num is None:
            num = w * img_use
            den = w.copy()
        else:
            num += w * img_use
            den += w
    if num is None or den is None:
        raise ValueError("No images provided for white")
    out = np.full_like(den, np.nan, dtype=np.float32)
    ok = den > 0
    out[ok] = (num[ok] / den[ok]).astype(np.float32)
    return out


def save_patch_overview(
    *,
    tr: Tractor,
    cat_patch: Optional[pd.DataFrame],
    meta: Optional[dict],
    outpath: Path,
    data_p_lo: float,
    data_p_hi: float,
    model_p_lo: float,
    model_p_hi: float,
    resid_p_abs: float,
    log: Optional[logging.Logger] = None,
) -> None:
    meta = meta or {}
    patch_tag = str(meta.get("patch_tag", "patch"))
    nsrc = int(meta.get("n_sources", len(tr.catalog))) if hasattr(tr, "catalog") else 0

    white_data = _white_from_images(images=list(tr.images), model=False, tr=None)
    white_model = _white_from_images(images=list(tr.images), model=True, tr=tr)
    white_resid = np.asarray(white_data - white_model, dtype=np.float32)

    dvmin, dvmax = _robust_limits_percentile(white_data, p_lo=data_p_lo, p_hi=data_p_hi)
    mvmin, mvmax = _robust_limits_percentile(white_model, p_lo=model_p_lo, p_hi=model_p_hi)
    rvmin, rvmax = _robust_resid_limits_percentile(white_resid, p_abs=resid_p_abs)

    fig, axes = plt.subplots(1, 3, figsize=(12, 4), constrained_layout=True)
    panels = [
        ("Data (white)", white_data, dvmin, dvmax, "Data"),
        ("Model+Sky (white)", white_model, mvmin, mvmax, "Model+Sky"),
        ("Residual (white)", white_resid, rvmin, rvmax, "Residual"),
    ]

    x_fit = np.array([float((s.getPosition() if hasattr(s, "getPosition") else s.pos).x) for s in tr.catalog], dtype=float)
    y_fit = np.array([float((s.getPosition() if hasattr(s, "getPosition") else s.pos).y) for s in tr.catalog], dtype=float)
    x_orig = y_orig = None
    if isinstance(cat_patch, pd.DataFrame) and "x_pix_patch" in cat_patch.columns and "y_pix_patch" in cat_patch.columns:
        x_orig = pd.to_numeric(cat_patch["x_pix_patch"], errors="coerce").to_numpy(dtype=float)
        y_orig = pd.to_numeric(cat_patch["y_pix_patch"], errors="coerce").to_numpy(dtype=float)

    for ax, (title, arr, vmin, vmax, cblab) in zip(axes, panels):
        im = ax.imshow(arr, origin="lower", cmap="gray", vmin=vmin, vmax=vmax, interpolation="nearest")
        ax.set_title(title, fontsize=10)
        ax.set_xticks([])
        ax.set_yticks([])
        if x_orig is not None and y_orig is not None:
            ok = np.isfinite(x_orig) & np.isfinite(y_orig)
            if np.any(ok):
                ax.scatter(x_orig[ok], y_orig[ok], s=18, marker="x", c="orange", linewidths=0.8, alpha=0.8)
        okf = np.isfinite(x_fit) & np.isfinite(y_fit)
        if np.any(okf):
            ax.scatter(x_fit[okf], y_fit[okf], s=18, marker="x", c="deepskyblue", linewidths=0.8, alpha=0.8)
        amin, amax = _true_minmax(arr)
        if amin is not None and amax is not None:
            sm = ScalarMappable(norm=Normalize(vmin=amin, vmax=amax), cmap=im.cmap)
            sm.set_array([])
            cb = fig.colorbar(sm, ax=ax, fraction=0.046, pad=0.02, extend="neither")
            cb.set_label(cblab)

    fig.suptitle(f"patch={patch_tag} | n_sources={nsrc}\norig=x orange, fit=x deepskyblue", fontsize=12)
    outpath.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(outpath, dpi=120)
    plt.close(fig)
    if log:
        log.info("Wrote patch overview: %s", str(outpath))


def _cut(arr: np.ndarray, cx: float, cy: float, size: int):
    ix = int(round(float(cx)))
    iy = int(round(float(cy)))
    half = max(1, int(size) // 2)
    ny, nx = arr.shape
    ix = int(np.clip(ix, 0, nx - 1))
    iy = int(np.clip(iy, 0, ny - 1))

    hx = min(half, ix, (nx - 1 - ix))
    hy = min(half, iy, (ny - 1 - iy))

    x0 = ix - hx
    x1 = ix + hx + 1
    y0 = iy - hy
    y1 = iy + hy + 1
    return arr[y0:y1, x0:x1], (y0, y1, x0, x1)


def save_source_montages(
    *,
    tr: Tractor,
    cat_patch: Optional[pd.DataFrame] = None,
    meta: Optional[dict] = None,
    outdir: Path,
    size: int,
    per_band_scale: bool,
    max_sources: Optional[int],
    start: int,
    data_p_lo: float,
    data_p_hi: float,
    model_p_lo: float,
    model_p_hi: float,
    resid_p_abs: float,
    log: Optional[logging.Logger] = None,
) -> None:
    _ensure_dir(outdir)
    meta = meta or {}
    patch_tag = str(meta.get("patch_tag", "patch"))
    roi_bbox = meta.get("roi_bbox", None)
    x0_roi = y0_roi = None
    if isinstance(roi_bbox, (list, tuple)) and len(roi_bbox) == 4:
        try:
            x0_roi = float(roi_bbox[0])
            y0_roi = float(roi_bbox[2])
        except Exception:
            x0_roi = y0_roi = None

    ids = None
    types = None
    x_orig_all = y_orig_all = None
    xw_orig_all = yw_orig_all = None
    if isinstance(cat_patch, pd.DataFrame):
        if "ID" in cat_patch.columns:
            ids = cat_patch["ID"].astype(str).to_numpy()
        if "TYPE" in cat_patch.columns:
            types = cat_patch["TYPE"].astype(str).to_numpy()
        if "x_pix_patch" in cat_patch.columns and "y_pix_patch" in cat_patch.columns:
            x_orig_all = pd.to_numeric(cat_patch["x_pix_patch"], errors="coerce").to_numpy(dtype=float)
            y_orig_all = pd.to_numeric(cat_patch["y_pix_patch"], errors="coerce").to_numpy(dtype=float)
        if "x_pix_white" in cat_patch.columns and "y_pix_white" in cat_patch.columns:
            xw_orig_all = pd.to_numeric(cat_patch["x_pix_white"], errors="coerce").to_numpy(dtype=float)
            yw_orig_all = pd.to_numeric(cat_patch["y_pix_white"], errors="coerce").to_numpy(dtype=float)

    bandnames = [str(getattr(tim, "name", f"band{i}")) for i, tim in enumerate(tr.images)]

    data_by_band = [np.asarray(tim.getImage(), dtype=np.float32) for tim in tr.images]
    model_by_band = [np.asarray(tr.getModelImage(i), dtype=np.float32) for i in range(len(tr.images))]
    sky_by_band = [float(getattr(getattr(tim, "sky", None), "getValue", lambda: 0.0)()) for tim in tr.images]

    indices = list(range(len(tr.catalog)))
    indices = [i for i in indices if i >= int(start)]
    if max_sources is not None:
        indices = indices[: int(max_sources)]

    if log:
        log.info("Saving %d montage(s) to %s", len(indices), str(outdir))

    for si in indices:
        src = tr.catalog[si]
        pos = src.getPosition() if hasattr(src, "getPosition") else src.pos
        cx, cy = float(pos.x), float(pos.y)

        sid = None
        if ids is not None and si < len(ids):
            sid = str(ids[si])
        stype = None
        if types is not None and si < len(types):
            stype = str(types[si])

        x0_fit_white = None
        y0_fit_white = None
        if x0_roi is not None and y0_roi is not None and np.isfinite(cx) and np.isfinite(cy):
            x0_fit_white = float(cx + x0_roi)
            y0_fit_white = float(cy + y0_roi)

        x0_orig = y0_orig = None
        if x_orig_all is not None and y_orig_all is not None and si < len(x_orig_all):
            x0_orig = float(x_orig_all[si]) if np.isfinite(x_orig_all[si]) else None
            y0_orig = float(y_orig_all[si]) if np.isfinite(y_orig_all[si]) else None

        x0_orig_white = y0_orig_white = None
        if xw_orig_all is not None and yw_orig_all is not None and si < len(xw_orig_all):
            x0_orig_white = float(xw_orig_all[si]) if np.isfinite(xw_orig_all[si]) else None
            y0_orig_white = float(yw_orig_all[si]) if np.isfinite(yw_orig_all[si]) else None

        x_fit_all = np.array([float((s.getPosition() if hasattr(s, "getPosition") else s.pos).x) for s in tr.catalog], dtype=float)
        y_fit_all = np.array([float((s.getPosition() if hasattr(s, "getPosition") else s.pos).y) for s in tr.catalog], dtype=float)

        ncols = len(bandnames)
        nrows = 3
        fig, axes = plt.subplots(nrows, ncols, figsize=(3 * ncols, 3 * nrows), constrained_layout=True)
        if ncols == 1:
            axes = np.array(axes).reshape(nrows, 1)

        axes[0, 0].set_ylabel("Data", fontsize=11)
        axes[1, 0].set_ylabel("Model+Sky", fontsize=11)
        axes[2, 0].set_ylabel("Residual", fontsize=11)

        for i, bn in enumerate(bandnames):
            data, (y0, y1, x0, x1) = _cut(data_by_band[i], cx, cy, size)
            model, _ = _cut(model_by_band[i], cx, cy, size)
            model = model + sky_by_band[i]
            resid = data - model

            x_fit_c = cx - float(x0)
            y_fit_c = cy - float(y0)
            x_orig_c = (x0_orig - float(x0)) if (x0_orig is not None) else None
            y_orig_c = (y0_orig - float(y0)) if (y0_orig is not None) else None

            x_fit_c_all = x_fit_all - float(x0)
            y_fit_c_all = y_fit_all - float(y0)
            ok_fit = (
                np.isfinite(x_fit_c_all)
                & np.isfinite(y_fit_c_all)
                & (x_fit_c_all >= 0)
                & (x_fit_c_all < (x1 - x0))
                & (y_fit_c_all >= 0)
                & (y_fit_c_all < (y1 - y0))
            )

            ok_orig = None
            x_orig_c_all = y_orig_c_all = None
            if x_orig_all is not None and y_orig_all is not None:
                x_orig_c_all = x_orig_all - float(x0)
                y_orig_c_all = y_orig_all - float(y0)
                ok_orig = (
                    np.isfinite(x_orig_c_all)
                    & np.isfinite(y_orig_c_all)
                    & (x_orig_c_all >= 0)
                    & (x_orig_c_all < (x1 - x0))
                    & (y_orig_c_all >= 0)
                    & (y_orig_c_all < (y1 - y0))
                )

            if per_band_scale:
                dvmin, dvmax = _robust_limits_percentile(data, p_lo=data_p_lo, p_hi=data_p_hi)
                mvmin, mvmax = _robust_limits_percentile(model, p_lo=model_p_lo, p_hi=model_p_hi)
                rvmin, rvmax = _robust_resid_limits_percentile(resid, p_abs=resid_p_abs)
            else:
                dvmin = dvmax = mvmin = mvmax = rvmin = rvmax = None

            ax = axes[0, i]
            im0 = ax.imshow(data, origin="lower", cmap="gray", vmin=dvmin, vmax=dvmax, interpolation="nearest")
            ax.set_title(bn, fontsize=10)
            ax.set_xticks([])
            ax.set_yticks([])
            if np.isfinite(x_fit_c) and np.isfinite(y_fit_c):
                ax.axvline(x_fit_c, color="magenta", lw=0.8, alpha=0.9)
                ax.axhline(y_fit_c, color="magenta", lw=0.8, alpha=0.9)
            if (x_orig_c is not None) and (y_orig_c is not None) and np.isfinite(x_orig_c) and np.isfinite(y_orig_c):
                ax.axvline(x_orig_c, color="lime", lw=0.8, alpha=0.9, linestyle="--")
                ax.axhline(y_orig_c, color="lime", lw=0.8, alpha=0.9, linestyle="--")
            if np.any(ok_fit):
                ax.scatter(x_fit_c_all[ok_fit], y_fit_c_all[ok_fit], s=18, marker="x", c="deepskyblue", linewidths=0.8, alpha=0.8)
            if ok_orig is not None and np.any(ok_orig):
                ax.scatter(x_orig_c_all[ok_orig], y_orig_c_all[ok_orig], s=18, marker="x", c="orange", linewidths=0.8, alpha=0.8)

            dmin_true, dmax_true = _true_minmax(data)
            if dmin_true is not None and dmax_true is not None:
                sm0 = ScalarMappable(norm=Normalize(vmin=dmin_true, vmax=dmax_true), cmap=im0.cmap)
                sm0.set_array([])
                cb0 = fig.colorbar(sm0, ax=ax, fraction=0.046, pad=0.02, extend="neither")
                cb0.set_label("Data")

            ax = axes[1, i]
            im1 = ax.imshow(model, origin="lower", cmap="gray", vmin=mvmin, vmax=mvmax, interpolation="nearest")
            ax.set_xticks([])
            ax.set_yticks([])
            if np.isfinite(x_fit_c) and np.isfinite(y_fit_c):
                ax.axvline(x_fit_c, color="magenta", lw=0.8, alpha=0.9)
                ax.axhline(y_fit_c, color="magenta", lw=0.8, alpha=0.9)
            if (x_orig_c is not None) and (y_orig_c is not None) and np.isfinite(x_orig_c) and np.isfinite(y_orig_c):
                ax.axvline(x_orig_c, color="lime", lw=0.8, alpha=0.9, linestyle="--")
                ax.axhline(y_orig_c, color="lime", lw=0.8, alpha=0.9, linestyle="--")
            if np.any(ok_fit):
                ax.scatter(x_fit_c_all[ok_fit], y_fit_c_all[ok_fit], s=18, marker="x", c="deepskyblue", linewidths=0.8, alpha=0.8)
            if ok_orig is not None and np.any(ok_orig):
                ax.scatter(x_orig_c_all[ok_orig], y_orig_c_all[ok_orig], s=18, marker="x", c="orange", linewidths=0.8, alpha=0.8)

            mmin_true, mmax_true = _true_minmax(model)
            if mmin_true is not None and mmax_true is not None:
                sm1 = ScalarMappable(norm=Normalize(vmin=mmin_true, vmax=mmax_true), cmap=im1.cmap)
                sm1.set_array([])
                cb1 = fig.colorbar(sm1, ax=ax, fraction=0.046, pad=0.02, extend="neither")
                cb1.set_label("Model+Sky")

            ax = axes[2, i]
            im2 = ax.imshow(resid, origin="lower", cmap="gray", vmin=rvmin, vmax=rvmax, interpolation="nearest")
            ax.set_xticks([])
            ax.set_yticks([])
            if np.isfinite(x_fit_c) and np.isfinite(y_fit_c):
                ax.axvline(x_fit_c, color="magenta", lw=0.8, alpha=0.9)
                ax.axhline(y_fit_c, color="magenta", lw=0.8, alpha=0.9)
            if (x_orig_c is not None) and (y_orig_c is not None) and np.isfinite(x_orig_c) and np.isfinite(y_orig_c):
                ax.axvline(x_orig_c, color="lime", lw=0.8, alpha=0.9, linestyle="--")
                ax.axhline(y_orig_c, color="lime", lw=0.8, alpha=0.9, linestyle="--")
            if np.any(ok_fit):
                ax.scatter(x_fit_c_all[ok_fit], y_fit_c_all[ok_fit], s=18, marker="x", c="deepskyblue", linewidths=0.8, alpha=0.8)
            if ok_orig is not None and np.any(ok_orig):
                ax.scatter(x_orig_c_all[ok_orig], y_orig_c_all[ok_orig], s=18, marker="x", c="orange", linewidths=0.8, alpha=0.8)

            rmin_true, rmax_true = _true_minmax(resid)
            if rmin_true is not None and rmax_true is not None:
                sm2 = ScalarMappable(norm=Normalize(vmin=rmin_true, vmax=rmax_true), cmap=im2.cmap)
                sm2.set_array([])
                cb2 = fig.colorbar(sm2, ax=ax, fraction=0.046, pad=0.02, extend="neither")
                cb2.set_label("Residual")

        s_id = sid if sid is not None else f"row{si}"
        s0 = f"ID={s_id} | patch={patch_tag} | idx_in_patch={si}/{len(tr.catalog)-1}"
        if stype is not None and stype != "" and stype.lower() != "nan":
            s0 += f" | TYPE={stype}"
        s_legend = "fit=center crosshair=magenta, orig=crosshair=lime(--), fit/all=x deepskyblue, orig/all=x orange"
        title = s0 + "\n" + s_legend
        fig.suptitle(title, fontsize=12)
        out_path = outdir / f"src_{si:06d}.png"
        plt.savefig(out_path, dpi=120)
        plt.close(fig)


def compute_flux_errors(tr: Tractor) -> dict[tuple[int, str], float]:
    names = tr.getParamNames()
    bandnames = [str(getattr(tim, "name", f"band{i}")) for i, tim in enumerate(tr.images)]
    band_to_i = {bn: i for i, bn in enumerate(bandnames)}

    pat = re.compile(r"^catalog\.source(\d+)\.brightness\.(.+)$")

    var = tr.optimize(variance=True, just_variance=True)
    if var is None or len(var) != len(names):
        return {}

    out: dict[tuple[int, str], float] = {}
    for i, pname in enumerate(names):
        m = pat.match(pname)
        if not m:
            continue
        sid = int(m.group(1))
        bn = m.group(2)
        if band_to_i.get(bn, None) is None:
            continue
        v = var[i]
        if v is None or (not np.isfinite(v)) or v <= 0:
            continue
        out[(sid, bn)] = float(math.sqrt(v))
    return out


def run_patch(*, payload: dict, epsf_root: Path, outdir: Path, cfg: PatchRunConfig) -> pd.DataFrame:
    meta = payload.get("meta", {}) or {}
    tag = _patch_tag_from_meta(meta)
    patch_out = outdir / tag
    _ensure_dir(patch_out)
    _ensure_dir(patch_out / "cutouts")

    log = _make_logger(patch_out, tag)
    log.info("Starting patch run: %s", tag)

    (x0_roi, x1_roi, y0_roi, y1_roi) = _roi_bbox_from_meta(meta)
    meta = dict(meta)
    meta.setdefault("roi_bbox", (int(x0_roi), int(x1_roi), int(y0_roi), int(y1_roi)))
    (patch_out / "meta.json").write_text(json.dumps(meta, indent=2, default=str))

    per_filter_patch = payload["per_filter_patch"]
    cat_patch = payload["cat_patch"]
    if not isinstance(cat_patch, pd.DataFrame):
        cat_patch = pd.DataFrame(cat_patch)

    epsf_tag = str(meta.get("epsf_tag", ""))
    if not epsf_tag:
        raise ValueError("meta.epsf_tag is required")

    psf_by_band = build_psf_by_band_for_patch(per_filter_patch=per_filter_patch, epsf_root=epsf_root, epsf_tag=epsf_tag, cfg=cfg, log=log)
    tractor_images, _image_data = build_tractor_images_from_per_filter_patch(per_filter_patch=per_filter_patch, psf_by_filt=psf_by_band, use_sky_sigma=True)
    catalog = build_catalog_from_cat_patch(cat_patch, tractor_images, cfg)

    tr = Tractor(tractor_images, catalog, optimizer=ConstrainedOptimizer())
    tr.thawAllRecursive()

    converged = False
    last_dlnp: float | None = None
    niters = 0
    for it in range(int(cfg.n_opt_iters)):
        dlnp, _X, _alpha = tr.optimize()
        niters = it + 1
        try:
            last_dlnp = float(dlnp)
        except Exception:
            last_dlnp = None
        log.info("opt iter %02d  dlnp=%s", it, str(dlnp))
        if dlnp < float(cfg.dlnp_stop):
            converged = True
            break

    margin = max(0, int(getattr(cfg, "flag_maxiter_margin", 0)))
    hit_max_iters = (not converged) and (niters >= max(1, int(cfg.n_opt_iters) - margin))
    if hit_max_iters:
        log.info(
            "WARNING: did not converge before max iters. niters=%d n_opt_iters=%d margin=%d last_dlnp=%s",
            int(niters),
            int(cfg.n_opt_iters),
            int(margin),
            str(last_dlnp),
        )

    meta = dict(meta)
    meta["opt_niters"] = int(niters)
    meta["opt_converged"] = bool(converged)
    meta["opt_hit_max_iters"] = bool(hit_max_iters)
    meta["opt_last_dlnp"] = (float(last_dlnp) if last_dlnp is not None and np.isfinite(last_dlnp) else None)
    (patch_out / "meta.json").write_text(json.dumps(meta, indent=2, default=str))

    out = cat_patch.copy()
    out["patch_tag"] = str(tag)
    out["epsf_tag"] = str(epsf_tag)
    out["opt_niters"] = int(niters)
    out["opt_converged"] = bool(converged)
    out["opt_hit_max_iters"] = bool(hit_max_iters)
    out["opt_last_dlnp"] = float(last_dlnp) if last_dlnp is not None and np.isfinite(last_dlnp) else np.nan
    out["x_pix_patch_fit"] = np.nan
    out["y_pix_patch_fit"] = np.nan
    out["x_pix_white_fit"] = np.nan
    out["y_pix_white_fit"] = np.nan
    out["RA_fit"] = np.nan
    out["DEC_fit"] = np.nan
    out["stype_fit"] = ""
    out["sersic_n_fit"] = np.nan
    out["re_pix_fit"] = np.nan
    out["ab_fit"] = np.nan
    out["phi_deg_fit"] = np.nan
    out["ELL_fit"] = np.nan
    out["Re_fit"] = np.nan
    out["THETA_fit"] = np.nan

    bandnames = [str(getattr(tim, "name", f"band{i}")) for i, tim in enumerate(tractor_images)]
    for bn in bandnames:
        out[f"FLUX_{bn}_fit"] = np.nan
        out[f"FLUXERR_{bn}_fit"] = np.nan

    def _get_sersic_n(src, default=np.nan):
        if not hasattr(src, "sersicindex"):
            return default
        si = src.sersicindex
        if hasattr(si, "getValue"):
            return float(si.getValue())
        if hasattr(si, "value"):
            return float(si.value)
        if hasattr(si, "n"):
            return float(si.n)
        return default

    def _get_shape_params(src):
        if not hasattr(src, "shape"):
            return (np.nan, np.nan, np.nan)
        sh = src.shape
        re_ = float(getattr(sh, "re", np.nan))
        ab_ = float(getattr(sh, "ab", np.nan))
        if hasattr(sh, "phi"):
            phi_deg = float(getattr(sh, "phi", np.nan))
        elif hasattr(sh, "theta"):
            try:
                phi_deg = float(-np.degrees(sh.theta))
            except Exception:
                phi_deg = np.nan
        else:
            phi_deg = np.nan
        if np.isfinite(phi_deg):
            phi_deg = float(phi_deg % 180.0)
        return (re_, ab_, phi_deg)

    for i, src in enumerate(tr.catalog):
        pos = src.getPosition() if hasattr(src, "getPosition") else src.pos
        bx = src.getBrightness() if hasattr(src, "getBrightness") else src.brightness
        out.at[i, "x_pix_patch_fit"] = float(pos.x)
        out.at[i, "y_pix_patch_fit"] = float(pos.y)
        out.at[i, "x_pix_white_fit"] = float(pos.x) + float(x0_roi)
        out.at[i, "y_pix_white_fit"] = float(pos.y) + float(y0_roi)

        if isinstance(src, SersicGalaxy):
            out.at[i, "stype_fit"] = "sersic"
            out.at[i, "sersic_n_fit"] = _get_sersic_n(src)
            re_, ab_, phi_ = _get_shape_params(src)
            out.at[i, "re_pix_fit"] = re_
            out.at[i, "ab_fit"] = ab_
            out.at[i, "phi_deg_fit"] = phi_
            if np.isfinite(re_):
                out.at[i, "Re_fit"] = float(re_)
            if np.isfinite(ab_):
                out.at[i, "ELL_fit"] = float(1.0 - ab_)
            if np.isfinite(phi_):
                out.at[i, "THETA_fit"] = float(phi_ - 90.0)
        elif isinstance(src, DevGalaxy):
            out.at[i, "stype_fit"] = "dev"
            re_, ab_, phi_ = _get_shape_params(src)
            out.at[i, "re_pix_fit"] = re_
            out.at[i, "ab_fit"] = ab_
            out.at[i, "phi_deg_fit"] = phi_
            if np.isfinite(re_):
                out.at[i, "Re_fit"] = float(re_)
            if np.isfinite(ab_):
                out.at[i, "ELL_fit"] = float(1.0 - ab_)
            if np.isfinite(phi_):
                out.at[i, "THETA_fit"] = float(phi_ - 90.0)
        elif isinstance(src, ExpGalaxy):
            out.at[i, "stype_fit"] = "exp"
            re_, ab_, phi_ = _get_shape_params(src)
            out.at[i, "re_pix_fit"] = re_
            out.at[i, "ab_fit"] = ab_
            out.at[i, "phi_deg_fit"] = phi_
            if np.isfinite(re_):
                out.at[i, "Re_fit"] = float(re_)
            if np.isfinite(ab_):
                out.at[i, "ELL_fit"] = float(1.0 - ab_)
            if np.isfinite(phi_):
                out.at[i, "THETA_fit"] = float(phi_ - 90.0)
        else:
            out.at[i, "stype_fit"] = "star"

        for bn in bandnames:
            try:
                out.at[i, f"FLUX_{bn}_fit"] = float(bx.getFlux(bn))
            except Exception:
                out.at[i, f"FLUX_{bn}_fit"] = np.nan

    try:
        ferr = compute_flux_errors(tr)
        for (sid, bn), fe in ferr.items():
            if 0 <= sid < len(out):
                out.at[sid, f"FLUXERR_{bn}_fit"] = float(fe)
        log.info("Computed flux errors for %d (source,band) pairs", len(ferr))
    except Exception as e:
        log.info("WARNING: flux error computation failed: %s", str(e))

    out_csv = patch_out / f"{tag}_cat_fit.csv"
    out.to_csv(out_csv, index=False)
    log.info("Wrote fitted catalog: %s", str(out_csv))

    if cfg.save_cutouts:
        save_source_montages(
            tr=tr,
            cat_patch=cat_patch,
            meta=meta,
            outdir=patch_out / "cutouts",
            size=int(cfg.cutout_size_pix),
            per_band_scale=True,
            max_sources=cfg.cutout_max_sources,
            start=int(cfg.cutout_start),
            data_p_lo=float(cfg.cutout_data_p_lo),
            data_p_hi=float(cfg.cutout_data_p_hi),
            model_p_lo=float(cfg.cutout_model_p_lo),
            model_p_hi=float(cfg.cutout_model_p_hi),
            resid_p_abs=float(cfg.cutout_resid_p_abs),
            log=log,
        )

    if getattr(cfg, "save_patch_overview", False):
        try:
            save_patch_overview(
                tr=tr,
                cat_patch=cat_patch,
                meta=meta,
                outpath=patch_out / "patch_overview.png",
                data_p_lo=float(cfg.cutout_data_p_lo),
                data_p_hi=float(cfg.cutout_data_p_hi),
                model_p_lo=float(cfg.cutout_model_p_lo),
                model_p_hi=float(cfg.cutout_model_p_hi),
                resid_p_abs=float(cfg.cutout_resid_p_abs),
                log=log,
            )
        except Exception as e:
            log.info("WARNING: patch overview failed: %s", str(e))

    log.info("Done patch run: %s", tag)
    return out


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--inputs", required=True, help="Path to patch input .pkl.gz")
    ap.add_argument("--epsf-root", required=True, help="ePSF root directory")
    ap.add_argument("--outdir", required=True, help="Output base directory")
    ap.add_argument("--no-cutouts", action="store_true", help="Disable montage saving")
    ap.add_argument("--no-patch-overview", action="store_true", help="Disable per-patch overview plot")
    ap.add_argument("--cutout-size", type=int, default=100)
    ap.add_argument("--cutout-max-sources", type=int, default=None)
    ap.add_argument("--cutout-start", type=int, default=0)
    ap.add_argument("--cutout-data-p-lo", type=float, default=1)
    ap.add_argument("--cutout-data-p-hi", type=float, default=99)
    ap.add_argument("--cutout-model-p-lo", type=float, default=1)
    ap.add_argument("--cutout-model-p-hi", type=float, default=99)
    ap.add_argument("--cutout-resid-p-abs", type=float, default=99)
    ap.add_argument("--gal-model", default="dev", choices=["dev", "exp", "sersic"])
    ap.add_argument("--n-opt-iters", type=int, default=200)
    ap.add_argument("--dlnp-stop", type=float, default=1e-6)
    ap.add_argument("--flag-maxiter-margin", type=int, default=5)
    ap.add_argument("--r-ap", type=float, default=5.0)
    ap.add_argument("--eps-flux", type=float, default=1e-4)
    ap.add_argument("--hybrid-psf-n", type=int, default=4)
    ap.add_argument("--sersic-n-init", type=float, default=3.0)
    ap.add_argument("--re-fallback-pix", type=float, default=3.0)
    ap.add_argument("--moffat-beta", type=float, default=3.5)
    ap.add_argument("--moffat-radius-pix", type=float, default=25.0)
    ap.add_argument("--moffat-default-fwhm-pix", type=float, default=4.0)
    ap.add_argument("--moffat-module", default=None, help="Optional path to moffat_psf.py")
    args = ap.parse_args(argv)

    if args.moffat_module:
        _load_moffat_psf_class(args.moffat_module)
    else:
        _load_moffat_psf_class(None)

    payload = load_patch_inputs(args.inputs)
    cfg = PatchRunConfig(
        save_cutouts=not args.no_cutouts,
        save_patch_overview=not args.no_patch_overview,
        cutout_size_pix=int(args.cutout_size),
        cutout_max_sources=args.cutout_max_sources,
        cutout_start=int(args.cutout_start),
        cutout_data_p_lo=float(args.cutout_data_p_lo),
        cutout_data_p_hi=float(args.cutout_data_p_hi),
        cutout_model_p_lo=float(args.cutout_model_p_lo),
        cutout_model_p_hi=float(args.cutout_model_p_hi),
        cutout_resid_p_abs=float(args.cutout_resid_p_abs),
        gal_model=str(args.gal_model),
        n_opt_iters=int(args.n_opt_iters),
        dlnp_stop=float(args.dlnp_stop),
        flag_maxiter_margin=int(args.flag_maxiter_margin),
        r_ap=float(args.r_ap),
        eps_flux=float(args.eps_flux),
        hybrid_psf_n=int(args.hybrid_psf_n),
        sersic_n_init=float(args.sersic_n_init),
        re_fallback_pix=float(args.re_fallback_pix),
        moffat_beta=float(args.moffat_beta),
        moffat_radius_pix=float(args.moffat_radius_pix),
        moffat_default_fwhm_pix=float(args.moffat_default_fwhm_pix),
    )

    run_patch(payload=payload, epsf_root=Path(args.epsf_root), outdir=Path(args.outdir), cfg=cfg)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
