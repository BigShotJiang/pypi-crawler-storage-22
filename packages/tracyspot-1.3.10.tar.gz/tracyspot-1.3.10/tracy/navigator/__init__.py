"""Navigation and main UI wiring for Tracy."""

from .main import KymographNavigator

__all__ = ["KymographNavigator"]
