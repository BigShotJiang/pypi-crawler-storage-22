"""Basic tests for the tradestation-mcp package."""

import importlib


def test_version():
    """Package version is defined and valid."""
    import tradestation_mcp

    assert tradestation_mcp.__version__ == "1.0.0"


def test_imports():
    """All submodules are importable."""
    importlib.import_module("tradestation_mcp.auth")
    importlib.import_module("tradestation_mcp.client")
    importlib.import_module("tradestation_mcp.server")


def test_tool_modules_importable():
    """Tool registration modules are importable."""
    importlib.import_module("tradestation_mcp.tools.market_data")
    importlib.import_module("tradestation_mcp.tools.brokerage")
    importlib.import_module("tradestation_mcp.tools.order_execution")
