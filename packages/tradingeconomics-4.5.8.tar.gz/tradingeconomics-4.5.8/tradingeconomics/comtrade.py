import json
import urllib
import pandas as pd
import sys
from . import functions as fn
from . import glob
import ssl

PY3 = sys.version_info[0] == 3

if PY3:  # Python 3+
    from urllib.request import urlopen  # type: ignore
    from urllib.parse import quote  # type: ignore
else:  # Python 2.X
    from urllib import urlopen  # type: ignore
    from urllib import quote  # type: ignore


class ParametersError(ValueError):
    pass


class CredentialsError(ValueError):
    pass


class LoginError(AttributeError):
    pass


class TypeError(AttributeError):
    pass


class WebRequestError(ValueError):
    pass


def checkCmtCountry(country):
    linkAPI = "/comtrade/country/"

    if type(country) is str:
        linkAPI += quote(country)
    else:
        encoded_items = [quote(c) for c in country]
        linkAPI += "/".join(encoded_items)
    return linkAPI


def checkCmtPage(linkAPI, page_number):
    if page_number != None:
        linkAPI += "/{0}".format(page_number)

    return linkAPI


def getCmtLastUpdates(output_type=None, country=None, start_date=None):
    """
    Get last updates by country or date on Comtrade database.
    =================================================================================

    Parameters:
    -----------
    output_type: string
            'dict'(default) for dictionary format output, 'df' for data frame,
            'raw' for list of dictionaries directly from the web.

    country: string
            For example: 'portugal'

    start_date: string
            For example: '2021-01-01'

    Example
    -------
    getCmtLastUpdates(start_date='2022-01-01')
    getCmtLastUpdates(country = 'portugal', start_date='2022-01-01')
    getCmtLastUpdates(country = 'portugal', start_date='2022-01-01', output_type='df')
    """

    fn.setup_ssl_context()

    if country:
        linkAPI = "/comtrade/updates/country/" + quote(country)
    else:
        linkAPI = "/comtrade/updates"

    if start_date:
        linkAPI += "?from=" + quote(start_date)

    return fn.dataRequest(api_request=linkAPI, output_type=output_type)


def getCmtUpdates(output_type=None):
    """
    Get latest updates information on Comtrade.
    =================================================================================

    Parameters:
    -----------
    output_type: string.
             'dict'(default) for dictionary format output, 'df' for data frame,
             'raw' for list of dictionaries directly from the web.

    Notes
    -----
    with no parameters a list of last updates will be given.

    Example
    -------
    getCmtUpdates(output_type = None)

    """
    fn.setup_ssl_context()

    linkAPI = "/comtrade/updates"

    return fn.dataRequest(api_request=linkAPI, output_type=output_type)


def getCmtCategories(output_type=None):
    """
    Get detailed information about Comtrade categories.
    =================================================================================

    Parameters:
    -----------
    output_type: string.
                'dict'(default) for dictionary format output, 'df' for data frame,
                'raw' for list of dictionaries directly from the web.

    Notes
    -----
    A list of all categories will be given.

    Example
    -------
    getCmtCategories(category = None, output_type = None)

    """
    fn.setup_ssl_context()

    linkAPI = "/comtrade/categories"

    return fn.dataRequest(api_request=linkAPI, output_type=output_type)


def getCmtCountry(country=None, page_number=None, output_type=None):
    """
    Get detailed information about Comtrade countries.
    =================================================================================

    Parameters:
    -----------
    country:list.
             List of strings of all categories or one country with pagination.
             for example:
                country = 'country_name' , page_number = 3
                country = ['country_name', 'country_name'], page_number = 3
    output_type: string.
             'dict'(default) for dictionary format output, 'df' for data frame,
             'raw' for list of dictionaries directly from the web.

    Notes
    -----
    with no parameters a list of all categories will be given.

    Example
    -------
    getCmtCountry(country = None, page_number = None, output_type = None)

    getCmtCountry(country = 'china' , page_number = 3, output_type = None)

    getCmtCountry(country = ['china', 'portugal'], page_number = 3, output_type = None)

    """
    fn.setup_ssl_context()

    linkAPI = "/comtrade/countries"

    if country is None:
        linkAPI = "/comtrade/countries"
    else:
        linkAPI = checkCmtCountry(country)

    if page_number != None:
        linkAPI = checkCmtPage(linkAPI, page_number)

    return fn.dataRequest(api_request=linkAPI, output_type=output_type)


def getCmtHistorical(symbol=None, output_type=None):
    """
    Get Historical data.
    =================================================================================

    Parameters:
    -----------
    symbol:list.
             List of strings by a specific symbol.
             for example:
                symbol = 'te_symbol'
    output_type: string.
             'dict'(default) for dictionary format output, 'df' for data frame,
             'raw' for list of dictionaries directly from the web.

    Notes
    -----
    A symbol is required.

    Example
    -------
    getCmtHistorical(symbol = 'PRTESP24031', output_type = None)

    """
    fn.setup_ssl_context()

    linkAPI = "/comtrade/historical/"

    if symbol == None:
        return "A symbol is required!"
    else:
        linkAPI = "/comtrade/historical/" + quote(symbol)

    return fn.dataRequest(api_request=linkAPI, output_type=output_type)


def getCmtTwoCountries(
    country1=None, country2=None, page_number=None, output_type=None
):
    """
    Get detailed information about Comtrade between two countries.
    =================================================================================

    Parameters:
    -----------
    country:list.
             List of strings of all categories between two countries with pagination.

    output_type: string.
             'dict'(default) for dictionary format output, 'df' for data frame,
             'raw' for list of dictionaries directly from the web.

    Example
    -------
    getCmtTwoCountries(country1 = 'portugal', country2 = 'spain', page_number = 3, output_type = None)

    """
    fn.setup_ssl_context()

    linkAPI = "/comtrade/country"

    if country1 is not None and country2 is None:
        linkAPI = f"/comtrade/country/{quote(country1)}"
    elif country1 is not None and country2 is not None:
        linkAPI = f"/comtrade/country/{quote(country1)}/{quote(country2)}"
    else:
        return "country1 is required"

    if page_number != None:
        linkAPI = checkCmtPage(linkAPI, page_number)

    return fn.dataRequest(api_request=linkAPI, output_type=output_type)


def getCmtCountryByCategory(country=None, type=None, category=None, output_type=None):
    """
    Get detailed information about Comtrade Country by Imports or Exports and by Category
    =================================================================================

    Parameters:
    -----------
    country:string.
             for example:
                country = 'country_name'

    type: string.
            for example:
                type = 'import'
                type = 'export'
    category: string.
            for example:
                category = 'live animals'
                category = 'Swine, live'
                category = 'Sheep and goats, live'


    output_type: string.
             'dict'(default) for dictionary format output, 'df' for data frame,
             'raw' for list of dictionaries directly from the web.

    Notes
    -----
    'country' and 'type' parameters are not optional.
    if 'category' is None, returns total exports or imports with main category

    Example
    -------
    getCmtCountryByCategory(country = 'Portugal', type = 'import', category = None, output_type = None )

    getCmtCountryByCategory(country = 'United States', type = 'export', category = 'live animals', output_type = 'raw')

    getCmtCountryByCategory(country = 'Brazil', type = import, category = 'Swine, live', output_type = 'df' )

    """

    if country is None:
        return f"country is missing"
    if type is None:
        return f"type is missing. Choose 'import' or 'export'"

    def getLinkApi(country, type, category):
        api_url_base = "/comtrade"

        if category is None:
            return f"{api_url_base}/{type}/{quote(country)}"
        return f"{api_url_base}/{type}/{quote(country)}/{quote(category)}"

    link_api = getLinkApi(country, type, category)

    return fn.dataRequest(api_request=link_api, output_type=output_type)


def getCmtTotalByType(country=None, type=None, output_type=None):
    """
    Get detailed information about Comtrade Country Total by Import or Exports
    =================================================================================

    Parameters:
    -----------
    country:string.
                for example:
                country = 'country_name' ,

    type: string.
            for example:
                type = 'import'
                type = 'export'

    output_type: string.
                'dict'(default) for dictionary format output, 'df' for data frame,
                'raw' for list of dictionaries directly from the web.

    Notes
    -----
    country and type parameters are not optional.

    Example
    -------
    getCmtTotalByType(country = 'Portugal', type = 'import', output_type = None )

    getCmtTotalByType(country = 'United States', type = 'export', output_type = 'raw' )

    getCmtTotalByType(country = 'Brazil', type = import, output_type = 'df' )

    """

    if country is None:
        return f"country is missing"

    if type is None:
        return f"type is missing. Choose 'import' or 'export'"

    def getLinkApi(country, type):
        api_url_base = "/comtrade"

        return f"{api_url_base}/{type}/{quote(country)}/totals/"

    link_api = getLinkApi(country, type)

    return fn.dataRequest(api_request=link_api, output_type=output_type)


def getCmtCountryFilterByType(
    country1=None, country2=None, type=None, output_type=None
):
    """
    Get detailed information about Comtrade Countries filter by type 'import' or 'export'
    =================================================================================

    Parameters:
    -----------
    country:string.
             for example:
                country1 = 'country_name'
                country2 = 'country_name'

    type: string.
            for example:
                type = 'import'
                type = 'export'
    category: string.
            for example:
                category = 'live animals'
                category = 'Swine, live'
                category = 'Sheep and goats, live'


    output_type: string.
             'dict'(default) for dictionary format output, 'df' for data frame,
             'raw' for list of dictionaries directly from the web.

    Notes
    -----
    'country1' and 'type' parameters are not optional.


    Example
    -------
    getCmtCountryFilterByType(country1 = 'Portugal', country2 = 'Spain', type = 'import' )

    getCmtCountryFilterByType(country1 = 'United States', type = 'export')


    """

    if country1 is None:
        return f"country is missing"
    if type is None:
        return f"type is missing. Choose 'import' or 'export'"

    def getLinkApi(country1, country2):
        api_url_base = "/comtrade/country"

        if country2 is None:
            return f"{api_url_base}/{quote(country1)}"
        return f"{api_url_base}/{quote(country1)}/{quote(country2)}"

    link_api = getLinkApi(country1, country2)

    try:
        link_api += f"?type={type}"
    except AttributeError:
        raise TypeError('type is missing. Choose "import" or "export"')

    return fn.dataRequest(api_request=link_api, output_type=output_type)


def getCmtSnapshotByType(country=None, type=None, output_type=None):
    """
    Get Snapshot of data per country filtered by type: import or export
    =================================================================================

    Parameters:
    -----------
    country:string.
                for example:
                country = 'country_name' ,

    type: string.
            for example:
                type = 'import'
                type = 'export'

    output_type: string.
                'dict'(default) for dictionary format output, 'df' for data frame,
                'raw' for list of dictionaries directly from the web.

    Notes
    -----
    country and type parameters are not optional.

    Example
    -------
    getCmtSnapshotByType(country = 'Portugal', type = 'import', output_type = None )

    getCmtSnapshotByType(country = 'United States', type = 'export', output_type = 'raw' )

    getCmtSnapshotByType(country = 'Brazil', type = import, output_type = 'df' )

    """

    if country is None:
        raise ParametersError(f"country is missing")

    if type is None:
        raise ParametersError(f"type is missing. Choose 'import' or 'export'")

    def getLinkApi(country, type):
        api_url_base = "/comtrade/country"

        return f"{api_url_base}/{quote(country)}?type={type}"

    link_api = getLinkApi(country, type)

    return fn.dataRequest(api_request=link_api, output_type=output_type)
