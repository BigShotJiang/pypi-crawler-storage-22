"""
TradingView MCP Server - A comprehensive MCP server for TradingView market screening.

This package provides:
- Direct TradingView API integration for market screening
- SQL-like query interface for building complex filters
- MCP tools for market analysis and technical indicators
- Support for 76+ markets including crypto, stocks, forex, and futures
"""

from tradingview_mcp.server import mcp, main

__version__ = "1.0.0"
__all__ = ["mcp", "main"]
