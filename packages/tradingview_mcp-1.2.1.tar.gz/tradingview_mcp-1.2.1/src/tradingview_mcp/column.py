"""
Column class for building filter expressions.

Provides a SQL-like interface for creating WHERE clauses.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Iterable, Optional

if TYPE_CHECKING:
    from tradingview_mcp.models import FilterOperationDict


class Column:
    """
    A Column object represents a field in the TradingView stock screener.

    Used in SELECT queries and WHERE queries with the Query object.
    Supports all comparison operations: <, <=, >, >=, ==, !=
    Plus methods like between(), isin(), crosses(), etc.

    Examples:
        >>> Column('close') > 2.5
        >>> Column('close').between(2.5, 15)
        >>> Column('high') > Column('VWAP')
        >>> Column('type').isin(['stock', 'fund'])
        >>> Column('description').like('apple')
        >>> Column('RSI') < 30
    """

    def __init__(self, name: str) -> None:
        """
        Create a Column object from a column name.

        Args:
            name: The column/field name (e.g., 'close', 'RSI', 'volume')
        """
        self.name = name

    @staticmethod
    def _extract_name(obj: "Column | str | int | float") -> str | int | float:
        """Extract the name from a Column or return the value as-is."""
        if isinstance(obj, Column):
            return obj.name
        return obj

    def __gt__(self, other: "Column | str | int | float") -> "FilterOperationDict":
        """Greater than comparison."""
        return {"left": self.name, "operation": "greater", "right": self._extract_name(other)}

    def __ge__(self, other: "Column | str | int | float") -> "FilterOperationDict":
        """Greater than or equal comparison."""
        return {"left": self.name, "operation": "egreater", "right": self._extract_name(other)}

    def __lt__(self, other: "Column | str | int | float") -> "FilterOperationDict":
        """Less than comparison."""
        return {"left": self.name, "operation": "less", "right": self._extract_name(other)}

    def __le__(self, other: "Column | str | int | float") -> "FilterOperationDict":
        """Less than or equal comparison."""
        return {"left": self.name, "operation": "eless", "right": self._extract_name(other)}

    def __eq__(self, other: "Column | str | int | float") -> "FilterOperationDict":  # type: ignore[override]
        """Equal comparison."""
        return {"left": self.name, "operation": "equal", "right": self._extract_name(other)}

    def __ne__(self, other: "Column | str | int | float") -> "FilterOperationDict":  # type: ignore[override]
        """Not equal comparison."""
        return {"left": self.name, "operation": "nequal", "right": self._extract_name(other)}

    def crosses(self, other: "Column | str") -> "FilterOperationDict":
        """Check if column crosses another column/value."""
        return {"left": self.name, "operation": "crosses", "right": self._extract_name(other)}

    def crosses_above(self, other: "Column | str") -> "FilterOperationDict":
        """Check if column crosses above another column/value."""
        return {"left": self.name, "operation": "crosses_above", "right": self._extract_name(other)}

    def crosses_below(self, other: "Column | str") -> "FilterOperationDict":
        """Check if column crosses below another column/value."""
        return {"left": self.name, "operation": "crosses_below", "right": self._extract_name(other)}

    def between(
        self, left: "Column | str | int | float", right: "Column | str | int | float"
    ) -> "FilterOperationDict":
        """
        Check if value is between two bounds (inclusive).

        Examples:
            >>> Column('close').between(10, 50)
            >>> Column('close').between(Column('EMA5'), Column('EMA20'))
        """
        return {
            "left": self.name,
            "operation": "in_range",
            "right": [self._extract_name(left), self._extract_name(right)],
        }

    def not_between(
        self, left: "Column | str | int | float", right: "Column | str | int | float"
    ) -> "FilterOperationDict":
        """Check if value is NOT between two bounds."""
        return {
            "left": self.name,
            "operation": "not_in_range",
            "right": [self._extract_name(left), self._extract_name(right)],
        }

    def isin(self, values: Iterable) -> "FilterOperationDict":
        """
        Check if value is in a list of values.

        Examples:
            >>> Column('type').isin(['stock', 'fund'])
            >>> Column('exchange').isin(['NASDAQ', 'NYSE'])
        """
        return {"left": self.name, "operation": "in_range", "right": list(values)}

    def not_in(self, values: Iterable) -> "FilterOperationDict":
        """Check if value is NOT in a list of values."""
        return {"left": self.name, "operation": "not_in_range", "right": list(values)}

    def has(self, values: str | list[str]) -> "FilterOperationDict":
        """
        Check if field contains any of the values (for set-type fields).

        Examples:
            >>> Column('typespecs').has(['common', 'preferred'])
        """
        return {"left": self.name, "operation": "has", "right": values}

    def has_none_of(self, values: str | list[str]) -> "FilterOperationDict":
        """Check if field contains NONE of the values (for set-type fields)."""
        return {"left": self.name, "operation": "has_none_of", "right": values}

    def in_day_range(self, a: int, b: int) -> "FilterOperationDict":
        """Check if date is within day range (0 = today)."""
        return {"left": self.name, "operation": "in_day_range", "right": [a, b]}

    def in_week_range(self, a: int, b: int) -> "FilterOperationDict":
        """Check if date is within week range."""
        return {"left": self.name, "operation": "in_week_range", "right": [a, b]}

    def in_month_range(self, a: int, b: int) -> "FilterOperationDict":
        """Check if date is within month range."""
        return {"left": self.name, "operation": "in_month_range", "right": [a, b]}

    def above_pct(self, column: "Column | str", pct: float) -> "FilterOperationDict":
        """
        Check if value is above another column by a percentage.

        Args:
            column: Reference column
            pct: Percentage multiplier (1.03 = 3% above)

        Examples:
            >>> Column('close').above_pct('VWAP', 1.03)  # 3% above VWAP
            >>> Column('close').above_pct('price_52_week_low', 2.5)  # 150% above 52w low
        """
        return {
            "left": self.name,
            "operation": "above%",
            "right": [self._extract_name(column), pct],
        }

    def below_pct(self, column: "Column | str", pct: float) -> "FilterOperationDict":
        """
        Check if value is below another column by a percentage.

        Examples:
            >>> Column('close').below_pct('VWAP', 1.03)  # 3% below VWAP
        """
        return {
            "left": self.name,
            "operation": "below%",
            "right": [self._extract_name(column), pct],
        }

    def between_pct(
        self, column: "Column | str", pct1: float, pct2: Optional[float] = None
    ) -> "FilterOperationDict":
        """
        Check if percentage change relative to column is within range.

        Examples:
            >>> Column('close').between_pct('EMA200', 1.2, 1.5)  # 20-50% above EMA200
        """
        return {
            "left": self.name,
            "operation": "in_range%",
            "right": [self._extract_name(column), pct1, pct2],
        }

    def not_between_pct(
        self, column: "Column | str", pct1: float, pct2: Optional[float] = None
    ) -> "FilterOperationDict":
        """Check if percentage change relative to column is NOT within range."""
        return {
            "left": self.name,
            "operation": "not_in_range%",
            "right": [self._extract_name(column), pct1, pct2],
        }

    def like(self, pattern: str) -> "FilterOperationDict":
        """
        Pattern matching (case-insensitive LIKE '%pattern%').

        Examples:
            >>> Column('description').like('apple')
        """
        return {"left": self.name, "operation": "match", "right": pattern}

    def not_like(self, pattern: str) -> "FilterOperationDict":
        """Negative pattern matching."""
        return {"left": self.name, "operation": "nmatch", "right": pattern}

    def empty(self) -> "FilterOperationDict":
        """Check if field is empty/null."""
        return {"left": self.name, "operation": "empty", "right": None}

    def not_empty(self) -> "FilterOperationDict":
        """Check if field is NOT empty/null."""
        return {"left": self.name, "operation": "nempty", "right": None}

    def __repr__(self) -> str:
        return f"Column({self.name!r})"


# Convenience alias
col = Column
