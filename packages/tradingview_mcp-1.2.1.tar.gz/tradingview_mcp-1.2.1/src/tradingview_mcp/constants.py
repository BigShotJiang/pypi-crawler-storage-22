"""
Constants for TradingView Screener integration.

Contains API URLs, headers, supported markets, and column definitions.
"""

from __future__ import annotations

# API Configuration
URL = "https://scanner.tradingview.com/{market}/scan"

HEADERS = {
    "authority": "scanner.tradingview.com",
    "sec-ch-ua": '" Not A;Brand";v="99", "Chromium";v="98", "Google Chrome";v="98"',
    "accept": "text/plain, */*; q=0.01",
    "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
    "sec-ch-ua-mobile": "?0",
    "user-agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36"
    ),
    "sec-ch-ua-platform": '"Windows"',
    "origin": "https://www.tradingview.com",
    "sec-fetch-site": "same-site",
    "sec-fetch-mode": "cors",
    "sec-fetch-dest": "empty",
    "referer": "https://www.tradingview.com/",
    "accept-language": "en-US,en;q=0.9",
}

DEFAULT_RANGE = [0, 50]

# Supported Markets (76 total)
MARKETS = {
    # Financial Instruments
    "bonds",
    "cfd",
    "coin",
    "crypto",
    "economics2",
    "forex",
    "futures",
    "options",
    # Countries (67)
    "america",
    "argentina",
    "australia",
    "austria",
    "bahrain",
    "bangladesh",
    "belgium",
    "brazil",
    "canada",
    "chile",
    "china",
    "colombia",
    "cyprus",
    "czech",
    "denmark",
    "egypt",
    "estonia",
    "finland",
    "france",
    "germany",
    "greece",
    "hongkong",
    "hungary",
    "iceland",
    "india",
    "indonesia",
    "israel",
    "italy",
    "japan",
    "kenya",
    "korea",
    "ksa",
    "kuwait",
    "latvia",
    "lithuania",
    "luxembourg",
    "malaysia",
    "mexico",
    "morocco",
    "netherlands",
    "newzealand",
    "nigeria",
    "norway",
    "pakistan",
    "peru",
    "philippines",
    "poland",
    "portugal",
    "qatar",
    "romania",
    "rsa",
    "russia",
    "serbia",
    "singapore",
    "slovakia",
    "spain",
    "srilanka",
    "sweden",
    "switzerland",
    "taiwan",
    "thailand",
    "tunisia",
    "turkey",
    "uae",
    "uk",
    "venezuela",
    "vietnam",
}

# Exchange to Screener Mapping
EXCHANGE_SCREENER = {
    # Crypto Exchanges
    "all": "crypto",
    "huobi": "crypto",
    "kucoin": "crypto",
    "coinbase": "crypto",
    "gateio": "crypto",
    "binance": "crypto",
    "bitfinex": "crypto",
    "bitget": "crypto",
    "bybit": "crypto",
    "okx": "crypto",
    "kraken": "crypto",
    "bitstamp": "crypto",
    "gemini": "crypto",
    "poloniex": "crypto",
    # Stock Exchanges
    "bist": "turkey",
    "nasdaq": "america",
    "nyse": "america",
    "amex": "america",
    # Malaysia
    "bursa": "malaysia",
    "myx": "malaysia",
    "klse": "malaysia",
    "ace": "malaysia",
    "leap": "malaysia",
    # Hong Kong
    "hkex": "hongkong",
    "hk": "hongkong",
    "hsi": "hongkong",
    # Others
    "lse": "uk",
    "tsx": "canada",
    "asx": "australia",
    "nse": "india",
    "bse": "india",
    "sse": "china",
    "szse": "china",
    "tse": "japan",
    "krx": "korea",
}

# Allowed Timeframes
ALLOWED_TIMEFRAMES = {"1m", "5m", "15m", "30m", "1h", "2h", "4h", "1D", "1W", "1M"}

# Timeframe to TradingView Resolution
TIMEFRAME_MAP = {
    "1m": "1",
    "5m": "5",
    "15m": "15",
    "30m": "30",
    "1h": "60",
    "2h": "120",
    "4h": "240",
    "1D": "1D",
    "1W": "1W",
    "1M": "1M",
}

# Column Definitions - Human readable names to API column names
COLUMNS = {
    # Technical Indicators
    "Average Day Range (14)": "ADR",
    "Average Directional Index (14)": "ADX",
    "Positive Directional Indicator (14)": "ADX+DI",
    "Negative Directional Indicator (14)": "ADX-DI",
    "Awesome Oscillator": "AO",
    "Average True Range (14)": "ATR",
    "Aroon Down (14)": "Aroon.Down",
    "Aroon Up (14)": "Aroon.Up",
    "Bollinger Lower Band (20)": "BB.lower",
    "Bollinger Upper Band (20)": "BB.upper",
    "Bull Bear Power": "BBPower",
    "Commodity Channel Index (20)": "CCI20",
    "Chaikin Money Flow (20)": "ChaikinMoneyFlow",
    "Donchian Channels Lower Band (20)": "DonchCh20.Lower",
    "Donchian Channels Upper Band (20)": "DonchCh20.Upper",
    # EMAs
    "Exponential Moving Average (5)": "EMA5",
    "Exponential Moving Average (10)": "EMA10",
    "Exponential Moving Average (20)": "EMA20",
    "Exponential Moving Average (30)": "EMA30",
    "Exponential Moving Average (50)": "EMA50",
    "Exponential Moving Average (100)": "EMA100",
    "Exponential Moving Average (200)": "EMA200",
    # Highs/Lows
    "1-Month High": "High.1M",
    "3-Month High": "High.3M",
    "6-Month High": "High.6M",
    "All Time High": "High.All",
    "1-Month Low": "Low.1M",
    "3-Month Low": "Low.3M",
    "6-Month Low": "Low.6M",
    "All Time Low": "Low.All",
    # Hull MA
    "Hull Moving Average (9)": "HullMA9",
    # Ichimoku
    "Ichimoku Base Line (9, 26, 52, 26)": "Ichimoku.BLine",
    "Ichimoku Conversion Line (9, 26, 52, 26)": "Ichimoku.CLine",
    "Ichimoku Leading Span A (9, 26, 52, 26)": "Ichimoku.Lead1",
    "Ichimoku Leading Span B (9, 26, 52, 26)": "Ichimoku.Lead2",
    # Keltner Channels
    "Keltner Channels Lower Band (20)": "KltChnl.lower",
    "Keltner Channels Upper Band (20)": "KltChnl.upper",
    # MACD
    "MACD Level (12, 26)": "MACD.macd",
    "MACD Signal (12, 26)": "MACD.signal",
    # Other Indicators
    "Momentum (10)": "Mom",
    "Money Flow (14)": "MoneyFlow",
    "Parabolic SAR": "P.SAR",
    # Performance
    "Monthly Performance": "Perf.1M",
    "3-Month Performance": "Perf.3M",
    "5Y Performance": "Perf.5Y",
    "6-Month Performance": "Perf.6M",
    "All Time Performance": "Perf.All",
    "Weekly Performance": "Perf.W",
    "Yearly Performance": "Perf.Y",
    "YTD Performance": "Perf.YTD",
    # Pivot Points (Classic)
    "Pivot Classic P": "Pivot.M.Classic.Middle",
    "Pivot Classic R1": "Pivot.M.Classic.R1",
    "Pivot Classic R2": "Pivot.M.Classic.R2",
    "Pivot Classic R3": "Pivot.M.Classic.R3",
    "Pivot Classic S1": "Pivot.M.Classic.S1",
    "Pivot Classic S2": "Pivot.M.Classic.S2",
    "Pivot Classic S3": "Pivot.M.Classic.S3",
    # Pivot Points (Fibonacci)
    "Pivot Fibonacci P": "Pivot.M.Fibonacci.Middle",
    "Pivot Fibonacci R1": "Pivot.M.Fibonacci.R1",
    "Pivot Fibonacci R2": "Pivot.M.Fibonacci.R2",
    "Pivot Fibonacci R3": "Pivot.M.Fibonacci.R3",
    "Pivot Fibonacci S1": "Pivot.M.Fibonacci.S1",
    "Pivot Fibonacci S2": "Pivot.M.Fibonacci.S2",
    "Pivot Fibonacci S3": "Pivot.M.Fibonacci.S3",
    # Rate of Change
    "Rate Of Change (9)": "ROC",
    # RSI
    "Relative Strength Index (14)": "RSI",
    "Relative Strength Index (7)": "RSI7",
    # Recommendations
    "Technical Rating": "Recommend.All",
    "Moving Averages Rating": "Recommend.MA",
    "Oscillators Rating": "Recommend.Other",
    # SMAs
    "Simple Moving Average (5)": "SMA5",
    "Simple Moving Average (10)": "SMA10",
    "Simple Moving Average (20)": "SMA20",
    "Simple Moving Average (30)": "SMA30",
    "Simple Moving Average (50)": "SMA50",
    "Simple Moving Average (100)": "SMA100",
    "Simple Moving Average (200)": "SMA200",
    # Stochastic
    "Stochastic %D (14, 3, 3)": "Stoch.D",
    "Stochastic %K (14, 3, 3)": "Stoch.K",
    "Stochastic RSI Slow (3, 3, 14, 14)": "Stoch.RSI.D",
    "Stochastic RSI Fast (3, 3, 14, 14)": "Stoch.RSI.K",
    # Other
    "Ultimate Oscillator (7, 14, 28)": "UO",
    "Volume Weighted Average Price": "VWAP",
    "Volume Weighted Moving Average (20)": "VWMA",
    "Volume*Price": "Value.Traded",
    "Volatility": "Volatility.D",
    "Volatility Month": "Volatility.M",
    "Volatility Week": "Volatility.W",
    "Williams Percent Range (14)": "W.R",
    # Fundamentals
    "Net Margin (TTM)": "after_tax_margin",
    "Average Volume (10 day)": "average_volume_10d_calc",
    "Average Volume (30 day)": "average_volume_30d_calc",
    "Average Volume (60 day)": "average_volume_60d_calc",
    "Average Volume (90 day)": "average_volume_90d_calc",
    "Basic EPS (FY)": "basic_eps_net_income",
    "1-Year Beta": "beta_1_year",
    "Cash & Equivalents (MRQ)": "cash_n_equivalents_fq",
    "Cash & Equivalents (FY)": "cash_n_equivalents_fy",
    # Price/Change
    "Change %": "change",
    "Change": "change_abs",
    "Change from Open %": "change_from_open",
    "Change from Open": "change_from_open_abs",
    "Price": "close",
    "Country": "country",
    "Currency": "currency",
    # Debt
    "Current Ratio (MRQ)": "current_ratio",
    "Debt to Equity Ratio (MRQ)": "debt_to_equity",
    # Dividends
    "Dividend Yield Forward": "dividend_yield_recent",
    "Dividends Paid (FY)": "dividends_paid",
    "Dividends per Share (MRQ)": "dividends_per_share_fq",
    # EPS
    "Basic EPS (TTM)": "earnings_per_share_basic_ttm",
    "EPS Diluted (TTM)": "earnings_per_share_diluted_ttm",
    "EPS Forecast (MRQ)": "earnings_per_share_forecast_next_fq",
    "EPS Diluted (MRQ)": "earnings_per_share_fq",
    # Earnings
    "Recent Earnings Date": "earnings_release_date",
    "Upcoming Earnings Date": "earnings_release_next_date",
    "EBITDA (TTM)": "ebitda",
    # Enterprise Value
    "Enterprise Value/EBITDA (TTM)": "enterprise_value_ebitda_ttm",
    "Enterprise Value (MRQ)": "enterprise_value_fq",
    # Basic Info
    "Exchange": "exchange",
    "Shares Float": "float_shares_outstanding",
    # Gap
    "Gap %": "gap",
    # Margins
    "Gross Margin (TTM)": "gross_margin",
    "Gross Profit (FY)": "gross_profit",
    # OHLCV
    "High": "high",
    "Low": "low",
    "Open": "open",
    "Volume": "volume",
    # Identification
    "Industry": "industry",
    "Sector": "sector",
    "Market": "market",
    "Name": "name",
    "Description": "description",
    "Type": "type",
    # Market Cap
    "Market Capitalization": "market_cap_basic",
    # Net Income
    "Net Debt (MRQ)": "net_debt",
    "Net Income (FY)": "net_income",
    # P/E Ratios
    "Price to Earnings Ratio (TTM)": "price_earnings_ttm",
    "Price to Book (MRQ)": "price_book_fq",
    "Price to Sales (FY)": "price_sales_ratio",
    "Price to Free Cash Flow (TTM)": "price_free_cash_flow_ttm",
    # 52 Week
    "52 Week High": "price_52_week_high",
    "52 Week Low": "price_52_week_low",
    # Pre/Post Market
    "Pre-market Change %": "premarket_change",
    "Pre-market Change": "premarket_change_abs",
    "Pre-market Close": "premarket_close",
    "Pre-market High": "premarket_high",
    "Pre-market Low": "premarket_low",
    "Pre-market Open": "premarket_open",
    "Pre-market Volume": "premarket_volume",
    "Pre-market Gap %": "premarket_gap",
    "Post-market Change %": "postmarket_change",
    "Post-market Change": "postmarket_change_abs",
    "Post-market Close": "postmarket_close",
    "Post-market High": "postmarket_high",
    "Post-market Low": "postmarket_low",
    "Post-market Open": "postmarket_open",
    "Post-market Volume": "postmarket_volume",
    # Relative Volume
    "Relative Volume": "relative_volume_10d_calc",
    "Relative Volume at Time": "relative_volume_intraday|5",
    # Returns
    "Return on Assets (TTM)": "return_on_assets",
    "Return on Equity (TTM)": "return_on_equity",
    "Return on Invested Capital (TTM)": "return_on_invested_capital",
    # Revenue
    "Total Revenue (FY)": "total_revenue",
    "Revenue per Employee (FY)": "revenue_per_employee",
    # Shares
    "Total Shares Outstanding": "total_shares_outstanding_fundamental",
    # Assets
    "Total Assets (MRQ)": "total_assets",
    "Total Current Assets (MRQ)": "total_current_assets",
    "Total Debt (MRQ)": "total_debt",
    "Total Liabilities (MRQ)": "total_liabilities_fq",
    # Crypto specific
    "24h Volume": "24h_vol|5",
    "24h Change %": "24h_close_change|5",
    "24h Volume Change %": "24h_vol_change|5",
    "24h Volume to Market Cap": "24h_vol_to_market_cap",
    # Quick ratio
    "Quick Ratio (MRQ)": "quick_ratio",
}

# Default columns for different query types
# Always include 'description' for full name (e.g., "Apple Inc." instead of just "AAPL")
DEFAULT_COLUMNS = ["name", "description", "close", "change", "volume", "market_cap_basic"]

PREMARKET_COLUMNS = ["name", "description", "close", "volume", "premarket_change", "premarket_change_abs", "premarket_volume"]

POSTMARKET_COLUMNS = ["name", "description", "close", "volume", "postmarket_change", "postmarket_change_abs", "postmarket_volume"]

CRYPTO_COLUMNS = ["name", "description", "close", "change", "volume", "market_cap_basic", "24h_vol|5"]

TECHNICAL_COLUMNS = [
    "name",
    "description",
    "close",
    "volume",
    "change",
    "RSI",
    "MACD.macd",
    "MACD.signal",
    "BB.upper",
    "BB.lower",
    "SMA20",
    "EMA50",
    "EMA200",
    "ADX",
    "Stoch.K",
    "Stoch.D",
]


def get_column_name(name: str) -> str:
    """Get the API column name from a human-readable name or return as-is."""
    return COLUMNS.get(name, name)
