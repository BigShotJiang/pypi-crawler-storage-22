"""TradingView MCP packaged data files.

This package contains:
- markets.json: Market metadata
- column_display_names.json: Field display names  
- metainfo/: Field definitions by market type
- screeners/: Screener presets and configurations
- extracted/: AI-friendly data extracted from docs
"""
