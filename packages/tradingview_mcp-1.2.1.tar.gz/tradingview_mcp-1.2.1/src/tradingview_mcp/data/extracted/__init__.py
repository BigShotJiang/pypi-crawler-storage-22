"""Extracted data from TradingView-Screener docs HTML files."""
