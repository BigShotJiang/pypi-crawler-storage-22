"""
Type definitions and models for TradingView Screener.

Provides TypedDicts for API request/response structures.
"""

from __future__ import annotations

from typing import Any, Literal, TypedDict


class FilterOperationDict(TypedDict):
    """Filter operation for WHERE clauses."""

    left: str
    operation: Literal[
        "greater",
        "egreater",
        "less",
        "eless",
        "equal",
        "nequal",
        "in_range",
        "not_in_range",
        "empty",
        "nempty",
        "crosses",
        "crosses_above",
        "crosses_below",
        "match",
        "nmatch",
        "smatch",
        "has",
        "has_none_of",
        "above%",
        "below%",
        "in_range%",
        "not_in_range%",
        "in_day_range",
        "in_week_range",
        "in_month_range",
    ]
    right: Any


class SortByDict(TypedDict, total=False):
    """Sort configuration."""

    sortBy: str
    sortOrder: Literal["asc", "desc"]
    nullsFirst: bool


class SymbolsDict(TypedDict, total=False):
    """Symbols configuration for queries."""

    query: dict[Literal["types"], list[str]]
    tickers: list[str]
    symbolset: list[str]
    watchlist: dict[Literal["id"], int]
    groups: list[dict[Literal["type", "values"], str]]


class ExpressionDict(TypedDict):
    """Single expression wrapper."""

    expression: FilterOperationDict


class OperationComparisonDict(TypedDict):
    """AND/OR operation for complex filters."""

    operator: Literal["and", "or"]
    operands: list[Any]  # Can be OperationDict or ExpressionDict


class OperationDict(TypedDict):
    """Operation wrapper for complex filters."""

    operation: OperationComparisonDict


class QueryDict(TypedDict, total=False):
    """Complete query structure for TradingView API."""

    markets: list[str]
    symbols: SymbolsDict
    options: dict[str, Any]
    columns: list[str]
    filter: list[FilterOperationDict]
    filter2: OperationComparisonDict
    sort: SortByDict
    range: list[int]
    ignore_unknown_fields: bool
    preset: str
    price_conversion: dict[str, Any]


class ScreenerRowDict(TypedDict):
    """Single row in screener response."""

    s: str  # symbol (NASDAQ:AAPL)
    d: list[Any]  # data values


class ScreenerDict(TypedDict):
    """Screener API response structure."""

    totalCount: int
    data: list[ScreenerRowDict]


class IndicatorMap(TypedDict, total=False):
    """Common technical indicators."""

    open: float | None
    high: float | None
    low: float | None
    close: float | None
    volume: float | None
    change: float | None
    SMA20: float | None
    SMA50: float | None
    SMA200: float | None
    EMA20: float | None
    EMA50: float | None
    EMA200: float | None
    RSI: float | None
    RSI7: float | None
    MACD_macd: float | None
    MACD_signal: float | None
    BB_upper: float | None
    BB_lower: float | None
    ADX: float | None
    ATR: float | None
    Stoch_K: float | None
    Stoch_D: float | None
    VWAP: float | None


class AnalysisResult(TypedDict, total=False):
    """Complete analysis result for a symbol."""

    symbol: str
    exchange: str
    timeframe: str
    timestamp: str
    price: float
    change_percent: float
    indicators: IndicatorMap
    bollinger: dict[str, Any]
    signals: list[str]
    rating: int
    recommendation: str
