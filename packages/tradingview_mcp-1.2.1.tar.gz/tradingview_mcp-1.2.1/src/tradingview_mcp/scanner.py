"""
Pre-built scanner configurations for common use cases.

Provides ready-to-use Query objects for popular screening scenarios.
"""

from __future__ import annotations

from tradingview_mcp.column import Column
from tradingview_mcp.query import Query


# Always include 'description' for full name (e.g., "Apple Inc." instead of just "AAPL")
DEFAULT_COLUMNS = ["name", "description", "close", "change", "volume", "market_cap_basic"]


class Scanner:
    """
    Collection of pre-built stock screeners.

    Examples:
        >>> Scanner.premarket_gainers.get_scanner_data()
        >>> Scanner.top_volume.get_scanner_data()
        >>> Scanner.oversold_rsi.get_scanner_data()
    """

    # Pre-market Scanners
    premarket_gainers = (
        Query()
        .select(*DEFAULT_COLUMNS, "premarket_change", "premarket_change_abs", "premarket_volume")
        .order_by("premarket_change", ascending=False)
    )

    premarket_losers = (
        Query()
        .select(*DEFAULT_COLUMNS, "premarket_change", "premarket_change_abs", "premarket_volume")
        .order_by("premarket_change", ascending=True)
    )

    premarket_most_active = (
        Query()
        .select(*DEFAULT_COLUMNS, "premarket_change", "premarket_change_abs", "premarket_volume")
        .order_by("premarket_volume", ascending=False)
    )

    premarket_gappers = (
        Query()
        .select(*DEFAULT_COLUMNS, "premarket_change", "premarket_change_abs", "premarket_volume", "premarket_gap")
        .order_by("premarket_gap", ascending=False)
    )

    # Post-market Scanners
    postmarket_gainers = (
        Query()
        .select(*DEFAULT_COLUMNS, "postmarket_change", "postmarket_change_abs", "postmarket_volume")
        .order_by("postmarket_change", ascending=False)
    )

    postmarket_losers = (
        Query()
        .select(*DEFAULT_COLUMNS, "postmarket_change", "postmarket_change_abs", "postmarket_volume")
        .order_by("postmarket_change", ascending=True)
    )

    postmarket_most_active = (
        Query()
        .select(*DEFAULT_COLUMNS, "postmarket_change", "postmarket_change_abs", "postmarket_volume")
        .order_by("postmarket_volume", ascending=False)
    )

    # Volume Scanners
    top_volume = (
        Query()
        .select(*DEFAULT_COLUMNS, "change", "relative_volume_10d_calc")
        .order_by("volume", ascending=False)
    )

    unusual_volume = (
        Query()
        .select(*DEFAULT_COLUMNS, "change", "relative_volume_10d_calc")
        .where(Column("relative_volume_10d_calc") > 2.0)
        .order_by("relative_volume_10d_calc", ascending=False)
    )

    # Price Change Scanners
    top_gainers = (
        Query()
        .select(*DEFAULT_COLUMNS, "change", "change_abs")
        .where(Column("change") > 0)
        .order_by("change", ascending=False)
    )

    top_losers = (
        Query()
        .select(*DEFAULT_COLUMNS, "change", "change_abs")
        .where(Column("change") < 0)
        .order_by("change", ascending=True)
    )

    # Technical Scanners
    oversold_rsi = (
        Query()
        .select(*DEFAULT_COLUMNS, "change", "RSI", "RSI7")
        .where(Column("RSI") < 30)
        .order_by("RSI", ascending=True)
    )

    overbought_rsi = (
        Query()
        .select(*DEFAULT_COLUMNS, "change", "RSI", "RSI7")
        .where(Column("RSI") > 70)
        .order_by("RSI", ascending=False)
    )

    macd_bullish_crossover = (
        Query()
        .select(*DEFAULT_COLUMNS, "change", "MACD.macd", "MACD.signal")
        .where(Column("MACD.macd").crosses_above(Column("MACD.signal")))
        .order_by("change", ascending=False)
    )

    macd_bearish_crossover = (
        Query()
        .select(*DEFAULT_COLUMNS, "change", "MACD.macd", "MACD.signal")
        .where(Column("MACD.macd").crosses_below(Column("MACD.signal")))
        .order_by("change", ascending=True)
    )

    # 52-Week Scanners
    near_52_week_high = (
        Query()
        .select(*DEFAULT_COLUMNS, "change", "price_52_week_high", "price_52_week_low")
        .where(Column("close").above_pct("price_52_week_high", 0.95))
        .order_by("change", ascending=False)
    )

    near_52_week_low = (
        Query()
        .select(*DEFAULT_COLUMNS, "change", "price_52_week_high", "price_52_week_low")
        .where(Column("close").below_pct("price_52_week_low", 1.05))
        .order_by("change", ascending=True)
    )

    # Bollinger Band Scanners
    bb_squeeze = (
        Query()
        .select(*DEFAULT_COLUMNS, "change", "BB.upper", "BB.lower", "SMA20", "ATR")
        .order_by("Volatility.D", ascending=True)
    )

    above_upper_bb = (
        Query()
        .select(*DEFAULT_COLUMNS, "change", "BB.upper", "BB.lower", "SMA20")
        .where(Column("close") > Column("BB.upper"))
        .order_by("change", ascending=False)
    )

    below_lower_bb = (
        Query()
        .select(*DEFAULT_COLUMNS, "change", "BB.upper", "BB.lower", "SMA20")
        .where(Column("close") < Column("BB.lower"))
        .order_by("change", ascending=True)
    )

    # Moving Average Scanners
    golden_cross = (
        Query()
        .select(*DEFAULT_COLUMNS, "change", "SMA50", "SMA200")
        .where(Column("SMA50").crosses_above(Column("SMA200")))
        .order_by("volume", ascending=False)
    )

    death_cross = (
        Query()
        .select(*DEFAULT_COLUMNS, "change", "SMA50", "SMA200")
        .where(Column("SMA50").crosses_below(Column("SMA200")))
        .order_by("volume", ascending=False)
    )

    above_all_mas = (
        Query()
        .select(*DEFAULT_COLUMNS, "change", "SMA20", "SMA50", "SMA200")
        .where(
            Column("close") > Column("SMA20"),
            Column("close") > Column("SMA50"),
            Column("close") > Column("SMA200"),
        )
        .order_by("change", ascending=False)
    )

    @classmethod
    def names(cls) -> list[str]:
        """Get list of all available scanner names."""
        return [x for x in cls.__dict__.keys() if not x.startswith("_") and x != "names"]


class CryptoScanner:
    """
    Collection of pre-built cryptocurrency screeners.

    Examples:
        >>> CryptoScanner.top_gainers.get_scanner_data()
        >>> CryptoScanner.high_volume.get_scanner_data()
    """

    CRYPTO_COLUMNS = ["name", "close", "volume", "change", "market_cap_basic"]

    top_gainers = (
        Query()
        .set_markets("crypto")
        .select(*CRYPTO_COLUMNS)
        .where(Column("change") > 0)
        .order_by("change", ascending=False)
    )

    top_losers = (
        Query()
        .set_markets("crypto")
        .select(*CRYPTO_COLUMNS)
        .where(Column("change") < 0)
        .order_by("change", ascending=True)
    )

    high_volume = (
        Query()
        .set_markets("crypto")
        .select(*CRYPTO_COLUMNS, "24h_vol|5")
        .order_by("volume", ascending=False)
    )

    most_volatile = (
        Query()
        .set_markets("crypto")
        .select(*CRYPTO_COLUMNS, "Volatility.D")
        .order_by("Volatility.D", ascending=False)
    )

    oversold = (
        Query()
        .set_markets("crypto")
        .select(*CRYPTO_COLUMNS, "RSI")
        .where(Column("RSI") < 30)
        .order_by("RSI", ascending=True)
    )

    overbought = (
        Query()
        .set_markets("crypto")
        .select(*CRYPTO_COLUMNS, "RSI")
        .where(Column("RSI") > 70)
        .order_by("RSI", ascending=False)
    )

    @classmethod
    def names(cls) -> list[str]:
        """Get list of all available crypto scanner names."""
        return [x for x in cls.__dict__.keys() if not x.startswith("_") and x not in ("names", "CRYPTO_COLUMNS")]
