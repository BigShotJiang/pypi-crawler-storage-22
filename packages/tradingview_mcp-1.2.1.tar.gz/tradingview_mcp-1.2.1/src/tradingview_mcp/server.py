"""
TradingView MCP Server - Main server implementation.

Provides comprehensive MCP tools and resources for TradingView market screening.
"""

from __future__ import annotations

import argparse
import inspect
import json
import os
import traceback
from datetime import datetime
from functools import wraps
from typing import Any, Optional

from mcp.server.fastmcp import FastMCP

from tradingview_mcp.column import Column
from tradingview_mcp.constants import (
    COLUMNS,
    CRYPTO_COLUMNS,
    DEFAULT_COLUMNS,
    EXCHANGE_SCREENER,
    MARKETS,
    POSTMARKET_COLUMNS,
    PREMARKET_COLUMNS,
    TECHNICAL_COLUMNS,
)
from tradingview_mcp.query import And, Or, Query, get_all_symbols
from tradingview_mcp.scanner import CryptoScanner, Scanner
from tradingview_mcp.utils import (
    analyze_indicators,
    compute_bollinger_band_width,
    compute_bollinger_rating,
    compute_percent_change,
    format_symbol,
    format_technical_rating,
    sanitize_exchange,
    sanitize_market,
    sanitize_timeframe,
    timeframe_to_resolution,
)
from tradingview_mcp.docs_data import (
    get_ai_quick_reference,
    get_column_display_names,
    get_common_fields,
    get_fields_by_market,
    get_markets_data,
    get_metainfo as load_metainfo,
    get_screener_code_examples,
    get_screener_markets,
    get_screener_presets,
    paginate_data,
    search_fields,
    get_field_summary,
    estimate_tokens,
    truncate_for_tokens,
    MAX_ITEMS_DEFAULT,
)

# Initialize MCP Server
mcp = FastMCP(
    name="TradingView Screener MCP",
    instructions="""TradingView Market Screener MCP - Stocks/Crypto screening tools

🚀 Quick start:
1. Call `get_help()` for the full usage guide
2. Call `ai_get_reference()` for markets, fields, and filter references

📊 Common tools:
- `screen_market(market, limit)` - Market screening (stocks, crypto, etc.)
- `get_top_gainers(market, limit)` - Top gainers
- `get_top_losers(market, limit)` - Top losers
- `search_symbols(query, market)` - 🔍 Search by name (e.g., "Apple", "Tesla")
- `get_symbol_info(symbol)` - Get detailed symbol info

⚠️ Important notes:
- `limit` controls result count (default 25, max 500)
- Results include the `description` field with full names (e.g., "Apple Inc.")
- `market` examples: america (US stocks), crypto, uk, etc.

📖 Resources (read-only):
- docs://ai-reference - AI quick reference
- markets://list - All markets
- columns://list - Available fields
""",
)

DEBUG_MODE = os.getenv("TRADINGVIEW_MCP_DEBUG", "0").lower() in {"1", "true", "yes"}


def _safe_json(value: Any) -> Any:
    try:
        return json.loads(json.dumps(value, default=str))
    except Exception:
        return str(value)


def _debug_hint(exc: Exception) -> str | None:
    message = str(exc).lower()
    if "market" in message and "invalid" in message:
        return "Check the market name using the markets://list or docs://screeners resources."
    if "column" in message and "unknown" in message:
        return "Check available columns via columns://list or docs://fields."
    if "http" in message or "status" in message:
        return "TradingView API may be rate-limiting or blocked. Retry with fewer requests."
    return None


def _build_error_response(tool_name: str, exc: Exception, context: dict[str, Any]) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "ok": False,
        "tool": tool_name,
        "error": {"type": exc.__class__.__name__, "message": str(exc)},
        "context": _safe_json(context),
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }
    hint = _debug_hint(exc)
    if hint:
        payload["hint"] = hint
    if DEBUG_MODE:
        payload["trace"] = traceback.format_exc()
    return payload


def _error_response(exc: Exception, context: dict[str, Any] | None = None) -> dict[str, Any]:
    frame = inspect.currentframe()
    caller = frame.f_back.f_code.co_name if frame and frame.f_back else "unknown"
    return _build_error_response(caller, exc, context or {})


def debug_tool(fn):
    """Decorator to return structured debug responses on failure."""

    @wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            result = fn(*args, **kwargs)
            if isinstance(result, dict) and "error" in result:
                return _build_error_response(
                    fn.__name__,
                    Exception(str(result.get("error"))),
                    {"args": args, "kwargs": kwargs, "note": "error returned by tool"},
                )
            if (
                isinstance(result, list)
                and len(result) == 1
                and isinstance(result[0], dict)
                and "error" in result[0]
            ):
                return _build_error_response(
                    fn.__name__,
                    Exception(str(result[0].get("error"))),
                    {"args": args, "kwargs": kwargs, "note": "error returned by tool"},
                )
            return result
        except Exception as exc:  # pragma: no cover - defensive guard
            context = {"args": args, "kwargs": kwargs}
            return _build_error_response(fn.__name__, exc, context)

    return wrapper


_original_mcp_tool = mcp.tool


def _debug_mcp_tool(*args, **kwargs):
    """Wrap FastMCP tool registration with debug handling."""

    def decorator(fn):
        return _original_mcp_tool(*args, **kwargs)(debug_tool(fn))

    return decorator


mcp.tool = _debug_mcp_tool


# =============================================================================
# MCP Resources
# =============================================================================


@mcp.resource("markets://list")
def list_markets() -> str:
    """List all available markets for screening."""
    categories = {
        "crypto": ["crypto", "coin"],
        "instruments": ["forex", "futures", "bonds", "cfd", "options", "economics2"],
        "americas": ["america", "argentina", "brazil", "canada", "chile", "colombia", "mexico", "peru", "venezuela"],
        "europe": [
            "austria",
            "belgium",
            "cyprus",
            "czech",
            "denmark",
            "estonia",
            "finland",
            "france",
            "germany",
            "greece",
            "hungary",
            "iceland",
            "italy",
            "latvia",
            "lithuania",
            "luxembourg",
            "netherlands",
            "norway",
            "poland",
            "portugal",
            "romania",
            "russia",
            "serbia",
            "slovakia",
            "spain",
            "sweden",
            "switzerland",
            "turkey",
            "uk",
        ],
        "asia_pacific": [
            "australia",
            "bangladesh",
            "china",
            "hongkong",
            "india",
            "indonesia",
            "japan",
            "korea",
            "malaysia",
            "newzealand",
            "pakistan",
            "philippines",
            "singapore",
            "srilanka",
            "taiwan",
            "thailand",
            "vietnam",
        ],
        "middle_east_africa": [
            "bahrain",
            "egypt",
            "israel",
            "kenya",
            "ksa",
            "kuwait",
            "morocco",
            "nigeria",
            "qatar",
            "rsa",
            "tunisia",
            "uae",
        ],
    }

    result = "# Available Markets\n\n"
    for category, markets in categories.items():
        result += f"## {category.replace('_', ' ').title()}\n"
        result += ", ".join(sorted(markets)) + "\n\n"
    return result


@mcp.resource("columns://list")
def list_columns() -> str:
    """List all available columns/indicators for screening."""
    result = "# Available Columns\n\n"

    # Group columns by category
    categories = {
        "Price & Change": [
            "close",
            "open",
            "high",
            "low",
            "volume",
            "change",
            "change_abs",
            "gap",
        ],
        "Moving Averages": [
            "SMA5",
            "SMA10",
            "SMA20",
            "SMA50",
            "SMA100",
            "SMA200",
            "EMA5",
            "EMA10",
            "EMA20",
            "EMA50",
            "EMA100",
            "EMA200",
        ],
        "Oscillators": [
            "RSI",
            "RSI7",
            "MACD.macd",
            "MACD.signal",
            "Stoch.K",
            "Stoch.D",
            "CCI20",
            "Mom",
            "AO",
            "UO",
        ],
        "Volatility": ["BB.upper", "BB.lower", "ATR", "Volatility.D", "Volatility.W", "Volatility.M"],
        "Trend": ["ADX", "ADX+DI", "ADX-DI", "Aroon.Up", "Aroon.Down", "P.SAR"],
        "Volume": [
            "volume",
            "VWAP",
            "VWMA",
            "relative_volume_10d_calc",
            "average_volume_10d_calc",
            "average_volume_30d_calc",
        ],
        "Pre/Post Market": [
            "premarket_change",
            "premarket_volume",
            "premarket_gap",
            "postmarket_change",
            "postmarket_volume",
        ],
        "Performance": ["Perf.W", "Perf.1M", "Perf.3M", "Perf.6M", "Perf.Y", "Perf.YTD", "Perf.All"],
        "Fundamentals": [
            "market_cap_basic",
            "price_earnings_ttm",
            "earnings_per_share_basic_ttm",
            "dividend_yield_recent",
            "price_book_fq",
        ],
        "Ratings": ["Recommend.All", "Recommend.MA", "Recommend.Other"],
    }

    for category, cols in categories.items():
        result += f"## {category}\n"
        result += ", ".join(cols) + "\n\n"

    result += "\n## Full Column Mapping\n"
    result += "Use human-readable names or API names:\n\n"
    for human_name, api_name in sorted(COLUMNS.items())[:50]:  # First 50
        result += f"- `{human_name}` → `{api_name}`\n"
    result += f"\n... and {len(COLUMNS) - 50} more columns available."

    return result


@mcp.resource("exchanges://crypto")
def list_crypto_exchanges() -> str:
    """List supported cryptocurrency exchanges."""
    crypto_exchanges = [ex for ex, screener in EXCHANGE_SCREENER.items() if screener == "crypto"]
    return f"# Supported Crypto Exchanges\n\n" + ", ".join(sorted(crypto_exchanges))


@mcp.resource("scanners://presets")
def list_scanner_presets() -> str:
    """List available pre-built scanner presets."""
    result = "# Scanner Presets\n\n"

    result += "## Stock Scanners\n"
    for name in Scanner.names():
        result += f"- `{name}`\n"

    result += "\n## Crypto Scanners\n"
    for name in CryptoScanner.names():
        result += f"- `{name}`\n"

    return result


@mcp.resource("docs://params")
def docs_params() -> str:
    """TradingView screener parameter format and schema."""
    schema = {
        "markets": ["america"],
        "columns": ["close", "volume", "market_cap_basic"],
        "filter": [
            {"left": "change", "operation": "gt", "right": 2},
            {"left": "volume", "operation": "greater", "right": 1000000},
        ],
        "filter2": {
            "operator": "and",
            "operands": [
                {
                    "expression": {"left": "type", "operation": "equal", "right": "stock"}
                },
                {
                    "expression": {"left": "is_primary", "operation": "equal", "right": True}
                },
            ],
        },
        "symbols": {"query": {"types": []}, "tickers": []},
        "sort": {"sortBy": "market_cap_basic", "sortOrder": "desc"},
        "range": [0, 50],
        "options": {"lang": "en"},
        "ignore_unknown_fields": False,
        "price_conversion": {"to_symbol": False},
    }

    format_notes = (
        "# Screener Params Format\n\n"
        "## Core fields\n"
        "- markets: list of market identifiers (e.g., america, crypto, forex)\n"
        "- columns: list of fields to return\n"
        "- filter: flat list of expressions\n"
        "- filter2: nested boolean logic tree (and/or)\n"
        "- symbols: optional tickers/types filter\n"
        "- sort: {sortBy, sortOrder}\n"
        "- range: [offset, limit]\n"
        "- options: {lang}\n"
        "- ignore_unknown_fields: boolean\n"
        "- price_conversion: {to_symbol}\n\n"
        "## Expression format\n"
        "{left: <field>, operation: <op>, right: <value>}\n\n"
        "Common operations: equal, ne, gt, gte, lt, lte, in_range, has, has_none_of\n\n"
        "## Example schema\n"
    )
    return format_notes + json.dumps(schema, ensure_ascii=False, indent=2)


@mcp.resource("docs://screeners")
def docs_screeners() -> str:
    """Predefined screener presets from docs data (compact overview)."""
    presets = get_screener_presets()
    overview = [
        {"name": p.get("name"), "url": p.get("url"), "has_query": bool(p.get("query"))}
        for p in presets
    ]
    return json.dumps(overview, ensure_ascii=False, indent=2)


@mcp.resource("docs://fields")
def docs_fields() -> str:
    """Field display names (first 100). Use search_available_fields tool for more."""
    mapping = get_column_display_names()
    # Limit output to save tokens
    limited = dict(list(mapping.items())[:100])
    result = {
        "fields": limited,
        "total": len(mapping),
        "note": "Showing first 100 fields. Use search_available_fields() tool to search for specific fields.",
    }
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.resource("docs://markets")
def docs_markets() -> str:
    """Markets metadata (compact). Use ai_get_reference tool for categorized list."""
    markets = get_markets_data()
    screener_markets = get_screener_markets()
    return json.dumps(
        {
            "markets_count": len(markets) if isinstance(markets, (list, dict)) else 0,
            "screener_markets": screener_markets,
            "hint": "Use ai_get_reference() tool for full categorized market list.",
        },
        ensure_ascii=False,
        indent=2,
    )


@mcp.tool()
def get_field_info(field: str) -> dict[str, Any]:
    """Get display name, type, and related info for a field.
    
    Args:
        field: Field/column name to look up
        
    Returns:
        Field info including display name, type, and variants if available
    """
    # Try get_field_summary first (uses common_fields)
    summary = get_field_summary(field)
    if summary and summary.get("display_name"):
        return summary
    
    # Fallback to display names mapping
    mapping = get_column_display_names()
    display = mapping.get(field)
    if display:
        return {"field": field, "display_name": display}

    # Try case-insensitive or partial matches
    normalized = field.lower()
    suggestions = [
        name for name in list(mapping.keys())[:500]
        if normalized in name.lower() or normalized in str(mapping[name]).lower()
    ][:10]
    return {
        "field": field,
        "display_name": None,
        "suggestions": suggestions,
    }


@mcp.tool()
def get_screener_preset(name: str) -> dict[str, Any]:
    """Return a full screener preset (query + code) by name."""
    presets = get_screener_presets()
    for preset in presets:
        if preset.get("name", "").lower() == name.lower():
            return preset
    return {
        "error": f"Preset '{name}' not found.",
        "available": [p.get("name") for p in presets],
    }


@mcp.tool()
def get_market_metainfo(
    market: str,
    limit: int = 50,
    offset: int = 0,
    confirm_large: bool = False,
) -> dict[str, Any]:
    """Return metainfo (field definitions and allowed values) for a market.
    
    Args:
        market: Market type (stocks, crypto, forex, bond, etc.)
        limit: Maximum fields to return (default 50, max 500)
        offset: Starting offset for pagination
        confirm_large: Set True to allow returning more than 100 items
        
    Returns:
        Paginated metainfo with field definitions
    """
    limit = min(limit, 500)  # Hard cap
    
    try:
        metainfo = load_metainfo(market)
        
        # Paginate if it's a list or large dict
        if isinstance(metainfo, list):
            return paginate_data(metainfo, offset, limit, confirm_large)
        elif isinstance(metainfo, dict):
            # Return summary if too large
            total_fields = len(metainfo.get("fields", []))
            if total_fields > MAX_ITEMS_DEFAULT and not confirm_large:
                return {
                    "market": market,
                    "total_fields": total_fields,
                    "warning": f"⚠️ Large data ({total_fields} fields). Use limit/offset to paginate or set confirm_large=True.",
                    "sample_fields": list(metainfo.get("fields", {}).keys())[:20] if isinstance(metainfo.get("fields"), dict) else None,
                }
            return {"market": market, "metainfo": metainfo}
        return {"market": market, "metainfo": metainfo}
    except FileNotFoundError:
        return {
            "error": f"Metainfo for '{market}' not found.",
            "available_markets": ["stocks", "crypto", "forex", "bond", "bonds", "cfd", "futures", "options", "coin", "economics2"],
            "hint": "Use one of the available markets listed above.",
        }


# =============================================================================
# AI-Friendly Tools - Quick Reference and Search
# =============================================================================


@mcp.resource("docs://ai-reference")
def docs_ai_reference() -> str:
    """AI quick reference guide with common patterns, markets, and filters."""
    ref = get_ai_quick_reference()
    return json.dumps(ref, ensure_ascii=False, indent=2)


@mcp.resource("docs://code-examples")  
def docs_code_examples() -> str:
    """Python code examples for common screener queries."""
    examples = get_screener_code_examples()
    return json.dumps(examples, ensure_ascii=False, indent=2)


@mcp.tool()
def ai_get_reference() -> dict[str, Any]:
    """Get AI-friendly quick reference for this MCP.
    
    Returns a compact guide with:
    - Available markets by category
    - Common columns by type  
    - Filter operations
    - Common filter patterns
    - Timeframes
    
    This is the recommended starting point for AI agents to understand how to use this MCP.
    """
    return get_ai_quick_reference()


@mcp.tool()
def search_available_fields(
    query: str,
    market: str = "stocks",
    limit: int = 20,
) -> dict[str, Any]:
    """Search for fields/columns by name or description.
    
    Args:
        query: Search term (e.g., "volume", "RSI", "market cap")
        market: Market type to search in (stocks, crypto, forex, etc.)
        limit: Maximum results (default 20, max 50)
        
    Returns:
        Matching fields with their display names and types
    """
    limit = min(limit, 50)
    results = search_fields(query, market, limit)
    
    return {
        "query": query,
        "market": market,
        "count": len(results),
        "fields": results,
        "hint": "Use the 'name' field as the column name in queries." if results else "No matches found. Try a different search term.",
    }


@mcp.tool()
def get_code_example(screener_name: str) -> dict[str, Any]:
    """Get Python code example for a specific screener type.
    
    Args:
        screener_name: Screener name (e.g., "Stocks (legacy)", "Crypto", "Forex", "ETFs", "Bonds")
        
    Returns:
        Python code example for building that screener query
    """
    examples = get_screener_code_examples()
    
    # Try exact match first
    if screener_name in examples:
        return {
            "name": screener_name,
            "code": examples[screener_name],
        }
    
    # Try case-insensitive match
    for name, code in examples.items():
        if name.lower() == screener_name.lower():
            return {"name": name, "code": code}
    
    # Return available options
    return {
        "error": f"Example '{screener_name}' not found.",
        "available": list(examples.keys()),
        "hint": "Use one of the available screener names listed above.",
    }


@mcp.tool()
def list_fields_for_market(
    market: str = "stocks",
    category: str | None = None,
    limit: int = 50,
    offset: int = 0,
    confirm_large: bool = False,
) -> dict[str, Any]:
    """List available fields for a specific market with pagination.
    
    Args:
        market: Market type (stocks, crypto, forex, coin, bond, cfd, futures, options)
        category: Optional filter by field type (price, volume, fundamental, technical)
        limit: Maximum results (default 50, max 200)
        offset: Starting offset for pagination
        confirm_large: Set True to allow more than 100 results
        
    Returns:
        Paginated list of field definitions
    """
    limit = min(limit, 200)
    
    fields = get_fields_by_market(market)
    
    if not fields:
        return {
            "error": f"No fields found for market '{market}'.",
            "available_markets": ["stocks", "crypto", "forex", "coin", "bond", "bonds", "cfd", "futures", "options", "economics2", "ireland"],
        }
    
    # Filter by category if specified
    if category and isinstance(fields, list):
        category_lower = category.lower()
        fields = [f for f in fields if category_lower in f.get("type", "").lower()]
    
    return paginate_data(fields, offset, limit, confirm_large)


@mcp.tool()
def get_common_fields_summary(
    category: str | None = None,
    limit: int = 30,
) -> dict[str, Any]:
    """Get summary of commonly used fields across all markets.
    
    Args:
        category: Optional filter (price, volume, fundamental, technical, rating)
        limit: Maximum fields to return (default 30)
        
    Returns:
        Dict with field names, display names, and types
    """
    ref = get_ai_quick_reference()
    common_cols = ref.get("common_columns", {})
    
    if category:
        category_lower = category.lower()
        if category_lower in common_cols:
            return {
                "category": category,
                "fields": common_cols[category_lower],
            }
        return {
            "error": f"Category '{category}' not found.",
            "available_categories": list(common_cols.keys()),
        }
    
    # Return all categories with limited fields
    result = {}
    for cat, fields in common_cols.items():
        result[cat] = fields[:limit] if len(fields) > limit else fields
    
    return {
        "categories": result,
        "total_categories": len(common_cols),
        "hint": "Use category parameter to filter by type.",
    }


# =============================================================================
# Help and Discovery Tools - Help AI understand usage
# =============================================================================


@mcp.tool()
def get_help(topic: str | None = None) -> dict[str, Any]:
    """📖 Usage guide - required reading for AI!
    
    Args:
        topic: Optional topic: 'markets', 'columns', 'filters', 'examples', 'tools'
               If omitted, returns the full guide
    
    Returns:
        Usage guide and examples
    """
    guide = {
        "overview": {
            "description": "TradingView MCP is a market screener for stocks and crypto",
            "key_points": [
                "All results include the 'description' field (full name like 'Apple Inc.')",
                "Use the limit parameter to control output size (default 25, max 500)",
                "Symbols are returned in ticker format: 'EXCHANGE:SYMBOL' (e.g., 'NASDAQ:AAPL')",
            ],
        },
        "quick_start": {
            "step_1": "Call get_top_gainers('america', 10) for top 10 US stock gainers",
            "step_2": "Call search_symbols('apple', 'america') to find symbols by name",
            "step_3": "Call get_symbol_info('NASDAQ:AAPL') for Apple details",
        },
        "markets": {
            "stocks": ["america (US)", "uk (UK)", "germany (DE)", "japan (JP)", "china (CN)", "hongkong (HK)", "taiwan (TW)"],
            "crypto": ["crypto (pairs)", "coin (coins)",],
            "others": ["forex", "futures", "bonds"],
        },
        "common_tools": {
            "screen_market": "Custom screening - screen_market(market='america', limit=50, sort_by='volume')",
            "get_top_gainers": "Top gainers - get_top_gainers(market='crypto', limit=25)",
            "get_top_losers": "Top losers - get_top_losers(market='america', limit=25)",
            "search_symbols": "🔍 Name search - search_symbols(query='tesla', market='america')",
            "get_symbol_info": "Symbol info - get_symbol_info(symbol='NASDAQ:AAPL')",
            "get_technical_analysis": "Technical analysis - get_technical_analysis(symbol='NASDAQ:AAPL')",
        },
        "important_columns": {
            "name": "Ticker (e.g., 'NASDAQ:AAPL')",
            "description": "Full name (e.g., 'Apple Inc.')",
            "close": "Close/last price",
            "change": "Change (%)",
            "volume": "Volume",
            "market_cap_basic": "Market cap",
        },
        "filters_example": {
            "description": "Use filters to apply conditions",
            "example": [
                {"column": "change", "operation": "gt", "value": 5},
                {"column": "volume", "operation": "gt", "value": 1000000},
            ],
            "operations": ["gt (>)", "gte (>=)", "lt (<)", "lte (<=)", "eq (=)", "neq (!=)", "between", "isin"],
        },
    }
    
    if topic:
        topic_lower = topic.lower()
        if topic_lower in guide:
            return {"topic": topic, "content": guide[topic_lower]}
        if topic_lower == "tools":
            return {"topic": "tools", "content": guide["common_tools"]}
        if topic_lower == "examples":
            return {"topic": "examples", "content": guide["quick_start"]}
        return {
            "error": f"Topic '{topic}' not found",
            "available_topics": list(guide.keys()) + ["tools", "examples"],
        }
    
    return guide


@mcp.tool()
def search_symbols(
    query: str,
    market: str = "america",
    limit: int = 25,
) -> dict[str, Any]:
    """🔍 Search symbols by name (fuzzy search)
    
    Supports company names or tickers, e.g., "Apple", "Tesla", "Microsoft".
    
    Args:
        query: Search keyword (company name or ticker)
        market: Market (america, crypto, uk, etc.)
        limit: Max results (default 25, max 100)
    
    Returns:
        Matching symbols with full names
        
    Examples:
        search_symbols("apple", "america") -> Apple Inc., Applebee's, etc.
        search_symbols("BTC", "crypto") -> BTC pairs
    """
    market = sanitize_market(market)
    limit = max(1, min(limit, 100))
    
    # Search fields: name (ticker) and description (full name)
    cols = ["name", "description", "close", "change", "volume", "market_cap_basic", "type", "exchange"]
    
    try:
        # Use TradingView text search
        # Search description (company name)
        query_obj = (
            Query()
            .set_markets(market)
            .select(*cols)
            .where(Column("description").like(query))
            .order_by("market_cap_basic", ascending=False)
            .limit(limit)
        )
        
        total, df = query_obj.get_scanner_data()
        results = df.to_dict("records")
        
        # If nothing found, try searching the name (ticker) field
        if not results:
            query_obj2 = (
                Query()
                .set_markets(market)
                .select(*cols)
                .where(Column("name").like(query))
                .order_by("market_cap_basic", ascending=False)
                .limit(limit)
            )
            total, df = query_obj2.get_scanner_data()
            results = df.to_dict("records")
        
        return {
            "query": query,
            "market": market,
            "total_found": total,
            "returned": len(results),
            "results": results,
            "hint": "Use 'name' field as symbol for other tools (e.g., get_symbol_info)" if results else "No matches found. Try different keywords.",
        }
    except Exception as e:
        # If LIKE isn't supported, use fallback
        return _search_symbols_fallback(query, market, limit, cols, str(e))


def _search_symbols_fallback(
    query: str, market: str, limit: int, cols: list[str], original_error: str
) -> dict[str, Any]:
    """Fallback search when LIKE is not supported."""
    try:
        # Fetch more data and filter locally
        query_obj = (
            Query()
            .set_markets(market)
            .select(*cols)
            .order_by("market_cap_basic", ascending=False)
            .limit(500)  # Fetch top 500
        )
        
        total, df = query_obj.get_scanner_data()
        
        # Local filter
        query_lower = query.lower()
        filtered = df[
            df["name"].str.lower().str.contains(query_lower, na=False) |
            df["description"].str.lower().str.contains(query_lower, na=False)
        ].head(limit)
        
        results = filtered.to_dict("records")
        
        return {
            "query": query,
            "market": market,
            "total_found": len(results),
            "returned": len(results),
            "results": results,
            "note": "Results from local filtering of top 500 by market cap",
            "hint": "Use 'name' field as symbol for other tools" if results else "No matches found",
        }
    except Exception as e:
        return {
            "error": f"Search failed: {str(e)}",
            "original_error": original_error,
            "hint": "Try using screen_market with specific filters instead",
        }


@mcp.tool()
def get_symbol_info(
    symbol: str,
    include_technical: bool = False,
) -> dict[str, Any]:
    """Get detailed information for a symbol.
    
    Args:
        symbol: Ticker in 'EXCHANGE:SYMBOL' format (e.g., 'NASDAQ:AAPL')
                or just a ticker (e.g., 'AAPL', auto-search)
        include_technical: Whether to include technical indicators
    
    Returns:
        Detailed symbol info including name, price, market cap, etc.
        
    Examples:
        get_symbol_info("NASDAQ:AAPL") -> Apple Inc. details
        get_symbol_info("AAPL") -> auto-search
    """
    cols = [
        "name", "description", "close", "open", "high", "low", 
        "change", "change_abs", "volume", "market_cap_basic",
        "price_earnings_ttm", "earnings_per_share_basic_ttm",
        "dividend_yield_recent", "sector", "industry", "exchange", "type",
    ]
    
    if include_technical:
        cols.extend([
            "RSI", "RSI7", "MACD.macd", "MACD.signal",
            "SMA20", "SMA50", "SMA200", "EMA20", "EMA50", "EMA200",
            "BB.upper", "BB.lower", "ATR", "ADX",
            "Recommend.All", "Recommend.MA", "Recommend.Other",
        ])
    
    try:
        # Determine market
        if ":" in symbol:
            exchange, ticker = symbol.split(":", 1)
            market = EXCHANGE_SCREENER.get(exchange.lower(), "america")
        else:
            ticker = symbol
            market = "america"
        
        query = (
            Query()
            .set_markets(market)
            .select(*cols)
            .where(Column("name").isin([symbol, ticker, symbol.upper(), ticker.upper()]))
            .limit(5)
        )
        
        total, df = query.get_scanner_data()
        
        if df.empty:
            # Fallback to search
            return search_symbols(ticker, market, 5)
        
        results = df.to_dict("records")
        
        if len(results) == 1:
            return {"symbol": symbol, "found": True, "data": results[0]}
        else:
            return {"symbol": symbol, "found": True, "matches": results}
            
    except Exception as e:
        return {
            "error": f"Failed to get symbol info: {str(e)}",
            "hint": "Try using search_symbols to find the correct symbol format",
        }


# =============================================================================
# MCP Tools - Basic Screening
# =============================================================================


@mcp.tool()
def screen_market(
    market: str = "america",
    columns: Optional[list[str]] = None,
    sort_by: str = "volume",
    ascending: bool = False,
    limit: int = 25,
    filters: Optional[list[dict[str, Any]]] = None,
) -> dict[str, Any]:
    """Run a custom market screening query.
    
    ⚠️ Note: Default returns 25 rows. Increase `limit` for more.

    Args:
        market: Market (america=US stocks, crypto, uk, etc.)
        columns: Columns to return (default includes name, description, close, change, volume, market_cap)
        sort_by: Sort column
        ascending: Sort order (True=asc, False=desc)
        limit: Max results (1-500, default 25)
        filters: Filter list, e.g. [{"column": "change", "operation": "gt", "value": 5}]
                 Supported ops: gt, gte, lt, lte, eq, neq, between, isin

    Returns:
        Dict with total_count, returned, data.
        Each row includes description (full name like "Apple Inc.").
    """
    market = sanitize_market(market)
    limit = max(1, min(limit, 500))
    
    # Ensure description is always included
    cols = columns or DEFAULT_COLUMNS
    if "description" not in cols:
        cols = ["description"] + list(cols)

    query = Query().set_markets(market).select(*cols).order_by(sort_by, ascending=ascending).limit(limit)

    # Apply filters if provided
    if filters:
        filter_expressions = []
        for f in filters:
            col = Column(f.get("column", "close"))
            op = f.get("operation", "gt")
            val = f.get("value")

            if op == "gt":
                filter_expressions.append(col > val)
            elif op == "gte":
                filter_expressions.append(col >= val)
            elif op == "lt":
                filter_expressions.append(col < val)
            elif op == "lte":
                filter_expressions.append(col <= val)
            elif op == "eq":
                filter_expressions.append(col == val)
            elif op == "neq":
                filter_expressions.append(col != val)
            elif op == "between" and isinstance(val, (list, tuple)) and len(val) == 2:
                filter_expressions.append(col.between(val[0], val[1]))
            elif op == "isin" and isinstance(val, (list, tuple)):
                filter_expressions.append(col.isin(val))

        if filter_expressions:
            query = query.where(*filter_expressions)

    try:
        total_count, df = query.get_scanner_data()
        results = df.to_dict("records")

        return {
            "total_count": total_count,
            "returned": len(results),
            "market": market,
            "data": results,
        }
    except Exception as e:
        return {"error": str(e), "market": market}


@mcp.tool()
def get_top_gainers(market: str = "america", limit: int = 25) -> dict[str, Any]:
    """Get top gainers for a market.
    
    ⚠️ Note: Default returns 25 rows. Increase `limit` for more.

    Args:
        market: Market (america=US stocks, crypto, uk, etc.)
        limit: Result count (1-100, default 25)

    Returns:
        Top gainers with description (full name).
        
    Example:
        get_top_gainers("america", 10) -> Top 10 US gainers
        get_top_gainers("crypto", 25) -> Top 25 crypto gainers
    """
    market = sanitize_market(market)
    limit = max(1, min(limit, 100))

    # Ensure description is included
    cols = ["name", "description", "close", "change", "change_abs", "volume", "market_cap_basic"]

    query = (
        Query()
        .set_markets(market)
        .select(*cols)
        .where(Column("change") > 0)
        .order_by("change", ascending=False)
        .limit(limit)
    )

    try:
        total, df = query.get_scanner_data()
        results = df.to_dict("records")
        return {
            "market": market,
            "type": "top_gainers",
            "total_found": total,
            "returned": len(results),
            "data": results,
        }
    except Exception as e:
        return {"error": str(e), "market": market}


@mcp.tool()
def get_top_losers(market: str = "america", limit: int = 25) -> dict[str, Any]:
    """Get top losers for a market.
    
    ⚠️ Note: Default returns 25 rows. Increase `limit` for more.

    Args:
        market: Market (america=US stocks, crypto, uk, etc.)
        limit: Result count (1-100, default 25)

    Returns:
        Top losers with description (full name).
        
    Example:
        get_top_losers("america", 10) -> Top 10 US losers
    """
    market = sanitize_market(market)
    limit = max(1, min(limit, 100))

    # Ensure description is included
    cols = ["name", "description", "close", "change", "change_abs", "volume", "market_cap_basic"]

    query = (
        Query()
        .set_markets(market)
        .select(*cols)
        .where(Column("change") < 0)
        .order_by("change", ascending=True)
        .limit(limit)
    )

    try:
        total, df = query.get_scanner_data()
        results = df.to_dict("records")
        return {
            "market": market,
            "type": "top_losers",
            "total_found": total,
            "returned": len(results),
            "data": results,
        }
    except Exception as e:
        return {"error": str(e), "market": market}


@mcp.tool()
def get_most_active(market: str = "america", limit: int = 25) -> dict[str, Any]:
    """Get most active by volume.
    
    ⚠️ Note: Default returns 25 rows.

    Args:
        market: Market
        limit: Result count (1-100)

    Returns:
        Most active list with description (full name)
    """
    market = sanitize_market(market)
    limit = max(1, min(limit, 100))

    cols = ["name", "description", "close", "change", "volume", "relative_volume_10d_calc", "market_cap_basic"]

    query = Query().set_markets(market).select(*cols).order_by("volume", ascending=False).limit(limit)

    try:
        total, df = query.get_scanner_data()
        results = df.to_dict("records")
        return {
            "market": market,
            "type": "most_active",
            "total_found": total,
            "returned": len(results),
            "data": results,
        }
    except Exception as e:
        return {"error": str(e), "market": market}


@mcp.tool()
def get_premarket_movers(
    scan_type: str = "gainers", limit: int = 25
) -> dict[str, Any]:
    """Get pre-market movers (US only).

    Args:
        scan_type: 'gainers', 'losers', 'most_active', 'gappers'
        limit: Result count (1-100)

    Returns:
        List of pre-market movers
    """
    limit = max(1, min(limit, 100))

    scanner_map = {
        "gainers": Scanner.premarket_gainers,
        "losers": Scanner.premarket_losers,
        "most_active": Scanner.premarket_most_active,
        "gappers": Scanner.premarket_gappers,
    }

    scanner = scanner_map.get(scan_type, Scanner.premarket_gainers).copy()
    scanner = scanner.limit(limit)

    try:
        total, df = scanner.get_scanner_data()
        return df.to_dict("records")
    except Exception as e:
        return [{"error": str(e)}]


@mcp.tool()
def get_postmarket_movers(
    scan_type: str = "gainers", limit: int = 25
) -> list[dict[str, Any]]:
    """
    Get post-market movers (US market only).

    Args:
        scan_type: Type of scan - 'gainers', 'losers', 'most_active'
        limit: Number of results (1-100)

    Returns:
        List of post-market movers
    """
    limit = max(1, min(limit, 100))

    scanner_map = {
        "gainers": Scanner.postmarket_gainers,
        "losers": Scanner.postmarket_losers,
        "most_active": Scanner.postmarket_most_active,
    }

    scanner = scanner_map.get(scan_type, Scanner.postmarket_gainers).copy()
    scanner = scanner.limit(limit)

    try:
        total, df = scanner.get_scanner_data()
        return df.to_dict("records")
    except Exception as e:
        return [{"error": str(e)}]


# =============================================================================
# MCP Tools - Technical Analysis Scanners
# =============================================================================


@mcp.tool()
def scan_rsi_extremes(
    market: str = "america",
    condition: str = "oversold",
    threshold: float = 30,
    limit: int = 25,
) -> list[dict[str, Any]]:
    """
    Scan for RSI overbought/oversold conditions.

    Args:
        market: Market to scan
        condition: 'oversold' or 'overbought'
        threshold: RSI threshold (default 30 for oversold, 70 for overbought)
        limit: Number of results (1-100)

    Returns:
        List of symbols matching RSI criteria
    """
    market = sanitize_market(market)
    limit = max(1, min(limit, 100))

    cols = ["name", "close", "volume", "change", "RSI", "RSI7", "market_cap_basic"]

    query = Query().set_markets(market).select(*cols).limit(limit)

    if condition == "oversold":
        threshold = min(threshold, 50)
        query = query.where(Column("RSI") < threshold).order_by("RSI", ascending=True)
    else:  # overbought
        threshold = max(threshold, 50)
        query = query.where(Column("RSI") > threshold).order_by("RSI", ascending=False)

    try:
        total, df = query.get_scanner_data()
        results = df.to_dict("records")

        # Add signal interpretation
        for r in results:
            rsi = r.get("RSI", 50)
            if rsi < 20:
                r["signal"] = "EXTREMELY_OVERSOLD"
            elif rsi < 30:
                r["signal"] = "OVERSOLD"
            elif rsi > 80:
                r["signal"] = "EXTREMELY_OVERBOUGHT"
            elif rsi > 70:
                r["signal"] = "OVERBOUGHT"
            else:
                r["signal"] = "NEUTRAL"

        return results
    except Exception as e:
        return [{"error": str(e)}]


@mcp.tool()
def scan_macd_crossover(
    market: str = "america",
    crossover_type: str = "bullish",
    limit: int = 25,
) -> list[dict[str, Any]]:
    """
    Scan for MACD crossover signals.

    Args:
        market: Market to scan
        crossover_type: 'bullish' (MACD crosses above signal) or 'bearish'
        limit: Number of results (1-100)

    Returns:
        List of symbols with MACD crossover
    """
    market = sanitize_market(market)
    limit = max(1, min(limit, 100))

    cols = ["name", "close", "volume", "change", "MACD.macd", "MACD.signal", "market_cap_basic"]

    query = Query().set_markets(market).select(*cols).limit(limit)

    if crossover_type == "bullish":
        query = query.where(Column("MACD.macd").crosses_above(Column("MACD.signal"))).order_by(
            "change", ascending=False
        )
    else:
        query = query.where(Column("MACD.macd").crosses_below(Column("MACD.signal"))).order_by(
            "change", ascending=True
        )

    try:
        total, df = query.get_scanner_data()
        results = df.to_dict("records")

        for r in results:
            macd = r.get("MACD.macd", 0)
            signal = r.get("MACD.signal", 0)
            r["macd_histogram"] = round(macd - signal, 4) if macd and signal else None
            r["crossover"] = crossover_type

        return results
    except Exception as e:
        return [{"error": str(e)}]


@mcp.tool()
def scan_bollinger_bands(
    market: str = "america",
    condition: str = "squeeze",
    limit: int = 25,
) -> list[dict[str, Any]]:
    """
    Scan for Bollinger Band conditions.

    Args:
        market: Market to scan
        condition: 'squeeze' (low volatility), 'above_upper', 'below_lower'
        limit: Number of results (1-100)

    Returns:
        List of symbols matching BB criteria
    """
    market = sanitize_market(market)
    limit = max(1, min(limit, 100))

    cols = ["name", "close", "volume", "change", "BB.upper", "BB.lower", "SMA20", "ATR", "Volatility.D"]

    query = Query().set_markets(market).select(*cols).limit(limit)

    if condition == "squeeze":
        query = query.order_by("Volatility.D", ascending=True)
    elif condition == "above_upper":
        query = query.where(Column("close") > Column("BB.upper")).order_by("change", ascending=False)
    elif condition == "below_lower":
        query = query.where(Column("close") < Column("BB.lower")).order_by("change", ascending=True)

    try:
        total, df = query.get_scanner_data()
        results = df.to_dict("records")

        # Calculate BBW and add signals
        for r in results:
            bb_upper = r.get("BB.upper", 0)
            bb_lower = r.get("BB.lower", 0)
            sma20 = r.get("SMA20", 0)
            close = r.get("close", 0)

            if sma20 and bb_upper and bb_lower:
                bbw = compute_bollinger_band_width(sma20, bb_upper, bb_lower)
                r["bbw"] = round(bbw, 4) if bbw else None

                rating, signal = compute_bollinger_rating(close, bb_upper, sma20, bb_lower)
                r["bb_rating"] = rating
                r["bb_signal"] = signal

        return results
    except Exception as e:
        return [{"error": str(e)}]


@mcp.tool()
def scan_volume_breakout(
    market: str = "america",
    volume_multiplier: float = 2.0,
    min_price_change: float = 3.0,
    limit: int = 25,
) -> list[dict[str, Any]]:
    """
    Scan for volume breakout candidates.

    Args:
        market: Market to scan
        volume_multiplier: Minimum relative volume vs 10-day average (default 2.0)
        min_price_change: Minimum absolute price change % (default 3.0)
        limit: Number of results (1-100)

    Returns:
        List of symbols with volume breakouts
    """
    market = sanitize_market(market)
    limit = max(1, min(limit, 100))
    volume_multiplier = max(1.2, min(10.0, volume_multiplier))
    min_price_change = max(0.5, min(20.0, min_price_change))

    cols = [
        "name",
        "close",
        "volume",
        "change",
        "change_abs",
        "relative_volume_10d_calc",
        "average_volume_10d_calc",
    ]

    query = (
        Query()
        .set_markets(market)
        .select(*cols)
        .where(
            Column("relative_volume_10d_calc") >= volume_multiplier,
        )
        .order_by("relative_volume_10d_calc", ascending=False)
        .limit(limit * 2)  # Get more to filter
    )

    try:
        total, df = query.get_scanner_data()
        results = df.to_dict("records")

        # Filter by price change
        filtered = []
        for r in results:
            change = abs(r.get("change", 0) or 0)
            if change >= min_price_change:
                rel_vol = r.get("relative_volume_10d_calc", 1)
                r["breakout_type"] = "bullish" if r.get("change", 0) > 0 else "bearish"
                r["volume_strength"] = "VERY_STRONG" if rel_vol >= 3 else "STRONG" if rel_vol >= 2 else "MODERATE"
                filtered.append(r)

        return filtered[:limit]
    except Exception as e:
        return [{"error": str(e)}]


@mcp.tool()
def scan_moving_average_crossover(
    market: str = "america",
    crossover_type: str = "golden_cross",
    limit: int = 25,
) -> list[dict[str, Any]]:
    """
    Scan for moving average crossovers.

    Args:
        market: Market to scan
        crossover_type: 'golden_cross' (SMA50 crosses above SMA200),
                       'death_cross' (SMA50 crosses below SMA200),
                       'above_all_mas', 'below_all_mas'
        limit: Number of results (1-100)

    Returns:
        List of symbols with MA crossovers
    """
    market = sanitize_market(market)
    limit = max(1, min(limit, 100))

    scanner_map = {
        "golden_cross": Scanner.golden_cross,
        "death_cross": Scanner.death_cross,
        "above_all_mas": Scanner.above_all_mas,
    }

    scanner = scanner_map.get(crossover_type)
    if scanner:
        scanner = scanner.copy().set_markets(market).limit(limit)
    else:
        # below_all_mas
        scanner = (
            Query()
            .set_markets(market)
            .select("name", "close", "volume", "change", "SMA20", "SMA50", "SMA200")
            .where(
                Column("close") < Column("SMA20"),
                Column("close") < Column("SMA50"),
                Column("close") < Column("SMA200"),
            )
            .order_by("change", ascending=True)
            .limit(limit)
        )

    try:
        total, df = scanner.get_scanner_data()
        results = df.to_dict("records")

        for r in results:
            r["crossover_type"] = crossover_type

        return results
    except Exception as e:
        return [{"error": str(e)}]


@mcp.tool()
def scan_52_week_levels(
    market: str = "america",
    level_type: str = "near_high",
    threshold_pct: float = 5.0,
    limit: int = 25,
) -> list[dict[str, Any]]:
    """
    Scan for stocks near 52-week highs or lows.

    Args:
        market: Market to scan
        level_type: 'near_high', 'near_low', 'new_high', 'new_low'
        threshold_pct: How close to the level (default 5%)
        limit: Number of results (1-100)

    Returns:
        List of symbols near 52-week extremes
    """
    market = sanitize_market(market)
    limit = max(1, min(limit, 100))
    threshold_pct = max(1.0, min(20.0, threshold_pct))

    cols = ["name", "close", "volume", "change", "price_52_week_high", "price_52_week_low", "Perf.Y"]

    query = Query().set_markets(market).select(*cols).limit(limit)

    if level_type == "near_high":
        # Price within threshold_pct of 52-week high
        multiplier = 1 - (threshold_pct / 100)
        query = query.where(Column("close").above_pct("price_52_week_high", multiplier)).order_by(
            "change", ascending=False
        )
    elif level_type == "near_low":
        # Price within threshold_pct of 52-week low
        multiplier = 1 + (threshold_pct / 100)
        query = query.where(Column("close").below_pct("price_52_week_low", multiplier)).order_by(
            "change", ascending=True
        )
    elif level_type == "new_high":
        query = query.where(Column("close") >= Column("price_52_week_high")).order_by(
            "change", ascending=False
        )
    else:  # new_low
        query = query.where(Column("close") <= Column("price_52_week_low")).order_by(
            "change", ascending=True
        )

    try:
        total, df = query.get_scanner_data()
        results = df.to_dict("records")

        for r in results:
            close = r.get("close", 0)
            high52 = r.get("price_52_week_high", 0)
            low52 = r.get("price_52_week_low", 0)

            if high52:
                r["pct_from_52w_high"] = round(((close - high52) / high52) * 100, 2)
            if low52:
                r["pct_from_52w_low"] = round(((close - low52) / low52) * 100, 2)

        return results
    except Exception as e:
        return [{"error": str(e)}]


# =============================================================================
# MCP Tools - Symbol Analysis
# =============================================================================


@mcp.tool()
def get_symbol_analysis(
    symbol: str,
    include_fundamentals: bool = True,
) -> dict[str, Any]:
    """
    Get comprehensive technical analysis for a specific symbol.

    Args:
        symbol: Symbol in format 'EXCHANGE:SYMBOL' (e.g., 'NASDAQ:AAPL', 'BINANCE:BTCUSDT')
        include_fundamentals: Include fundamental data if available

    Returns:
        Comprehensive analysis with indicators, signals, and recommendations
    """
    # Select columns based on what we want
    cols = [
        "name",
        "description",
        "type",
        "exchange",
        "close",
        "open",
        "high",
        "low",
        "volume",
        "change",
        "change_abs",
        # Technical indicators
        "RSI",
        "RSI7",
        "MACD.macd",
        "MACD.signal",
        "BB.upper",
        "BB.lower",
        "SMA20",
        "SMA50",
        "SMA200",
        "EMA20",
        "EMA50",
        "EMA200",
        "ADX",
        "ATR",
        "Stoch.K",
        "Stoch.D",
        "VWAP",
        "Volatility.D",
        # Performance
        "Perf.W",
        "Perf.1M",
        "Perf.3M",
        "Perf.Y",
        # Recommendations
        "Recommend.All",
        "Recommend.MA",
        "Recommend.Other",
    ]

    if include_fundamentals:
        cols.extend(
            [
                "market_cap_basic",
                "price_earnings_ttm",
                "earnings_per_share_basic_ttm",
                "dividend_yield_recent",
                "price_52_week_high",
                "price_52_week_low",
            ]
        )

    try:
        query = Query().set_tickers(symbol).select(*cols)
        total, df = query.get_scanner_data()

        if df.empty:
            return {"error": f"No data found for {symbol}"}

        row = df.iloc[0].to_dict()

        # Perform technical analysis
        analysis = analyze_indicators(row)

        # Build result
        result = {
            "symbol": symbol,
            "name": row.get("name"),
            "exchange": row.get("exchange"),
            "type": row.get("type"),
            "price_data": {
                "close": row.get("close"),
                "open": row.get("open"),
                "high": row.get("high"),
                "low": row.get("low"),
                "volume": row.get("volume"),
                "change": row.get("change"),
                "change_abs": row.get("change_abs"),
            },
            "technical_indicators": {
                "rsi": row.get("RSI"),
                "rsi7": row.get("RSI7"),
                "macd": row.get("MACD.macd"),
                "macd_signal": row.get("MACD.signal"),
                "bb_upper": row.get("BB.upper"),
                "bb_lower": row.get("BB.lower"),
                "sma20": row.get("SMA20"),
                "sma50": row.get("SMA50"),
                "sma200": row.get("SMA200"),
                "ema20": row.get("EMA20"),
                "ema50": row.get("EMA50"),
                "ema200": row.get("EMA200"),
                "adx": row.get("ADX"),
                "atr": row.get("ATR"),
                "stoch_k": row.get("Stoch.K"),
                "stoch_d": row.get("Stoch.D"),
                "vwap": row.get("VWAP"),
                "volatility": row.get("Volatility.D"),
            },
            "performance": {
                "weekly": row.get("Perf.W"),
                "monthly": row.get("Perf.1M"),
                "quarterly": row.get("Perf.3M"),
                "yearly": row.get("Perf.Y"),
            },
            "ratings": {
                "overall": row.get("Recommend.All"),
                "overall_label": format_technical_rating(row.get("Recommend.All", 0)),
                "moving_averages": row.get("Recommend.MA"),
                "oscillators": row.get("Recommend.Other"),
            },
            "analysis": analysis,
        }

        if include_fundamentals:
            result["fundamentals"] = {
                "market_cap": row.get("market_cap_basic"),
                "pe_ratio": row.get("price_earnings_ttm"),
                "eps": row.get("earnings_per_share_basic_ttm"),
                "dividend_yield": row.get("dividend_yield_recent"),
                "52_week_high": row.get("price_52_week_high"),
                "52_week_low": row.get("price_52_week_low"),
            }

        return result

    except Exception as e:
        return {"error": str(e), "symbol": symbol}


@mcp.tool()
def compare_symbols(
    symbols: list[str],
    columns: Optional[list[str]] = None,
) -> list[dict[str, Any]]:
    """
    Compare multiple symbols side by side.

    Args:
        symbols: List of symbols (e.g., ['NASDAQ:AAPL', 'NASDAQ:MSFT', 'NASDAQ:GOOGL'])
        columns: Columns to compare (default: standard comparison set)

    Returns:
        Comparison data for all symbols
    """
    if not symbols:
        return [{"error": "No symbols provided"}]

    cols = columns or [
        "name",
        "close",
        "change",
        "volume",
        "RSI",
        "MACD.macd",
        "market_cap_basic",
        "Perf.1M",
        "Perf.Y",
        "Recommend.All",
    ]

    try:
        query = Query().set_tickers(*symbols).select(*cols)
        total, df = query.get_scanner_data()

        results = df.to_dict("records")

        # Add technical rating labels
        for r in results:
            rec = r.get("Recommend.All")
            if rec is not None:
                r["rating_label"] = format_technical_rating(rec)

        return results

    except Exception as e:
        return [{"error": str(e)}]


# =============================================================================
# MCP Tools - Utility Functions
# =============================================================================


@mcp.tool()
def get_all_market_symbols(market: str = "america") -> dict[str, Any]:
    """
    Get all available symbols for a market.

    Args:
        market: Market identifier (america, crypto, uk, etc.)

    Returns:
        Dictionary with symbol count and list of symbols
    """
    market = sanitize_market(market)

    try:
        symbols = get_all_symbols(market)
        return {
            "market": market,
            "total_symbols": len(symbols),
            "symbols": symbols[:500],  # Return first 500 to avoid huge responses
            "note": f"Showing first 500 of {len(symbols)} symbols" if len(symbols) > 500 else None,
        }
    except Exception as e:
        return {"error": str(e), "market": market}


@mcp.tool()
def run_scanner_preset(
    preset_name: str,
    market: Optional[str] = None,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """
    Run a pre-built scanner preset.

    Args:
        preset_name: Name of the preset (see scanners://presets resource)
        market: Override market (optional)
        limit: Number of results (1-100)

    Returns:
        Scanner results
    """
    limit = max(1, min(limit, 100))

    # Try stock scanners first
    scanner = getattr(Scanner, preset_name, None)

    # Try crypto scanners
    if scanner is None:
        scanner = getattr(CryptoScanner, preset_name, None)

    if scanner is None:
        available = Scanner.names() + CryptoScanner.names()
        return [{"error": f"Unknown preset: {preset_name}", "available_presets": available}]

    scanner = scanner.copy().limit(limit)

    if market:
        market = sanitize_market(market)
        scanner = scanner.set_markets(market)

    try:
        total, df = scanner.get_scanner_data()
        return df.to_dict("records")
    except Exception as e:
        return [{"error": str(e)}]


@mcp.tool()
def advanced_query(
    market: str = "america",
    select_columns: list[str] = None,
    conditions: list[dict[str, Any]] = None,
    logic: str = "and",
    sort_by: str = "volume",
    ascending: bool = False,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """
    Execute an advanced query with complex AND/OR logic.

    Args:
        market: Market to scan
        select_columns: Columns to return
        conditions: List of conditions, each with:
                   - column: Column name
                   - op: Operation (gt, gte, lt, lte, eq, neq, between, isin, crosses_above, crosses_below)
                   - value: Value or [min, max] for between
        logic: 'and' or 'or' to combine conditions
        sort_by: Column to sort by
        ascending: Sort order
        limit: Maximum results (1-500)

    Returns:
        Query results

    Example:
        conditions=[
            {"column": "RSI", "op": "lt", "value": 30},
            {"column": "volume", "op": "gt", "value": 1000000},
            {"column": "change", "op": "between", "value": [-5, 5]}
        ]
    """
    market = sanitize_market(market)
    limit = max(1, min(limit, 500))
    cols = select_columns or TECHNICAL_COLUMNS

    query = Query().set_markets(market).select(*cols).order_by(sort_by, ascending=ascending).limit(limit)

    if conditions:
        expressions = []
        for cond in conditions:
            col = Column(cond.get("column", "close"))
            op = cond.get("op", "gt")
            val = cond.get("value")

            if op == "gt":
                expressions.append(col > val)
            elif op == "gte":
                expressions.append(col >= val)
            elif op == "lt":
                expressions.append(col < val)
            elif op == "lte":
                expressions.append(col <= val)
            elif op == "eq":
                expressions.append(col == val)
            elif op == "neq":
                expressions.append(col != val)
            elif op == "between" and isinstance(val, (list, tuple)) and len(val) == 2:
                expressions.append(col.between(val[0], val[1]))
            elif op == "isin" and isinstance(val, (list, tuple)):
                expressions.append(col.isin(val))
            elif op == "crosses_above":
                expressions.append(col.crosses_above(Column(val) if isinstance(val, str) else val))
            elif op == "crosses_below":
                expressions.append(col.crosses_below(Column(val) if isinstance(val, str) else val))
            elif op == "above_pct" and isinstance(val, (list, tuple)) and len(val) == 2:
                expressions.append(col.above_pct(val[0], val[1]))
            elif op == "below_pct" and isinstance(val, (list, tuple)) and len(val) == 2:
                expressions.append(col.below_pct(val[0], val[1]))

        if expressions:
            if logic == "or":
                query = query.where2(Or(*expressions))
            else:
                query = query.where(*expressions)

    try:
        total, df = query.get_scanner_data()
        results = df.to_dict("records")
        return [{"total_count": total, "returned": len(results), "data": results}]
    except Exception as e:
        return [{"error": str(e)}]


# =============================================================================
# MCP Tools - Crypto Specific
# =============================================================================


@mcp.tool()
def get_crypto_gainers(exchange: Optional[str] = None, limit: int = 25) -> list[dict[str, Any]]:
    """
    Get top gaining cryptocurrencies.

    Args:
        exchange: Specific exchange (binance, coinbase, etc.) or None for all
        limit: Number of results (1-100)

    Returns:
        List of top crypto gainers
    """
    limit = max(1, min(limit, 100))

    cols = ["name", "close", "volume", "change", "change_abs", "market_cap_basic", "24h_vol|5"]

    query = (
        Query()
        .set_markets("crypto")
        .select(*cols)
        .where(Column("change") > 0)
        .order_by("change", ascending=False)
        .limit(limit)
    )

    if exchange:
        query = query.where(Column("exchange") == exchange.upper())

    try:
        total, df = query.get_scanner_data()
        return df.to_dict("records")
    except Exception as e:
        return [{"error": str(e)}]


@mcp.tool()
def get_crypto_losers(exchange: Optional[str] = None, limit: int = 25) -> list[dict[str, Any]]:
    """
    Get top losing cryptocurrencies.

    Args:
        exchange: Specific exchange (binance, coinbase, etc.) or None for all
        limit: Number of results (1-100)

    Returns:
        List of top crypto losers
    """
    limit = max(1, min(limit, 100))

    cols = ["name", "close", "volume", "change", "change_abs", "market_cap_basic", "24h_vol|5"]

    query = (
        Query()
        .set_markets("crypto")
        .select(*cols)
        .where(Column("change") < 0)
        .order_by("change", ascending=True)
        .limit(limit)
    )

    if exchange:
        query = query.where(Column("exchange") == exchange.upper())

    try:
        total, df = query.get_scanner_data()
        return df.to_dict("records")
    except Exception as e:
        return [{"error": str(e)}]


@mcp.tool()
def scan_crypto_technicals(
    scan_type: str = "oversold",
    exchange: Optional[str] = None,
    limit: int = 25,
) -> list[dict[str, Any]]:
    """
    Scan cryptocurrencies based on technical indicators.

    Args:
        scan_type: Type of scan - 'oversold', 'overbought', 'macd_bullish', 'macd_bearish', 'high_volume'
        exchange: Specific exchange or None for all
        limit: Number of results (1-100)

    Returns:
        Crypto technical scan results
    """
    limit = max(1, min(limit, 100))

    scanner_map = {
        "oversold": CryptoScanner.oversold,
        "overbought": CryptoScanner.overbought,
        "high_volume": CryptoScanner.high_volume,
        "most_volatile": CryptoScanner.most_volatile,
    }

    if scan_type in scanner_map:
        scanner = scanner_map[scan_type].copy().limit(limit)
    elif scan_type == "macd_bullish":
        scanner = (
            Query()
            .set_markets("crypto")
            .select("name", "close", "volume", "change", "MACD.macd", "MACD.signal", "RSI")
            .where(Column("MACD.macd").crosses_above(Column("MACD.signal")))
            .order_by("change", ascending=False)
            .limit(limit)
        )
    elif scan_type == "macd_bearish":
        scanner = (
            Query()
            .set_markets("crypto")
            .select("name", "close", "volume", "change", "MACD.macd", "MACD.signal", "RSI")
            .where(Column("MACD.macd").crosses_below(Column("MACD.signal")))
            .order_by("change", ascending=True)
            .limit(limit)
        )
    else:
        return [{"error": f"Unknown scan_type: {scan_type}"}]

    if exchange:
        scanner = scanner.where(Column("exchange") == exchange.upper())

    try:
        total, df = scanner.get_scanner_data()
        return df.to_dict("records")
    except Exception as e:
        return [{"error": str(e)}]


# =============================================================================
# Server Entry Point
# =============================================================================


def main() -> None:
    """Main entry point for the MCP server."""
    parser = argparse.ArgumentParser(description="TradingView Screener MCP Server")
    parser.add_argument(
        "transport",
        choices=["stdio", "streamable-http"],
        default="stdio",
        nargs="?",
        help="Transport protocol (default: stdio)",
    )
    parser.add_argument("--host", default=os.environ.get("HOST", "127.0.0.1"), help="HTTP host")
    parser.add_argument(
        "--port", type=int, default=int(os.environ.get("PORT", "8000")), help="HTTP port"
    )
    args = parser.parse_args()

    if os.environ.get("DEBUG_MCP"):
        import sys

        print(f"[DEBUG] TradingView MCP starting: transport={args.transport}", file=sys.stderr, flush=True)

    if args.transport == "stdio":
        mcp.run()
    else:
        try:
            mcp.settings.host = args.host
            mcp.settings.port = args.port
        except AttributeError:
            pass
        mcp.run(transport="streamable-http")


if __name__ == "__main__":
    main()
