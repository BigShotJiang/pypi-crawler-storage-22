# TradingView MCP Server

[![PyPI version](https://badge.fury.io/py/tradingview-mcp.svg)](https://badge.fury.io/py/tradingview-mcp)
[![Python](https://img.shields.io/pypi/pyversions/tradingview-mcp.svg)](https://pypi.org/project/tradingview-mcp/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

MCP server for TradingView market screening. Supports stocks, crypto, forex, futures, bonds across 76+ markets.

## Quick Start
```json
{
  "mcpServers": {
    "tradingview": {
      "command": "uvx",
      "args": ["tradingview-mcp"]
    }
  }
}
```

## Smart Features

- **Auto-Market Detection**: If you search for `EURUSD` or `BTCUSDT`, the server automatically checks Forex and Crypto markets if not found in stocks.
- **Strict Exchange Support**: Use `EXCHANGE:SYMBOL` format (e.g., `BINANCE:BTCUSDT`, `FX:EURUSD`) to target specific markets.
- **Smart Filters**: You can use human-readable names in filters (e.g., `"Relative Strength Index (14)"` instead of `"RSI"`).

## Main Tools

| Tool | Description |
|------|-------------|
| `screen_market` | Custom market screening with filters |
| `get_top_gainers` | Top gaining assets |
| `get_top_losers` | Top losing assets |
| `get_most_active` | Most traded by volume |
| `search_symbols` | Search by company name |
| `get_symbol_info` | Detailed symbol info |
| `advanced_query` | Complex queries with AND/OR logic |

### Technical Analysis

| Tool | Description |
|------|-------------|
| `get_technical_analysis` | Full technical analysis |
| `scan_rsi_extremes` | RSI overbought/oversold |
| `scan_macd_crossover` | MACD crossover detection |
| `scan_bollinger_bands` | Bollinger Band squeeze |
| `scan_volume_breakout` | Volume breakout detection |

### Reference Tools

| Tool | Description |
|------|-------------|
| `ai_get_reference` | Quick reference for markets/columns/filters |
| `search_available_fields` | Search for fields by name |
| `get_field_info` | Get field display name and type |
| `list_fields_for_market` | List fields for a market |
| `get_screener_preset` | Get predefined screener presets |

## Reference Resources

These resources provide raw lists of available markets and fields for reference.

| Resource | Description |
|----------|-------------|
| `markets://list` | All available markets |
| `columns://list` | Available columns/fields |
| `docs://ai-reference` | AI quick reference |
| `docs://fields` | Field display names |

## Markets

- **Stocks**: america, uk, germany, japan, china, etc. (68 countries)
- **Crypto**: crypto (pairs), coin (individual coins)
- **Others**: forex, futures, bonds, cfd, options

## Installation

```bash
# Using uvx (recommended)
uvx tradingview-mcp

# Using pip
pip install tradingview-mcp

# From source
git clone https://github.com/k73a/tradingview-mcp.git
cd tradingview-mcp
uv sync
```

## Running

```bash
# Stdio (default)
tradingview-mcp

# HTTP
tradingview-mcp streamable-http --host 127.0.0.1 --port 8000
```

## Development

```bash
uv sync --all-extras
uv run pytest tests/ -v
uv run ruff format .
uv run ruff check . --fix
```

## License

MIT License
