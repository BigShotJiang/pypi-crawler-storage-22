"""
Constants for TradingView Screener integration.

Contains API URLs, headers, supported markets, and column definitions.
"""
from __future__ import annotations

import json
from pathlib import Path

# API Configuration
URL = "https://scanner.tradingview.com/{market}/scan"

HEADERS = {
    "authority": "scanner.tradingview.com",
    "sec-ch-ua": '" Not A;Brand";v="99", "Chromium";v="98", "Google Chrome";v="98"',
    "accept": "text/plain, */*; q=0.01",
    "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
    "sec-ch-ua-mobile": "?0",
    "user-agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36"
    ),
    "sec-ch-ua-platform": '"Windows"',
    "origin": "https://www.tradingview.com",
    "sec-fetch-site": "same-site",
    "sec-fetch-mode": "cors",
    "sec-fetch-dest": "empty",
    "referer": "https://www.tradingview.com/",
    "accept-language": "en-US,en;q=0.9",
}

DEFAULT_RANGE = [0, 50]

# =============================================================================
# Load Data from JSON (Dynamic)
# =============================================================================

_DATA_DIR = Path(__file__).parent / "data"

def _load_markets() -> set[str]:
    """Load supported markets from JSON."""
    try:
        with open(_DATA_DIR / "markets.json", "r", encoding="utf-8") as f:
            data = json.load(f)
            return set(data.get("countries", []) + data.get("other", []))
    except Exception:
        # Fallback if file not found (dev/test env)
        return {"america", "crypto", "forex"}

def _load_columns() -> dict[str, str]:
    """
    Load column definitions from JSON.
    Returns: Dict[Display Name, Field Name] (Reverse of JSON)
    """
    try:
        with open(_DATA_DIR / "column_display_names.json", "r", encoding="utf-8") as f:
            data = json.load(f)
            fields = data.get("fields", {})
            # Reverse mapping: Display Name -> Field Name
            # e.g. "Relative Strength Index (14)" -> "RSI"
            return {v: k for k, v in fields.items()}
    except Exception:
        return {}

# Public Constants
MARKETS = _load_markets()
COLUMNS = _load_columns()

# Exchange to Screener Mapping (Expanded)
EXCHANGE_SCREENER = {
    # Crypto
    "all": "crypto",
    "binance": "crypto",
    "coinbase": "crypto",
    "kraken": "crypto",
    "kucoin": "crypto",
    "bitfinex": "crypto",
    "bitstamp": "crypto",
    "okx": "crypto",
    "bybit": "crypto",
    "gateio": "crypto",
    "huobi": "crypto",
    "gemini": "crypto",
    "poloniex": "crypto",
    "bittrex": "crypto",
    "bitmex": "crypto",
    "deribit": "crypto",
    "mexc": "crypto",
    "bingx": "crypto",
    "phemex": "crypto",
    "bitget": "crypto",
    # Forex
    "fx": "forex",
    "fx_idc": "forex",
    "oanda": "forex",
    "forex": "forex",
    "ice": "forex",  # Often forex/futures
    "saxo": "forex",
    "cityindex": "forex",
    # Futures
    "cme": "futures",
    "cbot": "futures",
    "comex": "futures",
    "nymex": "futures",
    "eurex": "futures",
    # US Stocks
    "nasdaq": "america",
    "nyse": "america",
    "amex": "america",
    "arca": "america",
    "otc": "america",
    # Global Stocks
    "lse": "uk",  # London
    "tsx": "canada",  # Toronto
    "asx": "australia",
    "sse": "china",  # Shanghai
    "szse": "china",  # Shenzhen
    "hkex": "hongkong",
    "hk": "hongkong",
    "tse": "japan",  # Tokyo
    "tyo": "japan",
    "ebs": "switzerland",  # Swiss SIX
    "six": "switzerland",
    "xetra": "germany",
    "fwb": "germany",
    "euronext": "france",  # Generic Euronext
    "nse": "india",
    "bse": "india",
    "krx": "korea",
    "kosdaq": "korea",
    "b3": "brazil",
    "moex": "russia",
    "sgx": "singapore",
    "twse": "taiwan",
}

# Allowed Timeframes
ALLOWED_TIMEFRAMES = {"1m", "5m", "15m", "30m", "1h", "2h", "4h", "1D", "1W", "1M"}

# Timeframe to TradingView Resolution
TIMEFRAME_MAP = {
    "1m": "1",
    "5m": "5",
    "15m": "15",
    "30m": "30",
    "1h": "60",
    "2h": "120",
    "4h": "240",
    "1D": "1D",
    "1W": "1W",
    "1M": "1M",
}

# Default columns for different query types
# Always include 'description' for full name (e.g., "Apple Inc." instead of just "AAPL")
DEFAULT_COLUMNS = ["name", "description", "close", "change", "volume", "market_cap_basic"]

PREMARKET_COLUMNS = ["name", "description", "close", "volume", "premarket_change", "premarket_change_abs", "premarket_volume"]

POSTMARKET_COLUMNS = ["name", "description", "close", "volume", "postmarket_change", "postmarket_change_abs", "postmarket_volume"]

CRYPTO_COLUMNS = ["name", "description", "close", "change", "volume", "market_cap_basic", "24h_vol|5"]

TECHNICAL_COLUMNS = [
    "name",
    "description",
    "close",
    "volume",
    "change",
    "RSI",
    "MACD.macd",
    "MACD.signal",
    "BB.upper",
    "BB.lower",
    "SMA20",
    "EMA50",
    "EMA200",
    "ADX",
    "Stoch.K",
    "Stoch.D",
]

def get_column_name(name: str) -> str:
    """Get the API column name from a human-readable name or return as-is."""
    # Try exact match first
    if name in COLUMNS:
        return COLUMNS[name]
    
    # Try case-insensitive keys
    name_lower = name.lower()
    for k, v in COLUMNS.items():
        if k.lower() == name_lower:
            return v
            
    return name
