"""Load packaged docs datasets for MCP resources - AI-friendly fast lookup."""

from __future__ import annotations

import json
from functools import lru_cache
from importlib.resources import files
from typing import Any


# Token/size limits
MAX_ITEMS_DEFAULT = 50
MAX_ITEMS_LARGE = 200

# Valid markets for quick reference
STOCK_MARKETS = [
    "america", "argentina", "australia", "austria", "bahrain", "bangladesh",
    "belgium", "brazil", "canada", "chile", "china", "colombia", "cyprus",
    "czech", "denmark", "egypt", "estonia", "finland", "france", "germany",
    "greece", "hongkong", "hungary", "iceland", "india", "indonesia", "ireland",
    "israel", "italy", "japan", "kenya", "korea", "ksa", "kuwait", "latvia",
    "lithuania", "luxembourg", "malaysia", "mexico", "morocco", "netherlands",
    "newzealand", "nigeria", "norway", "pakistan", "peru", "philippines",
    "poland", "portugal", "qatar", "romania", "rsa", "russia", "serbia",
    "singapore", "slovakia", "spain", "srilanka", "sweden", "switzerland",
    "taiwan", "thailand", "tunisia", "turkey", "uae", "uk", "venezuela", "vietnam",
]
OTHER_MARKETS = ["bond", "bonds", "cfd", "coin", "crypto", "economics2", "forex", "futures", "options"]
ALL_MARKETS = STOCK_MARKETS + OTHER_MARKETS

# Common field categories for quick lookup
FIELD_CATEGORIES = {
    "price": ["close", "open", "high", "low", "change", "change_abs", "gap"],
    "volume": ["volume", "Value.Traded", "relative_volume_10d_calc", "average_volume_10d_calc"],
    "market_cap": ["market_cap_basic", "market_cap_calc"],
    "fundamental": ["price_earnings_ttm", "earnings_per_share_basic_ttm", "dividends_yield_current"],
    "technical": ["RSI", "MACD.macd", "BB.upper", "BB.lower", "SMA50", "SMA200", "EMA50", "Recommend.All"],
    "performance": ["Perf.W", "Perf.1M", "Perf.3M", "Perf.6M", "Perf.Y", "Perf.YTD"],
    "metadata": ["name", "description", "sector", "exchange", "type", "currency"],
}

# Filter operations reference
FILTER_OPS = {
    "comparison": ["greater", "less", "equal", "not_equal", "greater_or_equal", "less_or_equal"],
    "range": ["in_range", "not_in_range"],
    "list": ["in_list", "not_in_list"],
    "text": ["match", "not_match", "has", "has_none_of"],
    "null": ["empty", "not_empty"],
}


def _data_path(*parts: str):
    """Get path to packaged data file."""
    return files("tradingview_mcp.data").joinpath(*parts)


@lru_cache(maxsize=128)
def load_json(*parts: str) -> Any:
    """Load JSON file from packaged data."""
    path = _data_path(*parts)
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def get_markets_data() -> dict[str, list[str]]:
    """Get markets metadata."""
    return load_json("markets.json")


def get_column_display_names() -> dict[str, str]:
    """Get field name to display name mapping."""
    data = load_json("column_display_names.json")
    return data.get("fields", data)


def get_screener_presets() -> list[dict[str, Any]]:
    """Get predefined screener presets."""
    return load_json("screeners", "main_screeners.json")


def get_screener_markets() -> list[str]:
    """Get list of screener market identifiers."""
    return load_json("screeners", "markets.json")


def get_metainfo(market: str) -> dict[str, Any]:
    """Get field metainfo for a specific market."""
    return load_json("metainfo", f"{market}.json")


def get_screeners_data(name: str) -> Any:
    """Get screeners data by filename."""
    return load_json("screeners", name)


def get_stock_screeners() -> list[dict[str, Any]]:
    """Get stock screeners metadata."""
    return load_json("screeners", "stocks.json")


def get_stock_screeners_failed() -> list[dict[str, Any]]:
    """Get failed stock screeners metadata."""
    return load_json("screeners", "stocks_failed.json")


def get_stock_screener_presets(market: str | None = None) -> dict[str, Any]:
    """Get stock screener presets by market."""
    data = load_json("extracted", "stock_screener_presets.json")
    if market:
        return data.get(market, {})
    return data


def get_valid_fields_for_market(market: str) -> list[str]:
    """Get list of valid field names for a market."""
    fields_data = get_fields_by_market(market)
    if isinstance(fields_data, list):
        return [f.get("name", "") for f in fields_data if f.get("name")]
    return []


def suggest_fields_for_error(error_message: str, market: str = "stocks") -> dict[str, Any]:
    """Suggest valid fields when an error occurs."""
    valid_fields = get_valid_fields_for_market(market)
    common = get_common_fields()
    
    # Extract commonly used fields
    common_names = list(common.keys())[:50]
    
    return {
        "error": error_message,
        "market": market,
        "suggestion": "Use fields from the valid_fields list",
        "common_fields": common_names,
        "total_valid_fields": len(valid_fields),
        "hint": "Call list_fields_for_market(market) for full field list"
    }


# ============================================================================
# AI-Friendly Data Access with Output Limits
# ============================================================================


def get_ai_quick_reference() -> dict[str, Any]:
    """Get AI quick reference guide with common patterns and examples."""
    return load_json("extracted", "ai_quick_reference.json")


def get_screener_code_examples() -> dict[str, str]:
    """Get screener code examples by name."""
    return load_json("extracted", "screener_code_examples.json")


def get_common_fields() -> dict[str, dict[str, Any]]:
    """Get common field definitions (from stocks, most comprehensive)."""
    return load_json("extracted", "common_fields.json")


def get_fields_by_market(market: str | None = None) -> dict[str, Any]:
    """Get field definitions by market type."""
    data = load_json("extracted", "fields_by_market.json")
    if market:
        return data.get(market, {})
    return data


def get_default_columns_for_market(market: str) -> list[str]:
    """Get smart default columns for a market to avoid 400 errors."""
    # Base columns safe for all
    cols = ["name", "description", "close", "change", "change_abs", "exchange", "type"]
    
    # Check if market has specific fields in data
    fields = get_fields_by_market(market)
    if not fields:
        # Fallback defaults if market data missing
        if market == "crypto":
            return cols + ["volume", "market_cap_basic", "24h_vol|5"]
        if market == "forex":
            return cols + ["bid", "ask"]
        return cols + ["volume", "market_cap_basic", "price_earnings_ttm", "sector", "industry"]

    # Extract available field names
    valid_names = {f.get("name") for f in fields if f.get("name")}
    
    # Add common extra columns if they exist in this market
    extras = [
        "open", "high", "low", "volume", "market_cap_basic", 
        "24h_vol|5", "bid", "ask", "price_earnings_ttm", 
        "earnings_per_share_basic_ttm", "dividend_yield_recent", 
        "sector", "industry"
    ]
    
    for extra in extras:
        if extra in valid_names:
            cols.append(extra)
            
    # Deduplicate while preserving order
    seen = set()
    unique_cols = []
    for c in cols:
        if c not in seen:
            seen.add(c)
            unique_cols.append(c)
            
    return unique_cols


def paginate_data(
    data: list | dict,
    offset: int = 0,
    limit: int = MAX_ITEMS_DEFAULT,
    confirm_large: bool = False,
) -> dict[str, Any]:
    """Paginate data with offset and limit."""
    if isinstance(data, list):
        total = len(data)
        items = data if confirm_large else data[offset:offset + limit]
    else:
        keys = list(data.keys())
        total = len(keys)
        if confirm_large:
            items = data
        else:
            selected_keys = keys[offset:offset + limit]
            items = {k: data[k] for k in selected_keys}
    
    result: dict[str, Any] = {
        "data": items,
        "total": total,
        "offset": offset,
        "limit": total if confirm_large else limit,
        "has_more": False if confirm_large else (offset + limit) < total,
        "next_offset": None if confirm_large else ((offset + limit) if (offset + limit) < total else None),
    }
    return result


def search_fields(
    query: str,
    market: str | None = None,
    limit: int = 20,
) -> list[dict[str, Any]]:
    """Search fields by name or display name."""
    query_lower = query.lower()
    
    if market:
        fields_data = get_fields_by_market(market)
        if isinstance(fields_data, list):
            fields = fields_data
        else:
            return []
    else:
        fields = list(get_common_fields().items())
        fields = [
            {"name": k, **v} if isinstance(v, dict) else {"name": k, "display_name": str(v)}
            for k, v in fields[:500]  # Limit iteration
        ]
    
    matches = []
    for field in fields:
        if isinstance(field, dict):
            name = field.get("name", "")
            display = field.get("display_name", "")
            if query_lower in name.lower() or query_lower in display.lower():
                matches.append(field)
                if len(matches) >= limit:
                    break
    
    return matches


def get_field_summary(field_name: str) -> dict[str, Any] | None:
    """Get summary info for a field."""
    # Check common fields first
    common = get_common_fields()
    if field_name in common:
        info = common[field_name]
        return {
            "name": field_name,
            "display_name": info.get("display_name"),
            "type": info.get("type"),
            "variants": info.get("variants"),
        }
    
    # Check display names mapping
    display_names = get_column_display_names()
    if field_name in display_names:
        return {
            "name": field_name,
            "display_name": display_names[field_name],
        }
    
    return None


def estimate_tokens(data: Any) -> int:
    """Estimate token count for data (rough: 4 chars = 1 token)."""
    json_str = json.dumps(data, ensure_ascii=False, default=str)
    return len(json_str) // 4


def truncate_for_tokens(
    data: Any,
    max_tokens: int = 10000,
) -> tuple[Any, bool]:
    """Truncate data to fit within a token limit."""
    estimated = estimate_tokens(data)
    if estimated <= max_tokens:
        return data, False
    
    # Try to truncate intelligently
    if isinstance(data, list):
        # Binary search for right size
        low, high = 0, len(data)
        while low < high:
            mid = (low + high + 1) // 2
            if estimate_tokens(data[:mid]) <= max_tokens:
                low = mid
            else:
                high = mid - 1
        return data[:low], True
    
    elif isinstance(data, dict):
        keys = list(data.keys())
        low, high = 0, len(keys)
        while low < high:
            mid = (low + high + 1) // 2
            subset = {k: data[k] for k in keys[:mid]}
            if estimate_tokens(subset) <= max_tokens:
                low = mid
            else:
                high = mid - 1
        return {k: data[k] for k in keys[:low]}, True
    
    # Fallback: stringify and truncate
    json_str = json.dumps(data, ensure_ascii=False, default=str)
    max_chars = max_tokens * 4
    if len(json_str) > max_chars:
        return json_str[:max_chars] + "... (truncated)", True
    return data, False


# ============================================================================
# Fast Lookup Functions - Returns compact data, not full dumps
# ============================================================================


def get_quick_reference() -> dict[str, Any]:
    """Get compact quick reference - markets, field categories, filter ops."""
    return {
        "stock_markets": STOCK_MARKETS,
        "other_markets": OTHER_MARKETS,
        "field_categories": FIELD_CATEGORIES,
        "filter_operations": FILTER_OPS,
        "usage": {
            "lookup_field": "lookup_field('RSI') - get field info",
            "search_fields": "search_fields('volume') - search by keyword",
            "get_filter_format": "get_filter_format('price') - get filter example",
        },
    }


def lookup_field(field_name: str) -> dict[str, Any]:
    """Lookup a single field by exact name."""
    # Check common fields
    common = get_common_fields()
    if field_name in common:
        info = common[field_name]
        return {
            "found": True,
            "name": field_name,
            "display_name": info.get("display_name"),
            "type": info.get("type"),
            "variants": info.get("variants"),
        }
    
    # Check display names
    display_names = get_column_display_names()
    if field_name in display_names:
        return {
            "found": True,
            "name": field_name,
            "display_name": display_names[field_name],
        }
    
    # Not found - suggest similar
    query_lower = field_name.lower()
    suggestions = [
        name for name in list(common.keys())[:200]
        if query_lower in name.lower()
    ][:5]
    
    return {
        "found": False,
        "name": field_name,
        "suggestions": suggestions,
        "hint": f"Field '{field_name}' not found. Try one of: {suggestions}" if suggestions else f"Field '{field_name}' not found. Use search_fields() to find available fields.",
    }


def get_filter_format(field_type: str = "number") -> dict[str, Any]:
    """Get correct filter format for a field type."""
    formats = {
        "number": {
            "example": {"column": "RSI", "operation": "lt", "value": 30},
            "operations": ["gt", "gte", "lt", "lte", "eq", "neq", "between"],
            "between_example": {"column": "RSI", "operation": "between", "value": [20, 80]},
        },
        "price": {
            "example": {"column": "close", "operation": "gt", "value": 100},
            "operations": ["gt", "gte", "lt", "lte", "eq", "between"],
        },
        "percent": {
            "example": {"column": "change", "operation": "gt", "value": 5},
            "operations": ["gt", "gte", "lt", "lte", "between"],
            "note": "Values are percentages, e.g., 5 = 5%",
        },
        "text": {
            "example": {"column": "sector", "operation": "eq", "value": "Technology"},
            "operations": ["eq", "neq", "isin"],
            "isin_example": {"column": "exchange", "operation": "isin", "value": ["NASDAQ", "NYSE"]},
        },
        "bool": {
            "example": {"column": "is_primary", "operation": "eq", "value": True},
            "operations": ["eq"],
        },
    }
    
    if field_type in formats:
        return {"type": field_type, **formats[field_type]}
    
    return {
        "error": f"Unknown type '{field_type}'",
        "available_types": list(formats.keys()),
        "default": formats["number"],
    }


def get_market_fields_summary(market: str) -> dict[str, Any]:
    """Get summary of available fields for a market (not full list)."""
    if market not in ALL_MARKETS:
        return {
            "error": f"Invalid market '{market}'",
            "valid_markets": ALL_MARKETS,
        }
    
    # Try metainfo first
    try:
        metainfo = get_metainfo(market if market not in STOCK_MARKETS else "stocks")
        if isinstance(metainfo, list):
            field_count = len(metainfo)
            # Get field types distribution
            types = {}
            for f in metainfo[:500]:
                t = f.get("t", "unknown")
                types[t] = types.get(t, 0) + 1
            
            return {
                "market": market,
                "total_fields": field_count,
                "field_types": types,
                "sample_fields": [f.get("n") for f in metainfo[:20]],
                "hint": "Use search_fields(query, market) to find specific fields",
            }
    except FileNotFoundError:
        pass
    
    # Fallback to fields_by_market
    fields = get_fields_by_market(market)
    if isinstance(fields, list):
        return {
            "market": market,
            "total_fields": len(fields),
            "sample_fields": [f.get("name") for f in fields[:20]],
        }
    
    return {"market": market, "note": "Use get_common_fields() for this market"}


def get_screener_preset_names() -> list[str]:
    """Get list of available screener preset names only."""
    presets = get_screener_presets()
    return [p.get("name", "") for p in presets if p.get("name")]


def get_code_example_names() -> list[str]:
    """Get list of available code example names."""
    examples = get_screener_code_examples()
    return list(examples.keys())


def validate_market(market: str) -> dict[str, Any]:
    """Validate market name and return correct format if invalid."""
    if market in ALL_MARKETS:
        return {"valid": True, "market": market}
    
    # Try case-insensitive match
    market_lower = market.lower()
    for m in ALL_MARKETS:
        if m.lower() == market_lower:
            return {"valid": True, "market": m, "normalized": True}
    
    # Suggest similar
    suggestions = [m for m in ALL_MARKETS if market_lower in m.lower()][:5]
    
    return {
        "valid": False,
        "input": market,
        "suggestions": suggestions if suggestions else ALL_MARKETS[:10],
        "hint": f"Invalid market '{market}'. Use one of the valid markets.",
    }


def build_error_with_format(
    error_type: str,
    context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build helpful error response with correct format examples."""
    error_formats = {
        "invalid_market": {
            "error": "Invalid market",
            "valid_markets": ALL_MARKETS,
            "example": "market='america'",
        },
        "invalid_field": {
            "error": "Invalid field",
            "common_fields": list(FIELD_CATEGORIES.get("price", [])) + list(FIELD_CATEGORIES.get("volume", [])),
            "example": "columns=['close', 'volume', 'change']",
            "hint": "Use search_fields(query) to find fields",
        },
        "invalid_filter": {
            "error": "Invalid filter format",
            "correct_format": {"column": "field_name", "operation": "op", "value": "value"},
            "operations": ["gt", "gte", "lt", "lte", "eq", "neq", "between", "isin"],
            "examples": [
                {"column": "change", "operation": "gt", "value": 5},
                {"column": "volume", "operation": "gt", "value": 1000000},
                {"column": "RSI", "operation": "between", "value": [20, 30]},
            ],
        },
        "invalid_sort": {
            "error": "Invalid sort field",
            "common_sort_fields": ["volume", "change", "market_cap_basic", "close", "RSI"],
            "example": "sort_by='volume', ascending=False",
        },
    }
    
    result = error_formats.get(error_type, {"error": error_type})
    if context:
        result["context"] = context
    return result
