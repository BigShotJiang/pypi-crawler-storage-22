from __future__ import annotations
from typing import Any

from tradingview_mcp.docs_data import (
    get_markets_data,
    get_column_display_names,
    get_screener_presets,
    get_screener_markets,
    get_stock_screeners,
    get_stock_screeners_failed,
    get_fields_by_market,
    get_ai_quick_reference,
    get_screener_code_examples,
)
from tradingview_mcp.constants import EXCHANGE_SCREENER

def list_markets() -> dict[str, Any]:
    """List all available markets."""
    return get_markets_data()

def list_columns() -> dict[str, str]:
    """List all available columns."""
    return get_column_display_names()

def list_crypto_exchanges() -> list[str]:
    """List all crypto exchanges."""
    return [k for k, v in EXCHANGE_SCREENER.items() if v == "crypto"]

def list_scanner_presets() -> list[dict[str, Any]]:
    """List scanner presets."""
    return get_screener_presets()

def docs_params() -> dict[str, Any]:
    """Documentation for parameters."""
    return {"limit": "Max 500", "range": "[0, 100]"}

def docs_screeners() -> list[str]:
    """Documentation for screeners."""
    return get_screener_markets()

def docs_stock_screeners() -> list[dict[str, Any]]:
    """Documentation for stock screeners."""
    return get_stock_screeners()

def docs_stock_screeners_failed() -> list[dict[str, Any]]:
    """Documentation for failed stock screeners."""
    return get_stock_screeners_failed()

def docs_fields() -> dict[str, Any]:
    """Documentation for fields."""
    return get_fields_by_market("stocks") # Default to stocks

def docs_markets() -> dict[str, Any]:
    """Documentation for markets."""
    return get_markets_data()

def docs_ai_reference() -> dict[str, Any]:
    """Documentation for AI reference."""
    return get_ai_quick_reference()

def docs_code_examples() -> dict[str, Any]:
    """Documentation for code examples."""
    return get_screener_code_examples()
