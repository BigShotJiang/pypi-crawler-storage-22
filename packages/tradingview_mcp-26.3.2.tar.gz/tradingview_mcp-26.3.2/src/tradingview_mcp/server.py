"""
TradingView MCP Server - Main server implementation.

Provides comprehensive MCP tools and resources for TradingView market screening.
"""

from __future__ import annotations

import inspect
import json
import os
import traceback
from datetime import datetime
from functools import wraps
from typing import Any

from mcp.server.fastmcp import FastMCP

from tradingview_mcp.docs_data import suggest_fields_for_error
from tradingview_mcp.tools.search import search_symbols, get_symbol_info
from tradingview_mcp.tools.screener import (
    screen_market, 
    get_top_gainers, 
    get_top_losers, 
    get_most_active
)
from tradingview_mcp.tools.technical import (
    get_technical_analysis,
    scan_rsi_extremes,
    scan_bollinger_bands,
    scan_macd_crossover
)
from tradingview_mcp.tools.reference import (
    ai_get_reference,
    search_available_fields,
    get_code_example,
    list_fields_for_market,
    get_common_fields_summary,
    lookup_single_field,
    get_filter_example,
    check_market,
    get_help,
    get_field_info,
    get_screener_preset,
    get_market_metainfo,
)
from tradingview_mcp.resources import (
    list_markets,
    list_columns,
    list_crypto_exchanges,
    list_scanner_presets,
    docs_params,
    docs_screeners,
    docs_stock_screeners,
    docs_stock_screeners_failed,
    docs_fields,
    docs_markets,
    docs_ai_reference,
    docs_code_examples,
)

# Initialize MCP Server
mcp = FastMCP(
    name="TradingView Screener MCP",
    instructions="""TradingView Market Screener MCP

Quick start:
1. Call `get_help()` for usage
2. Call `ai_get_reference()` for markets and fields

Common tools:
- `screen_market(market, limit)`
- `get_top_gainers(market, limit)`
- `get_top_losers(market, limit)`
- `search_symbols(query, market)`
- `get_symbol_info(symbol)`

Notes:
- `limit` default 25, max 500
- Results include `description`

Resources:
- docs://ai-reference
- markets://list
- columns://list
""",
)

DEBUG_MODE = os.getenv("TRADINGVIEW_MCP_DEBUG", "0").lower() in {"1", "true", "yes"}


def _safe_json(value: Any) -> Any:
    try:
        return json.loads(json.dumps(value, default=str))
    except Exception:
        return str(value)


def _debug_hint(exc: Exception, context: dict[str, Any] | None = None) -> dict[str, Any] | str | None:
    """Generate helpful hints based on error type."""
    message = str(exc).lower()
    
    # Extract market from context if available
    market = None
    if context:
        market = context.get("kwargs", {}).get("market") or context.get("market")
    
    if "market" in message and "invalid" in message:
        return "Check the market name using the markets://list or docs://screeners resources."
    
    if "column" in message or "unknown" in message or "field" in message:
        # Return structured field suggestions
        market_type = market or "stocks"
        if market_type in ["crypto", "coin"]:
            market_type = market_type
        elif market_type in ["forex"]:
            market_type = "forex"
        else:
            # Default to stocks for field suggestions
            market_type = "stocks"
        
        return suggest_fields_for_error(str(exc), market_type)
    
    if "http" in message or "status" in message:
        return "TradingView API may be rate-limiting or blocked. Retry with fewer requests."
    
    return None


def _build_error_response(tool_name: str, exc: Exception, context: dict[str, Any]) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "ok": False,
        "tool": tool_name,
        "error": {"type": exc.__class__.__name__, "message": str(exc)},
        "context": _safe_json(context),
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }
    
    hint = _debug_hint(exc, context)
    if hint:
        if isinstance(hint, dict):
            payload["field_suggestions"] = hint
        else:
            payload["hint"] = hint
    
    if DEBUG_MODE:
        payload["trace"] = traceback.format_exc()
    return payload


def debug_tool(fn):
    """Decorator to return structured debug responses on failure."""

    @wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            result = fn(*args, **kwargs)
            if isinstance(result, dict) and "error" in result:
                return _build_error_response(
                    fn.__name__,
                    Exception(str(result.get("error"))),
                    {"args": args, "kwargs": kwargs, "note": "error returned by tool"},
                )
            if (
                isinstance(result, list)
                and len(result) == 1
                and isinstance(result[0], dict)
                and "error" in result[0]
            ):
                return _build_error_response(
                    fn.__name__,
                    Exception(str(result[0].get("error"))),
                    {"args": args, "kwargs": kwargs, "note": "error returned by tool"},
                )
            return result
        except Exception as exc: 
            context = {"args": args, "kwargs": kwargs}
            return _build_error_response(fn.__name__, exc, context)

    return wrapper


_original_mcp_tool = mcp.tool


def _debug_mcp_tool(*args, **kwargs):
    """Wrap FastMCP tool registration with debug handling."""

    def decorator(fn):
        return _original_mcp_tool(*args, **kwargs)(debug_tool(fn))

    return decorator


mcp.tool = _debug_mcp_tool


# =============================================================================
# Register Tools
# =============================================================================

mcp.tool()(search_symbols)
mcp.tool()(get_symbol_info)
mcp.tool()(screen_market)
mcp.tool()(get_top_gainers)
mcp.tool()(get_top_losers)
mcp.tool()(get_most_active)

mcp.tool()(get_technical_analysis)
mcp.tool()(scan_rsi_extremes)
mcp.tool()(scan_bollinger_bands)
mcp.tool()(scan_macd_crossover)

mcp.tool()(ai_get_reference)
mcp.tool()(search_available_fields)
mcp.tool()(get_code_example)
mcp.tool()(list_fields_for_market)
mcp.tool()(get_common_fields_summary)
mcp.tool()(lookup_single_field)
mcp.tool()(get_field_info)
mcp.tool()(get_filter_example)
mcp.tool()(check_market)
mcp.tool()(get_help)
mcp.tool()(get_screener_preset)
mcp.tool()(get_market_metainfo)

# =============================================================================
# Register Resources
# =============================================================================

mcp.resource("markets://list")(list_markets)
mcp.resource("columns://list")(list_columns)
mcp.resource("exchanges://crypto")(list_crypto_exchanges)
mcp.resource("scanners://presets")(list_scanner_presets)
mcp.resource("docs://params")(docs_params)
mcp.resource("docs://screeners")(docs_screeners)
mcp.resource("docs://stock-screeners")(docs_stock_screeners)
mcp.resource("docs://stock-screeners-failed")(docs_stock_screeners_failed)
mcp.resource("docs://fields")(docs_fields)
mcp.resource("docs://markets")(docs_markets)
mcp.resource("docs://ai-reference")(docs_ai_reference)
mcp.resource("docs://code-examples")(docs_code_examples)


def main():
    mcp.run()

if __name__ == "__main__":
    main()
