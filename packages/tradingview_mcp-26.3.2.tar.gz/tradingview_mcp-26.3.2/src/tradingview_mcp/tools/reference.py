from __future__ import annotations
from typing import Any, Optional

from tradingview_mcp.docs_data import (
    get_ai_quick_reference,
    search_fields,
    get_screener_code_examples,
    get_valid_fields_for_market,
    get_common_fields,
    lookup_field,
    get_field_summary,
    get_filter_format,
    validate_market,
    get_quick_reference,
    get_screener_presets,
    get_metainfo
)

def ai_get_reference() -> dict[str, Any]:
    """Get AI quick reference for using this MCP."""
    return get_ai_quick_reference()

def search_available_fields(query: str, market: str = None) -> list[dict[str, Any]]:
    """Search for available fields/columns."""
    return search_fields(query, market)

def get_code_example(name: str) -> str:
    """Get code example by name."""
    examples = get_screener_code_examples()
    return examples.get(name, "Example not found.")

def list_fields_for_market(market: str) -> list[str]:
    """List valid fields for a specific market."""
    return get_valid_fields_for_market(market)

def get_common_fields_summary() -> dict[str, Any]:
    """Get summary of common fields."""
    return get_common_fields()

def lookup_single_field(name: str) -> dict[str, Any]:
    """Lookup details for a single field."""
    return lookup_field(name)

def get_field_info(name: str) -> dict[str, Any]:
    """Get info for a field."""
    return get_field_summary(name) or {"error": "Field not found"}

def get_filter_example(type: str = "number") -> dict[str, Any]:
    """Get example filter format."""
    return get_filter_format(type)

from tradingview_mcp.utils import sanitize_market

def check_market(market: str) -> dict[str, Any]:
    """Validate a market name."""
    # Resolve alias first (e.g. 'tw' -> 'taiwan') for consistency with other tools
    # We use strict=False because we want the default 'america' if fails? No, check_market should be explicit.
    # sanitize_market returns default 'america' if invalid.
    # We want to know if it's strictly valid or valid alias.
    
    # Check if it's a known alias
    clean = market.strip().lower()
    from tradingview_mcp.utils import COUNTRY_ALIASES
    if clean in COUNTRY_ALIASES:
        return validate_market(COUNTRY_ALIASES[clean])
        
    return validate_market(market)

def get_help() -> dict[str, Any]:
    """Get help and usage info."""
    return get_quick_reference()

def get_screener_preset(name: str) -> dict[str, Any]:
    """Get a screener preset."""
    presets = get_screener_presets()
    for p in presets:
        if p.get("name") == name:
            return p
    return {"error": "Preset not found"}

def get_market_metainfo(market: str) -> dict[str, Any]:
    """Get metainfo for a market."""
    return get_metainfo(market)
