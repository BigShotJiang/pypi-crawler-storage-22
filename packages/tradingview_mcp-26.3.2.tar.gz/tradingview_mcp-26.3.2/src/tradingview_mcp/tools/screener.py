from __future__ import annotations
from typing import Any, Optional

from tradingview_mcp.column import Column
from tradingview_mcp.constants import DEFAULT_COLUMNS, get_column_name
from tradingview_mcp.query import Query
from tradingview_mcp.utils import sanitize_market

def screen_market(
    market: str = "america",
    columns: Optional[list[str]] = None,
    sort_by: str = "volume",
    ascending: bool = False,
    limit: int = 25,
    filters: Optional[list[dict[str, Any]]] = None,
) -> dict[str, Any]:
    """Run a custom market screening query."""
    market = sanitize_market(market, strict=True)
    limit = max(1, min(limit, 500))
    
    # Ensure description is always included
    cols = columns or DEFAULT_COLUMNS
    if "description" not in cols:
        cols = ["description"] + list(cols)

    query = Query().set_markets(market).select(*cols).order_by(sort_by, ascending=ascending).limit(limit)

    # Apply filters if provided
    if filters:
        filter_expressions = []
        for f in filters:
            # Automatic translation of human-readable column names
            col_name = get_column_name(f.get("column", "close"))
            col = Column(col_name)
            op = f.get("operation", "gt")
            val = f.get("value")

            if op == "gt":
                filter_expressions.append(col > val)
            elif op == "gte":
                filter_expressions.append(col >= val)
            elif op == "lt":
                filter_expressions.append(col < val)
            elif op == "lte":
                filter_expressions.append(col <= val)
            elif op == "eq":
                filter_expressions.append(col == val)
            elif op == "neq":
                filter_expressions.append(col != val)
            elif op == "between" and isinstance(val, (list, tuple)) and len(val) == 2:
                filter_expressions.append(col.between(val[0], val[1]))
            elif op == "isin" and isinstance(val, (list, tuple)):
                filter_expressions.append(col.isin(val))

        if filter_expressions:
            query = query.where(*filter_expressions)

    try:
        total_count, df = query.get_scanner_data()
        results = df.to_dict("records")

        return {
            "total_count": total_count,
            "returned": len(results),
            "market": market,
            "data": results,
        }
    except Exception as e:
        return {"error": str(e), "market": market}


def get_top_gainers(market: str = "america", limit: int = 25) -> dict[str, Any]:
    """Get top gainers for a market."""
    market = sanitize_market(market, strict=True)
    return screen_market(market, sort_by="change", ascending=False, limit=limit)


def get_top_losers(market: str = "america", limit: int = 25) -> dict[str, Any]:
    """Get top losers for a market."""
    market = sanitize_market(market, strict=True)
    return screen_market(market, sort_by="change", ascending=True, limit=limit)


def get_most_active(market: str = "america", limit: int = 25) -> dict[str, Any]:
    """Get most active symbols by volume."""
    market = sanitize_market(market, strict=True)
    return screen_market(market, sort_by="volume", ascending=False, limit=limit)
