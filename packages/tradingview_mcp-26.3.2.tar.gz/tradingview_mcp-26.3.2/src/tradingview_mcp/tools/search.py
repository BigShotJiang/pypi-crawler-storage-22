from __future__ import annotations
from typing import Any
import concurrent.futures

from mcp.server.fastmcp import Context

from tradingview_mcp.column import Column
from tradingview_mcp.constants import EXCHANGE_SCREENER
from tradingview_mcp.docs_data import get_default_columns_for_market, STOCK_MARKETS
from tradingview_mcp.query import Query
from tradingview_mcp.utils import sanitize_market

# Common aliases for commodities/forex that don't match TV names
SYMBOL_ALIASES = {
    # Precious Metals
    "XAG": ["SILVER", "XAGUSD"],
    "XAU": ["GOLD", "XAUUSD"],
    "XPT": ["PLATINUM", "XPTUSD"],
    "XPD": ["PALLADIUM", "XPDUSD"],
    
    # Energy
    "OIL": ["USOIL", "UKOIL", "WTI", "BRENT"],
    "WTI": ["USOIL"],
    "BRENT": ["UKOIL"],
    "NATGAS": ["NG1!", "NATURALGAS"],
    
    # Others
    "COPPER": ["HG1!", "XCUUSD"],
}

def search_symbols(
    query: str,
    market: str = "america",
    limit: int = 25,
) -> dict[str, Any]:
    """
    Search symbols by name or ticker. Returns strict locator format for downstream tools.
    
    Output format includes 'locator': 'EXCHANGE:SYMBOL, market_name'.
    Use this locator to call get_technical_analysis() or other tools precisely.
    """
    market = sanitize_market(market)
    limit = max(1, min(limit, 100))
    
    # Use dynamic default columns for this market
    cols = get_default_columns_for_market(market)
    
    # Determine sort column
    sort_col = "market_cap_basic" if "market_cap_basic" in cols else "name"
    
    # Expand query with aliases if available
    queries = [query]
    if query.upper() in SYMBOL_ALIASES:
        queries.extend(SYMBOL_ALIASES[query.upper()])

    try:
        # Standard search in requested market
        # We start this async to allow parallel peeking
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
            future_main = executor.submit(_execute_search, queries, market, limit, cols, sort_col)
            
            # Smart Peek: Always check CFD/Forex/Crypto for EXACT matches or high relevance
            # This solves the "Silver" problem: "Silver" exists in America (Stocks), but user might want "SILVER" (CFD)
            # We don't want to wait for main search to fail (lazy fallback), we want to augment results.
            peek_markets = ["cfd", "crypto", "forex"]
            if market in peek_markets:
                 peek_markets.remove(market)
            
            future_peeks = []
            for pm in peek_markets:
                # For peeking, we only care about high relevance, so limit is small
                p_cols = get_default_columns_for_market(pm)
                p_sort = "name" # Sort by name match
                future_peeks.append(executor.submit(_execute_search, queries, pm, 5, p_cols, p_sort))
            
            # Gather Main Results
            results = future_main.result()
            
            # Gather Peek Results
            extra_matches = []
            for f in future_peeks:
                try:
                    res = f.result()
                    if res.get("results"):
                        extra_matches.extend(res["results"])
                except:
                    pass
        
        # Merge Logic
        # 1. Start with Main Results
        final_list = results.get("results", [])
        
        # 2. Inject Exact Matches from Peeks at the TOP
        #    (e.g. if query="Silver" and we found "SILVER" in CFD, put it first)
        high_priority = []
        low_priority = []
        
        query_upper = query.upper()
        
        for m in extra_matches:
            # Check for exact ticker/name match
            n = m.get("name", "").upper()
            tick = m.get("ticker", "").split(":")[-1].upper()
            
            if n == query_upper or tick == query_upper or f"{query_upper}USD" in n:
                high_priority.append(m)
            else:
                low_priority.append(m)
        
        # specific uniqueness check
        seen = {f"{r.get('exchange')}:{r.get('name')}" for r in final_list}
        
        merged = []
        # Add High Priority Peeks (if new)
        for r in high_priority:
            k = f"{r.get('exchange')}:{r.get('name')}"
            if k not in seen:
                merged.append(r)
                seen.add(k)
                
        # Add Main Results
        merged.extend(final_list)
        
        # Add Low Priority Peeks (only if we have space or main list is empty)
        # Actually, let's append them if main list is small, or specialized matching
        if not final_list:
             for r in low_priority:
                k = f"{r.get('exchange')}:{r.get('name')}"
                if k not in seen:
                    merged.append(r)
                    seen.add(k)
                    
        # Update results
        results["results"] = merged
        results["total_found"] = len(merged)
        results["returned"] = len(merged)
        
        # Fallback Logic (Only if truly empty)
        if not results["results"] and market == "america":
            
            # 1. Asian Numeric Heuristic
            if query.isdigit() and len(query) in [4, 5, 6]:
                # ... existing heuristic code ...
                asian_markets = ["taiwan", "hongkong", "japan", "china", "korea"]
                for asian_market in asian_markets:
                    asian_cols = get_default_columns_for_market(asian_market)
                    asian_sort = "volume"
                    asian_res = _execute_search(queries, asian_market, 5, asian_cols, asian_sort)
                    if asian_res["results"]:
                         return {**asian_res, "note": f"No results in 'america', using numeric heuristic for '{asian_market}'."}

            # 2. True Global Search
            try:
                global_cols = ["name", "description", "close", "change", "volume", "market_cap_basic", "exchange", "type"]
                q = (
                    Query()
                    .set_markets(*STOCK_MARKETS)
                    .select(*global_cols)
                    .where(Column("description").like(query))
                    .order_by("volume", ascending=False)
                    .limit(5)
                )
                _, df = q.get_scanner_data()
                
                if df.empty:
                     q = (
                        Query()
                        .set_markets(*STOCK_MARKETS)
                        .select(*global_cols)
                        .where(Column("name").like(query))
                        .order_by("volume", ascending=False)
                        .limit(5)
                     )
                     _, df = q.get_scanner_data()
                
                if not df.empty:
                     # Add locators for global results
                     records = df.to_dict("records")
                     for r in records:
                          _enrich_locator(r, "stock", query) 
                     
                     return {
                        "query": query,
                        "market": "global",
                        "total_found": len(df),
                        "returned": len(df),
                        "results": records,
                        "note": "Found matches in global stock markets."
                    }
            except Exception:
                pass

        return results
        
    except Exception as e:
        return _search_symbols_fallback(query, market, limit, cols, str(e))


def _enrich_locator(record: dict, market: str, category: str = "stock"):
    """Add standard locator string to a record."""
    ex = record.get("exchange", "UNKNOWN")
    name = record.get("name", "UNKNOWN")
    
    # Try to deduce market if 'stock' is generic
    # (This is hard without a map of Exchange->Country, but we do our best)
    
    # Construct Locator
    # Format: EXCHANGE:SYMBOL, Market
    record["locator"] = f"{ex}:{name}, {market}"
    record["market"] = market


def _execute_search(queries: list[str] | str, market: str, limit: int, cols: list[str], sort_col: str) -> dict[str, Any]:
    """Execute search, supporting multiple query terms (aliases)."""
    if isinstance(queries, str):
        queries = [queries]
        
    all_results = []
    
    # Try each query term until we get enough results
    for q_term in queries:
        if len(all_results) >= limit: break
        
        try:
            # 1. Search description
            q = (
                Query()
                .set_markets(market)
                .select(*cols)
                .where(Column("description").like(q_term))
                .order_by(sort_col, ascending=False)
                .limit(limit)
            )
            _, df = q.get_scanner_data()
            if not df.empty:
                 all_results.extend(df.to_dict("records"))
            
            # 2. Search name
            if len(all_results) < limit:
                q2 = (
                    Query()
                    .set_markets(market)
                    .select(*cols)
                    .where(Column("name").like(q_term))
                    .order_by(sort_col, ascending=False)
                    .limit(limit)
                )
                _, df2 = q2.get_scanner_data()
                if not df2.empty:
                     all_results.extend(df2.to_dict("records"))
        except:
            pass
            
    # Dedup
    unique = {r.get("name")+r.get("exchange"): r for r in all_results}
    results = list(unique.values())[:limit]
    
    # Enhance with locator
    for r in results:
        _enrich_locator(r, market)
    
    return {
        "query": queries[0], 
        "market": market,
        "total_found": len(results),
        "returned": len(results),
        "results": results,
    }


def _search_symbols_fallback(query: str, market: str, limit: int, cols: list[str], error: str) -> dict[str, Any]:
    return {"error": f"Search failed: {str(e)}", "original_error": error}


def get_symbol_info(symbol: str, include_technical: bool = False) -> dict[str, Any]:
    """
    Get detailed information for a symbol.
    Returns matches with strict locators: 'EXCHANGE:SYMBOL, Market'.
    """
    technical_cols = [
        "RSI", "RSI7", "MACD.macd", "MACD.signal", "SMA20", "SMA50", "SMA200", 
        "EMA20", "EMA50", "EMA200", "BB.upper", "BB.lower", "ATR", "ADX", 
        "Recommend.All", "Recommend.MA", "Recommend.Other"
    ]

    try:
        # --- Strict Mode (Exchange Specified) ---
        if ":" in symbol:
            exchange, ticker = symbol.split(":", 1)
            market = EXCHANGE_SCREENER.get(exchange.lower()) or "america"
            
            # Allow override via sanitized lookup? No, specific exchange implies specific market logic usually.
            # But let's be safe.
            
            cols = get_default_columns_for_market(market)
            if include_technical: cols.extend(technical_cols)
            cols = list(dict.fromkeys(cols))

            q = (
                Query()
                .set_markets(market)
                .select(*cols)
                .where(Column("name").isin([symbol, ticker, symbol.upper(), ticker.upper()]))
                .limit(5)
            )
            _, df = q.get_scanner_data()
            results = df.to_dict("records")
            
            if results:
                # Add strict locators
                for r in results:
                    _enrich_locator(r, market)
                    
                if len(results) == 1:
                    return {"symbol": symbol, "found": True, "market": market, "data": results[0]}
                return {"symbol": symbol, "found": True, "market": market, "matches": results}
            else:
                return {"symbol": symbol, "found": False, "hint": f"Symbol not found in {market} ({exchange}). Check format."}

        # --- Universal Mode (Implicit Market) ---
        all_matches = []
        
        # Targets
        targets = [symbol, symbol.upper(), f"{symbol}USDT", f"{symbol}USD"]
        if symbol.upper() in SYMBOL_ALIASES:
            targets.extend(SYMBOL_ALIASES[symbol.upper()])
        
        # Helper
        def run_search(market, col_getter):
             try:
                cols = col_getter(market)
                if include_technical: cols.extend(technical_cols)
                cols = list(dict.fromkeys(cols))
                
                # We need to set markets properly
                q = Query()
                if market == "global_stocks":
                    q.set_markets(*STOCK_MARKETS)
                else:
                    q.set_markets(market)
                
                q.select(*cols).where(Column("name").isin(targets))
                
                if market == "global_stocks":
                    q.order_by("market_cap_basic", ascending=False).limit(10)
                else:
                    q.limit(5)
                    
                _, df = q.get_scanner_data()
                if not df.empty:
                    matches = df.to_dict("records")
                    cat = "stock" if market == "global_stocks" else market
                    
                    # Fixup locator logic 
                    for m in matches: 
                        m["_category"] = cat
                        # If global stock, we don't know exact country easily without map.
                        # But for now we pass 'global_stocks' or try to guess?
                        # It's better to tell AI "taiwan" if possible.
                        # But we queried ALL markets. 
                        # HACK: We should query 'taiwan' explicitly if heuristics match?
                        # No, just return EXCHANGE:SYMBOL and let AI use 'search_symbols' if it needs precise market.
                        # Actually user wants "TWSE:0050, taiwan".
                        # If we used set_markets(*ALL), we lose the origin market info in the response unless we select 'market' column?
                        # TradingView API doesn't usually return 'market' column. It returns 'exchange'.
                        # We can map Exchange -> Market via EXCHANGE_SCREENER?
                        rec_market = EXCHANGE_SCREENER.get(m.get("exchange", "").lower(), cat)
                        _enrich_locator(m, rec_market)
                        
                    return matches
             except:
                 pass
             return []

        # Execute in parallel
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
            futures = [
                executor.submit(run_search, "global_stocks", lambda m: ["name", "description", "close", "change", "volume", "market_cap_basic", "exchange", "type"]),
                executor.submit(run_search, "crypto", get_default_columns_for_market),
                executor.submit(run_search, "forex", get_default_columns_for_market),
                executor.submit(run_search, "cfd", get_default_columns_for_market)
            ]
            for future in concurrent.futures.as_completed(futures):
                all_matches.extend(future.result())

        # --- Aggregate Results ---
        if not all_matches:
             return search_symbols(symbol, "america", 5)

        # Remove duplicates
        unique_matches = {}
        for m in all_matches:
            key = m.get("ticker", m.get("name"))
            if key not in unique_matches:
                unique_matches[key] = m
        
        final_matches = list(unique_matches.values())

        if len(final_matches) == 1:
            first = final_matches[0]
            cat = first.pop("_category", "global")
            return {"symbol": symbol, "found": True, "market": cat, "data": first}
        
        return {
            "symbol": symbol,
            "found": True, 
            "market": "global", 
            "count": len(final_matches),
            "matches": final_matches,
            "note": "Multiple matches found across global markets."
        }

    except Exception as e:
        return {
            "error": f"Failed to get symbol info: {str(e)}",
            "hint": "Try using search_symbols to find the correct symbol format",
        }
