from __future__ import annotations
from typing import Any

from tradingview_mcp.column import Column
from tradingview_mcp.constants import TECHNICAL_COLUMNS
from tradingview_mcp.query import Query
from tradingview_mcp.utils import sanitize_market

def get_technical_analysis(symbol: str, market: str) -> dict[str, Any]:
    """
    Get technical indicators for a symbol.
    
    IMPORTANT: You must use a strictly formatted symbol and market.
    1. Call `get_symbol_info(symbol)` first.
    2. Use the `locator` field from the response (e.g. "EXCHANGE:SYMBOL") and the exact `market`.
    3. Do NOT guess the market.
    """
    # Strict validation
    if ":" not in symbol:
        return {
            "error": "Ambiguous symbol format. Missing exchange prefix.",
            "hint": f"Please run get_symbol_info('{symbol}') first to find the correct 'EXCHANGE:{symbol}' locator and 'market'."
        }
    
    # Parse strictly formatted symbol
    exchange, ticker = symbol.split(":", 1)
    
    market = sanitize_market(market, strict=True)
    
    # Use standard technical columns
    cols = list(TECHNICAL_COLUMNS)
    
    try:
        q = (
            Query()
            .set_markets(market)
            .select(*cols)
            .where(Column("name").isin([ticker, ticker.upper()])) # Use ticker part for name lookup
            .limit(1)
        )

        _, df = q.get_scanner_data()
        
        if df.empty:
            # Check if user maybe used wrong market?
            # But we want to be strict.
            return {
                "error": f"Symbol '{symbol}' not found in market '{market}'.",
                "hint": "Ensure you are using the correct market from get_symbol_info()."
            }
            
        data = df.iloc[0].to_dict()
        return {
            "symbol": symbol,
            "market": market,
            "indicators": data
        }
    except Exception as e:
        return {"error": str(e)}

def scan_rsi_extremes(market: str = "america", limit: int = 25) -> dict[str, Any]:
    """Find symbols with extreme RSI values (<30 or >70)."""
    market = sanitize_market(market, strict=True)
    
    q = (
        Query()
        .set_markets(market)
        .select("name", "close", "RSI", "volume")
        # RSI > 70 OR RSI < 30. Note: Current Query builder supports AND by default.
        # For OR logic, we might need multiple queries or where2 if supported.
        # Let's simple check oversold first (<30)
        .where(Column("RSI") < 30)
        .order_by("RSI", ascending=True)
        .limit(limit)
    )
    
    try:
        _, df_oversold = q.get_scanner_data()
        oversold = df_oversold.to_dict("records")
        
        # Overbought
        q2 = (
            Query()
            .set_markets(market)
            .select("name", "close", "RSI", "volume")
            .where(Column("RSI") > 70)
            .order_by("RSI", ascending=False)
            .limit(limit)
        )
        _, df_overbought = q2.get_scanner_data()
        overbought = df_overbought.to_dict("records")
        
        return {
            "market": market,
            "oversold": oversold,
            "overbought": overbought
        }
    except Exception as e:
        return {"error": str(e)}

def scan_bollinger_bands(market: str = "america", limit: int = 25) -> dict[str, Any]:
    """Find symbols trading outside Bollinger Bands."""
    market = sanitize_market(market, strict=True)
    # This is complex to do with simple filters.
    # We'll just return basic BB values for top volume stocks.
    
    q = (
        Query()
        .set_markets(market)
        .select("name", "close", "BB.upper", "BB.lower")
        .order_by("volume", ascending=False)
        .limit(limit)
    )
    
    try:
        _, df = q.get_scanner_data()
        return {"data": df.to_dict("records")}
    except Exception as e:
        return {"error": str(e)}

def scan_macd_crossover(market: str = "america", limit: int = 25) -> dict[str, Any]:
    """scan for MACD crossovers."""
    market = sanitize_market(market, strict=True)
    q = (
        Query()
        .set_markets(market)
        .select("name", "close", "MACD.macd", "MACD.signal")
        .where(Column("MACD.macd") > Column("MACD.signal")) # Bullish crossoverish (simple comparison)
        .order_by("volume", ascending=False)
        .limit(limit)
    )
    try:
        _, df = q.get_scanner_data()
        return {"bullish_macd_momentum": df.to_dict("records")}
    except Exception as e:
        return {"error": str(e)}
