"""
Utility functions for TradingView MCP.

Provides helper functions for data processing, validation, and technical analysis.
"""

from __future__ import annotations

from typing import Any, Optional

from tradingview_mcp.constants import (
    ALLOWED_TIMEFRAMES,
    EXCHANGE_SCREENER,
    MARKETS,
    TIMEFRAME_MAP,
)


def sanitize_timeframe(tf: str | None, default: str = "15m") -> str:
    """
    Validate and sanitize a timeframe string.

    Args:
        tf: Timeframe to validate
        default: Default value if invalid

    Returns:
        Valid timeframe string
    """
    if not tf:
        return default
    tf = tf.strip()
    return tf if tf in ALLOWED_TIMEFRAMES else default


def sanitize_exchange(ex: str | None, default: str = "america") -> str:
    """
    Validate and sanitize an exchange name.

    Args:
        ex: Exchange to validate
        default: Default value if invalid

    Returns:
        Valid exchange/market string
    """
    if not ex:
        return default
    ex = ex.strip().lower()
    if ex in EXCHANGE_SCREENER:
        return ex
    if ex in MARKETS:
        return ex
    return default


# Country Code mappings
COUNTRY_ALIASES = {
    "us": "america",
    "usa": "america",
    "uk": "uk",
    "gb": "uk",
    "de": "germany",
    "fr": "france",
    "it": "italy",
    "es": "spain",
    "pt": "portugal",
    "ch": "switzerland",
    "se": "sweden",
    "no": "norway",
    "fi": "finland",
    "nl": "netherlands",
    "be": "belgium",
    "at": "austria",
    "ie": "ireland",
    "ru": "russia",
    "cn": "china",
    "jp": "japan",
    "kr": "korea",
    "in": "india",
    "id": "indonesia",
    "my": "malaysia",
    "th": "thailand",
    "vn": "vietnam",
    "tw": "taiwan",
    "sg": "singapore",
    "hk": "hongkong",
    "au": "australia",
    "nz": "newzealand",
    "ca": "canada",
    "br": "brazil",
    "mx": "mexico",
    "ar": "argentina",
    "cl": "chile",
    "co": "colombia",
    "pe": "peru",
    "eg": "egypt",
    "tr": "turkey",
    "za": "rsa", # South Africa
}

def sanitize_market(market: str | None, default: str = "america", strict: bool = False) -> str:
    """
    Validate and sanitize a market name.
    
    Args:
        market: Market to validate (e.g. 'america', 'tw', 'crypto')
        default: Default value if invalid (only used if strict=False)
        strict: If True, raise ValueError for invalid markets instead of returning default.

    Returns:
        Valid market string
        
    Raises:
        ValueError: If strict=True and market is invalid.
    """
    if not market:
        if strict:
            raise ValueError("Market parameter is required (e.g. 'america', 'taiwan').")
        return default
    
    market_clean = market.strip().lower()
    
    # Check exact match
    if market_clean in MARKETS:
        return market_clean
        
    # Check alias match
    if market_clean in COUNTRY_ALIASES:
        return COUNTRY_ALIASES[market_clean]
        
    # Check if user passed exchange (e.g. 'nasdaq') by mistake
    if market_clean in EXCHANGE_SCREENER:
        return EXCHANGE_SCREENER[market_clean]

    if strict:
        raise ValueError(f"Invalid market '{market}'. Please use a valid country code or name (e.g. 'america', 'taiwan', 'crypto').")

    return default


def timeframe_to_resolution(tf: str) -> str:
    """
    Convert timeframe to TradingView API resolution.

    Args:
        tf: Timeframe string (e.g., '15m', '1h', '4h', '1D')

    Returns:
        TradingView resolution string
    """
    return TIMEFRAME_MAP.get(tf, tf)


def get_screener_for_exchange(exchange: str) -> str:
    """
    Get the screener market for an exchange.

    Args:
        exchange: Exchange name (e.g., 'binance', 'nasdaq')

    Returns:
        Screener market (e.g., 'crypto', 'america')
    """
    return EXCHANGE_SCREENER.get(exchange.lower(), "america")


def format_technical_rating(rating: float) -> str:
    """
    Convert numeric technical rating to human-readable format.

    Args:
        rating: Rating value (-1 to 1)

    Returns:
        Rating label (Strong Buy, Buy, Neutral, Sell, Strong Sell)
    """
    if rating >= 0.5:
        return "Strong Buy"
    elif rating >= 0.1:
        return "Buy"
    elif rating >= -0.1:
        return "Neutral"
    elif rating >= -0.5:
        return "Sell"
    else:
        return "Strong Sell"


def compute_percent_change(open_price: float, close_price: float) -> float:
    """
    Calculate percentage change.

    Args:
        open_price: Starting price
        close_price: Ending price

    Returns:
        Percentage change
    """
    if not open_price or open_price == 0:
        return 0.0
    return ((close_price - open_price) / open_price) * 100


def compute_bollinger_band_width(sma: float, bb_upper: float, bb_lower: float) -> Optional[float]:
    """
    Calculate Bollinger Band Width (BBW).

    BBW = (Upper Band - Lower Band) / SMA20

    Args:
        sma: SMA20 (middle band)
        bb_upper: Upper Bollinger Band
        bb_lower: Lower Bollinger Band

    Returns:
        BBW value or None if calculation fails
    """
    if not sma or sma == 0:
        return None
    try:
        return (bb_upper - bb_lower) / sma
    except (TypeError, ZeroDivisionError):
        return None


def compute_bollinger_rating(
    close: float, bb_upper: float, bb_middle: float, bb_lower: float
) -> tuple[int, str]:
    """
    Calculate Bollinger Band position rating and signal.

    Rating scale:
    - +3: Price above upper band (Strong overbought)
    - +2: Price in upper half above middle (Overbought)
    - +1: Price slightly above middle (Weak bullish)
    - -1: Price slightly below middle (Weak bearish)
    - -2: Price in lower half below middle (Oversold)
    - -3: Price below lower band (Strong oversold)

    Args:
        close: Current price
        bb_upper: Upper band
        bb_middle: Middle band (SMA20)
        bb_lower: Lower band

    Returns:
        Tuple of (rating, signal)
    """
    rating = 0
    signal = "NEUTRAL"

    if close > bb_upper:
        rating = 3
        signal = "STRONG_OVERBOUGHT"
    elif close > bb_middle + ((bb_upper - bb_middle) / 2):
        rating = 2
        signal = "BUY"
    elif close > bb_middle:
        rating = 1
        signal = "WEAK_BUY"
    elif close < bb_lower:
        rating = -3
        signal = "STRONG_OVERSOLD"
    elif close < bb_middle - ((bb_middle - bb_lower) / 2):
        rating = -2
        signal = "SELL"
    elif close < bb_middle:
        rating = -1
        signal = "WEAK_SELL"

    return rating, signal


def compute_rsi_signal(rsi: float) -> str:
    """
    Determine RSI signal.

    Args:
        rsi: RSI value (0-100)

    Returns:
        Signal string
    """
    if rsi >= 80:
        return "EXTREMELY_OVERBOUGHT"
    elif rsi >= 70:
        return "OVERBOUGHT"
    elif rsi >= 60:
        return "BULLISH"
    elif rsi <= 20:
        return "EXTREMELY_OVERSOLD"
    elif rsi <= 30:
        return "OVERSOLD"
    elif rsi <= 40:
        return "BEARISH"
    else:
        return "NEUTRAL"


def compute_macd_signal(macd: float, signal: float) -> str:
    """
    Determine MACD signal.

    Args:
        macd: MACD line value
        signal: Signal line value

    Returns:
        Signal string
    """
    diff = macd - signal
    if diff > 0:
        if macd > 0:
            return "STRONG_BULLISH"
        return "BULLISH"
    elif diff < 0:
        if macd < 0:
            return "STRONG_BEARISH"
        return "BEARISH"
    return "NEUTRAL"


def analyze_indicators(indicators: dict[str, Any]) -> dict[str, Any]:
    """
    Perform comprehensive technical analysis on indicator data.

    Args:
        indicators: Dictionary of indicator values

    Returns:
        Analysis results with signals and ratings
    """
    result: dict[str, Any] = {"signals": [], "rating": 0, "recommendation": "NEUTRAL"}

    # Extract values
    close = indicators.get("close", 0)
    open_price = indicators.get("open", 0)
    high = indicators.get("high", 0)
    low = indicators.get("low", 0)
    volume = indicators.get("volume", 0)
    rsi = indicators.get("RSI", 50)
    macd = indicators.get("MACD.macd", 0)
    macd_signal = indicators.get("MACD.signal", 0)
    bb_upper = indicators.get("BB.upper", 0)
    bb_lower = indicators.get("BB.lower", 0)
    sma20 = indicators.get("SMA20", close)
    ema50 = indicators.get("EMA50", close)
    ema200 = indicators.get("EMA200", close)
    adx = indicators.get("ADX", 0)

    # Price change
    if open_price and close:
        change = compute_percent_change(open_price, close)
        result["change_percent"] = round(change, 2)

    # RSI Analysis
    if rsi:
        rsi_signal = compute_rsi_signal(rsi)
        result["rsi_signal"] = rsi_signal
        if "OVERBOUGHT" in rsi_signal:
            result["signals"].append(f"RSI Overbought ({rsi:.1f})")
            result["rating"] -= 1
        elif "OVERSOLD" in rsi_signal:
            result["signals"].append(f"RSI Oversold ({rsi:.1f})")
            result["rating"] += 1

    # MACD Analysis
    if macd and macd_signal:
        macd_sig = compute_macd_signal(macd, macd_signal)
        result["macd_signal"] = macd_sig
        if "BULLISH" in macd_sig:
            result["signals"].append(f"MACD Bullish")
            result["rating"] += 1
        elif "BEARISH" in macd_sig:
            result["signals"].append(f"MACD Bearish")
            result["rating"] -= 1

    # Bollinger Band Analysis
    if bb_upper and bb_lower and sma20 and close:
        bb_rating, bb_signal = compute_bollinger_rating(close, bb_upper, sma20, bb_lower)
        bbw = compute_bollinger_band_width(sma20, bb_upper, bb_lower)
        result["bb_rating"] = bb_rating
        result["bb_signal"] = bb_signal
        result["bbw"] = round(bbw, 4) if bbw else None

        if bb_rating >= 2:
            result["signals"].append("Price near/above upper BB")
            result["rating"] -= 1
        elif bb_rating <= -2:
            result["signals"].append("Price near/below lower BB")
            result["rating"] += 1

        if bbw and bbw < 0.02:
            result["signals"].append("BB Squeeze (low volatility)")

    # Moving Average Analysis
    if close and sma20 and ema50 and ema200:
        if close > sma20 > ema50 > ema200:
            result["signals"].append("Strong uptrend (above all MAs)")
            result["rating"] += 2
        elif close < sma20 < ema50 < ema200:
            result["signals"].append("Strong downtrend (below all MAs)")
            result["rating"] -= 2
        elif close > ema200:
            result["signals"].append("Above EMA200 (long-term bullish)")
            result["rating"] += 1
        elif close < ema200:
            result["signals"].append("Below EMA200 (long-term bearish)")
            result["rating"] -= 1

    # ADX Trend Strength
    if adx:
        if adx > 50:
            result["signals"].append(f"Very strong trend (ADX: {adx:.1f})")
        elif adx > 25:
            result["signals"].append(f"Trending market (ADX: {adx:.1f})")
        else:
            result["signals"].append(f"Ranging/weak trend (ADX: {adx:.1f})")

    # Final recommendation
    if result["rating"] >= 3:
        result["recommendation"] = "STRONG_BUY"
    elif result["rating"] >= 1:
        result["recommendation"] = "BUY"
    elif result["rating"] <= -3:
        result["recommendation"] = "STRONG_SELL"
    elif result["rating"] <= -1:
        result["recommendation"] = "SELL"
    else:
        result["recommendation"] = "NEUTRAL"

    return result


def format_symbol(symbol: str, exchange: str) -> str:
    """
    Format a symbol with exchange prefix if needed.

    Args:
        symbol: Symbol (e.g., 'BTCUSDT' or 'BINANCE:BTCUSDT')
        exchange: Exchange name

    Returns:
        Formatted symbol (e.g., 'BINANCE:BTCUSDT')
    """
    if ":" in symbol:
        return symbol.upper()
    return f"{exchange.upper()}:{symbol.upper()}"
