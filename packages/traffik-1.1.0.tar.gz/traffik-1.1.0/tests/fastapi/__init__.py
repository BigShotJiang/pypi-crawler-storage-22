"""FastAPI related tests."""
