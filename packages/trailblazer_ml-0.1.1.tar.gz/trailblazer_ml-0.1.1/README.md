# ScoutML 🚀

Uma biblioteca de AutoML "Glass-Box" focada em exploração, limpeza e geração de código transparente.

## Instalação

```bash
pip install scoutml