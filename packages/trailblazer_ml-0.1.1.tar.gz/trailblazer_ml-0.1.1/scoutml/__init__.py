"""
ScoutML: Exploratory AutoML & Code Synthesis Library.
Version: 0.1.0-alpha
"""

import logging
import sys

# Configuração de Logging para o Usuário
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - [ScoutML] - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)

logger = logging.getLogger("scoutml")

# Expondo classes principais para acesso fácil
from .preprocessing import AutoCleaner, SmartImputer, AdaptiveEncoder
from .analysis import InsightEngine
from .transpiler import CodeSynthesizer

__all__ = [
    "AutoCleaner",
    "SmartImputer",
    "AdaptiveEncoder",
    "InsightEngine",
    "CodeSynthesizer",
]
