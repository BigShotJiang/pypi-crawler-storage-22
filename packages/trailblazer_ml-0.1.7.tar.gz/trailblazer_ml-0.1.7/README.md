# ScoutML: Enterprise AutoML & Audit Framework

**Versão:** 2.1.0  
**Foco:** Governança, Auditabilidade e Robustez

O **ScoutML** não é apenas mais um framework de AutoML. Ele foi desenhado para ambientes regulados e críticos (Crédito, Fraude, Seguros, Saúde), onde explicar **por que** um modelo tomou uma decisão é tão importante quanto a sua performance.

Diferente de outras ferramentas do tipo *caixa-preta*, o ScoutML gera um **Relatório de Auditoria Completo** (Markdown + Gráficos) detalhando cada decisão estatística tomada, desde a limpeza de dados até a validação de estabilidade (PSI/KS).

---

## Principais Diferenciais (v2.1)

### 1. Scout v2 (O Analista Estatístico)

Antes de treinar, o Scout realiza uma varredura profunda nos dados:

- **Detecção de Leakage:**  
  Usa um modelo "Sentinela" para identificar variáveis que contêm a resposta (vazamento de dados) e remove-as automaticamente.
- **Perfilamento Estatístico:**  
  Calcula *Skewness* (assimetria), *Kurtosis* e *Outliers* (via IQR) para guiar o pré-processamento.
- **Higiene de Dados:**  
  Remove identificadores (IDs), colunas constantes e multicolinearidade excessiva.

---

### 2. Forge v2 (O Engenheiro Inteligente)

Constrói pipelines de **scikit-learn** dinamicamente, baseados no diagnóstico do Scout:

- **Tratamento de Outliers:**  
  Aplica `RobustScaler` automaticamente se detectar mais de 5% de outliers.
- **Normalização:**  
  Aplica `PowerTransformer` (Yeo-Johnson) em distribuições enviesadas.
- **Encoding Inteligente:**  
  Alterna entre `OneHotEncoder` (baixa cardinalidade) e `TargetEncoder` (alta cardinalidade) para evitar explosão dimensional.

---

### 3. Auditoria de Risco & Estabilidade

Para problemas de classificação, o ScoutML gera métricas padrão de mercado financeiro:

- **KS (Kolmogorov-Smirnov):**  
  Mede a separação entre classes.
- **PSI (Population Stability Index):**  
  Garante que o modelo não está degradado entre Treino e Teste.
- **Matriz de Confusão:**  
  Visualização clara de Falsos Positivos e Falsos Negativos.

---

## Instalação

O ScoutML depende de bibliotecas robustas de Data Science.

1. Crie um arquivo `requirements.txt` (veja a seção abaixo).
2. Instale as dependências:

```bash
pip install -r requirements.txt
