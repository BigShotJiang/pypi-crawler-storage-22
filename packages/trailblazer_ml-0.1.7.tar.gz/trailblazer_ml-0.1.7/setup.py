from setuptools import setup, find_packages
import pathlib

# O diretório onde este arquivo está
here = pathlib.Path(__file__).parent.resolve()

# Lê o README para usar como descrição longa no PyPI
long_description = (here / "README.md").read_text(encoding="utf-8")

setup(
    name="trailblazer-ml",  # O nome que será usado no pip install
    version="0.1.7",
    description="Uma biblioteca de AutoML Exploratório e 'Glass-Box'.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/gabsalles/trailblazer-ml",  # Coloque seu GitHub aqui
    author="Gabriel Sales",
    author_email="ggcs10@gmail.com",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
    keywords="automl, data-science, preprocessing, cleaning",
    packages=find_packages(),
    python_requires=">=3.8, <4",
    install_requires=[
        "numpy",
        "pandas",
        "scipy",
        "scikit-learn",
        "optuna",
        "shap",
        "joblib",
        "matplotlib",
        "seaborn",
        "tabulate",
        "lightgbm",
        "xgboost",
    ],
    extras_require={
        "gpu": ["torch"]  # Quem quiser GPU instala: pip install scoutml[gpu]
    },
)
