"""TrainTrack Client Package."""

from pkgutil import extend_path

__path__ = extend_path(__path__, __name__)

from .client.hook import TrainTrackHook, DatasetConfig, MetricConfig, CategoryConfig
from .client.hf_callback import TrainTrackCallback
from .client.sender import TrainTrackSender
from .client.ddp import is_rank0, safe_barrier, is_distributed
from .datasets import list_categories, get_category_config
from .utils import get_logger

__version__ = "0.1.0"

__all__ = [
    "TrainTrackHook",
    "TrainTrackCallback",
    "DatasetConfig",
    "MetricConfig",
    "CategoryConfig",
    "TrainTrackSender",
    "is_rank0",
    "safe_barrier",
    "is_distributed",
    "list_categories",
    "get_category_config",
    "get_logger",
]
