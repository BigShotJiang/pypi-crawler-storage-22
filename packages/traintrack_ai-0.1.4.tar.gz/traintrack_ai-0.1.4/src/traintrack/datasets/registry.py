"""Registry of built-in datasets."""

from __future__ import annotations

from pathlib import Path

import sys

if sys.version_info >= (3, 9):
    from importlib import resources
else:
    import importlib_resources as resources

# Available builtin datasets
BUILTIN_DATASETS = [
    "reasoning",
    "conciseness",
    "helpfulness",
    "hallucination_risk",
    # Comprehensive evaluation datasets from HuggingFace
    "gpqa_diamond",
    "mmlu_pro",
    "truthfulqa",
]

# Default configurations for builtin datasets
BUILTIN_DEFAULTS = {
    "reasoning": {
        "metrics": ["logical_correctness", "step_by_step"],
        "judge_modes": ["criteria"],
    },
    "conciseness": {
        "metrics": ["conciseness", "clarity"],
        "judge_modes": ["criteria"],
    },
    "helpfulness": {
        "metrics": ["helpfulness", "politeness"],
        "judge_modes": ["criteria"],
    },
    "hallucination_risk": {
        "metrics": ["factual_accuracy", "citation_accuracy"],
        "judge_modes": ["criteria"],
    },
    "gpqa_diamond": {
        "metrics": ["correctness", "reasoning_quality"],
        "judge_modes": ["criteria"],
        "description": "Graduate-level science questions (Physics, Chemistry, Biology)",
    },
    "mmlu_pro": {
        "metrics": ["correctness", "reasoning_quality"],
        "judge_modes": ["criteria"],
        "description": "Professional-level multi-domain questions (STEM, humanities, social sciences)",
    },
    "truthfulqa": {
        "metrics": ["factual_accuracy", "helpfulness"],
        "judge_modes": ["criteria"],
        "description": "Adversarial questions to check for common misconceptions",
    },
}


def get_builtin_path(name: str) -> Path:
    """Get path to a built-in dataset."""
    if name not in BUILTIN_DATASETS:
        raise ValueError(
            f"Unknown builtin dataset: {name}. Available: {BUILTIN_DATASETS}"
        )

    # 1. Try to find in the 'eval' subdirectory first (comprehensive benchmarks)
    try:
        eval_path = resources.files("traintrack.datasets.builtin.eval").joinpath(
            f"{name}.jsonl"
        )
        if eval_path.is_file():
            return Path(str(eval_path))
    except (ImportError, ModuleNotFoundError, AttributeError):
        pass

    # 2. Fallback to the main builtin directory
    source_path = resources.files("traintrack.datasets.builtin").joinpath(
        f"{name}.jsonl"
    )
    return Path(str(source_path))


def get_builtin_defaults(name: str) -> dict:
    """Get default configuration for a built-in dataset."""
    return BUILTIN_DEFAULTS.get(name, {})


def list_builtin_datasets() -> list[str]:
    """List available built-in datasets."""
    return BUILTIN_DATASETS.copy()
