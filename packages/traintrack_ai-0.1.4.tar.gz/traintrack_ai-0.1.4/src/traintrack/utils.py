"""Shared utilities for traintrack."""

import logging
import os
from datetime import datetime, timezone


def get_logger(name: str) -> logging.Logger:
    """Get a configured logger."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(
            logging.Formatter(
                "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
            )
        )
        logger.addHandler(handler)
        logger.setLevel(
            getattr(logging, os.environ.get("TRAINTRACK_LOG_LEVEL", "INFO"))
        )
    return logger


def utc_now() -> datetime:
    """Get current UTC time."""
    return datetime.now(timezone.utc)


def utc_now_iso() -> str:
    """Get current UTC time as ISO string."""
    return utc_now().isoformat()
