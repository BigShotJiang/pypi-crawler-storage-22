from .utils import apply_patches
apply_patches() # 确保补丁在导入时应用

from .model import mae_vit_base_patch16, MaskedAutoencoderViT
from .dataset import PhysicsDataset
from .synth import advanced_physics_synth