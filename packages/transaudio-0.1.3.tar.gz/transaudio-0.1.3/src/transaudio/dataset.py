import torch
import torch.utils.data
import torchaudio
import numpy as np
from .synth import advanced_physics_synth

class PhysicsDataset(torch.utils.data.Dataset):
    def __init__(self, epoch_len=5000, target_length=1024):
        self.epoch_len = epoch_len
        self.target_length = target_length

    def __len__(self):
        return self.epoch_len

    def __getitem__(self, idx):
        # Generate random F0
        f0 = np.random.uniform(50.0, 2000.0)
        waveform = advanced_physics_synth(f0)

        # To Mel Spectrogram
        waveform = waveform.unsqueeze(0)
        fbank = torchaudio.compliance.kaldi.fbank(
            waveform, htk_compat=True, sample_frequency=16000, use_energy=False,
            window_type='hanning', num_mel_bins=128, dither=0.0, frame_shift=10
        )

        n_frames = fbank.shape[0]
        p = self.target_length - n_frames
        if p > 0:
            m = torch.nn.ZeroPad2d((0, 0, 0, p))
            fbank = m(fbank)
        elif p < 0:
            fbank = fbank[:self.target_length, :]

        # Normalization (as per paper/code)
        fbank = (fbank - (-4.26)) / (4.56 * 2)

        return fbank.unsqueeze(0), torch.tensor(0)