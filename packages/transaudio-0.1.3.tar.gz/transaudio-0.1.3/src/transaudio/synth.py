import random
import numpy as np
import torch
import torchaudio.functional as F

def advanced_physics_synth(f0_hz, duration=10.24, sample_rate=16000):
    """
    Advanced Physics-based Synthesizer v2.0
    Generates audio based on first principles: Additive, FM, Pulse, ADSR, etc.
    """
    t = np.arange(duration * sample_rate) / sample_rate
    num_samples = len(t)
    
    # Random Synthesis Mode
    synth_mode = random.choice(['additive', 'fm', 'pulse'])
    
    if synth_mode == 'additive':
        harmonics_count = random.randint(3, 15)
        waveform = np.zeros_like(t)
        for i in range(harmonics_count):
            strength = (1.0 / (i + 1)**random.uniform(0.5, 1.5)) * random.uniform(0.5, 1.2)
            phase = random.uniform(0, 2*np.pi)
            freq = f0_hz * (i + 1) * random.uniform(0.995, 1.005)
            waveform += strength * np.sin(2 * np.pi * freq * t + phase)
            
    elif synth_mode == 'fm':
        mod_index = random.uniform(0.5, 8.0)
        mod_ratio = random.choice([0.5, 1.0, 1.5, 2.0, 2.5, 3.14])
        mod_freq = f0_hz * mod_ratio
        modulator = mod_index * np.sin(2 * np.pi * mod_freq * t)
        waveform = np.sin(2 * np.pi * f0_hz * t + modulator)
        
    else: # Pulse/Saw
        if random.random() > 0.5:
            waveform = 2.0 * (t * f0_hz - np.floor(t * f0_hz + 0.5))
        else:
            waveform = np.sign(np.sin(2 * np.pi * f0_hz * t))

    # --- 1. Burst/Transient ---
    if random.random() > 0.4:
        burst_len = int(random.uniform(0.01, 0.1) * sample_rate)
        if burst_len < num_samples:
            start_idx = random.randint(0, num_samples - burst_len)
            burst = (np.random.rand(burst_len) * 2 - 1)
            waveform[start_idx:start_idx+burst_len] += burst * random.uniform(0.5, 2.0)

    # --- 2. ADSR Envelopes ---
    num_events = random.randint(1, 5)
    final_waveform = np.zeros_like(t)
    
    for _ in range(num_events):
        event_len_sec = random.uniform(0.5, duration/num_events)
        event_len = int(event_len_sec * sample_rate)
        if event_len > num_samples: event_len = num_samples
        
        attack = int(event_len * random.uniform(0.01, 0.3))
        decay = int(event_len * random.uniform(0.1, 0.4))
        sustain_len = max(0, event_len - attack - decay)
        
        env = np.ones(event_len)
        env[:attack] = np.linspace(0, 1, attack)
        env[attack:attack+decay] = np.linspace(1, 0.6, decay)
        env[attack+decay:] = np.linspace(0.6, 0, sustain_len)
        
        start_pos = random.randint(0, num_samples - event_len)
        segment = waveform[start_pos:start_pos+event_len] * env
        
        place_pos = random.randint(0, num_samples - event_len)
        final_waveform[place_pos:place_pos+event_len] += segment

    waveform = final_waveform

    # --- 3. Filter (Resonance) ---
    waveform_tensor = torch.from_numpy(waveform).float().view(1, -1)
    if random.random() > 0.3:
        cutoff = random.uniform(200, 6000)
        waveform_tensor = F.lowpass_biquad(waveform_tensor, sample_rate, cutoff_freq=cutoff)

    # --- 4. Background Noise ---
    noise = (torch.rand(1, num_samples) * 2 - 1) * random.uniform(0.001, 0.02)
    waveform_tensor += noise

    # Norm
    if waveform_tensor.abs().max() > 0:
        waveform_tensor /= waveform_tensor.abs().max()
        
    return waveform_tensor.squeeze(0)