import argparse
import torch
import torch.optim as optim
from tqdm import tqdm
from .model import mae_vit_base_patch16
from .dataset import PhysicsDataset

def main():
    parser = argparse.ArgumentParser(description="TransAudio: Pre-training AudioMAE with Physics Synthesis")
    parser.add_argument('--epochs', type=int, default=100, help='Number of epochs')
    parser.add_argument('--batch_size', type=int, default=16, help='Batch size')
    parser.add_argument('--lr', type=float, default=1e-4, help='Learning rate')
    parser.add_argument('--save_path', type=str, default='mae_advanced_synth_final.pth', help='Path to save model')
    parser.add_argument('--epoch_len', type=int, default=5000, help='Samples per epoch')
    
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"🚀 Pre-training with Advanced Physics Synth on {device}")
    
    dataset = PhysicsDataset(epoch_len=args.epoch_len)
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=args.batch_size, num_workers=4) 

    print("🏗️ Building AudioMAE Model...")
    model = mae_vit_base_patch16(norm_pix_loss=True, audio_exp=True, in_chans=1, img_size=(1024, 128))
    model.to(device)
    
    optimizer = optim.AdamW(model.parameters(), lr=args.lr, betas=(0.9, 0.95), weight_decay=0.05)
    scaler = torch.cuda.amp.GradScaler() 

    print(f"🔥 Starting Training for {args.epochs} Epochs...")
    
    model.train()
    for epoch in range(args.epochs):
        total_loss = 0
        pbar = tqdm(dataloader, desc=f"Epoch {epoch + 1}/{args.epochs}")

        for batch in pbar:
            images, _ = batch
            images = images.to(device)

            optimizer.zero_grad()
            with torch.cuda.amp.autocast():
                loss, _, _ = model(images, mask_ratio=0.75) 
            
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            total_loss += loss.item()
            pbar.set_postfix({'loss': f"{loss.item():.4f}"})

        avg_loss = total_loss / len(dataloader)
        print(f"✅ Epoch {epoch + 1} Done. Loss: {avg_loss:.4f}")
        
        if (epoch + 1) % 10 == 0:
            save_name = f"mae_advanced_synth_ep{epoch+1}.pth"
            torch.save(model.state_dict(), save_name)

    torch.save(model.state_dict(), args.save_path)
    print(f"💾 Training Finished! Saved to {args.save_path}")

if __name__ == '__main__':
    main()