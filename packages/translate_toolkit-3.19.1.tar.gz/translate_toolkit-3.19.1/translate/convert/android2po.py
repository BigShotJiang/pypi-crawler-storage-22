#
# Copyright 2023 Zuza Software Foundation and Jordi Mas i Hernàndez
#
# This file is part of translate.
#
# translate is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# translate is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, see <http://www.gnu.org/licenses/>.

"""
Convert Android string files to Gettext PO localization files.

See: http://docs.translatehouse.org/projects/translate-toolkit/en/latest/commands/android2po.html
for examples and usage instructions.
"""

import logging

from translate.convert import convert
from translate.storage import aresource, po

logger = logging.getLogger(__name__)


class android2po:
    """Convert a Android resource file to a PO file."""

    def convert_store(self, input_store, duplicatestyle="msgctxt"):
        output_store = po.pofile()
        output_header = output_store.header()
        output_header.addnote(f"extracted from {input_store.filename}", "developer")
        for input_unit in input_store.units:
            output_unit = self.convert_unit(input_unit)
            if output_unit is not None:
                output_store.addunit(output_unit)
        output_store.removeduplicates(duplicatestyle)
        return output_store

    def merge_store(
        self, template_store, input_store, blankmsgstr=False, duplicatestyle="msgctxt"
    ):
        """Converts two Android resource files to a PO file."""
        output_store = po.pofile()
        output_header = output_store.header()
        output_header.addnote(
            f"extracted from {template_store.filename}, {input_store.filename}",
            "developer",
        )

        input_store.makeindex()
        for template_unit in template_store.units:
            origpo = self.convert_unit(template_unit)

            template_unit_name = template_unit.getid()
            if template_unit_name in input_store.id_index:
                translatedxml = input_store.id_index[template_unit_name]
                translatedpo = self.convert_unit(translatedxml)
            else:
                translatedpo = None
            # if we have a valid po unit, get the translation and add it...
            if origpo is not None:
                if translatedpo is not None and not blankmsgstr:
                    origpo.target = translatedpo.source
                output_store.addunit(origpo)
            elif translatedpo is not None:
                logger.error(
                    "error converting original Android resource definition %s",
                    origpo.name,
                )
        output_store.removeduplicates(duplicatestyle)
        return output_store

    @staticmethod
    def convert_unit(input_unit):
        """
        Converts a Android resource unit to a PO unit.

        :return: None if empty or not for translation
        """
        if input_unit is None:
            return None
        # escape unicode
        output_unit = po.pounit(encoding="UTF-8")
        output_unit.addlocation(input_unit.getid())
        output_unit.source = input_unit.source
        output_unit.target = ""
        return output_unit


def _convertandroid(
    input_file,
    template_file,
    pot=False,
    duplicatestyle="msgctxt",
):
    input_store = aresource.AndroidResourceFile(input_file)
    convertor = android2po()
    if template_file is None:
        output_store = convertor.convert_store(
            input_store, duplicatestyle=duplicatestyle
        )
    else:
        template_store = aresource.AndroidResourceFile(template_file)
        output_store = convertor.merge_store(
            template_store, input_store, blankmsgstr=pot, duplicatestyle=duplicatestyle
        )

    return output_store


def convertandroid(
    input_file,
    output_file,
    template_file,
    pot=False,
    duplicatestyle="msgctxt",
) -> int:
    """
    Reads in *input_file* using aresource, converts using :class:`android2po`,
    writes to *output_file*.
    """
    output_store = _convertandroid(input_file, template_file, pot, duplicatestyle)
    output_store.serialize(output_file)
    return 1


def main(argv=None) -> None:
    formats = {
        "xml": ("po", convertandroid),
        ("xml", "xml"): ("po", convertandroid),
    }
    parser = convert.ConvertOptionParser(
        formats, usetemplates=True, usepots=False, description=__doc__
    )
    parser.add_duplicates_option()
    parser.run(argv)


if __name__ == "__main__":
    main()
