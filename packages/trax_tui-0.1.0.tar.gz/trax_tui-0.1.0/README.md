# tt

TrackingTime CLI tool

## Installation

Requires a keyring backend.
