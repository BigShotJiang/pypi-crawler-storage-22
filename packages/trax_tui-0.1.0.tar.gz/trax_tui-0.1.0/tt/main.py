import re
from datetime import datetime, timedelta

import typer
import keyring
import keyring.errors
import httpx

app = typer.Typer(help="TrackingTime CLI")

SERVICE_NAME = "tt-trackingtime"
API_BASE = "https://api.trackingtime.co/api/v4"


USER_AGENT = "tt-cli (https://codeberg.org/jax/tt)"


def parse_duration(s: str) -> int:
    """Parse duration string like '2h', '2h30m', '90m' to seconds."""
    total = 0
    for match in re.finditer(r"(\d+)\s*(h|m|s)?", s.lower()):
        val, unit = int(match.group(1)), match.group(2) or "m"
        if unit == "h":
            total += val * 3600
        elif unit == "m":
            total += val * 60
        else:
            total += val
    return total


def get_timezone_str() -> str:
    """Get local timezone in GMT+00 format."""
    now = datetime.now().astimezone()
    offset = now.utcoffset()
    if offset is None:
        return "GMT+00"
    hours = int(offset.total_seconds() // 3600)
    sign = "+" if hours >= 0 else ""
    return f"GMT{sign}{hours:02d}"


def get_credentials() -> tuple[str, str] | None:
    username = keyring.get_password(SERVICE_NAME, "username")
    password = keyring.get_password(SERVICE_NAME, "password")
    if username and password:
        return username, password
    return None


def get_client() -> httpx.Client:
    creds = get_credentials()
    if not creds:
        typer.echo("Not logged in. Run 'tt login' first.", err=True)
        raise typer.Exit(1)
    username, password = creds
    return httpx.Client(
        base_url=API_BASE,
        auth=(username, password),
        headers={"User-Agent": USER_AGENT},
    )


@app.command()
def login():
    username = typer.prompt("Username (email)")
    password = typer.prompt("Password", hide_input=True)

    keyring.set_password(SERVICE_NAME, "username", username)
    keyring.set_password(SERVICE_NAME, "password", password)

    typer.echo("Credentials saved.")


@app.command()
def logout():
    try:
        keyring.delete_password(SERVICE_NAME, "username")
        keyring.delete_password(SERVICE_NAME, "password")
        typer.echo("Credentials removed.")
    except keyring.errors.PasswordDeleteError:
        typer.echo("No credentials found.")


@app.command()
def projects():
    with get_client() as client:
        resp = client.get("/projects")
        resp.raise_for_status()
        body = resp.json()

        if body.get("response", {}).get("status") != 200:
            typer.echo(f"API error: {body.get('response', {}).get('message')}", err=True)
            raise typer.Exit(1)

        project_list = body.get("data", [])

        if not project_list:
            typer.echo("No projects found.")
            return

        for proj in project_list:
            name = proj.get("name", "Unknown")
            proj_id = proj.get("id", "?")
            typer.echo(f"[{proj_id}] {name}")


@app.command()
def tasks(project_id: int):
    with get_client() as client:
        resp = client.get(f"/projects/{project_id}/min", params={"include_tasks": "true"})
        resp.raise_for_status()
        body = resp.json()

        if body.get("response", {}).get("status") != 200:
            typer.echo(f"API error: {body.get('response', {}).get('message')}", err=True)
            raise typer.Exit(1)

        project_data = body.get("data", {})
        task_list = [t for t in project_data.get("tasks", []) if not t.get("is_archived")]

        if not task_list:
            typer.echo("No tasks found.")
            return

        for task in task_list:
            name = task.get("name", "Unknown")
            task_id = task.get("id", "?")
            tracking = "*" if task.get("tracking") else " "
            typer.echo(f"{tracking}[{task_id}] {name}")


@app.command()
def events(
    from_date: str = "",
    to_date: str = "",
    project_id: int | None = None,
    debug: bool = False,
):
    """List events. Defaults to current week."""
    if not from_date:
        today = datetime.now()
        start = today - timedelta(days=today.weekday())
        from_date = start.strftime("%Y-%m-%d")
    if not to_date:
        to_date = datetime.now().strftime("%Y-%m-%d")

    params = {"from": from_date, "to": to_date}
    if project_id:
        params["filter"] = "PROJECT"
        params["id"] = str(project_id)

    with get_client() as client:
        resp = client.get("/events", params=params)
        resp.raise_for_status()
        body = resp.json()

        if body.get("response", {}).get("status") != 200:
            typer.echo(f"API error: {body.get('response', {}).get('message')}", err=True)
            raise typer.Exit(1)

        event_list = body.get("data", [])

        if debug and event_list:
            import json
            typer.echo(json.dumps(event_list[0], indent=2))
            return

        if not event_list:
            typer.echo("No events found.")
            return

        for event in event_list:
            start = event.get("s", "")[:10]
            seconds = event.get("d", 0)
            hours, mins = divmod(seconds // 60, 60)
            duration = f"{hours}h{mins:02d}m" if hours else f"{mins}m"
            task = event.get("t", "")
            project = event.get("p", "")
            notes = event.get("n", "") or ""
            typer.echo(f"{start}  {duration:>7}  {project} / {task}  {notes}")


@app.command()
def log(
    task_id: int,
    duration: str,
    notes: str = "",
    date: str = "",
):
    """Log time to a task. Duration: '2h', '2h30m', '90m'."""
    seconds = parse_duration(duration)
    if seconds == 0:
        typer.echo("Invalid duration.", err=True)
        raise typer.Exit(1)

    if date:
        day = datetime.strptime(date, "%Y-%m-%d")
    else:
        day = datetime.now()

    start = day.replace(hour=9, minute=0, second=0, microsecond=0)
    end = start + timedelta(seconds=seconds)
    tz = get_timezone_str()

    with get_client() as client:
        resp = client.post("/events/add", params={
            "task_id": task_id,
            "start": start.strftime("%Y-%m-%d %H:%M:%S"),
            "end": end.strftime("%Y-%m-%d %H:%M:%S"),
            "duration": seconds,
            "timezone": tz,
            "notes": notes,
        })
        resp.raise_for_status()
        body = resp.json()

        if body.get("response", {}).get("status") != 200:
            typer.echo(f"API error: {body.get('response', {}).get('message')}", err=True)
            raise typer.Exit(1)

        typer.echo(f"Logged {duration} to task {task_id}.")


@app.command()
def tui():
    """Open the TUI for time tracking."""
    from tt.tui import run
    run()


if __name__ == "__main__":
    app()
