from datetime import datetime, timedelta
from collections import defaultdict

from textual.app import App, ComposeResult
from textual.widgets import Static, Footer, Label, Input, Button, Select
from textual.containers import Container, Horizontal, Vertical
from textual.binding import Binding
from textual.reactive import reactive

from tt.main import get_client, parse_duration, get_timezone_str

# Monkey-patch OptionList to treat j/k as arrow keys
from textual.widgets import OptionList as _OptionList
from textual.events import Key

_original_post_message = _OptionList.post_message

def _patched_post_message(self, message):
    if isinstance(message, Key):
        if message.key == "j":
            # Call cursor down directly
            self.action_cursor_down()
            return True
        elif message.key == "k":
            # Call cursor up directly
            self.action_cursor_up()
            return True
    return _original_post_message(self, message)

_OptionList.post_message = _patched_post_message




class DayCell(Static):
    selected = reactive(False)

    def __init__(self, date: datetime, seconds: int = 0, count: int = 0, **kwargs):
        super().__init__(**kwargs)
        self.date = date
        self.seconds = seconds
        self.count = count

    def compose(self) -> ComposeResult:
        day_name = self.date.strftime("%a")
        day_num = self.date.day
        yield Label(f"{day_name} {day_num}", classes="day-header")
        yield Label(self.format_time(), classes="day-total")

    def format_time(self) -> str:
        if self.seconds == 0:
            return "-"
        hours, mins = divmod(self.seconds // 60, 60)
        if hours:
            return f"{hours}h{mins:02d} ({self.count})"
        return f"{mins}m ({self.count})"

    def watch_selected(self, selected: bool) -> None:
        self.set_class(selected, "selected")


class WeekView(Static):
    selected_day = reactive(datetime.now().weekday())
    week_offset = reactive(0)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.day_cells: list[DayCell] = []
        self.events_by_day: dict[str, list[dict]] = {}

    def compose(self) -> ComposeResult:
        yield Label("", id="week-header")
        yield Horizontal(id="week-grid")

    def on_mount(self) -> None:
        self.refresh_week()

    def refresh_week(self) -> None:
        today = datetime.now()
        week_start = today - timedelta(days=today.weekday()) + timedelta(weeks=self.week_offset)
        week_end = week_start + timedelta(days=6)

        header = self.query_one("#week-header", Label)
        header.update(f"Week of {week_start.strftime('%b %d, %Y')}")

        # Fetch events for this week
        day_totals = self.fetch_week_events(week_start, week_end)

        grid = self.query_one("#week-grid", Horizontal)
        grid.remove_children()
        self.day_cells = []

        for i in range(7):
            day = week_start + timedelta(days=i)
            day_key = day.strftime("%Y-%m-%d")
            seconds, count = day_totals.get(day_key, (0, 0))
            cell = DayCell(day, seconds=seconds, count=count, classes="day-cell")
            cell.selected = i == self.selected_day
            self.day_cells.append(cell)
            grid.mount(cell)

        self.update_entries_panel()

    def fetch_week_events(self, start: datetime, end: datetime) -> dict[str, tuple[int, int]]:
        """Fetch events and return dict of date -> (total_seconds, count)."""
        day_totals: dict[str, tuple[int, int]] = defaultdict(lambda: (0, 0))
        self.events_by_day = defaultdict(list)

        try:
            with get_client() as client:
                resp = client.get("/events", params={
                    "from": start.strftime("%Y-%m-%d"),
                    "to": end.strftime("%Y-%m-%d"),
                })
                resp.raise_for_status()
                body = resp.json()
                if body.get("response", {}).get("status") == 200:
                    for event in body.get("data", []):
                        event_date = event.get("s", "")[:10]
                        seconds = event.get("d", 0)
                        cur_secs, cur_count = day_totals[event_date]
                        day_totals[event_date] = (cur_secs + seconds, cur_count + 1)
                        self.events_by_day[event_date].append(event)
        except Exception:
            pass

        return dict(day_totals)

    def get_selected_events(self) -> list[dict]:
        """Get events for the currently selected day."""
        if self.day_cells:
            date_key = self.day_cells[self.selected_day].date.strftime("%Y-%m-%d")
            return self.events_by_day.get(date_key, [])
        return []

    def update_entries_panel(self) -> None:
        """Update the entries panel with events for selected day."""
        try:
            entries_panel = self.app.query_one(EntriesPanel)
            events = self.get_selected_events()
            date = self.get_selected_date()
            entries_panel.update_entries(events, date)
        except Exception:
            pass

    def watch_selected_day(self, day: int) -> None:
        for i, cell in enumerate(self.day_cells):
            cell.selected = i == day
        self.update_entries_panel()

    def watch_week_offset(self, offset: int) -> None:
        self.refresh_week()

    def move_day(self, delta: int) -> None:
        self.selected_day = (self.selected_day + delta) % 7

    def move_week(self, delta: int) -> None:
        self.week_offset += delta

    def move_month(self, delta: int) -> None:
        """Move to the same day in next/previous month."""
        from dateutil.relativedelta import relativedelta
        current = self.get_selected_date()

        # Move by one month, relativedelta handles day clamping
        new_date = current + relativedelta(months=delta)

        # Calculate week offset: how many weeks from current week to new week
        current_week_start = current - timedelta(days=current.weekday())
        new_week_start = new_date - timedelta(days=new_date.weekday())
        weeks_diff = (new_week_start - current_week_start).days // 7

        self.week_offset += weeks_diff
        self.selected_day = new_date.weekday()

    def get_selected_date(self) -> datetime:
        if self.day_cells:
            return self.day_cells[self.selected_day].date
        return datetime.now()


class EntryRow(Static):
    selected = reactive(False)

    def __init__(self, event: dict, **kwargs):
        super().__init__(**kwargs)
        self.event = event
        seconds = event.get("d", 0)
        hours, mins = divmod(seconds // 60, 60)
        duration = f"{hours}h{mins:02d}m" if hours else f"{mins}m"
        project = event.get("p", "")
        task = event.get("t", "")
        notes = event.get("n", "") or ""
        self.text = f"{duration:>7}  {project} / {task}  {notes}"

    def compose(self) -> ComposeResult:
        yield Label(self.text)

    def watch_selected(self, selected: bool) -> None:
        self.set_class(selected, "selected")


class EntriesPanel(Static):
    selected_index = reactive(0)
    show_selection = reactive(False)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.entry_rows: list[EntryRow] = []

    def compose(self) -> ComposeResult:
        yield Static(id="entries-list")

    def update_entries(self, events: list[dict], date: datetime) -> None:
        container = self.query_one("#entries-list", Static)
        container.remove_children()
        self.entry_rows = []
        self.selected_index = 0

        if not events:
            container.mount(Label(f"No entries for {date.strftime('%a %b %d')}"))
            return

        for event in events:
            row = EntryRow(event, classes="entry-row")
            self.entry_rows.append(row)
            container.mount(row)

    def watch_selected_index(self, index: int) -> None:
        self._update_selection()

    def watch_show_selection(self, show: bool) -> None:
        self._update_selection()

    def _update_selection(self) -> None:
        for i, row in enumerate(self.entry_rows):
            row.selected = self.show_selection and i == self.selected_index

    def move_selection(self, delta: int) -> None:
        if self.entry_rows:
            self.selected_index = (self.selected_index + delta) % len(self.entry_rows)


class LogForm(Static):
    def compose(self) -> ComposeResult:
        yield Horizontal(
            Label("Project: ", classes="form-label"),
            Select([], id="project-select", prompt="Select project", disabled=True),
            classes="form-row",
        )
        yield Horizontal(
            Label("Task:    ", classes="form-label"),
            Select([], id="task-select", prompt="Select task", disabled=True),
            classes="form-row",
        )
        yield Horizontal(
            Label("Duration:", classes="form-label"),
            Input(placeholder="2h30m", id="duration-input", disabled=True),
            Label(" Notes:", classes="form-label"),
            Input(placeholder="What did you work on?", id="notes-input", disabled=True),
            classes="form-row",
        )
        yield Horizontal(
            Button("Submit", id="submit-btn", variant="primary", disabled=True),
            classes="form-row",
        )

    def enable_inputs(self) -> None:
        for widget in self.query("Select, Input, Button"):
            widget.disabled = False
        self.load_projects()

    def disable_inputs(self) -> None:
        for widget in self.query("Select, Input, Button"):
            widget.disabled = True

    def load_projects(self) -> None:
        try:
            with get_client() as client:
                resp = client.get("/projects")
                resp.raise_for_status()
                body = resp.json()
                if body.get("response", {}).get("status") == 200:
                    projects = body.get("data", [])
                    select = self.query_one("#project-select", Select)
                    options = [(p.get("name", "Unknown"), p.get("id")) for p in projects]
                    select.set_options(options)
        except Exception:
            pass

    def load_tasks(self, project_id: int) -> None:
        try:
            with get_client() as client:
                resp = client.get(f"/projects/{project_id}/min", params={"include_tasks": "true"})
                resp.raise_for_status()
                body = resp.json()
                if body.get("response", {}).get("status") == 200:
                    project_data = body.get("data", {})
                    tasks = [t for t in project_data.get("tasks", []) if not t.get("is_archived")]
                    select = self.query_one("#task-select", Select)
                    options = [(t.get("name", "Unknown"), t.get("id")) for t in tasks]
                    select.set_options(options)
        except Exception:
            pass


class TTApp(App):
    PANELS = ["week-view", "log-form", "entries-panel"]
    active_panel = reactive(0)
    panel_activated = reactive(False)

    CSS = """
    Screen {
        layout: vertical;
    }

    #week-view {
        height: 8;
        border: solid $surface;
        padding: 0 1;
    }

    #week-view.panel-focus {
        border: solid $primary;
    }

    #week-view.panel-active {
        border: double $primary;
    }

    #week-header {
        text-align: center;
        text-style: bold;
    }

    #week-grid {
        height: 4;
    }

    .day-cell {
        width: 1fr;
        height: 100%;
        content-align: center middle;
        border: solid $surface;
    }

    .day-cell.selected {
        border: solid $primary;
        background: $primary 20%;
        color: white;
    }

    #entries-panel {
        height: 1fr;
        border: solid $surface;
        padding: 0 1;
    }

    #entries-panel.panel-focus {
        border: solid $primary;
    }

    #entries-panel.panel-active {
        border: double $primary;
    }

    #log-form {
        height: auto;
        min-height: 7;
        border: solid $surface;
        padding: 0 1;
    }

    #log-form.panel-focus {
        border: solid $primary;
    }

    #log-form.panel-active {
        border: double $primary;
    }

    .form-row {
        height: 3;
        margin-bottom: 1;
    }

    .form-label {
        width: 10;
        height: 1;
        padding-top: 1;
    }

    #project-select, #task-select {
        width: 1fr;
    }

    #duration-input {
        width: 15;
    }

    #notes-input {
        width: 1fr;
    }

    #submit-btn {
        margin-left: 10;
    }

    .entry-row {
        height: 1;
        padding: 0 1;
    }

    .entry-row.selected {
        background: $primary 20%;
        color: white;
    }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("tab", "next_panel", "Next Panel"),
        Binding("shift+tab", "prev_panel", "Prev Panel", show=False),
        Binding("enter", "activate_panel", "Enter"),
        Binding("escape", "deactivate_panel", "Exit", show=False),
        Binding("h", "move_left", "← Day", show=False),
        Binding("l", "move_right", "Day →", show=False),
        Binding("k", "vim_up", "↑", show=False, priority=True),
        Binding("j", "vim_down", "↓", show=False, priority=True),
        Binding("g", "goto_today", "Today", show=False),
    ]

    def compose(self) -> ComposeResult:
        yield WeekView(id="week-view")
        yield LogForm(id="log-form")
        yield EntriesPanel(id="entries-panel")
        yield Footer()

    def action_move_left(self) -> None:
        if self.active_panel == 0:  # week view
            self.query_one(WeekView).move_day(-1)

    def action_move_right(self) -> None:
        if self.active_panel == 0:  # week view
            self.query_one(WeekView).move_day(1)

    def action_move_up(self) -> None:
        if self.active_panel == 0:  # week view
            self.query_one(WeekView).move_week(-1)

    def action_move_down(self) -> None:
        if self.active_panel == 0:  # week view
            self.query_one(WeekView).move_week(1)

    def action_vim_up(self) -> None:
        if not self.panel_activated:
            self.action_prev_panel()
        elif self.active_panel == 0:  # week view
            self.query_one(WeekView).move_week(-1)
        elif self.active_panel == 1:  # form
            # Try to navigate Select dropdown or do nothing
            from textual.widgets._select import SelectOverlay
            for overlay in self.query(SelectOverlay):
                overlay.action_cursor_up()
                return
        elif self.active_panel == 2:  # entries panel
            self.query_one(EntriesPanel).move_selection(-1)

    def action_vim_down(self) -> None:
        if not self.panel_activated:
            self.action_next_panel()
        elif self.active_panel == 0:  # week view
            self.query_one(WeekView).move_week(1)
        elif self.active_panel == 1:  # form
            # Try to navigate Select dropdown or do nothing
            from textual.widgets._select import SelectOverlay
            for overlay in self.query(SelectOverlay):
                overlay.action_cursor_down()
                return
        elif self.active_panel == 2:  # entries panel
            self.query_one(EntriesPanel).move_selection(1)

    def action_goto_today(self) -> None:
        week_view = self.query_one(WeekView)
        week_view.week_offset = 0
        week_view.selected_day = datetime.now().weekday()

    def on_mount(self) -> None:
        self.update_panel_classes()

    def watch_active_panel(self, panel: int) -> None:
        self.update_panel_classes()

    def watch_panel_activated(self, activated: bool) -> None:
        self.update_panel_classes()

    def update_panel_classes(self) -> None:
        for i, panel_id in enumerate(self.PANELS):
            panel = self.query_one(f"#{panel_id}")
            panel.remove_class("panel-focus", "panel-active")
            if i == self.active_panel:
                if self.panel_activated:
                    panel.add_class("panel-active")
                else:
                    panel.add_class("panel-focus")

    def action_next_panel(self) -> None:
        if not self.panel_activated:
            self.active_panel = (self.active_panel + 1) % len(self.PANELS)

    def action_prev_panel(self) -> None:
        if not self.panel_activated:
            self.active_panel = (self.active_panel - 1) % len(self.PANELS)

    def action_activate_panel(self) -> None:
        self.panel_activated = True
        if self.PANELS[self.active_panel] == "log-form":
            # Enable and focus first input in form
            form = self.query_one(LogForm)
            form.enable_inputs()
            self.query_one("#project-select").focus()
        elif self.PANELS[self.active_panel] == "entries-panel":
            self.query_one(EntriesPanel).show_selection = True

    def action_deactivate_panel(self) -> None:
        self.panel_activated = False
        self.set_focus(None)
        # Disable form inputs when leaving
        form = self.query_one(LogForm)
        form.disable_inputs()
        # Hide entries selection
        self.query_one(EntriesPanel).show_selection = False

    def on_select_changed(self, event: Select.Changed) -> None:
        if event.select.id == "project-select" and event.value != Select.BLANK:
            form = self.query_one(LogForm)
            form.load_tasks(event.value)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "submit-btn":
            self.submit_time_entry()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id in ("duration-input", "notes-input"):
            self.submit_time_entry()

    def submit_time_entry(self) -> None:
        # Get form values
        task_select = self.query_one("#task-select", Select)
        duration_input = self.query_one("#duration-input", Input)
        notes_input = self.query_one("#notes-input", Input)

        task_id = task_select.value
        duration_str = duration_input.value.strip()
        notes = notes_input.value.strip()

        # Validate
        if task_id == Select.BLANK:
            self.notify("Please select a task", severity="error")
            return

        if not duration_str:
            self.notify("Please enter a duration", severity="error")
            return

        seconds = parse_duration(duration_str)
        if seconds == 0:
            self.notify("Invalid duration format (e.g., 2h30m)", severity="error")
            return

        # Get date from calendar
        week_view = self.query_one(WeekView)
        day = week_view.get_selected_date()

        start = day.replace(hour=9, minute=0, second=0, microsecond=0)
        end = start + timedelta(seconds=seconds)
        tz = get_timezone_str()

        try:
            with get_client() as client:
                resp = client.post("/events/add", params={
                    "task_id": task_id,
                    "start": start.strftime("%Y-%m-%d %H:%M:%S"),
                    "end": end.strftime("%Y-%m-%d %H:%M:%S"),
                    "duration": seconds,
                    "timezone": tz,
                    "notes": notes,
                })
                resp.raise_for_status()
                body = resp.json()

                if body.get("response", {}).get("status") != 200:
                    self.notify(f"API error: {body.get('response', {}).get('message')}", severity="error")
                    return

                self.notify(f"Logged {duration_str} to task", severity="information")

                # Clear form
                duration_input.value = ""
                notes_input.value = ""

                # Refresh week view to show new entry
                week_view.refresh_week()

        except Exception as e:
            self.notify(f"Error: {e}", severity="error")

    def on_key(self, event) -> None:
        if not self.panel_activated:
            # Panel navigation mode
            if event.key in ("tab", "l"):
                event.prevent_default()
                event.stop()
                self.action_next_panel()
            elif event.key in ("shift+tab", "h"):
                event.prevent_default()
                event.stop()
                self.action_prev_panel()
            elif event.key == "enter":
                event.prevent_default()
                event.stop()
                self.action_activate_panel()
        else:
            # Activated mode
            if event.key == "escape":
                event.prevent_default()
                event.stop()
                self.action_deactivate_panel()
            # Tab in week view cycles months
            elif event.key == "tab" and self.PANELS[self.active_panel] == "week-view":
                event.prevent_default()
                event.stop()
                self.query_one(WeekView).move_month(1)
            elif event.key == "shift+tab" and self.PANELS[self.active_panel] == "week-view":
                event.prevent_default()
                event.stop()
                self.query_one(WeekView).move_month(-1)
            # Navigation in entries panel (h/l/tab - j/k handled by vim actions)
            elif event.key in ("tab", "l") and self.PANELS[self.active_panel] == "entries-panel":
                event.prevent_default()
                event.stop()
                self.query_one(EntriesPanel).move_selection(1)
            elif event.key in ("shift+tab", "h") and self.PANELS[self.active_panel] == "entries-panel":
                event.prevent_default()
                event.stop()
                self.query_one(EntriesPanel).move_selection(-1)


def run():
    app = TTApp()
    app.run()


if __name__ == "__main__":
    run()
