# trax-tui

A TUI for [TrackingTime](https://trackingtime.co).

## Installation

```shell
pipx install trax-tui
```

Requires a keyring backend (e.g., GNOME Keyring, macOS Keychain, Windows Credential Manager).

## Setup

```shell
tt login
```

Enter your TrackingTime email and App Password. You can create an App Password in your TrackingTime
settings under Apps & Integrations. Credentials are stored securely in your system keyring.

## Usage

```shell
tt
```

Opens an interactive terminal interface for logging time:

- **Panel navigation** - `j`/`k` to cycle panels, `Enter` to activate, `Esc` to exit
- **Week calendar** - `h`/`l` (days), `j`/`k` (weeks), `Tab`/`Shift+Tab` (months), `g` (today)
- **Log form** - `Tab` to move through fields, `Enter` to submit
- **Entries list** - `j`/`k` to navigate, `h`/`l` for days, `y` to yank, `p` to paste

Press `q` to quit.
