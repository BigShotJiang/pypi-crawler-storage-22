# trax-tui

<p align="center">
  <img src="https://codeberg.org/jax/trax-tui/raw/branch/main/assets/trax_tui_avatar.png" alt="trax-tui" width="200">
  <br>
  A TUI for <a href="https://trackingtime.co">TrackingTime</a>.
</p>

## Installation

```shell
pipx install trax-tui
```

Requires a keyring backend (e.g., GNOME Keyring, macOS Keychain, Windows Credential Manager).

## Setup

```shell
tt login
```

Enter your TrackingTime email and App Password. You can create an App Password in your TrackingTime
settings under Apps & Integrations. Credentials are stored securely in your system keyring.

## Usage

```shell
tt
```

Opens an interactive terminal interface for logging time:

- **Navigation** - `Ctrl+J`/`Ctrl+K` to cycle focus between elements
- **Week calendar** - `h`/`l` (days), `j`/`k` (weeks), `g` (today)
- **Entries list** - `j`/`k` to scroll entries
- **Global** - `h`/`l` (move day), `y` (yank event), `p` (submit form), `q` (quit)

Single keys type normally when an input is focused. `Ctrl+J`/`Ctrl+K` always works.
