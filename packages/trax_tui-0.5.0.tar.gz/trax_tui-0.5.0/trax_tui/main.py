import re
from datetime import datetime, timedelta

import typer
import keyring
import keyring.errors
import httpx

app = typer.Typer(help="TrackingTime TUI", invoke_without_command=True)


@app.callback()
def main(ctx: typer.Context):
    """TrackingTime TUI"""
    if ctx.invoked_subcommand is None:
        from trax_tui.tui import run
        run()

SERVICE_NAME = "tt-trackingtime"
API_BASE = "https://api.trackingtime.co/api/v4"


USER_AGENT = "tt-cli (https://codeberg.org/jax/tt)"


def parse_duration(s: str) -> int:
    """Parse duration string like '2h', '2h30m', '90m' to seconds."""
    total = 0
    for match in re.finditer(r"(\d+)\s*(h|m|s)?", s.lower()):
        val, unit = int(match.group(1)), match.group(2) or "m"
        if unit == "h":
            total += val * 3600
        elif unit == "m":
            total += val * 60
        else:
            total += val
    return total


def get_timezone_str() -> str:
    """Get local timezone in GMT+00 format."""
    now = datetime.now().astimezone()
    offset = now.utcoffset()
    if offset is None:
        return "GMT+00"
    hours = int(offset.total_seconds() // 3600)
    sign = "+" if hours >= 0 else ""
    return f"GMT{sign}{hours:02d}"


def get_credentials() -> tuple[str, str] | None:
    username = keyring.get_password(SERVICE_NAME, "username")
    password = keyring.get_password(SERVICE_NAME, "password")
    if username and password:
        return username, password
    return None


def get_client() -> httpx.Client:
    creds = get_credentials()
    if not creds:
        typer.echo("Not logged in. Run 'tt login' first.", err=True)
        raise typer.Exit(1)
    username, password = creds
    return httpx.Client(
        base_url=API_BASE,
        auth=(username, password),
        headers={"User-Agent": USER_AGENT},
    )


@app.command()
def login():
    username = typer.prompt("Username (email)")
    password = typer.prompt("Password", hide_input=True)

    keyring.set_password(SERVICE_NAME, "username", username)
    keyring.set_password(SERVICE_NAME, "password", password)

    typer.echo("Credentials saved.")


@app.command()
def logout():
    try:
        keyring.delete_password(SERVICE_NAME, "username")
        keyring.delete_password(SERVICE_NAME, "password")
        typer.echo("Credentials removed.")
    except keyring.errors.PasswordDeleteError:
        typer.echo("No credentials found.")


@app.command()
def tui():
    """Open the TUI for time tracking."""
    from trax_tui.tui import run
    run()


if __name__ == "__main__":
    app()
