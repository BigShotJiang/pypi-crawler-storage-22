__version__ = "1.2.1"  # This will be replaced during the build process
