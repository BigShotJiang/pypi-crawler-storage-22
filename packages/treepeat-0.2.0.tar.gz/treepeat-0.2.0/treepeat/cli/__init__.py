"""CLI module."""

from treepeat.cli.cli import main

__all__ = ["main"]
