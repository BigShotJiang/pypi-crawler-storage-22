# trex/__init__.py
from .model import LigandPayload, MapSite, TrexFull, TrexMin

# New public helper (supersedes the old canonicalize_smiles_with_map)
# from .smiles_canon import canonical_smiles_and_maps

__all__ = [
    "TrexMin",
    "TrexFull",
    "LigandPayload",
    "MapSite",
    #    "canonical_smiles_and_maps",
]
