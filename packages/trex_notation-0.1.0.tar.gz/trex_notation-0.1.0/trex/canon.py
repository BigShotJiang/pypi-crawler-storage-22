from collections import Counter

from .model import TrexMin
from .registry import Registry


def canonicalize_min(t: TrexMin, reg: Registry) -> TrexMin:
    dent = Counter()
    for i, j in t.pairs:
        dent[i] += 1
        dent[j] += 1
    for i in t.singles:
        dent[i] += 1

    props = []
    for idx, tok in enumerate(t.ligands, start=1):
        li = reg.get(tok)
        charge = li.charge
        mw = li.mw_monoiso or 0.0
        sign_rank = 0 if charge < 0 else (1 if charge == 0 else 2)
        props.append((idx, tok, dent[idx], abs(charge), sign_rank, mw))

    # priority: dent ↓, |charge| ↓, sign (anion<neutral<cation), MW ↓, token ↑
    order = [p[0] for p in sorted(props, key=lambda p: (-p[2], -p[3], p[4], -p[5], p[1]))]
    remap = {old: new for new, old in enumerate(order, start=1)}

    ligs = [t.ligands[i - 1] for i in order]
    pairs = sorted({tuple(sorted((remap[i], remap[j]))) for (i, j) in t.pairs})
    singles = sorted({remap[i] for i in t.singles})

    return TrexMin(
        metal=t.metal,
        ox=t.ox,
        spin=t.spin,
        ligands=ligs,
        pairs=pairs,
        singles=singles,
        G=t.G,
        X=t.X,
    )
