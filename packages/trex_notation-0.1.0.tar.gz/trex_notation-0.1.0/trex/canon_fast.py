# trex/canon_fast.py
from __future__ import annotations

import hashlib
import math
from collections.abc import Iterable

from .model import MapSite, TrexFull
from .parse_full import parse_trex_full, pretty_trex_full

# ------------------------ Lightweight SMILES atom tokenizer ------------------------
# This is intentionally simple and robust to common organic/inorganic ligand SMILES.
# It counts "atom tokens" in the display order so that 1-based indices in MAP
# line up with the token position list (no RDKit dependency).

_TWO_LETTER = {
    # Halogens
    "Cl",
    "Br",
    # Common main group / metalloid
    "Si",
    "Ge",
    "As",
    "Se",
    "Te",
    # Alkali / alkaline earth frequently seen in counterions (rare in ligands, safe to include)
    "Li",
    "Na",
    "Mg",
    "Al",
    "Ca",
    "K",
    # Transition metals sometimes present in special ligands (carbenes, etc.)
    "Sc",
    "Ti",
    "V",
    "Cr",
    "Mn",
    "Fe",
    "Co",
    "Ni",
    "Cu",
    "Zn",
    "Ga",
    "Zr",
    "Nb",
    "Mo",
    "Tc",
    "Ru",
    "Rh",
    "Pd",
    "Ag",
    "Cd",
    "In",
    "Sn",
    "Sb",
    "Xe",
    "Hf",
    "Ta",
    "W",
    "Re",
    "Os",
    "Ir",
    "Pt",
    "Au",
    "Hg",
    "Pb",
    "Bi",
}

# Aromatic lower-case one-letter atoms allowed outside brackets
_ARO_SINGLE = {
    "b": "B",
    "c": "C",
    "n": "N",
    "o": "O",
    "p": "P",
    "s": "S",
    "se": "Se",
    "as": "As",
}  # handle "se"/"as" gracefully

# Approx atomic masses for ranking
_MASS = {
    "H": 1.008,
    "B": 10.81,
    "C": 12.011,
    "N": 14.007,
    "O": 15.999,
    "F": 18.998,
    "P": 30.974,
    "S": 32.06,
    "Cl": 35.45,
    "Br": 79.904,
    "I": 126.90,
    "Si": 28.085,
    "Ge": 72.630,
    "As": 74.922,
    "Se": 78.971,
    "Te": 127.60,
    "Li": 6.94,
    "Na": 22.990,
    "Mg": 24.305,
    "Al": 26.982,
    "K": 39.098,
    "Ca": 40.078,
    "Sc": 44.956,
    "Ti": 47.867,
    "V": 50.942,
    "Cr": 51.996,
    "Mn": 54.938,
    "Fe": 55.845,
    "Co": 58.933,
    "Ni": 58.693,
    "Cu": 63.546,
    "Zn": 65.38,
    "Ga": 69.723,
    "Zr": 91.224,
    "Nb": 92.906,
    "Mo": 95.95,
    "Tc": 98.0,
    "Ru": 101.07,
    "Rh": 102.91,
    "Pd": 106.42,
    "Ag": 107.87,
    "Cd": 112.41,
    "In": 114.82,
    "Sn": 118.71,
    "Sb": 121.76,
    "Xe": 131.29,
    "Hf": 178.49,
    "Ta": 180.95,
    "W": 183.84,
    "Re": 186.21,
    "Os": 190.23,
    "Ir": 192.22,
    "Pt": 195.08,
    "Au": 196.97,
    "Hg": 200.59,
    "Pb": 207.2,
    "Bi": 208.98,
}


def _parse_bracket_atom(label: str) -> str:
    # label is the content between '[' and ']'. We pick the first element symbol present.
    # Examples: "nH", "NH3+", "13C@H", "se-", "Cl-", "Cu+2"
    i = 0
    # skip isotope digits
    while i < len(label) and label[i].isdigit():
        i += 1
    if i >= len(label):
        return "*"  # fallback
    # take first letter (case-insensitive) + optional second lower-case
    ch = label[i]
    if ch.isalpha():
        if i + 1 < len(label) and label[i + 1].islower():
            sym = label[i : i + 2]
        else:
            sym = ch
    else:
        sym = ch
    # normalize e.g. 'se' → 'Se'
    if len(sym) == 2:
        sym = sym[0].upper() + sym[1].lower()
    else:
        sym = sym.upper()
    # fix aromatic lower-case single-letter: ['n'] should become 'N'
    if sym in {"B", "C", "N", "O", "P", "S", "F", "I"} or sym in _TWO_LETTER or sym in _MASS:
        return sym
    # try lower-case aromatic two-letter (se/as) if given lower-case
    if sym.lower() in _ARO_SINGLE:
        return _ARO_SINGLE[sym.lower()]
    return sym  # unknown stays as-is; mass fallback will be 0


def smiles_atom_list(smi: str) -> list[str]:
    """Return a best-effort list of atom symbols in SMILES token order, 1-based matching."""
    atoms: list[str] = []
    i = 0
    L = len(smi)
    while i < L:
        ch = smi[i]
        if ch == "[":
            j = i + 1
            depth = 1
            while j < L and depth > 0:
                if smi[j] == "\\":
                    j += 2
                    continue
                if smi[j] == "[":
                    depth += 1
                elif smi[j] == "]":
                    depth -= 1
                    if depth == 0:
                        break
                j += 1
            inner = smi[i + 1 : j] if j < L else smi[i + 1 :]
            atoms.append(_parse_bracket_atom(inner))
            i = j + 1 if j < L else L
            continue

        # skip bond/branch/control symbols
        if ch in "-=#:()/\\.@+*%0123456789.":
            # handle %nn ring numbers: skip the following two digits
            if ch == "%" and i + 2 < L and smi[i + 1 : i + 3].isdigit():
                i += 3
            else:
                i += 1
            continue

        # two-letter element
        if i + 1 < L:
            di = smi[i : i + 2]
            if di in _TWO_LETTER:
                atoms.append(di)
                i += 2
                continue
            # aromatic "se/as"
            if di.lower() in _ARO_SINGLE:
                atoms.append(_ARO_SINGLE[di.lower()])
                i += 2
                continue

        # one-letter element (upper or aromatic lower)
        if ch.isalpha():
            if ch.islower() and ch in _ARO_SINGLE:
                atoms.append(_ARO_SINGLE[ch])  # e.g. 'c' -> 'C'
            else:
                atoms.append(ch.upper())
        i += 1
    return atoms


def _mass_of(sym: str) -> float:
    return _MASS.get(sym, 0.0)


def ligand_exact_mass_approx(smi: str) -> float:
    # Implicit H not counted
    return sum(_mass_of(a) for a in smiles_atom_list(smi))


def coord_mass_for_positions(smi: str, positions_1b: Iterable[int]) -> float:
    atoms = smiles_atom_list(smi)
    m = 0.0
    for pos in sorted(set(positions_1b)):
        if 1 <= pos <= len(atoms):
            m += _mass_of(atoms[pos - 1])
    return m


# ------------------------ Helpers for T-REX sites / ranking ------------------------


def _collect_sites_by_lig(
    pairs: list[tuple[MapSite, MapSite]], singles: list[MapSite]
) -> dict[int, list[tuple[int, ...]]]:
    sites: dict[int, list[tuple[int, ...]]] = {}
    for a, b in pairs:
        sites.setdefault(a.lig, []).append(tuple(sorted(a.atoms)))
        sites.setdefault(b.lig, []).append(tuple(sorted(b.atoms)))
    for s in singles:
        sites.setdefault(s.lig, []).append(tuple(sorted(s.atoms)))
    # normalize duplicate sites
    for k, v in list(sites.items()):
        uniq = []
        seen = set()
        for site in v:
            if site not in seen:
                seen.add(site)
                uniq.append(site)
        sites[k] = sorted(uniq)
    return sites


def denticity_for_lig(lig_idx: int, sites_by_lig: dict[int, list[tuple[int, ...]]]) -> int:
    return len(sites_by_lig.get(lig_idx, []))


def max_hapticity_for_lig(lig_idx: int, sites_by_lig: dict[int, list[tuple[int, ...]]]) -> int:
    sites = sites_by_lig.get(lig_idx, [])
    return max((len(site) for site in sites), default=0)


def _hash_text(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def _remap_lig_indices(
    pairs: list[tuple[MapSite, MapSite]],
    singles: list[MapSite],
    mapping: dict[int, int],
) -> tuple[list[tuple[MapSite, MapSite]], list[MapSite]]:
    def remap_site(ms: MapSite) -> MapSite:
        return MapSite(lig=mapping.get(ms.lig, ms.lig), atoms=ms.atoms)

    pairs2 = []
    for a, b in pairs:
        aa, bb = remap_site(a), remap_site(b)
        # normalized in-pair order
        if (aa.lig, aa.atoms) <= (bb.lig, bb.atoms):
            pairs2.append((aa, bb))
        else:
            pairs2.append((bb, aa))
    pairs2.sort(key=lambda ab: ((ab[0].lig, ab[0].atoms), (ab[1].lig, ab[1].atoms)))
    singles2 = [remap_site(s) for s in singles]
    singles2.sort(key=lambda s: (s.lig, s.atoms))
    return pairs2, singles2


def _validated_geometry(
    pairs: list[tuple[MapSite, MapSite]], singles: list[MapSite], G: str | None
) -> str | None:
    # Keep only 'O' (octahedral) when CN==6; else drop G (matches canonicalize_full behavior)
    cn = len(pairs) * 2 + len(singles)
    return "O" if (G == "O" and cn == 6) else (None if cn != 6 else ("O" if G == "O" else None))


# ------------------------ Public API ------------------------


def canonicalize_fast(t: TrexFull) -> TrexFull:
    """
    RDKit-free canonicalization:
      - No per-ligand SMILES recanonicalization / no atom-index remap within ligands.
      - Rank ligands by: denticity ↓, max hapticity ↓, coord-atom mass ↓, ligand mass ↓, hash.
      - Remap ligand indices accordingly.
      - For identical ligands, minimize the MAP usage lexicographically (pairs then singles).
      - Geometry validation: keep 'O' only when CN==6; else omit G.
    """
    # Sites per ligand
    sites_by_lig = _collect_sites_by_lig(t.pairs, t.singles)

    # Precompute metrics
    coord_mass_by_lig: dict[int, float] = {}
    lig_mass_by_lig: dict[int, float] = {}
    hash_by_lig: dict[int, str] = {}

    for lig_idx, pl in enumerate(t.ligands, start=1):
        if pl.kind == "SMILES":
            smi = pl.text
            posns = sorted({p for site in sites_by_lig.get(lig_idx, []) for p in site})
            coord_mass_by_lig[lig_idx] = coord_mass_for_positions(smi, posns)
            lig_mass_by_lig[lig_idx] = ligand_exact_mass_approx(smi)
            hash_by_lig[lig_idx] = _hash_text(smi)
        else:  # e.g., SELFIES
            coord_mass_by_lig[lig_idx] = 0.0
            lig_mass_by_lig[lig_idx] = 0.0
            hash_by_lig[lig_idx] = f"TXT:{pl.text}"

    def key(lig_idx: int) -> tuple[int, int, float, float, str]:
        dent = denticity_for_lig(lig_idx, sites_by_lig)
        hap = max_hapticity_for_lig(lig_idx, sites_by_lig)
        cmw = coord_mass_by_lig.get(lig_idx, 0.0)
        lmw = lig_mass_by_lig.get(lig_idx, 0.0)
        h = hash_by_lig.get(lig_idx, "")
        return (-dent, -hap, -cmw, -lmw, h)

    order = sorted(range(1, len(t.ligands) + 1), key=key)
    order_map = {old: i + 1 for i, old in enumerate(order)}

    # Reorder payloads and remap indices
    ligands2 = [t.ligands[old - 1] for old in order]
    pairs2, singles2 = _remap_lig_indices(t.pairs, t.singles, order_map)

    # ---------- identical-ligand minimization ----------
    from collections import defaultdict

    classes: dict[tuple[str, str], list[int]] = defaultdict(list)
    for i, pl in enumerate(ligands2, start=1):
        classes[(pl.kind, pl.text)].append(i)

    perm: dict[int, int] = {}
    for _, ligs in classes.items():
        if len(ligs) < 2:
            continue
        target_slots = sorted(ligs)

        usage: dict[int, list[tuple]] = {li: [] for li in ligs}
        for a, b in pairs2:
            if a.lig in usage:
                usage[a.lig].append((0, b.lig, tuple(b.atoms), tuple(a.atoms)))
            if b.lig in usage:
                usage[b.lig].append((0, a.lig, tuple(a.atoms), tuple(b.atoms)))
        for s in singles2:
            if s.lig in usage:
                usage[s.lig].append((1, math.inf, (), tuple(s.atoms)))

        ranked = sorted(
            ((tuple(sorted(v)), li) for li, v in usage.items()), key=lambda x: (x[0], x[1])
        )
        for tgt_idx, (_, old_li) in zip(target_slots, ranked, strict=False):
            perm[old_li] = tgt_idx

    if perm:
        n = len(ligands2)
        full_map = {i: i for i in range(1, n + 1)}
        full_map.update(perm)
        ligands3 = [None] * n
        for old_i in range(1, n + 1):
            ligands3[full_map[old_i] - 1] = ligands2[old_i - 1]
        pairs3, singles3 = _remap_lig_indices(pairs2, singles2, full_map)
    else:
        ligands3, pairs3, singles3 = ligands2, pairs2, singles2
    # ---------- end identical-ligand minimization ----------

    G2 = _validated_geometry(pairs3, singles3, t.G)

    return TrexFull(
        metal=t.metal,
        ox=t.ox,
        spin=t.spin,
        ligands=ligands3,
        pairs=pairs3,
        singles=singles3,
        G=G2,
        X=t.X,
    )


def canonicalize_fast_string(s: str) -> str:
    """Parse → canonicalize_fast → pretty (RDKit-free)."""
    t = parse_trex_full(s)
    tc = canonicalize_fast(t)
    return pretty_trex_full(tc)
