# trex/canon_full.py
from __future__ import annotations

# ---------------- ligand charge fixes (pre-canonicalization) ----------------
import math as _math
import re as _re
from collections.abc import Iterable
from functools import lru_cache
from itertools import permutations

import numpy as _np
from rdkit import Chem
from rdkit.Chem import rdMolDescriptors as rdMD
from rdkit.Chem import rdmolfiles as _rdmolfiles
from rdkit.Chem import rdmolops

from .graph_hash import hash_mol
from .model import LigandPayload, MapSite, TrexFull
from .smiles_map_utils import remap_indices_from_smiles

# ---------------- pentagonal bipyramidal rotation ordering ----------------


def _signed_angle_in_plane(v1: _np.ndarray, v2: _np.ndarray, axis: _np.ndarray) -> float:
    """
    Compute signed angle from v1 to v2 around axis (right-hand rule).
    Returns signed angle in degrees (-180, 180].
    """
    axis_norm = axis / (_np.linalg.norm(axis) + 1e-10)

    # Project vectors onto plane perpendicular to axis
    v1_proj = v1 - _np.dot(v1, axis_norm) * axis_norm
    v2_proj = v2 - _np.dot(v2, axis_norm) * axis_norm

    n1 = _np.linalg.norm(v1_proj)
    n2 = _np.linalg.norm(v2_proj)
    if n1 < 1e-10 or n2 < 1e-10:
        return 0.0

    v1_norm = v1_proj / n1
    v2_norm = v2_proj / n2

    cos_angle = _np.clip(_np.dot(v1_norm, v2_norm), -1.0, 1.0)
    angle = _math.degrees(_math.acos(cos_angle))

    # Determine sign using cross product
    cross = _np.cross(v1_norm, v2_norm)
    if _np.dot(cross, axis_norm) < 0:
        angle = -angle

    return angle


def _order_equatorial_by_rotation(
    singles: list[MapSite],
    axis: _np.ndarray,
) -> list[MapSite]:
    """
    Order equatorial singles by CCW rotation around axis.

    Starts with first site (highest priority), chains through by smallest
    positive angle. This formalizes close-cis (72°) vs far-cis (144°).
    """
    if len(singles) < 2:
        return list(singles)

    # Check all have coordinates
    for s in singles:
        if s.coord is None:
            return list(singles)

    if _np.linalg.norm(axis) < 1e-10:
        return list(singles)

    coords = [_np.array(s.coord) for s in singles]

    # Start with first site (highest priority)
    ordered = [0]
    remaining = set(range(1, len(singles)))

    while remaining:
        current_vec = coords[ordered[-1]]

        best_idx = None
        best_angle = float("inf")

        for idx in remaining:
            angle = _signed_angle_in_plane(current_vec, coords[idx], axis)
            if angle <= 0:
                angle += 360
            if angle < best_angle:
                best_angle = angle
                best_idx = idx

        if best_idx is not None:
            ordered.append(best_idx)
            remaining.remove(best_idx)
        else:
            ordered.extend(remaining)
            break

    return [singles[i] for i in ordered]


def _canonicalize_pntbp_singles(
    pairs: list[tuple[MapSite, MapSite]],
    singles: list[MapSite],
) -> tuple[list[MapSite], bool]:
    """
    For pentagonal bipyramidal (1 pair, 5 singles), order singles by rotation.

    Uses a CONSISTENT axis direction: we always use the cross product of the
    first two singles to define "up", then check which axial site is on the
    positive side. This makes the axis choice independent of pair ordering.

    Returns:
        (ordered_singles, was_reordered)
    """
    if len(pairs) != 1 or len(singles) != 5:
        return singles, False

    # Check if we have coordinates
    axial_a, axial_b = pairs[0]
    if axial_a.coord is None or axial_b.coord is None:
        return singles, False

    for s in singles:
        if s.coord is None:
            return singles, False

    # Define axis consistently using equatorial plane normal
    # Cross product of first two equatorial vectors defines a normal
    eq_coords = [_np.array(s.coord) for s in singles]

    # Use cross product of first two equatorial sites to get plane normal
    plane_normal = _np.cross(eq_coords[0], eq_coords[1])
    if _np.linalg.norm(plane_normal) < 1e-10:
        # Degenerate case, try different pair
        plane_normal = _np.cross(eq_coords[0], eq_coords[2])

    if _np.linalg.norm(plane_normal) < 1e-10:
        return singles, False

    plane_normal = plane_normal / _np.linalg.norm(plane_normal)

    # Choose axis direction so it points toward the axial site with
    # HIGHER priority (lower lig index = listed first = higher priority)
    # pairs[0][0] is already the higher priority site due to pair normalization
    axial_vec = _np.array(axial_a.coord)

    # Make sure we're looking from the correct direction
    # If axial_a is on the negative side of our plane normal, flip the normal
    if _np.dot(axial_vec, plane_normal) < 0:
        plane_normal = -plane_normal

    # Now order singles CCW when looking along plane_normal (toward axial_a)
    ordered = _order_equatorial_by_rotation(singles, plane_normal)

    return ordered, True


def _fix_nitro_smiles(smi: str) -> tuple[str, int]:
    """
    Fix incorrectly parsed nitro groups in SMILES string.

    Patterns fixed:
    - N([O-])[O-] → [N+](=O)[O-]
    - [O-]N([O-]) → O=[N+]([O-])
    - [O-]N(...)[O-] → O=[N+](...)[O-] (for non-terminal nitro)

    Returns:
        (fixed_smiles, num_fixes) where num_fixes is count of nitro groups fixed
    """
    count = 0

    # Pattern 1: N([O-])[O-] - most common form
    pattern1 = r"N\(\[O-\]\)\[O-\]"
    replacement1 = "[N+](=O)[O-]"
    smi, n = _re.subn(pattern1, replacement1, smi)
    count += n

    # Pattern 2: [O-]N([O-]) - terminal, written with O- first
    pattern2 = r"\[O-\]N\(\[O-\]\)"
    replacement2 = "O=[N+]([O-])"
    smi, n = _re.subn(pattern2, replacement2, smi)
    count += n

    # Pattern 3: [O-]N(X)[O-] where X is the rest of the molecule
    def fix_middle_nitro(s: str) -> tuple[str, int]:
        """Fix nitro groups where O- appears before N with content in middle."""
        fixes = 0
        result = []
        i = 0

        while i < len(s):
            # Look for [O-]N( pattern
            if s[i : i + 5] == "[O-]N" and i + 5 < len(s) and s[i + 5] == "(":
                # Find the matching closing paren
                paren_start = i + 5
                paren_depth = 1
                j = paren_start + 1

                while j < len(s) and paren_depth > 0:
                    if s[j] == "(":
                        paren_depth += 1
                    elif s[j] == ")":
                        paren_depth -= 1
                    j += 1

                # j is now just past the closing paren
                # Check if followed by [O-]
                if j < len(s) and s[j : j + 4] == "[O-]":
                    content = s[paren_start + 1 : j - 1]
                    result.append(f"O=[N+]({content})[O-]")
                    i = j + 4
                    fixes += 1
                else:
                    result.append(s[i])
                    i += 1
            else:
                result.append(s[i])
                i += 1

        return "".join(result), fixes

    smi, n = fix_middle_nitro(smi)
    count += n

    return smi, count


def _fix_hydride_smiles(smi: str) -> tuple[str, int]:
    """
    Fix incorrectly parsed hydride ligand: [H+] → [H-]

    Returns:
        (fixed_smiles, 1) if fixed, else (smi, 0)
    """
    if smi.strip() == "[H+]":
        return "[H-]", 1
    return smi, 0


def _fix_ligand_charges(t: TrexFull) -> TrexFull:
    """
    Fix common charge errors in ligand SMILES and adjust metal oxidation state.

    Called at the START of canonicalize_full, before any index tracking.

    Fixes applied:
    1. Nitro groups: N([O-])[O-] → [N+](=O)[O-]
       - Each fix decreases metal ox by 2 (ligand charge goes from -2 to 0)
    2. Hydride: [H+] → [H-]
       - Each fix increases metal ox by 2 (ligand charge goes from +1 to -1)
    """
    new_ligands: list[LigandPayload] = []
    ox_delta = 0

    for pl in t.ligands:
        if pl.kind != "SMILES":
            new_ligands.append(pl)
            continue

        smi = pl.text

        # Fix hydride first (complete ligand replacement)
        fixed_smi, n_hydride = _fix_hydride_smiles(smi)
        if n_hydride > 0:
            ox_delta += 2 * n_hydride  # H+ → H-, ox increases
            new_ligands.append(LigandPayload(kind="SMILES", text=fixed_smi))
            continue

        # Fix nitro groups
        fixed_smi, n_nitro = _fix_nitro_smiles(smi)
        if n_nitro > 0:
            ox_delta -= 2 * n_nitro  # Each nitro fix decreases ox by 2

        new_ligands.append(LigandPayload(kind="SMILES", text=fixed_smi))

    return TrexFull(
        metal=t.metal,
        ox=t.ox + ox_delta,
        spin=t.spin,
        ligands=new_ligands,
        pairs=list(t.pairs),
        singles=list(t.singles),
        G=t.G,
        X=t.X,
    )


# ---------------- helpers: site collection & simple stats ----------------


def _collect_sites_by_lig(
    pairs: list[tuple[MapSite, MapSite]],
    singles: list[MapSite],
) -> dict[int, list[tuple[int, ...]]]:
    """
    Build a map: lig_index -> list of (sorted, deduped) atom-tuples representing unique sites.
    """
    per_lig: dict[int, set[tuple[int, ...]]] = {}

    def add_site(s: MapSite):
        per_lig.setdefault(s.lig, set()).add(tuple(sorted(set(s.atoms))))

    for a, b in pairs:
        add_site(a)
        add_site(b)
    for s in singles:
        add_site(s)
    return {k: [t for t in v if t] for k, v in per_lig.items()}


def _coordination_number(pairs: list[tuple[MapSite, MapSite]], singles: list[MapSite]) -> int:
    """Number of unique sites (across all ligands)."""
    sites = set()
    for a, b in pairs:
        sites.add((a.lig, tuple(a.atoms)))
        sites.add((b.lig, tuple(b.atoms)))
    for s in singles:
        sites.add((s.lig, tuple(s.atoms)))
    return len(sites)


def _denticity_for_lig(lig: int, sites_by_lig: dict[int, list[tuple[int, ...]]]) -> int:
    return len(sites_by_lig.get(lig, []))


def _max_hapticity_for_lig(lig: int, sites_by_lig: dict[int, list[tuple[int, ...]]]) -> int:
    sites = sites_by_lig.get(lig, [])
    return max((len(s) for s in sites), default=0)


def _hash_from_smiles(smi: str) -> str:
    m = Chem.MolFromSmiles(smi)
    if m is None:
        return f"TXT:{smi}"
    try:
        return hash_mol(m, include_hs=True, charge_agnostic=True)
    except Exception:
        return f"TXT:{smi}"


# ---------------- helpers: SMILES canonicalization + per-ligand remaps ----------------


def _remap_atoms_for_ligand(
    payload: LigandPayload,
    needed_indices_1b: Iterable[int],
) -> tuple[LigandPayload, dict[int, int]]:
    """
    If payload.kind == 'SMILES', canonicalize the SMILES and remap the *subset*
    of indices we actually need (1-based -> 1-based). Return:
        - new LigandPayload(kind='SMILES', text=<canonical smiles>)
        - mapping dict old_1b -> new_1b (only for provided indices)

    For non-SMILES ligands: returns payload unchanged and an empty mapping.
    """
    if payload.kind != "SMILES":
        return payload, {}

    smi_in = payload.text
    need_0b = sorted({i - 1 for i in needed_indices_1b if i >= 1})
    try:
        can_smi, mapped_0b = remap_indices_from_smiles(smi_in, need_0b, mode="smiles")
    except Exception:
        # On failure, keep input unchanged, identity mapping for provided indices
        return payload, {i: i for i in needed_indices_1b}

    remap_1b = {
        old1b: (new0b + 1)
        for old1b, new0b in zip([i + 1 for i in need_0b], mapped_0b, strict=False)
    }
    return LigandPayload(kind="SMILES", text=can_smi), remap_1b


def _apply_within_ligand_remap(
    pairs: list[tuple[MapSite, MapSite]],
    singles: list[MapSite],
    per_lig_remap: dict[int, dict[int, int]],
) -> tuple[list[tuple[MapSite, MapSite]], list[MapSite]]:
    """
    Apply per-ligand (1-based) remaps to every site atom list.
    PRESERVES coord attribute on MapSite.
    """

    def remap_site(s: MapSite) -> MapSite:
        mp = per_lig_remap.get(s.lig, {})
        if not mp:
            return s
        atoms_new = sorted({mp.get(a, a) for a in s.atoms})
        return MapSite(lig=s.lig, atoms=atoms_new, coord=s.coord)  # PRESERVE coord

    out_pairs = []
    for a, b in pairs:
        aa, bb = remap_site(a), remap_site(b)
        a2, b2 = (aa, bb) if (aa.lig, aa.atoms) <= (bb.lig, bb.atoms) else (bb, aa)
        out_pairs.append((a2, b2))

    out_singles = [remap_site(s) for s in singles]
    return out_pairs, out_singles


def _remap_lig_indices(
    pairs: list[tuple[MapSite, MapSite]],
    singles: list[MapSite],
    order_map: dict[int, int],
) -> tuple[list[tuple[MapSite, MapSite]], list[MapSite]]:
    """
    Remap ligand indices according to order_map.
    PRESERVES coord attribute on MapSite.
    """

    def relabel(s: MapSite) -> MapSite:
        return MapSite(lig=order_map[s.lig], atoms=list(s.atoms), coord=s.coord)  # PRESERVE coord

    pairs2: list[tuple[MapSite, MapSite]] = []
    for a, b in pairs:
        aa, bb = relabel(a), relabel(b)
        a2, b2 = (aa, bb) if (aa.lig, aa.atoms) <= (bb.lig, bb.atoms) else (bb, aa)
        pairs2.append((a2, b2))
    singles2 = [relabel(s) for s in singles]
    pairs2.sort(key=lambda ab: ((ab[0].lig, ab[0].atoms), (ab[1].lig, ab[1].atoms)))
    singles2.sort(key=lambda s: (s.lig, s.atoms))
    return pairs2, singles2


# ---------------- mass metrics (coord atoms + full ligand) ----------------


def _written_order_to_rdidx(smi: str) -> list[int]:
    """
    Return a list `pos -> rd_idx` mapping SMILES writing order (0-based) to RDKit atom index.
    Round-trip with atom-map numbers equal to RD indices; fallback to canonical ranks.
    """
    m = Chem.MolFromSmiles(smi)
    if m is None:
        return []
    m2 = Chem.Mol(m)
    for a in m2.GetAtoms():
        a.SetAtomMapNum(a.GetIdx() + 1)
    s = Chem.MolToSmiles(m2, canonical=True, isomericSmiles=True)
    import re

    ids = [int(x) - 1 for x in re.findall(r":(\d+)\]", s)]
    if not ids and m2.GetNumAtoms() == 1:
        return [0]
    if len(ids) != m2.GetNumAtoms():
        ranks = Chem.CanonicalRankAtoms(m)
        order = sorted(range(m.GetNumAtoms()), key=lambda i: (ranks[i], i))
        return order
    return ids


def _coord_mass_for_ligand_smi(smi: str, site_positions_1b: Iterable[int]) -> float:
    """Sum of average atomic weights for the unique coordinating atoms."""
    m = Chem.MolFromSmiles(smi)
    if m is None:
        return 0.0
    pos_to_rd = _written_order_to_rdidx(smi)  # 0-based pos -> rd_idx
    pt = Chem.GetPeriodicTable()
    rd_ids = set()
    for p1 in set(site_positions_1b):
        p0 = p1 - 1
        if 0 <= p0 < len(pos_to_rd):
            rd_ids.add(pos_to_rd[p0])
    mass = 0.0
    for rid in rd_ids:
        z = m.GetAtomWithIdx(rid).GetAtomicNum()
        mass += pt.GetAtomicWeight(z)
    return float(mass)


def _lig_exact_mass_from_smi(smi: str) -> float:
    m = Chem.MolFromSmiles(smi)
    if m is None:
        return 0.0
    mh = Chem.AddHs(Chem.Mol(m), addCoords=False)
    try:
        return float(rdMD.CalcExactMolWt(mh))
    except Exception:
        return 0.0


# ---------------- geometry policy ----------------


def _validated_geometry(pairs: list[tuple[MapSite, MapSite]], singles: list[MapSite]) -> str | None:
    """
    Policy: Only emit 'O' (octahedral) if CN == 6. Otherwise, return None.
    This prevents, e.g., CN=3 being labeled 'O'.
    """
    cn = _coordination_number(pairs, singles)
    if cn == 6:
        if len(pairs) == 3:
            return "O"
        # return "O"
    return None


#  internal site equivalence (graph-only)
from collections import defaultdict as _dd


def _auto_site_equivalences_graph_only(t: TrexFull) -> dict[int, list[list[tuple[int, ...]]]]:
    """
    Return {lig_idx: [ [site1_atoms...](an equivalence class), ... ] }.
    Two sites are equivalent if their sets of RDKit canonical ranks match.
    Uses best-effort mapping from T-REX 1-based atoms -> RDKit indices.
    """
    out: dict[int, list[list[tuple[int, ...]]]] = {}
    # collect unique sites per ligand (1-based atom tuples)
    per_lig: dict[int, list[tuple[int, ...]]] = _collect_sites_by_lig(t.pairs, t.singles)
    for lig_idx, sites in per_lig.items():
        lp = t.ligands[lig_idx - 1]
        if lp.kind != "SMILES":
            continue
        mol = Chem.MolFromSmiles(lp.text)
        if mol is None or mol.GetNumAtoms() == 0:
            continue

        # try to map by atom-map numbers first; else naive 1-based -> 0-based if in range
        amap = {a.GetAtomMapNum(): a.GetIdx() for a in mol.GetAtoms() if a.GetAtomMapNum() > 0}
        have_mapnums = bool(amap)
        n = mol.GetNumAtoms()
        ranks = Chem.CanonicalRankAtoms(mol, breakTies=False)

        buckets: dict[tuple, list[tuple[int, ...]]] = _dd(list)
        for atoms1 in sites:
            if not atoms1:
                continue
            if have_mapnums and all(a in amap for a in atoms1):
                atoms0 = [amap[a] for a in atoms1]
            elif all(1 <= a <= n for a in atoms1):
                atoms0 = [a - 1 for a in atoms1]
            else:
                continue  # can't map safely → skip

            sig = ("graph", len(atoms0), tuple(sorted(ranks[i] for i in atoms0)))
            buckets[sig].append(tuple(sorted(set(atoms1))))

        classes = [sorted(cls) for cls in buckets.values() if len(cls) > 1]
        if classes:
            out[lig_idx] = classes
    return out


def _conn_chargeblind(mol: Chem.Mol) -> Chem.Mol:
    """Connectivity-only, charge-blind copy."""
    m2 = Chem.Mol(mol)
    for b in m2.GetBonds():
        b.SetBondType(Chem.BondType.SINGLE)
        b.SetIsAromatic(False)
        b.SetStereo(Chem.BondStereo.STEREONONE)
    for a in m2.GetAtoms():
        a.SetIsAromatic(False)
        a.SetFormalCharge(0)
    return m2


def _conn_chargeblind_with_Hs(mol: Chem.Mol) -> Chem.Mol:
    """
    Connectivity-only, charge-blind copy with explicit hydrogens.
    This preserves protonation differences for symmetry detection.
    """
    # 1) Add explicit Hs on the ORIGINAL (charged) molecule
    mh = Chem.AddHs(Chem.Mol(mol), addCoords=False)
    try:
        mh.UpdatePropertyCache(strict=False)
    except Exception:
        pass

    # 2) Now make the graph charge-blind & drop edge attributes
    for b in mh.GetBonds():
        b.SetBondType(Chem.BondType.SINGLE)
        b.SetIsAromatic(False)
        b.SetStereo(Chem.BondStereo.STEREONONE)
    for a in mh.GetAtoms():
        a.SetIsAromatic(False)
        a.SetFormalCharge(0)  # charge-blind; H presence distinguishes protonation
    return mh


@lru_cache(maxsize=512)
def _cached_autos_chargeblind(smi: str):
    m = Chem.MolFromSmiles(smi)
    if not m:
        return ()
    m2 = _conn_chargeblind(m)
    perms = rdmolops.GetAutomorphisms(m2)  # tuple of permutations idx->idx
    return tuple(tuple(p) for p in perms)


def _filter_perms_preserve_cip(orig: Chem.Mol, perms):
    """Optional safety: drop automorphisms that would flip atom CIP codes."""
    try:
        Chem.AssignStereochemistry(orig, force=True, cleanIt=True)
    except Exception:
        pass
    cip = {
        a.GetIdx(): (a.GetProp("_CIPCode") if a.HasProp("_CIPCode") else None)
        for a in orig.GetAtoms()
    }
    kept = []
    for p in perms:
        ok = True
        for i, code in cip.items():
            if code is None:
                continue
            j = p[i]
            cj = cip.get(j, None)
            if cj is not None and cj != code:
                ok = False
                break
        if ok:
            kept.append(p)
    return tuple(kept)


def _refine_by_rank_classes_chargeblind(
    smi: str, classes: list[list[tuple[int, ...]]]
) -> list[list[tuple[int, ...]]]:
    """
    Confirm/derive site equivalence using canonical symmetry classes from
    CanonicalRankAtoms on a charge-blind connectivity graph.
    Two sites are equivalent if their multisets of canonical ranks (global!) match.
    """
    m = Chem.MolFromSmiles(smi)
    if not m:
        return []

    m2 = _conn_chargeblind_with_Hs(m)
    # global symmetry labels; breakTies=False returns symmetry classes
    ranks = _rdmolfiles.CanonicalRankAtoms(
        m2,
        breakTies=False,
        includeChirality=True,
        includeIsotopes=True,
    )

    def sig(site1b: tuple[int, ...]) -> tuple[int, ...]:
        # multiset of global symmetry ranks for the atoms in this site
        return tuple(sorted(ranks[a - 1] for a in site1b if a >= 1))

    refined: list[list[tuple[int, ...]]] = []
    for cls in classes:
        # regroup by the rank-multiset signature
        buckets: dict[tuple[int, ...], list[tuple[int, ...]]] = {}
        for s in cls:
            buckets.setdefault(sig(s), []).append(tuple(sorted(s)))
        for group in buckets.values():
            if len(group) > 1:
                refined.append(sorted(group))
    return refined


def _auto_site_equivalences_connectivity_global(
    t: TrexFull,
) -> dict[int, list[list[tuple[int, ...]]]]:
    """
    Discover internal site equivalence classes per ligand using global
    canonical rank symmetry on a charge-blind connectivity graph.
    """
    out: dict[int, list[list[tuple[int, ...]]]] = {}
    per_lig = _collect_sites_by_lig(t.pairs, t.singles)
    for lig_idx, sites in per_lig.items():
        if not sites:
            continue
        pl = t.ligands[lig_idx - 1]
        if pl.kind != "SMILES":
            continue
        # start with a single bucket of all sites; rank refinement will split it
        refined = _refine_by_rank_classes_chargeblind(pl.text, [sites])
        if refined:
            out[lig_idx] = refined
    return out


# --- minimize MAP by renaming equivalent sites within ligands ---
def _lex_signature(pairs: list[tuple[MapSite, MapSite]], singles: list[MapSite]) -> tuple:
    ps = [((a.lig, tuple(a.atoms)), (b.lig, tuple(b.atoms))) for a, b in pairs]
    ps.sort()
    ss = sorted((s.lig, tuple(s.atoms)) for s in singles)
    return (tuple(ps), tuple(ss))


def _apply_site_renames_for_lig(
    pairs: list[tuple[MapSite, MapSite]],
    singles: list[MapSite],
    lig: int,
    rename: dict[tuple[int, ...], tuple[int, ...]],
) -> tuple[list[tuple[MapSite, MapSite]], list[MapSite]]:
    """
    Rename sites within a single ligand.
    PRESERVES coord attribute on MapSite.
    """

    def ren(ms: MapSite) -> MapSite:
        if ms.lig != lig:
            return ms
        key = tuple(sorted(ms.atoms))
        if key in rename:
            return MapSite(lig=lig, atoms=list(rename[key]), coord=ms.coord)  # PRESERVE coord
        return ms

    out_pairs = []
    for a, b in pairs:
        aa, bb = ren(a), ren(b)
        a2, b2 = (aa, bb) if (aa.lig, aa.atoms) <= (bb.lig, bb.atoms) else (bb, aa)
        out_pairs.append((a2, b2))
    out_pairs.sort(key=lambda ab: ((ab[0].lig, ab[0].atoms), (ab[1].lig, ab[1].atoms)))
    out_singles = [ren(s) for s in singles]
    out_singles.sort(key=lambda s: (s.lig, s.atoms))
    return out_pairs, out_singles


def _collapse_internal_symmetry_in_map(
    t_like: TrexFull,
    pairs: list[tuple[MapSite, MapSite]],
    singles: list[MapSite],
) -> tuple[list[tuple[MapSite, MapSite]], list[MapSite]]:
    """
    Greedy, local improvement:
      - size 2: try the single swap; keep if global lex signature improves
      - size 3: brute-force all 3! renames; keep the best if it strictly improves
      - size >=4: skip (do not permute)
    """
    site_eq = _auto_site_equivalences_connectivity_global(
        TrexFull(
            metal=t_like.metal,
            ox=t_like.ox,
            spin=t_like.spin,
            ligands=t_like.ligands,
            pairs=pairs,
            singles=singles,
            G=t_like.G,
            X=t_like.X,
        )
    )

    base_sig = _lex_signature(pairs, singles)

    for lig, classes in (site_eq or {}).items():
        for cls in classes:
            # unique site tuples in this class that are actually used
            used_all = set()
            for a, b in pairs:
                if a.lig == lig:
                    used_all.add(tuple(sorted(a.atoms)))
                if b.lig == lig:
                    used_all.add(tuple(sorted(b.atoms)))
            for s in singles:
                if s.lig == lig:
                    used_all.add(tuple(sorted(s.atoms)))
            used = sorted(t for t in (tuple(sorted(x)) for x in cls) if t in used_all)
            if len(used) <= 1:
                continue

            if len(used) == 2:
                a, b = used
                swap = {a: b, b: a}
                cand_pairs, cand_singles = _apply_site_renames_for_lig(pairs, singles, lig, swap)
                sig = _lex_signature(cand_pairs, cand_singles)
                if sig < base_sig:
                    pairs, singles, base_sig = cand_pairs, cand_singles, sig

            elif len(used) == 3:
                # full 3! search; keep strict lex improvement
                best_sig = base_sig
                best_map = None
                for perm in permutations(used):
                    if list(perm) == used:
                        continue  # skip identity
                    rename = {cur: new for cur, new in zip(used, perm, strict=False)}
                    cand_pairs, cand_singles = _apply_site_renames_for_lig(
                        pairs, singles, lig, rename
                    )
                    sig = _lex_signature(cand_pairs, cand_singles)
                    if sig < best_sig:
                        best_sig = sig
                        best_map = rename
                if best_map:
                    pairs, singles = _apply_site_renames_for_lig(pairs, singles, lig, best_map)
                    base_sig = best_sig

            else:
                # len(used) >= 4 do nothing (avoid trans-pair flips)
                continue

    return pairs, singles


def _apply_perm(payloads, pairs, singles, mapping):
    """
    Apply a ligand permutation.
    Uses _remap_lig_indices which PRESERVES coord attributes.
    """
    n = len(payloads)

    # Promote to full map: all ligands default to identity
    full_map: dict[int, int] = {i: i for i in range(1, n + 1)}
    full_map.update(mapping)

    # Remap payloads
    out_payloads = [None] * n
    for old in range(1, n + 1):
        new = full_map[old]
        out_payloads[new - 1] = payloads[old - 1]

    # Remap pairs/singles and normalize (coord preserved via _remap_lig_indices)
    pairs2, singles2 = _remap_lig_indices(pairs, singles, full_map)

    norm_pairs = []
    for a, b in pairs2:
        aa, bb = (a, b) if (a.lig, a.atoms) <= (b.lig, b.atoms) else (b, a)
        norm_pairs.append((aa, bb))
    norm_pairs.sort(key=lambda ab: ((ab[0].lig, ab[0].atoms), (ab[1].lig, ab[1].atoms)))
    singles2.sort(key=lambda s: (s.lig, s.atoms))

    return out_payloads, norm_pairs, singles2


def _minimize_identical_ligands(payloads, pairs, singles):
    """
    Greedy global lex-min over each identical-ligand class (k<=6 brute force).

    CRITICAL: We only group ligands if they are identical in Text,
    Denticity, Hapticity, AND Coordination Mass.
    This prevents re-ordering ligands that have the same SMILES but different
    binding modes (e.g. eta-1 vs eta-2), preserving the rigorous sort order
    established in canonicalize_full.
    """
    from collections import defaultdict

    # 1. Re-collect sites to calculate binding properties
    sites_by_lig = _collect_sites_by_lig(pairs, singles)

    base_sig = _lex_signature(pairs, singles)
    classes = defaultdict(list)

    for i, pl in enumerate(payloads, start=1):
        # Calculate distinguishing binding metrics
        dent = _denticity_for_lig(i, sites_by_lig)
        hap = _max_hapticity_for_lig(i, sites_by_lig)

        cmw = 0.0
        if pl.kind == "SMILES":
            # Calculate coord mass to distinguish linkage isomers
            # or different coordination sites if atoms differ.
            site_positions = sorted({pos for site in sites_by_lig.get(i, []) for pos in site})
            cmw = _coord_mass_for_ligand_smi(pl.text, site_positions)

        # Group by (Kind, Text, BindingProperties)
        key = (pl.kind, pl.text, dent, hap, cmw)
        classes[key].append(i)

    # process classes in ascending smallest index for determinism
    for _, ligs in sorted(classes.items(), key=lambda kv: min(kv[1])):
        if len(ligs) < 2:
            continue
        slots = sorted(ligs)
        best_sig = base_sig
        best_map = None

        if len(slots) <= 6:  # 720 perms worst-case; fine for coordination chemistry
            for perm in permutations(slots):
                local = {old: new for old, new in zip(slots, perm, strict=False)}
                _, p2, s2 = _apply_perm(payloads, pairs, singles, local)
                sig = _lex_signature(p2, s2)
                if sig < best_sig:
                    best_sig, best_map = sig, local
        else:
            # fallback:
            usage = {li: [] for li in slots}
            for a, b in pairs:
                if a.lig in usage:
                    usage[a.lig].append((0, b.lig, tuple(b.atoms), tuple(a.atoms)))
                if b.lig in usage:
                    usage[b.lig].append((0, a.lig, tuple(a.atoms), tuple(b.atoms)))
            for s in singles:
                if s.lig in usage:
                    usage[s.lig].append((1, float("inf"), (), tuple(s.atoms)))
            ranked = sorted(
                ((tuple(sorted(v)), li) for li, v in usage.items()), key=lambda x: (x[0], x[1])
            )
            best_map = {old: new for new, (_, old) in zip(slots, ranked, strict=False)}
            _, p2, s2 = _apply_perm(payloads, pairs, singles, best_map)
            if _lex_signature(p2, s2) >= best_sig:
                best_map = None  # don't worsen

        if best_map:
            payloads, pairs, singles = _apply_perm(payloads, pairs, singles, best_map)
            base_sig = best_sig

    return payloads, pairs, singles


# ---------------- main canonicalizer ----------------


def canonicalize_full(t: TrexFull) -> TrexFull:
    """
    Canonicalize a T-REX Full object:
      0) PRE-PROCESSING: Fix common charge errors (nitro groups, hydride)
      1) Per-SMILES ligand canonicalization + remap site indices to the new writing order.
      2) Recompute sites; rank ligands by:
           denticity ↓, max hapticity ↓, coordinating-atom mass ↓, ligand mass ↓, WL hash
      3) Remap ligand indices accordingly.
      4) Minimize the MAP over identical ligands (smaller ligand indices get lexicographically
         smaller usages). Then apply a FULL mapping (identity+perm) to pairs/singles.
      5) Geometry validation: only keep/emit 'O' when CN==6; else omit G.

    NOTE: This function PRESERVES coord attributes on MapSite objects throughout
    all transformations, enabling chirality computation after canonicalization.
    """
    # ---- STEP 0: Fix ligand charges BEFORE any index tracking ----
    # Nitro: N([O-])[O-] → [N+](=O)[O-], ox decreases by 2
    # Hydride: [H+] → [H-], ox increases by 2
    t = _fix_ligand_charges(t)

    # collect sites from the input (which indices to remap)
    # sites_by_lig_input = _collect_sites_by_lig(t.pairs, t.singles)

    # per-ligand canonicalization + within-ligand atom-index remap
    new_payloads: list[LigandPayload] = list(t.ligands)
    per_lig_remap: dict[int, dict[int, int]] = {}

    need_by_lig: dict[int, set[int]] = {}
    for a, b in t.pairs:
        need_by_lig.setdefault(a.lig, set()).update(a.atoms)
        need_by_lig.setdefault(b.lig, set()).update(b.atoms)
    for s in t.singles:
        need_by_lig.setdefault(s.lig, set()).update(s.atoms)

    for lig_idx, payload in enumerate(t.ligands, start=1):
        needed = need_by_lig.get(lig_idx, set())
        new_pl, idx_map_1b = _remap_atoms_for_ligand(payload, needed)
        new_payloads[lig_idx - 1] = new_pl
        per_lig_remap[lig_idx] = idx_map_1b

    pairs1, singles1 = _apply_within_ligand_remap(t.pairs, t.singles, per_lig_remap)

    # recompute sites (canonical SMILES positions)
    sites_by_lig = _collect_sites_by_lig(pairs1, singles1)

    # ligand-level metrics
    coord_mass_by_lig: dict[int, float] = {}
    lig_mass_by_lig: dict[int, float] = {}
    hash_by_lig: dict[int, str] = {}

    for lig_idx, pl in enumerate(new_payloads, start=1):
        if pl.kind == "SMILES":
            smi = pl.text
            site_positions = sorted({pos for site in sites_by_lig.get(lig_idx, []) for pos in site})
            coord_mass_by_lig[lig_idx] = _coord_mass_for_ligand_smi(smi, site_positions)
            lig_mass_by_lig[lig_idx] = _lig_exact_mass_from_smi(smi)
            hash_by_lig[lig_idx] = _hash_from_smiles(smi)
        else:
            coord_mass_by_lig[lig_idx] = 0.0
            lig_mass_by_lig[lig_idx] = 0.0
            hash_by_lig[lig_idx] = f"TXT:{pl.text}"

    def _key(lig_idx: int) -> tuple[int, int, float, float, str]:
        dent = _denticity_for_lig(lig_idx, sites_by_lig)
        hap = _max_hapticity_for_lig(lig_idx, sites_by_lig)
        cmw = coord_mass_by_lig.get(lig_idx, 0.0)
        lmw = lig_mass_by_lig.get(lig_idx, 0.0)
        h = hash_by_lig.get(lig_idx, "")
        return (-dent, -hap, -cmw, -lmw, h)

    order = sorted(range(1, len(new_payloads) + 1), key=_key)
    order_map = {old: i + 1 for i, old in enumerate(order)}

    # reorder payloads and remap ligand indices in MAP
    payloads2 = [new_payloads[old - 1] for old in order]
    pairs2, singles2 = _remap_lig_indices(pairs1, singles1, order_map)

    # ---------- collapse internal site symmetry (rename within ligands) ----------
    pairs2, singles2 = _collapse_internal_symmetry_in_map(
        TrexFull(
            metal=t.metal,
            ox=t.ox,
            spin=t.spin,
            ligands=payloads2,
            pairs=pairs2,
            singles=singles2,
            G=t.G,
            X=t.X,
        ),
        pairs2,
        singles2,
    )

    # ---------- identical-ligand minimization ----------

    payloads3, pairs3, singles3 = _minimize_identical_ligands(payloads2, pairs2, singles2)

    # geometry validation (emit only 'O' when CN==6)
    if t.G == "TP":
        G2 = "TP"
    else:
        G2 = _validated_geometry(pairs3, singles3)

    # ---------- pentagonal bipyramidal rotation ordering ----------
    # For pntbp (1 pair, 5 singles), order singles by CCW rotation
    # This must happen AFTER all ligand reordering is complete
    singles_final = singles3
    if len(pairs3) == 1 and len(singles3) == 5:
        singles_final, was_reordered = _canonicalize_pntbp_singles(pairs3, singles3)
        if was_reordered:
            G2 = "pntbp"  # Mark that rotation ordering was applied

    return TrexFull(
        metal=t.metal,
        ox=t.ox,
        spin=t.spin,
        ligands=payloads3,
        pairs=pairs3,
        singles=singles_final,
        G=G2,
        X=t.X,
    )


# Pretty printer
def pretty_trex_full(t: TrexFull) -> str:
    """
    Pretty-print a TrexFull with bracketed haptic sites.
    - Pairs are shown as (A, B)
    - Multi-atom sites use brackets: lig:[i,j,k]
    - Single-atom sites: lig:i
    - Empty sites (shouldn't occur): lig
    - Geometry 'G' emitted only when CN == 6 (via _validated_geometry)
    """
    lig = ", ".join(f"{p.kind}:{p.text}" for p in t.ligands)

    def _site(s: MapSite) -> str:
        if not s.atoms:
            return f"{s.lig}"
        if len(s.atoms) == 1:
            return f"{s.lig}:{s.atoms[0]}"
        return f"{s.lig}:[{','.join(str(x) for x in s.atoms)}]"

    pairs = ", ".join(f"({_site(a)}, {_site(b)})" for a, b in t.pairs)
    singles = ", ".join(_site(s) for s in t.singles)

    # geometry policy (only 'O' when CN == 6)
    if t.G is not None:
        Gout = t.G
    else:
        Gout = _validated_geometry(t.pairs, t.singles)

    ox = f"+{t.ox}" if t.ox > 0 else str(t.ox)
    tail = []
    if Gout:
        tail.append(f"G:{Gout}")
    if t.X:
        tail.append(f"X:{t.X}")
    tail_s = f" | {' | '.join(tail)}" if tail else ""

    # MAP section keeps ';' separator even if singles is empty
    return (
        f"{t.metal}{{{ox}{'' if t.spin is None else f',S={t.spin}'}}} | "
        f"L=[ {lig} ] | "
        f"MAP:{{ {pairs}{'' if not singles else ('; ' if pairs else '') + singles} }}{tail_s}"
    )
