# trex/chirality.py
"""
Chirality computation for T-REX transition metal complexes.

This module computes metal-centered POINT CHIRALITY using the determinant method.
It only handles all-monodentate complexes. Multidentate complexes (Δ/Λ chirality)
should be handled separately since that's helical chirality, not point-central.

Supported geometries (all-monodentate only):
- Tetrahedral (4 singles, 0 pairs)
- Trigonal bipyramidal (3 singles, 1 pair)
- Square pyramidal (1 single, 2 pairs)
- Octahedral (0 singles, 3 pairs)
"""

from __future__ import annotations

import numpy as np

from .model import MapSite, TrexFull

# -----------------------------------------------------------------------------
# Import equivalence machinery from canon_full (same logic used for sorting)
# -----------------------------------------------------------------------------


def _collect_sites_by_lig(
    pairs: list[tuple[MapSite, MapSite]],
    singles: list[MapSite],
) -> dict[int, list[tuple[int, ...]]]:
    """
    Build a map: lig_index -> list of (sorted, deduped) atom-tuples representing unique sites.
    """
    per_lig: dict[int, set[tuple[int, ...]]] = {}

    def add_site(s: MapSite):
        per_lig.setdefault(s.lig, set()).add(tuple(sorted(set(s.atoms))))

    for a, b in pairs:
        add_site(a)
        add_site(b)
    for s in singles:
        add_site(s)
    return {k: [t for t in v if t] for k, v in per_lig.items()}


def _denticity_for_lig(lig: int, sites_by_lig: dict[int, list[tuple[int, ...]]]) -> int:
    """Number of coordination sites from this ligand."""
    return len(sites_by_lig.get(lig, []))


def _max_hapticity_for_lig(lig: int, sites_by_lig: dict[int, list[tuple[int, ...]]]) -> int:
    """Maximum number of atoms in any single site from this ligand."""
    sites = sites_by_lig.get(lig, [])
    return max((len(s) for s in sites), default=0)


def _coord_mass_for_ligand_smi(smi: str, site_positions_1b: list[int]) -> float:
    """Sum of average atomic weights for the unique coordinating atoms."""
    from rdkit import Chem

    m = Chem.MolFromSmiles(smi)
    if m is None:
        return 0.0

    # Get writing order -> RDKit index mapping
    m2 = Chem.Mol(m)
    for a in m2.GetAtoms():
        a.SetAtomMapNum(a.GetIdx() + 1)
    s = Chem.MolToSmiles(m2, canonical=True, isomericSmiles=True)
    import re

    ids = [int(x) - 1 for x in re.findall(r":(\d+)\]", s)]

    if not ids and m2.GetNumAtoms() == 1:
        pos_to_rd = [0]
    elif len(ids) != m2.GetNumAtoms():
        ranks = Chem.CanonicalRankAtoms(m)
        pos_to_rd = sorted(range(m.GetNumAtoms()), key=lambda i: (ranks[i], i))
    else:
        pos_to_rd = ids

    pt = Chem.GetPeriodicTable()
    rd_ids = set()
    for p1 in set(site_positions_1b):
        p0 = p1 - 1
        if 0 <= p0 < len(pos_to_rd):
            rd_ids.add(pos_to_rd[p0])

    mass = 0.0
    for rid in rd_ids:
        z = m.GetAtomWithIdx(rid).GetAtomicNum()
        mass += pt.GetAtomicWeight(z)
    return float(mass)


# -----------------------------------------------------------------------------
# Site equivalence using canonical rank symmetry (same as canon_full)
# -----------------------------------------------------------------------------


def _get_site_equivalence_classes(t: TrexFull) -> dict[int, list[list[tuple[int, ...]]]]:
    """
    Discover internal site equivalence classes per ligand using global
    canonical rank symmetry on a charge-blind connectivity graph.

    This is the same logic as _auto_site_equivalences_connectivity_global in canon_full.
    """
    from rdkit import Chem
    from rdkit.Chem import rdmolfiles as _rdmolfiles

    def _conn_chargeblind_with_Hs(mol: Chem.Mol) -> Chem.Mol:
        """Connectivity-only, charge-blind copy with explicit hydrogens."""
        mh = Chem.AddHs(Chem.Mol(mol), addCoords=False)
        try:
            mh.UpdatePropertyCache(strict=False)
        except Exception:
            pass
        for b in mh.GetBonds():
            b.SetBondType(Chem.BondType.SINGLE)
            b.SetIsAromatic(False)
            b.SetStereo(Chem.BondStereo.STEREONONE)
        for a in mh.GetAtoms():
            a.SetIsAromatic(False)
            a.SetFormalCharge(0)
        return mh

    def _refine_by_rank_classes_chargeblind(
        smi: str, classes: list[list[tuple[int, ...]]]
    ) -> list[list[tuple[int, ...]]]:
        """
        Confirm/derive site equivalence using canonical symmetry classes.
        Two sites are equivalent if their multisets of canonical ranks match.
        """
        m = Chem.MolFromSmiles(smi)
        if not m:
            return []

        m2 = _conn_chargeblind_with_Hs(m)
        ranks = _rdmolfiles.CanonicalRankAtoms(
            m2,
            breakTies=False,
            includeChirality=True,
            includeIsotopes=True,
        )

        def sig(site1b: tuple[int, ...]) -> tuple[int, ...]:
            return tuple(sorted(ranks[a - 1] for a in site1b if a >= 1))

        refined: list[list[tuple[int, ...]]] = []
        for cls in classes:
            buckets: dict[tuple[int, ...], list[tuple[int, ...]]] = {}
            for s in cls:
                buckets.setdefault(sig(s), []).append(tuple(sorted(s)))
            for group in buckets.values():
                if len(group) > 1:
                    refined.append(sorted(group))
        return refined

    out: dict[int, list[list[tuple[int, ...]]]] = {}
    per_lig = _collect_sites_by_lig(t.pairs, t.singles)

    for lig_idx, sites in per_lig.items():
        if not sites:
            continue
        pl = t.ligands[lig_idx - 1]
        if pl.kind != "SMILES":
            continue
        refined = _refine_by_rank_classes_chargeblind(pl.text, [sites])
        if refined:
            out[lig_idx] = refined

    return out


def _ligands_are_equivalent(
    t: TrexFull,
    lig_a: int,
    lig_b: int,
    sites_by_lig: dict[int, list[tuple[int, ...]]],
) -> bool:
    """
    Check if two ligands are equivalent using the same criteria as canonicalization:
    same kind, text, denticity, hapticity, and coord mass.
    """
    if lig_a == lig_b:
        return True

    pl_a = t.ligands[lig_a - 1]
    pl_b = t.ligands[lig_b - 1]

    if pl_a.kind != pl_b.kind or pl_a.text != pl_b.text:
        return False

    if _denticity_for_lig(lig_a, sites_by_lig) != _denticity_for_lig(lig_b, sites_by_lig):
        return False

    if _max_hapticity_for_lig(lig_a, sites_by_lig) != _max_hapticity_for_lig(lig_b, sites_by_lig):
        return False

    # Check coord mass
    if pl_a.kind == "SMILES":
        pos_a = sorted({pos for site in sites_by_lig.get(lig_a, []) for pos in site})
        pos_b = sorted({pos for site in sites_by_lig.get(lig_b, []) for pos in site})
        cmw_a = _coord_mass_for_ligand_smi(pl_a.text, pos_a)
        cmw_b = _coord_mass_for_ligand_smi(pl_b.text, pos_b)
        if abs(cmw_a - cmw_b) > 0.01:
            return False

    return True


def _sites_are_equivalent(
    t: TrexFull,
    site_a: MapSite,
    site_b: MapSite,
    sites_by_lig: dict[int, list[tuple[int, ...]]],
    equiv_classes: dict[int, list[list[tuple[int, ...]]]],
) -> bool:
    """
    Check if two coordination sites are chemically equivalent.
    Uses the same logic as canonicalization for both ligand and site equivalence.
    """
    atoms_a = tuple(sorted(site_a.atoms))
    atoms_b = tuple(sorted(site_b.atoms))

    # Same ligand - check if atoms are in same equivalence class
    if site_a.lig == site_b.lig:
        if atoms_a == atoms_b:
            return True
        classes = equiv_classes.get(site_a.lig, [])
        for cls in classes:
            if atoms_a in cls and atoms_b in cls:
                return True
        return False

    # Different ligands - first check if ligands are equivalent
    if not _ligands_are_equivalent(t, site_a.lig, site_b.lig, sites_by_lig):
        return False

    # Ligands are equivalent - check if atom positions correspond to equivalent sites
    # For equivalent ligands with identical SMILES, equivalent positions mean equivalent sites
    if atoms_a == atoms_b:
        return True

    # Check if both are in corresponding equivalence classes
    classes_a = equiv_classes.get(site_a.lig, [])
    classes_b = equiv_classes.get(site_b.lig, [])

    # Find which class each belongs to (by index)
    def find_class_idx(atoms: tuple[int, ...], classes: list[list[tuple[int, ...]]]) -> int | None:
        for i, cls in enumerate(classes):
            if atoms in cls:
                return i
        return None

    idx_a = find_class_idx(atoms_a, classes_a)
    idx_b = find_class_idx(atoms_b, classes_b)

    # If both in equivalence classes with matching structure, consider equivalent
    if idx_a is not None and idx_b is not None:
        # For identical ligands, matching class indices means equivalent
        return idx_a == idx_b

    return False


def _pairs_are_equivalent(
    t: TrexFull,
    pair1: tuple[MapSite, MapSite],
    pair2: tuple[MapSite, MapSite],
    sites_by_lig: dict[int, list[tuple[int, ...]]],
    equiv_classes: dict[int, list[list[tuple[int, ...]]]],
) -> bool:
    """
    Check if two trans pairs are equivalent: (A,B) ≡ (C,D).
    Two pairs are equivalent if (A≡C and B≡D) OR (A≡D and B≡C).
    """
    a1, b1 = pair1
    a2, b2 = pair2

    same_order = _sites_are_equivalent(
        t, a1, a2, sites_by_lig, equiv_classes
    ) and _sites_are_equivalent(t, b1, b2, sites_by_lig, equiv_classes)
    swap_order = _sites_are_equivalent(
        t, a1, b2, sites_by_lig, equiv_classes
    ) and _sites_are_equivalent(t, b1, a2, sites_by_lig, equiv_classes)

    return same_order or swap_order


# -----------------------------------------------------------------------------
# Chirality detection
# -----------------------------------------------------------------------------


def _signed_volume(p1: np.ndarray, p2: np.ndarray, p3: np.ndarray, p4: np.ndarray) -> float:
    """
    Compute signed volume of tetrahedron formed by 4 points.

    Equivalent to det([x1,y1,z1,1; x2,y2,z2,1; x3,y3,z3,1; x4,y4,z4,1])
    which equals (p2-p1) · ((p3-p1) × (p4-p1))
    """
    v1 = p2 - p1
    v2 = p3 - p1
    v3 = p4 - p1
    return float(np.dot(v1, np.cross(v2, v3)))


def _get_coord(site: MapSite) -> np.ndarray:
    """Extract coordinate from MapSite, raising error if missing."""
    if site.coord is None:
        raise ValueError(
            f"MapSite (lig={site.lig}, atoms={site.atoms}) missing coordinate "
            "for chirality computation. Ensure coordinates are populated before canonicalization."
        )
    return np.array(site.coord)


def _is_all_monodentate(t: TrexFull) -> bool:
    """Check if all ligands are monodentate (each contributes exactly 1 site)."""
    sites_by_lig = _collect_sites_by_lig(t.pairs, t.singles)

    # Check that each ligand contributes exactly 1 site
    for lig_idx in range(1, len(t.ligands) + 1):
        if _denticity_for_lig(lig_idx, sites_by_lig) != 1:
            return False

    return True


def is_chiral(t: TrexFull) -> bool:
    """
    Determine if the complex has point-central chirality.

    This works for ALL complexes (mono and multidentate). The achirality
    conditions are based on site equivalence, which correctly handles
    multidentate ligands (e.g., two N atoms from en are equivalent sites).

    Note: Tris-bidentate complexes like [M(en)₃] will return False here
    (all sites equivalent → achiral by point-central logic) but are
    actually Δ/Λ chiral. Helical chirality should be handled separately.

    Returns:
        True: Complex is point-chiral
        False: Complex is not point-chiral (may still be Δ/Λ chiral)

    Achirality conditions:

    Tetrahedral (4 singles):
        - Achiral if any two singles are equivalent

    Trigonal bipyramidal (1 pair, 3 singles):
        - Achiral if axial trans partners are equivalent
        - Achiral if any two equatorial singles are equivalent

    Square pyramidal (2 pairs, 1 single):
        - Achiral if any trans partners within a pair are equivalent
        - Achiral if the two basal pairs are equivalent to each other

    Octahedral (3 pairs, 0 singles):
        - Achiral if any trans partners within a pair are equivalent
        - Achiral if the two equatorial pairs are equivalent to each other
    """
    geom = t.get_geo_type()
    n_pairs = len(t.pairs)
    n_singles = len(t.singles)

    # Precompute equivalence data (same as canonicalization uses)
    sites_by_lig = _collect_sites_by_lig(t.pairs, t.singles)
    equiv_classes = _get_site_equivalence_classes(t)

    def sites_equiv(a: MapSite, b: MapSite) -> bool:
        return _sites_are_equivalent(t, a, b, sites_by_lig, equiv_classes)

    def pairs_equiv(p1: tuple[MapSite, MapSite], p2: tuple[MapSite, MapSite]) -> bool:
        return _pairs_are_equivalent(t, p1, p2, sites_by_lig, equiv_classes)

    # ---------- Tetrahedral ----------
    if geom == "thd" and n_pairs == 0 and n_singles == 4:
        for i in range(4):
            for j in range(i + 1, 4):
                if sites_equiv(t.singles[i], t.singles[j]):
                    return False
        return True

    # ---------- Trigonal Bipyramidal ----------
    elif geom == "trbp" and n_pairs == 1 and n_singles == 3:
        # Axial trans partners must be different
        a, b = t.pairs[0]
        if sites_equiv(a, b):
            return False

        # All 3 equatorial singles must be distinct
        for i in range(3):
            for j in range(i + 1, 3):
                if sites_equiv(t.singles[i], t.singles[j]):
                    return False
        return True

    # ---------- Square Pyramidal ----------
    elif geom == "sqpy" and n_pairs == 2 and n_singles == 1:
        # Each basal trans pair must have different partners
        for a, b in t.pairs:
            if sites_equiv(a, b):
                return False

        # The two basal pairs must not be equivalent
        if pairs_equiv(t.pairs[0], t.pairs[1]):
            return False

        return True

    # ---------- Octahedral ----------
    elif geom == "O" and n_pairs == 3:
        # All trans partners must be different
        for a, b in t.pairs:
            if sites_equiv(a, b):
                return False

        # Any two pairs being equivalent creates a C2 axis → achiral
        # Must check ALL pair combinations, not just "equatorial" pairs
        for i in range(3):
            for j in range(i + 1, 3):
                if pairs_equiv(t.pairs[i], t.pairs[j]):
                    return False

        return True

    # Unsupported geometry
    return False


def compute_chirality(t: TrexFull) -> str | None:
    """
    Compute chirality flag for a canonical TrexFull with coordinates.

    This is the main entry point for chirality computation. It checks:
    1. Point-central chirality first → returns "@" or "@@"
    2. Helical chirality second → returns "Δ" or "Λ"
    3. Neither → returns None

    Args:
        t: Canonical TrexFull object with coord attributes populated on MapSites

    Returns:
        "@" or "@@" for point-chiral complexes
        "Δ" or "Λ" for helically chiral complexes
        None for achiral complexes

    Point selection rules for @/@@ (viewing from point 1 toward metal center):

    Tetrahedral:
        - pt1: singleton 0 (highest priority)
        - pt2, pt3, pt4: singletons 1, 2, 3 (by canonical order)

    Trigonal Bipyramidal:
        - pt1: first axial partner (pair[0][0])
        - pt2, pt3, pt4: equatorial singles 0, 1, 2

    Square Pyramidal:
        - pt1: singleton (apex)
        - pt2: first of basal pair 0
        - pt3: first of basal pair 1
        - pt4: second of basal pair 0 (trans partner of pt2)

    Octahedral:
        - pt1: first of axial pair (pair[0][0])
        - pt2: first of equatorial pair 1 (pair[1][0])
        - pt3: first of equatorial pair 2 (pair[2][0])
        - pt4: second of equatorial pair 1 (pair[1][1], trans partner of pt2)
    """
    # Check point-central chirality first
    if is_chiral(t):
        return _compute_point_chirality(t)

    # Check helical chirality second
    if has_helical_chirality(t):
        return compute_delta_lambda(t)

    # Neither
    return None


def _compute_point_chirality(t: TrexFull) -> str | None:
    """
    Compute point-central chirality (@/@@) using the determinant method.

    Should only be called after is_chiral() returns True.
    """
    geom = t.get_geo_type()
    n_pairs = len(t.pairs)
    n_singles = len(t.singles)

    # ---------- Tetrahedral ----------
    if geom == "thd" and n_pairs == 0 and n_singles == 4:
        pt1 = _get_coord(t.singles[0])
        pt2 = _get_coord(t.singles[1])
        pt3 = _get_coord(t.singles[2])
        pt4 = _get_coord(t.singles[3])

    # ---------- Trigonal Bipyramidal ----------
    elif geom == "trbp" and n_pairs == 1 and n_singles == 3:
        pt1 = _get_coord(t.pairs[0][0])  # axial (looking down from here)
        pt2 = _get_coord(t.singles[0])  # equatorial 1
        pt3 = _get_coord(t.singles[1])  # equatorial 2
        pt4 = _get_coord(t.singles[2])  # equatorial 3

    # ---------- Square Pyramidal ----------
    elif geom == "sqpy" and n_pairs == 2 and n_singles == 1:
        pt1 = _get_coord(t.singles[0])  # apex (looking down from here)
        pt2 = _get_coord(t.pairs[0][0])  # first of basal pair 1
        pt3 = _get_coord(t.pairs[1][0])  # first of basal pair 2
        pt4 = _get_coord(t.pairs[0][1])  # trans partner of pt2

    # ---------- Octahedral ----------
    elif geom == "O" and n_pairs == 3:
        pt1 = _get_coord(t.pairs[0][0])  # axial (looking down from here)
        pt2 = _get_coord(t.pairs[1][0])  # first of equatorial pair 1
        pt3 = _get_coord(t.pairs[2][0])  # first of equatorial pair 2
        pt4 = _get_coord(t.pairs[1][1])  # trans partner of pt2

    else:
        return None

    # Compute signed volume
    sign = _signed_volume(pt1, pt2, pt3, pt4)

    # Degenerate case (coplanar points)
    if abs(sign) < 1e-10:
        return None

    return "@" if sign > 0 else "@@"


def has_coordinates(t: TrexFull) -> bool:
    """Check if all MapSites in the TrexFull have coordinates."""
    for a, b in t.pairs:
        if a.coord is None or b.coord is None:
            return False
    for s in t.singles:
        if s.coord is None:
            return False
    return True


def assign_idealized_coordinates(t: TrexFull, chirality: str | None = None) -> TrexFull:
    """
    Assign idealized coordinates to a TrexFull based on geometry and chirality flag.

    This encodes chirality into the coordinates themselves, allowing it to survive
    canonicalization and ligand substitution operations. The coordinates are chosen
    to be consistent with compute_chirality()'s point selection, so that:
    - assign_idealized_coordinates(t, "@") followed by compute_chirality() returns "@"
    - assign_idealized_coordinates(t, "@@") followed by compute_chirality() returns "@@"

    Args:
        t: TrexFull object (coords will be set/overwritten)
        chirality: "@", "@@", or None.
                   If None and complex is chiral, defaults to "@".
                   If None and complex is achiral, no chirality is assigned.

    Returns:
        New TrexFull with idealized coordinates on all MapSites
    """
    import math

    geom = t.get_geo_type()
    n_pairs = len(t.pairs)
    n_singles = len(t.singles)

    # Check if we should assign chirality
    if chirality is None:
        if is_chiral(t):
            chirality = "@"  # default to @ for chiral complexes
        # else leave as None for achiral

    new_pairs: list[tuple[MapSite, MapSite]] = []
    new_singles: list[MapSite] = []

    # ---------- Octahedral ----------
    if geom == "O" and n_pairs == 3 and n_singles == 0:
        # Pair 0: Z-axis (axial)
        # Pair 1: X-axis (equatorial)
        # Pair 2: Y-axis (equatorial) - orientation encodes chirality
        #
        # Point selection in compute_chirality:
        #   pt1 = pairs[0][0] = (0, 0, 1)
        #   pt2 = pairs[1][0] = (1, 0, 0)
        #   pt3 = pairs[2][0] = (0, ±1, 0)  ← this determines chirality
        #   pt4 = pairs[1][1] = (-1, 0, 0)
        #
        # Signed volume with pt3=(0,-1,0) → positive → @
        # Signed volume with pt3=(0,+1,0) → negative → @@

        coords = {
            (0, 0): (0.0, 0.0, 1.0),
            (0, 1): (0.0, 0.0, -1.0),
            (1, 0): (1.0, 0.0, 0.0),
            (1, 1): (-1.0, 0.0, 0.0),
        }

        if chirality == "@@":
            coords[(2, 0)] = (0.0, 1.0, 0.0)
            coords[(2, 1)] = (0.0, -1.0, 0.0)
        else:  # @ or achiral (use @ orientation as default)
            coords[(2, 0)] = (0.0, -1.0, 0.0)
            coords[(2, 1)] = (0.0, 1.0, 0.0)

        for pair_idx, (a, b) in enumerate(t.pairs):
            new_a = MapSite(lig=a.lig, atoms=list(a.atoms), coord=coords[(pair_idx, 0)])
            new_b = MapSite(lig=b.lig, atoms=list(b.atoms), coord=coords[(pair_idx, 1)])
            new_pairs.append((new_a, new_b))

    # ---------- Square Pyramidal ----------
    elif geom == "sqpy" and n_pairs == 2 and n_singles == 1:
        # Single: apex on +Z
        # Pair 0: X-axis (basal)
        # Pair 1: Y-axis (basal) - orientation encodes chirality
        #
        # Point selection in compute_chirality:
        #   pt1 = singles[0] = (0, 0, 1)  (apex)
        #   pt2 = pairs[0][0] = (1, 0, 0)
        #   pt3 = pairs[1][0] = (0, ±1, 0)  ← this determines chirality
        #   pt4 = pairs[0][1] = (-1, 0, 0)

        s = t.singles[0]
        new_singles.append(MapSite(lig=s.lig, atoms=list(s.atoms), coord=(0.0, 0.0, 1.0)))

        # Pair 0 on X-axis
        a, b = t.pairs[0]
        new_pairs.append(
            (
                MapSite(lig=a.lig, atoms=list(a.atoms), coord=(1.0, 0.0, 0.0)),
                MapSite(lig=b.lig, atoms=list(b.atoms), coord=(-1.0, 0.0, 0.0)),
            )
        )

        # Pair 1 on Y-axis
        a, b = t.pairs[1]
        if chirality == "@@":
            new_pairs.append(
                (
                    MapSite(lig=a.lig, atoms=list(a.atoms), coord=(0.0, 1.0, 0.0)),
                    MapSite(lig=b.lig, atoms=list(b.atoms), coord=(0.0, -1.0, 0.0)),
                )
            )
        else:
            new_pairs.append(
                (
                    MapSite(lig=a.lig, atoms=list(a.atoms), coord=(0.0, -1.0, 0.0)),
                    MapSite(lig=b.lig, atoms=list(b.atoms), coord=(0.0, 1.0, 0.0)),
                )
            )

    # ---------- Trigonal Bipyramidal ----------
    elif geom == "trbp" and n_pairs == 1 and n_singles == 3:
        # Pair 0: Z-axis (axial)
        # Singles: equatorial at 120° apart in XY plane
        #
        # Point selection in compute_chirality:
        #   pt1 = pairs[0][0] = (0, 0, 1)
        #   pt2 = singles[0]
        #   pt3 = singles[1]
        #   pt4 = singles[2]
        #
        # Chirality determined by CW vs CCW ordering of equatorial ligands

        a, b = t.pairs[0]
        new_pairs.append(
            (
                MapSite(lig=a.lig, atoms=list(a.atoms), coord=(0.0, 0.0, 1.0)),
                MapSite(lig=b.lig, atoms=list(b.atoms), coord=(0.0, 0.0, -1.0)),
            )
        )

        # Equatorial at 0°, 120°, 240° or 0°, 240°, 120° (reversed)
        if chirality == "@@":
            angles = [0.0, 240.0, 120.0]  # reversed order
        else:
            angles = [0.0, 120.0, 240.0]  # standard CCW

        for i, s in enumerate(t.singles):
            angle_rad = math.radians(angles[i])
            coord = (math.cos(angle_rad), math.sin(angle_rad), 0.0)
            new_singles.append(MapSite(lig=s.lig, atoms=list(s.atoms), coord=coord))

    # ---------- Tetrahedral ----------
    elif geom == "thd" and n_pairs == 0 and n_singles == 4:
        # Tetrahedral vertices - two enantiomeric arrangements
        #
        # Point selection in compute_chirality:
        #   pt1 = singles[0]
        #   pt2 = singles[1]
        #   pt3 = singles[2]
        #   pt4 = singles[3]
        #
        # Standard tetrahedron vertices (normalized)

        sqrt3 = math.sqrt(3.0)

        if chirality == "@@":
            # Mirror image tetrahedron
            coords = [
                (1.0 / sqrt3, 1.0 / sqrt3, 1.0 / sqrt3),
                (1.0 / sqrt3, -1.0 / sqrt3, -1.0 / sqrt3),
                (-1.0 / sqrt3, -1.0 / sqrt3, 1.0 / sqrt3),
                (-1.0 / sqrt3, 1.0 / sqrt3, -1.0 / sqrt3),
            ]
        else:
            # Standard tetrahedron
            coords = [
                (1.0 / sqrt3, 1.0 / sqrt3, 1.0 / sqrt3),
                (1.0 / sqrt3, -1.0 / sqrt3, -1.0 / sqrt3),
                (-1.0 / sqrt3, 1.0 / sqrt3, -1.0 / sqrt3),
                (-1.0 / sqrt3, -1.0 / sqrt3, 1.0 / sqrt3),
            ]

        for i, s in enumerate(t.singles):
            new_singles.append(MapSite(lig=s.lig, atoms=list(s.atoms), coord=coords[i]))

    else:
        # Unsupported geometry - just copy without coords
        new_pairs = [
            (
                MapSite(lig=a.lig, atoms=list(a.atoms), coord=a.coord),
                MapSite(lig=b.lig, atoms=list(b.atoms), coord=b.coord),
            )
            for a, b in t.pairs
        ]
        new_singles = [MapSite(lig=s.lig, atoms=list(s.atoms), coord=s.coord) for s in t.singles]
        chirality = None  # don't claim chirality for unsupported geometry

    return TrexFull(
        metal=t.metal,
        ox=t.ox,
        spin=t.spin,
        ligands=list(t.ligands),
        pairs=new_pairs,
        singles=new_singles,
        G=t.G,
        X=chirality,
    )


# -----------------------------------------------------------------------------
# Helical (Δ/Λ) chirality
# -----------------------------------------------------------------------------


def _collect_sites_by_ligand(t: TrexFull) -> dict[int, list[MapSite]]:
    """Group all coordination sites by their ligand index."""
    sites_by_lig: dict[int, list[MapSite]] = {}
    for a, b in t.pairs:
        sites_by_lig.setdefault(a.lig, []).append(a)
        sites_by_lig.setdefault(b.lig, []).append(b)
    for s in t.singles:
        sites_by_lig.setdefault(s.lig, []).append(s)
    return sites_by_lig


def _helical_site_key(s: MapSite) -> tuple[int, tuple[int, ...]]:
    """Canonical key for a MapSite (for helical chirality checks)."""
    return (s.lig, tuple(sorted(s.atoms)))


def has_helical_chirality(t: TrexFull) -> bool:
    """
    Check if the complex has helical (Δ/Λ) chirality for octahedrals.

    This should be called when is_chiral() returns False, to catch
    cases like tris-bidentate where point-chirality is absent but
    helical chirality exists.

    Conditions for helical chirality:
    1. Tris-bidentate [M(L∩L)₃]: Always True
    2. Cis-bis-bidentate [M(L∩L)₂X₂]: True if the two bidentates don't
       share a trans relationship (i.e., no site from one is trans to
       a site from the other)
    3. Fac-fac bis-tridentate [M(L∩L∩L)₂]: True if neither tridentate
       has an internal trans pair (both must be fac, not mer)

    Returns:
        True if helical chirality exists, False otherwise
    """
    geom = t.get_geo_type()
    if geom != "O":
        return False

    sites_by_lig = _collect_sites_by_ligand(t)
    denticities = {lig: len(sites) for lig, sites in sites_by_lig.items()}
    denticity_list = sorted(denticities.values(), reverse=True)

    # ----- Case 1: Tris-bidentate [M(L∩L)₃] -----
    if denticity_list == [2, 2, 2]:
        return True

    # ----- Case 2: Bis-bidentate + monodentates [M(L∩L)₂X₂] -----
    if denticity_list == [2, 2, 1, 1]:
        monodentate_ligs = [lig for lig, d in denticities.items() if d == 1]

        # Get site keys for each monodentate
        mono1_key = _helical_site_key(sites_by_lig[monodentate_ligs[0]][0])
        mono2_key = _helical_site_key(sites_by_lig[monodentate_ligs[1]][0])

        # Check if the two monodentates are trans to each other
        for a, b in t.pairs:
            key_a, key_b = _helical_site_key(a), _helical_site_key(b)

            if (key_a == mono1_key and key_b == mono2_key) or (
                key_a == mono2_key and key_b == mono1_key
            ):
                return False  # Monodentates trans → bidentates coplanar → NOT helical

        return True  # Monodentates cis → bidentates have helical twist

    # ----- Case 3: Bis-tridentate [M(L∩L∩L)₂] -----
    if denticity_list == [3, 3]:
        tridentate_ligs = [lig for lig, d in denticities.items() if d == 3]

        for trid_lig in tridentate_ligs:
            trid_keys = {_helical_site_key(s) for s in sites_by_lig[trid_lig]}

            # Check if this tridentate has an internal trans pair (mer)
            for a, b in t.pairs:
                key_a, key_b = _helical_site_key(a), _helical_site_key(b)

                if key_a in trid_keys and key_b in trid_keys:
                    # Internal trans pair → mer → no helical chirality
                    return False

        # Both tridentates are fac → helical chirality exists
        return True

    # Other cases: no helical chirality
    return False


def compute_delta_lambda(t: TrexFull) -> str | None:
    """
    Compute Δ/Λ helical chirality descriptor.

    Should only be called after has_helical_chirality() returns True.

    For bidentates (tris-bidentate or cis-bis-bidentate):
        Uses the "propeller" method: for each bidentate chelate, the bite
        vector (site₂ - site₁) forms a blade. The twist direction of these
        blades around the pseudo-C₃ axis determines Δ or Λ.

    For fac-fac bis-tridentate:
        Measures the twist angle between the two triangular faces.
        Like comparing trigonal prism (0° twist) vs antiprism (60° twist),
        but the direction of twist determines Δ or Λ.

    Args:
        t: TrexFull with coordinates on MapSites

    Returns:
        "Δ", "Λ", or None if not computable
    """
    sites_by_lig = _collect_sites_by_ligand(t)
    denticities = {lig: len(sites) for lig, sites in sites_by_lig.items()}

    # Collect ligands by denticity
    bidentate_ligs = sorted([lig for lig, d in denticities.items() if d == 2])
    tridentate_ligs = sorted([lig for lig, d in denticities.items() if d == 3])

    # ----- Bidentate case (tris-bidentate or cis-bis-bidentate) -----
    if len(bidentate_ligs) >= 2:
        return _compute_delta_lambda_bidentate(t, sites_by_lig, bidentate_ligs)

    # ----- Fac-fac bis-tridentate case -----
    if len(tridentate_ligs) == 2:
        return _compute_delta_lambda_tridentate(t, sites_by_lig, tridentate_ligs)

    return None


def _compute_delta_lambda_bidentate(
    t: TrexFull,
    sites_by_lig: dict[int, list[MapSite]],
    bidentate_ligs: list[int],
) -> str | None:
    """
    Compute Δ/Λ for bidentate chelates using the propeller method.

    Math:
        For each bidentate i with sites aᵢ, bᵢ:
            mᵢ = midpoint = (aᵢ + bᵢ) / 2
            vᵢ = bite vector = bᵢ - aᵢ

        C₃ axis ≈ normalized average of midpoints

        Helicity = Σᵢ (mᵢ × c₃) · vᵢ

        Positive → Λ (left-handed propeller)
        Negative → Δ (right-handed propeller)
    """
    # Extract chelate data: midpoint and bite vector for each bidentate
    chelate_data: list[tuple[np.ndarray, np.ndarray]] = []

    for lig_idx in bidentate_ligs:
        sites = sites_by_lig[lig_idx]
        if len(sites) != 2:
            continue

        s0, s1 = sites[0], sites[1]
        a = _get_coord(s0)
        b = _get_coord(s1)

        # Canonical ordering: lower atom indices first
        if tuple(sorted(s0.atoms)) > tuple(sorted(s1.atoms)):
            a, b = b, a

        m = (a + b) / 2.0  # midpoint
        v = b - a  # bite vector
        chelate_data.append((m, v))

    if len(chelate_data) < 2:
        return None

    # Compute pseudo-C₃ (or C₂ for bis-bidentate) axis
    midpoints = np.array([d[0] for d in chelate_data])
    axis = np.mean(midpoints, axis=0)
    axis_norm = np.linalg.norm(axis)

    if axis_norm < 1e-10:
        return None
    axis = axis / axis_norm

    # Compute helicity: sum of (m × axis) · v
    # (m × axis) is tangent to rotation around axis at position m
    # Dotting with bite vector v measures twist direction
    helicity = 0.0
    for m, v in chelate_data:
        helicity += np.dot(np.cross(m, axis), v)

    if abs(helicity) < 1e-10:
        return None  # Degenerate case

    # Convention: positive → Λ (left-handed), negative → Δ (right-handed)
    return "Λ" if helicity > 0 else "Δ"


def _compute_delta_lambda_tridentate(
    t: TrexFull,
    sites_by_lig: dict[int, list[MapSite]],
    tridentate_ligs: list[int],
) -> str | None:
    """
    Compute Δ/Λ for fac-fac bis-tridentate using triangular face twist.

    Each fac tridentate defines a triangular face. The twist angle between
    the two faces (like trigonal antiprism) determines the helicity.

    Method:
        1. Get 3 coordinates for each tridentate face
        2. Compute centroid of each face
        3. C₃ axis ≈ line connecting centroids
        4. Project face vertices onto plane perpendicular to C₃
        5. Measure angular offset between the two triangles
        6. Direction of offset determines Δ/Λ
    """
    if len(tridentate_ligs) != 2:
        return None

    # Get coordinates for each tridentate
    face1_coords = []
    face2_coords = []

    for s in sites_by_lig[tridentate_ligs[0]]:
        face1_coords.append(_get_coord(s))
    for s in sites_by_lig[tridentate_ligs[1]]:
        face2_coords.append(_get_coord(s))

    if len(face1_coords) != 3 or len(face2_coords) != 3:
        return None

    face1 = np.array(face1_coords)
    face2 = np.array(face2_coords)

    # Compute centroids
    centroid1 = np.mean(face1, axis=0)
    centroid2 = np.mean(face2, axis=0)

    # C₃ axis: from centroid1 to centroid2
    axis = centroid2 - centroid1
    axis_norm = np.linalg.norm(axis)
    if axis_norm < 1e-10:
        return None
    axis = axis / axis_norm

    # Simpler approach: compute cross product of edge vectors
    # Edge of face 1
    e1 = face1[1] - face1[0]
    # Edge of face 2
    e2 = face2[1] - face2[0]

    # Project both edges onto plane perpendicular to axis
    e1_proj = e1 - np.dot(e1, axis) * axis
    e2_proj = e2 - np.dot(e2, axis) * axis

    # Cross product of projected edges gives twist direction
    twist = np.dot(np.cross(e1_proj, e2_proj), axis)

    if abs(twist) < 1e-10:
        return None

    # Convention: match with bidentate case
    return "Λ" if twist > 0 else "Δ"


__all__ = [
    "compute_chirality",
    "is_chiral",
    "has_coordinates",
    "assign_idealized_coordinates",
    "has_helical_chirality",
    "compute_delta_lambda",
]
