# trex/cli.py
from __future__ import annotations

import typer

from .canon import canonicalize_min
from .canon_full import canonicalize_full
from .model import LigandPayload, MapSite, TrexFull
from .parse_full import parse_trex_full, pretty_trex_full
from .parse_min import parse_trex_min, pretty_trex_min
from .validate import validate_min

app = typer.Typer(add_completion=False, help="T-REX CLI — Trans-pair RElations eXpression")


# --------------------------- helpers --------------------------- #


def _looks_full(s: str) -> bool:
    """Heuristic: does the string look like FULL?"""
    u = s.upper()
    return any(tok in u for tok in ("SMILES:", "SELFIES:", "INCHI:", "TOKEN:"))


def _print_issues(issues):
    for level, msg in issues:
        typer.echo(f"[{level}] {msg}", err=(level.upper() == "ERROR"))


# --------------------------- commands --------------------------- #


@app.command()
def validate(
    s: str = typer.Argument(..., help="T-REX string (FULL by default; use --mini for T-REX-min)"),
    mini: bool = typer.Option(False, "--mini", help="Parse and validate as T-REX-min"),
):
    """
    Validate and echo a canonicalized T-REX string.
    FULL is default unless --mini is given (or the string unambiguously looks MIN).
    """
    try_full = (not mini) and _looks_full(s)
    try:
        if try_full and not mini:
            t = parse_trex_full(s)
            t2 = canonicalize_full(t)
            typer.echo(pretty_trex_full(t2))
            raise typer.Exit(code=0)
        # MIN path
        t = parse_trex_min(s)
        issues = validate_min(t)
        _print_issues(issues)
        t2 = canonicalize_min(t)
        typer.echo(pretty_trex_min(t2))
        raise typer.Exit(code=0)
    except Exception as e:
        typer.echo(str(e), err=True)
        raise typer.Exit(code=1) from e


@app.command()
def canon(
    s: str = typer.Argument(..., help="T-REX string (FULL default)"),
    mini: bool = typer.Option(False, "--mini", help="Canonicalize as T-REX-min"),
):
    """
    Canonicalize without printing validator messages.
    """
    try:
        if (not mini) and _looks_full(s):
            t = parse_trex_full(s)
            t2 = canonicalize_full(t)
            typer.echo(pretty_trex_full(t2))
        else:
            t = parse_trex_min(s)
            t2 = canonicalize_min(t)
            typer.echo(pretty_trex_min(t2))
    except Exception as e:
        typer.echo(str(e), err=True)
        raise typer.Exit(code=1) from e


@app.command()
def translate(
    s: str = typer.Argument(..., help="Input T-REX string (FULL or MIN)"),
    to: str = typer.Option(..., "--to", help="Target form: full|min", case_sensitive=False),
):
    """
    Translate between FULL and MIN textual forms.

    - FULL → MIN: drops per-site atom lists and payload kinds, keeps topology (pairs/singles/G).
    - MIN → FULL: wraps tokens into TOKEN: payloads and lifts pairs/singles (atoms unknown).
      (Atoms are left as singletons [1] as placeholders; refine after MOL2/SMILES conversion.)
    """
    mode = to.lower().strip()
    if mode not in {"full", "min"}:
        typer.echo("Value for --to must be one of: full, min", err=True)
        raise typer.Exit(code=2)

    try:
        if _looks_full(s):
            # source FULL
            tf = parse_trex_full(s)
            if mode == "full":
                tf = canonicalize_full(tf)
                typer.echo(pretty_trex_full(tf))
                return
            # FULL -> MIN
            # collapse ligands to tokens where possible; otherwise keep text lowercased token-ish
            lig_tokens = []
            for pl in tf.ligands:
                if (pl.kind or "").upper() == "TOKEN":
                    lig_tokens.append(pl.text.lower())
                else:
                    # keep a readable token (e.g., canonical SMILES as surrogate token)
                    lig_tokens.append(pl.text.lower())
            # collapse MAP sites to ligand-level pairs/singles
            pair_idxs = sorted({tuple(sorted((a.lig, b.lig))) for a, b in tf.pairs})
            single_idxs = sorted({s.lig for s in tf.singles})
            from .model import TrexMin

            tmin = TrexMin(
                metal=tf.metal,
                ox=tf.ox,
                spin=tf.spin,
                ligands=lig_tokens,
                pairs=pair_idxs,
                singles=single_idxs,
                G=tf.G,
            )
            from .canon import canonicalize_min
            from .parse_min import pretty_trex_min

            tmin = canonicalize_min(tmin)
            typer.echo(pretty_trex_min(tmin))
        else:
            # source MIN
            tm = parse_trex_min(s)
            if mode == "min":
                tm = canonicalize_min(tm)
                typer.echo(pretty_trex_min(tm))
                return
            # MIN -> FULL (TOKEN payloads; atoms left as [1] placeholders)
            ligs = [LigandPayload(kind="TOKEN", text=x) for x in tm.ligands]
            pairs = [(MapSite(lig=i, atoms=[1]), MapSite(lig=j, atoms=[1])) for i, j in tm.pairs]
            singles = [MapSite(lig=i, atoms=[1]) for i in tm.singles]
            tf = TrexFull(
                metal=tm.metal,
                ox=tm.ox,
                spin=tm.spin,
                ligands=ligs,
                pairs=pairs,
                singles=singles,
                G=tm.G,
            )
            tf = canonicalize_full(tf)
            typer.echo(pretty_trex_full(tf))
    except Exception as e:
        typer.echo(str(e), err=True)
        raise typer.Exit(code=1) from e


def main():
    app()


if __name__ == "__main__":
    main()
