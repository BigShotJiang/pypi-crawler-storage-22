from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

# model classes:
from trex.model import LigandPayload, MapSite, TrexFull
from trex.parse_full import parse_trex_full

# RDKit for symmetry matching
try:
    from rdkit import Chem
    from rdkit.Chem import rdMolDescriptors
except Exception:
    Chem = None
    rdMolDescriptors = None


@dataclass(frozen=True)
class MapAssignment:
    pairs: tuple[tuple[MapSite, MapSite], ...]
    singles: tuple[MapSite, ...]


def enumerate_trex_maps_by_counts(
    full_or_string: TrexFull | str,
    parse_fn: callable | None = None,
    *,
    # 2) multidentate rules
    preserve_intra_pairs: bool = True,
    forbid_new_intra_pairs: bool = True,
    # cross-ligand pairs from the input are NOT preserved
    preserve_cross_pairs: bool = False,
    # 3) "counts first": by default, honor input len(pairs)/len(singles)
    use_input_counts: bool = True,
    pairs_required: int | None = None,
    singles_required: int | None = None,
    # 5) dedupe knobs
    collapse_identical_ligands: bool = True,  # collapse permutations of identical ligands
    # 6) automatic internal site-equivalence (multidentates only)
    collapse_internal_symmetry: bool = True,
    site_symmetry_mode: str = "hybrid",  # "strict" (graph only) or "hybrid" (graph + ECFP)
    ecfp_radius: int = 4,
    # optional hard limit
    limit: int | None = None,
) -> list[MapAssignment]:
    """
    Implementation

      1) Evaluate denticity from MAP sites.
      2) For multidentates, preserve existing intra-ligand trans pairs and forbid creating new ones.
      3) Enumerate all rearrangements that hit the input pair/single counts (or overrides).
      4) Discard any arrangement violating #2 (and any parity/feasibility constraints).
      5) Remove ordering duplicates via canonical signatures.
      6) Remove ligand internal site-symmetry duplicates automatically.

    Args:
      full_or_string: TrexFull OR a T-REX string (if string, provide parse_fn).
      parse_fn: function str -> TrexFull (only needed when you pass a string).

    Returns:
      List[MapAssignment] with canonical pairs/singles.
    """
    # ---------- parse ----------
    if isinstance(full_or_string, str):
        full: TrexFull = parse_trex_full(full_or_string)
    else:
        full: TrexFull = full_or_string

    ligs: list[LigandPayload] = full.ligands or []

    # ---------- tiny helpers ----------
    def _site_key(ms: MapSite) -> tuple[int, tuple[int, ...]]:
        return (ms.lig, tuple(sorted(ms.atoms or [])))

    def _norm_pair(a: MapSite, b: MapSite) -> tuple[MapSite, MapSite]:
        return (a, b) if _site_key(a) <= _site_key(b) else (b, a)

    def _unique_sites(f: TrexFull) -> dict[tuple[int, tuple[int, ...]], MapSite]:
        d: dict[tuple[int, tuple[int, ...]], MapSite] = {}
        for a, b in f.pairs:
            d[_site_key(a)] = a
            d[_site_key(b)] = b
        for s in f.singles:
            d[_site_key(s)] = s
        return d

    def _denticity(f: TrexFull) -> dict[int, int]:
        cnt: dict[int, int] = defaultdict(int)
        for lig, _ in _unique_sites(f).keys():
            cnt[lig] += 1
        return dict(cnt)

    # ---------- (6) AUTO site-equivalence  ----------
    def _site_graph_signature(ids: list[int], atoms0: list[int]) -> tuple:
        return ("graph", len(atoms0), tuple(sorted(ids[i] for i in atoms0)))

    def _site_ecfp_signature(mol, atoms0: list[int], radius: int) -> tuple:
        # local environment for the whole site
        fp = rdMolDescriptors.GetMorganFingerprint(
            mol, radius, useCounts=True, fromAtoms=atoms0, useChirality=True
        )
        items = fp.GetNonzeroElements()  # dict: hash -> count
        return (
            "ecfp",
            radius,
            len(atoms0),
            tuple(sorted((int(k), int(v)) for k, v in items.items())),
        )

    def _auto_site_equivalences(
        f: TrexFull, *, smiles_kind: str = "SMILES", mode: str = "hybrid", ecfp_radius: int = 2
    ) -> dict[int, list[set[frozenset]]]:
        """
        {lig_idx: [ {frozenset(1-based site atoms), ...}, ... ] }

          - If SMILES contains atom-map numbers, use them.
          - Else, use naive (a-1) only when all site atoms fit in RDKit's index range.
          - Otherwise, skip symmetry for that ligand.
        """
        out: dict[int, list[set[frozenset]]] = {}
        if not collapse_internal_symmetry or Chem is None:
            return out

        # Collect sites per ligand (keep 1-based for now)
        sites_by_lig: dict[int, list[list[int]]] = defaultdict(list)
        for ms in _unique_sites(f).values():
            atoms1 = list(ms.atoms or [])
            if atoms1:
                sites_by_lig[ms.lig].append(atoms1)

        for lig_idx, sites1 in sites_by_lig.items():
            lp = f.ligands[lig_idx - 1] if f.ligands else None
            if not lp or lp.kind != smiles_kind:
                continue

            mol = Chem.MolFromSmiles(lp.text)
            if mol is None:
                continue
            n = mol.GetNumAtoms()

            # Build a mapping via atom-map numbers if present
            amapnum_to_idx = {
                a.GetAtomMapNum(): a.GetIdx() for a in mol.GetAtoms() if a.GetAtomMapNum() > 0
            }
            have_mapnums = bool(amapnum_to_idx)

            # Convert each site's 1-based atoms to RDKit 0-based indices
            sites0: list[list[int]] = []
            mapping_ok = True
            for atoms1 in sites1:
                if have_mapnums and all(a in amapnum_to_idx for a in atoms1):
                    atoms0 = [amapnum_to_idx[a] for a in atoms1]
                elif all(1 <= a <= n for a in atoms1):
                    atoms0 = [a - 1 for a in atoms1]
                else:
                    mapping_ok = False
                    break
                sites0.append(atoms0)

            if not mapping_ok or not sites0:
                # Can't safely relate T-REX numbering to RDKit here — skip symmetry for this ligand
                continue

            # --- Graph symmetry via canonical ranks (ties not broken)
            ranks = Chem.CanonicalRankAtoms(mol, breakTies=False)

            buckets: dict[tuple, set[frozenset]] = defaultdict(set)
            for atoms0, atoms1 in zip(sites0, sites1, strict=False):
                sig = ("graph", len(atoms0), tuple(sorted(ranks[i] for i in atoms0)))
                buckets[sig].add(frozenset(atoms1))  # store 1-based back into the classes

            classes: list[set[frozenset]] = [cls for cls in buckets.values() if len(cls) > 1]

            # Optional: local environment clustering (hybrid mode)
            if mode == "hybrid" and rdMolDescriptors is not None:
                env_buckets: dict[tuple, set[frozenset]] = defaultdict(set)
                for atoms0, atoms1 in zip(sites0, sites1, strict=False):
                    fp = rdMolDescriptors.GetMorganFingerprint(
                        mol, ecfp_radius, useCounts=True, fromAtoms=atoms0, useChirality=True
                    )
                    items = fp.GetNonzeroElements()
                    sig = (
                        "ecfp",
                        ecfp_radius,
                        len(atoms0),
                        tuple(sorted((int(k), int(v)) for k, v in items.items())),
                    )
                    env_buckets[sig].add(frozenset(atoms1))
                for cls in env_buckets.values():
                    if len(cls) > 1 and not any(cls & existing for existing in classes):
                        classes.append(cls)

            if classes:
                out[lig_idx] = classes

        return out

    def _build_site_equiv_lookup(
        site_equivalences: dict[int, list[set[frozenset]]],
    ) -> dict[tuple[int, frozenset], tuple[int, int]]:
        out: dict[tuple[int, frozenset], tuple[int, int]] = {}
        for lig, classes in (site_equivalences or {}).items():
            for cid, cls in enumerate(classes):
                for atomset in cls:
                    out[(lig, atomset)] = (lig, cid)
        return out

    def _lig_equiv_key(lp: LigandPayload) -> tuple[str, str]:
        return (lp.kind, lp.text)

    def _site_signature(
        ms: MapSite,
        *,
        ligs: list[LigandPayload],
        collapse_identical_ligands: bool,
        site_equiv_lookup: dict[tuple[int, frozenset], tuple[int, int]] | None,
        multidentate_ligs: set[int],
    ) -> tuple:
        """
        Return a fully comparable, type-stable signature:
          (
            lig_sig,        # ("LIDX", <int>)  or ("LKEY", <kind>, <text>)
            atom_sig        # ("eq", <lig>, <class_id>)  or ("raw", <sorted ints...>)
          )
        """
        # --- ligand identity (type-stable) ---
        if collapse_identical_ligands and ligs:
            lp = ligs[ms.lig - 1]
            lig_sig = ("LKEY", lp.kind or "", lp.text or "")
        else:
            lig_sig = ("LIDX", int(ms.lig))

        # --- atom/site identity (type-stable) ---
        atoms_sorted = tuple(sorted(ms.atoms or []))
        atom_sig: tuple
        if site_equiv_lookup and (ms.lig in multidentate_ligs):
            lbl = site_equiv_lookup.get((ms.lig, frozenset(atoms_sorted)))
            if lbl is not None:
                # symmetry-collapsed site label
                lig_idx, class_id = lbl
                atom_sig = ("eq", int(lig_idx), int(class_id))
            else:
                atom_sig = ("raw",) + atoms_sorted
        else:
            atom_sig = ("raw",) + atoms_sorted

        return (lig_sig, atom_sig)

    def _map_signature(
        pairs: list[tuple[MapSite, MapSite]],
        singles: list[MapSite],
        *,
        ligs: list[LigandPayload],
        collapse_identical_ligands: bool,
        site_equiv_lookup: dict[tuple[int, frozenset], tuple[int, int]] | None,
        multidentate_ligs: set[int],
    ) -> tuple:
        def sig(ms: MapSite) -> tuple:
            return _site_signature(
                ms,
                ligs=ligs,
                collapse_identical_ligands=collapse_identical_ligands,
                site_equiv_lookup=site_equiv_lookup,
                multidentate_ligs=multidentate_ligs,
            )

        ps = []
        for a, b in pairs:
            sa, sb = sig(a), sig(b)
            ps.append(tuple(sorted([sa, sb])))
        ps = tuple(sorted(ps))
        ss = tuple(sorted(sig(s) for s in singles))
        return (ps, ss)

    # ---------- (1) denticity & multidentate set ----------
    dent = _denticity(full)
    multidentate_ligs: set[int] = {i for i, n in dent.items() if n >= 2}

    # ---------- fixed intra-ligand pairs to preserve (2) ----------
    fixed_pairs: list[tuple[MapSite, MapSite]] = []
    for a, b in full.pairs:
        same_lig = a.lig == b.lig
        if same_lig and preserve_intra_pairs:
            fixed_pairs.append(_norm_pair(a, b))
        elif (not same_lig) and preserve_cross_pairs:
            fixed_pairs.append(_norm_pair(a, b))

    # Disjointness check for fixed endpoints
    used = set()
    for a, b in fixed_pairs:
        ka, kb = _site_key(a), _site_key(b)
        if ka == kb or ka in used or kb in used:
            raise ValueError("Invalid MAP: overlapping fixed pair endpoints.")
        used.add(ka)
        used.add(kb)

    # ---------- counts (3) ----------
    all_sites = _unique_sites(full)
    all_keys = sorted(all_sites.keys())
    if use_input_counts:
        singles_target = len(full.singles) if singles_required is None else singles_required
        total_pairs_target = len(full.pairs) if pairs_required is None else pairs_required
    else:
        # infer from parity if you prefer
        singles_target = (len(all_keys) % 2) if singles_required is None else singles_required
        total_pairs_target = (
            ((len(all_keys) - singles_target) // 2) if pairs_required is None else pairs_required
        )

    if len(fixed_pairs) > total_pairs_target:
        raise ValueError("Input has more preserved intra-ligand pairs than target pairs.")
    pairs_left = total_pairs_target - len(fixed_pairs)

    # ---------- auto site-equivalence (6) ----------
    site_equiv_lookup = (
        _build_site_equiv_lookup(_auto_site_equivalences(full))
        if collapse_internal_symmetry
        else None
    )

    # ---------- free endpoints ----------
    free_keys = [k for k in all_keys if k not in used]

    # ---------- legality check (4) ----------
    def can_pair(ka, kb) -> bool:
        a, b = all_sites[ka], all_sites[kb]
        if a.lig == b.lig and (a.lig in multidentate_ligs) and forbid_new_intra_pairs:
            return False
        return True

    # ---------- enumerate by singles-then-pairs (3,4,5,6) ----------
    from itertools import combinations

    results: list[MapAssignment] = []
    seen: set[tuple] = set()

    for singles_keys in combinations(free_keys, singles_target):
        remaining = [k for k in free_keys if k not in singles_keys]
        if len(remaining) != 2 * pairs_left:
            continue

        partial_pairs: list[tuple[MapSite, MapSite]] = []

        def backtrack(
            rem: list[tuple[int, tuple[int, ...]]],
            _partial_pairs: list[tuple[MapSite, MapSite]] = partial_pairs,
            _singles_keys: tuple[tuple[int, tuple[int, ...]], ...] = singles_keys,
        ) -> None:
            if limit is not None and len(results) >= limit:
                return
            if not rem:
                # assemble result
                all_pairs = [_norm_pair(*p) for p in fixed_pairs] + [
                    _norm_pair(a, b) for (a, b) in _partial_pairs
                ]
                all_pairs.sort(key=lambda p: (_site_key(p[0]), _site_key(p[1])))
                singles_sorted = sorted([all_sites[k] for k in _singles_keys], key=_site_key)

                sig = _map_signature(
                    all_pairs,
                    singles_sorted,
                    ligs=ligs,
                    collapse_identical_ligands=collapse_identical_ligands,
                    site_equiv_lookup=site_equiv_lookup,
                    multidentate_ligs=multidentate_ligs,
                )

                if sig not in seen:
                    seen.add(sig)
                    results.append(
                        MapAssignment(pairs=tuple(all_pairs), singles=tuple(singles_sorted))
                    )
                return

            a = rem[0]
            rest = rem[1:]
            for i, b in enumerate(rest):
                if not can_pair(a, b):
                    continue
                nxt = rest[:i] + rest[i + 1 :]
                _partial_pairs.append((all_sites[a], all_sites[b]))
                backtrack(nxt)
                _partial_pairs.pop()

        backtrack(remaining)

    return results


# ------- Formatting helpers -------


def _fmt_ligand(lp: LigandPayload) -> str:
    # e.g. "SMILES:CCO" or "TOKEN:Cl"
    return f"{lp.kind}:{lp.text}"


def _fmt_site(ms):
    # ms.lig: int (1-based ligand index)
    # ms.atoms: iterable[int] (empty, 1 atom, or many for haptic)
    atoms = list(ms.atoms or [])
    if not atoms:
        return f"{ms.lig}:"
    if len(atoms) == 1:
        return f"{ms.lig}:{atoms[0]}"
    # ηn site → bracketed, comma-separated list
    return f"{ms.lig}:[{','.join(str(a) for a in atoms)}]"


def _fmt_map_block(pairs, singles):
    # pairs: iterable[tuple[MapSite, MapSite]], singles: iterable[MapSite]
    parts = []
    for a, b in pairs:
        parts.append(f"( {_fmt_site(a)}, {_fmt_site(b)} )")
    for s in singles:
        parts.append(_fmt_site(s))
    return "{ " + ", ".join(parts) + " }"


def _fmt_charge(q: int) -> str:
    return "0" if q == 0 else f"{q:+d}"


def _fmt_header(full):
    # primary: ox (matches TrexFull + parser)
    q = getattr(full, "ox", None)
    # optional fallbacks if you happen to pass a different object
    if q is None:
        q = getattr(full, "charge", None)
    if q is None:
        q = getattr(full, "os", 0)
    return f"{full.metal}{{{_fmt_charge(int(q))}}}"


def _fmt_l_block(full: TrexFull) -> str:
    return "L=[ " + ", ".join(_fmt_ligand(lp) for lp in full.ligands) + " ]"


def _fmt_tail_flags(full: TrexFull, x_override: str | None = None) -> str:
    """
    Format tail flags (G and X).

    Args:
        full: TrexFull object
        x_override: If provided, use this value for X instead of full.X
    """
    tail = []
    if getattr(full, "G", None):
        tail.append(f"G:{full.G}")

    x_val = x_override if x_override is not None else getattr(full, "X", None)
    if x_val:
        tail.append(f"X:{x_val}")

    return (" | " + " ".join(tail)) if tail else ""


# ------- Main wrapper -------


def trex_strings_from_enum(
    full_or_string: TrexFull | str,
    # pass-through knobs for the enumerator
    preserve_intra_pairs: bool = True,
    forbid_new_intra_pairs: bool = True,
    preserve_cross_pairs: bool = False,
    use_input_counts: bool = True,
    pairs_required: int | None = None,
    singles_required: int | None = None,
    collapse_identical_ligands: bool = True,
    collapse_internal_symmetry: bool = True,
    site_symmetry_mode: str = "strict",  # or "hybrid"
    ecfp_radius: int = 4,
    limit: int | None = None,
    # NEW: chirality enumeration
    enumerate_enantiomers: bool = True,
) -> list[str]:
    """
    Run enumeration then render each map as a T-REX string.

    If enumerate_enantiomers=True (default):
    - Point-chiral isomers are output twice with X:@ and X:@@
    - Helical-chiral isomers (Δ/Λ) are output twice with X:Δ and X:Λ
    - Achiral isomers have no X flag

    If `full_or_string` is a string, it will be parsed using parse_trex_full.
    """
    from trex.chirality import has_helical_chirality, is_chiral

    if isinstance(full_or_string, TrexFull):
        full = full_or_string
    else:
        full = parse_trex_full(full_or_string)

    # enumerate
    enum = enumerate_trex_maps_by_counts(
        full,
        preserve_intra_pairs=preserve_intra_pairs,
        forbid_new_intra_pairs=forbid_new_intra_pairs,
        preserve_cross_pairs=preserve_cross_pairs,
        use_input_counts=use_input_counts,
        pairs_required=pairs_required,
        singles_required=singles_required,
        collapse_identical_ligands=collapse_identical_ligands,
        collapse_internal_symmetry=collapse_internal_symmetry,
        site_symmetry_mode=site_symmetry_mode,
        ecfp_radius=ecfp_radius,
        limit=limit,
    )

    # render each map back into a full T-REX string, preserving ligands & flags
    header = _fmt_header(full)
    l_block = _fmt_l_block(full)

    out: list[str] = []
    for m in enum:
        map_block = _fmt_map_block(m.pairs, m.singles)

        if enumerate_enantiomers:
            # Build a TrexFull to check chirality
            t = TrexFull(
                metal=full.metal,
                ox=full.ox,
                spin=full.spin,
                ligands=full.ligands,
                pairs=list(m.pairs),
                singles=list(m.singles),
                G=full.G,
                X=None,
            )

            if is_chiral(t):
                # Point-chiral: emit both enantiomers with @/@@
                tail_1 = _fmt_tail_flags(full, x_override="@")
                tail_2 = _fmt_tail_flags(full, x_override="@@")
                out.append(f"{header} | {l_block} | MAP:{map_block}{tail_1}")
                out.append(f"{header} | {l_block} | MAP:{map_block}{tail_2}")
            elif has_helical_chirality(t):
                # Helical-chiral: emit both enantiomers with Δ/Λ
                tail_1 = _fmt_tail_flags(full, x_override="Δ")
                tail_2 = _fmt_tail_flags(full, x_override="Λ")
                out.append(f"{header} | {l_block} | MAP:{map_block}{tail_1}")
                out.append(f"{header} | {l_block} | MAP:{map_block}{tail_2}")
            else:
                # Not chiral: emit once, no X flag
                tail = _fmt_tail_flags(full, x_override=None)
                out.append(f"{header} | {l_block} | MAP:{map_block}{tail}")
        else:
            # No chirality enumeration: just emit the map
            tail = _fmt_tail_flags(full)
            out.append(f"{header} | {l_block} | MAP:{map_block}{tail}")

    return out
