# trex/geometry.py
"""
Geometric feature extraction for T-REX-geo training.

Extracts Δr (distance residuals) and Δcos(θ) (angular residuals) from
canonicalized TrexFull structures with metal-relative coordinates.

The extracted features are designed to match the hyperedge structure in HyperMPNN:
- SITE hyperedges: one Δr per coordination site
- CIS/TRANS hyperedges: one Δcos(θ) per site pair
"""

from __future__ import annotations

import math

import numpy as np
from rdkit import Chem

from .model import MapSite, TrexFull

# =============================================================================
# Covalent radii (Å) - Cordero et al. 2008 values
# =============================================================================
COVALENT_RADII = {
    # Non-metals
    "H": 0.31,
    "B": 0.84,
    "C": 0.76,
    "N": 0.71,
    "O": 0.66,
    "F": 0.57,
    "Si": 1.11,
    "P": 1.07,
    "S": 1.05,
    "Cl": 1.02,
    "As": 1.19,
    "Se": 1.20,
    "Br": 1.20,
    "Te": 1.38,
    "I": 1.39,
    # 3d metals
    "Sc": 1.70,
    "Ti": 1.60,
    "V": 1.53,
    "Cr": 1.39,
    "Mn": 1.39,
    "Fe": 1.32,
    "Co": 1.26,
    "Ni": 1.24,
    "Cu": 1.32,
    "Zn": 1.22,
    # 4d metals
    "Y": 1.90,
    "Zr": 1.75,
    "Nb": 1.64,
    "Mo": 1.54,
    "Tc": 1.47,
    "Ru": 1.46,
    "Rh": 1.42,
    "Pd": 1.39,
    "Ag": 1.45,
    "Cd": 1.44,
    # 5d metals
    "La": 2.07,
    "Hf": 1.75,
    "Ta": 1.70,
    "W": 1.62,
    "Re": 1.51,
    "Os": 1.44,
    "Ir": 1.41,
    "Pt": 1.36,
    "Au": 1.36,
    "Hg": 1.32,
    # Lanthanides (selected)
    "Ce": 2.04,
    "Nd": 2.01,
    "Sm": 1.98,
    "Eu": 1.98,
    "Gd": 1.96,
    "Dy": 1.92,
    "Er": 1.89,
    "Yb": 1.87,
    "Lu": 1.87,
}

# Default for unknown elements
DEFAULT_COVALENT_RADIUS = 1.50

# M-centroid distance for haptic sites (based on ferrocene-like binding)
HAPTIC_IDEAL_DISTANCE = 1.65


# =============================================================================
# Ideal angles by geometry
# =============================================================================

# Trans is always 180° -> cos(180°) = -1
IDEAL_TRANS_COS = -1.0

# Pentagonal bipyramidal specific angles
PNTBP_CLOSE_CIS_COS = math.cos(math.radians(72.0))  # ~0.309
PNTBP_FAR_CIS_COS = math.cos(math.radians(144.0))  # ~-0.809
PNTBP_EQ_AX_COS = 0.0  # 90°

# Trigonal bipyramidal specific angles
TRBP_EQ_EQ_COS = -0.5  # 120°
TRBP_EQ_AX_COS = 0.0  # 90°

# Cis angles depend on geometry (simple geometries)
IDEAL_CIS_COS_BY_GEOMETRY = {
    "O": 0.0,  # octahedral: 90°
    "sqpl": 0.0,  # square planar: 90°
    "sqpy": 0.0,  # square pyramidal: 90° (basal-basal and basal-apical)
    "thd": -1 / 3,  # tetrahedral: 109.5° -> cos(109.5°) ≈ -0.333
    "trpl": -0.5,  # trigonal planar: 120° -> cos(120°) = -0.5
    "ssw": 0.0,  # see-saw: ~90° for most angles
    "bnt": -0.5,  # bent: ~120° (approximate)
    "ln": None,  # linear: no cis angles
    "tsh": 0.0,  # T-shaped: 90°
    "unk": 0.0,  # unknown: default to 90°
}


def get_covalent_radius(symbol: str) -> float:
    """Get covalent radius for an element symbol."""
    return COVALENT_RADII.get(symbol, DEFAULT_COVALENT_RADIUS)


def is_haptic_site(site: MapSite) -> bool:
    """Check if site is haptic (η^n with n > 1)."""
    return len(site.atoms) > 1


def _get_coord_atom_symbol(site: MapSite, ligand_smiles: str) -> str:
    """
    Get the symbol of the coordinating atom for a σ-bound site.

    For haptic sites, this doesn't apply (returns 'C' as fallback).
    """
    if not site.atoms or is_haptic_site(site):
        return "C"  # fallback for haptic

    mol = Chem.MolFromSmiles(ligand_smiles)
    if mol is None:
        return "N"  # common fallback

    # Map SMILES writing position (1-based) to RDKit atom index
    mol2 = Chem.Mol(mol)
    for a in mol2.GetAtoms():
        a.SetAtomMapNum(a.GetIdx() + 1)
    smi_mapped = Chem.MolToSmiles(mol2, canonical=True, isomericSmiles=True)

    import re

    ids = [int(x) - 1 for x in re.findall(r":(\d+)\]", smi_mapped)]

    if not ids and mol.GetNumAtoms() == 1:
        pos_to_rd = [0]
    elif len(ids) != mol.GetNumAtoms():
        ranks = Chem.CanonicalRankAtoms(mol)
        pos_to_rd = sorted(range(mol.GetNumAtoms()), key=lambda i: (ranks[i], i))
    else:
        pos_to_rd = ids

    pos_1b = site.atoms[0]  # first coordinating atom position (1-based)
    pos_0b = pos_1b - 1

    if 0 <= pos_0b < len(pos_to_rd):
        rd_idx = pos_to_rd[pos_0b]
        return mol.GetAtomWithIdx(rd_idx).GetSymbol()

    return "N"  # fallback


def get_ideal_distance(metal_symbol: str, site: MapSite, ligand_smiles: str) -> float:
    """
    Get ideal M-L distance for a coordination site.

    For haptic sites (η^n, n > 1): returns HAPTIC_IDEAL_DISTANCE (1.65 Å)
    For σ-bound sites: returns sum of covalent radii

    Args:
        metal_symbol: Element symbol of the metal
        site: MapSite object
        ligand_smiles: SMILES string of the ligand

    Returns:
        Ideal distance in Ångströms
    """
    if is_haptic_site(site):
        return HAPTIC_IDEAL_DISTANCE

    coord_symbol = _get_coord_atom_symbol(site, ligand_smiles)
    r_metal = get_covalent_radius(metal_symbol)
    r_ligand = get_covalent_radius(coord_symbol)

    return r_metal + r_ligand


def get_ideal_cis_cos(
    geometry: str,
    site_i_in_trans: bool,
    site_j_in_trans: bool,
    site_i_singles_idx: int | None = None,
    site_j_singles_idx: int | None = None,
    n_singles: int | None = None,
) -> float:
    """
    Get ideal cos(θ) for a cis angle based on geometry.

    For trigonal bipyramidal (trbp), the ideal angle depends on whether
    sites are axial (in trans pair) or equatorial (singles):
    - eq-eq: 120° -> cos = -0.5
    - eq-ax: 90° -> cos = 0.0

    For pentagonal bipyramidal (pntbp), equatorial sites have position-dependent
    angles based on their canonical ordering (CCW rotation):
    - eq-eq close-cis (adjacent, separation=1): 72° -> cos ≈ 0.309
    - eq-eq far-cis (separation=2): 144° -> cos ≈ -0.809
    - eq-ax: 90° -> cos = 0.0

    Args:
        geometry: Geometry flag from T-REX
        site_i_in_trans: Whether site i is part of a trans pair
        site_j_in_trans: Whether site j is part of a trans pair
        site_i_singles_idx: Index of site i in singles list (0-based), if equatorial
        site_j_singles_idx: Index of site j in singles list (0-based), if equatorial
        n_singles: Total number of singles (for circular distance calculation)

    Returns:
        Ideal cos(θ) value
    """
    # Trigonal bipyramidal
    if geometry == "trbp":
        if site_i_in_trans or site_j_in_trans:
            return TRBP_EQ_AX_COS  # eq-ax: 90°
        else:
            return TRBP_EQ_EQ_COS  # eq-eq: 120°

    # Pentagonal bipyramidal
    if geometry == "pntbp":
        # If either site is axial (in trans pair)
        if site_i_in_trans or site_j_in_trans:
            return PNTBP_EQ_AX_COS  # eq-ax: 90°

        # Both equatorial - use position-based angle
        if (
            site_i_singles_idx is not None
            and site_j_singles_idx is not None
            and n_singles is not None
            and n_singles == 5
        ):
            # Circular distance in the canonical CCW ordering
            diff = abs(site_i_singles_idx - site_j_singles_idx)
            separation = min(diff, n_singles - diff)

            if separation == 1:
                return PNTBP_CLOSE_CIS_COS  # 72°
            elif separation == 2:
                return PNTBP_FAR_CIS_COS  # 144°
            else:
                # separation shouldn't be > 2 for 5 sites, but fallback
                return 0.0

        # Fallback if indices not provided
        return 0.0

    return IDEAL_CIS_COS_BY_GEOMETRY.get(geometry, 0.0) or 0.0


def get_ideal_angle_for_site_pair(
    t: TrexFull,
    site_i_idx: int,
    site_j_idx: int,
    is_trans: bool,
) -> float:
    """
    Get ideal cos(θ) for a pair of sites given the full T-REX structure.

    This is the main interface for HyperMPNN - handles all geometry cases
    including pentagonal bipyramidal with position-dependent angles.

    Args:
        t: TrexFull object with geometry information
        site_i_idx: Index in the canonical site ordering (0-based)
        site_j_idx: Index in the canonical site ordering (0-based)
        is_trans: Whether this pair is a trans pair

    Returns:
        Ideal cos(θ) value
    """
    if is_trans:
        return IDEAL_TRANS_COS

    geometry = t.G or t.get_geo_type()
    n_pairs = len(t.pairs)
    n_singles = len(t.singles)

    # Determine if each site is in a trans pair (axial) or single (equatorial)
    # Sites are ordered: pairs[0][0], pairs[0][1],
    # pairs[1][0], pairs[1][1], ..., singles[0], singles[1], ...
    n_pair_sites = 2 * n_pairs

    site_i_in_trans = site_i_idx < n_pair_sites
    site_j_in_trans = site_j_idx < n_pair_sites

    # Get singles indices if applicable
    site_i_singles_idx = None
    site_j_singles_idx = None

    if not site_i_in_trans:
        site_i_singles_idx = site_i_idx - n_pair_sites
    if not site_j_in_trans:
        site_j_singles_idx = site_j_idx - n_pair_sites

    return get_ideal_cis_cos(
        geometry=geometry,
        site_i_in_trans=site_i_in_trans,
        site_j_in_trans=site_j_in_trans,
        site_i_singles_idx=site_i_singles_idx,
        site_j_singles_idx=site_j_singles_idx,
        n_singles=n_singles,
    )


def has_coordinates(t: TrexFull) -> bool:
    """Check if all sites have coordinates attached."""
    for a, b in t.pairs:
        if a.coord is None or b.coord is None:
            return False
    for s in t.singles:
        if s.coord is None:
            return False
    return True


def extract_geometric_features(t: TrexFull) -> dict | None:
    """
    Extract Δr and Δcos(θ) from a canonicalized TrexFull with coordinates.

    Assumes coordinates are metal-relative (metal at origin).

    The output ordering matches the canonical T-REX site ordering:
    - Sites: pairs[0][0], pairs[0][1], pairs[1][0], pairs[1][1], ..., singles[0], singles[1], ...
    - Trans angles: one per pair, in pair order
    - Cis angles: all (i,j) with i < j that are not trans partners, in canonical order

    Args:
        t: Canonicalized TrexFull with metal-relative coordinates on MapSites

    Returns:
        Dictionary containing:
            - n_sites: number of coordination sites
            - geometry: geometry flag
            - site_r: actual M-site distances
            - site_delta_r: Δr values (actual - ideal)
            - site_is_haptic: boolean flags for haptic sites
            - site_coord_symbol: coordinating atom symbols
            - trans_cos: actual cos(θ) for trans pairs
            - trans_delta_cos: Δcos(θ) for trans pairs
            - trans_ideal_cos: ideal cos(θ) for trans pairs (always -1)
            - cis_cos: actual cos(θ) for cis pairs
            - cis_delta_cos: Δcos(θ) for cis pairs
            - cis_ideal_cos: ideal cos(θ) for cis pairs
            - cis_pair_indices: (i, j) site index pairs for cis angles
        Returns None if coordinates are missing.
    """
    if not has_coordinates(t):
        return None

    # Build ordered site list (canonical order)
    sites_ordered: list[MapSite] = []
    site_in_trans: list[bool] = []

    for a, b in t.pairs:
        sites_ordered.append(a)
        site_in_trans.append(True)
        sites_ordered.append(b)
        site_in_trans.append(True)

    for s in t.singles:
        sites_ordered.append(s)
        site_in_trans.append(False)

    n_sites = len(sites_ordered)

    if n_sites == 0:
        return None

    # Metal at origin (coordinates should already be metal-relative)
    # Extract site coordinates
    site_coords = np.array([s.coord for s in sites_ordered])

    # Compute distances
    site_r: list[float] = []
    site_delta_r: list[float] = []
    site_is_haptic: list[bool] = []
    site_coord_symbol: list[str] = []

    for i, s in enumerate(sites_ordered):
        r_actual = float(np.linalg.norm(site_coords[i]))
        site_r.append(r_actual)

        # Get ligand SMILES
        lig_payload = t.ligands[s.lig - 1]
        lig_smi = lig_payload.text if lig_payload.kind == "SMILES" else ""

        r_ideal = get_ideal_distance(t.metal, s, lig_smi)
        site_delta_r.append(r_actual - r_ideal)

        is_hap = is_haptic_site(s)
        site_is_haptic.append(is_hap)

        if is_hap:
            site_coord_symbol.append("Cp")  # placeholder for haptic
        else:
            site_coord_symbol.append(_get_coord_atom_symbol(s, lig_smi))

    # Trans pair angles
    trans_cos: list[float] = []
    trans_delta_cos: list[float] = []
    trans_ideal_cos: list[float] = []

    for pi in range(len(t.pairs)):
        idx_a = 2 * pi
        idx_b = 2 * pi + 1

        va = site_coords[idx_a]
        vb = site_coords[idx_b]

        norm_a = np.linalg.norm(va)
        norm_b = np.linalg.norm(vb)

        if norm_a > 1e-6 and norm_b > 1e-6:
            cos_theta = float(np.dot(va, vb) / (norm_a * norm_b))
        else:
            cos_theta = IDEAL_TRANS_COS  # fallback

        ideal = IDEAL_TRANS_COS
        trans_cos.append(cos_theta)
        trans_delta_cos.append(cos_theta - ideal)
        trans_ideal_cos.append(ideal)

    # Cis pair angles (all i < j not in same trans pair)
    cis_cos: list[float] = []
    cis_delta_cos: list[float] = []
    cis_ideal_cos: list[float] = []
    cis_pair_indices: list[tuple[int, int]] = []

    geometry = t.G or t.get_geo_type()

    # Build set of trans pair index tuples for quick lookup
    trans_pair_set = set()
    for pi in range(len(t.pairs)):
        idx_a = 2 * pi
        idx_b = 2 * pi + 1
        trans_pair_set.add((idx_a, idx_b))
        trans_pair_set.add((idx_b, idx_a))

    n_pair_sites = 2 * len(t.pairs)
    n_singles = len(t.singles)

    for i in range(n_sites):
        for j in range(i + 1, n_sites):
            # Skip trans partners
            if (i, j) in trans_pair_set:
                continue

            va = site_coords[i]
            vb = site_coords[j]

            norm_a = np.linalg.norm(va)
            norm_b = np.linalg.norm(vb)

            if norm_a > 1e-6 and norm_b > 1e-6:
                cos_theta = float(np.dot(va, vb) / (norm_a * norm_b))
            else:
                cos_theta = 0.0  # fallback

            # Get singles indices if applicable
            site_i_singles_idx = None if i < n_pair_sites else (i - n_pair_sites)
            site_j_singles_idx = None if j < n_pair_sites else (j - n_pair_sites)

            ideal_cos = get_ideal_cis_cos(
                geometry=geometry,
                site_i_in_trans=site_in_trans[i],
                site_j_in_trans=site_in_trans[j],
                site_i_singles_idx=site_i_singles_idx,
                site_j_singles_idx=site_j_singles_idx,
                n_singles=n_singles,
            )

            cis_cos.append(cos_theta)
            cis_delta_cos.append(cos_theta - ideal_cos)
            cis_ideal_cos.append(ideal_cos)
            cis_pair_indices.append((i, j))

    return {
        "n_sites": n_sites,
        "n_trans_pairs": len(t.pairs),
        "n_cis_pairs": len(cis_pair_indices),
        "geometry": geometry,
        "site_r": site_r,
        "site_delta_r": site_delta_r,
        "site_is_haptic": site_is_haptic,
        "site_coord_symbol": site_coord_symbol,
        "trans_cos": trans_cos,
        "trans_delta_cos": trans_delta_cos,
        "trans_ideal_cos": trans_ideal_cos,
        "cis_cos": cis_cos,
        "cis_delta_cos": cis_delta_cos,
        "cis_ideal_cos": cis_ideal_cos,
        "cis_pair_indices": cis_pair_indices,
    }


__all__ = [
    "extract_geometric_features",
    "has_coordinates",
    "get_ideal_distance",
    "get_ideal_cis_cos",
    "get_ideal_angle_for_site_pair",
    "is_haptic_site",
    "COVALENT_RADII",
    "HAPTIC_IDEAL_DISTANCE",
    "IDEAL_TRANS_COS",
    "PNTBP_CLOSE_CIS_COS",
    "PNTBP_FAR_CIS_COS",
]
