# trex/graph_hash.py Calculate WL hash for final tiebrakers
from __future__ import annotations

import networkx as nx
from networkx.algorithms.graph_hashing import weisfeiler_lehman_graph_hash as wl_hash
from rdkit import Chem


def _as_graph(
    mol: Chem.Mol,
    include_hs: bool = True,
    charge_agnostic: bool = True,
) -> nx.Graph:
    """
    RDKit Mol -> NetworkX Graph for WL hashing.

    - include_hs=True: expand to explicit Hs (Chem.AddHs) so protonation differences
      change the hash.
    - charge_agnostic=True: drop formal charge from node labels so Cl vs [Cl-] hash the same.
    """
    m = Chem.Mol(mol)
    if include_hs:
        m = Chem.AddHs(m, explicitOnly=False, addCoords=False)
    else:
        m = Chem.RemoveHs(m, implicitOnly=False)

    # Make sure aromatic / ring flags are set consistently
    Chem.SanitizeMol(m)

    g = nx.Graph()

    for a in m.GetAtoms():
        # Count explicit-H neighbors after AddHs (robust across inputs)
        h_neighbors = 0
        for nbr in a.GetNeighbors():
            if nbr.GetAtomicNum() == 1:
                h_neighbors += 1

        # Base label (no formal charge if charge_agnostic)
        label = (
            int(a.GetAtomicNum()),
            bool(a.GetIsAromatic()),
            bool(a.IsInRing()),
            int(a.GetDegree()),  # degree *after* adding Hs
            int(h_neighbors),  # explicit H neighbors
        )
        if not charge_agnostic:
            label = label + (int(a.GetFormalCharge()),)

        g.add_node(a.GetIdx(), label=label)

    for b in m.GetBonds():
        bt = b.GetBondType()
        if bt == Chem.BondType.SINGLE:
            et = 1
        elif bt == Chem.BondType.DOUBLE:
            et = 2
        elif bt == Chem.BondType.TRIPLE:
            et = 3
        elif bt == Chem.BondType.AROMATIC:
            et = 4
        else:
            et = 0
        g.add_edge(b.GetBeginAtomIdx(), b.GetEndAtomIdx(), label=et)

    return g


def hash_mol(
    mol: Chem.Mol,
    *,
    include_hs: bool = True,
    charge_agnostic: bool = True,
) -> str:
    """WL hash with the chosen invariances."""
    g = _as_graph(mol, include_hs=include_hs, charge_agnostic=charge_agnostic)
    return wl_hash(g, node_attr="label", edge_attr="label")
