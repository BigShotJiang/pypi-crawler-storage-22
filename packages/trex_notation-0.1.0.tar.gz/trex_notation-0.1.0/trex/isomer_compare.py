# trex/isomer_compare.py
"""
Isomer classification by T-REX comparison.

Classifies the relationship between two T-REX structures:
- IDENTICAL: Same structure
- ENANTIOMER: Mirror images (differ only in X flag)
- COORDINATION_ISOMER: Same sites, different arrangement
- GEOMETRIC_ISOMER: Different geometry (G flag)
- LINKAGE_ISOMER: Same ligands/denticity, different binding atoms
- HEMILABILE_ISOMER: Same ligands, different denticity
- NOT_ISOMERS: Different composition
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from enum import Enum, auto
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from trex.model import LigandPayload, MapSite, TrexFull


class IsomerType(Enum):
    """Classification of isomeric relationship between two complexes."""

    IDENTICAL = auto()
    ENANTIOMER = auto()
    COORDINATION_ISOMER = auto()
    GEOMETRIC_ISOMER = auto()
    LINKAGE_ISOMER = auto()  # Same denticity, different binding atoms
    HEMILABILE_ISOMER = auto()  # Different denticity
    NOT_ISOMERS = auto()  # Different composition


@dataclass
class IsomerComparison:
    """Result of comparing two T-REX structures."""

    isomer_type: IsomerType
    details: str = ""

    def __str__(self) -> str:
        if self.details:
            return f"{self.isomer_type.name}: {self.details}"
        return self.isomer_type.name


def _ligand_key(lp: LigandPayload) -> tuple[str, str]:
    """Get hashable key for a ligand payload."""
    return (lp.kind, lp.text)


def _ligands_as_multiset(t: TrexFull) -> Counter:
    """Get ligands as a multiset (Counter) for unordered comparison."""
    return Counter(_ligand_key(lp) for lp in t.ligands)


def _sites_per_ligand(t: TrexFull) -> dict[int, set[tuple[int, ...]]]:
    """
    Get coordinating sites per ligand index.
    Returns {lig_idx: {(atom1, atom2, ...), ...}}
    """
    sites: dict[int, set[tuple[int, ...]]] = {}

    for a, b in t.pairs:
        sites.setdefault(a.lig, set()).add(tuple(sorted(a.atoms)))
        sites.setdefault(b.lig, set()).add(tuple(sorted(b.atoms)))

    for s in t.singles:
        sites.setdefault(s.lig, set()).add(tuple(sorted(s.atoms)))

    return sites


def _denticity_per_ligand(t: TrexFull) -> dict[int, int]:
    """Get denticity (number of coordination sites) per ligand index."""
    sites = _sites_per_ligand(t)
    return {lig: len(site_set) for lig, site_set in sites.items()}


def _sites_by_ligand_key(t: TrexFull) -> dict[tuple[str, str], list[set[tuple[int, ...]]]]:
    """
    Get sites grouped by ligand identity (kind, text).

    For each unique ligand type, collect all site sets from all instances.
    Returns {(kind, text): [site_set_1, site_set_2, ...]}

    This handles the case where identical ligands may be in different
    canonical positions.
    """
    sites_per_lig = _sites_per_ligand(t)

    result: dict[tuple[str, str], list[set[tuple[int, ...]]]] = {}

    for lig_idx, site_set in sites_per_lig.items():
        lp = t.ligands[lig_idx - 1]
        key = _ligand_key(lp)
        result.setdefault(key, []).append(site_set)

    return result


def _normalize_sites_for_comparison(
    sites_by_key: dict[tuple[str, str], list[set[tuple[int, ...]]]],
) -> dict[tuple[str, str], tuple[tuple[tuple[int, ...], ...], ...]]:
    """
    Normalize sites for comparison: sort site sets within each ligand type.

    This handles the fact that identical ligands may appear in different
    order between two T-REX strings.
    """
    result = {}
    for key, site_lists in sites_by_key.items():
        # Sort each site set, then sort the list of site sets
        normalized = tuple(sorted(tuple(sorted(site_set)) for site_set in site_lists))
        result[key] = normalized
    return result


def _map_signature(t: TrexFull) -> tuple:
    """
    Get a canonical signature of the MAP block for comparison.

    Returns a sorted tuple of (pair_signatures, single_signatures).
    """

    def site_sig(s: MapSite) -> tuple:
        lp = t.ligands[s.lig - 1]
        return (_ligand_key(lp), tuple(sorted(s.atoms)))

    # Normalize pairs: each pair is sorted, then pairs are sorted
    pair_sigs = []
    for a, b in t.pairs:
        sig_a, sig_b = site_sig(a), site_sig(b)
        pair_sigs.append(tuple(sorted([sig_a, sig_b])))
    pair_sigs = tuple(sorted(pair_sigs))

    # Singles are sorted
    single_sigs = tuple(sorted(site_sig(s) for s in t.singles))

    return (pair_sigs, single_sigs)


def compare_isomers(t1: TrexFull, t2: TrexFull) -> IsomerComparison:
    """
    Compare two T-REX structures and classify their isomeric relationship.

    Args:
        t1: First TrexFull object
        t2: Second TrexFull object

    Returns:
        IsomerComparison with classification and details
    """
    # Level 0: Same metal, ox, spin?
    if t1.metal != t2.metal:
        return IsomerComparison(
            IsomerType.NOT_ISOMERS, f"Different metal: {t1.metal} vs {t2.metal}"
        )

    if t1.ox != t2.ox:
        return IsomerComparison(
            IsomerType.NOT_ISOMERS, f"Different oxidation state: {t1.ox} vs {t2.ox}"
        )

    if t1.spin != t2.spin:
        return IsomerComparison(IsomerType.NOT_ISOMERS, f"Different spin: {t1.spin} vs {t2.spin}")

    # Level 1: Same ligands (as multiset)?
    lig_ms1 = _ligands_as_multiset(t1)
    lig_ms2 = _ligands_as_multiset(t2)

    if lig_ms1 != lig_ms2:
        return IsomerComparison(IsomerType.NOT_ISOMERS, "Different ligand composition")

    # Level 2: Same coordinating sites per ligand type?
    sites1 = _sites_by_ligand_key(t1)
    sites2 = _sites_by_ligand_key(t2)

    norm_sites1 = _normalize_sites_for_comparison(sites1)
    norm_sites2 = _normalize_sites_for_comparison(sites2)

    if norm_sites1 != norm_sites2:
        # Sites differ - check if it's denticity change or binding mode change
        dent1 = _denticity_per_ligand(t1)
        dent2 = _denticity_per_ligand(t2)

        # Get denticity per ligand TYPE (not index)
        dent_by_type1: dict[tuple[str, str], list[int]] = {}
        dent_by_type2: dict[tuple[str, str], list[int]] = {}

        for lig_idx, dent in dent1.items():
            key = _ligand_key(t1.ligands[lig_idx - 1])
            dent_by_type1.setdefault(key, []).append(dent)

        for lig_idx, dent in dent2.items():
            key = _ligand_key(t2.ligands[lig_idx - 1])
            dent_by_type2.setdefault(key, []).append(dent)

        # Normalize for comparison
        norm_dent1 = {k: tuple(sorted(v)) for k, v in dent_by_type1.items()}
        norm_dent2 = {k: tuple(sorted(v)) for k, v in dent_by_type2.items()}

        if norm_dent1 != norm_dent2:
            return IsomerComparison(
                IsomerType.HEMILABILE_ISOMER, "Same ligands, different denticity"
            )
        else:
            return IsomerComparison(
                IsomerType.LINKAGE_ISOMER, "Same ligands and denticity, different binding atoms"
            )

    # Level 3: Same geometry?
    # Use get_geo_type() to normalize geometry representation
    geo1 = t1.get_geo_type()
    geo2 = t2.get_geo_type()

    if geo1 != geo2:
        return IsomerComparison(
            IsomerType.GEOMETRIC_ISOMER, f"Different geometry: {geo1} vs {geo2}"
        )

    # Level 4: Same MAP arrangement?
    map1 = _map_signature(t1)
    map2 = _map_signature(t2)

    if map1 != map2:
        return IsomerComparison(
            IsomerType.COORDINATION_ISOMER, "Same sites, different spatial arrangement"
        )

    # Level 5: Same chirality?
    if t1.X != t2.X:
        # Check if it's an enantiomeric relationship
        enantiomer_pairs = {("@", "@@"), ("@@", "@"), ("Δ", "Λ"), ("Λ", "Δ")}
        if (t1.X, t2.X) in enantiomer_pairs:
            return IsomerComparison(IsomerType.ENANTIOMER, f"Mirror images: {t1.X} vs {t2.X}")
        else:
            # Different X flags but not enantiomeric (shouldn't happen normally)
            return IsomerComparison(
                IsomerType.COORDINATION_ISOMER, f"Different chirality flags: {t1.X} vs {t2.X}"
            )

    # Everything matches
    return IsomerComparison(IsomerType.IDENTICAL, "Identical structures")


def classify_isomer_set(
    structures: list[TrexFull],
) -> dict[str, list[tuple[int, int, IsomerComparison]]]:
    """
    Classify all pairwise relationships in a set of structures.

    Args:
        structures: List of TrexFull objects

    Returns:
        Dictionary mapping isomer type names to lists of (i, j, comparison) tuples
    """
    results: dict[str, list[tuple[int, int, IsomerComparison]]] = {t.name: [] for t in IsomerType}

    n = len(structures)
    for i in range(n):
        for j in range(i + 1, n):
            comp = compare_isomers(structures[i], structures[j])
            results[comp.isomer_type.name].append((i, j, comp))

    return results


def group_by_isomer_class(
    structures: list[TrexFull],
    group_level: IsomerType = IsomerType.COORDINATION_ISOMER,
) -> list[list[int]]:
    """
    Group structures that are isomers at the specified level or closer.

    For example, with group_level=COORDINATION_ISOMER:
    - Enantiomers, coordination isomers, and identical structures are grouped together
    - Geometric, linkage, hemilabile isomers start new groups

    Args:
        structures: List of TrexFull objects
        group_level: Isomer types at this level or "closer" are grouped

    Returns:
        List of groups, where each group is a list of structure indices
    """
    # Define hierarchy (lower = more similar)
    hierarchy = {
        IsomerType.IDENTICAL: 0,
        IsomerType.ENANTIOMER: 1,
        IsomerType.COORDINATION_ISOMER: 2,
        IsomerType.GEOMETRIC_ISOMER: 3,
        IsomerType.LINKAGE_ISOMER: 4,
        IsomerType.HEMILABILE_ISOMER: 5,
        IsomerType.NOT_ISOMERS: 6,
    }

    threshold = hierarchy[group_level]
    n = len(structures)

    # Union-find for grouping
    parent = list(range(n))

    def find(x: int) -> int:
        if parent[x] != x:
            parent[x] = find(parent[x])
        return parent[x]

    def union(x: int, y: int) -> None:
        px, py = find(x), find(y)
        if px != py:
            parent[px] = py

    # Group structures that are similar enough
    for i in range(n):
        for j in range(i + 1, n):
            comp = compare_isomers(structures[i], structures[j])
            if hierarchy[comp.isomer_type] <= threshold:
                union(i, j)

    # Collect groups
    groups: dict[int, list[int]] = {}
    for i in range(n):
        root = find(i)
        groups.setdefault(root, []).append(i)

    return list(groups.values())


# =============================================================================
# EFFICIENT BATCH CLASSIFICATION FOR LARGE DATASETS
# =============================================================================


@dataclass
class IsomerFingerprint:
    """
    Hierarchical fingerprint for efficient isomer detection.

    Levels (from coarse to fine):
    1. composition_hash: (metal, ox, spin, ligand_multiset)
    2. site_hash: + sites per ligand type (catches linkage/hemilabile)
    3. geo_hash: + geometry flag
    4. map_hash: + MAP arrangement
    5. full_hash: + chirality (X flag)

    Structures with different composition_hash CANNOT be isomers.
    """

    idx: int  # Original index in dataset

    # Level 1: Composition
    composition_hash: str

    # Level 2: Sites (which atoms coordinate)
    site_hash: str

    # Level 3: Geometry
    geo_hash: str

    # Level 4: MAP arrangement
    map_hash: str

    # Level 5: Full (including chirality)
    full_hash: str

    # Store X separately for enantiomer detection
    chirality: str | None = None


def _stable_hash(obj) -> str:
    """Create a stable string hash from a nested Python object."""
    import hashlib
    import json

    # Convert to JSON string (sorted keys for determinism)
    s = json.dumps(obj, sort_keys=True, default=str)
    return hashlib.md5(s.encode()).hexdigest()[:16]


def compute_fingerprint(t: TrexFull, idx: int = 0) -> IsomerFingerprint:
    """
    Compute hierarchical fingerprint for a single TrexFull.

    Args:
        t: TrexFull object
        idx: Index in original dataset (for tracking)

    Returns:
        IsomerFingerprint with all hash levels
    """
    # Level 1: Composition
    lig_multiset = sorted(_ligand_key(lp) for lp in t.ligands)
    composition = (t.metal, t.ox, t.spin, tuple(lig_multiset))
    composition_hash = _stable_hash(composition)

    # Level 2: Sites per ligand type
    sites_by_type = _normalize_sites_for_comparison(_sites_by_ligand_key(t))
    site_data = (composition, sorted(sites_by_type.items()))
    site_hash = _stable_hash(site_data)

    # Level 3: Geometry
    geo = t.get_geo_type()
    geo_data = (site_data, geo)
    geo_hash = _stable_hash(geo_data)

    # Level 4: MAP arrangement
    map_sig = _map_signature(t)
    map_data = (geo_data, map_sig)
    map_hash = _stable_hash(map_data)

    # Level 5: Full (including chirality)
    full_data = (map_data, t.X)
    full_hash = _stable_hash(full_data)

    return IsomerFingerprint(
        idx=idx,
        composition_hash=composition_hash,
        site_hash=site_hash,
        geo_hash=geo_hash,
        map_hash=map_hash,
        full_hash=full_hash,
        chirality=t.X,
    )


def compute_fingerprints_batch(
    structures: list[TrexFull],
    show_progress: bool = True,
) -> list[IsomerFingerprint]:
    """
    Compute fingerprints for all structures in batch.

    Args:
        structures: List of TrexFull objects
        show_progress: Whether to show progress bar

    Returns:
        List of IsomerFingerprints
    """
    if show_progress:
        try:
            from tqdm import tqdm

            iterator = tqdm(enumerate(structures), total=len(structures), desc="Fingerprinting")
        except ImportError:
            iterator = enumerate(structures)
    else:
        iterator = enumerate(structures)

    return [compute_fingerprint(t, idx) for idx, t in iterator]


@dataclass
class IsomerSet:
    """
    A set of structures that share the same isomer relationship.

    Attributes:
        indices: Original dataset indices of structures in this set
        isomer_type: The relationship between structures in this set
        representative_idx: Index of a representative structure
    """

    indices: list[int]
    isomer_type: IsomerType
    representative_idx: int

    def __len__(self) -> int:
        return len(self.indices)


def find_isomer_sets_fast(
    structures: list[TrexFull],
    fingerprints: list[IsomerFingerprint] | None = None,
    group_level: IsomerType = IsomerType.COORDINATION_ISOMER,
    show_progress: bool = True,
) -> list[IsomerSet]:
    """
    Efficiently find all isomer sets in a large dataset.

    Uses hierarchical hashing to avoid O(n²) comparisons.

    Args:
        structures: List of TrexFull objects
        fingerprints: Pre-computed fingerprints (optional, will compute if None)
        group_level: Group structures at this isomer level or closer
        show_progress: Whether to show progress bar

    Returns:
        List of IsomerSets, each containing indices of isomeric structures
    """
    if fingerprints is None:
        fingerprints = compute_fingerprints_batch(structures, show_progress)

    # Determine which hash level to use for grouping
    hash_attr = {
        IsomerType.IDENTICAL: "full_hash",
        IsomerType.ENANTIOMER: "map_hash",  # Same map, differ only in X
        IsomerType.COORDINATION_ISOMER: "geo_hash",  # Same geo, differ in map
        IsomerType.GEOMETRIC_ISOMER: "site_hash",  # Same sites, differ in geo
        IsomerType.LINKAGE_ISOMER: "composition_hash",  # Same composition, differ in sites
        IsomerType.HEMILABILE_ISOMER: "composition_hash",
    }

    group_attr = hash_attr.get(group_level, "composition_hash")

    # Group by the appropriate hash
    buckets: dict[str, list[IsomerFingerprint]] = {}
    for fp in fingerprints:
        key = getattr(fp, group_attr)
        buckets.setdefault(key, []).append(fp)

    # Build isomer sets
    results: list[IsomerSet] = []

    for bucket in buckets.values():
        if len(bucket) == 1:
            # Single structure - it's its own set
            results.append(
                IsomerSet(
                    indices=[bucket[0].idx],
                    isomer_type=IsomerType.IDENTICAL,
                    representative_idx=bucket[0].idx,
                )
            )
        else:
            # Multiple structures - determine their relationship
            indices = [fp.idx for fp in bucket]

            # Use the first pair to determine relationship type
            # (all pairs in bucket should have same relationship at group_level)
            if len(set(fp.full_hash for fp in bucket)) == 1:
                iso_type = IsomerType.IDENTICAL
            elif len(set(fp.map_hash for fp in bucket)) == 1:
                iso_type = IsomerType.ENANTIOMER
            elif len(set(fp.geo_hash for fp in bucket)) == 1:
                iso_type = IsomerType.COORDINATION_ISOMER
            elif len(set(fp.site_hash for fp in bucket)) == 1:
                iso_type = IsomerType.GEOMETRIC_ISOMER
            else:
                # Need to check if linkage or hemilabile
                # This requires actual structure comparison
                t1, t2 = structures[bucket[0].idx], structures[bucket[1].idx]
                comp = compare_isomers(t1, t2)
                iso_type = comp.isomer_type

            results.append(
                IsomerSet(
                    indices=indices,
                    isomer_type=iso_type,
                    representative_idx=indices[0],
                )
            )

    return results


def find_isomer_sets_detailed(
    structures: list[TrexFull],
    fingerprints: list[IsomerFingerprint] | None = None,
    show_progress: bool = True,
) -> dict[str, list[IsomerSet]]:
    """
    Find isomer sets at ALL levels of the hierarchy.

    Returns a dictionary with keys for each isomer type.

    Args:
        structures: List of TrexFull objects
        fingerprints: Pre-computed fingerprints (optional)
        show_progress: Whether to show progress bar

    Returns:
        Dict mapping isomer type names to lists of IsomerSets
    """
    if fingerprints is None:
        fingerprints = compute_fingerprints_batch(structures, show_progress)

    results: dict[str, list[IsomerSet]] = {t.name: [] for t in IsomerType}

    # Group by composition first (everything else requires same composition)
    comp_buckets: dict[str, list[IsomerFingerprint]] = {}
    for fp in fingerprints:
        comp_buckets.setdefault(fp.composition_hash, []).append(fp)

    for comp_bucket in comp_buckets.values():
        if len(comp_bucket) == 1:
            continue  # No isomers possible

        # Within composition bucket, group by site_hash
        site_buckets: dict[str, list[IsomerFingerprint]] = {}
        for fp in comp_bucket:
            site_buckets.setdefault(fp.site_hash, []).append(fp)

        # Check for linkage/hemilabile isomers (different site_hash, same composition)
        if len(site_buckets) > 1:
            # Need to determine if linkage or hemilabile
            site_groups = list(site_buckets.values())
            t1 = structures[site_groups[0][0].idx]
            t2 = structures[site_groups[1][0].idx]
            comp = compare_isomers(t1, t2)

            all_indices = [fp.idx for fp in comp_bucket]
            results[comp.isomer_type.name].append(
                IsomerSet(
                    indices=all_indices,
                    isomer_type=comp.isomer_type,
                    representative_idx=all_indices[0],
                )
            )

        # Within each site bucket, group by geo_hash
        for site_bucket in site_buckets.values():
            if len(site_bucket) == 1:
                continue

            geo_buckets: dict[str, list[IsomerFingerprint]] = {}
            for fp in site_bucket:
                geo_buckets.setdefault(fp.geo_hash, []).append(fp)

            # Check for geometric isomers (different geo_hash, same site_hash)
            if len(geo_buckets) > 1:
                all_indices = [fp.idx for fp in site_bucket]
                results["GEOMETRIC_ISOMER"].append(
                    IsomerSet(
                        indices=all_indices,
                        isomer_type=IsomerType.GEOMETRIC_ISOMER,
                        representative_idx=all_indices[0],
                    )
                )

            # Within each geo bucket, group by map_hash
            for geo_bucket in geo_buckets.values():
                if len(geo_bucket) == 1:
                    continue

                map_buckets: dict[str, list[IsomerFingerprint]] = {}
                for fp in geo_bucket:
                    map_buckets.setdefault(fp.map_hash, []).append(fp)

                # Check for coordination isomers (different map_hash, same geo_hash)
                if len(map_buckets) > 1:
                    all_indices = [fp.idx for fp in geo_bucket]
                    results["COORDINATION_ISOMER"].append(
                        IsomerSet(
                            indices=all_indices,
                            isomer_type=IsomerType.COORDINATION_ISOMER,
                            representative_idx=all_indices[0],
                        )
                    )

                # Within each map bucket, check for enantiomers
                for map_bucket in map_buckets.values():
                    if len(map_bucket) == 1:
                        continue

                    # Same map_hash - check if enantiomers or identical
                    chiralities = set(fp.chirality for fp in map_bucket)

                    if len(chiralities) > 1 and None not in chiralities:
                        # Different chirality flags = enantiomers
                        all_indices = [fp.idx for fp in map_bucket]
                        results["ENANTIOMER"].append(
                            IsomerSet(
                                indices=all_indices,
                                isomer_type=IsomerType.ENANTIOMER,
                                representative_idx=all_indices[0],
                            )
                        )
                    elif len(set(fp.full_hash for fp in map_bucket)) == 1:
                        # Identical structures
                        all_indices = [fp.idx for fp in map_bucket]
                        results["IDENTICAL"].append(
                            IsomerSet(
                                indices=all_indices,
                                isomer_type=IsomerType.IDENTICAL,
                                representative_idx=all_indices[0],
                            )
                        )

    return results


import pandas as pd


def to_dataframe(
    fingerprints: list[IsomerFingerprint],
) -> pd.DataFrame:
    """
    Convert fingerprints to a pandas DataFrame for analysis.

    Useful for custom groupby operations and visualization.
    """

    records = [
        {
            "idx": fp.idx,
            "composition_hash": fp.composition_hash,
            "site_hash": fp.site_hash,
            "geo_hash": fp.geo_hash,
            "map_hash": fp.map_hash,
            "full_hash": fp.full_hash,
            "chirality": fp.chirality,
        }
        for fp in fingerprints
    ]

    return pd.DataFrame(records)


def summarize_isomer_sets(
    isomer_sets: dict[str, list[IsomerSet]],
) -> dict[str, dict]:
    """
    Generate summary statistics for isomer classification results.
    """
    summary = {}
    for iso_type, sets in isomer_sets.items():
        if not sets:
            continue

        sizes = [len(s) for s in sets]
        summary[iso_type] = {
            "num_sets": len(sets),
            "total_structures": sum(sizes),
            "avg_set_size": sum(sizes) / len(sizes) if sizes else 0,
            "max_set_size": max(sizes) if sizes else 0,
            "min_set_size": min(sizes) if sizes else 0,
        }

    return summary


__all__ = [
    "IsomerType",
    "IsomerComparison",
    "compare_isomers",
    "classify_isomer_set",
    "group_by_isomer_class",
    # Batch processing
    "IsomerFingerprint",
    "IsomerSet",
    "compute_fingerprint",
    "compute_fingerprints_batch",
    "find_isomer_sets_fast",
    "find_isomer_sets_detailed",
    "to_dataframe",
    "summarize_isomer_sets",
]
