# trex/model.py
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


# ---------------------- MINIMAL MODEL ---------------------- #
class TrexMin(BaseModel):
    """
    Minimal T-REX: no per-site atom lists, tokenized ligands only.
    """

    metal: str
    ox: int
    spin: int | None = None
    ligands: list[str]
    pairs: list[tuple[int, int]] = Field(default_factory=list)  # ligand-level pairs (1-based)
    singles: list[int] = Field(default_factory=list)  # ligand-level singletons (1-based)
    G: str | None = None  # geometry flag (e.g. O, TP.)
    lig_hashes: list[str] | None = None  # optional structural hashes used for canonical tiebreaks

    def cn(self) -> int:
        """Coordination number = number of ligand sites."""
        return 2 * len(self.pairs) + len(self.singles)


# ---------------------- FULL MODEL ------------------------- #
class LigandPayload(BaseModel):
    """
    One ligand's textual payload. Use one of:
      - kind="SMILES"  -> text = canonical SMILES
      - kind="SELFIES" -> text = SELFIES string
      - kind="INCHI"   -> text = InChI string
      - kind="TOKEN"   -> text = registry token (e.g., 'bpy', 'cl', 'nh3')
    """

    kind: Literal["SMILES", "SELFIES", "INCHI", "TOKEN"]
    text: str


class MapSite(BaseModel):
    """
    A specific coordination site on a given ligand:
      - lig   : 1-based ligand index referring into TrexFull.ligands
      - atoms : 1-based *local* atom indices within that ligand's payload
                (for SMILES these track atom-map remaps).
      - coord : optional 3D centroid (x, y, z) for chirality computation.
                Excluded from serialization (not part of T-REX string).
    """

    lig: int
    atoms: list[int] = Field(default_factory=list)
    coord: tuple[float, float, float] | None = Field(default=None, exclude=True)


class TrexFull(BaseModel):
    """
    Full T-REX: per-site atoms + explicit payloads per ligand.
    """

    metal: str
    ox: int
    spin: int | None = None
    ligands: list[LigandPayload]
    pairs: list[tuple[MapSite, MapSite]] = Field(default_factory=list)  # site-level pairs
    singles: list[MapSite] = Field(default_factory=list)  # site-level singletons
    G: str | None = None
    X: str | None = None  # chirality flag (@, @@) or other aux flags

    def cn(self) -> int:
        """Coordination number = number of sites = 2*len(pairs) + len(singles)."""
        return 2 * len(self.pairs) + len(self.singles)

    def get_geo_type(self) -> str:
        """
        Get geometry type from count of pairs and singles.
        If G is provided, return it. Otherwise infer a coarse geometry from site counts.
        Conventions mirror your prior labels:
        - p = len(pairs), s = len(singles)
        - p==3      -> 'O'     (octahedral, CN=6)
        - p==2      -> 'sqpl' if s==0 else 'sqpy'   (square planar vs square pyramidal)
        - p==1 & s==0 -> 'ln'  (linear, CN=2)
        - p==1 & s==1 -> 'tsh' (T-shaped, CN=3)
        - p==1 & s==2 -> 'ssw' (see-saw, CN=4)
        - p==1 & s==3 -> 'trbp' (trigonal bipyramidal, CN=5)
        - p==1 & s>=4 -> 'pntbp' (pentagonal TBP-like catch-all)
        - p==0 & s==2 -> 'bnt'  (bent, CN=2)
        - p==0 & s==3 -> 'trpl' (trigonal planar, CN=3)
        - else       -> 'thd'  (default "three-dimensional" bucket)
        """
        if self.G is not None:
            return self.G

        p = len(self.pairs)
        s = len(self.singles)

        if p == 3:
            return "O"
        elif p == 2:
            return "sqpl" if s == 0 else "sqpy"
        elif p == 1:
            if s == 0:
                return "ln"
            elif s == 1:
                return "tsh"
            elif s == 2:
                return "ssw"
            elif s == 3:
                return "trbp"
            else:
                return "pntbp"
        else:
            if s == 2:
                return "bnt"
            elif s == 3:
                return "trpl"
            elif s == 4:
                return "thd"
            else:
                return "unk"


LigandPayload.model_rebuild()
MapSite.model_rebuild()
TrexFull.model_rebuild()
TrexMin.model_rebuild()

__all__ = ["TrexMin", "LigandPayload", "MapSite", "TrexFull"]
