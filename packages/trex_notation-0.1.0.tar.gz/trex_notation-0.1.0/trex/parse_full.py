# trex/parse_full.py  T-REX parser for creating TrexFull model
from __future__ import annotations

import re

from pydantic import ValidationError

from .canon_full import canonicalize_full
from .canon_full import pretty_trex_full as _pretty_full
from .model import LigandPayload, MapSite, TrexFull

_HEAD = re.compile(r"^([A-Z][a-z]?)\{([+-]?\d+)(?:,S=(\d+))?\}$")
_LBLK = re.compile(r"^L=\[\s*(.*)\s*\]$")
_MAP = re.compile(r"^MAP:\{\s*(.*)\s*\}$")


def _split_top_level(s: str, sep: str) -> list[str]:
    """Split at sep ignoring separators inside (), [], {} and quotes."""
    out, buf = [], []
    depth_par = depth_brk = depth_brc = 0
    in_sq = in_dq = False
    esc = False
    for ch in s:
        if esc:
            buf.append(ch)
            esc = False
            continue
        if ch == "\\":
            buf.append(ch)
            esc = True
            continue
        if ch == "'" and not in_dq and depth_par == depth_brk == depth_brc == 0:
            in_sq = not in_sq
            buf.append(ch)
            continue
        if ch == '"' and not in_sq and depth_par == depth_brk == depth_brc == 0:
            in_dq = not in_dq
            buf.append(ch)
            continue
        if not (in_sq or in_dq):
            if ch == "(":
                depth_par += 1
            elif ch == ")":
                depth_par -= 1
            elif ch == "[":
                depth_brk += 1
            elif ch == "]":
                depth_brk -= 1
            elif ch == "{":
                depth_brc += 1
            elif ch == "}":
                depth_brc -= 1
            elif ch == sep and depth_par == depth_brk == depth_brc == 0:
                out.append("".join(buf).strip())
                buf = []
                continue
        buf.append(ch)
    tail = "".join(buf).strip()
    if tail:
        out.append(tail)
    return out


def _parse_map_site(part: str) -> MapSite:
    # part examples: "1:1" or "1:[1,3]"  (whitespace allowed)
    part = part.strip()
    if not part:
        raise ValueError("empty MAP site")
    if ":" not in part:
        # allow singles like "3" → treat as lig=3, atoms=[]
        lig = int(part)
        return MapSite(lig=lig, atoms=[])
    lig_str, idx_str = (x.strip() for x in part.split(":", 1))
    lig = int(lig_str)
    if idx_str.startswith("["):
        # remove surrounding brackets and split
        if not idx_str.endswith("]"):
            raise ValueError(f"bad site atoms list: {idx_str}")
        inner = idx_str[1:-1].strip()
        atoms = [int(x.strip()) for x in _split_top_level(inner, ",")] if inner else []
    else:
        atoms = [int(idx_str)]
    return MapSite(lig=lig, atoms=atoms)


def _parse_map_block(body: str):
    pairs = []
    singles = []

    def _split_top_level(s: str, sep: str):
        out, buf, depth, quote, esc = [], [], 0, None, False
        opener, closer = "([{", ")]}"
        for ch in s:
            if esc:
                buf.append(ch)
                esc = False
                continue
            if ch == "\\":
                esc = True
                buf.append(ch)
                continue
            if quote:
                buf.append(ch)
                if ch == quote:
                    quote = None
                continue
            if ch in "'\"":
                quote = ch
                buf.append(ch)
                continue
            if ch in opener:
                depth += 1
                buf.append(ch)
                continue
            if ch in closer:
                depth -= 1
                buf.append(ch)
                continue
            if ch == sep and depth == 0:
                out.append("".join(buf).strip())
                buf = []
                continue
            buf.append(ch)
        out.append("".join(buf).strip())
        return [x for x in out if x]

    # Collect pair groups
    groups = []
    depth = 0
    start = None
    quote = None
    esc = False
    for i, ch in enumerate(body):
        if esc:
            esc = False
            continue
        if ch == "\\":
            esc = True
            continue
        if quote:
            if ch == quote:
                quote = None
            continue
        if ch in "'\"":
            quote = ch
            continue
        if ch == "(" and depth == 0:
            start = i
            depth = 1
            continue
        if ch == "(":
            depth += 1
            continue
        if ch == ")" and depth > 0:
            depth -= 1
            if depth == 0 and start is not None:
                groups.append(body[start : i + 1])
                start = None
            continue

    for g in groups:
        inner = g.strip()[1:-1].strip()
        toks = _split_top_level(inner, ",")
        if len(toks) != 2:
            raise ValueError(f"bad pair group: {g}")
        a = _parse_map_site(toks[0].strip())
        b = _parse_map_site(toks[1].strip())
        key_a = (a.lig, tuple(sorted(a.atoms)))
        key_b = (b.lig, tuple(sorted(b.atoms)))
        if key_b < key_a:
            a, b = b, a
        if (a, b) not in pairs:
            pairs.append((a, b))

    # Remove pairs, parse remainder as singles (including after ';')
    remainder = body
    for g in groups:
        remainder = remainder.replace(g, " ")
    if ";" in remainder:
        remainder = remainder.split(";", 1)[1]

    for tok in _split_top_level(remainder, ","):
        tok = tok.strip()
        if not tok:
            continue
        singles.append(_parse_map_site(tok))

    # dedupe singles
    seen = set()
    uniq = []
    for s in singles:
        key = (s.lig, tuple(sorted(s.atoms)))
        if key not in seen:
            seen.add(key)
            uniq.append(s)
    singles = uniq
    return pairs, singles


def parse_trex_full(s: str) -> TrexFull:
    """Parse a T-REX-Full string. Keeps SMILES payloads verbatim."""
    parts = _split_top_level(s.strip(), "|")
    hdr = parts[0].strip()
    m = _HEAD.match(hdr)
    if not m:
        raise ValueError(f"bad header: {hdr}")
    metal, ox_str, spin_str = m.group(1), m.group(2), m.group(3)
    ox = int(ox_str)
    spin = int(spin_str) if spin_str is not None else None

    ligands: list[LigandPayload] = []
    pairs: list[tuple[MapSite, MapSite]] = []
    singles: list[MapSite] = []
    G = None
    X = None

    for p in parts[1:]:
        p = p.strip()
        if p.startswith("L="):
            lm = _LBLK.match(p)
            if not lm:
                raise ValueError(f"bad ligand block: {p}")
            inner = lm.group(1)
            toks = _split_top_level(inner, ",")
            for t in toks:
                t = t.strip()
                if not t:
                    continue
                if t.startswith("SMILES:"):
                    text = t[len("SMILES:") :].strip()
                    ligands.append(LigandPayload(kind="SMILES", text=text))
                elif t.startswith("SELFIES:"):
                    text = t[len("SELFIES:") :].strip()
                    ligands.append(LigandPayload(kind="SELFIES", text=text))
                else:
                    raise ValueError(f"unsupported ligand token: {t}")
        elif p.startswith("MAP:"):
            mm = _MAP.match(p)
            if not mm:
                raise ValueError(f"bad MAP block: {p}")
            pairs, singles = _parse_map_block(mm.group(1))
        elif p.startswith("G:"):
            G = p[2:].strip() or None
        elif p.startswith("X:"):
            X = p[2:].strip() or None
        else:
            raise ValueError(f"unknown section: {p}")

    try:
        return TrexFull(
            metal=metal, ox=ox, spin=spin, ligands=ligands, pairs=pairs, singles=singles, G=G, X=X
        )
    except ValidationError as e:
        raise ValueError(f"invalid TrexFull fields: {e}") from e


def canonicalize_trex_full_string(s: str) -> str:
    """Parse → canonicalize → pretty, using canon_full.canonicalize_full."""
    t = parse_trex_full(s)
    tc = canonicalize_full(t)
    return _pretty_full(tc)


def _to_string(self) -> str:
    return pretty_trex_full(self)


TrexFull.to_string = _to_string

# re-export for callers
pretty_trex_full = _pretty_full


def parse_trex_full_string(s: str) -> TrexFull:
    """Backward-compatible alias for parse_trex_full(s)."""
    return parse_trex_full(s)
