# trex/parse_min.py
import re

from .model import TrexMin

# ---- regexes ----
_HEAD = re.compile(r"^([A-Z][a-z]?)\{([+-]?\d+)(?:,S=(\d+))?\}$")  # obtain the metal block
_LBLK = re.compile(r"^L=\[\s*(.*?)\s*\]$")  # obtain the ligand block
_MAP = re.compile(r"^MAP:\{\s*(.*?)\s*\}$")  # obtain the pair block


def parse_trex_min(s: str) -> TrexMin:
    parts = [p.strip() for p in s.strip().split("|")]
    assert len(parts) >= 3, "expected HEAD | L=[…] | MAP:{…}"
    head, ligpart, mappart, *rest = parts

    # HEAD
    m = _HEAD.match(head)
    assert m, "bad head"
    metal = m.group(1)
    ox = int(m.group(2))
    spin = int(m.group(3)) if m.group(3) else None

    # LIGANDS
    lm = _LBLK.match(ligpart)
    assert lm, "bad ligand block"
    ligands = [tok.strip().lower() for tok in lm.group(1).split(",") if tok.strip()]

    # MAP block
    mm = _MAP.match(mappart)
    assert mm, "bad MAP block"
    inner = mm.group(1)
    # pull each (...) group as a unit
    entries = re.findall(r"\([^()]*\)", inner)
    pairs, singles = [], []
    for e in entries:
        nums = [int(v) for v in re.findall(r"\d+", e)]
        if len(nums) == 2:
            i, j = sorted(nums)
            pairs.append((i, j))
        elif len(nums) == 1:
            singles.append(nums[0])
        else:
            raise AssertionError(f"bad MAP entry: {e}")

    # optional disambiguation
    G = X = None
    for seg in rest:
        if seg.startswith("G:"):
            G = seg[2:].strip()
        elif seg.startswith("X:"):
            X = seg[2:].strip()

    return TrexMin(
        metal=metal,
        ox=ox,
        spin=spin,
        ligands=ligands,
        pairs=sorted(set(pairs)),
        singles=sorted(set(singles)),
        G=G,
        X=X,
    )


def pretty_trex_min(t: TrexMin) -> str:
    lig = ", ".join(t.ligands)
    pairs = ", ".join(f"({i},{j})" for (i, j) in sorted(t.pairs))
    singles = ", ".join(f"({i})" for i in sorted(t.singles))
    entries = ", ".join(x for x in [pairs, singles] if x)
    tail = []
    if t.G:
        tail.append(f"G:{t.G}")
    if t.X:
        tail.append(f"X:{t.X}")
    ox = f"+{t.ox}" if t.ox > 0 else str(t.ox)
    head = f"{t.metal}{{{ox}{'' if t.spin is None else f',S={t.spin}'}}}"
    return f"{head}|L=[ {lig} ]|MAP:{{ {entries} }}{('|' + '|'.join(tail)) if tail else ''}"
