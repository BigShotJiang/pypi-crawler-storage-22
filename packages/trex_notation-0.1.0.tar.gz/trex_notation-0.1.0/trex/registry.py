import os
from pathlib import Path

from pydantic import BaseModel
from ruamel.yaml import YAML

try:
    from importlib.resources import files as pkg_files  # py>=3.9
except Exception:
    pkg_files = None


class Ligand(BaseModel):
    token: str
    smiles: str | None = None
    charge: int
    mw_monoiso: float | None = None
    inchi_key: str | None = None
    aliases: list[str] = []


class Registry(BaseModel):
    ligands: dict[str, Ligand]

    @classmethod
    def load(cls, path: str | Path) -> "Registry":
        data = YAML(typ="safe").load(Path(path).read_text())
        ligs = {}
        for tok, rec in data["ligands"].items():
            rec["token"] = tok.lower()
            ligs[rec["token"]] = Ligand(**rec)
        return cls(ligands=ligs)

    def get(self, token: str) -> Ligand:
        return self.ligands[token.lower()]

    @staticmethod
    def _ascend_for_examples_root(start: Path) -> Path | None:
        """
        Walk upward from `start` to find a directory that contains examples/registry.yml
        (preferred) or examples/registry.yaml. Returns that examples dir or None.
        """
        for parent in [start, *start.parents]:
            ex = parent / "examples"
            if (ex / "registry.yml").exists():
                return ex
            if (ex / "registry.yaml").exists():
                return ex
        return None

    @staticmethod
    def _candidate_paths() -> list[Path]:
        candidates: list[Path] = []

        # 1) Environment variable highest priority
        env = os.getenv("TREX_REGISTRY")
        if env:
            candidates.append(Path(env))

        # 2) Repo examples/ directory (prefer .yml)
        module_path = Path(__file__).resolve()
        examples_dir = Registry._ascend_for_examples_root(module_path.parent)
        if examples_dir:
            candidates.append(examples_dir / "registry.yml")
            candidates.append(examples_dir / "registry.yaml")

        # 3) Packaged fallback (optional): trex/registry.(yml|yaml) shipped in wheel
        if pkg_files is not None:
            try:
                pkg = pkg_files("trex")
                yml = Path(str(pkg.joinpath("registry.yml")))
                yaml = Path(str(pkg.joinpath("registry.yaml")))
                if yml.exists():
                    candidates.append(yml)
                if yaml.exists():
                    candidates.append(yaml)
            except Exception:
                pass

        # Deduplicate while preserving order
        seen = set()
        uniq: list[Path] = []
        for p in candidates:
            sp = str(p)
            if sp not in seen:
                seen.add(sp)
                uniq.append(p)
        return uniq

    @classmethod
    def resolve(cls, path: str | Path | None) -> "Registry":
        if path is not None:
            p = Path(path)
            if not p.exists():
                raise ValueError(f"Registry file not found: {p}")
            return cls.load(p)

        tried = []
        for candidate in cls._candidate_paths():
            tried.append(str(candidate))
            if candidate.exists():
                return cls.load(candidate)

        tried_str = "\n  - ".join(tried) if tried else "  (no candidates generated)"
        raise ValueError(
            "Could not locate a ligand registry. Tried:\n"
            f"{tried_str}\n"
            "Set TREX_REGISTRY or pass --registry PATH."
        )
