# trex/smiles_map_utils.py
from __future__ import annotations

import re
from collections.abc import Iterable
from typing import Literal

from rdkit import Chem

# ---------------- internals ----------------


def _heavy_index_maps(mol: Chem.Mol) -> tuple[list[int], list[int]]:
    """Return (all_to_heavy 1-based; 0 for H), (heavy_to_all 0-based)."""
    all_to_heavy: list[int] = [0] * mol.GetNumAtoms()
    heavy_to_all: list[int] = []
    k = 0
    for a in mol.GetAtoms():
        if a.GetAtomicNum() == 1:
            continue
        k += 1
        all_to_heavy[a.GetIdx()] = k
        heavy_to_all.append(a.GetIdx())
    return all_to_heavy, heavy_to_all


# helper: recover the order RDKit WRITES atoms (by parsing :map tags)
def _written_order_noH(
    noH: Chem.Mol, *, canonical: bool, isomericSmiles: bool, kekuleSmiles: bool
) -> list[int]:
    """
    Return the order (0-based atom indices in `noH`) that RDKit WRITES.
    - For canonical order: we set ignoreAtomMapNumbers=True (so tags don't affect canon),
      and if tags aren't printed we fall back to CanonicalRankAtoms().
    - For non-canonical order (input SMILES mode): ignoreAtomMapNumbers=False so the tags
      are printed and we can parse them.
    """
    m = Chem.Mol(noH)
    for a in m.GetAtoms():
        a.SetAtomMapNum(a.GetIdx() + 1)  # 1-based temporary tag

    s = Chem.MolToSmiles(
        m,
        canonical=canonical,
        isomericSmiles=isomericSmiles,
        kekuleSmiles=kekuleSmiles,
        allHsExplicit=False,
        ignoreAtomMapNumbers=True if canonical else False,  # <-- key change
    )

    ids_1b = [int(x) for x in re.findall(r":(\d+)\]", s)]

    # If asked for canonical and the build suppressed printing tags,
    # just compute canonical order directly from ranks:
    if canonical and len(ids_1b) == 0:
        ranks = Chem.CanonicalRankAtoms(noH, includeChirality=isomericSmiles)
        order = sorted(range(noH.GetNumAtoms()), key=lambda i: (ranks[i], i))
        return order

    if len(ids_1b) != m.GetNumAtoms():
        raise RuntimeError(
            f"Parsed {len(ids_1b)} atoms from mapped SMILES but molecule has {m.GetNumAtoms()}. "
            f"SMILES: {s}"
        )

    # Convert parsed 1-based ids back to 0-based indices in `noH`
    return [i - 1 for i in ids_1b]


# ---------------- public API ----------------


def canonical_smiles_heavy_mapping_from_smiles(
    smiles: str,
    *,
    isomericSmiles: bool = True,
    kekuleSmiles: bool = False,
) -> tuple[str, list[int], list[int], list[int], list[int]]:
    """
    Heavy-atom-only canonicalization + mapping.

    Returns:
      can_smi        : PLAIN canonical SMILES (no maps, no explicit H)
      heavy_can2orig : for the i-th heavy token in can_smi,
      the original heavy index (0-based in input)
      heavy_orig2can : inverse: original heavy index -> position in can_smi (0-based)
      all_to_heavy   : per-atom original -> heavy ordinal (1-based; 0 for H)
      heavy_to_all   : heavy ordinal (1..Nheavy) -> original atom idx (0-based)
    """
    m = Chem.MolFromSmiles(smiles)
    if m is None:
        raise ValueError(f"Bad SMILES: {smiles}")

    all_to_heavy, heavy_to_all = _heavy_index_maps(m)
    noH = Chem.RemoveHs(Chem.Mol(m), sanitize=False)

    # Canonical written order (as noH indices)
    can_noH_order = _written_order_noH(
        noH, canonical=True, isomericSmiles=isomericSmiles, kekuleSmiles=kekuleSmiles
    )

    # Plain canonical heavy SMILES
    plain_can = Chem.MolToSmiles(
        noH,
        canonical=True,
        isomericSmiles=isomericSmiles,
        kekuleSmiles=kekuleSmiles,
        allHsExplicit=False,
    )

    # can -> original heavy index (both 0-based)
    heavy_can2orig = can_noH_order[:]  # in noH, atom indices are heavy indices (0..Nheavy-1)

    # original heavy -> position in canonical SMILES (0-based)
    nH = noH.GetNumAtoms()
    heavy_orig2can = [-1] * nH
    for pos, hidx in enumerate(heavy_can2orig):
        heavy_orig2can[hidx] = pos

    return plain_can, heavy_can2orig, heavy_orig2can, all_to_heavy, heavy_to_all


def remap_indices_from_smiles(
    smiles: str,
    orig_indices: Iterable[int],
    *,
    mode: Literal["heavy", "smiles"] = "heavy",
    isomericSmiles: bool = True,
    kekuleSmiles: bool = False,
) -> tuple[str, list[int]]:
    """
    Remap a list of indices from the *input* SMILES to
      positions in the PLAIN canonical heavy SMILES.

    Args:
      orig_indices : indices from the input
      mode         :
         - "heavy"  : indices are RDKit heavy atom indices (0-based)
         - "smiles" : indices are positions in the
         **printed non-canonical** SMILES writing order (0-based)

    Returns:
      can_smi, new_positions (0-based positions in canonical heavy SMILES)
    """
    m = Chem.MolFromSmiles(smiles)
    if m is None:
        raise ValueError(f"Bad SMILES: {smiles}")
    noH = Chem.RemoveHs(Chem.Mol(m), sanitize=False)

    # Canonical order (target)
    can_noH_order = _written_order_noH(
        noH, canonical=True, isomericSmiles=isomericSmiles, kekuleSmiles=kekuleSmiles
    )
    can_pos_by_noH = {hidx: pos for pos, hidx in enumerate(can_noH_order)}

    if mode == "heavy":
        # Input indices are RDKit heavy indices (== noH indices)
        source_noH_indices = list(orig_indices)
    elif mode == "smiles":
        # Interpret input indices as positions in RDKit's non-canonical printed order
        inp_noH_order = _written_order_noH(
            noH, canonical=False, isomericSmiles=isomericSmiles, kekuleSmiles=kekuleSmiles
        )
        source_noH_indices = []
        for p in orig_indices:
            if p < 0 or p >= len(inp_noH_order):
                raise IndexError(
                    f"Input SMILES position {p} out of range [0..{len(inp_noH_order)-1}]"
                )
            source_noH_indices.append(inp_noH_order[p])
    else:
        raise ValueError("mode must be 'heavy' or 'smiles'")

    # Map to canonical positions
    can_positions: list[int] = []
    for hidx in source_noH_indices:
        pos = can_pos_by_noH.get(hidx, None)
        if pos is None:
            raise RuntimeError("No mapping for a source heavy index; this should not happen.")
        can_positions.append(pos)

    # Plain canonical heavy SMILES
    plain_can = Chem.MolToSmiles(
        noH,
        canonical=True,
        isomericSmiles=isomericSmiles,
        kekuleSmiles=kekuleSmiles,
        allHsExplicit=False,
    )
    return plain_can, can_positions


def remap_groups_from_smiles(
    smiles: str,
    groups: Iterable[Iterable[int]],
    *,
    mode: Literal["heavy", "smiles"] = "heavy",
    isomericSmiles: bool = True,
    kekuleSmiles: bool = False,
) -> tuple[str, list[list[int]]]:
    """
    Remap groups (e.g., haptic donor sets) from input
    SMILES to PLAIN canonical heavy SMILES.

    Returns:
      can_smi, groups_can (each inner list sorted,
      0-based positions in canonical SMILES)
    """
    m = Chem.MolFromSmiles(smiles)
    if m is None:
        raise ValueError(f"Bad SMILES: {smiles}")
    noH = Chem.RemoveHs(Chem.Mol(m), sanitize=False)

    can_noH_order = _written_order_noH(
        noH, canonical=True, isomericSmiles=isomericSmiles, kekuleSmiles=kekuleSmiles
    )
    can_pos_by_noH = {hidx: pos for pos, hidx in enumerate(can_noH_order)}

    if mode == "heavy":
        # groups already refer to heavy indices (== noH indices)
        src_groups = [[int(x) for x in g] for g in groups]
    elif mode == "smiles":
        inp_noH_order = _written_order_noH(
            noH, canonical=False, isomericSmiles=isomericSmiles, kekuleSmiles=kekuleSmiles
        )
        src_groups = []
        for g in groups:
            tmp = []
            for p in g:
                if p < 0 or p >= len(inp_noH_order):
                    raise IndexError(
                        f"Input SMILES position {p} out of range [0..{len(inp_noH_order)-1}]"
                    )
                tmp.append(inp_noH_order[p])
            src_groups.append(tmp)
    else:
        raise ValueError("mode must be 'heavy' or 'smiles'")

    out_groups: list[list[int]] = []
    for g in src_groups:
        out_groups.append(sorted({can_pos_by_noH[h] for h in g}))
    plain_can = Chem.MolToSmiles(
        noH,
        canonical=True,
        isomericSmiles=isomericSmiles,
        kekuleSmiles=kekuleSmiles,
        allHsExplicit=False,
    )
    return plain_can, out_groups


# --------------- CLI for debugging ---------------
if __name__ == "__main__":
    import argparse

    p = argparse.ArgumentParser(
        description="SMILES canonicalization + heavy index remap (PLAIN output)"
    )
    p.add_argument("smiles", help="input SMILES")
    p.add_argument("--indices", nargs="*", type=int, default=[], help="0-based indices to remap")
    p.add_argument(
        "--group", action="append", default=[], help="comma-separated group like '1,2,5'"
    )
    p.add_argument(
        "--mode",
        choices=["heavy", "smiles"],
        default="heavy",
        help="interpret indices/groups as heavy atom indices or as "
        "positions in printed non-canonical SMILES",
    )
    args = p.parse_args()

    if args.group:
        groups = []
        for g in args.group:
            if g.strip():
                groups.append([int(x) for x in g.split(",") if x.strip()])
        can, grp = remap_groups_from_smiles(args.smiles, groups, mode=args.mode)
        print("can_smiles:", can)
        print("groups_can:", grp)
    else:
        can, idx = remap_indices_from_smiles(args.smiles, args.indices, mode=args.mode)
        print("can_smiles:", can)
        print("indices_can:", idx)
