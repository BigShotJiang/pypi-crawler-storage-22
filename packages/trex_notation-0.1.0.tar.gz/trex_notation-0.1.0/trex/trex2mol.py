# trex2mol.py
from __future__ import annotations

from dataclasses import dataclass

from rdkit import Chem
from rdkit.Chem import AllChem

# --- Types from T-REX model ---
TrexFull = None
LigandPayload = None
MapSite = None


@dataclass(frozen=True)
class SiteKey:
    lig: int
    atoms: tuple[int, ...]  # 1-based local positions in ligand payload (SMILES writing order)


@dataclass
class Trex2MolResult:
    mol: Chem.Mol
    metal_idx: int
    ligand_base_offsets: list[int]  # per-ligand base atom index offset in the combined mol
    ligand_pos1b_to_global: list[
        list[int]
    ]  # [lig_i][pos1b-1] -> global atom idx (or -1 if out of range)
    site_to_atoms_global: dict[SiteKey, list[int]]  # site -> global atom indices
    dative_bond_ids: list[int]
    trans_bond_ids: list[int]
    site_ghost_atom: dict[SiteKey, int]  # ghost atom index (if created for haptic sites)


# ----------------------- helpers -----------------------


def _written_order_to_rdidx(smi: str) -> list[int]:
    """
    Map SMILES *writing positions* (0-based) to RDKit atom indices for `smi`.
    Strategy mirrors canonicalizer helper: write atom map numbers equal to RD indices,
    then re-canonicalize and read back the order of [:map] tags.

    Returns a list pos -> rd_idx.
    """
    m = Chem.MolFromSmiles(smi)
    if m is None:
        return []
    m2 = Chem.Mol(m)
    for a in m2.GetAtoms():
        a.SetAtomMapNum(a.GetIdx() + 1)
    can = Chem.MolToSmiles(m2, canonical=True, isomericSmiles=True)
    import re

    ids = [int(x) - 1 for x in re.findall(r":(\d+)\]", can)]
    if not ids and m2.GetNumAtoms() == 1:
        return [0]
    if len(ids) != m2.GetNumAtoms():
        # Fallback to canonical ranks when tags are missing/misaligned
        ranks = Chem.CanonicalRankAtoms(m)
        order = sorted(range(m.GetNumAtoms()), key=lambda i: (ranks[i], i))
        return order
    return ids


def _copy_mol_into(dst: Chem.RWMol, src: Chem.Mol) -> tuple[int, dict[int, int]]:
    """
    Copy `src` into editable `dst`, returning (base_offset, local->global index map).
    """
    base = dst.GetNumAtoms()
    amap: dict[int, int] = {}

    # atoms
    for a in src.GetAtoms():
        na = Chem.Atom(a.GetAtomicNum())
        na.SetFormalCharge(a.GetFormalCharge())
        na.SetIsAromatic(a.GetIsAromatic())
        na.SetChiralTag(a.GetChiralTag())
        na.SetNoImplicit(True)
        gidx = dst.AddAtom(na)
        amap[a.GetIdx()] = gidx

    # bonds
    for b in src.GetBonds():
        i = amap[b.GetBeginAtomIdx()]
        j = amap[b.GetEndAtomIdx()]
        dst.AddBond(i, j, b.GetBondType())

    return base, amap


def _ensure_module_refs():
    """Late-import T-REX types and parser to avoid import-time side effects."""
    global TrexFull, LigandPayload, MapSite
    if TrexFull is not None:
        return
    from trex.model import LigandPayload as _LP
    from trex.model import MapSite as _MS
    from trex.model import TrexFull as _TF

    TrexFull, LigandPayload, MapSite = _TF, _LP, _MS


# ----------------------- main API -----------------------


def trex_to_mol(
    trex: str | TrexFull,
    *,
    add_haptic_centroids: bool = True,
    set_metal_formal_charge_from_ox: bool = True,
    annotate_props: bool = True,
    sanitize: bool = True,
) -> Trex2MolResult:
    """
    Build an RDKit Mol from a T-REX-Full string or object.

    Bonds added:
      • Metal–site: DATIVE (one per coordinating atom; ηn sites add n dative bonds)
      • trans-pairs: ZERO-ORDER virtual bond between site representatives
            - monodentate site → its single atom
            - haptic site      → a per-site ghost '*' atom (if add_haptic_centroids=True),
                                  otherwise the first coordinating atom

    Returns Trex2MolResult with rich mappings for downstream ML/graph work.
    """
    _ensure_module_refs()

    # Parse
    if isinstance(trex, str):
        from trex.parse_full import parse_trex_full as _parse

        t: TrexFull = _parse(trex)
        trex_str = trex
    else:
        t = trex
        trex_str = None

    # Prepare editable container
    rw = Chem.RWMol()
    site_to_atoms_global: dict[SiteKey, list[int]] = {}
    site_ghost_atom: dict[SiteKey, int] = {}
    dative_bond_ids: list[int] = []
    trans_bond_ids: list[int] = []
    ligand_base_offsets: list[int] = []
    ligand_pos1b_to_global: list[list[int]] = []

    # 1) Metal atom
    pt = Chem.GetPeriodicTable()
    try:
        z = pt.GetAtomicNumber(t.metal)
    except Exception as e:  # pragma: no cover
        raise ValueError(f"Unknown metal symbol in T-REX: {t.metal}") from e

    metal = Chem.Atom(z)
    if set_metal_formal_charge_from_ox:
        # Store ox as formal charge
        metal.SetFormalCharge(int(t.ox))
    metal.SetNoImplicit(True)
    metal_idx = rw.AddAtom(metal)

    if annotate_props:
        rw.SetProp("TREX_Metal", t.metal)
        rw.SetIntProp("TREX_OxidationState", int(t.ox))
        if t.spin is not None:
            rw.SetIntProp("TREX_Spin", int(t.spin))
        if trex_str:
            rw.SetProp("TREX_String", trex_str)

    # 2) Ligands → add molecules, record writing-order → rdidx → global mapping
    for lig_i, payload in enumerate(t.ligands, start=1):
        if payload.kind != "SMILES":
            raise NotImplementedError(
                f"Ligand {lig_i}: unsupported payload kind '{payload.kind}'. "
                f"(Only SMILES supported here; SELFIES/INCHI can be added with a converter.)"
            )
        smi = payload.text
        lig_m = Chem.MolFromSmiles(smi)
        if lig_m is None:
            raise ValueError(f"Ligand {lig_i}: could not parse SMILES '{smi}'")

        base, amap = _copy_mol_into(rw, lig_m)
        ligand_base_offsets.append(base)

        # pos (0b) -> local RD idx
        pos_to_rd = _written_order_to_rdidx(smi)
        # local RD idx -> global idx
        local_to_global = {loc: glob for loc, glob in amap.items()}
        # build pos1b -> global idx (length = num atoms)
        pos1b_to_global = [-1] * lig_m.GetNumAtoms()
        for pos0, rd_local in enumerate(pos_to_rd):
            g = local_to_global.get(rd_local, -1)
            pos1b_to_global[pos0] = g
        ligand_pos1b_to_global.append(pos1b_to_global)

    # helper to resolve a MapSite → list of global atom indices
    def _site_atoms_global(site: MapSite) -> list[int]:
        pos_map = ligand_pos1b_to_global[site.lig - 1]
        if not site.atoms:
            # Empty site (shouldn't occur); fall back to first atom
            return [a for a in pos_map if a >= 0][:1] or []
        out: list[int] = []
        for a1b in site.atoms:
            pos0 = a1b - 1
            if 0 <= pos0 < len(pos_map) and pos_map[pos0] >= 0:
                out.append(pos_map[pos0])
        # dedupe/sort for determinism
        return sorted(set(out))

    # 3) Metal–site dative bonds
    seen_sites: set[SiteKey] = set()

    def _remember_and_dative(site: MapSite):
        key = SiteKey(lig=site.lig, atoms=tuple(sorted(site.atoms)))
        if key in seen_sites:
            return
        seen_sites.add(key)
        gst = _site_atoms_global(site)
        site_to_atoms_global[key] = gst
        if len(gst) > 1 and add_haptic_centroids:
            # create/reuse ghost
            if key in site_ghost_atom:
                rep = site_ghost_atom[key]
            else:
                ghost = Chem.Atom(0)  # dummy '*'
                ghost.SetNoImplicit(True)
                rep = rw.AddAtom(ghost)
                site_ghost_atom[key] = rep
                if annotate_props:
                    rw.GetAtomWithIdx(rep).SetProp("TREX_role", "site_centroid")
                    rw.GetAtomWithIdx(rep).SetProp(
                        "TREX_site", f"{site.lig}:[{','.join(map(str,sorted(site.atoms)))}]"
                    )
                # tether ghost to all haptic atoms so subgraph stays connected
                for aidx in gst:
                    rw.AddBond(rep, aidx, Chem.BondType.ZERO)
                    b = rw.GetBondBetweenAtoms(rep, aidx)
                    if annotate_props and b is not None:
                        b.SetProp("TREX_tag", "haptic_centroid_link")

            # dative bond goes from ghost to metal
            rw.AddBond(rep, metal_idx, Chem.BondType.DATIVE)
            b = rw.GetBondBetweenAtoms(rep, metal_idx)
            if annotate_props and b is not None:
                b.SetBoolProp("TREX_is_coord", True)
                b.SetProp("TREX_site", f"{site.lig}:[{','.join(map(str,sorted(site.atoms)))}]")
            if b is not None:
                dative_bond_ids.append(b.GetIdx())

        else:
            # monodentate: bond each site atom to metal
            for g in gst:
                rw.AddBond(g, metal_idx, Chem.BondType.DATIVE)
                b = rw.GetBondBetweenAtoms(g, metal_idx)
                if annotate_props and b is not None:
                    b.SetBoolProp("TREX_is_coord", True)
                    if len(site.atoms) > 1:
                        site_str = f"{site.lig}:[{','.join(map(str,sorted(site.atoms)))}]"
                    elif site.atoms:
                        site_str = f"{site.lig}:{site.atoms[0]}"
                    else:
                        site_str = f"{site.lig}:"
                    b.SetProp("TREX_site", site_str)
                if b is not None:
                    dative_bond_ids.append(b.GetIdx())

    for a, b in t.pairs:
        _remember_and_dative(a)
        _remember_and_dative(b)
    for s in t.singles:
        _remember_and_dative(s)

    # 4) Virtual trans bonds
    def _rep_for_site(site: MapSite) -> int | None:
        key = SiteKey(lig=site.lig, atoms=tuple(sorted(site.atoms)))
        atoms = site_to_atoms_global.get(key, [])
        if len(atoms) == 0:
            return None
        if len(atoms) == 1 or not add_haptic_centroids:
            return atoms[0]
        # haptic & centroid requested → add a ghost '*' atom for this site
        if key in site_ghost_atom:
            return site_ghost_atom[key]
        ghost = Chem.Atom(0)  # dummy
        ghost.SetNoImplicit(True)
        gidx = rw.AddAtom(ghost)
        site_ghost_atom[key] = gidx
        if annotate_props:
            rw.GetAtomWithIdx(gidx).SetProp("TREX_role", "site_centroid")
            rw.GetAtomWithIdx(gidx).SetProp(
                "TREX_site", f"{site.lig}:[{','.join(map(str,sorted(site.atoms)))}]"
            )
        # tether ghost to all haptic atoms with ZERO bonds so subgraphs are connected
        for aidx in atoms:
            rw.AddBond(gidx, aidx, Chem.BondType.ZERO)
            b = rw.GetBondBetweenAtoms(gidx, aidx)
            if annotate_props and b is not None:
                b.SetProp("TREX_tag", "haptic_centroid_link")
        return gidx

    for a, b in t.pairs:
        ia = _rep_for_site(a)
        ib = _rep_for_site(b)
        if ia is None or ib is None:
            continue
        rw.AddBond(ia, ib, Chem.BondType.ZERO)
        vb = rw.GetBondBetweenAtoms(ia, ib)
        if annotate_props and vb is not None:
            vb.SetProp("TREX_tag", "trans")
            vb.SetBoolProp("TREX_is_trans", True)
            vb.SetProp(
                "TREX_trans_sites",
                f"({a.lig}:{a.atoms if a.atoms else []})-({b.lig}:{b.atoms if b.atoms else []})",
            )
        trans_bond_ids.append(vb.GetIdx() if vb is not None else -1)

    # 5) Finalize
    mol = rw.GetMol()
    if sanitize:
        Chem.SanitizeMol(mol, catchErrors=True)
    AllChem.AssignStereochemistry(mol, force=True, cleanIt=True)

    return Trex2MolResult(
        mol=mol,
        metal_idx=metal_idx,
        ligand_base_offsets=ligand_base_offsets,
        ligand_pos1b_to_global=ligand_pos1b_to_global,
        site_to_atoms_global=site_to_atoms_global,
        dative_bond_ids=[i for i in dative_bond_ids if i >= 0],
        trans_bond_ids=[i for i in trans_bond_ids if i >= 0],
        site_ghost_atom=site_ghost_atom,
    )
