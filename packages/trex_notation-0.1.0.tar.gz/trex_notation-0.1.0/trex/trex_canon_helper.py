# trex_canon_helper.py
from trex.xyz_to_trex import xyz_to_trex, xyz_to_trex_canon


def canonize_one(
    xyz_path: str,
    charge: int,
    geometry: str | None = None,
) -> str:
    s_noncanon = xyz_to_trex(xyz_path, int(charge), geometry)
    return xyz_to_trex_canon(s_noncanon)
