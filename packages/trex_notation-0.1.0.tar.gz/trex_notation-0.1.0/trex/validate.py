# trex/validate.py
from __future__ import annotations

from .model import TrexMin

__all__ = ["infer_denticities", "coordination_number", "validate_min"]


def infer_denticities(t: TrexMin) -> dict[int, int]:
    """
    Infer denticity per ligand index (1-based) from the MAP section of T-REX-min.
    Definition (min): count how many coordination sites each ligand occupies,
    i.e., how many times its index appears across pairs and singles.
    """
    n = len(t.ligands)
    D: dict[int, int] = {i: 0 for i in range(1, n + 1)}
    # each appearance in a pair contributes 1 site to each ligand in that pair
    for i, j in getattr(t, "pairs", []):
        if 1 <= i <= n:
            D[i] += 1
        if 1 <= j <= n:
            D[j] += 1
    # each single contributes 1 site to that ligand
    for i in getattr(t, "singles", []):
        if 1 <= i <= n:
            D[i] += 1
    return D


def coordination_number(t: TrexMin) -> int:
    """CN for T-REX-min: 2*len(pairs) + len(singles)."""
    return 2 * len(getattr(t, "pairs", [])) + len(getattr(t, "singles", []))


def validate_min(t: TrexMin) -> list[tuple[str, str]]:
    """
    Basic structural checks for T-REX-min objects.
    Returns a list of (LEVEL, message) where LEVEL is "ERROR" or "WARN".
    """
    issues: list[tuple[str, str]] = []
    n = len(t.ligands)

    # Index and duplication checks
    seen_pairs: set[tuple[int, int]] = set()
    for i, j in getattr(t, "pairs", []):
        if not (1 <= i <= n and 1 <= j <= n):
            issues.append(("ERROR", "pair index out of range"))
            continue
        if i == j:
            issues.append(("ERROR", "pair links ligand to itself"))
        key = (i, j) if i < j else (j, i)
        if key in seen_pairs:
            issues.append(("ERROR", "duplicate pair"))
        else:
            seen_pairs.add(key)

    for i in getattr(t, "singles", []):
        if not (1 <= i <= n):
            issues.append(("ERROR", "single index out of range"))

    # Consistency: sum of denticities equals CN
    D = infer_denticities(t)
    cn = coordination_number(t)
    if sum(D.values()) != cn:
        issues.append(("ERROR", "denticity sum does not equal CN"))

    # Geometry hint for CN=6 when three pairs present but G missing
    if cn == 6 and len(getattr(t, "pairs", [])) == 3 and getattr(t, "G", None) is None:
        issues.append(("WARN", "G missing; defaulting to O (octahedral) by convention"))

    return issues
