# helper functions for xyz to T-REX
from __future__ import annotations

import math
from dataclasses import dataclass

from rdkit import Chem
from rdkit.Chem.MolStandardize import rdMolStandardize as rdMS
from rdkit.Chem.rdchem import Mol

# -------------------- config --------------------

# Greedy "trans" threshold (deg)
ANGLE_TRANS_DEFAULT = 150.0

# Conservative set of "metals" (mostly d-block)
D_BLOCK_METALS = {
    21,
    22,
    23,
    24,
    25,
    26,
    27,
    28,
    29,
    30,
    39,
    40,
    41,
    42,
    43,
    44,
    45,
    46,
    47,
    48,
    57,
    72,
    73,
    74,
    75,
    76,
    77,
    78,
    79,
    80,
}


@dataclass
class NCConvertConfig:
    angle_trans: float = ANGLE_TRANS_DEFAULT
    prefer_obabel: bool = True  # try OBabel MOL2->SDF pre-pass if available
    verbose: bool = True


# -------------------- geometry / vector math --------------------


def geometry_to_n_trans_pairs(geometry: str | None) -> int | None:
    """
    Map human geometry names to the desired number of trans pairs.
    Robust to case, hyphens/underscores, and common aliases.
    """
    if not geometry:
        return None

    # normalize: lowercase, collapse whitespace, unify hyphens/underscores to spaces
    g = " ".join(geometry.strip().lower().replace("-", " ").replace("_", " ").split())

    # canonical alias table
    aliases = {
        # 0 pairs
        "bent": "bent",
        "trigonal planar": "trigonal planar",
        "trpl": "trigonal planar",
        "tp": "trigonal planar",
        "tetrahedral": "tetrahedral",
        "thd": "tetrahedral",
        # 1 pair
        "linear": "linear",
        "lin": "linear",
        "seesaw": "seesaw",
        "see saw": "seesaw",
        "t shape": "t shape",  # accept 't shape' after lowercasing
        "t shaped": "t shape",
        "t shaped planar": "t shape",
        "trigonal bipyramidal": "trigonal bipyramidal",
        "trigonal bi pyramidal": "trigonal bipyramidal",
        "tbp": "trigonal bipyramidal",
        "pentagonal bipyramidal": "pentagonal bipyramidal",
        "penta gonal bipyramidal": "pentagonal bipyramidal",
        # 2 pairs
        "square planar": "square planar",
        "sqpl": "square planar",
        "square pyramidal": "square pyramidal",
        "sqpy": "square pyramidal",
        # 3 pairs
        "octahedral": "octahedral",
        "oct": "octahedral",
        "trigonal prismatic": "trigonal prismatic",
        "tr pr": "trigonal prismatic",
        "trpr": "trigonal prismatic",
        "tpra": "trigonal prismatic",
    }

    g = aliases.get(g, g)  # resolve alias if possible

    zero = {"bent", "trigonal planar", "tetrahedral"}
    one = {"linear", "seesaw", "t shape", "trigonal bipyramidal", "pentagonal bipyramidal"}
    two = {"square planar", "square pyramidal"}
    three = {"octahedral", "trigonal prismatic"}

    if g in zero:
        return 0
    if g in one:
        return 1
    if g in two:
        return 2
    if g in three:
        return 3
    return None


def _site_vectors_from_centroids(
    mol: Mol, m_idx: int, sites_old: list[list[int]]
) -> list[tuple[float, float, float]]:
    conf = mol.GetConformer()
    pM = conf.GetAtomPosition(m_idx)
    out = []
    for atoms in sites_old:
        cx = cy = cz = 0.0
        for a in atoms:
            p = conf.GetAtomPosition(a)
            cx += p.x
            cy += p.y
            cz += p.z
        n = max(1, len(atoms))
        cx /= n
        cy /= n
        cz /= n
        out.append((cx - pM.x, cy - pM.y, cz - pM.z))
    return out


def _pick_trans_pairs_greedy_by_centroid(
    mol: Mol, m_idx: int, sites_old: list[list[int]], angle_trans: float
) -> tuple[list[tuple[int, int]], list[int]]:
    vecs = _site_vectors_from_centroids(mol, m_idx, sites_old)
    cand: list[tuple[int, int, float]] = []
    for i in range(len(vecs)):
        for j in range(i + 1, len(vecs)):
            ang = _angle_between_vectors(vecs[i], vecs[j])
            if ang >= angle_trans:
                cand.append((i, j, ang))
    cand.sort(key=lambda t: t[2], reverse=True)
    used = set()
    pairs: list[tuple[int, int]] = []
    for i, j, _ in cand:
        if i in used or j in used:
            continue
        pairs.append((i, j))
        used.add(i)
        used.add(j)
    singles = [k for k in range(len(vecs)) if k not in used]
    return pairs, singles


def _angle_between_vectors(u, v) -> float:
    du = math.sqrt(u[0] * u[0] + u[1] * u[1] + u[2] * u[2])
    dv = math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
    if du == 0 or dv == 0:
        return 0.0
    cosang = (u[0] * v[0] + u[1] * v[1] + u[2] * v[2]) / (du * dv)
    cosang = max(-1.0, min(1.0, float(cosang)))
    return math.degrees(math.acos(cosang))


def _pick_top_k_trans_pairs_by_centroid(
    mol, m_idx: int, sites_old: list[list[int]], k: int
) -> tuple[list[tuple[int, int]], list[int]]:
    """
    Pick the top-k non-overlapping site pairs with the largest inter-site angles
    (via centroid vectors). No angle thresholding is applied. If k == 0, return
    no pairs and all sites as singles. If fewer than k disjoint pairs exist,
    return as many as possible.
    """
    if k <= 0:
        return [], list(range(len(sites_old)))

    vecs = _site_vectors_from_centroids(mol, m_idx, sites_old)
    candidates: list[tuple[int, int, float]] = []
    for i in range(len(vecs)):
        for j in range(i + 1, len(vecs)):
            ang = _angle_between_vectors(vecs[i], vecs[j])
            candidates.append((i, j, ang))

    # Sort by descending angle (most trans first)
    candidates.sort(key=lambda t: t[2], reverse=True)

    used: set[int] = set()
    pairs: list[tuple[int, int]] = []
    for i, j, _ang in candidates:
        if i in used or j in used:
            continue
        pairs.append((i, j))
        used.add(i)
        used.add(j)
        if len(pairs) >= k:
            break

    singles = [s for s in range(len(vecs)) if s not in used]
    return pairs, singles


# -------------------- fragmentation --------------------


def _remove_atom_and_get_fragmaps(mol: Mol, remove_idx: int):
    """Remove atom and return (mol_noM, old2new, atom_to_frag, frags_as_mols)."""
    old2new: dict[int, int | None] = {}
    for aidx in range(mol.GetNumAtoms()):
        if aidx == remove_idx:
            old2new[aidx] = None
        elif aidx < remove_idx:
            old2new[aidx] = aidx
        else:
            old2new[aidx] = aidx - 1

    em = Chem.EditableMol(Chem.Mol(mol))
    em.RemoveAtom(remove_idx)
    mol2 = em.GetMol()
    Chem.SanitizeMol(mol2)

    frag_atom_tuples = Chem.GetMolFrags(mol2, asMols=False, sanitizeFrags=False)
    atom_to_frag = [-1] * mol2.GetNumAtoms()
    for fid, atoms in enumerate(frag_atom_tuples):
        for a in atoms:
            atom_to_frag[a] = fid

    frags_as_mols = list(Chem.GetMolFrags(mol2, asMols=True, sanitizeFrags=True))
    return mol2, old2new, atom_to_frag, frags_as_mols


# -------------------- donor grouping (hapticity) --------------------


def _connected_components_on_atoms(mol: Mol, atoms_old: list[int]) -> list[list[int]]:
    """Split a subset of original indices into connectivity components using `mol` bonds."""
    aset = set(atoms_old)
    adj: dict[int, list[int]] = {i: [] for i in atoms_old}
    for i in atoms_old:
        ai = mol.GetAtomWithIdx(i)
        for nb in ai.GetNeighbors():
            j = nb.GetIdx()
            if j in aset:
                adj[i].append(j)
    comps: list[list[int]] = []
    seen = set()
    for i in atoms_old:
        if i in seen:
            continue
        stack = [i]
        seen.add(i)
        comp = []
        while stack:
            u = stack.pop()
            comp.append(u)
            for w in adj[u]:
                if w not in seen:
                    seen.add(w)
                    stack.append(w)
        comps.append(sorted(comp))
    return comps


# -------------------- minimal topology fixes --------------------

HALO_Z = {9, 17, 35, 53}


def _formal_charge(m: Mol) -> int:
    return sum(a.GetFormalCharge() for a in m.GetAtoms())


def _fix_fragment_topology_minimal(frag: Mol, donor_child1b: list[int]) -> Mol:
    """
    Minimal, robust fixes:
      - If fragment is cationic overall, try RDKit Uncharger().
      - If fragment is a single halogen atom which is the donor -> set charge -1, drop implicit Hs.
    Returns a *new* Mol (sanitized).
    """
    m = Chem.Mol(frag)

    # 1) cationic → uncharge (common NH4+ → NH3 cases)
    try:
        if _formal_charge(m) > 0:
            m = rdMS.Uncharger().uncharge(m)
            Chem.SanitizeMol(m)
    except Exception:
        m = Chem.Mol(frag)  # fallback

    # 2) monatomic halide donor → anion
    heavy = [a for a in m.GetAtoms() if a.GetAtomicNum() != 1]
    if len(heavy) == 1 and heavy[0].GetAtomicNum() in HALO_Z and len(donor_child1b) == 1:
        rw = Chem.RWMol(m)
        at = rw.GetAtomWithIdx(heavy[0].GetIdx())
        at.SetFormalCharge(-1)
        at.SetNoImplicit(True)
        at.SetNumExplicitHs(0)
        m = rw.GetMol()
        Chem.SanitizeMol(m, sanitizeOps=Chem.SANITIZE_PROPERTIES)

    return m


# -------------------- SMILES + donor-index mapping (non-canonical) --------------------


def _noncanonical_smiles_and_order(m: Mol) -> tuple[str, list[int], dict[int, int]]:
    """
    Return (smiles_noncanonical, order_orig0, child1b_to_smipos1b)
      - order_orig0: list of original atom indices (0-based) in the printed order
      - child1b_to_smipos1b: map (1-based local index in this Mol) -> position (1-based) in SMILES
    """
    m2 = Chem.Mol(m)
    # tag each atom with its (1-based) local index so we can recover the written order:
    for a in m2.GetAtoms():
        a.SetAtomMapNum(a.GetIdx() + 1)
    s_mapped = Chem.MolToSmiles(
        m2, canonical=False, isomericSmiles=True, kekuleSmiles=False, allHsExplicit=False
    )
    # parse map numbers in written order
    import re

    ids_1b = [int(x) for x in re.findall(r":(\d+)\]", s_mapped)]
    if len(ids_1b) != m2.GetNumAtoms():
        # Fallback: try with allHsExplicit=True if there are explicit Hs written
        s_mapped2 = Chem.MolToSmiles(
            m2, canonical=False, isomericSmiles=True, kekuleSmiles=False, allHsExplicit=True
        )
        ids_1b = [int(x) for x in re.findall(r":(\d+)\]", s_mapped2)]
        if len(ids_1b) != m2.GetNumAtoms():
            raise RuntimeError(
                f"Could not recover SMILES order (got {len(ids_1b)} / {m2.GetNumAtoms()})."
            )
        s_mapped = s_mapped2

    # plain non-canonical SMILES without map numbers:
    # re-generate without maps so output is clean:
    for a in m2.GetAtoms():
        a.SetAtomMapNum(0)
    s_plain = Chem.MolToSmiles(
        m2, canonical=False, isomericSmiles=True, kekuleSmiles=False, allHsExplicit=False
    )

    order_orig0 = [i - 1 for i in ids_1b]  # 0-based original order (within this fragment)
    child1b_to_smipos1b = {(i + 1): (pos + 1) for pos, i in enumerate(order_orig0)}
    return s_plain, order_orig0, child1b_to_smipos1b


# -------------------- pretty printer (non-canonical T-REX-Full) --------------------


def _pretty_noncanon_trex(
    metal: str,
    ox: int,
    lig_smiles: list[str],
    pairs_sites: list[tuple[tuple[int, list[int]], tuple[int, list[int]]]],
    singles_sites: list[tuple[int, list[int]]] | None = None,
    G: str | None = None,
) -> str:
    oxs = f"+{ox}" if ox > 0 else str(ox)
    L = ", ".join(f"SMILES:{s}" for s in lig_smiles)

    def _site_str(lig: int, atoms: list[int]) -> str:
        if not atoms:
            return f"{lig}"
        return (
            f"{lig}:[{','.join(str(a) for a in atoms)}]" if len(atoms) > 1 else f"{lig}:{atoms[0]}"
        )

    pairs_txt = ", ".join(f"({_site_str(i,a)}, {_site_str(j,b)})" for (i, a), (j, b) in pairs_sites)
    singles_txt = (
        "" if not singles_sites else "; " + ", ".join(_site_str(i, a) for i, a in singles_sites)
    )
    tail = f" | G:{G}" if G else ""
    return f"{metal}{{{oxs}}} | L=[ {L} ] | MAP:{{ {pairs_txt}{singles_txt} }}{tail}"


# -------------------- main pipeline --------------------


def _guess_geometry_from_counts(n_pairs: int, n_singles: int) -> str | None:
    # Minimal heuristic: exactly 3 trans pairs → octahedral
    if n_pairs == 3:
        return "O"
    return None
