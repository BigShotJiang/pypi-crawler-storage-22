# trex/xyz_to_trex.py
from __future__ import annotations

from pathlib import Path

import numpy as np
from rdkit import Chem
from rdkit.Chem.rdchem import Mol

from trex.model import LigandPayload, MapSite, TrexFull

# --- XYZ → bonded mol (Jensen path) ---
from trex.xyz2mol_tmc import (
    get_basic_mol,  # xyz -> RDKit Mol with bonds & 3D
    get_lig_mol,  # build sanitizable ligand + refine charge
    get_proposed_ligand_charge,  # EHT-based ligand charge guess
)

# --- Use helpers (mapping, hapticity grouping, pretty) ---
from trex.xyz_helper import (
    D_BLOCK_METALS,
    _connected_components_on_atoms,
    _fix_fragment_topology_minimal,
    _noncanonical_smiles_and_order,
    _pick_top_k_trans_pairs_by_centroid,
    _pick_trans_pairs_greedy_by_centroid,
    _pretty_noncanon_trex,
    _remove_atom_and_get_fragmaps,
    geometry_to_n_trans_pairs,
)

# ---------------- geometry to coordination number mapping ----------------

GEOMETRY_TO_CN: dict[str, int] = {
    "octahedral": 6,
    "square planar": 4,
    "square pyramidal": 5,
    "trigonal bipyramidal": 5,
    "pentagonal bipyramidal": 7,
    "tetrahedral": 4,
    "trigonal prismatic": 6,
    "t-shaped": 3,
    "see-saw": 4,
    "linear": 2,
    "bent": 2,
    "trigonal planar": 3,
}

# Typical donor atoms (atomic numbers)
DONOR_ATOM_NUMS: set[int] = {
    5,  # B (boron, for some ligands)
    6,  # C (carbene, Cp, CO)
    7,  # N
    8,  # O
    9,  # F
    14,  # Si
    15,  # P
    16,  # S
    17,  # Cl
    33,  # As
    34,  # Se
    35,  # Br
    53,  # I
}


def _find_missing_donors(
    mol: Mol,
    metal_idx: int,
    current_donors: list[int],
    expected_cn: int,
    max_distance: float = 3.5,
) -> list[int]:
    """
    Find candidate donor atoms that may have been missed due to long M-L bonds.

    Args:
        mol: RDKit Mol with 3D conformer
        metal_idx: Index of the metal atom
        current_donors: Already detected donor atom indices
        expected_cn: Expected coordination number from geometry
        max_distance: Maximum M-L distance to consider (Angstroms)

    Returns:
        List of additional donor atom indices, sorted by distance (closest first)
    """
    current_cn = len(current_donors)
    missing = expected_cn - current_cn

    if missing <= 0:
        return []

    conf = mol.GetConformer()
    metal_pos = conf.GetAtomPosition(metal_idx)

    # Find candidate atoms
    candidates: list[tuple[float, int]] = []  # (distance, atom_idx)

    current_set = set(current_donors)
    current_set.add(metal_idx)

    for atom in mol.GetAtoms():
        idx = atom.GetIdx()
        if idx in current_set:
            continue

        # Check if it's a reasonable donor atom
        anum = atom.GetAtomicNum()
        if anum not in DONOR_ATOM_NUMS:
            continue

        # Skip atoms that are likely not donors (e.g., C in alkyl chains)
        # Carbon should only be considered if it has few hydrogens (carbene/CO/Cp)
        if anum == 6:  # Carbon
            # Only consider C with ≤1 H (carbene, CO, isocyanide, Cp-type)
            total_hs = atom.GetTotalNumHs()
            if total_hs > 1:
                continue

        # Check distance
        atom_pos = conf.GetAtomPosition(idx)
        dist = metal_pos.Distance(atom_pos)

        if dist <= max_distance:
            candidates.append((dist, idx))

    # Sort by distance and return the closest ones
    candidates.sort(key=lambda x: x[0])

    return [idx for _, idx in candidates[:missing]]


def _add_bond_to_mol(mol: Mol, idx1: int, idx2: int) -> Mol:
    """
    Add a single bond between two atoms in the molecule.
    Returns a new editable molecule with the bond added.
    """
    from rdkit.Chem import RWMol

    rw = RWMol(mol)
    # Check if bond already exists
    if rw.GetBondBetweenAtoms(idx1, idx2) is None:
        rw.AddBond(idx1, idx2, Chem.BondType.SINGLE)
    return rw.GetMol()


# ---------------- main functions ----------------


def _find_single_metal(m: Mol) -> int:
    metals = [a.GetIdx() for a in m.GetAtoms() if a.GetAtomicNum() in D_BLOCK_METALS]
    if len(metals) != 1:
        raise ValueError(f"Expected exactly one metal center; found {len(metals)}")
    return metals[0]


def _align_local_indices_heavy(src: Mol, dst: Mol) -> dict[int, int]:
    """
    Map heavy-atom indices: src_idx0 (no H) -> dst_idx0 (no H).
    Uses substructure match with kekulé fallback; identity if sizes match and match fails.
    """
    # ensure both are heavy-only
    srcH = Chem.RemoveHs(Chem.Mol(src))
    dstH = Chem.RemoveHs(Chem.Mol(dst))

    match = dstH.GetSubstructMatch(srcH)
    if not match or len(match) != srcH.GetNumAtoms():
        q = Chem.Mol(srcH)
        t = Chem.Mol(dstH)
        try:
            Chem.Kekulize(q, clearAromaticFlags=True)
            Chem.Kekulize(t, clearAromaticFlags=True)
        except Exception:
            pass
        match = t.GetSubstructMatch(q)

    if match and len(match) == srcH.GetNumAtoms():
        return {i: match[i] for i in range(len(match))}

    if srcH.GetNumAtoms() == dstH.GetNumAtoms():
        # last-resort identity mapping
        return {i: i for i in range(srcH.GetNumAtoms())}

    raise ValueError("Could not align fragment to EHT-refined ligand (heavy-atom mismatch).")


def _child1b_to_heavy_child1b(m: Mol) -> dict[int, int]:
    """
    Build a map from local child index (1-based, with H) -> local heavy-only index (1-based).
    We tag atoms with their child1b, remove H, then read tags back.
    """
    m2 = Chem.Mol(m)
    for a in m2.GetAtoms():
        a.SetIntProp("_child1b", a.GetIdx() + 1)
    mh = Chem.RemoveHs(m2)
    out: dict[int, int] = {}
    for i, a in enumerate(mh.GetAtoms()):
        out[a.GetIntProp("_child1b")] = i + 1  # now heavy index is 1-based
    return out


def _noncanon_smiles_and_positions_from_lig_best(lig_best: Mol) -> tuple[str, dict[int, int]]:
    """
    Produce clean (implicit-H) non-canonical SMILES from lig_best and the map:
      local heavy 1-based index -> SMILES writing position (1-based).
    """
    ligH = Chem.RemoveHs(Chem.Mol(lig_best))
    s_noH, _ord0, child1b_to_pos1b = _noncanonical_smiles_and_order(ligH)
    return s_noH, child1b_to_pos1b


def _get_site_centroid(
    mol: Mol,
    atom_indices: list[int],
    origin: tuple[float, float, float] | None = None,
) -> tuple[float, float, float]:
    """
    Get centroid of atoms (handles haptic sites with multiple atoms).

    Args:
        mol: RDKit Mol with 3D conformer
        atom_indices: list of atom indices (0-based) in the mol
        origin: optional origin point to subtract (for metal-relative coords)

    Returns:
        (x, y, z) tuple of centroid coordinates (relative to origin if provided)
    """
    conf = mol.GetConformer()
    positions = []
    for idx in atom_indices:
        pos = conf.GetAtomPosition(idx)
        positions.append([pos.x, pos.y, pos.z])
    centroid = np.mean(positions, axis=0)

    if origin is not None:
        centroid = centroid - np.array(origin)

    return tuple(centroid)


def _get_metal_position(mol: Mol, metal_idx: int) -> tuple[float, float, float]:
    """Get the 3D position of the metal atom."""
    conf = mol.GetConformer()
    pos = conf.GetAtomPosition(metal_idx)
    return (pos.x, pos.y, pos.z)


def noncanonical_trex_from_xyz(
    xyz_path: str | Path,
    overall_charge: int,
    angle_trans: float = 150.0,
    geometry: str | None = None,
) -> str:
    """
    XYZ → non-canonical T-REX (mapping tied to printed SMILES) + EHT ligand charges.
      • SMILES are implicit-H (no [H] in text).
      • MAP indices are *SMILES writing positions* (per ligand).
      • Haptic sites are bracketed; trans pairs picked by centroid vectors.
      • Metal oxidation state = overall_charge - sum(ligand_charges by EHT).
      If `geometry` is one of the supported names, choose exactly that many
    non-overlapping, most-trans site pairs (no threshold). Otherwise fall back
    to the greedy-by-cutoff logic with `angle_trans`.
    """
    xyz_path = Path(xyz_path)

    # 1) Build bonded mol from XYZ
    mol = get_basic_mol(xyz_path, overall_charge)
    if mol is None or mol.GetNumConformers() == 0:
        raise ValueError("XYZ build failed or has no 3D conformer.")

    # 2) Metal & first shell donors
    m_idx = _find_single_metal(mol)
    metal_symbol = mol.GetAtomWithIdx(m_idx).GetSymbol()
    donors_old = [n.GetIdx() for n in mol.GetAtomWithIdx(m_idx).GetNeighbors()]

    # 2b) Recovery for missed donors due to long M-L bonds
    # If geometry is specified and we're missing exactly 1 site, try to find it
    # Only for CN < 7 (higher CN complexes aren't well-suited for T-REX anyway)
    if geometry is not None and geometry in GEOMETRY_TO_CN:
        expected_cn = GEOMETRY_TO_CN[geometry]
        current_cn = len(donors_old)

        if expected_cn < 7 and current_cn == expected_cn - 1:
            # Try to find the missing donor
            missing_donors = _find_missing_donors(
                mol, m_idx, donors_old, expected_cn, max_distance=3.5
            )

            if missing_donors:
                # Add bond(s) to the molecule and update donors list
                for new_donor_idx in missing_donors:
                    mol = _add_bond_to_mol(mol, m_idx, new_donor_idx)
                    donors_old.append(new_donor_idx)

    if not donors_old:
        raise ValueError("No metal–ligand bonds detected from XYZ topology.")

    # 3) Remove metal → fragments & maps (as in MOL2 path)
    mol_noM, old2new, atom_to_frag, frags_as_mols = _remove_atom_and_get_fragmaps(mol, m_idx)

    # donor -> fragment id, and donor-old -> child (1-based) index inside its fragment (WITH H)
    frag_atom_tuples = Chem.GetMolFrags(mol_noM, asMols=False, sanitizeFrags=False)
    new_to_child1b: dict[int, dict[int, int]] = {
        fid: {new_idx: (pos + 1) for pos, new_idx in enumerate(atoms)}
        for fid, atoms in enumerate(frag_atom_tuples)
    }

    site_to_frag: dict[int, int] = {}
    site_old_to_child1b: dict[int, int] = {}
    for a_old in donors_old:
        a_new = old2new[a_old]
        if a_new is None:
            raise RuntimeError("Neighbor vanished after metal removal.")
        fid = atom_to_frag[a_new]
        site_to_frag[a_old] = fid
        site_old_to_child1b[a_old] = new_to_child1b[fid][a_new]

    # Stable ligand order by fragment id
    frag_order = sorted(set(site_to_frag.values()))

    # 4) Hapticity: group donor atoms per fragment using connectivity in the parent mol
    lig_sites_old: list[list[list[int]]] = []
    for fid in frag_order:
        atoms_for_f = [a_old for a_old in donors_old if site_to_frag[a_old] == fid]
        comps = _connected_components_on_atoms(mol, atoms_for_f)  # lists of OLD atom indices
        lig_sites_old.append(comps)

        # 5) Per-ligand smiles + writing-order mapping from lig_best (EHT-refined)
    lig_smiles: list[str] = []
    # heavy child(1b) on lig_best → SMILES pos(1b)
    lig_best_heavy1b_to_smipos1b: list[dict[int, int]] = []
    # heavy index mapping: frag_fix(0b) -> lig_best(0b)
    lig_align_fixH_to_bestH: list[dict[int, int]] = []
    # child(1b with H) -> heavy(1b) map for frag_fix
    lig_child1b_to_heavy_fix: list[dict[int, int]] = []

    ligand_charge_sum = 0

    for fid in frag_order:
        frag = frags_as_mols[fid]

        # donors for this fragment as CHILD indices (WITH H)
        donor_child1b = [
            site_old_to_child1b[a_old] for a_old in donors_old if site_to_frag[a_old] == fid
        ]

        # minimal fixes BEFORE EHT/mapping
        frag_fix = _fix_fragment_topology_minimal(frag, donor_child1b)

        # map child(1b, with H) -> heavy(1b) on frag_fix
        child1b_to_heavy = _child1b_to_heavy_child1b(frag_fix)
        lig_child1b_to_heavy_fix.append(child1b_to_heavy)

        # --- EHT charge (Jensen) using refined ligand ---
        try:
            q0 = int(get_proposed_ligand_charge(frag_fix))
        except Exception:
            q0 = 0
        # print(q0)
        try:
            # note: get_lig_mol expects 0-based indices (on frag_fix)
            lig_best, q = get_lig_mol(frag_fix, q0, [i - 1 for i in donor_child1b])
            if lig_best is None:
                lig_best = frag_fix
            ligand_charge_sum += int(q)
        except Exception:
            lig_best = frag_fix
            ligand_charge_sum += q0

        # align HEAVY atoms: frag_fix → lig_best
        try:
            map_fixH_to_bestH = _align_local_indices_heavy(frag_fix, lig_best)  # 0-based
        except Exception:
            # Identity fallback if sizes match
            n_fixH = Chem.RemoveHs(Chem.Mol(frag_fix)).GetNumAtoms()
            n_bestH = Chem.RemoveHs(Chem.Mol(lig_best)).GetNumAtoms()
            if n_fixH != n_bestH:
                raise
            map_fixH_to_bestH = {i: i for i in range(n_fixH)}
        lig_align_fixH_to_bestH.append(map_fixH_to_bestH)

        # implicit-H SMILES from lig_best + heavy(1b) → SMILES pos(1b) map
        s_plain, best_heavy1b_to_pos1b = _noncanon_smiles_and_positions_from_lig_best(lig_best)
        lig_smiles.append(s_plain)
        lig_best_heavy1b_to_smipos1b.append(best_heavy1b_to_pos1b)

    # 6) Global site list and trans pairing (centroid vectors)
    global_sites_old: list[tuple[int, list[int]]] = []
    for lig_temp, comps in enumerate(lig_sites_old, start=1):
        for site in comps:
            global_sites_old.append((lig_temp, site))

    sites_only = [s for (_, s) in global_sites_old]
    k = geometry_to_n_trans_pairs(geometry)

    if k is not None:
        pairs_idx, singles_idx = _pick_top_k_trans_pairs_by_centroid(mol, m_idx, sites_only, k)
    else:
        pairs_idx, singles_idx = _pick_trans_pairs_greedy_by_centroid(
            mol, m_idx, sites_only, angle_trans
        )

    # helper: OLD atom set → (lig_temp, SMILES positions 1b) using stored heavy-only maps
    def _site_to_out(si: int) -> tuple[int, list[int]]:
        lig_temp, site_atoms_old = global_sites_old[si]
        L = lig_temp - 1

        # donor_old -> child1b(with H) -> HEAVY child1b on frag_fix
        child_map_fix = lig_child1b_to_heavy_fix[L]
        site_heavy_child1b_fix = []
        for a_old in site_atoms_old:
            ch1 = site_old_to_child1b.get(a_old)
            if ch1 is None:
                continue
            hv1 = child_map_fix.get(ch1)
            if hv1 is not None:
                site_heavy_child1b_fix.append(hv1)

        if not site_heavy_child1b_fix:
            return lig_temp, []

        # HEAVY child(1b) on frag_fix → HEAVY (1b) on lig_best
        align = lig_align_fixH_to_bestH[L]  # 0-based indices
        site_best_heavy_1b = []
        for hv1 in site_heavy_child1b_fix:
            hv0 = hv1 - 1
            if hv0 in align:
                site_best_heavy_1b.append(align[hv0] + 1)

        # HEAVY (1b) on lig_best → SMILES writing pos(1b)
        best_map = lig_best_heavy1b_to_smipos1b[L]
        pos = sorted({best_map.get(i) for i in site_best_heavy_1b if best_map.get(i) is not None})
        return lig_temp, pos

    pairs_sites = [(_site_to_out(i), _site_to_out(j)) for i, j in pairs_idx]
    singles_sites = [_site_to_out(i) for i in singles_idx]

    # 7) Metal oxidation state from overall charge and ligand sum
    metal_ox = int(overall_charge - ligand_charge_sum)

    # 8) Compose non-canonical T-REX (η^n bracketed; implicit-H SMILES)
    if geometry == "trigonal prismatic":
        return _pretty_noncanon_trex(
            metal_symbol, metal_ox, lig_smiles, pairs_sites, singles_sites, G="TP"
        )
    else:
        return _pretty_noncanon_trex(
            metal_symbol, metal_ox, lig_smiles, pairs_sites, singles_sites, G=None
        )


def noncanonical_trex_model_from_xyz(
    xyz_path: str | Path,
    overall_charge: int,
    angle_trans: float = 150.0,
    geometry: str | None = None,
) -> TrexFull:
    """
    XYZ → non-canonical TrexFull object WITH 3D coordinates attached to MapSites.

    This is the coordinate-aware version that enables chirality computation.
    The coord attribute on each MapSite contains the 3D centroid of the coordinating atoms.

    Args:
        xyz_path: Path to XYZ file
        overall_charge: Total charge of the complex
        angle_trans: Threshold angle for trans pair detection (default 150°)
        geometry: Optional geometry hint (e.g., "octahedral", "square planar")

    Returns:
        TrexFull object with coord attributes populated on all MapSites
    """
    xyz_path = Path(xyz_path)

    # 1) Build bonded mol from XYZ
    mol = get_basic_mol(xyz_path, overall_charge)
    if mol is None or mol.GetNumConformers() == 0:
        raise ValueError("XYZ build failed or has no 3D conformer.")

    # 2) Metal & first shell donors
    m_idx = _find_single_metal(mol)
    metal_symbol = mol.GetAtomWithIdx(m_idx).GetSymbol()
    donors_old = [n.GetIdx() for n in mol.GetAtomWithIdx(m_idx).GetNeighbors()]

    # 2b) Recovery for missed donors due to long M-L bonds
    # If geometry is specified and we're missing exactly 1 site, try to find it
    # Only for CN < 7 (higher CN complexes aren't well-suited for T-REX anyway)
    if geometry is not None and geometry in GEOMETRY_TO_CN:
        expected_cn = GEOMETRY_TO_CN[geometry]
        current_cn = len(donors_old)

        if expected_cn < 7 and current_cn == expected_cn - 1:
            # Try to find the missing donor
            missing_donors = _find_missing_donors(
                mol, m_idx, donors_old, expected_cn, max_distance=3.5
            )

            if missing_donors:
                # Add bond(s) to the molecule and update donors list
                for new_donor_idx in missing_donors:
                    mol = _add_bond_to_mol(mol, m_idx, new_donor_idx)
                    donors_old.append(new_donor_idx)

    if not donors_old:
        raise ValueError("No metal–ligand bonds detected from XYZ topology.")

    # 3) Remove metal → fragments & maps
    mol_noM, old2new, atom_to_frag, frags_as_mols = _remove_atom_and_get_fragmaps(mol, m_idx)

    frag_atom_tuples = Chem.GetMolFrags(mol_noM, asMols=False, sanitizeFrags=False)
    new_to_child1b: dict[int, dict[int, int]] = {
        fid: {new_idx: (pos + 1) for pos, new_idx in enumerate(atoms)}
        for fid, atoms in enumerate(frag_atom_tuples)
    }

    site_to_frag: dict[int, int] = {}
    site_old_to_child1b: dict[int, int] = {}
    for a_old in donors_old:
        a_new = old2new[a_old]
        if a_new is None:
            raise RuntimeError("Neighbor vanished after metal removal.")
        fid = atom_to_frag[a_new]
        site_to_frag[a_old] = fid
        site_old_to_child1b[a_old] = new_to_child1b[fid][a_new]

    frag_order = sorted(set(site_to_frag.values()))

    # 4) Hapticity grouping
    lig_sites_old: list[list[list[int]]] = []
    for fid in frag_order:
        atoms_for_f = [a_old for a_old in donors_old if site_to_frag[a_old] == fid]
        comps = _connected_components_on_atoms(mol, atoms_for_f)
        lig_sites_old.append(comps)

    # 5) Per-ligand processing
    lig_smiles: list[str] = []
    lig_best_heavy1b_to_smipos1b: list[dict[int, int]] = []
    lig_align_fixH_to_bestH: list[dict[int, int]] = []
    lig_child1b_to_heavy_fix: list[dict[int, int]] = []
    ligand_charge_sum = 0

    for fid in frag_order:
        frag = frags_as_mols[fid]
        donor_child1b = [
            site_old_to_child1b[a_old] for a_old in donors_old if site_to_frag[a_old] == fid
        ]
        frag_fix = _fix_fragment_topology_minimal(frag, donor_child1b)
        child1b_to_heavy = _child1b_to_heavy_child1b(frag_fix)
        lig_child1b_to_heavy_fix.append(child1b_to_heavy)

        try:
            q0 = int(get_proposed_ligand_charge(frag_fix))
        except Exception:
            q0 = 0
        try:
            lig_best, q = get_lig_mol(frag_fix, q0, [i - 1 for i in donor_child1b])
            if lig_best is None:
                lig_best = frag_fix
            ligand_charge_sum += int(q)
        except Exception:
            lig_best = frag_fix
            ligand_charge_sum += q0

        try:
            map_fixH_to_bestH = _align_local_indices_heavy(frag_fix, lig_best)
        except Exception:
            n_fixH = Chem.RemoveHs(Chem.Mol(frag_fix)).GetNumAtoms()
            n_bestH = Chem.RemoveHs(Chem.Mol(lig_best)).GetNumAtoms()
            if n_fixH != n_bestH:
                raise
            map_fixH_to_bestH = {i: i for i in range(n_fixH)}
        lig_align_fixH_to_bestH.append(map_fixH_to_bestH)

        s_plain, best_heavy1b_to_pos1b = _noncanon_smiles_and_positions_from_lig_best(lig_best)
        lig_smiles.append(s_plain)
        lig_best_heavy1b_to_smipos1b.append(best_heavy1b_to_pos1b)

    # 6) Global site list and trans pairing
    global_sites_old: list[tuple[int, list[int]]] = []
    for lig_temp, comps in enumerate(lig_sites_old, start=1):
        for site in comps:
            global_sites_old.append((lig_temp, site))

    sites_only = [s for (_, s) in global_sites_old]
    k = geometry_to_n_trans_pairs(geometry)

    if k is not None:
        pairs_idx, singles_idx = _pick_top_k_trans_pairs_by_centroid(mol, m_idx, sites_only, k)
    else:
        pairs_idx, singles_idx = _pick_trans_pairs_greedy_by_centroid(
            mol, m_idx, sites_only, angle_trans
        )

    # Get metal position for computing metal-relative coordinates
    metal_pos = _get_metal_position(mol, m_idx)

    # Helper to convert site index to MapSite WITH metal-relative coordinate
    def _site_to_mapsite(si: int) -> MapSite:
        lig_temp, site_atoms_old = global_sites_old[si]
        L = lig_temp - 1

        # Get SMILES positions
        child_map_fix = lig_child1b_to_heavy_fix[L]
        site_heavy_child1b_fix = []
        for a_old in site_atoms_old:
            ch1 = site_old_to_child1b.get(a_old)
            if ch1 is None:
                continue
            hv1 = child_map_fix.get(ch1)
            if hv1 is not None:
                site_heavy_child1b_fix.append(hv1)

        if not site_heavy_child1b_fix:
            pos_list = []
        else:
            align = lig_align_fixH_to_bestH[L]
            site_best_heavy_1b = []
            for hv1 in site_heavy_child1b_fix:
                hv0 = hv1 - 1
                if hv0 in align:
                    site_best_heavy_1b.append(align[hv0] + 1)
            best_map = lig_best_heavy1b_to_smipos1b[L]
            pos_list = sorted(
                {best_map.get(i) for i in site_best_heavy_1b if best_map.get(i) is not None}
            )

        # Get 3D coordinate relative to metal (metal at origin)
        coord = _get_site_centroid(mol, site_atoms_old, origin=metal_pos)

        return MapSite(lig=lig_temp, atoms=pos_list, coord=coord)

    # Build pairs and singles with coordinates
    pairs = []
    for i, j in pairs_idx:
        site_a = _site_to_mapsite(i)
        site_b = _site_to_mapsite(j)
        pairs.append((site_a, site_b))

    singles = [_site_to_mapsite(i) for i in singles_idx]

    # 7) Build ligand payloads
    ligand_payloads = [LigandPayload(kind="SMILES", text=s) for s in lig_smiles]

    # 8) Metal oxidation state
    metal_ox = int(overall_charge - ligand_charge_sum)

    # 9) Geometry flag
    G_flag = "TP" if geometry == "trigonal prismatic" else None

    return TrexFull(
        metal=metal_symbol,
        ox=metal_ox,
        spin=None,
        ligands=ligand_payloads,
        pairs=pairs,
        singles=singles,
        G=G_flag,
        X=None,
    )


def _canonicalize_trex_string(s: str) -> str:
    """Parse → canonicalize → pretty-print (ensure bracket-safe pretty in canon_full)."""
    from trex.canon_full import canonicalize_full, pretty_trex_full
    from trex.parse_full import parse_trex_full_string

    t = parse_trex_full_string(s)
    tc = canonicalize_full(t)
    return pretty_trex_full(tc)


def xyz_to_trex(
    xyz_path: str | Path,
    overall_charge: int,
    canonicalize_fn=None,
    angle_trans: float = 150.0,
    geometry: str | None = None,
) -> str:
    s_nc = noncanonical_trex_from_xyz(
        xyz_path, overall_charge, angle_trans=angle_trans, geometry=geometry
    )
    return canonicalize_fn(s_nc) if callable(canonicalize_fn) else s_nc


def xyz_to_trex_canonical(
    xyz_path: str | Path,
    overall_charge: int,
    angle_trans: float = 150.0,
    geometry: str | None = None,
) -> str:
    """
    XYZ → canonical T-REX string (no chirality flag).

    This applies full canonicalization including:
    - Ligand charge fixes (nitro, hydride)
    - Standard ligand/site ordering
    - Pentagonal bipyramidal rotation ordering (if applicable, requires coordinates)

    For chirality-aware output, use xyz_to_trex_with_chirality instead.

    Args:
        xyz_path: Path to XYZ file
        overall_charge: Total charge of the complex
        angle_trans: Threshold angle for trans pair detection
        geometry: Optional geometry hint

    Returns:
        Canonical T-REX string
    """
    from trex.canon_full import canonicalize_full, pretty_trex_full

    # Build TrexFull with coordinates attached
    t_nc = noncanonical_trex_model_from_xyz(
        xyz_path, overall_charge, angle_trans=angle_trans, geometry=geometry
    )

    # Canonicalize (coordinates travel with MapSites)
    # pntbp rotation ordering is now handled inside canonicalize_full
    t_canon = canonicalize_full(t_nc)

    return pretty_trex_full(t_canon)


def xyz_to_trex_with_chirality(
    xyz_path: str | Path,
    overall_charge: int,
    angle_trans: float = 150.0,
    geometry: str | None = None,
) -> str:
    """
    XYZ → canonical T-REX string with chirality flag.

    This is the main entry point for chirality-aware T-REX generation.

    Args:
        xyz_path: Path to XYZ file
        overall_charge: Total charge of the complex
        angle_trans: Threshold angle for trans pair detection
        geometry: Optional geometry hint

    Returns:
        Canonical T-REX string with chirality flag (X:@ or X:@@) if chiral
    """
    from trex.canon_full import canonicalize_full, pretty_trex_full
    from trex.chirality import compute_chirality

    # Build TrexFull with coordinates attached
    t_nc = noncanonical_trex_model_from_xyz(
        xyz_path, overall_charge, angle_trans=angle_trans, geometry=geometry
    )

    # Canonicalize (coordinates travel with MapSites)
    # pntbp rotation ordering is now handled inside canonicalize_full
    t_canon = canonicalize_full(t_nc)

    # Compute chirality using canonical coordinates
    chirality = compute_chirality(t_canon)

    # Attach chirality flag
    t_canon.X = chirality

    return pretty_trex_full(t_canon)


def xyz_to_trex_canon(s: str) -> str:
    """
    Canonicalize a non-canonical T-REX (FULL) string.

    Args:
        s: Non-canonical T-REX string, e.g.
           'Fe{+2} | L=[ SMILES:..., ... ] | MAP:{ (1:1, 2:1); 3:1 }'

    Returns:
        Canonical T-REX string.

    Raises:
        ImportError: If 'trex.parse_full' is unavailable.
        ValueError: If the input string is invalid.
    """
    # Lazy import to avoid any circular import surprises.
    try:
        from .parse_full import canonicalize_trex_full_string
    except Exception as e:
        raise ImportError("trex.parse_full.canonicalize_trex_full_string is not available.") from e

    if not isinstance(s, str) or not s.strip():
        raise ValueError("Input must be a non-empty T-REX string.")

    return canonicalize_trex_full_string(s)
