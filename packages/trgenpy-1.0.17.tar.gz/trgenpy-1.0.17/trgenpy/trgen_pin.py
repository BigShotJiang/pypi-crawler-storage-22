from enum import IntEnum

class TrgenPin(IntEnum):
    """
    Enum for the trigger pins.
    
    Represents various trigger pins available on the device.
    Pins NS0 to NS7, SA0 to SA7, BNCO, BNCI, and GPIO0 to GPIO7 are defined.

    Code values correspond to pin identifiers:
    
    * 0-7: NS0 to NS7
    * 8-15: SA0 to SA7  
    * 16: BNCO
    * 17: BNCI
    * 18-25: GPIO0 to GPIO7
    * 26: FOTODIODO

    Example:
        .. code-block:: python
        
            pin = TrgenPin.NS0
            if pin == TrgenPin.NS0:
                print("Selected pin is NS0")
    """
    NS0 = 0
    NS1 = 1
    NS2 = 2
    NS3 = 3
    NS4 = 4
    NS5 = 5
    NS6 = 6
    NS7 = 7
    SA0 = 8
    SA1 = 9
    SA2 = 10
    SA3 = 11
    SA4 = 12
    SA5 = 13
    SA6 = 14
    SA7 = 15
    BNCO = 16
    BNCI = 17
    GPIO0 = 18
    GPIO1 = 19
    GPIO2 = 20
    GPIO3 = 21
    GPIO4 = 22
    GPIO5 = 23
    GPIO6 = 24
    GPIO7 = 25
    PD = 26

class TrgenLevel(IntEnum):
    """
    Enum for the trigger levels.
    A trigger can be set to HIGH or LOW level.
    """
    LOW = 0
    HIGH = 1

class GPIODirection(IntEnum):
    """
    Enum for the GPIO directions.
    GPIO can be configured as input or output.
    """
    IN = 0
    OUT = 1
