# SDK — Design & Implementation Reference

## Overview

The Triage SDK captures telemetry from AI agents to enable security-focused observability. The SDK's job is **data collection only** — all heavy analysis (embeddings, PII detection, drift scoring, groundedness) happens later on backend workers. The SDK must never add meaningful latency to the customer's application.

## Architecture

### The SDK Has Two Layers

**Layer 1: OpenLLMetry (all auto-instrumentation)**

OpenLLMetry (by Traceloop), built on OpenTelemetry, already auto-instruments LLM providers, agent frameworks, and vector DBs. It handles framework callbacks internally — we do not build our own. We initialize it and point its exporter at our ingest API.

**Layer 2: Triage context helpers (developer annotations)**

Six data points that live in the application layer above the LLM library boundary. OpenLLMetry cannot see these, so the developer must pass them in via our helper functions.

That's it. The SDK is OpenLLMetry init + a standard OTLP exporter pointed at our backend + 6 helper functions.

## What OpenLLMetry Auto-Captures

OpenLLMetry intercepts LLM client calls, framework agent loops, and vector DB queries. It gives us the following with zero developer effort:

- **System Prompt** — From the `messages` array sent to the LLM client.
- **Chain-of-Thought / Hidden Thoughts** — From response (extended thinking, reasoning tokens).
- **Confidence/Uncertainty Scores** — From logprobs or model response metadata.
- **Step Count per Request** — From tool-use rounds in an agent loop.
- **Pre-Execution Tool Arguments** — The JSON payload before each tool call.
- **Tool Execution Status & Error Codes** — Return status from tool execution.
- **Tool Output (Post-Execution)** — Data returned by tools.
- **Model/Infrastructure Metadata** — Model name, provider, token usage, latency.
- **Retrieved Chunk Metadata** — Chunks returned by vector DB queries (OpenLLMetry instruments Pinecone, Chroma, Weaviate, Qdrant, etc.).
- **Vector Namespace/Index ID** — Which namespace/index was queried.

## What We Build: Developer Annotation Helpers

OpenLLMetry instruments at the **library boundary** (e.g., `openai.chat.completions.create()`). Everything above that boundary — auth, tenancy, session management, input filtering, prompt templating — is invisible to it. We provide helpers for these 6 data points:

1. **User ID & Role** — Lives in the app's auth middleware/JWT/session. The LLM SDK has no concept of users.
2. **Organization/Tenant ID** — Multi-tenancy is an app concern. The LLM API doesn't know about tenants.
3. **Session/Conversation History Hash** — OpenLLMetry sees the messages array but doesn't know which session or turn number this is.
4. **Raw vs. Sanitized User Input** — The app filters input before the LLM call. OpenLLMetry only sees the sanitized version.
5. **Template Version ID** — The app renders a template into a string. OpenLLMetry sees the string, not which template produced it.
6. **Retrieved Chunk ACLs** — OpenLLMetry sees retrieved chunks but not their access control metadata from the app's data layer.

These helpers attach the data as custom OTel span attributes so they flow through the same export pipeline as everything else.

## What the Backend Computes Later (NOT in the SDK)

Derived metrics computed asynchronously after trace ingestion. Do not build these into the SDK:

- Latent embeddings of prompts
- PII/sensitive entity flags
- Retrieval groundedness score
- Instruction drift score
- Prompt injection detection
- Cross-tenant leakage detection
- Privilege escalation detection

## SDK Per Language

- `sdk/python` — Depends on `traceloop-sdk`. Configures standard `OTLPSpanExporter` pointed at our backend + 6 context helpers.
- `sdk/typescript` — Depends on `@traceloop/node-server-sdk`. Configures standard OTLP exporter + 6 context helpers.
- `sdk/go` — Depends on `go.opentelemetry.io/otel` + Traceloop Go instrumentors. Configures standard OTLP exporter + 6 context helpers.
- `sdk/rust` — OTel Rust SDK + custom instrumentors (OpenLLMetry has no Rust support, requires more work).

## Async Event Pipeline

All trace emission is async and non-blocking:
1. **Hot path (sync):** Capture raw data into in-memory buffer — microseconds
2. **Background thread:** Batch flush every N events or M milliseconds to Triage ingest API
3. **Backpressure:** If buffer fills, sample or drop — never block the customer's application

---

## Python SDK — Implementation Plan

### Wire Protocol Decision: OTLP/HTTP

We use the **standard OpenTelemetry Protocol over HTTP** (protobuf encoding, JSON fallback) instead of a custom exporter. This is a foundational decision that shapes the entire SDK and backend.

**Why OTLP, not a custom exporter:**
- `traceloop-sdk` already transitively installs `opentelemetry-exporter-otlp-proto-http`. A custom exporter would reimplement ~2,000 lines of battle-tested batching, retry, compression, and connection management code we already ship.
- Every future SDK language (TypeScript, Go, Rust) has a production-grade OTLP exporter. Custom exporters mean maintaining serialization + HTTP transport per language indefinitely.
- Any customer already using OpenTelemetry (without our SDK) can point their existing OTLP exporter at our backend with an API key header — instant integration, zero SDK dependency.
- Langfuse (closest competitor, LLM observability) started with a custom JSON protocol and explicitly states they would start with OTLP if building today. Their migration from custom to OTLP was driven by the unsustainable cost of maintaining per-language custom SDKs.
- Triage-specific metadata (`triage.user.id`, `triage.tenant.id`, etc.) is transmitted as standard OTel span attributes — the protocol is extensible without breaking the standard.

**Why HTTP, not gRPC:**
- Our backend is FastAPI on ECS Fargate — HTTP/1.1 is native. gRPC requires HTTP/2, gRPC-aware load balancers, and different server frameworks.
- `BatchSpanProcessor` already batches and exports spans in bulk, so we get the throughput gRPC streaming would provide.
- gRPC adds `grpcio` (~20 MB compiled binary) as a dependency to both SDK and backend.
- Can always add a gRPC endpoint later if needed.

**Why protobuf encoding (with JSON fallback):**
- Protobuf is 3-6x smaller than equivalent JSON before compression.
- The Python `OTLPSpanExporter` defaults to protobuf — zero configuration.
- Backend accepts both: `Content-Type: application/x-protobuf` (primary) and `Content-Type: application/json` (debugging, `curl` testing, browser SDKs later).
- Backend uses `opentelemetry-proto` Python package for deserialization — pre-generated classes, no manual parsing.

### End-User Experience

A developer integrates Triage observability with **3 lines of setup** and optional annotation calls:

```python
import triage_sdk
from openai import OpenAI

# 1. Initialize once at app startup
triage_sdk.init(api_key="tsk_...", app_name="my-chatbot", environment="production")

# 2. (Optional) Annotate application context before LLM calls
def handle_chat(request):
    triage_sdk.set_user(user_id=request.user.id, role=request.user.role)
    triage_sdk.set_tenant(tenant_id=request.org.id)
    triage_sdk.set_session(session_id=request.session_id, turn_number=request.turn)
    triage_sdk.set_input(raw=request.raw_body, sanitized=request.cleaned_body)

    # 3. Use any LLM provider normally — telemetry is automatic
    client = OpenAI()
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": request.cleaned_body}],
    )
    return response.choices[0].message.content
```

This works identically for all 37 OpenLLMetry-supported providers (OpenAI, Anthropic, Cohere, Mistral, Groq, Bedrock, Vertex AI, LangChain, LlamaIndex, CrewAI, Pinecone, Chroma, Qdrant, etc.) — zero provider-specific code.

### Package Structure

```
sdk/python/
├── pyproject.toml                          # PEP 621 build config, deps, metadata
├── src/
│   └── triage_sdk/
│       ├── __init__.py                     # Public API surface — init(), helpers, __version__
│       ├── version.py                      # Single-source version string
│       ├── config.py                       # TriageConfig dataclass + env var resolution
│       ├── constants.py                    # Span attribute keys (triage.* namespace)
│       ├── sdk.py                          # TriageSDK singleton — wires Traceloop + OTLPSpanExporter + processor
│       ├── context.py                      # 6 context helpers + TriageContext via contextvars
│       ├── processor.py                    # TriageSpanProcessor — injects TriageContext into spans
│       └── py.typed                        # PEP 561 marker for downstream type checking
└── tests/
    ├── conftest.py                         # Shared fixtures, InMemorySpanExporter, reset_sdk autouse
    ├── test_config.py                      # Config validation, env var fallbacks, defaults
    ├── test_context.py                     # Context helpers, ContextVar propagation, thread safety
    ├── test_processor.py                   # Processor injects context into spans on_start
    ├── test_sdk.py                         # init() wiring, idempotency, shutdown, disabled config
    └── test_e2e.py                         # Full flow: mock OpenAI call → spans captured → attributes verified
```

**Note:** No `exporter.py` or `transport.py`. The standard `OTLPSpanExporter` from `opentelemetry-exporter-otlp-proto-http` (already a transitive dependency of `traceloop-sdk`) handles serialization, batching, retry, compression, and HTTP transport.

### Implementation Steps

#### Step 1 · Project Scaffolding — `pyproject.toml`

Create `sdk/python/pyproject.toml` using PEP 621 (modern `[project]` table).

**Runtime dependencies:**
| Package | Min Version | Purpose |
|---------|-------------|---------|
| `traceloop-sdk` | `>=0.51.0` | OpenLLMetry auto-instrumentation for 37 providers |
| `opentelemetry-api` | `>=1.20.0` | Tracer/Span/Context API |
| `opentelemetry-sdk` | `>=1.20.0` | TracerProvider, BatchSpanProcessor |
| `opentelemetry-exporter-otlp-proto-http` | `>=1.20.0` | Standard OTLP/HTTP exporter (transitive via traceloop-sdk, pinned explicitly for clarity) |

No `requests` dependency — the OTLP exporter manages HTTP internally.

**Dev dependencies (`[project.optional-dependencies] dev`):**
| Package | Purpose |
|---------|---------|
| `pytest` | Test runner |
| `pytest-asyncio` | Async test support |
| `mypy` | Static type checking |
| `ruff` | Linting + formatting |

**Build system:** `hatchling` (lightweight, PEP 621 native, used by OTel Python SDK itself).

**Package metadata:**
- Name: `triage-sdk`
- Import: `triage_sdk`
- Python: `>=3.9`
- License: proprietary
- `src/` layout (PEP 517 recommended)

Create `src/triage_sdk/py.typed` (empty marker file for PEP 561).

---

#### Step 2 · Version — `version.py`

Single-source version string. Referenced by `pyproject.toml` via dynamic version and by `__init__.py`.

```python
__version__ = "0.1.0"
```

---

#### Step 3 · Constants — `constants.py`

All custom span attribute keys under the `triage.*` namespace. Using constants prevents typos and enables IDE autocomplete.

**Triage context attributes (the 6 helpers):**
```
ATTR_USER_ID            = "triage.user.id"
ATTR_USER_ROLE          = "triage.user.role"
ATTR_TENANT_ID          = "triage.tenant.id"
ATTR_TENANT_NAME        = "triage.tenant.name"
ATTR_SESSION_ID         = "triage.session.id"
ATTR_SESSION_TURN       = "triage.session.turn_number"
ATTR_SESSION_HASH       = "triage.session.history_hash"
ATTR_INPUT_RAW          = "triage.input.raw"
ATTR_INPUT_SANITIZED    = "triage.input.sanitized"
ATTR_TEMPLATE_ID        = "triage.template.id"
ATTR_TEMPLATE_VERSION   = "triage.template.version"
ATTR_CHUNK_ACLS         = "triage.chunk_acls"
```

**SDK metadata attributes:**
```
ATTR_SDK_NAME           = "triage.sdk.name"
ATTR_SDK_VERSION        = "triage.sdk.version"
SDK_NAME                = "triage-sdk-python"
```

**Environment variable names:**
```
ENV_API_KEY             = "TRIAGE_API_KEY"
ENV_ENDPOINT            = "TRIAGE_ENDPOINT"
ENV_APP_NAME            = "TRIAGE_APP_NAME"
ENV_ENVIRONMENT         = "TRIAGE_ENVIRONMENT"
ENV_ENABLED             = "TRIAGE_ENABLED"
ENV_TRACE_CONTENT       = "TRIAGE_TRACE_CONTENT"
```

**Defaults:**
```
DEFAULT_ENDPOINT        = "https://api.triageai.dev"
DEFAULT_OTLP_TRACES_PATH = "/v1/traces"
```

---

#### Step 4 · Configuration — `config.py`

`TriageConfig` frozen dataclass. Constructor arguments take precedence; env vars are fallbacks; defaults are last.

```python
@dataclasses.dataclass(frozen=True)
class TriageConfig:
    api_key: str                                    # Required — TRIAGE_API_KEY
    endpoint: str                                   # Default: DEFAULT_ENDPOINT
    app_name: str                                   # Default: sys.argv[0]
    environment: str                                # Default: "development"
    enabled: bool                                   # Default: True
    trace_content: bool                             # Default: True (capture prompts/completions)
    instruments: Optional[Set[Instruments]]          # None = auto-detect all
    block_instruments: Optional[Set[Instruments]]    # None = block nothing
```

Batch size, flush interval, and queue size are **not** in our config — `BatchSpanProcessor` and `OTLPSpanExporter` handle these internally via standard OTel environment variables (`OTEL_BSP_SCHEDULE_DELAY`, `OTEL_BSP_MAX_QUEUE_SIZE`, `OTEL_BSP_MAX_EXPORT_BATCH_SIZE`). We don't wrap what we don't need to control.

**Validation:** Raise `ValueError` with clear message if `api_key` is missing (neither arg nor env var).

**Factory classmethod `TriageConfig.resolve(...)`** — merges explicit kwargs → env vars → defaults in that priority order, returns frozen instance.

---

#### Step 5 · Context Helpers — `context.py`

Uses `contextvars.ContextVar` for propagation that is both thread-safe and async-safe.

**Internal state:**

```python
@dataclasses.dataclass
class TriageContext:
    user_id: Optional[str] = None
    user_role: Optional[str] = None
    tenant_id: Optional[str] = None
    tenant_name: Optional[str] = None
    session_id: Optional[str] = None
    session_turn_number: Optional[int] = None
    session_history_hash: Optional[str] = None
    input_raw: Optional[str] = None
    input_sanitized: Optional[str] = None
    template_id: Optional[str] = None
    template_version: Optional[str] = None
    chunk_acls: Optional[str] = None  # JSON-serialized list

_triage_context: ContextVar[TriageContext] = ContextVar("triage_context", default=TriageContext())
```

**Public functions (the 6 helpers):**

```python
def set_user(user_id: str, role: str | None = None) -> None
def set_tenant(tenant_id: str, name: str | None = None) -> None
def set_session(session_id: str, turn_number: int | None = None, history_hash: str | None = None) -> None
def set_input(raw: str, sanitized: str | None = None) -> None
def set_template(template_id: str, version: str | None = None) -> None
def set_chunk_acls(acls: list[dict[str, Any]]) -> None
```

Each function:
1. Gets (or creates) the `TriageContext` from the ContextVar.
2. Updates the relevant fields (immutable replace via `dataclasses.replace`).
3. Sets the updated context back on the ContextVar.
4. Also sets attributes directly on the current span if one is active (immediate effect for already-started spans).

**Context manager for scoped annotations:**

```python
@contextmanager
def context(
    user_id: str | None = None,
    tenant_id: str | None = None,
    session_id: str | None = None,
    **kwargs,
) -> Iterator[None]:
    token = _triage_context.set(TriageContext(...))
    try:
        yield
    finally:
        _triage_context.reset(token)
```

**`get_context() -> dict[str, Any]`** — Returns a flat dict of all non-None context attributes (keyed by `constants.ATTR_*`). Used by the processor.

---

#### Step 6 · Span Processor — `processor.py`

`TriageSpanProcessor(SpanProcessor)` — bridges TriageContext into every OTel span.

```python
class TriageSpanProcessor(SpanProcessor):
    def on_start(self, span: Span, parent_context: Context | None = None) -> None:
        ctx_attrs = get_context()  # from context.py
        for key, value in ctx_attrs.items():
            span.set_attribute(key, value)

    def on_end(self, span: ReadableSpan) -> None:
        pass  # Export handled by BatchSpanProcessor + OTLPSpanExporter

    def shutdown(self) -> None:
        pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True
```

**Why a separate processor instead of setting attributes in the helpers only?**
- Auto-instrumented spans (from OpenLLMetry) start *inside* the LLM library call. The user calls `set_user()` *before* the LLM call. By the time the auto-span starts, the context is set but not yet on that span.
- The processor runs on every `span.start()`, reading the ContextVar at that moment.
- This guarantees all spans (manual and auto-instrumented) get the context annotations.

---

#### Step 7 · SDK Initialization — `sdk.py`

`TriageSDK` — singleton that orchestrates the full setup.

```python
class TriageSDK:
    _initialized: ClassVar[bool] = False

    @classmethod
    def init(
        cls,
        api_key: str | None = None,
        *,
        endpoint: str | None = None,
        app_name: str | None = None,
        environment: str | None = None,
        enabled: bool | None = None,
        trace_content: bool | None = None,
        instruments: Set[Instruments] | None = None,
        block_instruments: Set[Instruments] | None = None,
    ) -> None:
```

**init() does the following in order:**

1. Guard against double-init (log warning, return early if `_initialized`).
2. Resolve config via `TriageConfig.resolve(...)`.
3. If `not config.enabled`, log info and return (kill switch).
4. Create `OTLPSpanExporter`:
   ```python
   from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
   exporter = OTLPSpanExporter(
       endpoint=f"{config.endpoint}{DEFAULT_OTLP_TRACES_PATH}",
       headers={"Authorization": f"Bearer {config.api_key}"},
   )
   ```
5. Create `TriageSpanProcessor()`.
6. Call `Traceloop.init(...)`:
   - `app_name=config.app_name`
   - `exporter=exporter`
   - `processor=processor`
   - `resource_attributes={"triage.sdk.name": SDK_NAME, "triage.sdk.version": __version__, "triage.environment": config.environment}`
   - `instruments=config.instruments`
   - `block_instruments=config.block_instruments`
   - `disable_batch=False`
   - Set `TRACELOOP_TRACE_CONTENT` env var based on `config.trace_content`
7. Register `atexit` handler for graceful shutdown.
8. Set `_initialized = True`.

**`shutdown()`:** Force-flush the TracerProvider via `trace.get_tracer_provider().shutdown()`.

---

#### Step 8 · Public API Surface — `__init__.py`

Clean re-exports. This is the only file users import from.

```python
from triage_sdk.version import __version__
from triage_sdk.sdk import TriageSDK
from triage_sdk.config import TriageConfig
from triage_sdk.context import (
    set_user,
    set_tenant,
    set_session,
    set_input,
    set_template,
    set_chunk_acls,
    context,
)

init = TriageSDK.init
shutdown = TriageSDK.shutdown

__all__ = [
    "__version__",
    "init",
    "shutdown",
    "set_user",
    "set_tenant",
    "set_session",
    "set_input",
    "set_template",
    "set_chunk_acls",
    "context",
    "TriageConfig",
]
```

---

#### Step 9 · Backend OTLP Receiver (required for SDK to function)

The SDK sends spans via standard OTLP/HTTP. The backend needs a receiver endpoint.

**File:** `backend/src/triage/routes/traces.py`

**Endpoint:** `POST /v1/traces`

Accepts OTLP `ExportTraceServiceRequest` in both protobuf and JSON encoding, based on `Content-Type` header. Returns `ExportTraceServiceResponse`.

**New backend dependency:** `opentelemetry-proto` (provides pre-generated Python protobuf classes for OTLP messages).

**Receiver logic (~80 lines):**
```python
from opentelemetry.proto.collector.trace.v1.trace_service_pb2 import (
    ExportTraceServiceRequest,
    ExportTraceServiceResponse,
)

@router.post("/v1/traces")
async def receive_traces(request: Request, db: AsyncSession = Depends(get_db)):
    content_type = request.headers.get("content-type", "")
    body = await request.body()

    otlp_request = ExportTraceServiceRequest()
    if "application/x-protobuf" in content_type:
        otlp_request.ParseFromString(body)
    elif "application/json" in content_type:
        from google.protobuf.json_format import Parse
        Parse(body, otlp_request)

    # Walk resource_spans → scope_spans → spans
    # Transform each span into a traces table row
    # Bulk insert into PostgreSQL

    response = ExportTraceServiceResponse()
    return Response(
        content=response.SerializeToString(),
        media_type="application/x-protobuf",
    )
```

**File:** `backend/src/triage/models/db/trace.py`

SQLAlchemy ORM model mapping to the existing `traces` migration (id, session_id, timestamp, provider, model, request, response, metadata, error).

**OTLP span → `traces` row transformation:**
- `id` ← hex(trace_id) + ":" + hex(span_id)
- `session_id` ← span attribute `triage.session.id` (if present)
- `timestamp` ← `start_time_unix_nano // 1_000_000` (ns → ms)
- `provider` ← span attribute `gen_ai.system` or resource attribute `gen_ai.provider.name`
- `model` ← span attribute `gen_ai.request.model`
- `request` ← JSONB dict of request-related attributes (`gen_ai.prompt`, tool definitions, etc.)
- `response` ← JSONB dict of response-related attributes (`gen_ai.completion`, usage, finish reasons, etc.)
- `metadata` ← JSONB dict of all `triage.*` attributes + resource attributes
- `error` ← span status + error events (if status code == ERROR)

---

#### Step 10 · Tests

All tests live in `sdk/python/tests/`. Use `pytest` with `InMemorySpanExporter` from OTel SDK for capturing spans.

| Test File | What It Covers |
|-----------|---------------|
| `conftest.py` | `InMemorySpanExporter` fixture, `TracerProvider` setup, `reset_sdk()` autouse fixture |
| `test_config.py` | Arg > env > default precedence, missing api_key raises ValueError |
| `test_context.py` | Each helper sets correct ContextVar fields, `get_context()` returns flat dict, `context()` manager scopes and resets, thread isolation, async isolation |
| `test_processor.py` | `on_start` injects context attrs into span, no context = no attrs added, multiple context values propagated correctly |
| `test_sdk.py` | `init()` calls Traceloop.init with correct OTLPSpanExporter args, double-init is idempotent, shutdown cleans up, disabled config skips init |
| `test_e2e.py` | Full flow: mock OpenAI call → spans captured by InMemorySpanExporter → verify `gen_ai.*` attributes present → verify `triage.*` attributes present |

No `test_exporter.py` or `test_transport.py` — those layers are tested by the OpenTelemetry project itself.

---

#### Step 11 · Implementation Order

Execute in this order to maintain a working, testable state at each step:

| Order | File | Rationale |
|-------|------|-----------|
| 1 | `pyproject.toml` | Enables `uv sync --extra dev` — everything else needs deps |
| 2 | `version.py` | Trivial, referenced everywhere |
| 3 | `constants.py` | No deps, referenced by all other modules |
| 4 | `config.py` | Depends only on `constants.py` — testable immediately |
| 5 | `context.py` | Depends on `constants.py` — testable in isolation |
| 6 | `processor.py` | Depends on `context.py` — testable with mock spans |
| 7 | `sdk.py` | Depends on all above — integration point |
| 8 | `__init__.py` | Re-exports only — testable by importing |
| 9 | Backend endpoint | `routes/traces.py` + `models/db/trace.py` |
| 10 | `tests/` | Write tests alongside each module (steps 4-8) |
| 11 | `test_e2e.py` | After everything is wired — full integration validation |

---

### Design Decisions & Rationale

**Why OTLP instead of a custom exporter?**
See "Wire Protocol Decision" section at the top of this plan. In short: `OTLPSpanExporter` is already a transitive dependency, handles batching/retry/compression, works across all SDK languages, and lets non-SDK customers send traces with zero Triage code. Langfuse started with a custom protocol and migrated to OTLP — we skip that detour.

**Why `contextvars` + processor instead of direct span attribute calls?**
The developer sets context (e.g., `set_user()`) *before* making an LLM call. OpenLLMetry auto-creates spans *inside* the LLM call. If we only set attributes on the current span, auto-spans would miss the context. The processor runs on every `span.start()`, reading the ContextVar at that moment, guaranteeing propagation to all spans including auto-instrumented ones.

**Why not wrap OTel batch/queue config?**
`BatchSpanProcessor` already exposes configuration via standard environment variables (`OTEL_BSP_SCHEDULE_DELAY`, `OTEL_BSP_MAX_QUEUE_SIZE`, `OTEL_BSP_MAX_EXPORT_BATCH_SIZE`). Wrapping these in `TriageConfig` adds surface area without value. Power users can set the OTel env vars directly.

**Why `hatchling` build backend?**
Lightweight, PEP 621 native, no `setup.py`/`setup.cfg` needed. Used by the OTel Python SDK itself.

**Why `frozen=True` on TriageConfig?**
Config should not change after init. Frozen dataclass enforces immutability and is hashable.

### Data Flow Diagram

```
Developer's Application
    │
    ├── triage_sdk.init(api_key="tsk_...")
    │       └── Traceloop.init(exporter=OTLPSpanExporter, processor=TriageSpanProcessor)
    │              └── Auto-instruments 37 providers via monkey-patching
    │
    ├── triage_sdk.set_user(user_id="u_123")
    │       └── Stores in ContextVar (thread-safe, async-safe)
    │
    ├── openai.chat.completions.create(...)    ← OpenLLMetry intercepts this
    │       │
    │       ├── [on_start] TriageSpanProcessor reads ContextVar → sets triage.* attributes on span
    │       ├── [auto] OpenLLMetry sets gen_ai.* attributes (model, tokens, messages, etc.)
    │       ├── [on_end] BatchSpanProcessor queues span for export
    │       │
    │       └── [background thread] OTLPSpanExporter
    │               ├── Serializes spans to protobuf (ExportTraceServiceRequest)
    │               ├── POST /v1/traces with Authorization: Bearer tsk_...
    │               ├── Gzip compression, retry with backoff on 429/5xx
    │               └── Receives ExportTraceServiceResponse
    │
    v
FastAPI Backend: POST /v1/traces
    │
    ├── Parse ExportTraceServiceRequest (protobuf or JSON based on Content-Type)
    ├── Walk resource_spans → scope_spans → spans
    ├── Transform each span → traces table row
    ├── Bulk insert into PostgreSQL
    │
    v
Backend Workers (async, post-ingestion)
    ├── Embeddings, PII detection, drift scoring, groundedness
    └── Security analysis (prompt injection, cross-tenant leakage, privilege escalation)
```

### Provider Coverage

The SDK works for **all 37 OpenLLMetry-instrumented providers** with zero provider-specific code:

**LLM Providers:** OpenAI, Anthropic, Cohere, Mistral, Groq, Ollama, AWS Bedrock, AWS SageMaker, Google Vertex AI, Google Generative AI, Replicate, Together AI, IBM WatsonX, Aleph Alpha, HuggingFace Transformers, Writer, OpenAI Agents SDK

**Frameworks:** LangChain/LangGraph, LlamaIndex, Haystack, CrewAI, Agno, MCP, Voyage AI

**Vector DBs:** ChromaDB, Pinecone, Qdrant, Weaviate, Milvus, Marqo, LanceDB

**General:** Redis, PyMySQL, Requests, urllib3
