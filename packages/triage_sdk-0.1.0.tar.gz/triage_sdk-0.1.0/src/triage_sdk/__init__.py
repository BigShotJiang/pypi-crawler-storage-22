"""Triage SDK — security-focused observability for AI agents.

Usage::

    import triage_sdk

    triage_sdk.init(api_key="tsk_...", app_name="my-app")

    # Optional: annotate application context
    triage_sdk.set_user(user_id="u123", role="admin")
    triage_sdk.set_tenant(tenant_id="org_456")

    # Use any LLM provider normally — telemetry is automatic
"""

from triage_sdk.config import TriageConfig
from triage_sdk.context import (
    context,
    set_chunk_acls,
    set_input,
    set_session,
    set_template,
    set_tenant,
    set_user,
)
from triage_sdk.sdk import TriageSDK
from triage_sdk.version import __version__

init = TriageSDK.init
shutdown = TriageSDK.shutdown

__all__ = [
    "__version__",
    "init",
    "shutdown",
    "set_user",
    "set_tenant",
    "set_session",
    "set_input",
    "set_template",
    "set_chunk_acls",
    "context",
    "TriageConfig",
]
