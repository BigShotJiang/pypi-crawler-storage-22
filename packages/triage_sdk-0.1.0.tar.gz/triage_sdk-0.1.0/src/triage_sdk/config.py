"""SDK configuration with arg > env var > default precedence."""

from __future__ import annotations

import dataclasses
import os
import sys
from typing import Optional, Set

from traceloop.sdk.instruments import Instruments

from triage_sdk.constants import (
    DEFAULT_ENDPOINT,
    ENV_API_KEY,
    ENV_APP_NAME,
    ENV_ENABLED,
    ENV_ENDPOINT,
    ENV_ENVIRONMENT,
    ENV_TRACE_CONTENT,
)


@dataclasses.dataclass(frozen=True)
class TriageConfig:
    """Immutable configuration resolved from explicit args, env vars, and defaults."""

    api_key: str
    endpoint: str
    app_name: str
    environment: str
    enabled: bool
    trace_content: bool
    instruments: Optional[Set[Instruments]]
    block_instruments: Optional[Set[Instruments]]

    @classmethod
    def resolve(
        cls,
        *,
        api_key: Optional[str] = None,
        endpoint: Optional[str] = None,
        app_name: Optional[str] = None,
        environment: Optional[str] = None,
        enabled: Optional[bool] = None,
        trace_content: Optional[bool] = None,
        instruments: Optional[Set[Instruments]] = None,
        block_instruments: Optional[Set[Instruments]] = None,
    ) -> TriageConfig:
        """Merge explicit kwargs -> env vars -> defaults. Return a frozen instance."""
        resolved_api_key = api_key or os.environ.get(ENV_API_KEY, "")
        if not resolved_api_key:
            raise ValueError(
                f"Triage API key is required. Pass api_key= to init() "
                f"or set the {ENV_API_KEY} environment variable."
            )

        resolved_enabled = (
            enabled
            if enabled is not None
            else _env_bool(ENV_ENABLED, default=True)
        )

        resolved_trace_content = (
            trace_content
            if trace_content is not None
            else _env_bool(ENV_TRACE_CONTENT, default=True)
        )

        return cls(
            api_key=resolved_api_key,
            endpoint=endpoint or os.environ.get(ENV_ENDPOINT, DEFAULT_ENDPOINT),
            app_name=app_name or os.environ.get(ENV_APP_NAME, _default_app_name()),
            environment=environment or os.environ.get(ENV_ENVIRONMENT, "development"),
            enabled=resolved_enabled,
            trace_content=resolved_trace_content,
            instruments=instruments,
            block_instruments=block_instruments,
        )


def _env_bool(key: str, *, default: bool) -> bool:
    """Read a boolean from an environment variable. Accepts true/false/1/0."""
    value = os.environ.get(key)
    if value is None:
        return default
    return value.lower() in ("true", "1", "yes")


def _default_app_name() -> str:
    """Best-effort application name from sys.argv."""
    try:
        return os.path.basename(sys.argv[0]) or "unknown"
    except (AttributeError, IndexError):
        return "unknown"
