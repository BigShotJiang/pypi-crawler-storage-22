"""Span attribute keys, environment variable names, and defaults for the Triage SDK."""

# --- Triage context span attributes (the 6 developer annotation helpers) ---

ATTR_USER_ID = "triage.user.id"
ATTR_USER_ROLE = "triage.user.role"

ATTR_TENANT_ID = "triage.tenant.id"
ATTR_TENANT_NAME = "triage.tenant.name"

ATTR_SESSION_ID = "triage.session.id"
ATTR_SESSION_TURN = "triage.session.turn_number"
ATTR_SESSION_HASH = "triage.session.history_hash"

ATTR_INPUT_RAW = "triage.input.raw"
ATTR_INPUT_SANITIZED = "triage.input.sanitized"

ATTR_TEMPLATE_ID = "triage.template.id"
ATTR_TEMPLATE_VERSION = "triage.template.version"

ATTR_CHUNK_ACLS = "triage.chunk_acls"

# --- SDK metadata span attributes ---

ATTR_SDK_NAME = "triage.sdk.name"
ATTR_SDK_VERSION = "triage.sdk.version"
SDK_NAME = "triage-sdk-python"

# --- Environment variable names ---

ENV_API_KEY = "TRIAGE_API_KEY"
ENV_ENDPOINT = "TRIAGE_ENDPOINT"
ENV_APP_NAME = "TRIAGE_APP_NAME"
ENV_ENVIRONMENT = "TRIAGE_ENVIRONMENT"
ENV_ENABLED = "TRIAGE_ENABLED"
ENV_TRACE_CONTENT = "TRIAGE_TRACE_CONTENT"

# --- Defaults ---

DEFAULT_ENDPOINT = "https://api.triageai.dev"
DEFAULT_OTLP_TRACES_PATH = "/v1/traces"
