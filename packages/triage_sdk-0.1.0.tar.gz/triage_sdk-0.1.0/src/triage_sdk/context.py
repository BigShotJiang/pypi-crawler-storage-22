"""Context helpers for annotating spans with application-level metadata.

These six helpers attach data that lives above the LLM library boundary —
user identity, tenancy, sessions, input filtering, prompt templates, and
chunk ACLs — to all subsequent spans in the current execution context.

Internally, values are stored in a ``contextvars.ContextVar`` so they
propagate correctly across both threads and async tasks.  The companion
``TriageSpanProcessor`` reads this ContextVar on every ``span.start()``
to inject the attributes into auto-instrumented spans from OpenLLMetry.
"""

from __future__ import annotations

import dataclasses
import json
from contextlib import contextmanager
from contextvars import ContextVar, Token
from typing import Any, Dict, Iterator, List, Optional

from opentelemetry import trace

from triage_sdk.constants import (
    ATTR_CHUNK_ACLS,
    ATTR_INPUT_RAW,
    ATTR_INPUT_SANITIZED,
    ATTR_SESSION_HASH,
    ATTR_SESSION_ID,
    ATTR_SESSION_TURN,
    ATTR_TEMPLATE_ID,
    ATTR_TEMPLATE_VERSION,
    ATTR_TENANT_ID,
    ATTR_TENANT_NAME,
    ATTR_USER_ID,
    ATTR_USER_ROLE,
)

# ---------------------------------------------------------------------------
# Internal state
# ---------------------------------------------------------------------------


@dataclasses.dataclass
class TriageContext:
    """Holds application-level metadata to be attached to all spans in scope."""

    user_id: Optional[str] = None
    user_role: Optional[str] = None
    tenant_id: Optional[str] = None
    tenant_name: Optional[str] = None
    session_id: Optional[str] = None
    session_turn_number: Optional[int] = None
    session_history_hash: Optional[str] = None
    input_raw: Optional[str] = None
    input_sanitized: Optional[str] = None
    template_id: Optional[str] = None
    template_version: Optional[str] = None
    chunk_acls: Optional[str] = None  # JSON-serialized list


_triage_context: ContextVar[TriageContext] = ContextVar(
    "triage_context", default=TriageContext()
)

# Maps TriageContext field names → span attribute keys.
_FIELD_TO_ATTR: Dict[str, str] = {
    "user_id": ATTR_USER_ID,
    "user_role": ATTR_USER_ROLE,
    "tenant_id": ATTR_TENANT_ID,
    "tenant_name": ATTR_TENANT_NAME,
    "session_id": ATTR_SESSION_ID,
    "session_turn_number": ATTR_SESSION_TURN,
    "session_history_hash": ATTR_SESSION_HASH,
    "input_raw": ATTR_INPUT_RAW,
    "input_sanitized": ATTR_INPUT_SANITIZED,
    "template_id": ATTR_TEMPLATE_ID,
    "template_version": ATTR_TEMPLATE_VERSION,
    "chunk_acls": ATTR_CHUNK_ACLS,
}

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def get_context() -> Dict[str, Any]:
    """Return non-None context attributes as a flat ``{attr_key: value}`` dict.

    Used by ``TriageSpanProcessor`` to inject context into spans on start.
    """
    ctx = _triage_context.get()
    attrs: Dict[str, Any] = {}
    for field_name, attr_key in _FIELD_TO_ATTR.items():
        value = getattr(ctx, field_name)
        if value is not None:
            attrs[attr_key] = value
    return attrs


def _update_context(**fields: Any) -> None:
    """Merge *fields* into the current context and mirror to the active span.

    Only non-None values are written — passing ``role=None`` to ``set_user``
    leaves the existing ``user_role`` unchanged rather than clearing it.
    """
    non_none = {k: v for k, v in fields.items() if v is not None}
    if not non_none:
        return

    ctx = _triage_context.get()
    _triage_context.set(dataclasses.replace(ctx, **non_none))

    # Also set on current span for immediate effect on already-started spans.
    span = trace.get_current_span()
    if span.is_recording():
        for field_name, value in non_none.items():
            span.set_attribute(_FIELD_TO_ATTR[field_name], value)


# ---------------------------------------------------------------------------
# Public API — the 6 developer annotation helpers
# ---------------------------------------------------------------------------


def set_user(user_id: str, role: Optional[str] = None) -> None:
    """Attach user identity to all subsequent spans in this context."""
    _update_context(user_id=user_id, user_role=role)


def set_tenant(tenant_id: str, name: Optional[str] = None) -> None:
    """Attach organization/tenant identity to all subsequent spans in this context."""
    _update_context(tenant_id=tenant_id, tenant_name=name)


def set_session(
    session_id: str,
    turn_number: Optional[int] = None,
    history_hash: Optional[str] = None,
) -> None:
    """Attach conversation session metadata to all subsequent spans in this context."""
    _update_context(
        session_id=session_id,
        session_turn_number=turn_number,
        session_history_hash=history_hash,
    )


def set_input(raw: str, sanitized: Optional[str] = None) -> None:
    """Attach raw and sanitized user input to all subsequent spans in this context."""
    _update_context(input_raw=raw, input_sanitized=sanitized)


def set_template(template_id: str, version: Optional[str] = None) -> None:
    """Attach prompt template metadata to all subsequent spans in this context."""
    _update_context(template_id=template_id, template_version=version)


def set_chunk_acls(acls: List[Dict[str, Any]]) -> None:
    """Attach retrieved chunk access control metadata.

    ACLs are JSON-serialized because OTel span attributes only support
    primitive types.
    """
    _update_context(chunk_acls=json.dumps(acls))


# ---------------------------------------------------------------------------
# Scoped context manager
# ---------------------------------------------------------------------------


@contextmanager
def context(
    *,
    user_id: Optional[str] = None,
    user_role: Optional[str] = None,
    tenant_id: Optional[str] = None,
    tenant_name: Optional[str] = None,
    session_id: Optional[str] = None,
    session_turn_number: Optional[int] = None,
    session_history_hash: Optional[str] = None,
    input_raw: Optional[str] = None,
    input_sanitized: Optional[str] = None,
    template_id: Optional[str] = None,
    template_version: Optional[str] = None,
    chunk_acls: Optional[List[Dict[str, Any]]] = None,
) -> Iterator[None]:
    """Set triage context for the duration of a block, inheriting unset fields.

    On exit the previous context is restored automatically::

        triage_sdk.set_user(user_id="u1")
        with triage_sdk.context(tenant_id="t1"):
            # user_id="u1" is still visible here
            ...
        # tenant_id="t1" is no longer visible here
    """
    current = _triage_context.get()

    overrides: Dict[str, Any] = {}
    if user_id is not None:
        overrides["user_id"] = user_id
    if user_role is not None:
        overrides["user_role"] = user_role
    if tenant_id is not None:
        overrides["tenant_id"] = tenant_id
    if tenant_name is not None:
        overrides["tenant_name"] = tenant_name
    if session_id is not None:
        overrides["session_id"] = session_id
    if session_turn_number is not None:
        overrides["session_turn_number"] = session_turn_number
    if session_history_hash is not None:
        overrides["session_history_hash"] = session_history_hash
    if input_raw is not None:
        overrides["input_raw"] = input_raw
    if input_sanitized is not None:
        overrides["input_sanitized"] = input_sanitized
    if template_id is not None:
        overrides["template_id"] = template_id
    if template_version is not None:
        overrides["template_version"] = template_version
    if chunk_acls is not None:
        overrides["chunk_acls"] = json.dumps(chunk_acls)

    new_ctx = dataclasses.replace(current, **overrides)
    token: Token[TriageContext] = _triage_context.set(new_ctx)
    try:
        yield
    finally:
        _triage_context.reset(token)
