"""Span processor that injects TriageContext attributes into every span.

Auto-instrumented spans from OpenLLMetry start *inside* the LLM library
call — after the developer has already called ``set_user()`` etc.  This
processor runs on every ``span.start()``, reads the current TriageContext
from the ContextVar, and writes any non-None values as span attributes.
This guarantees that both manual and auto-instrumented spans carry the
triage annotations.
"""

from __future__ import annotations

from typing import Optional

from opentelemetry.context import Context
from opentelemetry.sdk.trace import ReadableSpan, Span, SpanProcessor

from triage_sdk.context import get_context


class TriageSpanProcessor(SpanProcessor):
    """Reads ``TriageContext`` on span start and sets ``triage.*`` attributes."""

    def on_start(self, span: Span, parent_context: Optional[Context] = None) -> None:
        ctx_attrs = get_context()
        for key, value in ctx_attrs.items():
            span.set_attribute(key, value)

    def on_end(self, span: ReadableSpan) -> None:
        pass  # Export is handled by BatchSpanProcessor + OTLPSpanExporter.

    def shutdown(self) -> None:
        pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True
