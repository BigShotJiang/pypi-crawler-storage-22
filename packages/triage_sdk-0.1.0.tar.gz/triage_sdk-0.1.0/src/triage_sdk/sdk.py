"""SDK initialization — wires Traceloop, OTLPSpanExporter, and TriageSpanProcessor."""

from __future__ import annotations

import atexit
import logging
import os
from typing import Optional, Set

from traceloop.sdk import Traceloop
from traceloop.sdk.instruments import Instruments

from triage_sdk.config import TriageConfig
from triage_sdk.constants import (
    ATTR_SDK_NAME,
    ATTR_SDK_VERSION,
    DEFAULT_OTLP_TRACES_PATH,
    SDK_NAME,
)
from triage_sdk.processor import TriageSpanProcessor
from triage_sdk.version import __version__

logger = logging.getLogger("triage_sdk")


class TriageSDK:
    """Singleton that bootstraps the full observability pipeline."""

    _initialized: bool = False

    @classmethod
    def init(
        cls,
        api_key: Optional[str] = None,
        *,
        endpoint: Optional[str] = None,
        app_name: Optional[str] = None,
        environment: Optional[str] = None,
        enabled: Optional[bool] = None,
        trace_content: Optional[bool] = None,
        instruments: Optional[Set[Instruments]] = None,
        block_instruments: Optional[Set[Instruments]] = None,
    ) -> None:
        """Initialize the Triage SDK. Safe to call once; subsequent calls are no-ops."""
        if cls._initialized:
            logger.warning("triage_sdk.init() called more than once — ignoring.")
            return

        config = TriageConfig.resolve(
            api_key=api_key,
            endpoint=endpoint,
            app_name=app_name,
            environment=environment,
            enabled=enabled,
            trace_content=trace_content,
            instruments=instruments,
            block_instruments=block_instruments,
        )

        if not config.enabled:
            logger.info("Triage SDK disabled via config — skipping initialization.")
            return

        # Control whether OpenLLMetry captures prompt/completion content.
        os.environ["TRACELOOP_TRACE_CONTENT"] = str(config.trace_content).lower()

        # Defer imports so OTel modules are only loaded when actually needed.
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
            OTLPSpanExporter,
        )
        from opentelemetry.sdk.trace.export import BatchSpanProcessor

        exporter = OTLPSpanExporter(
            endpoint=f"{config.endpoint}{DEFAULT_OTLP_TRACES_PATH}",
            headers={"Authorization": f"Bearer {config.api_key}"},
        )

        # Pass both processors as a list so Traceloop registers both:
        # 1. TriageSpanProcessor — injects triage.* context attributes on span start
        # 2. BatchSpanProcessor — batches and exports spans via OTLP
        # When a single `processor` is passed, Traceloop ignores the `exporter` param.
        processors = [TriageSpanProcessor(), BatchSpanProcessor(exporter)]

        Traceloop.init(
            app_name=config.app_name,
            processor=processors,
            resource_attributes={
                ATTR_SDK_NAME: SDK_NAME,
                ATTR_SDK_VERSION: __version__,
                "triage.environment": config.environment,
            },
            instruments=config.instruments,
            block_instruments=config.block_instruments,
            disable_batch=False,
            telemetry_enabled=False,
        )

        atexit.register(cls.shutdown)
        cls._initialized = True
        logger.info(
            "Triage SDK initialized (app=%s, env=%s, endpoint=%s)",
            config.app_name,
            config.environment,
            config.endpoint,
        )

    @classmethod
    def shutdown(cls) -> None:
        """Flush pending spans and release resources. Safe to call multiple times."""
        if not cls._initialized:
            return

        from opentelemetry import trace

        provider = trace.get_tracer_provider()
        if hasattr(provider, "force_flush"):
            provider.force_flush()
        if hasattr(provider, "shutdown"):
            provider.shutdown()

        cls._initialized = False
        logger.debug("Triage SDK shut down.")
