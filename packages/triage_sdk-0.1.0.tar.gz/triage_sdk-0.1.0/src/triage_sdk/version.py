"""Single-source version for the triage-sdk package."""

__version__ = "0.1.0"
