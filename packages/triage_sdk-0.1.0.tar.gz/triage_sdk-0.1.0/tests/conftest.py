"""Shared fixtures for triage_sdk tests."""

from __future__ import annotations

import pytest
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

from triage_sdk.context import TriageContext, _triage_context
from triage_sdk.processor import TriageSpanProcessor
from triage_sdk.sdk import TriageSDK


@pytest.fixture(autouse=True)
def _reset_context():
    """Reset TriageContext between tests to prevent leakage."""
    _triage_context.set(TriageContext())
    yield
    _triage_context.set(TriageContext())


@pytest.fixture(autouse=True)
def _reset_sdk():
    """Reset TriageSDK singleton state between tests."""
    TriageSDK._initialized = False
    yield
    TriageSDK._initialized = False


@pytest.fixture()
def memory_exporter() -> InMemorySpanExporter:
    """An in-memory span exporter for capturing spans in tests."""
    return InMemorySpanExporter()


@pytest.fixture()
def tracer_provider(memory_exporter: InMemorySpanExporter) -> TracerProvider:
    """TracerProvider wired with TriageSpanProcessor + InMemorySpanExporter."""
    provider = TracerProvider()
    provider.add_span_processor(TriageSpanProcessor())
    provider.add_span_processor(SimpleSpanProcessor(memory_exporter))
    return provider
