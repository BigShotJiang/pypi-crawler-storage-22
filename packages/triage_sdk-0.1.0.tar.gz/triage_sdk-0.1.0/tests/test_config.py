"""Tests for TriageConfig resolution (arg > env > default precedence)."""

from __future__ import annotations

import os

import pytest
from traceloop.sdk.instruments import Instruments

from triage_sdk.config import TriageConfig
from triage_sdk.constants import (
    DEFAULT_ENDPOINT,
    ENV_API_KEY,
    ENV_APP_NAME,
    ENV_ENABLED,
    ENV_ENDPOINT,
    ENV_ENVIRONMENT,
    ENV_TRACE_CONTENT,
)


class TestApiKeyResolution:
    def test_explicit_arg(self):
        cfg = TriageConfig.resolve(api_key="tsk_explicit")
        assert cfg.api_key == "tsk_explicit"

    def test_env_var_fallback(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv(ENV_API_KEY, "tsk_from_env")
        cfg = TriageConfig.resolve()
        assert cfg.api_key == "tsk_from_env"

    def test_arg_beats_env(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv(ENV_API_KEY, "tsk_env")
        cfg = TriageConfig.resolve(api_key="tsk_arg")
        assert cfg.api_key == "tsk_arg"

    def test_missing_raises(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.delenv(ENV_API_KEY, raising=False)
        with pytest.raises(ValueError, match="Triage API key is required"):
            TriageConfig.resolve()

    def test_empty_string_raises(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.delenv(ENV_API_KEY, raising=False)
        with pytest.raises(ValueError, match="Triage API key is required"):
            TriageConfig.resolve(api_key="")


class TestEndpointResolution:
    def test_default(self):
        cfg = TriageConfig.resolve(api_key="k")
        assert cfg.endpoint == DEFAULT_ENDPOINT

    def test_explicit_arg(self):
        cfg = TriageConfig.resolve(api_key="k", endpoint="https://custom.io")
        assert cfg.endpoint == "https://custom.io"

    def test_env_fallback(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv(ENV_ENDPOINT, "https://env.io")
        cfg = TriageConfig.resolve(api_key="k")
        assert cfg.endpoint == "https://env.io"

    def test_arg_beats_env(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv(ENV_ENDPOINT, "https://env.io")
        cfg = TriageConfig.resolve(api_key="k", endpoint="https://arg.io")
        assert cfg.endpoint == "https://arg.io"


class TestAppNameResolution:
    def test_explicit_arg(self):
        cfg = TriageConfig.resolve(api_key="k", app_name="my-app")
        assert cfg.app_name == "my-app"

    def test_env_fallback(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv(ENV_APP_NAME, "env-app")
        cfg = TriageConfig.resolve(api_key="k")
        assert cfg.app_name == "env-app"

    def test_default_from_argv(self):
        cfg = TriageConfig.resolve(api_key="k")
        # Should be some non-empty string derived from sys.argv[0].
        assert isinstance(cfg.app_name, str)
        assert len(cfg.app_name) > 0


class TestEnvironmentResolution:
    def test_default(self):
        cfg = TriageConfig.resolve(api_key="k")
        assert cfg.environment == "development"

    def test_explicit_arg(self):
        cfg = TriageConfig.resolve(api_key="k", environment="production")
        assert cfg.environment == "production"

    def test_env_fallback(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv(ENV_ENVIRONMENT, "staging")
        cfg = TriageConfig.resolve(api_key="k")
        assert cfg.environment == "staging"


class TestBooleanFields:
    @pytest.mark.parametrize("env_val,expected", [
        ("true", True),
        ("True", True),
        ("1", True),
        ("yes", True),
        ("false", False),
        ("0", False),
        ("no", False),
    ])
    def test_enabled_env_values(
        self, monkeypatch: pytest.MonkeyPatch, env_val: str, expected: bool
    ):
        monkeypatch.setenv(ENV_ENABLED, env_val)
        cfg = TriageConfig.resolve(api_key="k")
        assert cfg.enabled is expected

    def test_enabled_default_is_true(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.delenv(ENV_ENABLED, raising=False)
        cfg = TriageConfig.resolve(api_key="k")
        assert cfg.enabled is True

    def test_enabled_explicit_overrides_env(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv(ENV_ENABLED, "true")
        cfg = TriageConfig.resolve(api_key="k", enabled=False)
        assert cfg.enabled is False

    @pytest.mark.parametrize("env_val,expected", [
        ("true", True),
        ("false", False),
    ])
    def test_trace_content_env_values(
        self, monkeypatch: pytest.MonkeyPatch, env_val: str, expected: bool
    ):
        monkeypatch.setenv(ENV_TRACE_CONTENT, env_val)
        cfg = TriageConfig.resolve(api_key="k")
        assert cfg.trace_content is expected

    def test_trace_content_default_is_true(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.delenv(ENV_TRACE_CONTENT, raising=False)
        cfg = TriageConfig.resolve(api_key="k")
        assert cfg.trace_content is True


class TestInstruments:
    def test_instruments_passthrough(self):
        instruments = {Instruments.OPENAI, Instruments.ANTHROPIC}
        cfg = TriageConfig.resolve(api_key="k", instruments=instruments)
        assert cfg.instruments == instruments

    def test_block_instruments_passthrough(self):
        blocked = {Instruments.LANGCHAIN}
        cfg = TriageConfig.resolve(api_key="k", block_instruments=blocked)
        assert cfg.block_instruments == blocked

    def test_default_is_none(self):
        cfg = TriageConfig.resolve(api_key="k")
        assert cfg.instruments is None
        assert cfg.block_instruments is None


class TestImmutability:
    def test_frozen(self):
        cfg = TriageConfig.resolve(api_key="k")
        with pytest.raises(AttributeError):
            cfg.api_key = "changed"  # type: ignore[misc]
