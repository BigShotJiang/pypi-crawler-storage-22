"""Tests for context helpers and ContextVar propagation."""

from __future__ import annotations

import json

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider

from triage_sdk.constants import (
    ATTR_CHUNK_ACLS,
    ATTR_INPUT_RAW,
    ATTR_INPUT_SANITIZED,
    ATTR_SESSION_HASH,
    ATTR_SESSION_ID,
    ATTR_SESSION_TURN,
    ATTR_TEMPLATE_ID,
    ATTR_TEMPLATE_VERSION,
    ATTR_TENANT_ID,
    ATTR_TENANT_NAME,
    ATTR_USER_ID,
    ATTR_USER_ROLE,
)
from triage_sdk.context import (
    context,
    get_context,
    set_chunk_acls,
    set_input,
    set_session,
    set_template,
    set_tenant,
    set_user,
)


class TestSetUser:
    def test_sets_user_id(self):
        set_user(user_id="u1")
        assert get_context()[ATTR_USER_ID] == "u1"

    def test_sets_role(self):
        set_user(user_id="u1", role="admin")
        ctx = get_context()
        assert ctx[ATTR_USER_ID] == "u1"
        assert ctx[ATTR_USER_ROLE] == "admin"

    def test_omitted_role_does_not_overwrite(self):
        set_user(user_id="u1", role="admin")
        set_user(user_id="u2")  # role=None — should not clear "admin"
        ctx = get_context()
        assert ctx[ATTR_USER_ID] == "u2"
        assert ctx[ATTR_USER_ROLE] == "admin"


class TestSetTenant:
    def test_sets_tenant_id(self):
        set_tenant(tenant_id="org_1")
        assert get_context()[ATTR_TENANT_ID] == "org_1"

    def test_sets_name(self):
        set_tenant(tenant_id="org_1", name="Acme")
        ctx = get_context()
        assert ctx[ATTR_TENANT_ID] == "org_1"
        assert ctx[ATTR_TENANT_NAME] == "Acme"


class TestSetSession:
    def test_sets_session_id(self):
        set_session(session_id="s1")
        assert get_context()[ATTR_SESSION_ID] == "s1"

    def test_sets_turn_and_hash(self):
        set_session(session_id="s1", turn_number=3, history_hash="abc123")
        ctx = get_context()
        assert ctx[ATTR_SESSION_TURN] == 3
        assert ctx[ATTR_SESSION_HASH] == "abc123"

    def test_omitted_optionals_do_not_overwrite(self):
        set_session(session_id="s1", turn_number=1)
        set_session(session_id="s2")  # turn_number=None
        ctx = get_context()
        assert ctx[ATTR_SESSION_ID] == "s2"
        assert ctx[ATTR_SESSION_TURN] == 1


class TestSetInput:
    def test_sets_raw(self):
        set_input(raw="hello <script>")
        assert get_context()[ATTR_INPUT_RAW] == "hello <script>"

    def test_sets_sanitized(self):
        set_input(raw="hello <script>", sanitized="hello")
        ctx = get_context()
        assert ctx[ATTR_INPUT_RAW] == "hello <script>"
        assert ctx[ATTR_INPUT_SANITIZED] == "hello"


class TestSetTemplate:
    def test_sets_template_id(self):
        set_template(template_id="tmpl_1")
        assert get_context()[ATTR_TEMPLATE_ID] == "tmpl_1"

    def test_sets_version(self):
        set_template(template_id="tmpl_1", version="v2.1")
        ctx = get_context()
        assert ctx[ATTR_TEMPLATE_ID] == "tmpl_1"
        assert ctx[ATTR_TEMPLATE_VERSION] == "v2.1"


class TestSetChunkAcls:
    def test_json_serialized(self):
        acls = [{"chunk_id": "c1", "acl": ["role:admin"]}]
        set_chunk_acls(acls)
        raw = get_context()[ATTR_CHUNK_ACLS]
        assert json.loads(raw) == acls


class TestGetContext:
    def test_empty_when_nothing_set(self):
        assert get_context() == {}

    def test_returns_only_non_none(self):
        set_user(user_id="u1")
        ctx = get_context()
        assert ATTR_USER_ID in ctx
        assert ATTR_USER_ROLE not in ctx  # was not set

    def test_multiple_helpers_merge(self):
        set_user(user_id="u1")
        set_tenant(tenant_id="org_1")
        ctx = get_context()
        assert ctx[ATTR_USER_ID] == "u1"
        assert ctx[ATTR_TENANT_ID] == "org_1"


class TestContextManager:
    def test_inherits_parent_values(self):
        set_user(user_id="u1")
        with context(tenant_id="org_1"):
            ctx = get_context()
            assert ctx[ATTR_USER_ID] == "u1"  # inherited
            assert ctx[ATTR_TENANT_ID] == "org_1"  # set by manager

    def test_restores_on_exit(self):
        set_tenant(tenant_id="org_1")
        with context(tenant_id="org_override"):
            assert get_context()[ATTR_TENANT_ID] == "org_override"
        assert get_context()[ATTR_TENANT_ID] == "org_1"

    def test_override_does_not_leak(self):
        with context(user_id="u_scoped"):
            assert get_context()[ATTR_USER_ID] == "u_scoped"
        assert ATTR_USER_ID not in get_context()

    def test_nested_managers(self):
        with context(user_id="u1"):
            with context(tenant_id="org_1"):
                ctx = get_context()
                assert ctx[ATTR_USER_ID] == "u1"
                assert ctx[ATTR_TENANT_ID] == "org_1"
            # tenant gone, user still present
            ctx = get_context()
            assert ctx[ATTR_USER_ID] == "u1"
            assert ATTR_TENANT_ID not in ctx


class TestActiveSpanIntegration:
    def test_helper_sets_attribute_on_current_span(
        self, tracer_provider: TracerProvider
    ):
        tracer = tracer_provider.get_tracer("test")
        with tracer.start_as_current_span("test-span") as span:
            set_user(user_id="u1", role="admin")
            # The helper should set on the active span immediately.
        # After the span ends we can't read attributes from the Span object
        # directly, but the processor test covers the export path.
        # Here we verify no exceptions were raised.
