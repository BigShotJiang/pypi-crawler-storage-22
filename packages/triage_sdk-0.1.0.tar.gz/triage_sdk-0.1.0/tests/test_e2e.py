"""End-to-end tests — real OTel components, no mocks.

Verifies the full data flow:
  context helpers → TriageSpanProcessor → span attributes captured by InMemorySpanExporter
"""

from __future__ import annotations

import json

from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

from triage_sdk.constants import (
    ATTR_CHUNK_ACLS,
    ATTR_INPUT_RAW,
    ATTR_INPUT_SANITIZED,
    ATTR_SESSION_HASH,
    ATTR_SESSION_ID,
    ATTR_SESSION_TURN,
    ATTR_TEMPLATE_ID,
    ATTR_TEMPLATE_VERSION,
    ATTR_TENANT_ID,
    ATTR_TENANT_NAME,
    ATTR_USER_ID,
    ATTR_USER_ROLE,
)
from triage_sdk.context import (
    context,
    set_chunk_acls,
    set_input,
    set_session,
    set_template,
    set_tenant,
    set_user,
)


class TestFullAnnotationFlow:
    """Set all 6 helpers, create a span, verify everything lands on the exported span."""

    def test_all_helpers(
        self,
        tracer_provider: TracerProvider,
        memory_exporter: InMemorySpanExporter,
    ):
        tracer = tracer_provider.get_tracer("test")

        set_user(user_id="u_42", role="admin")
        set_tenant(tenant_id="org_7", name="Acme Corp")
        set_session(session_id="sess_1", turn_number=3, history_hash="sha256abc")
        set_input(raw="drop table users;", sanitized="drop table users")
        set_template(template_id="tmpl_chat", version="v2.1")
        set_chunk_acls([{"chunk_id": "c1", "acl": ["role:admin"]}])

        with tracer.start_as_current_span("chat gpt-4o"):
            pass

        spans = memory_exporter.get_finished_spans()
        assert len(spans) == 1
        attrs = dict(spans[0].attributes)

        assert attrs[ATTR_USER_ID] == "u_42"
        assert attrs[ATTR_USER_ROLE] == "admin"
        assert attrs[ATTR_TENANT_ID] == "org_7"
        assert attrs[ATTR_TENANT_NAME] == "Acme Corp"
        assert attrs[ATTR_SESSION_ID] == "sess_1"
        assert attrs[ATTR_SESSION_TURN] == 3
        assert attrs[ATTR_SESSION_HASH] == "sha256abc"
        assert attrs[ATTR_INPUT_RAW] == "drop table users;"
        assert attrs[ATTR_INPUT_SANITIZED] == "drop table users"
        assert attrs[ATTR_TEMPLATE_ID] == "tmpl_chat"
        assert attrs[ATTR_TEMPLATE_VERSION] == "v2.1"
        assert json.loads(attrs[ATTR_CHUNK_ACLS]) == [
            {"chunk_id": "c1", "acl": ["role:admin"]}
        ]


class TestContextManagerScoping:
    """Verify context() manager correctly scopes attributes to the block."""

    def test_attributes_present_inside_gone_outside(
        self,
        tracer_provider: TracerProvider,
        memory_exporter: InMemorySpanExporter,
    ):
        tracer = tracer_provider.get_tracer("test")

        with context(user_id="u_scoped", tenant_id="org_scoped"):
            with tracer.start_as_current_span("inside"):
                pass

        with tracer.start_as_current_span("outside"):
            pass

        spans = memory_exporter.get_finished_spans()
        assert len(spans) == 2

        inside_attrs = dict(spans[0].attributes)
        assert inside_attrs[ATTR_USER_ID] == "u_scoped"
        assert inside_attrs[ATTR_TENANT_ID] == "org_scoped"

        outside_attrs = dict(spans[1].attributes)
        assert ATTR_USER_ID not in outside_attrs
        assert ATTR_TENANT_ID not in outside_attrs


class TestTriageAndGenAiCoexist:
    """Verify triage.* attributes coexist with manually-set gen_ai.* attributes."""

    def test_both_namespaces_on_same_span(
        self,
        tracer_provider: TracerProvider,
        memory_exporter: InMemorySpanExporter,
    ):
        tracer = tracer_provider.get_tracer("test")

        set_user(user_id="u1")

        with tracer.start_as_current_span("chat gpt-4o") as span:
            # Simulate what OpenLLMetry auto-instrumentation would set.
            span.set_attribute("gen_ai.system", "openai")
            span.set_attribute("gen_ai.request.model", "gpt-4o")
            span.set_attribute("gen_ai.usage.input_tokens", 150)
            span.set_attribute("gen_ai.usage.output_tokens", 42)

        spans = memory_exporter.get_finished_spans()
        attrs = dict(spans[0].attributes)

        # Triage attributes present.
        assert attrs[ATTR_USER_ID] == "u1"
        # gen_ai attributes also present.
        assert attrs["gen_ai.system"] == "openai"
        assert attrs["gen_ai.request.model"] == "gpt-4o"
        assert attrs["gen_ai.usage.input_tokens"] == 150
        assert attrs["gen_ai.usage.output_tokens"] == 42


class TestMultiSpanTrace:
    """Verify each span in a trace gets the context at its creation time."""

    def test_parent_and_child_spans(
        self,
        tracer_provider: TracerProvider,
        memory_exporter: InMemorySpanExporter,
    ):
        tracer = tracer_provider.get_tracer("test")

        set_user(user_id="u1")
        set_session(session_id="sess_1", turn_number=1)

        with tracer.start_as_current_span("workflow"):
            with tracer.start_as_current_span("llm-call"):
                pass
            with tracer.start_as_current_span("tool-call"):
                pass

        spans = memory_exporter.get_finished_spans()
        assert len(spans) == 3  # llm-call, tool-call, workflow (LIFO order)

        for span in spans:
            attrs = dict(span.attributes)
            assert attrs[ATTR_USER_ID] == "u1"
            assert attrs[ATTR_SESSION_ID] == "sess_1"
            assert attrs[ATTR_SESSION_TURN] == 1

    def test_context_change_between_child_spans(
        self,
        tracer_provider: TracerProvider,
        memory_exporter: InMemorySpanExporter,
    ):
        tracer = tracer_provider.get_tracer("test")

        set_session(session_id="sess_1", turn_number=1)

        with tracer.start_as_current_span("workflow"):
            with tracer.start_as_current_span("turn-1"):
                pass

            set_session(session_id="sess_1", turn_number=2)

            with tracer.start_as_current_span("turn-2"):
                pass

        spans = memory_exporter.get_finished_spans()
        # Spans end in LIFO order: turn-1, turn-2, workflow
        span_map = {s.name: dict(s.attributes) for s in spans}

        assert span_map["turn-1"][ATTR_SESSION_TURN] == 1
        assert span_map["turn-2"][ATTR_SESSION_TURN] == 2
