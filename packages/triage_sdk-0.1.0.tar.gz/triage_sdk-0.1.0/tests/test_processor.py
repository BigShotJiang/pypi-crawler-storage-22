"""Tests for TriageSpanProcessor — verifies context injection into real spans."""

from __future__ import annotations

from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

from triage_sdk.constants import (
    ATTR_SESSION_ID,
    ATTR_TENANT_ID,
    ATTR_USER_ID,
    ATTR_USER_ROLE,
)
from triage_sdk.context import set_session, set_tenant, set_user


class TestTriageSpanProcessor:
    def test_context_injected_into_span(
        self,
        tracer_provider: TracerProvider,
        memory_exporter: InMemorySpanExporter,
    ):
        tracer = tracer_provider.get_tracer("test")

        set_user(user_id="u1", role="admin")
        set_tenant(tenant_id="org_1")

        with tracer.start_as_current_span("llm-call"):
            pass

        spans = memory_exporter.get_finished_spans()
        assert len(spans) == 1
        attrs = dict(spans[0].attributes)
        assert attrs[ATTR_USER_ID] == "u1"
        assert attrs[ATTR_USER_ROLE] == "admin"
        assert attrs[ATTR_TENANT_ID] == "org_1"

    def test_no_context_means_no_triage_attrs(
        self,
        tracer_provider: TracerProvider,
        memory_exporter: InMemorySpanExporter,
    ):
        tracer = tracer_provider.get_tracer("test")

        with tracer.start_as_current_span("clean-span"):
            pass

        spans = memory_exporter.get_finished_spans()
        assert len(spans) == 1
        triage_keys = [k for k in spans[0].attributes if k.startswith("triage.")]
        assert triage_keys == []

    def test_different_context_per_span(
        self,
        tracer_provider: TracerProvider,
        memory_exporter: InMemorySpanExporter,
    ):
        tracer = tracer_provider.get_tracer("test")

        set_user(user_id="u1")
        with tracer.start_as_current_span("span-1"):
            pass

        set_user(user_id="u2")
        with tracer.start_as_current_span("span-2"):
            pass

        spans = memory_exporter.get_finished_spans()
        assert len(spans) == 2
        assert dict(spans[0].attributes)[ATTR_USER_ID] == "u1"
        assert dict(spans[1].attributes)[ATTR_USER_ID] == "u2"

    def test_multiple_fields(
        self,
        tracer_provider: TracerProvider,
        memory_exporter: InMemorySpanExporter,
    ):
        tracer = tracer_provider.get_tracer("test")

        set_user(user_id="u1", role="viewer")
        set_tenant(tenant_id="org_5")
        set_session(session_id="sess_9")

        with tracer.start_as_current_span("multi"):
            pass

        spans = memory_exporter.get_finished_spans()
        attrs = dict(spans[0].attributes)
        assert attrs[ATTR_USER_ID] == "u1"
        assert attrs[ATTR_USER_ROLE] == "viewer"
        assert attrs[ATTR_TENANT_ID] == "org_5"
        assert attrs[ATTR_SESSION_ID] == "sess_9"
