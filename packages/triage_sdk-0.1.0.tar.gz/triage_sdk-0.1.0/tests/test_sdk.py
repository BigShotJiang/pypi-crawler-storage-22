"""Tests for TriageSDK.init() wiring and lifecycle."""

from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

import pytest

from triage_sdk.constants import (
    ATTR_SDK_NAME,
    ATTR_SDK_VERSION,
    DEFAULT_ENDPOINT,
    DEFAULT_OTLP_TRACES_PATH,
    SDK_NAME,
)
from triage_sdk.processor import TriageSpanProcessor
from triage_sdk.sdk import TriageSDK
from triage_sdk.version import __version__

# Patch targets: the actual module where each name is imported from at call time.
_OTLP_EXPORTER = "opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter"
_TRACELOOP = "triage_sdk.sdk.Traceloop"


class TestInit:
    @patch(_TRACELOOP)
    @patch(_OTLP_EXPORTER)
    def test_passes_correct_endpoint(self, mock_exporter_cls, mock_traceloop):
        TriageSDK.init(api_key="tsk_test", endpoint="https://custom.io")

        call_kwargs = mock_exporter_cls.call_args[1]
        assert call_kwargs["endpoint"] == f"https://custom.io{DEFAULT_OTLP_TRACES_PATH}"

    @patch(_TRACELOOP)
    @patch(_OTLP_EXPORTER)
    def test_passes_auth_header(self, mock_exporter_cls, mock_traceloop):
        TriageSDK.init(api_key="tsk_secret")

        call_kwargs = mock_exporter_cls.call_args[1]
        assert call_kwargs["headers"] == {"Authorization": "Bearer tsk_secret"}

    @patch(_TRACELOOP)
    @patch(_OTLP_EXPORTER)
    def test_passes_default_endpoint(self, mock_exporter_cls, mock_traceloop):
        TriageSDK.init(api_key="tsk_test")

        call_kwargs = mock_exporter_cls.call_args[1]
        assert call_kwargs["endpoint"] == f"{DEFAULT_ENDPOINT}{DEFAULT_OTLP_TRACES_PATH}"

    @patch(_TRACELOOP)
    @patch(_OTLP_EXPORTER)
    def test_passes_resource_attributes(self, mock_exporter_cls, mock_traceloop):
        TriageSDK.init(api_key="tsk_test", environment="staging")

        traceloop_init_kwargs = mock_traceloop.init.call_args[1]
        resource_attrs = traceloop_init_kwargs["resource_attributes"]
        assert resource_attrs[ATTR_SDK_NAME] == SDK_NAME
        assert resource_attrs[ATTR_SDK_VERSION] == __version__
        assert resource_attrs["triage.environment"] == "staging"

    @patch(_TRACELOOP)
    @patch(_OTLP_EXPORTER)
    def test_passes_processor(self, mock_exporter_cls, mock_traceloop):
        TriageSDK.init(api_key="tsk_test")

        traceloop_init_kwargs = mock_traceloop.init.call_args[1]
        assert isinstance(traceloop_init_kwargs["processor"], TriageSpanProcessor)

    @patch(_TRACELOOP)
    @patch(_OTLP_EXPORTER)
    def test_passes_app_name(self, mock_exporter_cls, mock_traceloop):
        TriageSDK.init(api_key="tsk_test", app_name="my-service")

        traceloop_init_kwargs = mock_traceloop.init.call_args[1]
        assert traceloop_init_kwargs["app_name"] == "my-service"


class TestDoubleInit:
    @patch(_TRACELOOP)
    @patch(_OTLP_EXPORTER)
    def test_second_call_is_noop(self, mock_exporter_cls, mock_traceloop):
        TriageSDK.init(api_key="tsk_test")
        mock_traceloop.init.reset_mock()

        TriageSDK.init(api_key="tsk_test")  # second call
        mock_traceloop.init.assert_not_called()

    @patch(_TRACELOOP)
    @patch(_OTLP_EXPORTER)
    def test_second_call_logs_warning(self, mock_exporter_cls, mock_traceloop, caplog):
        TriageSDK.init(api_key="tsk_test")

        with caplog.at_level("WARNING", logger="triage_sdk"):
            TriageSDK.init(api_key="tsk_test")

        assert "called more than once" in caplog.text


class TestDisabled:
    @patch(_TRACELOOP)
    def test_enabled_false_skips_init(self, mock_traceloop):
        TriageSDK.init(api_key="tsk_test", enabled=False)

        mock_traceloop.init.assert_not_called()
        assert TriageSDK._initialized is False


class TestTraceContent:
    @patch(_TRACELOOP)
    @patch(_OTLP_EXPORTER)
    def test_trace_content_false_sets_env(self, mock_exporter_cls, mock_traceloop):
        TriageSDK.init(api_key="tsk_test", trace_content=False)
        assert os.environ.get("TRACELOOP_TRACE_CONTENT") == "false"

    @patch(_TRACELOOP)
    @patch(_OTLP_EXPORTER)
    def test_trace_content_true_sets_env(self, mock_exporter_cls, mock_traceloop):
        TriageSDK.init(api_key="tsk_test", trace_content=True)
        assert os.environ.get("TRACELOOP_TRACE_CONTENT") == "true"


class TestShutdown:
    def test_shutdown_when_not_initialized_is_noop(self):
        TriageSDK._initialized = False
        TriageSDK.shutdown()  # should not raise

    @patch(_TRACELOOP)
    @patch(_OTLP_EXPORTER)
    def test_shutdown_resets_initialized(self, mock_exporter_cls, mock_traceloop):
        TriageSDK.init(api_key="tsk_test")
        assert TriageSDK._initialized is True

        TriageSDK.shutdown()
        assert TriageSDK._initialized is False
