import unittest
from tricc_oo.models.base import (
    TriccOperator, TriccOperation, TriccStatic, TriccReference,
    clean_and_list, not_clean
)


class TestCleanAndList(unittest.TestCase):

    def test_empty_list(self):
        """Test with empty list"""
        result = clean_and_list([])
        self.assertEqual(result, [])

    def test_single_true(self):
        """Test single TRUE is removed"""
        result = clean_and_list([TriccStatic(True)])
        self.assertEqual(result, [])

    def test_single_false(self):
        """Test single FALSE returns [FALSE]"""
        result = clean_and_list([TriccStatic(False)])
        self.assertEqual(result, [TriccStatic(False)])

    def test_mixed_true_false(self):
        """Test TRUE and FALSE returns [FALSE]"""
        result = clean_and_list([TriccStatic(True), TriccStatic(False)])
        self.assertEqual(result, [TriccStatic(False)])

    def test_and_flattening(self):
        """Test AND operations are flattened"""
        a = TriccReference("a")
        b = TriccReference("b")
        c = TriccReference("c")
        and_op = TriccOperation(TriccOperator.AND, [a, b])
        result = clean_and_list([and_op, c])
        expected = sorted([a, b, c], key=str)
        self.assertEqual(result, expected)

    def test_nested_and_flattening(self):
        """Test nested AND operations are flattened"""
        a = TriccReference("a")
        b = TriccReference("b")
        c = TriccReference("c")
        d = TriccReference("d")
        inner_and = TriccOperation(TriccOperator.AND, [a, b])
        outer_and = TriccOperation(TriccOperator.AND, [inner_and, c])
        result = clean_and_list([outer_and, d])
        expected = sorted([a, b, c, d], key=str)
        self.assertEqual(result, expected)

    def test_contradiction_detection_exists(self):
        """Test EXISTS(a) and NOTEXISTS(a) returns [FALSE]"""
        a = TriccReference("a")
        exists_a = TriccOperation(TriccOperator.EXISTS, [a])
        not_exists_a = TriccOperation(TriccOperator.NOTEXISTS, [a])
        result = clean_and_list([exists_a, not_exists_a])
        self.assertEqual(result, [TriccStatic(False)])

    def test_contradiction_detection_boolean_ops(self):
        """Test boolean operation and its negation returns [FALSE]"""
        a = TriccReference("a")
        is_true_a = TriccOperation(TriccOperator.ISTRUE, [a])
        is_false_a = TriccOperation(TriccOperator.ISFALSE, [a])
        result = clean_and_list([is_true_a, is_false_a])
        self.assertEqual(result, [TriccStatic(False)])

    def test_remove_trues(self):
        """Test TRUE values are removed"""
        a = TriccReference("a")
        b = TriccReference("b")
        result = clean_and_list([a, TriccStatic(True), b])
        expected = sorted([a, b], key=str)
        self.assertEqual(result, expected)

    def test_not_and_optimization_simple(self):
        """Test NOT(AND(a, b)) with a present removes a from AND"""
        a = TriccReference("a")
        b = TriccReference("b")
        not_and = TriccOperation(TriccOperator.NOT, [
            TriccOperation(TriccOperator.AND, [a, b])
        ])
        result = clean_and_list([a, not_and])
        # Should simplify NOT(AND(b)) which is equivalent to OR(NOT(b))
        # But let's see what the current logic does
        expected = sorted([a, not_and], key=str)
        self.assertEqual(result, expected)

    def test_basic_uniqueness(self):
        """Test duplicate elements are removed"""
        a = TriccReference("a")
        result = clean_and_list([a, a, a])
        self.assertEqual(result, [a])

    def test_mixed_types(self):
        """Test with mixed reference and static types"""
        ref = TriccReference("test")
        static = TriccStatic("value")
        result = clean_and_list([ref, static, TriccStatic(True)])
        expected = sorted([ref, static], key=str)
        self.assertEqual(result, expected)

    def test_false_with_others(self):
        """Test FALSE with other elements returns [FALSE]"""
        a = TriccReference("a")
        b = TriccReference("b")
        result = clean_and_list([a, TriccStatic(False), b])
        self.assertEqual(result, [TriccStatic(False)])

    def test_only_trues(self):
        """Test list of only TRUEs returns empty"""
        result = clean_and_list([TriccStatic(True), TriccStatic(True)])
        self.assertEqual(result, [])

    def test_complex_and_flattening(self):
        """Test complex AND flattening with TRUEs and duplicates"""
        a = TriccReference("a")
        b = TriccReference("b")
        c = TriccReference("c")
        and_op = TriccOperation(TriccOperator.AND, [a, TriccStatic(True), b])
        result = clean_and_list([and_op, c, TriccStatic(True)])
        expected = sorted([a, b, c], key=str)
        self.assertEqual(result, expected)


if __name__ == "__main__":
    unittest.main()