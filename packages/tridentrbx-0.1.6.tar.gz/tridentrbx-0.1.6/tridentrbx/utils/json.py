import json

def formatjson(data: dict) -> str:
    return json.dumps(data, indent=2, ensure_ascii=False) if data else "None"