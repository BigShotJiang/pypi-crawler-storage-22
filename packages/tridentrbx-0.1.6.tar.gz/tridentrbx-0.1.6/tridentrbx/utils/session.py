import requests

sesh = requests.Session()
timeout = 5