import requests
from tridentrbx.utils.json import formatjson
from tridentrbx.utils.session import sesh, timeout

def getfriendcount() -> str | None:
    try:
        r = sesh.get("https://friends.roblox.com/v1/my/friends/count", timeout=timeout)
    except requests.RequestException:
        return None
    if r.status_code == 200:
        return formatjson(r.json())
    return None

def getfriendrequests(limit: int = 10, cursor: str = None, friendrequestsort: int = 1) -> str | None:
    params = {"limit": limit, "friendRequestSort": friendrequestsort}
    if cursor:
        params["cursor"] = cursor
    try:
        r = sesh.get("https://friends.roblox.com/v1/my/friends/requests", params=params, timeout=timeout)
    except requests.RequestException:
        return None
    if r.status_code == 200:
        return formatjson(r.json())
    return None

def getfollowcount(targetuserid: int) -> str | None:
    if not isinstance(targetuserid, int):
        return None
    try:
        r = sesh.get(f"https://friends.roblox.com/v1/users/{targetuserid}/followers/count", timeout=timeout)
    except requests.RequestException:
        return None
    if r.status_code == 200:
        return formatjson(r.json())
    return None