import requests
from tridentrbx.utils.json import formatjson
from tridentrbx.utils.session import sesh, timeout

def getgroupgames(groupid: int, accessfilter: int = 1, limit: int = 10, cursor: str = None, sortorder: str = "Asc") -> str | None:
    if not isinstance(groupid, int):
        return None
    params = {"accessFilter": accessfilter, "limit": limit, "sortOrder": sortorder}
    if cursor:
        params["cursor"] = cursor
    try:
        r = sesh.get(f"https://games.roblox.com/v2/groups/{groupid}/gamesV2", params=params, timeout=timeout)
    except requests.RequestException:
        return None
    if r.status_code == 200:
        return formatjson(r.json())
    if r.status_code == 501:
        return None
    return None