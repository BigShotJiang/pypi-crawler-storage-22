from typing import Any, Optional
import httpx
from websockets.asyncio.client import connect
from tristero.config import get_config
from tristero.data import get_gas_addr

class APIException(Exception):
    pass

class QuoteException(Exception):
    pass

def handle_resp(resp: httpx.Response):
    try:
        resp.raise_for_status()
        data = resp.json()
        return data
    except Exception as e:
        try:
            data = resp.json()
        except Exception as json_e:
            if resp.text:
                raise APIException(resp.text)
            else:
                raise e
        raise APIException(data)

async def t_get(client: httpx.AsyncClient, url: str):
    resp = await client.get(url, headers=get_config().headers, timeout=20)
    return handle_resp(resp)


async def t_post(client: httpx.AsyncClient, url: str, body: Optional[dict[str, Any]]):
    resp = await client.post(url, headers=get_config().headers, json=body, timeout=20)
    return handle_resp(resp)

def or_native(chain_id: str, address: str):
    return get_gas_addr(chain_id) if address == "native" else address

c = httpx.AsyncClient()

async def get_quote(
    from_wallet: str,
    to_wallet: str,
    from_chain_id: str,
    from_address: str,
    to_chain_id: str,
    to_address: str,
    amount: int,
):
    from_chain_id = from_chain_id
    to_chain_id = to_chain_id

    from_token_address = or_native(from_chain_id, from_address)
    to_token_address = or_native(to_chain_id, to_address)

    data = {
        "src_chain_id": from_chain_id,
        "src_token_address": from_token_address,
        "src_token_quantity": str(int(amount)),
        "src_wallet_address": from_wallet,
        "dst_chain_id": to_chain_id,
        "dst_token_address": to_token_address,
        "dst_wallet_address": to_wallet,
    }
    resp = await c.post(
        get_config().quoter_url,
        json=data,
    )
    # print(data, resp)
    try:
        return handle_resp(resp)
    except Exception as e:
        raise QuoteException(e, data) from e

async def fill_order(signature: str, domain: dict[str, Any], message: dict[str, Any]):
    data = {"signature": signature, "domain": domain, "message": message}
    resp = await c.post(
        get_config().filler_url,
        json=data,
    )
    return handle_resp(resp)

async def fill_order_feather(src_chain: str, dst_chain: str, dst_address: str, amount: int, client_id: str = ''):
    data = {
        "client_id": client_id,
        "src_chain": src_chain,
        "dst_chain": dst_chain,
        "dst_address": dst_address,
        "amount": amount
    }
    resp = await c.post(
        get_config().filler_url,
        json=data,
    )
    return handle_resp(resp)

async def poll_updates(order_id: str):
    ws = await connect(f"{get_config().ws_url}/{order_id}")
    return ws

async def poll_updates_feather(order_id: str):
    ws = await connect(f"{get_config().ws_url}/feather/{order_id}")
    return ws
