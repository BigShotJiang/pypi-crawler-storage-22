import asyncio
from dataclasses import dataclass
import json
import logging
from typing import Any, Optional, TypeVar

from eth_account.signers.local import LocalAccount
from pydantic import BaseModel

from tristero.api import fill_order, fill_order_feather, get_quote, poll_updates, poll_updates_feather
from .permit2 import Permit2Order, create_permit2_order
from .data import ChainID
from web3 import AsyncBaseProvider, AsyncWeb3
from web3 import AsyncWeb3
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
)
logger = logging.getLogger(__name__)

P = TypeVar("P", bound=AsyncBaseProvider)

class WebSocketClosedError(Exception):
    pass

class SwapException(Exception):
    """Base exception for all swap-related errors."""
    pass


class StuckException(SwapException):
    """Raised when swap execution times out"""
    pass


class OrderFailedException(SwapException):
    """Order execution failed on-chain."""
    def __init__(self, message: str, order_id: str, details: dict[str, Any]):
        super().__init__(message)
        self.order_id = order_id
        self.details = details

class TokenSpec(BaseModel, frozen=True):
    chain_id: ChainID
    token_address: str

async def wait_for_feather_completion(order_id: str):
    ws = await poll_updates_feather(order_id)
    try:
        async for msg in ws:
            if not msg:
                continue
            msg = json.loads(msg)
            status = msg['status']
            logger.info(
                {
                    "message": f"status={status}",
                    "id": "order_update",
                    "payload": msg,
                }
            )
            if status in ['Expired']:
                await ws.close()
                raise Exception(f"Swap failed: {ws.close_reason} {msg}")
            elif status in ['Finalized']:
                await ws.close()
                return msg
        # If we exit the loop without completed/failed, raise to retry
        raise WebSocketClosedError("WebSocket closed without completion status")
    except Exception as e:
        # Close cleanly if still open
        if not ws.close_code:
            await ws.close()
        raise

async def wait_for_permit2_completion(order_id: str):
    ws = await poll_updates(order_id)
    try:
        async for msg in ws:
            msg = json.loads(msg)
            logger.info(
                {
                    "message": f"failed={msg['failed']} completed={msg['completed']}",
                    "id": "order_update",
                    "payload": msg,
                }
            )
            if msg["failed"]:
                await ws.close()
                raise Exception(f"Swap failed: {ws.close_reason} {msg}")
            elif msg["completed"]:
                await ws.close()
                return msg

        # If we exit the loop without completed/failed, raise to retry
        raise WebSocketClosedError("WebSocket closed without completion status")
    except Exception:
        # Close cleanly if still open
        if not ws.close_code:
            await ws.close()
        raise

async def wait_for_completion(order_id: str, feather: bool):
    if feather:
        return await wait_for_feather_completion(order_id)
    else:
        return await wait_for_permit2_completion(order_id)

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=4, max=10),
    retry=retry_if_exception_type(WebSocketClosedError)
)
async def wait_for_completion_with_retry(order_id: str, feather: bool = False):
    return await wait_for_completion(order_id, feather)

@dataclass
class FeatherSwapResult:
    deposit_address: str
    data: Any

class FeatherException(Exception):
    pass

async def start_feather_swap(
    src_t: TokenSpec,
    dst_t: TokenSpec,
    dst_addr: str,
    raw_amount: int,
    client_id: str = ''
):
    resp = await fill_order_feather(client_id, str(src_t.chain_id.value), str(dst_t.chain_id), dst_addr, raw_amount)
    if resp['detail']:
        raise FeatherException(resp)
    else:
        return FeatherSwapResult(
            deposit_address = resp['deposit_address'],
            data = resp
        )

async def start_permit2_swap(
    w3: AsyncWeb3[P],
    account: LocalAccount,
    src_t: TokenSpec,
    dst_t: TokenSpec,
    raw_amount: int,
):
    order = await create_permit2_order(
        w3,
        account,
        str(src_t.chain_id.value),
        src_t.token_address,
        str(dst_t.chain_id.value),
        dst_t.token_address,
        raw_amount,
    )
    response = await fill_order(
        str(order.sig.signature.to_0x_hex()),
        order.msg.domain.model_dump(by_alias=True, mode="json"),
        order.msg.message.model_dump(by_alias=True, mode="json"),
    )
    order_id = response['id']
    return order_id

async def execute_permit2_swap(
    w3: AsyncWeb3[P],
    account: LocalAccount,
    src_t: TokenSpec,
    dst_t: TokenSpec,
    raw_amount: int,
    retry: bool = True,
    timeout: Optional[float] = None
) -> dict[str, Any]:
    """Execute and wait for swap completion."""
    order_id = await start_permit2_swap(w3, account, src_t, dst_t, raw_amount)
    logger.info(f"Swap order placed: {order_id}")

    waiter = wait_for_completion_with_retry if retry else wait_for_completion

    try:
        if timeout is None:
            return await waiter(order_id, False)

        return await asyncio.wait_for(
            waiter(order_id),
            timeout=timeout
        )
    except asyncio.TimeoutError as exc:
        raise StuckException(f"Swap {order_id} timed out after {timeout}s") from exc

