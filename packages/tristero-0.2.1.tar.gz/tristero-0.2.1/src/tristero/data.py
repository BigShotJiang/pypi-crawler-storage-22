from importlib import resources as impresources
import json
from typing import TYPE_CHECKING
import enum

CHAINS_FILE = impresources.files("tristero.files") / "chains.json"
CHAINS = json.loads(CHAINS_FILE.read_text())

def get_address(chain: str, id: str) -> str | None:
    return CHAINS[chain].get('addresses').get(id)

def get_permit2_addr(chain: str):
    return get_address(chain, 'permit2')

def get_wrapped_gas_addr(chain: str):
    return get_address(chain, 'wrappedGasToken')

def get_gas_addr(chain: str):
    return get_address(chain, 'gasToken')

def chain(id: str) -> str | None:
    return CHAINS[str(id)].get('chainId')

if TYPE_CHECKING:
    from enum import IntEnum
    class ChainID(IntEnum):
        _value_: int
else:
    ChainID = enum.Enum(
        'ChainID',
        {
            name: data['chainId']
            for name, data in CHAINS.items()
        }
    )
