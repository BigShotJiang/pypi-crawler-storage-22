from tristero.client import (
    OrderFailedException,
    StuckException,
    SwapException,
    MarginException,
    FeatherException,
    TokenSpec,
    OrderType,
    QuoteResult,
    OrderResult,
    MarginPosition,
    FeatherSwapResult,
    make_async_w3,
    execute_permit2_swap,
    execute_swap,
    start_permit2_swap,
    start_feather_swap,
    wait_for_feather_completion,
    wait_for_completion,
    wait_for_completion_with_retry,
    request_margin_quote,
    sign_order,
    submit_order,
    open_margin_position,
    close_margin_position,
    list_margin_positions,
    get_position,
)
from tristero.config import set_config, Config
from tristero.data import ChainID
from tristero.permit2 import get_erc20_contract
from tristero.api import APIException, QuoteException, get_quote, fill_order

__all__ = [
    # Enums and Types
    "ChainID",
    "TokenSpec",
    "OrderType",
    "QuoteResult",
    "OrderResult",
    "MarginPosition",
    "FeatherSwapResult",
    "Config",
    # Exceptions
    "StuckException",
    "OrderFailedException",
    "SwapException",
    "MarginException",
    "FeatherException",
    # Swap Functions
    "start_permit2_swap",
    "start_feather_swap",
    "execute_permit2_swap",
    "execute_swap",
    "make_async_w3",
    # Wait Functions
    "wait_for_feather_completion",
    "wait_for_completion",
    "wait_for_completion_with_retry",
    # Margin Functions (Quote Flow)
    "request_margin_quote",
    "sign_order",
    "submit_order",
    # Margin Functions (Direct Execution)
    "open_margin_position",
    "close_margin_position",
    # Position Management
    "list_margin_positions",
    "get_position",
    # Config
    "set_config",
    # ERC20 Helpers
    "get_erc20_contract",
    # Low-level HTTP API
    "APIException",
    "QuoteException",
    "get_quote",
    "fill_order",
]
