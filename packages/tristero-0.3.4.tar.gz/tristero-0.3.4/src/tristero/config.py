from contextvars import ContextVar


class Config:
    filler_url = "https://api.tristero.com/v2/orders"
    quoter_url = "https://api.tristero.com/v2/quotes"
    ws_url = "wss://api.tristero.com/v2/orders"
    
    margin_quoter_url = "https://api.tristero.com/v2/quotes"
    margin_filler_url = "https://api.tristero.com/v2/orders"
    wallet_server_url = "https://api.tristero.com/v2/wallets"

    # filler_url = "http://localhost:8070"
    # quoter_url = "http://localhost:8060"
    # ws_url = "ws://localhost:8070"
    
    # margin_quoter_url = "http://localhost:8060"
    # margin_filler_url = "http://localhost:8070"
    # wallet_server_url = "http://localhost:8090"

    headers = {
        "User-Agent": "Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148"
    }


config_var = ContextVar("config", default=Config())


def get_config():
    return config_var.get()


def set_config(new_config: Config):
    return config_var.set(new_config)

