from .simple_types import (
    EIP712OrderParameters,
    EIP712TokenPermissions,
    EIP712Domain,
    EIP712Permit,
    EIP712MMWitness,
    EIP712MarginWitness,
    EIP712CloseWithSwap,
)

from .nested_types import (
    EIP712SignedOrder,
    EIP712PermitWitnessTransferFromOrder,
    EIP712PermitWitnessTransferFromMM,
    EIP712PermitWitnessTransferFromMargin,
)

from .eip712_struct import EIP712Struct
from .eip712_auto import EIP712AutoStruct
from .escrow_utils import get_escrow_domain, get_close_with_swap_types, ESCROW_NAME, ESCROW_VERSION
from eth_utils import keccak


def eip712_digest(domain: "EIP712Struct", message: "EIP712Struct") -> bytes:
    prefix = b"\x19\x01"
    return keccak(prefix + domain.hash() + message.hash())


__all__ = [
    "EIP712OrderParameters",
    "EIP712TokenPermissions",
    "EIP712SignedOrder",
    "EIP712PermitWitnessTransferFromOrder",
    "EIP712PermitWitnessTransferFromMM",
    "EIP712PermitWitnessTransferFromMargin",
    "EIP712MMWitness",
    "EIP712MarginWitness",
    "EIP712CloseWithSwap",
    "EIP712Struct",
    "EIP712Domain",
    "EIP712Permit",
    "EIP712AutoStruct",
    "eip712_digest",
    "get_escrow_domain",
    "get_close_with_swap_types",
    "ESCROW_NAME",
    "ESCROW_VERSION",
]
