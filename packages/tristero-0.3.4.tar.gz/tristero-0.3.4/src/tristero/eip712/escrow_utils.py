from __future__ import annotations

from typing import Any, Dict

from eth_utils import to_checksum_address

from .simple_types import EIP712CloseWithSwap


ESCROW_NAME = "Tristero Margin Position"
ESCROW_VERSION = "3"


def get_escrow_domain(chain_id: int, verifying_contract: str) -> Dict[str, Any]:
    return {
        "name": ESCROW_NAME,
        "version": ESCROW_VERSION,
        "chainId": int(chain_id),
        "verifyingContract": to_checksum_address(verifying_contract),
    }


def get_close_with_swap_types() -> Dict[str, Any]:
    return {
        "EIP712Domain": [
            {"name": "name", "type": "string"},
            {"name": "version", "type": "string"},
            {"name": "chainId", "type": "uint256"},
            {"name": "verifyingContract", "type": "address"},
        ],
        "CloseWithSwap": EIP712CloseWithSwap.TYPE_STRUCT,
    }
