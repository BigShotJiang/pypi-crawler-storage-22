from __future__ import annotations
from typing import List
from .eip712_auto import EIP712AutoStruct
from .simple_types import (
    EIP712OrderParameters,
    EIP712TokenPermissions,
    EIP712MMWitness,
    EIP712MarginWitness,
)


class EIP712SignedOrder(EIP712AutoStruct):
    SOL_TYPE_NAME = "SignedOrder"

    sender: str
    parameters: EIP712OrderParameters
    deadline: int
    target: str
    filler: str
    orderType: str
    customData: List[bytes]

    SOL_TYPES = {
        "sender": "address",
        "parameters": "OrderParameters",
        "deadline": "uint256",
        "target": "address",
        "filler": "address",
        "orderType": "string",
        "customData": "bytes[]",
    }


class EIP712PermitWitnessTransferFromOrder(EIP712AutoStruct):
    SOL_TYPE_NAME = "PermitWitnessTransferFrom"

    permitted: EIP712TokenPermissions
    spender: str
    nonce: int
    deadline: int
    witness: EIP712SignedOrder

    SOL_TYPES = {
        "permitted": "TokenPermissions",
        "spender": "address",
        "nonce": "uint256",
        "deadline": "uint256",
        "witness": "SignedOrder",
    }


class EIP712PermitWitnessTransferFromMM(EIP712AutoStruct):
    SOL_TYPE_NAME = "PermitWitnessTransferFrom"

    permitted: EIP712TokenPermissions
    spender: str
    nonce: int
    deadline: int
    witness: EIP712MMWitness

    SOL_TYPES = {
        "permitted": "TokenPermissions",
        "spender": "address",
        "nonce": "uint256",
        "deadline": "uint256",
        "witness": "MMWitness",
    }


class EIP712PermitWitnessTransferFromMargin(EIP712AutoStruct):
    SOL_TYPE_NAME = "PermitWitnessTransferFrom"

    permitted: EIP712TokenPermissions
    spender: str
    nonce: int
    deadline: int
    witness: EIP712MarginWitness

    SOL_TYPES = {
        "permitted": "TokenPermissions",
        "spender": "address",
        "nonce": "uint256",
        "deadline": "uint256",
        "witness": "MarginWitness",
    }
