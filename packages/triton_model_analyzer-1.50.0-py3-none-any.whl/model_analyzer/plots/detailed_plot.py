#!/usr/bin/env python3
# SPDX-FileCopyrightText: Copyright (c) 2021-2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

import logging
import os
from collections import defaultdict

import matplotlib.pyplot as plt
from matplotlib import patches as mpatches

from model_analyzer.constants import LOGGER_NAME
from model_analyzer.perf_analyzer.perf_config import PerfAnalyzerConfig
from model_analyzer.record.metrics_manager import MetricsManager

logging.getLogger("matplotlib").setLevel(logging.ERROR)

logger = logging.getLogger(LOGGER_NAME)


class DetailedPlot:
    """
    A wrapper class around a matplotlib
    plot that adapts with the kinds of
    plots the model analyzer wants to generates

    Detailed plots detail th
    """

    detailed_metrics = [
        "perf_server_queue",
        "perf_server_compute_input",
        "perf_server_compute_infer",
        "perf_server_compute_output",
    ]

    def __init__(self, name, title, bar_width=0.5):
        """
        Parameters
        ----------
        name: str
            The name of the file that the plot
            will be saved as
        title : str
            The title of this plot/figure
        bar_width: float
            width of the latency breakdown bars
        """

        self._name = name
        self._title = title

        self._fig, self._ax_latency = plt.subplots()
        self._ax_latency.set_title(title)
        self._ax_throughput = self._ax_latency.twinx()

        latency_axis_label, throughput_axis_label = [
            metric.header(aggregation_tag="")
            for metric in MetricsManager.get_metric_types(
                ["perf_latency_avg", "perf_throughput"]
            )
        ]

        # Okabe-Ito guideline colors for colorblind
        # https://jfly.uni-koeln.de/color/#select
        self._bar_colors = {
            "perf_server_queue": "#e69f00",
            "perf_server_compute_input": "#56b4e9",
            "perf_server_compute_infer": "#009e73",
            "perf_server_compute_output": "#f0e442",
            "perf_throughput": "#000000",
        }

        self._bar_width = bar_width
        self._legend_x = 0.92
        self._legend_y = 1.15
        self._legend_font_size = 10
        self._fig.set_figheight(8)
        self._fig.set_figwidth(12)

        self._ax_latency.set_ylabel(latency_axis_label)
        self._ax_throughput.set_ylabel(throughput_axis_label)

        self._data = defaultdict(list)

    def data(self):
        """
        Get the data in this plot

        Returns
        -------
        dict
            keys are line labels
            and values are lists of floats
        """

        return self._data

    def add_run_config_measurement(self, run_config_measurement):
        """
        Adds a measurement to this plot

        Parameters
        ----------
        measurement : Measurement
            The measurement containing the data to
            be plotted.
        """

        # TODO-TMA-568: This needs to be updated because there will be multiple model configs
        for load_arg in PerfAnalyzerConfig.get_inference_load_args():
            if (
                load_arg in run_config_measurement.model_specific_pa_params()[0]
                and run_config_measurement.model_specific_pa_params()[0][load_arg]
            ):
                data_key = self._get_data_key_from_load_arg(load_arg)
                self._data[data_key].append(
                    run_config_measurement.model_specific_pa_params()[0][load_arg]
                )

        self._data["perf_throughput"].append(
            run_config_measurement.get_non_gpu_metric_value(tag="perf_throughput")
        )

        for metric in self.detailed_metrics:
            if MetricsManager.is_gpu_metric(tag=metric):
                self._data[metric].append(
                    run_config_measurement.get_gpu_metric_value(tag=metric)
                )
            else:
                self._data[metric].append(
                    run_config_measurement.get_non_gpu_metric_value(tag=metric)
                )

    def plot_data(self):
        """
        Calls plotting function
        on this plot's Axes object
        """

        # Update the x-axis plot title
        if "request_intervals" in self._data and self._data["request_intervals"][0]:
            self._ax_latency.set_xlabel("Request Intervals File")
            sort_indices_key = "request_intervals"
        elif "request_rate" in self._data and self._data["request_rate"][0]:
            self._ax_latency.set_xlabel("Client Request Rate")
            sort_indices_key = "request_rate"
        else:
            self._ax_latency.set_xlabel("Concurrent Client Requests")
            sort_indices_key = "concurrency"

        sort_indices = list(
            zip(*sorted(enumerate(self._data[sort_indices_key]), key=lambda x: x[1]))
        )[0]

        sorted_data = {
            key: [data_list[i] for i in sort_indices]
            for key, data_list in self._data.items()
        }

        sorted_data["indices"] = list(map(str, sorted_data[sort_indices_key]))

        # Plot latency breakdown bars
        labels = dict(
            zip(
                self.detailed_metrics,
                [
                    metric.header()
                    for metric in MetricsManager.get_metric_types(
                        tags=self.detailed_metrics
                    )
                ],
            )
        )
        bottoms = None

        # Plot latency breakdown with concurrency casted as string to make uniform x
        for metric, label in labels.items():
            self._ax_latency.bar(
                sorted_data["indices"],
                sorted_data[metric],
                width=self._bar_width,
                label=label,
                bottom=bottoms,
                color=self._bar_colors[metric],
            )
            if not bottoms:
                bottoms = sorted_data[metric]
            else:
                bottoms = list(map(lambda x, y: x + y, bottoms, sorted_data[metric]))

        # Plot the inference line
        inference_line = self._ax_throughput.plot(
            sorted_data["indices"],
            sorted_data["perf_throughput"],
            label="Inferences/second",
            marker="o",
            color=self._bar_colors["perf_throughput"],
        )

        # Create legend handles
        handles = [
            mpatches.Patch(color=self._bar_colors[m], label=labels[m])
            for m in self._bar_colors
            if m != "perf_throughput"
        ]
        handles.append(inference_line[0])

        self._ax_latency.legend(
            handles=handles,
            ncol=(len(self._bar_colors) // 2) + 1,
            bbox_to_anchor=(self._legend_x, self._legend_y),
            prop=dict(size=self._legend_font_size),
        )
        # Annotate inferences
        for x, y in zip(sorted_data["indices"], sorted_data["perf_throughput"]):
            self._ax_throughput.annotate(
                str(round(y, 2)),
                xy=(x, y),
                textcoords="offset points",  # how to position the text
                xytext=(0, 10),  # distance from text to points (x,y)
                ha="center",
            )

        self._ax_latency.grid()
        self._ax_latency.set_axisbelow(True)

    def save(self, filepath):
        """
        Saves a .png of the plot to disk

        Parameters
        ----------
        filepath : the path to the directory
            this plot should be saved to
        """

        self._fig.savefig(os.path.join(filepath, self._name))

    def _get_data_key_from_load_arg(self, load_arg):
        """
        Gets the key into _data corresponding with the input load arg

        For example, the load arg "request-rate-range" has the key "request_rate"
        """
        # Check if '-range' exists at the end of the input string and remove it
        if load_arg.endswith("-range"):
            load_arg = load_arg[:-6]

        # Replace any '-' with '_' in the remaining string
        data_key = load_arg.replace("-", "_")

        return data_key
