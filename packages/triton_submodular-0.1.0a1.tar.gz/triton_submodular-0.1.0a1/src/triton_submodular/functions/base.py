import torch
from ..optimizers import create_optimizer, OptimizerType


class BaseFunction:
    def __init__(self, data: torch.Tensor, calc_gains_fn, update_fn):
        self.n: int
        self.d: int
        self.n, self.d = data.shape
        self.device = data.device
        self.dtype = data.dtype
        self.data: torch.Tensor = data
        self.calculate_gains = calc_gains_fn
        self.update = update_fn

    def initial_buffers(self):
        current_values = torch.zeros(self.d, device=self.device, dtype=self.dtype)
        max_values = torch.zeros_like(current_values)
        return current_values, max_values

    def evaluate(self, idxs=None) -> torch.Tensor:
        raise NotImplementedError()

    def maximize(self, budget: int, optimizer_type: OptimizerType, **kwargs):
        optimizer = create_optimizer(optimizer_type, self, **kwargs)
        return optimizer.maximize(budget)


def compute_similarity_matrix(data, metric):
    # TODO: Add more metrics
    dist_matrix = torch.cdist(data, data, p=2)
    if metric == "submodlib":
        gamma = 1.0 / data.shape[1]
        data = torch.exp(-gamma * dist_matrix)
    else:  # apricot
        dist_matrix.square_()
        data = dist_matrix.max() - dist_matrix
    return data


class BaseGraphFunction(BaseFunction):
    def __init__(self, data, calc_gains_fn, update_fn, metric=None):
        if metric is not None:
            data = compute_similarity_matrix(data, metric)
        super().__init__(data, calc_gains_fn, update_fn)
