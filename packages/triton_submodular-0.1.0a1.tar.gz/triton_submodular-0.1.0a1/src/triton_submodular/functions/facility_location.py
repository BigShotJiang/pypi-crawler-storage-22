from typing import Literal

import torch
import triton
import triton.language as tl

from .base import BaseGraphFunction


@triton.jit
def _calculate_gains_triton(
    sim_matrix_ptr,
    idxs,
    idx_mask,
    current_values,
    max_values,
    n: tl.constexpr,
    d: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_D: tl.constexpr,
    N_IDX,
    threshold: tl.constexpr,
):
    gains = tl.zeros([N_IDX], dtype=sim_matrix_ptr.dtype.element_ty)
    d_range = tl.arange(0, BLOCK_D)
    for d_off in range(0, d, BLOCK_D):
        d_idx = d_range + d_off
        d_mask = d_idx < d
        sim_block = tl.load(
            sim_matrix_ptr + idxs[:, None] * d + d_idx[None, :],
            mask=idx_mask[:, None] & d_mask[None, :],
            other=-torch.inf,
        )
        cur_max_sims_block = tl.load(
            current_values + d_idx, mask=d_mask, other=torch.inf
        )
        gains += tl.sum(tl.maximum(sim_block - cur_max_sims_block, 0.0), axis=1)
    return gains


@triton.jit
def _update_gains_triton(
    best_vec,
    current_values,
    max_values,
    n: tl.constexpr,
    d: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_D: tl.constexpr,
    threshold: tl.constexpr,
):
    d_range = tl.arange(0, BLOCK_D)
    for d_off in range(0, d, BLOCK_D):
        d_idx = d_range + d_off
        d_mask = d_idx < d
        sim_block = tl.load(best_vec + d_idx, mask=d_mask)
        current_max_sims_block = tl.load(current_values + d_idx, mask=d_mask)
        new_max_sims_block = tl.maximum(current_max_sims_block, sim_block)
        tl.store(current_values + d_idx, new_max_sims_block, mask=d_mask)


class FacilityLocation(BaseGraphFunction):
    def __init__(
        self,
        data: torch.Tensor,
        metric: Literal["submodlib", "apricot"] = "submodlib",
    ):
        super().__init__(data, _calculate_gains_triton, _update_gains_triton, metric)

    def evaluate(self, idxs=None) -> torch.Tensor:
        if idxs is None:
            idxs = slice(None)
        return self.data[idxs].amax(0).sum()
