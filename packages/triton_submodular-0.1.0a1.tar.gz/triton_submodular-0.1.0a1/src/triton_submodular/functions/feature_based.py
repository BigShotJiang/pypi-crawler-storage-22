from typing import Literal, Union
from functools import cache

import torch
import triton
import triton.language as tl

from .base import BaseFunction


@cache
def _calculate_gains_triton(concave_func):
    @triton.jit
    def _kernel(
        data_ptr,
        idxs,
        idx_mask,
        current_values,
        max_values,
        n: tl.constexpr,
        d: tl.constexpr,
        BLOCK_N: tl.constexpr,
        BLOCK_D: tl.constexpr,
        N_IDX,
        threshold: tl.constexpr,
    ):
        gains = tl.zeros([N_IDX], dtype=data_ptr.dtype.element_ty)
        d_range = tl.arange(0, BLOCK_D)
        for d_off in range(0, d, BLOCK_D):
            d_idx = d_range + d_off
            d_mask = d_idx < d
            data_block = tl.load(
                data_ptr + idxs[:, None] * d + d_idx[None, :],
                mask=idx_mask[:, None] & d_mask[None, :],
                other=0.0,
            )
            cur_vals_block = tl.load(current_values + d_idx, mask=d_mask, other=0.0)
            gains += tl.sum(
                concave_func(cur_vals_block + data_block)
                - concave_func(cur_vals_block),
                axis=1,
            )
        return gains

    return _kernel


@triton.jit
def _update_gains_triton(
    best_vec,
    current_values,
    max_values,
    n: tl.constexpr,
    d: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_D: tl.constexpr,
    threshold: tl.constexpr,
):
    d_range = tl.arange(0, BLOCK_D)
    for d_off in range(0, d, BLOCK_D):
        d_idx = d_range + d_off
        d_mask = d_idx < d
        data_block = tl.load(best_vec + d_idx, mask=d_mask)
        cur_vals_block = tl.load(current_values + d_idx, mask=d_mask)
        new_vals_block = cur_vals_block + data_block
        tl.store(current_values + d_idx, new_vals_block, mask=d_mask)


@triton.jit
def log1p(x):
    return 1 + tl.log(x)


@cache
def triton_elemwise_to_torch_inplace(func):
    @triton.jit
    def _kernel(x, n, BLOCK_N):
        for off in range(0, n, BLOCK_N):
            idxs = tl.arange(off, off + BLOCK_N)
            x_block = tl.load(x + idxs, mask=idxs < n)
            x_block = func(x_block)
            tl.store(x + idxs, x_block, mask=idxs < n)

    def _torch_func(x: torch.Tensor):
        x = x.contiguous()
        _kernel[(1,)](x, x.numel(), 128)
        return x

    return _torch_func


class FeatureBased(BaseFunction):
    def __init__(
        self,
        data: torch.Tensor,
        concave_func: Union[Literal["log", "sqrt", "sigmoid"], triton.JITFunction],
    ):
        triton_concave_func = {
            "log": log1p,
            "sqrt": tl.sqrt,
            "sigmoid": tl.sigmoid,
        }.get(concave_func, concave_func)
        self.torch_concave_func = {
            "log": torch.log1p,
            "sqrt": torch.sqrt,
            "sigmoid": torch.sigmoid,
        }.get(concave_func, triton_elemwise_to_torch_inplace(triton_concave_func))
        calc_gains = _calculate_gains_triton(triton_concave_func)
        super().__init__(data, calc_gains, _update_gains_triton)

    def evaluate(self, idxs=None) -> torch.Tensor:
        if idxs is None:
            idxs = slice(None)
        return self.torch_concave_func(self.data[idxs].sum(0)).sum()
