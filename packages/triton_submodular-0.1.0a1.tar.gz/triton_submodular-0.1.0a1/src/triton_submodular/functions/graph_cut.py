from typing import Literal

import torch
import triton
import triton.language as tl

from .base import BaseGraphFunction


@triton.jit
def _calculate_gains_triton(
    sim_matrix_ptr,
    idxs,
    idx_mask,
    current_values,
    row_sums,
    n: tl.constexpr,
    d: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_D: tl.constexpr,
    N_IDX,
    threshold: tl.constexpr,
):
    row_sums_block = tl.load(row_sums + idxs, mask=idx_mask, other=0.0)
    cur_vals_block = tl.load(current_values + idxs, mask=idx_mask, other=0.0)
    gains = row_sums_block - cur_vals_block
    return gains


@triton.jit
def _update_gains_triton(
    best_vec,
    current_values,
    row_sums,
    n: tl.constexpr,
    d: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_D: tl.constexpr,
    threshold: tl.constexpr,
):
    d_range = tl.arange(0, BLOCK_D)
    for d_off in range(0, d, BLOCK_D):
        d_idx = d_range + d_off
        d_mask = d_idx < d
        data_block = tl.load(best_vec + d_idx, mask=d_mask)
        cur_vals_block = tl.load(current_values + d_idx, mask=d_mask)
        new_vals_block = cur_vals_block + data_block * 2.0
        tl.store(current_values + d_idx, new_vals_block, mask=d_mask)


class GraphCut(BaseGraphFunction):
    def __init__(
        self,
        data: torch.Tensor,
        metric: Literal["submodlib", "apricot"] = "submodlib",
    ):
        super().__init__(data, _calculate_gains_triton, _update_gains_triton, metric)

    def initial_buffers(self):
        current_values = self.data.diag()
        row_sums = self.data.sum(dim=1)
        return current_values, row_sums

    def evaluate(self, idxs=None) -> torch.Tensor:
        if idxs is None:
            idxs = slice(None)
        return self.data[idxs].sum() - self.data[idxs][:, idxs].sum()
