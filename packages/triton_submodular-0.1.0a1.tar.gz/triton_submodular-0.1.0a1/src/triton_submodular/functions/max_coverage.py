import torch
import triton
import triton.language as tl

from .base import BaseFunction


@triton.jit
def _calculate_gains_triton(
    data_ptr,
    idxs,
    idx_mask,
    current_values,
    max_values,
    n: tl.constexpr,
    d: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_D: tl.constexpr,
    N_IDX,
    threshold: tl.constexpr,
):
    gains = tl.zeros([N_IDX], dtype=data_ptr.dtype.element_ty)
    d_range = tl.arange(0, BLOCK_D)
    for d_off in range(0, d, BLOCK_D):
        d_idx = d_range + d_off
        d_mask = d_idx < d
        data_block = tl.load(
            data_ptr + idxs[:, None] * d + d_idx[None, :],
            mask=idx_mask[:, None] & d_mask[None, :],
            other=0.0,
        )
        cur_vals_block = tl.load(current_values + d_idx, mask=d_mask, other=0.0)
        gains += tl.sum(tl.minimum(data_block, threshold - cur_vals_block), axis=1)
    return gains


@triton.jit
def _update_gains_triton(
    best_vec,
    current_values,
    max_values,
    n: tl.constexpr,
    d: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_D: tl.constexpr,
    threshold: tl.constexpr,
):
    d_range = tl.arange(0, BLOCK_D)
    for d_off in range(0, d, BLOCK_D):
        d_idx = d_range + d_off
        d_mask = d_idx < d
        data_block = tl.load(best_vec + d_idx, mask=d_mask)
        cur_vals_block = tl.load(current_values + d_idx, mask=d_mask)
        new_max_sims_block = tl.minimum(cur_vals_block + data_block, threshold)
        tl.store(current_values + d_idx, new_max_sims_block, mask=d_mask)


class MaxCoverage(BaseFunction):
    def __init__(self, data: torch.Tensor, threshold: float = 1.0):
        super().__init__(data, _calculate_gains_triton, _update_gains_triton)
        self.threshold = threshold

    def evaluate(self, idxs=None) -> torch.Tensor:
        if idxs is None:
            idxs = slice(None)
        one = torch.ones((), dtype=self.data.dtype, device=self.data.device)
        return torch.minimum(self.data[idxs].sum(0), one).sum()
