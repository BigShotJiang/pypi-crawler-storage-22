from typing import Literal, TYPE_CHECKING
from .lazy_greedy import LazyGreedyTriton
from .stochastic_greedy import StochasticGreedyTriton
from .naive_greedy import NaiveGreedyTriton as NaiveGreedyTriton

if TYPE_CHECKING:
    from ..functions.base import BaseFunction

OptimizerType = Literal[
    "StochasticGreedyTriton",
    "LazyGreedyTriton",
    "NaiveGreedyTriton",
]


def create_optimizer(optimizer_type: OptimizerType, function: "BaseFunction", **kwargs):
    if optimizer_type == "LazyGreedyTriton":
        return LazyGreedyTriton(function)
    if optimizer_type == "StochasticGreedyTriton":
        return StochasticGreedyTriton(function, **kwargs)
    if optimizer_type == "NaiveGreedyTriton":
        return NaiveGreedyTriton(function)
    raise ValueError(f"Unknown optimizer: {optimizer_type}")
