import torch
import triton
import triton.language as tl
from functools import cache


@triton.jit
def block_argmax(ptr, n: tl.constexpr, block_size: tl.constexpr):
    n_range = tl.arange(0, block_size)
    max_val = -torch.inf
    max_idx = torch.iinfo(torch.long).max
    for n_off in range(0, n, block_size):
        offs = n_off + n_range
        mask = offs < n
        block = tl.load(ptr + offs, mask=mask, other=-torch.inf)
        max_block, argmax_block = tl.max(block, axis=0, return_indices=True)
        update = max_block > max_val
        max_val = tl.where(update, max_block, max_val)
        max_idx = tl.where(update, argmax_block + n_off, max_idx)
    return max_val, max_idx


@triton.jit
def block_max(ptr, n: tl.constexpr, block_size: tl.constexpr):
    n_range = tl.arange(0, block_size)
    max_val = -torch.inf
    for n_off in range(0, n, block_size):
        offs = n_off + n_range
        mask = offs < n
        block = tl.load(ptr + offs, mask=mask, other=-torch.inf)
        max_block = tl.max(block)
        update = max_block > max_val
        max_val = tl.where(update, max_block, max_val)
    return max_val


@cache
def get_lazy_greedy_kernel(calculate_gains_fn, update_gains_fn):
    @triton.jit
    def _kernel(
        data_ptr,
        max_heap_ptr,
        current_values_ptr,
        max_values_ptr,
        out_indices_ptr,
        gains_out_ptr,
        n: tl.constexpr,
        d: tl.constexpr,
        budget: tl.constexpr,
        BLOCK_N: tl.constexpr,
        BLOCK_D: tl.constexpr,
        threshold: tl.constexpr,
    ):
        idx = 0
        remaining_budget = budget
        upper_bound = n * budget  # A safe upper bound for iterations

        n_range = tl.arange(0, BLOCK_N)
        for n_off in range(0, n, BLOCK_N):
            idxs = n_off + n_range
            idx_mask = idxs < n
            gains = calculate_gains_fn(
                data_ptr,
                idxs,
                idx_mask,
                current_values_ptr,
                max_values_ptr,
                n,
                d,
                BLOCK_N,
                BLOCK_D,
                BLOCK_N,
                threshold,
            )
            tl.store(max_heap_ptr + idxs, gains, mask=idx_mask)

        for i in range(upper_bound):
            if remaining_budget > 0:
                _, cur_max_idx = block_argmax(max_heap_ptr, n, BLOCK_N)
                tl.store(max_heap_ptr + cur_max_idx, -torch.inf)

                gains = calculate_gains_fn(
                    data_ptr,
                    cur_max_idx,
                    cur_max_idx < n,
                    current_values_ptr,
                    max_values_ptr,
                    n,
                    d,
                    BLOCK_N,
                    BLOCK_D,
                    1,
                    threshold,
                ).item()

                cur_max = block_max(max_heap_ptr, n, BLOCK_N)

                if gains >= cur_max:
                    update_gains_fn(
                        data_ptr + d * cur_max_idx,
                        current_values_ptr,
                        max_values_ptr,
                        n,
                        d,
                        BLOCK_N,
                        BLOCK_D,
                        threshold,
                    )
                    tl.store(out_indices_ptr + idx, cur_max_idx)
                    tl.store(gains_out_ptr + idx, gains)
                    idx += 1
                    remaining_budget -= 1
                else:
                    tl.store(max_heap_ptr + cur_max_idx, gains)

    return _kernel[(1,)]


class LazyGreedyTriton:
    def __init__(self, function):
        self.function = function

    def maximize(self, budget: int) -> tuple[torch.Tensor, torch.Tensor]:
        threshold = getattr(self.function, "threshold", None)
        lazy_greedy_kernel = get_lazy_greedy_kernel(
            self.function.calculate_gains, self.function.update
        )

        data = self.function.data
        n, d = data.shape
        dev = data.device
        dt = data.dtype

        current_values, max_values = self.function.initial_buffers()
        out_indices = torch.zeros(budget, device=dev, dtype=torch.long)
        gains_out = torch.zeros(budget, device=dev, dtype=dt)
        max_heap = torch.zeros(n, device=dev, dtype=dt)

        lazy_greedy_kernel(
            data,
            max_heap,
            current_values,
            max_values,
            out_indices,
            gains_out,
            n=n,
            d=d,
            budget=budget,
            BLOCK_N=256,
            BLOCK_D=128,
            threshold=threshold,
        )
        return out_indices, gains_out
