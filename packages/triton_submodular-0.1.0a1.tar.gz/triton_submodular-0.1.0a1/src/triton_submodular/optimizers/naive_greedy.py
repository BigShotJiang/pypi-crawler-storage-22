import torch
import triton
import triton.language as tl
from functools import cache


@cache
def get_naive_greedy_kernel(calculate_gains_fn, update_gains_fn):
    @triton.jit
    def _kernel(
        data_ptr,
        current_values_ptr,
        max_values_ptr,
        out_indices_ptr,
        gains_out_ptr,
        indices_ptr,
        n: tl.constexpr,
        d: tl.constexpr,
        budget: tl.constexpr,
        BLOCK_N: tl.constexpr,
        BLOCK_D: tl.constexpr,
        threshold: tl.constexpr,
    ):
        idx = 0
        remaining_budget = budget

        n_range = tl.arange(0, BLOCK_N)

        for i in range(budget):
            # Calculate all gains and get the argmax
            current_pool_size = n - i
            best_gain = -torch.inf
            best_gain_idx = -1
            for n_off in range(0, current_pool_size, BLOCK_N):
                idxs = n_off + n_range
                idx_mask = idxs < current_pool_size
                idxs = tl.load(indices_ptr + idxs, mask=idx_mask)
                gains = calculate_gains_fn(
                    data_ptr,
                    idxs,
                    idx_mask,
                    current_values_ptr,
                    max_values_ptr,
                    n,
                    d,
                    BLOCK_N,
                    BLOCK_D,
                    BLOCK_N,
                    threshold,
                )
                gains = tl.where(idx_mask, gains, -torch.inf)
                max_block, argmax_block = tl.max(gains, axis=0, return_indices=True)
                update = max_block > best_gain
                best_gain = tl.where(update, max_block, best_gain)
                best_gain_idx = tl.where(update, argmax_block + n_off, best_gain_idx)

            global_best_idx = tl.load(indices_ptr + best_gain_idx)

            update_gains_fn(
                data_ptr + d * global_best_idx,
                current_values_ptr,
                max_values_ptr,
                n,
                d,
                BLOCK_N,
                BLOCK_D,
                threshold,
            )
            tl.store(out_indices_ptr + idx, global_best_idx)
            tl.store(gains_out_ptr + idx, best_gain)

            last_idx = current_pool_size - 1
            last_index = tl.load(indices_ptr + last_idx)
            tl.store(indices_ptr + best_gain_idx, last_index)
            idx += 1
            remaining_budget -= 1

    return _kernel[(1,)]


class NaiveGreedyTriton:
    def __init__(self, function):
        self.function = function

    def maximize(self, budget: int) -> tuple[torch.Tensor, torch.Tensor]:
        threshold = getattr(self.function, "threshold", None)
        naive_greedy_kernel = get_naive_greedy_kernel(
            self.function.calculate_gains, self.function.update
        )

        data = self.function.data
        n, d = data.shape
        dev = data.device
        dt = data.dtype

        current_values, max_values = self.function.initial_buffers()
        out_indices = torch.zeros(budget, device=dev, dtype=torch.long)
        gains_out = torch.zeros(budget, device=dev, dtype=dt)
        indices = torch.arange(n, device=dev, dtype=torch.long)

        naive_greedy_kernel(
            data,
            current_values,
            max_values,
            out_indices,
            gains_out,
            indices,
            n=n,
            d=d,
            budget=budget,
            BLOCK_N=256,
            BLOCK_D=128,
            threshold=threshold,
        )
        return out_indices, gains_out
