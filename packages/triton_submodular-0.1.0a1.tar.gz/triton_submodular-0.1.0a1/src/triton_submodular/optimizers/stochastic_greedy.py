from math import log
from typing import Optional

import torch
from functools import cache


import triton
import triton.language as tl
import numpy as np


@cache
def get_stochastic_greedy_kernel(calculate_gains_fn, update_gains_fn):
    @triton.jit
    def _kernel(
        data_ptr,
        current_values_ptr,
        max_values_ptr,
        indices_ptr,
        out_indices_ptr,
        out_gains_ptr,
        samples_ptr,
        n: tl.constexpr,
        d: tl.constexpr,
        sample_size: tl.constexpr,
        budget: tl.constexpr,
        BLOCK_N: tl.constexpr,
        BLOCK_D: tl.constexpr,
        BLOCK_S: tl.constexpr,
        threshold: tl.constexpr,
        testing: tl.constexpr,
    ):
        s_range = tl.arange(0, BLOCK_S)

        for i in range(budget):
            current_pool_size = n - i
            true_sample_size = min(sample_size, current_pool_size)
            best_gain = -torch.inf
            best_j = torch.iinfo(torch.long).max  # will crash on memory error
            for s_off in range(0, true_sample_size, BLOCK_S):
                # Compute gains for all samples (vector)
                j = s_off + s_range
                j_mask = j < true_sample_size

                pos_in_pool = tl.load(samples_ptr + i * sample_size + j, mask=j_mask)
                val_global = tl.load(indices_ptr + pos_in_pool, mask=j_mask)

                gains_vec = calculate_gains_fn(
                    data_ptr,
                    val_global,
                    j_mask,
                    current_values_ptr,
                    max_values_ptr,
                    n,
                    d,
                    BLOCK_N,
                    BLOCK_D,
                    BLOCK_S,
                    threshold,
                )
                gains_vec = tl.where(j_mask, gains_vec, -torch.inf)

                # Argmax over gains (vector reduction)
                block_best_gain, block_best_j = tl.max(
                    gains_vec, axis=0, return_indices=True
                )
                update = block_best_gain > best_gain
                best_gain = tl.where(update, block_best_gain, best_gain)
                best_j = tl.where(update, block_best_j + s_off, best_j)

            global_best_idx = tl.load(samples_ptr + i * sample_size + best_j)
            global_best = tl.load(indices_ptr + global_best_idx)

            update_gains_fn(
                data_ptr + global_best * d,
                current_values_ptr,
                max_values_ptr,
                n,
                d,
                BLOCK_N,
                BLOCK_D,
                threshold,
            )
            tl.store(out_indices_ptr + i, global_best)
            tl.store(out_gains_ptr + i, best_gain)

            if testing:
                # Match apricot behavior of sliding everything over
                # Keeps invariant that indices_ptr remains sorted at all iters
                n_range = tl.arange(0, triton.next_power_of_2(n))  # type: ignore
                big_mask = n_range < n
                vals = tl.load(indices_ptr + n_range, mask=big_mask, other=n + 1)
                vals = tl.where(n_range == global_best_idx, n + 1, vals)
                vals = tl.sort(vals)
                tl.store(indices_ptr + n_range, vals, mask=big_mask)
            else:
                last_idx = current_pool_size - 1
                last_ind = tl.load(indices_ptr + last_idx)
                tl.store(indices_ptr + global_best_idx, last_ind)

    return _kernel


class StochasticGreedyTriton:
    def __init__(
        self,
        function,
        epsilon: float = 0.1,
        testing: bool = False,
        seed: Optional[int] = None,
    ):
        self.function = function
        self.epsilon = epsilon
        self.testing = testing
        self.seed = seed

    def maximize(self, budget: int) -> tuple[torch.Tensor, torch.Tensor]:
        threshold = getattr(self.function, "threshold", None)
        stochastic_greedy_kernel = get_stochastic_greedy_kernel(
            self.function.calculate_gains, self.function.update
        )
        data = self.function.data
        n, d = data.shape
        fn = stochastic_greedy_kernel[(1,)]
        dev = data.device
        dt = data.dtype
        current_values, max_values = self.function.initial_buffers()
        indices = torch.arange(n, device=dev, dtype=torch.long)
        out_indices = torch.zeros(budget, device=dev, dtype=torch.long)
        out_gains = torch.zeros(budget, device=dev, dtype=dt)
        sample_size = int((n / budget) * -log(self.epsilon))
        sample_size = max(1, min(sample_size, n))
        gen = torch.Generator(device=data.device)
        if self.seed is not None:
            gen = gen.manual_seed(self.seed)
        _, samples = (
            torch.empty((budget, n), device=dev, dtype=dt)
            .uniform_(0.1, 1, generator=gen)  # Uniform between eps and 1
            .triu()  # Sets unavailable indices to 0, so 0 NEVER chosen (0 < eps from above)
            .flip(1)  # triu gives it flipped, so we flip it back
            # topk of independent uniform numbers gives uniform sampling w/o/r
            .topk(sample_size, sorted=False)
        )
        if self.testing:
            # Used for 1:1 testing against apricot-select
            samples_list = []
            rs = np.random.RandomState(self.seed)
            for i in range(budget):
                true_sample_size = min(sample_size, n - i)
                sample = rs.choice(n - i, true_sample_size, replace=False)
                sample = np.pad(sample, (0, sample_size - true_sample_size))
                samples_list.append(sample)
            samples = torch.from_numpy(np.array(samples_list)).to(samples)
        fn(
            data,
            current_values,
            max_values,
            indices,
            out_indices,
            out_gains,
            samples,
            n,
            d,
            sample_size,
            budget,
            128,
            128,
            128,
            threshold,
            self.testing,
        )
        return out_indices, out_gains
