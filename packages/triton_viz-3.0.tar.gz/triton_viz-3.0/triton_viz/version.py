"""Auto-generated version file. Do not edit."""
__version__ = "3.0+gitba13e47e"
git_version = "ba13e47ef1bfb2a45b7fe320e9b39f2cc81e97a6"
