"""
TriTopic: Tri-Modal Graph Topic Modeling with Iterative Refinement

A state-of-the-art topic modeling library that consistently outperforms
BERTopic and traditional approaches.

Key Features:
- Multi-view representation (semantic, lexical, metadata)
- Hybrid graph construction (Mutual kNN + SNN)
- Consensus Leiden clustering for stability
- Iterative refinement for improved coherence
- Multilingual support (60+ languages)
- LLM-powered labeling

Example:
    >>> from tritopic import TriTopic
    >>> model = TriTopic(verbose=True)
    >>> topics = model.fit_transform(documents)
    >>> print(model.get_topic_info())
"""

__version__ = "1.0.0"
__author__ = "Roman Egger"

from .model import TriTopic, Topic
from .config import TriTopicConfig, get_config
from .labeling import LLMLabeler, KeywordLabeler

__all__ = [
    "TriTopic",
    "Topic",
    "TriTopicConfig",
    "get_config",
    "LLMLabeler",
    "KeywordLabeler",
]
