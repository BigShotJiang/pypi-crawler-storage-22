"""
Clustering Module

Implements Consensus Leiden clustering for stable topic discovery.
"""

from typing import List, Optional, Tuple
import numpy as np
from scipy import sparse
import warnings


class ConsensusLeiden:
    """
    Consensus clustering using Leiden algorithm.
    
    Runs Leiden multiple times and builds a co-assignment matrix
    to find stable cluster assignments.
    """
    
    def __init__(
        self,
        resolution: float = 1.0,
        n_runs: int = 10,
        min_cluster_size: int = 5,
        random_state: Optional[int] = 42,
    ):
        """
        Initialize the consensus clustering.
        
        Parameters
        ----------
        resolution : float
            Resolution parameter for Leiden
        n_runs : int
            Number of clustering runs
        min_cluster_size : int
            Minimum cluster size
        random_state : int, optional
            Random seed for reproducibility
        """
        self.resolution = resolution
        self.n_runs = n_runs
        self.min_cluster_size = min_cluster_size
        self.random_state = random_state
        
        self._check_dependencies()
    
    def _check_dependencies(self):
        """Check if required packages are installed."""
        try:
            import leidenalg
            import igraph
        except ImportError:
            raise ImportError(
                "leidenalg and python-igraph are required for clustering. "
                "Install with: pip install leidenalg python-igraph"
            )
    
    def fit_predict(
        self,
        graph: sparse.csr_matrix,
    ) -> np.ndarray:
        """
        Fit the consensus clustering and predict labels.
        
        Parameters
        ----------
        graph : sparse.csr_matrix
            Adjacency matrix of the document graph
            
        Returns
        -------
        np.ndarray
            Cluster labels for each document
        """
        import leidenalg
        import igraph as ig
        
        n = graph.shape[0]
        
        # Convert sparse matrix to igraph
        sources, targets = graph.nonzero()
        weights = np.array(graph[sources, targets]).flatten()
        
        # Create igraph graph
        g = ig.Graph(directed=False)
        g.add_vertices(n)
        edges = list(zip(sources.tolist(), targets.tolist()))
        g.add_edges(edges)
        g.es['weight'] = weights.tolist()
        
        # Run Leiden multiple times
        partitions = []
        
        for run in range(self.n_runs):
            seed = None if self.random_state is None else self.random_state + run
            
            partition = leidenalg.find_partition(
                g,
                leidenalg.RBConfigurationVertexPartition,
                weights='weight',
                resolution_parameter=self.resolution,
                seed=seed,
            )
            
            labels = np.array(partition.membership)
            partitions.append(labels)
        
        # Build co-assignment matrix
        co_assignment = self._build_co_assignment_matrix(partitions)
        
        # Final clustering on co-assignment matrix
        final_labels = self._final_clustering(co_assignment, g)
        
        # Apply minimum cluster size constraint
        final_labels = self._apply_min_cluster_size(final_labels)
        
        return final_labels
    
    def _build_co_assignment_matrix(
        self,
        partitions: List[np.ndarray],
    ) -> np.ndarray:
        """
        Build co-assignment matrix from multiple partitions.
        
        C[i,j] = fraction of runs where i and j are in the same cluster
        """
        n = len(partitions[0])
        co_assignment = np.zeros((n, n))
        
        for labels in partitions:
            # Documents with same label get co-assignment
            for label in np.unique(labels):
                mask = labels == label
                indices = np.where(mask)[0]
                for i in indices:
                    for j in indices:
                        co_assignment[i, j] += 1
        
        # Normalize by number of runs
        co_assignment /= len(partitions)
        
        return co_assignment
    
    def _final_clustering(
        self,
        co_assignment: np.ndarray,
        original_graph: "igraph.Graph",
    ) -> np.ndarray:
        """
        Perform final clustering on the co-assignment matrix.
        """
        import leidenalg
        import igraph as ig
        
        n = co_assignment.shape[0]
        
        # Threshold the co-assignment matrix
        # Keep only edges where co-assignment > 0.5 (majority of runs)
        threshold = 0.5
        adjacency = np.where(co_assignment > threshold, co_assignment, 0)
        
        # Create graph from co-assignment
        sources, targets = np.where(adjacency > 0)
        weights = adjacency[sources, targets]
        
        g = ig.Graph(directed=False)
        g.add_vertices(n)
        edges = list(zip(sources.tolist(), targets.tolist()))
        g.add_edges(edges)
        g.es['weight'] = weights.tolist()
        
        # Final Leiden run
        partition = leidenalg.find_partition(
            g,
            leidenalg.RBConfigurationVertexPartition,
            weights='weight',
            resolution_parameter=self.resolution,
            seed=self.random_state,
        )
        
        return np.array(partition.membership)
    
    def _apply_min_cluster_size(
        self,
        labels: np.ndarray,
    ) -> np.ndarray:
        """
        Apply minimum cluster size constraint.
        
        Small clusters are marked as outliers (-1).
        """
        unique_labels, counts = np.unique(labels, return_counts=True)
        
        # Find small clusters
        small_clusters = unique_labels[counts < self.min_cluster_size]
        
        # Mark as outliers
        result = labels.copy()
        for small_label in small_clusters:
            result[labels == small_label] = -1
        
        # Renumber remaining clusters from 0
        if len(np.unique(result[result >= 0])) > 0:
            unique_valid = np.unique(result[result >= 0])
            label_map = {old: new for new, old in enumerate(unique_valid)}
            
            for old, new in label_map.items():
                result[labels == old] = new
        
        return result
    
    def find_optimal_resolution(
        self,
        graph: sparse.csr_matrix,
        resolution_range: Tuple[float, float] = (0.1, 2.0),
        n_steps: int = 10,
        target_n_topics: Optional[int] = None,
    ) -> float:
        """
        Find optimal resolution parameter.
        
        Parameters
        ----------
        graph : sparse.csr_matrix
            Document graph
        resolution_range : tuple
            Range of resolutions to search
        n_steps : int
            Number of steps in search
        target_n_topics : int, optional
            Target number of topics
            
        Returns
        -------
        float
            Optimal resolution
        """
        resolutions = np.linspace(resolution_range[0], resolution_range[1], n_steps)
        best_resolution = self.resolution
        best_score = float('-inf')
        
        for res in resolutions:
            self.resolution = res
            labels = self.fit_predict(graph)
            
            n_topics = len(np.unique(labels[labels >= 0]))
            
            if target_n_topics is not None:
                # Score based on closeness to target
                score = -abs(n_topics - target_n_topics)
            else:
                # Score based on modularity (higher is better)
                score = self._compute_modularity(graph, labels)
            
            if score > best_score:
                best_score = score
                best_resolution = res
        
        self.resolution = best_resolution
        return best_resolution
    
    def _compute_modularity(
        self,
        graph: sparse.csr_matrix,
        labels: np.ndarray,
    ) -> float:
        """Compute modularity of a partition."""
        import igraph as ig
        
        n = graph.shape[0]
        sources, targets = graph.nonzero()
        weights = np.array(graph[sources, targets]).flatten()
        
        g = ig.Graph(directed=False)
        g.add_vertices(n)
        edges = list(zip(sources.tolist(), targets.tolist()))
        g.add_edges(edges)
        g.es['weight'] = weights.tolist()
        
        # Filter out outliers
        valid_labels = labels.copy()
        valid_labels[labels < 0] = 0  # Temporarily assign to cluster 0
        
        return g.modularity(valid_labels.tolist(), weights='weight')


def compute_clustering_stability(
    labels1: np.ndarray,
    labels2: np.ndarray,
) -> float:
    """
    Compute stability between two label assignments using Adjusted Rand Index.
    
    Parameters
    ----------
    labels1 : np.ndarray
        First label assignment
    labels2 : np.ndarray
        Second label assignment
        
    Returns
    -------
    float
        Adjusted Rand Index (0-1, higher is more stable)
    """
    from sklearn.metrics import adjusted_rand_score
    
    # Filter out outliers from both
    mask = (labels1 >= 0) & (labels2 >= 0)
    
    if mask.sum() < 2:
        return 0.0
    
    return adjusted_rand_score(labels1[mask], labels2[mask])
