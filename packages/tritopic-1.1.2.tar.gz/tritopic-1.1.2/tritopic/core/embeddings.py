"""
Embedding Engine Module

Handles document embedding generation with multilingual model selection.
"""

from typing import List, Optional, Union
import numpy as np
import warnings


class EmbeddingEngine:
    """
    Generates document embeddings using Sentence Transformers.
    
    Supports automatic model selection based on language configuration.
    """
    
    # Model recommendations by language
    LANGUAGE_MODELS = {
        'en': 'all-MiniLM-L6-v2',
        'zh': 'BAAI/bge-base-zh-v1.5',
        'multilingual': 'paraphrase-multilingual-mpnet-base-v2',
        'multilingual_small': 'paraphrase-multilingual-MiniLM-L12-v2',
        'multilingual_best': 'BAAI/bge-m3',
    }
    
    def __init__(
        self,
        model_name: str = "auto",
        language: str = "en",
        multilingual: bool = False,
        batch_size: int = 32,
        device: Optional[str] = None,
        show_progress: bool = True,
    ):
        """
        Initialize the embedding engine.
        
        Parameters
        ----------
        model_name : str
            Model name or "auto" for automatic selection
        language : str
            Language code for model selection
        multilingual : bool
            Force multilingual model
        batch_size : int
            Batch size for encoding
        device : str, optional
            Device to use ('cuda', 'cpu', or None for auto)
        show_progress : bool
            Show progress bar during encoding
        """
        self.model_name = model_name
        self.language = language
        self.multilingual = multilingual
        self.batch_size = batch_size
        self.device = device
        self.show_progress = show_progress
        
        self._model = None
        self._resolved_model_name = None
    
    def _resolve_model_name(self) -> str:
        """Resolve the model name based on configuration."""
        if self.model_name != "auto":
            return self.model_name
        
        if self.multilingual:
            return self.LANGUAGE_MODELS['multilingual']
        
        lang = self.language.lower()
        
        if lang == 'en':
            return self.LANGUAGE_MODELS['en']
        elif lang == 'zh':
            return self.LANGUAGE_MODELS['zh']
        elif lang in ['ja', 'ko', 'th', 'vi', 'ar', 'he', 'hi']:
            # Asian and Middle Eastern languages need multilingual
            return self.LANGUAGE_MODELS['multilingual_small']
        elif lang in ['de', 'fr', 'es', 'it', 'pt', 'nl', 'pl', 'ru', 'sv', 'da', 'no', 'fi']:
            # European languages
            return self.LANGUAGE_MODELS['multilingual_small']
        else:
            # Default to multilingual for unknown languages
            return self.LANGUAGE_MODELS['multilingual_small']
    
    def _load_model(self):
        """Load the sentence transformer model."""
        if self._model is not None:
            return
        
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError:
            raise ImportError(
                "sentence-transformers is required for embedding generation. "
                "Install with: pip install sentence-transformers"
            )
        
        self._resolved_model_name = self._resolve_model_name()
        
        try:
            self._model = SentenceTransformer(
                self._resolved_model_name,
                device=self.device
            )
        except Exception as e:
            # Fall back to a known working model
            warnings.warn(
                f"Could not load model '{self._resolved_model_name}': {e}. "
                f"Falling back to 'all-MiniLM-L6-v2'"
            )
            self._resolved_model_name = 'all-MiniLM-L6-v2'
            self._model = SentenceTransformer(
                self._resolved_model_name,
                device=self.device
            )
    
    def encode(
        self,
        documents: List[str],
        normalize: bool = True,
    ) -> np.ndarray:
        """
        Encode documents into embeddings.
        
        Parameters
        ----------
        documents : List[str]
            List of documents to encode
        normalize : bool
            Whether to L2-normalize embeddings
            
        Returns
        -------
        np.ndarray
            Document embeddings of shape (n_documents, embedding_dim)
        """
        self._load_model()
        
        embeddings = self._model.encode(
            documents,
            batch_size=self.batch_size,
            show_progress_bar=self.show_progress,
            convert_to_numpy=True,
            normalize_embeddings=normalize,
        )
        
        return embeddings
    
    @property
    def embedding_dim(self) -> int:
        """Get the embedding dimension."""
        self._load_model()
        return self._model.get_sentence_embedding_dimension()
    
    @property
    def model_info(self) -> dict:
        """Get information about the loaded model."""
        self._load_model()
        return {
            'model_name': self._resolved_model_name,
            'embedding_dim': self.embedding_dim,
            'language': self.language,
            'multilingual': self.multilingual,
        }


def compute_similarity_matrix(
    embeddings: np.ndarray,
    metric: str = "cosine"
) -> np.ndarray:
    """
    Compute pairwise similarity matrix from embeddings.
    
    Parameters
    ----------
    embeddings : np.ndarray
        Document embeddings of shape (n_documents, embedding_dim)
    metric : str
        Similarity metric: "cosine", "euclidean", "dot"
        
    Returns
    -------
    np.ndarray
        Similarity matrix of shape (n_documents, n_documents)
    """
    if metric == "cosine":
        # For normalized embeddings, cosine similarity = dot product
        # Ensure normalization
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        norms[norms == 0] = 1  # Avoid division by zero
        normalized = embeddings / norms
        similarity = np.dot(normalized, normalized.T)
        
    elif metric == "dot":
        similarity = np.dot(embeddings, embeddings.T)
        
    elif metric == "euclidean":
        # Convert Euclidean distance to similarity
        from scipy.spatial.distance import cdist
        distances = cdist(embeddings, embeddings, metric='euclidean')
        similarity = 1 / (1 + distances)
        
    else:
        raise ValueError(f"Unknown metric: {metric}")
    
    # Ensure diagonal is 1 (self-similarity)
    np.fill_diagonal(similarity, 1.0)
    
    # Clip to [0, 1] range
    similarity = np.clip(similarity, 0, 1)
    
    return similarity
