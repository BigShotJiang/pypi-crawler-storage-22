"""
Keyword Extraction Module

Extracts topic keywords using various methods:
- c-TF-IDF (class-based TF-IDF)
- BM25
- KeyBERT (embedding-based)
"""

from typing import List, Dict, Set, Optional, Literal
import numpy as np
from collections import Counter


class KeywordExtractor:
    """
    Extracts keywords for topics using various methods.
    """
    
    def __init__(
        self,
        method: Literal["ctfidf", "bm25", "keybert"] = "ctfidf",
        n_keywords: int = 10,
        ngram_range: tuple = (1, 2),
        min_df: int = 2,
        stopwords: Set[str] = None,
    ):
        """
        Initialize the keyword extractor.
        
        Parameters
        ----------
        method : str
            Extraction method
        n_keywords : int
            Number of keywords per topic
        ngram_range : tuple
            N-gram range
        min_df : int
            Minimum document frequency
        stopwords : set
            Stopwords to exclude
        """
        self.method = method
        self.n_keywords = n_keywords
        self.ngram_range = ngram_range
        self.min_df = min_df
        self.stopwords = stopwords or set()
    
    def extract(
        self,
        documents: List[str],
        labels: np.ndarray,
        tokenized_documents: List[List[str]] = None,
        embeddings: np.ndarray = None,
    ) -> Dict[int, List[str]]:
        """
        Extract keywords for each topic.
        
        Parameters
        ----------
        documents : List[str]
            Original documents
        labels : np.ndarray
            Topic labels
        tokenized_documents : List[List[str]], optional
            Pre-tokenized documents
        embeddings : np.ndarray, optional
            Document embeddings (for KeyBERT)
            
        Returns
        -------
        Dict[int, List[str]]
            Keywords per topic
        """
        if self.method == "ctfidf":
            return self._extract_ctfidf(documents, labels, tokenized_documents)
        elif self.method == "bm25":
            return self._extract_bm25(documents, labels, tokenized_documents)
        elif self.method == "keybert":
            return self._extract_keybert(documents, labels, embeddings)
        else:
            raise ValueError(f"Unknown method: {self.method}")
    
    def _extract_ctfidf(
        self,
        documents: List[str],
        labels: np.ndarray,
        tokenized_documents: List[List[str]] = None,
    ) -> Dict[int, List[str]]:
        """
        Extract keywords using c-TF-IDF.
        
        c-TF-IDF treats each topic as a single "document" by
        concatenating all documents in the topic.
        """
        from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
        
        unique_topics = sorted([t for t in np.unique(labels) if t >= 0])
        
        # Create topic documents (concatenate all docs in each topic)
        topic_docs = []
        topic_ids = []
        
        for topic_id in unique_topics:
            mask = labels == topic_id
            topic_text = ' '.join(documents[i] for i, m in enumerate(mask) if m)
            topic_docs.append(topic_text)
            topic_ids.append(topic_id)
        
        # Vectorize
        vectorizer = CountVectorizer(
            ngram_range=self.ngram_range,
            min_df=1,  # We're using topic-level docs
            stop_words=list(self.stopwords) if self.stopwords else None,
        )
        
        count_matrix = vectorizer.fit_transform(topic_docs)
        feature_names = vectorizer.get_feature_names_out()
        
        # Apply TF-IDF transformation
        tfidf = TfidfTransformer()
        tfidf_matrix = tfidf.fit_transform(count_matrix)
        
        # Extract top keywords per topic
        keywords = {}
        
        for i, topic_id in enumerate(topic_ids):
            scores = tfidf_matrix[i].toarray().flatten()
            top_indices = np.argsort(scores)[::-1]
            
            topic_keywords = []
            for idx in top_indices:
                word = feature_names[idx]
                if len(topic_keywords) >= self.n_keywords:
                    break
                if word.lower() not in self.stopwords:
                    topic_keywords.append(word)
            
            keywords[topic_id] = topic_keywords
        
        return keywords
    
    def _extract_bm25(
        self,
        documents: List[str],
        labels: np.ndarray,
        tokenized_documents: List[List[str]] = None,
    ) -> Dict[int, List[str]]:
        """
        Extract keywords using BM25 scoring.
        """
        unique_topics = sorted([t for t in np.unique(labels) if t >= 0])
        
        # Tokenize if not provided
        if tokenized_documents is None:
            tokenized_documents = [doc.lower().split() for doc in documents]
        
        # Filter stopwords
        tokenized_documents = [
            [w for w in tokens if w not in self.stopwords]
            for tokens in tokenized_documents
        ]
        
        keywords = {}
        
        for topic_id in unique_topics:
            mask = labels == topic_id
            topic_tokens = [tokenized_documents[i] for i, m in enumerate(mask) if m]
            other_tokens = [tokenized_documents[i] for i, m in enumerate(mask) if not m]
            
            # Count term frequencies in topic
            topic_tf = Counter()
            for tokens in topic_tokens:
                topic_tf.update(tokens)
            
            # Count document frequencies across all docs
            all_tokens = tokenized_documents
            df = Counter()
            for tokens in all_tokens:
                df.update(set(tokens))
            
            # Compute BM25-like scores
            N = len(all_tokens)
            avgdl = np.mean([len(t) for t in all_tokens])
            k1, b = 1.5, 0.75
            
            scores = {}
            topic_len = sum(len(t) for t in topic_tokens)
            
            for term, freq in topic_tf.items():
                if df[term] < self.min_df:
                    continue
                
                idf = np.log((N - df[term] + 0.5) / (df[term] + 0.5) + 1)
                tf_normalized = freq * (k1 + 1) / (freq + k1 * (1 - b + b * topic_len / avgdl))
                scores[term] = idf * tf_normalized
            
            # Get top keywords
            sorted_terms = sorted(scores.items(), key=lambda x: x[1], reverse=True)
            keywords[topic_id] = [term for term, _ in sorted_terms[:self.n_keywords]]
        
        return keywords
    
    def _extract_keybert(
        self,
        documents: List[str],
        labels: np.ndarray,
        embeddings: np.ndarray = None,
    ) -> Dict[int, List[str]]:
        """
        Extract keywords using KeyBERT (embedding-based).
        """
        try:
            from keybert import KeyBERT
        except ImportError:
            # Fall back to c-TF-IDF
            import warnings
            warnings.warn("KeyBERT not installed, falling back to c-TF-IDF")
            return self._extract_ctfidf(documents, labels, None)
        
        unique_topics = sorted([t for t in np.unique(labels) if t >= 0])
        
        # Initialize KeyBERT
        kw_model = KeyBERT()
        
        keywords = {}
        
        for topic_id in unique_topics:
            mask = labels == topic_id
            topic_text = ' '.join(documents[i] for i, m in enumerate(mask) if m)
            
            # Extract keywords
            kw_results = kw_model.extract_keywords(
                topic_text,
                keyphrase_ngram_range=self.ngram_range,
                stop_words=list(self.stopwords) if self.stopwords else None,
                top_n=self.n_keywords,
            )
            
            keywords[topic_id] = [kw for kw, _ in kw_results]
        
        return keywords


def compute_keyword_scores(
    keywords: Dict[int, List[str]],
    documents: List[str],
    labels: np.ndarray,
) -> Dict[int, List[tuple]]:
    """
    Compute scores for keywords based on their discriminative power.
    
    Returns keywords with their scores.
    """
    # Get document frequencies per topic
    topic_dfs = {}
    unique_topics = sorted([t for t in np.unique(labels) if t >= 0])
    
    for topic_id in unique_topics:
        mask = labels == topic_id
        topic_docs = [documents[i].lower() for i, m in enumerate(mask) if m]
        
        df = Counter()
        for doc in topic_docs:
            words = set(doc.split())
            df.update(words)
        
        topic_dfs[topic_id] = df
    
    # Compute scores
    scored_keywords = {}
    
    for topic_id, topic_keywords in keywords.items():
        scored = []
        topic_df = topic_dfs[topic_id]
        n_topic_docs = sum(labels == topic_id)
        
        for keyword in topic_keywords:
            # TF in topic
            tf = topic_df.get(keyword.lower(), 0) / n_topic_docs
            
            # DF across other topics (for IDF-like scoring)
            other_df = sum(
                topic_dfs[t].get(keyword.lower(), 0)
                for t in unique_topics if t != topic_id
            )
            n_other_docs = sum(labels != topic_id)
            
            if n_other_docs > 0:
                other_ratio = other_df / n_other_docs
                # Discriminative score
                score = tf / (other_ratio + 0.1)
            else:
                score = tf
            
            scored.append((keyword, round(score, 4)))
        
        scored_keywords[topic_id] = scored
    
    return scored_keywords
