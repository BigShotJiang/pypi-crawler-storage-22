"""
TriTopic Multilingual Module

Provides language detection, tokenization, and stopwords for 60+ languages.
"""

from .detection import (
    detect_language,
    detect_corpus_language,
    normalize_language_code,
    LANGUAGE_ALIASES,
)

from .tokenizers import (
    TokenizerFactory,
    tokenize_documents,
)

from .stopwords import (
    get_stopwords,
    get_available_languages,
    STOPWORDS,
)

__all__ = [
    # Detection
    'detect_language',
    'detect_corpus_language',
    'normalize_language_code',
    'LANGUAGE_ALIASES',
    # Tokenizers
    'TokenizerFactory',
    'tokenize_documents',
    # Stopwords
    'get_stopwords',
    'get_available_languages',
    'STOPWORDS',
]
