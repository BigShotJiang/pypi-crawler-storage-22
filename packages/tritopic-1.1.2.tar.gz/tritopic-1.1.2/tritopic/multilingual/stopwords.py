"""
Multilingual Stopwords Module

Provides stopword lists for 60+ languages.
"""

from typing import List, Set, Optional
import warnings


# Stopword lists for major languages
# These are commonly used function words that don't carry topical meaning

STOPWORDS = {
    'en': {
        'a', 'an', 'the', 'and', 'or', 'but', 'if', 'then', 'else', 'when',
        'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into',
        'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from',
        'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again',
        'further', 'once', 'here', 'there', 'all', 'each', 'few', 'more',
        'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own',
        'same', 'so', 'than', 'too', 'very', 'just', 'can', 'will', 'should',
        'now', 'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves',
        'you', 'your', 'yours', 'yourself', 'yourselves', 'he', 'him', 'his',
        'himself', 'she', 'her', 'hers', 'herself', 'it', 'its', 'itself',
        'they', 'them', 'their', 'theirs', 'themselves', 'what', 'which',
        'who', 'whom', 'this', 'that', 'these', 'those', 'am', 'is', 'are',
        'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having',
        'do', 'does', 'did', 'doing', 'would', 'could', 'ought', 'might',
        'must', 'shall', 'need', 'dare', 'as', 'of', 'also', 'how', 'why',
        'where', 'because', 'while', 'although', 'though', 'however', 'therefore',
        'get', 'got', 'getting', 'make', 'made', 'making', 'go', 'going',
        'went', 'gone', 'come', 'came', 'coming', 'take', 'took', 'taking',
        'use', 'used', 'using', 'know', 'known', 'see', 'seen', 'want',
        'think', 'like', 'even', 'well', 'back', 'way', 'much', 'many',
        'may', 'say', 'said', 'one', 'two', 'first', 'new', 'time', 'year',
        'people', 'part', 'still', 'really', 'actually', 'something', 'anything',
    },
    
    'de': {
        'der', 'die', 'das', 'den', 'dem', 'des', 'ein', 'eine', 'einer',
        'einem', 'einen', 'eines', 'und', 'oder', 'aber', 'wenn', 'dann',
        'weil', 'dass', 'daß', 'ob', 'als', 'wie', 'was', 'wer', 'wo',
        'wann', 'warum', 'welche', 'welcher', 'welches', 'welchen', 'welchem',
        'ich', 'du', 'er', 'sie', 'es', 'wir', 'ihr', 'mich', 'dich', 'sich',
        'mir', 'dir', 'ihm', 'uns', 'euch', 'ihnen', 'mein', 'dein', 'sein',
        'unser', 'euer', 'meine', 'deine', 'seine', 'unsere', 'eure', 'ihre',
        'ist', 'sind', 'war', 'waren', 'bin', 'bist', 'seid', 'sein', 'haben',
        'hat', 'hatte', 'hatten', 'habe', 'hast', 'werden', 'wird', 'wurde',
        'wurden', 'werde', 'wirst', 'können', 'kann', 'konnte', 'konnten',
        'müssen', 'muss', 'musste', 'mussten', 'sollen', 'soll', 'sollte',
        'wollen', 'will', 'wollte', 'dürfen', 'darf', 'durfte', 'mögen',
        'mag', 'mochte', 'möchte', 'für', 'mit', 'ohne', 'gegen', 'durch',
        'bei', 'nach', 'von', 'aus', 'zu', 'bis', 'über', 'unter', 'vor',
        'hinter', 'neben', 'zwischen', 'in', 'an', 'auf', 'um', 'nicht',
        'kein', 'keine', 'keiner', 'keinem', 'keinen', 'auch', 'nur', 'noch',
        'schon', 'immer', 'wieder', 'sehr', 'mehr', 'viel', 'hier', 'dort',
        'jetzt', 'heute', 'gestern', 'morgen', 'also', 'so', 'doch', 'ja',
        'nein', 'alle', 'alles', 'andere', 'anderen', 'anderer', 'anderem',
        'dieser', 'diese', 'dieses', 'diesem', 'diesen', 'jener', 'jene',
        'jenes', 'jenem', 'jenen', 'man', 'etwas', 'nichts', 'selbst',
        'gibt', 'gab', 'geben', 'macht', 'machen', 'geht', 'gehen', 'kommt',
        'kommen', 'sagt', 'sagen', 'sagte', 'steht', 'liegt', 'zwei', 'drei',
    },
    
    'fr': {
        'le', 'la', 'les', 'un', 'une', 'des', 'du', 'de', 'et', 'ou', 'mais',
        'donc', 'car', 'ni', 'que', 'qui', 'quoi', 'dont', 'où', 'si', 'quand',
        'comme', 'comment', 'pourquoi', 'ce', 'cette', 'ces', 'cet', 'celui',
        'celle', 'ceux', 'celles', 'je', 'tu', 'il', 'elle', 'on', 'nous',
        'vous', 'ils', 'elles', 'me', 'te', 'se', 'lui', 'leur', 'nous', 'vous',
        'mon', 'ma', 'mes', 'ton', 'ta', 'tes', 'son', 'sa', 'ses', 'notre',
        'nos', 'votre', 'vos', 'leur', 'leurs', 'être', 'suis', 'es', 'est',
        'sommes', 'êtes', 'sont', 'étais', 'était', 'étions', 'étiez', 'étaient',
        'avoir', 'ai', 'as', 'a', 'avons', 'avez', 'ont', 'avais', 'avait',
        'faire', 'fait', 'fais', 'font', 'faisais', 'aller', 'vais', 'vas',
        'va', 'allons', 'allez', 'vont', 'pouvoir', 'peux', 'peut', 'pouvons',
        'peuvent', 'vouloir', 'veux', 'veut', 'voulons', 'veulent', 'devoir',
        'dois', 'doit', 'devons', 'doivent', 'savoir', 'sais', 'sait', 'savons',
        'pour', 'avec', 'sans', 'dans', 'sur', 'sous', 'par', 'entre', 'vers',
        'chez', 'avant', 'après', 'depuis', 'pendant', 'contre', 'ne', 'pas',
        'plus', 'moins', 'très', 'bien', 'aussi', 'encore', 'toujours', 'jamais',
        'tout', 'tous', 'toute', 'toutes', 'autre', 'autres', 'même', 'mêmes',
        'ici', 'là', 'y', 'en', 'alors', 'ainsi', 'cela', 'ça', 'voici', 'voilà',
    },
    
    'es': {
        'el', 'la', 'los', 'las', 'un', 'una', 'unos', 'unas', 'lo', 'al', 'del',
        'y', 'o', 'pero', 'porque', 'que', 'quien', 'cual', 'cuyo', 'donde',
        'cuando', 'como', 'si', 'aunque', 'mientras', 'este', 'esta', 'estos',
        'estas', 'ese', 'esa', 'esos', 'esas', 'aquel', 'aquella', 'aquellos',
        'yo', 'tú', 'él', 'ella', 'usted', 'nosotros', 'vosotros', 'ellos',
        'ellas', 'ustedes', 'me', 'te', 'se', 'le', 'les', 'nos', 'os',
        'mi', 'mis', 'tu', 'tus', 'su', 'sus', 'nuestro', 'nuestra', 'nuestros',
        'vuestro', 'vuestra', 'vuestros', 'ser', 'soy', 'eres', 'es', 'somos',
        'sois', 'son', 'era', 'eras', 'éramos', 'eran', 'fui', 'fue', 'fuimos',
        'estar', 'estoy', 'estás', 'está', 'estamos', 'están', 'estaba',
        'haber', 'he', 'has', 'ha', 'hemos', 'habéis', 'han', 'había',
        'tener', 'tengo', 'tienes', 'tiene', 'tenemos', 'tienen', 'tenía',
        'hacer', 'hago', 'haces', 'hace', 'hacemos', 'hacen', 'hacía',
        'poder', 'puedo', 'puedes', 'puede', 'podemos', 'pueden', 'podía',
        'para', 'por', 'con', 'sin', 'sobre', 'entre', 'hasta', 'desde',
        'de', 'en', 'a', 'ante', 'bajo', 'contra', 'hacia', 'según',
        'no', 'ni', 'sí', 'también', 'más', 'menos', 'muy', 'ya', 'aún',
        'todavía', 'siempre', 'nunca', 'aquí', 'ahí', 'allí', 'así', 'bien',
        'todo', 'toda', 'todos', 'todas', 'algo', 'alguien', 'nada', 'nadie',
        'otro', 'otra', 'otros', 'otras', 'mismo', 'misma', 'mismos', 'mismas',
    },
    
    'it': {
        'il', 'lo', 'la', 'i', 'gli', 'le', 'un', 'uno', 'una', 'dei', 'degli',
        'delle', 'del', 'dello', 'della', 'e', 'o', 'ma', 'però', 'perché',
        'che', 'chi', 'cui', 'quale', 'quali', 'dove', 'quando', 'come', 'se',
        'questo', 'questa', 'questi', 'queste', 'quello', 'quella', 'quelli',
        'io', 'tu', 'lui', 'lei', 'noi', 'voi', 'loro', 'esso', 'essa', 'essi',
        'mi', 'ti', 'ci', 'vi', 'si', 'lo', 'la', 'li', 'le', 'ne', 'gli',
        'mio', 'mia', 'miei', 'mie', 'tuo', 'tua', 'tuoi', 'tue', 'suo', 'sua',
        'nostro', 'nostra', 'nostri', 'nostre', 'vostro', 'vostra', 'loro',
        'essere', 'sono', 'sei', 'è', 'siamo', 'siete', 'era', 'ero', 'erano',
        'avere', 'ho', 'hai', 'ha', 'abbiamo', 'avete', 'hanno', 'aveva', 'avevo',
        'fare', 'faccio', 'fai', 'fa', 'facciamo', 'fanno', 'faceva', 'fatto',
        'potere', 'posso', 'puoi', 'può', 'possiamo', 'possono', 'poteva',
        'volere', 'voglio', 'vuoi', 'vuole', 'vogliamo', 'vogliono', 'voleva',
        'dovere', 'devo', 'devi', 'deve', 'dobbiamo', 'devono', 'doveva',
        'per', 'con', 'senza', 'su', 'in', 'da', 'a', 'tra', 'fra', 'di',
        'non', 'né', 'sì', 'anche', 'più', 'meno', 'molto', 'poco', 'già',
        'ancora', 'sempre', 'mai', 'qui', 'qua', 'là', 'lì', 'così', 'bene',
        'tutto', 'tutta', 'tutti', 'tutte', 'altro', 'altra', 'altri', 'altre',
    },
    
    'pt': {
        'o', 'a', 'os', 'as', 'um', 'uma', 'uns', 'umas', 'do', 'da', 'dos',
        'das', 'no', 'na', 'nos', 'nas', 'ao', 'à', 'aos', 'às', 'pelo', 'pela',
        'e', 'ou', 'mas', 'porém', 'porque', 'que', 'quem', 'qual', 'cujo',
        'onde', 'quando', 'como', 'se', 'este', 'esta', 'estes', 'estas',
        'esse', 'essa', 'esses', 'essas', 'aquele', 'aquela', 'aqueles',
        'eu', 'tu', 'ele', 'ela', 'nós', 'vós', 'eles', 'elas', 'você', 'vocês',
        'me', 'te', 'se', 'lhe', 'nos', 'vos', 'lhes', 'o', 'a', 'os', 'as',
        'meu', 'minha', 'meus', 'minhas', 'teu', 'tua', 'seu', 'sua', 'nosso',
        'ser', 'sou', 'és', 'é', 'somos', 'sois', 'são', 'era', 'eras', 'eram',
        'estar', 'estou', 'estás', 'está', 'estamos', 'estão', 'estava',
        'ter', 'tenho', 'tens', 'tem', 'temos', 'têm', 'tinha', 'tinham',
        'haver', 'hei', 'hás', 'há', 'havemos', 'hão', 'havia', 'houve',
        'fazer', 'faço', 'fazes', 'faz', 'fazemos', 'fazem', 'fazia', 'fez',
        'poder', 'posso', 'podes', 'pode', 'podemos', 'podem', 'podia',
        'para', 'por', 'com', 'sem', 'sobre', 'entre', 'até', 'desde', 'de',
        'em', 'a', 'ante', 'sob', 'contra', 'não', 'nem', 'sim', 'também',
        'mais', 'menos', 'muito', 'pouco', 'já', 'ainda', 'sempre', 'nunca',
        'aqui', 'aí', 'ali', 'assim', 'bem', 'todo', 'toda', 'todos', 'todas',
    },
    
    'nl': {
        'de', 'het', 'een', 'en', 'van', 'in', 'is', 'op', 'te', 'dat', 'die',
        'voor', 'zijn', 'met', 'niet', 'aan', 'er', 'maar', 'om', 'ook', 'als',
        'dan', 'of', 'naar', 'bij', 'nog', 'wel', 'geen', 'zou', 'kunnen',
        'worden', 'heeft', 'hebben', 'dit', 'door', 'over', 'tot', 'uit', 'al',
        'wat', 'wie', 'waar', 'wanneer', 'waarom', 'hoe', 'ik', 'je', 'jij',
        'hij', 'zij', 'wij', 'jullie', 'u', 'mij', 'hem', 'haar', 'ons', 'hun',
        'mijn', 'jouw', 'zijn', 'haar', 'uw', 'onze', 'hun', 'deze', 'dit',
        'die', 'dat', 'welke', 'elk', 'ieder', 'alle', 'veel', 'meer', 'meest',
        'zo', 'zeer', 'hier', 'daar', 'nu', 'toen', 'vaak', 'altijd', 'nooit',
    },
    
    'ru': {
        'и', 'в', 'не', 'на', 'я', 'что', 'он', 'с', 'со', 'как', 'а', 'то',
        'все', 'она', 'так', 'его', 'но', 'да', 'ты', 'к', 'у', 'же', 'вы',
        'за', 'бы', 'по', 'только', 'её', 'мне', 'было', 'вот', 'от', 'меня',
        'ещё', 'нет', 'о', 'из', 'ему', 'теперь', 'когда', 'уже', 'вам', 'ни',
        'быть', 'был', 'была', 'были', 'есть', 'будет', 'для', 'этот', 'эта',
        'эти', 'этого', 'этой', 'мы', 'они', 'их', 'им', 'ней', 'него', 'нас',
        'себя', 'себе', 'свой', 'свою', 'своего', 'своей', 'кто', 'где', 'куда',
        'почему', 'зачем', 'который', 'которая', 'которое', 'которые', 'или',
        'тоже', 'также', 'может', 'надо', 'нужно', 'очень', 'даже', 'чем',
        'при', 'под', 'над', 'между', 'через', 'после', 'перед', 'более',
        'менее', 'здесь', 'там', 'тогда', 'сейчас', 'всегда', 'никогда',
    },
    
    'zh': {
        '的', '是', '在', '不', '了', '有', '和', '人', '这', '中', '大', '为',
        '上', '个', '国', '我', '以', '要', '他', '时', '来', '用', '们', '生',
        '到', '作', '地', '于', '出', '就', '分', '对', '成', '会', '可', '主',
        '发', '年', '动', '同', '工', '也', '能', '下', '过', '子', '说', '产',
        '种', '面', '而', '方', '后', '多', '定', '行', '学', '法', '所', '民',
        '得', '经', '十', '三', '之', '进', '着', '等', '部', '度', '家', '电',
        '力', '里', '如', '水', '化', '高', '自', '二', '理', '起', '小', '物',
        '现', '实', '加', '量', '都', '两', '体', '制', '机', '当', '使', '点',
        '从', '业', '本', '去', '把', '性', '好', '应', '开', '它', '合', '还',
        '因', '由', '其', '些', '然', '前', '外', '天', '政', '四', '日', '那',
        '社', '义', '事', '平', '形', '相', '全', '表', '间', '样', '与', '关',
        '各', '重', '新', '线', '内', '数', '正', '心', '反', '你', '明', '看',
        '原', '又', '么', '利', '比', '或', '但', '质', '气', '第', '向', '道',
        '命', '此', '变', '条', '只', '没', '结', '解', '问', '意', '建', '月',
        '公', '无', '系', '军', '很', '情', '最', '何', '果', '却', '将', '吗',
        '您', '她', '吧', '啊', '呢', '哪', '谁', '怎', '么样', '这样', '那样',
    },
    
    'ja': {
        'の', 'に', 'は', 'を', 'た', 'が', 'で', 'て', 'と', 'し', 'れ', 'さ',
        'ある', 'いる', 'も', 'する', 'から', 'な', 'こと', 'として', 'い', 'や',
        'れる', 'など', 'なっ', 'ない', 'この', 'ため', 'その', 'あっ', 'よう',
        'また', 'もの', 'という', 'あり', 'まで', 'られ', 'なる', 'へ', 'か',
        'だ', 'これ', 'によって', 'により', 'おり', 'より', 'による', 'ず',
        'なり', 'られる', 'において', 'ば', 'なかっ', 'なく', 'しかし', 'について',
        'せ', 'だっ', 'その後', 'できる', 'それ', 'う', 'ので', 'なお', 'のみ',
        'でき', 'き', 'つ', 'における', 'および', 'いう', 'さらに', 'でも',
        'ら', 'たり', 'その他', 'に関する', 'たち', 'ます', 'ん', 'なら', 'に対して',
        'わたし', 'あなた', 'かれ', 'かのじょ', 'わたしたち', 'です', 'ました',
    },
    
    'ko': {
        '이', '그', '저', '것', '수', '등', '들', '및', '에', '의', '가', '을',
        '를', '으로', '로', '에서', '와', '과', '는', '은', '도', '에게', '까지',
        '부터', '만', '뿐', '다', '하다', '있다', '없다', '되다', '이다', '아니다',
        '같다', '보다', '위하다', '대하다', '통하다', '그리고', '그러나', '그래서',
        '그런데', '하지만', '또한', '또는', '즉', '곧', '만약', '비록', '아무리',
        '나', '너', '우리', '저희', '그들', '이것', '그것', '저것', '여기', '거기',
        '저기', '이런', '그런', '저런', '어떤', '무슨', '어느', '언제', '어디',
        '왜', '어떻게', '얼마나', '매우', '아주', '너무', '정말', '참', '꽤',
    },
    
    'ar': {
        'في', 'من', 'على', 'إلى', 'عن', 'مع', 'هذا', 'هذه', 'ذلك', 'تلك', 'التي',
        'الذي', 'الذين', 'اللذين', 'اللتين', 'اللواتي', 'هو', 'هي', 'هم', 'هن',
        'أنا', 'أنت', 'أنتم', 'أنتن', 'نحن', 'كان', 'كانت', 'كانوا', 'يكون',
        'تكون', 'ليس', 'ليست', 'ليسوا', 'إن', 'أن', 'لأن', 'لكن', 'بل', 'أو',
        'و', 'ف', 'ثم', 'أي', 'كل', 'بعض', 'غير', 'قد', 'لقد', 'سوف', 'قبل',
        'بعد', 'فوق', 'تحت', 'بين', 'حول', 'ضد', 'خلال', 'عند', 'منذ', 'حتى',
        'لا', 'نعم', 'ما', 'ماذا', 'من', 'أين', 'متى', 'كيف', 'لماذا', 'كم',
        'هنا', 'هناك', 'الآن', 'أيضا', 'فقط', 'جدا', 'كثير', 'قليل', 'كبير',
    },
    
    'tr': {
        've', 'bir', 'bu', 'da', 'de', 'için', 'ile', 'ne', 'var', 'daha', 'çok',
        'en', 'gibi', 'o', 'ama', 'ancak', 'fakat', 'lakin', 'veya', 'ya', 'hem',
        'ki', 'kadar', 'sonra', 'önce', 'şu', 'hangi', 'nasıl', 'neden', 'nerede',
        'ben', 'sen', 'biz', 'siz', 'onlar', 'benim', 'senin', 'onun', 'bizim',
        'bana', 'sana', 'ona', 'bize', 'size', 'beni', 'seni', 'onu', 'bizi',
        'olmak', 'oldu', 'olur', 'olan', 'olarak', 'etmek', 'etti', 'yapmak',
        'yaptı', 'gelmek', 'geldi', 'gitmek', 'gitti', 'vermek', 'verdi', 'almak',
        'aldı', 'demek', 'dedi', 'görmek', 'gördü', 'bilmek', 'bildi', 'istemek',
        'üzerinde', 'üzerine', 'altında', 'içinde', 'dışında', 'arasında', 'karşı',
        'değil', 'evet', 'hayır', 'belki', 'artık', 'hala', 'henüz', 'sadece',
    },
    
    'pl': {
        'i', 'w', 'nie', 'na', 'do', 'że', 'to', 'z', 'co', 'jak', 'ale', 'o',
        'się', 'tak', 'po', 'za', 'już', 'od', 'jest', 'by', 'tylko', 'być',
        'jeszcze', 'który', 'która', 'które', 'tego', 'tej', 'tym', 'ten', 'ta',
        'te', 'jego', 'jej', 'ich', 'ja', 'ty', 'on', 'ona', 'ono', 'my', 'wy',
        'oni', 'one', 'mnie', 'ciebie', 'go', 'ją', 'nas', 'was', 'im', 'mój',
        'twój', 'swój', 'nasz', 'wasz', 'gdzie', 'kiedy', 'dlaczego', 'czy',
        'lub', 'albo', 'ani', 'więc', 'jednak', 'także', 'również', 'bardzo',
        'może', 'można', 'musi', 'powinien', 'chce', 'był', 'była', 'było',
        'będzie', 'przy', 'przez', 'przed', 'nad', 'pod', 'między', 'tutaj',
        'tam', 'teraz', 'wtedy', 'zawsze', 'nigdy', 'często', 'rzadko', 'wszystko',
    },
    
    'sv': {
        'och', 'i', 'att', 'det', 'som', 'en', 'på', 'är', 'av', 'för', 'med',
        'till', 'den', 'har', 'de', 'inte', 'om', 'ett', 'men', 'var', 'jag',
        'vi', 'kan', 'så', 'han', 'hon', 'eller', 'vad', 'finns', 'då', 'när',
        'nu', 'ska', 'efter', 'från', 'också', 'bara', 'vid', 'sig', 'sin',
        'sina', 'sitt', 'dig', 'du', 'mig', 'min', 'mitt', 'mina', 'ditt',
        'dina', 'honom', 'henne', 'dem', 'detta', 'denna', 'dessa', 'här',
        'där', 'hur', 'varför', 'vilken', 'vilket', 'vilka', 'vem', 'blev',
        'bli', 'blir', 'blivit', 'hade', 'ha', 'haft', 'vara', 'varit', 'vore',
        'skulle', 'kunde', 'ville', 'måste', 'får', 'fick', 'går', 'gick',
        'kommer', 'kom', 'tar', 'tog', 'ger', 'gav', 'ser', 'såg', 'säger',
        'sa', 'gör', 'gjorde', 'över', 'under', 'mellan', 'genom', 'mot',
    },
    
    'da': {
        'og', 'i', 'at', 'det', 'er', 'en', 'den', 'til', 'på', 'af', 'for',
        'med', 'som', 'de', 'har', 'ikke', 'var', 'et', 'om', 'men', 'jeg',
        'vi', 'kan', 'han', 'hun', 'eller', 'hvad', 'så', 'da', 'nu', 'vil',
        'efter', 'fra', 'også', 'kun', 'sig', 'sin', 'sit', 'sine', 'dig',
        'du', 'mig', 'min', 'mit', 'mine', 'dit', 'dine', 'ham', 'hende',
        'dem', 'dette', 'denne', 'disse', 'her', 'der', 'hvor', 'hvorfor',
        'hvilken', 'hvilket', 'hvilke', 'hvem', 'blev', 'blive', 'bliver',
        'havde', 'have', 'haft', 'være', 'været', 'skulle', 'kunne', 'ville',
        'må', 'får', 'fik', 'går', 'gik', 'kommer', 'kom', 'tager', 'tog',
        'giver', 'gav', 'ser', 'så', 'siger', 'sagde', 'gør', 'gjorde',
        'over', 'under', 'mellem', 'gennem', 'mod', 'hos', 'uden', 'inden',
    },
    
    'fi': {
        'ja', 'on', 'ei', 'ole', 'se', 'että', 'joka', 'hän', 'oli', 'mutta',
        'niin', 'kun', 'ovat', 'tai', 'tämä', 'ne', 'voi', 'kuin', 'nyt',
        'jo', 'jos', 'sitten', 'myös', 'olla', 'minä', 'sinä', 'me', 'te',
        'he', 'sitä', 'mitä', 'mikä', 'kuka', 'missä', 'milloin', 'miksi',
        'miten', 'paljon', 'vain', 'vielä', 'aina', 'kaikki', 'tässä', 'siellä',
        'täällä', 'tänne', 'sinne', 'mistä', 'mihin', 'jossa', 'johon', 'josta',
        'kanssa', 'ilman', 'mukaan', 'kautta', 'kohti', 'vastaan', 'ennen',
        'jälkeen', 'yli', 'ali', 'välillä', 'läpi', 'ympäri', 'koska', 'vaikka',
    },
    
    'no': {
        'og', 'i', 'at', 'det', 'er', 'en', 'den', 'til', 'på', 'av', 'for',
        'med', 'som', 'de', 'har', 'ikke', 'var', 'et', 'om', 'men', 'jeg',
        'vi', 'kan', 'han', 'hun', 'eller', 'hva', 'så', 'da', 'nå', 'vil',
        'etter', 'fra', 'også', 'bare', 'seg', 'sin', 'sitt', 'sine', 'deg',
        'du', 'meg', 'min', 'mitt', 'mine', 'ditt', 'dine', 'ham', 'henne',
        'dem', 'dette', 'denne', 'disse', 'her', 'der', 'hvor', 'hvorfor',
        'hvilken', 'hvilket', 'hvilke', 'hvem', 'ble', 'bli', 'blir', 'blitt',
        'hadde', 'ha', 'hatt', 'være', 'vært', 'skulle', 'kunne', 'ville',
        'må', 'får', 'fikk', 'går', 'gikk', 'kommer', 'kom', 'tar', 'tok',
        'gir', 'gav', 'ser', 'så', 'sier', 'sa', 'gjør', 'gjorde', 'over',
        'under', 'mellom', 'gjennom', 'mot', 'hos', 'uten', 'innen', 'ved',
    },
    
    'el': {
        'και', 'το', 'τη', 'της', 'τον', 'του', 'των', 'τα', 'να', 'με', 'για',
        'είναι', 'στο', 'στη', 'στον', 'στην', 'από', 'ως', 'που', 'ένα', 'μια',
        'ο', 'η', 'οι', 'θα', 'δεν', 'αλλά', 'αν', 'ή', 'όταν', 'πως', 'τι',
        'ποιος', 'πού', 'πότε', 'γιατί', 'πώς', 'εγώ', 'εσύ', 'αυτός', 'αυτή',
        'αυτό', 'εμείς', 'εσείς', 'αυτοί', 'αυτές', 'αυτά', 'μου', 'σου', 'του',
        'της', 'μας', 'σας', 'τους', 'είχε', 'έχει', 'έχουν', 'είχαν', 'ήταν',
        'είμαι', 'είσαι', 'είμαστε', 'είστε', 'πολύ', 'λίγο', 'όλα', 'κάθε',
        'μόνο', 'εδώ', 'εκεί', 'τώρα', 'τότε', 'πάντα', 'ποτέ', 'ακόμα', 'πια',
    },
    
    'he': {
        'של', 'את', 'על', 'הוא', 'היא', 'הם', 'הן', 'אני', 'אתה', 'את', 'אנחנו',
        'אתם', 'אתן', 'זה', 'זאת', 'אלה', 'אלו', 'לא', 'כן', 'גם', 'או', 'אבל',
        'אם', 'כי', 'כאשר', 'מה', 'מי', 'איפה', 'מתי', 'למה', 'איך', 'כמה',
        'היה', 'היתה', 'היו', 'יהיה', 'תהיה', 'יהיו', 'להיות', 'יש', 'אין',
        'עם', 'בלי', 'אל', 'מן', 'אצל', 'בין', 'לפני', 'אחרי', 'מעל', 'מתחת',
        'כל', 'רק', 'עוד', 'כבר', 'עכשיו', 'אז', 'תמיד', 'לעולם', 'פה', 'שם',
        'אחר', 'אחרת', 'אחרים', 'אחרות', 'עצמו', 'עצמה', 'עצמם', 'עצמן', 'יותר',
        'פחות', 'הרבה', 'מעט', 'מאוד', 'קצת', 'טוב', 'רע', 'גדול', 'קטן', 'חדש',
    },
    
    'hi': {
        'का', 'के', 'की', 'को', 'से', 'में', 'है', 'हैं', 'था', 'थी', 'थे',
        'और', 'या', 'पर', 'इस', 'उस', 'जो', 'यह', 'वह', 'कि', 'जब', 'तो',
        'भी', 'ने', 'हो', 'कर', 'एक', 'अपने', 'होता', 'होती', 'करना', 'करता',
        'करती', 'करते', 'जैसे', 'लिए', 'साथ', 'बाद', 'पहले', 'अगर', 'लेकिन',
        'कोई', 'कुछ', 'सब', 'यहाँ', 'वहाँ', 'कहाँ', 'कब', 'क्यों', 'कैसे',
        'मैं', 'तुम', 'हम', 'आप', 'वे', 'मेरा', 'तेरा', 'उसका', 'हमारा', 'आपका',
        'बहुत', 'कम', 'ज्यादा', 'अब', 'फिर', 'हमेशा', 'कभी', 'सिर्फ', 'बस',
    },
    
    'th': {
        'ที่', 'และ', 'ใน', 'ของ', 'จะ', 'ได้', 'เป็น', 'มี', 'ไม่', 'ว่า', 'นี้',
        'ให้', 'กับ', 'แต่', 'หรือ', 'ก็', 'ซึ่ง', 'โดย', 'จาก', 'ถึง', 'เมื่อ',
        'แล้ว', 'อยู่', 'ทำ', 'คือ', 'นั้น', 'เรา', 'คุณ', 'ผม', 'ฉัน', 'เขา',
        'เธอ', 'พวกเรา', 'พวกเขา', 'มัน', 'อะไร', 'ใคร', 'ไหน', 'เมื่อไร', 'ทำไม',
        'อย่างไร', 'เท่าไร', 'มาก', 'น้อย', 'ทุก', 'บาง', 'แค่', 'เพียง', 'ยัง',
        'เคย', 'ต้อง', 'ควร', 'อาจ', 'คง', 'ตรง', 'ข้าง', 'บน', 'ล่าง', 'ระหว่าง',
    },
    
    'vi': {
        'và', 'của', 'là', 'có', 'trong', 'được', 'cho', 'không', 'một', 'những',
        'này', 'các', 'với', 'để', 'từ', 'khi', 'đã', 'như', 'về', 'đến', 'nếu',
        'nhưng', 'hoặc', 'mà', 'vì', 'cũng', 'còn', 'sẽ', 'bởi', 'theo', 'tại',
        'qua', 'rằng', 'trên', 'dưới', 'giữa', 'sau', 'trước', 'tôi', 'bạn',
        'chúng tôi', 'họ', 'anh', 'chị', 'ông', 'bà', 'nó', 'gì', 'ai', 'đâu',
        'nào', 'sao', 'bao nhiêu', 'rất', 'nhiều', 'ít', 'mỗi', 'tất cả', 'chỉ',
        'đây', 'đó', 'kia', 'bây giờ', 'luôn', 'thường', 'hay', 'lại', 'nên',
    },
    
    'id': {
        'yang', 'dan', 'di', 'ini', 'itu', 'dengan', 'untuk', 'tidak', 'dari',
        'dalam', 'akan', 'pada', 'juga', 'ke', 'karena', 'atau', 'ada', 'mereka',
        'sudah', 'saya', 'kami', 'kita', 'ia', 'dia', 'anda', 'adalah', 'sebagai',
        'oleh', 'bisa', 'dapat', 'telah', 'lebih', 'tersebut', 'bahwa', 'maka',
        'bila', 'ketika', 'jika', 'namun', 'tetapi', 'hanya', 'masih', 'apa',
        'siapa', 'mana', 'kapan', 'mengapa', 'bagaimana', 'berapa', 'sangat',
        'banyak', 'sedikit', 'semua', 'setiap', 'sini', 'sana', 'sekarang',
        'kemudian', 'selalu', 'sering', 'pernah', 'harus', 'perlu', 'boleh',
    },
    
    'cs': {
        'a', 'i', 'v', 'na', 'že', 'je', 'se', 'to', 'z', 's', 'do', 'o', 'pro',
        'ale', 'tak', 'jako', 'nebo', 'jsem', 'jsou', 'byl', 'byla', 'bylo',
        'být', 'jeho', 'její', 'jejich', 'já', 'ty', 'on', 'ona', 'ono', 'my',
        'vy', 'oni', 'ony', 'mně', 'tě', 'ho', 'ji', 'nás', 'vás', 'je', 'jim',
        'můj', 'tvůj', 'svůj', 'náš', 'váš', 'tento', 'tato', 'toto', 'ten',
        'ta', 'ti', 'ty', 'co', 'kdo', 'kde', 'kdy', 'proč', 'jak', 'kolik',
        'už', 'ještě', 'také', 'jen', 'jenom', 'tady', 'tam', 'teď', 'pak',
        'vždy', 'nikdy', 'často', 'zřídka', 'více', 'méně', 'velmi', 'málo',
    },
    
    'hu': {
        'a', 'az', 'és', 'hogy', 'nem', 'is', 'volt', 'egy', 'van', 'meg', 'de',
        'ezt', 'már', 'csak', 'én', 'te', 'ő', 'mi', 'ti', 'ők', 'az', 'ez',
        'aki', 'ami', 'ahol', 'amikor', 'ahogy', 'mindig', 'soha', 'igen', 'nem',
        'itt', 'ott', 'most', 'majd', 'még', 'már', 'nagyon', 'kevés', 'sok',
        'minden', 'semmi', 'valami', 'valaki', 'senki', 'ki', 'mi', 'hol',
        'mikor', 'miért', 'hogyan', 'mennyi', 'után', 'előtt', 'között', 'alatt',
        'fölött', 'mellett', 'mögött', 'ellen', 'által', 'szerint', 'nélkül',
    },
    
    'ro': {
        'și', 'în', 'a', 'de', 'la', 'cu', 'pe', 'o', 'că', 'nu', 'din', 'care',
        'ce', 'se', 'lui', 'un', 'pentru', 'sunt', 'mai', 'fi', 'sau', 'dar',
        'el', 'ea', 'ei', 'ele', 'eu', 'tu', 'noi', 'voi', 'meu', 'tău', 'său',
        'nostru', 'vostru', 'lor', 'acest', 'această', 'acești', 'aceste', 'acel',
        'acea', 'acei', 'acele', 'cine', 'ce', 'unde', 'când', 'cum', 'de ce',
        'cât', 'aici', 'acolo', 'acum', 'atunci', 'mereu', 'niciodată', 'foarte',
        'puțin', 'mult', 'tot', 'toată', 'toți', 'toate', 'fiecare', 'unii',
        'nimic', 'nimeni', 'ceva', 'cineva', 'doar', 'încă', 'deja', 'poate',
    },
    
    'uk': {
        'і', 'в', 'на', 'що', 'не', 'з', 'у', 'до', 'як', 'але', 'за', 'від',
        'так', 'він', 'вона', 'воно', 'вони', 'я', 'ти', 'ми', 'ви', 'це', 'той',
        'та', 'те', 'ті', 'який', 'яка', 'яке', 'які', 'де', 'коли', 'чому',
        'як', 'хто', 'що', 'скільки', 'тут', 'там', 'зараз', 'тоді', 'завжди',
        'ніколи', 'дуже', 'мало', 'багато', 'все', 'всі', 'ніщо', 'ніхто',
        'щось', 'хтось', 'тільки', 'ще', 'вже', 'може', 'треба', 'можна',
        'був', 'була', 'було', 'були', 'бути', 'є', 'буде', 'будуть', 'мій',
        'твій', 'його', 'її', 'наш', 'ваш', 'їх', 'свій', 'цей', 'ця', 'ці',
    },
}


def get_stopwords(language: str, custom_stopwords: Optional[List[str]] = None) -> Set[str]:
    """
    Get stopwords for a given language.
    
    Parameters
    ----------
    language : str
        ISO 639-1 language code
    custom_stopwords : List[str], optional
        Additional stopwords to add
        
    Returns
    -------
    Set[str]
        Set of stopwords
    """
    # Normalize language code
    lang = language.lower().strip()
    if lang in ['zh-cn', 'zh-tw', 'chinese']:
        lang = 'zh'
    elif lang in ['japanese']:
        lang = 'ja'
    elif lang in ['korean']:
        lang = 'ko'
    
    # Get base stopwords
    if lang in STOPWORDS:
        stopwords = STOPWORDS[lang].copy()
    else:
        # Fall back to English if language not found
        warnings.warn(f"No stopwords found for language '{language}', using English stopwords")
        stopwords = STOPWORDS['en'].copy()
    
    # Add custom stopwords
    if custom_stopwords:
        stopwords.update(custom_stopwords)
    
    return stopwords


def get_available_languages() -> List[str]:
    """
    Get list of languages with available stopwords.
    
    Returns
    -------
    List[str]
        List of language codes
    """
    return list(STOPWORDS.keys())
