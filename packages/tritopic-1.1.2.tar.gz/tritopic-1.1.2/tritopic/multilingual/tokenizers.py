"""
Multilingual Tokenizers Module

Provides language-specific tokenization for various languages including CJK.
"""

from typing import List, Callable, Optional
import re
import warnings


class TokenizerFactory:
    """Factory for creating language-specific tokenizers."""
    
    _tokenizers = {}
    
    @classmethod
    def get_tokenizer(cls, language: str, tokenizer_type: str = "auto") -> Callable[[str], List[str]]:
        """
        Get the appropriate tokenizer for a language.
        
        Parameters
        ----------
        language : str
            ISO 639-1 language code
        tokenizer_type : str
            Type of tokenizer: "auto", "whitespace", "spacy", "jieba", "fugashi", "konlpy", "pythainlp"
            
        Returns
        -------
        Callable[[str], List[str]]
            A tokenizer function that takes text and returns tokens
        """
        if tokenizer_type != "auto":
            return cls._get_specific_tokenizer(tokenizer_type, language)
        
        # Auto-select based on language
        if language in ['zh', 'zh-cn', 'zh-tw']:
            return cls._get_jieba_tokenizer()
        elif language == 'ja':
            return cls._get_japanese_tokenizer()
        elif language == 'ko':
            return cls._get_korean_tokenizer()
        elif language == 'th':
            return cls._get_thai_tokenizer()
        else:
            return cls._get_whitespace_tokenizer(language)
    
    @classmethod
    def _get_specific_tokenizer(cls, tokenizer_type: str, language: str) -> Callable[[str], List[str]]:
        """Get a specific tokenizer by name."""
        tokenizer_map = {
            "whitespace": lambda: cls._get_whitespace_tokenizer(language),
            "jieba": cls._get_jieba_tokenizer,
            "fugashi": cls._get_japanese_tokenizer,
            "mecab": cls._get_japanese_tokenizer,
            "konlpy": cls._get_korean_tokenizer,
            "pythainlp": cls._get_thai_tokenizer,
            "spacy": lambda: cls._get_spacy_tokenizer(language),
        }
        
        if tokenizer_type in tokenizer_map:
            return tokenizer_map[tokenizer_type]()
        else:
            warnings.warn(f"Unknown tokenizer '{tokenizer_type}', falling back to whitespace")
            return cls._get_whitespace_tokenizer(language)
    
    @classmethod
    def _get_whitespace_tokenizer(cls, language: str) -> Callable[[str], List[str]]:
        """Get a simple whitespace-based tokenizer with language-aware preprocessing."""
        
        def tokenize(text: str) -> List[str]:
            # Lowercase
            text = text.lower()
            # Remove punctuation but keep apostrophes for contractions
            text = re.sub(r"[^\w\s'-]", " ", text)
            # Split on whitespace
            tokens = text.split()
            # Remove tokens that are just punctuation or numbers
            tokens = [t for t in tokens if re.search(r'[a-zA-ZäöüßàâçéèêëîïôûùüÿñæœÄÖÜ]', t)]
            return tokens
        
        return tokenize
    
    @classmethod
    def _get_jieba_tokenizer(cls) -> Callable[[str], List[str]]:
        """Get Chinese tokenizer using jieba."""
        try:
            import jieba
            jieba.setLogLevel(jieba.logging.INFO)  # Reduce verbosity
            
            def tokenize(text: str) -> List[str]:
                # Use jieba's cut function for word segmentation
                tokens = list(jieba.cut(text, cut_all=False))
                # Filter out whitespace and punctuation
                tokens = [t.strip() for t in tokens if t.strip() and not re.match(r'^[\s\W]+$', t)]
                return tokens
            
            return tokenize
            
        except ImportError:
            warnings.warn(
                "jieba not installed. Install with 'pip install jieba' for Chinese tokenization. "
                "Falling back to character-based tokenization."
            )
            return cls._get_character_tokenizer()
    
    @classmethod
    def _get_japanese_tokenizer(cls) -> Callable[[str], List[str]]:
        """Get Japanese tokenizer using fugashi (MeCab)."""
        try:
            import fugashi
            tagger = fugashi.Tagger()
            
            def tokenize(text: str) -> List[str]:
                tokens = []
                for word in tagger(text):
                    surface = word.surface
                    # Filter out punctuation and whitespace
                    if surface.strip() and not re.match(r'^[\s\W]+$', surface):
                        tokens.append(surface)
                return tokens
            
            return tokenize
            
        except ImportError:
            warnings.warn(
                "fugashi not installed. Install with 'pip install fugashi unidic-lite' for Japanese tokenization. "
                "Falling back to character-based tokenization."
            )
            return cls._get_character_tokenizer()
    
    @classmethod
    def _get_korean_tokenizer(cls) -> Callable[[str], List[str]]:
        """Get Korean tokenizer using KoNLPy."""
        try:
            from konlpy.tag import Okt
            okt = Okt()
            
            def tokenize(text: str) -> List[str]:
                # Use morphological analysis
                tokens = okt.morphs(text)
                # Filter out punctuation
                tokens = [t for t in tokens if t.strip() and not re.match(r'^[\s\W]+$', t)]
                return tokens
            
            return tokenize
            
        except ImportError:
            warnings.warn(
                "konlpy not installed. Install with 'pip install konlpy' for Korean tokenization. "
                "Note: KoNLPy may require Java. Falling back to character-based tokenization."
            )
            return cls._get_character_tokenizer()
    
    @classmethod
    def _get_thai_tokenizer(cls) -> Callable[[str], List[str]]:
        """Get Thai tokenizer using pythainlp."""
        try:
            from pythainlp.tokenize import word_tokenize
            
            def tokenize(text: str) -> List[str]:
                tokens = word_tokenize(text, engine='newmm')
                # Filter out whitespace and punctuation
                tokens = [t.strip() for t in tokens if t.strip() and not re.match(r'^[\s\W]+$', t)]
                return tokens
            
            return tokenize
            
        except ImportError:
            warnings.warn(
                "pythainlp not installed. Install with 'pip install pythainlp' for Thai tokenization. "
                "Falling back to whitespace tokenization."
            )
            return cls._get_whitespace_tokenizer('th')
    
    @classmethod
    def _get_spacy_tokenizer(cls, language: str) -> Callable[[str], List[str]]:
        """Get spaCy tokenizer for specified language."""
        try:
            import spacy
            
            # Map language codes to spaCy model names
            model_map = {
                'en': 'en_core_web_sm',
                'de': 'de_core_news_sm',
                'fr': 'fr_core_news_sm',
                'es': 'es_core_news_sm',
                'it': 'it_core_news_sm',
                'pt': 'pt_core_news_sm',
                'nl': 'nl_core_news_sm',
                'pl': 'pl_core_news_sm',
                'ru': 'ru_core_news_sm',
                'zh': 'zh_core_web_sm',
                'ja': 'ja_core_news_sm',
            }
            
            model_name = model_map.get(language, 'en_core_web_sm')
            
            try:
                nlp = spacy.load(model_name)
            except OSError:
                warnings.warn(f"spaCy model '{model_name}' not found. Falling back to whitespace tokenization.")
                return cls._get_whitespace_tokenizer(language)
            
            def tokenize(text: str) -> List[str]:
                doc = nlp(text)
                tokens = [token.text.lower() for token in doc if not token.is_punct and not token.is_space]
                return tokens
            
            return tokenize
            
        except ImportError:
            warnings.warn("spaCy not installed. Falling back to whitespace tokenization.")
            return cls._get_whitespace_tokenizer(language)
    
    @classmethod
    def _get_character_tokenizer(cls) -> Callable[[str], List[str]]:
        """Fallback character-based tokenizer for CJK without proper tokenizer."""
        
        def tokenize(text: str) -> List[str]:
            # For CJK, use n-gram characters
            tokens = []
            # Remove whitespace and punctuation
            text = re.sub(r'[\s\W]+', '', text)
            # Create character bigrams
            for i in range(len(text) - 1):
                tokens.append(text[i:i+2])
            return tokens
        
        return tokenize


def tokenize_documents(
    documents: List[str],
    language: str,
    tokenizer_type: str = "auto",
    min_length: int = 2,
    max_length: int = 50
) -> List[List[str]]:
    """
    Tokenize a list of documents.
    
    Parameters
    ----------
    documents : List[str]
        List of documents to tokenize
    language : str
        ISO 639-1 language code
    tokenizer_type : str
        Type of tokenizer to use
    min_length : int
        Minimum token length to keep
    max_length : int
        Maximum token length to keep
        
    Returns
    -------
    List[List[str]]
        List of tokenized documents
    """
    tokenizer = TokenizerFactory.get_tokenizer(language, tokenizer_type)
    
    tokenized = []
    for doc in documents:
        if not isinstance(doc, str):
            tokenized.append([])
            continue
        
        tokens = tokenizer(doc)
        # Filter by length
        tokens = [t for t in tokens if min_length <= len(t) <= max_length]
        tokenized.append(tokens)
    
    return tokenized
