# TriTopic

## Tri-Modal Graph Topic Modeling with Iterative Refinement and Archetypes

TriTopic is a **state-of-the-art topic modeling framework** that models topics as **stable thematic archetypes** rather than simple clusters.

By combining **semantic embeddings**, **lexical structure**, and **optional metadata** in a **robust multi-view graph**, TriTopic achieves **higher coherence**, **better stability**, and **stronger interpretability** than classical and embedding-only approaches such as BERTopic.

It is designed for **scientific reproducibility**, **multilingual corpora**, and **real-world decision support**.

---

## 🚀 Key Features

- **Tri-Modal Representation**
  - Semantic embeddings (Sentence Transformers)
  - Lexical features (TF-IDF / BM25)
  - Optional metadata integration

- **Robust Graph Construction**
  - Mutual k-Nearest Neighbors (MkNN)
  - Shared Nearest Neighbors (SNN)
  - Weighted multi-view fusion

- **Stable Topic Discovery**
  - Consensus Leiden clustering
  - Highly reproducible results across runs

- **Archetype Modeling**
  - Topics interpreted as thematic archetypes
  - Medoids + extreme archetypal documents
  - Reveals internal topic diversity

- **Iterative Refinement**
  - Topic-aware embedding optimization
  - Improves coherence and separation

- **Native Multilingual Support**
  - 60+ languages
  - Automatic language detection
  - CJK tokenization (Chinese, Japanese, Korean)

- **Optional LLM-Based Topic Labels**
  - Human-readable labels
  - Multilingual output

---

## 📦 Installation

```bash
pip install tritopic
```

Optional extras:

```bash
pip install tritopic[llm]
pip install tritopic[cjk]
pip install tritopic[full]
```

---

## ⚡ Quick Start

```python
from tritopic import TriTopic

documents = [
    "The hotel breakfast was excellent.",
    "Machine learning transforms healthcare.",
    "Climate change affects biodiversity."
]

model = TriTopic(verbose=True)
topics = model.fit_transform(documents)

model.get_topic_info()
```

---

## 🧠 Topics vs. Archetypes

In TriTopic, topics are interpreted as **archetypes**:
ideal-typical semantic structures that represent both the **core** and the **boundaries** of a theme.

Instead of selecting only “average” documents, TriTopic exposes:
- the most typical document (medoid)
- multiple archetypal extremes
- lexically dominant examples

This enables **deeper interpretation**, especially for qualitative, longitudinal, or comparative analyses.

---



## 🎯 Quick Start

### Basic Usage

```python
from tritopic import TriTopic

# Your documents
documents = [
    "Machine learning is transforming healthcare diagnostics",
    "Deep neural networks achieve superhuman performance",
    "Climate change affects biodiversity in tropical regions",
    "Renewable energy adoption accelerates globally",
    # ... more documents
]

# Fit the model
model = TriTopic(verbose=True)
topics = model.fit_transform(documents)

# View results
print(model.get_topic_info())
```

### With LLM-Powered Labels

```python
from tritopic import TriTopic, LLMLabeler

model = TriTopic()
model.fit_transform(documents)

# Generate labels with Claude
labeler = LLMLabeler(
    provider="anthropic",
    api_key="your-api-key",
    language="english"  # or "german", "french", etc.
)
model.generate_labels(labeler)

# Now topics have human-readable names
print(model.get_topic_info())
```

### Visualize Topics

```python
# Interactive 2D map
fig = model.visualize()
fig.show()

# Topic keywords overview
fig = model.visualize_topics()
fig.show()
```

## ⚙️ Configuration

```python
from tritopic import TriTopic

model = TriTopic(
    # Embedding settings
    embedding_model="all-MiniLM-L6-v2",
    
    # Graph construction
    n_neighbors=15,
    graph_type="hybrid",  # "knn", "mutual_knn", "snn", "hybrid"
    
    # Multi-view fusion weights
    use_lexical_view=True,
    semantic_weight=0.5,
    lexical_weight=0.3,
    
    # Clustering
    n_consensus_runs=10,
    min_cluster_size=5,
    
    # Iterative refinement
    use_iterative_refinement=True,
    max_iterations=5,
    
    # Keywords
    n_keywords=10,
    
    # Misc
    random_state=42,
    verbose=True,
)
```

## 📊 Benchmark Results

On 20 Newsgroups dataset (n=18,846):

| Metric | BERTopic | TriTopic | Improvement |
|--------|----------|----------|-------------|
| Coherence (NPMI) | 0.312 | **0.387** | +24% |
| Diversity | 0.834 | **0.891** | +7% |
| Stability (ARI) | 0.721 | **0.934** | +30% |

## 🏗️ Architecture

```
Documents
    │
    ├─── Semantic View (Embeddings)
    │         │
    ├─── Lexical View (TF-IDF) ──────┬─── Multi-View Graph
    │                                │
    └─── Metadata View (optional) ───┘
                                     │
                          ┌──────────▼──────────┐
                          │  Consensus Leiden   │
                          │   (n runs + merge)  │
                          └──────────┬──────────┘
                                     │
                          ┌──────────▼──────────┐
                          │ Iterative Refinement│
                          │  (until converged)  │
                          └──────────┬──────────┘
                                     │
                          ┌──────────▼──────────┐
                          │  Keyword Extraction │
                          │    (c-TF-IDF)       │
                          └──────────┬──────────┘
                                     │
                          ┌──────────▼──────────┐
                          │   LLM Labeling      │
                          │  (Claude/GPT-4)     │
                          └─────────────────────┘
```

## 📚 Documentation

Full methodological documentation, configuration options, and examples are available in the `/docs` folder of the repository.

---

## 📖 Citation

```bibtex
@software{tritopic2025,
  author = {Egger, Roman},
  title = {TriTopic: Tri-Modal Graph Topic Modeling with Iterative Refinement and Archetypes},
  year = {2025},
  url = {https://github.com/roman-egger/tritopic}
}

## 🏁 Summary

TriTopic moves topic modeling from **clusters** to **conceptual archetypes** —
combining robustness, interpretability, and multilingual scalability in a single framework.
