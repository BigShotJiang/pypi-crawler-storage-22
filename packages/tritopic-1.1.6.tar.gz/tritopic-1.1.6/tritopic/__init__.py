"""
TriTopic: Tri-Modal Graph Topic Modeling with Iterative Refinement

A state-of-the-art topic modeling library that consistently outperforms
BERTopic and traditional approaches.

Key Features:
- Multi-View Graph Fusion (semantic, lexical, metadata)
- Mutual kNN + SNN for robust graph construction
- Consensus Leiden clustering for stability
- Iterative embedding refinement
- LLM-powered topic labeling

Quick Start:
    >>> from tritopic import TriTopic
    >>> model = TriTopic(verbose=True)
    >>> topics = model.fit_transform(documents)
    >>> print(model.get_topic_info())

With LLM Labels:
    >>> from tritopic import TriTopic, LLMLabeler
    >>> model = TriTopic()
    >>> model.fit_transform(documents)
    >>> labeler = LLMLabeler(provider="anthropic", api_key="...")
    >>> model.generate_labels(labeler)

For more information, see: https://github.com/roman-egger/tritopic
"""

__version__ = "1.1.0"
__author__ = "Roman Egger"
__email__ = "roman.egger@modul.ac.at"

from .model import TriTopic, TopicInfo
from .config import TriTopicConfig, get_config

# Labeling
from .labeling import (
    LLMLabeler,
    AnthropicLabeler,
    OpenAILabeler,
    KeywordLabeler,
)

# Core components (for advanced users)
from .core import (
    EmbeddingEngine,
    GraphBuilder,
    MultiViewGraphBuilder,
    ConsensusLeiden,
    IterativeRefinement,
    KeywordExtractor,
    RepresentativeSelector,
)

__all__ = [
    # Main classes
    "TriTopic",
    "TopicInfo",
    "TriTopicConfig",
    "get_config",
    
    # Labeling
    "LLMLabeler",
    "AnthropicLabeler",
    "OpenAILabeler",
    "KeywordLabeler",
    
    # Core components
    "EmbeddingEngine",
    "GraphBuilder",
    "MultiViewGraphBuilder",
    "ConsensusLeiden",
    "IterativeRefinement",
    "KeywordExtractor",
    "RepresentativeSelector",
    
    # Version
    "__version__",
]
