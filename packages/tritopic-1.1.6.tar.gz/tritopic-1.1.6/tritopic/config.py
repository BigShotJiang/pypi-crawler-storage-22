"""
TriTopic Configuration Module

Defines all configuration parameters for the TriTopic model.
"""

from dataclasses import dataclass, field
from typing import Optional, List, Literal, Union


@dataclass
class TriTopicConfig:
    """
    Configuration for TriTopic model.
    
    Attributes
    ----------
    # Embedding Settings
    embedding_model : str
        Sentence-Transformer model name or "auto" for automatic selection.
    embedding_batch_size : int
        Batch size for embedding generation.
    
    # Language Settings
    language : str
        ISO 639-1 language code (e.g., "en", "de", "zh") or "auto" for detection.
    multilingual : bool
        If True, uses multilingual embedding models.
    custom_stopwords : List[str]
        Additional stopwords to add.
    min_token_length : int
        Minimum token length to keep.
    max_token_length : int
        Maximum token length to keep.
    
    # Graph Construction
    n_neighbors : int
        Number of neighbors for kNN graph.
    metric : str
        Distance metric for similarity.
    graph_type : str
        Graph type: "knn", "mutual_knn", "snn", "hybrid".
    snn_weight : float
        Weight for SNN component in hybrid graph.
    
    # Multi-View Fusion
    use_lexical_view : bool
        Whether to include lexical (TF-IDF) view.
    use_metadata_view : bool
        Whether to include metadata view.
    semantic_weight : float
        Weight for semantic similarity.
    lexical_weight : float
        Weight for lexical similarity.
    metadata_weight : float
        Weight for metadata similarity.
    
    # Clustering
    resolution : float
        Resolution parameter for Leiden algorithm.
    n_consensus_runs : int
        Number of clustering runs for consensus.
    min_cluster_size : int
        Minimum documents per topic.
    
    # Iterative Refinement
    use_iterative_refinement : bool
        Whether to use iterative refinement.
    max_iterations : int
        Maximum refinement iterations.
    convergence_threshold : float
        ARI threshold for convergence.
    refinement_strength : float
        How strongly to pull embeddings toward centroids.
    
    # Keywords & Representatives
    n_keywords : int
        Number of keywords per topic.
    n_representative_docs : int
        Number of representative documents per topic.
    keyword_method : str
        Keyword extraction method: "ctfidf", "bm25", "keybert".
    representative_method : str
        Method for selecting representatives: "centroid", "medoid", "archetype", "diverse".
    n_archetypes : int
        Number of archetypes if using archetype method.
    
    # Outlier Handling
    outlier_threshold : float
        Threshold for outlier detection.
    
    # Misc
    random_state : int
        Random seed for reproducibility.
    verbose : bool
        Whether to print progress.
    """
    
    # Embedding Settings
    embedding_model: str = "all-MiniLM-L6-v2"
    embedding_batch_size: int = 32
    
    # Language Settings
    language: str = "en"
    multilingual: bool = False
    custom_stopwords: List[str] = field(default_factory=list)
    min_token_length: int = 2
    max_token_length: int = 50
    
    # Graph Construction
    n_neighbors: int = 15
    metric: str = "cosine"
    graph_type: str = "hybrid"
    snn_weight: float = 0.5
    
    # Multi-View Fusion
    use_lexical_view: bool = True
    use_metadata_view: bool = False
    semantic_weight: float = 0.5
    lexical_weight: float = 0.3
    metadata_weight: float = 0.2
    
    # Clustering
    resolution: float = 1.0
    n_consensus_runs: int = 10
    min_cluster_size: int = 5
    
    # Iterative Refinement
    use_iterative_refinement: bool = True
    max_iterations: int = 5
    convergence_threshold: float = 0.95
    refinement_strength: float = 0.15
    
    # Keywords & Representatives
    n_keywords: int = 10
    n_representative_docs: int = 5
    keyword_method: str = "ctfidf"
    representative_method: str = "centroid"
    n_archetypes: int = 5
    
    # Outlier Handling
    outlier_threshold: float = 0.1
    
    # Misc
    random_state: Optional[int] = 42
    verbose: bool = True
    
    def __post_init__(self):
        """Validate configuration values."""
        if self.semantic_weight + self.lexical_weight + self.metadata_weight > 1.0 + 1e-6:
            raise ValueError("View weights should sum to approximately 1.0")
        
        if self.graph_type not in ["knn", "mutual_knn", "snn", "hybrid"]:
            raise ValueError(f"Invalid graph_type: {self.graph_type}")
        
        if self.keyword_method not in ["ctfidf", "bm25", "keybert"]:
            raise ValueError(f"Invalid keyword_method: {self.keyword_method}")
        
        if self.representative_method not in ["centroid", "medoid", "archetype", "diverse"]:
            raise ValueError(f"Invalid representative_method: {self.representative_method}")


# Multilingual model recommendations
MULTILINGUAL_MODELS = {
    "auto": "paraphrase-multilingual-MiniLM-L12-v2",
    "small": "paraphrase-multilingual-MiniLM-L12-v2",
    "base": "paraphrase-multilingual-mpnet-base-v2",
    "large": "intfloat/multilingual-e5-large",
}

LANGUAGE_SPECIFIC_MODELS = {
    "en": "all-MiniLM-L6-v2",
    "de": "T-Systems-onsite/cross-en-de-roberta-sentence-transformer",
    "zh": "shibing624/text2vec-base-chinese",
    "ja": "cl-tohoku/bert-base-japanese-v3",
    "ko": "jhgan/ko-sroberta-multitask",
    "multi": "paraphrase-multilingual-MiniLM-L12-v2",
}


def get_config(**kwargs) -> TriTopicConfig:
    """Create configuration with custom parameters."""
    return TriTopicConfig(**kwargs)


def get_recommended_model(language: str, multilingual: bool = False) -> str:
    """Get recommended embedding model for a language."""
    if multilingual:
        return MULTILINGUAL_MODELS.get("base")
    return LANGUAGE_SPECIFIC_MODELS.get(language, LANGUAGE_SPECIFIC_MODELS["multi"])
