"""
Clustering Module for TriTopic

Implements Consensus Leiden Clustering for stable topic discovery.
"""

from __future__ import annotations

from typing import Optional, Tuple, List

import numpy as np
from scipy import sparse
from sklearn.metrics import adjusted_rand_score


class ConsensusLeiden:
    """
    Consensus Leiden Clustering.
    
    Runs Leiden algorithm multiple times and aggregates results
    for more stable clustering.
    
    Parameters
    ----------
    resolution : float
        Resolution parameter for Leiden algorithm.
    n_runs : int
        Number of clustering runs for consensus.
    min_cluster_size : int
        Minimum documents per cluster.
    random_state : int, optional
        Random seed.
    """
    
    def __init__(
        self,
        resolution: float = 1.0,
        n_runs: int = 10,
        min_cluster_size: int = 5,
        random_state: Optional[int] = 42,
    ):
        self.resolution = resolution
        self.n_runs = n_runs
        self.min_cluster_size = min_cluster_size
        self.random_state = random_state
    
    def fit_predict(self, adjacency: sparse.csr_matrix) -> np.ndarray:
        """
        Perform consensus clustering.
        
        Parameters
        ----------
        adjacency : sparse.csr_matrix
            Adjacency matrix of the graph.
            
        Returns
        -------
        labels : np.ndarray
            Cluster labels for each document.
        """
        import igraph as ig
        import leidenalg
        
        n_samples = adjacency.shape[0]
        
        # Convert to igraph
        graph = self._sparse_to_igraph(adjacency)
        
        # Run Leiden multiple times
        partitions = []
        rng = np.random.default_rng(self.random_state)
        
        for i in range(self.n_runs):
            seed = rng.integers(0, 2**31 - 1)
            partition = leidenalg.find_partition(
                graph,
                leidenalg.RBConfigurationVertexPartition,
                resolution_parameter=self.resolution,
                seed=int(seed),
            )
            partitions.append(np.array(partition.membership))
        
        # Build co-assignment matrix
        co_assignment = self._build_co_assignment_matrix(partitions, n_samples)
        
        # Final clustering on co-assignment matrix
        labels = self._cluster_co_assignment(co_assignment, graph)
        
        # Handle small clusters
        labels = self._handle_small_clusters(labels)
        
        return labels
    
    def _sparse_to_igraph(self, adjacency: sparse.csr_matrix):
        """Convert sparse matrix to igraph."""
        import igraph as ig
        
        # Get edges and weights
        adjacency = adjacency.tocoo()
        edges = list(zip(adjacency.row, adjacency.col))
        weights = adjacency.data.tolist()
        
        # Create graph
        graph = ig.Graph(n=adjacency.shape[0], edges=edges, directed=False)
        graph.es["weight"] = weights
        
        return graph
    
    def _build_co_assignment_matrix(
        self,
        partitions: List[np.ndarray],
        n_samples: int,
    ) -> np.ndarray:
        """Build co-assignment matrix from multiple partitions."""
        co_assignment = np.zeros((n_samples, n_samples))
        
        for partition in partitions:
            for cluster_id in np.unique(partition):
                mask = partition == cluster_id
                co_assignment[np.ix_(mask, mask)] += 1
        
        co_assignment /= len(partitions)
        return co_assignment
    
    def _cluster_co_assignment(
        self,
        co_assignment: np.ndarray,
        original_graph,
    ) -> np.ndarray:
        """Cluster the co-assignment matrix."""
        import igraph as ig
        import leidenalg
        
        # Threshold co-assignment matrix
        threshold = 0.5
        adjacency = (co_assignment > threshold).astype(float)
        np.fill_diagonal(adjacency, 0)
        
        # Convert to igraph
        n = adjacency.shape[0]
        rows, cols = np.where(adjacency > 0)
        edges = list(zip(rows.tolist(), cols.tolist()))
        weights = adjacency[rows, cols].tolist()
        
        if not edges:
            # Fallback: use original graph
            partition = leidenalg.find_partition(
                original_graph,
                leidenalg.RBConfigurationVertexPartition,
                resolution_parameter=self.resolution,
                seed=self.random_state,
            )
            return np.array(partition.membership)
        
        graph = ig.Graph(n=n, edges=edges, directed=False)
        graph.es["weight"] = weights
        
        partition = leidenalg.find_partition(
            graph,
            leidenalg.RBConfigurationVertexPartition,
            resolution_parameter=self.resolution,
            seed=self.random_state,
        )
        
        return np.array(partition.membership)
    
    def _handle_small_clusters(self, labels: np.ndarray) -> np.ndarray:
        """Merge small clusters into nearest larger cluster."""
        unique_labels = np.unique(labels[labels >= 0])
        cluster_sizes = {l: np.sum(labels == l) for l in unique_labels}
        
        small_clusters = [l for l, s in cluster_sizes.items() if s < self.min_cluster_size]
        
        for small in small_clusters:
            # Mark as outlier (-1)
            labels[labels == small] = -1
        
        # Renumber remaining clusters
        unique_valid = np.unique(labels[labels >= 0])
        mapping = {old: new for new, old in enumerate(unique_valid)}
        mapping[-1] = -1
        
        return np.array([mapping[l] for l in labels])
    
    def find_optimal_resolution(
        self,
        adjacency: sparse.csr_matrix,
        resolution_range: Tuple[float, float] = (0.5, 2.0),
        n_steps: int = 10,
        target_n_topics: Optional[int] = None,
    ) -> float:
        """
        Find optimal resolution parameter.
        
        Parameters
        ----------
        adjacency : sparse.csr_matrix
            Adjacency matrix.
        resolution_range : tuple
            Range of resolutions to try.
        n_steps : int
            Number of resolution values to try.
        target_n_topics : int, optional
            Target number of topics.
            
        Returns
        -------
        optimal_resolution : float
            Best resolution value.
        """
        import igraph as ig
        import leidenalg
        
        graph = self._sparse_to_igraph(adjacency)
        
        resolutions = np.linspace(resolution_range[0], resolution_range[1], n_steps)
        best_resolution = self.resolution
        best_score = -np.inf
        
        for res in resolutions:
            partition = leidenalg.find_partition(
                graph,
                leidenalg.RBConfigurationVertexPartition,
                resolution_parameter=res,
                seed=self.random_state,
            )
            
            n_clusters = len(set(partition.membership))
            modularity = partition.modularity
            
            if target_n_topics is not None:
                # Score based on distance to target
                score = -abs(n_clusters - target_n_topics) + modularity * 0.1
            else:
                score = modularity
            
            if score > best_score:
                best_score = score
                best_resolution = res
        
        return best_resolution
