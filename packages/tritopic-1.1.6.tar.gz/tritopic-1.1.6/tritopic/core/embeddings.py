"""
Embedding Engine for TriTopic

Handles document embedding generation using Sentence Transformers.
"""

from __future__ import annotations

from typing import List, Optional, Union

import numpy as np
from tqdm import tqdm


class EmbeddingEngine:
    """
    Generates document embeddings using Sentence Transformers.
    
    Parameters
    ----------
    model_name : str
        Name of the sentence-transformers model.
    batch_size : int
        Batch size for encoding.
    device : str, optional
        Device to use ('cpu', 'cuda', 'mps').
    show_progress : bool
        Whether to show progress bar.
    """
    
    def __init__(
        self,
        model_name: str = "all-MiniLM-L6-v2",
        batch_size: int = 32,
        device: Optional[str] = None,
        show_progress: bool = True,
    ):
        self.model_name = model_name
        self.batch_size = batch_size
        self.device = device
        self.show_progress = show_progress
        self._model = None
    
    @property
    def model(self):
        """Lazy load the model."""
        if self._model is None:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer(self.model_name, device=self.device)
        return self._model
    
    def encode(
        self,
        documents: List[str],
        normalize: bool = True,
    ) -> np.ndarray:
        """
        Encode documents to embeddings.
        
        Parameters
        ----------
        documents : List[str]
            List of documents to encode.
        normalize : bool
            Whether to L2-normalize embeddings.
            
        Returns
        -------
        embeddings : np.ndarray
            Document embeddings of shape (n_docs, embedding_dim).
        """
        embeddings = self.model.encode(
            documents,
            batch_size=self.batch_size,
            show_progress_bar=self.show_progress,
            convert_to_numpy=True,
            normalize_embeddings=normalize,
        )
        return embeddings
    
    @property
    def embedding_dim(self) -> int:
        """Get embedding dimension."""
        return self.model.get_sentence_embedding_dimension()
