"""
Graph Construction for TriTopic

Implements Multi-View Graph with Mutual kNN and Shared Nearest Neighbors.
"""

from __future__ import annotations

from typing import Optional, Tuple, Literal

import numpy as np
from scipy import sparse
from scipy.spatial.distance import cdist
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.neighbors import NearestNeighbors


class GraphBuilder:
    """
    Builds similarity graphs from embeddings.
    
    Supports kNN, Mutual kNN, SNN, and Hybrid approaches.
    
    Parameters
    ----------
    n_neighbors : int
        Number of neighbors for kNN.
    metric : str
        Distance metric.
    graph_type : str
        Type of graph: "knn", "mutual_knn", "snn", "hybrid".
    snn_weight : float
        Weight for SNN in hybrid mode.
    """
    
    def __init__(
        self,
        n_neighbors: int = 15,
        metric: str = "cosine",
        graph_type: str = "hybrid",
        snn_weight: float = 0.5,
    ):
        self.n_neighbors = n_neighbors
        self.metric = metric
        self.graph_type = graph_type
        self.snn_weight = snn_weight
    
    def build_graph(self, embeddings: np.ndarray) -> sparse.csr_matrix:
        """
        Build similarity graph from embeddings.
        
        Parameters
        ----------
        embeddings : np.ndarray
            Document embeddings.
            
        Returns
        -------
        adjacency : sparse.csr_matrix
            Sparse adjacency matrix.
        """
        n_samples = embeddings.shape[0]
        k = min(self.n_neighbors, n_samples - 1)
        
        # Compute kNN
        nn = NearestNeighbors(n_neighbors=k + 1, metric=self.metric)
        nn.fit(embeddings)
        distances, indices = nn.kneighbors(embeddings)
        
        # Remove self-neighbors
        indices = indices[:, 1:]
        distances = distances[:, 1:]
        
        if self.graph_type == "knn":
            return self._build_knn_graph(indices, distances, n_samples)
        elif self.graph_type == "mutual_knn":
            return self._build_mutual_knn_graph(indices, distances, n_samples)
        elif self.graph_type == "snn":
            return self._build_snn_graph(indices, n_samples)
        elif self.graph_type == "hybrid":
            return self._build_hybrid_graph(indices, distances, n_samples)
        else:
            raise ValueError(f"Unknown graph type: {self.graph_type}")
    
    def _build_knn_graph(
        self,
        indices: np.ndarray,
        distances: np.ndarray,
        n_samples: int,
    ) -> sparse.csr_matrix:
        """Build standard kNN graph."""
        # Convert distances to similarities
        similarities = 1 - distances / (distances.max() + 1e-10)
        
        rows = np.repeat(np.arange(n_samples), indices.shape[1])
        cols = indices.ravel()
        data = similarities.ravel()
        
        adjacency = sparse.csr_matrix((data, (rows, cols)), shape=(n_samples, n_samples))
        return adjacency
    
    def _build_mutual_knn_graph(
        self,
        indices: np.ndarray,
        distances: np.ndarray,
        n_samples: int,
    ) -> sparse.csr_matrix:
        """Build Mutual kNN graph (symmetric)."""
        similarities = 1 - distances / (distances.max() + 1e-10)
        
        rows = np.repeat(np.arange(n_samples), indices.shape[1])
        cols = indices.ravel()
        data = similarities.ravel()
        
        # Build asymmetric adjacency
        adjacency = sparse.csr_matrix((data, (rows, cols)), shape=(n_samples, n_samples))
        
        # Make symmetric (keep only mutual connections)
        mutual = adjacency.multiply(adjacency.T)
        return mutual
    
    def _build_snn_graph(
        self,
        indices: np.ndarray,
        n_samples: int,
    ) -> sparse.csr_matrix:
        """Build Shared Nearest Neighbors graph."""
        k = indices.shape[1]
        
        # Create neighbor sets for each document
        neighbor_sets = [set(indices[i]) for i in range(n_samples)]
        
        # Compute SNN similarity
        rows, cols, data = [], [], []
        
        for i in range(n_samples):
            for j in indices[i]:
                if j > i:  # Only upper triangle
                    shared = len(neighbor_sets[i] & neighbor_sets[j])
                    if shared > 0:
                        snn_sim = shared / k
                        rows.extend([i, j])
                        cols.extend([j, i])
                        data.extend([snn_sim, snn_sim])
        
        adjacency = sparse.csr_matrix((data, (rows, cols)), shape=(n_samples, n_samples))
        return adjacency
    
    def _build_hybrid_graph(
        self,
        indices: np.ndarray,
        distances: np.ndarray,
        n_samples: int,
    ) -> sparse.csr_matrix:
        """Build Hybrid graph (MkNN + SNN)."""
        mknn = self._build_mutual_knn_graph(indices, distances, n_samples)
        snn = self._build_snn_graph(indices, n_samples)
        
        # Normalize both
        mknn_norm = mknn / (mknn.max() + 1e-10) if mknn.max() > 0 else mknn
        snn_norm = snn / (snn.max() + 1e-10) if snn.max() > 0 else snn
        
        # Combine
        hybrid = (1 - self.snn_weight) * mknn_norm + self.snn_weight * snn_norm
        return hybrid


class MultiViewGraphBuilder:
    """
    Builds multi-view graph combining semantic, lexical, and metadata views.
    
    Parameters
    ----------
    n_neighbors : int
        Number of neighbors for each view.
    graph_type : str
        Graph type for each view.
    semantic_weight : float
        Weight for semantic view.
    lexical_weight : float
        Weight for lexical view.
    metadata_weight : float
        Weight for metadata view.
    use_lexical : bool
        Whether to include lexical view.
    use_metadata : bool
        Whether to include metadata view.
    """
    
    def __init__(
        self,
        n_neighbors: int = 15,
        graph_type: str = "hybrid",
        snn_weight: float = 0.5,
        semantic_weight: float = 0.5,
        lexical_weight: float = 0.3,
        metadata_weight: float = 0.2,
        use_lexical: bool = True,
        use_metadata: bool = False,
    ):
        self.n_neighbors = n_neighbors
        self.graph_type = graph_type
        self.snn_weight = snn_weight
        self.semantic_weight = semantic_weight
        self.lexical_weight = lexical_weight
        self.metadata_weight = metadata_weight
        self.use_lexical = use_lexical
        self.use_metadata = use_metadata
        
        self.graph_builder = GraphBuilder(
            n_neighbors=n_neighbors,
            graph_type=graph_type,
            snn_weight=snn_weight,
        )
    
    def build_multiview_graph(
        self,
        embeddings: np.ndarray,
        documents: Optional[list] = None,
        metadata: Optional[np.ndarray] = None,
        tfidf_matrix: Optional[sparse.csr_matrix] = None,
    ) -> sparse.csr_matrix:
        """
        Build multi-view graph combining all views.
        
        Parameters
        ----------
        embeddings : np.ndarray
            Document embeddings.
        documents : list, optional
            Document texts for lexical view.
        metadata : np.ndarray, optional
            Metadata features.
        tfidf_matrix : sparse.csr_matrix, optional
            Pre-computed TF-IDF matrix.
            
        Returns
        -------
        adjacency : sparse.csr_matrix
            Combined multi-view adjacency matrix.
        """
        # Semantic view
        semantic_graph = self.graph_builder.build_graph(embeddings)
        
        # Normalize weights
        total_weight = self.semantic_weight
        
        # Lexical view
        lexical_graph = None
        if self.use_lexical and (documents is not None or tfidf_matrix is not None):
            if tfidf_matrix is None:
                tfidf_matrix = self._compute_tfidf(documents)
            
            # Use cosine similarity on TF-IDF
            lexical_sim = cosine_similarity(tfidf_matrix)
            lexical_graph = self._similarity_to_graph(lexical_sim)
            total_weight += self.lexical_weight
        
        # Metadata view
        metadata_graph = None
        if self.use_metadata and metadata is not None:
            metadata_graph = self._build_metadata_graph(metadata)
            total_weight += self.metadata_weight
        
        # Combine views
        combined = (self.semantic_weight / total_weight) * semantic_graph
        
        if lexical_graph is not None:
            combined = combined + (self.lexical_weight / total_weight) * lexical_graph
        
        if metadata_graph is not None:
            combined = combined + (self.metadata_weight / total_weight) * metadata_graph
        
        return combined
    
    def _compute_tfidf(self, documents: list) -> sparse.csr_matrix:
        """Compute TF-IDF matrix."""
        vectorizer = TfidfVectorizer(
            max_features=5000,
            min_df=2,
            max_df=0.95,
            stop_words="english",
        )
        return vectorizer.fit_transform(documents)
    
    def _similarity_to_graph(self, similarity_matrix: np.ndarray) -> sparse.csr_matrix:
        """Convert similarity matrix to sparse graph."""
        n = similarity_matrix.shape[0]
        
        # Keep only top-k connections
        rows, cols, data = [], [], []
        for i in range(n):
            # Get top neighbors
            top_k = min(self.n_neighbors, n - 1)
            top_indices = np.argsort(similarity_matrix[i])[-top_k-1:-1][::-1]
            
            for j in top_indices:
                if i != j:
                    rows.append(i)
                    cols.append(j)
                    data.append(similarity_matrix[i, j])
        
        return sparse.csr_matrix((data, (rows, cols)), shape=(n, n))
    
    def _build_metadata_graph(self, metadata: np.ndarray) -> sparse.csr_matrix:
        """Build graph from metadata features."""
        # Compute cosine similarity on metadata
        sim = cosine_similarity(metadata)
        return self._similarity_to_graph(sim)
