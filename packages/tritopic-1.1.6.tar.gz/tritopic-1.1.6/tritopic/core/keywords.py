"""
Keyword Extraction for TriTopic

Implements c-TF-IDF and other keyword extraction methods.
This is a critical module for topic interpretability.
"""

from __future__ import annotations

from typing import List, Tuple, Optional, Dict
from collections import Counter
import re

import numpy as np
from scipy import sparse
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer


class KeywordExtractor:
    """
    Extracts keywords for each topic using c-TF-IDF or other methods.
    
    Parameters
    ----------
    method : str
        Extraction method: "ctfidf", "bm25", "keybert".
    n_keywords : int
        Number of keywords to extract per topic.
    min_df : int
        Minimum document frequency for terms.
    max_df : float
        Maximum document frequency for terms.
    language : str
        Language for stopwords.
    custom_stopwords : List[str]
        Additional stopwords.
    """
    
    def __init__(
        self,
        method: str = "ctfidf",
        n_keywords: int = 10,
        min_df: int = 2,
        max_df: float = 0.95,
        language: str = "en",
        custom_stopwords: Optional[List[str]] = None,
    ):
        self.method = method
        self.n_keywords = n_keywords
        self.min_df = min_df
        self.max_df = max_df
        self.language = language
        self.custom_stopwords = custom_stopwords or []
        
        self.vectorizer_ = None
        self.vocabulary_ = None
        self.term_matrix_ = None
    
    def extract_keywords(
        self,
        documents: List[str],
        labels: np.ndarray,
    ) -> Dict[int, List[Tuple[str, float]]]:
        """
        Extract keywords for each topic.
        
        Parameters
        ----------
        documents : List[str]
            All documents.
        labels : np.ndarray
            Topic labels for each document.
            
        Returns
        -------
        keywords : Dict[int, List[Tuple[str, float]]]
            Mapping from topic_id to list of (keyword, score) tuples.
        """
        if self.method == "ctfidf":
            return self._extract_ctfidf(documents, labels)
        elif self.method == "bm25":
            return self._extract_bm25(documents, labels)
        elif self.method == "keybert":
            return self._extract_keybert(documents, labels)
        else:
            raise ValueError(f"Unknown method: {self.method}")
    
    def _get_stopwords(self) -> List[str]:
        """Get stopwords for the configured language."""
        # Basic English stopwords
        english_stopwords = {
            'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you',
            "you're", "you've", "you'll", "you'd", 'your', 'yours', 'yourself',
            'yourselves', 'he', 'him', 'his', 'himself', 'she', "she's", 'her',
            'hers', 'herself', 'it', "it's", 'its', 'itself', 'they', 'them',
            'their', 'theirs', 'themselves', 'what', 'which', 'who', 'whom',
            'this', 'that', "that'll", 'these', 'those', 'am', 'is', 'are',
            'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had',
            'having', 'do', 'does', 'did', 'doing', 'a', 'an', 'the', 'and',
            'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 'at',
            'by', 'for', 'with', 'about', 'against', 'between', 'into',
            'through', 'during', 'before', 'after', 'above', 'below', 'to',
            'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under',
            'again', 'further', 'then', 'once', 'here', 'there', 'when',
            'where', 'why', 'how', 'all', 'each', 'few', 'more', 'most',
            'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same',
            'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 'just',
            'don', "don't", 'should', "should've", 'now', 'd', 'll', 'm', 'o',
            're', 've', 'y', 'ain', 'aren', "aren't", 'couldn', "couldn't",
            'didn', "didn't", 'doesn', "doesn't", 'hadn', "hadn't", 'hasn',
            "hasn't", 'haven', "haven't", 'isn', "isn't", 'ma', 'mightn',
            "mightn't", 'mustn', "mustn't", 'needn', "needn't", 'shan',
            "shan't", 'shouldn', "shouldn't", 'wasn', "wasn't", 'weren',
            "weren't", 'won', "won't", 'wouldn', "wouldn't",
            # Additional common words
            'also', 'would', 'could', 'one', 'two', 'get', 'like', 'make',
            'know', 'use', 'say', 'go', 'come', 'see', 'look', 'want', 'give',
            'think', 'well', 'even', 'back', 'way', 'may', 'much', 'still',
            'new', 'old', 'first', 'last', 'long', 'little', 'good', 'great',
            'right', 'high', 'different', 'small', 'large', 'next', 'early',
            'young', 'important', 'public', 'bad', 'same', 'able',
        }
        
        # German stopwords
        german_stopwords = {
            'der', 'die', 'das', 'ein', 'eine', 'einer', 'einem', 'einen',
            'und', 'oder', 'aber', 'denn', 'weil', 'wenn', 'als', 'ob',
            'ist', 'sind', 'war', 'waren', 'sein', 'haben', 'hat', 'hatte',
            'wird', 'werden', 'wurde', 'würde', 'kann', 'können', 'muss',
            'ich', 'du', 'er', 'sie', 'es', 'wir', 'ihr', 'man',
            'mich', 'mir', 'sich', 'uns', 'euch', 'ihnen',
            'mein', 'dein', 'sein', 'ihr', 'unser', 'euer',
            'nicht', 'kein', 'keine', 'keiner',
            'von', 'mit', 'zu', 'bei', 'nach', 'aus', 'für', 'über', 'unter',
            'auf', 'an', 'in', 'vor', 'hinter', 'neben', 'zwischen',
            'auch', 'noch', 'schon', 'nur', 'sehr', 'mehr', 'so', 'da',
            'hier', 'dort', 'wo', 'was', 'wer', 'wie', 'warum', 'wann',
            'alle', 'alles', 'andere', 'anderer', 'anderen',
            'diese', 'dieser', 'diesem', 'diesen', 'jene', 'jener',
            'welche', 'welcher', 'welchem', 'welchen',
            'dass', 'damit', 'dazu', 'dabei', 'dafür', 'davon', 'daran',
        }
        
        if self.language in ["en", "english"]:
            stopwords = english_stopwords
        elif self.language in ["de", "german", "deutsch"]:
            stopwords = german_stopwords | english_stopwords
        else:
            # Default to English
            stopwords = english_stopwords
        
        return list(stopwords | set(self.custom_stopwords))
    
    def _extract_ctfidf(
        self,
        documents: List[str],
        labels: np.ndarray,
    ) -> Dict[int, List[Tuple[str, float]]]:
        """
        Extract keywords using class-based TF-IDF (c-TF-IDF).
        
        c-TF-IDF treats each topic as a single document by concatenating
        all documents in that topic, then applies TF-IDF.
        """
        stopwords = self._get_stopwords()
        
        # Create count vectorizer
        self.vectorizer_ = CountVectorizer(
            min_df=self.min_df,
            max_df=self.max_df,
            stop_words=stopwords,
            ngram_range=(1, 2),  # Include bigrams
            token_pattern=r'(?u)\b[a-zA-Z][a-zA-Z0-9_-]{1,}\b',
        )
        
        # Fit on all documents
        try:
            count_matrix = self.vectorizer_.fit_transform(documents)
        except ValueError as e:
            # Fallback with simpler settings
            self.vectorizer_ = CountVectorizer(
                min_df=1,
                max_df=1.0,
                stop_words=stopwords,
            )
            count_matrix = self.vectorizer_.fit_transform(documents)
        
        self.vocabulary_ = self.vectorizer_.get_feature_names_out()
        
        # Get unique topic labels (excluding outliers)
        unique_labels = sorted(set(labels[labels >= 0]))
        
        if len(unique_labels) == 0:
            return {}
        
        # Aggregate counts per topic (c-TF)
        n_topics = len(unique_labels)
        n_terms = len(self.vocabulary_)
        
        topic_term_matrix = np.zeros((n_topics, n_terms))
        topic_doc_counts = np.zeros(n_topics)
        
        for topic_idx, topic_id in enumerate(unique_labels):
            mask = labels == topic_id
            topic_counts = count_matrix[mask].sum(axis=0)
            topic_term_matrix[topic_idx] = np.asarray(topic_counts).flatten()
            topic_doc_counts[topic_idx] = np.sum(mask)
        
        # Compute c-TF-IDF
        # TF: term frequency within topic (normalized by total terms in topic)
        topic_sums = topic_term_matrix.sum(axis=1, keepdims=True) + 1e-10
        tf = topic_term_matrix / topic_sums
        
        # IDF: log(total topics / topics containing term + 1)
        term_topic_presence = (topic_term_matrix > 0).sum(axis=0) + 1
        idf = np.log(n_topics / term_topic_presence + 1)
        
        # c-TF-IDF
        ctfidf = tf * idf
        
        # Extract top keywords per topic
        keywords = {}
        for topic_idx, topic_id in enumerate(unique_labels):
            scores = ctfidf[topic_idx]
            top_indices = scores.argsort()[::-1][:self.n_keywords * 2]  # Get more, filter later
            
            topic_keywords = []
            seen_stems = set()
            
            for idx in top_indices:
                if len(topic_keywords) >= self.n_keywords:
                    break
                
                word = self.vocabulary_[idx]
                score = scores[idx]
                
                if score <= 0:
                    continue
                
                # Skip if we've seen a similar word (simple deduplication)
                word_stem = word[:5] if len(word) > 5 else word
                if word_stem in seen_stems:
                    continue
                seen_stems.add(word_stem)
                
                topic_keywords.append((word, float(score)))
            
            keywords[topic_id] = topic_keywords
        
        return keywords
    
    def _extract_bm25(
        self,
        documents: List[str],
        labels: np.ndarray,
    ) -> Dict[int, List[Tuple[str, float]]]:
        """Extract keywords using BM25 scoring."""
        # Fallback to c-TF-IDF for now
        return self._extract_ctfidf(documents, labels)
    
    def _extract_keybert(
        self,
        documents: List[str],
        labels: np.ndarray,
    ) -> Dict[int, List[Tuple[str, float]]]:
        """Extract keywords using KeyBERT (embedding-based)."""
        try:
            from keybert import KeyBERT
            kw_model = KeyBERT()
        except ImportError:
            # Fallback to c-TF-IDF
            return self._extract_ctfidf(documents, labels)
        
        unique_labels = sorted(set(labels[labels >= 0]))
        keywords = {}
        
        for topic_id in unique_labels:
            mask = labels == topic_id
            topic_docs = [documents[i] for i in range(len(documents)) if mask[i]]
            
            # Concatenate topic documents
            topic_text = " ".join(topic_docs[:100])  # Limit for efficiency
            
            try:
                kw = kw_model.extract_keywords(
                    topic_text,
                    keyphrase_ngram_range=(1, 2),
                    stop_words="english",
                    top_n=self.n_keywords,
                )
                keywords[topic_id] = kw
            except Exception:
                keywords[topic_id] = []
        
        return keywords


def get_topic_keywords_simple(
    documents: List[str],
    labels: np.ndarray,
    n_keywords: int = 10,
) -> Dict[int, List[str]]:
    """
    Simple utility function to get keywords for topics.
    
    Parameters
    ----------
    documents : List[str]
        Documents.
    labels : np.ndarray
        Topic labels.
    n_keywords : int
        Number of keywords per topic.
        
    Returns
    -------
    Dict[int, List[str]]
        Topic ID to list of keyword strings.
    """
    extractor = KeywordExtractor(n_keywords=n_keywords)
    keywords_with_scores = extractor.extract_keywords(documents, labels)
    
    return {
        topic_id: [kw for kw, _ in kw_list]
        for topic_id, kw_list in keywords_with_scores.items()
    }
