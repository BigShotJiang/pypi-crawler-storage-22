"""
Iterative Refinement for TriTopic

Implements the iterative embedding refinement process.
"""

from __future__ import annotations

from typing import Optional, Tuple, Callable

import numpy as np
from sklearn.metrics import adjusted_rand_score


class IterativeRefinement:
    """
    Iteratively refines embeddings based on cluster assignments.
    
    The process alternates between:
    1. Clustering documents based on current embeddings
    2. Pulling embeddings toward their cluster centroids
    
    This creates a self-improving loop where topics inform embeddings
    and embeddings inform topics.
    
    Parameters
    ----------
    max_iterations : int
        Maximum number of refinement iterations.
    convergence_threshold : float
        ARI threshold for convergence (0-1).
    refinement_strength : float
        How strongly to pull embeddings toward centroids (0-1).
    verbose : bool
        Whether to print progress.
    """
    
    def __init__(
        self,
        max_iterations: int = 5,
        convergence_threshold: float = 0.95,
        refinement_strength: float = 0.15,
        verbose: bool = True,
    ):
        self.max_iterations = max_iterations
        self.convergence_threshold = convergence_threshold
        self.refinement_strength = refinement_strength
        self.verbose = verbose
        
        self.history_ = []
    
    def refine(
        self,
        embeddings: np.ndarray,
        cluster_fn: Callable[[np.ndarray], np.ndarray],
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Perform iterative refinement.
        
        Parameters
        ----------
        embeddings : np.ndarray
            Initial document embeddings.
        cluster_fn : Callable
            Function that takes embeddings and returns cluster labels.
            
        Returns
        -------
        refined_embeddings : np.ndarray
            Refined embeddings.
        final_labels : np.ndarray
            Final cluster labels.
        """
        current_embeddings = embeddings.copy()
        previous_labels = None
        
        self.history_ = []
        
        for iteration in range(1, self.max_iterations + 1):
            if self.verbose:
                print(f"      Iteration {iteration}...")
            
            # Cluster with current embeddings
            labels = cluster_fn(current_embeddings)
            
            # Check convergence
            if previous_labels is not None:
                ari = adjusted_rand_score(previous_labels, labels)
                self.history_.append({
                    "iteration": iteration,
                    "ari": ari,
                    "n_clusters": len(set(labels[labels >= 0])),
                })
                
                if self.verbose:
                    print(f"         ARI vs previous: {ari:.4f}")
                
                if ari >= self.convergence_threshold:
                    if self.verbose:
                        print(f"      ✓ Converged at iteration {iteration}")
                    return current_embeddings, labels
            
            # Refine embeddings
            current_embeddings = self._refine_embeddings(
                current_embeddings, labels
            )
            
            previous_labels = labels.copy()
        
        if self.verbose:
            print(f"      ✓ Max iterations ({self.max_iterations}) reached")
        
        return current_embeddings, labels
    
    def _refine_embeddings(
        self,
        embeddings: np.ndarray,
        labels: np.ndarray,
    ) -> np.ndarray:
        """
        Refine embeddings by pulling toward cluster centroids.
        
        Parameters
        ----------
        embeddings : np.ndarray
            Current embeddings.
        labels : np.ndarray
            Cluster labels.
            
        Returns
        -------
        refined : np.ndarray
            Refined embeddings.
        """
        refined = embeddings.copy()
        unique_labels = np.unique(labels[labels >= 0])
        
        for label in unique_labels:
            mask = labels == label
            if np.sum(mask) < 2:
                continue
            
            # Compute centroid
            centroid = embeddings[mask].mean(axis=0)
            
            # Pull documents toward centroid
            refined[mask] = (
                (1 - self.refinement_strength) * embeddings[mask] +
                self.refinement_strength * centroid
            )
        
        # Normalize embeddings
        norms = np.linalg.norm(refined, axis=1, keepdims=True)
        norms = np.maximum(norms, 1e-10)
        refined = refined / norms
        
        return refined
