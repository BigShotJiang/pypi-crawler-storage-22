"""
Representative Document Selection for TriTopic

Implements various methods for selecting representative documents.
"""

from __future__ import annotations

from typing import List, Dict, Optional

import numpy as np
from scipy.spatial.distance import cdist


class RepresentativeSelector:
    """
    Selects representative documents for each topic.
    
    Supports multiple selection methods:
    - centroid: Documents closest to topic centroid
    - medoid: The most central actual document
    - archetype: Documents at the extremes (convex hull)
    - diverse: Maximally diverse selection
    
    Parameters
    ----------
    method : str
        Selection method: "centroid", "medoid", "archetype", "diverse".
    n_representatives : int
        Number of representative documents per topic.
    n_archetypes : int
        Number of archetypes if using archetype method.
    """
    
    def __init__(
        self,
        method: str = "centroid",
        n_representatives: int = 5,
        n_archetypes: int = 5,
    ):
        self.method = method
        self.n_representatives = n_representatives
        self.n_archetypes = n_archetypes
    
    def select_representatives(
        self,
        embeddings: np.ndarray,
        labels: np.ndarray,
        documents: Optional[List[str]] = None,
    ) -> Dict[int, List[int]]:
        """
        Select representative documents for each topic.
        
        Parameters
        ----------
        embeddings : np.ndarray
            Document embeddings.
        labels : np.ndarray
            Topic labels.
        documents : List[str], optional
            Document texts (for keyword-based selection).
            
        Returns
        -------
        representatives : Dict[int, List[int]]
            Mapping from topic_id to list of document indices.
        """
        unique_labels = sorted(set(labels[labels >= 0]))
        representatives = {}
        
        for topic_id in unique_labels:
            mask = labels == topic_id
            topic_indices = np.where(mask)[0]
            topic_embeddings = embeddings[mask]
            
            if len(topic_indices) <= self.n_representatives:
                representatives[topic_id] = topic_indices.tolist()
                continue
            
            if self.method == "centroid":
                selected = self._select_by_centroid(topic_embeddings, topic_indices)
            elif self.method == "medoid":
                selected = self._select_by_medoid(topic_embeddings, topic_indices)
            elif self.method == "archetype":
                selected = self._select_by_archetype(topic_embeddings, topic_indices)
            elif self.method == "diverse":
                selected = self._select_diverse(topic_embeddings, topic_indices)
            else:
                selected = self._select_by_centroid(topic_embeddings, topic_indices)
            
            representatives[topic_id] = selected
        
        return representatives
    
    def _select_by_centroid(
        self,
        embeddings: np.ndarray,
        indices: np.ndarray,
    ) -> List[int]:
        """Select documents closest to centroid."""
        centroid = embeddings.mean(axis=0, keepdims=True)
        distances = cdist(embeddings, centroid, metric="cosine").flatten()
        top_k = np.argsort(distances)[:self.n_representatives]
        return indices[top_k].tolist()
    
    def _select_by_medoid(
        self,
        embeddings: np.ndarray,
        indices: np.ndarray,
    ) -> List[int]:
        """Select the medoid and documents close to it."""
        # Compute pairwise distances
        distances = cdist(embeddings, embeddings, metric="cosine")
        
        # Medoid is the point with minimum total distance to all others
        total_distances = distances.sum(axis=1)
        medoid_idx = np.argmin(total_distances)
        
        # Get documents closest to medoid
        distances_to_medoid = distances[medoid_idx]
        top_k = np.argsort(distances_to_medoid)[:self.n_representatives]
        return indices[top_k].tolist()
    
    def _select_by_archetype(
        self,
        embeddings: np.ndarray,
        indices: np.ndarray,
    ) -> List[int]:
        """
        Select archetypal documents (extreme points).
        
        Uses a simple heuristic: find points that are most dissimilar
        from each other (approximates convex hull vertices).
        """
        n_docs = len(embeddings)
        n_select = min(self.n_archetypes, n_docs)
        
        if n_docs <= n_select:
            return indices.tolist()
        
        # Start with the document furthest from centroid
        centroid = embeddings.mean(axis=0)
        distances_to_centroid = cdist(embeddings, centroid.reshape(1, -1), metric="cosine").flatten()
        
        selected_local = [np.argmax(distances_to_centroid)]
        
        # Greedily add points that are furthest from already selected
        for _ in range(1, n_select):
            min_distances = np.full(n_docs, np.inf)
            for sel in selected_local:
                distances = cdist(embeddings, embeddings[sel:sel+1], metric="cosine").flatten()
                min_distances = np.minimum(min_distances, distances)
            
            # Mask already selected
            min_distances[selected_local] = -np.inf
            
            # Select point with maximum minimum distance
            selected_local.append(np.argmax(min_distances))
        
        return indices[selected_local].tolist()
    
    def _select_diverse(
        self,
        embeddings: np.ndarray,
        indices: np.ndarray,
    ) -> List[int]:
        """
        Select maximally diverse documents.
        
        Uses maxmin diversity: iteratively select the point
        furthest from the nearest already-selected point.
        """
        n_docs = len(embeddings)
        n_select = min(self.n_representatives, n_docs)
        
        if n_docs <= n_select:
            return indices.tolist()
        
        # Start with document closest to centroid (most typical)
        centroid = embeddings.mean(axis=0)
        distances_to_centroid = cdist(embeddings, centroid.reshape(1, -1), metric="cosine").flatten()
        selected_local = [np.argmin(distances_to_centroid)]
        
        # Greedily add diverse points
        for _ in range(1, n_select):
            min_distances = np.full(n_docs, np.inf)
            for sel in selected_local:
                distances = cdist(embeddings, embeddings[sel:sel+1], metric="cosine").flatten()
                min_distances = np.minimum(min_distances, distances)
            
            # Mask already selected
            min_distances[selected_local] = -np.inf
            
            # Select point with maximum minimum distance
            selected_local.append(np.argmax(min_distances))
        
        return indices[selected_local].tolist()
