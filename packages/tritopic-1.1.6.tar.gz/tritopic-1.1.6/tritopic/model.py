"""
TriTopic: Tri-Modal Graph Topic Modeling with Iterative Refinement

Main model class that orchestrates all components.
"""

from __future__ import annotations

import pickle
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from scipy import sparse
from tqdm import tqdm

from .config import TriTopicConfig, get_config
from .core.embeddings import EmbeddingEngine
from .core.graph import GraphBuilder, MultiViewGraphBuilder
from .core.clustering import ConsensusLeiden
from .core.refinement import IterativeRefinement
from .core.keywords import KeywordExtractor
from .core.representatives import RepresentativeSelector


@dataclass
class TopicInfo:
    """Represents a single topic with its metadata."""
    topic_id: int
    size: int
    keywords: List[str]
    keyword_scores: List[float]
    representative_docs: List[int]
    representative_texts: List[str] = field(default_factory=list)
    centroid: Optional[np.ndarray] = None
    label: Optional[str] = None
    description: Optional[str] = None
    coherence: Optional[float] = None
    
    def __repr__(self) -> str:
        kw_str = ", ".join(self.keywords[:5])
        label_str = f" ({self.label})" if self.label else ""
        return f"Topic {self.topic_id}{label_str}: [{kw_str}...] (n={self.size})"


class TriTopic:
    """
    Tri-Modal Graph Topic Modeling with Iterative Refinement.
    
    A state-of-the-art topic modeling approach that combines:
    - Multi-view representation (semantic, lexical, metadata)
    - Hybrid graph construction (Mutual kNN + SNN)
    - Consensus Leiden clustering
    - Iterative embedding refinement
    - LLM-powered topic labeling
    
    Parameters
    ----------
    config : TriTopicConfig, optional
        Full configuration object.
    embedding_model : str
        Sentence-Transformer model name.
    n_neighbors : int
        Number of neighbors for graph construction.
    use_iterative_refinement : bool
        Whether to use iterative refinement.
    verbose : bool
        Whether to print progress.
    random_state : int
        Random seed for reproducibility.
    **kwargs
        Additional configuration parameters.
        
    Examples
    --------
    >>> from tritopic import TriTopic
    >>> model = TriTopic(verbose=True)
    >>> topics = model.fit_transform(documents)
    >>> print(model.get_topic_info())
    """
    
    def __init__(
        self,
        config: Optional[TriTopicConfig] = None,
        embedding_model: str = "all-MiniLM-L6-v2",
        n_neighbors: int = 15,
        use_iterative_refinement: bool = True,
        verbose: bool = True,
        random_state: Optional[int] = 42,
        **kwargs
    ):
        # Build configuration
        if config is not None:
            self.config = config
        else:
            self.config = get_config(
                embedding_model=embedding_model,
                n_neighbors=n_neighbors,
                use_iterative_refinement=use_iterative_refinement,
                verbose=verbose,
                random_state=random_state,
                **kwargs
            )
        
        # Initialize components (lazy loading)
        self._embedding_engine = None
        self._graph_builder = None
        self._clusterer = None
        self._keyword_extractor = None
        self._representative_selector = None
        
        # State
        self._is_fitted = False
        self.documents_: Optional[List[str]] = None
        self.embeddings_: Optional[np.ndarray] = None
        self.labels_: Optional[np.ndarray] = None
        self.topics_: List[TopicInfo] = []
        self.graph_: Optional[sparse.csr_matrix] = None
        self.tfidf_matrix_: Optional[sparse.csr_matrix] = None
    
    @property
    def embedding_engine(self) -> EmbeddingEngine:
        """Lazy-load embedding engine."""
        if self._embedding_engine is None:
            self._embedding_engine = EmbeddingEngine(
                model_name=self.config.embedding_model,
                batch_size=self.config.embedding_batch_size,
                show_progress=self.config.verbose,
            )
        return self._embedding_engine
    
    @property
    def graph_builder(self) -> MultiViewGraphBuilder:
        """Lazy-load graph builder."""
        if self._graph_builder is None:
            self._graph_builder = MultiViewGraphBuilder(
                n_neighbors=self.config.n_neighbors,
                graph_type=self.config.graph_type,
                snn_weight=self.config.snn_weight,
                semantic_weight=self.config.semantic_weight,
                lexical_weight=self.config.lexical_weight,
                metadata_weight=self.config.metadata_weight,
                use_lexical=self.config.use_lexical_view,
                use_metadata=self.config.use_metadata_view,
            )
        return self._graph_builder
    
    @property
    def clusterer(self) -> ConsensusLeiden:
        """Lazy-load clusterer."""
        if self._clusterer is None:
            self._clusterer = ConsensusLeiden(
                resolution=self.config.resolution,
                n_runs=self.config.n_consensus_runs,
                min_cluster_size=self.config.min_cluster_size,
                random_state=self.config.random_state,
            )
        return self._clusterer
    
    @property
    def keyword_extractor(self) -> KeywordExtractor:
        """Lazy-load keyword extractor."""
        if self._keyword_extractor is None:
            self._keyword_extractor = KeywordExtractor(
                method=self.config.keyword_method,
                n_keywords=self.config.n_keywords,
                language=self.config.language,
                custom_stopwords=self.config.custom_stopwords,
            )
        return self._keyword_extractor
    
    @property
    def representative_selector(self) -> RepresentativeSelector:
        """Lazy-load representative selector."""
        if self._representative_selector is None:
            self._representative_selector = RepresentativeSelector(
                method=self.config.representative_method,
                n_representatives=self.config.n_representative_docs,
                n_archetypes=self.config.n_archetypes,
            )
        return self._representative_selector
    
    def fit(
        self,
        documents: List[str],
        embeddings: Optional[np.ndarray] = None,
        metadata: Optional[pd.DataFrame] = None,
    ) -> "TriTopic":
        """
        Fit the model to documents.
        
        Parameters
        ----------
        documents : List[str]
            List of documents to fit.
        embeddings : np.ndarray, optional
            Pre-computed embeddings.
        metadata : pd.DataFrame, optional
            Document metadata.
            
        Returns
        -------
        self : TriTopic
            Fitted model.
        """
        n_docs = len(documents)
        self.documents_ = documents
        
        if self.config.verbose:
            print(f"🚀 TriTopic: Fitting model on {n_docs} documents")
            print(f"   Config: {self.config.graph_type} graph, "
                  f"{'iterative' if self.config.use_iterative_refinement else 'single-pass'} mode")
        
        # Step 1: Generate embeddings
        if embeddings is None:
            if self.config.verbose:
                print(f"   → Generating embeddings ({self.config.embedding_model})...")
            self.embeddings_ = self.embedding_engine.encode(documents)
        else:
            self.embeddings_ = embeddings
        
        # Step 2: Build TF-IDF matrix for lexical view
        if self.config.use_lexical_view:
            if self.config.verbose:
                print("   → Building lexical similarity matrix...")
            from sklearn.feature_extraction.text import TfidfVectorizer
            vectorizer = TfidfVectorizer(
                max_features=5000,
                min_df=2,
                max_df=0.95,
                stop_words="english",
            )
            try:
                self.tfidf_matrix_ = vectorizer.fit_transform(documents)
            except ValueError:
                # Fallback with simpler settings
                vectorizer = TfidfVectorizer(max_features=1000)
                self.tfidf_matrix_ = vectorizer.fit_transform(documents)
        
        # Step 3: Build multi-view graph
        metadata_features = None
        if self.config.use_metadata_view and metadata is not None:
            metadata_features = self._encode_metadata(metadata)
        
        # Step 4: Clustering (with optional iterative refinement)
        if self.config.use_iterative_refinement:
            if self.config.verbose:
                print(f"   → Starting iterative refinement (max {self.config.max_iterations} iterations)...")
            
            refiner = IterativeRefinement(
                max_iterations=self.config.max_iterations,
                convergence_threshold=self.config.convergence_threshold,
                refinement_strength=self.config.refinement_strength,
                verbose=self.config.verbose,
            )
            
            def cluster_fn(emb):
                graph = self.graph_builder.build_multiview_graph(
                    emb,
                    documents=documents,
                    tfidf_matrix=self.tfidf_matrix_,
                    metadata=metadata_features,
                )
                return self.clusterer.fit_predict(graph)
            
            self.embeddings_, self.labels_ = refiner.refine(
                self.embeddings_, cluster_fn
            )
        else:
            self.graph_ = self.graph_builder.build_multiview_graph(
                self.embeddings_,
                documents=documents,
                tfidf_matrix=self.tfidf_matrix_,
                metadata=metadata_features,
            )
            self.labels_ = self.clusterer.fit_predict(self.graph_)
        
        # Step 5: Extract keywords and representatives
        if self.config.verbose:
            print("   → Extracting keywords and representative documents...")
        
        self._extract_topic_info(documents)
        
        self._is_fitted = True
        
        # Summary
        n_topics = len([t for t in self.topics_ if t.topic_id >= 0])
        n_outliers = np.sum(self.labels_ == -1)
        outlier_pct = 100 * n_outliers / n_docs
        
        if self.config.verbose:
            print(f"\n✅ Fitting complete!")
            print(f"   Found {n_topics} topics")
            print(f"   {n_outliers} outlier documents ({outlier_pct:.1f}%)")
        
        return self
    
    def fit_transform(
        self,
        documents: List[str],
        embeddings: Optional[np.ndarray] = None,
        metadata: Optional[pd.DataFrame] = None,
    ) -> np.ndarray:
        """
        Fit the model and return topic assignments.
        
        Parameters
        ----------
        documents : List[str]
            Documents to fit.
        embeddings : np.ndarray, optional
            Pre-computed embeddings.
        metadata : pd.DataFrame, optional
            Document metadata.
            
        Returns
        -------
        labels : np.ndarray
            Topic labels for each document.
        """
        self.fit(documents, embeddings, metadata)
        return self.labels_
    
    def transform(
        self,
        documents: List[str],
        embeddings: Optional[np.ndarray] = None,
    ) -> np.ndarray:
        """
        Assign topics to new documents.
        
        Parameters
        ----------
        documents : List[str]
            New documents.
        embeddings : np.ndarray, optional
            Pre-computed embeddings.
            
        Returns
        -------
        labels : np.ndarray
            Topic labels.
        """
        if not self._is_fitted:
            raise ValueError("Model not fitted. Call fit() first.")
        
        # Get embeddings
        if embeddings is None:
            new_embeddings = self.embedding_engine.encode(documents)
        else:
            new_embeddings = embeddings
        
        # Assign to nearest topic centroid
        labels = np.zeros(len(documents), dtype=int)
        
        centroids = []
        topic_ids = []
        for topic in self.topics_:
            if topic.topic_id >= 0 and topic.centroid is not None:
                centroids.append(topic.centroid)
                topic_ids.append(topic.topic_id)
        
        if not centroids:
            return np.full(len(documents), -1)
        
        centroids = np.array(centroids)
        
        for i, emb in enumerate(new_embeddings):
            distances = np.linalg.norm(centroids - emb, axis=1)
            labels[i] = topic_ids[np.argmin(distances)]
        
        return labels
    
    def _encode_metadata(self, metadata: pd.DataFrame) -> np.ndarray:
        """Encode metadata to numeric features."""
        from sklearn.preprocessing import LabelEncoder, StandardScaler
        
        encoded = []
        
        for col in metadata.columns:
            if metadata[col].dtype == "object":
                le = LabelEncoder()
                encoded.append(le.fit_transform(metadata[col].astype(str)))
            else:
                encoded.append(metadata[col].values)
        
        features = np.column_stack(encoded)
        scaler = StandardScaler()
        return scaler.fit_transform(features)
    
    def _extract_topic_info(self, documents: List[str]) -> None:
        """Extract keywords and representatives for each topic."""
        # Get keywords
        keywords_dict = self.keyword_extractor.extract_keywords(
            documents, self.labels_
        )
        
        # Get representatives
        representatives_dict = self.representative_selector.select_representatives(
            self.embeddings_, self.labels_, documents
        )
        
        # Build topic info
        self.topics_ = []
        unique_labels = sorted(set(self.labels_[self.labels_ >= 0]))
        
        for topic_id in unique_labels:
            mask = self.labels_ == topic_id
            size = int(np.sum(mask))
            
            # Keywords
            kw_with_scores = keywords_dict.get(topic_id, [])
            keywords = [kw for kw, _ in kw_with_scores]
            keyword_scores = [score for _, score in kw_with_scores]
            
            # Representatives
            rep_indices = representatives_dict.get(topic_id, [])
            rep_texts = [documents[i] for i in rep_indices]
            
            # Centroid
            centroid = self.embeddings_[mask].mean(axis=0)
            
            self.topics_.append(TopicInfo(
                topic_id=topic_id,
                size=size,
                keywords=keywords,
                keyword_scores=keyword_scores,
                representative_docs=rep_indices,
                representative_texts=rep_texts,
                centroid=centroid,
            ))
        
        # Add outlier topic if exists
        if np.any(self.labels_ == -1):
            outlier_size = int(np.sum(self.labels_ == -1))
            self.topics_.append(TopicInfo(
                topic_id=-1,
                size=outlier_size,
                keywords=["outlier"],
                keyword_scores=[1.0],
                representative_docs=[],
                label="Outliers",
            ))
    
    def get_topic_info(self) -> pd.DataFrame:
        """
        Get summary information about all topics.
        
        Returns
        -------
        df : pd.DataFrame
            DataFrame with columns: Topic, Size, Keywords, Label
        """
        if not self._is_fitted:
            raise ValueError("Model not fitted. Call fit() first.")
        
        data = []
        for topic in self.topics_:
            data.append({
                "Topic": topic.topic_id,
                "Size": topic.size,
                "Keywords": ", ".join(topic.keywords[:5]),
                "All_Keywords": topic.keywords,
                "Keyword_Scores": topic.keyword_scores,
                "Label": topic.label or f"Topic {topic.topic_id}",
                "Representative_Docs": topic.representative_docs,
            })
        
        return pd.DataFrame(data)
    
    def get_topic(self, topic_id: int) -> Optional[TopicInfo]:
        """Get information about a specific topic."""
        for topic in self.topics_:
            if topic.topic_id == topic_id:
                return topic
        return None
    
    def get_representative_docs(
        self,
        topic_id: int,
        n_docs: int = 5,
    ) -> List[Tuple[int, str]]:
        """
        Get representative documents for a topic.
        
        Parameters
        ----------
        topic_id : int
            Topic ID.
        n_docs : int
            Number of documents to return.
            
        Returns
        -------
        docs : List[Tuple[int, str]]
            List of (index, document_text) tuples.
        """
        if not self._is_fitted or self.documents_ is None:
            raise ValueError("Model not fitted. Call fit() first.")
        
        topic = self.get_topic(topic_id)
        if topic is None:
            raise ValueError(f"Topic {topic_id} not found.")
        
        indices = topic.representative_docs[:n_docs]
        return [(idx, self.documents_[idx]) for idx in indices]
    
    def generate_labels(
        self,
        labeler: "LLMLabeler",
        topics: Optional[List[int]] = None,
        context: Optional[str] = None,
    ) -> None:
        """
        Generate labels for topics using an LLM.
        
        Parameters
        ----------
        labeler : LLMLabeler
            Configured LLM labeler instance.
        topics : List[int], optional
            Specific topics to label. If None, labels all.
        context : str, optional
            Context about the corpus to include in prompts.
        """
        if not self._is_fitted:
            raise ValueError("Model not fitted. Call fit() first.")
        
        topics_to_label = topics or [t.topic_id for t in self.topics_ if t.topic_id >= 0]
        
        if self.config.verbose:
            print(f"   → Generating LLM labels for {len(topics_to_label)} topics...")
        
        for topic in tqdm(self.topics_, disable=not self.config.verbose):
            if topic.topic_id not in topics_to_label:
                continue
            
            if topic.topic_id < 0:
                continue
            
            try:
                label = labeler.generate_label(
                    keywords=topic.keywords,
                    representative_docs=topic.representative_texts,
                    context=context,
                )
                topic.label = label
            except Exception as e:
                if self.config.verbose:
                    print(f"      Warning: Failed to generate label for topic {topic.topic_id}: {e}")
                topic.label = f"Topic {topic.topic_id}"
    
    def visualize(
        self,
        method: str = "umap",
        width: int = 800,
        height: int = 600,
        **kwargs
    ):
        """
        Create an interactive visualization of topics.
        
        Parameters
        ----------
        method : str
            Dimensionality reduction method: "umap" or "tsne".
        width : int
            Plot width.
        height : int
            Plot height.
            
        Returns
        -------
        fig : plotly.graph_objects.Figure
            Interactive plotly figure.
        """
        if not self._is_fitted:
            raise ValueError("Model not fitted. Call fit() first.")
        
        import plotly.express as px
        from umap import UMAP
        
        # Reduce to 2D
        reducer = UMAP(
            n_components=2,
            random_state=self.config.random_state,
            **kwargs
        )
        coords = reducer.fit_transform(self.embeddings_)
        
        # Create DataFrame
        df = pd.DataFrame({
            "x": coords[:, 0],
            "y": coords[:, 1],
            "topic": [str(l) for l in self.labels_],
            "text": [doc[:100] + "..." if len(doc) > 100 else doc 
                     for doc in self.documents_],
        })
        
        fig = px.scatter(
            df,
            x="x",
            y="y",
            color="topic",
            hover_data=["text"],
            title="TriTopic Document Map",
            width=width,
            height=height,
        )
        
        return fig
    
    def visualize_topics(
        self,
        n_keywords: int = 8,
        width: int = 800,
        height: int = 400,
    ):
        """
        Create a bar chart visualization of topic keywords.
        
        Parameters
        ----------
        n_keywords : int
            Number of keywords to show per topic.
        width : int
            Plot width.
        height : int
            Plot height.
            
        Returns
        -------
        fig : plotly.graph_objects.Figure
            Interactive plotly figure.
        """
        if not self._is_fitted:
            raise ValueError("Model not fitted. Call fit() first.")
        
        import plotly.graph_objects as go
        from plotly.subplots import make_subplots
        
        topics = [t for t in self.topics_ if t.topic_id >= 0]
        n_topics = len(topics)
        
        fig = make_subplots(
            rows=1, cols=n_topics,
            subplot_titles=[t.label or f"Topic {t.topic_id}" for t in topics],
        )
        
        for i, topic in enumerate(topics):
            kw = topic.keywords[:n_keywords]
            scores = topic.keyword_scores[:n_keywords]
            
            fig.add_trace(
                go.Bar(
                    y=kw[::-1],
                    x=scores[::-1],
                    orientation="h",
                    name=f"Topic {topic.topic_id}",
                ),
                row=1,
                col=i + 1,
            )
        
        fig.update_layout(
            title="Topic Keywords",
            showlegend=False,
            width=width,
            height=height,
        )
        
        return fig
    
    def evaluate(self) -> Dict[str, float]:
        """
        Evaluate topic model quality.
        
        Returns
        -------
        metrics : Dict[str, float]
            Dictionary of evaluation metrics.
        """
        if not self._is_fitted:
            raise ValueError("Model not fitted. Call fit() first.")
        
        metrics = {
            "n_topics": len([t for t in self.topics_ if t.topic_id >= 0]),
            "outlier_ratio": float(np.sum(self.labels_ == -1) / len(self.labels_)),
        }
        
        # Topic diversity
        all_keywords = []
        for topic in self.topics_:
            if topic.topic_id >= 0:
                all_keywords.extend(topic.keywords[:10])
        
        if all_keywords:
            metrics["diversity"] = len(set(all_keywords)) / len(all_keywords)
        
        return metrics
    
    def save(self, path: Union[str, Path]) -> None:
        """Save model to file."""
        path = Path(path)
        with open(path, "wb") as f:
            pickle.dump(self, f)
    
    @classmethod
    def load(cls, path: Union[str, Path]) -> "TriTopic":
        """Load model from file."""
        path = Path(path)
        with open(path, "rb") as f:
            return pickle.load(f)
