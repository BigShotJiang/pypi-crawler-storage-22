"""
Multilingual Support for TriTopic

Provides language detection, tokenization, and stopwords
for multiple languages.
"""

from __future__ import annotations

from typing import List, Optional, Set
import re


# Stopwords for different languages
STOPWORDS = {
    "en": {
        'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you',
        "you're", "you've", "you'll", "you'd", 'your', 'yours', 'yourself',
        'yourselves', 'he', 'him', 'his', 'himself', 'she', "she's", 'her',
        'hers', 'herself', 'it', "it's", 'its', 'itself', 'they', 'them',
        'their', 'theirs', 'themselves', 'what', 'which', 'who', 'whom',
        'this', 'that', "that'll", 'these', 'those', 'am', 'is', 'are',
        'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had',
        'having', 'do', 'does', 'did', 'doing', 'a', 'an', 'the', 'and',
        'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 'at',
        'by', 'for', 'with', 'about', 'against', 'between', 'into',
        'through', 'during', 'before', 'after', 'above', 'below', 'to',
        'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under',
        'again', 'further', 'then', 'once', 'here', 'there', 'when',
        'where', 'why', 'how', 'all', 'each', 'few', 'more', 'most',
        'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same',
        'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 'just',
        'don', "don't", 'should', "should've", 'now',
    },
    
    "de": {
        'der', 'die', 'das', 'ein', 'eine', 'einer', 'einem', 'einen',
        'und', 'oder', 'aber', 'denn', 'weil', 'wenn', 'als', 'ob',
        'ist', 'sind', 'war', 'waren', 'sein', 'haben', 'hat', 'hatte',
        'wird', 'werden', 'wurde', 'würde', 'kann', 'können', 'muss',
        'ich', 'du', 'er', 'sie', 'es', 'wir', 'ihr', 'man',
        'mich', 'mir', 'sich', 'uns', 'euch', 'ihnen',
        'mein', 'dein', 'sein', 'ihr', 'unser', 'euer',
        'nicht', 'kein', 'keine', 'keiner',
        'von', 'mit', 'zu', 'bei', 'nach', 'aus', 'für', 'über', 'unter',
        'auf', 'an', 'in', 'vor', 'hinter', 'neben', 'zwischen',
        'auch', 'noch', 'schon', 'nur', 'sehr', 'mehr', 'so', 'da',
    },
    
    "fr": {
        'le', 'la', 'les', 'un', 'une', 'des', 'du', 'de', 'et', 'ou',
        'mais', 'donc', 'car', 'ni', 'que', 'qui', 'quoi', 'dont', 'où',
        'je', 'tu', 'il', 'elle', 'nous', 'vous', 'ils', 'elles',
        'me', 'te', 'se', 'lui', 'leur', 'mon', 'ton', 'son', 'notre',
        'votre', 'ce', 'cette', 'ces', 'est', 'sont', 'était', 'étaient',
        'être', 'avoir', 'fait', 'faire', 'dit', 'dire', 'pas', 'plus',
        'tout', 'tous', 'toute', 'toutes', 'avec', 'sans', 'pour', 'par',
        'sur', 'sous', 'dans', 'en', 'au', 'aux', 'très', 'bien',
    },
    
    "es": {
        'el', 'la', 'los', 'las', 'un', 'una', 'unos', 'unas', 'y', 'o',
        'pero', 'que', 'de', 'del', 'al', 'en', 'con', 'por', 'para',
        'yo', 'tú', 'él', 'ella', 'nosotros', 'vosotros', 'ellos', 'ellas',
        'mi', 'tu', 'su', 'nuestro', 'vuestro', 'este', 'esta', 'estos',
        'estas', 'ese', 'esa', 'esos', 'esas', 'es', 'son', 'está', 'están',
        'era', 'eran', 'ser', 'estar', 'tener', 'hacer', 'no', 'más',
        'muy', 'todo', 'toda', 'todos', 'todas', 'como', 'cuando', 'donde',
    },
}


def detect_language(texts: List[str], n_samples: int = 100) -> str:
    """
    Detect the primary language of a text corpus.
    
    Parameters
    ----------
    texts : List[str]
        Documents to analyze.
    n_samples : int
        Number of documents to sample.
        
    Returns
    -------
    language : str
        ISO 639-1 language code.
    """
    try:
        from langdetect import detect_langs
        
        import random
        sample = random.sample(texts, min(n_samples, len(texts)))
        combined = " ".join(sample)[:10000]
        
        langs = detect_langs(combined)
        if langs:
            return langs[0].lang
        return "en"
    
    except ImportError:
        # Fallback: simple heuristic
        return _detect_language_simple(texts)


def _detect_language_simple(texts: List[str]) -> str:
    """Simple language detection based on stopword frequency."""
    combined = " ".join(texts[:100]).lower()
    words = set(re.findall(r'\b\w+\b', combined))
    
    scores = {}
    for lang, stopwords in STOPWORDS.items():
        overlap = len(words & stopwords)
        scores[lang] = overlap
    
    if scores:
        return max(scores, key=scores.get)
    return "en"


def get_stopwords(language: str, additional: Optional[List[str]] = None) -> Set[str]:
    """
    Get stopwords for a language.
    
    Parameters
    ----------
    language : str
        ISO 639-1 language code.
    additional : List[str], optional
        Additional stopwords to add.
        
    Returns
    -------
    stopwords : Set[str]
        Set of stopwords.
    """
    base = STOPWORDS.get(language, STOPWORDS.get("en", set()))
    
    if additional:
        base = base | set(additional)
    
    return base


def get_tokenizer(language: str):
    """
    Get an appropriate tokenizer for a language.
    
    Parameters
    ----------
    language : str
        ISO 639-1 language code.
        
    Returns
    -------
    tokenizer : callable
        Tokenizer function.
    """
    if language in ["zh", "chinese"]:
        try:
            import jieba
            return lambda text: list(jieba.cut(text))
        except ImportError:
            pass
    
    elif language in ["ja", "japanese"]:
        try:
            import fugashi
            tagger = fugashi.Tagger()
            return lambda text: [word.surface for word in tagger(text)]
        except ImportError:
            pass
    
    elif language in ["ko", "korean"]:
        try:
            from konlpy.tag import Okt
            okt = Okt()
            return lambda text: okt.morphs(text)
        except ImportError:
            pass
    
    elif language in ["th", "thai"]:
        try:
            from pythainlp.tokenize import word_tokenize
            return word_tokenize
        except ImportError:
            pass
    
    # Default: whitespace tokenizer
    return lambda text: text.split()


# Recommended models for different languages
RECOMMENDED_MODELS = {
    "en": "all-MiniLM-L6-v2",
    "de": "T-Systems-onsite/cross-en-de-roberta-sentence-transformer",
    "fr": "camembert-base",
    "es": "hiiamsid/sentence_similarity_spanish_es",
    "zh": "shibing624/text2vec-base-chinese",
    "ja": "cl-tohoku/bert-base-japanese-v3",
    "ko": "jhgan/ko-sroberta-multitask",
    "multi": "paraphrase-multilingual-MiniLM-L12-v2",
}


def get_recommended_model(language: str) -> str:
    """Get recommended embedding model for a language."""
    return RECOMMENDED_MODELS.get(language, RECOMMENDED_MODELS["multi"])
