File comparison
=========================
.. automodule:: TRSFX.compare
    :members: