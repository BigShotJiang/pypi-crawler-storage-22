File Manipulation
=================
.. automodule:: TRSFX.manipulation
    :members: