"""Standalone OpenAI-compatible proxy for Truffle gRPC inference."""
