"""
TrustGate Python SDK with Automatic Context for Enterprises.

Provides a drop-in compatible client and multi-model patching (OpenAI, Anthropic, Gemini)
for the TrustGate gateway. All patches use context.build_trustgate_headers() for
Shadow AI detection (local_script, n8n, github_actions, gitlab_ci).
"""

from trustgate._version import __version__

from trustgate.client import TrustGate
from trustgate.exceptions import TrustGatePolicyViolation
from trustgate.gemini import TrustGateGeminiClient, patch_google_generativeai
from trustgate.patch import patch_all, patch_anthropic, patch_openai
from trustgate.tracer import tracer

__all__ = [
    "TrustGate",
    "TrustGateGeminiClient",
    "TrustGatePolicyViolation",
    "patch_openai",
    "patch_anthropic",
    "patch_google_generativeai",
    "patch_all",
    "tracer",
    "__version__",
]
