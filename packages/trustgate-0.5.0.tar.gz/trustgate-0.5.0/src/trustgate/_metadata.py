"""
Source tool metadata for TrustGate requests (Node.js parity).
Includes sdk_version, python_version, os, and arch; all keys lowercase.
"""

import platform

from trustgate._version import __version__ as _sdk_version


def get_source_tool_metadata() -> dict:
    """Build the source_tool metadata dict for gateway requests."""
    return {
        "sdk_version": _sdk_version,
        "python_version": platform.python_version(),
        "os": platform.system().lower(),
        "arch": platform.machine().lower(),
    }
