"""
TrustGate HTTP client wrapping httpx.

Provides tg.chat.completions.create() mirroring the OpenAI signature
with automatic TrustGate header injection. On 403 Forbidden, raises
TrustGatePolicyViolation with error.message from the response body.
finish_reason: "content_filter" in 200 responses is passed through without raising.
"""

from __future__ import annotations

import json

import httpx

from trustgate.context import build_trustgate_headers
from trustgate.exceptions import TrustGatePolicyViolation


class _ChatCompletions:
    """Chat completions resource: tg.chat.completions.create(**kwargs)."""

    def __init__(self, client: TrustGate) -> None:
        self._client = client

    def create(
        self,
        *,
        workflow_step: str | None = None,
        source_tool_override: dict | None = None,
        **kwargs,
    ) -> dict:
        """
        Create a chat completion (OpenAI-compatible signature).

        Forwards model, messages, temperature, etc. to the TrustGate gateway
        and injects x-trustgate-* headers automatically.

        Optional TrustGate context:
            workflow_step: Set x-trustgate-workflow-step for this request
                (e.g. 'Data_Extraction', 'Final_Summary' for Gantt visibility).
            source_tool_override: Dict merged into source_tool metadata
                (e.g. {"step_name": "extract"}).
        """
        return self._client._post_chat_completions(
            kwargs,
            workflow_step=workflow_step,
            source_tool_override=source_tool_override,
        )


class _Chat:
    """Chat resource: tg.chat.completions."""

    def __init__(self, client: TrustGate) -> None:
        self._client = client
        self._completions = _ChatCompletions(client)

    @property
    def completions(self) -> _ChatCompletions:
        return self._completions


class TrustGate:
    """
    TrustGate gateway client using httpx.

    Use tg.chat.completions.create() with the same arguments as
    openai.chat.completions.create(); headers are injected automatically.
    """

    def __init__(
        self,
        base_url: str,
        api_key: str | None = None,
        timeout: float | httpx.Timeout | None = None,
        **kwargs: object,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._timeout = timeout
        self._client = httpx.Client(
            base_url=self._base_url,
            timeout=timeout or 60.0,
            **kwargs,
        )
        self.chat = _Chat(self)

    def _headers(
        self,
        workflow_step: str | None = None,
        source_tool_override: dict | None = None,
    ) -> dict[str, str]:
        """Request headers: TrustGate context + Authorization Bearer (primary auth)."""
        return build_trustgate_headers(
            workflow_step=workflow_step,
            source_tool_override=source_tool_override,
            api_key=self._api_key,
        )

    def _post_chat_completions(
        self,
        body: dict,
        workflow_step: str | None = None,
        source_tool_override: dict | None = None,
    ) -> dict:
        """POST to /v1/chat/completions with TrustGate headers. Raises TrustGatePolicyViolation on 403."""
        response = self._client.post(
            "/v1/chat/completions",
            json=body,
            headers=self._headers(
                workflow_step=workflow_step,
                source_tool_override=source_tool_override,
            ),
        )
        if response.status_code == 403:
            msg = "Policy violation (403)"
            try:
                data = response.json()
                err = data.get("error") if isinstance(data.get("error"), dict) else None
                if err and isinstance(err.get("message"), str):
                    msg = err["message"]
                elif isinstance(data.get("message"), str):
                    msg = data["message"]
            except (json.JSONDecodeError, TypeError):
                pass
            raise TrustGatePolicyViolation(msg, status_code=403)
        response.raise_for_status()
        # finish_reason: "content_filter" in 200 response is passed through (no error)
        return response.json()

    def close(self) -> None:
        """Close the underlying httpx client."""
        self._client.close()

    def __enter__(self) -> TrustGate:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
