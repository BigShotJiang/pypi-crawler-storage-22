"""
Universal Context Brain for TrustGate (Node.js parity).

Detects n8n, GitHub Actions, and GitLab CI via environment variables.
If no managed environment is detected, source is always "local_script" for
Shadow AI identification. All header keys are lowercase for consistent gateway parsing.

Primary auth: Authorization: Bearer <tg_sk_...> (from TRUSTGATE_API_KEY).
Provider-specific headers (e.g. x-api-key) are NOT set here; the gateway injects them server-side.
"""

import json
import os
import platform
import uuid

from trustgate._metadata import get_source_tool_metadata
from trustgate._version import __version__ as _sdk_version
from trustgate.tracer import tracer


def _detect_source() -> str:
    """Detect execution environment from env vars. Always returns local_script if no managed env (Shadow AI)."""
    if os.environ.get("N8N_EXECUTION_ID"):
        return "n8n"
    if os.environ.get("GITHUB_ACTIONS") == "true":
        return "github_actions"
    if os.environ.get("GITLAB_CI") == "true":
        return "gitlab_ci"
    return "local_script"


def _get_trace_id() -> str:
    """Resolve trace id from environment or generate one."""
    if os.environ.get("N8N_EXECUTION_ID"):
        return os.environ["N8N_EXECUTION_ID"]
    if os.environ.get("GITHUB_RUN_ID"):
        return os.environ["GITHUB_RUN_ID"]
    if os.environ.get("GITLAB_CI") and os.environ.get("CI_PIPELINE_ID"):
        return os.environ["CI_PIPELINE_ID"]
    return str(uuid.uuid4())


def _get_workflow_name() -> str | None:
    """Resolve workflow/pipeline name from environment."""
    if os.environ.get("N8N_EXECUTION_ID"):
        return (
            os.environ.get("N8N_WORKFLOW_NAME")
            or os.environ.get("N8N_WORKFLOW_ID")
            or "n8n"
        )
    if os.environ.get("GITHUB_ACTIONS") == "true":
        return os.environ.get("GITHUB_WORKFLOW") or "github_actions"
    if os.environ.get("GITLAB_CI") == "true":
        return (
            os.environ.get("CI_JOB_NAME")
            or os.environ.get("CI_PIPELINE_SOURCE")
            or "gitlab_ci"
        )
    return None


def _get_workflow_step_from_n8n() -> str | None:
    """
    Shadow AI / n8n: resolve workflow step from node context when running in n8n.
    Uses N8N_NODE_ID or N8N_NODE_NAME so the gateway can show granular steps
    (e.g. 'Data_Extraction' vs 'Final_Summary') in the Agent Intelligence Gantt.
    """
    if not os.environ.get("N8N_EXECUTION_ID"):
        return None
    return (
        os.environ.get("N8N_NODE_NAME")
        or os.environ.get("N8N_NODE_ID")
        or None
    )


def build_trustgate_headers(
    include_metadata: bool = True,
    workflow_step: str | None = None,
    source_tool_override: dict | None = None,
    api_key: str | None = None,
) -> dict[str, str]:
    """
    Build headers for TrustGate gateway requests. All keys are lowercase for
    Node.js SDK and gateway parity.

    Primary auth: Authorization: Bearer <tg_sk_...> (api_key arg or TRUSTGATE_API_KEY env).
    workflow_step is sent as x-trustgate-workflow-step.
    System metadata is sent with x-trustlog- prefix (os, arch, python_version).
    User-Agent is set to trustgate-python/<version> so the gateway can infer the source tool.
    """
    source = _detect_source()
    trace_id = _get_trace_id()
    workflow_name = _get_workflow_name()

    headers: dict[str, str] = {
        "x-trustgate-source": source,
        "x-trustgate-trace-id": trace_id,
        "user-agent": f"trustgate-python/{_sdk_version}",
    }

    # Primary auth: Bearer token (gateway injects provider keys server-side)
    key = api_key or os.environ.get("TRUSTGATE_API_KEY")
    if key:
        headers["authorization"] = f"Bearer {key}"

    if workflow_name:
        headers["x-trustgate-workflow-name"] = workflow_name

    # workflow_step -> x-trustgate-workflow-step (Gantt / Agent Intelligence)
    step = workflow_step if workflow_step is not None else _get_workflow_step_from_n8n()
    if step:
        headers["x-trustgate-workflow-step"] = step

    # System metadata with x-trustlog- prefix
    headers["x-trustlog-os"] = platform.system().lower()
    headers["x-trustlog-arch"] = platform.machine().lower()
    headers["x-trustlog-python-version"] = platform.python_version()

    if include_metadata:
        metadata = dict(get_source_tool_metadata())
        if source_tool_override:
            metadata.update(source_tool_override)
        headers["x-trustgate-source-tool"] = json.dumps(metadata)

    # --- TRACING INJECTION ---
    # If the user is inside a 'with tracer.span():' block, use that context.
    if tracer.is_active:
        headers["x-trustgate-trace-id"] = tracer.trace_id
        headers["x-trustgate-span-id"] = tracer.current_span_id or ""
        # Parent of the current span (so gateway can build hierarchy; empty when in root span)
        headers["x-trustgate-parent-id"] = tracer.parent_span_id or ""
    else:
        if "x-trustgate-trace-id" not in headers:
            headers["x-trustgate-trace-id"] = _get_trace_id()

    # All keys lowercase for consistent gateway parsing (design constraint)
    return {k.lower(): v for k, v in headers.items()}
