"""
TrustGate SDK exceptions.

TrustGatePolicyViolation is raised when the gateway returns 403 Forbidden
due to a policy violation (e.g. error.message from the response body).
"""


class TrustGatePolicyViolation(Exception):
    """
    Raised when the TrustGate gateway returns 403 Forbidden for a policy violation.

    The message is taken from the response body's error.message when present.
    """

    def __init__(self, message: str, status_code: int = 403) -> None:
        self.status_code = status_code
        super().__init__(message)
