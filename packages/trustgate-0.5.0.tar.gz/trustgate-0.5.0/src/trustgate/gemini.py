"""
TrustGate support for Google Gemini (google.generativeai / google-generativeai).

Provides patch_google_generativeai() to inject x-trustgate-* headers so the
gateway can track Google LLM calls; uses context.build_trustgate_headers()
for Shadow AI detection (local_script, n8n, etc.).
"""

from __future__ import annotations

import json
import os
from typing import Any

from trustgate.context import build_trustgate_headers
from trustgate.exceptions import TrustGatePolicyViolation

DEFAULT_TRUSTGATE_GEMINI_BASE_URL = "https://gateway.trustgate.ai"


def patch_google_generativeai(
    base_url: str | None = None,
    workflow_step: str | None = None,
) -> None:
    """
    Patch the Google Generative AI client (legacy google.generativeai or new
    google.genai) so that requests include x-trustgate-* headers from
    context.build_trustgate_headers() (Shadow AI detection).

    Call once at startup. If the legacy package (google-generativeai) is
    installed, patches the module's client to add our headers. If the new
    package (google-genai) is installed, patches the Client to add headers.
    Traffic can be sent to the gateway via base_url when the gateway proxies Gemini.

    Args:
        base_url: Optional gateway base URL for Gemini. If set, the patched
                  client will use this URL instead of the default Google endpoint.
        workflow_step: Default x-trustgate-workflow-step for every request.
    """
    gateway_url = (
        base_url
        or os.environ.get("TRUSTGATE_GEMINI_BASE_URL")
        or os.environ.get("TRUSTGATE_BASE_URL")
        or DEFAULT_TRUSTGATE_GEMINI_BASE_URL
    )
    gateway_url = gateway_url.rstrip("/")
    trustgate_headers = build_trustgate_headers(workflow_step=workflow_step)

    # New package: google.genai (google-genai) — Client accepts default_headers
    try:
        from google import genai as genai_new

        if not getattr(genai_new, "_trustgate_patched", False):
            _orig_client_init = genai_new.Client.__init__

            def _patched_client_init(
                self: Any,
                *args: Any,
                **kwargs: Any,
            ) -> None:
                default_headers = kwargs.get("default_headers") or {}
                kwargs["default_headers"] = {**trustgate_headers, **dict(default_headers)}
                if gateway_url and (base_url or os.environ.get("TRUSTGATE_GEMINI_BASE_URL")):
                    opts = kwargs.get("http_options") or {}
                    if isinstance(opts, dict):
                        opts = {**opts, "api_endpoint": gateway_url}
                        kwargs["http_options"] = opts
                _orig_client_init(self, *args, **kwargs)

            genai_new.Client.__init__ = _patched_client_init  # type: ignore[method-assign]
            genai_new._trustgate_patched = True  # type: ignore[attr-defined]
    except ImportError:
        pass

    # Legacy package: google.generativeai — inject headers into request (client or generate_content path)
    try:
        import google.generativeai as genai_legacy
    except ImportError:
        genai_legacy = None
    if genai_legacy is not None and not getattr(genai_legacy, "_trustgate_legacy_patched", False):
        try:
            from google.generativeai import generative_models as gm

            if hasattr(gm, "GenerativeModel"):
                _orig_gc = gm.GenerativeModel.generate_content

                def _patched_gc(self: Any, *args: Any, **kwargs: Any) -> Any:
                    # Inject x-trustgate-* into request metadata where supported
                    ro = kwargs.get("request_options")
                    if ro is None:
                        kwargs["request_options"] = {"custom_headers": dict(trustgate_headers)}
                    elif isinstance(ro, dict):
                        ch = ro.get("custom_headers") or ro.get("headers") or {}
                        kwargs["request_options"] = {**ro, "custom_headers": {**trustgate_headers, **dict(ch)}}
                    return _orig_gc(self, *args, **kwargs)

                gm.GenerativeModel.generate_content = _patched_gc  # type: ignore[method-assign]
            # If the module uses a shared client with a request method, wrap it
            if hasattr(genai_legacy, "client"):
                _mod = getattr(genai_legacy, "client", None)
                if _mod and hasattr(_mod, "_http_client"):
                    _hc = getattr(_mod, "_http_client", None)
                    if _hc and callable(getattr(_hc, "request", None)):
                        _orig_req = _hc.request

                        def _wrapped_req(*a: Any, **kw: Any) -> Any:
                            kw["headers"] = {**trustgate_headers, **dict(kw.get("headers") or {})}
                            return _orig_req(*a, **kw)

                        _hc.request = _wrapped_req  # type: ignore[assignment]
            genai_legacy._trustgate_legacy_patched = True  # type: ignore[attr-defined]
        except Exception:
            pass  # legacy SDK structure may differ; TrustGateGeminiClient still available


class TrustGateGeminiClient:
    """
    Wrapper that sends Gemini-style requests to the TrustGate gateway with
    x-trustgate-* headers (from context.build_trustgate_headers()) so the
    gateway can track and proxy Google LLM calls.
    """

    def __init__(
        self,
        base_url: str,
        api_key: str | None = None,
        workflow_step: str | None = None,
        source_tool_override: dict | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._workflow_step = workflow_step
        self._source_tool_override = source_tool_override

    def _headers(self) -> dict[str, str]:
        h = build_trustgate_headers(
            workflow_step=self._workflow_step,
            source_tool_override=self._source_tool_override,
            api_key=self._api_key,
        )
        # Auth: Bearer only; gateway injects provider keys (e.g. x-goog-api-key) server-side
        return h

    def generate_content(
        self,
        model: str,
        contents: str | list[Any],
        **kwargs: Any,
    ) -> Any:
        """
        Generate content via the TrustGate gateway (gateway must proxy to Gemini).
        Uses the same context headers as other TrustGate patches (local_script, etc.).
        """
        import httpx

        if isinstance(contents, list):
            contents_payload = contents
        else:
            contents_payload = [{"role": "user", "parts": [{"text": contents}]}]
        payload = {"contents": contents_payload, **kwargs}
        url = f"{self._base_url}/v1beta/models/{model}:generateContent"
        with httpx.Client() as client:
            r = client.post(url, json=payload, headers=self._headers(), timeout=60.0)
            if r.status_code == 403:
                msg = "Policy violation (403)"
                try:
                    data = r.json()
                    err = data.get("error") if isinstance(data.get("error"), dict) else None
                    if err and isinstance(err.get("message"), str):
                        msg = err["message"]
                    elif isinstance(data.get("message"), str):
                        msg = data["message"]
                except (json.JSONDecodeError, TypeError):
                    pass
                raise TrustGatePolicyViolation(msg, status_code=403)
            r.raise_for_status()
            return r.json()
