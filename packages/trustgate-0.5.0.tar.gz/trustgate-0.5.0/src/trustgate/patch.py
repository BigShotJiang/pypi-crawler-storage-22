"""
Multi-model patching for TrustGate gateway (Node.js parity).

All headers are lowercase. patch_all() is the primary entry point and runs
OpenAI, Anthropic, and Google Gemini patches sequentially. workflow_step
drives Gantt chart bars in the Agent Intelligence dashboard.

Auth: Only Authorization: Bearer <tg_sk_...> is sent; provider headers
(x-api-key, etc.) are NOT injected—the gateway injects them server-side.
User-Agent is set to trustgate-python/0.4.0 via context.build_trustgate_headers().
"""

import json
import os
from typing import Any

import httpx

from trustgate.context import build_trustgate_headers
from trustgate.exceptions import TrustGatePolicyViolation

# Production gateway (env TRUSTGATE_BASE_URL / TRUSTGATE_ANTHROPIC_BASE_URL override when set)
DEFAULT_TRUSTGATE_BASE_URL = "https://gateway.trustgate.ai/v1"
DEFAULT_TRUSTGATE_ANTHROPIC_BASE_URL = "https://gateway.trustgate.ai"

# Provider-specific headers that must NOT be sent by the SDK; gateway injects them server-side.
_PROVIDER_AUTH_HEADERS = frozenset(
    k.lower()
    for k in (
        "x-api-key",
        "x-goog-api-key",
        "api-key",
    )
)


def _trustgate_headers_only(trustgate_headers: dict[str, str], existing: dict[str, str] | None) -> dict[str, str]:
    """Merge TrustGate headers with existing, stripping any provider auth headers."""
    existing = existing or {}
    merged = {**trustgate_headers, **dict(existing)}
    return {k: v for k, v in merged.items() if k.lower() not in _PROVIDER_AUTH_HEADERS}


def _raise_if_403(response: httpx.Response) -> None:
    """If response is 403, parse error.message and raise TrustGatePolicyViolation."""
    if response.status_code != 403:
        return
    msg = "Policy violation (403)"
    try:
        body = response.content
        if body:
            data = json.loads(body)
            err = data.get("error") if isinstance(data.get("error"), dict) else None
            if err and isinstance(err.get("message"), str):
                msg = err["message"]
            elif isinstance(data.get("message"), str):
                msg = data["message"]
    except (json.JSONDecodeError, TypeError):
        pass
    raise TrustGatePolicyViolation(msg, status_code=403)


class _TrustGateTransport(httpx.HTTPTransport):
    """HTTP transport that raises TrustGatePolicyViolation on 403 with error.message from body."""

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        response = super().handle_request(request)
        _raise_if_403(response)
        return response


class _AsyncTrustGateTransport(httpx.AsyncHTTPTransport):
    """Async transport that raises TrustGatePolicyViolation on 403 with error.message from body."""

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        response = await super().handle_async_request(request)
        _raise_if_403(response)
        return response


def patch_openai(
    base_url: str | None = None,
    workflow_step: str | None = None,
) -> None:
    """
    Intercept openai.OpenAI so that requests use the TrustGate gateway and
    include lowercase x-trustgate-* headers in default_headers.

    Args:
        base_url: TrustGate gateway base URL (e.g. https://gateway.trustgate.ai/v1).
                  If None, uses env TRUSTGATE_BASE_URL or production default.
        workflow_step: x-trustgate-workflow-step for every request; key for
                       Gantt chart bars in the Agent Intelligence dashboard.
                       In n8n, step can also be auto-set from N8N_NODE_ID/N8N_NODE_NAME.
    """
    import openai

    gateway_url = (
        base_url
        or os.environ.get("TRUSTGATE_BASE_URL")
        or DEFAULT_TRUSTGATE_BASE_URL
    )
    gateway_url = gateway_url.rstrip("/")
    if not gateway_url.endswith("/v1"):
        gateway_url = f"{gateway_url}/v1"

    # build_trustgate_headers returns lowercase keys (gateway requirement); no provider headers
    trustgate_headers = build_trustgate_headers(workflow_step=workflow_step)

    _original_init = openai.OpenAI.__init__

    def _patched_init(
        self: Any,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        kwargs["base_url"] = gateway_url
        existing = kwargs.get("default_headers") or {}
        kwargs["default_headers"] = _trustgate_headers_only(trustgate_headers, existing)
        # Intercept 403 so we can raise TrustGatePolicyViolation with error.message
        if kwargs.get("http_client") is None:
            kwargs["http_client"] = httpx.Client(transport=_TrustGateTransport())
        _original_init(self, *args, **kwargs)

    openai.OpenAI.__init__ = _patched_init  # type: ignore[method-assign]


def patch_anthropic(
    base_url: str | None = None,
    workflow_step: str | None = None,
) -> None:
    """
    Monkey-patch anthropic.Anthropic (and AsyncAnthropic) and intercept
    Messages.create and Completions.create to inject lowercase x-trustgate-*
    headers. Auth is Bearer only; provider headers (e.g. x-api-key) are not
    injected—the gateway injects them server-side. Headers apply to
    both non-streaming and streaming requests.

    Args:
        base_url: TrustGate gateway base URL (e.g. https://gateway.trustgate.ai).
                  If None, uses TRUSTGATE_ANTHROPIC_BASE_URL or TRUSTGATE_BASE_URL.
        workflow_step: x-trustgate-workflow-step; drives Gantt chart bars in
                       the Agent Intelligence dashboard.
    """
    try:
        import anthropic
    except ImportError:
        return  # optional: anthropic not installed
    try:
        from anthropic.resources.messages import Messages, AsyncMessages
    except ImportError:
        Messages = AsyncMessages = None  # type: ignore[assignment,misc]
    try:
        from anthropic.resources.completions import Completions, AsyncCompletions
    except ImportError:
        Completions = AsyncCompletions = None  # type: ignore[assignment,misc]

    gateway_url = (
        base_url
        or os.environ.get("TRUSTGATE_ANTHROPIC_BASE_URL")
        or os.environ.get("TRUSTGATE_BASE_URL")
        or DEFAULT_TRUSTGATE_ANTHROPIC_BASE_URL
    )
    gateway_url = gateway_url.rstrip("/")

    _workflow_step = workflow_step
    trustgate_headers = build_trustgate_headers(workflow_step=_workflow_step)

    # Patch client __init__: set base_url and merge TrustGate headers only (no provider auth).
    _orig_sync = anthropic.Anthropic.__init__
    _orig_async = anthropic.AsyncAnthropic.__init__

    def _patched_sync_init(
        self: Any,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        kwargs["base_url"] = gateway_url
        existing = kwargs.get("default_headers") or {}
        kwargs["default_headers"] = _trustgate_headers_only(trustgate_headers, existing)
        if kwargs.get("http_client") is None:
            kwargs["http_client"] = httpx.Client(transport=_TrustGateTransport())
        _orig_sync(self, *args, **kwargs)

    def _patched_async_init(
        self: Any,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        kwargs["base_url"] = gateway_url
        existing = kwargs.get("default_headers") or {}
        kwargs["default_headers"] = _trustgate_headers_only(trustgate_headers, existing)
        if kwargs.get("http_client") is None:
            kwargs["http_client"] = httpx.AsyncClient(transport=_AsyncTrustGateTransport())
        _orig_async(self, *args, **kwargs)

    anthropic.Anthropic.__init__ = _patched_sync_init  # type: ignore[method-assign]
    anthropic.AsyncAnthropic.__init__ = _patched_async_init  # type: ignore[method-assign]

    def _inject_extra_headers(kwargs: dict, workflow_step: str | None) -> None:
        """Merge x-trustgate-* into extra_headers; strip provider auth (gateway injects server-side)."""
        headers = build_trustgate_headers(workflow_step=workflow_step)
        extra = kwargs.get("extra_headers") or {}
        kwargs["extra_headers"] = _trustgate_headers_only(headers, extra)

    # Intercept Messages.create (sync + async). extra_headers apply to the same request
    # used for both non-streaming and streaming, so headers are sent for streams too.
    if Messages is not None and AsyncMessages is not None:
        _orig_messages_create = Messages.create
        _orig_async_messages_create = AsyncMessages.create

        def _patched_messages_create(self: Any, *args: Any, **kwargs: Any) -> Any:
            _inject_extra_headers(kwargs, _workflow_step)
            return _orig_messages_create(self, *args, **kwargs)

        async def _patched_async_messages_create(self: Any, *args: Any, **kwargs: Any) -> Any:
            _inject_extra_headers(kwargs, _workflow_step)
            return await _orig_async_messages_create(self, *args, **kwargs)

        Messages.create = _patched_messages_create  # type: ignore[method-assign]
        AsyncMessages.create = _patched_async_messages_create  # type: ignore[method-assign]

    # Intercept Completions.create (sync + async) for legacy Text Completions API.
    if Completions is not None and AsyncCompletions is not None:
        _orig_completions_create = Completions.create
        _orig_async_completions_create = AsyncCompletions.create

        def _patched_completions_create(self: Any, *args: Any, **kwargs: Any) -> Any:
            _inject_extra_headers(kwargs, _workflow_step)
            return _orig_completions_create(self, *args, **kwargs)

        async def _patched_async_completions_create(self: Any, *args: Any, **kwargs: Any) -> Any:
            _inject_extra_headers(kwargs, _workflow_step)
            return await _orig_async_completions_create(self, *args, **kwargs)

        Completions.create = _patched_completions_create  # type: ignore[method-assign]
        AsyncCompletions.create = _patched_async_completions_create  # type: ignore[method-assign]


def patch_all(
    base_url: str | None = None,
    workflow_step: str | None = None,
) -> None:
    """
    Primary entry point: run OpenAI, Anthropic, and Google Gemini patches
    sequentially. Zero-config when base_url is unset (env vars used).
    All patches inject lowercase x-trustgate-* headers; workflow_step
    drives Gantt chart bars in the Agent Intelligence dashboard.
    """
    patch_openai(base_url=base_url, workflow_step=workflow_step)
    patch_anthropic(base_url=base_url, workflow_step=workflow_step)
    from trustgate.gemini import patch_google_generativeai
    patch_google_generativeai(base_url=base_url, workflow_step=workflow_step)
