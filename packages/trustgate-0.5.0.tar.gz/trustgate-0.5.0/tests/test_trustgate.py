"""Basic tests for TrustGate SDK."""

import json

import pytest

from trustgate import (
    TrustGate,
    TrustGateGeminiClient,
    patch_all,
    patch_anthropic,
    patch_google_generativeai,
    patch_openai,
    __version__,
)
from trustgate.context import build_trustgate_headers
from trustgate._metadata import get_source_tool_metadata


def test_version():
    assert __version__ and isinstance(__version__, str)


def test_source_tool_metadata():
    meta = get_source_tool_metadata()
    assert "sdk_version" in meta
    assert "python_version" in meta
    assert "os" in meta
    assert "arch" in meta
    assert meta["sdk_version"] == __version__
    assert meta["os"] == meta["os"].lower()
    assert meta["arch"] == meta["arch"].lower()


def test_build_trustgate_headers():
    headers = build_trustgate_headers()
    assert "x-trustgate-trace-id" in headers
    assert "x-trustgate-source" in headers
    assert "x-trustgate-source-tool" in headers
    for key in headers:
        assert key == key.lower(), "header keys must be lowercase for Node.js/gateway parity"
    meta = json.loads(headers["x-trustgate-source-tool"])
    assert meta["sdk_version"] == __version__
    assert "arch" in meta


def test_headers_detect_n8n(monkeypatch):
    monkeypatch.setenv("N8N_EXECUTION_ID", "exec-123")
    monkeypatch.setenv("N8N_WORKFLOW_NAME", "My Workflow")
    headers = build_trustgate_headers()
    assert headers["x-trustgate-source"] == "n8n"
    assert headers["x-trustgate-trace-id"] == "exec-123"
    assert headers["x-trustgate-workflow-name"] == "My Workflow"


def test_headers_detect_github_actions(monkeypatch):
    monkeypatch.setenv("GITHUB_ACTIONS", "true")
    monkeypatch.setenv("GITHUB_RUN_ID", "run-456")
    monkeypatch.setenv("GITHUB_WORKFLOW", "ci.yml")
    headers = build_trustgate_headers()
    assert headers["x-trustgate-source"] == "github_actions"
    assert headers["x-trustgate-trace-id"] == "run-456"
    assert headers["x-trustgate-workflow-name"] == "ci.yml"


def test_headers_detect_gitlab_ci(monkeypatch):
    monkeypatch.setenv("GITLAB_CI", "true")
    monkeypatch.setenv("CI_PIPELINE_ID", "pipe-789")
    monkeypatch.setenv("CI_JOB_NAME", "test")
    headers = build_trustgate_headers()
    assert headers["x-trustgate-source"] == "gitlab_ci"
    assert headers["x-trustgate-trace-id"] == "pipe-789"
    assert headers["x-trustgate-workflow-name"] == "test"


def test_headers_default_source_local_script(monkeypatch):
    """When no env (n8n/GitHub/GitLab) is set, source is local_script for Shadow AI."""
    monkeypatch.delenv("N8N_EXECUTION_ID", raising=False)
    monkeypatch.delenv("GITHUB_ACTIONS", raising=False)
    monkeypatch.delenv("GITLAB_CI", raising=False)
    headers = build_trustgate_headers()
    assert headers["x-trustgate-source"] == "local_script"


def test_trustgate_client_headers():
    tg = TrustGate(base_url="https://gateway.example")
    headers = tg._headers()
    assert "x-trustgate-trace-id" in headers
    assert "x-trustgate-source" in headers
    tg.close()


def test_chat_completions_create_signature():
    """chat.completions.create exists and accepts OpenAI-like kwargs."""
    tg = TrustGate(base_url="https://gateway.example")
    assert hasattr(tg.chat, "completions")
    assert hasattr(tg.chat.completions, "create")
    tg.close()


def test_patch_openai_callable():
    """patch_openai is callable."""
    assert callable(patch_openai)


def test_build_trustgate_headers_workflow_step():
    headers = build_trustgate_headers(workflow_step="Data_Extraction")
    assert headers["x-trustgate-workflow-step"] == "Data_Extraction"


def test_build_trustgate_headers_source_tool_override():
    headers = build_trustgate_headers(source_tool_override={"step_name": "extract"})
    meta = json.loads(headers["x-trustgate-source-tool"])
    assert meta["step_name"] == "extract"
    assert meta["sdk_version"] == __version__


def test_n8n_auto_workflow_step_from_node_name(monkeypatch):
    monkeypatch.setenv("N8N_EXECUTION_ID", "exec-1")
    monkeypatch.setenv("N8N_NODE_NAME", "Final_Summary")
    headers = build_trustgate_headers()
    assert headers["x-trustgate-workflow-step"] == "Final_Summary"


def test_n8n_auto_workflow_step_from_node_id(monkeypatch):
    monkeypatch.setenv("N8N_EXECUTION_ID", "exec-1")
    monkeypatch.setenv("N8N_NODE_ID", "node-abc-123")
    headers = build_trustgate_headers()
    assert headers["x-trustgate-workflow-step"] == "node-abc-123"


def test_explicit_workflow_step_overrides_n8n_auto(monkeypatch):
    monkeypatch.setenv("N8N_EXECUTION_ID", "exec-1")
    monkeypatch.setenv("N8N_NODE_NAME", "AutoNode")
    headers = build_trustgate_headers(workflow_step="Manual_Step")
    assert headers["x-trustgate-workflow-step"] == "Manual_Step"


def test_client_create_accepts_workflow_step_and_source_tool_override():
    """create() accepts workflow_step and source_tool_override."""
    import inspect

    tg = TrustGate(base_url="https://gateway.example")
    sig = inspect.signature(tg.chat.completions.create)
    assert "workflow_step" in sig.parameters
    assert "source_tool_override" in sig.parameters
    tg.close()


def test_patch_anthropic_callable():
    """patch_anthropic is callable and uses context headers."""
    assert callable(patch_anthropic)
    patch_anthropic(base_url="https://gateway.test", workflow_step="Test")
    # Restore to avoid affecting other tests: re-import and re-patch with no-op is complex;
    # in process we've patched. Just verify it was callable.
    assert True


def test_patch_google_generativeai_callable():
    """patch_google_generativeai is callable (no optional deps required)."""
    assert callable(patch_google_generativeai)
    patch_google_generativeai(workflow_step="Gemini_Step")


def test_trustgate_gemini_client_headers():
    """TrustGateGeminiClient uses build_trustgate_headers (Shadow AI detection)."""
    client = TrustGateGeminiClient(base_url="https://gateway.example")
    headers = client._headers()
    assert "x-trustgate-trace-id" in headers
    assert "x-trustgate-source" in headers
    assert "x-trustgate-source-tool" in headers


def test_patch_all_callable():
    """patch_all runs OpenAI + Anthropic + Gemini patches (zero-config)."""
    assert callable(patch_all)
    patch_all(base_url="https://gateway.test", workflow_step="Unified")
