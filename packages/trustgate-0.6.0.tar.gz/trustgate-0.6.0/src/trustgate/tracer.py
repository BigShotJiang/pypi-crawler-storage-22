"""
Distributed Tracing for TrustGate.

Manages hierarchical spans via contextvars and flushes span telemetry
to the gateway in the background. Use tracer.span() or @tracer.trace()
to create spans; x-trustgate-trace-id / span-id / parent-id are read from
here by context.build_trustgate_headers() for gateway requests.
"""

import atexit
import contextvars
import logging
import os
import threading
import time
import uuid
from contextlib import contextmanager
from typing import Any, Callable, Dict, List, Optional, Union

# Thread-safe context variables for the current trace/span
_trace_id_var: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "trustgate_trace_id", default=None
)
_span_id_var: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "trustgate_span_id", default=None
)
_parent_span_id_var: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "trustgate_parent_span_id", default=None
)

# Telemetry buffer and flush config (runtime; do not read env at import time)
_span_buffer: List[Dict[str, Any]] = []
_buffer_lock = threading.Lock()
_config: Dict[str, Optional[str]] = {
    "api_key": None,
    "gateway_url": None,
}

logger = logging.getLogger(__name__)


def _get_flush_config() -> tuple[Optional[str], str]:
    """Resolve api_key and gateway_url from _config with fallback to os.environ (at flush time)."""
    api_key = _config.get("api_key") or os.environ.get("TRUSTGATE_API_KEY")
    gateway_url = (
        _config.get("gateway_url")
        or os.environ.get("TRUSTGATE_BASE_URL", "https://gateway.trustgate.ai")
    ).rstrip("/")
    return api_key, gateway_url


def _flush_spans() -> None:
    """Background task to send spans to the Gateway. Reads config/env at run time."""
    global _span_buffer
    api_key, gateway_url = _get_flush_config()
    if not _span_buffer or not api_key:
        return

    with _buffer_lock:
        to_send = _span_buffer[:]
        _span_buffer.clear()

    if not to_send:
        return

    try:
        import httpx

        httpx.post(
            f"{gateway_url}/api/telemetry/spans",
            json=to_send,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=2.0,
        )
    except Exception as e:
        logger.debug("TrustGate telemetry flush failed: %s", e)


atexit.register(_flush_spans)


class Tracer:
    """
    Manages Distributed Tracing context via contextvars.

    Use span() as a context manager or trace() as a decorator to create
    hierarchical spans. The current trace_id, span_id, and parent_span_id
    are available for injection into gateway request headers.

    Call configure(base_url=..., api_key=...) after load_dotenv() (or once
    env is set) so telemetry flush uses the correct gateway and key instead
    of import-time env values.
    """

    def configure(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> None:
        """
        Set gateway URL and API key for telemetry flush at runtime.

        Use after load_dotenv() so values from .env are applied. Falls back
        to TRUSTGATE_BASE_URL and TRUSTGATE_API_KEY env when not set here.
        """
        if base_url is not None:
            _config["gateway_url"] = base_url.rstrip("/")
        if api_key is not None:
            _config["api_key"] = api_key

    @property
    def is_active(self) -> bool:
        """True if we are currently inside a span context."""
        return _span_id_var.get() is not None

    @property
    def trace_id(self) -> str:
        """Returns the current Trace ID. Generates one if missing."""
        tid = _trace_id_var.get()
        if not tid:
            tid = str(uuid.uuid4())
            _trace_id_var.set(tid)
        return tid

    @property
    def current_span_id(self) -> Optional[str]:
        """Current span ID, or None if not inside a span."""
        return _span_id_var.get()

    @property
    def parent_span_id(self) -> Optional[str]:
        """Parent of the current span (None when in the root span)."""
        return _parent_span_id_var.get()

    @contextmanager
    def span(self, name: str, metadata: Optional[Dict[str, Any]] = None):
        """
        Start a new span in the trace hierarchy.

        Usage::

            with tracer.span("tool:calculator"):
                do_work()
        """
        parent_id = self.current_span_id
        new_span_id = str(uuid.uuid4())
        trace_id = self.trace_id

        token = _span_id_var.set(new_span_id)
        token_parent = _parent_span_id_var.set(parent_id)
        start_time = time.time()

        try:
            yield new_span_id
        finally:
            duration = time.time() - start_time
            span_data: Dict[str, Any] = {
                "trace_id": trace_id,
                "span_id": new_span_id,
                "parent_span_id": parent_id,
                "name": name,
                "start_time": start_time,
                "end_time": time.time(),
                "duration": duration,
                "metadata": metadata or {},
            }

            with _buffer_lock:
                _span_buffer.append(span_data)
                should_flush = len(_span_buffer) >= 10

            if should_flush:
                threading.Thread(target=_flush_spans, daemon=True).start()

            _parent_span_id_var.reset(token_parent)
            _span_id_var.reset(token)

    def trace(
        self, name_or_func: Optional[Union[str, Callable[..., Any]]] = None
    ) -> Union[Callable[..., Any], Callable[[Callable[..., Any]], Callable[..., Any]]]:
        """
        Decorator to run a function inside a span.

        Usage::

            @tracer.trace
            def my_tool(): ...

            @tracer.trace("tool:calculator")
            def calc(): ...
        """
        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                span_name = (
                    name_or_func
                    if isinstance(name_or_func, str)
                    else getattr(func, "__name__", "unknown")
                )
                with self.span(span_name):
                    return func(*args, **kwargs)

            return wrapper

        # @tracer.trace (no parens): first arg is the function
        if name_or_func is not None and callable(name_or_func):
            return decorator(name_or_func)
        return decorator


# Global instance for drop-in use
tracer = Tracer()
