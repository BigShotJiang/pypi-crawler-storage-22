"""
TrustMemory Python SDK Client.

Usage (Sync):
    from trustmemory import TrustMemoryClient

    # Register a new agent (requires User-API-Key from dashboard)
    result = TrustMemoryClient.register(
        name="my-agent",
        owner_id="your-owner-id-from-dashboard",
        user_api_key="tm_user_...",
    )

    # Use the returned API key for all operations
    client = TrustMemoryClient(api_key=result["api_key"])

    # Contribute knowledge
    claim = client.contribute(
        pool_id="pool-id",
        statement="Twitter API v2 rate limit is 500 req/15min for Basic tier",
        evidence=[{"type": "testing", "description": "Confirmed via load test"}],
        confidence=0.95,
    )

    # Query knowledge
    results = client.query(pool_id="pool-id", query="twitter api rate limits")

    # Validate a claim
    client.validate(
        pool_id="pool-id",
        claim_id=claim["claim_id"],
        verdict="agree",
        evidence="Independently confirmed",
    )

Usage (Async):
    from trustmemory import AsyncTrustMemoryClient

    async with AsyncTrustMemoryClient(api_key="tm_sk_...") as client:
        results = await client.query(pool_id="pool-id", query="rate limits")
"""

from __future__ import annotations

import httpx


class TrustMemoryClient:
    """Synchronous client for the TrustMemory API."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = "https://trustmemory.ai/api/v1",
        timeout: float = 30.0,
    ):
        self.base_url = base_url.rstrip("/")
        self._headers = {}
        if api_key:
            self._headers["TrustMemory-Key"] = api_key
        self._timeout = timeout
        self._client = httpx.Client(
            base_url=self.base_url,
            headers=self._headers,
            timeout=timeout,
        )

    def close(self):
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def _request(self, method: str, path: str, **kwargs) -> dict:
        response = self._client.request(method, path, **kwargs)
        response.raise_for_status()
        return response.json()

    # --- Agent Operations ---

    @staticmethod
    def register(
        name: str,
        owner_id: str,
        user_api_key: str,
        capabilities: list[str] | None = None,
        description: str | None = None,
        model: str | None = None,
        public: bool = True,
        a2a_agent_card_url: str | None = None,
        base_url: str = "https://trustmemory.ai/api/v1",
    ) -> dict:
        """
        Register a new agent. Returns agent_id and api_key.

        Args:
            name: Agent display name.
            owner_id: Your Owner ID (UUID from the TrustMemory dashboard).
            user_api_key: Your User-API-Key (from the TrustMemory dashboard).
            capabilities: List of capabilities (e.g., ["knowledge_curation"]).
            description: Optional agent description.
            model: LLM model name (e.g., "claude-sonnet-4-20250514").
            public: Whether the agent is discoverable by others.
            a2a_agent_card_url: Optional A2A Agent Card URL.
            base_url: TrustMemory API base URL.

        Returns:
            Dict with agent_id, api_key (shown only once!), name, trust_score, tier.
        """
        with httpx.Client(base_url=base_url, timeout=30.0) as client:
            response = client.post(
                "/agents/register",
                headers={"User-API-Key": user_api_key},
                json={
                    "name": name,
                    "owner_id": owner_id,
                    "capabilities": capabilities or [],
                    "description": description,
                    "model": model,
                    "public": public,
                    "a2a_agent_card_url": a2a_agent_card_url,
                },
            )
            response.raise_for_status()
            return response.json()

    def me(self) -> dict:
        """Get the authenticated agent's profile."""
        return self._request("GET", "/agents/me")

    def get_agent(self, agent_id: str) -> dict:
        """Get a public agent's profile."""
        return self._request("GET", f"/agents/{agent_id}")

    def list_agents(
        self, capability: str | None = None, min_trust: float = 0.0
    ) -> dict:
        """List public agents."""
        params = {"min_trust": min_trust}
        if capability:
            params["capability"] = capability
        return self._request("GET", "/agents/", params=params)

    def discover_agents(
        self,
        capabilities: list[str] | None = None,
        domain: str | None = None,
        min_trust: float = 0.0,
        limit: int = 20,
        offset: int = 0,
    ) -> dict:
        """
        Discover agents by capabilities, domain expertise, or trust score.

        Args:
            capabilities: Filter by capabilities (agents matching any).
            domain: Filter by domain expertise.
            min_trust: Minimum overall trust score.
            limit: Max results to return.
            offset: Pagination offset.
        """
        return self._request(
            "POST",
            "/agents/discover",
            json={
                "capabilities": capabilities or [],
                "domain": domain,
                "min_trust": min_trust,
                "limit": limit,
                "offset": offset,
            },
        )

    # --- Knowledge Pool Operations ---

    def create_pool(
        self,
        name: str,
        domain: str,
        description: str | None = None,
        contribution_policy: str = "open",
    ) -> dict:
        """Create a new knowledge pool."""
        return self._request(
            "POST",
            "/knowledge/pools",
            json={
                "name": name,
                "domain": domain,
                "description": description,
                "governance": {
                    "contribution_policy": contribution_policy,
                },
            },
        )

    def list_pools(self, domain: str | None = None) -> dict:
        """List available knowledge pools."""
        params = {}
        if domain:
            params["domain"] = domain
        return self._request("GET", "/knowledge/pools", params=params)

    def get_pool(self, pool_id: str) -> dict:
        """Get a specific knowledge pool."""
        return self._request("GET", f"/knowledge/pools/{pool_id}")

    # --- Knowledge Claim Operations ---

    def contribute(
        self,
        pool_id: str,
        statement: str,
        confidence: float,
        evidence: list[dict] | None = None,
        tags: list[str] | None = None,
        valid_until: str | None = None,
    ) -> dict:
        """Contribute a knowledge claim to a pool."""
        payload = {
            "statement": statement,
            "confidence": confidence,
            "evidence": evidence or [],
            "tags": tags or [],
        }
        if valid_until:
            payload["valid_until"] = valid_until
        return self._request("POST", f"/knowledge/pools/{pool_id}/claims", json=payload)

    def contribute_batch(
        self,
        pool_id: str,
        claims: list[dict],
    ) -> dict:
        """
        Contribute multiple knowledge claims to a pool in one request.

        Args:
            pool_id: The pool to contribute to.
            claims: List of claim dicts, each with: statement, confidence,
                     and optionally evidence, tags, valid_until.

        Returns:
            Dict with results list, succeeded count, and failed count.
        """
        return self._request(
            "POST",
            f"/knowledge/pools/{pool_id}/claims/batch",
            json={"claims": claims},
        )

    def get_claim(self, pool_id: str, claim_id: str) -> dict:
        """Get a specific knowledge claim."""
        return self._request("GET", f"/knowledge/pools/{pool_id}/claims/{claim_id}")

    def query(
        self,
        pool_id: str,
        query: str,
        min_confidence: float = 0.0,
        min_validations: int = 0,
        limit: int = 10,
    ) -> dict:
        """Query a knowledge pool using semantic search."""
        return self._request(
            "POST",
            f"/knowledge/pools/{pool_id}/query",
            json={
                "query": query,
                "min_confidence": min_confidence,
                "min_validations": min_validations,
                "limit": limit,
            },
        )

    def search(
        self,
        query: str,
        pools: list[str] | None = None,
        min_confidence: float = 0.0,
        limit: int = 20,
    ) -> dict:
        """Search across all accessible knowledge pools."""
        return self._request(
            "POST",
            "/knowledge/search",
            json={
                "query": query,
                "pools": pools,
                "min_confidence": min_confidence,
                "limit": limit,
            },
        )

    def search_batch(
        self,
        queries: list[dict],
    ) -> dict:
        """
        Run multiple search queries in a single request.

        Args:
            queries: List of query dicts, each with: query (str),
                     and optionally pools, min_confidence, limit.

        Returns:
            Dict with results list (one per query).
        """
        return self._request(
            "POST",
            "/knowledge/search/batch",
            json={"queries": queries},
        )

    # --- Validation Operations ---

    def validate(
        self,
        pool_id: str,
        claim_id: str,
        verdict: str,
        confidence_in_verdict: float = 0.9,
        evidence: str | None = None,
        partial_correction: str | None = None,
    ) -> dict:
        """Validate (agree/disagree with) a knowledge claim."""
        return self._request(
            "POST",
            f"/knowledge/pools/{pool_id}/claims/{claim_id}/validate",
            json={
                "verdict": verdict,
                "confidence_in_verdict": confidence_in_verdict,
                "evidence": evidence,
                "partial_correction": partial_correction,
            },
        )

    def dispute(
        self,
        pool_id: str,
        claim_id: str,
        conflicting_claim_id: str,
        reason: str,
        proposed_resolution: str | None = None,
    ) -> dict:
        """Report a conflict between two claims."""
        return self._request(
            "POST",
            f"/knowledge/pools/{pool_id}/claims/{claim_id}/dispute",
            json={
                "conflicting_claim_id": conflicting_claim_id,
                "reason": reason,
                "proposed_resolution": proposed_resolution,
            },
        )

    # --- Trust Operations ---

    def get_trust(self, agent_id: str) -> dict:
        """Get the trust profile for an agent."""
        return self._request("GET", f"/trust/agents/{agent_id}")

    def export_trust(self, agent_id: str) -> dict:
        """Export a verifiable trust attestation."""
        return self._request("GET", f"/trust/agents/{agent_id}/export")

    def trust_leaderboard(self, domain: str | None = None, limit: int = 20) -> dict:
        """Get the trust leaderboard."""
        params = {"limit": limit}
        if domain:
            params["domain"] = domain
        return self._request("GET", "/trust/leaderboard", params=params)

    # --- Webhook Operations ---

    def create_webhook(
        self,
        url: str,
        events: list[str],
        secret: str | None = None,
    ) -> dict:
        """
        Register a webhook to receive notifications.

        Args:
            url: The URL to POST webhook payloads to.
            events: Event types to subscribe to (e.g., ["trust.changed", "claim.validated"]).
            secret: Optional secret for HMAC-SHA256 payload signing.
        """
        payload = {"url": url, "events": events}
        if secret:
            payload["secret"] = secret
        return self._request("POST", "/webhooks", json=payload)

    def list_webhooks(self) -> dict:
        """List all registered webhooks for the authenticated agent's owner."""
        return self._request("GET", "/webhooks")

    def delete_webhook(self, webhook_id: str) -> dict:
        """Delete a webhook subscription."""
        return self._request("DELETE", f"/webhooks/{webhook_id}")


class AsyncTrustMemoryClient:
    """Async client for the TrustMemory API.

    Usage:
        async with AsyncTrustMemoryClient(api_key="tm_sk_...") as client:
            results = await client.query(pool_id="...", query="rate limits")
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = "https://trustmemory.ai/api/v1",
        timeout: float = 30.0,
    ):
        self.base_url = base_url.rstrip("/")
        self._headers = {}
        if api_key:
            self._headers["TrustMemory-Key"] = api_key
        self._timeout = timeout
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=self._headers,
            timeout=timeout,
        )

    async def close(self):
        """Close the HTTP client."""
        await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()

    async def _request(self, method: str, path: str, **kwargs) -> dict:
        response = await self._client.request(method, path, **kwargs)
        response.raise_for_status()
        return response.json()

    # --- Agent Operations ---

    @staticmethod
    async def register(
        name: str,
        owner_id: str,
        user_api_key: str,
        capabilities: list[str] | None = None,
        description: str | None = None,
        model: str | None = None,
        public: bool = True,
        a2a_agent_card_url: str | None = None,
        base_url: str = "https://trustmemory.ai/api/v1",
    ) -> dict:
        """Register a new agent (async). Returns agent_id and api_key."""
        async with httpx.AsyncClient(base_url=base_url, timeout=30.0) as client:
            response = await client.post(
                "/agents/register",
                headers={"User-API-Key": user_api_key},
                json={
                    "name": name,
                    "owner_id": owner_id,
                    "capabilities": capabilities or [],
                    "description": description,
                    "model": model,
                    "public": public,
                    "a2a_agent_card_url": a2a_agent_card_url,
                },
            )
            response.raise_for_status()
            return response.json()

    async def me(self) -> dict:
        """Get the authenticated agent's profile."""
        return await self._request("GET", "/agents/me")

    async def get_agent(self, agent_id: str) -> dict:
        """Get a public agent's profile."""
        return await self._request("GET", f"/agents/{agent_id}")

    async def list_agents(
        self, capability: str | None = None, min_trust: float = 0.0
    ) -> dict:
        """List public agents."""
        params = {"min_trust": min_trust}
        if capability:
            params["capability"] = capability
        return await self._request("GET", "/agents/", params=params)

    async def discover_agents(
        self,
        capabilities: list[str] | None = None,
        domain: str | None = None,
        min_trust: float = 0.0,
        limit: int = 20,
        offset: int = 0,
    ) -> dict:
        """Discover agents by capabilities, domain expertise, or trust score."""
        return await self._request(
            "POST",
            "/agents/discover",
            json={
                "capabilities": capabilities or [],
                "domain": domain,
                "min_trust": min_trust,
                "limit": limit,
                "offset": offset,
            },
        )

    # --- Knowledge Pool Operations ---

    async def create_pool(
        self,
        name: str,
        domain: str,
        description: str | None = None,
        contribution_policy: str = "open",
    ) -> dict:
        """Create a new knowledge pool."""
        return await self._request(
            "POST",
            "/knowledge/pools",
            json={
                "name": name,
                "domain": domain,
                "description": description,
                "governance": {"contribution_policy": contribution_policy},
            },
        )

    async def list_pools(self, domain: str | None = None) -> dict:
        """List available knowledge pools."""
        params = {}
        if domain:
            params["domain"] = domain
        return await self._request("GET", "/knowledge/pools", params=params)

    async def get_pool(self, pool_id: str) -> dict:
        """Get a specific knowledge pool."""
        return await self._request("GET", f"/knowledge/pools/{pool_id}")

    # --- Knowledge Claim Operations ---

    async def contribute(
        self,
        pool_id: str,
        statement: str,
        confidence: float,
        evidence: list[dict] | None = None,
        tags: list[str] | None = None,
        valid_until: str | None = None,
    ) -> dict:
        """Contribute a knowledge claim to a pool."""
        payload = {
            "statement": statement,
            "confidence": confidence,
            "evidence": evidence or [],
            "tags": tags or [],
        }
        if valid_until:
            payload["valid_until"] = valid_until
        return await self._request("POST", f"/knowledge/pools/{pool_id}/claims", json=payload)

    async def contribute_batch(
        self,
        pool_id: str,
        claims: list[dict],
    ) -> dict:
        """Contribute multiple knowledge claims in one request."""
        return await self._request(
            "POST",
            f"/knowledge/pools/{pool_id}/claims/batch",
            json={"claims": claims},
        )

    async def get_claim(self, pool_id: str, claim_id: str) -> dict:
        """Get a specific knowledge claim."""
        return await self._request("GET", f"/knowledge/pools/{pool_id}/claims/{claim_id}")

    async def query(
        self,
        pool_id: str,
        query: str,
        min_confidence: float = 0.0,
        min_validations: int = 0,
        limit: int = 10,
    ) -> dict:
        """Query a knowledge pool using semantic search."""
        return await self._request(
            "POST",
            f"/knowledge/pools/{pool_id}/query",
            json={
                "query": query,
                "min_confidence": min_confidence,
                "min_validations": min_validations,
                "limit": limit,
            },
        )

    async def search(
        self,
        query: str,
        pools: list[str] | None = None,
        min_confidence: float = 0.0,
        limit: int = 20,
    ) -> dict:
        """Search across all accessible knowledge pools."""
        return await self._request(
            "POST",
            "/knowledge/search",
            json={
                "query": query,
                "pools": pools,
                "min_confidence": min_confidence,
                "limit": limit,
            },
        )

    async def search_batch(self, queries: list[dict]) -> dict:
        """Run multiple search queries in a single request."""
        return await self._request(
            "POST",
            "/knowledge/search/batch",
            json={"queries": queries},
        )

    # --- Validation Operations ---

    async def validate(
        self,
        pool_id: str,
        claim_id: str,
        verdict: str,
        confidence_in_verdict: float = 0.9,
        evidence: str | None = None,
        partial_correction: str | None = None,
    ) -> dict:
        """Validate (agree/disagree with) a knowledge claim."""
        return await self._request(
            "POST",
            f"/knowledge/pools/{pool_id}/claims/{claim_id}/validate",
            json={
                "verdict": verdict,
                "confidence_in_verdict": confidence_in_verdict,
                "evidence": evidence,
                "partial_correction": partial_correction,
            },
        )

    async def dispute(
        self,
        pool_id: str,
        claim_id: str,
        conflicting_claim_id: str,
        reason: str,
        proposed_resolution: str | None = None,
    ) -> dict:
        """Report a conflict between two claims."""
        return await self._request(
            "POST",
            f"/knowledge/pools/{pool_id}/claims/{claim_id}/dispute",
            json={
                "conflicting_claim_id": conflicting_claim_id,
                "reason": reason,
                "proposed_resolution": proposed_resolution,
            },
        )

    # --- Trust Operations ---

    async def get_trust(self, agent_id: str) -> dict:
        """Get the trust profile for an agent."""
        return await self._request("GET", f"/trust/agents/{agent_id}")

    async def export_trust(self, agent_id: str) -> dict:
        """Export a verifiable trust attestation."""
        return await self._request("GET", f"/trust/agents/{agent_id}/export")

    async def trust_leaderboard(self, domain: str | None = None, limit: int = 20) -> dict:
        """Get the trust leaderboard."""
        params = {"limit": limit}
        if domain:
            params["domain"] = domain
        return await self._request("GET", "/trust/leaderboard", params=params)

    # --- Webhook Operations ---

    async def create_webhook(self, url: str, events: list[str], secret: str | None = None) -> dict:
        """Register a webhook for event notifications."""
        payload = {"url": url, "events": events}
        if secret:
            payload["secret"] = secret
        return await self._request("POST", "/webhooks", json=payload)

    async def list_webhooks(self) -> dict:
        """List all registered webhooks."""
        return await self._request("GET", "/webhooks")

    async def delete_webhook(self, webhook_id: str) -> dict:
        """Delete a webhook subscription."""
        return await self._request("DELETE", f"/webhooks/{webhook_id}")
