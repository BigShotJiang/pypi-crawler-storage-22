# Trustplane Python SDK (v0.1)

Minimal SDK to generate Trustplane proof headers.

## Install

```bash
pip install trustplane-sdk
```

## Usage

```python
from trustplane_sdk import sign

out = sign(
    tenant_id="mergematter.io",
    api_id="api_demo",
    client_id="client_demo",
    private_key_b64url="<private_key_b64url>",
    method="GET",
    path="/orders",
    body=""
)

print(out["headers"])
```

## Config file

```python
from trustplane_sdk import from_file

client = from_file("./trustplane.json")
out = client.sign(method="GET", path="/orders", body="", private_key_b64url="<private_key_b64url>")
```

## Tests

```bash
python3 -m unittest sdk/python/tests/test_vector.py
```
