"""Tru-Guard: A modular Python library for AI guardrails.

Tru-Guard provides input/output scanning capabilities for AI applications,
with parallel execution of multiple scanners and extensible failure action handling.

Example:
    ```python
    from trusys import TruGuard
    from trusys.scanners import BaseScanner, register_scanner
    from trusys.types import ScanResult, ScanContext

    # Create a custom scanner
    @register_scanner(name="my_scanner", scan_types=["input", "output"])
    class MyScanner(BaseScanner):
        def scan(self, content: dict[str, Any], context: ScanContext) -> ScanResult:
            # Your scanning logic here
            return ScanResult(
                passed=True,
                scanner_name=self.name,
                scan_type=context.scan_type,
            )

    # Use the guard
    guard = TruGuard(type="input")
    guard.add_scanners([MyScanner(config={}, on_fail="fix")])

    result = guard.scan(content={"prompt": "Hello, world!"})
    print(result.passed)
    ```
"""

from typing import Any

from trusys.core.config import GuardConfig
from trusys.core.guard import TruGuard
from trusys.scanners.builtin import (
    BlockListScanner,
    ContentSafetyScanner,
    PIIScanner,
    PromptInjectionScanner,
    RegexScanner,
)
from trusys.types import (
    ActionType,
    AggregatedResult,
    ConflictStrategy,
    ExecutionMode,
    MatchType,
    ScanContext,
    ScanResult,
    ScanType,
    Severity,
    Violation,
)

__version__ = "0.1.1"

__all__ = [
    # Main class
    "TruGuard",
    # Configuration
    "GuardConfig",
    # Built-in scanners
    "BlockListScanner",
    "ContentSafetyScanner",
    "PIIScanner",
    "PromptInjectionScanner",
    "RegexScanner",
    # Types
    "ScanType",
    "ActionType",
    "ExecutionMode",
    "ConflictStrategy",
    "MatchType",
    "Severity",
    "Violation",
    "ScanResult",
    "AggregatedResult",
    "ScanContext",
    # Version
    "__version__",
]
