"""Base action class for Tru-Guard."""

from abc import ABC, abstractmethod
from typing import Any

from trusys.types import ActionType, ScanResult


class BaseAction(ABC):
    """Abstract base class for all actions.

    Actions define what happens when a scanner detects a violation.
    """

    action_type: ActionType

    @abstractmethod
    def execute(
        self,
        result: ScanResult,
        content: str,
        **kwargs: Any,
    ) -> tuple[str | None, bool]:
        """Execute the action.

        Args:
            result: The scan result that triggered this action
            content: The original content that was scanned
            **kwargs: Additional action-specific arguments

        Returns:
            Tuple of (modified_content, should_continue)
            - modified_content: The modified content, or None if unchanged
            - should_continue: Whether to continue processing or stop
        """
        pass

    def __repr__(self) -> str:
        """String representation of the action."""
        return f"{self.__class__.__name__}(type={self.action_type.value})"
