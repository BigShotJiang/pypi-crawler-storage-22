"""Core module for Tru-Guard."""

from trusys.core.config import GuardConfig
from trusys.core.guard import TruGuard

__all__ = ["TruGuard", "GuardConfig"]
