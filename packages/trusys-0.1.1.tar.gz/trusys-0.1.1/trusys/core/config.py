"""Configuration for TruGuard."""

from dataclasses import dataclass, field
from typing import Any

from trusys.types import ConflictStrategy, ExecutionMode


@dataclass
class GuardConfig:
    """Configuration for TruGuard instance."""

    # Execution settings
    execution_mode: ExecutionMode = ExecutionMode.PARALLEL
    timeout: float = 30.0  # Per-scanner timeout in seconds
    early_exit: bool = False  # Stop on first failure (for PIPELINE mode)

    # Action settings
    conflict_strategy: ConflictStrategy = ConflictStrategy.PRIORITY

    # Logging settings
    enable_logging: bool = True

    # Advanced settings
    max_parallel_scanners: int | None = None  # None = unlimited
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Convert string values to enums if needed."""
        if isinstance(self.execution_mode, str):
            self.execution_mode = ExecutionMode(self.execution_mode)
        if isinstance(self.conflict_strategy, str):
            self.conflict_strategy = ConflictStrategy(self.conflict_strategy)

    def merge(self, **kwargs: Any) -> "GuardConfig":
        """Create a new config with updated values.

        Args:
            **kwargs: Configuration values to update

        Returns:
            New GuardConfig with updated values
        """
        current = {
            "execution_mode": self.execution_mode,
            "timeout": self.timeout,
            "early_exit": self.early_exit,
            "conflict_strategy": self.conflict_strategy,
            "enable_logging": self.enable_logging,
            "max_parallel_scanners": self.max_parallel_scanners,
            "metadata": self.metadata.copy(),
        }
        current.update(kwargs)
        return GuardConfig(**current)
