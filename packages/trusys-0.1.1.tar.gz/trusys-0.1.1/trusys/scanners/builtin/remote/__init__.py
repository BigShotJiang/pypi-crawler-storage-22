"""Remote scanners for Tru-Guard (content-safety, prompt-injection)."""

from trusys.scanners.builtin.remote.content_safety import ContentSafetyScanner
from trusys.scanners.builtin.remote.prompt_injection import PromptInjectionScanner

__all__ = ["ContentSafetyScanner", "PromptInjectionScanner"]
