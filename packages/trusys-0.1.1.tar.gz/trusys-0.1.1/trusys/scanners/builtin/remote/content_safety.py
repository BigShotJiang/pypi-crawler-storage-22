"""ContentSafety remote scanner for Tru-Guard."""

from typing import Any

from trusys.scanners import register_scanner
from trusys.scanners.remote import BaseRemoteScanner


@register_scanner(
    name="content-safety",
    scan_types=["input", "output"],
    description="Scanner for content safety checks",
    validator_type="content-safety",
)
class ContentSafetyScanner(BaseRemoteScanner):
    """Scanner for content safety validation.

    This scanner checks content for
    safety violations such as toxicity, hate speech, etc.

    Args:
        config: JSON configuration dictionary with scanner-specific parameters:
               - threshold (float, optional): Safety threshold (0.0 to 1.0)
               - categories (list[str], optional): Specific safety categories to check
               - on_fail (str, optional): Action to take when scan fails
               - enabled (bool, optional): Whether this scanner is enabled
        on_fail: Action to take when scan fails (can be in config or as parameter)
        enabled: Whether this scanner is enabled (can be in config or as parameter)
    """

    scanner_type: str = "content-safety"

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        on_fail: str | None = None,
        enabled: bool | None = None,
    ) -> None:
        """Initialize the ContentSafety scanner.

        Args:
            config: JSON configuration dictionary with scanner-specific parameters
            on_fail: Action to take when scan fails (can be in config or as parameter)
            enabled: Whether this scanner is enabled (can be in config or as parameter)
        """
        super().__init__(config=config, on_fail=on_fail, enabled=enabled)

        # Extract and validate config parameters
        threshold = config.get("threshold") if config else None
        if threshold is not None:
            if not isinstance(threshold, (int, float)) or not (0.0 <= threshold <= 1.0):
                raise ValueError(
                    "threshold must be a float between 0.0 and 1.0"
                )

        categories = config.get("categories") if config else None
        if categories is not None and not isinstance(categories, list):
            raise ValueError("categories must be a list of strings")
