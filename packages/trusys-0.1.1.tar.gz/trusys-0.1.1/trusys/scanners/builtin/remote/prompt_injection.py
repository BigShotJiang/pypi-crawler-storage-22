"""Prompt-injection remote scanner for Tru-Guard."""

from typing import Any

from trusys.scanners import register_scanner
from trusys.scanners.remote import BaseRemoteScanner


@register_scanner(
    name="prompt-injection",
    scan_types=["input"],
    description="Scanner for prompt injection detection (input only)",
    validator_type="prompt-injection",
)
class PromptInjectionScanner(BaseRemoteScanner):
    """Scanner for prompt injection detection.

    This scanner checks content for prompt injection attempts.
    Executes remotely via the same batch API as content-safety.

    Args:
        config: JSON configuration dictionary with scanner-specific parameters:
               - threshold (float, optional): Detection threshold (0.0 to 1.0)
               - on_fail (str, optional): Action to take when scan fails
               - enabled (bool, optional): Whether this scanner is enabled
        on_fail: Action to take when scan fails (can be in config or as parameter)
        enabled: Whether this scanner is enabled (can be in config or as parameter)
    """

    scanner_type: str = "prompt-injection"

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        on_fail: str | None = None,
        enabled: bool | None = None,
    ) -> None:
        """Initialize the PromptInjection scanner.

        Args:
            config: JSON configuration dictionary with scanner-specific parameters
            on_fail: Action to take when scan fails (can be in config or as parameter)
            enabled: Whether this scanner is enabled (can be in config or as parameter)
        """
        super().__init__(config=config, on_fail=on_fail, enabled=enabled)

        # Extract and validate config parameters
        cfg = config or {}
        threshold = cfg.get("threshold")
        if threshold is not None:
            if not isinstance(threshold, (int, float)) or not (0.0 <= threshold <= 1.0):
                raise ValueError(
                    "threshold must be a float between 0.0 and 1.0"
                )
