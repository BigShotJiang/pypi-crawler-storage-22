"""Allow running as python -m truthound_dashboard."""

from truthound_dashboard.cli import app

if __name__ == "__main__":
    app()
