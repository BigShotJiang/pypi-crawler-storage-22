# truthstack

Python SDK for [TruthStack](https://truthstack.co) supplement safety API. Works with LangChain, LlamaIndex, CrewAI, OpenAI function calling, and standalone.

## Install

```bash
pip install truthstack                    # Core client (zero deps)
pip install truthstack[langchain]         # + LangChain tools
pip install truthstack[llamaindex]        # + LlamaIndex tools
pip install truthstack[crewai]            # + CrewAI tools
pip install truthstack[all]              # Everything
```

## Quick Start

### Standalone

```python
from truthstack import TruthStackClient

client = TruthStackClient(api_key="your-key")

# Check interactions (the money endpoint)
result = client.check_interactions(
    supplements=["berberine", "magnesium", "vitamin_d"],
    medications=["semaglutide"]
)
print(result["risk_level"])  # "HIGH"
print(result["cyp_pathway_conflicts"])
print(result["evidence_by_compound"])

# Get evidence balance
evidence = client.get_evidence("berberine")
print(evidence["evidence_balance"])  # {"positive": 8, "null": 2, ...}
print(evidence["citations"])  # [{"pmid": "12345", ...}]
```

### LangChain

```python
from truthstack import get_langchain_tools
from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_openai_tools_agent

tools = get_langchain_tools(api_key="your-key")
llm = ChatOpenAI(model="gpt-4")
agent = create_openai_tools_agent(llm, tools, prompt)
executor = AgentExecutor(agent=agent, tools=tools)

result = executor.invoke({"input": "Can I take berberine while on Ozempic?"})
```

### LlamaIndex

```python
from truthstack import get_llamaindex_tools
from llama_index.core.agent import ReActAgent
from llama_index.llms.openai import OpenAI

tools = get_llamaindex_tools(api_key="your-key")
agent = ReActAgent.from_tools(tools, llm=OpenAI(model="gpt-4"))

response = agent.chat("What's the evidence for CoQ10?")
```

### CrewAI

```python
from truthstack import get_crewai_tools
from crewai import Agent, Task, Crew

tools = get_crewai_tools(api_key="your-key")

analyst = Agent(
    role="Supplement Safety Analyst",
    goal="Check supplement interactions and evidence",
    tools=tools,
)
```

### OpenAI Function Calling

```python
from truthstack import get_openai_functions, handle_openai_function_call
from openai import OpenAI

client = OpenAI()
functions = get_openai_functions()

response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Is magnesium safe with sertraline?"}],
    functions=functions,
    function_call="auto",
)

call = response.choices[0].message.function_call
result = handle_openai_function_call(
    call.name, json.loads(call.arguments), api_key="your-key"
)
```

## System Prompts

```python
from truthstack import SYSTEM_PROMPTS

SYSTEM_PROMPTS["supplement_safety_advisor"]   # General safety
SYSTEM_PROMPTS["glp1_supplement_checker"]     # GLP-1/Ozempic focus
SYSTEM_PROMPTS["evidence_researcher"]         # Research analysis
SYSTEM_PROMPTS["stack_optimizer"]             # Stack optimization
SYSTEM_PROMPTS["clinician_assistant"]         # Clinician-facing
```

## Tools

| Tool | Description |
|------|-------------|
| `truthstack_check_interactions` | Check supplement + drug interactions |
| `truthstack_get_evidence` | Evidence balance + citations |
| `truthstack_search_supplements` | Fuzzy compound search |
| `truthstack_safety_signals` | FDA CAERS/FAERS signals |
| `truthstack_drug_profile` | Drug CYP450 + botanical interactions |

## Environment Variables

```bash
TRUTHSTACK_API_KEY=your-key
TRUTHSTACK_BASE_URL=https://api.truthstack.co  # optional
```

## API Key

Get a free key (2,000 calls/month) at [truthstack.co/developers](https://truthstack.co/developers).

## License

MIT
