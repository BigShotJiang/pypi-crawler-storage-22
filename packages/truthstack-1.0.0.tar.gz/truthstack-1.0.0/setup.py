from setuptools import setup, find_packages

setup(
    name="truthstack",
    version="1.0.0",
    description="TruthStack supplement safety API SDK. LangChain, LlamaIndex, CrewAI, and OpenAI integrations.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="TruthStack",
    author_email="chris@truthstack.co",
    url="https://github.com/TruthStack1/truthstack-python",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[],  # Zero deps for core client
    extras_require={
        "langchain": ["langchain-core>=0.1.0", "pydantic>=2.0"],
        "llamaindex": ["llama-index-core>=0.10.0"],
        "crewai": ["crewai>=0.1.0"],
        "all": ["langchain-core>=0.1.0", "pydantic>=2.0", "llama-index-core>=0.10.0", "crewai>=0.1.0"],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Medical Science Apps.",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords="supplements drug-interactions langchain llamaindex crewai openai health safety pharmacovigilance glp-1 ozempic",
    license="MIT",
    project_urls={
        "Documentation": "https://api.truthstack.co/docs",
        "MCP Server": "https://github.com/TruthStack1/truthstack-mcp",
        "Bug Tracker": "https://github.com/TruthStack1/truthstack-python/issues",
    },
)
