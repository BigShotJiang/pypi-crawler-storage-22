"""
truthstack - Python SDK for TruthStack supplement safety API.
Works with LangChain, LlamaIndex, CrewAI, and standalone.

pip install truthstack

Usage:
    from truthstack import TruthStackClient
    client = TruthStackClient(api_key="your-key")
    result = client.check_interactions(["berberine", "magnesium"], ["semaglutide"])
"""

import os
import json
import urllib.request
import urllib.error
import urllib.parse
from typing import List, Optional, Dict, Any

__version__ = "1.0.0"
__all__ = [
    "TruthStackClient",
    "get_langchain_tools",
    "get_llamaindex_tools",
    "get_crewai_tools",
    "get_openai_functions",
    "handle_openai_function_call",
    "SYSTEM_PROMPTS",
]

DEFAULT_BASE_URL = "https://api.truthstack.co"
CLIENT_ID_BASE = "truthstack-python"


class TruthStackError(Exception):
    """Error from the TruthStack API."""
    def __init__(self, message: str, code: str = "UNKNOWN", status: int = 0,
                 suggestions: list = None, hint: str = None):
        super().__init__(message)
        self.code = code
        self.status = status
        self.suggestions = suggestions or []
        self.hint = hint


class TruthStackClient:
    """Client for the TruthStack Vault API."""

    def __init__(self, api_key: str = None, base_url: str = None, framework: str = None):
        self.api_key = api_key or os.environ.get("TRUTHSTACK_API_KEY", "")
        self.base_url = (base_url or os.environ.get("TRUTHSTACK_BASE_URL", DEFAULT_BASE_URL)).rstrip("/")
        self.framework = framework or "standalone"
        if not self.api_key:
            raise ValueError(
                "TruthStack API key required. Set TRUTHSTACK_API_KEY env var "
                "or pass api_key. Get a free key at truthstack.co/developers"
            )

    @property
    def _client_id(self) -> str:
        return f"{CLIENT_ID_BASE}-{self.framework}/{__version__}"

    def _request(self, method: str, path: str, body: dict = None) -> dict:
        url = f"{self.base_url}{path}"
        data = json.dumps(body).encode() if body else None
        headers = {
            "X-API-Key": self.api_key,
            "X-TruthStack-Client": self._client_id,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            body_str = e.read().decode()
            try:
                parsed = json.loads(body_str)
                raise TruthStackError(
                    message=parsed.get("message", str(e)),
                    code=parsed.get("error_code", "UNKNOWN"),
                    status=e.code,
                    suggestions=parsed.get("suggestions", []),
                    hint=parsed.get("hint"),
                )
            except (json.JSONDecodeError, TruthStackError):
                if isinstance(e.__context__, TruthStackError):
                    raise e.__context__
                raise TruthStackError(str(e), status=e.code)

    def check_interactions(self, supplements: List[str], medications: List[str] = None) -> dict:
        """Check supplement-supplement and supplement-drug interactions."""
        return self._request("POST", "/api/interactions/check", {
            "supplements": supplements,
            "medications": medications or [],
        })

    def get_evidence(self, compound_id: str) -> dict:
        """Get evidence balance and citations for a compound."""
        return self._request("GET", f"/api/compounds/{urllib.parse.quote(compound_id)}/evidence")

    def search_compounds(self, query: str, limit: int = 10) -> dict:
        """Search for compounds by name."""
        return self._request("GET", f"/api/compounds/search?q={urllib.parse.quote(query)}&limit={limit}")

    def get_compound(self, compound_id: str) -> dict:
        """Get compound details."""
        return self._request("GET", f"/api/compounds/{urllib.parse.quote(compound_id)}")

    def get_safety_signals(self, compound_id: str) -> dict:
        """Get FDA adverse event safety signals."""
        return self._request("GET", f"/api/compounds/{urllib.parse.quote(compound_id)}/safety-signals")

    def get_drug(self, drug_id: str) -> dict:
        """Get drug profile with CYP pathways."""
        return self._request("GET", f"/api/drugs/{urllib.parse.quote(drug_id)}")

    def health(self) -> dict:
        """Check API health."""
        return self._request("GET", "/api/health")


# ============================================================
# LANGCHAIN INTEGRATION
# ============================================================

def get_langchain_tools(api_key: str = None, base_url: str = None):
    """
    Get TruthStack tools for LangChain.

    Usage:
        from truthstack import get_langchain_tools
        from langchain.agents import AgentExecutor

        tools = get_langchain_tools(api_key="your-key")
        agent = AgentExecutor(tools=tools, llm=llm, ...)
    """
    try:
        from langchain_core.tools import StructuredTool
        from pydantic import BaseModel, Field
    except ImportError:
        raise ImportError("Install langchain: pip install langchain-core pydantic")

    client = TruthStackClient(api_key=api_key, base_url=base_url, framework="langchain")

    class CheckInteractionsInput(BaseModel):
        supplements: List[str] = Field(description="List of supplement names")
        medications: List[str] = Field(default=[], description="Optional list of medication names")

    class CompoundInput(BaseModel):
        compound_id: str = Field(description='Supplement ID (lowercase, underscores). E.g. "vitamin_d"')

    class SearchInput(BaseModel):
        query: str = Field(description='Search query, e.g. "magnesium glycinate"')

    class DrugInput(BaseModel):
        drug_id: str = Field(description='Drug name, e.g. "sertraline"')

    def _check_interactions(supplements: List[str], medications: List[str] = []) -> str:
        return json.dumps(client.check_interactions(supplements, medications), indent=2)

    def _get_evidence(compound_id: str) -> str:
        return json.dumps(client.get_evidence(compound_id), indent=2)

    def _search(query: str) -> str:
        return json.dumps(client.search_compounds(query), indent=2)

    def _safety_signals(compound_id: str) -> str:
        return json.dumps(client.get_safety_signals(compound_id), indent=2)

    def _drug_profile(drug_id: str) -> str:
        return json.dumps(client.get_drug(drug_id), indent=2)

    return [
        StructuredTool.from_function(
            func=_check_interactions,
            name="truthstack_check_interactions",
            description="Check supplement-supplement and supplement-drug interactions. Returns risk level, CYP conflicts, FDA warnings, evidence balance, citations.",
            args_schema=CheckInteractionsInput,
        ),
        StructuredTool.from_function(
            func=_get_evidence,
            name="truthstack_get_evidence",
            description="Get evidence balance and research citations for a supplement. Returns positive/negative/null counts, evidence level, conditions studied, PMIDs.",
            args_schema=CompoundInput,
        ),
        StructuredTool.from_function(
            func=_search,
            name="truthstack_search_supplements",
            description="Search for supplements by name with fuzzy matching and alias resolution.",
            args_schema=SearchInput,
        ),
        StructuredTool.from_function(
            func=_safety_signals,
            name="truthstack_safety_signals",
            description="Get FDA adverse event (CAERS/FAERS) safety signals for a supplement.",
            args_schema=CompoundInput,
        ),
        StructuredTool.from_function(
            func=_drug_profile,
            name="truthstack_drug_profile",
            description="Get drug CYP450 pathways, transporters, and botanical interactions.",
            args_schema=DrugInput,
        ),
    ]


# ============================================================
# LLAMAINDEX INTEGRATION
# ============================================================

def get_llamaindex_tools(api_key: str = None, base_url: str = None):
    """
    Get TruthStack tools for LlamaIndex.

    Usage:
        from truthstack import get_llamaindex_tools
        from llama_index.core.agent import ReActAgent

        tools = get_llamaindex_tools(api_key="your-key")
        agent = ReActAgent.from_tools(tools, llm=llm, ...)
    """
    try:
        from llama_index.core.tools import FunctionTool
    except ImportError:
        raise ImportError("Install llama-index: pip install llama-index-core")

    client = TruthStackClient(api_key=api_key, base_url=base_url, framework="llamaindex")

    def check_interactions(supplements: List[str], medications: List[str] = []) -> str:
        """Check supplement-supplement and supplement-drug interactions for safety.
        Returns risk level, CYP pathway conflicts, FDA warnings, evidence balance, and citations.
        Args:
            supplements: List of supplement names (e.g. ["berberine", "magnesium"])
            medications: Optional list of medication names (e.g. ["semaglutide"])
        """
        return json.dumps(client.check_interactions(supplements, medications), indent=2)

    def get_evidence(compound_id: str) -> str:
        """Get evidence balance and research citations for a supplement compound.
        Returns positive/negative/null finding counts, evidence level, conditions studied, PMIDs.
        Args:
            compound_id: Supplement ID in lowercase with underscores (e.g. "vitamin_d")
        """
        return json.dumps(client.get_evidence(compound_id), indent=2)

    def search_supplements(query: str) -> str:
        """Search for supplements by name with fuzzy matching and alias resolution.
        Args:
            query: Search query (e.g. "mag glycinate", "fish oil")
        """
        return json.dumps(client.search_compounds(query), indent=2)

    def safety_signals(compound_id: str) -> str:
        """Get FDA adverse event (CAERS/FAERS) safety signals for a supplement.
        Args:
            compound_id: Supplement ID in lowercase with underscores
        """
        return json.dumps(client.get_safety_signals(compound_id), indent=2)

    def drug_profile(drug_id: str) -> str:
        """Get drug CYP450 metabolism pathways, transporters, and botanical interactions.
        Args:
            drug_id: Drug name (e.g. "sertraline", "metformin")
        """
        return json.dumps(client.get_drug(drug_id), indent=2)

    return [
        FunctionTool.from_defaults(fn=check_interactions, name="truthstack_check_interactions"),
        FunctionTool.from_defaults(fn=get_evidence, name="truthstack_get_evidence"),
        FunctionTool.from_defaults(fn=search_supplements, name="truthstack_search_supplements"),
        FunctionTool.from_defaults(fn=safety_signals, name="truthstack_safety_signals"),
        FunctionTool.from_defaults(fn=drug_profile, name="truthstack_drug_profile"),
    ]


# ============================================================
# CREWAI INTEGRATION
# ============================================================

def get_crewai_tools(api_key: str = None, base_url: str = None):
    """
    Get TruthStack tools for CrewAI.

    Usage:
        from truthstack import get_crewai_tools
        from crewai import Agent

        tools = get_crewai_tools(api_key="your-key")
        agent = Agent(role="Supplement Safety Analyst", tools=tools, ...)
    """
    try:
        from crewai.tools import tool as crewai_tool
    except ImportError:
        raise ImportError("Install crewai: pip install crewai")

    client = TruthStackClient(api_key=api_key, base_url=base_url, framework="crewai")

    @crewai_tool("TruthStack Interaction Checker")
    def check_interactions(supplements: str, medications: str = "") -> str:
        """Check supplement-supplement and supplement-drug interactions for safety.
        supplements: Comma-separated supplement names (e.g. "berberine, magnesium")
        medications: Optional comma-separated medication names (e.g. "semaglutide, metformin")
        """
        supps = [s.strip() for s in supplements.split(",") if s.strip()]
        meds = [m.strip() for m in medications.split(",") if m.strip()] if medications else []
        return json.dumps(client.check_interactions(supps, meds), indent=2)

    @crewai_tool("TruthStack Evidence Lookup")
    def get_evidence(compound_id: str) -> str:
        """Get evidence balance and research citations for a supplement.
        compound_id: Supplement ID in lowercase with underscores (e.g. "vitamin_d")
        """
        return json.dumps(client.get_evidence(compound_id), indent=2)

    @crewai_tool("TruthStack Supplement Search")
    def search_supplements(query: str) -> str:
        """Search for supplements by name with fuzzy matching.
        query: Search query (e.g. "magnesium glycinate")
        """
        return json.dumps(client.search_compounds(query), indent=2)

    @crewai_tool("TruthStack Safety Signals")
    def safety_signals(compound_id: str) -> str:
        """Get FDA adverse event safety signals for a supplement.
        compound_id: Supplement ID in lowercase with underscores
        """
        return json.dumps(client.get_safety_signals(compound_id), indent=2)

    @crewai_tool("TruthStack Drug Profile")
    def drug_profile(drug_id: str) -> str:
        """Get drug CYP450 pathways and botanical interactions.
        drug_id: Drug name (e.g. "sertraline")
        """
        return json.dumps(client.get_drug(drug_id), indent=2)

    return [check_interactions, get_evidence, search_supplements, safety_signals, drug_profile]


# ============================================================
# OPENAI FUNCTION CALLING
# ============================================================

def get_openai_functions() -> List[dict]:
    """Get OpenAI function calling definitions for TruthStack tools."""
    return [
        {
            "name": "truthstack_check_interactions",
            "description": "Check supplement-supplement and supplement-drug interactions. Returns risk level, CYP conflicts, FDA warnings, evidence balance, citations.",
            "parameters": {
                "type": "object",
                "properties": {
                    "supplements": {"type": "array", "items": {"type": "string"}, "description": "List of supplement names"},
                    "medications": {"type": "array", "items": {"type": "string"}, "description": "Optional medication names"},
                },
                "required": ["supplements"],
            },
        },
        {
            "name": "truthstack_get_evidence",
            "description": "Get evidence balance and research citations for a supplement compound.",
            "parameters": {
                "type": "object",
                "properties": {
                    "compound_id": {"type": "string", "description": "Supplement ID (lowercase, underscores)"},
                },
                "required": ["compound_id"],
            },
        },
        {
            "name": "truthstack_search_supplements",
            "description": "Search for supplements by name with fuzzy matching.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Search query"},
                },
                "required": ["query"],
            },
        },
        {
            "name": "truthstack_safety_signals",
            "description": "Get FDA adverse event safety signals for a supplement.",
            "parameters": {
                "type": "object",
                "properties": {
                    "compound_id": {"type": "string", "description": "Supplement ID"},
                },
                "required": ["compound_id"],
            },
        },
        {
            "name": "truthstack_drug_profile",
            "description": "Get drug CYP450 pathways, transporters, and botanical interactions.",
            "parameters": {
                "type": "object",
                "properties": {
                    "drug_id": {"type": "string", "description": "Drug name"},
                },
                "required": ["drug_id"],
            },
        },
    ]


def handle_openai_function_call(function_name: str, arguments: dict,
                                 api_key: str = None, base_url: str = None) -> dict:
    """Handle an OpenAI function call response."""
    client = TruthStackClient(api_key=api_key, base_url=base_url, framework="openai")
    handlers = {
        "truthstack_check_interactions": lambda a: client.check_interactions(a["supplements"], a.get("medications", [])),
        "truthstack_get_evidence": lambda a: client.get_evidence(a["compound_id"]),
        "truthstack_search_supplements": lambda a: client.search_compounds(a["query"]),
        "truthstack_safety_signals": lambda a: client.get_safety_signals(a["compound_id"]),
        "truthstack_drug_profile": lambda a: client.get_drug(a["drug_id"]),
    }
    handler = handlers.get(function_name)
    if not handler:
        raise ValueError(f"Unknown function: {function_name}")
    return handler(arguments)


# ============================================================
# SYSTEM PROMPTS
# ============================================================

SYSTEM_PROMPTS = {
    "supplement_safety_advisor": (
        "You are a supplement safety advisor powered by TruthStack's evidence database.\n\n"
        "When a user asks about supplements:\n"
        "1. ALWAYS check interactions first using truthstack_check_interactions\n"
        "2. Look up evidence using truthstack_get_evidence for each supplement\n"
        "3. Check safety signals using truthstack_safety_signals for concerning compounds\n"
        "4. Cite PMIDs when available\n\n"
        "Key safety rules:\n"
        "- Flag hypoglycemia stacking: berberine + chromium + ALA with GLP-1 drugs\n"
        "- Flag CYP3A4 interactions: St. John's Wort, grapefruit, turmeric\n"
        "- Always mention when evidence is insufficient (< 3 findings)\n"
        "- Never recommend stopping prescribed medications\n"
        "- Recommend consulting healthcare provider for medication interactions"
    ),
    "glp1_supplement_checker": (
        "You are a GLP-1 medication supplement safety checker powered by TruthStack.\n\n"
        "50M+ people take GLP-1 receptor agonists (Ozempic, Wegovy, Mounjaro) with supplements.\n\n"
        "Critical interactions:\n"
        "- HYPOGLYCEMIA STACKING: berberine, chromium, alpha-lipoic acid + GLP-1\n"
        "- ABSORPTION CHANGES: B12, iron, vitamin D (GLP-1s slow gastric emptying)\n"
        "- BENEFICIAL: magnesium (constipation), creatine (muscle preservation)\n\n"
        "Always check interactions with the GLP-1 medication included.\n"
        "Recommend CGM monitoring for glucose-active supplements."
    ),
    "evidence_researcher": (
        "You are a supplement evidence researcher powered by TruthStack.\n\n"
        "When asked about a supplement:\n"
        "1. Use truthstack_get_evidence for the evidence balance\n"
        "2. Report positive vs null vs negative ratio\n"
        "3. Cite specific PMIDs and study designs\n"
        "4. Note the evidence level (high/moderate/low/very_low/insufficient)\n"
        "5. Be honest about gaps\n\n"
        "Never overstate evidence. A few positive animal studies != proven effective."
    ),
    "stack_optimizer": (
        "You are a supplement stack optimizer powered by TruthStack.\n\n"
        "When a user shares their stack:\n"
        "1. Check ALL interactions with truthstack_check_interactions\n"
        "2. Get evidence for each compound\n"
        "3. Identify redundancies\n"
        "4. Flag supplements lacking evidence\n"
        "5. Suggest timing optimizations\n"
        "6. Estimate if they're wasting money on unsupported supplements\n\n"
        "Be direct about what lacks evidence."
    ),
    "clinician_assistant": (
        "You are a clinician-facing supplement interaction checker powered by TruthStack.\n\n"
        "When checking patient supplement-drug interactions:\n"
        "1. Run truthstack_check_interactions with full stack\n"
        "2. Check truthstack_drug_profile for CYP pathways\n"
        "3. Report by severity: CRITICAL > HIGH > MODERATE > LOW\n"
        "4. Include FAERS signal data\n"
        "5. Cite PMIDs for all claims\n\n"
        "Use clinical terminology. Flag pharmacokinetic interactions explicitly."
    ),
}
