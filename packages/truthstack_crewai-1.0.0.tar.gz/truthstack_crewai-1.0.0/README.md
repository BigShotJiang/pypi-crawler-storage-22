# truthstack-crewai

CrewAI adapter for [TruthStack](https://truthstack.co) supplement safety API.

## Install

```bash
pip install truthstack-crewai
```

## Quick Start

```python
from truthstack_crewai import get_tools
from crewai import Agent, Task, Crew

tools = get_tools(api_key="your-key")

analyst = Agent(
    role="Supplement Safety Analyst",
    goal="Check supplement interactions and evidence for safety",
    tools=tools,
)

task = Task(
    description="Check if berberine is safe with Ozempic",
    agent=analyst,
)

crew = Crew(agents=[analyst], tasks=[task])
result = crew.kickoff()
```

## Tools Included

| Tool | Description |
|------|-------------|
| `TruthStack Interaction Checker` | Check supplement + drug interactions |
| `TruthStack Evidence Lookup` | Evidence balance + citations |
| `TruthStack Supplement Search` | Fuzzy compound search |
| `TruthStack Safety Signals` | FDA CAERS/FAERS signals |
| `TruthStack Drug Profile` | Drug CYP450 + botanical interactions |

## Also available

```bash
pip install truthstack                    # Core client
pip install truthstack-langchain          # LangChain adapter
pip install truthstack-llamaindex         # LlamaIndex adapter
```

## API Key

Free key (2,000 calls/month): [truthstack.co/developers](https://truthstack.co/developers)

## License

MIT
