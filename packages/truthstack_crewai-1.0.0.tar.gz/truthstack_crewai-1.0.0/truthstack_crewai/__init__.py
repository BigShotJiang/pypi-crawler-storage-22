"""
truthstack-crewai — CrewAI adapter for TruthStack supplement safety API.

pip install truthstack-crewai

Usage:
    from truthstack_crewai import get_tools, TruthStackClient
    tools = get_tools(api_key="your-key")
"""
from truthstack import (
    TruthStackClient,
    get_crewai_tools as get_tools,
    SYSTEM_PROMPTS,
)

__all__ = [
    "TruthStackClient",
    "get_tools",
    "SYSTEM_PROMPTS",
]
