# truthstack-langchain

LangChain adapter for [TruthStack](https://truthstack.co) supplement safety API.

## Install

```bash
pip install truthstack-langchain
```

## Quick Start

```python
from truthstack_langchain import get_tools
from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_openai_tools_agent

tools = get_tools(api_key="your-key")
llm = ChatOpenAI(model="gpt-4")
agent = create_openai_tools_agent(llm, tools, prompt)
executor = AgentExecutor(agent=agent, tools=tools)

result = executor.invoke({"input": "Can I take berberine while on Ozempic?"})
```

## Tools Included

| Tool | Description |
|------|-------------|
| `truthstack_check_interactions` | Check supplement + drug interactions |
| `truthstack_get_evidence` | Evidence balance + citations |
| `truthstack_search_supplements` | Fuzzy compound search |
| `truthstack_safety_signals` | FDA CAERS/FAERS signals |
| `truthstack_drug_profile` | Drug CYP450 + botanical interactions |

## Also available

```bash
pip install truthstack                    # Core client
pip install truthstack-llamaindex         # LlamaIndex adapter
pip install truthstack-crewai             # CrewAI adapter
```

## API Key

Free key (2,000 calls/month): [truthstack.co/developers](https://truthstack.co/developers)

## License

MIT
