from setuptools import setup, find_packages

setup(
    name="truthstack-langchain",
    version="1.0.0",
    description="LangChain adapter for TruthStack supplement safety API. Check drug interactions, get evidence, search compounds.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="TruthStack",
    author_email="chris@truthstack.co",
    url="https://github.com/TruthStack1/truthstack-python",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=["truthstack[langchain]>=1.0.0"],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Topic :: Scientific/Engineering :: Medical Science Apps.",
    ],
    keywords="langchain ai-agent health supplements drug-interactions safety pharmacovigilance glp-1 ozempic tool",
    license="MIT",
)
