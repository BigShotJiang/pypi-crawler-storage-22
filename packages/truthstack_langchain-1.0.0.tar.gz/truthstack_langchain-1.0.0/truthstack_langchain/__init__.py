"""
truthstack-langchain — LangChain adapter for TruthStack supplement safety API.

pip install truthstack-langchain

Usage:
    from truthstack_langchain import get_tools, TruthStackClient, SYSTEM_PROMPTS
    tools = get_tools(api_key="your-key")
"""
from truthstack import (
    TruthStackClient,
    get_langchain_tools as get_tools,
    get_openai_functions,
    handle_openai_function_call,
    SYSTEM_PROMPTS,
)

__all__ = [
    "TruthStackClient",
    "get_tools",
    "get_openai_functions",
    "handle_openai_function_call",
    "SYSTEM_PROMPTS",
]
