# truthstack-llamaindex

LlamaIndex adapter for [TruthStack](https://truthstack.co) supplement safety API.

## Install

```bash
pip install truthstack-llamaindex
```

## Quick Start

```python
from truthstack_llamaindex import get_tools
from llama_index.core.agent import ReActAgent
from llama_index.llms.openai import OpenAI

tools = get_tools(api_key="your-key")
agent = ReActAgent.from_tools(tools, llm=OpenAI(model="gpt-4"))

response = agent.chat("What's the evidence for CoQ10?")
```

## Tools Included

| Tool | Description |
|------|-------------|
| `truthstack_check_interactions` | Check supplement + drug interactions |
| `truthstack_get_evidence` | Evidence balance + citations |
| `truthstack_search_supplements` | Fuzzy compound search |
| `truthstack_safety_signals` | FDA CAERS/FAERS signals |
| `truthstack_drug_profile` | Drug CYP450 + botanical interactions |

## Also available

```bash
pip install truthstack                    # Core client
pip install truthstack-langchain          # LangChain adapter
pip install truthstack-crewai             # CrewAI adapter
```

## API Key

Free key (2,000 calls/month): [truthstack.co/developers](https://truthstack.co/developers)

## License

MIT
