"""
truthstack-llamaindex — LlamaIndex adapter for TruthStack supplement safety API.

pip install truthstack-llamaindex

Usage:
    from truthstack_llamaindex import get_tools, TruthStackClient
    tools = get_tools(api_key="your-key")
"""
from truthstack import (
    TruthStackClient,
    get_llamaindex_tools as get_tools,
    SYSTEM_PROMPTS,
)

__all__ = [
    "TruthStackClient",
    "get_tools",
    "SYSTEM_PROMPTS",
]
