"""Provider adapter interfaces and stubs."""

