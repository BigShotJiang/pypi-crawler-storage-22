"""Normalization helpers (bars, symbols, calendars)."""

