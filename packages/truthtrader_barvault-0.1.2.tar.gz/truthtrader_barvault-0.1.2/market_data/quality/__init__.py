"""Data quality checks (gaps, anomalies)."""

