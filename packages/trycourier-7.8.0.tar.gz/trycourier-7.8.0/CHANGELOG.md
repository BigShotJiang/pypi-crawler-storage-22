# Changelog

## 7.8.0 (2026-02-06)

Full Changelog: [v7.7.1...v7.8.0](https://github.com/trycourier/courier-python/compare/v7.7.1...v7.8.0)

### Features

* **api:** add publish/replace methods, versions resource to tenants.templates ([2b39781](https://github.com/trycourier/courier-python/commit/2b397816d696929cf5ad38b137b3c624f897ee26))
* **api:** support list of recipients in send message ([76ccdfd](https://github.com/trycourier/courier-python/commit/76ccdfd9aee812c97cbad0d10b13b5746db4b24e))
* **client:** add custom JSON encoder for extended type support ([b641cb6](https://github.com/trycourier/courier-python/commit/b641cb6819d5727a7ec7f1c3cf240a91a28ffd42))

## 7.7.1 (2026-01-27)

Full Changelog: [v7.7.0...v7.7.1](https://github.com/trycourier/courier-python/compare/v7.7.0...v7.7.1)

### Chores

* **ci:** upgrade `actions/github-script` ([d2d306b](https://github.com/trycourier/courier-python/commit/d2d306b62a83f3700f893d1949f4388b870d6ce9))
* **internal:** update `actions/checkout` version ([3a5c4ad](https://github.com/trycourier/courier-python/commit/3a5c4ad617bd1bd8259dd4b786b9c0716e2b4076))


### Documentation

* **types:** clarify version field description in automation_template ([f04a9e0](https://github.com/trycourier/courier-python/commit/f04a9e04d27ba53cbdf8fe7f4a0a4c168b55b070))

## 7.7.0 (2026-01-14)

Full Changelog: [v7.6.1...v7.7.0](https://github.com/trycourier/courier-python/compare/v7.6.1...v7.7.0)

### Features

* **client:** add support for binary request streaming ([f0cc366](https://github.com/trycourier/courier-python/commit/f0cc366e61a95d66d2cf01477822c21625e3a2a3))


### Chores

* **internal:** regenerate SDK with no functional changes ([a9d8cf1](https://github.com/trycourier/courier-python/commit/a9d8cf18d10f801475fb21b74546781769244cb4))
* **internal:** regenerate SDK with no functional changes ([4b373e6](https://github.com/trycourier/courier-python/commit/4b373e6fabfd0005eb5f4d954fc9f2826120cc09))

## 7.6.1 (2026-01-12)

Full Changelog: [v7.6.0...v7.6.1](https://github.com/trycourier/courier-python/compare/v7.6.0...v7.6.1)

### Bug Fixes

* **types:** remove FilterConfig/FilterConfigParam, consolidate to Filter/FilterParam types ([60a1861](https://github.com/trycourier/courier-python/commit/60a1861d91952d5059675259de9e1520f9d1e5fa))


### Chores

* **internal:** regenerate SDK with no functional changes ([4f5a16f](https://github.com/trycourier/courier-python/commit/4f5a16fb4d691e54a01e07594a5416ef6aa68e1f))

## 7.6.0 (2026-01-08)

Full Changelog: [v7.5.0...v7.6.0](https://github.com/trycourier/courier-python/compare/v7.5.0...v7.6.0)

### Features

* **api:** remove audit_events/automations/brands/bulk/inbound/translations/tenants.templates ([9967cc0](https://github.com/trycourier/courier-python/commit/9967cc0183c5d3a8af38bae19f384c8d12c66b26))


### Chores

* **internal:** codegen related update ([0e618c3](https://github.com/trycourier/courier-python/commit/0e618c3ef16b92452a1488f378ef968cee961a6c))

## 7.5.0 (2025-12-22)

Full Changelog: [v7.4.0...v7.5.0](https://github.com/trycourier/courier-python/compare/v7.4.0...v7.5.0)

### Features

* **api:** add slack/teams/pagerduty/webhook/audience recipient types to send ([5401702](https://github.com/trycourier/courier-python/commit/54017021e9ff5ba391c2b702ccdec08cb17b4ecc))


### Bug Fixes

* use async_to_httpx_files in patch method ([81d7991](https://github.com/trycourier/courier-python/commit/81d7991941ba20d717b289d4a2e87b16091ed6e0))


### Chores

* **internal:** add `--fix` argument to lint script ([14a2c9a](https://github.com/trycourier/courier-python/commit/14a2c9a30220a43af14730219bf9d81a406a7f8f))
* speedup initial import ([1ce264e](https://github.com/trycourier/courier-python/commit/1ce264e0da7aac803ffd405e4672fd2f69fdfd10))

## 7.4.0 (2025-12-16)

Full Changelog: [v7.3.0...v7.4.0](https://github.com/trycourier/courier-python/compare/v7.3.0...v7.4.0)

### Features

* Add timezone field to Delay schema ([85b8c6f](https://github.com/trycourier/courier-python/commit/85b8c6f5fca9a68321d16c2927ea89cf509813d7))
* Update bulk API spec: make event required, document profile.email req… ([1b99e93](https://github.com/trycourier/courier-python/commit/1b99e9336b2f38487b873962a81e9ffd2b82f019))


### Bug Fixes

* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([ab5f2d0](https://github.com/trycourier/courier-python/commit/ab5f2d0b7e4f0534e3fff420f7f1ea6c159693bf))


### Chores

* add missing docstrings ([ea1dec0](https://github.com/trycourier/courier-python/commit/ea1dec0951b56ee5420d3c81d0fcbd5442ae726f))
* **internal:** add missing files argument to base client ([a6fba70](https://github.com/trycourier/courier-python/commit/a6fba70d97a444af4c6c06c9adeb539051ceaee8))

## 7.3.0 (2025-12-08)

Full Changelog: [v7.2.0...v7.3.0](https://github.com/trycourier/courier-python/compare/v7.2.0...v7.3.0)

### Features

* Fix UsersGetAllTokensResponse to return object with tokens property i… ([805f26a](https://github.com/trycourier/courier-python/commit/805f26a723b14446bd70d30e45da4c3ba73ca0f9))

## 7.2.0 (2025-12-08)

Full Changelog: [v7.1.1...v7.2.0](https://github.com/trycourier/courier-python/compare/v7.1.1...v7.2.0)

### Features

* Add event_ids field to Notification schema ([02bb30d](https://github.com/trycourier/courier-python/commit/02bb30db537aca01f146a165ddf08d561cea1244))


### Bug Fixes

* **client:** fix duplicate Go struct resulting from name derivations schema ([f2f7fc4](https://github.com/trycourier/courier-python/commit/f2f7fc498132b1ca3d39a90d178ab01ca372e6c9))


### Chores

* **docs:** use environment variables for authentication in code snippets ([f393857](https://github.com/trycourier/courier-python/commit/f393857a8d91fdeb8eecb649033de72b8adbee9f))
* update lockfile ([15713ee](https://github.com/trycourier/courier-python/commit/15713ee6c246e5d1a7388718b9d09303eebeb541))

## 7.1.1 (2025-12-02)

Full Changelog: [v7.1.0...v7.1.1](https://github.com/trycourier/courier-python/compare/v7.1.0...v7.1.1)

### Bug Fixes

* ensure streams are always closed ([0b75285](https://github.com/trycourier/courier-python/commit/0b75285d6addee258564f8b5a900b17248d2b1b7))


### Chores

* add Python 3.14 classifier and testing ([b712bc3](https://github.com/trycourier/courier-python/commit/b712bc3294d19db94aa6aae15b4bb5693e57e2c4))
* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([8fb8ad7](https://github.com/trycourier/courier-python/commit/8fb8ad70a33482ae03cccd8de913b6c3b79101bf))

## 7.1.0 (2025-11-18)

Full Changelog: [v7.0.1...v7.1.0](https://github.com/trycourier/courier-python/compare/v7.0.1...v7.1.0)

### Features

* JWT scope updates ([79503e5](https://github.com/trycourier/courier-python/commit/79503e5c99993a0a81fdc8da9eb8553c541cf6af))
* NPM enabled ([a93573b](https://github.com/trycourier/courier-python/commit/a93573b77947d06113262e73b48c7aaba74e1832))
* Test ([cdeccac](https://github.com/trycourier/courier-python/commit/cdeccac6ac1d08ba5864b8e1a9b05b4ae5ae983f))

## 7.0.1 (2025-11-12)

Full Changelog: [v7.0.0...v7.0.1](https://github.com/trycourier/courier-python/compare/v7.0.0...v7.0.1)

### Chores

* update SDK settings ([7c0140c](https://github.com/trycourier/courier-python/commit/7c0140c957a23aa2f60911b7383537215251927d))

## 7.0.0 (2025-11-12)

Full Changelog: [v6.4.0...v7.0.0](https://github.com/trycourier/courier-python/compare/v6.4.0...v7.0.0)

### Bug Fixes

* compat with Python 3.14 ([a337f1e](https://github.com/trycourier/courier-python/commit/a337f1e0b438535a0f2fc15c9420e898bb8f70aa))
* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([97cf79e](https://github.com/trycourier/courier-python/commit/97cf79e38f18413e79e836660b76e8ef302c4132))


### Chores

* **package:** drop Python 3.8 support ([f229ffd](https://github.com/trycourier/courier-python/commit/f229ffdcb06fb808b578cec0d2920a5fb893a205))

## 6.4.0 (2025-11-08)

Full Changelog: [v6.4.0-alpha20...v6.4.0](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha20...v6.4.0)

### Features

* **api:** manual updates ([b16bac2](https://github.com/trycourier/courier-python/commit/b16bac2553d106e3ddc040bdfe3beac79f8c0408))
* **api:** manual updates ([cd9ed1b](https://github.com/trycourier/courier-python/commit/cd9ed1b563215b6896734669bd041c091f0db29a))
* Token Prop Description Change ([66b3845](https://github.com/trycourier/courier-python/commit/66b3845cce21eca402dac7348ce9017fa8a55255))


### Chores

* configure new SDK language ([f004f07](https://github.com/trycourier/courier-python/commit/f004f07aabba46f78d7834c62b4ef1ce4ec11759))
* **internal:** codegen related update ([6fb395b](https://github.com/trycourier/courier-python/commit/6fb395bb3062bb749130c8f6345fbfcd693d2584))

## 6.4.0-alpha20 (2025-11-04)

Full Changelog: [v6.4.0-alpha19...v6.4.0-alpha20](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha19...v6.4.0-alpha20)

### Features

* Attempt kick off again ([d6f825e](https://github.com/trycourier/courier-python/commit/d6f825e2fae7878f03066540056f672b5ff8463d))
* Organization update ([4ba51f6](https://github.com/trycourier/courier-python/commit/4ba51f6bbdf8af2c82cd076935ade4d7d185971e))


### Chores

* **internal/tests:** avoid race condition with implicit client cleanup ([a01184b](https://github.com/trycourier/courier-python/commit/a01184b50a2c8c951d499cf85967fa2350a5371f))
* **internal:** grammar fix (it's -&gt; its) ([e774a66](https://github.com/trycourier/courier-python/commit/e774a6671c0892b648f02d051c56a441baabc679))

## 6.4.0-alpha19 (2025-11-01)

Full Changelog: [v6.4.0-alpha18...v6.4.0-alpha19](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha18...v6.4.0-alpha19)

### Bug Fixes

* **client:** close streams without requiring full consumption ([31633eb](https://github.com/trycourier/courier-python/commit/31633eb82c4d91ac6972769edac89b53309988b3))

## 6.4.0-alpha18 (2025-10-31)

Full Changelog: [v6.4.0-alpha17...v6.4.0-alpha18](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha17...v6.4.0-alpha18)

### Features

* Comment adjustment to kick of build ([0ea3bef](https://github.com/trycourier/courier-python/commit/0ea3bef13736755b7d4cf9b76f73df6ed06c0dee))


### Bug Fixes

* Comment to kick off build ([a375abf](https://github.com/trycourier/courier-python/commit/a375abfa4ce25503b3d1b54b00092d49dcf3fbf4))

## 6.4.0-alpha17 (2025-10-18)

Full Changelog: [v6.4.0-alpha16...v6.4.0-alpha17](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha16...v6.4.0-alpha17)

### Chores

* bump `httpx-aiohttp` version to 0.1.9 ([e0d109f](https://github.com/trycourier/courier-python/commit/e0d109f1a1f1818a3649392af3c49b82890f0cc9))

## 6.4.0-alpha16 (2025-10-17)

Full Changelog: [v6.4.0-alpha15...v6.4.0-alpha16](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha15...v6.4.0-alpha16)

### Bug Fixes

* Dep Warning ([57f6081](https://github.com/trycourier/courier-python/commit/57f6081d87114e8c7fb0b8765a20321e9bf2542c))

## 6.4.0-alpha15 (2025-10-17)

Full Changelog: [v6.4.0-alpha14...v6.4.0-alpha15](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha14...v6.4.0-alpha15)

### Features

* Changes to spec, examples and scripts ([78b8d02](https://github.com/trycourier/courier-python/commit/78b8d023d5e683676e24a273015bc41e3f4ba409))
* More PHP and attempted node automerge ([14dc341](https://github.com/trycourier/courier-python/commit/14dc341fcc0abf5ebe420bb0b7cba33743d71cd2))


### Bug Fixes

* Updated paths for each model and go example updates ([5afd3bc](https://github.com/trycourier/courier-python/commit/5afd3bcbe1ebb4a53949101715726498f00e82eb))

## 6.4.0-alpha14 (2025-10-14)

Full Changelog: [v6.4.0-alpha13...v6.4.0-alpha14](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha13...v6.4.0-alpha14)

### Features

* **api:** manual updates ([e112bd0](https://github.com/trycourier/courier-python/commit/e112bd07fe318d465a9001f674cefc659de76873))
* **api:** manual updates ([d42b37a](https://github.com/trycourier/courier-python/commit/d42b37ac6d7a7b5c8aa4cc5a3eea1b72cb09afa4))
* **api:** manual updates ([d47cd8b](https://github.com/trycourier/courier-python/commit/d47cd8b0f978bb63366d0a936e8acccd11765b10))
* **api:** manual updates ([71f3a3c](https://github.com/trycourier/courier-python/commit/71f3a3c26f652978c94cc38793ab5092ad67f66a))
* Examples and ref polish ([2064338](https://github.com/trycourier/courier-python/commit/2064338fb827f5e0ad9db7c0b5d4926a40ef8367))
* Kick of merge attempt ([06e8c01](https://github.com/trycourier/courier-python/commit/06e8c015bc29116e7a082d09861f6b6f36302a1b))
* Model sync ([01f64f4](https://github.com/trycourier/courier-python/commit/01f64f404515503bcf81349f9f8ccaa1c6233317))
* Polish and Kick of Java Kit Gen ([bd0f5eb](https://github.com/trycourier/courier-python/commit/bd0f5ebf450895f319e0d1ee2e5ec2c198248137))
* Template Id ([8d36ed8](https://github.com/trycourier/courier-python/commit/8d36ed831629ea1910533783f184c5798fba3aea))
* Test Github Action ([cb50c99](https://github.com/trycourier/courier-python/commit/cb50c99f72467b58071fe058c42acd4359152ea4))
* Test stainless open action ([b107881](https://github.com/trycourier/courier-python/commit/b107881432227ac071760c1f2918bf69ec4aec8d))


### Chores

* **internal:** detect missing future annotations with ruff ([3826b8b](https://github.com/trycourier/courier-python/commit/3826b8b4fbe88b0e2b536c176e9ae7da86446445))

## 6.4.0-alpha13 (2025-10-07)

Full Changelog: [v6.4.0-alpha12...v6.4.0-alpha13](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha12...v6.4.0-alpha13)

### Features

* **api:** manual updates ([1482bb2](https://github.com/trycourier/courier-python/commit/1482bb27d45147a4b65e671b81faaff53f786225))

## 6.4.0-alpha12 (2025-10-07)

Full Changelog: [v6.4.0-alpha11...v6.4.0-alpha12](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha11...v6.4.0-alpha12)

### Features

* **api:** manual updates ([ad3b963](https://github.com/trycourier/courier-python/commit/ad3b9633fa1ceba37addacfde355a595d61b4e10))
* **api:** manual updates ([0fa89b2](https://github.com/trycourier/courier-python/commit/0fa89b2c933ae9f5cb8ca2510ee37a4b6cc2db5f))

## 6.4.0-alpha11 (2025-10-07)

Full Changelog: [v6.4.0-alpha9...v6.4.0-alpha11](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha9...v6.4.0-alpha11)

### Features

* **api:** manual updates ([26ed528](https://github.com/trycourier/courier-python/commit/26ed528ff384d590feeef3405b5e2cb15136c25b))
* **api:** manual updates ([250903a](https://github.com/trycourier/courier-python/commit/250903a54c817c31f369d7739bb16f4a1a693c24))
* **api:** manual updates ([1878d7e](https://github.com/trycourier/courier-python/commit/1878d7ebb8b8b6ab96c48cade6e8adc7f85ee73f))
* **api:** manual updates ([87191fd](https://github.com/trycourier/courier-python/commit/87191fd3b6b369946744a4d5459979c3c6b1fead))
* **api:** manual updates ([cc4c950](https://github.com/trycourier/courier-python/commit/cc4c9500b58b8d337a59f79cd7ca58ab1ee4e4fc))
* **api:** manual updates ([899b66a](https://github.com/trycourier/courier-python/commit/899b66a240ea0dee22607751d8b1f6375b656610))
* **api:** manual updates ([f1e4f47](https://github.com/trycourier/courier-python/commit/f1e4f47468781a5bd3b7e2f001570d7990c85f00))
* **api:** manual updates ([def8956](https://github.com/trycourier/courier-python/commit/def895610f763927486200d52191229730b676a4))
* **api:** manual updates ([ae8ca25](https://github.com/trycourier/courier-python/commit/ae8ca2565fbaed044943de63bd72ecb2db329815))


### Chores

* update SDK settings ([32ed923](https://github.com/trycourier/courier-python/commit/32ed923a5ad675ec4e1f70623dca1e7447dda737))
* update SDK settings ([480ec2f](https://github.com/trycourier/courier-python/commit/480ec2f6dde592809c21ce10e834686bf56bb4f9))

## 6.4.0-alpha9 (2025-10-06)

Full Changelog: [v6.4.0-alpha8...v6.4.0-alpha9](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha8...v6.4.0-alpha9)

### Features

* **api:** manual updates ([ca9ad78](https://github.com/trycourier/courier-python/commit/ca9ad7836de13c74bb8079dbee85e24b952a3062))
* **api:** manual updates ([834a929](https://github.com/trycourier/courier-python/commit/834a929017d2cce9fc436c74ed2ee62dc35755b4))
* **api:** manual updates ([8ac4acb](https://github.com/trycourier/courier-python/commit/8ac4acb4c4b727f5909b362bed3feec644e4b619))

## 6.4.0-alpha8 (2025-10-06)

Full Changelog: [v6.4.0-alpha7...v6.4.0-alpha8](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha7...v6.4.0-alpha8)

### Features

* **api:** manual updates ([9f8698c](https://github.com/trycourier/courier-python/commit/9f8698cc478334c02ee28e1b9149f9f255887f35))

## 6.4.0-alpha7 (2025-10-03)

Full Changelog: [v6.4.0-alpha6...v6.4.0-alpha7](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha6...v6.4.0-alpha7)

### Features

* **api:** manual updates ([afad076](https://github.com/trycourier/courier-python/commit/afad076eed4506db36e9997072a6c74bc127a64e))
* **api:** manual updates ([07455a3](https://github.com/trycourier/courier-python/commit/07455a32228d749413929e164d47b504edd86354))

## 6.4.0-alpha6 (2025-10-02)

Full Changelog: [v6.4.0-alpha5...v6.4.0-alpha6](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha5...v6.4.0-alpha6)

### Features

* **api:** manual updates ([a451897](https://github.com/trycourier/courier-python/commit/a45189735dca2ee6983378929a634b606b9020e2))
* **api:** manual updates ([36bb627](https://github.com/trycourier/courier-python/commit/36bb62743986c845fad2f3fecaa188d7de556385))

## 6.4.0-alpha5 (2025-10-02)

Full Changelog: [v6.4.0-alpha4...v6.4.0-alpha5](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha4...v6.4.0-alpha5)

### Features

* **api:** manual updates ([c34431e](https://github.com/trycourier/courier-python/commit/c34431efa9d87ddf206192dec64b06889c900a45))

## 6.4.0-alpha4 (2025-10-02)

Full Changelog: [v6.4.0-alpha3...v6.4.0-alpha4](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha3...v6.4.0-alpha4)

### Features

* **api:** manual updates ([1d2cb25](https://github.com/trycourier/courier-python/commit/1d2cb258a5765cdf7aa8ce86158b01947565530b))

## 6.4.0-alpha3 (2025-10-02)

Full Changelog: [v6.4.0-alpha2...v6.4.0-alpha3](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha2...v6.4.0-alpha3)

### Features

* **api:** manual updates ([75fba38](https://github.com/trycourier/courier-python/commit/75fba382fb63386480b3b12b3d48ee329244e85d))

## 6.4.0-alpha2 (2025-10-02)

Full Changelog: [v6.4.0-alpha1...v6.4.0-alpha2](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha1...v6.4.0-alpha2)

### Features

* **api:** manual updates ([174ee72](https://github.com/trycourier/courier-python/commit/174ee72b20f2dca6ec5f680f0ed6d7efabc1833a))

## 6.4.0-alpha1 (2025-10-02)

Full Changelog: [v6.4.0-alpha0...v6.4.0-alpha1](https://github.com/trycourier/courier-python/compare/v6.4.0-alpha0...v6.4.0-alpha1)

### Chores

* update SDK settings ([6c392ae](https://github.com/trycourier/courier-python/commit/6c392ae4d5e6a1d41eb3b175964978d79a783f58))

## 6.4.0-alpha0 (2025-10-02)

Full Changelog: [v0.0.1...v6.4.0-alpha0](https://github.com/trycourier/courier-python/compare/v0.0.1...v6.4.0-alpha0)

### Features

* **api:** manual updates ([2e6a07a](https://github.com/trycourier/courier-python/commit/2e6a07ab17a63673de30d2dd088a492e1ecf5073))
* **api:** manual updates ([51a28ef](https://github.com/trycourier/courier-python/commit/51a28efc4e1d20328556ae691fe4a768bbb277b4))
* **api:** manual updates ([b16bac2](https://github.com/trycourier/courier-python/commit/b16bac2553d106e3ddc040bdfe3beac79f8c0408))
* **api:** manual updates ([cd9ed1b](https://github.com/trycourier/courier-python/commit/cd9ed1b563215b6896734669bd041c091f0db29a))


### Chores

* configure new SDK language ([f004f07](https://github.com/trycourier/courier-python/commit/f004f07aabba46f78d7834c62b4ef1ce4ec11759))
* **internal:** codegen related update ([6fb395b](https://github.com/trycourier/courier-python/commit/6fb395bb3062bb749130c8f6345fbfcd693d2584))
* update SDK settings ([3317d9e](https://github.com/trycourier/courier-python/commit/3317d9ec8f294d05ddd89e3b2e7f5da9a8716127))
* update SDK settings ([2677204](https://github.com/trycourier/courier-python/commit/2677204576bea283de2c5f7e17cad008a0ca497b))
