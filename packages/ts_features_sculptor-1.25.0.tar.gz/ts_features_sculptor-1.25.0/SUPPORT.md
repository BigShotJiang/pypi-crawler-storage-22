# Support

Best-effort maintenance: no SLA, no on-call, no production incident support.

This project is intended for research and rapid experimentation.
If you use it in production, you are responsible for validation, monitoring, and risk management.

We welcome: reproducible bug reports, minimal examples, PRs with tests.