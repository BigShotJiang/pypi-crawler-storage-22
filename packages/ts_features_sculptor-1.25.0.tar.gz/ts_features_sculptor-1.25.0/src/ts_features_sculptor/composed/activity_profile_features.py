"""Профиль активности по дневной сетке."""
from dataclasses import dataclass

import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin

from ts_features_sculptor import (
    DaysSinceLastEvent,
    RowLag,
)
from ts_features_sculptor import (
    EwmSmoother,
    IndexedWindowAggregator,
    Ratio,
    TimeRollingAggregator,
    WorkdayWindowIndexer,
)


@dataclass
class ActivityProfileFeatures(
    BaseEstimator, TransformerMixin
):
    """Профиль активности по дневной сетке.

    Составной трансформер: дни неактивности, стаж,
    скользящие средние, сглаживание, изменение
    активности. Все шаги stateless (только transform).

    Parameters
    ----------
    time_col : str, default="time"
        Колонка с датой.
    event_col : str, default="has_event"
        Бинарный флаг события (>0).
    holiday_col : str, default="is_holiday"
        Флаг праздников для WorkdayWindowIndexer.
    count_col : str, default="daily_order_count"
        Количество базовых строк в день.
    value_col : str, default="daily_total_original_sum"
        Значение для скользящих средних.
    window_workdays : int, default=30
        Окно рабочих дней для подсчета строк.
    short_window_days : int, default=15
        Короткое окно (дни) для rolling mean.
    long_window_days : int, default=30
        Длинное окно (дни) для rolling mean.
    ewm_passes : int, default=2
        Число проходов EWM-сглаживания.
    trend_lag_rows : int, default=15
        Лаг (строки) для расчета тренда.

    Algorithm
    ---------
    V = value_col, S = short_window_days,
    L = long_window_days, P = ewm_passes,
    LAG = trend_lag_rows

    1. DaysSinceLastEvent(event_col)
       -> days_inactive, last_event_day
    2. days_of_life = last_event_day - first_event_day
    3. WorkdayWindowIndexer(window_workdays, backward)
       -> workday_start_idx, workday_end_idx
    4. IndexedWindowAggregator(count_col, sum)
       -> base_count_W
    5. TimeRollingAggregator(V, S, mean)
       -> rolling_{V}_mean_{S}d
    6. TimeRollingAggregator(V, L, mean)
       -> rolling_{V}_mean_{L}d
    7. EwmSmoother(V, passes=P)
       -> {V}_smoothed
    8. TimeRollingAggregator({V}_smoothed, S, mean)
       -> recent_col
    9. RowLag(recent_col, lag=LAG)
       -> prev_col
    10. Ratio(prev / recent)
        -> activity_change_ratio
    """

    time_col: str = "time"
    event_col: str = "has_event"
    holiday_col: str = "is_holiday"
    count_col: str = "daily_order_count"
    value_col: str = "daily_total_original_sum"
    window_workdays: int = 30
    short_window_days: int = 15
    long_window_days: int = 30
    ewm_passes: int = 2
    trend_lag_rows: int = 15

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        df = X.copy()

        sw = self.short_window_days
        lw = self.long_window_days
        smoothed_col = f"{self.value_col}_smoothed"

        # 1. days_inactive, last_event_day
        df = DaysSinceLastEvent(
            time_col=self.time_col,
            event_col=self.event_col,
            out_days_col="days_inactive",
            out_last_day_col="last_event_day",
        ).transform(df)

        # 2. days_of_life
        ts = pd.to_datetime(df[self.time_col])
        first_day = (
            ts.where(df[self.event_col] > 0).min()
        )
        df["days_of_life"] = (
            df["last_event_day"] - first_day
        ).dt.days

        # 3. WorkdayWindowIndexer
        df = WorkdayWindowIndexer(
            time_col=self.time_col,
            anchor_col="last_event_day",
            holiday_col=self.holiday_col,
            window_workdays=self.window_workdays,
            direction="backward",
            closed="both",
            start_idx_col="workday_start_idx",
            end_idx_col="workday_end_idx",
            is_full_window_col="is_full_window",
        ).transform(df)

        # 4. base_count_W
        df = IndexedWindowAggregator(
            time_col=self.time_col,
            value_col=self.count_col,
            start_idx_col="workday_start_idx",
            end_idx_col="workday_end_idx",
            agg="sum",
            out_col="base_count_W",
        ).transform(df)

        # 5. rolling mean (short window)
        df = TimeRollingAggregator(
            time_col=self.time_col,
            feature_col=self.value_col,
            window_days=sw,
            agg_funcs=["mean"],
            closed_interval="left",
        ).transform(df)

        # 6. rolling mean (long window)
        df = TimeRollingAggregator(
            time_col=self.time_col,
            feature_col=self.value_col,
            window_days=lw,
            agg_funcs=["mean"],
            closed_interval="left",
        ).transform(df)

        # 7. EWM smoothing
        df = EwmSmoother(
            time_col=self.time_col,
            value_col=self.value_col,
            passes=self.ewm_passes,
            out_col=smoothed_col,
        ).transform(df)

        # 8. rolling mean of smoothed (short window)
        df = TimeRollingAggregator(
            time_col=self.time_col,
            feature_col=smoothed_col,
            window_days=sw,
            agg_funcs=["mean"],
            closed_interval="left",
        ).transform(df)
        recent_col = (
            f"rolling_{smoothed_col}_mean_{sw}d"
        )

        # 9. RowLag(recent, trend_lag_rows)
        lag = self.trend_lag_rows
        df = RowLag(
            time_col=self.time_col,
            feature_col=recent_col,
            lags=[lag],
            fillna=None,
        ).transform(df)
        prev_col = f"{recent_col}_rowlag_{lag}r"

        # 10. activity_change_ratio = prev / recent
        df = Ratio(
            numerator_col=prev_col,
            denominator_col=recent_col,
            out_col="activity_change_ratio",
            fillna_value=0.0,
        ).transform(df)

        return df
