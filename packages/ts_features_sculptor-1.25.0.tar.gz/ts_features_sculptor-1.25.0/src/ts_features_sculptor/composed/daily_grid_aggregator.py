from dataclasses import dataclass, field
from typing import Optional

import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline

from ts_features_sculptor import (
    SortByTime,
    ToDateTime,
    TimeGridResampler,
    TimeBucketAggregator,
)


@dataclass
class DailyGridAggregator(
    BaseEstimator, TransformerMixin
):
    """Агрегация временного ряда в дневную сетку.

    Составной трансформер: приводит время,
    сортирует, агрегирует в дневные бакеты,
    заполняет пропуски на сетке.

    Parameters
    ----------
    event_df : pd.DataFrame | None, default=None
        Интервальные события с колонками start/end.
        Используются для расчета правой границы
        сетки. None = без событий.
    time_col : str, default="time"
        Колонка с датой/временем в X.
    event_start_col : str, default="start"
        Колонка начала в event_df.
    event_end_col : str, default="end"
        Колонка конца в event_df.
    agg_map : dict | None, default=None
        Словарь агрегаций для TimeBucketAggregator.
        None = без агрегации (только сетка).
    count_col : str | None, default=None
        Ключ из agg_map с agg="size". Если задан,
        переименовывает _size-суффикс и добавляет
        бинарный флаг has_event.
    grid_end_policy : str, default="events"
        Способ расчета конца сетки
        ("events" | "strict_as_of").
    target_horizon_days : int, default=21
        Горизонт таргета в днях.
    observation_end : pd.Timestamp | None,
            default=None
        Правая граница наблюдения.
    as_of_ts : pd.Timestamp | None, default=None
        Временная метка для политики strict_as_of.

    Attributes (после fit)
    ----------------------
    grid_start_ : pd.Timestamp
        Левая граница сетки.
    grid_end_ : pd.Timestamp
        Правая граница сетки.

    Algorithm
    ---------
    fit(X):
        grid_start_ = floor(min(X[time_col]), D)
        candidate   = floor(max(X[time_col]), D)

        if event_df:
            candidate = max(
                candidate,
                floor(max(event_df[end]), D),
                floor(max(event_df[start]), D)
                    + target_horizon_days
            )

        if grid_end_policy == "strict_as_of":
            grid_end_ = floor(as_of_ts, D)
        else:
            grid_end_ = candidate

        if observation_end:
            grid_end_ = min(grid_end_, floor(obs, D))

    transform(X):
        X -> ToDateTime -> SortByTime
          -> TimeBucketAggregator(agg_map)
          -> TimeGridResampler([grid_start_, grid_end_])
          -> result
    """
    event_df: Optional[pd.DataFrame] = None
    time_col: str = "time"
    event_start_col: str = "start"
    event_end_col: str = "end"
    agg_map: Optional[dict] = None
    count_col: Optional[str] = None
    grid_end_policy: str = "events"
    target_horizon_days: int = 21
    observation_end: Optional[pd.Timestamp] = None
    as_of_ts: Optional[pd.Timestamp] = None

    def fit(self, X, y=None):
        base_time = pd.to_datetime(X[self.time_col])
        self.grid_start_ = base_time.min().normalize()
        last_base_day = base_time.max().normalize()

        candidate = last_base_day
        last_event_start_day = None

        ev = self.event_df
        if ev is not None and not ev.empty:
            last_start = pd.to_datetime(
                ev[self.event_start_col]
            ).max()
            if pd.notna(last_start):
                last_event_start_day = (
                    last_start.normalize()
                )

            last_end = pd.to_datetime(
                ev[self.event_end_col]
            ).max()
            if pd.notna(last_end):
                candidate = max(
                    candidate,
                    last_end.normalize(),
                )

        if last_event_start_day is not None:
            horizon = pd.Timedelta(
                days=int(self.target_horizon_days)
            )
            candidate = max(
                candidate,
                last_event_start_day + horizon,
            )

        if self.grid_end_policy == "strict_as_of":
            if self.as_of_ts is None:
                raise ValueError(
                    "DailyGridAggregator: "
                    "as_of_ts is required"
                )
            grid_end = pd.to_datetime(
                self.as_of_ts
            ).normalize()
        else:
            grid_end = candidate

        if self.observation_end is not None:
            obs_day = pd.to_datetime(
                self.observation_end
            ).normalize()
            grid_end = min(obs_day, grid_end)

        self.grid_end_ = grid_end
        return self

    def transform(self, X):
        steps = [
            ("to_datetime", ToDateTime(
                time_col=self.time_col,
                date_format="mixed",
            )),
            ("sort", SortByTime(
                time_col=self.time_col,
            )),
        ]
        if self.agg_map is not None:
            steps.append((
                "daily_agg",
                TimeBucketAggregator(
                    time_col=self.time_col,
                    agg_map=self.agg_map,
                ),
            ))
        steps.append((
            "grid",
            TimeGridResampler(
                time_col=self.time_col,
                start=self.grid_start_,
                end=self.grid_end_,
            ),
        ))

        pipe = Pipeline(steps=steps)
        out_df = pipe.fit_transform(X)

        if self.count_col is not None:
            size_col = (
                f"daily_{self.count_col}_size"
            )
            target_col = f"daily_{self.count_col}"
            if size_col in out_df.columns:
                out_df = out_df.rename(
                    columns={size_col: target_col}
                )
            elif target_col not in out_df.columns:
                target_col = size_col
            out_df["has_event"] = (
                (out_df[target_col] > 0).astype(int)
            )

        return out_df
