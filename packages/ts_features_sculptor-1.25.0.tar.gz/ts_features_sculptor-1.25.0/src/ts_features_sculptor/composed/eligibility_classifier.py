"""Классификация допустимости воздействия."""
from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


@dataclass
class EligibilityClassifier(
    BaseEstimator, TransformerMixin
):
    """Классификация допустимости воздействия.

    Пороговый классификатор: по поведенческим метрикам
    и кулдауну определяет категорию допустимости
    (declining, lapsing, low_activity).

    Parameters
    ----------
    days_inactive_col : str, default="days_inactive"
        Дни неактивности.
    change_ratio_col : str
        Отношение прошлой активности к текущей.
    lifetime_col : str, default="days_of_life"
        Стаж (дни от первого события).
    count_col : str, default="base_count_W"
        Число базовых строк в окне рабочих дней.
    cooldown_ok_col : str, default="cooldown_ok"
        Флаг допустимости по кулдауну.
    days_inactive_threshold : float, default=14.0
        Базовый порог неактивности (дни).
    lifetime_min : int, default=30
        Минимальный стаж (дни).
    declining_koeff : float, default=0.6
        Множитель порога для declining.
    change_ratio_threshold : float, default=2.5
        Порог падения активности для declining.
    declining_count_min : int, default=5
        Мин. число строк для declining.
    lapsing_koeff : float, default=1.5
        Множитель порога для lapsing.
    lapsing_count_min : int, default=5
        Мин. число строк для lapsing.
    low_act_search_days : float, default=14.0
        Макс. неактивность для low_activity.
    low_act_count_min : int, default=2
        Мин. число строк для low_activity.
    low_act_count_max : int, default=5
        Макс. число строк для low_activity.

    Algorithm
    ---------
    1. eligible_declining =
       days_inactive < declining_koeff * threshold
       AND change_ratio > change_ratio_threshold
       AND lifetime >= lifetime_min
       AND count >= declining_count_min
    2. eligible_lapsing =
       threshold <= days_inactive
           <= lapsing_koeff * threshold
       AND lifetime >= lifetime_min
       AND count >= lapsing_count_min
    3. eligible_low_activity =
       days_inactive <= low_act_search_days
       AND lifetime >= lifetime_min
       AND low_act_count_min <= count
           <= low_act_count_max
    4. eligible_any = declining OR lapsing
           OR low_activity
       eligible_final = eligible_any AND cooldown_ok
       eligible_category = priority(
           DECLINING > LAPSING > LOW_ACTIVITY)
    """

    # -- входные колонки --
    days_inactive_col: str = "days_inactive"
    change_ratio_col: str = (
        "activity_change_ratio"
    )
    lifetime_col: str = "days_of_life"
    count_col: str = "base_count_W"
    cooldown_ok_col: str = "cooldown_ok"

    # -- общие пороги --
    days_inactive_threshold: float = 14.0
    lifetime_min: int = 30

    # -- declining --
    declining_koeff: float = 0.6
    change_ratio_threshold: float = 2.5
    declining_count_min: int = 5

    # -- lapsing --
    lapsing_koeff: float = 1.5
    lapsing_count_min: int = 5

    # -- low_activity --
    low_act_search_days: float = 14.0
    low_act_count_min: int = 2
    low_act_count_max: int = 5

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        df = X.copy()

        di = df[self.days_inactive_col]
        cr = df[self.change_ratio_col]
        lt = df[self.lifetime_col]
        cnt = df[self.count_col]
        thr = self.days_inactive_threshold

        # 1. declining (retention)
        df["eligible_declining"] = (
            (di < self.declining_koeff * thr)
            & (cr > self.change_ratio_threshold)
            & (lt >= self.lifetime_min)
            & (cnt >= self.declining_count_min)
        ).astype(int)

        # 2. lapsing (win-back)
        df["eligible_lapsing"] = (
            (di >= thr)
            & (di <= self.lapsing_koeff * thr)
            & (lt >= self.lifetime_min)
            & (cnt >= self.lapsing_count_min)
        ).astype(int)

        # 3. low_activity (activation)
        df["eligible_low_activity"] = (
            (di <= self.low_act_search_days)
            & (lt >= self.lifetime_min)
            & (cnt >= self.low_act_count_min)
            & (cnt <= self.low_act_count_max)
        ).astype(int)

        # 4. eligible_any, eligible_final, category
        any_mask = (
            df["eligible_declining"]
            | df["eligible_lapsing"]
            | df["eligible_low_activity"]
        )
        df["eligible_any"] = any_mask.astype(int)

        if self.cooldown_ok_col in df.columns:
            cooldown = df[self.cooldown_ok_col]
            df["eligible_final"] = (
                any_mask & cooldown
            ).astype(int)
        else:
            df["eligible_final"] = (
                df["eligible_any"]
            )

        cat = np.where(
            df["eligible_declining"] == 1,
            "DECLINING",
            np.where(
                df["eligible_lapsing"] == 1,
                "LAPSING",
                np.where(
                    df["eligible_low_activity"] == 1,
                    "LOW_ACTIVITY",
                    None,
                ),
            ),
        )
        df["eligible_category"] = cat

        return df
