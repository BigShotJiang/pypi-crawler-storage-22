"""Вычисляет профиль политики назначения.

Оборачивает 2-х уровневый CalendarAssignmentPolicyStats
и HierarchicalAssignmentPolicyWeights в единый
трансформер.

Ключи задаются пользователем -- coarse_keys и
fine_keys могут быть любыми календарными разрезами.

Algorithm
---------
  C = coarse_keys, F = fine_keys

  1. prep profile: cast key columns to int
  2. coarse = CalendarAssignmentPolicyStats(keys=C)
     -> scheduler_intensity_y,
        scheduler_weight_y, support_cnt_y
  3. if F is not None:
       fine = CalendarAssignmentPolicyStats(keys=F)
       -> scheduler_intensity_ym,
          scheduler_weight_ym, support_cnt_ym
       mix = HierarchicalAssignmentPolicyWeights(
           fine=scheduler_weight_ym,
           coarse=scheduler_weight_y,
           support=support_cnt_ym, k=k)
       -> scheduler_weight
     else:
       scheduler_weight = scheduler_weight_y
"""
from dataclasses import dataclass, field

import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin

from ts_features_sculptor import (
    CalendarAssignmentPolicyStats,
    HierarchicalAssignmentPolicyWeights,
)


@dataclass
class HierarchicalAssignmentPolicyProfile(
    BaseEstimator, TransformerMixin,
):
    """2-х уровневый профиль политики назначения.

    Parameters
    ----------
    profile_df : pd.DataFrame
        Внешняя таблица профиля с колонками
        push_cnt_col, days_cnt_col и ключами.
    coarse_keys : tuple[str, ...]
        Ключи грубого уровня, например
        ("year", "dow0", "hour_bucket_12").
    normalize_coarse_keys : tuple[str, ...]
        Ключи нормировки грубого уровня,
        например ("year", "hour_bucket_12").
    fine_keys : tuple[str, ...] | None
        Ключи точного уровня. None -- только
        грубый уровень. Например
        ("year", "month", "dow0",
        "hour_bucket_12").
    normalize_fine_keys : tuple[str, ...] | None
        Ключи нормировки точного уровня.
        Например ("year", "month",
        "hour_bucket_12").
    push_cnt_col, days_cnt_col : str
        Счетчики в profile_df.
    alpha, beta : float
        Сглаживание Poisson-Gamma.
    k : float
        Псевдо-опора иерархического смешивания.
    fillna : str
        Стратегия заполнения пропусков.
    """

    profile_df: pd.DataFrame = field(repr=False)
    coarse_keys: tuple[str, ...]
    normalize_coarse_keys: tuple[str, ...]
    fine_keys: tuple[str, ...] | None = None
    normalize_fine_keys: tuple[str, ...] | None = None
    push_cnt_col: str = "hist_push_cnt"
    days_cnt_col: str = "hist_days"
    alpha: float = 1.0
    beta: float = 1.0
    k: float = 30.0
    fillna: str = "mean"

    def _prep_profile(self) -> pd.DataFrame:
        prof = self.profile_df.copy()
        all_keys = set(self.coarse_keys)
        if self.fine_keys is not None:
            all_keys |= set(self.fine_keys)
        for col in all_keys:
            if col in prof.columns:
                prof[col] = prof[col].astype(int)
        return prof

    def fit(self, X, y=None):
        prof = self._prep_profile()

        self.coarse_ = CalendarAssignmentPolicyStats(
            base_profile_df=prof,
            keys=self.coarse_keys,
            push_cnt_col=self.push_cnt_col,
            days_cnt_col=self.days_cnt_col,
            alpha=self.alpha,
            beta=self.beta,
            normalize_keys=(
                self.normalize_coarse_keys
            ),
            fillna=self.fillna,
            out_intensity_col=(
                "scheduler_intensity_y"
            ),
            out_weight_col="scheduler_weight_y",
            out_support_col="support_cnt_y",
        )

        self.has_fine_ = self.fine_keys is not None

        if self.has_fine_:
            self.fine_ = (
                CalendarAssignmentPolicyStats(
                    base_profile_df=prof,
                    keys=self.fine_keys,
                    push_cnt_col=self.push_cnt_col,
                    days_cnt_col=self.days_cnt_col,
                    alpha=self.alpha,
                    beta=self.beta,
                    normalize_keys=(
                        self.normalize_fine_keys
                    ),
                    fillna=self.fillna,
                    out_intensity_col=(
                        "scheduler_intensity_ym"
                    ),
                    out_weight_col=(
                        "scheduler_weight_ym"
                    ),
                    out_support_col=(
                        "support_cnt_ym"
                    ),
                )
            )
            self.mix_ = (
                HierarchicalAssignmentPolicyWeights(
                    fine_weight_col=(
                        "scheduler_weight_ym"
                    ),
                    fine_support_col=(
                        "support_cnt_ym"
                    ),
                    coarse_weight_col=(
                        "scheduler_weight_y"
                    ),
                    k=self.k,
                    out_weight_col=(
                        "scheduler_weight"
                    ),
                )
            )

        df = self.coarse_.fit_transform(X)
        if self.has_fine_:
            df = self.fine_.fit_transform(df)
        return self

    def transform(self, X):
        df = self.coarse_.transform(X)
        if self.has_fine_:
            df = self.fine_.transform(df)
            df = self.mix_.transform(df)
        else:
            df = df.assign(
                scheduler_weight=(
                    df["scheduler_weight_y"]
                ),
            )
        return df
