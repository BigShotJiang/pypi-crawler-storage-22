"""Кулдаун между интервальными событиями."""
from dataclasses import dataclass, field

import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin

from ts_features_sculptor import (
    IntervalEventsMerge,
    EventDaysFeatures,
    CooldownEligibility,
)


@dataclass
class TreatmentCooldown(
    BaseEstimator, TransformerMixin
):
    """Кулдаун между интервальными событиями.

    Составной трансформер: врезка интервальных событий
    в дневную сетку, дни от окончания последнего
    события, допустимость воздействия (кулдаун).
    Все шаги stateless (только transform).

    Parameters
    ----------
    time_col : str, default="time"
        Колонка с датой в base_df.
    events_df : pd.DataFrame, default=empty
        Интервальные события (start/end).
    start_col : str, default="start"
        Колонка начала события в events_df.
    end_col : str, default="end"
        Колонка конца события в events_df.
    event_name : str, default="cooldown"
        Префикс для генерируемых колонок.
    settling_days : float, default=45.0
        Порог кулдауна в днях после окончания.
    events_cols : list, default=[]
        Доп. колонки из events_df для врезки.

    Algorithm
    ---------
    1. IntervalEventsMerge(events_df, event_name)
       -> {event_name}_flag, [events_cols...]
    2. EventDaysFeatures(events_df, "since_last_end")
       -> days_since_last_{event_name}_end
    3. CooldownEligibility(
           flag_col, days_col, settling_days)
       -> {event_name}_flag_lag1,
          cooldown_ok, eligible_pre
    """

    time_col: str = "time"
    events_df: pd.DataFrame = field(
        default_factory=pd.DataFrame
    )
    start_col: str = "start"
    end_col: str = "end"
    event_name: str = "cooldown"
    settling_days: float = 45.0
    events_cols: list = field(default_factory=list)

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        df = X.copy()

        # 1. IntervalEventsMerge
        #    -> {event_name}_flag, [events_cols...]
        df = IntervalEventsMerge(
            time_col=self.time_col,
            events_df=self.events_df,
            start_col=self.start_col,
            end_col=self.end_col,
            events_cols=self.events_cols,
            fillna=0,
            event_name=self.event_name,
        ).transform(df)

        # 2. EventDaysFeatures
        #    -> days_since_last_{event_name}_end
        df = EventDaysFeatures(
            time_col=self.time_col,
            events_df=self.events_df,
            start_col=self.start_col,
            end_col=self.end_col,
            event_name=self.event_name,
            features=["since_last_end"],
        ).transform(df)

        # 3. CooldownEligibility
        #    -> {event_name}_flag_lag1,
        #       cooldown_ok, eligible_pre
        flag_col = f"{self.event_name}_flag"
        days_col = (
            f"days_since_last"
            f"_{self.event_name}_end"
        )
        df = CooldownEligibility(
            event_flag_col=flag_col,
            days_since_last_end_col=days_col,
            cooldown_days=self.settling_days,
            time_col=self.time_col,
        ).transform(df)

        return df
