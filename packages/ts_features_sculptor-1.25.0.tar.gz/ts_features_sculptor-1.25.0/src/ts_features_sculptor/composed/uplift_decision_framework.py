from dataclasses import dataclass

import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


@dataclass
class UpliftDecisionFramework(
    BaseEstimator, TransformerMixin,
):
    """Каркас decision rows для uplift-моделирования.

    Формирует строки решений из временного ряда:
    gate (pre-decision маска) -- множество риска,
        кандидат на воздействие,
    treatment (воздействие) -- факт применения
        воздействия,
    target (forward-looking исход) -- цель,
        которую необходимо предсказывать,
    observed (полнота окна) -- цель вычисляется
        на горизонте и может быть не полной.

    Parameters
    ----------
    gate_col : str
        Колонка pre-decision маски (1 = момент
        решения). Например pending_lag1.
    treatment_col : str
        Колонка индикатора воздействия.
        Например treatment_start_flag.
    outcome_col : str
        Колонка исхода для вычисления target.
        Например daily_total_original_sum.
    horizon_days : int
        Горизонт таргета в днях.
    lag_cols : tuple[str, ...] | None
        Колонки для сдвига на 1 день назад
        (pre-decision X). None -- без сдвига.
    out_gate_col : str
        Имя выходной колонки gate.
    out_treatment_col : str
        Имя выходной колонки treatment.
    out_target_col : str | None
        Имя выходной колонки target.
        None -- y_h{horizon_days}.
    out_observed_col : str | None
        Имя выходной колонки observed.
        None -- y_observed_h{horizon_days}.
    filter_gate : bool
        Оставить только строки с gate = 1.
    filter_observed : bool
        Оставить только строки с observed = 1.
    filter_clean : bool
        Оставить только строки, в горизонте
        которых нет нового воздействия
        (clean_horizon = 1). Исключает
        контрольные наблюдения, чей outcome
        загрязнен будущим treatment.

    Algorithm
    ---------
    G = gate_col,
    T = treatment_col
    O = outcome_col,
    H = horizon_days

    1. S(t) = G(t)
    2. E(t) = T(t)
    3. y(t) = sum(O(t+1 .. t+H))
        shifted = O.shift(-1)
        roll = shifted.rolling(H, min_periods=H).sum()
        y = roll.shift(-(H - 1))
    4. observed(t) = 1 if y(t) is not NaN
    5. clean_horizon(t) =
        1 if no treatment in (t, t+H]
        cumT = cumsum(T)
        n = cumT.shift(-H) - cumT
        clean = (n == 0)
    6. if lag_cols:
        for col in lag_cols: col(t) = col(t-1)
    7. if filter_gate: keep S = 1
    8. if filter_observed: keep observed = 1
    9. if filter_clean: keep clean_horizon = 1
    10. reset_index
    """

    gate_col: str
    treatment_col: str
    outcome_col: str
    horizon_days: int
    lag_cols: tuple[str, ...] | None = None
    out_gate_col: str = "S_exp"
    out_treatment_col: str = "E"
    out_target_col: str | None = None
    out_observed_col: str | None = None
    filter_gate: bool = True
    filter_observed: bool = True
    filter_clean: bool = True

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        target_col = (
            self.out_target_col
            or f"y_h{self.horizon_days}"
        )
        observed_col = (
            self.out_observed_col
            or f"y_observed_h{self.horizon_days}"
        )

        df = X.copy()

        # 1-2. gate + treatment
        df[self.out_gate_col] = (
            df[self.gate_col].fillna(0).astype(int)
        )
        df[self.out_treatment_col] = (
            df[self.treatment_col]
            .fillna(0).astype(int)
        )

        # 3. forward target: y(t) = sum(O(t+1..t+H))
        outcome = df[self.outcome_col]
        shifted = outcome.shift(-1)
        roll = shifted.rolling(
            window=self.horizon_days,
            min_periods=self.horizon_days,
        ).sum()
        df[target_col] = roll.shift(
            -(self.horizon_days - 1),
        )

        # 4. observed
        df[observed_col] = (
            df[target_col].notna().astype(int)
        )

        # 5. clean_horizon: no treatment in (t, t+H]
        treat_s = (
            df[self.treatment_col]
            .fillna(0).astype(int)
        )
        cum_t = treat_s.cumsum()
        n_treat_in_h = (
            cum_t.shift(-self.horizon_days) - cum_t
        )
        df["clean_horizon"] = (
            (n_treat_in_h == 0)
            | n_treat_in_h.isna()
        ).astype(int)

        # 6. lag pre-decision features
        if self.lag_cols is not None:
            for col in self.lag_cols:
                df[col] = df[col].shift(1)

        # 7-9. filter
        if self.filter_gate:
            df = df[df[self.out_gate_col] == 1]
        if self.filter_observed:
            df = df[df[observed_col] == 1]
        if self.filter_clean:
            df = df[df["clean_horizon"] == 1]

        df = df.reset_index(drop=True)
        return df
