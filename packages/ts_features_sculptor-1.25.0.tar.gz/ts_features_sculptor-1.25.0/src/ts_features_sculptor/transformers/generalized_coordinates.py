from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd
from scipy.signal import hilbert
from sklearn.base import BaseEstimator, TransformerMixin


@dataclass
class GeneralizedCoordinates(BaseEstimator, TransformerMixin):
    """
    Вычисляет нормированные обобщённые координаты фазового пространства
    из категориальной временной серии, агрегированной по состояниям
    во временных окнах.

    Parameters
    ----------
    time_col : str, default="frame.time"
        Имя столбца с временными метками событий. Столбец приводится
        к типу datetime автоматически, если это необходимо.
    flag_col : str, default="tcp.flags"
        Имя столбца с категориальными состояниями событий
        (например, тип пакета, класс сигнала, вид операции).
    value_col : str, default="ip.len"
        Имя столбца со значением, используемым для вычисления
        информационной значимости (например, размер, амплитуда).
    window : str, default="50ms"
        Ширина временного окна агрегации в формате pandas
        (например, ``"50ms"``, ``"500ms"``, ``"1s"``).
    epsilon : float, default=1e-10
        Малая константа для предотвращения деления на ноль
        при нормировке.
    group_col : Optional[str], default=None
        Имя столбца для группировки. Если задан, преобразование
        выполняется независимо для каждой группы.

    Methods
    -------
    fit(X, y=None)
        Не используется, возвращает self.

    transform(X)
        Агрегирует события во временные окна, вычисляет обобщённые
        координаты и возвращает новый DataFrame.

    Notes
    -----
    Трансформер реализует построение фазового пространства
    категориальной временной серии по методике оператора
    эволюции [1].

    Для каждого категориального состояния $j$ и временного окна $t_k$
    выполняются следующие шаги:

    1. Агрегация числа событий $N_j(t_k)$ и среднего значения
       $I_j(t_k)$ в окне шириной ``window``.

    2. Обобщённая координата:

       $$x_j(t_k) = \\sqrt{N_j(t_k)}$$

    3. Обобщённая скорость через преобразование Гильберта:

       $$y_j(t_k) = \\mathrm{Im}\\,\\mathcal{H}[x_j](t_k)$$

    4. Нормировка на единичную фазовую сферу (формула 3 из [1]):

       $$R(t_k) = \\sqrt{\\sum_j x_j^2(t_k) + \\sum_j y_j^2(t_k)
       + \\varepsilon}$$

       $$\\tilde{x}_j(t_k) = \\frac{x_j(t_k)}{R(t_k)}, \\quad
       \\tilde{y}_j(t_k) = \\frac{y_j(t_k)}{R(t_k)}$$

    Выходной DataFrame содержит столбцы:

    - ``time`` — время окна в секундах от начала записи;
    - ``x_{flag}`` — нормированная обобщённая координата;
    - ``y_{flag}`` — нормированная обобщённая скорость;
    - ``info_{flag}`` — информационная значимость (среднее значение).

    Зависимость: ``scipy.signal.hilbert``.

    [1] Краснов А.Е., Никольский Д.Н. // Изв. вузов. Физика.
    2020. Т. 63, No 4. С. 30–39.

    Examples
    --------
    >>> import pandas as pd
    >>> from ts_features_sculptor import GeneralizedCoordinates
    >>> t0 = pd.Timestamp("2000")
    >>> w, ms = pd.Timedelta("100ms"), pd.Timedelta("1ms")
    >>> df = pd.DataFrame({
    ...     "time": ([t0 + i*ms for i in range(25)]
    ...            + [t0 + w + i*ms for i in range(25)]),
    ...     "flag": (["A"]*9 + ["B"]*16) * 2,
    ...     "size": ([100]*9 + [300]*16) * 2,
    ... })
    >>> gc = GeneralizedCoordinates(
    ...     time_col="time", flag_col="flag",
    ...     value_col="size", window="100ms",
    ... )
    >>> result = gc.transform(df)
    >>> print((result.round(3) + 0.0).to_string(index=False))  # doctest: +NORMALIZE_WHITESPACE
     time  x_A  y_A  info_A  x_B  y_B  info_B
      0.0  0.6  0.0   100.0  0.8  0.0   300.0
      0.1  0.6  0.0   100.0  0.8  0.0   300.0
    """

    time_col: str = "frame.time"
    flag_col: str = "tcp.flags"
    value_col: str = "ip.len"
    window: str = "50ms"
    epsilon: float = 1e-10
    group_col: Optional[str] = None

    def fit(self, X: pd.DataFrame, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        self._validate(X)

        if self.group_col and self.group_col in X.columns:
            parts = []
            for _, group_df in X.groupby(self.group_col):
                parts.append(self._transform_single(group_df))
            return pd.concat(parts, ignore_index=True)

        return self._transform_single(X)

    def _validate(self, X: pd.DataFrame):
        for col in [self.time_col, self.flag_col, self.value_col]:
            if col not in X.columns:
                raise ValueError(
                    f"GeneralizedCoordinates: столбец '{col}' отсутствует "
                    f"в DataFrame. Доступные столбцы: {list(X.columns)}"
                )

    def _transform_single(self, X: pd.DataFrame) -> pd.DataFrame:
        df = X.copy()

        if not pd.api.types.is_datetime64_any_dtype(df[self.time_col]):
            df[self.time_col] = pd.to_datetime(df[self.time_col])

        t0 = df[self.time_col].min()
        df.index = df[self.time_col] - t0

        pivoted = df.pivot_table(
            index=df.index,
            columns=self.flag_col,
            values=self.value_col,
            aggfunc="sum",
        )

        N = pivoted.resample(self.window).count().fillna(0)
        I = pivoted.resample(self.window).mean().fillna(0)

        N.index = N.index.total_seconds()
        I.index = I.index.total_seconds()

        flags = N.columns.tolist()

        # Обобщённые координаты
        X_coord = N ** 0.5
        Y_coord = pd.DataFrame(
            hilbert(X_coord.values, axis=0).imag,
            index=X_coord.index,
            columns=X_coord.columns,
        )

        # Нормировка на единичную гиперсферу (формула 3)
        R = np.sqrt(
            (X_coord ** 2).sum(axis=1)
            + (Y_coord ** 2).sum(axis=1)
            + self.epsilon
        )
        Xn = X_coord.div(R, axis=0)
        Yn = Y_coord.div(R, axis=0)

        # Формирование результата
        result = pd.DataFrame({"time": Xn.index})
        for flag in flags:
            safe = str(flag).replace(".", "_").replace(" ", "_")
            result[f"x_{safe}"] = Xn[flag].values
            result[f"y_{safe}"] = Yn[flag].values
            result[f"info_{safe}"] = I[flag].values

        return result.reset_index(drop=True)
