from dataclasses import dataclass
from typing import List, Optional

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


@dataclass
class PartialCorrelation(BaseEstimator, TransformerMixin):
    """
    Вычисляет парциальную корреляцию $F$ из обобщённых координат
    фазового пространства посредством оператора эволюции $S$
    и информационного оператора $Q$.

    Parameters
    ----------
    x_cols : Optional[List[str]], default=None
        Список столбцов с нормированными обобщёнными координатами
        $\\tilde{x}_j$. Если не задан, автоматически
        определяется по префиксу ``x_``.
    y_cols : Optional[List[str]], default=None
        Список столбцов с нормированными обобщёнными скоростями
        $\\tilde{y}_j$. Если не задан, автоматически
        определяется по префиксу ``y_``.
    info_cols : Optional[List[str]], default=None
        Список столбцов с информационной значимостью $I_j$.
        Если не задан, автоматически определяется по префиксу ``info_``.
    epsilon : float, default=1e-10
        Малая константа для предотвращения деления на ноль
        при нормировке информационного оператора.
    group_col : Optional[str], default=None
        Имя столбца для группировки. Если задан, преобразование
        выполняется независимо для каждой группы.
    output_col : str, default="partial_correlation"
        Имя выходного столбца со значениями $F$.

    Methods
    -------
    fit(X, y=None)
        Не используется, возвращает self.

    transform(X)
        Добавляет к входному DataFrame столбец ``output_col``
        с вычисленными значениями парциальной корреляции $F$.

    Notes
    -----
    Трансформер реализует вычисление парциальной корреляции
    по методике оператора эволюции [1].

    Предполагается, что входной DataFrame содержит выход трансформера
    ``GeneralizedCoordinates``, а именно столбцы ``x_{flag}``,
    ``y_{flag}`` и ``info_{flag}`` для каждого категориального
    состояния.

    Для каждого временного шага $t_k$ (при $k \\geq 1$)
    выполняются следующие вычисления:

    1. **Оператор эволюции** — матрица перекрёстных корреляций
       между текущим и предыдущим состояниями фазового пространства:

       $$S_{ij}(t_k, t_{k-1}) = \\tilde{x}_i(t_k) \\, \\tilde{x}_j(t_{k-1})
       + \\tilde{y}_i(t_k) \\, \\tilde{y}_j(t_{k-1})$$

    2. **Информационный оператор** — весовая матрица, учитывающая
       информационную значимость категориальных состояний:

       $$\\Pi_j = I_j(t_k) \\cdot I_j(t_{k-1}), \\quad
       \\hat{\\Pi}_j = \\frac{\\Pi_j}{\\sum_m \\Pi_m + \\varepsilon}$$

       $$Q_{jj} = \\hat{\\Pi}_j, \\quad
       Q_{jm} = \\hat{\\Pi}_j \\cdot \\hat{\\Pi}_m \\quad (j \\neq m)$$

    3. **Парциальная корреляция** — свёртка операторов:

       $$F(t_k) = \\mathrm{tr}\\bigl[Q(t_k, t_{k-1}) \\cdot
       S(t_k, t_{k-1})\\bigr] = \\sum_{i,j} S_{ij} \\, Q_{ji}$$

    Значение $F(t_k)$ характеризует степень эволюционной
    связности процесса между соседними временными окнами.
    Резкое изменение $F$ указывает на смену режима
    (начало или окончание аномалии).

    Для первого временного шага ($k = 0$) значение $F$
    не определено и заполняется ``NaN``.

    Количество столбцов ``x_``, ``y_`` и ``info_`` должно
    совпадать.

    [1] Краснов А.Е., Никольский Д.Н. // Изв. вузов. Физика.
    2020. Т. 63, No 4. С. 30–39.

    Examples
    --------
    >>> import pandas as pd
    >>> from ts_features_sculptor import PartialCorrelation
    >>> df = pd.DataFrame({
    ...     "time":   [0.0,   0.1],
    ...     "x_A":    [0.6,   0.6],
    ...     "y_A":    [0.0,   0.0],
    ...     "info_A": [100.,  100.],
    ...     "x_B":    [0.8,   0.8],
    ...     "y_B":    [0.0,   0.0],
    ...     "info_B": [300.,  300.],
    ... })
    >>> pc = PartialCorrelation(output_col="F")
    >>> result = pc.transform(df)
    >>> print((result.round(3) + 0.0).to_string(index=False))  # doctest: +NORMALIZE_WHITESPACE
     time  x_A  y_A  info_A  x_B  y_B  info_B     F
      0.0  0.6  0.0   100.0  0.8  0.0   300.0   NaN
      0.1  0.6  0.0   100.0  0.8  0.0   300.0 0.698
    """

    x_cols: Optional[List[str]] = None
    y_cols: Optional[List[str]] = None
    info_cols: Optional[List[str]] = None
    epsilon: float = 1e-10
    group_col: Optional[str] = None
    output_col: str = "partial_correlation"

    def fit(self, X: pd.DataFrame, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        if self.group_col and self.group_col in X.columns:
            parts = []
            for _, group_df in X.groupby(self.group_col):
                parts.append(self._transform_single(group_df))
            return pd.concat(parts, ignore_index=True)

        return self._transform_single(X)

    def _detect_cols(self, X: pd.DataFrame):
        x_cols = self.x_cols or [c for c in X.columns if c.startswith("x_")]
        y_cols = self.y_cols or [c for c in X.columns if c.startswith("y_")]
        info_cols = self.info_cols or [
            c for c in X.columns if c.startswith("info_")
        ]

        if not x_cols:
            raise ValueError(
                "PartialCorrelation: не найдены столбцы обобщённых "
                "координат (x_). Убедитесь, что DataFrame содержит "
                "выход GeneralizedCoordinates."
            )
        if not y_cols:
            raise ValueError(
                "PartialCorrelation: не найдены столбцы обобщённых "
                "скоростей (y_)."
            )
        if not info_cols:
            raise ValueError(
                "PartialCorrelation: не найдены столбцы информационной "
                "значимости (info_)."
            )
        if len(x_cols) != len(y_cols):
            raise ValueError(
                f"PartialCorrelation: число столбцов x_ ({len(x_cols)}) "
                f"и y_ ({len(y_cols)}) должно совпадать."
            )

        return x_cols, y_cols, info_cols

    def _transform_single(self, X: pd.DataFrame) -> pd.DataFrame:
        x_cols, y_cols, info_cols = self._detect_cols(X)

        Xn = X[x_cols].values
        Yn = X[y_cols].values
        In = X[info_cols].values

        n_steps = Xn.shape[0]
        F_values = np.full(n_steps, np.nan)

        for k in range(1, n_steps):
            x_k = Xn[k]
            x_prev = Xn[k - 1]
            y_k = Yn[k]
            y_prev = Yn[k - 1]

            # Оператор эволюции S
            S = np.outer(x_k, x_prev) + np.outer(y_k, y_prev)

            # Информационный оператор Q
            ii = In[k] * In[k - 1]
            di = ii.sum() + self.epsilon
            ii_n = ii / di

            Q = np.outer(ii_n, ii_n)
            np.fill_diagonal(Q, ii_n)

            # Парциальная корреляция F = tr(Q @ S)
            F_values[k] = np.tensordot(S, Q, axes=[[1, 0], [0, 1]])

        result = X.copy()
        result[self.output_col] = F_values
        return result
