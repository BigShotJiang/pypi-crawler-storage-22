SELECT timestamp, sensor, device_id, value
FROM myschema.sensor_data
ORDER BY timestamp DESC
LIMIT 3;
