SELECT s AS id, 'row_' || s AS label
FROM generate_series(1, 3) AS s;
