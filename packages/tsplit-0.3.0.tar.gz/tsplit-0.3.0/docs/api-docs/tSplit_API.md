# getTIRs Class

::: tsplit.parseAlign.getTIRs
options:
members: - **init**

# getLTRs Class

::: tsplit.parseAlign.getLTRs
options:
members: - **init**
