"""UI components for ttydal."""
