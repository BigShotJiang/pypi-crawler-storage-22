class Thumbnail:
    def __init__(self, name: str, width: int, height: int, url: str):
        self.name: str = name
        self.width: int = width
        self.height: int = height
        self.url: str = url
