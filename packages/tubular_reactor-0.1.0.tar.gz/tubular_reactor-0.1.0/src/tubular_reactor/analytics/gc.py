import re
from collections import deque
import datetime as dt
from typing import Literal

import numpy as np
import numpy.typing as npt
import pandas as pd
from pybaselines import Baseline
from scipy.signal import find_peaks


def read_perkin_elmer(filepath: str) -> tuple[npt.NDArray[np.timedelta64], npt.NDArray[np.float64]]:
    #TODO: Add time milliseconds
    """
    Reads the
    """

    n_header: int = 47
    n_footer: int = 530
    start_time = np.datetime64("1970-01-01T00:00:00")

    # Get information for chromatogram
    with open(filepath, 'r', encoding='utf-8') as file:
        footer = deque(file, maxlen=n_footer)

    sampling_info: str
    sampling_rate: float | bool = False
    for idx, line in enumerate(footer):
        if line.startswith('\"RATE\"'):
            sampling_info = footer[idx+2]
            sampling_rate = float(sampling_info.split('\"')[1])
    if not sampling_rate:
        print("Sampling rate not found in chromatogram!")
        sampling_rate = 12.5
        print(f"Sampling rate to standart value of {sampling_rate:.1f}.")

    df_data: pd.DataFrame = pd.read_csv(filepath, engine='python', skiprows=n_header, skipfooter=n_footer)
    signal: npt.NDArray[np.float64] = df_data.values[:, 0]
    samples: npt.NDArray[np.int64] = np.arange(signal.shape[0])
    time: npt.NDArray[np.timedelta64] = start_time + samples * np.timedelta64(int(1e3 / sampling_rate), "ms")
    baseline_fitter = Baseline(time)
    baseline: npt.NDArray[np.float64] = baseline_fitter.asls(
        signal,
        lam=1e6,  # smoothness 1e5 - 1e7 (higher = smoother baseline)
        p=0.001  # asymmetry 0.0001 - 0.01 (smaller = ignore peaks more)
    )[0]
    signal_corrected: npt.NDArray[np.float64] = signal - baseline

    return time, signal_corrected

# Functions for conversion between str for input time, int for number of measurement / idx and dt.datetime for visualization

def strtime2dt(strtime: str) -> dt.datetime:
    """
    Conversion from time as string to datetime object
    Parameters:
        string(str): Time in form '%M":%S'.
    """

    start_time: dt.datetime = dt.datetime(1970, 1, 1)

    pattern = r"(\d+):(\d+)(?:[:.](\d{1,3}))?"
    match = re.split(pattern, strtime)
    if match:
        minutes = int(match[1])
        seconds = int(match[2])
        ms_str = match[3] if match[3] else "0"
        milliseconds = int(ms_str.ljust(3, '0')[:3])
        return start_time + dt.timedelta(minutes=minutes, seconds=seconds, milliseconds=milliseconds)
    else:
        print("Invalid time format")
        return start_time


def strtime2int(strtime: str) -> int:
    sampling_rate: float = 12.5
    # pattern: str = r"(\d+):(\d+)?:\.(\d+)"
    pattern: str = r"(\d+):(\d+)(?:\.(\d{1,3}))?"
    match = re.split(pattern, strtime)
    if match:
        minutes = int(match[1])
        seconds = int(match[2])
        ms_str = match[3] if match[3] else "0"
        milliseconds = int(ms_str.ljust(3, '0')[:3])
        total_value = int(round((minutes * 60 * sampling_rate) + (seconds * sampling_rate) + milliseconds))
        return total_value
    else:
        print("Invalid time format. Use '1:23', '1:23.4', '1:23.400' or '1:23:400")
        return 0

def int2dt(index: int) -> str:
    return str(index)



def int2strtime(index: int) -> str:
    sampling_rate: float = 12.5
    seconds, remainder = divmod(index, sampling_rate)
    milliseconds = int(remainder * 1000 / sampling_rate)
    minutes, seconds = map(int, divmod(seconds, 60))
    return f'{minutes}:{seconds:02d}.{milliseconds:03d}'


def list_peaks(signal: npt.NDArray[np.float32],
               limit_left: str | int | None = None,
               limit_right: str | int | None = None,
               # Pead finding
               min_height: float = 2500,
               min_distance: float = 25,
               min_width: float = 5,
               return_type: Literal['index', 'time'] = 'index') -> list[int | str]:
    """
    Find peaks in chromatogram and optionally return only those from a given range.
    Parameters:
        min_height(float): Minimum height of peak.
        min_distance(float): Minimum distance between two peaks.
        min_width(float): Minimum width of peak. If lower, peak is getting ignored as noise.
        # min_prominence(float): 
        # wlen(int): Window length around peak for selection of
    """
    #TODO: Check if lower distance value results in overseen peak of if peaks are getting combines as one
    peaks_cut = []
    peaks, _ = find_peaks(signal,
                          height=min_height,
                          distance=min_distance,
                          width=min_width)

    if type(limit_left) == str and type(limit_right) == str:
        try:
            limit_left_int: int = strtime2int(limit_left)
            limit_right_int: int = strtime2int(limit_right)
            peaks = [peak for peak in peaks if limit_left_int <= peak <= limit_right_int]
        except:
            print("Input valid limit for right and left as measurement index like 3820.")
    if type(limit_left) == int and type(limit_right) == int:
        try:
            peaks = [peak for peak in peaks if limit_left <= peak <= limit_right]
        except:
            print("Input valid limit for right and left as time '2:30'.")

    if return_type == 'time':
        for peak in peaks:
            peaks_cut.append(int2strtime(peak))
    else:
        peaks_cut = peaks

    return peaks_cut


def integrate_peak(chromatogram: npt.NDArray[np.float32],
                   timepoint: int | str,
                   # For peak finding
                   min_height: float=2500,
                   min_distance: float=25,
                   min_width: float=5,
                   # For peak integration
                   # min_prominence: float=0.5,
                   wlen: float=30,
                   output_limit: bool=False):
    """
    Find peaks in chromatogram and optionally return only those from a given range.
    Parameters:
        min_height(float): Minimum height of peak.
        min_distance(float): Minimum distance between two peaks.
        min_width(float): Minimum width of peak. If lower, peak is getting ignored as noise.
        min_prominence(float): 
        wlen(int): Maximum window length for selection of integration limits.
                   Adoption of peaks are wider or multiple peaks fall in window length.
    """

    if type(timepoint) == str:
        peak_select = strtime2int(timepoint)
    elif type(timepoint) == int or np.int64:
        peak_select = int(timepoint)
    else:
        print('Wrong input for timepoint. Use str or int.')
        return None

    idx = 0
    while True:
        peaks, props = find_peaks(chromatogram,
                                  height=min_height,
                                  distance=min_distance,
                                  width=min_width,
                                  # prominence=min_prominence,
                                  wlen=wlen)

        right_limits: npt.NDArray = props['right_bases']
        left_limits: npt.NDArray = props['left_bases']

        # Get limits for selected peak
        left_limit: int = 0
        right_limit: int = 0
        for left_limit, right_limit in zip(left_limits, right_limits):
            if left_limit < peak_select < right_limit:
                break

        limit_deriviative = 100
        deriviative_chromatogram = np.gradient(chromatogram)

        # Check for multiple peaks in integration range
        peaks_in_range: int = 0
        for peak in peaks:
            if left_limit < peak < right_limit:
                peaks_in_range += 1

        if peaks_in_range > 1:
            wlen -= 10
            print("Narrowing integration limits for only integration one peak.")
            if wlen < 20:
                print("Warning: Narrow window length.")
            if idx == 15:
                print(f"No good limits found: {left_limit}, {right_limit}")
        elif peaks_in_range == 0:
            print("No peaks in integration limits detected. Seems odd")
            return 0
        elif deriviative_chromatogram[left_limit - 1] * deriviative_chromatogram[left_limit + 1] < 0 and \
                    deriviative_chromatogram[right_limit - 1] * deriviative_chromatogram[right_limit + 1] < 0:
            # Change of sign in deriviative -> minimum between two peaks reached
            print(f"left: {deriviative_chromatogram[left_limit]:.0f} CoS: {deriviative_chromatogram[left_limit - 1] * deriviative_chromatogram[left_limit + 1] < 0}, right: {deriviative_chromatogram[right_limit]:.0f} CoS: {deriviative_chromatogram[right_limit - 1] * deriviative_chromatogram[right_limit + 1] < 0}")
            break
        elif limit_deriviative > abs(deriviative_chromatogram[left_limit]) and limit_deriviative > abs(deriviative_chromatogram[right_limit]):
            print(f"left: {deriviative_chromatogram[left_limit]:.0f}, right: {deriviative_chromatogram[right_limit]:.0f}")
            break
        else:
            # Deriviative still high, end of peak not reached
            wlen += 10
            # print("Increasing window by 10")
            if wlen > 200:
                print("Warning: Wide window length.")
            if idx == 10:
                print(f"No good limits found: {left_limit}, {right_limit}")

    # print(f"Left limit: {left_limit} deriv {deriviative_chromatogram[left_limit]:.0f}, right limit: {right_limit} \
    # deriv {deriviative_chromatogram[right_limit]:.0f}, wlen: {wlen}")

    area = np.trapezoid(chromatogram[left_limit:right_limit])
    if output_limit:
        return area, left_limit, right_limit
    else:
        return area


def area_peak_range(chroma: npt.NDArray[np.float32],
                    limit_left: str,
                    limit_right: str,
                    ) -> int:
    # limit_left_int: int = strtime2int(limit_left_str)
    # limit_right_int: int = strtime2int(limit_right_str)
    peaks: list[int] = list_peaks(chroma, limit_left=limit_left, limit_right=limit_right)
    areas = []
    for peak in peaks:
        area = integrate_peak(chroma, peak)
        areas.append(area)
    return sum(areas)
