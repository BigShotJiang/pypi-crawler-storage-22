"""Collection of predefined constants (:mod:`tueplots.constants`).

Provides standardised values for colours, line styles, markers,
and figure sizes.
"""
