"""Colour definitions and tools (:mod:`tueplots.constants.color`).

Includes named colours and utilities for working with colour schemes.
"""
