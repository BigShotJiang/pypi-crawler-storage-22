"""Entry point for running tuft as a module: python -m tuft."""

from tuft.cli import main


if __name__ == "__main__":
    main()
