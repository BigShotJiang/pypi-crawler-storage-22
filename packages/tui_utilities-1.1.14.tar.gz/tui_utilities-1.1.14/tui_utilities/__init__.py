from .console import *
from .structure import *
from .validation import *
from .format import *
from .system import *

__all__ = [
    "print", "input", "clear_console", "wait_for_key",
    "header", "menu", "confirm_exit", "separator", "error_message",
    "check_if_empty", "validate_string", "validate_integer", "validate_double",
    "validate_date", "validate_id", "validate_cellphone_number", "validate_email",
    "decimal_format", "id_format", "cellphone_number_format",
    "set_window_title", "maximize_window", "set_locale"
]