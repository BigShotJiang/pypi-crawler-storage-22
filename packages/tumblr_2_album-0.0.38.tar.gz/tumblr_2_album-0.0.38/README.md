Personal use. Will add more details if more than 10 people star the repo.

Tumblr to telegram.