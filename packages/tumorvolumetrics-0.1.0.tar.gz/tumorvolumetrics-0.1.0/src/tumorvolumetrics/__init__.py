from .app import MainApp
__version__ = "0.1.0"

__all__ = ["MainApp"]