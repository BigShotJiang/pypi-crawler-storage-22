---
id: psr-ba9c
status: closed
deps: []
links: []
created: 2026-01-26T23:39:48Z
type: task
priority: 1
assignee: tunahorse1
parent: psr-e147
tags: [tools, constants, ui]
---
# Simplify tool dispatcher and constants

Remove tool categorization and execute all tools in parallel; delete tool type constants and Yolo command.

