---
id: psr-e147
status: closed
deps: []
links: []
created: 2026-01-26T23:39:36Z
type: epic
priority: 1
assignee: tunahorse1
tags: [tools, ui, core]
---
# Remove permission system

Remove tool authorization/confirmation system and related UI/state.

