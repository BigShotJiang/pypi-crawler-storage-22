---
id: tun-8e8a
status: closed
deps: []
links: []
created: 2026-01-26T23:13:14Z
type: task
priority: 0
assignee: tunahorse1
tags: [prompt-migration]
---
# Update prompting __init__.py exports

Remove exports for deleted modules from src/tunacode/core/prompting/__init__.py. Keep resolve_prompt export. Remove SectionLoader, SystemPromptSection, compose_prompt, MAIN_TEMPLATE, LOCAL_TEMPLATE, RESEARCH_TEMPLATE, TEMPLATE_OVERRIDES.

