---
id: tun-c259
status: closed
deps: [tun-fc71]
links: []
created: 2026-01-26T21:23:06Z
type: task
priority: 2
assignee: tunahorse1
parent: tun-4ee0
---
# Remove todo state and protocols

Delete todo state fields, serialization, and TodoProtocol/TodoItem/TodoStatus types from core and types.

