---
id: tun-d98c
status: closed
deps: []
links: []
created: 2026-01-27T22:59:52Z
type: task
priority: 2
assignee: tunahorse1
parent: tun-33a8
tags: [ui, css, styles]
---
# Update layout CSS for chat

Remove #streaming-output rules and add styling for MessageWidget/ChatContainer.

## Acceptance Criteria

layout.tcss reflects new chat layout and no dead streaming-output rules remain.

