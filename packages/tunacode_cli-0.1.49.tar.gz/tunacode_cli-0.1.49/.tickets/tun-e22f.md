---
id: tun-e22f
status: closed
deps: [tun-9b76]
links: []
created: 2026-01-26T21:23:14Z
type: task
priority: 2
assignee: tunahorse1
parent: tun-4ee0
---
# Remove todo tests

Delete tests covering todo tools and todo canonical types.

