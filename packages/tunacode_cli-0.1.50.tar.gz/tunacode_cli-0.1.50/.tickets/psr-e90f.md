---
id: psr-e90f
status: closed
deps: []
links: []
created: 2026-01-26T23:39:44Z
type: task
priority: 1
assignee: tunahorse1
parent: psr-e147
tags: [ui]
---
# Remove confirmation UI and REPL hooks

Strip confirmation UI methods/handlers and simplify textual tool callback.

