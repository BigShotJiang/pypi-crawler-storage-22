---
id: tun-0fe3
status: closed
deps: [tun-ed77, tun-90b6, tun-1160]
links: []
created: 2026-01-26T23:13:17Z
type: task
priority: 2
assignee: tunahorse1
tags: [prompt-migration, docs]
---
# Update prompts.md documentation

Update docs/codebase-map/modules/prompts.md to reference single system_prompt.md file instead of 11 section files. Note that tool prompts remain unchanged.

