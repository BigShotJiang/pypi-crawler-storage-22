---
id: tun-6a86
status: closed
deps: []
links: []
created: 2026-01-26T23:30:03Z
type: epic
priority: 2
assignee: tunahorse1
tags: [ui, commands, docs]
---
# Remove /branch command

Remove the /branch command from UI and docs and update references.

## Acceptance Criteria

- /branch command implementation removed\n- UI welcome list updated\n- README and UI codebase-map updated\n- No other branch-related docs changed

