---
id: tun-9b76
status: closed
deps: [tun-c259]
links: []
created: 2026-01-26T21:23:11Z
type: task
priority: 2
assignee: tunahorse1
parent: tun-4ee0
---
# Remove todo UI integration

Strip todo references from UI commands and clear flow.

