---
id: tun-ddb2
status: closed
deps: []
links: []
created: 2026-01-27T22:59:39Z
type: task
priority: 2
assignee: tunahorse1
parent: tun-33a8
tags: [ui, widgets, streaming]
---
# Add chat widgets

Create MessageWidget + ChatContainer in ui/widgets/chat.py and export from widgets/__init__.py.

## Acceptance Criteria

New widgets provide add_message/start_stream/stream/end_stream API and can mount in UI.

