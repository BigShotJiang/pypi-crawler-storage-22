---
id: tun-ed77
status: closed
deps: [tun-d495, tun-8e8a]
links: []
created: 2026-01-26T23:13:14Z
type: task
priority: 1
assignee: tunahorse1
tags: [prompt-migration]
---
# Delete unused prompt module files

Delete three module files: loader.py, sections.py, templates.py from src/tunacode/core/prompting/

