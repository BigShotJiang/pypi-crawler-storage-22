---
id: psr-53c0
status: closed
deps: []
links: []
created: 2026-01-26T23:39:42Z
type: task
priority: 1
assignee: tunahorse1
parent: psr-e147
tags: [core, types]
---
# Remove authorization state/protocol fields

Drop yolo/tool_ignore/tool_handler fields and authorization protocols from state/types.

