---
id: psr-b89d
status: closed
deps: []
links: []
created: 2026-01-26T23:39:50Z
type: task
priority: 2
assignee: tunahorse1
parent: psr-e147
tags: [docs]
---
# Update docs for permission system removal

Update codebase map docs to reflect removal of authorization system.

