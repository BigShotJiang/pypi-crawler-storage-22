---
id: t-6f0e
status: closed
deps: [t-e5bf]
links: []
created: 2026-01-26T07:32:47Z
type: task
priority: 2
parent: t-6162
tags: [core, state]
---
# Integrate IndexingService into StateManager

Add indexing_service property to StateManager in core/state.py.

## Acceptance Criteria

StateManager.indexing_service is available.

