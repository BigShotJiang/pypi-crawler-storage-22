---
id: tun-0db4
status: closed
deps: [tun-c2f8]
links: []
created: 2026-01-27T20:18:49Z
type: task
priority: 1
parent: tun-c2f8
tags: [lsp, removal]
---
# Delete core/lsp_status.py facade


## Notes

**2026-01-27T20:18:52Z**

Remove src/tunacode/core/lsp_status.py facade.

Acceptance: File deleted, ui/resource_bar.py updated to remove LSP indicator or show 'not configured' state
