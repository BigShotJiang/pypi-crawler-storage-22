---
id: tun-48fe
status: closed
deps: [tun-979a]
links: []
created: 2026-01-27T06:20:45Z
type: task
priority: 1
tags: [architecture, types]
---
# Update 17 core files to import from core/types/

Change imports in all 17 core files from tunacode.types to tunacode.core.types for moved types

## Acceptance Criteria

All imports updated, ruff check passes

