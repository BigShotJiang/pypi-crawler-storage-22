---
id: tun-dc79
status: closed
deps: []
links: []
created: 2026-01-26T23:13:14Z
type: task
priority: 0
assignee: tunahorse1
tags: [prompt-migration]
---
# Create system_prompt.md from section files

Create src/tunacode/prompts/system_prompt.md by concatenating content from all 11 section files in MAIN_TEMPLATE order with ==== separators. Remove XML wrapper tags and keep only the inner content.

