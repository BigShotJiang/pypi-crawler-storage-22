"""Prompting engine for dynamic placeholder resolution."""

from tunacode.core.prompting.prompting_engine import resolve_prompt

__all__ = [
    "resolve_prompt",
]
