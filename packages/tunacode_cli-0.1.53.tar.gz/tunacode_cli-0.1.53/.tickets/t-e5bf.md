---
id: t-e5bf
status: closed
deps: []
links: []
created: 2026-01-26T07:32:45Z
type: task
priority: 2
parent: t-6162
tags: [core, indexing]
---
# Create core/indexing_service.py

Implement IndexingService class to handle two-phase strategy logic and threading, using a callback for status updates.

## Acceptance Criteria

IndexingService exists and can perform indexing without direct UI dependencies.

