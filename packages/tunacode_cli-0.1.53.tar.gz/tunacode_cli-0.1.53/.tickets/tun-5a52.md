---
id: tun-5a52
status: closed
deps: [tun-8d48, tun-a63b]
links: []
created: 2026-01-26T22:46:13Z
type: task
priority: 2
assignee: tunahorse1
tags: [deletion, cleanup, core]
---
# Delete delegation_tools.py and research_agent.py

Remove src/tunacode/core/agents/delegation_tools.py and research_agent.py, remove commented import from agent_config.py

## Acceptance Criteria

Both files deleted, imports raise errors, no commented code remains

