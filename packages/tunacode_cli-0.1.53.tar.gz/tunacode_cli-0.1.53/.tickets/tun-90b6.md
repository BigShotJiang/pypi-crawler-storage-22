---
id: tun-90b6
status: closed
deps: [tun-dc79]
links: []
created: 2026-01-26T23:13:14Z
type: task
priority: 1
assignee: tunahorse1
tags: [prompt-migration]
---
# Delete prompts/sections/ directory

Delete entire src/tunacode/prompts/sections/ directory containing 11 XML section files

