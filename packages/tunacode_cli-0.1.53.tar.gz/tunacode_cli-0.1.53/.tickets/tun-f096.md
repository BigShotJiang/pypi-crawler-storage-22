---
id: tun-f096
status: closed
deps: [tun-48fe]
links: []
created: 2026-01-27T06:20:46Z
type: task
priority: 2
tags: [cleanup, types]
---
# Delete dead code (CommandContext, ProcessRequestCallback)

Remove unused CommandContext from types/dataclasses.py and ProcessRequestCallback from types/callbacks.py

## Acceptance Criteria

Dead code removed, no references remain

