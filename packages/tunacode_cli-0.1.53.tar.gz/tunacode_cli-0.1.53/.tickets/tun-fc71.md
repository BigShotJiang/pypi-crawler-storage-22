---
id: tun-fc71
status: closed
deps: []
links: []
created: 2026-01-26T21:23:03Z
type: task
priority: 2
assignee: tunahorse1
parent: tun-4ee0
---
# Remove todo tools and prompts

Delete todo tools (todowrite/todoread/todoclear) and their prompt assets; remove registration from tool list.

