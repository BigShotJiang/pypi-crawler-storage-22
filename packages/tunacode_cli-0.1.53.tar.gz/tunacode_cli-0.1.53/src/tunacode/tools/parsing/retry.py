"""Retry utilities for handling transient failures."""

import asyncio
import functools
import json
from collections.abc import Callable
from typing import Any


def retry_on_json_error(
    max_retries: int = 10,
    base_delay: float = 0.1,
    max_delay: float = 5.0,
) -> Callable:
    """Decorator to retry function calls that fail with JSON parsing errors.

    Implements exponential backoff with configurable parameters.

    Args:
        max_retries: Maximum number of retry attempts (default: 10)
        base_delay: Initial delay between retries in seconds (default: 0.1)
        max_delay: Maximum delay between retries in seconds (default: 5.0)

    Returns:
        Decorated function that retries on JSONDecodeError
    """

    def _sleep_sync(delay: float) -> None:
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            asyncio.run(asyncio.sleep(delay))
            return
        raise RuntimeError("Sync JSON retry cannot sleep in a running event loop.")

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            last_exception = None

            for attempt in range(max_retries + 1):
                try:
                    return await func(*args, **kwargs)
                except json.JSONDecodeError as e:
                    last_exception = e

                    if attempt == max_retries:
                        # Final attempt failed
                        raise

                    # Calculate delay with exponential backoff
                    delay = min(base_delay * (2**attempt), max_delay)

                    await asyncio.sleep(delay)

            # Should never reach here, but just in case
            if last_exception:
                raise last_exception

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            last_exception = None

            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except json.JSONDecodeError as e:
                    last_exception = e

                    if attempt == max_retries:
                        # Final attempt failed
                        raise

                    # Calculate delay with exponential backoff
                    delay = min(base_delay * (2**attempt), max_delay)

                    _sleep_sync(delay)

            # Should never reach here, but just in case
            if last_exception:
                raise last_exception

        # Return appropriate wrapper based on function type
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper

    return decorator


def retry_json_parse(
    json_string: str,
    max_retries: int = 10,
    base_delay: float = 0.1,
    max_delay: float = 5.0,
) -> Any:
    """Parse JSON with automatic retry on failure.

    Args:
        json_string: JSON string to parse
        max_retries: Maximum number of retry attempts
        base_delay: Initial delay between retries in seconds
        max_delay: Maximum delay between retries in seconds

    Returns:
        Parsed JSON object

    Raises:
        json.JSONDecodeError: If parsing fails after all retries
    """

    @retry_on_json_error(
        max_retries=max_retries,
        base_delay=base_delay,
        max_delay=max_delay,
    )
    def _parse() -> Any:
        return json.loads(json_string)

    return _parse()


async def retry_json_parse_async(
    json_string: str,
    max_retries: int = 10,
    base_delay: float = 0.1,
    max_delay: float = 5.0,
) -> Any:
    """Asynchronously parse JSON with automatic retry on failure.

    Args:
        json_string: JSON string to parse
        max_retries: Maximum number of retry attempts
        base_delay: Initial delay between retries in seconds
        max_delay: Maximum delay between retries in seconds

    Returns:
        Parsed JSON object

    Raises:
        json.JSONDecodeError: If parsing fails after all retries
    """

    @retry_on_json_error(
        max_retries=max_retries,
        base_delay=base_delay,
        max_delay=max_delay,
    )
    async def _parse() -> Any:
        return json.loads(json_string)

    return await _parse()
