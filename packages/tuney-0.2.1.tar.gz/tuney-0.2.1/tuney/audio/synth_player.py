from __future__ import annotations

import dataclasses as dc
import time
from contextlib import suppress
from functools import cached_property
from threading import Thread

import numpy as np

from ..scale.scale import NoteNumber, Scale
from ..scale.twelve_tet import TWELVE_TET
from . import Data, Number
from . import oscillator as osc
from .device_config import DeviceConfig
from .player import Player

INTENSITY = 0.1
FADE = 0  # 0x40000
OSC = osc.sawtooth


# TODO: relieve the tension between human units (frequency, time) and sample units.
@dc.dataclass(frozen=True)
class Sound:
    period: Number = 0x100
    intensity: Number = INTENSITY
    fade_in_samples: Number = 0x1000
    fade_out_samples: Number = 0x1000


@dc.dataclass
class OscillatorPlayer(Player):
    sound: Sound = dc.field(default_factory=Sound)
    oscillator: osc.Oscillator = OSC

    _stopping: bool = False

    #: Records the the frame we started to fade out.
    _fade_frame: Number | None = None

    def stop(self) -> None:
        if self.sound.fade_out_samples > 0:
            self._stopping = True
        else:
            super().stop()

    def _fill(self, out: Data) -> bool:
        start = self.frame_count % self.sound.period
        end = start + len(out)
        ratio = self.oscillator.period / self.sound.period
        wave = np.linspace(start * ratio, end * ratio, len(out))
        wave = self.oscillator.function(wave, out=wave)

        intensity = self.sound.intensity
        with suppress(ValueError):
            # Scale up from [-1, 1] for int types only
            intensity *= np.iinfo(out.dtype).max
        wave *= intensity

        fade_in = self.sound.fade_in_samples
        if self.frame_count < fade_in and not self._stopping:
            _fade(wave, self.frame_count / fade_in, len(out) / fade_in)

        elif self._stopping:
            if self._fade_frame is None:
                # Account for the case when we fade out before we've faded in
                offset = max(0.0, fade_in - self.frame_count)
                self._fade_frame = self.frame_count - offset

            fade_out = self.sound.fade_out_samples
            elapsed = self.frame_count - self._fade_frame
            if (start := 1 - elapsed / fade_out) <= 0:
                super().stop()
                return False

            _fade(wave, start, -len(out) / fade_out)

        wave = wave.reshape((len(wave), 1))
        out[:] = np.asarray(wave, dtype=out.dtype)
        return True


@dc.dataclass(frozen=True)
class OscillatorController:
    config: DeviceConfig = dc.field(default_factory=DeviceConfig)
    oscillator: osc.Oscillator = OSC
    players: dict[int, OscillatorPlayer] = dc.field(default_factory=dict)
    scale: Scale = TWELVE_TET
    start_note_name: str = 'C3'

    def note(self, note_number: NoteNumber, is_press: bool) -> bool:
        return self.start(note_number) if is_press else self.stop(note_number)

    def start(self, note_number: NoteNumber) -> bool:
        if note_number in self.players:
            return False
        frequency = self.scale.tuning(note_number + self.start_note_number)
        period = (self.config.samplerate or 48_000) / frequency
        op = OscillatorPlayer(
            config=self.config, oscillator=self.oscillator, sound=Sound(period)
        )
        Thread(target=op.run).start()
        self.players[note_number] = op
        return True

    def stop(self, note_number: NoteNumber) -> bool:
        if (op := self.players.pop(note_number, None)) is not None:
            op.stop()
        return bool(op)

    def stop_all(self) -> None:
        for player in self.players.values():
            player.stop()
        self.players.clear()

    @cached_property
    def start_note_number(self) -> int:
        return self.scale.name_to_number(self.start_note_name)


def _clamp(x: Number) -> Number:
    return max(0.0, min(1.0, x))


def _fade(wave: Data, start: Number, length: Number) -> None:
    wave *= np.linspace(_clamp(start), _clamp(start + length), len(wave))


def run_many_notes():
    oc = OscillatorController()
    DT = 0.2

    stack = []
    o1 = 'C4', 'E4', 'D5', 'Eb3', 'G3', 'C3', 'E3', 'D4', 'Eb2', 'G2'
    o2 = 'C2', 'E2', 'D3', 'Eb1', 'G1', 'C1', 'E1', 'D2', 'Eb0', 'G0'

    for name in (o1 + o2)[0]:
        stack.append(note := TWELVE_TET.name_to_number(name))
        if not oc.start(note):
            print('oops', name)
        time.sleep(DT)

    while stack:
        if not oc.stop(note := stack.pop()):
            print('oops off', note)
        time.sleep(DT / 2)


if __name__ == '__main__':
    run_many_notes()
