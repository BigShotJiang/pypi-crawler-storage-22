from turbine_lib.binarydata import BinaryData
from turbine_lib.subfile import Subfile
from turbine_lib.subfiledata import SubfileData


class JPG:
    """Marker class for JPG file type"""
    pass


class SubfileJPG(Subfile):
    """Python translation of the C++ Subfile<JPG> template specialization"""

    @staticmethod
    def build_for_export(file_data):
        """
        Build data for export from JPG file
        :param file_data: BinaryData with file data
        :return: SubfileData with processed data
        """
        result = SubfileData()
        result.binary_data = file_data.cut_data(24)
        result.options["ext"] = ".jpg"
        return result

    @staticmethod
    def build_for_import(old_data, data):
        """
        Build data for import to JPG file
        :param old_data: BinaryData with old data
        :param data: SubfileData with new data
        :return: BinaryData with processed data
        """
        file_size = BinaryData.from_number(4, data.binary_data.size())
        return old_data.cut_data(0, 20) + file_size + data.binary_data