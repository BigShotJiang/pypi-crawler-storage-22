# TurboML: High-Performance Machine Learning

TurboML is a blazing fast Machine Learning and Math library for Python, written in **Rust**.
It uses SIMD (AVX2) instructions, Parallel Processing, and Memory Optimization to run **200x-400x faster** than standard Python/NumPy for specific workloads.

## 🚀 Features

* **TurboMatrix:** 245x Faster Matrix Multiplication using hardware acceleration (AVX2).
* **TurboSolver:** 170x Faster Linear Regression Training using parallel gradient descent.
* **TurboArray:** Memory-efficient array storage (uses 67% less RAM than Python lists).
* **Universal Accelerator:** Generic parallel processing for custom heavy loops (O(N^6) complexity support).

## 📦 Installation

```bash
pip install turbo_ml_dhakshin