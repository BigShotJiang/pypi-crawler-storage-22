# CHANGELOG

<!-- version list -->

## v1.3.5 (2026-02-16)

### Bug Fixes

- Fix build command to use apt-get to install rust, instead of curl
  ([#15](https://github.com/BrightNight-Energy/turbodiff/pull/15),
  [`024f863`](https://github.com/BrightNight-Energy/turbodiff/commit/024f863df6d8e8c60d01bf9864f74c8910e97edf))


## v1.3.4 (2026-02-16)

### Bug Fixes

- Fix build command to include adding rust
  ([#14](https://github.com/BrightNight-Energy/turbodiff/pull/14),
  [`8219fed`](https://github.com/BrightNight-Energy/turbodiff/commit/8219fed845f55d5db38988486ad018c8974f394f))


## v1.3.3 (2026-02-16)

### Bug Fixes

- Add build command to semantic release
  ([#13](https://github.com/BrightNight-Energy/turbodiff/pull/13),
  [`f29f221`](https://github.com/BrightNight-Energy/turbodiff/commit/f29f22106de95ce10a4c66078b94cfa7cbb4a769))


## v1.3.2 (2026-02-16)

### Bug Fixes

- Remove --locked from crates publish command
  ([#12](https://github.com/BrightNight-Energy/turbodiff/pull/12),
  [`0c7b720`](https://github.com/BrightNight-Energy/turbodiff/commit/0c7b7207f6a261f6df1df4e68d9345fb9b96d133))


## v1.3.1 (2026-02-16)

### Bug Fixes

- Add crates publishing to CI release workflow
  ([#11](https://github.com/BrightNight-Energy/turbodiff/pull/11),
  [`be5334e`](https://github.com/BrightNight-Energy/turbodiff/commit/be5334eb138048bd9edf9fab36f7e9ee1b039dd7))


## v1.3.0 (2026-02-16)

### Features

- Add pretty formatter and set support for DeepDiff
  ([#10](https://github.com/BrightNight-Energy/turbodiff/pull/10),
  [`9d8e2f8`](https://github.com/BrightNight-Energy/turbodiff/commit/9d8e2f804e9fa776097d17083c56ca404787df56))


## v1.2.1 (2026-02-13)

### Bug Fixes

- **ci**: Build from release tag ([#9](https://github.com/BrightNight-Energy/turbodiff/pull/9),
  [`eaedf29`](https://github.com/BrightNight-Energy/turbodiff/commit/eaedf296b149a917033f626db4b88f0e232fd6a6))


## v1.2.0 (2026-02-13)

### Features

- Broaden DeepDiff python input support
  ([#8](https://github.com/BrightNight-Energy/turbodiff/pull/8),
  [`62e27ae`](https://github.com/BrightNight-Energy/turbodiff/commit/62e27ae51a35477739bb73276f76ba79fa86109f))


## v1.1.2 (2026-02-12)

### Bug Fixes

- Remove uv from release step ([#7](https://github.com/BrightNight-Energy/turbodiff/pull/7),
  [`7a7c832`](https://github.com/BrightNight-Energy/turbodiff/commit/7a7c832c408b95fcd9fb66494d82707a1e208f34))


## v1.1.1 (2026-02-12)

### Bug Fixes

- Add wheels to package ([#6](https://github.com/BrightNight-Energy/turbodiff/pull/6),
  [`c1d70c3`](https://github.com/BrightNight-Energy/turbodiff/commit/c1d70c33060ab1bfd843276df4b39ef5fa33d51b))


## v1.1.0 (2026-02-11)

### Chores

- Add to tests ([#3](https://github.com/BrightNight-Energy/turbodiff/pull/3),
  [`8d054e0`](https://github.com/BrightNight-Energy/turbodiff/commit/8d054e0a3ea8d6d286f2570478d8237d66e84d75))

- Fix to release branch protections ([#5](https://github.com/BrightNight-Energy/turbodiff/pull/5),
  [`d490890`](https://github.com/BrightNight-Energy/turbodiff/commit/d490890a1397c338cbd3e9e57bab188ae3fd5ff3))

### Features

- Add limited support for numpy ([#4](https://github.com/BrightNight-Energy/turbodiff/pull/4),
  [`4918e80`](https://github.com/BrightNight-Energy/turbodiff/commit/4918e8089f85ed44e38e6c44cf439fca0e2904c2))


## v1.0.0 (2026-02-11)

- Initial Release
