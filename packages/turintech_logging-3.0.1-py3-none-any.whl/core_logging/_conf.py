# ───────────────────────────────────────────────────── imports ────────────────────────────────────────────────────── #

from pydantic import Field

from core_common_configuration.base_conf_env import BaseConfEnv
from core_logging.types import LogLevel, LogSink


class LoggingConf(BaseConfEnv):
    """Pydantic configuration model for structured logging.

    Loads from environment variables (with optional prefix) or can be
    constructed directly. All fields have defaults so no env file is required.

    Fields:
        level: Log level. Case-insensitive, normalised to uppercase on load.
        sink: Output format — "json" for machine-readable, "console" for human-readable.
        verbose_errors: When True and sink is "console", includes full tracebacks
            and diagnostic info. Should not be enabled in production.
    """

    level: LogLevel = Field(default="DEBUG", description="Log level.")
    sink: LogSink = Field(default="console", description="Log sink.")
    verbose_errors: bool = Field(
        default=False,
        description="Verbose errors. If True and console sink is used, include full exception traceback "
        "in the log along with diagnostic information. DO NOT USE IN PRODUCTION.",
    )
