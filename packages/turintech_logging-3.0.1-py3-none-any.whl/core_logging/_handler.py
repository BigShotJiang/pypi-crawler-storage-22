# ───────────────────────────────────────────────────── imports ────────────────────────────────────────────────────── #
from __future__ import annotations

import logging
import sys
import typing
from types import FrameType

from loguru import logger

from core_logging._conf import LoggingConf
from core_logging._json import json_formatter, json_patcher
from core_logging.types import LogLevel

if typing.TYPE_CHECKING:
    from loguru import Record


# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #
#                                                       Types                                                         #
# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #


class _HandlerConfigRequired(typing.TypedDict):
    sink: typing.Any
    level: LogLevel


class HandlerConfig(_HandlerConfigRequired, total=False):
    format: str | typing.Callable[[Record], str]
    filter: str | typing.Callable[[Record], bool] | dict[str | None, str | int | bool] | None
    colorize: bool | None
    serialize: bool
    backtrace: bool
    diagnose: bool
    enqueue: bool
    catch: bool


class ConfigureKwargs(typing.TypedDict, total=False):
    handlers: list[HandlerConfig]
    patcher: typing.Callable[[Record], None]


# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #
#                                                Module Implementation                                                 #
# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #


class InterceptHandler(logging.Handler):
    """stdlib logging.Handler that forwards log records to loguru.

    Attach this to any stdlib logger to route its output through the
    structured logging pipeline. The original logger name is preserved
    as a "stdlib_logger" field in the loguru context.
    """

    def emit(self, record: logging.LogRecord) -> None:
        # Get corresponding Loguru level if it exists
        try:
            level = logger.level(record.levelname).name
        except ValueError:
            level = record.levelno

        # Find caller from where originated the logged message
        frame: FrameType | None = logging.currentframe()
        depth: int = 2
        while frame and frame.f_code.co_filename == logging.__file__:
            frame = frame.f_back
            depth += 1

        with logger.contextualize(stdlib_logger=record.name):
            logger.opt(depth=depth, exception=record.exc_info).log(level, record.getMessage())


def bootstrap_logging(
    logging_conf: LoggingConf,
    loggers_to_intercept: typing.Sequence[str] = (),
    *,
    log_filter: str | typing.Callable[[Record], bool] | dict[str | None, str | int | bool] | None = None,
) -> None:
    """Configure loguru and stdlib logging in one call.

    Sets up a single loguru handler writing to stderr in either JSON or
    human-readable format. Suppresses all stdlib logging by default and
    optionally bridges named stdlib loggers into loguru via InterceptHandler.

    Should be called once at application startup, before any log messages
    are emitted. Since enqueue=True is set, call `await logger.complete()`
    before shutdown to flush any pending log messages.

    Args:
        logging_conf: Logging configuration (level, sink, verbose_errors).
        loggers_to_intercept: stdlib logger names to bridge into loguru
            (e.g. ["uvicorn", "sqlalchemy"]). Each gets an InterceptHandler
            attached with propagation disabled.
        log_filter: Optional filter passed to loguru's handler. Can be a module
            name (str), a callable `(record) -> bool`, or a dict mapping
            logger names to minimum levels. See `loguru.logger.add()`.
    """
    log_sink = logging_conf.sink
    log_level = logging_conf.level

    # Base configuration shared by all sinks
    base_handler_config: HandlerConfig = {
        "sink": sys.stderr,
        "enqueue": True,
        "level": log_level,
    }

    # Sink-specific overrides
    sink_overrides: dict[str, HandlerConfig] = {
        "json": {
            "sink": sys.stderr,
            "level": log_level,
            "format": json_formatter,
            "backtrace": False,
            "diagnose": False,
            "colorize": False,
        },
        "console": {
            "sink": sys.stderr,
            "level": log_level,
            "backtrace": logging_conf.verbose_errors,
            "diagnose": logging_conf.verbose_errors,
            "colorize": True,
        },
    }

    # Merge base config with sink-specific config
    handler_config: HandlerConfig = {**base_handler_config, **sink_overrides[log_sink]}
    if log_filter is not None:
        handler_config["filter"] = log_filter

    # Configure logger
    configure_kwargs: ConfigureKwargs = {"handlers": [handler_config]}
    if log_sink == "json":
        configure_kwargs["patcher"] = json_patcher

    logger.configure(**configure_kwargs)  # type: ignore[arg-type]

    # Suppress all standard library logging, intercept only the loggers we specify
    logging.basicConfig(handlers=[logging.NullHandler()], level=0, force=True)
    for logger_name in loggers_to_intercept:
        logger_to_intercept = logging.getLogger(logger_name)
        logger_to_intercept.handlers = [InterceptHandler()]
        logger_to_intercept.propagate = False
