from __future__ import annotations

import json
import traceback
import typing
from datetime import date, datetime
from decimal import Decimal
from uuid import UUID

if typing.TYPE_CHECKING:
    from loguru import Record


def _json_default(obj: object) -> object:
    """Fallback serializer for types that json.dumps cannot handle natively."""
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, date):
        return obj.isoformat()
    if isinstance(obj, UUID):
        return str(obj)
    if isinstance(obj, Decimal):
        return str(obj)
    if isinstance(obj, (set, frozenset)):
        return sorted(obj, key=str)
    if isinstance(obj, bytes):
        return obj.decode("utf-8", errors="replace")
    return str(obj)


def json_serialize(record: Record) -> str:
    """Serialize a log record to a JSON string."""
    # Extras go first so structural fields can never be clobbered
    subset: dict[str, typing.Any] = {
        **(record["extra"] or {}),
        "time": record["time"].isoformat(),
        "level": record["level"].name,
        "message": record["message"],
    }

    if record["exception"]:
        type, value, tb = record["exception"]
        traceback_lines = traceback.format_exception(type, value, tb)
        traceback_string = "".join(traceback_lines)
        subset["exception"] = {
            "type": type.__name__ if type is not None else None,
            "value": str(value),
            "traceback": traceback_string,
        }
        if value is not None and getattr(value, "__notes__", None):
            subset["exception"]["notes"] = value.__notes__

    return json.dumps(subset, default=_json_default)


def json_patcher(record: Record) -> None:
    """Patcher for JSON log records."""
    record["serialized"] = json_serialize(record)  # type: ignore


def json_formatter(_record: Record) -> str:
    """Formatter for JSON log records."""
    return "{serialized}\n"
