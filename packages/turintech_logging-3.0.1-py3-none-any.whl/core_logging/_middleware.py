from __future__ import annotations

import time
from typing import Callable

from loguru import logger
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response

ExtraContextCallback = Callable[[Request], dict[str, object]]


class LoggerContextMiddleware(BaseHTTPMiddleware):
    """Binds request metadata to the loguru context for the lifetime of each request.

    Does not emit any log messages itself. Any log emitted during the request
    (by your code or by RequestLoggerMiddleware) will automatically include
    these extra fields in structured (JSON) output.

    Default context (always included):
        - method    (str)       — HTTP method, e.g. "GET"
        - path      (str)       — URL path, e.g. "/api/v1/tasks"
        - query     (str)       — query string, e.g. "page=2&limit=10"

    Pass `extra_context` to add arbitrary fields from the request, e.g.

        ```
        LoggerContextMiddleware(
            app,
            extra_context=lambda r: {
                "user_id": r.headers.get("X-User-Id"),
                "tenant_id": r.headers.get("X-Tenant-Id"),
            },
        )
        ```

    Stack this before RequestLoggerMiddleware so request logs also carry the context.
    """

    def __init__(self, app, extra_context: ExtraContextCallback | None = None):
        super().__init__(app)
        self._extra_context = extra_context

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        ctx: dict[str, object] = {
            "method": request.method,
            "path": request.url.path,
            "query": request.url.query,
        }
        if self._extra_context:
            ctx.update(self._extra_context(request))

        with logger.contextualize(**ctx):
            return await call_next(request)


class RequestLoggerMiddleware(BaseHTTPMiddleware):
    """Emits structured log messages at request start and completion/failure.

    Reads from the incoming request:
        - request.method
        - request.url.path
        - request.url.query

    Emits two INFO logs per successful request:
        1. "Starting request GET /path"
        2. "Request GET /path returned 200 in 0.0123s"
           with extra fields: status_code (int), execution_time (str)

    On unhandled exception, emits one ERROR log instead of (2):
        "Request GET /path failed after 0.0123s"
        with extra fields: execution_time (str), exception (dict)
    """

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        method = request.method
        path = request.url.path
        query = request.url.query
        url = f"{path}?{query}" if query else path

        start = time.perf_counter()
        logger.info(f"Starting request {method} {url}")

        try:
            response = await call_next(request)
        except Exception:
            elapsed = f"{time.perf_counter() - start:.4f}s"
            logger.exception(
                f"Request {method} {url} failed after {elapsed}",
                execution_time=elapsed,
            )
            raise

        elapsed = f"{time.perf_counter() - start:.4f}s"
        logger.info(
            f"Request {method} {url} returned {response.status_code} in {elapsed}",
            status_code=response.status_code,
            execution_time=elapsed,
        )
        return response
