"""Public type aliases for core_logging."""

from __future__ import annotations

import typing

from pydantic import BeforeValidator

__all__ = [
    "LogLevel",
    "LogSink",
]

_LogLevelLiteral = typing.Literal["TRACE", "DEBUG", "INFO", "SUCCESS", "WARNING", "ERROR", "CRITICAL"]
LogLevel: typing.TypeAlias = typing.Annotated[
    _LogLevelLiteral, BeforeValidator(lambda v: v.upper() if isinstance(v, str) else v)
]
LogSink: typing.TypeAlias = typing.Literal["json", "console"]
