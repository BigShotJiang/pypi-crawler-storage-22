# Engelliler Sarayı - Türkçe Python Kütüphanesi

Python programlama dilinin tüm fonksiyonlarını, sözdizimini ve kütüphanelerini Türkçe olarak sunan kapsamlı bir kütüphane.

## Kurulum

```bash
pip install turkce-python-engelliler-sarayi
```

## v0.0.2 Yenilikleri

- ✅ **Tarih ve Zaman**: `simdi()`, `bugun()`, `yas_hesapla()`, `turkce_tarih()`
- ✅ **Web İşlemleri**: `get_istegi()`, `post_istegi()`, `dosya_indir()`
- ✅ **Sistem İşlemleri**: `isletim_sistemi()`, `komut_calistir()`, `disk_kullanimi()`
- ✅ **Gelişmiş Veri Tipleri**: Türkçe sınıflar ve metodlar
- ✅ **Hata Düzeltmeleri**: v0.0.1'deki eksik fonksiyonlar eklendi

## Kullanım

```python
from engelliler_sarayi import *

# Temel fonksiyonlar
yazdir("Merhaba Dünya!")
sayi = tam_sayi("42")
liste_sayilar = [1, 2, 3, 4, 5]
yazdir(f"Toplam: {topla(liste_sayilar)}")

# Tarih ve zaman
yazdir(f"Bugün: {turkce_tarih(bugun())}")
yazdir(f"Şu an: {simdi()}")

# Matematik
yazdir(f"5'in karesi: {kare(5)}")
yazdir(f"17 asal mı: {asal_mi(17)}")

# Sistem bilgileri
yazdir(f"İşletim sistemi: {isletim_sistemi()}")
yazdir(f"Python sürümü: {python_surumu()}")

# Web işlemleri (internet bağlantısı gerekli)
if internet_baglantisi_kontrol():
    sonuc = get_istegi("https://api.github.com")
    yazdir(f"API çağrısı: {sonuc['durum_kodu']}")
```

## Özellikler

- ✅ Temel Python fonksiyonlarının Türkçe karşılıkları
- ✅ Kontrol yapıları (if, for, while) için Türkçe anahtar kelimeler
- ✅ Veri tipleri ve işlemleri
- ✅ Dosya işlemleri
- ✅ Hata yönetimi

## Sürüm Geçmişi

### v0.0.1
- İlk sürüm
- Temel fonksiyonlar eklendi
- Türkçe anahtar kelimeler desteği

## Lisans

MIT License