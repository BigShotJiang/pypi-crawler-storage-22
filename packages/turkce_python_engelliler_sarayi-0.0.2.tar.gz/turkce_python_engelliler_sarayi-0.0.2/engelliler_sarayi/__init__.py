"""
Engelliler Sarayı - Türkçe Python Kütüphanesi
Python'u Türkçe olarak kullanmanızı sağlayan kapsamlı kütüphane
"""

__version__ = "0.0.2"
__author__ = "Engelliler Sarayı Geliştirici"

# Temel fonksiyonları içe aktar
from .temel import *
from .veri_tipleri import *
from .dosya_islemleri import *
from .matematik import *
from .tarih_zaman import *
from .web_islemleri import *
from .sistem_islemleri import *

# Türkçe anahtar kelimeler için makrolar
import builtins

# Temel fonksiyonların Türkçe karşılıkları
yazdir = print
uzunluk = len
tip = type
girdi = input
aralik = range
liste = list
sozluk = dict
demet = tuple
kume = set

# Veri tipi dönüşümleri
tam_sayi = int
ondalik_sayi = float
metin = str
mantiksal = bool

# Temel matematik fonksiyonları
mutlak = abs
en_buyuk = max
en_kucuk = min
topla = sum
yuvarla = round

# Sıralama ve filtreleme
sirala = sorted
def filtrele(fonksiyon, dizi):
    return list(filter(fonksiyon, dizi))
def haritala(fonksiyon, dizi):
    return list(map(fonksiyon, dizi))

# Mantıksal operatörler
ve = lambda x, y: x and y
veya = lambda x, y: x or y
degil = lambda x: not x

# Karşılaştırma operatörleri için yardımcı fonksiyonlar
def esittir(a, b):
    return a == b

def esit_degildir(a, b):
    return a != b

def buyuktur(a, b):
    return a > b

def kucuktur(a, b):
    return a < b

def buyuk_esittir(a, b):
    return a >= b

def kucuk_esittir(a, b):
    return a <= b

# Kontrol yapıları için yardımcı sınıflar
class EgerYapisi:
    def __init__(self, kosul):
        self.kosul = kosul
        self.calistirildi = False
    
    def __enter__(self):
        if self.kosul and not self.calistirildi:
            self.calistirildi = True
            return True
        return False
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

def eger(kosul):
    return EgerYapisi(kosul)

# Döngü yapıları
def icin(dizi):
    return iter(dizi)

def iken(kosul):
    class IkenDongusu:
        def __init__(self, kosul_func):
            self.kosul_func = kosul_func
        
        def __iter__(self):
            return self
        
        def __next__(self):
            if callable(self.kosul_func):
                if self.kosul_func():
                    return True
                else:
                    raise StopIteration
            else:
                if self.kosul_func:
                    return True
                else:
                    raise StopIteration
    
    return IkenDongusu(kosul)

# Hata yönetimi
class TurkceHata(Exception):
    pass

def hata_firlat(mesaj):
    raise TurkceHata(mesaj)

# Dosya işlemleri kısayolları
def dosya_ac(dosya_yolu, mod="r", kodlama="utf-8"):
    return open(dosya_yolu, mod, encoding=kodlama)

def dosya_oku(dosya_yolu, kodlama="utf-8"):
    with open(dosya_yolu, "r", encoding=kodlama) as f:
        return f.read()

def dosya_yaz(dosya_yolu, icerik, kodlama="utf-8"):
    with open(dosya_yolu, "w", encoding=kodlama) as f:
        f.write(icerik)

# Tüm fonksiyonları dışa aktar
__all__ = [
    # Temel fonksiyonlar
    'yazdir', 'uzunluk', 'tip', 'girdi', 'aralik', 'liste', 'sozluk', 'demet', 'kume',
    'tam_sayi', 'ondalik_sayi', 'metin', 'mantiksal', 'mutlak', 'en_buyuk', 'en_kucuk',
    'topla', 'yuvarla', 'sirala', 'filtrele', 'haritala',
    've', 'veya', 'degil', 'esittir', 'esit_degildir', 'buyuktur', 'kucuktur',
    'buyuk_esittir', 'kucuk_esittir', 'eger', 'icin', 'iken', 'TurkceHata',
    'hata_firlat', 'dosya_ac', 'dosya_oku', 'dosya_yaz',
    
    # Matematik fonksiyonları
    'kare', 'karekok', 'kup', 'us_alma', 'sinus', 'kosinus', 'tanjant',
    'rastgele_sayi', 'rastgele_tam_sayi', 'ortalama', 'medyan',
    'faktoriyel', 'kombinasyon', 'permutasyon', 'asal_mi',
    'dereceden_radyana', 'radyandan_dereceye', 'logaritma', 'tavan', 'taban',
    
    # Veri tipleri
    'metin_olustur', 'liste_olustur', 'sozluk_olustur', 'kume_olustur',
    'TurkceMetin', 'TurkceListe', 'TurkceSozluk', 'TurkceKume',
    
    # Tarih ve zaman
    'simdi', 'bugun', 'su_an', 'bekle', 'tarih_olustur', 'zaman_olustur',
    'tarih_zaman_olustur', 'tarih_formatla', 'ay_adi', 'gun_adi', 'haftanin_gunu',
    'gun_ekle', 'gun_cikar', 'tarih_farki', 'yas_hesapla', 'turkce_tarih',
    'ZamanOlcer', 'zaman_olcer_olustur',
    
    # Web işlemleri
    'get_istegi', 'post_istegi', 'dosya_indir', 'json_api_cagir',
    'web_sayfasi_oku', 'internet_baglantisi_kontrol',
    
    # Sistem işlemleri
    'isletim_sistemi', 'sistem_mimarisi', 'python_surumu', 'bilgisayar_adi',
    'kullanici_adi', 'komut_calistir', 'disk_kullanimi', 'bellek_kullanimi',
    'sistem_bilgileri', 'windows_mi', 'linux_mi', 'macos_mi'
]