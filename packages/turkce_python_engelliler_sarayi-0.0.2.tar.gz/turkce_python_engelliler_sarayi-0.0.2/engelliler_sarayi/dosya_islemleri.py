"""
Dosya ve dizin işlemleri için Türkçe fonksiyonlar
"""

import os
import shutil
import json
import csv
from pathlib import Path

# Temel dosya işlemleri
def dosya_ac(dosya_yolu, mod="r", kodlama="utf-8"):
    """open() fonksiyonunun Türkçe karşılığı"""
    return open(dosya_yolu, mod, encoding=kodlama)

def dosya_oku(dosya_yolu, kodlama="utf-8"):
    """Dosya içeriğini okuma"""
    try:
        with open(dosya_yolu, "r", encoding=kodlama) as dosya:
            return dosya.read()
    except FileNotFoundError:
        raise FileNotFoundError(f"Dosya bulunamadı: {dosya_yolu}")
    except Exception as e:
        raise Exception(f"Dosya okuma hatası: {e}")

def dosya_yaz(dosya_yolu, icerik, kodlama="utf-8"):
    """Dosyaya içerik yazma"""
    try:
        with open(dosya_yolu, "w", encoding=kodlama) as dosya:
            dosya.write(icerik)
        return True
    except Exception as e:
        raise Exception(f"Dosya yazma hatası: {e}")

def dosya_ekle(dosya_yolu, icerik, kodlama="utf-8"):
    """Dosyaya içerik ekleme"""
    try:
        with open(dosya_yolu, "a", encoding=kodlama) as dosya:
            dosya.write(icerik)
        return True
    except Exception as e:
        raise Exception(f"Dosya ekleme hatası: {e}")

def dosya_satirlari_oku(dosya_yolu, kodlama="utf-8"):
    """Dosyayı satır satır okuma"""
    try:
        with open(dosya_yolu, "r", encoding=kodlama) as dosya:
            return dosya.readlines()
    except FileNotFoundError:
        raise FileNotFoundError(f"Dosya bulunamadı: {dosya_yolu}")
    except Exception as e:
        raise Exception(f"Dosya okuma hatası: {e}")

# Dosya durumu kontrolleri
def dosya_varmi(dosya_yolu):
    """os.path.exists() fonksiyonunun Türkçe karşılığı"""
    return os.path.exists(dosya_yolu)

def dosya_mi(yol):
    """os.path.isfile() fonksiyonunun Türkçe karşılığı"""
    return os.path.isfile(yol)

def dizin_mi(yol):
    """os.path.isdir() fonksiyonunun Türkçe karşılığı"""
    return os.path.isdir(yol)

def dosya_boyutu(dosya_yolu):
    """os.path.getsize() fonksiyonunun Türkçe karşılığı"""
    return os.path.getsize(dosya_yolu)

def dosya_degisim_zamani(dosya_yolu):
    """os.path.getmtime() fonksiyonunun Türkçe karşılığı"""
    return os.path.getmtime(dosya_yolu)

# Dosya ve dizin işlemleri
def dosya_sil(dosya_yolu):
    """os.remove() fonksiyonunun Türkçe karşılığı"""
    try:
        os.remove(dosya_yolu)
        return True
    except FileNotFoundError:
        raise FileNotFoundError(f"Dosya bulunamadı: {dosya_yolu}")
    except Exception as e:
        raise Exception(f"Dosya silme hatası: {e}")

def dosya_kopyala(kaynak, hedef):
    """shutil.copy2() fonksiyonunun Türkçe karşılığı"""
    try:
        shutil.copy2(kaynak, hedef)
        return True
    except Exception as e:
        raise Exception(f"Dosya kopyalama hatası: {e}")

def dosya_tasi(kaynak, hedef):
    """shutil.move() fonksiyonunun Türkçe karşılığı"""
    try:
        shutil.move(kaynak, hedef)
        return True
    except Exception as e:
        raise Exception(f"Dosya taşıma hatası: {e}")

def dosya_yeniden_adlandir(eski_ad, yeni_ad):
    """os.rename() fonksiyonunun Türkçe karşılığı"""
    try:
        os.rename(eski_ad, yeni_ad)
        return True
    except Exception as e:
        raise Exception(f"Dosya yeniden adlandırma hatası: {e}")

# Dizin işlemleri
def dizin_olustur(dizin_yolu):
    """os.makedirs() fonksiyonunun Türkçe karşılığı"""
    try:
        os.makedirs(dizin_yolu, exist_ok=True)
        return True
    except Exception as e:
        raise Exception(f"Dizin oluşturma hatası: {e}")

def dizin_sil(dizin_yolu):
    """shutil.rmtree() fonksiyonunun Türkçe karşılığı"""
    try:
        shutil.rmtree(dizin_yolu)
        return True
    except Exception as e:
        raise Exception(f"Dizin silme hatası: {e}")

def dizin_listele(dizin_yolu="."):
    """os.listdir() fonksiyonunun Türkçe karşılığı"""
    try:
        return os.listdir(dizin_yolu)
    except Exception as e:
        raise Exception(f"Dizin listeleme hatası: {e}")

def calisma_dizini():
    """os.getcwd() fonksiyonunun Türkçe karşılığı"""
    return os.getcwd()

def dizin_degistir(yeni_dizin):
    """os.chdir() fonksiyonunun Türkçe karşılığı"""
    try:
        os.chdir(yeni_dizin)
        return True
    except Exception as e:
        raise Exception(f"Dizin değiştirme hatası: {e}")

# Yol işlemleri
def yol_birlestir(*yollar):
    """os.path.join() fonksiyonunun Türkçe karşılığı"""
    return os.path.join(*yollar)

def yol_ayir(yol):
    """os.path.split() fonksiyonunun Türkçe karşılığı"""
    return os.path.split(yol)

def dosya_adi_al(yol):
    """os.path.basename() fonksiyonunun Türkçe karşılığı"""
    return os.path.basename(yol)

def dizin_adi_al(yol):
    """os.path.dirname() fonksiyonunun Türkçe karşılığı"""
    return os.path.dirname(yol)

def uzanti_al(dosya_yolu):
    """Dosya uzantısını alma"""
    return os.path.splitext(dosya_yolu)[1]

def mutlak_yol(yol):
    """os.path.abspath() fonksiyonunun Türkçe karşılığı"""
    return os.path.abspath(yol)

# JSON işlemleri
def json_oku(dosya_yolu, kodlama="utf-8"):
    """JSON dosyası okuma"""
    try:
        with open(dosya_yolu, "r", encoding=kodlama) as dosya:
            return json.load(dosya)
    except Exception as e:
        raise Exception(f"JSON okuma hatası: {e}")

def json_yaz(dosya_yolu, veri, kodlama="utf-8", girintili=True):
    """JSON dosyası yazma"""
    try:
        with open(dosya_yolu, "w", encoding=kodlama) as dosya:
            if girintili:
                json.dump(veri, dosya, ensure_ascii=False, indent=2)
            else:
                json.dump(veri, dosya, ensure_ascii=False)
        return True
    except Exception as e:
        raise Exception(f"JSON yazma hatası: {e}")

# CSV işlemleri
def csv_oku(dosya_yolu, kodlama="utf-8", ayirici=","):
    """CSV dosyası okuma"""
    try:
        with open(dosya_yolu, "r", encoding=kodlama, newline="") as dosya:
            okuyucu = csv.reader(dosya, delimiter=ayirici)
            return list(okuyucu)
    except Exception as e:
        raise Exception(f"CSV okuma hatası: {e}")

def csv_yaz(dosya_yolu, veri, kodlama="utf-8", ayirici=","):
    """CSV dosyası yazma"""
    try:
        with open(dosya_yolu, "w", encoding=kodlama, newline="") as dosya:
            yazici = csv.writer(dosya, delimiter=ayirici)
            yazici.writerows(veri)
        return True
    except Exception as e:
        raise Exception(f"CSV yazma hatası: {e}")

# Yardımcı fonksiyonlar
def dosya_uzantisi_degistir(dosya_yolu, yeni_uzanti):
    """Dosya uzantısını değiştirme"""
    temel_ad = os.path.splitext(dosya_yolu)[0]
    return f"{temel_ad}.{yeni_uzanti.lstrip('.')}"

def gecici_dosya_olustur(uzanti="txt"):
    """Geçici dosya oluşturma"""
    import tempfile
    return tempfile.NamedTemporaryFile(suffix=f".{uzanti}", delete=False).name

def dosya_izinleri_al(dosya_yolu):
    """Dosya izinlerini alma"""
    return oct(os.stat(dosya_yolu).st_mode)[-3:]