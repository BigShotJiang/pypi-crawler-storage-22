"""
Matematik işlemleri için Türkçe fonksiyonlar
"""

import math
import random

# Temel matematik fonksiyonları
def karekok(sayi):
    """math.sqrt() fonksiyonunun Türkçe karşılığı"""
    return math.sqrt(sayi)

def kare(sayi):
    """Sayının karesini alma"""
    return sayi ** 2

def kup(sayi):
    """Sayının küpünü alma"""
    return sayi ** 3

def us_alma(taban, us):
    """pow() fonksiyonunun Türkçe karşılığı"""
    return pow(taban, us)

def logaritma(sayi, taban=math.e):
    """math.log() fonksiyonunun Türkçe karşılığı"""
    return math.log(sayi, taban)

def dogal_logaritma(sayi):
    """math.log() fonksiyonunun Türkçe karşılığı (doğal logaritma)"""
    return math.log(sayi)

def on_tabanli_logaritma(sayi):
    """math.log10() fonksiyonunun Türkçe karşılığı"""
    return math.log10(sayi)

# Trigonometrik fonksiyonlar
def sinus(aci):
    """math.sin() fonksiyonunun Türkçe karşılığı"""
    return math.sin(aci)

def kosinus(aci):
    """math.cos() fonksiyonunun Türkçe karşılığı"""
    return math.cos(aci)

def tanjant(aci):
    """math.tan() fonksiyonunun Türkçe karşılığı"""
    return math.tan(aci)

def ark_sinus(deger):
    """math.asin() fonksiyonunun Türkçe karşılığı"""
    return math.asin(deger)

def ark_kosinus(deger):
    """math.acos() fonksiyonunun Türkçe karşılığı"""
    return math.acos(deger)

def ark_tanjant(deger):
    """math.atan() fonksiyonunun Türkçe karşılığı"""
    return math.atan(deger)

# Açı dönüşümleri
def radyandan_dereceye(radyan):
    """math.degrees() fonksiyonunun Türkçe karşılığı"""
    return math.degrees(radyan)

def dereceden_radyana(derece):
    """math.radians() fonksiyonunun Türkçe karşılığı"""
    return math.radians(derece)

# Yuvarlama ve taban fonksiyonları
def tavan(sayi):
    """math.ceil() fonksiyonunun Türkçe karşılığı"""
    return math.ceil(sayi)

def taban(sayi):
    """math.floor() fonksiyonunun Türkçe karşılığı"""
    return math.floor(sayi)

def kesir_bolumu(sayi):
    """math.modf() fonksiyonunun Türkçe karşılığı"""
    return math.modf(sayi)

# Faktöriyel ve kombinasyon
def faktoriyel(sayi):
    """math.factorial() fonksiyonunun Türkçe karşılığı"""
    return math.factorial(sayi)

def kombinasyon(n, k):
    """math.comb() fonksiyonunun Türkçe karşılığı (Python 3.8+)"""
    if hasattr(math, 'comb'):
        return math.comb(n, k)
    else:
        return faktoriyel(n) // (faktoriyel(k) * faktoriyel(n - k))

def permutasyon(n, k):
    """math.perm() fonksiyonunun Türkçe karşılığı (Python 3.8+)"""
    if hasattr(math, 'perm'):
        return math.perm(n, k)
    else:
        return faktoriyel(n) // faktoriyel(n - k)

# Rastgele sayı üretimi
def rastgele_sayi():
    """random.random() fonksiyonunun Türkçe karşılığı"""
    return random.random()

def rastgele_tam_sayi(baslangic, bitis):
    """random.randint() fonksiyonunun Türkçe karşılığı"""
    return random.randint(baslangic, bitis)

def rastgele_sec(dizi):
    """random.choice() fonksiyonunun Türkçe karşılığı"""
    return random.choice(dizi)

def karistir(dizi):
    """random.shuffle() fonksiyonunun Türkçe karşılığı"""
    random.shuffle(dizi)
    return dizi

def rastgele_ornekle(dizi, adet):
    """random.sample() fonksiyonunun Türkçe karşılığı"""
    return random.sample(dizi, adet)

# İstatistik fonksiyonları
def ortalama(dizi):
    """Aritmetik ortalama hesaplama"""
    return sum(dizi) / len(dizi)

def medyan(dizi):
    """Medyan hesaplama"""
    sirali = sorted(dizi)
    n = len(sirali)
    if n % 2 == 0:
        return (sirali[n//2 - 1] + sirali[n//2]) / 2
    else:
        return sirali[n//2]

def varyans(dizi):
    """Varyans hesaplama"""
    ort = ortalama(dizi)
    return sum((x - ort) ** 2 for x in dizi) / len(dizi)

def standart_sapma(dizi):
    """Standart sapma hesaplama"""
    return karekok(varyans(dizi))

# Sabitler
PI = math.pi
E = math.e
SONSUZ = math.inf
NEGATIF_SONSUZ = -math.inf

# Yardımcı fonksiyonlar
def mutlak_deger(sayi):
    """abs() fonksiyonunun Türkçe karşılığı"""
    return abs(sayi)

def isaret(sayi):
    """Sayının işaretini döndürür"""
    if sayi > 0:
        return 1
    elif sayi < 0:
        return -1
    else:
        return 0

def cift_mi(sayi):
    """Sayının çift olup olmadığını kontrol eder"""
    return sayi % 2 == 0

def tek_mi(sayi):
    """Sayının tek olup olmadığını kontrol eder"""
    return sayi % 2 == 1

def asal_mi(sayi):
    """Sayının asal olup olmadığını kontrol eder"""
    if sayi < 2:
        return False
    for i in range(2, int(karekok(sayi)) + 1):
        if sayi % i == 0:
            return False
    return True