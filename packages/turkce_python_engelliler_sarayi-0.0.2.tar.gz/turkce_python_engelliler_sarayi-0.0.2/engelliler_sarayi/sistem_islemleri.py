"""
Sistem işlemleri için Türkçe fonksiyonlar
"""

import os
import sys
import platform
import subprocess
try:
    import psutil
    PSUTIL_MEVCUT = True
except ImportError:
    PSUTIL_MEVCUT = False
    psutil = None

# Sistem bilgileri
def isletim_sistemi():
    """İşletim sistemi adını döndürür"""
    return platform.system()

def sistem_mimarisi():
    """Sistem mimarisini döndürür"""
    return platform.machine()

def python_surumu():
    """Python sürümünü döndürür"""
    return platform.python_version()

def bilgisayar_adi():
    """Bilgisayar adını döndürür"""
    return platform.node()

def kullanici_adi():
    """Mevcut kullanıcı adını döndürür"""
    return os.getlogin() if hasattr(os, 'getlogin') else os.environ.get('USER', os.environ.get('USERNAME', 'Bilinmiyor'))

def ev_dizini():
    """Kullanıcının ev dizinini döndürür"""
    return os.path.expanduser('~')

def gecici_dizin():
    """Geçici dosyalar dizinini döndürür"""
    import tempfile
    return tempfile.gettempdir()

# Çevre değişkenleri
def cevre_degiskeni_al(ad, varsayilan=None):
    """Çevre değişkenini alır"""
    return os.environ.get(ad, varsayilan)

def cevre_degiskeni_ata(ad, deger):
    """Çevre değişkeni atar"""
    os.environ[ad] = str(deger)

def tum_cevre_degiskenleri():
    """Tüm çevre değişkenlerini döndürür"""
    return dict(os.environ)

# Komut çalıştırma
def komut_calistir(komut, kabuk=True):
    """Sistem komutu çalıştırır"""
    try:
        sonuc = subprocess.run(
            komut, 
            shell=kabuk, 
            capture_output=True, 
            text=True,
            timeout=30
        )
        return {
            'cikis_kodu': sonuc.returncode,
            'cikti': sonuc.stdout,
            'hata': sonuc.stderr,
            'basarili': sonuc.returncode == 0
        }
    except subprocess.TimeoutExpired:
        return {'hata': 'Komut zaman aşımına uğradı', 'basarili': False}
    except Exception as e:
        return {'hata': str(e), 'basarili': False}

def komut_calistir_canli(komut, kabuk=True):
    """Komutu canlı çıktı ile çalıştırır"""
    try:
        process = subprocess.Popen(
            komut,
            shell=kabuk,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True
        )
        
        cikti_satirlari = []
        for satir in process.stdout:
            print(satir.rstrip())
            cikti_satirlari.append(satir.rstrip())
        
        process.wait()
        return {
            'cikis_kodu': process.returncode,
            'cikti': '\n'.join(cikti_satirlari),
            'basarili': process.returncode == 0
        }
    except Exception as e:
        return {'hata': str(e), 'basarili': False}

# Dosya sistemi bilgileri
def disk_kullanimi(yol='.'):
    """Disk kullanım bilgilerini döndürür"""
    try:
        if hasattr(os, 'statvfs'):  # Unix/Linux
            stat = os.statvfs(yol)
            toplam = stat.f_frsize * stat.f_blocks
            bos = stat.f_frsize * stat.f_available
            kullanilan = toplam - bos
        else:  # Windows
            import shutil
            toplam, kullanilan, bos = shutil.disk_usage(yol)
        
        return {
            'toplam': toplam,
            'kullanilan': kullanilan,
            'bos': bos,
            'kullanim_yuzdesi': (kullanilan / toplam) * 100 if toplam > 0 else 0
        }
    except Exception as e:
        return {'hata': str(e)}

def bellek_kullanimi():
    """Bellek kullanım bilgilerini döndürür"""
    try:
        if PSUTIL_MEVCUT and psutil:
            bellek = psutil.virtual_memory()
            return {
                'toplam': bellek.total,
                'kullanilan': bellek.used,
                'bos': bellek.available,
                'kullanim_yuzdesi': bellek.percent
            }
        else:
            return {'hata': 'psutil kütüphanesi gerekli'}
    except Exception as e:
        return {'hata': str(e)}

def cpu_kullanimi():
    """CPU kullanım yüzdesini döndürür"""
    try:
        if PSUTIL_MEVCUT and psutil:
            return psutil.cpu_percent(interval=1)
        else:
            return {'hata': 'psutil kütüphanesi gerekli'}
    except Exception as e:
        return {'hata': str(e)}

# Ağ bilgileri
def ag_arayuzleri():
    """Ağ arayüzlerini listeler"""
    try:
        if PSUTIL_MEVCUT and psutil:
            arayuzler = psutil.net_if_addrs()
            sonuc = {}
            for arayuz, adresler in arayuzler.items():
                sonuc[arayuz] = []
                for adres in adresler:
                    sonuc[arayuz].append({
                        'aile': str(adres.family),
                        'adres': adres.address,
                        'netmask': adres.netmask,
                        'broadcast': adres.broadcast
                    })
            return sonuc
        else:
            return {'hata': 'psutil kütüphanesi gerekli'}
    except Exception as e:
        return {'hata': str(e)}

# Süreç yönetimi
def calisanlar_surecler():
    """Çalışan süreçleri listeler"""
    try:
        if PSUTIL_MEVCUT and psutil:
            surecler = []
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
                try:
                    surecler.append(proc.info)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            return surecler
        else:
            return {'hata': 'psutil kütüphanesi gerekli'}
    except Exception as e:
        return {'hata': str(e)}

def surec_oldur(pid):
    """Belirtilen PID'li süreci öldürür"""
    try:
        if PSUTIL_MEVCUT and psutil:
            proc = psutil.Process(pid)
            proc.terminate()
            return {'basarili': True}
        else:
            return {'hata': 'psutil kütüphanesi gerekli'}
    except Exception as e:
        return {'hata': str(e)}

# Sistem performansı
def sistem_bilgileri():
    """Kapsamlı sistem bilgilerini döndürür"""
    bilgiler = {
        'isletim_sistemi': isletim_sistemi(),
        'mimari': sistem_mimarisi(),
        'python_surumu': python_surumu(),
        'bilgisayar_adi': bilgisayar_adi(),
        'kullanici_adi': kullanici_adi(),
        'ev_dizini': ev_dizini()
    }
    
    # Ek bilgiler (mümkünse)
    try:
        bilgiler['disk_kullanimi'] = disk_kullanimi()
        bilgiler['bellek_kullanimi'] = bellek_kullanimi()
        bilgiler['cpu_kullanimi'] = cpu_kullanimi()
    except:
        pass
    
    return bilgiler

# Yardımcı fonksiyonlar
def dosya_izinleri_kontrol(dosya_yolu):
    """Dosya izinlerini kontrol eder"""
    return {
        'okunabilir': os.access(dosya_yolu, os.R_OK),
        'yazilabilir': os.access(dosya_yolu, os.W_OK),
        'calistirilabilir': os.access(dosya_yolu, os.X_OK)
    }

def yol_mutlak_mi(yol):
    """Yolun mutlak yol olup olmadığını kontrol eder"""
    return os.path.isabs(yol)

def yol_var_mi(yol):
    """Yolun var olup olmadığını kontrol eder"""
    return os.path.exists(yol)

def sembolik_baglanti_mi(yol):
    """Yolun sembolik bağlantı olup olmadığını kontrol eder"""
    return os.path.islink(yol)

# Platform özel fonksiyonlar
def windows_mi():
    """Windows işletim sistemi mi kontrol eder"""
    return platform.system().lower() == 'windows'

def linux_mi():
    """Linux işletim sistemi mi kontrol eder"""
    return platform.system().lower() == 'linux'

def macos_mi():
    """macOS işletim sistemi mi kontrol eder"""
    return platform.system().lower() == 'darwin'