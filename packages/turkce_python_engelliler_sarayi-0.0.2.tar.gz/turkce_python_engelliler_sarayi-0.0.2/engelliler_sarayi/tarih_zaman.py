"""
Tarih ve zaman işlemleri için Türkçe fonksiyonlar
"""

import datetime
import time
import calendar

# Temel tarih/zaman fonksiyonları
def simdi():
    """datetime.now() fonksiyonunun Türkçe karşılığı"""
    return datetime.datetime.now()

def bugun():
    """datetime.date.today() fonksiyonunun Türkçe karşılığı"""
    return datetime.date.today()

def su_an():
    """time.time() fonksiyonunun Türkçe karşılığı"""
    return time.time()

def bekle(saniye):
    """time.sleep() fonksiyonunun Türkçe karşılığı"""
    time.sleep(saniye)

# Tarih oluşturma
def tarih_olustur(yil, ay, gun):
    """datetime.date() fonksiyonunun Türkçe karşılığı"""
    return datetime.date(yil, ay, gun)

def zaman_olustur(saat, dakika, saniye=0):
    """datetime.time() fonksiyonunun Türkçe karşılığı"""
    return datetime.time(saat, dakika, saniye)

def tarih_zaman_olustur(yil, ay, gun, saat=0, dakika=0, saniye=0):
    """datetime.datetime() fonksiyonunun Türkçe karşılığı"""
    return datetime.datetime(yil, ay, gun, saat, dakika, saniye)

# Tarih formatları
def tarih_formatla(tarih, format="%d/%m/%Y"):
    """Tarihi belirtilen formatta string'e çevirir"""
    return tarih.strftime(format)

def tarih_ayristir(tarih_str, format="%d/%m/%Y"):
    """String'i tarihe çevirir"""
    return datetime.datetime.strptime(tarih_str, format)

# Türkçe ay isimleri
AYLAR = [
    "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran",
    "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"
]

GUNLER = [
    "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"
]

def ay_adi(ay_numarasi):
    """Ay numarasından Türkçe ay adını döndürür"""
    if 1 <= ay_numarasi <= 12:
        return AYLAR[ay_numarasi - 1]
    return "Geçersiz ay"

def gun_adi(gun_numarasi):
    """Gün numarasından Türkçe gün adını döndürür (0=Pazartesi)"""
    if 0 <= gun_numarasi <= 6:
        return GUNLER[gun_numarasi]
    return "Geçersiz gün"

def haftanin_gunu(tarih):
    """Tarihin haftanın hangi günü olduğunu döndürür"""
    return gun_adi(tarih.weekday())

# Tarih hesaplamaları
def gun_ekle(tarih, gun_sayisi):
    """Tarihe gün ekler"""
    return tarih + datetime.timedelta(days=gun_sayisi)

def gun_cikar(tarih, gun_sayisi):
    """Tarihten gün çıkarır"""
    return tarih - datetime.timedelta(days=gun_sayisi)

def saat_ekle(tarih, saat_sayisi):
    """Tarihe saat ekler"""
    return tarih + datetime.timedelta(hours=saat_sayisi)

def dakika_ekle(tarih, dakika_sayisi):
    """Tarihe dakika ekler"""
    return tarih + datetime.timedelta(minutes=dakika_sayisi)

def tarih_farki(tarih1, tarih2):
    """İki tarih arasındaki farkı döndürür"""
    return abs((tarih1 - tarih2).days)

def saat_farki(tarih1, tarih2):
    """İki tarih arasındaki saat farkını döndürür"""
    return abs((tarih1 - tarih2).total_seconds() / 3600)

# Özel tarih fonksiyonları
def artik_yil_mi(yil):
    """Yılın artık yıl olup olmadığını kontrol eder"""
    return calendar.isleap(yil)

def ayin_gun_sayisi(yil, ay):
    """Belirtilen ay ve yıldaki gün sayısını döndürür"""
    return calendar.monthrange(yil, ay)[1]

def yilin_gun_sayisi(yil):
    """Yıldaki toplam gün sayısını döndürür"""
    return 366 if artik_yil_mi(yil) else 365

# Zaman ölçümü
class ZamanOlcer:
    """Zaman ölçümü için Türkçe sınıf"""
    
    def __init__(self):
        self.baslangic = None
        self.bitis = None
    
    def baslat(self):
        """Zaman ölçümünü başlatır"""
        self.baslangic = time.time()
    
    def durdur(self):
        """Zaman ölçümünü durdurur"""
        self.bitis = time.time()
    
    def gecen_sure(self):
        """Geçen süreyi saniye cinsinden döndürür"""
        if self.baslangic and self.bitis:
            return self.bitis - self.baslangic
        elif self.baslangic:
            return time.time() - self.baslangic
        return 0

def zaman_olcer_olustur():
    """Yeni zaman ölçer oluşturur"""
    return ZamanOlcer()

# Yaş hesaplama
def yas_hesapla(dogum_tarihi, referans_tarihi=None):
    """Doğum tarihinden yaşı hesaplar"""
    if referans_tarihi is None:
        referans_tarihi = bugun()
    
    yas = referans_tarihi.year - dogum_tarihi.year
    
    # Doğum günü henüz gelmemişse yaşı bir azalt
    if (referans_tarihi.month, referans_tarihi.day) < (dogum_tarihi.month, dogum_tarihi.day):
        yas -= 1
    
    return yas

# Türkçe tarih formatları
def turkce_tarih(tarih):
    """Tarihi Türkçe formatta döndürür"""
    gun = tarih.day
    ay = ay_adi(tarih.month)
    yil = tarih.year
    gun_adi_str = haftanin_gunu(tarih)
    
    return f"{gun} {ay} {yil} {gun_adi_str}"

def kisa_turkce_tarih(tarih):
    """Tarihi kısa Türkçe formatta döndürür"""
    gun = tarih.day
    ay = ay_adi(tarih.month)[:3]  # İlk 3 harf
    yil = tarih.year
    
    return f"{gun} {ay} {yil}"