"""
Temel Python fonksiyonlarının Türkçe karşılıkları
"""

import builtins
import sys
import os

# Temel giriş/çıkış fonksiyonları
def yazdir(*args, **kwargs):
    """print() fonksiyonunun Türkçe karşılığı"""
    return builtins.print(*args, **kwargs)

def girdi(mesaj=""):
    """input() fonksiyonunun Türkçe karşılığı"""
    return builtins.input(mesaj)

# Veri tipi dönüşümleri
def tam_sayi(deger):
    """int() fonksiyonunun Türkçe karşılığı"""
    return int(deger)

def ondalik_sayi(deger):
    """float() fonksiyonunun Türkçe karşılığı"""
    return float(deger)

def metin(deger):
    """str() fonksiyonunun Türkçe karşılığı"""
    return str(deger)

def mantiksal(deger):
    """bool() fonksiyonunun Türkçe karşılığı"""
    return bool(deger)

# Veri yapısı fonksiyonları
def uzunluk(nesne):
    """len() fonksiyonunun Türkçe karşılığı"""
    return len(nesne)

def tip(nesne):
    """type() fonksiyonunun Türkçe karşılığı"""
    return type(nesne)

def kimlik(nesne):
    """id() fonksiyonunun Türkçe karşılığı"""
    return id(nesne)

# Koleksiyon fonksiyonları
def liste(*args):
    """list() fonksiyonunun Türkçe karşılığı"""
    if len(args) == 0:
        return []
    elif len(args) == 1:
        return list(args[0])
    else:
        return list(args)

def demet(*args):
    """tuple() fonksiyonunun Türkçe karşılığı"""
    if len(args) == 0:
        return ()
    elif len(args) == 1:
        return tuple(args[0])
    else:
        return tuple(args)

def sozluk(*args, **kwargs):
    """dict() fonksiyonunun Türkçe karşılığı"""
    return dict(*args, **kwargs)

def kume(*args):
    """set() fonksiyonunun Türkçe karşılığı"""
    if len(args) == 0:
        return set()
    elif len(args) == 1:
        return set(args[0])
    else:
        return set(args)

# Aralık fonksiyonu
def aralik(*args):
    """range() fonksiyonunun Türkçe karşılığı"""
    return range(*args)

# Sıralama ve filtreleme
def sirala(dizi, ters=False):
    """sorted() fonksiyonunun Türkçe karşılığı"""
    return sorted(dizi, reverse=ters)

def filtrele(fonksiyon, dizi):
    """filter() fonksiyonunun Türkçe karşılığı"""
    return list(filter(fonksiyon, dizi))

def haritala(fonksiyon, dizi):
    """map() fonksiyonunun Türkçe karşılığı"""
    return list(map(fonksiyon, dizi))

# Matematiksel fonksiyonlar
def mutlak(sayi):
    """abs() fonksiyonunun Türkçe karşılığı"""
    return abs(sayi)

def en_buyuk(*args):
    """max() fonksiyonunun Türkçe karşılığı"""
    return max(*args)

def en_kucuk(*args):
    """min() fonksiyonunun Türkçe karşılığı"""
    return min(*args)

def topla(dizi):
    """sum() fonksiyonunun Türkçe karşılığı"""
    return sum(dizi)

def yuvarla(sayi, basamak=0):
    """round() fonksiyonunun Türkçe karşılığı"""
    return round(sayi, basamak)

# Dosya ve sistem fonksiyonları
def cikis(kod=0):
    """sys.exit() fonksiyonunun Türkçe karşılığı"""
    sys.exit(kod)

def sistem_komutu(komut):
    """os.system() fonksiyonunun Türkçe karşılığı"""
    return os.system(komut)

# Yardımcı fonksiyonlar
def varmi(nesne, ozellik):
    """hasattr() fonksiyonunun Türkçe karşılığı"""
    return hasattr(nesne, ozellik)

def al(nesne, ozellik, varsayilan=None):
    """getattr() fonksiyonunun Türkçe karşılığı"""
    return getattr(nesne, ozellik, varsayilan)

def ata(nesne, ozellik, deger):
    """setattr() fonksiyonunun Türkçe karşılığı"""
    return setattr(nesne, ozellik, deger)

def sil(nesne, ozellik):
    """delattr() fonksiyonunun Türkçe karşılığı"""
    return delattr(nesne, ozellik)