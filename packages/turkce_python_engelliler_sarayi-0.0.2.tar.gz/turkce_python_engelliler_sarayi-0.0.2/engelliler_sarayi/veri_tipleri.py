"""
Veri tipleri ve işlemleri için Türkçe fonksiyonlar
"""

# String (Metin) işlemleri
class TurkceMetin(str):
    """String sınıfının Türkçe karşılığı"""
    
    def buyuk_harf(self):
        """upper() metodunun Türkçe karşılığı"""
        return TurkceMetin(self.upper())
    
    def kucuk_harf(self):
        """lower() metodunun Türkçe karşılığı"""
        return TurkceMetin(self.lower())
    
    def baslik_harf(self):
        """title() metodunun Türkçe karşılığı"""
        return TurkceMetin(self.title())
    
    def ilk_harf_buyuk(self):
        """capitalize() metodunun Türkçe karşılığı"""
        return TurkceMetin(self.capitalize())
    
    def parcala(self, ayirici=None):
        """split() metodunun Türkçe karşılığı"""
        return [TurkceMetin(x) for x in self.split(ayirici)]
    
    def birlestir(self, dizi):
        """join() metodunun Türkçe karşılığı"""
        return TurkceMetin(self.join(dizi))
    
    def degistir(self, eski, yeni):
        """replace() metodunun Türkçe karşılığı"""
        return TurkceMetin(self.replace(eski, yeni))
    
    def bul(self, alt_metin):
        """find() metodunun Türkçe karşılığı"""
        return self.find(alt_metin)
    
    def icerirmi(self, alt_metin):
        """in operatörünün Türkçe karşılığı"""
        return alt_metin in self
    
    def baslarmi(self, metin):
        """startswith() metodunun Türkçe karşılığı"""
        return self.startswith(metin)
    
    def bitirirmi(self, metin):
        """endswith() metodunun Türkçe karşılığı"""
        return self.endswith(metin)
    
    def temizle(self):
        """strip() metodunun Türkçe karşılığı"""
        return TurkceMetin(self.strip())

# Liste işlemleri
class TurkceListe(list):
    """List sınıfının Türkçe karşılığı"""
    
    def ekle(self, eleman):
        """append() metodunun Türkçe karşılığı"""
        self.append(eleman)
    
    def uzat(self, dizi):
        """extend() metodunun Türkçe karşılığı"""
        self.extend(dizi)
    
    def ekle_konuma(self, konum, eleman):
        """insert() metodunun Türkçe karşılığı"""
        self.insert(konum, eleman)
    
    def cikar(self, eleman):
        """remove() metodunun Türkçe karşılığı"""
        self.remove(eleman)
    
    def cikar_konumdan(self, konum=-1):
        """pop() metodunun Türkçe karşılığı"""
        return self.pop(konum)
    
    def temizle(self):
        """clear() metodunun Türkçe karşılığı"""
        self.clear()
    
    def bul(self, eleman):
        """index() metodunun Türkçe karşılığı"""
        return self.index(eleman)
    
    def say(self, eleman):
        """count() metodunun Türkçe karşılığı"""
        return self.count(eleman)
    
    def sirala(self, ters=False):
        """sort() metodunun Türkçe karşılığı"""
        self.sort(reverse=ters)
    
    def ters_cevir(self):
        """reverse() metodunun Türkçe karşılığı"""
        self.reverse()
    
    def kopyala(self):
        """copy() metodunun Türkçe karşılığı"""
        return TurkceListe(self.copy())

# Sözlük işlemleri
class TurkceSozluk(dict):
    """Dict sınıfının Türkçe karşılığı"""
    
    def anahtarlar(self):
        """keys() metodunun Türkçe karşılığı"""
        return self.keys()
    
    def degerler(self):
        """values() metodunun Türkçe karşılığı"""
        return self.values()
    
    def ogeler(self):
        """items() metodunun Türkçe karşılığı"""
        return self.items()
    
    def al(self, anahtar, varsayilan=None):
        """get() metodunun Türkçe karşılığı"""
        return self.get(anahtar, varsayilan)
    
    def cikar(self, anahtar, varsayilan=None):
        """pop() metodunun Türkçe karşılığı"""
        if varsayilan is None:
            return self.pop(anahtar)
        return self.pop(anahtar, varsayilan)
    
    def guncelle(self, diger):
        """update() metodunun Türkçe karşılığı"""
        self.update(diger)
    
    def temizle(self):
        """clear() metodunun Türkçe karşılığı"""
        self.clear()
    
    def kopyala(self):
        """copy() metodunun Türkçe karşılığı"""
        return TurkceSozluk(self.copy())
    
    def varmi(self, anahtar):
        """in operatörünün Türkçe karşılığı"""
        return anahtar in self

# Küme işlemleri
class TurkceKume(set):
    """Set sınıfının Türkçe karşılığı"""
    
    def ekle(self, eleman):
        """add() metodunun Türkçe karşılığı"""
        self.add(eleman)
    
    def cikar(self, eleman):
        """remove() metodunun Türkçe karşılığı"""
        self.remove(eleman)
    
    def at(self, eleman):
        """discard() metodunun Türkçe karşılığı"""
        self.discard(eleman)
    
    def cikar_rastgele(self):
        """pop() metodunun Türkçe karşılığı"""
        return self.pop()
    
    def temizle(self):
        """clear() metodunun Türkçe karşılığı"""
        self.clear()
    
    def birlesim(self, diger):
        """union() metodunun Türkçe karşılığı"""
        return TurkceKume(self.union(diger))
    
    def kesisim(self, diger):
        """intersection() metodunun Türkçe karşılığı"""
        return TurkceKume(self.intersection(diger))
    
    def fark(self, diger):
        """difference() metodunun Türkçe karşılığı"""
        return TurkceKume(self.difference(diger))
    
    def varmi(self, eleman):
        """in operatörünün Türkçe karşılığı"""
        return eleman in self
    
    def kopyala(self):
        """copy() metodunun Türkçe karşılığı"""
        return TurkceKume(self.copy())

# Yardımcı fonksiyonlar
def metin_olustur(deger=""):
    """Türkçe metin oluşturma"""
    return TurkceMetin(deger)

def liste_olustur(dizi=None):
    """Türkçe liste oluşturma"""
    if dizi is None:
        return TurkceListe()
    return TurkceListe(dizi)

def sozluk_olustur(deger=None):
    """Türkçe sözlük oluşturma"""
    if deger is None:
        return TurkceSozluk()
    return TurkceSozluk(deger)

def kume_olustur(dizi=None):
    """Türkçe küme oluşturma"""
    if dizi is None:
        return TurkceKume()
    return TurkceKume(dizi)