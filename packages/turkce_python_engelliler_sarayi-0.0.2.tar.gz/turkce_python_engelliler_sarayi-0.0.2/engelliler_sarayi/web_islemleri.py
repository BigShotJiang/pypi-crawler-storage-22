"""
Web ve HTTP işlemleri için Türkçe fonksiyonlar
"""

try:
    import requests
    REQUESTS_MEVCUT = True
except ImportError:
    REQUESTS_MEVCUT = False

try:
    import urllib.request
    import urllib.parse
    import urllib.error
    URLLIB_MEVCUT = True
except ImportError:
    URLLIB_MEVCUT = False

import json

# HTTP istekleri
def get_istegi(url, basliklar=None):
    """HTTP GET isteği gönderir"""
    if REQUESTS_MEVCUT:
        try:
            yanit = requests.get(url, headers=basliklar)
            return {
                'durum_kodu': yanit.status_code,
                'icerik': yanit.text,
                'json': yanit.json() if yanit.headers.get('content-type', '').startswith('application/json') else None,
                'basliklar': dict(yanit.headers)
            }
        except Exception as e:
            return {'hata': str(e)}
    elif URLLIB_MEVCUT:
        try:
            istek = urllib.request.Request(url)
            if basliklar:
                for anahtar, deger in basliklar.items():
                    istek.add_header(anahtar, deger)
            
            with urllib.request.urlopen(istek) as yanit:
                icerik = yanit.read().decode('utf-8')
                return {
                    'durum_kodu': yanit.getcode(),
                    'icerik': icerik,
                    'json': json.loads(icerik) if yanit.headers.get('content-type', '').startswith('application/json') else None,
                    'basliklar': dict(yanit.headers)
                }
        except Exception as e:
            return {'hata': str(e)}
    else:
        return {'hata': 'HTTP kütüphanesi bulunamadı'}

def post_istegi(url, veri=None, json_veri=None, basliklar=None):
    """HTTP POST isteği gönderir"""
    if REQUESTS_MEVCUT:
        try:
            if json_veri:
                yanit = requests.post(url, json=json_veri, headers=basliklar)
            else:
                yanit = requests.post(url, data=veri, headers=basliklar)
            
            return {
                'durum_kodu': yanit.status_code,
                'icerik': yanit.text,
                'json': yanit.json() if yanit.headers.get('content-type', '').startswith('application/json') else None,
                'basliklar': dict(yanit.headers)
            }
        except Exception as e:
            return {'hata': str(e)}
    else:
        return {'hata': 'requests kütüphanesi gerekli'}

# URL işlemleri
def url_ayristir(url):
    """URL'yi parçalarına ayırır"""
    if URLLIB_MEVCUT:
        parsed = urllib.parse.urlparse(url)
        return {
            'protokol': parsed.scheme,
            'sunucu': parsed.netloc,
            'yol': parsed.path,
            'parametreler': parsed.params,
            'sorgu': parsed.query,
            'fragment': parsed.fragment
        }
    return {'hata': 'urllib kütüphanesi bulunamadı'}

def url_kodla(metin):
    """Metni URL için kodlar"""
    if URLLIB_MEVCUT:
        return urllib.parse.quote(metin)
    return metin

def url_coz(kodlu_metin):
    """URL kodlamasını çözer"""
    if URLLIB_MEVCUT:
        return urllib.parse.unquote(kodlu_metin)
    return kodlu_metin

def sorgu_parametreleri_ayristir(sorgu_str):
    """Sorgu parametrelerini sözlük olarak döndürür"""
    if URLLIB_MEVCUT:
        return dict(urllib.parse.parse_qsl(sorgu_str))
    return {}

# Dosya indirme
def dosya_indir(url, dosya_yolu, ilerleme_fonksiyonu=None):
    """URL'den dosya indirir"""
    if REQUESTS_MEVCUT:
        try:
            with requests.get(url, stream=True) as yanit:
                yanit.raise_for_status()
                toplam_boyut = int(yanit.headers.get('content-length', 0))
                indirilen = 0
                
                with open(dosya_yolu, 'wb') as dosya:
                    for chunk in yanit.iter_content(chunk_size=8192):
                        dosya.write(chunk)
                        indirilen += len(chunk)
                        
                        if ilerleme_fonksiyonu and toplam_boyut > 0:
                            yuzde = (indirilen / toplam_boyut) * 100
                            ilerleme_fonksiyonu(yuzde, indirilen, toplam_boyut)
                
                return {'basarili': True, 'boyut': indirilen}
        except Exception as e:
            return {'hata': str(e)}
    elif URLLIB_MEVCUT:
        try:
            urllib.request.urlretrieve(url, dosya_yolu)
            return {'basarili': True}
        except Exception as e:
            return {'hata': str(e)}
    else:
        return {'hata': 'HTTP kütüphanesi bulunamadı'}

# JSON API işlemleri
def json_api_cagir(url, metod='GET', veri=None, basliklar=None):
    """JSON API'ye istek gönderir"""
    if basliklar is None:
        basliklar = {}
    
    basliklar['Content-Type'] = 'application/json'
    basliklar['Accept'] = 'application/json'
    
    if metod.upper() == 'GET':
        return get_istegi(url, basliklar)
    elif metod.upper() == 'POST':
        return post_istegi(url, json_veri=veri, basliklar=basliklar)
    else:
        return {'hata': 'Desteklenmeyen HTTP metodu'}

# Basit web scraping
def web_sayfasi_oku(url, kodlama='utf-8'):
    """Web sayfasının HTML içeriğini okur"""
    sonuc = get_istegi(url)
    if 'hata' not in sonuc:
        return sonuc['icerik']
    return None

def web_sayfasi_baslik_bul(html_icerik):
    """HTML içeriğinden title etiketini bulur"""
    import re
    baslik_match = re.search(r'<title[^>]*>(.*?)</title>', html_icerik, re.IGNORECASE | re.DOTALL)
    if baslik_match:
        return baslik_match.group(1).strip()
    return None

# Yardımcı fonksiyonlar
def durum_kodu_acikla(kod):
    """HTTP durum kodunu açıklar"""
    kodlar = {
        200: 'Başarılı',
        201: 'Oluşturuldu',
        400: 'Hatalı İstek',
        401: 'Yetkisiz',
        403: 'Yasak',
        404: 'Bulunamadı',
        500: 'Sunucu Hatası',
        502: 'Kötü Ağ Geçidi',
        503: 'Hizmet Kullanılamıyor'
    }
    return kodlar.get(kod, f'Bilinmeyen kod: {kod}')

def internet_baglantisi_kontrol(test_url='http://www.google.com'):
    """İnternet bağlantısını kontrol eder"""
    try:
        sonuc = get_istegi(test_url)
        return 'hata' not in sonuc and sonuc.get('durum_kodu') == 200
    except:
        return False

# Basit form verileri
def form_verisi_olustur(veri_sozlugu):
    """Form verilerini URL encoded formatına çevirir"""
    if URLLIB_MEVCUT:
        return urllib.parse.urlencode(veri_sozlugu)
    return str(veri_sozlugu)

# Cookie işlemleri (basit)
def cookie_ayristir(cookie_str):
    """Cookie string'ini sözlük olarak ayırır"""
    cookies = {}
    if cookie_str:
        for item in cookie_str.split(';'):
            if '=' in item:
                key, value = item.strip().split('=', 1)
                cookies[key] = value
    return cookies