from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="turkce-python-engelliler-sarayi",
    version="0.0.2",
    author="Engelliler Sarayı Geliştirici",
    author_email="gelistirici@engelliersarayi.com",
    description="Python programlama dilini Türkçe olarak sunan kütüphane",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/kullanici/engelliler-sarayi",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Natural Language :: Turkish",
    ],
    python_requires=">=3.7",
    keywords="turkish, türkçe, python, programming, programlama",
)