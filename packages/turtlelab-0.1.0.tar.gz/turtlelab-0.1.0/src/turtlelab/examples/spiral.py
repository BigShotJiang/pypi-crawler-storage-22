# Draw a spiral
if True:
    t.speed(0)
t.pendown()
for i in range(100):
    t.forward(i)
    t.right(30)
