# Draw a square
t.speed(0)
t.pendown()
for i in range(4):
    t.forward(100)
    t.right(90)
t.penup()
