# Draw a star
t.speed(0)
for i in range(5):
    t.forward(200)
    t.right(144)
