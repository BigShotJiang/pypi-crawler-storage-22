"""PyJWT instrumentation for REPLAY mode."""

from .instrumentation import PyJWTInstrumentation

__all__ = ["PyJWTInstrumentation"]
