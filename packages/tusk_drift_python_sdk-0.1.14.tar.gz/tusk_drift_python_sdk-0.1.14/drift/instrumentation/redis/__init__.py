"""Redis instrumentation for Drift Python SDK."""

from .instrumentation import RedisInstrumentation

__all__ = ["RedisInstrumentation"]
