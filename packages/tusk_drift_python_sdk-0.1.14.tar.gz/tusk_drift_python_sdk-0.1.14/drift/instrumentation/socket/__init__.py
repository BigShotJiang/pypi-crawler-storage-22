"""Socket instrumentation for detecting unpatched dependencies."""

from .instrumentation import SocketInstrumentation

__all__ = ["SocketInstrumentation"]
