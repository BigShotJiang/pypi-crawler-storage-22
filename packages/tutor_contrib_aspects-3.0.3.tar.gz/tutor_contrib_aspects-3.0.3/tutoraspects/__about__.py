"""
Expose some package metadata.
"""

__version__ = "3.0.3"
